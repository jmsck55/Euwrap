// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _54hashfn(object _name_46791)
{
    object _len_46792 = NOVALUE;
    object _val_46793 = NOVALUE;
    object _int_46794 = NOVALUE;
    object _24297 = NOVALUE;
    object _24296 = NOVALUE;
    object _24293 = NOVALUE;
    object _24292 = NOVALUE;
    object _24281 = NOVALUE;
    object _24277 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:49		len = length(name)*/
    if (IS_SEQUENCE(_name_46791)){
            _len_46792 = SEQ_PTR(_name_46791)->length;
    }
    else {
        _len_46792 = 1;
    }

    /** symtab.e:51		val = name[1]*/
    _2 = (object)SEQ_PTR(_name_46791);
    _val_46793 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_val_46793))
    _val_46793 = (object)DBL_PTR(_val_46793)->dbl;

    /** symtab.e:52		int = name[$]*/
    if (IS_SEQUENCE(_name_46791)){
            _24277 = SEQ_PTR(_name_46791)->length;
    }
    else {
        _24277 = 1;
    }
    _2 = (object)SEQ_PTR(_name_46791);
    _int_46794 = (object)*(((s1_ptr)_2)->base + _24277);
    if (!IS_ATOM_INT(_int_46794))
    _int_46794 = (object)DBL_PTR(_int_46794)->dbl;

    /** symtab.e:53		int *= 256*/
    _int_46794 = _int_46794 * 256LL;

    /** symtab.e:54		val *= 2*/
    _val_46793 = _val_46793 + _val_46793;

    /** symtab.e:55		val += int + len*/
    _24281 = _int_46794 + _len_46792;
    if ((object)((uintptr_t)_24281 + (uintptr_t)HIGH_BITS) >= 0){
        _24281 = NewDouble((eudouble)_24281);
    }
    if (IS_ATOM_INT(_24281)) {
        _val_46793 = _val_46793 + _24281;
    }
    else {
        _val_46793 = NewDouble((eudouble)_val_46793 + DBL_PTR(_24281)->dbl);
    }
    DeRef(_24281);
    _24281 = NOVALUE;
    if (!IS_ATOM_INT(_val_46793)) {
        _1 = (object)(DBL_PTR(_val_46793)->dbl);
        DeRefDS(_val_46793);
        _val_46793 = _1;
    }

    /** symtab.e:57		if len = 3 then*/
    if (_len_46792 != 3LL)
    goto L1; // [51] 78

    /** symtab.e:58			val *= 32*/
    _val_46793 = _val_46793 * 32LL;

    /** symtab.e:59			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46791);
    _int_46794 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_46794))
    _int_46794 = (object)DBL_PTR(_int_46794)->dbl;

    /** symtab.e:60			val += int*/
    _val_46793 = _val_46793 + _int_46794;
    goto L2; // [75] 133
L1: 

    /** symtab.e:61		elsif len > 3 then*/
    if (_len_46792 <= 3LL)
    goto L3; // [80] 132

    /** symtab.e:62			val *= 32*/
    _val_46793 = _val_46793 * 32LL;

    /** symtab.e:63			int = name[2]*/
    _2 = (object)SEQ_PTR(_name_46791);
    _int_46794 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_int_46794))
    _int_46794 = (object)DBL_PTR(_int_46794)->dbl;

    /** symtab.e:64			val += int*/
    _val_46793 = _val_46793 + _int_46794;

    /** symtab.e:66			val *= 32*/
    _val_46793 = _val_46793 * 32LL;

    /** symtab.e:67			int = name[$-1]*/
    if (IS_SEQUENCE(_name_46791)){
            _24292 = SEQ_PTR(_name_46791)->length;
    }
    else {
        _24292 = 1;
    }
    _24293 = _24292 - 1LL;
    _24292 = NOVALUE;
    _2 = (object)SEQ_PTR(_name_46791);
    _int_46794 = (object)*(((s1_ptr)_2)->base + _24293);
    if (!IS_ATOM_INT(_int_46794))
    _int_46794 = (object)DBL_PTR(_int_46794)->dbl;

    /** symtab.e:68			val += int*/
    _val_46793 = _val_46793 + _int_46794;
L3: 
L2: 

    /** symtab.e:70		return remainder(val, NBUCKETS) + 1*/
    _24296 = (_val_46793 % 2003LL);
    _24297 = _24296 + 1;
    _24296 = NOVALUE;
    DeRefDS(_name_46791);
    DeRef(_24293);
    _24293 = NOVALUE;
    return _24297;
    ;
}


void _54remove_symbol(object _sym_46823)
{
    object _hash_46824 = NOVALUE;
    object _st_ptr_46825 = NOVALUE;
    object _24312 = NOVALUE;
    object _24311 = NOVALUE;
    object _24309 = NOVALUE;
    object _24308 = NOVALUE;
    object _24307 = NOVALUE;
    object _24305 = NOVALUE;
    object _24303 = NOVALUE;
    object _24302 = NOVALUE;
    object _24301 = NOVALUE;
    object _24298 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:79		hash = SymTab[sym][S_HASHVAL]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24298 = (object)*(((s1_ptr)_2)->base + _sym_46823);
    _2 = (object)SEQ_PTR(_24298);
    _hash_46824 = (object)*(((s1_ptr)_2)->base + 11LL);
    if (!IS_ATOM_INT(_hash_46824)){
        _hash_46824 = (object)DBL_PTR(_hash_46824)->dbl;
    }
    _24298 = NOVALUE;

    /** symtab.e:80		st_ptr = buckets[hash]*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _st_ptr_46825 = (object)*(((s1_ptr)_2)->base + _hash_46824);
    if (!IS_ATOM_INT(_st_ptr_46825))
    _st_ptr_46825 = (object)DBL_PTR(_st_ptr_46825)->dbl;

    /** symtab.e:82		while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_46825 == 0) {
        goto L2; // [32] 65
    }
    _24302 = (_st_ptr_46825 != _sym_46823);
    if (_24302 == 0)
    {
        DeRef(_24302);
        _24302 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24302);
        _24302 = NOVALUE;
    }

    /** symtab.e:83			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24303 = (object)*(((s1_ptr)_2)->base + _st_ptr_46825);
    _2 = (object)SEQ_PTR(_24303);
    _st_ptr_46825 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_46825)){
        _st_ptr_46825 = (object)DBL_PTR(_st_ptr_46825)->dbl;
    }
    _24303 = NOVALUE;

    /** symtab.e:84		end while*/
    goto L1; // [62] 32
L2: 

    /** symtab.e:86		if st_ptr then*/
    if (_st_ptr_46825 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** symtab.e:87			if st_ptr = buckets[hash] then*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _24305 = (object)*(((s1_ptr)_2)->base + _hash_46824);
    if (binary_op_a(NOTEQ, _st_ptr_46825, _24305)){
        _24305 = NOVALUE;
        goto L4; // [78] 105
    }
    _24305 = NOVALUE;

    /** symtab.e:89				buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24307 = (object)*(((s1_ptr)_2)->base + _st_ptr_46825);
    _2 = (object)SEQ_PTR(_24307);
    _24308 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24307 = NOVALUE;
    Ref(_24308);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _2 = (object)(((s1_ptr)_2)->base + _hash_46824);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24308;
    if( _1 != _24308 ){
        DeRef(_1);
    }
    _24308 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** symtab.e:92				SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_st_ptr_46825 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24311 = (object)*(((s1_ptr)_2)->base + _sym_46823);
    _2 = (object)SEQ_PTR(_24311);
    _24312 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24311 = NOVALUE;
    Ref(_24312);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24312;
    if( _1 != _24312 ){
        DeRef(_1);
    }
    _24312 = NOVALUE;
    _24309 = NOVALUE;
L5: 
L3: 

    /** symtab.e:95	end procedure*/
    return;
    ;
}


object _54NewBasicEntry(object _name_46857, object _varnum_46858, object _scope_46859, object _token_46860, object _hashval_46861, object _samehash_46863, object _type_sym_46865)
{
    object _new_46866 = NOVALUE;
    object _24321 = NOVALUE;
    object _24319 = NOVALUE;
    object _24318 = NOVALUE;
    object _24317 = NOVALUE;
    object _24316 = NOVALUE;
    object _24315 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:105		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** symtab.e:106			new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_46866);
    _new_46866 = Repeat(0LL, _36SIZEOF_ROUTINE_ENTRY_21202);
    goto L2; // [30] 42
L1: 

    /** symtab.e:108			new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_46866);
    _new_46866 = Repeat(0LL, _36SIZEOF_VAR_ENTRY_21205);
L2: 

    /** symtab.e:111		new[S_NEXT] = 0*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:112		new[S_NAME] = name*/
    RefDS(_name_46857);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_NAME_21076))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_NAME_21076);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _name_46857;
    DeRef(_1);

    /** symtab.e:113		new[S_SCOPE] = scope*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _scope_46859;
    DeRef(_1);

    /** symtab.e:114		new[S_MODE] = M_NORMAL*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);

    /** symtab.e:115		new[S_USAGE] = U_UNUSED*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:116		new[S_FILE_NO] = current_file_no*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21072))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36current_file_no_21439;
    DeRef(_1);

    /** symtab.e:118		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** symtab.e:120			new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:121			new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 38LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:123			new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:124			new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 40LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:126			new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 43LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:127			new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 44LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:128			new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 45LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:129			new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 46LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:131			new[S_ARG_MIN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 47LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** symtab.e:132			new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _24315 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24315 = - _36NOVALUE_21293;
        }
    }
    else {
        _24315 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 49LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24315;
    if( _1 != _24315 ){
        DeRef(_1);
    }
    _24315 = NOVALUE;

    /** symtab.e:134			new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 51LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** symtab.e:135			new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _24316 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24316 = - _36NOVALUE_21293;
        }
    }
    else {
        _24316 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 52LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24316;
    if( _1 != _24316 ){
        DeRef(_1);
    }
    _24316 = NOVALUE;

    /** symtab.e:137			new[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** symtab.e:138			new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _24317 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24317 = - _36NOVALUE_21293;
        }
    }
    else {
        _24317 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 39LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24317;
    if( _1 != _24317 ){
        DeRef(_1);
    }
    _24317 = NOVALUE;

    /** symtab.e:140			new[S_NREFS] = 0*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:141			new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 35LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _13TRUE_452;
    DeRef(_1);

    /** symtab.e:142			new[S_RI_TARGET] = 0*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 53LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);

    /** symtab.e:144			new[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21263);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MININT_21263;
    DeRef(_1);

    /** symtab.e:145			new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _24318 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24318 = - _36NOVALUE_21293;
        }
    }
    else {
        _24318 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 41LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24318;
    if( _1 != _24318 ){
        DeRef(_1);
    }
    _24318 = NOVALUE;

    /** symtab.e:147			new[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21262);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21262;
    DeRef(_1);

    /** symtab.e:148			new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_36NOVALUE_21293)) {
        if ((uintptr_t)_36NOVALUE_21293 == (uintptr_t)HIGH_BITS){
            _24319 = (object)NewDouble((eudouble) -HIGH_BITS);
        }
        else{
            _24319 = - _36NOVALUE_21293;
        }
    }
    else {
        _24319 = unary_op(UMINUS, _36NOVALUE_21293);
    }
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 42LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24319;
    if( _1 != _24319 ){
        DeRef(_1);
    }
    _24319 = NOVALUE;
L3: 

    /** symtab.e:151		new[S_TOKEN] = token*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TOKEN_21081))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _token_46860;
    DeRef(_1);

    /** symtab.e:152		new[S_VARNUM] = varnum*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 16LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _varnum_46858;
    DeRef(_1);

    /** symtab.e:153		new[S_INITLEVEL] = -1*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 14LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = -1LL;
    DeRef(_1);

    /** symtab.e:154		new[S_VTYPE] = type_sym*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 15LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _type_sym_46865;
    DeRef(_1);

    /** symtab.e:156		new[S_HASHVAL] = hashval*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 11LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _hashval_46861;
    DeRef(_1);

    /** symtab.e:157		new[S_SAMEHASH] = samehash*/
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _samehash_46863;
    DeRef(_1);

    /** symtab.e:159		new[S_OBJ] = NOVALUE -- important*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_new_46866);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_46866 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** symtab.e:162		SymTab = append(SymTab, new)*/
    RefDS(_new_46866);
    Append(&_37SymTab_15406, _37SymTab_15406, _new_46866);

    /** symtab.e:164		return length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _24321 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _24321 = 1;
    }
    DeRefDS(_name_46857);
    DeRefDS(_new_46866);
    return _24321;
    ;
}


object _54NewEntry(object _name_46945, object _varnum_46946, object _scope_46947, object _token_46948, object _hashval_46949, object _samehash_46951, object _type_sym_46953)
{
    object _new_46955 = NOVALUE;
    object _24323 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_scope_46947)) {
        _1 = (object)(DBL_PTR(_scope_46947)->dbl);
        DeRefDS(_scope_46947);
        _scope_46947 = _1;
    }
    if (!IS_ATOM_INT(_token_46948)) {
        _1 = (object)(DBL_PTR(_token_46948)->dbl);
        DeRefDS(_token_46948);
        _token_46948 = _1;
    }
    if (!IS_ATOM_INT(_samehash_46951)) {
        _1 = (object)(DBL_PTR(_samehash_46951)->dbl);
        DeRefDS(_samehash_46951);
        _samehash_46951 = _1;
    }

    /** symtab.e:171		symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_46945);
    _new_46955 = _54NewBasicEntry(_name_46945, _varnum_46946, _scope_46947, _token_46948, _hashval_46949, _samehash_46951, _type_sym_46953);
    if (!IS_ATOM_INT(_new_46955)) {
        _1 = (object)(DBL_PTR(_new_46955)->dbl);
        DeRefDS(_new_46955);
        _new_46955 = _1;
    }

    /** symtab.e:174		if last_sym then*/
    if (_54last_sym_46785 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** symtab.e:175			SymTab[last_sym][S_NEXT] = new*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_54last_sym_46785 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _new_46955;
    DeRef(_1);
    _24323 = NOVALUE;
L1: 

    /** symtab.e:177		last_sym = new*/
    _54last_sym_46785 = _new_46955;

    /** symtab.e:178		if type_sym < 0 then*/
    if (_type_sym_46953 >= 0LL)
    goto L2; // [63] 76

    /** symtab.e:179			register_forward_type( last_sym, type_sym )*/
    _44register_forward_type(_54last_sym_46785, _type_sym_46953);
L2: 

    /** symtab.e:181		return last_sym*/
    DeRefDS(_name_46945);
    return _54last_sym_46785;
    ;
}


object _54tmp_alloc()
{
    object _new_entry_46970 = NOVALUE;
    object _24337 = NOVALUE;
    object _24335 = NOVALUE;
    object _24332 = NOVALUE;
    object _24329 = NOVALUE;
    object _24328 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:188		sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_46970);
    _new_entry_46970 = Repeat(0LL, _36SIZEOF_TEMP_ENTRY_21211);

    /** symtab.e:192		new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    *(intptr_t *)_2 = 4LL;

    /** symtab.e:194		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** symtab.e:195			new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    *(intptr_t *)_2 = 16LL;

    /** symtab.e:196			new_entry[S_OBJ_MIN] = MININT*/
    Ref(_36MININT_21263);
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    *(intptr_t *)_2 = _36MININT_21263;

    /** symtab.e:197			new_entry[S_OBJ_MAX] = MAXINT*/
    Ref(_36MAXINT_21262);
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36MAXINT_21262;
    DeRef(_1);

    /** symtab.e:198			new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);

    /** symtab.e:199			new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);

    /** symtab.e:200			if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_36temp_name_type_21525)){
            _24328 = SEQ_PTR(_36temp_name_type_21525)->length;
    }
    else {
        _24328 = 1;
    }
    _24329 = _24328 + 1;
    _24328 = NOVALUE;
    if (_24329 != 8087LL)
    goto L2; // [87] 106

    /** symtab.e:202				temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 0LL;
    ((intptr_t *)_2)[2] = 0LL;
    _24332 = MAKE_SEQ(_1);
    RefDS(_24332);
    Append(&_36temp_name_type_21525, _36temp_name_type_21525, _24332);
    DeRefDS(_24332);
    _24332 = NOVALUE;
L2: 

    /** symtab.e:204			temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_55TYPES_OBNL_46617);
    Append(&_36temp_name_type_21525, _36temp_name_type_21525, _55TYPES_OBNL_46617);

    /** symtab.e:205			new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_36temp_name_type_21525)){
            _24335 = SEQ_PTR(_36temp_name_type_21525)->length;
    }
    else {
        _24335 = 1;
    }
    _2 = (object)SEQ_PTR(_new_entry_46970);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _new_entry_46970 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24335;
    if( _1 != _24335 ){
        DeRef(_1);
    }
    _24335 = NOVALUE;
L1: 

    /** symtab.e:208		SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_46970);
    Append(&_37SymTab_15406, _37SymTab_15406, _new_entry_46970);

    /** symtab.e:210		return length( SymTab )*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _24337 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _24337 = 1;
    }
    DeRefDS(_new_entry_46970);
    DeRef(_24329);
    _24329 = NOVALUE;
    return _24337;
    ;
}


void _54DefinedYet(object _sym_47039)
{
    object _24357 = NOVALUE;
    object _24356 = NOVALUE;
    object _24355 = NOVALUE;
    object _24353 = NOVALUE;
    object _24352 = NOVALUE;
    object _24350 = NOVALUE;
    object _24349 = NOVALUE;
    object _24348 = NOVALUE;
    object _24347 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:230		if not find(SymTab[sym][S_SCOPE],*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24347 = (object)*(((s1_ptr)_2)->base + _sym_47039);
    _2 = (object)SEQ_PTR(_24347);
    _24348 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24347 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 9LL;
    ((intptr_t*)_2)[2] = 10LL;
    ((intptr_t*)_2)[3] = 7LL;
    _24349 = MAKE_SEQ(_1);
    _24350 = find_from(_24348, _24349, 1LL);
    _24348 = NOVALUE;
    DeRefDS(_24349);
    _24349 = NOVALUE;
    if (_24350 != 0)
    goto L1; // [34] 84
    _24350 = NOVALUE;

    /** symtab.e:232			if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24352 = (object)*(((s1_ptr)_2)->base + _sym_47039);
    _2 = (object)SEQ_PTR(_24352);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _24353 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _24353 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _24352 = NOVALUE;
    if (binary_op_a(NOTEQ, _24353, _36current_file_no_21439)){
        _24353 = NOVALUE;
        goto L2; // [53] 83
    }
    _24353 = NOVALUE;

    /** symtab.e:233				CompileErr(ATTEMPT_TO_REDEFINE_1, {SymTab[sym][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24355 = (object)*(((s1_ptr)_2)->base + _sym_47039);
    _2 = (object)SEQ_PTR(_24355);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _24356 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _24356 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _24355 = NOVALUE;
    _1 = NewS1(1);
    _2 = (object)((s1_ptr)_1)->base;
    Ref(_24356);
    ((intptr_t*)_2)[1] = _24356;
    _24357 = MAKE_SEQ(_1);
    _24356 = NOVALUE;
    _50CompileErr(31LL, _24357, 0LL);
    _24357 = NOVALUE;
L2: 
L1: 

    /** symtab.e:236	end procedure*/
    return;
    ;
}


object _54name_ext(object _s_47067)
{
    object _24364 = NOVALUE;
    object _24363 = NOVALUE;
    object _24362 = NOVALUE;
    object _24361 = NOVALUE;
    object _24359 = NOVALUE;
    object _24358 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:241		for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_47067)){
            _24358 = SEQ_PTR(_s_47067)->length;
    }
    else {
        _24358 = 1;
    }
    {
        object _i_47069;
        _i_47069 = _24358;
L1: 
        if (_i_47069 < 1LL){
            goto L2; // [8] 55
        }

        /** symtab.e:242			if find(s[i], "/\\:") then*/
        _2 = (object)SEQ_PTR(_s_47067);
        _24359 = (object)*(((s1_ptr)_2)->base + _i_47069);
        _24361 = find_from(_24359, _24360, 1LL);
        _24359 = NOVALUE;
        if (_24361 == 0)
        {
            _24361 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24361 = NOVALUE;
        }

        /** symtab.e:243				return s[i+1 .. $]*/
        _24362 = _i_47069 + 1;
        if (IS_SEQUENCE(_s_47067)){
                _24363 = SEQ_PTR(_s_47067)->length;
        }
        else {
            _24363 = 1;
        }
        rhs_slice_target = (object_ptr)&_24364;
        RHS_Slice(_s_47067, _24362, _24363);
        DeRefDS(_s_47067);
        _24362 = NOVALUE;
        return _24364;
L3: 

        /** symtab.e:245		end for*/
        _i_47069 = _i_47069 + -1LL;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** symtab.e:247		return s*/
    DeRef(_24362);
    _24362 = NOVALUE;
    DeRef(_24364);
    _24364 = NOVALUE;
    return _s_47067;
    ;
}


object _54NewStringSym(object _s_47086)
{
    object _p_47088 = NOVALUE;
    object _tp_47089 = NOVALUE;
    object _prev_47090 = NOVALUE;
    object _search_count_47091 = NOVALUE;
    object _24408 = NOVALUE;
    object _24406 = NOVALUE;
    object _24405 = NOVALUE;
    object _24404 = NOVALUE;
    object _24402 = NOVALUE;
    object _24401 = NOVALUE;
    object _24398 = NOVALUE;
    object _24396 = NOVALUE;
    object _24394 = NOVALUE;
    object _24393 = NOVALUE;
    object _24392 = NOVALUE;
    object _24390 = NOVALUE;
    object _24388 = NOVALUE;
    object _24386 = NOVALUE;
    object _24384 = NOVALUE;
    object _24381 = NOVALUE;
    object _24379 = NOVALUE;
    object _24378 = NOVALUE;
    object _24377 = NOVALUE;
    object _24375 = NOVALUE;
    object _24373 = NOVALUE;
    object _24372 = NOVALUE;
    object _24371 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:255		integer search_count*/

    /** symtab.e:258		tp = literal_init*/
    _tp_47089 = _54literal_init_46784;

    /** symtab.e:259		prev = 0*/
    _prev_47090 = 0LL;

    /** symtab.e:260		search_count = 0*/
    _search_count_47091 = 0LL;

    /** symtab.e:261		while tp != 0 do*/
L1: 
    if (_tp_47089 == 0LL)
    goto L2; // [31] 170

    /** symtab.e:262			search_count += 1*/
    _search_count_47091 = _search_count_47091 + 1;

    /** symtab.e:263			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47091, _54SEARCH_LIMIT_47078)){
        goto L3; // [45] 54
    }

    /** symtab.e:264				exit*/
    goto L2; // [51] 170
L3: 

    /** symtab.e:266			if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24371 = (object)*(((s1_ptr)_2)->base + _tp_47089);
    _2 = (object)SEQ_PTR(_24371);
    _24372 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24371 = NOVALUE;
    if (_s_47086 == _24372)
    _24373 = 1;
    else if (IS_ATOM_INT(_s_47086) && IS_ATOM_INT(_24372))
    _24373 = 0;
    else
    _24373 = (compare(_s_47086, _24372) == 0);
    _24372 = NOVALUE;
    if (_24373 == 0)
    {
        _24373 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24373 = NOVALUE;
    }

    /** symtab.e:268				if tp != literal_init then*/
    if (_tp_47089 == _54literal_init_46784)
    goto L5; // [79] 135

    /** symtab.e:269					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47090 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24377 = (object)*(((s1_ptr)_2)->base + _tp_47089);
    _2 = (object)SEQ_PTR(_24377);
    _24378 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24377 = NOVALUE;
    Ref(_24378);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24378;
    if( _1 != _24378 ){
        DeRef(_1);
    }
    _24378 = NOVALUE;
    _24375 = NOVALUE;

    /** symtab.e:270					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47089 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46784;
    DeRef(_1);
    _24379 = NOVALUE;

    /** symtab.e:271					literal_init = tp*/
    _54literal_init_46784 = _tp_47089;
L5: 

    /** symtab.e:273				return tp*/
    DeRefDS(_s_47086);
    return _tp_47089;
L4: 

    /** symtab.e:275			prev = tp*/
    _prev_47090 = _tp_47089;

    /** symtab.e:276			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24381 = (object)*(((s1_ptr)_2)->base + _tp_47089);
    _2 = (object)SEQ_PTR(_24381);
    _tp_47089 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47089)){
        _tp_47089 = (object)DBL_PTR(_tp_47089)->dbl;
    }
    _24381 = NOVALUE;

    /** symtab.e:277		end while*/
    goto L1; // [167] 31
L2: 

    /** symtab.e:279		p = tmp_alloc()*/
    _p_47088 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47088)) {
        _1 = (object)(DBL_PTR(_p_47088)->dbl);
        DeRefDS(_p_47088);
        _p_47088 = _1;
    }

    /** symtab.e:280		SymTab[p][S_OBJ] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    RefDS(_s_47086);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_47086;
    DeRef(_1);
    _24384 = NOVALUE;

    /** symtab.e:282		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** symtab.e:283			SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24386 = NOVALUE;

    /** symtab.e:284			SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 8LL;
    DeRef(_1);
    _24388 = NOVALUE;

    /** symtab.e:285			SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_47086)){
            _24392 = SEQ_PTR(_s_47086)->length;
    }
    else {
        _24392 = 1;
    }
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 32LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24392;
    if( _1 != _24392 ){
        DeRef(_1);
    }
    _24392 = NOVALUE;
    _24390 = NOVALUE;

    /** symtab.e:286			if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24393 = (object)*(((s1_ptr)_2)->base + _p_47088);
    _2 = (object)SEQ_PTR(_24393);
    _24394 = (object)*(((s1_ptr)_2)->base + 32LL);
    _24393 = NOVALUE;
    if (binary_op_a(LESSEQ, _24394, 0LL)){
        _24394 = NOVALUE;
        goto L7; // [265] 289
    }
    _24394 = NOVALUE;

    /** symtab.e:287				SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24396 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** symtab.e:289				SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _24398 = NOVALUE;
L8: 

    /** symtab.e:291			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24401 = (object)*(((s1_ptr)_2)->base + _p_47088);
    _2 = (object)SEQ_PTR(_24401);
    _24402 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24401 = NOVALUE;
    RefDS(_24400);
    Ref(_24402);
    _55c_printf(_24400, _24402);
    _24402 = NOVALUE;

    /** symtab.e:292			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24404 = (object)*(((s1_ptr)_2)->base + _p_47088);
    _2 = (object)SEQ_PTR(_24404);
    _24405 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24404 = NOVALUE;
    RefDS(_24403);
    Ref(_24405);
    _55c_hprintf(_24403, _24405);
    _24405 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** symtab.e:295			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24406 = NOVALUE;
L9: 

    /** symtab.e:299		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47088 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46784;
    DeRef(_1);
    _24408 = NOVALUE;

    /** symtab.e:300		literal_init = p*/
    _54literal_init_46784 = _p_47088;

    /** symtab.e:301		return p*/
    DeRefDS(_s_47086);
    return _p_47088;
    ;
}


object _54NewIntSym(object _int_val_47184)
{
    object _p_47186 = NOVALUE;
    object _x_47187 = NOVALUE;
    object _24432 = NOVALUE;
    object _24430 = NOVALUE;
    object _24426 = NOVALUE;
    object _24424 = NOVALUE;
    object _24422 = NOVALUE;
    object _24420 = NOVALUE;
    object _24418 = NOVALUE;
    object _24416 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:308		integer x*/

    /** symtab.e:310		x = find(int_val, lastintval)*/
    _x_47187 = find_from(_int_val_47184, _54lastintval_46786, 1LL);

    /** symtab.e:311		if x then*/
    if (_x_47187 == 0)
    {
        goto L1; // [14] 75
    }
    else{
    }

    /** symtab.e:312			if repl then*/

    /** symtab.e:317			return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (object)SEQ_PTR(_54lastintsym_46787);
    _24416 = (object)*(((s1_ptr)_2)->base + _x_47187);
    DeRef(_int_val_47184);
    return _24416;
    goto L2; // [72] 225
L1: 

    /** symtab.e:320			label "lolol"*/
G3:

    /** symtab.e:321			p = tmp_alloc()*/
    _p_47186 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47186)) {
        _1 = (object)(DBL_PTR(_p_47186)->dbl);
        DeRefDS(_p_47186);
        _p_47186 = _1;
    }

    /** symtab.e:322			SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47186 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24418 = NOVALUE;

    /** symtab.e:323			SymTab[p][S_OBJ] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47186 + ((s1_ptr)_2)->base);
    Ref(_int_val_47184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47184;
    DeRef(_1);
    _24420 = NOVALUE;

    /** symtab.e:325			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L4; // [122] 173
    }
    else{
    }

    /** symtab.e:326				SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47186 + ((s1_ptr)_2)->base);
    Ref(_int_val_47184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 30LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47184;
    DeRef(_1);
    _24422 = NOVALUE;

    /** symtab.e:327				SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47186 + ((s1_ptr)_2)->base);
    Ref(_int_val_47184);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 31LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _int_val_47184;
    DeRef(_1);
    _24424 = NOVALUE;

    /** symtab.e:328				SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47186 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24426 = NOVALUE;
L4: 

    /** symtab.e:331			lastintval = prepend(lastintval, int_val)*/
    Ref(_int_val_47184);
    Prepend(&_54lastintval_46786, _54lastintval_46786, _int_val_47184);

    /** symtab.e:332			lastintsym = prepend(lastintsym, p)*/
    Prepend(&_54lastintsym_46787, _54lastintsym_46787, _p_47186);

    /** symtab.e:333			if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_54lastintval_46786)){
            _24430 = SEQ_PTR(_54lastintval_46786)->length;
    }
    else {
        _24430 = 1;
    }
    if (binary_op_a(LESSEQ, _24430, _54SEARCH_LIMIT_47078)){
        _24430 = NOVALUE;
        goto L5; // [198] 218
    }
    _24430 = NOVALUE;

    /** symtab.e:334				lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_54SEARCH_LIMIT_47078)) {
        _24432 = _54SEARCH_LIMIT_47078 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _54SEARCH_LIMIT_47078, 2);
        _24432 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_54lastintval_46786;
    RHS_Slice(_54lastintval_46786, 1LL, _24432);
L5: 

    /** symtab.e:336			return p*/
    DeRef(_int_val_47184);
    DeRef(_24432);
    _24432 = NOVALUE;
    _24416 = NOVALUE;
    return _p_47186;
L2: 
    ;
}


object _54NewDoubleSym(object _d_47236)
{
    object _p_47238 = NOVALUE;
    object _tp_47239 = NOVALUE;
    object _prev_47240 = NOVALUE;
    object _search_count_47241 = NOVALUE;
    object _24462 = NOVALUE;
    object _24461 = NOVALUE;
    object _24460 = NOVALUE;
    object _24459 = NOVALUE;
    object _24458 = NOVALUE;
    object _24456 = NOVALUE;
    object _24454 = NOVALUE;
    object _24452 = NOVALUE;
    object _24450 = NOVALUE;
    object _24447 = NOVALUE;
    object _24445 = NOVALUE;
    object _24444 = NOVALUE;
    object _24443 = NOVALUE;
    object _24441 = NOVALUE;
    object _24439 = NOVALUE;
    object _24438 = NOVALUE;
    object _24437 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:343		integer search_count*/

    /** symtab.e:346		tp = literal_init*/
    _tp_47239 = _54literal_init_46784;

    /** symtab.e:347		prev = 0*/
    _prev_47240 = 0LL;

    /** symtab.e:348		search_count = 0*/
    _search_count_47241 = 0LL;

    /** symtab.e:349		while tp != 0 do*/
L1: 
    if (_tp_47239 == 0LL)
    goto L2; // [29] 168

    /** symtab.e:350			search_count += 1*/
    _search_count_47241 = _search_count_47241 + 1;

    /** symtab.e:351			if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_47241, _54SEARCH_LIMIT_47078)){
        goto L3; // [43] 52
    }

    /** symtab.e:352				exit*/
    goto L2; // [49] 168
L3: 

    /** symtab.e:354			if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24437 = (object)*(((s1_ptr)_2)->base + _tp_47239);
    _2 = (object)SEQ_PTR(_24437);
    _24438 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24437 = NOVALUE;
    if (_d_47236 == _24438)
    _24439 = 1;
    else if (IS_ATOM_INT(_d_47236) && IS_ATOM_INT(_24438))
    _24439 = 0;
    else
    _24439 = (compare(_d_47236, _24438) == 0);
    _24438 = NOVALUE;
    if (_24439 == 0)
    {
        _24439 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24439 = NOVALUE;
    }

    /** symtab.e:356				if tp != literal_init then*/
    if (_tp_47239 == _54literal_init_46784)
    goto L5; // [77] 133

    /** symtab.e:358					SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_47240 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24443 = (object)*(((s1_ptr)_2)->base + _tp_47239);
    _2 = (object)SEQ_PTR(_24443);
    _24444 = (object)*(((s1_ptr)_2)->base + 2LL);
    _24443 = NOVALUE;
    Ref(_24444);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24444;
    if( _1 != _24444 ){
        DeRef(_1);
    }
    _24444 = NOVALUE;
    _24441 = NOVALUE;

    /** symtab.e:359					SymTab[tp][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_tp_47239 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46784;
    DeRef(_1);
    _24445 = NOVALUE;

    /** symtab.e:360					literal_init = tp*/
    _54literal_init_46784 = _tp_47239;
L5: 

    /** symtab.e:362				return tp*/
    DeRef(_d_47236);
    return _tp_47239;
L4: 

    /** symtab.e:364			prev = tp*/
    _prev_47240 = _tp_47239;

    /** symtab.e:365			tp = SymTab[tp][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24447 = (object)*(((s1_ptr)_2)->base + _tp_47239);
    _2 = (object)SEQ_PTR(_24447);
    _tp_47239 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_tp_47239)){
        _tp_47239 = (object)DBL_PTR(_tp_47239)->dbl;
    }
    _24447 = NOVALUE;

    /** symtab.e:366		end while*/
    goto L1; // [165] 29
L2: 

    /** symtab.e:368		p = tmp_alloc()*/
    _p_47238 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47238)) {
        _1 = (object)(DBL_PTR(_p_47238)->dbl);
        DeRefDS(_p_47238);
        _p_47238 = _1;
    }

    /** symtab.e:369		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47238 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24450 = NOVALUE;

    /** symtab.e:370		SymTab[p][S_OBJ] = d*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47238 + ((s1_ptr)_2)->base);
    Ref(_d_47236);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _d_47236;
    DeRef(_1);
    _24452 = NOVALUE;

    /** symtab.e:372		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** symtab.e:373			SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47238 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24454 = NOVALUE;

    /** symtab.e:374			SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47238 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24456 = NOVALUE;

    /** symtab.e:375			c_printf("object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24458 = (object)*(((s1_ptr)_2)->base + _p_47238);
    _2 = (object)SEQ_PTR(_24458);
    _24459 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24458 = NOVALUE;
    RefDS(_24400);
    Ref(_24459);
    _55c_printf(_24400, _24459);
    _24459 = NOVALUE;

    /** symtab.e:376			c_hprintf("extern object _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24460 = (object)*(((s1_ptr)_2)->base + _p_47238);
    _2 = (object)SEQ_PTR(_24460);
    _24461 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24460 = NOVALUE;
    RefDS(_24403);
    Ref(_24461);
    _55c_hprintf(_24403, _24461);
    _24461 = NOVALUE;
L6: 

    /** symtab.e:379		SymTab[p][S_NEXT] = literal_init*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47238 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _54literal_init_46784;
    DeRef(_1);
    _24462 = NOVALUE;

    /** symtab.e:380		literal_init = p*/
    _54literal_init_46784 = _p_47238;

    /** symtab.e:381		return p*/
    DeRef(_d_47236);
    return _p_47238;
    ;
}


object _54NewTempSym(object _inlining_47310)
{
    object _p_47312 = NOVALUE;
    object _q_47313 = NOVALUE;
    object _24511 = NOVALUE;
    object _24509 = NOVALUE;
    object _24507 = NOVALUE;
    object _24505 = NOVALUE;
    object _24503 = NOVALUE;
    object _24501 = NOVALUE;
    object _24500 = NOVALUE;
    object _24499 = NOVALUE;
    object _24497 = NOVALUE;
    object _24496 = NOVALUE;
    object _24495 = NOVALUE;
    object _24493 = NOVALUE;
    object _24491 = NOVALUE;
    object _24488 = NOVALUE;
    object _24487 = NOVALUE;
    object _24486 = NOVALUE;
    object _24484 = NOVALUE;
    object _24482 = NOVALUE;
    object _24481 = NOVALUE;
    object _24480 = NOVALUE;
    object _24478 = NOVALUE;
    object _24476 = NOVALUE;
    object _24471 = NOVALUE;
    object _24470 = NOVALUE;
    object _24469 = NOVALUE;
    object _24468 = NOVALUE;
    object _24467 = NOVALUE;
    object _24466 = NOVALUE;
    object _24464 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:392		if inlining then*/
    if (_inlining_47310 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** symtab.e:393			p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24464 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_24464);
    if (!IS_ATOM_INT(_36S_TEMPS_21121)){
        _p_47312 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    }
    else{
        _p_47312 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    }
    if (!IS_ATOM_INT(_p_47312)){
        _p_47312 = (object)DBL_PTR(_p_47312)->dbl;
    }
    _24464 = NOVALUE;

    /** symtab.e:394			while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24466 = (_p_47312 != 0LL);
    if (_24466 == 0) {
        goto L3; // [35] 93
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24468 = (object)*(((s1_ptr)_2)->base + _p_47312);
    _2 = (object)SEQ_PTR(_24468);
    _24469 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24468 = NOVALUE;
    if (IS_ATOM_INT(_24469)) {
        _24470 = (_24469 != 0LL);
    }
    else {
        _24470 = binary_op(NOTEQ, _24469, 0LL);
    }
    _24469 = NOVALUE;
    if (_24470 <= 0) {
        if (_24470 == 0) {
            DeRef(_24470);
            _24470 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24470) && DBL_PTR(_24470)->dbl == 0.0){
                DeRef(_24470);
                _24470 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24470);
            _24470 = NOVALUE;
        }
    }
    DeRef(_24470);
    _24470 = NOVALUE;

    /** symtab.e:395				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24471 = (object)*(((s1_ptr)_2)->base + _p_47312);
    _2 = (object)SEQ_PTR(_24471);
    _p_47312 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47312)){
        _p_47312 = (object)DBL_PTR(_p_47312)->dbl;
    }
    _24471 = NOVALUE;

    /** symtab.e:396			end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** symtab.e:398			p = 0*/
    _p_47312 = 0LL;
L3: 

    /** symtab.e:401		if p = 0 then*/
    if (_p_47312 != 0LL)
    goto L4; // [97] 213

    /** symtab.e:403			temps_allocated += 1*/
    _54temps_allocated_47307 = _54temps_allocated_47307 + 1;

    /** symtab.e:404			p = tmp_alloc()*/
    _p_47312 = _54tmp_alloc();
    if (!IS_ATOM_INT(_p_47312)) {
        _1 = (object)(DBL_PTR(_p_47312)->dbl);
        DeRefDS(_p_47312);
        _p_47312 = _1;
    }

    /** symtab.e:405			SymTab[p][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24476 = NOVALUE;

    /** symtab.e:406			SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24480 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_24480);
    if (!IS_ATOM_INT(_36S_TEMPS_21121)){
        _24481 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    }
    else{
        _24481 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    }
    _24480 = NOVALUE;
    Ref(_24481);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24481;
    if( _1 != _24481 ){
        DeRef(_1);
    }
    _24481 = NOVALUE;
    _24478 = NOVALUE;

    /** symtab.e:407			SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21121))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_47312;
    DeRef(_1);
    _24482 = NOVALUE;

    /** symtab.e:409			if inlining then*/
    if (_inlining_47310 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** symtab.e:410				SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136)){
        _24486 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    }
    else{
        _24486 = (object)*(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    }
    _24484 = NOVALUE;
    if (IS_ATOM_INT(_24486)) {
        _24487 = _24486 + 1;
        if (_24487 > MAXINT){
            _24487 = NewDouble((eudouble)_24487);
        }
    }
    else
    _24487 = binary_op(PLUS, 1, _24486);
    _24486 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_STACK_SPACE_21136))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_STACK_SPACE_21136)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_STACK_SPACE_21136);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24487;
    if( _1 != _24487 ){
        DeRef(_1);
    }
    _24487 = NOVALUE;
    _24484 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** symtab.e:413		elsif TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** symtab.e:418			SymTab[p][S_SCOPE] = DELETED*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 2LL;
    DeRef(_1);
    _24488 = NOVALUE;

    /** symtab.e:420			q = tmp_alloc()*/
    _q_47313 = _54tmp_alloc();
    if (!IS_ATOM_INT(_q_47313)) {
        _1 = (object)(DBL_PTR(_q_47313)->dbl);
        DeRefDS(_q_47313);
        _q_47313 = _1;
    }

    /** symtab.e:421			SymTab[q][S_MODE] = M_TEMP*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47313 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 3LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 3LL;
    DeRef(_1);
    _24491 = NOVALUE;

    /** symtab.e:422			SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47313 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24495 = (object)*(((s1_ptr)_2)->base + _p_47312);
    _2 = (object)SEQ_PTR(_24495);
    _24496 = (object)*(((s1_ptr)_2)->base + 34LL);
    _24495 = NOVALUE;
    Ref(_24496);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 34LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24496;
    if( _1 != _24496 ){
        DeRef(_1);
    }
    _24496 = NOVALUE;
    _24493 = NOVALUE;

    /** symtab.e:423			SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_q_47313 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24499 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_24499);
    if (!IS_ATOM_INT(_36S_TEMPS_21121)){
        _24500 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    }
    else{
        _24500 = (object)*(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    }
    _24499 = NOVALUE;
    Ref(_24500);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 2LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24500;
    if( _1 != _24500 ){
        DeRef(_1);
    }
    _24500 = NOVALUE;
    _24497 = NOVALUE;

    /** symtab.e:424			SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_TEMPS_21121))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TEMPS_21121)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_TEMPS_21121);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _q_47313;
    DeRef(_1);
    _24501 = NOVALUE;

    /** symtab.e:425			p = q*/
    _p_47312 = _q_47313;
L6: 
L5: 

    /** symtab.e:428		if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** symtab.e:429			SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 36LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24503 = NOVALUE;

    /** symtab.e:430			SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 33LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 16LL;
    DeRef(_1);
    _24505 = NOVALUE;
L7: 

    /** symtab.e:433		SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    Ref(_36NOVALUE_21293);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 1LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _36NOVALUE_21293;
    DeRef(_1);
    _24507 = NOVALUE;

    /** symtab.e:434		SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 5LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 4LL;
    DeRef(_1);
    _24509 = NOVALUE;

    /** symtab.e:435		SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47312 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 4LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 1LL;
    DeRef(_1);
    _24511 = NOVALUE;

    /** symtab.e:437		return p*/
    DeRef(_24466);
    _24466 = NOVALUE;
    return _p_47312;
    ;
}


void _54InitSymTab()
{
    object _hashval_47429 = NOVALUE;
    object _len_47430 = NOVALUE;
    object _s_47432 = NOVALUE;
    object _st_index_47433 = NOVALUE;
    object _kname_47434 = NOVALUE;
    object _fixups_47435 = NOVALUE;
    object _si_47574 = NOVALUE;
    object _sj_47575 = NOVALUE;
    object _25097 = NOVALUE;
    object _25096 = NOVALUE;
    object _24626 = NOVALUE;
    object _24625 = NOVALUE;
    object _24624 = NOVALUE;
    object _24623 = NOVALUE;
    object _24622 = NOVALUE;
    object _24620 = NOVALUE;
    object _24619 = NOVALUE;
    object _24618 = NOVALUE;
    object _24617 = NOVALUE;
    object _24615 = NOVALUE;
    object _24613 = NOVALUE;
    object _24611 = NOVALUE;
    object _24610 = NOVALUE;
    object _24608 = NOVALUE;
    object _24606 = NOVALUE;
    object _24604 = NOVALUE;
    object _24603 = NOVALUE;
    object _24601 = NOVALUE;
    object _24600 = NOVALUE;
    object _24599 = NOVALUE;
    object _24598 = NOVALUE;
    object _24597 = NOVALUE;
    object _24594 = NOVALUE;
    object _24593 = NOVALUE;
    object _24592 = NOVALUE;
    object _24590 = NOVALUE;
    object _24589 = NOVALUE;
    object _24588 = NOVALUE;
    object _24586 = NOVALUE;
    object _24585 = NOVALUE;
    object _24584 = NOVALUE;
    object _24581 = NOVALUE;
    object _24579 = NOVALUE;
    object _24577 = NOVALUE;
    object _24576 = NOVALUE;
    object _24573 = NOVALUE;
    object _24572 = NOVALUE;
    object _24570 = NOVALUE;
    object _24568 = NOVALUE;
    object _24566 = NOVALUE;
    object _24564 = NOVALUE;
    object _24563 = NOVALUE;
    object _24562 = NOVALUE;
    object _24559 = NOVALUE;
    object _24558 = NOVALUE;
    object _24556 = NOVALUE;
    object _24555 = NOVALUE;
    object _24553 = NOVALUE;
    object _24552 = NOVALUE;
    object _24551 = NOVALUE;
    object _24549 = NOVALUE;
    object _24547 = NOVALUE;
    object _24546 = NOVALUE;
    object _24544 = NOVALUE;
    object _24543 = NOVALUE;
    object _24542 = NOVALUE;
    object _24540 = NOVALUE;
    object _24539 = NOVALUE;
    object _24538 = NOVALUE;
    object _24536 = NOVALUE;
    object _24535 = NOVALUE;
    object _24534 = NOVALUE;
    object _24532 = NOVALUE;
    object _24531 = NOVALUE;
    object _24530 = NOVALUE;
    object _24529 = NOVALUE;
    object _24528 = NOVALUE;
    object _24527 = NOVALUE;
    object _24526 = NOVALUE;
    object _24525 = NOVALUE;
    object _24524 = NOVALUE;
    object _24523 = NOVALUE;
    object _24521 = NOVALUE;
    object _24520 = NOVALUE;
    object _24519 = NOVALUE;
    object _24518 = NOVALUE;
    object _24514 = NOVALUE;
    object _24513 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:445		sequence kname, fixups = {}*/
    RefDS(_21993);
    DeRefi(_fixups_47435);
    _fixups_47435 = _21993;

    /** symtab.e:447		for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23115)){
            _24513 = SEQ_PTR(_63keylist_23115)->length;
    }
    else {
        _24513 = 1;
    }
    {
        object _k_47437;
        _k_47437 = 1LL;
L1: 
        if (_k_47437 > _24513){
            goto L2; // [15] 560
        }

        /** symtab.e:448			kname = keylist[k][K_NAME]*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24514 = (object)*(((s1_ptr)_2)->base + _k_47437);
        DeRef(_kname_47434);
        _2 = (object)SEQ_PTR(_24514);
        _kname_47434 = (object)*(((s1_ptr)_2)->base + 1LL);
        Ref(_kname_47434);
        _24514 = NOVALUE;

        /** symtab.e:449			len = length(kname)*/
        if (IS_SEQUENCE(_kname_47434)){
                _len_47430 = SEQ_PTR(_kname_47434)->length;
        }
        else {
            _len_47430 = 1;
        }

        /** symtab.e:450			hashval = hashfn(kname)*/
        RefDS(_kname_47434);
        _hashval_47429 = _54hashfn(_kname_47434);
        if (!IS_ATOM_INT(_hashval_47429)) {
            _1 = (object)(DBL_PTR(_hashval_47429)->dbl);
            DeRefDS(_hashval_47429);
            _hashval_47429 = _1;
        }

        /** symtab.e:451			st_index = NewEntry(kname,*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24518 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24518);
        _24519 = (object)*(((s1_ptr)_2)->base + 2LL);
        _24518 = NOVALUE;
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24520 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24520);
        _24521 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24520 = NOVALUE;
        RefDS(_kname_47434);
        Ref(_24519);
        Ref(_24521);
        _st_index_47433 = _54NewEntry(_kname_47434, 0LL, _24519, _24521, _hashval_47429, 0LL, 0LL);
        _24519 = NOVALUE;
        _24521 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_47433)) {
            _1 = (object)(DBL_PTR(_st_index_47433)->dbl);
            DeRefDS(_st_index_47433);
            _st_index_47433 = _1;
        }

        /** symtab.e:456			if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24523 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24523);
        _24524 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24523 = NOVALUE;
        _24525 = find_from(_24524, _38RTN_TOKS_16045, 1LL);
        _24524 = NOVALUE;
        if (_24525 == 0)
        {
            _24525 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24525 = NOVALUE;
        }

        /** symtab.e:457				SymTab[st_index] = SymTab[st_index] &*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24526 = (object)*(((s1_ptr)_2)->base + _st_index_47433);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24527 = (object)*(((s1_ptr)_2)->base + _st_index_47433);
        if (IS_SEQUENCE(_24527)){
                _24528 = SEQ_PTR(_24527)->length;
        }
        else {
            _24528 = 1;
        }
        _24527 = NOVALUE;
        _24529 = _36SIZEOF_ROUTINE_ENTRY_21202 - _24528;
        _24528 = NOVALUE;
        _24530 = Repeat(0LL, _24529);
        _24529 = NOVALUE;
        if (IS_SEQUENCE(_24526) && IS_ATOM(_24530)) {
        }
        else if (IS_ATOM(_24526) && IS_SEQUENCE(_24530)) {
            Ref(_24526);
            Prepend(&_24531, _24530, _24526);
        }
        else {
            Concat((object_ptr)&_24531, _24526, _24530);
            _24526 = NOVALUE;
        }
        _24526 = NOVALUE;
        DeRefDS(_24530);
        _24530 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _st_index_47433);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24531;
        if( _1 != _24531 ){
            DeRef(_1);
        }
        _24531 = NOVALUE;

        /** symtab.e:460				SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24534 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24534);
        _24535 = (object)*(((s1_ptr)_2)->base + 5LL);
        _24534 = NOVALUE;
        Ref(_24535);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21127))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24535;
        if( _1 != _24535 ){
            DeRef(_1);
        }
        _24535 = NOVALUE;
        _24532 = NOVALUE;

        /** symtab.e:461				SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24538 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24538);
        _24539 = (object)*(((s1_ptr)_2)->base + 4LL);
        _24538 = NOVALUE;
        Ref(_24539);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 21LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24539;
        if( _1 != _24539 ){
            DeRef(_1);
        }
        _24539 = NOVALUE;
        _24536 = NOVALUE;

        /** symtab.e:462				SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24542 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24542);
        _24543 = (object)*(((s1_ptr)_2)->base + 6LL);
        _24542 = NOVALUE;
        Ref(_24543);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 23LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24543;
        if( _1 != _24543 ){
            DeRef(_1);
        }
        _24543 = NOVALUE;
        _24540 = NOVALUE;

        /** symtab.e:463				SymTab[st_index][S_REFLIST] = {}*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        RefDS(_21993);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 24LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _21993;
        DeRef(_1);
        _24544 = NOVALUE;

        /** symtab.e:464				if length(keylist[k]) > K_EFFECT then*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24546 = (object)*(((s1_ptr)_2)->base + _k_47437);
        if (IS_SEQUENCE(_24546)){
                _24547 = SEQ_PTR(_24546)->length;
        }
        else {
            _24547 = 1;
        }
        _24546 = NOVALUE;
        if (_24547 <= 6LL)
        goto L4; // [259] 324

        /** symtab.e:465				    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24551 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24551);
        _24552 = (object)*(((s1_ptr)_2)->base + 7LL);
        _24551 = NOVALUE;
        Ref(_24552);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21088))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24552;
        if( _1 != _24552 ){
            DeRef(_1);
        }
        _24552 = NOVALUE;
        _24549 = NOVALUE;

        /** symtab.e:466				    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24555 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24555);
        _24556 = (object)*(((s1_ptr)_2)->base + 8LL);
        _24555 = NOVALUE;
        Ref(_24556);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 28LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24556;
        if( _1 != _24556 ){
            DeRef(_1);
        }
        _24556 = NOVALUE;
        _24553 = NOVALUE;

        /** symtab.e:467				    fixups &= st_index*/
        Append(&_fixups_47435, _fixups_47435, _st_index_47433);
L4: 
L3: 

        /** symtab.e:470			if keylist[k][K_TOKEN] = PROC then*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24558 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24558);
        _24559 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24558 = NOVALUE;
        if (binary_op_a(NOTEQ, _24559, 27LL)){
            _24559 = NOVALUE;
            goto L5; // [341] 365
        }
        _24559 = NOVALUE;

        /** symtab.e:471				if equal(kname, "<TopLevel>") then*/
        if (_kname_47434 == _24561)
        _24562 = 1;
        else if (IS_ATOM_INT(_kname_47434) && IS_ATOM_INT(_24561))
        _24562 = 0;
        else
        _24562 = (compare(_kname_47434, _24561) == 0);
        if (_24562 == 0)
        {
            _24562 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24562 = NOVALUE;
        }

        /** symtab.e:472					TopLevelSub = st_index*/
        _36TopLevelSub_21446 = _st_index_47433;
        goto L6; // [362] 462
L5: 

        /** symtab.e:474			elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _24563 = (object)*(((s1_ptr)_2)->base + _k_47437);
        _2 = (object)SEQ_PTR(_24563);
        _24564 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24563 = NOVALUE;
        if (binary_op_a(NOTEQ, _24564, 504LL)){
            _24564 = NOVALUE;
            goto L7; // [381] 461
        }
        _24564 = NOVALUE;

        /** symtab.e:475				if equal(kname, "object") then*/
        if (_kname_47434 == _22955)
        _24566 = 1;
        else if (IS_ATOM_INT(_kname_47434) && IS_ATOM_INT(_22955))
        _24566 = 0;
        else
        _24566 = (compare(_kname_47434, _22955) == 0);
        if (_24566 == 0)
        {
            _24566 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24566 = NOVALUE;
        }

        /** symtab.e:476					object_type = st_index*/
        _54object_type_46776 = _st_index_47433;
        goto L9; // [401] 460
L8: 

        /** symtab.e:477				elsif equal(kname, "atom") then*/
        if (_kname_47434 == _24567)
        _24568 = 1;
        else if (IS_ATOM_INT(_kname_47434) && IS_ATOM_INT(_24567))
        _24568 = 0;
        else
        _24568 = (compare(_kname_47434, _24567) == 0);
        if (_24568 == 0)
        {
            _24568 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24568 = NOVALUE;
        }

        /** symtab.e:478					atom_type = st_index*/
        _54atom_type_46778 = _st_index_47433;
        goto L9; // [420] 460
LA: 

        /** symtab.e:479				elsif equal(kname, "integer") then*/
        if (_kname_47434 == _24569)
        _24570 = 1;
        else if (IS_ATOM_INT(_kname_47434) && IS_ATOM_INT(_24569))
        _24570 = 0;
        else
        _24570 = (compare(_kname_47434, _24569) == 0);
        if (_24570 == 0)
        {
            _24570 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24570 = NOVALUE;
        }

        /** symtab.e:480					integer_type = st_index*/
        _54integer_type_46782 = _st_index_47433;
        goto L9; // [439] 460
LB: 

        /** symtab.e:481				elsif equal(kname, "sequence") then*/
        if (_kname_47434 == _24571)
        _24572 = 1;
        else if (IS_ATOM_INT(_kname_47434) && IS_ATOM_INT(_24571))
        _24572 = 0;
        else
        _24572 = (compare(_kname_47434, _24571) == 0);
        if (_24572 == 0)
        {
            _24572 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24572 = NOVALUE;
        }

        /** symtab.e:482					sequence_type = st_index*/
        _54sequence_type_46780 = _st_index_47433;
LC: 
L9: 
L7: 
L6: 

        /** symtab.e:485			if buckets[hashval] = 0 then*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _24573 = (object)*(((s1_ptr)_2)->base + _hashval_47429);
        if (binary_op_a(NOTEQ, _24573, 0LL)){
            _24573 = NOVALUE;
            goto LD; // [470] 485
        }
        _24573 = NOVALUE;

        /** symtab.e:486				buckets[hashval] = st_index*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _2 = (object)(((s1_ptr)_2)->base + _hashval_47429);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47433;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** symtab.e:488				s = buckets[hashval]*/
        _2 = (object)SEQ_PTR(_54buckets_46772);
        _s_47432 = (object)*(((s1_ptr)_2)->base + _hashval_47429);
        if (!IS_ATOM_INT(_s_47432)){
            _s_47432 = (object)DBL_PTR(_s_47432)->dbl;
        }

        /** symtab.e:489				while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24576 = (object)*(((s1_ptr)_2)->base + _s_47432);
        _2 = (object)SEQ_PTR(_24576);
        _24577 = (object)*(((s1_ptr)_2)->base + 9LL);
        _24576 = NOVALUE;
        if (binary_op_a(EQUALS, _24577, 0LL)){
            _24577 = NOVALUE;
            goto L10; // [512] 537
        }
        _24577 = NOVALUE;

        /** symtab.e:490					s = SymTab[s][S_SAMEHASH]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24579 = (object)*(((s1_ptr)_2)->base + _s_47432);
        _2 = (object)SEQ_PTR(_24579);
        _s_47432 = (object)*(((s1_ptr)_2)->base + 9LL);
        if (!IS_ATOM_INT(_s_47432)){
            _s_47432 = (object)DBL_PTR(_s_47432)->dbl;
        }
        _24579 = NOVALUE;

        /** symtab.e:491				end while*/
        goto LF; // [534] 500
L10: 

        /** symtab.e:492				SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_s_47432 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + 9LL);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _st_index_47433;
        DeRef(_1);
        _24581 = NOVALUE;
LE: 

        /** symtab.e:494		end for*/
        _k_47437 = _k_47437 + 1LL;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** symtab.e:495		file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_37SymTab_15406)){
            _36file_start_sym_21445 = SEQ_PTR(_37SymTab_15406)->length;
    }
    else {
        _36file_start_sym_21445 = 1;
    }

    /** symtab.e:497		sequence si, sj*/

    /** symtab.e:498		CurrentSub = TopLevelSub*/
    _36CurrentSub_21447 = _36TopLevelSub_21446;

    /** symtab.e:499		for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_47435)){
            _24584 = SEQ_PTR(_fixups_47435)->length;
    }
    else {
        _24584 = 1;
    }
    {
        object _i_47579;
        _i_47579 = 1LL;
L11: 
        if (_i_47579 > _24584){
            goto L12; // [585] 946
        }

        /** symtab.e:500		    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (object)SEQ_PTR(_fixups_47435);
        _24585 = (object)*(((s1_ptr)_2)->base + _i_47579);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24586 = (object)*(((s1_ptr)_2)->base + _24585);
        DeRef(_si_47574);
        _2 = (object)SEQ_PTR(_24586);
        if (!IS_ATOM_INT(_36S_CODE_21088)){
            _si_47574 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        }
        else{
            _si_47574 = (object)*(((s1_ptr)_2)->base + _36S_CODE_21088);
        }
        Ref(_si_47574);
        _24586 = NOVALUE;

        /** symtab.e:501		    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_47574)){
                _24588 = SEQ_PTR(_si_47574)->length;
        }
        else {
            _24588 = 1;
        }
        {
            object _j_47587;
            _j_47587 = 1LL;
L13: 
            if (_j_47587 > _24588){
                goto L14; // [617] 920
            }

            /** symtab.e:502		        if sequence(si[j]) then*/
            _2 = (object)SEQ_PTR(_si_47574);
            _24589 = (object)*(((s1_ptr)_2)->base + _j_47587);
            _24590 = IS_SEQUENCE(_24589);
            _24589 = NOVALUE;
            if (_24590 == 0)
            {
                _24590 = NOVALUE;
                goto L15; // [633] 913
            }
            else{
                _24590 = NOVALUE;
            }

            /** symtab.e:503		            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_47575);
            _2 = (object)SEQ_PTR(_si_47574);
            _sj_47575 = (object)*(((s1_ptr)_2)->base + _j_47587);
            Ref(_sj_47575);

            /** symtab.e:504					for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_47575)){
                    _24592 = SEQ_PTR(_sj_47575)->length;
            }
            else {
                _24592 = 1;
            }
            {
                object _ij_47594;
                _ij_47594 = 1LL;
L16: 
                if (_ij_47594 > _24592){
                    goto L17; // [649] 906
                }

                /** symtab.e:505		                switch sj[ij][T_ID] with fallthru do*/
                _2 = (object)SEQ_PTR(_sj_47575);
                _24593 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                _2 = (object)SEQ_PTR(_24593);
                _24594 = (object)*(((s1_ptr)_2)->base + 1LL);
                _24593 = NOVALUE;
                if (IS_SEQUENCE(_24594) ){
                    goto L18; // [668] 899
                }
                if(!IS_ATOM_INT(_24594)){
                    if( (DBL_PTR(_24594)->dbl != (eudouble) ((object) DBL_PTR(_24594)->dbl) ) ){
                        goto L18; // [668] 899
                    }
                    _0 = (object) DBL_PTR(_24594)->dbl;
                }
                else {
                    _0 = _24594;
                };
                _24594 = NOVALUE;
                switch ( _0 ){ 

                    /** symtab.e:506		                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** symtab.e:507		                    	if is_integer(sj[ij][T_SYM]) then*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    _24597 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                    _2 = (object)SEQ_PTR(_24597);
                    _24598 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24597 = NOVALUE;
                    Ref(_24598);
                    _24599 = _36is_integer(_24598);
                    _24598 = NOVALUE;
                    if (_24599 == 0) {
                        DeRef(_24599);
                        _24599 = NOVALUE;
                        goto L19; // [693] 717
                    }
                    else {
                        if (!IS_ATOM_INT(_24599) && DBL_PTR(_24599)->dbl == 0.0){
                            DeRef(_24599);
                            _24599 = NOVALUE;
                            goto L19; // [693] 717
                        }
                        DeRef(_24599);
                        _24599 = NOVALUE;
                    }
                    DeRef(_24599);
                    _24599 = NOVALUE;

                    /** symtab.e:508									st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    _24600 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                    _2 = (object)SEQ_PTR(_24600);
                    _24601 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24600 = NOVALUE;
                    Ref(_24601);
                    _st_index_47433 = _54NewIntSym(_24601);
                    _24601 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47433)) {
                        _1 = (object)(DBL_PTR(_st_index_47433)->dbl);
                        DeRefDS(_st_index_47433);
                        _st_index_47433 = _1;
                    }
                    goto L1A; // [714] 736
L19: 

                    /** symtab.e:510									st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    _24603 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                    _2 = (object)SEQ_PTR(_24603);
                    _24604 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24603 = NOVALUE;
                    Ref(_24604);
                    _st_index_47433 = _54NewDoubleSym(_24604);
                    _24604 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47433)) {
                        _1 = (object)(DBL_PTR(_st_index_47433)->dbl);
                        DeRefDS(_st_index_47433);
                        _st_index_47433 = _1;
                    }
L1A: 

                    /** symtab.e:512								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15406);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15406 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24606 = NOVALUE;

                    /** symtab.e:513								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47575 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47594 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47433;
                    DeRef(_1);
                    _24608 = NOVALUE;

                    /** symtab.e:514								break*/
                    goto L18; // [770] 899

                    /** symtab.e:515							case STRING then -- same*/
                    case 503:

                    /** symtab.e:516		                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    _24610 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                    _2 = (object)SEQ_PTR(_24610);
                    _24611 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24610 = NOVALUE;
                    Ref(_24611);
                    _st_index_47433 = _54NewStringSym(_24611);
                    _24611 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_47433)) {
                        _1 = (object)(DBL_PTR(_st_index_47433)->dbl);
                        DeRefDS(_st_index_47433);
                        _st_index_47433 = _1;
                    }

                    /** symtab.e:517								SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (object)SEQ_PTR(_37SymTab_15406);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _37SymTab_15406 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_st_index_47433 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 4LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = 1LL;
                    DeRef(_1);
                    _24613 = NOVALUE;

                    /** symtab.e:518								sj[ij][T_SYM] = st_index*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47575 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47594 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _st_index_47433;
                    DeRef(_1);
                    _24615 = NOVALUE;

                    /** symtab.e:519								break*/
                    goto L18; // [826] 899

                    /** symtab.e:520							case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /** symtab.e:521	                            sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    _24617 = (object)*(((s1_ptr)_2)->base + _ij_47594);
                    _2 = (object)SEQ_PTR(_24617);
                    _24618 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24617 = NOVALUE;
                    Ref(_24618);
                    DeRef(_25096);
                    _25096 = _24618;
                    _25097 = _54hashfn(_25096);
                    _25096 = NOVALUE;
                    Ref(_24618);
                    _24619 = _54keyfind(_24618, -1LL, _36current_file_no_21439, 0LL, _25097);
                    _24618 = NOVALUE;
                    _25097 = NOVALUE;
                    _2 = (object)SEQ_PTR(_sj_47575);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47575 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + _ij_47594);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24619;
                    if( _1 != _24619 ){
                        DeRef(_1);
                    }
                    _24619 = NOVALUE;

                    /** symtab.e:522								break*/
                    goto L18; // [867] 899

                    /** symtab.e:523							case DEF_PARAM then*/
                    case 510:

                    /** symtab.e:524								sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (object)SEQ_PTR(_sj_47575);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        _sj_47575 = MAKE_SEQ(_2);
                    }
                    _3 = (object)(_ij_47594 + ((s1_ptr)_2)->base);
                    _2 = (object)SEQ_PTR(_fixups_47435);
                    _24622 = (object)*(((s1_ptr)_2)->base + _i_47579);
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    _24623 = (object)*(((s1_ptr)_2)->base + 2LL);
                    _24620 = NOVALUE;
                    if (IS_SEQUENCE(_24623) && IS_ATOM(_24622)) {
                        Append(&_24624, _24623, _24622);
                    }
                    else if (IS_ATOM(_24623) && IS_SEQUENCE(_24622)) {
                    }
                    else {
                        Concat((object_ptr)&_24624, _24623, _24622);
                        _24623 = NOVALUE;
                    }
                    _24623 = NOVALUE;
                    _24622 = NOVALUE;
                    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (object)SequenceCopy((s1_ptr)_2);
                        *(intptr_t *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (object)(((s1_ptr)_2)->base + 2LL);
                    _1 = *(intptr_t *)_2;
                    *(intptr_t *)_2 = _24624;
                    if( _1 != _24624 ){
                        DeRef(_1);
                    }
                    _24624 = NOVALUE;
                    _24620 = NOVALUE;
                ;}L18: 

                /** symtab.e:526					end for*/
                _ij_47594 = _ij_47594 + 1LL;
                goto L16; // [901] 656
L17: 
                ;
            }

            /** symtab.e:527					si[j] = sj*/
            RefDS(_sj_47575);
            _2 = (object)SEQ_PTR(_si_47574);
            if (!UNIQUE(_2)) {
                _2 = (object)SequenceCopy((s1_ptr)_2);
                _si_47574 = MAKE_SEQ(_2);
            }
            _2 = (object)(((s1_ptr)_2)->base + _j_47587);
            _1 = *(intptr_t *)_2;
            *(intptr_t *)_2 = _sj_47575;
            DeRef(_1);
L15: 

            /** symtab.e:529			end for*/
            _j_47587 = _j_47587 + 1LL;
            goto L13; // [915] 624
L14: 
            ;
        }

        /** symtab.e:530			SymTab[fixups[i]][S_CODE] = si*/
        _2 = (object)SEQ_PTR(_fixups_47435);
        _24625 = (object)*(((s1_ptr)_2)->base + _i_47579);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_24625 + ((s1_ptr)_2)->base);
        RefDS(_si_47574);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_36S_CODE_21088))
        _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_CODE_21088)->dbl));
        else
        _2 = (object)(((s1_ptr)_2)->base + _36S_CODE_21088);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _si_47574;
        DeRef(_1);
        _24626 = NOVALUE;

        /** symtab.e:531		end for*/
        _i_47579 = _i_47579 + 1LL;
        goto L11; // [941] 592
L12: 
        ;
    }

    /** symtab.e:532	end procedure*/
    DeRef(_kname_47434);
    DeRefi(_fixups_47435);
    DeRef(_si_47574);
    DeRef(_sj_47575);
    _24585 = NOVALUE;
    _24546 = NOVALUE;
    _24527 = NOVALUE;
    _24625 = NOVALUE;
    return;
    ;
}


void _54add_ref(object _tok_47663)
{
    object _s_47665 = NOVALUE;
    object _24642 = NOVALUE;
    object _24641 = NOVALUE;
    object _24639 = NOVALUE;
    object _24638 = NOVALUE;
    object _24637 = NOVALUE;
    object _24635 = NOVALUE;
    object _24634 = NOVALUE;
    object _24633 = NOVALUE;
    object _24632 = NOVALUE;
    object _24631 = NOVALUE;
    object _24630 = NOVALUE;
    object _24629 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:538		s = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47663);
    _s_47665 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_47665)){
        _s_47665 = (object)DBL_PTR(_s_47665)->dbl;
    }

    /** symtab.e:539		if s != CurrentSub and -- ignore self-ref's*/
    _24629 = (_s_47665 != _36CurrentSub_21447);
    if (_24629 == 0) {
        goto L1; // [19] 98
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24631 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_24631);
    _24632 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24631 = NOVALUE;
    _24633 = find_from(_s_47665, _24632, 1LL);
    _24632 = NOVALUE;
    _24634 = (_24633 == 0);
    _24633 = NOVALUE;
    if (_24634 == 0)
    {
        DeRef(_24634);
        _24634 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24634);
        _24634 = NOVALUE;
    }

    /** symtab.e:542			SymTab[s][S_NREFS] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_47665 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24637 = (object)*(((s1_ptr)_2)->base + 12LL);
    _24635 = NOVALUE;
    if (IS_ATOM_INT(_24637)) {
        _24638 = _24637 + 1;
        if (_24638 > MAXINT){
            _24638 = NewDouble((eudouble)_24638);
        }
    }
    else
    _24638 = binary_op(PLUS, 1, _24637);
    _24637 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 12LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24638;
    if( _1 != _24638 ){
        DeRef(_1);
    }
    _24638 = NOVALUE;
    _24635 = NOVALUE;

    /** symtab.e:543			SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_36CurrentSub_21447 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24641 = (object)*(((s1_ptr)_2)->base + 24LL);
    _24639 = NOVALUE;
    if (IS_SEQUENCE(_24641) && IS_ATOM(_s_47665)) {
        Append(&_24642, _24641, _s_47665);
    }
    else if (IS_ATOM(_24641) && IS_SEQUENCE(_s_47665)) {
    }
    else {
        Concat((object_ptr)&_24642, _24641, _s_47665);
        _24641 = NOVALUE;
    }
    _24641 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 24LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24642;
    if( _1 != _24642 ){
        DeRef(_1);
    }
    _24642 = NOVALUE;
    _24639 = NOVALUE;
L1: 

    /** symtab.e:545	end procedure*/
    DeRef(_tok_47663);
    DeRef(_24629);
    _24629 = NOVALUE;
    return;
    ;
}


void _54mark_all(object _attribute_47695)
{
    object _p_47698 = NOVALUE;
    object _sym_file_47705 = NOVALUE;
    object _scope_47722 = NOVALUE;
    object _24674 = NOVALUE;
    object _24673 = NOVALUE;
    object _24672 = NOVALUE;
    object _24670 = NOVALUE;
    object _24668 = NOVALUE;
    object _24667 = NOVALUE;
    object _24666 = NOVALUE;
    object _24665 = NOVALUE;
    object _24664 = NOVALUE;
    object _24662 = NOVALUE;
    object _24661 = NOVALUE;
    object _24660 = NOVALUE;
    object _24659 = NOVALUE;
    object _24655 = NOVALUE;
    object _24654 = NOVALUE;
    object _24653 = NOVALUE;
    object _24651 = NOVALUE;
    object _24650 = NOVALUE;
    object _24648 = NOVALUE;
    object _24646 = NOVALUE;
    object _24643 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:550		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_47692 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** symtab.e:551			symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24643 = (object)*(((s1_ptr)_2)->base + _54just_mark_everything_from_47692);
    _2 = (object)SEQ_PTR(_24643);
    _p_47698 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47698)){
        _p_47698 = (object)DBL_PTR(_p_47698)->dbl;
    }
    _24643 = NOVALUE;

    /** symtab.e:552			while p != 0 do*/
L2: 
    if (_p_47698 == 0LL)
    goto L3; // [33] 269

    /** symtab.e:553				integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24646 = (object)*(((s1_ptr)_2)->base + _p_47698);
    _2 = (object)SEQ_PTR(_24646);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _sym_file_47705 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _sym_file_47705 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_sym_file_47705)){
        _sym_file_47705 = (object)DBL_PTR(_sym_file_47705)->dbl;
    }
    _24646 = NOVALUE;

    /** symtab.e:554				just_mark_everything_from = p*/
    _54just_mark_everything_from_47692 = _p_47698;

    /** symtab.e:555				if sym_file = current_file_no or map:has( recheck_routines, sym_file ) then*/
    _24648 = (_sym_file_47705 == _36current_file_no_21439);
    if (_24648 != 0) {
        goto L4; // [68] 84
    }
    Ref(_54recheck_routines_47765);
    _24650 = _29has(_54recheck_routines_47765, _sym_file_47705);
    if (_24650 == 0) {
        DeRef(_24650);
        _24650 = NOVALUE;
        goto L5; // [80] 108
    }
    else {
        if (!IS_ATOM_INT(_24650) && DBL_PTR(_24650)->dbl == 0.0){
            DeRef(_24650);
            _24650 = NOVALUE;
            goto L5; // [80] 108
        }
        DeRef(_24650);
        _24650 = NOVALUE;
    }
    DeRef(_24650);
    _24650 = NOVALUE;
L4: 

    /** symtab.e:556					SymTab[p][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_p_47698 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24653 = (object)*(((s1_ptr)_2)->base + _attribute_47695);
    _24651 = NOVALUE;
    if (IS_ATOM_INT(_24653)) {
        _24654 = _24653 + 1;
        if (_24654 > MAXINT){
            _24654 = NewDouble((eudouble)_24654);
        }
    }
    else
    _24654 = binary_op(PLUS, 1, _24653);
    _24653 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47695);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24654;
    if( _1 != _24654 ){
        DeRef(_1);
    }
    _24654 = NOVALUE;
    _24651 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** symtab.e:558					integer scope = SymTab[p][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24655 = (object)*(((s1_ptr)_2)->base + _p_47698);
    _2 = (object)SEQ_PTR(_24655);
    _scope_47722 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_47722)){
        _scope_47722 = (object)DBL_PTR(_scope_47722)->dbl;
    }
    _24655 = NOVALUE;

    /** symtab.e:559					switch scope with fallthru do*/
    _0 = _scope_47722;
    switch ( _0 ){ 

        /** symtab.e:560						case SC_PUBLIC then*/
        case 13:

        /** symtab.e:561							if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24659 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
        _2 = (object)SEQ_PTR(_24659);
        _24660 = (object)*(((s1_ptr)_2)->base + _sym_file_47705);
        _24659 = NOVALUE;
        if (IS_ATOM_INT(_24660)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24660;
                 _24661 = MAKE_UINT(tu);
            }
        }
        else {
            _24661 = binary_op(AND_BITS, 6LL, _24660);
        }
        _24660 = NOVALUE;
        if (_24661 == 0) {
            DeRef(_24661);
            _24661 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24661) && DBL_PTR(_24661)->dbl == 0.0){
                DeRef(_24661);
                _24661 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24661);
            _24661 = NOVALUE;
        }
        DeRef(_24661);
        _24661 = NOVALUE;

        /** symtab.e:562								SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47698 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24664 = (object)*(((s1_ptr)_2)->base + _attribute_47695);
        _24662 = NOVALUE;
        if (IS_ATOM_INT(_24664)) {
            _24665 = _24664 + 1;
            if (_24665 > MAXINT){
                _24665 = NewDouble((eudouble)_24665);
            }
        }
        else
        _24665 = binary_op(PLUS, 1, _24664);
        _24664 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47695);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24665;
        if( _1 != _24665 ){
            DeRef(_1);
        }
        _24665 = NOVALUE;
        _24662 = NOVALUE;

        /** symtab.e:564							break*/
        goto L7; // [182] 243

        /** symtab.e:565						case SC_EXPORT then*/
        case 11:

        /** symtab.e:566							if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24666 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
        _2 = (object)SEQ_PTR(_24666);
        _24667 = (object)*(((s1_ptr)_2)->base + _sym_file_47705);
        _24666 = NOVALUE;
        if (IS_ATOM_INT(_24667)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24667;
                 _24668 = MAKE_UINT(tu);
            }
        }
        else {
            _24668 = binary_op(AND_BITS, 2LL, _24667);
        }
        _24667 = NOVALUE;
        if (IS_ATOM_INT(_24668)) {
            if (_24668 != 0){
                DeRef(_24668);
                _24668 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24668)->dbl != 0.0){
                DeRef(_24668);
                _24668 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24668);
        _24668 = NOVALUE;

        /** symtab.e:567								break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** symtab.e:570						case SC_GLOBAL then*/
        case 6:

        /** symtab.e:571							SymTab[p][attribute] += 1*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            _37SymTab_15406 = MAKE_SEQ(_2);
        }
        _3 = (object)(_p_47698 + ((s1_ptr)_2)->base);
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        _24672 = (object)*(((s1_ptr)_2)->base + _attribute_47695);
        _24670 = NOVALUE;
        if (IS_ATOM_INT(_24672)) {
            _24673 = _24672 + 1;
            if (_24673 > MAXINT){
                _24673 = NewDouble((eudouble)_24673);
            }
        }
        else
        _24673 = binary_op(PLUS, 1, _24672);
        _24672 = NOVALUE;
        _2 = (object)SEQ_PTR(*(intptr_t *)_3);
        if (!UNIQUE(_2)) {
            _2 = (object)SequenceCopy((s1_ptr)_2);
            *(intptr_t *)_3 = MAKE_SEQ(_2);
        }
        _2 = (object)(((s1_ptr)_2)->base + _attribute_47695);
        _1 = *(intptr_t *)_2;
        *(intptr_t *)_2 = _24673;
        if( _1 != _24673 ){
            DeRef(_1);
        }
        _24673 = NOVALUE;
        _24670 = NOVALUE;
    ;}L7: 
L6: 

    /** symtab.e:575				p = SymTab[p][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24674 = (object)*(((s1_ptr)_2)->base + _p_47698);
    _2 = (object)SEQ_PTR(_24674);
    _p_47698 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_p_47698)){
        _p_47698 = (object)DBL_PTR(_p_47698)->dbl;
    }
    _24674 = NOVALUE;

    /** symtab.e:576			end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** symtab.e:578	end procedure*/
    DeRef(_24648);
    _24648 = NOVALUE;
    return;
    ;
}


void _54mark_rechecks(object _file_no_47771)
{
    object _recheck_targets_47774 = NOVALUE;
    object _remaining_47778 = NOVALUE;
    object _marked_47782 = NOVALUE;
    object _24681 = NOVALUE;
    object _24679 = NOVALUE;
    object _24678 = NOVALUE;
    object _24677 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_no_47771)) {
        _1 = (object)(DBL_PTR(_file_no_47771)->dbl);
        DeRefDS(_file_no_47771);
        _file_no_47771 = _1;
    }

    /** symtab.e:584		sequence recheck_targets = map:get( recheck_routines, file_no, {} )*/
    Ref(_54recheck_routines_47765);
    RefDS(_21993);
    _0 = _recheck_targets_47774;
    _recheck_targets_47774 = _29get(_54recheck_routines_47765, _file_no_47771, _21993);
    DeRef(_0);

    /** symtab.e:585		if length( recheck_targets ) then*/
    if (IS_SEQUENCE(_recheck_targets_47774)){
            _24677 = SEQ_PTR(_recheck_targets_47774)->length;
    }
    else {
        _24677 = 1;
    }
    if (_24677 == 0)
    {
        _24677 = NOVALUE;
        goto L1; // [20] 129
    }
    else{
        _24677 = NOVALUE;
    }

    /** symtab.e:586			sequence remaining = {}*/
    RefDS(_21993);
    DeRefi(_remaining_47778);
    _remaining_47778 = _21993;

    /** symtab.e:587			for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_recheck_targets_47774)){
            _24678 = SEQ_PTR(_recheck_targets_47774)->length;
    }
    else {
        _24678 = 1;
    }
    {
        object _i_47780;
        _i_47780 = _24678;
L2: 
        if (_i_47780 < 1LL){
            goto L3; // [35] 117
        }

        /** symtab.e:588				integer marked = 0*/
        _marked_47782 = 0LL;

        /** symtab.e:589				if TRANSLATE then*/
        if (_36TRANSLATE_21041 == 0)
        {
            goto L4; // [51] 72
        }
        else{
        }

        /** symtab.e:590					marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47774);
        _24679 = (object)*(((s1_ptr)_2)->base + _i_47780);
        Ref(_24679);
        _marked_47782 = _54MarkTargets(_24679, 53LL);
        _24679 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47782)) {
            _1 = (object)(DBL_PTR(_marked_47782)->dbl);
            DeRefDS(_marked_47782);
            _marked_47782 = _1;
        }
        goto L5; // [69] 96
L4: 

        /** symtab.e:591				elsif BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto L6; // [76] 95
        }
        else{
        }

        /** symtab.e:592					marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (object)SEQ_PTR(_recheck_targets_47774);
        _24681 = (object)*(((s1_ptr)_2)->base + _i_47780);
        Ref(_24681);
        _marked_47782 = _54MarkTargets(_24681, 12LL);
        _24681 = NOVALUE;
        if (!IS_ATOM_INT(_marked_47782)) {
            _1 = (object)(DBL_PTR(_marked_47782)->dbl);
            DeRefDS(_marked_47782);
            _marked_47782 = _1;
        }
L6: 
L5: 

        /** symtab.e:594				if not marked then*/
        if (_marked_47782 != 0)
        goto L7; // [98] 108

        /** symtab.e:595					remaining &= file_no*/
        Append(&_remaining_47778, _remaining_47778, _file_no_47771);
L7: 

        /** symtab.e:597			end for*/
        _i_47780 = _i_47780 + -1LL;
        goto L2; // [112] 42
L3: 
        ;
    }

    /** symtab.e:598			map:put( recheck_routines, file_no, recheck_targets )*/
    Ref(_54recheck_routines_47765);
    RefDS(_recheck_targets_47774);
    _29put(_54recheck_routines_47765, _file_no_47771, _recheck_targets_47774, 1LL, 0LL);
L1: 
    DeRefi(_remaining_47778);
    _remaining_47778 = NOVALUE;

    /** symtab.e:600	end procedure*/
    DeRef(_recheck_targets_47774);
    return;
    ;
}


void _54mark_final_targets()
{
    object _size_1__tmp_at47_47810 = NOVALUE;
    object _size_inlined_size_at_47_47809 = NOVALUE;
    object _recheck_files_47811 = NOVALUE;
    object _24687 = NOVALUE;
    object _24686 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:603		if just_mark_everything_from then*/
    if (_54just_mark_everything_from_47692 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** symtab.e:604			if TRANSLATE then*/
    if (_36TRANSLATE_21041 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** symtab.e:605				mark_all( S_RI_TARGET )*/
    _54mark_all(53LL);
    goto L3; // [22] 109
L2: 

    /** symtab.e:606			elsif BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L3; // [29] 109
    }
    else{
    }

    /** symtab.e:607				mark_all( S_NREFS )*/
    _54mark_all(12LL);
    goto L3; // [41] 109
L1: 

    /** symtab.e:609		elsif map:size( recheck_routines ) then*/

    /** map.e:800		return eumem:ram_space[the_map_p][MAP_SIZE]*/
    DeRef(_size_1__tmp_at47_47810);
    _2 = (object)SEQ_PTR(_30ram_space_11238);
    if (!IS_ATOM_INT(_54recheck_routines_47765)){
        _size_1__tmp_at47_47810 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_54recheck_routines_47765)->dbl));
    }
    else{
        _size_1__tmp_at47_47810 = (object)*(((s1_ptr)_2)->base + _54recheck_routines_47765);
    }
    Ref(_size_1__tmp_at47_47810);
    DeRef(_size_inlined_size_at_47_47809);
    _2 = (object)SEQ_PTR(_size_1__tmp_at47_47810);
    _size_inlined_size_at_47_47809 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_size_inlined_size_at_47_47809);
    DeRef(_size_1__tmp_at47_47810);
    _size_1__tmp_at47_47810 = NOVALUE;
    if (_size_inlined_size_at_47_47809 == 0) {
        goto L4; // [63] 106
    }
    else {
        if (!IS_ATOM_INT(_size_inlined_size_at_47_47809) && DBL_PTR(_size_inlined_size_at_47_47809)->dbl == 0.0){
            goto L4; // [63] 106
        }
    }

    /** symtab.e:610			sequence recheck_files = map:keys( recheck_routines )*/
    Ref(_54recheck_routines_47765);
    _0 = _recheck_files_47811;
    _recheck_files_47811 = _29keys(_54recheck_routines_47765, 0LL);
    DeRef(_0);

    /** symtab.e:611			for i = 1 to length( recheck_files ) do*/
    if (IS_SEQUENCE(_recheck_files_47811)){
            _24686 = SEQ_PTR(_recheck_files_47811)->length;
    }
    else {
        _24686 = 1;
    }
    {
        object _i_47814;
        _i_47814 = 1LL;
L5: 
        if (_i_47814 > _24686){
            goto L6; // [82] 105
        }

        /** symtab.e:612				mark_rechecks( recheck_files[i] )*/
        _2 = (object)SEQ_PTR(_recheck_files_47811);
        _24687 = (object)*(((s1_ptr)_2)->base + _i_47814);
        Ref(_24687);
        _54mark_rechecks(_24687);
        _24687 = NOVALUE;

        /** symtab.e:613			end for*/
        _i_47814 = _i_47814 + 1LL;
        goto L5; // [100] 89
L6: 
        ;
    }
L4: 
    DeRef(_recheck_files_47811);
    _recheck_files_47811 = NOVALUE;
L3: 

    /** symtab.e:615	end procedure*/
    return;
    ;
}


object _54is_routine(object _sym_47820)
{
    object _tok_47821 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:618		integer tok = sym_token( sym )*/
    _tok_47821 = _54sym_token(_sym_47820);
    if (!IS_ATOM_INT(_tok_47821)) {
        _1 = (object)(DBL_PTR(_tok_47821)->dbl);
        DeRefDS(_tok_47821);
        _tok_47821 = _1;
    }

    /** symtab.e:619		switch tok do*/
    _0 = _tok_47821;
    switch ( _0 ){ 

        /** symtab.e:620			case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** symtab.e:621				return 1*/
        return 1LL;
        goto L1; // [32] 45

        /** symtab.e:622			case else*/
        default:

        /** symtab.e:623				return 0*/
        return 0LL;
    ;}L1: 
    ;
}


object _54is_visible(object _sym_47834, object _from_file_47835)
{
    object _scope_47836 = NOVALUE;
    object _sym_file_47839 = NOVALUE;
    object _visible_mask_47844 = NOVALUE;
    object _24699 = NOVALUE;
    object _24698 = NOVALUE;
    object _24697 = NOVALUE;
    object _24696 = NOVALUE;
    object _24692 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:628		integer scope = sym_scope( sym )*/
    _scope_47836 = _54sym_scope(_sym_47834);
    if (!IS_ATOM_INT(_scope_47836)) {
        _1 = (object)(DBL_PTR(_scope_47836)->dbl);
        DeRefDS(_scope_47836);
        _scope_47836 = _1;
    }

    /** symtab.e:629		integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24692 = (object)*(((s1_ptr)_2)->base + _sym_47834);
    _2 = (object)SEQ_PTR(_24692);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _sym_file_47839 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _sym_file_47839 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_sym_file_47839)){
        _sym_file_47839 = (object)DBL_PTR(_sym_file_47839)->dbl;
    }
    _24692 = NOVALUE;

    /** symtab.e:631		switch scope do*/
    _0 = _scope_47836;
    switch ( _0 ){ 

        /** symtab.e:632			case SC_PUBLIC then*/
        case 13:

        /** symtab.e:633				visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_47844 = 6LL;
        goto L1; // [49] 93

        /** symtab.e:634			case SC_EXPORT then*/
        case 11:

        /** symtab.e:635				visible_mask = DIRECT_INCLUDE*/
        _visible_mask_47844 = 2LL;
        goto L1; // [64] 93

        /** symtab.e:636			case SC_GLOBAL then*/
        case 6:

        /** symtab.e:637				return 1*/
        return 1LL;
        goto L1; // [76] 93

        /** symtab.e:638			case else*/
        default:

        /** symtab.e:639				return from_file = sym_file*/
        _24696 = (_from_file_47835 == _sym_file_47839);
        return _24696;
    ;}L1: 

    /** symtab.e:641		return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24697 = (object)*(((s1_ptr)_2)->base + _from_file_47835);
    _2 = (object)SEQ_PTR(_24697);
    _24698 = (object)*(((s1_ptr)_2)->base + _sym_file_47839);
    _24697 = NOVALUE;
    if (IS_ATOM_INT(_24698)) {
        {uintptr_t tu;
             tu = (uintptr_t)_visible_mask_47844 & (uintptr_t)_24698;
             _24699 = MAKE_UINT(tu);
        }
    }
    else {
        _24699 = binary_op(AND_BITS, _visible_mask_47844, _24698);
    }
    _24698 = NOVALUE;
    DeRef(_24696);
    _24696 = NOVALUE;
    return _24699;
    ;
}


object _54MarkTargets(object _s_47864, object _attribute_47865)
{
    object _p_47867 = NOVALUE;
    object _sname_47868 = NOVALUE;
    object _string_47869 = NOVALUE;
    object _colon_47870 = NOVALUE;
    object _h_47871 = NOVALUE;
    object _scope_47872 = NOVALUE;
    object _found_47893 = NOVALUE;
    object _24747 = NOVALUE;
    object _24745 = NOVALUE;
    object _24744 = NOVALUE;
    object _24743 = NOVALUE;
    object _24742 = NOVALUE;
    object _24740 = NOVALUE;
    object _24739 = NOVALUE;
    object _24738 = NOVALUE;
    object _24737 = NOVALUE;
    object _24736 = NOVALUE;
    object _24734 = NOVALUE;
    object _24733 = NOVALUE;
    object _24732 = NOVALUE;
    object _24730 = NOVALUE;
    object _24728 = NOVALUE;
    object _24726 = NOVALUE;
    object _24725 = NOVALUE;
    object _24724 = NOVALUE;
    object _24723 = NOVALUE;
    object _24721 = NOVALUE;
    object _24720 = NOVALUE;
    object _24719 = NOVALUE;
    object _24718 = NOVALUE;
    object _24716 = NOVALUE;
    object _24715 = NOVALUE;
    object _24711 = NOVALUE;
    object _24710 = NOVALUE;
    object _24709 = NOVALUE;
    object _24708 = NOVALUE;
    object _24707 = NOVALUE;
    object _24706 = NOVALUE;
    object _24705 = NOVALUE;
    object _24704 = NOVALUE;
    object _24703 = NOVALUE;
    object _24702 = NOVALUE;
    object _24701 = NOVALUE;
    object _24700 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47864)) {
        _1 = (object)(DBL_PTR(_s_47864)->dbl);
        DeRefDS(_s_47864);
        _s_47864 = _1;
    }

    /** symtab.e:648		sequence sname*/

    /** symtab.e:649		sequence string*/

    /** symtab.e:650		integer colon, h*/

    /** symtab.e:651		integer scope*/

    /** symtab.e:653		if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24700 = (object)*(((s1_ptr)_2)->base + _s_47864);
    _2 = (object)SEQ_PTR(_24700);
    _24701 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24700 = NOVALUE;
    if (IS_ATOM_INT(_24701)) {
        _24702 = (_24701 == 3LL);
    }
    else {
        _24702 = binary_op(EQUALS, _24701, 3LL);
    }
    _24701 = NOVALUE;
    if (IS_ATOM_INT(_24702)) {
        if (_24702 != 0) {
            _24703 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24702)->dbl != 0.0) {
            _24703 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24704 = (object)*(((s1_ptr)_2)->base + _s_47864);
    _2 = (object)SEQ_PTR(_24704);
    _24705 = (object)*(((s1_ptr)_2)->base + 3LL);
    _24704 = NOVALUE;
    if (IS_ATOM_INT(_24705)) {
        _24706 = (_24705 == 2LL);
    }
    else {
        _24706 = binary_op(EQUALS, _24705, 2LL);
    }
    _24705 = NOVALUE;
    DeRef(_24703);
    if (IS_ATOM_INT(_24706))
    _24703 = (_24706 != 0);
    else
    _24703 = DBL_PTR(_24706)->dbl != 0.0;
L1: 
    if (_24703 == 0) {
        goto L2; // [59] 411
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24708 = (object)*(((s1_ptr)_2)->base + _s_47864);
    _2 = (object)SEQ_PTR(_24708);
    _24709 = (object)*(((s1_ptr)_2)->base + 1LL);
    _24708 = NOVALUE;
    _24710 = IS_SEQUENCE(_24709);
    _24709 = NOVALUE;
    if (_24710 == 0)
    {
        _24710 = NOVALUE;
        goto L2; // [79] 411
    }
    else{
        _24710 = NOVALUE;
    }

    /** symtab.e:658			integer found = 0*/
    _found_47893 = 0LL;

    /** symtab.e:660			string = SymTab[s][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24711 = (object)*(((s1_ptr)_2)->base + _s_47864);
    DeRef(_string_47869);
    _2 = (object)SEQ_PTR(_24711);
    _string_47869 = (object)*(((s1_ptr)_2)->base + 1LL);
    Ref(_string_47869);
    _24711 = NOVALUE;

    /** symtab.e:661			colon = find(':', string)*/
    _colon_47870 = find_from(58LL, _string_47869, 1LL);

    /** symtab.e:662			if colon = 0 then*/
    if (_colon_47870 != 0LL)
    goto L3; // [112] 126

    /** symtab.e:663				sname = string*/
    RefDS(_string_47869);
    DeRef(_sname_47868);
    _sname_47868 = _string_47869;
    goto L4; // [123] 200
L3: 

    /** symtab.e:665				sname = string[colon+1..$]  -- ignore namespace part*/
    _24715 = _colon_47870 + 1;
    if (_24715 > MAXINT){
        _24715 = NewDouble((eudouble)_24715);
    }
    if (IS_SEQUENCE(_string_47869)){
            _24716 = SEQ_PTR(_string_47869)->length;
    }
    else {
        _24716 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_47868;
    RHS_Slice(_string_47869, _24715, _24716);

    /** symtab.e:666				while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_47868)){
            _24718 = SEQ_PTR(_sname_47868)->length;
    }
    else {
        _24718 = 1;
    }
    if (_24718 == 0) {
        _24719 = 0;
        goto L6; // [148] 164
    }
    _2 = (object)SEQ_PTR(_sname_47868);
    _24720 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24720)) {
        _24721 = (_24720 == 32LL);
    }
    else {
        _24721 = binary_op(EQUALS, _24720, 32LL);
    }
    _24720 = NOVALUE;
    if (IS_ATOM_INT(_24721))
    _24719 = (_24721 != 0);
    else
    _24719 = DBL_PTR(_24721)->dbl != 0.0;
L6: 
    if (_24719 != 0) {
        goto L7; // [164] 181
    }
    _2 = (object)SEQ_PTR(_sname_47868);
    _24723 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24723)) {
        _24724 = (_24723 == 9LL);
    }
    else {
        _24724 = binary_op(EQUALS, _24723, 9LL);
    }
    _24723 = NOVALUE;
    if (_24724 <= 0) {
        if (_24724 == 0) {
            DeRef(_24724);
            _24724 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24724) && DBL_PTR(_24724)->dbl == 0.0){
                DeRef(_24724);
                _24724 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24724);
            _24724 = NOVALUE;
        }
    }
    DeRef(_24724);
    _24724 = NOVALUE;
L7: 

    /** symtab.e:667					sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_47868)){
            _24725 = SEQ_PTR(_sname_47868)->length;
    }
    else {
        _24725 = 1;
    }
    _24726 = _24725 - 1LL;
    _24725 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_47868)->length;
        int size = (IS_ATOM_INT(_24726)) ? _24726 : (object)(DBL_PTR(_24726)->dbl);
        if (size <= 0) {
            DeRef(_sname_47868);
            _sname_47868 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_47868);
            DeRef(_sname_47868);
            _sname_47868 = _sname_47868;
        }
        else Tail(SEQ_PTR(_sname_47868), len-size+1, &_sname_47868);
    }
    _24726 = NOVALUE;

    /** symtab.e:668				end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** symtab.e:671			if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_47868)){
            _24728 = SEQ_PTR(_sname_47868)->length;
    }
    else {
        _24728 = 1;
    }
    if (_24728 != 0LL)
    goto L9; // [207] 218

    /** symtab.e:672				return 1*/
    DeRefDS(_sname_47868);
    DeRef(_string_47869);
    DeRef(_24721);
    _24721 = NOVALUE;
    DeRef(_24702);
    _24702 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24715);
    _24715 = NOVALUE;
    return 1LL;
L9: 

    /** symtab.e:674			h = buckets[hashfn(sname)]*/
    RefDS(_sname_47868);
    _24730 = _54hashfn(_sname_47868);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_24730)){
        _h_47871 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24730)->dbl));
    }
    else{
        _h_47871 = (object)*(((s1_ptr)_2)->base + _24730);
    }
    if (!IS_ATOM_INT(_h_47871))
    _h_47871 = (object)DBL_PTR(_h_47871)->dbl;

    /** symtab.e:675			while h do*/
LA: 
    if (_h_47871 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** symtab.e:676				if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24732 = (object)*(((s1_ptr)_2)->base + _h_47871);
    _2 = (object)SEQ_PTR(_24732);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _24733 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _24733 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _24732 = NOVALUE;
    if (_sname_47868 == _24733)
    _24734 = 1;
    else if (IS_ATOM_INT(_sname_47868) && IS_ATOM_INT(_24733))
    _24734 = 0;
    else
    _24734 = (compare(_sname_47868, _24733) == 0);
    _24733 = NOVALUE;
    if (_24734 == 0)
    {
        _24734 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24734 = NOVALUE;
    }

    /** symtab.e:677					if attribute = S_NREFS then*/
    if (_attribute_47865 != 12LL)
    goto LD; // [263] 289

    /** symtab.e:678						if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** symtab.e:679							add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = 27LL;
    ((intptr_t *)_2)[2] = _h_47871;
    _24736 = MAKE_SEQ(_1);
    _54add_ref(_24736);
    _24736 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** symtab.e:681					elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24737 = _54is_routine(_h_47871);
    if (IS_ATOM_INT(_24737)) {
        if (_24737 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24737)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24739 = _54is_visible(_h_47871, _36current_file_no_21439);
    if (_24739 == 0) {
        DeRef(_24739);
        _24739 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24739) && DBL_PTR(_24739)->dbl == 0.0){
            DeRef(_24739);
            _24739 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24739);
        _24739 = NOVALUE;
    }
    DeRef(_24739);
    _24739 = NOVALUE;

    /** symtab.e:682						SymTab[h][attribute] += 1*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_h_47871 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    _24742 = (object)*(((s1_ptr)_2)->base + _attribute_47865);
    _24740 = NOVALUE;
    if (IS_ATOM_INT(_24742)) {
        _24743 = _24742 + 1;
        if (_24743 > MAXINT){
            _24743 = NewDouble((eudouble)_24743);
        }
    }
    else
    _24743 = binary_op(PLUS, 1, _24742);
    _24742 = NOVALUE;
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + _attribute_47865);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24743;
    if( _1 != _24743 ){
        DeRef(_1);
    }
    _24743 = NOVALUE;
    _24740 = NOVALUE;

    /** symtab.e:683						if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24744 = (object)*(((s1_ptr)_2)->base + _h_47871);
    _2 = (object)SEQ_PTR(_24744);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _24745 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _24745 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _24744 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21439, _24745)){
        _24745 = NOVALUE;
        goto L10; // [347] 357
    }
    _24745 = NOVALUE;

    /** symtab.e:684							found = 1*/
    _found_47893 = 1LL;
L10: 
LF: 
LE: 
LC: 

    /** symtab.e:688				h = SymTab[h][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24747 = (object)*(((s1_ptr)_2)->base + _h_47871);
    _2 = (object)SEQ_PTR(_24747);
    _h_47871 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_h_47871)){
        _h_47871 = (object)DBL_PTR(_h_47871)->dbl;
    }
    _24747 = NOVALUE;

    /** symtab.e:689			end while*/
    goto LA; // [378] 235
LB: 

    /** symtab.e:691			if not found then*/
    if (_found_47893 != 0)
    goto L11; // [383] 400

    /** symtab.e:692				map:put( recheck_routines, current_file_no, s, map:APPEND )*/
    Ref(_54recheck_routines_47765);
    _29put(_54recheck_routines_47765, _36current_file_no_21439, _s_47864, 6LL, 0LL);
L11: 

    /** symtab.e:694			return found*/
    DeRef(_sname_47868);
    DeRef(_string_47869);
    DeRef(_24721);
    _24721 = NOVALUE;
    DeRef(_24730);
    _24730 = NOVALUE;
    DeRef(_24702);
    _24702 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24715);
    _24715 = NOVALUE;
    DeRef(_24737);
    _24737 = NOVALUE;
    return _found_47893;
    goto L12; // [408] 440
L2: 

    /** symtab.e:696			if not just_mark_everything_from then*/
    if (_54just_mark_everything_from_47692 != 0)
    goto L13; // [415] 428

    /** symtab.e:697				just_mark_everything_from = TopLevelSub*/
    _54just_mark_everything_from_47692 = _36TopLevelSub_21446;
L13: 

    /** symtab.e:699			mark_all( attribute )*/
    _54mark_all(_attribute_47865);

    /** symtab.e:700			return 1*/
    DeRef(_sname_47868);
    DeRef(_string_47869);
    DeRef(_24721);
    _24721 = NOVALUE;
    DeRef(_24730);
    _24730 = NOVALUE;
    DeRef(_24702);
    _24702 = NOVALUE;
    DeRef(_24706);
    _24706 = NOVALUE;
    DeRef(_24715);
    _24715 = NOVALUE;
    DeRef(_24737);
    _24737 = NOVALUE;
    return 1LL;
L12: 
    ;
}


void _54resolve_unincluded_globals(object _ok_47971)
{
    object _0, _1, _2;
    

    /** symtab.e:724		Resolve_unincluded_globals = ok*/
    _54Resolve_unincluded_globals_47968 = 1LL;

    /** symtab.e:725	end procedure*/
    return;
    ;
}


object _54get_resolve_unincluded_globals()
{
    object _0, _1, _2;
    

    /** symtab.e:728		return Resolve_unincluded_globals*/
    return _54Resolve_unincluded_globals_47968;
    ;
}


object _54keyfind(object _word_47977, object _file_no_47978, object _scanning_file_47979, object _namespace_ok_47982, object _hashval_47983)
{
    object _msg_47985 = NOVALUE;
    object _b_name_47986 = NOVALUE;
    object _scope_47987 = NOVALUE;
    object _defined_47988 = NOVALUE;
    object _ix_47989 = NOVALUE;
    object _st_ptr_47991 = NOVALUE;
    object _st_builtin_47992 = NOVALUE;
    object _tok_47994 = NOVALUE;
    object _gtok_47995 = NOVALUE;
    object _any_symbol_47998 = NOVALUE;
    object _tok_file_48166 = NOVALUE;
    object _good_48173 = NOVALUE;
    object _include_type_48183 = NOVALUE;
    object _msg_file_48239 = NOVALUE;
    object _24942 = NOVALUE;
    object _24941 = NOVALUE;
    object _24939 = NOVALUE;
    object _24937 = NOVALUE;
    object _24936 = NOVALUE;
    object _24935 = NOVALUE;
    object _24934 = NOVALUE;
    object _24933 = NOVALUE;
    object _24931 = NOVALUE;
    object _24929 = NOVALUE;
    object _24928 = NOVALUE;
    object _24927 = NOVALUE;
    object _24926 = NOVALUE;
    object _24925 = NOVALUE;
    object _24924 = NOVALUE;
    object _24923 = NOVALUE;
    object _24922 = NOVALUE;
    object _24920 = NOVALUE;
    object _24919 = NOVALUE;
    object _24918 = NOVALUE;
    object _24917 = NOVALUE;
    object _24916 = NOVALUE;
    object _24915 = NOVALUE;
    object _24914 = NOVALUE;
    object _24913 = NOVALUE;
    object _24912 = NOVALUE;
    object _24911 = NOVALUE;
    object _24910 = NOVALUE;
    object _24909 = NOVALUE;
    object _24908 = NOVALUE;
    object _24907 = NOVALUE;
    object _24906 = NOVALUE;
    object _24905 = NOVALUE;
    object _24904 = NOVALUE;
    object _24902 = NOVALUE;
    object _24901 = NOVALUE;
    object _24898 = NOVALUE;
    object _24894 = NOVALUE;
    object _24892 = NOVALUE;
    object _24891 = NOVALUE;
    object _24890 = NOVALUE;
    object _24889 = NOVALUE;
    object _24888 = NOVALUE;
    object _24886 = NOVALUE;
    object _24885 = NOVALUE;
    object _24884 = NOVALUE;
    object _24883 = NOVALUE;
    object _24881 = NOVALUE;
    object _24878 = NOVALUE;
    object _24877 = NOVALUE;
    object _24876 = NOVALUE;
    object _24875 = NOVALUE;
    object _24873 = NOVALUE;
    object _24870 = NOVALUE;
    object _24869 = NOVALUE;
    object _24868 = NOVALUE;
    object _24867 = NOVALUE;
    object _24866 = NOVALUE;
    object _24865 = NOVALUE;
    object _24864 = NOVALUE;
    object _24861 = NOVALUE;
    object _24860 = NOVALUE;
    object _24858 = NOVALUE;
    object _24856 = NOVALUE;
    object _24854 = NOVALUE;
    object _24853 = NOVALUE;
    object _24852 = NOVALUE;
    object _24848 = NOVALUE;
    object _24847 = NOVALUE;
    object _24842 = NOVALUE;
    object _24840 = NOVALUE;
    object _24838 = NOVALUE;
    object _24837 = NOVALUE;
    object _24833 = NOVALUE;
    object _24832 = NOVALUE;
    object _24830 = NOVALUE;
    object _24829 = NOVALUE;
    object _24827 = NOVALUE;
    object _24826 = NOVALUE;
    object _24825 = NOVALUE;
    object _24824 = NOVALUE;
    object _24823 = NOVALUE;
    object _24821 = NOVALUE;
    object _24820 = NOVALUE;
    object _24819 = NOVALUE;
    object _24818 = NOVALUE;
    object _24817 = NOVALUE;
    object _24816 = NOVALUE;
    object _24815 = NOVALUE;
    object _24814 = NOVALUE;
    object _24813 = NOVALUE;
    object _24812 = NOVALUE;
    object _24811 = NOVALUE;
    object _24810 = NOVALUE;
    object _24809 = NOVALUE;
    object _24808 = NOVALUE;
    object _24807 = NOVALUE;
    object _24806 = NOVALUE;
    object _24805 = NOVALUE;
    object _24804 = NOVALUE;
    object _24803 = NOVALUE;
    object _24802 = NOVALUE;
    object _24801 = NOVALUE;
    object _24800 = NOVALUE;
    object _24798 = NOVALUE;
    object _24797 = NOVALUE;
    object _24795 = NOVALUE;
    object _24794 = NOVALUE;
    object _24793 = NOVALUE;
    object _24792 = NOVALUE;
    object _24791 = NOVALUE;
    object _24789 = NOVALUE;
    object _24788 = NOVALUE;
    object _24787 = NOVALUE;
    object _24785 = NOVALUE;
    object _24784 = NOVALUE;
    object _24783 = NOVALUE;
    object _24782 = NOVALUE;
    object _24781 = NOVALUE;
    object _24780 = NOVALUE;
    object _24779 = NOVALUE;
    object _24777 = NOVALUE;
    object _24776 = NOVALUE;
    object _24771 = NOVALUE;
    object _24768 = NOVALUE;
    object _24767 = NOVALUE;
    object _24766 = NOVALUE;
    object _24765 = NOVALUE;
    object _24764 = NOVALUE;
    object _24763 = NOVALUE;
    object _24762 = NOVALUE;
    object _24761 = NOVALUE;
    object _24760 = NOVALUE;
    object _24759 = NOVALUE;
    object _24758 = NOVALUE;
    object _24757 = NOVALUE;
    object _24756 = NOVALUE;
    object _24755 = NOVALUE;
    object _24754 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_47978)) {
        _1 = (object)(DBL_PTR(_file_no_47978)->dbl);
        DeRefDS(_file_no_47978);
        _file_no_47978 = _1;
    }
    if (!IS_ATOM_INT(_hashval_47983)) {
        _1 = (object)(DBL_PTR(_hashval_47983)->dbl);
        DeRefDS(_hashval_47983);
        _hashval_47983 = _1;
    }

    /** symtab.e:750		dup_globals = {}*/
    RefDS(_21993);
    DeRef(_54dup_globals_47963);
    _54dup_globals_47963 = _21993;

    /** symtab.e:751		dup_overrides = {}*/
    RefDS(_21993);
    DeRefi(_54dup_overrides_47964);
    _54dup_overrides_47964 = _21993;

    /** symtab.e:752		in_include_path = {}*/
    RefDS(_21993);
    DeRef(_54in_include_path_47965);
    _54in_include_path_47965 = _21993;

    /** symtab.e:753		symbol_resolution_warning = ""*/
    RefDS(_21993);
    DeRef(_36symbol_resolution_warning_21544);
    _36symbol_resolution_warning_21544 = _21993;

    /** symtab.e:754		st_builtin = 0*/
    _st_builtin_47992 = 0LL;

    /** symtab.e:756		ifdef EUDIS then*/

    /** symtab.e:759		st_ptr = buckets[hashval]*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _st_ptr_47991 = (object)*(((s1_ptr)_2)->base + _hashval_47983);
    if (!IS_ATOM_INT(_st_ptr_47991)){
        _st_ptr_47991 = (object)DBL_PTR(_st_ptr_47991)->dbl;
    }

    /** symtab.e:760		integer any_symbol = namespace_ok = -1*/
    _any_symbol_47998 = (_namespace_ok_47982 == -1LL);

    /** symtab.e:761		while st_ptr do*/
L1: 
    if (_st_ptr_47991 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** symtab.e:762			if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24754 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24754);
    _24755 = (object)*(((s1_ptr)_2)->base + 4LL);
    _24754 = NOVALUE;
    if (IS_ATOM_INT(_24755)) {
        _24756 = (_24755 != 9LL);
    }
    else {
        _24756 = binary_op(NOTEQ, _24755, 9LL);
    }
    _24755 = NOVALUE;
    if (IS_ATOM_INT(_24756)) {
        if (_24756 == 0) {
            DeRef(_24757);
            _24757 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24756)->dbl == 0.0) {
            DeRef(_24757);
            _24757 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24758 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24758);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _24759 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _24759 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _24758 = NOVALUE;
    if (_word_47977 == _24759)
    _24760 = 1;
    else if (IS_ATOM_INT(_word_47977) && IS_ATOM_INT(_24759))
    _24760 = 0;
    else
    _24760 = (compare(_word_47977, _24759) == 0);
    _24759 = NOVALUE;
    DeRef(_24757);
    _24757 = (_24760 != 0);
L3: 
    if (_24757 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_47998 != 0) {
        DeRef(_24762);
        _24762 = 1;
        goto L5; // [120] 150
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24763 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24763);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _24764 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _24764 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _24763 = NOVALUE;
    if (IS_ATOM_INT(_24764)) {
        _24765 = (_24764 == 523LL);
    }
    else {
        _24765 = binary_op(EQUALS, _24764, 523LL);
    }
    _24764 = NOVALUE;
    if (IS_ATOM_INT(_24765)) {
        _24766 = (_namespace_ok_47982 == _24765);
    }
    else {
        _24766 = binary_op(EQUALS, _namespace_ok_47982, _24765);
    }
    DeRef(_24765);
    _24765 = NOVALUE;
    if (IS_ATOM_INT(_24766))
    _24762 = (_24766 != 0);
    else
    _24762 = DBL_PTR(_24766)->dbl != 0.0;
L5: 
    if (_24762 == 0)
    {
        _24762 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24762 = NOVALUE;
    }

    /** symtab.e:767				tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24767 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24767);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _24768 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _24768 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _24767 = NOVALUE;
    Ref(_24768);
    DeRef(_tok_47994);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24768;
    ((intptr_t *)_2)[2] = _st_ptr_47991;
    _tok_47994 = MAKE_SEQ(_1);
    _24768 = NOVALUE;

    /** symtab.e:769				if file_no = -1 then*/
    if (_file_no_47978 != -1LL)
    goto L6; // [174] 714

    /** symtab.e:774					scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24771 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24771);
    _scope_47987 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_47987)){
        _scope_47987 = (object)DBL_PTR(_scope_47987)->dbl;
    }
    _24771 = NOVALUE;

    /** symtab.e:776					switch scope with fallthru do*/
    _0 = _scope_47987;
    switch ( _0 ){ 

        /** symtab.e:777					case SC_OVERRIDE then*/
        case 12:

        /** symtab.e:778						dup_overrides &= st_ptr*/
        Append(&_54dup_overrides_47964, _54dup_overrides_47964, _st_ptr_47991);

        /** symtab.e:779						break*/
        goto L7; // [215] 1011

        /** symtab.e:781					case SC_PREDEF then*/
        case 7:

        /** symtab.e:782						st_builtin = st_ptr*/
        _st_builtin_47992 = _st_ptr_47991;

        /** symtab.e:783						break*/
        goto L7; // [230] 1011

        /** symtab.e:784					case SC_GLOBAL then*/
        case 6:

        /** symtab.e:785						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24776 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24776);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24777 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24777 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24776 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47979, _24777)){
            _24777 = NOVALUE;
            goto L8; // [250] 274
        }
        _24777 = NOVALUE;

        /** symtab.e:788							if BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** symtab.e:789								add_ref(tok)*/
        Ref(_tok_47994);
        _54add_ref(_tok_47994);
L9: 

        /** symtab.e:792							return tok*/
        DeRefDS(_word_47977);
        DeRef(_msg_47985);
        DeRef(_b_name_47986);
        DeRef(_gtok_47995);
        DeRef(_24766);
        _24766 = NOVALUE;
        DeRef(_24756);
        _24756 = NOVALUE;
        return _tok_47994;
L8: 

        /** symtab.e:796						if Resolve_unincluded_globals */
        if (_54Resolve_unincluded_globals_47968 != 0) {
            _24779 = 1;
            goto LA; // [278] 322
        }
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _24780 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        if (_24780 == 0) {
            _24781 = 0;
            goto LB; // [288] 318
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24782 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24783 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24783);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24784 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24784 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24783 = NOVALUE;
        _2 = (object)SEQ_PTR(_24782);
        if (!IS_ATOM_INT(_24784)){
            _24785 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24784)->dbl));
        }
        else{
            _24785 = (object)*(((s1_ptr)_2)->base + _24784);
        }
        _24782 = NOVALUE;
        if (IS_ATOM_INT(_24785))
        _24781 = (_24785 != 0);
        else
        _24781 = DBL_PTR(_24785)->dbl != 0.0;
LB: 
        _24779 = (_24781 != 0);
LA: 
        if (_24779 != 0) {
            goto LC; // [322] 349
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24787 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24787);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _24788 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _24788 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _24787 = NOVALUE;
        if (IS_ATOM_INT(_24788)) {
            _24789 = (_24788 == 523LL);
        }
        else {
            _24789 = binary_op(EQUALS, _24788, 523LL);
        }
        _24788 = NOVALUE;
        if (_24789 == 0) {
            DeRef(_24789);
            _24789 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24789) && DBL_PTR(_24789)->dbl == 0.0){
                DeRef(_24789);
                _24789 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24789);
            _24789 = NOVALUE;
        }
        DeRef(_24789);
        _24789 = NOVALUE;
LC: 

        /** symtab.e:800							gtok = tok*/
        Ref(_tok_47994);
        DeRef(_gtok_47995);
        _gtok_47995 = _tok_47994;

        /** symtab.e:801							dup_globals &= st_ptr*/
        Append(&_54dup_globals_47963, _54dup_globals_47963, _st_ptr_47991);

        /** symtab.e:802							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24791 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24792 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24792);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24793 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24793 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24792 = NOVALUE;
        _2 = (object)SEQ_PTR(_24791);
        if (!IS_ATOM_INT(_24793)){
            _24794 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24793)->dbl));
        }
        else{
            _24794 = (object)*(((s1_ptr)_2)->base + _24793);
        }
        _24791 = NOVALUE;
        if (IS_ATOM_INT(_24794)) {
            _24795 = (_24794 != 0LL);
        }
        else {
            _24795 = binary_op(NOTEQ, _24794, 0LL);
        }
        _24794 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_47965) && IS_ATOM(_24795)) {
            Ref(_24795);
            Append(&_54in_include_path_47965, _54in_include_path_47965, _24795);
        }
        else if (IS_ATOM(_54in_include_path_47965) && IS_SEQUENCE(_24795)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_47965, _54in_include_path_47965, _24795);
        }
        DeRef(_24795);
        _24795 = NOVALUE;

        /** symtab.e:804						break*/
        goto L7; // [399] 1011

        /** symtab.e:807					case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** symtab.e:809						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24797 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24797);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24798 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24798 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24797 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47979, _24798)){
            _24798 = NOVALUE;
            goto LD; // [421] 445
        }
        _24798 = NOVALUE;

        /** symtab.e:811							if BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** symtab.e:812								add_ref(tok)*/
        Ref(_tok_47994);
        _54add_ref(_tok_47994);
LE: 

        /** symtab.e:815							return tok*/
        DeRefDS(_word_47977);
        DeRef(_msg_47985);
        DeRef(_b_name_47986);
        DeRef(_gtok_47995);
        DeRef(_24766);
        _24766 = NOVALUE;
        _24793 = NOVALUE;
        DeRef(_24756);
        _24756 = NOVALUE;
        _24785 = NOVALUE;
        _24784 = NOVALUE;
        _24780 = NOVALUE;
        return _tok_47994;
LD: 

        /** symtab.e:818						if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (object)SEQ_PTR(_37finished_files_15409);
        _24800 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        if (_24800 != 0) {
            _24801 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_47982 == 0) {
            _24802 = 0;
            goto L10; // [457] 483
        }
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24803 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24803);
        if (!IS_ATOM_INT(_36S_TOKEN_21081)){
            _24804 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
        }
        else{
            _24804 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
        }
        _24803 = NOVALUE;
        if (IS_ATOM_INT(_24804)) {
            _24805 = (_24804 == 523LL);
        }
        else {
            _24805 = binary_op(EQUALS, _24804, 523LL);
        }
        _24804 = NOVALUE;
        if (IS_ATOM_INT(_24805))
        _24802 = (_24805 != 0);
        else
        _24802 = DBL_PTR(_24805)->dbl != 0.0;
L10: 
        _24801 = (_24802 != 0);
LF: 
        if (_24801 == 0) {
            goto L7; // [487] 1011
        }
        _24807 = (_scope_47987 == 13LL);
        if (_24807 == 0) {
            _24808 = 0;
            goto L11; // [497] 533
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24809 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24810 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24810);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24811 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24811 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24810 = NOVALUE;
        _2 = (object)SEQ_PTR(_24809);
        if (!IS_ATOM_INT(_24811)){
            _24812 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24811)->dbl));
        }
        else{
            _24812 = (object)*(((s1_ptr)_2)->base + _24811);
        }
        _24809 = NOVALUE;
        if (IS_ATOM_INT(_24812)) {
            {uintptr_t tu;
                 tu = (uintptr_t)6LL & (uintptr_t)_24812;
                 _24813 = MAKE_UINT(tu);
            }
        }
        else {
            _24813 = binary_op(AND_BITS, 6LL, _24812);
        }
        _24812 = NOVALUE;
        if (IS_ATOM_INT(_24813))
        _24808 = (_24813 != 0);
        else
        _24808 = DBL_PTR(_24813)->dbl != 0.0;
L11: 
        if (_24808 != 0) {
            DeRef(_24814);
            _24814 = 1;
            goto L12; // [533] 583
        }
        _24815 = (_scope_47987 == 11LL);
        if (_24815 == 0) {
            _24816 = 0;
            goto L13; // [543] 579
        }
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24817 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24818 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24818);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24819 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24819 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24818 = NOVALUE;
        _2 = (object)SEQ_PTR(_24817);
        if (!IS_ATOM_INT(_24819)){
            _24820 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24819)->dbl));
        }
        else{
            _24820 = (object)*(((s1_ptr)_2)->base + _24819);
        }
        _24817 = NOVALUE;
        if (IS_ATOM_INT(_24820)) {
            {uintptr_t tu;
                 tu = (uintptr_t)2LL & (uintptr_t)_24820;
                 _24821 = MAKE_UINT(tu);
            }
        }
        else {
            _24821 = binary_op(AND_BITS, 2LL, _24820);
        }
        _24820 = NOVALUE;
        if (IS_ATOM_INT(_24821))
        _24816 = (_24821 != 0);
        else
        _24816 = DBL_PTR(_24821)->dbl != 0.0;
L13: 
        DeRef(_24814);
        _24814 = (_24816 != 0);
L12: 
        if (_24814 == 0)
        {
            _24814 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24814 = NOVALUE;
        }

        /** symtab.e:826							gtok = tok*/
        Ref(_tok_47994);
        DeRef(_gtok_47995);
        _gtok_47995 = _tok_47994;

        /** symtab.e:827							dup_globals &= st_ptr*/
        Append(&_54dup_globals_47963, _54dup_globals_47963, _st_ptr_47991);

        /** symtab.e:828							in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (object)SEQ_PTR(_37include_matrix_15413);
        _24823 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24824 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24824);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24825 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24825 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24824 = NOVALUE;
        _2 = (object)SEQ_PTR(_24823);
        if (!IS_ATOM_INT(_24825)){
            _24826 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24825)->dbl));
        }
        else{
            _24826 = (object)*(((s1_ptr)_2)->base + _24825);
        }
        _24823 = NOVALUE;
        if (IS_ATOM_INT(_24826)) {
            _24827 = (_24826 != 0LL);
        }
        else {
            _24827 = binary_op(NOTEQ, _24826, 0LL);
        }
        _24826 = NOVALUE;
        if (IS_SEQUENCE(_54in_include_path_47965) && IS_ATOM(_24827)) {
            Ref(_24827);
            Append(&_54in_include_path_47965, _54in_include_path_47965, _24827);
        }
        else if (IS_ATOM(_54in_include_path_47965) && IS_SEQUENCE(_24827)) {
        }
        else {
            Concat((object_ptr)&_54in_include_path_47965, _54in_include_path_47965, _24827);
        }
        DeRef(_24827);
        _24827 = NOVALUE;

        /** symtab.e:831	ifdef STDDEBUG then*/

        /** symtab.e:852						break*/
        goto L7; // [639] 1011

        /** symtab.e:853					case SC_LOCAL then*/
        case 5:

        /** symtab.e:854						if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24829 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
        _2 = (object)SEQ_PTR(_24829);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24830 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24830 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24829 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_47979, _24830)){
            _24830 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24830 = NOVALUE;

        /** symtab.e:857							if BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** symtab.e:858								add_ref(tok)*/
        Ref(_tok_47994);
        _54add_ref(_tok_47994);
L14: 

        /** symtab.e:861							return tok*/
        DeRefDS(_word_47977);
        DeRef(_msg_47985);
        DeRef(_b_name_47986);
        DeRef(_gtok_47995);
        DeRef(_24766);
        _24766 = NOVALUE;
        DeRef(_24815);
        _24815 = NOVALUE;
        DeRef(_24807);
        _24807 = NOVALUE;
        _24825 = NOVALUE;
        _24811 = NOVALUE;
        _24793 = NOVALUE;
        DeRef(_24813);
        _24813 = NOVALUE;
        _24819 = NOVALUE;
        DeRef(_24756);
        _24756 = NOVALUE;
        _24785 = NOVALUE;
        DeRef(_24821);
        _24821 = NOVALUE;
        _24784 = NOVALUE;
        _24800 = NOVALUE;
        _24780 = NOVALUE;
        DeRef(_24805);
        _24805 = NOVALUE;
        return _tok_47994;

        /** symtab.e:863						break*/
        goto L7; // [685] 1011

        /** symtab.e:864					case else*/
        default:

        /** symtab.e:866						if BIND then*/
        if (_36BIND_21044 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** symtab.e:867							add_ref(tok)*/
        Ref(_tok_47994);
        _54add_ref(_tok_47994);
L15: 

        /** symtab.e:870						return tok -- keyword, private*/
        DeRefDS(_word_47977);
        DeRef(_msg_47985);
        DeRef(_b_name_47986);
        DeRef(_gtok_47995);
        DeRef(_24766);
        _24766 = NOVALUE;
        DeRef(_24815);
        _24815 = NOVALUE;
        DeRef(_24807);
        _24807 = NOVALUE;
        _24825 = NOVALUE;
        _24811 = NOVALUE;
        _24793 = NOVALUE;
        DeRef(_24813);
        _24813 = NOVALUE;
        _24819 = NOVALUE;
        DeRef(_24756);
        _24756 = NOVALUE;
        _24785 = NOVALUE;
        DeRef(_24821);
        _24821 = NOVALUE;
        _24784 = NOVALUE;
        _24800 = NOVALUE;
        _24780 = NOVALUE;
        DeRef(_24805);
        _24805 = NOVALUE;
        return _tok_47994;
    ;}    goto L7; // [711] 1011
L6: 

    /** symtab.e:877					scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_tok_47994);
    _24832 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24832)){
        _24833 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24832)->dbl));
    }
    else{
        _24833 = (object)*(((s1_ptr)_2)->base + _24832);
    }
    _2 = (object)SEQ_PTR(_24833);
    _scope_47987 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_scope_47987)){
        _scope_47987 = (object)DBL_PTR(_scope_47987)->dbl;
    }
    _24833 = NOVALUE;

    /** symtab.e:878					if not file_no then*/
    if (_file_no_47978 != 0)
    goto L16; // [738] 772

    /** symtab.e:880						if scope = SC_PREDEF then*/
    if (_scope_47987 != 7LL)
    goto L17; // [745] 1010

    /** symtab.e:881							if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** symtab.e:882								add_ref( tok )*/
    Ref(_tok_47994);
    _54add_ref(_tok_47994);
L18: 

    /** symtab.e:884							return tok*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_gtok_47995);
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    _24832 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _tok_47994;
    goto L17; // [769] 1010
L16: 

    /** symtab.e:887						integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (object)SEQ_PTR(_tok_47994);
    _24837 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24837)){
        _24838 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24837)->dbl));
    }
    else{
        _24838 = (object)*(((s1_ptr)_2)->base + _24837);
    }
    _2 = (object)SEQ_PTR(_24838);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _tok_file_48166 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _tok_file_48166 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    if (!IS_ATOM_INT(_tok_file_48166)){
        _tok_file_48166 = (object)DBL_PTR(_tok_file_48166)->dbl;
    }
    _24838 = NOVALUE;

    /** symtab.e:888						integer good = 0*/
    _good_48173 = 0LL;

    /** symtab.e:889						if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24840 = (_scope_47987 == 3LL);
    if (_24840 != 0) {
        goto L19; // [807] 940
    }
    _24842 = (_scope_47987 == 7LL);
    if (_24842 == 0)
    {
        DeRef(_24842);
        _24842 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24842);
        _24842 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** symtab.e:892						elsif file_no = tok_file then*/
    if (_file_no_47978 != _tok_file_48166)
    goto L1B; // [827] 839

    /** symtab.e:893							good = 1*/
    _good_48173 = 1LL;
    goto L19; // [836] 940
L1B: 

    /** symtab.e:896							integer include_type = 0*/
    _include_type_48183 = 0LL;

    /** symtab.e:897							switch scope do*/
    _0 = _scope_47987;
    switch ( _0 ){ 

        /** symtab.e:898								case SC_GLOBAL then*/
        case 6:

        /** symtab.e:899									if Resolve_unincluded_globals then*/
        if (_54Resolve_unincluded_globals_47968 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** symtab.e:900										include_type = ANY_INCLUDE*/
        _include_type_48183 = 7LL;
        goto L1D; // [871] 919
L1C: 

        /** symtab.e:902										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48183 = 6LL;
        goto L1D; // [884] 919

        /** symtab.e:905								case SC_PUBLIC then*/
        case 13:

        /** symtab.e:907									if tok_file != file_no then*/
        if (_tok_file_48166 == _file_no_47978)
        goto L1E; // [892] 908

        /** symtab.e:908										include_type = PUBLIC_INCLUDE*/
        _include_type_48183 = 4LL;
        goto L1F; // [905] 918
L1E: 

        /** symtab.e:910										include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_48183 = 6LL;
L1F: 
    ;}L1D: 

    /** symtab.e:914							good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24847 = (object)*(((s1_ptr)_2)->base + _file_no_47978);
    _2 = (object)SEQ_PTR(_24847);
    _24848 = (object)*(((s1_ptr)_2)->base + _tok_file_48166);
    _24847 = NOVALUE;
    if (IS_ATOM_INT(_24848)) {
        {uintptr_t tu;
             tu = (uintptr_t)_include_type_48183 & (uintptr_t)_24848;
             _good_48173 = MAKE_UINT(tu);
        }
    }
    else {
        _good_48173 = binary_op(AND_BITS, _include_type_48183, _24848);
    }
    _24848 = NOVALUE;
    if (!IS_ATOM_INT(_good_48173)) {
        _1 = (object)(DBL_PTR(_good_48173)->dbl);
        DeRefDS(_good_48173);
        _good_48173 = _1;
    }
L19: 

    /** symtab.e:917						if good then*/
    if (_good_48173 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** symtab.e:919							if file_no = tok_file then*/
    if (_file_no_47978 != _tok_file_48166)
    goto L21; // [947] 971

    /** symtab.e:920								if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** symtab.e:921									add_ref(tok)*/
    Ref(_tok_47994);
    _54add_ref(_tok_47994);
L22: 

    /** symtab.e:923								return tok*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_gtok_47995);
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    _24832 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _tok_47994;
L21: 

    /** symtab.e:926							gtok = tok*/
    Ref(_tok_47994);
    DeRef(_gtok_47995);
    _gtok_47995 = _tok_47994;

    /** symtab.e:927							dup_globals &= st_ptr*/
    Append(&_54dup_globals_47963, _54dup_globals_47963, _st_ptr_47991);

    /** symtab.e:928							in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (object)SEQ_PTR(_37include_matrix_15413);
    _24852 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
    _2 = (object)SEQ_PTR(_24852);
    _24853 = (object)*(((s1_ptr)_2)->base + _tok_file_48166);
    _24852 = NOVALUE;
    if (IS_ATOM_INT(_24853)) {
        _24854 = (_24853 != 0LL);
    }
    else {
        _24854 = binary_op(NOTEQ, _24853, 0LL);
    }
    _24853 = NOVALUE;
    if (IS_SEQUENCE(_54in_include_path_47965) && IS_ATOM(_24854)) {
        Ref(_24854);
        Append(&_54in_include_path_47965, _54in_include_path_47965, _24854);
    }
    else if (IS_ATOM(_54in_include_path_47965) && IS_SEQUENCE(_24854)) {
    }
    else {
        Concat((object_ptr)&_54in_include_path_47965, _54in_include_path_47965, _24854);
    }
    DeRef(_24854);
    _24854 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** symtab.e:936			st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24856 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24856);
    _st_ptr_47991 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_st_ptr_47991)){
        _st_ptr_47991 = (object)DBL_PTR(_st_ptr_47991)->dbl;
    }
    _24856 = NOVALUE;

    /** symtab.e:937		end while*/
    goto L1; // [1030] 69
L2: 

    /** symtab.e:939		if length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_47964)){
            _24858 = SEQ_PTR(_54dup_overrides_47964)->length;
    }
    else {
        _24858 = 1;
    }
    if (_24858 == 0)
    {
        _24858 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24858 = NOVALUE;
    }

    /** symtab.e:940			st_ptr = dup_overrides[1]*/
    _2 = (object)SEQ_PTR(_54dup_overrides_47964);
    _st_ptr_47991 = (object)*(((s1_ptr)_2)->base + 1LL);

    /** symtab.e:941			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24860 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24860);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _24861 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _24861 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _24860 = NOVALUE;
    Ref(_24861);
    DeRef(_tok_47994);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24861;
    ((intptr_t *)_2)[2] = _st_ptr_47991;
    _tok_47994 = MAKE_SEQ(_1);
    _24861 = NOVALUE;

    /** symtab.e:944				if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** symtab.e:945					add_ref(tok)*/
    RefDS(_tok_47994);
    _54add_ref(_tok_47994);
L24: 

    /** symtab.e:948				return tok*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_gtok_47995);
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    _24832 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _tok_47994;
    goto L25; // [1090] 1320
L23: 

    /** symtab.e:951		elsif st_builtin != 0 then*/
    if (_st_builtin_47992 == 0LL)
    goto L26; // [1095] 1319

    /** symtab.e:952			if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24864 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24864 = 1;
    }
    if (_24864 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24866 = (object)*(((s1_ptr)_2)->base + _st_builtin_47992);
    _2 = (object)SEQ_PTR(_24866);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _24867 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _24867 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _24866 = NOVALUE;
    _24868 = find_from(_24867, _54builtin_warnings_47967, 1LL);
    _24867 = NOVALUE;
    _24869 = (_24868 == 0LL);
    _24868 = NOVALUE;
    if (_24869 == 0)
    {
        DeRef(_24869);
        _24869 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24869);
        _24869 = NOVALUE;
    }

    /** symtab.e:953				sequence msg_file */

    /** symtab.e:955				b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24870 = (object)*(((s1_ptr)_2)->base + _st_builtin_47992);
    DeRef(_b_name_47986);
    _2 = (object)SEQ_PTR(_24870);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _b_name_47986 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _b_name_47986 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_b_name_47986);
    _24870 = NOVALUE;

    /** symtab.e:956				builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_47986);
    Append(&_54builtin_warnings_47967, _54builtin_warnings_47967, _b_name_47986);

    /** symtab.e:958				if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24873 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24873 = 1;
    }
    if (_24873 <= 1LL)
    goto L28; // [1170] 1184

    /** symtab.e:959					msg = "\n"*/
    RefDS(_22188);
    DeRef(_msg_47985);
    _msg_47985 = _22188;
    goto L29; // [1181] 1192
L28: 

    /** symtab.e:961					msg = ""*/
    RefDS(_21993);
    DeRef(_msg_47985);
    _msg_47985 = _21993;
L29: 

    /** symtab.e:964				for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24875 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24875 = 1;
    }
    {
        object _i_48250;
        _i_48250 = 1LL;
L2A: 
        if (_i_48250 > _24875){
            goto L2B; // [1199] 1255
        }

        /** symtab.e:965					msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (object)SEQ_PTR(_54dup_globals_47963);
        _24876 = (object)*(((s1_ptr)_2)->base + _i_48250);
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        if (!IS_ATOM_INT(_24876)){
            _24877 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24876)->dbl));
        }
        else{
            _24877 = (object)*(((s1_ptr)_2)->base + _24876);
        }
        _2 = (object)SEQ_PTR(_24877);
        if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
            _24878 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
        }
        else{
            _24878 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
        }
        _24877 = NOVALUE;
        DeRef(_msg_file_48239);
        _2 = (object)SEQ_PTR(_37known_files_15407);
        if (!IS_ATOM_INT(_24878)){
            _msg_file_48239 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24878)->dbl));
        }
        else{
            _msg_file_48239 = (object)*(((s1_ptr)_2)->base + _24878);
        }
        Ref(_msg_file_48239);

        /** symtab.e:966					msg &= "    " & msg_file & "\n"*/
        {
            object concat_list[3];

            concat_list[0] = _22188;
            concat_list[1] = _msg_file_48239;
            concat_list[2] = _24880;
            Concat_N((object_ptr)&_24881, concat_list, 3);
        }
        Concat((object_ptr)&_msg_47985, _msg_47985, _24881);
        DeRefDS(_24881);
        _24881 = NOVALUE;

        /** symtab.e:967				end for*/
        _i_48250 = _i_48250 + 1LL;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** symtab.e:969				Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _24883 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_b_name_47986);
    ((intptr_t*)_2)[1] = _b_name_47986;
    Ref(_24883);
    ((intptr_t*)_2)[2] = _24883;
    RefDS(_msg_47985);
    ((intptr_t*)_2)[3] = _msg_47985;
    _24884 = MAKE_SEQ(_1);
    _24883 = NOVALUE;
    _50Warning(234LL, 8LL, _24884);
    _24884 = NOVALUE;
L27: 
    DeRef(_msg_file_48239);
    _msg_file_48239 = NOVALUE;

    /** symtab.e:972			tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24885 = (object)*(((s1_ptr)_2)->base + _st_builtin_47992);
    _2 = (object)SEQ_PTR(_24885);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _24886 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _24886 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _24885 = NOVALUE;
    Ref(_24886);
    DeRef(_tok_47994);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24886;
    ((intptr_t *)_2)[2] = _st_builtin_47992;
    _tok_47994 = MAKE_SEQ(_1);
    _24886 = NOVALUE;

    /** symtab.e:974			if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** symtab.e:975				add_ref(tok)*/
    RefDS(_tok_47994);
    _54add_ref(_tok_47994);
L2C: 

    /** symtab.e:978			return tok*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_gtok_47995);
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24876 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    _24832 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _tok_47994;
L26: 
L25: 

    /** symtab.e:981	ifdef STDDEBUG then*/

    /** symtab.e:996		if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24888 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24888 = 1;
    }
    _24889 = (_24888 > 1LL);
    _24888 = NOVALUE;
    if (_24889 == 0) {
        goto L2D; // [1333] 1452
    }
    _24891 = find_from(1LL, _54in_include_path_47965, 1LL);
    if (_24891 == 0)
    {
        _24891 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24891 = NOVALUE;
    }

    /** symtab.e:998			ix = 1*/
    _ix_47989 = 1LL;

    /** symtab.e:999			while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24892 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24892 = 1;
    }
    if (_ix_47989 > _24892)
    goto L2F; // [1363] 1411

    /** symtab.e:1000				if in_include_path[ix] then*/
    _2 = (object)SEQ_PTR(_54in_include_path_47965);
    _24894 = (object)*(((s1_ptr)_2)->base + _ix_47989);
    if (_24894 == 0) {
        _24894 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24894) && DBL_PTR(_24894)->dbl == 0.0){
            _24894 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24894 = NOVALUE;
    }
    _24894 = NOVALUE;

    /** symtab.e:1001					ix += 1*/
    _ix_47989 = _ix_47989 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** symtab.e:1003					dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54dup_globals_47963);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47989)) ? _ix_47989 : (object)(DBL_PTR(_ix_47989)->dbl);
        int stop = (IS_ATOM_INT(_ix_47989)) ? _ix_47989 : (object)(DBL_PTR(_ix_47989)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54dup_globals_47963), start, &_54dup_globals_47963 );
            }
            else Tail(SEQ_PTR(_54dup_globals_47963), stop+1, &_54dup_globals_47963);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54dup_globals_47963), start, &_54dup_globals_47963);
        }
        else {
            assign_slice_seq = &assign_space;
            _54dup_globals_47963 = Remove_elements(start, stop, (SEQ_PTR(_54dup_globals_47963)->ref == 1));
        }
    }

    /** symtab.e:1004					in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_54in_include_path_47965);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_47989)) ? _ix_47989 : (object)(DBL_PTR(_ix_47989)->dbl);
        int stop = (IS_ATOM_INT(_ix_47989)) ? _ix_47989 : (object)(DBL_PTR(_ix_47989)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<1) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_54in_include_path_47965), start, &_54in_include_path_47965 );
            }
            else Tail(SEQ_PTR(_54in_include_path_47965), stop+1, &_54in_include_path_47965);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_54in_include_path_47965), start, &_54in_include_path_47965);
        }
        else {
            assign_slice_seq = &assign_space;
            _54in_include_path_47965 = Remove_elements(start, stop, (SEQ_PTR(_54in_include_path_47965)->ref == 1));
        }
    }

    /** symtab.e:1006			end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** symtab.e:1008			if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24898 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24898 = 1;
    }
    if (_24898 != 1LL)
    goto L31; // [1418] 1451

    /** symtab.e:1009					st_ptr = dup_globals[1]*/
    _2 = (object)SEQ_PTR(_54dup_globals_47963);
    _st_ptr_47991 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (!IS_ATOM_INT(_st_ptr_47991)){
        _st_ptr_47991 = (object)DBL_PTR(_st_ptr_47991)->dbl;
    }

    /** symtab.e:1010					gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24901 = (object)*(((s1_ptr)_2)->base + _st_ptr_47991);
    _2 = (object)SEQ_PTR(_24901);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _24902 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _24902 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _24901 = NOVALUE;
    Ref(_24902);
    DeRef(_gtok_47995);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _24902;
    ((intptr_t *)_2)[2] = _st_ptr_47991;
    _gtok_47995 = MAKE_SEQ(_1);
    _24902 = NOVALUE;
L31: 
L2D: 

    /** symtab.e:1014	ifdef STDDEBUG then*/

    /** symtab.e:1023		if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24904 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24904 = 1;
    }
    _24905 = (_24904 == 1LL);
    _24904 = NOVALUE;
    if (_24905 == 0) {
        goto L32; // [1465] 1644
    }
    _24907 = (_st_builtin_47992 == 0LL);
    if (_24907 == 0)
    {
        DeRef(_24907);
        _24907 = NOVALUE;
        goto L32; // [1474] 1644
    }
    else{
        DeRef(_24907);
        _24907 = NOVALUE;
    }

    /** symtab.e:1026			if BIND then*/
    if (_36BIND_21044 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** symtab.e:1027				add_ref(gtok)*/
    Ref(_gtok_47995);
    _54add_ref(_gtok_47995);
L33: 

    /** symtab.e:1029			if not in_include_path[1] and*/
    _2 = (object)SEQ_PTR(_54in_include_path_47965);
    _24908 = (object)*(((s1_ptr)_2)->base + 1LL);
    if (IS_ATOM_INT(_24908)) {
        _24909 = (_24908 == 0);
    }
    else {
        _24909 = unary_op(NOT, _24908);
    }
    _24908 = NOVALUE;
    if (IS_ATOM_INT(_24909)) {
        if (_24909 == 0) {
            goto L34; // [1503] 1637
        }
    }
    else {
        if (DBL_PTR(_24909)->dbl == 0.0) {
            goto L34; // [1503] 1637
        }
    }
    _2 = (object)SEQ_PTR(_gtok_47995);
    _24911 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24911)){
        _24912 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24911)->dbl));
    }
    else{
        _24912 = (object)*(((s1_ptr)_2)->base + _24911);
    }
    _2 = (object)SEQ_PTR(_24912);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _24913 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _24913 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _24912 = NOVALUE;
    Ref(_24913);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_47979;
    ((intptr_t *)_2)[2] = _24913;
    _24914 = MAKE_SEQ(_1);
    _24913 = NOVALUE;
    _24915 = find_from(_24914, _54include_warnings_47966, 1LL);
    DeRefDS(_24914);
    _24914 = NOVALUE;
    _24916 = (_24915 == 0);
    _24915 = NOVALUE;
    if (_24916 == 0)
    {
        DeRef(_24916);
        _24916 = NOVALUE;
        goto L34; // [1542] 1637
    }
    else{
        DeRef(_24916);
        _24916 = NOVALUE;
    }

    /** symtab.e:1032				include_warnings = prepend( include_warnings,*/
    _2 = (object)SEQ_PTR(_gtok_47995);
    _24917 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24917)){
        _24918 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24917)->dbl));
    }
    else{
        _24918 = (object)*(((s1_ptr)_2)->base + _24917);
    }
    _2 = (object)SEQ_PTR(_24918);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _24919 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _24919 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _24918 = NOVALUE;
    Ref(_24919);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _scanning_file_47979;
    ((intptr_t *)_2)[2] = _24919;
    _24920 = MAKE_SEQ(_1);
    _24919 = NOVALUE;
    RefDS(_24920);
    Prepend(&_54include_warnings_47966, _54include_warnings_47966, _24920);
    DeRefDS(_24920);
    _24920 = NOVALUE;

    /** symtab.e:1034	ifdef STDDEBUG then*/

    /** symtab.e:1040					symbol_resolution_warning = GetMsgText(MSG_12__IDENTIFIER_3_IN_4_IS_NOT_INCLUDED,0,*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _24922 = (object)*(((s1_ptr)_2)->base + _scanning_file_47979);
    Ref(_24922);
    _24923 = _54name_ext(_24922);
    _24922 = NOVALUE;
    _2 = (object)SEQ_PTR(_gtok_47995);
    _24924 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!IS_ATOM_INT(_24924)){
        _24925 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24924)->dbl));
    }
    else{
        _24925 = (object)*(((s1_ptr)_2)->base + _24924);
    }
    _2 = (object)SEQ_PTR(_24925);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _24926 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _24926 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _24925 = NOVALUE;
    _2 = (object)SEQ_PTR(_37known_files_15407);
    if (!IS_ATOM_INT(_24926)){
        _24927 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24926)->dbl));
    }
    else{
        _24927 = (object)*(((s1_ptr)_2)->base + _24926);
    }
    Ref(_24927);
    _24928 = _54name_ext(_24927);
    _24927 = NOVALUE;
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = _24923;
    ((intptr_t*)_2)[2] = _36line_number_21440;
    RefDS(_word_47977);
    ((intptr_t*)_2)[3] = _word_47977;
    ((intptr_t*)_2)[4] = _24928;
    _24929 = MAKE_SEQ(_1);
    _24928 = NOVALUE;
    _24923 = NOVALUE;
    _0 = _39GetMsgText(233LL, 0LL, _24929);
    DeRef(_36symbol_resolution_warning_21544);
    _36symbol_resolution_warning_21544 = _0;
    _24929 = NOVALUE;
L34: 

    /** symtab.e:1047			return gtok*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_tok_47994);
    _24917 = NOVALUE;
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24924 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24876 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24832 = NOVALUE;
    _24911 = NOVALUE;
    DeRef(_24889);
    _24889 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    _24926 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _gtok_47995;
L32: 

    /** symtab.e:1051		if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24931 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24931 = 1;
    }
    if (_24931 != 0LL)
    goto L35; // [1651] 1725

    /** symtab.e:1052			defined = SC_UNDEFINED*/
    _defined_47988 = 9LL;

    /** symtab.e:1054			if fwd_line_number then*/
    if (_36fwd_line_number_21441 == 0)
    {
        goto L36; // [1668] 1697
    }
    else{
    }

    /** symtab.e:1055				last_ForwardLine     = ForwardLine*/
    Ref(_50ForwardLine_49235);
    DeRef(_50last_ForwardLine_49237);
    _50last_ForwardLine_49237 = _50ForwardLine_49235;

    /** symtab.e:1056				last_forward_bp      = forward_bp*/
    _50last_forward_bp_49241 = _50forward_bp_49239;

    /** symtab.e:1057				last_fwd_line_number = fwd_line_number*/
    _36last_fwd_line_number_21443 = _36fwd_line_number_21441;
L36: 

    /** symtab.e:1060			ForwardLine = ThisLine*/
    Ref(_50ThisLine_49234);
    DeRef(_50ForwardLine_49235);
    _50ForwardLine_49235 = _50ThisLine_49234;

    /** symtab.e:1061			forward_bp = bp*/
    _50forward_bp_49239 = _50bp_49238;

    /** symtab.e:1062			fwd_line_number = line_number*/
    _36fwd_line_number_21441 = _36line_number_21440;
    goto L37; // [1722] 1768
L35: 

    /** symtab.e:1064		elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_54dup_globals_47963)){
            _24933 = SEQ_PTR(_54dup_globals_47963)->length;
    }
    else {
        _24933 = 1;
    }
    if (_24933 == 0)
    {
        _24933 = NOVALUE;
        goto L38; // [1732] 1747
    }
    else{
        _24933 = NOVALUE;
    }

    /** symtab.e:1065			defined = SC_MULTIPLY_DEFINED*/
    _defined_47988 = 10LL;
    goto L37; // [1744] 1768
L38: 

    /** symtab.e:1066		elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_54dup_overrides_47964)){
            _24934 = SEQ_PTR(_54dup_overrides_47964)->length;
    }
    else {
        _24934 = 1;
    }
    if (_24934 == 0)
    {
        _24934 = NOVALUE;
        goto L39; // [1754] 1767
    }
    else{
        _24934 = NOVALUE;
    }

    /** symtab.e:1067			defined = SC_OVERRIDE*/
    _defined_47988 = 12LL;
L39: 
L37: 

    /** symtab.e:1070		if No_new_entry then*/
    if (_54No_new_entry_47974 == 0)
    {
        goto L3A; // [1772] 1795
    }
    else{
    }

    /** symtab.e:1071			return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t*)_2)[1] = 509LL;
    RefDS(_word_47977);
    ((intptr_t*)_2)[2] = _word_47977;
    ((intptr_t*)_2)[3] = _defined_47988;
    RefDS(_54dup_globals_47963);
    ((intptr_t*)_2)[4] = _54dup_globals_47963;
    _24935 = MAKE_SEQ(_1);
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_tok_47994);
    DeRef(_gtok_47995);
    _24917 = NOVALUE;
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24924 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24876 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24832 = NOVALUE;
    _24911 = NOVALUE;
    DeRef(_24889);
    _24889 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    _24819 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    _24926 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _24935;
L3A: 

    /** symtab.e:1074		tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _24936 = (object)*(((s1_ptr)_2)->base + _hashval_47983);
    RefDS(_word_47977);
    Ref(_24936);
    _24937 = _54NewEntry(_word_47977, 0LL, _defined_47988, -100LL, _hashval_47983, _24936, 0LL);
    _24936 = NOVALUE;
    DeRef(_tok_47994);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = -100LL;
    ((intptr_t *)_2)[2] = _24937;
    _tok_47994 = MAKE_SEQ(_1);
    _24937 = NOVALUE;

    /** symtab.e:1076		buckets[hashval] = tok[T_SYM]*/
    _2 = (object)SEQ_PTR(_tok_47994);
    _24939 = (object)*(((s1_ptr)_2)->base + 2LL);
    Ref(_24939);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    _2 = (object)(((s1_ptr)_2)->base + _hashval_47983);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24939;
    if( _1 != _24939 ){
        DeRef(_1);
    }
    _24939 = NOVALUE;

    /** symtab.e:1078		if file_no != -1 then*/
    if (_file_no_47978 == -1LL)
    goto L3B; // [1839] 1865

    /** symtab.e:1079			SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (object)SEQ_PTR(_tok_47994);
    _24941 = (object)*(((s1_ptr)_2)->base + 2LL);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24941))
    _3 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24941)->dbl));
    else
    _3 = (object)(_24941 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_36S_FILE_NO_21072))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _file_no_47978;
    DeRef(_1);
    _24942 = NOVALUE;
L3B: 

    /** symtab.e:1081		return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_47977);
    DeRef(_msg_47985);
    DeRef(_b_name_47986);
    DeRef(_gtok_47995);
    _24917 = NOVALUE;
    DeRef(_24766);
    _24766 = NOVALUE;
    DeRef(_24815);
    _24815 = NOVALUE;
    DeRef(_24807);
    _24807 = NOVALUE;
    _24924 = NOVALUE;
    DeRef(_24909);
    _24909 = NOVALUE;
    _24876 = NOVALUE;
    _24825 = NOVALUE;
    _24811 = NOVALUE;
    _24793 = NOVALUE;
    DeRef(_24905);
    _24905 = NOVALUE;
    _24832 = NOVALUE;
    _24911 = NOVALUE;
    DeRef(_24889);
    _24889 = NOVALUE;
    DeRef(_24813);
    _24813 = NOVALUE;
    DeRef(_24935);
    _24935 = NOVALUE;
    _24819 = NOVALUE;
    _24878 = NOVALUE;
    DeRef(_24756);
    _24756 = NOVALUE;
    _24785 = NOVALUE;
    DeRef(_24821);
    _24821 = NOVALUE;
    _24926 = NOVALUE;
    DeRef(_24840);
    _24840 = NOVALUE;
    _24784 = NOVALUE;
    _24800 = NOVALUE;
    _24837 = NOVALUE;
    _24941 = NOVALUE;
    _24780 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return _tok_47994;
    ;
}


void _54Hide(object _s_48388)
{
    object _prev_48390 = NOVALUE;
    object _p_48391 = NOVALUE;
    object _24962 = NOVALUE;
    object _24961 = NOVALUE;
    object _24960 = NOVALUE;
    object _24958 = NOVALUE;
    object _24957 = NOVALUE;
    object _24956 = NOVALUE;
    object _24955 = NOVALUE;
    object _24954 = NOVALUE;
    object _24950 = NOVALUE;
    object _24949 = NOVALUE;
    object _24948 = NOVALUE;
    object _24947 = NOVALUE;
    object _24945 = NOVALUE;
    object _24944 = NOVALUE;
    object _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_48388)) {
        _1 = (object)(DBL_PTR(_s_48388)->dbl);
        DeRefDS(_s_48388);
        _s_48388 = _1;
    }

    /** symtab.e:1090		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24944 = (object)*(((s1_ptr)_2)->base + _s_48388);
    _2 = (object)SEQ_PTR(_24944);
    _24945 = (object)*(((s1_ptr)_2)->base + 11LL);
    _24944 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_24945)){
        _p_48391 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24945)->dbl));
    }
    else{
        _p_48391 = (object)*(((s1_ptr)_2)->base + _24945);
    }
    if (!IS_ATOM_INT(_p_48391)){
        _p_48391 = (object)DBL_PTR(_p_48391)->dbl;
    }

    /** symtab.e:1091		prev = 0*/
    _prev_48390 = 0LL;

    /** symtab.e:1093		while p != s and p != 0 do*/
L1: 
    _24947 = (_p_48391 != _s_48388);
    if (_24947 == 0) {
        goto L2; // [41] 81
    }
    _24949 = (_p_48391 != 0LL);
    if (_24949 == 0)
    {
        DeRef(_24949);
        _24949 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_24949);
        _24949 = NOVALUE;
    }

    /** symtab.e:1094			prev = p*/
    _prev_48390 = _p_48391;

    /** symtab.e:1095			p = SymTab[p][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24950 = (object)*(((s1_ptr)_2)->base + _p_48391);
    _2 = (object)SEQ_PTR(_24950);
    _p_48391 = (object)*(((s1_ptr)_2)->base + 9LL);
    if (!IS_ATOM_INT(_p_48391)){
        _p_48391 = (object)DBL_PTR(_p_48391)->dbl;
    }
    _24950 = NOVALUE;

    /** symtab.e:1096		end while*/
    goto L1; // [78] 37
L2: 

    /** symtab.e:1098		if p = 0 then*/
    if (_p_48391 != 0LL)
    goto L3; // [83] 93

    /** symtab.e:1099			return -- already hidden*/
    _24945 = NOVALUE;
    DeRef(_24947);
    _24947 = NOVALUE;
    return;
L3: 

    /** symtab.e:1101		if prev = 0 then*/
    if (_prev_48390 != 0LL)
    goto L4; // [95] 134

    /** symtab.e:1102			buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24954 = (object)*(((s1_ptr)_2)->base + _s_48388);
    _2 = (object)SEQ_PTR(_24954);
    _24955 = (object)*(((s1_ptr)_2)->base + 11LL);
    _24954 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24956 = (object)*(((s1_ptr)_2)->base + _s_48388);
    _2 = (object)SEQ_PTR(_24956);
    _24957 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24956 = NOVALUE;
    Ref(_24957);
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_24955))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24955)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24955);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24957;
    if( _1 != _24957 ){
        DeRef(_1);
    }
    _24957 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** symtab.e:1104			SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_prev_48390 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24960 = (object)*(((s1_ptr)_2)->base + _s_48388);
    _2 = (object)SEQ_PTR(_24960);
    _24961 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24960 = NOVALUE;
    Ref(_24961);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _24961;
    if( _1 != _24961 ){
        DeRef(_1);
    }
    _24961 = NOVALUE;
    _24958 = NOVALUE;
L5: 

    /** symtab.e:1106		SymTab[s][S_SAMEHASH] = 0*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48388 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = 0LL;
    DeRef(_1);
    _24962 = NOVALUE;

    /** symtab.e:1107	end procedure*/
    _24955 = NOVALUE;
    _24945 = NOVALUE;
    DeRef(_24947);
    _24947 = NOVALUE;
    return;
    ;
}


void _54Show(object _s_48433)
{
    object _p_48435 = NOVALUE;
    object _24974 = NOVALUE;
    object _24973 = NOVALUE;
    object _24971 = NOVALUE;
    object _24970 = NOVALUE;
    object _24968 = NOVALUE;
    object _24967 = NOVALUE;
    object _24965 = NOVALUE;
    object _24964 = NOVALUE;
    object _0, _1, _2, _3;
    

    /** symtab.e:1114		p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24964 = (object)*(((s1_ptr)_2)->base + _s_48433);
    _2 = (object)SEQ_PTR(_24964);
    _24965 = (object)*(((s1_ptr)_2)->base + 11LL);
    _24964 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_24965)){
        _p_48435 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_24965)->dbl));
    }
    else{
        _p_48435 = (object)*(((s1_ptr)_2)->base + _24965);
    }
    if (!IS_ATOM_INT(_p_48435)){
        _p_48435 = (object)DBL_PTR(_p_48435)->dbl;
    }

    /** symtab.e:1116		if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24967 = (object)*(((s1_ptr)_2)->base + _s_48433);
    _2 = (object)SEQ_PTR(_24967);
    _24968 = (object)*(((s1_ptr)_2)->base + 9LL);
    _24967 = NOVALUE;
    if (IS_ATOM_INT(_24968)) {
        if (_24968 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_24968)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _24970 = (_p_48435 == _s_48433);
    if (_24970 == 0)
    {
        DeRef(_24970);
        _24970 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_24970);
        _24970 = NOVALUE;
    }
L1: 

    /** symtab.e:1118			return*/
    _24965 = NOVALUE;
    _24968 = NOVALUE;
    return;
L2: 

    /** symtab.e:1121		SymTab[s][S_SAMEHASH] = p*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        _37SymTab_15406 = MAKE_SEQ(_2);
    }
    _3 = (object)(_s_48433 + ((s1_ptr)_2)->base);
    _2 = (object)SEQ_PTR(*(intptr_t *)_3);
    if (!UNIQUE(_2)) {
        _2 = (object)SequenceCopy((s1_ptr)_2);
        *(intptr_t *)_3 = MAKE_SEQ(_2);
    }
    _2 = (object)(((s1_ptr)_2)->base + 9LL);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _p_48435;
    DeRef(_1);
    _24971 = NOVALUE;

    /** symtab.e:1122		buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24973 = (object)*(((s1_ptr)_2)->base + _s_48433);
    _2 = (object)SEQ_PTR(_24973);
    _24974 = (object)*(((s1_ptr)_2)->base + 11LL);
    _24973 = NOVALUE;
    _2 = (object)SEQ_PTR(_54buckets_46772);
    if (!IS_ATOM_INT(_24974))
    _2 = (object)(((s1_ptr)_2)->base + (object)(DBL_PTR(_24974)->dbl));
    else
    _2 = (object)(((s1_ptr)_2)->base + _24974);
    _1 = *(intptr_t *)_2;
    *(intptr_t *)_2 = _s_48433;
    DeRef(_1);

    /** symtab.e:1124	end procedure*/
    _24965 = NOVALUE;
    _24968 = NOVALUE;
    _24974 = NOVALUE;
    return;
    ;
}


void _54hide_params(object _s_48459)
{
    object _param_48461 = NOVALUE;
    object _24977 = NOVALUE;
    object _24976 = NOVALUE;
    object _24975 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1127		symtab_index param = s*/
    _param_48461 = _s_48459;

    /** symtab.e:1128		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24975 = (object)*(((s1_ptr)_2)->base + _s_48459);
    _2 = (object)SEQ_PTR(_24975);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _24976 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _24976 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _24975 = NOVALUE;
    {
        object _i_48463;
        _i_48463 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48463, _24976)){
            goto L2; // [24] 59
        }

        /** symtab.e:1129			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24977 = (object)*(((s1_ptr)_2)->base + _s_48459);
        _2 = (object)SEQ_PTR(_24977);
        _param_48461 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48461)){
            _param_48461 = (object)DBL_PTR(_param_48461)->dbl;
        }
        _24977 = NOVALUE;

        /** symtab.e:1130			Hide( param )*/
        _54Hide(_param_48461);

        /** symtab.e:1131		end for*/
        _0 = _i_48463;
        if (IS_ATOM_INT(_i_48463)) {
            _i_48463 = _i_48463 + 1LL;
            if ((object)((uintptr_t)_i_48463 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48463 = NewDouble((eudouble)_i_48463);
            }
        }
        else {
            _i_48463 = binary_op_a(PLUS, _i_48463, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48463);
    }

    /** symtab.e:1132	end procedure*/
    _24976 = NOVALUE;
    return;
    ;
}


void _54show_params(object _s_48475)
{
    object _param_48477 = NOVALUE;
    object _24981 = NOVALUE;
    object _24980 = NOVALUE;
    object _24979 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1135		symtab_index param = s*/
    _param_48477 = _s_48475;

    /** symtab.e:1136		for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24979 = (object)*(((s1_ptr)_2)->base + _s_48475);
    _2 = (object)SEQ_PTR(_24979);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _24980 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _24980 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _24979 = NOVALUE;
    {
        object _i_48479;
        _i_48479 = 1LL;
L1: 
        if (binary_op_a(GREATER, _i_48479, _24980)){
            goto L2; // [24] 59
        }

        /** symtab.e:1137			param = SymTab[s][S_NEXT]*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24981 = (object)*(((s1_ptr)_2)->base + _s_48475);
        _2 = (object)SEQ_PTR(_24981);
        _param_48477 = (object)*(((s1_ptr)_2)->base + 2LL);
        if (!IS_ATOM_INT(_param_48477)){
            _param_48477 = (object)DBL_PTR(_param_48477)->dbl;
        }
        _24981 = NOVALUE;

        /** symtab.e:1138			Show( param )*/
        _54Show(_param_48477);

        /** symtab.e:1139		end for*/
        _0 = _i_48479;
        if (IS_ATOM_INT(_i_48479)) {
            _i_48479 = _i_48479 + 1LL;
            if ((object)((uintptr_t)_i_48479 +(uintptr_t) HIGH_BITS) >= 0){
                _i_48479 = NewDouble((eudouble)_i_48479);
            }
        }
        else {
            _i_48479 = binary_op_a(PLUS, _i_48479, 1LL);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_48479);
    }

    /** symtab.e:1140	end procedure*/
    _24980 = NOVALUE;
    return;
    ;
}


void _54LintCheck(object _s_48491)
{
    object _warn_level_48492 = NOVALUE;
    object _file_48493 = NOVALUE;
    object _vscope_48494 = NOVALUE;
    object _vname_48495 = NOVALUE;
    object _vusage_48496 = NOVALUE;
    object _25042 = NOVALUE;
    object _25041 = NOVALUE;
    object _25040 = NOVALUE;
    object _25039 = NOVALUE;
    object _25038 = NOVALUE;
    object _25037 = NOVALUE;
    object _25035 = NOVALUE;
    object _25034 = NOVALUE;
    object _25033 = NOVALUE;
    object _25032 = NOVALUE;
    object _25031 = NOVALUE;
    object _25030 = NOVALUE;
    object _25027 = NOVALUE;
    object _25026 = NOVALUE;
    object _25025 = NOVALUE;
    object _25024 = NOVALUE;
    object _25023 = NOVALUE;
    object _25022 = NOVALUE;
    object _25020 = NOVALUE;
    object _25018 = NOVALUE;
    object _25017 = NOVALUE;
    object _25015 = NOVALUE;
    object _25014 = NOVALUE;
    object _25012 = NOVALUE;
    object _25011 = NOVALUE;
    object _25010 = NOVALUE;
    object _25009 = NOVALUE;
    object _25007 = NOVALUE;
    object _25006 = NOVALUE;
    object _25002 = NOVALUE;
    object _24999 = NOVALUE;
    object _24998 = NOVALUE;
    object _24997 = NOVALUE;
    object _24996 = NOVALUE;
    object _24993 = NOVALUE;
    object _24992 = NOVALUE;
    object _24987 = NOVALUE;
    object _24985 = NOVALUE;
    object _24983 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_48491)) {
        _1 = (object)(DBL_PTR(_s_48491)->dbl);
        DeRefDS(_s_48491);
        _s_48491 = _1;
    }

    /** symtab.e:1150		vusage = SymTab[s][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24983 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_24983);
    _vusage_48496 = (object)*(((s1_ptr)_2)->base + 5LL);
    if (!IS_ATOM_INT(_vusage_48496)){
        _vusage_48496 = (object)DBL_PTR(_vusage_48496)->dbl;
    }
    _24983 = NOVALUE;

    /** symtab.e:1151		vscope = SymTab[s][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24985 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_24985);
    _vscope_48494 = (object)*(((s1_ptr)_2)->base + 4LL);
    if (!IS_ATOM_INT(_vscope_48494)){
        _vscope_48494 = (object)DBL_PTR(_vscope_48494)->dbl;
    }
    _24985 = NOVALUE;

    /** symtab.e:1152		vname = SymTab[s][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _24987 = (object)*(((s1_ptr)_2)->base + _s_48491);
    DeRef(_vname_48495);
    _2 = (object)SEQ_PTR(_24987);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _vname_48495 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _vname_48495 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    Ref(_vname_48495);
    _24987 = NOVALUE;

    /** symtab.e:1154		switch vusage do*/
    _0 = _vusage_48496;
    switch ( _0 ){ 

        /** symtab.e:1156			case U_UNUSED then*/
        case 0:

        /** symtab.e:1157				warn_level = 1*/
        _warn_level_48492 = 1LL;
        goto L1; // [67] 193

        /** symtab.e:1159			case U_WRITTEN then -- Set but never read*/
        case 2:

        /** symtab.e:1160				warn_level = 2*/
        _warn_level_48492 = 2LL;

        /** symtab.e:1162				if vscope > SC_LOCAL then*/
        if (_vscope_48494 <= 5LL)
        goto L2; // [82] 94

        /** symtab.e:1164					warn_level = 0 */
        _warn_level_48492 = 0LL;
        goto L1; // [91] 193
L2: 

        /** symtab.e:1166				elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24992 = (object)*(((s1_ptr)_2)->base + _s_48491);
        _2 = (object)SEQ_PTR(_24992);
        _24993 = (object)*(((s1_ptr)_2)->base + 3LL);
        _24992 = NOVALUE;
        if (binary_op_a(NOTEQ, _24993, 2LL)){
            _24993 = NOVALUE;
            goto L1; // [110] 193
        }
        _24993 = NOVALUE;

        /** symtab.e:1167					if not Strict_is_on then*/
        if (_36Strict_is_on_21508 != 0)
        goto L1; // [118] 193

        /** symtab.e:1170						warn_level = 0 */
        _warn_level_48492 = 0LL;
        goto L1; // [129] 193

        /** symtab.e:1174			case U_READ then -- Read but never set*/
        case 1:

        /** symtab.e:1175				if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24996 = (object)*(((s1_ptr)_2)->base + _s_48491);
        _2 = (object)SEQ_PTR(_24996);
        _24997 = (object)*(((s1_ptr)_2)->base + 16LL);
        _24996 = NOVALUE;
        _2 = (object)SEQ_PTR(_37SymTab_15406);
        _24998 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
        _2 = (object)SEQ_PTR(_24998);
        if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
            _24999 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
        }
        else{
            _24999 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
        }
        _24998 = NOVALUE;
        if (binary_op_a(LESS, _24997, _24999)){
            _24997 = NOVALUE;
            _24999 = NOVALUE;
            goto L3; // [163] 175
        }
        _24997 = NOVALUE;
        _24999 = NOVALUE;

        /** symtab.e:1176			    	warn_level = 3*/
        _warn_level_48492 = 3LL;
        goto L1; // [172] 193
L3: 

        /** symtab.e:1179			    	warn_level = 0*/
        _warn_level_48492 = 0LL;
        goto L1; // [181] 193

        /** symtab.e:1182		    case else*/
        default:

        /** symtab.e:1183		    	warn_level = 0*/
        _warn_level_48492 = 0LL;
    ;}L1: 

    /** symtab.e:1186		if warn_level = 0 then*/
    if (_warn_level_48492 != 0LL)
    goto L4; // [197] 207

    /** symtab.e:1187			return*/
    DeRef(_file_48493);
    DeRef(_vname_48495);
    return;
L4: 

    /** symtab.e:1191		file = abbreviate_path(known_files[current_file_no])*/
    _2 = (object)SEQ_PTR(_37known_files_15407);
    _25002 = (object)*(((s1_ptr)_2)->base + _36current_file_no_21439);
    Ref(_25002);
    RefDS(_21993);
    _0 = _file_48493;
    _file_48493 = _17abbreviate_path(_25002, _21993);
    DeRef(_0);
    _25002 = NOVALUE;

    /** symtab.e:1192		if warn_level = 3 then*/
    if (_warn_level_48492 != 3LL)
    goto L5; // [226] 308

    /** symtab.e:1193			if vscope = SC_LOCAL then*/
    if (_vscope_48494 != 5LL)
    goto L6; // [234] 275

    /** symtab.e:1194				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25006 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_25006);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _25007 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _25007 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _25006 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21439, _25007)){
        _25007 = NOVALUE;
        goto L7; // [254] 602
    }
    _25007 = NOVALUE;

    /** symtab.e:1195					Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_48495);
    RefDS(_file_48493);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48493;
    ((intptr_t *)_2)[2] = _vname_48495;
    _25009 = MAKE_SEQ(_1);
    _50Warning(226LL, 32LL, _25009);
    _25009 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** symtab.e:1198				Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25010 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25010);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25011 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25011 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25010 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48493);
    ((intptr_t*)_2)[1] = _file_48493;
    RefDS(_vname_48495);
    ((intptr_t*)_2)[2] = _vname_48495;
    Ref(_25011);
    ((intptr_t*)_2)[3] = _25011;
    _25012 = MAKE_SEQ(_1);
    _25011 = NOVALUE;
    _50Warning(227LL, 32LL, _25012);
    _25012 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** symtab.e:1201			if vscope = SC_LOCAL then*/
    if (_vscope_48494 != 5LL)
    goto L8; // [312] 412

    /** symtab.e:1202				if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25014 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_25014);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _25015 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _25015 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _25014 = NOVALUE;
    if (binary_op_a(NOTEQ, _36current_file_no_21439, _25015)){
        _25015 = NOVALUE;
        goto L9; // [332] 601
    }
    _25015 = NOVALUE;

    /** symtab.e:1203					if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25017 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_25017);
    _25018 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25017 = NOVALUE;
    if (binary_op_a(NOTEQ, _25018, 2LL)){
        _25018 = NOVALUE;
        goto LA; // [352] 372
    }
    _25018 = NOVALUE;

    /** symtab.e:1204						Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48495);
    RefDS(_file_48493);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48493;
    ((intptr_t *)_2)[2] = _vname_48495;
    _25020 = MAKE_SEQ(_1);
    _50Warning(228LL, 16LL, _25020);
    _25020 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** symtab.e:1206					elsif warn_level = 1 then*/
    if (_warn_level_48492 != 1LL)
    goto LB; // [374] 394

    /** symtab.e:1207						Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48495);
    RefDS(_file_48493);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48493;
    ((intptr_t *)_2)[2] = _vname_48495;
    _25022 = MAKE_SEQ(_1);
    _50Warning(229LL, 16LL, _25022);
    _25022 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** symtab.e:1210						Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_48495);
    RefDS(_file_48493);
    _1 = NewS1(2);
    _2 = (object)((s1_ptr)_1)->base;
    ((intptr_t *)_2)[1] = _file_48493;
    ((intptr_t *)_2)[2] = _vname_48495;
    _25023 = MAKE_SEQ(_1);
    _50Warning(320LL, 16LL, _25023);
    _25023 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** symtab.e:1214				if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25024 = (object)*(((s1_ptr)_2)->base + _s_48491);
    _2 = (object)SEQ_PTR(_25024);
    _25025 = (object)*(((s1_ptr)_2)->base + 16LL);
    _25024 = NOVALUE;
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25026 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25026);
    if (!IS_ATOM_INT(_36S_NUM_ARGS_21127)){
        _25027 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NUM_ARGS_21127)->dbl));
    }
    else{
        _25027 = (object)*(((s1_ptr)_2)->base + _36S_NUM_ARGS_21127);
    }
    _25026 = NOVALUE;
    if (binary_op_a(GREATEREQ, _25025, _25027)){
        _25025 = NOVALUE;
        _25027 = NOVALUE;
        goto LC; // [440] 523
    }
    _25025 = NOVALUE;
    _25027 = NOVALUE;

    /** symtab.e:1216					if warn_level = 1 then*/
    if (_warn_level_48492 != 1LL)
    goto LD; // [446] 490

    /** symtab.e:1217						if Strict_is_on then*/
    if (_36Strict_is_on_21508 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** symtab.e:1219							Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25030 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25030);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25031 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25031 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25030 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48493);
    ((intptr_t*)_2)[1] = _file_48493;
    RefDS(_vname_48495);
    ((intptr_t*)_2)[2] = _vname_48495;
    Ref(_25031);
    ((intptr_t*)_2)[3] = _25031;
    _25032 = MAKE_SEQ(_1);
    _25031 = NOVALUE;
    _50Warning(230LL, 16LL, _25032);
    _25032 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** symtab.e:1222						Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25033 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25033);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25034 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25034 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25033 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48493);
    ((intptr_t*)_2)[1] = _file_48493;
    RefDS(_vname_48495);
    ((intptr_t*)_2)[2] = _vname_48495;
    Ref(_25034);
    ((intptr_t*)_2)[3] = _25034;
    _25035 = MAKE_SEQ(_1);
    _25034 = NOVALUE;
    _50Warning(321LL, 16LL, _25035);
    _25035 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** symtab.e:1226					if warn_level = 1 then*/
    if (_warn_level_48492 != 1LL)
    goto LF; // [525] 569

    /** symtab.e:1227						if Strict_is_on then*/
    if (_36Strict_is_on_21508 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** symtab.e:1229							Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25037 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25037);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25038 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25038 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25037 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48493);
    ((intptr_t*)_2)[1] = _file_48493;
    RefDS(_vname_48495);
    ((intptr_t*)_2)[2] = _vname_48495;
    Ref(_25038);
    ((intptr_t*)_2)[3] = _25038;
    _25039 = MAKE_SEQ(_1);
    _25038 = NOVALUE;
    _50Warning(231LL, 16LL, _25039);
    _25039 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** symtab.e:1232						Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25040 = (object)*(((s1_ptr)_2)->base + _36CurrentSub_21447);
    _2 = (object)SEQ_PTR(_25040);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25041 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25041 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25040 = NOVALUE;
    _1 = NewS1(3);
    _2 = (object)((s1_ptr)_1)->base;
    RefDS(_file_48493);
    ((intptr_t*)_2)[1] = _file_48493;
    RefDS(_vname_48495);
    ((intptr_t*)_2)[2] = _vname_48495;
    Ref(_25041);
    ((intptr_t*)_2)[3] = _25041;
    _25042 = MAKE_SEQ(_1);
    _25041 = NOVALUE;
    _50Warning(322LL, 16LL, _25042);
    _25042 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** symtab.e:1238	end procedure*/
    DeRef(_file_48493);
    DeRef(_vname_48495);
    return;
    ;
}


void _54HideLocals()
{
    object _s_48662 = NOVALUE;
    object _25055 = NOVALUE;
    object _25053 = NOVALUE;
    object _25052 = NOVALUE;
    object _25051 = NOVALUE;
    object _25050 = NOVALUE;
    object _25049 = NOVALUE;
    object _25048 = NOVALUE;
    object _25047 = NOVALUE;
    object _25046 = NOVALUE;
    object _25045 = NOVALUE;
    object _25044 = NOVALUE;
    object _25043 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1244		mark_rechecks()*/
    _54mark_rechecks(_36current_file_no_21439);

    /** symtab.e:1245		s = file_start_sym*/
    _s_48662 = _36file_start_sym_21445;

    /** symtab.e:1246		while s do*/
L1: 
    if (_s_48662 == 0)
    {
        goto L2; // [22] 148
    }
    else{
    }

    /** symtab.e:1247			if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25043 = (object)*(((s1_ptr)_2)->base + _s_48662);
    _2 = (object)SEQ_PTR(_25043);
    _25044 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25043 = NOVALUE;
    if (IS_ATOM_INT(_25044)) {
        _25045 = (_25044 == 5LL);
    }
    else {
        _25045 = binary_op(EQUALS, _25044, 5LL);
    }
    _25044 = NOVALUE;
    if (IS_ATOM_INT(_25045)) {
        if (_25045 == 0) {
            goto L3; // [45] 127
        }
    }
    else {
        if (DBL_PTR(_25045)->dbl == 0.0) {
            goto L3; // [45] 127
        }
    }
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25047 = (object)*(((s1_ptr)_2)->base + _s_48662);
    _2 = (object)SEQ_PTR(_25047);
    if (!IS_ATOM_INT(_36S_FILE_NO_21072)){
        _25048 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_FILE_NO_21072)->dbl));
    }
    else{
        _25048 = (object)*(((s1_ptr)_2)->base + _36S_FILE_NO_21072);
    }
    _25047 = NOVALUE;
    if (IS_ATOM_INT(_25048)) {
        _25049 = (_25048 == _36current_file_no_21439);
    }
    else {
        _25049 = binary_op(EQUALS, _25048, _36current_file_no_21439);
    }
    _25048 = NOVALUE;
    if (_25049 == 0) {
        DeRef(_25049);
        _25049 = NOVALUE;
        goto L3; // [68] 127
    }
    else {
        if (!IS_ATOM_INT(_25049) && DBL_PTR(_25049)->dbl == 0.0){
            DeRef(_25049);
            _25049 = NOVALUE;
            goto L3; // [68] 127
        }
        DeRef(_25049);
        _25049 = NOVALUE;
    }
    DeRef(_25049);
    _25049 = NOVALUE;

    /** symtab.e:1249			   	if current_block = top_level_block and repl then*/
    _25050 = (_65current_block_25114 == _65top_level_block_25115);
    if (_25050 == 0) {
        goto L4; // [81] 94
    }
    goto L4; // [88] 94
    goto L5; // [91] 100
L4: 

    /** symtab.e:1251				Hide(s)*/
    _54Hide(_s_48662);
L5: 

    /** symtab.e:1253				if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25052 = (object)*(((s1_ptr)_2)->base + _s_48662);
    _2 = (object)SEQ_PTR(_25052);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _25053 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _25053 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _25052 = NOVALUE;
    if (binary_op_a(NOTEQ, _25053, -100LL)){
        _25053 = NOVALUE;
        goto L6; // [116] 126
    }
    _25053 = NOVALUE;

    /** symtab.e:1254					LintCheck(s)*/
    _54LintCheck(_s_48662);
L6: 
L3: 

    /** symtab.e:1257			s = SymTab[s][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25055 = (object)*(((s1_ptr)_2)->base + _s_48662);
    _2 = (object)SEQ_PTR(_25055);
    _s_48662 = (object)*(((s1_ptr)_2)->base + 2LL);
    if (!IS_ATOM_INT(_s_48662)){
        _s_48662 = (object)DBL_PTR(_s_48662)->dbl;
    }
    _25055 = NOVALUE;

    /** symtab.e:1258		end while*/
    goto L1; // [145] 22
L2: 

    /** symtab.e:1259	end procedure*/
    DeRef(_25050);
    _25050 = NOVALUE;
    DeRef(_25045);
    _25045 = NOVALUE;
    return;
    ;
}


object _54sym_name(object _sym_48701)
{
    object _25058 = NOVALUE;
    object _25057 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48701)) {
        _1 = (object)(DBL_PTR(_sym_48701)->dbl);
        DeRefDS(_sym_48701);
        _sym_48701 = _1;
    }

    /** symtab.e:1262		return SymTab[sym][S_NAME]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25057 = (object)*(((s1_ptr)_2)->base + _sym_48701);
    _2 = (object)SEQ_PTR(_25057);
    if (!IS_ATOM_INT(_36S_NAME_21076)){
        _25058 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NAME_21076)->dbl));
    }
    else{
        _25058 = (object)*(((s1_ptr)_2)->base + _36S_NAME_21076);
    }
    _25057 = NOVALUE;
    Ref(_25058);
    return _25058;
    ;
}


object _54sym_token(object _sym_48709)
{
    object _25060 = NOVALUE;
    object _25059 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48709)) {
        _1 = (object)(DBL_PTR(_sym_48709)->dbl);
        DeRefDS(_sym_48709);
        _sym_48709 = _1;
    }

    /** symtab.e:1266		return SymTab[sym][S_TOKEN]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25059 = (object)*(((s1_ptr)_2)->base + _sym_48709);
    _2 = (object)SEQ_PTR(_25059);
    if (!IS_ATOM_INT(_36S_TOKEN_21081)){
        _25060 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_TOKEN_21081)->dbl));
    }
    else{
        _25060 = (object)*(((s1_ptr)_2)->base + _36S_TOKEN_21081);
    }
    _25059 = NOVALUE;
    Ref(_25060);
    return _25060;
    ;
}


object _54sym_scope(object _sym_48717)
{
    object _25062 = NOVALUE;
    object _25061 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48717)) {
        _1 = (object)(DBL_PTR(_sym_48717)->dbl);
        DeRefDS(_sym_48717);
        _sym_48717 = _1;
    }

    /** symtab.e:1270		return SymTab[sym][S_SCOPE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25061 = (object)*(((s1_ptr)_2)->base + _sym_48717);
    _2 = (object)SEQ_PTR(_25061);
    _25062 = (object)*(((s1_ptr)_2)->base + 4LL);
    _25061 = NOVALUE;
    Ref(_25062);
    return _25062;
    ;
}


object _54sym_mode(object _sym_48725)
{
    object _25064 = NOVALUE;
    object _25063 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48725)) {
        _1 = (object)(DBL_PTR(_sym_48725)->dbl);
        DeRefDS(_sym_48725);
        _sym_48725 = _1;
    }

    /** symtab.e:1274		return SymTab[sym][S_MODE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25063 = (object)*(((s1_ptr)_2)->base + _sym_48725);
    _2 = (object)SEQ_PTR(_25063);
    _25064 = (object)*(((s1_ptr)_2)->base + 3LL);
    _25063 = NOVALUE;
    Ref(_25064);
    return _25064;
    ;
}


object _54sym_obj(object _sym_48733)
{
    object _25066 = NOVALUE;
    object _25065 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_48733)) {
        _1 = (object)(DBL_PTR(_sym_48733)->dbl);
        DeRefDS(_sym_48733);
        _sym_48733 = _1;
    }

    /** symtab.e:1278		return SymTab[sym][S_OBJ]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25065 = (object)*(((s1_ptr)_2)->base + _sym_48733);
    _2 = (object)SEQ_PTR(_25065);
    _25066 = (object)*(((s1_ptr)_2)->base + 1LL);
    _25065 = NOVALUE;
    Ref(_25066);
    return _25066;
    ;
}


object _54sym_next(object _sym_48741)
{
    object _25068 = NOVALUE;
    object _25067 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1282		return SymTab[sym][S_NEXT]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25067 = (object)*(((s1_ptr)_2)->base + _sym_48741);
    _2 = (object)SEQ_PTR(_25067);
    _25068 = (object)*(((s1_ptr)_2)->base + 2LL);
    _25067 = NOVALUE;
    Ref(_25068);
    return _25068;
    ;
}


object _54sym_block(object _sym_48749)
{
    object _25070 = NOVALUE;
    object _25069 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1286		return SymTab[sym][S_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25069 = (object)*(((s1_ptr)_2)->base + _sym_48749);
    _2 = (object)SEQ_PTR(_25069);
    if (!IS_ATOM_INT(_36S_BLOCK_21096)){
        _25070 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_BLOCK_21096)->dbl));
    }
    else{
        _25070 = (object)*(((s1_ptr)_2)->base + _36S_BLOCK_21096);
    }
    _25069 = NOVALUE;
    Ref(_25070);
    return _25070;
    ;
}


object _54sym_next_in_block(object _sym_48757)
{
    object _25072 = NOVALUE;
    object _25071 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1290		return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25071 = (object)*(((s1_ptr)_2)->base + _sym_48757);
    _2 = (object)SEQ_PTR(_25071);
    if (!IS_ATOM_INT(_36S_NEXT_IN_BLOCK_21068)){
        _25072 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_36S_NEXT_IN_BLOCK_21068)->dbl));
    }
    else{
        _25072 = (object)*(((s1_ptr)_2)->base + _36S_NEXT_IN_BLOCK_21068);
    }
    _25071 = NOVALUE;
    Ref(_25072);
    return _25072;
    ;
}


object _54sym_usage(object _sym_48765)
{
    object _25074 = NOVALUE;
    object _25073 = NOVALUE;
    object _0, _1, _2;
    

    /** symtab.e:1294		return SymTab[sym][S_USAGE]*/
    _2 = (object)SEQ_PTR(_37SymTab_15406);
    _25073 = (object)*(((s1_ptr)_2)->base + _sym_48765);
    _2 = (object)SEQ_PTR(_25073);
    _25074 = (object)*(((s1_ptr)_2)->base + 5LL);
    _25073 = NOVALUE;
    Ref(_25074);
    return _25074;
    ;
}



// 0x3EE80608
