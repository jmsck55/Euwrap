// Euphoria To C version 4.1.0 development (5861:57179171dbed, 2015-02-02 14:18:53)
#include "include/euphoria.h"
#include "main-.h"

object _63find_category(object _tokid_23996)
{
    object _catname_23997 = NOVALUE;
    object _13505 = NOVALUE;
    object _13504 = NOVALUE;
    object _13502 = NOVALUE;
    object _13501 = NOVALUE;
    object _13500 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23996)) {
        _1 = (object)(DBL_PTR(_tokid_23996)->dbl);
        DeRefDS(_tokid_23996);
        _tokid_23996 = _1;
    }

    /** keylist.e:194		sequence catname = "reserved word"*/
    RefDS(_13499);
    DeRef(_catname_23997);
    _catname_23997 = _13499;

    /** keylist.e:195		for i = 1 to length(token_category) do*/
    _13500 = 73;
    {
        object _i_24000;
        _i_24000 = 1LL;
L1: 
        if (_i_24000 > 73LL){
            goto L2; // [17] 72
        }

        /** keylist.e:196			if token_category[i][1] = tokid then*/
        _2 = (object)SEQ_PTR(_38token_category_15972);
        _13501 = (object)*(((s1_ptr)_2)->base + _i_24000);
        _2 = (object)SEQ_PTR(_13501);
        _13502 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13501 = NOVALUE;
        if (binary_op_a(NOTEQ, _13502, _tokid_23996)){
            _13502 = NOVALUE;
            goto L3; // [36] 65
        }
        _13502 = NOVALUE;

        /** keylist.e:197				catname = token_catname[token_category[i][2]]*/
        _2 = (object)SEQ_PTR(_38token_category_15972);
        _13504 = (object)*(((s1_ptr)_2)->base + _i_24000);
        _2 = (object)SEQ_PTR(_13504);
        _13505 = (object)*(((s1_ptr)_2)->base + 2LL);
        _13504 = NOVALUE;
        DeRef(_catname_23997);
        _2 = (object)SEQ_PTR(_38token_catname_15959);
        if (!IS_ATOM_INT(_13505)){
            _catname_23997 = (object)*(((s1_ptr)_2)->base + (object)(DBL_PTR(_13505)->dbl));
        }
        else{
            _catname_23997 = (object)*(((s1_ptr)_2)->base + _13505);
        }
        RefDS(_catname_23997);

        /** keylist.e:198				exit*/
        goto L2; // [62] 72
L3: 

        /** keylist.e:200		end for*/
        _i_24000 = _i_24000 + 1LL;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** keylist.e:201		return catname*/
    _13505 = NOVALUE;
    return _catname_23997;
    ;
}


object _63find_token_text(object _tokid_24015)
{
    object _13514 = NOVALUE;
    object _13512 = NOVALUE;
    object _13511 = NOVALUE;
    object _13509 = NOVALUE;
    object _13508 = NOVALUE;
    object _13507 = NOVALUE;
    object _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_24015)) {
        _1 = (object)(DBL_PTR(_tokid_24015)->dbl);
        DeRefDS(_tokid_24015);
        _tokid_24015 = _1;
    }

    /** keylist.e:205		for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_23115)){
            _13507 = SEQ_PTR(_63keylist_23115)->length;
    }
    else {
        _13507 = 1;
    }
    {
        object _i_24017;
        _i_24017 = 1LL;
L1: 
        if (_i_24017 > _13507){
            goto L2; // [10] 57
        }

        /** keylist.e:206			if keylist[i][3] = tokid then*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _13508 = (object)*(((s1_ptr)_2)->base + _i_24017);
        _2 = (object)SEQ_PTR(_13508);
        _13509 = (object)*(((s1_ptr)_2)->base + 3LL);
        _13508 = NOVALUE;
        if (binary_op_a(NOTEQ, _13509, _tokid_24015)){
            _13509 = NOVALUE;
            goto L3; // [29] 50
        }
        _13509 = NOVALUE;

        /** keylist.e:207				return keylist[i][1]*/
        _2 = (object)SEQ_PTR(_63keylist_23115);
        _13511 = (object)*(((s1_ptr)_2)->base + _i_24017);
        _2 = (object)SEQ_PTR(_13511);
        _13512 = (object)*(((s1_ptr)_2)->base + 1LL);
        _13511 = NOVALUE;
        Ref(_13512);
        return _13512;
L3: 

        /** keylist.e:209		end for*/
        _i_24017 = _i_24017 + 1LL;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** keylist.e:210		return LexName(tokid, "unknown word")*/
    RefDS(_13513);
    _13514 = _47LexName(_tokid_24015, _13513);
    _13512 = NOVALUE;
    return _13514;
    ;
}



// 0x6626B851
