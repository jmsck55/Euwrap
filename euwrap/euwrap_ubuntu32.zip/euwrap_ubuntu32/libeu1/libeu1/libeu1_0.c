// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_1eu_puts(int _fn_id, int _id1)
{
    int _561 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	puts(fn_id, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _561 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_561);
    EPuts(_fn_id, _561);

    // end procedure
    DeRef(_561);
    return 0;
    ;
}


_1eu_rand(int _id1)
{
    int _562 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(rand(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _562 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_562);
    _0 = _562;
    if (IS_ATOM_INT(_562)) {
        _562 = good_rand() % ((unsigned)_562) + 1;
    }
    else {
        _562 = unary_op(RAND, _562);
    }
    DeRef(_0);
    Ref(_562);
    _0 = _562;
    _562 = _1retval(_562);
    DeRef(_0);
    return _562;
    ;
}


_1eu_remainder(int _id1, int _id2)
{
    int _566 = 0;
    int _565 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(remainder(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _565 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_565);
    _2 = (int)SEQ_PTR(_1data);
    _566 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_566);
    _0 = _566;
    if (IS_ATOM_INT(_565) && IS_ATOM_INT(_566)) {
        _566 = (_565 % _566);
    }
    else {
        _566 = binary_op(REMAINDER, _565, _566);
    }
    DeRef(_0);
    Ref(_566);
    _0 = _566;
    _566 = _1retval(_566);
    DeRef(_0);
    DeRef(_565);
    return _566;
    ;
}


_1eu_sequence(int _id)
{
    int _569 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return sequence(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _569 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_569);
    _0 = _569;
    _569 = IS_SEQUENCE(_569);
    DeRef(_0);
    return _569;
    ;
}


_1eu_sin(int _id)
{
    int _571 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(sin(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _571 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_571);
    _0 = _571;
    if (IS_ATOM_INT(_571))
        _571 = e_sin(_571);
    else
        _571 = unary_op(SIN, _571);
    DeRef(_0);
    Ref(_571);
    _0 = _571;
    _571 = _1retval(_571);
    DeRef(_0);
    return _571;
    ;
}


_1eu_sprintf(int _id1, int _id2)
{
    int _575 = 0;
    int _574 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(sprintf(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _574 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_574);
    _2 = (int)SEQ_PTR(_1data);
    _575 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_575);
    _0 = _575;
    _575 = EPrintf(-9999999, _574, _575);
    DeRef(_0);
    RefDS(_575);
    _0 = _575;
    _575 = _1retval(_575);
    DeRefDSi(_0);
    DeRef(_574);
    return _575;
    ;
}


_1eu_sqrt(int _id)
{
    int _578 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(sqrt(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _578 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_578);
    _0 = _578;
    if (IS_ATOM_INT(_578))
        _578 = e_sqrt(_578);
    else
        _578 = unary_op(SQRT, _578);
    DeRef(_0);
    Ref(_578);
    _0 = _578;
    _578 = _1retval(_578);
    DeRef(_0);
    return _578;
    ;
}


_1eu_subscript(int _id, int _start, int _stop)
{
    int _581 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }
    if (!IS_ATOM_INT(_stop)) {
        _1 = (long)(DBL_PTR(_stop)->dbl);
        DeRefDS(_stop);
        _stop = _1;
    }

    // 	return retval(data[id][start..stop])
    _2 = (int)SEQ_PTR(_1data);
    _581 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_581);
    rhs_slice_target = (object_ptr)&_581;
    RHS_Slice((s1_ptr)_581, _start, _stop);
    RefDS(_581);
    _0 = _581;
    _581 = _1retval(_581);
    DeRefDS(_0);
    return _581;
    ;
}


_1eu_system(int _id1, int _mode)
{
    int _584 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_mode)) {
        _1 = (long)(DBL_PTR(_mode)->dbl);
        DeRefDS(_mode);
        _mode = _1;
    }

    // 	system(data[id1], mode)
    _2 = (int)SEQ_PTR(_1data);
    _584 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_584);
    system_call(_584, _mode);

    // end procedure
    DeRef(_584);
    return 0;
    ;
}


_1eu_system_exec(int _id1, int _mode)
{
    int _585 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_mode)) {
        _1 = (long)(DBL_PTR(_mode)->dbl);
        DeRefDS(_mode);
        _mode = _1;
    }

    // 	return system_exec(data[id1], mode) -- returns the exit code from the called process.
    _2 = (int)SEQ_PTR(_1data);
    _585 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_585);
    _0 = _585;
    _585 = system_exec_call(_585, _mode);
    DeRef(_0);
    return _585;
    ;
}


_1eu_tan(int _id)
{
    int _587 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(tan(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _587 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_587);
    _0 = _587;
    if (IS_ATOM_INT(_587))
        _587 = e_tan(_587);
    else
        _587 = unary_op(TAN, _587);
    DeRef(_0);
    Ref(_587);
    _0 = _587;
    _587 = _1retval(_587);
    DeRef(_0);
    return _587;
    ;
}


_1eu_time()
{
    int _590 = 0;
    int _0, _1, _2;
    

    // 	return retval(time())
    _590 = NewDouble(current_time());
    RefDS(_590);
    _0 = _590;
    _590 = _1retval(_590);
    DeRefDS(_0);
    return _590;
    ;
}


_1eu_xor_bits(int _id1, int _id2)
{
    int _593 = 0;
    int _592 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(xor_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _592 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_592);
    _2 = (int)SEQ_PTR(_1data);
    _593 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_593);
    _0 = _593;
    if (IS_ATOM_INT(_592) && IS_ATOM_INT(_593)) {
        _593 = (_592 ^ _593);
    }
    else {
        _593 = binary_op(XOR_BITS, _592, _593);
    }
    DeRef(_0);
    Ref(_593);
    _0 = _593;
    _593 = _1retval(_593);
    DeRef(_0);
    DeRef(_592);
    return _593;
    ;
}


_1eu_call_func_std(int _rid, int _did)
{
    int _596 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(call_func(rid, data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _596 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_596);
    _1 = (int)SEQ_PTR(_596);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    DeRef(_596);
    _596 = _1;
    Ref(_596);
    _0 = _596;
    _596 = _1retval(_596);
    DeRef(_0);
    return _596;
    ;
}


_1eu_call_func_val(int _rid, int _did)
{
    int _599 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(call_func(rid, data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _599 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_599);
    _1 = (int)SEQ_PTR(_599);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    DeRef(_599);
    _599 = _1;
    Ref(_599);
    _0 = _599;
    _599 = _1retval(_599);
    DeRef(_0);
    return _599;
    ;
}


_1eu_call_func(int _rid, int _did)
{
    int _i;
    int _602 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = call_func(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _602 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_602);
    _1 = (int)SEQ_PTR(_602);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _i = _1;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	return i
    DeRef(_602);
    return _i;
    ;
}


_1eu_call_proc(int _rid, int _did)
{
    int _604 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	call_proc(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _604 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_604);
    _1 = (int)SEQ_PTR(_604);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }

    // end procedure
    DeRef(_604);
    return 0;
    ;
}


_1eu_routine_id(int _did)
{
    int _605 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return routine_id(data[did]) -- this is the only time it uses a string
    _2 = (int)SEQ_PTR(_1data);
    _605 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_605);
    _0 = _605;
    _605 = CRoutineId(139, 1, _605);
    DeRef(_0);
    return _605;
    ;
}


_1eu_routine_id_str(int _low, int _high)
{
    int _607 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	return routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string
    _607 = _1get_address(_low, _high);
    Ref(_607);
    _0 = _607;
    _607 = _3peek_string(_607);
    DeRef(_0);
    _0 = _607;
    _607 = CRoutineId(140, 1, _607);
    DeRefDSi(_0);
    return _607;
    ;
}


