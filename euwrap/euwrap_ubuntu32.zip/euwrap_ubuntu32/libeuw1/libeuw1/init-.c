#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

int _152;
int _187;
int _189;
int _198;
int _202;
int _216;
int _218;
int _221;
int _230;
int _258;
int _272;
int _280;
int _304;
int _305;
int _315;
int _395;
int _396;
int _422;
int _423;
int _425;
int _439;
int _441;
int _442;
int _562;
int _573;
int _711;
int _967;
int _1027;
int _1168;
int _1169;
int _1170;
int _1173;
int _1188;
int _1306;
int _1312;
int _1313;
int _1317;
int _1320;
int _1324;
int _1329;
int _1330;
int _1337;
int _1341;
int _1354;
int _1355;
int _1357;
int _1358;
int _1359;
int _1361;
int _1367;
int _1373;
int _1376;
int _1383;
int _1390;
int _1393;
int _1397;
int _1500;
int _1506;
int _1670;
int _1673;
int _1692;
int _1757;
int _1806;
int _1896;
int _1910;
int _1918;
int _1921;
int _1926;
int _1927;
int _1930;
int _1933;
int _1934;
int _1976;
int _2005;
int _2006;
int _2008;
int _2011;
int _2015;
int _2016;
int _2017;
int _2018;
int _2019;

int _2MAX_ADDR;
int _2LOW_ADDR;
int _2mem;
int _2check_calls;
int _6pretty_end_col;
int _6pretty_chars;
int _6pretty_start_col;
int _6pretty_level;
int _6pretty_file;
int _6pretty_ascii;
int _6pretty_indent;
int _6pretty_ascii_min;
int _6pretty_ascii_max;
int _6pretty_line_count;
int _6pretty_line_max;
int _6pretty_dots;
int _6pretty_fp_format;
int _6pretty_int_format;
int _6pretty_line;
int _6PI;
int _6PI_HALF;
int _4SLASH;
int _4my_dir;
int _7DIGITS;
int _7HEX_DIGITS;
int _7START_NUMERIC;
int _7input_file;
int _7input_string;
int _7string_next;
int _7ch;
int _7ESCAPE_CHARS;
int _7ESCAPED_CHARS;
int _8BLUE;
int _8CYAN;
int _8RED;
int _8BROWN;
int _8BRIGHT_BLUE;
int _8BRIGHT_CYAN;
int _8BRIGHT_RED;
int _8YELLOW;
int _9fn;
int _9error_code;
int _9numXPixels;
int _9numYPixels;
int _9bitCount;
int _9numRowBytes;
int _9startXPixel;
int _9startYPixel;
int _9endYPixel;
int _10TO_LOWER;
int _11current_db;
int _11current_table;
int _11db_names;
int _11db_file_nums;
int _11db_lock_methods;
int _11current_lock;
int _11SLASH_CHAR;
int _11key_pointers;
int _11db_fatal_id;
int _11mem0;
int _11mem1;
int _11mem2;
int _11mem3;
int _11MIN2B;
int _11MAX2B;
int _11MIN3B;
int _11MAX3B;
int _11MIN4B;
int _11memseq;
int _12always_linked_list;
int _12SIGN_MASK;
int _12SIGN_FLAG;
int _12DOUBLE_FLAG;
int _12INT_FLAG;
int _12UINT_FLAG;
int _12FLOAT_FLAG;
int _12CSTRING;
int _12CBYTES;
int _1high_address;
int _1data;
int _1free_list;


struct routine_list _00[] = {
  {"allocate", (int (*)())_2allocate, 7, -2, 1, 0},
  {"free", (int (*)())_2free, 8, -2, 1, 0},
  {"allocate_low", (int (*)())_2allocate_low, 9, -2, 1, 0},
  {"free_low", (int (*)())_2free_low, 10, -2, 1, 0},
  {"dos_interrupt", (int (*)())_2dos_interrupt, 11, -2, 2, 0},
  {"int_to_bytes", (int (*)())_2int_to_bytes, 12, -2, 1, 0},
  {"bytes_to_int", (int (*)())_2bytes_to_int, 13, -2, 1, 0},
  {"int_to_bits", (int (*)())_2int_to_bits, 14, -2, 2, 0},
  {"bits_to_int", (int (*)())_2bits_to_int, 15, -2, 1, 0},
  {"set_rand", (int (*)())_2set_rand, 16, -2, 1, 0},
  {"use_vesa", (int (*)())_2use_vesa, 17, -2, 1, 0},
  {"crash_message", (int (*)())_2crash_message, 18, -2, 1, 0},
  {"crash_file", (int (*)())_2crash_file, 19, -2, 1, 0},
  {"crash_routine", (int (*)())_2crash_routine, 20, -2, 1, 0},
  {"tick_rate", (int (*)())_2tick_rate, 21, -2, 1, 0},
  {"get_vector", (int (*)())_2get_vector, 22, -2, 1, 0},
  {"set_vector", (int (*)())_2set_vector, 23, -2, 2, 0},
  {"lock_memory", (int (*)())_2lock_memory, 24, -2, 2, 0},
  {"atom_to_float64", (int (*)())_2atom_to_float64, 25, -2, 1, 0},
  {"atom_to_float32", (int (*)())_2atom_to_float32, 26, -2, 1, 0},
  {"float64_to_atom", (int (*)())_2float64_to_atom, 27, -2, 1, 0},
  {"float32_to_atom", (int (*)())_2float32_to_atom, 28, -2, 1, 0},
  {"allocate_string", (int (*)())_2allocate_string, 29, -2, 1, 0},
  {"register_block", (int (*)())_2register_block, 30, -2, 2, 0},
  {"unregister_block", (int (*)())_2unregister_block, 31, -2, 1, 0},
  {"check_all_blocks", (int (*)())_2check_all_blocks, 32, -2, 0, 0},
  {"open_dll", (int (*)())_3open_dll, 33, -3, 1, 0},
  {"define_c_var", (int (*)())_3define_c_var, 34, -3, 2, 0},
  {"define_c_proc", (int (*)())_3define_c_proc, 35, -3, 3, 0},
  {"define_c_func", (int (*)())_3define_c_func, 36, -3, 4, 0},
  {"call_back", (int (*)())_3call_back, 37, -3, 1, 0},
  {"free_console", (int (*)())_3free_console, 38, -3, 0, 0},
  {"sort", (int (*)())_5sort, 39, -5, 1, 0},
  {"custom_sort", (int (*)())_5custom_sort, 40, -5, 2, 0},
  {"instance", (int (*)())_6instance, 41, -6, 0, 0},
  {"sleep", (int (*)())_6sleep, 42, -6, 1, 0},
  {"reverse", (int (*)())_6reverse, 43, -6, 1, 0},
  {"sprint", (int (*)())_6sprint, 44, -6, 1, 0},
  {"pretty_print", (int (*)())_6pretty_print, 50, -6, 3, 0},
  {"arccos", (int (*)())_6arccos, 52, -6, 1, 0},
  {"arcsin", (int (*)())_6arcsin, 53, -6, 1, 0},
  {"seek", (int (*)())_4seek, 57, -4, 2, 0},
  {"where", (int (*)())_4where, 58, -4, 1, 0},
  {"flush", (int (*)())_4flush, 59, -4, 1, 0},
  {"lock_file", (int (*)())_4lock_file, 62, -4, 3, 0},
  {"unlock_file", (int (*)())_4unlock_file, 63, -4, 2, 0},
  {"dir", (int (*)())_4dir, 64, -4, 1, 0},
  {"current_dir", (int (*)())_4current_dir, 65, -4, 0, 0},
  {"chdir", (int (*)())_4chdir, 66, -4, 1, 0},
  {"allow_break", (int (*)())_4allow_break, 67, -4, 1, 0},
  {"check_break", (int (*)())_4check_break, 68, -4, 0, 0},
  {"walk_dir", (int (*)())_4walk_dir, 70, -4, 3, 0},
  {"wait_key", (int (*)())_7wait_key, 73, -7, 0, 0},
  {"get", (int (*)())_7get, 82, -7, 1, 0},
  {"value", (int (*)())_7value, 83, -7, 1, 0},
  {"prompt_number", (int (*)())_7prompt_number, 84, -7, 2, 0},
  {"prompt_string", (int (*)())_7prompt_string, 85, -7, 1, 0},
  {"get_bytes", (int (*)())_7get_bytes, 86, -7, 2, 0},
  {"draw_line", (int (*)())_8draw_line, 93, -8, 2, 0},
  {"polygon", (int (*)())_8polygon, 94, -8, 3, 0},
  {"ellipse", (int (*)())_8ellipse, 95, -8, 4, 0},
  {"graphics_mode", (int (*)())_8graphics_mode, 96, -8, 1, 0},
  {"video_config", (int (*)())_8video_config, 97, -8, 0, 0},
  {"cursor", (int (*)())_8cursor, 98, -8, 1, 0},
  {"get_position", (int (*)())_8get_position, 99, -8, 0, 0},
  {"text_rows", (int (*)())_8text_rows, 100, -8, 1, 0},
  {"wrap", (int (*)())_8wrap, 101, -8, 1, 0},
  {"scroll", (int (*)())_8scroll, 102, -8, 3, 0},
  {"text_color", (int (*)())_8text_color, 103, -8, 1, 0},
  {"bk_color", (int (*)())_8bk_color, 104, -8, 1, 0},
  {"palette", (int (*)())_8palette, 106, -8, 2, 0},
  {"all_palette", (int (*)())_8all_palette, 107, -8, 1, 0},
  {"sound", (int (*)())_8sound, 109, -8, 1, 0},
  {"read_bitmap", (int (*)())_9read_bitmap, 117, -9, 1, 0},
  {"display_image", (int (*)())_9display_image, 120, -9, 2, 0},
  {"save_image", (int (*)())_9save_image, 121, -9, 2, 0},
  {"get_display_page", (int (*)())_9get_display_page, 123, -9, 0, 0},
  {"set_display_page", (int (*)())_9set_display_page, 124, -9, 1, 0},
  {"get_active_page", (int (*)())_9get_active_page, 125, -9, 0, 0},
  {"set_active_page", (int (*)())_9set_active_page, 126, -9, 1, 0},
  {"get_screen_char", (int (*)())_9get_screen_char, 129, -9, 2, 0},
  {"put_screen_char", (int (*)())_9put_screen_char, 130, -9, 3, 0},
  {"display_text_image", (int (*)())_9display_text_image, 131, -9, 2, 0},
  {"save_text_image", (int (*)())_9save_text_image, 132, -9, 2, 0},
  {"get_all_palette", (int (*)())_9get_all_palette, 138, -9, 0, 0},
  {"save_screen", (int (*)())_9save_screen, 140, -9, 2, 0},
  {"save_bitmap", (int (*)())_9save_bitmap, 142, -9, 2, 0},
  {"lower", (int (*)())_10lower, 143, -10, 1, 0},
  {"upper", (int (*)())_10upper, 144, -10, 1, 0},
  {"wildcard_match", (int (*)())_10wildcard_match, 146, -10, 2, 0},
  {"wildcard_file", (int (*)())_10wildcard_file, 147, -10, 2, 0},
  {"default_fatal", (int (*)())_11default_fatal, 148, 11, 1, 0},
  {"db_dump", (int (*)())_11db_dump, 159, -11, 2, 0},
  {"check_free_list", (int (*)())_11check_free_list, 160, -11, 0, 0},
  {"db_create", (int (*)())_11db_create, 163, -11, 2, 0},
  {"db_open", (int (*)())_11db_open, 164, -11, 2, 0},
  {"db_select", (int (*)())_11db_select, 165, -11, 1, 0},
  {"db_close", (int (*)())_11db_close, 166, -11, 0, 0},
  {"db_select_table", (int (*)())_11db_select_table, 168, -11, 1, 0},
  {"db_create_table", (int (*)())_11db_create_table, 169, -11, 1, 0},
  {"db_delete_table", (int (*)())_11db_delete_table, 170, -11, 1, 0},
  {"db_rename_table", (int (*)())_11db_rename_table, 171, -11, 2, 0},
  {"db_table_list", (int (*)())_11db_table_list, 172, -11, 0, 0},
  {"db_find_key", (int (*)())_11db_find_key, 174, -11, 1, 0},
  {"db_insert", (int (*)())_11db_insert, 175, -11, 2, 0},
  {"db_delete_record", (int (*)())_11db_delete_record, 176, -11, 1, 0},
  {"db_replace_data", (int (*)())_11db_replace_data, 177, -11, 2, 0},
  {"db_table_size", (int (*)())_11db_table_size, 178, -11, 0, 0},
  {"db_record_data", (int (*)())_11db_record_data, 179, -11, 1, 0},
  {"db_record_key", (int (*)())_11db_record_key, 180, -11, 1, 0},
  {"db_compress", (int (*)())_11db_compress, 183, -11, 0, 0},
  {"set_return_linked_list", (int (*)())_12set_return_linked_list, 184, -12, 1, 0},
  {"get_return_linked_list", (int (*)())_12get_return_linked_list, 185, -12, 0, 0},
  {"peek_string", (int (*)())_12peek_string, 186, -12, 1, 0},
  {"mystring", (int (*)())_12mystring, 187, -12, 1, 0},
  {"myarray", (int (*)())_12myarray, 188, -12, 1, 0},
  {"sequence_to_linked_list", (int (*)())_12sequence_to_linked_list, 189, -12, 1, 0},
  {"free_linked_list", (int (*)())_12free_linked_list, 190, -12, 1, 0},
  {"linked_list_to_sequence", (int (*)())_12linked_list_to_sequence, 191, -12, 1, 0},
  {"get_version", (int (*)())_1get_version, 192, -1, 0, 0},
  {"binary_search", (int (*)())_1binary_search, 193, 1, 2, 0},
  {"init", (int (*)())_1init, 194, -1, 0, 0},
  {"get_high_address", (int (*)())_1get_high_address, 195, -1, 0, 0},
  {"set_high_address", (int (*)())_1set_high_address, 196, 1, 1, 0},
  {"get_address", (int (*)())_1get_address, 197, 1, 2, 0},
  {"register_data", (int (*)())_1register_data, 198, 1, 1, 0},
  {"retval", (int (*)())_1retval, 199, 1, 1, 0},
  {"length_of_data", (int (*)())_1length_of_data, 200, -1, 0, 0},
  {"is_free", (int (*)())_1is_free, 201, -1, 1, 0},
  {"access_free_list", (int (*)())_1access_free_list, 202, -1, 0, 0},
  {"generic_free", (int (*)())_1generic_free, 203, -1, 2, 0},
  {"delete_linked_list", (int (*)())_1delete_linked_list, 204, -1, 1, 0},
  {"free_linked_lists", (int (*)())_1free_linked_lists, 205, -1, 3, 0},
  {"register_linked_list", (int (*)())_1register_linked_list, 206, -1, 2, 0},
  {"new_linked_list", (int (*)())_1new_linked_list, 207, -1, 2, 0},
  {"store_linked_list", (int (*)())_1store_linked_list, 208, -1, 3, 0},
  {"access_linked_list", (int (*)())_1access_linked_list, 209, -1, 1, 0},
  {"at_linked_list", (int (*)())_1at_linked_list, 210, -1, 2, 0},
  {"free_linked_list_dll", (int (*)())_1free_linked_list_dll, 211, -1, 2, 0},
  {"length_linked_list", (int (*)())_1length_linked_list, 212, -1, 1, 0},
  {"store_at_linked_list", (int (*)())_1store_at_linked_list, 213, -1, 4, 0},
  {"eu_repeat", (int (*)())_1eu_repeat, 214, -1, 2, 0},
  {"eu_mem_set", (int (*)())_1eu_mem_set, 215, -1, 4, 0},
  {"eu_mem_copy", (int (*)())_1eu_mem_copy, 216, -1, 5, 0},
  {"eu_add", (int (*)())_1eu_add, 217, -1, 2, 0},
  {"eu_subtract", (int (*)())_1eu_subtract, 218, -1, 2, 0},
  {"eu_multiply", (int (*)())_1eu_multiply, 219, -1, 2, 0},
  {"eu_divide", (int (*)())_1eu_divide, 220, -1, 2, 0},
  {"eu_negate", (int (*)())_1eu_negate, 221, -1, 1, 0},
  {"eu_not", (int (*)())_1eu_not, 222, -1, 1, 0},
  {"eu_equals", (int (*)())_1eu_equals, 223, -1, 2, 0},
  {"eu_and", (int (*)())_1eu_and, 224, -1, 2, 0},
  {"eu_or", (int (*)())_1eu_or, 225, -1, 2, 0},
  {"eu_xor", (int (*)())_1eu_xor, 226, -1, 2, 0},
  {"eu_question_mark", (int (*)())_1eu_question_mark, 227, -1, 1, 0},
  {"eu_abort", (int (*)())_1eu_abort, 228, -1, 1, 0},
  {"eu_and_bits", (int (*)())_1eu_and_bits, 229, -1, 2, 0},
  {"eu_append", (int (*)())_1eu_append, 230, -1, 2, 0},
  {"eu_arctan", (int (*)())_1eu_arctan, 231, -1, 1, 0},
  {"eu_atom", (int (*)())_1eu_atom, 232, -1, 1, 0},
  {"eu_c_func", (int (*)())_1eu_c_func, 233, -1, 2, 0},
  {"eu_c_proc", (int (*)())_1eu_c_proc, 234, -1, 2, 0},
  {"eu_call", (int (*)())_1eu_call, 235, -1, 2, 0},
  {"eu_clear_screen", (int (*)())_1eu_clear_screen, 236, -1, 0, 0},
  {"eu_close", (int (*)())_1eu_close, 237, -1, 1, 0},
  {"eu_command_line", (int (*)())_1eu_command_line, 238, -1, 0, 0},
  {"eu_compare", (int (*)())_1eu_compare, 239, -1, 2, 0},
  {"eu_concat", (int (*)())_1eu_concat, 240, -1, 2, 0},
  {"eu_cos", (int (*)())_1eu_cos, 241, -1, 1, 0},
  {"eu_date", (int (*)())_1eu_date, 242, -1, 0, 0},
  {"eu_equal", (int (*)())_1eu_equal, 243, -1, 2, 0},
  {"eu_find_from", (int (*)())_1eu_find_from, 244, -1, 3, 0},
  {"eu_floor", (int (*)())_1eu_floor, 245, -1, 1, 0},
  {"eu_integer_division", (int (*)())_1eu_integer_division, 246, -1, 2, 0},
  {"eu_get_key", (int (*)())_1eu_get_key, 247, -1, 0, 0},
  {"eu_getc", (int (*)())_1eu_getc, 248, -1, 1, 0},
  {"eu_getenv", (int (*)())_1eu_getenv, 249, -1, 1, 0},
  {"eu_gets", (int (*)())_1eu_gets, 250, -1, 1, 0},
  {"eu_integer", (int (*)())_1eu_integer, 251, -1, 1, 0},
  {"eu_length", (int (*)())_1eu_length, 252, -1, 1, 0},
  {"eu_log", (int (*)())_1eu_log, 253, -1, 1, 0},
  {"eu_machine_func", (int (*)())_1eu_machine_func, 254, -1, 2, 0},
  {"eu_machine_proc", (int (*)())_1eu_machine_proc, 255, -1, 2, 0},
  {"eu_match_from", (int (*)())_1eu_match_from, 256, -1, 3, 0},
  {"eu_not_bits", (int (*)())_1eu_not_bits, 257, -1, 1, 0},
  {"eu_object", (int (*)())_1eu_object, 258, -1, 1, 0},
  {"eu_open", (int (*)())_1eu_open, 259, -1, 2, 0},
  {"eu_open_str", (int (*)())_1eu_open_str, 260, -1, 3, 0},
  {"eu_or_bits", (int (*)())_1eu_or_bits, 261, -1, 2, 0},
  {"eu_peek", (int (*)())_1eu_peek, 262, -1, 1, 0},
  {"eu_peek4s", (int (*)())_1eu_peek4s, 263, -1, 1, 0},
  {"eu_peek4u", (int (*)())_1eu_peek4u, 264, -1, 1, 0},
  {"eu_platform", (int (*)())_1eu_platform, 265, -1, 0, 0},
  {"eu_poke", (int (*)())_1eu_poke, 266, -1, 2, 0},
  {"eu_poke4", (int (*)())_1eu_poke4, 267, -1, 2, 0},
  {"eu_position", (int (*)())_1eu_position, 268, -1, 2, 0},
  {"eu_power", (int (*)())_1eu_power, 269, -1, 2, 0},
  {"eu_prepend", (int (*)())_1eu_prepend, 270, -1, 2, 0},
  {"eu_print", (int (*)())_1eu_print, 271, -1, 2, 0},
  {"eu_printf", (int (*)())_1eu_printf, 272, -1, 3, 0},
  {"eu_puts", (int (*)())_1eu_puts, 273, -1, 2, 0},
  {"eu_rand", (int (*)())_1eu_rand, 274, -1, 1, 0},
  {"eu_remainder", (int (*)())_1eu_remainder, 275, -1, 2, 0},
  {"eu_sequence", (int (*)())_1eu_sequence, 276, -1, 1, 0},
  {"eu_sin", (int (*)())_1eu_sin, 277, -1, 1, 0},
  {"eu_sprintf", (int (*)())_1eu_sprintf, 278, -1, 2, 0},
  {"eu_sqrt", (int (*)())_1eu_sqrt, 279, -1, 1, 0},
  {"eu_subscript", (int (*)())_1eu_subscript, 280, -1, 3, 0},
  {"eu_system", (int (*)())_1eu_system, 281, -1, 2, 0},
  {"eu_system_exec", (int (*)())_1eu_system_exec, 282, -1, 2, 0},
  {"eu_tan", (int (*)())_1eu_tan, 283, -1, 1, 0},
  {"eu_time", (int (*)())_1eu_time, 284, -1, 0, 0},
  {"eu_xor_bits", (int (*)())_1eu_xor_bits, 285, -1, 2, 0},
  {"eu_allocate", (int (*)())_1eu_allocate, 286, -1, 1, 0},
  {"eu_free", (int (*)())_1eu_free, 287, -1, 1, 0},
  {"eu_int_to_bytes", (int (*)())_1eu_int_to_bytes, 288, -1, 1, 0},
  {"eu_bytes_to_int", (int (*)())_1eu_bytes_to_int, 289, -1, 1, 0},
  {"eu_int_to_bits", (int (*)())_1eu_int_to_bits, 290, -1, 2, 0},
  {"eu_bits_to_int", (int (*)())_1eu_bits_to_int, 291, -1, 1, 0},
  {"eu_set_rand", (int (*)())_1eu_set_rand, 292, -1, 1, 0},
  {"eu_crash_message", (int (*)())_1eu_crash_message, 293, -1, 1, 0},
  {"eu_crash_file", (int (*)())_1eu_crash_file, 294, -1, 1, 0},
  {"eu_atom_to_float64", (int (*)())_1eu_atom_to_float64, 295, -1, 1, 0},
  {"eu_atom_to_float32", (int (*)())_1eu_atom_to_float32, 296, -1, 1, 0},
  {"eu_float64_to_atom", (int (*)())_1eu_float64_to_atom, 297, -1, 1, 0},
  {"eu_float32_to_atom", (int (*)())_1eu_float32_to_atom, 298, -1, 1, 0},
  {"eu_allocate_string", (int (*)())_1eu_allocate_string, 299, -1, 1, 0},
  {"eu_open_dll", (int (*)())_1eu_open_dll, 300, -1, 1, 0},
  {"eu_define_c_var", (int (*)())_1eu_define_c_var, 301, -1, 2, 0},
  {"eu_define_c_proc", (int (*)())_1eu_define_c_proc, 302, -1, 3, 0},
  {"eu_define_c_func", (int (*)())_1eu_define_c_func, 303, -1, 4, 0},
  {"eu_call_back", (int (*)())_1eu_call_back, 304, -1, 1, 0},
  {"eu_free_console", (int (*)())_1eu_free_console, 305, -1, 0, 0},
  {"eu_seek", (int (*)())_1eu_seek, 306, -1, 2, 0},
  {"eu_where", (int (*)())_1eu_where, 307, -1, 1, 0},
  {"eu_flush", (int (*)())_1eu_flush, 308, -1, 1, 0},
  {"eu_lock_file", (int (*)())_1eu_lock_file, 309, -1, 3, 0},
  {"eu_unlock_file", (int (*)())_1eu_unlock_file, 310, -1, 2, 0},
  {"eu_dir", (int (*)())_1eu_dir, 311, -1, 1, 0},
  {"eu_current_dir", (int (*)())_1eu_current_dir, 312, -1, 0, 0},
  {"eu_chdir", (int (*)())_1eu_chdir, 313, -1, 1, 0},
  {"eu_allow_break", (int (*)())_1eu_allow_break, 314, -1, 1, 0},
  {"eu_check_break", (int (*)())_1eu_check_break, 315, -1, 0, 0},
  {"eu_wait_key", (int (*)())_1eu_wait_key, 316, -1, 0, 0},
  {"eu_get", (int (*)())_1eu_get, 317, -1, 1, 0},
  {"eu_value", (int (*)())_1eu_value, 318, -1, 1, 0},
  {"eu_prompt_number", (int (*)())_1eu_prompt_number, 319, -1, 2, 0},
  {"eu_prompt_string", (int (*)())_1eu_prompt_string, 320, -1, 1, 0},
  {"eu_get_bytes", (int (*)())_1eu_get_bytes, 321, -1, 2, 0},
  {"eu_video_config", (int (*)())_1eu_video_config, 322, -1, 0, 0},
  {"eu_cursor", (int (*)())_1eu_cursor, 323, -1, 1, 0},
  {"eu_get_position", (int (*)())_1eu_get_position, 324, -1, 0, 0},
  {"eu_text_rows", (int (*)())_1eu_text_rows, 325, -1, 1, 0},
  {"eu_wrap", (int (*)())_1eu_wrap, 326, -1, 1, 0},
  {"eu_scroll", (int (*)())_1eu_scroll, 327, -1, 3, 0},
  {"eu_text_color", (int (*)())_1eu_text_color, 328, -1, 1, 0},
  {"eu_bk_color", (int (*)())_1eu_bk_color, 329, -1, 1, 0},
  {"eu_read_bitmap", (int (*)())_1eu_read_bitmap, 330, -1, 1, 0},
  {"eu_get_screen_char", (int (*)())_1eu_get_screen_char, 331, -1, 2, 0},
  {"eu_put_screen_char", (int (*)())_1eu_put_screen_char, 332, -1, 3, 0},
  {"eu_display_text_image", (int (*)())_1eu_display_text_image, 333, -1, 2, 0},
  {"eu_save_text_image", (int (*)())_1eu_save_text_image, 334, -1, 2, 0},
  {"eu_save_bitmap", (int (*)())_1eu_save_bitmap, 335, -1, 2, 0},
  {"eu_instance", (int (*)())_1eu_instance, 336, -1, 0, 0},
  {"eu_sleep", (int (*)())_1eu_sleep, 337, -1, 1, 0},
  {"eu_reverse", (int (*)())_1eu_reverse, 338, -1, 1, 0},
  {"eu_sprint", (int (*)())_1eu_sprint, 339, -1, 1, 0},
  {"eu_pretty_print", (int (*)())_1eu_pretty_print, 340, -1, 3, 0},
  {"eu_arccos", (int (*)())_1eu_arccos, 341, -1, 1, 0},
  {"eu_arcsin", (int (*)())_1eu_arcsin, 342, -1, 1, 0},
  {"eu_sort", (int (*)())_1eu_sort, 343, -1, 1, 0},
  {"eu_lower", (int (*)())_1eu_lower, 344, -1, 1, 0},
  {"eu_upper", (int (*)())_1eu_upper, 345, -1, 1, 0},
  {"eu_wildcard_match", (int (*)())_1eu_wildcard_match, 346, -1, 2, 0},
  {"eu_wildcard_file", (int (*)())_1eu_wildcard_file, 347, -1, 2, 0},
  {"eudb_dump", (int (*)())_1eudb_dump, 348, -1, 2, 0},
  {"eudb_create", (int (*)())_1eudb_create, 349, -1, 2, 0},
  {"eudb_open", (int (*)())_1eudb_open, 350, -1, 2, 0},
  {"eudb_select", (int (*)())_1eudb_select, 351, -1, 1, 0},
  {"eudb_close", (int (*)())_1eudb_close, 352, -1, 0, 0},
  {"eudb_select_table", (int (*)())_1eudb_select_table, 353, -1, 1, 0},
  {"eudb_create_table", (int (*)())_1eudb_create_table, 354, -1, 1, 0},
  {"eudb_delete_table", (int (*)())_1eudb_delete_table, 355, -1, 1, 0},
  {"eudb_rename_table", (int (*)())_1eudb_rename_table, 356, -1, 2, 0},
  {"eudb_table_list", (int (*)())_1eudb_table_list, 357, -1, 0, 0},
  {"eudb_find_key", (int (*)())_1eudb_find_key, 358, -1, 1, 0},
  {"eudb_insert", (int (*)())_1eudb_insert, 359, -1, 2, 0},
  {"eudb_delete_record", (int (*)())_1eudb_delete_record, 360, -1, 1, 0},
  {"eudb_replace_data", (int (*)())_1eudb_replace_data, 361, -1, 2, 0},
  {"eudb_table_size", (int (*)())_1eudb_table_size, 362, -1, 0, 0},
  {"eudb_record_data", (int (*)())_1eudb_record_data, 363, -1, 1, 0},
  {"eudb_record_key", (int (*)())_1eudb_record_key, 364, -1, 1, 0},
  {"eudb_compress", (int (*)())_1eudb_compress, 365, -1, 0, 0},
  {"eu_call_func_std", (int (*)())_1eu_call_func_std, 366, -1, 2, 0},
  {"eu_call_func_val", (int (*)())_1eu_call_func_val, 367, -1, 2, 0},
  {"eu_call_func", (int (*)())_1eu_call_func, 368, -1, 2, 0},
  {"eu_call_proc", (int (*)())_1eu_call_proc, 369, -1, 2, 0},
  {"eu_routine_id", (int (*)())_1eu_routine_id, 370, -1, 1, 0},
  {"eu_routine_id_str", (int (*)())_1eu_routine_id_str, 371, -1, 2, 0},
  {"", 0, 999999999, 0, 0, 0}
};

struct ns_list _01[] = {
  {"", 0, 999999999, 0}
};

void init_literal()
{
    extern double sqrt();
    _202 = NewString("");
    _2006 = NewDouble((double)-2.1474836480000000e+09);
    _2005 = NewDouble((double)2.1474836480000000e+09);
    _2011 = NewDouble((double)2.1474836470000000e+09);
    _2008 = NewDouble((double)4.2949672950000000e+09);
    _2019 = NewDouble((double)3.4896609280000000e+09);
    _2018 = NewDouble((double)2.9527900160000000e+09);
    _2017 = NewDouble((double)2.6843545600000000e+09);
    _2016 = NewDouble((double)2.4159191040000000e+09);
    _2015 = NewDouble((double)4.0265318400000000e+09);
    _1976 = NewString("couldn't insert into new database");
    _1934 = NewString(" ");
    _1933 = NewString("ren ");
    _1927 = NewString("\" \"");
    _1930 = NewString("ren \"");
    _1926 = NewString("mv \"");
    _1921 = NewString("r");
    _1918 = NewString("t%d");
    _1910 = NewString("no current database");
    _1896 = NewString(" \t\r\n");
    _1806 = NewString("bad record number");
    _1692 = NewString("no table selected");
    _1757 = NewDouble((double)1.5000000000000000e+00);
    _1673 = NewString("Target table name already exists");
    _1670 = NewString("Source table doesn't exist");
    _1500 = NewString(".edb");
    _711 = NewString("rb");
    _1506 = NewString("ub");
    _1027 = NewString("wb");
    _1397 = NewString("bad size in front of free block");
    _1393 = NewString("block size too big");
    _1390 = NewString("bad block address");
    _1383 = NewString("free list space is bad");
    _1376 = NewString("bad free list pointer");
    _1373 = NewString("free count is too high");
    _1367 = NewString("%d: %d bytes\n");
    _1361 = NewString("List of free blocks:\n");
    _1359 = NewString("\n\n");
    _1358 = NewString("\x01\x02\x09");
    _1357 = NewString("  data: ");
    _1355 = NewString("\x01\x02\x08");
    _1354 = NewString("  key: ");
    _1341 = NewString("\nblock #%d\n\n");
    _1337 = NewString("\ntable \"%s\":\n");
    _1330 = NewString("s\n");
    _1329 = NewString("\n");
    _1324 = NewString("The \"%s\" database has %d table");
    _1320 = NewString("Euphoria Database System Version %d.%d\n\n");
    _1317 = NewString("This is not a Euphoria Database file\n");
    _1313 = NewString("%d, ");
    _1312 = NewString("\n%d: ");
    _1306 = NewString("seek to position %d failed!\n");
    _1188 = NewString("string is missing 0 terminator");
    _1173 = NewString("default_fatal");
    _1170 = NewString("Fatal Database Error: ");
    _1169 = NewString("\\/");
    _1168 = NewString("/");
    _967 = NewString("BM");
    _573 = NewString("A number from %g to %g is expected here - try again\n");
    _562 = NewString("A number is expected - try again\n");
    _442 = NewString("\n\t'\"\\\r");
    _441 = NewString("nt'\"\\r");
    _439 = NewString(" \t\n\r");
    _425 = NewString("-+.#");
    _423 = NewString("ABCDEF");
    _422 = NewString("0123456789");
    _396 = NewString("..");
    _395 = NewString(".");
    _315 = NewDouble((double)1.0000000000000000e+00);
    _305 = NewDouble((double)2.0000000000000000e+00);
    _304 = NewDouble((double)3.1415926535897931e+00);
    _187 = NewString("%.10g");
    _280 = NewString("%d");
    _272 = NewString(" ...");
    _258 = NewString("\t\r\n");
    _230 = NewString("\t\n\r");
    _221 = NewString("\\r");
    _218 = NewString("\\n");
    _216 = NewString("\\t");
    _198 = NewString("}");
    _189 = NewString("{");
    _152 = NewDouble((double)3.5000000000000000e+00);
}
