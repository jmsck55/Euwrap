// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_11db_create(int _path, int _lock_method)
{
    int _db;
    int _1498 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method)) {
        _1 = (long)(DBL_PTR(_lock_method)->dbl);
        DeRefDS(_lock_method);
        _lock_method = _1;
    }

    //     if not find('.', path) then
    _1498 = find(46, _path);
    if (_1498 != 0)
        goto L1;

    // 	path &= ".edb"
    Concat((object_ptr)&_path, _path, (s1_ptr)_1500);
L1:

    //     db = open(path, "rb")
    _db = EOpen(_path, _711);

    //     if db != -1 then
    if (_db == -1)
        goto L2;

    // 	close(db)
    EClose(_db);

    // 	return DB_EXISTS_ALREADY
    DeRefDS(_path);
    DeRef(_1498);
    return -2;
L2:

    //     db = open(path, "wb")
    _db = EOpen(_path, _1027);

    //     if db = -1 then
    if (_db != -1)
        goto L3;

    // 	return DB_OPEN_FAIL
    DeRefDS(_path);
    DeRef(_1498);
    return -1;
L3:

    //     close(db)
    EClose(_db);

    //     db = open(path, "ub")
    _db = EOpen(_path, _1506);

    //     if db = -1 then
    if (_db != -1)
        goto L4;

    // 	return DB_OPEN_FAIL
    DeRefDS(_path);
    DeRef(_1498);
    return -1;
L4:

    //     if lock_method = DB_LOCK_SHARED then
    if (_lock_method != 1)
        goto L5;

    // 	lock_method = DB_LOCK_NO
    _lock_method = 0;
L5:

    //     if lock_method = DB_LOCK_EXCLUSIVE then
    if (_lock_method != 2)
        goto L6;

    // 	if not lock_file(db, LOCK_EXCLUSIVE,{}) then
    RefDS(_202);
    _0 = _1498;
    _1498 = _4lock_file(_db, 2, _202);
    DeRef(_0);
    if (_1498 != 0)
        goto L7;

    // 	    return DB_LOCK_FAIL
    DeRefDS(_path);
    return -3;
L7:
L6:

    //     current_db = db
    _11current_db = _db;

    //     current_lock = lock_method
    _11current_lock = _lock_method;

    //     current_table = -1
    DeRef(_11current_table);
    _11current_table = -1;

    //     db_names = append(db_names, path)
    RefDS(_path);
    Append(&_11db_names, _11db_names, _path);

    //     db_lock_methods = append(db_lock_methods, lock_method)
    Append(&_11db_lock_methods, _11db_lock_methods, _lock_method);

    //     db_file_nums = append(db_file_nums, db)
    Append(&_11db_file_nums, _11db_file_nums, _db);

    //     put1(DB_MAGIC) -- so we know what type of file it is
    _11put1(77);

    //     put1(DB_MAJOR) -- major version
    _11put1(3);

    //     put1(DB_MINOR) -- minor version
    _11put1(0);

    //     put4(19)  -- pointer to tables
    _11put4(19);

    //     put4(0)   -- number of free blocks
    _11put4(0);

    //     put4(23 + INIT_TABLES * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list
    DeRef(_1498);
    _1498 = 80;
    _1498 = 103;
    _1498 = 107;
    _11put4(107);

    //     put4( 8 + INIT_TABLES * SIZEOF_TABLE_HEADER)  -- allocated size
    _1498 = 80;
    _1498 = 88;
    _11put4(88);

    //     put4(0)   -- number of tables that currently exist
    _11put4(0);

    //     putn(repeat(0, INIT_TABLES * SIZEOF_TABLE_HEADER)) 
    _1498 = 80;
    _1498 = Repeat(0, 80);
    RefDS(_1498);
    _11putn(_1498);

    //     put4(4+INIT_FREE*8)   -- allocated size
    DeRefDSi(_1498);
    _1498 = 40;
    _1498 = 44;
    _11put4(44);

    //     putn(repeat(0, INIT_FREE * 8))
    _1498 = 40;
    _1498 = Repeat(0, 40);
    RefDS(_1498);
    _11putn(_1498);

    //     return DB_OK
    DeRefDS(_path);
    DeRefDSi(_1498);
    return 0;
    ;
}


_11db_open(int _path, int _lock_method)
{
    int _db;
    int _magic;
    int _1532;
    int _1527;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lock_method)) {
        _1 = (long)(DBL_PTR(_lock_method)->dbl);
        DeRefDS(_lock_method);
        _lock_method = _1;
    }

    //     if not find('.', path) then
    _1527 = find(46, _path);
    if (_1527 != 0)
        goto L1;

    // 	path &= ".edb"
    Concat((object_ptr)&_path, _path, (s1_ptr)_1500);
L1:

    //     if lock_method = DB_LOCK_NO or 
    _1527 = (_lock_method == 0);
    if (_1527 != 0) {
        goto L2;
    }
    _1532 = (_lock_method == 2);
L3:
    if (_1532 == 0)
        goto L4;
L2:

    // 	db = open(path, "ub")
    _db = EOpen(_path, _1506);
    goto L5;
L4:

    // 	db = open(path, "rb")
    _db = EOpen(_path, _711);
L5:

    //     if db = -1 then
    if (_db != -1)
        goto L6;

    // 	return DB_OPEN_FAIL
    DeRefDS(_path);
    return -1;
L6:

    //     if lock_method = DB_LOCK_EXCLUSIVE then
    if (_lock_method != 2)
        goto L7;

    // 	if not lock_file(db, LOCK_EXCLUSIVE, {}) then
    RefDS(_202);
    _1532 = _4lock_file(_db, 2, _202);
    if (_1532 != 0)
        goto L8;

    // 	    close(db)
    EClose(_db);

    // 	    return DB_LOCK_FAIL
    DeRefDS(_path);
    return -3;
L9:
    goto L8;
L7:

    //     elsif lock_method = DB_LOCK_SHARED then
    if (_lock_method != 1)
        goto LA;

    // 	if not lock_file(db, LOCK_SHARED, {}) then
    RefDS(_202);
    _1532 = _4lock_file(_db, 1, _202);
    if (_1532 != 0)
        goto LB;

    // 	    close(db)
    EClose(_db);

    // 	    return DB_LOCK_FAIL
    DeRefDS(_path);
    return -3;
LB:
LA:
L8:

    //     magic = getc(db)
    if (_db != last_r_file_no) {
        last_r_file_ptr = which_file(_db, EF_READ);
        last_r_file_no = _db;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic = getc(xstdin);
        }
        else
            _magic = getc(last_r_file_ptr);
    }
    else
        _magic = getc(last_r_file_ptr);

    //     if magic != DB_MAGIC then
    if (_magic == 77)
        goto LC;

    // 	close(db)
    EClose(_db);

    // 	return DB_OPEN_FAIL
    DeRefDS(_path);
    return -1;
LC:

    //     current_db = db
    _11current_db = _db;

    //     current_table = -1
    DeRef(_11current_table);
    _11current_table = -1;

    //     current_lock = lock_method
    _11current_lock = _lock_method;

    //     db_names = append(db_names, path)
    RefDS(_path);
    Append(&_11db_names, _11db_names, _path);

    //     db_lock_methods = append(db_lock_methods, lock_method)
    Append(&_11db_lock_methods, _11db_lock_methods, _lock_method);

    //     db_file_nums = append(db_file_nums, db)
    Append(&_11db_file_nums, _11db_file_nums, _db);

    //     return DB_OK
    DeRefDS(_path);
    return 0;
    ;
}


_11db_select(int _path)
{
    int _index;
    int _1547;
    int _0, _1, _2;
    

    //     if not find('.', path) then
    _1547 = find(46, _path);
    if (_1547 != 0)
        goto L1;

    // 	path &= ".edb"
    Concat((object_ptr)&_path, _path, (s1_ptr)_1500);
L1:

    //     index = find(path, db_names)
    _index = find(_path, _11db_names);

    //     if index = 0 then 
    if (_index != 0)
        goto L2;

    // 	return DB_OPEN_FAIL 
    DeRefDS(_path);
    return -1;
L2:

    //     current_db = db_file_nums[index]
    _2 = (int)SEQ_PTR(_11db_file_nums);
    _11current_db = (int)*(((s1_ptr)_2)->base + _index);
    if (!IS_ATOM_INT(_11current_db))
        _11current_db = (long)DBL_PTR(_11current_db)->dbl;

    //     current_lock = db_lock_methods[index]
    _2 = (int)SEQ_PTR(_11db_lock_methods);
    _11current_lock = (int)*(((s1_ptr)_2)->base + _index);
    if (!IS_ATOM_INT(_11current_lock))
        _11current_lock = (long)DBL_PTR(_11current_lock)->dbl;

    //     current_table = -1
    DeRef(_11current_table);
    _11current_table = -1;

    //     return DB_OK
    DeRefDS(_path);
    return 0;
    ;
}


_11db_close()
{
    int _index;
    int _1559 = 0;
    int _1558;
    int _1554 = 0;
    int _0, _1, _2;
    

    //     if current_db = -1 then
    if (_11current_db != -1)
        goto L1;

    // 	return
    return 0;
L1:

    //     if current_lock then
    if (_11current_lock == 0)
        goto L2;

    // 	unlock_file(current_db, {})
    RefDS(_202);
    _4unlock_file(_11current_db, _202);
L2:

    //     close(current_db)
    EClose(_11current_db);

    //     index = find(current_db, db_file_nums)
    _index = find(_11current_db, _11db_file_nums);

    // 	   db_names = db_names[1..index-1] & db_names[index+1..$]
    DeRef(_1554);
    _1554 = _index - 1;
    rhs_slice_target = (object_ptr)&_1554;
    RHS_Slice((s1_ptr)_11db_names, 1, _1554);
    _1558 = _index + 1;
    DeRef(_1559);
    _1559 = SEQ_PTR(_11db_names)->length;
    rhs_slice_target = (object_ptr)&_1559;
    RHS_Slice((s1_ptr)_11db_names, _1558, _1559);
    Concat((object_ptr)&_11db_names, _1554, (s1_ptr)_1559);

    //        db_file_nums = db_file_nums[1..index-1] & db_file_nums[index+1..$]
    DeRefDS(_1559);
    _1559 = _index - 1;
    rhs_slice_target = (object_ptr)&_1559;
    RHS_Slice((s1_ptr)_11db_file_nums, 1, _1559);
    _1558 = _index + 1;
    DeRefDS(_1554);
    _1554 = SEQ_PTR(_11db_file_nums)->length;
    rhs_slice_target = (object_ptr)&_1554;
    RHS_Slice((s1_ptr)_11db_file_nums, _1558, _1554);
    Concat((object_ptr)&_11db_file_nums, _1559, (s1_ptr)_1554);

    //     db_lock_methods = db_lock_methods[1..index-1] & db_lock_methods[index+1..$]
    DeRefDS(_1554);
    _1554 = _index - 1;
    rhs_slice_target = (object_ptr)&_1554;
    RHS_Slice((s1_ptr)_11db_lock_methods, 1, _1554);
    _1558 = _index + 1;
    DeRefDS(_1559);
    _1559 = SEQ_PTR(_11db_lock_methods)->length;
    rhs_slice_target = (object_ptr)&_1559;
    RHS_Slice((s1_ptr)_11db_lock_methods, _1558, _1559);
    Concat((object_ptr)&_11db_lock_methods, _1554, (s1_ptr)_1559);

    //     current_db = -1 
    _11current_db = -1;

    // end procedure
    DeRefDS(_1559);
    DeRefDS(_1554);
    return 0;
    ;
}


int _11table_find(int _name)
{
    int _tables = 0;
    int _nt = 0;
    int _t_header = 0;
    int _name_ptr = 0;
    int _tname = 0;
    int _1578;
    int _1574 = 0;
    int _0, _1, _2;
    

    //     safe_seek(TABLE_HEADERS)
    _11safe_seek(3);

    //     tables = get4()
    _tables = _11get4();

    //     safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    //     nt = get4()
    _nt = _11get4();

    //     t_header = tables+4
    if (IS_ATOM_INT(_tables)) {
        _t_header = _tables + 4;
        if ((long)((unsigned long)_t_header + (unsigned long)HIGH_BITS) >= 0) 
            _t_header = NewDouble((double)_t_header);
    }
    else {
        _t_header = NewDouble(DBL_PTR(_tables)->dbl + (double)4);
    }

    //     for i = 1 to nt do
    Ref(_nt);
    _1574 = _nt;
    { int _i;
        _i = 1;
L1:
        if (binary_op_a(GREATER, _i, _1574))
            goto L2;

        // 	safe_seek(t_header)
        Ref(_t_header);
        _11safe_seek(_t_header);

        // 	name_ptr = get4()
        _0 = _name_ptr;
        _name_ptr = _11get4();
        DeRef(_0);

        // 	safe_seek(name_ptr)
        Ref(_name_ptr);
        _11safe_seek(_name_ptr);

        // 	tname = get_string()
        _0 = _tname;
        _tname = _11get_string();
        DeRefi(_0);

        // 	if equal(tname, name) then
        if (_tname == _name)
            _1578 = 1;
        else if (IS_ATOM_INT(_tname) && IS_ATOM_INT(_name))
            _1578 = 0;
        else
            _1578 = (compare(_tname, _name) == 0);
        if (_1578 == 0)
            goto L3;

        // 	    return t_header
        DeRef(_i);
        DeRefDS(_name);
        DeRef(_tables);
        DeRef(_nt);
        DeRef(_name_ptr);
        DeRefDSi(_tname);
        DeRef(_1574);
        return _t_header;
L3:

        // 	t_header += SIZEOF_TABLE_HEADER
        _0 = _t_header;
        if (IS_ATOM_INT(_t_header)) {
            _t_header = _t_header + 16;
            if ((long)((unsigned long)_t_header + (unsigned long)HIGH_BITS) >= 0) 
                _t_header = NewDouble((double)_t_header);
        }
        else {
            _t_header = NewDouble(DBL_PTR(_t_header)->dbl + (double)16);
        }
        DeRef(_0);

        //     end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L1;
L2:
        ;
        DeRef(_i);
    }

    //     return -1
    DeRefDS(_name);
    DeRef(_tables);
    DeRef(_nt);
    DeRef(_t_header);
    DeRef(_name_ptr);
    DeRefi(_tname);
    DeRef(_1574);
    return -1;
    ;
}


_11db_select_table(int _name)
{
    int _table = 0;
    int _nkeys = 0;
    int _index = 0;
    int _block_ptr = 0;
    int _block_size = 0;
    int _blocks;
    int _k;
    int _1594 = 0;
    int _1591 = 0;
    int _1582 = 0;
    int _0, _1, _2;
    

    //     table = table_find(name)
    RefDS(_name);
    _table = _11table_find(_name);

    //     if table = -1 then
    if (binary_op_a(NOTEQ, _table, -1))
        goto L1;

    // 	return DB_OPEN_FAIL
    DeRefDS(_name);
    DeRef(_table);
    return -1;
L1:

    //     if current_table = table then
    if (binary_op_a(NOTEQ, _11current_table, _table))
        goto L2;

    // 	return DB_OK -- nothing to do
    DeRefDS(_name);
    DeRef(_table);
    DeRef(_nkeys);
    DeRef(_index);
    DeRef(_block_ptr);
    DeRef(_block_size);
    DeRef(_1594);
    DeRef(_1591);
    DeRef(_1582);
    return 0;
L2:

    //     current_table = table
    Ref(_table);
    DeRef(_11current_table);
    _11current_table = _table;

    //     safe_seek(table+4)
    DeRef(_1582);
    if (IS_ATOM_INT(_table)) {
        _1582 = _table + 4;
        if ((long)((unsigned long)_1582 + (unsigned long)HIGH_BITS) >= 0) 
            _1582 = NewDouble((double)_1582);
    }
    else {
        _1582 = NewDouble(DBL_PTR(_table)->dbl + (double)4);
    }
    Ref(_1582);
    _11safe_seek(_1582);

    //     nkeys = get4()
    _0 = _nkeys;
    _nkeys = _11get4();
    DeRef(_0);

    //     blocks = get4()
    _blocks = _11get4();
    if (!IS_ATOM_INT(_blocks)) {
        _1 = (long)(DBL_PTR(_blocks)->dbl);
        DeRefDS(_blocks);
        _blocks = _1;
    }

    //     index = get4()
    _0 = _index;
    _index = _11get4();
    DeRef(_0);

    //     key_pointers = repeat(0, nkeys)
    DeRef(_11key_pointers);
    _11key_pointers = Repeat(0, _nkeys);

    //     k = 1
    _k = 1;

    //     for b = 0 to blocks-1 do
    DeRef(_1582);
    _1582 = _blocks - 1;
    if ((long)((unsigned long)_1582 +(unsigned long) HIGH_BITS) >= 0)
        _1582 = NewDouble((double)_1582);
    { int _b;
        _b = 0;
L3:
        if (binary_op_a(GREATER, _b, _1582))
            goto L4;

        // 	safe_seek(index)
        Ref(_index);
        _11safe_seek(_index);

        // 	block_size = get4()
        _0 = _block_size;
        _block_size = _11get4();
        DeRef(_0);

        // 	block_ptr = get4()
        _0 = _block_ptr;
        _block_ptr = _11get4();
        DeRef(_0);

        // 	safe_seek(block_ptr)
        Ref(_block_ptr);
        _11safe_seek(_block_ptr);

        // 	for j = 1 to block_size do
        Ref(_block_size);
        DeRef(_1591);
        _1591 = _block_size;
        { int _j;
            _j = 1;
L5:
            if (binary_op_a(GREATER, _j, _1591))
                goto L6;

            // 	    key_pointers[k] = get4()
            _0 = _1594;
            _1594 = _11get4();
            DeRef(_0);
            Ref(_1594);
            _2 = (int)SEQ_PTR(_11key_pointers);
            _2 = (int)(((s1_ptr)_2)->base + _k);
            _1 = *(int *)_2;
            *(int *)_2 = _1594;
            DeRef(_1);

            // 	    k += 1
            _k = _k + 1;

            // 	end for
            _0 = _j;
            if (IS_ATOM_INT(_j)) {
                _j = _j + 1;
                if ((long)((unsigned long)_j +(unsigned long) HIGH_BITS) >= 0) 
                    _j = NewDouble((double)_j);
            }
            else {
                _j = binary_op_a(PLUS, _j, 1);
            }
            DeRef(_0);
            goto L5;
L6:
            ;
            DeRef(_j);
        }

        // 	index += 8
        _0 = _index;
        if (IS_ATOM_INT(_index)) {
            _index = _index + 8;
            if ((long)((unsigned long)_index + (unsigned long)HIGH_BITS) >= 0) 
                _index = NewDouble((double)_index);
        }
        else {
            _index = NewDouble(DBL_PTR(_index)->dbl + (double)8);
        }
        DeRef(_0);

        //     end for
        _0 = _b;
        if (IS_ATOM_INT(_b)) {
            _b = _b + 1;
            if ((long)((unsigned long)_b +(unsigned long) HIGH_BITS) >= 0) 
                _b = NewDouble((double)_b);
        }
        else {
            _b = binary_op_a(PLUS, _b, 1);
        }
        DeRef(_0);
        goto L3;
L4:
        ;
        DeRef(_b);
    }

    //     return DB_OK
    DeRefDS(_name);
    DeRef(_table);
    DeRef(_nkeys);
    DeRef(_index);
    DeRef(_block_ptr);
    DeRef(_block_size);
    DeRef(_1594);
    DeRef(_1591);
    DeRef(_1582);
    return 0;
    ;
}


_11db_create_table(int _name)
{
    int _name_ptr = 0;
    int _nt = 0;
    int _tables = 0;
    int _newtables = 0;
    int _table = 0;
    int _records_ptr = 0;
    int _size = 0;
    int _newsize = 0;
    int _index_ptr = 0;
    int _remaining = 0;
    int _1597 = 0;
    int _1616 = 0;
    int _0, _1, _2;
    

    //     table = table_find(name)
    RefDS(_name);
    _table = _11table_find(_name);

    //     if table != -1 then
    if (binary_op_a(EQUALS, _table, -1))
        goto L1;

    // 	return DB_EXISTS_ALREADY
    DeRefDS(_name);
    DeRef(_table);
    return -2;
L1:

    //     safe_seek(TABLE_HEADERS)
    _11safe_seek(3);

    //     tables = get4()
    _0 = _tables;
    _tables = _11get4();
    DeRef(_0);

    //     safe_seek(tables-4)
    DeRef(_1597);
    if (IS_ATOM_INT(_tables)) {
        _1597 = _tables - 4;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0)
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_tables)->dbl - (double)4);
    }
    Ref(_1597);
    _11safe_seek(_1597);

    //     size = get4()
    _0 = _size;
    _size = _11get4();
    DeRef(_0);

    //     nt = get4()+1
    _0 = _1597;
    _1597 = _11get4();
    DeRef(_0);
    DeRef(_nt);
    if (IS_ATOM_INT(_1597)) {
        _nt = _1597 + 1;
        if (_nt > MAXINT)
            _nt = NewDouble((double)_nt);
    }
    else
        _nt = binary_op(PLUS, 1, _1597);

    //     if nt*SIZEOF_TABLE_HEADER + 8 > size then
    DeRef(_1597);
    if (IS_ATOM_INT(_nt)) {
        if (_nt == (short)_nt)
            _1597 = _nt * 16;
        else
            _1597 = NewDouble(_nt * (double)16);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_nt)->dbl * (double)16);
    }
    _0 = _1597;
    if (IS_ATOM_INT(_1597)) {
        _1597 = _1597 + 8;
        if ((long)((unsigned long)_1597 + (unsigned long)HIGH_BITS) >= 0) 
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_1597)->dbl + (double)8);
    }
    DeRef(_0);
    if (binary_op_a(LESSEQ, _1597, _size))
        goto L2;

    // 	newsize = floor(size * 3 / 2)
    DeRef(_1597);
    if (IS_ATOM_INT(_size)) {
        if (_size == (short)_size)
            _1597 = _size * 3;
        else
            _1597 = NewDouble(_size * (double)3);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_size)->dbl * (double)3);
    }
    DeRef(_newsize);
    if (IS_ATOM_INT(_1597)) {
        _newsize = _1597 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1597, 2);
        _newsize = unary_op(FLOOR, _1);
        DeRef(_1);
    }

    // 	newtables = db_allocate(newsize)
    Ref(_newsize);
    _0 = _newtables;
    _newtables = _11db_allocate(_newsize);
    DeRef(_0);

    // 	put4(nt)
    Ref(_nt);
    _11put4(_nt);

    // 	safe_seek(tables+4)
    DeRef(_1597);
    if (IS_ATOM_INT(_tables)) {
        _1597 = _tables + 4;
        if ((long)((unsigned long)_1597 + (unsigned long)HIGH_BITS) >= 0) 
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_tables)->dbl + (double)4);
    }
    Ref(_1597);
    _11safe_seek(_1597);

    // 	remaining = get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)
    DeRef(_1597);
    if (IS_ATOM_INT(_nt)) {
        _1597 = _nt - 1;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0)
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_nt)->dbl - (double)1);
    }
    _0 = _1597;
    if (IS_ATOM_INT(_1597)) {
        if (_1597 == (short)_1597)
            _1597 = _1597 * 16;
        else
            _1597 = NewDouble(_1597 * (double)16);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_1597)->dbl * (double)16);
    }
    DeRef(_0);
    Ref(_1597);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1597);
    DeRefi(_0);

    // 	safe_seek(newtables+4)
    DeRef(_1597);
    if (IS_ATOM_INT(_newtables)) {
        _1597 = _newtables + 4;
        if ((long)((unsigned long)_1597 + (unsigned long)HIGH_BITS) >= 0) 
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_newtables)->dbl + (double)4);
    }
    Ref(_1597);
    _11safe_seek(_1597);

    // 	putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))
    DeRef(_1597);
    if (IS_ATOM_INT(_newsize)) {
        _1597 = _newsize - 4;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0)
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_newsize)->dbl - (double)4);
    }
    DeRef(_1616);
    if (IS_ATOM_INT(_nt)) {
        _1616 = _nt - 1;
        if ((long)((unsigned long)_1616 +(unsigned long) HIGH_BITS) >= 0)
            _1616 = NewDouble((double)_1616);
    }
    else {
        _1616 = NewDouble(DBL_PTR(_nt)->dbl - (double)1);
    }
    _0 = _1616;
    if (IS_ATOM_INT(_1616)) {
        if (_1616 == (short)_1616)
            _1616 = _1616 * 16;
        else
            _1616 = NewDouble(_1616 * (double)16);
    }
    else {
        _1616 = NewDouble(DBL_PTR(_1616)->dbl * (double)16);
    }
    DeRef(_0);
    _0 = _1616;
    if (IS_ATOM_INT(_1597) && IS_ATOM_INT(_1616)) {
        _1616 = _1597 - _1616;
    }
    else {
        if (IS_ATOM_INT(_1597)) {
            _1616 = NewDouble((double)_1597 - DBL_PTR(_1616)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1616)) {
                _1616 = NewDouble(DBL_PTR(_1597)->dbl - (double)_1616);
            }
            else
                _1616 = NewDouble(DBL_PTR(_1597)->dbl - DBL_PTR(_1616)->dbl);
        }
    }
    DeRef(_0);
    _0 = _1616;
    _1616 = Repeat(0, _1616);
    DeRef(_0);
    RefDS(_1616);
    _11putn(_1616);

    // 	db_free(tables)
    Ref(_tables);
    _11db_free(_tables);

    // 	safe_seek(TABLE_HEADERS)
    _11safe_seek(3);

    // 	put4(newtables)
    Ref(_newtables);
    _11put4(_newtables);

    // 	tables = newtables
    Ref(_newtables);
    DeRef(_tables);
    _tables = _newtables;
    goto L3;
L2:

    // 	safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    // 	put4(nt)
    Ref(_nt);
    _11put4(_nt);
L3:

    //     records_ptr = db_allocate(INIT_RECORDS * 4)
    DeRef(_1616);
    _1616 = 200;
    _0 = _records_ptr;
    _records_ptr = _11db_allocate(200);
    DeRef(_0);

    //     putn(repeat(0, INIT_RECORDS * 4))
    _1616 = 200;
    _1616 = Repeat(0, 200);
    RefDS(_1616);
    _11putn(_1616);

    //     index_ptr = db_allocate(INIT_INDEX * 8)
    DeRefDSi(_1616);
    _1616 = 80;
    _0 = _index_ptr;
    _index_ptr = _11db_allocate(80);
    DeRef(_0);

    //     put4(0)  -- 0 records 
    _11put4(0);

    //     put4(records_ptr) -- point to 1st block
    Ref(_records_ptr);
    _11put4(_records_ptr);

    //     putn(repeat(0, (INIT_INDEX-1) * 8))
    _1616 = 9;
    _1616 = 72;
    _1616 = Repeat(0, 72);
    RefDS(_1616);
    _11putn(_1616);

    //     name_ptr = db_allocate(length(name)+1)
    DeRefDSi(_1616);
    _1616 = SEQ_PTR(_name)->length;
    _1616 = _1616 + 1;
    _0 = _name_ptr;
    _name_ptr = _11db_allocate(_1616);
    DeRef(_0);

    //     putn(name & 0)
    Append(&_1616, _name, 0);
    RefDS(_1616);
    _11putn(_1616);

    //     safe_seek(tables+4+(nt-1)*SIZEOF_TABLE_HEADER)
    DeRefDS(_1616);
    if (IS_ATOM_INT(_tables)) {
        _1616 = _tables + 4;
        if ((long)((unsigned long)_1616 + (unsigned long)HIGH_BITS) >= 0) 
            _1616 = NewDouble((double)_1616);
    }
    else {
        _1616 = NewDouble(DBL_PTR(_tables)->dbl + (double)4);
    }
    DeRef(_1597);
    if (IS_ATOM_INT(_nt)) {
        _1597 = _nt - 1;
        if ((long)((unsigned long)_1597 +(unsigned long) HIGH_BITS) >= 0)
            _1597 = NewDouble((double)_1597);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_nt)->dbl - (double)1);
    }
    _0 = _1597;
    if (IS_ATOM_INT(_1597)) {
        if (_1597 == (short)_1597)
            _1597 = _1597 * 16;
        else
            _1597 = NewDouble(_1597 * (double)16);
    }
    else {
        _1597 = NewDouble(DBL_PTR(_1597)->dbl * (double)16);
    }
    DeRef(_0);
    _0 = _1597;
    if (IS_ATOM_INT(_1616) && IS_ATOM_INT(_1597)) {
        _1597 = _1616 + _1597;
        if ((long)((unsigned long)_1597 + (unsigned long)HIGH_BITS) >= 0) 
            _1597 = NewDouble((double)_1597);
    }
    else {
        if (IS_ATOM_INT(_1616)) {
            _1597 = NewDouble((double)_1616 + DBL_PTR(_1597)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1597)) {
                _1597 = NewDouble(DBL_PTR(_1616)->dbl + (double)_1597);
            }
            else
                _1597 = NewDouble(DBL_PTR(_1616)->dbl + DBL_PTR(_1597)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1597);
    _11safe_seek(_1597);

    //     put4(name_ptr)
    Ref(_name_ptr);
    _11put4(_name_ptr);

    //     put4(0)  -- start with 0 records total
    _11put4(0);

    //     put4(1)  -- start with 1 block of records in index
    _11put4(1);

    //     put4(index_ptr)
    Ref(_index_ptr);
    _11put4(_index_ptr);

    //     if db_select_table(name) then
    RefDS(_name);
    _0 = _1597;
    _1597 = _11db_select_table(_name);
    DeRef(_0);
    if (_1597 == 0)
        goto L4;
L4:

    //     return DB_OK
    DeRefDS(_name);
    DeRef(_name_ptr);
    DeRef(_nt);
    DeRef(_tables);
    DeRef(_newtables);
    DeRef(_table);
    DeRef(_records_ptr);
    DeRef(_size);
    DeRef(_newsize);
    DeRef(_index_ptr);
    DeRefi(_remaining);
    DeRef(_1597);
    DeRef(_1616);
    return 0;
    ;
}


_11db_delete_table(int _name)
{
    int _table = 0;
    int _tables = 0;
    int _nt = 0;
    int _nrecs = 0;
    int _records_ptr = 0;
    int _blocks = 0;
    int _p = 0;
    int _data_ptr = 0;
    int _index = 0;
    int _remaining = 0;
    int _1651 = 0;
    int _1646 = 0;
    int _1638 = 0;
    int _0, _1, _2;
    

    //     table = table_find(name)
    RefDS(_name);
    _table = _11table_find(_name);

    //     if table = -1 then
    if (binary_op_a(NOTEQ, _table, -1))
        goto L1;

    // 	return 
    DeRefDS(_name);
    DeRef(_table);
    return 0;
L1:

    //     safe_seek(table)
    Ref(_table);
    _11safe_seek(_table);

    //     db_free(get4())
    _0 = _1638;
    _1638 = _11get4();
    DeRef(_0);
    Ref(_1638);
    _11db_free(_1638);

    //     safe_seek(table+4)
    DeRef(_1638);
    if (IS_ATOM_INT(_table)) {
        _1638 = _table + 4;
        if ((long)((unsigned long)_1638 + (unsigned long)HIGH_BITS) >= 0) 
            _1638 = NewDouble((double)_1638);
    }
    else {
        _1638 = NewDouble(DBL_PTR(_table)->dbl + (double)4);
    }
    Ref(_1638);
    _11safe_seek(_1638);

    //     nrecs = get4()
    _0 = _nrecs;
    _nrecs = _11get4();
    DeRef(_0);

    //     blocks = get4()
    _0 = _blocks;
    _blocks = _11get4();
    DeRef(_0);

    //     index = get4()
    _0 = _index;
    _index = _11get4();
    DeRef(_0);

    //     for b = 0 to blocks-1 do
    DeRef(_1638);
    if (IS_ATOM_INT(_blocks)) {
        _1638 = _blocks - 1;
        if ((long)((unsigned long)_1638 +(unsigned long) HIGH_BITS) >= 0)
            _1638 = NewDouble((double)_1638);
    }
    else {
        _1638 = NewDouble(DBL_PTR(_blocks)->dbl - (double)1);
    }
    { int _b;
        _b = 0;
L2:
        if (binary_op_a(GREATER, _b, _1638))
            goto L3;

        // 	safe_seek(index+b*8)
        DeRef(_1646);
        if (IS_ATOM_INT(_b)) {
            if (_b == (short)_b)
                _1646 = _b * 8;
            else
                _1646 = NewDouble(_b * (double)8);
        }
        else {
            _1646 = NewDouble(DBL_PTR(_b)->dbl * (double)8);
        }
        _0 = _1646;
        if (IS_ATOM_INT(_index) && IS_ATOM_INT(_1646)) {
            _1646 = _index + _1646;
            if ((long)((unsigned long)_1646 + (unsigned long)HIGH_BITS) >= 0) 
                _1646 = NewDouble((double)_1646);
        }
        else {
            if (IS_ATOM_INT(_index)) {
                _1646 = NewDouble((double)_index + DBL_PTR(_1646)->dbl);
            }
            else {
                if (IS_ATOM_INT(_1646)) {
                    _1646 = NewDouble(DBL_PTR(_index)->dbl + (double)_1646);
                }
                else
                    _1646 = NewDouble(DBL_PTR(_index)->dbl + DBL_PTR(_1646)->dbl);
            }
        }
        DeRef(_0);
        Ref(_1646);
        _11safe_seek(_1646);

        // 	nrecs = get4()
        _0 = _nrecs;
        _nrecs = _11get4();
        DeRef(_0);

        // 	records_ptr = get4()
        _0 = _records_ptr;
        _records_ptr = _11get4();
        DeRef(_0);

        // 	for r = 0 to nrecs-1 do
        DeRef(_1646);
        if (IS_ATOM_INT(_nrecs)) {
            _1646 = _nrecs - 1;
            if ((long)((unsigned long)_1646 +(unsigned long) HIGH_BITS) >= 0)
                _1646 = NewDouble((double)_1646);
        }
        else {
            _1646 = NewDouble(DBL_PTR(_nrecs)->dbl - (double)1);
        }
        { int _r;
            _r = 0;
L4:
            if (binary_op_a(GREATER, _r, _1646))
                goto L5;

            // 	    safe_seek(records_ptr + r*4)
            DeRef(_1651);
            if (IS_ATOM_INT(_r)) {
                if (_r == (short)_r)
                    _1651 = _r * 4;
                else
                    _1651 = NewDouble(_r * (double)4);
            }
            else {
                _1651 = NewDouble(DBL_PTR(_r)->dbl * (double)4);
            }
            _0 = _1651;
            if (IS_ATOM_INT(_records_ptr) && IS_ATOM_INT(_1651)) {
                _1651 = _records_ptr + _1651;
                if ((long)((unsigned long)_1651 + (unsigned long)HIGH_BITS) >= 0) 
                    _1651 = NewDouble((double)_1651);
            }
            else {
                if (IS_ATOM_INT(_records_ptr)) {
                    _1651 = NewDouble((double)_records_ptr + DBL_PTR(_1651)->dbl);
                }
                else {
                    if (IS_ATOM_INT(_1651)) {
                        _1651 = NewDouble(DBL_PTR(_records_ptr)->dbl + (double)_1651);
                    }
                    else
                        _1651 = NewDouble(DBL_PTR(_records_ptr)->dbl + DBL_PTR(_1651)->dbl);
                }
            }
            DeRef(_0);
            Ref(_1651);
            _11safe_seek(_1651);

            // 	    p = get4()
            _0 = _p;
            _p = _11get4();
            DeRef(_0);

            // 	    safe_seek(p)
            Ref(_p);
            _11safe_seek(_p);

            // 	    data_ptr = get4()
            _0 = _data_ptr;
            _data_ptr = _11get4();
            DeRef(_0);

            // 	    db_free(data_ptr)
            Ref(_data_ptr);
            _11db_free(_data_ptr);

            // 	    db_free(p)
            Ref(_p);
            _11db_free(_p);

            // 	end for
            _0 = _r;
            if (IS_ATOM_INT(_r)) {
                _r = _r + 1;
                if ((long)((unsigned long)_r +(unsigned long) HIGH_BITS) >= 0) 
                    _r = NewDouble((double)_r);
            }
            else {
                _r = binary_op_a(PLUS, _r, 1);
            }
            DeRef(_0);
            goto L4;
L5:
            ;
            DeRef(_r);
        }

        // 	db_free(records_ptr)
        Ref(_records_ptr);
        _11db_free(_records_ptr);

        //     end for
        _0 = _b;
        if (IS_ATOM_INT(_b)) {
            _b = _b + 1;
            if ((long)((unsigned long)_b +(unsigned long) HIGH_BITS) >= 0) 
                _b = NewDouble((double)_b);
        }
        else {
            _b = binary_op_a(PLUS, _b, 1);
        }
        DeRef(_0);
        goto L2;
L3:
        ;
        DeRef(_b);
    }

    //     db_free(index)
    Ref(_index);
    _11db_free(_index);

    //     safe_seek(TABLE_HEADERS)
    _11safe_seek(3);

    //     tables = get4()
    _0 = _tables;
    _tables = _11get4();
    DeRef(_0);

    //     safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    //     nt = get4()
    _0 = _nt;
    _nt = _11get4();
    DeRef(_0);

    //     safe_seek(table+SIZEOF_TABLE_HEADER)
    DeRef(_1651);
    if (IS_ATOM_INT(_table)) {
        _1651 = _table + 16;
        if ((long)((unsigned long)_1651 + (unsigned long)HIGH_BITS) >= 0) 
            _1651 = NewDouble((double)_1651);
    }
    else {
        _1651 = NewDouble(DBL_PTR(_table)->dbl + (double)16);
    }
    Ref(_1651);
    _11safe_seek(_1651);

    //     remaining = get_bytes(current_db, 
    DeRef(_1651);
    if (IS_ATOM_INT(_tables)) {
        _1651 = _tables + 4;
        if ((long)((unsigned long)_1651 + (unsigned long)HIGH_BITS) >= 0) 
            _1651 = NewDouble((double)_1651);
    }
    else {
        _1651 = NewDouble(DBL_PTR(_tables)->dbl + (double)4);
    }
    DeRef(_1646);
    if (IS_ATOM_INT(_nt)) {
        if (_nt == (short)_nt)
            _1646 = _nt * 16;
        else
            _1646 = NewDouble(_nt * (double)16);
    }
    else {
        _1646 = NewDouble(DBL_PTR(_nt)->dbl * (double)16);
    }
    _0 = _1646;
    if (IS_ATOM_INT(_1651) && IS_ATOM_INT(_1646)) {
        _1646 = _1651 + _1646;
        if ((long)((unsigned long)_1646 + (unsigned long)HIGH_BITS) >= 0) 
            _1646 = NewDouble((double)_1646);
    }
    else {
        if (IS_ATOM_INT(_1651)) {
            _1646 = NewDouble((double)_1651 + DBL_PTR(_1646)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1646)) {
                _1646 = NewDouble(DBL_PTR(_1651)->dbl + (double)_1646);
            }
            else
                _1646 = NewDouble(DBL_PTR(_1651)->dbl + DBL_PTR(_1646)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1651);
    if (IS_ATOM_INT(_table)) {
        _1651 = _table + 16;
        if ((long)((unsigned long)_1651 + (unsigned long)HIGH_BITS) >= 0) 
            _1651 = NewDouble((double)_1651);
    }
    else {
        _1651 = NewDouble(DBL_PTR(_table)->dbl + (double)16);
    }
    _0 = _1651;
    if (IS_ATOM_INT(_1646) && IS_ATOM_INT(_1651)) {
        _1651 = _1646 - _1651;
        if ((long)((unsigned long)_1651 +(unsigned long) HIGH_BITS) >= 0)
            _1651 = NewDouble((double)_1651);
    }
    else {
        if (IS_ATOM_INT(_1646)) {
            _1651 = NewDouble((double)_1646 - DBL_PTR(_1651)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1651)) {
                _1651 = NewDouble(DBL_PTR(_1646)->dbl - (double)_1651);
            }
            else
                _1651 = NewDouble(DBL_PTR(_1646)->dbl - DBL_PTR(_1651)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1651);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1651);
    DeRefi(_0);

    //     safe_seek(table)
    Ref(_table);
    _11safe_seek(_table);

    //     putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    //     nt -= 1
    _0 = _nt;
    if (IS_ATOM_INT(_nt)) {
        _nt = _nt - 1;
        if ((long)((unsigned long)_nt +(unsigned long) HIGH_BITS) >= 0)
            _nt = NewDouble((double)_nt);
    }
    else {
        _nt = NewDouble(DBL_PTR(_nt)->dbl - (double)1);
    }
    DeRef(_0);

    //     safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    //     put4(nt)
    Ref(_nt);
    _11put4(_nt);

    //     if table = current_table then
    if (binary_op_a(NOTEQ, _table, _11current_table))
        goto L6;

    // 	current_table = -1
    DeRef(_11current_table);
    _11current_table = -1;
    goto L7;
L6:

    //     elsif table < current_table then
    if (binary_op_a(GREATEREQ, _table, _11current_table))
        goto L8;

    // 	current_table -= SIZEOF_TABLE_HEADER
    _0 = _11current_table;
    if (IS_ATOM_INT(_11current_table)) {
        _11current_table = _11current_table - 16;
        if ((long)((unsigned long)_11current_table +(unsigned long) HIGH_BITS) >= 0)
            _11current_table = NewDouble((double)_11current_table);
    }
    else {
        _11current_table = NewDouble(DBL_PTR(_11current_table)->dbl - (double)16);
    }
    DeRef(_0);
L8:
L7:

    // end procedure
    DeRefDS(_name);
    DeRef(_table);
    DeRef(_tables);
    DeRef(_nt);
    DeRef(_nrecs);
    DeRef(_records_ptr);
    DeRef(_blocks);
    DeRef(_p);
    DeRef(_data_ptr);
    DeRef(_index);
    DeRefi(_remaining);
    DeRef(_1651);
    DeRef(_1646);
    DeRef(_1638);
    return 0;
    ;
}


_11db_rename_table(int _name, int _new_name)
{
    int _table = 0;
    int _table_ptr = 0;
    int _1668 = 0;
    int _0, _1, _2;
    

    //     table = table_find(name)
    RefDS(_name);
    _table = _11table_find(_name);

    //     if table = -1 then 
    if (binary_op_a(NOTEQ, _table, -1))
        goto L1;

    // 	fatal("Source table doesn't exist")
    RefDS(_1670);
    _11fatal(_1670);
L1:

    //     if table_find(new_name) != -1 then
    RefDS(_new_name);
    _0 = _1668;
    _1668 = _11table_find(_new_name);
    DeRef(_0);
    if (binary_op_a(EQUALS, _1668, -1))
        goto L2;

    // 	fatal("Target table name already exists")
    RefDS(_1673);
    _11fatal(_1673);
L2:

    //     safe_seek(table)
    Ref(_table);
    _11safe_seek(_table);

    //     db_free(get4())
    _0 = _1668;
    _1668 = _11get4();
    DeRef(_0);
    Ref(_1668);
    _11db_free(_1668);

    //     table_ptr = db_allocate(length(new_name)+1)
    DeRef(_1668);
    _1668 = SEQ_PTR(_new_name)->length;
    _1668 = _1668 + 1;
    _0 = _table_ptr;
    _table_ptr = _11db_allocate(_1668);
    DeRef(_0);

    //     putn(new_name & 0)
    Append(&_1668, _new_name, 0);
    RefDS(_1668);
    _11putn(_1668);

    //     safe_seek(table)
    Ref(_table);
    _11safe_seek(_table);

    //     put4(table_ptr)
    Ref(_table_ptr);
    _11put4(_table_ptr);

    // end procedure
    DeRefDS(_name);
    DeRefDS(_new_name);
    DeRef(_table);
    DeRef(_table_ptr);
    DeRefDS(_1668);
    return 0;
    ;
}


_11db_table_list()
{
    int _table_names = 0;
    int _tables = 0;
    int _nt = 0;
    int _name = 0;
    int _1683 = 0;
    int _1684 = 0;
    int _1679 = 0;
    int _0, _1, _2;
    

    //     safe_seek(TABLE_HEADERS)
    _11safe_seek(3);

    //     tables = get4()
    _tables = _11get4();

    //     safe_seek(tables)
    Ref(_tables);
    _11safe_seek(_tables);

    //     nt = get4()
    _nt = _11get4();

    //     table_names = repeat(0, nt)
    _table_names = Repeat(0, _nt);

    //     for i = 0 to nt-1 do
    if (IS_ATOM_INT(_nt)) {
        _1679 = _nt - 1;
        if ((long)((unsigned long)_1679 +(unsigned long) HIGH_BITS) >= 0)
            _1679 = NewDouble((double)_1679);
    }
    else {
        _1679 = NewDouble(DBL_PTR(_nt)->dbl - (double)1);
    }
    { int _i;
        _i = 0;
L1:
        if (binary_op_a(GREATER, _i, _1679))
            goto L2;

        // 	safe_seek(tables + 4 + i*SIZEOF_TABLE_HEADER)
        DeRef(_1683);
        if (IS_ATOM_INT(_tables)) {
            _1683 = _tables + 4;
            if ((long)((unsigned long)_1683 + (unsigned long)HIGH_BITS) >= 0) 
                _1683 = NewDouble((double)_1683);
        }
        else {
            _1683 = NewDouble(DBL_PTR(_tables)->dbl + (double)4);
        }
        DeRef(_1684);
        if (IS_ATOM_INT(_i)) {
            if (_i == (short)_i)
                _1684 = _i * 16;
            else
                _1684 = NewDouble(_i * (double)16);
        }
        else {
            _1684 = NewDouble(DBL_PTR(_i)->dbl * (double)16);
        }
        _0 = _1684;
        if (IS_ATOM_INT(_1683) && IS_ATOM_INT(_1684)) {
            _1684 = _1683 + _1684;
            if ((long)((unsigned long)_1684 + (unsigned long)HIGH_BITS) >= 0) 
                _1684 = NewDouble((double)_1684);
        }
        else {
            if (IS_ATOM_INT(_1683)) {
                _1684 = NewDouble((double)_1683 + DBL_PTR(_1684)->dbl);
            }
            else {
                if (IS_ATOM_INT(_1684)) {
                    _1684 = NewDouble(DBL_PTR(_1683)->dbl + (double)_1684);
                }
                else
                    _1684 = NewDouble(DBL_PTR(_1683)->dbl + DBL_PTR(_1684)->dbl);
            }
        }
        DeRef(_0);
        Ref(_1684);
        _11safe_seek(_1684);

        // 	name = get4()
        _0 = _name;
        _name = _11get4();
        DeRef(_0);

        // 	safe_seek(name)
        Ref(_name);
        _11safe_seek(_name);

        // 	table_names[i+1] = get_string()
        DeRef(_1684);
        if (IS_ATOM_INT(_i)) {
            _1684 = _i + 1;
            if (_1684 > MAXINT)
                _1684 = NewDouble((double)_1684);
        }
        else
            _1684 = binary_op(PLUS, 1, _i);
        _0 = _1683;
        _1683 = _11get_string();
        DeRef(_0);
        RefDS(_1683);
        _2 = (int)SEQ_PTR(_table_names);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_1684))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_1684)->dbl));
        else
            _2 = (int)(((s1_ptr)_2)->base + _1684);
        _1 = *(int *)_2;
        *(int *)_2 = _1683;
        DeRef(_1);

        //     end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L1;
L2:
        ;
        DeRef(_i);
    }

    //     return table_names
    DeRef(_tables);
    DeRef(_nt);
    DeRef(_name);
    DeRef(_1683);
    DeRef(_1684);
    DeRef(_1679);
    return _table_names;
    ;
}


int _11key_value(int _ptr)
{
    int _1689 = 0;
    int _0, _1, _2;
    

    //     safe_seek(ptr+4) -- skip ptr to data
    if (IS_ATOM_INT(_ptr)) {
        _1689 = _ptr + 4;
        if ((long)((unsigned long)_1689 + (unsigned long)HIGH_BITS) >= 0) 
            _1689 = NewDouble((double)_1689);
    }
    else {
        _1689 = NewDouble(DBL_PTR(_ptr)->dbl + (double)4);
    }
    Ref(_1689);
    _11safe_seek(_1689);

    //     return decompress(0)
    _0 = _1689;
    _1689 = _11decompress(0);
    DeRef(_0);
    DeRef(_ptr);
    return _1689;
    ;
}


_11db_find_key(int _key)
{
    int _lo;
    int _hi;
    int _mid;
    int _c;
    int _1691 = 0;
    int _0, _1, _2;
    

    //     if current_table = -1 then
    if (binary_op_a(NOTEQ, _11current_table, -1))
        goto L1;

    // 	fatal("no table selected")
    RefDS(_1692);
    _11fatal(_1692);
L1:

    //     lo = 1
    _lo = 1;

    //     hi = length(key_pointers)
    _hi = SEQ_PTR(_11key_pointers)->length;

    //     mid = 1
    _mid = 1;

    //     c = 0
    _c = 0;

    //     while lo <= hi do
L2:
    if (_lo > _hi)
        goto L3;

    // 	mid = floor((lo + hi) / 2)
    DeRef(_1691);
    _1691 = _lo + _hi;
    if ((long)((unsigned long)_1691 + (unsigned long)HIGH_BITS) >= 0) 
        _1691 = NewDouble((double)_1691);
    if (IS_ATOM_INT(_1691)) {
        _mid = _1691 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1691, 2);
        _mid = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_mid)) {
        _1 = (long)(DBL_PTR(_mid)->dbl);
        DeRefDS(_mid);
        _mid = _1;
    }

    // 	c = compare(key, key_value(key_pointers[mid]))
    DeRef(_1691);
    _2 = (int)SEQ_PTR(_11key_pointers);
    _1691 = (int)*(((s1_ptr)_2)->base + _mid);
    Ref(_1691);
    Ref(_1691);
    _0 = _1691;
    _1691 = _11key_value(_1691);
    DeRef(_0);
    if (IS_ATOM_INT(_key) && IS_ATOM_INT(_1691))
        _c = (_key < _1691) ? -1 : (_key > _1691);
    else
        _c = compare(_key, _1691);

    // 	if c < 0 then
    if (_c >= 0)
        goto L4;

    // 	    hi = mid - 1
    _hi = _mid - 1;
    goto L2;
L4:

    // 	elsif c > 0 then
    if (_c <= 0)
        goto L5;

    // 	    lo = mid + 1
    _lo = _mid + 1;
    goto L2;
L5:

    // 	    return mid
    DeRef(_key);
    DeRef(_1691);
    return _mid;
L6:

    //     end while
    goto L2;
L3:

    //     if c > 0 then
    if (_c <= 0)
        goto L7;

    // 	mid += 1
    _mid = _mid + 1;
L7:

    //     return -mid
    DeRef(_1691);
    if (_mid == 0xC0000000)
        _1691 = (int)NewDouble((double)-0xC0000000);
    else
        _1691 = - _mid;
    DeRef(_key);
    return _1691;
    ;
}


_11db_insert(int _key, int _data)
{
    int _key_string = 0;
    int _data_string = 0;
    int _last_part = 0;
    int _remaining = 0;
    int _key_ptr = 0;
    int _data_ptr = 0;
    int _records_ptr = 0;
    int _nrecs = 0;
    int _current_block = 0;
    int _size = 0;
    int _new_size = 0;
    int _key_location = 0;
    int _new_block = 0;
    int _index_ptr = 0;
    int _new_index_ptr = 0;
    int _total_recs = 0;
    int _r;
    int _blocks;
    int _new_recs;
    int _n;
    int _1727 = 0;
    int _1728 = 0;
    int _1707 = 0;
    int _0, _1, _2;
    

    //     key_location = db_find_key(key)
    Ref(_key);
    _key_location = _11db_find_key(_key);

    //     if key_location > 0 then
    if (binary_op_a(LESSEQ, _key_location, 0))
        goto L1;

    // 	return DB_EXISTS_ALREADY
    DeRef(_key);
    DeRef(_data);
    DeRef(_key_location);
    return -2;
L1:

    //     key_location = -key_location
    _0 = _key_location;
    if (IS_ATOM_INT(_key_location)) {
        if (_key_location == 0xC0000000)
            _key_location = (int)NewDouble((double)-0xC0000000);
        else
            _key_location = - _key_location;
    }
    else {
        _key_location = unary_op(UMINUS, _key_location);
    }
    DeRef(_0);

    //     data_string = compress(data)
    Ref(_data);
    _0 = _data_string;
    _data_string = _11compress(_data);
    DeRef(_0);

    //     key_string  = compress(key)
    Ref(_key);
    _0 = _key_string;
    _key_string = _11compress(_key);
    DeRef(_0);

    //     data_ptr = db_allocate(length(data_string))
    DeRef(_1707);
    _1707 = SEQ_PTR(_data_string)->length;
    _0 = _data_ptr;
    _data_ptr = _11db_allocate(_1707);
    DeRef(_0);

    //     putn(data_string)
    RefDS(_data_string);
    _11putn(_data_string);

    //     key_ptr = db_allocate(4+length(key_string))
    _1707 = SEQ_PTR(_key_string)->length;
    _1707 = 4 + _1707;
    _0 = _key_ptr;
    _key_ptr = _11db_allocate(_1707);
    DeRef(_0);

    //     put4(data_ptr)
    Ref(_data_ptr);
    _11put4(_data_ptr);

    //     putn(key_string)
    RefDS(_key_string);
    _11putn(_key_string);

    //     safe_seek(current_table+4)
    if (IS_ATOM_INT(_11current_table)) {
        _1707 = _11current_table + 4;
        if ((long)((unsigned long)_1707 + (unsigned long)HIGH_BITS) >= 0) 
            _1707 = NewDouble((double)_1707);
    }
    else {
        _1707 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)4);
    }
    Ref(_1707);
    _11safe_seek(_1707);

    //     total_recs = get4()+1
    _0 = _1707;
    _1707 = _11get4();
    DeRef(_0);
    DeRef(_total_recs);
    if (IS_ATOM_INT(_1707)) {
        _total_recs = _1707 + 1;
        if (_total_recs > MAXINT)
            _total_recs = NewDouble((double)_total_recs);
    }
    else
        _total_recs = binary_op(PLUS, 1, _1707);

    //     blocks = get4()
    _blocks = _11get4();
    if (!IS_ATOM_INT(_blocks)) {
        _1 = (long)(DBL_PTR(_blocks)->dbl);
        DeRefDS(_blocks);
        _blocks = _1;
    }

    //     safe_seek(current_table+4)
    DeRef(_1707);
    if (IS_ATOM_INT(_11current_table)) {
        _1707 = _11current_table + 4;
        if ((long)((unsigned long)_1707 + (unsigned long)HIGH_BITS) >= 0) 
            _1707 = NewDouble((double)_1707);
    }
    else {
        _1707 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)4);
    }
    Ref(_1707);
    _11safe_seek(_1707);

    //     put4(total_recs)
    Ref(_total_recs);
    _11put4(_total_recs);

    //     n = length(key_pointers)
    _n = SEQ_PTR(_11key_pointers)->length;

    //     if key_location >= floor(n/2) then
    DeRef(_1707);
    _1707 = _n >> 1;
    if (binary_op_a(LESS, _key_location, _1707))
        goto L2;

    // 	key_pointers = append(key_pointers, 0)
    Append(&_11key_pointers, _11key_pointers, 0);

    // 	key_pointers[key_location+1..n+1] = key_pointers[key_location..n]
    if (IS_ATOM_INT(_key_location)) {
        _1707 = _key_location + 1;
        if (_1707 > MAXINT)
            _1707 = NewDouble((double)_1707);
    }
    else
        _1707 = binary_op(PLUS, 1, _key_location);
    DeRef(_1727);
    _1727 = _n + 1;
    rhs_slice_target = (object_ptr)&_1728;
    RHS_Slice((s1_ptr)_11key_pointers, _key_location, _n);
    assign_slice_seq = (s1_ptr *)&_11key_pointers;
    AssignSlice(_1707, _1727, _1728);
    goto L3;
L2:

    // 	key_pointers = prepend(key_pointers, 0)
    Prepend(&_11key_pointers, _11key_pointers, 0);

    // 	key_pointers[1..key_location-1] = key_pointers[2..key_location]
    DeRef(_1728);
    if (IS_ATOM_INT(_key_location)) {
        _1728 = _key_location - 1;
        if ((long)((unsigned long)_1728 +(unsigned long) HIGH_BITS) >= 0)
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_key_location)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_1727;
    RHS_Slice((s1_ptr)_11key_pointers, 2, _key_location);
    assign_slice_seq = (s1_ptr *)&_11key_pointers;
    AssignSlice(1, _1728, _1727);
L3:

    //     key_pointers[key_location] = key_ptr
    Ref(_key_ptr);
    _2 = (int)SEQ_PTR(_11key_pointers);
    if (!IS_ATOM_INT(_key_location))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location)->dbl));
    else
        _2 = (int)(((s1_ptr)_2)->base + _key_location);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr;
    DeRef(_1);

    //     safe_seek(current_table+12) -- get after put - seek is necessary
    DeRef(_1727);
    if (IS_ATOM_INT(_11current_table)) {
        _1727 = _11current_table + 12;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)12);
    }
    Ref(_1727);
    _11safe_seek(_1727);

    //     index_ptr = get4()
    _0 = _index_ptr;
    _index_ptr = _11get4();
    DeRef(_0);

    //     safe_seek(index_ptr)
    Ref(_index_ptr);
    _11safe_seek(_index_ptr);

    //     r = 0
    _r = 0;

    //     while TRUE do
L4:

    // 	nrecs = get4()
    _0 = _nrecs;
    _nrecs = _11get4();
    DeRef(_0);

    // 	records_ptr = get4()
    _0 = _records_ptr;
    _records_ptr = _11get4();
    DeRef(_0);

    // 	r += nrecs
    if (IS_ATOM_INT(_nrecs)) {
        _r = _r + _nrecs;
    }
    else {
        _r = NewDouble((double)_r + DBL_PTR(_nrecs)->dbl);
    }
    if (!IS_ATOM_INT(_r)) {
        _1 = (long)(DBL_PTR(_r)->dbl);
        DeRefDS(_r);
        _r = _1;
    }

    // 	if r + 1 >= key_location then
    DeRef(_1727);
    _1727 = _r + 1;
    if (_1727 > MAXINT)
        _1727 = NewDouble((double)_1727);
    if (binary_op_a(LESS, _1727, _key_location))
        goto L4;

    // 	    exit
    goto L5;
L6:

    //     end while
    goto L4;
L5:

    //     current_block = where(current_db)-8
    _0 = _1727;
    _1727 = _4where(_11current_db);
    DeRef(_0);
    DeRef(_current_block);
    if (IS_ATOM_INT(_1727)) {
        _current_block = _1727 - 8;
        if ((long)((unsigned long)_current_block +(unsigned long) HIGH_BITS) >= 0)
            _current_block = NewDouble((double)_current_block);
    }
    else {
        _current_block = NewDouble(DBL_PTR(_1727)->dbl - (double)8);
    }

    //     key_location -= (r-nrecs)
    DeRef(_1727);
    if (IS_ATOM_INT(_nrecs)) {
        _1727 = _r - _nrecs;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble((double)_r - DBL_PTR(_nrecs)->dbl);
    }
    _0 = _key_location;
    if (IS_ATOM_INT(_key_location) && IS_ATOM_INT(_1727)) {
        _key_location = _key_location - _1727;
        if ((long)((unsigned long)_key_location +(unsigned long) HIGH_BITS) >= 0)
            _key_location = NewDouble((double)_key_location);
    }
    else {
        if (IS_ATOM_INT(_key_location)) {
            _key_location = NewDouble((double)_key_location - DBL_PTR(_1727)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1727)) {
                _key_location = NewDouble(DBL_PTR(_key_location)->dbl - (double)_1727);
            }
            else
                _key_location = NewDouble(DBL_PTR(_key_location)->dbl - DBL_PTR(_1727)->dbl);
        }
    }
    DeRef(_0);

    //     safe_seek(records_ptr+4*(key_location-1))
    DeRef(_1727);
    if (IS_ATOM_INT(_key_location)) {
        _1727 = _key_location - 1;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_key_location)->dbl - (double)1);
    }
    _0 = _1727;
    if (IS_ATOM_INT(_1727)) {
        if (_1727 <= INT15 && _1727 >= -INT15)
            _1727 = 4 * _1727;
        else
            _1727 = NewDouble(4 * (double)_1727);
    }
    else {
        _1727 = NewDouble((double)4 * DBL_PTR(_1727)->dbl);
    }
    DeRef(_0);
    _0 = _1727;
    if (IS_ATOM_INT(_records_ptr) && IS_ATOM_INT(_1727)) {
        _1727 = _records_ptr + _1727;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        if (IS_ATOM_INT(_records_ptr)) {
            _1727 = NewDouble((double)_records_ptr + DBL_PTR(_1727)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1727)) {
                _1727 = NewDouble(DBL_PTR(_records_ptr)->dbl + (double)_1727);
            }
            else
                _1727 = NewDouble(DBL_PTR(_records_ptr)->dbl + DBL_PTR(_1727)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1727);
    _11safe_seek(_1727);

    //     for i = key_location to nrecs+1 do
    DeRef(_1727);
    if (IS_ATOM_INT(_nrecs)) {
        _1727 = _nrecs + 1;
        if (_1727 > MAXINT)
            _1727 = NewDouble((double)_1727);
    }
    else
        _1727 = binary_op(PLUS, 1, _nrecs);
    { int _i;
        Ref(_key_location);
        _i = _key_location;
L7:
        if (binary_op_a(GREATER, _i, _1727))
            goto L8;

        // 	put4(key_pointers[i+r-nrecs])
        DeRef(_1728);
        if (IS_ATOM_INT(_i)) {
            _1728 = _i + _r;
            if ((long)((unsigned long)_1728 + (unsigned long)HIGH_BITS) >= 0) 
                _1728 = NewDouble((double)_1728);
        }
        else {
            _1728 = NewDouble(DBL_PTR(_i)->dbl + (double)_r);
        }
        _0 = _1728;
        if (IS_ATOM_INT(_1728) && IS_ATOM_INT(_nrecs)) {
            _1728 = _1728 - _nrecs;
        }
        else {
            if (IS_ATOM_INT(_1728)) {
                _1728 = NewDouble((double)_1728 - DBL_PTR(_nrecs)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs)) {
                    _1728 = NewDouble(DBL_PTR(_1728)->dbl - (double)_nrecs);
                }
                else
                    _1728 = NewDouble(DBL_PTR(_1728)->dbl - DBL_PTR(_nrecs)->dbl);
            }
        }
        DeRef(_0);
        _0 = _1728;
        _2 = (int)SEQ_PTR(_11key_pointers);
        if (!IS_ATOM_INT(_1728))
            _1728 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1728)->dbl));
        else
            _1728 = (int)*(((s1_ptr)_2)->base + _1728);
        Ref(_1728);
        DeRef(_0);
        Ref(_1728);
        _11put4(_1728);

        //     end for
        _0 = _i;
        if (IS_ATOM_INT(_i)) {
            _i = _i + 1;
            if ((long)((unsigned long)_i +(unsigned long) HIGH_BITS) >= 0) 
                _i = NewDouble((double)_i);
        }
        else {
            _i = binary_op_a(PLUS, _i, 1);
        }
        DeRef(_0);
        goto L7;
L8:
        ;
        DeRef(_i);
    }

    //     safe_seek(current_block)
    Ref(_current_block);
    _11safe_seek(_current_block);

    //     nrecs += 1
    _0 = _nrecs;
    if (IS_ATOM_INT(_nrecs)) {
        _nrecs = _nrecs + 1;
        if (_nrecs > MAXINT)
            _nrecs = NewDouble((double)_nrecs);
    }
    else
        _nrecs = binary_op(PLUS, 1, _nrecs);
    DeRef(_0);

    //     put4(nrecs)
    Ref(_nrecs);
    _11put4(_nrecs);

    //     safe_seek(records_ptr - 4)
    DeRef(_1728);
    if (IS_ATOM_INT(_records_ptr)) {
        _1728 = _records_ptr - 4;
        if ((long)((unsigned long)_1728 +(unsigned long) HIGH_BITS) >= 0)
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_records_ptr)->dbl - (double)4);
    }
    Ref(_1728);
    _11safe_seek(_1728);

    //     size = get4() - 4
    _0 = _1728;
    _1728 = _11get4();
    DeRef(_0);
    DeRef(_size);
    if (IS_ATOM_INT(_1728)) {
        _size = _1728 - 4;
        if ((long)((unsigned long)_size +(unsigned long) HIGH_BITS) >= 0)
            _size = NewDouble((double)_size);
    }
    else {
        _size = NewDouble(DBL_PTR(_1728)->dbl - (double)4);
    }

    //     if nrecs*4 > size-4 then
    DeRef(_1728);
    if (IS_ATOM_INT(_nrecs)) {
        if (_nrecs == (short)_nrecs)
            _1728 = _nrecs * 4;
        else
            _1728 = NewDouble(_nrecs * (double)4);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_nrecs)->dbl * (double)4);
    }
    DeRef(_1727);
    if (IS_ATOM_INT(_size)) {
        _1727 = _size - 4;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_size)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _1728, _1727))
        goto L9;

    // 	new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))
    DeRef(_1727);
    if (IS_ATOM_INT(_total_recs)) {
        _1727 = NewDouble(DBL_PTR(_1757)->dbl * (double)_total_recs);
    }
    else
        _1727 = NewDouble(DBL_PTR(_1757)->dbl * DBL_PTR(_total_recs)->dbl);
    _0 = _1727;
    _1727 = unary_op(SQRT, _1727);
    DeRefDS(_0);
    _0 = _1727;
    _1727 = unary_op(FLOOR, _1727);
    DeRefDS(_0);
    _0 = _1727;
    _1727 = NewDouble((double)20 + DBL_PTR(_1727)->dbl);
    DeRefDS(_0);
    DeRef(_new_size);
    _new_size = NewDouble((double)8 * DBL_PTR(_1727)->dbl);

    // 	new_recs = floor(new_size/8)
    _2 = binary_op(DIVIDE, _new_size, 8);
    _new_recs = unary_op(FLOOR, _2);
    DeRef(_2);
    if (!IS_ATOM_INT(_new_recs)) {
        _1 = (long)(DBL_PTR(_new_recs)->dbl);
        DeRefDS(_new_recs);
        _new_recs = _1;
    }

    // 	if new_recs > floor(nrecs/2) then
    DeRefDS(_1727);
    if (IS_ATOM_INT(_nrecs)) {
        _1727 = _nrecs >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs, 2);
        _1727 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs, _1727))
        goto LA;

    // 	    new_recs = floor(nrecs/2)
    if (IS_ATOM_INT(_nrecs)) {
        _new_recs = _nrecs >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs, 2);
        _new_recs = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs)) {
        _1 = (long)(DBL_PTR(_new_recs)->dbl);
        DeRefDS(_new_recs);
        _new_recs = _1;
    }
LA:

    // 	safe_seek(records_ptr + (nrecs-new_recs)*4)
    DeRef(_1727);
    if (IS_ATOM_INT(_nrecs)) {
        _1727 = _nrecs - _new_recs;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_nrecs)->dbl - (double)_new_recs);
    }
    _0 = _1727;
    if (IS_ATOM_INT(_1727)) {
        if (_1727 == (short)_1727)
            _1727 = _1727 * 4;
        else
            _1727 = NewDouble(_1727 * (double)4);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_1727)->dbl * (double)4);
    }
    DeRef(_0);
    _0 = _1727;
    if (IS_ATOM_INT(_records_ptr) && IS_ATOM_INT(_1727)) {
        _1727 = _records_ptr + _1727;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        if (IS_ATOM_INT(_records_ptr)) {
            _1727 = NewDouble((double)_records_ptr + DBL_PTR(_1727)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1727)) {
                _1727 = NewDouble(DBL_PTR(_records_ptr)->dbl + (double)_1727);
            }
            else
                _1727 = NewDouble(DBL_PTR(_records_ptr)->dbl + DBL_PTR(_1727)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1727);
    _11safe_seek(_1727);

    // 	last_part = get_bytes(current_db, new_recs*4)
    DeRef(_1727);
    if (_new_recs == (short)_new_recs)
        _1727 = _new_recs * 4;
    else
        _1727 = NewDouble(_new_recs * (double)4);
    Ref(_1727);
    _0 = _last_part;
    _last_part = _7get_bytes(_11current_db, _1727);
    DeRefi(_0);

    // 	new_block = db_allocate(new_size)
    Ref(_new_size);
    _0 = _new_block;
    _new_block = _11db_allocate(_new_size);
    DeRef(_0);

    // 	putn(last_part)
    RefDS(_last_part);
    _11putn(_last_part);

    // 	putn(repeat(0, new_size-length(last_part)))
    DeRef(_1727);
    _1727 = SEQ_PTR(_last_part)->length;
    if (IS_ATOM_INT(_new_size)) {
        _1727 = _new_size - _1727;
    }
    else {
        _1727 = NewDouble(DBL_PTR(_new_size)->dbl - (double)_1727);
    }
    _0 = _1727;
    _1727 = Repeat(0, _1727);
    DeRef(_0);
    RefDS(_1727);
    _11putn(_1727);

    // 	safe_seek(current_block)
    Ref(_current_block);
    _11safe_seek(_current_block);

    // 	put4(nrecs-new_recs)
    DeRefDSi(_1727);
    if (IS_ATOM_INT(_nrecs)) {
        _1727 = _nrecs - _new_recs;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_nrecs)->dbl - (double)_new_recs);
    }
    Ref(_1727);
    _11put4(_1727);

    // 	safe_seek(current_block+8)
    DeRef(_1727);
    if (IS_ATOM_INT(_current_block)) {
        _1727 = _current_block + 8;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_current_block)->dbl + (double)8);
    }
    Ref(_1727);
    _11safe_seek(_1727);

    // 	remaining = get_bytes(current_db, index_ptr+blocks*8-(current_block+8))
    DeRef(_1727);
    if (_blocks == (short)_blocks)
        _1727 = _blocks * 8;
    else
        _1727 = NewDouble(_blocks * (double)8);
    _0 = _1727;
    if (IS_ATOM_INT(_index_ptr) && IS_ATOM_INT(_1727)) {
        _1727 = _index_ptr + _1727;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        if (IS_ATOM_INT(_index_ptr)) {
            _1727 = NewDouble((double)_index_ptr + DBL_PTR(_1727)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1727)) {
                _1727 = NewDouble(DBL_PTR(_index_ptr)->dbl + (double)_1727);
            }
            else
                _1727 = NewDouble(DBL_PTR(_index_ptr)->dbl + DBL_PTR(_1727)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1728);
    if (IS_ATOM_INT(_current_block)) {
        _1728 = _current_block + 8;
        if ((long)((unsigned long)_1728 + (unsigned long)HIGH_BITS) >= 0) 
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_current_block)->dbl + (double)8);
    }
    _0 = _1728;
    if (IS_ATOM_INT(_1727) && IS_ATOM_INT(_1728)) {
        _1728 = _1727 - _1728;
        if ((long)((unsigned long)_1728 +(unsigned long) HIGH_BITS) >= 0)
            _1728 = NewDouble((double)_1728);
    }
    else {
        if (IS_ATOM_INT(_1727)) {
            _1728 = NewDouble((double)_1727 - DBL_PTR(_1728)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1728)) {
                _1728 = NewDouble(DBL_PTR(_1727)->dbl - (double)_1728);
            }
            else
                _1728 = NewDouble(DBL_PTR(_1727)->dbl - DBL_PTR(_1728)->dbl);
        }
    }
    DeRef(_0);
    Ref(_1728);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1728);
    DeRefi(_0);

    // 	safe_seek(current_block+8)
    DeRef(_1728);
    if (IS_ATOM_INT(_current_block)) {
        _1728 = _current_block + 8;
        if ((long)((unsigned long)_1728 + (unsigned long)HIGH_BITS) >= 0) 
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_current_block)->dbl + (double)8);
    }
    Ref(_1728);
    _11safe_seek(_1728);

    // 	put4(new_recs)
    _11put4(_new_recs);

    // 	put4(new_block)
    Ref(_new_block);
    _11put4(_new_block);

    // 	putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	safe_seek(current_table+8)
    DeRef(_1728);
    if (IS_ATOM_INT(_11current_table)) {
        _1728 = _11current_table + 8;
        if ((long)((unsigned long)_1728 + (unsigned long)HIGH_BITS) >= 0) 
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)8);
    }
    Ref(_1728);
    _11safe_seek(_1728);

    // 	blocks += 1
    _blocks = _blocks + 1;

    // 	put4(blocks)
    _11put4(_blocks);

    // 	safe_seek(index_ptr-4)
    DeRef(_1728);
    if (IS_ATOM_INT(_index_ptr)) {
        _1728 = _index_ptr - 4;
        if ((long)((unsigned long)_1728 +(unsigned long) HIGH_BITS) >= 0)
            _1728 = NewDouble((double)_1728);
    }
    else {
        _1728 = NewDouble(DBL_PTR(_index_ptr)->dbl - (double)4);
    }
    Ref(_1728);
    _11safe_seek(_1728);

    // 	size = get4() - 4
    _0 = _1728;
    _1728 = _11get4();
    DeRef(_0);
    DeRef(_size);
    if (IS_ATOM_INT(_1728)) {
        _size = _1728 - 4;
        if ((long)((unsigned long)_size +(unsigned long) HIGH_BITS) >= 0)
            _size = NewDouble((double)_size);
    }
    else {
        _size = NewDouble(DBL_PTR(_1728)->dbl - (double)4);
    }

    // 	if blocks*8 > size-8 then
    DeRef(_1728);
    if (_blocks == (short)_blocks)
        _1728 = _blocks * 8;
    else
        _1728 = NewDouble(_blocks * (double)8);
    DeRef(_1727);
    if (IS_ATOM_INT(_size)) {
        _1727 = _size - 8;
        if ((long)((unsigned long)_1727 +(unsigned long) HIGH_BITS) >= 0)
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_size)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _1728, _1727))
        goto LB;

    // 	    remaining = get_bytes(current_db, blocks*8)
    DeRef(_1727);
    if (_blocks == (short)_blocks)
        _1727 = _blocks * 8;
    else
        _1727 = NewDouble(_blocks * (double)8);
    Ref(_1727);
    _0 = _remaining;
    _remaining = _7get_bytes(_11current_db, _1727);
    DeRefDSi(_0);

    // 	    new_size = floor(size*3/2)
    DeRef(_1727);
    if (IS_ATOM_INT(_size)) {
        if (_size == (short)_size)
            _1727 = _size * 3;
        else
            _1727 = NewDouble(_size * (double)3);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_size)->dbl * (double)3);
    }
    DeRef(_new_size);
    if (IS_ATOM_INT(_1727)) {
        _new_size = _1727 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1727, 2);
        _new_size = unary_op(FLOOR, _1);
        DeRef(_1);
    }

    // 	    new_index_ptr = db_allocate(new_size)
    Ref(_new_size);
    _0 = _new_index_ptr;
    _new_index_ptr = _11db_allocate(_new_size);
    DeRef(_0);

    // 	    putn(remaining)
    RefDS(_remaining);
    _11putn(_remaining);

    // 	    putn(repeat(0, new_size-blocks*8))
    DeRef(_1727);
    if (_blocks == (short)_blocks)
        _1727 = _blocks * 8;
    else
        _1727 = NewDouble(_blocks * (double)8);
    _0 = _1727;
    if (IS_ATOM_INT(_new_size) && IS_ATOM_INT(_1727)) {
        _1727 = _new_size - _1727;
    }
    else {
        if (IS_ATOM_INT(_new_size)) {
            _1727 = NewDouble((double)_new_size - DBL_PTR(_1727)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1727)) {
                _1727 = NewDouble(DBL_PTR(_new_size)->dbl - (double)_1727);
            }
            else
                _1727 = NewDouble(DBL_PTR(_new_size)->dbl - DBL_PTR(_1727)->dbl);
        }
    }
    DeRef(_0);
    _0 = _1727;
    _1727 = Repeat(0, _1727);
    DeRef(_0);
    RefDS(_1727);
    _11putn(_1727);

    // 	    db_free(index_ptr)
    Ref(_index_ptr);
    _11db_free(_index_ptr);

    // 	    safe_seek(current_table+12)
    DeRefDSi(_1727);
    if (IS_ATOM_INT(_11current_table)) {
        _1727 = _11current_table + 12;
        if ((long)((unsigned long)_1727 + (unsigned long)HIGH_BITS) >= 0) 
            _1727 = NewDouble((double)_1727);
    }
    else {
        _1727 = NewDouble(DBL_PTR(_11current_table)->dbl + (double)12);
    }
    Ref(_1727);
    _11safe_seek(_1727);

    // 	    put4(new_index_ptr)
    Ref(_new_index_ptr);
    _11put4(_new_index_ptr);
LB:
L9:

    //     return DB_OK
    DeRef(_key);
    DeRef(_data);
    DeRef(_key_string);
    DeRef(_data_string);
    DeRefi(_last_part);
    DeRefi(_remaining);
    DeRef(_key_ptr);
    DeRef(_data_ptr);
    DeRef(_records_ptr);
    DeRef(_nrecs);
    DeRef(_current_block);
    DeRef(_size);
    DeRef(_new_size);
    DeRef(_key_location);
    DeRef(_new_block);
    DeRef(_index_ptr);
    DeRef(_new_index_ptr);
    DeRef(_total_recs);
    DeRef(_1727);
    DeRef(_1728);
    DeRef(_1707);
    return 0;
    ;
}


