// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

_1eu_printf(int _fn_id, int _id1, int _id2)
{
    int _2424 = 0;
    int _2423 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	printf(fn_id, data[id1], data[id2])
    _2 = (int)SEQ_PTR(_1data);
    _2423 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2423);
    _2 = (int)SEQ_PTR(_1data);
    _2424 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2424);
    EPrintf(_fn_id, _2423, _2424);

    // end procedure
    DeRef(_2424);
    DeRef(_2423);
    return 0;
    ;
}


_1eu_puts(int _fn_id, int _id1)
{
    int _2425 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	puts(fn_id, data[id1])
    _2 = (int)SEQ_PTR(_1data);
    _2425 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2425);
    EPuts(_fn_id, _2425);

    // end procedure
    DeRef(_2425);
    return 0;
    ;
}


_1eu_rand(int _id1)
{
    int _2426 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }

    // 	return retval(rand(data[id1]))
    _2 = (int)SEQ_PTR(_1data);
    _2426 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2426);
    _0 = _2426;
    if (IS_ATOM_INT(_2426)) {
        _2426 = good_rand() % ((unsigned)_2426) + 1;
    }
    else {
        _2426 = unary_op(RAND, _2426);
    }
    DeRef(_0);
    Ref(_2426);
    _0 = _2426;
    _2426 = _1retval(_2426);
    DeRef(_0);
    return _2426;
    ;
}


_1eu_remainder(int _id1, int _id2)
{
    int _2430 = 0;
    int _2429 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(remainder(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2429 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2429);
    _2 = (int)SEQ_PTR(_1data);
    _2430 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2430);
    _0 = _2430;
    if (IS_ATOM_INT(_2429) && IS_ATOM_INT(_2430)) {
        _2430 = (_2429 % _2430);
    }
    else {
        _2430 = binary_op(REMAINDER, _2429, _2430);
    }
    DeRef(_0);
    Ref(_2430);
    _0 = _2430;
    _2430 = _1retval(_2430);
    DeRef(_0);
    DeRef(_2429);
    return _2430;
    ;
}


_1eu_sequence(int _id)
{
    int _i;
    int _2433 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	i = sequence(data[id]) -- boolean
    _2 = (int)SEQ_PTR(_1data);
    _2433 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2433);
    _i = IS_SEQUENCE(_2433);

    // 	return i
    DeRef(_2433);
    return _i;
    ;
}


_1eu_sin(int _id)
{
    int _2435 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(sin(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2435 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2435);
    _0 = _2435;
    if (IS_ATOM_INT(_2435))
        _2435 = e_sin(_2435);
    else
        _2435 = unary_op(SIN, _2435);
    DeRef(_0);
    Ref(_2435);
    _0 = _2435;
    _2435 = _1retval(_2435);
    DeRef(_0);
    return _2435;
    ;
}


_1eu_sprintf(int _id1, int _id2)
{
    int _2439 = 0;
    int _2438 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(sprintf(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2438 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2438);
    _2 = (int)SEQ_PTR(_1data);
    _2439 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2439);
    _0 = _2439;
    _2439 = EPrintf(-9999999, _2438, _2439);
    DeRef(_0);
    RefDS(_2439);
    _0 = _2439;
    _2439 = _1retval(_2439);
    DeRefDSi(_0);
    DeRef(_2438);
    return _2439;
    ;
}


_1eu_sqrt(int _id)
{
    int _2442 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(sqrt(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2442 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2442);
    _0 = _2442;
    if (IS_ATOM_INT(_2442))
        _2442 = e_sqrt(_2442);
    else
        _2442 = unary_op(SQRT, _2442);
    DeRef(_0);
    Ref(_2442);
    _0 = _2442;
    _2442 = _1retval(_2442);
    DeRef(_0);
    return _2442;
    ;
}


_1eu_subscript(int _id, int _start, int _stop)
{
    int _2445 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }
    if (!IS_ATOM_INT(_start)) {
        _1 = (long)(DBL_PTR(_start)->dbl);
        DeRefDS(_start);
        _start = _1;
    }
    if (!IS_ATOM_INT(_stop)) {
        _1 = (long)(DBL_PTR(_stop)->dbl);
        DeRefDS(_stop);
        _stop = _1;
    }

    // 	return retval(data[id][start..stop])
    _2 = (int)SEQ_PTR(_1data);
    _2445 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2445);
    rhs_slice_target = (object_ptr)&_2445;
    RHS_Slice((s1_ptr)_2445, _start, _stop);
    RefDS(_2445);
    _0 = _2445;
    _2445 = _1retval(_2445);
    DeRefDS(_0);
    return _2445;
    ;
}


_1eu_system(int _id1, int _mode)
{
    int _2448 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_mode)) {
        _1 = (long)(DBL_PTR(_mode)->dbl);
        DeRefDS(_mode);
        _mode = _1;
    }

    // 	system(data[id1], mode)
    _2 = (int)SEQ_PTR(_1data);
    _2448 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2448);
    system_call(_2448, _mode);

    // end procedure
    DeRef(_2448);
    return 0;
    ;
}


_1eu_system_exec(int _id1, int _mode)
{
    int _i;
    int _2449 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_mode)) {
        _1 = (long)(DBL_PTR(_mode)->dbl);
        DeRefDS(_mode);
        _mode = _1;
    }

    // 	i = system_exec(data[id1], mode) -- returns the exit code from the called process.
    _2 = (int)SEQ_PTR(_1data);
    _2449 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2449);
    _i = system_exec_call(_2449, _mode);

    // 	return i
    DeRef(_2449);
    return _i;
    ;
}


_1eu_tan(int _id)
{
    int _2451 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id)) {
        _1 = (long)(DBL_PTR(_id)->dbl);
        DeRefDS(_id);
        _id = _1;
    }

    // 	return retval(tan(data[id]))
    _2 = (int)SEQ_PTR(_1data);
    _2451 = (int)*(((s1_ptr)_2)->base + _id);
    Ref(_2451);
    _0 = _2451;
    if (IS_ATOM_INT(_2451))
        _2451 = e_tan(_2451);
    else
        _2451 = unary_op(TAN, _2451);
    DeRef(_0);
    Ref(_2451);
    _0 = _2451;
    _2451 = _1retval(_2451);
    DeRef(_0);
    return _2451;
    ;
}


_1eu_time()
{
    int _2454 = 0;
    int _0, _1, _2;
    

    // 	return retval(time())
    _2454 = NewDouble(current_time());
    RefDS(_2454);
    _0 = _2454;
    _2454 = _1retval(_2454);
    DeRefDS(_0);
    return _2454;
    ;
}


_1eu_xor_bits(int _id1, int _id2)
{
    int _2457 = 0;
    int _2456 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id1)) {
        _1 = (long)(DBL_PTR(_id1)->dbl);
        DeRefDS(_id1);
        _id1 = _1;
    }
    if (!IS_ATOM_INT(_id2)) {
        _1 = (long)(DBL_PTR(_id2)->dbl);
        DeRefDS(_id2);
        _id2 = _1;
    }

    // 	return retval(xor_bits(data[id1], data[id2]))
    _2 = (int)SEQ_PTR(_1data);
    _2456 = (int)*(((s1_ptr)_2)->base + _id1);
    Ref(_2456);
    _2 = (int)SEQ_PTR(_1data);
    _2457 = (int)*(((s1_ptr)_2)->base + _id2);
    Ref(_2457);
    _0 = _2457;
    if (IS_ATOM_INT(_2456) && IS_ATOM_INT(_2457)) {
        _2457 = (_2456 ^ _2457);
    }
    else {
        _2457 = binary_op(XOR_BITS, _2456, _2457);
    }
    DeRef(_0);
    Ref(_2457);
    _0 = _2457;
    _2457 = _1retval(_2457);
    DeRef(_0);
    DeRef(_2456);
    return _2457;
    ;
}


_1eu_allocate(int _n)
{
    int _2460 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n)) {
        _1 = (long)(DBL_PTR(_n)->dbl);
        DeRefDS(_n);
        _n = _1;
    }

    // 	return retval(allocate(n))
    _2460 = _2allocate(_n);
    Ref(_2460);
    _0 = _2460;
    _2460 = _1retval(_2460);
    DeRef(_0);
    return _2460;
    ;
}


_1eu_free(int _did)
{
    int _2462 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	free(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2462 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2462);
    Ref(_2462);
    _2free(_2462);

    // end procedure
    DeRef(_2462);
    return 0;
    ;
}


_1eu_int_to_bytes(int _did)
{
    int _2463 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(int_to_bytes(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2463 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2463);
    Ref(_2463);
    _0 = _2463;
    _2463 = _2int_to_bytes(_2463);
    DeRef(_0);
    RefDS(_2463);
    _0 = _2463;
    _2463 = _1retval(_2463);
    DeRefDSi(_0);
    return _2463;
    ;
}


_1eu_bytes_to_int(int _did)
{
    int _2466 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(bytes_to_int(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2466 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2466);
    Ref(_2466);
    _0 = _2466;
    _2466 = _2bytes_to_int(_2466);
    DeRef(_0);
    Ref(_2466);
    _0 = _2466;
    _2466 = _1retval(_2466);
    DeRef(_0);
    return _2466;
    ;
}


_1eu_int_to_bits(int _did, int _nbits)
{
    int _2469 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }
    if (!IS_ATOM_INT(_nbits)) {
        _1 = (long)(DBL_PTR(_nbits)->dbl);
        DeRefDS(_nbits);
        _nbits = _1;
    }

    // 	return retval(int_to_bits(data[did], nbits))
    _2 = (int)SEQ_PTR(_1data);
    _2469 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2469);
    Ref(_2469);
    _0 = _2469;
    _2469 = _2int_to_bits(_2469, _nbits);
    DeRef(_0);
    RefDS(_2469);
    _0 = _2469;
    _2469 = _1retval(_2469);
    DeRefDS(_0);
    return _2469;
    ;
}


_1eu_bits_to_int(int _did)
{
    int _2472 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(bits_to_int(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2472 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2472);
    Ref(_2472);
    _0 = _2472;
    _2472 = _2bits_to_int(_2472);
    DeRef(_0);
    Ref(_2472);
    _0 = _2472;
    _2472 = _1retval(_2472);
    DeRef(_0);
    return _2472;
    ;
}


_1eu_set_rand(int _seed)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_seed)) {
        _1 = (long)(DBL_PTR(_seed)->dbl);
        DeRefDS(_seed);
        _seed = _1;
    }

    // 	set_rand(seed)
    _2set_rand(_seed);

    // end procedure
    return 0;
    ;
}


_1eu_crash_message(int _did)
{
    int _2475 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	crash_message(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2475 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2475);
    Ref(_2475);
    _2crash_message(_2475);

    // end procedure
    DeRef(_2475);
    return 0;
    ;
}


_1eu_crash_file(int _did)
{
    int _2476 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	crash_file(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2476 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2476);
    Ref(_2476);
    _2crash_file(_2476);

    // end procedure
    DeRef(_2476);
    return 0;
    ;
}


_1eu_atom_to_float64(int _did)
{
    int _2477 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(atom_to_float64(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2477 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2477);
    Ref(_2477);
    _0 = _2477;
    _2477 = _2atom_to_float64(_2477);
    DeRef(_0);
    RefDS(_2477);
    _0 = _2477;
    _2477 = _1retval(_2477);
    DeRefDSi(_0);
    return _2477;
    ;
}


_1eu_atom_to_float32(int _did)
{
    int _2480 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(atom_to_float32(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2480 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2480);
    Ref(_2480);
    _0 = _2480;
    _2480 = _2atom_to_float32(_2480);
    DeRef(_0);
    RefDS(_2480);
    _0 = _2480;
    _2480 = _1retval(_2480);
    DeRefDSi(_0);
    return _2480;
    ;
}


_1eu_float64_to_atom(int _did)
{
    int _2483 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(float64_to_atom(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2483 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2483);
    Ref(_2483);
    _0 = _2483;
    _2483 = _2float64_to_atom(_2483);
    DeRef(_0);
    Ref(_2483);
    _0 = _2483;
    _2483 = _1retval(_2483);
    DeRef(_0);
    return _2483;
    ;
}


_1eu_float32_to_atom(int _did)
{
    int _2486 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(float32_to_atom(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2486 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2486);
    Ref(_2486);
    _0 = _2486;
    _2486 = _2float32_to_atom(_2486);
    DeRef(_0);
    Ref(_2486);
    _0 = _2486;
    _2486 = _1retval(_2486);
    DeRef(_0);
    return _2486;
    ;
}


_1eu_allocate_string(int _did)
{
    int _2489 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(allocate_string(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2489 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2489);
    Ref(_2489);
    _0 = _2489;
    _2489 = _2allocate_string(_2489);
    DeRef(_0);
    Ref(_2489);
    _0 = _2489;
    _2489 = _1retval(_2489);
    DeRef(_0);
    return _2489;
    ;
}


_1eu_open_dll(int _did)
{
    int _2492 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(open_dll(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2492 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2492);
    Ref(_2492);
    _0 = _2492;
    _2492 = _3open_dll(_2492);
    DeRef(_0);
    Ref(_2492);
    _0 = _2492;
    _2492 = _1retval(_2492);
    DeRef(_0);
    return _2492;
    ;
}


_1eu_define_c_var(int _did1, int _did2)
{
    int _2496 = 0;
    int _2495 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return retval(define_c_var(data[did1], data[did2]))
    _2 = (int)SEQ_PTR(_1data);
    _2495 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2495);
    _2 = (int)SEQ_PTR(_1data);
    _2496 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2496);
    Ref(_2495);
    Ref(_2496);
    _0 = _2496;
    _2496 = _3define_c_var(_2495, _2496);
    DeRef(_0);
    Ref(_2496);
    _0 = _2496;
    _2496 = _1retval(_2496);
    DeRef(_0);
    DeRef(_2495);
    return _2496;
    ;
}


_1eu_define_c_proc(int _did1, int _did2, int _did3)
{
    int _i;
    int _2501 = 0;
    int _2500 = 0;
    int _2499 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }
    if (!IS_ATOM_INT(_did3)) {
        _1 = (long)(DBL_PTR(_did3)->dbl);
        DeRefDS(_did3);
        _did3 = _1;
    }

    // 	i = define_c_proc(data[did1], data[did2], data[did3])
    _2 = (int)SEQ_PTR(_1data);
    _2499 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2499);
    _2 = (int)SEQ_PTR(_1data);
    _2500 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2500);
    _2 = (int)SEQ_PTR(_1data);
    _2501 = (int)*(((s1_ptr)_2)->base + _did3);
    Ref(_2501);
    Ref(_2499);
    Ref(_2500);
    Ref(_2501);
    _i = _3define_c_proc(_2499, _2500, _2501);

    // 	return i
    DeRef(_2501);
    DeRef(_2500);
    DeRef(_2499);
    return _i;
    ;
}


_1eu_define_c_func(int _did1, int _did2, int _did3, int _did4)
{
    int _i;
    int _2506 = 0;
    int _2505 = 0;
    int _2504 = 0;
    int _2503 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }
    if (!IS_ATOM_INT(_did3)) {
        _1 = (long)(DBL_PTR(_did3)->dbl);
        DeRefDS(_did3);
        _did3 = _1;
    }
    if (!IS_ATOM_INT(_did4)) {
        _1 = (long)(DBL_PTR(_did4)->dbl);
        DeRefDS(_did4);
        _did4 = _1;
    }

    // 	i = define_c_func(data[did1], data[did2], data[did3], data[did4])
    _2 = (int)SEQ_PTR(_1data);
    _2503 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2503);
    _2 = (int)SEQ_PTR(_1data);
    _2504 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2504);
    _2 = (int)SEQ_PTR(_1data);
    _2505 = (int)*(((s1_ptr)_2)->base + _did3);
    Ref(_2505);
    _2 = (int)SEQ_PTR(_1data);
    _2506 = (int)*(((s1_ptr)_2)->base + _did4);
    Ref(_2506);
    Ref(_2503);
    Ref(_2504);
    Ref(_2505);
    Ref(_2506);
    _i = _3define_c_func(_2503, _2504, _2505, _2506);

    // 	return i
    DeRef(_2506);
    DeRef(_2505);
    DeRef(_2504);
    DeRef(_2503);
    return _i;
    ;
}


_1eu_call_back(int _did)
{
    int _2508 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(call_back(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2508 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2508);
    Ref(_2508);
    _0 = _2508;
    _2508 = _3call_back(_2508);
    DeRef(_0);
    Ref(_2508);
    _0 = _2508;
    _2508 = _1retval(_2508);
    DeRef(_0);
    return _2508;
    ;
}


_1eu_free_console()
{
    int _0, _1, _2;
    

    // 	free_console()
    _3free_console();

    // end procedure
    return 0;
    ;
}


_1eu_seek(int _fn_id, int _pos)
{
    int _i;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_pos)) {
        _1 = (long)(DBL_PTR(_pos)->dbl);
        DeRefDS(_pos);
        _pos = _1;
    }

    // 	i = seek(fn_id, pos) -- returns 0 on success
    _i = _4seek(_fn_id, _pos);

    // 	return i
    return _i;
    ;
}


_1eu_where(int _fn_id)
{
    int _pos;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	pos = where(fn_id)
    _pos = _4where(_fn_id);
    if (!IS_ATOM_INT(_pos)) {
        _1 = (long)(DBL_PTR(_pos)->dbl);
        DeRefDS(_pos);
        _pos = _1;
    }

    // 	return pos
    return _pos;
    ;
}


_1eu_flush(int _fn_id)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	flush(fn_id)
    _4flush(_fn_id);

    // end procedure
    return 0;
    ;
}


_1eu_lock_file(int _fn_id, int _t, int _did)
{
    int _i;
    int _2513 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_t)) {
        _1 = (long)(DBL_PTR(_t)->dbl);
        DeRefDS(_t);
        _t = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = lock_file(fn_id, t, data[did]) -- returns 1 on success, 0 on failure
    _2 = (int)SEQ_PTR(_1data);
    _2513 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2513);
    Ref(_2513);
    _i = _4lock_file(_fn_id, _t, _2513);

    // 	return i
    DeRef(_2513);
    return _i;
    ;
}


_1eu_unlock_file(int _fn_id, int _did)
{
    int _2515 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	unlock_file(fn_id, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2515 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2515);
    Ref(_2515);
    _4unlock_file(_fn_id, _2515);

    // end procedure
    DeRef(_2515);
    return 0;
    ;
}


_1eu_dir(int _did)
{
    int _2516 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(dir(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2516 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2516);
    Ref(_2516);
    _0 = _2516;
    _2516 = _4dir(_2516);
    DeRef(_0);
    Ref(_2516);
    _0 = _2516;
    _2516 = _1retval(_2516);
    DeRef(_0);
    return _2516;
    ;
}


_1eu_current_dir()
{
    int _2519 = 0;
    int _0, _1, _2;
    

    // 	return retval(current_dir())
    _2519 = _4current_dir();
    RefDS(_2519);
    _0 = _2519;
    _2519 = _1retval(_2519);
    DeRefDSi(_0);
    return _2519;
    ;
}


_1eu_chdir(int _did)
{
    int _2521 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(chdir(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2521 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2521);
    Ref(_2521);
    _0 = _2521;
    _2521 = _4chdir(_2521);
    DeRef(_0);
    _2521 = _1retval(_2521);
    return _2521;
    ;
}


_1eu_allow_break(int _condition)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_condition)) {
        _1 = (long)(DBL_PTR(_condition)->dbl);
        DeRefDS(_condition);
        _condition = _1;
    }

    // 	allow_break(condition)
    _4allow_break(_condition);

    // end procedure
    return 0;
    ;
}


_1eu_check_break()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = check_break()
    _i = _4check_break();

    // 	return i
    return _i;
    ;
}


_1eu_wait_key()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = wait_key()
    _i = _7wait_key();

    // 	return i
    return _i;
    ;
}


_1eu_get(int _fn_id)
{
    int _2526 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }

    // 	return retval(get(fn_id))
    _2526 = _7get(_fn_id);
    RefDS(_2526);
    _0 = _2526;
    _2526 = _1retval(_2526);
    DeRefDS(_0);
    return _2526;
    ;
}


_1eu_value(int _did)
{
    int _2528 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(value(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2528 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2528);
    Ref(_2528);
    _0 = _2528;
    _2528 = _7value(_2528);
    DeRef(_0);
    RefDS(_2528);
    _0 = _2528;
    _2528 = _1retval(_2528);
    DeRefDS(_0);
    return _2528;
    ;
}


_1eu_prompt_number(int _did1, int _did2)
{
    int _2532 = 0;
    int _2531 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return retval(prompt_number(data[did1], data[did2]))
    _2 = (int)SEQ_PTR(_1data);
    _2531 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2531);
    _2 = (int)SEQ_PTR(_1data);
    _2532 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2532);
    Ref(_2531);
    Ref(_2532);
    _0 = _2532;
    _2532 = _7prompt_number(_2531, _2532);
    DeRef(_0);
    Ref(_2532);
    _0 = _2532;
    _2532 = _1retval(_2532);
    DeRef(_0);
    DeRef(_2531);
    return _2532;
    ;
}


_1eu_prompt_string(int _did)
{
    int _2535 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(prompt_string(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2535 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2535);
    Ref(_2535);
    _0 = _2535;
    _2535 = _7prompt_string(_2535);
    DeRef(_0);
    RefDS(_2535);
    _0 = _2535;
    _2535 = _1retval(_2535);
    DeRefDSi(_0);
    return _2535;
    ;
}


_1eu_get_bytes(int _fn_id, int _n)
{
    int _2538 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_n)) {
        _1 = (long)(DBL_PTR(_n)->dbl);
        DeRefDS(_n);
        _n = _1;
    }

    // 	return retval(get_bytes(fn_id, n))
    _2538 = _7get_bytes(_fn_id, _n);
    RefDS(_2538);
    _0 = _2538;
    _2538 = _1retval(_2538);
    DeRefDSi(_0);
    return _2538;
    ;
}


_1eu_video_config()
{
    int _2540 = 0;
    int _0, _1, _2;
    

    // 	return retval(video_config())
    _2540 = _8video_config();
    RefDS(_2540);
    _0 = _2540;
    _2540 = _1retval(_2540);
    DeRefDSi(_0);
    return _2540;
    ;
}


_1eu_cursor(int _style)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_style)) {
        _1 = (long)(DBL_PTR(_style)->dbl);
        DeRefDS(_style);
        _style = _1;
    }

    // 	cursor(style)
    _8cursor(_style);

    // end procedure
    return 0;
    ;
}


_1eu_get_position()
{
    int _2542 = 0;
    int _0, _1, _2;
    

    // 	return retval(get_position())
    _2542 = _8get_position();
    RefDS(_2542);
    _0 = _2542;
    _2542 = _1retval(_2542);
    DeRefDSi(_0);
    return _2542;
    ;
}


_1eu_text_rows(int _rows)
{
    int _i;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rows)) {
        _1 = (long)(DBL_PTR(_rows)->dbl);
        DeRefDS(_rows);
        _rows = _1;
    }

    // 	i = text_rows(rows)
    _i = _8text_rows(_rows);

    // 	return i
    return _i;
    ;
}


_1eu_wrap(int _on)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_on)) {
        _1 = (long)(DBL_PTR(_on)->dbl);
        DeRefDS(_on);
        _on = _1;
    }

    // 	wrap(on)
    _8wrap(_on);

    // end procedure
    return 0;
    ;
}


_1eu_scroll(int _amount, int _top_line, int _bottom_line)
{
    int _2547;
    int _2546;
    int _2545;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount)) {
        _1 = (long)(DBL_PTR(_amount)->dbl);
        DeRefDS(_amount);
        _amount = _1;
    }
    if (!IS_ATOM_INT(_top_line)) {
        _1 = (long)(DBL_PTR(_top_line)->dbl);
        DeRefDS(_top_line);
        _top_line = _1;
    }
    if (!IS_ATOM_INT(_bottom_line)) {
        _1 = (long)(DBL_PTR(_bottom_line)->dbl);
        DeRefDS(_bottom_line);
        _bottom_line = _1;
    }

    // 	eu_scroll(amount, top_line, bottom_line)
    _2545 = _amount;
    _2546 = _top_line;
    _2547 = _bottom_line;
    _1eu_scroll(_2545, _2546, _2547);

    // end procedure
    return 0;
    ;
}


_1eu_text_color(int _byte_value)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_byte_value)) {
        _1 = (long)(DBL_PTR(_byte_value)->dbl);
        DeRefDS(_byte_value);
        _byte_value = _1;
    }

    // 	text_color(byte_value)
    _8text_color(_byte_value);

    // end procedure
    return 0;
    ;
}


_1eu_bk_color(int _byte_value)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_byte_value)) {
        _1 = (long)(DBL_PTR(_byte_value)->dbl);
        DeRefDS(_byte_value);
        _byte_value = _1;
    }

    // 	bk_color(byte_value)
    _8bk_color(_byte_value);

    // end procedure
    return 0;
    ;
}


_1eu_read_bitmap(int _did)
{
    int _2548 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(read_bitmap(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2548 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2548);
    Ref(_2548);
    _0 = _2548;
    _2548 = _9read_bitmap(_2548);
    DeRef(_0);
    Ref(_2548);
    _0 = _2548;
    _2548 = _1retval(_2548);
    DeRef(_0);
    return _2548;
    ;
}


_1eu_get_screen_char(int _line, int _column)
{
    int _2551 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line)) {
        _1 = (long)(DBL_PTR(_line)->dbl);
        DeRefDS(_line);
        _line = _1;
    }
    if (!IS_ATOM_INT(_column)) {
        _1 = (long)(DBL_PTR(_column)->dbl);
        DeRefDS(_column);
        _column = _1;
    }

    // 	return retval(get_screen_char(line, column))
    _2551 = _9get_screen_char(_line, _column);
    RefDS(_2551);
    _0 = _2551;
    _2551 = _1retval(_2551);
    DeRefDS(_0);
    return _2551;
    ;
}


_1eu_put_screen_char(int _line, int _column, int _did)
{
    int _2553 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line)) {
        _1 = (long)(DBL_PTR(_line)->dbl);
        DeRefDS(_line);
        _line = _1;
    }
    if (!IS_ATOM_INT(_column)) {
        _1 = (long)(DBL_PTR(_column)->dbl);
        DeRefDS(_column);
        _column = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	put_screen_char(line, column, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2553 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2553);
    Ref(_2553);
    _9put_screen_char(_line, _column, _2553);

    // end procedure
    DeRef(_2553);
    return 0;
    ;
}


_1eu_display_text_image(int _did1, int _did2)
{
    int _2555 = 0;
    int _2554 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	display_text_image(data[did1], data[did2])
    _2 = (int)SEQ_PTR(_1data);
    _2554 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2554);
    _2 = (int)SEQ_PTR(_1data);
    _2555 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2555);
    Ref(_2554);
    Ref(_2555);
    _9display_text_image(_2554, _2555);

    // end procedure
    DeRef(_2555);
    DeRef(_2554);
    return 0;
    ;
}


_1eu_save_text_image(int _did1, int _did2)
{
    int _2557 = 0;
    int _2556 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return retval(save_text_image(data[did1], data[did2]))
    _2 = (int)SEQ_PTR(_1data);
    _2556 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2556);
    _2 = (int)SEQ_PTR(_1data);
    _2557 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2557);
    Ref(_2556);
    Ref(_2557);
    _0 = _2557;
    _2557 = _9save_text_image(_2556, _2557);
    DeRef(_0);
    RefDS(_2557);
    _0 = _2557;
    _2557 = _1retval(_2557);
    DeRefDS(_0);
    DeRef(_2556);
    return _2557;
    ;
}


_1eu_save_bitmap(int _did1, int _did2)
{
    int _2561 = 0;
    int _2560 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return save_bitmap(data[did1], data[did2])
    _2 = (int)SEQ_PTR(_1data);
    _2560 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2560);
    _2 = (int)SEQ_PTR(_1data);
    _2561 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2561);
    Ref(_2560);
    Ref(_2561);
    _0 = _2561;
    _2561 = _9save_bitmap(_2560, _2561);
    DeRef(_0);
    DeRef(_2560);
    return _2561;
    ;
}


_1eu_instance()
{
    int _2563 = 0;
    int _0, _1, _2;
    

    // 	return retval(instance())
    _2563 = _6instance();
    Ref(_2563);
    _0 = _2563;
    _2563 = _1retval(_2563);
    DeRef(_0);
    return _2563;
    ;
}


_1eu_sleep(int _seconds)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_seconds)) {
        _1 = (long)(DBL_PTR(_seconds)->dbl);
        DeRefDS(_seconds);
        _seconds = _1;
    }

    // 	sleep(seconds)
    _6sleep(_seconds);

    // end procedure
    return 0;
    ;
}


_1eu_reverse(int _did)
{
    int _2565 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(reverse(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2565 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2565);
    Ref(_2565);
    _0 = _2565;
    _2565 = _6reverse(_2565);
    DeRef(_0);
    RefDS(_2565);
    _0 = _2565;
    _2565 = _1retval(_2565);
    DeRefDS(_0);
    return _2565;
    ;
}


_1eu_sprint(int _did)
{
    int _2568 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(sprint(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2568 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2568);
    Ref(_2568);
    _0 = _2568;
    _2568 = _6sprint(_2568);
    DeRef(_0);
    RefDS(_2568);
    _0 = _2568;
    _2568 = _1retval(_2568);
    DeRefDS(_0);
    return _2568;
    ;
}


_1eu_pretty_print(int _fn_id, int _did1, int _did2)
{
    int _2572 = 0;
    int _2571 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	pretty_print(fn_id, data[did1], data[did2])
    _2 = (int)SEQ_PTR(_1data);
    _2571 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2571);
    _2 = (int)SEQ_PTR(_1data);
    _2572 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2572);
    Ref(_2571);
    Ref(_2572);
    _6pretty_print(_fn_id, _2571, _2572);

    // end procedure
    DeRef(_2572);
    DeRef(_2571);
    return 0;
    ;
}


_1eu_arccos(int _did)
{
    int _2573 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(arccos(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2573 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2573);
    Ref(_2573);
    _0 = _2573;
    _2573 = _6arccos(_2573);
    DeRef(_0);
    Ref(_2573);
    _0 = _2573;
    _2573 = _1retval(_2573);
    DeRef(_0);
    return _2573;
    ;
}


_1eu_arcsin(int _did)
{
    int _2576 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(arcsin(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2576 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2576);
    Ref(_2576);
    _0 = _2576;
    _2576 = _6arcsin(_2576);
    DeRef(_0);
    Ref(_2576);
    _0 = _2576;
    _2576 = _1retval(_2576);
    DeRef(_0);
    return _2576;
    ;
}


_1eu_sort(int _did)
{
    int _2579 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(sort(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2579 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2579);
    Ref(_2579);
    _0 = _2579;
    _2579 = _5sort(_2579);
    DeRef(_0);
    RefDS(_2579);
    _0 = _2579;
    _2579 = _1retval(_2579);
    DeRefDS(_0);
    return _2579;
    ;
}


_1eu_lower(int _did)
{
    int _2582 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(lower(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2582 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2582);
    Ref(_2582);
    _0 = _2582;
    _2582 = _10lower(_2582);
    DeRef(_0);
    Ref(_2582);
    _0 = _2582;
    _2582 = _1retval(_2582);
    DeRef(_0);
    return _2582;
    ;
}


_1eu_upper(int _did)
{
    int _2585 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(upper(data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2585 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2585);
    Ref(_2585);
    _0 = _2585;
    _2585 = _10upper(_2585);
    DeRef(_0);
    Ref(_2585);
    _0 = _2585;
    _2585 = _1retval(_2585);
    DeRef(_0);
    return _2585;
    ;
}


_1eu_wildcard_match(int _did1, int _did2)
{
    int _2589 = 0;
    int _2588 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return retval(wildcard_match(data[did1], data[did2]))
    _2 = (int)SEQ_PTR(_1data);
    _2588 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2588);
    _2 = (int)SEQ_PTR(_1data);
    _2589 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2589);
    Ref(_2588);
    Ref(_2589);
    _0 = _2589;
    _2589 = _10wildcard_match(_2588, _2589);
    DeRef(_0);
    _2589 = _1retval(_2589);
    DeRef(_2588);
    return _2589;
    ;
}


_1eu_wildcard_file(int _did1, int _did2)
{
    int _2593 = 0;
    int _2592 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	return retval(wildcard_file(data[did1], data[did2]))
    _2 = (int)SEQ_PTR(_1data);
    _2592 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2592);
    _2 = (int)SEQ_PTR(_1data);
    _2593 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2593);
    Ref(_2592);
    Ref(_2593);
    _0 = _2593;
    _2593 = _10wildcard_file(_2592, _2593);
    DeRef(_0);
    _2593 = _1retval(_2593);
    DeRef(_2592);
    return _2593;
    ;
}


_1eudb_dump(int _fn_id, int _low_level_too)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_id)) {
        _1 = (long)(DBL_PTR(_fn_id)->dbl);
        DeRefDS(_fn_id);
        _fn_id = _1;
    }
    if (!IS_ATOM_INT(_low_level_too)) {
        _1 = (long)(DBL_PTR(_low_level_too)->dbl);
        DeRefDS(_low_level_too);
        _low_level_too = _1;
    }

    // 	db_dump(fn_id, low_level_too)
    _11db_dump(_fn_id, _low_level_too);

    // end procedure
    return 0;
    ;
}


_1eudb_create(int _did, int _lock_method)
{
    int _i;
    int _2596 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }
    if (!IS_ATOM_INT(_lock_method)) {
        _1 = (long)(DBL_PTR(_lock_method)->dbl);
        DeRefDS(_lock_method);
        _lock_method = _1;
    }

    // 	i = db_create(data[did], lock_method)
    _2 = (int)SEQ_PTR(_1data);
    _2596 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2596);
    Ref(_2596);
    _i = _11db_create(_2596, _lock_method);

    // 	return i
    DeRef(_2596);
    return _i;
    ;
}


_1eudb_open(int _did, int _lock_method)
{
    int _i;
    int _2598 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }
    if (!IS_ATOM_INT(_lock_method)) {
        _1 = (long)(DBL_PTR(_lock_method)->dbl);
        DeRefDS(_lock_method);
        _lock_method = _1;
    }

    // 	i = db_open(data[did], lock_method)
    _2 = (int)SEQ_PTR(_1data);
    _2598 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2598);
    Ref(_2598);
    _i = _11db_open(_2598, _lock_method);

    // 	return i
    DeRef(_2598);
    return _i;
    ;
}


_1eudb_select(int _did)
{
    int _i;
    int _2600 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = db_select(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2600 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2600);
    Ref(_2600);
    _i = _11db_select(_2600);

    // 	return i
    DeRef(_2600);
    return _i;
    ;
}


_1eudb_close()
{
    int _0, _1, _2;
    

    // 	db_close()
    _11db_close();

    // end procedure
    return 0;
    ;
}


_1eudb_select_table(int _did)
{
    int _i;
    int _2602 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = db_select_table(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2602 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2602);
    Ref(_2602);
    _i = _11db_select_table(_2602);

    // 	return i
    DeRef(_2602);
    return _i;
    ;
}


_1eudb_create_table(int _did)
{
    int _i;
    int _2604 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = db_create_table(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2604 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2604);
    Ref(_2604);
    _i = _11db_create_table(_2604);

    // 	return i
    DeRef(_2604);
    return _i;
    ;
}


_1eudb_delete_table(int _did)
{
    int _2606 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	db_delete_table(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2606 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2606);
    Ref(_2606);
    _11db_delete_table(_2606);

    // end procedure
    DeRef(_2606);
    return 0;
    ;
}


_1eudb_rename_table(int _did1, int _did2)
{
    int _2608 = 0;
    int _2607 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	db_rename_table(data[did1], data[did2])
    _2 = (int)SEQ_PTR(_1data);
    _2607 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2607);
    _2 = (int)SEQ_PTR(_1data);
    _2608 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2608);
    Ref(_2607);
    Ref(_2608);
    _11db_rename_table(_2607, _2608);

    // end procedure
    DeRef(_2608);
    DeRef(_2607);
    return 0;
    ;
}


_1eudb_table_list()
{
    int _2609 = 0;
    int _0, _1, _2;
    

    // 	return retval(db_table_list())
    _2609 = _11db_table_list();
    RefDS(_2609);
    _0 = _2609;
    _2609 = _1retval(_2609);
    DeRefDS(_0);
    return _2609;
    ;
}


_1eudb_find_key(int _did)
{
    int _rec_id;
    int _2611 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	rec_id = db_find_key(data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2611 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2611);
    Ref(_2611);
    _rec_id = _11db_find_key(_2611);
    if (!IS_ATOM_INT(_rec_id)) {
        _1 = (long)(DBL_PTR(_rec_id)->dbl);
        DeRefDS(_rec_id);
        _rec_id = _1;
    }

    // 	return rec_id
    DeRef(_2611);
    return _rec_id;
    ;
}


_1eudb_insert(int _did1, int _did2)
{
    int _i;
    int _2614 = 0;
    int _2613 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did1)) {
        _1 = (long)(DBL_PTR(_did1)->dbl);
        DeRefDS(_did1);
        _did1 = _1;
    }
    if (!IS_ATOM_INT(_did2)) {
        _1 = (long)(DBL_PTR(_did2)->dbl);
        DeRefDS(_did2);
        _did2 = _1;
    }

    // 	i = db_insert(data[did1], data[did2])
    _2 = (int)SEQ_PTR(_1data);
    _2613 = (int)*(((s1_ptr)_2)->base + _did1);
    Ref(_2613);
    _2 = (int)SEQ_PTR(_1data);
    _2614 = (int)*(((s1_ptr)_2)->base + _did2);
    Ref(_2614);
    Ref(_2613);
    Ref(_2614);
    _i = _11db_insert(_2613, _2614);

    // 	return i
    DeRef(_2614);
    DeRef(_2613);
    return _i;
    ;
}


_1eudb_delete_record(int _rec_id)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rec_id)) {
        _1 = (long)(DBL_PTR(_rec_id)->dbl);
        DeRefDS(_rec_id);
        _rec_id = _1;
    }

    // 	db_delete_record(rec_id)
    _11db_delete_record(_rec_id);

    // end procedure
    return 0;
    ;
}


_1eudb_replace_data(int _rec_id, int _did)
{
    int _2616 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rec_id)) {
        _1 = (long)(DBL_PTR(_rec_id)->dbl);
        DeRefDS(_rec_id);
        _rec_id = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	db_replace_data(rec_id, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2616 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2616);
    Ref(_2616);
    _11db_replace_data(_rec_id, _2616);

    // end procedure
    DeRef(_2616);
    return 0;
    ;
}


_1eudb_table_size()
{
    int _i;
    int _0, _1, _2;
    

    // 	i = db_table_size() -- returns an int
    _i = _11db_table_size();

    // 	return i
    return _i;
    ;
}


_1eudb_record_data(int _rec_id)
{
    int _2618 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rec_id)) {
        _1 = (long)(DBL_PTR(_rec_id)->dbl);
        DeRefDS(_rec_id);
        _rec_id = _1;
    }

    // 	return retval(db_record_data(rec_id))
    _2618 = _11db_record_data(_rec_id);
    Ref(_2618);
    _0 = _2618;
    _2618 = _1retval(_2618);
    DeRef(_0);
    return _2618;
    ;
}


_1eudb_record_key(int _rec_id)
{
    int _2620 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rec_id)) {
        _1 = (long)(DBL_PTR(_rec_id)->dbl);
        DeRefDS(_rec_id);
        _rec_id = _1;
    }

    // 	return retval(db_record_key(rec_id))
    _2620 = _11db_record_key(_rec_id);
    Ref(_2620);
    _0 = _2620;
    _2620 = _1retval(_2620);
    DeRef(_0);
    return _2620;
    ;
}


_1eudb_compress()
{
    int _2622;
    int _0, _1, _2;
    

    // 	return db_compress()
    _2622 = _11db_compress();
    return _2622;
    ;
}


_1eu_call_func_std(int _rid, int _did)
{
    int _2623 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(call_func(rid, data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2623 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2623);
    _1 = (int)SEQ_PTR(_2623);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    DeRef(_2623);
    _2623 = _1;
    Ref(_2623);
    _0 = _2623;
    _2623 = _1retval(_2623);
    DeRef(_0);
    return _2623;
    ;
}


_1eu_call_func_val(int _rid, int _did)
{
    int _2626 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	return retval(call_func(rid, data[did]))
    _2 = (int)SEQ_PTR(_1data);
    _2626 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2626);
    _1 = (int)SEQ_PTR(_2626);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    DeRef(_2626);
    _2626 = _1;
    Ref(_2626);
    _0 = _2626;
    _2626 = _1retval(_2626);
    DeRef(_0);
    return _2626;
    ;
}


_1eu_call_func(int _rid, int _did)
{
    int _i;
    int _2629 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = call_func(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2629 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2629);
    _1 = (int)SEQ_PTR(_2629);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }
    _i = _1;
    if (!IS_ATOM_INT(_i)) {
        _1 = (long)(DBL_PTR(_i)->dbl);
        DeRefDS(_i);
        _i = _1;
    }

    // 	return i
    DeRef(_2629);
    return _i;
    ;
}


_1eu_call_proc(int _rid, int _did)
{
    int _2631 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid)) {
        _1 = (long)(DBL_PTR(_rid)->dbl);
        DeRefDS(_rid);
        _rid = _1;
    }
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	call_proc(rid, data[did])
    _2 = (int)SEQ_PTR(_1data);
    _2631 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2631);
    _1 = (int)SEQ_PTR(_2631);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rid].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
    }

    // end procedure
    DeRef(_2631);
    return 0;
    ;
}


_1eu_routine_id(int _did)
{
    int _i;
    int _2632 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_did)) {
        _1 = (long)(DBL_PTR(_did)->dbl);
        DeRefDS(_did);
        _did = _1;
    }

    // 	i = routine_id(data[did]) -- this is the only time it uses a string
    _2 = (int)SEQ_PTR(_1data);
    _2632 = (int)*(((s1_ptr)_2)->base + _did);
    Ref(_2632);
    _i = CRoutineId(370, 1, _2632);

    // 	return i
    DeRef(_2632);
    return _i;
    ;
}


_1eu_routine_id_str(int _low, int _high)
{
    int _i;
    int _2634 = 0;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_low)) {
        _1 = (long)(DBL_PTR(_low)->dbl);
        DeRefDS(_low);
        _low = _1;
    }
    if (!IS_ATOM_INT(_high)) {
        _1 = (long)(DBL_PTR(_high)->dbl);
        DeRefDS(_high);
        _high = _1;
    }

    // 	i = routine_id(peek_string(get_address(low, high))) -- this is the only time it uses a string
    _2634 = _1get_address(_low, _high);
    Ref(_2634);
    _0 = _2634;
    _2634 = _12peek_string(_2634);
    DeRef(_0);
    _i = CRoutineId(371, 1, _2634);

    // 	return i
    DeRefDSi(_2634);
    return _i;
    ;
}


