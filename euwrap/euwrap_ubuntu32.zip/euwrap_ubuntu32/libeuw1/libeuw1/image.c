// Euphoria To C version 3.1.1
#include "/home/owner/euphoria/include/euphoria.h"
#include "main-.h"

int _9get_word()
{
    int _lower;
    int _upper;
    int _644;
    int _0, _1, _2;
    

    //     lower = getc(fn)
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _lower = getc(xstdin);
        }
        else
            _lower = getc(last_r_file_ptr);
    }
    else
        _lower = getc(last_r_file_ptr);

    //     upper = getc(fn)
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _upper = getc(xstdin);
        }
        else
            _upper = getc(last_r_file_ptr);
    }
    else
        _upper = getc(last_r_file_ptr);

    //     if upper = EOF then
    if (_upper != -1)
        goto L1;

    // 	error_code = BMP_UNEXPECTED_EOF
    _9error_code = 2;
L1:

    //     return upper * 256 + lower
    _644 = _upper * 256;
    _644 = _644 + _lower;
    return _644;
    ;
}


int _9get_dword()
{
    int _lower;
    int _upper;
    int _649 = 0;
    int _0, _1, _2;
    

    //     lower = get_word()
    _lower = _9get_word();

    //     upper = get_word()
    _upper = _9get_word();

    //     return upper * 65536 + lower
    _649 = NewDouble(_upper * (double)65536);
    _0 = _649;
    if (IS_ATOM_INT(_649)) {
        _649 = _649 + _lower;
        if ((long)((unsigned long)_649 + (unsigned long)HIGH_BITS) >= 0) 
            _649 = NewDouble((double)_649);
    }
    else {
        _649 = NewDouble(DBL_PTR(_649)->dbl + (double)_lower);
    }
    DeRef(_0);
    return _649;
    ;
}


int _9get_c_block(int _num_bytes)
{
    int _s = 0;
    int _656;
    int _654;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_bytes)) {
        _1 = (long)(DBL_PTR(_num_bytes)->dbl);
        DeRefDS(_num_bytes);
        _num_bytes = _1;
    }

    //     s = repeat(0, num_bytes)
    _s = Repeat(0, _num_bytes);

    //     for i = 1 to num_bytes do
    _654 = _num_bytes;
    { int _i;
        _i = 1;
L1:
        if (_i > _654)
            goto L2;

        // 	s[i] = getc(fn)
        if (_9fn != last_r_file_no) {
            last_r_file_ptr = which_file(_9fn, EF_READ);
            last_r_file_no = _9fn;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _656 = getc(xstdin);
            }
            else
                _656 = getc(last_r_file_ptr);
        }
        else
            _656 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i);
        *(int *)_2 = _656;

        //     end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    //     if s[$] = EOF then
    _656 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _656 = (int)*(((s1_ptr)_2)->base + _656);
    if (_656 != -1)
        goto L3;

    // 	error_code = BMP_UNEXPECTED_EOF
    _9error_code = 2;
L3:

    //     return s
    return _s;
    ;
}


int _9get_rgb(int _set_size)
{
    int _red;
    int _green;
    int _blue;
    int _660 = 0;
    int _0, _1, _2;
    

    //     blue = getc(fn)
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _blue = getc(xstdin);
        }
        else
            _blue = getc(last_r_file_ptr);
    }
    else
        _blue = getc(last_r_file_ptr);

    //     green = getc(fn)
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _green = getc(xstdin);
        }
        else
            _green = getc(last_r_file_ptr);
    }
    else
        _green = getc(last_r_file_ptr);

    //     red = getc(fn)
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _red = getc(xstdin);
        }
        else
            _red = getc(last_r_file_ptr);
    }
    else
        _red = getc(last_r_file_ptr);

    //     if set_size = 4 then
    if (_set_size != 4)
        goto L1;

    // 	if getc(fn) then
    if (_9fn != last_r_file_no) {
        last_r_file_ptr = which_file(_9fn, EF_READ);
        last_r_file_no = _9fn;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _660 = getc(xstdin);
        }
        else
            _660 = getc(last_r_file_ptr);
    }
    else
        _660 = getc(last_r_file_ptr);
    if (_660 == 0)
        goto L2;
L2:
L1:

    //     return {red, green, blue}
    _0 = _660;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _red;
    *((int *)(_2+8)) = _green;
    *((int *)(_2+12)) = _blue;
    _660 = MAKE_SEQ(_1);
    DeRef(_0);
    return _660;
    ;
}


int _9get_rgb_block(int _num_dwords, int _set_size)
{
    int _s = 0;
    int _667 = 0;
    int _666;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_num_dwords)) {
        _1 = (long)(DBL_PTR(_num_dwords)->dbl);
        DeRefDS(_num_dwords);
        _num_dwords = _1;
    }

    //     s = {}
    RefDS(_202);
    _s = _202;

    //     for i = 1 to num_dwords do
    _666 = _num_dwords;
    { int _i;
        _i = 1;
L1:
        if (_i > _666)
            goto L2;

        // 	s = append(s, get_rgb(set_size))
        _0 = _667;
        _667 = _9get_rgb(_set_size);
        DeRef(_0);
        RefDS(_667);
        Append(&_s, _s, _667);

        //     end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    //     if s[$][3] = EOF then
    DeRef(_667);
    _667 = SEQ_PTR(_s)->length;
    _2 = (int)SEQ_PTR(_s);
    _667 = (int)*(((s1_ptr)_2)->base + _667);
    RefDS(_667);
    _0 = _667;
    _2 = (int)SEQ_PTR(_667);
    _667 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_667);
    DeRefDS(_0);
    if (binary_op_a(NOTEQ, _667, -1))
        goto L3;

    // 	error_code = BMP_UNEXPECTED_EOF
    _9error_code = 2;
L3:

    //     return s
    DeRef(_667);
    return _s;
    ;
}


int _9row_bytes(int _BitCount, int _Width)
{
    int _673 = 0;
    int _0, _1, _2;
    

    //     return floor(((BitCount * Width) + 31) / 32) * 4
    if (IS_ATOM_INT(_Width)) {
        if (_BitCount == (short)_BitCount && _Width <= INT15 && _Width >= -INT15)
            _673 = _BitCount * _Width;
        else
            _673 = NewDouble(_BitCount * (double)_Width);
    }
    else {
        _673 = NewDouble((double)_BitCount * DBL_PTR(_Width)->dbl);
    }
    _0 = _673;
    if (IS_ATOM_INT(_673)) {
        _673 = _673 + 31;
        if ((long)((unsigned long)_673 + (unsigned long)HIGH_BITS) >= 0) 
            _673 = NewDouble((double)_673);
    }
    else {
        _673 = NewDouble(DBL_PTR(_673)->dbl + (double)31);
    }
    DeRef(_0);
    _0 = _673;
    if (IS_ATOM_INT(_673)) {
        if (32 > 0 && _673 >= 0) {
            _673 = _673 / 32;
        }
        else {
            temp_dbl = floor((double)_673 / (double)32);
            if (_673 != MININT)
                _673 = (long)temp_dbl;
            else
                _673 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _673, 32);
        _673 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);
    _0 = _673;
    if (IS_ATOM_INT(_673)) {
        if (_673 == (short)_673)
            _673 = _673 * 4;
        else
            _673 = NewDouble(_673 * (double)4);
    }
    else {
        _673 = NewDouble(DBL_PTR(_673)->dbl * (double)4);
    }
    DeRef(_0);
    DeRef(_Width);
    return _673;
    ;
}


int _9unpack(int _image, int _BitCount, int _Width, int _Height)
{
    int _pic_2d = 0;
    int _row = 0;
    int _bits = 0;
    int _bytes;
    int _next_byte;
    int _byte;
    int _682 = 0;
    int _680;
    int _678;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_Width)) {
        _1 = (long)(DBL_PTR(_Width)->dbl);
        DeRefDS(_Width);
        _Width = _1;
    }
    if (!IS_ATOM_INT(_Height)) {
        _1 = (long)(DBL_PTR(_Height)->dbl);
        DeRefDS(_Height);
        _Height = _1;
    }

    //     pic_2d = {}
    RefDS(_202);
    _pic_2d = _202;

    //     bytes = row_bytes(BitCount, Width)
    _bytes = _9row_bytes(_BitCount, _Width);
    if (!IS_ATOM_INT(_bytes)) {
        _1 = (long)(DBL_PTR(_bytes)->dbl);
        DeRefDS(_bytes);
        _bytes = _1;
    }

    //     next_byte = 1
    _next_byte = 1;

    //     for i = 1 to Height do
    _678 = _Height;
    { int _i;
        _i = 1;
L1:
        if (_i > _678)
            goto L2;

        // 	row = {}
        RefDS(_202);
        DeRefi(_row);
        _row = _202;

        // 	if BitCount = 1 then
        if (_BitCount != 1)
            goto L3;

        // 	    for j = 1 to bytes do
        _680 = _bytes;
        { int _j;
            _j = 1;
L4:
            if (_j > _680)
                goto L5;

            // 		byte = image[next_byte]
            _2 = (int)SEQ_PTR(_image);
            _byte = (int)*(((s1_ptr)_2)->base + _next_byte);

            // 		next_byte += 1
            _next_byte = _next_byte + 1;

            // 		bits = repeat(0, 8)
            DeRefi(_bits);
            _bits = Repeat(0, 8);

            // 		for k = 8 to 1 by -1 do
            { int _k;
                _k = 8;
L6:
                if (_k < 1)
                    goto L7;

                // 		    bits[k] = and_bits(byte, 1)
                DeRef(_682);
                _682 = (_byte & 1);
                _2 = (int)SEQ_PTR(_bits);
                _2 = (int)(((s1_ptr)_2)->base + _k);
                *(int *)_2 = _682;

                // 		    byte = floor(byte/2)
                _byte = _byte >> 1;

                // 		end for
                _k = _k + -1;
                goto L6;
L7:
                ;
            }

            // 		row &= bits
            Concat((object_ptr)&_row, _row, (s1_ptr)_bits);

            // 	    end for
            _j = _j + 1;
            goto L4;
L5:
            ;
        }
        goto L8;
L3:

        // 	elsif BitCount = 2 then
        if (_BitCount != 2)
            goto L9;

        // 	    for j = 1 to bytes do
        DeRef(_682);
        _682 = _bytes;
        { int _j;
            _j = 1;
LA:
            if (_j > _682)
                goto LB;

            // 		byte = image[next_byte]
            _2 = (int)SEQ_PTR(_image);
            _byte = (int)*(((s1_ptr)_2)->base + _next_byte);

            // 		next_byte += 1
            _next_byte = _next_byte + 1;

            // 		bits = repeat(0, 4)
            DeRefi(_bits);
            _bits = Repeat(0, 4);

            // 		for k = 4 to 1 by -1 do
            { int _k;
                _k = 4;
LC:
                if (_k < 1)
                    goto LD;

                // 		    bits[k] = and_bits(byte, 3)
                _680 = (_byte & 3);
                _2 = (int)SEQ_PTR(_bits);
                _2 = (int)(((s1_ptr)_2)->base + _k);
                *(int *)_2 = _680;

                // 		    byte = floor(byte/4)
                if (4 > 0 && _byte >= 0) {
                    _byte = _byte / 4;
                }
                else {
                    temp_dbl = floor((double)_byte / (double)4);
                    _byte = (long)temp_dbl;
                }

                // 		end for
                _k = _k + -1;
                goto LC;
LD:
                ;
            }

            // 		row &= bits
            Concat((object_ptr)&_row, _row, (s1_ptr)_bits);

            // 	    end for
            _j = _j + 1;
            goto LA;
LB:
            ;
        }
        goto L8;
L9:

        // 	elsif BitCount = 4 then
        if (_BitCount != 4)
            goto LE;

        // 	    for j = 1 to bytes do
        _680 = _bytes;
        { int _j;
            _j = 1;
LF:
            if (_j > _680)
                goto L10;

            // 		byte = image[next_byte]
            _2 = (int)SEQ_PTR(_image);
            _byte = (int)*(((s1_ptr)_2)->base + _next_byte);

            // 		row = append(row, floor(byte/16))
            DeRef(_682);
            if (16 > 0 && _byte >= 0) {
                _682 = _byte / 16;
            }
            else {
                temp_dbl = floor((double)_byte / (double)16);
                _682 = (long)temp_dbl;
            }
            Append(&_row, _row, _682);

            // 		row = append(row, and_bits(byte, 15))
            _682 = (_byte & 15);
            Append(&_row, _row, _682);

            // 		next_byte += 1
            _next_byte = _next_byte + 1;

            // 	    end for
            _j = _j + 1;
            goto LF;
L10:
            ;
        }
        goto L8;
LE:

        // 	elsif BitCount = 8 then
        if (_BitCount != 8)
            goto L11;

        // 	    row = image[next_byte..next_byte+bytes-1]
        DeRef(_682);
        _682 = _next_byte + _bytes;
        if ((long)((unsigned long)_682 + (unsigned long)HIGH_BITS) >= 0) 
            _682 = NewDouble((double)_682);
        _0 = _682;
        if (IS_ATOM_INT(_682)) {
            _682 = _682 - 1;
        }
        else {
            _682 = NewDouble(DBL_PTR(_682)->dbl - (double)1);
        }
        DeRef(_0);
        rhs_slice_target = (object_ptr)&_row;
        RHS_Slice((s1_ptr)_image, _next_byte, _682);

        // 	    next_byte += bytes
        _next_byte = _next_byte + _bytes;
        goto L8;
L11:

        // 	    error_code = BMP_UNSUPPORTED_FORMAT
        _9error_code = 3;

        // 	    exit
        goto L2;
L8:

        // 	pic_2d = prepend(pic_2d, row[1..Width])
        rhs_slice_target = (object_ptr)&_682;
        RHS_Slice((s1_ptr)_row, 1, _Width);
        RefDS(_682);
        Prepend(&_pic_2d, _pic_2d, _682);

        //     end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    //     return pic_2d
    DeRefDSi(_image);
    DeRefi(_row);
    DeRefi(_bits);
    DeRef(_682);
    return _pic_2d;
    ;
}


_9read_bitmap(int _file_name)
{
    int _Size = 0;
    int _Type;
    int _Xhot;
    int _Yhot;
    int _Planes;
    int _BitCount;
    int _Width = 0;
    int _Height = 0;
    int _Compression = 0;
    int _OffBits = 0;
    int _SizeHeader = 0;
    int _SizeImage = 0;
    int _XPelsPerMeter = 0;
    int _YPelsPerMeter = 0;
    int _ClrUsed = 0;
    int _ClrImportant = 0;
    int _NumColors = 0;
    int _Palette = 0;
    int _Bits = 0;
    int _two_d_bits = 0;
    int _737 = 0;
    int _712 = 0;
    int _0, _1, _2;
    

    //     error_code = 0
    _9error_code = 0;

    //     fn = open(file_name, "rb")
    _9fn = EOpen(_file_name, _711);

    //     if fn = -1 then
    if (_9fn != -1)
        goto L1;

    // 	return BMP_OPEN_FAILED
    DeRefDS(_file_name);
    return 1;
L1:

    //     Type = get_word()
    _Type = _9get_word();

    //     Size = get_dword()
    _0 = _Size;
    _Size = _9get_dword();
    DeRef(_0);

    //     Xhot = get_word()
    _Xhot = _9get_word();

    //     Yhot = get_word()
    _Yhot = _9get_word();

    //     OffBits = get_dword()
    _0 = _OffBits;
    _OffBits = _9get_dword();
    DeRef(_0);

    //     SizeHeader = get_dword()
    _0 = _SizeHeader;
    _SizeHeader = _9get_dword();
    DeRef(_0);

    //     if SizeHeader = NEWHDRSIZE then
    if (binary_op_a(NOTEQ, _SizeHeader, 40))
        goto L2;

    // 	Width = get_dword()
    _0 = _Width;
    _Width = _9get_dword();
    DeRef(_0);

    // 	Height = get_dword()
    _0 = _Height;
    _Height = _9get_dword();
    DeRef(_0);

    // 	Planes = get_word()
    _Planes = _9get_word();

    // 	BitCount = get_word()
    _BitCount = _9get_word();

    // 	Compression = get_dword()
    _0 = _Compression;
    _Compression = _9get_dword();
    DeRef(_0);

    // 	if Compression != 0 then
    if (binary_op_a(EQUALS, _Compression, 0))
        goto L3;

    // 	    close(fn)
    EClose(_9fn);

    // 	    return BMP_UNSUPPORTED_FORMAT
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRef(_Palette);
    DeRefi(_Bits);
    DeRef(_two_d_bits);
    DeRef(_737);
    DeRef(_712);
    return 3;
L3:

    // 	SizeImage = get_dword()
    _0 = _SizeImage;
    _SizeImage = _9get_dword();
    DeRef(_0);

    // 	XPelsPerMeter = get_dword()
    _0 = _XPelsPerMeter;
    _XPelsPerMeter = _9get_dword();
    DeRef(_0);

    // 	YPelsPerMeter = get_dword()
    _0 = _YPelsPerMeter;
    _YPelsPerMeter = _9get_dword();
    DeRef(_0);

    // 	ClrUsed = get_dword()
    _0 = _ClrUsed;
    _ClrUsed = _9get_dword();
    DeRef(_0);

    // 	ClrImportant = get_dword()
    _0 = _ClrImportant;
    _ClrImportant = _9get_dword();
    DeRef(_0);

    // 	NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 4
    DeRef(_712);
    if (IS_ATOM_INT(_OffBits) && IS_ATOM_INT(_SizeHeader)) {
        _712 = _OffBits - _SizeHeader;
        if ((long)((unsigned long)_712 +(unsigned long) HIGH_BITS) >= 0)
            _712 = NewDouble((double)_712);
    }
    else {
        if (IS_ATOM_INT(_OffBits)) {
            _712 = NewDouble((double)_OffBits - DBL_PTR(_SizeHeader)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader)) {
                _712 = NewDouble(DBL_PTR(_OffBits)->dbl - (double)_SizeHeader);
            }
            else
                _712 = NewDouble(DBL_PTR(_OffBits)->dbl - DBL_PTR(_SizeHeader)->dbl);
        }
    }
    _0 = _712;
    if (IS_ATOM_INT(_712)) {
        _712 = _712 - 14;
        if ((long)((unsigned long)_712 +(unsigned long) HIGH_BITS) >= 0)
            _712 = NewDouble((double)_712);
    }
    else {
        _712 = NewDouble(DBL_PTR(_712)->dbl - (double)14);
    }
    DeRef(_0);
    DeRef(_NumColors);
    if (IS_ATOM_INT(_712)) {
        _NumColors = (_712 % 4) ? NewDouble((double)_712 / 4) : (_712 / 4);
    }
    else {
        _NumColors = NewDouble(DBL_PTR(_712)->dbl / (double)4);
    }

    // 	if NumColors < 2 or NumColors > 256 then
    DeRef(_712);
    if (IS_ATOM_INT(_NumColors)) {
        _712 = (_NumColors < 2);
    }
    else {
        _712 = (DBL_PTR(_NumColors)->dbl < (double)2);
    }
    if (_712 != 0) {
        goto L4;
    }
    DeRef(_737);
    if (IS_ATOM_INT(_NumColors)) {
        _737 = (_NumColors > 256);
    }
    else {
        _737 = (DBL_PTR(_NumColors)->dbl > (double)256);
    }
L5:
    if (_737 == 0)
        goto L6;
L4:

    // 	    close(fn)
    EClose(_9fn);

    // 	    return BMP_UNSUPPORTED_FORMAT
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRef(_Palette);
    DeRefi(_Bits);
    DeRef(_two_d_bits);
    DeRef(_737);
    DeRef(_712);
    return 3;
L6:

    // 	Palette = get_rgb_block(NumColors, 4) 
    Ref(_NumColors);
    _0 = _Palette;
    _Palette = _9get_rgb_block(_NumColors, 4);
    DeRef(_0);
    goto L7;
L2:

    //     elsif SizeHeader = OLDHDRSIZE then 
    if (binary_op_a(NOTEQ, _SizeHeader, 12))
        goto L8;

    // 	Width = get_word()
    _0 = _Width;
    _Width = _9get_word();
    DeRef(_0);

    // 	Height = get_word()
    _0 = _Height;
    _Height = _9get_word();
    DeRef(_0);

    // 	Planes = get_word()
    _Planes = _9get_word();

    // 	BitCount = get_word()
    _BitCount = _9get_word();

    // 	NumColors = (OffBits - SizeHeader - BMPFILEHDRSIZE) / 3
    DeRef(_737);
    if (IS_ATOM_INT(_OffBits) && IS_ATOM_INT(_SizeHeader)) {
        _737 = _OffBits - _SizeHeader;
        if ((long)((unsigned long)_737 +(unsigned long) HIGH_BITS) >= 0)
            _737 = NewDouble((double)_737);
    }
    else {
        if (IS_ATOM_INT(_OffBits)) {
            _737 = NewDouble((double)_OffBits - DBL_PTR(_SizeHeader)->dbl);
        }
        else {
            if (IS_ATOM_INT(_SizeHeader)) {
                _737 = NewDouble(DBL_PTR(_OffBits)->dbl - (double)_SizeHeader);
            }
            else
                _737 = NewDouble(DBL_PTR(_OffBits)->dbl - DBL_PTR(_SizeHeader)->dbl);
        }
    }
    _0 = _737;
    if (IS_ATOM_INT(_737)) {
        _737 = _737 - 14;
        if ((long)((unsigned long)_737 +(unsigned long) HIGH_BITS) >= 0)
            _737 = NewDouble((double)_737);
    }
    else {
        _737 = NewDouble(DBL_PTR(_737)->dbl - (double)14);
    }
    DeRef(_0);
    DeRef(_NumColors);
    if (IS_ATOM_INT(_737)) {
        _NumColors = (_737 % 3) ? NewDouble((double)_737 / 3) : (_737 / 3);
    }
    else {
        _NumColors = NewDouble(DBL_PTR(_737)->dbl / (double)3);
    }

    // 	SizeImage = row_bytes(BitCount, Width) * Height
    _0 = _737;
    _737 = _9row_bytes(_BitCount, _Width);
    DeRef(_0);
    DeRef(_SizeImage);
    if (IS_ATOM_INT(_737)) {
        if (_737 == (short)_737 && _Height <= INT15)
            _SizeImage = _737 * _Height;
        else
            _SizeImage = NewDouble(_737 * (double)_Height);
    }
    else {
        _SizeImage = NewDouble(DBL_PTR(_737)->dbl * (double)_Height);
    }

    // 	Palette = get_rgb_block(NumColors, 3) 
    Ref(_NumColors);
    _0 = _Palette;
    _Palette = _9get_rgb_block(_NumColors, 3);
    DeRef(_0);
    goto L7;
L8:

    // 	close(fn)
    EClose(_9fn);

    // 	return BMP_UNSUPPORTED_FORMAT
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRef(_Palette);
    DeRefi(_Bits);
    DeRef(_two_d_bits);
    DeRef(_737);
    DeRef(_712);
    return 3;
L7:

    //     if Planes != 1 or Height <= 0 or Width <= 0 then
    DeRef(_737);
    _737 = (_Planes != 1);
    if (_737 != 0) {
        _737 = 1;
        goto L9;
    }
    DeRef(_712);
    if (IS_ATOM_INT(_Height)) {
        _712 = (_Height <= 0);
    }
    else {
        _712 = (DBL_PTR(_Height)->dbl <= (double)0);
    }
    _737 = (_712 != 0);
L9:
    if (_737 != 0) {
        goto LA;
    }
    DeRef(_737);
    if (IS_ATOM_INT(_Width)) {
        _737 = (_Width <= 0);
    }
    else {
        _737 = (DBL_PTR(_Width)->dbl <= (double)0);
    }
LB:
    if (_737 == 0)
        goto LC;
LA:

    // 	close(fn)
    EClose(_9fn);

    // 	return BMP_UNSUPPORTED_FORMAT
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRef(_Palette);
    DeRefi(_Bits);
    DeRef(_two_d_bits);
    DeRef(_737);
    DeRef(_712);
    return 3;
LC:

    //     Bits = get_c_block(row_bytes(BitCount, Width) * Height)
    Ref(_Width);
    _0 = _737;
    _737 = _9row_bytes(_BitCount, _Width);
    DeRef(_0);
    _0 = _737;
    if (IS_ATOM_INT(_737) && IS_ATOM_INT(_Height)) {
        if (_737 == (short)_737 && _Height <= INT15 && _Height >= -INT15)
            _737 = _737 * _Height;
        else
            _737 = NewDouble(_737 * (double)_Height);
    }
    else {
        if (IS_ATOM_INT(_737)) {
            _737 = NewDouble((double)_737 * DBL_PTR(_Height)->dbl);
        }
        else {
            if (IS_ATOM_INT(_Height)) {
                _737 = NewDouble(DBL_PTR(_737)->dbl * (double)_Height);
            }
            else
                _737 = NewDouble(DBL_PTR(_737)->dbl * DBL_PTR(_Height)->dbl);
        }
    }
    DeRef(_0);
    Ref(_737);
    _0 = _Bits;
    _Bits = _9get_c_block(_737);
    DeRefi(_0);

    //     close(fn)
    EClose(_9fn);

    //     two_d_bits = unpack(Bits, BitCount, Width, Height)
    RefDS(_Bits);
    Ref(_Width);
    Ref(_Height);
    _0 = _two_d_bits;
    _two_d_bits = _9unpack(_Bits, _BitCount, _Width, _Height);
    DeRef(_0);

    //     if error_code then
    if (_9error_code == 0)
        goto LD;

    // 	return error_code 
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRef(_Palette);
    DeRefDSi(_Bits);
    DeRefDS(_two_d_bits);
    DeRef(_737);
    DeRef(_712);
    return _9error_code;
LD:

    //     return {Palette, two_d_bits}
    DeRef(_737);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _Palette;
    RefDS(_Palette);
    ((int *)_2)[2] = _two_d_bits;
    RefDS(_two_d_bits);
    _737 = MAKE_SEQ(_1);
    DeRefDS(_file_name);
    DeRef(_Size);
    DeRef(_Width);
    DeRef(_Height);
    DeRef(_Compression);
    DeRef(_OffBits);
    DeRef(_SizeHeader);
    DeRef(_SizeImage);
    DeRef(_XPelsPerMeter);
    DeRef(_YPelsPerMeter);
    DeRef(_ClrUsed);
    DeRef(_ClrImportant);
    DeRef(_NumColors);
    DeRefDS(_Palette);
    DeRefi(_Bits);
    DeRefDS(_two_d_bits);
    DeRef(_712);
    return _737;
    ;
}


_9display_image(int _xy, int _pixels)
{
    int _785 = 0;
    int _784;
    int _0, _1, _2;
    

    //     for i = 1 to length(pixels) do
    _784 = SEQ_PTR(_pixels)->length;
    { int _i;
        _i = 1;
L1:
        if (_i > _784)
            goto L2;

        // 	pixel(pixels[i], xy)
        DeRef(_785);
        _2 = (int)SEQ_PTR(_pixels);
        _785 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_785);
        Pixel(_785, _xy);

        // 	xy[2] += 1
        DeRef(_785);
        _2 = (int)SEQ_PTR(_xy);
        _785 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_785);
        _0 = _785;
        if (IS_ATOM_INT(_785)) {
            _785 = _785 + 1;
            if (_785 > MAXINT)
                _785 = NewDouble((double)_785);
        }
        else
            _785 = binary_op(PLUS, 1, _785);
        DeRef(_0);
        Ref(_785);
        _2 = (int)SEQ_PTR(_xy);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _xy = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _785;
        DeRef(_1);

        //     end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRefDS(_xy);
    DeRefDS(_pixels);
    DeRef(_785);
    return 0;
    ;
}


_9save_image(int _top_left, int _bottom_right)
{
    int _x;
    int _width;
    int _save = 0;
    int _788 = 0;
    int _793 = 0;
    int _0, _1, _2;
    

    //     x = top_left[1]
    _2 = (int)SEQ_PTR(_top_left);
    _x = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_x))
        _x = (long)DBL_PTR(_x)->dbl;

    //     width = bottom_right[1] - x + 1
    _2 = (int)SEQ_PTR(_bottom_right);
    _788 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_788);
    _0 = _788;
    if (IS_ATOM_INT(_788)) {
        _788 = _788 - _x;
        if ((long)((unsigned long)_788 +(unsigned long) HIGH_BITS) >= 0)
            _788 = NewDouble((double)_788);
    }
    else {
        _788 = binary_op(MINUS, _788, _x);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_788)) {
        _width = _788 + 1;
    }
    else
        _width = 1+(long)(DBL_PTR(_788)->dbl);

    //     save = {}
    RefDS(_202);
    _save = _202;

    //     for y = top_left[2] to bottom_right[2] do
    DeRef(_788);
    _2 = (int)SEQ_PTR(_top_left);
    _788 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_788);
    _2 = (int)SEQ_PTR(_bottom_right);
    _793 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_793);
    { int _y;
        Ref(_788);
        _y = _788;
L1:
        if (binary_op_a(GREATER, _y, _793))
            goto L2;

        // 	save = append(save, get_pixel({x, y, width}))
        _0 = _788;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _x;
        Ref(_y);
        *((int *)(_2+8)) = _y;
        *((int *)(_2+12)) = _width;
        _788 = MAKE_SEQ(_1);
        DeRef(_0);
        _0 = _788;
        _788 = Get_Pixel(_788);
        DeRefDS(_0);
        RefDS(_788);
        Append(&_save, _save, _788);

        //     end for
        _0 = _y;
        if (IS_ATOM_INT(_y)) {
            _y = _y + 1;
            if ((long)((unsigned long)_y +(unsigned long) HIGH_BITS) >= 0) 
                _y = NewDouble((double)_y);
        }
        else {
            _y = binary_op_a(PLUS, _y, 1);
        }
        DeRef(_0);
        goto L1;
L2:
        ;
        DeRef(_y);
    }

    //     return save
    DeRefDS(_top_left);
    DeRefDS(_bottom_right);
    DeRef(_788);
    DeRef(_793);
    return _save;
    ;
}


_9get_display_page()
{
    int _804;
    int _0, _1, _2;
    

    //     return machine_func(M_GET_DISPLAY_PAGE, 0)
    _804 = machine(28, 0);
    return _804;
    ;
}


_9set_display_page(int _page)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_page)) {
        _1 = (long)(DBL_PTR(_page)->dbl);
        DeRefDS(_page);
        _page = _1;
    }

    //     machine_proc(M_SET_DISPLAY_PAGE, page)
    machine(29, _page);

    // end procedure
    return 0;
    ;
}


_9get_active_page()
{
    int _805;
    int _0, _1, _2;
    

    //     return machine_func(M_GET_ACTIVE_PAGE, 0)
    _805 = machine(30, 0);
    return _805;
    ;
}


_9set_active_page(int _page)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_page)) {
        _1 = (long)(DBL_PTR(_page)->dbl);
        DeRefDS(_page);
        _page = _1;
    }

    //     machine_proc(M_SET_ACTIVE_PAGE, page)
    machine(31, _page);

    // end procedure
    return 0;
    ;
}


_9get_screen_char(int _line, int _column)
{
    int _scr_addr = 0;
    int _vc = 0;
    int _836 = 0;
    int _0, _1, _2;
    

    //     if platform() = DOS32 then

    // 	return machine_func(M_GET_SCREEN_CHAR, {line, column})
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _line;
    Ref(_line);
    ((int *)_2)[2] = _column;
    Ref(_column);
    _836 = MAKE_SEQ(_1);
    _0 = _836;
    _836 = machine(58, _836);
    DeRefDS(_0);
    DeRef(_line);
    DeRef(_column);
    return _836;
L1:
    ;
}


_9put_screen_char(int _line, int _column, int _char_attr)
{
    int _scr_addr = 0;
    int _vc = 0;
    int _overflow;
    int _850 = 0;
    int _0, _1, _2;
    

    //     if platform() = DOS32 then

    // 	machine_proc(M_PUT_SCREEN_CHAR, {line, column, char_attr})
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_line);
    *((int *)(_2+4)) = _line;
    Ref(_column);
    *((int *)(_2+8)) = _column;
    RefDS(_char_attr);
    *((int *)(_2+12)) = _char_attr;
    _850 = MAKE_SEQ(_1);
    machine(59, _850);
L1:

    // end procedure
    DeRef(_line);
    DeRef(_column);
    DeRefDS(_char_attr);
    DeRef(_scr_addr);
    DeRef(_vc);
    DeRef(_850);
    return 0;
    ;
}


_9display_text_image(int _xy, int _text)
{
    int _scr_addr = 0;
    int _screen_width;
    int _extra_col2;
    int _extra_lines;
    int _vc = 0;
    int _one_row = 0;
    int _904 = 0;
    int _870 = 0;
    int _878 = 0;
    int _0, _1, _2;
    

    //     vc = video_config()
    _vc = _8video_config();

    //     if platform() = DOS32 then

    //     if xy[1] < 1 or xy[2] < 1 then
    _2 = (int)SEQ_PTR(_xy);
    _870 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_870);
    _0 = _870;
    if (IS_ATOM_INT(_870)) {
        _870 = (_870 < 1);
    }
    else {
        _870 = binary_op(LESS, _870, 1);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_870)) {
        if (_870 != 0) {
            goto L1;
        }
    }
    else {
        if (DBL_PTR(_870)->dbl != 0.0) {
            goto L1;
        }
    }
    _2 = (int)SEQ_PTR(_xy);
    _878 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_878);
    _0 = _878;
    if (IS_ATOM_INT(_878)) {
        _878 = (_878 < 1);
    }
    else {
        _878 = binary_op(LESS, _878, 1);
    }
    DeRef(_0);
L2:
    if (_878 == 0) {
        goto L3;
    }
    else {
        if (!IS_ATOM_INT(_878) && DBL_PTR(_878)->dbl == 0.0)
            goto L3;
    }
L1:

    // 	return -- bad starting point
    DeRefDS(_xy);
    DeRefDS(_text);
    DeRef(_scr_addr);
    DeRefi(_vc);
    DeRef(_one_row);
    DeRef(_904);
    DeRef(_870);
    DeRef(_878);
    return 0;
L3:

    //     extra_lines = vc[VC_LINES] - xy[1] + 1 
    DeRef(_878);
    _2 = (int)SEQ_PTR(_vc);
    _878 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_870);
    _2 = (int)SEQ_PTR(_xy);
    _870 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_870);
    _0 = _870;
    if (IS_ATOM_INT(_870)) {
        _870 = _878 - _870;
        if ((long)((unsigned long)_870 +(unsigned long) HIGH_BITS) >= 0)
            _870 = NewDouble((double)_870);
    }
    else {
        _870 = binary_op(MINUS, _878, _870);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_870)) {
        _extra_lines = _870 + 1;
    }
    else
        _extra_lines = 1+(long)(DBL_PTR(_870)->dbl);

    //     if length(text) > extra_lines then
    DeRef(_870);
    _870 = SEQ_PTR(_text)->length;
    if (_870 <= _extra_lines)
        goto L4;

    // 	if extra_lines <= 0 then
    if (_extra_lines > 0)
        goto L5;

    // 	    return -- nothing to display
    DeRefDS(_xy);
    DeRefDS(_text);
    DeRef(_scr_addr);
    DeRefDSi(_vc);
    DeRef(_one_row);
    DeRef(_904);
    return 0;
L5:

    // 	text = text[1..extra_lines] -- truncate
    rhs_slice_target = (object_ptr)&_text;
    RHS_Slice((s1_ptr)_text, 1, _extra_lines);
L4:

    //     extra_col2 = 2 * (vc[VC_COLUMNS] - xy[2] + 1)
    DeRef(_870);
    _2 = (int)SEQ_PTR(_vc);
    _870 = (int)*(((s1_ptr)_2)->base + 4);
    DeRef(_878);
    _2 = (int)SEQ_PTR(_xy);
    _878 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_878);
    _0 = _878;
    if (IS_ATOM_INT(_878)) {
        _878 = _870 - _878;
        if ((long)((unsigned long)_878 +(unsigned long) HIGH_BITS) >= 0)
            _878 = NewDouble((double)_878);
    }
    else {
        _878 = binary_op(MINUS, _870, _878);
    }
    DeRef(_0);
    _0 = _878;
    if (IS_ATOM_INT(_878)) {
        _878 = _878 + 1;
        if (_878 > MAXINT)
            _878 = NewDouble((double)_878);
    }
    else
        _878 = binary_op(PLUS, 1, _878);
    DeRef(_0);
    if (IS_ATOM_INT(_878) && IS_ATOM_INT(_878)) {
        _extra_col2 = _878 + _878;
    }
    else {
        _extra_col2 = binary_op(PLUS, _878, _878);
    }
    if (!IS_ATOM_INT(_extra_col2)) {
        _1 = (long)(DBL_PTR(_extra_col2)->dbl);
        DeRefDS(_extra_col2);
        _extra_col2 = _1;
    }

    //     for row = 1 to length(text) do
    DeRef(_878);
    _878 = SEQ_PTR(_text)->length;
    { int _row;
        _row = 1;
L6:
        if (_row > _878)
            goto L7;

        // 	one_row = text[row]
        DeRef(_one_row);
        _2 = (int)SEQ_PTR(_text);
        _one_row = (int)*(((s1_ptr)_2)->base + _row);
        Ref(_one_row);

        // 	if length(one_row) > extra_col2 then
        DeRef(_870);
        _870 = SEQ_PTR(_one_row)->length;
        if (_870 <= _extra_col2)
            goto L8;

        // 	    if extra_col2 <= 0 then
        if (_extra_col2 > 0)
            goto L9;

        // 		return -- nothing to display
        DeRefDS(_xy);
        DeRefDS(_text);
        DeRef(_scr_addr);
        DeRefi(_vc);
        DeRefDS(_one_row);
        DeRef(_904);
        DeRef(_878);
        return 0;
L9:

        // 	    one_row = one_row[1..extra_col2] -- truncate
        rhs_slice_target = (object_ptr)&_one_row;
        RHS_Slice((s1_ptr)_one_row, 1, _extra_col2);
L8:

        // 	if platform() = DOS32 then

        // 	    machine_proc(M_PUT_SCREEN_CHAR, {xy[1]+row-1, xy[2], one_row})
        DeRef(_870);
        _2 = (int)SEQ_PTR(_xy);
        _870 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_870);
        _0 = _870;
        if (IS_ATOM_INT(_870)) {
            _870 = _870 + _row;
            if ((long)((unsigned long)_870 + (unsigned long)HIGH_BITS) >= 0) 
                _870 = NewDouble((double)_870);
        }
        else {
            _870 = binary_op(PLUS, _870, _row);
        }
        DeRef(_0);
        _0 = _870;
        if (IS_ATOM_INT(_870)) {
            _870 = _870 - 1;
            if ((long)((unsigned long)_870 +(unsigned long) HIGH_BITS) >= 0)
                _870 = NewDouble((double)_870);
        }
        else {
            _870 = binary_op(MINUS, _870, 1);
        }
        DeRef(_0);
        DeRef(_904);
        _2 = (int)SEQ_PTR(_xy);
        _904 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_904);
        _0 = _904;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_870);
        *((int *)(_2+4)) = _870;
        Ref(_904);
        *((int *)(_2+8)) = _904;
        RefDS(_one_row);
        *((int *)(_2+12)) = _one_row;
        _904 = MAKE_SEQ(_1);
        DeRef(_0);
        machine(59, _904);
LA:

        //     end for
        _row = _row + 1;
        goto L6;
L7:
        ;
    }

    // end procedure
    DeRefDS(_xy);
    DeRefDS(_text);
    DeRef(_scr_addr);
    DeRefi(_vc);
    DeRef(_one_row);
    DeRef(_904);
    DeRef(_870);
    DeRef(_878);
    return 0;
    ;
}


_9save_text_image(int _top_left, int _bottom_right)
{
    int _image = 0;
    int _row_chars = 0;
    int _vc = 0;
    int _scr_addr = 0;
    int _screen_memory = 0;
    int _screen_width;
    int _image_width;
    int _page_size;
    int _906 = 0;
    int _940 = 0;
    int _924 = 0;
    int _0, _1, _2;
    

    //     vc = video_config()
    _vc = _8video_config();

    //     screen_width = vc[VC_COLUMNS] * BYTES_PER_CHAR
    _2 = (int)SEQ_PTR(_vc);
    _906 = (int)*(((s1_ptr)_2)->base + 4);
    _screen_width = _906 + _906;

    //     if platform() = DOS32 then

    //     image = {}
    RefDS(_202);
    _image = _202;

    //     image_width = (bottom_right[2] - top_left[2] + 1) * BYTES_PER_CHAR
    _2 = (int)SEQ_PTR(_bottom_right);
    _924 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_924);
    _2 = (int)SEQ_PTR(_top_left);
    _906 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_906);
    _0 = _906;
    if (IS_ATOM_INT(_924) && IS_ATOM_INT(_906)) {
        _906 = _924 - _906;
        if ((long)((unsigned long)_906 +(unsigned long) HIGH_BITS) >= 0)
            _906 = NewDouble((double)_906);
    }
    else {
        _906 = binary_op(MINUS, _924, _906);
    }
    DeRef(_0);
    _0 = _906;
    if (IS_ATOM_INT(_906)) {
        _906 = _906 + 1;
        if (_906 > MAXINT)
            _906 = NewDouble((double)_906);
    }
    else
        _906 = binary_op(PLUS, 1, _906);
    DeRef(_0);
    if (IS_ATOM_INT(_906) && IS_ATOM_INT(_906)) {
        _image_width = _906 + _906;
    }
    else {
        _image_width = binary_op(PLUS, _906, _906);
    }
    if (!IS_ATOM_INT(_image_width)) {
        _1 = (long)(DBL_PTR(_image_width)->dbl);
        DeRefDS(_image_width);
        _image_width = _1;
    }

    //     for row = top_left[1] to bottom_right[1] do
    DeRef(_906);
    _2 = (int)SEQ_PTR(_top_left);
    _906 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_906);
    DeRef(_924);
    _2 = (int)SEQ_PTR(_bottom_right);
    _924 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_924);
    { int _row;
        Ref(_906);
        _row = _906;
L1:
        if (binary_op_a(GREATER, _row, _924))
            goto L2;

        // 	if platform() = DOS32 then

        // 	    row_chars = {}
        RefDS(_202);
        DeRef(_row_chars);
        _row_chars = _202;

        // 	    for col = top_left[2] to bottom_right[2] do
        DeRef(_906);
        _2 = (int)SEQ_PTR(_top_left);
        _906 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_906);
        DeRef(_940);
        _2 = (int)SEQ_PTR(_bottom_right);
        _940 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_940);
        { int _col;
            Ref(_906);
            _col = _906;
L3:
            if (binary_op_a(GREATER, _col, _940))
                goto L4;

            // 		row_chars &= machine_func(M_GET_SCREEN_CHAR, {row, col})
            DeRef(_906);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _row;
            Ref(_row);
            ((int *)_2)[2] = _col;
            Ref(_col);
            _906 = MAKE_SEQ(_1);
            _0 = _906;
            _906 = machine(58, _906);
            DeRefDS(_0);
            Concat((object_ptr)&_row_chars, _row_chars, (s1_ptr)_906);

            // 	    end for
            _0 = _col;
            if (IS_ATOM_INT(_col)) {
                _col = _col + 1;
                if ((long)((unsigned long)_col +(unsigned long) HIGH_BITS) >= 0) 
                    _col = NewDouble((double)_col);
            }
            else {
                _col = binary_op_a(PLUS, _col, 1);
            }
            DeRef(_0);
            goto L3;
L4:
            ;
            DeRef(_col);
        }
L5:

        // 	image = append(image, row_chars)
        RefDS(_row_chars);
        Append(&_image, _image, _row_chars);

        //     end for
        _0 = _row;
        if (IS_ATOM_INT(_row)) {
            _row = _row + 1;
            if ((long)((unsigned long)_row +(unsigned long) HIGH_BITS) >= 0) 
                _row = NewDouble((double)_row);
        }
        else {
            _row = binary_op_a(PLUS, _row, 1);
        }
        DeRef(_0);
        goto L1;
L2:
        ;
        DeRef(_row);
    }

    //     return image
    DeRefDS(_top_left);
    DeRefDS(_bottom_right);
    DeRef(_row_chars);
    DeRefi(_vc);
    DeRef(_scr_addr);
    DeRef(_screen_memory);
    DeRef(_906);
    DeRef(_940);
    DeRef(_924);
    return _image;
    ;
}


int _9putBmpFileHeader(int _numColors)
{
    int _offBytes;
    int _963 = 0;
    int _0, _1, _2;
    

    //     if numColors = 256 then
    if (_numColors != 256)
        goto L1;

    // 	bitCount = 8            -- 8 bits per pixel
    _9bitCount = 8;
    goto L2;
L1:

    //     elsif numColors = 16 then
    if (_numColors != 16)
        goto L3;

    // 	bitCount = 4            -- 4 bits per pixel
    _9bitCount = 4;
    goto L2;
L3:

    //     elsif numColors = 4 then
    if (_numColors != 4)
        goto L4;

    // 	bitCount = 2            -- 2 bits per pixel 
    _9bitCount = 2;
    goto L2;
L4:

    //     elsif numColors = 2 then
    if (_numColors != 2)
        goto L5;

    // 	bitCount = 1            -- 1 bit per pixel
    _9bitCount = 1;
    goto L2;
L5:

    // 	error_code = BMP_INVALID_MODE
    _9error_code = 4;

    // 	return
    DeRef(_963);
    return 0;
L2:

    //     puts(fn, "BM")  -- file-type field in the file header
    EPuts(_9fn, _967);

    //     offBytes = 4 * numColors + BMPFILEHDRSIZE + NEWHDRSIZE
    DeRef(_963);
    if (_numColors <= INT15 && _numColors >= -INT15)
        _963 = 4 * _numColors;
    else
        _963 = NewDouble(4 * (double)_numColors);
    _0 = _963;
    if (IS_ATOM_INT(_963)) {
        _963 = _963 + 14;
        if ((long)((unsigned long)_963 + (unsigned long)HIGH_BITS) >= 0) 
            _963 = NewDouble((double)_963);
    }
    else {
        _963 = NewDouble(DBL_PTR(_963)->dbl + (double)14);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_963)) {
        _offBytes = _963 + 40;
    }
    else {
        _offBytes = NewDouble(DBL_PTR(_963)->dbl + (double)40);
    }
    if (!IS_ATOM_INT(_offBytes)) {
        _1 = (long)(DBL_PTR(_offBytes)->dbl);
        DeRefDS(_offBytes);
        _offBytes = _1;
    }

    //     numRowBytes = row_bytes(bitCount, numXPixels)
    _0 = _9row_bytes(_9bitCount, _9numXPixels);
    _9numRowBytes = _0;
    if (!IS_ATOM_INT(_9numRowBytes)) {
        _1 = (long)(DBL_PTR(_9numRowBytes)->dbl);
        DeRefDS(_9numRowBytes);
        _9numRowBytes = _1;
    }

    //     puts(fn, int_to_bytes(offBytes + numRowBytes * numYPixels))
    DeRef(_963);
    if (_9numRowBytes == (short)_9numRowBytes && _9numYPixels <= INT15 && _9numYPixels >= -INT15)
        _963 = _9numRowBytes * _9numYPixels;
    else
        _963 = NewDouble(_9numRowBytes * (double)_9numYPixels);
    _0 = _963;
    if (IS_ATOM_INT(_963)) {
        _963 = _offBytes + _963;
        if ((long)((unsigned long)_963 + (unsigned long)HIGH_BITS) >= 0) 
            _963 = NewDouble((double)_963);
    }
    else {
        _963 = NewDouble((double)_offBytes + DBL_PTR(_963)->dbl);
    }
    DeRef(_0);
    Ref(_963);
    _0 = _963;
    _963 = _2int_to_bytes(_963);
    DeRef(_0);
    EPuts(_9fn, _963);

    //     puts(fn, {0, 0, 0, 0})              -- reserved fields, must be 0
    _0 = _963;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _963 = MAKE_SEQ(_1);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(offBytes))    -- offBytes is the offset to the start
    _0 = _963;
    _963 = _2int_to_bytes(_offBytes);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(NEWHDRSIZE))  -- size of the secondary header
    _0 = _963;
    _963 = _2int_to_bytes(40);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(numXPixels))  -- width of the bitmap in pixels
    _0 = _963;
    _963 = _2int_to_bytes(_9numXPixels);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(numYPixels))  -- height of the bitmap in pixels
    _0 = _963;
    _963 = _2int_to_bytes(_9numYPixels);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, {1, 0})                    -- planes, must be a word of value 1
    DeRefDSi(_963);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _963 = MAKE_SEQ(_1);
    EPuts(_9fn, _963);

    //     puts(fn, {bitCount, 0})     -- bitCount
    DeRefDSi(_963);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9bitCount;
    ((int *)_2)[2] = 0;
    _963 = MAKE_SEQ(_1);
    EPuts(_9fn, _963);

    //     puts(fn, {0, 0, 0, 0})      -- compression scheme
    _0 = _963;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _963 = MAKE_SEQ(_1);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, {0, 0, 0, 0})      -- size image, not required
    _0 = _963;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _963 = MAKE_SEQ(_1);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, {0, 0, 0, 0})      -- XPelsPerMeter, not required 
    _0 = _963;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _963 = MAKE_SEQ(_1);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, {0, 0, 0, 0})      -- YPelsPerMeter, not required
    _0 = _963;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _963 = MAKE_SEQ(_1);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(numColors))   -- num colors used in the image
    _0 = _963;
    _963 = _2int_to_bytes(_numColors);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    //     puts(fn, int_to_bytes(numColors))   -- num important colors in the image
    _0 = _963;
    _963 = _2int_to_bytes(_numColors);
    DeRefDSi(_0);
    EPuts(_9fn, _963);

    // end procedure
    DeRefDSi(_963);
    return 0;
    ;
}


int _9putOneRowImage(int _x, int _numPixelsPerByte, int _shift)
{
    int _j;
    int _byte;
    int _numBytesFilled;
    int _994 = 0;
    int _993 = 0;
    int _988 = 0;
    int _0, _1, _2;
    

    //     x &= repeat(0, 7)   -- 7 zeros is safe enough
    _988 = Repeat(0, 7);
    Concat((object_ptr)&_x, _x, (s1_ptr)_988);

    //     numBytesFilled = 0
    _numBytesFilled = 0;

    //     j = 1
    _j = 1;

    //     while j <= numXPixels do
L1:
    if (_j > _9numXPixels)
        goto L2;

    // 	byte = x[j]
    _2 = (int)SEQ_PTR(_x);
    _byte = (int)*(((s1_ptr)_2)->base + _j);
    if (!IS_ATOM_INT(_byte))
        _byte = (long)DBL_PTR(_byte)->dbl;

    // 	for k = 1 to numPixelsPerByte - 1 do
    DeRef(_988);
    _988 = _numPixelsPerByte - 1;
    if ((long)((unsigned long)_988 +(unsigned long) HIGH_BITS) >= 0)
        _988 = NewDouble((double)_988);
    { int _k;
        _k = 1;
L3:
        if (binary_op_a(GREATER, _k, _988))
            goto L4;

        // 	    byte = byte * shift + x[j + k]
        DeRef(_993);
        if (_byte == (short)_byte && _shift <= INT15 && _shift >= -INT15)
            _993 = _byte * _shift;
        else
            _993 = NewDouble(_byte * (double)_shift);
        DeRef(_994);
        if (IS_ATOM_INT(_k)) {
            _994 = _j + _k;
        }
        else {
            _994 = NewDouble((double)_j + DBL_PTR(_k)->dbl);
        }
        _0 = _994;
        _2 = (int)SEQ_PTR(_x);
        if (!IS_ATOM_INT(_994))
            _994 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_994)->dbl));
        else
            _994 = (int)*(((s1_ptr)_2)->base + _994);
        Ref(_994);
        DeRef(_0);
        if (IS_ATOM_INT(_993) && IS_ATOM_INT(_994)) {
            _byte = _993 + _994;
        }
        else {
            _byte = binary_op(PLUS, _993, _994);
        }
        if (!IS_ATOM_INT(_byte)) {
            _1 = (long)(DBL_PTR(_byte)->dbl);
            DeRefDS(_byte);
            _byte = _1;
        }

        // 	end for
        _0 = _k;
        if (IS_ATOM_INT(_k)) {
            _k = _k + 1;
            if ((long)((unsigned long)_k +(unsigned long) HIGH_BITS) >= 0) 
                _k = NewDouble((double)_k);
        }
        else {
            _k = binary_op_a(PLUS, _k, 1);
        }
        DeRef(_0);
        goto L3;
L4:
        ;
        DeRef(_k);
    }

    // 	puts(fn, byte)
    EPuts(_9fn, _byte);

    // 	numBytesFilled += 1
    _numBytesFilled = _numBytesFilled + 1;

    // 	j += numPixelsPerByte
    _j = _j + _numPixelsPerByte;

    //     end while
    goto L1;
L2:

    //     for m = 1 to numRowBytes - numBytesFilled do
    DeRef(_994);
    _994 = _9numRowBytes - _numBytesFilled;
    if ((long)((unsigned long)_994 +(unsigned long) HIGH_BITS) >= 0)
        _994 = NewDouble((double)_994);
    { int _m;
        _m = 1;
L5:
        if (binary_op_a(GREATER, _m, _994))
            goto L6;

        // 	puts(fn, 0)
        EPuts(_9fn, 0);

        //     end for
        _0 = _m;
        if (IS_ATOM_INT(_m)) {
            _m = _m + 1;
            if ((long)((unsigned long)_m +(unsigned long) HIGH_BITS) >= 0) 
                _m = NewDouble((double)_m);
        }
        else {
            _m = binary_op_a(PLUS, _m, 1);
        }
        DeRef(_0);
        goto L5;
L6:
        ;
        DeRef(_m);
    }

    // end procedure
    DeRefDS(_x);
    DeRef(_994);
    DeRef(_993);
    DeRef(_988);
    return 0;
    ;
}


int _9putImage()
{
    int _x = 0;
    int _numPixelsPerByte;
    int _shift;
    int _1003 = 0;
    int _1000;
    int _0, _1, _2;
    

    //     numPixelsPerByte = 8 / bitCount
    _numPixelsPerByte = (8 % _9bitCount) ? NewDouble((double)8 / _9bitCount) : (8 / _9bitCount);
    if (!IS_ATOM_INT(_numPixelsPerByte)) {
        _1 = (long)(DBL_PTR(_numPixelsPerByte)->dbl);
        DeRefDS(_numPixelsPerByte);
        _numPixelsPerByte = _1;
    }

    //     shift = power(2, bitCount)
    _shift = power(2, _9bitCount);

    //     for i = endYPixel to startYPixel by -1 do
    _1000 = _9startYPixel;
    { int _i;
        _i = _9endYPixel;
L1:
        if (_i < _1000)
            goto L2;

        // 	x = get_pixel({startXPixel, i, numXPixels})
        _0 = _1003;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9startXPixel;
        *((int *)(_2+8)) = _i;
        *((int *)(_2+12)) = _9numXPixels;
        _1003 = MAKE_SEQ(_1);
        DeRef(_0);
        DeRefi(_x);
        _x = Get_Pixel(_1003);

        // 	putOneRowImage(x, numPixelsPerByte, shift)
        RefDS(_x);
        _9putOneRowImage(_x, _numPixelsPerByte, _shift);

        //     end for
        _i = _i + -1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRefi(_x);
    DeRef(_1003);
    return 0;
    ;
}


_9get_all_palette()
{
    int _mem;
    int _numColors;
    int _vc = 0;
    int _reg = 0;
    int _colors = 0;
    int _1017 = 0;
    int _1005 = 0;
    int _0, _1, _2;
    

    //     vc = video_config()
    _vc = _8video_config();

    //     numColors = vc[VC_NCOLORS]
    _2 = (int)SEQ_PTR(_vc);
    _numColors = (int)*(((s1_ptr)_2)->base + 7);

    //     reg = repeat(0, REG_LIST_SIZE)
    _reg = Repeat(0, 10);

    //     mem = allocate_low(numColors*3)
    if (_numColors == (short)_numColors)
        _1005 = _numColors * 3;
    else
        _1005 = NewDouble(_numColors * (double)3);
    Ref(_1005);
    _mem = _2allocate_low(_1005);

    //     if mem then
    if (_mem == 0)
        goto L1;

    // 	reg[REG_AX] = #1017
    _2 = (int)SEQ_PTR(_reg);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _reg = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    *(int *)_2 = 4119;

    // 	reg[REG_BX] = 0
    _2 = (int)SEQ_PTR(_reg);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _reg = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    *(int *)_2 = 0;

    // 	reg[REG_CX] = numColors
    _2 = (int)SEQ_PTR(_reg);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _reg = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    *(int *)_2 = _numColors;

    // 	reg[REG_ES] = floor(mem/16)
    DeRef(_1005);
    if (16 > 0 && _mem >= 0) {
        _1005 = _mem / 16;
    }
    else {
        temp_dbl = floor((double)_mem / (double)16);
        _1005 = (long)temp_dbl;
    }
    _2 = (int)SEQ_PTR(_reg);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _reg = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = _1005;

    // 	reg[REG_DX] = and_bits(mem, 15)
    _1005 = (_mem & 15);
    _2 = (int)SEQ_PTR(_reg);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _reg = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    *(int *)_2 = _1005;

    // 	reg = dos_interrupt(#10, reg)
    RefDS(_reg);
    _0 = _reg;
    _reg = _2dos_interrupt(16, _reg);
    DeRefDSi(_0);

    // 	colors = {}
    RefDS(_202);
    _colors = _202;

    // 	for col = mem to mem+(numColors-1)*3 by 3 do
    _1005 = _numColors - 1;
    if ((long)((unsigned long)_1005 +(unsigned long) HIGH_BITS) >= 0)
        _1005 = NewDouble((double)_1005);
    _0 = _1005;
    if (IS_ATOM_INT(_1005)) {
        if (_1005 == (short)_1005)
            _1005 = _1005 * 3;
        else
            _1005 = NewDouble(_1005 * (double)3);
    }
    else {
        _1005 = NewDouble(DBL_PTR(_1005)->dbl * (double)3);
    }
    DeRef(_0);
    _0 = _1005;
    if (IS_ATOM_INT(_1005)) {
        _1005 = _mem + _1005;
        if ((long)((unsigned long)_1005 + (unsigned long)HIGH_BITS) >= 0) 
            _1005 = NewDouble((double)_1005);
    }
    else {
        _1005 = NewDouble((double)_mem + DBL_PTR(_1005)->dbl);
    }
    DeRef(_0);
    { int _col;
        _col = _mem;
L2:
        if (binary_op_a(GREATER, _col, _1005))
            goto L3;

        // 	    colors = append(colors, peek({col,3}))
        DeRef(_1017);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _col;
        Ref(_col);
        ((int *)_2)[2] = 3;
        _1017 = MAKE_SEQ(_1);
        _0 = _1017;
        _1 = (int)SEQ_PTR(_1017);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _1017 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            *(int *)poke4_addr = *poke_addr++;
        }
        DeRefDS(_0);
        RefDS(_1017);
        Append(&_colors, _colors, _1017);

        // 	end for
        _0 = _col;
        if (IS_ATOM_INT(_col)) {
            _col = _col + 3;
            if ((long)((unsigned long)_col +(unsigned long) HIGH_BITS) >= 0) 
                _col = NewDouble((double)_col);
        }
        else {
            _col = binary_op_a(PLUS, _col, 3);
        }
        DeRef(_0);
        goto L2;
L3:
        ;
        DeRef(_col);
    }

    // 	free_low(mem)
    _2free_low(_mem);

    // 	return colors
    DeRefi(_vc);
    DeRefi(_reg);
    DeRef(_1017);
    DeRef(_1005);
    return _colors;
    goto L4;
L1:

    // 	return {} -- unlikely
    RefDS(_202);
    DeRefi(_vc);
    DeRefi(_reg);
    DeRef(_colors);
    DeRef(_1017);
    DeRef(_1005);
    return _202;
L4:
    ;
}


int _9putColorTable(int _numColors, int _pal)
{
    int _1021 = 0;
    int _1020;
    int _0, _1, _2;
    

    //     for i = 1 to numColors do
    _1020 = _numColors;
    { int _i;
        _i = 1;
L1:
        if (_i > _1020)
            goto L2;

        // 	puts(fn, pal[i][3])     -- blue first in .BMP file
        DeRef(_1021);
        _2 = (int)SEQ_PTR(_pal);
        _1021 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1021);
        _0 = _1021;
        _2 = (int)SEQ_PTR(_1021);
        _1021 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_1021);
        DeRef(_0);
        EPuts(_9fn, _1021);

        // 	puts(fn, pal[i][2])     -- green second 
        DeRef(_1021);
        _2 = (int)SEQ_PTR(_pal);
        _1021 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1021);
        _0 = _1021;
        _2 = (int)SEQ_PTR(_1021);
        _1021 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_1021);
        DeRef(_0);
        EPuts(_9fn, _1021);

        // 	puts(fn, pal[i][1])     -- red third
        DeRef(_1021);
        _2 = (int)SEQ_PTR(_pal);
        _1021 = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_1021);
        _0 = _1021;
        _2 = (int)SEQ_PTR(_1021);
        _1021 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_1021);
        DeRef(_0);
        EPuts(_9fn, _1021);

        // 	puts(fn, 0)             -- reserved, must be 0
        EPuts(_9fn, 0);

        //     end for
        _i = _i + 1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRefDS(_pal);
    DeRef(_1021);
    return 0;
    ;
}


_9save_screen(int _r, int _file_name)
{
    int _vc = 0;
    int _numColors;
    int _1028 = 0;
    int _1051 = 0;
    int _1034 = 0;
    int _0, _1, _2;
    

    //     error_code = BMP_SUCCESS
    _9error_code = 0;

    //     fn = open(file_name, "wb")
    _9fn = EOpen(_file_name, _1027);

    //     if fn = -1 then
    if (_9fn != -1)
        goto L1;

    // 	return BMP_OPEN_FAILED
    DeRef(_r);
    DeRefDS(_file_name);
    return 1;
L1:

    //     vc = video_config()
    _0 = _vc;
    _vc = _8video_config();
    DeRefi(_0);

    //     if sequence(r) then
    DeRef(_1028);
    _1028 = IS_SEQUENCE(_r);
    if (_1028 == 0)
        goto L2;

    // 	numXPixels = r[2][1] - r[1][1] + 1
    _2 = (int)SEQ_PTR(_r);
    _1028 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1028);
    _0 = _1028;
    _2 = (int)SEQ_PTR(_1028);
    _1028 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1028);
    DeRef(_0);
    DeRef(_1034);
    _2 = (int)SEQ_PTR(_r);
    _1034 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1034);
    _0 = _1034;
    _2 = (int)SEQ_PTR(_1034);
    _1034 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1034);
    DeRef(_0);
    _0 = _1034;
    if (IS_ATOM_INT(_1028) && IS_ATOM_INT(_1034)) {
        _1034 = _1028 - _1034;
        if ((long)((unsigned long)_1034 +(unsigned long) HIGH_BITS) >= 0)
            _1034 = NewDouble((double)_1034);
    }
    else {
        _1034 = binary_op(MINUS, _1028, _1034);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_1034)) {
        _9numXPixels = _1034 + 1;
    }
    else
        _9numXPixels = 1+(long)(DBL_PTR(_1034)->dbl);

    // 	numYPixels = r[2][2] - r[1][2] + 1
    DeRef(_1034);
    _2 = (int)SEQ_PTR(_r);
    _1034 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1034);
    _0 = _1034;
    _2 = (int)SEQ_PTR(_1034);
    _1034 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1034);
    DeRef(_0);
    DeRef(_1028);
    _2 = (int)SEQ_PTR(_r);
    _1028 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1028);
    _0 = _1028;
    _2 = (int)SEQ_PTR(_1028);
    _1028 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1028);
    DeRef(_0);
    _0 = _1028;
    if (IS_ATOM_INT(_1034) && IS_ATOM_INT(_1028)) {
        _1028 = _1034 - _1028;
        if ((long)((unsigned long)_1028 +(unsigned long) HIGH_BITS) >= 0)
            _1028 = NewDouble((double)_1028);
    }
    else {
        _1028 = binary_op(MINUS, _1034, _1028);
    }
    DeRef(_0);
    if (IS_ATOM_INT(_1028)) {
        _9numYPixels = _1028 + 1;
    }
    else
        _9numYPixels = 1+(long)(DBL_PTR(_1028)->dbl);

    // 	if r[2][1] >= vc[VC_XPIXELS] or r[2][2] >= vc[VC_YPIXELS] then
    DeRef(_1028);
    _2 = (int)SEQ_PTR(_r);
    _1028 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1028);
    _0 = _1028;
    _2 = (int)SEQ_PTR(_1028);
    _1028 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1028);
    DeRef(_0);
    DeRef(_1034);
    _2 = (int)SEQ_PTR(_vc);
    _1034 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1028)) {
        _1034 = (_1028 >= _1034);
    }
    else {
        _1034 = binary_op(GREATEREQ, _1028, _1034);
    }
    if (IS_ATOM_INT(_1034)) {
        if (_1034 != 0) {
            goto L3;
        }
    }
    else {
        if (DBL_PTR(_1034)->dbl != 0.0) {
            goto L3;
        }
    }
    DeRef(_1028);
    _2 = (int)SEQ_PTR(_r);
    _1028 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1028);
    _0 = _1028;
    _2 = (int)SEQ_PTR(_1028);
    _1028 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1028);
    DeRef(_0);
    DeRef(_1051);
    _2 = (int)SEQ_PTR(_vc);
    _1051 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1028)) {
        _1051 = (_1028 >= _1051);
    }
    else {
        _1051 = binary_op(GREATEREQ, _1028, _1051);
    }
L4:
    if (_1051 == 0) {
        goto L5;
    }
    else {
        if (!IS_ATOM_INT(_1051) && DBL_PTR(_1051)->dbl == 0.0)
            goto L5;
    }
L3:

    // 	    close(fn)
    EClose(_9fn);

    // 	    return BMP_INVALID_MODE   -- not a valid argument 
    DeRef(_r);
    DeRefDS(_file_name);
    DeRefi(_vc);
    DeRef(_1028);
    DeRef(_1051);
    DeRef(_1034);
    return 4;
L5:

    // 	startXPixel = r[1][1]
    DeRef(_1051);
    _2 = (int)SEQ_PTR(_r);
    _1051 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1051);
    _2 = (int)SEQ_PTR(_1051);
    _9startXPixel = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_9startXPixel))
        _9startXPixel = (long)DBL_PTR(_9startXPixel)->dbl;

    // 	startYPixel = r[1][2]
    DeRef(_1051);
    _2 = (int)SEQ_PTR(_r);
    _1051 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1051);
    _2 = (int)SEQ_PTR(_1051);
    _9startYPixel = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_9startYPixel))
        _9startYPixel = (long)DBL_PTR(_9startYPixel)->dbl;

    // 	endYPixel   = r[2][2]
    DeRef(_1051);
    _2 = (int)SEQ_PTR(_r);
    _1051 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1051);
    _2 = (int)SEQ_PTR(_1051);
    _9endYPixel = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_9endYPixel))
        _9endYPixel = (long)DBL_PTR(_9endYPixel)->dbl;
    goto L6;
L2:

    // 	numXPixels = vc[VC_XPIXELS]
    _2 = (int)SEQ_PTR(_vc);
    _9numXPixels = (int)*(((s1_ptr)_2)->base + 5);

    // 	numYPixels = vc[VC_YPIXELS]
    _2 = (int)SEQ_PTR(_vc);
    _9numYPixels = (int)*(((s1_ptr)_2)->base + 6);

    // 	startXPixel = 0
    _9startXPixel = 0;

    // 	startYPixel = 0
    _9startYPixel = 0;

    // 	endYPixel   = numYPixels - 1
    _9endYPixel = _9numYPixels - 1;
L6:

    //     if numXPixels <= 0 or numYPixels <= 0 then
    DeRef(_1051);
    _1051 = (_9numXPixels <= 0);
    if (_1051 != 0) {
        goto L7;
    }
    DeRef(_1028);
    _1028 = (_9numYPixels <= 0);
L8:
    if (_1028 == 0)
        goto L9;
L7:

    // 	close(fn)
    EClose(_9fn);

    // 	return BMP_INVALID_MODE
    DeRef(_r);
    DeRefDS(_file_name);
    DeRefi(_vc);
    DeRef(_1028);
    DeRef(_1051);
    DeRef(_1034);
    return 4;
L9:

    //     numColors = vc[VC_NCOLORS]
    _2 = (int)SEQ_PTR(_vc);
    _numColors = (int)*(((s1_ptr)_2)->base + 7);

    //     putBmpFileHeader(numColors)
    _9putBmpFileHeader(_numColors);

    //     if error_code = BMP_SUCCESS then
    if (_9error_code != 0)
        goto LA;

    // 	putColorTable(numColors, get_all_palette()*4)
    _0 = _1028;
    _1028 = _9get_all_palette();
    DeRef(_0);
    _0 = _1028;
    _1028 = binary_op(MULTIPLY, _1028, 4);
    DeRefDS(_0);
    RefDS(_1028);
    _9putColorTable(_numColors, _1028);
LA:

    //     if error_code = BMP_SUCCESS then
    if (_9error_code != 0)
        goto LB;

    // 	putImage()
    _9putImage();
LB:

    //     close(fn)
    EClose(_9fn);

    //     return error_code
    DeRef(_r);
    DeRefDS(_file_name);
    DeRefi(_vc);
    DeRef(_1028);
    DeRef(_1051);
    DeRef(_1034);
    return _9error_code;
    ;
}


int _9putImage1(int _image)
{
    int _x = 0;
    int _numPixelsPerByte;
    int _shift;
    int _1070;
    int _0, _1, _2;
    

    //     numPixelsPerByte = 8 / bitCount
    _numPixelsPerByte = (8 % _9bitCount) ? NewDouble((double)8 / _9bitCount) : (8 / _9bitCount);
    if (!IS_ATOM_INT(_numPixelsPerByte)) {
        _1 = (long)(DBL_PTR(_numPixelsPerByte)->dbl);
        DeRefDS(_numPixelsPerByte);
        _numPixelsPerByte = _1;
    }

    //     shift = power(2, bitCount)
    _shift = power(2, _9bitCount);

    //     for i = numYPixels to 1 by -1 do
    { int _i;
        _i = _9numYPixels;
L1:
        if (_i < 1)
            goto L2;

        // 	x = image[i]
        DeRef(_x);
        _2 = (int)SEQ_PTR(_image);
        _x = (int)*(((s1_ptr)_2)->base + _i);
        Ref(_x);

        // 	if atom(x) then
        _1070 = IS_ATOM(_x);
        if (_1070 == 0)
            goto L3;

        // 	    error_code = BMP_INVALID_MODE
        _9error_code = 4;

        // 	    return
        DeRefDS(_image);
        DeRef(_x);
        return 0;
        goto L4;
L3:

        // 	elsif length(x) != numXPixels then
        _1070 = SEQ_PTR(_x)->length;
        if (_1070 == _9numXPixels)
            goto L5;

        // 	    error_code = BMP_INVALID_MODE
        _9error_code = 4;

        // 	    return
        DeRefDS(_image);
        DeRef(_x);
        return 0;
L5:
L4:

        // 	putOneRowImage(x, numPixelsPerByte, shift) 
        Ref(_x);
        _9putOneRowImage(_x, _numPixelsPerByte, _shift);

        //     end for
        _i = _i + -1;
        goto L1;
L2:
        ;
    }

    // end procedure
    DeRefDS(_image);
    DeRef(_x);
    return 0;
    ;
}


_9save_bitmap(int _palette_n_image, int _file_name)
{
    int _color = 0;
    int _image = 0;
    int _numColors;
    int _1076 = 0;
    int _0, _1, _2;
    

    //     error_code = BMP_SUCCESS
    _9error_code = 0;

    //     fn = open(file_name, "wb")
    _9fn = EOpen(_file_name, _1027);

    //     if fn = -1 then
    if (_9fn != -1)
        goto L1;

    // 	return BMP_OPEN_FAILED
    DeRefDS(_palette_n_image);
    DeRefDS(_file_name);
    return 1;
L1:

    //     color = palette_n_image[1]
    DeRef(_color);
    _2 = (int)SEQ_PTR(_palette_n_image);
    _color = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_color);

    //     image = palette_n_image[2]
    DeRef(_image);
    _2 = (int)SEQ_PTR(_palette_n_image);
    _image = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_image);

    //     numYPixels = length(image)
    _9numYPixels = SEQ_PTR(_image)->length;

    //     numXPixels = length(image[1])   -- assume the same length with each row
    DeRef(_1076);
    _2 = (int)SEQ_PTR(_image);
    _1076 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1076);
    _9numXPixels = SEQ_PTR(_1076)->length;

    //     numColors = length(color)
    _numColors = SEQ_PTR(_color)->length;

    //     putBmpFileHeader(numColors)
    _9putBmpFileHeader(_numColors);

    //     if error_code = BMP_SUCCESS then
    if (_9error_code != 0)
        goto L2;

    // 	putColorTable(numColors, color) 
    RefDS(_color);
    _9putColorTable(_numColors, _color);

    // 	putImage1(image)
    RefDS(_image);
    _9putImage1(_image);
L2:

    //     close(fn)
    EClose(_9fn);

    //     return error_code
    DeRefDS(_palette_n_image);
    DeRefDS(_file_name);
    DeRef(_color);
    DeRef(_image);
    DeRef(_1076);
    return _9error_code;
    ;
}


