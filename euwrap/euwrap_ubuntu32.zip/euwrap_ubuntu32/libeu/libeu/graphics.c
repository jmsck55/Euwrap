// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _40get_position()
{
    int _10472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_GET_POSITION, 0)*/
    _10472 = machine(25, 0);
    return _10472;
    ;
}
int get_position() __attribute__ ((alias ("_40get_position")));


void _40text_color(int _c_18835)
{
    int _10474 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = and_bits(c, 0x1F)*/
    _0 = _c_18835;
    if (IS_ATOM_INT(_c_18835)) {
        {unsigned long tu;
             tu = (unsigned long)_c_18835 & (unsigned long)31;
             _c_18835 = MAKE_UINT(tu);
        }
    }
    else {
        _c_18835 = binary_op(AND_BITS, _c_18835, 31);
    }
    DeRef(_0);

    /** 	c = true_fgcolor[c+1]*/
    if (IS_ATOM_INT(_c_18835)) {
        _10474 = _c_18835 + 1;
    }
    else
    _10474 = binary_op(PLUS, 1, _c_18835);
    DeRef(_c_18835);
    _2 = (int)SEQ_PTR(_36true_fgcolor_14151);
    if (!IS_ATOM_INT(_10474)){
        _c_18835 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10474)->dbl));
    }
    else{
        _c_18835 = (int)*(((s1_ptr)_2)->base + _10474);
    }
    Ref(_c_18835);

    /** 	machine_proc(M_SET_T_COLOR, c)*/
    machine(9, _c_18835);

    /** end procedure*/
    DeRef(_c_18835);
    DeRef(_10474);
    _10474 = NOVALUE;
    return;
    ;
}
void text_color() __attribute__ ((alias ("_40text_color")));


void _40bk_color(int _c_18843)
{
    int _10477 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = and_bits(c, 0x1F)*/
    _0 = _c_18843;
    if (IS_ATOM_INT(_c_18843)) {
        {unsigned long tu;
             tu = (unsigned long)_c_18843 & (unsigned long)31;
             _c_18843 = MAKE_UINT(tu);
        }
    }
    else {
        _c_18843 = binary_op(AND_BITS, _c_18843, 31);
    }
    DeRef(_0);

    /** 	c = true_bgcolor[c+1]*/
    if (IS_ATOM_INT(_c_18843)) {
        _10477 = _c_18843 + 1;
    }
    else
    _10477 = binary_op(PLUS, 1, _c_18843);
    DeRef(_c_18843);
    _2 = (int)SEQ_PTR(_36true_bgcolor_14153);
    if (!IS_ATOM_INT(_10477)){
        _c_18843 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10477)->dbl));
    }
    else{
        _c_18843 = (int)*(((s1_ptr)_2)->base + _10477);
    }
    Ref(_c_18843);

    /** 	machine_proc(M_SET_B_COLOR, c)*/
    machine(10, _c_18843);

    /** end procedure*/
    DeRef(_c_18843);
    DeRef(_10477);
    _10477 = NOVALUE;
    return;
    ;
}
void bk_color() __attribute__ ((alias ("_40bk_color")));


int _40console_colors(int _colorset_18850)
{
    int _currentset_18851 = NOVALUE;
    int _10508 = NOVALUE;
    int _10507 = NOVALUE;
    int _10506 = NOVALUE;
    int _10505 = NOVALUE;
    int _10504 = NOVALUE;
    int _10503 = NOVALUE;
    int _10501 = NOVALUE;
    int _10500 = NOVALUE;
    int _10499 = NOVALUE;
    int _10498 = NOVALUE;
    int _10496 = NOVALUE;
    int _10495 = NOVALUE;
    int _10493 = NOVALUE;
    int _10492 = NOVALUE;
    int _10491 = NOVALUE;
    int _10490 = NOVALUE;
    int _10488 = NOVALUE;
    int _10487 = NOVALUE;
    int _10485 = NOVALUE;
    int _10482 = NOVALUE;
    int _10480 = NOVALUE;
    int _10479 = NOVALUE;
    int _0, _1, _2;
    

    /** 	currentset = {true_fgcolor[1 .. 16], true_bgcolor[1 .. 16]}*/
    rhs_slice_target = (object_ptr)&_10479;
    RHS_Slice(_36true_fgcolor_14151, 1, 16);
    rhs_slice_target = (object_ptr)&_10480;
    RHS_Slice(_36true_bgcolor_14153, 1, 16);
    DeRef(_currentset_18851);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _10479;
    ((int *)_2)[2] = _10480;
    _currentset_18851 = MAKE_SEQ(_1);
    _10480 = NOVALUE;
    _10479 = NOVALUE;

    /** 	if length(colorset) = 16 then*/
    if (IS_SEQUENCE(_colorset_18850)){
            _10482 = SEQ_PTR(_colorset_18850)->length;
    }
    else {
        _10482 = 1;
    }
    if (_10482 != 16)
    goto L1; // [28] 39

    /** 		colorset = {colorset, colorset}*/
    RefDS(_colorset_18850);
    RefDS(_colorset_18850);
    _0 = _colorset_18850;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _colorset_18850;
    ((int *)_2)[2] = _colorset_18850;
    _colorset_18850 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	if length(colorset) != 2 then*/
    if (IS_SEQUENCE(_colorset_18850)){
            _10485 = SEQ_PTR(_colorset_18850)->length;
    }
    else {
        _10485 = 1;
    }
    if (_10485 == 2)
    goto L2; // [44] 55

    /** 		return currentset*/
    DeRefDS(_colorset_18850);
    return _currentset_18851;
L2: 

    /** 	if length(colorset[FGSET]) != 16 then*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10487 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_10487)){
            _10488 = SEQ_PTR(_10487)->length;
    }
    else {
        _10488 = 1;
    }
    _10487 = NOVALUE;
    if (_10488 == 16)
    goto L3; // [66] 77

    /** 	   	return currentset*/
    DeRefDS(_colorset_18850);
    _10487 = NOVALUE;
    return _currentset_18851;
L3: 

    /** 	if not types:char_test( colorset[FGSET], {{0,15}} ) then*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10490 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 15;
    _10491 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _10491;
    _10492 = MAKE_SEQ(_1);
    _10491 = NOVALUE;
    Ref(_10490);
    _10493 = _7char_test(_10490, _10492);
    _10490 = NOVALUE;
    _10492 = NOVALUE;
    if (IS_ATOM_INT(_10493)) {
        if (_10493 != 0){
            DeRef(_10493);
            _10493 = NOVALUE;
            goto L4; // [98] 108
        }
    }
    else {
        if (DBL_PTR(_10493)->dbl != 0.0){
            DeRef(_10493);
            _10493 = NOVALUE;
            goto L4; // [98] 108
        }
    }
    DeRef(_10493);
    _10493 = NOVALUE;

    /** 	   	return currentset*/
    DeRefDS(_colorset_18850);
    _10487 = NOVALUE;
    return _currentset_18851;
L4: 

    /** 	if length(colorset[BGSET]) != 16 then*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10495 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_10495)){
            _10496 = SEQ_PTR(_10495)->length;
    }
    else {
        _10496 = 1;
    }
    _10495 = NOVALUE;
    if (_10496 == 16)
    goto L5; // [119] 130

    /** 	   	return currentset*/
    DeRefDS(_colorset_18850);
    _10487 = NOVALUE;
    _10495 = NOVALUE;
    return _currentset_18851;
L5: 

    /** 	if not types:char_test( colorset[BGSET], {{0,15}} ) then*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10498 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 15;
    _10499 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _10499;
    _10500 = MAKE_SEQ(_1);
    _10499 = NOVALUE;
    Ref(_10498);
    _10501 = _7char_test(_10498, _10500);
    _10498 = NOVALUE;
    _10500 = NOVALUE;
    if (IS_ATOM_INT(_10501)) {
        if (_10501 != 0){
            DeRef(_10501);
            _10501 = NOVALUE;
            goto L6; // [151] 161
        }
    }
    else {
        if (DBL_PTR(_10501)->dbl != 0.0){
            DeRef(_10501);
            _10501 = NOVALUE;
            goto L6; // [151] 161
        }
    }
    DeRef(_10501);
    _10501 = NOVALUE;

    /** 	   	return currentset*/
    DeRefDS(_colorset_18850);
    _10487 = NOVALUE;
    _10495 = NOVALUE;
    return _currentset_18851;
L6: 

    /** 	true_fgcolor[1..16]  = colorset[FGSET]*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10503 = (int)*(((s1_ptr)_2)->base + 1);
    assign_slice_seq = (s1_ptr *)&_36true_fgcolor_14151;
    AssignSlice(1, 16, _10503);
    _10503 = NOVALUE;

    /** 	true_fgcolor[17..32] = colorset[FGSET] + BLINKING*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10504 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_10504)) {
        _10505 = _10504 + 16;
        if ((long)((unsigned long)_10505 + (unsigned long)HIGH_BITS) >= 0) 
        _10505 = NewDouble((double)_10505);
    }
    else {
        _10505 = binary_op(PLUS, _10504, 16);
    }
    _10504 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_36true_fgcolor_14151;
    AssignSlice(17, 32, _10505);
    DeRef(_10505);
    _10505 = NOVALUE;

    /** 	true_bgcolor[1..16]  = colorset[BGSET]*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10506 = (int)*(((s1_ptr)_2)->base + 2);
    assign_slice_seq = (s1_ptr *)&_36true_bgcolor_14153;
    AssignSlice(1, 16, _10506);
    _10506 = NOVALUE;

    /** 	true_bgcolor[17..32] = colorset[BGSET] + BLINKING*/
    _2 = (int)SEQ_PTR(_colorset_18850);
    _10507 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_10507)) {
        _10508 = _10507 + 16;
        if ((long)((unsigned long)_10508 + (unsigned long)HIGH_BITS) >= 0) 
        _10508 = NewDouble((double)_10508);
    }
    else {
        _10508 = binary_op(PLUS, _10507, 16);
    }
    _10507 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_36true_bgcolor_14153;
    AssignSlice(17, 32, _10508);
    DeRef(_10508);
    _10508 = NOVALUE;

    /** 	return currentset*/
    DeRefDS(_colorset_18850);
    _10487 = NOVALUE;
    _10495 = NOVALUE;
    return _currentset_18851;
    ;
}
int console_colors() __attribute__ ((alias ("_40console_colors")));


void _40wrap(int _on_18906)
{
    int _10510 = NOVALUE;
    int _10509 = NOVALUE;
    int _0, _1, _2;
    

    /** 	machine_proc(M_WRAP, not equal(on, 0))*/
    if (_on_18906 == 0)
    _10509 = 1;
    else if (IS_ATOM_INT(_on_18906) && IS_ATOM_INT(0))
    _10509 = 0;
    else
    _10509 = (compare(_on_18906, 0) == 0);
    _10510 = (_10509 == 0);
    _10509 = NOVALUE;
    machine(7, _10510);
    _10510 = NOVALUE;

    /** end procedure*/
    DeRef(_on_18906);
    return;
    ;
}


void _40scroll(int _amount_18911, int _top_line_18912, int _bottom_line_18913)
{
    int _10511 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_18911)) {
        _1 = (long)(DBL_PTR(_amount_18911)->dbl);
        DeRefDS(_amount_18911);
        _amount_18911 = _1;
    }

    /** 	machine_proc(M_SCROLL, {amount, top_line, bottom_line})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _amount_18911;
    Ref(_top_line_18912);
    *((int *)(_2+8)) = _top_line_18912;
    Ref(_bottom_line_18913);
    *((int *)(_2+12)) = _bottom_line_18913;
    _10511 = MAKE_SEQ(_1);
    machine(8, _10511);
    DeRefDS(_10511);
    _10511 = NOVALUE;

    /** end procedure*/
    DeRef(_top_line_18912);
    DeRef(_bottom_line_18913);
    return;
    ;
}
void scroll() __attribute__ ((alias ("_40scroll")));


int _40graphics_mode(int _m_18917)
{
    int _10512 = NOVALUE;
    int _0, _1, _2;
    

    /**    return machine_func(M_GRAPHICS_MODE, m)*/
    _10512 = machine(5, _m_18917);
    DeRef(_m_18917);
    return _10512;
    ;
}
int graphics_mode() __attribute__ ((alias ("_40graphics_mode")));



// 0xF64C00FF
