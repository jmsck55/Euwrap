// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _2syncolor_new()
{
    int _new_inlined_new_at_2_24904 = NOVALUE;
    int _state_inlined_new_at_2_24903 = NOVALUE;
    int _6310 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return syncolor:new()*/

    /** 	atom state = eumem:malloc()*/
    _0 = _state_inlined_new_at_2_24903;
    _state_inlined_new_at_2_24903 = _28malloc(1, 1);
    DeRef(_0);

    /** 	reset(state)*/
    Ref(_state_inlined_new_at_2_24903);
    _5reset(_state_inlined_new_at_2_24903);

    /** 	return state*/
    Ref(_state_inlined_new_at_2_24903);
    DeRef(_new_inlined_new_at_2_24904);
    _new_inlined_new_at_2_24904 = _state_inlined_new_at_2_24903;
    DeRef(_state_inlined_new_at_2_24903);
    _state_inlined_new_at_2_24903 = NOVALUE;
    Ref(_new_inlined_new_at_2_24904);
    DeRef(_6310);
    _6310 = _new_inlined_new_at_2_24904;
    return _6310;
    ;
}


int _2base64_encode(int _a_12117, int _b_12118)
{
    int _6881 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return base64:encode(a,b)*/
    Ref(_a_12117);
    Ref(_b_12118);
    _6881 = _30encode(_a_12117, _b_12118);
    DeRef(_a_12117);
    DeRef(_b_12118);
    return _6881;
    ;
}


int _2base64_decode(int _a_12122)
{
    int _6882 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return base64:decode(a)*/
    Ref(_a_12122);
    _6882 = _30decode(_a_12122);
    DeRef(_a_12122);
    return _6882;
    ;
}


void _2console_allow_break(int _a_16335)
{
    int _0, _1, _2;
    

    /** 	console:allow_break(a)*/

    /** 	machine_proc(M_ALLOW_BREAK, b)*/
    machine(42, _a_16335);

    /** end procedure*/
    goto L1; // [10] 13
L1: 

    /** end procedure*/
    DeRef(_a_16335);
    return;
    ;
}


int _2console_has_console()
{
    int _has_console_inlined_has_console_at_2_16340 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return console:has_console()*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_2_16340);
    _has_console_inlined_has_console_at_2_16340 = machine(99, 0);
    return _has_console_inlined_has_console_at_2_16340;
    ;
}


int _2datetime_format(int _a_16343, int _b_16344)
{
    int _9331 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:format(a,b)*/
    Ref(_a_16343);
    Ref(_b_16344);
    _9331 = _12format(_a_16343, _b_16344);
    DeRef(_a_16343);
    DeRef(_b_16344);
    return _9331;
    ;
}


int _2datetime_new(int _n1_16348, int _n2_16349, int _n3_16350, int _n4_16351, int _n5_16352, int _n6_16353)
{
    int _9332 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:new(n1,n2,n3,n4,n5,n6)*/
    Ref(_n1_16348);
    Ref(_n2_16349);
    Ref(_n3_16350);
    Ref(_n4_16351);
    Ref(_n5_16352);
    Ref(_n6_16353);
    _9332 = _12new(_n1_16348, _n2_16349, _n3_16350, _n4_16351, _n5_16352, _n6_16353);
    DeRef(_n1_16348);
    DeRef(_n2_16349);
    DeRef(_n3_16350);
    DeRef(_n4_16351);
    DeRef(_n5_16352);
    DeRef(_n6_16353);
    return _9332;
    ;
}


int _2datetime_datetime(int _a_16357)
{
    int _9333 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:datetime(a)*/
    Ref(_a_16357);
    _9333 = _12datetime(_a_16357);
    DeRef(_a_16357);
    return _9333;
    ;
}


int _2datetime_parse(int _a_16361, int _b_16362, int _c_16363)
{
    int _9334 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:parse(a,b,c)*/
    Ref(_a_16361);
    Ref(_b_16362);
    Ref(_c_16363);
    _9334 = _12parse(_a_16361, _b_16362, _c_16363);
    DeRef(_a_16361);
    DeRef(_b_16362);
    DeRef(_c_16363);
    return _9334;
    ;
}


int _2datetime_add(int _a_16367, int _b_16368, int _c_16369)
{
    int _9335 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetime:add(a,b,c)*/
    Ref(_a_16367);
    Ref(_b_16368);
    Ref(_c_16369);
    _9335 = _12add(_a_16367, _b_16368, _c_16369);
    DeRef(_a_16367);
    DeRef(_b_16368);
    DeRef(_c_16369);
    return _9335;
    ;
}


int _2stdget_get(int _a_18816, int _b_18817, int _c_18818)
{
    int _get_inlined_get_at_2_18820 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdget:get(a,b,c)*/
    if (!IS_ATOM_INT(_a_18816)) {
        _1 = (long)(DBL_PTR(_a_18816)->dbl);
        DeRefDS(_a_18816);
        _a_18816 = _1;
    }
    if (!IS_ATOM_INT(_b_18817)) {
        _1 = (long)(DBL_PTR(_b_18817)->dbl);
        DeRefDS(_b_18817);
        _b_18817 = _1;
    }
    if (!IS_ATOM_INT(_c_18818)) {
        _1 = (long)(DBL_PTR(_c_18818)->dbl);
        DeRefDS(_c_18818);
        _c_18818 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _0 = _get_inlined_get_at_2_18820;
    _get_inlined_get_at_2_18820 = _17get_value(_a_18816, _b_18817, _c_18818);
    DeRef(_0);
    DeRef(_a_18816);
    DeRef(_b_18817);
    DeRef(_c_18818);
    return _get_inlined_get_at_2_18820;
    ;
}


void _2graphics_wrap(int _a_18921)
{
    int _wrap_2__tmp_at2_18924 = NOVALUE;
    int _wrap_1__tmp_at2_18923 = NOVALUE;
    int _0, _1, _2;
    

    /** 	graphics:wrap(a)*/

    /** 	machine_proc(M_WRAP, not equal(on, 0))*/
    if (_a_18921 == 0)
    _wrap_1__tmp_at2_18923 = 1;
    else if (IS_ATOM_INT(_a_18921) && IS_ATOM_INT(0))
    _wrap_1__tmp_at2_18923 = 0;
    else
    _wrap_1__tmp_at2_18923 = (compare(_a_18921, 0) == 0);
    _wrap_2__tmp_at2_18924 = (_wrap_1__tmp_at2_18923 == 0);
    machine(7, _wrap_2__tmp_at2_18924);

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** end procedure*/
    DeRef(_a_18921);
    return;
    ;
}


int _2locale_get()
{
    int _11617 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:get()*/
    _11617 = _43get();
    return _11617;
    ;
}


int _2locale_datetime(int _a_20515, int _b_20516)
{
    int _11618 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:datetime(a,b)*/
    Ref(_a_20515);
    Ref(_b_20516);
    _11618 = _43datetime(_a_20515, _b_20516);
    DeRef(_a_20515);
    DeRef(_b_20516);
    return _11618;
    ;
}


int _2locale_set(int _a_20520)
{
    int _11619 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return locale:set(a)*/
    Ref(_a_20520);
    _11619 = _43set(_a_20520);
    DeRef(_a_20520);
    return _11619;
    ;
}


int _2map_new(int _a_20524)
{
    int _11620 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:new(a)*/
    Ref(_a_20524);
    _11620 = _33new(_a_20524);
    DeRef(_a_20524);
    return _11620;
    ;
}


int _2map_get(int _a_20528, int _b_20529, int _c_20530)
{
    int _11621 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:get(a,b,c)*/
    Ref(_a_20528);
    Ref(_b_20529);
    Ref(_c_20530);
    _11621 = _33get(_a_20528, _b_20529, _c_20530);
    DeRef(_a_20528);
    DeRef(_b_20529);
    DeRef(_c_20530);
    return _11621;
    ;
}


int _2map_size(int _a_20534)
{
    int _size_1__tmp_at2_20537 = NOVALUE;
    int _size_inlined_size_at_2_20536 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:size(a)*/

    /** 	return eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    DeRef(_size_1__tmp_at2_20537);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_a_20534)){
        _size_1__tmp_at2_20537 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_20534)->dbl));
    }
    else{
        _size_1__tmp_at2_20537 = (int)*(((s1_ptr)_2)->base + _a_20534);
    }
    Ref(_size_1__tmp_at2_20537);
    DeRef(_size_inlined_size_at_2_20536);
    _2 = (int)SEQ_PTR(_size_1__tmp_at2_20537);
    _size_inlined_size_at_2_20536 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_size_inlined_size_at_2_20536);
    DeRef(_size_1__tmp_at2_20537);
    _size_1__tmp_at2_20537 = NOVALUE;
    DeRef(_a_20534);
    return _size_inlined_size_at_2_20536;
    ;
}


void _2map_clear(int _a_20540)
{
    int _0, _1, _2;
    

    /** 	map:clear(a)*/
    Ref(_a_20540);
    _33clear(_a_20540);

    /** end procedure*/
    DeRef(_a_20540);
    return;
    ;
}


void _2map_remove(int _a_20543, int _b_20544)
{
    int _0, _1, _2;
    

    /** 	map:remove(a,b)*/
    Ref(_a_20543);
    Ref(_b_20544);
    _33remove(_a_20543, _b_20544);

    /** end procedure*/
    DeRef(_a_20543);
    DeRef(_b_20544);
    return;
    ;
}


int _2map_calc_hash(int _a_20547, int _b_20548)
{
    int _calc_hash_1__tmp_at2_20552 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_2_20551 = NOVALUE;
    int _ret__inlined_calc_hash_at_2_20550 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:calc_hash(a,b)*/
    if (!IS_ATOM_INT(_b_20548)) {
        _1 = (long)(DBL_PTR(_b_20548)->dbl);
        DeRefDS(_b_20548);
        _b_20548 = _1;
    }

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_2_20550);
    _ret__inlined_calc_hash_at_2_20550 = calc_hash(_a_20547, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_2_20550)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_2_20550)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_2_20550);
        _ret__inlined_calc_hash_at_2_20550 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at2_20552 = (_ret__inlined_calc_hash_at_2_20550 % _b_20548);
    DeRef(_calc_hash_inlined_calc_hash_at_2_20551);
    _calc_hash_inlined_calc_hash_at_2_20551 = _calc_hash_1__tmp_at2_20552 + 1;
    if (_calc_hash_inlined_calc_hash_at_2_20551 > MAXINT){
        _calc_hash_inlined_calc_hash_at_2_20551 = NewDouble((double)_calc_hash_inlined_calc_hash_at_2_20551);
    }
    DeRef(_ret__inlined_calc_hash_at_2_20550);
    _ret__inlined_calc_hash_at_2_20550 = NOVALUE;
    DeRef(_a_20547);
    DeRef(_b_20548);
    return _calc_hash_inlined_calc_hash_at_2_20551;
    ;
}


int _2map_compare(int _a_20555, int _b_20556, int _c_20557)
{
    int _11622 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return map:compare(a,b,c)*/
    Ref(_a_20555);
    Ref(_b_20556);
    Ref(_c_20557);
    _11622 = _33compare(_a_20555, _b_20556, _c_20557);
    DeRef(_a_20555);
    DeRef(_b_20556);
    DeRef(_c_20557);
    return _11622;
    ;
}


int _2math_sum(int _a_20561)
{
    int _11623 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return math:sum(a)*/
    Ref(_a_20561);
    _11623 = _20sum(_a_20561);
    DeRef(_a_20561);
    return _11623;
    ;
}


int _2pipeio_create()
{
    int _11813 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return pipeio:create()*/
    _11813 = _46create();
    return _11813;
    ;
}


int _2pipeio_close(int _a_20898)
{
    int _11814 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return pipeio:close(a)*/
    Ref(_a_20898);
    _11814 = _46close(_a_20898);
    DeRef(_a_20898);
    return _11814;
    ;
}


int _2regex_new(int _a_21469, int _b_21470)
{
    int _new_2__tmp_at5_24909 = NOVALUE;
    int _new_1__tmp_at5_24908 = NOVALUE;
    int _new_inlined_new_at_5_24907 = NOVALUE;
    int _options_inlined_new_at_2_24906 = NOVALUE;
    int _12128 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:new(a,b)*/
    Ref(_b_21470);
    DeRef(_options_inlined_new_at_2_24906);
    _options_inlined_new_at_2_24906 = _b_21470;

    /** 	if sequence(options) then */
    _new_1__tmp_at5_24908 = IS_SEQUENCE(_options_inlined_new_at_2_24906);
    if (_new_1__tmp_at5_24908 == 0)
    {
        goto L1; // [11] 21
    }
    else{
    }

    /** 		options = math:or_all(options) */
    Ref(_options_inlined_new_at_2_24906);
    _0 = _options_inlined_new_at_2_24906;
    _options_inlined_new_at_2_24906 = _20or_all(_options_inlined_new_at_2_24906);
    DeRef(_0);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_inlined_new_at_2_24906);
    Ref(_a_21469);
    DeRef(_new_2__tmp_at5_24909);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _a_21469;
    ((int *)_2)[2] = _options_inlined_new_at_2_24906;
    _new_2__tmp_at5_24909 = MAKE_SEQ(_1);
    DeRef(_new_inlined_new_at_5_24907);
    _new_inlined_new_at_5_24907 = machine(68, _new_2__tmp_at5_24909);
    DeRef(_options_inlined_new_at_2_24906);
    _options_inlined_new_at_2_24906 = NOVALUE;
    DeRef(_new_2__tmp_at5_24909);
    _new_2__tmp_at5_24909 = NOVALUE;
    Ref(_new_inlined_new_at_5_24907);
    DeRef(_12128);
    _12128 = _new_inlined_new_at_5_24907;
    DeRef(_a_21469);
    DeRef(_b_21470);
    return _12128;
    ;
}


int _2regex_escape(int _a_21474)
{
    int _escape_inlined_escape_at_2_24923 = NOVALUE;
    int _12129 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:escape(a)*/

    /** 	return text:escape(s, ".\\+*?[^]$(){}=!<>|:-")*/
    Ref(_a_21474);
    RefDS(_11966);
    _0 = _escape_inlined_escape_at_2_24923;
    _escape_inlined_escape_at_2_24923 = _6escape(_a_21474, _11966);
    DeRef(_0);
    Ref(_escape_inlined_escape_at_2_24923);
    DeRef(_12129);
    _12129 = _escape_inlined_escape_at_2_24923;
    DeRef(_a_21474);
    return _12129;
    ;
}


int _2regex_find_all(int _n1_21478, int _n2_21479, int _n3_21480, int _n4_21481, int _n5_21482)
{
    int _12130 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find_all(n1,n2,n3,n4,n5)*/
    Ref(_n1_21478);
    Ref(_n2_21479);
    Ref(_n3_21480);
    Ref(_n4_21481);
    Ref(_n5_21482);
    _12130 = _47find_all(_n1_21478, _n2_21479, _n3_21480, _n4_21481, _n5_21482);
    DeRef(_n1_21478);
    DeRef(_n2_21479);
    DeRef(_n3_21480);
    DeRef(_n4_21481);
    DeRef(_n5_21482);
    return _12130;
    ;
}


int _2regex_is_match(int _a_21486, int _b_21487, int _c_21488, int _d_21489)
{
    int _12131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:is_match(a,b,c,d)*/
    Ref(_a_21486);
    Ref(_b_21487);
    Ref(_c_21488);
    Ref(_d_21489);
    _12131 = _47is_match(_a_21486, _b_21487, _c_21488, _d_21489);
    DeRef(_a_21486);
    DeRef(_b_21487);
    DeRef(_c_21488);
    DeRef(_d_21489);
    return _12131;
    ;
}


int _2regex_split(int _a_21493, int _b_21494, int _c_21495, int _d_21496)
{
    int _split_inlined_split_at_2_24925 = NOVALUE;
    int _12132 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:split(a,b,c,d)*/
    if (!IS_ATOM_INT(_c_21495)) {
        _1 = (long)(DBL_PTR(_c_21495)->dbl);
        DeRefDS(_c_21495);
        _c_21495 = _1;
    }

    /** 	return split_limit(re, text, 0, from, options)*/
    Ref(_a_21493);
    Ref(_b_21494);
    Ref(_d_21496);
    _0 = _split_inlined_split_at_2_24925;
    _split_inlined_split_at_2_24925 = _47split_limit(_a_21493, _b_21494, 0, _c_21495, _d_21496);
    DeRef(_0);
    Ref(_split_inlined_split_at_2_24925);
    DeRef(_12132);
    _12132 = _split_inlined_split_at_2_24925;
    DeRef(_a_21493);
    DeRef(_b_21494);
    DeRef(_c_21495);
    DeRef(_d_21496);
    return _12132;
    ;
}


int _2regex_find_replace(int _n1_21500, int _n2_21501, int _n3_21502, int _n4_21503, int _n5_21504)
{
    int _find_replace_inlined_find_replace_at_2_24927 = NOVALUE;
    int _12133 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find_replace(n1,n2,n3,n4,n5)*/
    if (!IS_ATOM_INT(_n4_21503)) {
        _1 = (long)(DBL_PTR(_n4_21503)->dbl);
        DeRefDS(_n4_21503);
        _n4_21503 = _1;
    }

    /** 	return find_replace_limit(ex, text, replacement, -1, from, options)*/
    Ref(_n1_21500);
    Ref(_n2_21501);
    Ref(_n3_21502);
    Ref(_n5_21504);
    _0 = _find_replace_inlined_find_replace_at_2_24927;
    _find_replace_inlined_find_replace_at_2_24927 = _47find_replace_limit(_n1_21500, _n2_21501, _n3_21502, -1, _n4_21503, _n5_21504);
    DeRef(_0);
    Ref(_find_replace_inlined_find_replace_at_2_24927);
    DeRef(_12133);
    _12133 = _find_replace_inlined_find_replace_at_2_24927;
    DeRef(_n1_21500);
    DeRef(_n2_21501);
    DeRef(_n3_21502);
    DeRef(_n4_21503);
    DeRef(_n5_21504);
    return _12133;
    ;
}


int _2regex_get_ovector_size(int _a_21508, int _b_21509)
{
    int _12134 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:get_ovector_size(a,b)*/
    Ref(_a_21508);
    Ref(_b_21509);
    _12134 = _47get_ovector_size(_a_21508, _b_21509);
    DeRef(_a_21508);
    DeRef(_b_21509);
    return _12134;
    ;
}


int _2regex_find(int _n1_21513, int _n2_21514, int _n3_21515, int _n4_21516, int _n5_21517)
{
    int _12135 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return regex:find(n1,n2,n3,n4,n5)*/
    Ref(_n1_21513);
    Ref(_n2_21514);
    Ref(_n3_21515);
    Ref(_n4_21516);
    Ref(_n5_21517);
    _12135 = _47find(_n1_21513, _n2_21514, _n3_21515, _n4_21516, _n5_21517);
    DeRef(_n1_21513);
    DeRef(_n2_21514);
    DeRef(_n3_21515);
    DeRef(_n4_21516);
    DeRef(_n5_21517);
    return _12135;
    ;
}


int _2search_find_all(int _a_21521, int _b_21522, int _c_21523)
{
    int _12136 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return search:find_all(a,b,c)*/
    Ref(_a_21521);
    Ref(_b_21522);
    Ref(_c_21523);
    _12136 = _9find_all(_a_21521, _b_21522, _c_21523);
    DeRef(_a_21521);
    DeRef(_b_21522);
    DeRef(_c_21523);
    return _12136;
    ;
}


int _2search_find_replace(int _a_21527, int _b_21528, int _c_21529, int _d_21530)
{
    int _12137 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return search:find_replace(a,b,c,d)*/
    Ref(_a_21527);
    Ref(_b_21528);
    Ref(_c_21529);
    Ref(_d_21530);
    _12137 = _9find_replace(_a_21527, _b_21528, _c_21529, _d_21530);
    DeRef(_a_21527);
    DeRef(_b_21528);
    DeRef(_c_21529);
    DeRef(_d_21530);
    return _12137;
    ;
}


int _2stdseq_split(int _a_21534, int _b_21535, int _c_21536, int _d_21537)
{
    int _12138 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:split(a,b,c,d)*/
    Ref(_a_21534);
    Ref(_b_21535);
    Ref(_c_21536);
    Ref(_d_21537);
    _12138 = _23split(_a_21534, _b_21535, _c_21536, _d_21537);
    DeRef(_a_21534);
    DeRef(_b_21535);
    DeRef(_c_21536);
    DeRef(_d_21537);
    return _12138;
    ;
}


int _2sockets_create(int _a_22210, int _b_22211, int _c_22212)
{
    int _12425 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sockets:create(a,b,c)*/
    Ref(_a_22210);
    Ref(_b_22211);
    Ref(_c_22212);
    _12425 = _48create(_a_22210, _b_22211, _c_22212);
    DeRef(_a_22210);
    DeRef(_b_22211);
    DeRef(_c_22212);
    return _12425;
    ;
}


int _2sockets_close(int _a_22216)
{
    int _close_1__tmp_at2_22219 = NOVALUE;
    int _close_inlined_close_at_2_22218 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sockets:close(a)*/

    /** 	return machine_func(M_SOCK_CLOSE, { sock })*/
    _0 = _close_1__tmp_at2_22219;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_a_22216);
    *((int *)(_2+4)) = _a_22216;
    _close_1__tmp_at2_22219 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_close_inlined_close_at_2_22218);
    _close_inlined_close_at_2_22218 = machine(82, _close_1__tmp_at2_22219);
    DeRef(_close_1__tmp_at2_22219);
    _close_1__tmp_at2_22219 = NOVALUE;
    DeRef(_a_22216);
    return _close_inlined_close_at_2_22218;
    ;
}


int _2stack_new(int _a_22524)
{
    int _new_1__tmp_at2_22528 = NOVALUE;
    int _new_inlined_new_at_2_22527 = NOVALUE;
    int _new_stack_inlined_new_at_2_22526 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stack:new(a)*/
    if (!IS_ATOM_INT(_a_22524)) {
        _1 = (long)(DBL_PTR(_a_22524)->dbl);
        DeRefDS(_a_22524);
        _a_22524 = _1;
    }

    /** 	atom new_stack = eumem:malloc()*/
    _0 = _new_stack_inlined_new_at_2_22526;
    _new_stack_inlined_new_at_2_22526 = _28malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[new_stack] = { type_is_stack, typ, {} }*/
    _0 = _new_1__tmp_at2_22528;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50type_is_stack_22227);
    *((int *)(_2+4)) = _50type_is_stack_22227;
    *((int *)(_2+8)) = _a_22524;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _new_1__tmp_at2_22528 = MAKE_SEQ(_1);
    DeRef(_0);
    RefDS(_new_1__tmp_at2_22528);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_new_stack_inlined_new_at_2_22526))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_new_stack_inlined_new_at_2_22526)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _new_stack_inlined_new_at_2_22526);
    _1 = *(int *)_2;
    *(int *)_2 = _new_1__tmp_at2_22528;
    DeRef(_1);

    /** 	return new_stack*/
    Ref(_new_stack_inlined_new_at_2_22526);
    DeRef(_new_inlined_new_at_2_22527);
    _new_inlined_new_at_2_22527 = _new_stack_inlined_new_at_2_22526;
    DeRef(_new_stack_inlined_new_at_2_22526);
    _new_stack_inlined_new_at_2_22526 = NOVALUE;
    DeRef(_new_1__tmp_at2_22528);
    _new_1__tmp_at2_22528 = NOVALUE;
    DeRef(_a_22524);
    return _new_inlined_new_at_2_22527;
    ;
}


int _2stack_size(int _a_22531)
{
    int _size_2__tmp_at2_22535 = NOVALUE;
    int _size_1__tmp_at2_22534 = NOVALUE;
    int _size_inlined_size_at_2_22533 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stack:size(a)*/

    /** 	return length(eumem:ram_space[sk][data])*/
    DeRef(_size_1__tmp_at2_22534);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_a_22531)){
        _size_1__tmp_at2_22534 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_22531)->dbl));
    }
    else{
        _size_1__tmp_at2_22534 = (int)*(((s1_ptr)_2)->base + _a_22531);
    }
    Ref(_size_1__tmp_at2_22534);
    DeRef(_size_2__tmp_at2_22535);
    _2 = (int)SEQ_PTR(_size_1__tmp_at2_22534);
    _size_2__tmp_at2_22535 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_size_2__tmp_at2_22535);
    if (IS_SEQUENCE(_size_2__tmp_at2_22535)){
            _size_inlined_size_at_2_22533 = SEQ_PTR(_size_2__tmp_at2_22535)->length;
    }
    else {
        _size_inlined_size_at_2_22533 = 1;
    }
    DeRef(_size_1__tmp_at2_22534);
    _size_1__tmp_at2_22534 = NOVALUE;
    DeRef(_size_2__tmp_at2_22535);
    _size_2__tmp_at2_22535 = NOVALUE;
    DeRef(_a_22531);
    return _size_inlined_size_at_2_22533;
    ;
}


void _2stack_set(int _a_22538, int _b_22539, int _c_22540)
{
    int _0, _1, _2;
    

    /** 	stack:set(a,b,c)*/
    Ref(_a_22538);
    Ref(_b_22539);
    Ref(_c_22540);
    _50set(_a_22538, _b_22539, _c_22540);

    /** end procedure*/
    DeRef(_a_22538);
    DeRef(_b_22539);
    DeRef(_c_22540);
    return;
    ;
}


void _2stack_clear(int _a_22543)
{
    int _clear_2__tmp_at2_22546 = NOVALUE;
    int _clear_1__tmp_at2_22545 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	stack:clear(a)*/

    /** 	eumem:ram_space[sk][data] = {}*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_a_22543))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_a_22543)->dbl));
    else
    _3 = (int)(_a_22543 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** end procedure*/
    goto L1; // [18] 21
L1: 

    /** end procedure*/
    DeRef(_a_22543);
    return;
    ;
}


int _2stats_sum(int _a_22549, int _b_22550)
{
    int _12595 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stats:sum(a, b)*/
    Ref(_a_22549);
    Ref(_b_22550);
    _12595 = _35sum(_a_22549, _b_22550);
    DeRef(_a_22549);
    DeRef(_b_22550);
    return _12595;
    ;
}


int _2text_format(int _a_22567, int _b_22568)
{
    int _12601 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:format(a, b)*/
    Ref(_a_22567);
    Ref(_b_22568);
    _12601 = _6format(_a_22567, _b_22568);
    DeRef(_a_22567);
    DeRef(_b_22568);
    return _12601;
    ;
}


int _2text_wrap(int _a_22572, int _b_22573, int _c_22574, int _d_22575)
{
    int _12602 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:wrap(a,b,c,d)*/
    Ref(_a_22572);
    Ref(_b_22573);
    Ref(_c_22574);
    Ref(_d_22575);
    _12602 = _6wrap(_a_22572, _b_22573, _c_22574, _d_22575);
    DeRef(_a_22572);
    DeRef(_b_22573);
    DeRef(_c_22574);
    DeRef(_d_22575);
    return _12602;
    ;
}


int _2text_escape(int _a_22579, int _b_22580)
{
    int _12603 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return text:escape(a,b)*/
    Ref(_a_22579);
    Ref(_b_22580);
    _12603 = _6escape(_a_22579, _b_22580);
    DeRef(_a_22579);
    DeRef(_b_22580);
    return _12603;
    ;
}


int _2wildcard_is_match(int _a_22599, int _b_22600)
{
    int _12604 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return wildcard:is_match(a,b)*/
    Ref(_a_22599);
    Ref(_b_22600);
    _12604 = _25is_match(_a_22599, _b_22600);
    DeRef(_a_22599);
    DeRef(_b_22600);
    return _12604;
    ;
}


int _2url_parse(int _a_23318, int _b_23319)
{
    int _12991 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:parse(a,b)*/
    Ref(_a_23318);
    Ref(_b_23319);
    _12991 = _55parse(_a_23318, _b_23319);
    DeRef(_a_23318);
    DeRef(_b_23319);
    return _12991;
    ;
}


int _2url_encode(int _a_23323, int _b_23324)
{
    int _12992 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:encode(a,b)*/
    Ref(_a_23323);
    Ref(_b_23324);
    _12992 = _55encode(_a_23323, _b_23324);
    DeRef(_a_23323);
    DeRef(_b_23324);
    return _12992;
    ;
}


int _2url_decode(int _a_23328)
{
    int _12993 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return url:decode(a)*/
    Ref(_a_23328);
    _12993 = _55decode(_a_23328);
    DeRef(_a_23328);
    return _12993;
    ;
}


int _2lib_call_func(int _a_23426, int _b_23427)
{
    int _13020 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eu:call_func(a,b)*/
    _1 = (int)SEQ_PTR(_b_23427);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_a_23426].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            _1 = (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }
    _13020 = _1;
    DeRef(_a_23426);
    DeRef(_b_23427);
    return _13020;
    ;
}


void _2lib_call_proc(int _a_23431, int _b_23432)
{
    int _0, _1, _2;
    

    /** 	eu:call_proc(a,b)*/
    _1 = (int)SEQ_PTR(_b_23432);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_a_23431].addr;
    switch(((s1_ptr)_1)->length) {
        case 0:
            (*(int (*)())_0)(
                                 );
            break;
        case 1:
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            break;
        case 2:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            break;
        case 3:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            break;
        case 4:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16)
                                 );
            break;
        case 5:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20)
                                 );
            break;
        case 6:
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            Ref(*(int *)(_2+16));
            Ref(*(int *)(_2+20));
            Ref(*(int *)(_2+24));
            (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12), 
                                *(int *)(_2+16), 
                                *(int *)(_2+20), 
                                *(int *)(_2+24)
                                 );
            break;
    }

    /** end procedure*/
    DeRef(_a_23431);
    DeRef(_b_23432);
    return;
    ;
}


int _2lib_routine_id(int _a_23435)
{
    int _13021 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return eu:routine_id(a)*/
    _13021 = CRoutineId(814, 2, _a_23435);
    DeRefDS(_a_23435);
    return _13021;
    ;
}



// 0x1C08FF82
