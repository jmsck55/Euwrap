// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _32has_console()
{
    int _8052 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    _8052 = machine(99, 0);
    return _8052;
    ;
}


int _32key_codes(int _codes_14206)
{
    int _8053 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_KEY_CODES, codes)*/
    _8053 = machine(100, _codes_14206);
    DeRef(_codes_14206);
    return _8053;
    ;
}
int key_codes() __attribute__ ((alias ("_32key_codes")));


int _32set_keycodes(int _kcfile_14523)
{
    int _m_14524 = NOVALUE;
    int _kcv_14525 = NOVALUE;
    int _kc_14526 = NOVALUE;
    int _keyname_14527 = NOVALUE;
    int _keycode_14528 = NOVALUE;
    int _key_codes_inlined_key_codes_at_34_14536 = NOVALUE;
    int _key_codes_inlined_key_codes_at_2013_14822 = NOVALUE;
    int _8242 = NOVALUE;
    int _8240 = NOVALUE;
    int _8239 = NOVALUE;
    int _8238 = NOVALUE;
    int _8237 = NOVALUE;
    int _8236 = NOVALUE;
    int _8235 = NOVALUE;
    int _8232 = NOVALUE;
    int _0, _1, _2;
    

    /** 	m = map:load_map(kcfile)*/
    Ref(_kcfile_14523);
    _0 = _m_14524;
    _m_14524 = _33load_map(_kcfile_14523);
    DeRef(_0);

    /** 	if not map(m) then*/
    Ref(_m_14524);
    _8232 = _33map(_m_14524);
    if (IS_ATOM_INT(_8232)) {
        if (_8232 != 0){
            DeRef(_8232);
            _8232 = NOVALUE;
            goto L1; // [13] 23
        }
    }
    else {
        if (DBL_PTR(_8232)->dbl != 0.0){
            DeRef(_8232);
            _8232 = NOVALUE;
            goto L1; // [13] 23
        }
    }
    DeRef(_8232);
    _8232 = NOVALUE;

    /** 		return -1 -- The file could not be loaded intoa map.*/
    DeRef(_kcfile_14523);
    DeRef(_m_14524);
    DeRef(_kcv_14525);
    DeRef(_kc_14526);
    DeRef(_keyname_14527);
    return -1;
L1: 

    /** 	kcv = map:pairs(m)*/
    Ref(_m_14524);
    _0 = _kcv_14525;
    _kcv_14525 = _33pairs(_m_14524, 0);
    DeRef(_0);

    /** 	kc = key_codes(0)*/

    /** 	return machine_func(M_KEY_CODES, codes)*/
    DeRef(_kc_14526);
    _kc_14526 = machine(100, 0);

    /** 	for i = 1 to length(kcv) do*/
    if (IS_SEQUENCE(_kcv_14525)){
            _8235 = SEQ_PTR(_kcv_14525)->length;
    }
    else {
        _8235 = 1;
    }
    {
        int _i_14538;
        _i_14538 = 1;
L2: 
        if (_i_14538 > _8235){
            goto L3; // [48] 2010
        }

        /** 		if integer(kcv[i][2]) then*/
        _2 = (int)SEQ_PTR(_kcv_14525);
        _8236 = (int)*(((s1_ptr)_2)->base + _i_14538);
        _2 = (int)SEQ_PTR(_8236);
        _8237 = (int)*(((s1_ptr)_2)->base + 2);
        _8236 = NOVALUE;
        if (IS_ATOM_INT(_8237))
        _8238 = 1;
        else if (IS_ATOM_DBL(_8237))
        _8238 = IS_ATOM_INT(DoubleToInt(_8237));
        else
        _8238 = 0;
        _8237 = NOVALUE;
        if (_8238 == 0)
        {
            _8238 = NOVALUE;
            goto L4; // [68] 1996
        }
        else{
            _8238 = NOVALUE;
        }

        /** 			keyname = upper(kcv[i][1])*/
        _2 = (int)SEQ_PTR(_kcv_14525);
        _8239 = (int)*(((s1_ptr)_2)->base + _i_14538);
        _2 = (int)SEQ_PTR(_8239);
        _8240 = (int)*(((s1_ptr)_2)->base + 1);
        _8239 = NOVALUE;
        Ref(_8240);
        _0 = _keyname_14527;
        _keyname_14527 = _6upper(_8240);
        DeRef(_0);
        _8240 = NOVALUE;

        /** 			keycode = kcv[i][2]*/
        _2 = (int)SEQ_PTR(_kcv_14525);
        _8242 = (int)*(((s1_ptr)_2)->base + _i_14538);
        _2 = (int)SEQ_PTR(_8242);
        _keycode_14528 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_keycode_14528)){
            _keycode_14528 = (long)DBL_PTR(_keycode_14528)->dbl;
        }
        _8242 = NOVALUE;

        /** 			switch keyname do*/
        _1 = find(_keyname_14527, _8244);
        switch ( _1 ){ 

            /** 				case "LBUTTON" then*/
            case 1:

            /** 					kc[KC_LBUTTON] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [118] 2003

            /** 				case "RBUTTON" then*/
            case 2:

            /** 					kc[KC_RBUTTON] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 3);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [132] 2003

            /** 				case "CANCEL" then*/
            case 3:

            /** 					kc[KC_CANCEL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 4);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [146] 2003

            /** 				case "MBUTTON" then*/
            case 4:

            /** 					kc[KC_MBUTTON] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 5);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [160] 2003

            /** 				case "XBUTTON1" then*/
            case 5:

            /** 					kc[KC_XBUTTON1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 6);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [174] 2003

            /** 				case "XBUTTON2" then*/
            case 6:

            /** 					kc[KC_XBUTTON2] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 7);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [188] 2003

            /** 				case "BACK" then*/
            case 7:

            /** 					kc[KC_BACK] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 9);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [202] 2003

            /** 				case "TAB" then*/
            case 8:

            /** 					kc[KC_TAB] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 10);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [216] 2003

            /** 				case "CLEAR" then*/
            case 9:

            /** 					kc[KC_CLEAR] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 13);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [230] 2003

            /** 				case "RETURN" then*/
            case 10:

            /** 					kc[KC_RETURN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 14);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [244] 2003

            /** 				case "SHIFT" then*/
            case 11:

            /** 					kc[KC_SHIFT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 17);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [258] 2003

            /** 				case "CONTROL" then*/
            case 12:

            /** 					kc[KC_CONTROL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 18);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [272] 2003

            /** 				case "MENU" then*/
            case 13:

            /** 					kc[KC_MENU] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 19);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [286] 2003

            /** 				case "PAUSE" then*/
            case 14:

            /** 					kc[KC_PAUSE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 20);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [300] 2003

            /** 				case "CAPITAL" then*/
            case 15:

            /** 					kc[KC_CAPITAL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 21);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [314] 2003

            /** 				case "KANA" then*/
            case 16:

            /** 					kc[KC_KANA] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 22);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [328] 2003

            /** 				case "JUNJA" then*/
            case 17:

            /** 					kc[KC_JUNJA] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 24);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [342] 2003

            /** 				case "FINAL" then*/
            case 18:

            /** 					kc[KC_FINAL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 25);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [356] 2003

            /** 				case "HANJA" then*/
            case 19:

            /** 					kc[KC_HANJA] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 26);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [370] 2003

            /** 				case "ESCAPE" then*/
            case 20:

            /** 					kc[KC_ESCAPE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 28);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [384] 2003

            /** 				case "CONVERT" then*/
            case 21:

            /** 					kc[KC_CONVERT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 29);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [398] 2003

            /** 				case "NONCONVERT" then*/
            case 22:

            /** 					kc[KC_NONCONVERT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 30);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [412] 2003

            /** 				case "ACCEPT" then*/
            case 23:

            /** 					kc[KC_ACCEPT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 31);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [426] 2003

            /** 				case "MODECHANGE" then*/
            case 24:

            /** 					kc[KC_MODECHANGE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 32);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [440] 2003

            /** 				case "SPACE" then*/
            case 25:

            /** 					kc[KC_SPACE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 33);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [454] 2003

            /** 				case "PRIOR" then*/
            case 26:

            /** 					kc[KC_PRIOR] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 34);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [468] 2003

            /** 				case "NEXT" then*/
            case 27:

            /** 					kc[KC_NEXT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 35);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [482] 2003

            /** 				case "END" then*/
            case 28:

            /** 					kc[KC_END] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 36);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [496] 2003

            /** 				case "HOME" then*/
            case 29:

            /** 					kc[KC_HOME] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 37);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [510] 2003

            /** 				case "LEFT" then*/
            case 30:

            /** 					kc[KC_LEFT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 38);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [524] 2003

            /** 				case "UP" then*/
            case 31:

            /** 					kc[KC_UP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 39);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [538] 2003

            /** 				case "RIGHT" then*/
            case 32:

            /** 					kc[KC_RIGHT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 40);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [552] 2003

            /** 				case "DOWN" then*/
            case 33:

            /** 					kc[KC_DOWN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 41);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [566] 2003

            /** 				case "SELECT" then*/
            case 34:

            /** 					kc[KC_SELECT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 42);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [580] 2003

            /** 				case "PRINT" then*/
            case 35:

            /** 					kc[KC_PRINT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 43);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [594] 2003

            /** 				case "EXECUTE" then*/
            case 36:

            /** 					kc[KC_EXECUTE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 44);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [608] 2003

            /** 				case "SNAPSHOT" then*/
            case 37:

            /** 					kc[KC_SNAPSHOT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 45);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [622] 2003

            /** 				case "INSERT" then*/
            case 38:

            /** 					kc[KC_INSERT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 46);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [636] 2003

            /** 				case "DELETE" then*/
            case 39:

            /** 					kc[KC_DELETE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 47);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [650] 2003

            /** 				case "HELP" then*/
            case 40:

            /** 					kc[KC_HELP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 48);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [664] 2003

            /** 				case "LWIN" then*/
            case 41:

            /** 					kc[KC_LWIN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 92);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [678] 2003

            /** 				case "RWIN" then*/
            case 42:

            /** 					kc[KC_RWIN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 93);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [692] 2003

            /** 				case "APPS" then*/
            case 43:

            /** 					kc[KC_APPS] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 94);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [706] 2003

            /** 				case "SLEEP" then*/
            case 44:

            /** 					kc[KC_SLEEP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 96);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [720] 2003

            /** 				case "NUMPAD0" then*/
            case 45:

            /** 					kc[KC_NUMPAD0] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 97);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [734] 2003

            /** 				case "NUMPAD1" then*/
            case 46:

            /** 					kc[KC_NUMPAD1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 98);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [748] 2003

            /** 				case "NUMPAD2" then*/
            case 47:

            /** 					kc[KC_NUMPAD2] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 99);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [762] 2003

            /** 				case "NUMPAD3" then*/
            case 48:

            /** 					kc[KC_NUMPAD3] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 100);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [776] 2003

            /** 				case "NUMPAD4" then*/
            case 49:

            /** 					kc[KC_NUMPAD4] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 101);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [790] 2003

            /** 				case "NUMPAD5" then*/
            case 50:

            /** 					kc[KC_NUMPAD5] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 102);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [804] 2003

            /** 				case "NUMPAD6" then*/
            case 51:

            /** 					kc[KC_NUMPAD6] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 103);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [818] 2003

            /** 				case "NUMPAD7" then*/
            case 52:

            /** 					kc[KC_NUMPAD7] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 104);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [832] 2003

            /** 				case "NUMPAD8" then*/
            case 53:

            /** 					kc[KC_NUMPAD8] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 105);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [846] 2003

            /** 				case "NUMPAD9" then*/
            case 54:

            /** 					kc[KC_NUMPAD9] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 106);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [860] 2003

            /** 				case "MULTIPLY" then*/
            case 55:

            /** 					kc[KC_MULTIPLY] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 107);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [874] 2003

            /** 				case "ADD" then*/
            case 56:

            /** 					kc[KC_ADD] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 108);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [888] 2003

            /** 				case "SEPARATOR" then*/
            case 57:

            /** 					kc[KC_SEPARATOR] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 109);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [902] 2003

            /** 				case "SUBTRACT" then*/
            case 58:

            /** 					kc[KC_SUBTRACT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 110);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [916] 2003

            /** 				case "DECIMAL" then*/
            case 59:

            /** 					kc[KC_DECIMAL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 111);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [930] 2003

            /** 				case "DIVIDE" then*/
            case 60:

            /** 					kc[KC_DIVIDE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 112);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [944] 2003

            /** 				case "F1" then*/
            case 61:

            /** 					kc[KC_F1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 113);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [958] 2003

            /** 				case "F2" then*/
            case 62:

            /** 					kc[KC_F2] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 114);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [972] 2003

            /** 				case "F3" then*/
            case 63:

            /** 					kc[KC_F3] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 115);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [986] 2003

            /** 				case "F4" then*/
            case 64:

            /** 					kc[KC_F4] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 116);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1000] 2003

            /** 				case "F5" then*/
            case 65:

            /** 					kc[KC_F5] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 117);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1014] 2003

            /** 				case "F6" then*/
            case 66:

            /** 					kc[KC_F6] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 118);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1028] 2003

            /** 				case "F7" then*/
            case 67:

            /** 					kc[KC_F7] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 119);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1042] 2003

            /** 				case "F8" then*/
            case 68:

            /** 					kc[KC_F8] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 120);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1056] 2003

            /** 				case "F9" then*/
            case 69:

            /** 					kc[KC_F9] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 121);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1070] 2003

            /** 				case "F10" then*/
            case 70:

            /** 					kc[KC_F10] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 122);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1084] 2003

            /** 				case "F11" then*/
            case 71:

            /** 					kc[KC_F11] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 123);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1098] 2003

            /** 				case "F12" then*/
            case 72:

            /** 					kc[KC_F12] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 124);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1112] 2003

            /** 				case "F13" then*/
            case 73:

            /** 					kc[KC_F13] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 125);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1126] 2003

            /** 				case "F14" then*/
            case 74:

            /** 					kc[KC_F14] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 126);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1140] 2003

            /** 				case "F15" then*/
            case 75:

            /** 					kc[KC_F15] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 127);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1154] 2003

            /** 				case "F16" then*/
            case 76:

            /** 					kc[KC_F16] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 128);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1168] 2003

            /** 				case "F17" then*/
            case 77:

            /** 					kc[KC_F17] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 129);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1182] 2003

            /** 				case "F18" then*/
            case 78:

            /** 					kc[KC_F18] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 130);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1196] 2003

            /** 				case "F19" then*/
            case 79:

            /** 					kc[KC_F19] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 131);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1210] 2003

            /** 				case "F20" then*/
            case 80:

            /** 					kc[KC_F20] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 132);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1224] 2003

            /** 				case "F21" then*/
            case 81:

            /** 					kc[KC_F21] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 133);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1238] 2003

            /** 				case "F22" then*/
            case 82:

            /** 					kc[KC_F22] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 134);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1252] 2003

            /** 				case "F23" then*/
            case 83:

            /** 					kc[KC_F23] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 135);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1266] 2003

            /** 				case "F24" then*/
            case 84:

            /** 					kc[KC_F24] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 136);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1280] 2003

            /** 				case "NUMLOCK" then*/
            case 85:

            /** 					kc[KC_NUMLOCK] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 145);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1294] 2003

            /** 				case "SCROLL" then*/
            case 86:

            /** 					kc[KC_SCROLL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 146);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1308] 2003

            /** 				case "LSHIFT" then*/
            case 87:

            /** 					kc[KC_LSHIFT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 161);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1322] 2003

            /** 				case "RSHIFT" then*/
            case 88:

            /** 					kc[KC_RSHIFT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 162);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1336] 2003

            /** 				case "LCONTROL" then*/
            case 89:

            /** 					kc[KC_LCONTROL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 163);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1350] 2003

            /** 				case "RCONTROL" then*/
            case 90:

            /** 					kc[KC_RCONTROL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 164);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1364] 2003

            /** 				case "LMENU" then*/
            case 91:

            /** 					kc[KC_LMENU] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 165);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1378] 2003

            /** 				case "RMENU" then*/
            case 92:

            /** 					kc[KC_RMENU] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 166);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1392] 2003

            /** 				case "BROWSER_BACK" then*/
            case 93:

            /** 					kc[KC_BROWSER_BACK] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 167);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1406] 2003

            /** 				case "BROWSER_FORWARD" then*/
            case 94:

            /** 					kc[KC_BROWSER_FORWARD] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 168);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1420] 2003

            /** 				case "BROWSER_REFRESH" then*/
            case 95:

            /** 					kc[KC_BROWSER_REFRESH] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 169);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1434] 2003

            /** 				case "BROWSER_STOP" then*/
            case 96:

            /** 					kc[KC_BROWSER_STOP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 170);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1448] 2003

            /** 				case "BROWSER_SEARCH" then*/
            case 97:

            /** 					kc[KC_BROWSER_SEARCH] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 171);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1462] 2003

            /** 				case "BROWSER_FAVORITES" then*/
            case 98:

            /** 					kc[KC_BROWSER_FAVORITES] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 172);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1476] 2003

            /** 				case "BROWSER_HOME" then*/
            case 99:

            /** 					kc[KC_BROWSER_HOME] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 173);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1490] 2003

            /** 				case "VOLUME_MUTE" then*/
            case 100:

            /** 					kc[KC_VOLUME_MUTE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 174);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1504] 2003

            /** 				case "VOLUME_DOWN" then*/
            case 101:

            /** 					kc[KC_VOLUME_DOWN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 175);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1518] 2003

            /** 				case "VOLUME_UP" then*/
            case 102:

            /** 					kc[KC_VOLUME_UP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 176);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1532] 2003

            /** 				case "MEDIA_NEXT_TRACK" then*/
            case 103:

            /** 					kc[KC_MEDIA_NEXT_TRACK] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 177);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1546] 2003

            /** 				case "MEDIA_PREV_TRACK" then*/
            case 104:

            /** 					kc[KC_MEDIA_PREV_TRACK] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 178);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1560] 2003

            /** 				case "MEDIA_STOP" then*/
            case 105:

            /** 					kc[KC_MEDIA_STOP] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 179);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1574] 2003

            /** 				case "MEDIA_PLAY_PAUSE" then*/
            case 106:

            /** 					kc[KC_MEDIA_PLAY_PAUSE] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 180);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1588] 2003

            /** 				case "LAUNCH_MAIL" then*/
            case 107:

            /** 					kc[KC_LAUNCH_MAIL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 181);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1602] 2003

            /** 				case "LAUNCH_MEDIA_SELECT" then*/
            case 108:

            /** 					kc[KC_LAUNCH_MEDIA_SELECT] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 182);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1616] 2003

            /** 				case "LAUNCH_APP1" then*/
            case 109:

            /** 					kc[KC_LAUNCH_APP1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 183);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1630] 2003

            /** 				case "LAUNCH_APP2" then*/
            case 110:

            /** 					kc[KC_LAUNCH_APP2] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 184);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1644] 2003

            /** 				case "OEM_1" then*/
            case 111:

            /** 					kc[KC_OEM_1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 187);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1658] 2003

            /** 				case "OEM_PLUS" then*/
            case 112:

            /** 					kc[KC_OEM_PLUS] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 188);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1672] 2003

            /** 				case "OEM_COMMA" then*/
            case 113:

            /** 					kc[KC_OEM_COMMA] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 189);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1686] 2003

            /** 				case "OEM_MINUS" then*/
            case 114:

            /** 					kc[KC_OEM_MINUS] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 190);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1700] 2003

            /** 				case "OEM_PERIOD" then*/
            case 115:

            /** 					kc[KC_OEM_PERIOD] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 191);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1714] 2003

            /** 				case "OEM_2" then*/
            case 116:

            /** 					kc[KC_OEM_2] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 192);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1728] 2003

            /** 				case "OEM_3" then*/
            case 117:

            /** 					kc[KC_OEM_3] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 193);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1742] 2003

            /** 				case "OEM_4" then*/
            case 118:

            /** 					kc[KC_OEM_4] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 220);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1756] 2003

            /** 				case "OEM_5" then*/
            case 119:

            /** 					kc[KC_OEM_5] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 221);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1770] 2003

            /** 				case "OEM_6" then*/
            case 120:

            /** 					kc[KC_OEM_6] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 222);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1784] 2003

            /** 				case "OEM_7" then*/
            case 121:

            /** 					kc[KC_OEM_7] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 223);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1798] 2003

            /** 				case "OEM_8" then*/
            case 122:

            /** 					kc[KC_OEM_8] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 224);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1812] 2003

            /** 				case "OEM_102" then*/
            case 123:

            /** 					kc[KC_OEM_102] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 227);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1826] 2003

            /** 				case "PROCESSKEY" then*/
            case 124:

            /** 					kc[KC_PROCESSKEY] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 230);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1840] 2003

            /** 				case "PACKET" then*/
            case 125:

            /** 					kc[KC_PACKET] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 232);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1854] 2003

            /** 				case "ATTN" then*/
            case 126:

            /** 					kc[KC_ATTN] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 247);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1868] 2003

            /** 				case "CRSEL" then*/
            case 127:

            /** 					kc[KC_CRSEL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 248);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1882] 2003

            /** 				case "EXSEL" then*/
            case 128:

            /** 					kc[KC_EXSEL] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 249);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1896] 2003

            /** 				case "EREOF" then*/
            case 129:

            /** 					kc[KC_EREOF] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 250);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1910] 2003

            /** 				case "PLAY" then*/
            case 130:

            /** 					kc[KC_PLAY] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 251);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1924] 2003

            /** 				case "ZOOM" then*/
            case 131:

            /** 					kc[KC_ZOOM] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 252);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1938] 2003

            /** 				case "NONAME" then*/
            case 132:

            /** 					kc[KC_NONAME] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 253);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1952] 2003

            /** 				case "PA1" then*/
            case 133:

            /** 					kc[KC_PA1] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 254);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1966] 2003

            /** 				case "OEM_CLEAR" then*/
            case 134:

            /** 					kc[KC_OEM_CLEAR] = keycode*/
            _2 = (int)SEQ_PTR(_kc_14526);
            _2 = (int)(((s1_ptr)_2)->base + 255);
            _1 = *(int *)_2;
            *(int *)_2 = _keycode_14528;
            DeRef(_1);
            goto L5; // [1980] 2003

            /** 				case else*/
            case 0:

            /** 					return -3 -- Unknown keyname used.*/
            DeRef(_kcfile_14523);
            DeRef(_m_14524);
            DeRef(_kcv_14525);
            DeRef(_kc_14526);
            DeRef(_keyname_14527);
            return -3;
        ;}        goto L5; // [1993] 2003
L4: 

        /** 			return -2 -- New key value is not an integer*/
        DeRef(_kcfile_14523);
        DeRef(_m_14524);
        DeRef(_kcv_14525);
        DeRef(_kc_14526);
        DeRef(_keyname_14527);
        return -2;
L5: 

        /** 	end for*/
        _i_14538 = _i_14538 + 1;
        goto L2; // [2005] 55
L3: 
        ;
    }

    /** 	key_codes(kc)*/

    /** 	return machine_func(M_KEY_CODES, codes)*/
    DeRef(_key_codes_inlined_key_codes_at_2013_14822);
    _key_codes_inlined_key_codes_at_2013_14822 = machine(100, _kc_14526);

    /**   return 0 -- All done okay*/
    DeRef(_kcfile_14523);
    DeRef(_m_14524);
    DeRef(_kcv_14525);
    DeRef(_kc_14526);
    DeRef(_keyname_14527);
    return 0;
    ;
}
int set_keycodes() __attribute__ ((alias ("_32set_keycodes")));


void _32allow_break(int _b_14833)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_ALLOW_BREAK, b)*/
    machine(42, _b_14833);

    /** end procedure*/
    DeRef(_b_14833);
    return;
    ;
}


int _32check_break()
{
    int _8382 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHECK_BREAK, 0)*/
    _8382 = machine(43, 0);
    return _8382;
    ;
}
int check_break() __attribute__ ((alias ("_32check_break")));


int _32wait_key()
{
    int _8383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WAIT_KEY, 0)*/
    _8383 = machine(26, 0);
    return _8383;
    ;
}
int wait_key() __attribute__ ((alias ("_32wait_key")));


void _32any_key(int _prompt_14842, int _con_14844)
{
    int _wait_key_inlined_wait_key_at_27_14849 = NOVALUE;
    int _8385 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_con_14844)) {
        _1 = (long)(DBL_PTR(_con_14844)->dbl);
        DeRefDS(_con_14844);
        _con_14844 = _1;
    }

    /** 	if not find(con, {1,2}) then*/
    _8385 = find_from(_con_14844, _7917, 1);
    if (_8385 != 0)
    goto L1; // [12] 21
    _8385 = NOVALUE;

    /** 		con = 1*/
    _con_14844 = 1;
L1: 

    /** 	puts(con, prompt)*/
    EPuts(_con_14844, _prompt_14842); // DJP 

    /** 	wait_key()*/

    /** 	return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14849 = machine(26, 0);

    /** 	puts(con, "\n")*/
    EPuts(_con_14844, _1297); // DJP 

    /** end procedure*/
    DeRefDS(_prompt_14842);
    return;
    ;
}
void any_key() __attribute__ ((alias ("_32any_key")));


void _32maybe_any_key(int _prompt_14852, int _con_14853)
{
    int _has_console_inlined_has_console_at_6_14856 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_con_14853)) {
        _1 = (long)(DBL_PTR(_con_14853)->dbl);
        DeRefDS(_con_14853);
        _con_14853 = _1;
    }

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14856);
    _has_console_inlined_has_console_at_6_14856 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14856)) {
        if (_has_console_inlined_has_console_at_6_14856 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14856)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_prompt_14852);
    _32any_key(_prompt_14852, _con_14853);
L1: 

    /** end procedure*/
    DeRefDS(_prompt_14852);
    return;
    ;
}
void maybe_any_key() __attribute__ ((alias ("_32maybe_any_key")));


int _32prompt_number(int _prompt_14860, int _range_14861)
{
    int _answer_14862 = NOVALUE;
    int _value_inlined_value_at_28_14866 = NOVALUE;
    int _8406 = NOVALUE;
    int _8404 = NOVALUE;
    int _8403 = NOVALUE;
    int _8402 = NOVALUE;
    int _8401 = NOVALUE;
    int _8400 = NOVALUE;
    int _8399 = NOVALUE;
    int _8398 = NOVALUE;
    int _8397 = NOVALUE;
    int _8395 = NOVALUE;
    int _8393 = NOVALUE;
    int _8392 = NOVALUE;
    int _8390 = NOVALUE;
    int _8389 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while 1 do*/
L1: 

    /** 		 puts(1, prompt)*/
    EPuts(1, _prompt_14860); // DJP 

    /** 		 answer = gets(0) -- make sure whole line is read*/
    DeRef(_answer_14862);
    _answer_14862 = EGets(0);

    /** 		 puts(1, '\n')*/
    EPuts(1, 10); // DJP 

    /** 		 answer = stdget:value(answer)*/
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    Ref(_answer_14862);
    _0 = _answer_14862;
    _answer_14862 = _17get_value(_answer_14862, 1, _17GET_SHORT_ANSWER_3238);
    DeRefi(_0);

    /** 		 if answer[1] != stdget:GET_SUCCESS or sequence(answer[2]) then*/
    _2 = (int)SEQ_PTR(_answer_14862);
    _8389 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8389)) {
        _8390 = (_8389 != 0);
    }
    else {
        _8390 = binary_op(NOTEQ, _8389, 0);
    }
    _8389 = NOVALUE;
    if (IS_ATOM_INT(_8390)) {
        if (_8390 != 0) {
            goto L2; // [52] 68
        }
    }
    else {
        if (DBL_PTR(_8390)->dbl != 0.0) {
            goto L2; // [52] 68
        }
    }
    _2 = (int)SEQ_PTR(_answer_14862);
    _8392 = (int)*(((s1_ptr)_2)->base + 2);
    _8393 = IS_SEQUENCE(_8392);
    _8392 = NOVALUE;
    if (_8393 == 0)
    {
        _8393 = NOVALUE;
        goto L3; // [64] 76
    }
    else{
        _8393 = NOVALUE;
    }
L2: 

    /** 			  puts(1, "A number is expected - try again\n")*/
    EPuts(1, _8394); // DJP 
    goto L1; // [73] 10
L3: 

    /** 			 if length(range) = 2 then*/
    if (IS_SEQUENCE(_range_14861)){
            _8395 = SEQ_PTR(_range_14861)->length;
    }
    else {
        _8395 = 1;
    }
    if (_8395 != 2)
    goto L4; // [81] 142

    /** 				  if range[1] <= answer[2] and answer[2] <= range[2] then*/
    _2 = (int)SEQ_PTR(_range_14861);
    _8397 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_answer_14862);
    _8398 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8397) && IS_ATOM_INT(_8398)) {
        _8399 = (_8397 <= _8398);
    }
    else {
        _8399 = binary_op(LESSEQ, _8397, _8398);
    }
    _8397 = NOVALUE;
    _8398 = NOVALUE;
    if (IS_ATOM_INT(_8399)) {
        if (_8399 == 0) {
            goto L5; // [99] 132
        }
    }
    else {
        if (DBL_PTR(_8399)->dbl == 0.0) {
            goto L5; // [99] 132
        }
    }
    _2 = (int)SEQ_PTR(_answer_14862);
    _8401 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_range_14861);
    _8402 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8401) && IS_ATOM_INT(_8402)) {
        _8403 = (_8401 <= _8402);
    }
    else {
        _8403 = binary_op(LESSEQ, _8401, _8402);
    }
    _8401 = NOVALUE;
    _8402 = NOVALUE;
    if (_8403 == 0) {
        DeRef(_8403);
        _8403 = NOVALUE;
        goto L5; // [116] 132
    }
    else {
        if (!IS_ATOM_INT(_8403) && DBL_PTR(_8403)->dbl == 0.0){
            DeRef(_8403);
            _8403 = NOVALUE;
            goto L5; // [116] 132
        }
        DeRef(_8403);
        _8403 = NOVALUE;
    }
    DeRef(_8403);
    _8403 = NOVALUE;

    /** 					  return answer[2]*/
    _2 = (int)SEQ_PTR(_answer_14862);
    _8404 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8404);
    DeRefDS(_prompt_14860);
    DeRefDS(_range_14861);
    DeRef(_answer_14862);
    DeRef(_8390);
    _8390 = NOVALUE;
    DeRef(_8399);
    _8399 = NOVALUE;
    return _8404;
    goto L1; // [129] 10
L5: 

    /** 					printf(1, "A number from %g to %g is expected here - try again\n", range)*/
    EPrintf(1, _8405, _range_14861);
    goto L1; // [139] 10
L4: 

    /** 				  return answer[2]*/
    _2 = (int)SEQ_PTR(_answer_14862);
    _8406 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8406);
    DeRefDS(_prompt_14860);
    DeRefDS(_range_14861);
    DeRef(_answer_14862);
    _8404 = NOVALUE;
    DeRef(_8390);
    _8390 = NOVALUE;
    DeRef(_8399);
    _8399 = NOVALUE;
    return _8406;

    /** 	end while*/
    goto L1; // [156] 10
    ;
}
int prompt_number() __attribute__ ((alias ("_32prompt_number")));


int _32prompt_string(int _prompt_14893)
{
    int _answer_14894 = NOVALUE;
    int _8414 = NOVALUE;
    int _8413 = NOVALUE;
    int _8412 = NOVALUE;
    int _8411 = NOVALUE;
    int _8410 = NOVALUE;
    int _8409 = NOVALUE;
    int _8408 = NOVALUE;
    int _0, _1, _2;
    

    /** 	puts(1, prompt)*/
    EPuts(1, _prompt_14893); // DJP 

    /** 	answer = gets(0)*/
    DeRefi(_answer_14894);
    _answer_14894 = EGets(0);

    /** 	puts(1, '\n')*/
    EPuts(1, 10); // DJP 

    /** 	if sequence(answer) and length(answer) > 0 then*/
    _8408 = IS_SEQUENCE(_answer_14894);
    if (_8408 == 0) {
        goto L1; // [23] 59
    }
    if (IS_SEQUENCE(_answer_14894)){
            _8410 = SEQ_PTR(_answer_14894)->length;
    }
    else {
        _8410 = 1;
    }
    _8411 = (_8410 > 0);
    _8410 = NOVALUE;
    if (_8411 == 0)
    {
        DeRef(_8411);
        _8411 = NOVALUE;
        goto L1; // [35] 59
    }
    else{
        DeRef(_8411);
        _8411 = NOVALUE;
    }

    /** 		return answer[1..$-1] -- trim the \n*/
    if (IS_SEQUENCE(_answer_14894)){
            _8412 = SEQ_PTR(_answer_14894)->length;
    }
    else {
        _8412 = 1;
    }
    _8413 = _8412 - 1;
    _8412 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8414;
    RHS_Slice(_answer_14894, 1, _8413);
    DeRefDS(_prompt_14893);
    DeRefi(_answer_14894);
    _8413 = NOVALUE;
    return _8414;
    goto L2; // [56] 66
L1: 

    /** 		return ""*/
    RefDS(_5);
    DeRefDS(_prompt_14893);
    DeRefi(_answer_14894);
    DeRef(_8413);
    _8413 = NOVALUE;
    DeRef(_8414);
    _8414 = NOVALUE;
    return _5;
L2: 
    ;
}
int prompt_string() __attribute__ ((alias ("_32prompt_string")));


int _32positive_int(int _x_14930)
{
    int _8434 = NOVALUE;
    int _8433 = NOVALUE;
    int _8432 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) and x >= 1 then*/
    if (IS_ATOM_INT(_x_14930))
    _8432 = 1;
    else if (IS_ATOM_DBL(_x_14930))
    _8432 = IS_ATOM_INT(DoubleToInt(_x_14930));
    else
    _8432 = 0;
    if (_8432 == 0) {
        goto L1; // [6] 27
    }
    if (IS_ATOM_INT(_x_14930)) {
        _8434 = (_x_14930 >= 1);
    }
    else {
        _8434 = binary_op(GREATEREQ, _x_14930, 1);
    }
    if (_8434 == 0) {
        DeRef(_8434);
        _8434 = NOVALUE;
        goto L1; // [15] 27
    }
    else {
        if (!IS_ATOM_INT(_8434) && DBL_PTR(_8434)->dbl == 0.0){
            DeRef(_8434);
            _8434 = NOVALUE;
            goto L1; // [15] 27
        }
        DeRef(_8434);
        _8434 = NOVALUE;
    }
    DeRef(_8434);
    _8434 = NOVALUE;

    /** 		return 1*/
    DeRef(_x_14930);
    return 1;
    goto L2; // [24] 34
L1: 

    /** 		return 0*/
    DeRef(_x_14930);
    return 0;
L2: 
    ;
}
int positive_int() __attribute__ ((alias ("_32positive_int")));


int _32get_screen_char(int _line_14938, int _column_14939, int _fgbg_14940)
{
    int _ca_14941 = NOVALUE;
    int _8442 = NOVALUE;
    int _8441 = NOVALUE;
    int _8440 = NOVALUE;
    int _8439 = NOVALUE;
    int _8438 = NOVALUE;
    int _8437 = NOVALUE;
    int _8435 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fgbg_14940)) {
        _1 = (long)(DBL_PTR(_fgbg_14940)->dbl);
        DeRefDS(_fgbg_14940);
        _fgbg_14940 = _1;
    }

    /** 	ca = machine_func(M_GET_SCREEN_CHAR, {line, column})*/
    Ref(_column_14939);
    Ref(_line_14938);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _line_14938;
    ((int *)_2)[2] = _column_14939;
    _8435 = MAKE_SEQ(_1);
    DeRef(_ca_14941);
    _ca_14941 = machine(58, _8435);
    DeRefDS(_8435);
    _8435 = NOVALUE;

    /** 	if fgbg then*/
    if (_fgbg_14940 == 0)
    {
        goto L1; // [17] 51
    }
    else{
    }

    /** 		ca = ca[1] & and_bits({ca[2], ca[2]/16}, 0x0F)*/
    _2 = (int)SEQ_PTR(_ca_14941);
    _8437 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ca_14941);
    _8438 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_ca_14941);
    _8439 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8439)) {
        _8440 = (_8439 % 16) ? NewDouble((double)_8439 / 16) : (_8439 / 16);
    }
    else {
        _8440 = binary_op(DIVIDE, _8439, 16);
    }
    _8439 = NOVALUE;
    Ref(_8438);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _8438;
    ((int *)_2)[2] = _8440;
    _8441 = MAKE_SEQ(_1);
    _8440 = NOVALUE;
    _8438 = NOVALUE;
    _8442 = binary_op(AND_BITS, _8441, 15);
    DeRefDS(_8441);
    _8441 = NOVALUE;
    if (IS_SEQUENCE(_8437) && IS_ATOM(_8442)) {
    }
    else if (IS_ATOM(_8437) && IS_SEQUENCE(_8442)) {
        Ref(_8437);
        Prepend(&_ca_14941, _8442, _8437);
    }
    else {
        Concat((object_ptr)&_ca_14941, _8437, _8442);
        _8437 = NOVALUE;
    }
    _8437 = NOVALUE;
    DeRefDS(_8442);
    _8442 = NOVALUE;
L1: 

    /** 	return ca*/
    DeRef(_line_14938);
    DeRef(_column_14939);
    return _ca_14941;
    ;
}
int get_screen_char() __attribute__ ((alias ("_32get_screen_char")));


void _32put_screen_char(int _line_14954, int _column_14955, int _char_attr_14956)
{
    int _8444 = NOVALUE;
    int _0, _1, _2;
    

    /** 	machine_proc(M_PUT_SCREEN_CHAR, {line, column, char_attr})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_line_14954);
    *((int *)(_2+4)) = _line_14954;
    Ref(_column_14955);
    *((int *)(_2+8)) = _column_14955;
    RefDS(_char_attr_14956);
    *((int *)(_2+12)) = _char_attr_14956;
    _8444 = MAKE_SEQ(_1);
    machine(59, _8444);
    DeRefDS(_8444);
    _8444 = NOVALUE;

    /** end procedure*/
    DeRef(_line_14954);
    DeRef(_column_14955);
    DeRefDS(_char_attr_14956);
    return;
    ;
}
void put_screen_char() __attribute__ ((alias ("_32put_screen_char")));


int _32attr_to_colors(int _attr_code_14960)
{
    int _fgbg_14961 = NOVALUE;
    int _8454 = NOVALUE;
    int _8453 = NOVALUE;
    int _8452 = NOVALUE;
    int _8451 = NOVALUE;
    int _8450 = NOVALUE;
    int _8449 = NOVALUE;
    int _8448 = NOVALUE;
    int _8446 = NOVALUE;
    int _8445 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_attr_code_14960)) {
        _1 = (long)(DBL_PTR(_attr_code_14960)->dbl);
        DeRefDS(_attr_code_14960);
        _attr_code_14960 = _1;
    }

    /**     sequence fgbg = and_bits({attr_code, attr_code/16}, 0x0F)*/
    _8445 = (_attr_code_14960 % 16) ? NewDouble((double)_attr_code_14960 / 16) : (_attr_code_14960 / 16);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _attr_code_14960;
    ((int *)_2)[2] = _8445;
    _8446 = MAKE_SEQ(_1);
    _8445 = NOVALUE;
    DeRef(_fgbg_14961);
    _fgbg_14961 = binary_op(AND_BITS, _8446, 15);
    DeRefDS(_8446);
    _8446 = NOVALUE;

    /**     return {find(fgbg[1],true_fgcolor)-1, find(fgbg[2],true_bgcolor)-1}*/
    _2 = (int)SEQ_PTR(_fgbg_14961);
    _8448 = (int)*(((s1_ptr)_2)->base + 1);
    _8449 = find_from(_8448, _36true_fgcolor_14151, 1);
    _8448 = NOVALUE;
    _8450 = _8449 - 1;
    _8449 = NOVALUE;
    _2 = (int)SEQ_PTR(_fgbg_14961);
    _8451 = (int)*(((s1_ptr)_2)->base + 2);
    _8452 = find_from(_8451, _36true_bgcolor_14153, 1);
    _8451 = NOVALUE;
    _8453 = _8452 - 1;
    _8452 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _8450;
    ((int *)_2)[2] = _8453;
    _8454 = MAKE_SEQ(_1);
    _8453 = NOVALUE;
    _8450 = NOVALUE;
    DeRefDS(_fgbg_14961);
    return _8454;
    ;
}
int attr_to_colors() __attribute__ ((alias ("_32attr_to_colors")));


int _32colors_to_attr(int _fgbg_14976, int _bg_14977)
{
    int _8469 = NOVALUE;
    int _8468 = NOVALUE;
    int _8467 = NOVALUE;
    int _8466 = NOVALUE;
    int _8465 = NOVALUE;
    int _8464 = NOVALUE;
    int _8463 = NOVALUE;
    int _8462 = NOVALUE;
    int _8461 = NOVALUE;
    int _8460 = NOVALUE;
    int _8459 = NOVALUE;
    int _8458 = NOVALUE;
    int _8457 = NOVALUE;
    int _8456 = NOVALUE;
    int _8455 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_bg_14977)) {
        _1 = (long)(DBL_PTR(_bg_14977)->dbl);
        DeRefDS(_bg_14977);
        _bg_14977 = _1;
    }

    /** 	if sequence(fgbg) then*/
    _8455 = IS_SEQUENCE(_fgbg_14976);
    if (_8455 == 0)
    {
        _8455 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _8455 = NOVALUE;
    }

    /**                 return true_fgcolor[fgbg[1]+1] + true_bgcolor[fgbg[2]+1] * 16*/
    _2 = (int)SEQ_PTR(_fgbg_14976);
    _8456 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8456)) {
        _8457 = _8456 + 1;
    }
    else
    _8457 = binary_op(PLUS, 1, _8456);
    _8456 = NOVALUE;
    _2 = (int)SEQ_PTR(_36true_fgcolor_14151);
    if (!IS_ATOM_INT(_8457)){
        _8458 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8457)->dbl));
    }
    else{
        _8458 = (int)*(((s1_ptr)_2)->base + _8457);
    }
    _2 = (int)SEQ_PTR(_fgbg_14976);
    _8459 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8459)) {
        _8460 = _8459 + 1;
    }
    else
    _8460 = binary_op(PLUS, 1, _8459);
    _8459 = NOVALUE;
    _2 = (int)SEQ_PTR(_36true_bgcolor_14153);
    if (!IS_ATOM_INT(_8460)){
        _8461 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8460)->dbl));
    }
    else{
        _8461 = (int)*(((s1_ptr)_2)->base + _8460);
    }
    if (IS_ATOM_INT(_8461)) {
        if (_8461 == (short)_8461)
        _8462 = _8461 * 16;
        else
        _8462 = NewDouble(_8461 * (double)16);
    }
    else {
        _8462 = binary_op(MULTIPLY, _8461, 16);
    }
    _8461 = NOVALUE;
    if (IS_ATOM_INT(_8458) && IS_ATOM_INT(_8462)) {
        _8463 = _8458 + _8462;
        if ((long)((unsigned long)_8463 + (unsigned long)HIGH_BITS) >= 0) 
        _8463 = NewDouble((double)_8463);
    }
    else {
        _8463 = binary_op(PLUS, _8458, _8462);
    }
    _8458 = NOVALUE;
    DeRef(_8462);
    _8462 = NOVALUE;
    DeRef(_fgbg_14976);
    DeRef(_8457);
    _8457 = NOVALUE;
    DeRef(_8460);
    _8460 = NOVALUE;
    return _8463;
    goto L2; // [53] 91
L1: 

    /**                 return true_fgcolor[fgbg+1] + true_bgcolor[bg+1] * 16*/
    if (IS_ATOM_INT(_fgbg_14976)) {
        _8464 = _fgbg_14976 + 1;
    }
    else
    _8464 = binary_op(PLUS, 1, _fgbg_14976);
    _2 = (int)SEQ_PTR(_36true_fgcolor_14151);
    if (!IS_ATOM_INT(_8464)){
        _8465 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8464)->dbl));
    }
    else{
        _8465 = (int)*(((s1_ptr)_2)->base + _8464);
    }
    _8466 = _bg_14977 + 1;
    _2 = (int)SEQ_PTR(_36true_bgcolor_14153);
    _8467 = (int)*(((s1_ptr)_2)->base + _8466);
    if (IS_ATOM_INT(_8467)) {
        if (_8467 == (short)_8467)
        _8468 = _8467 * 16;
        else
        _8468 = NewDouble(_8467 * (double)16);
    }
    else {
        _8468 = binary_op(MULTIPLY, _8467, 16);
    }
    _8467 = NOVALUE;
    if (IS_ATOM_INT(_8465) && IS_ATOM_INT(_8468)) {
        _8469 = _8465 + _8468;
        if ((long)((unsigned long)_8469 + (unsigned long)HIGH_BITS) >= 0) 
        _8469 = NewDouble((double)_8469);
    }
    else {
        _8469 = binary_op(PLUS, _8465, _8468);
    }
    _8465 = NOVALUE;
    DeRef(_8468);
    _8468 = NOVALUE;
    DeRef(_fgbg_14976);
    DeRef(_8464);
    _8464 = NOVALUE;
    DeRef(_8457);
    _8457 = NOVALUE;
    DeRef(_8463);
    _8463 = NOVALUE;
    DeRef(_8460);
    _8460 = NOVALUE;
    _8466 = NOVALUE;
    return _8469;
L2: 
    ;
}
int colors_to_attr() __attribute__ ((alias ("_32colors_to_attr")));


void _32display_text_image(int _xy_15001, int _text_15002)
{
    int _extra_col2_15003 = NOVALUE;
    int _extra_lines_15004 = NOVALUE;
    int _vc_15005 = NOVALUE;
    int _one_row_15006 = NOVALUE;
    int _video_config_inlined_video_config_at_6_15008 = NOVALUE;
    int _8498 = NOVALUE;
    int _8497 = NOVALUE;
    int _8496 = NOVALUE;
    int _8495 = NOVALUE;
    int _8494 = NOVALUE;
    int _8490 = NOVALUE;
    int _8488 = NOVALUE;
    int _8486 = NOVALUE;
    int _8485 = NOVALUE;
    int _8484 = NOVALUE;
    int _8483 = NOVALUE;
    int _8479 = NOVALUE;
    int _8477 = NOVALUE;
    int _8476 = NOVALUE;
    int _8475 = NOVALUE;
    int _8474 = NOVALUE;
    int _8473 = NOVALUE;
    int _8471 = NOVALUE;
    int _8470 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vc = graphcst:video_config()*/

    /** 	return machine_func(M_VIDEO_CONFIG, 0)*/
    DeRefi(_vc_15005);
    _vc_15005 = machine(13, 0);

    /** 	if xy[1] < 1 or xy[2] < 1 then*/
    _2 = (int)SEQ_PTR(_xy_15001);
    _8470 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8470)) {
        _8471 = (_8470 < 1);
    }
    else {
        _8471 = binary_op(LESS, _8470, 1);
    }
    _8470 = NOVALUE;
    if (IS_ATOM_INT(_8471)) {
        if (_8471 != 0) {
            goto L1; // [26] 43
        }
    }
    else {
        if (DBL_PTR(_8471)->dbl != 0.0) {
            goto L1; // [26] 43
        }
    }
    _2 = (int)SEQ_PTR(_xy_15001);
    _8473 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8473)) {
        _8474 = (_8473 < 1);
    }
    else {
        _8474 = binary_op(LESS, _8473, 1);
    }
    _8473 = NOVALUE;
    if (_8474 == 0) {
        DeRef(_8474);
        _8474 = NOVALUE;
        goto L2; // [39] 49
    }
    else {
        if (!IS_ATOM_INT(_8474) && DBL_PTR(_8474)->dbl == 0.0){
            DeRef(_8474);
            _8474 = NOVALUE;
            goto L2; // [39] 49
        }
        DeRef(_8474);
        _8474 = NOVALUE;
    }
    DeRef(_8474);
    _8474 = NOVALUE;
L1: 

    /** 		return -- bad starting point*/
    DeRefDS(_xy_15001);
    DeRefDS(_text_15002);
    DeRefi(_vc_15005);
    DeRef(_one_row_15006);
    DeRef(_8471);
    _8471 = NOVALUE;
    return;
L2: 

    /** 	extra_lines = vc[graphcst:VC_LINES] - xy[1] + 1*/
    _2 = (int)SEQ_PTR(_vc_15005);
    _8475 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_xy_15001);
    _8476 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8476)) {
        _8477 = _8475 - _8476;
        if ((long)((unsigned long)_8477 +(unsigned long) HIGH_BITS) >= 0){
            _8477 = NewDouble((double)_8477);
        }
    }
    else {
        _8477 = binary_op(MINUS, _8475, _8476);
    }
    _8475 = NOVALUE;
    _8476 = NOVALUE;
    if (IS_ATOM_INT(_8477)) {
        _extra_lines_15004 = _8477 + 1;
    }
    else
    { // coercing _extra_lines_15004 to an integer 1
        _extra_lines_15004 = 1+(long)(DBL_PTR(_8477)->dbl);
        if( !IS_ATOM_INT(_extra_lines_15004) ){
            _extra_lines_15004 = (object)DBL_PTR(_extra_lines_15004)->dbl;
        }
    }
    DeRef(_8477);
    _8477 = NOVALUE;

    /** 	if length(text) > extra_lines then*/
    if (IS_SEQUENCE(_text_15002)){
            _8479 = SEQ_PTR(_text_15002)->length;
    }
    else {
        _8479 = 1;
    }
    if (_8479 <= _extra_lines_15004)
    goto L3; // [72] 96

    /** 		if extra_lines <= 0 then*/
    if (_extra_lines_15004 > 0)
    goto L4; // [78] 88

    /** 			return -- nothing to display*/
    DeRefDS(_xy_15001);
    DeRefDS(_text_15002);
    DeRefDSi(_vc_15005);
    DeRef(_one_row_15006);
    DeRef(_8471);
    _8471 = NOVALUE;
    return;
L4: 

    /** 		text = text[1..extra_lines] -- truncate*/
    rhs_slice_target = (object_ptr)&_text_15002;
    RHS_Slice(_text_15002, 1, _extra_lines_15004);
L3: 

    /** 	extra_col2 = 2 * (vc[graphcst:VC_COLUMNS] - xy[2] + 1)*/
    _2 = (int)SEQ_PTR(_vc_15005);
    _8483 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_xy_15001);
    _8484 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8484)) {
        _8485 = _8483 - _8484;
        if ((long)((unsigned long)_8485 +(unsigned long) HIGH_BITS) >= 0){
            _8485 = NewDouble((double)_8485);
        }
    }
    else {
        _8485 = binary_op(MINUS, _8483, _8484);
    }
    _8483 = NOVALUE;
    _8484 = NOVALUE;
    if (IS_ATOM_INT(_8485)) {
        _8486 = _8485 + 1;
        if (_8486 > MAXINT){
            _8486 = NewDouble((double)_8486);
        }
    }
    else
    _8486 = binary_op(PLUS, 1, _8485);
    DeRef(_8485);
    _8485 = NOVALUE;
    if (IS_ATOM_INT(_8486) && IS_ATOM_INT(_8486)) {
        _extra_col2_15003 = _8486 + _8486;
    }
    else {
        _extra_col2_15003 = binary_op(PLUS, _8486, _8486);
    }
    DeRef(_8486);
    _8486 = NOVALUE;
    _8486 = NOVALUE;
    if (!IS_ATOM_INT(_extra_col2_15003)) {
        _1 = (long)(DBL_PTR(_extra_col2_15003)->dbl);
        DeRefDS(_extra_col2_15003);
        _extra_col2_15003 = _1;
    }

    /** 	for row = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_15002)){
            _8488 = SEQ_PTR(_text_15002)->length;
    }
    else {
        _8488 = 1;
    }
    {
        int _row_15031;
        _row_15031 = 1;
L5: 
        if (_row_15031 > _8488){
            goto L6; // [125] 203
        }

        /** 		one_row = text[row]*/
        DeRef(_one_row_15006);
        _2 = (int)SEQ_PTR(_text_15002);
        _one_row_15006 = (int)*(((s1_ptr)_2)->base + _row_15031);
        Ref(_one_row_15006);

        /** 		if length(one_row) > extra_col2 then*/
        if (IS_SEQUENCE(_one_row_15006)){
                _8490 = SEQ_PTR(_one_row_15006)->length;
        }
        else {
            _8490 = 1;
        }
        if (_8490 <= _extra_col2_15003)
        goto L7; // [145] 169

        /** 			if extra_col2 <= 0 then*/
        if (_extra_col2_15003 > 0)
        goto L8; // [151] 161

        /** 				return -- nothing to display*/
        DeRefDS(_xy_15001);
        DeRefDS(_text_15002);
        DeRefi(_vc_15005);
        DeRefDS(_one_row_15006);
        DeRef(_8471);
        _8471 = NOVALUE;
        return;
L8: 

        /** 			one_row = one_row[1..extra_col2] -- truncate*/
        rhs_slice_target = (object_ptr)&_one_row_15006;
        RHS_Slice(_one_row_15006, 1, _extra_col2_15003);
L7: 

        /** 		machine_proc(M_PUT_SCREEN_CHAR, {xy[1]+row-1, xy[2], one_row})*/
        _2 = (int)SEQ_PTR(_xy_15001);
        _8494 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8494)) {
            _8495 = _8494 + _row_15031;
            if ((long)((unsigned long)_8495 + (unsigned long)HIGH_BITS) >= 0) 
            _8495 = NewDouble((double)_8495);
        }
        else {
            _8495 = binary_op(PLUS, _8494, _row_15031);
        }
        _8494 = NOVALUE;
        if (IS_ATOM_INT(_8495)) {
            _8496 = _8495 - 1;
            if ((long)((unsigned long)_8496 +(unsigned long) HIGH_BITS) >= 0){
                _8496 = NewDouble((double)_8496);
            }
        }
        else {
            _8496 = binary_op(MINUS, _8495, 1);
        }
        DeRef(_8495);
        _8495 = NOVALUE;
        _2 = (int)SEQ_PTR(_xy_15001);
        _8497 = (int)*(((s1_ptr)_2)->base + 2);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _8496;
        Ref(_8497);
        *((int *)(_2+8)) = _8497;
        RefDS(_one_row_15006);
        *((int *)(_2+12)) = _one_row_15006;
        _8498 = MAKE_SEQ(_1);
        _8497 = NOVALUE;
        _8496 = NOVALUE;
        machine(59, _8498);
        DeRefDS(_8498);
        _8498 = NOVALUE;

        /** 	end for*/
        _row_15031 = _row_15031 + 1;
        goto L5; // [198] 132
L6: 
        ;
    }

    /** end procedure*/
    DeRefDS(_xy_15001);
    DeRefDS(_text_15002);
    DeRefi(_vc_15005);
    DeRef(_one_row_15006);
    DeRef(_8471);
    _8471 = NOVALUE;
    return;
    ;
}
void display_text_image() __attribute__ ((alias ("_32display_text_image")));


int _32save_text_image(int _top_left_15047, int _bottom_right_15048)
{
    int _image_15049 = NOVALUE;
    int _row_chars_15050 = NOVALUE;
    int _8504 = NOVALUE;
    int _8503 = NOVALUE;
    int _8502 = NOVALUE;
    int _8501 = NOVALUE;
    int _8500 = NOVALUE;
    int _8499 = NOVALUE;
    int _0, _1, _2;
    

    /** 	image = {}*/
    RefDS(_5);
    DeRef(_image_15049);
    _image_15049 = _5;

    /** 	for row = top_left[1] to bottom_right[1] do*/
    _2 = (int)SEQ_PTR(_top_left_15047);
    _8499 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_bottom_right_15048);
    _8500 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int _row_15052;
        Ref(_8499);
        _row_15052 = _8499;
L1: 
        if (binary_op_a(GREATER, _row_15052, _8500)){
            goto L2; // [22] 87
        }

        /** 		row_chars = {}*/
        RefDS(_5);
        DeRef(_row_chars_15050);
        _row_chars_15050 = _5;

        /** 		for col = top_left[2] to bottom_right[2] do*/
        _2 = (int)SEQ_PTR(_top_left_15047);
        _8501 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_bottom_right_15048);
        _8502 = (int)*(((s1_ptr)_2)->base + 2);
        {
            int _col_15056;
            Ref(_8501);
            _col_15056 = _8501;
L3: 
            if (binary_op_a(GREATER, _col_15056, _8502)){
                goto L4; // [46] 74
            }

            /** 			row_chars &= machine_func(M_GET_SCREEN_CHAR, {row, col})*/
            Ref(_col_15056);
            Ref(_row_15052);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _row_15052;
            ((int *)_2)[2] = _col_15056;
            _8503 = MAKE_SEQ(_1);
            _8504 = machine(58, _8503);
            DeRefDS(_8503);
            _8503 = NOVALUE;
            Concat((object_ptr)&_row_chars_15050, _row_chars_15050, _8504);
            DeRefDS(_8504);
            _8504 = NOVALUE;

            /** 		end for*/
            _0 = _col_15056;
            if (IS_ATOM_INT(_col_15056)) {
                _col_15056 = _col_15056 + 1;
                if ((long)((unsigned long)_col_15056 +(unsigned long) HIGH_BITS) >= 0){
                    _col_15056 = NewDouble((double)_col_15056);
                }
            }
            else {
                _col_15056 = binary_op_a(PLUS, _col_15056, 1);
            }
            DeRef(_0);
            goto L3; // [69] 53
L4: 
            ;
            DeRef(_col_15056);
        }

        /** 		image = append(image, row_chars)*/
        RefDS(_row_chars_15050);
        Append(&_image_15049, _image_15049, _row_chars_15050);

        /** 	end for*/
        _0 = _row_15052;
        if (IS_ATOM_INT(_row_15052)) {
            _row_15052 = _row_15052 + 1;
            if ((long)((unsigned long)_row_15052 +(unsigned long) HIGH_BITS) >= 0){
                _row_15052 = NewDouble((double)_row_15052);
            }
        }
        else {
            _row_15052 = binary_op_a(PLUS, _row_15052, 1);
        }
        DeRef(_0);
        goto L1; // [82] 29
L2: 
        ;
        DeRef(_row_15052);
    }

    /** 	return image*/
    DeRefDS(_top_left_15047);
    DeRefDS(_bottom_right_15048);
    DeRef(_row_chars_15050);
    _8499 = NOVALUE;
    _8500 = NOVALUE;
    _8501 = NOVALUE;
    _8502 = NOVALUE;
    return _image_15049;
    ;
}
int save_text_image() __attribute__ ((alias ("_32save_text_image")));


int _32text_rows(int _rows_15065)
{
    int _8507 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_TEXTROWS, rows)*/
    _8507 = machine(12, _rows_15065);
    DeRef(_rows_15065);
    return _8507;
    ;
}
int text_rows() __attribute__ ((alias ("_32text_rows")));


void _32cursor(int _style_15069)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_style_15069)) {
        _1 = (long)(DBL_PTR(_style_15069)->dbl);
        DeRefDS(_style_15069);
        _style_15069 = _1;
    }

    /** 	machine_proc(M_CURSOR, style)*/
    machine(6, _style_15069);

    /** end procedure*/
    return;
    ;
}
void cursor() __attribute__ ((alias ("_32cursor")));


void _32free_console()
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_FREE_CONSOLE, 0)*/
    machine(54, 0);

    /** end procedure*/
    return;
    ;
}
void free_console() __attribute__ ((alias ("_32free_console")));


void _32display(int _data_in_15074, int _args_15075, int _finalnl_15076)
{
    int _8535 = NOVALUE;
    int _8534 = NOVALUE;
    int _8533 = NOVALUE;
    int _8530 = NOVALUE;
    int _8528 = NOVALUE;
    int _8527 = NOVALUE;
    int _8525 = NOVALUE;
    int _8524 = NOVALUE;
    int _8522 = NOVALUE;
    int _8521 = NOVALUE;
    int _8519 = NOVALUE;
    int _8518 = NOVALUE;
    int _8517 = NOVALUE;
    int _8515 = NOVALUE;
    int _8514 = NOVALUE;
    int _8513 = NOVALUE;
    int _8511 = NOVALUE;
    int _8510 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_finalnl_15076)) {
        _1 = (long)(DBL_PTR(_finalnl_15076)->dbl);
        DeRefDS(_finalnl_15076);
        _finalnl_15076 = _1;
    }

    /** 	if atom(data_in) then*/
    _8510 = IS_ATOM(_data_in_15074);
    if (_8510 == 0)
    {
        _8510 = NOVALUE;
        goto L1; // [8] 47
    }
    else{
        _8510 = NOVALUE;
    }

    /** 		if integer(data_in) then*/
    if (IS_ATOM_INT(_data_in_15074))
    _8511 = 1;
    else if (IS_ATOM_DBL(_data_in_15074))
    _8511 = IS_ATOM_INT(DoubleToInt(_data_in_15074));
    else
    _8511 = 0;
    if (_8511 == 0)
    {
        _8511 = NOVALUE;
        goto L2; // [16] 28
    }
    else{
        _8511 = NOVALUE;
    }

    /** 			printf(1, "%d", data_in)*/
    EPrintf(1, _919, _data_in_15074);
    goto L3; // [25] 170
L2: 

    /** 			puts(1, text:trim(sprintf("%15.15f", data_in), '0'))*/
    _8513 = EPrintf(-9999999, _8512, _data_in_15074);
    _8514 = _6trim(_8513, 48, 0);
    _8513 = NOVALUE;
    EPuts(1, _8514); // DJP 
    DeRef(_8514);
    _8514 = NOVALUE;
    goto L3; // [44] 170
L1: 

    /** 	elsif length(data_in) > 0 then*/
    if (IS_SEQUENCE(_data_in_15074)){
            _8515 = SEQ_PTR(_data_in_15074)->length;
    }
    else {
        _8515 = 1;
    }
    if (_8515 <= 0)
    goto L4; // [52] 154

    /** 		if types:t_display( data_in ) then*/
    Ref(_data_in_15074);
    _8517 = _7t_display(_data_in_15074);
    if (_8517 == 0) {
        DeRef(_8517);
        _8517 = NOVALUE;
        goto L5; // [62] 111
    }
    else {
        if (!IS_ATOM_INT(_8517) && DBL_PTR(_8517)->dbl == 0.0){
            DeRef(_8517);
            _8517 = NOVALUE;
            goto L5; // [62] 111
        }
        DeRef(_8517);
        _8517 = NOVALUE;
    }
    DeRef(_8517);
    _8517 = NOVALUE;

    /** 			if data_in[$] = '_' then*/
    if (IS_SEQUENCE(_data_in_15074)){
            _8518 = SEQ_PTR(_data_in_15074)->length;
    }
    else {
        _8518 = 1;
    }
    _2 = (int)SEQ_PTR(_data_in_15074);
    _8519 = (int)*(((s1_ptr)_2)->base + _8518);
    if (binary_op_a(NOTEQ, _8519, 95)){
        _8519 = NOVALUE;
        goto L6; // [74] 98
    }
    _8519 = NOVALUE;

    /** 				data_in = data_in[1..$-1]*/
    if (IS_SEQUENCE(_data_in_15074)){
            _8521 = SEQ_PTR(_data_in_15074)->length;
    }
    else {
        _8521 = 1;
    }
    _8522 = _8521 - 1;
    _8521 = NOVALUE;
    rhs_slice_target = (object_ptr)&_data_in_15074;
    RHS_Slice(_data_in_15074, 1, _8522);

    /** 				finalnl = 0*/
    _finalnl_15076 = 0;
L6: 

    /** 			puts(1, text:format(data_in, args))*/
    Ref(_data_in_15074);
    Ref(_args_15075);
    _8524 = _6format(_data_in_15074, _args_15075);
    EPuts(1, _8524); // DJP 
    DeRef(_8524);
    _8524 = NOVALUE;
    goto L3; // [108] 170
L5: 

    /** 			if atom(args) or length(args) = 0 then*/
    _8525 = IS_ATOM(_args_15075);
    if (_8525 != 0) {
        goto L7; // [116] 132
    }
    if (IS_SEQUENCE(_args_15075)){
            _8527 = SEQ_PTR(_args_15075)->length;
    }
    else {
        _8527 = 1;
    }
    _8528 = (_8527 == 0);
    _8527 = NOVALUE;
    if (_8528 == 0)
    {
        DeRef(_8528);
        _8528 = NOVALUE;
        goto L8; // [128] 142
    }
    else{
        DeRef(_8528);
        _8528 = NOVALUE;
    }
L7: 

    /** 				pretty:pretty_print(1, data_in, {2})*/
    Ref(_data_in_15074);
    RefDS(_8529);
    _26pretty_print(1, _data_in_15074, _8529);
    goto L3; // [139] 170
L8: 

    /** 				pretty:pretty_print(1, data_in, args)*/
    Ref(_data_in_15074);
    Ref(_args_15075);
    _26pretty_print(1, _data_in_15074, _args_15075);
    goto L3; // [151] 170
L4: 

    /** 		if equal(args, 2) then*/
    if (_args_15075 == 2)
    _8530 = 1;
    else if (IS_ATOM_INT(_args_15075) && IS_ATOM_INT(2))
    _8530 = 0;
    else
    _8530 = (compare(_args_15075, 2) == 0);
    if (_8530 == 0)
    {
        _8530 = NOVALUE;
        goto L9; // [160] 169
    }
    else{
        _8530 = NOVALUE;
    }

    /** 			puts(1, `""`)*/
    EPuts(1, _8531); // DJP 
L9: 
L3: 

    /** 	if finalnl = 0 then*/
    if (_finalnl_15076 != 0)
    goto LA; // [172] 179
    goto LB; // [176] 206
LA: 

    /** 	elsif finalnl = -918_273_645 and equal(args,0) then*/
    _8533 = (_finalnl_15076 == -918273645);
    if (_8533 == 0) {
        goto LC; // [185] 200
    }
    if (_args_15075 == 0)
    _8535 = 1;
    else if (IS_ATOM_INT(_args_15075) && IS_ATOM_INT(0))
    _8535 = 0;
    else
    _8535 = (compare(_args_15075, 0) == 0);
    if (_8535 == 0)
    {
        _8535 = NOVALUE;
        goto LC; // [194] 200
    }
    else{
        _8535 = NOVALUE;
    }
    goto LB; // [197] 206
LC: 

    /** 		puts(1, '\n')*/
    EPuts(1, 10); // DJP 
LB: 

    /** 	return*/
    DeRef(_data_in_15074);
    DeRef(_args_15075);
    DeRef(_8522);
    _8522 = NOVALUE;
    DeRef(_8533);
    _8533 = NOVALUE;
    return;

    /** end procedure*/
    DeRef(_8522);
    _8522 = NOVALUE;
    DeRef(_8533);
    _8533 = NOVALUE;
    return;
    ;
}
void display() __attribute__ ((alias ("_32display")));



// 0x102420F2
