// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _9find_any(int _needles_884, int _haystack_885, int _start_886)
{
    int _484 = NOVALUE;
    int _483 = NOVALUE;
    int _482 = NOVALUE;
    int _480 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_886)) {
        _1 = (long)(DBL_PTR(_start_886)->dbl);
        DeRefDS(_start_886);
        _start_886 = _1;
    }

    /** 	if atom(needles) then*/
    _480 = IS_ATOM(_needles_884);
    if (_480 == 0)
    {
        _480 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _480 = NOVALUE;
    }

    /** 		needles = {needles}*/
    _0 = _needles_884;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needles_884);
    *((int *)(_2+4)) = _needles_884;
    _needles_884 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = start to length(haystack) do*/
    if (IS_SEQUENCE(_haystack_885)){
            _482 = SEQ_PTR(_haystack_885)->length;
    }
    else {
        _482 = 1;
    }
    {
        int _i_891;
        _i_891 = _start_886;
L2: 
        if (_i_891 > _482){
            goto L3; // [25] 60
        }

        /** 		if find(haystack[i],needles) then*/
        _2 = (int)SEQ_PTR(_haystack_885);
        _483 = (int)*(((s1_ptr)_2)->base + _i_891);
        _484 = find_from(_483, _needles_884, 1);
        _483 = NOVALUE;
        if (_484 == 0)
        {
            _484 = NOVALUE;
            goto L4; // [43] 53
        }
        else{
            _484 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needles_884);
        DeRefDS(_haystack_885);
        return _i_891;
L4: 

        /** 	end for*/
        _i_891 = _i_891 + 1;
        goto L2; // [55] 32
L3: 
        ;
    }

    /** 	return 0*/
    DeRef(_needles_884);
    DeRefDS(_haystack_885);
    return 0;
    ;
}
int find_any() __attribute__ ((alias ("_9find_any")));


int _9match_any(int _needles_898, int _haystack_899, int _start_900)
{
    int _487 = NOVALUE;
    int _486 = NOVALUE;
    int _485 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_900)) {
        _1 = (long)(DBL_PTR(_start_900)->dbl);
        DeRefDS(_start_900);
        _start_900 = _1;
    }

    /** 	for i = start to length(haystack) do*/
    if (IS_SEQUENCE(_haystack_899)){
            _485 = SEQ_PTR(_haystack_899)->length;
    }
    else {
        _485 = 1;
    }
    {
        int _i_902;
        _i_902 = _start_900;
L1: 
        if (_i_902 > _485){
            goto L2; // [12] 47
        }

        /** 		if find(haystack[i],needles) then*/
        _2 = (int)SEQ_PTR(_haystack_899);
        _486 = (int)*(((s1_ptr)_2)->base + _i_902);
        _487 = find_from(_486, _needles_898, 1);
        _486 = NOVALUE;
        if (_487 == 0)
        {
            _487 = NOVALUE;
            goto L3; // [30] 40
        }
        else{
            _487 = NOVALUE;
        }

        /** 			return 1*/
        DeRefDS(_needles_898);
        DeRefDS(_haystack_899);
        return 1;
L3: 

        /** 	end for*/
        _i_902 = _i_902 + 1;
        goto L1; // [42] 19
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_needles_898);
    DeRefDS(_haystack_899);
    return 0;
    ;
}
int match_any() __attribute__ ((alias ("_9match_any")));


int _9find_each(int _needles_909, int _haystack_910, int _start_911)
{
    int _kx_912 = NOVALUE;
    int _493 = NOVALUE;
    int _492 = NOVALUE;
    int _490 = NOVALUE;
    int _489 = NOVALUE;
    int _488 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_911)) {
        _1 = (long)(DBL_PTR(_start_911)->dbl);
        DeRefDS(_start_911);
        _start_911 = _1;
    }

    /** 	integer kx = 0*/
    _kx_912 = 0;

    /** 	for i = start to length(haystack) do*/
    if (IS_SEQUENCE(_haystack_910)){
            _488 = SEQ_PTR(_haystack_910)->length;
    }
    else {
        _488 = 1;
    }
    {
        int _i_914;
        _i_914 = _start_911;
L1: 
        if (_i_914 > _488){
            goto L2; // [17] 58
        }

        /** 		if find(haystack[i],needles) then*/
        _2 = (int)SEQ_PTR(_haystack_910);
        _489 = (int)*(((s1_ptr)_2)->base + _i_914);
        _490 = find_from(_489, _needles_909, 1);
        _489 = NOVALUE;
        if (_490 == 0)
        {
            _490 = NOVALUE;
            goto L3; // [35] 51
        }
        else{
            _490 = NOVALUE;
        }

        /** 			kx += 1*/
        _kx_912 = _kx_912 + 1;

        /** 			haystack[kx] = i*/
        _2 = (int)SEQ_PTR(_haystack_910);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _haystack_910 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _kx_912);
        _1 = *(int *)_2;
        *(int *)_2 = _i_914;
        DeRef(_1);
L3: 

        /** 	end for*/
        _i_914 = _i_914 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _492 = _kx_912 + 1;
    if (_492 > MAXINT){
        _492 = NewDouble((double)_492);
    }
    if (IS_SEQUENCE(_haystack_910)){
            _493 = SEQ_PTR(_haystack_910)->length;
    }
    else {
        _493 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_910);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_492)) ? _492 : (long)(DBL_PTR(_492)->dbl);
        int stop = (IS_ATOM_INT(_493)) ? _493 : (long)(DBL_PTR(_493)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_910), start, &_haystack_910 );
            }
            else Tail(SEQ_PTR(_haystack_910), stop+1, &_haystack_910);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_910), start, &_haystack_910);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_910 = Remove_elements(start, stop, (SEQ_PTR(_haystack_910)->ref == 1));
        }
    }
    DeRef(_492);
    _492 = NOVALUE;
    _493 = NOVALUE;

    /** 	return haystack*/
    DeRefDS(_needles_909);
    return _haystack_910;
    ;
}
int find_each() __attribute__ ((alias ("_9find_each")));


int _9find_all(int _needle_925, int _haystack_926, int _start_927)
{
    int _kx_928 = NOVALUE;
    int _499 = NOVALUE;
    int _498 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_927)) {
        _1 = (long)(DBL_PTR(_start_927)->dbl);
        DeRefDS(_start_927);
        _start_927 = _1;
    }

    /** 	integer kx = 0*/
    _kx_928 = 0;

    /** 	while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_927 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** 		kx += 1*/
    _kx_928 = _kx_928 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_926);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_926 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_928);
    _1 = *(int *)_2;
    *(int *)_2 = _start_927;
    DeRef(_1);

    /** 		start += 1*/
    _start_927 = _start_927 + 1;

    /** 	entry*/
L1: 

    /** 		start = find(needle, haystack, start)*/
    _start_927 = find_from(_needle_925, _haystack_926, _start_927);

    /** 	end while*/
    goto L2; // [48] 15
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _498 = _kx_928 + 1;
    if (_498 > MAXINT){
        _498 = NewDouble((double)_498);
    }
    if (IS_SEQUENCE(_haystack_926)){
            _499 = SEQ_PTR(_haystack_926)->length;
    }
    else {
        _499 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_926);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_498)) ? _498 : (long)(DBL_PTR(_498)->dbl);
        int stop = (IS_ATOM_INT(_499)) ? _499 : (long)(DBL_PTR(_499)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_926), start, &_haystack_926 );
            }
            else Tail(SEQ_PTR(_haystack_926), stop+1, &_haystack_926);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_926), start, &_haystack_926);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_926 = Remove_elements(start, stop, (SEQ_PTR(_haystack_926)->ref == 1));
        }
    }
    DeRef(_498);
    _498 = NOVALUE;
    _499 = NOVALUE;

    /** 	return haystack*/
    DeRef(_needle_925);
    return _haystack_926;
    ;
}


int _9find_all_but(int _needle_938, int _haystack_939, int _start_940)
{
    int _ix_941 = NOVALUE;
    int _jx_942 = NOVALUE;
    int _kx_943 = NOVALUE;
    int _508 = NOVALUE;
    int _507 = NOVALUE;
    int _505 = NOVALUE;
    int _501 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_940)) {
        _1 = (long)(DBL_PTR(_start_940)->dbl);
        DeRefDS(_start_940);
        _start_940 = _1;
    }

    /** 	integer ix = start */
    _ix_941 = _start_940;

    /** 	integer kx = 0 */
    _kx_943 = 0;

    /** 	while jx with entry do*/
    goto L1; // [17] 66
L2: 
    if (_jx_942 == 0)
    {
        goto L3; // [22] 78
    }
    else{
    }

    /** 		for i = ix to jx - 1 do */
    _501 = _jx_942 - 1;
    if ((long)((unsigned long)_501 +(unsigned long) HIGH_BITS) >= 0){
        _501 = NewDouble((double)_501);
    }
    {
        int _i_946;
        _i_946 = _ix_941;
L4: 
        if (binary_op_a(GREATER, _i_946, _501)){
            goto L5; // [31] 57
        }

        /** 			kx += 1 */
        _kx_943 = _kx_943 + 1;

        /** 			haystack[kx] = i */
        Ref(_i_946);
        _2 = (int)SEQ_PTR(_haystack_939);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _haystack_939 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _kx_943);
        _1 = *(int *)_2;
        *(int *)_2 = _i_946;
        DeRef(_1);

        /** 		end for */
        _0 = _i_946;
        if (IS_ATOM_INT(_i_946)) {
            _i_946 = _i_946 + 1;
            if ((long)((unsigned long)_i_946 +(unsigned long) HIGH_BITS) >= 0){
                _i_946 = NewDouble((double)_i_946);
            }
        }
        else {
            _i_946 = binary_op_a(PLUS, _i_946, 1);
        }
        DeRef(_0);
        goto L4; // [52] 38
L5: 
        ;
        DeRef(_i_946);
    }

    /** 		ix = jx + 1 */
    _ix_941 = _jx_942 + 1;

    /** 	entry */
L1: 

    /** 		jx = find( needle, haystack, ix ) */
    _jx_942 = find_from(_needle_938, _haystack_939, _ix_941);

    /** 	end while */
    goto L2; // [75] 20
L3: 

    /** 	for i = ix to length(haystack) do */
    if (IS_SEQUENCE(_haystack_939)){
            _505 = SEQ_PTR(_haystack_939)->length;
    }
    else {
        _505 = 1;
    }
    {
        int _i_952;
        _i_952 = _ix_941;
L6: 
        if (_i_952 > _505){
            goto L7; // [83] 109
        }

        /** 		kx += 1 */
        _kx_943 = _kx_943 + 1;

        /** 		haystack[kx] = i */
        _2 = (int)SEQ_PTR(_haystack_939);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _haystack_939 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _kx_943);
        _1 = *(int *)_2;
        *(int *)_2 = _i_952;
        DeRef(_1);

        /** 	end for */
        _i_952 = _i_952 + 1;
        goto L6; // [104] 90
L7: 
        ;
    }

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _507 = _kx_943 + 1;
    if (_507 > MAXINT){
        _507 = NewDouble((double)_507);
    }
    if (IS_SEQUENCE(_haystack_939)){
            _508 = SEQ_PTR(_haystack_939)->length;
    }
    else {
        _508 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_939);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_507)) ? _507 : (long)(DBL_PTR(_507)->dbl);
        int stop = (IS_ATOM_INT(_508)) ? _508 : (long)(DBL_PTR(_508)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_939), start, &_haystack_939 );
            }
            else Tail(SEQ_PTR(_haystack_939), stop+1, &_haystack_939);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_939), start, &_haystack_939);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_939 = Remove_elements(start, stop, (SEQ_PTR(_haystack_939)->ref == 1));
        }
    }
    DeRef(_507);
    _507 = NOVALUE;
    _508 = NOVALUE;

    /** 	return haystack*/
    DeRef(_needle_938);
    DeRef(_501);
    _501 = NOVALUE;
    return _haystack_939;
    ;
}
int find_all_but() __attribute__ ((alias ("_9find_all_but")));


int _9find_nested(int _needle_964, int _haystack_965, int _flags_966, int _rtn_id_967)
{
    int _occurrences_968 = NOVALUE;
    int _depth_969 = NOVALUE;
    int _branches_970 = NOVALUE;
    int _indexes_971 = NOVALUE;
    int _last_indexes_972 = NOVALUE;
    int _last_idx_973 = NOVALUE;
    int _current_idx_975 = NOVALUE;
    int _direction_976 = NOVALUE;
    int _x_977 = NOVALUE;
    int _rc_978 = NOVALUE;
    int _any_979 = NOVALUE;
    int _info_1002 = NOVALUE;
    int _548 = NOVALUE;
    int _536 = NOVALUE;
    int _533 = NOVALUE;
    int _531 = NOVALUE;
    int _529 = NOVALUE;
    int _526 = NOVALUE;
    int _524 = NOVALUE;
    int _522 = NOVALUE;
    int _516 = NOVALUE;
    int _514 = NOVALUE;
    int _512 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_flags_966)) {
        _1 = (long)(DBL_PTR(_flags_966)->dbl);
        DeRefDS(_flags_966);
        _flags_966 = _1;
    }
    if (!IS_ATOM_INT(_rtn_id_967)) {
        _1 = (long)(DBL_PTR(_rtn_id_967)->dbl);
        DeRefDS(_rtn_id_967);
        _rtn_id_967 = _1;
    }

    /** 	sequence occurrences = {} -- accumulated results*/
    RefDS(_5);
    DeRef(_occurrences_968);
    _occurrences_968 = _5;

    /** 	integer depth = 0*/
    _depth_969 = 0;

    /** 	sequence branches = {}, indexes = {}, last_indexes = {} -- saved states*/
    RefDS(_5);
    DeRef(_branches_970);
    _branches_970 = _5;
    RefDS(_5);
    DeRefi(_indexes_971);
    _indexes_971 = _5;
    RefDS(_5);
    DeRefi(_last_indexes_972);
    _last_indexes_972 = _5;

    /** 	integer last_idx = length(haystack), current_idx = 1, direction = 1 -- assume forward searches more frequent*/
    if (IS_SEQUENCE(_haystack_965)){
            _last_idx_973 = SEQ_PTR(_haystack_965)->length;
    }
    else {
        _last_idx_973 = 1;
    }
    _current_idx_975 = 1;
    _direction_976 = 1;

    /** 	integer rc, any = and_bits(flags, NESTED_ANY)*/
    {unsigned long tu;
         tu = (unsigned long)_flags_966 & (unsigned long)1;
         _any_979 = MAKE_UINT(tu);
    }

    /** 	if and_bits(flags,NESTED_BACKWARD) then*/
    {unsigned long tu;
         tu = (unsigned long)_flags_966 & (unsigned long)8;
         _512 = MAKE_UINT(tu);
    }
    if (_512 == 0) {
        DeRef(_512);
        _512 = NOVALUE;
        goto L1; // [59] 78
    }
    else {
        if (!IS_ATOM_INT(_512) && DBL_PTR(_512)->dbl == 0.0){
            DeRef(_512);
            _512 = NOVALUE;
            goto L1; // [59] 78
        }
        DeRef(_512);
        _512 = NOVALUE;
    }
    DeRef(_512);
    _512 = NOVALUE;

    /** 	    current_idx = last_idx*/
    _current_idx_975 = _last_idx_973;

    /** 	    last_idx = 1*/
    _last_idx_973 = 1;

    /** 	    direction = -1*/
    _direction_976 = -1;
L1: 

    /** 	any = any and sequence(needle)*/
    _514 = IS_SEQUENCE(_needle_964);
    _any_979 = (_any_979 != 0 && _514 != 0);
    _514 = NOVALUE;

    /** 	while 1 do -- traverse the whole haystack tree*/
L2: 

    /** 		while eu:compare(current_idx, last_idx) != direction do*/
L3: 
    if (IS_ATOM_INT(_current_idx_975) && IS_ATOM_INT(_last_idx_973)){
        _516 = (_current_idx_975 < _last_idx_973) ? -1 : (_current_idx_975 > _last_idx_973);
    }
    else{
        _516 = compare(_current_idx_975, _last_idx_973);
    }
    if (_516 == _direction_976)
    goto L4; // [101] 363

    /** 	        x = haystack[current_idx]*/
    DeRef(_x_977);
    _2 = (int)SEQ_PTR(_haystack_965);
    _x_977 = (int)*(((s1_ptr)_2)->base + _current_idx_975);
    Ref(_x_977);

    /** 			if rtn_id = NO_ROUTINE_ID then*/
    if (_rtn_id_967 != -99999)
    goto L5; // [115] 144

    /** 	         	if any then*/
    if (_any_979 == 0)
    {
        goto L6; // [121] 134
    }
    else{
    }

    /** 	         		rc = find(x, needle)*/
    _rc_978 = find_from(_x_977, _needle_964, 1);
    goto L7; // [131] 157
L6: 

    /** 					rc = equal(x, needle)*/
    if (_x_977 == _needle_964)
    _rc_978 = 1;
    else if (IS_ATOM_INT(_x_977) && IS_ATOM_INT(_needle_964))
    _rc_978 = 0;
    else
    _rc_978 = (compare(_x_977, _needle_964) == 0);
    goto L7; // [141] 157
L5: 

    /** 		        rc = call_func(rtn_id, {x, needle})*/
    Ref(_needle_964);
    Ref(_x_977);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _x_977;
    ((int *)_2)[2] = _needle_964;
    _522 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_522);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_rtn_id_967].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4), 
                        *(int *)(_2+8)
                         );
    _rc_978 = _1;
    DeRefDS(_522);
    _522 = NOVALUE;
    if (!IS_ATOM_INT(_rc_978)) {
        _1 = (long)(DBL_PTR(_rc_978)->dbl);
        DeRefDS(_rc_978);
        _rc_978 = _1;
    }
L7: 

    /** 	        if rc then*/
    if (_rc_978 == 0)
    {
        goto L8; // [161] 244
    }
    else{
    }

    /** 	            sequence info*/

    /** 				if depth < length(indexes) then*/
    if (IS_SEQUENCE(_indexes_971)){
            _524 = SEQ_PTR(_indexes_971)->length;
    }
    else {
        _524 = 1;
    }
    if (_depth_969 >= _524)
    goto L9; // [171] 189

    /** 					info = indexes[1..depth] & current_idx*/
    rhs_slice_target = (object_ptr)&_526;
    RHS_Slice(_indexes_971, 1, _depth_969);
    Append(&_info_1002, _526, _current_idx_975);
    DeRefDS(_526);
    _526 = NOVALUE;
    goto LA; // [186] 196
L9: 

    /** 					info = indexes & current_idx*/
    Append(&_info_1002, _indexes_971, _current_idx_975);
LA: 

    /** 	            if and_bits(flags, NESTED_INDEX) then*/
    {unsigned long tu;
         tu = (unsigned long)_flags_966 & (unsigned long)4;
         _529 = MAKE_UINT(tu);
    }
    if (_529 == 0) {
        DeRef(_529);
        _529 = NOVALUE;
        goto LB; // [202] 214
    }
    else {
        if (!IS_ATOM_INT(_529) && DBL_PTR(_529)->dbl == 0.0){
            DeRef(_529);
            _529 = NOVALUE;
            goto LB; // [202] 214
        }
        DeRef(_529);
        _529 = NOVALUE;
    }
    DeRef(_529);
    _529 = NOVALUE;

    /** 	               info = {info, rc}*/
    RefDS(_info_1002);
    _0 = _info_1002;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _info_1002;
    ((int *)_2)[2] = _rc_978;
    _info_1002 = MAKE_SEQ(_1);
    DeRefDS(_0);
LB: 

    /** 	            if and_bits(flags, NESTED_ALL) then*/
    {unsigned long tu;
         tu = (unsigned long)_flags_966 & (unsigned long)2;
         _531 = MAKE_UINT(tu);
    }
    if (_531 == 0) {
        DeRef(_531);
        _531 = NOVALUE;
        goto LC; // [220] 234
    }
    else {
        if (!IS_ATOM_INT(_531) && DBL_PTR(_531)->dbl == 0.0){
            DeRef(_531);
            _531 = NOVALUE;
            goto LC; // [220] 234
        }
        DeRef(_531);
        _531 = NOVALUE;
    }
    DeRef(_531);
    _531 = NOVALUE;

    /** 	                occurrences = append(occurrences, info)*/
    RefDS(_info_1002);
    Append(&_occurrences_968, _occurrences_968, _info_1002);
    goto LD; // [231] 243
LC: 

    /** 	                return info*/
    DeRef(_needle_964);
    DeRefDS(_haystack_965);
    DeRef(_occurrences_968);
    DeRef(_branches_970);
    DeRefi(_indexes_971);
    DeRefi(_last_indexes_972);
    DeRef(_x_977);
    return _info_1002;
LD: 
L8: 
    DeRef(_info_1002);
    _info_1002 = NOVALUE;

    /** 	        if eu:compare(x, {})=1 then*/
    if (IS_ATOM_INT(_x_977) && IS_ATOM_INT(_5)){
        _533 = (_x_977 < _5) ? -1 : (_x_977 > _5);
    }
    else{
        _533 = compare(_x_977, _5);
    }
    if (_533 != 1)
    goto LE; // [252] 351

    /** 				depth += 1*/
    _depth_969 = _depth_969 + 1;

    /** 	            if length(indexes) < depth then*/
    if (IS_SEQUENCE(_indexes_971)){
            _536 = SEQ_PTR(_indexes_971)->length;
    }
    else {
        _536 = 1;
    }
    if (_536 >= _depth_969)
    goto LF; // [267] 292

    /** 	                indexes &= current_idx*/
    Append(&_indexes_971, _indexes_971, _current_idx_975);

    /** 	                branches = append(branches, haystack)*/
    RefDS(_haystack_965);
    Append(&_branches_970, _branches_970, _haystack_965);

    /** 	                last_indexes &= last_idx*/
    Append(&_last_indexes_972, _last_indexes_972, _last_idx_973);
    goto L10; // [289] 311
LF: 

    /** 	                indexes[depth] = current_idx*/
    _2 = (int)SEQ_PTR(_indexes_971);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _indexes_971 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _depth_969);
    *(int *)_2 = _current_idx_975;

    /** 	                branches[depth] = haystack*/
    RefDS(_haystack_965);
    _2 = (int)SEQ_PTR(_branches_970);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _branches_970 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _depth_969);
    _1 = *(int *)_2;
    *(int *)_2 = _haystack_965;
    DeRefDS(_1);

    /** 	                last_indexes[depth] = last_idx*/
    _2 = (int)SEQ_PTR(_last_indexes_972);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _last_indexes_972 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _depth_969);
    *(int *)_2 = _last_idx_973;
L10: 

    /** 	            haystack = x*/
    Ref(_x_977);
    DeRefDS(_haystack_965);
    _haystack_965 = _x_977;

    /** 	            if direction = 1 then*/
    if (_direction_976 != 1)
    goto L11; // [320] 337

    /** 	                current_idx = 1*/
    _current_idx_975 = 1;

    /** 	                last_idx = length(haystack)*/
    if (IS_SEQUENCE(_haystack_965)){
            _last_idx_973 = SEQ_PTR(_haystack_965)->length;
    }
    else {
        _last_idx_973 = 1;
    }
    goto L3; // [334] 97
L11: 

    /** 	                last_idx = 1*/
    _last_idx_973 = 1;

    /** 	                current_idx = length(haystack)*/
    if (IS_SEQUENCE(_haystack_965)){
            _current_idx_975 = SEQ_PTR(_haystack_965)->length;
    }
    else {
        _current_idx_975 = 1;
    }
    goto L3; // [348] 97
LE: 

    /** 				current_idx += direction*/
    _current_idx_975 = _current_idx_975 + _direction_976;

    /** 	    end while*/
    goto L3; // [360] 97
L4: 

    /** 	    if depth=0 then*/
    if (_depth_969 != 0)
    goto L12; // [365] 376

    /** 	        return occurrences -- either accumulated results, or {} if none -> ok*/
    DeRef(_needle_964);
    DeRefDS(_haystack_965);
    DeRef(_branches_970);
    DeRefi(_indexes_971);
    DeRefi(_last_indexes_972);
    DeRef(_x_977);
    return _occurrences_968;
L12: 

    /** 	    haystack = branches[depth]*/
    DeRefDS(_haystack_965);
    _2 = (int)SEQ_PTR(_branches_970);
    _haystack_965 = (int)*(((s1_ptr)_2)->base + _depth_969);
    RefDS(_haystack_965);

    /** 	    last_idx = last_indexes[depth]*/
    _2 = (int)SEQ_PTR(_last_indexes_972);
    _last_idx_973 = (int)*(((s1_ptr)_2)->base + _depth_969);

    /** 	    current_idx = indexes[depth] + direction*/
    _2 = (int)SEQ_PTR(_indexes_971);
    _548 = (int)*(((s1_ptr)_2)->base + _depth_969);
    _current_idx_975 = _548 + _direction_976;
    _548 = NOVALUE;

    /** 	    depth -= 1*/
    _depth_969 = _depth_969 - 1;

    /** 	end while*/
    goto L2; // [410] 92
    ;
}
int find_nested() __attribute__ ((alias ("_9find_nested")));


int _9rfind(int _needle_1044, int _haystack_1045, int _start_1046)
{
    int _len_1048 = NOVALUE;
    int _561 = NOVALUE;
    int _560 = NOVALUE;
    int _557 = NOVALUE;
    int _556 = NOVALUE;
    int _554 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_1046)) {
        _1 = (long)(DBL_PTR(_start_1046)->dbl);
        DeRefDS(_start_1046);
        _start_1046 = _1;
    }

    /** 	integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1045)){
            _len_1048 = SEQ_PTR(_haystack_1045)->length;
    }
    else {
        _len_1048 = 1;
    }

    /** 	if start = 0 then start = len end if*/
    if (_start_1046 != 0)
    goto L1; // [12] 20
    _start_1046 = _len_1048;
L1: 

    /** 	if (start > len) or (len + start < 1) then*/
    _554 = (_start_1046 > _len_1048);
    if (_554 != 0) {
        goto L2; // [26] 43
    }
    _556 = _len_1048 + _start_1046;
    if ((long)((unsigned long)_556 + (unsigned long)HIGH_BITS) >= 0) 
    _556 = NewDouble((double)_556);
    if (IS_ATOM_INT(_556)) {
        _557 = (_556 < 1);
    }
    else {
        _557 = (DBL_PTR(_556)->dbl < (double)1);
    }
    DeRef(_556);
    _556 = NOVALUE;
    if (_557 == 0)
    {
        DeRef(_557);
        _557 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_557);
        _557 = NOVALUE;
    }
L2: 

    /** 		return 0*/
    DeRef(_needle_1044);
    DeRefDS(_haystack_1045);
    DeRef(_554);
    _554 = NOVALUE;
    return 0;
L3: 

    /** 	if start < 1 then*/
    if (_start_1046 >= 1)
    goto L4; // [52] 63

    /** 		start = len + start*/
    _start_1046 = _len_1048 + _start_1046;
L4: 

    /** 	for i = start to 1 by -1 do*/
    {
        int _i_1061;
        _i_1061 = _start_1046;
L5: 
        if (_i_1061 < 1){
            goto L6; // [65] 99
        }

        /** 		if equal(haystack[i], needle) then*/
        _2 = (int)SEQ_PTR(_haystack_1045);
        _560 = (int)*(((s1_ptr)_2)->base + _i_1061);
        if (_560 == _needle_1044)
        _561 = 1;
        else if (IS_ATOM_INT(_560) && IS_ATOM_INT(_needle_1044))
        _561 = 0;
        else
        _561 = (compare(_560, _needle_1044) == 0);
        _560 = NOVALUE;
        if (_561 == 0)
        {
            _561 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _561 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needle_1044);
        DeRefDS(_haystack_1045);
        DeRef(_554);
        _554 = NOVALUE;
        return _i_1061;
L7: 

        /** 	end for*/
        _i_1061 = _i_1061 + -1;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** 	return 0*/
    DeRef(_needle_1044);
    DeRefDS(_haystack_1045);
    DeRef(_554);
    _554 = NOVALUE;
    return 0;
    ;
}
int rfind() __attribute__ ((alias ("_9rfind")));


int _9find_replace(int _needle_1067, int _haystack_1068, int _replacement_1069, int _max_1070)
{
    int _posn_1071 = NOVALUE;
    int _565 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_1070)) {
        _1 = (long)(DBL_PTR(_max_1070)->dbl);
        DeRefDS(_max_1070);
        _max_1070 = _1;
    }

    /** 	integer posn = 0*/
    _posn_1071 = 0;

    /** 	while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1071 == 0)
    goto L3; // [15] 61

    /** 		haystack[posn] = replacement*/
    Ref(_replacement_1069);
    _2 = (int)SEQ_PTR(_haystack_1068);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1068 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _posn_1071);
    _1 = *(int *)_2;
    *(int *)_2 = _replacement_1069;
    DeRef(_1);

    /** 		max -= 1*/
    _max_1070 = _max_1070 - 1;

    /** 		if max = 0 then*/
    if (_max_1070 != 0)
    goto L4; // [33] 42

    /** 			exit*/
    goto L3; // [39] 61
L4: 

    /** 	entry*/
L1: 

    /** 		posn = find(needle, haystack, posn + 1)*/
    _565 = _posn_1071 + 1;
    if (_565 > MAXINT){
        _565 = NewDouble((double)_565);
    }
    _posn_1071 = find_from(_needle_1067, _haystack_1068, _565);
    DeRef(_565);
    _565 = NOVALUE;

    /** 	end while*/
    goto L2; // [58] 15
L3: 

    /** 	return haystack*/
    DeRef(_needle_1067);
    DeRef(_replacement_1069);
    return _haystack_1068;
    ;
}


int _9match_replace(int _needle_1081, int _haystack_1082, int _replacement_1083, int _max_1084)
{
    int _posn_1085 = NOVALUE;
    int _needle_len_1086 = NOVALUE;
    int _replacement_len_1087 = NOVALUE;
    int _scan_from_1088 = NOVALUE;
    int _cnt_1089 = NOVALUE;
    int _577 = NOVALUE;
    int _574 = NOVALUE;
    int _572 = NOVALUE;
    int _570 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_max_1084)) {
        _1 = (long)(DBL_PTR(_max_1084)->dbl);
        DeRefDS(_max_1084);
        _max_1084 = _1;
    }

    /** 	if max < 0 then*/
    if (_max_1084 >= 0)
    goto L1; // [7] 18

    /** 		return haystack*/
    DeRef(_needle_1081);
    DeRef(_replacement_1083);
    return _haystack_1082;
L1: 

    /** 	cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1082)){
            _cnt_1089 = SEQ_PTR(_haystack_1082)->length;
    }
    else {
        _cnt_1089 = 1;
    }

    /** 	if max != 0 then*/
    if (_max_1084 == 0)
    goto L2; // [25] 35

    /** 		cnt = max*/
    _cnt_1089 = _max_1084;
L2: 

    /** 	if atom(needle) then*/
    _570 = IS_ATOM(_needle_1081);
    if (_570 == 0)
    {
        _570 = NOVALUE;
        goto L3; // [40] 50
    }
    else{
        _570 = NOVALUE;
    }

    /** 		needle = {needle}*/
    _0 = _needle_1081;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needle_1081);
    *((int *)(_2+4)) = _needle_1081;
    _needle_1081 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	if atom(replacement) then*/
    _572 = IS_ATOM(_replacement_1083);
    if (_572 == 0)
    {
        _572 = NOVALUE;
        goto L4; // [55] 65
    }
    else{
        _572 = NOVALUE;
    }

    /** 		replacement = {replacement}*/
    _0 = _replacement_1083;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_replacement_1083);
    *((int *)(_2+4)) = _replacement_1083;
    _replacement_1083 = MAKE_SEQ(_1);
    DeRef(_0);
L4: 

    /** 	needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1081)){
            _574 = SEQ_PTR(_needle_1081)->length;
    }
    else {
        _574 = 1;
    }
    _needle_len_1086 = _574 - 1;
    _574 = NOVALUE;

    /** 	replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1083)){
            _replacement_len_1087 = SEQ_PTR(_replacement_1083)->length;
    }
    else {
        _replacement_len_1087 = 1;
    }

    /** 	scan_from = 1*/
    _scan_from_1088 = 1;

    /** 	while posn with entry do*/
    goto L5; // [86] 132
L6: 
    if (_posn_1085 == 0)
    {
        goto L7; // [91] 144
    }
    else{
    }

    /** 		haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _577 = _posn_1085 + _needle_len_1086;
    if ((long)((unsigned long)_577 + (unsigned long)HIGH_BITS) >= 0) 
    _577 = NewDouble((double)_577);
    {
        int p1 = _haystack_1082;
        int p2 = _replacement_1083;
        int p3 = _posn_1085;
        int p4 = _577;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1082;
        Replace( &replace_params );
    }
    DeRef(_577);
    _577 = NOVALUE;

    /** 		cnt -= 1*/
    _cnt_1089 = _cnt_1089 - 1;

    /** 		if cnt = 0 then*/
    if (_cnt_1089 != 0)
    goto L8; // [114] 123

    /** 			exit*/
    goto L7; // [120] 144
L8: 

    /** 		scan_from = posn + replacement_len*/
    _scan_from_1088 = _posn_1085 + _replacement_len_1087;

    /** 	entry*/
L5: 

    /** 		posn = match(needle, haystack, scan_from)*/
    _posn_1085 = e_match_from(_needle_1081, _haystack_1082, _scan_from_1088);

    /** 	end while*/
    goto L6; // [141] 89
L7: 

    /** 	return haystack*/
    DeRef(_needle_1081);
    DeRef(_replacement_1083);
    return _haystack_1082;
    ;
}
int match_replace() __attribute__ ((alias ("_9match_replace")));


int _9binary_search(int _needle_1114, int _haystack_1115, int _start_point_1116, int _end_point_1117)
{
    int _lo_1118 = NOVALUE;
    int _hi_1119 = NOVALUE;
    int _mid_1120 = NOVALUE;
    int _c_1121 = NOVALUE;
    int _603 = NOVALUE;
    int _595 = NOVALUE;
    int _593 = NOVALUE;
    int _590 = NOVALUE;
    int _589 = NOVALUE;
    int _588 = NOVALUE;
    int _587 = NOVALUE;
    int _584 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_point_1116)) {
        _1 = (long)(DBL_PTR(_start_point_1116)->dbl);
        DeRefDS(_start_point_1116);
        _start_point_1116 = _1;
    }
    if (!IS_ATOM_INT(_end_point_1117)) {
        _1 = (long)(DBL_PTR(_end_point_1117)->dbl);
        DeRefDS(_end_point_1117);
        _end_point_1117 = _1;
    }

    /** 	lo = start_point*/
    _lo_1118 = _start_point_1116;

    /** 	if end_point <= 0 then*/
    if (_end_point_1117 > 0)
    goto L1; // [14] 30

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_1115)){
            _584 = SEQ_PTR(_haystack_1115)->length;
    }
    else {
        _584 = 1;
    }
    _hi_1119 = _584 + _end_point_1117;
    _584 = NOVALUE;
    goto L2; // [27] 36
L1: 

    /** 		hi = end_point*/
    _hi_1119 = _end_point_1117;
L2: 

    /** 	if lo<1 then*/
    if (_lo_1118 >= 1)
    goto L3; // [38] 48

    /** 		lo=1*/
    _lo_1118 = 1;
L3: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _587 = (_lo_1118 > _hi_1119);
    if (_587 == 0) {
        goto L4; // [56] 77
    }
    if (IS_SEQUENCE(_haystack_1115)){
            _589 = SEQ_PTR(_haystack_1115)->length;
    }
    else {
        _589 = 1;
    }
    _590 = (_589 > 0);
    _589 = NOVALUE;
    if (_590 == 0)
    {
        DeRef(_590);
        _590 = NOVALUE;
        goto L4; // [68] 77
    }
    else{
        DeRef(_590);
        _590 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1115)){
            _hi_1119 = SEQ_PTR(_haystack_1115)->length;
    }
    else {
        _hi_1119 = 1;
    }
L4: 

    /** 	mid = start_point*/
    _mid_1120 = _start_point_1116;

    /** 	c = 0*/
    _c_1121 = 0;

    /** 	while lo <= hi do*/
L5: 
    if (_lo_1118 > _hi_1119)
    goto L6; // [92] 160

    /** 		mid = floor((lo + hi) / 2)*/
    _593 = _lo_1118 + _hi_1119;
    if ((long)((unsigned long)_593 + (unsigned long)HIGH_BITS) >= 0) 
    _593 = NewDouble((double)_593);
    if (IS_ATOM_INT(_593)) {
        _mid_1120 = _593 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _593, 2);
        _mid_1120 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_593);
    _593 = NOVALUE;
    if (!IS_ATOM_INT(_mid_1120)) {
        _1 = (long)(DBL_PTR(_mid_1120)->dbl);
        DeRefDS(_mid_1120);
        _mid_1120 = _1;
    }

    /** 		c = eu:compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_1115);
    _595 = (int)*(((s1_ptr)_2)->base + _mid_1120);
    if (IS_ATOM_INT(_needle_1114) && IS_ATOM_INT(_595)){
        _c_1121 = (_needle_1114 < _595) ? -1 : (_needle_1114 > _595);
    }
    else{
        _c_1121 = compare(_needle_1114, _595);
    }
    _595 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_1121 >= 0)
    goto L7; // [120] 133

    /** 			hi = mid - 1*/
    _hi_1119 = _mid_1120 - 1;
    goto L5; // [130] 92
L7: 

    /** 		elsif c > 0 then*/
    if (_c_1121 <= 0)
    goto L8; // [135] 148

    /** 			lo = mid + 1*/
    _lo_1118 = _mid_1120 + 1;
    goto L5; // [145] 92
L8: 

    /** 			return mid*/
    DeRef(_needle_1114);
    DeRefDS(_haystack_1115);
    DeRef(_587);
    _587 = NOVALUE;
    return _mid_1120;

    /** 	end while*/
    goto L5; // [157] 92
L6: 

    /** 	if c > 0 then*/
    if (_c_1121 <= 0)
    goto L9; // [162] 173

    /** 		mid += 1*/
    _mid_1120 = _mid_1120 + 1;
L9: 

    /** 	return -mid*/
    if ((unsigned long)_mid_1120 == 0xC0000000)
    _603 = (int)NewDouble((double)-0xC0000000);
    else
    _603 = - _mid_1120;
    DeRef(_needle_1114);
    DeRefDS(_haystack_1115);
    DeRef(_587);
    _587 = NOVALUE;
    return _603;
    ;
}
int binary_search() __attribute__ ((alias ("_9binary_search")));


int _9match_all(int _needle_1154, int _haystack_1155, int _start_1156)
{
    int _kx_1157 = NOVALUE;
    int _610 = NOVALUE;
    int _609 = NOVALUE;
    int _606 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_1156)) {
        _1 = (long)(DBL_PTR(_start_1156)->dbl);
        DeRefDS(_start_1156);
        _start_1156 = _1;
    }

    /** 	integer kx = 0*/
    _kx_1157 = 0;

    /** 	while start > 0 with entry do*/
    goto L1; // [14] 45
L2: 
    if (_start_1156 <= 0)
    goto L3; // [17] 57

    /** 		kx += 1*/
    _kx_1157 = _kx_1157 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_1155);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1155 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_1157);
    _1 = *(int *)_2;
    *(int *)_2 = _start_1156;
    DeRef(_1);

    /** 		start += length(needle)*/
    if (IS_SEQUENCE(_needle_1154)){
            _606 = SEQ_PTR(_needle_1154)->length;
    }
    else {
        _606 = 1;
    }
    _start_1156 = _start_1156 + _606;
    _606 = NOVALUE;

    /** 	entry*/
L1: 

    /** 		start = match(needle, haystack, start)*/
    _start_1156 = e_match_from(_needle_1154, _haystack_1155, _start_1156);

    /** 	end while*/
    goto L2; // [54] 17
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _609 = _kx_1157 + 1;
    if (_609 > MAXINT){
        _609 = NewDouble((double)_609);
    }
    if (IS_SEQUENCE(_haystack_1155)){
            _610 = SEQ_PTR(_haystack_1155)->length;
    }
    else {
        _610 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1155);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_609)) ? _609 : (long)(DBL_PTR(_609)->dbl);
        int stop = (IS_ATOM_INT(_610)) ? _610 : (long)(DBL_PTR(_610)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1155), start, &_haystack_1155 );
            }
            else Tail(SEQ_PTR(_haystack_1155), stop+1, &_haystack_1155);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1155), start, &_haystack_1155);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1155 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1155)->ref == 1));
        }
    }
    DeRef(_609);
    _609 = NOVALUE;
    _610 = NOVALUE;

    /** 	return haystack*/
    DeRefDS(_needle_1154);
    return _haystack_1155;
    ;
}
int match_all() __attribute__ ((alias ("_9match_all")));


int _9rmatch(int _needle_1169, int _haystack_1170, int _start_1171)
{
    int _len_1173 = NOVALUE;
    int _lenX_1174 = NOVALUE;
    int _630 = NOVALUE;
    int _629 = NOVALUE;
    int _628 = NOVALUE;
    int _625 = NOVALUE;
    int _623 = NOVALUE;
    int _622 = NOVALUE;
    int _619 = NOVALUE;
    int _618 = NOVALUE;
    int _616 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_1171)) {
        _1 = (long)(DBL_PTR(_start_1171)->dbl);
        DeRefDS(_start_1171);
        _start_1171 = _1;
    }

    /** 	len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1170)){
            _len_1173 = SEQ_PTR(_haystack_1170)->length;
    }
    else {
        _len_1173 = 1;
    }

    /** 	lenX = length(needle)*/
    if (IS_SEQUENCE(_needle_1169)){
            _lenX_1174 = SEQ_PTR(_needle_1169)->length;
    }
    else {
        _lenX_1174 = 1;
    }

    /** 	if lenX = 0 then*/
    if (_lenX_1174 != 0)
    goto L1; // [19] 32

    /** 		return 0*/
    DeRefDS(_needle_1169);
    DeRefDS(_haystack_1170);
    return 0;
    goto L2; // [29] 63
L1: 

    /** 	elsif (start > len) or  (len + start < 1) then*/
    _616 = (_start_1171 > _len_1173);
    if (_616 != 0) {
        goto L3; // [38] 55
    }
    _618 = _len_1173 + _start_1171;
    if ((long)((unsigned long)_618 + (unsigned long)HIGH_BITS) >= 0) 
    _618 = NewDouble((double)_618);
    if (IS_ATOM_INT(_618)) {
        _619 = (_618 < 1);
    }
    else {
        _619 = (DBL_PTR(_618)->dbl < (double)1);
    }
    DeRef(_618);
    _618 = NOVALUE;
    if (_619 == 0)
    {
        DeRef(_619);
        _619 = NOVALUE;
        goto L4; // [51] 62
    }
    else{
        DeRef(_619);
        _619 = NOVALUE;
    }
L3: 

    /** 		return 0*/
    DeRefDS(_needle_1169);
    DeRefDS(_haystack_1170);
    DeRef(_616);
    _616 = NOVALUE;
    return 0;
L4: 
L2: 

    /** 	if start < 1 then*/
    if (_start_1171 >= 1)
    goto L5; // [65] 76

    /** 		start = len + start*/
    _start_1171 = _len_1173 + _start_1171;
L5: 

    /** 	if start + lenX - 1 > len then*/
    _622 = _start_1171 + _lenX_1174;
    if ((long)((unsigned long)_622 + (unsigned long)HIGH_BITS) >= 0) 
    _622 = NewDouble((double)_622);
    if (IS_ATOM_INT(_622)) {
        _623 = _622 - 1;
        if ((long)((unsigned long)_623 +(unsigned long) HIGH_BITS) >= 0){
            _623 = NewDouble((double)_623);
        }
    }
    else {
        _623 = NewDouble(DBL_PTR(_622)->dbl - (double)1);
    }
    DeRef(_622);
    _622 = NOVALUE;
    if (binary_op_a(LESSEQ, _623, _len_1173)){
        DeRef(_623);
        _623 = NOVALUE;
        goto L6; // [86] 101
    }
    DeRef(_623);
    _623 = NOVALUE;

    /** 		start = len - lenX + 1*/
    _625 = _len_1173 - _lenX_1174;
    if ((long)((unsigned long)_625 +(unsigned long) HIGH_BITS) >= 0){
        _625 = NewDouble((double)_625);
    }
    if (IS_ATOM_INT(_625)) {
        _start_1171 = _625 + 1;
    }
    else
    { // coercing _start_1171 to an integer 1
        _start_1171 = 1+(long)(DBL_PTR(_625)->dbl);
        if( !IS_ATOM_INT(_start_1171) ){
            _start_1171 = (object)DBL_PTR(_start_1171)->dbl;
        }
    }
    DeRef(_625);
    _625 = NOVALUE;
L6: 

    /** 	lenX -= 1*/
    _lenX_1174 = _lenX_1174 - 1;

    /** 	for i=start to 1 by -1 do*/
    {
        int _i_1195;
        _i_1195 = _start_1171;
L7: 
        if (_i_1195 < 1){
            goto L8; // [109] 148
        }

        /** 		if equal(needle, haystack[i..i + lenX]) then*/
        _628 = _i_1195 + _lenX_1174;
        rhs_slice_target = (object_ptr)&_629;
        RHS_Slice(_haystack_1170, _i_1195, _628);
        if (_needle_1169 == _629)
        _630 = 1;
        else if (IS_ATOM_INT(_needle_1169) && IS_ATOM_INT(_629))
        _630 = 0;
        else
        _630 = (compare(_needle_1169, _629) == 0);
        DeRefDS(_629);
        _629 = NOVALUE;
        if (_630 == 0)
        {
            _630 = NOVALUE;
            goto L9; // [131] 141
        }
        else{
            _630 = NOVALUE;
        }

        /** 			return i*/
        DeRefDS(_needle_1169);
        DeRefDS(_haystack_1170);
        DeRef(_616);
        _616 = NOVALUE;
        _628 = NOVALUE;
        return _i_1195;
L9: 

        /** 	end for*/
        _i_1195 = _i_1195 + -1;
        goto L7; // [143] 116
L8: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_needle_1169);
    DeRefDS(_haystack_1170);
    DeRef(_616);
    _616 = NOVALUE;
    DeRef(_628);
    _628 = NOVALUE;
    return 0;
    ;
}
int rmatch() __attribute__ ((alias ("_9rmatch")));


int _9begins(int _sub_text_1202, int _full_text_1203)
{
    int _641 = NOVALUE;
    int _640 = NOVALUE;
    int _639 = NOVALUE;
    int _637 = NOVALUE;
    int _636 = NOVALUE;
    int _635 = NOVALUE;
    int _634 = NOVALUE;
    int _633 = NOVALUE;
    int _631 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1203)){
            _631 = SEQ_PTR(_full_text_1203)->length;
    }
    else {
        _631 = 1;
    }
    if (_631 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _633 = IS_ATOM(_sub_text_1202);
    if (_633 == 0)
    {
        _633 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _633 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[1]) then*/
    _2 = (int)SEQ_PTR(_full_text_1203);
    _634 = (int)*(((s1_ptr)_2)->base + 1);
    if (_sub_text_1202 == _634)
    _635 = 1;
    else if (IS_ATOM_INT(_sub_text_1202) && IS_ATOM_INT(_634))
    _635 = 0;
    else
    _635 = (compare(_sub_text_1202, _634) == 0);
    _634 = NOVALUE;
    if (_635 == 0)
    {
        _635 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _635 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 1;
    goto L4; // [46] 56
L3: 

    /** 			return 0*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1202)){
            _636 = SEQ_PTR(_sub_text_1202)->length;
    }
    else {
        _636 = 1;
    }
    if (IS_SEQUENCE(_full_text_1203)){
            _637 = SEQ_PTR(_full_text_1203)->length;
    }
    else {
        _637 = 1;
    }
    if (_636 <= _637)
    goto L5; // [65] 76

    /** 		return 0*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1202)){
            _639 = SEQ_PTR(_sub_text_1202)->length;
    }
    else {
        _639 = 1;
    }
    rhs_slice_target = (object_ptr)&_640;
    RHS_Slice(_full_text_1203, 1, _639);
    if (_sub_text_1202 == _640)
    _641 = 1;
    else if (IS_ATOM_INT(_sub_text_1202) && IS_ATOM_INT(_640))
    _641 = 0;
    else
    _641 = (compare(_sub_text_1202, _640) == 0);
    DeRefDS(_640);
    _640 = NOVALUE;
    if (_641 == 0)
    {
        _641 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _641 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 1;
    goto L7; // [99] 109
L6: 

    /** 		return 0*/
    DeRef(_sub_text_1202);
    DeRefDS(_full_text_1203);
    return 0;
L7: 
    ;
}
int begins() __attribute__ ((alias ("_9begins")));


int _9ends(int _sub_text_1224, int _full_text_1225)
{
    int _657 = NOVALUE;
    int _656 = NOVALUE;
    int _655 = NOVALUE;
    int _654 = NOVALUE;
    int _653 = NOVALUE;
    int _652 = NOVALUE;
    int _651 = NOVALUE;
    int _649 = NOVALUE;
    int _648 = NOVALUE;
    int _647 = NOVALUE;
    int _646 = NOVALUE;
    int _645 = NOVALUE;
    int _644 = NOVALUE;
    int _642 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1225)){
            _642 = SEQ_PTR(_full_text_1225)->length;
    }
    else {
        _642 = 1;
    }
    if (_642 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _644 = IS_ATOM(_sub_text_1224);
    if (_644 == 0)
    {
        _644 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _644 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1225)){
            _645 = SEQ_PTR(_full_text_1225)->length;
    }
    else {
        _645 = 1;
    }
    _2 = (int)SEQ_PTR(_full_text_1225);
    _646 = (int)*(((s1_ptr)_2)->base + _645);
    if (_sub_text_1224 == _646)
    _647 = 1;
    else if (IS_ATOM_INT(_sub_text_1224) && IS_ATOM_INT(_646))
    _647 = 0;
    else
    _647 = (compare(_sub_text_1224, _646) == 0);
    _646 = NOVALUE;
    if (_647 == 0)
    {
        _647 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _647 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    return 1;
    goto L4; // [49] 59
L3: 

    /** 			return 0*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1224)){
            _648 = SEQ_PTR(_sub_text_1224)->length;
    }
    else {
        _648 = 1;
    }
    if (IS_SEQUENCE(_full_text_1225)){
            _649 = SEQ_PTR(_full_text_1225)->length;
    }
    else {
        _649 = 1;
    }
    if (_648 <= _649)
    goto L5; // [68] 79

    /** 		return 0*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1225)){
            _651 = SEQ_PTR(_full_text_1225)->length;
    }
    else {
        _651 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1224)){
            _652 = SEQ_PTR(_sub_text_1224)->length;
    }
    else {
        _652 = 1;
    }
    _653 = _651 - _652;
    _651 = NOVALUE;
    _652 = NOVALUE;
    _654 = _653 + 1;
    _653 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1225)){
            _655 = SEQ_PTR(_full_text_1225)->length;
    }
    else {
        _655 = 1;
    }
    rhs_slice_target = (object_ptr)&_656;
    RHS_Slice(_full_text_1225, _654, _655);
    if (_sub_text_1224 == _656)
    _657 = 1;
    else if (IS_ATOM_INT(_sub_text_1224) && IS_ATOM_INT(_656))
    _657 = 0;
    else
    _657 = (compare(_sub_text_1224, _656) == 0);
    DeRefDS(_656);
    _656 = NOVALUE;
    if (_657 == 0)
    {
        _657 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _657 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    _654 = NOVALUE;
    return 1;
    goto L7; // [116] 126
L6: 

    /** 		return 0*/
    DeRef(_sub_text_1224);
    DeRefDS(_full_text_1225);
    DeRef(_654);
    _654 = NOVALUE;
    return 0;
L7: 
    ;
}
int ends() __attribute__ ((alias ("_9ends")));


int _9is_in_range(int _item_1251, int _range_limits_1252, int _boundries_1253)
{
    int _692 = NOVALUE;
    int _691 = NOVALUE;
    int _690 = NOVALUE;
    int _688 = NOVALUE;
    int _687 = NOVALUE;
    int _685 = NOVALUE;
    int _684 = NOVALUE;
    int _683 = NOVALUE;
    int _681 = NOVALUE;
    int _680 = NOVALUE;
    int _677 = NOVALUE;
    int _676 = NOVALUE;
    int _675 = NOVALUE;
    int _673 = NOVALUE;
    int _672 = NOVALUE;
    int _669 = NOVALUE;
    int _668 = NOVALUE;
    int _667 = NOVALUE;
    int _665 = NOVALUE;
    int _664 = NOVALUE;
    int _659 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(range_limits) < 2 then*/
    if (IS_SEQUENCE(_range_limits_1252)){
            _659 = SEQ_PTR(_range_limits_1252)->length;
    }
    else {
        _659 = 1;
    }
    if (_659 >= 2)
    goto L1; // [10] 21

    /** 		return 0*/
    DeRef(_item_1251);
    DeRefDS(_range_limits_1252);
    DeRefDS(_boundries_1253);
    return 0;
L1: 

    /** 	switch boundries do*/
    _1 = find(_boundries_1253, _661);
    switch ( _1 ){ 

        /** 		case "()" then*/
        case 1:

        /** 			if eu:compare(item, range_limits[1]) <= 0 then*/
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _664 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_664)){
            _665 = (_item_1251 < _664) ? -1 : (_item_1251 > _664);
        }
        else{
            _665 = compare(_item_1251, _664);
        }
        _664 = NOVALUE;
        if (_665 > 0)
        goto L2; // [42] 53

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
L2: 

        /** 			if eu:compare(item, range_limits[$]) >= 0 then*/
        if (IS_SEQUENCE(_range_limits_1252)){
                _667 = SEQ_PTR(_range_limits_1252)->length;
        }
        else {
            _667 = 1;
        }
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _668 = (int)*(((s1_ptr)_2)->base + _667);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_668)){
            _669 = (_item_1251 < _668) ? -1 : (_item_1251 > _668);
        }
        else{
            _669 = compare(_item_1251, _668);
        }
        _668 = NOVALUE;
        if (_669 < 0)
        goto L3; // [66] 231

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
        goto L3; // [77] 231

        /** 		case "[)" then*/
        case 2:

        /** 			if eu:compare(item, range_limits[1]) < 0 then*/
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _672 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_672)){
            _673 = (_item_1251 < _672) ? -1 : (_item_1251 > _672);
        }
        else{
            _673 = compare(_item_1251, _672);
        }
        _672 = NOVALUE;
        if (_673 >= 0)
        goto L4; // [93] 104

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
L4: 

        /** 			if eu:compare(item, range_limits[$]) >= 0 then*/
        if (IS_SEQUENCE(_range_limits_1252)){
                _675 = SEQ_PTR(_range_limits_1252)->length;
        }
        else {
            _675 = 1;
        }
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _676 = (int)*(((s1_ptr)_2)->base + _675);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_676)){
            _677 = (_item_1251 < _676) ? -1 : (_item_1251 > _676);
        }
        else{
            _677 = compare(_item_1251, _676);
        }
        _676 = NOVALUE;
        if (_677 < 0)
        goto L3; // [117] 231

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
        goto L3; // [128] 231

        /** 		case "(]" then*/
        case 3:

        /** 			if eu:compare(item, range_limits[1]) <= 0 then*/
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _680 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_680)){
            _681 = (_item_1251 < _680) ? -1 : (_item_1251 > _680);
        }
        else{
            _681 = compare(_item_1251, _680);
        }
        _680 = NOVALUE;
        if (_681 > 0)
        goto L5; // [144] 155

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
L5: 

        /** 			if eu:compare(item, range_limits[$]) > 0 then*/
        if (IS_SEQUENCE(_range_limits_1252)){
                _683 = SEQ_PTR(_range_limits_1252)->length;
        }
        else {
            _683 = 1;
        }
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _684 = (int)*(((s1_ptr)_2)->base + _683);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_684)){
            _685 = (_item_1251 < _684) ? -1 : (_item_1251 > _684);
        }
        else{
            _685 = compare(_item_1251, _684);
        }
        _684 = NOVALUE;
        if (_685 <= 0)
        goto L3; // [168] 231

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
        goto L3; // [179] 231

        /** 		case else*/
        case 0:

        /** 			if eu:compare(item, range_limits[1]) < 0 then*/
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _687 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_687)){
            _688 = (_item_1251 < _687) ? -1 : (_item_1251 > _687);
        }
        else{
            _688 = compare(_item_1251, _687);
        }
        _687 = NOVALUE;
        if (_688 >= 0)
        goto L6; // [195] 206

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
L6: 

        /** 			if eu:compare(item, range_limits[$]) > 0 then*/
        if (IS_SEQUENCE(_range_limits_1252)){
                _690 = SEQ_PTR(_range_limits_1252)->length;
        }
        else {
            _690 = 1;
        }
        _2 = (int)SEQ_PTR(_range_limits_1252);
        _691 = (int)*(((s1_ptr)_2)->base + _690);
        if (IS_ATOM_INT(_item_1251) && IS_ATOM_INT(_691)){
            _692 = (_item_1251 < _691) ? -1 : (_item_1251 > _691);
        }
        else{
            _692 = compare(_item_1251, _691);
        }
        _691 = NOVALUE;
        if (_692 <= 0)
        goto L7; // [219] 230

        /** 				return 0*/
        DeRef(_item_1251);
        DeRefDS(_range_limits_1252);
        DeRefDS(_boundries_1253);
        return 0;
L7: 
    ;}L3: 

    /** 	return 1*/
    DeRef(_item_1251);
    DeRefDS(_range_limits_1252);
    DeRefDS(_boundries_1253);
    return 1;
    ;
}
int is_in_range() __attribute__ ((alias ("_9is_in_range")));


int _9is_in_list(int _item_1305, int _list_1306)
{
    int _695 = NOVALUE;
    int _694 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return (find(item, list) != 0)*/
    _694 = find_from(_item_1305, _list_1306, 1);
    _695 = (_694 != 0);
    _694 = NOVALUE;
    DeRef(_item_1305);
    DeRefDS(_list_1306);
    return _695;
    ;
}
int is_in_list() __attribute__ ((alias ("_9is_in_list")));


int _9lookup(int _find_item_1311, int _source_list_1312, int _target_list_1313, int _def_value_1314)
{
    int _lPosn_1315 = NOVALUE;
    int _704 = NOVALUE;
    int _703 = NOVALUE;
    int _701 = NOVALUE;
    int _700 = NOVALUE;
    int _699 = NOVALUE;
    int _697 = NOVALUE;
    int _0, _1, _2;
    

    /**     lPosn = find(find_item, source_list)*/
    _lPosn_1315 = find_from(_find_item_1311, _source_list_1312, 1);

    /**     if lPosn then*/
    if (_lPosn_1315 == 0)
    {
        goto L1; // [14] 49
    }
    else{
    }

    /**         if lPosn <= length(target_list) then*/
    if (IS_SEQUENCE(_target_list_1313)){
            _697 = SEQ_PTR(_target_list_1313)->length;
    }
    else {
        _697 = 1;
    }
    if (_lPosn_1315 > _697)
    goto L2; // [22] 39

    /**             return target_list[lPosn]*/
    _2 = (int)SEQ_PTR(_target_list_1313);
    _699 = (int)*(((s1_ptr)_2)->base + _lPosn_1315);
    Ref(_699);
    DeRef(_find_item_1311);
    DeRefDS(_source_list_1312);
    DeRefDS(_target_list_1313);
    DeRef(_def_value_1314);
    return _699;
    goto L3; // [36] 84
L2: 

    /**         	return def_value*/
    DeRef(_find_item_1311);
    DeRefDS(_source_list_1312);
    DeRefDS(_target_list_1313);
    _699 = NOVALUE;
    return _def_value_1314;
    goto L3; // [46] 84
L1: 

    /**     elsif length(target_list) > length(source_list) then*/
    if (IS_SEQUENCE(_target_list_1313)){
            _700 = SEQ_PTR(_target_list_1313)->length;
    }
    else {
        _700 = 1;
    }
    if (IS_SEQUENCE(_source_list_1312)){
            _701 = SEQ_PTR(_source_list_1312)->length;
    }
    else {
        _701 = 1;
    }
    if (_700 <= _701)
    goto L4; // [57] 77

    /**         return target_list[$]*/
    if (IS_SEQUENCE(_target_list_1313)){
            _703 = SEQ_PTR(_target_list_1313)->length;
    }
    else {
        _703 = 1;
    }
    _2 = (int)SEQ_PTR(_target_list_1313);
    _704 = (int)*(((s1_ptr)_2)->base + _703);
    Ref(_704);
    DeRef(_find_item_1311);
    DeRefDS(_source_list_1312);
    DeRefDS(_target_list_1313);
    DeRef(_def_value_1314);
    _699 = NOVALUE;
    return _704;
    goto L3; // [74] 84
L4: 

    /**     	return def_value*/
    DeRef(_find_item_1311);
    DeRefDS(_source_list_1312);
    DeRefDS(_target_list_1313);
    _699 = NOVALUE;
    _704 = NOVALUE;
    return _def_value_1314;
L3: 
    ;
}
int lookup() __attribute__ ((alias ("_9lookup")));


int _9vlookup(int _find_item_1332, int _grid_data_1333, int _source_col_1334, int _target_col_1335, int _def_value_1336)
{
    int _718 = NOVALUE;
    int _717 = NOVALUE;
    int _715 = NOVALUE;
    int _714 = NOVALUE;
    int _713 = NOVALUE;
    int _712 = NOVALUE;
    int _711 = NOVALUE;
    int _709 = NOVALUE;
    int _708 = NOVALUE;
    int _707 = NOVALUE;
    int _706 = NOVALUE;
    int _705 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_source_col_1334)) {
        _1 = (long)(DBL_PTR(_source_col_1334)->dbl);
        DeRefDS(_source_col_1334);
        _source_col_1334 = _1;
    }
    if (!IS_ATOM_INT(_target_col_1335)) {
        _1 = (long)(DBL_PTR(_target_col_1335)->dbl);
        DeRefDS(_target_col_1335);
        _target_col_1335 = _1;
    }

    /**     for i = 1 to length(grid_data) do*/
    if (IS_SEQUENCE(_grid_data_1333)){
            _705 = SEQ_PTR(_grid_data_1333)->length;
    }
    else {
        _705 = 1;
    }
    {
        int _i_1338;
        _i_1338 = 1;
L1: 
        if (_i_1338 > _705){
            goto L2; // [12] 113
        }

        /**     	if atom(grid_data[i]) then*/
        _2 = (int)SEQ_PTR(_grid_data_1333);
        _706 = (int)*(((s1_ptr)_2)->base + _i_1338);
        _707 = IS_ATOM(_706);
        _706 = NOVALUE;
        if (_707 == 0)
        {
            _707 = NOVALUE;
            goto L3; // [28] 36
        }
        else{
            _707 = NOVALUE;
        }

        /**     		continue*/
        goto L4; // [33] 108
L3: 

        /**     	if length(grid_data[i]) < source_col then*/
        _2 = (int)SEQ_PTR(_grid_data_1333);
        _708 = (int)*(((s1_ptr)_2)->base + _i_1338);
        if (IS_SEQUENCE(_708)){
                _709 = SEQ_PTR(_708)->length;
        }
        else {
            _709 = 1;
        }
        _708 = NOVALUE;
        if (_709 >= _source_col_1334)
        goto L5; // [45] 54

        /**     		continue*/
        goto L4; // [51] 108
L5: 

        /**     	if equal(find_item, grid_data[i][source_col]) then*/
        _2 = (int)SEQ_PTR(_grid_data_1333);
        _711 = (int)*(((s1_ptr)_2)->base + _i_1338);
        _2 = (int)SEQ_PTR(_711);
        _712 = (int)*(((s1_ptr)_2)->base + _source_col_1334);
        _711 = NOVALUE;
        if (_find_item_1332 == _712)
        _713 = 1;
        else if (IS_ATOM_INT(_find_item_1332) && IS_ATOM_INT(_712))
        _713 = 0;
        else
        _713 = (compare(_find_item_1332, _712) == 0);
        _712 = NOVALUE;
        if (_713 == 0)
        {
            _713 = NOVALUE;
            goto L6; // [68] 106
        }
        else{
            _713 = NOVALUE;
        }

        /** 	    	if length(grid_data[i]) < target_col then*/
        _2 = (int)SEQ_PTR(_grid_data_1333);
        _714 = (int)*(((s1_ptr)_2)->base + _i_1338);
        if (IS_SEQUENCE(_714)){
                _715 = SEQ_PTR(_714)->length;
        }
        else {
            _715 = 1;
        }
        _714 = NOVALUE;
        if (_715 >= _target_col_1335)
        goto L7; // [80] 91

        /**     			return def_value*/
        DeRef(_find_item_1332);
        DeRefDS(_grid_data_1333);
        _708 = NOVALUE;
        _714 = NOVALUE;
        return _def_value_1336;
L7: 

        /**     		return grid_data[i][target_col]*/
        _2 = (int)SEQ_PTR(_grid_data_1333);
        _717 = (int)*(((s1_ptr)_2)->base + _i_1338);
        _2 = (int)SEQ_PTR(_717);
        _718 = (int)*(((s1_ptr)_2)->base + _target_col_1335);
        _717 = NOVALUE;
        Ref(_718);
        DeRef(_find_item_1332);
        DeRefDS(_grid_data_1333);
        DeRef(_def_value_1336);
        _708 = NOVALUE;
        _714 = NOVALUE;
        return _718;
L6: 

        /**     end for*/
L4: 
        _i_1338 = _i_1338 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /**     return def_value*/
    DeRef(_find_item_1332);
    DeRefDS(_grid_data_1333);
    _708 = NOVALUE;
    _714 = NOVALUE;
    _718 = NOVALUE;
    return _def_value_1336;
    ;
}
int vlookup() __attribute__ ((alias ("_9vlookup")));



// 0x394CDB5A
