// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _23binop_ok(int _a_5281, int _b_5282)
{
    int _2738 = NOVALUE;
    int _2737 = NOVALUE;
    int _2736 = NOVALUE;
    int _2735 = NOVALUE;
    int _2733 = NOVALUE;
    int _2732 = NOVALUE;
    int _2731 = NOVALUE;
    int _2729 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) or atom(b) then*/
    _2729 = IS_ATOM(_a_5281);
    if (_2729 != 0) {
        goto L1; // [6] 18
    }
    _2731 = IS_ATOM(_b_5282);
    if (_2731 == 0)
    {
        _2731 = NOVALUE;
        goto L2; // [14] 25
    }
    else{
        _2731 = NOVALUE;
    }
L1: 

    /** 		return 1*/
    DeRef(_a_5281);
    DeRef(_b_5282);
    return 1;
L2: 

    /** 	if length(a) != length(b) then*/
    if (IS_SEQUENCE(_a_5281)){
            _2732 = SEQ_PTR(_a_5281)->length;
    }
    else {
        _2732 = 1;
    }
    if (IS_SEQUENCE(_b_5282)){
            _2733 = SEQ_PTR(_b_5282)->length;
    }
    else {
        _2733 = 1;
    }
    if (_2732 == _2733)
    goto L3; // [33] 44

    /** 		return 0*/
    DeRef(_a_5281);
    DeRef(_b_5282);
    return 0;
L3: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_5281)){
            _2735 = SEQ_PTR(_a_5281)->length;
    }
    else {
        _2735 = 1;
    }
    {
        int _i_5292;
        _i_5292 = 1;
L4: 
        if (_i_5292 > _2735){
            goto L5; // [49] 88
        }

        /** 		if not binop_ok(a[i], b[i]) then*/
        _2 = (int)SEQ_PTR(_a_5281);
        _2736 = (int)*(((s1_ptr)_2)->base + _i_5292);
        _2 = (int)SEQ_PTR(_b_5282);
        _2737 = (int)*(((s1_ptr)_2)->base + _i_5292);
        Ref(_2736);
        Ref(_2737);
        _2738 = _23binop_ok(_2736, _2737);
        _2736 = NOVALUE;
        _2737 = NOVALUE;
        if (IS_ATOM_INT(_2738)) {
            if (_2738 != 0){
                DeRef(_2738);
                _2738 = NOVALUE;
                goto L6; // [71] 81
            }
        }
        else {
            if (DBL_PTR(_2738)->dbl != 0.0){
                DeRef(_2738);
                _2738 = NOVALUE;
                goto L6; // [71] 81
            }
        }
        DeRef(_2738);
        _2738 = NOVALUE;

        /** 			return 0*/
        DeRef(_a_5281);
        DeRef(_b_5282);
        return 0;
L6: 

        /** 	end for*/
        _i_5292 = _i_5292 + 1;
        goto L4; // [83] 56
L5: 
        ;
    }

    /** 	return 1*/
    DeRef(_a_5281);
    DeRef(_b_5282);
    return 1;
    ;
}
int binop_ok() __attribute__ ((alias ("_23binop_ok")));


int _23fetch(int _source_5301, int _indexes_5302)
{
    int _x_5303 = NOVALUE;
    int _2750 = NOVALUE;
    int _2749 = NOVALUE;
    int _2748 = NOVALUE;
    int _2747 = NOVALUE;
    int _2746 = NOVALUE;
    int _2744 = NOVALUE;
    int _2742 = NOVALUE;
    int _2741 = NOVALUE;
    int _2740 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i=1 to length(indexes)-1 do*/
    if (IS_SEQUENCE(_indexes_5302)){
            _2740 = SEQ_PTR(_indexes_5302)->length;
    }
    else {
        _2740 = 1;
    }
    _2741 = _2740 - 1;
    _2740 = NOVALUE;
    {
        int _i_5305;
        _i_5305 = 1;
L1: 
        if (_i_5305 > _2741){
            goto L2; // [14] 40
        }

        /** 		source = source[indexes[i]]*/
        _2 = (int)SEQ_PTR(_indexes_5302);
        _2742 = (int)*(((s1_ptr)_2)->base + _i_5305);
        _0 = _source_5301;
        _2 = (int)SEQ_PTR(_source_5301);
        if (!IS_ATOM_INT(_2742)){
            _source_5301 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_2742)->dbl));
        }
        else{
            _source_5301 = (int)*(((s1_ptr)_2)->base + _2742);
        }
        Ref(_source_5301);
        DeRefDS(_0);

        /** 	end for*/
        _i_5305 = _i_5305 + 1;
        goto L1; // [35] 21
L2: 
        ;
    }

    /** 	x = indexes[$]*/
    if (IS_SEQUENCE(_indexes_5302)){
            _2744 = SEQ_PTR(_indexes_5302)->length;
    }
    else {
        _2744 = 1;
    }
    DeRef(_x_5303);
    _2 = (int)SEQ_PTR(_indexes_5302);
    _x_5303 = (int)*(((s1_ptr)_2)->base + _2744);
    Ref(_x_5303);

    /** 	if atom(x) then*/
    _2746 = IS_ATOM(_x_5303);
    if (_2746 == 0)
    {
        _2746 = NOVALUE;
        goto L3; // [54] 70
    }
    else{
        _2746 = NOVALUE;
    }

    /** 		return source[x]*/
    _2 = (int)SEQ_PTR(_source_5301);
    if (!IS_ATOM_INT(_x_5303)){
        _2747 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_x_5303)->dbl));
    }
    else{
        _2747 = (int)*(((s1_ptr)_2)->base + _x_5303);
    }
    Ref(_2747);
    DeRefDS(_source_5301);
    DeRefDS(_indexes_5302);
    DeRef(_x_5303);
    DeRef(_2741);
    _2741 = NOVALUE;
    _2742 = NOVALUE;
    return _2747;
    goto L4; // [67] 90
L3: 

    /** 		return source[x[1]..x[2]]*/
    _2 = (int)SEQ_PTR(_x_5303);
    _2748 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_5303);
    _2749 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_2750;
    RHS_Slice(_source_5301, _2748, _2749);
    DeRefDS(_source_5301);
    DeRefDS(_indexes_5302);
    DeRef(_x_5303);
    DeRef(_2741);
    _2741 = NOVALUE;
    _2742 = NOVALUE;
    _2747 = NOVALUE;
    _2748 = NOVALUE;
    _2749 = NOVALUE;
    return _2750;
L4: 
    ;
}
int fetch() __attribute__ ((alias ("_23fetch")));


int _23store(int _target_5321, int _indexes_5322, int _x_5323)
{
    int _partials_5324 = NOVALUE;
    int _result_5325 = NOVALUE;
    int _branch_5326 = NOVALUE;
    int _last_idx_5327 = NOVALUE;
    int _2768 = NOVALUE;
    int _2767 = NOVALUE;
    int _2765 = NOVALUE;
    int _2764 = NOVALUE;
    int _2762 = NOVALUE;
    int _2761 = NOVALUE;
    int _2760 = NOVALUE;
    int _2758 = NOVALUE;
    int _2756 = NOVALUE;
    int _2755 = NOVALUE;
    int _2754 = NOVALUE;
    int _2752 = NOVALUE;
    int _2751 = NOVALUE;
    int _0, _1, _2;
    

    /** 	partials = repeat(target,length(indexes)-1)*/
    if (IS_SEQUENCE(_indexes_5322)){
            _2751 = SEQ_PTR(_indexes_5322)->length;
    }
    else {
        _2751 = 1;
    }
    _2752 = _2751 - 1;
    _2751 = NOVALUE;
    DeRef(_partials_5324);
    _partials_5324 = Repeat(_target_5321, _2752);
    _2752 = NOVALUE;

    /** 	branch = target*/
    RefDS(_target_5321);
    DeRef(_branch_5326);
    _branch_5326 = _target_5321;

    /** 	for i=1 to length(indexes)-1 do*/
    if (IS_SEQUENCE(_indexes_5322)){
            _2754 = SEQ_PTR(_indexes_5322)->length;
    }
    else {
        _2754 = 1;
    }
    _2755 = _2754 - 1;
    _2754 = NOVALUE;
    {
        int _i_5332;
        _i_5332 = 1;
L1: 
        if (_i_5332 > _2755){
            goto L2; // [34] 66
        }

        /** 		branch=branch[indexes[i]]*/
        _2 = (int)SEQ_PTR(_indexes_5322);
        _2756 = (int)*(((s1_ptr)_2)->base + _i_5332);
        _0 = _branch_5326;
        _2 = (int)SEQ_PTR(_branch_5326);
        if (!IS_ATOM_INT(_2756)){
            _branch_5326 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_2756)->dbl));
        }
        else{
            _branch_5326 = (int)*(((s1_ptr)_2)->base + _2756);
        }
        Ref(_branch_5326);
        DeRef(_0);

        /** 		partials[i]=branch*/
        RefDS(_branch_5326);
        _2 = (int)SEQ_PTR(_partials_5324);
        _2 = (int)(((s1_ptr)_2)->base + _i_5332);
        _1 = *(int *)_2;
        *(int *)_2 = _branch_5326;
        DeRef(_1);

        /** 	end for*/
        _i_5332 = _i_5332 + 1;
        goto L1; // [61] 41
L2: 
        ;
    }

    /** 	last_idx = indexes[$]*/
    if (IS_SEQUENCE(_indexes_5322)){
            _2758 = SEQ_PTR(_indexes_5322)->length;
    }
    else {
        _2758 = 1;
    }
    DeRef(_last_idx_5327);
    _2 = (int)SEQ_PTR(_indexes_5322);
    _last_idx_5327 = (int)*(((s1_ptr)_2)->base + _2758);
    Ref(_last_idx_5327);

    /** 	if atom(last_idx) then*/
    _2760 = IS_ATOM(_last_idx_5327);
    if (_2760 == 0)
    {
        _2760 = NOVALUE;
        goto L3; // [80] 92
    }
    else{
        _2760 = NOVALUE;
    }

    /** 		branch[last_idx]=x*/
    Ref(_x_5323);
    _2 = (int)SEQ_PTR(_branch_5326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _branch_5326 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_last_idx_5327))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_last_idx_5327)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _last_idx_5327);
    _1 = *(int *)_2;
    *(int *)_2 = _x_5323;
    DeRef(_1);
    goto L4; // [89] 108
L3: 

    /** 		branch[last_idx[1]..last_idx[2]]=x*/
    _2 = (int)SEQ_PTR(_last_idx_5327);
    _2761 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_last_idx_5327);
    _2762 = (int)*(((s1_ptr)_2)->base + 2);
    assign_slice_seq = (s1_ptr *)&_branch_5326;
    AssignSlice(_2761, _2762, _x_5323);
    _2761 = NOVALUE;
    _2762 = NOVALUE;
L4: 

    /** 	partials = prepend(partials,0) -- avoids computing temp=i+1 a few times*/
    Prepend(&_partials_5324, _partials_5324, 0);

    /** 	for i=length(indexes)-1 to 2 by -1 do*/
    if (IS_SEQUENCE(_indexes_5322)){
            _2764 = SEQ_PTR(_indexes_5322)->length;
    }
    else {
        _2764 = 1;
    }
    _2765 = _2764 - 1;
    _2764 = NOVALUE;
    {
        int _i_5346;
        _i_5346 = _2765;
L5: 
        if (_i_5346 < 2){
            goto L6; // [123] 162
        }

        /** 		result = partials[i]*/
        DeRef(_result_5325);
        _2 = (int)SEQ_PTR(_partials_5324);
        _result_5325 = (int)*(((s1_ptr)_2)->base + _i_5346);
        Ref(_result_5325);

        /** 		result[indexes[i]] = branch*/
        _2 = (int)SEQ_PTR(_indexes_5322);
        _2767 = (int)*(((s1_ptr)_2)->base + _i_5346);
        RefDS(_branch_5326);
        _2 = (int)SEQ_PTR(_result_5325);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result_5325 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_2767))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_2767)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _2767);
        _1 = *(int *)_2;
        *(int *)_2 = _branch_5326;
        DeRef(_1);

        /** 		branch = result*/
        RefDS(_result_5325);
        DeRefDS(_branch_5326);
        _branch_5326 = _result_5325;

        /** 	end for*/
        _i_5346 = _i_5346 + -1;
        goto L5; // [157] 130
L6: 
        ;
    }

    /** 	target[indexes[1]] = branch*/
    _2 = (int)SEQ_PTR(_indexes_5322);
    _2768 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_branch_5326);
    _2 = (int)SEQ_PTR(_target_5321);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _target_5321 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_2768))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_2768)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _2768);
    _1 = *(int *)_2;
    *(int *)_2 = _branch_5326;
    DeRef(_1);

    /** 	return target*/
    DeRefDS(_indexes_5322);
    DeRef(_x_5323);
    DeRef(_partials_5324);
    DeRef(_result_5325);
    DeRefDS(_branch_5326);
    DeRef(_last_idx_5327);
    DeRef(_2755);
    _2755 = NOVALUE;
    _2756 = NOVALUE;
    DeRef(_2765);
    _2765 = NOVALUE;
    _2767 = NOVALUE;
    _2768 = NOVALUE;
    return _target_5321;
    ;
}
int store() __attribute__ ((alias ("_23store")));


int _23valid_index(int _st_5354, int _x_5355)
{
    int _2773 = NOVALUE;
    int _2772 = NOVALUE;
    int _2769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(x) then*/
    _2769 = IS_ATOM(_x_5355);
    if (_2769 != 0)
    goto L1; // [8] 18
    _2769 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_st_5354);
    DeRef(_x_5355);
    return 0;
L1: 

    /** 	if x < 1 then*/
    if (binary_op_a(GREATEREQ, _x_5355, 1)){
        goto L2; // [20] 31
    }

    /** 		return 0*/
    DeRefDS(_st_5354);
    DeRef(_x_5355);
    return 0;
L2: 

    /** 	if floor(x) > length(st) then*/
    if (IS_ATOM_INT(_x_5355))
    _2772 = e_floor(_x_5355);
    else
    _2772 = unary_op(FLOOR, _x_5355);
    if (IS_SEQUENCE(_st_5354)){
            _2773 = SEQ_PTR(_st_5354)->length;
    }
    else {
        _2773 = 1;
    }
    if (binary_op_a(LESSEQ, _2772, _2773)){
        DeRef(_2772);
        _2772 = NOVALUE;
        _2773 = NOVALUE;
        goto L3; // [39] 50
    }
    DeRef(_2772);
    _2772 = NOVALUE;
    _2773 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_st_5354);
    DeRef(_x_5355);
    return 0;
L3: 

    /** 	return 1*/
    DeRefDS(_st_5354);
    DeRef(_x_5355);
    return 1;
    ;
}
int valid_index() __attribute__ ((alias ("_23valid_index")));


int _23rotate(int _source_5367, int _shift_5368, int _start_5369, int _stop_5370)
{
    int _shifted_5372 = NOVALUE;
    int _len_5373 = NOVALUE;
    int _lSize_5374 = NOVALUE;
    int _msg_inlined_crash_at_60_5387 = NOVALUE;
    int _msg_inlined_crash_at_91_5393 = NOVALUE;
    int _2801 = NOVALUE;
    int _2800 = NOVALUE;
    int _2799 = NOVALUE;
    int _2798 = NOVALUE;
    int _2797 = NOVALUE;
    int _2795 = NOVALUE;
    int _2794 = NOVALUE;
    int _2788 = NOVALUE;
    int _2785 = NOVALUE;
    int _2782 = NOVALUE;
    int _2781 = NOVALUE;
    int _2779 = NOVALUE;
    int _2778 = NOVALUE;
    int _2777 = NOVALUE;
    int _2776 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_shift_5368)) {
        _1 = (long)(DBL_PTR(_shift_5368)->dbl);
        DeRefDS(_shift_5368);
        _shift_5368 = _1;
    }
    if (!IS_ATOM_INT(_start_5369)) {
        _1 = (long)(DBL_PTR(_start_5369)->dbl);
        DeRefDS(_start_5369);
        _start_5369 = _1;
    }
    if (!IS_ATOM_INT(_stop_5370)) {
        _1 = (long)(DBL_PTR(_stop_5370)->dbl);
        DeRefDS(_stop_5370);
        _stop_5370 = _1;
    }

    /** 	if start >= stop or length(source)=0 or not shift then*/
    _2776 = (_start_5369 >= _stop_5370);
    if (_2776 != 0) {
        _2777 = 1;
        goto L1; // [15] 30
    }
    if (IS_SEQUENCE(_source_5367)){
            _2778 = SEQ_PTR(_source_5367)->length;
    }
    else {
        _2778 = 1;
    }
    _2779 = (_2778 == 0);
    _2778 = NOVALUE;
    _2777 = (_2779 != 0);
L1: 
    if (_2777 != 0) {
        goto L2; // [30] 42
    }
    _2781 = (_shift_5368 == 0);
    if (_2781 == 0)
    {
        DeRef(_2781);
        _2781 = NOVALUE;
        goto L3; // [38] 49
    }
    else{
        DeRef(_2781);
        _2781 = NOVALUE;
    }
L2: 

    /** 		return source*/
    DeRef(_shifted_5372);
    DeRef(_2776);
    _2776 = NOVALUE;
    DeRef(_2779);
    _2779 = NOVALUE;
    return _source_5367;
L3: 

    /** 	if not valid_index(source, start) then*/
    RefDS(_source_5367);
    _2782 = _23valid_index(_source_5367, _start_5369);
    if (IS_ATOM_INT(_2782)) {
        if (_2782 != 0){
            DeRef(_2782);
            _2782 = NOVALUE;
            goto L4; // [56] 80
        }
    }
    else {
        if (DBL_PTR(_2782)->dbl != 0.0){
            DeRef(_2782);
            _2782 = NOVALUE;
            goto L4; // [56] 80
        }
    }
    DeRef(_2782);
    _2782 = NOVALUE;

    /** 		error:crash("sequence:rotate(): invalid 'start' parameter %d", start)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_60_5387);
    _msg_inlined_crash_at_60_5387 = EPrintf(-9999999, _2784, _start_5369);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_60_5387);

    /** end procedure*/
    goto L5; // [74] 77
L5: 
    DeRefi(_msg_inlined_crash_at_60_5387);
    _msg_inlined_crash_at_60_5387 = NOVALUE;
L4: 

    /** 	if not valid_index(source, stop) then*/
    RefDS(_source_5367);
    _2785 = _23valid_index(_source_5367, _stop_5370);
    if (IS_ATOM_INT(_2785)) {
        if (_2785 != 0){
            DeRef(_2785);
            _2785 = NOVALUE;
            goto L6; // [87] 111
        }
    }
    else {
        if (DBL_PTR(_2785)->dbl != 0.0){
            DeRef(_2785);
            _2785 = NOVALUE;
            goto L6; // [87] 111
        }
    }
    DeRef(_2785);
    _2785 = NOVALUE;

    /** 		error:crash("sequence:rotate(): invalid 'stop' parameter %d", stop)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_91_5393);
    _msg_inlined_crash_at_91_5393 = EPrintf(-9999999, _2787, _stop_5370);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_91_5393);

    /** end procedure*/
    goto L7; // [105] 108
L7: 
    DeRefi(_msg_inlined_crash_at_91_5393);
    _msg_inlined_crash_at_91_5393 = NOVALUE;
L6: 

    /** 	len = stop - start + 1*/
    _2788 = _stop_5370 - _start_5369;
    if ((long)((unsigned long)_2788 +(unsigned long) HIGH_BITS) >= 0){
        _2788 = NewDouble((double)_2788);
    }
    if (IS_ATOM_INT(_2788)) {
        _len_5373 = _2788 + 1;
    }
    else
    { // coercing _len_5373 to an integer 1
        _len_5373 = 1+(long)(DBL_PTR(_2788)->dbl);
        if( !IS_ATOM_INT(_len_5373) ){
            _len_5373 = (object)DBL_PTR(_len_5373)->dbl;
        }
    }
    DeRef(_2788);
    _2788 = NOVALUE;

    /** 	lSize = remainder(shift, len)*/
    _lSize_5374 = (_shift_5368 % _len_5373);

    /** 	if lSize = 0 then*/
    if (_lSize_5374 != 0)
    goto L8; // [129] 140

    /** 		return source*/
    DeRef(_shifted_5372);
    DeRef(_2776);
    _2776 = NOVALUE;
    DeRef(_2779);
    _2779 = NOVALUE;
    return _source_5367;
L8: 

    /** 	if lSize < 0 then -- convert right shift to left shift*/
    if (_lSize_5374 >= 0)
    goto L9; // [142] 153

    /** 		lSize += len*/
    _lSize_5374 = _lSize_5374 + _len_5373;
L9: 

    /** 	shifted = source[start .. start + lSize-1]*/
    _2794 = _start_5369 + _lSize_5374;
    if ((long)((unsigned long)_2794 + (unsigned long)HIGH_BITS) >= 0) 
    _2794 = NewDouble((double)_2794);
    if (IS_ATOM_INT(_2794)) {
        _2795 = _2794 - 1;
    }
    else {
        _2795 = NewDouble(DBL_PTR(_2794)->dbl - (double)1);
    }
    DeRef(_2794);
    _2794 = NOVALUE;
    rhs_slice_target = (object_ptr)&_shifted_5372;
    RHS_Slice(_source_5367, _start_5369, _2795);

    /** 	source[start .. stop - lSize] = source[start + lSize .. stop]*/
    _2797 = _stop_5370 - _lSize_5374;
    if ((long)((unsigned long)_2797 +(unsigned long) HIGH_BITS) >= 0){
        _2797 = NewDouble((double)_2797);
    }
    _2798 = _start_5369 + _lSize_5374;
    rhs_slice_target = (object_ptr)&_2799;
    RHS_Slice(_source_5367, _2798, _stop_5370);
    assign_slice_seq = (s1_ptr *)&_source_5367;
    AssignSlice(_start_5369, _2797, _2799);
    DeRef(_2797);
    _2797 = NOVALUE;
    DeRefDS(_2799);
    _2799 = NOVALUE;

    /** 	source[stop - lSize + 1.. stop] = shifted*/
    _2800 = _stop_5370 - _lSize_5374;
    if ((long)((unsigned long)_2800 +(unsigned long) HIGH_BITS) >= 0){
        _2800 = NewDouble((double)_2800);
    }
    if (IS_ATOM_INT(_2800)) {
        _2801 = _2800 + 1;
    }
    else
    _2801 = binary_op(PLUS, 1, _2800);
    DeRef(_2800);
    _2800 = NOVALUE;
    assign_slice_seq = (s1_ptr *)&_source_5367;
    AssignSlice(_2801, _stop_5370, _shifted_5372);
    DeRef(_2801);
    _2801 = NOVALUE;

    /** 	return source*/
    DeRefDS(_shifted_5372);
    DeRef(_2776);
    _2776 = NOVALUE;
    DeRef(_2779);
    _2779 = NOVALUE;
    DeRef(_2795);
    _2795 = NOVALUE;
    _2798 = NOVALUE;
    return _source_5367;
    ;
}
int rotate() __attribute__ ((alias ("_23rotate")));


int _23columnize(int _source_5412, int _cols_5413, int _defval_5414)
{
    int _result_5415 = NOVALUE;
    int _collist_5416 = NOVALUE;
    int _col_5442 = NOVALUE;
    int _2832 = NOVALUE;
    int _2831 = NOVALUE;
    int _2830 = NOVALUE;
    int _2829 = NOVALUE;
    int _2828 = NOVALUE;
    int _2827 = NOVALUE;
    int _2826 = NOVALUE;
    int _2825 = NOVALUE;
    int _2824 = NOVALUE;
    int _2823 = NOVALUE;
    int _2822 = NOVALUE;
    int _2820 = NOVALUE;
    int _2819 = NOVALUE;
    int _2818 = NOVALUE;
    int _2816 = NOVALUE;
    int _2814 = NOVALUE;
    int _2812 = NOVALUE;
    int _2810 = NOVALUE;
    int _2808 = NOVALUE;
    int _2807 = NOVALUE;
    int _2806 = NOVALUE;
    int _2804 = NOVALUE;
    int _2802 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(cols) then*/
    _2802 = IS_SEQUENCE(_cols_5413);
    if (_2802 == 0)
    {
        _2802 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _2802 = NOVALUE;
    }

    /** 		collist = cols*/
    Ref(_cols_5413);
    DeRef(_collist_5416);
    _collist_5416 = _cols_5413;
    goto L2; // [18] 28
L1: 

    /** 		collist = {cols}*/
    _0 = _collist_5416;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_cols_5413);
    *((int *)(_2+4)) = _cols_5413;
    _collist_5416 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	if length(collist) = 0 then*/
    if (IS_SEQUENCE(_collist_5416)){
            _2804 = SEQ_PTR(_collist_5416)->length;
    }
    else {
        _2804 = 1;
    }
    if (_2804 != 0)
    goto L3; // [35] 112

    /** 		cols = 0*/
    DeRef(_cols_5413);
    _cols_5413 = 0;

    /** 		for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5412)){
            _2806 = SEQ_PTR(_source_5412)->length;
    }
    else {
        _2806 = 1;
    }
    {
        int _i_5425;
        _i_5425 = 1;
L4: 
        if (_i_5425 > _2806){
            goto L5; // [49] 86
        }

        /** 			if cols < length(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5412);
        _2807 = (int)*(((s1_ptr)_2)->base + _i_5425);
        if (IS_SEQUENCE(_2807)){
                _2808 = SEQ_PTR(_2807)->length;
        }
        else {
            _2808 = 1;
        }
        _2807 = NOVALUE;
        if (binary_op_a(GREATEREQ, _cols_5413, _2808)){
            _2808 = NOVALUE;
            goto L6; // [65] 79
        }
        _2808 = NOVALUE;

        /** 				cols = length(source[i])*/
        _2 = (int)SEQ_PTR(_source_5412);
        _2810 = (int)*(((s1_ptr)_2)->base + _i_5425);
        DeRef(_cols_5413);
        if (IS_SEQUENCE(_2810)){
                _cols_5413 = SEQ_PTR(_2810)->length;
        }
        else {
            _cols_5413 = 1;
        }
        _2810 = NOVALUE;
L6: 

        /** 		end for*/
        _i_5425 = _i_5425 + 1;
        goto L4; // [81] 56
L5: 
        ;
    }

    /** 		for i = 1 to cols do*/
    Ref(_cols_5413);
    DeRef(_2812);
    _2812 = _cols_5413;
    {
        int _i_5434;
        _i_5434 = 1;
L7: 
        if (binary_op_a(GREATER, _i_5434, _2812)){
            goto L8; // [91] 111
        }

        /** 			collist &= i*/
        Ref(_i_5434);
        Append(&_collist_5416, _collist_5416, _i_5434);

        /** 		end for*/
        _0 = _i_5434;
        if (IS_ATOM_INT(_i_5434)) {
            _i_5434 = _i_5434 + 1;
            if ((long)((unsigned long)_i_5434 +(unsigned long) HIGH_BITS) >= 0){
                _i_5434 = NewDouble((double)_i_5434);
            }
        }
        else {
            _i_5434 = binary_op_a(PLUS, _i_5434, 1);
        }
        DeRef(_0);
        goto L7; // [106] 98
L8: 
        ;
        DeRef(_i_5434);
    }
L3: 

    /** 	result = repeat({}, length(collist))*/
    if (IS_SEQUENCE(_collist_5416)){
            _2814 = SEQ_PTR(_collist_5416)->length;
    }
    else {
        _2814 = 1;
    }
    DeRef(_result_5415);
    _result_5415 = Repeat(_5, _2814);
    _2814 = NOVALUE;

    /** 	for i = 1 to length(collist) do*/
    if (IS_SEQUENCE(_collist_5416)){
            _2816 = SEQ_PTR(_collist_5416)->length;
    }
    else {
        _2816 = 1;
    }
    {
        int _i_5440;
        _i_5440 = 1;
L9: 
        if (_i_5440 > _2816){
            goto LA; // [126] 254
        }

        /** 		integer col = collist[i]*/
        _2 = (int)SEQ_PTR(_collist_5416);
        _col_5442 = (int)*(((s1_ptr)_2)->base + _i_5440);
        if (!IS_ATOM_INT(_col_5442))
        _col_5442 = (long)DBL_PTR(_col_5442)->dbl;

        /** 		for j = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5412)){
                _2818 = SEQ_PTR(_source_5412)->length;
        }
        else {
            _2818 = 1;
        }
        {
            int _j_5445;
            _j_5445 = 1;
LB: 
            if (_j_5445 > _2818){
                goto LC; // [144] 245
            }

            /** 			if length(source[j]) < col then*/
            _2 = (int)SEQ_PTR(_source_5412);
            _2819 = (int)*(((s1_ptr)_2)->base + _j_5445);
            if (IS_SEQUENCE(_2819)){
                    _2820 = SEQ_PTR(_2819)->length;
            }
            else {
                _2820 = 1;
            }
            _2819 = NOVALUE;
            if (_2820 >= _col_5442)
            goto LD; // [160] 181

            /** 				result[i] = append(result[i], defval)*/
            _2 = (int)SEQ_PTR(_result_5415);
            _2822 = (int)*(((s1_ptr)_2)->base + _i_5440);
            Ref(_defval_5414);
            Append(&_2823, _2822, _defval_5414);
            _2822 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5415);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5415 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5440);
            _1 = *(int *)_2;
            *(int *)_2 = _2823;
            if( _1 != _2823 ){
                DeRefDS(_1);
            }
            _2823 = NOVALUE;
            goto LE; // [178] 238
LD: 

            /** 				if atom(source[j]) then*/
            _2 = (int)SEQ_PTR(_source_5412);
            _2824 = (int)*(((s1_ptr)_2)->base + _j_5445);
            _2825 = IS_ATOM(_2824);
            _2824 = NOVALUE;
            if (_2825 == 0)
            {
                _2825 = NOVALUE;
                goto LF; // [190] 214
            }
            else{
                _2825 = NOVALUE;
            }

            /** 					result[i] = append(result[i], source[j])*/
            _2 = (int)SEQ_PTR(_result_5415);
            _2826 = (int)*(((s1_ptr)_2)->base + _i_5440);
            _2 = (int)SEQ_PTR(_source_5412);
            _2827 = (int)*(((s1_ptr)_2)->base + _j_5445);
            Ref(_2827);
            Append(&_2828, _2826, _2827);
            _2826 = NOVALUE;
            _2827 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5415);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5415 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5440);
            _1 = *(int *)_2;
            *(int *)_2 = _2828;
            if( _1 != _2828 ){
                DeRefDS(_1);
            }
            _2828 = NOVALUE;
            goto L10; // [211] 237
LF: 

            /** 					result[i] = append(result[i], source[j][col])*/
            _2 = (int)SEQ_PTR(_result_5415);
            _2829 = (int)*(((s1_ptr)_2)->base + _i_5440);
            _2 = (int)SEQ_PTR(_source_5412);
            _2830 = (int)*(((s1_ptr)_2)->base + _j_5445);
            _2 = (int)SEQ_PTR(_2830);
            _2831 = (int)*(((s1_ptr)_2)->base + _col_5442);
            _2830 = NOVALUE;
            Ref(_2831);
            Append(&_2832, _2829, _2831);
            _2829 = NOVALUE;
            _2831 = NOVALUE;
            _2 = (int)SEQ_PTR(_result_5415);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5415 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5440);
            _1 = *(int *)_2;
            *(int *)_2 = _2832;
            if( _1 != _2832 ){
                DeRefDS(_1);
            }
            _2832 = NOVALUE;
L10: 
LE: 

            /** 		end for*/
            _j_5445 = _j_5445 + 1;
            goto LB; // [240] 151
LC: 
            ;
        }

        /** 	end for*/
        _i_5440 = _i_5440 + 1;
        goto L9; // [249] 133
LA: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_5412);
    DeRef(_cols_5413);
    DeRef(_defval_5414);
    DeRef(_collist_5416);
    _2807 = NOVALUE;
    _2810 = NOVALUE;
    _2819 = NOVALUE;
    return _result_5415;
    ;
}
int columnize() __attribute__ ((alias ("_23columnize")));


int _23apply(int _source_5467, int _rid_5468, int _userdata_5469)
{
    int _2836 = NOVALUE;
    int _2835 = NOVALUE;
    int _2834 = NOVALUE;
    int _2833 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_rid_5468)) {
        _1 = (long)(DBL_PTR(_rid_5468)->dbl);
        DeRefDS(_rid_5468);
        _rid_5468 = _1;
    }

    /** 	for a = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5467)){
            _2833 = SEQ_PTR(_source_5467)->length;
    }
    else {
        _2833 = 1;
    }
    {
        int _a_5471;
        _a_5471 = 1;
L1: 
        if (_a_5471 > _2833){
            goto L2; // [10] 42
        }

        /** 		source[a] = call_func(rid, {source[a], userdata})*/
        _2 = (int)SEQ_PTR(_source_5467);
        _2834 = (int)*(((s1_ptr)_2)->base + _a_5471);
        Ref(_userdata_5469);
        Ref(_2834);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _2834;
        ((int *)_2)[2] = _userdata_5469;
        _2835 = MAKE_SEQ(_1);
        _2834 = NOVALUE;
        _1 = (int)SEQ_PTR(_2835);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_rid_5468].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
        DeRef(_2836);
        _2836 = _1;
        DeRefDS(_2835);
        _2835 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_5467);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5467 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _a_5471);
        _1 = *(int *)_2;
        *(int *)_2 = _2836;
        if( _1 != _2836 ){
            DeRef(_1);
        }
        _2836 = NOVALUE;

        /** 	end for*/
        _a_5471 = _a_5471 + 1;
        goto L1; // [37] 17
L2: 
        ;
    }

    /** 	return source*/
    DeRef(_userdata_5469);
    return _source_5467;
    ;
}
int apply() __attribute__ ((alias ("_23apply")));


int _23mapping(int _source_arg_5478, int _from_set_5479, int _to_set_5480, int _one_level_5481)
{
    int _pos_5482 = NOVALUE;
    int _2858 = NOVALUE;
    int _2857 = NOVALUE;
    int _2856 = NOVALUE;
    int _2855 = NOVALUE;
    int _2854 = NOVALUE;
    int _2853 = NOVALUE;
    int _2852 = NOVALUE;
    int _2851 = NOVALUE;
    int _2850 = NOVALUE;
    int _2848 = NOVALUE;
    int _2846 = NOVALUE;
    int _2845 = NOVALUE;
    int _2844 = NOVALUE;
    int _2842 = NOVALUE;
    int _2841 = NOVALUE;
    int _2840 = NOVALUE;
    int _2839 = NOVALUE;
    int _2837 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_one_level_5481)) {
        _1 = (long)(DBL_PTR(_one_level_5481)->dbl);
        DeRefDS(_one_level_5481);
        _one_level_5481 = _1;
    }

    /** 	if atom(source_arg) then*/
    _2837 = IS_ATOM(_source_arg_5478);
    if (_2837 == 0)
    {
        _2837 = NOVALUE;
        goto L1; // [12] 53
    }
    else{
        _2837 = NOVALUE;
    }

    /** 		pos = find(source_arg, from_set)*/
    _pos_5482 = find_from(_source_arg_5478, _from_set_5479, 1);

    /** 		if pos >= 1  and pos <= length(to_set) then*/
    _2839 = (_pos_5482 >= 1);
    if (_2839 == 0) {
        goto L2; // [28] 161
    }
    if (IS_SEQUENCE(_to_set_5480)){
            _2841 = SEQ_PTR(_to_set_5480)->length;
    }
    else {
        _2841 = 1;
    }
    _2842 = (_pos_5482 <= _2841);
    _2841 = NOVALUE;
    if (_2842 == 0)
    {
        DeRef(_2842);
        _2842 = NOVALUE;
        goto L2; // [40] 161
    }
    else{
        DeRef(_2842);
        _2842 = NOVALUE;
    }

    /** 			source_arg = to_set[pos]*/
    DeRef(_source_arg_5478);
    _2 = (int)SEQ_PTR(_to_set_5480);
    _source_arg_5478 = (int)*(((s1_ptr)_2)->base + _pos_5482);
    Ref(_source_arg_5478);
    goto L2; // [50] 161
L1: 

    /** 		for i = 1 to length(source_arg) do*/
    if (IS_SEQUENCE(_source_arg_5478)){
            _2844 = SEQ_PTR(_source_arg_5478)->length;
    }
    else {
        _2844 = 1;
    }
    {
        int _i_5494;
        _i_5494 = 1;
L3: 
        if (_i_5494 > _2844){
            goto L4; // [58] 160
        }

        /** 			if atom(source_arg[i]) or one_level then*/
        _2 = (int)SEQ_PTR(_source_arg_5478);
        _2845 = (int)*(((s1_ptr)_2)->base + _i_5494);
        _2846 = IS_ATOM(_2845);
        _2845 = NOVALUE;
        if (_2846 != 0) {
            goto L5; // [74] 83
        }
        if (_one_level_5481 == 0)
        {
            goto L6; // [79] 129
        }
        else{
        }
L5: 

        /** 				pos = find(source_arg[i], from_set)*/
        _2 = (int)SEQ_PTR(_source_arg_5478);
        _2848 = (int)*(((s1_ptr)_2)->base + _i_5494);
        _pos_5482 = find_from(_2848, _from_set_5479, 1);
        _2848 = NOVALUE;

        /** 				if pos >= 1  and pos <= length(to_set) then*/
        _2850 = (_pos_5482 >= 1);
        if (_2850 == 0) {
            goto L7; // [100] 153
        }
        if (IS_SEQUENCE(_to_set_5480)){
                _2852 = SEQ_PTR(_to_set_5480)->length;
        }
        else {
            _2852 = 1;
        }
        _2853 = (_pos_5482 <= _2852);
        _2852 = NOVALUE;
        if (_2853 == 0)
        {
            DeRef(_2853);
            _2853 = NOVALUE;
            goto L7; // [112] 153
        }
        else{
            DeRef(_2853);
            _2853 = NOVALUE;
        }

        /** 					source_arg[i] = to_set[pos]*/
        _2 = (int)SEQ_PTR(_to_set_5480);
        _2854 = (int)*(((s1_ptr)_2)->base + _pos_5482);
        Ref(_2854);
        _2 = (int)SEQ_PTR(_source_arg_5478);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_arg_5478 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5494);
        _1 = *(int *)_2;
        *(int *)_2 = _2854;
        if( _1 != _2854 ){
            DeRef(_1);
        }
        _2854 = NOVALUE;
        goto L7; // [126] 153
L6: 

        /** 				source_arg[i] = mapping(source_arg[i], from_set, to_set)*/
        _2 = (int)SEQ_PTR(_source_arg_5478);
        _2855 = (int)*(((s1_ptr)_2)->base + _i_5494);
        RefDS(_from_set_5479);
        DeRef(_2856);
        _2856 = _from_set_5479;
        RefDS(_to_set_5480);
        DeRef(_2857);
        _2857 = _to_set_5480;
        Ref(_2855);
        _2858 = _23mapping(_2855, _2856, _2857, 0);
        _2855 = NOVALUE;
        _2856 = NOVALUE;
        _2857 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_arg_5478);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_arg_5478 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5494);
        _1 = *(int *)_2;
        *(int *)_2 = _2858;
        if( _1 != _2858 ){
            DeRef(_1);
        }
        _2858 = NOVALUE;
L7: 

        /** 		end for*/
        _i_5494 = _i_5494 + 1;
        goto L3; // [155] 65
L4: 
        ;
    }
L2: 

    /** 	return source_arg*/
    DeRefDS(_from_set_5479);
    DeRefDS(_to_set_5480);
    DeRef(_2839);
    _2839 = NOVALUE;
    DeRef(_2850);
    _2850 = NOVALUE;
    return _source_arg_5478;
    ;
}
int mapping() __attribute__ ((alias ("_23mapping")));


int _23reverse(int _target_5515, int _pFrom_5516, int _pTo_5517)
{
    int _uppr_5518 = NOVALUE;
    int _n_5519 = NOVALUE;
    int _lLimit_5520 = NOVALUE;
    int _t_5521 = NOVALUE;
    int _2873 = NOVALUE;
    int _2872 = NOVALUE;
    int _2871 = NOVALUE;
    int _2869 = NOVALUE;
    int _2868 = NOVALUE;
    int _2866 = NOVALUE;
    int _2864 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pFrom_5516)) {
        _1 = (long)(DBL_PTR(_pFrom_5516)->dbl);
        DeRefDS(_pFrom_5516);
        _pFrom_5516 = _1;
    }
    if (!IS_ATOM_INT(_pTo_5517)) {
        _1 = (long)(DBL_PTR(_pTo_5517)->dbl);
        DeRefDS(_pTo_5517);
        _pTo_5517 = _1;
    }

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_5515)){
            _n_5519 = SEQ_PTR(_target_5515)->length;
    }
    else {
        _n_5519 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_5519 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_5521);
    return _target_5515;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_5516 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_5516 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_5517 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_5517 = _n_5519 + _pTo_5517;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _2864 = (_pTo_5517 < _pFrom_5516);
    if (_2864 != 0) {
        goto L4; // [54] 67
    }
    _2866 = (_pFrom_5516 >= _n_5519);
    if (_2866 == 0)
    {
        DeRef(_2866);
        _2866 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2866);
        _2866 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_5521);
    DeRef(_2864);
    _2864 = NOVALUE;
    return _target_5515;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_5517 <= _n_5519)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_5517 = _n_5519;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _2868 = _pFrom_5516 + _pTo_5517;
    if ((long)((unsigned long)_2868 + (unsigned long)HIGH_BITS) >= 0) 
    _2868 = NewDouble((double)_2868);
    if (IS_ATOM_INT(_2868)) {
        _2869 = _2868 - 1;
        if ((long)((unsigned long)_2869 +(unsigned long) HIGH_BITS) >= 0){
            _2869 = NewDouble((double)_2869);
        }
    }
    else {
        _2869 = NewDouble(DBL_PTR(_2868)->dbl - (double)1);
    }
    DeRef(_2868);
    _2868 = NOVALUE;
    if (IS_ATOM_INT(_2869)) {
        _lLimit_5520 = _2869 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2869, 2);
        _lLimit_5520 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2869);
    _2869 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_5520)) {
        _1 = (long)(DBL_PTR(_lLimit_5520)->dbl);
        DeRefDS(_lLimit_5520);
        _lLimit_5520 = _1;
    }

    /** 	t = target*/
    Ref(_target_5515);
    DeRef(_t_5521);
    _t_5521 = _target_5515;

    /** 	uppr = pTo*/
    _uppr_5518 = _pTo_5517;

    /** 	for lowr = pFrom to lLimit do*/
    _2871 = _lLimit_5520;
    {
        int _lowr_5540;
        _lowr_5540 = _pFrom_5516;
L7: 
        if (_lowr_5540 > _2871){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_5515);
        _2872 = (int)*(((s1_ptr)_2)->base + _lowr_5540);
        Ref(_2872);
        _2 = (int)SEQ_PTR(_t_5521);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5521 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_5518);
        _1 = *(int *)_2;
        *(int *)_2 = _2872;
        if( _1 != _2872 ){
            DeRef(_1);
        }
        _2872 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_5515);
        _2873 = (int)*(((s1_ptr)_2)->base + _uppr_5518);
        Ref(_2873);
        _2 = (int)SEQ_PTR(_t_5521);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_5521 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_5540);
        _1 = *(int *)_2;
        *(int *)_2 = _2873;
        if( _1 != _2873 ){
            DeRef(_1);
        }
        _2873 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_5518 = _uppr_5518 - 1;

        /** 	end for*/
        _lowr_5540 = _lowr_5540 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_5515);
    DeRef(_2864);
    _2864 = NOVALUE;
    return _t_5521;
    ;
}
int reverse() __attribute__ ((alias ("_23reverse")));


int _23shuffle(int _seq_5547)
{
    int _fromIdx_5551 = NOVALUE;
    int _swapValue_5553 = NOVALUE;
    int _2878 = NOVALUE;
    int _2875 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for toIdx = length(seq) to 2 by -1 do*/
    if (IS_SEQUENCE(_seq_5547)){
            _2875 = SEQ_PTR(_seq_5547)->length;
    }
    else {
        _2875 = 1;
    }
    {
        int _toIdx_5549;
        _toIdx_5549 = _2875;
L1: 
        if (_toIdx_5549 < 2){
            goto L2; // [6] 49
        }

        /** 		integer fromIdx = rand(toIdx)*/
        _fromIdx_5551 = good_rand() % ((unsigned)_toIdx_5549) + 1;

        /** 		object swapValue = seq[fromIdx]*/
        DeRef(_swapValue_5553);
        _2 = (int)SEQ_PTR(_seq_5547);
        _swapValue_5553 = (int)*(((s1_ptr)_2)->base + _fromIdx_5551);
        Ref(_swapValue_5553);

        /** 		seq[fromIdx] = seq[toIdx]*/
        _2 = (int)SEQ_PTR(_seq_5547);
        _2878 = (int)*(((s1_ptr)_2)->base + _toIdx_5549);
        Ref(_2878);
        _2 = (int)SEQ_PTR(_seq_5547);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_5547 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _fromIdx_5551);
        _1 = *(int *)_2;
        *(int *)_2 = _2878;
        if( _1 != _2878 ){
            DeRef(_1);
        }
        _2878 = NOVALUE;

        /** 		seq[toIdx] = swapValue*/
        Ref(_swapValue_5553);
        _2 = (int)SEQ_PTR(_seq_5547);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_5547 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _toIdx_5549);
        _1 = *(int *)_2;
        *(int *)_2 = _swapValue_5553;
        DeRef(_1);
        DeRef(_swapValue_5553);
        _swapValue_5553 = NOVALUE;

        /** 	end for*/
        _toIdx_5549 = _toIdx_5549 + -1;
        goto L1; // [44] 13
L2: 
        ;
    }

    /** 	return seq*/
    return _seq_5547;
    ;
}
int shuffle() __attribute__ ((alias ("_23shuffle")));


int _23series(int _start_5558, int _increment_5559, int _count_5560, int _op_5561)
{
    int _result_5562 = NOVALUE;
    int _2889 = NOVALUE;
    int _2886 = NOVALUE;
    int _2880 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_5560)) {
        _1 = (long)(DBL_PTR(_count_5560)->dbl);
        DeRefDS(_count_5560);
        _count_5560 = _1;
    }
    if (!IS_ATOM_INT(_op_5561)) {
        _1 = (long)(DBL_PTR(_op_5561)->dbl);
        DeRefDS(_op_5561);
        _op_5561 = _1;
    }

    /** 	if count < 0 then*/
    if (_count_5560 >= 0)
    goto L1; // [7] 18

    /** 		return 0*/
    DeRef(_start_5558);
    DeRef(_increment_5559);
    DeRef(_result_5562);
    return 0;
L1: 

    /** 	if not binop_ok(start, increment) then*/
    Ref(_start_5558);
    Ref(_increment_5559);
    _2880 = _23binop_ok(_start_5558, _increment_5559);
    if (IS_ATOM_INT(_2880)) {
        if (_2880 != 0){
            DeRef(_2880);
            _2880 = NOVALUE;
            goto L2; // [25] 35
        }
    }
    else {
        if (DBL_PTR(_2880)->dbl != 0.0){
            DeRef(_2880);
            _2880 = NOVALUE;
            goto L2; // [25] 35
        }
    }
    DeRef(_2880);
    _2880 = NOVALUE;

    /** 		return 0*/
    DeRef(_start_5558);
    DeRef(_increment_5559);
    DeRef(_result_5562);
    return 0;
L2: 

    /** 	if count = 0 then*/
    if (_count_5560 != 0)
    goto L3; // [37] 48

    /** 		return {}*/
    RefDS(_5);
    DeRef(_start_5558);
    DeRef(_increment_5559);
    DeRef(_result_5562);
    return _5;
L3: 

    /** 	result = repeat(0, count )*/
    DeRef(_result_5562);
    _result_5562 = Repeat(0, _count_5560);

    /** 	result[1] = start*/
    Ref(_start_5558);
    _2 = (int)SEQ_PTR(_result_5562);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_5562 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _start_5558;

    /** 	switch op do*/
    _0 = _op_5561;
    switch ( _0 ){ 

        /** 		case '+' then*/
        case 43:

        /** 			for i = 2 to count  do*/
        _2886 = _count_5560;
        {
            int _i_5575;
            _i_5575 = 2;
L4: 
            if (_i_5575 > _2886){
                goto L5; // [76] 102
            }

            /** 				start += increment*/
            _0 = _start_5558;
            if (IS_ATOM_INT(_start_5558) && IS_ATOM_INT(_increment_5559)) {
                _start_5558 = _start_5558 + _increment_5559;
                if ((long)((unsigned long)_start_5558 + (unsigned long)HIGH_BITS) >= 0) 
                _start_5558 = NewDouble((double)_start_5558);
            }
            else {
                _start_5558 = binary_op(PLUS, _start_5558, _increment_5559);
            }
            DeRef(_0);

            /** 				result[i] = start*/
            Ref(_start_5558);
            _2 = (int)SEQ_PTR(_result_5562);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5562 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5575);
            _1 = *(int *)_2;
            *(int *)_2 = _start_5558;
            DeRef(_1);

            /** 			end for*/
            _i_5575 = _i_5575 + 1;
            goto L4; // [97] 83
L5: 
            ;
        }
        goto L6; // [102] 152

        /** 		case '*' then*/
        case 42:

        /** 			for i = 2 to count do*/
        _2889 = _count_5560;
        {
            int _i_5581;
            _i_5581 = 2;
L7: 
            if (_i_5581 > _2889){
                goto L8; // [113] 139
            }

            /** 				start *= increment*/
            _0 = _start_5558;
            if (IS_ATOM_INT(_start_5558) && IS_ATOM_INT(_increment_5559)) {
                if (_start_5558 == (short)_start_5558 && _increment_5559 <= INT15 && _increment_5559 >= -INT15)
                _start_5558 = _start_5558 * _increment_5559;
                else
                _start_5558 = NewDouble(_start_5558 * (double)_increment_5559);
            }
            else {
                _start_5558 = binary_op(MULTIPLY, _start_5558, _increment_5559);
            }
            DeRef(_0);

            /** 				result[i] = start*/
            Ref(_start_5558);
            _2 = (int)SEQ_PTR(_result_5562);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_5562 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_5581);
            _1 = *(int *)_2;
            *(int *)_2 = _start_5558;
            DeRef(_1);

            /** 			end for*/
            _i_5581 = _i_5581 + 1;
            goto L7; // [134] 120
L8: 
            ;
        }
        goto L6; // [139] 152

        /** 		case else*/
        default:

        /** 			return 0*/
        DeRef(_start_5558);
        DeRef(_increment_5559);
        DeRef(_result_5562);
        return 0;
    ;}L6: 

    /** 	return result*/
    DeRef(_start_5558);
    DeRef(_increment_5559);
    return _result_5562;
    ;
}
int series() __attribute__ ((alias ("_23series")));


int _23repeat_pattern(int _pattern_5587, int _count_5588)
{
    int _ls_5589 = NOVALUE;
    int _result_5590 = NOVALUE;
    int _2898 = NOVALUE;
    int _2897 = NOVALUE;
    int _2896 = NOVALUE;
    int _2895 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_5588)) {
        _1 = (long)(DBL_PTR(_count_5588)->dbl);
        DeRefDS(_count_5588);
        _count_5588 = _1;
    }

    /** 	if count<=0 then*/
    if (_count_5588 > 0)
    goto L1; // [5] 16

    /** 		return {}*/
    RefDS(_5);
    DeRef(_pattern_5587);
    DeRef(_result_5590);
    return _5;
L1: 

    /** 	ls = length(pattern)*/
    if (IS_SEQUENCE(_pattern_5587)){
            _ls_5589 = SEQ_PTR(_pattern_5587)->length;
    }
    else {
        _ls_5589 = 1;
    }

    /** 	count *= ls*/
    _count_5588 = _count_5588 * _ls_5589;

    /** 	result=repeat(0,count)*/
    DeRef(_result_5590);
    _result_5590 = Repeat(0, _count_5588);

    /** 	for i=1 to count by ls do*/
    _2895 = _ls_5589;
    _2896 = _count_5588;
    {
        int _i_5597;
        _i_5597 = 1;
L2: 
        if (_i_5597 > _2896){
            goto L3; // [43] 72
        }

        /** 		result[i..i+ls-1] = pattern*/
        _2897 = _i_5597 + _ls_5589;
        if ((long)((unsigned long)_2897 + (unsigned long)HIGH_BITS) >= 0) 
        _2897 = NewDouble((double)_2897);
        if (IS_ATOM_INT(_2897)) {
            _2898 = _2897 - 1;
        }
        else {
            _2898 = NewDouble(DBL_PTR(_2897)->dbl - (double)1);
        }
        DeRef(_2897);
        _2897 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_result_5590;
        AssignSlice(_i_5597, _2898, _pattern_5587);
        DeRef(_2898);
        _2898 = NOVALUE;

        /** 	end for*/
        _i_5597 = _i_5597 + _2895;
        goto L2; // [67] 50
L3: 
        ;
    }

    /** 	return result*/
    DeRef(_pattern_5587);
    return _result_5590;
    ;
}
int repeat_pattern() __attribute__ ((alias ("_23repeat_pattern")));


int _23pad_head(int _target_5604, int _size_5605, int _ch_5606)
{
    int _2904 = NOVALUE;
    int _2903 = NOVALUE;
    int _2902 = NOVALUE;
    int _2901 = NOVALUE;
    int _2899 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_5605)) {
        _1 = (long)(DBL_PTR(_size_5605)->dbl);
        DeRefDS(_size_5605);
        _size_5605 = _1;
    }

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_5604)){
            _2899 = SEQ_PTR(_target_5604)->length;
    }
    else {
        _2899 = 1;
    }
    if (_size_5605 > _2899)
    goto L1; // [8] 19

    /** 		return target*/
    DeRef(_ch_5606);
    return _target_5604;
L1: 

    /** 	return repeat(ch, size - length(target)) & target*/
    if (IS_SEQUENCE(_target_5604)){
            _2901 = SEQ_PTR(_target_5604)->length;
    }
    else {
        _2901 = 1;
    }
    _2902 = _size_5605 - _2901;
    _2901 = NOVALUE;
    _2903 = Repeat(_ch_5606, _2902);
    _2902 = NOVALUE;
    if (IS_SEQUENCE(_2903) && IS_ATOM(_target_5604)) {
        Ref(_target_5604);
        Append(&_2904, _2903, _target_5604);
    }
    else if (IS_ATOM(_2903) && IS_SEQUENCE(_target_5604)) {
    }
    else {
        Concat((object_ptr)&_2904, _2903, _target_5604);
        DeRefDS(_2903);
        _2903 = NOVALUE;
    }
    DeRef(_2903);
    _2903 = NOVALUE;
    DeRef(_target_5604);
    DeRef(_ch_5606);
    return _2904;
    ;
}
int pad_head() __attribute__ ((alias ("_23pad_head")));


int _23pad_tail(int _target_5616, int _size_5617, int _ch_5618)
{
    int _2910 = NOVALUE;
    int _2909 = NOVALUE;
    int _2908 = NOVALUE;
    int _2907 = NOVALUE;
    int _2905 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_5617)) {
        _1 = (long)(DBL_PTR(_size_5617)->dbl);
        DeRefDS(_size_5617);
        _size_5617 = _1;
    }

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_5616)){
            _2905 = SEQ_PTR(_target_5616)->length;
    }
    else {
        _2905 = 1;
    }
    if (_size_5617 > _2905)
    goto L1; // [8] 19

    /** 		return target*/
    DeRef(_ch_5618);
    return _target_5616;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_5616)){
            _2907 = SEQ_PTR(_target_5616)->length;
    }
    else {
        _2907 = 1;
    }
    _2908 = _size_5617 - _2907;
    _2907 = NOVALUE;
    _2909 = Repeat(_ch_5618, _2908);
    _2908 = NOVALUE;
    if (IS_SEQUENCE(_target_5616) && IS_ATOM(_2909)) {
    }
    else if (IS_ATOM(_target_5616) && IS_SEQUENCE(_2909)) {
        Ref(_target_5616);
        Prepend(&_2910, _2909, _target_5616);
    }
    else {
        Concat((object_ptr)&_2910, _target_5616, _2909);
    }
    DeRefDS(_2909);
    _2909 = NOVALUE;
    DeRef(_target_5616);
    DeRef(_ch_5618);
    return _2910;
    ;
}
int pad_tail() __attribute__ ((alias ("_23pad_tail")));


int _23add_item(int _needle_5628, int _haystack_5629, int _pOrder_5630)
{
    int _msg_inlined_crash_at_108_5648 = NOVALUE;
    int _2919 = NOVALUE;
    int _2918 = NOVALUE;
    int _2917 = NOVALUE;
    int _2916 = NOVALUE;
    int _2915 = NOVALUE;
    int _2914 = NOVALUE;
    int _2911 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pOrder_5630)) {
        _1 = (long)(DBL_PTR(_pOrder_5630)->dbl);
        DeRefDS(_pOrder_5630);
        _pOrder_5630 = _1;
    }

    /** 	if find(needle, haystack) then*/
    _2911 = find_from(_needle_5628, _haystack_5629, 1);
    if (_2911 == 0)
    {
        _2911 = NOVALUE;
        goto L1; // [12] 22
    }
    else{
        _2911 = NOVALUE;
    }

    /** 		return haystack*/
    DeRef(_needle_5628);
    return _haystack_5629;
L1: 

    /** 	switch pOrder do*/
    _0 = _pOrder_5630;
    switch ( _0 ){ 

        /** 		case ADD_PREPEND then*/
        case 1:

        /** 			return prepend(haystack, needle)*/
        Ref(_needle_5628);
        Prepend(&_2914, _haystack_5629, _needle_5628);
        DeRef(_needle_5628);
        DeRefDS(_haystack_5629);
        return _2914;
        goto L2; // [43] 128

        /** 		case ADD_APPEND then*/
        case 2:

        /** 			return append(haystack, needle)*/
        Ref(_needle_5628);
        Append(&_2915, _haystack_5629, _needle_5628);
        DeRef(_needle_5628);
        DeRefDS(_haystack_5629);
        DeRef(_2914);
        _2914 = NOVALUE;
        return _2915;
        goto L2; // [59] 128

        /** 		case ADD_SORT_UP then*/
        case 3:

        /** 			return stdsort:sort(append(haystack, needle))*/
        Ref(_needle_5628);
        Append(&_2916, _haystack_5629, _needle_5628);
        _2917 = _24sort(_2916, 1);
        _2916 = NOVALUE;
        DeRef(_needle_5628);
        DeRefDS(_haystack_5629);
        DeRef(_2914);
        _2914 = NOVALUE;
        DeRef(_2915);
        _2915 = NOVALUE;
        return _2917;
        goto L2; // [80] 128

        /** 		case ADD_SORT_DOWN then*/
        case 4:

        /** 			return stdsort:sort(append(haystack, needle), stdsort:DESCENDING)*/
        Ref(_needle_5628);
        Append(&_2918, _haystack_5629, _needle_5628);
        _2919 = _24sort(_2918, -1);
        _2918 = NOVALUE;
        DeRef(_needle_5628);
        DeRefDS(_haystack_5629);
        DeRef(_2914);
        _2914 = NOVALUE;
        DeRef(_2915);
        _2915 = NOVALUE;
        DeRef(_2917);
        _2917 = NOVALUE;
        return _2919;
        goto L2; // [101] 128

        /** 		case else*/
        default:

        /** 			error:crash("sequence.e:add_item() invalid Order argument '%d'", pOrder)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_108_5648);
        _msg_inlined_crash_at_108_5648 = EPrintf(-9999999, _2920, _pOrder_5630);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_108_5648);

        /** end procedure*/
        goto L3; // [122] 125
L3: 
        DeRefi(_msg_inlined_crash_at_108_5648);
        _msg_inlined_crash_at_108_5648 = NOVALUE;
    ;}L2: 

    /** 	return haystack*/
    DeRef(_needle_5628);
    DeRef(_2914);
    _2914 = NOVALUE;
    DeRef(_2915);
    _2915 = NOVALUE;
    DeRef(_2917);
    _2917 = NOVALUE;
    DeRef(_2919);
    _2919 = NOVALUE;
    return _haystack_5629;
    ;
}
int add_item() __attribute__ ((alias ("_23add_item")));


int _23remove_item(int _needle_5651, int _haystack_5652)
{
    int _lIdx_5653 = NOVALUE;
    int _2936 = NOVALUE;
    int _2935 = NOVALUE;
    int _2934 = NOVALUE;
    int _2933 = NOVALUE;
    int _2932 = NOVALUE;
    int _2931 = NOVALUE;
    int _2930 = NOVALUE;
    int _2929 = NOVALUE;
    int _2928 = NOVALUE;
    int _2926 = NOVALUE;
    int _2925 = NOVALUE;
    int _2924 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lIdx = find(needle, haystack)*/
    _lIdx_5653 = find_from(_needle_5651, _haystack_5652, 1);

    /** 	if not lIdx then*/
    if (_lIdx_5653 != 0)
    goto L1; // [12] 22

    /** 		return haystack*/
    DeRef(_needle_5651);
    return _haystack_5652;
L1: 

    /** 	if lIdx = 1 then*/
    if (_lIdx_5653 != 1)
    goto L2; // [24] 45

    /** 		return haystack[2 .. $]*/
    if (IS_SEQUENCE(_haystack_5652)){
            _2924 = SEQ_PTR(_haystack_5652)->length;
    }
    else {
        _2924 = 1;
    }
    rhs_slice_target = (object_ptr)&_2925;
    RHS_Slice(_haystack_5652, 2, _2924);
    DeRef(_needle_5651);
    DeRefDS(_haystack_5652);
    return _2925;
    goto L3; // [42] 107
L2: 

    /** 	elsif lIdx = length(haystack) then*/
    if (IS_SEQUENCE(_haystack_5652)){
            _2926 = SEQ_PTR(_haystack_5652)->length;
    }
    else {
        _2926 = 1;
    }
    if (_lIdx_5653 != _2926)
    goto L4; // [50] 75

    /** 		return haystack[1 .. $-1]*/
    if (IS_SEQUENCE(_haystack_5652)){
            _2928 = SEQ_PTR(_haystack_5652)->length;
    }
    else {
        _2928 = 1;
    }
    _2929 = _2928 - 1;
    _2928 = NOVALUE;
    rhs_slice_target = (object_ptr)&_2930;
    RHS_Slice(_haystack_5652, 1, _2929);
    DeRef(_needle_5651);
    DeRefDS(_haystack_5652);
    DeRef(_2925);
    _2925 = NOVALUE;
    _2929 = NOVALUE;
    return _2930;
    goto L3; // [72] 107
L4: 

    /** 		return haystack[1 .. lIdx - 1] & haystack[lIdx + 1 .. $]*/
    _2931 = _lIdx_5653 - 1;
    rhs_slice_target = (object_ptr)&_2932;
    RHS_Slice(_haystack_5652, 1, _2931);
    _2933 = _lIdx_5653 + 1;
    if (_2933 > MAXINT){
        _2933 = NewDouble((double)_2933);
    }
    if (IS_SEQUENCE(_haystack_5652)){
            _2934 = SEQ_PTR(_haystack_5652)->length;
    }
    else {
        _2934 = 1;
    }
    rhs_slice_target = (object_ptr)&_2935;
    RHS_Slice(_haystack_5652, _2933, _2934);
    Concat((object_ptr)&_2936, _2932, _2935);
    DeRefDS(_2932);
    _2932 = NOVALUE;
    DeRef(_2932);
    _2932 = NOVALUE;
    DeRefDS(_2935);
    _2935 = NOVALUE;
    DeRef(_needle_5651);
    DeRefDS(_haystack_5652);
    DeRef(_2925);
    _2925 = NOVALUE;
    DeRef(_2929);
    _2929 = NOVALUE;
    DeRef(_2930);
    _2930 = NOVALUE;
    _2931 = NOVALUE;
    DeRef(_2933);
    _2933 = NOVALUE;
    return _2936;
L3: 
    ;
}
int remove_item() __attribute__ ((alias ("_23remove_item")));


int _23mid(int _source_5676, int _start_5677, int _len_5678)
{
    int _msg_inlined_crash_at_45_5693 = NOVALUE;
    int _data_inlined_crash_at_42_5692 = NOVALUE;
    int _2960 = NOVALUE;
    int _2959 = NOVALUE;
    int _2958 = NOVALUE;
    int _2957 = NOVALUE;
    int _2956 = NOVALUE;
    int _2954 = NOVALUE;
    int _2953 = NOVALUE;
    int _2952 = NOVALUE;
    int _2950 = NOVALUE;
    int _2948 = NOVALUE;
    int _2947 = NOVALUE;
    int _2946 = NOVALUE;
    int _2945 = NOVALUE;
    int _2944 = NOVALUE;
    int _2943 = NOVALUE;
    int _2942 = NOVALUE;
    int _2938 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if len<0 then*/
    if (binary_op_a(GREATEREQ, _len_5678, 0)){
        goto L1; // [5] 66
    }

    /** 		len += length(source)*/
    if (IS_SEQUENCE(_source_5676)){
            _2938 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2938 = 1;
    }
    _0 = _len_5678;
    if (IS_ATOM_INT(_len_5678)) {
        _len_5678 = _len_5678 + _2938;
        if ((long)((unsigned long)_len_5678 + (unsigned long)HIGH_BITS) >= 0) 
        _len_5678 = NewDouble((double)_len_5678);
    }
    else {
        _len_5678 = NewDouble(DBL_PTR(_len_5678)->dbl + (double)_2938);
    }
    DeRef(_0);
    _2938 = NOVALUE;

    /** 		if len<0 then*/
    if (binary_op_a(GREATEREQ, _len_5678, 0)){
        goto L2; // [20] 65
    }

    /** 			error:crash("mid(): len was %d and should be greater than %d.",*/
    if (IS_SEQUENCE(_source_5676)){
            _2942 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2942 = 1;
    }
    if (IS_ATOM_INT(_len_5678)) {
        _2943 = _len_5678 - _2942;
        if ((long)((unsigned long)_2943 +(unsigned long) HIGH_BITS) >= 0){
            _2943 = NewDouble((double)_2943);
        }
    }
    else {
        _2943 = NewDouble(DBL_PTR(_len_5678)->dbl - (double)_2942);
    }
    _2942 = NOVALUE;
    if (IS_SEQUENCE(_source_5676)){
            _2944 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2944 = 1;
    }
    _2945 = - _2944;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _2943;
    ((int *)_2)[2] = _2945;
    _2946 = MAKE_SEQ(_1);
    _2945 = NOVALUE;
    _2943 = NOVALUE;
    DeRef(_data_inlined_crash_at_42_5692);
    _data_inlined_crash_at_42_5692 = _2946;
    _2946 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_45_5693);
    _msg_inlined_crash_at_45_5693 = EPrintf(-9999999, _2941, _data_inlined_crash_at_42_5692);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_45_5693);

    /** end procedure*/
    goto L3; // [59] 62
L3: 
    DeRef(_data_inlined_crash_at_42_5692);
    _data_inlined_crash_at_42_5692 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_45_5693);
    _msg_inlined_crash_at_45_5693 = NOVALUE;
L2: 
L1: 

    /** 	if start > length(source) or len=0 then*/
    if (IS_SEQUENCE(_source_5676)){
            _2947 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2947 = 1;
    }
    if (IS_ATOM_INT(_start_5677)) {
        _2948 = (_start_5677 > _2947);
    }
    else {
        _2948 = (DBL_PTR(_start_5677)->dbl > (double)_2947);
    }
    _2947 = NOVALUE;
    if (_2948 != 0) {
        goto L4; // [75] 88
    }
    if (IS_ATOM_INT(_len_5678)) {
        _2950 = (_len_5678 == 0);
    }
    else {
        _2950 = (DBL_PTR(_len_5678)->dbl == (double)0);
    }
    if (_2950 == 0)
    {
        DeRef(_2950);
        _2950 = NOVALUE;
        goto L5; // [84] 95
    }
    else{
        DeRef(_2950);
        _2950 = NOVALUE;
    }
L4: 

    /** 		return ""*/
    RefDS(_5);
    DeRefDS(_source_5676);
    DeRef(_start_5677);
    DeRef(_len_5678);
    DeRef(_2948);
    _2948 = NOVALUE;
    return _5;
L5: 

    /** 	if start<1 then*/
    if (binary_op_a(GREATEREQ, _start_5677, 1)){
        goto L6; // [97] 107
    }

    /** 		start=1*/
    DeRef(_start_5677);
    _start_5677 = 1;
L6: 

    /** 	if start+len-1 >= length(source) then*/
    if (IS_ATOM_INT(_start_5677) && IS_ATOM_INT(_len_5678)) {
        _2952 = _start_5677 + _len_5678;
        if ((long)((unsigned long)_2952 + (unsigned long)HIGH_BITS) >= 0) 
        _2952 = NewDouble((double)_2952);
    }
    else {
        if (IS_ATOM_INT(_start_5677)) {
            _2952 = NewDouble((double)_start_5677 + DBL_PTR(_len_5678)->dbl);
        }
        else {
            if (IS_ATOM_INT(_len_5678)) {
                _2952 = NewDouble(DBL_PTR(_start_5677)->dbl + (double)_len_5678);
            }
            else
            _2952 = NewDouble(DBL_PTR(_start_5677)->dbl + DBL_PTR(_len_5678)->dbl);
        }
    }
    if (IS_ATOM_INT(_2952)) {
        _2953 = _2952 - 1;
        if ((long)((unsigned long)_2953 +(unsigned long) HIGH_BITS) >= 0){
            _2953 = NewDouble((double)_2953);
        }
    }
    else {
        _2953 = NewDouble(DBL_PTR(_2952)->dbl - (double)1);
    }
    DeRef(_2952);
    _2952 = NOVALUE;
    if (IS_SEQUENCE(_source_5676)){
            _2954 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2954 = 1;
    }
    if (binary_op_a(LESS, _2953, _2954)){
        DeRef(_2953);
        _2953 = NOVALUE;
        _2954 = NOVALUE;
        goto L7; // [120] 141
    }
    DeRef(_2953);
    _2953 = NOVALUE;
    _2954 = NOVALUE;

    /** 		return source[start..$]*/
    if (IS_SEQUENCE(_source_5676)){
            _2956 = SEQ_PTR(_source_5676)->length;
    }
    else {
        _2956 = 1;
    }
    rhs_slice_target = (object_ptr)&_2957;
    RHS_Slice(_source_5676, _start_5677, _2956);
    DeRefDS(_source_5676);
    DeRef(_start_5677);
    DeRef(_len_5678);
    DeRef(_2948);
    _2948 = NOVALUE;
    return _2957;
    goto L8; // [138] 161
L7: 

    /** 		return source[start..len+start-1]*/
    if (IS_ATOM_INT(_len_5678) && IS_ATOM_INT(_start_5677)) {
        _2958 = _len_5678 + _start_5677;
        if ((long)((unsigned long)_2958 + (unsigned long)HIGH_BITS) >= 0) 
        _2958 = NewDouble((double)_2958);
    }
    else {
        if (IS_ATOM_INT(_len_5678)) {
            _2958 = NewDouble((double)_len_5678 + DBL_PTR(_start_5677)->dbl);
        }
        else {
            if (IS_ATOM_INT(_start_5677)) {
                _2958 = NewDouble(DBL_PTR(_len_5678)->dbl + (double)_start_5677);
            }
            else
            _2958 = NewDouble(DBL_PTR(_len_5678)->dbl + DBL_PTR(_start_5677)->dbl);
        }
    }
    if (IS_ATOM_INT(_2958)) {
        _2959 = _2958 - 1;
    }
    else {
        _2959 = NewDouble(DBL_PTR(_2958)->dbl - (double)1);
    }
    DeRef(_2958);
    _2958 = NOVALUE;
    rhs_slice_target = (object_ptr)&_2960;
    RHS_Slice(_source_5676, _start_5677, _2959);
    DeRefDS(_source_5676);
    DeRef(_start_5677);
    DeRef(_len_5678);
    DeRef(_2948);
    _2948 = NOVALUE;
    DeRef(_2957);
    _2957 = NOVALUE;
    DeRef(_2959);
    _2959 = NOVALUE;
    return _2960;
L8: 
    ;
}
int mid() __attribute__ ((alias ("_23mid")));


int _23slice(int _source_5714, int _start_5715, int _stop_5716)
{
    int _2969 = NOVALUE;
    int _2964 = NOVALUE;
    int _2962 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if stop < 1 then */
    if (binary_op_a(GREATEREQ, _stop_5716, 1)){
        goto L1; // [5] 21
    }

    /** 		stop += length(source) */
    if (IS_SEQUENCE(_source_5714)){
            _2962 = SEQ_PTR(_source_5714)->length;
    }
    else {
        _2962 = 1;
    }
    _0 = _stop_5716;
    if (IS_ATOM_INT(_stop_5716)) {
        _stop_5716 = _stop_5716 + _2962;
        if ((long)((unsigned long)_stop_5716 + (unsigned long)HIGH_BITS) >= 0) 
        _stop_5716 = NewDouble((double)_stop_5716);
    }
    else {
        _stop_5716 = NewDouble(DBL_PTR(_stop_5716)->dbl + (double)_2962);
    }
    DeRef(_0);
    _2962 = NOVALUE;
    goto L2; // [18] 37
L1: 

    /** 	elsif stop > length(source) then */
    if (IS_SEQUENCE(_source_5714)){
            _2964 = SEQ_PTR(_source_5714)->length;
    }
    else {
        _2964 = 1;
    }
    if (binary_op_a(LESSEQ, _stop_5716, _2964)){
        _2964 = NOVALUE;
        goto L3; // [26] 36
    }
    _2964 = NOVALUE;

    /** 		stop = length(source) */
    DeRef(_stop_5716);
    if (IS_SEQUENCE(_source_5714)){
            _stop_5716 = SEQ_PTR(_source_5714)->length;
    }
    else {
        _stop_5716 = 1;
    }
L3: 
L2: 

    /** 	if start < 1 then */
    if (binary_op_a(GREATEREQ, _start_5715, 1)){
        goto L4; // [39] 49
    }

    /** 		start = 1 */
    DeRef(_start_5715);
    _start_5715 = 1;
L4: 

    /** 	if start > stop then*/
    if (binary_op_a(LESSEQ, _start_5715, _stop_5716)){
        goto L5; // [51] 62
    }

    /** 		return ""*/
    RefDS(_5);
    DeRefDS(_source_5714);
    DeRef(_start_5715);
    DeRef(_stop_5716);
    return _5;
L5: 

    /** 	return source[start..stop]*/
    rhs_slice_target = (object_ptr)&_2969;
    RHS_Slice(_source_5714, _start_5715, _stop_5716);
    DeRefDS(_source_5714);
    DeRef(_start_5715);
    DeRef(_stop_5716);
    return _2969;
    ;
}
int slice() __attribute__ ((alias ("_23slice")));


int _23vslice(int _source_5732, int _colno_5733, int _error_control_5734)
{
    int _substitutes_5735 = NOVALUE;
    int _current_sub_5736 = NOVALUE;
    int _msg_inlined_crash_at_10_5741 = NOVALUE;
    int _msg_inlined_crash_at_103_5761 = NOVALUE;
    int _data_inlined_crash_at_100_5760 = NOVALUE;
    int _2993 = NOVALUE;
    int _2992 = NOVALUE;
    int _2991 = NOVALUE;
    int _2990 = NOVALUE;
    int _2989 = NOVALUE;
    int _2987 = NOVALUE;
    int _2985 = NOVALUE;
    int _2984 = NOVALUE;
    int _2982 = NOVALUE;
    int _2978 = NOVALUE;
    int _2977 = NOVALUE;
    int _2976 = NOVALUE;
    int _2973 = NOVALUE;
    int _2972 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if colno < 1 then*/
    if (binary_op_a(GREATEREQ, _colno_5733, 1)){
        goto L1; // [5] 30
    }

    /** 		error:crash("sequence:vslice(): colno should be a valid index, but was %d",colno)*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_10_5741);
    _msg_inlined_crash_at_10_5741 = EPrintf(-9999999, _2971, _colno_5733);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_10_5741);

    /** end procedure*/
    goto L2; // [24] 27
L2: 
    DeRefi(_msg_inlined_crash_at_10_5741);
    _msg_inlined_crash_at_10_5741 = NOVALUE;
L1: 

    /** 	if atom(error_control) then*/
    _2972 = IS_ATOM(_error_control_5734);
    if (_2972 == 0)
    {
        _2972 = NOVALUE;
        goto L3; // [35] 51
    }
    else{
        _2972 = NOVALUE;
    }

    /** 		substitutes =-(not error_control)*/
    if (IS_ATOM_INT(_error_control_5734)) {
        _2973 = (_error_control_5734 == 0);
    }
    else {
        _2973 = unary_op(NOT, _error_control_5734);
    }
    if (IS_ATOM_INT(_2973)) {
        if ((unsigned long)_2973 == 0xC0000000)
        _substitutes_5735 = (int)NewDouble((double)-0xC0000000);
        else
        _substitutes_5735 = - _2973;
    }
    else {
        _substitutes_5735 = unary_op(UMINUS, _2973);
    }
    DeRef(_2973);
    _2973 = NOVALUE;
    if (!IS_ATOM_INT(_substitutes_5735)) {
        _1 = (long)(DBL_PTR(_substitutes_5735)->dbl);
        DeRefDS(_substitutes_5735);
        _substitutes_5735 = _1;
    }
    goto L4; // [48] 62
L3: 

    /** 		substitutes = length(error_control)*/
    if (IS_SEQUENCE(_error_control_5734)){
            _substitutes_5735 = SEQ_PTR(_error_control_5734)->length;
    }
    else {
        _substitutes_5735 = 1;
    }

    /** 		current_sub = 0*/
    _current_sub_5736 = 0;
L4: 

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_5732)){
            _2976 = SEQ_PTR(_source_5732)->length;
    }
    else {
        _2976 = 1;
    }
    {
        int _i_5749;
        _i_5749 = 1;
L5: 
        if (_i_5749 > _2976){
            goto L6; // [67] 221
        }

        /** 		if colno > length(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5732);
        _2977 = (int)*(((s1_ptr)_2)->base + _i_5749);
        if (IS_SEQUENCE(_2977)){
                _2978 = SEQ_PTR(_2977)->length;
        }
        else {
            _2978 = 1;
        }
        _2977 = NOVALUE;
        if (binary_op_a(LESSEQ, _colno_5733, _2978)){
            _2978 = NOVALUE;
            goto L7; // [83] 186
        }
        _2978 = NOVALUE;

        /** 			if substitutes = -1 then*/
        if (_substitutes_5735 != -1)
        goto L8; // [91] 125

        /** 				error:crash("sequence:vslice(): colno should be a valid index on the %d-th element, but was %d", {i, colno})*/
        Ref(_colno_5733);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_5749;
        ((int *)_2)[2] = _colno_5733;
        _2982 = MAKE_SEQ(_1);
        DeRef(_data_inlined_crash_at_100_5760);
        _data_inlined_crash_at_100_5760 = _2982;
        _2982 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_103_5761);
        _msg_inlined_crash_at_103_5761 = EPrintf(-9999999, _2981, _data_inlined_crash_at_100_5760);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_103_5761);

        /** end procedure*/
        goto L9; // [117] 120
L9: 
        DeRef(_data_inlined_crash_at_100_5760);
        _data_inlined_crash_at_100_5760 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_103_5761);
        _msg_inlined_crash_at_103_5761 = NOVALUE;
        goto LA; // [122] 214
L8: 

        /** 			elsif substitutes = 0 then*/
        if (_substitutes_5735 != 0)
        goto LB; // [127] 149

        /** 				return source[1..i-1]*/
        _2984 = _i_5749 - 1;
        rhs_slice_target = (object_ptr)&_2985;
        RHS_Slice(_source_5732, 1, _2984);
        DeRefDS(_source_5732);
        DeRef(_colno_5733);
        DeRef(_error_control_5734);
        _2977 = NOVALUE;
        _2984 = NOVALUE;
        return _2985;
        goto LA; // [146] 214
LB: 

        /** 				current_sub += 1*/
        _current_sub_5736 = _current_sub_5736 + 1;

        /** 				if current_sub > length(error_control) then*/
        if (IS_SEQUENCE(_error_control_5734)){
                _2987 = SEQ_PTR(_error_control_5734)->length;
        }
        else {
            _2987 = 1;
        }
        if (_current_sub_5736 <= _2987)
        goto LC; // [162] 172

        /** 					current_sub = 1*/
        _current_sub_5736 = 1;
LC: 

        /** 				source[i] = error_control[current_sub]*/
        _2 = (int)SEQ_PTR(_error_control_5734);
        _2989 = (int)*(((s1_ptr)_2)->base + _current_sub_5736);
        Ref(_2989);
        _2 = (int)SEQ_PTR(_source_5732);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5732 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5749);
        _1 = *(int *)_2;
        *(int *)_2 = _2989;
        if( _1 != _2989 ){
            DeRef(_1);
        }
        _2989 = NOVALUE;
        goto LA; // [183] 214
L7: 

        /** 			if sequence(source[i]) then*/
        _2 = (int)SEQ_PTR(_source_5732);
        _2990 = (int)*(((s1_ptr)_2)->base + _i_5749);
        _2991 = IS_SEQUENCE(_2990);
        _2990 = NOVALUE;
        if (_2991 == 0)
        {
            _2991 = NOVALUE;
            goto LD; // [195] 213
        }
        else{
            _2991 = NOVALUE;
        }

        /** 				source[i] = source[i][colno]*/
        _2 = (int)SEQ_PTR(_source_5732);
        _2992 = (int)*(((s1_ptr)_2)->base + _i_5749);
        _2 = (int)SEQ_PTR(_2992);
        if (!IS_ATOM_INT(_colno_5733)){
            _2993 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_colno_5733)->dbl));
        }
        else{
            _2993 = (int)*(((s1_ptr)_2)->base + _colno_5733);
        }
        _2992 = NOVALUE;
        Ref(_2993);
        _2 = (int)SEQ_PTR(_source_5732);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _source_5732 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5749);
        _1 = *(int *)_2;
        *(int *)_2 = _2993;
        if( _1 != _2993 ){
            DeRef(_1);
        }
        _2993 = NOVALUE;
LD: 
LA: 

        /** 	end for*/
        _i_5749 = _i_5749 + 1;
        goto L5; // [216] 74
L6: 
        ;
    }

    /** 	return source*/
    DeRef(_colno_5733);
    DeRef(_error_control_5734);
    _2977 = NOVALUE;
    DeRef(_2984);
    _2984 = NOVALUE;
    DeRef(_2985);
    _2985 = NOVALUE;
    return _source_5732;
    ;
}
int vslice() __attribute__ ((alias ("_23vslice")));


int _23patch(int _target_5780, int _source_5781, int _start_5782, int _filler_5783)
{
    int _3031 = NOVALUE;
    int _3030 = NOVALUE;
    int _3029 = NOVALUE;
    int _3028 = NOVALUE;
    int _3027 = NOVALUE;
    int _3026 = NOVALUE;
    int _3025 = NOVALUE;
    int _3024 = NOVALUE;
    int _3022 = NOVALUE;
    int _3021 = NOVALUE;
    int _3019 = NOVALUE;
    int _3018 = NOVALUE;
    int _3017 = NOVALUE;
    int _3016 = NOVALUE;
    int _3015 = NOVALUE;
    int _3014 = NOVALUE;
    int _3013 = NOVALUE;
    int _3012 = NOVALUE;
    int _3011 = NOVALUE;
    int _3010 = NOVALUE;
    int _3009 = NOVALUE;
    int _3008 = NOVALUE;
    int _3005 = NOVALUE;
    int _3004 = NOVALUE;
    int _3003 = NOVALUE;
    int _3002 = NOVALUE;
    int _3001 = NOVALUE;
    int _3000 = NOVALUE;
    int _2999 = NOVALUE;
    int _2998 = NOVALUE;
    int _2997 = NOVALUE;
    int _2995 = NOVALUE;
    int _2994 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_5782)) {
        _1 = (long)(DBL_PTR(_start_5782)->dbl);
        DeRefDS(_start_5782);
        _start_5782 = _1;
    }

    /** 	if start + length(source) <= 0 then*/
    if (IS_SEQUENCE(_source_5781)){
            _2994 = SEQ_PTR(_source_5781)->length;
    }
    else {
        _2994 = 1;
    }
    _2995 = _start_5782 + _2994;
    if ((long)((unsigned long)_2995 + (unsigned long)HIGH_BITS) >= 0) 
    _2995 = NewDouble((double)_2995);
    _2994 = NOVALUE;
    if (binary_op_a(GREATER, _2995, 0)){
        DeRef(_2995);
        _2995 = NOVALUE;
        goto L1; // [16] 53
    }
    DeRef(_2995);
    _2995 = NOVALUE;

    /** 		return source & repeat(filler, -start-length(source))+1 & target*/
    if ((unsigned long)_start_5782 == 0xC0000000)
    _2997 = (int)NewDouble((double)-0xC0000000);
    else
    _2997 = - _start_5782;
    if (IS_SEQUENCE(_source_5781)){
            _2998 = SEQ_PTR(_source_5781)->length;
    }
    else {
        _2998 = 1;
    }
    if (IS_ATOM_INT(_2997)) {
        _2999 = _2997 - _2998;
    }
    else {
        _2999 = NewDouble(DBL_PTR(_2997)->dbl - (double)_2998);
    }
    DeRef(_2997);
    _2997 = NOVALUE;
    _2998 = NOVALUE;
    _3000 = Repeat(_filler_5783, _2999);
    DeRef(_2999);
    _2999 = NOVALUE;
    _3001 = binary_op(PLUS, 1, _3000);
    DeRefDS(_3000);
    _3000 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _target_5780;
        concat_list[1] = _3001;
        concat_list[2] = _source_5781;
        Concat_N((object_ptr)&_3002, concat_list, 3);
    }
    DeRefDS(_3001);
    _3001 = NOVALUE;
    DeRefDS(_target_5780);
    DeRefDS(_source_5781);
    DeRef(_filler_5783);
    return _3002;
    goto L2; // [50] 221
L1: 

    /** 	elsif start + length(source) <= length(target) then*/
    if (IS_SEQUENCE(_source_5781)){
            _3003 = SEQ_PTR(_source_5781)->length;
    }
    else {
        _3003 = 1;
    }
    _3004 = _start_5782 + _3003;
    if ((long)((unsigned long)_3004 + (unsigned long)HIGH_BITS) >= 0) 
    _3004 = NewDouble((double)_3004);
    _3003 = NOVALUE;
    if (IS_SEQUENCE(_target_5780)){
            _3005 = SEQ_PTR(_target_5780)->length;
    }
    else {
        _3005 = 1;
    }
    if (binary_op_a(GREATER, _3004, _3005)){
        DeRef(_3004);
        _3004 = NOVALUE;
        _3005 = NOVALUE;
        goto L3; // [65] 143
    }
    DeRef(_3004);
    _3004 = NOVALUE;
    _3005 = NOVALUE;

    /** 		if start<=0 then*/
    if (_start_5782 > 0)
    goto L4; // [71] 103

    /** 			return source & target[start+length(source)..$]*/
    if (IS_SEQUENCE(_source_5781)){
            _3008 = SEQ_PTR(_source_5781)->length;
    }
    else {
        _3008 = 1;
    }
    _3009 = _start_5782 + _3008;
    if ((long)((unsigned long)_3009 + (unsigned long)HIGH_BITS) >= 0) 
    _3009 = NewDouble((double)_3009);
    _3008 = NOVALUE;
    if (IS_SEQUENCE(_target_5780)){
            _3010 = SEQ_PTR(_target_5780)->length;
    }
    else {
        _3010 = 1;
    }
    rhs_slice_target = (object_ptr)&_3011;
    RHS_Slice(_target_5780, _3009, _3010);
    Concat((object_ptr)&_3012, _source_5781, _3011);
    DeRefDS(_3011);
    _3011 = NOVALUE;
    DeRefDS(_target_5780);
    DeRefDS(_source_5781);
    DeRef(_filler_5783);
    DeRef(_3002);
    _3002 = NOVALUE;
    DeRef(_3009);
    _3009 = NOVALUE;
    return _3012;
    goto L2; // [100] 221
L4: 

    /**         	return target[1..start-1] & source &  target[start+length(source)..$]*/
    _3013 = _start_5782 - 1;
    rhs_slice_target = (object_ptr)&_3014;
    RHS_Slice(_target_5780, 1, _3013);
    if (IS_SEQUENCE(_source_5781)){
            _3015 = SEQ_PTR(_source_5781)->length;
    }
    else {
        _3015 = 1;
    }
    _3016 = _start_5782 + _3015;
    if ((long)((unsigned long)_3016 + (unsigned long)HIGH_BITS) >= 0) 
    _3016 = NewDouble((double)_3016);
    _3015 = NOVALUE;
    if (IS_SEQUENCE(_target_5780)){
            _3017 = SEQ_PTR(_target_5780)->length;
    }
    else {
        _3017 = 1;
    }
    rhs_slice_target = (object_ptr)&_3018;
    RHS_Slice(_target_5780, _3016, _3017);
    {
        int concat_list[3];

        concat_list[0] = _3018;
        concat_list[1] = _source_5781;
        concat_list[2] = _3014;
        Concat_N((object_ptr)&_3019, concat_list, 3);
    }
    DeRefDS(_3018);
    _3018 = NOVALUE;
    DeRefDS(_3014);
    _3014 = NOVALUE;
    DeRefDS(_target_5780);
    DeRefDS(_source_5781);
    DeRef(_filler_5783);
    DeRef(_3002);
    _3002 = NOVALUE;
    DeRef(_3009);
    _3009 = NOVALUE;
    DeRef(_3012);
    _3012 = NOVALUE;
    _3013 = NOVALUE;
    DeRef(_3016);
    _3016 = NOVALUE;
    return _3019;
    goto L2; // [140] 221
L3: 

    /** 	elsif start <= 1 then*/
    if (_start_5782 > 1)
    goto L5; // [145] 158

    /** 		return source*/
    DeRefDS(_target_5780);
    DeRef(_filler_5783);
    DeRef(_3002);
    _3002 = NOVALUE;
    DeRef(_3009);
    _3009 = NOVALUE;
    DeRef(_3012);
    _3012 = NOVALUE;
    DeRef(_3013);
    _3013 = NOVALUE;
    DeRef(_3019);
    _3019 = NOVALUE;
    DeRef(_3016);
    _3016 = NOVALUE;
    return _source_5781;
    goto L2; // [155] 221
L5: 

    /** 	elsif start <= length(target)+1 then*/
    if (IS_SEQUENCE(_target_5780)){
            _3021 = SEQ_PTR(_target_5780)->length;
    }
    else {
        _3021 = 1;
    }
    _3022 = _3021 + 1;
    _3021 = NOVALUE;
    if (_start_5782 > _3022)
    goto L6; // [167] 193

    /** 		return target[1..start-1] & source*/
    _3024 = _start_5782 - 1;
    rhs_slice_target = (object_ptr)&_3025;
    RHS_Slice(_target_5780, 1, _3024);
    Concat((object_ptr)&_3026, _3025, _source_5781);
    DeRefDS(_3025);
    _3025 = NOVALUE;
    DeRef(_3025);
    _3025 = NOVALUE;
    DeRefDS(_target_5780);
    DeRefDS(_source_5781);
    DeRef(_filler_5783);
    DeRef(_3002);
    _3002 = NOVALUE;
    DeRef(_3009);
    _3009 = NOVALUE;
    DeRef(_3012);
    _3012 = NOVALUE;
    DeRef(_3013);
    _3013 = NOVALUE;
    DeRef(_3019);
    _3019 = NOVALUE;
    DeRef(_3016);
    _3016 = NOVALUE;
    _3022 = NOVALUE;
    _3024 = NOVALUE;
    return _3026;
    goto L2; // [190] 221
L6: 

    /** 		return target & repeat(filler,start-length(target)-1) & source*/
    if (IS_SEQUENCE(_target_5780)){
            _3027 = SEQ_PTR(_target_5780)->length;
    }
    else {
        _3027 = 1;
    }
    _3028 = _start_5782 - _3027;
    if ((long)((unsigned long)_3028 +(unsigned long) HIGH_BITS) >= 0){
        _3028 = NewDouble((double)_3028);
    }
    _3027 = NOVALUE;
    if (IS_ATOM_INT(_3028)) {
        _3029 = _3028 - 1;
    }
    else {
        _3029 = NewDouble(DBL_PTR(_3028)->dbl - (double)1);
    }
    DeRef(_3028);
    _3028 = NOVALUE;
    _3030 = Repeat(_filler_5783, _3029);
    DeRef(_3029);
    _3029 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _source_5781;
        concat_list[1] = _3030;
        concat_list[2] = _target_5780;
        Concat_N((object_ptr)&_3031, concat_list, 3);
    }
    DeRefDS(_3030);
    _3030 = NOVALUE;
    DeRefDS(_target_5780);
    DeRefDS(_source_5781);
    DeRef(_filler_5783);
    DeRef(_3002);
    _3002 = NOVALUE;
    DeRef(_3009);
    _3009 = NOVALUE;
    DeRef(_3012);
    _3012 = NOVALUE;
    DeRef(_3013);
    _3013 = NOVALUE;
    DeRef(_3019);
    _3019 = NOVALUE;
    DeRef(_3016);
    _3016 = NOVALUE;
    DeRef(_3022);
    _3022 = NOVALUE;
    DeRef(_3024);
    _3024 = NOVALUE;
    DeRef(_3026);
    _3026 = NOVALUE;
    return _3031;
L2: 
    ;
}
int patch() __attribute__ ((alias ("_23patch")));


int _23remove_all(int _needle_5831, int _haystack_5832)
{
    int _found_5833 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer found = 1*/
    _found_5833 = 1;

    /** 	while found entry do*/
    goto L1; // [10] 26
L2: 
    if (_found_5833 == 0)
    {
        goto L3; // [13] 38
    }
    else{
    }

    /** 		haystack = remove( haystack, found )*/
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_5832);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_found_5833)) ? _found_5833 : (long)(DBL_PTR(_found_5833)->dbl);
        int stop = (IS_ATOM_INT(_found_5833)) ? _found_5833 : (long)(DBL_PTR(_found_5833)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_5832), start, &_haystack_5832 );
            }
            else Tail(SEQ_PTR(_haystack_5832), stop+1, &_haystack_5832);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_5832), start, &_haystack_5832);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_5832 = Remove_elements(start, stop, (SEQ_PTR(_haystack_5832)->ref == 1));
        }
    }

    /** 	entry*/
L1: 

    /** 		found = find( needle, haystack, found )*/
    _found_5833 = find_from(_needle_5831, _haystack_5832, _found_5833);

    /** 	end while*/
    goto L2; // [35] 13
L3: 

    /** 	return haystack*/
    DeRef(_needle_5831);
    return _haystack_5832;
    ;
}
int remove_all() __attribute__ ((alias ("_23remove_all")));


int _23retain_all(int _needles_5839, int _haystack_5840)
{
    int _lp_5841 = NOVALUE;
    int _np_5842 = NOVALUE;
    int _result_5843 = NOVALUE;
    int _3049 = NOVALUE;
    int _3046 = NOVALUE;
    int _3045 = NOVALUE;
    int _3043 = NOVALUE;
    int _3042 = NOVALUE;
    int _3041 = NOVALUE;
    int _3038 = NOVALUE;
    int _3036 = NOVALUE;
    int _3034 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(needles) then*/
    _3034 = IS_ATOM(_needles_5839);
    if (_3034 == 0)
    {
        _3034 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _3034 = NOVALUE;
    }

    /** 		needles = {needles}*/
    _0 = _needles_5839;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needles_5839);
    *((int *)(_2+4)) = _needles_5839;
    _needles_5839 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if length(needles) = 0 then*/
    if (IS_SEQUENCE(_needles_5839)){
            _3036 = SEQ_PTR(_needles_5839)->length;
    }
    else {
        _3036 = 1;
    }
    if (_3036 != 0)
    goto L2; // [23] 34

    /** 		return {}*/
    RefDS(_5);
    DeRef(_needles_5839);
    DeRefDS(_haystack_5840);
    DeRef(_result_5843);
    return _5;
L2: 

    /** 	if length(haystack) = 0 then*/
    if (IS_SEQUENCE(_haystack_5840)){
            _3038 = SEQ_PTR(_haystack_5840)->length;
    }
    else {
        _3038 = 1;
    }
    if (_3038 != 0)
    goto L3; // [39] 50

    /** 		return {}*/
    RefDS(_5);
    DeRef(_needles_5839);
    DeRefDS(_haystack_5840);
    DeRef(_result_5843);
    return _5;
L3: 

    /** 	result = haystack*/
    RefDS(_haystack_5840);
    DeRef(_result_5843);
    _result_5843 = _haystack_5840;

    /** 	lp = length(haystack)*/
    if (IS_SEQUENCE(_haystack_5840)){
            _lp_5841 = SEQ_PTR(_haystack_5840)->length;
    }
    else {
        _lp_5841 = 1;
    }

    /** 	np = 1*/
    _np_5842 = 1;

    /** 	for i = 1 to length(haystack) do*/
    if (IS_SEQUENCE(_haystack_5840)){
            _3041 = SEQ_PTR(_haystack_5840)->length;
    }
    else {
        _3041 = 1;
    }
    {
        int _i_5855;
        _i_5855 = 1;
L4: 
        if (_i_5855 > _3041){
            goto L5; // [72] 138
        }

        /** 		if find(haystack[i], needles) then*/
        _2 = (int)SEQ_PTR(_haystack_5840);
        _3042 = (int)*(((s1_ptr)_2)->base + _i_5855);
        _3043 = find_from(_3042, _needles_5839, 1);
        _3042 = NOVALUE;
        if (_3043 == 0)
        {
            _3043 = NOVALUE;
            goto L6; // [90] 124
        }
        else{
            _3043 = NOVALUE;
        }

        /** 			if np < i then*/
        if (_np_5842 >= _i_5855)
        goto L7; // [95] 115

        /** 				result[np .. lp] = haystack[i..$]*/
        if (IS_SEQUENCE(_haystack_5840)){
                _3045 = SEQ_PTR(_haystack_5840)->length;
        }
        else {
            _3045 = 1;
        }
        rhs_slice_target = (object_ptr)&_3046;
        RHS_Slice(_haystack_5840, _i_5855, _3045);
        assign_slice_seq = (s1_ptr *)&_result_5843;
        AssignSlice(_np_5842, _lp_5841, _3046);
        DeRefDS(_3046);
        _3046 = NOVALUE;
L7: 

        /** 			np += 1*/
        _np_5842 = _np_5842 + 1;
        goto L8; // [121] 131
L6: 

        /** 			lp -= 1*/
        _lp_5841 = _lp_5841 - 1;
L8: 

        /** 	end for*/
        _i_5855 = _i_5855 + 1;
        goto L4; // [133] 79
L5: 
        ;
    }

    /** 	return result[1 .. lp]*/
    rhs_slice_target = (object_ptr)&_3049;
    RHS_Slice(_result_5843, 1, _lp_5841);
    DeRef(_needles_5839);
    DeRefDS(_haystack_5840);
    DeRefDS(_result_5843);
    return _3049;
    ;
}
int retain_all() __attribute__ ((alias ("_23retain_all")));


int _23filter(int _source_5870, int _rid_5871, int _userdata_5872, int _rangetype_5873)
{
    int _dest_5874 = NOVALUE;
    int _idx_5875 = NOVALUE;
    int _3224 = NOVALUE;
    int _3223 = NOVALUE;
    int _3221 = NOVALUE;
    int _3220 = NOVALUE;
    int _3219 = NOVALUE;
    int _3218 = NOVALUE;
    int _3217 = NOVALUE;
    int _3214 = NOVALUE;
    int _3213 = NOVALUE;
    int _3212 = NOVALUE;
    int _3211 = NOVALUE;
    int _3208 = NOVALUE;
    int _3207 = NOVALUE;
    int _3206 = NOVALUE;
    int _3205 = NOVALUE;
    int _3204 = NOVALUE;
    int _3201 = NOVALUE;
    int _3200 = NOVALUE;
    int _3199 = NOVALUE;
    int _3198 = NOVALUE;
    int _3195 = NOVALUE;
    int _3194 = NOVALUE;
    int _3193 = NOVALUE;
    int _3192 = NOVALUE;
    int _3191 = NOVALUE;
    int _3188 = NOVALUE;
    int _3187 = NOVALUE;
    int _3186 = NOVALUE;
    int _3185 = NOVALUE;
    int _3182 = NOVALUE;
    int _3181 = NOVALUE;
    int _3180 = NOVALUE;
    int _3179 = NOVALUE;
    int _3178 = NOVALUE;
    int _3175 = NOVALUE;
    int _3174 = NOVALUE;
    int _3173 = NOVALUE;
    int _3172 = NOVALUE;
    int _3169 = NOVALUE;
    int _3168 = NOVALUE;
    int _3167 = NOVALUE;
    int _3166 = NOVALUE;
    int _3165 = NOVALUE;
    int _3162 = NOVALUE;
    int _3161 = NOVALUE;
    int _3160 = NOVALUE;
    int _3156 = NOVALUE;
    int _3153 = NOVALUE;
    int _3152 = NOVALUE;
    int _3151 = NOVALUE;
    int _3149 = NOVALUE;
    int _3148 = NOVALUE;
    int _3147 = NOVALUE;
    int _3146 = NOVALUE;
    int _3145 = NOVALUE;
    int _3142 = NOVALUE;
    int _3141 = NOVALUE;
    int _3140 = NOVALUE;
    int _3138 = NOVALUE;
    int _3137 = NOVALUE;
    int _3136 = NOVALUE;
    int _3135 = NOVALUE;
    int _3134 = NOVALUE;
    int _3131 = NOVALUE;
    int _3130 = NOVALUE;
    int _3129 = NOVALUE;
    int _3127 = NOVALUE;
    int _3126 = NOVALUE;
    int _3125 = NOVALUE;
    int _3124 = NOVALUE;
    int _3123 = NOVALUE;
    int _3120 = NOVALUE;
    int _3119 = NOVALUE;
    int _3118 = NOVALUE;
    int _3116 = NOVALUE;
    int _3115 = NOVALUE;
    int _3114 = NOVALUE;
    int _3113 = NOVALUE;
    int _3112 = NOVALUE;
    int _3110 = NOVALUE;
    int _3109 = NOVALUE;
    int _3108 = NOVALUE;
    int _3104 = NOVALUE;
    int _3101 = NOVALUE;
    int _3100 = NOVALUE;
    int _3099 = NOVALUE;
    int _3096 = NOVALUE;
    int _3093 = NOVALUE;
    int _3092 = NOVALUE;
    int _3091 = NOVALUE;
    int _3088 = NOVALUE;
    int _3085 = NOVALUE;
    int _3084 = NOVALUE;
    int _3083 = NOVALUE;
    int _3080 = NOVALUE;
    int _3077 = NOVALUE;
    int _3076 = NOVALUE;
    int _3075 = NOVALUE;
    int _3071 = NOVALUE;
    int _3068 = NOVALUE;
    int _3067 = NOVALUE;
    int _3066 = NOVALUE;
    int _3063 = NOVALUE;
    int _3060 = NOVALUE;
    int _3059 = NOVALUE;
    int _3058 = NOVALUE;
    int _3052 = NOVALUE;
    int _3050 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_5870)){
            _3050 = SEQ_PTR(_source_5870)->length;
    }
    else {
        _3050 = 1;
    }
    if (_3050 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRef(_rid_5871);
    DeRef(_userdata_5872);
    DeRef(_rangetype_5873);
    DeRef(_dest_5874);
    return _source_5870;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_5870)){
            _3052 = SEQ_PTR(_source_5870)->length;
    }
    else {
        _3052 = 1;
    }
    DeRef(_dest_5874);
    _dest_5874 = Repeat(0, _3052);
    _3052 = NOVALUE;

    /** 	idx = 0*/
    _idx_5875 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_5871, _3054);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3058 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3058 = 1;
        }
        {
            int _a_5887;
            _a_5887 = 1;
L2: 
            if (_a_5887 > _3058){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3059 = (int)*(((s1_ptr)_2)->base + _a_5887);
            if (IS_ATOM_INT(_3059) && IS_ATOM_INT(_userdata_5872)){
                _3060 = (_3059 < _userdata_5872) ? -1 : (_3059 > _userdata_5872);
            }
            else{
                _3060 = compare(_3059, _userdata_5872);
            }
            _3059 = NOVALUE;
            if (_3060 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3063 = (int)*(((s1_ptr)_2)->base + _a_5887);
            Ref(_3063);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3063;
            if( _1 != _3063 ){
                DeRef(_1);
            }
            _3063 = NOVALUE;
L4: 

            /** 			end for*/
            _a_5887 = _a_5887 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3066 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3066 = 1;
        }
        {
            int _a_5899;
            _a_5899 = 1;
L6: 
            if (_a_5899 > _3066){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3067 = (int)*(((s1_ptr)_2)->base + _a_5899);
            if (IS_ATOM_INT(_3067) && IS_ATOM_INT(_userdata_5872)){
                _3068 = (_3067 < _userdata_5872) ? -1 : (_3067 > _userdata_5872);
            }
            else{
                _3068 = compare(_3067, _userdata_5872);
            }
            _3067 = NOVALUE;
            if (_3068 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3071 = (int)*(((s1_ptr)_2)->base + _a_5899);
            Ref(_3071);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3071;
            if( _1 != _3071 ){
                DeRef(_1);
            }
            _3071 = NOVALUE;
L8: 

            /** 			end for*/
            _a_5899 = _a_5899 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3075 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3075 = 1;
        }
        {
            int _a_5912;
            _a_5912 = 1;
L9: 
            if (_a_5912 > _3075){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3076 = (int)*(((s1_ptr)_2)->base + _a_5912);
            if (IS_ATOM_INT(_3076) && IS_ATOM_INT(_userdata_5872)){
                _3077 = (_3076 < _userdata_5872) ? -1 : (_3076 > _userdata_5872);
            }
            else{
                _3077 = compare(_3076, _userdata_5872);
            }
            _3076 = NOVALUE;
            if (_3077 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3080 = (int)*(((s1_ptr)_2)->base + _a_5912);
            Ref(_3080);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3080;
            if( _1 != _3080 ){
                DeRef(_1);
            }
            _3080 = NOVALUE;
LB: 

            /** 			end for*/
            _a_5912 = _a_5912 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3083 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3083 = 1;
        }
        {
            int _a_5924;
            _a_5924 = 1;
LC: 
            if (_a_5924 > _3083){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3084 = (int)*(((s1_ptr)_2)->base + _a_5924);
            if (IS_ATOM_INT(_3084) && IS_ATOM_INT(_userdata_5872)){
                _3085 = (_3084 < _userdata_5872) ? -1 : (_3084 > _userdata_5872);
            }
            else{
                _3085 = compare(_3084, _userdata_5872);
            }
            _3084 = NOVALUE;
            if (_3085 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3088 = (int)*(((s1_ptr)_2)->base + _a_5924);
            Ref(_3088);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3088;
            if( _1 != _3088 ){
                DeRef(_1);
            }
            _3088 = NOVALUE;
LE: 

            /** 			end for*/
            _a_5924 = _a_5924 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3091 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3091 = 1;
        }
        {
            int _a_5936;
            _a_5936 = 1;
LF: 
            if (_a_5936 > _3091){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3092 = (int)*(((s1_ptr)_2)->base + _a_5936);
            if (IS_ATOM_INT(_3092) && IS_ATOM_INT(_userdata_5872)){
                _3093 = (_3092 < _userdata_5872) ? -1 : (_3092 > _userdata_5872);
            }
            else{
                _3093 = compare(_3092, _userdata_5872);
            }
            _3092 = NOVALUE;
            if (_3093 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3096 = (int)*(((s1_ptr)_2)->base + _a_5936);
            Ref(_3096);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3096;
            if( _1 != _3096 ){
                DeRef(_1);
            }
            _3096 = NOVALUE;
L11: 

            /** 			end for*/
            _a_5936 = _a_5936 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3099 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3099 = 1;
        }
        {
            int _a_5948;
            _a_5948 = 1;
L12: 
            if (_a_5948 > _3099){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3100 = (int)*(((s1_ptr)_2)->base + _a_5948);
            if (IS_ATOM_INT(_3100) && IS_ATOM_INT(_userdata_5872)){
                _3101 = (_3100 < _userdata_5872) ? -1 : (_3100 > _userdata_5872);
            }
            else{
                _3101 = compare(_3100, _userdata_5872);
            }
            _3100 = NOVALUE;
            if (_3101 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3104 = (int)*(((s1_ptr)_2)->base + _a_5948);
            Ref(_3104);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3104;
            if( _1 != _3104 ){
                DeRef(_1);
            }
            _3104 = NOVALUE;
L14: 

            /** 			end for*/
            _a_5948 = _a_5948 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_5873, _3106);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3108 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3108 = 1;
            }
            {
                int _a_5962;
                _a_5962 = 1;
L15: 
                if (_a_5962 > _3108){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3109 = (int)*(((s1_ptr)_2)->base + _a_5962);
                _3110 = find_from(_3109, _userdata_5872, 1);
                _3109 = NOVALUE;
                if (_3110 == 0)
                {
                    _3110 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _3110 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3112 = (int)*(((s1_ptr)_2)->base + _a_5962);
                Ref(_3112);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3112;
                if( _1 != _3112 ){
                    DeRef(_1);
                }
                _3112 = NOVALUE;
L17: 

                /** 					end for*/
                _a_5962 = _a_5962 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3113 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3113 = 1;
            }
            {
                int _a_5971;
                _a_5971 = 1;
L18: 
                if (_a_5971 > _3113){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3114 = (int)*(((s1_ptr)_2)->base + _a_5971);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3115 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3114) && IS_ATOM_INT(_3115)){
                    _3116 = (_3114 < _3115) ? -1 : (_3114 > _3115);
                }
                else{
                    _3116 = compare(_3114, _3115);
                }
                _3114 = NOVALUE;
                _3115 = NOVALUE;
                if (_3116 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3118 = (int)*(((s1_ptr)_2)->base + _a_5971);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3119 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3118) && IS_ATOM_INT(_3119)){
                    _3120 = (_3118 < _3119) ? -1 : (_3118 > _3119);
                }
                else{
                    _3120 = compare(_3118, _3119);
                }
                _3118 = NOVALUE;
                _3119 = NOVALUE;
                if (_3120 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3123 = (int)*(((s1_ptr)_2)->base + _a_5971);
                Ref(_3123);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3123;
                if( _1 != _3123 ){
                    DeRef(_1);
                }
                _3123 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_5971 = _a_5971 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3124 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3124 = 1;
            }
            {
                int _a_5987;
                _a_5987 = 1;
L1C: 
                if (_a_5987 > _3124){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3125 = (int)*(((s1_ptr)_2)->base + _a_5987);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3126 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3125) && IS_ATOM_INT(_3126)){
                    _3127 = (_3125 < _3126) ? -1 : (_3125 > _3126);
                }
                else{
                    _3127 = compare(_3125, _3126);
                }
                _3125 = NOVALUE;
                _3126 = NOVALUE;
                if (_3127 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3129 = (int)*(((s1_ptr)_2)->base + _a_5987);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3130 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3129) && IS_ATOM_INT(_3130)){
                    _3131 = (_3129 < _3130) ? -1 : (_3129 > _3130);
                }
                else{
                    _3131 = compare(_3129, _3130);
                }
                _3129 = NOVALUE;
                _3130 = NOVALUE;
                if (_3131 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3134 = (int)*(((s1_ptr)_2)->base + _a_5987);
                Ref(_3134);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3134;
                if( _1 != _3134 ){
                    DeRef(_1);
                }
                _3134 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_5987 = _a_5987 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3135 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3135 = 1;
            }
            {
                int _a_6003;
                _a_6003 = 1;
L20: 
                if (_a_6003 > _3135){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3136 = (int)*(((s1_ptr)_2)->base + _a_6003);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3137 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3136) && IS_ATOM_INT(_3137)){
                    _3138 = (_3136 < _3137) ? -1 : (_3136 > _3137);
                }
                else{
                    _3138 = compare(_3136, _3137);
                }
                _3136 = NOVALUE;
                _3137 = NOVALUE;
                if (_3138 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3140 = (int)*(((s1_ptr)_2)->base + _a_6003);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3141 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3140) && IS_ATOM_INT(_3141)){
                    _3142 = (_3140 < _3141) ? -1 : (_3140 > _3141);
                }
                else{
                    _3142 = compare(_3140, _3141);
                }
                _3140 = NOVALUE;
                _3141 = NOVALUE;
                if (_3142 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3145 = (int)*(((s1_ptr)_2)->base + _a_6003);
                Ref(_3145);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3145;
                if( _1 != _3145 ){
                    DeRef(_1);
                }
                _3145 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_6003 = _a_6003 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3146 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3146 = 1;
            }
            {
                int _a_6019;
                _a_6019 = 1;
L24: 
                if (_a_6019 > _3146){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3147 = (int)*(((s1_ptr)_2)->base + _a_6019);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3148 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3147) && IS_ATOM_INT(_3148)){
                    _3149 = (_3147 < _3148) ? -1 : (_3147 > _3148);
                }
                else{
                    _3149 = compare(_3147, _3148);
                }
                _3147 = NOVALUE;
                _3148 = NOVALUE;
                if (_3149 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3151 = (int)*(((s1_ptr)_2)->base + _a_6019);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3152 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3151) && IS_ATOM_INT(_3152)){
                    _3153 = (_3151 < _3152) ? -1 : (_3151 > _3152);
                }
                else{
                    _3153 = compare(_3151, _3152);
                }
                _3151 = NOVALUE;
                _3152 = NOVALUE;
                if (_3153 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3156 = (int)*(((s1_ptr)_2)->base + _a_6019);
                Ref(_3156);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3156;
                if( _1 != _3156 ){
                    DeRef(_1);
                }
                _3156 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_6019 = _a_6019 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_5873, _3158);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3160 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3160 = 1;
            }
            {
                int _a_6040;
                _a_6040 = 1;
L28: 
                if (_a_6040 > _3160){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3161 = (int)*(((s1_ptr)_2)->base + _a_6040);
                _3162 = find_from(_3161, _userdata_5872, 1);
                _3161 = NOVALUE;
                if (_3162 != 0)
                goto L2A; // [818] 838
                _3162 = NOVALUE;

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3165 = (int)*(((s1_ptr)_2)->base + _a_6040);
                Ref(_3165);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3165;
                if( _1 != _3165 ){
                    DeRef(_1);
                }
                _3165 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_6040 = _a_6040 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3166 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3166 = 1;
            }
            {
                int _a_6050;
                _a_6050 = 1;
L2B: 
                if (_a_6050 > _3166){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3167 = (int)*(((s1_ptr)_2)->base + _a_6050);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3168 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3167) && IS_ATOM_INT(_3168)){
                    _3169 = (_3167 < _3168) ? -1 : (_3167 > _3168);
                }
                else{
                    _3169 = compare(_3167, _3168);
                }
                _3167 = NOVALUE;
                _3168 = NOVALUE;
                if (_3169 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3172 = (int)*(((s1_ptr)_2)->base + _a_6050);
                Ref(_3172);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3172;
                if( _1 != _3172 ){
                    DeRef(_1);
                }
                _3172 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3173 = (int)*(((s1_ptr)_2)->base + _a_6050);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3174 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3173) && IS_ATOM_INT(_3174)){
                    _3175 = (_3173 < _3174) ? -1 : (_3173 > _3174);
                }
                else{
                    _3175 = compare(_3173, _3174);
                }
                _3173 = NOVALUE;
                _3174 = NOVALUE;
                if (_3175 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3178 = (int)*(((s1_ptr)_2)->base + _a_6050);
                Ref(_3178);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3178;
                if( _1 != _3178 ){
                    DeRef(_1);
                }
                _3178 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_6050 = _a_6050 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3179 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3179 = 1;
            }
            {
                int _a_6068;
                _a_6068 = 1;
L30: 
                if (_a_6068 > _3179){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3180 = (int)*(((s1_ptr)_2)->base + _a_6068);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3181 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3180) && IS_ATOM_INT(_3181)){
                    _3182 = (_3180 < _3181) ? -1 : (_3180 > _3181);
                }
                else{
                    _3182 = compare(_3180, _3181);
                }
                _3180 = NOVALUE;
                _3181 = NOVALUE;
                if (_3182 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3185 = (int)*(((s1_ptr)_2)->base + _a_6068);
                Ref(_3185);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3185;
                if( _1 != _3185 ){
                    DeRef(_1);
                }
                _3185 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3186 = (int)*(((s1_ptr)_2)->base + _a_6068);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3187 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3186) && IS_ATOM_INT(_3187)){
                    _3188 = (_3186 < _3187) ? -1 : (_3186 > _3187);
                }
                else{
                    _3188 = compare(_3186, _3187);
                }
                _3186 = NOVALUE;
                _3187 = NOVALUE;
                if (_3188 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3191 = (int)*(((s1_ptr)_2)->base + _a_6068);
                Ref(_3191);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3191;
                if( _1 != _3191 ){
                    DeRef(_1);
                }
                _3191 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_6068 = _a_6068 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3192 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3192 = 1;
            }
            {
                int _a_6086;
                _a_6086 = 1;
L35: 
                if (_a_6086 > _3192){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3193 = (int)*(((s1_ptr)_2)->base + _a_6086);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3194 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3193) && IS_ATOM_INT(_3194)){
                    _3195 = (_3193 < _3194) ? -1 : (_3193 > _3194);
                }
                else{
                    _3195 = compare(_3193, _3194);
                }
                _3193 = NOVALUE;
                _3194 = NOVALUE;
                if (_3195 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3198 = (int)*(((s1_ptr)_2)->base + _a_6086);
                Ref(_3198);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3198;
                if( _1 != _3198 ){
                    DeRef(_1);
                }
                _3198 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3199 = (int)*(((s1_ptr)_2)->base + _a_6086);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3200 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3199) && IS_ATOM_INT(_3200)){
                    _3201 = (_3199 < _3200) ? -1 : (_3199 > _3200);
                }
                else{
                    _3201 = compare(_3199, _3200);
                }
                _3199 = NOVALUE;
                _3200 = NOVALUE;
                if (_3201 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3204 = (int)*(((s1_ptr)_2)->base + _a_6086);
                Ref(_3204);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3204;
                if( _1 != _3204 ){
                    DeRef(_1);
                }
                _3204 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_6086 = _a_6086 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_5870)){
                    _3205 = SEQ_PTR(_source_5870)->length;
            }
            else {
                _3205 = 1;
            }
            {
                int _a_6104;
                _a_6104 = 1;
L3A: 
                if (_a_6104 > _3205){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3206 = (int)*(((s1_ptr)_2)->base + _a_6104);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3207 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_3206) && IS_ATOM_INT(_3207)){
                    _3208 = (_3206 < _3207) ? -1 : (_3206 > _3207);
                }
                else{
                    _3208 = compare(_3206, _3207);
                }
                _3206 = NOVALUE;
                _3207 = NOVALUE;
                if (_3208 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3211 = (int)*(((s1_ptr)_2)->base + _a_6104);
                Ref(_3211);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3211;
                if( _1 != _3211 ){
                    DeRef(_1);
                }
                _3211 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3212 = (int)*(((s1_ptr)_2)->base + _a_6104);
                _2 = (int)SEQ_PTR(_userdata_5872);
                _3213 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_3212) && IS_ATOM_INT(_3213)){
                    _3214 = (_3212 < _3213) ? -1 : (_3212 > _3213);
                }
                else{
                    _3214 = compare(_3212, _3213);
                }
                _3212 = NOVALUE;
                _3213 = NOVALUE;
                if (_3214 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_5875 = _idx_5875 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_5870);
                _3217 = (int)*(((s1_ptr)_2)->base + _a_6104);
                Ref(_3217);
                _2 = (int)SEQ_PTR(_dest_5874);
                _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
                _1 = *(int *)_2;
                *(int *)_2 = _3217;
                if( _1 != _3217 ){
                    DeRef(_1);
                }
                _3217 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_6104 = _a_6104 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_5870)){
                _3218 = SEQ_PTR(_source_5870)->length;
        }
        else {
            _3218 = 1;
        }
        {
            int _a_6123;
            _a_6123 = 1;
L3F: 
            if (_a_6123 > _3218){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3219 = (int)*(((s1_ptr)_2)->base + _a_6123);
            Ref(_userdata_5872);
            Ref(_3219);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _3219;
            ((int *)_2)[2] = _userdata_5872;
            _3220 = MAKE_SEQ(_1);
            _3219 = NOVALUE;
            _1 = (int)SEQ_PTR(_3220);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_5871].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            DeRef(_3221);
            _3221 = _1;
            DeRefDS(_3220);
            _3220 = NOVALUE;
            if (_3221 == 0) {
                DeRef(_3221);
                _3221 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_3221) && DBL_PTR(_3221)->dbl == 0.0){
                    DeRef(_3221);
                    _3221 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_3221);
                _3221 = NOVALUE;
            }
            DeRef(_3221);
            _3221 = NOVALUE;

            /** 					idx += 1*/
            _idx_5875 = _idx_5875 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_5870);
            _3223 = (int)*(((s1_ptr)_2)->base + _a_6123);
            Ref(_3223);
            _2 = (int)SEQ_PTR(_dest_5874);
            _2 = (int)(((s1_ptr)_2)->base + _idx_5875);
            _1 = *(int *)_2;
            *(int *)_2 = _3223;
            if( _1 != _3223 ){
                DeRef(_1);
            }
            _3223 = NOVALUE;
L41: 

            /** 			end for*/
            _a_6123 = _a_6123 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_3224;
    RHS_Slice(_dest_5874, 1, _idx_5875);
    DeRefDS(_source_5870);
    DeRef(_rid_5871);
    DeRef(_userdata_5872);
    DeRef(_rangetype_5873);
    DeRefDS(_dest_5874);
    return _3224;
    ;
}
int filter() __attribute__ ((alias ("_23filter")));


int _23filter_alpha(int _elem_6135, int _ud_6136)
{
    int _3225 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_6135);
    _3225 = _7t_alpha(_elem_6135);
    DeRef(_elem_6135);
    return _3225;
    ;
}


int _23extract(int _source_6144, int _indexes_6145)
{
    int _p_6146 = NOVALUE;
    int _msg_inlined_crash_at_34_6156 = NOVALUE;
    int _3233 = NOVALUE;
    int _3230 = NOVALUE;
    int _3228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(indexes) do*/
    if (IS_SEQUENCE(_indexes_6145)){
            _3228 = SEQ_PTR(_indexes_6145)->length;
    }
    else {
        _3228 = 1;
    }
    {
        int _i_6148;
        _i_6148 = 1;
L1: 
        if (_i_6148 > _3228){
            goto L2; // [10] 71
        }

        /** 		p = indexes[i]*/
        DeRef(_p_6146);
        _2 = (int)SEQ_PTR(_indexes_6145);
        _p_6146 = (int)*(((s1_ptr)_2)->base + _i_6148);
        Ref(_p_6146);

        /** 		if not valid_index(source,p) then*/
        RefDS(_source_6144);
        Ref(_p_6146);
        _3230 = _23valid_index(_source_6144, _p_6146);
        if (IS_ATOM_INT(_3230)) {
            if (_3230 != 0){
                DeRef(_3230);
                _3230 = NOVALUE;
                goto L3; // [30] 54
            }
        }
        else {
            if (DBL_PTR(_3230)->dbl != 0.0){
                DeRef(_3230);
                _3230 = NOVALUE;
                goto L3; // [30] 54
            }
        }
        DeRef(_3230);
        _3230 = NOVALUE;

        /** 			error:crash("%d is not a valid index for the input sequence",p)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_34_6156);
        _msg_inlined_crash_at_34_6156 = EPrintf(-9999999, _3232, _p_6146);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_34_6156);

        /** end procedure*/
        goto L4; // [48] 51
L4: 
        DeRefi(_msg_inlined_crash_at_34_6156);
        _msg_inlined_crash_at_34_6156 = NOVALUE;
L3: 

        /** 		indexes[i] = source[p]*/
        _2 = (int)SEQ_PTR(_source_6144);
        if (!IS_ATOM_INT(_p_6146)){
            _3233 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_6146)->dbl));
        }
        else{
            _3233 = (int)*(((s1_ptr)_2)->base + _p_6146);
        }
        Ref(_3233);
        _2 = (int)SEQ_PTR(_indexes_6145);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _indexes_6145 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6148);
        _1 = *(int *)_2;
        *(int *)_2 = _3233;
        if( _1 != _3233 ){
            DeRef(_1);
        }
        _3233 = NOVALUE;

        /** 	end for*/
        _i_6148 = _i_6148 + 1;
        goto L1; // [66] 17
L2: 
        ;
    }

    /** 	return indexes*/
    DeRefDS(_source_6144);
    DeRef(_p_6146);
    return _indexes_6145;
    ;
}
int extract() __attribute__ ((alias ("_23extract")));


int _23project(int _source_6160, int _coords_6161)
{
    int _result_6162 = NOVALUE;
    int _3244 = NOVALUE;
    int _3243 = NOVALUE;
    int _3242 = NOVALUE;
    int _3240 = NOVALUE;
    int _3239 = NOVALUE;
    int _3238 = NOVALUE;
    int _3236 = NOVALUE;
    int _3235 = NOVALUE;
    int _3234 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	result = repeat( repeat(0, length(coords)), length(source) )*/
    if (IS_SEQUENCE(_coords_6161)){
            _3234 = SEQ_PTR(_coords_6161)->length;
    }
    else {
        _3234 = 1;
    }
    _3235 = Repeat(0, _3234);
    _3234 = NOVALUE;
    if (IS_SEQUENCE(_source_6160)){
            _3236 = SEQ_PTR(_source_6160)->length;
    }
    else {
        _3236 = 1;
    }
    DeRef(_result_6162);
    _result_6162 = Repeat(_3235, _3236);
    DeRefDS(_3235);
    _3235 = NOVALUE;
    _3236 = NOVALUE;

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_6160)){
            _3238 = SEQ_PTR(_source_6160)->length;
    }
    else {
        _3238 = 1;
    }
    {
        int _i_6168;
        _i_6168 = 1;
L1: 
        if (_i_6168 > _3238){
            goto L2; // [26] 83
        }

        /** 		for j = 1 to length(coords) do*/
        if (IS_SEQUENCE(_coords_6161)){
                _3239 = SEQ_PTR(_coords_6161)->length;
        }
        else {
            _3239 = 1;
        }
        {
            int _j_6171;
            _j_6171 = 1;
L3: 
            if (_j_6171 > _3239){
                goto L4; // [38] 76
            }

            /** 			result[i][j] = extract(source[i], coords[j])*/
            _2 = (int)SEQ_PTR(_result_6162);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _result_6162 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_6168 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_source_6160);
            _3242 = (int)*(((s1_ptr)_2)->base + _i_6168);
            _2 = (int)SEQ_PTR(_coords_6161);
            _3243 = (int)*(((s1_ptr)_2)->base + _j_6171);
            Ref(_3242);
            Ref(_3243);
            _3244 = _23extract(_3242, _3243);
            _3242 = NOVALUE;
            _3243 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_6171);
            _1 = *(int *)_2;
            *(int *)_2 = _3244;
            if( _1 != _3244 ){
                DeRef(_1);
            }
            _3244 = NOVALUE;
            _3240 = NOVALUE;

            /** 		end for*/
            _j_6171 = _j_6171 + 1;
            goto L3; // [71] 45
L4: 
            ;
        }

        /** 	end for*/
        _i_6168 = _i_6168 + 1;
        goto L1; // [78] 33
L2: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_6160);
    DeRefDS(_coords_6161);
    return _result_6162;
    ;
}
int project() __attribute__ ((alias ("_23project")));


int _23split(int _st_6180, int _delim_6181, int _no_empty_6182, int _limit_6183)
{
    int _ret_6184 = NOVALUE;
    int _start_6185 = NOVALUE;
    int _pos_6186 = NOVALUE;
    int _k_6238 = NOVALUE;
    int _3293 = NOVALUE;
    int _3291 = NOVALUE;
    int _3290 = NOVALUE;
    int _3286 = NOVALUE;
    int _3285 = NOVALUE;
    int _3284 = NOVALUE;
    int _3281 = NOVALUE;
    int _3280 = NOVALUE;
    int _3275 = NOVALUE;
    int _3274 = NOVALUE;
    int _3270 = NOVALUE;
    int _3266 = NOVALUE;
    int _3264 = NOVALUE;
    int _3263 = NOVALUE;
    int _3259 = NOVALUE;
    int _3257 = NOVALUE;
    int _3256 = NOVALUE;
    int _3255 = NOVALUE;
    int _3254 = NOVALUE;
    int _3251 = NOVALUE;
    int _3250 = NOVALUE;
    int _3249 = NOVALUE;
    int _3248 = NOVALUE;
    int _3247 = NOVALUE;
    int _3245 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_no_empty_6182)) {
        _1 = (long)(DBL_PTR(_no_empty_6182)->dbl);
        DeRefDS(_no_empty_6182);
        _no_empty_6182 = _1;
    }
    if (!IS_ATOM_INT(_limit_6183)) {
        _1 = (long)(DBL_PTR(_limit_6183)->dbl);
        DeRefDS(_limit_6183);
        _limit_6183 = _1;
    }

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_6184);
    _ret_6184 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_6180)){
            _3245 = SEQ_PTR(_st_6180)->length;
    }
    else {
        _3245 = 1;
    }
    if (_3245 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_6180);
    DeRef(_delim_6181);
    return _ret_6184;
L1: 

    /** 	if sequence(delim) then*/
    _3247 = IS_SEQUENCE(_delim_6181);
    if (_3247 == 0)
    {
        _3247 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _3247 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_6181 == _5)
    _3248 = 1;
    else if (IS_ATOM_INT(_delim_6181) && IS_ATOM_INT(_5))
    _3248 = 0;
    else
    _3248 = (compare(_delim_6181, _5) == 0);
    if (_3248 == 0)
    {
        _3248 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _3248 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_6180)){
            _3249 = SEQ_PTR(_st_6180)->length;
    }
    else {
        _3249 = 1;
    }
    {
        int _i_6195;
        _i_6195 = 1;
L4: 
        if (_i_6195 > _3249){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_6180);
        _3250 = (int)*(((s1_ptr)_2)->base + _i_6195);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_3250);
        *((int *)(_2+4)) = _3250;
        _3251 = MAKE_SEQ(_1);
        _3250 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_6180);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_6180 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6195);
        _1 = *(int *)_2;
        *(int *)_2 = _3251;
        if( _1 != _3251 ){
            DeRef(_1);
        }
        _3251 = NOVALUE;

        /** 				limit -= 1*/
        _limit_6183 = _limit_6183 - 1;

        /** 				if limit = 0 then*/
        if (_limit_6183 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_3254;
        RHS_Slice(_st_6180, 1, _i_6195);
        _3255 = _i_6195 + 1;
        if (IS_SEQUENCE(_st_6180)){
                _3256 = SEQ_PTR(_st_6180)->length;
        }
        else {
            _3256 = 1;
        }
        rhs_slice_target = (object_ptr)&_3257;
        RHS_Slice(_st_6180, _3255, _3256);
        RefDS(_3257);
        Append(&_st_6180, _3254, _3257);
        DeRefDS(_3254);
        _3254 = NOVALUE;
        DeRefDS(_3257);
        _3257 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_6195 = _i_6195 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRef(_delim_6181);
    DeRef(_ret_6184);
    DeRef(_3255);
    _3255 = NOVALUE;
    return _st_6180;
L3: 

    /** 		start = 1*/
    _start_6185 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_6180)){
            _3259 = SEQ_PTR(_st_6180)->length;
    }
    else {
        _3259 = 1;
    }
    if (_start_6185 > _3259)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_6186 = e_match_from(_delim_6181, _st_6180, _start_6185);

    /** 			if pos = 0 then*/
    if (_pos_6186 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3263 = _pos_6186 - 1;
    rhs_slice_target = (object_ptr)&_3264;
    RHS_Slice(_st_6180, _start_6185, _3263);
    RefDS(_3264);
    Append(&_ret_6184, _ret_6184, _3264);
    DeRefDS(_3264);
    _3264 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_6181)){
            _3266 = SEQ_PTR(_delim_6181)->length;
    }
    else {
        _3266 = 1;
    }
    _start_6185 = _pos_6186 + _3266;
    _3266 = NOVALUE;

    /** 			limit -= 1*/
    _limit_6183 = _limit_6183 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6183 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_6185 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_6180)){
            _3270 = SEQ_PTR(_st_6180)->length;
    }
    else {
        _3270 = 1;
    }
    if (_start_6185 > _3270)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_6186 = find_from(_delim_6181, _st_6180, _start_6185);

    /** 			if pos = 0 then*/
    if (_pos_6186 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _3274 = _pos_6186 - 1;
    rhs_slice_target = (object_ptr)&_3275;
    RHS_Slice(_st_6180, _start_6185, _3274);
    RefDS(_3275);
    Append(&_ret_6184, _ret_6184, _3275);
    DeRefDS(_3275);
    _3275 = NOVALUE;

    /** 			start = pos + 1*/
    _start_6185 = _pos_6186 + 1;

    /** 			limit -= 1*/
    _limit_6183 = _limit_6183 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6183 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_6180)){
            _3280 = SEQ_PTR(_st_6180)->length;
    }
    else {
        _3280 = 1;
    }
    rhs_slice_target = (object_ptr)&_3281;
    RHS_Slice(_st_6180, _start_6185, _3280);
    RefDS(_3281);
    Append(&_ret_6184, _ret_6184, _3281);
    DeRefDS(_3281);
    _3281 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_6184)){
            _k_6238 = SEQ_PTR(_ret_6184)->length;
    }
    else {
        _k_6238 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_6182 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_6238 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_6184)){
            _3284 = SEQ_PTR(_ret_6184)->length;
    }
    else {
        _3284 = 1;
    }
    {
        int _i_6242;
        _i_6242 = 1;
LE: 
        if (_i_6242 > _3284){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_6184);
        _3285 = (int)*(((s1_ptr)_2)->base + _i_6242);
        if (IS_SEQUENCE(_3285)){
                _3286 = SEQ_PTR(_3285)->length;
        }
        else {
            _3286 = 1;
        }
        _3285 = NOVALUE;
        if (_3286 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_6238 = _k_6238 + 1;

        /** 				if k != i then*/
        if (_k_6238 == _i_6242)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_6184);
        _3290 = (int)*(((s1_ptr)_2)->base + _i_6242);
        Ref(_3290);
        _2 = (int)SEQ_PTR(_ret_6184);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_6184 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_6238);
        _1 = *(int *)_2;
        *(int *)_2 = _3290;
        if( _1 != _3290 ){
            DeRef(_1);
        }
        _3290 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_6242 = _i_6242 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_6184)){
            _3291 = SEQ_PTR(_ret_6184)->length;
    }
    else {
        _3291 = 1;
    }
    if (_k_6238 >= _3291)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3293;
    RHS_Slice(_ret_6184, 1, _k_6238);
    DeRefDS(_st_6180);
    DeRef(_delim_6181);
    DeRefDS(_ret_6184);
    DeRef(_3263);
    _3263 = NOVALUE;
    DeRef(_3255);
    _3255 = NOVALUE;
    DeRef(_3274);
    _3274 = NOVALUE;
    _3285 = NOVALUE;
    return _3293;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_6180);
    DeRef(_delim_6181);
    DeRef(_3263);
    _3263 = NOVALUE;
    DeRef(_3255);
    _3255 = NOVALUE;
    DeRef(_3274);
    _3274 = NOVALUE;
    _3285 = NOVALUE;
    DeRef(_3293);
    _3293 = NOVALUE;
    return _ret_6184;
L13: 
    ;
}


int _23split_any(int _source_6259, int _delim_6260, int _limit_6262, int _no_empty_6263)
{
    int _ret_6264 = NOVALUE;
    int _start_6265 = NOVALUE;
    int _pos_6266 = NOVALUE;
    int _next_pos_6267 = NOVALUE;
    int _k_6286 = NOVALUE;
    int _3318 = NOVALUE;
    int _3316 = NOVALUE;
    int _3315 = NOVALUE;
    int _3311 = NOVALUE;
    int _3310 = NOVALUE;
    int _3309 = NOVALUE;
    int _3306 = NOVALUE;
    int _3305 = NOVALUE;
    int _3301 = NOVALUE;
    int _3300 = NOVALUE;
    int _3297 = NOVALUE;
    int _3295 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_limit_6262)) {
        _1 = (long)(DBL_PTR(_limit_6262)->dbl);
        DeRefDS(_limit_6262);
        _limit_6262 = _1;
    }
    if (!IS_ATOM_INT(_no_empty_6263)) {
        _1 = (long)(DBL_PTR(_no_empty_6263)->dbl);
        DeRefDS(_no_empty_6263);
        _no_empty_6263 = _1;
    }

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_6264);
    _ret_6264 = _5;

    /** 	integer start = 1, pos, next_pos*/
    _start_6265 = 1;

    /** 	if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_6260)){
            _3295 = SEQ_PTR(_delim_6260)->length;
    }
    else {
        _3295 = 1;
    }
    if (_3295 != 0)
    goto L1; // [24] 39

    /** 		return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6259);
    *((int *)(_2+4)) = _source_6259;
    _3297 = MAKE_SEQ(_1);
    DeRefDS(_source_6259);
    DeRef(_delim_6260);
    DeRefDS(_ret_6264);
    return _3297;
L1: 

    /** 	while 1 do*/
L2: 

    /** 		pos = search:find_any(delim, source, start)*/
    Ref(_delim_6260);
    RefDS(_source_6259);
    _pos_6266 = _9find_any(_delim_6260, _source_6259, _start_6265);
    if (!IS_ATOM_INT(_pos_6266)) {
        _1 = (long)(DBL_PTR(_pos_6266)->dbl);
        DeRefDS(_pos_6266);
        _pos_6266 = _1;
    }

    /** 		next_pos = pos + 1*/
    _next_pos_6267 = _pos_6266 + 1;

    /** 		if pos then*/
    if (_pos_6266 == 0)
    {
        goto L3; // [62] 115
    }
    else{
    }

    /** 			ret = append(ret, source[start..pos-1])*/
    _3300 = _pos_6266 - 1;
    rhs_slice_target = (object_ptr)&_3301;
    RHS_Slice(_source_6259, _start_6265, _3300);
    RefDS(_3301);
    Append(&_ret_6264, _ret_6264, _3301);
    DeRefDS(_3301);
    _3301 = NOVALUE;

    /** 			start = next_pos*/
    _start_6265 = _next_pos_6267;

    /** 			limit -= 1*/
    _limit_6262 = _limit_6262 - 1;

    /** 			if limit = 0 then*/
    if (_limit_6262 != 0)
    goto L2; // [93] 44

    /** 				exit*/
    goto L3; // [99] 115
    goto L2; // [102] 44

    /** 			exit*/
    goto L3; // [107] 115

    /** 	end while*/
    goto L2; // [112] 44
L3: 

    /** 	ret = append(ret, source[start..$])*/
    if (IS_SEQUENCE(_source_6259)){
            _3305 = SEQ_PTR(_source_6259)->length;
    }
    else {
        _3305 = 1;
    }
    rhs_slice_target = (object_ptr)&_3306;
    RHS_Slice(_source_6259, _start_6265, _3305);
    RefDS(_3306);
    Append(&_ret_6264, _ret_6264, _3306);
    DeRefDS(_3306);
    _3306 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_6264)){
            _k_6286 = SEQ_PTR(_ret_6264)->length;
    }
    else {
        _k_6286 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_6263 == 0)
    {
        goto L4; // [136] 201
    }
    else{
    }

    /** 		k = 0*/
    _k_6286 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_6264)){
            _3309 = SEQ_PTR(_ret_6264)->length;
    }
    else {
        _3309 = 1;
    }
    {
        int _i_6290;
        _i_6290 = 1;
L5: 
        if (_i_6290 > _3309){
            goto L6; // [149] 200
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_6264);
        _3310 = (int)*(((s1_ptr)_2)->base + _i_6290);
        if (IS_SEQUENCE(_3310)){
                _3311 = SEQ_PTR(_3310)->length;
        }
        else {
            _3311 = 1;
        }
        _3310 = NOVALUE;
        if (_3311 == 0)
        goto L7; // [165] 193

        /** 				k += 1*/
        _k_6286 = _k_6286 + 1;

        /** 				if k != i then*/
        if (_k_6286 == _i_6290)
        goto L8; // [177] 192

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_6264);
        _3315 = (int)*(((s1_ptr)_2)->base + _i_6290);
        Ref(_3315);
        _2 = (int)SEQ_PTR(_ret_6264);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_6264 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_6286);
        _1 = *(int *)_2;
        *(int *)_2 = _3315;
        if( _1 != _3315 ){
            DeRef(_1);
        }
        _3315 = NOVALUE;
L8: 
L7: 

        /** 		end for*/
        _i_6290 = _i_6290 + 1;
        goto L5; // [195] 156
L6: 
        ;
    }
L4: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_6264)){
            _3316 = SEQ_PTR(_ret_6264)->length;
    }
    else {
        _3316 = 1;
    }
    if (_k_6286 >= _3316)
    goto L9; // [206] 224

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_3318;
    RHS_Slice(_ret_6264, 1, _k_6286);
    DeRefDS(_source_6259);
    DeRef(_delim_6260);
    DeRefDS(_ret_6264);
    DeRef(_3297);
    _3297 = NOVALUE;
    DeRef(_3300);
    _3300 = NOVALUE;
    _3310 = NOVALUE;
    return _3318;
    goto LA; // [221] 231
L9: 

    /** 		return ret*/
    DeRefDS(_source_6259);
    DeRef(_delim_6260);
    DeRef(_3297);
    _3297 = NOVALUE;
    DeRef(_3300);
    _3300 = NOVALUE;
    _3310 = NOVALUE;
    DeRef(_3318);
    _3318 = NOVALUE;
    return _ret_6264;
LA: 
    ;
}
int split_any() __attribute__ ((alias ("_23split_any")));


int _23join(int _items_6307, int _delim_6308)
{
    int _ret_6310 = NOVALUE;
    int _3328 = NOVALUE;
    int _3327 = NOVALUE;
    int _3325 = NOVALUE;
    int _3324 = NOVALUE;
    int _3323 = NOVALUE;
    int _3322 = NOVALUE;
    int _3320 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_6307)){
            _3320 = SEQ_PTR(_items_6307)->length;
    }
    else {
        _3320 = 1;
    }
    if (_3320 != 0)
    goto L1; // [8] 16
    _3320 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_6307);
    DeRef(_delim_6308);
    DeRef(_ret_6310);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_6310);
    _ret_6310 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_6307)){
            _3322 = SEQ_PTR(_items_6307)->length;
    }
    else {
        _3322 = 1;
    }
    _3323 = _3322 - 1;
    _3322 = NOVALUE;
    {
        int _i_6315;
        _i_6315 = 1;
L2: 
        if (_i_6315 > _3323){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_6307);
        _3324 = (int)*(((s1_ptr)_2)->base + _i_6315);
        if (IS_SEQUENCE(_3324) && IS_ATOM(_delim_6308)) {
            Ref(_delim_6308);
            Append(&_3325, _3324, _delim_6308);
        }
        else if (IS_ATOM(_3324) && IS_SEQUENCE(_delim_6308)) {
            Ref(_3324);
            Prepend(&_3325, _delim_6308, _3324);
        }
        else {
            Concat((object_ptr)&_3325, _3324, _delim_6308);
            _3324 = NOVALUE;
        }
        _3324 = NOVALUE;
        if (IS_SEQUENCE(_ret_6310) && IS_ATOM(_3325)) {
        }
        else if (IS_ATOM(_ret_6310) && IS_SEQUENCE(_3325)) {
            Ref(_ret_6310);
            Prepend(&_ret_6310, _3325, _ret_6310);
        }
        else {
            Concat((object_ptr)&_ret_6310, _ret_6310, _3325);
        }
        DeRefDS(_3325);
        _3325 = NOVALUE;

        /** 	end for*/
        _i_6315 = _i_6315 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_6307)){
            _3327 = SEQ_PTR(_items_6307)->length;
    }
    else {
        _3327 = 1;
    }
    _2 = (int)SEQ_PTR(_items_6307);
    _3328 = (int)*(((s1_ptr)_2)->base + _3327);
    if (IS_SEQUENCE(_ret_6310) && IS_ATOM(_3328)) {
        Ref(_3328);
        Append(&_ret_6310, _ret_6310, _3328);
    }
    else if (IS_ATOM(_ret_6310) && IS_SEQUENCE(_3328)) {
        Ref(_ret_6310);
        Prepend(&_ret_6310, _3328, _ret_6310);
    }
    else {
        Concat((object_ptr)&_ret_6310, _ret_6310, _3328);
    }
    _3328 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_6307);
    DeRef(_delim_6308);
    DeRef(_3323);
    _3323 = NOVALUE;
    return _ret_6310;
    ;
}
int join() __attribute__ ((alias ("_23join")));


int _23breakup(int _source_6328, int _size_6329, int _style_6330)
{
    int _len_6339 = NOVALUE;
    int _rem_6340 = NOVALUE;
    int _ns_6381 = NOVALUE;
    int _source_idx_6384 = NOVALUE;
    int _k_6391 = NOVALUE;
    int _3387 = NOVALUE;
    int _3386 = NOVALUE;
    int _3384 = NOVALUE;
    int _3381 = NOVALUE;
    int _3379 = NOVALUE;
    int _3378 = NOVALUE;
    int _3377 = NOVALUE;
    int _3376 = NOVALUE;
    int _3374 = NOVALUE;
    int _3373 = NOVALUE;
    int _3372 = NOVALUE;
    int _3371 = NOVALUE;
    int _3369 = NOVALUE;
    int _3368 = NOVALUE;
    int _3366 = NOVALUE;
    int _3364 = NOVALUE;
    int _3363 = NOVALUE;
    int _3361 = NOVALUE;
    int _3358 = NOVALUE;
    int _3357 = NOVALUE;
    int _3354 = NOVALUE;
    int _3353 = NOVALUE;
    int _3349 = NOVALUE;
    int _3344 = NOVALUE;
    int _3342 = NOVALUE;
    int _3341 = NOVALUE;
    int _3340 = NOVALUE;
    int _3339 = NOVALUE;
    int _3337 = NOVALUE;
    int _3335 = NOVALUE;
    int _3333 = NOVALUE;
    int _3332 = NOVALUE;
    int _3331 = NOVALUE;
    int _3330 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_style_6330)) {
        _1 = (long)(DBL_PTR(_style_6330)->dbl);
        DeRefDS(_style_6330);
        _style_6330 = _1;
    }

    /** 	if atom(size) and not integer(size) then*/
    _3330 = IS_ATOM(_size_6329);
    if (_3330 == 0) {
        goto L1; // [10] 30
    }
    if (IS_ATOM_INT(_size_6329))
    _3332 = 1;
    else if (IS_ATOM_DBL(_size_6329))
    _3332 = IS_ATOM_INT(DoubleToInt(_size_6329));
    else
    _3332 = 0;
    _3333 = (_3332 == 0);
    _3332 = NOVALUE;
    if (_3333 == 0)
    {
        DeRef(_3333);
        _3333 = NOVALUE;
        goto L1; // [21] 30
    }
    else{
        DeRef(_3333);
        _3333 = NOVALUE;
    }

    /** 		size = floor(size)*/
    _0 = _size_6329;
    if (IS_ATOM_INT(_size_6329))
    _size_6329 = e_floor(_size_6329);
    else
    _size_6329 = unary_op(FLOOR, _size_6329);
    DeRef(_0);
L1: 

    /** 	if integer(size) then*/
    if (IS_ATOM_INT(_size_6329))
    _3335 = 1;
    else if (IS_ATOM_DBL(_size_6329))
    _3335 = IS_ATOM_INT(DoubleToInt(_size_6329));
    else
    _3335 = 0;
    if (_3335 == 0)
    {
        _3335 = NOVALUE;
        goto L2; // [35] 253
    }
    else{
        _3335 = NOVALUE;
    }

    /** 		integer len*/

    /** 		integer rem*/

    /** 		if style = BK_LEN then*/
    if (_style_6330 != 1)
    goto L3; // [44] 125

    /** 			if size < 1 or size >= length(source) then*/
    if (IS_ATOM_INT(_size_6329)) {
        _3337 = (_size_6329 < 1);
    }
    else {
        _3337 = binary_op(LESS, _size_6329, 1);
    }
    if (IS_ATOM_INT(_3337)) {
        if (_3337 != 0) {
            goto L4; // [54] 70
        }
    }
    else {
        if (DBL_PTR(_3337)->dbl != 0.0) {
            goto L4; // [54] 70
        }
    }
    if (IS_SEQUENCE(_source_6328)){
            _3339 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3339 = 1;
    }
    if (IS_ATOM_INT(_size_6329)) {
        _3340 = (_size_6329 >= _3339);
    }
    else {
        _3340 = binary_op(GREATEREQ, _size_6329, _3339);
    }
    _3339 = NOVALUE;
    if (_3340 == 0) {
        DeRef(_3340);
        _3340 = NOVALUE;
        goto L5; // [66] 81
    }
    else {
        if (!IS_ATOM_INT(_3340) && DBL_PTR(_3340)->dbl == 0.0){
            DeRef(_3340);
            _3340 = NOVALUE;
            goto L5; // [66] 81
        }
        DeRef(_3340);
        _3340 = NOVALUE;
    }
    DeRef(_3340);
    _3340 = NOVALUE;
L4: 

    /** 				return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6328);
    *((int *)(_2+4)) = _source_6328;
    _3341 = MAKE_SEQ(_1);
    DeRefDS(_source_6328);
    DeRef(_size_6329);
    DeRef(_ns_6381);
    DeRef(_3337);
    _3337 = NOVALUE;
    return _3341;
L5: 

    /** 			len = floor(length(source) / size)*/
    if (IS_SEQUENCE(_source_6328)){
            _3342 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3342 = 1;
    }
    if (IS_ATOM_INT(_size_6329)) {
        if (_size_6329 > 0 && _3342 >= 0) {
            _len_6339 = _3342 / _size_6329;
        }
        else {
            temp_dbl = floor((double)_3342 / (double)_size_6329);
            _len_6339 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _3342, _size_6329);
        _len_6339 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _3342 = NOVALUE;
    if (!IS_ATOM_INT(_len_6339)) {
        _1 = (long)(DBL_PTR(_len_6339)->dbl);
        DeRefDS(_len_6339);
        _len_6339 = _1;
    }

    /** 			rem = remainder(length(source), size)*/
    if (IS_SEQUENCE(_source_6328)){
            _3344 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3344 = 1;
    }
    if (IS_ATOM_INT(_size_6329)) {
        _rem_6340 = (_3344 % _size_6329);
    }
    else {
        _rem_6340 = binary_op(REMAINDER, _3344, _size_6329);
    }
    _3344 = NOVALUE;
    if (!IS_ATOM_INT(_rem_6340)) {
        _1 = (long)(DBL_PTR(_rem_6340)->dbl);
        DeRefDS(_rem_6340);
        _rem_6340 = _1;
    }

    /** 			size = repeat(size, len)*/
    _0 = _size_6329;
    _size_6329 = Repeat(_size_6329, _len_6339);
    DeRef(_0);

    /** 			if rem > 0 then*/
    if (_rem_6340 <= 0)
    goto L6; // [111] 252

    /** 				size &= rem*/
    Append(&_size_6329, _size_6329, _rem_6340);
    goto L6; // [122] 252
L3: 

    /** 			if size > length(source) then*/
    if (IS_SEQUENCE(_source_6328)){
            _3349 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3349 = 1;
    }
    if (binary_op_a(LESSEQ, _size_6329, _3349)){
        _3349 = NOVALUE;
        goto L7; // [130] 140
    }
    _3349 = NOVALUE;

    /** 				size = length(source)*/
    DeRef(_size_6329);
    if (IS_SEQUENCE(_source_6328)){
            _size_6329 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _size_6329 = 1;
    }
L7: 

    /** 			if size < 1 then*/
    if (binary_op_a(GREATEREQ, _size_6329, 1)){
        goto L8; // [142] 157
    }

    /** 				return {source}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_source_6328);
    *((int *)(_2+4)) = _source_6328;
    _3353 = MAKE_SEQ(_1);
    DeRefDS(_source_6328);
    DeRef(_size_6329);
    DeRef(_ns_6381);
    DeRef(_3337);
    _3337 = NOVALUE;
    DeRef(_3341);
    _3341 = NOVALUE;
    return _3353;
L8: 

    /** 			len = floor(length(source) / size)*/
    if (IS_SEQUENCE(_source_6328)){
            _3354 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3354 = 1;
    }
    if (IS_ATOM_INT(_size_6329)) {
        if (_size_6329 > 0 && _3354 >= 0) {
            _len_6339 = _3354 / _size_6329;
        }
        else {
            temp_dbl = floor((double)_3354 / (double)_size_6329);
            _len_6339 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _3354, _size_6329);
        _len_6339 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _3354 = NOVALUE;
    if (!IS_ATOM_INT(_len_6339)) {
        _1 = (long)(DBL_PTR(_len_6339)->dbl);
        DeRefDS(_len_6339);
        _len_6339 = _1;
    }

    /** 			if len < 1 then*/
    if (_len_6339 >= 1)
    goto L9; // [170] 180

    /** 				len = 1*/
    _len_6339 = 1;
L9: 

    /** 			rem = length(source) - (size * len)*/
    if (IS_SEQUENCE(_source_6328)){
            _3357 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3357 = 1;
    }
    if (IS_ATOM_INT(_size_6329)) {
        if (_size_6329 == (short)_size_6329 && _len_6339 <= INT15 && _len_6339 >= -INT15)
        _3358 = _size_6329 * _len_6339;
        else
        _3358 = NewDouble(_size_6329 * (double)_len_6339);
    }
    else {
        _3358 = binary_op(MULTIPLY, _size_6329, _len_6339);
    }
    if (IS_ATOM_INT(_3358)) {
        _rem_6340 = _3357 - _3358;
    }
    else {
        _rem_6340 = binary_op(MINUS, _3357, _3358);
    }
    _3357 = NOVALUE;
    DeRef(_3358);
    _3358 = NOVALUE;
    if (!IS_ATOM_INT(_rem_6340)) {
        _1 = (long)(DBL_PTR(_rem_6340)->dbl);
        DeRefDS(_rem_6340);
        _rem_6340 = _1;
    }

    /** 			size = repeat(len, size)*/
    _0 = _size_6329;
    _size_6329 = Repeat(_len_6339, _size_6329);
    DeRef(_0);

    /** 			for i = 1 to length(size) do*/
    if (IS_SEQUENCE(_size_6329)){
            _3361 = SEQ_PTR(_size_6329)->length;
    }
    else {
        _3361 = 1;
    }
    {
        int _i_6374;
        _i_6374 = 1;
LA: 
        if (_i_6374 > _3361){
            goto LB; // [206] 251
        }

        /** 				if rem = 0 then*/
        if (_rem_6340 != 0)
        goto LC; // [215] 224

        /** 					exit*/
        goto LB; // [221] 251
LC: 

        /** 				size[i] += 1*/
        _2 = (int)SEQ_PTR(_size_6329);
        _3363 = (int)*(((s1_ptr)_2)->base + _i_6374);
        if (IS_ATOM_INT(_3363)) {
            _3364 = _3363 + 1;
            if (_3364 > MAXINT){
                _3364 = NewDouble((double)_3364);
            }
        }
        else
        _3364 = binary_op(PLUS, 1, _3363);
        _3363 = NOVALUE;
        _2 = (int)SEQ_PTR(_size_6329);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _size_6329 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6374);
        _1 = *(int *)_2;
        *(int *)_2 = _3364;
        if( _1 != _3364 ){
            DeRef(_1);
        }
        _3364 = NOVALUE;

        /** 				rem -= 1*/
        _rem_6340 = _rem_6340 - 1;

        /** 			end for*/
        _i_6374 = _i_6374 + 1;
        goto LA; // [246] 213
LB: 
        ;
    }
L6: 
L2: 

    /** 	sequence ns = repeat(0, length(size))*/
    if (IS_SEQUENCE(_size_6329)){
            _3366 = SEQ_PTR(_size_6329)->length;
    }
    else {
        _3366 = 1;
    }
    DeRef(_ns_6381);
    _ns_6381 = Repeat(0, _3366);
    _3366 = NOVALUE;

    /** 	integer source_idx = 1*/
    _source_idx_6384 = 1;

    /** 	for i = 1 to length(size) do*/
    if (IS_SEQUENCE(_size_6329)){
            _3368 = SEQ_PTR(_size_6329)->length;
    }
    else {
        _3368 = 1;
    }
    {
        int _i_6386;
        _i_6386 = 1;
LD: 
        if (_i_6386 > _3368){
            goto LE; // [274] 408
        }

        /** 		if source_idx <= length(source) then*/
        if (IS_SEQUENCE(_source_6328)){
                _3369 = SEQ_PTR(_source_6328)->length;
        }
        else {
            _3369 = 1;
        }
        if (_source_idx_6384 > _3369)
        goto LF; // [286] 394

        /** 			integer k = 1*/
        _k_6391 = 1;

        /** 			ns[i] = repeat(0, size[i])*/
        _2 = (int)SEQ_PTR(_size_6329);
        _3371 = (int)*(((s1_ptr)_2)->base + _i_6386);
        _3372 = Repeat(0, _3371);
        _3371 = NOVALUE;
        _2 = (int)SEQ_PTR(_ns_6381);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ns_6381 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6386);
        _1 = *(int *)_2;
        *(int *)_2 = _3372;
        if( _1 != _3372 ){
            DeRef(_1);
        }
        _3372 = NOVALUE;

        /** 			for j = 1 to size[i] do*/
        _2 = (int)SEQ_PTR(_size_6329);
        _3373 = (int)*(((s1_ptr)_2)->base + _i_6386);
        {
            int _j_6395;
            _j_6395 = 1;
L10: 
            if (binary_op_a(GREATER, _j_6395, _3373)){
                goto L11; // [315] 389
            }

            /** 				if source_idx > length(source) then*/
            if (IS_SEQUENCE(_source_6328)){
                    _3374 = SEQ_PTR(_source_6328)->length;
            }
            else {
                _3374 = 1;
            }
            if (_source_idx_6384 <= _3374)
            goto L12; // [327] 355

            /** 					ns[i] = ns[i][1 .. k-1]*/
            _2 = (int)SEQ_PTR(_ns_6381);
            _3376 = (int)*(((s1_ptr)_2)->base + _i_6386);
            _3377 = _k_6391 - 1;
            rhs_slice_target = (object_ptr)&_3378;
            RHS_Slice(_3376, 1, _3377);
            _3376 = NOVALUE;
            _2 = (int)SEQ_PTR(_ns_6381);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _ns_6381 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_6386);
            _1 = *(int *)_2;
            *(int *)_2 = _3378;
            if( _1 != _3378 ){
                DeRef(_1);
            }
            _3378 = NOVALUE;

            /** 					exit*/
            goto L11; // [352] 389
L12: 

            /** 				ns[i][k] = source[source_idx]*/
            _2 = (int)SEQ_PTR(_ns_6381);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _ns_6381 = MAKE_SEQ(_2);
            }
            _3 = (int)(_i_6386 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_source_6328);
            _3381 = (int)*(((s1_ptr)_2)->base + _source_idx_6384);
            Ref(_3381);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_6391);
            _1 = *(int *)_2;
            *(int *)_2 = _3381;
            if( _1 != _3381 ){
                DeRef(_1);
            }
            _3381 = NOVALUE;
            _3379 = NOVALUE;

            /** 				k += 1*/
            _k_6391 = _k_6391 + 1;

            /** 				source_idx += 1*/
            _source_idx_6384 = _source_idx_6384 + 1;

            /** 			end for*/
            _0 = _j_6395;
            if (IS_ATOM_INT(_j_6395)) {
                _j_6395 = _j_6395 + 1;
                if ((long)((unsigned long)_j_6395 +(unsigned long) HIGH_BITS) >= 0){
                    _j_6395 = NewDouble((double)_j_6395);
                }
            }
            else {
                _j_6395 = binary_op_a(PLUS, _j_6395, 1);
            }
            DeRef(_0);
            goto L10; // [384] 322
L11: 
            ;
            DeRef(_j_6395);
        }
        goto L13; // [391] 401
LF: 

        /** 			ns[i] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_ns_6381);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ns_6381 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6386);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
L13: 

        /** 	end for*/
        _i_6386 = _i_6386 + 1;
        goto LD; // [403] 281
LE: 
        ;
    }

    /** 	if source_idx <= length(source) then*/
    if (IS_SEQUENCE(_source_6328)){
            _3384 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3384 = 1;
    }
    if (_source_idx_6384 > _3384)
    goto L14; // [413] 432

    /** 		ns = append(ns, source[source_idx .. $])*/
    if (IS_SEQUENCE(_source_6328)){
            _3386 = SEQ_PTR(_source_6328)->length;
    }
    else {
        _3386 = 1;
    }
    rhs_slice_target = (object_ptr)&_3387;
    RHS_Slice(_source_6328, _source_idx_6384, _3386);
    RefDS(_3387);
    Append(&_ns_6381, _ns_6381, _3387);
    DeRefDS(_3387);
    _3387 = NOVALUE;
L14: 

    /** 	return ns*/
    DeRefDS(_source_6328);
    DeRef(_size_6329);
    DeRef(_3337);
    _3337 = NOVALUE;
    DeRef(_3341);
    _3341 = NOVALUE;
    DeRef(_3353);
    _3353 = NOVALUE;
    _3373 = NOVALUE;
    DeRef(_3377);
    _3377 = NOVALUE;
    return _ns_6381;
    ;
}
int breakup() __attribute__ ((alias ("_23breakup")));


int _23flatten(int _s_6417, int _delim_6418)
{
    int _ret_6419 = NOVALUE;
    int _x_6420 = NOVALUE;
    int _len_6421 = NOVALUE;
    int _pos_6422 = NOVALUE;
    int _temp_6440 = NOVALUE;
    int _3414 = NOVALUE;
    int _3413 = NOVALUE;
    int _3412 = NOVALUE;
    int _3410 = NOVALUE;
    int _3409 = NOVALUE;
    int _3408 = NOVALUE;
    int _3406 = NOVALUE;
    int _3404 = NOVALUE;
    int _3403 = NOVALUE;
    int _3402 = NOVALUE;
    int _3400 = NOVALUE;
    int _3399 = NOVALUE;
    int _3398 = NOVALUE;
    int _3397 = NOVALUE;
    int _3396 = NOVALUE;
    int _3395 = NOVALUE;
    int _3393 = NOVALUE;
    int _3392 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_6417);
    DeRef(_ret_6419);
    _ret_6419 = _s_6417;

    /** 	pos = 1*/
    _pos_6422 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_6419)){
            _len_6421 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _len_6421 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_6422 > _len_6421)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_6420);
    _2 = (int)SEQ_PTR(_ret_6419);
    _x_6420 = (int)*(((s1_ptr)_2)->base + _pos_6422);
    Ref(_x_6420);

    /** 		if sequence(x) then*/
    _3392 = IS_SEQUENCE(_x_6420);
    if (_3392 == 0)
    {
        _3392 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _3392 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_6418)){
            _3393 = SEQ_PTR(_delim_6418)->length;
    }
    else {
        _3393 = 1;
    }
    if (_3393 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _3395 = _pos_6422 - 1;
    rhs_slice_target = (object_ptr)&_3396;
    RHS_Slice(_ret_6419, 1, _3395);
    Ref(_x_6420);
    RefDS(_5);
    _3397 = _23flatten(_x_6420, _5);
    _3398 = _pos_6422 + 1;
    if (_3398 > MAXINT){
        _3398 = NewDouble((double)_3398);
    }
    if (IS_SEQUENCE(_ret_6419)){
            _3399 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _3399 = 1;
    }
    rhs_slice_target = (object_ptr)&_3400;
    RHS_Slice(_ret_6419, _3398, _3399);
    {
        int concat_list[3];

        concat_list[0] = _3400;
        concat_list[1] = _3397;
        concat_list[2] = _3396;
        Concat_N((object_ptr)&_ret_6419, concat_list, 3);
    }
    DeRefDS(_3400);
    _3400 = NOVALUE;
    DeRef(_3397);
    _3397 = NOVALUE;
    DeRefDS(_3396);
    _3396 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _3402 = _pos_6422 - 1;
    rhs_slice_target = (object_ptr)&_3403;
    RHS_Slice(_ret_6419, 1, _3402);
    Ref(_x_6420);
    RefDS(_5);
    _3404 = _23flatten(_x_6420, _5);
    if (IS_SEQUENCE(_3403) && IS_ATOM(_3404)) {
        Ref(_3404);
        Append(&_temp_6440, _3403, _3404);
    }
    else if (IS_ATOM(_3403) && IS_SEQUENCE(_3404)) {
    }
    else {
        Concat((object_ptr)&_temp_6440, _3403, _3404);
        DeRefDS(_3403);
        _3403 = NOVALUE;
    }
    DeRef(_3403);
    _3403 = NOVALUE;
    DeRef(_3404);
    _3404 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_6419)){
            _3406 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _3406 = 1;
    }
    if (_pos_6422 == _3406)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _3408 = _pos_6422 + 1;
    if (_3408 > MAXINT){
        _3408 = NewDouble((double)_3408);
    }
    if (IS_SEQUENCE(_ret_6419)){
            _3409 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _3409 = 1;
    }
    rhs_slice_target = (object_ptr)&_3410;
    RHS_Slice(_ret_6419, _3408, _3409);
    {
        int concat_list[3];

        concat_list[0] = _3410;
        concat_list[1] = _delim_6418;
        concat_list[2] = _temp_6440;
        Concat_N((object_ptr)&_ret_6419, concat_list, 3);
    }
    DeRefDS(_3410);
    _3410 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _3412 = _pos_6422 + 1;
    if (_3412 > MAXINT){
        _3412 = NewDouble((double)_3412);
    }
    if (IS_SEQUENCE(_ret_6419)){
            _3413 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _3413 = 1;
    }
    rhs_slice_target = (object_ptr)&_3414;
    RHS_Slice(_ret_6419, _3412, _3413);
    Concat((object_ptr)&_ret_6419, _temp_6440, _3414);
    DeRefDS(_3414);
    _3414 = NOVALUE;
L7: 
    DeRef(_temp_6440);
    _temp_6440 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_6419)){
            _len_6421 = SEQ_PTR(_ret_6419)->length;
    }
    else {
        _len_6421 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_6422 = _pos_6422 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_6417);
    DeRef(_delim_6418);
    DeRef(_x_6420);
    DeRef(_3395);
    _3395 = NOVALUE;
    DeRef(_3402);
    _3402 = NOVALUE;
    DeRef(_3408);
    _3408 = NOVALUE;
    DeRef(_3398);
    _3398 = NOVALUE;
    DeRef(_3412);
    _3412 = NOVALUE;
    return _ret_6419;
    ;
}
int flatten() __attribute__ ((alias ("_23flatten")));


int _23pivot(int _data_p_6462, int _pivot_p_6463)
{
    int _result__6464 = NOVALUE;
    int _pos__6465 = NOVALUE;
    int _3427 = NOVALUE;
    int _3426 = NOVALUE;
    int _3425 = NOVALUE;
    int _3423 = NOVALUE;
    int _3422 = NOVALUE;
    int _3421 = NOVALUE;
    int _3419 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_ = {{}, {}, {}}*/
    _0 = _result__6464;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_5, 3);
    *((int *)(_2+4)) = _5;
    *((int *)(_2+8)) = _5;
    *((int *)(_2+12)) = _5;
    _result__6464 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if atom(data_p) then*/
    _3419 = IS_ATOM(_data_p_6462);
    if (_3419 == 0)
    {
        _3419 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _3419 = NOVALUE;
    }

    /** 		data_p = {data_p}*/
    _0 = _data_p_6462;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_p_6462);
    *((int *)(_2+4)) = _data_p_6462;
    _data_p_6462 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(data_p) do*/
    if (IS_SEQUENCE(_data_p_6462)){
            _3421 = SEQ_PTR(_data_p_6462)->length;
    }
    else {
        _3421 = 1;
    }
    {
        int _i_6471;
        _i_6471 = 1;
L2: 
        if (_i_6471 > _3421){
            goto L3; // [29] 75
        }

        /** 		pos_ = eu:compare(data_p[i], pivot_p) + 2*/
        _2 = (int)SEQ_PTR(_data_p_6462);
        _3422 = (int)*(((s1_ptr)_2)->base + _i_6471);
        if (IS_ATOM_INT(_3422) && IS_ATOM_INT(_pivot_p_6463)){
            _3423 = (_3422 < _pivot_p_6463) ? -1 : (_3422 > _pivot_p_6463);
        }
        else{
            _3423 = compare(_3422, _pivot_p_6463);
        }
        _3422 = NOVALUE;
        _pos__6465 = _3423 + 2;
        _3423 = NOVALUE;

        /** 		result_[pos_] = append(result_[pos_], data_p[i])*/
        _2 = (int)SEQ_PTR(_result__6464);
        _3425 = (int)*(((s1_ptr)_2)->base + _pos__6465);
        _2 = (int)SEQ_PTR(_data_p_6462);
        _3426 = (int)*(((s1_ptr)_2)->base + _i_6471);
        Ref(_3426);
        Append(&_3427, _3425, _3426);
        _3425 = NOVALUE;
        _3426 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__6464);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__6464 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__6465);
        _1 = *(int *)_2;
        *(int *)_2 = _3427;
        if( _1 != _3427 ){
            DeRefDS(_1);
        }
        _3427 = NOVALUE;

        /** 	end for*/
        _i_6471 = _i_6471 + 1;
        goto L2; // [70] 36
L3: 
        ;
    }

    /** 	return result_*/
    DeRef(_data_p_6462);
    DeRef(_pivot_p_6463);
    return _result__6464;
    ;
}
int pivot() __attribute__ ((alias ("_23pivot")));


int _23build_list(int _source_6481, int _transformer_6482, int _singleton_6483, int _user_data_6484)
{
    int _result_6485 = NOVALUE;
    int _x_6486 = NOVALUE;
    int _new_x_6487 = NOVALUE;
    int _3444 = NOVALUE;
    int _3442 = NOVALUE;
    int _3440 = NOVALUE;
    int _3438 = NOVALUE;
    int _3436 = NOVALUE;
    int _3435 = NOVALUE;
    int _3433 = NOVALUE;
    int _3432 = NOVALUE;
    int _3431 = NOVALUE;
    int _3430 = NOVALUE;
    int _3428 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_singleton_6483)) {
        _1 = (long)(DBL_PTR(_singleton_6483)->dbl);
        DeRefDS(_singleton_6483);
        _singleton_6483 = _1;
    }

    /** 	sequence result = {}*/
    RefDS(_5);
    DeRef(_result_6485);
    _result_6485 = _5;

    /** 	if atom(transformer) then*/
    _3428 = IS_ATOM(_transformer_6482);
    if (_3428 == 0)
    {
        _3428 = NOVALUE;
        goto L1; // [17] 27
    }
    else{
        _3428 = NOVALUE;
    }

    /** 		transformer = {transformer}*/
    _0 = _transformer_6482;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_transformer_6482);
    *((int *)(_2+4)) = _transformer_6482;
    _transformer_6482 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(source) do*/
    if (IS_SEQUENCE(_source_6481)){
            _3430 = SEQ_PTR(_source_6481)->length;
    }
    else {
        _3430 = 1;
    }
    {
        int _i_6492;
        _i_6492 = 1;
L2: 
        if (_i_6492 > _3430){
            goto L3; // [32] 193
        }

        /** 		x = {source[i], {i, length(source)}, user_data}*/
        _2 = (int)SEQ_PTR(_source_6481);
        _3431 = (int)*(((s1_ptr)_2)->base + _i_6492);
        if (IS_SEQUENCE(_source_6481)){
                _3432 = SEQ_PTR(_source_6481)->length;
        }
        else {
            _3432 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_6492;
        ((int *)_2)[2] = _3432;
        _3433 = MAKE_SEQ(_1);
        _3432 = NOVALUE;
        _0 = _x_6486;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_3431);
        *((int *)(_2+4)) = _3431;
        *((int *)(_2+8)) = _3433;
        Ref(_user_data_6484);
        *((int *)(_2+12)) = _user_data_6484;
        _x_6486 = MAKE_SEQ(_1);
        DeRef(_0);
        _3433 = NOVALUE;
        _3431 = NOVALUE;

        /** 		for j = 1 to length(transformer) do*/
        if (IS_SEQUENCE(_transformer_6482)){
                _3435 = SEQ_PTR(_transformer_6482)->length;
        }
        else {
            _3435 = 1;
        }
        {
            int _j_6499;
            _j_6499 = 1;
L4: 
            if (_j_6499 > _3435){
                goto L5; // [63] 186
            }

            /** 			if transformer[j] >= 0 then*/
            _2 = (int)SEQ_PTR(_transformer_6482);
            _3436 = (int)*(((s1_ptr)_2)->base + _j_6499);
            if (binary_op_a(LESS, _3436, 0)){
                _3436 = NOVALUE;
                goto L6; // [76] 143
            }
            _3436 = NOVALUE;

            /** 				new_x = call_func(transformer[j], x)*/
            _2 = (int)SEQ_PTR(_transformer_6482);
            _3438 = (int)*(((s1_ptr)_2)->base + _j_6499);
            _1 = (int)SEQ_PTR(_x_6486);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_3438].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            Ref(*(int *)(_2+12));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8), 
                                *(int *)(_2+12)
                                 );
            DeRef(_new_x_6487);
            _new_x_6487 = _1;

            /** 				if length(new_x) = 0 then*/
            if (IS_SEQUENCE(_new_x_6487)){
                    _3440 = SEQ_PTR(_new_x_6487)->length;
            }
            else {
                _3440 = 1;
            }
            if (_3440 != 0)
            goto L7; // [95] 104

            /** 					continue*/
            goto L8; // [101] 181
L7: 

            /** 				if new_x[1] = 0 then*/
            _2 = (int)SEQ_PTR(_new_x_6487);
            _3442 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _3442, 0)){
                _3442 = NOVALUE;
                goto L9; // [110] 119
            }
            _3442 = NOVALUE;

            /** 					continue*/
            goto L8; // [116] 181
L9: 

            /** 				if new_x[1] < 0 then*/
            _2 = (int)SEQ_PTR(_new_x_6487);
            _3444 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(GREATEREQ, _3444, 0)){
                _3444 = NOVALUE;
                goto LA; // [125] 134
            }
            _3444 = NOVALUE;

            /** 					exit*/
            goto L5; // [131] 186
LA: 

            /** 				new_x = new_x[2]*/
            _0 = _new_x_6487;
            _2 = (int)SEQ_PTR(_new_x_6487);
            _new_x_6487 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_new_x_6487);
            DeRef(_0);
            goto LB; // [140] 150
L6: 

            /** 				new_x = x[1]*/
            DeRef(_new_x_6487);
            _2 = (int)SEQ_PTR(_x_6486);
            _new_x_6487 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_new_x_6487);
LB: 

            /** 			if singleton then*/
            if (_singleton_6483 == 0)
            {
                goto LC; // [152] 166
            }
            else{
            }

            /** 				result = append(result, new_x)*/
            Ref(_new_x_6487);
            Append(&_result_6485, _result_6485, _new_x_6487);
            goto L5; // [163] 186
LC: 

            /** 				result &= new_x*/
            if (IS_SEQUENCE(_result_6485) && IS_ATOM(_new_x_6487)) {
                Ref(_new_x_6487);
                Append(&_result_6485, _result_6485, _new_x_6487);
            }
            else if (IS_ATOM(_result_6485) && IS_SEQUENCE(_new_x_6487)) {
            }
            else {
                Concat((object_ptr)&_result_6485, _result_6485, _new_x_6487);
            }

            /** 			exit*/
            goto L5; // [177] 186

            /** 		end for*/
L8: 
            _j_6499 = _j_6499 + 1;
            goto L4; // [181] 70
L5: 
            ;
        }

        /** 	end for*/
        _i_6492 = _i_6492 + 1;
        goto L2; // [188] 39
L3: 
        ;
    }

    /** 	return result*/
    DeRefDS(_source_6481);
    DeRef(_transformer_6482);
    DeRef(_user_data_6484);
    DeRef(_x_6486);
    DeRef(_new_x_6487);
    _3438 = NOVALUE;
    return _result_6485;
    ;
}
int build_list() __attribute__ ((alias ("_23build_list")));


int _23transform(int _source_data_6524, int _transformer_rids_6525)
{
    int _lResult_6526 = NOVALUE;
    int _3464 = NOVALUE;
    int _3463 = NOVALUE;
    int _3462 = NOVALUE;
    int _3461 = NOVALUE;
    int _3460 = NOVALUE;
    int _3459 = NOVALUE;
    int _3458 = NOVALUE;
    int _3456 = NOVALUE;
    int _3455 = NOVALUE;
    int _3454 = NOVALUE;
    int _3453 = NOVALUE;
    int _3452 = NOVALUE;
    int _3450 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lResult = source_data*/
    RefDS(_source_data_6524);
    DeRef(_lResult_6526);
    _lResult_6526 = _source_data_6524;

    /** 	if atom(transformer_rids) then*/
    _3450 = IS_ATOM(_transformer_rids_6525);
    if (_3450 == 0)
    {
        _3450 = NOVALUE;
        goto L1; // [15] 25
    }
    else{
        _3450 = NOVALUE;
    }

    /** 		transformer_rids = {transformer_rids}*/
    _0 = _transformer_rids_6525;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_transformer_rids_6525);
    *((int *)(_2+4)) = _transformer_rids_6525;
    _transformer_rids_6525 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(transformer_rids) do*/
    if (IS_SEQUENCE(_transformer_rids_6525)){
            _3452 = SEQ_PTR(_transformer_rids_6525)->length;
    }
    else {
        _3452 = 1;
    }
    {
        int _i_6531;
        _i_6531 = 1;
L2: 
        if (_i_6531 > _3452){
            goto L3; // [30] 112
        }

        /** 		if atom(transformer_rids[i]) then*/
        _2 = (int)SEQ_PTR(_transformer_rids_6525);
        _3453 = (int)*(((s1_ptr)_2)->base + _i_6531);
        _3454 = IS_ATOM(_3453);
        _3453 = NOVALUE;
        if (_3454 == 0)
        {
            _3454 = NOVALUE;
            goto L4; // [46] 68
        }
        else{
            _3454 = NOVALUE;
        }

        /** 			lResult = call_func(transformer_rids[i], {lResult})*/
        _2 = (int)SEQ_PTR(_transformer_rids_6525);
        _3455 = (int)*(((s1_ptr)_2)->base + _i_6531);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_lResult_6526);
        *((int *)(_2+4)) = _lResult_6526;
        _3456 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_3456);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_3455].addr;
        Ref(*(int *)(_2+4));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4)
                             );
        DeRefDS(_lResult_6526);
        _lResult_6526 = _1;
        DeRefDS(_3456);
        _3456 = NOVALUE;
        goto L5; // [65] 105
L4: 

        /** 			lResult = call_func(transformer_rids[i][1], {lResult} & transformer_rids[i][2..$])*/
        _2 = (int)SEQ_PTR(_transformer_rids_6525);
        _3458 = (int)*(((s1_ptr)_2)->base + _i_6531);
        _2 = (int)SEQ_PTR(_3458);
        _3459 = (int)*(((s1_ptr)_2)->base + 1);
        _3458 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_lResult_6526);
        *((int *)(_2+4)) = _lResult_6526;
        _3460 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_transformer_rids_6525);
        _3461 = (int)*(((s1_ptr)_2)->base + _i_6531);
        if (IS_SEQUENCE(_3461)){
                _3462 = SEQ_PTR(_3461)->length;
        }
        else {
            _3462 = 1;
        }
        rhs_slice_target = (object_ptr)&_3463;
        RHS_Slice(_3461, 2, _3462);
        _3461 = NOVALUE;
        Concat((object_ptr)&_3464, _3460, _3463);
        DeRefDS(_3460);
        _3460 = NOVALUE;
        DeRef(_3460);
        _3460 = NOVALUE;
        DeRefDS(_3463);
        _3463 = NOVALUE;
        _1 = (int)SEQ_PTR(_3464);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_3459].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
        }
        DeRefDS(_lResult_6526);
        _lResult_6526 = _1;
        DeRefDS(_3464);
        _3464 = NOVALUE;
L5: 

        /** 	end for*/
        _i_6531 = _i_6531 + 1;
        goto L2; // [107] 37
L3: 
        ;
    }

    /** 	return lResult*/
    DeRefDS(_source_data_6524);
    DeRef(_transformer_rids_6525);
    _3455 = NOVALUE;
    _3459 = NOVALUE;
    return _lResult_6526;
    ;
}
int transform() __attribute__ ((alias ("_23transform")));


int _23transmute(int _source_data_6550, int _current_items_6551, int _new_items_6552, int _start_6553, int _limit_6554)
{
    int _pos_6556 = NOVALUE;
    int _cs_6557 = NOVALUE;
    int _ns_6558 = NOVALUE;
    int _i_6559 = NOVALUE;
    int _elen_6560 = NOVALUE;
    int _3535 = NOVALUE;
    int _3534 = NOVALUE;
    int _3533 = NOVALUE;
    int _3531 = NOVALUE;
    int _3530 = NOVALUE;
    int _3528 = NOVALUE;
    int _3527 = NOVALUE;
    int _3526 = NOVALUE;
    int _3525 = NOVALUE;
    int _3524 = NOVALUE;
    int _3523 = NOVALUE;
    int _3522 = NOVALUE;
    int _3517 = NOVALUE;
    int _3515 = NOVALUE;
    int _3514 = NOVALUE;
    int _3513 = NOVALUE;
    int _3511 = NOVALUE;
    int _3510 = NOVALUE;
    int _3509 = NOVALUE;
    int _3508 = NOVALUE;
    int _3507 = NOVALUE;
    int _3506 = NOVALUE;
    int _3505 = NOVALUE;
    int _3500 = NOVALUE;
    int _3497 = NOVALUE;
    int _3496 = NOVALUE;
    int _3495 = NOVALUE;
    int _3493 = NOVALUE;
    int _3491 = NOVALUE;
    int _3486 = NOVALUE;
    int _3485 = NOVALUE;
    int _3483 = NOVALUE;
    int _3478 = NOVALUE;
    int _3473 = NOVALUE;
    int _3472 = NOVALUE;
    int _3471 = NOVALUE;
    int _3469 = NOVALUE;
    int _3468 = NOVALUE;
    int _3467 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_6553)) {
        _1 = (long)(DBL_PTR(_start_6553)->dbl);
        DeRefDS(_start_6553);
        _start_6553 = _1;
    }
    if (!IS_ATOM_INT(_limit_6554)) {
        _1 = (long)(DBL_PTR(_limit_6554)->dbl);
        DeRefDS(_limit_6554);
        _limit_6554 = _1;
    }

    /** 	if equal(current_items[1], {}) then*/
    _2 = (int)SEQ_PTR(_current_items_6551);
    _3467 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3467 == _5)
    _3468 = 1;
    else if (IS_ATOM_INT(_3467) && IS_ATOM_INT(_5))
    _3468 = 0;
    else
    _3468 = (compare(_3467, _5) == 0);
    _3467 = NOVALUE;
    if (_3468 == 0)
    {
        _3468 = NOVALUE;
        goto L1; // [21] 42
    }
    else{
        _3468 = NOVALUE;
    }

    /** 		cs = 1*/
    _cs_6557 = 1;

    /** 		current_items = current_items[2 .. $]*/
    if (IS_SEQUENCE(_current_items_6551)){
            _3469 = SEQ_PTR(_current_items_6551)->length;
    }
    else {
        _3469 = 1;
    }
    rhs_slice_target = (object_ptr)&_current_items_6551;
    RHS_Slice(_current_items_6551, 2, _3469);
    goto L2; // [39] 48
L1: 

    /** 		cs = 0*/
    _cs_6557 = 0;
L2: 

    /** 	if equal(new_items[1], {}) then*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3471 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3471 == _5)
    _3472 = 1;
    else if (IS_ATOM_INT(_3471) && IS_ATOM_INT(_5))
    _3472 = 0;
    else
    _3472 = (compare(_3471, _5) == 0);
    _3471 = NOVALUE;
    if (_3472 == 0)
    {
        _3472 = NOVALUE;
        goto L3; // [58] 79
    }
    else{
        _3472 = NOVALUE;
    }

    /** 		ns = 1*/
    _ns_6558 = 1;

    /** 		new_items = new_items[2 .. $]*/
    if (IS_SEQUENCE(_new_items_6552)){
            _3473 = SEQ_PTR(_new_items_6552)->length;
    }
    else {
        _3473 = 1;
    }
    rhs_slice_target = (object_ptr)&_new_items_6552;
    RHS_Slice(_new_items_6552, 2, _3473);
    goto L4; // [76] 85
L3: 

    /** 		ns = 0*/
    _ns_6558 = 0;
L4: 

    /** 	i = start - 1*/
    _i_6559 = _start_6553 - 1;

    /** 	if cs = 0 then*/
    if (_cs_6557 != 0)
    goto L5; // [95] 269

    /** 		if ns = 0 then*/
    if (_ns_6558 != 0)
    goto L6; // [103] 177

    /** 			while i < length(source_data) do*/
L7: 
    if (IS_SEQUENCE(_source_data_6550)){
            _3478 = SEQ_PTR(_source_data_6550)->length;
    }
    else {
        _3478 = 1;
    }
    if (_i_6559 >= _3478)
    goto L8; // [115] 567

    /** 				if limit <= 0 then*/
    if (_limit_6554 > 0)
    goto L9; // [121] 130

    /** 					exit*/
    goto L8; // [127] 567
L9: 

    /** 				limit -= 1*/
    _limit_6554 = _limit_6554 - 1;

    /** 				i += 1*/
    _i_6559 = _i_6559 + 1;

    /** 				pos = find(source_data[i], current_items) */
    _2 = (int)SEQ_PTR(_source_data_6550);
    _3483 = (int)*(((s1_ptr)_2)->base + _i_6559);
    _pos_6556 = find_from(_3483, _current_items_6551, 1);
    _3483 = NOVALUE;

    /** 				if pos then*/
    if (_pos_6556 == 0)
    {
        goto L7; // [155] 112
    }
    else{
    }

    /** 					source_data[i] = new_items[pos]*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3485 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    Ref(_3485);
    _2 = (int)SEQ_PTR(_source_data_6550);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _source_data_6550 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_6559);
    _1 = *(int *)_2;
    *(int *)_2 = _3485;
    if( _1 != _3485 ){
        DeRef(_1);
    }
    _3485 = NOVALUE;

    /** 			end while*/
    goto L7; // [171] 112
    goto L8; // [174] 567
L6: 

    /** 			while i < length(source_data) do*/
LA: 
    if (IS_SEQUENCE(_source_data_6550)){
            _3486 = SEQ_PTR(_source_data_6550)->length;
    }
    else {
        _3486 = 1;
    }
    if (_i_6559 >= _3486)
    goto L8; // [185] 567

    /** 				if limit <= 0 then*/
    if (_limit_6554 > 0)
    goto LB; // [191] 200

    /** 					exit*/
    goto L8; // [197] 567
LB: 

    /** 				limit -= 1*/
    _limit_6554 = _limit_6554 - 1;

    /** 				i += 1*/
    _i_6559 = _i_6559 + 1;

    /** 				pos = find(source_data[i], current_items) */
    _2 = (int)SEQ_PTR(_source_data_6550);
    _3491 = (int)*(((s1_ptr)_2)->base + _i_6559);
    _pos_6556 = find_from(_3491, _current_items_6551, 1);
    _3491 = NOVALUE;

    /** 				if pos then*/
    if (_pos_6556 == 0)
    {
        goto LA; // [225] 182
    }
    else{
    }

    /** 					source_data = replace(source_data, new_items[pos], i, i)*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3493 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    {
        int p1 = _source_data_6550;
        int p2 = _3493;
        int p3 = _i_6559;
        int p4 = _i_6559;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6550;
        Replace( &replace_params );
    }
    _3493 = NOVALUE;

    /** 					i += length(new_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3495 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    if (IS_SEQUENCE(_3495)){
            _3496 = SEQ_PTR(_3495)->length;
    }
    else {
        _3496 = 1;
    }
    _3495 = NOVALUE;
    _3497 = _3496 - 1;
    _3496 = NOVALUE;
    _i_6559 = _i_6559 + _3497;
    _3497 = NOVALUE;

    /** 			end while*/
    goto LA; // [262] 182
    goto L8; // [266] 567
L5: 

    /** 		if ns = 0 then*/
    if (_ns_6558 != 0)
    goto LC; // [273] 415

    /** 			while i < length(source_data) do*/
LD: 
    if (IS_SEQUENCE(_source_data_6550)){
            _3500 = SEQ_PTR(_source_data_6550)->length;
    }
    else {
        _3500 = 1;
    }
    if (_i_6559 >= _3500)
    goto LE; // [285] 566

    /** 				if limit <= 0 then*/
    if (_limit_6554 > 0)
    goto LF; // [291] 300

    /** 					exit*/
    goto LE; // [297] 566
LF: 

    /** 				limit -= 1*/
    _limit_6554 = _limit_6554 - 1;

    /** 				i += 1*/
    _i_6559 = _i_6559 + 1;

    /** 				pos = 0*/
    _pos_6556 = 0;

    /** 				for j = 1 to length(current_items) do*/
    if (IS_SEQUENCE(_current_items_6551)){
            _3505 = SEQ_PTR(_current_items_6551)->length;
    }
    else {
        _3505 = 1;
    }
    {
        int _j_6617;
        _j_6617 = 1;
L10: 
        if (_j_6617 > _3505){
            goto L11; // [322] 368
        }

        /** 					if search:begins(current_items[j], source_data[i .. $]) then*/
        _2 = (int)SEQ_PTR(_current_items_6551);
        _3506 = (int)*(((s1_ptr)_2)->base + _j_6617);
        if (IS_SEQUENCE(_source_data_6550)){
                _3507 = SEQ_PTR(_source_data_6550)->length;
        }
        else {
            _3507 = 1;
        }
        rhs_slice_target = (object_ptr)&_3508;
        RHS_Slice(_source_data_6550, _i_6559, _3507);
        Ref(_3506);
        _3509 = _9begins(_3506, _3508);
        _3506 = NOVALUE;
        _3508 = NOVALUE;
        if (_3509 == 0) {
            DeRef(_3509);
            _3509 = NOVALUE;
            goto L12; // [348] 361
        }
        else {
            if (!IS_ATOM_INT(_3509) && DBL_PTR(_3509)->dbl == 0.0){
                DeRef(_3509);
                _3509 = NOVALUE;
                goto L12; // [348] 361
            }
            DeRef(_3509);
            _3509 = NOVALUE;
        }
        DeRef(_3509);
        _3509 = NOVALUE;

        /** 						pos = j*/
        _pos_6556 = _j_6617;

        /** 						exit*/
        goto L11; // [358] 368
L12: 

        /** 				end for*/
        _j_6617 = _j_6617 + 1;
        goto L10; // [363] 329
L11: 
        ;
    }

    /** 				if pos then*/
    if (_pos_6556 == 0)
    {
        goto LD; // [370] 282
    }
    else{
    }

    /** 			    	elen = length(current_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_current_items_6551);
    _3510 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    if (IS_SEQUENCE(_3510)){
            _3511 = SEQ_PTR(_3510)->length;
    }
    else {
        _3511 = 1;
    }
    _3510 = NOVALUE;
    _elen_6560 = _3511 - 1;
    _3511 = NOVALUE;

    /** 					source_data = replace(source_data, {new_items[pos]}, i, i + elen)*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3513 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_3513);
    *((int *)(_2+4)) = _3513;
    _3514 = MAKE_SEQ(_1);
    _3513 = NOVALUE;
    _3515 = _i_6559 + _elen_6560;
    if ((long)((unsigned long)_3515 + (unsigned long)HIGH_BITS) >= 0) 
    _3515 = NewDouble((double)_3515);
    {
        int p1 = _source_data_6550;
        int p2 = _3514;
        int p3 = _i_6559;
        int p4 = _3515;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6550;
        Replace( &replace_params );
    }
    DeRefDS(_3514);
    _3514 = NOVALUE;
    DeRef(_3515);
    _3515 = NOVALUE;

    /** 			end while*/
    goto LD; // [409] 282
    goto LE; // [412] 566
LC: 

    /** 			while i < length(source_data) do*/
L13: 
    if (IS_SEQUENCE(_source_data_6550)){
            _3517 = SEQ_PTR(_source_data_6550)->length;
    }
    else {
        _3517 = 1;
    }
    if (_i_6559 >= _3517)
    goto L14; // [423] 565

    /** 				if limit <= 0 then*/
    if (_limit_6554 > 0)
    goto L15; // [429] 438

    /** 					exit*/
    goto L14; // [435] 565
L15: 

    /** 				limit -= 1*/
    _limit_6554 = _limit_6554 - 1;

    /** 				i += 1*/
    _i_6559 = _i_6559 + 1;

    /** 				pos = 0*/
    _pos_6556 = 0;

    /** 				for j = 1 to length(current_items) do*/
    if (IS_SEQUENCE(_current_items_6551)){
            _3522 = SEQ_PTR(_current_items_6551)->length;
    }
    else {
        _3522 = 1;
    }
    {
        int _j_6641;
        _j_6641 = 1;
L16: 
        if (_j_6641 > _3522){
            goto L17; // [460] 506
        }

        /** 					if search:begins(current_items[j], source_data[i .. $]) then*/
        _2 = (int)SEQ_PTR(_current_items_6551);
        _3523 = (int)*(((s1_ptr)_2)->base + _j_6641);
        if (IS_SEQUENCE(_source_data_6550)){
                _3524 = SEQ_PTR(_source_data_6550)->length;
        }
        else {
            _3524 = 1;
        }
        rhs_slice_target = (object_ptr)&_3525;
        RHS_Slice(_source_data_6550, _i_6559, _3524);
        Ref(_3523);
        _3526 = _9begins(_3523, _3525);
        _3523 = NOVALUE;
        _3525 = NOVALUE;
        if (_3526 == 0) {
            DeRef(_3526);
            _3526 = NOVALUE;
            goto L18; // [486] 499
        }
        else {
            if (!IS_ATOM_INT(_3526) && DBL_PTR(_3526)->dbl == 0.0){
                DeRef(_3526);
                _3526 = NOVALUE;
                goto L18; // [486] 499
            }
            DeRef(_3526);
            _3526 = NOVALUE;
        }
        DeRef(_3526);
        _3526 = NOVALUE;

        /** 						pos = j*/
        _pos_6556 = _j_6641;

        /** 						exit*/
        goto L17; // [496] 506
L18: 

        /** 				end for*/
        _j_6641 = _j_6641 + 1;
        goto L16; // [501] 467
L17: 
        ;
    }

    /** 				if pos then*/
    if (_pos_6556 == 0)
    {
        goto L13; // [508] 420
    }
    else{
    }

    /** 			    	elen = length(current_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_current_items_6551);
    _3527 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    if (IS_SEQUENCE(_3527)){
            _3528 = SEQ_PTR(_3527)->length;
    }
    else {
        _3528 = 1;
    }
    _3527 = NOVALUE;
    _elen_6560 = _3528 - 1;
    _3528 = NOVALUE;

    /** 					source_data = replace(source_data, new_items[pos], i, i + elen)*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3530 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    _3531 = _i_6559 + _elen_6560;
    if ((long)((unsigned long)_3531 + (unsigned long)HIGH_BITS) >= 0) 
    _3531 = NewDouble((double)_3531);
    {
        int p1 = _source_data_6550;
        int p2 = _3530;
        int p3 = _i_6559;
        int p4 = _3531;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_source_data_6550;
        Replace( &replace_params );
    }
    _3530 = NOVALUE;
    DeRef(_3531);
    _3531 = NOVALUE;

    /** 					i += length(new_items[pos]) - 1*/
    _2 = (int)SEQ_PTR(_new_items_6552);
    _3533 = (int)*(((s1_ptr)_2)->base + _pos_6556);
    if (IS_SEQUENCE(_3533)){
            _3534 = SEQ_PTR(_3533)->length;
    }
    else {
        _3534 = 1;
    }
    _3533 = NOVALUE;
    _3535 = _3534 - 1;
    _3534 = NOVALUE;
    _i_6559 = _i_6559 + _3535;
    _3535 = NOVALUE;

    /** 			end while*/
    goto L13; // [562] 420
L14: 
LE: 
L8: 

    /** 	return source_data*/
    DeRefDS(_current_items_6551);
    DeRefDS(_new_items_6552);
    _3495 = NOVALUE;
    _3510 = NOVALUE;
    _3527 = NOVALUE;
    _3533 = NOVALUE;
    return _source_data_6550;
    ;
}
int transmute() __attribute__ ((alias ("_23transmute")));


int _23sim_index(int _A_6661, int _B_6662)
{
    int _accum_score_6663 = NOVALUE;
    int _pos_factor_6664 = NOVALUE;
    int _indx_a_6665 = NOVALUE;
    int _indx_b_6666 = NOVALUE;
    int _used_A_6667 = NOVALUE;
    int _used_B_6668 = NOVALUE;
    int _total_elems_6727 = NOVALUE;
    int _3605 = NOVALUE;
    int _3604 = NOVALUE;
    int _3603 = NOVALUE;
    int _3600 = NOVALUE;
    int _3599 = NOVALUE;
    int _3598 = NOVALUE;
    int _3597 = NOVALUE;
    int _3595 = NOVALUE;
    int _3594 = NOVALUE;
    int _3593 = NOVALUE;
    int _3592 = NOVALUE;
    int _3591 = NOVALUE;
    int _3589 = NOVALUE;
    int _3588 = NOVALUE;
    int _3585 = NOVALUE;
    int _3584 = NOVALUE;
    int _3583 = NOVALUE;
    int _3582 = NOVALUE;
    int _3581 = NOVALUE;
    int _3579 = NOVALUE;
    int _3578 = NOVALUE;
    int _3577 = NOVALUE;
    int _3576 = NOVALUE;
    int _3575 = NOVALUE;
    int _3573 = NOVALUE;
    int _3572 = NOVALUE;
    int _3566 = NOVALUE;
    int _3565 = NOVALUE;
    int _3564 = NOVALUE;
    int _3563 = NOVALUE;
    int _3562 = NOVALUE;
    int _3561 = NOVALUE;
    int _3560 = NOVALUE;
    int _3559 = NOVALUE;
    int _3557 = NOVALUE;
    int _3556 = NOVALUE;
    int _3555 = NOVALUE;
    int _3554 = NOVALUE;
    int _3553 = NOVALUE;
    int _3552 = NOVALUE;
    int _3550 = NOVALUE;
    int _3548 = NOVALUE;
    int _3547 = NOVALUE;
    int _3546 = NOVALUE;
    int _3545 = NOVALUE;
    int _3544 = NOVALUE;
    int _3541 = NOVALUE;
    int _3539 = NOVALUE;
    int _3537 = NOVALUE;
    int _0, _1, _2;
    

    /** 	accum_score = 0*/
    DeRef(_accum_score_6663);
    _accum_score_6663 = 0;

    /** 	indx_a = 1*/
    _indx_a_6665 = 1;

    /** 	used_A = repeat(0, length(A))*/
    if (IS_SEQUENCE(_A_6661)){
            _3537 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3537 = 1;
    }
    DeRefi(_used_A_6667);
    _used_A_6667 = Repeat(0, _3537);
    _3537 = NOVALUE;

    /** 	used_B = repeat(0, length(B))*/
    if (IS_SEQUENCE(_B_6662)){
            _3539 = SEQ_PTR(_B_6662)->length;
    }
    else {
        _3539 = 1;
    }
    DeRefi(_used_B_6668);
    _used_B_6668 = Repeat(0, _3539);
    _3539 = NOVALUE;

    /** 	while indx_a <= length(A) label "DoA" do*/
L1: 
    if (IS_SEQUENCE(_A_6661)){
            _3541 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3541 = 1;
    }
    if (_indx_a_6665 > _3541)
    goto L2; // [41] 232

    /** 		pos_factor = power((1 + length(A) - indx_a) / length(A),2)*/
    if (IS_SEQUENCE(_A_6661)){
            _3544 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3544 = 1;
    }
    _3545 = _3544 + 1;
    _3544 = NOVALUE;
    _3546 = _3545 - _indx_a_6665;
    if ((long)((unsigned long)_3546 +(unsigned long) HIGH_BITS) >= 0){
        _3546 = NewDouble((double)_3546);
    }
    _3545 = NOVALUE;
    if (IS_SEQUENCE(_A_6661)){
            _3547 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3547 = 1;
    }
    if (IS_ATOM_INT(_3546)) {
        _3548 = (_3546 % _3547) ? NewDouble((double)_3546 / _3547) : (_3546 / _3547);
    }
    else {
        _3548 = NewDouble(DBL_PTR(_3546)->dbl / (double)_3547);
    }
    DeRef(_3546);
    _3546 = NOVALUE;
    _3547 = NOVALUE;
    DeRef(_pos_factor_6664);
    if (IS_ATOM_INT(_3548) && IS_ATOM_INT(_3548)) {
        if (_3548 == (short)_3548 && _3548 <= INT15 && _3548 >= -INT15)
        _pos_factor_6664 = _3548 * _3548;
        else
        _pos_factor_6664 = NewDouble(_3548 * (double)_3548);
    }
    else {
        if (IS_ATOM_INT(_3548)) {
            _pos_factor_6664 = NewDouble((double)_3548 * DBL_PTR(_3548)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3548)) {
                _pos_factor_6664 = NewDouble(DBL_PTR(_3548)->dbl * (double)_3548);
            }
            else
            _pos_factor_6664 = NewDouble(DBL_PTR(_3548)->dbl * DBL_PTR(_3548)->dbl);
        }
    }
    DeRef(_3548);
    _3548 = NOVALUE;
    _3548 = NOVALUE;

    /** 		indx_b = 1*/
    _indx_b_6666 = 1;

    /** 		while indx_b <= length(B) do*/
L3: 
    if (IS_SEQUENCE(_B_6662)){
            _3550 = SEQ_PTR(_B_6662)->length;
    }
    else {
        _3550 = 1;
    }
    if (_indx_b_6666 > _3550)
    goto L4; // [82] 221

    /** 			if equal(A[indx_a],B[indx_b]) then*/
    _2 = (int)SEQ_PTR(_A_6661);
    _3552 = (int)*(((s1_ptr)_2)->base + _indx_a_6665);
    _2 = (int)SEQ_PTR(_B_6662);
    _3553 = (int)*(((s1_ptr)_2)->base + _indx_b_6666);
    if (_3552 == _3553)
    _3554 = 1;
    else if (IS_ATOM_INT(_3552) && IS_ATOM_INT(_3553))
    _3554 = 0;
    else
    _3554 = (compare(_3552, _3553) == 0);
    _3552 = NOVALUE;
    _3553 = NOVALUE;
    if (_3554 == 0)
    {
        _3554 = NOVALUE;
        goto L5; // [100] 210
    }
    else{
        _3554 = NOVALUE;
    }

    /** 				accum_score += power((indx_b - indx_a) * pos_factor,2)*/
    _3555 = _indx_b_6666 - _indx_a_6665;
    if ((long)((unsigned long)_3555 +(unsigned long) HIGH_BITS) >= 0){
        _3555 = NewDouble((double)_3555);
    }
    if (IS_ATOM_INT(_3555) && IS_ATOM_INT(_pos_factor_6664)) {
        if (_3555 == (short)_3555 && _pos_factor_6664 <= INT15 && _pos_factor_6664 >= -INT15)
        _3556 = _3555 * _pos_factor_6664;
        else
        _3556 = NewDouble(_3555 * (double)_pos_factor_6664);
    }
    else {
        if (IS_ATOM_INT(_3555)) {
            _3556 = NewDouble((double)_3555 * DBL_PTR(_pos_factor_6664)->dbl);
        }
        else {
            if (IS_ATOM_INT(_pos_factor_6664)) {
                _3556 = NewDouble(DBL_PTR(_3555)->dbl * (double)_pos_factor_6664);
            }
            else
            _3556 = NewDouble(DBL_PTR(_3555)->dbl * DBL_PTR(_pos_factor_6664)->dbl);
        }
    }
    DeRef(_3555);
    _3555 = NOVALUE;
    if (IS_ATOM_INT(_3556) && IS_ATOM_INT(_3556)) {
        if (_3556 == (short)_3556 && _3556 <= INT15 && _3556 >= -INT15)
        _3557 = _3556 * _3556;
        else
        _3557 = NewDouble(_3556 * (double)_3556);
    }
    else {
        if (IS_ATOM_INT(_3556)) {
            _3557 = NewDouble((double)_3556 * DBL_PTR(_3556)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3556)) {
                _3557 = NewDouble(DBL_PTR(_3556)->dbl * (double)_3556);
            }
            else
            _3557 = NewDouble(DBL_PTR(_3556)->dbl * DBL_PTR(_3556)->dbl);
        }
    }
    DeRef(_3556);
    _3556 = NOVALUE;
    _3556 = NOVALUE;
    _0 = _accum_score_6663;
    if (IS_ATOM_INT(_accum_score_6663) && IS_ATOM_INT(_3557)) {
        _accum_score_6663 = _accum_score_6663 + _3557;
        if ((long)((unsigned long)_accum_score_6663 + (unsigned long)HIGH_BITS) >= 0) 
        _accum_score_6663 = NewDouble((double)_accum_score_6663);
    }
    else {
        if (IS_ATOM_INT(_accum_score_6663)) {
            _accum_score_6663 = NewDouble((double)_accum_score_6663 + DBL_PTR(_3557)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3557)) {
                _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + (double)_3557);
            }
            else
            _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + DBL_PTR(_3557)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_3557);
    _3557 = NOVALUE;

    /** 				while indx_a <= length(A) and indx_b <= length(B) with entry do*/
    goto L6; // [123] 176
L7: 
    if (IS_SEQUENCE(_A_6661)){
            _3559 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3559 = 1;
    }
    _3560 = (_indx_a_6665 <= _3559);
    _3559 = NOVALUE;
    if (_3560 == 0) {
        DeRef(_3561);
        _3561 = 0;
        goto L8; // [133] 148
    }
    if (IS_SEQUENCE(_B_6662)){
            _3562 = SEQ_PTR(_B_6662)->length;
    }
    else {
        _3562 = 1;
    }
    _3563 = (_indx_b_6666 <= _3562);
    _3562 = NOVALUE;
    _3561 = (_3563 != 0);
L8: 
    if (_3561 == 0)
    {
        _3561 = NOVALUE;
        goto L1; // [148] 38
    }
    else{
        _3561 = NOVALUE;
    }

    /** 					if not equal(A[indx_a], B[indx_b]) then*/
    _2 = (int)SEQ_PTR(_A_6661);
    _3564 = (int)*(((s1_ptr)_2)->base + _indx_a_6665);
    _2 = (int)SEQ_PTR(_B_6662);
    _3565 = (int)*(((s1_ptr)_2)->base + _indx_b_6666);
    if (_3564 == _3565)
    _3566 = 1;
    else if (IS_ATOM_INT(_3564) && IS_ATOM_INT(_3565))
    _3566 = 0;
    else
    _3566 = (compare(_3564, _3565) == 0);
    _3564 = NOVALUE;
    _3565 = NOVALUE;
    if (_3566 != 0)
    goto L9; // [165] 173
    _3566 = NOVALUE;

    /** 						exit*/
    goto L1; // [170] 38
L9: 

    /** 				entry*/
L6: 

    /** 					used_B[indx_b] = 1*/
    _2 = (int)SEQ_PTR(_used_B_6668);
    _2 = (int)(((s1_ptr)_2)->base + _indx_b_6666);
    *(int *)_2 = 1;

    /** 					used_A[indx_a] = 1*/
    _2 = (int)SEQ_PTR(_used_A_6667);
    _2 = (int)(((s1_ptr)_2)->base + _indx_a_6665);
    *(int *)_2 = 1;

    /** 					indx_a += 1*/
    _indx_a_6665 = _indx_a_6665 + 1;

    /** 					indx_b += 1*/
    _indx_b_6666 = _indx_b_6666 + 1;

    /** 				end while*/
    goto L7; // [202] 126

    /** 				continue "DoA"*/
    goto L1; // [207] 38
L5: 

    /** 			indx_b += 1*/
    _indx_b_6666 = _indx_b_6666 + 1;

    /** 		end while*/
    goto L3; // [218] 79
L4: 

    /** 		indx_a += 1*/
    _indx_a_6665 = _indx_a_6665 + 1;

    /** 	end while*/
    goto L1; // [229] 38
L2: 

    /**  	for i = 1 to length(A) do*/
    if (IS_SEQUENCE(_A_6661)){
            _3572 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _3572 = 1;
    }
    {
        int _i_6710;
        _i_6710 = 1;
LA: 
        if (_i_6710 > _3572){
            goto LB; // [237] 311
        }

        /**  		if used_A[i] = 0 then*/
        _2 = (int)SEQ_PTR(_used_A_6667);
        _3573 = (int)*(((s1_ptr)_2)->base + _i_6710);
        if (_3573 != 0)
        goto LC; // [250] 304

        /** 			pos_factor = power((1 + length(A) - i) / length(A),2)*/
        if (IS_SEQUENCE(_A_6661)){
                _3575 = SEQ_PTR(_A_6661)->length;
        }
        else {
            _3575 = 1;
        }
        _3576 = _3575 + 1;
        _3575 = NOVALUE;
        _3577 = _3576 - _i_6710;
        _3576 = NOVALUE;
        if (IS_SEQUENCE(_A_6661)){
                _3578 = SEQ_PTR(_A_6661)->length;
        }
        else {
            _3578 = 1;
        }
        _3579 = (_3577 % _3578) ? NewDouble((double)_3577 / _3578) : (_3577 / _3578);
        _3577 = NOVALUE;
        _3578 = NOVALUE;
        DeRef(_pos_factor_6664);
        if (IS_ATOM_INT(_3579) && IS_ATOM_INT(_3579)) {
            if (_3579 == (short)_3579 && _3579 <= INT15 && _3579 >= -INT15)
            _pos_factor_6664 = _3579 * _3579;
            else
            _pos_factor_6664 = NewDouble(_3579 * (double)_3579);
        }
        else {
            if (IS_ATOM_INT(_3579)) {
                _pos_factor_6664 = NewDouble((double)_3579 * DBL_PTR(_3579)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3579)) {
                    _pos_factor_6664 = NewDouble(DBL_PTR(_3579)->dbl * (double)_3579);
                }
                else
                _pos_factor_6664 = NewDouble(DBL_PTR(_3579)->dbl * DBL_PTR(_3579)->dbl);
            }
        }
        DeRef(_3579);
        _3579 = NOVALUE;
        _3579 = NOVALUE;

        /**  			accum_score += power((length(A) - i + 1) * pos_factor,2)*/
        if (IS_SEQUENCE(_A_6661)){
                _3581 = SEQ_PTR(_A_6661)->length;
        }
        else {
            _3581 = 1;
        }
        _3582 = _3581 - _i_6710;
        _3581 = NOVALUE;
        _3583 = _3582 + 1;
        _3582 = NOVALUE;
        if (IS_ATOM_INT(_pos_factor_6664)) {
            if (_3583 == (short)_3583 && _pos_factor_6664 <= INT15 && _pos_factor_6664 >= -INT15)
            _3584 = _3583 * _pos_factor_6664;
            else
            _3584 = NewDouble(_3583 * (double)_pos_factor_6664);
        }
        else {
            _3584 = NewDouble((double)_3583 * DBL_PTR(_pos_factor_6664)->dbl);
        }
        _3583 = NOVALUE;
        if (IS_ATOM_INT(_3584) && IS_ATOM_INT(_3584)) {
            if (_3584 == (short)_3584 && _3584 <= INT15 && _3584 >= -INT15)
            _3585 = _3584 * _3584;
            else
            _3585 = NewDouble(_3584 * (double)_3584);
        }
        else {
            if (IS_ATOM_INT(_3584)) {
                _3585 = NewDouble((double)_3584 * DBL_PTR(_3584)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3584)) {
                    _3585 = NewDouble(DBL_PTR(_3584)->dbl * (double)_3584);
                }
                else
                _3585 = NewDouble(DBL_PTR(_3584)->dbl * DBL_PTR(_3584)->dbl);
            }
        }
        DeRef(_3584);
        _3584 = NOVALUE;
        _3584 = NOVALUE;
        _0 = _accum_score_6663;
        if (IS_ATOM_INT(_accum_score_6663) && IS_ATOM_INT(_3585)) {
            _accum_score_6663 = _accum_score_6663 + _3585;
            if ((long)((unsigned long)_accum_score_6663 + (unsigned long)HIGH_BITS) >= 0) 
            _accum_score_6663 = NewDouble((double)_accum_score_6663);
        }
        else {
            if (IS_ATOM_INT(_accum_score_6663)) {
                _accum_score_6663 = NewDouble((double)_accum_score_6663 + DBL_PTR(_3585)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3585)) {
                    _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + (double)_3585);
                }
                else
                _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + DBL_PTR(_3585)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_3585);
        _3585 = NOVALUE;
LC: 

        /**  	end for*/
        _i_6710 = _i_6710 + 1;
        goto LA; // [306] 244
LB: 
        ;
    }

    /**  	integer total_elems = length(A)*/
    if (IS_SEQUENCE(_A_6661)){
            _total_elems_6727 = SEQ_PTR(_A_6661)->length;
    }
    else {
        _total_elems_6727 = 1;
    }

    /**  	for i = 1 to length(B) do*/
    if (IS_SEQUENCE(_B_6662)){
            _3588 = SEQ_PTR(_B_6662)->length;
    }
    else {
        _3588 = 1;
    }
    {
        int _i_6730;
        _i_6730 = 1;
LD: 
        if (_i_6730 > _3588){
            goto LE; // [321] 397
        }

        /**  		if used_B[i] = 0 then*/
        _2 = (int)SEQ_PTR(_used_B_6668);
        _3589 = (int)*(((s1_ptr)_2)->base + _i_6730);
        if (_3589 != 0)
        goto LF; // [334] 390

        /** 			pos_factor = power((1 + length(B) - i) / length(B),2)*/
        if (IS_SEQUENCE(_B_6662)){
                _3591 = SEQ_PTR(_B_6662)->length;
        }
        else {
            _3591 = 1;
        }
        _3592 = _3591 + 1;
        _3591 = NOVALUE;
        _3593 = _3592 - _i_6730;
        _3592 = NOVALUE;
        if (IS_SEQUENCE(_B_6662)){
                _3594 = SEQ_PTR(_B_6662)->length;
        }
        else {
            _3594 = 1;
        }
        _3595 = (_3593 % _3594) ? NewDouble((double)_3593 / _3594) : (_3593 / _3594);
        _3593 = NOVALUE;
        _3594 = NOVALUE;
        DeRef(_pos_factor_6664);
        if (IS_ATOM_INT(_3595) && IS_ATOM_INT(_3595)) {
            if (_3595 == (short)_3595 && _3595 <= INT15 && _3595 >= -INT15)
            _pos_factor_6664 = _3595 * _3595;
            else
            _pos_factor_6664 = NewDouble(_3595 * (double)_3595);
        }
        else {
            if (IS_ATOM_INT(_3595)) {
                _pos_factor_6664 = NewDouble((double)_3595 * DBL_PTR(_3595)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3595)) {
                    _pos_factor_6664 = NewDouble(DBL_PTR(_3595)->dbl * (double)_3595);
                }
                else
                _pos_factor_6664 = NewDouble(DBL_PTR(_3595)->dbl * DBL_PTR(_3595)->dbl);
            }
        }
        DeRef(_3595);
        _3595 = NOVALUE;
        _3595 = NOVALUE;

        /**  			accum_score += (length(B) - i + 1) * pos_factor*/
        if (IS_SEQUENCE(_B_6662)){
                _3597 = SEQ_PTR(_B_6662)->length;
        }
        else {
            _3597 = 1;
        }
        _3598 = _3597 - _i_6730;
        _3597 = NOVALUE;
        _3599 = _3598 + 1;
        _3598 = NOVALUE;
        if (IS_ATOM_INT(_pos_factor_6664)) {
            if (_3599 == (short)_3599 && _pos_factor_6664 <= INT15 && _pos_factor_6664 >= -INT15)
            _3600 = _3599 * _pos_factor_6664;
            else
            _3600 = NewDouble(_3599 * (double)_pos_factor_6664);
        }
        else {
            _3600 = NewDouble((double)_3599 * DBL_PTR(_pos_factor_6664)->dbl);
        }
        _3599 = NOVALUE;
        _0 = _accum_score_6663;
        if (IS_ATOM_INT(_accum_score_6663) && IS_ATOM_INT(_3600)) {
            _accum_score_6663 = _accum_score_6663 + _3600;
            if ((long)((unsigned long)_accum_score_6663 + (unsigned long)HIGH_BITS) >= 0) 
            _accum_score_6663 = NewDouble((double)_accum_score_6663);
        }
        else {
            if (IS_ATOM_INT(_accum_score_6663)) {
                _accum_score_6663 = NewDouble((double)_accum_score_6663 + DBL_PTR(_3600)->dbl);
            }
            else {
                if (IS_ATOM_INT(_3600)) {
                    _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + (double)_3600);
                }
                else
                _accum_score_6663 = NewDouble(DBL_PTR(_accum_score_6663)->dbl + DBL_PTR(_3600)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_3600);
        _3600 = NOVALUE;

        /**  			total_elems += 1*/
        _total_elems_6727 = _total_elems_6727 + 1;
LF: 

        /**  	end for*/
        _i_6730 = _i_6730 + 1;
        goto LD; // [392] 328
LE: 
        ;
    }

    /** 	return power(accum_score / power(total_elems,2), 0.5)*/
    if (_total_elems_6727 == (short)_total_elems_6727 && _total_elems_6727 <= INT15 && _total_elems_6727 >= -INT15)
    _3603 = _total_elems_6727 * _total_elems_6727;
    else
    _3603 = NewDouble(_total_elems_6727 * (double)_total_elems_6727);
    if (IS_ATOM_INT(_accum_score_6663) && IS_ATOM_INT(_3603)) {
        _3604 = (_accum_score_6663 % _3603) ? NewDouble((double)_accum_score_6663 / _3603) : (_accum_score_6663 / _3603);
    }
    else {
        if (IS_ATOM_INT(_accum_score_6663)) {
            _3604 = NewDouble((double)_accum_score_6663 / DBL_PTR(_3603)->dbl);
        }
        else {
            if (IS_ATOM_INT(_3603)) {
                _3604 = NewDouble(DBL_PTR(_accum_score_6663)->dbl / (double)_3603);
            }
            else
            _3604 = NewDouble(DBL_PTR(_accum_score_6663)->dbl / DBL_PTR(_3603)->dbl);
        }
    }
    DeRef(_3603);
    _3603 = NOVALUE;
    if (IS_ATOM_INT(_3604)) {
        temp_d.dbl = (double)_3604;
        _3605 = Dpower(&temp_d, DBL_PTR(_2326));
    }
    else {
        _3605 = Dpower(DBL_PTR(_3604), DBL_PTR(_2326));
    }
    DeRef(_3604);
    _3604 = NOVALUE;
    DeRefDS(_A_6661);
    DeRefDS(_B_6662);
    DeRef(_accum_score_6663);
    DeRef(_pos_factor_6664);
    DeRefi(_used_A_6667);
    DeRefi(_used_B_6668);
    DeRef(_3560);
    _3560 = NOVALUE;
    DeRef(_3563);
    _3563 = NOVALUE;
    _3573 = NOVALUE;
    _3589 = NOVALUE;
    return _3605;
    ;
}
int sim_index() __attribute__ ((alias ("_23sim_index")));


int _23remove_subseq(int _source_list_6756, int _alt_value_6757)
{
    int _lResult_6758 = NOVALUE;
    int _lCOW_6759 = NOVALUE;
    int _3622 = NOVALUE;
    int _3621 = NOVALUE;
    int _3617 = NOVALUE;
    int _3614 = NOVALUE;
    int _3611 = NOVALUE;
    int _3610 = NOVALUE;
    int _3609 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lCOW = 0*/
    _lCOW_6759 = 0;

    /** 	for i = 1 to length(source_list) do*/
    if (IS_SEQUENCE(_source_list_6756)){
            _3609 = SEQ_PTR(_source_list_6756)->length;
    }
    else {
        _3609 = 1;
    }
    {
        int _i_6761;
        _i_6761 = 1;
L1: 
        if (_i_6761 > _3609){
            goto L2; // [13] 121
        }

        /** 		if atom(source_list[i]) then*/
        _2 = (int)SEQ_PTR(_source_list_6756);
        _3610 = (int)*(((s1_ptr)_2)->base + _i_6761);
        _3611 = IS_ATOM(_3610);
        _3610 = NOVALUE;
        if (_3611 == 0)
        {
            _3611 = NOVALUE;
            goto L3; // [29] 69
        }
        else{
            _3611 = NOVALUE;
        }

        /** 			if lCOW != 0 then*/
        if (_lCOW_6759 == 0)
        goto L4; // [34] 116

        /** 				if lCOW != i then*/
        if (_lCOW_6759 == _i_6761)
        goto L5; // [40] 57

        /** 					lResult[lCOW] = source_list[i]*/
        _2 = (int)SEQ_PTR(_source_list_6756);
        _3614 = (int)*(((s1_ptr)_2)->base + _i_6761);
        Ref(_3614);
        _2 = (int)SEQ_PTR(_lResult_6758);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lResult_6758 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lCOW_6759);
        _1 = *(int *)_2;
        *(int *)_2 = _3614;
        if( _1 != _3614 ){
            DeRef(_1);
        }
        _3614 = NOVALUE;
L5: 

        /** 				lCOW += 1*/
        _lCOW_6759 = _lCOW_6759 + 1;

        /** 			continue*/
        goto L4; // [66] 116
L3: 

        /** 		if lCOW = 0 then*/
        if (_lCOW_6759 != 0)
        goto L6; // [71] 88

        /** 			lResult = source_list*/
        RefDS(_source_list_6756);
        DeRef(_lResult_6758);
        _lResult_6758 = _source_list_6756;

        /** 			lCOW = i*/
        _lCOW_6759 = _i_6761;
L6: 

        /** 		if not equal(alt_value, SEQ_NOALT) then*/
        if (_alt_value_6757 == _23SEQ_NOALT_6750)
        _3617 = 1;
        else if (IS_ATOM_INT(_alt_value_6757) && IS_ATOM_INT(_23SEQ_NOALT_6750))
        _3617 = 0;
        else
        _3617 = (compare(_alt_value_6757, _23SEQ_NOALT_6750) == 0);
        if (_3617 != 0)
        goto L7; // [96] 114
        _3617 = NOVALUE;

        /** 			lResult[lCOW] = alt_value*/
        Ref(_alt_value_6757);
        _2 = (int)SEQ_PTR(_lResult_6758);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lResult_6758 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lCOW_6759);
        _1 = *(int *)_2;
        *(int *)_2 = _alt_value_6757;
        DeRef(_1);

        /** 			lCOW += 1*/
        _lCOW_6759 = _lCOW_6759 + 1;
L7: 

        /** 	end for*/
L4: 
        _i_6761 = _i_6761 + 1;
        goto L1; // [116] 20
L2: 
        ;
    }

    /** 	if lCOW = 0 then*/
    if (_lCOW_6759 != 0)
    goto L8; // [123] 134

    /** 		return source_list*/
    DeRef(_alt_value_6757);
    DeRef(_lResult_6758);
    return _source_list_6756;
L8: 

    /** 	return lResult[1.. lCOW - 1]*/
    _3621 = _lCOW_6759 - 1;
    rhs_slice_target = (object_ptr)&_3622;
    RHS_Slice(_lResult_6758, 1, _3621);
    DeRefDS(_source_list_6756);
    DeRef(_alt_value_6757);
    DeRefDS(_lResult_6758);
    _3621 = NOVALUE;
    return _3622;
    ;
}
int remove_subseq() __attribute__ ((alias ("_23remove_subseq")));


int _23remove_dups(int _source_data_6787, int _proc_option_6788)
{
    int _lTo_6789 = NOVALUE;
    int _lFrom_6790 = NOVALUE;
    int _lResult_6813 = NOVALUE;
    int _3643 = NOVALUE;
    int _3641 = NOVALUE;
    int _3640 = NOVALUE;
    int _3639 = NOVALUE;
    int _3638 = NOVALUE;
    int _3636 = NOVALUE;
    int _3632 = NOVALUE;
    int _3631 = NOVALUE;
    int _3630 = NOVALUE;
    int _3628 = NOVALUE;
    int _3623 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_option_6788)) {
        _1 = (long)(DBL_PTR(_proc_option_6788)->dbl);
        DeRefDS(_proc_option_6788);
        _proc_option_6788 = _1;
    }

    /** 	if length(source_data) < 2 then*/
    if (IS_SEQUENCE(_source_data_6787)){
            _3623 = SEQ_PTR(_source_data_6787)->length;
    }
    else {
        _3623 = 1;
    }
    if (_3623 >= 2)
    goto L1; // [10] 21

    /** 		return source_data*/
    DeRef(_lResult_6813);
    return _source_data_6787;
L1: 

    /** 	if proc_option = RD_SORT then*/
    if (_proc_option_6788 != 3)
    goto L2; // [23] 42

    /** 		source_data = stdsort:sort(source_data)*/
    RefDS(_source_data_6787);
    _0 = _source_data_6787;
    _source_data_6787 = _24sort(_source_data_6787, 1);
    DeRefDS(_0);

    /** 		proc_option = RD_PRESORTED*/
    _proc_option_6788 = 2;
L2: 

    /** 	if proc_option = RD_PRESORTED then*/
    if (_proc_option_6788 != 2)
    goto L3; // [44] 134

    /** 		lTo = 1*/
    _lTo_6789 = 1;

    /** 		lFrom = 2*/
    _lFrom_6790 = 2;

    /** 		while lFrom <= length(source_data) do*/
L4: 
    if (IS_SEQUENCE(_source_data_6787)){
            _3628 = SEQ_PTR(_source_data_6787)->length;
    }
    else {
        _3628 = 1;
    }
    if (_lFrom_6790 > _3628)
    goto L5; // [66] 122

    /** 			if not equal(source_data[lFrom], source_data[lTo]) then*/
    _2 = (int)SEQ_PTR(_source_data_6787);
    _3630 = (int)*(((s1_ptr)_2)->base + _lFrom_6790);
    _2 = (int)SEQ_PTR(_source_data_6787);
    _3631 = (int)*(((s1_ptr)_2)->base + _lTo_6789);
    if (_3630 == _3631)
    _3632 = 1;
    else if (IS_ATOM_INT(_3630) && IS_ATOM_INT(_3631))
    _3632 = 0;
    else
    _3632 = (compare(_3630, _3631) == 0);
    _3630 = NOVALUE;
    _3631 = NOVALUE;
    if (_3632 != 0)
    goto L6; // [84] 111
    _3632 = NOVALUE;

    /** 				lTo += 1*/
    _lTo_6789 = _lTo_6789 + 1;

    /** 				if lTo != lFrom then*/
    if (_lTo_6789 == _lFrom_6790)
    goto L7; // [95] 110

    /** 					source_data[lTo] = source_data[lFrom]*/
    _2 = (int)SEQ_PTR(_source_data_6787);
    _3636 = (int)*(((s1_ptr)_2)->base + _lFrom_6790);
    Ref(_3636);
    _2 = (int)SEQ_PTR(_source_data_6787);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _source_data_6787 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lTo_6789);
    _1 = *(int *)_2;
    *(int *)_2 = _3636;
    if( _1 != _3636 ){
        DeRef(_1);
    }
    _3636 = NOVALUE;
L7: 
L6: 

    /** 			lFrom += 1*/
    _lFrom_6790 = _lFrom_6790 + 1;

    /** 		end while*/
    goto L4; // [119] 63
L5: 

    /** 		return source_data[1 .. lTo]*/
    rhs_slice_target = (object_ptr)&_3638;
    RHS_Slice(_source_data_6787, 1, _lTo_6789);
    DeRefDS(_source_data_6787);
    DeRef(_lResult_6813);
    return _3638;
L3: 

    /** 	sequence lResult*/

    /** 	lResult = {}*/
    RefDS(_5);
    DeRef(_lResult_6813);
    _lResult_6813 = _5;

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6787)){
            _3639 = SEQ_PTR(_source_data_6787)->length;
    }
    else {
        _3639 = 1;
    }
    {
        int _i_6815;
        _i_6815 = 1;
L8: 
        if (_i_6815 > _3639){
            goto L9; // [148] 187
        }

        /** 		if not find(source_data[i], lResult) then*/
        _2 = (int)SEQ_PTR(_source_data_6787);
        _3640 = (int)*(((s1_ptr)_2)->base + _i_6815);
        _3641 = find_from(_3640, _lResult_6813, 1);
        _3640 = NOVALUE;
        if (_3641 != 0)
        goto LA; // [166] 180
        _3641 = NOVALUE;

        /** 			lResult = append(lResult, source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6787);
        _3643 = (int)*(((s1_ptr)_2)->base + _i_6815);
        Ref(_3643);
        Append(&_lResult_6813, _lResult_6813, _3643);
        _3643 = NOVALUE;
LA: 

        /** 	end for*/
        _i_6815 = _i_6815 + 1;
        goto L8; // [182] 155
L9: 
        ;
    }

    /** 	return lResult*/
    DeRefDS(_source_data_6787);
    DeRef(_3638);
    _3638 = NOVALUE;
    return _lResult_6813;
    ;
}
int remove_dups() __attribute__ ((alias ("_23remove_dups")));


int _23combine(int _source_data_6827, int _proc_option_6828)
{
    int _lResult_6829 = NOVALUE;
    int _lTotalSize_6830 = NOVALUE;
    int _lPos_6831 = NOVALUE;
    int _3665 = NOVALUE;
    int _3662 = NOVALUE;
    int _3661 = NOVALUE;
    int _3660 = NOVALUE;
    int _3659 = NOVALUE;
    int _3658 = NOVALUE;
    int _3657 = NOVALUE;
    int _3656 = NOVALUE;
    int _3655 = NOVALUE;
    int _3652 = NOVALUE;
    int _3651 = NOVALUE;
    int _3650 = NOVALUE;
    int _3649 = NOVALUE;
    int _3647 = NOVALUE;
    int _3645 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_option_6828)) {
        _1 = (long)(DBL_PTR(_proc_option_6828)->dbl);
        DeRefDS(_proc_option_6828);
        _proc_option_6828 = _1;
    }

    /** 	integer lTotalSize = 0*/
    _lTotalSize_6830 = 0;

    /** 	if length(source_data) = 0 then*/
    if (IS_SEQUENCE(_source_data_6827)){
            _3645 = SEQ_PTR(_source_data_6827)->length;
    }
    else {
        _3645 = 1;
    }
    if (_3645 != 0)
    goto L1; // [15] 26

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_source_data_6827);
    DeRef(_lResult_6829);
    return _5;
L1: 

    /** 	if length(source_data) = 1 then*/
    if (IS_SEQUENCE(_source_data_6827)){
            _3647 = SEQ_PTR(_source_data_6827)->length;
    }
    else {
        _3647 = 1;
    }
    if (_3647 != 1)
    goto L2; // [31] 46

    /** 		return source_data[1]*/
    _2 = (int)SEQ_PTR(_source_data_6827);
    _3649 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3649);
    DeRefDS(_source_data_6827);
    DeRef(_lResult_6829);
    return _3649;
L2: 

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6827)){
            _3650 = SEQ_PTR(_source_data_6827)->length;
    }
    else {
        _3650 = 1;
    }
    {
        int _i_6840;
        _i_6840 = 1;
L3: 
        if (_i_6840 > _3650){
            goto L4; // [51] 78
        }

        /** 		lTotalSize += length(source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6827);
        _3651 = (int)*(((s1_ptr)_2)->base + _i_6840);
        if (IS_SEQUENCE(_3651)){
                _3652 = SEQ_PTR(_3651)->length;
        }
        else {
            _3652 = 1;
        }
        _3651 = NOVALUE;
        _lTotalSize_6830 = _lTotalSize_6830 + _3652;
        _3652 = NOVALUE;

        /** 	end for*/
        _i_6840 = _i_6840 + 1;
        goto L3; // [73] 58
L4: 
        ;
    }

    /** 	lResult = repeat(0, lTotalSize)*/
    DeRef(_lResult_6829);
    _lResult_6829 = Repeat(0, _lTotalSize_6830);

    /** 	lPos = 1*/
    _lPos_6831 = 1;

    /** 	for i = 1 to length(source_data) do*/
    if (IS_SEQUENCE(_source_data_6827)){
            _3655 = SEQ_PTR(_source_data_6827)->length;
    }
    else {
        _3655 = 1;
    }
    {
        int _i_6847;
        _i_6847 = 1;
L5: 
        if (_i_6847 > _3655){
            goto L6; // [94] 147
        }

        /** 		lResult[lPos .. length(source_data[i]) + lPos - 1] = source_data[i]*/
        _2 = (int)SEQ_PTR(_source_data_6827);
        _3656 = (int)*(((s1_ptr)_2)->base + _i_6847);
        if (IS_SEQUENCE(_3656)){
                _3657 = SEQ_PTR(_3656)->length;
        }
        else {
            _3657 = 1;
        }
        _3656 = NOVALUE;
        _3658 = _3657 + _lPos_6831;
        if ((long)((unsigned long)_3658 + (unsigned long)HIGH_BITS) >= 0) 
        _3658 = NewDouble((double)_3658);
        _3657 = NOVALUE;
        if (IS_ATOM_INT(_3658)) {
            _3659 = _3658 - 1;
            if ((long)((unsigned long)_3659 +(unsigned long) HIGH_BITS) >= 0){
                _3659 = NewDouble((double)_3659);
            }
        }
        else {
            _3659 = NewDouble(DBL_PTR(_3658)->dbl - (double)1);
        }
        DeRef(_3658);
        _3658 = NOVALUE;
        _2 = (int)SEQ_PTR(_source_data_6827);
        _3660 = (int)*(((s1_ptr)_2)->base + _i_6847);
        assign_slice_seq = (s1_ptr *)&_lResult_6829;
        AssignSlice(_lPos_6831, _3659, _3660);
        DeRef(_3659);
        _3659 = NOVALUE;
        _3660 = NOVALUE;

        /** 		lPos += length(source_data[i])*/
        _2 = (int)SEQ_PTR(_source_data_6827);
        _3661 = (int)*(((s1_ptr)_2)->base + _i_6847);
        if (IS_SEQUENCE(_3661)){
                _3662 = SEQ_PTR(_3661)->length;
        }
        else {
            _3662 = 1;
        }
        _3661 = NOVALUE;
        _lPos_6831 = _lPos_6831 + _3662;
        _3662 = NOVALUE;

        /** 	end for*/
        _i_6847 = _i_6847 + 1;
        goto L5; // [142] 101
L6: 
        ;
    }

    /** 	if proc_option = COMBINE_SORTED then*/
    if (_proc_option_6828 != 1)
    goto L7; // [149] 167

    /** 		return stdsort:sort(lResult)*/
    RefDS(_lResult_6829);
    _3665 = _24sort(_lResult_6829, 1);
    DeRefDS(_source_data_6827);
    DeRefDS(_lResult_6829);
    _3649 = NOVALUE;
    _3651 = NOVALUE;
    _3656 = NOVALUE;
    _3661 = NOVALUE;
    return _3665;
    goto L8; // [164] 174
L7: 

    /** 		return lResult*/
    DeRefDS(_source_data_6827);
    _3649 = NOVALUE;
    _3651 = NOVALUE;
    _3656 = NOVALUE;
    _3661 = NOVALUE;
    DeRef(_3665);
    _3665 = NOVALUE;
    return _lResult_6829;
L8: 
    ;
}
int combine() __attribute__ ((alias ("_23combine")));


int _23minsize(int _source_data_6863, int _min_size_6864, int _new_data_6869)
{
    int _3674 = NOVALUE;
    int _3673 = NOVALUE;
    int _3672 = NOVALUE;
    int _3670 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_min_size_6864)) {
        _1 = (long)(DBL_PTR(_min_size_6864)->dbl);
        DeRefDS(_min_size_6864);
        _min_size_6864 = _1;
    }

    /**     if length(source_data) < min_size then*/
    if (IS_SEQUENCE(_source_data_6863)){
            _3670 = SEQ_PTR(_source_data_6863)->length;
    }
    else {
        _3670 = 1;
    }
    if (_3670 >= _min_size_6864)
    goto L1; // [8] 30

    /**         source_data &= repeat(new_data, min_size - length(source_data))*/
    if (IS_SEQUENCE(_source_data_6863)){
            _3672 = SEQ_PTR(_source_data_6863)->length;
    }
    else {
        _3672 = 1;
    }
    _3673 = _min_size_6864 - _3672;
    _3672 = NOVALUE;
    _3674 = Repeat(_new_data_6869, _3673);
    _3673 = NOVALUE;
    if (IS_SEQUENCE(_source_data_6863) && IS_ATOM(_3674)) {
    }
    else if (IS_ATOM(_source_data_6863) && IS_SEQUENCE(_3674)) {
        Ref(_source_data_6863);
        Prepend(&_source_data_6863, _3674, _source_data_6863);
    }
    else {
        Concat((object_ptr)&_source_data_6863, _source_data_6863, _3674);
    }
    DeRefDS(_3674);
    _3674 = NOVALUE;
L1: 

    /**     return source_data*/
    DeRef(_new_data_6869);
    return _source_data_6863;
    ;
}
int minsize() __attribute__ ((alias ("_23minsize")));



// 0x25C6E6C5
