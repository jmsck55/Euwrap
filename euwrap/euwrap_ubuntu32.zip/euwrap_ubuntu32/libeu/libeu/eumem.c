// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _28malloc(int _mem_struct_p_10769, int _cleanup_p_10770)
{
    int _temp__10771 = NOVALUE;
    int _6097 = NOVALUE;
    int _6095 = NOVALUE;
    int _6094 = NOVALUE;
    int _6093 = NOVALUE;
    int _6089 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_cleanup_p_10770)) {
        _1 = (long)(DBL_PTR(_cleanup_p_10770)->dbl);
        DeRefDS(_cleanup_p_10770);
        _cleanup_p_10770 = _1;
    }

    /** 	if atom(mem_struct_p) then*/
    _6089 = IS_ATOM(_mem_struct_p_10769);
    if (_6089 == 0)
    {
        _6089 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _6089 = NOVALUE;
    }

    /** 		mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_10769;
    _mem_struct_p_10769 = Repeat(0, _mem_struct_p_10769);
    DeRef(_0);
L1: 

    /** 	if ram_free_list = 0 then*/
    if (_28ram_free_list_10765 != 0)
    goto L2; // [22] 72

    /** 		ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_10769);
    Append(&_28ram_space_10764, _28ram_space_10764, _mem_struct_p_10769);

    /** 		if cleanup_p then*/
    if (_cleanup_p_10770 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** 			return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_28ram_space_10764)){
            _6093 = SEQ_PTR(_28ram_space_10764)->length;
    }
    else {
        _6093 = 1;
    }
    _6094 = NewDouble( (double) _6093 );
    _1 = (int) _00[_28free_rid_10766].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_28free_rid_10766].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _28free_rid_10766;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6094)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6094)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6094)) ){
        DeRefDS(_6094);
        _6094 = NewDouble( DBL_PTR(_6094)->dbl );
    }
    DBL_PTR(_6094)->cleanup = (cleanup_ptr)_1;
    _6093 = NOVALUE;
    DeRef(_mem_struct_p_10769);
    return _6094;
    goto L4; // [56] 71
L3: 

    /** 			return length(ram_space)*/
    if (IS_SEQUENCE(_28ram_space_10764)){
            _6095 = SEQ_PTR(_28ram_space_10764)->length;
    }
    else {
        _6095 = 1;
    }
    DeRef(_mem_struct_p_10769);
    DeRef(_6094);
    _6094 = NOVALUE;
    return _6095;
L4: 
L2: 

    /** 	temp_ = ram_free_list*/
    _temp__10771 = _28ram_free_list_10765;

    /** 	ram_free_list = ram_space[temp_]*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    _28ram_free_list_10765 = (int)*(((s1_ptr)_2)->base + _temp__10771);
    if (!IS_ATOM_INT(_28ram_free_list_10765))
    _28ram_free_list_10765 = (long)DBL_PTR(_28ram_free_list_10765)->dbl;

    /** 	ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_10769);
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp__10771);
    _1 = *(int *)_2;
    *(int *)_2 = _mem_struct_p_10769;
    DeRef(_1);

    /** 	if cleanup_p then*/
    if (_cleanup_p_10770 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** 		return delete_routine( temp_, free_rid )*/
    _6097 = NewDouble( (double) _temp__10771 );
    _1 = (int) _00[_28free_rid_10766].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_28free_rid_10766].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _28free_rid_10766;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_6097)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_6097)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_6097)) ){
        DeRefDS(_6097);
        _6097 = NewDouble( DBL_PTR(_6097)->dbl );
    }
    DBL_PTR(_6097)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_10769);
    DeRef(_6094);
    _6094 = NOVALUE;
    return _6097;
    goto L6; // [112] 122
L5: 

    /** 		return temp_*/
    DeRef(_mem_struct_p_10769);
    DeRef(_6094);
    _6094 = NOVALUE;
    DeRef(_6097);
    _6097 = NOVALUE;
    return _temp__10771;
L6: 
    ;
}


void _28free(int _mem_p_10789)
{
    int _6099 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10789, 1)){
        goto L1; // [3] 11
    }
    DeRef(_mem_p_10789);
    return;
L1: 

    /** 	if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_28ram_space_10764)){
            _6099 = SEQ_PTR(_28ram_space_10764)->length;
    }
    else {
        _6099 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10789, _6099)){
        _6099 = NOVALUE;
        goto L2; // [18] 26
    }
    _6099 = NOVALUE;
    DeRef(_mem_p_10789);
    return;
L2: 

    /** 	ram_space[mem_p] = ram_free_list*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_10789))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10789)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _mem_p_10789);
    _1 = *(int *)_2;
    *(int *)_2 = _28ram_free_list_10765;
    DeRef(_1);

    /** 	ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_10789))
    _28ram_free_list_10765 = e_floor(_mem_p_10789);
    else
    _28ram_free_list_10765 = unary_op(FLOOR, _mem_p_10789);
    if (!IS_ATOM_INT(_28ram_free_list_10765)) {
        _1 = (long)(DBL_PTR(_28ram_free_list_10765)->dbl);
        DeRefDS(_28ram_free_list_10765);
        _28ram_free_list_10765 = _1;
    }

    /** end procedure*/
    DeRef(_mem_p_10789);
    return;
    ;
}


int _28valid(int _mem_p_10799, int _mem_struct_p_10800)
{
    int _6113 = NOVALUE;
    int _6112 = NOVALUE;
    int _6110 = NOVALUE;
    int _6109 = NOVALUE;
    int _6108 = NOVALUE;
    int _6106 = NOVALUE;
    int _6103 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(mem_p) then return 0 end if*/
    if (IS_ATOM_INT(_mem_p_10799))
    _6103 = 1;
    else if (IS_ATOM_DBL(_mem_p_10799))
    _6103 = IS_ATOM_INT(DoubleToInt(_mem_p_10799));
    else
    _6103 = 0;
    if (_6103 != 0)
    goto L1; // [6] 14
    _6103 = NOVALUE;
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 0;
L1: 

    /** 	if mem_p < 1 then return 0 end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10799, 1)){
        goto L2; // [16] 25
    }
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 0;
L2: 

    /** 	if mem_p > length(ram_space) then return 0 end if*/
    if (IS_SEQUENCE(_28ram_space_10764)){
            _6106 = SEQ_PTR(_28ram_space_10764)->length;
    }
    else {
        _6106 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10799, _6106)){
        _6106 = NOVALUE;
        goto L3; // [32] 41
    }
    _6106 = NOVALUE;
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 0;
L3: 

    /** 	if sequence(mem_struct_p) then return 1 end if*/
    _6108 = IS_SEQUENCE(_mem_struct_p_10800);
    if (_6108 == 0)
    {
        _6108 = NOVALUE;
        goto L4; // [46] 54
    }
    else{
        _6108 = NOVALUE;
    }
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 1;
L4: 

    /** 	if atom(ram_space[mem_p]) then */
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_mem_p_10799)){
        _6109 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10799)->dbl));
    }
    else{
        _6109 = (int)*(((s1_ptr)_2)->base + _mem_p_10799);
    }
    _6110 = IS_ATOM(_6109);
    _6109 = NOVALUE;
    if (_6110 == 0)
    {
        _6110 = NOVALUE;
        goto L5; // [65] 88
    }
    else{
        _6110 = NOVALUE;
    }

    /** 		if mem_struct_p >= 0 then*/
    if (binary_op_a(LESS, _mem_struct_p_10800, 0)){
        goto L6; // [70] 81
    }

    /** 			return 0*/
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 0;
L6: 

    /** 		return 1*/
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    return 1;
L5: 

    /** 	if length(ram_space[mem_p]) != mem_struct_p then*/
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!IS_ATOM_INT(_mem_p_10799)){
        _6112 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10799)->dbl));
    }
    else{
        _6112 = (int)*(((s1_ptr)_2)->base + _mem_p_10799);
    }
    if (IS_SEQUENCE(_6112)){
            _6113 = SEQ_PTR(_6112)->length;
    }
    else {
        _6113 = 1;
    }
    _6112 = NOVALUE;
    if (binary_op_a(EQUALS, _6113, _mem_struct_p_10800)){
        _6113 = NOVALUE;
        goto L7; // [99] 110
    }
    _6113 = NOVALUE;

    /** 		return 0*/
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    _6112 = NOVALUE;
    return 0;
L7: 

    /** 	return 1*/
    DeRef(_mem_p_10799);
    DeRef(_mem_struct_p_10800);
    _6112 = NOVALUE;
    return 1;
    ;
}



// 0xA747727D
