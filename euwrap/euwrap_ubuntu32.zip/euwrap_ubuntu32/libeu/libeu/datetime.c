// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _12gmtime(int _time_3330)
{
    int _ret_3331 = NOVALUE;
    int _timep_3332 = NOVALUE;
    int _tm_p_3333 = NOVALUE;
    int _n_3334 = NOVALUE;
    int _1651 = NOVALUE;
    int _1650 = NOVALUE;
    int _1647 = NOVALUE;
    int _0, _1, _2;
    

    /** 	timep = machine:allocate(4)*/
    _0 = _timep_3332;
    _timep_3332 = _14allocate(4, 0);
    DeRef(_0);

    /** 	poke4(timep, time)*/
    if (IS_ATOM_INT(_timep_3332)){
        poke4_addr = (unsigned long *)_timep_3332;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_timep_3332)->dbl);
    }
    if (IS_ATOM_INT(_time_3330)) {
        *poke4_addr = (unsigned long)_time_3330;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_time_3330)->dbl;
    }

    /** 	tm_p = c_func(gmtime_, {timep})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_timep_3332);
    *((int *)(_2+4)) = _timep_3332;
    _1647 = MAKE_SEQ(_1);
    DeRef(_tm_p_3333);
    _tm_p_3333 = call_c(1, _12gmtime__3303, _1647);
    DeRefDS(_1647);
    _1647 = NOVALUE;

    /** 	machine:free(timep)*/
    Ref(_timep_3332);
    _14free(_timep_3332);

    /** 	ret = repeat(0, 9)*/
    DeRef(_ret_3331);
    _ret_3331 = Repeat(0, 9);

    /** 	n = 0*/
    _n_3334 = 0;

    /** 	for i = 1 to 9 do*/
    {
        int _i_3340;
        _i_3340 = 1;
L1: 
        if (_i_3340 > 9){
            goto L2; // [44] 77
        }

        /** 		ret[i] = peek4s(tm_p+n)*/
        if (IS_ATOM_INT(_tm_p_3333)) {
            _1650 = _tm_p_3333 + _n_3334;
            if ((long)((unsigned long)_1650 + (unsigned long)HIGH_BITS) >= 0) 
            _1650 = NewDouble((double)_1650);
        }
        else {
            _1650 = NewDouble(DBL_PTR(_tm_p_3333)->dbl + (double)_n_3334);
        }
        if (IS_ATOM_INT(_1650)) {
            _1651 = *(unsigned long *)_1650;
            if (_1651 < MININT || _1651 > MAXINT)
            _1651 = NewDouble((double)(long)_1651);
        }
        else {
            _1651 = *(unsigned long *)(unsigned long)(DBL_PTR(_1650)->dbl);
            if (_1651 < MININT || _1651 > MAXINT)
            _1651 = NewDouble((double)(long)_1651);
        }
        DeRef(_1650);
        _1650 = NOVALUE;
        _2 = (int)SEQ_PTR(_ret_3331);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_3331 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3340);
        _1 = *(int *)_2;
        *(int *)_2 = _1651;
        if( _1 != _1651 ){
            DeRef(_1);
        }
        _1651 = NOVALUE;

        /** 		n = n + 4*/
        _n_3334 = _n_3334 + 4;

        /** 	end for*/
        _i_3340 = _i_3340 + 1;
        goto L1; // [72] 51
L2: 
        ;
    }

    /** 	return ret*/
    DeRef(_time_3330);
    DeRef(_timep_3332);
    DeRef(_tm_p_3333);
    return _ret_3331;
    ;
}


int _12tolower(int _x_3357)
{
    int _1664 = NOVALUE;
    int _1663 = NOVALUE;
    int _1662 = NOVALUE;
    int _1661 = NOVALUE;
    int _1660 = NOVALUE;
    int _1659 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return x + (x >= 'A' and x <= 'Z') * ('a' - 'A')*/
    _1659 = binary_op(GREATEREQ, _x_3357, 65);
    _1660 = binary_op(LESSEQ, _x_3357, 90);
    _1661 = binary_op(AND, _1659, _1660);
    DeRefDS(_1659);
    _1659 = NOVALUE;
    DeRefDS(_1660);
    _1660 = NOVALUE;
    _1662 = 32;
    _1663 = binary_op(MULTIPLY, _1661, 32);
    DeRefDS(_1661);
    _1661 = NOVALUE;
    _1662 = NOVALUE;
    _1664 = binary_op(PLUS, _x_3357, _1663);
    DeRefDS(_1663);
    _1663 = NOVALUE;
    DeRefDS(_x_3357);
    return _1664;
    ;
}


int _12isLeap(int _year_3366)
{
    int _ly_3367 = NOVALUE;
    int _1682 = NOVALUE;
    int _1681 = NOVALUE;
    int _1680 = NOVALUE;
    int _1679 = NOVALUE;
    int _1678 = NOVALUE;
    int _1677 = NOVALUE;
    int _1676 = NOVALUE;
    int _1675 = NOVALUE;
    int _1674 = NOVALUE;
    int _1671 = NOVALUE;
    int _1669 = NOVALUE;
    int _1668 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3366)) {
        _1 = (long)(DBL_PTR(_year_3366)->dbl);
        DeRefDS(_year_3366);
        _year_3366 = _1;
    }

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _1668 = MAKE_SEQ(_1);
    _1669 = binary_op(REMAINDER, _year_3366, _1668);
    DeRefDS(_1668);
    _1668 = NOVALUE;
    DeRefi(_ly_3367);
    _ly_3367 = binary_op(EQUALS, _1669, 0);
    DeRefDS(_1669);
    _1669 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_3367);
    _1671 = (int)*(((s1_ptr)_2)->base + 1);
    if (_1671 != 0)
    goto L1; // [29] 37
    _1671 = NOVALUE;
    DeRefDSi(_ly_3367);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_3366 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_3367);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_3367);
    _1674 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_3367);
    _1675 = (int)*(((s1_ptr)_2)->base + 2);
    _1676 = _1674 - _1675;
    if ((long)((unsigned long)_1676 +(unsigned long) HIGH_BITS) >= 0){
        _1676 = NewDouble((double)_1676);
    }
    _1674 = NOVALUE;
    _1675 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3367);
    _1677 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1676)) {
        _1678 = _1676 + _1677;
        if ((long)((unsigned long)_1678 + (unsigned long)HIGH_BITS) >= 0) 
        _1678 = NewDouble((double)_1678);
    }
    else {
        _1678 = NewDouble(DBL_PTR(_1676)->dbl + (double)_1677);
    }
    DeRef(_1676);
    _1676 = NOVALUE;
    _1677 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3367);
    _1679 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1678)) {
        _1680 = _1678 - _1679;
        if ((long)((unsigned long)_1680 +(unsigned long) HIGH_BITS) >= 0){
            _1680 = NewDouble((double)_1680);
        }
    }
    else {
        _1680 = NewDouble(DBL_PTR(_1678)->dbl - (double)_1679);
    }
    DeRef(_1678);
    _1678 = NOVALUE;
    _1679 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_3367);
    _1681 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1680)) {
        _1682 = _1680 + _1681;
        if ((long)((unsigned long)_1682 + (unsigned long)HIGH_BITS) >= 0) 
        _1682 = NewDouble((double)_1682);
    }
    else {
        _1682 = NewDouble(DBL_PTR(_1680)->dbl + (double)_1681);
    }
    DeRef(_1680);
    _1680 = NOVALUE;
    _1681 = NOVALUE;
    DeRefDSi(_ly_3367);
    return _1682;
L3: 
    ;
}


int _12daysInMonth(int _year_3391, int _month_3392)
{
    int _1690 = NOVALUE;
    int _1689 = NOVALUE;
    int _1688 = NOVALUE;
    int _1687 = NOVALUE;
    int _1685 = NOVALUE;
    int _1684 = NOVALUE;
    int _1683 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3391)) {
        _1 = (long)(DBL_PTR(_year_3391)->dbl);
        DeRefDS(_year_3391);
        _year_3391 = _1;
    }
    if (!IS_ATOM_INT(_month_3392)) {
        _1 = (long)(DBL_PTR(_month_3392)->dbl);
        DeRefDS(_month_3392);
        _month_3392 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1683 = (_year_3391 == 1752);
    if (_1683 == 0) {
        goto L1; // [11] 32
    }
    _1685 = (_month_3392 == 9);
    if (_1685 == 0)
    {
        DeRef(_1685);
        _1685 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_1685);
        _1685 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_1683);
    _1683 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_3392 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_12DaysPerMonth_3348);
    _1687 = (int)*(((s1_ptr)_2)->base + _month_3392);
    Ref(_1687);
    DeRef(_1683);
    _1683 = NOVALUE;
    return _1687;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_12DaysPerMonth_3348);
    _1688 = (int)*(((s1_ptr)_2)->base + _month_3392);
    _1689 = _12isLeap(_year_3391);
    if (IS_ATOM_INT(_1688) && IS_ATOM_INT(_1689)) {
        _1690 = _1688 + _1689;
        if ((long)((unsigned long)_1690 + (unsigned long)HIGH_BITS) >= 0) 
        _1690 = NewDouble((double)_1690);
    }
    else {
        _1690 = binary_op(PLUS, _1688, _1689);
    }
    _1688 = NOVALUE;
    DeRef(_1689);
    _1689 = NOVALUE;
    DeRef(_1683);
    _1683 = NOVALUE;
    _1687 = NOVALUE;
    return _1690;
L2: 
    ;
}


int _12julianDayOfYear(int _ymd_3415)
{
    int _year_3416 = NOVALUE;
    int _month_3417 = NOVALUE;
    int _day_3418 = NOVALUE;
    int _d_3419 = NOVALUE;
    int _1706 = NOVALUE;
    int _1705 = NOVALUE;
    int _1704 = NOVALUE;
    int _1701 = NOVALUE;
    int _1700 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3415);
    _year_3416 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3416)){
        _year_3416 = (long)DBL_PTR(_year_3416)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_3415);
    _month_3417 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_3417)){
        _month_3417 = (long)DBL_PTR(_month_3417)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_3415);
    _day_3418 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_3418)){
        _day_3418 = (long)DBL_PTR(_day_3418)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_3417 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_3415);
    return _day_3418;
L1: 

    /** 	d = 0*/
    _d_3419 = 0;

    /** 	for i = 1 to month - 1 do*/
    _1700 = _month_3417 - 1;
    if ((long)((unsigned long)_1700 +(unsigned long) HIGH_BITS) >= 0){
        _1700 = NewDouble((double)_1700);
    }
    {
        int _i_3426;
        _i_3426 = 1;
L2: 
        if (binary_op_a(GREATER, _i_3426, _1700)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_3426);
        _1701 = _12daysInMonth(_year_3416, _i_3426);
        if (IS_ATOM_INT(_1701)) {
            _d_3419 = _d_3419 + _1701;
        }
        else {
            _d_3419 = binary_op(PLUS, _d_3419, _1701);
        }
        DeRef(_1701);
        _1701 = NOVALUE;
        if (!IS_ATOM_INT(_d_3419)) {
            _1 = (long)(DBL_PTR(_d_3419)->dbl);
            DeRefDS(_d_3419);
            _d_3419 = _1;
        }

        /** 	end for*/
        _0 = _i_3426;
        if (IS_ATOM_INT(_i_3426)) {
            _i_3426 = _i_3426 + 1;
            if ((long)((unsigned long)_i_3426 +(unsigned long) HIGH_BITS) >= 0){
                _i_3426 = NewDouble((double)_i_3426);
            }
        }
        else {
            _i_3426 = binary_op_a(PLUS, _i_3426, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_3426);
    }

    /** 	d += day*/
    _d_3419 = _d_3419 + _day_3418;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1704 = (_year_3416 == 1752);
    if (_1704 == 0) {
        goto L4; // [86] 128
    }
    _1706 = (_month_3417 == 9);
    if (_1706 == 0)
    {
        DeRef(_1706);
        _1706 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1706);
        _1706 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_3418 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_3419 = _d_3419 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_3418 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_3415);
    DeRef(_1700);
    _1700 = NOVALUE;
    DeRef(_1704);
    _1704 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_3415);
    DeRef(_1700);
    _1700 = NOVALUE;
    DeRef(_1704);
    _1704 = NOVALUE;
    return _d_3419;
    ;
}


int _12julianDay(int _ymd_3442)
{
    int _year_3443 = NOVALUE;
    int _j_3444 = NOVALUE;
    int _greg00_3445 = NOVALUE;
    int _1735 = NOVALUE;
    int _1732 = NOVALUE;
    int _1729 = NOVALUE;
    int _1728 = NOVALUE;
    int _1727 = NOVALUE;
    int _1726 = NOVALUE;
    int _1725 = NOVALUE;
    int _1724 = NOVALUE;
    int _1723 = NOVALUE;
    int _1722 = NOVALUE;
    int _1720 = NOVALUE;
    int _1719 = NOVALUE;
    int _1718 = NOVALUE;
    int _1717 = NOVALUE;
    int _1716 = NOVALUE;
    int _1715 = NOVALUE;
    int _1714 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_3442);
    _year_3443 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_3443)){
        _year_3443 = (long)DBL_PTR(_year_3443)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_3442);
    _j_3444 = _12julianDayOfYear(_ymd_3442);
    if (!IS_ATOM_INT(_j_3444)) {
        _1 = (long)(DBL_PTR(_j_3444)->dbl);
        DeRefDS(_j_3444);
        _j_3444 = _1;
    }

    /** 	year  -= 1*/
    _year_3443 = _year_3443 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_3445 = _year_3443 - 1700;

    /** 	j += (*/
    if (_year_3443 <= INT15 && _year_3443 >= -INT15)
    _1714 = 365 * _year_3443;
    else
    _1714 = NewDouble(365 * (double)_year_3443);
    if (4 > 0 && _year_3443 >= 0) {
        _1715 = _year_3443 / 4;
    }
    else {
        temp_dbl = floor((double)_year_3443 / (double)4);
        _1715 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_1714)) {
        _1716 = _1714 + _1715;
        if ((long)((unsigned long)_1716 + (unsigned long)HIGH_BITS) >= 0) 
        _1716 = NewDouble((double)_1716);
    }
    else {
        _1716 = NewDouble(DBL_PTR(_1714)->dbl + (double)_1715);
    }
    DeRef(_1714);
    _1714 = NOVALUE;
    _1715 = NOVALUE;
    _1717 = (_greg00_3445 > 0);
    if (100 > 0 && _greg00_3445 >= 0) {
        _1718 = _greg00_3445 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_3445 / (double)100);
        _1718 = (long)temp_dbl;
    }
    _1719 = - _1718;
    _1720 = (_greg00_3445 % 400) ? NewDouble((double)_greg00_3445 / 400) : (_greg00_3445 / 400);
    if (IS_ATOM_INT(_1720)) {
        _1722 = NewDouble((double)_1720 + DBL_PTR(_1721)->dbl);
    }
    else {
        _1722 = NewDouble(DBL_PTR(_1720)->dbl + DBL_PTR(_1721)->dbl);
    }
    DeRef(_1720);
    _1720 = NOVALUE;
    _1723 = unary_op(FLOOR, _1722);
    DeRefDS(_1722);
    _1722 = NOVALUE;
    if (IS_ATOM_INT(_1723)) {
        _1724 = _1719 + _1723;
        if ((long)((unsigned long)_1724 + (unsigned long)HIGH_BITS) >= 0) 
        _1724 = NewDouble((double)_1724);
    }
    else {
        _1724 = NewDouble((double)_1719 + DBL_PTR(_1723)->dbl);
    }
    _1719 = NOVALUE;
    DeRef(_1723);
    _1723 = NOVALUE;
    if (IS_ATOM_INT(_1724)) {
        if (_1724 <= INT15 && _1724 >= -INT15)
        _1725 = _1717 * _1724;
        else
        _1725 = NewDouble(_1717 * (double)_1724);
    }
    else {
        _1725 = NewDouble((double)_1717 * DBL_PTR(_1724)->dbl);
    }
    _1717 = NOVALUE;
    DeRef(_1724);
    _1724 = NOVALUE;
    if (IS_ATOM_INT(_1716) && IS_ATOM_INT(_1725)) {
        _1726 = _1716 + _1725;
        if ((long)((unsigned long)_1726 + (unsigned long)HIGH_BITS) >= 0) 
        _1726 = NewDouble((double)_1726);
    }
    else {
        if (IS_ATOM_INT(_1716)) {
            _1726 = NewDouble((double)_1716 + DBL_PTR(_1725)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1725)) {
                _1726 = NewDouble(DBL_PTR(_1716)->dbl + (double)_1725);
            }
            else
            _1726 = NewDouble(DBL_PTR(_1716)->dbl + DBL_PTR(_1725)->dbl);
        }
    }
    DeRef(_1716);
    _1716 = NOVALUE;
    DeRef(_1725);
    _1725 = NOVALUE;
    _1727 = (_year_3443 >= 1752);
    _1728 = 11 * _1727;
    _1727 = NOVALUE;
    if (IS_ATOM_INT(_1726)) {
        _1729 = _1726 - _1728;
        if ((long)((unsigned long)_1729 +(unsigned long) HIGH_BITS) >= 0){
            _1729 = NewDouble((double)_1729);
        }
    }
    else {
        _1729 = NewDouble(DBL_PTR(_1726)->dbl - (double)_1728);
    }
    DeRef(_1726);
    _1726 = NOVALUE;
    _1728 = NOVALUE;
    if (IS_ATOM_INT(_1729)) {
        _j_3444 = _j_3444 + _1729;
    }
    else {
        _j_3444 = NewDouble((double)_j_3444 + DBL_PTR(_1729)->dbl);
    }
    DeRef(_1729);
    _1729 = NOVALUE;
    if (!IS_ATOM_INT(_j_3444)) {
        _1 = (long)(DBL_PTR(_j_3444)->dbl);
        DeRefDS(_j_3444);
        _j_3444 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_3443 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_3443 >= 0) {
        _1732 = _year_3443 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_3443 / (double)3200);
        _1732 = (long)temp_dbl;
    }
    _j_3444 = _j_3444 - _1732;
    _1732 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_3443 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_3443 >= 0) {
        _1735 = _year_3443 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_3443 / (double)80000);
        _1735 = (long)temp_dbl;
    }
    _j_3444 = _j_3444 + _1735;
    _1735 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_3442);
    DeRef(_1718);
    _1718 = NOVALUE;
    return _j_3444;
    ;
}


int _12julianDate(int _j_3477)
{
    int _year_3478 = NOVALUE;
    int _doy_3479 = NOVALUE;
    int _daysInYear_1__tmp_at83_3501 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_83_3500 = NOVALUE;
    int _daysInYear_1__tmp_at126_3506 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_126_3505 = NOVALUE;
    int _daysInYear_1__tmp_at159_3510 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_159_3509 = NOVALUE;
    int _1768 = NOVALUE;
    int _1767 = NOVALUE;
    int _1766 = NOVALUE;
    int _1765 = NOVALUE;
    int _1763 = NOVALUE;
    int _1761 = NOVALUE;
    int _1760 = NOVALUE;
    int _1759 = NOVALUE;
    int _1757 = NOVALUE;
    int _1749 = NOVALUE;
    int _1748 = NOVALUE;
    int _1747 = NOVALUE;
    int _1745 = NOVALUE;
    int _1744 = NOVALUE;
    int _1742 = NOVALUE;
    int _1740 = NOVALUE;
    int _1739 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if j >= 0 then*/
    if (_j_3477 < 0)
    goto L1; // [5] 26

    /** 		year = floor(j / (12 * 30.43687604)) + 1*/
    _1739 = NewDouble((double)12 * DBL_PTR(_1738)->dbl);
    _2 = binary_op(DIVIDE, _j_3477, _1739);
    _1740 = unary_op(FLOOR, _2);
    DeRef(_2);
    DeRefDS(_1739);
    _1739 = NOVALUE;
    if (IS_ATOM_INT(_1740)) {
        _year_3478 = _1740 + 1;
    }
    else
    { // coercing _year_3478 to an integer 1
        _year_3478 = 1+(long)(DBL_PTR(_1740)->dbl);
        if( !IS_ATOM_INT(_year_3478) ){
            _year_3478 = (object)DBL_PTR(_year_3478)->dbl;
        }
    }
    DeRef(_1740);
    _1740 = NOVALUE;
    goto L2; // [23] 43
L1: 

    /** 		year = -floor(-j / 365.25) + 1*/
    if ((unsigned long)_j_3477 == 0xC0000000)
    _1742 = (int)NewDouble((double)-0xC0000000);
    else
    _1742 = - _j_3477;
    _2 = binary_op(DIVIDE, _1742, _1743);
    _1744 = unary_op(FLOOR, _2);
    DeRef(_2);
    DeRef(_1742);
    _1742 = NOVALUE;
    if (IS_ATOM_INT(_1744)) {
        if ((unsigned long)_1744 == 0xC0000000)
        _1745 = (int)NewDouble((double)-0xC0000000);
        else
        _1745 = - _1744;
    }
    else {
        _1745 = unary_op(UMINUS, _1744);
    }
    DeRef(_1744);
    _1744 = NOVALUE;
    if (IS_ATOM_INT(_1745)) {
        _year_3478 = _1745 + 1;
    }
    else
    { // coercing _year_3478 to an integer 1
        _year_3478 = 1+(long)(DBL_PTR(_1745)->dbl);
        if( !IS_ATOM_INT(_year_3478) ){
            _year_3478 = (object)DBL_PTR(_year_3478)->dbl;
        }
    }
    DeRef(_1745);
    _1745 = NOVALUE;
L2: 

    /** 	doy = j - (julianDay({year, 1, 1}) - 1) -- = j - last day of prev year*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3478;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 1;
    _1747 = MAKE_SEQ(_1);
    _1748 = _12julianDay(_1747);
    _1747 = NOVALUE;
    if (IS_ATOM_INT(_1748)) {
        _1749 = _1748 - 1;
        if ((long)((unsigned long)_1749 +(unsigned long) HIGH_BITS) >= 0){
            _1749 = NewDouble((double)_1749);
        }
    }
    else {
        _1749 = binary_op(MINUS, _1748, 1);
    }
    DeRef(_1748);
    _1748 = NOVALUE;
    if (IS_ATOM_INT(_1749)) {
        _doy_3479 = _j_3477 - _1749;
    }
    else {
        _doy_3479 = binary_op(MINUS, _j_3477, _1749);
    }
    DeRef(_1749);
    _1749 = NOVALUE;
    if (!IS_ATOM_INT(_doy_3479)) {
        _1 = (long)(DBL_PTR(_doy_3479)->dbl);
        DeRefDS(_doy_3479);
        _doy_3479 = _1;
    }

    /** 	while doy <= 0 do -- we guessed too high for the year*/
L3: 
    if (_doy_3479 > 0)
    goto L4; // [72] 122

    /** 		year -= 1*/
    _year_3478 = _year_3478 - 1;

    /** 		doy += daysInYear(year)*/

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3478 != 1752)
    goto L5; // [86] 98

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_83_3500);
    _daysInYear_inlined_daysInYear_at_83_3500 = 355;
    goto L6; // [95] 109
L5: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at83_3501;
    _daysInYear_1__tmp_at83_3501 = _12isLeap(_year_3478);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_83_3500);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at83_3501)) {
        _daysInYear_inlined_daysInYear_at_83_3500 = 365 + _daysInYear_1__tmp_at83_3501;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_83_3500 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_83_3500 = NewDouble((double)_daysInYear_inlined_daysInYear_at_83_3500);
    }
    else {
        _daysInYear_inlined_daysInYear_at_83_3500 = binary_op(PLUS, 365, _daysInYear_1__tmp_at83_3501);
    }
L6: 
    DeRef(_daysInYear_1__tmp_at83_3501);
    _daysInYear_1__tmp_at83_3501 = NOVALUE;
    if (IS_ATOM_INT(_daysInYear_inlined_daysInYear_at_83_3500)) {
        _doy_3479 = _doy_3479 + _daysInYear_inlined_daysInYear_at_83_3500;
    }
    else {
        _doy_3479 = binary_op(PLUS, _doy_3479, _daysInYear_inlined_daysInYear_at_83_3500);
    }
    if (!IS_ATOM_INT(_doy_3479)) {
        _1 = (long)(DBL_PTR(_doy_3479)->dbl);
        DeRefDS(_doy_3479);
        _doy_3479 = _1;
    }

    /** 	end while*/
    goto L3; // [119] 72
L4: 

    /** 	while doy > daysInYear(year) do -- we guessed too low*/
L7: 

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3478 != 1752)
    goto L8; // [129] 141

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_126_3505);
    _daysInYear_inlined_daysInYear_at_126_3505 = 355;
    goto L9; // [138] 152
L8: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at126_3506;
    _daysInYear_1__tmp_at126_3506 = _12isLeap(_year_3478);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_126_3505);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at126_3506)) {
        _daysInYear_inlined_daysInYear_at_126_3505 = 365 + _daysInYear_1__tmp_at126_3506;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_126_3505 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_126_3505 = NewDouble((double)_daysInYear_inlined_daysInYear_at_126_3505);
    }
    else {
        _daysInYear_inlined_daysInYear_at_126_3505 = binary_op(PLUS, 365, _daysInYear_1__tmp_at126_3506);
    }
L9: 
    DeRef(_daysInYear_1__tmp_at126_3506);
    _daysInYear_1__tmp_at126_3506 = NOVALUE;
    if (binary_op_a(LESSEQ, _doy_3479, _daysInYear_inlined_daysInYear_at_126_3505)){
        goto LA; // [154] 204
    }

    /** 		doy -= daysInYear(year)*/

    /** 	if year = Gregorian_Reformation then*/
    if (_year_3478 != 1752)
    goto LB; // [162] 174

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_159_3509);
    _daysInYear_inlined_daysInYear_at_159_3509 = 355;
    goto LC; // [171] 185
LB: 

    /** 	return 365 + isLeap(year)*/
    _0 = _daysInYear_1__tmp_at159_3510;
    _daysInYear_1__tmp_at159_3510 = _12isLeap(_year_3478);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_159_3509);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at159_3510)) {
        _daysInYear_inlined_daysInYear_at_159_3509 = 365 + _daysInYear_1__tmp_at159_3510;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_159_3509 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_159_3509 = NewDouble((double)_daysInYear_inlined_daysInYear_at_159_3509);
    }
    else {
        _daysInYear_inlined_daysInYear_at_159_3509 = binary_op(PLUS, 365, _daysInYear_1__tmp_at159_3510);
    }
LC: 
    DeRef(_daysInYear_1__tmp_at159_3510);
    _daysInYear_1__tmp_at159_3510 = NOVALUE;
    if (IS_ATOM_INT(_daysInYear_inlined_daysInYear_at_159_3509)) {
        _doy_3479 = _doy_3479 - _daysInYear_inlined_daysInYear_at_159_3509;
    }
    else {
        _doy_3479 = binary_op(MINUS, _doy_3479, _daysInYear_inlined_daysInYear_at_159_3509);
    }
    if (!IS_ATOM_INT(_doy_3479)) {
        _1 = (long)(DBL_PTR(_doy_3479)->dbl);
        DeRefDS(_doy_3479);
        _doy_3479 = _1;
    }

    /** 		year += 1*/
    _year_3478 = _year_3478 + 1;

    /** 	end while*/
    goto L7; // [201] 127
LA: 

    /** 	if doy <= daysInMonth(year, 1) then*/
    _1757 = _12daysInMonth(_year_3478, 1);
    if (binary_op_a(GREATER, _doy_3479, _1757)){
        DeRef(_1757);
        _1757 = NOVALUE;
        goto LD; // [211] 228
    }
    DeRef(_1757);
    _1757 = NOVALUE;

    /** 		return {year, 1, doy}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3478;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _doy_3479;
    _1759 = MAKE_SEQ(_1);
    return _1759;
LD: 

    /** 	for month = 2 to 12 do*/
    {
        int _month_3518;
        _month_3518 = 2;
LE: 
        if (_month_3518 > 12){
            goto LF; // [230] 285
        }

        /** 		doy -= daysInMonth(year, month-1)*/
        _1760 = _month_3518 - 1;
        _1761 = _12daysInMonth(_year_3478, _1760);
        _1760 = NOVALUE;
        if (IS_ATOM_INT(_1761)) {
            _doy_3479 = _doy_3479 - _1761;
        }
        else {
            _doy_3479 = binary_op(MINUS, _doy_3479, _1761);
        }
        DeRef(_1761);
        _1761 = NOVALUE;
        if (!IS_ATOM_INT(_doy_3479)) {
            _1 = (long)(DBL_PTR(_doy_3479)->dbl);
            DeRefDS(_doy_3479);
            _doy_3479 = _1;
        }

        /** 		if doy <= daysInMonth(year, month) then*/
        _1763 = _12daysInMonth(_year_3478, _month_3518);
        if (binary_op_a(GREATER, _doy_3479, _1763)){
            DeRef(_1763);
            _1763 = NOVALUE;
            goto L10; // [261] 278
        }
        DeRef(_1763);
        _1763 = NOVALUE;

        /** 			return {year, month, doy}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _year_3478;
        *((int *)(_2+8)) = _month_3518;
        *((int *)(_2+12)) = _doy_3479;
        _1765 = MAKE_SEQ(_1);
        DeRef(_1759);
        _1759 = NOVALUE;
        return _1765;
L10: 

        /** 	end for*/
        _month_3518 = _month_3518 + 1;
        goto LE; // [280] 237
LF: 
        ;
    }

    /** 	return {year+1, 1, doy-31}*/
    _1766 = _year_3478 + 1;
    if (_1766 > MAXINT){
        _1766 = NewDouble((double)_1766);
    }
    _1767 = _doy_3479 - 31;
    if ((long)((unsigned long)_1767 +(unsigned long) HIGH_BITS) >= 0){
        _1767 = NewDouble((double)_1767);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1766;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _1767;
    _1768 = MAKE_SEQ(_1);
    _1767 = NOVALUE;
    _1766 = NOVALUE;
    DeRef(_1759);
    _1759 = NOVALUE;
    DeRef(_1765);
    _1765 = NOVALUE;
    return _1768;
    ;
}


int _12datetimeToSeconds(int _dt_3531)
{
    int _1778 = NOVALUE;
    int _1777 = NOVALUE;
    int _1776 = NOVALUE;
    int _1775 = NOVALUE;
    int _1774 = NOVALUE;
    int _1773 = NOVALUE;
    int _1772 = NOVALUE;
    int _1771 = NOVALUE;
    int _1770 = NOVALUE;
    int _1769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_3531);
    _1769 = _12julianDay(_dt_3531);
    if (IS_ATOM_INT(_1769)) {
        _1770 = NewDouble(_1769 * (double)86400);
    }
    else {
        _1770 = binary_op(MULTIPLY, _1769, 86400);
    }
    DeRef(_1769);
    _1769 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3531);
    _1771 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1771)) {
        if (_1771 == (short)_1771)
        _1772 = _1771 * 60;
        else
        _1772 = NewDouble(_1771 * (double)60);
    }
    else {
        _1772 = binary_op(MULTIPLY, _1771, 60);
    }
    _1771 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3531);
    _1773 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1772) && IS_ATOM_INT(_1773)) {
        _1774 = _1772 + _1773;
        if ((long)((unsigned long)_1774 + (unsigned long)HIGH_BITS) >= 0) 
        _1774 = NewDouble((double)_1774);
    }
    else {
        _1774 = binary_op(PLUS, _1772, _1773);
    }
    DeRef(_1772);
    _1772 = NOVALUE;
    _1773 = NOVALUE;
    if (IS_ATOM_INT(_1774)) {
        if (_1774 == (short)_1774)
        _1775 = _1774 * 60;
        else
        _1775 = NewDouble(_1774 * (double)60);
    }
    else {
        _1775 = binary_op(MULTIPLY, _1774, 60);
    }
    DeRef(_1774);
    _1774 = NOVALUE;
    if (IS_ATOM_INT(_1770) && IS_ATOM_INT(_1775)) {
        _1776 = _1770 + _1775;
        if ((long)((unsigned long)_1776 + (unsigned long)HIGH_BITS) >= 0) 
        _1776 = NewDouble((double)_1776);
    }
    else {
        _1776 = binary_op(PLUS, _1770, _1775);
    }
    DeRef(_1770);
    _1770 = NOVALUE;
    DeRef(_1775);
    _1775 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_3531);
    _1777 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1776) && IS_ATOM_INT(_1777)) {
        _1778 = _1776 + _1777;
        if ((long)((unsigned long)_1778 + (unsigned long)HIGH_BITS) >= 0) 
        _1778 = NewDouble((double)_1778);
    }
    else {
        _1778 = binary_op(PLUS, _1776, _1777);
    }
    DeRef(_1776);
    _1776 = NOVALUE;
    _1777 = NOVALUE;
    DeRef(_dt_3531);
    return _1778;
    ;
}


int _12secondsToDateTime(int _seconds_3544)
{
    int _days_3545 = NOVALUE;
    int _minutes_3546 = NOVALUE;
    int _hours_3547 = NOVALUE;
    int _1790 = NOVALUE;
    int _1789 = NOVALUE;
    int _1788 = NOVALUE;
    int _1786 = NOVALUE;
    int _1783 = NOVALUE;
    int _0, _1, _2;
    

    /** 	days = floor(seconds / DayLengthInSeconds)*/
    if (IS_ATOM_INT(_seconds_3544)) {
        if (86400 > 0 && _seconds_3544 >= 0) {
            _days_3545 = _seconds_3544 / 86400;
        }
        else {
            temp_dbl = floor((double)_seconds_3544 / (double)86400);
            _days_3545 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3544, 86400);
        _days_3545 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_days_3545)) {
        _1 = (long)(DBL_PTR(_days_3545)->dbl);
        DeRefDS(_days_3545);
        _days_3545 = _1;
    }

    /** 	seconds = remainder(seconds, DayLengthInSeconds)*/
    _0 = _seconds_3544;
    if (IS_ATOM_INT(_seconds_3544)) {
        _seconds_3544 = (_seconds_3544 % 86400);
    }
    else {
        temp_d.dbl = (double)86400;
        _seconds_3544 = Dremainder(DBL_PTR(_seconds_3544), &temp_d);
    }
    DeRef(_0);

    /** 		hours = floor( seconds / 3600 )*/
    if (IS_ATOM_INT(_seconds_3544)) {
        if (3600 > 0 && _seconds_3544 >= 0) {
            _hours_3547 = _seconds_3544 / 3600;
        }
        else {
            temp_dbl = floor((double)_seconds_3544 / (double)3600);
            _hours_3547 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3544, 3600);
        _hours_3547 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_hours_3547)) {
        _1 = (long)(DBL_PTR(_hours_3547)->dbl);
        DeRefDS(_hours_3547);
        _hours_3547 = _1;
    }

    /** 		seconds -= hours * 3600*/
    if (_hours_3547 == (short)_hours_3547)
    _1783 = _hours_3547 * 3600;
    else
    _1783 = NewDouble(_hours_3547 * (double)3600);
    _0 = _seconds_3544;
    if (IS_ATOM_INT(_seconds_3544) && IS_ATOM_INT(_1783)) {
        _seconds_3544 = _seconds_3544 - _1783;
        if ((long)((unsigned long)_seconds_3544 +(unsigned long) HIGH_BITS) >= 0){
            _seconds_3544 = NewDouble((double)_seconds_3544);
        }
    }
    else {
        if (IS_ATOM_INT(_seconds_3544)) {
            _seconds_3544 = NewDouble((double)_seconds_3544 - DBL_PTR(_1783)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1783)) {
                _seconds_3544 = NewDouble(DBL_PTR(_seconds_3544)->dbl - (double)_1783);
            }
            else
            _seconds_3544 = NewDouble(DBL_PTR(_seconds_3544)->dbl - DBL_PTR(_1783)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1783);
    _1783 = NOVALUE;

    /** 		minutes = floor( seconds / 60 )*/
    if (IS_ATOM_INT(_seconds_3544)) {
        if (60 > 0 && _seconds_3544 >= 0) {
            _minutes_3546 = _seconds_3544 / 60;
        }
        else {
            temp_dbl = floor((double)_seconds_3544 / (double)60);
            _minutes_3546 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _seconds_3544, 60);
        _minutes_3546 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_minutes_3546)) {
        _1 = (long)(DBL_PTR(_minutes_3546)->dbl);
        DeRefDS(_minutes_3546);
        _minutes_3546 = _1;
    }

    /** 		seconds -= minutes* 60*/
    if (_minutes_3546 == (short)_minutes_3546)
    _1786 = _minutes_3546 * 60;
    else
    _1786 = NewDouble(_minutes_3546 * (double)60);
    _0 = _seconds_3544;
    if (IS_ATOM_INT(_seconds_3544) && IS_ATOM_INT(_1786)) {
        _seconds_3544 = _seconds_3544 - _1786;
        if ((long)((unsigned long)_seconds_3544 +(unsigned long) HIGH_BITS) >= 0){
            _seconds_3544 = NewDouble((double)_seconds_3544);
        }
    }
    else {
        if (IS_ATOM_INT(_seconds_3544)) {
            _seconds_3544 = NewDouble((double)_seconds_3544 - DBL_PTR(_1786)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1786)) {
                _seconds_3544 = NewDouble(DBL_PTR(_seconds_3544)->dbl - (double)_1786);
            }
            else
            _seconds_3544 = NewDouble(DBL_PTR(_seconds_3544)->dbl - DBL_PTR(_1786)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_1786);
    _1786 = NOVALUE;

    /** 	return julianDate(days) & {hours, minutes, seconds}*/
    _1788 = _12julianDate(_days_3545);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _hours_3547;
    *((int *)(_2+8)) = _minutes_3546;
    Ref(_seconds_3544);
    *((int *)(_2+12)) = _seconds_3544;
    _1789 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_1788) && IS_ATOM(_1789)) {
    }
    else if (IS_ATOM(_1788) && IS_SEQUENCE(_1789)) {
        Ref(_1788);
        Prepend(&_1790, _1789, _1788);
    }
    else {
        Concat((object_ptr)&_1790, _1788, _1789);
        DeRef(_1788);
        _1788 = NOVALUE;
    }
    DeRef(_1788);
    _1788 = NOVALUE;
    DeRefDS(_1789);
    _1789 = NOVALUE;
    DeRef(_seconds_3544);
    return _1790;
    ;
}


int _12datetime(int _o_3625)
{
    int _1883 = NOVALUE;
    int _1881 = NOVALUE;
    int _1878 = NOVALUE;
    int _1876 = NOVALUE;
    int _1873 = NOVALUE;
    int _1871 = NOVALUE;
    int _1869 = NOVALUE;
    int _1868 = NOVALUE;
    int _1867 = NOVALUE;
    int _1866 = NOVALUE;
    int _1864 = NOVALUE;
    int _1862 = NOVALUE;
    int _1860 = NOVALUE;
    int _1858 = NOVALUE;
    int _1857 = NOVALUE;
    int _1856 = NOVALUE;
    int _1854 = NOVALUE;
    int _1853 = NOVALUE;
    int _1851 = NOVALUE;
    int _1850 = NOVALUE;
    int _1848 = NOVALUE;
    int _1847 = NOVALUE;
    int _1845 = NOVALUE;
    int _1844 = NOVALUE;
    int _1842 = NOVALUE;
    int _1841 = NOVALUE;
    int _1839 = NOVALUE;
    int _1838 = NOVALUE;
    int _1836 = NOVALUE;
    int _1835 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(o) then return 0 end if*/
    _1835 = IS_ATOM(_o_3625);
    if (_1835 == 0)
    {
        _1835 = NOVALUE;
        goto L1; // [6] 14
    }
    else{
        _1835 = NOVALUE;
    }
    DeRef(_o_3625);
    return 0;
L1: 

    /** 	if length(o) != 6 then return 0 end if*/
    if (IS_SEQUENCE(_o_3625)){
            _1836 = SEQ_PTR(_o_3625)->length;
    }
    else {
        _1836 = 1;
    }
    if (_1836 == 6)
    goto L2; // [19] 28
    DeRef(_o_3625);
    return 0;
L2: 

    /** 	if not integer(o[YEAR]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1838 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1838))
    _1839 = 1;
    else if (IS_ATOM_DBL(_1838))
    _1839 = IS_ATOM_INT(DoubleToInt(_1838));
    else
    _1839 = 0;
    _1838 = NOVALUE;
    if (_1839 != 0)
    goto L3; // [37] 45
    _1839 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L3: 

    /** 	if not integer(o[MONTH]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1841 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_1841))
    _1842 = 1;
    else if (IS_ATOM_DBL(_1841))
    _1842 = IS_ATOM_INT(DoubleToInt(_1841));
    else
    _1842 = 0;
    _1841 = NOVALUE;
    if (_1842 != 0)
    goto L4; // [54] 62
    _1842 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L4: 

    /** 	if not integer(o[DAY]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1844 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_1844))
    _1845 = 1;
    else if (IS_ATOM_DBL(_1844))
    _1845 = IS_ATOM_INT(DoubleToInt(_1844));
    else
    _1845 = 0;
    _1844 = NOVALUE;
    if (_1845 != 0)
    goto L5; // [71] 79
    _1845 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L5: 

    /** 	if not integer(o[HOUR]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1847 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1847))
    _1848 = 1;
    else if (IS_ATOM_DBL(_1847))
    _1848 = IS_ATOM_INT(DoubleToInt(_1847));
    else
    _1848 = 0;
    _1847 = NOVALUE;
    if (_1848 != 0)
    goto L6; // [88] 96
    _1848 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L6: 

    /** 	if not integer(o[MINUTE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1850 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1850))
    _1851 = 1;
    else if (IS_ATOM_DBL(_1850))
    _1851 = IS_ATOM_INT(DoubleToInt(_1850));
    else
    _1851 = 0;
    _1850 = NOVALUE;
    if (_1851 != 0)
    goto L7; // [105] 113
    _1851 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L7: 

    /** 	if not atom(o[SECOND]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1853 = (int)*(((s1_ptr)_2)->base + 6);
    _1854 = IS_ATOM(_1853);
    _1853 = NOVALUE;
    if (_1854 != 0)
    goto L8; // [122] 130
    _1854 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L8: 

    /** 	if not equal(o[1..3], {0,0,0}) then*/
    rhs_slice_target = (object_ptr)&_1856;
    RHS_Slice(_o_3625, 1, 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _1857 = MAKE_SEQ(_1);
    if (_1856 == _1857)
    _1858 = 1;
    else if (IS_ATOM_INT(_1856) && IS_ATOM_INT(_1857))
    _1858 = 0;
    else
    _1858 = (compare(_1856, _1857) == 0);
    DeRefDS(_1856);
    _1856 = NOVALUE;
    DeRefDS(_1857);
    _1857 = NOVALUE;
    if (_1858 != 0)
    goto L9; // [147] 224
    _1858 = NOVALUE;

    /** 		if o[MONTH] < 1 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1860 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _1860, 1)){
        _1860 = NOVALUE;
        goto LA; // [156] 165
    }
    _1860 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LA: 

    /** 		if o[MONTH] > 12 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1862 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _1862, 12)){
        _1862 = NOVALUE;
        goto LB; // [171] 180
    }
    _1862 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LB: 

    /** 		if o[DAY] < 1 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1864 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _1864, 1)){
        _1864 = NOVALUE;
        goto LC; // [186] 195
    }
    _1864 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LC: 

    /** 		if o[DAY] > daysInMonth(o[YEAR],o[MONTH]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1866 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_o_3625);
    _1867 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_o_3625);
    _1868 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1867);
    Ref(_1868);
    _1869 = _12daysInMonth(_1867, _1868);
    _1867 = NOVALUE;
    _1868 = NOVALUE;
    if (binary_op_a(LESSEQ, _1866, _1869)){
        _1866 = NOVALUE;
        DeRef(_1869);
        _1869 = NOVALUE;
        goto LD; // [214] 223
    }
    _1866 = NOVALUE;
    DeRef(_1869);
    _1869 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LD: 
L9: 

    /** 	if o[HOUR] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1871 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(GREATEREQ, _1871, 0)){
        _1871 = NOVALUE;
        goto LE; // [230] 239
    }
    _1871 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LE: 

    /** 	if o[HOUR] > 23 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1873 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(LESSEQ, _1873, 23)){
        _1873 = NOVALUE;
        goto LF; // [245] 254
    }
    _1873 = NOVALUE;
    DeRef(_o_3625);
    return 0;
LF: 

    /** 	if o[MINUTE] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1876 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(GREATEREQ, _1876, 0)){
        _1876 = NOVALUE;
        goto L10; // [260] 269
    }
    _1876 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L10: 

    /** 	if o[MINUTE] > 59 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1878 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _1878, 59)){
        _1878 = NOVALUE;
        goto L11; // [275] 284
    }
    _1878 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L11: 

    /** 	if o[SECOND] < 0 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1881 = (int)*(((s1_ptr)_2)->base + 6);
    if (binary_op_a(GREATEREQ, _1881, 0)){
        _1881 = NOVALUE;
        goto L12; // [290] 299
    }
    _1881 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L12: 

    /** 	if o[SECOND] >= 60 then return 0 end if*/
    _2 = (int)SEQ_PTR(_o_3625);
    _1883 = (int)*(((s1_ptr)_2)->base + 6);
    if (binary_op_a(LESS, _1883, 60)){
        _1883 = NOVALUE;
        goto L13; // [305] 314
    }
    _1883 = NOVALUE;
    DeRef(_o_3625);
    return 0;
L13: 

    /** 	return 1*/
    DeRef(_o_3625);
    return 1;
    ;
}


int _12from_date(int _src_3697)
{
    int _1893 = NOVALUE;
    int _1892 = NOVALUE;
    int _1891 = NOVALUE;
    int _1890 = NOVALUE;
    int _1889 = NOVALUE;
    int _1888 = NOVALUE;
    int _1887 = NOVALUE;
    int _1885 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_3697);
    _1885 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_1885)) {
        _1887 = _1885 + 1900;
        if ((long)((unsigned long)_1887 + (unsigned long)HIGH_BITS) >= 0) 
        _1887 = NewDouble((double)_1887);
    }
    else {
        _1887 = binary_op(PLUS, _1885, 1900);
    }
    _1885 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_3697);
    _1888 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_3697);
    _1889 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_3697);
    _1890 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_3697);
    _1891 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_3697);
    _1892 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1887;
    Ref(_1888);
    *((int *)(_2+8)) = _1888;
    Ref(_1889);
    *((int *)(_2+12)) = _1889;
    Ref(_1890);
    *((int *)(_2+16)) = _1890;
    Ref(_1891);
    *((int *)(_2+20)) = _1891;
    Ref(_1892);
    *((int *)(_2+24)) = _1892;
    _1893 = MAKE_SEQ(_1);
    _1892 = NOVALUE;
    _1891 = NOVALUE;
    _1890 = NOVALUE;
    _1889 = NOVALUE;
    _1888 = NOVALUE;
    _1887 = NOVALUE;
    DeRefDS(_src_3697);
    return _1893;
    ;
}
int from_date() __attribute__ ((alias ("_12from_date")));


int _12now()
{
    int _1895 = NOVALUE;
    int _1894 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return from_date(date())*/
    _1894 = Date();
    _1895 = _12from_date(_1894);
    _1894 = NOVALUE;
    return _1895;
    ;
}
int now() __attribute__ ((alias ("_12now")));


int _12now_gmt()
{
    int _time_1__tmp_at2_3716 = NOVALUE;
    int _time_inlined_time_at_2_3715 = NOVALUE;
    int _t1_3713 = NOVALUE;
    int _1905 = NOVALUE;
    int _1904 = NOVALUE;
    int _1903 = NOVALUE;
    int _1902 = NOVALUE;
    int _1901 = NOVALUE;
    int _1900 = NOVALUE;
    int _1899 = NOVALUE;
    int _1898 = NOVALUE;
    int _1897 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence t1 = gmtime(time())*/

    /** 	ifdef WINDOWS then*/

    /** 		return c_func(time_, {dll:NULL})*/
    _0 = _time_1__tmp_at2_3716;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _time_1__tmp_at2_3716 = MAKE_SEQ(_1);
    DeRefi(_0);
    DeRef(_time_inlined_time_at_2_3715);
    _time_inlined_time_at_2_3715 = call_c(1, _12time__3308, _time_1__tmp_at2_3716);
    DeRefi(_time_1__tmp_at2_3716);
    _time_1__tmp_at2_3716 = NOVALUE;
    Ref(_time_inlined_time_at_2_3715);
    _0 = _t1_3713;
    _t1_3713 = _12gmtime(_time_inlined_time_at_2_3715);
    DeRef(_0);

    /** 	return { */
    _2 = (int)SEQ_PTR(_t1_3713);
    _1897 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1897)) {
        _1898 = _1897 + 1900;
        if ((long)((unsigned long)_1898 + (unsigned long)HIGH_BITS) >= 0) 
        _1898 = NewDouble((double)_1898);
    }
    else {
        _1898 = binary_op(PLUS, _1897, 1900);
    }
    _1897 = NOVALUE;
    _2 = (int)SEQ_PTR(_t1_3713);
    _1899 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1899)) {
        _1900 = _1899 + 1;
        if (_1900 > MAXINT){
            _1900 = NewDouble((double)_1900);
        }
    }
    else
    _1900 = binary_op(PLUS, 1, _1899);
    _1899 = NOVALUE;
    _2 = (int)SEQ_PTR(_t1_3713);
    _1901 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_t1_3713);
    _1902 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_t1_3713);
    _1903 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_t1_3713);
    _1904 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1898;
    *((int *)(_2+8)) = _1900;
    Ref(_1901);
    *((int *)(_2+12)) = _1901;
    Ref(_1902);
    *((int *)(_2+16)) = _1902;
    Ref(_1903);
    *((int *)(_2+20)) = _1903;
    Ref(_1904);
    *((int *)(_2+24)) = _1904;
    _1905 = MAKE_SEQ(_1);
    _1904 = NOVALUE;
    _1903 = NOVALUE;
    _1902 = NOVALUE;
    _1901 = NOVALUE;
    _1900 = NOVALUE;
    _1898 = NOVALUE;
    DeRefDS(_t1_3713);
    return _1905;
    ;
}
int now_gmt() __attribute__ ((alias ("_12now_gmt")));


int _12new(int _year_3729, int _month_3730, int _day_3731, int _hour_3732, int _minute_3733, int _second_3734)
{
    int _d_3735 = NOVALUE;
    int _now_1__tmp_at41_3742 = NOVALUE;
    int _now_inlined_now_at_41_3741 = NOVALUE;
    int _1908 = NOVALUE;
    int _1907 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_3729)) {
        _1 = (long)(DBL_PTR(_year_3729)->dbl);
        DeRefDS(_year_3729);
        _year_3729 = _1;
    }
    if (!IS_ATOM_INT(_month_3730)) {
        _1 = (long)(DBL_PTR(_month_3730)->dbl);
        DeRefDS(_month_3730);
        _month_3730 = _1;
    }
    if (!IS_ATOM_INT(_day_3731)) {
        _1 = (long)(DBL_PTR(_day_3731)->dbl);
        DeRefDS(_day_3731);
        _day_3731 = _1;
    }
    if (!IS_ATOM_INT(_hour_3732)) {
        _1 = (long)(DBL_PTR(_hour_3732)->dbl);
        DeRefDS(_hour_3732);
        _hour_3732 = _1;
    }
    if (!IS_ATOM_INT(_minute_3733)) {
        _1 = (long)(DBL_PTR(_minute_3733)->dbl);
        DeRefDS(_minute_3733);
        _minute_3733 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_3735;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_3729;
    *((int *)(_2+8)) = _month_3730;
    *((int *)(_2+12)) = _day_3731;
    *((int *)(_2+16)) = _hour_3732;
    *((int *)(_2+20)) = _minute_3733;
    Ref(_second_3734);
    *((int *)(_2+24)) = _second_3734;
    _d_3735 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _1907 = MAKE_SEQ(_1);
    if (_d_3735 == _1907)
    _1908 = 1;
    else if (IS_ATOM_INT(_d_3735) && IS_ATOM_INT(_1907))
    _1908 = 0;
    else
    _1908 = (compare(_d_3735, _1907) == 0);
    DeRefDS(_1907);
    _1907 = NOVALUE;
    if (_1908 == 0)
    {
        _1908 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1908 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_3742);
    _now_1__tmp_at41_3742 = Date();
    RefDS(_now_1__tmp_at41_3742);
    _0 = _now_inlined_now_at_41_3741;
    _now_inlined_now_at_41_3741 = _12from_date(_now_1__tmp_at41_3742);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_3742);
    _now_1__tmp_at41_3742 = NOVALUE;
    DeRef(_second_3734);
    DeRef(_d_3735);
    return _now_inlined_now_at_41_3741;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_3734);
    return _d_3735;
L2: 
    ;
}


int _12new_time(int _hour_3746, int _minute_3747, int _second_3748)
{
    int _1909 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_hour_3746)) {
        _1 = (long)(DBL_PTR(_hour_3746)->dbl);
        DeRefDS(_hour_3746);
        _hour_3746 = _1;
    }
    if (!IS_ATOM_INT(_minute_3747)) {
        _1 = (long)(DBL_PTR(_minute_3747)->dbl);
        DeRefDS(_minute_3747);
        _minute_3747 = _1;
    }

    /** 	return new(0, 0, 0, hour, minute, second)*/
    Ref(_second_3748);
    _1909 = _12new(0, 0, 0, _hour_3746, _minute_3747, _second_3748);
    DeRef(_second_3748);
    return _1909;
    ;
}
int new_time() __attribute__ ((alias ("_12new_time")));


int _12weeks_day(int _dt_3752)
{
    int _1915 = NOVALUE;
    int _1914 = NOVALUE;
    int _1913 = NOVALUE;
    int _1911 = NOVALUE;
    int _1910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
    Ref(_dt_3752);
    _1910 = _12julianDay(_dt_3752);
    if (IS_ATOM_INT(_1910)) {
        _1911 = _1910 - 1;
        if ((long)((unsigned long)_1911 +(unsigned long) HIGH_BITS) >= 0){
            _1911 = NewDouble((double)_1911);
        }
    }
    else {
        _1911 = binary_op(MINUS, _1910, 1);
    }
    DeRef(_1910);
    _1910 = NOVALUE;
    if (IS_ATOM_INT(_1911)) {
        _1913 = _1911 + 4094;
        if ((long)((unsigned long)_1913 + (unsigned long)HIGH_BITS) >= 0) 
        _1913 = NewDouble((double)_1913);
    }
    else {
        _1913 = binary_op(PLUS, _1911, 4094);
    }
    DeRef(_1911);
    _1911 = NOVALUE;
    if (IS_ATOM_INT(_1913)) {
        _1914 = (_1913 % 7);
    }
    else {
        _1914 = binary_op(REMAINDER, _1913, 7);
    }
    DeRef(_1913);
    _1913 = NOVALUE;
    if (IS_ATOM_INT(_1914)) {
        _1915 = _1914 + 1;
        if (_1915 > MAXINT){
            _1915 = NewDouble((double)_1915);
        }
    }
    else
    _1915 = binary_op(PLUS, 1, _1914);
    DeRef(_1914);
    _1914 = NOVALUE;
    DeRef(_dt_3752);
    return _1915;
    ;
}
int weeks_day() __attribute__ ((alias ("_12weeks_day")));


int _12years_day(int _dt_3761)
{
    int _1920 = NOVALUE;
    int _1919 = NOVALUE;
    int _1918 = NOVALUE;
    int _1917 = NOVALUE;
    int _1916 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDayOfYear({dt[YEAR], dt[MONTH], dt[DAY]})*/
    _2 = (int)SEQ_PTR(_dt_3761);
    _1916 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_dt_3761);
    _1917 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_dt_3761);
    _1918 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_1916);
    *((int *)(_2+4)) = _1916;
    Ref(_1917);
    *((int *)(_2+8)) = _1917;
    Ref(_1918);
    *((int *)(_2+12)) = _1918;
    _1919 = MAKE_SEQ(_1);
    _1918 = NOVALUE;
    _1917 = NOVALUE;
    _1916 = NOVALUE;
    _1920 = _12julianDayOfYear(_1919);
    _1919 = NOVALUE;
    DeRef(_dt_3761);
    return _1920;
    ;
}
int years_day() __attribute__ ((alias ("_12years_day")));


int _12is_leap_year(int _dt_3769)
{
    int _1922 = NOVALUE;
    int _1921 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return isLeap(dt[YEAR])*/
    _2 = (int)SEQ_PTR(_dt_3769);
    _1921 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1921);
    _1922 = _12isLeap(_1921);
    _1921 = NOVALUE;
    DeRef(_dt_3769);
    return _1922;
    ;
}
int is_leap_year() __attribute__ ((alias ("_12is_leap_year")));


int _12days_in_month(int _dt_3774)
{
    int _1925 = NOVALUE;
    int _1924 = NOVALUE;
    int _1923 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return daysInMonth(dt[YEAR], dt[MONTH])*/
    _2 = (int)SEQ_PTR(_dt_3774);
    _1923 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_dt_3774);
    _1924 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_1923);
    Ref(_1924);
    _1925 = _12daysInMonth(_1923, _1924);
    _1923 = NOVALUE;
    _1924 = NOVALUE;
    DeRef(_dt_3774);
    return _1925;
    ;
}
int days_in_month() __attribute__ ((alias ("_12days_in_month")));


int _12days_in_year(int _dt_3780)
{
    int _daysInYear_1__tmp_at9_3785 = NOVALUE;
    int _daysInYear_inlined_daysInYear_at_9_3784 = NOVALUE;
    int _year_inlined_daysInYear_at_6_3783 = NOVALUE;
    int _1926 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return daysInYear(dt[YEAR])*/
    _2 = (int)SEQ_PTR(_dt_3780);
    _1926 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_1926);
    DeRef(_year_inlined_daysInYear_at_6_3783);
    _year_inlined_daysInYear_at_6_3783 = _1926;
    _1926 = NOVALUE;
    if (!IS_ATOM_INT(_year_inlined_daysInYear_at_6_3783)) {
        _1 = (long)(DBL_PTR(_year_inlined_daysInYear_at_6_3783)->dbl);
        DeRefDS(_year_inlined_daysInYear_at_6_3783);
        _year_inlined_daysInYear_at_6_3783 = _1;
    }

    /** 	if year = Gregorian_Reformation then*/
    if (_year_inlined_daysInYear_at_6_3783 != 1752)
    goto L1; // [14] 26

    /** 		return 355*/
    DeRef(_daysInYear_inlined_daysInYear_at_9_3784);
    _daysInYear_inlined_daysInYear_at_9_3784 = 355;
    goto L2; // [23] 37
L1: 

    /** 	return 365 + isLeap(year)*/
    Ref(_year_inlined_daysInYear_at_6_3783);
    _0 = _daysInYear_1__tmp_at9_3785;
    _daysInYear_1__tmp_at9_3785 = _12isLeap(_year_inlined_daysInYear_at_6_3783);
    DeRef(_0);
    DeRef(_daysInYear_inlined_daysInYear_at_9_3784);
    if (IS_ATOM_INT(_daysInYear_1__tmp_at9_3785)) {
        _daysInYear_inlined_daysInYear_at_9_3784 = 365 + _daysInYear_1__tmp_at9_3785;
        if ((long)((unsigned long)_daysInYear_inlined_daysInYear_at_9_3784 + (unsigned long)HIGH_BITS) >= 0) 
        _daysInYear_inlined_daysInYear_at_9_3784 = NewDouble((double)_daysInYear_inlined_daysInYear_at_9_3784);
    }
    else {
        _daysInYear_inlined_daysInYear_at_9_3784 = binary_op(PLUS, 365, _daysInYear_1__tmp_at9_3785);
    }
L2: 
    DeRef(_year_inlined_daysInYear_at_6_3783);
    _year_inlined_daysInYear_at_6_3783 = NOVALUE;
    DeRef(_daysInYear_1__tmp_at9_3785);
    _daysInYear_1__tmp_at9_3785 = NOVALUE;
    DeRef(_dt_3780);
    return _daysInYear_inlined_daysInYear_at_9_3784;
    ;
}
int days_in_year() __attribute__ ((alias ("_12days_in_year")));


int _12to_unix(int _dt_3788)
{
    int _1928 = NOVALUE;
    int _1927 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetimeToSeconds(dt) - EPOCH_1970*/
    Ref(_dt_3788);
    _1927 = _12datetimeToSeconds(_dt_3788);
    _1928 = binary_op(MINUS, _1927, _12EPOCH_1970_3351);
    DeRef(_1927);
    _1927 = NOVALUE;
    DeRef(_dt_3788);
    return _1928;
    ;
}
int to_unix() __attribute__ ((alias ("_12to_unix")));


int _12from_unix(int _unix_3793)
{
    int _1930 = NOVALUE;
    int _1929 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return secondsToDateTime(EPOCH_1970 + unix)*/
    if (IS_ATOM_INT(_unix_3793)) {
        _1929 = NewDouble(DBL_PTR(_12EPOCH_1970_3351)->dbl + (double)_unix_3793);
    }
    else
    _1929 = NewDouble(DBL_PTR(_12EPOCH_1970_3351)->dbl + DBL_PTR(_unix_3793)->dbl);
    _1930 = _12secondsToDateTime(_1929);
    _1929 = NOVALUE;
    DeRef(_unix_3793);
    return _1930;
    ;
}
int from_unix() __attribute__ ((alias ("_12from_unix")));


int _12format(int _d_3798, int _pattern_3799)
{
    int _in_fmt_3801 = NOVALUE;
    int _ch_3802 = NOVALUE;
    int _tmp_3803 = NOVALUE;
    int _res_3804 = NOVALUE;
    int _weeks_day_4__tmp_at67_3820 = NOVALUE;
    int _weeks_day_3__tmp_at67_3819 = NOVALUE;
    int _weeks_day_2__tmp_at67_3818 = NOVALUE;
    int _weeks_day_1__tmp_at67_3817 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_67_3816 = NOVALUE;
    int _weeks_day_4__tmp_at113_3830 = NOVALUE;
    int _weeks_day_3__tmp_at113_3829 = NOVALUE;
    int _weeks_day_2__tmp_at113_3828 = NOVALUE;
    int _weeks_day_1__tmp_at113_3827 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_113_3826 = NOVALUE;
    int _to_unix_1__tmp_at584_3935 = NOVALUE;
    int _to_unix_inlined_to_unix_at_584_3934 = NOVALUE;
    int _weeks_day_4__tmp_at639_3952 = NOVALUE;
    int _weeks_day_3__tmp_at639_3951 = NOVALUE;
    int _weeks_day_2__tmp_at639_3950 = NOVALUE;
    int _weeks_day_1__tmp_at639_3949 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_639_3948 = NOVALUE;
    int _weeks_day_4__tmp_at681_3963 = NOVALUE;
    int _weeks_day_3__tmp_at681_3962 = NOVALUE;
    int _weeks_day_2__tmp_at681_3961 = NOVALUE;
    int _weeks_day_1__tmp_at681_3960 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_681_3959 = NOVALUE;
    int _weeks_day_4__tmp_at730_3975 = NOVALUE;
    int _weeks_day_3__tmp_at730_3974 = NOVALUE;
    int _weeks_day_2__tmp_at730_3973 = NOVALUE;
    int _weeks_day_1__tmp_at730_3972 = NOVALUE;
    int _weeks_day_inlined_weeks_day_at_730_3971 = NOVALUE;
    int _2053 = NOVALUE;
    int _2052 = NOVALUE;
    int _2047 = NOVALUE;
    int _2046 = NOVALUE;
    int _2045 = NOVALUE;
    int _2044 = NOVALUE;
    int _2042 = NOVALUE;
    int _2038 = NOVALUE;
    int _2037 = NOVALUE;
    int _2033 = NOVALUE;
    int _2032 = NOVALUE;
    int _2025 = NOVALUE;
    int _2024 = NOVALUE;
    int _2020 = NOVALUE;
    int _2016 = NOVALUE;
    int _2015 = NOVALUE;
    int _2013 = NOVALUE;
    int _2012 = NOVALUE;
    int _2010 = NOVALUE;
    int _2006 = NOVALUE;
    int _2004 = NOVALUE;
    int _2002 = NOVALUE;
    int _1998 = NOVALUE;
    int _1997 = NOVALUE;
    int _1993 = NOVALUE;
    int _1992 = NOVALUE;
    int _1988 = NOVALUE;
    int _1980 = NOVALUE;
    int _1979 = NOVALUE;
    int _1975 = NOVALUE;
    int _1974 = NOVALUE;
    int _1970 = NOVALUE;
    int _1962 = NOVALUE;
    int _1961 = NOVALUE;
    int _1958 = NOVALUE;
    int _1957 = NOVALUE;
    int _1954 = NOVALUE;
    int _1953 = NOVALUE;
    int _1952 = NOVALUE;
    int _1948 = NOVALUE;
    int _1947 = NOVALUE;
    int _1944 = NOVALUE;
    int _1943 = NOVALUE;
    int _1940 = NOVALUE;
    int _1937 = NOVALUE;
    int _1932 = NOVALUE;
    int _0, _1, _2;
    

    /** 	in_fmt = 0*/
    _in_fmt_3801 = 0;

    /** 	res = ""*/
    RefDS(_5);
    DeRef(_res_3804);
    _res_3804 = _5;

    /** 	for i = 1 to length(pattern) do*/
    if (IS_SEQUENCE(_pattern_3799)){
            _1932 = SEQ_PTR(_pattern_3799)->length;
    }
    else {
        _1932 = 1;
    }
    {
        int _i_3806;
        _i_3806 = 1;
L1: 
        if (_i_3806 > _1932){
            goto L2; // [20] 869
        }

        /** 		ch = pattern[i]*/
        _2 = (int)SEQ_PTR(_pattern_3799);
        _ch_3802 = (int)*(((s1_ptr)_2)->base + _i_3806);
        if (!IS_ATOM_INT(_ch_3802))
        _ch_3802 = (long)DBL_PTR(_ch_3802)->dbl;

        /** 		if in_fmt then*/
        if (_in_fmt_3801 == 0)
        {
            goto L3; // [35] 841
        }
        else{
        }

        /** 			in_fmt = 0*/
        _in_fmt_3801 = 0;

        /** 			if ch = '%' then*/
        if (_ch_3802 != 37)
        goto L4; // [45] 58

        /** 				res &= '%'*/
        Append(&_res_3804, _res_3804, 37);
        goto L5; // [55] 862
L4: 

        /** 			elsif ch = 'a' then*/
        if (_ch_3802 != 97)
        goto L6; // [60] 104

        /** 				res &= day_abbrs[weeks_day(d)]*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3798);
        _0 = _weeks_day_1__tmp_at67_3817;
        _weeks_day_1__tmp_at67_3817 = _12julianDay(_d_3798);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at67_3818);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at67_3817)) {
            _weeks_day_2__tmp_at67_3818 = _weeks_day_1__tmp_at67_3817 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at67_3818 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at67_3818 = NewDouble((double)_weeks_day_2__tmp_at67_3818);
            }
        }
        else {
            _weeks_day_2__tmp_at67_3818 = binary_op(MINUS, _weeks_day_1__tmp_at67_3817, 1);
        }
        DeRef(_weeks_day_3__tmp_at67_3819);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at67_3818)) {
            _weeks_day_3__tmp_at67_3819 = _weeks_day_2__tmp_at67_3818 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at67_3819 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at67_3819 = NewDouble((double)_weeks_day_3__tmp_at67_3819);
        }
        else {
            _weeks_day_3__tmp_at67_3819 = binary_op(PLUS, _weeks_day_2__tmp_at67_3818, 4094);
        }
        DeRef(_weeks_day_4__tmp_at67_3820);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at67_3819)) {
            _weeks_day_4__tmp_at67_3820 = (_weeks_day_3__tmp_at67_3819 % 7);
        }
        else {
            _weeks_day_4__tmp_at67_3820 = binary_op(REMAINDER, _weeks_day_3__tmp_at67_3819, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_67_3816);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at67_3820)) {
            _weeks_day_inlined_weeks_day_at_67_3816 = _weeks_day_4__tmp_at67_3820 + 1;
            if (_weeks_day_inlined_weeks_day_at_67_3816 > MAXINT){
                _weeks_day_inlined_weeks_day_at_67_3816 = NewDouble((double)_weeks_day_inlined_weeks_day_at_67_3816);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_67_3816 = binary_op(PLUS, 1, _weeks_day_4__tmp_at67_3820);
        DeRef(_weeks_day_1__tmp_at67_3817);
        _weeks_day_1__tmp_at67_3817 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at67_3818);
        _weeks_day_2__tmp_at67_3818 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at67_3819);
        _weeks_day_3__tmp_at67_3819 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at67_3820);
        _weeks_day_4__tmp_at67_3820 = NOVALUE;
        _2 = (int)SEQ_PTR(_12day_abbrs_3596);
        if (!IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_67_3816)){
            _1937 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_weeks_day_inlined_weeks_day_at_67_3816)->dbl));
        }
        else{
            _1937 = (int)*(((s1_ptr)_2)->base + _weeks_day_inlined_weeks_day_at_67_3816);
        }
        Concat((object_ptr)&_res_3804, _res_3804, _1937);
        _1937 = NOVALUE;
        goto L5; // [101] 862
L6: 

        /** 			elsif ch = 'A' then*/
        if (_ch_3802 != 65)
        goto L7; // [106] 150

        /** 				res &= day_names[weeks_day(d)]*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3798);
        _0 = _weeks_day_1__tmp_at113_3827;
        _weeks_day_1__tmp_at113_3827 = _12julianDay(_d_3798);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at113_3828);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at113_3827)) {
            _weeks_day_2__tmp_at113_3828 = _weeks_day_1__tmp_at113_3827 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at113_3828 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at113_3828 = NewDouble((double)_weeks_day_2__tmp_at113_3828);
            }
        }
        else {
            _weeks_day_2__tmp_at113_3828 = binary_op(MINUS, _weeks_day_1__tmp_at113_3827, 1);
        }
        DeRef(_weeks_day_3__tmp_at113_3829);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at113_3828)) {
            _weeks_day_3__tmp_at113_3829 = _weeks_day_2__tmp_at113_3828 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at113_3829 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at113_3829 = NewDouble((double)_weeks_day_3__tmp_at113_3829);
        }
        else {
            _weeks_day_3__tmp_at113_3829 = binary_op(PLUS, _weeks_day_2__tmp_at113_3828, 4094);
        }
        DeRef(_weeks_day_4__tmp_at113_3830);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at113_3829)) {
            _weeks_day_4__tmp_at113_3830 = (_weeks_day_3__tmp_at113_3829 % 7);
        }
        else {
            _weeks_day_4__tmp_at113_3830 = binary_op(REMAINDER, _weeks_day_3__tmp_at113_3829, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_113_3826);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at113_3830)) {
            _weeks_day_inlined_weeks_day_at_113_3826 = _weeks_day_4__tmp_at113_3830 + 1;
            if (_weeks_day_inlined_weeks_day_at_113_3826 > MAXINT){
                _weeks_day_inlined_weeks_day_at_113_3826 = NewDouble((double)_weeks_day_inlined_weeks_day_at_113_3826);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_113_3826 = binary_op(PLUS, 1, _weeks_day_4__tmp_at113_3830);
        DeRef(_weeks_day_1__tmp_at113_3827);
        _weeks_day_1__tmp_at113_3827 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at113_3828);
        _weeks_day_2__tmp_at113_3828 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at113_3829);
        _weeks_day_3__tmp_at113_3829 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at113_3830);
        _weeks_day_4__tmp_at113_3830 = NOVALUE;
        _2 = (int)SEQ_PTR(_12day_names_3587);
        if (!IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_113_3826)){
            _1940 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_weeks_day_inlined_weeks_day_at_113_3826)->dbl));
        }
        else{
            _1940 = (int)*(((s1_ptr)_2)->base + _weeks_day_inlined_weeks_day_at_113_3826);
        }
        Concat((object_ptr)&_res_3804, _res_3804, _1940);
        _1940 = NOVALUE;
        goto L5; // [147] 862
L7: 

        /** 			elsif ch = 'b' then*/
        if (_ch_3802 != 98)
        goto L8; // [152] 175

        /** 				res &= month_abbrs[d[MONTH]]*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1943 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_12month_abbrs_3574);
        if (!IS_ATOM_INT(_1943)){
            _1944 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1943)->dbl));
        }
        else{
            _1944 = (int)*(((s1_ptr)_2)->base + _1943);
        }
        Concat((object_ptr)&_res_3804, _res_3804, _1944);
        _1944 = NOVALUE;
        goto L5; // [172] 862
L8: 

        /** 			elsif ch = 'B' then*/
        if (_ch_3802 != 66)
        goto L9; // [177] 200

        /** 				res &= month_names[d[MONTH]]*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1947 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_12month_names_3560);
        if (!IS_ATOM_INT(_1947)){
            _1948 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_1947)->dbl));
        }
        else{
            _1948 = (int)*(((s1_ptr)_2)->base + _1947);
        }
        Concat((object_ptr)&_res_3804, _res_3804, _1948);
        _1948 = NOVALUE;
        goto L5; // [197] 862
L9: 

        /** 			elsif ch = 'C' then*/
        if (_ch_3802 != 67)
        goto LA; // [202] 227

        /** 				res &= sprintf("%02d", d[YEAR] / 100)*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1952 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_1952)) {
            _1953 = (_1952 % 100) ? NewDouble((double)_1952 / 100) : (_1952 / 100);
        }
        else {
            _1953 = binary_op(DIVIDE, _1952, 100);
        }
        _1952 = NOVALUE;
        _1954 = EPrintf(-9999999, _1951, _1953);
        DeRef(_1953);
        _1953 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1954);
        DeRefDS(_1954);
        _1954 = NOVALUE;
        goto L5; // [224] 862
LA: 

        /** 			elsif ch = 'd' then*/
        if (_ch_3802 != 100)
        goto LB; // [229] 250

        /** 				res &= sprintf("%02d", d[DAY])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1957 = (int)*(((s1_ptr)_2)->base + 3);
        _1958 = EPrintf(-9999999, _1951, _1957);
        _1957 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1958);
        DeRefDS(_1958);
        _1958 = NOVALUE;
        goto L5; // [247] 862
LB: 

        /** 			elsif ch = 'H' then*/
        if (_ch_3802 != 72)
        goto LC; // [252] 273

        /** 				res &= sprintf("%02d", d[HOUR])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1961 = (int)*(((s1_ptr)_2)->base + 4);
        _1962 = EPrintf(-9999999, _1951, _1961);
        _1961 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1962);
        DeRefDS(_1962);
        _1962 = NOVALUE;
        goto L5; // [270] 862
LC: 

        /** 			elsif ch = 'I' then*/
        if (_ch_3802 != 73)
        goto LD; // [275] 328

        /** 				tmp = d[HOUR]*/
        _2 = (int)SEQ_PTR(_d_3798);
        _tmp_3803 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_tmp_3803)){
            _tmp_3803 = (long)DBL_PTR(_tmp_3803)->dbl;
        }

        /** 				if tmp > 12 then*/
        if (_tmp_3803 <= 12)
        goto LE; // [289] 302

        /** 					tmp -= 12*/
        _tmp_3803 = _tmp_3803 - 12;
        goto LF; // [299] 315
LE: 

        /** 				elsif tmp = 0 then*/
        if (_tmp_3803 != 0)
        goto L10; // [304] 314

        /** 					tmp = 12*/
        _tmp_3803 = 12;
L10: 
LF: 

        /** 				res &= sprintf("%02d", tmp)*/
        _1970 = EPrintf(-9999999, _1951, _tmp_3803);
        Concat((object_ptr)&_res_3804, _res_3804, _1970);
        DeRefDS(_1970);
        _1970 = NOVALUE;
        goto L5; // [325] 862
LD: 

        /** 			elsif ch = 'j' then*/
        if (_ch_3802 != 106)
        goto L11; // [330] 351

        /** 				res &= sprintf("%d", julianDayOfYear(d))*/
        Ref(_d_3798);
        _1974 = _12julianDayOfYear(_d_3798);
        _1975 = EPrintf(-9999999, _919, _1974);
        DeRef(_1974);
        _1974 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1975);
        DeRefDS(_1975);
        _1975 = NOVALUE;
        goto L5; // [348] 862
L11: 

        /** 			elsif ch = 'k' then*/
        if (_ch_3802 != 107)
        goto L12; // [353] 374

        /** 				res &= sprintf("%d", d[HOUR])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1979 = (int)*(((s1_ptr)_2)->base + 4);
        _1980 = EPrintf(-9999999, _919, _1979);
        _1979 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1980);
        DeRefDS(_1980);
        _1980 = NOVALUE;
        goto L5; // [371] 862
L12: 

        /** 			elsif ch = 'l' then*/
        if (_ch_3802 != 108)
        goto L13; // [376] 429

        /** 				tmp = d[HOUR]*/
        _2 = (int)SEQ_PTR(_d_3798);
        _tmp_3803 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_tmp_3803)){
            _tmp_3803 = (long)DBL_PTR(_tmp_3803)->dbl;
        }

        /** 				if tmp > 12 then*/
        if (_tmp_3803 <= 12)
        goto L14; // [390] 403

        /** 					tmp -= 12*/
        _tmp_3803 = _tmp_3803 - 12;
        goto L15; // [400] 416
L14: 

        /** 				elsif tmp = 0 then*/
        if (_tmp_3803 != 0)
        goto L16; // [405] 415

        /** 					tmp = 12*/
        _tmp_3803 = 12;
L16: 
L15: 

        /** 				res &= sprintf("%d", tmp)*/
        _1988 = EPrintf(-9999999, _919, _tmp_3803);
        Concat((object_ptr)&_res_3804, _res_3804, _1988);
        DeRefDS(_1988);
        _1988 = NOVALUE;
        goto L5; // [426] 862
L13: 

        /** 			elsif ch = 'm' then*/
        if (_ch_3802 != 109)
        goto L17; // [431] 452

        /** 				res &= sprintf("%02d", d[MONTH])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1992 = (int)*(((s1_ptr)_2)->base + 2);
        _1993 = EPrintf(-9999999, _1951, _1992);
        _1992 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1993);
        DeRefDS(_1993);
        _1993 = NOVALUE;
        goto L5; // [449] 862
L17: 

        /** 			elsif ch = 'M' then*/
        if (_ch_3802 != 77)
        goto L18; // [454] 475

        /** 				res &= sprintf("%02d", d[MINUTE])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _1997 = (int)*(((s1_ptr)_2)->base + 5);
        _1998 = EPrintf(-9999999, _1951, _1997);
        _1997 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _1998);
        DeRefDS(_1998);
        _1998 = NOVALUE;
        goto L5; // [472] 862
L18: 

        /** 			elsif ch = 'p' then*/
        if (_ch_3802 != 112)
        goto L19; // [477] 522

        /** 				if d[HOUR] <= 12 then*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2002 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(GREATER, _2002, 12)){
            _2002 = NOVALUE;
            goto L1A; // [487] 506
        }
        _2002 = NOVALUE;

        /** 					res &= ampm[1]*/
        _2 = (int)SEQ_PTR(_12ampm_3605);
        _2004 = (int)*(((s1_ptr)_2)->base + 1);
        Concat((object_ptr)&_res_3804, _res_3804, _2004);
        _2004 = NOVALUE;
        goto L5; // [503] 862
L1A: 

        /** 					res &= ampm[2]*/
        _2 = (int)SEQ_PTR(_12ampm_3605);
        _2006 = (int)*(((s1_ptr)_2)->base + 2);
        Concat((object_ptr)&_res_3804, _res_3804, _2006);
        _2006 = NOVALUE;
        goto L5; // [519] 862
L19: 

        /** 			elsif ch = 'P' then*/
        if (_ch_3802 != 80)
        goto L1B; // [524] 577

        /** 				if d[HOUR] <= 12 then*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2010 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(GREATER, _2010, 12)){
            _2010 = NOVALUE;
            goto L1C; // [534] 557
        }
        _2010 = NOVALUE;

        /** 					res &= tolower(ampm[1])*/
        _2 = (int)SEQ_PTR(_12ampm_3605);
        _2012 = (int)*(((s1_ptr)_2)->base + 1);
        RefDS(_2012);
        _2013 = _12tolower(_2012);
        _2012 = NOVALUE;
        if (IS_SEQUENCE(_res_3804) && IS_ATOM(_2013)) {
            Ref(_2013);
            Append(&_res_3804, _res_3804, _2013);
        }
        else if (IS_ATOM(_res_3804) && IS_SEQUENCE(_2013)) {
        }
        else {
            Concat((object_ptr)&_res_3804, _res_3804, _2013);
        }
        DeRef(_2013);
        _2013 = NOVALUE;
        goto L5; // [554] 862
L1C: 

        /** 					res &= tolower(ampm[2])*/
        _2 = (int)SEQ_PTR(_12ampm_3605);
        _2015 = (int)*(((s1_ptr)_2)->base + 2);
        RefDS(_2015);
        _2016 = _12tolower(_2015);
        _2015 = NOVALUE;
        if (IS_SEQUENCE(_res_3804) && IS_ATOM(_2016)) {
            Ref(_2016);
            Append(&_res_3804, _res_3804, _2016);
        }
        else if (IS_ATOM(_res_3804) && IS_SEQUENCE(_2016)) {
        }
        else {
            Concat((object_ptr)&_res_3804, _res_3804, _2016);
        }
        DeRef(_2016);
        _2016 = NOVALUE;
        goto L5; // [574] 862
L1B: 

        /** 			elsif ch = 's' then*/
        if (_ch_3802 != 115)
        goto L1D; // [579] 609

        /** 				res &= sprintf("%d", to_unix(d))*/

        /** 	return datetimeToSeconds(dt) - EPOCH_1970*/
        Ref(_d_3798);
        _0 = _to_unix_1__tmp_at584_3935;
        _to_unix_1__tmp_at584_3935 = _12datetimeToSeconds(_d_3798);
        DeRef(_0);
        DeRef(_to_unix_inlined_to_unix_at_584_3934);
        _to_unix_inlined_to_unix_at_584_3934 = binary_op(MINUS, _to_unix_1__tmp_at584_3935, _12EPOCH_1970_3351);
        DeRef(_to_unix_1__tmp_at584_3935);
        _to_unix_1__tmp_at584_3935 = NOVALUE;
        _2020 = EPrintf(-9999999, _919, _to_unix_inlined_to_unix_at_584_3934);
        Concat((object_ptr)&_res_3804, _res_3804, _2020);
        DeRefDS(_2020);
        _2020 = NOVALUE;
        goto L5; // [606] 862
L1D: 

        /** 			elsif ch = 'S' then*/
        if (_ch_3802 != 83)
        goto L1E; // [611] 632

        /** 				res &= sprintf("%02d", d[SECOND])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2024 = (int)*(((s1_ptr)_2)->base + 6);
        _2025 = EPrintf(-9999999, _1951, _2024);
        _2024 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _2025);
        DeRefDS(_2025);
        _2025 = NOVALUE;
        goto L5; // [629] 862
L1E: 

        /** 			elsif ch = 'u' then*/
        if (_ch_3802 != 117)
        goto L1F; // [634] 723

        /** 				tmp = weeks_day(d)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3798);
        _0 = _weeks_day_1__tmp_at639_3949;
        _weeks_day_1__tmp_at639_3949 = _12julianDay(_d_3798);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at639_3950);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at639_3949)) {
            _weeks_day_2__tmp_at639_3950 = _weeks_day_1__tmp_at639_3949 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at639_3950 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at639_3950 = NewDouble((double)_weeks_day_2__tmp_at639_3950);
            }
        }
        else {
            _weeks_day_2__tmp_at639_3950 = binary_op(MINUS, _weeks_day_1__tmp_at639_3949, 1);
        }
        DeRef(_weeks_day_3__tmp_at639_3951);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at639_3950)) {
            _weeks_day_3__tmp_at639_3951 = _weeks_day_2__tmp_at639_3950 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at639_3951 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at639_3951 = NewDouble((double)_weeks_day_3__tmp_at639_3951);
        }
        else {
            _weeks_day_3__tmp_at639_3951 = binary_op(PLUS, _weeks_day_2__tmp_at639_3950, 4094);
        }
        DeRef(_weeks_day_4__tmp_at639_3952);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at639_3951)) {
            _weeks_day_4__tmp_at639_3952 = (_weeks_day_3__tmp_at639_3951 % 7);
        }
        else {
            _weeks_day_4__tmp_at639_3952 = binary_op(REMAINDER, _weeks_day_3__tmp_at639_3951, 7);
        }
        if (IS_ATOM_INT(_weeks_day_4__tmp_at639_3952)) {
            _tmp_3803 = _weeks_day_4__tmp_at639_3952 + 1;
        }
        else
        { // coercing _tmp_3803 to an integer 1
            _tmp_3803 = binary_op(PLUS, 1, _weeks_day_4__tmp_at639_3952);
            if( !IS_ATOM_INT(_tmp_3803) ){
                _tmp_3803 = (object)DBL_PTR(_tmp_3803)->dbl;
            }
        }
        DeRef(_weeks_day_1__tmp_at639_3949);
        _weeks_day_1__tmp_at639_3949 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at639_3950);
        _weeks_day_2__tmp_at639_3950 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at639_3951);
        _weeks_day_3__tmp_at639_3951 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at639_3952);
        _weeks_day_4__tmp_at639_3952 = NOVALUE;

        /** 				if tmp = 1 then*/
        if (_tmp_3803 != 1)
        goto L20; // [667] 680

        /** 					res &= "7" -- Sunday*/
        Concat((object_ptr)&_res_3804, _res_3804, _2030);
        goto L5; // [677] 862
L20: 

        /** 					res &= sprintf("%d", weeks_day(d) - 1)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3798);
        _0 = _weeks_day_1__tmp_at681_3960;
        _weeks_day_1__tmp_at681_3960 = _12julianDay(_d_3798);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at681_3961);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at681_3960)) {
            _weeks_day_2__tmp_at681_3961 = _weeks_day_1__tmp_at681_3960 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at681_3961 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at681_3961 = NewDouble((double)_weeks_day_2__tmp_at681_3961);
            }
        }
        else {
            _weeks_day_2__tmp_at681_3961 = binary_op(MINUS, _weeks_day_1__tmp_at681_3960, 1);
        }
        DeRef(_weeks_day_3__tmp_at681_3962);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at681_3961)) {
            _weeks_day_3__tmp_at681_3962 = _weeks_day_2__tmp_at681_3961 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at681_3962 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at681_3962 = NewDouble((double)_weeks_day_3__tmp_at681_3962);
        }
        else {
            _weeks_day_3__tmp_at681_3962 = binary_op(PLUS, _weeks_day_2__tmp_at681_3961, 4094);
        }
        DeRef(_weeks_day_4__tmp_at681_3963);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at681_3962)) {
            _weeks_day_4__tmp_at681_3963 = (_weeks_day_3__tmp_at681_3962 % 7);
        }
        else {
            _weeks_day_4__tmp_at681_3963 = binary_op(REMAINDER, _weeks_day_3__tmp_at681_3962, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_681_3959);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at681_3963)) {
            _weeks_day_inlined_weeks_day_at_681_3959 = _weeks_day_4__tmp_at681_3963 + 1;
            if (_weeks_day_inlined_weeks_day_at_681_3959 > MAXINT){
                _weeks_day_inlined_weeks_day_at_681_3959 = NewDouble((double)_weeks_day_inlined_weeks_day_at_681_3959);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_681_3959 = binary_op(PLUS, 1, _weeks_day_4__tmp_at681_3963);
        DeRef(_weeks_day_1__tmp_at681_3960);
        _weeks_day_1__tmp_at681_3960 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at681_3961);
        _weeks_day_2__tmp_at681_3961 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at681_3962);
        _weeks_day_3__tmp_at681_3962 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at681_3963);
        _weeks_day_4__tmp_at681_3963 = NOVALUE;
        if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_681_3959)) {
            _2032 = _weeks_day_inlined_weeks_day_at_681_3959 - 1;
            if ((long)((unsigned long)_2032 +(unsigned long) HIGH_BITS) >= 0){
                _2032 = NewDouble((double)_2032);
            }
        }
        else {
            _2032 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_681_3959, 1);
        }
        _2033 = EPrintf(-9999999, _919, _2032);
        DeRef(_2032);
        _2032 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _2033);
        DeRefDS(_2033);
        _2033 = NOVALUE;
        goto L5; // [720] 862
L1F: 

        /** 			elsif ch = 'w' then*/
        if (_ch_3802 != 119)
        goto L21; // [725] 771

        /** 				res &= sprintf("%d", weeks_day(d) - 1)*/

        /** 	return remainder(julianDay(dt)-1+4094, 7) + 1*/
        Ref(_d_3798);
        _0 = _weeks_day_1__tmp_at730_3972;
        _weeks_day_1__tmp_at730_3972 = _12julianDay(_d_3798);
        DeRef(_0);
        DeRef(_weeks_day_2__tmp_at730_3973);
        if (IS_ATOM_INT(_weeks_day_1__tmp_at730_3972)) {
            _weeks_day_2__tmp_at730_3973 = _weeks_day_1__tmp_at730_3972 - 1;
            if ((long)((unsigned long)_weeks_day_2__tmp_at730_3973 +(unsigned long) HIGH_BITS) >= 0){
                _weeks_day_2__tmp_at730_3973 = NewDouble((double)_weeks_day_2__tmp_at730_3973);
            }
        }
        else {
            _weeks_day_2__tmp_at730_3973 = binary_op(MINUS, _weeks_day_1__tmp_at730_3972, 1);
        }
        DeRef(_weeks_day_3__tmp_at730_3974);
        if (IS_ATOM_INT(_weeks_day_2__tmp_at730_3973)) {
            _weeks_day_3__tmp_at730_3974 = _weeks_day_2__tmp_at730_3973 + 4094;
            if ((long)((unsigned long)_weeks_day_3__tmp_at730_3974 + (unsigned long)HIGH_BITS) >= 0) 
            _weeks_day_3__tmp_at730_3974 = NewDouble((double)_weeks_day_3__tmp_at730_3974);
        }
        else {
            _weeks_day_3__tmp_at730_3974 = binary_op(PLUS, _weeks_day_2__tmp_at730_3973, 4094);
        }
        DeRef(_weeks_day_4__tmp_at730_3975);
        if (IS_ATOM_INT(_weeks_day_3__tmp_at730_3974)) {
            _weeks_day_4__tmp_at730_3975 = (_weeks_day_3__tmp_at730_3974 % 7);
        }
        else {
            _weeks_day_4__tmp_at730_3975 = binary_op(REMAINDER, _weeks_day_3__tmp_at730_3974, 7);
        }
        DeRef(_weeks_day_inlined_weeks_day_at_730_3971);
        if (IS_ATOM_INT(_weeks_day_4__tmp_at730_3975)) {
            _weeks_day_inlined_weeks_day_at_730_3971 = _weeks_day_4__tmp_at730_3975 + 1;
            if (_weeks_day_inlined_weeks_day_at_730_3971 > MAXINT){
                _weeks_day_inlined_weeks_day_at_730_3971 = NewDouble((double)_weeks_day_inlined_weeks_day_at_730_3971);
            }
        }
        else
        _weeks_day_inlined_weeks_day_at_730_3971 = binary_op(PLUS, 1, _weeks_day_4__tmp_at730_3975);
        DeRef(_weeks_day_1__tmp_at730_3972);
        _weeks_day_1__tmp_at730_3972 = NOVALUE;
        DeRef(_weeks_day_2__tmp_at730_3973);
        _weeks_day_2__tmp_at730_3973 = NOVALUE;
        DeRef(_weeks_day_3__tmp_at730_3974);
        _weeks_day_3__tmp_at730_3974 = NOVALUE;
        DeRef(_weeks_day_4__tmp_at730_3975);
        _weeks_day_4__tmp_at730_3975 = NOVALUE;
        if (IS_ATOM_INT(_weeks_day_inlined_weeks_day_at_730_3971)) {
            _2037 = _weeks_day_inlined_weeks_day_at_730_3971 - 1;
            if ((long)((unsigned long)_2037 +(unsigned long) HIGH_BITS) >= 0){
                _2037 = NewDouble((double)_2037);
            }
        }
        else {
            _2037 = binary_op(MINUS, _weeks_day_inlined_weeks_day_at_730_3971, 1);
        }
        _2038 = EPrintf(-9999999, _919, _2037);
        DeRef(_2037);
        _2037 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _2038);
        DeRefDS(_2038);
        _2038 = NOVALUE;
        goto L5; // [768] 862
L21: 

        /** 			elsif ch = 'y' then*/
        if (_ch_3802 != 121)
        goto L22; // [773] 814

        /** 			   tmp = floor(d[YEAR] / 100)*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2042 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2042)) {
            if (100 > 0 && _2042 >= 0) {
                _tmp_3803 = _2042 / 100;
            }
            else {
                temp_dbl = floor((double)_2042 / (double)100);
                _tmp_3803 = (long)temp_dbl;
            }
        }
        else {
            _2 = binary_op(DIVIDE, _2042, 100);
            _tmp_3803 = unary_op(FLOOR, _2);
            DeRef(_2);
        }
        _2042 = NOVALUE;
        if (!IS_ATOM_INT(_tmp_3803)) {
            _1 = (long)(DBL_PTR(_tmp_3803)->dbl);
            DeRefDS(_tmp_3803);
            _tmp_3803 = _1;
        }

        /** 			   res &= sprintf("%02d", d[YEAR] - (tmp * 100))*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2044 = (int)*(((s1_ptr)_2)->base + 1);
        if (_tmp_3803 == (short)_tmp_3803)
        _2045 = _tmp_3803 * 100;
        else
        _2045 = NewDouble(_tmp_3803 * (double)100);
        if (IS_ATOM_INT(_2044) && IS_ATOM_INT(_2045)) {
            _2046 = _2044 - _2045;
            if ((long)((unsigned long)_2046 +(unsigned long) HIGH_BITS) >= 0){
                _2046 = NewDouble((double)_2046);
            }
        }
        else {
            _2046 = binary_op(MINUS, _2044, _2045);
        }
        _2044 = NOVALUE;
        DeRef(_2045);
        _2045 = NOVALUE;
        _2047 = EPrintf(-9999999, _1951, _2046);
        DeRef(_2046);
        _2046 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _2047);
        DeRefDS(_2047);
        _2047 = NOVALUE;
        goto L5; // [811] 862
L22: 

        /** 			elsif ch = 'Y' then*/
        if (_ch_3802 != 89)
        goto L5; // [816] 862

        /** 				res &= sprintf("%04d", d[YEAR])*/
        _2 = (int)SEQ_PTR(_d_3798);
        _2052 = (int)*(((s1_ptr)_2)->base + 1);
        _2053 = EPrintf(-9999999, _2051, _2052);
        _2052 = NOVALUE;
        Concat((object_ptr)&_res_3804, _res_3804, _2053);
        DeRefDS(_2053);
        _2053 = NOVALUE;
        goto L5; // [834] 862
        goto L5; // [838] 862
L3: 

        /** 		elsif ch = '%' then*/
        if (_ch_3802 != 37)
        goto L23; // [843] 855

        /** 			in_fmt = 1*/
        _in_fmt_3801 = 1;
        goto L5; // [852] 862
L23: 

        /** 			res &= ch*/
        Append(&_res_3804, _res_3804, _ch_3802);
L5: 

        /** 	end for*/
        _i_3806 = _i_3806 + 1;
        goto L1; // [864] 27
L2: 
        ;
    }

    /** 	return res*/
    DeRef(_d_3798);
    DeRefDS(_pattern_3799);
    _1943 = NOVALUE;
    _1947 = NOVALUE;
    return _res_3804;
    ;
}


int _12parse(int _val_4007, int _fmt_4008, int _yylower_4009)
{
    int _fpos_4011 = NOVALUE;
    int _spos_4012 = NOVALUE;
    int _maxlen_4013 = NOVALUE;
    int _rpos_4014 = NOVALUE;
    int _res_4015 = NOVALUE;
    int _got_4036 = NOVALUE;
    int _epos_4037 = NOVALUE;
    int _value_inlined_value_at_335_4064 = NOVALUE;
    int _st_inlined_value_at_332_4063 = NOVALUE;
    int _century_4071 = NOVALUE;
    int _year_4075 = NOVALUE;
    int _2116 = NOVALUE;
    int _2115 = NOVALUE;
    int _2114 = NOVALUE;
    int _2113 = NOVALUE;
    int _2112 = NOVALUE;
    int _2111 = NOVALUE;
    int _2110 = NOVALUE;
    int _2108 = NOVALUE;
    int _2107 = NOVALUE;
    int _2105 = NOVALUE;
    int _2103 = NOVALUE;
    int _2101 = NOVALUE;
    int _2099 = NOVALUE;
    int _2097 = NOVALUE;
    int _2096 = NOVALUE;
    int _2094 = NOVALUE;
    int _2093 = NOVALUE;
    int _2091 = NOVALUE;
    int _2090 = NOVALUE;
    int _2088 = NOVALUE;
    int _2086 = NOVALUE;
    int _2085 = NOVALUE;
    int _2084 = NOVALUE;
    int _2082 = NOVALUE;
    int _2079 = NOVALUE;
    int _2078 = NOVALUE;
    int _2077 = NOVALUE;
    int _2076 = NOVALUE;
    int _2075 = NOVALUE;
    int _2074 = NOVALUE;
    int _2073 = NOVALUE;
    int _2070 = NOVALUE;
    int _2069 = NOVALUE;
    int _2067 = NOVALUE;
    int _2064 = NOVALUE;
    int _2061 = NOVALUE;
    int _2059 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_yylower_4009)) {
        _1 = (long)(DBL_PTR(_yylower_4009)->dbl);
        DeRefDS(_yylower_4009);
        _yylower_4009 = _1;
    }

    /** 	integer fpos = 1, spos = 1, maxlen, rpos */
    _fpos_4011 = 1;
    _spos_4012 = 1;

    /** 	sequence res = {0,0,0,0,0,0}*/
    _0 = _res_4015;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _res_4015 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	while fpos <= length(fmt) do*/
L1: 
    if (IS_SEQUENCE(_fmt_4008)){
            _2059 = SEQ_PTR(_fmt_4008)->length;
    }
    else {
        _2059 = 1;
    }
    if (_fpos_4011 > _2059)
    goto L2; // [34] 482

    /** 		if fmt[fpos] = '%' then*/
    _2 = (int)SEQ_PTR(_fmt_4008);
    _2061 = (int)*(((s1_ptr)_2)->base + _fpos_4011);
    if (binary_op_a(NOTEQ, _2061, 37)){
        _2061 = NOVALUE;
        goto L3; // [44] 471
    }
    _2061 = NOVALUE;

    /** 			fpos += 1*/
    _fpos_4011 = _fpos_4011 + 1;

    /** 			switch fmt[fpos] do*/
    _2 = (int)SEQ_PTR(_fmt_4008);
    _2064 = (int)*(((s1_ptr)_2)->base + _fpos_4011);
    if (IS_SEQUENCE(_2064) ){
        goto L4; // [60] 179
    }
    if(!IS_ATOM_INT(_2064)){
        if( (DBL_PTR(_2064)->dbl != (double) ((int) DBL_PTR(_2064)->dbl) ) ){
            goto L4; // [60] 179
        }
        _0 = (int) DBL_PTR(_2064)->dbl;
    }
    else {
        _0 = _2064;
    };
    _2064 = NOVALUE;
    switch ( _0 ){ 

        /** 				case 'Y' then*/
        case 89:

        /** 					rpos = 1*/
        _rpos_4014 = 1;

        /** 					maxlen = 4*/
        _maxlen_4013 = 4;
        goto L5; // [79] 187

        /** 				case 'y' then*/
        case 121:

        /** 					rpos = 1*/
        _rpos_4014 = 1;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [95] 187

        /** 				case 'm' then*/
        case 109:

        /** 					rpos = 2*/
        _rpos_4014 = 2;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [111] 187

        /** 				case 'd' then*/
        case 100:

        /** 					rpos = 3*/
        _rpos_4014 = 3;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [127] 187

        /** 				case 'H' then*/
        case 72:

        /** 					rpos = 4*/
        _rpos_4014 = 4;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [143] 187

        /** 				case 'M' then*/
        case 77:

        /** 					rpos = 5*/
        _rpos_4014 = 5;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [159] 187

        /** 				case 'S' then*/
        case 83:

        /** 					rpos = 6*/
        _rpos_4014 = 6;

        /** 					maxlen = 2*/
        _maxlen_4013 = 2;
        goto L5; // [175] 187

        /** 				case else*/
        default:
L4: 

        /** 					rpos = 0*/
        _rpos_4014 = 0;
    ;}L5: 

    /** 			if rpos then*/
    if (_rpos_4014 == 0)
    {
        goto L6; // [191] 468
    }
    else{
    }

    /** 				sequence got*/

    /** 				integer epos*/

    /** 				while spos <= length(val) do*/
L7: 
    if (IS_SEQUENCE(_val_4007)){
            _2067 = SEQ_PTR(_val_4007)->length;
    }
    else {
        _2067 = 1;
    }
    if (_spos_4012 > _2067)
    goto L8; // [206] 239

    /** 					if types:t_digit(val[spos]) then*/
    _2 = (int)SEQ_PTR(_val_4007);
    _2069 = (int)*(((s1_ptr)_2)->base + _spos_4012);
    Ref(_2069);
    _2070 = _7t_digit(_2069);
    _2069 = NOVALUE;
    if (_2070 == 0) {
        DeRef(_2070);
        _2070 = NOVALUE;
        goto L9; // [220] 228
    }
    else {
        if (!IS_ATOM_INT(_2070) && DBL_PTR(_2070)->dbl == 0.0){
            DeRef(_2070);
            _2070 = NOVALUE;
            goto L9; // [220] 228
        }
        DeRef(_2070);
        _2070 = NOVALUE;
    }
    DeRef(_2070);
    _2070 = NOVALUE;

    /** 						exit*/
    goto L8; // [225] 239
L9: 

    /** 					spos += 1*/
    _spos_4012 = _spos_4012 + 1;

    /** 				end while*/
    goto L7; // [236] 203
L8: 

    /** 				epos = spos + 1*/
    _epos_4037 = _spos_4012 + 1;

    /** 				while epos <= length(val) and epos < spos + maxlen do*/
LA: 
    if (IS_SEQUENCE(_val_4007)){
            _2073 = SEQ_PTR(_val_4007)->length;
    }
    else {
        _2073 = 1;
    }
    _2074 = (_epos_4037 <= _2073);
    _2073 = NOVALUE;
    if (_2074 == 0) {
        goto LB; // [257] 304
    }
    _2076 = _spos_4012 + _maxlen_4013;
    if ((long)((unsigned long)_2076 + (unsigned long)HIGH_BITS) >= 0) 
    _2076 = NewDouble((double)_2076);
    if (IS_ATOM_INT(_2076)) {
        _2077 = (_epos_4037 < _2076);
    }
    else {
        _2077 = ((double)_epos_4037 < DBL_PTR(_2076)->dbl);
    }
    DeRef(_2076);
    _2076 = NOVALUE;
    if (_2077 == 0)
    {
        DeRef(_2077);
        _2077 = NOVALUE;
        goto LB; // [272] 304
    }
    else{
        DeRef(_2077);
        _2077 = NOVALUE;
    }

    /** 					if not types:t_digit(val[epos]) then*/
    _2 = (int)SEQ_PTR(_val_4007);
    _2078 = (int)*(((s1_ptr)_2)->base + _epos_4037);
    Ref(_2078);
    _2079 = _7t_digit(_2078);
    _2078 = NOVALUE;
    if (IS_ATOM_INT(_2079)) {
        if (_2079 != 0){
            DeRef(_2079);
            _2079 = NOVALUE;
            goto LC; // [285] 293
        }
    }
    else {
        if (DBL_PTR(_2079)->dbl != 0.0){
            DeRef(_2079);
            _2079 = NOVALUE;
            goto LC; // [285] 293
        }
    }
    DeRef(_2079);
    _2079 = NOVALUE;

    /** 						exit*/
    goto LB; // [290] 304
LC: 

    /** 					epos += 1*/
    _epos_4037 = _epos_4037 + 1;

    /** 				end while*/
    goto LA; // [301] 250
LB: 

    /** 				if spos > length(val) then*/
    if (IS_SEQUENCE(_val_4007)){
            _2082 = SEQ_PTR(_val_4007)->length;
    }
    else {
        _2082 = 1;
    }
    if (_spos_4012 <= _2082)
    goto LD; // [309] 320

    /** 					return -1*/
    DeRef(_got_4036);
    DeRefDS(_val_4007);
    DeRefDS(_fmt_4008);
    DeRef(_res_4015);
    DeRef(_2074);
    _2074 = NOVALUE;
    return -1;
LD: 

    /** 				got = stdget:value(val[spos .. epos-1], , stdget:GET_LONG_ANSWER)*/
    _2084 = _epos_4037 - 1;
    rhs_slice_target = (object_ptr)&_2085;
    RHS_Slice(_val_4007, _spos_4012, _2084);
    DeRef(_st_inlined_value_at_332_4063);
    _st_inlined_value_at_332_4063 = _2085;
    _2085 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_LONG_ANSWER_3241)) {
        _1 = (long)(DBL_PTR(_17GET_LONG_ANSWER_3241)->dbl);
        DeRefDS(_17GET_LONG_ANSWER_3241);
        _17GET_LONG_ANSWER_3241 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_332_4063);
    _0 = _got_4036;
    _got_4036 = _17get_value(_st_inlined_value_at_332_4063, 1, _17GET_LONG_ANSWER_3241);
    DeRef(_0);
    DeRef(_st_inlined_value_at_332_4063);
    _st_inlined_value_at_332_4063 = NOVALUE;

    /** 				if got[1] != stdget:GET_SUCCESS then*/
    _2 = (int)SEQ_PTR(_got_4036);
    _2086 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _2086, 0)){
        _2086 = NOVALUE;
        goto LE; // [359] 370
    }
    _2086 = NOVALUE;

    /** 					return -1*/
    DeRefDS(_got_4036);
    DeRefDS(_val_4007);
    DeRefDS(_fmt_4008);
    DeRef(_res_4015);
    DeRef(_2074);
    _2074 = NOVALUE;
    DeRef(_2084);
    _2084 = NOVALUE;
    return -1;
LE: 

    /** 				if fmt[fpos] = 'y' then*/
    _2 = (int)SEQ_PTR(_fmt_4008);
    _2088 = (int)*(((s1_ptr)_2)->base + _fpos_4011);
    if (binary_op_a(NOTEQ, _2088, 121)){
        _2088 = NOVALUE;
        goto LF; // [376] 450
    }
    _2088 = NOVALUE;

    /** 					integer century = floor(date_now[YEAR] / 100) * 100*/
    _2 = (int)SEQ_PTR(_12date_now_4001);
    _2090 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2090)) {
        if (100 > 0 && _2090 >= 0) {
            _2091 = _2090 / 100;
        }
        else {
            temp_dbl = floor((double)_2090 / (double)100);
            if (_2090 != MININT)
            _2091 = (long)temp_dbl;
            else
            _2091 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _2090, 100);
        _2091 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _2090 = NOVALUE;
    if (IS_ATOM_INT(_2091)) {
        _century_4071 = _2091 * 100;
    }
    else {
        _century_4071 = binary_op(MULTIPLY, _2091, 100);
    }
    DeRef(_2091);
    _2091 = NOVALUE;
    if (!IS_ATOM_INT(_century_4071)) {
        _1 = (long)(DBL_PTR(_century_4071)->dbl);
        DeRefDS(_century_4071);
        _century_4071 = _1;
    }

    /** 					integer year = got[2] + (century - 100)*/
    _2 = (int)SEQ_PTR(_got_4036);
    _2093 = (int)*(((s1_ptr)_2)->base + 2);
    _2094 = _century_4071 - 100;
    if ((long)((unsigned long)_2094 +(unsigned long) HIGH_BITS) >= 0){
        _2094 = NewDouble((double)_2094);
    }
    if (IS_ATOM_INT(_2093) && IS_ATOM_INT(_2094)) {
        _year_4075 = _2093 + _2094;
    }
    else {
        _year_4075 = binary_op(PLUS, _2093, _2094);
    }
    _2093 = NOVALUE;
    DeRef(_2094);
    _2094 = NOVALUE;
    if (!IS_ATOM_INT(_year_4075)) {
        _1 = (long)(DBL_PTR(_year_4075)->dbl);
        DeRefDS(_year_4075);
        _year_4075 = _1;
    }

    /** 					if year < (date_now[YEAR] + yylower) then*/
    _2 = (int)SEQ_PTR(_12date_now_4001);
    _2096 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2096)) {
        _2097 = _2096 + _yylower_4009;
        if ((long)((unsigned long)_2097 + (unsigned long)HIGH_BITS) >= 0) 
        _2097 = NewDouble((double)_2097);
    }
    else {
        _2097 = binary_op(PLUS, _2096, _yylower_4009);
    }
    _2096 = NOVALUE;
    if (binary_op_a(GREATEREQ, _year_4075, _2097)){
        DeRef(_2097);
        _2097 = NOVALUE;
        goto L10; // [426] 443
    }
    DeRef(_2097);
    _2097 = NOVALUE;

    /** 						year = got[2] + century*/
    _2 = (int)SEQ_PTR(_got_4036);
    _2099 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_2099)) {
        _year_4075 = _2099 + _century_4071;
    }
    else {
        _year_4075 = binary_op(PLUS, _2099, _century_4071);
    }
    _2099 = NOVALUE;
    if (!IS_ATOM_INT(_year_4075)) {
        _1 = (long)(DBL_PTR(_year_4075)->dbl);
        DeRefDS(_year_4075);
        _year_4075 = _1;
    }
L10: 

    /** 					got[2] = year*/
    _2 = (int)SEQ_PTR(_got_4036);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _got_4036 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _year_4075;
    DeRef(_1);
LF: 

    /** 				res[rpos] = got[2]*/
    _2 = (int)SEQ_PTR(_got_4036);
    _2101 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_2101);
    _2 = (int)SEQ_PTR(_res_4015);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _res_4015 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _rpos_4014);
    _1 = *(int *)_2;
    *(int *)_2 = _2101;
    if( _1 != _2101 ){
        DeRef(_1);
    }
    _2101 = NOVALUE;

    /** 				spos = epos*/
    _spos_4012 = _epos_4037;
L6: 
    DeRef(_got_4036);
    _got_4036 = NOVALUE;
L3: 

    /** 		fpos += 1*/
    _fpos_4011 = _fpos_4011 + 1;

    /** 	end while*/
    goto L1; // [479] 31
L2: 

    /** 	if not datetime(res) then*/
    RefDS(_res_4015);
    _2103 = _12datetime(_res_4015);
    if (IS_ATOM_INT(_2103)) {
        if (_2103 != 0){
            DeRef(_2103);
            _2103 = NOVALUE;
            goto L11; // [488] 498
        }
    }
    else {
        if (DBL_PTR(_2103)->dbl != 0.0){
            DeRef(_2103);
            _2103 = NOVALUE;
            goto L11; // [488] 498
        }
    }
    DeRef(_2103);
    _2103 = NOVALUE;

    /** 		return -1*/
    DeRefDS(_val_4007);
    DeRefDS(_fmt_4008);
    DeRefDS(_res_4015);
    DeRef(_2074);
    _2074 = NOVALUE;
    DeRef(_2084);
    _2084 = NOVALUE;
    return -1;
L11: 

    /** 	while spos <= length(val) do*/
L12: 
    if (IS_SEQUENCE(_val_4007)){
            _2105 = SEQ_PTR(_val_4007)->length;
    }
    else {
        _2105 = 1;
    }
    if (_spos_4012 > _2105)
    goto L13; // [506] 541

    /** 		if types:t_digit(val[spos]) then*/
    _2 = (int)SEQ_PTR(_val_4007);
    _2107 = (int)*(((s1_ptr)_2)->base + _spos_4012);
    Ref(_2107);
    _2108 = _7t_digit(_2107);
    _2107 = NOVALUE;
    if (_2108 == 0) {
        DeRef(_2108);
        _2108 = NOVALUE;
        goto L14; // [520] 530
    }
    else {
        if (!IS_ATOM_INT(_2108) && DBL_PTR(_2108)->dbl == 0.0){
            DeRef(_2108);
            _2108 = NOVALUE;
            goto L14; // [520] 530
        }
        DeRef(_2108);
        _2108 = NOVALUE;
    }
    DeRef(_2108);
    _2108 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_val_4007);
    DeRefDS(_fmt_4008);
    DeRef(_res_4015);
    DeRef(_2074);
    _2074 = NOVALUE;
    DeRef(_2084);
    _2084 = NOVALUE;
    return -1;
L14: 

    /** 		spos += 1*/
    _spos_4012 = _spos_4012 + 1;

    /** 	end while*/
    goto L12; // [538] 503
L13: 

    /** 	return new(res[1], res[2], res[3], res[4], res[5], res[6])*/
    _2 = (int)SEQ_PTR(_res_4015);
    _2110 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_res_4015);
    _2111 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_res_4015);
    _2112 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_res_4015);
    _2113 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_res_4015);
    _2114 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_res_4015);
    _2115 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_2110);
    Ref(_2111);
    Ref(_2112);
    Ref(_2113);
    Ref(_2114);
    Ref(_2115);
    _2116 = _12new(_2110, _2111, _2112, _2113, _2114, _2115);
    _2110 = NOVALUE;
    _2111 = NOVALUE;
    _2112 = NOVALUE;
    _2113 = NOVALUE;
    _2114 = NOVALUE;
    _2115 = NOVALUE;
    DeRefDS(_val_4007);
    DeRefDS(_fmt_4008);
    DeRefDS(_res_4015);
    DeRef(_2074);
    _2074 = NOVALUE;
    DeRef(_2084);
    _2084 = NOVALUE;
    return _2116;
    ;
}


int _12add(int _dt_4106, int _qty_4107, int _interval_4108)
{
    int _inc_4109 = NOVALUE;
    int _2162 = NOVALUE;
    int _2161 = NOVALUE;
    int _2160 = NOVALUE;
    int _2157 = NOVALUE;
    int _2155 = NOVALUE;
    int _2154 = NOVALUE;
    int _2153 = NOVALUE;
    int _2152 = NOVALUE;
    int _2151 = NOVALUE;
    int _2150 = NOVALUE;
    int _2149 = NOVALUE;
    int _2148 = NOVALUE;
    int _2147 = NOVALUE;
    int _2146 = NOVALUE;
    int _2144 = NOVALUE;
    int _2143 = NOVALUE;
    int _2142 = NOVALUE;
    int _2141 = NOVALUE;
    int _2140 = NOVALUE;
    int _2139 = NOVALUE;
    int _2138 = NOVALUE;
    int _2137 = NOVALUE;
    int _2136 = NOVALUE;
    int _2135 = NOVALUE;
    int _2134 = NOVALUE;
    int _2133 = NOVALUE;
    int _2132 = NOVALUE;
    int _2131 = NOVALUE;
    int _2130 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_interval_4108)) {
        _1 = (long)(DBL_PTR(_interval_4108)->dbl);
        DeRefDS(_interval_4108);
        _interval_4108 = _1;
    }

    /** 	if interval = SECONDS then*/
    if (_interval_4108 != 7)
    goto L1; // [5] 12
    goto L2; // [9] 340
L1: 

    /** 	elsif interval = MINUTES then*/
    if (_interval_4108 != 6)
    goto L3; // [14] 27

    /** 		qty *= 60*/
    _0 = _qty_4107;
    if (IS_ATOM_INT(_qty_4107)) {
        if (_qty_4107 == (short)_qty_4107)
        _qty_4107 = _qty_4107 * 60;
        else
        _qty_4107 = NewDouble(_qty_4107 * (double)60);
    }
    else {
        _qty_4107 = binary_op(MULTIPLY, _qty_4107, 60);
    }
    DeRef(_0);
    goto L2; // [24] 340
L3: 

    /** 	elsif interval = HOURS then*/
    if (_interval_4108 != 5)
    goto L4; // [29] 42

    /** 		qty *= 3600*/
    _0 = _qty_4107;
    if (IS_ATOM_INT(_qty_4107)) {
        if (_qty_4107 == (short)_qty_4107)
        _qty_4107 = _qty_4107 * 3600;
        else
        _qty_4107 = NewDouble(_qty_4107 * (double)3600);
    }
    else {
        _qty_4107 = binary_op(MULTIPLY, _qty_4107, 3600);
    }
    DeRef(_0);
    goto L2; // [39] 340
L4: 

    /** 	elsif interval = DAYS then*/
    if (_interval_4108 != 4)
    goto L5; // [44] 57

    /** 		qty *= 86400*/
    _0 = _qty_4107;
    if (IS_ATOM_INT(_qty_4107)) {
        _qty_4107 = NewDouble(_qty_4107 * (double)86400);
    }
    else {
        _qty_4107 = binary_op(MULTIPLY, _qty_4107, 86400);
    }
    DeRef(_0);
    goto L2; // [54] 340
L5: 

    /** 	elsif interval = WEEKS then*/
    if (_interval_4108 != 3)
    goto L6; // [59] 72

    /** 		qty *= 604800*/
    _0 = _qty_4107;
    if (IS_ATOM_INT(_qty_4107)) {
        _qty_4107 = NewDouble(_qty_4107 * (double)604800);
    }
    else {
        _qty_4107 = binary_op(MULTIPLY, _qty_4107, 604800);
    }
    DeRef(_0);
    goto L2; // [69] 340
L6: 

    /** 	elsif interval = MONTHS then*/
    if (_interval_4108 != 2)
    goto L7; // [74] 238

    /** 		if qty > 0 then*/
    if (binary_op_a(LESSEQ, _qty_4107, 0)){
        goto L8; // [80] 92
    }

    /** 			inc = 1*/
    _inc_4109 = 1;
    goto L9; // [89] 103
L8: 

    /** 			inc = -1*/
    _inc_4109 = -1;

    /** 			qty = -(qty)*/
    _0 = _qty_4107;
    if (IS_ATOM_INT(_qty_4107)) {
        if ((unsigned long)_qty_4107 == 0xC0000000)
        _qty_4107 = (int)NewDouble((double)-0xC0000000);
        else
        _qty_4107 = - _qty_4107;
    }
    else {
        _qty_4107 = unary_op(UMINUS, _qty_4107);
    }
    DeRef(_0);
L9: 

    /** 		for i = 1 to qty do*/
    Ref(_qty_4107);
    DeRef(_2130);
    _2130 = _qty_4107;
    {
        int _i_4132;
        _i_4132 = 1;
LA: 
        if (binary_op_a(GREATER, _i_4132, _2130)){
            goto LB; // [108] 229
        }

        /** 			if inc = 1 and dt[MONTH] = 12 then*/
        _2131 = (_inc_4109 == 1);
        if (_2131 == 0) {
            goto LC; // [123] 162
        }
        _2 = (int)SEQ_PTR(_dt_4106);
        _2133 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2133)) {
            _2134 = (_2133 == 12);
        }
        else {
            _2134 = binary_op(EQUALS, _2133, 12);
        }
        _2133 = NOVALUE;
        if (_2134 == 0) {
            DeRef(_2134);
            _2134 = NOVALUE;
            goto LC; // [136] 162
        }
        else {
            if (!IS_ATOM_INT(_2134) && DBL_PTR(_2134)->dbl == 0.0){
                DeRef(_2134);
                _2134 = NOVALUE;
                goto LC; // [136] 162
            }
            DeRef(_2134);
            _2134 = NOVALUE;
        }
        DeRef(_2134);
        _2134 = NOVALUE;

        /** 				dt[MONTH] = 1*/
        _2 = (int)SEQ_PTR(_dt_4106);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4106 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);

        /** 				dt[YEAR] += 1*/
        _2 = (int)SEQ_PTR(_dt_4106);
        _2135 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2135)) {
            _2136 = _2135 + 1;
            if (_2136 > MAXINT){
                _2136 = NewDouble((double)_2136);
            }
        }
        else
        _2136 = binary_op(PLUS, 1, _2135);
        _2135 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4106);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4106 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _2136;
        if( _1 != _2136 ){
            DeRef(_1);
        }
        _2136 = NOVALUE;
        goto LD; // [159] 222
LC: 

        /** 			elsif inc = -1 and dt[MONTH] = 1 then*/
        _2137 = (_inc_4109 == -1);
        if (_2137 == 0) {
            goto LE; // [168] 207
        }
        _2 = (int)SEQ_PTR(_dt_4106);
        _2139 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2139)) {
            _2140 = (_2139 == 1);
        }
        else {
            _2140 = binary_op(EQUALS, _2139, 1);
        }
        _2139 = NOVALUE;
        if (_2140 == 0) {
            DeRef(_2140);
            _2140 = NOVALUE;
            goto LE; // [181] 207
        }
        else {
            if (!IS_ATOM_INT(_2140) && DBL_PTR(_2140)->dbl == 0.0){
                DeRef(_2140);
                _2140 = NOVALUE;
                goto LE; // [181] 207
            }
            DeRef(_2140);
            _2140 = NOVALUE;
        }
        DeRef(_2140);
        _2140 = NOVALUE;

        /** 				dt[MONTH] = 12*/
        _2 = (int)SEQ_PTR(_dt_4106);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4106 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 12;
        DeRef(_1);

        /** 				dt[YEAR] -= 1*/
        _2 = (int)SEQ_PTR(_dt_4106);
        _2141 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_2141)) {
            _2142 = _2141 - 1;
            if ((long)((unsigned long)_2142 +(unsigned long) HIGH_BITS) >= 0){
                _2142 = NewDouble((double)_2142);
            }
        }
        else {
            _2142 = binary_op(MINUS, _2141, 1);
        }
        _2141 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4106);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4106 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _2142;
        if( _1 != _2142 ){
            DeRef(_1);
        }
        _2142 = NOVALUE;
        goto LD; // [204] 222
LE: 

        /** 				dt[MONTH] += inc*/
        _2 = (int)SEQ_PTR(_dt_4106);
        _2143 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_2143)) {
            _2144 = _2143 + _inc_4109;
            if ((long)((unsigned long)_2144 + (unsigned long)HIGH_BITS) >= 0) 
            _2144 = NewDouble((double)_2144);
        }
        else {
            _2144 = binary_op(PLUS, _2143, _inc_4109);
        }
        _2143 = NOVALUE;
        _2 = (int)SEQ_PTR(_dt_4106);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _dt_4106 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _2144;
        if( _1 != _2144 ){
            DeRef(_1);
        }
        _2144 = NOVALUE;
LD: 

        /** 		end for*/
        _0 = _i_4132;
        if (IS_ATOM_INT(_i_4132)) {
            _i_4132 = _i_4132 + 1;
            if ((long)((unsigned long)_i_4132 +(unsigned long) HIGH_BITS) >= 0){
                _i_4132 = NewDouble((double)_i_4132);
            }
        }
        else {
            _i_4132 = binary_op_a(PLUS, _i_4132, 1);
        }
        DeRef(_0);
        goto LA; // [224] 115
LB: 
        ;
        DeRef(_i_4132);
    }

    /** 		return dt*/
    DeRef(_qty_4107);
    DeRef(_2131);
    _2131 = NOVALUE;
    DeRef(_2137);
    _2137 = NOVALUE;
    return _dt_4106;
    goto L2; // [235] 340
L7: 

    /** 	elsif interval = YEARS then*/
    if (_interval_4108 != 1)
    goto LF; // [240] 326

    /** 		dt[YEAR] += qty*/
    _2 = (int)SEQ_PTR(_dt_4106);
    _2146 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_2146) && IS_ATOM_INT(_qty_4107)) {
        _2147 = _2146 + _qty_4107;
        if ((long)((unsigned long)_2147 + (unsigned long)HIGH_BITS) >= 0) 
        _2147 = NewDouble((double)_2147);
    }
    else {
        _2147 = binary_op(PLUS, _2146, _qty_4107);
    }
    _2146 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_4106);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4106 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _2147;
    if( _1 != _2147 ){
        DeRef(_1);
    }
    _2147 = NOVALUE;

    /** 		if isLeap(dt[YEAR]) = 0 and dt[MONTH] = 2 and dt[DAY] = 29 then*/
    _2 = (int)SEQ_PTR(_dt_4106);
    _2148 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_2148);
    _2149 = _12isLeap(_2148);
    _2148 = NOVALUE;
    if (IS_ATOM_INT(_2149)) {
        _2150 = (_2149 == 0);
    }
    else {
        _2150 = binary_op(EQUALS, _2149, 0);
    }
    DeRef(_2149);
    _2149 = NOVALUE;
    if (IS_ATOM_INT(_2150)) {
        if (_2150 == 0) {
            DeRef(_2151);
            _2151 = 0;
            goto L10; // [272] 288
        }
    }
    else {
        if (DBL_PTR(_2150)->dbl == 0.0) {
            DeRef(_2151);
            _2151 = 0;
            goto L10; // [272] 288
        }
    }
    _2 = (int)SEQ_PTR(_dt_4106);
    _2152 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_2152)) {
        _2153 = (_2152 == 2);
    }
    else {
        _2153 = binary_op(EQUALS, _2152, 2);
    }
    _2152 = NOVALUE;
    DeRef(_2151);
    if (IS_ATOM_INT(_2153))
    _2151 = (_2153 != 0);
    else
    _2151 = DBL_PTR(_2153)->dbl != 0.0;
L10: 
    if (_2151 == 0) {
        goto L11; // [288] 317
    }
    _2 = (int)SEQ_PTR(_dt_4106);
    _2155 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_2155)) {
        _2157 = (_2155 == 29);
    }
    else {
        _2157 = binary_op(EQUALS, _2155, 29);
    }
    _2155 = NOVALUE;
    if (_2157 == 0) {
        DeRef(_2157);
        _2157 = NOVALUE;
        goto L11; // [301] 317
    }
    else {
        if (!IS_ATOM_INT(_2157) && DBL_PTR(_2157)->dbl == 0.0){
            DeRef(_2157);
            _2157 = NOVALUE;
            goto L11; // [301] 317
        }
        DeRef(_2157);
        _2157 = NOVALUE;
    }
    DeRef(_2157);
    _2157 = NOVALUE;

    /** 			dt[MONTH] = 3*/
    _2 = (int)SEQ_PTR(_dt_4106);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4106 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 			dt[DAY] = 1*/
    _2 = (int)SEQ_PTR(_dt_4106);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _dt_4106 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L11: 

    /** 		return dt*/
    DeRef(_qty_4107);
    DeRef(_2131);
    _2131 = NOVALUE;
    DeRef(_2137);
    _2137 = NOVALUE;
    DeRef(_2150);
    _2150 = NOVALUE;
    DeRef(_2153);
    _2153 = NOVALUE;
    return _dt_4106;
    goto L2; // [323] 340
LF: 

    /** 	elsif interval = DATE then*/
    if (_interval_4108 != 8)
    goto L12; // [328] 339

    /** 		qty = datetimeToSeconds(qty)*/
    Ref(_qty_4107);
    _0 = _qty_4107;
    _qty_4107 = _12datetimeToSeconds(_qty_4107);
    DeRef(_0);
L12: 
L2: 

    /** 	return secondsToDateTime(datetimeToSeconds(dt) + qty)*/
    Ref(_dt_4106);
    _2160 = _12datetimeToSeconds(_dt_4106);
    if (IS_ATOM_INT(_2160) && IS_ATOM_INT(_qty_4107)) {
        _2161 = _2160 + _qty_4107;
        if ((long)((unsigned long)_2161 + (unsigned long)HIGH_BITS) >= 0) 
        _2161 = NewDouble((double)_2161);
    }
    else {
        _2161 = binary_op(PLUS, _2160, _qty_4107);
    }
    DeRef(_2160);
    _2160 = NOVALUE;
    _2162 = _12secondsToDateTime(_2161);
    _2161 = NOVALUE;
    DeRef(_dt_4106);
    DeRef(_qty_4107);
    DeRef(_2131);
    _2131 = NOVALUE;
    DeRef(_2137);
    _2137 = NOVALUE;
    DeRef(_2150);
    _2150 = NOVALUE;
    DeRef(_2153);
    _2153 = NOVALUE;
    return _2162;
    ;
}


int _12subtract(int _dt_4174, int _qty_4175, int _interval_4176)
{
    int _2164 = NOVALUE;
    int _2163 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_interval_4176)) {
        _1 = (long)(DBL_PTR(_interval_4176)->dbl);
        DeRefDS(_interval_4176);
        _interval_4176 = _1;
    }

    /** 	return add(dt, -(qty), interval)*/
    if (IS_ATOM_INT(_qty_4175)) {
        if ((unsigned long)_qty_4175 == 0xC0000000)
        _2163 = (int)NewDouble((double)-0xC0000000);
        else
        _2163 = - _qty_4175;
    }
    else {
        _2163 = unary_op(UMINUS, _qty_4175);
    }
    Ref(_dt_4174);
    _2164 = _12add(_dt_4174, _2163, _interval_4176);
    _2163 = NOVALUE;
    DeRef(_dt_4174);
    DeRef(_qty_4175);
    return _2164;
    ;
}
int subtract() __attribute__ ((alias ("_12subtract")));


int _12diff(int _dt1_4181, int _dt2_4182)
{
    int _2167 = NOVALUE;
    int _2166 = NOVALUE;
    int _2165 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_dt2_4182);
    _2165 = _12datetimeToSeconds(_dt2_4182);
    Ref(_dt1_4181);
    _2166 = _12datetimeToSeconds(_dt1_4181);
    if (IS_ATOM_INT(_2165) && IS_ATOM_INT(_2166)) {
        _2167 = _2165 - _2166;
        if ((long)((unsigned long)_2167 +(unsigned long) HIGH_BITS) >= 0){
            _2167 = NewDouble((double)_2167);
        }
    }
    else {
        _2167 = binary_op(MINUS, _2165, _2166);
    }
    DeRef(_2165);
    _2165 = NOVALUE;
    DeRef(_2166);
    _2166 = NOVALUE;
    DeRef(_dt1_4181);
    DeRef(_dt2_4182);
    return _2167;
    ;
}
int diff() __attribute__ ((alias ("_12diff")));



// 0x473B8F66
