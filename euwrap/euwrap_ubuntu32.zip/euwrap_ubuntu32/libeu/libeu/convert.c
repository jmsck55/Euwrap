// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _8int_to_bytes(int _x_1368)
{
    int _a_1369 = NOVALUE;
    int _b_1370 = NOVALUE;
    int _c_1371 = NOVALUE;
    int _d_1372 = NOVALUE;
    int _730 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1368)) {
        _a_1369 = (_x_1368 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_1369 = Dremainder(DBL_PTR(_x_1368), &temp_d);
    }
    if (!IS_ATOM_INT(_a_1369)) {
        _1 = (long)(DBL_PTR(_a_1369)->dbl);
        DeRefDS(_a_1369);
        _a_1369 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1368;
    if (IS_ATOM_INT(_x_1368)) {
        if (256 > 0 && _x_1368 >= 0) {
            _x_1368 = _x_1368 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1368 / (double)256);
            if (_x_1368 != MININT)
            _x_1368 = (long)temp_dbl;
            else
            _x_1368 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1368, 256);
        _x_1368 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1368)) {
        _b_1370 = (_x_1368 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_1370 = Dremainder(DBL_PTR(_x_1368), &temp_d);
    }
    if (!IS_ATOM_INT(_b_1370)) {
        _1 = (long)(DBL_PTR(_b_1370)->dbl);
        DeRefDS(_b_1370);
        _b_1370 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1368;
    if (IS_ATOM_INT(_x_1368)) {
        if (256 > 0 && _x_1368 >= 0) {
            _x_1368 = _x_1368 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1368 / (double)256);
            if (_x_1368 != MININT)
            _x_1368 = (long)temp_dbl;
            else
            _x_1368 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1368, 256);
        _x_1368 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1368)) {
        _c_1371 = (_x_1368 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_1371 = Dremainder(DBL_PTR(_x_1368), &temp_d);
    }
    if (!IS_ATOM_INT(_c_1371)) {
        _1 = (long)(DBL_PTR(_c_1371)->dbl);
        DeRefDS(_c_1371);
        _c_1371 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1368;
    if (IS_ATOM_INT(_x_1368)) {
        if (256 > 0 && _x_1368 >= 0) {
            _x_1368 = _x_1368 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1368 / (double)256);
            if (_x_1368 != MININT)
            _x_1368 = (long)temp_dbl;
            else
            _x_1368 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1368, 256);
        _x_1368 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1368)) {
        _d_1372 = (_x_1368 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_1372 = Dremainder(DBL_PTR(_x_1368), &temp_d);
    }
    if (!IS_ATOM_INT(_d_1372)) {
        _1 = (long)(DBL_PTR(_d_1372)->dbl);
        DeRefDS(_d_1372);
        _d_1372 = _1;
    }

    /** 	return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_1369;
    *((int *)(_2+8)) = _b_1370;
    *((int *)(_2+12)) = _c_1371;
    *((int *)(_2+16)) = _d_1372;
    _730 = MAKE_SEQ(_1);
    DeRef(_x_1368);
    return _730;
    ;
}
int int_to_bytes() __attribute__ ((alias ("_8int_to_bytes")));


int _8bytes_to_int(int _s_1394)
{
    int _744 = NOVALUE;
    int _743 = NOVALUE;
    int _742 = NOVALUE;
    int _741 = NOVALUE;
    int _740 = NOVALUE;
    int _739 = NOVALUE;
    int _737 = NOVALUE;
    int _735 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(s) = 4 then*/
    if (IS_SEQUENCE(_s_1394)){
            _735 = SEQ_PTR(_s_1394)->length;
    }
    else {
        _735 = 1;
    }
    if (_735 != 4)
    goto L1; // [8] 22

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_8mem_1364)){
        poke_addr = (unsigned char *)_8mem_1364;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem_1364)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_1394);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    goto L2; // [19] 69
L1: 

    /** 	elsif length(s) < 4 then*/
    if (IS_SEQUENCE(_s_1394)){
            _737 = SEQ_PTR(_s_1394)->length;
    }
    else {
        _737 = 1;
    }
    if (_737 >= 4)
    goto L3; // [27] 56

    /** 		poke(mem, s & repeat(0, 4 - length(s))) -- avoid breaking old code*/
    if (IS_SEQUENCE(_s_1394)){
            _739 = SEQ_PTR(_s_1394)->length;
    }
    else {
        _739 = 1;
    }
    _740 = 4 - _739;
    _739 = NOVALUE;
    _741 = Repeat(0, _740);
    _740 = NOVALUE;
    Concat((object_ptr)&_742, _s_1394, _741);
    DeRefDS(_741);
    _741 = NOVALUE;
    if (IS_ATOM_INT(_8mem_1364)){
        poke_addr = (unsigned char *)_8mem_1364;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem_1364)->dbl);
    }
    _1 = (int)SEQ_PTR(_742);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_742);
    _742 = NOVALUE;
    goto L2; // [53] 69
L3: 

    /** 		poke(mem, s[1..4]) -- avoid breaking old code*/
    rhs_slice_target = (object_ptr)&_743;
    RHS_Slice(_s_1394, 1, 4);
    if (IS_ATOM_INT(_8mem_1364)){
        poke_addr = (unsigned char *)_8mem_1364;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem_1364)->dbl);
    }
    _1 = (int)SEQ_PTR(_743);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_743);
    _743 = NOVALUE;
L2: 

    /** 	return peek4u(mem)*/
    if (IS_ATOM_INT(_8mem_1364)) {
        _744 = *(unsigned long *)_8mem_1364;
        if ((unsigned)_744 > (unsigned)MAXINT)
        _744 = NewDouble((double)(unsigned long)_744);
    }
    else {
        _744 = *(unsigned long *)(unsigned long)(DBL_PTR(_8mem_1364)->dbl);
        if ((unsigned)_744 > (unsigned)MAXINT)
        _744 = NewDouble((double)(unsigned long)_744);
    }
    DeRefDS(_s_1394);
    return _744;
    ;
}
int bytes_to_int() __attribute__ ((alias ("_8bytes_to_int")));


int _8int_to_bits(int _x_1410, int _nbits_1411)
{
    int _bits_1412 = NOVALUE;
    int _mask_1413 = NOVALUE;
    int _756 = NOVALUE;
    int _755 = NOVALUE;
    int _753 = NOVALUE;
    int _750 = NOVALUE;
    int _749 = NOVALUE;
    int _748 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nbits_1411)) {
        _1 = (long)(DBL_PTR(_nbits_1411)->dbl);
        DeRefDS(_nbits_1411);
        _nbits_1411 = _1;
    }

    /** 	if nbits < 1 then*/
    if (_nbits_1411 >= 1)
    goto L1; // [5] 16

    /** 		return {}*/
    RefDS(_5);
    DeRef(_x_1410);
    DeRef(_bits_1412);
    DeRef(_mask_1413);
    return _5;
L1: 

    /** 	bits = repeat(0, nbits)*/
    DeRef(_bits_1412);
    _bits_1412 = Repeat(0, _nbits_1411);

    /** 	if nbits <= 32 then*/
    if (_nbits_1411 > 32)
    goto L2; // [24] 75

    /** 		mask = 1*/
    DeRef(_mask_1413);
    _mask_1413 = 1;

    /** 		for i = 1 to nbits do*/
    _748 = _nbits_1411;
    {
        int _i_1420;
        _i_1420 = 1;
L3: 
        if (_i_1420 > _748){
            goto L4; // [38] 72
        }

        /** 			bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_1410) && IS_ATOM_INT(_mask_1413)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_1410 & (unsigned long)_mask_1413;
                 _749 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_1410)) {
                temp_d.dbl = (double)_x_1410;
                _749 = Dand_bits(&temp_d, DBL_PTR(_mask_1413));
            }
            else {
                if (IS_ATOM_INT(_mask_1413)) {
                    temp_d.dbl = (double)_mask_1413;
                    _749 = Dand_bits(DBL_PTR(_x_1410), &temp_d);
                }
                else
                _749 = Dand_bits(DBL_PTR(_x_1410), DBL_PTR(_mask_1413));
            }
        }
        if (IS_ATOM_INT(_749)) {
            _750 = (_749 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _750 = Dand(DBL_PTR(_749), &temp_d);
        }
        DeRef(_749);
        _749 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_1412);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1412 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1420);
        _1 = *(int *)_2;
        *(int *)_2 = _750;
        if( _1 != _750 ){
            DeRef(_1);
        }
        _750 = NOVALUE;

        /** 			mask *= 2*/
        _0 = _mask_1413;
        if (IS_ATOM_INT(_mask_1413) && IS_ATOM_INT(_mask_1413)) {
            _mask_1413 = _mask_1413 + _mask_1413;
            if ((long)((unsigned long)_mask_1413 + (unsigned long)HIGH_BITS) >= 0) 
            _mask_1413 = NewDouble((double)_mask_1413);
        }
        else {
            if (IS_ATOM_INT(_mask_1413)) {
                _mask_1413 = NewDouble((double)_mask_1413 + DBL_PTR(_mask_1413)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_1413)) {
                    _mask_1413 = NewDouble(DBL_PTR(_mask_1413)->dbl + (double)_mask_1413);
                }
                else
                _mask_1413 = NewDouble(DBL_PTR(_mask_1413)->dbl + DBL_PTR(_mask_1413)->dbl);
            }
        }
        DeRef(_0);

        /** 		end for*/
        _i_1420 = _i_1420 + 1;
        goto L3; // [67] 45
L4: 
        ;
    }
    goto L5; // [72] 128
L2: 

    /** 		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_1410, 0)){
        goto L6; // [77] 92
    }

    /** 			x += power(2, nbits) -- for 2's complement bit pattern*/
    _753 = power(2, _nbits_1411);
    _0 = _x_1410;
    if (IS_ATOM_INT(_x_1410) && IS_ATOM_INT(_753)) {
        _x_1410 = _x_1410 + _753;
        if ((long)((unsigned long)_x_1410 + (unsigned long)HIGH_BITS) >= 0) 
        _x_1410 = NewDouble((double)_x_1410);
    }
    else {
        if (IS_ATOM_INT(_x_1410)) {
            _x_1410 = NewDouble((double)_x_1410 + DBL_PTR(_753)->dbl);
        }
        else {
            if (IS_ATOM_INT(_753)) {
                _x_1410 = NewDouble(DBL_PTR(_x_1410)->dbl + (double)_753);
            }
            else
            _x_1410 = NewDouble(DBL_PTR(_x_1410)->dbl + DBL_PTR(_753)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_753);
    _753 = NOVALUE;
L6: 

    /** 		for i = 1 to nbits do*/
    _755 = _nbits_1411;
    {
        int _i_1431;
        _i_1431 = 1;
L7: 
        if (_i_1431 > _755){
            goto L8; // [97] 127
        }

        /** 			bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_1410)) {
            _756 = (_x_1410 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _756 = Dremainder(DBL_PTR(_x_1410), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_1412);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1412 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1431);
        _1 = *(int *)_2;
        *(int *)_2 = _756;
        if( _1 != _756 ){
            DeRef(_1);
        }
        _756 = NOVALUE;

        /** 			x = floor(x / 2)*/
        _0 = _x_1410;
        if (IS_ATOM_INT(_x_1410)) {
            _x_1410 = _x_1410 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_1410, 2);
            _x_1410 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 		end for*/
        _i_1431 = _i_1431 + 1;
        goto L7; // [122] 104
L8: 
        ;
    }
L5: 

    /** 	return bits*/
    DeRef(_x_1410);
    DeRef(_mask_1413);
    return _bits_1412;
    ;
}
int int_to_bits() __attribute__ ((alias ("_8int_to_bits")));


int _8bits_to_int(int _bits_1437)
{
    int _value_1438 = NOVALUE;
    int _p_1439 = NOVALUE;
    int _759 = NOVALUE;
    int _758 = NOVALUE;
    int _0, _1, _2;
    

    /** 	value = 0*/
    DeRef(_value_1438);
    _value_1438 = 0;

    /** 	p = 1*/
    DeRef(_p_1439);
    _p_1439 = 1;

    /** 	for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_1437)){
            _758 = SEQ_PTR(_bits_1437)->length;
    }
    else {
        _758 = 1;
    }
    {
        int _i_1441;
        _i_1441 = 1;
L1: 
        if (_i_1441 > _758){
            goto L2; // [18] 54
        }

        /** 		if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_1437);
        _759 = (int)*(((s1_ptr)_2)->base + _i_1441);
        if (_759 == 0) {
            _759 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_759) && DBL_PTR(_759)->dbl == 0.0){
                _759 = NOVALUE;
                goto L3; // [31] 41
            }
            _759 = NOVALUE;
        }
        _759 = NOVALUE;

        /** 			value += p*/
        _0 = _value_1438;
        if (IS_ATOM_INT(_value_1438) && IS_ATOM_INT(_p_1439)) {
            _value_1438 = _value_1438 + _p_1439;
            if ((long)((unsigned long)_value_1438 + (unsigned long)HIGH_BITS) >= 0) 
            _value_1438 = NewDouble((double)_value_1438);
        }
        else {
            if (IS_ATOM_INT(_value_1438)) {
                _value_1438 = NewDouble((double)_value_1438 + DBL_PTR(_p_1439)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1439)) {
                    _value_1438 = NewDouble(DBL_PTR(_value_1438)->dbl + (double)_p_1439);
                }
                else
                _value_1438 = NewDouble(DBL_PTR(_value_1438)->dbl + DBL_PTR(_p_1439)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 		p += p*/
        _0 = _p_1439;
        if (IS_ATOM_INT(_p_1439) && IS_ATOM_INT(_p_1439)) {
            _p_1439 = _p_1439 + _p_1439;
            if ((long)((unsigned long)_p_1439 + (unsigned long)HIGH_BITS) >= 0) 
            _p_1439 = NewDouble((double)_p_1439);
        }
        else {
            if (IS_ATOM_INT(_p_1439)) {
                _p_1439 = NewDouble((double)_p_1439 + DBL_PTR(_p_1439)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1439)) {
                    _p_1439 = NewDouble(DBL_PTR(_p_1439)->dbl + (double)_p_1439);
                }
                else
                _p_1439 = NewDouble(DBL_PTR(_p_1439)->dbl + DBL_PTR(_p_1439)->dbl);
            }
        }
        DeRef(_0);

        /** 	end for*/
        _i_1441 = _i_1441 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** 	return value*/
    DeRefDS(_bits_1437);
    DeRef(_p_1439);
    return _value_1438;
    ;
}
int bits_to_int() __attribute__ ((alias ("_8bits_to_int")));


int _8atom_to_float64(int _a_1449)
{
    int _762 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F64, a)*/
    _762 = machine(46, _a_1449);
    DeRef(_a_1449);
    return _762;
    ;
}
int atom_to_float64() __attribute__ ((alias ("_8atom_to_float64")));


int _8atom_to_float32(int _a_1453)
{
    int _763 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F32, a)*/
    _763 = machine(48, _a_1453);
    DeRef(_a_1453);
    return _763;
    ;
}
int atom_to_float32() __attribute__ ((alias ("_8atom_to_float32")));


int _8float64_to_atom(int _ieee64_1457)
{
    int _764 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F64_TO_A, ieee64)*/
    _764 = machine(47, _ieee64_1457);
    DeRefDS(_ieee64_1457);
    return _764;
    ;
}
int float64_to_atom() __attribute__ ((alias ("_8float64_to_atom")));


int _8float32_to_atom(int _ieee32_1461)
{
    int _765 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    _765 = machine(49, _ieee32_1461);
    DeRefDS(_ieee32_1461);
    return _765;
    ;
}
int float32_to_atom() __attribute__ ((alias ("_8float32_to_atom")));


int _8hex_text(int _text_1465)
{
    int _res_1466 = NOVALUE;
    int _fp_1467 = NOVALUE;
    int _div_1468 = NOVALUE;
    int _pos_1469 = NOVALUE;
    int _sign_1470 = NOVALUE;
    int _n_1471 = NOVALUE;
    int _792 = NOVALUE;
    int _790 = NOVALUE;
    int _782 = NOVALUE;
    int _781 = NOVALUE;
    int _780 = NOVALUE;
    int _779 = NOVALUE;
    int _776 = NOVALUE;
    int _773 = NOVALUE;
    int _769 = NOVALUE;
    int _767 = NOVALUE;
    int _766 = NOVALUE;
    int _0, _1, _2;
    

    /** 	res = 0*/
    DeRef(_res_1466);
    _res_1466 = 0;

    /** 	fp = 0*/
    DeRef(_fp_1467);
    _fp_1467 = 0;

    /** 	div = 0*/
    _div_1468 = 0;

    /** 	sign = 0*/
    _sign_1470 = 0;

    /** 	n = 0*/
    _n_1471 = 0;

    /** 	for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_1465)){
            _766 = SEQ_PTR(_text_1465)->length;
    }
    else {
        _766 = 1;
    }
    {
        int _i_1473;
        _i_1473 = 1;
L1: 
        if (_i_1473 > _766){
            goto L2; // [33] 254
        }

        /** 		if text[i] = '_' then*/
        _2 = (int)SEQ_PTR(_text_1465);
        _767 = (int)*(((s1_ptr)_2)->base + _i_1473);
        if (binary_op_a(NOTEQ, _767, 95)){
            _767 = NOVALUE;
            goto L3; // [46] 55
        }
        _767 = NOVALUE;

        /** 			continue*/
        goto L4; // [52] 249
L3: 

        /** 		if text[i] = '#' then*/
        _2 = (int)SEQ_PTR(_text_1465);
        _769 = (int)*(((s1_ptr)_2)->base + _i_1473);
        if (binary_op_a(NOTEQ, _769, 35)){
            _769 = NOVALUE;
            goto L5; // [61] 84
        }
        _769 = NOVALUE;

        /** 			if n = 0 then*/
        if (_n_1471 != 0)
        goto L2; // [67] 254

        /** 				continue*/
        goto L4; // [73] 249
        goto L6; // [75] 83

        /** 				exit*/
        goto L2; // [80] 254
L6: 
L5: 

        /** 		if text[i] = '.' then*/
        _2 = (int)SEQ_PTR(_text_1465);
        _773 = (int)*(((s1_ptr)_2)->base + _i_1473);
        if (binary_op_a(NOTEQ, _773, 46)){
            _773 = NOVALUE;
            goto L7; // [90] 118
        }
        _773 = NOVALUE;

        /** 			if div = 0 then*/
        if (_div_1468 != 0)
        goto L2; // [96] 254

        /** 				div = 1*/
        _div_1468 = 1;

        /** 				continue*/
        goto L4; // [107] 249
        goto L8; // [109] 117

        /** 				exit*/
        goto L2; // [114] 254
L8: 
L7: 

        /** 		if text[i] = '-' then*/
        _2 = (int)SEQ_PTR(_text_1465);
        _776 = (int)*(((s1_ptr)_2)->base + _i_1473);
        if (binary_op_a(NOTEQ, _776, 45)){
            _776 = NOVALUE;
            goto L9; // [124] 164
        }
        _776 = NOVALUE;

        /** 			if sign = 0 and n = 0 then*/
        _779 = (_sign_1470 == 0);
        if (_779 == 0) {
            goto L2; // [134] 254
        }
        _781 = (_n_1471 == 0);
        if (_781 == 0)
        {
            DeRef(_781);
            _781 = NOVALUE;
            goto L2; // [143] 254
        }
        else{
            DeRef(_781);
            _781 = NOVALUE;
        }

        /** 				sign = -1*/
        _sign_1470 = -1;

        /** 				continue*/
        goto L4; // [153] 249
        goto LA; // [155] 163

        /** 				exit*/
        goto L2; // [160] 254
LA: 
L9: 

        /** 		pos = eu:find(text[i], "0123456789abcdefABCDEF")*/
        _2 = (int)SEQ_PTR(_text_1465);
        _782 = (int)*(((s1_ptr)_2)->base + _i_1473);
        _pos_1469 = find_from(_782, _783, 1);
        _782 = NOVALUE;

        /** 		if pos = 0 then*/
        if (_pos_1469 != 0)
        goto LB; // [177] 186

        /** 			exit*/
        goto L2; // [183] 254
LB: 

        /** 		if pos > 16 then*/
        if (_pos_1469 <= 16)
        goto LC; // [188] 199

        /** 			pos -= 6*/
        _pos_1469 = _pos_1469 - 6;
LC: 

        /** 		pos -= 1*/
        _pos_1469 = _pos_1469 - 1;

        /** 		if div = 0 then*/
        if (_div_1468 != 0)
        goto LD; // [207] 224

        /** 			res = res * 16 + pos*/
        if (IS_ATOM_INT(_res_1466)) {
            if (_res_1466 == (short)_res_1466)
            _790 = _res_1466 * 16;
            else
            _790 = NewDouble(_res_1466 * (double)16);
        }
        else {
            _790 = NewDouble(DBL_PTR(_res_1466)->dbl * (double)16);
        }
        DeRef(_res_1466);
        if (IS_ATOM_INT(_790)) {
            _res_1466 = _790 + _pos_1469;
            if ((long)((unsigned long)_res_1466 + (unsigned long)HIGH_BITS) >= 0) 
            _res_1466 = NewDouble((double)_res_1466);
        }
        else {
            _res_1466 = NewDouble(DBL_PTR(_790)->dbl + (double)_pos_1469);
        }
        DeRef(_790);
        _790 = NOVALUE;
        goto LE; // [221] 241
LD: 

        /** 		    fp = fp * 16 + pos*/
        if (IS_ATOM_INT(_fp_1467)) {
            if (_fp_1467 == (short)_fp_1467)
            _792 = _fp_1467 * 16;
            else
            _792 = NewDouble(_fp_1467 * (double)16);
        }
        else {
            _792 = NewDouble(DBL_PTR(_fp_1467)->dbl * (double)16);
        }
        DeRef(_fp_1467);
        if (IS_ATOM_INT(_792)) {
            _fp_1467 = _792 + _pos_1469;
            if ((long)((unsigned long)_fp_1467 + (unsigned long)HIGH_BITS) >= 0) 
            _fp_1467 = NewDouble((double)_fp_1467);
        }
        else {
            _fp_1467 = NewDouble(DBL_PTR(_792)->dbl + (double)_pos_1469);
        }
        DeRef(_792);
        _792 = NOVALUE;

        /** 		    div += 1*/
        _div_1468 = _div_1468 + 1;
LE: 

        /** 		n += 1*/
        _n_1471 = _n_1471 + 1;

        /** 	end for*/
L4: 
        _i_1473 = _i_1473 + 1;
        goto L1; // [249] 40
L2: 
        ;
    }

    /** 	while div > 1 do*/
LF: 
    if (_div_1468 <= 1)
    goto L10; // [259] 280

    /** 		fp /= 16*/
    _0 = _fp_1467;
    if (IS_ATOM_INT(_fp_1467)) {
        _fp_1467 = (_fp_1467 % 16) ? NewDouble((double)_fp_1467 / 16) : (_fp_1467 / 16);
    }
    else {
        _fp_1467 = NewDouble(DBL_PTR(_fp_1467)->dbl / (double)16);
    }
    DeRef(_0);

    /** 		div -= 1*/
    _div_1468 = _div_1468 - 1;

    /** 	end while*/
    goto LF; // [277] 259
L10: 

    /** 	res += fp*/
    _0 = _res_1466;
    if (IS_ATOM_INT(_res_1466) && IS_ATOM_INT(_fp_1467)) {
        _res_1466 = _res_1466 + _fp_1467;
        if ((long)((unsigned long)_res_1466 + (unsigned long)HIGH_BITS) >= 0) 
        _res_1466 = NewDouble((double)_res_1466);
    }
    else {
        if (IS_ATOM_INT(_res_1466)) {
            _res_1466 = NewDouble((double)_res_1466 + DBL_PTR(_fp_1467)->dbl);
        }
        else {
            if (IS_ATOM_INT(_fp_1467)) {
                _res_1466 = NewDouble(DBL_PTR(_res_1466)->dbl + (double)_fp_1467);
            }
            else
            _res_1466 = NewDouble(DBL_PTR(_res_1466)->dbl + DBL_PTR(_fp_1467)->dbl);
        }
    }
    DeRef(_0);

    /** 	if sign != 0 then*/
    if (_sign_1470 == 0)
    goto L11; // [288] 298

    /** 		res = -res*/
    _0 = _res_1466;
    if (IS_ATOM_INT(_res_1466)) {
        if ((unsigned long)_res_1466 == 0xC0000000)
        _res_1466 = (int)NewDouble((double)-0xC0000000);
        else
        _res_1466 = - _res_1466;
    }
    else {
        _res_1466 = unary_op(UMINUS, _res_1466);
    }
    DeRef(_0);
L11: 

    /** 	return res*/
    DeRefDS(_text_1465);
    DeRef(_fp_1467);
    DeRef(_779);
    _779 = NOVALUE;
    return _res_1466;
    ;
}
int hex_text() __attribute__ ((alias ("_8hex_text")));


int _8set_decimal_mark(int _new_mark_1531)
{
    int _old_mark_1532 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_mark_1531)) {
        _1 = (long)(DBL_PTR(_new_mark_1531)->dbl);
        DeRefDS(_new_mark_1531);
        _new_mark_1531 = _1;
    }

    /** 	old_mark = decimal_mark*/
    _old_mark_1532 = _8decimal_mark_1528;

    /** 	switch new_mark do*/
    _0 = _new_mark_1531;
    switch ( _0 ){ 

        /** 		case ',', '.' then*/
        case 44:
        case 46:

        /** 			decimal_mark = new_mark*/
        _8decimal_mark_1528 = _new_mark_1531;
        goto L1; // [28] 35

        /** 		case else*/
        default:
    ;}L1: 

    /** 	return old_mark*/
    return _old_mark_1532;
    ;
}
int set_decimal_mark() __attribute__ ((alias ("_8set_decimal_mark")));


int _8to_number(int _text_in_1540, int _return_bad_pos_1541)
{
    int _lDotFound_1542 = NOVALUE;
    int _lSignFound_1543 = NOVALUE;
    int _lCharValue_1544 = NOVALUE;
    int _lBadPos_1545 = NOVALUE;
    int _lLeftSize_1546 = NOVALUE;
    int _lRightSize_1547 = NOVALUE;
    int _lLeftValue_1548 = NOVALUE;
    int _lRightValue_1549 = NOVALUE;
    int _lBase_1550 = NOVALUE;
    int _lPercent_1551 = NOVALUE;
    int _lResult_1552 = NOVALUE;
    int _lDigitCount_1553 = NOVALUE;
    int _lCurrencyFound_1554 = NOVALUE;
    int _lLastDigit_1555 = NOVALUE;
    int _lChar_1556 = NOVALUE;
    int _896 = NOVALUE;
    int _895 = NOVALUE;
    int _888 = NOVALUE;
    int _886 = NOVALUE;
    int _885 = NOVALUE;
    int _880 = NOVALUE;
    int _879 = NOVALUE;
    int _878 = NOVALUE;
    int _877 = NOVALUE;
    int _876 = NOVALUE;
    int _875 = NOVALUE;
    int _871 = NOVALUE;
    int _867 = NOVALUE;
    int _859 = NOVALUE;
    int _841 = NOVALUE;
    int _840 = NOVALUE;
    int _834 = NOVALUE;
    int _832 = NOVALUE;
    int _825 = NOVALUE;
    int _824 = NOVALUE;
    int _823 = NOVALUE;
    int _822 = NOVALUE;
    int _821 = NOVALUE;
    int _820 = NOVALUE;
    int _818 = NOVALUE;
    int _817 = NOVALUE;
    int _816 = NOVALUE;
    int _808 = NOVALUE;
    int _807 = NOVALUE;
    int _806 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_return_bad_pos_1541)) {
        _1 = (long)(DBL_PTR(_return_bad_pos_1541)->dbl);
        DeRefDS(_return_bad_pos_1541);
        _return_bad_pos_1541 = _1;
    }

    /** 	integer lDotFound = 0*/
    _lDotFound_1542 = 0;

    /** 	integer lSignFound = 2*/
    _lSignFound_1543 = 2;

    /** 	integer lBadPos = 0*/
    _lBadPos_1545 = 0;

    /** 	atom    lLeftSize = 0*/
    DeRef(_lLeftSize_1546);
    _lLeftSize_1546 = 0;

    /** 	atom    lRightSize = 1*/
    DeRef(_lRightSize_1547);
    _lRightSize_1547 = 1;

    /** 	atom    lLeftValue = 0*/
    DeRef(_lLeftValue_1548);
    _lLeftValue_1548 = 0;

    /** 	atom    lRightValue = 0*/
    DeRef(_lRightValue_1549);
    _lRightValue_1549 = 0;

    /** 	integer lBase = 10*/
    _lBase_1550 = 10;

    /** 	integer lPercent = 1*/
    _lPercent_1551 = 1;

    /** 	integer lDigitCount = 0*/
    _lDigitCount_1553 = 0;

    /** 	integer lCurrencyFound = 0*/
    _lCurrencyFound_1554 = 0;

    /** 	integer lLastDigit = 0*/
    _lLastDigit_1555 = 0;

    /** 	for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_1540)){
            _806 = SEQ_PTR(_text_in_1540)->length;
    }
    else {
        _806 = 1;
    }
    {
        int _i_1558;
        _i_1558 = 1;
L1: 
        if (_i_1558 > _806){
            goto L2; // [70] 672
        }

        /** 		if not integer(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_1540);
        _807 = (int)*(((s1_ptr)_2)->base + _i_1558);
        if (IS_ATOM_INT(_807))
        _808 = 1;
        else if (IS_ATOM_DBL(_807))
        _808 = IS_ATOM_INT(DoubleToInt(_807));
        else
        _808 = 0;
        _807 = NOVALUE;
        if (_808 != 0)
        goto L3; // [86] 94
        _808 = NOVALUE;

        /** 			exit*/
        goto L2; // [91] 672
L3: 

        /** 		lChar = text_in[i]*/
        _2 = (int)SEQ_PTR(_text_in_1540);
        _lChar_1556 = (int)*(((s1_ptr)_2)->base + _i_1558);
        if (!IS_ATOM_INT(_lChar_1556))
        _lChar_1556 = (long)DBL_PTR(_lChar_1556)->dbl;

        /** 		switch lChar do*/
        _0 = _lChar_1556;
        switch ( _0 ){ 

            /** 			case '-' then*/
            case 45:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_1543 != 2)
            goto L4; // [113] 130

            /** 					lSignFound = -1*/
            _lSignFound_1543 = -1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1555 = _lDigitCount_1553;
            goto L5; // [127] 654
L4: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [136] 654

            /** 			case '+' then*/
            case 43:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_1543 != 2)
            goto L6; // [144] 161

            /** 					lSignFound = 1*/
            _lSignFound_1543 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1555 = _lDigitCount_1553;
            goto L5; // [158] 654
L6: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [167] 654

            /** 			case '#' then*/
            case 35:

            /** 				if lDigitCount = 0 and lBase = 10 then*/
            _816 = (_lDigitCount_1553 == 0);
            if (_816 == 0) {
                goto L7; // [179] 199
            }
            _818 = (_lBase_1550 == 10);
            if (_818 == 0)
            {
                DeRef(_818);
                _818 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_818);
                _818 = NOVALUE;
            }

            /** 					lBase = 16*/
            _lBase_1550 = 16;
            goto L5; // [196] 654
L7: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [205] 654

            /** 			case '@' then*/
            case 64:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _820 = (_lDigitCount_1553 == 0);
            if (_820 == 0) {
                goto L8; // [217] 237
            }
            _822 = (_lBase_1550 == 10);
            if (_822 == 0)
            {
                DeRef(_822);
                _822 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_822);
                _822 = NOVALUE;
            }

            /** 					lBase = 8*/
            _lBase_1550 = 8;
            goto L5; // [234] 654
L8: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [243] 654

            /** 			case '!' then*/
            case 33:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _823 = (_lDigitCount_1553 == 0);
            if (_823 == 0) {
                goto L9; // [255] 275
            }
            _825 = (_lBase_1550 == 10);
            if (_825 == 0)
            {
                DeRef(_825);
                _825 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_825);
                _825 = NOVALUE;
            }

            /** 					lBase = 2*/
            _lBase_1550 = 2;
            goto L5; // [272] 654
L9: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [281] 654

            /** 			case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** 				if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_1554 != 0)
            goto LA; // [297] 314

            /** 					lCurrencyFound = 1*/
            _lCurrencyFound_1554 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1555 = _lDigitCount_1553;
            goto L5; // [311] 654
LA: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [320] 654

            /** 			case '_' then -- grouping character*/
            case 95:

            /** 				if lDigitCount = 0 or lLastDigit != 0 then*/
            _832 = (_lDigitCount_1553 == 0);
            if (_832 != 0) {
                goto LB; // [332] 345
            }
            _834 = (_lLastDigit_1555 != 0);
            if (_834 == 0)
            {
                DeRef(_834);
                _834 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_834);
                _834 = NOVALUE;
            }
LB: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [351] 654

            /** 			case '.', ',' then*/
            case 46:
            case 44:

            /** 				if lLastDigit = 0 then*/
            if (_lLastDigit_1555 != 0)
            goto LC; // [361] 400

            /** 					if decimal_mark = lChar then*/
            if (_8decimal_mark_1528 != _lChar_1556)
            goto L5; // [369] 654

            /** 						if lDotFound = 0 then*/
            if (_lDotFound_1542 != 0)
            goto LD; // [375] 387

            /** 							lDotFound = 1*/
            _lDotFound_1542 = 1;
            goto L5; // [384] 654
LD: 

            /** 							lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [406] 654

            /** 			case '%' then*/
            case 37:

            /** 				lLastDigit = lDigitCount*/
            _lLastDigit_1555 = _lDigitCount_1553;

            /** 				if lPercent = 1 then*/
            if (_lPercent_1551 != 1)
            goto LE; // [419] 431

            /** 					lPercent = 100*/
            _lPercent_1551 = 100;
            goto L5; // [428] 654
LE: 

            /** 					if text_in[i-1] = '%' then*/
            _840 = _i_1558 - 1;
            _2 = (int)SEQ_PTR(_text_in_1540);
            _841 = (int)*(((s1_ptr)_2)->base + _840);
            if (binary_op_a(NOTEQ, _841, 37)){
                _841 = NOVALUE;
                goto LF; // [441] 456
            }
            _841 = NOVALUE;

            /** 						lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_1551 = _lPercent_1551 * 10;
            goto L5; // [453] 654
LF: 

            /** 						lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [463] 654

            /** 			case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** 				if lDigitCount = 0 then*/
            if (_lDigitCount_1553 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** 					lLastDigit = i*/
            _lLastDigit_1555 = _i_1558;
            goto L5; // [488] 654

            /** 			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** 	            lCharValue = find(lChar, vDigits) - 1*/
            _859 = find_from(_lChar_1556, _8vDigits_1526, 1);
            _lCharValue_1544 = _859 - 1;
            _859 = NOVALUE;

            /** 	            if lCharValue > 15 then*/
            if (_lCharValue_1544 <= 15)
            goto L11; // [549] 560

            /** 	            	lCharValue -= 6*/
            _lCharValue_1544 = _lCharValue_1544 - 6;
L11: 

            /** 	            if lCharValue >= lBase then*/
            if (_lCharValue_1544 < _lBase_1550)
            goto L12; // [562] 574

            /** 	                lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [571] 654
L12: 

            /** 	            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_1555 == 0)
            goto L13; // [576] 588

            /** 					lBadPos = i*/
            _lBadPos_1545 = _i_1558;
            goto L5; // [585] 654
L13: 

            /** 				elsif lDotFound = 1 then*/
            if (_lDotFound_1542 != 1)
            goto L14; // [590] 619

            /** 					lRightSize *= lBase*/
            _0 = _lRightSize_1547;
            if (IS_ATOM_INT(_lRightSize_1547)) {
                if (_lRightSize_1547 == (short)_lRightSize_1547 && _lBase_1550 <= INT15 && _lBase_1550 >= -INT15)
                _lRightSize_1547 = _lRightSize_1547 * _lBase_1550;
                else
                _lRightSize_1547 = NewDouble(_lRightSize_1547 * (double)_lBase_1550);
            }
            else {
                _lRightSize_1547 = NewDouble(DBL_PTR(_lRightSize_1547)->dbl * (double)_lBase_1550);
            }
            DeRef(_0);

            /** 					lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_1549)) {
                if (_lRightValue_1549 == (short)_lRightValue_1549 && _lBase_1550 <= INT15 && _lBase_1550 >= -INT15)
                _867 = _lRightValue_1549 * _lBase_1550;
                else
                _867 = NewDouble(_lRightValue_1549 * (double)_lBase_1550);
            }
            else {
                _867 = NewDouble(DBL_PTR(_lRightValue_1549)->dbl * (double)_lBase_1550);
            }
            DeRef(_lRightValue_1549);
            if (IS_ATOM_INT(_867)) {
                _lRightValue_1549 = _867 + _lCharValue_1544;
                if ((long)((unsigned long)_lRightValue_1549 + (unsigned long)HIGH_BITS) >= 0) 
                _lRightValue_1549 = NewDouble((double)_lRightValue_1549);
            }
            else {
                _lRightValue_1549 = NewDouble(DBL_PTR(_867)->dbl + (double)_lCharValue_1544);
            }
            DeRef(_867);
            _867 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_1553 = _lDigitCount_1553 + 1;
            goto L5; // [616] 654
L14: 

            /** 					lLeftSize += 1*/
            _0 = _lLeftSize_1546;
            if (IS_ATOM_INT(_lLeftSize_1546)) {
                _lLeftSize_1546 = _lLeftSize_1546 + 1;
                if (_lLeftSize_1546 > MAXINT){
                    _lLeftSize_1546 = NewDouble((double)_lLeftSize_1546);
                }
            }
            else
            _lLeftSize_1546 = binary_op(PLUS, 1, _lLeftSize_1546);
            DeRef(_0);

            /** 					lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_1548)) {
                if (_lLeftValue_1548 == (short)_lLeftValue_1548 && _lBase_1550 <= INT15 && _lBase_1550 >= -INT15)
                _871 = _lLeftValue_1548 * _lBase_1550;
                else
                _871 = NewDouble(_lLeftValue_1548 * (double)_lBase_1550);
            }
            else {
                _871 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl * (double)_lBase_1550);
            }
            DeRef(_lLeftValue_1548);
            if (IS_ATOM_INT(_871)) {
                _lLeftValue_1548 = _871 + _lCharValue_1544;
                if ((long)((unsigned long)_lLeftValue_1548 + (unsigned long)HIGH_BITS) >= 0) 
                _lLeftValue_1548 = NewDouble((double)_lLeftValue_1548);
            }
            else {
                _lLeftValue_1548 = NewDouble(DBL_PTR(_871)->dbl + (double)_lCharValue_1544);
            }
            DeRef(_871);
            _871 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_1553 = _lDigitCount_1553 + 1;
            goto L5; // [642] 654

            /** 			case else*/
            default:

            /** 				lBadPos = i*/
            _lBadPos_1545 = _i_1558;
        ;}L5: 

        /** 		if lBadPos != 0 then*/
        if (_lBadPos_1545 == 0)
        goto L15; // [656] 665

        /** 			exit*/
        goto L2; // [662] 672
L15: 

        /** 	end for*/
        _i_1558 = _i_1558 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** 	if lBadPos = 0 and lDigitCount = 0 then*/
    _875 = (_lBadPos_1545 == 0);
    if (_875 == 0) {
        goto L16; // [678] 696
    }
    _877 = (_lDigitCount_1553 == 0);
    if (_877 == 0)
    {
        DeRef(_877);
        _877 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_877);
        _877 = NOVALUE;
    }

    /** 		lBadPos = 1*/
    _lBadPos_1545 = 1;
L16: 

    /** 	if return_bad_pos = 0 and lBadPos != 0 then*/
    _878 = (_return_bad_pos_1541 == 0);
    if (_878 == 0) {
        goto L17; // [702] 721
    }
    _880 = (_lBadPos_1545 != 0);
    if (_880 == 0)
    {
        DeRef(_880);
        _880 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_880);
        _880 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_text_in_1540);
    DeRef(_lLeftSize_1546);
    DeRef(_lRightSize_1547);
    DeRef(_lLeftValue_1548);
    DeRef(_lRightValue_1549);
    DeRef(_lResult_1552);
    DeRef(_816);
    _816 = NOVALUE;
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_832);
    _832 = NOVALUE;
    DeRef(_840);
    _840 = NOVALUE;
    DeRef(_875);
    _875 = NOVALUE;
    DeRef(_878);
    _878 = NOVALUE;
    return 0;
L17: 

    /** 	if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_1549, 0)){
        goto L18; // [723] 751
    }

    /** 	    if lPercent != 1 then*/
    if (_lPercent_1551 == 1)
    goto L19; // [729] 742

    /** 			lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_1552);
    if (IS_ATOM_INT(_lLeftValue_1548)) {
        _lResult_1552 = (_lLeftValue_1548 % _lPercent_1551) ? NewDouble((double)_lLeftValue_1548 / _lPercent_1551) : (_lLeftValue_1548 / _lPercent_1551);
    }
    else {
        _lResult_1552 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl / (double)_lPercent_1551);
    }
    goto L1A; // [739] 786
L19: 

    /** 	        lResult = lLeftValue*/
    Ref(_lLeftValue_1548);
    DeRef(_lResult_1552);
    _lResult_1552 = _lLeftValue_1548;
    goto L1A; // [748] 786
L18: 

    /** 	    if lPercent != 1 then*/
    if (_lPercent_1551 == 1)
    goto L1B; // [753] 774

    /** 	        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_1549) && IS_ATOM_INT(_lRightSize_1547)) {
        _885 = (_lRightValue_1549 % _lRightSize_1547) ? NewDouble((double)_lRightValue_1549 / _lRightSize_1547) : (_lRightValue_1549 / _lRightSize_1547);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_1549)) {
            _885 = NewDouble((double)_lRightValue_1549 / DBL_PTR(_lRightSize_1547)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_1547)) {
                _885 = NewDouble(DBL_PTR(_lRightValue_1549)->dbl / (double)_lRightSize_1547);
            }
            else
            _885 = NewDouble(DBL_PTR(_lRightValue_1549)->dbl / DBL_PTR(_lRightSize_1547)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_1548) && IS_ATOM_INT(_885)) {
        _886 = _lLeftValue_1548 + _885;
        if ((long)((unsigned long)_886 + (unsigned long)HIGH_BITS) >= 0) 
        _886 = NewDouble((double)_886);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_1548)) {
            _886 = NewDouble((double)_lLeftValue_1548 + DBL_PTR(_885)->dbl);
        }
        else {
            if (IS_ATOM_INT(_885)) {
                _886 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl + (double)_885);
            }
            else
            _886 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl + DBL_PTR(_885)->dbl);
        }
    }
    DeRef(_885);
    _885 = NOVALUE;
    DeRef(_lResult_1552);
    if (IS_ATOM_INT(_886)) {
        _lResult_1552 = (_886 % _lPercent_1551) ? NewDouble((double)_886 / _lPercent_1551) : (_886 / _lPercent_1551);
    }
    else {
        _lResult_1552 = NewDouble(DBL_PTR(_886)->dbl / (double)_lPercent_1551);
    }
    DeRef(_886);
    _886 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** 	        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_1549) && IS_ATOM_INT(_lRightSize_1547)) {
        _888 = (_lRightValue_1549 % _lRightSize_1547) ? NewDouble((double)_lRightValue_1549 / _lRightSize_1547) : (_lRightValue_1549 / _lRightSize_1547);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_1549)) {
            _888 = NewDouble((double)_lRightValue_1549 / DBL_PTR(_lRightSize_1547)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_1547)) {
                _888 = NewDouble(DBL_PTR(_lRightValue_1549)->dbl / (double)_lRightSize_1547);
            }
            else
            _888 = NewDouble(DBL_PTR(_lRightValue_1549)->dbl / DBL_PTR(_lRightSize_1547)->dbl);
        }
    }
    DeRef(_lResult_1552);
    if (IS_ATOM_INT(_lLeftValue_1548) && IS_ATOM_INT(_888)) {
        _lResult_1552 = _lLeftValue_1548 + _888;
        if ((long)((unsigned long)_lResult_1552 + (unsigned long)HIGH_BITS) >= 0) 
        _lResult_1552 = NewDouble((double)_lResult_1552);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_1548)) {
            _lResult_1552 = NewDouble((double)_lLeftValue_1548 + DBL_PTR(_888)->dbl);
        }
        else {
            if (IS_ATOM_INT(_888)) {
                _lResult_1552 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl + (double)_888);
            }
            else
            _lResult_1552 = NewDouble(DBL_PTR(_lLeftValue_1548)->dbl + DBL_PTR(_888)->dbl);
        }
    }
    DeRef(_888);
    _888 = NOVALUE;
L1C: 
L1A: 

    /** 	if lSignFound < 0 then*/
    if (_lSignFound_1543 >= 0)
    goto L1D; // [788] 800

    /** 		lResult = -lResult*/
    _0 = _lResult_1552;
    if (IS_ATOM_INT(_lResult_1552)) {
        if ((unsigned long)_lResult_1552 == 0xC0000000)
        _lResult_1552 = (int)NewDouble((double)-0xC0000000);
        else
        _lResult_1552 = - _lResult_1552;
    }
    else {
        _lResult_1552 = unary_op(UMINUS, _lResult_1552);
    }
    DeRef(_0);
L1D: 

    /** 	if return_bad_pos = 0 then*/
    if (_return_bad_pos_1541 != 0)
    goto L1E; // [802] 815

    /** 		return lResult*/
    DeRefDS(_text_in_1540);
    DeRef(_lLeftSize_1546);
    DeRef(_lRightSize_1547);
    DeRef(_lLeftValue_1548);
    DeRef(_lRightValue_1549);
    DeRef(_816);
    _816 = NOVALUE;
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_832);
    _832 = NOVALUE;
    DeRef(_840);
    _840 = NOVALUE;
    DeRef(_875);
    _875 = NOVALUE;
    DeRef(_878);
    _878 = NOVALUE;
    return _lResult_1552;
L1E: 

    /** 	if return_bad_pos = -1 then*/
    if (_return_bad_pos_1541 != -1)
    goto L1F; // [817] 850

    /** 		if lBadPos = 0 then*/
    if (_lBadPos_1545 != 0)
    goto L20; // [823] 838

    /** 			return lResult*/
    DeRefDS(_text_in_1540);
    DeRef(_lLeftSize_1546);
    DeRef(_lRightSize_1547);
    DeRef(_lLeftValue_1548);
    DeRef(_lRightValue_1549);
    DeRef(_816);
    _816 = NOVALUE;
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_832);
    _832 = NOVALUE;
    DeRef(_840);
    _840 = NOVALUE;
    DeRef(_875);
    _875 = NOVALUE;
    DeRef(_878);
    _878 = NOVALUE;
    return _lResult_1552;
    goto L21; // [835] 849
L20: 

    /** 			return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _lBadPos_1545;
    _895 = MAKE_SEQ(_1);
    DeRefDS(_text_in_1540);
    DeRef(_lLeftSize_1546);
    DeRef(_lRightSize_1547);
    DeRef(_lLeftValue_1548);
    DeRef(_lRightValue_1549);
    DeRef(_lResult_1552);
    DeRef(_816);
    _816 = NOVALUE;
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_832);
    _832 = NOVALUE;
    DeRef(_840);
    _840 = NOVALUE;
    DeRef(_875);
    _875 = NOVALUE;
    DeRef(_878);
    _878 = NOVALUE;
    return _895;
L21: 
L1F: 

    /** 	return {lResult, lBadPos}*/
    Ref(_lResult_1552);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_1552;
    ((int *)_2)[2] = _lBadPos_1545;
    _896 = MAKE_SEQ(_1);
    DeRefDS(_text_in_1540);
    DeRef(_lLeftSize_1546);
    DeRef(_lRightSize_1547);
    DeRef(_lLeftValue_1548);
    DeRef(_lRightValue_1549);
    DeRef(_lResult_1552);
    DeRef(_816);
    _816 = NOVALUE;
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_832);
    _832 = NOVALUE;
    DeRef(_840);
    _840 = NOVALUE;
    DeRef(_875);
    _875 = NOVALUE;
    DeRef(_878);
    _878 = NOVALUE;
    DeRef(_895);
    _895 = NOVALUE;
    return _896;
    ;
}
int to_number() __attribute__ ((alias ("_8to_number")));


int _8to_integer(int _data_in_1709, int _def_value_1710)
{
    int _lResult_1719 = NOVALUE;
    int _906 = NOVALUE;
    int _905 = NOVALUE;
    int _903 = NOVALUE;
    int _900 = NOVALUE;
    int _898 = NOVALUE;
    int _897 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_def_value_1710)) {
        _1 = (long)(DBL_PTR(_def_value_1710)->dbl);
        DeRefDS(_def_value_1710);
        _def_value_1710 = _1;
    }

    /** 	if integer(data_in) then*/
    if (IS_ATOM_INT(_data_in_1709))
    _897 = 1;
    else if (IS_ATOM_DBL(_data_in_1709))
    _897 = IS_ATOM_INT(DoubleToInt(_data_in_1709));
    else
    _897 = 0;
    if (_897 == 0)
    {
        _897 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _897 = NOVALUE;
    }

    /** 		return data_in*/
    DeRef(_lResult_1719);
    return _data_in_1709;
L1: 

    /** 	if atom(data_in) then*/
    _898 = IS_ATOM(_data_in_1709);
    if (_898 == 0)
    {
        _898 = NOVALUE;
        goto L2; // [23] 53
    }
    else{
        _898 = NOVALUE;
    }

    /** 		data_in = floor(data_in)*/
    _0 = _data_in_1709;
    if (IS_ATOM_INT(_data_in_1709))
    _data_in_1709 = e_floor(_data_in_1709);
    else
    _data_in_1709 = unary_op(FLOOR, _data_in_1709);
    DeRef(_0);

    /** 		if not integer(data_in) then*/
    if (IS_ATOM_INT(_data_in_1709))
    _900 = 1;
    else if (IS_ATOM_DBL(_data_in_1709))
    _900 = IS_ATOM_INT(DoubleToInt(_data_in_1709));
    else
    _900 = 0;
    if (_900 != 0)
    goto L3; // [36] 46
    _900 = NOVALUE;

    /** 			return def_value*/
    DeRef(_data_in_1709);
    DeRef(_lResult_1719);
    return _def_value_1710;
L3: 

    /** 		return data_in*/
    DeRef(_lResult_1719);
    return _data_in_1709;
L2: 

    /** 	sequence lResult = to_number(data_in, 1)*/
    Ref(_data_in_1709);
    _0 = _lResult_1719;
    _lResult_1719 = _8to_number(_data_in_1709, 1);
    DeRef(_0);

    /** 	if lResult[2] != 0 then*/
    _2 = (int)SEQ_PTR(_lResult_1719);
    _903 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _903, 0)){
        _903 = NOVALUE;
        goto L4; // [68] 81
    }
    _903 = NOVALUE;

    /** 		return def_value*/
    DeRef(_data_in_1709);
    DeRefDS(_lResult_1719);
    return _def_value_1710;
    goto L5; // [78] 95
L4: 

    /** 		return floor(lResult[1])*/
    _2 = (int)SEQ_PTR(_lResult_1719);
    _905 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_905))
    _906 = e_floor(_905);
    else
    _906 = unary_op(FLOOR, _905);
    _905 = NOVALUE;
    DeRef(_data_in_1709);
    DeRefDS(_lResult_1719);
    return _906;
L5: 
    ;
}
int to_integer() __attribute__ ((alias ("_8to_integer")));


int _8to_string(int _data_in_1729, int _string_quote_1730, int _embed_string_quote_1731)
{
    int _data_out_1733 = NOVALUE;
    int _935 = NOVALUE;
    int _933 = NOVALUE;
    int _932 = NOVALUE;
    int _931 = NOVALUE;
    int _930 = NOVALUE;
    int _927 = NOVALUE;
    int _925 = NOVALUE;
    int _924 = NOVALUE;
    int _922 = NOVALUE;
    int _920 = NOVALUE;
    int _918 = NOVALUE;
    int _917 = NOVALUE;
    int _916 = NOVALUE;
    int _914 = NOVALUE;
    int _913 = NOVALUE;
    int _908 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_string_quote_1730)) {
        _1 = (long)(DBL_PTR(_string_quote_1730)->dbl);
        DeRefDS(_string_quote_1730);
        _string_quote_1730 = _1;
    }
    if (!IS_ATOM_INT(_embed_string_quote_1731)) {
        _1 = (long)(DBL_PTR(_embed_string_quote_1731)->dbl);
        DeRefDS(_embed_string_quote_1731);
        _embed_string_quote_1731 = _1;
    }

    /** 	if types:string(data_in) then*/
    Ref(_data_in_1729);
    _908 = _7string(_data_in_1729);
    if (_908 == 0) {
        DeRef(_908);
        _908 = NOVALUE;
        goto L1; // [11] 66
    }
    else {
        if (!IS_ATOM_INT(_908) && DBL_PTR(_908)->dbl == 0.0){
            DeRef(_908);
            _908 = NOVALUE;
            goto L1; // [11] 66
        }
        DeRef(_908);
        _908 = NOVALUE;
    }
    DeRef(_908);
    _908 = NOVALUE;

    /** 		if string_quote = 0 then*/
    if (_string_quote_1730 != 0)
    goto L2; // [16] 27

    /** 			return data_in*/
    DeRef(_data_out_1733);
    return _data_in_1729;
L2: 

    /** 		data_in = search:match_replace(`\`, data_in, `\\`)*/
    RefDS(_910);
    Ref(_data_in_1729);
    RefDS(_911);
    _0 = _data_in_1729;
    _data_in_1729 = _9match_replace(_910, _data_in_1729, _911, 0);
    DeRef(_0);

    /** 		data_in = search:match_replace({string_quote}, data_in, `\` & string_quote)*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _string_quote_1730;
    _913 = MAKE_SEQ(_1);
    Append(&_914, _910, _string_quote_1730);
    Ref(_data_in_1729);
    _0 = _data_in_1729;
    _data_in_1729 = _9match_replace(_913, _data_in_1729, _914, 0);
    DeRef(_0);
    _913 = NOVALUE;
    _914 = NOVALUE;

    /** 		return string_quote & data_in & string_quote*/
    {
        int concat_list[3];

        concat_list[0] = _string_quote_1730;
        concat_list[1] = _data_in_1729;
        concat_list[2] = _string_quote_1730;
        Concat_N((object_ptr)&_916, concat_list, 3);
    }
    DeRef(_data_in_1729);
    DeRef(_data_out_1733);
    return _916;
L1: 

    /** 	if atom(data_in) then*/
    _917 = IS_ATOM(_data_in_1729);
    if (_917 == 0)
    {
        _917 = NOVALUE;
        goto L3; // [71] 136
    }
    else{
        _917 = NOVALUE;
    }

    /** 		if integer(data_in) then*/
    if (IS_ATOM_INT(_data_in_1729))
    _918 = 1;
    else if (IS_ATOM_DBL(_data_in_1729))
    _918 = IS_ATOM_INT(DoubleToInt(_data_in_1729));
    else
    _918 = 0;
    if (_918 == 0)
    {
        _918 = NOVALUE;
        goto L4; // [79] 93
    }
    else{
        _918 = NOVALUE;
    }

    /** 			return sprintf("%d", data_in)*/
    _920 = EPrintf(-9999999, _919, _data_in_1729);
    DeRef(_data_in_1729);
    DeRef(_data_out_1733);
    DeRef(_916);
    _916 = NOVALUE;
    return _920;
L4: 

    /** 		data_in = text:trim_tail(sprintf("%.15f", data_in), '0')*/
    _922 = EPrintf(-9999999, _921, _data_in_1729);
    _0 = _data_in_1729;
    _data_in_1729 = _6trim_tail(_922, 48, 0);
    DeRef(_0);
    _922 = NOVALUE;

    /** 		if data_in[$] = '.' then*/
    if (IS_SEQUENCE(_data_in_1729)){
            _924 = SEQ_PTR(_data_in_1729)->length;
    }
    else {
        _924 = 1;
    }
    _2 = (int)SEQ_PTR(_data_in_1729);
    _925 = (int)*(((s1_ptr)_2)->base + _924);
    if (binary_op_a(NOTEQ, _925, 46)){
        _925 = NOVALUE;
        goto L5; // [114] 129
    }
    _925 = NOVALUE;

    /** 			data_in = remove(data_in, length(data_in))*/
    if (IS_SEQUENCE(_data_in_1729)){
            _927 = SEQ_PTR(_data_in_1729)->length;
    }
    else {
        _927 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_data_in_1729);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_927)) ? _927 : (long)(DBL_PTR(_927)->dbl);
        int stop = (IS_ATOM_INT(_927)) ? _927 : (long)(DBL_PTR(_927)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_data_in_1729), start, &_data_in_1729 );
            }
            else Tail(SEQ_PTR(_data_in_1729), stop+1, &_data_in_1729);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_data_in_1729), start, &_data_in_1729);
        }
        else {
            assign_slice_seq = &assign_space;
            _data_in_1729 = Remove_elements(start, stop, (SEQ_PTR(_data_in_1729)->ref == 1));
        }
    }
    _927 = NOVALUE;
    _927 = NOVALUE;
L5: 

    /** 		return data_in*/
    DeRef(_data_out_1733);
    DeRef(_916);
    _916 = NOVALUE;
    DeRef(_920);
    _920 = NOVALUE;
    return _data_in_1729;
L3: 

    /** 	data_out = "{"*/
    RefDS(_929);
    DeRef(_data_out_1733);
    _data_out_1733 = _929;

    /** 	for i = 1 to length(data_in) do*/
    if (IS_SEQUENCE(_data_in_1729)){
            _930 = SEQ_PTR(_data_in_1729)->length;
    }
    else {
        _930 = 1;
    }
    {
        int _i_1763;
        _i_1763 = 1;
L6: 
        if (_i_1763 > _930){
            goto L7; // [148] 197
        }

        /** 		data_out &= to_string(data_in[i], embed_string_quote)*/
        _2 = (int)SEQ_PTR(_data_in_1729);
        _931 = (int)*(((s1_ptr)_2)->base + _i_1763);
        DeRef(_932);
        _932 = _embed_string_quote_1731;
        Ref(_931);
        _933 = _8to_string(_931, _932, 34);
        _931 = NOVALUE;
        _932 = NOVALUE;
        if (IS_SEQUENCE(_data_out_1733) && IS_ATOM(_933)) {
            Ref(_933);
            Append(&_data_out_1733, _data_out_1733, _933);
        }
        else if (IS_ATOM(_data_out_1733) && IS_SEQUENCE(_933)) {
        }
        else {
            Concat((object_ptr)&_data_out_1733, _data_out_1733, _933);
        }
        DeRef(_933);
        _933 = NOVALUE;

        /** 		if i != length(data_in) then*/
        if (IS_SEQUENCE(_data_in_1729)){
                _935 = SEQ_PTR(_data_in_1729)->length;
        }
        else {
            _935 = 1;
        }
        if (_i_1763 == _935)
        goto L8; // [179] 190

        /** 			data_out &= ", "*/
        Concat((object_ptr)&_data_out_1733, _data_out_1733, _937);
L8: 

        /** 	end for*/
        _i_1763 = _i_1763 + 1;
        goto L6; // [192] 155
L7: 
        ;
    }

    /** 	data_out &= '}'*/
    Append(&_data_out_1733, _data_out_1733, 125);

    /** 	return data_out*/
    DeRef(_data_in_1729);
    DeRef(_916);
    _916 = NOVALUE;
    DeRef(_920);
    _920 = NOVALUE;
    return _data_out_1733;
    ;
}
int to_string() __attribute__ ((alias ("_8to_string")));



// 0x3276E89E
