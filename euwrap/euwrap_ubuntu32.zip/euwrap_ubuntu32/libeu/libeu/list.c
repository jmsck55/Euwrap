// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _58set_return_linked_list(int _i_23635)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_23635)) {
        _1 = (long)(DBL_PTR(_i_23635)->dbl);
        DeRefDS(_i_23635);
        _i_23635 = _1;
    }

    /** 	always_linked_list = i*/
    _58always_linked_list_23632 = _i_23635;

    /** end procedure*/
    return;
    ;
}


int _58get_return_linked_list()
{
    int _0, _1, _2;
    

    /** 	return always_linked_list*/
    return _58always_linked_list_23632;
    ;
}


int _58mystring(int _x_23640)
{
    int _flag_23641 = NOVALUE;
    int _i_23642 = NOVALUE;
    int _ob_23643 = NOVALUE;
    int _13089 = NOVALUE;
    int _13083 = NOVALUE;
    int _13081 = NOVALUE;
    int _13079 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _13079 = IS_SEQUENCE(_x_23640);
    if (_13079 != 0)
    goto L1; // [6] 16
    _13079 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_23640);
    DeRef(_ob_23643);
    return 0;
L1: 

    /** 	flag = 0*/
    _flag_23641 = 0;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_23640)){
            _13081 = SEQ_PTR(_x_23640)->length;
    }
    else {
        _13081 = 1;
    }
    {
        int _j_23648;
        _j_23648 = 1;
L2: 
        if (_j_23648 > _13081){
            goto L3; // [26] 107
        }

        /** 		ob = x[j]*/
        DeRef(_ob_23643);
        _2 = (int)SEQ_PTR(_x_23640);
        _ob_23643 = (int)*(((s1_ptr)_2)->base + _j_23648);
        Ref(_ob_23643);

        /** 		if not integer(ob) then*/
        if (IS_ATOM_INT(_ob_23643))
        _13083 = 1;
        else if (IS_ATOM_DBL(_ob_23643))
        _13083 = IS_ATOM_INT(DoubleToInt(_ob_23643));
        else
        _13083 = 0;
        if (_13083 != 0)
        goto L4; // [44] 54
        _13083 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_23640);
        DeRef(_ob_23643);
        return 0;
L4: 

        /** 		i = ob*/
        Ref(_ob_23643);
        _i_23642 = _ob_23643;
        if (!IS_ATOM_INT(_i_23642)) {
            _1 = (long)(DBL_PTR(_i_23642)->dbl);
            DeRefDS(_i_23642);
            _i_23642 = _1;
        }

        /** 		if i < 0 then*/
        if (_i_23642 >= 0)
        goto L5; // [63] 74

        /** 			return 0*/
        DeRef(_x_23640);
        DeRef(_ob_23643);
        return 0;
L5: 

        /** 		if i > 255 then*/
        if (_i_23642 <= 255)
        goto L6; // [76] 87

        /** 			return 0*/
        DeRef(_x_23640);
        DeRef(_ob_23643);
        return 0;
L6: 

        /** 		if flag = 0 then*/
        if (_flag_23641 != 0)
        goto L7; // [89] 100

        /** 			flag = (i = 0)*/
        _flag_23641 = (_i_23642 == 0);
L7: 

        /** 	end for*/
        _j_23648 = _j_23648 + 1;
        goto L2; // [102] 33
L3: 
        ;
    }

    /** 	return 1 + flag*/
    _13089 = _flag_23641 + 1;
    if (_13089 > MAXINT){
        _13089 = NewDouble((double)_13089);
    }
    DeRef(_x_23640);
    DeRef(_ob_23643);
    return _13089;
    ;
}


int _58myarray(int _x_23664)
{
    int _flag_23665 = NOVALUE;
    int _i_23666 = NOVALUE;
    int _ob_23667 = NOVALUE;
    int _13097 = NOVALUE;
    int _13094 = NOVALUE;
    int _13092 = NOVALUE;
    int _13090 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _13090 = IS_SEQUENCE(_x_23664);
    if (_13090 != 0)
    goto L1; // [6] 16
    _13090 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_23664);
    DeRef(_i_23666);
    DeRef(_ob_23667);
    return 0;
L1: 

    /** 	flag = 1*/
    _flag_23665 = 1;

    /** 	for j = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_23664)){
            _13092 = SEQ_PTR(_x_23664)->length;
    }
    else {
        _13092 = 1;
    }
    {
        int _j_23672;
        _j_23672 = 1;
L2: 
        if (_j_23672 > _13092){
            goto L3; // [26] 152
        }

        /** 		ob = x[j]*/
        DeRef(_ob_23667);
        _2 = (int)SEQ_PTR(_x_23664);
        _ob_23667 = (int)*(((s1_ptr)_2)->base + _j_23672);
        Ref(_ob_23667);

        /** 		if not atom(ob) then*/
        _13094 = IS_ATOM(_ob_23667);
        if (_13094 != 0)
        goto L4; // [44] 54
        _13094 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_23664);
        DeRef(_i_23666);
        DeRef(_ob_23667);
        return 0;
L4: 

        /** 		if flag <= 2 then*/
        if (_flag_23665 > 2)
        goto L5; // [56] 145

        /** 			i = ob*/
        Ref(_ob_23667);
        DeRef(_i_23666);
        _i_23666 = _ob_23667;

        /** 			if floor(i) != i then*/
        if (IS_ATOM_INT(_i_23666))
        _13097 = e_floor(_i_23666);
        else
        _13097 = unary_op(FLOOR, _i_23666);
        if (binary_op_a(EQUALS, _13097, _i_23666)){
            DeRef(_13097);
            _13097 = NOVALUE;
            goto L6; // [70] 82
        }
        DeRef(_13097);
        _13097 = NOVALUE;

        /** 				flag = 3 -- for double*/
        _flag_23665 = 3;
        goto L7; // [79] 144
L6: 

        /** 			elsif i < (-2147483648) then*/
        if (binary_op_a(GREATEREQ, _i_23666, _13100)){
            goto L8; // [84] 96
        }

        /** 				flag = 3 -- for double*/
        _flag_23665 = 3;
        goto L7; // [93] 144
L8: 

        /** 			elsif i > 4294967295 then*/
        if (binary_op_a(LESSEQ, _i_23666, _13102)){
            goto L9; // [98] 110
        }

        /** 				flag = 3 -- for double*/
        _flag_23665 = 3;
        goto L7; // [107] 144
L9: 

        /** 			elsif flag = 2 then*/
        if (_flag_23665 != 2)
        goto LA; // [112] 131

        /** 				if i > 2147483647 then*/
        if (binary_op_a(LESSEQ, _i_23666, _13105)){
            goto L7; // [118] 144
        }

        /** 					flag = 3 -- for double*/
        _flag_23665 = 3;
        goto L7; // [128] 144
LA: 

        /** 			elsif i < 0 then*/
        if (binary_op_a(GREATEREQ, _i_23666, 0)){
            goto LB; // [133] 143
        }

        /** 				flag = 2 -- for signed int*/
        _flag_23665 = 2;
LB: 
L7: 
L5: 

        /** 	end for*/
        _j_23672 = _j_23672 + 1;
        goto L2; // [147] 33
L3: 
        ;
    }

    /** 	return flag -- 3 for double, 2 for signed int, 1 for unsigned int, 0 for linked list*/
    DeRef(_x_23664);
    DeRef(_i_23666);
    DeRef(_ob_23667);
    return _flag_23665;
    ;
}


int _58sequence_to_linked_list(int _s_23716)
{
    int _ma_23717 = NOVALUE;
    int _next_23718 = NOVALUE;
    int _tmp_23719 = NOVALUE;
    int _a_23720 = NOVALUE;
    int _i_23721 = NOVALUE;
    int _13199 = NOVALUE;
    int _13198 = NOVALUE;
    int _13197 = NOVALUE;
    int _13196 = NOVALUE;
    int _13195 = NOVALUE;
    int _13193 = NOVALUE;
    int _13192 = NOVALUE;
    int _13190 = NOVALUE;
    int _13189 = NOVALUE;
    int _13188 = NOVALUE;
    int _13187 = NOVALUE;
    int _13185 = NOVALUE;
    int _13184 = NOVALUE;
    int _13182 = NOVALUE;
    int _13181 = NOVALUE;
    int _13179 = NOVALUE;
    int _13178 = NOVALUE;
    int _13177 = NOVALUE;
    int _13176 = NOVALUE;
    int _13175 = NOVALUE;
    int _13174 = NOVALUE;
    int _13173 = NOVALUE;
    int _13171 = NOVALUE;
    int _13170 = NOVALUE;
    int _13169 = NOVALUE;
    int _13167 = NOVALUE;
    int _13166 = NOVALUE;
    int _13164 = NOVALUE;
    int _13163 = NOVALUE;
    int _13162 = NOVALUE;
    int _13160 = NOVALUE;
    int _13159 = NOVALUE;
    int _13157 = NOVALUE;
    int _13156 = NOVALUE;
    int _13155 = NOVALUE;
    int _13153 = NOVALUE;
    int _13152 = NOVALUE;
    int _13149 = NOVALUE;
    int _13148 = NOVALUE;
    int _13147 = NOVALUE;
    int _13145 = NOVALUE;
    int _13144 = NOVALUE;
    int _13143 = NOVALUE;
    int _13141 = NOVALUE;
    int _13137 = NOVALUE;
    int _13135 = NOVALUE;
    int _13134 = NOVALUE;
    int _13133 = NOVALUE;
    int _13131 = NOVALUE;
    int _13130 = NOVALUE;
    int _13128 = NOVALUE;
    int _13127 = NOVALUE;
    int _13126 = NOVALUE;
    int _13125 = NOVALUE;
    int _13124 = NOVALUE;
    int _13123 = NOVALUE;
    int _13122 = NOVALUE;
    int _13121 = NOVALUE;
    int _13119 = NOVALUE;
    int _13118 = NOVALUE;
    int _13117 = NOVALUE;
    int _13115 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ma = allocate(SIZE_OF_STRUCT)*/
    _0 = _ma_23717;
    _ma_23717 = _59allocate(16);
    DeRef(_0);

    /** 	if integer(s) then -- most of the time it will be an integer(a)*/
    if (IS_ATOM_INT(_s_23716))
    _13115 = 1;
    else if (IS_ATOM_DBL(_s_23716))
    _13115 = IS_ATOM_INT(DoubleToInt(_s_23716));
    else
    _13115 = 0;
    if (_13115 == 0)
    {
        _13115 = NOVALUE;
        goto L1; // [12] 54
    }
    else{
        _13115 = NOVALUE;
    }

    /** 		i = s*/
    Ref(_s_23716);
    _i_23721 = _s_23716;
    if (!IS_ATOM_INT(_i_23721)) {
        _1 = (long)(DBL_PTR(_i_23721)->dbl);
        DeRefDS(_i_23721);
        _i_23721 = _1;
    }

    /** 		if i >= 0 then*/
    if (_i_23721 < 0)
    goto L2; // [24] 36

    /** 			poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58UINT_FLAG_23708)->dbl;
    goto L3; // [33] 42
L2: 

    /** 			poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58INT_FLAG_23706)->dbl;
L3: 

    /** 		poke4(ma + 4, i)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13117 = _ma_23717 + 4;
        if ((long)((unsigned long)_13117 + (unsigned long)HIGH_BITS) >= 0) 
        _13117 = NewDouble((double)_13117);
    }
    else {
        _13117 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13117)){
        poke4_addr = (unsigned long *)_13117;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13117)->dbl);
    }
    *poke4_addr = (unsigned long)_i_23721;
    DeRef(_13117);
    _13117 = NOVALUE;
    goto L4; // [51] 695
L1: 

    /** 	elsif atom(s) then*/
    _13118 = IS_ATOM(_s_23716);
    if (_13118 == 0)
    {
        _13118 = NOVALUE;
        goto L5; // [59] 212
    }
    else{
        _13118 = NOVALUE;
    }

    /** 		a = s*/
    Ref(_s_23716);
    DeRef(_a_23720);
    _a_23720 = _s_23716;

    /** 		if a = floor(a) then*/
    if (IS_ATOM_INT(_a_23720))
    _13119 = e_floor(_a_23720);
    else
    _13119 = unary_op(FLOOR, _a_23720);
    if (binary_op_a(NOTEQ, _a_23720, _13119)){
        DeRef(_13119);
        _13119 = NOVALUE;
        goto L6; // [72] 179
    }
    DeRef(_13119);
    _13119 = NOVALUE;

    /** 			if a <= #FFFFFFFF and a >= 0 then*/
    if (IS_ATOM_INT(_a_23720)) {
        _13121 = ((double)_a_23720 <= DBL_PTR(_13102)->dbl);
    }
    else {
        _13121 = (DBL_PTR(_a_23720)->dbl <= DBL_PTR(_13102)->dbl);
    }
    if (_13121 == 0) {
        goto L7; // [82] 111
    }
    if (IS_ATOM_INT(_a_23720)) {
        _13123 = (_a_23720 >= 0);
    }
    else {
        _13123 = (DBL_PTR(_a_23720)->dbl >= (double)0);
    }
    if (_13123 == 0)
    {
        DeRef(_13123);
        _13123 = NOVALUE;
        goto L7; // [91] 111
    }
    else{
        DeRef(_13123);
        _13123 = NOVALUE;
    }

    /** 				poke4(ma, UINT_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58UINT_FLAG_23708)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13124 = _ma_23717 + 4;
        if ((long)((unsigned long)_13124 + (unsigned long)HIGH_BITS) >= 0) 
        _13124 = NewDouble((double)_13124);
    }
    else {
        _13124 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13124)){
        poke4_addr = (unsigned long *)_13124;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13124)->dbl);
    }
    if (IS_ATOM_INT(_a_23720)) {
        *poke4_addr = (unsigned long)_a_23720;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_23720)->dbl;
    }
    DeRef(_13124);
    _13124 = NOVALUE;
    goto L4; // [108] 695
L7: 

    /** 			elsif a <= 2147483647 and a >= -2147483648 then*/
    if (IS_ATOM_INT(_a_23720)) {
        _13125 = ((double)_a_23720 <= DBL_PTR(_13105)->dbl);
    }
    else {
        _13125 = (DBL_PTR(_a_23720)->dbl <= DBL_PTR(_13105)->dbl);
    }
    if (_13125 == 0) {
        goto L8; // [117] 146
    }
    if (IS_ATOM_INT(_a_23720)) {
        _13127 = ((double)_a_23720 >= DBL_PTR(_13100)->dbl);
    }
    else {
        _13127 = (DBL_PTR(_a_23720)->dbl >= DBL_PTR(_13100)->dbl);
    }
    if (_13127 == 0)
    {
        DeRef(_13127);
        _13127 = NOVALUE;
        goto L8; // [126] 146
    }
    else{
        DeRef(_13127);
        _13127 = NOVALUE;
    }

    /** 				poke4(ma, INT_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58INT_FLAG_23706)->dbl;

    /** 				poke4(ma + 4, a)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13128 = _ma_23717 + 4;
        if ((long)((unsigned long)_13128 + (unsigned long)HIGH_BITS) >= 0) 
        _13128 = NewDouble((double)_13128);
    }
    else {
        _13128 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13128)){
        poke4_addr = (unsigned long *)_13128;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13128)->dbl);
    }
    if (IS_ATOM_INT(_a_23720)) {
        *poke4_addr = (unsigned long)_a_23720;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_23720)->dbl;
    }
    DeRef(_13128);
    _13128 = NOVALUE;
    goto L4; // [143] 695
L8: 

    /** 				tmp = allocate(8)*/
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(8);
    DeRef(_0);

    /** 				poke(tmp, atom_to_float64(a))*/
    Ref(_a_23720);
    _13130 = _59atom_to_float64(_a_23720);
    if (IS_ATOM_INT(_tmp_23719)){
        poke_addr = (unsigned char *)_tmp_23719;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
    }
    if (IS_ATOM_INT(_13130)) {
        *poke_addr = (unsigned char)_13130;
    }
    else if (IS_ATOM(_13130)) {
        *poke_addr = (signed char)DBL_PTR(_13130)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13130);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13130);
    _13130 = NOVALUE;

    /** 				poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58DOUBLE_FLAG_23704)->dbl;

    /** 				poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13131 = _ma_23717 + 4;
        if ((long)((unsigned long)_13131 + (unsigned long)HIGH_BITS) >= 0) 
        _13131 = NewDouble((double)_13131);
    }
    else {
        _13131 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13131)){
        poke4_addr = (unsigned long *)_13131;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13131)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13131);
    _13131 = NOVALUE;
    goto L4; // [176] 695
L6: 

    /** 			tmp = allocate(8)*/
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(8);
    DeRef(_0);

    /** 			poke(tmp, atom_to_float64(a))*/
    Ref(_a_23720);
    _13133 = _59atom_to_float64(_a_23720);
    if (IS_ATOM_INT(_tmp_23719)){
        poke_addr = (unsigned char *)_tmp_23719;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
    }
    if (IS_ATOM_INT(_13133)) {
        *poke_addr = (unsigned char)_13133;
    }
    else if (IS_ATOM(_13133)) {
        *poke_addr = (signed char)DBL_PTR(_13133)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_13133);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13133);
    _13133 = NOVALUE;

    /** 			poke4(ma, DOUBLE_FLAG)*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58DOUBLE_FLAG_23704)->dbl;

    /** 			poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13134 = _ma_23717 + 4;
        if ((long)((unsigned long)_13134 + (unsigned long)HIGH_BITS) >= 0) 
        _13134 = NewDouble((double)_13134);
    }
    else {
        _13134 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13134)){
        poke4_addr = (unsigned long *)_13134;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13134)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13134);
    _13134 = NOVALUE;
    goto L4; // [209] 695
L5: 

    /** 	elsif length(s) = 0 then*/
    if (IS_SEQUENCE(_s_23716)){
            _13135 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13135 = 1;
    }
    if (_13135 != 0)
    goto L9; // [217] 233

    /** 		poke4(ma, {NULL,NULL})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13137 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    _1 = (int)SEQ_PTR(_13137);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_13137);
    _13137 = NOVALUE;
    goto L4; // [230] 695
L9: 

    /** 		if not always_linked_list then*/
    if (_58always_linked_list_23632 != 0)
    goto LA; // [237] 548

    /** 			i = mystring(s)*/
    Ref(_s_23716);
    _i_23721 = _58mystring(_s_23716);
    if (!IS_ATOM_INT(_i_23721)) {
        _1 = (long)(DBL_PTR(_i_23721)->dbl);
        DeRefDS(_i_23721);
        _i_23721 = _1;
    }

    /** 			if i then -- string*/
    if (_i_23721 == 0)
    {
        goto LB; // [250] 338
    }
    else{
    }

    /** 				if i = 2 then*/
    if (_i_23721 != 2)
    goto LC; // [255] 297

    /** 					tmp = allocate(length(s))*/
    if (IS_SEQUENCE(_s_23716)){
            _13141 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13141 = 1;
    }
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(_13141);
    DeRef(_0);
    _13141 = NOVALUE;

    /** 					poke(tmp, s)*/
    if (IS_ATOM_INT(_tmp_23719)){
        poke_addr = (unsigned char *)_tmp_23719;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
    }
    if (IS_ATOM_INT(_s_23716)) {
        *poke_addr = (unsigned char)_s_23716;
    }
    else if (IS_ATOM(_s_23716)) {
        *poke_addr = (signed char)DBL_PTR(_s_23716)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_23716);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(CBYTES, length(s))) -- needs a check for MAX_LENGTH*/
    if (IS_SEQUENCE(_s_23716)){
            _13143 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13143 = 1;
    }
    temp_d.dbl = (double)_13143;
    _13144 = Dor_bits(DBL_PTR(_58CBYTES_23713), &temp_d);
    _13143 = NOVALUE;
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    if (IS_ATOM_INT(_13144)) {
        *poke4_addr = (unsigned long)_13144;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13144)->dbl;
    }
    DeRef(_13144);
    _13144 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13145 = _ma_23717 + 4;
        if ((long)((unsigned long)_13145 + (unsigned long)HIGH_BITS) >= 0) 
        _13145 = NewDouble((double)_13145);
    }
    else {
        _13145 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13145)){
        poke4_addr = (unsigned long *)_13145;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13145)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13145);
    _13145 = NOVALUE;
    goto LD; // [294] 318
LC: 

    /** 					tmp = allocate_string(s)*/
    Ref(_s_23716);
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate_string(_s_23716);
    DeRef(_0);

    /** 					poke4(ma, CSTRING) -- why?*/
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)DBL_PTR(_58CSTRING_23712)->dbl;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13147 = _ma_23717 + 4;
        if ((long)((unsigned long)_13147 + (unsigned long)HIGH_BITS) >= 0) 
        _13147 = NewDouble((double)_13147);
    }
    else {
        _13147 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13147)){
        poke4_addr = (unsigned long *)_13147;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13147)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13147);
    _13147 = NOVALUE;
LD: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13148 = _ma_23717 + 8;
        if ((long)((unsigned long)_13148 + (unsigned long)HIGH_BITS) >= 0) 
        _13148 = NewDouble((double)_13148);
    }
    else {
        _13148 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13149 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13148)){
        poke4_addr = (unsigned long *)_13148;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13148)->dbl);
    }
    _1 = (int)SEQ_PTR(_13149);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13148);
    _13148 = NOVALUE;
    DeRefDS(_13149);
    _13149 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_23716);
    DeRef(_next_23718);
    DeRef(_tmp_23719);
    DeRef(_a_23720);
    DeRef(_13121);
    _13121 = NOVALUE;
    DeRef(_13125);
    _13125 = NOVALUE;
    return _ma_23717;
LB: 

    /** 			i = myarray(s)*/
    Ref(_s_23716);
    _i_23721 = _58myarray(_s_23716);
    if (!IS_ATOM_INT(_i_23721)) {
        _1 = (long)(DBL_PTR(_i_23721)->dbl);
        DeRefDS(_i_23721);
        _i_23721 = _1;
    }

    /** 			if i then*/
    if (_i_23721 == 0)
    {
        goto LE; // [348] 547
    }
    else{
    }

    /** 				if i = 1 then*/
    if (_i_23721 != 1)
    goto LF; // [353] 399

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_23716)){
            _13152 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13152 = 1;
    }
    if (_13152 == (short)_13152)
    _13153 = _13152 * 4;
    else
    _13153 = NewDouble(_13152 * (double)4);
    _13152 = NOVALUE;
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(_13153);
    DeRef(_0);
    _13153 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_23719)){
        poke4_addr = (unsigned long *)_tmp_23719;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
    }
    if (IS_ATOM_INT(_s_23716)) {
        *poke4_addr = (unsigned long)_s_23716;
    }
    else if (IS_ATOM(_s_23716)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_23716)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_23716);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(UINT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_23716)){
            _13155 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13155 = 1;
    }
    temp_d.dbl = (double)_13155;
    _13156 = Dor_bits(DBL_PTR(_58UINT_FLAG_23708), &temp_d);
    _13155 = NOVALUE;
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    if (IS_ATOM_INT(_13156)) {
        *poke4_addr = (unsigned long)_13156;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13156)->dbl;
    }
    DeRef(_13156);
    _13156 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13157 = _ma_23717 + 4;
        if ((long)((unsigned long)_13157 + (unsigned long)HIGH_BITS) >= 0) 
        _13157 = NewDouble((double)_13157);
    }
    else {
        _13157 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13157)){
        poke4_addr = (unsigned long *)_13157;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13157)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13157);
    _13157 = NOVALUE;
    goto L10; // [396] 527
LF: 

    /** 				elsif i = 2 then*/
    if (_i_23721 != 2)
    goto L11; // [401] 447

    /** 					tmp = allocate(length(s) * 4)*/
    if (IS_SEQUENCE(_s_23716)){
            _13159 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13159 = 1;
    }
    if (_13159 == (short)_13159)
    _13160 = _13159 * 4;
    else
    _13160 = NewDouble(_13159 * (double)4);
    _13159 = NOVALUE;
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(_13160);
    DeRef(_0);
    _13160 = NOVALUE;

    /** 					poke4(tmp, s)*/
    if (IS_ATOM_INT(_tmp_23719)){
        poke4_addr = (unsigned long *)_tmp_23719;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
    }
    if (IS_ATOM_INT(_s_23716)) {
        *poke4_addr = (unsigned long)_s_23716;
    }
    else if (IS_ATOM(_s_23716)) {
        *poke4_addr = (unsigned long)DBL_PTR(_s_23716)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_s_23716);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }

    /** 					poke4(ma, or_bits(INT_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_23716)){
            _13162 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13162 = 1;
    }
    temp_d.dbl = (double)_13162;
    _13163 = Dor_bits(DBL_PTR(_58INT_FLAG_23706), &temp_d);
    _13162 = NOVALUE;
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    if (IS_ATOM_INT(_13163)) {
        *poke4_addr = (unsigned long)_13163;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13163)->dbl;
    }
    DeRef(_13163);
    _13163 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13164 = _ma_23717 + 4;
        if ((long)((unsigned long)_13164 + (unsigned long)HIGH_BITS) >= 0) 
        _13164 = NewDouble((double)_13164);
    }
    else {
        _13164 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13164)){
        poke4_addr = (unsigned long *)_13164;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13164)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13164);
    _13164 = NOVALUE;
    goto L10; // [444] 527
L11: 

    /** 				elsif i = 3 then*/
    if (_i_23721 != 3)
    goto L12; // [449] 526

    /** 					tmp = allocate(length(s) * 8)*/
    if (IS_SEQUENCE(_s_23716)){
            _13166 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13166 = 1;
    }
    if (_13166 == (short)_13166)
    _13167 = _13166 * 8;
    else
    _13167 = NewDouble(_13166 * (double)8);
    _13166 = NOVALUE;
    _0 = _tmp_23719;
    _tmp_23719 = _59allocate(_13167);
    DeRef(_0);
    _13167 = NOVALUE;

    /** 					for j = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_23716)){
            _13169 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13169 = 1;
    }
    {
        int _j_23807;
        _j_23807 = 1;
L13: 
        if (_j_23807 > _13169){
            goto L14; // [471] 504
        }

        /** 						poke(tmp, atom_to_float64(s[j]))*/
        _2 = (int)SEQ_PTR(_s_23716);
        _13170 = (int)*(((s1_ptr)_2)->base + _j_23807);
        Ref(_13170);
        _13171 = _59atom_to_float64(_13170);
        _13170 = NOVALUE;
        if (IS_ATOM_INT(_tmp_23719)){
            poke_addr = (unsigned char *)_tmp_23719;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_tmp_23719)->dbl);
        }
        if (IS_ATOM_INT(_13171)) {
            *poke_addr = (unsigned char)_13171;
        }
        else if (IS_ATOM(_13171)) {
            *poke_addr = (signed char)DBL_PTR(_13171)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_13171);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *poke_addr++ = (unsigned char)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
                }
            }
        }
        DeRef(_13171);
        _13171 = NOVALUE;

        /** 						tmp += 8*/
        _0 = _tmp_23719;
        if (IS_ATOM_INT(_tmp_23719)) {
            _tmp_23719 = _tmp_23719 + 8;
            if ((long)((unsigned long)_tmp_23719 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_23719 = NewDouble((double)_tmp_23719);
        }
        else {
            _tmp_23719 = NewDouble(DBL_PTR(_tmp_23719)->dbl + (double)8);
        }
        DeRef(_0);

        /** 					end for*/
        _j_23807 = _j_23807 + 1;
        goto L13; // [499] 478
L14: 
        ;
    }

    /** 					poke4(ma, or_bits(DOUBLE_FLAG, length(s)))*/
    if (IS_SEQUENCE(_s_23716)){
            _13173 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13173 = 1;
    }
    temp_d.dbl = (double)_13173;
    _13174 = Dor_bits(DBL_PTR(_58DOUBLE_FLAG_23704), &temp_d);
    _13173 = NOVALUE;
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    if (IS_ATOM_INT(_13174)) {
        *poke4_addr = (unsigned long)_13174;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_13174)->dbl;
    }
    DeRef(_13174);
    _13174 = NOVALUE;

    /** 					poke4(ma + 4, tmp)*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13175 = _ma_23717 + 4;
        if ((long)((unsigned long)_13175 + (unsigned long)HIGH_BITS) >= 0) 
        _13175 = NewDouble((double)_13175);
    }
    else {
        _13175 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13175)){
        poke4_addr = (unsigned long *)_13175;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13175)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13175);
    _13175 = NOVALUE;
L12: 
L10: 

    /** 				poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13176 = _ma_23717 + 8;
        if ((long)((unsigned long)_13176 + (unsigned long)HIGH_BITS) >= 0) 
        _13176 = NewDouble((double)_13176);
    }
    else {
        _13176 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13177 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13176)){
        poke4_addr = (unsigned long *)_13176;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13176)->dbl);
    }
    _1 = (int)SEQ_PTR(_13177);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13176);
    _13176 = NOVALUE;
    DeRefDS(_13177);
    _13177 = NOVALUE;

    /** 				return ma*/
    DeRef(_s_23716);
    DeRef(_next_23718);
    DeRef(_tmp_23719);
    DeRef(_a_23720);
    DeRef(_13121);
    _13121 = NOVALUE;
    DeRef(_13125);
    _13125 = NOVALUE;
    return _ma_23717;
LE: 
LA: 

    /** 		next = NULL -- 0*/
    DeRef(_next_23718);
    _next_23718 = 0;

    /** 		poke4(ma, length(s))*/
    if (IS_SEQUENCE(_s_23716)){
            _13178 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13178 = 1;
    }
    if (IS_ATOM_INT(_ma_23717)){
        poke4_addr = (unsigned long *)_ma_23717;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_ma_23717)->dbl);
    }
    *poke4_addr = (unsigned long)_13178;
    _13178 = NOVALUE;

    /** 		if length(s) then*/
    if (IS_SEQUENCE(_s_23716)){
            _13179 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13179 = 1;
    }
    if (_13179 == 0)
    {
        _13179 = NOVALUE;
        goto L15; // [566] 678
    }
    else{
        _13179 = NOVALUE;
    }

    /** 			a = allocate(8) -- iterators to beginning and end of list*/
    _0 = _a_23720;
    _a_23720 = _59allocate(8);
    DeRef(_0);

    /** 			next = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_23716)){
            _13181 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13181 = 1;
    }
    _2 = (int)SEQ_PTR(_s_23716);
    _13182 = (int)*(((s1_ptr)_2)->base + _13181);
    Ref(_13182);
    _next_23718 = _58sequence_to_linked_list(_13182);
    _13182 = NOVALUE;

    /** 			s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_23716)){
            _13184 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13184 = 1;
    }
    _13185 = _13184 - 1;
    _13184 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_23716;
    RHS_Slice(_s_23716, 1, _13185);

    /** 			poke4(a + 4, next) -- store the end iterator*/
    if (IS_ATOM_INT(_a_23720)) {
        _13187 = _a_23720 + 4;
        if ((long)((unsigned long)_13187 + (unsigned long)HIGH_BITS) >= 0) 
        _13187 = NewDouble((double)_13187);
    }
    else {
        _13187 = NewDouble(DBL_PTR(_a_23720)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13187)){
        poke4_addr = (unsigned long *)_13187;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13187)->dbl);
    }
    if (IS_ATOM_INT(_next_23718)) {
        *poke4_addr = (unsigned long)_next_23718;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_23718)->dbl;
    }
    DeRef(_13187);
    _13187 = NOVALUE;

    /** 			while length(s) do*/
L16: 
    if (IS_SEQUENCE(_s_23716)){
            _13188 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13188 = 1;
    }
    if (_13188 == 0)
    {
        _13188 = NOVALUE;
        goto L17; // [619] 677
    }
    else{
        _13188 = NOVALUE;
    }

    /** 				tmp = sequence_to_linked_list(s[$])*/
    if (IS_SEQUENCE(_s_23716)){
            _13189 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13189 = 1;
    }
    _2 = (int)SEQ_PTR(_s_23716);
    _13190 = (int)*(((s1_ptr)_2)->base + _13189);
    Ref(_13190);
    _0 = _tmp_23719;
    _tmp_23719 = _58sequence_to_linked_list(_13190);
    DeRef(_0);
    _13190 = NOVALUE;

    /** 				s = s[1..$-1]*/
    if (IS_SEQUENCE(_s_23716)){
            _13192 = SEQ_PTR(_s_23716)->length;
    }
    else {
        _13192 = 1;
    }
    _13193 = _13192 - 1;
    _13192 = NOVALUE;
    rhs_slice_target = (object_ptr)&_s_23716;
    RHS_Slice(_s_23716, 1, _13193);

    /** 				poke4(next + 8, tmp)*/
    if (IS_ATOM_INT(_next_23718)) {
        _13195 = _next_23718 + 8;
        if ((long)((unsigned long)_13195 + (unsigned long)HIGH_BITS) >= 0) 
        _13195 = NewDouble((double)_13195);
    }
    else {
        _13195 = NewDouble(DBL_PTR(_next_23718)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_13195)){
        poke4_addr = (unsigned long *)_13195;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13195)->dbl);
    }
    if (IS_ATOM_INT(_tmp_23719)) {
        *poke4_addr = (unsigned long)_tmp_23719;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_tmp_23719)->dbl;
    }
    DeRef(_13195);
    _13195 = NOVALUE;

    /** 				poke4(tmp + 12, next)*/
    if (IS_ATOM_INT(_tmp_23719)) {
        _13196 = _tmp_23719 + 12;
        if ((long)((unsigned long)_13196 + (unsigned long)HIGH_BITS) >= 0) 
        _13196 = NewDouble((double)_13196);
    }
    else {
        _13196 = NewDouble(DBL_PTR(_tmp_23719)->dbl + (double)12);
    }
    if (IS_ATOM_INT(_13196)){
        poke4_addr = (unsigned long *)_13196;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13196)->dbl);
    }
    if (IS_ATOM_INT(_next_23718)) {
        *poke4_addr = (unsigned long)_next_23718;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_23718)->dbl;
    }
    DeRef(_13196);
    _13196 = NOVALUE;

    /** 				next = tmp*/
    Ref(_tmp_23719);
    DeRef(_next_23718);
    _next_23718 = _tmp_23719;

    /** 			end while*/
    goto L16; // [674] 616
L17: 
L15: 

    /** 		poke4(a, next) -- store the beginning iterator*/
    if (IS_ATOM_INT(_a_23720)){
        poke4_addr = (unsigned long *)_a_23720;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_a_23720)->dbl);
    }
    if (IS_ATOM_INT(_next_23718)) {
        *poke4_addr = (unsigned long)_next_23718;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_next_23718)->dbl;
    }

    /** 		poke4(ma + 4, a) -- point data to the iterators*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13197 = _ma_23717 + 4;
        if ((long)((unsigned long)_13197 + (unsigned long)HIGH_BITS) >= 0) 
        _13197 = NewDouble((double)_13197);
    }
    else {
        _13197 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_13197)){
        poke4_addr = (unsigned long *)_13197;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13197)->dbl);
    }
    if (IS_ATOM_INT(_a_23720)) {
        *poke4_addr = (unsigned long)_a_23720;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_a_23720)->dbl;
    }
    DeRef(_13197);
    _13197 = NOVALUE;
L4: 

    /** 	poke4(ma + 8, {NULL,NULL}) -- what is this? sets *prev and *next to NULL or 0.*/
    if (IS_ATOM_INT(_ma_23717)) {
        _13198 = _ma_23717 + 8;
        if ((long)((unsigned long)_13198 + (unsigned long)HIGH_BITS) >= 0) 
        _13198 = NewDouble((double)_13198);
    }
    else {
        _13198 = NewDouble(DBL_PTR(_ma_23717)->dbl + (double)8);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _13199 = MAKE_SEQ(_1);
    if (IS_ATOM_INT(_13198)){
        poke4_addr = (unsigned long *)_13198;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_13198)->dbl);
    }
    _1 = (int)SEQ_PTR(_13199);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *(int *)poke4_addr++ = (unsigned long)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
        }
    }
    DeRef(_13198);
    _13198 = NOVALUE;
    DeRefDS(_13199);
    _13199 = NOVALUE;

    /** 	return ma*/
    DeRef(_s_23716);
    DeRef(_next_23718);
    DeRef(_tmp_23719);
    DeRef(_a_23720);
    DeRef(_13121);
    _13121 = NOVALUE;
    DeRef(_13125);
    _13125 = NOVALUE;
    DeRef(_13185);
    _13185 = NOVALUE;
    DeRef(_13193);
    _13193 = NOVALUE;
    return _ma_23717;
    ;
}


void _58free_linked_list(int _ma_23845)
{
    int _len_23846 = NOVALUE;
    int _tmp_23847 = NOVALUE;
    int _next_23848 = NOVALUE;
    int _ptr_23849 = NOVALUE;
    int _13211 = NOVALUE;
    int _13209 = NOVALUE;
    int _13208 = NOVALUE;
    int _13204 = NOVALUE;
    int _13203 = NOVALUE;
    int _13201 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_23846);
    if (IS_ATOM_INT(_ma_23845)) {
        _len_23846 = *(unsigned long *)_ma_23845;
        if ((unsigned)_len_23846 > (unsigned)MAXINT)
        _len_23846 = NewDouble((double)(unsigned long)_len_23846);
    }
    else {
        _len_23846 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_23845)->dbl);
        if ((unsigned)_len_23846 > (unsigned)MAXINT)
        _len_23846 = NewDouble((double)(unsigned long)_len_23846);
    }

    /** 	ptr = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23845)) {
        _13201 = _ma_23845 + 4;
        if ((long)((unsigned long)_13201 + (unsigned long)HIGH_BITS) >= 0) 
        _13201 = NewDouble((double)_13201);
    }
    else {
        _13201 = NewDouble(DBL_PTR(_ma_23845)->dbl + (double)4);
    }
    DeRef(_ptr_23849);
    if (IS_ATOM_INT(_13201)) {
        _ptr_23849 = *(unsigned long *)_13201;
        if ((unsigned)_ptr_23849 > (unsigned)MAXINT)
        _ptr_23849 = NewDouble((double)(unsigned long)_ptr_23849);
    }
    else {
        _ptr_23849 = *(unsigned long *)(unsigned long)(DBL_PTR(_13201)->dbl);
        if ((unsigned)_ptr_23849 > (unsigned)MAXINT)
        _ptr_23849 = NewDouble((double)(unsigned long)_ptr_23849);
    }
    DeRef(_13201);
    _13201 = NOVALUE;

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_23846)) {
        temp_d.dbl = (double)_len_23846;
        _13203 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_FLAG_23703));
    }
    else {
        _13203 = Dand_bits(DBL_PTR(_len_23846), DBL_PTR(_58SIGN_FLAG_23703));
    }
    if (_13203 == 0) {
        DeRef(_13203);
        _13203 = NOVALUE;
        goto L1; // [21] 57
    }
    else {
        if (!IS_ATOM_INT(_13203) && DBL_PTR(_13203)->dbl == 0.0){
            DeRef(_13203);
            _13203 = NOVALUE;
            goto L1; // [21] 57
        }
        DeRef(_13203);
        _13203 = NOVALUE;
    }
    DeRef(_13203);
    _13203 = NOVALUE;

    /** 	 	if and_bits(len, MAX_LENGTH) then*/
    if (IS_ATOM_INT(_len_23846)) {
        {unsigned long tu;
             tu = (unsigned long)_len_23846 & (unsigned long)268435455;
             _13204 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _13204 = Dand_bits(DBL_PTR(_len_23846), &temp_d);
    }
    if (_13204 == 0) {
        DeRef(_13204);
        _13204 = NOVALUE;
        goto L2; // [30] 41
    }
    else {
        if (!IS_ATOM_INT(_13204) && DBL_PTR(_13204)->dbl == 0.0){
            DeRef(_13204);
            _13204 = NOVALUE;
            goto L2; // [30] 41
        }
        DeRef(_13204);
        _13204 = NOVALUE;
    }
    DeRef(_13204);
    _13204 = NOVALUE;

    /** 			free(ptr)*/
    Ref(_ptr_23849);
    _59free(_ptr_23849);
    goto L3; // [38] 116
L2: 

    /** 		elsif len = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _len_23846, _58DOUBLE_FLAG_23704)){
        goto L3; // [43] 116
    }

    /** 			free(ptr)*/
    Ref(_ptr_23849);
    _59free(_ptr_23849);
    goto L3; // [54] 116
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_23846, 0)){
        goto L4; // [59] 115
    }

    /** 		tmp = peek4u(ptr) -- iterator to the beginning of the list*/
    DeRef(_tmp_23847);
    if (IS_ATOM_INT(_ptr_23849)) {
        _tmp_23847 = *(unsigned long *)_ptr_23849;
        if ((unsigned)_tmp_23847 > (unsigned)MAXINT)
        _tmp_23847 = NewDouble((double)(unsigned long)_tmp_23847);
    }
    else {
        _tmp_23847 = *(unsigned long *)(unsigned long)(DBL_PTR(_ptr_23849)->dbl);
        if ((unsigned)_tmp_23847 > (unsigned)MAXINT)
        _tmp_23847 = NewDouble((double)(unsigned long)_tmp_23847);
    }

    /** 		free(ptr) -- free the iterators*/
    Ref(_ptr_23849);
    _59free(_ptr_23849);

    /** 		for i = 1 to len do*/
    Ref(_len_23846);
    DeRef(_13208);
    _13208 = _len_23846;
    {
        int _i_23866;
        _i_23866 = 1;
L5: 
        if (binary_op_a(GREATER, _i_23866, _13208)){
            goto L6; // [78] 114
        }

        /** 			next = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_23847)) {
            _13209 = _tmp_23847 + 12;
            if ((long)((unsigned long)_13209 + (unsigned long)HIGH_BITS) >= 0) 
            _13209 = NewDouble((double)_13209);
        }
        else {
            _13209 = NewDouble(DBL_PTR(_tmp_23847)->dbl + (double)12);
        }
        DeRef(_next_23848);
        if (IS_ATOM_INT(_13209)) {
            _next_23848 = *(unsigned long *)_13209;
            if ((unsigned)_next_23848 > (unsigned)MAXINT)
            _next_23848 = NewDouble((double)(unsigned long)_next_23848);
        }
        else {
            _next_23848 = *(unsigned long *)(unsigned long)(DBL_PTR(_13209)->dbl);
            if ((unsigned)_next_23848 > (unsigned)MAXINT)
            _next_23848 = NewDouble((double)(unsigned long)_next_23848);
        }
        DeRef(_13209);
        _13209 = NOVALUE;

        /** 			free_linked_list(tmp)*/
        Ref(_tmp_23847);
        DeRef(_13211);
        _13211 = _tmp_23847;
        _58free_linked_list(_13211);
        _13211 = NOVALUE;

        /** 			tmp = next*/
        Ref(_next_23848);
        DeRef(_tmp_23847);
        _tmp_23847 = _next_23848;

        /** 		end for*/
        _0 = _i_23866;
        if (IS_ATOM_INT(_i_23866)) {
            _i_23866 = _i_23866 + 1;
            if ((long)((unsigned long)_i_23866 +(unsigned long) HIGH_BITS) >= 0){
                _i_23866 = NewDouble((double)_i_23866);
            }
        }
        else {
            _i_23866 = binary_op_a(PLUS, _i_23866, 1);
        }
        DeRef(_0);
        goto L5; // [109] 85
L6: 
        ;
        DeRef(_i_23866);
    }
L4: 
L3: 

    /** 	free(ma)*/
    Ref(_ma_23845);
    _59free(_ma_23845);

    /** end procedure*/
    DeRef(_ma_23845);
    DeRef(_len_23846);
    DeRef(_tmp_23847);
    DeRef(_next_23848);
    DeRef(_ptr_23849);
    return;
    ;
}


int _58linked_list_to_sequence(int _ma_23874)
{
    int _len_23875 = NOVALUE;
    int _tmp_23876 = NOVALUE;
    int _val_23877 = NOVALUE;
    int _s_23878 = NOVALUE;
    int _13270 = NOVALUE;
    int _13269 = NOVALUE;
    int _13267 = NOVALUE;
    int _13266 = NOVALUE;
    int _13265 = NOVALUE;
    int _13264 = NOVALUE;
    int _13260 = NOVALUE;
    int _13257 = NOVALUE;
    int _13255 = NOVALUE;
    int _13254 = NOVALUE;
    int _13252 = NOVALUE;
    int _13251 = NOVALUE;
    int _13250 = NOVALUE;
    int _13249 = NOVALUE;
    int _13245 = NOVALUE;
    int _13243 = NOVALUE;
    int _13242 = NOVALUE;
    int _13241 = NOVALUE;
    int _13239 = NOVALUE;
    int _13238 = NOVALUE;
    int _13237 = NOVALUE;
    int _13236 = NOVALUE;
    int _13233 = NOVALUE;
    int _13230 = NOVALUE;
    int _13228 = NOVALUE;
    int _13227 = NOVALUE;
    int _13224 = NOVALUE;
    int _13222 = NOVALUE;
    int _13221 = NOVALUE;
    int _13215 = NOVALUE;
    int _13213 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = peek4u(ma)*/
    DeRef(_len_23875);
    if (IS_ATOM_INT(_ma_23874)) {
        _len_23875 = *(unsigned long *)_ma_23874;
        if ((unsigned)_len_23875 > (unsigned)MAXINT)
        _len_23875 = NewDouble((double)(unsigned long)_len_23875);
    }
    else {
        _len_23875 = *(unsigned long *)(unsigned long)(DBL_PTR(_ma_23874)->dbl);
        if ((unsigned)_len_23875 > (unsigned)MAXINT)
        _len_23875 = NewDouble((double)(unsigned long)_len_23875);
    }

    /** 	if and_bits(len, SIGN_FLAG) then*/
    if (IS_ATOM_INT(_len_23875)) {
        temp_d.dbl = (double)_len_23875;
        _13213 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_FLAG_23703));
    }
    else {
        _13213 = Dand_bits(DBL_PTR(_len_23875), DBL_PTR(_58SIGN_FLAG_23703));
    }
    if (_13213 == 0) {
        DeRef(_13213);
        _13213 = NOVALUE;
        goto L1; // [12] 380
    }
    else {
        if (!IS_ATOM_INT(_13213) && DBL_PTR(_13213)->dbl == 0.0){
            DeRef(_13213);
            _13213 = NOVALUE;
            goto L1; // [12] 380
        }
        DeRef(_13213);
        _13213 = NOVALUE;
    }
    DeRef(_13213);
    _13213 = NOVALUE;

    /** 		if len = CSTRING then*/
    if (binary_op_a(NOTEQ, _len_23875, _58CSTRING_23712)){
        goto L2; // [17] 44
    }

    /** 			tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13215 = _ma_23874 + 4;
        if ((long)((unsigned long)_13215 + (unsigned long)HIGH_BITS) >= 0) 
        _13215 = NewDouble((double)_13215);
    }
    else {
        _13215 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13215)) {
        _tmp_23876 = *(unsigned long *)_13215;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13215)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_13215);
    _13215 = NOVALUE;

    /** 			s = peek_string(tmp)*/
    DeRef(_s_23878);
    if (IS_ATOM_INT(_tmp_23876)) {
        _s_23878 =  NewString((char *)_tmp_23876);
    }
    else {
        _s_23878 = NewString((char *)(unsigned long)(DBL_PTR(_tmp_23876)->dbl));
    }

    /** 			return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
L2: 

    /** 		val = and_bits(len, SIGN_MASK)*/
    DeRef(_val_23877);
    if (IS_ATOM_INT(_len_23875)) {
        temp_d.dbl = (double)_len_23875;
        _val_23877 = Dand_bits(&temp_d, DBL_PTR(_58SIGN_MASK_23701));
    }
    else {
        _val_23877 = Dand_bits(DBL_PTR(_len_23875), DBL_PTR(_58SIGN_MASK_23701));
    }

    /** 		len = and_bits(len, MAX_LENGTH)*/
    _0 = _len_23875;
    if (IS_ATOM_INT(_len_23875)) {
        {unsigned long tu;
             tu = (unsigned long)_len_23875 & (unsigned long)268435455;
             _len_23875 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)268435455;
        _len_23875 = Dand_bits(DBL_PTR(_len_23875), &temp_d);
    }
    DeRef(_0);

    /** 		if val = UINT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_23877, _58UINT_FLAG_23708)){
        goto L3; // [58] 108
    }

    /** 			if len then*/
    if (_len_23875 == 0) {
        goto L4; // [64] 91
    }
    else {
        if (!IS_ATOM_INT(_len_23875) && DBL_PTR(_len_23875)->dbl == 0.0){
            goto L4; // [64] 91
        }
    }

    /** 				s = peek4u({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13221 = _ma_23874 + 4;
        if ((long)((unsigned long)_13221 + (unsigned long)HIGH_BITS) >= 0) 
        _13221 = NewDouble((double)_13221);
    }
    else {
        _13221 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    Ref(_len_23875);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13221;
    ((int *)_2)[2] = _len_23875;
    _13222 = MAKE_SEQ(_1);
    _13221 = NOVALUE;
    DeRef(_s_23878);
    _1 = (int)SEQ_PTR(_13222);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_23878 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13222);
    _13222 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto L5; // [88] 107
L4: 

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13224 = _ma_23874 + 4;
        if ((long)((unsigned long)_13224 + (unsigned long)HIGH_BITS) >= 0) 
        _13224 = NewDouble((double)_13224);
    }
    else {
        _13224 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13224)) {
        _tmp_23876 = *(unsigned long *)_13224;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13224)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_13224);
    _13224 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_val_23877);
    DeRef(_s_23878);
    return _tmp_23876;
L5: 
L3: 

    /** 		if val = INT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_23877, _58INT_FLAG_23706)){
        goto L6; // [110] 160
    }

    /** 			if len then*/
    if (_len_23875 == 0) {
        goto L7; // [116] 143
    }
    else {
        if (!IS_ATOM_INT(_len_23875) && DBL_PTR(_len_23875)->dbl == 0.0){
            goto L7; // [116] 143
        }
    }

    /** 				s = peek4s({ma + 4, len})*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13227 = _ma_23874 + 4;
        if ((long)((unsigned long)_13227 + (unsigned long)HIGH_BITS) >= 0) 
        _13227 = NewDouble((double)_13227);
    }
    else {
        _13227 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    Ref(_len_23875);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13227;
    ((int *)_2)[2] = _len_23875;
    _13228 = MAKE_SEQ(_1);
    _13227 = NOVALUE;
    DeRef(_s_23878);
    _1 = (int)SEQ_PTR(_13228);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_23878 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if (_1 < MININT || _1 > MAXINT)
        _1 = NewDouble((double)(long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13228);
    _13228 = NOVALUE;

    /** 				return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto L8; // [140] 159
L7: 

    /** 				tmp = peek4s(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13230 = _ma_23874 + 4;
        if ((long)((unsigned long)_13230 + (unsigned long)HIGH_BITS) >= 0) 
        _13230 = NewDouble((double)_13230);
    }
    else {
        _13230 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13230)) {
        _tmp_23876 = *(unsigned long *)_13230;
        if (_tmp_23876 < MININT || _tmp_23876 > MAXINT)
        _tmp_23876 = NewDouble((double)(long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13230)->dbl);
        if (_tmp_23876 < MININT || _tmp_23876 > MAXINT)
        _tmp_23876 = NewDouble((double)(long)_tmp_23876);
    }
    DeRef(_13230);
    _13230 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_val_23877);
    DeRef(_s_23878);
    return _tmp_23876;
L8: 
L6: 

    /** 		if val = FLOAT_FLAG then*/
    if (binary_op_a(NOTEQ, _val_23877, _58FLOAT_FLAG_23710)){
        goto L9; // [162] 262
    }

    /** 			if len then*/
    if (_len_23875 == 0) {
        goto LA; // [168] 237
    }
    else {
        if (!IS_ATOM_INT(_len_23875) && DBL_PTR(_len_23875)->dbl == 0.0){
            goto LA; // [168] 237
        }
    }

    /** 				tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13233 = _ma_23874 + 4;
        if ((long)((unsigned long)_13233 + (unsigned long)HIGH_BITS) >= 0) 
        _13233 = NewDouble((double)_13233);
    }
    else {
        _13233 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13233)) {
        _tmp_23876 = *(unsigned long *)_13233;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13233)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_13233);
    _13233 = NOVALUE;

    /** 				s = repeat(0, len)*/
    DeRef(_s_23878);
    _s_23878 = Repeat(0, _len_23875);

    /** 				for i = 1 to len do*/
    Ref(_len_23875);
    DeRef(_13236);
    _13236 = _len_23875;
    {
        int _i_23914;
        _i_23914 = 1;
LB: 
        if (binary_op_a(GREATER, _i_23914, _13236)){
            goto LC; // [191] 228
        }

        /** 					s[i] = float32_to_atom(peek({tmp, 4}))*/
        Ref(_tmp_23876);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_23876;
        ((int *)_2)[2] = 4;
        _13237 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_13237);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13238 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_13237);
        _13237 = NOVALUE;
        _13239 = _59float32_to_atom(_13238);
        _13238 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_23878);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_23878 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_23914))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_23914)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_23914);
        _1 = *(int *)_2;
        *(int *)_2 = _13239;
        if( _1 != _13239 ){
            DeRef(_1);
        }
        _13239 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_23876;
        if (IS_ATOM_INT(_tmp_23876)) {
            _tmp_23876 = _tmp_23876 + 8;
            if ((long)((unsigned long)_tmp_23876 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_23876 = NewDouble((double)_tmp_23876);
        }
        else {
            _tmp_23876 = NewDouble(DBL_PTR(_tmp_23876)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_23914;
        if (IS_ATOM_INT(_i_23914)) {
            _i_23914 = _i_23914 + 1;
            if ((long)((unsigned long)_i_23914 +(unsigned long) HIGH_BITS) >= 0){
                _i_23914 = NewDouble((double)_i_23914);
            }
        }
        else {
            _i_23914 = binary_op_a(PLUS, _i_23914, 1);
        }
        DeRef(_0);
        goto LB; // [223] 198
LC: 
        ;
        DeRef(_i_23914);
    }

    /** 				return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto LD; // [234] 261
LA: 

    /** 				tmp = float32_to_atom(peek({ma + 4, 4}))*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13241 = _ma_23874 + 4;
        if ((long)((unsigned long)_13241 + (unsigned long)HIGH_BITS) >= 0) 
        _13241 = NewDouble((double)_13241);
    }
    else {
        _13241 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13241;
    ((int *)_2)[2] = 4;
    _13242 = MAKE_SEQ(_1);
    _13241 = NOVALUE;
    _1 = (int)SEQ_PTR(_13242);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _13243 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13242);
    _13242 = NOVALUE;
    _0 = _tmp_23876;
    _tmp_23876 = _59float32_to_atom(_13243);
    DeRef(_0);
    _13243 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_val_23877);
    DeRef(_s_23878);
    return _tmp_23876;
LD: 
L9: 

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13245 = _ma_23874 + 4;
        if ((long)((unsigned long)_13245 + (unsigned long)HIGH_BITS) >= 0) 
        _13245 = NewDouble((double)_13245);
    }
    else {
        _13245 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13245)) {
        _tmp_23876 = *(unsigned long *)_13245;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13245)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_13245);
    _13245 = NOVALUE;

    /** 		if val = DOUBLE_FLAG then*/
    if (binary_op_a(NOTEQ, _val_23877, _58DOUBLE_FLAG_23704)){
        goto LE; // [273] 360
    }

    /** 			if len then*/
    if (_len_23875 == 0) {
        goto LF; // [279] 339
    }
    else {
        if (!IS_ATOM_INT(_len_23875) && DBL_PTR(_len_23875)->dbl == 0.0){
            goto LF; // [279] 339
        }
    }

    /** 				s = repeat(0, len)*/
    DeRef(_s_23878);
    _s_23878 = Repeat(0, _len_23875);

    /** 				for i = 1 to len do*/
    Ref(_len_23875);
    DeRef(_13249);
    _13249 = _len_23875;
    {
        int _i_23934;
        _i_23934 = 1;
L10: 
        if (binary_op_a(GREATER, _i_23934, _13249)){
            goto L11; // [293] 330
        }

        /** 					s[i] = float64_to_atom(peek({tmp, 8}))*/
        Ref(_tmp_23876);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _tmp_23876;
        ((int *)_2)[2] = 8;
        _13250 = MAKE_SEQ(_1);
        _1 = (int)SEQ_PTR(_13250);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _13251 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        DeRefDS(_13250);
        _13250 = NOVALUE;
        _13252 = _59float64_to_atom(_13251);
        _13251 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_23878);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_23878 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_23934))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_23934)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_23934);
        _1 = *(int *)_2;
        *(int *)_2 = _13252;
        if( _1 != _13252 ){
            DeRef(_1);
        }
        _13252 = NOVALUE;

        /** 					tmp += 8*/
        _0 = _tmp_23876;
        if (IS_ATOM_INT(_tmp_23876)) {
            _tmp_23876 = _tmp_23876 + 8;
            if ((long)((unsigned long)_tmp_23876 + (unsigned long)HIGH_BITS) >= 0) 
            _tmp_23876 = NewDouble((double)_tmp_23876);
        }
        else {
            _tmp_23876 = NewDouble(DBL_PTR(_tmp_23876)->dbl + (double)8);
        }
        DeRef(_0);

        /** 				end for*/
        _0 = _i_23934;
        if (IS_ATOM_INT(_i_23934)) {
            _i_23934 = _i_23934 + 1;
            if ((long)((unsigned long)_i_23934 +(unsigned long) HIGH_BITS) >= 0){
                _i_23934 = NewDouble((double)_i_23934);
            }
        }
        else {
            _i_23934 = binary_op_a(PLUS, _i_23934, 1);
        }
        DeRef(_0);
        goto L10; // [325] 300
L11: 
        ;
        DeRef(_i_23934);
    }

    /** 				return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto L12; // [336] 359
LF: 

    /** 				tmp = float64_to_atom(peek({tmp, 8}))*/
    Ref(_tmp_23876);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_23876;
    ((int *)_2)[2] = 8;
    _13254 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_13254);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _13255 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13254);
    _13254 = NOVALUE;
    _0 = _tmp_23876;
    _tmp_23876 = _59float64_to_atom(_13255);
    DeRef(_0);
    _13255 = NOVALUE;

    /** 				return tmp*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_val_23877);
    DeRef(_s_23878);
    return _tmp_23876;
L12: 
LE: 

    /** 		s = peek({tmp, len})*/
    Ref(_len_23875);
    Ref(_tmp_23876);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tmp_23876;
    ((int *)_2)[2] = _len_23875;
    _13257 = MAKE_SEQ(_1);
    DeRef(_s_23878);
    _1 = (int)SEQ_PTR(_13257);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _s_23878 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13257);
    _13257 = NOVALUE;

    /** 		return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto L13; // [377] 476
L1: 

    /** 	elsif len > 0 then*/
    if (binary_op_a(LESSEQ, _len_23875, 0)){
        goto L14; // [382] 469
    }

    /** 		tmp = peek4u(ma + 4)*/
    if (IS_ATOM_INT(_ma_23874)) {
        _13260 = _ma_23874 + 4;
        if ((long)((unsigned long)_13260 + (unsigned long)HIGH_BITS) >= 0) 
        _13260 = NewDouble((double)_13260);
    }
    else {
        _13260 = NewDouble(DBL_PTR(_ma_23874)->dbl + (double)4);
    }
    DeRef(_tmp_23876);
    if (IS_ATOM_INT(_13260)) {
        _tmp_23876 = *(unsigned long *)_13260;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13260)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_13260);
    _13260 = NOVALUE;

    /** 		tmp = peek4u(tmp)*/
    _0 = _tmp_23876;
    if (IS_ATOM_INT(_tmp_23876)) {
        _tmp_23876 = *(unsigned long *)_tmp_23876;
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    else {
        _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_tmp_23876)->dbl);
        if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
        _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
    }
    DeRef(_0);

    /** 		s = repeat(0, len)*/
    DeRef(_s_23878);
    _s_23878 = Repeat(0, _len_23875);

    /** 		s[1] = linked_list_to_sequence(tmp)*/
    Ref(_tmp_23876);
    DeRef(_13264);
    _13264 = _tmp_23876;
    _13265 = _58linked_list_to_sequence(_13264);
    _13264 = NOVALUE;
    _2 = (int)SEQ_PTR(_s_23878);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_23878 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _13265;
    if( _1 != _13265 ){
    }
    _13265 = NOVALUE;

    /** 		for i = 2 to length(s) do*/
    if (IS_SEQUENCE(_s_23878)){
            _13266 = SEQ_PTR(_s_23878)->length;
    }
    else {
        _13266 = 1;
    }
    {
        int _i_23957;
        _i_23957 = 2;
L15: 
        if (_i_23957 > _13266){
            goto L16; // [424] 460
        }

        /** 			tmp = peek4u(tmp + 12)*/
        if (IS_ATOM_INT(_tmp_23876)) {
            _13267 = _tmp_23876 + 12;
            if ((long)((unsigned long)_13267 + (unsigned long)HIGH_BITS) >= 0) 
            _13267 = NewDouble((double)_13267);
        }
        else {
            _13267 = NewDouble(DBL_PTR(_tmp_23876)->dbl + (double)12);
        }
        DeRef(_tmp_23876);
        if (IS_ATOM_INT(_13267)) {
            _tmp_23876 = *(unsigned long *)_13267;
            if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
            _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
        }
        else {
            _tmp_23876 = *(unsigned long *)(unsigned long)(DBL_PTR(_13267)->dbl);
            if ((unsigned)_tmp_23876 > (unsigned)MAXINT)
            _tmp_23876 = NewDouble((double)(unsigned long)_tmp_23876);
        }
        DeRef(_13267);
        _13267 = NOVALUE;

        /** 			s[i] = linked_list_to_sequence(tmp)*/
        Ref(_tmp_23876);
        DeRef(_13269);
        _13269 = _tmp_23876;
        _13270 = _58linked_list_to_sequence(_13269);
        _13269 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_23878);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_23878 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_23957);
        _1 = *(int *)_2;
        *(int *)_2 = _13270;
        if( _1 != _13270 ){
            DeRef(_1);
        }
        _13270 = NOVALUE;

        /** 		end for*/
        _i_23957 = _i_23957 + 1;
        goto L15; // [455] 431
L16: 
        ;
    }

    /** 		return s*/
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    return _s_23878;
    goto L13; // [466] 476
L14: 

    /** 		return {}*/
    RefDS(_5);
    DeRef(_ma_23874);
    DeRef(_len_23875);
    DeRef(_tmp_23876);
    DeRef(_val_23877);
    DeRef(_s_23878);
    return _5;
L13: 
    ;
}



// 0xC75A7223
