// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _31local_abort(int _lvl_15231)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236 = NOVALUE;
    int _8575 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    if (IS_SEQUENCE(_31pause_msg_15228)){
            _8575 = SEQ_PTR(_31pause_msg_15228)->length;
    }
    else {
        _8575 = 1;
    }
    if (_8575 == 0)
    goto L1; // [10] 45

    /** 		console:maybe_any_key(pause_msg, 1)*/

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236)) {
        if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236 != 0){
            goto L2; // [27] 42
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236)->dbl != 0.0){
            goto L2; // [27] 42
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_31pause_msg_15228);
    _32any_key(_31pause_msg_15228, 1);

    /** end procedure*/
    goto L2; // [39] 42
L2: 
    DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236);
    _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_15236 = NOVALUE;
L1: 

    /** 	abort(lvl)*/
    UserCleanup(_lvl_15231);

    /** end procedure*/
    return;
    ;
}


int _31standardize_opts(int _opts_15239, int _auto_help_switches_15240)
{
    int _lExtras_15241 = NOVALUE;
    int _opt_15245 = NOVALUE;
    int _updated_15247 = NOVALUE;
    int _msg_inlined_crash_at_178_15279 = NOVALUE;
    int _msg_inlined_crash_at_354_15310 = NOVALUE;
    int _msg_inlined_crash_at_410_15319 = NOVALUE;
    int _msg_inlined_crash_at_460_15328 = NOVALUE;
    int _msg_inlined_crash_at_510_15337 = NOVALUE;
    int _msg_inlined_crash_at_560_15346 = NOVALUE;
    int _opt_15380 = NOVALUE;
    int _msg_inlined_crash_at_878_15399 = NOVALUE;
    int _data_inlined_crash_at_875_15398 = NOVALUE;
    int _msg_inlined_crash_at_967_15417 = NOVALUE;
    int _data_inlined_crash_at_964_15416 = NOVALUE;
    int _has_h_15418 = NOVALUE;
    int _has_help_15419 = NOVALUE;
    int _has_question_15420 = NOVALUE;
    int _appended_opts_15440 = NOVALUE;
    int _8752 = NOVALUE;
    int _8751 = NOVALUE;
    int _8749 = NOVALUE;
    int _8748 = NOVALUE;
    int _8747 = NOVALUE;
    int _8746 = NOVALUE;
    int _8745 = NOVALUE;
    int _8744 = NOVALUE;
    int _8743 = NOVALUE;
    int _8742 = NOVALUE;
    int _8741 = NOVALUE;
    int _8740 = NOVALUE;
    int _8739 = NOVALUE;
    int _8738 = NOVALUE;
    int _8736 = NOVALUE;
    int _8735 = NOVALUE;
    int _8734 = NOVALUE;
    int _8733 = NOVALUE;
    int _8732 = NOVALUE;
    int _8731 = NOVALUE;
    int _8730 = NOVALUE;
    int _8729 = NOVALUE;
    int _8728 = NOVALUE;
    int _8727 = NOVALUE;
    int _8726 = NOVALUE;
    int _8725 = NOVALUE;
    int _8723 = NOVALUE;
    int _8721 = NOVALUE;
    int _8720 = NOVALUE;
    int _8719 = NOVALUE;
    int _8718 = NOVALUE;
    int _8716 = NOVALUE;
    int _8714 = NOVALUE;
    int _8711 = NOVALUE;
    int _8708 = NOVALUE;
    int _8705 = NOVALUE;
    int _8703 = NOVALUE;
    int _8702 = NOVALUE;
    int _8701 = NOVALUE;
    int _8700 = NOVALUE;
    int _8698 = NOVALUE;
    int _8697 = NOVALUE;
    int _8696 = NOVALUE;
    int _8694 = NOVALUE;
    int _8693 = NOVALUE;
    int _8692 = NOVALUE;
    int _8690 = NOVALUE;
    int _8689 = NOVALUE;
    int _8688 = NOVALUE;
    int _8687 = NOVALUE;
    int _8686 = NOVALUE;
    int _8684 = NOVALUE;
    int _8683 = NOVALUE;
    int _8682 = NOVALUE;
    int _8681 = NOVALUE;
    int _8680 = NOVALUE;
    int _8679 = NOVALUE;
    int _8678 = NOVALUE;
    int _8677 = NOVALUE;
    int _8676 = NOVALUE;
    int _8675 = NOVALUE;
    int _8673 = NOVALUE;
    int _8672 = NOVALUE;
    int _8671 = NOVALUE;
    int _8670 = NOVALUE;
    int _8669 = NOVALUE;
    int _8668 = NOVALUE;
    int _8667 = NOVALUE;
    int _8666 = NOVALUE;
    int _8664 = NOVALUE;
    int _8663 = NOVALUE;
    int _8662 = NOVALUE;
    int _8661 = NOVALUE;
    int _8660 = NOVALUE;
    int _8659 = NOVALUE;
    int _8658 = NOVALUE;
    int _8657 = NOVALUE;
    int _8656 = NOVALUE;
    int _8655 = NOVALUE;
    int _8654 = NOVALUE;
    int _8653 = NOVALUE;
    int _8652 = NOVALUE;
    int _8651 = NOVALUE;
    int _8650 = NOVALUE;
    int _8648 = NOVALUE;
    int _8646 = NOVALUE;
    int _8645 = NOVALUE;
    int _8644 = NOVALUE;
    int _8643 = NOVALUE;
    int _8641 = NOVALUE;
    int _8640 = NOVALUE;
    int _8639 = NOVALUE;
    int _8638 = NOVALUE;
    int _8636 = NOVALUE;
    int _8635 = NOVALUE;
    int _8634 = NOVALUE;
    int _8633 = NOVALUE;
    int _8631 = NOVALUE;
    int _8630 = NOVALUE;
    int _8629 = NOVALUE;
    int _8628 = NOVALUE;
    int _8626 = NOVALUE;
    int _8625 = NOVALUE;
    int _8624 = NOVALUE;
    int _8623 = NOVALUE;
    int _8620 = NOVALUE;
    int _8619 = NOVALUE;
    int _8618 = NOVALUE;
    int _8617 = NOVALUE;
    int _8616 = NOVALUE;
    int _8615 = NOVALUE;
    int _8614 = NOVALUE;
    int _8613 = NOVALUE;
    int _8611 = NOVALUE;
    int _8610 = NOVALUE;
    int _8609 = NOVALUE;
    int _8608 = NOVALUE;
    int _8607 = NOVALUE;
    int _8606 = NOVALUE;
    int _8605 = NOVALUE;
    int _8604 = NOVALUE;
    int _8601 = NOVALUE;
    int _8600 = NOVALUE;
    int _8599 = NOVALUE;
    int _8598 = NOVALUE;
    int _8597 = NOVALUE;
    int _8596 = NOVALUE;
    int _8595 = NOVALUE;
    int _8594 = NOVALUE;
    int _8593 = NOVALUE;
    int _8592 = NOVALUE;
    int _8591 = NOVALUE;
    int _8590 = NOVALUE;
    int _8589 = NOVALUE;
    int _8588 = NOVALUE;
    int _8587 = NOVALUE;
    int _8586 = NOVALUE;
    int _8585 = NOVALUE;
    int _8583 = NOVALUE;
    int _8582 = NOVALUE;
    int _8581 = NOVALUE;
    int _8579 = NOVALUE;
    int _8577 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_15241 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15239)){
            _8577 = SEQ_PTR(_opts_15239)->length;
    }
    else {
        _8577 = 1;
    }
    {
        int _i_15243;
        _i_15243 = 1;
L1: 
        if (_i_15243 > _8577){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_15245);
        _2 = (int)SEQ_PTR(_opts_15239);
        _opt_15245 = (int)*(((s1_ptr)_2)->base + _i_15243);
        Ref(_opt_15245);

        /** 		integer updated = 0*/
        _updated_15247 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_15245)){
                _8579 = SEQ_PTR(_opt_15245)->length;
        }
        else {
            _8579 = 1;
        }
        if (_8579 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_15245)){
                _8581 = SEQ_PTR(_opt_15245)->length;
        }
        else {
            _8581 = 1;
        }
        _8582 = 6 - _8581;
        _8581 = NOVALUE;
        _8583 = Repeat(-1, _8582);
        _8582 = NOVALUE;
        Concat((object_ptr)&_opt_15245, _opt_15245, _8583);
        DeRefDS(_8583);
        _8583 = NOVALUE;

        /** 			updated = 1*/
        _updated_15247 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8585 = (int)*(((s1_ptr)_2)->base + 1);
        _8586 = IS_SEQUENCE(_8585);
        _8585 = NOVALUE;
        if (_8586 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_15245);
        _8588 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_8588)){
                _8589 = SEQ_PTR(_8588)->length;
        }
        else {
            _8589 = 1;
        }
        _8588 = NOVALUE;
        _8590 = (_8589 == 0);
        _8589 = NOVALUE;
        if (_8590 == 0)
        {
            DeRef(_8590);
            _8590 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_8590);
            _8590 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8591 = (int)*(((s1_ptr)_2)->base + 2);
        _8592 = IS_SEQUENCE(_8591);
        _8591 = NOVALUE;
        if (_8592 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_15245);
        _8594 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_8594)){
                _8595 = SEQ_PTR(_8594)->length;
        }
        else {
            _8595 = 1;
        }
        _8594 = NOVALUE;
        _8596 = (_8595 == 0);
        _8595 = NOVALUE;
        if (_8596 == 0)
        {
            DeRef(_8596);
            _8596 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_8596);
            _8596 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8597 = (int)*(((s1_ptr)_2)->base + 2);
        _8598 = IS_ATOM(_8597);
        _8597 = NOVALUE;
        if (_8598 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_15245);
        _8600 = (int)*(((s1_ptr)_2)->base + 1);
        _8601 = IS_ATOM(_8600);
        _8600 = NOVALUE;
        if (_8601 == 0)
        {
            _8601 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _8601 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_15241 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_15279);
        _msg_inlined_crash_at_178_15279 = EPrintf(-9999999, _8603, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_15279);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_15279);
        _msg_inlined_crash_at_178_15279 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_15241 = _i_15243;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8604 = (int)*(((s1_ptr)_2)->base + 6);
        _8605 = IS_ATOM(_8604);
        _8604 = NOVALUE;
        if (_8605 == 0)
        {
            _8605 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _8605 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_31EXTRAS_15217);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _31EXTRAS_15217;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_15247 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8606 = (int)*(((s1_ptr)_2)->base + 3);
        _8607 = IS_ATOM(_8606);
        _8606 = NOVALUE;
        if (_8607 == 0)
        {
            _8607 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _8607 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8608 = (int)*(((s1_ptr)_2)->base + 4);
        _8609 = IS_ATOM(_8608);
        _8608 = NOVALUE;
        if (_8609 == 0)
        {
            _8609 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _8609 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8610 = (int)*(((s1_ptr)_2)->base + 4);
        if (_8610 == 112)
        _8611 = 1;
        else if (IS_ATOM_INT(_8610) && IS_ATOM_INT(112))
        _8611 = 0;
        else
        _8611 = (compare(_8610, 112) == 0);
        _8610 = NOVALUE;
        if (_8611 == 0)
        {
            _8611 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _8611 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_8612);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _8612;
        _8613 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8613;
        if( _1 != _8613 ){
            DeRef(_1);
        }
        _8613 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_15247 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8614 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_8614)){
                _8615 = SEQ_PTR(_8614)->length;
        }
        else {
            _8615 = 1;
        }
        _8614 = NOVALUE;
        {
            int _j_15298;
            _j_15298 = 1;
L10: 
            if (_j_15298 > _8615){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_15245);
            _8616 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_8616);
            _8617 = (int)*(((s1_ptr)_2)->base + _j_15298);
            _8616 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_15245);
            _8618 = (int)*(((s1_ptr)_2)->base + 4);
            _8619 = _j_15298 + 1;
            _8620 = find_from(_8617, _8618, _8619);
            _8617 = NOVALUE;
            _8618 = NOVALUE;
            _8619 = NOVALUE;
            if (_8620 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_15310);
            _msg_inlined_crash_at_354_15310 = EPrintf(-9999999, _8622, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_15310);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_15310);
            _msg_inlined_crash_at_354_15310 = NOVALUE;
L12: 

            /** 			end for*/
            _j_15298 = _j_15298 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8623 = (int)*(((s1_ptr)_2)->base + 4);
        _8624 = find_from(112, _8623, 1);
        _8623 = NOVALUE;
        if (_8624 == 0)
        {
            _8624 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _8624 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8625 = (int)*(((s1_ptr)_2)->base + 4);
        _8626 = find_from(110, _8625, 1);
        _8625 = NOVALUE;
        if (_8626 == 0)
        {
            _8626 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _8626 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_15319);
        _msg_inlined_crash_at_410_15319 = EPrintf(-9999999, _8627, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_15319);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_15319);
        _msg_inlined_crash_at_410_15319 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8628 = (int)*(((s1_ptr)_2)->base + 4);
        _8629 = find_from(99, _8628, 1);
        _8628 = NOVALUE;
        if (_8629 == 0)
        {
            _8629 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _8629 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8630 = (int)*(((s1_ptr)_2)->base + 4);
        _8631 = find_from(105, _8630, 1);
        _8630 = NOVALUE;
        if (_8631 == 0)
        {
            _8631 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _8631 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_15328);
        _msg_inlined_crash_at_460_15328 = EPrintf(-9999999, _8632, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_15328);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_15328);
        _msg_inlined_crash_at_460_15328 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8633 = (int)*(((s1_ptr)_2)->base + 4);
        _8634 = find_from(109, _8633, 1);
        _8633 = NOVALUE;
        if (_8634 == 0)
        {
            _8634 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _8634 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8635 = (int)*(((s1_ptr)_2)->base + 4);
        _8636 = find_from(111, _8635, 1);
        _8635 = NOVALUE;
        if (_8636 == 0)
        {
            _8636 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _8636 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_15337);
        _msg_inlined_crash_at_510_15337 = EPrintf(-9999999, _8637, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_15337);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_15337);
        _msg_inlined_crash_at_510_15337 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8638 = (int)*(((s1_ptr)_2)->base + 4);
        _8639 = find_from(49, _8638, 1);
        _8638 = NOVALUE;
        if (_8639 == 0)
        {
            _8639 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _8639 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8640 = (int)*(((s1_ptr)_2)->base + 4);
        _8641 = find_from(42, _8640, 1);
        _8640 = NOVALUE;
        if (_8641 == 0)
        {
            _8641 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _8641 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_15346);
        _msg_inlined_crash_at_560_15346 = EPrintf(-9999999, _8642, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_15346);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_15346);
        _msg_inlined_crash_at_560_15346 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8643 = (int)*(((s1_ptr)_2)->base + 5);
        _8644 = IS_SEQUENCE(_8643);
        _8643 = NOVALUE;
        if (_8644 == 0)
        {
            _8644 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _8644 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8645 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_8645))
        _8646 = 1;
        else if (IS_ATOM_DBL(_8645))
        _8646 = IS_ATOM_INT(DoubleToInt(_8645));
        else
        _8646 = 0;
        _8645 = NOVALUE;
        if (_8646 != 0)
        goto L22; // [617] 634
        _8646 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8648 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _8648, 0)){
            _8648 = NOVALUE;
            goto L23; // [640] 656
        }
        _8648 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8650 = (int)*(((s1_ptr)_2)->base + 6);
        _8651 = IS_SEQUENCE(_8650);
        _8650 = NOVALUE;
        if (_8651 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_15245);
        _8653 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_8653)){
                _8654 = SEQ_PTR(_8653)->length;
        }
        else {
            _8654 = 1;
        }
        _8653 = NOVALUE;
        _8655 = (_8654 == 0);
        _8654 = NOVALUE;
        if (_8655 == 0)
        {
            DeRef(_8655);
            _8655 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_8655);
            _8655 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_15247 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8656 = (int)*(((s1_ptr)_2)->base + 6);
        _8657 = IS_ATOM(_8656);
        _8656 = NOVALUE;
        if (_8657 == 0)
        {
            _8657 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _8657 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8658 = (int)*(((s1_ptr)_2)->base + 2);
        _8659 = IS_SEQUENCE(_8658);
        _8658 = NOVALUE;
        if (_8659 == 0)
        {
            _8659 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _8659 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8660 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_8660);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8660;
        if( _1 != _8660 ){
            DeRef(_1);
        }
        _8660 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8661 = (int)*(((s1_ptr)_2)->base + 1);
        _8662 = IS_SEQUENCE(_8661);
        _8661 = NOVALUE;
        if (_8662 == 0)
        {
            _8662 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _8662 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_15245);
        _8663 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_8663);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _8663;
        if( _1 != _8663 ){
            DeRef(_1);
        }
        _8663 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_31EXTRAS_15217);
        _2 = (int)SEQ_PTR(_opt_15245);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_15245 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _31EXTRAS_15217;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_15247 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_15247 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_15245);
        _2 = (int)SEQ_PTR(_opts_15239);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15239 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15243);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_15245;
        DeRef(_1);
L29: 
        DeRef(_opt_15245);
        _opt_15245 = NOVALUE;

        /** 	end for*/
        _i_15243 = _i_15243 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15239)){
            _8664 = SEQ_PTR(_opts_15239)->length;
    }
    else {
        _8664 = 1;
    }
    {
        int _i_15378;
        _i_15378 = 1;
L2A: 
        if (_i_15378 > _8664){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_15380);
        _2 = (int)SEQ_PTR(_opts_15239);
        _opt_15380 = (int)*(((s1_ptr)_2)->base + _i_15378);
        Ref(_opt_15380);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15380);
        _8666 = (int)*(((s1_ptr)_2)->base + 1);
        _8667 = IS_SEQUENCE(_8666);
        _8666 = NOVALUE;
        if (_8667 == 0)
        {
            _8667 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _8667 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8668 = _i_15378 + 1;
        if (IS_SEQUENCE(_opts_15239)){
                _8669 = SEQ_PTR(_opts_15239)->length;
        }
        else {
            _8669 = 1;
        }
        {
            int _j_15386;
            _j_15386 = _8668;
L2D: 
            if (_j_15386 > _8669){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15380);
            _8670 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_15239);
            _8671 = (int)*(((s1_ptr)_2)->base + _j_15386);
            _2 = (int)SEQ_PTR(_8671);
            _8672 = (int)*(((s1_ptr)_2)->base + 1);
            _8671 = NOVALUE;
            if (_8670 == _8672)
            _8673 = 1;
            else if (IS_ATOM_INT(_8670) && IS_ATOM_INT(_8672))
            _8673 = 0;
            else
            _8673 = (compare(_8670, _8672) == 0);
            _8670 = NOVALUE;
            _8672 = NOVALUE;
            if (_8673 == 0)
            {
                _8673 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _8673 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15380);
            _8675 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8675);
            *((int *)(_2+4)) = _8675;
            _8676 = MAKE_SEQ(_1);
            _8675 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_15398);
            _data_inlined_crash_at_875_15398 = _8676;
            _8676 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_15399);
            _msg_inlined_crash_at_878_15399 = EPrintf(-9999999, _8674, _data_inlined_crash_at_875_15398);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_15399);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_15398);
            _data_inlined_crash_at_875_15398 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_15399);
            _msg_inlined_crash_at_878_15399 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_15386 = _j_15386 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_15380);
        _8677 = (int)*(((s1_ptr)_2)->base + 2);
        _8678 = IS_SEQUENCE(_8677);
        _8677 = NOVALUE;
        if (_8678 == 0)
        {
            _8678 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _8678 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _8679 = _i_15378 + 1;
        if (IS_SEQUENCE(_opts_15239)){
                _8680 = SEQ_PTR(_opts_15239)->length;
        }
        else {
            _8680 = 1;
        }
        {
            int _j_15404;
            _j_15404 = _8679;
L32: 
            if (_j_15404 > _8680){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_15380);
            _8681 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_15239);
            _8682 = (int)*(((s1_ptr)_2)->base + _j_15404);
            _2 = (int)SEQ_PTR(_8682);
            _8683 = (int)*(((s1_ptr)_2)->base + 2);
            _8682 = NOVALUE;
            if (_8681 == _8683)
            _8684 = 1;
            else if (IS_ATOM_INT(_8681) && IS_ATOM_INT(_8683))
            _8684 = 0;
            else
            _8684 = (compare(_8681, _8683) == 0);
            _8681 = NOVALUE;
            _8683 = NOVALUE;
            if (_8684 == 0)
            {
                _8684 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _8684 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_15380);
            _8686 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_8686);
            *((int *)(_2+4)) = _8686;
            _8687 = MAKE_SEQ(_1);
            _8686 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_15416);
            _data_inlined_crash_at_964_15416 = _8687;
            _8687 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_15417);
            _msg_inlined_crash_at_967_15417 = EPrintf(-9999999, _8685, _data_inlined_crash_at_964_15416);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_15417);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_15416);
            _data_inlined_crash_at_964_15416 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_15417);
            _msg_inlined_crash_at_967_15417 = NOVALUE;
L34: 

            /** 			end for*/
            _j_15404 = _j_15404 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_15380);
        _opt_15380 = NOVALUE;

        /** 	end for*/
        _i_15378 = _i_15378 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_15418 = 0;
    _has_help_15419 = 0;
    _has_question_15420 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15239)){
            _8688 = SEQ_PTR(_opts_15239)->length;
    }
    else {
        _8688 = 1;
    }
    {
        int _i_15422;
        _i_15422 = 1;
L36: 
        if (_i_15422 > _8688){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8689 = (int)*(((s1_ptr)_2)->base + _i_15422);
        _2 = (int)SEQ_PTR(_8689);
        _8690 = (int)*(((s1_ptr)_2)->base + 1);
        _8689 = NOVALUE;
        if (_8690 == _8691)
        _8692 = 1;
        else if (IS_ATOM_INT(_8690) && IS_ATOM_INT(_8691))
        _8692 = 0;
        else
        _8692 = (compare(_8690, _8691) == 0);
        _8690 = NOVALUE;
        if (_8692 == 0)
        {
            _8692 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _8692 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_15418 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8693 = (int)*(((s1_ptr)_2)->base + _i_15422);
        _2 = (int)SEQ_PTR(_8693);
        _8694 = (int)*(((s1_ptr)_2)->base + 1);
        _8693 = NOVALUE;
        if (_8694 == _8695)
        _8696 = 1;
        else if (IS_ATOM_INT(_8694) && IS_ATOM_INT(_8695))
        _8696 = 0;
        else
        _8696 = (compare(_8694, _8695) == 0);
        _8694 = NOVALUE;
        if (_8696 == 0)
        {
            _8696 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _8696 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_15420 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8697 = (int)*(((s1_ptr)_2)->base + _i_15422);
        _2 = (int)SEQ_PTR(_8697);
        _8698 = (int)*(((s1_ptr)_2)->base + 2);
        _8697 = NOVALUE;
        if (_8698 == _8699)
        _8700 = 1;
        else if (IS_ATOM_INT(_8698) && IS_ATOM_INT(_8699))
        _8700 = 0;
        else
        _8700 = (compare(_8698, _8699) == 0);
        _8698 = NOVALUE;
        if (_8700 == 0)
        {
            _8700 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _8700 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_15419 = 1;
L3B: 

        /** 	end for*/
        _i_15422 = _i_15422 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_15240 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_15440 = 0;

    /** 		if not has_h and not has_help then*/
    _8701 = (_has_h_15418 == 0);
    if (_8701 == 0) {
        goto L3D; // [1121] 1154
    }
    _8703 = (_has_help_15419 == 0);
    if (_8703 == 0)
    {
        DeRef(_8703);
        _8703 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_8703);
        _8703 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8691);
    *((int *)(_2+4)) = _8691;
    RefDS(_8699);
    *((int *)(_2+8)) = _8699;
    RefDS(_8704);
    *((int *)(_2+12)) = _8704;
    RefDS(_8691);
    *((int *)(_2+16)) = _8691;
    *((int *)(_2+20)) = -1;
    _8705 = MAKE_SEQ(_1);
    RefDS(_8705);
    Append(&_opts_15239, _opts_15239, _8705);
    DeRefDS(_8705);
    _8705 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15440 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_15418 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8691);
    *((int *)(_2+4)) = _8691;
    *((int *)(_2+8)) = 0;
    RefDS(_8704);
    *((int *)(_2+12)) = _8704;
    RefDS(_8691);
    *((int *)(_2+16)) = _8691;
    *((int *)(_2+20)) = -1;
    _8708 = MAKE_SEQ(_1);
    RefDS(_8708);
    Append(&_opts_15239, _opts_15239, _8708);
    DeRefDS(_8708);
    _8708 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15440 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_15419 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_8699);
    *((int *)(_2+8)) = _8699;
    RefDS(_8704);
    *((int *)(_2+12)) = _8704;
    RefDS(_8691);
    *((int *)(_2+16)) = _8691;
    *((int *)(_2+20)) = -1;
    _8711 = MAKE_SEQ(_1);
    RefDS(_8711);
    Append(&_opts_15239, _opts_15239, _8711);
    DeRefDS(_8711);
    _8711 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15440 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_15420 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8695);
    *((int *)(_2+4)) = _8695;
    *((int *)(_2+8)) = 0;
    RefDS(_8704);
    *((int *)(_2+12)) = _8704;
    RefDS(_8691);
    *((int *)(_2+16)) = _8691;
    *((int *)(_2+20)) = -1;
    _8714 = MAKE_SEQ(_1);
    RefDS(_8714);
    Append(&_opts_15239, _opts_15239, _8714);
    DeRefDS(_8714);
    _8714 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_15440 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_15440 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_15239);
    DeRef(_8716);
    _8716 = _opts_15239;
    _0 = _opts_15239;
    _opts_15239 = _31standardize_opts(_8716, 0);
    DeRefDS(_0);
    _8716 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15239)){
            _8718 = SEQ_PTR(_opts_15239)->length;
    }
    else {
        _8718 = 1;
    }
    {
        int _i_15464;
        _i_15464 = 1;
L43: 
        if (_i_15464 > _8718){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8719 = (int)*(((s1_ptr)_2)->base + _i_15464);
        _2 = (int)SEQ_PTR(_8719);
        _8720 = (int)*(((s1_ptr)_2)->base + 4);
        _8719 = NOVALUE;
        _8721 = find_from(112, _8720, 1);
        _8720 = NOVALUE;
        if (_8721 != 0)
        goto L45; // [1280] 1303
        _8721 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_15239);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15239 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15464 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8725 = (int)*(((s1_ptr)_2)->base + 4);
        _8723 = NOVALUE;
        if (IS_SEQUENCE(_8725) && IS_ATOM(110)) {
            Append(&_8726, _8725, 110);
        }
        else if (IS_ATOM(_8725) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_8726, _8725, 110);
            _8725 = NOVALUE;
        }
        _8725 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8726;
        if( _1 != _8726 ){
            DeRef(_1);
        }
        _8726 = NOVALUE;
        _8723 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8727 = (int)*(((s1_ptr)_2)->base + _i_15464);
        _2 = (int)SEQ_PTR(_8727);
        _8728 = (int)*(((s1_ptr)_2)->base + 4);
        _8727 = NOVALUE;
        _8729 = find_from(42, _8728, 1);
        _8728 = NOVALUE;
        _8730 = (_8729 == 0);
        _8729 = NOVALUE;
        if (_8730 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_15239);
        _8732 = (int)*(((s1_ptr)_2)->base + _i_15464);
        _2 = (int)SEQ_PTR(_8732);
        _8733 = (int)*(((s1_ptr)_2)->base + 4);
        _8732 = NOVALUE;
        _8734 = find_from(49, _8733, 1);
        _8733 = NOVALUE;
        _8735 = (_8734 == 0);
        _8734 = NOVALUE;
        if (_8735 == 0)
        {
            DeRef(_8735);
            _8735 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_8735);
            _8735 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_15239);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15239 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15464 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8738 = (int)*(((s1_ptr)_2)->base + 4);
        _8736 = NOVALUE;
        if (IS_SEQUENCE(_8738) && IS_ATOM(49)) {
            Append(&_8739, _8738, 49);
        }
        else if (IS_ATOM(_8738) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_8739, _8738, 49);
            _8738 = NOVALUE;
        }
        _8738 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8739;
        if( _1 != _8739 ){
            DeRef(_1);
        }
        _8739 = NOVALUE;
        _8736 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15239);
        _8740 = (int)*(((s1_ptr)_2)->base + _i_15464);
        _2 = (int)SEQ_PTR(_8740);
        _8741 = (int)*(((s1_ptr)_2)->base + 4);
        _8740 = NOVALUE;
        _8742 = find_from(99, _8741, 1);
        _8741 = NOVALUE;
        _8743 = (_8742 == 0);
        _8742 = NOVALUE;
        if (_8743 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_15239);
        _8745 = (int)*(((s1_ptr)_2)->base + _i_15464);
        _2 = (int)SEQ_PTR(_8745);
        _8746 = (int)*(((s1_ptr)_2)->base + 4);
        _8745 = NOVALUE;
        _8747 = find_from(105, _8746, 1);
        _8746 = NOVALUE;
        _8748 = (_8747 == 0);
        _8747 = NOVALUE;
        if (_8748 == 0)
        {
            DeRef(_8748);
            _8748 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_8748);
            _8748 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_15239);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_15239 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_15464 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _8751 = (int)*(((s1_ptr)_2)->base + 4);
        _8749 = NOVALUE;
        if (IS_SEQUENCE(_8751) && IS_ATOM(105)) {
            Append(&_8752, _8751, 105);
        }
        else if (IS_ATOM(_8751) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_8752, _8751, 105);
            _8751 = NOVALUE;
        }
        _8751 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _8752;
        if( _1 != _8752 ){
            DeRef(_1);
        }
        _8752 = NOVALUE;
        _8749 = NOVALUE;
L47: 

        /** 	end for*/
        _i_15464 = _i_15464 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _8588 = NOVALUE;
    _8594 = NOVALUE;
    _8614 = NOVALUE;
    _8653 = NOVALUE;
    DeRef(_8668);
    _8668 = NOVALUE;
    DeRef(_8679);
    _8679 = NOVALUE;
    DeRef(_8701);
    _8701 = NOVALUE;
    DeRef(_8730);
    _8730 = NOVALUE;
    DeRef(_8743);
    _8743 = NOVALUE;
    return _opts_15239;
    ;
}


void _31local_help(int _opts_15505, int _add_help_rid_15506, int _cmds_15507, int _std_15509, int _parse_options_15510)
{
    int _pad_size_15511 = NOVALUE;
    int _this_size_15512 = NOVALUE;
    int _cmd_15513 = NOVALUE;
    int _param_name_15514 = NOVALUE;
    int _has_param_15515 = NOVALUE;
    int _is_mandatory_15516 = NOVALUE;
    int _extras_mandatory_15517 = NOVALUE;
    int _extras_opt_15518 = NOVALUE;
    int _auto_help_15519 = NOVALUE;
    int _po_15520 = NOVALUE;
    int _msg_inlined_crash_at_94_15539 = NOVALUE;
    int _8942 = NOVALUE;
    int _8941 = NOVALUE;
    int _8940 = NOVALUE;
    int _8939 = NOVALUE;
    int _8937 = NOVALUE;
    int _8936 = NOVALUE;
    int _8935 = NOVALUE;
    int _8934 = NOVALUE;
    int _8933 = NOVALUE;
    int _8931 = NOVALUE;
    int _8929 = NOVALUE;
    int _8927 = NOVALUE;
    int _8925 = NOVALUE;
    int _8924 = NOVALUE;
    int _8923 = NOVALUE;
    int _8921 = NOVALUE;
    int _8920 = NOVALUE;
    int _8919 = NOVALUE;
    int _8916 = NOVALUE;
    int _8915 = NOVALUE;
    int _8914 = NOVALUE;
    int _8912 = NOVALUE;
    int _8911 = NOVALUE;
    int _8910 = NOVALUE;
    int _8908 = NOVALUE;
    int _8907 = NOVALUE;
    int _8906 = NOVALUE;
    int _8905 = NOVALUE;
    int _8904 = NOVALUE;
    int _8903 = NOVALUE;
    int _8902 = NOVALUE;
    int _8901 = NOVALUE;
    int _8898 = NOVALUE;
    int _8894 = NOVALUE;
    int _8891 = NOVALUE;
    int _8890 = NOVALUE;
    int _8889 = NOVALUE;
    int _8883 = NOVALUE;
    int _8882 = NOVALUE;
    int _8881 = NOVALUE;
    int _8880 = NOVALUE;
    int _8876 = NOVALUE;
    int _8873 = NOVALUE;
    int _8872 = NOVALUE;
    int _8871 = NOVALUE;
    int _8868 = NOVALUE;
    int _8867 = NOVALUE;
    int _8866 = NOVALUE;
    int _8864 = NOVALUE;
    int _8863 = NOVALUE;
    int _8862 = NOVALUE;
    int _8860 = NOVALUE;
    int _8859 = NOVALUE;
    int _8858 = NOVALUE;
    int _8857 = NOVALUE;
    int _8856 = NOVALUE;
    int _8855 = NOVALUE;
    int _8852 = NOVALUE;
    int _8851 = NOVALUE;
    int _8850 = NOVALUE;
    int _8847 = NOVALUE;
    int _8846 = NOVALUE;
    int _8845 = NOVALUE;
    int _8844 = NOVALUE;
    int _8843 = NOVALUE;
    int _8842 = NOVALUE;
    int _8841 = NOVALUE;
    int _8840 = NOVALUE;
    int _8839 = NOVALUE;
    int _8838 = NOVALUE;
    int _8837 = NOVALUE;
    int _8836 = NOVALUE;
    int _8831 = NOVALUE;
    int _8830 = NOVALUE;
    int _8828 = NOVALUE;
    int _8827 = NOVALUE;
    int _8826 = NOVALUE;
    int _8825 = NOVALUE;
    int _8824 = NOVALUE;
    int _8823 = NOVALUE;
    int _8821 = NOVALUE;
    int _8820 = NOVALUE;
    int _8819 = NOVALUE;
    int _8815 = NOVALUE;
    int _8814 = NOVALUE;
    int _8812 = NOVALUE;
    int _8811 = NOVALUE;
    int _8810 = NOVALUE;
    int _8809 = NOVALUE;
    int _8808 = NOVALUE;
    int _8807 = NOVALUE;
    int _8806 = NOVALUE;
    int _8803 = NOVALUE;
    int _8802 = NOVALUE;
    int _8801 = NOVALUE;
    int _8799 = NOVALUE;
    int _8798 = NOVALUE;
    int _8797 = NOVALUE;
    int _8796 = NOVALUE;
    int _8795 = NOVALUE;
    int _8794 = NOVALUE;
    int _8793 = NOVALUE;
    int _8790 = NOVALUE;
    int _8789 = NOVALUE;
    int _8788 = NOVALUE;
    int _8786 = NOVALUE;
    int _8785 = NOVALUE;
    int _8784 = NOVALUE;
    int _8783 = NOVALUE;
    int _8782 = NOVALUE;
    int _8781 = NOVALUE;
    int _8780 = NOVALUE;
    int _8779 = NOVALUE;
    int _8778 = NOVALUE;
    int _8777 = NOVALUE;
    int _8776 = NOVALUE;
    int _8775 = NOVALUE;
    int _8774 = NOVALUE;
    int _8773 = NOVALUE;
    int _8772 = NOVALUE;
    int _8771 = NOVALUE;
    int _8770 = NOVALUE;
    int _8769 = NOVALUE;
    int _8761 = NOVALUE;
    int _8758 = NOVALUE;
    int _8756 = NOVALUE;
    int _8754 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_15517 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_15518 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_15519 = 1;

    /** 	integer po = 1*/
    _po_15520 = 1;

    /** 	if atom(parse_options) then*/
    _8754 = IS_ATOM(_parse_options_15510);
    if (_8754 == 0)
    {
        _8754 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _8754 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15510;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_15510);
    *((int *)(_2+4)) = _parse_options_15510;
    _parse_options_15510 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15510)){
            _8756 = SEQ_PTR(_parse_options_15510)->length;
    }
    else {
        _8756 = 1;
    }
    if (_po_15520 > _8756)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15510);
    _8758 = (int)*(((s1_ptr)_2)->base + _po_15520);
    if (IS_SEQUENCE(_8758) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_8758)){
        if( (DBL_PTR(_8758)->dbl != (double) ((int) DBL_PTR(_8758)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_8758)->dbl;
    }
    else {
        _0 = _8758;
    };
    _8758 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15510)){
                _8761 = SEQ_PTR(_parse_options_15510)->length;
        }
        else {
            _8761 = 1;
        }
        if (_po_15520 >= _8761)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_15520 = _po_15520 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15506);
        _2 = (int)SEQ_PTR(_parse_options_15510);
        _add_help_rid_15506 = (int)*(((s1_ptr)_2)->base + _po_15520);
        Ref(_add_help_rid_15506);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_15539);
        _msg_inlined_crash_at_94_15539 = EPrintf(-9999999, _8765, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_15539);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_15539);
        _msg_inlined_crash_at_94_15539 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15519 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_15520 = _po_15520 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_15509 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15505);
    _0 = _opts_15505;
    _opts_15505 = _31standardize_opts(_opts_15505, _auto_help_15519);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_15511 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15505)){
            _8769 = SEQ_PTR(_opts_15505)->length;
    }
    else {
        _8769 = 1;
    }
    {
        int _i_15547;
        _i_15547 = 1;
L9: 
        if (_i_15547 > _8769){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_15512 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_15514);
        _param_name_15514 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8770 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8770);
        _8771 = (int)*(((s1_ptr)_2)->base + 1);
        _8770 = NOVALUE;
        _8772 = IS_ATOM(_8771);
        _8771 = NOVALUE;
        if (_8772 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_15505);
        _8774 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8774);
        _8775 = (int)*(((s1_ptr)_2)->base + 2);
        _8774 = NOVALUE;
        _8776 = IS_ATOM(_8775);
        _8775 = NOVALUE;
        if (_8776 == 0)
        {
            _8776 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _8776 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_15518 = _i_15547;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8777 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8777);
        _8778 = (int)*(((s1_ptr)_2)->base + 4);
        _8777 = NOVALUE;
        _8779 = find_from(109, _8778, 1);
        _8778 = NOVALUE;
        if (_8779 == 0)
        {
            _8779 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _8779 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_15517 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8780 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8780);
        _8781 = (int)*(((s1_ptr)_2)->base + 1);
        _8780 = NOVALUE;
        _8782 = IS_SEQUENCE(_8781);
        _8781 = NOVALUE;
        if (_8782 == 0)
        {
            _8782 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _8782 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8783 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8783);
        _8784 = (int)*(((s1_ptr)_2)->base + 1);
        _8783 = NOVALUE;
        if (IS_SEQUENCE(_8784)){
                _8785 = SEQ_PTR(_8784)->length;
        }
        else {
            _8785 = 1;
        }
        _8784 = NOVALUE;
        _8786 = _8785 + 1;
        _8785 = NOVALUE;
        _this_size_15512 = _this_size_15512 + _8786;
        _8786 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8788 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8788);
        _8789 = (int)*(((s1_ptr)_2)->base + 4);
        _8788 = NOVALUE;
        _8790 = find_from(109, _8789, 1);
        _8789 = NOVALUE;
        if (_8790 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15512 = _this_size_15512 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8793 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8793);
        _8794 = (int)*(((s1_ptr)_2)->base + 2);
        _8793 = NOVALUE;
        _8795 = IS_SEQUENCE(_8794);
        _8794 = NOVALUE;
        if (_8795 == 0)
        {
            _8795 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _8795 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8796 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8796);
        _8797 = (int)*(((s1_ptr)_2)->base + 2);
        _8796 = NOVALUE;
        if (IS_SEQUENCE(_8797)){
                _8798 = SEQ_PTR(_8797)->length;
        }
        else {
            _8798 = 1;
        }
        _8797 = NOVALUE;
        _8799 = _8798 + 2;
        _8798 = NOVALUE;
        _this_size_15512 = _this_size_15512 + _8799;
        _8799 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8801 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8801);
        _8802 = (int)*(((s1_ptr)_2)->base + 4);
        _8801 = NOVALUE;
        _8803 = find_from(109, _8802, 1);
        _8802 = NOVALUE;
        if (_8803 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_15512 = _this_size_15512 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8806 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8806);
        _8807 = (int)*(((s1_ptr)_2)->base + 1);
        _8806 = NOVALUE;
        _8808 = IS_SEQUENCE(_8807);
        _8807 = NOVALUE;
        if (_8808 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_15505);
        _8810 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8810);
        _8811 = (int)*(((s1_ptr)_2)->base + 2);
        _8810 = NOVALUE;
        _8812 = IS_SEQUENCE(_8811);
        _8811 = NOVALUE;
        if (_8812 == 0)
        {
            _8812 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _8812 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_15512 = _this_size_15512 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8814 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8814);
        _8815 = (int)*(((s1_ptr)_2)->base + 4);
        _8814 = NOVALUE;
        _has_param_15515 = find_from(112, _8815, 1);
        _8815 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15515 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_15512 = _this_size_15512 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8819 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8819);
        _8820 = (int)*(((s1_ptr)_2)->base + 4);
        _8819 = NOVALUE;
        if (IS_SEQUENCE(_8820)){
                _8821 = SEQ_PTR(_8820)->length;
        }
        else {
            _8821 = 1;
        }
        _8820 = NOVALUE;
        if (_has_param_15515 >= _8821)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8823 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8823);
        _8824 = (int)*(((s1_ptr)_2)->base + 4);
        _8823 = NOVALUE;
        _2 = (int)SEQ_PTR(_8824);
        _8825 = (int)*(((s1_ptr)_2)->base + _has_param_15515);
        _8824 = NOVALUE;
        _8826 = IS_SEQUENCE(_8825);
        _8825 = NOVALUE;
        if (_8826 == 0)
        {
            _8826 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _8826 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8827 = (int)*(((s1_ptr)_2)->base + _i_15547);
        _2 = (int)SEQ_PTR(_8827);
        _8828 = (int)*(((s1_ptr)_2)->base + 4);
        _8827 = NOVALUE;
        DeRef(_param_name_15514);
        _2 = (int)SEQ_PTR(_8828);
        _param_name_15514 = (int)*(((s1_ptr)_2)->base + _has_param_15515);
        Ref(_param_name_15514);
        _8828 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_8612);
        DeRef(_param_name_15514);
        _param_name_15514 = _8612;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_8612);
        DeRef(_param_name_15514);
        _param_name_15514 = _8612;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_15514)){
                _8830 = SEQ_PTR(_param_name_15514)->length;
        }
        else {
            _8830 = 1;
        }
        _8831 = 2 + _8830;
        _8830 = NOVALUE;
        _this_size_15512 = _this_size_15512 + _8831;
        _8831 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_15511 >= _this_size_15512)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_15511 = _this_size_15512;
L16: 

        /** 	end for*/
LC: 
        _i_15547 = _i_15547 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_15511 = _pad_size_15511 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_15507);
    _8836 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8836);
    *((int *)(_2+4)) = _8836;
    _8837 = MAKE_SEQ(_1);
    _8836 = NOVALUE;
    EPrintf(1, _8835, _8837);
    DeRefDS(_8837);
    _8837 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15505)){
            _8838 = SEQ_PTR(_opts_15505)->length;
    }
    else {
        _8838 = 1;
    }
    {
        int _i_15631;
        _i_15631 = 1;
L17: 
        if (_i_15631 > _8838){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8839 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8839);
        _8840 = (int)*(((s1_ptr)_2)->base + 1);
        _8839 = NOVALUE;
        _8841 = IS_ATOM(_8840);
        _8840 = NOVALUE;
        if (_8841 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_15505);
        _8843 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8843);
        _8844 = (int)*(((s1_ptr)_2)->base + 2);
        _8843 = NOVALUE;
        _8845 = IS_ATOM(_8844);
        _8844 = NOVALUE;
        if (_8845 == 0)
        {
            _8845 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _8845 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8846 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8846);
        _8847 = (int)*(((s1_ptr)_2)->base + 4);
        _8846 = NOVALUE;
        _has_param_15515 = find_from(112, _8847, 1);
        _8847 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_15515 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8850 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8850);
        _8851 = (int)*(((s1_ptr)_2)->base + 4);
        _8850 = NOVALUE;
        if (IS_SEQUENCE(_8851)){
                _8852 = SEQ_PTR(_8851)->length;
        }
        else {
            _8852 = 1;
        }
        _8851 = NOVALUE;
        if (_has_param_15515 >= _8852)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_15515 = _has_param_15515 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8855 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8855);
        _8856 = (int)*(((s1_ptr)_2)->base + 4);
        _8855 = NOVALUE;
        _2 = (int)SEQ_PTR(_8856);
        _8857 = (int)*(((s1_ptr)_2)->base + _has_param_15515);
        _8856 = NOVALUE;
        _8858 = IS_SEQUENCE(_8857);
        _8857 = NOVALUE;
        if (_8858 == 0)
        {
            _8858 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _8858 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8859 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8859);
        _8860 = (int)*(((s1_ptr)_2)->base + 4);
        _8859 = NOVALUE;
        DeRef(_param_name_15514);
        _2 = (int)SEQ_PTR(_8860);
        _param_name_15514 = (int)*(((s1_ptr)_2)->base + _has_param_15515);
        Ref(_param_name_15514);
        _8860 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_8612);
        DeRef(_param_name_15514);
        _param_name_15514 = _8612;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_8612);
        DeRef(_param_name_15514);
        _param_name_15514 = _8612;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8862 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8862);
        _8863 = (int)*(((s1_ptr)_2)->base + 4);
        _8862 = NOVALUE;
        _8864 = find_from(109, _8863, 1);
        _8863 = NOVALUE;
        _is_mandatory_15516 = (_8864 != 0);
        _8864 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_15513);
        _cmd_15513 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8866 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8866);
        _8867 = (int)*(((s1_ptr)_2)->base + 1);
        _8866 = NOVALUE;
        _8868 = IS_SEQUENCE(_8867);
        _8867 = NOVALUE;
        if (_8868 == 0)
        {
            _8868 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _8868 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15516 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_15513, _cmd_15513, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8871 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8871);
        _8872 = (int)*(((s1_ptr)_2)->base + 1);
        _8871 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_8872)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_8872)) {
            Prepend(&_8873, _8872, 45);
        }
        else {
            Concat((object_ptr)&_8873, 45, _8872);
        }
        _8872 = NOVALUE;
        Concat((object_ptr)&_cmd_15513, _cmd_15513, _8873);
        DeRefDS(_8873);
        _8873 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15515 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_8876, _param_name_15514, 32);
        Concat((object_ptr)&_cmd_15513, _cmd_15513, _8876);
        DeRefDS(_8876);
        _8876 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15516 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_15513, _cmd_15513, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8880 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8880);
        _8881 = (int)*(((s1_ptr)_2)->base + 2);
        _8880 = NOVALUE;
        _8882 = IS_SEQUENCE(_8881);
        _8881 = NOVALUE;
        if (_8882 == 0)
        {
            _8882 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _8882 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_15513)){
                _8883 = SEQ_PTR(_cmd_15513)->length;
        }
        else {
            _8883 = 1;
        }
        if (_8883 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_15513, _cmd_15513, _8885);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15516 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_15513, _cmd_15513, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8889 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8889);
        _8890 = (int)*(((s1_ptr)_2)->base + 2);
        _8889 = NOVALUE;
        if (IS_SEQUENCE(_6651) && IS_ATOM(_8890)) {
            Ref(_8890);
            Append(&_8891, _6651, _8890);
        }
        else if (IS_ATOM(_6651) && IS_SEQUENCE(_8890)) {
        }
        else {
            Concat((object_ptr)&_8891, _6651, _8890);
        }
        _8890 = NOVALUE;
        Concat((object_ptr)&_cmd_15513, _cmd_15513, _8891);
        DeRefDS(_8891);
        _8891 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_15515 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_8894, _param_name_15514, 61);
        Concat((object_ptr)&_cmd_15513, _cmd_15513, _8894);
        DeRefDS(_8894);
        _8894 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_15516 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_15513, _cmd_15513, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_15513)){
                _8898 = SEQ_PTR(_cmd_15513)->length;
        }
        else {
            _8898 = 1;
        }
        if (_8898 <= _pad_size_15511)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_15513;
            concat_list[2] = _8900;
            Concat_N((object_ptr)&_8901, concat_list, 3);
        }
        EPuts(1, _8901); // DJP 
        DeRefDS(_8901);
        _8901 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _8902 = _pad_size_15511 + 3;
        _8903 = Repeat(32, _8902);
        _8902 = NOVALUE;
        EPuts(1, _8903); // DJP 
        DeRefDS(_8903);
        _8903 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_15513);
        _8904 = _23pad_tail(_cmd_15513, _pad_size_15511, 32);
        if (IS_SEQUENCE(_8900) && IS_ATOM(_8904)) {
            Ref(_8904);
            Append(&_8905, _8900, _8904);
        }
        else if (IS_ATOM(_8900) && IS_SEQUENCE(_8904)) {
        }
        else {
            Concat((object_ptr)&_8905, _8900, _8904);
        }
        DeRef(_8904);
        _8904 = NOVALUE;
        EPuts(1, _8905); // DJP 
        DeRefDS(_8905);
        _8905 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_15505);
        _8906 = (int)*(((s1_ptr)_2)->base + _i_15631);
        _2 = (int)SEQ_PTR(_8906);
        _8907 = (int)*(((s1_ptr)_2)->base + 3);
        _8906 = NOVALUE;
        if (IS_SEQUENCE(_8907) && IS_ATOM(10)) {
            Append(&_8908, _8907, 10);
        }
        else if (IS_ATOM(_8907) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_8908, _8907, 10);
            _8907 = NOVALUE;
        }
        _8907 = NOVALUE;
        EPuts(1, _8908); // DJP 
        DeRefDS(_8908);
        _8908 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_15631 = _i_15631 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_15517 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15505);
    _8910 = (int)*(((s1_ptr)_2)->base + _extras_opt_15518);
    _2 = (int)SEQ_PTR(_8910);
    _8911 = (int)*(((s1_ptr)_2)->base + 3);
    _8910 = NOVALUE;
    if (IS_SEQUENCE(_8911)){
            _8912 = SEQ_PTR(_8911)->length;
    }
    else {
        _8912 = 1;
    }
    _8911 = NOVALUE;
    if (_8912 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15505);
    _8914 = (int)*(((s1_ptr)_2)->base + _extras_opt_15518);
    _2 = (int)SEQ_PTR(_8914);
    _8915 = (int)*(((s1_ptr)_2)->base + 3);
    _8914 = NOVALUE;
    if (IS_SEQUENCE(_1297) && IS_ATOM(_8915)) {
        Ref(_8915);
        Append(&_8916, _1297, _8915);
    }
    else if (IS_ATOM(_1297) && IS_SEQUENCE(_8915)) {
    }
    else {
        Concat((object_ptr)&_8916, _1297, _8915);
    }
    _8915 = NOVALUE;
    EPuts(1, _8916); // DJP 
    DeRefDS(_8916);
    _8916 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8917); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_15518 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_15505);
    _8919 = (int)*(((s1_ptr)_2)->base + _extras_opt_15518);
    _2 = (int)SEQ_PTR(_8919);
    _8920 = (int)*(((s1_ptr)_2)->base + 3);
    _8919 = NOVALUE;
    if (IS_SEQUENCE(_8920)){
            _8921 = SEQ_PTR(_8920)->length;
    }
    else {
        _8921 = 1;
    }
    _8920 = NOVALUE;
    if (_8921 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_15505);
    _8923 = (int)*(((s1_ptr)_2)->base + _extras_opt_15518);
    _2 = (int)SEQ_PTR(_8923);
    _8924 = (int)*(((s1_ptr)_2)->base + 3);
    _8923 = NOVALUE;
    if (IS_SEQUENCE(_1297) && IS_ATOM(_8924)) {
        Ref(_8924);
        Append(&_8925, _1297, _8924);
    }
    else if (IS_ATOM(_1297) && IS_SEQUENCE(_8924)) {
    }
    else {
        Concat((object_ptr)&_8925, _1297, _8924);
    }
    _8924 = NOVALUE;
    EPuts(1, _8925); // DJP 
    DeRefDS(_8925);
    _8925 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8926); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _8927 = IS_ATOM(_add_help_rid_15506);
    if (_8927 == 0)
    {
        _8927 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _8927 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_15506, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1297); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_15506].addr;
    (*(int (*)())_0)(
                         );

    /** 			puts(1, "\n")*/
    EPuts(1, _1297); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_15506)){
            _8929 = SEQ_PTR(_add_help_rid_15506)->length;
    }
    else {
        _8929 = 1;
    }
    if (_8929 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _1297); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_15506);
    _8931 = _7t_display(_add_help_rid_15506);
    if (_8931 == 0) {
        DeRef(_8931);
        _8931 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_8931) && DBL_PTR(_8931)->dbl == 0.0){
            DeRef(_8931);
            _8931 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_8931);
        _8931 = NOVALUE;
    }
    DeRef(_8931);
    _8931 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_15506;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_15506);
    *((int *)(_2+4)) = _add_help_rid_15506;
    _add_help_rid_15506 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_15506)){
            _8933 = SEQ_PTR(_add_help_rid_15506)->length;
    }
    else {
        _8933 = 1;
    }
    {
        int _i_15756;
        _i_15756 = 1;
L34: 
        if (_i_15756 > _8933){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_15506);
        _8934 = (int)*(((s1_ptr)_2)->base + _i_15756);
        EPuts(1, _8934); // DJP 
        _8934 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_15506);
        _8935 = (int)*(((s1_ptr)_2)->base + _i_15756);
        if (IS_SEQUENCE(_8935)){
                _8936 = SEQ_PTR(_8935)->length;
        }
        else {
            _8936 = 1;
        }
        _8935 = NOVALUE;
        _8937 = (_8936 == 0);
        _8936 = NOVALUE;
        if (_8937 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_15506);
        _8939 = (int)*(((s1_ptr)_2)->base + _i_15756);
        if (IS_SEQUENCE(_8939)){
                _8940 = SEQ_PTR(_8939)->length;
        }
        else {
            _8940 = 1;
        }
        _2 = (int)SEQ_PTR(_8939);
        _8941 = (int)*(((s1_ptr)_2)->base + _8940);
        _8939 = NOVALUE;
        if (IS_ATOM_INT(_8941)) {
            _8942 = (_8941 != 10);
        }
        else {
            _8942 = binary_op(NOTEQ, _8941, 10);
        }
        _8941 = NOVALUE;
        if (_8942 == 0) {
            DeRef(_8942);
            _8942 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_8942) && DBL_PTR(_8942)->dbl == 0.0){
                DeRef(_8942);
                _8942 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_8942);
            _8942 = NOVALUE;
        }
        DeRef(_8942);
        _8942 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_15756 = _i_15756 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _1297); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_15505);
    DeRef(_add_help_rid_15506);
    DeRefDS(_cmds_15507);
    DeRef(_parse_options_15510);
    DeRef(_cmd_15513);
    DeRef(_param_name_15514);
    _8784 = NOVALUE;
    _8797 = NOVALUE;
    _8820 = NOVALUE;
    _8851 = NOVALUE;
    _8911 = NOVALUE;
    _8920 = NOVALUE;
    _8935 = NOVALUE;
    DeRef(_8937);
    _8937 = NOVALUE;
    return;
    ;
}


void _31show_help(int _opts_15770, int _add_help_rid_15771, int _cmds_15772, int _parse_options_15774)
{
    int _0, _1, _2;
    

    /**     local_help(opts, add_help_rid, cmds, 0, parse_options)*/
    RefDS(_opts_15770);
    Ref(_add_help_rid_15771);
    RefDS(_cmds_15772);
    Ref(_parse_options_15774);
    _31local_help(_opts_15770, _add_help_rid_15771, _cmds_15772, 0, _parse_options_15774);

    /** end procedure*/
    DeRefDS(_opts_15770);
    DeRef(_add_help_rid_15771);
    DeRefDS(_cmds_15772);
    DeRef(_parse_options_15774);
    return;
    ;
}
void show_help() __attribute__ ((alias ("_31show_help")));


int _31find_opt(int _opts_15777, int _opt_style_15778, int _cmd_text_15779)
{
    int _opt_name_15780 = NOVALUE;
    int _opt_param_15781 = NOVALUE;
    int _param_found_15782 = NOVALUE;
    int _reversed_15783 = NOVALUE;
    int _9044 = NOVALUE;
    int _9042 = NOVALUE;
    int _9041 = NOVALUE;
    int _9039 = NOVALUE;
    int _9038 = NOVALUE;
    int _9037 = NOVALUE;
    int _9036 = NOVALUE;
    int _9035 = NOVALUE;
    int _9032 = NOVALUE;
    int _9031 = NOVALUE;
    int _9030 = NOVALUE;
    int _9028 = NOVALUE;
    int _9027 = NOVALUE;
    int _9026 = NOVALUE;
    int _9025 = NOVALUE;
    int _9023 = NOVALUE;
    int _9022 = NOVALUE;
    int _9021 = NOVALUE;
    int _9020 = NOVALUE;
    int _9019 = NOVALUE;
    int _9018 = NOVALUE;
    int _9017 = NOVALUE;
    int _9016 = NOVALUE;
    int _9015 = NOVALUE;
    int _9014 = NOVALUE;
    int _9013 = NOVALUE;
    int _9012 = NOVALUE;
    int _9006 = NOVALUE;
    int _9005 = NOVALUE;
    int _9004 = NOVALUE;
    int _8996 = NOVALUE;
    int _8995 = NOVALUE;
    int _8993 = NOVALUE;
    int _8991 = NOVALUE;
    int _8990 = NOVALUE;
    int _8988 = NOVALUE;
    int _8987 = NOVALUE;
    int _8986 = NOVALUE;
    int _8985 = NOVALUE;
    int _8984 = NOVALUE;
    int _8982 = NOVALUE;
    int _8981 = NOVALUE;
    int _8979 = NOVALUE;
    int _8977 = NOVALUE;
    int _8976 = NOVALUE;
    int _8974 = NOVALUE;
    int _8973 = NOVALUE;
    int _8972 = NOVALUE;
    int _8971 = NOVALUE;
    int _8969 = NOVALUE;
    int _8968 = NOVALUE;
    int _8965 = NOVALUE;
    int _8963 = NOVALUE;
    int _8962 = NOVALUE;
    int _8960 = NOVALUE;
    int _8958 = NOVALUE;
    int _8956 = NOVALUE;
    int _8955 = NOVALUE;
    int _8953 = NOVALUE;
    int _8952 = NOVALUE;
    int _8951 = NOVALUE;
    int _8950 = NOVALUE;
    int _8949 = NOVALUE;
    int _8947 = NOVALUE;
    int _8946 = NOVALUE;
    int _8944 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_15782 = 0;

    /** 	integer reversed = 0*/
    _reversed_15783 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8944 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8944 = 1;
    }
    if (_8944 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_15779);
    _8946 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8946)) {
        _8947 = (_8946 == 39);
    }
    else {
        _8947 = binary_op(EQUALS, _8946, 39);
    }
    _8946 = NOVALUE;
    if (IS_ATOM_INT(_8947)) {
        if (_8947 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8947)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_15779);
    _8949 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8949)) {
        _8950 = (_8949 == 34);
    }
    else {
        _8950 = binary_op(EQUALS, _8949, 34);
    }
    _8949 = NOVALUE;
    if (_8950 == 0) {
        DeRef(_8950);
        _8950 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8950) && DBL_PTR(_8950)->dbl == 0.0){
            DeRef(_8950);
            _8950 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8950);
        _8950 = NOVALUE;
    }
    DeRef(_8950);
    _8950 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8951 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8951 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_15779);
    _8952 = (int)*(((s1_ptr)_2)->base + _8951);
    _2 = (int)SEQ_PTR(_cmd_text_15779);
    _8953 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8952, _8953)){
        _8952 = NOVALUE;
        _8953 = NOVALUE;
        goto L4; // [64] 83
    }
    _8952 = NOVALUE;
    _8953 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8955 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8955 = 1;
    }
    _8956 = _8955 - 1;
    _8955 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_15779;
    RHS_Slice(_cmd_text_15779, 2, _8956);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8958 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8958 = 1;
    }
    if (_8958 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_15779);
    _8960 = (int)*(((s1_ptr)_2)->base + 1);
    _8962 = find_from(_8960, _8961, 1);
    _8960 = NOVALUE;
    if (_8962 == 0)
    {
        _8962 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8962 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_15783 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8963 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8963 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_15779;
    RHS_Slice(_cmd_text_15779, 2, _8963);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8965 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8965 = 1;
    }
    if (_8965 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_8967);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _8967;
    _8968 = MAKE_SEQ(_1);
    DeRefDS(_opts_15777);
    DeRefDS(_opt_style_15778);
    DeRef(_cmd_text_15779);
    DeRef(_opt_name_15780);
    DeRef(_opt_param_15781);
    DeRef(_8956);
    _8956 = NOVALUE;
    DeRef(_8947);
    _8947 = NOVALUE;
    return _8968;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8969 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8969 = 1;
    }
    DeRef(_opt_name_15780);
    _opt_name_15780 = Repeat(32, _8969);
    _8969 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_15781);
    _opt_param_15781 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_15779)){
            _8971 = SEQ_PTR(_cmd_text_15779)->length;
    }
    else {
        _8971 = 1;
    }
    {
        int _i_15818;
        _i_15818 = 1;
L8: 
        if (_i_15818 > _8971){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_15779);
        _8972 = (int)*(((s1_ptr)_2)->base + _i_15818);
        _8973 = find_from(_8972, _5299, 1);
        _8972 = NOVALUE;
        if (_8973 == 0)
        {
            _8973 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8973 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _8974 = _i_15818 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_15780;
        RHS_Slice(_opt_name_15780, 1, _8974);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _8976 = _i_15818 + 1;
        if (IS_SEQUENCE(_cmd_text_15779)){
                _8977 = SEQ_PTR(_cmd_text_15779)->length;
        }
        else {
            _8977 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_15781;
        RHS_Slice(_cmd_text_15779, _8976, _8977);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_15781)){
                _8979 = SEQ_PTR(_opt_param_15781)->length;
        }
        else {
            _8979 = 1;
        }
        if (_8979 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_15781);
        _8981 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8981)) {
            _8982 = (_8981 == 39);
        }
        else {
            _8982 = binary_op(EQUALS, _8981, 39);
        }
        _8981 = NOVALUE;
        if (IS_ATOM_INT(_8982)) {
            if (_8982 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8982)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_15781);
        _8984 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8984)) {
            _8985 = (_8984 == 34);
        }
        else {
            _8985 = binary_op(EQUALS, _8984, 34);
        }
        _8984 = NOVALUE;
        if (_8985 == 0) {
            DeRef(_8985);
            _8985 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8985) && DBL_PTR(_8985)->dbl == 0.0){
                DeRef(_8985);
                _8985 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8985);
            _8985 = NOVALUE;
        }
        DeRef(_8985);
        _8985 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_15781)){
                _8986 = SEQ_PTR(_opt_param_15781)->length;
        }
        else {
            _8986 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_15781);
        _8987 = (int)*(((s1_ptr)_2)->base + _8986);
        _2 = (int)SEQ_PTR(_opt_param_15781);
        _8988 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8987, _8988)){
            _8987 = NOVALUE;
            _8988 = NOVALUE;
            goto LE; // [259] 278
        }
        _8987 = NOVALUE;
        _8988 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_15781)){
                _8990 = SEQ_PTR(_opt_param_15781)->length;
        }
        else {
            _8990 = 1;
        }
        _8991 = _8990 - 1;
        _8990 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_15781;
        RHS_Slice(_opt_param_15781, 2, _8991);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_15781)){
                _8993 = SEQ_PTR(_opt_param_15781)->length;
        }
        else {
            _8993 = 1;
        }
        if (_8993 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_15782 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_15779);
        _8995 = (int)*(((s1_ptr)_2)->base + _i_15818);
        Ref(_8995);
        _2 = (int)SEQ_PTR(_opt_name_15780);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_15780 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_15818);
        _1 = *(int *)_2;
        *(int *)_2 = _8995;
        if( _1 != _8995 ){
            DeRef(_1);
        }
        _8995 = NOVALUE;
LF: 

        /** 	end for*/
        _i_15818 = _i_15818 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_15782 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_15781);
    _8996 = _6lower(_opt_param_15781);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8997);
    *((int *)(_2+4)) = _8997;
    RefDS(_8998);
    *((int *)(_2+8)) = _8998;
    RefDS(_8999);
    *((int *)(_2+12)) = _8999;
    RefDS(_9000);
    *((int *)(_2+16)) = _9000;
    RefDS(_9001);
    *((int *)(_2+20)) = _9001;
    RefDS(_9002);
    *((int *)(_2+24)) = _9002;
    RefDS(_9003);
    *((int *)(_2+28)) = _9003;
    _9004 = MAKE_SEQ(_1);
    _9005 = find_from(_8996, _9004, 1);
    DeRef(_8996);
    _8996 = NOVALUE;
    DeRefDS(_9004);
    _9004 = NOVALUE;
    if (_9005 == 0)
    {
        _9005 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _9005 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_15781);
    _opt_param_15781 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_15781);
    _9006 = _6lower(_opt_param_15781);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_9007);
    *((int *)(_2+4)) = _9007;
    RefDS(_9008);
    *((int *)(_2+8)) = _9008;
    RefDS(_9009);
    *((int *)(_2+12)) = _9009;
    RefDS(_9010);
    *((int *)(_2+16)) = _9010;
    RefDS(_9011);
    *((int *)(_2+20)) = _9011;
    RefDS(_7870);
    *((int *)(_2+24)) = _7870;
    _9012 = MAKE_SEQ(_1);
    _9013 = find_from(_9006, _9012, 1);
    DeRef(_9006);
    _9006 = NOVALUE;
    DeRefDS(_9012);
    _9012 = NOVALUE;
    if (_9013 == 0)
    {
        _9013 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _9013 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_15781);
    _opt_param_15781 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15777)){
            _9014 = SEQ_PTR(_opts_15777)->length;
    }
    else {
        _9014 = 1;
    }
    {
        int _i_15872;
        _i_15872 = 1;
L14: 
        if (_i_15872 > _9014){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15777);
        _9015 = (int)*(((s1_ptr)_2)->base + _i_15872);
        _2 = (int)SEQ_PTR(_9015);
        _9016 = (int)*(((s1_ptr)_2)->base + 4);
        _9015 = NOVALUE;
        _9017 = find_from(105, _9016, 1);
        _9016 = NOVALUE;
        if (_9017 == 0)
        {
            _9017 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _9017 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_15780);
        _9018 = _6lower(_opt_name_15780);
        _2 = (int)SEQ_PTR(_opts_15777);
        _9019 = (int)*(((s1_ptr)_2)->base + _i_15872);
        _2 = (int)SEQ_PTR(_opt_style_15778);
        _9020 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_9019);
        if (!IS_ATOM_INT(_9020)){
            _9021 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9020)->dbl));
        }
        else{
            _9021 = (int)*(((s1_ptr)_2)->base + _9020);
        }
        _9019 = NOVALUE;
        Ref(_9021);
        _9022 = _6lower(_9021);
        _9021 = NOVALUE;
        if (_9018 == _9022)
        _9023 = 1;
        else if (IS_ATOM_INT(_9018) && IS_ATOM_INT(_9022))
        _9023 = 0;
        else
        _9023 = (compare(_9018, _9022) == 0);
        DeRef(_9018);
        _9018 = NOVALUE;
        DeRef(_9022);
        _9022 = NOVALUE;
        if (_9023 != 0)
        goto L17; // [444] 482
        _9023 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_15777);
        _9025 = (int)*(((s1_ptr)_2)->base + _i_15872);
        _2 = (int)SEQ_PTR(_opt_style_15778);
        _9026 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_9025);
        if (!IS_ATOM_INT(_9026)){
            _9027 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9026)->dbl));
        }
        else{
            _9027 = (int)*(((s1_ptr)_2)->base + _9026);
        }
        _9025 = NOVALUE;
        if (_opt_name_15780 == _9027)
        _9028 = 1;
        else if (IS_ATOM_INT(_opt_name_15780) && IS_ATOM_INT(_9027))
        _9028 = 0;
        else
        _9028 = (compare(_opt_name_15780, _9027) == 0);
        _9027 = NOVALUE;
        if (_9028 != 0)
        goto L19; // [473] 481
        _9028 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15777);
        _9030 = (int)*(((s1_ptr)_2)->base + _i_15872);
        _2 = (int)SEQ_PTR(_9030);
        _9031 = (int)*(((s1_ptr)_2)->base + 4);
        _9030 = NOVALUE;
        _9032 = find_from(112, _9031, 1);
        _9031 = NOVALUE;
        if (_9032 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_15782 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_9034);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _9034;
        _9035 = MAKE_SEQ(_1);
        DeRefDS(_opts_15777);
        DeRefDS(_opt_style_15778);
        DeRef(_cmd_text_15779);
        DeRef(_opt_name_15780);
        DeRef(_opt_param_15781);
        DeRef(_8956);
        _8956 = NOVALUE;
        DeRef(_8947);
        _8947 = NOVALUE;
        DeRef(_8968);
        _8968 = NOVALUE;
        DeRef(_8974);
        _8974 = NOVALUE;
        DeRef(_8976);
        _8976 = NOVALUE;
        DeRef(_8991);
        _8991 = NOVALUE;
        DeRef(_8982);
        _8982 = NOVALUE;
        _9026 = NOVALUE;
        _9020 = NOVALUE;
        return _9035;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_15782 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15872;
        RefDS(_opt_name_15780);
        *((int *)(_2+8)) = _opt_name_15780;
        *((int *)(_2+12)) = _reversed_15783;
        Ref(_opt_param_15781);
        *((int *)(_2+16)) = _opt_param_15781;
        _9036 = MAKE_SEQ(_1);
        DeRefDS(_opts_15777);
        DeRefDS(_opt_style_15778);
        DeRef(_cmd_text_15779);
        DeRefDS(_opt_name_15780);
        DeRef(_opt_param_15781);
        DeRef(_8956);
        _8956 = NOVALUE;
        DeRef(_8947);
        _8947 = NOVALUE;
        DeRef(_8968);
        _8968 = NOVALUE;
        DeRef(_8974);
        _8974 = NOVALUE;
        DeRef(_8976);
        _8976 = NOVALUE;
        DeRef(_8991);
        _8991 = NOVALUE;
        DeRef(_8982);
        _8982 = NOVALUE;
        DeRef(_9035);
        _9035 = NOVALUE;
        _9026 = NOVALUE;
        _9020 = NOVALUE;
        return _9036;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15777);
        _9037 = (int)*(((s1_ptr)_2)->base + _i_15872);
        _2 = (int)SEQ_PTR(_9037);
        _9038 = (int)*(((s1_ptr)_2)->base + 4);
        _9037 = NOVALUE;
        _9039 = find_from(112, _9038, 1);
        _9038 = NOVALUE;
        if (_9039 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15872;
        RefDS(_opt_name_15780);
        *((int *)(_2+8)) = _opt_name_15780;
        *((int *)(_2+12)) = _reversed_15783;
        *((int *)(_2+16)) = 1;
        _9041 = MAKE_SEQ(_1);
        DeRefDS(_opts_15777);
        DeRefDS(_opt_style_15778);
        DeRef(_cmd_text_15779);
        DeRefDS(_opt_name_15780);
        DeRef(_opt_param_15781);
        DeRef(_8956);
        _8956 = NOVALUE;
        DeRef(_8947);
        _8947 = NOVALUE;
        DeRef(_8968);
        _8968 = NOVALUE;
        DeRef(_8974);
        _8974 = NOVALUE;
        DeRef(_8976);
        _8976 = NOVALUE;
        DeRef(_8991);
        _8991 = NOVALUE;
        DeRef(_8982);
        _8982 = NOVALUE;
        DeRef(_9035);
        _9035 = NOVALUE;
        _9026 = NOVALUE;
        _9020 = NOVALUE;
        DeRef(_9036);
        _9036 = NOVALUE;
        return _9041;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_15872;
        RefDS(_opt_name_15780);
        *((int *)(_2+8)) = _opt_name_15780;
        *((int *)(_2+12)) = _reversed_15783;
        _9042 = MAKE_SEQ(_1);
        DeRefDS(_opts_15777);
        DeRefDS(_opt_style_15778);
        DeRef(_cmd_text_15779);
        DeRefDS(_opt_name_15780);
        DeRef(_opt_param_15781);
        DeRef(_8956);
        _8956 = NOVALUE;
        DeRef(_8947);
        _8947 = NOVALUE;
        DeRef(_8968);
        _8968 = NOVALUE;
        DeRef(_8974);
        _8974 = NOVALUE;
        DeRef(_8976);
        _8976 = NOVALUE;
        DeRef(_8991);
        _8991 = NOVALUE;
        DeRef(_8982);
        _8982 = NOVALUE;
        DeRef(_9035);
        _9035 = NOVALUE;
        _9026 = NOVALUE;
        _9020 = NOVALUE;
        DeRef(_9036);
        _9036 = NOVALUE;
        DeRef(_9041);
        _9041 = NOVALUE;
        return _9042;
L1D: 

        /** 	end for*/
L18: 
        _i_15872 = _i_15872 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_9043);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _9043;
    _9044 = MAKE_SEQ(_1);
    DeRefDS(_opts_15777);
    DeRefDS(_opt_style_15778);
    DeRef(_cmd_text_15779);
    DeRef(_opt_name_15780);
    DeRef(_opt_param_15781);
    DeRef(_8956);
    _8956 = NOVALUE;
    DeRef(_8947);
    _8947 = NOVALUE;
    DeRef(_8968);
    _8968 = NOVALUE;
    DeRef(_8974);
    _8974 = NOVALUE;
    DeRef(_8976);
    _8976 = NOVALUE;
    DeRef(_8991);
    _8991 = NOVALUE;
    DeRef(_8982);
    _8982 = NOVALUE;
    DeRef(_9035);
    _9035 = NOVALUE;
    _9026 = NOVALUE;
    _9020 = NOVALUE;
    DeRef(_9036);
    _9036 = NOVALUE;
    DeRef(_9041);
    _9041 = NOVALUE;
    DeRef(_9042);
    _9042 = NOVALUE;
    return _9044;
    ;
}


int _31cmd_parse(int _opts_15915, int _parse_options_15916, int _cmds_15917)
{
    int _arg_idx_15919 = NOVALUE;
    int _opts_done_15920 = NOVALUE;
    int _cmd_15921 = NOVALUE;
    int _param_15922 = NOVALUE;
    int _find_result_15923 = NOVALUE;
    int _type__15924 = NOVALUE;
    int _from__15925 = NOVALUE;
    int _help_opts_15926 = NOVALUE;
    int _call_count_15927 = NOVALUE;
    int _add_help_rid_15928 = NOVALUE;
    int _validation_15929 = NOVALUE;
    int _has_extra_15930 = NOVALUE;
    int _use_at_15931 = NOVALUE;
    int _auto_help_15932 = NOVALUE;
    int _help_on_error_15933 = NOVALUE;
    int _po_15934 = NOVALUE;
    int _msg_inlined_crash_at_107_15952 = NOVALUE;
    int _msg_inlined_crash_at_237_15969 = NOVALUE;
    int _msg_inlined_crash_at_275_15976 = NOVALUE;
    int _fmt_inlined_crash_at_272_15975 = NOVALUE;
    int _parsed_opts_15981 = NOVALUE;
    int _at_cmds_16028 = NOVALUE;
    int _j_16029 = NOVALUE;
    int _cmdex_16114 = NOVALUE;
    int _opt_16178 = NOVALUE;
    int _map_add_operation_16181 = NOVALUE;
    int _pos_16220 = NOVALUE;
    int _ver_pos_16267 = NOVALUE;
    int _msg_inlined_crash_at_2040_16285 = NOVALUE;
    int _fmt_inlined_crash_at_2037_16284 = NOVALUE;
    int _9326 = NOVALUE;
    int _9325 = NOVALUE;
    int _9324 = NOVALUE;
    int _9321 = NOVALUE;
    int _9320 = NOVALUE;
    int _9319 = NOVALUE;
    int _9316 = NOVALUE;
    int _9315 = NOVALUE;
    int _9314 = NOVALUE;
    int _9313 = NOVALUE;
    int _9312 = NOVALUE;
    int _9311 = NOVALUE;
    int _9310 = NOVALUE;
    int _9309 = NOVALUE;
    int _9308 = NOVALUE;
    int _9307 = NOVALUE;
    int _9306 = NOVALUE;
    int _9305 = NOVALUE;
    int _9304 = NOVALUE;
    int _9303 = NOVALUE;
    int _9302 = NOVALUE;
    int _9301 = NOVALUE;
    int _9298 = NOVALUE;
    int _9297 = NOVALUE;
    int _9296 = NOVALUE;
    int _9293 = NOVALUE;
    int _9292 = NOVALUE;
    int _9290 = NOVALUE;
    int _9289 = NOVALUE;
    int _9288 = NOVALUE;
    int _9287 = NOVALUE;
    int _9286 = NOVALUE;
    int _9285 = NOVALUE;
    int _9284 = NOVALUE;
    int _9283 = NOVALUE;
    int _9281 = NOVALUE;
    int _9280 = NOVALUE;
    int _9278 = NOVALUE;
    int _9277 = NOVALUE;
    int _9276 = NOVALUE;
    int _9275 = NOVALUE;
    int _9274 = NOVALUE;
    int _9273 = NOVALUE;
    int _9272 = NOVALUE;
    int _9271 = NOVALUE;
    int _9269 = NOVALUE;
    int _9268 = NOVALUE;
    int _9267 = NOVALUE;
    int _9265 = NOVALUE;
    int _9263 = NOVALUE;
    int _9262 = NOVALUE;
    int _9261 = NOVALUE;
    int _9260 = NOVALUE;
    int _9259 = NOVALUE;
    int _9258 = NOVALUE;
    int _9257 = NOVALUE;
    int _9256 = NOVALUE;
    int _9255 = NOVALUE;
    int _9252 = NOVALUE;
    int _9249 = NOVALUE;
    int _9248 = NOVALUE;
    int _9246 = NOVALUE;
    int _9245 = NOVALUE;
    int _9244 = NOVALUE;
    int _9243 = NOVALUE;
    int _9242 = NOVALUE;
    int _9241 = NOVALUE;
    int _9240 = NOVALUE;
    int _9239 = NOVALUE;
    int _9238 = NOVALUE;
    int _9237 = NOVALUE;
    int _9236 = NOVALUE;
    int _9233 = NOVALUE;
    int _9230 = NOVALUE;
    int _9228 = NOVALUE;
    int _9227 = NOVALUE;
    int _9225 = NOVALUE;
    int _9224 = NOVALUE;
    int _9223 = NOVALUE;
    int _9221 = NOVALUE;
    int _9220 = NOVALUE;
    int _9219 = NOVALUE;
    int _9217 = NOVALUE;
    int _9215 = NOVALUE;
    int _9213 = NOVALUE;
    int _9211 = NOVALUE;
    int _9210 = NOVALUE;
    int _9209 = NOVALUE;
    int _9208 = NOVALUE;
    int _9207 = NOVALUE;
    int _9203 = NOVALUE;
    int _9201 = NOVALUE;
    int _9200 = NOVALUE;
    int _9199 = NOVALUE;
    int _9198 = NOVALUE;
    int _9197 = NOVALUE;
    int _9196 = NOVALUE;
    int _9194 = NOVALUE;
    int _9193 = NOVALUE;
    int _9192 = NOVALUE;
    int _9191 = NOVALUE;
    int _9190 = NOVALUE;
    int _9189 = NOVALUE;
    int _9188 = NOVALUE;
    int _9184 = NOVALUE;
    int _9183 = NOVALUE;
    int _9180 = NOVALUE;
    int _9179 = NOVALUE;
    int _9178 = NOVALUE;
    int _9177 = NOVALUE;
    int _9176 = NOVALUE;
    int _9175 = NOVALUE;
    int _9174 = NOVALUE;
    int _9173 = NOVALUE;
    int _9172 = NOVALUE;
    int _9171 = NOVALUE;
    int _9170 = NOVALUE;
    int _9169 = NOVALUE;
    int _9168 = NOVALUE;
    int _9167 = NOVALUE;
    int _9166 = NOVALUE;
    int _9165 = NOVALUE;
    int _9164 = NOVALUE;
    int _9163 = NOVALUE;
    int _9162 = NOVALUE;
    int _9161 = NOVALUE;
    int _9160 = NOVALUE;
    int _9159 = NOVALUE;
    int _9158 = NOVALUE;
    int _9157 = NOVALUE;
    int _9156 = NOVALUE;
    int _9155 = NOVALUE;
    int _9154 = NOVALUE;
    int _9153 = NOVALUE;
    int _9152 = NOVALUE;
    int _9151 = NOVALUE;
    int _9150 = NOVALUE;
    int _9149 = NOVALUE;
    int _9146 = NOVALUE;
    int _9145 = NOVALUE;
    int _9144 = NOVALUE;
    int _9143 = NOVALUE;
    int _9142 = NOVALUE;
    int _9140 = NOVALUE;
    int _9139 = NOVALUE;
    int _9136 = NOVALUE;
    int _9135 = NOVALUE;
    int _9134 = NOVALUE;
    int _9133 = NOVALUE;
    int _9132 = NOVALUE;
    int _9130 = NOVALUE;
    int _9129 = NOVALUE;
    int _9128 = NOVALUE;
    int _9127 = NOVALUE;
    int _9124 = NOVALUE;
    int _9122 = NOVALUE;
    int _9121 = NOVALUE;
    int _9120 = NOVALUE;
    int _9118 = NOVALUE;
    int _9116 = NOVALUE;
    int _9115 = NOVALUE;
    int _9112 = NOVALUE;
    int _9110 = NOVALUE;
    int _9109 = NOVALUE;
    int _9108 = NOVALUE;
    int _9107 = NOVALUE;
    int _9106 = NOVALUE;
    int _9105 = NOVALUE;
    int _9104 = NOVALUE;
    int _9103 = NOVALUE;
    int _9102 = NOVALUE;
    int _9101 = NOVALUE;
    int _9099 = NOVALUE;
    int _9095 = NOVALUE;
    int _9093 = NOVALUE;
    int _9092 = NOVALUE;
    int _9091 = NOVALUE;
    int _9088 = NOVALUE;
    int _9087 = NOVALUE;
    int _9086 = NOVALUE;
    int _9084 = NOVALUE;
    int _9083 = NOVALUE;
    int _9082 = NOVALUE;
    int _9081 = NOVALUE;
    int _9080 = NOVALUE;
    int _9078 = NOVALUE;
    int _9077 = NOVALUE;
    int _9076 = NOVALUE;
    int _9075 = NOVALUE;
    int _9074 = NOVALUE;
    int _9073 = NOVALUE;
    int _9072 = NOVALUE;
    int _9071 = NOVALUE;
    int _9070 = NOVALUE;
    int _9067 = NOVALUE;
    int _9064 = NOVALUE;
    int _9063 = NOVALUE;
    int _9057 = NOVALUE;
    int _9053 = NOVALUE;
    int _9050 = NOVALUE;
    int _9048 = NOVALUE;
    int _9046 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    DeRef(_add_help_rid_15928);
    _add_help_rid_15928 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_15929 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_15930 = 0;

    /** 	integer use_at = 1*/
    _use_at_15931 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_15932 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_15933 = 1;

    /** 	integer po = 1*/
    _po_15934 = 1;

    /** 	if atom(parse_options) then*/
    _9046 = IS_ATOM(_parse_options_15916);
    if (_9046 == 0)
    {
        _9046 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _9046 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_15916;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_15916);
    *((int *)(_2+4)) = _parse_options_15916;
    _parse_options_15916 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_15916)){
            _9048 = SEQ_PTR(_parse_options_15916)->length;
    }
    else {
        _9048 = 1;
    }
    if (_po_15934 > _9048)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_15916);
    _9050 = (int)*(((s1_ptr)_2)->base + _po_15934);
    if (IS_SEQUENCE(_9050) ){
        goto L4; // [73] 261
    }
    if(!IS_ATOM_INT(_9050)){
        if( (DBL_PTR(_9050)->dbl != (double) ((int) DBL_PTR(_9050)->dbl) ) ){
            goto L4; // [73] 261
        }
        _0 = (int) DBL_PTR(_9050)->dbl;
    }
    else {
        _0 = _9050;
    };
    _9050 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15916)){
                _9053 = SEQ_PTR(_parse_options_15916)->length;
        }
        else {
            _9053 = 1;
        }
        if (_po_15934 >= _9053)
        goto L5; // [87] 106

        /** 					po += 1*/
        _po_15934 = _po_15934 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_15928);
        _2 = (int)SEQ_PTR(_parse_options_15916);
        _add_help_rid_15928 = (int)*(((s1_ptr)_2)->base + _po_15934);
        Ref(_add_help_rid_15928);
        goto L6; // [103] 297
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_15952);
        _msg_inlined_crash_at_107_15952 = EPrintf(-9999999, _8765, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_15952);

        /** end procedure*/
        goto L7; // [121] 124
L7: 
        DeRefi(_msg_inlined_crash_at_107_15952);
        _msg_inlined_crash_at_107_15952 = NOVALUE;
        goto L6; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_15932 = 0;
        goto L6; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_15933 = 0;
        goto L6; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_15929 = 2;
        goto L6; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_15929 = 3;
        goto L6; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_15929 = 4;
        goto L6; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_15931 = 0;
        goto L6; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_15931 = 1;
        goto L6; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_15916)){
                _9057 = SEQ_PTR(_parse_options_15916)->length;
        }
        else {
            _9057 = 1;
        }
        if (_po_15934 >= _9057)
        goto L8; // [215] 236

        /** 					po += 1*/
        _po_15934 = _po_15934 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_31pause_msg_15228);
        _2 = (int)SEQ_PTR(_parse_options_15916);
        _31pause_msg_15228 = (int)*(((s1_ptr)_2)->base + _po_15934);
        Ref(_31pause_msg_15228);
        goto L6; // [233] 297
L8: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_15969);
        _msg_inlined_crash_at_237_15969 = EPrintf(-9999999, _9061, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_15969);

        /** end procedure*/
        goto L9; // [251] 254
L9: 
        DeRefi(_msg_inlined_crash_at_237_15969);
        _msg_inlined_crash_at_237_15969 = NOVALUE;
        goto L6; // [257] 297

        /** 			case else*/
        default:
L4: 

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_15916);
        _9063 = (int)*(((s1_ptr)_2)->base + _po_15934);
        _9064 = EPrintf(-9999999, _9062, _9063);
        _9063 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_15975);
        _fmt_inlined_crash_at_272_15975 = _9064;
        _9064 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_15976);
        _msg_inlined_crash_at_275_15976 = EPrintf(-9999999, _fmt_inlined_crash_at_272_15975, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_15976);

        /** end procedure*/
        goto LA; // [291] 294
LA: 
        DeRefi(_fmt_inlined_crash_at_272_15975);
        _fmt_inlined_crash_at_272_15975 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_15976);
        _msg_inlined_crash_at_275_15976 = NOVALUE;
    ;}L6: 

    /** 		po += 1*/
    _po_15934 = _po_15934 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_15915);
    _0 = _opts_15915;
    _opts_15915 = _31standardize_opts(_opts_15915, _auto_help_15932);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_15915)){
            _9067 = SEQ_PTR(_opts_15915)->length;
    }
    else {
        _9067 = 1;
    }
    DeRef(_call_count_15927);
    _call_count_15927 = Repeat(0, _9067);
    _9067 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_15981;
    _parsed_opts_15981 = _33new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_15981);
    RefDS(_31EXTRAS_15217);
    RefDS(_5);
    _33put(_parsed_opts_15981, _31EXTRAS_15217, _5, 1, _33threshold_size_12820);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_15926);
    _help_opts_15926 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15915)){
            _9070 = SEQ_PTR(_opts_15915)->length;
    }
    else {
        _9070 = 1;
    }
    {
        int _i_15984;
        _i_15984 = 1;
LB: 
        if (_i_15984 > _9070){
            goto LC; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9071 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9071);
        _9072 = (int)*(((s1_ptr)_2)->base + 4);
        _9071 = NOVALUE;
        _9073 = find_from(104, _9072, 1);
        _9072 = NOVALUE;
        if (_9073 == 0)
        {
            _9073 = NOVALUE;
            goto LD; // [379] 510
        }
        else{
            _9073 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9074 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9074);
        _9075 = (int)*(((s1_ptr)_2)->base + 1);
        _9074 = NOVALUE;
        _9076 = IS_SEQUENCE(_9075);
        _9075 = NOVALUE;
        if (_9076 == 0)
        {
            _9076 = NOVALUE;
            goto LE; // [395] 413
        }
        else{
            _9076 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9077 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9077);
        _9078 = (int)*(((s1_ptr)_2)->base + 1);
        _9077 = NOVALUE;
        Ref(_9078);
        Append(&_help_opts_15926, _help_opts_15926, _9078);
        _9078 = NOVALUE;
LE: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9080 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9080);
        _9081 = (int)*(((s1_ptr)_2)->base + 2);
        _9080 = NOVALUE;
        _9082 = IS_SEQUENCE(_9081);
        _9081 = NOVALUE;
        if (_9082 == 0)
        {
            _9082 = NOVALUE;
            goto LF; // [426] 444
        }
        else{
            _9082 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9083 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9083);
        _9084 = (int)*(((s1_ptr)_2)->base + 2);
        _9083 = NOVALUE;
        Ref(_9084);
        Append(&_help_opts_15926, _help_opts_15926, _9084);
        _9084 = NOVALUE;
LF: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9086 = (int)*(((s1_ptr)_2)->base + _i_15984);
        _2 = (int)SEQ_PTR(_9086);
        _9087 = (int)*(((s1_ptr)_2)->base + 4);
        _9086 = NOVALUE;
        _9088 = find_from(105, _9087, 1);
        _9087 = NOVALUE;
        if (_9088 == 0)
        {
            _9088 = NOVALUE;
            goto L10; // [459] 509
        }
        else{
            _9088 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_15926);
        _0 = _help_opts_15926;
        _help_opts_15926 = _6lower(_help_opts_15926);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_15926)){
                _arg_idx_15919 = SEQ_PTR(_help_opts_15926)->length;
        }
        else {
            _arg_idx_15919 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _9091 = _arg_idx_15919;
        {
            int _j_16011;
            _j_16011 = 1;
L11: 
            if (_j_16011 > _9091){
                goto L12; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_15926);
            _9092 = (int)*(((s1_ptr)_2)->base + _j_16011);
            Ref(_9092);
            _9093 = _6upper(_9092);
            _9092 = NOVALUE;
            Ref(_9093);
            Append(&_help_opts_15926, _help_opts_15926, _9093);
            DeRef(_9093);
            _9093 = NOVALUE;

            /** 				end for*/
            _j_16011 = _j_16011 + 1;
            goto L11; // [503] 487
L12: 
            ;
        }
L10: 
LD: 

        /** 	end for*/
        _i_15984 = _i_15984 + 1;
        goto LB; // [512] 364
LC: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_15919 = 2;

    /** 	opts_done = 0*/
    _opts_done_15920 = 0;

    /** 	while arg_idx < length(cmds) do*/
L13: 
    if (IS_SEQUENCE(_cmds_15917)){
            _9095 = SEQ_PTR(_cmds_15917)->length;
    }
    else {
        _9095 = 1;
    }
    if (_arg_idx_15919 >= _9095)
    goto L14; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_15919 = _arg_idx_15919 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_15921);
    _2 = (int)SEQ_PTR(_cmds_15917);
    _cmd_15921 = (int)*(((s1_ptr)_2)->base + _arg_idx_15919);
    Ref(_cmd_15921);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9099 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9099 = 1;
    }
    if (_9099 != 0)
    goto L15; // [558] 567

    /** 			continue*/
    goto L13; // [564] 532
L15: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_15921);
    _9101 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_9101)) {
        _9102 = (_9101 == 64);
    }
    else {
        _9102 = binary_op(EQUALS, _9101, 64);
    }
    _9101 = NOVALUE;
    if (IS_ATOM_INT(_9102)) {
        if (_9102 == 0) {
            goto L16; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_9102)->dbl == 0.0) {
            goto L16; // [577] 1095
        }
    }
    if (_use_at_15931 == 0)
    {
        goto L16; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9104 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9104 = 1;
    }
    _9105 = (_9104 > 2);
    _9104 = NOVALUE;
    if (_9105 == 0) {
        goto L17; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_15921);
    _9107 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_9107)) {
        _9108 = (_9107 == 64);
    }
    else {
        _9108 = binary_op(EQUALS, _9107, 64);
    }
    _9107 = NOVALUE;
    if (_9108 == 0) {
        DeRef(_9108);
        _9108 = NOVALUE;
        goto L17; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_9108) && DBL_PTR(_9108)->dbl == 0.0){
            DeRef(_9108);
            _9108 = NOVALUE;
            goto L17; // [611] 660
        }
        DeRef(_9108);
        _9108 = NOVALUE;
    }
    DeRef(_9108);
    _9108 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9109 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9109 = 1;
    }
    rhs_slice_target = (object_ptr)&_9110;
    RHS_Slice(_cmd_15921, 3, _9109);
    _0 = _at_cmds_16028;
    _at_cmds_16028 = _18read_lines(_9110);
    DeRef(_0);
    _9110 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16028 == -1)
    _9112 = 1;
    else if (IS_ATOM_INT(_at_cmds_16028) && IS_ATOM_INT(-1))
    _9112 = 0;
    else
    _9112 = (compare(_at_cmds_16028, -1) == 0);
    if (_9112 == 0)
    {
        _9112 = NOVALUE;
        goto L18; // [634] 738
    }
    else{
        _9112 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_15917);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_15919)) ? _arg_idx_15919 : (long)(DBL_PTR(_arg_idx_15919)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_15919)) ? _arg_idx_15919 : (long)(DBL_PTR(_arg_idx_15919)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_15917), start, &_cmds_15917 );
            }
            else Tail(SEQ_PTR(_cmds_15917), stop+1, &_cmds_15917);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_15917), start, &_cmds_15917);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_15917 = Remove_elements(start, stop, (SEQ_PTR(_cmds_15917)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_15919 = _arg_idx_15919 - 1;

    /** 					continue*/
    DeRef(_at_cmds_16028);
    _at_cmds_16028 = NOVALUE;
    goto L13; // [654] 532
    goto L18; // [657] 738
L17: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9115 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9115 = 1;
    }
    rhs_slice_target = (object_ptr)&_9116;
    RHS_Slice(_cmd_15921, 2, _9115);
    _0 = _at_cmds_16028;
    _at_cmds_16028 = _18read_lines(_9116);
    DeRef(_0);
    _9116 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_16028 == -1)
    _9118 = 1;
    else if (IS_ATOM_INT(_at_cmds_16028) && IS_ATOM_INT(-1))
    _9118 = 0;
    else
    _9118 = (compare(_at_cmds_16028, -1) == 0);
    if (_9118 == 0)
    {
        _9118 = NOVALUE;
        goto L19; // [680] 737
    }
    else{
        _9118 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9120 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9120 = 1;
    }
    rhs_slice_target = (object_ptr)&_9121;
    RHS_Slice(_cmd_15921, 2, _9120);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9121;
    _9122 = MAKE_SEQ(_1);
    _9121 = NOVALUE;
    EPrintf(2, _9119, _9122);
    DeRefDS(_9122);
    _9122 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_15933 == 0)
    {
        goto L1A; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15915);
    Ref(_add_help_rid_15928);
    RefDS(_cmds_15917);
    Ref(_parse_options_15916);
    _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
    goto L1B; // [715] 731
L1A: 

    /** 					elsif auto_help then*/
    if (_auto_help_15932 == 0)
    {
        goto L1C; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _9123, _5);
L1C: 
L1B: 

    /** 					local_abort(1)*/
    _31local_abort(1);
L19: 
L18: 

    /** 			j = 0*/
    _j_16029 = 0;

    /** 			while j < length(at_cmds) do*/
L1D: 
    if (IS_SEQUENCE(_at_cmds_16028)){
            _9124 = SEQ_PTR(_at_cmds_16028)->length;
    }
    else {
        _9124 = 1;
    }
    if (_j_16029 >= _9124)
    goto L1E; // [753] 1074

    /** 				j += 1*/
    _j_16029 = _j_16029 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9127 = (int)*(((s1_ptr)_2)->base + _j_16029);
    Ref(_9127);
    RefDS(_4498);
    _9128 = _6trim(_9127, _4498, 0);
    _9127 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16028 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16029);
    _1 = *(int *)_2;
    *(int *)_2 = _9128;
    if( _1 != _9128 ){
        DeRef(_1);
    }
    _9128 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9129 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9129)){
            _9130 = SEQ_PTR(_9129)->length;
    }
    else {
        _9130 = 1;
    }
    _9129 = NOVALUE;
    if (_9130 != 0)
    goto L1F; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _9132 = _j_16029 - 1;
    rhs_slice_target = (object_ptr)&_9133;
    RHS_Slice(_at_cmds_16028, 1, _9132);
    _9134 = _j_16029 + 1;
    if (_9134 > MAXINT){
        _9134 = NewDouble((double)_9134);
    }
    if (IS_SEQUENCE(_at_cmds_16028)){
            _9135 = SEQ_PTR(_at_cmds_16028)->length;
    }
    else {
        _9135 = 1;
    }
    rhs_slice_target = (object_ptr)&_9136;
    RHS_Slice(_at_cmds_16028, _9134, _9135);
    Concat((object_ptr)&_at_cmds_16028, _9133, _9136);
    DeRefDS(_9133);
    _9133 = NOVALUE;
    DeRef(_9133);
    _9133 = NOVALUE;
    DeRefDS(_9136);
    _9136 = NOVALUE;

    /** 					j -= 1*/
    _j_16029 = _j_16029 - 1;
    goto L1D; // [825] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9139 = (int)*(((s1_ptr)_2)->base + _j_16029);
    _2 = (int)SEQ_PTR(_9139);
    _9140 = (int)*(((s1_ptr)_2)->base + 1);
    _9139 = NOVALUE;
    if (binary_op_a(NOTEQ, _9140, 35)){
        _9140 = NOVALUE;
        goto L20; // [838] 878
    }
    _9140 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _9142 = _j_16029 - 1;
    rhs_slice_target = (object_ptr)&_9143;
    RHS_Slice(_at_cmds_16028, 1, _9142);
    _9144 = _j_16029 + 1;
    if (_9144 > MAXINT){
        _9144 = NewDouble((double)_9144);
    }
    if (IS_SEQUENCE(_at_cmds_16028)){
            _9145 = SEQ_PTR(_at_cmds_16028)->length;
    }
    else {
        _9145 = 1;
    }
    rhs_slice_target = (object_ptr)&_9146;
    RHS_Slice(_at_cmds_16028, _9144, _9145);
    Concat((object_ptr)&_at_cmds_16028, _9143, _9146);
    DeRefDS(_9143);
    _9143 = NOVALUE;
    DeRef(_9143);
    _9143 = NOVALUE;
    DeRefDS(_9146);
    _9146 = NOVALUE;

    /** 					j -= 1*/
    _j_16029 = _j_16029 - 1;
    goto L1D; // [875] 748
L20: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9149 = (int)*(((s1_ptr)_2)->base + _j_16029);
    _2 = (int)SEQ_PTR(_9149);
    _9150 = (int)*(((s1_ptr)_2)->base + 1);
    _9149 = NOVALUE;
    if (IS_ATOM_INT(_9150)) {
        _9151 = (_9150 == 34);
    }
    else {
        _9151 = binary_op(EQUALS, _9150, 34);
    }
    _9150 = NOVALUE;
    if (IS_ATOM_INT(_9151)) {
        if (_9151 == 0) {
            DeRef(_9152);
            _9152 = 0;
            goto L21; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_9151)->dbl == 0.0) {
            DeRef(_9152);
            _9152 = 0;
            goto L21; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9153 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9153)){
            _9154 = SEQ_PTR(_9153)->length;
    }
    else {
        _9154 = 1;
    }
    _2 = (int)SEQ_PTR(_9153);
    _9155 = (int)*(((s1_ptr)_2)->base + _9154);
    _9153 = NOVALUE;
    if (IS_ATOM_INT(_9155)) {
        _9156 = (_9155 == 34);
    }
    else {
        _9156 = binary_op(EQUALS, _9155, 34);
    }
    _9155 = NOVALUE;
    DeRef(_9152);
    if (IS_ATOM_INT(_9156))
    _9152 = (_9156 != 0);
    else
    _9152 = DBL_PTR(_9156)->dbl != 0.0;
L21: 
    if (_9152 == 0) {
        goto L22; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9158 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9158)){
            _9159 = SEQ_PTR(_9158)->length;
    }
    else {
        _9159 = 1;
    }
    _9158 = NOVALUE;
    _9160 = (_9159 >= 2);
    _9159 = NOVALUE;
    if (_9160 == 0)
    {
        DeRef(_9160);
        _9160 = NOVALUE;
        goto L22; // [931] 959
    }
    else{
        DeRef(_9160);
        _9160 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9161 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9161)){
            _9162 = SEQ_PTR(_9161)->length;
    }
    else {
        _9162 = 1;
    }
    _9163 = _9162 - 1;
    _9162 = NOVALUE;
    rhs_slice_target = (object_ptr)&_9164;
    RHS_Slice(_9161, 2, _9163);
    _9161 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_16028 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_16029);
    _1 = *(int *)_2;
    *(int *)_2 = _9164;
    if( _1 != _9164 ){
        DeRef(_1);
    }
    _9164 = NOVALUE;
    goto L1D; // [956] 748
L22: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9165 = (int)*(((s1_ptr)_2)->base + _j_16029);
    _2 = (int)SEQ_PTR(_9165);
    _9166 = (int)*(((s1_ptr)_2)->base + 1);
    _9165 = NOVALUE;
    if (IS_ATOM_INT(_9166)) {
        _9167 = (_9166 == 39);
    }
    else {
        _9167 = binary_op(EQUALS, _9166, 39);
    }
    _9166 = NOVALUE;
    if (IS_ATOM_INT(_9167)) {
        if (_9167 == 0) {
            DeRef(_9168);
            _9168 = 0;
            goto L23; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_9167)->dbl == 0.0) {
            DeRef(_9168);
            _9168 = 0;
            goto L23; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9169 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9169)){
            _9170 = SEQ_PTR(_9169)->length;
    }
    else {
        _9170 = 1;
    }
    _2 = (int)SEQ_PTR(_9169);
    _9171 = (int)*(((s1_ptr)_2)->base + _9170);
    _9169 = NOVALUE;
    if (IS_ATOM_INT(_9171)) {
        _9172 = (_9171 == 39);
    }
    else {
        _9172 = binary_op(EQUALS, _9171, 39);
    }
    _9171 = NOVALUE;
    DeRef(_9168);
    if (IS_ATOM_INT(_9172))
    _9168 = (_9172 != 0);
    else
    _9168 = DBL_PTR(_9172)->dbl != 0.0;
L23: 
    if (_9168 == 0) {
        goto L24; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9174 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9174)){
            _9175 = SEQ_PTR(_9174)->length;
    }
    else {
        _9175 = 1;
    }
    _9174 = NOVALUE;
    _9176 = (_9175 >= 2);
    _9175 = NOVALUE;
    if (_9176 == 0)
    {
        DeRef(_9176);
        _9176 = NOVALUE;
        goto L24; // [1012] 1066
    }
    else{
        DeRef(_9176);
        _9176 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_16028);
    _9177 = (int)*(((s1_ptr)_2)->base + _j_16029);
    if (IS_SEQUENCE(_9177)){
            _9178 = SEQ_PTR(_9177)->length;
    }
    else {
        _9178 = 1;
    }
    _9179 = _9178 - 1;
    _9178 = NOVALUE;
    rhs_slice_target = (object_ptr)&_9180;
    RHS_Slice(_9177, 2, _9179);
    _9177 = NOVALUE;
    _0 = _cmdex_16114;
    _cmdex_16114 = _23split(_9180, 32, 1, 0);
    DeRef(_0);
    _9180 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_16028;
        int p2 = _cmdex_16114;
        int p3 = _j_16029;
        int p4 = _j_16029;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_16028;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_16114)){
            _9183 = SEQ_PTR(_cmdex_16114)->length;
    }
    else {
        _9183 = 1;
    }
    _9184 = _j_16029 + _9183;
    if ((long)((unsigned long)_9184 + (unsigned long)HIGH_BITS) >= 0) 
    _9184 = NewDouble((double)_9184);
    _9183 = NOVALUE;
    if (IS_ATOM_INT(_9184)) {
        _j_16029 = _9184 - 1;
    }
    else {
        _j_16029 = NewDouble(DBL_PTR(_9184)->dbl - (double)1);
    }
    DeRef(_9184);
    _9184 = NOVALUE;
    if (!IS_ATOM_INT(_j_16029)) {
        _1 = (long)(DBL_PTR(_j_16029)->dbl);
        DeRefDS(_j_16029);
        _j_16029 = _1;
    }
L24: 
    DeRef(_cmdex_16114);
    _cmdex_16114 = NOVALUE;

    /** 			end while*/
    goto L1D; // [1071] 748
L1E: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_15917;
        int p2 = _at_cmds_16028;
        int p3 = _arg_idx_15919;
        int p4 = _arg_idx_15919;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_15917;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_15919 = _arg_idx_15919 - 1;

    /** 			continue*/
    DeRef(_at_cmds_16028);
    _at_cmds_16028 = NOVALUE;
    goto L13; // [1092] 532
L16: 
    DeRef(_at_cmds_16028);
    _at_cmds_16028 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_15920 != 0) {
        _9188 = 1;
        goto L25; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_15921);
    _9189 = (int)*(((s1_ptr)_2)->base + 1);
    _9190 = find_from(_9189, _37CMD_SWITCHES_15121, 1);
    _9189 = NOVALUE;
    _9191 = (_9190 == 0);
    _9190 = NOVALUE;
    _9188 = (_9191 != 0);
L25: 
    if (_9188 != 0) {
        DeRef(_9192);
        _9192 = 1;
        goto L26; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_15921)){
            _9193 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9193 = 1;
    }
    _9194 = (_9193 == 1);
    _9193 = NOVALUE;
    _9192 = (_9194 != 0);
L26: 
    if (_9192 == 0)
    {
        _9192 = NOVALUE;
        goto L27; // [1135] 1215
    }
    else{
        _9192 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_15981);
    RefDS(_31EXTRAS_15217);
    RefDS(_cmd_15921);
    _33put(_parsed_opts_15981, _31EXTRAS_15217, _cmd_15921, 6, _33threshold_size_12820);

    /** 			has_extra = 1*/
    _has_extra_15930 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_15929 != 4)
    goto L13; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _9196 = _arg_idx_15919 + 1;
    if (_9196 > MAXINT){
        _9196 = NewDouble((double)_9196);
    }
    if (IS_SEQUENCE(_cmds_15917)){
            _9197 = SEQ_PTR(_cmds_15917)->length;
    }
    else {
        _9197 = 1;
    }
    {
        int _i_16137;
        Ref(_9196);
        _i_16137 = _9196;
L28: 
        if (binary_op_a(GREATER, _i_16137, _9197)){
            goto L29; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_15917);
        if (!IS_ATOM_INT(_i_16137)){
            _9198 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_16137)->dbl));
        }
        else{
            _9198 = (int)*(((s1_ptr)_2)->base + _i_16137);
        }
        Ref(_parsed_opts_15981);
        RefDS(_31EXTRAS_15217);
        Ref(_9198);
        _33put(_parsed_opts_15981, _31EXTRAS_15217, _9198, 6, _33threshold_size_12820);
        _9198 = NOVALUE;

        /** 				end for*/
        _0 = _i_16137;
        if (IS_ATOM_INT(_i_16137)) {
            _i_16137 = _i_16137 + 1;
            if ((long)((unsigned long)_i_16137 +(unsigned long) HIGH_BITS) >= 0){
                _i_16137 = NewDouble((double)_i_16137);
            }
        }
        else {
            _i_16137 = binary_op_a(PLUS, _i_16137, 1);
        }
        DeRef(_0);
        goto L28; // [1197] 1178
L29: 
        ;
        DeRef(_i_16137);
    }

    /** 				exit*/
    goto L14; // [1204] 2072
    goto L2A; // [1206] 1214

    /** 				continue*/
    goto L13; // [1211] 532
L2A: 
L27: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_15921 == _6651)
    _9199 = 1;
    else if (IS_ATOM_INT(_cmd_15921) && IS_ATOM_INT(_6651))
    _9199 = 0;
    else
    _9199 = (compare(_cmd_15921, _6651) == 0);
    if (_9199 == 0)
    {
        _9199 = NOVALUE;
        goto L2B; // [1221] 1234
    }
    else{
        _9199 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_15920 = 1;

    /** 			continue*/
    goto L13; // [1231] 532
L2B: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_9200;
    RHS_Slice(_cmd_15921, 1, 2);
    if (_9200 == _6651)
    _9201 = 1;
    else if (IS_ATOM_INT(_9200) && IS_ATOM_INT(_6651))
    _9201 = 0;
    else
    _9201 = (compare(_9200, _6651) == 0);
    DeRefDS(_9200);
    _9200 = NOVALUE;
    if (_9201 == 0)
    {
        _9201 = NOVALUE;
        goto L2C; // [1245] 1262
    }
    else{
        _9201 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_6651);
    DeRef(_type__15924);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _6651;
    _type__15924 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__15925 = 3;
    goto L2D; // [1259] 1298
L2C: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_15921);
    _9203 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9203, 45)){
        _9203 = NOVALUE;
        goto L2E; // [1268] 1286
    }
    _9203 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_7870);
    DeRef(_type__15924);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _7870;
    _type__15924 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__15925 = 2;
    goto L2D; // [1283] 1298
L2E: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_3761);
    DeRef(_type__15924);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _3761;
    _type__15924 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__15925 = 2;
L2D: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9207 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9207 = 1;
    }
    rhs_slice_target = (object_ptr)&_9208;
    RHS_Slice(_cmd_15921, _from__15925, _9207);
    _9209 = find_from(_9208, _help_opts_15926, 1);
    DeRefDS(_9208);
    _9208 = NOVALUE;
    if (_9209 == 0)
    {
        _9209 = NOVALUE;
        goto L2F; // [1315] 1335
    }
    else{
        _9209 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15915);
    Ref(_add_help_rid_15928);
    RefDS(_cmds_15917);
    Ref(_parse_options_15916);
    _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _31local_abort(0);
L2F: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_15921)){
            _9210 = SEQ_PTR(_cmd_15921)->length;
    }
    else {
        _9210 = 1;
    }
    rhs_slice_target = (object_ptr)&_9211;
    RHS_Slice(_cmd_15921, _from__15925, _9210);
    RefDS(_opts_15915);
    RefDS(_type__15924);
    _0 = _find_result_15923;
    _find_result_15923 = _31find_opt(_opts_15915, _type__15924, _9211);
    DeRef(_0);
    _9211 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9213 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _9213, 0)){
        _9213 = NOVALUE;
        goto L30; // [1361] 1370
    }
    _9213 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L13; // [1367] 532
L30: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9215 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _9215, 0)){
        _9215 = NOVALUE;
        goto L31; // [1376] 1471
    }
    _9215 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _9217 = (_validation_15929 == 2);
    if (_9217 != 0) {
        goto L32; // [1386] 1411
    }
    _9219 = (_validation_15929 == 4);
    if (_9219 == 0) {
        DeRef(_9220);
        _9220 = 0;
        goto L33; // [1394] 1406
    }
    _9221 = (_has_extra_15930 == 0);
    _9220 = (_9221 != 0);
L33: 
    if (_9220 == 0)
    {
        _9220 = NOVALUE;
        goto L13; // [1407] 532
    }
    else{
        _9220 = NOVALUE;
    }
L32: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9223 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_9223);
    RefDS(_cmd_15921);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_15921;
    ((int *)_2)[2] = _9223;
    _9224 = MAKE_SEQ(_1);
    _9223 = NOVALUE;
    EPrintf(1, _9222, _9224);
    DeRefDS(_9224);
    _9224 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_15933 == 0)
    {
        goto L34; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15915);
    Ref(_add_help_rid_15928);
    RefDS(_cmds_15917);
    Ref(_parse_options_15916);
    _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
    goto L35; // [1444] 1460
L34: 

    /** 				elsif auto_help then*/
    if (_auto_help_15932 == 0)
    {
        goto L36; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _9123, _5);
L36: 
L35: 

    /** 				local_abort(1)*/
    _31local_abort(1);

    /** 			continue*/
    goto L13; // [1468] 532
L31: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9225 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_16178);
    _2 = (int)SEQ_PTR(_opts_15915);
    if (!IS_ATOM_INT(_9225)){
        _opt_16178 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_9225)->dbl));
    }
    else{
        _opt_16178 = (int)*(((s1_ptr)_2)->base + _9225);
    }
    Ref(_opt_16178);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_16181 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9227 = (int)*(((s1_ptr)_2)->base + 4);
    _9228 = find_from(112, _9227, 1);
    _9227 = NOVALUE;
    if (_9228 == 0)
    goto L37; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_16181 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_15923)){
            _9230 = SEQ_PTR(_find_result_15923)->length;
    }
    else {
        _9230 = 1;
    }
    if (_9230 >= 4)
    goto L38; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_15919 = _arg_idx_15919 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_15917)){
            _9233 = SEQ_PTR(_cmds_15917)->length;
    }
    else {
        _9233 = 1;
    }
    if (_arg_idx_15919 > _9233)
    goto L39; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_15922);
    _2 = (int)SEQ_PTR(_cmds_15917);
    _param_15922 = (int)*(((s1_ptr)_2)->base + _arg_idx_15919);
    Ref(_param_15922);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_15922)){
            _9236 = SEQ_PTR(_param_15922)->length;
    }
    else {
        _9236 = 1;
    }
    _9237 = (_9236 == 2);
    _9236 = NOVALUE;
    if (_9237 == 0) {
        goto L3A; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_15922);
    _9239 = (int)*(((s1_ptr)_2)->base + 1);
    _9240 = find_from(_9239, _8536, 1);
    _9239 = NOVALUE;
    if (_9240 == 0)
    {
        _9240 = NOVALUE;
        goto L3A; // [1561] 1579
    }
    else{
        _9240 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_15922);
    _param_15922 = _5;
    goto L3A; // [1570] 1579
L39: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_15922);
    _param_15922 = _5;
L3A: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_15922)){
            _9241 = SEQ_PTR(_param_15922)->length;
    }
    else {
        _9241 = 1;
    }
    _9242 = (_9241 == 0);
    _9241 = NOVALUE;
    if (_9242 == 0) {
        goto L3B; // [1590] 1684
    }
    _9244 = (_validation_15929 == 2);
    if (_9244 != 0) {
        DeRef(_9245);
        _9245 = 1;
        goto L3C; // [1598] 1610
    }
    _9246 = (_validation_15929 == 4);
    _9245 = (_9246 != 0);
L3C: 
    if (_9245 == 0)
    {
        _9245 = NOVALUE;
        goto L3B; // [1611] 1684
    }
    else{
        _9245 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9248 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9248);
    *((int *)(_2+4)) = _9248;
    _9249 = MAKE_SEQ(_1);
    _9248 = NOVALUE;
    EPrintf(1, _9247, _9249);
    DeRefDS(_9249);
    _9249 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_15933 == 0)
    {
        goto L3D; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15915);
    Ref(_add_help_rid_15928);
    RefDS(_cmds_15917);
    Ref(_parse_options_15916);
    _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
    goto L3E; // [1642] 1658
L3D: 

    /** 					elsif auto_help then*/
    if (_auto_help_15932 == 0)
    {
        goto L3F; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _9123, _5);
L3F: 
L3E: 

    /** 					local_abort(1)*/
    _31local_abort(1);
    goto L3B; // [1664] 1684
L38: 

    /** 				param = find_result[4]*/
    DeRef(_param_15922);
    _2 = (int)SEQ_PTR(_find_result_15923);
    _param_15922 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15922);
    goto L3B; // [1674] 1684
L37: 

    /** 			param = find_result[4]*/
    DeRef(_param_15922);
    _2 = (int)SEQ_PTR(_find_result_15923);
    _param_15922 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_15922);
L3B: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9252 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _9252, 0)){
        _9252 = NOVALUE;
        goto L40; // [1690] 1763
    }
    _9252 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _pos_16220 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_16220))
    _pos_16220 = (long)DBL_PTR(_pos_16220)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_15927);
    _9255 = (int)*(((s1_ptr)_2)->base + _pos_16220);
    if (IS_ATOM_INT(_9255)) {
        _9256 = _9255 + 1;
        if (_9256 > MAXINT){
            _9256 = NewDouble((double)_9256);
        }
    }
    else
    _9256 = binary_op(PLUS, 1, _9255);
    _9255 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_15927);
    _2 = (int)(((s1_ptr)_2)->base + _pos_16220);
    _1 = *(int *)_2;
    *(int *)_2 = _9256;
    if( _1 != _9256 ){
        DeRef(_1);
    }
    _9256 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9257 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9258 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_15927);
    _9259 = (int)*(((s1_ptr)_2)->base + _pos_16220);
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9260 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9258);
    *((int *)(_2+4)) = _9258;
    Ref(_9259);
    *((int *)(_2+8)) = _9259;
    Ref(_param_15922);
    *((int *)(_2+12)) = _param_15922;
    Ref(_9260);
    *((int *)(_2+16)) = _9260;
    _9261 = MAKE_SEQ(_1);
    _9260 = NOVALUE;
    _9259 = NOVALUE;
    _9258 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9261;
    _9262 = MAKE_SEQ(_1);
    _9261 = NOVALUE;
    _1 = (int)SEQ_PTR(_9262);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_9257].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_9263);
    _9263 = _1;
    DeRefDS(_9262);
    _9262 = NOVALUE;
    if (binary_op_a(NOTEQ, _9263, 0)){
        DeRef(_9263);
        _9263 = NOVALUE;
        goto L41; // [1749] 1762
    }
    DeRef(_9263);
    _9263 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_16178);
    _opt_16178 = NOVALUE;
    goto L13; // [1759] 532
L41: 
L40: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9265 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _9265, 1)){
        _9265 = NOVALUE;
        goto L42; // [1771] 1788
    }
    _9265 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9267 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15981);
    Ref(_9267);
    _33remove(_parsed_opts_15981, _9267);
    _9267 = NOVALUE;
    goto L43; // [1785] 1965
L42: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9268 = (int)*(((s1_ptr)_2)->base + 4);
    _9269 = find_from(42, _9268, 1);
    _9268 = NOVALUE;
    if (_9269 != 0)
    goto L44; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9271 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15981);
    Ref(_9271);
    _9272 = _33has(_parsed_opts_15981, _9271);
    _9271 = NOVALUE;
    if (IS_ATOM_INT(_9272)) {
        if (_9272 == 0) {
            goto L45; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_9272)->dbl == 0.0) {
            goto L45; // [1814] 1925
        }
    }
    _9274 = (_validation_15929 == 2);
    if (_9274 != 0) {
        DeRef(_9275);
        _9275 = 1;
        goto L46; // [1822] 1834
    }
    _9276 = (_validation_15929 == 4);
    _9275 = (_9276 != 0);
L46: 
    if (_9275 == 0)
    {
        _9275 = NOVALUE;
        goto L45; // [1835] 1925
    }
    else{
        _9275 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9277 = (int)*(((s1_ptr)_2)->base + 4);
    _9278 = find_from(112, _9277, 1);
    _9277 = NOVALUE;
    if (_9278 != 0) {
        goto L47; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_16178);
    _9280 = (int)*(((s1_ptr)_2)->base + 4);
    _9281 = find_from(49, _9280, 1);
    _9280 = NOVALUE;
    if (_9281 == 0)
    {
        _9281 = NOVALUE;
        goto L48; // [1863] 1964
    }
    else{
        _9281 = NOVALUE;
    }
L47: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_15923);
    _9283 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9283);
    *((int *)(_2+4)) = _9283;
    _9284 = MAKE_SEQ(_1);
    _9283 = NOVALUE;
    EPrintf(1, _9282, _9284);
    DeRefDS(_9284);
    _9284 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_15933 == 0)
    {
        goto L49; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_15915);
    Ref(_add_help_rid_15928);
    RefDS(_cmds_15917);
    Ref(_parse_options_15916);
    _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
    goto L4A; // [1900] 1916
L49: 

    /** 						elsif auto_help then*/
    if (_auto_help_15932 == 0)
    {
        goto L4B; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _9123, _5);
L4B: 
L4A: 

    /** 						local_abort(1)*/
    _31local_abort(1);
    goto L48; // [1922] 1964
L45: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9285 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15981);
    Ref(_9285);
    Ref(_param_15922);
    _33put(_parsed_opts_15981, _9285, _param_15922, 1, _33threshold_size_12820);
    _9285 = NOVALUE;
    goto L48; // [1943] 1964
L44: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9286 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_15981);
    Ref(_9286);
    Ref(_param_15922);
    _33put(_parsed_opts_15981, _9286, _param_15922, _map_add_operation_16181, _33threshold_size_12820);
    _9286 = NOVALUE;
L48: 
L43: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9287 = (int)*(((s1_ptr)_2)->base + 4);
    _9288 = find_from(118, _9287, 1);
    _9287 = NOVALUE;
    if (_9288 == 0)
    {
        _9288 = NOVALUE;
        goto L4C; // [1976] 2063
    }
    else{
        _9288 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9289 = (int)*(((s1_ptr)_2)->base + 4);
    _9290 = find_from(118, _9289, 1);
    _9289 = NOVALUE;
    _ver_pos_16267 = _9290 + 1;
    _9290 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9292 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_9292)){
            _9293 = SEQ_PTR(_9292)->length;
    }
    else {
        _9293 = 1;
    }
    _9292 = NOVALUE;
    if (_9293 < _ver_pos_16267)
    goto L4D; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_16178);
    _9296 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_9296);
    _9297 = (int)*(((s1_ptr)_2)->base + _ver_pos_16267);
    _9296 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_9297);
    *((int *)(_2+4)) = _9297;
    _9298 = MAKE_SEQ(_1);
    _9297 = NOVALUE;
    EPrintf(1, _9295, _9298);
    DeRefDS(_9298);
    _9298 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4E; // [2029] 2062
L4D: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_9301, _9299, _9300);
    DeRefi(_fmt_inlined_crash_at_2037_16284);
    _fmt_inlined_crash_at_2037_16284 = _9301;
    _9301 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_16285);
    _msg_inlined_crash_at_2040_16285 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_16284, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_16285);

    /** end procedure*/
    goto L4F; // [2056] 2059
L4F: 
    DeRefi(_fmt_inlined_crash_at_2037_16284);
    _fmt_inlined_crash_at_2037_16284 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_16285);
    _msg_inlined_crash_at_2040_16285 = NOVALUE;
L4E: 
L4C: 
    DeRef(_opt_16178);
    _opt_16178 = NOVALUE;

    /** 	end while*/
    goto L13; // [2069] 532
L14: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_15915)){
            _9302 = SEQ_PTR(_opts_15915)->length;
    }
    else {
        _9302 = 1;
    }
    {
        int _i_16287;
        _i_16287 = 1;
L50: 
        if (_i_16287 > _9302){
            goto L51; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9303 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9303);
        _9304 = (int)*(((s1_ptr)_2)->base + 4);
        _9303 = NOVALUE;
        _9305 = find_from(109, _9304, 1);
        _9304 = NOVALUE;
        if (_9305 == 0)
        {
            _9305 = NOVALUE;
            goto L52; // [2099] 2285
        }
        else{
            _9305 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9306 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9306);
        _9307 = (int)*(((s1_ptr)_2)->base + 1);
        _9306 = NOVALUE;
        _9308 = IS_ATOM(_9307);
        _9307 = NOVALUE;
        if (_9308 == 0) {
            goto L53; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_15915);
        _9310 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9310);
        _9311 = (int)*(((s1_ptr)_2)->base + 2);
        _9310 = NOVALUE;
        _9312 = IS_ATOM(_9311);
        _9311 = NOVALUE;
        if (_9312 == 0)
        {
            _9312 = NOVALUE;
            goto L53; // [2131] 2206
        }
        else{
            _9312 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9313 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9313);
        _9314 = (int)*(((s1_ptr)_2)->base + 6);
        _9313 = NOVALUE;
        Ref(_parsed_opts_15981);
        Ref(_9314);
        _9315 = _33get(_parsed_opts_15981, _9314, 0);
        _9314 = NOVALUE;
        if (IS_SEQUENCE(_9315)){
                _9316 = SEQ_PTR(_9315)->length;
        }
        else {
            _9316 = 1;
        }
        DeRef(_9315);
        _9315 = NOVALUE;
        if (_9316 != 0)
        goto L54; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _9318); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_15933 == 0)
        {
            goto L55; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15915);
        Ref(_add_help_rid_15928);
        RefDS(_cmds_15917);
        Ref(_parse_options_15916);
        _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
        goto L56; // [2181] 2197
L55: 

        /** 					elsif auto_help then*/
        if (_auto_help_15932 == 0)
        {
            goto L57; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _9123, _5);
L57: 
L56: 

        /** 					local_abort(1)*/
        _31local_abort(1);
        goto L54; // [2203] 2284
L53: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9319 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9319);
        _9320 = (int)*(((s1_ptr)_2)->base + 6);
        _9319 = NOVALUE;
        Ref(_parsed_opts_15981);
        Ref(_9320);
        _9321 = _33has(_parsed_opts_15981, _9320);
        _9320 = NOVALUE;
        if (IS_ATOM_INT(_9321)) {
            if (_9321 != 0){
                DeRef(_9321);
                _9321 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_9321)->dbl != 0.0){
                DeRef(_9321);
                _9321 = NOVALUE;
                goto L58; // [2221] 2283
            }
        }
        DeRef(_9321);
        _9321 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_15915);
        _9324 = (int)*(((s1_ptr)_2)->base + _i_16287);
        _2 = (int)SEQ_PTR(_9324);
        _9325 = (int)*(((s1_ptr)_2)->base + 6);
        _9324 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_9325);
        *((int *)(_2+4)) = _9325;
        _9326 = MAKE_SEQ(_1);
        _9325 = NOVALUE;
        EPrintf(1, _9323, _9326);
        DeRefDS(_9326);
        _9326 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_15933 == 0)
        {
            goto L59; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_15915);
        Ref(_add_help_rid_15928);
        RefDS(_cmds_15917);
        Ref(_parse_options_15916);
        _31local_help(_opts_15915, _add_help_rid_15928, _cmds_15917, 1, _parse_options_15916);
        goto L5A; // [2261] 2277
L59: 

        /** 					elsif auto_help then*/
        if (_auto_help_15932 == 0)
        {
            goto L5B; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _9123, _5);
L5B: 
L5A: 

        /** 					local_abort(1)*/
        _31local_abort(1);
L58: 
L54: 
L52: 

        /** 	end for*/
        _i_16287 = _i_16287 + 1;
        goto L50; // [2287] 2084
L51: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_15915);
    DeRef(_parse_options_15916);
    DeRefDS(_cmds_15917);
    DeRef(_cmd_15921);
    DeRef(_param_15922);
    DeRef(_find_result_15923);
    DeRef(_type__15924);
    DeRef(_help_opts_15926);
    DeRef(_call_count_15927);
    DeRef(_add_help_rid_15928);
    DeRef(_9144);
    _9144 = NOVALUE;
    _9174 = NOVALUE;
    DeRef(_9219);
    _9219 = NOVALUE;
    DeRef(_9272);
    _9272 = NOVALUE;
    DeRef(_9172);
    _9172 = NOVALUE;
    DeRef(_9196);
    _9196 = NOVALUE;
    _9292 = NOVALUE;
    DeRef(_9217);
    _9217 = NOVALUE;
    DeRef(_9242);
    _9242 = NOVALUE;
    _9129 = NOVALUE;
    DeRef(_9163);
    _9163 = NOVALUE;
    DeRef(_9102);
    _9102 = NOVALUE;
    DeRef(_9142);
    _9142 = NOVALUE;
    DeRef(_9167);
    _9167 = NOVALUE;
    DeRef(_9105);
    _9105 = NOVALUE;
    _9225 = NOVALUE;
    DeRef(_9237);
    _9237 = NOVALUE;
    DeRef(_9134);
    _9134 = NOVALUE;
    DeRef(_9132);
    _9132 = NOVALUE;
    _9158 = NOVALUE;
    DeRef(_9274);
    _9274 = NOVALUE;
    DeRef(_9276);
    _9276 = NOVALUE;
    _9315 = NOVALUE;
    DeRef(_9156);
    _9156 = NOVALUE;
    DeRef(_9179);
    _9179 = NOVALUE;
    DeRef(_9244);
    _9244 = NOVALUE;
    DeRef(_9191);
    _9191 = NOVALUE;
    DeRef(_9151);
    _9151 = NOVALUE;
    DeRef(_9246);
    _9246 = NOVALUE;
    DeRef(_9221);
    _9221 = NOVALUE;
    _9257 = NOVALUE;
    DeRef(_9194);
    _9194 = NOVALUE;
    return _parsed_opts_15981;
    ;
}
int cmd_parse() __attribute__ ((alias ("_31cmd_parse")));


int _31build_commandline(int _cmds_16324)
{
    int _9329 = NOVALUE;
    int _9328 = NOVALUE;
    int _9327 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_5475);
    RefDS(_5475);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5475;
    ((int *)_2)[2] = _5475;
    _9327 = MAKE_SEQ(_1);
    RefDS(_cmds_16324);
    RefDS(_3319);
    _9328 = _6quote(_cmds_16324, _9327, 92, _3319);
    _9327 = NOVALUE;
    RefDS(_3319);
    _9329 = _23flatten(_9328, _3319);
    _9328 = NOVALUE;
    DeRefDS(_cmds_16324);
    return _9329;
    ;
}
int build_commandline() __attribute__ ((alias ("_31build_commandline")));


int _31parse_commandline(int _cmdline_16330)
{
    int _9330 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return keyvalues(cmdline, " ", ":=", "\"'`", " \t\r\n", 0)*/
    RefDS(_cmdline_16330);
    RefDS(_3319);
    RefDS(_5299);
    RefDS(_5300);
    RefDS(_4498);
    _9330 = _6keyvalues(_cmdline_16330, _3319, _5299, _5300, _4498, 0);
    DeRefDS(_cmdline_16330);
    return _9330;
    ;
}
int parse_commandline() __attribute__ ((alias ("_31parse_commandline")));



// 0x8A80DA11
