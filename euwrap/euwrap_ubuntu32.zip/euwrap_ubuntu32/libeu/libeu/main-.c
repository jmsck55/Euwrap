// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include <time.h>
#include "include/euphoria.h"
#include "main-.h"

#include <unistd.h>


int Argc;
char **Argv;
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned short *poke2_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
int total_stack_size = 262144;

void __attribute__ ((constructor)) eu_init()
{
    s1_ptr _0switch_ptr;
    int _13025 = 0;
    int _13023 = 0;
    int _12766 = 0;
    int _12765 = 0;
    int _12764 = 0;
    int _11941 = 0;
    int _11939 = 0;
    int _11937 = 0;
    int _11935 = 0;
    int _11933 = 0;
    int _11931 = 0;
    int _11929 = 0;
    int _11927 = 0;
    int _11925 = 0;
    int _11923 = 0;
    int _11921 = 0;
    int _11919 = 0;
    int _11917 = 0;
    int _11915 = 0;
    int _11913 = 0;
    int _11911 = 0;
    int _11909 = 0;
    int _11907 = 0;
    int _11905 = 0;
    int _11903 = 0;
    int _11902 = 0;
    int _11900 = 0;
    int _11898 = 0;
    int _11896 = 0;
    int _11894 = 0;
    int _11875 = 0;
    int _11873 = 0;
    int _11871 = 0;
    int _11869 = 0;
    int _11867 = 0;
    int _11865 = 0;
    int _11863 = 0;
    int _11861 = 0;
    int _11859 = 0;
    int _11857 = 0;
    int _11855 = 0;
    int _11853 = 0;
    int _11851 = 0;
    int _11849 = 0;
    int _11847 = 0;
    int _11845 = 0;
    int _11843 = 0;
    int _11841 = 0;
    int _11839 = 0;
    int _11837 = 0;
    int _11835 = 0;
    int _11833 = 0;
    int _11831 = 0;
    int _11829 = 0;
    int _11827 = 0;
    int _11825 = 0;
    int _11823 = 0;
    int _11821 = 0;
    int _11819 = 0;
    int _11660 = 0;
    int _11657 = 0;
    int _11652 = 0;
    int _11649 = 0;
    int _11646 = 0;
    int _11643 = 0;
    int _11640 = 0;
    int _11637 = 0;
    int _11634 = 0;
    int _11480 = 0;
    int _11478 = 0;
    int _11476 = 0;
    int _9400 = 0;
    int _9398 = 0;
    int _9396 = 0;
    int _9394 = 0;
    int _9392 = 0;
    int _8573 = 0;
    int _6309 = 0;
    int _6159 = 0;
    int _4809 = 0;
    int _4807 = 0;
    int _4805 = 0;
    int _4803 = 0;
    int _4801 = 0;
    int _3752 = 0;
    int _3749 = 0;
    int _3746 = 0;
    int _3743 = 0;
    int _3740 = 0;
    int _3736 = 0;
    int _3607 = 0;
    int _1636 = 0;
    int _1635 = 0;
    int _1633 = 0;
    int _1631 = 0;
    int _964 = 0;
    int _946 = 0;
    int _944 = 0;
    int _17 = 0;
    int _0, _1, _2;
    
    
    Argc = 0;

    _02 = (unsigned char**) malloc( 4 * 60 );
    _02[0] = (unsigned char*) malloc( 4 );
    _02[0][0] = 59;
    _02[1] = "\x01\x02\x03\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04"
"\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x04\x03\x00";
    _02[2] = "\x02\x00\x02\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07"
"\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x07\x00\x00";
    _02[3] = "\x03\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[4] = "\x04\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[5] = "\x05\x00\x00\x00\x03\x02\x03\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[6] = "\x06\x00\x00\x00\x00\x00\x03\x03\x03\x03\x03\x03\x01\x01\x01"
"\x03\x03\x00\x03\x01\x03\x07\x07\x03\x01\x01\x03\x03\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[7] = "\x07\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[8] = "\x08\x00\x00\x00\x00\x00\x03\x03\x03\x03\x01\x01\x01\x01\x01"
"\x01\x01\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[9] = "\x09\x00\x00\x00\x00\x00\x00\x03\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[10] = "\x0A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[11] = "\x0B\x00\x00\x00\x00\x00\x03\x03\x01\x03\x01\x03\x03\x03\x03"
"\x07\x07\x03\x03\x03\x03\x05\x05\x03\x03\x03\x01\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[12] = "\x0C\x00\x00\x00\x00\x00\x00\x03\x00\x00\x01\x00\x02\x03\x03"
"\x07\x07\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[13] = "\x0D\x00\x00\x00\x00\x00\x00\x03\x00\x00\x03\x00\x00\x03\x03"
"\x05\x05\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[14] = "\x0E\x00\x00\x00\x00\x00\x00\x03\x00\x00\x03\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[15] = "\x0F\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[16] = "\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x07\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[17] = "\x11\x00\x00\x00\x00\x00\x01\x01\x01\x01\x03\x01\x01\x01\x01"
"\x01\x01\x02\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[18] = "\x12\x00\x00\x00\x00\x00\x03\x03\x01\x03\x03\x01\x01\x01\x03"
"\x07\x07\x00\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[19] = "\x13\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[20] = "\x14\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x07\x07\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[21] = "\x15\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[22] = "\x16\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[23] = "\x17\x00\x00\x00\x00\x00\x00\x03\x00\x03\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[24] = "\x18\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[25] = "\x19\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[26] = "\x1A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[27] = "\x1B\x00\x00\x00\x00\x00\x01\x01\x03\x01\x03\x01\x01\x03\x03"
"\x07\x07\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x02\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[28] = "\x1C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[29] = "\x1D\x00\x00\x00\x03\x00\x01\x01\x03\x01\x01\x01\x01\x01\x01"
"\x03\x03\x00\x03\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x02"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[30] = "\x1E\x00\x00\x00\x00\x00\x00\x01\x00\x03\x01\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x03\x01\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[31] = "\x1F\x00\x00\x01\x00\x00\x03\x03\x01\x01\x03\x01\x01\x01\x01"
"\x03\x03\x01\x03\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x00\x02\x03\x03\x01\x01\x04\x03\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[32] = "\x20\x00\x00\x00\x00\x00\x03\x03\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x03\x01\x01\x01\x03\x03\x01\x01\x01\x03\x01\x01\x00"
"\x00\x00\x02\x03\x01\x01\x07\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[33] = "\x21\x00\x00\x03\x00\x00\x03\x03\x01\x03\x03\x01\x03\x01\x01"
"\x03\x03\x03\x03\x03\x03\x07\x07\x01\x03\x01\x03\x03\x03\x00"
"\x00\x00\x00\x02\x03\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[34] = "\x22\x00\x00\x00\x00\x00\x00\x01\x00\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[35] = "\x23\x00\x00\x00\x00\x00\x00\x01\x00\x01\x01\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x03\x03\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[36] = "\x24\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[37] = "\x25\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x01\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[38] = "\x26\x00\x00\x00\x00\x00\x03\x03\x03\x01\x03\x03\x03\x01\x03"
"\x07\x07\x01\x03\x01\x03\x07\x07\x01\x01\x01\x03\x01\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[39] = "\x27\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x01\x01\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x00\x02\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[40] = "\x28\x00\x00\x00\x00\x00\x01\x03\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x07\x01\x01\x01\x07\x00\x00\x00\x02\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[41] = "\x29\x00\x00\x00\x00\x00\x01\x01\x03\x01\x01\x01\x01\x01\x01"
"\x01\x01\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x07\x00\x00\x00\x00\x02\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[42] = "\x2A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[43] = "\x2B\x00\x00\x01\x00\x00\x03\x03\x01\x03\x01\x03\x03\x03\x03"
"\x07\x07\x01\x03\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x03\x00\x00\x00\x03\x02\x03"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[44] = "\x2C\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[45] = "\x2D\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[46] = "\x2E\x00\x00\x00\x00\x00\x00\x01\x00\x00\x03\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[47] = "\x2F\x00\x00\x01\x00\x00\x03\x03\x01\x03\x01\x01\x01\x01\x03"
"\x07\x07\x01\x01\x01\x03\x07\x07\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x03\x00\x00\x00\x00\x00"
"\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[48] = "\x30\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x03"
"\x07\x07\x01\x01\x01\x01\x01\x01\x03\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x01\x02\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[49] = "\x31\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x03\x03\x03\x01\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x03\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[50] = "\x32\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x03\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[51] = "\x33\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00\x00";
    _02[52] = "\x34\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00\x00";
    _02[53] = "\x35\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00\x00\x00";
    _02[54] = "\x36\x00\x00\x03\x00\x00\x03\x03\x03\x01\x01\x01\x01\x01\x01"
"\x03\x03\x01\x01\x01\x01\x03\x03\x03\x01\x01\x01\x01\x01\x00"
"\x03\x00\x00\x01\x01\x01\x00\x00\x00\x01\x00\x00\x00\x00\x00"
"\x00\x00\x01\x03\x01\x00\x00\x00\x03\x02\x03\x00\x00\x00\x00";
    _02[55] = "\x37\x00\x00\x01\x00\x00\x01\x01\x01\x01\x01\x01\x01\x01\x01"
"\x01\x01\x03\x01\x01\x01\x03\x03\x01\x01\x01\x01\x01\x01\x00"
"\x00\x00\x00\x03\x01\x01\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00\x00";
    _02[56] = "\x38\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x03\x03"
"\x07\x07\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00\x00";
    _02[57] = "\x39\x00\x00\x00\x00\x00\x00\x01\x00\x00\x01\x00\x00\x03\x01"
"\x03\x03\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x00\x00";
    _02[58] = "\x3A\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02\x03";
    _02[59] = "\x3B\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"
"\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x02";

#ifdef CLK_TCK
    eu_startup(_00, _01, _02, (int)CLOCKS_PER_SEC, (int)CLK_TCK);
#else
    eu_startup(_00, _01, _02, (int)CLOCKS_PER_SEC, (int)sysconf(_SC_CLK_TCK));
#endif
    _0switch_ptr = (s1_ptr) NewS1( 4 );
    _0switch_ptr->base[1] = NewString("-keep    ");
    _0switch_ptr->base[2] = NewString("-dll    ");
    _0switch_ptr->base[3] = NewString("-i    ");
    _0switch_ptr->base[4] = NewString("/usr/share/euphoria/include    ");
    _0switches = MAKE_SEQ( _0switch_ptr );

    init_literal();
    _3version_info_163 = machine(75, _5);
    _2 = (int)SEQ_PTR(_3version_info_163);
    _17 = (int)*(((s1_ptr)_2)->base + 4);
    if (_17 == _18)
    _3is_developmental_165 = 1;
    else if (IS_ATOM_INT(_17) && IS_ATOM_INT(_18))
    _3is_developmental_165 = 0;
    else
    _3is_developmental_165 = (compare(_17, _18) == 0);
    _17 = NOVALUE;
    _3is_release_169 = (_3is_developmental_165 == 0);
    _1 = NewS1(45);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_94);
    *((int *)(_2+4)) = _94;
    RefDS(_95);
    *((int *)(_2+8)) = _95;
    RefDS(_96);
    *((int *)(_2+12)) = _96;
    RefDS(_97);
    *((int *)(_2+16)) = _97;
    RefDS(_98);
    *((int *)(_2+20)) = _98;
    RefDS(_99);
    *((int *)(_2+24)) = _99;
    RefDS(_100);
    *((int *)(_2+28)) = _100;
    RefDS(_101);
    *((int *)(_2+32)) = _101;
    RefDS(_102);
    *((int *)(_2+36)) = _102;
    RefDS(_103);
    *((int *)(_2+40)) = _103;
    RefDS(_104);
    *((int *)(_2+44)) = _104;
    RefDS(_105);
    *((int *)(_2+48)) = _105;
    RefDS(_106);
    *((int *)(_2+52)) = _106;
    RefDS(_107);
    *((int *)(_2+56)) = _107;
    RefDS(_108);
    *((int *)(_2+60)) = _108;
    RefDS(_109);
    *((int *)(_2+64)) = _109;
    RefDS(_110);
    *((int *)(_2+68)) = _110;
    RefDS(_111);
    *((int *)(_2+72)) = _111;
    RefDS(_112);
    *((int *)(_2+76)) = _112;
    RefDS(_113);
    *((int *)(_2+80)) = _113;
    RefDS(_114);
    *((int *)(_2+84)) = _114;
    RefDS(_115);
    *((int *)(_2+88)) = _115;
    RefDS(_116);
    *((int *)(_2+92)) = _116;
    RefDS(_117);
    *((int *)(_2+96)) = _117;
    RefDS(_118);
    *((int *)(_2+100)) = _118;
    RefDS(_119);
    *((int *)(_2+104)) = _119;
    RefDS(_120);
    *((int *)(_2+108)) = _120;
    RefDS(_121);
    *((int *)(_2+112)) = _121;
    RefDS(_122);
    *((int *)(_2+116)) = _122;
    RefDS(_123);
    *((int *)(_2+120)) = _123;
    RefDS(_124);
    *((int *)(_2+124)) = _124;
    RefDS(_125);
    *((int *)(_2+128)) = _125;
    RefDS(_126);
    *((int *)(_2+132)) = _126;
    RefDS(_127);
    *((int *)(_2+136)) = _127;
    RefDS(_128);
    *((int *)(_2+140)) = _128;
    RefDS(_129);
    *((int *)(_2+144)) = _129;
    RefDS(_130);
    *((int *)(_2+148)) = _130;
    RefDS(_131);
    *((int *)(_2+152)) = _131;
    RefDS(_132);
    *((int *)(_2+156)) = _132;
    RefDS(_133);
    *((int *)(_2+160)) = _133;
    RefDS(_134);
    *((int *)(_2+164)) = _134;
    RefDS(_135);
    *((int *)(_2+168)) = _135;
    RefDS(_136);
    *((int *)(_2+172)) = _136;
    RefDS(_137);
    *((int *)(_2+176)) = _137;
    RefDS(_138);
    *((int *)(_2+180)) = _138;
    _4keywords_296 = MAKE_SEQ(_1);
    _1 = NewS1(88);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_140);
    *((int *)(_2+4)) = _140;
    RefDS(_141);
    *((int *)(_2+8)) = _141;
    RefDS(_142);
    *((int *)(_2+12)) = _142;
    RefDS(_143);
    *((int *)(_2+16)) = _143;
    RefDS(_144);
    *((int *)(_2+20)) = _144;
    RefDS(_145);
    *((int *)(_2+24)) = _145;
    RefDS(_146);
    *((int *)(_2+28)) = _146;
    RefDS(_147);
    *((int *)(_2+32)) = _147;
    RefDS(_148);
    *((int *)(_2+36)) = _148;
    RefDS(_149);
    *((int *)(_2+40)) = _149;
    RefDS(_150);
    *((int *)(_2+44)) = _150;
    RefDS(_151);
    *((int *)(_2+48)) = _151;
    RefDS(_152);
    *((int *)(_2+52)) = _152;
    RefDS(_153);
    *((int *)(_2+56)) = _153;
    RefDS(_154);
    *((int *)(_2+60)) = _154;
    RefDS(_155);
    *((int *)(_2+64)) = _155;
    RefDS(_156);
    *((int *)(_2+68)) = _156;
    RefDS(_157);
    *((int *)(_2+72)) = _157;
    RefDS(_158);
    *((int *)(_2+76)) = _158;
    RefDS(_159);
    *((int *)(_2+80)) = _159;
    RefDS(_160);
    *((int *)(_2+84)) = _160;
    RefDS(_161);
    *((int *)(_2+88)) = _161;
    RefDS(_162);
    *((int *)(_2+92)) = _162;
    RefDS(_163);
    *((int *)(_2+96)) = _163;
    RefDS(_164);
    *((int *)(_2+100)) = _164;
    RefDS(_165);
    *((int *)(_2+104)) = _165;
    RefDS(_166);
    *((int *)(_2+108)) = _166;
    RefDS(_167);
    *((int *)(_2+112)) = _167;
    RefDS(_168);
    *((int *)(_2+116)) = _168;
    RefDS(_169);
    *((int *)(_2+120)) = _169;
    RefDS(_170);
    *((int *)(_2+124)) = _170;
    RefDS(_171);
    *((int *)(_2+128)) = _171;
    RefDS(_172);
    *((int *)(_2+132)) = _172;
    RefDS(_173);
    *((int *)(_2+136)) = _173;
    RefDS(_174);
    *((int *)(_2+140)) = _174;
    RefDS(_175);
    *((int *)(_2+144)) = _175;
    RefDS(_176);
    *((int *)(_2+148)) = _176;
    RefDS(_177);
    *((int *)(_2+152)) = _177;
    RefDS(_178);
    *((int *)(_2+156)) = _178;
    RefDS(_179);
    *((int *)(_2+160)) = _179;
    RefDS(_180);
    *((int *)(_2+164)) = _180;
    RefDS(_181);
    *((int *)(_2+168)) = _181;
    RefDS(_182);
    *((int *)(_2+172)) = _182;
    RefDS(_183);
    *((int *)(_2+176)) = _183;
    RefDS(_184);
    *((int *)(_2+180)) = _184;
    RefDS(_185);
    *((int *)(_2+184)) = _185;
    RefDS(_186);
    *((int *)(_2+188)) = _186;
    RefDS(_187);
    *((int *)(_2+192)) = _187;
    RefDS(_188);
    *((int *)(_2+196)) = _188;
    RefDS(_189);
    *((int *)(_2+200)) = _189;
    RefDS(_190);
    *((int *)(_2+204)) = _190;
    RefDS(_191);
    *((int *)(_2+208)) = _191;
    RefDS(_192);
    *((int *)(_2+212)) = _192;
    RefDS(_193);
    *((int *)(_2+216)) = _193;
    RefDS(_194);
    *((int *)(_2+220)) = _194;
    RefDS(_195);
    *((int *)(_2+224)) = _195;
    RefDS(_196);
    *((int *)(_2+228)) = _196;
    RefDS(_197);
    *((int *)(_2+232)) = _197;
    RefDS(_198);
    *((int *)(_2+236)) = _198;
    RefDS(_199);
    *((int *)(_2+240)) = _199;
    RefDS(_200);
    *((int *)(_2+244)) = _200;
    RefDS(_201);
    *((int *)(_2+248)) = _201;
    RefDS(_202);
    *((int *)(_2+252)) = _202;
    RefDS(_203);
    *((int *)(_2+256)) = _203;
    RefDS(_204);
    *((int *)(_2+260)) = _204;
    RefDS(_205);
    *((int *)(_2+264)) = _205;
    RefDS(_206);
    *((int *)(_2+268)) = _206;
    RefDS(_207);
    *((int *)(_2+272)) = _207;
    RefDS(_208);
    *((int *)(_2+276)) = _208;
    RefDS(_209);
    *((int *)(_2+280)) = _209;
    RefDS(_210);
    *((int *)(_2+284)) = _210;
    RefDS(_211);
    *((int *)(_2+288)) = _211;
    RefDS(_212);
    *((int *)(_2+292)) = _212;
    RefDS(_213);
    *((int *)(_2+296)) = _213;
    RefDS(_214);
    *((int *)(_2+300)) = _214;
    RefDS(_215);
    *((int *)(_2+304)) = _215;
    RefDS(_216);
    *((int *)(_2+308)) = _216;
    RefDS(_217);
    *((int *)(_2+312)) = _217;
    RefDS(_218);
    *((int *)(_2+316)) = _218;
    RefDS(_219);
    *((int *)(_2+320)) = _219;
    RefDS(_220);
    *((int *)(_2+324)) = _220;
    RefDS(_221);
    *((int *)(_2+328)) = _221;
    RefDS(_222);
    *((int *)(_2+332)) = _222;
    RefDS(_223);
    *((int *)(_2+336)) = _223;
    RefDS(_224);
    *((int *)(_2+340)) = _224;
    RefDS(_225);
    *((int *)(_2+344)) = _225;
    RefDS(_226);
    *((int *)(_2+348)) = _226;
    RefDS(_227);
    *((int *)(_2+352)) = _227;
    _4builtins_343 = MAKE_SEQ(_1);
    _7FALSE_443 = (1 == 0);
    _7TRUE_445 = (1 == 1);

    /** set_default_charsets()*/
    _7set_default_charsets();
    _7INVALID_ROUTINE_ID_872 = CRoutineId(54, 7, _476);
    DeRef1(_8mem_1364);
    _8mem_1364 = machine(16, 4);
    _8decimal_mark_1528 = 46;

    /** ifdef WINDOWS then*/
    {unsigned long tu;
         tu = (unsigned long)1 | (unsigned long)4;
         _15PAGE_EXECUTE_READ_1817 = MAKE_UINT(tu);
    }
    {unsigned long tu;
         tu = (unsigned long)4 | (unsigned long)2;
         _944 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_944)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_944;
             _15PAGE_EXECUTE_READWRITE_1819 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)1;
        _15PAGE_EXECUTE_READWRITE_1819 = Dor_bits(&temp_d, DBL_PTR(_944));
    }
    DeRef1(_944);
    _944 = NOVALUE;
    {unsigned long tu;
         tu = (unsigned long)4 | (unsigned long)2;
         _946 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_946)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_946;
             _15PAGE_EXECUTE_WRITECOPY_1822 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)1;
        _15PAGE_EXECUTE_WRITECOPY_1822 = Dor_bits(&temp_d, DBL_PTR(_946));
    }
    DeRef1(_946);
    _946 = NOVALUE;
    {unsigned long tu;
         tu = (unsigned long)1 | (unsigned long)2;
         _15PAGE_WRITECOPY_1825 = MAKE_UINT(tu);
    }
    {unsigned long tu;
         tu = (unsigned long)1 | (unsigned long)2;
         _15PAGE_READWRITE_1827 = MAKE_UINT(tu);
    }
    Ref(_15PAGE_EXECUTE_READ_1817);
    _15PAGE_READ_EXECUTE_1832 = _15PAGE_EXECUTE_READ_1817;
    Ref(_15PAGE_READWRITE_1827);
    _15PAGE_READ_WRITE_1833 = _15PAGE_READWRITE_1827;
    Ref(_15PAGE_EXECUTE_READWRITE_1819);
    _15PAGE_READ_WRITE_EXECUTE_1835 = _15PAGE_EXECUTE_READWRITE_1819;
    Ref(_15PAGE_EXECUTE_WRITECOPY_1822);
    _15PAGE_WRITE_EXECUTE_COPY_1836 = _15PAGE_EXECUTE_WRITECOPY_1822;
    Ref(_15PAGE_WRITECOPY_1825);
    _15PAGE_WRITE_COPY_1837 = _15PAGE_WRITECOPY_1825;
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    Ref(_15PAGE_EXECUTE_READ_1817);
    *((int *)(_2+8)) = _15PAGE_EXECUTE_READ_1817;
    Ref(_15PAGE_EXECUTE_READWRITE_1819);
    *((int *)(_2+12)) = _15PAGE_EXECUTE_READWRITE_1819;
    Ref(_15PAGE_EXECUTE_WRITECOPY_1822);
    *((int *)(_2+16)) = _15PAGE_EXECUTE_WRITECOPY_1822;
    Ref(_15PAGE_WRITECOPY_1825);
    *((int *)(_2+20)) = _15PAGE_WRITECOPY_1825;
    Ref(_15PAGE_READWRITE_1827);
    *((int *)(_2+24)) = _15PAGE_READWRITE_1827;
    *((int *)(_2+28)) = 1;
    *((int *)(_2+32)) = 0;
    _15MEMORY_PROTECTION_1838 = MAKE_SEQ(_1);
    _15DEP_really_works_1864 = 0;
    _15use_DEP_1865 = 1;

    /** ifdef SAFE then*/
    _964 = power(2, 32);
    if (IS_ATOM_INT(_964)) {
        _16MAX_ADDR_1891 = _964 - 1;
        if ((long)((unsigned long)_16MAX_ADDR_1891 +(unsigned long) HIGH_BITS) >= 0){
            _16MAX_ADDR_1891 = NewDouble((double)_16MAX_ADDR_1891);
        }
    }
    else {
        _16MAX_ADDR_1891 = NewDouble(DBL_PTR(_964)->dbl - (double)1);
    }
    DeRef1(_964);
    _964 = NOVALUE;

    /** ifdef DATA_EXECUTE then*/

    /** memconst:FREE_RID = routine_id("deallocate")*/
    _15FREE_RID_1874 = CRoutineId(110, 16, _978);
    _16check_calls_1923 = 1;
    _16leader_1950 = Repeat(64, 0);
    _16trailer_1952 = Repeat(37, 0);
    _14page_size_2083 = 0;

    /** ifdef WINDOWS then*/
    RefDS(_1043);
    RefDS(_5);
    _14getpagesize_rid_2093 = _13define_c_func(-1, _1043, _5, 33554436);

    /** 	page_size = c_func( getpagesize_rid, {} )*/
    _14page_size_2083 = call_c(1, _14getpagesize_rid_2093, _5);
    if (!IS_ATOM_INT(_14page_size_2083)) {
        _1 = (long)(DBL_PTR(_14page_size_2083)->dbl);
        DeRefDS(_14page_size_2083);
        _14page_size_2083 = _1;
    }
    _14PAGE_SIZE_2099 = _14page_size_2083;

    /** ifdef WINDOWS then*/

    /** ifdef WINDOWS then*/

    /** memconst:FREE_RID = routine_id("free")*/
    _15FREE_RID_1874 = CRoutineId(136, 14, _1085);

    /** FREE_ARRAY_RID = routine_id("free_pointer_array")*/
    _14FREE_ARRAY_RID_1969 = CRoutineId(137, 14, _1089);

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_18mem0_2403);
    _18mem0_2403 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_18mem1_2404);
    if (IS_ATOM_INT(_18mem0_2403)) {
        _18mem1_2404 = _18mem0_2403 + 1;
        if (_18mem1_2404 > MAXINT){
            _18mem1_2404 = NewDouble((double)_18mem1_2404);
        }
    }
    else
    _18mem1_2404 = binary_op(PLUS, 1, _18mem0_2403);

    /** mem2 = mem0 + 2*/
    DeRef1(_18mem2_2405);
    if (IS_ATOM_INT(_18mem0_2403)) {
        _18mem2_2405 = _18mem0_2403 + 2;
        if ((long)((unsigned long)_18mem2_2405 + (unsigned long)HIGH_BITS) >= 0) 
        _18mem2_2405 = NewDouble((double)_18mem2_2405);
    }
    else {
        _18mem2_2405 = NewDouble(DBL_PTR(_18mem0_2403)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_18mem3_2406);
    if (IS_ATOM_INT(_18mem0_2403)) {
        _18mem3_2406 = _18mem0_2403 + 3;
        if ((long)((unsigned long)_18mem3_2406 + (unsigned long)HIGH_BITS) >= 0) 
        _18mem3_2406 = NewDouble((double)_18mem3_2406);
    }
    else {
        _18mem3_2406 = NewDouble(DBL_PTR(_18mem0_2403)->dbl + (double)3);
    }
    Concat((object_ptr)&_17HEX_DIGITS_2823, _17DIGITS_2821, _1354);
    Concat((object_ptr)&_17START_NUMERIC_2826, _17DIGITS_2821, _1356);
    _17GET_SHORT_ANSWER_3238 = CRoutineId(182, 17, _1608);
    _17GET_LONG_ANSWER_3241 = CRoutineId(182, 17, _1610);

    /** ifdef LINUX then*/
    RefDS(_5);
    _1631 = _13open_dll(_5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _1633 = MAKE_SEQ(_1);
    RefDS(_1632);
    _12gmtime__3303 = _13define_c_func(_1631, _1632, _1633, 33554436);
    _1631 = NOVALUE;
    _1633 = NOVALUE;
    RefDS(_5);
    _1635 = _13open_dll(_5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _1636 = MAKE_SEQ(_1);
    RefDS(_225);
    _12time__3308 = _13define_c_func(_1635, _225, _1636, 16777220);
    _1635 = NOVALUE;
    _1636 = NOVALUE;
    _0 = _12month_names_3560;
    _1 = NewS1(12);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1791);
    *((int *)(_2+4)) = _1791;
    RefDS(_1792);
    *((int *)(_2+8)) = _1792;
    RefDS(_1793);
    *((int *)(_2+12)) = _1793;
    RefDS(_1794);
    *((int *)(_2+16)) = _1794;
    RefDS(_1795);
    *((int *)(_2+20)) = _1795;
    RefDS(_1796);
    *((int *)(_2+24)) = _1796;
    RefDS(_1797);
    *((int *)(_2+28)) = _1797;
    RefDS(_1798);
    *((int *)(_2+32)) = _1798;
    RefDS(_1799);
    *((int *)(_2+36)) = _1799;
    RefDS(_1800);
    *((int *)(_2+40)) = _1800;
    RefDS(_1801);
    *((int *)(_2+44)) = _1801;
    RefDS(_1802);
    *((int *)(_2+48)) = _1802;
    _12month_names_3560 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12month_abbrs_3574;
    _1 = NewS1(12);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1804);
    *((int *)(_2+4)) = _1804;
    RefDS(_1805);
    *((int *)(_2+8)) = _1805;
    RefDS(_1806);
    *((int *)(_2+12)) = _1806;
    RefDS(_1807);
    *((int *)(_2+16)) = _1807;
    RefDS(_1795);
    *((int *)(_2+20)) = _1795;
    RefDS(_1808);
    *((int *)(_2+24)) = _1808;
    RefDS(_1809);
    *((int *)(_2+28)) = _1809;
    RefDS(_1810);
    *((int *)(_2+32)) = _1810;
    RefDS(_1811);
    *((int *)(_2+36)) = _1811;
    RefDS(_1812);
    *((int *)(_2+40)) = _1812;
    RefDS(_1813);
    *((int *)(_2+44)) = _1813;
    RefDS(_1814);
    *((int *)(_2+48)) = _1814;
    _12month_abbrs_3574 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12day_names_3587;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1816);
    *((int *)(_2+4)) = _1816;
    RefDS(_1817);
    *((int *)(_2+8)) = _1817;
    RefDS(_1818);
    *((int *)(_2+12)) = _1818;
    RefDS(_1819);
    *((int *)(_2+16)) = _1819;
    RefDS(_1820);
    *((int *)(_2+20)) = _1820;
    RefDS(_1821);
    *((int *)(_2+24)) = _1821;
    RefDS(_1822);
    *((int *)(_2+28)) = _1822;
    _12day_names_3587 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _12day_abbrs_3596;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_1824);
    *((int *)(_2+4)) = _1824;
    RefDS(_1825);
    *((int *)(_2+8)) = _1825;
    RefDS(_1826);
    *((int *)(_2+12)) = _1826;
    RefDS(_1827);
    *((int *)(_2+16)) = _1827;
    RefDS(_1828);
    *((int *)(_2+20)) = _1828;
    RefDS(_1829);
    *((int *)(_2+24)) = _1829;
    RefDS(_1830);
    *((int *)(_2+28)) = _1830;
    _12day_abbrs_3596 = MAKE_SEQ(_1);
    DeRef1(_0);
    RefDS(_1833);
    RefDS(_1832);
    DeRef1(_12ampm_3605);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _1832;
    ((int *)_2)[2] = _1833;
    _12ampm_3605 = MAKE_SEQ(_1);

    /** 	return from_date(date())*/
    DeRef1(_12now_1__tmp_at555_4004);
    _12now_1__tmp_at555_4004 = Date();
    RefDS(_12now_1__tmp_at555_4004);
    _12date_now_4001 = _12from_date(_12now_1__tmp_at555_4004);
    DeRef1(_12now_1__tmp_at555_4004);
    _12now_1__tmp_at555_4004 = NOVALUE;
    _22PINF_4351 = NewDouble(DBL_PTR(_2242)->dbl * (double)1000);
    _22MINF_4354 = unary_op(UMINUS, _22PINF_4351);
    _23STDFLTR_ALPHA_6139 = CRoutineId(300, 23, _3226);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3606);
    *((int *)(_2+4)) = _3606;
    _3607 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3607;
    _23SEQ_NOALT_6750 = MAKE_SEQ(_1);
    _3607 = NOVALUE;

    /** ifdef not UNIX then*/

    /** ifdef UNIX then*/

    /** ifdef WINDOWS then	*/
    RefDS(_5);
    _11lib_6973 = _13open_dll(_5);

    /** ifdef LINUX then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 33554436;
    _3736 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3735);
    _11xStatFile_6975 = _13define_c_func(_11lib_6973, _3735, _3736, 16777220);
    _3736 = NOVALUE;

    /** ifdef UNIX then*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _3740 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3739);
    _11xMoveFile_6980 = _13define_c_func(_11lib_6973, _3739, _3740, 16777220);
    _3740 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _3743 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3742);
    _11xDeleteFile_6984 = _13define_c_func(_11lib_6973, _3742, _3743, 16777220);
    _3743 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 16777220;
    _3746 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3745);
    _11xCreateDirectory_6988 = _13define_c_func(_11lib_6973, _3745, _3746, 16777220);
    _3746 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _3749 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3748);
    _11xRemoveDirectory_6992 = _13define_c_func(_11lib_6973, _3748, _3749, 16777220);
    _3749 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 16777220;
    _3752 = MAKE_SEQ(_1);
    Ref(_11lib_6973);
    RefDS(_3751);
    _11xGetFileAttributes_6996 = _13define_c_func(_11lib_6973, _3751, _3752, 16777220);
    _3752 = NOVALUE;

    /** ifdef UNIX then*/

    /** 	ifdef OSX then*/
    _11my_dir_7142 = -2;
    _0 = _11curdir(0);
    DeRef1(_11InitCurDir_7278);
    _11InitCurDir_7278 = _0;

    /** ifdef WINDOWS then*/

    /** ifdef LINUX then*/
    RefDS(_5);
    DeRef1(_11file_counters_8296);
    _11file_counters_8296 = _5;

    /** ifdef UNIX then*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 78;
    RefDS(_919);
    *((int *)(_2+20)) = _919;
    RefDS(_4772);
    *((int *)(_2+24)) = _4772;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 126;
    *((int *)(_2+36)) = 1000000000;
    *((int *)(_2+40)) = 1;
    _26PRETTY_DEFAULT_8726 = MAKE_SEQ(_1);
    _4801 = 32768;
    _27MIN2B_8794 = - 32768;
    _4803 = 32768;
    _27MAX2B_8797 = 32767;
    _4803 = NOVALUE;
    _4805 = 8388608;
    _27MIN3B_8800 = - 8388608;
    _4807 = 8388608;
    _27MAX3B_8803 = 8388607;
    _4807 = NOVALUE;
    _4809 = power(2, 31);
    if (IS_ATOM_INT(_4809)) {
        if ((unsigned long)_4809 == 0xC0000000)
        _27MIN4B_8806 = (int)NewDouble((double)-0xC0000000);
        else
        _27MIN4B_8806 = - _4809;
    }
    else {
        _27MIN4B_8806 = unary_op(UMINUS, _4809);
    }
    DeRef1(_4809);
    _4809 = NOVALUE;
    _4801 = NOVALUE;
    _4805 = NOVALUE;

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_27mem0_8809);
    _27mem0_8809 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_27mem1_8810);
    if (IS_ATOM_INT(_27mem0_8809)) {
        _27mem1_8810 = _27mem0_8809 + 1;
        if (_27mem1_8810 > MAXINT){
            _27mem1_8810 = NewDouble((double)_27mem1_8810);
        }
    }
    else
    _27mem1_8810 = binary_op(PLUS, 1, _27mem0_8809);

    /** mem2 = mem0 + 2*/
    DeRef1(_27mem2_8811);
    if (IS_ATOM_INT(_27mem0_8809)) {
        _27mem2_8811 = _27mem0_8809 + 2;
        if ((long)((unsigned long)_27mem2_8811 + (unsigned long)HIGH_BITS) >= 0) 
        _27mem2_8811 = NewDouble((double)_27mem2_8811);
    }
    else {
        _27mem2_8811 = NewDouble(DBL_PTR(_27mem0_8809)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_27mem3_8812);
    if (IS_ATOM_INT(_27mem0_8809)) {
        _27mem3_8812 = _27mem0_8809 + 3;
        if ((long)((unsigned long)_27mem3_8812 + (unsigned long)HIGH_BITS) >= 0) 
        _27mem3_8812 = NewDouble((double)_27mem3_8812);
    }
    else {
        _27mem3_8812 = NewDouble(DBL_PTR(_27mem0_8809)->dbl + (double)3);
    }
    DeRef1(_27f80_8817);
    _27f80_8817 = 0;
    DeRef1(_27f64_8818);
    _27f64_8818 = 0;
    _27F80_TO_ATOM_8819 = 0;
    DeRef1(_27i64_8857);
    _27i64_8857 = 0;
    _27PEEK8S_8858 = 0;

    /** ifdef UNIX then*/
    _6TO_LOWER_9353 = 32;
    RefDS(_5);
    DeRef1(_6lower_case_SET_9355);
    _6lower_case_SET_9355 = _5;
    RefDS(_5);
    DeRef1(_6upper_case_SET_9356);
    _6upper_case_SET_9356 = _5;
    RefDS(_5152);
    DeRef1(_6encoding_NAME_9357);
    _6encoding_NAME_9357 = _5152;

    /** ifdef WINDOWS then*/
    RefDS(_5);
    DeRef1(_28ram_space_10764);
    _28ram_space_10764 = _5;
    _28ram_free_list_10765 = 0;

    /** free_rid = routine_id("free")*/
    _28free_rid_10766 = CRoutineId(403, 28, _1085);
    _0 = _28malloc(1, 1);
    DeRef1(_5g_state_10913);
    _5g_state_10913 = _0;

    /** eumem:ram_space[g_state] = default_state()*/
    _6159 = _5default_state();
    _2 = (int)SEQ_PTR(_28ram_space_10764);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _28ram_space_10764 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5g_state_10913))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5g_state_10913)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _5g_state_10913);
    _1 = *(int *)_2;
    *(int *)_2 = _6159;
    if( _1 != _6159 ){
        DeRef(_1);
    }
    _6159 = NOVALUE;

    /** new()*/

    /** 	atom state = eumem:malloc()*/
    _0 = _28malloc(1, 1);
    DeRef1(_1state_inlined_new_at_912_24900);
    _1state_inlined_new_at_912_24900 = _0;

    /** 	reset(state)*/
    Ref(_1state_inlined_new_at_912_24900);
    _5reset(_1state_inlined_new_at_912_24900);

    /** 	return state*/
    Ref(_1state_inlined_new_at_912_24900);
    DeRef1(_1new_inlined_new_at_912_24901);
    _1new_inlined_new_at_912_24901 = _1state_inlined_new_at_912_24900;
    DeRef1(_1state_inlined_new_at_912_24900);
    _1state_inlined_new_at_912_24900 = NOVALUE;
    Ref(_1new_inlined_new_at_912_24901);
    DeRef1(_6309);
    _6309 = _1new_inlined_new_at_912_24901;

    /** init_class()*/
    _5init_class();
    Concat((object_ptr)&_29Delimiters_11199, _6315, _6316);
    _0 = _29Token_11208;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    RefDS(_5);
    *((int *)(_2+8)) = _5;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    _29Token_11208 = MAKE_SEQ(_1);
    DeRef1(_0);
    RefDS(_5);
    DeRef1(_29source_text_11210);
    _29source_text_11210 = _5;
    _29sti_11211 = 0;
    _29LNum_11212 = 0;
    _29LPos_11213 = 0;
    _29Look_11214 = 10;
    _29ERR_11215 = 0;
    _29ERR_LNUM_11216 = 0;
    _29ERR_LPOS_11217 = 0;
    _1 = NewS1(11);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6319);
    *((int *)(_2+4)) = _6319;
    RefDS(_6320);
    *((int *)(_2+8)) = _6320;
    RefDS(_6321);
    *((int *)(_2+12)) = _6321;
    RefDS(_6322);
    *((int *)(_2+16)) = _6322;
    RefDS(_6323);
    *((int *)(_2+20)) = _6323;
    RefDS(_6324);
    *((int *)(_2+24)) = _6324;
    RefDS(_6325);
    *((int *)(_2+28)) = _6325;
    RefDS(_6326);
    *((int *)(_2+32)) = _6326;
    RefDS(_6327);
    *((int *)(_2+36)) = _6327;
    RefDS(_6328);
    *((int *)(_2+40)) = _6328;
    RefDS(_6329);
    *((int *)(_2+44)) = _6329;
    _29ERROR_STRING_11230 = MAKE_SEQ(_1);
    _29IGNORE_NEWLINES_11257 = 1;
    _29IGNORE_COMMENTS_11258 = 1;
    _29STRING_NUMBERS_11259 = 0;
    _29SUBSCRIPT_11504 = 0;
    _29INCLUDE_NEXT_11679 = 0;
    _1 = NewS1(39);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6694);
    *((int *)(_2+4)) = _6694;
    RefDS(_6695);
    *((int *)(_2+8)) = _6695;
    RefDS(_6696);
    *((int *)(_2+12)) = _6696;
    RefDS(_6697);
    *((int *)(_2+16)) = _6697;
    RefDS(_6698);
    *((int *)(_2+20)) = _6698;
    RefDS(_6699);
    *((int *)(_2+24)) = _6699;
    RefDS(_6700);
    *((int *)(_2+28)) = _6700;
    RefDS(_6701);
    *((int *)(_2+32)) = _6701;
    RefDS(_6702);
    *((int *)(_2+36)) = _6702;
    RefDS(_6703);
    *((int *)(_2+40)) = _6703;
    RefDS(_6704);
    *((int *)(_2+44)) = _6704;
    RefDS(_6705);
    *((int *)(_2+48)) = _6705;
    RefDS(_6706);
    *((int *)(_2+52)) = _6706;
    RefDS(_6707);
    *((int *)(_2+56)) = _6707;
    RefDS(_6708);
    *((int *)(_2+60)) = _6708;
    RefDS(_6709);
    *((int *)(_2+64)) = _6709;
    RefDS(_6710);
    *((int *)(_2+68)) = _6710;
    RefDS(_6711);
    *((int *)(_2+72)) = _6711;
    RefDS(_6712);
    *((int *)(_2+76)) = _6712;
    RefDS(_6713);
    *((int *)(_2+80)) = _6713;
    RefDS(_6714);
    *((int *)(_2+84)) = _6714;
    RefDS(_6715);
    *((int *)(_2+88)) = _6715;
    RefDS(_6716);
    *((int *)(_2+92)) = _6716;
    RefDS(_6717);
    *((int *)(_2+96)) = _6717;
    RefDS(_6718);
    *((int *)(_2+100)) = _6718;
    RefDS(_6719);
    *((int *)(_2+104)) = _6719;
    RefDS(_6720);
    *((int *)(_2+108)) = _6720;
    RefDS(_6721);
    *((int *)(_2+112)) = _6721;
    RefDS(_6722);
    *((int *)(_2+116)) = _6722;
    RefDS(_6723);
    *((int *)(_2+120)) = _6723;
    RefDS(_6724);
    *((int *)(_2+124)) = _6724;
    RefDS(_6725);
    *((int *)(_2+128)) = _6725;
    RefDS(_6726);
    *((int *)(_2+132)) = _6726;
    RefDS(_6727);
    *((int *)(_2+136)) = _6727;
    RefDS(_6728);
    *((int *)(_2+140)) = _6728;
    RefDS(_6729);
    *((int *)(_2+144)) = _6729;
    RefDS(_6730);
    *((int *)(_2+148)) = _6730;
    RefDS(_6731);
    *((int *)(_2+152)) = _6731;
    RefDS(_6732);
    *((int *)(_2+156)) = _6732;
    _29token_names_11865 = MAKE_SEQ(_1);
    _1 = NewS1(9);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_6734);
    *((int *)(_2+4)) = _6734;
    RefDS(_6735);
    *((int *)(_2+8)) = _6735;
    RefDS(_6736);
    *((int *)(_2+12)) = _6736;
    RefDS(_6737);
    *((int *)(_2+16)) = _6737;
    RefDS(_6738);
    *((int *)(_2+20)) = _6738;
    RefDS(_6739);
    *((int *)(_2+24)) = _6739;
    RefDS(_6740);
    *((int *)(_2+28)) = _6740;
    RefDS(_6741);
    *((int *)(_2+32)) = _6741;
    RefDS(_6742);
    *((int *)(_2+36)) = _6742;
    _29token_forms_11906 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 16;
    *((int *)(_2+12)) = 64;
    *((int *)(_2+16)) = 0;
    _30ediv_11997 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 16;
    *((int *)(_2+16)) = 64;
    _30erem_11999 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 16;
    *((int *)(_2+12)) = 4;
    *((int *)(_2+16)) = 1;
    _30emul_12001 = MAKE_SEQ(_1);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 0;
    _30next_12011 = MAKE_SEQ(_1);
    RefDS(_6883);
    DeRef1(_34list_of_primes_12132);
    _34list_of_primes_12132 = _6883;
    _33threshold_size_12820 = 23;

    /** ifdef WINDOWS then*/
    _0 = _36true_fgcolor_14151;
    _1 = NewS1(32);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 6;
    *((int *)(_2+20)) = 1;
    *((int *)(_2+24)) = 5;
    *((int *)(_2+28)) = 3;
    *((int *)(_2+32)) = 7;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 12;
    *((int *)(_2+44)) = 10;
    *((int *)(_2+48)) = 14;
    *((int *)(_2+52)) = 9;
    *((int *)(_2+56)) = 13;
    *((int *)(_2+60)) = 11;
    *((int *)(_2+64)) = 15;
    *((int *)(_2+68)) = 16;
    *((int *)(_2+72)) = 20;
    *((int *)(_2+76)) = 18;
    *((int *)(_2+80)) = 22;
    *((int *)(_2+84)) = 17;
    *((int *)(_2+88)) = 21;
    *((int *)(_2+92)) = 19;
    *((int *)(_2+96)) = 23;
    *((int *)(_2+100)) = 24;
    *((int *)(_2+104)) = 28;
    *((int *)(_2+108)) = 26;
    *((int *)(_2+112)) = 28;
    *((int *)(_2+116)) = 25;
    *((int *)(_2+120)) = 29;
    *((int *)(_2+124)) = 17;
    *((int *)(_2+128)) = 31;
    _36true_fgcolor_14151 = MAKE_SEQ(_1);
    DeRef1(_0);
    _0 = _36true_bgcolor_14153;
    _1 = NewS1(32);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 4;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 6;
    *((int *)(_2+20)) = 1;
    *((int *)(_2+24)) = 5;
    *((int *)(_2+28)) = 3;
    *((int *)(_2+32)) = 7;
    *((int *)(_2+36)) = 8;
    *((int *)(_2+40)) = 12;
    *((int *)(_2+44)) = 10;
    *((int *)(_2+48)) = 14;
    *((int *)(_2+52)) = 9;
    *((int *)(_2+56)) = 13;
    *((int *)(_2+60)) = 11;
    *((int *)(_2+64)) = 15;
    *((int *)(_2+68)) = 16;
    *((int *)(_2+72)) = 20;
    *((int *)(_2+76)) = 18;
    *((int *)(_2+80)) = 22;
    *((int *)(_2+84)) = 17;
    *((int *)(_2+88)) = 21;
    *((int *)(_2+92)) = 19;
    *((int *)(_2+96)) = 23;
    *((int *)(_2+100)) = 24;
    *((int *)(_2+104)) = 28;
    *((int *)(_2+108)) = 26;
    *((int *)(_2+112)) = 28;
    *((int *)(_2+116)) = 25;
    *((int *)(_2+120)) = 29;
    *((int *)(_2+124)) = 17;
    *((int *)(_2+128)) = 31;
    _36true_bgcolor_14153 = MAKE_SEQ(_1);
    DeRef1(_0);
    _32KC_LBUTTON_14208 = 2;
    _32KC_RBUTTON_14210 = 3;
    _32KC_CANCEL_14212 = 4;
    _32KC_MBUTTON_14214 = 5;
    _32KC_XBUTTON1_14216 = 6;
    _32KC_XBUTTON2_14218 = 7;
    _32KC_BACK_14220 = 9;
    _32KC_TAB_14222 = 10;
    _32KC_CLEAR_14224 = 13;
    _32KC_RETURN_14226 = 14;
    _32KC_SHIFT_14228 = 17;
    _32KC_CONTROL_14230 = 18;
    _32KC_MENU_14232 = 19;
    _32KC_PAUSE_14234 = 20;
    _32KC_CAPITAL_14236 = 21;
    _32KC_KANA_14238 = 22;
    _32KC_JUNJA_14240 = 24;
    _32KC_FINAL_14242 = 25;
    _32KC_HANJA_14244 = 26;
    _32KC_ESCAPE_14246 = 28;
    _32KC_CONVERT_14248 = 29;
    _32KC_NONCONVERT_14250 = 30;
    _32KC_ACCEPT_14252 = 31;
    _32KC_MODECHANGE_14254 = 32;
    _32KC_SPACE_14256 = 33;
    _32KC_PRIOR_14258 = 34;
    _32KC_NEXT_14260 = 35;
    _32KC_END_14262 = 36;
    _32KC_HOME_14264 = 37;
    _32KC_LEFT_14266 = 38;
    _32KC_UP_14268 = 39;
    _32KC_RIGHT_14270 = 40;
    _32KC_DOWN_14272 = 41;
    _32KC_SELECT_14274 = 42;
    _32KC_PRINT_14276 = 43;
    _32KC_EXECUTE_14278 = 44;
    _32KC_SNAPSHOT_14280 = 45;
    _32KC_INSERT_14282 = 46;
    _32KC_DELETE_14284 = 47;
    _32KC_HELP_14286 = 48;
    _32KC_LWIN_14288 = 92;
    _32KC_RWIN_14290 = 93;
    _32KC_APPS_14292 = 94;
    _32KC_SLEEP_14294 = 96;
    _32KC_NUMPAD0_14296 = 97;
    _32KC_NUMPAD1_14298 = 98;
    _32KC_NUMPAD2_14300 = 99;
    _32KC_NUMPAD3_14302 = 100;
    _32KC_NUMPAD4_14304 = 101;
    _32KC_NUMPAD5_14306 = 102;
    _32KC_NUMPAD6_14308 = 103;
    _32KC_NUMPAD7_14310 = 104;
    _32KC_NUMPAD8_14312 = 105;
    _32KC_NUMPAD9_14314 = 106;
    _32KC_MULTIPLY_14316 = 107;
    _32KC_ADD_14318 = 108;
    _32KC_SEPARATOR_14320 = 109;
    _32KC_SUBTRACT_14322 = 110;
    _32KC_DECIMAL_14324 = 111;
    _32KC_DIVIDE_14326 = 112;
    _32KC_F1_14328 = 113;
    _32KC_F2_14330 = 114;
    _32KC_F3_14332 = 115;
    _32KC_F4_14334 = 116;
    _32KC_F5_14336 = 117;
    _32KC_F6_14338 = 118;
    _32KC_F7_14340 = 119;
    _32KC_F8_14342 = 120;
    _32KC_F9_14344 = 121;
    _32KC_F10_14346 = 122;
    _32KC_F11_14348 = 123;
    _32KC_F12_14350 = 124;
    _32KC_F13_14352 = 125;
    _32KC_F14_14355 = 126;
    _32KC_F15_14357 = 127;
    _32KC_F16_14359 = 128;
    _32KC_F17_14361 = 129;
    _32KC_F18_14363 = 130;
    _32KC_F19_14366 = 131;
    _32KC_F20_14369 = 132;
    _32KC_F21_14371 = 133;
    _32KC_F22_14374 = 134;
    _32KC_F23_14377 = 135;
    _32KC_F24_14380 = 136;
    _32KC_NUMLOCK_14383 = 145;
    _32KC_SCROLL_14386 = 146;
    _32KC_LSHIFT_14389 = 161;
    _32KC_RSHIFT_14391 = 162;
    _32KC_LCONTROL_14394 = 163;
    _32KC_RCONTROL_14397 = 164;
    _32KC_LMENU_14399 = 165;
    _32KC_RMENU_14401 = 166;
    _32KC_BROWSER_BACK_14403 = 167;
    _32KC_BROWSER_FORWARD_14406 = 168;
    _32KC_BROWSER_REFRESH_14409 = 169;
    _32KC_BROWSER_STOP_14412 = 170;
    _32KC_BROWSER_SEARCH_14414 = 171;
    _32KC_BROWSER_FAVORITES_14417 = 172;
    _32KC_BROWSER_HOME_14420 = 173;
    _32KC_VOLUME_MUTE_14423 = 174;
    _32KC_VOLUME_DOWN_14426 = 175;
    _32KC_VOLUME_UP_14429 = 176;
    _32KC_MEDIA_NEXT_TRACK_14432 = 177;
    _32KC_MEDIA_PREV_TRACK_14435 = 178;
    _32KC_MEDIA_STOP_14438 = 179;
    _32KC_MEDIA_PLAY_PAUSE_14441 = 180;
    _32KC_LAUNCH_MAIL_14444 = 181;
    _32KC_LAUNCH_MEDIA_SELECT_14447 = 182;
    _32KC_LAUNCH_APP1_14450 = 183;
    _32KC_LAUNCH_APP2_14453 = 184;
    _32KC_OEM_1_14456 = 187;
    _32KC_OEM_PLUS_14459 = 188;
    _32KC_OEM_COMMA_14462 = 189;
    _32KC_OEM_MINUS_14465 = 190;
    _32KC_OEM_PERIOD_14468 = 191;
    _32KC_OEM_2_14471 = 192;
    _32KC_OEM_3_14474 = 193;
    _32KC_OEM_4_14477 = 220;
    _32KC_OEM_5_14479 = 221;
    _32KC_OEM_6_14482 = 222;
    _32KC_OEM_7_14484 = 223;
    _32KC_OEM_8_14487 = 224;
    _32KC_OEM_102_14489 = 227;
    _32KC_PROCESSKEY_14492 = 230;
    _32KC_PACKET_14494 = 232;
    _32KC_ATTN_14497 = 247;
    _32KC_CRSEL_14500 = 248;
    _32KC_EXSEL_14503 = 249;
    _32KC_EREOF_14505 = 250;
    _32KC_PLAY_14507 = 251;
    _32KC_ZOOM_14509 = 252;
    _32KC_NONAME_14511 = 253;
    _32KC_PA1_14513 = 254;
    _32KC_OEM_CLEAR_14515 = 255;

    /** ifdef WINDOWS then*/

    /** ifdef UNIX then*/

    /** ifdef WINDOWS then*/

    /** ifdef WINDOWS then*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8572);
    *((int *)(_2+4)) = _8572;
    _8573 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8573;
    _31EXTRAS_15217 = MAKE_SEQ(_1);
    _8573 = NOVALUE;
    RefDS(_31EXTRAS_15217);
    _31OPT_EXTRAS_15221 = _31EXTRAS_15217;
    RefDS(_5);
    DeRef1(_31pause_msg_15228);
    _31pause_msg_15228 = _5;
    _38current_db_16418 = -1;
    DeRef1(_38current_table_pos_16419);
    _38current_table_pos_16419 = -1;
    RefDS(_5);
    DeRef1(_38current_table_name_16420);
    _38current_table_name_16420 = _5;
    RefDS(_5);
    DeRef1(_38db_names_16421);
    _38db_names_16421 = _5;
    RefDS(_5);
    DeRef1(_38db_file_nums_16422);
    _38db_file_nums_16422 = _5;
    RefDS(_5);
    DeRef1(_38db_lock_methods_16423);
    _38db_lock_methods_16423 = _5;
    _38current_lock_16424 = 0;
    RefDS(_5);
    DeRef1(_38key_pointers_16425);
    _38key_pointers_16425 = _5;
    RefDS(_5);
    DeRef1(_38key_cache_16426);
    _38key_cache_16426 = _5;
    RefDS(_5);
    DeRef1(_38cache_index_16427);
    _38cache_index_16427 = _5;
    _38caching_option_16428 = 1;
    RefDS(_5);
    DeRef1(_38Known_Aliases_16439);
    _38Known_Aliases_16439 = _5;
    RefDS(_5);
    DeRef1(_38Alias_Details_16440);
    _38Alias_Details_16440 = _5;

    /** db_fatal_id = DB_FATAL_FAIL	-- Initialized separately from declaration so*/
    _38db_fatal_id_16441 = -404;
    RefDS(_5);
    DeRef1(_38vLastErrors_16442);
    _38vLastErrors_16442 = _5;

    /** mem0 = machine:allocate(4)*/
    _0 = _14allocate(4, 0);
    DeRef1(_38mem0_16460);
    _38mem0_16460 = _0;

    /** mem1 = mem0 + 1*/
    DeRef1(_38mem1_16461);
    if (IS_ATOM_INT(_38mem0_16460)) {
        _38mem1_16461 = _38mem0_16460 + 1;
        if (_38mem1_16461 > MAXINT){
            _38mem1_16461 = NewDouble((double)_38mem1_16461);
        }
    }
    else
    _38mem1_16461 = binary_op(PLUS, 1, _38mem0_16460);

    /** mem2 = mem0 + 2*/
    DeRef1(_38mem2_16462);
    if (IS_ATOM_INT(_38mem0_16460)) {
        _38mem2_16462 = _38mem0_16460 + 2;
        if ((long)((unsigned long)_38mem2_16462 + (unsigned long)HIGH_BITS) >= 0) 
        _38mem2_16462 = NewDouble((double)_38mem2_16462);
    }
    else {
        _38mem2_16462 = NewDouble(DBL_PTR(_38mem0_16460)->dbl + (double)2);
    }

    /** mem3 = mem0 + 3*/
    DeRef1(_38mem3_16463);
    if (IS_ATOM_INT(_38mem0_16460)) {
        _38mem3_16463 = _38mem0_16460 + 3;
        if ((long)((unsigned long)_38mem3_16463 + (unsigned long)HIGH_BITS) >= 0) 
        _38mem3_16463 = NewDouble((double)_38mem3_16463);
    }
    else {
        _38mem3_16463 = NewDouble(DBL_PTR(_38mem0_16460)->dbl + (double)3);
    }
    _9392 = 32768;
    _38MIN2B_16528 = - 32768;
    _9394 = 32768;
    _38MAX2B_16531 = 32767;
    _9394 = NOVALUE;
    _9396 = 8388608;
    _38MIN3B_16534 = - 8388608;
    _9398 = 8388608;
    _38MAX3B_16537 = 8388607;
    _9398 = NOVALUE;
    _9400 = power(2, 31);
    if (IS_ATOM_INT(_9400)) {
        if ((unsigned long)_9400 == 0xC0000000)
        _38MIN4B_16540 = (int)NewDouble((double)-0xC0000000);
        else
        _38MIN4B_16540 = - _9400;
    }
    else {
        _38MIN4B_16540 = unary_op(UMINUS, _9400);
    }
    DeRef1(_9400);
    _9400 = NOVALUE;
    _9392 = NOVALUE;
    _9396 = NOVALUE;

    /** memseq = {mem0, 4}*/
    Ref(_38mem0_16460);
    DeRef1(_38memseq_16680);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _38mem0_16460;
    ((int *)_2)[2] = 4;
    _38memseq_16680 = MAKE_SEQ(_1);
    _0 = _33new(690);
    DeRef1(_39one_bit_numbers_18728);
    _39one_bit_numbers_18728 = _0;

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0001, 1)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 1, 1, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0010, 2)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 2, 2, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_0100, 3)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 4, 3, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0000_1000, 4)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 8, 4, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0001_0000, 5)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 16, 5, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0010_0000, 6)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 32, 6, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_0100_0000, 7)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 64, 7, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0000_1000_0000, 8)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 128, 8, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0001_0000_0000, 9)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 256, 9, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0010_0000_0000, 10)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 512, 10, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_0100_0000_0000, 11)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 1024, 11, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0000_1000_0000_0000, 12)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 2048, 12, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0001_0000_0000_0000, 13)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 4096, 13, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0010_0000_0000_0000, 14)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 8192, 14, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_0100_0000_0000_0000, 15)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 16384, 15, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0000_1000_0000_0000_0000, 16)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 32768, 16, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0001_0000_0000_0000_0000, 17)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 65536, 17, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0010_0000_0000_0000_0000, 18)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 131072, 18, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_0100_0000_0000_0000_0000, 19)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 262144, 19, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0000_1000_0000_0000_0000_0000, 20)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 524288, 20, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0001_0000_0000_0000_0000_0000, 21)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 1048576, 21, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0010_0000_0000_0000_0000_0000, 22)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 2097152, 22, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_0100_0000_0000_0000_0000_0000, 23)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 4194304, 23, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0000_1000_0000_0000_0000_0000_0000, 24)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 8388608, 24, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0001_0000_0000_0000_0000_0000_0000, 25)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 16777216, 25, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0010_0000_0000_0000_0000_0000_0000, 26)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 33554432, 26, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_0100_0000_0000_0000_0000_0000_0000, 27)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 67108864, 27, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0000_1000_0000_0000_0000_0000_0000_0000, 28)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 134217728, 28, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0001_0000_0000_0000_0000_0000_0000_0000, 29)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 268435456, 29, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0010_0000_0000_0000_0000_0000_0000_0000, 30)*/
    Ref(_39one_bit_numbers_18728);
    _33put(_39one_bit_numbers_18728, 536870912, 30, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b0100_0000_0000_0000_0000_0000_0000_0000, 31)*/
    Ref(_39one_bit_numbers_18728);
    RefDS(_10434);
    _33put(_39one_bit_numbers_18728, _10434, 31, 1, _33threshold_size_12820);

    /** map:put(one_bit_numbers, 0b1000_0000_0000_0000_0000_0000_0000_0000, 32)*/
    Ref(_39one_bit_numbers_18728);
    RefDS(_10435);
    _33put(_39one_bit_numbers_18728, _10435, 32, 1, _33threshold_size_12820);

    /** ifdef WINDOWS then*/
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_11131);
    *((int *)(_2+4)) = _11131;
    RefDS(_11132);
    *((int *)(_2+8)) = _11132;
    RefDS(_11133);
    *((int *)(_2+12)) = _11133;
    RefDS(_11134);
    *((int *)(_2+16)) = _11134;
    RefDS(_11135);
    *((int *)(_2+20)) = _11135;
    RefDS(_11136);
    *((int *)(_2+24)) = _11136;
    RefDS(_11137);
    *((int *)(_2+28)) = _11137;
    RefDS(_11138);
    *((int *)(_2+32)) = _11138;
    RefDS(_11139);
    *((int *)(_2+36)) = _11139;
    RefDS(_11140);
    *((int *)(_2+40)) = _11140;
    RefDS(_11141);
    *((int *)(_2+44)) = _11141;
    RefDS(_11142);
    *((int *)(_2+48)) = _11142;
    RefDS(_11143);
    *((int *)(_2+52)) = _11143;
    RefDS(_11144);
    *((int *)(_2+56)) = _11144;
    RefDS(_11145);
    *((int *)(_2+60)) = _11145;
    RefDS(_11146);
    *((int *)(_2+64)) = _11146;
    RefDS(_11147);
    *((int *)(_2+68)) = _11147;
    RefDS(_11148);
    *((int *)(_2+72)) = _11148;
    RefDS(_11149);
    *((int *)(_2+76)) = _11149;
    RefDS(_11150);
    *((int *)(_2+80)) = _11150;
    RefDS(_11151);
    *((int *)(_2+84)) = _11151;
    RefDS(_11152);
    *((int *)(_2+88)) = _11152;
    RefDS(_11153);
    *((int *)(_2+92)) = _11153;
    RefDS(_11154);
    *((int *)(_2+96)) = _11154;
    RefDS(_11155);
    *((int *)(_2+100)) = _11155;
    RefDS(_11156);
    *((int *)(_2+104)) = _11156;
    RefDS(_11157);
    *((int *)(_2+108)) = _11157;
    RefDS(_11158);
    *((int *)(_2+112)) = _11158;
    RefDS(_11159);
    *((int *)(_2+116)) = _11159;
    RefDS(_11160);
    *((int *)(_2+120)) = _11160;
    RefDS(_11161);
    *((int *)(_2+124)) = _11161;
    RefDS(_11162);
    *((int *)(_2+128)) = _11162;
    RefDS(_11163);
    *((int *)(_2+132)) = _11163;
    RefDS(_11164);
    *((int *)(_2+136)) = _11164;
    RefDS(_11165);
    *((int *)(_2+140)) = _11165;
    RefDS(_11166);
    *((int *)(_2+144)) = _11166;
    RefDS(_11167);
    *((int *)(_2+148)) = _11167;
    RefDS(_11168);
    *((int *)(_2+152)) = _11168;
    RefDS(_11169);
    *((int *)(_2+156)) = _11169;
    RefDS(_11170);
    *((int *)(_2+160)) = _11170;
    RefDS(_11171);
    *((int *)(_2+164)) = _11171;
    RefDS(_11172);
    *((int *)(_2+168)) = _11172;
    RefDS(_11173);
    *((int *)(_2+172)) = _11173;
    RefDS(_11174);
    *((int *)(_2+176)) = _11174;
    RefDS(_11175);
    *((int *)(_2+180)) = _11175;
    RefDS(_11176);
    *((int *)(_2+184)) = _11176;
    RefDS(_11177);
    *((int *)(_2+188)) = _11177;
    RefDS(_11178);
    *((int *)(_2+192)) = _11178;
    RefDS(_11179);
    *((int *)(_2+196)) = _11179;
    RefDS(_11180);
    *((int *)(_2+200)) = _11180;
    RefDS(_11181);
    *((int *)(_2+204)) = _11181;
    RefDS(_11182);
    *((int *)(_2+208)) = _11182;
    RefDS(_11183);
    *((int *)(_2+212)) = _11183;
    RefDS(_11184);
    *((int *)(_2+216)) = _11184;
    RefDS(_11185);
    *((int *)(_2+220)) = _11185;
    RefDS(_11186);
    *((int *)(_2+224)) = _11186;
    RefDS(_11187);
    *((int *)(_2+228)) = _11187;
    RefDS(_11188);
    *((int *)(_2+232)) = _11188;
    RefDS(_11189);
    *((int *)(_2+236)) = _11189;
    RefDS(_11190);
    *((int *)(_2+240)) = _11190;
    RefDS(_11191);
    *((int *)(_2+244)) = _11191;
    RefDS(_11192);
    *((int *)(_2+248)) = _11192;
    RefDS(_11193);
    *((int *)(_2+252)) = _11193;
    RefDS(_11194);
    *((int *)(_2+256)) = _11194;
    RefDS(_11195);
    *((int *)(_2+260)) = _11195;
    RefDS(_11196);
    *((int *)(_2+264)) = _11196;
    RefDS(_11197);
    *((int *)(_2+268)) = _11197;
    RefDS(_11198);
    *((int *)(_2+272)) = _11198;
    RefDS(_11199);
    *((int *)(_2+276)) = _11199;
    RefDS(_11200);
    *((int *)(_2+280)) = _11200;
    RefDS(_11201);
    *((int *)(_2+284)) = _11201;
    RefDS(_11202);
    *((int *)(_2+288)) = _11202;
    RefDS(_11203);
    *((int *)(_2+292)) = _11203;
    RefDS(_11204);
    *((int *)(_2+296)) = _11204;
    RefDS(_11205);
    *((int *)(_2+300)) = _11205;
    RefDS(_11206);
    *((int *)(_2+304)) = _11206;
    RefDS(_11207);
    *((int *)(_2+308)) = _11207;
    RefDS(_11208);
    *((int *)(_2+312)) = _11208;
    RefDS(_11209);
    *((int *)(_2+316)) = _11209;
    RefDS(_11210);
    *((int *)(_2+320)) = _11210;
    RefDS(_11211);
    *((int *)(_2+324)) = _11211;
    RefDS(_11212);
    *((int *)(_2+328)) = _11212;
    RefDS(_11213);
    *((int *)(_2+332)) = _11213;
    RefDS(_11214);
    *((int *)(_2+336)) = _11214;
    RefDS(_11215);
    *((int *)(_2+340)) = _11215;
    RefDS(_11216);
    *((int *)(_2+344)) = _11216;
    RefDS(_11217);
    *((int *)(_2+348)) = _11217;
    RefDS(_11218);
    *((int *)(_2+352)) = _11218;
    RefDS(_11219);
    *((int *)(_2+356)) = _11219;
    RefDS(_11220);
    *((int *)(_2+360)) = _11220;
    RefDS(_11221);
    *((int *)(_2+364)) = _11221;
    RefDS(_11222);
    *((int *)(_2+368)) = _11222;
    RefDS(_11223);
    *((int *)(_2+372)) = _11223;
    RefDS(_11224);
    *((int *)(_2+376)) = _11224;
    RefDS(_11225);
    *((int *)(_2+380)) = _11225;
    RefDS(_11226);
    *((int *)(_2+384)) = _11226;
    RefDS(_11227);
    *((int *)(_2+388)) = _11227;
    RefDS(_11228);
    *((int *)(_2+392)) = _11228;
    RefDS(_11229);
    *((int *)(_2+396)) = _11229;
    RefDS(_11230);
    *((int *)(_2+400)) = _11230;
    RefDS(_11231);
    *((int *)(_2+404)) = _11231;
    RefDS(_11232);
    *((int *)(_2+408)) = _11232;
    RefDS(_11233);
    *((int *)(_2+412)) = _11233;
    RefDS(_11234);
    *((int *)(_2+416)) = _11234;
    RefDS(_11235);
    *((int *)(_2+420)) = _11235;
    RefDS(_11236);
    *((int *)(_2+424)) = _11236;
    RefDS(_11237);
    *((int *)(_2+428)) = _11237;
    RefDS(_11238);
    *((int *)(_2+432)) = _11238;
    RefDS(_11239);
    *((int *)(_2+436)) = _11239;
    RefDS(_11240);
    *((int *)(_2+440)) = _11240;
    RefDS(_11241);
    *((int *)(_2+444)) = _11241;
    RefDS(_11242);
    *((int *)(_2+448)) = _11242;
    RefDS(_11243);
    *((int *)(_2+452)) = _11243;
    RefDS(_11244);
    *((int *)(_2+456)) = _11244;
    RefDS(_11245);
    *((int *)(_2+460)) = _11245;
    RefDS(_11246);
    *((int *)(_2+464)) = _11246;
    RefDS(_11247);
    *((int *)(_2+468)) = _11247;
    RefDS(_11248);
    *((int *)(_2+472)) = _11248;
    RefDS(_11249);
    *((int *)(_2+476)) = _11249;
    RefDS(_11250);
    *((int *)(_2+480)) = _11250;
    RefDS(_11251);
    *((int *)(_2+484)) = _11251;
    RefDS(_11252);
    *((int *)(_2+488)) = _11252;
    RefDS(_11253);
    *((int *)(_2+492)) = _11253;
    RefDS(_11254);
    *((int *)(_2+496)) = _11254;
    RefDS(_11255);
    *((int *)(_2+500)) = _11255;
    RefDS(_11256);
    *((int *)(_2+504)) = _11256;
    RefDS(_11257);
    *((int *)(_2+508)) = _11257;
    RefDS(_11258);
    *((int *)(_2+512)) = _11258;
    RefDS(_11259);
    *((int *)(_2+516)) = _11259;
    RefDS(_11260);
    *((int *)(_2+520)) = _11260;
    RefDS(_11261);
    *((int *)(_2+524)) = _11261;
    RefDS(_11262);
    *((int *)(_2+528)) = _11262;
    RefDS(_11263);
    *((int *)(_2+532)) = _11263;
    RefDS(_11264);
    *((int *)(_2+536)) = _11264;
    RefDS(_11265);
    *((int *)(_2+540)) = _11265;
    RefDS(_11266);
    *((int *)(_2+544)) = _11266;
    RefDS(_11267);
    *((int *)(_2+548)) = _11267;
    RefDS(_11268);
    *((int *)(_2+552)) = _11268;
    RefDS(_11269);
    *((int *)(_2+556)) = _11269;
    RefDS(_11270);
    *((int *)(_2+560)) = _11270;
    RefDS(_11271);
    *((int *)(_2+564)) = _11271;
    RefDS(_11272);
    *((int *)(_2+568)) = _11272;
    RefDS(_11273);
    *((int *)(_2+572)) = _11273;
    RefDS(_11274);
    *((int *)(_2+576)) = _11274;
    RefDS(_11275);
    *((int *)(_2+580)) = _11275;
    RefDS(_11276);
    *((int *)(_2+584)) = _11276;
    RefDS(_11277);
    *((int *)(_2+588)) = _11277;
    RefDS(_11278);
    *((int *)(_2+592)) = _11278;
    RefDS(_11279);
    *((int *)(_2+596)) = _11279;
    RefDS(_11280);
    *((int *)(_2+600)) = _11280;
    RefDS(_11281);
    *((int *)(_2+604)) = _11281;
    RefDS(_11282);
    *((int *)(_2+608)) = _11282;
    RefDS(_11283);
    *((int *)(_2+612)) = _11283;
    RefDS(_11284);
    *((int *)(_2+616)) = _11284;
    RefDS(_11285);
    *((int *)(_2+620)) = _11285;
    RefDS(_11286);
    *((int *)(_2+624)) = _11286;
    RefDS(_11287);
    *((int *)(_2+628)) = _11287;
    RefDS(_11288);
    *((int *)(_2+632)) = _11288;
    RefDS(_11289);
    *((int *)(_2+636)) = _11289;
    RefDS(_11290);
    *((int *)(_2+640)) = _11290;
    RefDS(_11291);
    *((int *)(_2+644)) = _11291;
    RefDS(_11292);
    *((int *)(_2+648)) = _11292;
    RefDS(_11293);
    *((int *)(_2+652)) = _11293;
    RefDS(_11294);
    *((int *)(_2+656)) = _11294;
    RefDS(_11295);
    *((int *)(_2+660)) = _11295;
    RefDS(_11296);
    *((int *)(_2+664)) = _11296;
    RefDS(_11297);
    *((int *)(_2+668)) = _11297;
    RefDS(_11298);
    *((int *)(_2+672)) = _11298;
    RefDS(_11299);
    *((int *)(_2+676)) = _11299;
    RefDS(_11300);
    *((int *)(_2+680)) = _11300;
    RefDS(_11301);
    *((int *)(_2+684)) = _11301;
    RefDS(_11302);
    *((int *)(_2+688)) = _11302;
    RefDS(_11303);
    *((int *)(_2+692)) = _11303;
    RefDS(_11304);
    *((int *)(_2+696)) = _11304;
    RefDS(_11305);
    *((int *)(_2+700)) = _11305;
    RefDS(_11306);
    *((int *)(_2+704)) = _11306;
    RefDS(_11307);
    *((int *)(_2+708)) = _11307;
    RefDS(_11308);
    *((int *)(_2+712)) = _11308;
    RefDS(_11309);
    *((int *)(_2+716)) = _11309;
    RefDS(_11310);
    *((int *)(_2+720)) = _11310;
    RefDS(_11311);
    *((int *)(_2+724)) = _11311;
    RefDS(_11312);
    *((int *)(_2+728)) = _11312;
    RefDS(_11313);
    *((int *)(_2+732)) = _11313;
    RefDS(_11314);
    *((int *)(_2+736)) = _11314;
    RefDS(_11315);
    *((int *)(_2+740)) = _11315;
    RefDS(_11316);
    *((int *)(_2+744)) = _11316;
    RefDS(_11317);
    *((int *)(_2+748)) = _11317;
    RefDS(_11318);
    *((int *)(_2+752)) = _11318;
    RefDS(_11319);
    *((int *)(_2+756)) = _11319;
    RefDS(_11320);
    *((int *)(_2+760)) = _11320;
    RefDS(_11321);
    *((int *)(_2+764)) = _11321;
    RefDS(_11322);
    *((int *)(_2+768)) = _11322;
    RefDS(_11323);
    *((int *)(_2+772)) = _11323;
    RefDS(_11324);
    *((int *)(_2+776)) = _11324;
    RefDS(_11325);
    *((int *)(_2+780)) = _11325;
    RefDS(_11326);
    *((int *)(_2+784)) = _11326;
    RefDS(_11327);
    *((int *)(_2+788)) = _11327;
    RefDS(_11328);
    *((int *)(_2+792)) = _11328;
    RefDS(_11329);
    *((int *)(_2+796)) = _11329;
    RefDS(_11330);
    *((int *)(_2+800)) = _11330;
    RefDS(_11331);
    *((int *)(_2+804)) = _11331;
    RefDS(_11332);
    *((int *)(_2+808)) = _11332;
    RefDS(_11333);
    *((int *)(_2+812)) = _11333;
    RefDS(_11334);
    *((int *)(_2+816)) = _11334;
    RefDS(_11335);
    *((int *)(_2+820)) = _11335;
    RefDS(_11336);
    *((int *)(_2+824)) = _11336;
    RefDS(_11337);
    *((int *)(_2+828)) = _11337;
    RefDS(_11338);
    *((int *)(_2+832)) = _11338;
    _44w32_names_19811 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RepeatElem(_2+4, _11340, 24);
    RefDSn(_11341, 2);
    *((int *)(_2+100)) = _11341;
    *((int *)(_2+104)) = _11341;
    RefDSn(_11342, 6);
    *((int *)(_2+108)) = _11342;
    *((int *)(_2+112)) = _11342;
    *((int *)(_2+116)) = _11342;
    *((int *)(_2+120)) = _11342;
    *((int *)(_2+124)) = _11342;
    *((int *)(_2+128)) = _11342;
    RepeatElem(_2+132, _11343, 10);
    RefDSn(_11344, 5);
    *((int *)(_2+172)) = _11344;
    *((int *)(_2+176)) = _11344;
    *((int *)(_2+180)) = _11344;
    *((int *)(_2+184)) = _11344;
    *((int *)(_2+188)) = _11344;
    RefDS(_11345);
    *((int *)(_2+192)) = _11345;
    RepeatElem(_2+196, _11346, 15);
    RefDS(_11347);
    *((int *)(_2+256)) = _11347;
    RefDSn(_11346, 2);
    *((int *)(_2+260)) = _11346;
    *((int *)(_2+264)) = _11346;
    RefDS(_11348);
    *((int *)(_2+268)) = _11348;
    RepeatElem(_2+272, _11349, 20);
    RefDSn(_11350, 7);
    *((int *)(_2+352)) = _11350;
    *((int *)(_2+356)) = _11350;
    *((int *)(_2+360)) = _11350;
    *((int *)(_2+364)) = _11350;
    *((int *)(_2+368)) = _11350;
    *((int *)(_2+372)) = _11350;
    *((int *)(_2+376)) = _11350;
    RepeatElem(_2+380, _11351, 42);
    RefDSn(_11352, 2);
    *((int *)(_2+548)) = _11352;
    *((int *)(_2+552)) = _11352;
    RefDSn(_11353, 4);
    *((int *)(_2+556)) = _11353;
    *((int *)(_2+560)) = _11353;
    *((int *)(_2+564)) = _11353;
    *((int *)(_2+568)) = _11353;
    RepeatElem(_2+572, _11354, 15);
    RefDS(_11355);
    *((int *)(_2+632)) = _11355;
    RepeatElem(_2+636, _11347, 16);
    RefDS(_11356);
    *((int *)(_2+700)) = _11356;
    RefDSn(_11347, 4);
    *((int *)(_2+704)) = _11347;
    *((int *)(_2+708)) = _11347;
    *((int *)(_2+712)) = _11347;
    *((int *)(_2+716)) = _11347;
    RepeatElem(_2+720, _11357, 15);
    RepeatElem(_2+780, _11358, 14);
    _44w32_name_canonical_20021 = MAKE_SEQ(_1);
    _1 = NewS1(208);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_10923);
    *((int *)(_2+4)) = _10923;
    RefDS(_10924);
    *((int *)(_2+8)) = _10924;
    RefDS(_10925);
    *((int *)(_2+12)) = _10925;
    RefDS(_10926);
    *((int *)(_2+16)) = _10926;
    RefDS(_10927);
    *((int *)(_2+20)) = _10927;
    RefDS(_10928);
    *((int *)(_2+24)) = _10928;
    RefDS(_10929);
    *((int *)(_2+28)) = _10929;
    RefDS(_10930);
    *((int *)(_2+32)) = _10930;
    RefDS(_10931);
    *((int *)(_2+36)) = _10931;
    RefDS(_10932);
    *((int *)(_2+40)) = _10932;
    RefDS(_10933);
    *((int *)(_2+44)) = _10933;
    RefDS(_10934);
    *((int *)(_2+48)) = _10934;
    RefDS(_10935);
    *((int *)(_2+52)) = _10935;
    RefDS(_10936);
    *((int *)(_2+56)) = _10936;
    RefDS(_10937);
    *((int *)(_2+60)) = _10937;
    RefDS(_10938);
    *((int *)(_2+64)) = _10938;
    RefDS(_10939);
    *((int *)(_2+68)) = _10939;
    RefDS(_10940);
    *((int *)(_2+72)) = _10940;
    RefDS(_10941);
    *((int *)(_2+76)) = _10941;
    RefDS(_10942);
    *((int *)(_2+80)) = _10942;
    RefDS(_10943);
    *((int *)(_2+84)) = _10943;
    RefDS(_10944);
    *((int *)(_2+88)) = _10944;
    RefDS(_10945);
    *((int *)(_2+92)) = _10945;
    RefDS(_10946);
    *((int *)(_2+96)) = _10946;
    RefDS(_10947);
    *((int *)(_2+100)) = _10947;
    RefDS(_10948);
    *((int *)(_2+104)) = _10948;
    RefDS(_10949);
    *((int *)(_2+108)) = _10949;
    RefDS(_10950);
    *((int *)(_2+112)) = _10950;
    RefDS(_10951);
    *((int *)(_2+116)) = _10951;
    RefDS(_10952);
    *((int *)(_2+120)) = _10952;
    RefDS(_10953);
    *((int *)(_2+124)) = _10953;
    RefDS(_10954);
    *((int *)(_2+128)) = _10954;
    RefDS(_10955);
    *((int *)(_2+132)) = _10955;
    RefDS(_10956);
    *((int *)(_2+136)) = _10956;
    RefDS(_10957);
    *((int *)(_2+140)) = _10957;
    RefDS(_10958);
    *((int *)(_2+144)) = _10958;
    RefDS(_10959);
    *((int *)(_2+148)) = _10959;
    RefDS(_10960);
    *((int *)(_2+152)) = _10960;
    RefDS(_11360);
    *((int *)(_2+156)) = _11360;
    RefDS(_10961);
    *((int *)(_2+160)) = _10961;
    RefDS(_10962);
    *((int *)(_2+164)) = _10962;
    RefDS(_10963);
    *((int *)(_2+168)) = _10963;
    RefDS(_10964);
    *((int *)(_2+172)) = _10964;
    RefDS(_10965);
    *((int *)(_2+176)) = _10965;
    RefDS(_10966);
    *((int *)(_2+180)) = _10966;
    RefDS(_10967);
    *((int *)(_2+184)) = _10967;
    RefDS(_10968);
    *((int *)(_2+188)) = _10968;
    RefDS(_10969);
    *((int *)(_2+192)) = _10969;
    RefDS(_10970);
    *((int *)(_2+196)) = _10970;
    RefDS(_10971);
    *((int *)(_2+200)) = _10971;
    RefDS(_10972);
    *((int *)(_2+204)) = _10972;
    RefDS(_10973);
    *((int *)(_2+208)) = _10973;
    RefDS(_10974);
    *((int *)(_2+212)) = _10974;
    RefDS(_10975);
    *((int *)(_2+216)) = _10975;
    RefDS(_10976);
    *((int *)(_2+220)) = _10976;
    RefDS(_10977);
    *((int *)(_2+224)) = _10977;
    RefDS(_10978);
    *((int *)(_2+228)) = _10978;
    RefDS(_10979);
    *((int *)(_2+232)) = _10979;
    RefDS(_10980);
    *((int *)(_2+236)) = _10980;
    RefDS(_10981);
    *((int *)(_2+240)) = _10981;
    RefDS(_10982);
    *((int *)(_2+244)) = _10982;
    RefDS(_10983);
    *((int *)(_2+248)) = _10983;
    RefDS(_10984);
    *((int *)(_2+252)) = _10984;
    RefDS(_10985);
    *((int *)(_2+256)) = _10985;
    RefDS(_10986);
    *((int *)(_2+260)) = _10986;
    RefDS(_10987);
    *((int *)(_2+264)) = _10987;
    RefDS(_10988);
    *((int *)(_2+268)) = _10988;
    RefDS(_10989);
    *((int *)(_2+272)) = _10989;
    RefDS(_10990);
    *((int *)(_2+276)) = _10990;
    RefDS(_10991);
    *((int *)(_2+280)) = _10991;
    RefDS(_10992);
    *((int *)(_2+284)) = _10992;
    RefDS(_10993);
    *((int *)(_2+288)) = _10993;
    RefDS(_10994);
    *((int *)(_2+292)) = _10994;
    RefDS(_10995);
    *((int *)(_2+296)) = _10995;
    RefDS(_10996);
    *((int *)(_2+300)) = _10996;
    RefDS(_10997);
    *((int *)(_2+304)) = _10997;
    RefDS(_10998);
    *((int *)(_2+308)) = _10998;
    RefDS(_10999);
    *((int *)(_2+312)) = _10999;
    RefDS(_11000);
    *((int *)(_2+316)) = _11000;
    RefDS(_11001);
    *((int *)(_2+320)) = _11001;
    RefDS(_11002);
    *((int *)(_2+324)) = _11002;
    RefDS(_11003);
    *((int *)(_2+328)) = _11003;
    RefDS(_11004);
    *((int *)(_2+332)) = _11004;
    RefDS(_11005);
    *((int *)(_2+336)) = _11005;
    RefDS(_11006);
    *((int *)(_2+340)) = _11006;
    RefDS(_11007);
    *((int *)(_2+344)) = _11007;
    RefDS(_11008);
    *((int *)(_2+348)) = _11008;
    RefDS(_11009);
    *((int *)(_2+352)) = _11009;
    RefDS(_11010);
    *((int *)(_2+356)) = _11010;
    RefDS(_11011);
    *((int *)(_2+360)) = _11011;
    RefDS(_11012);
    *((int *)(_2+364)) = _11012;
    RefDS(_11013);
    *((int *)(_2+368)) = _11013;
    RefDS(_11014);
    *((int *)(_2+372)) = _11014;
    RefDS(_11015);
    *((int *)(_2+376)) = _11015;
    RefDS(_11016);
    *((int *)(_2+380)) = _11016;
    RefDS(_11017);
    *((int *)(_2+384)) = _11017;
    RefDS(_11018);
    *((int *)(_2+388)) = _11018;
    RefDS(_11019);
    *((int *)(_2+392)) = _11019;
    RefDS(_11020);
    *((int *)(_2+396)) = _11020;
    RefDS(_11021);
    *((int *)(_2+400)) = _11021;
    RefDS(_11022);
    *((int *)(_2+404)) = _11022;
    RefDS(_11023);
    *((int *)(_2+408)) = _11023;
    RefDS(_11024);
    *((int *)(_2+412)) = _11024;
    RefDS(_11025);
    *((int *)(_2+416)) = _11025;
    RefDS(_11026);
    *((int *)(_2+420)) = _11026;
    RefDS(_11027);
    *((int *)(_2+424)) = _11027;
    RefDS(_11028);
    *((int *)(_2+428)) = _11028;
    RefDS(_11029);
    *((int *)(_2+432)) = _11029;
    RefDS(_11030);
    *((int *)(_2+436)) = _11030;
    RefDS(_11031);
    *((int *)(_2+440)) = _11031;
    RefDS(_11032);
    *((int *)(_2+444)) = _11032;
    RefDS(_11033);
    *((int *)(_2+448)) = _11033;
    RefDS(_11034);
    *((int *)(_2+452)) = _11034;
    RefDS(_11035);
    *((int *)(_2+456)) = _11035;
    RefDS(_11036);
    *((int *)(_2+460)) = _11036;
    RefDS(_11037);
    *((int *)(_2+464)) = _11037;
    RefDS(_11038);
    *((int *)(_2+468)) = _11038;
    RefDS(_11039);
    *((int *)(_2+472)) = _11039;
    RefDS(_11040);
    *((int *)(_2+476)) = _11040;
    RefDS(_11041);
    *((int *)(_2+480)) = _11041;
    RefDS(_11042);
    *((int *)(_2+484)) = _11042;
    RefDS(_11043);
    *((int *)(_2+488)) = _11043;
    RefDS(_11044);
    *((int *)(_2+492)) = _11044;
    RefDS(_11045);
    *((int *)(_2+496)) = _11045;
    RefDS(_11046);
    *((int *)(_2+500)) = _11046;
    RefDS(_11047);
    *((int *)(_2+504)) = _11047;
    RefDS(_11048);
    *((int *)(_2+508)) = _11048;
    RefDS(_11049);
    *((int *)(_2+512)) = _11049;
    RefDS(_11050);
    *((int *)(_2+516)) = _11050;
    RefDS(_11051);
    *((int *)(_2+520)) = _11051;
    RefDS(_11052);
    *((int *)(_2+524)) = _11052;
    RefDS(_11053);
    *((int *)(_2+528)) = _11053;
    RefDS(_11054);
    *((int *)(_2+532)) = _11054;
    RefDS(_11055);
    *((int *)(_2+536)) = _11055;
    RefDS(_11056);
    *((int *)(_2+540)) = _11056;
    RefDS(_11057);
    *((int *)(_2+544)) = _11057;
    RefDS(_11058);
    *((int *)(_2+548)) = _11058;
    RefDS(_11059);
    *((int *)(_2+552)) = _11059;
    RefDS(_11060);
    *((int *)(_2+556)) = _11060;
    RefDS(_11061);
    *((int *)(_2+560)) = _11061;
    RefDS(_11062);
    *((int *)(_2+564)) = _11062;
    RefDS(_11063);
    *((int *)(_2+568)) = _11063;
    RefDS(_11064);
    *((int *)(_2+572)) = _11064;
    RefDS(_11065);
    *((int *)(_2+576)) = _11065;
    RefDS(_11066);
    *((int *)(_2+580)) = _11066;
    RefDS(_11067);
    *((int *)(_2+584)) = _11067;
    RefDS(_11068);
    *((int *)(_2+588)) = _11068;
    RefDS(_11069);
    *((int *)(_2+592)) = _11069;
    RefDS(_11070);
    *((int *)(_2+596)) = _11070;
    RefDS(_11071);
    *((int *)(_2+600)) = _11071;
    RefDS(_11072);
    *((int *)(_2+604)) = _11072;
    RefDS(_11073);
    *((int *)(_2+608)) = _11073;
    RefDS(_11074);
    *((int *)(_2+612)) = _11074;
    RefDS(_11075);
    *((int *)(_2+616)) = _11075;
    RefDS(_11076);
    *((int *)(_2+620)) = _11076;
    RefDS(_11077);
    *((int *)(_2+624)) = _11077;
    RefDS(_11078);
    *((int *)(_2+628)) = _11078;
    RefDS(_11079);
    *((int *)(_2+632)) = _11079;
    RefDS(_11080);
    *((int *)(_2+636)) = _11080;
    RefDS(_11081);
    *((int *)(_2+640)) = _11081;
    RefDS(_11082);
    *((int *)(_2+644)) = _11082;
    RefDS(_11083);
    *((int *)(_2+648)) = _11083;
    RefDS(_11084);
    *((int *)(_2+652)) = _11084;
    RefDS(_11085);
    *((int *)(_2+656)) = _11085;
    RefDS(_11086);
    *((int *)(_2+660)) = _11086;
    RefDS(_11087);
    *((int *)(_2+664)) = _11087;
    RefDS(_11088);
    *((int *)(_2+668)) = _11088;
    RefDS(_11089);
    *((int *)(_2+672)) = _11089;
    RefDS(_11090);
    *((int *)(_2+676)) = _11090;
    RefDS(_11091);
    *((int *)(_2+680)) = _11091;
    RefDS(_11092);
    *((int *)(_2+684)) = _11092;
    RefDS(_11093);
    *((int *)(_2+688)) = _11093;
    RefDS(_11094);
    *((int *)(_2+692)) = _11094;
    RefDS(_11095);
    *((int *)(_2+696)) = _11095;
    RefDS(_11096);
    *((int *)(_2+700)) = _11096;
    RefDS(_11097);
    *((int *)(_2+704)) = _11097;
    RefDS(_11098);
    *((int *)(_2+708)) = _11098;
    RefDS(_11099);
    *((int *)(_2+712)) = _11099;
    RefDS(_11100);
    *((int *)(_2+716)) = _11100;
    RefDS(_11101);
    *((int *)(_2+720)) = _11101;
    RefDS(_11102);
    *((int *)(_2+724)) = _11102;
    RefDS(_11103);
    *((int *)(_2+728)) = _11103;
    RefDS(_11104);
    *((int *)(_2+732)) = _11104;
    RefDS(_11105);
    *((int *)(_2+736)) = _11105;
    RefDS(_11106);
    *((int *)(_2+740)) = _11106;
    RefDS(_11107);
    *((int *)(_2+744)) = _11107;
    RefDS(_11108);
    *((int *)(_2+748)) = _11108;
    RefDS(_11109);
    *((int *)(_2+752)) = _11109;
    RefDS(_11110);
    *((int *)(_2+756)) = _11110;
    RefDS(_11111);
    *((int *)(_2+760)) = _11111;
    RefDS(_11112);
    *((int *)(_2+764)) = _11112;
    RefDS(_11113);
    *((int *)(_2+768)) = _11113;
    RefDS(_11114);
    *((int *)(_2+772)) = _11114;
    RefDS(_11115);
    *((int *)(_2+776)) = _11115;
    RefDS(_11116);
    *((int *)(_2+780)) = _11116;
    RefDS(_11117);
    *((int *)(_2+784)) = _11117;
    RefDS(_11118);
    *((int *)(_2+788)) = _11118;
    RefDS(_11119);
    *((int *)(_2+792)) = _11119;
    RefDS(_11120);
    *((int *)(_2+796)) = _11120;
    RefDS(_11121);
    *((int *)(_2+800)) = _11121;
    RefDS(_11122);
    *((int *)(_2+804)) = _11122;
    RefDS(_11123);
    *((int *)(_2+808)) = _11123;
    RefDS(_11124);
    *((int *)(_2+812)) = _11124;
    RefDS(_11125);
    *((int *)(_2+816)) = _11125;
    RefDS(_11126);
    *((int *)(_2+820)) = _11126;
    RefDS(_11127);
    *((int *)(_2+824)) = _11127;
    RefDS(_11128);
    *((int *)(_2+828)) = _11128;
    RefDS(_11129);
    *((int *)(_2+832)) = _11129;
    _44posix_names_20042 = MAKE_SEQ(_1);
    RefDS(_44posix_names_20042);
    _44locale_canonical_20045 = _44posix_names_20042;

    /** ifdef UNIX then*/
    RefDS(_44posix_names_20042);
    _44platform_locale_20046 = _44posix_names_20042;
    DeRef1(_43def_lang_20094);
    _43def_lang_20094 = 0;
    DeRef1(_43lang_path_20095);
    _43lang_path_20095 = 0;

    /** ifdef WINDOWS then*/
    RefDS(_5);
    _43lib_20256 = _13open_dll(_5);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 16777220;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 50331656;
    _11476 = MAKE_SEQ(_1);
    Ref(_43lib_20256);
    RefDS(_11475);
    _43f_strfmon_20258 = _13define_c_func(_43lib_20256, _11475, _11476, 16777220);
    _11476 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777220;
    ((int *)_2)[2] = 33554436;
    _11478 = MAKE_SEQ(_1);
    Ref(_43lib_20256);
    RefDS(_11472);
    _43f_setlocale_20263 = _13define_c_func(_43lib_20256, _11472, _11478, 33554436);
    _11478 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    *((int *)(_2+8)) = 16777220;
    *((int *)(_2+12)) = 33554436;
    *((int *)(_2+16)) = 33554436;
    _11480 = MAKE_SEQ(_1);
    Ref(_43lib_20256);
    RefDS(_11473);
    _43f_strftime_20266 = _13define_c_func(_43lib_20256, _11473, _11480, 16777220);
    _11480 = NOVALUE;

    /** ifdef WINDOWS then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_11482);
    *((int *)(_2+4)) = _11482;
    RefDS(_11483);
    *((int *)(_2+8)) = _11483;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _11634 = MAKE_SEQ(_1);
    _46STDLIB_20575 = _13open_dll(_11634);
    _11634 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _11637 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11636);
    _46PIPE_20578 = _13define_c_func(_46STDLIB_20575, _11636, _11637, 16777220);
    _11637 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 16777220;
    _11640 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11639);
    _46READ_20582 = _13define_c_func(_46STDLIB_20575, _11639, _11640, 16777220);
    _11640 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    *((int *)(_2+8)) = 33554436;
    *((int *)(_2+12)) = 16777220;
    _11643 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11642);
    _46WRITE_20586 = _13define_c_func(_46STDLIB_20575, _11642, _11643, 16777220);
    _11643 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 16777220;
    _11646 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11645);
    _46CLOSE_20590 = _13define_c_func(_46STDLIB_20575, _11645, _11646, 16777220);
    _11646 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777220;
    ((int *)_2)[2] = 16777220;
    _11649 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11648);
    _46DUP2_20594 = _13define_c_func(_46STDLIB_20575, _11648, _11649, 16777220);
    _11649 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777220;
    ((int *)_2)[2] = 16777220;
    _11652 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11651);
    _46KILL_20598 = _13define_c_func(_46STDLIB_20575, _11651, _11652, 16777220);
    _11652 = NOVALUE;
    Ref(_46STDLIB_20575);
    RefDS(_11654);
    RefDS(_5);
    _46FORK_20602 = _13define_c_func(_46STDLIB_20575, _11654, _5, 16777220);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 33554436;
    ((int *)_2)[2] = 33554436;
    _11657 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11656);
    _46EXECV_20605 = _13define_c_func(_46STDLIB_20575, _11656, _11657, 16777220);
    _11657 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777220;
    ((int *)_2)[2] = 33554436;
    _11660 = MAKE_SEQ(_1);
    Ref(_46STDLIB_20575);
    RefDS(_11659);
    _46SIGNAL_20609 = _13define_c_func(_46STDLIB_20575, _11659, _11660, 33554436);
    _11660 = NOVALUE;

    /** 	return machine_func(M_DEFINE_VAR, {lib, variable_name})*/
    RefDS(_11662);
    Ref(_46STDLIB_20575);
    DeRef1(_46define_c_var_1__tmp_at3239_20617);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _46STDLIB_20575;
    ((int *)_2)[2] = _11662;
    _46define_c_var_1__tmp_at3239_20617 = MAKE_SEQ(_1);
    _46ERRNO_20613 = machine(56, _46define_c_var_1__tmp_at3239_20617);
    DeRef1(_46define_c_var_1__tmp_at3239_20617);
    _46define_c_var_1__tmp_at3239_20617 = NOVALUE;
    DeRef1(_46os_errno_20630);
    _46os_errno_20630 = 0;

    /** ifdef WINDOWS then*/
    RefDS(_11818);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _11818;
    _11819 = MAKE_SEQ(_1);
    RefDS(_11820);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _11820;
    _11821 = MAKE_SEQ(_1);
    RefDS(_11822);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _11822;
    _11823 = MAKE_SEQ(_1);
    RefDS(_11824);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _11824;
    _11825 = MAKE_SEQ(_1);
    RefDS(_11826);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8;
    ((int *)_2)[2] = _11826;
    _11827 = MAKE_SEQ(_1);
    RefDS(_11828);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16;
    ((int *)_2)[2] = _11828;
    _11829 = MAKE_SEQ(_1);
    RefDS(_11830);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 32;
    ((int *)_2)[2] = _11830;
    _11831 = MAKE_SEQ(_1);
    RefDS(_11832);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 64;
    ((int *)_2)[2] = _11832;
    _11833 = MAKE_SEQ(_1);
    RefDS(_11834);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 128;
    ((int *)_2)[2] = _11834;
    _11835 = MAKE_SEQ(_1);
    RefDS(_11836);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 256;
    ((int *)_2)[2] = _11836;
    _11837 = MAKE_SEQ(_1);
    RefDS(_11838);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 512;
    ((int *)_2)[2] = _11838;
    _11839 = MAKE_SEQ(_1);
    RefDS(_11840);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1024;
    ((int *)_2)[2] = _11840;
    _11841 = MAKE_SEQ(_1);
    RefDS(_11842);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2048;
    ((int *)_2)[2] = _11842;
    _11843 = MAKE_SEQ(_1);
    RefDS(_11844);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4096;
    ((int *)_2)[2] = _11844;
    _11845 = MAKE_SEQ(_1);
    RefDS(_11846);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8192;
    ((int *)_2)[2] = _11846;
    _11847 = MAKE_SEQ(_1);
    RefDS(_11848);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16384;
    ((int *)_2)[2] = _11848;
    _11849 = MAKE_SEQ(_1);
    RefDS(_11850);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 32768;
    ((int *)_2)[2] = _11850;
    _11851 = MAKE_SEQ(_1);
    RefDS(_11852);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 65536;
    ((int *)_2)[2] = _11852;
    _11853 = MAKE_SEQ(_1);
    RefDS(_11854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 131072;
    ((int *)_2)[2] = _11854;
    _11855 = MAKE_SEQ(_1);
    RefDS(_11856);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 262144;
    ((int *)_2)[2] = _11856;
    _11857 = MAKE_SEQ(_1);
    RefDS(_11858);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 524288;
    ((int *)_2)[2] = _11858;
    _11859 = MAKE_SEQ(_1);
    RefDS(_11860);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1048576;
    ((int *)_2)[2] = _11860;
    _11861 = MAKE_SEQ(_1);
    RefDS(_11862);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2097152;
    ((int *)_2)[2] = _11862;
    _11863 = MAKE_SEQ(_1);
    RefDS(_11864);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3145728;
    ((int *)_2)[2] = _11864;
    _11865 = MAKE_SEQ(_1);
    RefDS(_11866);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4194304;
    ((int *)_2)[2] = _11866;
    _11867 = MAKE_SEQ(_1);
    RefDS(_11868);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5242880;
    ((int *)_2)[2] = _11868;
    _11869 = MAKE_SEQ(_1);
    RefDS(_11870);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 8388608;
    ((int *)_2)[2] = _11870;
    _11871 = MAKE_SEQ(_1);
    RefDS(_11872);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 16777216;
    ((int *)_2)[2] = _11872;
    _11873 = MAKE_SEQ(_1);
    RefDS(_11874);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 201326592;
    ((int *)_2)[2] = _11874;
    _11875 = MAKE_SEQ(_1);
    _1 = NewS1(29);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _11819;
    *((int *)(_2+8)) = _11821;
    *((int *)(_2+12)) = _11823;
    *((int *)(_2+16)) = _11825;
    *((int *)(_2+20)) = _11827;
    *((int *)(_2+24)) = _11829;
    *((int *)(_2+28)) = _11831;
    *((int *)(_2+32)) = _11833;
    *((int *)(_2+36)) = _11835;
    *((int *)(_2+40)) = _11837;
    *((int *)(_2+44)) = _11839;
    *((int *)(_2+48)) = _11841;
    *((int *)(_2+52)) = _11843;
    *((int *)(_2+56)) = _11845;
    *((int *)(_2+60)) = _11847;
    *((int *)(_2+64)) = _11849;
    *((int *)(_2+68)) = _11851;
    *((int *)(_2+72)) = _11853;
    *((int *)(_2+76)) = _11855;
    *((int *)(_2+80)) = _11857;
    *((int *)(_2+84)) = _11859;
    *((int *)(_2+88)) = _11861;
    *((int *)(_2+92)) = _11863;
    *((int *)(_2+96)) = _11865;
    *((int *)(_2+100)) = _11867;
    *((int *)(_2+104)) = _11869;
    *((int *)(_2+108)) = _11871;
    *((int *)(_2+112)) = _11873;
    *((int *)(_2+116)) = _11875;
    _47option_names_20940 = MAKE_SEQ(_1);
    _11875 = NOVALUE;
    _11873 = NOVALUE;
    _11871 = NOVALUE;
    _11869 = NOVALUE;
    _11867 = NOVALUE;
    _11865 = NOVALUE;
    _11863 = NOVALUE;
    _11861 = NOVALUE;
    _11859 = NOVALUE;
    _11857 = NOVALUE;
    _11855 = NOVALUE;
    _11853 = NOVALUE;
    _11851 = NOVALUE;
    _11849 = NOVALUE;
    _11847 = NOVALUE;
    _11845 = NOVALUE;
    _11843 = NOVALUE;
    _11841 = NOVALUE;
    _11839 = NOVALUE;
    _11837 = NOVALUE;
    _11835 = NOVALUE;
    _11833 = NOVALUE;
    _11831 = NOVALUE;
    _11829 = NOVALUE;
    _11827 = NOVALUE;
    _11825 = NOVALUE;
    _11823 = NOVALUE;
    _11821 = NOVALUE;
    _11819 = NOVALUE;
    RefDS(_11893);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _11893;
    _11894 = MAKE_SEQ(_1);
    RefDS(_11895);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _11895;
    _11896 = MAKE_SEQ(_1);
    RefDS(_11897);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -3;
    ((int *)_2)[2] = _11897;
    _11898 = MAKE_SEQ(_1);
    RefDS(_11899);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -4;
    ((int *)_2)[2] = _11899;
    _11900 = MAKE_SEQ(_1);
    RefDS(_11901);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -5;
    ((int *)_2)[2] = _11901;
    _11902 = MAKE_SEQ(_1);
    RefDS(_11901);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -5;
    ((int *)_2)[2] = _11901;
    _11903 = MAKE_SEQ(_1);
    RefDS(_11904);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -6;
    ((int *)_2)[2] = _11904;
    _11905 = MAKE_SEQ(_1);
    RefDS(_11906);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -7;
    ((int *)_2)[2] = _11906;
    _11907 = MAKE_SEQ(_1);
    RefDS(_11908);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -8;
    ((int *)_2)[2] = _11908;
    _11909 = MAKE_SEQ(_1);
    RefDS(_11910);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -9;
    ((int *)_2)[2] = _11910;
    _11911 = MAKE_SEQ(_1);
    RefDS(_11912);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -10;
    ((int *)_2)[2] = _11912;
    _11913 = MAKE_SEQ(_1);
    RefDS(_11914);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -11;
    ((int *)_2)[2] = _11914;
    _11915 = MAKE_SEQ(_1);
    RefDS(_11916);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -12;
    ((int *)_2)[2] = _11916;
    _11917 = MAKE_SEQ(_1);
    RefDS(_11918);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -13;
    ((int *)_2)[2] = _11918;
    _11919 = MAKE_SEQ(_1);
    RefDS(_11920);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -14;
    ((int *)_2)[2] = _11920;
    _11921 = MAKE_SEQ(_1);
    RefDS(_11922);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -15;
    ((int *)_2)[2] = _11922;
    _11923 = MAKE_SEQ(_1);
    RefDS(_11924);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -16;
    ((int *)_2)[2] = _11924;
    _11925 = MAKE_SEQ(_1);
    RefDS(_11926);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -17;
    ((int *)_2)[2] = _11926;
    _11927 = MAKE_SEQ(_1);
    RefDS(_11928);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -18;
    ((int *)_2)[2] = _11928;
    _11929 = MAKE_SEQ(_1);
    RefDS(_11930);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -19;
    ((int *)_2)[2] = _11930;
    _11931 = MAKE_SEQ(_1);
    RefDS(_11932);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -20;
    ((int *)_2)[2] = _11932;
    _11933 = MAKE_SEQ(_1);
    RefDS(_11934);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -21;
    ((int *)_2)[2] = _11934;
    _11935 = MAKE_SEQ(_1);
    RefDS(_11936);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -22;
    ((int *)_2)[2] = _11936;
    _11937 = MAKE_SEQ(_1);
    RefDS(_11938);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -23;
    ((int *)_2)[2] = _11938;
    _11939 = MAKE_SEQ(_1);
    _1 = NewS1(24);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _11894;
    *((int *)(_2+8)) = _11896;
    *((int *)(_2+12)) = _11898;
    *((int *)(_2+16)) = _11900;
    *((int *)(_2+20)) = _11902;
    *((int *)(_2+24)) = _11903;
    *((int *)(_2+28)) = _11905;
    *((int *)(_2+32)) = _11907;
    *((int *)(_2+36)) = _11909;
    *((int *)(_2+40)) = _11911;
    *((int *)(_2+44)) = _11913;
    *((int *)(_2+48)) = _11915;
    *((int *)(_2+52)) = _11917;
    *((int *)(_2+56)) = _11919;
    *((int *)(_2+60)) = _11921;
    *((int *)(_2+64)) = _11923;
    *((int *)(_2+68)) = _11925;
    *((int *)(_2+72)) = _11927;
    *((int *)(_2+76)) = _11929;
    *((int *)(_2+80)) = _11931;
    *((int *)(_2+84)) = _11933;
    *((int *)(_2+88)) = _11935;
    *((int *)(_2+92)) = _11937;
    *((int *)(_2+96)) = _11939;
    _47error_names_21040 = MAKE_SEQ(_1);
    _11939 = NOVALUE;
    _11937 = NOVALUE;
    _11935 = NOVALUE;
    _11933 = NOVALUE;
    _11931 = NOVALUE;
    _11929 = NOVALUE;
    _11927 = NOVALUE;
    _11925 = NOVALUE;
    _11923 = NOVALUE;
    _11921 = NOVALUE;
    _11919 = NOVALUE;
    _11917 = NOVALUE;
    _11915 = NOVALUE;
    _11913 = NOVALUE;
    _11911 = NOVALUE;
    _11909 = NOVALUE;
    _11907 = NOVALUE;
    _11905 = NOVALUE;
    _11903 = NOVALUE;
    _11902 = NOVALUE;
    _11900 = NOVALUE;
    _11898 = NOVALUE;
    _11896 = NOVALUE;
    _11894 = NOVALUE;
    _1 = NewS1(29);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = 2;
    *((int *)(_2+16)) = 4;
    *((int *)(_2+20)) = 8;
    *((int *)(_2+24)) = 16;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 64;
    *((int *)(_2+36)) = 128;
    *((int *)(_2+40)) = 256;
    *((int *)(_2+44)) = 512;
    *((int *)(_2+48)) = 1024;
    *((int *)(_2+52)) = 2048;
    *((int *)(_2+56)) = 4096;
    *((int *)(_2+60)) = 8192;
    *((int *)(_2+64)) = 16384;
    *((int *)(_2+68)) = 32768;
    *((int *)(_2+72)) = 65536;
    *((int *)(_2+76)) = 131072;
    *((int *)(_2+80)) = 262144;
    *((int *)(_2+84)) = 524288;
    *((int *)(_2+88)) = 1048576;
    *((int *)(_2+92)) = 2097152;
    *((int *)(_2+96)) = 3145728;
    *((int *)(_2+100)) = 4194304;
    *((int *)(_2+104)) = 5242880;
    *((int *)(_2+108)) = 8388608;
    *((int *)(_2+112)) = 16777216;
    *((int *)(_2+116)) = 201326592;
    _11941 = MAKE_SEQ(_1);
    _47all_options_21089 = _20or_all(_11941);
    _11941 = NOVALUE;
    DeRef1(_1options_inlined_new_at_3594_24911);
    _1options_inlined_new_at_3594_24911 = 0;

    /** 	if sequence(options) then */
    _1new_1__tmp_at3597_24912 = 0;
    if (_1new_1__tmp_at3597_24912 == 0)
    {
        goto L1; // [3603] 3613
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(0);
    _1options_inlined_new_at_3594_24911 = _0;
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_3594_24911);
    RefDS(_12139);
    DeRef1(_1new_2__tmp_at3597_24913);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12139;
    ((int *)_2)[2] = _1options_inlined_new_at_3594_24911;
    _1new_2__tmp_at3597_24913 = MAKE_SEQ(_1);
    _49re_ip_21545 = machine(68, _1new_2__tmp_at3597_24913);
    DeRef1(_1options_inlined_new_at_3594_24911);
    _1options_inlined_new_at_3594_24911 = NOVALUE;
    DeRef1(_1new_2__tmp_at3597_24913);
    _1new_2__tmp_at3597_24913 = NOVALUE;
    DeRef1(_1options_inlined_new_at_3625_24915);
    _1options_inlined_new_at_3625_24915 = 1;

    /** 	if sequence(options) then */
    _1new_1__tmp_at3628_24916 = 0;
    if (_1new_1__tmp_at3628_24916 == 0)
    {
        goto L2; // [3634] 3644
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(1);
    _1options_inlined_new_at_3625_24915 = _0;
L2: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_3625_24915);
    RefDS(_12141);
    DeRef1(_1new_2__tmp_at3628_24917);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12141;
    ((int *)_2)[2] = _1options_inlined_new_at_3625_24915;
    _1new_2__tmp_at3628_24917 = MAKE_SEQ(_1);
    _49re_http_url_21548 = machine(68, _1new_2__tmp_at3628_24917);
    DeRef1(_1options_inlined_new_at_3625_24915);
    _1options_inlined_new_at_3625_24915 = NOVALUE;
    DeRef1(_1new_2__tmp_at3628_24917);
    _1new_2__tmp_at3628_24917 = NOVALUE;
    DeRef1(_1options_inlined_new_at_3656_24919);
    _1options_inlined_new_at_3656_24919 = 0;

    /** 	if sequence(options) then */
    _1new_1__tmp_at3659_24920 = 0;
    if (_1new_1__tmp_at3659_24920 == 0)
    {
        goto L3; // [3665] 3675
    }
    else{
    }

    /** 		options = math:or_all(options) */
    _0 = _20or_all(0);
    _1options_inlined_new_at_3656_24919 = _0;
L3: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_1options_inlined_new_at_3656_24919);
    RefDS(_12143);
    DeRef1(_1new_2__tmp_at3659_24921);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12143;
    ((int *)_2)[2] = _1options_inlined_new_at_3656_24919;
    _1new_2__tmp_at3659_24921 = MAKE_SEQ(_1);
    _49re_mail_url_21551 = machine(68, _1new_2__tmp_at3659_24921);
    DeRef1(_1options_inlined_new_at_3656_24919);
    _1options_inlined_new_at_3656_24919 = NOVALUE;
    DeRef1(_1new_2__tmp_at3659_24921);
    _1new_2__tmp_at3659_24921 = NOVALUE;
    _0 = _48info(1);
    DeRef1(_48sockinfo_21741);
    _48sockinfo_21741 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_UNSPEC_21744 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_UNIX_21746 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_INET_21748 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_INET6_21750 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_APPLETALK_21752 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48AF_BTH_21754 = (int)*(((s1_ptr)_2)->base + 5);

    /** sockinfo = info(ESOCK_TYPE_TYPE)*/
    _0 = _48info(2);
    DeRef1(_48sockinfo_21741);
    _48sockinfo_21741 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOCK_STREAM_21758 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOCK_DGRAM_21760 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOCK_RAW_21762 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOCK_RDM_21764 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOCK_SEQPACKET_21766 = (int)*(((s1_ptr)_2)->base + 5);

    /** sockinfo = info(ESOCK_TYPE_OPTION)*/
    _0 = _48info(3);
    DeRef1(_48sockinfo_21741);
    _48sockinfo_21741 = _0;
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SOL_SOCKET_21881 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DEBUG_21883 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_ACCEPTCONN_21885 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_REUSEADDR_21887 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_KEEPALIVE_21889 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DONTROUTE_21891 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_BROADCAST_21893 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_LINGER_21895 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SNDBUF_21897 = (int)*(((s1_ptr)_2)->base + 9);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_RCVBUF_21899 = (int)*(((s1_ptr)_2)->base + 10);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SNDLOWAT_21901 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_RCVLOWAT_21903 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SNDTIMEO_21905 = (int)*(((s1_ptr)_2)->base + 13);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_RCVTIMEO_21907 = (int)*(((s1_ptr)_2)->base + 14);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_ERROR_21909 = (int)*(((s1_ptr)_2)->base + 15);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_TYPE_21911 = (int)*(((s1_ptr)_2)->base + 16);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_OOBINLINE_21913 = (int)*(((s1_ptr)_2)->base + 17);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_USELOOPBACK_21915 = (int)*(((s1_ptr)_2)->base + 18);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DONTLINGER_21917 = (int)*(((s1_ptr)_2)->base + 19);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_REUSEPORT_21919 = (int)*(((s1_ptr)_2)->base + 20);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_CONNDATA_21921 = (int)*(((s1_ptr)_2)->base + 21);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_CONNOPT_21923 = (int)*(((s1_ptr)_2)->base + 22);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DISCDATA_21925 = (int)*(((s1_ptr)_2)->base + 23);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DISCOPT_21927 = (int)*(((s1_ptr)_2)->base + 24);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_CONNDATALEN_21929 = (int)*(((s1_ptr)_2)->base + 25);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_CONNOPTLEN_21931 = (int)*(((s1_ptr)_2)->base + 26);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DISCDATALEN_21933 = (int)*(((s1_ptr)_2)->base + 27);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DISCOPTLEN_21935 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_OPENTYPE_21937 = (int)*(((s1_ptr)_2)->base + 29);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_MAXDG_21939 = (int)*(((s1_ptr)_2)->base + 30);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_MAXPATHDG_21941 = (int)*(((s1_ptr)_2)->base + 31);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SYNCHRONOUS_ALTERT_21943 = (int)*(((s1_ptr)_2)->base + 32);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SYNCHRONOUS_NONALERT_21945 = (int)*(((s1_ptr)_2)->base + 33);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SNDBUFFORCE_21947 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_RCVBUFFORCE_21949 = (int)*(((s1_ptr)_2)->base + 35);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_NO_CHECK_21951 = (int)*(((s1_ptr)_2)->base + 36);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PRIORITY_21953 = (int)*(((s1_ptr)_2)->base + 37);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_BSDCOMPAT_21955 = (int)*(((s1_ptr)_2)->base + 38);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PASSCRED_21957 = (int)*(((s1_ptr)_2)->base + 39);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PEERCRED_21959 = (int)*(((s1_ptr)_2)->base + 40);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SECURITY_AUTHENTICATION_21961 = (int)*(((s1_ptr)_2)->base + 41);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SECURITY_ENCRYPTION_TRANSPORT_21963 = (int)*(((s1_ptr)_2)->base + 42);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_SECURITY_ENCRYPTION_NETWORK_21965 = (int)*(((s1_ptr)_2)->base + 43);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_BINDTODEVICE_21967 = (int)*(((s1_ptr)_2)->base + 44);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_ATTACH_FILTER_21969 = (int)*(((s1_ptr)_2)->base + 45);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DETACH_FILTER_21971 = (int)*(((s1_ptr)_2)->base + 46);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PEERNAME_21973 = (int)*(((s1_ptr)_2)->base + 47);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_TIMESTAMP_21975 = (int)*(((s1_ptr)_2)->base + 48);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SCM_TIMESTAMP_21977 = (int)*(((s1_ptr)_2)->base + 49);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PEERSEC_21979 = (int)*(((s1_ptr)_2)->base + 50);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PASSSEC_21981 = (int)*(((s1_ptr)_2)->base + 51);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_TIMESTAMPNS_21983 = (int)*(((s1_ptr)_2)->base + 52);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SCM_TIMESTAMPNS_21985 = (int)*(((s1_ptr)_2)->base + 53);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_MARK_21987 = (int)*(((s1_ptr)_2)->base + 54);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_TIMESTAMPING_21989 = (int)*(((s1_ptr)_2)->base + 55);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SCM_TIMESTAMPING_21991 = (int)*(((s1_ptr)_2)->base + 56);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_PROTOCOL_21993 = (int)*(((s1_ptr)_2)->base + 57);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_DOMAIN_21995 = (int)*(((s1_ptr)_2)->base + 58);
    _2 = (int)SEQ_PTR(_48sockinfo_21741);
    _48SO_RXQ_OVFL_21997 = (int)*(((s1_ptr)_2)->base + 59);
    _48delete_socket_rid_22054 = CRoutineId(737, 48, _12361);
    _12764 = _3version_major();
    _12765 = _3version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12764;
    ((int *)_2)[2] = _12765;
    _12766 = MAKE_SEQ(_1);
    _12765 = NOVALUE;
    _12764 = NOVALUE;
    _54USER_AGENT_HEADER_22921 = EPrintf(-9999999, _12763, _12766);
    DeRef1(_12766);
    _12766 = NOVALUE;
    RefDS(_12774);
    RefDS(_12773);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12773;
    ((int *)_2)[2] = _12774;
    _54ENCODING_STRINGS_22951 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_54rand_chars_23106)){
            _54rand_chars_len_23108 = SEQ_PTR(_54rand_chars_23106)->length;
    }
    else {
        _54rand_chars_len_23108 = 1;
    }

    /** ifdef WINDOWS then*/
    _13023 = power(2, 32);
    if (IS_ATOM_INT(_13023)) {
        _59MAX_ADDR_23458 = _13023 - 1;
        if ((long)((unsigned long)_59MAX_ADDR_23458 +(unsigned long) HIGH_BITS) >= 0){
            _59MAX_ADDR_23458 = NewDouble((double)_59MAX_ADDR_23458);
        }
    }
    else {
        _59MAX_ADDR_23458 = NewDouble(DBL_PTR(_13023)->dbl - (double)1);
    }
    DeRef1(_13023);
    _13023 = NOVALUE;
    _13025 = 1048576;
    _59LOW_ADDR_23461 = 1048575;
    _13025 = NOVALUE;

    /** mem = allocate(4)*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef1(_59mem_23533);
    _59mem_23533 = machine(16, 4);

    /** check_calls = 1*/
    _59check_calls_23622 = 1;

    /** always_linked_list = 0*/
    _58always_linked_list_23632 = 0;

    /** init()*/

    /** 	high_address = 0*/
    _1high_address_23974 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef1(_1data_23975);
    _1data_23975 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef1(_1free_list_23976);
    _1free_list_23976 = _5;

    /** end procedure*/
    goto L4; // [4323] 4326
L4: 
    ;
}
// GenerateUserRoutines

// 0x745882B1
