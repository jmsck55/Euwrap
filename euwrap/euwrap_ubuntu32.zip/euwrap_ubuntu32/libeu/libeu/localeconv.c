// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _44canonical(int _new_locale_20049)
{
    int _w_20050 = NOVALUE;
    int _ws_20051 = NOVALUE;
    int _p_20052 = NOVALUE;
    int _n_20053 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	p = find(new_locale, posix_names)*/
    _p_20052 = find_from(_new_locale_20049, _44posix_names_20042, 1);

    /** 	w = find(new_locale, w32_names)*/
    _w_20050 = find_from(_new_locale_20049, _44w32_names_19811, 1);

    /** 	ws = find(new_locale, w32_name_canonical)*/
    _ws_20051 = find_from(_new_locale_20049, _44w32_name_canonical_20021, 1);

    /** 	if p != 0 then*/
    if (_p_20052 == 0)
    goto L1; // [34] 46

    /** 		n = p*/
    _n_20053 = _p_20052;
    goto L2; // [43] 81
L1: 

    /** 	elsif w != 0 then*/
    if (_w_20050 == 0)
    goto L3; // [48] 60

    /** 		n = w*/
    _n_20053 = _w_20050;
    goto L2; // [57] 81
L3: 

    /** 	elsif ws != 0 then*/
    if (_ws_20051 == 0)
    goto L4; // [62] 74

    /** 		n = ws*/
    _n_20053 = _ws_20051;
    goto L2; // [71] 81
L4: 

    /** 		return new_locale*/
    return _new_locale_20049;
L2: 

    /** 	new_locale = locale_canonical[n]*/
    DeRefDS(_new_locale_20049);
    _2 = (int)SEQ_PTR(_44locale_canonical_20045);
    _new_locale_20049 = (int)*(((s1_ptr)_2)->base + _n_20053);
    RefDS(_new_locale_20049);

    /** 	ifdef WINDOWS then*/

    /** 	return new_locale*/
    return _new_locale_20049;
    ;
}
int canonical() __attribute__ ((alias ("_44canonical")));


int _44decanonical(int _new_locale_20067)
{
    int _w_20068 = NOVALUE;
    int _ws_20069 = NOVALUE;
    int _p_20070 = NOVALUE;
    int _n_20071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	p = find(new_locale, posix_names)*/
    _p_20070 = find_from(_new_locale_20067, _44posix_names_20042, 1);

    /** 	w = find(new_locale, w32_names)*/
    _w_20068 = find_from(_new_locale_20067, _44w32_names_19811, 1);

    /** 	ws = find(new_locale, w32_name_canonical)*/
    _ws_20069 = find_from(_new_locale_20067, _44w32_name_canonical_20021, 1);

    /** 	if p != 0 then*/
    if (_p_20070 == 0)
    goto L1; // [34] 46

    /** 		n = p*/
    _n_20071 = _p_20070;
    goto L2; // [43] 81
L1: 

    /** 	elsif w != 0 then*/
    if (_w_20068 == 0)
    goto L3; // [48] 60

    /** 		n = w*/
    _n_20071 = _w_20068;
    goto L2; // [57] 81
L3: 

    /** 	elsif ws != 0 then*/
    if (_ws_20069 == 0)
    goto L4; // [62] 74

    /** 		n = ws*/
    _n_20071 = _ws_20069;
    goto L2; // [71] 81
L4: 

    /** 		return new_locale*/
    return _new_locale_20067;
L2: 

    /** 	new_locale = platform_locale[n]*/
    DeRefDS(_new_locale_20067);
    _2 = (int)SEQ_PTR(_44platform_locale_20046);
    _new_locale_20067 = (int)*(((s1_ptr)_2)->base + _n_20071);
    RefDS(_new_locale_20067);

    /** 	ifdef WINDOWS then*/

    /** 	return new_locale*/
    return _new_locale_20067;
    ;
}
int decanonical() __attribute__ ((alias ("_44decanonical")));


int _44canon2win(int _new_locale_20085)
{
    int _w_20086 = NOVALUE;
    int _n_20087 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	w = find(new_locale, posix_names)*/
    _w_20086 = find_from(_new_locale_20085, _44posix_names_20042, 1);

    /** 	if w = 0 then*/
    if (_w_20086 != 0)
    goto L1; // [16] 27

    /** 		return "C"*/
    RefDS(_11130);
    DeRefDS(_new_locale_20085);
    return _11130;
L1: 

    /** 	new_locale = w32_names[w]*/
    DeRefDS(_new_locale_20085);
    _2 = (int)SEQ_PTR(_44w32_names_19811);
    _new_locale_20085 = (int)*(((s1_ptr)_2)->base + _w_20086);
    RefDS(_new_locale_20085);

    /** 	ifdef WINDOWS then*/

    /** 	return new_locale*/
    return _new_locale_20085;
    ;
}
int canon2win() __attribute__ ((alias ("_44canon2win")));



// 0x030DD85C
