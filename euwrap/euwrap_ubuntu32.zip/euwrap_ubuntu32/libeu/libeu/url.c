// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _55parse_querystring(int _query_string_22671)
{
    int _i_22672 = NOVALUE;
    int _char_22673 = NOVALUE;
    int _tmp_22674 = NOVALUE;
    int _charbuf_22675 = NOVALUE;
    int _fname_22676 = NOVALUE;
    int _the_map_22677 = NOVALUE;
    int _value_inlined_value_at_100_22696 = NOVALUE;
    int _st_inlined_value_at_97_22695 = NOVALUE;
    int _12635 = NOVALUE;
    int _12628 = NOVALUE;
    int _12627 = NOVALUE;
    int _12626 = NOVALUE;
    int _12625 = NOVALUE;
    int _12624 = NOVALUE;
    int _12623 = NOVALUE;
    int _12617 = NOVALUE;
    int _12616 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence charbuf, fname=""*/
    RefDS(_5);
    DeRef(_fname_22676);
    _fname_22676 = _5;

    /** 	map:map the_map = map:new()*/
    _0 = _the_map_22677;
    _the_map_22677 = _33new(690);
    DeRef(_0);

    /** 	if atom(query_string) then*/
    _12616 = IS_ATOM(_query_string_22671);
    if (_12616 == 0)
    {
        _12616 = NOVALUE;
        goto L1; // [19] 29
    }
    else{
        _12616 = NOVALUE;
    }

    /** 		return the_map*/
    DeRef(_query_string_22671);
    DeRef(_tmp_22674);
    DeRef(_charbuf_22675);
    DeRefDS(_fname_22676);
    return _the_map_22677;
L1: 

    /** 	charbuf = {}  */
    RefDS(_5);
    DeRef(_charbuf_22675);
    _charbuf_22675 = _5;

    /** 	i = 1*/
    _i_22672 = 1;

    /** 	while i <= length(query_string) do*/
L2: 
    if (IS_SEQUENCE(_query_string_22671)){
            _12617 = SEQ_PTR(_query_string_22671)->length;
    }
    else {
        _12617 = 1;
    }
    if (_i_22672 > _12617)
    goto L3; // [49] 221

    /** 		char = query_string[i]  -- character we're working on*/
    _2 = (int)SEQ_PTR(_query_string_22671);
    _char_22673 = (int)*(((s1_ptr)_2)->base + _i_22672);
    if (!IS_ATOM_INT(_char_22673)){
        _char_22673 = (long)DBL_PTR(_char_22673)->dbl;
    }

    /** 		switch char do*/
    _0 = _char_22673;
    switch ( _0 ){ 

        /** 			case HEX_SIG then*/
        case 37:

        /** 				tmp = stdget:value("#" & query_string[i+1] & query_string[i+2])*/
        _12623 = _i_22672 + 1;
        _2 = (int)SEQ_PTR(_query_string_22671);
        _12624 = (int)*(((s1_ptr)_2)->base + _12623);
        _12625 = _i_22672 + 2;
        _2 = (int)SEQ_PTR(_query_string_22671);
        _12626 = (int)*(((s1_ptr)_2)->base + _12625);
        {
            int concat_list[3];

            concat_list[0] = _12626;
            concat_list[1] = _12624;
            concat_list[2] = _12622;
            Concat_N((object_ptr)&_12627, concat_list, 3);
        }
        _12626 = NOVALUE;
        _12624 = NOVALUE;
        DeRef(_st_inlined_value_at_97_22695);
        _st_inlined_value_at_97_22695 = _12627;
        _12627 = NOVALUE;
        if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
            _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
            DeRefDS(_17GET_SHORT_ANSWER_3238);
            _17GET_SHORT_ANSWER_3238 = _1;
        }

        /** 	return get_value(st, start_point, answer)*/
        RefDS(_st_inlined_value_at_97_22695);
        _0 = _tmp_22674;
        _tmp_22674 = _17get_value(_st_inlined_value_at_97_22695, 1, _17GET_SHORT_ANSWER_3238);
        DeRef(_0);
        DeRef(_st_inlined_value_at_97_22695);
        _st_inlined_value_at_97_22695 = NOVALUE;

        /** 				charbuf &= tmp[2]*/
        _2 = (int)SEQ_PTR(_tmp_22674);
        _12628 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_charbuf_22675) && IS_ATOM(_12628)) {
            Ref(_12628);
            Append(&_charbuf_22675, _charbuf_22675, _12628);
        }
        else if (IS_ATOM(_charbuf_22675) && IS_SEQUENCE(_12628)) {
        }
        else {
            Concat((object_ptr)&_charbuf_22675, _charbuf_22675, _12628);
        }
        _12628 = NOVALUE;

        /** 				i += 2 -- skip over hex digits*/
        _i_22672 = _i_22672 + 2;
        goto L4; // [132] 210

        /** 			case WHITESPACE then*/
        case 43:

        /** 				charbuf &= " "*/
        Concat((object_ptr)&_charbuf_22675, _charbuf_22675, _12631);
        goto L4; // [144] 210

        /** 			case VALUE_SEP then*/
        case 61:

        /** 				fname = charbuf*/
        RefDS(_charbuf_22675);
        DeRef(_fname_22676);
        _fname_22676 = _charbuf_22675;

        /** 				charbuf = {}*/
        RefDS(_5);
        DeRefDS(_charbuf_22675);
        _charbuf_22675 = _5;
        goto L4; // [164] 210

        /** 			case PAIR_SEP_A, PAIR_SEP_B then*/
        case 38:
        case 59:

        /** 				map:put(the_map, fname, charbuf)*/
        Ref(_the_map_22677);
        RefDS(_fname_22676);
        RefDS(_charbuf_22675);
        _33put(_the_map_22677, _fname_22676, _charbuf_22675, 1, _33threshold_size_12820);

        /** 				fname = {}*/
        RefDS(_5);
        DeRefDS(_fname_22676);
        _fname_22676 = _5;

        /** 				charbuf = {}*/
        RefDS(_5);
        DeRefDS(_charbuf_22675);
        _charbuf_22675 = _5;
        goto L4; // [197] 210

        /** 			case else*/
        default:

        /** 				charbuf &= char*/
        Append(&_charbuf_22675, _charbuf_22675, _char_22673);
    ;}L4: 

    /** 		i += 1*/
    _i_22672 = _i_22672 + 1;

    /** 	end while*/
    goto L2; // [218] 46
L3: 

    /** 	if length(fname) then*/
    if (IS_SEQUENCE(_fname_22676)){
            _12635 = SEQ_PTR(_fname_22676)->length;
    }
    else {
        _12635 = 1;
    }
    if (_12635 == 0)
    {
        _12635 = NOVALUE;
        goto L5; // [226] 241
    }
    else{
        _12635 = NOVALUE;
    }

    /** 		map:put(the_map, fname, charbuf)*/
    Ref(_the_map_22677);
    RefDS(_fname_22676);
    RefDS(_charbuf_22675);
    _33put(_the_map_22677, _fname_22676, _charbuf_22675, 1, _33threshold_size_12820);
L5: 

    /** 	return the_map*/
    DeRef(_query_string_22671);
    DeRef(_tmp_22674);
    DeRef(_charbuf_22675);
    DeRef(_fname_22676);
    DeRef(_12623);
    _12623 = NOVALUE;
    DeRef(_12625);
    _12625 = NOVALUE;
    return _the_map_22677;
    ;
}
int parse_querystring() __attribute__ ((alias ("_55parse_querystring")));


int _55parse(int _url_22719, int _querystring_also_22720)
{
    int _protocol_22721 = NOVALUE;
    int _host_name_22722 = NOVALUE;
    int _path_22723 = NOVALUE;
    int _user_name_22724 = NOVALUE;
    int _password_22725 = NOVALUE;
    int _query_string_22726 = NOVALUE;
    int _port_22727 = NOVALUE;
    int _pos_22728 = NOVALUE;
    int _at_22747 = NOVALUE;
    int _password_colon_22752 = NOVALUE;
    int _qs_start_22767 = NOVALUE;
    int _first_slash_22770 = NOVALUE;
    int _port_colon_22772 = NOVALUE;
    int _port_end_22791 = NOVALUE;
    int _12699 = NOVALUE;
    int _12697 = NOVALUE;
    int _12696 = NOVALUE;
    int _12694 = NOVALUE;
    int _12693 = NOVALUE;
    int _12690 = NOVALUE;
    int _12687 = NOVALUE;
    int _12683 = NOVALUE;
    int _12682 = NOVALUE;
    int _12677 = NOVALUE;
    int _12675 = NOVALUE;
    int _12673 = NOVALUE;
    int _12669 = NOVALUE;
    int _12662 = NOVALUE;
    int _12660 = NOVALUE;
    int _12659 = NOVALUE;
    int _12657 = NOVALUE;
    int _12656 = NOVALUE;
    int _12655 = NOVALUE;
    int _12654 = NOVALUE;
    int _12647 = NOVALUE;
    int _12644 = NOVALUE;
    int _12641 = NOVALUE;
    int _12638 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_querystring_also_22720)) {
        _1 = (long)(DBL_PTR(_querystring_also_22720)->dbl);
        DeRefDS(_querystring_also_22720);
        _querystring_also_22720 = _1;
    }

    /**     sequence protocol = ""*/
    RefDS(_5);
    DeRef(_protocol_22721);
    _protocol_22721 = _5;

    /**     host_name = 0*/
    DeRef(_host_name_22722);
    _host_name_22722 = 0;

    /**     port = 0*/
    _port_22727 = 0;

    /**     path = 0*/
    DeRef(_path_22723);
    _path_22723 = 0;

    /**     user_name = 0*/
    DeRef(_user_name_22724);
    _user_name_22724 = 0;

    /**     password  = 0*/
    DeRef(_password_22725);
    _password_22725 = 0;

    /**     query_string = 0*/
    DeRef(_query_string_22726);
    _query_string_22726 = 0;

    /** 	integer pos = find(':', url)*/
    _pos_22728 = find_from(58, _url_22719, 1);

    /**     if not pos then*/
    if (_pos_22728 != 0)
    goto L1; // [51] 61

    /**         return 0*/
    DeRefDS(_url_22719);
    DeRefDS(_protocol_22721);
    return 0;
L1: 

    /** 	protocol = url[1..pos - 1]*/
    _12638 = _pos_22728 - 1;
    rhs_slice_target = (object_ptr)&_protocol_22721;
    RHS_Slice(_url_22719, 1, _12638);

    /**     pos += 1*/
    _pos_22728 = _pos_22728 + 1;

    /**     if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_22719);
    _12641 = (int)*(((s1_ptr)_2)->base + _pos_22728);
    if (binary_op_a(NOTEQ, _12641, 47)){
        _12641 = NOVALUE;
        goto L2; // [84] 95
    }
    _12641 = NOVALUE;

    /**         pos += 1*/
    _pos_22728 = _pos_22728 + 1;
L2: 

    /**     if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_22719);
    _12644 = (int)*(((s1_ptr)_2)->base + _pos_22728);
    if (binary_op_a(NOTEQ, _12644, 47)){
        _12644 = NOVALUE;
        goto L3; // [101] 112
    }
    _12644 = NOVALUE;

    /**         pos += 1*/
    _pos_22728 = _pos_22728 + 1;
L3: 

    /** 	if url[pos] = '/' then*/
    _2 = (int)SEQ_PTR(_url_22719);
    _12647 = (int)*(((s1_ptr)_2)->base + _pos_22728);
    if (binary_op_a(NOTEQ, _12647, 47)){
        _12647 = NOVALUE;
        goto L4; // [118] 129
    }
    _12647 = NOVALUE;

    /**         goto "parse_path"*/
    goto G5;
L4: 

    /** 	integer at = find('@', url)*/
    _at_22747 = find_from(64, _url_22719, 1);

    /**     if not at then*/
    if (_at_22747 != 0)
    goto L6; // [138] 148

    /**         goto "parse_domain"*/
    goto G7;
L6: 

    /**     integer password_colon = find(':', url, pos)*/
    _password_colon_22752 = find_from(58, _url_22719, _pos_22728);

    /**     if password_colon > 0 and password_colon < at then*/
    _12654 = (_password_colon_22752 > 0);
    if (_12654 == 0) {
        goto L8; // [161] 202
    }
    _12656 = (_password_colon_22752 < _at_22747);
    if (_12656 == 0)
    {
        DeRef(_12656);
        _12656 = NOVALUE;
        goto L8; // [170] 202
    }
    else{
        DeRef(_12656);
        _12656 = NOVALUE;
    }

    /**         user_name = url[pos..password_colon-1]*/
    _12657 = _password_colon_22752 - 1;
    rhs_slice_target = (object_ptr)&_user_name_22724;
    RHS_Slice(_url_22719, _pos_22728, _12657);

    /**         password = url[password_colon+1..at-1]*/
    _12659 = _password_colon_22752 + 1;
    if (_12659 > MAXINT){
        _12659 = NewDouble((double)_12659);
    }
    _12660 = _at_22747 - 1;
    rhs_slice_target = (object_ptr)&_password_22725;
    RHS_Slice(_url_22719, _12659, _12660);
    goto L9; // [199] 214
L8: 

    /**     	user_name = url[pos..at-1]*/
    _12662 = _at_22747 - 1;
    rhs_slice_target = (object_ptr)&_user_name_22724;
    RHS_Slice(_url_22719, _pos_22728, _12662);
L9: 

    /**     pos = at + 1*/
    _pos_22728 = _at_22747 + 1;

    /** label "parse_domain"*/
G7:

    /**     integer qs_start = find('?', url, pos)*/
    _qs_start_22767 = find_from(63, _url_22719, _pos_22728);

    /** 	integer first_slash = find('/', url, pos)*/
    _first_slash_22770 = find_from(47, _url_22719, _pos_22728);

    /**     integer port_colon = find(':', url, pos)*/
    _port_colon_22772 = find_from(58, _url_22719, _pos_22728);

    /**     if port_colon then*/
    if (_port_colon_22772 == 0)
    {
        goto LA; // [247] 264
    }
    else{
    }

    /**         host_name = url[pos..port_colon-1]*/
    _12669 = _port_colon_22772 - 1;
    rhs_slice_target = (object_ptr)&_host_name_22722;
    RHS_Slice(_url_22719, _pos_22728, _12669);
    goto LB; // [261] 315
LA: 

    /**         if not first_slash then*/
    if (_first_slash_22770 != 0)
    goto LC; // [266] 302

    /**             if not qs_start then*/
    if (_qs_start_22767 != 0)
    goto LD; // [271] 287

    /**                 host_name = url[pos..$]*/
    if (IS_SEQUENCE(_url_22719)){
            _12673 = SEQ_PTR(_url_22719)->length;
    }
    else {
        _12673 = 1;
    }
    rhs_slice_target = (object_ptr)&_host_name_22722;
    RHS_Slice(_url_22719, _pos_22728, _12673);
    goto LE; // [284] 314
LD: 

    /**             	host_name = url[pos..qs_start-1]*/
    _12675 = _qs_start_22767 - 1;
    rhs_slice_target = (object_ptr)&_host_name_22722;
    RHS_Slice(_url_22719, _pos_22728, _12675);
    goto LE; // [299] 314
LC: 

    /**         	host_name = url[pos..first_slash-1]*/
    _12677 = _first_slash_22770 - 1;
    rhs_slice_target = (object_ptr)&_host_name_22722;
    RHS_Slice(_url_22719, _pos_22728, _12677);
LE: 
LB: 

    /**     if port_colon then*/
    if (_port_colon_22772 == 0)
    {
        goto LF; // [317] 379
    }
    else{
    }

    /**         integer port_end = 0*/
    _port_end_22791 = 0;

    /** 		if first_slash then*/
    if (_first_slash_22770 == 0)
    {
        goto L10; // [327] 339
    }
    else{
    }

    /**             port_end = first_slash - 1*/
    _port_end_22791 = _first_slash_22770 - 1;
    goto L11; // [336] 359
L10: 

    /**         elsif qs_start then*/
    if (_qs_start_22767 == 0)
    {
        goto L12; // [341] 353
    }
    else{
    }

    /**             port_end = qs_start - 1*/
    _port_end_22791 = _qs_start_22767 - 1;
    goto L11; // [350] 359
L12: 

    /**         	port_end = length(url)*/
    if (IS_SEQUENCE(_url_22719)){
            _port_end_22791 = SEQ_PTR(_url_22719)->length;
    }
    else {
        _port_end_22791 = 1;
    }
L11: 

    /** 		port = stdget:defaulted_value(url[port_colon+1..port_end], 0)*/
    _12682 = _port_colon_22772 + 1;
    rhs_slice_target = (object_ptr)&_12683;
    RHS_Slice(_url_22719, _12682, _port_end_22791);
    _port_22727 = _17defaulted_value(_12683, 0, 1);
    _12683 = NOVALUE;
    if (!IS_ATOM_INT(_port_22727)) {
        _1 = (long)(DBL_PTR(_port_22727)->dbl);
        DeRefDS(_port_22727);
        _port_22727 = _1;
    }
LF: 

    /**     if first_slash then*/
    if (_first_slash_22770 == 0)
    {
        goto L13; // [383] 394
    }
    else{
    }

    /**         pos = first_slash*/
    _pos_22728 = _first_slash_22770;
    goto L14; // [391] 414
L13: 

    /**     elsif qs_start then*/
    if (_qs_start_22767 == 0)
    {
        goto L15; // [396] 407
    }
    else{
    }

    /**         pos = qs_start*/
    _pos_22728 = _qs_start_22767;
    goto L14; // [404] 414
L15: 

    /**         goto "parse_done"*/
    goto G16;
L14: 

    /** label "parse_path"*/
G5:

    /**     if not qs_start then*/
    if (_qs_start_22767 != 0)
    goto L17; // [420] 440

    /**         path = url[pos..$]*/
    if (IS_SEQUENCE(_url_22719)){
            _12687 = SEQ_PTR(_url_22719)->length;
    }
    else {
        _12687 = 1;
    }
    rhs_slice_target = (object_ptr)&_path_22723;
    RHS_Slice(_url_22719, _pos_22728, _12687);

    /**         goto "parse_done"*/
    goto G16;
L17: 

    /**     if pos != qs_start then*/
    if (_pos_22728 == _qs_start_22767)
    goto L18; // [442] 458

    /**         path = url[pos..qs_start - 1]*/
    _12690 = _qs_start_22767 - 1;
    rhs_slice_target = (object_ptr)&_path_22723;
    RHS_Slice(_url_22719, _pos_22728, _12690);
L18: 

    /**     pos = qs_start*/
    _pos_22728 = _qs_start_22767;

    /** label "parse_query_string"*/
G19:

    /** 	query_string = url[qs_start + 1..$]*/
    _12693 = _qs_start_22767 + 1;
    if (_12693 > MAXINT){
        _12693 = NewDouble((double)_12693);
    }
    if (IS_SEQUENCE(_url_22719)){
            _12694 = SEQ_PTR(_url_22719)->length;
    }
    else {
        _12694 = 1;
    }
    rhs_slice_target = (object_ptr)&_query_string_22726;
    RHS_Slice(_url_22719, _12693, _12694);

    /**     if querystring_also and length(query_string) then*/
    if (_querystring_also_22720 == 0) {
        goto L1A; // [483] 501
    }
    if (IS_SEQUENCE(_query_string_22726)){
            _12697 = SEQ_PTR(_query_string_22726)->length;
    }
    else {
        _12697 = 1;
    }
    if (_12697 == 0)
    {
        _12697 = NOVALUE;
        goto L1A; // [491] 501
    }
    else{
        _12697 = NOVALUE;
    }

    /**         query_string = parse_querystring(query_string)*/
    Ref(_query_string_22726);
    _0 = _query_string_22726;
    _query_string_22726 = _55parse_querystring(_query_string_22726);
    DeRef(_0);
L1A: 

    /** label "parse_done"*/
G16:

    /**     return { protocol, host_name, port, path, user_name, password, query_string }*/
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_protocol_22721);
    *((int *)(_2+4)) = _protocol_22721;
    Ref(_host_name_22722);
    *((int *)(_2+8)) = _host_name_22722;
    *((int *)(_2+12)) = _port_22727;
    Ref(_path_22723);
    *((int *)(_2+16)) = _path_22723;
    Ref(_user_name_22724);
    *((int *)(_2+20)) = _user_name_22724;
    Ref(_password_22725);
    *((int *)(_2+24)) = _password_22725;
    Ref(_query_string_22726);
    *((int *)(_2+28)) = _query_string_22726;
    _12699 = MAKE_SEQ(_1);
    DeRefDS(_url_22719);
    DeRefDS(_protocol_22721);
    DeRef(_host_name_22722);
    DeRef(_path_22723);
    DeRef(_user_name_22724);
    DeRef(_password_22725);
    DeRef(_query_string_22726);
    DeRef(_12638);
    _12638 = NOVALUE;
    DeRef(_12654);
    _12654 = NOVALUE;
    DeRef(_12657);
    _12657 = NOVALUE;
    DeRef(_12659);
    _12659 = NOVALUE;
    DeRef(_12660);
    _12660 = NOVALUE;
    DeRef(_12662);
    _12662 = NOVALUE;
    DeRef(_12669);
    _12669 = NOVALUE;
    DeRef(_12675);
    _12675 = NOVALUE;
    DeRef(_12677);
    _12677 = NOVALUE;
    DeRef(_12682);
    _12682 = NOVALUE;
    DeRef(_12690);
    _12690 = NOVALUE;
    DeRef(_12693);
    _12693 = NOVALUE;
    return _12699;
    ;
}


int _55encode(int _what_22828, int _spacecode_22829)
{
    int _encoded_22831 = NOVALUE;
    int _junk_22832 = NOVALUE;
    int _junk1_22833 = NOVALUE;
    int _junk2_22834 = NOVALUE;
    int _12721 = NOVALUE;
    int _12720 = NOVALUE;
    int _12719 = NOVALUE;
    int _12718 = NOVALUE;
    int _12717 = NOVALUE;
    int _12714 = NOVALUE;
    int _12713 = NOVALUE;
    int _12709 = NOVALUE;
    int _12708 = NOVALUE;
    int _12706 = NOVALUE;
    int _12705 = NOVALUE;
    int _12704 = NOVALUE;
    int _12703 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence encoded = ""*/
    RefDS(_5);
    DeRef(_encoded_22831);
    _encoded_22831 = _5;

    /** 	object junk = "", junk1, junk2*/
    RefDS(_5);
    DeRef(_junk_22832);
    _junk_22832 = _5;

    /** 	for idx = 1 to length(what) do*/
    if (IS_SEQUENCE(_what_22828)){
            _12703 = SEQ_PTR(_what_22828)->length;
    }
    else {
        _12703 = 1;
    }
    {
        int _idx_22836;
        _idx_22836 = 1;
L1: 
        if (_idx_22836 > _12703){
            goto L2; // [22] 145
        }

        /** 		if find(what[idx],alphanum) then*/
        _2 = (int)SEQ_PTR(_what_22828);
        _12704 = (int)*(((s1_ptr)_2)->base + _idx_22836);
        _12705 = find_from(_12704, _55alphanum_22822, 1);
        _12704 = NOVALUE;
        if (_12705 == 0)
        {
            _12705 = NOVALUE;
            goto L3; // [40] 56
        }
        else{
            _12705 = NOVALUE;
        }

        /** 			encoded &= what[idx]*/
        _2 = (int)SEQ_PTR(_what_22828);
        _12706 = (int)*(((s1_ptr)_2)->base + _idx_22836);
        if (IS_SEQUENCE(_encoded_22831) && IS_ATOM(_12706)) {
            Ref(_12706);
            Append(&_encoded_22831, _encoded_22831, _12706);
        }
        else if (IS_ATOM(_encoded_22831) && IS_SEQUENCE(_12706)) {
        }
        else {
            Concat((object_ptr)&_encoded_22831, _encoded_22831, _12706);
        }
        _12706 = NOVALUE;
        goto L4; // [53] 138
L3: 

        /** 		elsif equal(what[idx],' ') then*/
        _2 = (int)SEQ_PTR(_what_22828);
        _12708 = (int)*(((s1_ptr)_2)->base + _idx_22836);
        if (_12708 == 32)
        _12709 = 1;
        else if (IS_ATOM_INT(_12708) && IS_ATOM_INT(32))
        _12709 = 0;
        else
        _12709 = (compare(_12708, 32) == 0);
        _12708 = NOVALUE;
        if (_12709 == 0)
        {
            _12709 = NOVALUE;
            goto L5; // [66] 78
        }
        else{
            _12709 = NOVALUE;
        }

        /** 			encoded &= spacecode*/
        Concat((object_ptr)&_encoded_22831, _encoded_22831, _spacecode_22829);
        goto L4; // [75] 138
L5: 

        /** 		elsif 1 then*/

        /** 			junk = what[idx]*/
        DeRef(_junk_22832);
        _2 = (int)SEQ_PTR(_what_22828);
        _junk_22832 = (int)*(((s1_ptr)_2)->base + _idx_22836);
        Ref(_junk_22832);

        /** 			junk1 = floor(junk / 16)*/
        DeRef(_junk1_22833);
        if (IS_ATOM_INT(_junk_22832)) {
            if (16 > 0 && _junk_22832 >= 0) {
                _junk1_22833 = _junk_22832 / 16;
            }
            else {
                temp_dbl = floor((double)_junk_22832 / (double)16);
                if (_junk_22832 != MININT)
                _junk1_22833 = (long)temp_dbl;
                else
                _junk1_22833 = NewDouble(temp_dbl);
            }
        }
        else {
            _2 = binary_op(DIVIDE, _junk_22832, 16);
            _junk1_22833 = unary_op(FLOOR, _2);
            DeRef(_2);
        }

        /** 			junk2 = floor(junk - (junk1 * 16))*/
        if (IS_ATOM_INT(_junk1_22833)) {
            if (_junk1_22833 == (short)_junk1_22833)
            _12713 = _junk1_22833 * 16;
            else
            _12713 = NewDouble(_junk1_22833 * (double)16);
        }
        else {
            _12713 = binary_op(MULTIPLY, _junk1_22833, 16);
        }
        if (IS_ATOM_INT(_junk_22832) && IS_ATOM_INT(_12713)) {
            _12714 = _junk_22832 - _12713;
            if ((long)((unsigned long)_12714 +(unsigned long) HIGH_BITS) >= 0){
                _12714 = NewDouble((double)_12714);
            }
        }
        else {
            _12714 = binary_op(MINUS, _junk_22832, _12713);
        }
        DeRef(_12713);
        _12713 = NOVALUE;
        DeRef(_junk2_22834);
        if (IS_ATOM_INT(_12714))
        _junk2_22834 = e_floor(_12714);
        else
        _junk2_22834 = unary_op(FLOOR, _12714);
        DeRef(_12714);
        _12714 = NOVALUE;

        /** 			encoded &= "%" & hexnums[junk1+1] & hexnums[junk2+1]*/
        if (IS_ATOM_INT(_junk1_22833)) {
            _12717 = _junk1_22833 + 1;
        }
        else
        _12717 = binary_op(PLUS, 1, _junk1_22833);
        _2 = (int)SEQ_PTR(_55hexnums_22824);
        if (!IS_ATOM_INT(_12717)){
            _12718 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12717)->dbl));
        }
        else{
            _12718 = (int)*(((s1_ptr)_2)->base + _12717);
        }
        if (IS_ATOM_INT(_junk2_22834)) {
            _12719 = _junk2_22834 + 1;
        }
        else
        _12719 = binary_op(PLUS, 1, _junk2_22834);
        _2 = (int)SEQ_PTR(_55hexnums_22824);
        if (!IS_ATOM_INT(_12719)){
            _12720 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12719)->dbl));
        }
        else{
            _12720 = (int)*(((s1_ptr)_2)->base + _12719);
        }
        {
            int concat_list[3];

            concat_list[0] = _12720;
            concat_list[1] = _12718;
            concat_list[2] = _12716;
            Concat_N((object_ptr)&_12721, concat_list, 3);
        }
        _12720 = NOVALUE;
        _12718 = NOVALUE;
        Concat((object_ptr)&_encoded_22831, _encoded_22831, _12721);
        DeRefDS(_12721);
        _12721 = NOVALUE;
L4: 

        /** 	end for*/
        _idx_22836 = _idx_22836 + 1;
        goto L1; // [140] 29
L2: 
        ;
    }

    /** 	return encoded*/
    DeRefDS(_what_22828);
    DeRefDS(_spacecode_22829);
    DeRef(_junk_22832);
    DeRef(_junk1_22833);
    DeRef(_junk2_22834);
    DeRef(_12717);
    _12717 = NOVALUE;
    DeRef(_12719);
    _12719 = NOVALUE;
    return _encoded_22831;
    ;
}


int _55decode(int _what_22862)
{
    int _k_22863 = NOVALUE;
    int _value_inlined_value_at_119_22892 = NOVALUE;
    int _st_inlined_value_at_116_22891 = NOVALUE;
    int _value_inlined_value_at_202_22907 = NOVALUE;
    int _st_inlined_value_at_199_22906 = NOVALUE;
    int _12760 = NOVALUE;
    int _12759 = NOVALUE;
    int _12758 = NOVALUE;
    int _12757 = NOVALUE;
    int _12756 = NOVALUE;
    int _12755 = NOVALUE;
    int _12754 = NOVALUE;
    int _12753 = NOVALUE;
    int _12752 = NOVALUE;
    int _12751 = NOVALUE;
    int _12749 = NOVALUE;
    int _12748 = NOVALUE;
    int _12747 = NOVALUE;
    int _12746 = NOVALUE;
    int _12745 = NOVALUE;
    int _12744 = NOVALUE;
    int _12743 = NOVALUE;
    int _12742 = NOVALUE;
    int _12741 = NOVALUE;
    int _12738 = NOVALUE;
    int _12737 = NOVALUE;
    int _12735 = NOVALUE;
    int _12734 = NOVALUE;
    int _12733 = NOVALUE;
    int _12732 = NOVALUE;
    int _12731 = NOVALUE;
    int _12729 = NOVALUE;
    int _12727 = NOVALUE;
    int _12725 = NOVALUE;
    int _12723 = NOVALUE;
    int _0, _1, _2;
    

    /**   integer k = 1*/
    _k_22863 = 1;

    /**   while k <= length(what) do*/
L1: 
    if (IS_SEQUENCE(_what_22862)){
            _12723 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12723 = 1;
    }
    if (_k_22863 > _12723)
    goto L2; // [16] 275

    /**     if what[k] = '+' then*/
    _2 = (int)SEQ_PTR(_what_22862);
    _12725 = (int)*(((s1_ptr)_2)->base + _k_22863);
    if (binary_op_a(NOTEQ, _12725, 43)){
        _12725 = NOVALUE;
        goto L3; // [26] 39
    }
    _12725 = NOVALUE;

    /**       what[k] = ' ' -- space is a special case, converts into +*/
    _2 = (int)SEQ_PTR(_what_22862);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_22862 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_22863);
    _1 = *(int *)_2;
    *(int *)_2 = 32;
    DeRef(_1);
    goto L4; // [36] 264
L3: 

    /**     elsif what[k] = '%' then*/
    _2 = (int)SEQ_PTR(_what_22862);
    _12727 = (int)*(((s1_ptr)_2)->base + _k_22863);
    if (binary_op_a(NOTEQ, _12727, 37)){
        _12727 = NOVALUE;
        goto L5; // [45] 263
    }
    _12727 = NOVALUE;

    /**       if k = length(what) then*/
    if (IS_SEQUENCE(_what_22862)){
            _12729 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12729 = 1;
    }
    if (_k_22863 != _12729)
    goto L6; // [54] 88

    /**         what = what[1..k-1] & what[k+1 .. $]*/
    _12731 = _k_22863 - 1;
    rhs_slice_target = (object_ptr)&_12732;
    RHS_Slice(_what_22862, 1, _12731);
    _12733 = _k_22863 + 1;
    if (_12733 > MAXINT){
        _12733 = NewDouble((double)_12733);
    }
    if (IS_SEQUENCE(_what_22862)){
            _12734 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12734 = 1;
    }
    rhs_slice_target = (object_ptr)&_12735;
    RHS_Slice(_what_22862, _12733, _12734);
    Concat((object_ptr)&_what_22862, _12732, _12735);
    DeRefDS(_12732);
    _12732 = NOVALUE;
    DeRef(_12732);
    _12732 = NOVALUE;
    DeRefDS(_12735);
    _12735 = NOVALUE;
    goto L4; // [85] 264
L6: 

    /**       elsif k+1 = length(what) then*/
    _12737 = _k_22863 + 1;
    if (_12737 > MAXINT){
        _12737 = NewDouble((double)_12737);
    }
    if (IS_SEQUENCE(_what_22862)){
            _12738 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12738 = 1;
    }
    if (binary_op_a(NOTEQ, _12737, _12738)){
        DeRef(_12737);
        _12737 = NOVALUE;
        _12738 = NOVALUE;
        goto L7; // [97] 179
    }
    DeRef(_12737);
    _12737 = NOVALUE;
    _12738 = NOVALUE;

    /**         what[k] = stdget:value("#0" & what[k+1])*/
    _12741 = _k_22863 + 1;
    _2 = (int)SEQ_PTR(_what_22862);
    _12742 = (int)*(((s1_ptr)_2)->base + _12741);
    if (IS_SEQUENCE(_12740) && IS_ATOM(_12742)) {
        Ref(_12742);
        Append(&_12743, _12740, _12742);
    }
    else if (IS_ATOM(_12740) && IS_SEQUENCE(_12742)) {
    }
    else {
        Concat((object_ptr)&_12743, _12740, _12742);
    }
    _12742 = NOVALUE;
    DeRef(_st_inlined_value_at_116_22891);
    _st_inlined_value_at_116_22891 = _12743;
    _12743 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_116_22891);
    _0 = _value_inlined_value_at_119_22892;
    _value_inlined_value_at_119_22892 = _17get_value(_st_inlined_value_at_116_22891, 1, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);
    DeRef(_st_inlined_value_at_116_22891);
    _st_inlined_value_at_116_22891 = NOVALUE;
    Ref(_value_inlined_value_at_119_22892);
    _2 = (int)SEQ_PTR(_what_22862);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_22862 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_22863);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_119_22892;
    DeRef(_1);

    /**         what[k] = what[k][2]*/
    _2 = (int)SEQ_PTR(_what_22862);
    _12744 = (int)*(((s1_ptr)_2)->base + _k_22863);
    _2 = (int)SEQ_PTR(_12744);
    _12745 = (int)*(((s1_ptr)_2)->base + 2);
    _12744 = NOVALUE;
    Ref(_12745);
    _2 = (int)SEQ_PTR(_what_22862);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_22862 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_22863);
    _1 = *(int *)_2;
    *(int *)_2 = _12745;
    if( _1 != _12745 ){
        DeRef(_1);
    }
    _12745 = NOVALUE;

    /**         what = what[1..k] & what[k+2 .. $]*/
    rhs_slice_target = (object_ptr)&_12746;
    RHS_Slice(_what_22862, 1, _k_22863);
    _12747 = _k_22863 + 2;
    if ((long)((unsigned long)_12747 + (unsigned long)HIGH_BITS) >= 0) 
    _12747 = NewDouble((double)_12747);
    if (IS_SEQUENCE(_what_22862)){
            _12748 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12748 = 1;
    }
    rhs_slice_target = (object_ptr)&_12749;
    RHS_Slice(_what_22862, _12747, _12748);
    Concat((object_ptr)&_what_22862, _12746, _12749);
    DeRefDS(_12746);
    _12746 = NOVALUE;
    DeRef(_12746);
    _12746 = NOVALUE;
    DeRefDS(_12749);
    _12749 = NOVALUE;
    goto L4; // [176] 264
L7: 

    /**         what[k] = stdget:value("#" & what[k+1..k+2])*/
    _12751 = _k_22863 + 1;
    if (_12751 > MAXINT){
        _12751 = NewDouble((double)_12751);
    }
    _12752 = _k_22863 + 2;
    rhs_slice_target = (object_ptr)&_12753;
    RHS_Slice(_what_22862, _12751, _12752);
    Concat((object_ptr)&_12754, _12622, _12753);
    DeRefDS(_12753);
    _12753 = NOVALUE;
    DeRef(_st_inlined_value_at_199_22906);
    _st_inlined_value_at_199_22906 = _12754;
    _12754 = NOVALUE;
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_inlined_value_at_199_22906);
    _0 = _value_inlined_value_at_202_22907;
    _value_inlined_value_at_202_22907 = _17get_value(_st_inlined_value_at_199_22906, 1, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);
    DeRef(_st_inlined_value_at_199_22906);
    _st_inlined_value_at_199_22906 = NOVALUE;
    Ref(_value_inlined_value_at_202_22907);
    _2 = (int)SEQ_PTR(_what_22862);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_22862 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_22863);
    _1 = *(int *)_2;
    *(int *)_2 = _value_inlined_value_at_202_22907;
    DeRef(_1);

    /**         what[k] = what[k][2]*/
    _2 = (int)SEQ_PTR(_what_22862);
    _12755 = (int)*(((s1_ptr)_2)->base + _k_22863);
    _2 = (int)SEQ_PTR(_12755);
    _12756 = (int)*(((s1_ptr)_2)->base + 2);
    _12755 = NOVALUE;
    Ref(_12756);
    _2 = (int)SEQ_PTR(_what_22862);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _what_22862 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_22863);
    _1 = *(int *)_2;
    *(int *)_2 = _12756;
    if( _1 != _12756 ){
        DeRef(_1);
    }
    _12756 = NOVALUE;

    /**         what = what[1..k] & what[k+3 .. $]*/
    rhs_slice_target = (object_ptr)&_12757;
    RHS_Slice(_what_22862, 1, _k_22863);
    _12758 = _k_22863 + 3;
    if ((long)((unsigned long)_12758 + (unsigned long)HIGH_BITS) >= 0) 
    _12758 = NewDouble((double)_12758);
    if (IS_SEQUENCE(_what_22862)){
            _12759 = SEQ_PTR(_what_22862)->length;
    }
    else {
        _12759 = 1;
    }
    rhs_slice_target = (object_ptr)&_12760;
    RHS_Slice(_what_22862, _12758, _12759);
    Concat((object_ptr)&_what_22862, _12757, _12760);
    DeRefDS(_12757);
    _12757 = NOVALUE;
    DeRef(_12757);
    _12757 = NOVALUE;
    DeRefDS(_12760);
    _12760 = NOVALUE;
    goto L4; // [260] 264
L5: 
L4: 

    /**     k += 1*/
    _k_22863 = _k_22863 + 1;

    /**   end while*/
    goto L1; // [272] 13
L2: 

    /**   return what*/
    DeRef(_12731);
    _12731 = NOVALUE;
    DeRef(_12741);
    _12741 = NOVALUE;
    DeRef(_12733);
    _12733 = NOVALUE;
    DeRef(_12751);
    _12751 = NOVALUE;
    DeRef(_12747);
    _12747 = NOVALUE;
    DeRef(_12752);
    _12752 = NOVALUE;
    DeRef(_12758);
    _12758 = NOVALUE;
    return _what_22862;
    ;
}



// 0x2F439638
