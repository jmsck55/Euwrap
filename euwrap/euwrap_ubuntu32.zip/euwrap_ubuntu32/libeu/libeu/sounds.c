// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _57sound(int _sound_type_23414)
{
    int _13019 = NOVALUE;
    int _13017 = NOVALUE;
    int _13013 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not object(xMessageBeep) then*/
    if( NOVALUE == _57xMessageBeep_23410 ){
        _13013 = 0;
    }
    else{
        _13013 = 1;
    }
    if (_13013 != 0)
    goto L1; // [6] 34
    _13013 = NOVALUE;

    /** 		xUser32 = dll:open_dll("user32.dll")*/
    RefDS(_12997);
    _0 = _13open_dll(_12997);
    DeRef(_57xUser32_23411);
    _57xUser32_23411 = _0;

    /** 		xMessageBeep   = dll:define_c_proc(xUser32, "MessageBeep", {C_UINT})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 33554436;
    _13017 = MAKE_SEQ(_1);
    Ref(_57xUser32_23411);
    RefDS(_13016);
    _0 = _13define_c_proc(_57xUser32_23411, _13016, _13017);
    _57xMessageBeep_23410 = _0;
    _13017 = NOVALUE;
    if (!IS_ATOM_INT(_57xMessageBeep_23410)) {
        _1 = (long)(DBL_PTR(_57xMessageBeep_23410)->dbl);
        DeRefDS(_57xMessageBeep_23410);
        _57xMessageBeep_23410 = _1;
    }
L1: 

    /**     c_proc( xMessageBeep, { sound_type } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_sound_type_23414);
    *((int *)(_2+4)) = _sound_type_23414;
    _13019 = MAKE_SEQ(_1);
    call_c(0, _57xMessageBeep_23410, _13019);
    DeRefDS(_13019);
    _13019 = NOVALUE;

    /** end procedure*/
    DeRef(_sound_type_23414);
    return;
    ;
}
void sound() __attribute__ ((alias ("_57sound")));



// 0x388FF424
