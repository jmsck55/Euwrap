// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _56message_box(int _text_23379, int _title_23380, int _style_23381)
{
    int _or_style_23382 = NOVALUE;
    int _text_ptr_23383 = NOVALUE;
    int _title_ptr_23384 = NOVALUE;
    int _ret_23385 = NOVALUE;
    int _13011 = NOVALUE;
    int _13010 = NOVALUE;
    int _13008 = NOVALUE;
    int _13007 = NOVALUE;
    int _13006 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text_ptr = machine:allocate_string(text)*/
    RefDS(_text_23379);
    _0 = _text_ptr_23383;
    _text_ptr_23383 = _14allocate_string(_text_23379, 0);
    DeRef(_0);

    /** 	if not text_ptr then*/
    if (IS_ATOM_INT(_text_ptr_23383)) {
        if (_text_ptr_23383 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_text_ptr_23383)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		return 0*/
    DeRefDS(_text_23379);
    DeRefDS(_title_23380);
    DeRef(_style_23381);
    DeRef(_text_ptr_23383);
    DeRef(_title_ptr_23384);
    DeRef(_ret_23385);
    return 0;
L1: 

    /** 	title_ptr = machine:allocate_string(title)*/
    RefDS(_title_23380);
    _0 = _title_ptr_23384;
    _title_ptr_23384 = _14allocate_string(_title_23380, 0);
    DeRef(_0);

    /** 	if not title_ptr then*/
    if (IS_ATOM_INT(_title_ptr_23384)) {
        if (_title_ptr_23384 != 0){
            goto L2; // [33] 48
        }
    }
    else {
        if (DBL_PTR(_title_ptr_23384)->dbl != 0.0){
            goto L2; // [33] 48
        }
    }

    /** 		machine:free(text_ptr)*/
    Ref(_text_ptr_23383);
    _14free(_text_ptr_23383);

    /** 		return 0*/
    DeRefDS(_text_23379);
    DeRefDS(_title_23380);
    DeRef(_style_23381);
    DeRef(_text_ptr_23383);
    DeRef(_title_ptr_23384);
    DeRef(_ret_23385);
    return 0;
L2: 

    /** 	if atom(style) then*/
    _13006 = IS_ATOM(_style_23381);
    if (_13006 == 0)
    {
        _13006 = NOVALUE;
        goto L3; // [53] 66
    }
    else{
        _13006 = NOVALUE;
    }

    /** 		or_style = style*/
    Ref(_style_23381);
    _or_style_23382 = _style_23381;
    if (!IS_ATOM_INT(_or_style_23382)) {
        _1 = (long)(DBL_PTR(_or_style_23382)->dbl);
        DeRefDS(_or_style_23382);
        _or_style_23382 = _1;
    }
    goto L4; // [63] 103
L3: 

    /** 		or_style = 0*/
    _or_style_23382 = 0;

    /** 		for i = 1 to length(style) do*/
    if (IS_SEQUENCE(_style_23381)){
            _13007 = SEQ_PTR(_style_23381)->length;
    }
    else {
        _13007 = 1;
    }
    {
        int _i_23396;
        _i_23396 = 1;
L5: 
        if (_i_23396 > _13007){
            goto L6; // [76] 102
        }

        /** 			or_style = or_bits(or_style, style[i])*/
        _2 = (int)SEQ_PTR(_style_23381);
        _13008 = (int)*(((s1_ptr)_2)->base + _i_23396);
        if (IS_ATOM_INT(_13008)) {
            {unsigned long tu;
                 tu = (unsigned long)_or_style_23382 | (unsigned long)_13008;
                 _or_style_23382 = MAKE_UINT(tu);
            }
        }
        else {
            _or_style_23382 = binary_op(OR_BITS, _or_style_23382, _13008);
        }
        _13008 = NOVALUE;
        if (!IS_ATOM_INT(_or_style_23382)) {
            _1 = (long)(DBL_PTR(_or_style_23382)->dbl);
            DeRefDS(_or_style_23382);
            _or_style_23382 = _1;
        }

        /** 		end for*/
        _i_23396 = _i_23396 + 1;
        goto L5; // [97] 83
L6: 
        ;
    }
L4: 

    /** 	ret = c_func(msgbox_id, {c_func(get_active_id, {}), */
    _13010 = call_c(1, _56get_active_id_23371, _5);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13010;
    Ref(_text_ptr_23383);
    *((int *)(_2+8)) = _text_ptr_23383;
    Ref(_title_ptr_23384);
    *((int *)(_2+12)) = _title_ptr_23384;
    *((int *)(_2+16)) = _or_style_23382;
    _13011 = MAKE_SEQ(_1);
    _13010 = NOVALUE;
    DeRef(_ret_23385);
    _ret_23385 = call_c(1, _56msgbox_id_23370, _13011);
    DeRefDS(_13011);
    _13011 = NOVALUE;

    /** 	machine:free(text_ptr)*/
    Ref(_text_ptr_23383);
    _14free(_text_ptr_23383);

    /** 	machine:free(title_ptr)*/
    Ref(_title_ptr_23384);
    _14free(_title_ptr_23384);

    /** 	return ret*/
    DeRefDS(_text_23379);
    DeRefDS(_title_23380);
    DeRef(_style_23381);
    DeRef(_text_ptr_23383);
    DeRef(_title_ptr_23384);
    return _ret_23385;
    ;
}
int message_box() __attribute__ ((alias ("_56message_box")));



// 0xD5A69A73
