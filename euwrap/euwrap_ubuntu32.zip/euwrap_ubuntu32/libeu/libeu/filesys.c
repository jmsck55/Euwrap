// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _11find_first_wildcard(int _name_7035, int _from_7036)
{
    int _asterisk_at_7037 = NOVALUE;
    int _question_at_7039 = NOVALUE;
    int _first_wildcard_at_7041 = NOVALUE;
    int _3772 = NOVALUE;
    int _3771 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_7037 = find_from(42, _name_7035, _from_7036);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_7039 = find_from(63, _name_7035, _from_7036);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_7041 = _asterisk_at_7037;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_7037 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_7039 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_7039 == 0) {
        goto L3; // [37] 55
    }
    _3772 = (_question_at_7039 < _asterisk_at_7037);
    if (_3772 == 0)
    {
        DeRef(_3772);
        _3772 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3772);
        _3772 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_7041 = _question_at_7039;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_7035);
    return _first_wildcard_at_7041;
    ;
}


int _11dir(int _name_7049)
{
    int _dir_data_7050 = NOVALUE;
    int _data_7051 = NOVALUE;
    int _the_name_7052 = NOVALUE;
    int _the_dir_7053 = NOVALUE;
    int _the_suffix_7054 = NOVALUE;
    int _idx_7055 = NOVALUE;
    int _first_wildcard_at_7056 = NOVALUE;
    int _next_slash_7071 = NOVALUE;
    int _wild_data_7103 = NOVALUE;
    int _interim_dir_7107 = NOVALUE;
    int _dir_results_7111 = NOVALUE;
    int _3815 = NOVALUE;
    int _3814 = NOVALUE;
    int _3813 = NOVALUE;
    int _3811 = NOVALUE;
    int _3810 = NOVALUE;
    int _3809 = NOVALUE;
    int _3807 = NOVALUE;
    int _3805 = NOVALUE;
    int _3804 = NOVALUE;
    int _3803 = NOVALUE;
    int _3802 = NOVALUE;
    int _3800 = NOVALUE;
    int _3798 = NOVALUE;
    int _3797 = NOVALUE;
    int _3796 = NOVALUE;
    int _3795 = NOVALUE;
    int _3794 = NOVALUE;
    int _3793 = NOVALUE;
    int _3790 = NOVALUE;
    int _3789 = NOVALUE;
    int _3787 = NOVALUE;
    int _3785 = NOVALUE;
    int _3784 = NOVALUE;
    int _3777 = NOVALUE;
    int _3775 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	ifdef WINDOWS then*/

    /** 		object dir_data, data, the_name, the_dir, the_suffix = 0*/
    DeRef(_the_suffix_7054);
    _the_suffix_7054 = 0;

    /** 		integer idx*/

    /** 		integer first_wildcard_at = find_first_wildcard( name )*/
    RefDS(_name_7049);
    _first_wildcard_at_7056 = _11find_first_wildcard(_name_7049, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_7056)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_7056)->dbl);
        DeRefDS(_first_wildcard_at_7056);
        _first_wildcard_at_7056 = _1;
    }

    /** 		if first_wildcard_at = 0 then*/
    if (_first_wildcard_at_7056 != 0)
    goto L1; // [23] 38

    /** 			return machine_func(M_DIR, name)*/
    _3775 = machine(22, _name_7049);
    DeRefDS(_name_7049);
    DeRef(_dir_data_7050);
    DeRef(_data_7051);
    DeRef(_the_name_7052);
    DeRef(_the_dir_7053);
    return _3775;
L1: 

    /** 		if first_wildcard_at then*/
    if (_first_wildcard_at_7056 == 0)
    {
        goto L2; // [40] 56
    }
    else{
    }

    /** 			idx = search:rfind(SLASH, name, first_wildcard_at )*/
    RefDS(_name_7049);
    _idx_7055 = _9rfind(47, _name_7049, _first_wildcard_at_7056);
    if (!IS_ATOM_INT(_idx_7055)) {
        _1 = (long)(DBL_PTR(_idx_7055)->dbl);
        DeRefDS(_idx_7055);
        _idx_7055 = _1;
    }
    goto L3; // [53] 70
L2: 

    /** 			idx = search:rfind(SLASH, name )*/
    if (IS_SEQUENCE(_name_7049)){
            _3777 = SEQ_PTR(_name_7049)->length;
    }
    else {
        _3777 = 1;
    }
    RefDS(_name_7049);
    _idx_7055 = _9rfind(47, _name_7049, _3777);
    _3777 = NOVALUE;
    if (!IS_ATOM_INT(_idx_7055)) {
        _1 = (long)(DBL_PTR(_idx_7055)->dbl);
        DeRefDS(_idx_7055);
        _idx_7055 = _1;
    }
L3: 

    /** 		if idx = 0 then*/
    if (_idx_7055 != 0)
    goto L4; // [74] 91

    /** 			the_dir = "."*/
    RefDS(_3780);
    DeRef(_the_dir_7053);
    _the_dir_7053 = _3780;

    /** 			the_name = name*/
    RefDS(_name_7049);
    DeRef(_the_name_7052);
    _the_name_7052 = _name_7049;
    goto L5; // [88] 187
L4: 

    /** 			the_dir = name[1 .. idx]*/
    rhs_slice_target = (object_ptr)&_the_dir_7053;
    RHS_Slice(_name_7049, 1, _idx_7055);

    /** 			integer next_slash = 0*/
    _next_slash_7071 = 0;

    /** 			if first_wildcard_at then*/
    if (_first_wildcard_at_7056 == 0)
    {
        goto L6; // [105] 116
    }
    else{
    }

    /** 				next_slash = eu:find( SLASH, name, first_wildcard_at )*/
    _next_slash_7071 = find_from(47, _name_7049, _first_wildcard_at_7056);
L6: 

    /** 			if next_slash then*/
    if (_next_slash_7071 == 0)
    {
        goto L7; // [118] 164
    }
    else{
    }

    /** 				first_wildcard_at = find_first_wildcard( name, next_slash )*/
    RefDS(_name_7049);
    _first_wildcard_at_7056 = _11find_first_wildcard(_name_7049, _next_slash_7071);
    if (!IS_ATOM_INT(_first_wildcard_at_7056)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_7056)->dbl);
        DeRefDS(_first_wildcard_at_7056);
        _first_wildcard_at_7056 = _1;
    }

    /** 				if first_wildcard_at then*/
    if (_first_wildcard_at_7056 == 0)
    {
        goto L8; // [132] 184
    }
    else{
    }

    /** 					the_name = name[idx+1..next_slash-1]*/
    _3784 = _idx_7055 + 1;
    if (_3784 > MAXINT){
        _3784 = NewDouble((double)_3784);
    }
    _3785 = _next_slash_7071 - 1;
    rhs_slice_target = (object_ptr)&_the_name_7052;
    RHS_Slice(_name_7049, _3784, _3785);

    /** 					the_suffix = name[next_slash..$]*/
    if (IS_SEQUENCE(_name_7049)){
            _3787 = SEQ_PTR(_name_7049)->length;
    }
    else {
        _3787 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_suffix_7054;
    RHS_Slice(_name_7049, _next_slash_7071, _3787);
    goto L8; // [161] 184
L7: 

    /** 				the_name = name[idx+1 .. $]*/
    _3789 = _idx_7055 + 1;
    if (_3789 > MAXINT){
        _3789 = NewDouble((double)_3789);
    }
    if (IS_SEQUENCE(_name_7049)){
            _3790 = SEQ_PTR(_name_7049)->length;
    }
    else {
        _3790 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_name_7052;
    RHS_Slice(_name_7049, _3789, _3790);

    /** 				the_suffix = 0*/
    DeRef(_the_suffix_7054);
    _the_suffix_7054 = 0;
L8: 
L5: 

    /** 		dir_data = dir( the_dir )*/
    Ref(_the_dir_7053);
    _0 = _dir_data_7050;
    _dir_data_7050 = _11dir(_the_dir_7053);
    DeRef(_0);

    /** 		if atom(dir_data) then*/
    _3793 = IS_ATOM(_dir_data_7050);
    if (_3793 == 0)
    {
        _3793 = NOVALUE;
        goto L9; // [200] 210
    }
    else{
        _3793 = NOVALUE;
    }

    /** 			return dir_data*/
    DeRefDS(_name_7049);
    DeRef(_data_7051);
    DeRef(_the_name_7052);
    DeRef(_the_dir_7053);
    DeRef(_the_suffix_7054);
    DeRef(_3775);
    _3775 = NOVALUE;
    DeRef(_3784);
    _3784 = NOVALUE;
    DeRef(_3785);
    _3785 = NOVALUE;
    DeRef(_3789);
    _3789 = NOVALUE;
    return _dir_data_7050;
L9: 

    /** 		data = {}*/
    RefDS(_5);
    DeRef(_data_7051);
    _data_7051 = _5;

    /** 		for i = 1 to length(dir_data) do*/
    if (IS_SEQUENCE(_dir_data_7050)){
            _3794 = SEQ_PTR(_dir_data_7050)->length;
    }
    else {
        _3794 = 1;
    }
    {
        int _i_7090;
        _i_7090 = 1;
LA: 
        if (_i_7090 > _3794){
            goto LB; // [220] 265
        }

        /** 			if wildcard:is_match(the_name, dir_data[i][1]) then*/
        _2 = (int)SEQ_PTR(_dir_data_7050);
        _3795 = (int)*(((s1_ptr)_2)->base + _i_7090);
        _2 = (int)SEQ_PTR(_3795);
        _3796 = (int)*(((s1_ptr)_2)->base + 1);
        _3795 = NOVALUE;
        Ref(_the_name_7052);
        Ref(_3796);
        _3797 = _25is_match(_the_name_7052, _3796);
        _3796 = NOVALUE;
        if (_3797 == 0) {
            DeRef(_3797);
            _3797 = NOVALUE;
            goto LC; // [244] 258
        }
        else {
            if (!IS_ATOM_INT(_3797) && DBL_PTR(_3797)->dbl == 0.0){
                DeRef(_3797);
                _3797 = NOVALUE;
                goto LC; // [244] 258
            }
            DeRef(_3797);
            _3797 = NOVALUE;
        }
        DeRef(_3797);
        _3797 = NOVALUE;

        /** 					data = append(data, dir_data[i])*/
        _2 = (int)SEQ_PTR(_dir_data_7050);
        _3798 = (int)*(((s1_ptr)_2)->base + _i_7090);
        Ref(_3798);
        Append(&_data_7051, _data_7051, _3798);
        _3798 = NOVALUE;
LC: 

        /** 		end for*/
        _i_7090 = _i_7090 + 1;
        goto LA; // [260] 227
LB: 
        ;
    }

    /** 		if not length(data) then*/
    if (IS_SEQUENCE(_data_7051)){
            _3800 = SEQ_PTR(_data_7051)->length;
    }
    else {
        _3800 = 1;
    }
    if (_3800 != 0)
    goto LD; // [270] 280
    _3800 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_name_7049);
    DeRef(_dir_data_7050);
    DeRef(_data_7051);
    DeRef(_the_name_7052);
    DeRef(_the_dir_7053);
    DeRef(_the_suffix_7054);
    DeRef(_3775);
    _3775 = NOVALUE;
    DeRef(_3784);
    _3784 = NOVALUE;
    DeRef(_3785);
    _3785 = NOVALUE;
    DeRef(_3789);
    _3789 = NOVALUE;
    return -1;
LD: 

    /** 		if sequence( the_suffix ) then*/
    _3802 = IS_SEQUENCE(_the_suffix_7054);
    if (_3802 == 0)
    {
        _3802 = NOVALUE;
        goto LE; // [285] 406
    }
    else{
        _3802 = NOVALUE;
    }

    /** 			sequence wild_data = {}*/
    RefDS(_5);
    DeRef(_wild_data_7103);
    _wild_data_7103 = _5;

    /** 			for i = 1 to length( dir_data ) do*/
    if (IS_SEQUENCE(_dir_data_7050)){
            _3803 = SEQ_PTR(_dir_data_7050)->length;
    }
    else {
        _3803 = 1;
    }
    {
        int _i_7105;
        _i_7105 = 1;
LF: 
        if (_i_7105 > _3803){
            goto L10; // [300] 399
        }

        /** 				sequence interim_dir = the_dir & dir_data[i][D_NAME] & SLASH*/
        _2 = (int)SEQ_PTR(_dir_data_7050);
        _3804 = (int)*(((s1_ptr)_2)->base + _i_7105);
        _2 = (int)SEQ_PTR(_3804);
        _3805 = (int)*(((s1_ptr)_2)->base + 1);
        _3804 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _3805;
            concat_list[2] = _the_dir_7053;
            Concat_N((object_ptr)&_interim_dir_7107, concat_list, 3);
        }
        _3805 = NOVALUE;

        /** 				object dir_results = dir( interim_dir & the_suffix )*/
        if (IS_SEQUENCE(_interim_dir_7107) && IS_ATOM(_the_suffix_7054)) {
            Ref(_the_suffix_7054);
            Append(&_3807, _interim_dir_7107, _the_suffix_7054);
        }
        else if (IS_ATOM(_interim_dir_7107) && IS_SEQUENCE(_the_suffix_7054)) {
        }
        else {
            Concat((object_ptr)&_3807, _interim_dir_7107, _the_suffix_7054);
        }
        _0 = _dir_results_7111;
        _dir_results_7111 = _11dir(_3807);
        DeRef(_0);
        _3807 = NOVALUE;

        /** 				if sequence( dir_results ) then*/
        _3809 = IS_SEQUENCE(_dir_results_7111);
        if (_3809 == 0)
        {
            _3809 = NOVALUE;
            goto L11; // [338] 390
        }
        else{
            _3809 = NOVALUE;
        }

        /** 					for j = 1 to length( dir_results ) do*/
        if (IS_SEQUENCE(_dir_results_7111)){
                _3810 = SEQ_PTR(_dir_results_7111)->length;
        }
        else {
            _3810 = 1;
        }
        {
            int _j_7117;
            _j_7117 = 1;
L12: 
            if (_j_7117 > _3810){
                goto L13; // [346] 383
            }

            /** 						dir_results[j][D_NAME] = interim_dir & dir_results[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_dir_results_7111);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _dir_results_7111 = MAKE_SEQ(_2);
            }
            _3 = (int)(_j_7117 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_dir_results_7111);
            _3813 = (int)*(((s1_ptr)_2)->base + _j_7117);
            _2 = (int)SEQ_PTR(_3813);
            _3814 = (int)*(((s1_ptr)_2)->base + 1);
            _3813 = NOVALUE;
            if (IS_SEQUENCE(_interim_dir_7107) && IS_ATOM(_3814)) {
                Ref(_3814);
                Append(&_3815, _interim_dir_7107, _3814);
            }
            else if (IS_ATOM(_interim_dir_7107) && IS_SEQUENCE(_3814)) {
            }
            else {
                Concat((object_ptr)&_3815, _interim_dir_7107, _3814);
            }
            _3814 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _3815;
            if( _1 != _3815 ){
                DeRef(_1);
            }
            _3815 = NOVALUE;
            _3811 = NOVALUE;

            /** 					end for*/
            _j_7117 = _j_7117 + 1;
            goto L12; // [378] 353
L13: 
            ;
        }

        /** 					wild_data &= dir_results*/
        if (IS_SEQUENCE(_wild_data_7103) && IS_ATOM(_dir_results_7111)) {
            Ref(_dir_results_7111);
            Append(&_wild_data_7103, _wild_data_7103, _dir_results_7111);
        }
        else if (IS_ATOM(_wild_data_7103) && IS_SEQUENCE(_dir_results_7111)) {
        }
        else {
            Concat((object_ptr)&_wild_data_7103, _wild_data_7103, _dir_results_7111);
        }
L11: 
        DeRef(_interim_dir_7107);
        _interim_dir_7107 = NOVALUE;
        DeRef(_dir_results_7111);
        _dir_results_7111 = NOVALUE;

        /** 			end for*/
        _i_7105 = _i_7105 + 1;
        goto LF; // [394] 307
L10: 
        ;
    }

    /** 			return wild_data*/
    DeRefDS(_name_7049);
    DeRef(_dir_data_7050);
    DeRef(_data_7051);
    DeRef(_the_name_7052);
    DeRef(_the_dir_7053);
    DeRef(_the_suffix_7054);
    DeRef(_3775);
    _3775 = NOVALUE;
    DeRef(_3784);
    _3784 = NOVALUE;
    DeRef(_3785);
    _3785 = NOVALUE;
    DeRef(_3789);
    _3789 = NOVALUE;
    return _wild_data_7103;
LE: 
    DeRef(_wild_data_7103);
    _wild_data_7103 = NOVALUE;

    /** 		return data*/
    DeRefDS(_name_7049);
    DeRef(_dir_data_7050);
    DeRef(_the_name_7052);
    DeRef(_the_dir_7053);
    DeRef(_the_suffix_7054);
    DeRef(_3775);
    _3775 = NOVALUE;
    DeRef(_3784);
    _3784 = NOVALUE;
    DeRef(_3785);
    _3785 = NOVALUE;
    DeRef(_3789);
    _3789 = NOVALUE;
    return _data_7051;
    ;
}
int dir() __attribute__ ((alias ("_11dir")));


int _11current_dir()
{
    int _3817 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _3817 = machine(23, 0);
    return _3817;
    ;
}
int current_dir() __attribute__ ((alias ("_11current_dir")));


int _11chdir(int _newdir_7130)
{
    int _3818 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _3818 = machine(63, _newdir_7130);
    DeRefDS(_newdir_7130);
    return _3818;
    ;
}
int chdir() __attribute__ ((alias ("_11chdir")));


int _11default_dir(int _path_7134)
{
    int _d_7135 = NOVALUE;
    int _3821 = NOVALUE;
    int _3820 = NOVALUE;
    int _0, _1, _2;
    

    /** 	d = dir(path)*/
    RefDS(_path_7134);
    _0 = _d_7135;
    _d_7135 = _11dir(_path_7134);
    DeRef(_0);

    /** 	if atom(d) then*/
    _3820 = IS_ATOM(_d_7135);
    if (_3820 == 0)
    {
        _3820 = NOVALUE;
        goto L1; // [14] 26
    }
    else{
        _3820 = NOVALUE;
    }

    /** 		return d*/
    DeRefDS(_path_7134);
    return _d_7135;
    goto L2; // [23] 38
L1: 

    /** 		return stdsort:sort(d)*/
    Ref(_d_7135);
    _3821 = _24sort(_d_7135, 1);
    DeRefDS(_path_7134);
    DeRef(_d_7135);
    return _3821;
L2: 
    ;
}


int _11walk_dir(int _path_name_7145, int _your_function_7146, int _scan_subdirs_7147, int _dir_source_7148)
{
    int _d_7149 = NOVALUE;
    int _abort_now_7150 = NOVALUE;
    int _orig_func_7151 = NOVALUE;
    int _user_data_7152 = NOVALUE;
    int _source_orig_func_7154 = NOVALUE;
    int _source_user_data_7155 = NOVALUE;
    int _3866 = NOVALUE;
    int _3865 = NOVALUE;
    int _3864 = NOVALUE;
    int _3863 = NOVALUE;
    int _3862 = NOVALUE;
    int _3860 = NOVALUE;
    int _3859 = NOVALUE;
    int _3858 = NOVALUE;
    int _3857 = NOVALUE;
    int _3856 = NOVALUE;
    int _3855 = NOVALUE;
    int _3854 = NOVALUE;
    int _3852 = NOVALUE;
    int _3850 = NOVALUE;
    int _3849 = NOVALUE;
    int _3848 = NOVALUE;
    int _3846 = NOVALUE;
    int _3845 = NOVALUE;
    int _3844 = NOVALUE;
    int _3841 = NOVALUE;
    int _3839 = NOVALUE;
    int _3835 = NOVALUE;
    int _3833 = NOVALUE;
    int _3832 = NOVALUE;
    int _3830 = NOVALUE;
    int _3827 = NOVALUE;
    int _3824 = NOVALUE;
    int _3823 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_scan_subdirs_7147)) {
        _1 = (long)(DBL_PTR(_scan_subdirs_7147)->dbl);
        DeRefDS(_scan_subdirs_7147);
        _scan_subdirs_7147 = _1;
    }

    /** 	sequence user_data = {path_name, 0}*/
    RefDS(_path_name_7145);
    DeRef(_user_data_7152);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _path_name_7145;
    ((int *)_2)[2] = 0;
    _user_data_7152 = MAKE_SEQ(_1);

    /** 	orig_func = your_function*/
    Ref(_your_function_7146);
    DeRef(_orig_func_7151);
    _orig_func_7151 = _your_function_7146;

    /** 	if sequence(your_function) then*/
    _3823 = IS_SEQUENCE(_your_function_7146);
    if (_3823 == 0)
    {
        _3823 = NOVALUE;
        goto L1; // [21] 41
    }
    else{
        _3823 = NOVALUE;
    }

    /** 		user_data = append(user_data, your_function[2])*/
    _2 = (int)SEQ_PTR(_your_function_7146);
    _3824 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_3824);
    Append(&_user_data_7152, _user_data_7152, _3824);
    _3824 = NOVALUE;

    /** 		your_function = your_function[1]*/
    _0 = _your_function_7146;
    _2 = (int)SEQ_PTR(_your_function_7146);
    _your_function_7146 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_your_function_7146);
    DeRef(_0);
L1: 

    /** 	source_orig_func = dir_source*/
    Ref(_dir_source_7148);
    DeRef(_source_orig_func_7154);
    _source_orig_func_7154 = _dir_source_7148;

    /** 	if sequence(dir_source) then*/
    _3827 = IS_SEQUENCE(_dir_source_7148);
    if (_3827 == 0)
    {
        _3827 = NOVALUE;
        goto L2; // [51] 67
    }
    else{
        _3827 = NOVALUE;
    }

    /** 		source_user_data = dir_source[2]*/
    DeRef(_source_user_data_7155);
    _2 = (int)SEQ_PTR(_dir_source_7148);
    _source_user_data_7155 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_source_user_data_7155);

    /** 		dir_source = dir_source[1]*/
    _0 = _dir_source_7148;
    _2 = (int)SEQ_PTR(_dir_source_7148);
    _dir_source_7148 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_dir_source_7148);
    DeRef(_0);
L2: 

    /** 	if not equal(dir_source, types:NO_ROUTINE_ID) then*/
    if (_dir_source_7148 == -99999)
    _3830 = 1;
    else if (IS_ATOM_INT(_dir_source_7148) && IS_ATOM_INT(-99999))
    _3830 = 0;
    else
    _3830 = (compare(_dir_source_7148, -99999) == 0);
    if (_3830 != 0)
    goto L3; // [73] 113
    _3830 = NOVALUE;

    /** 		if atom(source_orig_func) then*/
    _3832 = IS_ATOM(_source_orig_func_7154);
    if (_3832 == 0)
    {
        _3832 = NOVALUE;
        goto L4; // [81] 97
    }
    else{
        _3832 = NOVALUE;
    }

    /** 			d = call_func(dir_source, {path_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_path_name_7145);
    *((int *)(_2+4)) = _path_name_7145;
    _3833 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3833);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_dir_source_7148].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_d_7149);
    _d_7149 = _1;
    DeRefDS(_3833);
    _3833 = NOVALUE;
    goto L5; // [94] 143
L4: 

    /** 			d = call_func(dir_source, {path_name, source_user_data})*/
    Ref(_source_user_data_7155);
    RefDS(_path_name_7145);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _path_name_7145;
    ((int *)_2)[2] = _source_user_data_7155;
    _3835 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3835);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_dir_source_7148].addr;
    Ref(*(int *)(_2+4));
    Ref(*(int *)(_2+8));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4), 
                        *(int *)(_2+8)
                         );
    DeRef(_d_7149);
    _d_7149 = _1;
    DeRefDS(_3835);
    _3835 = NOVALUE;
    goto L5; // [110] 143
L3: 

    /** 	elsif my_dir = DEFAULT_DIR_SOURCE then*/

    /** 		d = default_dir(path_name)*/
    RefDS(_path_name_7145);
    _0 = _d_7149;
    _d_7149 = _11default_dir(_path_name_7145);
    DeRef(_0);
    goto L5; // [127] 143

    /** 		d = call_func(my_dir, {path_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_path_name_7145);
    *((int *)(_2+4)) = _path_name_7145;
    _3839 = MAKE_SEQ(_1);
    _1 = (int)SEQ_PTR(_3839);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[-2].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_d_7149);
    _d_7149 = _1;
    DeRefDS(_3839);
    _3839 = NOVALUE;
L5: 

    /** 	if atom(d) then*/
    _3841 = IS_ATOM(_d_7149);
    if (_3841 == 0)
    {
        _3841 = NOVALUE;
        goto L6; // [150] 160
    }
    else{
        _3841 = NOVALUE;
    }

    /** 		return W_BAD_PATH*/
    DeRefDS(_path_name_7145);
    DeRef(_your_function_7146);
    DeRef(_dir_source_7148);
    DeRef(_d_7149);
    DeRef(_abort_now_7150);
    DeRef(_orig_func_7151);
    DeRef(_user_data_7152);
    DeRef(_source_orig_func_7154);
    DeRef(_source_user_data_7155);
    return -1;
L6: 

    /** 	ifdef not UNIX then*/

    /** 	path_name = text:trim_tail(path_name, {' ', SLASH, '\n'})*/
    RefDS(_path_name_7145);
    RefDS(_3842);
    _0 = _path_name_7145;
    _path_name_7145 = _6trim_tail(_path_name_7145, _3842, 0);
    DeRefDS(_0);

    /** 	user_data[1] = path_name*/
    RefDS(_path_name_7145);
    _2 = (int)SEQ_PTR(_user_data_7152);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _path_name_7145;
    DeRef(_1);

    /** 	for i = 1 to length(d) do*/
    if (IS_SEQUENCE(_d_7149)){
            _3844 = SEQ_PTR(_d_7149)->length;
    }
    else {
        _3844 = 1;
    }
    {
        int _i_7187;
        _i_7187 = 1;
L7: 
        if (_i_7187 > _3844){
            goto L8; // [183] 338
        }

        /** 		if eu:find(d[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_d_7149);
        _3845 = (int)*(((s1_ptr)_2)->base + _i_7187);
        _2 = (int)SEQ_PTR(_3845);
        _3846 = (int)*(((s1_ptr)_2)->base + 1);
        _3845 = NOVALUE;
        RefDS(_3847);
        RefDS(_3780);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _3780;
        ((int *)_2)[2] = _3847;
        _3848 = MAKE_SEQ(_1);
        _3849 = find_from(_3846, _3848, 1);
        _3846 = NOVALUE;
        DeRefDS(_3848);
        _3848 = NOVALUE;
        if (_3849 == 0)
        {
            _3849 = NOVALUE;
            goto L9; // [209] 217
        }
        else{
            _3849 = NOVALUE;
        }

        /** 			continue*/
        goto LA; // [214] 333
L9: 

        /** 		user_data[2] = d[i]*/
        _2 = (int)SEQ_PTR(_d_7149);
        _3850 = (int)*(((s1_ptr)_2)->base + _i_7187);
        Ref(_3850);
        _2 = (int)SEQ_PTR(_user_data_7152);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _3850;
        if( _1 != _3850 ){
            DeRef(_1);
        }
        _3850 = NOVALUE;

        /** 		abort_now = call_func(your_function, user_data)*/
        _1 = (int)SEQ_PTR(_user_data_7152);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_your_function_7146].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
        }
        DeRef(_abort_now_7150);
        _abort_now_7150 = _1;

        /** 		if not equal(abort_now, 0) then*/
        if (_abort_now_7150 == 0)
        _3852 = 1;
        else if (IS_ATOM_INT(_abort_now_7150) && IS_ATOM_INT(0))
        _3852 = 0;
        else
        _3852 = (compare(_abort_now_7150, 0) == 0);
        if (_3852 != 0)
        goto LB; // [239] 249
        _3852 = NOVALUE;

        /** 			return abort_now*/
        DeRefDS(_path_name_7145);
        DeRef(_your_function_7146);
        DeRef(_dir_source_7148);
        DeRef(_d_7149);
        DeRef(_orig_func_7151);
        DeRefDS(_user_data_7152);
        DeRef(_source_orig_func_7154);
        DeRef(_source_user_data_7155);
        return _abort_now_7150;
LB: 

        /** 		if eu:find('d', d[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_d_7149);
        _3854 = (int)*(((s1_ptr)_2)->base + _i_7187);
        _2 = (int)SEQ_PTR(_3854);
        _3855 = (int)*(((s1_ptr)_2)->base + 2);
        _3854 = NOVALUE;
        _3856 = find_from(100, _3855, 1);
        _3855 = NOVALUE;
        if (_3856 == 0)
        {
            _3856 = NOVALUE;
            goto LC; // [264] 331
        }
        else{
            _3856 = NOVALUE;
        }

        /** 			if scan_subdirs then*/
        if (_scan_subdirs_7147 == 0)
        {
            goto LD; // [269] 330
        }
        else{
        }

        /** 				abort_now = walk_dir(path_name & SLASH & d[i][D_NAME],*/
        _2 = (int)SEQ_PTR(_d_7149);
        _3857 = (int)*(((s1_ptr)_2)->base + _i_7187);
        _2 = (int)SEQ_PTR(_3857);
        _3858 = (int)*(((s1_ptr)_2)->base + 1);
        _3857 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _3858;
            concat_list[1] = 47;
            concat_list[2] = _path_name_7145;
            Concat_N((object_ptr)&_3859, concat_list, 3);
        }
        _3858 = NOVALUE;
        DeRef(_3860);
        _3860 = _scan_subdirs_7147;
        Ref(_orig_func_7151);
        Ref(_source_orig_func_7154);
        _0 = _abort_now_7150;
        _abort_now_7150 = _11walk_dir(_3859, _orig_func_7151, _3860, _source_orig_func_7154);
        DeRef(_0);
        _3859 = NOVALUE;
        _3860 = NOVALUE;

        /** 				if not equal(abort_now, 0) and */
        if (_abort_now_7150 == 0)
        _3862 = 1;
        else if (IS_ATOM_INT(_abort_now_7150) && IS_ATOM_INT(0))
        _3862 = 0;
        else
        _3862 = (compare(_abort_now_7150, 0) == 0);
        _3863 = (_3862 == 0);
        _3862 = NOVALUE;
        if (_3863 == 0) {
            goto LE; // [307] 329
        }
        if (_abort_now_7150 == -1)
        _3865 = 1;
        else if (IS_ATOM_INT(_abort_now_7150) && IS_ATOM_INT(-1))
        _3865 = 0;
        else
        _3865 = (compare(_abort_now_7150, -1) == 0);
        _3866 = (_3865 == 0);
        _3865 = NOVALUE;
        if (_3866 == 0)
        {
            DeRef(_3866);
            _3866 = NOVALUE;
            goto LE; // [319] 329
        }
        else{
            DeRef(_3866);
            _3866 = NOVALUE;
        }

        /** 					return abort_now*/
        DeRefDS(_path_name_7145);
        DeRef(_your_function_7146);
        DeRef(_dir_source_7148);
        DeRef(_d_7149);
        DeRef(_orig_func_7151);
        DeRef(_user_data_7152);
        DeRef(_source_orig_func_7154);
        DeRef(_source_user_data_7155);
        DeRef(_3863);
        _3863 = NOVALUE;
        return _abort_now_7150;
LE: 
LD: 
LC: 

        /** 	end for*/
LA: 
        _i_7187 = _i_7187 + 1;
        goto L7; // [333] 190
L8: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_path_name_7145);
    DeRef(_your_function_7146);
    DeRef(_dir_source_7148);
    DeRef(_d_7149);
    DeRef(_abort_now_7150);
    DeRef(_orig_func_7151);
    DeRef(_user_data_7152);
    DeRef(_source_orig_func_7154);
    DeRef(_source_user_data_7155);
    DeRef(_3863);
    _3863 = NOVALUE;
    return 0;
    ;
}
int walk_dir() __attribute__ ((alias ("_11walk_dir")));


int _11create_directory(int _name_7218, int _mode_7219, int _mkparent_7221)
{
    int _pname_7222 = NOVALUE;
    int _ret_7223 = NOVALUE;
    int _pos_7224 = NOVALUE;
    int _3887 = NOVALUE;
    int _3886 = NOVALUE;
    int _3883 = NOVALUE;
    int _3882 = NOVALUE;
    int _3881 = NOVALUE;
    int _3880 = NOVALUE;
    int _3877 = NOVALUE;
    int _3874 = NOVALUE;
    int _3873 = NOVALUE;
    int _3871 = NOVALUE;
    int _3870 = NOVALUE;
    int _3868 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mode_7219)) {
        _1 = (long)(DBL_PTR(_mode_7219)->dbl);
        DeRefDS(_mode_7219);
        _mode_7219 = _1;
    }
    if (!IS_ATOM_INT(_mkparent_7221)) {
        _1 = (long)(DBL_PTR(_mkparent_7221)->dbl);
        DeRefDS(_mkparent_7221);
        _mkparent_7221 = _1;
    }

    /** 	if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_7218)){
            _3868 = SEQ_PTR(_name_7218)->length;
    }
    else {
        _3868 = 1;
    }
    if (_3868 != 0)
    goto L1; // [12] 23

    /** 		return 0 -- failed*/
    DeRefDS(_name_7218);
    DeRef(_pname_7222);
    DeRef(_ret_7223);
    return 0;
L1: 

    /** 	if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_7218)){
            _3870 = SEQ_PTR(_name_7218)->length;
    }
    else {
        _3870 = 1;
    }
    _2 = (int)SEQ_PTR(_name_7218);
    _3871 = (int)*(((s1_ptr)_2)->base + _3870);
    if (binary_op_a(NOTEQ, _3871, 47)){
        _3871 = NOVALUE;
        goto L2; // [32] 51
    }
    _3871 = NOVALUE;

    /** 		name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_7218)){
            _3873 = SEQ_PTR(_name_7218)->length;
    }
    else {
        _3873 = 1;
    }
    _3874 = _3873 - 1;
    _3873 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_7218;
    RHS_Slice(_name_7218, 1, _3874);
L2: 

    /** 	if mkparent != 0 then*/
    if (_mkparent_7221 == 0)
    goto L3; // [53] 101

    /** 		pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_7218)){
            _3877 = SEQ_PTR(_name_7218)->length;
    }
    else {
        _3877 = 1;
    }
    RefDS(_name_7218);
    _pos_7224 = _9rfind(47, _name_7218, _3877);
    _3877 = NOVALUE;
    if (!IS_ATOM_INT(_pos_7224)) {
        _1 = (long)(DBL_PTR(_pos_7224)->dbl);
        DeRefDS(_pos_7224);
        _pos_7224 = _1;
    }

    /** 		if pos != 0 then*/
    if (_pos_7224 == 0)
    goto L4; // [72] 100

    /** 			ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3880 = _pos_7224 - 1;
    rhs_slice_target = (object_ptr)&_3881;
    RHS_Slice(_name_7218, 1, _3880);
    DeRef(_3882);
    _3882 = _mode_7219;
    DeRef(_3883);
    _3883 = _mkparent_7221;
    _0 = _ret_7223;
    _ret_7223 = _11create_directory(_3881, _3882, _3883);
    DeRef(_0);
    _3881 = NOVALUE;
    _3882 = NOVALUE;
    _3883 = NOVALUE;
L4: 
L3: 

    /** 	pname = machine:allocate_string(name)*/
    RefDS(_name_7218);
    _0 = _pname_7222;
    _pname_7222 = _14allocate_string(_name_7218, 0);
    DeRef(_0);

    /** 	ifdef UNIX then*/

    /** 		ret = not c_func(xCreateDirectory, {pname, mode})*/
    Ref(_pname_7222);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pname_7222;
    ((int *)_2)[2] = _mode_7219;
    _3886 = MAKE_SEQ(_1);
    _3887 = call_c(1, _11xCreateDirectory_6988, _3886);
    DeRefDS(_3886);
    _3886 = NOVALUE;
    DeRef(_ret_7223);
    if (IS_ATOM_INT(_3887)) {
        _ret_7223 = (_3887 == 0);
    }
    else {
        _ret_7223 = unary_op(NOT, _3887);
    }
    DeRef(_3887);
    _3887 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_name_7218);
    DeRef(_pname_7222);
    DeRef(_3874);
    _3874 = NOVALUE;
    DeRef(_3880);
    _3880 = NOVALUE;
    return _ret_7223;
    ;
}
int create_directory() __attribute__ ((alias ("_11create_directory")));


int _11create_file(int _name_7252)
{
    int _fh_7253 = NOVALUE;
    int _ret_7255 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fh = open(name, "wb")*/
    _fh_7253 = EOpen(_name_7252, _1325, 0);

    /** 	integer ret = (fh != -1)*/
    _ret_7255 = (_fh_7253 != -1);

    /** 	if ret then*/
    if (_ret_7255 == 0)
    {
        goto L1; // [18] 26
    }
    else{
    }

    /** 		close(fh)*/
    EClose(_fh_7253);
L1: 

    /** 	return ret*/
    DeRefDS(_name_7252);
    return _ret_7255;
    ;
}
int create_file() __attribute__ ((alias ("_11create_file")));


int _11delete_file(int _name_7260)
{
    int _pfilename_7261 = NOVALUE;
    int _success_7263 = NOVALUE;
    int _3892 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_7260);
    _0 = _pfilename_7261;
    _pfilename_7261 = _14allocate_string(_name_7260, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_7261);
    *((int *)(_2+4)) = _pfilename_7261;
    _3892 = MAKE_SEQ(_1);
    _success_7263 = call_c(1, _11xDeleteFile_6984, _3892);
    DeRefDS(_3892);
    _3892 = NOVALUE;
    if (!IS_ATOM_INT(_success_7263)) {
        _1 = (long)(DBL_PTR(_success_7263)->dbl);
        DeRefDS(_success_7263);
        _success_7263 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 		success = not success*/
    _success_7263 = (_success_7263 == 0);

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_7261);
    _14free(_pfilename_7261);

    /** 	return success*/
    DeRefDS(_name_7260);
    DeRef(_pfilename_7261);
    return _success_7263;
    ;
}
int delete_file() __attribute__ ((alias ("_11delete_file")));


int _11curdir(int _drive_id_7269)
{
    int _lCurDir_7270 = NOVALUE;
    int _current_dir_inlined_current_dir_at_6_7272 = NOVALUE;
    int _3896 = NOVALUE;
    int _3895 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_drive_id_7269)) {
        _1 = (long)(DBL_PTR(_drive_id_7269)->dbl);
        DeRefDS(_drive_id_7269);
        _drive_id_7269 = _1;
    }

    /** 	ifdef not LINUX then*/

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_7270);
    _lCurDir_7270 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_7270)){
            _3895 = SEQ_PTR(_lCurDir_7270)->length;
    }
    else {
        _3895 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_7270);
    _3896 = (int)*(((s1_ptr)_2)->base + _3895);
    if (_3896 == 47)
    goto L1; // [27] 38

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_7270, _lCurDir_7270, 47);
L1: 

    /** 	return lCurDir*/
    _3896 = NOVALUE;
    return _lCurDir_7270;
    ;
}
int curdir() __attribute__ ((alias ("_11curdir")));


int _11init_curdir()
{
    int _0, _1, _2;
    

    /** 	return InitCurDir*/
    RefDS(_11InitCurDir_7278);
    return _11InitCurDir_7278;
    ;
}
int init_curdir() __attribute__ ((alias ("_11init_curdir")));


int _11clear_directory(int _path_7284, int _recurse_7285)
{
    int _files_7286 = NOVALUE;
    int _ret_7287 = NOVALUE;
    int _cnt_7321 = NOVALUE;
    int _3933 = NOVALUE;
    int _3932 = NOVALUE;
    int _3931 = NOVALUE;
    int _3930 = NOVALUE;
    int _3926 = NOVALUE;
    int _3925 = NOVALUE;
    int _3924 = NOVALUE;
    int _3923 = NOVALUE;
    int _3922 = NOVALUE;
    int _3921 = NOVALUE;
    int _3920 = NOVALUE;
    int _3918 = NOVALUE;
    int _3917 = NOVALUE;
    int _3916 = NOVALUE;
    int _3915 = NOVALUE;
    int _3912 = NOVALUE;
    int _3911 = NOVALUE;
    int _3908 = NOVALUE;
    int _3906 = NOVALUE;
    int _3905 = NOVALUE;
    int _3903 = NOVALUE;
    int _3902 = NOVALUE;
    int _3900 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recurse_7285)) {
        _1 = (long)(DBL_PTR(_recurse_7285)->dbl);
        DeRefDS(_recurse_7285);
        _recurse_7285 = _1;
    }

    /** 	if length(path) > 0 then*/
    if (IS_SEQUENCE(_path_7284)){
            _3900 = SEQ_PTR(_path_7284)->length;
    }
    else {
        _3900 = 1;
    }
    if (_3900 <= 0)
    goto L1; // [10] 43

    /** 		if path[$] = SLASH then*/
    if (IS_SEQUENCE(_path_7284)){
            _3902 = SEQ_PTR(_path_7284)->length;
    }
    else {
        _3902 = 1;
    }
    _2 = (int)SEQ_PTR(_path_7284);
    _3903 = (int)*(((s1_ptr)_2)->base + _3902);
    if (binary_op_a(NOTEQ, _3903, 47)){
        _3903 = NOVALUE;
        goto L2; // [23] 42
    }
    _3903 = NOVALUE;

    /** 			path = path[1 .. $-1]*/
    if (IS_SEQUENCE(_path_7284)){
            _3905 = SEQ_PTR(_path_7284)->length;
    }
    else {
        _3905 = 1;
    }
    _3906 = _3905 - 1;
    _3905 = NOVALUE;
    rhs_slice_target = (object_ptr)&_path_7284;
    RHS_Slice(_path_7284, 1, _3906);
L2: 
L1: 

    /** 	if length(path) = 0 then*/
    if (IS_SEQUENCE(_path_7284)){
            _3908 = SEQ_PTR(_path_7284)->length;
    }
    else {
        _3908 = 1;
    }
    if (_3908 != 0)
    goto L3; // [48] 59

    /** 		return 0 -- Nothing specified to clear. Not safe to assume anything.*/
    DeRefDS(_path_7284);
    DeRef(_files_7286);
    DeRef(_3906);
    _3906 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 	files = dir(path)*/
    RefDS(_path_7284);
    _0 = _files_7286;
    _files_7286 = _11dir(_path_7284);
    DeRef(_0);

    /** 	if atom(files) then*/
    _3911 = IS_ATOM(_files_7286);
    if (_3911 == 0)
    {
        _3911 = NOVALUE;
        goto L4; // [72] 82
    }
    else{
        _3911 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_path_7284);
    DeRef(_files_7286);
    DeRef(_3906);
    _3906 = NOVALUE;
    return 0;
L4: 

    /** 	ifdef WINDOWS then*/

    /** 		if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_7286)){
            _3912 = SEQ_PTR(_files_7286)->length;
    }
    else {
        _3912 = 1;
    }
    if (_3912 >= 2)
    goto L5; // [89] 100

    /** 			return 0 -- not a directory*/
    DeRefDS(_path_7284);
    DeRef(_files_7286);
    DeRef(_3906);
    _3906 = NOVALUE;
    return 0;
L5: 

    /** 	ret = 1*/
    _ret_7287 = 1;

    /** 	path &= SLASH*/
    Append(&_path_7284, _path_7284, 47);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_7286)){
            _3915 = SEQ_PTR(_files_7286)->length;
    }
    else {
        _3915 = 1;
    }
    {
        int _i_7309;
        _i_7309 = 1;
L6: 
        if (_i_7309 > _3915){
            goto L7; // [118] 270
        }

        /** 			if files[i][D_NAME][1] = '.' then*/
        _2 = (int)SEQ_PTR(_files_7286);
        _3916 = (int)*(((s1_ptr)_2)->base + _i_7309);
        _2 = (int)SEQ_PTR(_3916);
        _3917 = (int)*(((s1_ptr)_2)->base + 1);
        _3916 = NOVALUE;
        _2 = (int)SEQ_PTR(_3917);
        _3918 = (int)*(((s1_ptr)_2)->base + 1);
        _3917 = NOVALUE;
        if (binary_op_a(NOTEQ, _3918, 46)){
            _3918 = NOVALUE;
            goto L8; // [139] 148
        }
        _3918 = NOVALUE;

        /** 				continue*/
        goto L9; // [145] 265
L8: 

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_7286);
        _3920 = (int)*(((s1_ptr)_2)->base + _i_7309);
        _2 = (int)SEQ_PTR(_3920);
        _3921 = (int)*(((s1_ptr)_2)->base + 2);
        _3920 = NOVALUE;
        _3922 = find_from(100, _3921, 1);
        _3921 = NOVALUE;
        if (_3922 == 0)
        {
            _3922 = NOVALUE;
            goto LA; // [163] 227
        }
        else{
            _3922 = NOVALUE;
        }

        /** 				if recurse then*/
        if (_recurse_7285 == 0)
        {
            goto L9; // [168] 265
        }
        else{
        }

        /** 					integer cnt = clear_directory(path & files[i][D_NAME], recurse)*/
        _2 = (int)SEQ_PTR(_files_7286);
        _3923 = (int)*(((s1_ptr)_2)->base + _i_7309);
        _2 = (int)SEQ_PTR(_3923);
        _3924 = (int)*(((s1_ptr)_2)->base + 1);
        _3923 = NOVALUE;
        if (IS_SEQUENCE(_path_7284) && IS_ATOM(_3924)) {
            Ref(_3924);
            Append(&_3925, _path_7284, _3924);
        }
        else if (IS_ATOM(_path_7284) && IS_SEQUENCE(_3924)) {
        }
        else {
            Concat((object_ptr)&_3925, _path_7284, _3924);
        }
        _3924 = NOVALUE;
        DeRef(_3926);
        _3926 = _recurse_7285;
        _cnt_7321 = _11clear_directory(_3925, _3926);
        _3925 = NOVALUE;
        _3926 = NOVALUE;
        if (!IS_ATOM_INT(_cnt_7321)) {
            _1 = (long)(DBL_PTR(_cnt_7321)->dbl);
            DeRefDS(_cnt_7321);
            _cnt_7321 = _1;
        }

        /** 					if cnt = 0 then*/
        if (_cnt_7321 != 0)
        goto LB; // [197] 208

        /** 						return 0*/
        DeRefDS(_path_7284);
        DeRef(_files_7286);
        DeRef(_3906);
        _3906 = NOVALUE;
        return 0;
LB: 

        /** 					ret += cnt*/
        _ret_7287 = _ret_7287 + _cnt_7321;
        goto LC; // [216] 263

        /** 					continue*/
        goto L9; // [221] 265
        goto LC; // [224] 263
LA: 

        /** 				if delete_file(path & files[i][D_NAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_files_7286);
        _3930 = (int)*(((s1_ptr)_2)->base + _i_7309);
        _2 = (int)SEQ_PTR(_3930);
        _3931 = (int)*(((s1_ptr)_2)->base + 1);
        _3930 = NOVALUE;
        if (IS_SEQUENCE(_path_7284) && IS_ATOM(_3931)) {
            Ref(_3931);
            Append(&_3932, _path_7284, _3931);
        }
        else if (IS_ATOM(_path_7284) && IS_SEQUENCE(_3931)) {
        }
        else {
            Concat((object_ptr)&_3932, _path_7284, _3931);
        }
        _3931 = NOVALUE;
        _3933 = _11delete_file(_3932);
        _3932 = NOVALUE;
        if (binary_op_a(NOTEQ, _3933, 0)){
            DeRef(_3933);
            _3933 = NOVALUE;
            goto LD; // [245] 256
        }
        DeRef(_3933);
        _3933 = NOVALUE;

        /** 					return 0*/
        DeRefDS(_path_7284);
        DeRef(_files_7286);
        DeRef(_3906);
        _3906 = NOVALUE;
        return 0;
LD: 

        /** 				ret += 1*/
        _ret_7287 = _ret_7287 + 1;
LC: 

        /** 		end for*/
L9: 
        _i_7309 = _i_7309 + 1;
        goto L6; // [265] 125
L7: 
        ;
    }

    /** 	return ret*/
    DeRefDS(_path_7284);
    DeRef(_files_7286);
    DeRef(_3906);
    _3906 = NOVALUE;
    return _ret_7287;
    ;
}
int clear_directory() __attribute__ ((alias ("_11clear_directory")));


int _11remove_directory(int _dir_name_7341, int _force_7342)
{
    int _pname_7343 = NOVALUE;
    int _ret_7344 = NOVALUE;
    int _files_7345 = NOVALUE;
    int _D_NAME_7346 = NOVALUE;
    int _D_ATTRIBUTES_7347 = NOVALUE;
    int _3970 = NOVALUE;
    int _3966 = NOVALUE;
    int _3965 = NOVALUE;
    int _3964 = NOVALUE;
    int _3962 = NOVALUE;
    int _3961 = NOVALUE;
    int _3960 = NOVALUE;
    int _3959 = NOVALUE;
    int _3958 = NOVALUE;
    int _3957 = NOVALUE;
    int _3956 = NOVALUE;
    int _3955 = NOVALUE;
    int _3954 = NOVALUE;
    int _3953 = NOVALUE;
    int _3952 = NOVALUE;
    int _3951 = NOVALUE;
    int _3948 = NOVALUE;
    int _3947 = NOVALUE;
    int _3944 = NOVALUE;
    int _3942 = NOVALUE;
    int _3941 = NOVALUE;
    int _3939 = NOVALUE;
    int _3938 = NOVALUE;
    int _3936 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_force_7342)) {
        _1 = (long)(DBL_PTR(_force_7342)->dbl);
        DeRefDS(_force_7342);
        _force_7342 = _1;
    }

    /** 	integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_7346 = 1;
    _D_ATTRIBUTES_7347 = 2;

    /**  	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_7341)){
            _3936 = SEQ_PTR(_dir_name_7341)->length;
    }
    else {
        _3936 = 1;
    }
    if (_3936 <= 0)
    goto L1; // [18] 51

    /** 		if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_7341)){
            _3938 = SEQ_PTR(_dir_name_7341)->length;
    }
    else {
        _3938 = 1;
    }
    _2 = (int)SEQ_PTR(_dir_name_7341);
    _3939 = (int)*(((s1_ptr)_2)->base + _3938);
    if (binary_op_a(NOTEQ, _3939, 47)){
        _3939 = NOVALUE;
        goto L2; // [31] 50
    }
    _3939 = NOVALUE;

    /** 			dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_7341)){
            _3941 = SEQ_PTR(_dir_name_7341)->length;
    }
    else {
        _3941 = 1;
    }
    _3942 = _3941 - 1;
    _3941 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_7341;
    RHS_Slice(_dir_name_7341, 1, _3942);
L2: 
L1: 

    /** 	if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_7341)){
            _3944 = SEQ_PTR(_dir_name_7341)->length;
    }
    else {
        _3944 = 1;
    }
    if (_3944 != 0)
    goto L3; // [56] 67

    /** 		return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_7341);
    DeRef(_pname_7343);
    DeRef(_ret_7344);
    DeRef(_files_7345);
    DeRef(_3942);
    _3942 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 	files = dir(dir_name)*/
    RefDS(_dir_name_7341);
    _0 = _files_7345;
    _files_7345 = _11dir(_dir_name_7341);
    DeRef(_0);

    /** 	if atom(files) then*/
    _3947 = IS_ATOM(_files_7345);
    if (_3947 == 0)
    {
        _3947 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3947 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_dir_name_7341);
    DeRef(_pname_7343);
    DeRef(_ret_7344);
    DeRef(_files_7345);
    DeRef(_3942);
    _3942 = NOVALUE;
    return 0;
L4: 

    /** 	if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_7345)){
            _3948 = SEQ_PTR(_files_7345)->length;
    }
    else {
        _3948 = 1;
    }
    if (_3948 >= 2)
    goto L5; // [95] 106

    /** 		return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_7341);
    DeRef(_pname_7343);
    DeRef(_ret_7344);
    DeRef(_files_7345);
    DeRef(_3942);
    _3942 = NOVALUE;
    return 0;
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	dir_name &= SLASH*/
    Append(&_dir_name_7341, _dir_name_7341, 47);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_7345)){
            _3951 = SEQ_PTR(_files_7345)->length;
    }
    else {
        _3951 = 1;
    }
    {
        int _i_7369;
        _i_7369 = 1;
L6: 
        if (_i_7369 > _3951){
            goto L7; // [121] 240
        }

        /** 			if find( files[i][D_NAME], {".",".."}) then*/
        _2 = (int)SEQ_PTR(_files_7345);
        _3952 = (int)*(((s1_ptr)_2)->base + _i_7369);
        _2 = (int)SEQ_PTR(_3952);
        _3953 = (int)*(((s1_ptr)_2)->base + _D_NAME_7346);
        _3952 = NOVALUE;
        RefDS(_3847);
        RefDS(_3780);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _3780;
        ((int *)_2)[2] = _3847;
        _3954 = MAKE_SEQ(_1);
        _3955 = find_from(_3953, _3954, 1);
        _3953 = NOVALUE;
        DeRefDS(_3954);
        _3954 = NOVALUE;
        if (_3955 == 0)
        {
            _3955 = NOVALUE;
            goto L8; // [147] 155
        }
        else{
            _3955 = NOVALUE;
        }

        /** 				continue*/
        goto L9; // [152] 235
L8: 

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_7345);
        _3956 = (int)*(((s1_ptr)_2)->base + _i_7369);
        _2 = (int)SEQ_PTR(_3956);
        _3957 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_7347);
        _3956 = NOVALUE;
        _3958 = find_from(100, _3957, 1);
        _3957 = NOVALUE;
        if (_3958 == 0)
        {
            _3958 = NOVALUE;
            goto LA; // [170] 200
        }
        else{
            _3958 = NOVALUE;
        }

        /** 				ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (int)SEQ_PTR(_files_7345);
        _3959 = (int)*(((s1_ptr)_2)->base + _i_7369);
        _2 = (int)SEQ_PTR(_3959);
        _3960 = (int)*(((s1_ptr)_2)->base + _D_NAME_7346);
        _3959 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _3960;
            concat_list[2] = _dir_name_7341;
            Concat_N((object_ptr)&_3961, concat_list, 3);
        }
        _3960 = NOVALUE;
        DeRef(_3962);
        _3962 = _force_7342;
        _0 = _ret_7344;
        _ret_7344 = _11remove_directory(_3961, _3962);
        DeRef(_0);
        _3961 = NOVALUE;
        _3962 = NOVALUE;
        goto LB; // [197] 219
LA: 

        /** 				ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (int)SEQ_PTR(_files_7345);
        _3964 = (int)*(((s1_ptr)_2)->base + _i_7369);
        _2 = (int)SEQ_PTR(_3964);
        _3965 = (int)*(((s1_ptr)_2)->base + _D_NAME_7346);
        _3964 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_7341) && IS_ATOM(_3965)) {
            Ref(_3965);
            Append(&_3966, _dir_name_7341, _3965);
        }
        else if (IS_ATOM(_dir_name_7341) && IS_SEQUENCE(_3965)) {
        }
        else {
            Concat((object_ptr)&_3966, _dir_name_7341, _3965);
        }
        _3965 = NOVALUE;
        _0 = _ret_7344;
        _ret_7344 = _11delete_file(_3966);
        DeRef(_0);
        _3966 = NOVALUE;
LB: 

        /** 			if not ret then*/
        if (IS_ATOM_INT(_ret_7344)) {
            if (_ret_7344 != 0){
                goto LC; // [223] 233
            }
        }
        else {
            if (DBL_PTR(_ret_7344)->dbl != 0.0){
                goto LC; // [223] 233
            }
        }

        /** 				return 0*/
        DeRefDS(_dir_name_7341);
        DeRef(_pname_7343);
        DeRef(_ret_7344);
        DeRef(_files_7345);
        DeRef(_3942);
        _3942 = NOVALUE;
        return 0;
LC: 

        /** 		end for*/
L9: 
        _i_7369 = _i_7369 + 1;
        goto L6; // [235] 128
L7: 
        ;
    }

    /** 	pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_7341);
    _0 = _pname_7343;
    _pname_7343 = _14allocate_string(_dir_name_7341, 0);
    DeRef(_0);

    /** 	ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pname_7343);
    *((int *)(_2+4)) = _pname_7343;
    _3970 = MAKE_SEQ(_1);
    DeRef(_ret_7344);
    _ret_7344 = call_c(1, _11xRemoveDirectory_6992, _3970);
    DeRefDS(_3970);
    _3970 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 			ret = not ret */
    _0 = _ret_7344;
    if (IS_ATOM_INT(_ret_7344)) {
        _ret_7344 = (_ret_7344 == 0);
    }
    else {
        _ret_7344 = unary_op(NOT, _ret_7344);
    }
    DeRef(_0);

    /** 	machine:free(pname)*/
    Ref(_pname_7343);
    _14free(_pname_7343);

    /** 	return ret*/
    DeRefDS(_dir_name_7341);
    DeRef(_pname_7343);
    DeRef(_files_7345);
    DeRef(_3942);
    _3942 = NOVALUE;
    return _ret_7344;
    ;
}
int remove_directory() __attribute__ ((alias ("_11remove_directory")));


int _11pathinfo(int _path_7403, int _std_slash_7404)
{
    int _slash_7405 = NOVALUE;
    int _period_7406 = NOVALUE;
    int _ch_7407 = NOVALUE;
    int _dir_name_7408 = NOVALUE;
    int _file_name_7409 = NOVALUE;
    int _file_ext_7410 = NOVALUE;
    int _file_full_7411 = NOVALUE;
    int _drive_id_7412 = NOVALUE;
    int _from_slash_7444 = NOVALUE;
    int _3998 = NOVALUE;
    int _3991 = NOVALUE;
    int _3990 = NOVALUE;
    int _3987 = NOVALUE;
    int _3986 = NOVALUE;
    int _3984 = NOVALUE;
    int _3983 = NOVALUE;
    int _3980 = NOVALUE;
    int _3978 = NOVALUE;
    int _3977 = NOVALUE;
    int _3976 = NOVALUE;
    int _3975 = NOVALUE;
    int _3973 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_std_slash_7404)) {
        _1 = (long)(DBL_PTR(_std_slash_7404)->dbl);
        DeRefDS(_std_slash_7404);
        _std_slash_7404 = _1;
    }

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_7408);
    _dir_name_7408 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_7409);
    _file_name_7409 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_7410);
    _file_ext_7410 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_7411);
    _file_full_7411 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_7412);
    _drive_id_7412 = _5;

    /** 	slash = 0*/
    _slash_7405 = 0;

    /** 	period = 0*/
    _period_7406 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7403)){
            _3973 = SEQ_PTR(_path_7403)->length;
    }
    else {
        _3973 = 1;
    }
    {
        int _i_7414;
        _i_7414 = _3973;
L1: 
        if (_i_7414 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_7403);
        _ch_7407 = (int)*(((s1_ptr)_2)->base + _i_7414);
        if (!IS_ATOM_INT(_ch_7407))
        _ch_7407 = (long)DBL_PTR(_ch_7407)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _3975 = (_period_7406 == 0);
        if (_3975 == 0) {
            goto L3; // [74] 94
        }
        _3977 = (_ch_7407 == 46);
        if (_3977 == 0)
        {
            DeRef(_3977);
            _3977 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3977);
            _3977 = NOVALUE;
        }

        /** 			period = i*/
        _period_7406 = _i_7414;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _3978 = find_from(_ch_7407, _11SLASHES_7008, 1);
        if (_3978 == 0)
        {
            _3978 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3978 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_7405 = _i_7414;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_7414 = _i_7414 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_7405 <= 0)
    goto L6; // [124] 142

    /** 		dir_name = path[1..slash-1]*/
    _3980 = _slash_7405 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_7408;
    RHS_Slice(_path_7403, 1, _3980);

    /** 		ifdef not UNIX then*/
L6: 

    /** 	if period > 0 then*/
    if (_period_7406 <= 0)
    goto L7; // [144] 188

    /** 		file_name = path[slash+1..period-1]*/
    _3983 = _slash_7405 + 1;
    if (_3983 > MAXINT){
        _3983 = NewDouble((double)_3983);
    }
    _3984 = _period_7406 - 1;
    rhs_slice_target = (object_ptr)&_file_name_7409;
    RHS_Slice(_path_7403, _3983, _3984);

    /** 		file_ext = path[period+1..$]*/
    _3986 = _period_7406 + 1;
    if (_3986 > MAXINT){
        _3986 = NewDouble((double)_3986);
    }
    if (IS_SEQUENCE(_path_7403)){
            _3987 = SEQ_PTR(_path_7403)->length;
    }
    else {
        _3987 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_7410;
    RHS_Slice(_path_7403, _3986, _3987);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_7410;
        concat_list[1] = 46;
        concat_list[2] = _file_name_7409;
        Concat_N((object_ptr)&_file_full_7411, concat_list, 3);
    }
    goto L8; // [185] 210
L7: 

    /** 		file_name = path[slash+1..$]*/
    _3990 = _slash_7405 + 1;
    if (_3990 > MAXINT){
        _3990 = NewDouble((double)_3990);
    }
    if (IS_SEQUENCE(_path_7403)){
            _3991 = SEQ_PTR(_path_7403)->length;
    }
    else {
        _3991 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_7409;
    RHS_Slice(_path_7403, _3990, _3991);

    /** 		file_full = file_name*/
    RefDS(_file_name_7409);
    DeRef(_file_full_7411);
    _file_full_7411 = _file_name_7409;
L8: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_7404 == 0)
    goto L9; // [212] 278

    /** 		if std_slash < 0 then*/
    if (_std_slash_7404 >= 0)
    goto LA; // [218] 254

    /** 			std_slash = SLASH*/
    _std_slash_7404 = 47;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "\\"*/
    RefDS(_910);
    DeRefi(_from_slash_7444);
    _from_slash_7444 = _910;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_7444);
    RefDS(_dir_name_7408);
    _0 = _dir_name_7408;
    _dir_name_7408 = _9match_replace(_from_slash_7444, _dir_name_7408, 47, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_7444);
    _from_slash_7444 = NOVALUE;
    goto LB; // [251] 277
LA: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_910);
    RefDS(_dir_name_7408);
    _0 = _dir_name_7408;
    _dir_name_7408 = _9match_replace(_910, _dir_name_7408, _std_slash_7404, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3761);
    RefDS(_dir_name_7408);
    _0 = _dir_name_7408;
    _dir_name_7408 = _9match_replace(_3761, _dir_name_7408, _std_slash_7404, 0);
    DeRefDS(_0);
LB: 
L9: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_7408);
    *((int *)(_2+4)) = _dir_name_7408;
    RefDS(_file_full_7411);
    *((int *)(_2+8)) = _file_full_7411;
    RefDS(_file_name_7409);
    *((int *)(_2+12)) = _file_name_7409;
    RefDS(_file_ext_7410);
    *((int *)(_2+16)) = _file_ext_7410;
    RefDS(_drive_id_7412);
    *((int *)(_2+20)) = _drive_id_7412;
    _3998 = MAKE_SEQ(_1);
    DeRefDS(_path_7403);
    DeRefDS(_dir_name_7408);
    DeRefDS(_file_name_7409);
    DeRefDS(_file_ext_7410);
    DeRefDS(_file_full_7411);
    DeRefDS(_drive_id_7412);
    DeRef(_3975);
    _3975 = NOVALUE;
    DeRef(_3980);
    _3980 = NOVALUE;
    DeRef(_3983);
    _3983 = NOVALUE;
    DeRef(_3984);
    _3984 = NOVALUE;
    DeRef(_3986);
    _3986 = NOVALUE;
    DeRef(_3990);
    _3990 = NOVALUE;
    return _3998;
    ;
}
int pathinfo() __attribute__ ((alias ("_11pathinfo")));


int _11dirname(int _path_7452, int _pcd_7453)
{
    int _data_7454 = NOVALUE;
    int _4003 = NOVALUE;
    int _4001 = NOVALUE;
    int _4000 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pcd_7453)) {
        _1 = (long)(DBL_PTR(_pcd_7453)->dbl);
        DeRefDS(_pcd_7453);
        _pcd_7453 = _1;
    }

    /** 	data = pathinfo(path)*/
    RefDS(_path_7452);
    _0 = _data_7454;
    _data_7454 = _11pathinfo(_path_7452, 0);
    DeRef(_0);

    /** 	if pcd then*/
    if (_pcd_7453 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** 		if length(data[1]) = 0 then*/
    _2 = (int)SEQ_PTR(_data_7454);
    _4000 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_4000)){
            _4001 = SEQ_PTR(_4000)->length;
    }
    else {
        _4001 = 1;
    }
    _4000 = NOVALUE;
    if (_4001 != 0)
    goto L2; // [28] 39

    /** 			return "."*/
    RefDS(_3780);
    DeRefDS(_path_7452);
    DeRefDS(_data_7454);
    _4000 = NOVALUE;
    return _3780;
L2: 
L1: 

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_7454);
    _4003 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4003);
    DeRefDS(_path_7452);
    DeRefDS(_data_7454);
    _4000 = NOVALUE;
    return _4003;
    ;
}
int dirname() __attribute__ ((alias ("_11dirname")));


int _11pathname(int _path_7464)
{
    int _data_7465 = NOVALUE;
    int _stop_7466 = NOVALUE;
    int _4008 = NOVALUE;
    int _4007 = NOVALUE;
    int _4005 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = canonical_path(path)*/
    RefDS(_path_7464);
    _0 = _data_7465;
    _data_7465 = _11canonical_path(_path_7464, 0, 0);
    DeRef(_0);

    /** 	stop = search:rfind(SLASH, data)*/
    if (IS_SEQUENCE(_data_7465)){
            _4005 = SEQ_PTR(_data_7465)->length;
    }
    else {
        _4005 = 1;
    }
    RefDS(_data_7465);
    _stop_7466 = _9rfind(47, _data_7465, _4005);
    _4005 = NOVALUE;
    if (!IS_ATOM_INT(_stop_7466)) {
        _1 = (long)(DBL_PTR(_stop_7466)->dbl);
        DeRefDS(_stop_7466);
        _stop_7466 = _1;
    }

    /** 	return data[1 .. stop - 1]*/
    _4007 = _stop_7466 - 1;
    rhs_slice_target = (object_ptr)&_4008;
    RHS_Slice(_data_7465, 1, _4007);
    DeRefDS(_path_7464);
    DeRefDS(_data_7465);
    _4007 = NOVALUE;
    return _4008;
    ;
}
int pathname() __attribute__ ((alias ("_11pathname")));


int _11filename(int _path_7475)
{
    int _data_7476 = NOVALUE;
    int _4010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7475);
    _0 = _data_7476;
    _data_7476 = _11pathinfo(_path_7475, 0);
    DeRef(_0);

    /** 	return data[2]*/
    _2 = (int)SEQ_PTR(_data_7476);
    _4010 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_4010);
    DeRefDS(_path_7475);
    DeRefDS(_data_7476);
    return _4010;
    ;
}
int filename() __attribute__ ((alias ("_11filename")));


int _11filebase(int _path_7481)
{
    int _data_7482 = NOVALUE;
    int _4012 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7481);
    _0 = _data_7482;
    _data_7482 = _11pathinfo(_path_7481, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_7482);
    _4012 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_4012);
    DeRefDS(_path_7481);
    DeRefDS(_data_7482);
    return _4012;
    ;
}
int filebase() __attribute__ ((alias ("_11filebase")));


int _11fileext(int _path_7487)
{
    int _data_7488 = NOVALUE;
    int _4014 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7487);
    _0 = _data_7488;
    _data_7488 = _11pathinfo(_path_7487, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_7488);
    _4014 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_4014);
    DeRefDS(_path_7487);
    DeRefDS(_data_7488);
    return _4014;
    ;
}
int fileext() __attribute__ ((alias ("_11fileext")));


int _11driveid(int _path_7493)
{
    int _data_7494 = NOVALUE;
    int _4016 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_7493);
    _0 = _data_7494;
    _data_7494 = _11pathinfo(_path_7493, 0);
    DeRef(_0);

    /** 	return data[5]*/
    _2 = (int)SEQ_PTR(_data_7494);
    _4016 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_4016);
    DeRefDS(_path_7493);
    DeRefDS(_data_7494);
    return _4016;
    ;
}
int driveid() __attribute__ ((alias ("_11driveid")));


int _11defaultext(int _path_7499, int _defext_7500)
{
    int _4029 = NOVALUE;
    int _4026 = NOVALUE;
    int _4024 = NOVALUE;
    int _4023 = NOVALUE;
    int _4022 = NOVALUE;
    int _4020 = NOVALUE;
    int _4019 = NOVALUE;
    int _4017 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    if (IS_SEQUENCE(_defext_7500)){
            _4017 = SEQ_PTR(_defext_7500)->length;
    }
    else {
        _4017 = 1;
    }
    if (_4017 != 0)
    goto L1; // [10] 21

    /** 		return path*/
    DeRefDS(_defext_7500);
    return _path_7499;
L1: 

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_7499)){
            _4019 = SEQ_PTR(_path_7499)->length;
    }
    else {
        _4019 = 1;
    }
    {
        int _i_7505;
        _i_7505 = _4019;
L2: 
        if (_i_7505 < 1){
            goto L3; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_7499);
        _4020 = (int)*(((s1_ptr)_2)->base + _i_7505);
        if (binary_op_a(NOTEQ, _4020, 46)){
            _4020 = NOVALUE;
            goto L4; // [39] 50
        }
        _4020 = NOVALUE;

        /** 			return path*/
        DeRefDS(_defext_7500);
        return _path_7499;
L4: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_7499);
        _4022 = (int)*(((s1_ptr)_2)->base + _i_7505);
        _4023 = find_from(_4022, _11SLASHES_7008, 1);
        _4022 = NOVALUE;
        if (_4023 == 0)
        {
            _4023 = NOVALUE;
            goto L5; // [61] 88
        }
        else{
            _4023 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_7499)){
                _4024 = SEQ_PTR(_path_7499)->length;
        }
        else {
            _4024 = 1;
        }
        if (_i_7505 != _4024)
        goto L3; // [69] 95

        /** 				return path*/
        DeRefDS(_defext_7500);
        return _path_7499;
        goto L6; // [79] 87

        /** 				exit*/
        goto L3; // [84] 95
L6: 
L5: 

        /** 	end for*/
        _i_7505 = _i_7505 + -1;
        goto L2; // [90] 33
L3: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_7500);
    _4026 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4026, 46)){
        _4026 = NOVALUE;
        goto L7; // [101] 112
    }
    _4026 = NOVALUE;

    /** 		path &= '.'*/
    Append(&_path_7499, _path_7499, 46);
L7: 

    /** 	return path & defext*/
    Concat((object_ptr)&_4029, _path_7499, _defext_7500);
    DeRefDS(_path_7499);
    DeRefDS(_defext_7500);
    return _4029;
    ;
}
int defaultext() __attribute__ ((alias ("_11defaultext")));


int _11absolute_path(int _filename_7524)
{
    int _4033 = NOVALUE;
    int _4032 = NOVALUE;
    int _4030 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_7524)){
            _4030 = SEQ_PTR(_filename_7524)->length;
    }
    else {
        _4030 = 1;
    }
    if (_4030 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_7524);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_7524);
    _4032 = (int)*(((s1_ptr)_2)->base + 1);
    _4033 = find_from(_4032, _11SLASHES_7008, 1);
    _4032 = NOVALUE;
    if (_4033 == 0)
    {
        _4033 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _4033 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_7524);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	return 0*/
    DeRefDS(_filename_7524);
    return 0;
    ;
}
int absolute_path() __attribute__ ((alias ("_11absolute_path")));


int _11case_flagset_type(int _x_7537)
{
    int _4037 = NOVALUE;
    int _4036 = NOVALUE;
    int _4035 = NOVALUE;
    int _4034 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_7537)) {
        _1 = (long)(DBL_PTR(_x_7537)->dbl);
        DeRefDS(_x_7537);
        _x_7537 = _1;
    }

    /** 	return x >= AS_IS and x < 2*TO_SHORT*/
    _4034 = (_x_7537 >= 0);
    _4035 = 8;
    _4036 = (_x_7537 < 8);
    _4035 = NOVALUE;
    _4037 = (_4034 != 0 && _4036 != 0);
    _4034 = NOVALUE;
    _4036 = NOVALUE;
    return _4037;
    ;
}
int case_flagset_type() __attribute__ ((alias ("_11case_flagset_type")));


int _11canonical_path(int _path_in_7544, int _directory_given_7545, int _case_flags_7546)
{
    int _lPath_7547 = NOVALUE;
    int _lPosA_7548 = NOVALUE;
    int _lPosB_7549 = NOVALUE;
    int _lLevel_7550 = NOVALUE;
    int _lHome_7551 = NOVALUE;
    int _wildcard_suffix_7593 = NOVALUE;
    int _first_wildcard_at_7594 = NOVALUE;
    int _last_slash_7597 = NOVALUE;
    int _sl_7650 = NOVALUE;
    int _short_name_7653 = NOVALUE;
    int _correct_name_7656 = NOVALUE;
    int _lower_name_7659 = NOVALUE;
    int _part_7675 = NOVALUE;
    int _list_7679 = NOVALUE;
    int _supplied_name_7682 = NOVALUE;
    int _read_name_7701 = NOVALUE;
    int _read_name_7726 = NOVALUE;
    int _4213 = NOVALUE;
    int _4211 = NOVALUE;
    int _4210 = NOVALUE;
    int _4209 = NOVALUE;
    int _4208 = NOVALUE;
    int _4207 = NOVALUE;
    int _4205 = NOVALUE;
    int _4204 = NOVALUE;
    int _4203 = NOVALUE;
    int _4202 = NOVALUE;
    int _4201 = NOVALUE;
    int _4200 = NOVALUE;
    int _4199 = NOVALUE;
    int _4198 = NOVALUE;
    int _4196 = NOVALUE;
    int _4195 = NOVALUE;
    int _4194 = NOVALUE;
    int _4193 = NOVALUE;
    int _4192 = NOVALUE;
    int _4191 = NOVALUE;
    int _4190 = NOVALUE;
    int _4189 = NOVALUE;
    int _4188 = NOVALUE;
    int _4186 = NOVALUE;
    int _4185 = NOVALUE;
    int _4184 = NOVALUE;
    int _4183 = NOVALUE;
    int _4182 = NOVALUE;
    int _4181 = NOVALUE;
    int _4180 = NOVALUE;
    int _4179 = NOVALUE;
    int _4178 = NOVALUE;
    int _4177 = NOVALUE;
    int _4176 = NOVALUE;
    int _4175 = NOVALUE;
    int _4174 = NOVALUE;
    int _4173 = NOVALUE;
    int _4172 = NOVALUE;
    int _4170 = NOVALUE;
    int _4169 = NOVALUE;
    int _4168 = NOVALUE;
    int _4167 = NOVALUE;
    int _4166 = NOVALUE;
    int _4164 = NOVALUE;
    int _4163 = NOVALUE;
    int _4162 = NOVALUE;
    int _4161 = NOVALUE;
    int _4160 = NOVALUE;
    int _4159 = NOVALUE;
    int _4158 = NOVALUE;
    int _4157 = NOVALUE;
    int _4156 = NOVALUE;
    int _4155 = NOVALUE;
    int _4154 = NOVALUE;
    int _4153 = NOVALUE;
    int _4152 = NOVALUE;
    int _4150 = NOVALUE;
    int _4149 = NOVALUE;
    int _4147 = NOVALUE;
    int _4146 = NOVALUE;
    int _4145 = NOVALUE;
    int _4144 = NOVALUE;
    int _4143 = NOVALUE;
    int _4141 = NOVALUE;
    int _4140 = NOVALUE;
    int _4139 = NOVALUE;
    int _4138 = NOVALUE;
    int _4137 = NOVALUE;
    int _4135 = NOVALUE;
    int _4133 = NOVALUE;
    int _4132 = NOVALUE;
    int _4130 = NOVALUE;
    int _4129 = NOVALUE;
    int _4127 = NOVALUE;
    int _4126 = NOVALUE;
    int _4125 = NOVALUE;
    int _4123 = NOVALUE;
    int _4122 = NOVALUE;
    int _4120 = NOVALUE;
    int _4118 = NOVALUE;
    int _4116 = NOVALUE;
    int _4109 = NOVALUE;
    int _4106 = NOVALUE;
    int _4105 = NOVALUE;
    int _4104 = NOVALUE;
    int _4103 = NOVALUE;
    int _4097 = NOVALUE;
    int _4093 = NOVALUE;
    int _4092 = NOVALUE;
    int _4091 = NOVALUE;
    int _4090 = NOVALUE;
    int _4089 = NOVALUE;
    int _4087 = NOVALUE;
    int _4086 = NOVALUE;
    int _4085 = NOVALUE;
    int _4083 = NOVALUE;
    int _4082 = NOVALUE;
    int _4081 = NOVALUE;
    int _4080 = NOVALUE;
    int _4078 = NOVALUE;
    int _4076 = NOVALUE;
    int _4072 = NOVALUE;
    int _4071 = NOVALUE;
    int _4069 = NOVALUE;
    int _4068 = NOVALUE;
    int _4067 = NOVALUE;
    int _4066 = NOVALUE;
    int _4065 = NOVALUE;
    int _4064 = NOVALUE;
    int _4063 = NOVALUE;
    int _4060 = NOVALUE;
    int _4059 = NOVALUE;
    int _4054 = NOVALUE;
    int _4053 = NOVALUE;
    int _4052 = NOVALUE;
    int _4051 = NOVALUE;
    int _4050 = NOVALUE;
    int _4048 = NOVALUE;
    int _4047 = NOVALUE;
    int _4046 = NOVALUE;
    int _4045 = NOVALUE;
    int _4044 = NOVALUE;
    int _4043 = NOVALUE;
    int _4042 = NOVALUE;
    int _4041 = NOVALUE;
    int _4040 = NOVALUE;
    int _4039 = NOVALUE;
    int _4038 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_directory_given_7545)) {
        _1 = (long)(DBL_PTR(_directory_given_7545)->dbl);
        DeRefDS(_directory_given_7545);
        _directory_given_7545 = _1;
    }
    if (!IS_ATOM_INT(_case_flags_7546)) {
        _1 = (long)(DBL_PTR(_case_flags_7546)->dbl);
        DeRefDS(_case_flags_7546);
        _case_flags_7546 = _1;
    }

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_7547);
    _lPath_7547 = _5;

    /**     integer lPosA = -1*/
    _lPosA_7548 = -1;

    /**     integer lPosB = -1*/
    _lPosB_7549 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_7550);
    _lLevel_7550 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_7544);
    DeRefDS(_path_in_7544);
    _path_in_7544 = _path_in_7544;

    /** 	ifdef UNIX then*/

    /** 		lPath = path_in*/
    RefDS(_path_in_7544);
    DeRefDS(_lPath_7547);
    _lPath_7547 = _path_in_7544;

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4038 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4038 = 1;
    }
    _4039 = (_4038 > 2);
    _4038 = NOVALUE;
    if (_4039 == 0) {
        _4040 = 0;
        goto L1; // [56] 72
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4041 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4041)) {
        _4042 = (_4041 == 34);
    }
    else {
        _4042 = binary_op(EQUALS, _4041, 34);
    }
    _4041 = NOVALUE;
    if (IS_ATOM_INT(_4042))
    _4040 = (_4042 != 0);
    else
    _4040 = DBL_PTR(_4042)->dbl != 0.0;
L1: 
    if (_4040 == 0) {
        DeRef(_4043);
        _4043 = 0;
        goto L2; // [72] 91
    }
    if (IS_SEQUENCE(_lPath_7547)){
            _4044 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4044 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4045 = (int)*(((s1_ptr)_2)->base + _4044);
    if (IS_ATOM_INT(_4045)) {
        _4046 = (_4045 == 34);
    }
    else {
        _4046 = binary_op(EQUALS, _4045, 34);
    }
    _4045 = NOVALUE;
    if (IS_ATOM_INT(_4046))
    _4043 = (_4046 != 0);
    else
    _4043 = DBL_PTR(_4046)->dbl != 0.0;
L2: 
    if (_4043 == 0)
    {
        _4043 = NOVALUE;
        goto L3; // [91] 109
    }
    else{
        _4043 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4047 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4047 = 1;
    }
    _4048 = _4047 - 1;
    _4047 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_7547;
    RHS_Slice(_lPath_7547, 2, _4048);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4050 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4050 = 1;
    }
    _4051 = (_4050 > 0);
    _4050 = NOVALUE;
    if (_4051 == 0) {
        DeRef(_4052);
        _4052 = 0;
        goto L4; // [118] 134
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4053 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4053)) {
        _4054 = (_4053 == 126);
    }
    else {
        _4054 = binary_op(EQUALS, _4053, 126);
    }
    _4053 = NOVALUE;
    if (IS_ATOM_INT(_4054))
    _4052 = (_4054 != 0);
    else
    _4052 = DBL_PTR(_4054)->dbl != 0.0;
L4: 
    if (_4052 == 0)
    {
        _4052 = NOVALUE;
        goto L5; // [134] 222
    }
    else{
        _4052 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRefi(_lHome_7551);
    _lHome_7551 = EGetEnv(_4055);

    /** 		ifdef WINDOWS then*/

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_7551)){
            _4059 = SEQ_PTR(_lHome_7551)->length;
    }
    else {
        _4059 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_7551);
    _4060 = (int)*(((s1_ptr)_2)->base + _4059);
    if (_4060 == 47)
    goto L6; // [153] 164

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_7551) && IS_ATOM(47)) {
        Append(&_lHome_7551, _lHome_7551, 47);
    }
    else if (IS_ATOM(_lHome_7551) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_lHome_7551, _lHome_7551, 47);
    }
L6: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4063 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4063 = 1;
    }
    _4064 = (_4063 > 1);
    _4063 = NOVALUE;
    if (_4064 == 0) {
        goto L7; // [173] 206
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4066 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4066)) {
        _4067 = (_4066 == 47);
    }
    else {
        _4067 = binary_op(EQUALS, _4066, 47);
    }
    _4066 = NOVALUE;
    if (_4067 == 0) {
        DeRef(_4067);
        _4067 = NOVALUE;
        goto L7; // [186] 206
    }
    else {
        if (!IS_ATOM_INT(_4067) && DBL_PTR(_4067)->dbl == 0.0){
            DeRef(_4067);
            _4067 = NOVALUE;
            goto L7; // [186] 206
        }
        DeRef(_4067);
        _4067 = NOVALUE;
    }
    DeRef(_4067);
    _4067 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4068 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4068 = 1;
    }
    rhs_slice_target = (object_ptr)&_4069;
    RHS_Slice(_lPath_7547, 3, _4068);
    if (IS_SEQUENCE(_lHome_7551) && IS_ATOM(_4069)) {
    }
    else if (IS_ATOM(_lHome_7551) && IS_SEQUENCE(_4069)) {
        Ref(_lHome_7551);
        Prepend(&_lPath_7547, _4069, _lHome_7551);
    }
    else {
        Concat((object_ptr)&_lPath_7547, _lHome_7551, _4069);
    }
    DeRefDS(_4069);
    _4069 = NOVALUE;
    goto L8; // [203] 221
L7: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4071 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4071 = 1;
    }
    rhs_slice_target = (object_ptr)&_4072;
    RHS_Slice(_lPath_7547, 2, _4071);
    if (IS_SEQUENCE(_lHome_7551) && IS_ATOM(_4072)) {
    }
    else if (IS_ATOM(_lHome_7551) && IS_SEQUENCE(_4072)) {
        Ref(_lHome_7551);
        Prepend(&_lPath_7547, _4072, _lHome_7551);
    }
    else {
        Concat((object_ptr)&_lPath_7547, _lHome_7551, _4072);
    }
    DeRefDS(_4072);
    _4072 = NOVALUE;
L8: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_7547);
    _first_wildcard_at_7594 = _11find_first_wildcard(_lPath_7547, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_7594)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_7594)->dbl);
        DeRefDS(_first_wildcard_at_7594);
        _first_wildcard_at_7594 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_7594 == 0)
    {
        goto L9; // [237] 298
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_7547);
    _last_slash_7597 = _9rfind(47, _lPath_7547, _first_wildcard_at_7594);
    if (!IS_ATOM_INT(_last_slash_7597)) {
        _1 = (long)(DBL_PTR(_last_slash_7597)->dbl);
        DeRefDS(_last_slash_7597);
        _last_slash_7597 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_7597 == 0)
    {
        goto LA; // [252] 278
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4076 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4076 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_7593;
    RHS_Slice(_lPath_7547, _last_slash_7597, _4076);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4078 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4078 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7547);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_7597)) ? _last_slash_7597 : (long)(DBL_PTR(_last_slash_7597)->dbl);
        int stop = (IS_ATOM_INT(_4078)) ? _4078 : (long)(DBL_PTR(_4078)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7547), start, &_lPath_7547 );
            }
            else Tail(SEQ_PTR(_lPath_7547), stop+1, &_lPath_7547);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7547), start, &_lPath_7547);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7547 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7547)->ref == 1));
        }
    }
    _4078 = NOVALUE;
    goto LB; // [275] 293
LA: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_7547);
    DeRef(_wildcard_suffix_7593);
    _wildcard_suffix_7593 = _lPath_7547;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_7547);
    _lPath_7547 = _5;
LB: 
    goto LC; // [295] 306
L9: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_7593);
    _wildcard_suffix_7593 = _5;
LC: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4080 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4080 = 1;
    }
    _4081 = (_4080 == 0);
    _4080 = NOVALUE;
    if (_4081 != 0) {
        DeRef(_4082);
        _4082 = 1;
        goto LD; // [315] 335
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4083 = (int)*(((s1_ptr)_2)->base + 1);
    _4085 = find_from(_4083, _4084, 1);
    _4083 = NOVALUE;
    _4086 = (_4085 == 0);
    _4085 = NOVALUE;
    _4082 = (_4086 != 0);
LD: 
    if (_4082 == 0)
    {
        _4082 = NOVALUE;
        goto LE; // [335] 351
    }
    else{
        _4082 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			lPath = curdir() & lPath*/
    _4087 = _11curdir(0);
    if (IS_SEQUENCE(_4087) && IS_ATOM(_lPath_7547)) {
    }
    else if (IS_ATOM(_4087) && IS_SEQUENCE(_lPath_7547)) {
        Ref(_4087);
        Prepend(&_lPath_7547, _lPath_7547, _4087);
    }
    else {
        Concat((object_ptr)&_lPath_7547, _4087, _lPath_7547);
        DeRef(_4087);
        _4087 = NOVALUE;
    }
    DeRef(_4087);
    _4087 = NOVALUE;
LE: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _4089 = (_directory_given_7545 != 0);
    if (_4089 == 0) {
        DeRef(_4090);
        _4090 = 0;
        goto LF; // [357] 376
    }
    if (IS_SEQUENCE(_lPath_7547)){
            _4091 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4091 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4092 = (int)*(((s1_ptr)_2)->base + _4091);
    if (IS_ATOM_INT(_4092)) {
        _4093 = (_4092 != 47);
    }
    else {
        _4093 = binary_op(NOTEQ, _4092, 47);
    }
    _4092 = NOVALUE;
    if (IS_ATOM_INT(_4093))
    _4090 = (_4093 != 0);
    else
    _4090 = DBL_PTR(_4093)->dbl != 0.0;
LF: 
    if (_4090 == 0)
    {
        _4090 = NOVALUE;
        goto L10; // [376] 386
    }
    else{
        _4090 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_7547, _lPath_7547, 47);
L10: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = 46;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_7550, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_7548 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L11; // [401] 422
L12: 
    if (_lPosA_7548 == 0)
    goto L13; // [404] 434

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _4097 = _lPosA_7548 + 1;
    if (_4097 > MAXINT){
        _4097 = NewDouble((double)_4097);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7547);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_7548)) ? _lPosA_7548 : (long)(DBL_PTR(_lPosA_7548)->dbl);
        int stop = (IS_ATOM_INT(_4097)) ? _4097 : (long)(DBL_PTR(_4097)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7547), start, &_lPath_7547 );
            }
            else Tail(SEQ_PTR(_lPath_7547), stop+1, &_lPath_7547);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7547), start, &_lPath_7547);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7547 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7547)->ref == 1));
        }
    }
    DeRef(_4097);
    _4097 = NOVALUE;

    /** 	  entry*/
L11: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_7548 = e_match_from(_lLevel_7550, _lPath_7547, _lPosA_7548);

    /** 	end while*/
    goto L12; // [431] 404
L13: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = _3847;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_7550, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_7549 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L14; // [449] 527
L15: 
    if (_lPosA_7548 == 0)
    goto L16; // [452] 539

    /** 		lPosB = lPosA-1*/
    _lPosB_7549 = _lPosA_7548 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L17: 
    _4103 = (_lPosB_7549 > 0);
    if (_4103 == 0) {
        DeRef(_4104);
        _4104 = 0;
        goto L18; // [471] 487
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4105 = (int)*(((s1_ptr)_2)->base + _lPosB_7549);
    if (IS_ATOM_INT(_4105)) {
        _4106 = (_4105 != 47);
    }
    else {
        _4106 = binary_op(NOTEQ, _4105, 47);
    }
    _4105 = NOVALUE;
    if (IS_ATOM_INT(_4106))
    _4104 = (_4106 != 0);
    else
    _4104 = DBL_PTR(_4106)->dbl != 0.0;
L18: 
    if (_4104 == 0)
    {
        _4104 = NOVALUE;
        goto L19; // [487] 501
    }
    else{
        _4104 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_7549 = _lPosB_7549 - 1;

    /** 		end while*/
    goto L17; // [498] 467
L19: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_7549 > 0)
    goto L1A; // [503] 513

    /** 			lPosB = 1*/
    _lPosB_7549 = 1;
L1A: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _4109 = _lPosA_7548 + 2;
    if ((long)((unsigned long)_4109 + (unsigned long)HIGH_BITS) >= 0) 
    _4109 = NewDouble((double)_4109);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_7547);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_7549)) ? _lPosB_7549 : (long)(DBL_PTR(_lPosB_7549)->dbl);
        int stop = (IS_ATOM_INT(_4109)) ? _4109 : (long)(DBL_PTR(_4109)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_7547), start, &_lPath_7547 );
            }
            else Tail(SEQ_PTR(_lPath_7547), stop+1, &_lPath_7547);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_7547), start, &_lPath_7547);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_7547 = Remove_elements(start, stop, (SEQ_PTR(_lPath_7547)->ref == 1));
        }
    }
    DeRef(_4109);
    _4109 = NOVALUE;

    /** 	  entry*/
L14: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_7548 = e_match_from(_lLevel_7550, _lPath_7547, _lPosB_7549);

    /** 	end while*/
    goto L15; // [536] 452
L16: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_7546 != 1)
    goto L1B; // [541] 556

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_7547);
    _0 = _lPath_7547;
    _lPath_7547 = _6lower(_lPath_7547);
    DeRefDS(_0);
    goto L1C; // [553] 1149
L1B: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_7546 == 0)
    goto L1D; // [558] 1146

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_7547);
    _0 = _sl_7650;
    _sl_7650 = _9find_all(47, _lPath_7547, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_7546;
         _4116 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4116)) {
        _short_name_7653 = (_4116 == 4);
    }
    else {
        _short_name_7653 = (DBL_PTR(_4116)->dbl == (double)4);
    }
    DeRef(_4116);
    _4116 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_7546 & (unsigned long)2;
         _4118 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4118)) {
        _correct_name_7656 = (_4118 == 2);
    }
    else {
        _correct_name_7656 = (DBL_PTR(_4118)->dbl == (double)2);
    }
    DeRef(_4118);
    _4118 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_7546;
         _4120 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4120)) {
        _lower_name_7659 = (_4120 == 1);
    }
    else {
        _lower_name_7659 = (DBL_PTR(_4120)->dbl == (double)1);
    }
    DeRef(_4120);
    _4120 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4122 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4122 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_7547);
    _4123 = (int)*(((s1_ptr)_2)->base + _4122);
    if (binary_op_a(EQUALS, _4123, 47)){
        _4123 = NOVALUE;
        goto L1E; // [611] 633
    }
    _4123 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_7547)){
            _4125 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4125 = 1;
    }
    _4126 = _4125 + 1;
    _4125 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4126;
    _4127 = MAKE_SEQ(_1);
    _4126 = NOVALUE;
    Concat((object_ptr)&_sl_7650, _sl_7650, _4127);
    DeRefDS(_4127);
    _4127 = NOVALUE;
L1E: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_7650)){
            _4129 = SEQ_PTR(_sl_7650)->length;
    }
    else {
        _4129 = 1;
    }
    _4130 = _4129 - 1;
    _4129 = NOVALUE;
    {
        int _i_7671;
        _i_7671 = _4130;
L1F: 
        if (_i_7671 < 1){
            goto L20; // [642] 1111
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_7650);
        _4132 = (int)*(((s1_ptr)_2)->base + _i_7671);
        if (IS_ATOM_INT(_4132)) {
            _4133 = _4132 - 1;
        }
        else {
            _4133 = binary_op(MINUS, _4132, 1);
        }
        _4132 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_7675;
        RHS_Slice(_lPath_7547, 1, _4133);

        /** 			object list = dir( part & SLASH )*/
        Append(&_4135, _part_7675, 47);
        _0 = _list_7679;
        _list_7679 = _11dir(_4135);
        DeRef(_0);
        _4135 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_7650);
        _4137 = (int)*(((s1_ptr)_2)->base + _i_7671);
        if (IS_ATOM_INT(_4137)) {
            _4138 = _4137 + 1;
            if (_4138 > MAXINT){
                _4138 = NewDouble((double)_4138);
            }
        }
        else
        _4138 = binary_op(PLUS, 1, _4137);
        _4137 = NOVALUE;
        _4139 = _i_7671 + 1;
        _2 = (int)SEQ_PTR(_sl_7650);
        _4140 = (int)*(((s1_ptr)_2)->base + _4139);
        if (IS_ATOM_INT(_4140)) {
            _4141 = _4140 - 1;
        }
        else {
            _4141 = binary_op(MINUS, _4140, 1);
        }
        _4140 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_7682;
        RHS_Slice(_lPath_7547, _4138, _4141);

        /** 			if atom(list) then*/
        _4143 = IS_ATOM(_list_7679);
        if (_4143 == 0)
        {
            _4143 = NOVALUE;
            goto L21; // [706] 744
        }
        else{
            _4143 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_7659 == 0)
        {
            goto L22; // [711] 737
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7650);
        _4144 = (int)*(((s1_ptr)_2)->base + _i_7671);
        if (IS_SEQUENCE(_lPath_7547)){
                _4145 = SEQ_PTR(_lPath_7547)->length;
        }
        else {
            _4145 = 1;
        }
        rhs_slice_target = (object_ptr)&_4146;
        RHS_Slice(_lPath_7547, _4144, _4145);
        _4147 = _6lower(_4146);
        _4146 = NOVALUE;
        if (IS_SEQUENCE(_part_7675) && IS_ATOM(_4147)) {
            Ref(_4147);
            Append(&_lPath_7547, _part_7675, _4147);
        }
        else if (IS_ATOM(_part_7675) && IS_SEQUENCE(_4147)) {
        }
        else {
            Concat((object_ptr)&_lPath_7547, _part_7675, _4147);
        }
        DeRef(_4147);
        _4147 = NOVALUE;
L22: 

        /** 				continue*/
        DeRef(_part_7675);
        _part_7675 = NOVALUE;
        DeRef(_list_7679);
        _list_7679 = NOVALUE;
        DeRef(_supplied_name_7682);
        _supplied_name_7682 = NOVALUE;
        goto L23; // [741] 1106
L21: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7679)){
                _4149 = SEQ_PTR(_list_7679)->length;
        }
        else {
            _4149 = 1;
        }
        {
            int _j_7699;
            _j_7699 = 1;
L24: 
            if (_j_7699 > _4149){
                goto L25; // [749] 874
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7679);
            _4150 = (int)*(((s1_ptr)_2)->base + _j_7699);
            DeRef(_read_name_7701);
            _2 = (int)SEQ_PTR(_4150);
            _read_name_7701 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7701);
            _4150 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_7701 == _supplied_name_7682)
            _4152 = 1;
            else if (IS_ATOM_INT(_read_name_7701) && IS_ATOM_INT(_supplied_name_7682))
            _4152 = 0;
            else
            _4152 = (compare(_read_name_7701, _supplied_name_7682) == 0);
            if (_4152 == 0)
            {
                _4152 = NOVALUE;
                goto L26; // [774] 865
            }
            else{
                _4152 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7653 == 0) {
                goto L27; // [779] 856
            }
            _2 = (int)SEQ_PTR(_list_7679);
            _4154 = (int)*(((s1_ptr)_2)->base + _j_7699);
            _2 = (int)SEQ_PTR(_4154);
            _4155 = (int)*(((s1_ptr)_2)->base + 11);
            _4154 = NOVALUE;
            _4156 = IS_SEQUENCE(_4155);
            _4155 = NOVALUE;
            if (_4156 == 0)
            {
                _4156 = NOVALUE;
                goto L27; // [795] 856
            }
            else{
                _4156 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7650);
            _4157 = (int)*(((s1_ptr)_2)->base + _i_7671);
            rhs_slice_target = (object_ptr)&_4158;
            RHS_Slice(_lPath_7547, 1, _4157);
            _2 = (int)SEQ_PTR(_list_7679);
            _4159 = (int)*(((s1_ptr)_2)->base + _j_7699);
            _2 = (int)SEQ_PTR(_4159);
            _4160 = (int)*(((s1_ptr)_2)->base + 11);
            _4159 = NOVALUE;
            _4161 = _i_7671 + 1;
            _2 = (int)SEQ_PTR(_sl_7650);
            _4162 = (int)*(((s1_ptr)_2)->base + _4161);
            if (IS_SEQUENCE(_lPath_7547)){
                    _4163 = SEQ_PTR(_lPath_7547)->length;
            }
            else {
                _4163 = 1;
            }
            rhs_slice_target = (object_ptr)&_4164;
            RHS_Slice(_lPath_7547, _4162, _4163);
            {
                int concat_list[3];

                concat_list[0] = _4164;
                concat_list[1] = _4160;
                concat_list[2] = _4158;
                Concat_N((object_ptr)&_lPath_7547, concat_list, 3);
            }
            DeRefDS(_4164);
            _4164 = NOVALUE;
            _4160 = NOVALUE;
            DeRefDS(_4158);
            _4158 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7650)){
                    _4166 = SEQ_PTR(_sl_7650)->length;
            }
            else {
                _4166 = 1;
            }
            if (IS_SEQUENCE(_lPath_7547)){
                    _4167 = SEQ_PTR(_lPath_7547)->length;
            }
            else {
                _4167 = 1;
            }
            _4168 = _4167 + 1;
            _4167 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7650);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7650 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4166);
            _1 = *(int *)_2;
            *(int *)_2 = _4168;
            if( _1 != _4168 ){
                DeRef(_1);
            }
            _4168 = NOVALUE;
L27: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7701);
            _read_name_7701 = NOVALUE;
            DeRef(_part_7675);
            _part_7675 = NOVALUE;
            DeRef(_list_7679);
            _list_7679 = NOVALUE;
            DeRef(_supplied_name_7682);
            _supplied_name_7682 = NOVALUE;
            goto L23; // [862] 1106
L26: 
            DeRef(_read_name_7701);
            _read_name_7701 = NOVALUE;

            /** 			end for*/
            _j_7699 = _j_7699 + 1;
            goto L24; // [869] 756
L25: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_7679)){
                _4169 = SEQ_PTR(_list_7679)->length;
        }
        else {
            _4169 = 1;
        }
        {
            int _j_7724;
            _j_7724 = 1;
L28: 
            if (_j_7724 > _4169){
                goto L29; // [879] 1051
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_7679);
            _4170 = (int)*(((s1_ptr)_2)->base + _j_7724);
            DeRef(_read_name_7726);
            _2 = (int)SEQ_PTR(_4170);
            _read_name_7726 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_7726);
            _4170 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_7726);
            _4172 = _6lower(_read_name_7726);
            RefDS(_supplied_name_7682);
            _4173 = _6lower(_supplied_name_7682);
            if (_4172 == _4173)
            _4174 = 1;
            else if (IS_ATOM_INT(_4172) && IS_ATOM_INT(_4173))
            _4174 = 0;
            else
            _4174 = (compare(_4172, _4173) == 0);
            DeRef(_4172);
            _4172 = NOVALUE;
            DeRef(_4173);
            _4173 = NOVALUE;
            if (_4174 == 0)
            {
                _4174 = NOVALUE;
                goto L2A; // [912] 1042
            }
            else{
                _4174 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_7653 == 0) {
                goto L2B; // [917] 994
            }
            _2 = (int)SEQ_PTR(_list_7679);
            _4176 = (int)*(((s1_ptr)_2)->base + _j_7724);
            _2 = (int)SEQ_PTR(_4176);
            _4177 = (int)*(((s1_ptr)_2)->base + 11);
            _4176 = NOVALUE;
            _4178 = IS_SEQUENCE(_4177);
            _4177 = NOVALUE;
            if (_4178 == 0)
            {
                _4178 = NOVALUE;
                goto L2B; // [933] 994
            }
            else{
                _4178 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7650);
            _4179 = (int)*(((s1_ptr)_2)->base + _i_7671);
            rhs_slice_target = (object_ptr)&_4180;
            RHS_Slice(_lPath_7547, 1, _4179);
            _2 = (int)SEQ_PTR(_list_7679);
            _4181 = (int)*(((s1_ptr)_2)->base + _j_7724);
            _2 = (int)SEQ_PTR(_4181);
            _4182 = (int)*(((s1_ptr)_2)->base + 11);
            _4181 = NOVALUE;
            _4183 = _i_7671 + 1;
            _2 = (int)SEQ_PTR(_sl_7650);
            _4184 = (int)*(((s1_ptr)_2)->base + _4183);
            if (IS_SEQUENCE(_lPath_7547)){
                    _4185 = SEQ_PTR(_lPath_7547)->length;
            }
            else {
                _4185 = 1;
            }
            rhs_slice_target = (object_ptr)&_4186;
            RHS_Slice(_lPath_7547, _4184, _4185);
            {
                int concat_list[3];

                concat_list[0] = _4186;
                concat_list[1] = _4182;
                concat_list[2] = _4180;
                Concat_N((object_ptr)&_lPath_7547, concat_list, 3);
            }
            DeRefDS(_4186);
            _4186 = NOVALUE;
            _4182 = NOVALUE;
            DeRefDS(_4180);
            _4180 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_7650)){
                    _4188 = SEQ_PTR(_sl_7650)->length;
            }
            else {
                _4188 = 1;
            }
            if (IS_SEQUENCE(_lPath_7547)){
                    _4189 = SEQ_PTR(_lPath_7547)->length;
            }
            else {
                _4189 = 1;
            }
            _4190 = _4189 + 1;
            _4189 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_7650);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_7650 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _4188);
            _1 = *(int *)_2;
            *(int *)_2 = _4190;
            if( _1 != _4190 ){
                DeRef(_1);
            }
            _4190 = NOVALUE;
L2B: 

            /** 					if correct_name then*/
            if (_correct_name_7656 == 0)
            {
                goto L2C; // [996] 1033
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_7650);
            _4191 = (int)*(((s1_ptr)_2)->base + _i_7671);
            rhs_slice_target = (object_ptr)&_4192;
            RHS_Slice(_lPath_7547, 1, _4191);
            _4193 = _i_7671 + 1;
            _2 = (int)SEQ_PTR(_sl_7650);
            _4194 = (int)*(((s1_ptr)_2)->base + _4193);
            if (IS_SEQUENCE(_lPath_7547)){
                    _4195 = SEQ_PTR(_lPath_7547)->length;
            }
            else {
                _4195 = 1;
            }
            rhs_slice_target = (object_ptr)&_4196;
            RHS_Slice(_lPath_7547, _4194, _4195);
            {
                int concat_list[3];

                concat_list[0] = _4196;
                concat_list[1] = _read_name_7726;
                concat_list[2] = _4192;
                Concat_N((object_ptr)&_lPath_7547, concat_list, 3);
            }
            DeRefDS(_4196);
            _4196 = NOVALUE;
            DeRefDS(_4192);
            _4192 = NOVALUE;
L2C: 

            /** 					continue "partloop"*/
            DeRef(_read_name_7726);
            _read_name_7726 = NOVALUE;
            DeRef(_part_7675);
            _part_7675 = NOVALUE;
            DeRef(_list_7679);
            _list_7679 = NOVALUE;
            DeRef(_supplied_name_7682);
            _supplied_name_7682 = NOVALUE;
            goto L23; // [1039] 1106
L2A: 
            DeRef(_read_name_7726);
            _read_name_7726 = NOVALUE;

            /** 			end for*/
            _j_7724 = _j_7724 + 1;
            goto L28; // [1046] 886
L29: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_7546;
             _4198 = MAKE_UINT(tu);
        }
        if (_4198 == 0) {
            DeRef(_4198);
            _4198 = NOVALUE;
            goto L2D; // [1057] 1096
        }
        else {
            if (!IS_ATOM_INT(_4198) && DBL_PTR(_4198)->dbl == 0.0){
                DeRef(_4198);
                _4198 = NOVALUE;
                goto L2D; // [1057] 1096
            }
            DeRef(_4198);
            _4198 = NOVALUE;
        }
        DeRef(_4198);
        _4198 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_7650);
        _4199 = (int)*(((s1_ptr)_2)->base + _i_7671);
        if (IS_ATOM_INT(_4199)) {
            _4200 = _4199 - 1;
        }
        else {
            _4200 = binary_op(MINUS, _4199, 1);
        }
        _4199 = NOVALUE;
        rhs_slice_target = (object_ptr)&_4201;
        RHS_Slice(_lPath_7547, 1, _4200);
        _2 = (int)SEQ_PTR(_sl_7650);
        _4202 = (int)*(((s1_ptr)_2)->base + _i_7671);
        if (IS_SEQUENCE(_lPath_7547)){
                _4203 = SEQ_PTR(_lPath_7547)->length;
        }
        else {
            _4203 = 1;
        }
        rhs_slice_target = (object_ptr)&_4204;
        RHS_Slice(_lPath_7547, _4202, _4203);
        _4205 = _6lower(_4204);
        _4204 = NOVALUE;
        if (IS_SEQUENCE(_4201) && IS_ATOM(_4205)) {
            Ref(_4205);
            Append(&_lPath_7547, _4201, _4205);
        }
        else if (IS_ATOM(_4201) && IS_SEQUENCE(_4205)) {
        }
        else {
            Concat((object_ptr)&_lPath_7547, _4201, _4205);
            DeRefDS(_4201);
            _4201 = NOVALUE;
        }
        DeRef(_4201);
        _4201 = NOVALUE;
        DeRef(_4205);
        _4205 = NOVALUE;
L2D: 

        /** 			exit*/
        DeRef(_part_7675);
        _part_7675 = NOVALUE;
        DeRef(_list_7679);
        _list_7679 = NOVALUE;
        DeRef(_supplied_name_7682);
        _supplied_name_7682 = NOVALUE;
        goto L20; // [1100] 1111

        /** 		end for*/
L23: 
        _i_7671 = _i_7671 + -1;
        goto L1F; // [1106] 649
L20: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _4207 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_4207)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_7546 & (unsigned long)_4207;
             _4208 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_7546;
        _4208 = Dand_bits(&temp_d, DBL_PTR(_4207));
    }
    DeRef(_4207);
    _4207 = NOVALUE;
    if (IS_ATOM_INT(_4208)) {
        _4209 = (_4208 == 1);
    }
    else {
        _4209 = (DBL_PTR(_4208)->dbl == (double)1);
    }
    DeRef(_4208);
    _4208 = NOVALUE;
    if (_4209 == 0) {
        goto L2E; // [1125] 1145
    }
    if (IS_SEQUENCE(_lPath_7547)){
            _4211 = SEQ_PTR(_lPath_7547)->length;
    }
    else {
        _4211 = 1;
    }
    if (_4211 == 0)
    {
        _4211 = NOVALUE;
        goto L2E; // [1133] 1145
    }
    else{
        _4211 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_7547);
    _0 = _lPath_7547;
    _lPath_7547 = _6lower(_lPath_7547);
    DeRefDS(_0);
L2E: 
L1D: 
    DeRef(_sl_7650);
    _sl_7650 = NOVALUE;
L1C: 

    /** 	ifdef WINDOWS then*/

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_4213, _lPath_7547, _wildcard_suffix_7593);
    DeRefDS(_path_in_7544);
    DeRefDS(_lPath_7547);
    DeRefi(_lLevel_7550);
    DeRefi(_lHome_7551);
    DeRefDS(_wildcard_suffix_7593);
    DeRef(_4051);
    _4051 = NOVALUE;
    DeRef(_4064);
    _4064 = NOVALUE;
    DeRef(_4193);
    _4193 = NOVALUE;
    DeRef(_4054);
    _4054 = NOVALUE;
    DeRef(_4130);
    _4130 = NOVALUE;
    _4179 = NOVALUE;
    DeRef(_4183);
    _4183 = NOVALUE;
    _4184 = NOVALUE;
    DeRef(_4081);
    _4081 = NOVALUE;
    DeRef(_4093);
    _4093 = NOVALUE;
    DeRef(_4133);
    _4133 = NOVALUE;
    DeRef(_4106);
    _4106 = NOVALUE;
    _4162 = NOVALUE;
    DeRef(_4048);
    _4048 = NOVALUE;
    _4060 = NOVALUE;
    DeRef(_4042);
    _4042 = NOVALUE;
    _4157 = NOVALUE;
    DeRef(_4161);
    _4161 = NOVALUE;
    DeRef(_4039);
    _4039 = NOVALUE;
    DeRef(_4139);
    _4139 = NOVALUE;
    _4202 = NOVALUE;
    DeRef(_4046);
    _4046 = NOVALUE;
    DeRef(_4086);
    _4086 = NOVALUE;
    DeRef(_4089);
    _4089 = NOVALUE;
    _4144 = NOVALUE;
    _4191 = NOVALUE;
    _4194 = NOVALUE;
    DeRef(_4141);
    _4141 = NOVALUE;
    DeRef(_4103);
    _4103 = NOVALUE;
    DeRef(_4200);
    _4200 = NOVALUE;
    DeRef(_4209);
    _4209 = NOVALUE;
    DeRef(_4138);
    _4138 = NOVALUE;
    return _4213;
    ;
}
int canonical_path() __attribute__ ((alias ("_11canonical_path")));


int _11abbreviate_path(int _orig_path_7785, int _base_paths_7786)
{
    int _expanded_path_7787 = NOVALUE;
    int _fs_case_inlined_fs_case_at_61_7797 = NOVALUE;
    int _lowered_expanded_path_7798 = NOVALUE;
    int _fs_case_inlined_fs_case_at_73_7800 = NOVALUE;
    int _fs_case_inlined_fs_case_at_216_7827 = NOVALUE;
    int _s_inlined_fs_case_at_213_7826 = NOVALUE;
    int _4249 = NOVALUE;
    int _4248 = NOVALUE;
    int _4245 = NOVALUE;
    int _4244 = NOVALUE;
    int _4243 = NOVALUE;
    int _4242 = NOVALUE;
    int _4241 = NOVALUE;
    int _4239 = NOVALUE;
    int _4238 = NOVALUE;
    int _4237 = NOVALUE;
    int _4236 = NOVALUE;
    int _4235 = NOVALUE;
    int _4234 = NOVALUE;
    int _4233 = NOVALUE;
    int _4232 = NOVALUE;
    int _4229 = NOVALUE;
    int _4228 = NOVALUE;
    int _4227 = NOVALUE;
    int _4226 = NOVALUE;
    int _4225 = NOVALUE;
    int _4224 = NOVALUE;
    int _4223 = NOVALUE;
    int _4222 = NOVALUE;
    int _4221 = NOVALUE;
    int _4220 = NOVALUE;
    int _4219 = NOVALUE;
    int _4218 = NOVALUE;
    int _4217 = NOVALUE;
    int _4215 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_7785);
    _0 = _expanded_path_7787;
    _expanded_path_7787 = _11canonical_path(_orig_path_7785, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _4215 = _11curdir(0);
    Ref(_4215);
    Append(&_base_paths_7786, _base_paths_7786, _4215);
    DeRef(_4215);
    _4215 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_7786)){
            _4217 = SEQ_PTR(_base_paths_7786)->length;
    }
    else {
        _4217 = 1;
    }
    {
        int _i_7792;
        _i_7792 = 1;
L1: 
        if (_i_7792 > _4217){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_7786);
        _4218 = (int)*(((s1_ptr)_2)->base + _i_7792);
        Ref(_4218);
        _4219 = _11canonical_path(_4218, 1, 0);
        _4218 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_7786);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_7786 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_7792);
        _1 = *(int *)_2;
        *(int *)_2 = _4219;
        if( _1 != _4219 ){
            DeRef(_1);
        }
        _4219 = NOVALUE;

        /** 	end for*/
        _i_7792 = _i_7792 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_base_paths_7786);
    DeRefDS(_base_paths_7786);
    _base_paths_7786 = _base_paths_7786;

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_expanded_path_7787);
    DeRef(_lowered_expanded_path_7798);
    _lowered_expanded_path_7798 = _expanded_path_7787;

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_7786)){
            _4220 = SEQ_PTR(_base_paths_7786)->length;
    }
    else {
        _4220 = 1;
    }
    {
        int _i_7802;
        _i_7802 = 1;
L3: 
        if (_i_7802 > _4220){
            goto L4; // [89] 143
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_7786);
        _4221 = (int)*(((s1_ptr)_2)->base + _i_7802);
        Ref(_4221);
        RefDS(_lowered_expanded_path_7798);
        _4222 = _9begins(_4221, _lowered_expanded_path_7798);
        _4221 = NOVALUE;
        if (_4222 == 0) {
            DeRef(_4222);
            _4222 = NOVALUE;
            goto L5; // [107] 136
        }
        else {
            if (!IS_ATOM_INT(_4222) && DBL_PTR(_4222)->dbl == 0.0){
                DeRef(_4222);
                _4222 = NOVALUE;
                goto L5; // [107] 136
            }
            DeRef(_4222);
            _4222 = NOVALUE;
        }
        DeRef(_4222);
        _4222 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_7786);
        _4223 = (int)*(((s1_ptr)_2)->base + _i_7802);
        if (IS_SEQUENCE(_4223)){
                _4224 = SEQ_PTR(_4223)->length;
        }
        else {
            _4224 = 1;
        }
        _4223 = NOVALUE;
        _4225 = _4224 + 1;
        _4224 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_7787)){
                _4226 = SEQ_PTR(_expanded_path_7787)->length;
        }
        else {
            _4226 = 1;
        }
        rhs_slice_target = (object_ptr)&_4227;
        RHS_Slice(_expanded_path_7787, _4225, _4226);
        DeRefDS(_orig_path_7785);
        DeRefDS(_base_paths_7786);
        DeRefDS(_expanded_path_7787);
        DeRefDS(_lowered_expanded_path_7798);
        _4223 = NOVALUE;
        _4225 = NOVALUE;
        return _4227;
L5: 

        /** 	end for*/
        _i_7802 = _i_7802 + 1;
        goto L3; // [138] 96
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_7786)){
            _4228 = SEQ_PTR(_base_paths_7786)->length;
    }
    else {
        _4228 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_7786);
    _4229 = (int)*(((s1_ptr)_2)->base + _4228);
    Ref(_4229);
    _0 = _base_paths_7786;
    _base_paths_7786 = _23split(_4229, 47, 0, 0);
    DeRefDS(_0);
    _4229 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_7787);
    _0 = _expanded_path_7787;
    _expanded_path_7787 = _23split(_expanded_path_7787, 47, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_7798);
    _lowered_expanded_path_7798 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_7787)){
            _4232 = SEQ_PTR(_expanded_path_7787)->length;
    }
    else {
        _4232 = 1;
    }
    if (IS_SEQUENCE(_base_paths_7786)){
            _4233 = SEQ_PTR(_base_paths_7786)->length;
    }
    else {
        _4233 = 1;
    }
    _4234 = _4233 - 1;
    _4233 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4232;
    ((int *)_2)[2] = _4234;
    _4235 = MAKE_SEQ(_1);
    _4234 = NOVALUE;
    _4232 = NOVALUE;
    _4236 = _20min(_4235);
    _4235 = NOVALUE;
    {
        int _i_7817;
        _i_7817 = 1;
L6: 
        if (binary_op_a(GREATER, _i_7817, _4236)){
            goto L7; // [201] 305
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_7787);
        if (!IS_ATOM_INT(_i_7817)){
            _4237 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_7817)->dbl));
        }
        else{
            _4237 = (int)*(((s1_ptr)_2)->base + _i_7817);
        }
        Ref(_4237);
        DeRef(_s_inlined_fs_case_at_213_7826);
        _s_inlined_fs_case_at_213_7826 = _4237;
        _4237 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return s*/
        Ref(_s_inlined_fs_case_at_213_7826);
        DeRef(_fs_case_inlined_fs_case_at_216_7827);
        _fs_case_inlined_fs_case_at_216_7827 = _s_inlined_fs_case_at_213_7826;
        DeRef(_s_inlined_fs_case_at_213_7826);
        _s_inlined_fs_case_at_213_7826 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_7786);
        if (!IS_ATOM_INT(_i_7817)){
            _4238 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_7817)->dbl));
        }
        else{
            _4238 = (int)*(((s1_ptr)_2)->base + _i_7817);
        }
        if (_fs_case_inlined_fs_case_at_216_7827 == _4238)
        _4239 = 1;
        else if (IS_ATOM_INT(_fs_case_inlined_fs_case_at_216_7827) && IS_ATOM_INT(_4238))
        _4239 = 0;
        else
        _4239 = (compare(_fs_case_inlined_fs_case_at_216_7827, _4238) == 0);
        _4238 = NOVALUE;
        if (_4239 != 0)
        goto L8; // [237] 298
        _4239 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_7786)){
                _4241 = SEQ_PTR(_base_paths_7786)->length;
        }
        else {
            _4241 = 1;
        }
        if (IS_ATOM_INT(_i_7817)) {
            _4242 = _4241 - _i_7817;
        }
        else {
            _4242 = NewDouble((double)_4241 - DBL_PTR(_i_7817)->dbl);
        }
        _4241 = NOVALUE;
        _4243 = Repeat(_3847, _4242);
        DeRef(_4242);
        _4242 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_7787)){
                _4244 = SEQ_PTR(_expanded_path_7787)->length;
        }
        else {
            _4244 = 1;
        }
        rhs_slice_target = (object_ptr)&_4245;
        RHS_Slice(_expanded_path_7787, _i_7817, _4244);
        Concat((object_ptr)&_expanded_path_7787, _4243, _4245);
        DeRefDS(_4243);
        _4243 = NOVALUE;
        DeRef(_4243);
        _4243 = NOVALUE;
        DeRefDS(_4245);
        _4245 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_7787);
        _0 = _expanded_path_7787;
        _expanded_path_7787 = _23join(_expanded_path_7787, 47);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_7787)){
                _4248 = SEQ_PTR(_expanded_path_7787)->length;
        }
        else {
            _4248 = 1;
        }
        if (IS_SEQUENCE(_orig_path_7785)){
                _4249 = SEQ_PTR(_orig_path_7785)->length;
        }
        else {
            _4249 = 1;
        }
        if (_4248 >= _4249)
        goto L7; // [282] 305

        /** 		  		return expanded_path*/
        DeRef(_i_7817);
        DeRefDS(_orig_path_7785);
        DeRefDS(_base_paths_7786);
        DeRef(_lowered_expanded_path_7798);
        _4223 = NOVALUE;
        DeRef(_4225);
        _4225 = NOVALUE;
        DeRef(_4227);
        _4227 = NOVALUE;
        DeRef(_4236);
        _4236 = NOVALUE;
        return _expanded_path_7787;

        /** 			exit*/
        goto L7; // [295] 305
L8: 

        /** 	end for*/
        _0 = _i_7817;
        if (IS_ATOM_INT(_i_7817)) {
            _i_7817 = _i_7817 + 1;
            if ((long)((unsigned long)_i_7817 +(unsigned long) HIGH_BITS) >= 0){
                _i_7817 = NewDouble((double)_i_7817);
            }
        }
        else {
            _i_7817 = binary_op_a(PLUS, _i_7817, 1);
        }
        DeRef(_0);
        goto L6; // [300] 208
L7: 
        ;
        DeRef(_i_7817);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_7786);
    DeRef(_expanded_path_7787);
    DeRef(_lowered_expanded_path_7798);
    _4223 = NOVALUE;
    DeRef(_4225);
    _4225 = NOVALUE;
    DeRef(_4227);
    _4227 = NOVALUE;
    DeRef(_4236);
    _4236 = NOVALUE;
    return _orig_path_7785;
    ;
}
int abbreviate_path() __attribute__ ((alias ("_11abbreviate_path")));


int _11split_path(int _fname_7844)
{
    int _4251 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:split(fname, SLASH, 1)*/
    RefDS(_fname_7844);
    _4251 = _23split(_fname_7844, 47, 1, 0);
    DeRefDS(_fname_7844);
    return _4251;
    ;
}
int split_path() __attribute__ ((alias ("_11split_path")));


int _11join_path(int _path_elements_7848)
{
    int _fname_7849 = NOVALUE;
    int _elem_7853 = NOVALUE;
    int _4263 = NOVALUE;
    int _4262 = NOVALUE;
    int _4261 = NOVALUE;
    int _4260 = NOVALUE;
    int _4258 = NOVALUE;
    int _4257 = NOVALUE;
    int _4255 = NOVALUE;
    int _4254 = NOVALUE;
    int _4252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fname = ""*/
    RefDS(_5);
    DeRef(_fname_7849);
    _fname_7849 = _5;

    /** 	for i = 1 to length(path_elements) do*/
    if (IS_SEQUENCE(_path_elements_7848)){
            _4252 = SEQ_PTR(_path_elements_7848)->length;
    }
    else {
        _4252 = 1;
    }
    {
        int _i_7851;
        _i_7851 = 1;
L1: 
        if (_i_7851 > _4252){
            goto L2; // [15] 103
        }

        /** 		sequence elem = path_elements[i]*/
        DeRef(_elem_7853);
        _2 = (int)SEQ_PTR(_path_elements_7848);
        _elem_7853 = (int)*(((s1_ptr)_2)->base + _i_7851);
        Ref(_elem_7853);

        /** 		if elem[$] = SLASH then*/
        if (IS_SEQUENCE(_elem_7853)){
                _4254 = SEQ_PTR(_elem_7853)->length;
        }
        else {
            _4254 = 1;
        }
        _2 = (int)SEQ_PTR(_elem_7853);
        _4255 = (int)*(((s1_ptr)_2)->base + _4254);
        if (binary_op_a(NOTEQ, _4255, 47)){
            _4255 = NOVALUE;
            goto L3; // [39] 58
        }
        _4255 = NOVALUE;

        /** 			elem = elem[1..$ - 1]*/
        if (IS_SEQUENCE(_elem_7853)){
                _4257 = SEQ_PTR(_elem_7853)->length;
        }
        else {
            _4257 = 1;
        }
        _4258 = _4257 - 1;
        _4257 = NOVALUE;
        rhs_slice_target = (object_ptr)&_elem_7853;
        RHS_Slice(_elem_7853, 1, _4258);
L3: 

        /** 		if length(elem) and elem[1] != SLASH then*/
        if (IS_SEQUENCE(_elem_7853)){
                _4260 = SEQ_PTR(_elem_7853)->length;
        }
        else {
            _4260 = 1;
        }
        if (_4260 == 0) {
            goto L4; // [63] 88
        }
        _2 = (int)SEQ_PTR(_elem_7853);
        _4262 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_4262)) {
            _4263 = (_4262 != 47);
        }
        else {
            _4263 = binary_op(NOTEQ, _4262, 47);
        }
        _4262 = NOVALUE;
        if (_4263 == 0) {
            DeRef(_4263);
            _4263 = NOVALUE;
            goto L4; // [76] 88
        }
        else {
            if (!IS_ATOM_INT(_4263) && DBL_PTR(_4263)->dbl == 0.0){
                DeRef(_4263);
                _4263 = NOVALUE;
                goto L4; // [76] 88
            }
            DeRef(_4263);
            _4263 = NOVALUE;
        }
        DeRef(_4263);
        _4263 = NOVALUE;

        /** 			ifdef WINDOWS then*/

        /** 				elem = SLASH & elem*/
        Prepend(&_elem_7853, _elem_7853, 47);
L4: 

        /** 		fname &= elem*/
        Concat((object_ptr)&_fname_7849, _fname_7849, _elem_7853);
        DeRefDS(_elem_7853);
        _elem_7853 = NOVALUE;

        /** 	end for*/
        _i_7851 = _i_7851 + 1;
        goto L1; // [98] 22
L2: 
        ;
    }

    /** 	return fname*/
    DeRefDS(_path_elements_7848);
    DeRef(_4258);
    _4258 = NOVALUE;
    return _fname_7849;
    ;
}
int join_path() __attribute__ ((alias ("_11join_path")));


int _11file_type(int _filename_7875)
{
    int _dirfil_7876 = NOVALUE;
    int _4282 = NOVALUE;
    int _4281 = NOVALUE;
    int _4280 = NOVALUE;
    int _4279 = NOVALUE;
    int _4278 = NOVALUE;
    int _4276 = NOVALUE;
    int _4275 = NOVALUE;
    int _4274 = NOVALUE;
    int _4273 = NOVALUE;
    int _4272 = NOVALUE;
    int _4271 = NOVALUE;
    int _4270 = NOVALUE;
    int _4268 = NOVALUE;
    int _4266 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _4266 = find_from(42, _filename_7875, 1);
    if (_4266 != 0) {
        goto L1; // [10] 24
    }
    _4268 = find_from(63, _filename_7875, 1);
    if (_4268 == 0)
    {
        _4268 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _4268 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_7875);
    DeRef(_dirfil_7876);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	dirfil = dir(filename)*/
    RefDS(_filename_7875);
    _0 = _dirfil_7876;
    _dirfil_7876 = _11dir(_filename_7875);
    DeRef(_0);

    /** 	if sequence(dirfil) then*/
    _4270 = IS_SEQUENCE(_dirfil_7876);
    if (_4270 == 0)
    {
        _4270 = NOVALUE;
        goto L3; // [42] 126
    }
    else{
        _4270 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_7876)){
            _4271 = SEQ_PTR(_dirfil_7876)->length;
    }
    else {
        _4271 = 1;
    }
    _4272 = (_4271 > 1);
    _4271 = NOVALUE;
    if (_4272 != 0) {
        _4273 = 1;
        goto L4; // [54] 75
    }
    _2 = (int)SEQ_PTR(_dirfil_7876);
    _4274 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4274);
    _4275 = (int)*(((s1_ptr)_2)->base + 2);
    _4274 = NOVALUE;
    _4276 = find_from(100, _4275, 1);
    _4275 = NOVALUE;
    _4273 = (_4276 != 0);
L4: 
    if (_4273 != 0) {
        goto L5; // [75] 107
    }
    if (IS_SEQUENCE(_filename_7875)){
            _4278 = SEQ_PTR(_filename_7875)->length;
    }
    else {
        _4278 = 1;
    }
    _4279 = (_4278 == 3);
    _4278 = NOVALUE;
    if (_4279 == 0) {
        DeRef(_4280);
        _4280 = 0;
        goto L6; // [86] 102
    }
    _2 = (int)SEQ_PTR(_filename_7875);
    _4281 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4281)) {
        _4282 = (_4281 == 58);
    }
    else {
        _4282 = binary_op(EQUALS, _4281, 58);
    }
    _4281 = NOVALUE;
    if (IS_ATOM_INT(_4282))
    _4280 = (_4282 != 0);
    else
    _4280 = DBL_PTR(_4282)->dbl != 0.0;
L6: 
    if (_4280 == 0)
    {
        _4280 = NOVALUE;
        goto L7; // [103] 116
    }
    else{
        _4280 = NOVALUE;
    }
L5: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_7875);
    DeRef(_dirfil_7876);
    DeRef(_4272);
    _4272 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    DeRef(_4282);
    _4282 = NOVALUE;
    return 2;
    goto L8; // [113] 133
L7: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_7875);
    DeRef(_dirfil_7876);
    DeRef(_4272);
    _4272 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    DeRef(_4282);
    _4282 = NOVALUE;
    return 1;
    goto L8; // [123] 133
L3: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_7875);
    DeRef(_dirfil_7876);
    DeRef(_4272);
    _4272 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    DeRef(_4282);
    _4282 = NOVALUE;
    return 0;
L8: 
    ;
}
int file_type() __attribute__ ((alias ("_11file_type")));


int _11file_exists(int _name_7915)
{
    int _pName_7918 = NOVALUE;
    int _r_7920 = NOVALUE;
    int _4287 = NOVALUE;
    int _4285 = NOVALUE;
    int _4283 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _4283 = IS_ATOM(_name_7915);
    if (_4283 == 0)
    {
        _4283 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _4283 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_7915);
    DeRef(_pName_7918);
    DeRef(_r_7920);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = machine:allocate_string(name)*/
    Ref(_name_7915);
    _0 = _pName_7918;
    _pName_7918 = _14allocate_string(_name_7915, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName, 0})*/
    Ref(_pName_7918);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pName_7918;
    ((int *)_2)[2] = 0;
    _4285 = MAKE_SEQ(_1);
    DeRef(_r_7920);
    _r_7920 = call_c(1, _11xGetFileAttributes_6996, _4285);
    DeRefDS(_4285);
    _4285 = NOVALUE;

    /** 		machine:free(pName)*/
    Ref(_pName_7918);
    _14free(_pName_7918);

    /** 		return r = 0*/
    if (IS_ATOM_INT(_r_7920)) {
        _4287 = (_r_7920 == 0);
    }
    else {
        _4287 = (DBL_PTR(_r_7920)->dbl == (double)0);
    }
    DeRef(_name_7915);
    DeRef(_pName_7918);
    DeRef(_r_7920);
    return _4287;
    ;
}
int file_exists() __attribute__ ((alias ("_11file_exists")));


int _11file_timestamp(int _fname_7926)
{
    int _d_7927 = NOVALUE;
    int _4302 = NOVALUE;
    int _4301 = NOVALUE;
    int _4300 = NOVALUE;
    int _4299 = NOVALUE;
    int _4298 = NOVALUE;
    int _4297 = NOVALUE;
    int _4296 = NOVALUE;
    int _4295 = NOVALUE;
    int _4294 = NOVALUE;
    int _4293 = NOVALUE;
    int _4292 = NOVALUE;
    int _4291 = NOVALUE;
    int _4290 = NOVALUE;
    int _4289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/
    RefDS(_fname_7926);
    _0 = _d_7927;
    _d_7927 = _11dir(_fname_7926);
    DeRef(_0);

    /** 	if atom(d) then return -1 end if*/
    _4289 = IS_ATOM(_d_7927);
    if (_4289 == 0)
    {
        _4289 = NOVALUE;
        goto L1; // [14] 22
    }
    else{
        _4289 = NOVALUE;
    }
    DeRefDS(_fname_7926);
    DeRef(_d_7927);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_7927);
    _4290 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4290);
    _4291 = (int)*(((s1_ptr)_2)->base + 4);
    _4290 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_7927);
    _4292 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4292);
    _4293 = (int)*(((s1_ptr)_2)->base + 5);
    _4292 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_7927);
    _4294 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4294);
    _4295 = (int)*(((s1_ptr)_2)->base + 6);
    _4294 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_7927);
    _4296 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4296);
    _4297 = (int)*(((s1_ptr)_2)->base + 7);
    _4296 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_7927);
    _4298 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4298);
    _4299 = (int)*(((s1_ptr)_2)->base + 8);
    _4298 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_7927);
    _4300 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4300);
    _4301 = (int)*(((s1_ptr)_2)->base + 9);
    _4300 = NOVALUE;
    Ref(_4291);
    Ref(_4293);
    Ref(_4295);
    Ref(_4297);
    Ref(_4299);
    Ref(_4301);
    _4302 = _12new(_4291, _4293, _4295, _4297, _4299, _4301);
    _4291 = NOVALUE;
    _4293 = NOVALUE;
    _4295 = NOVALUE;
    _4297 = NOVALUE;
    _4299 = NOVALUE;
    _4301 = NOVALUE;
    DeRefDS(_fname_7926);
    DeRef(_d_7927);
    return _4302;
    ;
}
int file_timestamp() __attribute__ ((alias ("_11file_timestamp")));


int _11copy_file(int _src_7946, int _dest_7947, int _overwrite_7948)
{
    int _info_7959 = NOVALUE;
    int _success_7963 = NOVALUE;
    int _in_7970 = NOVALUE;
    int _out_7972 = NOVALUE;
    int _byte_7978 = NOVALUE;
    int _4321 = NOVALUE;
    int _4320 = NOVALUE;
    int _4319 = NOVALUE;
    int _4316 = NOVALUE;
    int _4315 = NOVALUE;
    int _4313 = NOVALUE;
    int _4311 = NOVALUE;
    int _4307 = NOVALUE;
    int _4306 = NOVALUE;
    int _4304 = NOVALUE;
    int _4303 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_7948)) {
        _1 = (long)(DBL_PTR(_overwrite_7948)->dbl);
        DeRefDS(_overwrite_7948);
        _overwrite_7948 = _1;
    }

    /** 	if length(dest) then*/
    if (IS_SEQUENCE(_dest_7947)){
            _4303 = SEQ_PTR(_dest_7947)->length;
    }
    else {
        _4303 = 1;
    }
    if (_4303 == 0)
    {
        _4303 = NOVALUE;
        goto L1; // [12] 68
    }
    else{
        _4303 = NOVALUE;
    }

    /** 		if file_type( dest ) = FILETYPE_DIRECTORY then*/
    RefDS(_dest_7947);
    _4304 = _11file_type(_dest_7947);
    if (binary_op_a(NOTEQ, _4304, 2)){
        DeRef(_4304);
        _4304 = NOVALUE;
        goto L2; // [21] 65
    }
    DeRef(_4304);
    _4304 = NOVALUE;

    /** 			if dest[$] != SLASH then*/
    if (IS_SEQUENCE(_dest_7947)){
            _4306 = SEQ_PTR(_dest_7947)->length;
    }
    else {
        _4306 = 1;
    }
    _2 = (int)SEQ_PTR(_dest_7947);
    _4307 = (int)*(((s1_ptr)_2)->base + _4306);
    if (binary_op_a(EQUALS, _4307, 47)){
        _4307 = NOVALUE;
        goto L3; // [34] 45
    }
    _4307 = NOVALUE;

    /** 				dest &= SLASH*/
    Append(&_dest_7947, _dest_7947, 47);
L3: 

    /** 			sequence info = pathinfo( src )*/
    RefDS(_src_7946);
    _0 = _info_7959;
    _info_7959 = _11pathinfo(_src_7946, 0);
    DeRef(_0);

    /** 			dest &= info[PATH_FILENAME]*/
    _2 = (int)SEQ_PTR(_info_7959);
    _4311 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_dest_7947) && IS_ATOM(_4311)) {
        Ref(_4311);
        Append(&_dest_7947, _dest_7947, _4311);
    }
    else if (IS_ATOM(_dest_7947) && IS_SEQUENCE(_4311)) {
    }
    else {
        Concat((object_ptr)&_dest_7947, _dest_7947, _4311);
    }
    _4311 = NOVALUE;
L2: 
    DeRef(_info_7959);
    _info_7959 = NOVALUE;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		integer success = 0*/
    _success_7963 = 0;

    /** 		if file_exists(src) then*/
    RefDS(_src_7946);
    _4313 = _11file_exists(_src_7946);
    if (_4313 == 0) {
        DeRef(_4313);
        _4313 = NOVALUE;
        goto L4; // [81] 187
    }
    else {
        if (!IS_ATOM_INT(_4313) && DBL_PTR(_4313)->dbl == 0.0){
            DeRef(_4313);
            _4313 = NOVALUE;
            goto L4; // [81] 187
        }
        DeRef(_4313);
        _4313 = NOVALUE;
    }
    DeRef(_4313);
    _4313 = NOVALUE;

    /** 			if overwrite or not file_exists( dest ) then*/
    if (_overwrite_7948 != 0) {
        goto L5; // [86] 102
    }
    RefDS(_dest_7947);
    _4315 = _11file_exists(_dest_7947);
    if (IS_ATOM_INT(_4315)) {
        _4316 = (_4315 == 0);
    }
    else {
        _4316 = unary_op(NOT, _4315);
    }
    DeRef(_4315);
    _4315 = NOVALUE;
    if (_4316 == 0) {
        DeRef(_4316);
        _4316 = NOVALUE;
        goto L6; // [98] 184
    }
    else {
        if (!IS_ATOM_INT(_4316) && DBL_PTR(_4316)->dbl == 0.0){
            DeRef(_4316);
            _4316 = NOVALUE;
            goto L6; // [98] 184
        }
        DeRef(_4316);
        _4316 = NOVALUE;
    }
    DeRef(_4316);
    _4316 = NOVALUE;
L5: 

    /** 				integer*/

    /** 					in  = open( src, "rb" ),*/
    _in_7970 = EOpen(_src_7946, _1284, 0);

    /** 					out = open( dest, "wb" )*/
    _out_7972 = EOpen(_dest_7947, _1325, 0);

    /** 				if in != -1 and out != -1 then*/
    _4319 = (_in_7970 != -1);
    if (_4319 == 0) {
        goto L7; // [124] 181
    }
    _4321 = (_out_7972 != -1);
    if (_4321 == 0)
    {
        DeRef(_4321);
        _4321 = NOVALUE;
        goto L7; // [133] 181
    }
    else{
        DeRef(_4321);
        _4321 = NOVALUE;
    }

    /** 					integer byte*/

    /** 					while byte != -1 with entry do*/
    goto L8; // [140] 157
L9: 
    if (_byte_7978 == -1)
    goto LA; // [145] 167

    /** 						puts( out, byte )*/
    EPuts(_out_7972, _byte_7978); // DJP 

    /** 					entry*/
L8: 

    /** 						byte = getc( in )*/
    if (_in_7970 != last_r_file_no) {
        last_r_file_ptr = which_file(_in_7970, EF_READ);
        last_r_file_no = _in_7970;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _byte_7978 = getc((FILE*)xstdin);
        }
        else
        _byte_7978 = getc(last_r_file_ptr);
    }
    else
    _byte_7978 = getc(last_r_file_ptr);

    /** 					end while*/
    goto L9; // [164] 143
LA: 

    /** 					success = 1*/
    _success_7963 = 1;

    /** 					close( in )*/
    EClose(_in_7970);

    /** 					close( out )*/
    EClose(_out_7972);
L7: 
L6: 
L4: 

    /** 	return success*/
    DeRefDS(_src_7946);
    DeRefDS(_dest_7947);
    DeRef(_4319);
    _4319 = NOVALUE;
    return _success_7963;
    ;
}
int copy_file() __attribute__ ((alias ("_11copy_file")));


int _11rename_file(int _old_name_7984, int _new_name_7985, int _overwrite_7986)
{
    int _psrc_7987 = NOVALUE;
    int _pdest_7988 = NOVALUE;
    int _ret_7989 = NOVALUE;
    int _tempfile_7990 = NOVALUE;
    int _4339 = NOVALUE;
    int _4336 = NOVALUE;
    int _4334 = NOVALUE;
    int _4331 = NOVALUE;
    int _4326 = NOVALUE;
    int _4325 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_7986)) {
        _1 = (long)(DBL_PTR(_overwrite_7986)->dbl);
        DeRefDS(_overwrite_7986);
        _overwrite_7986 = _1;
    }

    /** 	sequence tempfile = ""*/
    RefDS(_5);
    DeRef(_tempfile_7990);
    _tempfile_7990 = _5;

    /** 	if not overwrite then*/
    if (_overwrite_7986 != 0)
    goto L1; // [16] 38

    /** 		if file_exists(new_name) then*/
    RefDS(_new_name_7985);
    _4325 = _11file_exists(_new_name_7985);
    if (_4325 == 0) {
        DeRef(_4325);
        _4325 = NOVALUE;
        goto L2; // [25] 68
    }
    else {
        if (!IS_ATOM_INT(_4325) && DBL_PTR(_4325)->dbl == 0.0){
            DeRef(_4325);
            _4325 = NOVALUE;
            goto L2; // [25] 68
        }
        DeRef(_4325);
        _4325 = NOVALUE;
    }
    DeRef(_4325);
    _4325 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_old_name_7984);
    DeRefDS(_new_name_7985);
    DeRef(_psrc_7987);
    DeRef(_pdest_7988);
    DeRef(_ret_7989);
    DeRefDS(_tempfile_7990);
    return 0;
    goto L2; // [35] 68
L1: 

    /** 		if file_exists(new_name) then*/
    RefDS(_new_name_7985);
    _4326 = _11file_exists(_new_name_7985);
    if (_4326 == 0) {
        DeRef(_4326);
        _4326 = NOVALUE;
        goto L3; // [44] 67
    }
    else {
        if (!IS_ATOM_INT(_4326) && DBL_PTR(_4326)->dbl == 0.0){
            DeRef(_4326);
            _4326 = NOVALUE;
            goto L3; // [44] 67
        }
        DeRef(_4326);
        _4326 = NOVALUE;
    }
    DeRef(_4326);
    _4326 = NOVALUE;

    /** 			tempfile = temp_file(new_name)*/
    RefDS(_new_name_7985);
    RefDS(_5);
    RefDS(_4589);
    _0 = _tempfile_7990;
    _tempfile_7990 = _11temp_file(_new_name_7985, _5, _4589, 0);
    DeRef(_0);

    /** 			ret = move_file(new_name, tempfile)*/
    RefDS(_new_name_7985);
    RefDS(_tempfile_7990);
    _0 = _ret_7989;
    _ret_7989 = _11move_file(_new_name_7985, _tempfile_7990, 0);
    DeRef(_0);
L3: 
L2: 

    /** 	psrc = machine:allocate_string(old_name)*/
    RefDS(_old_name_7984);
    _0 = _psrc_7987;
    _psrc_7987 = _14allocate_string(_old_name_7984, 0);
    DeRef(_0);

    /** 	pdest = machine:allocate_string(new_name)*/
    RefDS(_new_name_7985);
    _0 = _pdest_7988;
    _pdest_7988 = _14allocate_string(_new_name_7985, 0);
    DeRef(_0);

    /** 	ret = c_func(xMoveFile, {psrc, pdest})*/
    Ref(_pdest_7988);
    Ref(_psrc_7987);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrc_7987;
    ((int *)_2)[2] = _pdest_7988;
    _4331 = MAKE_SEQ(_1);
    DeRef(_ret_7989);
    _ret_7989 = call_c(1, _11xMoveFile_6980, _4331);
    DeRefDS(_4331);
    _4331 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		ret = not ret */
    _0 = _ret_7989;
    if (IS_ATOM_INT(_ret_7989)) {
        _ret_7989 = (_ret_7989 == 0);
    }
    else {
        _ret_7989 = unary_op(NOT, _ret_7989);
    }
    DeRef(_0);

    /** 	machine:free({pdest, psrc})*/
    Ref(_psrc_7987);
    Ref(_pdest_7988);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pdest_7988;
    ((int *)_2)[2] = _psrc_7987;
    _4334 = MAKE_SEQ(_1);
    _14free(_4334);
    _4334 = NOVALUE;

    /** 	if overwrite then*/
    if (_overwrite_7986 == 0)
    {
        goto L4; // [113] 147
    }
    else{
    }

    /** 		if not ret then*/
    if (_ret_7989 != 0)
    goto L5; // [118] 140

    /** 			if length(tempfile) > 0 then*/
    if (IS_SEQUENCE(_tempfile_7990)){
            _4336 = SEQ_PTR(_tempfile_7990)->length;
    }
    else {
        _4336 = 1;
    }
    if (_4336 <= 0)
    goto L6; // [126] 139

    /** 				ret = move_file(tempfile, new_name)*/
    RefDS(_tempfile_7990);
    RefDS(_new_name_7985);
    _ret_7989 = _11move_file(_tempfile_7990, _new_name_7985, 0);
L6: 
L5: 

    /** 		delete_file(tempfile)*/
    RefDS(_tempfile_7990);
    _4339 = _11delete_file(_tempfile_7990);
L4: 

    /** 	return ret*/
    DeRefDS(_old_name_7984);
    DeRefDS(_new_name_7985);
    DeRef(_psrc_7987);
    DeRef(_pdest_7988);
    DeRef(_tempfile_7990);
    DeRef(_4339);
    _4339 = NOVALUE;
    return _ret_7989;
    ;
}
int rename_file() __attribute__ ((alias ("_11rename_file")));


int _11move_file(int _src_8025, int _dest_8026, int _overwrite_8027)
{
    int _psrc_8028 = NOVALUE;
    int _pdest_8029 = NOVALUE;
    int _ret_8030 = NOVALUE;
    int _tempfile_8031 = NOVALUE;
    int _psrcbuf_8039 = NOVALUE;
    int _pdestbuf_8040 = NOVALUE;
    int _stat_t_offset_8041 = NOVALUE;
    int _stat_buf_size_8042 = NOVALUE;
    int _xstat_1__tmp_at103_8048 = NOVALUE;
    int _xstat_inlined_xstat_at_103_8047 = NOVALUE;
    int _xstat_1__tmp_at158_8055 = NOVALUE;
    int _xstat_inlined_xstat_at_158_8054 = NOVALUE;
    int _pdir_8057 = NOVALUE;
    int _current_dir_inlined_current_dir_at_199_8063 = NOVALUE;
    int _xstat_1__tmp_at231_8070 = NOVALUE;
    int _xstat_inlined_xstat_at_231_8069 = NOVALUE;
    int _4380 = NOVALUE;
    int _4379 = NOVALUE;
    int _4378 = NOVALUE;
    int _4376 = NOVALUE;
    int _4375 = NOVALUE;
    int _4372 = NOVALUE;
    int _4371 = NOVALUE;
    int _4369 = NOVALUE;
    int _4368 = NOVALUE;
    int _4365 = NOVALUE;
    int _4364 = NOVALUE;
    int _4363 = NOVALUE;
    int _4362 = NOVALUE;
    int _4361 = NOVALUE;
    int _4360 = NOVALUE;
    int _4359 = NOVALUE;
    int _4358 = NOVALUE;
    int _4356 = NOVALUE;
    int _4353 = NOVALUE;
    int _4352 = NOVALUE;
    int _4349 = NOVALUE;
    int _4345 = NOVALUE;
    int _4342 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_8027)) {
        _1 = (long)(DBL_PTR(_overwrite_8027)->dbl);
        DeRefDS(_overwrite_8027);
        _overwrite_8027 = _1;
    }

    /** 	atom psrc = 0, pdest = 0, ret*/
    DeRef(_psrc_8028);
    _psrc_8028 = 0;
    DeRef(_pdest_8029);
    _pdest_8029 = 0;

    /** 	sequence tempfile = ""*/
    RefDS(_5);
    DeRef(_tempfile_8031);
    _tempfile_8031 = _5;

    /** 	if not file_exists(src) then*/
    RefDS(_src_8025);
    _4342 = _11file_exists(_src_8025);
    if (IS_ATOM_INT(_4342)) {
        if (_4342 != 0){
            DeRef(_4342);
            _4342 = NOVALUE;
            goto L1; // [28] 38
        }
    }
    else {
        if (DBL_PTR(_4342)->dbl != 0.0){
            DeRef(_4342);
            _4342 = NOVALUE;
            goto L1; // [28] 38
        }
    }
    DeRef(_4342);
    _4342 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_src_8025);
    DeRefDS(_dest_8026);
    DeRef(_ret_8030);
    DeRefDS(_tempfile_8031);
    DeRef(_psrcbuf_8039);
    DeRef(_pdestbuf_8040);
    return 0;
L1: 

    /** 	if not overwrite then*/
    if (_overwrite_8027 != 0)
    goto L2; // [40] 60

    /** 		if file_exists( dest ) then*/
    RefDS(_dest_8026);
    _4345 = _11file_exists(_dest_8026);
    if (_4345 == 0) {
        DeRef(_4345);
        _4345 = NOVALUE;
        goto L3; // [49] 59
    }
    else {
        if (!IS_ATOM_INT(_4345) && DBL_PTR(_4345)->dbl == 0.0){
            DeRef(_4345);
            _4345 = NOVALUE;
            goto L3; // [49] 59
        }
        DeRef(_4345);
        _4345 = NOVALUE;
    }
    DeRef(_4345);
    _4345 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_src_8025);
    DeRefDS(_dest_8026);
    DeRef(_psrc_8028);
    DeRef(_pdest_8029);
    DeRef(_ret_8030);
    DeRef(_tempfile_8031);
    DeRef(_psrcbuf_8039);
    DeRef(_pdestbuf_8040);
    return 0;
L3: 
L2: 

    /** 	ifdef UNIX then*/

    /** 		atom psrcbuf = 0, pdestbuf = 0*/
    DeRef(_psrcbuf_8039);
    _psrcbuf_8039 = 0;
    DeRef(_pdestbuf_8040);
    _pdestbuf_8040 = 0;

    /** 		integer stat_t_offset, stat_buf_size*/

    /** 	ifdef LINUX then*/

    /** 		stat_t_offset = 0*/
    _stat_t_offset_8041 = 0;

    /** 		stat_buf_size = 88*/
    _stat_buf_size_8042 = 88;

    /** 	ifdef UNIX then*/

    /** 		psrcbuf = machine:allocate(stat_buf_size)*/
    _psrcbuf_8039 = _14allocate(88, 0);

    /** 		psrc = machine:allocate_string(src)*/
    RefDS(_src_8025);
    _0 = _psrc_8028;
    _psrc_8028 = _14allocate_string(_src_8025, 0);
    DeRef(_0);

    /** 		ret = xstat(psrc, psrcbuf)*/

    /** 		return c_func(xStatFile, {3, psrc, psrcbuf})*/
    _0 = _xstat_1__tmp_at103_8048;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3;
    Ref(_psrc_8028);
    *((int *)(_2+8)) = _psrc_8028;
    Ref(_psrcbuf_8039);
    *((int *)(_2+12)) = _psrcbuf_8039;
    _xstat_1__tmp_at103_8048 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_ret_8030);
    _ret_8030 = call_c(1, _11xStatFile_6975, _xstat_1__tmp_at103_8048);
    DeRef(_xstat_1__tmp_at103_8048);
    _xstat_1__tmp_at103_8048 = NOVALUE;

    /** 		if ret then*/
    if (_ret_8030 == 0) {
        goto L4; // [124] 143
    }
    else {
        if (!IS_ATOM_INT(_ret_8030) && DBL_PTR(_ret_8030)->dbl == 0.0){
            goto L4; // [124] 143
        }
    }

    /**  			machine:free({psrcbuf, psrc})*/
    Ref(_psrc_8028);
    Ref(_psrcbuf_8039);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrcbuf_8039;
    ((int *)_2)[2] = _psrc_8028;
    _4349 = MAKE_SEQ(_1);
    _14free(_4349);
    _4349 = NOVALUE;

    /**  			return 0*/
    DeRefDS(_src_8025);
    DeRefDS(_dest_8026);
    DeRef(_psrc_8028);
    DeRef(_pdest_8029);
    DeRef(_ret_8030);
    DeRef(_tempfile_8031);
    DeRef(_psrcbuf_8039);
    DeRef(_pdestbuf_8040);
    return 0;
L4: 

    /** 		pdestbuf = machine:allocate(stat_buf_size)*/
    _0 = _pdestbuf_8040;
    _pdestbuf_8040 = _14allocate(_stat_buf_size_8042, 0);
    DeRef(_0);

    /** 		pdest = machine:allocate_string(dest)*/
    RefDS(_dest_8026);
    _0 = _pdest_8029;
    _pdest_8029 = _14allocate_string(_dest_8026, 0);
    DeRef(_0);

    /** 		ret = xstat(pdest, pdestbuf)*/

    /** 		return c_func(xStatFile, {3, psrc, psrcbuf})*/
    _0 = _xstat_1__tmp_at158_8055;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3;
    Ref(_pdest_8029);
    *((int *)(_2+8)) = _pdest_8029;
    Ref(_pdestbuf_8040);
    *((int *)(_2+12)) = _pdestbuf_8040;
    _xstat_1__tmp_at158_8055 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_ret_8030);
    _ret_8030 = call_c(1, _11xStatFile_6975, _xstat_1__tmp_at158_8055);
    DeRef(_xstat_1__tmp_at158_8055);
    _xstat_1__tmp_at158_8055 = NOVALUE;

    /** 		if ret then*/
    if (_ret_8030 == 0) {
        goto L5; // [179] 256
    }
    else {
        if (!IS_ATOM_INT(_ret_8030) && DBL_PTR(_ret_8030)->dbl == 0.0){
            goto L5; // [179] 256
        }
    }

    /** 			atom pdir*/

    /** 			if length(dirname(dest)) = 0 then*/
    RefDS(_dest_8026);
    _4352 = _11dirname(_dest_8026, 0);
    if (IS_SEQUENCE(_4352)){
            _4353 = SEQ_PTR(_4352)->length;
    }
    else {
        _4353 = 1;
    }
    DeRef(_4352);
    _4352 = NOVALUE;
    if (_4353 != 0)
    goto L6; // [194] 215

    /** 				pdir = machine:allocate_string(current_dir())*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_current_dir_inlined_current_dir_at_199_8063);
    _current_dir_inlined_current_dir_at_199_8063 = machine(23, 0);
    RefDS(_current_dir_inlined_current_dir_at_199_8063);
    _0 = _pdir_8057;
    _pdir_8057 = _14allocate_string(_current_dir_inlined_current_dir_at_199_8063, 0);
    DeRef(_0);
    goto L7; // [212] 228
L6: 

    /** 				pdir = machine:allocate_string(dirname(dest))*/
    RefDS(_dest_8026);
    _4356 = _11dirname(_dest_8026, 0);
    _0 = _pdir_8057;
    _pdir_8057 = _14allocate_string(_4356, 0);
    DeRef(_0);
    _4356 = NOVALUE;
L7: 

    /** 			ret = xstat(pdir, pdestbuf)*/

    /** 		return c_func(xStatFile, {3, psrc, psrcbuf})*/
    _0 = _xstat_1__tmp_at231_8070;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3;
    Ref(_pdir_8057);
    *((int *)(_2+8)) = _pdir_8057;
    Ref(_pdestbuf_8040);
    *((int *)(_2+12)) = _pdestbuf_8040;
    _xstat_1__tmp_at231_8070 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_ret_8030);
    _ret_8030 = call_c(1, _11xStatFile_6975, _xstat_1__tmp_at231_8070);
    DeRef(_xstat_1__tmp_at231_8070);
    _xstat_1__tmp_at231_8070 = NOVALUE;

    /** 			machine:free(pdir)*/
    Ref(_pdir_8057);
    _14free(_pdir_8057);
L5: 
    DeRef(_pdir_8057);
    _pdir_8057 = NOVALUE;

    /** 		if not ret and not equal(peek(pdestbuf+stat_t_offset), peek(psrcbuf+stat_t_offset)) then*/
    if (IS_ATOM_INT(_ret_8030)) {
        _4358 = (_ret_8030 == 0);
    }
    else {
        _4358 = unary_op(NOT, _ret_8030);
    }
    if (_4358 == 0) {
        goto L8; // [263] 336
    }
    if (IS_ATOM_INT(_pdestbuf_8040)) {
        _4360 = _pdestbuf_8040 + _stat_t_offset_8041;
        if ((long)((unsigned long)_4360 + (unsigned long)HIGH_BITS) >= 0) 
        _4360 = NewDouble((double)_4360);
    }
    else {
        _4360 = NewDouble(DBL_PTR(_pdestbuf_8040)->dbl + (double)_stat_t_offset_8041);
    }
    if (IS_ATOM_INT(_4360)) {
        _4361 = *(unsigned char *)_4360;
    }
    else {
        _4361 = *(unsigned char *)(unsigned long)(DBL_PTR(_4360)->dbl);
    }
    DeRef(_4360);
    _4360 = NOVALUE;
    if (IS_ATOM_INT(_psrcbuf_8039)) {
        _4362 = _psrcbuf_8039 + _stat_t_offset_8041;
        if ((long)((unsigned long)_4362 + (unsigned long)HIGH_BITS) >= 0) 
        _4362 = NewDouble((double)_4362);
    }
    else {
        _4362 = NewDouble(DBL_PTR(_psrcbuf_8039)->dbl + (double)_stat_t_offset_8041);
    }
    if (IS_ATOM_INT(_4362)) {
        _4363 = *(unsigned char *)_4362;
    }
    else {
        _4363 = *(unsigned char *)(unsigned long)(DBL_PTR(_4362)->dbl);
    }
    DeRef(_4362);
    _4362 = NOVALUE;
    if (_4361 == _4363)
    _4364 = 1;
    else if (IS_ATOM_INT(_4361) && IS_ATOM_INT(_4363))
    _4364 = 0;
    else
    _4364 = (compare(_4361, _4363) == 0);
    _4361 = NOVALUE;
    _4363 = NOVALUE;
    _4365 = (_4364 == 0);
    _4364 = NOVALUE;
    if (_4365 == 0)
    {
        DeRef(_4365);
        _4365 = NOVALUE;
        goto L8; // [291] 336
    }
    else{
        DeRef(_4365);
        _4365 = NOVALUE;
    }

    /** 			ret = copy_file(src, dest, overwrite)*/
    RefDS(_src_8025);
    RefDS(_dest_8026);
    _0 = _ret_8030;
    _ret_8030 = _11copy_file(_src_8025, _dest_8026, _overwrite_8027);
    DeRef(_0);

    /** 			if ret then*/
    if (_ret_8030 == 0) {
        goto L9; // [304] 314
    }
    else {
        if (!IS_ATOM_INT(_ret_8030) && DBL_PTR(_ret_8030)->dbl == 0.0){
            goto L9; // [304] 314
        }
    }

    /** 				ret = delete_file(src)*/
    RefDS(_src_8025);
    _0 = _ret_8030;
    _ret_8030 = _11delete_file(_src_8025);
    DeRef(_0);
L9: 

    /**  			machine:free({psrcbuf, psrc, pdestbuf, pdest})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_psrcbuf_8039);
    *((int *)(_2+4)) = _psrcbuf_8039;
    Ref(_psrc_8028);
    *((int *)(_2+8)) = _psrc_8028;
    Ref(_pdestbuf_8040);
    *((int *)(_2+12)) = _pdestbuf_8040;
    Ref(_pdest_8029);
    *((int *)(_2+16)) = _pdest_8029;
    _4368 = MAKE_SEQ(_1);
    _14free(_4368);
    _4368 = NOVALUE;

    /**  			return (not ret)*/
    if (IS_ATOM_INT(_ret_8030)) {
        _4369 = (_ret_8030 == 0);
    }
    else {
        _4369 = unary_op(NOT, _ret_8030);
    }
    DeRefDS(_src_8025);
    DeRefDS(_dest_8026);
    DeRef(_psrc_8028);
    DeRef(_pdest_8029);
    DeRef(_ret_8030);
    DeRef(_tempfile_8031);
    DeRef(_psrcbuf_8039);
    DeRef(_pdestbuf_8040);
    _4352 = NOVALUE;
    DeRef(_4358);
    _4358 = NOVALUE;
    return _4369;
L8: 

    /** 	if overwrite then*/
    if (_overwrite_8027 == 0)
    {
        goto LA; // [338] 361
    }
    else{
    }

    /** 		tempfile = temp_file(dest)*/
    RefDS(_dest_8026);
    RefDS(_5);
    RefDS(_4589);
    _0 = _tempfile_8031;
    _tempfile_8031 = _11temp_file(_dest_8026, _5, _4589, 0);
    DeRef(_0);

    /** 		move_file(dest, tempfile)*/
    RefDS(_dest_8026);
    RefDS(_tempfile_8031);
    _4371 = _11move_file(_dest_8026, _tempfile_8031, 0);
LA: 

    /** 	ret = c_func(xMoveFile, {psrc, pdest})*/
    Ref(_pdest_8029);
    Ref(_psrc_8028);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrc_8028;
    ((int *)_2)[2] = _pdest_8029;
    _4372 = MAKE_SEQ(_1);
    DeRef(_ret_8030);
    _ret_8030 = call_c(1, _11xMoveFile_6980, _4372);
    DeRefDS(_4372);
    _4372 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		ret = not ret */
    _0 = _ret_8030;
    if (IS_ATOM_INT(_ret_8030)) {
        _ret_8030 = (_ret_8030 == 0);
    }
    else {
        _ret_8030 = unary_op(NOT, _ret_8030);
    }
    DeRef(_0);

    /** 		machine:free({psrcbuf, pdestbuf})*/
    Ref(_pdestbuf_8040);
    Ref(_psrcbuf_8039);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrcbuf_8039;
    ((int *)_2)[2] = _pdestbuf_8040;
    _4375 = MAKE_SEQ(_1);
    _14free(_4375);
    _4375 = NOVALUE;

    /** 	machine:free({pdest, psrc})*/
    Ref(_psrc_8028);
    Ref(_pdest_8029);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pdest_8029;
    ((int *)_2)[2] = _psrc_8028;
    _4376 = MAKE_SEQ(_1);
    _14free(_4376);
    _4376 = NOVALUE;

    /** 	if overwrite then*/
    if (_overwrite_8027 == 0)
    {
        goto LB; // [405] 432
    }
    else{
    }

    /** 		if not ret then*/
    if (_ret_8030 != 0)
    goto LC; // [410] 425

    /** 			move_file(tempfile, dest)*/
    RefDS(_dest_8026);
    DeRef(_4378);
    _4378 = _dest_8026;
    RefDS(_tempfile_8031);
    _4379 = _11move_file(_tempfile_8031, _4378, 0);
    _4378 = NOVALUE;
LC: 

    /** 		delete_file(tempfile)*/
    RefDS(_tempfile_8031);
    _4380 = _11delete_file(_tempfile_8031);
LB: 

    /** 	return ret*/
    DeRefDS(_src_8025);
    DeRefDS(_dest_8026);
    DeRef(_psrc_8028);
    DeRef(_pdest_8029);
    DeRef(_tempfile_8031);
    DeRef(_psrcbuf_8039);
    DeRef(_pdestbuf_8040);
    _4352 = NOVALUE;
    DeRef(_4358);
    _4358 = NOVALUE;
    DeRef(_4369);
    _4369 = NOVALUE;
    DeRef(_4371);
    _4371 = NOVALUE;
    DeRef(_4379);
    _4379 = NOVALUE;
    DeRef(_4380);
    _4380 = NOVALUE;
    return _ret_8030;
    ;
}
int move_file() __attribute__ ((alias ("_11move_file")));


int _11file_length(int _filename_8102)
{
    int _list_8103 = NOVALUE;
    int _4387 = NOVALUE;
    int _4386 = NOVALUE;
    int _4385 = NOVALUE;
    int _4384 = NOVALUE;
    int _4382 = NOVALUE;
    int _0, _1, _2;
    

    /** 	list = dir(filename)*/
    RefDS(_filename_8102);
    _0 = _list_8103;
    _list_8103 = _11dir(_filename_8102);
    DeRef(_0);

    /** 	if atom(list) or length(list) = 0 then*/
    _4382 = IS_ATOM(_list_8103);
    if (_4382 != 0) {
        goto L1; // [14] 30
    }
    if (IS_SEQUENCE(_list_8103)){
            _4384 = SEQ_PTR(_list_8103)->length;
    }
    else {
        _4384 = 1;
    }
    _4385 = (_4384 == 0);
    _4384 = NOVALUE;
    if (_4385 == 0)
    {
        DeRef(_4385);
        _4385 = NOVALUE;
        goto L2; // [26] 37
    }
    else{
        DeRef(_4385);
        _4385 = NOVALUE;
    }
L1: 

    /** 		return -1*/
    DeRefDS(_filename_8102);
    DeRef(_list_8103);
    return -1;
L2: 

    /** 	return list[1][D_SIZE]*/
    _2 = (int)SEQ_PTR(_list_8103);
    _4386 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_4386);
    _4387 = (int)*(((s1_ptr)_2)->base + 3);
    _4386 = NOVALUE;
    Ref(_4387);
    DeRefDS(_filename_8102);
    DeRef(_list_8103);
    return _4387;
    ;
}
int file_length() __attribute__ ((alias ("_11file_length")));


int _11locate_file(int _filename_8114, int _search_list_8115, int _subdir_8116)
{
    int _extra_paths_8117 = NOVALUE;
    int _this_path_8118 = NOVALUE;
    int _4469 = NOVALUE;
    int _4468 = NOVALUE;
    int _4466 = NOVALUE;
    int _4464 = NOVALUE;
    int _4462 = NOVALUE;
    int _4461 = NOVALUE;
    int _4460 = NOVALUE;
    int _4458 = NOVALUE;
    int _4457 = NOVALUE;
    int _4456 = NOVALUE;
    int _4454 = NOVALUE;
    int _4453 = NOVALUE;
    int _4452 = NOVALUE;
    int _4449 = NOVALUE;
    int _4448 = NOVALUE;
    int _4446 = NOVALUE;
    int _4444 = NOVALUE;
    int _4443 = NOVALUE;
    int _4440 = NOVALUE;
    int _4435 = NOVALUE;
    int _4431 = NOVALUE;
    int _4422 = NOVALUE;
    int _4419 = NOVALUE;
    int _4416 = NOVALUE;
    int _4415 = NOVALUE;
    int _4411 = NOVALUE;
    int _4408 = NOVALUE;
    int _4406 = NOVALUE;
    int _4402 = NOVALUE;
    int _4400 = NOVALUE;
    int _4399 = NOVALUE;
    int _4395 = NOVALUE;
    int _4394 = NOVALUE;
    int _4391 = NOVALUE;
    int _4389 = NOVALUE;
    int _4388 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_8114);
    _4388 = _11absolute_path(_filename_8114);
    if (_4388 == 0) {
        DeRef(_4388);
        _4388 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_4388) && DBL_PTR(_4388)->dbl == 0.0){
            DeRef(_4388);
            _4388 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_4388);
        _4388 = NOVALUE;
    }
    DeRef(_4388);
    _4388 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_8115);
    DeRefDS(_subdir_8116);
    DeRef(_extra_paths_8117);
    DeRef(_this_path_8118);
    return _filename_8114;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_8115)){
            _4389 = SEQ_PTR(_search_list_8115)->length;
    }
    else {
        _4389 = 1;
    }
    if (_4389 != 0)
    goto L2; // [28] 282

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_4391, _3780, 47);
    RefDS(_4391);
    Append(&_search_list_8115, _search_list_8115, _4391);
    DeRefDS(_4391);
    _4391 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_8117);
    _4394 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_4394);
    _4395 = _11dirname(_4394, 0);
    _4394 = NOVALUE;
    _0 = _extra_paths_8117;
    _extra_paths_8117 = _11canonical_path(_4395, 1, 0);
    DeRefDS(_0);
    _4395 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_8117);
    Append(&_search_list_8115, _search_list_8115, _extra_paths_8117);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOME")*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = EGetEnv(_4055);

    /** 		if sequence(extra_paths) then*/
    _4399 = IS_SEQUENCE(_extra_paths_8117);
    if (_4399 == 0)
    {
        _4399 = NOVALUE;
        goto L3; // [81] 95
    }
    else{
        _4399 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_8117) && IS_ATOM(47)) {
        Append(&_4400, _extra_paths_8117, 47);
    }
    else if (IS_ATOM(_extra_paths_8117) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_4400, _extra_paths_8117, 47);
    }
    RefDS(_4400);
    Append(&_search_list_8115, _search_list_8115, _4400);
    DeRefDS(_4400);
    _4400 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_4402, _3847, 47);
    RefDS(_4402);
    Append(&_search_list_8115, _search_list_8115, _4402);
    DeRefDS(_4402);
    _4402 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = EGetEnv(_4404);

    /** 		if sequence(extra_paths) then*/
    _4406 = IS_SEQUENCE(_extra_paths_8117);
    if (_4406 == 0)
    {
        _4406 = NOVALUE;
        goto L4; // [115] 145
    }
    else{
        _4406 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _4407;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_8117;
        Concat_N((object_ptr)&_4408, concat_list, 4);
    }
    RefDS(_4408);
    Append(&_search_list_8115, _search_list_8115, _4408);
    DeRefDS(_4408);
    _4408 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _4410;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_8117;
        Concat_N((object_ptr)&_4411, concat_list, 4);
    }
    RefDS(_4411);
    Append(&_search_list_8115, _search_list_8115, _4411);
    DeRefDS(_4411);
    _4411 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = EGetEnv(_4413);

    /** 		if sequence(extra_paths) then*/
    _4415 = IS_SEQUENCE(_extra_paths_8117);
    if (_4415 == 0)
    {
        _4415 = NOVALUE;
        goto L5; // [155] 195
    }
    else{
        _4415 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_8117) && IS_ATOM(47)) {
        Append(&_4416, _extra_paths_8117, 47);
    }
    else if (IS_ATOM(_extra_paths_8117) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_4416, _extra_paths_8117, 47);
    }
    RefDS(_4416);
    Append(&_search_list_8115, _search_list_8115, _4416);
    DeRefDS(_4416);
    _4416 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _4418;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_8117;
        Concat_N((object_ptr)&_4419, concat_list, 4);
    }
    RefDS(_4419);
    Append(&_search_list_8115, _search_list_8115, _4419);
    DeRefDS(_4419);
    _4419 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _4421;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_8117;
        Concat_N((object_ptr)&_4422, concat_list, 4);
    }
    RefDS(_4422);
    Append(&_search_list_8115, _search_list_8115, _4422);
    DeRefDS(_4422);
    _4422 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 			search_list = append( search_list, "/usr/local/share/euphoria/bin/" )*/
    RefDS(_4424);
    Append(&_search_list_8115, _search_list_8115, _4424);

    /** 			search_list = append( search_list, "/usr/share/euphoria/bin/" )*/
    RefDS(_4426);
    Append(&_search_list_8115, _search_list_8115, _4426);

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_4430);
    *((int *)(_2+4)) = _4430;
    RefDS(_4429);
    *((int *)(_2+8)) = _4429;
    RefDS(_4428);
    *((int *)(_2+12)) = _4428;
    _4431 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_8115, _search_list_8115, _4431);
    DeRefDS(_4431);
    _4431 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = EGetEnv(_4433);

    /** 		if sequence(extra_paths) then*/
    _4435 = IS_SEQUENCE(_extra_paths_8117);
    if (_4435 == 0)
    {
        _4435 = NOVALUE;
        goto L6; // [231] 250
    }
    else{
        _4435 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8117);
    _0 = _extra_paths_8117;
    _extra_paths_8117 = _23split(_extra_paths_8117, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8115) && IS_ATOM(_extra_paths_8117)) {
        Ref(_extra_paths_8117);
        Append(&_search_list_8115, _search_list_8115, _extra_paths_8117);
    }
    else if (IS_ATOM(_search_list_8115) && IS_SEQUENCE(_extra_paths_8117)) {
    }
    else {
        Concat((object_ptr)&_search_list_8115, _search_list_8115, _extra_paths_8117);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_8117);
    _extra_paths_8117 = EGetEnv(_4438);

    /** 		if sequence(extra_paths) then*/
    _4440 = IS_SEQUENCE(_extra_paths_8117);
    if (_4440 == 0)
    {
        _4440 = NOVALUE;
        goto L7; // [260] 307
    }
    else{
        _4440 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_8117);
    _0 = _extra_paths_8117;
    _extra_paths_8117 = _23split(_extra_paths_8117, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_8115) && IS_ATOM(_extra_paths_8117)) {
        Ref(_extra_paths_8117);
        Append(&_search_list_8115, _search_list_8115, _extra_paths_8117);
    }
    else if (IS_ATOM(_search_list_8115) && IS_SEQUENCE(_extra_paths_8117)) {
    }
    else {
        Concat((object_ptr)&_search_list_8115, _search_list_8115, _extra_paths_8117);
    }
    goto L7; // [279] 307
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_8115);
    _4443 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4443))
    _4444 = 1;
    else if (IS_ATOM_DBL(_4443))
    _4444 = IS_ATOM_INT(DoubleToInt(_4443));
    else
    _4444 = 0;
    _4443 = NOVALUE;
    if (_4444 == 0)
    {
        _4444 = NOVALUE;
        goto L8; // [291] 306
    }
    else{
        _4444 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_8115);
    _0 = _search_list_8115;
    _search_list_8115 = _23split(_search_list_8115, 58, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_8116)){
            _4446 = SEQ_PTR(_subdir_8116)->length;
    }
    else {
        _4446 = 1;
    }
    if (_4446 <= 0)
    goto L9; // [312] 337

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_8116)){
            _4448 = SEQ_PTR(_subdir_8116)->length;
    }
    else {
        _4448 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_8116);
    _4449 = (int)*(((s1_ptr)_2)->base + _4448);
    if (binary_op_a(EQUALS, _4449, 47)){
        _4449 = NOVALUE;
        goto LA; // [325] 336
    }
    _4449 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_8116, _subdir_8116, 47);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_8115)){
            _4452 = SEQ_PTR(_search_list_8115)->length;
    }
    else {
        _4452 = 1;
    }
    {
        int _i_8195;
        _i_8195 = 1;
LB: 
        if (_i_8195 > _4452){
            goto LC; // [342] 465
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_8115);
        _4453 = (int)*(((s1_ptr)_2)->base + _i_8195);
        if (IS_SEQUENCE(_4453)){
                _4454 = SEQ_PTR(_4453)->length;
        }
        else {
            _4454 = 1;
        }
        _4453 = NOVALUE;
        if (_4454 != 0)
        goto LD; // [358] 367

        /** 			continue*/
        goto LE; // [364] 460
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_8115);
        _4456 = (int)*(((s1_ptr)_2)->base + _i_8195);
        if (IS_SEQUENCE(_4456)){
                _4457 = SEQ_PTR(_4456)->length;
        }
        else {
            _4457 = 1;
        }
        _2 = (int)SEQ_PTR(_4456);
        _4458 = (int)*(((s1_ptr)_2)->base + _4457);
        _4456 = NOVALUE;
        if (binary_op_a(EQUALS, _4458, 47)){
            _4458 = NOVALUE;
            goto LF; // [380] 399
        }
        _4458 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_8115);
        _4460 = (int)*(((s1_ptr)_2)->base + _i_8195);
        if (IS_SEQUENCE(_4460) && IS_ATOM(47)) {
            Append(&_4461, _4460, 47);
        }
        else if (IS_ATOM(_4460) && IS_SEQUENCE(47)) {
        }
        else {
            Concat((object_ptr)&_4461, _4460, 47);
            _4460 = NOVALUE;
        }
        _4460 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_8115);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_8115 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8195);
        _1 = *(int *)_2;
        *(int *)_2 = _4461;
        if( _1 != _4461 ){
            DeRef(_1);
        }
        _4461 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_8116)){
                _4462 = SEQ_PTR(_subdir_8116)->length;
        }
        else {
            _4462 = 1;
        }
        if (_4462 <= 0)
        goto L10; // [404] 423

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_8115);
        _4464 = (int)*(((s1_ptr)_2)->base + _i_8195);
        {
            int concat_list[3];

            concat_list[0] = _filename_8114;
            concat_list[1] = _subdir_8116;
            concat_list[2] = _4464;
            Concat_N((object_ptr)&_this_path_8118, concat_list, 3);
        }
        _4464 = NOVALUE;
        goto L11; // [420] 434
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_8115);
        _4466 = (int)*(((s1_ptr)_2)->base + _i_8195);
        if (IS_SEQUENCE(_4466) && IS_ATOM(_filename_8114)) {
        }
        else if (IS_ATOM(_4466) && IS_SEQUENCE(_filename_8114)) {
            Ref(_4466);
            Prepend(&_this_path_8118, _filename_8114, _4466);
        }
        else {
            Concat((object_ptr)&_this_path_8118, _4466, _filename_8114);
            _4466 = NOVALUE;
        }
        _4466 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_8118);
        _4468 = _11file_exists(_this_path_8118);
        if (_4468 == 0) {
            DeRef(_4468);
            _4468 = NOVALUE;
            goto L12; // [442] 458
        }
        else {
            if (!IS_ATOM_INT(_4468) && DBL_PTR(_4468)->dbl == 0.0){
                DeRef(_4468);
                _4468 = NOVALUE;
                goto L12; // [442] 458
            }
            DeRef(_4468);
            _4468 = NOVALUE;
        }
        DeRef(_4468);
        _4468 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_8118);
        _4469 = _11canonical_path(_this_path_8118, 0, 0);
        DeRefDS(_filename_8114);
        DeRefDS(_search_list_8115);
        DeRefDS(_subdir_8116);
        DeRef(_extra_paths_8117);
        DeRefDS(_this_path_8118);
        _4453 = NOVALUE;
        return _4469;
L12: 

        /** 	end for*/
LE: 
        _i_8195 = _i_8195 + 1;
        goto LB; // [460] 349
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_8115);
    DeRefDS(_subdir_8116);
    DeRef(_extra_paths_8117);
    DeRef(_this_path_8118);
    _4453 = NOVALUE;
    DeRef(_4469);
    _4469 = NOVALUE;
    return _filename_8114;
    ;
}
int locate_file() __attribute__ ((alias ("_11locate_file")));


int _11disk_metrics(int _disk_path_8221)
{
    int _result_8222 = NOVALUE;
    int _path_addr_8224 = NOVALUE;
    int _metric_addr_8225 = NOVALUE;
    int _size_of_disk_8226 = NOVALUE;
    int _bytes_per_cluster_8228 = NOVALUE;
    int _psrc_8229 = NOVALUE;
    int _ret_8230 = NOVALUE;
    int _psrcbuf_8231 = NOVALUE;
    int _stat_t_offset_8232 = NOVALUE;
    int _stat_buf_size_8233 = NOVALUE;
    int _xstat_1__tmp_at65_8238 = NOVALUE;
    int _xstat_inlined_xstat_at_65_8237 = NOVALUE;
    int _4484 = NOVALUE;
    int _4483 = NOVALUE;
    int _4482 = NOVALUE;
    int _4481 = NOVALUE;
    int _4480 = NOVALUE;
    int _4479 = NOVALUE;
    int _4476 = NOVALUE;
    int _4474 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence result = {0, 0, 0, 0} */
    _0 = _result_8222;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _result_8222 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	atom path_addr = 0*/
    _path_addr_8224 = 0;

    /** 	atom metric_addr = 0*/
    _metric_addr_8225 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		sequence size_of_disk = {0,0,0}*/
    _0 = _size_of_disk_8226;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _size_of_disk_8226 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		atom bytes_per_cluster*/

    /** 		atom psrc, ret, psrcbuf*/

    /** 		integer stat_t_offset, stat_buf_size*/

    /** 		ifdef LINUX then*/

    /** 			stat_t_offset = 48*/
    _stat_t_offset_8232 = 48;

    /** 			stat_buf_size = 88*/
    _stat_buf_size_8233 = 88;

    /** 		psrc    = machine:allocate_string(disk_path)*/
    Ref(_disk_path_8221);
    _0 = _psrc_8229;
    _psrc_8229 = _14allocate_string(_disk_path_8221, 0);
    DeRef(_0);

    /** 		psrcbuf = machine:allocate(stat_buf_size)*/
    _0 = _psrcbuf_8231;
    _psrcbuf_8231 = _14allocate(88, 0);
    DeRef(_0);

    /** 		ret = xstat(psrc,psrcbuf)*/

    /** 		return c_func(xStatFile, {3, psrc, psrcbuf})*/
    _0 = _xstat_1__tmp_at65_8238;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 3;
    Ref(_psrc_8229);
    *((int *)(_2+8)) = _psrc_8229;
    Ref(_psrcbuf_8231);
    *((int *)(_2+12)) = _psrcbuf_8231;
    _xstat_1__tmp_at65_8238 = MAKE_SEQ(_1);
    DeRef(_0);
    DeRef(_ret_8230);
    _ret_8230 = call_c(1, _11xStatFile_6975, _xstat_1__tmp_at65_8238);
    DeRef(_xstat_1__tmp_at65_8238);
    _xstat_1__tmp_at65_8238 = NOVALUE;

    /** 		bytes_per_cluster = peek4s(psrcbuf+stat_t_offset)*/
    if (IS_ATOM_INT(_psrcbuf_8231)) {
        _4474 = _psrcbuf_8231 + _stat_t_offset_8232;
        if ((long)((unsigned long)_4474 + (unsigned long)HIGH_BITS) >= 0) 
        _4474 = NewDouble((double)_4474);
    }
    else {
        _4474 = NewDouble(DBL_PTR(_psrcbuf_8231)->dbl + (double)_stat_t_offset_8232);
    }
    DeRef(_bytes_per_cluster_8228);
    if (IS_ATOM_INT(_4474)) {
        _bytes_per_cluster_8228 = *(unsigned long *)_4474;
        if (_bytes_per_cluster_8228 < MININT || _bytes_per_cluster_8228 > MAXINT)
        _bytes_per_cluster_8228 = NewDouble((double)(long)_bytes_per_cluster_8228);
    }
    else {
        _bytes_per_cluster_8228 = *(unsigned long *)(unsigned long)(DBL_PTR(_4474)->dbl);
        if (_bytes_per_cluster_8228 < MININT || _bytes_per_cluster_8228 > MAXINT)
        _bytes_per_cluster_8228 = NewDouble((double)(long)_bytes_per_cluster_8228);
    }
    DeRef(_4474);
    _4474 = NOVALUE;

    /** 		machine:free({psrcbuf, psrc})*/
    Ref(_psrc_8229);
    Ref(_psrcbuf_8231);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _psrcbuf_8231;
    ((int *)_2)[2] = _psrc_8229;
    _4476 = MAKE_SEQ(_1);
    _14free(_4476);
    _4476 = NOVALUE;

    /** 		if ret then*/
    if (_ret_8230 == 0) {
        goto L1; // [106] 116
    }
    else {
        if (!IS_ATOM_INT(_ret_8230) && DBL_PTR(_ret_8230)->dbl == 0.0){
            goto L1; // [106] 116
        }
    }

    /** 			return result */
    DeRef(_disk_path_8221);
    DeRef(_size_of_disk_8226);
    DeRef(_bytes_per_cluster_8228);
    DeRef(_psrc_8229);
    DeRef(_ret_8230);
    DeRef(_psrcbuf_8231);
    return _result_8222;
L1: 

    /** 		size_of_disk = disk_size(disk_path)*/
    Ref(_disk_path_8221);
    _0 = _size_of_disk_8226;
    _size_of_disk_8226 = _11disk_size(_disk_path_8221);
    DeRef(_0);

    /** 		result[BYTES_PER_SECTOR] = 512*/
    _2 = (int)SEQ_PTR(_result_8222);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_8222 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 512;
    DeRef(_1);

    /** 		result[SECTORS_PER_CLUSTER] = bytes_per_cluster / result[BYTES_PER_SECTOR]*/
    _2 = (int)SEQ_PTR(_result_8222);
    _4479 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_bytes_per_cluster_8228) && IS_ATOM_INT(_4479)) {
        _4480 = (_bytes_per_cluster_8228 % _4479) ? NewDouble((double)_bytes_per_cluster_8228 / _4479) : (_bytes_per_cluster_8228 / _4479);
    }
    else {
        _4480 = binary_op(DIVIDE, _bytes_per_cluster_8228, _4479);
    }
    _4479 = NOVALUE;
    _2 = (int)SEQ_PTR(_result_8222);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_8222 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4480;
    if( _1 != _4480 ){
        DeRef(_1);
    }
    _4480 = NOVALUE;

    /** 		result[TOTAL_NUMBER_OF_CLUSTERS] = size_of_disk[TOTAL_BYTES] / bytes_per_cluster*/
    _2 = (int)SEQ_PTR(_size_of_disk_8226);
    _4481 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4481) && IS_ATOM_INT(_bytes_per_cluster_8228)) {
        _4482 = (_4481 % _bytes_per_cluster_8228) ? NewDouble((double)_4481 / _bytes_per_cluster_8228) : (_4481 / _bytes_per_cluster_8228);
    }
    else {
        _4482 = binary_op(DIVIDE, _4481, _bytes_per_cluster_8228);
    }
    _4481 = NOVALUE;
    _2 = (int)SEQ_PTR(_result_8222);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_8222 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4482;
    if( _1 != _4482 ){
        DeRef(_1);
    }
    _4482 = NOVALUE;

    /** 		result[NUMBER_OF_FREE_CLUSTERS] = size_of_disk[FREE_BYTES] / bytes_per_cluster*/
    _2 = (int)SEQ_PTR(_size_of_disk_8226);
    _4483 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4483) && IS_ATOM_INT(_bytes_per_cluster_8228)) {
        _4484 = (_4483 % _bytes_per_cluster_8228) ? NewDouble((double)_4483 / _bytes_per_cluster_8228) : (_4483 / _bytes_per_cluster_8228);
    }
    else {
        _4484 = binary_op(DIVIDE, _4483, _bytes_per_cluster_8228);
    }
    _4483 = NOVALUE;
    _2 = (int)SEQ_PTR(_result_8222);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result_8222 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4484;
    if( _1 != _4484 ){
        DeRef(_1);
    }
    _4484 = NOVALUE;

    /** 	return result */
    DeRef(_disk_path_8221);
    DeRefDS(_size_of_disk_8226);
    DeRef(_bytes_per_cluster_8228);
    DeRef(_psrc_8229);
    DeRef(_ret_8230);
    DeRef(_psrcbuf_8231);
    return _result_8222;
    ;
}
int disk_metrics() __attribute__ ((alias ("_11disk_metrics")));


int _11disk_size(int _disk_path_8254)
{
    int _disk_size_8255 = NOVALUE;
    int _temph_8257 = NOVALUE;
    int _tempfile_8258 = NOVALUE;
    int _data_8259 = NOVALUE;
    int _filesys_8260 = NOVALUE;
    int _get_inlined_get_at_147_8283 = NOVALUE;
    int _get_inlined_get_at_176_8288 = NOVALUE;
    int _get_inlined_get_at_205_8292 = NOVALUE;
    int _4509 = NOVALUE;
    int _4508 = NOVALUE;
    int _4507 = NOVALUE;
    int _4506 = NOVALUE;
    int _4505 = NOVALUE;
    int _4503 = NOVALUE;
    int _4499 = NOVALUE;
    int _4493 = NOVALUE;
    int _4488 = NOVALUE;
    int _4487 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence disk_size = {0,0,0, disk_path}*/
    _0 = _disk_size_8255;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    Ref(_disk_path_8254);
    *((int *)(_2+16)) = _disk_path_8254;
    _disk_size_8255 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		integer temph*/

    /** 		sequence tempfile*/

    /** 		object data*/

    /** 		sequence filesys = ""*/
    RefDS(_5);
    DeRef(_filesys_8260);
    _filesys_8260 = _5;

    /** 		tempfile = "/tmp/eudf" & sprintf("%d", rand(1000)) & ".tmp"*/
    _4487 = good_rand() % ((unsigned)1000) + 1;
    _4488 = EPrintf(-9999999, _919, _4487);
    _4487 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _4489;
        concat_list[1] = _4488;
        concat_list[2] = _4486;
        Concat_N((object_ptr)&_tempfile_8258, concat_list, 3);
    }
    DeRefDS(_4488);
    _4488 = NOVALUE;

    /** 		system("df -k "&disk_path&" > "&tempfile, 2)*/
    {
        int concat_list[4];

        concat_list[0] = _tempfile_8258;
        concat_list[1] = _4492;
        concat_list[2] = _disk_path_8254;
        concat_list[3] = _4491;
        Concat_N((object_ptr)&_4493, concat_list, 4);
    }
    system_call(_4493, 2);
    DeRefDS(_4493);
    _4493 = NOVALUE;

    /** 		temph = open(tempfile, "r")*/
    _temph_8257 = EOpen(_tempfile_8258, _1217, 0);

    /** 		if temph = -1 then*/
    if (_temph_8257 != -1)
    goto L1; // [61] 72

    /** 			return disk_size*/
    DeRef(_disk_path_8254);
    DeRefDSi(_tempfile_8258);
    DeRef(_data_8259);
    DeRefDS(_filesys_8260);
    return _disk_size_8255;
L1: 

    /** 		data = gets(temph)*/
    DeRef(_data_8259);
    _data_8259 = EGets(_temph_8257);

    /** 		while 1 do */
L2: 

    /** 			data = getc(temph)*/
    DeRef(_data_8259);
    if (_temph_8257 != last_r_file_no) {
        last_r_file_ptr = which_file(_temph_8257, EF_READ);
        last_r_file_no = _temph_8257;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _data_8259 = getc((FILE*)xstdin);
        }
        else
        _data_8259 = getc(last_r_file_ptr);
    }
    else
    _data_8259 = getc(last_r_file_ptr);

    /** 			if find(data," \t\r\n") then*/
    _4499 = find_from(_data_8259, _4498, 1);
    if (_4499 == 0)
    {
        _4499 = NOVALUE;
        goto L3; // [94] 102
    }
    else{
        _4499 = NOVALUE;
    }

    /** 				exit*/
    goto L4; // [99] 144
L3: 

    /** 			if data = -1 then*/
    if (binary_op_a(NOTEQ, _data_8259, -1)){
        goto L5; // [104] 133
    }

    /** 				close(temph)*/
    EClose(_temph_8257);

    /** 				temph = delete_file(tempfile)*/
    RefDS(_tempfile_8258);
    _temph_8257 = _11delete_file(_tempfile_8258);
    if (!IS_ATOM_INT(_temph_8257)) {
        _1 = (long)(DBL_PTR(_temph_8257)->dbl);
        DeRefDS(_temph_8257);
        _temph_8257 = _1;
    }

    /** 				disk_size[4] = filesys*/
    RefDS(_filesys_8260);
    _2 = (int)SEQ_PTR(_disk_size_8255);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8255 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _filesys_8260;
    DeRef(_1);

    /** 				return disk_size*/
    DeRef(_disk_path_8254);
    DeRefDSi(_tempfile_8258);
    DeRef(_data_8259);
    DeRefDS(_filesys_8260);
    return _disk_size_8255;
L5: 

    /** 			filesys &= data*/
    if (IS_SEQUENCE(_filesys_8260) && IS_ATOM(_data_8259)) {
        Ref(_data_8259);
        Append(&_filesys_8260, _filesys_8260, _data_8259);
    }
    else if (IS_ATOM(_filesys_8260) && IS_SEQUENCE(_data_8259)) {
    }
    else {
        Concat((object_ptr)&_filesys_8260, _filesys_8260, _data_8259);
    }

    /** 		end while*/
    goto L2; // [141] 82
L4: 

    /** 		data = stdget:get(temph)*/
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _0 = _data_8259;
    _data_8259 = _17get_value(_temph_8257, 0, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);

    /** 		disk_size[TOTAL_BYTES] = data[2] * 1024*/
    _2 = (int)SEQ_PTR(_data_8259);
    _4503 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4503)) {
        if (_4503 == (short)_4503)
        _4505 = _4503 * 1024;
        else
        _4505 = NewDouble(_4503 * (double)1024);
    }
    else {
        _4505 = binary_op(MULTIPLY, _4503, 1024);
    }
    _4503 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8255);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8255 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4505;
    if( _1 != _4505 ){
        DeRef(_1);
    }
    _4505 = NOVALUE;

    /** 		data = stdget:get(temph)*/
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _0 = _data_8259;
    _data_8259 = _17get_value(_temph_8257, 0, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);

    /** 		disk_size[USED_BYTES] = data[2] * 1024*/
    _2 = (int)SEQ_PTR(_data_8259);
    _4506 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4506)) {
        if (_4506 == (short)_4506)
        _4507 = _4506 * 1024;
        else
        _4507 = NewDouble(_4506 * (double)1024);
    }
    else {
        _4507 = binary_op(MULTIPLY, _4506, 1024);
    }
    _4506 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8255);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8255 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4507;
    if( _1 != _4507 ){
        DeRef(_1);
    }
    _4507 = NOVALUE;

    /** 		data = stdget:get(temph)*/
    if (!IS_ATOM_INT(_17GET_SHORT_ANSWER_3238)) {
        _1 = (long)(DBL_PTR(_17GET_SHORT_ANSWER_3238)->dbl);
        DeRefDS(_17GET_SHORT_ANSWER_3238);
        _17GET_SHORT_ANSWER_3238 = _1;
    }

    /** 	return get_value(file, offset, answer)*/
    _0 = _data_8259;
    _data_8259 = _17get_value(_temph_8257, 0, _17GET_SHORT_ANSWER_3238);
    DeRef(_0);

    /** 		disk_size[FREE_BYTES] = data[2] * 1024*/
    _2 = (int)SEQ_PTR(_data_8259);
    _4508 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_4508)) {
        if (_4508 == (short)_4508)
        _4509 = _4508 * 1024;
        else
        _4509 = NewDouble(_4508 * (double)1024);
    }
    else {
        _4509 = binary_op(MULTIPLY, _4508, 1024);
    }
    _4508 = NOVALUE;
    _2 = (int)SEQ_PTR(_disk_size_8255);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8255 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4509;
    if( _1 != _4509 ){
        DeRef(_1);
    }
    _4509 = NOVALUE;

    /** 		disk_size[4] = filesys*/
    RefDS(_filesys_8260);
    _2 = (int)SEQ_PTR(_disk_size_8255);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _disk_size_8255 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _filesys_8260;
    DeRef(_1);

    /** 		close(temph)*/
    EClose(_temph_8257);

    /** 		temph = delete_file(tempfile)*/
    RefDS(_tempfile_8258);
    _temph_8257 = _11delete_file(_tempfile_8258);
    if (!IS_ATOM_INT(_temph_8257)) {
        _1 = (long)(DBL_PTR(_temph_8257)->dbl);
        DeRefDS(_temph_8257);
        _temph_8257 = _1;
    }

    /** 	return disk_size */
    DeRef(_disk_path_8254);
    DeRefDSi(_tempfile_8258);
    DeRef(_data_8259);
    DeRefDS(_filesys_8260);
    return _disk_size_8255;
    ;
}
int disk_size() __attribute__ ((alias ("_11disk_size")));


int _11count_files(int _orig_path_8299, int _dir_info_8300, int _inst_8301)
{
    int _pos_8302 = NOVALUE;
    int _ext_8303 = NOVALUE;
    int _fileext_inlined_fileext_at_218_8344 = NOVALUE;
    int _data_inlined_fileext_at_218_8343 = NOVALUE;
    int _path_inlined_fileext_at_215_8342 = NOVALUE;
    int _4573 = NOVALUE;
    int _4572 = NOVALUE;
    int _4571 = NOVALUE;
    int _4569 = NOVALUE;
    int _4568 = NOVALUE;
    int _4567 = NOVALUE;
    int _4566 = NOVALUE;
    int _4564 = NOVALUE;
    int _4563 = NOVALUE;
    int _4561 = NOVALUE;
    int _4560 = NOVALUE;
    int _4559 = NOVALUE;
    int _4558 = NOVALUE;
    int _4557 = NOVALUE;
    int _4556 = NOVALUE;
    int _4555 = NOVALUE;
    int _4553 = NOVALUE;
    int _4552 = NOVALUE;
    int _4550 = NOVALUE;
    int _4549 = NOVALUE;
    int _4548 = NOVALUE;
    int _4547 = NOVALUE;
    int _4546 = NOVALUE;
    int _4545 = NOVALUE;
    int _4544 = NOVALUE;
    int _4543 = NOVALUE;
    int _4542 = NOVALUE;
    int _4541 = NOVALUE;
    int _4540 = NOVALUE;
    int _4539 = NOVALUE;
    int _4538 = NOVALUE;
    int _4536 = NOVALUE;
    int _4535 = NOVALUE;
    int _4534 = NOVALUE;
    int _4533 = NOVALUE;
    int _4531 = NOVALUE;
    int _4530 = NOVALUE;
    int _4529 = NOVALUE;
    int _4528 = NOVALUE;
    int _4527 = NOVALUE;
    int _4526 = NOVALUE;
    int _4525 = NOVALUE;
    int _4523 = NOVALUE;
    int _4522 = NOVALUE;
    int _4521 = NOVALUE;
    int _4520 = NOVALUE;
    int _4519 = NOVALUE;
    int _4518 = NOVALUE;
    int _4515 = NOVALUE;
    int _4514 = NOVALUE;
    int _4513 = NOVALUE;
    int _4512 = NOVALUE;
    int _4511 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_8302 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_8299);
    DeRefDS(_orig_path_8299);
    _orig_path_8299 = _orig_path_8299;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4511 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4511 == _3780)
    _4512 = 1;
    else if (IS_ATOM_INT(_4511) && IS_ATOM_INT(_3780))
    _4512 = 0;
    else
    _4512 = (compare(_4511, _3780) == 0);
    _4511 = NOVALUE;
    if (_4512 == 0)
    {
        _4512 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _4512 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8299);
    DeRefDS(_dir_info_8300);
    DeRefDS(_inst_8301);
    DeRef(_ext_8303);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4513 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4513 == _3847)
    _4514 = 1;
    else if (IS_ATOM_INT(_4513) && IS_ATOM_INT(_3847))
    _4514 = 0;
    else
    _4514 = (compare(_4513, _3847) == 0);
    _4513 = NOVALUE;
    if (_4514 == 0)
    {
        _4514 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _4514 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_8299);
    DeRefDS(_dir_info_8300);
    DeRefDS(_inst_8301);
    DeRef(_ext_8303);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4515 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _4515, 0)){
        _4515 = NOVALUE;
        goto L3; // [65] 112
    }
    _4515 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4518 = (int)*(((s1_ptr)_2)->base + 2);
    _4519 = find_from(104, _4518, 1);
    _4518 = NOVALUE;
    if (_4519 == 0)
    {
        _4519 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _4519 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8299);
    DeRefDS(_dir_info_8300);
    DeRefDS(_inst_8301);
    DeRef(_ext_8303);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4520 = (int)*(((s1_ptr)_2)->base + 2);
    _4521 = find_from(115, _4520, 1);
    _4520 = NOVALUE;
    if (_4521 == 0)
    {
        _4521 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _4521 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_8299);
    DeRefDS(_dir_info_8300);
    DeRefDS(_inst_8301);
    DeRef(_ext_8303);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4522 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4522))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4522)->dbl));
    else
    _3 = (int)(_4522 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4525 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4526 = (int)*(((s1_ptr)_2)->base + 3);
    _4523 = NOVALUE;
    if (IS_ATOM_INT(_4526) && IS_ATOM_INT(_4525)) {
        _4527 = _4526 + _4525;
        if ((long)((unsigned long)_4527 + (unsigned long)HIGH_BITS) >= 0) 
        _4527 = NewDouble((double)_4527);
    }
    else {
        _4527 = binary_op(PLUS, _4526, _4525);
    }
    _4526 = NOVALUE;
    _4525 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4527;
    if( _1 != _4527 ){
        DeRef(_1);
    }
    _4527 = NOVALUE;
    _4523 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4528 = (int)*(((s1_ptr)_2)->base + 2);
    _4529 = find_from(100, _4528, 1);
    _4528 = NOVALUE;
    if (_4529 == 0)
    {
        _4529 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _4529 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4530 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4530))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4530)->dbl));
    else
    _3 = (int)(_4530 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4533 = (int)*(((s1_ptr)_2)->base + 1);
    _4531 = NOVALUE;
    if (IS_ATOM_INT(_4533)) {
        _4534 = _4533 + 1;
        if (_4534 > MAXINT){
            _4534 = NewDouble((double)_4534);
        }
    }
    else
    _4534 = binary_op(PLUS, 1, _4533);
    _4533 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4534;
    if( _1 != _4534 ){
        DeRef(_1);
    }
    _4534 = NOVALUE;
    _4531 = NOVALUE;
    goto L7; // [180] 460
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4535 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4535))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4535)->dbl));
    else
    _3 = (int)(_4535 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4538 = (int)*(((s1_ptr)_2)->base + 2);
    _4536 = NOVALUE;
    if (IS_ATOM_INT(_4538)) {
        _4539 = _4538 + 1;
        if (_4539 > MAXINT){
            _4539 = NewDouble((double)_4539);
        }
    }
    else
    _4539 = binary_op(PLUS, 1, _4538);
    _4538 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4539;
    if( _1 != _4539 ){
        DeRef(_1);
    }
    _4539 = NOVALUE;
    _4536 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(dir_info[D_NAME])*/
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4540 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4540);
    DeRef(_path_inlined_fileext_at_215_8342);
    _path_inlined_fileext_at_215_8342 = _4540;
    _4540 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_215_8342);
    _0 = _data_inlined_fileext_at_218_8343;
    _data_inlined_fileext_at_218_8343 = _11pathinfo(_path_inlined_fileext_at_215_8342, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_8303);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_218_8343);
    _ext_8303 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_8303);
    DeRef(_path_inlined_fileext_at_215_8342);
    _path_inlined_fileext_at_215_8342 = NOVALUE;
    DeRef(_data_inlined_fileext_at_218_8343);
    _data_inlined_fileext_at_218_8343 = NOVALUE;

    /** 		pos = 0*/
    _pos_8302 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4541 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!IS_ATOM_INT(_4541)){
        _4542 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4541)->dbl));
    }
    else{
        _4542 = (int)*(((s1_ptr)_2)->base + _4541);
    }
    _2 = (int)SEQ_PTR(_4542);
    _4543 = (int)*(((s1_ptr)_2)->base + 4);
    _4542 = NOVALUE;
    if (IS_SEQUENCE(_4543)){
            _4544 = SEQ_PTR(_4543)->length;
    }
    else {
        _4544 = 1;
    }
    _4543 = NOVALUE;
    {
        int _i_8346;
        _i_8346 = 1;
L8: 
        if (_i_8346 > _4544){
            goto L9; // [265] 322
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_8301);
        _4545 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_11file_counters_8296);
        if (!IS_ATOM_INT(_4545)){
            _4546 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4545)->dbl));
        }
        else{
            _4546 = (int)*(((s1_ptr)_2)->base + _4545);
        }
        _2 = (int)SEQ_PTR(_4546);
        _4547 = (int)*(((s1_ptr)_2)->base + 4);
        _4546 = NOVALUE;
        _2 = (int)SEQ_PTR(_4547);
        _4548 = (int)*(((s1_ptr)_2)->base + _i_8346);
        _4547 = NOVALUE;
        _2 = (int)SEQ_PTR(_4548);
        _4549 = (int)*(((s1_ptr)_2)->base + 1);
        _4548 = NOVALUE;
        if (_4549 == _ext_8303)
        _4550 = 1;
        else if (IS_ATOM_INT(_4549) && IS_ATOM_INT(_ext_8303))
        _4550 = 0;
        else
        _4550 = (compare(_4549, _ext_8303) == 0);
        _4549 = NOVALUE;
        if (_4550 == 0)
        {
            _4550 = NOVALUE;
            goto LA; // [302] 315
        }
        else{
            _4550 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_8302 = _i_8346;

        /** 				exit*/
        goto L9; // [312] 322
LA: 

        /** 		end for*/
        _i_8346 = _i_8346 + 1;
        goto L8; // [317] 272
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_8302 != 0)
    goto LB; // [324] 385

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4552 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4552))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4552)->dbl));
    else
    _3 = (int)(_4552 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_8303);
    *((int *)(_2+4)) = _ext_8303;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _4555 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4555;
    _4556 = MAKE_SEQ(_1);
    _4555 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4557 = (int)*(((s1_ptr)_2)->base + 4);
    _4553 = NOVALUE;
    if (IS_SEQUENCE(_4557) && IS_ATOM(_4556)) {
    }
    else if (IS_ATOM(_4557) && IS_SEQUENCE(_4556)) {
        Ref(_4557);
        Prepend(&_4558, _4556, _4557);
    }
    else {
        Concat((object_ptr)&_4558, _4557, _4556);
        _4557 = NOVALUE;
    }
    _4557 = NOVALUE;
    DeRefDS(_4556);
    _4556 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4558;
    if( _1 != _4558 ){
        DeRef(_1);
    }
    _4558 = NOVALUE;
    _4553 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4559 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!IS_ATOM_INT(_4559)){
        _4560 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_4559)->dbl));
    }
    else{
        _4560 = (int)*(((s1_ptr)_2)->base + _4559);
    }
    _2 = (int)SEQ_PTR(_4560);
    _4561 = (int)*(((s1_ptr)_2)->base + 4);
    _4560 = NOVALUE;
    if (IS_SEQUENCE(_4561)){
            _pos_8302 = SEQ_PTR(_4561)->length;
    }
    else {
        _pos_8302 = 1;
    }
    _4561 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4563 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4563))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4563)->dbl));
    else
    _3 = (int)(_4563 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4564 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8302 + ((s1_ptr)_2)->base);
    _4564 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4566 = (int)*(((s1_ptr)_2)->base + 2);
    _4564 = NOVALUE;
    if (IS_ATOM_INT(_4566)) {
        _4567 = _4566 + 1;
        if (_4567 > MAXINT){
            _4567 = NewDouble((double)_4567);
        }
    }
    else
    _4567 = binary_op(PLUS, 1, _4566);
    _4566 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4567;
    if( _1 != _4567 ){
        DeRef(_1);
    }
    _4567 = NOVALUE;
    _4564 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_8301);
    _4568 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _11file_counters_8296 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_4568))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_4568)->dbl));
    else
    _3 = (int)(_4568 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _4569 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_8302 + ((s1_ptr)_2)->base);
    _4569 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_8300);
    _4571 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _4572 = (int)*(((s1_ptr)_2)->base + 3);
    _4569 = NOVALUE;
    if (IS_ATOM_INT(_4572) && IS_ATOM_INT(_4571)) {
        _4573 = _4572 + _4571;
        if ((long)((unsigned long)_4573 + (unsigned long)HIGH_BITS) >= 0) 
        _4573 = NewDouble((double)_4573);
    }
    else {
        _4573 = binary_op(PLUS, _4572, _4571);
    }
    _4572 = NOVALUE;
    _4571 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _4573;
    if( _1 != _4573 ){
        DeRef(_1);
    }
    _4573 = NOVALUE;
    _4569 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_8299);
    DeRefDS(_dir_info_8300);
    DeRefDS(_inst_8301);
    DeRef(_ext_8303);
    _4522 = NOVALUE;
    _4530 = NOVALUE;
    _4535 = NOVALUE;
    _4541 = NOVALUE;
    _4543 = NOVALUE;
    _4545 = NOVALUE;
    _4552 = NOVALUE;
    _4559 = NOVALUE;
    _4561 = NOVALUE;
    _4563 = NOVALUE;
    _4568 = NOVALUE;
    return 0;
    ;
}


int _11dir_size(int _dir_path_8384, int _count_all_8385)
{
    int _fc_8386 = NOVALUE;
    int _4588 = NOVALUE;
    int _4587 = NOVALUE;
    int _4585 = NOVALUE;
    int _4584 = NOVALUE;
    int _4582 = NOVALUE;
    int _4581 = NOVALUE;
    int _4580 = NOVALUE;
    int _4579 = NOVALUE;
    int _4578 = NOVALUE;
    int _4577 = NOVALUE;
    int _4574 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_count_all_8385)) {
        _1 = (long)(DBL_PTR(_count_all_8385)->dbl);
        DeRefDS(_count_all_8385);
        _count_all_8385 = _1;
    }

    /** 	file_counters = append(file_counters, {0,0,0,{}})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    RefDS(_5);
    *((int *)(_2+16)) = _5;
    _4574 = MAKE_SEQ(_1);
    RefDS(_4574);
    Append(&_11file_counters_8296, _11file_counters_8296, _4574);
    DeRefDS(_4574);
    _4574 = NOVALUE;

    /** 	walk_dir(dir_path, {routine_id("count_files"), {count_all, length(file_counters)}}, 0)*/
    _4577 = CRoutineId(360, 11, _4576);
    if (IS_SEQUENCE(_11file_counters_8296)){
            _4578 = SEQ_PTR(_11file_counters_8296)->length;
    }
    else {
        _4578 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _count_all_8385;
    ((int *)_2)[2] = _4578;
    _4579 = MAKE_SEQ(_1);
    _4578 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4577;
    ((int *)_2)[2] = _4579;
    _4580 = MAKE_SEQ(_1);
    _4579 = NOVALUE;
    _4577 = NOVALUE;
    RefDS(_dir_path_8384);
    _4581 = _11walk_dir(_dir_path_8384, _4580, 0, -99999);
    _4580 = NOVALUE;

    /** 	fc = file_counters[$]*/
    if (IS_SEQUENCE(_11file_counters_8296)){
            _4582 = SEQ_PTR(_11file_counters_8296)->length;
    }
    else {
        _4582 = 1;
    }
    DeRef(_fc_8386);
    _2 = (int)SEQ_PTR(_11file_counters_8296);
    _fc_8386 = (int)*(((s1_ptr)_2)->base + _4582);
    RefDS(_fc_8386);

    /** 	file_counters = file_counters[1 .. $-1]*/
    if (IS_SEQUENCE(_11file_counters_8296)){
            _4584 = SEQ_PTR(_11file_counters_8296)->length;
    }
    else {
        _4584 = 1;
    }
    _4585 = _4584 - 1;
    _4584 = NOVALUE;
    rhs_slice_target = (object_ptr)&_11file_counters_8296;
    RHS_Slice(_11file_counters_8296, 1, _4585);

    /** 	fc[COUNT_TYPES] = stdsort:sort(fc[COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_fc_8386);
    _4587 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_4587);
    _4588 = _24sort(_4587, 1);
    _4587 = NOVALUE;
    _2 = (int)SEQ_PTR(_fc_8386);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _fc_8386 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _4588;
    if( _1 != _4588 ){
        DeRef(_1);
    }
    _4588 = NOVALUE;

    /** 	return fc*/
    DeRefDS(_dir_path_8384);
    _4585 = NOVALUE;
    DeRef(_4581);
    _4581 = NOVALUE;
    return _fc_8386;
    ;
}
int dir_size() __attribute__ ((alias ("_11dir_size")));


int _11temp_file(int _temp_location_8404, int _temp_prefix_8405, int _temp_extn_8406, int _reserve_temp_8408)
{
    int _randname_8409 = NOVALUE;
    int _envtmp_8413 = NOVALUE;
    int _tdir_8432 = NOVALUE;
    int _4627 = NOVALUE;
    int _4625 = NOVALUE;
    int _4623 = NOVALUE;
    int _4621 = NOVALUE;
    int _4619 = NOVALUE;
    int _4618 = NOVALUE;
    int _4617 = NOVALUE;
    int _4613 = NOVALUE;
    int _4612 = NOVALUE;
    int _4611 = NOVALUE;
    int _4610 = NOVALUE;
    int _4607 = NOVALUE;
    int _4606 = NOVALUE;
    int _4605 = NOVALUE;
    int _4600 = NOVALUE;
    int _4598 = NOVALUE;
    int _4594 = NOVALUE;
    int _4590 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_reserve_temp_8408)) {
        _1 = (long)(DBL_PTR(_reserve_temp_8408)->dbl);
        DeRefDS(_reserve_temp_8408);
        _reserve_temp_8408 = _1;
    }

    /** 	if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_8404)){
            _4590 = SEQ_PTR(_temp_location_8404)->length;
    }
    else {
        _4590 = 1;
    }
    if (_4590 != 0)
    goto L1; // [14] 67

    /** 		object envtmp*/

    /** 		envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_8413);
    _envtmp_8413 = EGetEnv(_4592);

    /** 		if atom(envtmp) then*/
    _4594 = IS_ATOM(_envtmp_8413);
    if (_4594 == 0)
    {
        _4594 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _4594 = NOVALUE;
    }

    /** 			envtmp = getenv("TMP")*/
    DeRefi(_envtmp_8413);
    _envtmp_8413 = EGetEnv(_4595);
L2: 

    /** 		ifdef WINDOWS then			*/

    /** 			if atom(envtmp) then*/
    _4598 = IS_ATOM(_envtmp_8413);
    if (_4598 == 0)
    {
        _4598 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _4598 = NOVALUE;
    }

    /** 				envtmp = "/tmp/"*/
    RefDS(_4599);
    DeRefi(_envtmp_8413);
    _envtmp_8413 = _4599;
L3: 

    /** 		temp_location = envtmp*/
    Ref(_envtmp_8413);
    DeRefDS(_temp_location_8404);
    _temp_location_8404 = _envtmp_8413;
    DeRefi(_envtmp_8413);
    _envtmp_8413 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** 		switch file_type(temp_location) do*/
    RefDS(_temp_location_8404);
    _4600 = _11file_type(_temp_location_8404);
    if (IS_SEQUENCE(_4600) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_4600)){
        if( (DBL_PTR(_4600)->dbl != (double) ((int) DBL_PTR(_4600)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (int) DBL_PTR(_4600)->dbl;
    }
    else {
        _0 = _4600;
    };
    DeRef(_4600);
    _4600 = NOVALUE;
    switch ( _0 ){ 

        /** 			case FILETYPE_FILE then*/
        case 1:

        /** 				temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_8404);
        _0 = _temp_location_8404;
        _temp_location_8404 = _11dirname(_temp_location_8404, 1);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** 			case FILETYPE_DIRECTORY then*/
        case 2:

        /** 				temp_location = temp_location*/
        RefDS(_temp_location_8404);
        DeRefDS(_temp_location_8404);
        _temp_location_8404 = _temp_location_8404;
        goto L6; // [104] 160

        /** 			case FILETYPE_NOT_FOUND then*/
        case 0:

        /** 				object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_8404);
        _0 = _tdir_8432;
        _tdir_8432 = _11dirname(_temp_location_8404, 1);
        DeRef(_0);

        /** 				if file_exists(tdir) then*/
        Ref(_tdir_8432);
        _4605 = _11file_exists(_tdir_8432);
        if (_4605 == 0) {
            DeRef(_4605);
            _4605 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_4605) && DBL_PTR(_4605)->dbl == 0.0){
                DeRef(_4605);
                _4605 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_4605);
            _4605 = NOVALUE;
        }
        DeRef(_4605);
        _4605 = NOVALUE;

        /** 					temp_location = tdir*/
        Ref(_tdir_8432);
        DeRefDS(_temp_location_8404);
        _temp_location_8404 = _tdir_8432;
        goto L8; // [133] 144
L7: 

        /** 					temp_location = "."*/
        RefDS(_3780);
        DeRefDS(_temp_location_8404);
        _temp_location_8404 = _3780;
L8: 
        DeRef(_tdir_8432);
        _tdir_8432 = NOVALUE;
        goto L6; // [146] 160

        /** 			case else*/
        default:
L5: 

        /** 				temp_location = "."*/
        RefDS(_3780);
        DeRefDS(_temp_location_8404);
        _temp_location_8404 = _3780;
    ;}L6: 
L4: 

    /** 	if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_8404)){
            _4606 = SEQ_PTR(_temp_location_8404)->length;
    }
    else {
        _4606 = 1;
    }
    _2 = (int)SEQ_PTR(_temp_location_8404);
    _4607 = (int)*(((s1_ptr)_2)->base + _4606);
    if (binary_op_a(EQUALS, _4607, 47)){
        _4607 = NOVALUE;
        goto L9; // [170] 181
    }
    _4607 = NOVALUE;

    /** 		temp_location &= SLASH*/
    Append(&_temp_location_8404, _temp_location_8404, 47);
L9: 

    /** 	if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_8406)){
            _4610 = SEQ_PTR(_temp_extn_8406)->length;
    }
    else {
        _4610 = 1;
    }
    if (_4610 == 0) {
        goto LA; // [186] 209
    }
    _2 = (int)SEQ_PTR(_temp_extn_8406);
    _4612 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_4612)) {
        _4613 = (_4612 != 46);
    }
    else {
        _4613 = binary_op(NOTEQ, _4612, 46);
    }
    _4612 = NOVALUE;
    if (_4613 == 0) {
        DeRef(_4613);
        _4613 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_4613) && DBL_PTR(_4613)->dbl == 0.0){
            DeRef(_4613);
            _4613 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_4613);
        _4613 = NOVALUE;
    }
    DeRef(_4613);
    _4613 = NOVALUE;

    /** 		temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_8406, _temp_extn_8406, 46);
LA: 

    /** 	while 1 do*/
LB: 

    /** 		randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _4617 = good_rand() % ((unsigned)1000000) + 1;
    _4618 = _4617 - 1;
    _4617 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_temp_location_8404);
    *((int *)(_2+4)) = _temp_location_8404;
    RefDS(_temp_prefix_8405);
    *((int *)(_2+8)) = _temp_prefix_8405;
    *((int *)(_2+12)) = _4618;
    RefDS(_temp_extn_8406);
    *((int *)(_2+16)) = _temp_extn_8406;
    _4619 = MAKE_SEQ(_1);
    _4618 = NOVALUE;
    DeRefi(_randname_8409);
    _randname_8409 = EPrintf(-9999999, _4615, _4619);
    DeRefDS(_4619);
    _4619 = NOVALUE;

    /** 		if not file_exists( randname ) then*/
    RefDS(_randname_8409);
    _4621 = _11file_exists(_randname_8409);
    if (IS_ATOM_INT(_4621)) {
        if (_4621 != 0){
            DeRef(_4621);
            _4621 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_4621)->dbl != 0.0){
            DeRef(_4621);
            _4621 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_4621);
    _4621 = NOVALUE;

    /** 			exit*/
    goto LC; // [245] 253

    /** 	end while*/
    goto LB; // [250] 214
LC: 

    /** 	if reserve_temp then*/
    if (_reserve_temp_8408 == 0)
    {
        goto LD; // [255] 298
    }
    else{
    }

    /** 		if not file_exists(temp_location) then*/
    RefDS(_temp_location_8404);
    _4623 = _11file_exists(_temp_location_8404);
    if (IS_ATOM_INT(_4623)) {
        if (_4623 != 0){
            DeRef(_4623);
            _4623 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_4623)->dbl != 0.0){
            DeRef(_4623);
            _4623 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_4623);
    _4623 = NOVALUE;

    /** 			if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_8404);
    _4625 = _11create_directory(_temp_location_8404, 448, 1);
    if (binary_op_a(NOTEQ, _4625, 0)){
        DeRef(_4625);
        _4625 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_4625);
    _4625 = NOVALUE;

    /** 				return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_8404);
    DeRefDS(_temp_prefix_8405);
    DeRefDS(_temp_extn_8406);
    DeRefi(_randname_8409);
    return _5;
LF: 
LE: 

    /** 		io:write_file(randname, "")*/
    RefDS(_randname_8409);
    RefDS(_5);
    _4627 = _18write_file(_randname_8409, _5, 1);
LD: 

    /** 	return randname*/
    DeRefDS(_temp_location_8404);
    DeRefDS(_temp_prefix_8405);
    DeRefDS(_temp_extn_8406);
    DeRef(_4627);
    _4627 = NOVALUE;
    return _randname_8409;
    ;
}
int temp_file() __attribute__ ((alias ("_11temp_file")));


int _11checksum(int _filename_8469, int _size_8470, int _usename_8471, int _return_text_8472)
{
    int _fn_8473 = NOVALUE;
    int _cs_8474 = NOVALUE;
    int _hits_8475 = NOVALUE;
    int _ix_8476 = NOVALUE;
    int _jx_8477 = NOVALUE;
    int _fx_8478 = NOVALUE;
    int _data_8479 = NOVALUE;
    int _nhit_8480 = NOVALUE;
    int _nmiss_8481 = NOVALUE;
    int _cs_text_8553 = NOVALUE;
    int _4687 = NOVALUE;
    int _4685 = NOVALUE;
    int _4684 = NOVALUE;
    int _4682 = NOVALUE;
    int _4680 = NOVALUE;
    int _4679 = NOVALUE;
    int _4678 = NOVALUE;
    int _4677 = NOVALUE;
    int _4676 = NOVALUE;
    int _4674 = NOVALUE;
    int _4672 = NOVALUE;
    int _4670 = NOVALUE;
    int _4669 = NOVALUE;
    int _4668 = NOVALUE;
    int _4667 = NOVALUE;
    int _4666 = NOVALUE;
    int _4665 = NOVALUE;
    int _4664 = NOVALUE;
    int _4662 = NOVALUE;
    int _4659 = NOVALUE;
    int _4657 = NOVALUE;
    int _4656 = NOVALUE;
    int _4655 = NOVALUE;
    int _4654 = NOVALUE;
    int _4653 = NOVALUE;
    int _4650 = NOVALUE;
    int _4649 = NOVALUE;
    int _4648 = NOVALUE;
    int _4647 = NOVALUE;
    int _4645 = NOVALUE;
    int _4642 = NOVALUE;
    int _4640 = NOVALUE;
    int _4636 = NOVALUE;
    int _4635 = NOVALUE;
    int _4634 = NOVALUE;
    int _4633 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_8470)) {
        _1 = (long)(DBL_PTR(_size_8470)->dbl);
        DeRefDS(_size_8470);
        _size_8470 = _1;
    }
    if (!IS_ATOM_INT(_usename_8471)) {
        _1 = (long)(DBL_PTR(_usename_8471)->dbl);
        DeRefDS(_usename_8471);
        _usename_8471 = _1;
    }
    if (!IS_ATOM_INT(_return_text_8472)) {
        _1 = (long)(DBL_PTR(_return_text_8472)->dbl);
        DeRefDS(_return_text_8472);
        _return_text_8472 = _1;
    }

    /** 	if size <= 0 then*/
    if (_size_8470 > 0)
    goto L1; // [11] 22

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_filename_8469);
    DeRef(_cs_8474);
    DeRef(_hits_8475);
    DeRef(_jx_8477);
    DeRef(_fx_8478);
    DeRefi(_data_8479);
    return _5;
L1: 

    /** 	fn = open(filename, "rb")*/
    _fn_8473 = EOpen(_filename_8469, _1284, 0);

    /** 	if fn = -1 then*/
    if (_fn_8473 != -1)
    goto L2; // [31] 42

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_filename_8469);
    DeRef(_cs_8474);
    DeRef(_hits_8475);
    DeRef(_jx_8477);
    DeRef(_fx_8478);
    DeRefi(_data_8479);
    return _5;
L2: 

    /** 	jx = file_length(filename)*/
    RefDS(_filename_8469);
    _0 = _jx_8477;
    _jx_8477 = _11file_length(_filename_8469);
    DeRef(_0);

    /** 	cs = repeat(jx, size)*/
    DeRef(_cs_8474);
    _cs_8474 = Repeat(_jx_8477, _size_8470);

    /** 	for i = 1 to size do*/
    _4633 = _size_8470;
    {
        int _i_8490;
        _i_8490 = 1;
L3: 
        if (_i_8490 > _4633){
            goto L4; // [59] 91
        }

        /** 		cs[i] = hash(i + size, cs[i])*/
        _4634 = _i_8490 + _size_8470;
        if ((long)((unsigned long)_4634 + (unsigned long)HIGH_BITS) >= 0) 
        _4634 = NewDouble((double)_4634);
        _2 = (int)SEQ_PTR(_cs_8474);
        _4635 = (int)*(((s1_ptr)_2)->base + _i_8490);
        _4636 = calc_hash(_4634, _4635);
        DeRef(_4634);
        _4634 = NOVALUE;
        _4635 = NOVALUE;
        _2 = (int)SEQ_PTR(_cs_8474);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _cs_8474 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8490);
        _1 = *(int *)_2;
        *(int *)_2 = _4636;
        if( _1 != _4636 ){
            DeRef(_1);
        }
        _4636 = NOVALUE;

        /** 	end for*/
        _i_8490 = _i_8490 + 1;
        goto L3; // [86] 66
L4: 
        ;
    }

    /** 	if usename != 0 then*/
    if (_usename_8471 == 0)
    goto L5; // [93] 214

    /** 		nhit = 0*/
    _nhit_8480 = 0;

    /** 		nmiss = 0*/
    _nmiss_8481 = 0;

    /** 		hits = {0,0}*/
    DeRef(_hits_8475);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _hits_8475 = MAKE_SEQ(_1);

    /** 		fx = hash(filename, stdhash:HSIEH32) -- Get a hash value for the whole name.*/
    DeRef(_fx_8478);
    _fx_8478 = calc_hash(_filename_8469, -5);

    /** 		while find(0, hits) do*/
L6: 
    _4640 = find_from(0, _hits_8475, 1);
    if (_4640 == 0)
    {
        _4640 = NOVALUE;
        goto L7; // [129] 213
    }
    else{
        _4640 = NOVALUE;
    }

    /** 			nhit += 1*/
    _nhit_8480 = _nhit_8480 + 1;

    /** 			if nhit > length(filename) then*/
    if (IS_SEQUENCE(_filename_8469)){
            _4642 = SEQ_PTR(_filename_8469)->length;
    }
    else {
        _4642 = 1;
    }
    if (_nhit_8480 <= _4642)
    goto L8; // [143] 159

    /** 				nhit = 1*/
    _nhit_8480 = 1;

    /** 				hits[1] = 1*/
    _2 = (int)SEQ_PTR(_hits_8475);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L8: 

    /** 			nmiss += 1*/
    _nmiss_8481 = _nmiss_8481 + 1;

    /** 			if nmiss > length(cs) then*/
    if (IS_SEQUENCE(_cs_8474)){
            _4645 = SEQ_PTR(_cs_8474)->length;
    }
    else {
        _4645 = 1;
    }
    if (_nmiss_8481 <= _4645)
    goto L9; // [170] 186

    /** 				nmiss = 1*/
    _nmiss_8481 = 1;

    /** 				hits[2] = 1*/
    _2 = (int)SEQ_PTR(_hits_8475);
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L9: 

    /** 			cs[nmiss] = hash(filename[nhit], xor_bits(fx, cs[nmiss]))*/
    _2 = (int)SEQ_PTR(_filename_8469);
    _4647 = (int)*(((s1_ptr)_2)->base + _nhit_8480);
    _2 = (int)SEQ_PTR(_cs_8474);
    _4648 = (int)*(((s1_ptr)_2)->base + _nmiss_8481);
    if (IS_ATOM_INT(_fx_8478) && IS_ATOM_INT(_4648)) {
        {unsigned long tu;
             tu = (unsigned long)_fx_8478 ^ (unsigned long)_4648;
             _4649 = MAKE_UINT(tu);
        }
    }
    else {
        _4649 = binary_op(XOR_BITS, _fx_8478, _4648);
    }
    _4648 = NOVALUE;
    _4650 = calc_hash(_4647, _4649);
    _4647 = NOVALUE;
    DeRef(_4649);
    _4649 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8474);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8474 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8481);
    _1 = *(int *)_2;
    *(int *)_2 = _4650;
    if( _1 != _4650 ){
        DeRef(_1);
    }
    _4650 = NOVALUE;

    /** 		end while -- repeat until every bucket and every character has been used.*/
    goto L6; // [210] 124
L7: 
L5: 

    /** 	hits = repeat(0, size)*/
    DeRef(_hits_8475);
    _hits_8475 = Repeat(0, _size_8470);

    /** 	if jx != 0 then*/
    if (binary_op_a(EQUALS, _jx_8477, 0)){
        goto LA; // [222] 458
    }

    /** 		data = repeat(0, remainder( hash(jx * jx / size , stdhash:HSIEH32), 8) + 7)*/
    if (IS_ATOM_INT(_jx_8477) && IS_ATOM_INT(_jx_8477)) {
        if (_jx_8477 == (short)_jx_8477 && _jx_8477 <= INT15 && _jx_8477 >= -INT15)
        _4653 = _jx_8477 * _jx_8477;
        else
        _4653 = NewDouble(_jx_8477 * (double)_jx_8477);
    }
    else {
        if (IS_ATOM_INT(_jx_8477)) {
            _4653 = NewDouble((double)_jx_8477 * DBL_PTR(_jx_8477)->dbl);
        }
        else {
            if (IS_ATOM_INT(_jx_8477)) {
                _4653 = NewDouble(DBL_PTR(_jx_8477)->dbl * (double)_jx_8477);
            }
            else
            _4653 = NewDouble(DBL_PTR(_jx_8477)->dbl * DBL_PTR(_jx_8477)->dbl);
        }
    }
    if (IS_ATOM_INT(_4653)) {
        _4654 = (_4653 % _size_8470) ? NewDouble((double)_4653 / _size_8470) : (_4653 / _size_8470);
    }
    else {
        _4654 = NewDouble(DBL_PTR(_4653)->dbl / (double)_size_8470);
    }
    DeRef(_4653);
    _4653 = NOVALUE;
    _4655 = calc_hash(_4654, -5);
    DeRef(_4654);
    _4654 = NOVALUE;
    if (IS_ATOM_INT(_4655)) {
        _4656 = (_4655 % 8);
    }
    else {
        temp_d.dbl = (double)8;
        _4656 = Dremainder(DBL_PTR(_4655), &temp_d);
    }
    DeRef(_4655);
    _4655 = NOVALUE;
    if (IS_ATOM_INT(_4656)) {
        _4657 = _4656 + 7;
    }
    else {
        _4657 = NewDouble(DBL_PTR(_4656)->dbl + (double)7);
    }
    DeRef(_4656);
    _4656 = NOVALUE;
    DeRefi(_data_8479);
    _data_8479 = Repeat(0, _4657);
    DeRef(_4657);
    _4657 = NOVALUE;

    /** 		while data[1] != -1 with entry do*/
    goto LB; // [254] 316
LC: 
    _2 = (int)SEQ_PTR(_data_8479);
    _4659 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4659 == -1)
    goto LD; // [261] 349

    /** 			jx = hash(jx, data)*/
    _0 = _jx_8477;
    _jx_8477 = calc_hash(_jx_8477, _data_8479);
    DeRef(_0);

    /** 			ix = remainder(jx, size) + 1*/
    if (IS_ATOM_INT(_jx_8477)) {
        _4662 = (_jx_8477 % _size_8470);
    }
    else {
        temp_d.dbl = (double)_size_8470;
        _4662 = Dremainder(DBL_PTR(_jx_8477), &temp_d);
    }
    if (IS_ATOM_INT(_4662)) {
        _ix_8476 = _4662 + 1;
    }
    else
    { // coercing _ix_8476 to an integer 1
        _ix_8476 = 1+(long)(DBL_PTR(_4662)->dbl);
        if( !IS_ATOM_INT(_ix_8476) ){
            _ix_8476 = (object)DBL_PTR(_ix_8476)->dbl;
        }
    }
    DeRef(_4662);
    _4662 = NOVALUE;

    /** 			cs[ix] = xor_bits(cs[ix], hash(data, stdhash:HSIEH32))*/
    _2 = (int)SEQ_PTR(_cs_8474);
    _4664 = (int)*(((s1_ptr)_2)->base + _ix_8476);
    _4665 = calc_hash(_data_8479, -5);
    if (IS_ATOM_INT(_4664) && IS_ATOM_INT(_4665)) {
        {unsigned long tu;
             tu = (unsigned long)_4664 ^ (unsigned long)_4665;
             _4666 = MAKE_UINT(tu);
        }
    }
    else {
        _4666 = binary_op(XOR_BITS, _4664, _4665);
    }
    _4664 = NOVALUE;
    DeRef(_4665);
    _4665 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8474);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8474 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ix_8476);
    _1 = *(int *)_2;
    *(int *)_2 = _4666;
    if( _1 != _4666 ){
        DeRef(_1);
    }
    _4666 = NOVALUE;

    /** 			hits[ix] += 1*/
    _2 = (int)SEQ_PTR(_hits_8475);
    _4667 = (int)*(((s1_ptr)_2)->base + _ix_8476);
    if (IS_ATOM_INT(_4667)) {
        _4668 = _4667 + 1;
        if (_4668 > MAXINT){
            _4668 = NewDouble((double)_4668);
        }
    }
    else
    _4668 = binary_op(PLUS, 1, _4667);
    _4667 = NOVALUE;
    _2 = (int)SEQ_PTR(_hits_8475);
    _2 = (int)(((s1_ptr)_2)->base + _ix_8476);
    _1 = *(int *)_2;
    *(int *)_2 = _4668;
    if( _1 != _4668 ){
        DeRef(_1);
    }
    _4668 = NOVALUE;

    /** 		entry*/
LB: 

    /** 			for i = 1 to length(data) do*/
    if (IS_SEQUENCE(_data_8479)){
            _4669 = SEQ_PTR(_data_8479)->length;
    }
    else {
        _4669 = 1;
    }
    {
        int _i_8534;
        _i_8534 = 1;
LE: 
        if (_i_8534 > _4669){
            goto LF; // [321] 344
        }

        /** 				data[i] = getc(fn)*/
        if (_fn_8473 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_8473, EF_READ);
            last_r_file_no = _fn_8473;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _4670 = getc((FILE*)xstdin);
            }
            else
            _4670 = getc(last_r_file_ptr);
        }
        else
        _4670 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_data_8479);
        _2 = (int)(((s1_ptr)_2)->base + _i_8534);
        *(int *)_2 = _4670;
        if( _1 != _4670 ){
        }
        _4670 = NOVALUE;

        /** 			end for*/
        _i_8534 = _i_8534 + 1;
        goto LE; // [339] 328
LF: 
        ;
    }

    /** 		end while*/
    goto LC; // [346] 257
LD: 

    /** 		nhit = 0*/
    _nhit_8480 = 0;

    /** 		while nmiss with entry do*/
    goto L10; // [356] 445
L11: 
    if (_nmiss_8481 == 0)
    {
        goto L12; // [361] 457
    }
    else{
    }

    /** 			while 1 do*/
L13: 

    /** 				nhit += 1*/
    _nhit_8480 = _nhit_8480 + 1;

    /** 				if nhit > length(hits) then*/
    if (IS_SEQUENCE(_hits_8475)){
            _4672 = SEQ_PTR(_hits_8475)->length;
    }
    else {
        _4672 = 1;
    }
    if (_nhit_8480 <= _4672)
    goto L14; // [380] 390

    /** 					nhit = 1*/
    _nhit_8480 = 1;
L14: 

    /** 				if hits[nhit] != 0 then*/
    _2 = (int)SEQ_PTR(_hits_8475);
    _4674 = (int)*(((s1_ptr)_2)->base + _nhit_8480);
    if (binary_op_a(EQUALS, _4674, 0)){
        _4674 = NOVALUE;
        goto L13; // [396] 369
    }
    _4674 = NOVALUE;

    /** 					exit*/
    goto L15; // [402] 410

    /** 			end while*/
    goto L13; // [407] 369
L15: 

    /** 			cs[nmiss] = hash(cs[nmiss], cs[nhit])*/
    _2 = (int)SEQ_PTR(_cs_8474);
    _4676 = (int)*(((s1_ptr)_2)->base + _nmiss_8481);
    _2 = (int)SEQ_PTR(_cs_8474);
    _4677 = (int)*(((s1_ptr)_2)->base + _nhit_8480);
    _4678 = calc_hash(_4676, _4677);
    _4676 = NOVALUE;
    _4677 = NOVALUE;
    _2 = (int)SEQ_PTR(_cs_8474);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _cs_8474 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8481);
    _1 = *(int *)_2;
    *(int *)_2 = _4678;
    if( _1 != _4678 ){
        DeRef(_1);
    }
    _4678 = NOVALUE;

    /** 			hits[nmiss] += 1*/
    _2 = (int)SEQ_PTR(_hits_8475);
    _4679 = (int)*(((s1_ptr)_2)->base + _nmiss_8481);
    if (IS_ATOM_INT(_4679)) {
        _4680 = _4679 + 1;
        if (_4680 > MAXINT){
            _4680 = NewDouble((double)_4680);
        }
    }
    else
    _4680 = binary_op(PLUS, 1, _4679);
    _4679 = NOVALUE;
    _2 = (int)SEQ_PTR(_hits_8475);
    _2 = (int)(((s1_ptr)_2)->base + _nmiss_8481);
    _1 = *(int *)_2;
    *(int *)_2 = _4680;
    if( _1 != _4680 ){
        DeRef(_1);
    }
    _4680 = NOVALUE;

    /** 		entry*/
L10: 

    /** 			nmiss = find(0, hits)	*/
    _nmiss_8481 = find_from(0, _hits_8475, 1);

    /** 		end while*/
    goto L11; // [454] 359
L12: 
LA: 

    /** 	close(fn)*/
    EClose(_fn_8473);

    /** 	if return_text then*/
    if (_return_text_8472 == 0)
    {
        goto L16; // [464] 535
    }
    else{
    }

    /** 		sequence cs_text = ""*/
    RefDS(_5);
    DeRef(_cs_text_8553);
    _cs_text_8553 = _5;

    /** 		for i = 1 to length(cs) do*/
    if (IS_SEQUENCE(_cs_8474)){
            _4682 = SEQ_PTR(_cs_8474)->length;
    }
    else {
        _4682 = 1;
    }
    {
        int _i_8555;
        _i_8555 = 1;
L17: 
        if (_i_8555 > _4682){
            goto L18; // [479] 524
        }

        /** 			cs_text &= text:format("[:08X]", cs[i])*/
        _2 = (int)SEQ_PTR(_cs_8474);
        _4684 = (int)*(((s1_ptr)_2)->base + _i_8555);
        RefDS(_4683);
        Ref(_4684);
        _4685 = _6format(_4683, _4684);
        _4684 = NOVALUE;
        if (IS_SEQUENCE(_cs_text_8553) && IS_ATOM(_4685)) {
            Ref(_4685);
            Append(&_cs_text_8553, _cs_text_8553, _4685);
        }
        else if (IS_ATOM(_cs_text_8553) && IS_SEQUENCE(_4685)) {
        }
        else {
            Concat((object_ptr)&_cs_text_8553, _cs_text_8553, _4685);
        }
        DeRef(_4685);
        _4685 = NOVALUE;

        /** 			if i != length(cs) then*/
        if (IS_SEQUENCE(_cs_8474)){
                _4687 = SEQ_PTR(_cs_8474)->length;
        }
        else {
            _4687 = 1;
        }
        if (_i_8555 == _4687)
        goto L19; // [506] 517

        /** 				cs_text &= ' '*/
        Append(&_cs_text_8553, _cs_text_8553, 32);
L19: 

        /** 		end for*/
        _i_8555 = _i_8555 + 1;
        goto L17; // [519] 486
L18: 
        ;
    }

    /** 		return cs_text*/
    DeRefDS(_filename_8469);
    DeRef(_cs_8474);
    DeRef(_hits_8475);
    DeRef(_jx_8477);
    DeRef(_fx_8478);
    DeRefi(_data_8479);
    _4659 = NOVALUE;
    return _cs_text_8553;
    DeRefDS(_cs_text_8553);
    _cs_text_8553 = NOVALUE;
    goto L1A; // [532] 542
L16: 

    /** 		return cs*/
    DeRefDS(_filename_8469);
    DeRef(_hits_8475);
    DeRef(_jx_8477);
    DeRef(_fx_8478);
    DeRefi(_data_8479);
    _4659 = NOVALUE;
    return _cs_8474;
L1A: 
    ;
}
int checksum() __attribute__ ((alias ("_11checksum")));



// 0xD1861710
