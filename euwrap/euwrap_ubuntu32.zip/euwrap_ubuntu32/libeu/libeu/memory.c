// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _16positive_int(int _x_1898)
{
    int _968 = NOVALUE;
    int _966 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(x) then*/
    if (IS_ATOM_INT(_x_1898))
    _966 = 1;
    else if (IS_ATOM_DBL(_x_1898))
    _966 = IS_ATOM_INT(DoubleToInt(_x_1898));
    else
    _966 = 0;
    if (_966 != 0)
    goto L1; // [6] 16
    _966 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_1898);
    return 0;
L1: 

    /**     return x >= 1*/
    if (IS_ATOM_INT(_x_1898)) {
        _968 = (_x_1898 >= 1);
    }
    else {
        _968 = binary_op(GREATEREQ, _x_1898, 1);
    }
    DeRef(_x_1898);
    return _968;
    ;
}


int _16machine_addr(int _a_1905)
{
    int _977 = NOVALUE;
    int _976 = NOVALUE;
    int _975 = NOVALUE;
    int _973 = NOVALUE;
    int _971 = NOVALUE;
    int _969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _969 = IS_ATOM(_a_1905);
    if (_969 != 0)
    goto L1; // [6] 16
    _969 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_1905);
    return 0;
L1: 

    /** 	if not integer(a)then*/
    if (IS_ATOM_INT(_a_1905))
    _971 = 1;
    else if (IS_ATOM_DBL(_a_1905))
    _971 = IS_ATOM_INT(DoubleToInt(_a_1905));
    else
    _971 = 0;
    if (_971 != 0)
    goto L2; // [21] 41
    _971 = NOVALUE;

    /** 		if floor(a) != a then*/
    if (IS_ATOM_INT(_a_1905))
    _973 = e_floor(_a_1905);
    else
    _973 = unary_op(FLOOR, _a_1905);
    if (binary_op_a(EQUALS, _973, _a_1905)){
        DeRef(_973);
        _973 = NOVALUE;
        goto L3; // [29] 40
    }
    DeRef(_973);
    _973 = NOVALUE;

    /** 			return 0*/
    DeRef(_a_1905);
    return 0;
L3: 
L2: 

    /** 	return a > 0 and a <= MAX_ADDR*/
    if (IS_ATOM_INT(_a_1905)) {
        _975 = (_a_1905 > 0);
    }
    else {
        _975 = binary_op(GREATER, _a_1905, 0);
    }
    if (IS_ATOM_INT(_a_1905) && IS_ATOM_INT(_16MAX_ADDR_1891)) {
        _976 = (_a_1905 <= _16MAX_ADDR_1891);
    }
    else {
        _976 = binary_op(LESSEQ, _a_1905, _16MAX_ADDR_1891);
    }
    if (IS_ATOM_INT(_975) && IS_ATOM_INT(_976)) {
        _977 = (_975 != 0 && _976 != 0);
    }
    else {
        _977 = binary_op(AND, _975, _976);
    }
    DeRef(_975);
    _975 = NOVALUE;
    DeRef(_976);
    _976 = NOVALUE;
    DeRef(_a_1905);
    return _977;
    ;
}
int machine_addr() __attribute__ ((alias ("_16machine_addr")));


void _16deallocate(int _addr_1920)
{
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1920);

    /** end procedure*/
    DeRef(_addr_1920);
    return;
    ;
}


void _16register_block(int _block_addr_1927, int _block_len_1928, int _protection_1929)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_1929)) {
        _1 = (long)(DBL_PTR(_protection_1929)->dbl);
        DeRefDS(_protection_1929);
        _protection_1929 = _1;
    }

    /** end procedure*/
    return;
    ;
}
void register_block() __attribute__ ((alias ("_16register_block")));


void _16unregister_block(int _block_addr_1933)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}
void unregister_block() __attribute__ ((alias ("_16unregister_block")));


int _16safe_address(int _start_1937, int _len_1938, int _action_1939)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_len_1938)) {
        _1 = (long)(DBL_PTR(_len_1938)->dbl);
        DeRefDS(_len_1938);
        _len_1938 = _1;
    }

    /** 	return 1*/
    return 1;
    ;
}
int safe_address() __attribute__ ((alias ("_16safe_address")));


void _16check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}
void check_all_blocks() __attribute__ ((alias ("_16check_all_blocks")));


int _16prepare_block(int _addr_1946, int _a_1947, int _protection_1948)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1947)) {
        _1 = (long)(DBL_PTR(_a_1947)->dbl);
        DeRefDS(_a_1947);
        _a_1947 = _1;
    }
    if (!IS_ATOM_INT(_protection_1948)) {
        _1 = (long)(DBL_PTR(_protection_1948)->dbl);
        DeRefDS(_protection_1948);
        _protection_1948 = _1;
    }

    /** 	return addr*/
    return _addr_1946;
    ;
}


int _16bordered_address(int _addr_1956)
{
    int _982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(addr) then*/
    _982 = IS_ATOM(_addr_1956);
    if (_982 != 0)
    goto L1; // [6] 16
    _982 = NOVALUE;

    /** 		return 0*/
    DeRef(_addr_1956);
    return 0;
L1: 

    /** 	return 1*/
    DeRef(_addr_1956);
    return 1;
    ;
}


int _16dep_works()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	return 1*/
    return 1;
    ;
}


void _16free_code(int _addr_1965, int _size_1966, int _wordsize_1968)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_1966)) {
        _1 = (long)(DBL_PTR(_size_1966)->dbl);
        DeRefDS(_size_1966);
        _size_1966 = _1;
    }

    /** 		machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1965);

    /** end procedure*/
    DeRef(_addr_1965);
    return;
    ;
}
void free_code() __attribute__ ((alias ("_16free_code")));



// 0x51DC93C3
