// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _35small(int _data_set_12273, int _ordinal_idx_12274)
{
    int _lSortedData_12275 = NOVALUE;
    int _6979 = NOVALUE;
    int _6978 = NOVALUE;
    int _6977 = NOVALUE;
    int _6976 = NOVALUE;
    int _6974 = NOVALUE;
    int _6973 = NOVALUE;
    int _6971 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ordinal_idx_12274)) {
        _1 = (long)(DBL_PTR(_ordinal_idx_12274)->dbl);
        DeRefDS(_ordinal_idx_12274);
        _ordinal_idx_12274 = _1;
    }

    /** 	if ordinal_idx < 1 or ordinal_idx > length(data_set) then*/
    _6971 = (_ordinal_idx_12274 < 1);
    if (_6971 != 0) {
        goto L1; // [11] 27
    }
    if (IS_SEQUENCE(_data_set_12273)){
            _6973 = SEQ_PTR(_data_set_12273)->length;
    }
    else {
        _6973 = 1;
    }
    _6974 = (_ordinal_idx_12274 > _6973);
    _6973 = NOVALUE;
    if (_6974 == 0)
    {
        DeRef(_6974);
        _6974 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_6974);
        _6974 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12273);
    DeRef(_lSortedData_12275);
    DeRef(_6971);
    _6971 = NOVALUE;
    return _5;
L2: 

    /** 	lSortedData = stdsort:sort(data_set)*/
    RefDS(_data_set_12273);
    _0 = _lSortedData_12275;
    _lSortedData_12275 = _24sort(_data_set_12273, 1);
    DeRef(_0);

    /** 	return {lSortedData[ordinal_idx], find(lSortedData[ordinal_idx], data_set)}*/
    _2 = (int)SEQ_PTR(_lSortedData_12275);
    _6976 = (int)*(((s1_ptr)_2)->base + _ordinal_idx_12274);
    _2 = (int)SEQ_PTR(_lSortedData_12275);
    _6977 = (int)*(((s1_ptr)_2)->base + _ordinal_idx_12274);
    _6978 = find_from(_6977, _data_set_12273, 1);
    _6977 = NOVALUE;
    Ref(_6976);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6976;
    ((int *)_2)[2] = _6978;
    _6979 = MAKE_SEQ(_1);
    _6978 = NOVALUE;
    _6976 = NOVALUE;
    DeRefDS(_data_set_12273);
    DeRefDS(_lSortedData_12275);
    DeRef(_6971);
    _6971 = NOVALUE;
    return _6979;
    ;
}
int small() __attribute__ ((alias ("_35small")));


int _35largest(int _data_set_12288)
{
    int _result__12289 = NOVALUE;
    int _temp__12290 = NOVALUE;
    int _lFoundAny_12291 = NOVALUE;
    int _6983 = NOVALUE;
    int _6982 = NOVALUE;
    int _6981 = NOVALUE;
    int _6980 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _6980 = IS_ATOM(_data_set_12288);
    if (_6980 == 0)
    {
        _6980 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _6980 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_result__12289);
    DeRef(_temp__12290);
    return _data_set_12288;
L1: 

    /** 	lFoundAny = 0*/
    _lFoundAny_12291 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12288)){
            _6981 = SEQ_PTR(_data_set_12288)->length;
    }
    else {
        _6981 = 1;
    }
    {
        int _i_12295;
        _i_12295 = 1;
L2: 
        if (_i_12295 > _6981){
            goto L3; // [26] 92
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12288);
        _6982 = (int)*(((s1_ptr)_2)->base + _i_12295);
        _6983 = IS_ATOM(_6982);
        _6982 = NOVALUE;
        if (_6983 == 0)
        {
            _6983 = NOVALUE;
            goto L4; // [42] 85
        }
        else{
            _6983 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12290);
        _2 = (int)SEQ_PTR(_data_set_12288);
        _temp__12290 = (int)*(((s1_ptr)_2)->base + _i_12295);
        Ref(_temp__12290);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12291 == 0)
        {
            goto L5; // [53] 73
        }
        else{
        }

        /** 				if temp_ > result_ then*/
        if (binary_op_a(LESSEQ, _temp__12290, _result__12289)){
            goto L6; // [60] 84
        }

        /** 					result_ = temp_*/
        Ref(_temp__12290);
        DeRef(_result__12289);
        _result__12289 = _temp__12290;
        goto L6; // [70] 84
L5: 

        /** 				result_ = temp_*/
        Ref(_temp__12290);
        DeRef(_result__12289);
        _result__12289 = _temp__12290;

        /** 				lFoundAny = 1*/
        _lFoundAny_12291 = 1;
L6: 
L4: 

        /** 	end for*/
        _i_12295 = _i_12295 + 1;
        goto L2; // [87] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12291 != 0)
    goto L7; // [94] 105

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12288);
    DeRef(_result__12289);
    DeRef(_temp__12290);
    return _5;
L7: 

    /** 	return result_*/
    DeRef(_data_set_12288);
    DeRef(_temp__12290);
    return _result__12289;
    ;
}
int largest() __attribute__ ((alias ("_35largest")));


int _35smallest(int _data_set_12309)
{
    int _result__12310 = NOVALUE;
    int _temp__12311 = NOVALUE;
    int _lFoundAny_12312 = NOVALUE;
    int _6990 = NOVALUE;
    int _6989 = NOVALUE;
    int _6988 = NOVALUE;
    int _6987 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _6987 = IS_ATOM(_data_set_12309);
    if (_6987 == 0)
    {
        _6987 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _6987 = NOVALUE;
    }

    /** 			return data_set*/
    DeRef(_result__12310);
    DeRef(_temp__12311);
    return _data_set_12309;
L1: 

    /** 	lFoundAny = 0*/
    _lFoundAny_12312 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12309)){
            _6988 = SEQ_PTR(_data_set_12309)->length;
    }
    else {
        _6988 = 1;
    }
    {
        int _i_12316;
        _i_12316 = 1;
L2: 
        if (_i_12316 > _6988){
            goto L3; // [26] 92
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12309);
        _6989 = (int)*(((s1_ptr)_2)->base + _i_12316);
        _6990 = IS_ATOM(_6989);
        _6989 = NOVALUE;
        if (_6990 == 0)
        {
            _6990 = NOVALUE;
            goto L4; // [42] 85
        }
        else{
            _6990 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12311);
        _2 = (int)SEQ_PTR(_data_set_12309);
        _temp__12311 = (int)*(((s1_ptr)_2)->base + _i_12316);
        Ref(_temp__12311);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12312 == 0)
        {
            goto L5; // [53] 73
        }
        else{
        }

        /** 				if temp_ < result_ then*/
        if (binary_op_a(GREATEREQ, _temp__12311, _result__12310)){
            goto L6; // [60] 84
        }

        /** 					result_ = temp_*/
        Ref(_temp__12311);
        DeRef(_result__12310);
        _result__12310 = _temp__12311;
        goto L6; // [70] 84
L5: 

        /** 				result_ = temp_*/
        Ref(_temp__12311);
        DeRef(_result__12310);
        _result__12310 = _temp__12311;

        /** 				lFoundAny = 1*/
        _lFoundAny_12312 = 1;
L6: 
L4: 

        /** 	end for*/
        _i_12316 = _i_12316 + 1;
        goto L2; // [87] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12312 != 0)
    goto L7; // [94] 105

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12309);
    DeRef(_result__12310);
    DeRef(_temp__12311);
    return _5;
L7: 

    /** 	return result_*/
    DeRef(_data_set_12309);
    DeRef(_temp__12311);
    return _result__12310;
    ;
}
int smallest() __attribute__ ((alias ("_35smallest")));


int _35range(int _data_set_12330)
{
    int _result__12331 = NOVALUE;
    int _temp__12332 = NOVALUE;
    int _lFoundAny_12333 = NOVALUE;
    int _7012 = NOVALUE;
    int _7011 = NOVALUE;
    int _7010 = NOVALUE;
    int _7009 = NOVALUE;
    int _7008 = NOVALUE;
    int _7007 = NOVALUE;
    int _7006 = NOVALUE;
    int _7002 = NOVALUE;
    int _7000 = NOVALUE;
    int _6998 = NOVALUE;
    int _6997 = NOVALUE;
    int _6996 = NOVALUE;
    int _6994 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lFoundAny = 0*/
    _lFoundAny_12333 = 0;

    /** 	if atom(data_set) then*/
    _6994 = IS_ATOM(_data_set_12330);
    if (_6994 == 0)
    {
        _6994 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _6994 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12330;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12330);
    *((int *)(_2+4)) = _data_set_12330;
    _data_set_12330 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12330)){
            _6996 = SEQ_PTR(_data_set_12330)->length;
    }
    else {
        _6996 = 1;
    }
    {
        int _i_12338;
        _i_12338 = 1;
L2: 
        if (_i_12338 > _6996){
            goto L3; // [26] 121
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12330);
        _6997 = (int)*(((s1_ptr)_2)->base + _i_12338);
        _6998 = IS_ATOM(_6997);
        _6997 = NOVALUE;
        if (_6998 == 0)
        {
            _6998 = NOVALUE;
            goto L4; // [42] 114
        }
        else{
            _6998 = NOVALUE;
        }

        /** 			temp_ = data_set[i]*/
        DeRef(_temp__12332);
        _2 = (int)SEQ_PTR(_data_set_12330);
        _temp__12332 = (int)*(((s1_ptr)_2)->base + _i_12338);
        Ref(_temp__12332);

        /** 			if lFoundAny then*/
        if (_lFoundAny_12333 == 0)
        {
            goto L5; // [53] 98
        }
        else{
        }

        /** 				if temp_ < result_[1] then*/
        _2 = (int)SEQ_PTR(_result__12331);
        _7000 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(GREATEREQ, _temp__12332, _7000)){
            _7000 = NOVALUE;
            goto L6; // [64] 77
        }
        _7000 = NOVALUE;

        /** 					result_[1] = temp_*/
        Ref(_temp__12332);
        _2 = (int)SEQ_PTR(_result__12331);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12331 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _temp__12332;
        DeRef(_1);
        goto L7; // [74] 113
L6: 

        /** 				elsif temp_ > result_[2] then*/
        _2 = (int)SEQ_PTR(_result__12331);
        _7002 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(LESSEQ, _temp__12332, _7002)){
            _7002 = NOVALUE;
            goto L7; // [83] 113
        }
        _7002 = NOVALUE;

        /** 					result_[2] = temp_*/
        Ref(_temp__12332);
        _2 = (int)SEQ_PTR(_result__12331);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12331 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _temp__12332;
        DeRef(_1);
        goto L7; // [95] 113
L5: 

        /** 				result_ = {temp_, temp_, 0, 0}*/
        _0 = _result__12331;
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Refn(_temp__12332, 2);
        *((int *)(_2+4)) = _temp__12332;
        *((int *)(_2+8)) = _temp__12332;
        *((int *)(_2+12)) = 0;
        *((int *)(_2+16)) = 0;
        _result__12331 = MAKE_SEQ(_1);
        DeRef(_0);

        /** 				lFoundAny = 1*/
        _lFoundAny_12333 = 1;
L7: 
L4: 

        /** 	end for*/
        _i_12338 = _i_12338 + 1;
        goto L2; // [116] 33
L3: 
        ;
    }

    /** 	if lFoundAny = 0 then*/
    if (_lFoundAny_12333 != 0)
    goto L8; // [123] 134

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12330);
    DeRef(_result__12331);
    DeRef(_temp__12332);
    return _5;
L8: 

    /** 	result_[3] = result_[2] - result_[1]*/
    _2 = (int)SEQ_PTR(_result__12331);
    _7006 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_result__12331);
    _7007 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_7006) && IS_ATOM_INT(_7007)) {
        _7008 = _7006 - _7007;
        if ((long)((unsigned long)_7008 +(unsigned long) HIGH_BITS) >= 0){
            _7008 = NewDouble((double)_7008);
        }
    }
    else {
        _7008 = binary_op(MINUS, _7006, _7007);
    }
    _7006 = NOVALUE;
    _7007 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12331);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12331 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7008;
    if( _1 != _7008 ){
        DeRef(_1);
    }
    _7008 = NOVALUE;

    /** 	result_[4] = (result_[1] + result_[2]) / 2*/
    _2 = (int)SEQ_PTR(_result__12331);
    _7009 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_result__12331);
    _7010 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7009) && IS_ATOM_INT(_7010)) {
        _7011 = _7009 + _7010;
        if ((long)((unsigned long)_7011 + (unsigned long)HIGH_BITS) >= 0) 
        _7011 = NewDouble((double)_7011);
    }
    else {
        _7011 = binary_op(PLUS, _7009, _7010);
    }
    _7009 = NOVALUE;
    _7010 = NOVALUE;
    if (IS_ATOM_INT(_7011)) {
        if (_7011 & 1) {
            _7012 = NewDouble((_7011 >> 1) + 0.5);
        }
        else
        _7012 = _7011 >> 1;
    }
    else {
        _7012 = binary_op(DIVIDE, _7011, 2);
    }
    DeRef(_7011);
    _7011 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12331);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12331 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _7012;
    if( _1 != _7012 ){
        DeRef(_1);
    }
    _7012 = NOVALUE;

    /** 	return result_*/
    DeRef(_data_set_12330);
    DeRef(_temp__12332);
    return _result__12331;
    ;
}
int range() __attribute__ ((alias ("_35range")));


int _35massage(int _data_set_12369, int _subseq_opt_12370)
{
    int _7016 = NOVALUE;
    int _7015 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch subseq_opt do*/
    if (IS_SEQUENCE(_subseq_opt_12370) ){
        goto L1; // [5] 48
    }
    if(!IS_ATOM_INT(_subseq_opt_12370)){
        if( (DBL_PTR(_subseq_opt_12370)->dbl != (double) ((int) DBL_PTR(_subseq_opt_12370)->dbl) ) ){
            goto L1; // [5] 48
        }
        _0 = (int) DBL_PTR(_subseq_opt_12370)->dbl;
    }
    else {
        _0 = _subseq_opt_12370;
    };
    switch ( _0 ){ 

        /** 		case ST_IGNSTR then*/
        case 2:

        /** 			return stdseq:remove_subseq(data_set, stdseq:SEQ_NOALT)*/
        RefDS(_data_set_12369);
        RefDS(_23SEQ_NOALT_6750);
        _7015 = _23remove_subseq(_data_set_12369, _23SEQ_NOALT_6750);
        DeRefDS(_data_set_12369);
        DeRef(_subseq_opt_12370);
        return _7015;
        goto L2; // [27] 57

        /** 		case ST_ZEROSTR then*/
        case 3:

        /** 			return stdseq:remove_subseq(data_set, 0)*/
        RefDS(_data_set_12369);
        _7016 = _23remove_subseq(_data_set_12369, 0);
        DeRefDS(_data_set_12369);
        DeRef(_subseq_opt_12370);
        DeRef(_7015);
        _7015 = NOVALUE;
        return _7016;
        goto L2; // [44] 57

        /** 		case else*/
        default:
L1: 

        /** 			return data_set*/
        DeRef(_subseq_opt_12370);
        DeRef(_7015);
        _7015 = NOVALUE;
        DeRef(_7016);
        _7016 = NOVALUE;
        return _data_set_12369;
    ;}L2: 
    ;
}


int _35stdev(int _data_set_12380, int _subseq_opt_12381, int _population_type_12382)
{
    int _lSum_12383 = NOVALUE;
    int _lMean_12384 = NOVALUE;
    int _lCnt_12385 = NOVALUE;
    int _7033 = NOVALUE;
    int _7032 = NOVALUE;
    int _7028 = NOVALUE;
    int _7027 = NOVALUE;
    int _7026 = NOVALUE;
    int _7025 = NOVALUE;
    int _7022 = NOVALUE;
    int _7021 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_population_type_12382)) {
        _1 = (long)(DBL_PTR(_population_type_12382)->dbl);
        DeRefDS(_population_type_12382);
        _population_type_12382 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12380);
    Ref(_subseq_opt_12381);
    _0 = _data_set_12380;
    _data_set_12380 = _35massage(_data_set_12380, _subseq_opt_12381);
    DeRefDS(_0);

    /** 	lCnt = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12380)){
            _lCnt_12385 = SEQ_PTR(_data_set_12380)->length;
    }
    else {
        _lCnt_12385 = 1;
    }

    /** 	if lCnt = 0 then*/
    if (_lCnt_12385 != 0)
    goto L1; // [21] 32

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12380);
    DeRef(_subseq_opt_12381);
    DeRef(_lSum_12383);
    DeRef(_lMean_12384);
    return _5;
L1: 

    /** 	if lCnt = 1 then*/
    if (_lCnt_12385 != 1)
    goto L2; // [34] 45

    /** 		return 0*/
    DeRefDS(_data_set_12380);
    DeRef(_subseq_opt_12381);
    DeRef(_lSum_12383);
    DeRef(_lMean_12384);
    return 0;
L2: 

    /** 	lSum = 0*/
    DeRef(_lSum_12383);
    _lSum_12383 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12380)){
            _7021 = SEQ_PTR(_data_set_12380)->length;
    }
    else {
        _7021 = 1;
    }
    {
        int _i_12393;
        _i_12393 = 1;
L3: 
        if (_i_12393 > _7021){
            goto L4; // [55] 79
        }

        /** 		lSum += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12380);
        _7022 = (int)*(((s1_ptr)_2)->base + _i_12393);
        _0 = _lSum_12383;
        if (IS_ATOM_INT(_lSum_12383) && IS_ATOM_INT(_7022)) {
            _lSum_12383 = _lSum_12383 + _7022;
            if ((long)((unsigned long)_lSum_12383 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12383 = NewDouble((double)_lSum_12383);
        }
        else {
            _lSum_12383 = binary_op(PLUS, _lSum_12383, _7022);
        }
        DeRef(_0);
        _7022 = NOVALUE;

        /** 	end for*/
        _i_12393 = _i_12393 + 1;
        goto L3; // [74] 62
L4: 
        ;
    }

    /** 	lMean = lSum / lCnt*/
    DeRef(_lMean_12384);
    if (IS_ATOM_INT(_lSum_12383)) {
        _lMean_12384 = (_lSum_12383 % _lCnt_12385) ? NewDouble((double)_lSum_12383 / _lCnt_12385) : (_lSum_12383 / _lCnt_12385);
    }
    else {
        _lMean_12384 = NewDouble(DBL_PTR(_lSum_12383)->dbl / (double)_lCnt_12385);
    }

    /** 	lSum = 0*/
    DeRef(_lSum_12383);
    _lSum_12383 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12380)){
            _7025 = SEQ_PTR(_data_set_12380)->length;
    }
    else {
        _7025 = 1;
    }
    {
        int _i_12399;
        _i_12399 = 1;
L5: 
        if (_i_12399 > _7025){
            goto L6; // [95] 127
        }

        /** 		lSum += power(data_set[i] - lMean, 2)*/
        _2 = (int)SEQ_PTR(_data_set_12380);
        _7026 = (int)*(((s1_ptr)_2)->base + _i_12399);
        if (IS_ATOM_INT(_7026) && IS_ATOM_INT(_lMean_12384)) {
            _7027 = _7026 - _lMean_12384;
            if ((long)((unsigned long)_7027 +(unsigned long) HIGH_BITS) >= 0){
                _7027 = NewDouble((double)_7027);
            }
        }
        else {
            _7027 = binary_op(MINUS, _7026, _lMean_12384);
        }
        _7026 = NOVALUE;
        if (IS_ATOM_INT(_7027) && IS_ATOM_INT(_7027)) {
            if (_7027 == (short)_7027 && _7027 <= INT15 && _7027 >= -INT15)
            _7028 = _7027 * _7027;
            else
            _7028 = NewDouble(_7027 * (double)_7027);
        }
        else {
            _7028 = binary_op(MULTIPLY, _7027, _7027);
        }
        DeRef(_7027);
        _7027 = NOVALUE;
        _7027 = NOVALUE;
        _0 = _lSum_12383;
        if (IS_ATOM_INT(_lSum_12383) && IS_ATOM_INT(_7028)) {
            _lSum_12383 = _lSum_12383 + _7028;
            if ((long)((unsigned long)_lSum_12383 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12383 = NewDouble((double)_lSum_12383);
        }
        else {
            _lSum_12383 = binary_op(PLUS, _lSum_12383, _7028);
        }
        DeRef(_0);
        DeRef(_7028);
        _7028 = NOVALUE;

        /** 	end for*/
        _i_12399 = _i_12399 + 1;
        goto L5; // [122] 102
L6: 
        ;
    }

    /** 	if population_type = ST_SAMPLE then*/
    if (_population_type_12382 != 2)
    goto L7; // [129] 140

    /** 		lCnt -= 1*/
    _lCnt_12385 = _lCnt_12385 - 1;
L7: 

    /** 	return power(lSum / lCnt, 0.5)*/
    if (IS_ATOM_INT(_lSum_12383)) {
        _7032 = (_lSum_12383 % _lCnt_12385) ? NewDouble((double)_lSum_12383 / _lCnt_12385) : (_lSum_12383 / _lCnt_12385);
    }
    else {
        _7032 = NewDouble(DBL_PTR(_lSum_12383)->dbl / (double)_lCnt_12385);
    }
    if (IS_ATOM_INT(_7032)) {
        temp_d.dbl = (double)_7032;
        _7033 = Dpower(&temp_d, DBL_PTR(_2326));
    }
    else {
        _7033 = Dpower(DBL_PTR(_7032), DBL_PTR(_2326));
    }
    DeRef(_7032);
    _7032 = NOVALUE;
    DeRefDS(_data_set_12380);
    DeRef(_subseq_opt_12381);
    DeRef(_lSum_12383);
    DeRef(_lMean_12384);
    return _7033;
    ;
}
int stdev() __attribute__ ((alias ("_35stdev")));


int _35avedev(int _data_set_12412, int _subseq_opt_12413, int _population_type_12414)
{
    int _lSum_12415 = NOVALUE;
    int _lMean_12416 = NOVALUE;
    int _lCnt_12417 = NOVALUE;
    int _7053 = NOVALUE;
    int _7049 = NOVALUE;
    int _7048 = NOVALUE;
    int _7046 = NOVALUE;
    int _7045 = NOVALUE;
    int _7043 = NOVALUE;
    int _7042 = NOVALUE;
    int _7039 = NOVALUE;
    int _7038 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_population_type_12414)) {
        _1 = (long)(DBL_PTR(_population_type_12414)->dbl);
        DeRefDS(_population_type_12414);
        _population_type_12414 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12412);
    Ref(_subseq_opt_12413);
    _0 = _data_set_12412;
    _data_set_12412 = _35massage(_data_set_12412, _subseq_opt_12413);
    DeRefDS(_0);

    /** 	lCnt = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12412)){
            _lCnt_12417 = SEQ_PTR(_data_set_12412)->length;
    }
    else {
        _lCnt_12417 = 1;
    }

    /** 	if lCnt = 0 then*/
    if (_lCnt_12417 != 0)
    goto L1; // [21] 32

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12412);
    DeRef(_subseq_opt_12413);
    DeRef(_lSum_12415);
    DeRef(_lMean_12416);
    return _5;
L1: 

    /** 	if lCnt = 1 then*/
    if (_lCnt_12417 != 1)
    goto L2; // [34] 45

    /** 		return 0*/
    DeRefDS(_data_set_12412);
    DeRef(_subseq_opt_12413);
    DeRef(_lSum_12415);
    DeRef(_lMean_12416);
    return 0;
L2: 

    /** 	lSum = 0*/
    DeRef(_lSum_12415);
    _lSum_12415 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12412)){
            _7038 = SEQ_PTR(_data_set_12412)->length;
    }
    else {
        _7038 = 1;
    }
    {
        int _i_12425;
        _i_12425 = 1;
L3: 
        if (_i_12425 > _7038){
            goto L4; // [55] 79
        }

        /** 		lSum += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12412);
        _7039 = (int)*(((s1_ptr)_2)->base + _i_12425);
        _0 = _lSum_12415;
        if (IS_ATOM_INT(_lSum_12415) && IS_ATOM_INT(_7039)) {
            _lSum_12415 = _lSum_12415 + _7039;
            if ((long)((unsigned long)_lSum_12415 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12415 = NewDouble((double)_lSum_12415);
        }
        else {
            _lSum_12415 = binary_op(PLUS, _lSum_12415, _7039);
        }
        DeRef(_0);
        _7039 = NOVALUE;

        /** 	end for*/
        _i_12425 = _i_12425 + 1;
        goto L3; // [74] 62
L4: 
        ;
    }

    /** 	lMean = lSum / lCnt*/
    DeRef(_lMean_12416);
    if (IS_ATOM_INT(_lSum_12415)) {
        _lMean_12416 = (_lSum_12415 % _lCnt_12417) ? NewDouble((double)_lSum_12415 / _lCnt_12417) : (_lSum_12415 / _lCnt_12417);
    }
    else {
        _lMean_12416 = NewDouble(DBL_PTR(_lSum_12415)->dbl / (double)_lCnt_12417);
    }

    /** 	lSum = 0*/
    DeRef(_lSum_12415);
    _lSum_12415 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12412)){
            _7042 = SEQ_PTR(_data_set_12412)->length;
    }
    else {
        _7042 = 1;
    }
    {
        int _i_12431;
        _i_12431 = 1;
L5: 
        if (_i_12431 > _7042){
            goto L6; // [95] 151
        }

        /** 		if data_set[i] > lMean then*/
        _2 = (int)SEQ_PTR(_data_set_12412);
        _7043 = (int)*(((s1_ptr)_2)->base + _i_12431);
        if (binary_op_a(LESSEQ, _7043, _lMean_12416)){
            _7043 = NOVALUE;
            goto L7; // [108] 129
        }
        _7043 = NOVALUE;

        /** 			lSum += data_set[i] - lMean*/
        _2 = (int)SEQ_PTR(_data_set_12412);
        _7045 = (int)*(((s1_ptr)_2)->base + _i_12431);
        if (IS_ATOM_INT(_7045) && IS_ATOM_INT(_lMean_12416)) {
            _7046 = _7045 - _lMean_12416;
            if ((long)((unsigned long)_7046 +(unsigned long) HIGH_BITS) >= 0){
                _7046 = NewDouble((double)_7046);
            }
        }
        else {
            _7046 = binary_op(MINUS, _7045, _lMean_12416);
        }
        _7045 = NOVALUE;
        _0 = _lSum_12415;
        if (IS_ATOM_INT(_lSum_12415) && IS_ATOM_INT(_7046)) {
            _lSum_12415 = _lSum_12415 + _7046;
            if ((long)((unsigned long)_lSum_12415 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12415 = NewDouble((double)_lSum_12415);
        }
        else {
            _lSum_12415 = binary_op(PLUS, _lSum_12415, _7046);
        }
        DeRef(_0);
        DeRef(_7046);
        _7046 = NOVALUE;
        goto L8; // [126] 144
L7: 

        /** 			lSum += lMean - data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12412);
        _7048 = (int)*(((s1_ptr)_2)->base + _i_12431);
        if (IS_ATOM_INT(_lMean_12416) && IS_ATOM_INT(_7048)) {
            _7049 = _lMean_12416 - _7048;
            if ((long)((unsigned long)_7049 +(unsigned long) HIGH_BITS) >= 0){
                _7049 = NewDouble((double)_7049);
            }
        }
        else {
            _7049 = binary_op(MINUS, _lMean_12416, _7048);
        }
        _7048 = NOVALUE;
        _0 = _lSum_12415;
        if (IS_ATOM_INT(_lSum_12415) && IS_ATOM_INT(_7049)) {
            _lSum_12415 = _lSum_12415 + _7049;
            if ((long)((unsigned long)_lSum_12415 + (unsigned long)HIGH_BITS) >= 0) 
            _lSum_12415 = NewDouble((double)_lSum_12415);
        }
        else {
            _lSum_12415 = binary_op(PLUS, _lSum_12415, _7049);
        }
        DeRef(_0);
        DeRef(_7049);
        _7049 = NOVALUE;
L8: 

        /** 	end for*/
        _i_12431 = _i_12431 + 1;
        goto L5; // [146] 102
L6: 
        ;
    }

    /** 	if population_type = ST_SAMPLE then*/
    if (_population_type_12414 != 2)
    goto L9; // [153] 164

    /** 		lCnt -= 1*/
    _lCnt_12417 = _lCnt_12417 - 1;
L9: 

    /** 	return lSum / lCnt*/
    if (IS_ATOM_INT(_lSum_12415)) {
        _7053 = (_lSum_12415 % _lCnt_12417) ? NewDouble((double)_lSum_12415 / _lCnt_12417) : (_lSum_12415 / _lCnt_12417);
    }
    else {
        _7053 = NewDouble(DBL_PTR(_lSum_12415)->dbl / (double)_lCnt_12417);
    }
    DeRefDS(_data_set_12412);
    DeRef(_subseq_opt_12413);
    DeRef(_lSum_12415);
    DeRef(_lMean_12416);
    return _7053;
    ;
}
int avedev() __attribute__ ((alias ("_35avedev")));


int _35sum(int _data_set_12449, int _subseq_opt_12450)
{
    int _result__12451 = NOVALUE;
    int _7057 = NOVALUE;
    int _7056 = NOVALUE;
    int _7054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7054 = IS_ATOM(_data_set_12449);
    if (_7054 == 0)
    {
        _7054 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7054 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12450);
    DeRef(_result__12451);
    return _data_set_12449;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12449);
    Ref(_subseq_opt_12450);
    _0 = _data_set_12449;
    _data_set_12449 = _35massage(_data_set_12449, _subseq_opt_12450);
    DeRef(_0);

    /** 	result_ = 0*/
    DeRef(_result__12451);
    _result__12451 = 0;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12449)){
            _7056 = SEQ_PTR(_data_set_12449)->length;
    }
    else {
        _7056 = 1;
    }
    {
        int _i_12456;
        _i_12456 = 1;
L2: 
        if (_i_12456 > _7056){
            goto L3; // [33] 57
        }

        /** 		result_ += data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12449);
        _7057 = (int)*(((s1_ptr)_2)->base + _i_12456);
        _0 = _result__12451;
        if (IS_ATOM_INT(_result__12451) && IS_ATOM_INT(_7057)) {
            _result__12451 = _result__12451 + _7057;
            if ((long)((unsigned long)_result__12451 + (unsigned long)HIGH_BITS) >= 0) 
            _result__12451 = NewDouble((double)_result__12451);
        }
        else {
            _result__12451 = binary_op(PLUS, _result__12451, _7057);
        }
        DeRef(_0);
        _7057 = NOVALUE;

        /** 	end for*/
        _i_12456 = _i_12456 + 1;
        goto L2; // [52] 40
L3: 
        ;
    }

    /** 	return result_*/
    DeRef(_data_set_12449);
    DeRef(_subseq_opt_12450);
    return _result__12451;
    ;
}


int _35count(int _data_set_12462, int _subseq_opt_12463)
{
    int _7061 = NOVALUE;
    int _7060 = NOVALUE;
    int _7059 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7059 = IS_ATOM(_data_set_12462);
    if (_7059 == 0)
    {
        _7059 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7059 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_data_set_12462);
    DeRef(_subseq_opt_12463);
    return 1;
L1: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12462);
    Ref(_subseq_opt_12463);
    _7060 = _35massage(_data_set_12462, _subseq_opt_12463);
    if (IS_SEQUENCE(_7060)){
            _7061 = SEQ_PTR(_7060)->length;
    }
    else {
        _7061 = 1;
    }
    DeRef(_7060);
    _7060 = NOVALUE;
    DeRef(_data_set_12462);
    DeRef(_subseq_opt_12463);
    _7060 = NOVALUE;
    return _7061;
    ;
}
int count() __attribute__ ((alias ("_35count")));


int _35average(int _data_set_12470, int _subseq_opt_12471)
{
    int _7068 = NOVALUE;
    int _7067 = NOVALUE;
    int _7066 = NOVALUE;
    int _7064 = NOVALUE;
    int _7062 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7062 = IS_ATOM(_data_set_12470);
    if (_7062 == 0)
    {
        _7062 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7062 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12471);
    return _data_set_12470;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12470);
    Ref(_subseq_opt_12471);
    _0 = _data_set_12470;
    _data_set_12470 = _35massage(_data_set_12470, _subseq_opt_12471);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12470)){
            _7064 = SEQ_PTR(_data_set_12470)->length;
    }
    else {
        _7064 = 1;
    }
    if (_7064 != 0)
    goto L2; // [28] 39

    /** 		return {}*/
    RefDS(_5);
    DeRef(_data_set_12470);
    DeRef(_subseq_opt_12471);
    return _5;
L2: 

    /** 	return sum(data_set) / length(data_set)*/
    Ref(_data_set_12470);
    _7066 = _35sum(_data_set_12470, 1);
    if (IS_SEQUENCE(_data_set_12470)){
            _7067 = SEQ_PTR(_data_set_12470)->length;
    }
    else {
        _7067 = 1;
    }
    if (IS_ATOM_INT(_7066)) {
        _7068 = (_7066 % _7067) ? NewDouble((double)_7066 / _7067) : (_7066 / _7067);
    }
    else {
        _7068 = binary_op(DIVIDE, _7066, _7067);
    }
    DeRef(_7066);
    _7066 = NOVALUE;
    _7067 = NOVALUE;
    DeRef(_data_set_12470);
    DeRef(_subseq_opt_12471);
    return _7068;
    ;
}
int average() __attribute__ ((alias ("_35average")));


int _35geomean(int _data_set_12483, int _subseq_opt_12484)
{
    int _prod__12485 = NOVALUE;
    int _count__12486 = NOVALUE;
    int _x_12499 = NOVALUE;
    int _7084 = NOVALUE;
    int _7083 = NOVALUE;
    int _7082 = NOVALUE;
    int _7081 = NOVALUE;
    int _7080 = NOVALUE;
    int _7075 = NOVALUE;
    int _7074 = NOVALUE;
    int _7069 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom prod_ = 1.0*/
    RefDS(_2193);
    DeRef(_prod__12485);
    _prod__12485 = _2193;

    /** 	if atom(data_set) then*/
    _7069 = IS_ATOM(_data_set_12483);
    if (_7069 == 0)
    {
        _7069 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _7069 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12484);
    DeRefDS(_prod__12485);
    return _data_set_12483;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12483);
    Ref(_subseq_opt_12484);
    _0 = _data_set_12483;
    _data_set_12483 = _35massage(_data_set_12483, _subseq_opt_12484);
    DeRef(_0);

    /** 	count_ = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12483)){
            _count__12486 = SEQ_PTR(_data_set_12483)->length;
    }
    else {
        _count__12486 = 1;
    }

    /** 	if count_ = 0 then*/
    if (_count__12486 != 0)
    goto L2; // [35] 46

    /** 		return 1*/
    DeRef(_data_set_12483);
    DeRef(_subseq_opt_12484);
    DeRef(_prod__12485);
    return 1;
L2: 

    /** 	if count_ = 1 then*/
    if (_count__12486 != 1)
    goto L3; // [48] 63

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12483);
    _7074 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7074);
    DeRef(_data_set_12483);
    DeRef(_subseq_opt_12484);
    DeRef(_prod__12485);
    return _7074;
L3: 

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12483)){
            _7075 = SEQ_PTR(_data_set_12483)->length;
    }
    else {
        _7075 = 1;
    }
    {
        int _i_12497;
        _i_12497 = 1;
L4: 
        if (_i_12497 > _7075){
            goto L5; // [68] 112
        }

        /** 		atom x = data_set[i]*/
        DeRef(_x_12499);
        _2 = (int)SEQ_PTR(_data_set_12483);
        _x_12499 = (int)*(((s1_ptr)_2)->base + _i_12497);
        Ref(_x_12499);

        /** 	    if x = 0 then*/
        if (binary_op_a(NOTEQ, _x_12499, 0)){
            goto L6; // [83] 96
        }

        /** 	        return 0*/
        DeRef(_x_12499);
        DeRef(_data_set_12483);
        DeRef(_subseq_opt_12484);
        DeRef(_prod__12485);
        _7074 = NOVALUE;
        return 0;
        goto L7; // [93] 103
L6: 

        /** 		    prod_ *= x*/
        _0 = _prod__12485;
        if (IS_ATOM_INT(_prod__12485) && IS_ATOM_INT(_x_12499)) {
            if (_prod__12485 == (short)_prod__12485 && _x_12499 <= INT15 && _x_12499 >= -INT15)
            _prod__12485 = _prod__12485 * _x_12499;
            else
            _prod__12485 = NewDouble(_prod__12485 * (double)_x_12499);
        }
        else {
            if (IS_ATOM_INT(_prod__12485)) {
                _prod__12485 = NewDouble((double)_prod__12485 * DBL_PTR(_x_12499)->dbl);
            }
            else {
                if (IS_ATOM_INT(_x_12499)) {
                    _prod__12485 = NewDouble(DBL_PTR(_prod__12485)->dbl * (double)_x_12499);
                }
                else
                _prod__12485 = NewDouble(DBL_PTR(_prod__12485)->dbl * DBL_PTR(_x_12499)->dbl);
            }
        }
        DeRef(_0);
L7: 
        DeRef(_x_12499);
        _x_12499 = NOVALUE;

        /** 	end for*/
        _i_12497 = _i_12497 + 1;
        goto L4; // [107] 75
L5: 
        ;
    }

    /** 	if prod_ < 0 then*/
    if (binary_op_a(GREATEREQ, _prod__12485, 0)){
        goto L8; // [114] 138
    }

    /** 		return power(-prod_, 1/count_)*/
    if (IS_ATOM_INT(_prod__12485)) {
        if ((unsigned long)_prod__12485 == 0xC0000000)
        _7080 = (int)NewDouble((double)-0xC0000000);
        else
        _7080 = - _prod__12485;
    }
    else {
        _7080 = unary_op(UMINUS, _prod__12485);
    }
    _7081 = (1 % _count__12486) ? NewDouble((double)1 / _count__12486) : (1 / _count__12486);
    if (IS_ATOM_INT(_7080) && IS_ATOM_INT(_7081)) {
        _7082 = power(_7080, _7081);
    }
    else {
        if (IS_ATOM_INT(_7080)) {
            temp_d.dbl = (double)_7080;
            _7082 = Dpower(&temp_d, DBL_PTR(_7081));
        }
        else {
            if (IS_ATOM_INT(_7081)) {
                temp_d.dbl = (double)_7081;
                _7082 = Dpower(DBL_PTR(_7080), &temp_d);
            }
            else
            _7082 = Dpower(DBL_PTR(_7080), DBL_PTR(_7081));
        }
    }
    DeRef(_7080);
    _7080 = NOVALUE;
    DeRef(_7081);
    _7081 = NOVALUE;
    DeRef(_data_set_12483);
    DeRef(_subseq_opt_12484);
    DeRef(_prod__12485);
    _7074 = NOVALUE;
    return _7082;
    goto L9; // [135] 153
L8: 

    /** 		return power(prod_, 1/count_)*/
    _7083 = (1 % _count__12486) ? NewDouble((double)1 / _count__12486) : (1 / _count__12486);
    if (IS_ATOM_INT(_prod__12485) && IS_ATOM_INT(_7083)) {
        _7084 = power(_prod__12485, _7083);
    }
    else {
        if (IS_ATOM_INT(_prod__12485)) {
            temp_d.dbl = (double)_prod__12485;
            _7084 = Dpower(&temp_d, DBL_PTR(_7083));
        }
        else {
            if (IS_ATOM_INT(_7083)) {
                temp_d.dbl = (double)_7083;
                _7084 = Dpower(DBL_PTR(_prod__12485), &temp_d);
            }
            else
            _7084 = Dpower(DBL_PTR(_prod__12485), DBL_PTR(_7083));
        }
    }
    DeRef(_7083);
    _7083 = NOVALUE;
    DeRef(_data_set_12483);
    DeRef(_subseq_opt_12484);
    DeRef(_prod__12485);
    _7074 = NOVALUE;
    DeRef(_7082);
    _7082 = NOVALUE;
    return _7084;
L9: 
    ;
}
int geomean() __attribute__ ((alias ("_35geomean")));


int _35harmean(int _data_set_12515, int _subseq_opt_12516)
{
    int _count__12517 = NOVALUE;
    int _y_12523 = NOVALUE;
    int _z_12524 = NOVALUE;
    int _x_12528 = NOVALUE;
    int _7099 = NOVALUE;
    int _7098 = NOVALUE;
    int _7094 = NOVALUE;
    int _7092 = NOVALUE;
    int _7090 = NOVALUE;
    int _7089 = NOVALUE;
    int _7088 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12515);
    Ref(_subseq_opt_12516);
    _0 = _data_set_12515;
    _data_set_12515 = _35massage(_data_set_12515, _subseq_opt_12516);
    DeRefDS(_0);

    /** 	count_ = length(data_set)*/
    if (IS_SEQUENCE(_data_set_12515)){
            _count__12517 = SEQ_PTR(_data_set_12515)->length;
    }
    else {
        _count__12517 = 1;
    }

    /** 	if count_ = 1 then*/
    if (_count__12517 != 1)
    goto L1; // [19] 34

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12515);
    _7088 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7088);
    DeRefDS(_data_set_12515);
    DeRef(_subseq_opt_12516);
    DeRef(_y_12523);
    DeRef(_z_12524);
    return _7088;
L1: 

    /** 	atom y = 0*/
    DeRef(_y_12523);
    _y_12523 = 0;

    /** 	atom z = 1*/
    DeRef(_z_12524);
    _z_12524 = 1;

    /** 	for i = 1 to count_ do*/
    _7089 = _count__12517;
    {
        int _i_12526;
        _i_12526 = 1;
L2: 
        if (_i_12526 > _7089){
            goto L3; // [49] 122
        }

        /** 		atom x = 1*/
        DeRef(_x_12528);
        _x_12528 = 1;

        /** 		z *= data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12515);
        _7090 = (int)*(((s1_ptr)_2)->base + _i_12526);
        _0 = _z_12524;
        if (IS_ATOM_INT(_z_12524) && IS_ATOM_INT(_7090)) {
            if (_z_12524 == (short)_z_12524 && _7090 <= INT15 && _7090 >= -INT15)
            _z_12524 = _z_12524 * _7090;
            else
            _z_12524 = NewDouble(_z_12524 * (double)_7090);
        }
        else {
            _z_12524 = binary_op(MULTIPLY, _z_12524, _7090);
        }
        DeRef(_0);
        _7090 = NOVALUE;

        /** 		for j = 1 to count_ do*/
        _7092 = _count__12517;
        {
            int _j_12532;
            _j_12532 = 1;
L4: 
            if (_j_12532 > _7092){
                goto L5; // [76] 107
            }

            /** 			if j != i then*/
            if (_j_12532 == _i_12526)
            goto L6; // [85] 100

            /** 				x *= data_set[j]*/
            _2 = (int)SEQ_PTR(_data_set_12515);
            _7094 = (int)*(((s1_ptr)_2)->base + _j_12532);
            _0 = _x_12528;
            if (IS_ATOM_INT(_x_12528) && IS_ATOM_INT(_7094)) {
                if (_x_12528 == (short)_x_12528 && _7094 <= INT15 && _7094 >= -INT15)
                _x_12528 = _x_12528 * _7094;
                else
                _x_12528 = NewDouble(_x_12528 * (double)_7094);
            }
            else {
                _x_12528 = binary_op(MULTIPLY, _x_12528, _7094);
            }
            DeRef(_0);
            _7094 = NOVALUE;
L6: 

            /** 		end for*/
            _j_12532 = _j_12532 + 1;
            goto L4; // [102] 83
L5: 
            ;
        }

        /** 		y += x*/
        _0 = _y_12523;
        if (IS_ATOM_INT(_y_12523) && IS_ATOM_INT(_x_12528)) {
            _y_12523 = _y_12523 + _x_12528;
            if ((long)((unsigned long)_y_12523 + (unsigned long)HIGH_BITS) >= 0) 
            _y_12523 = NewDouble((double)_y_12523);
        }
        else {
            if (IS_ATOM_INT(_y_12523)) {
                _y_12523 = NewDouble((double)_y_12523 + DBL_PTR(_x_12528)->dbl);
            }
            else {
                if (IS_ATOM_INT(_x_12528)) {
                    _y_12523 = NewDouble(DBL_PTR(_y_12523)->dbl + (double)_x_12528);
                }
                else
                _y_12523 = NewDouble(DBL_PTR(_y_12523)->dbl + DBL_PTR(_x_12528)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_x_12528);
        _x_12528 = NOVALUE;

        /** 	end for*/
        _i_12526 = _i_12526 + 1;
        goto L2; // [117] 56
L3: 
        ;
    }

    /**  	if y = 0 then*/
    if (binary_op_a(NOTEQ, _y_12523, 0)){
        goto L7; // [124] 135
    }

    /**  		return 0*/
    DeRefDS(_data_set_12515);
    DeRef(_subseq_opt_12516);
    DeRef(_y_12523);
    DeRef(_z_12524);
    _7088 = NOVALUE;
    return 0;
L7: 

    /**  	return count_ * z / y*/
    if (IS_ATOM_INT(_z_12524)) {
        if (_count__12517 == (short)_count__12517 && _z_12524 <= INT15 && _z_12524 >= -INT15)
        _7098 = _count__12517 * _z_12524;
        else
        _7098 = NewDouble(_count__12517 * (double)_z_12524);
    }
    else {
        _7098 = NewDouble((double)_count__12517 * DBL_PTR(_z_12524)->dbl);
    }
    if (IS_ATOM_INT(_7098) && IS_ATOM_INT(_y_12523)) {
        _7099 = (_7098 % _y_12523) ? NewDouble((double)_7098 / _y_12523) : (_7098 / _y_12523);
    }
    else {
        if (IS_ATOM_INT(_7098)) {
            _7099 = NewDouble((double)_7098 / DBL_PTR(_y_12523)->dbl);
        }
        else {
            if (IS_ATOM_INT(_y_12523)) {
                _7099 = NewDouble(DBL_PTR(_7098)->dbl / (double)_y_12523);
            }
            else
            _7099 = NewDouble(DBL_PTR(_7098)->dbl / DBL_PTR(_y_12523)->dbl);
        }
    }
    DeRef(_7098);
    _7098 = NOVALUE;
    DeRefDS(_data_set_12515);
    DeRef(_subseq_opt_12516);
    DeRef(_y_12523);
    DeRef(_z_12524);
    _7088 = NOVALUE;
    return _7099;
    ;
}
int harmean() __attribute__ ((alias ("_35harmean")));


int _35movavg(int _data_set_12545, int _period_delta_12546)
{
    int _result__12547 = NOVALUE;
    int _lLow_12548 = NOVALUE;
    int _lHigh_12549 = NOVALUE;
    int _j_12550 = NOVALUE;
    int _n_12551 = NOVALUE;
    int _count_2__tmp_at19_12559 = NOVALUE;
    int _count_1__tmp_at19_12558 = NOVALUE;
    int _count_inlined_count_at_19_12557 = NOVALUE;
    int _7136 = NOVALUE;
    int _7135 = NOVALUE;
    int _7131 = NOVALUE;
    int _7130 = NOVALUE;
    int _7129 = NOVALUE;
    int _7128 = NOVALUE;
    int _7127 = NOVALUE;
    int _7126 = NOVALUE;
    int _7125 = NOVALUE;
    int _7124 = NOVALUE;
    int _7122 = NOVALUE;
    int _7120 = NOVALUE;
    int _7119 = NOVALUE;
    int _7118 = NOVALUE;
    int _7117 = NOVALUE;
    int _7114 = NOVALUE;
    int _7113 = NOVALUE;
    int _7112 = NOVALUE;
    int _7111 = NOVALUE;
    int _7109 = NOVALUE;
    int _7108 = NOVALUE;
    int _7106 = NOVALUE;
    int _7104 = NOVALUE;
    int _7103 = NOVALUE;
    int _7100 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7100 = IS_ATOM(_data_set_12545);
    if (_7100 == 0)
    {
        _7100 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _7100 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12545;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12545);
    *((int *)(_2+4)) = _data_set_12545;
    _data_set_12545 = MAKE_SEQ(_1);
    DeRef(_0);
    goto L2; // [15] 61
L1: 

    /** 	elsif count(data_set) = 0 then*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at19_12558 = IS_ATOM(_data_set_12545);
    if (_count_1__tmp_at19_12558 == 0)
    {
        goto L3; // [25] 36
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_19_12557 = 1;
    goto L4; // [33] 47
L3: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12545);
    _0 = _count_2__tmp_at19_12559;
    _count_2__tmp_at19_12559 = _35massage(_data_set_12545, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at19_12559)){
            _count_inlined_count_at_19_12557 = SEQ_PTR(_count_2__tmp_at19_12559)->length;
    }
    else {
        _count_inlined_count_at_19_12557 = 1;
    }
L4: 
    DeRef(_count_2__tmp_at19_12559);
    _count_2__tmp_at19_12559 = NOVALUE;
    if (_count_inlined_count_at_19_12557 != 0)
    goto L5; // [49] 60

    /** 		return data_set*/
    DeRef(_period_delta_12546);
    DeRef(_result__12547);
    return _data_set_12545;
L5: 
L2: 

    /** 	if atom(period_delta) then*/
    _7103 = IS_ATOM(_period_delta_12546);
    if (_7103 == 0)
    {
        _7103 = NOVALUE;
        goto L6; // [66] 95
    }
    else{
        _7103 = NOVALUE;
    }

    /** 		if floor(period_delta) < 1 then*/
    if (IS_ATOM_INT(_period_delta_12546))
    _7104 = e_floor(_period_delta_12546);
    else
    _7104 = unary_op(FLOOR, _period_delta_12546);
    if (binary_op_a(GREATEREQ, _7104, 1)){
        DeRef(_7104);
        _7104 = NOVALUE;
        goto L7; // [74] 85
    }
    DeRef(_7104);
    _7104 = NOVALUE;

    /** 			return {}*/
    RefDS(_5);
    DeRef(_data_set_12545);
    DeRef(_period_delta_12546);
    DeRef(_result__12547);
    return _5;
L7: 

    /** 		period_delta = repeat(1, floor(period_delta))*/
    if (IS_ATOM_INT(_period_delta_12546))
    _7106 = e_floor(_period_delta_12546);
    else
    _7106 = unary_op(FLOOR, _period_delta_12546);
    DeRef(_period_delta_12546);
    _period_delta_12546 = Repeat(1, _7106);
    DeRef(_7106);
    _7106 = NOVALUE;
L6: 

    /** 	if length(data_set) < length(period_delta) then*/
    if (IS_SEQUENCE(_data_set_12545)){
            _7108 = SEQ_PTR(_data_set_12545)->length;
    }
    else {
        _7108 = 1;
    }
    if (IS_SEQUENCE(_period_delta_12546)){
            _7109 = SEQ_PTR(_period_delta_12546)->length;
    }
    else {
        _7109 = 1;
    }
    if (_7108 >= _7109)
    goto L8; // [103] 128

    /** 		data_set = repeat(0, length(period_delta) - length(data_set)) & data_set*/
    if (IS_SEQUENCE(_period_delta_12546)){
            _7111 = SEQ_PTR(_period_delta_12546)->length;
    }
    else {
        _7111 = 1;
    }
    if (IS_SEQUENCE(_data_set_12545)){
            _7112 = SEQ_PTR(_data_set_12545)->length;
    }
    else {
        _7112 = 1;
    }
    _7113 = _7111 - _7112;
    _7111 = NOVALUE;
    _7112 = NOVALUE;
    _7114 = Repeat(0, _7113);
    _7113 = NOVALUE;
    if (IS_SEQUENCE(_7114) && IS_ATOM(_data_set_12545)) {
        Ref(_data_set_12545);
        Append(&_data_set_12545, _7114, _data_set_12545);
    }
    else if (IS_ATOM(_7114) && IS_SEQUENCE(_data_set_12545)) {
    }
    else {
        Concat((object_ptr)&_data_set_12545, _7114, _data_set_12545);
        DeRefDS(_7114);
        _7114 = NOVALUE;
    }
    DeRef(_7114);
    _7114 = NOVALUE;
L8: 

    /** 	lLow = 1*/
    _lLow_12548 = 1;

    /** 	lHigh = length(period_delta)*/
    if (IS_SEQUENCE(_period_delta_12546)){
            _lHigh_12549 = SEQ_PTR(_period_delta_12546)->length;
    }
    else {
        _lHigh_12549 = 1;
    }

    /** 	result_ = repeat(0, length(data_set) - length(period_delta) + 1)*/
    if (IS_SEQUENCE(_data_set_12545)){
            _7117 = SEQ_PTR(_data_set_12545)->length;
    }
    else {
        _7117 = 1;
    }
    if (IS_SEQUENCE(_period_delta_12546)){
            _7118 = SEQ_PTR(_period_delta_12546)->length;
    }
    else {
        _7118 = 1;
    }
    _7119 = _7117 - _7118;
    _7117 = NOVALUE;
    _7118 = NOVALUE;
    _7120 = _7119 + 1;
    _7119 = NOVALUE;
    DeRef(_result__12547);
    _result__12547 = Repeat(0, _7120);
    _7120 = NOVALUE;

    /** 	while lHigh <= length(data_set) do*/
L9: 
    if (IS_SEQUENCE(_data_set_12545)){
            _7122 = SEQ_PTR(_data_set_12545)->length;
    }
    else {
        _7122 = 1;
    }
    if (_lHigh_12549 > _7122)
    goto LA; // [166] 297

    /** 		j = 1*/
    _j_12550 = 1;

    /** 		n = 0*/
    _n_12551 = 0;

    /** 		for i = lLow to lHigh do*/
    _7124 = _lHigh_12549;
    {
        int _i_12587;
        _i_12587 = _lLow_12548;
LB: 
        if (_i_12587 > _7124){
            goto LC; // [185] 250
        }

        /** 			if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12545);
        _7125 = (int)*(((s1_ptr)_2)->base + _i_12587);
        _7126 = IS_ATOM(_7125);
        _7125 = NOVALUE;
        if (_7126 == 0)
        {
            _7126 = NOVALUE;
            goto LD; // [201] 237
        }
        else{
            _7126 = NOVALUE;
        }

        /** 				result_[lLow] += data_set[i] * period_delta[j]*/
        _2 = (int)SEQ_PTR(_data_set_12545);
        _7127 = (int)*(((s1_ptr)_2)->base + _i_12587);
        _2 = (int)SEQ_PTR(_period_delta_12546);
        _7128 = (int)*(((s1_ptr)_2)->base + _j_12550);
        if (IS_ATOM_INT(_7127) && IS_ATOM_INT(_7128)) {
            if (_7127 == (short)_7127 && _7128 <= INT15 && _7128 >= -INT15)
            _7129 = _7127 * _7128;
            else
            _7129 = NewDouble(_7127 * (double)_7128);
        }
        else {
            _7129 = binary_op(MULTIPLY, _7127, _7128);
        }
        _7127 = NOVALUE;
        _7128 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__12547);
        _7130 = (int)*(((s1_ptr)_2)->base + _lLow_12548);
        if (IS_ATOM_INT(_7130) && IS_ATOM_INT(_7129)) {
            _7131 = _7130 + _7129;
            if ((long)((unsigned long)_7131 + (unsigned long)HIGH_BITS) >= 0) 
            _7131 = NewDouble((double)_7131);
        }
        else {
            _7131 = binary_op(PLUS, _7130, _7129);
        }
        _7130 = NOVALUE;
        DeRef(_7129);
        _7129 = NOVALUE;
        _2 = (int)SEQ_PTR(_result__12547);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _result__12547 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lLow_12548);
        _1 = *(int *)_2;
        *(int *)_2 = _7131;
        if( _1 != _7131 ){
            DeRef(_1);
        }
        _7131 = NOVALUE;

        /** 				n += 1*/
        _n_12551 = _n_12551 + 1;
LD: 

        /** 			j += 1*/
        _j_12550 = _j_12550 + 1;

        /** 		end for*/
        _i_12587 = _i_12587 + 1;
        goto LB; // [245] 192
LC: 
        ;
    }

    /** 		if n > 0 then*/
    if (_n_12551 <= 0)
    goto LE; // [252] 273

    /** 			result_[lLow] /= n*/
    _2 = (int)SEQ_PTR(_result__12547);
    _7135 = (int)*(((s1_ptr)_2)->base + _lLow_12548);
    if (IS_ATOM_INT(_7135)) {
        _7136 = (_7135 % _n_12551) ? NewDouble((double)_7135 / _n_12551) : (_7135 / _n_12551);
    }
    else {
        _7136 = binary_op(DIVIDE, _7135, _n_12551);
    }
    _7135 = NOVALUE;
    _2 = (int)SEQ_PTR(_result__12547);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12547 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lLow_12548);
    _1 = *(int *)_2;
    *(int *)_2 = _7136;
    if( _1 != _7136 ){
        DeRef(_1);
    }
    _7136 = NOVALUE;
    goto LF; // [270] 280
LE: 

    /** 			result_[lLow] = 0*/
    _2 = (int)SEQ_PTR(_result__12547);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _result__12547 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _lLow_12548);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
LF: 

    /** 		lLow += 1*/
    _lLow_12548 = _lLow_12548 + 1;

    /** 		lHigh += 1*/
    _lHigh_12549 = _lHigh_12549 + 1;

    /** 	end while*/
    goto L9; // [294] 163
LA: 

    /** 	return result_*/
    DeRef(_data_set_12545);
    DeRef(_period_delta_12546);
    return _result__12547;
    ;
}
int movavg() __attribute__ ((alias ("_35movavg")));


int _35emovavg(int _data_set_12608, int _smoothing_factor_12609)
{
    int _lPrev_12610 = NOVALUE;
    int _count_2__tmp_at19_12618 = NOVALUE;
    int _count_1__tmp_at19_12617 = NOVALUE;
    int _count_inlined_count_at_19_12616 = NOVALUE;
    int _count_2__tmp_at81_12627 = NOVALUE;
    int _count_1__tmp_at81_12626 = NOVALUE;
    int _count_inlined_count_at_81_12625 = NOVALUE;
    int _7154 = NOVALUE;
    int _7153 = NOVALUE;
    int _7152 = NOVALUE;
    int _7151 = NOVALUE;
    int _7150 = NOVALUE;
    int _7149 = NOVALUE;
    int _7148 = NOVALUE;
    int _7145 = NOVALUE;
    int _7144 = NOVALUE;
    int _7142 = NOVALUE;
    int _7139 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7139 = IS_ATOM(_data_set_12608);
    if (_7139 == 0)
    {
        _7139 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _7139 = NOVALUE;
    }

    /** 		data_set = {data_set}*/
    _0 = _data_set_12608;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_set_12608);
    *((int *)(_2+4)) = _data_set_12608;
    _data_set_12608 = MAKE_SEQ(_1);
    DeRef(_0);
    goto L2; // [15] 61
L1: 

    /** 	elsif count(data_set) = 0 then*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at19_12617 = IS_ATOM(_data_set_12608);
    if (_count_1__tmp_at19_12617 == 0)
    {
        goto L3; // [25] 36
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_19_12616 = 1;
    goto L4; // [33] 47
L3: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12608);
    _0 = _count_2__tmp_at19_12618;
    _count_2__tmp_at19_12618 = _35massage(_data_set_12608, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at19_12618)){
            _count_inlined_count_at_19_12616 = SEQ_PTR(_count_2__tmp_at19_12618)->length;
    }
    else {
        _count_inlined_count_at_19_12616 = 1;
    }
L4: 
    DeRef(_count_2__tmp_at19_12618);
    _count_2__tmp_at19_12618 = NOVALUE;
    if (_count_inlined_count_at_19_12616 != 0)
    goto L5; // [49] 60

    /** 		return data_set*/
    DeRef(_smoothing_factor_12609);
    DeRef(_lPrev_12610);
    return _data_set_12608;
L5: 
L2: 

    /** 	if smoothing_factor < 0 or smoothing_factor > 1 then*/
    if (IS_ATOM_INT(_smoothing_factor_12609)) {
        _7142 = (_smoothing_factor_12609 < 0);
    }
    else {
        _7142 = (DBL_PTR(_smoothing_factor_12609)->dbl < (double)0);
    }
    if (_7142 != 0) {
        goto L6; // [67] 80
    }
    if (IS_ATOM_INT(_smoothing_factor_12609)) {
        _7144 = (_smoothing_factor_12609 > 1);
    }
    else {
        _7144 = (DBL_PTR(_smoothing_factor_12609)->dbl > (double)1);
    }
    if (_7144 == 0)
    {
        DeRef(_7144);
        _7144 = NOVALUE;
        goto L7; // [76] 120
    }
    else{
        DeRef(_7144);
        _7144 = NOVALUE;
    }
L6: 

    /** 		smoothing_factor = (2 / (count(data_set) + 1))*/

    /** 	if atom(data_set) then*/
    _count_1__tmp_at81_12626 = IS_ATOM(_data_set_12608);
    if (_count_1__tmp_at81_12626 == 0)
    {
        goto L8; // [87] 98
    }
    else{
    }

    /** 		return 1*/
    _count_inlined_count_at_81_12625 = 1;
    goto L9; // [95] 109
L8: 

    /** 	return length(massage(data_set, subseq_opt))*/
    Ref(_data_set_12608);
    _0 = _count_2__tmp_at81_12627;
    _count_2__tmp_at81_12627 = _35massage(_data_set_12608, 1);
    DeRef(_0);
    if (IS_SEQUENCE(_count_2__tmp_at81_12627)){
            _count_inlined_count_at_81_12625 = SEQ_PTR(_count_2__tmp_at81_12627)->length;
    }
    else {
        _count_inlined_count_at_81_12625 = 1;
    }
L9: 
    DeRef(_count_2__tmp_at81_12627);
    _count_2__tmp_at81_12627 = NOVALUE;
    _7145 = _count_inlined_count_at_81_12625 + 1;
    DeRef(_smoothing_factor_12609);
    _smoothing_factor_12609 = (2 % _7145) ? NewDouble((double)2 / _7145) : (2 / _7145);
    _7145 = NOVALUE;
L7: 

    /** 	lPrev = average(data_set)*/
    Ref(_data_set_12608);
    _0 = _lPrev_12610;
    _lPrev_12610 = _35average(_data_set_12608, 1);
    DeRef(_0);

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12608)){
            _7148 = SEQ_PTR(_data_set_12608)->length;
    }
    else {
        _7148 = 1;
    }
    {
        int _i_12632;
        _i_12632 = 1;
LA: 
        if (_i_12632 > _7148){
            goto LB; // [132] 187
        }

        /** 		if atom(data_set[i]) then*/
        _2 = (int)SEQ_PTR(_data_set_12608);
        _7149 = (int)*(((s1_ptr)_2)->base + _i_12632);
        _7150 = IS_ATOM(_7149);
        _7149 = NOVALUE;
        if (_7150 == 0)
        {
            _7150 = NOVALUE;
            goto LC; // [148] 180
        }
        else{
            _7150 = NOVALUE;
        }

        /** 			data_set[i] = (data_set[i] - lPrev) * smoothing_factor + lPrev*/
        _2 = (int)SEQ_PTR(_data_set_12608);
        _7151 = (int)*(((s1_ptr)_2)->base + _i_12632);
        if (IS_ATOM_INT(_7151) && IS_ATOM_INT(_lPrev_12610)) {
            _7152 = _7151 - _lPrev_12610;
            if ((long)((unsigned long)_7152 +(unsigned long) HIGH_BITS) >= 0){
                _7152 = NewDouble((double)_7152);
            }
        }
        else {
            _7152 = binary_op(MINUS, _7151, _lPrev_12610);
        }
        _7151 = NOVALUE;
        if (IS_ATOM_INT(_7152) && IS_ATOM_INT(_smoothing_factor_12609)) {
            if (_7152 == (short)_7152 && _smoothing_factor_12609 <= INT15 && _smoothing_factor_12609 >= -INT15)
            _7153 = _7152 * _smoothing_factor_12609;
            else
            _7153 = NewDouble(_7152 * (double)_smoothing_factor_12609);
        }
        else {
            _7153 = binary_op(MULTIPLY, _7152, _smoothing_factor_12609);
        }
        DeRef(_7152);
        _7152 = NOVALUE;
        if (IS_ATOM_INT(_7153) && IS_ATOM_INT(_lPrev_12610)) {
            _7154 = _7153 + _lPrev_12610;
            if ((long)((unsigned long)_7154 + (unsigned long)HIGH_BITS) >= 0) 
            _7154 = NewDouble((double)_7154);
        }
        else {
            _7154 = binary_op(PLUS, _7153, _lPrev_12610);
        }
        DeRef(_7153);
        _7153 = NOVALUE;
        _2 = (int)SEQ_PTR(_data_set_12608);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _data_set_12608 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12632);
        _1 = *(int *)_2;
        *(int *)_2 = _7154;
        if( _1 != _7154 ){
            DeRef(_1);
        }
        _7154 = NOVALUE;

        /** 			lPrev = data_set[i]*/
        DeRef(_lPrev_12610);
        _2 = (int)SEQ_PTR(_data_set_12608);
        _lPrev_12610 = (int)*(((s1_ptr)_2)->base + _i_12632);
        Ref(_lPrev_12610);
LC: 

        /** 	end for*/
        _i_12632 = _i_12632 + 1;
        goto LA; // [182] 139
LB: 
        ;
    }

    /** 	return data_set*/
    DeRef(_smoothing_factor_12609);
    DeRef(_lPrev_12610);
    DeRef(_7142);
    _7142 = NOVALUE;
    return _data_set_12608;
    ;
}
int emovavg() __attribute__ ((alias ("_35emovavg")));


int _35median(int _data_set_12644, int _subseq_opt_12645)
{
    int _7167 = NOVALUE;
    int _7166 = NOVALUE;
    int _7165 = NOVALUE;
    int _7164 = NOVALUE;
    int _7162 = NOVALUE;
    int _7160 = NOVALUE;
    int _7158 = NOVALUE;
    int _7156 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7156 = IS_ATOM(_data_set_12644);
    if (_7156 == 0)
    {
        _7156 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7156 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12645);
    return _data_set_12644;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12644);
    Ref(_subseq_opt_12645);
    _0 = _data_set_12644;
    _data_set_12644 = _35massage(_data_set_12644, _subseq_opt_12645);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12644)){
            _7158 = SEQ_PTR(_data_set_12644)->length;
    }
    else {
        _7158 = 1;
    }
    if (_7158 != 0)
    goto L2; // [28] 39

    /** 		return data_set*/
    DeRef(_subseq_opt_12645);
    return _data_set_12644;
L2: 

    /** 	if length(data_set) < 3 then*/
    if (IS_SEQUENCE(_data_set_12644)){
            _7160 = SEQ_PTR(_data_set_12644)->length;
    }
    else {
        _7160 = 1;
    }
    if (_7160 >= 3)
    goto L3; // [44] 59

    /** 		return data_set[1]*/
    _2 = (int)SEQ_PTR(_data_set_12644);
    _7162 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_7162);
    DeRef(_data_set_12644);
    DeRef(_subseq_opt_12645);
    return _7162;
L3: 

    /** 	data_set = stdsort:sort(data_set)*/
    Ref(_data_set_12644);
    _0 = _data_set_12644;
    _data_set_12644 = _24sort(_data_set_12644, 1);
    DeRef(_0);

    /** 	return data_set[ floor((length(data_set) + 1) / 2) ]*/
    if (IS_SEQUENCE(_data_set_12644)){
            _7164 = SEQ_PTR(_data_set_12644)->length;
    }
    else {
        _7164 = 1;
    }
    _7165 = _7164 + 1;
    _7164 = NOVALUE;
    _7166 = _7165 >> 1;
    _7165 = NOVALUE;
    _2 = (int)SEQ_PTR(_data_set_12644);
    _7167 = (int)*(((s1_ptr)_2)->base + _7166);
    Ref(_7167);
    DeRef(_data_set_12644);
    DeRef(_subseq_opt_12645);
    _7162 = NOVALUE;
    _7166 = NOVALUE;
    return _7167;
    ;
}
int median() __attribute__ ((alias ("_35median")));


int _35raw_frequency(int _data_set_12663, int _subseq_opt_12664)
{
    int _lCounts_12665 = NOVALUE;
    int _lKeys_12666 = NOVALUE;
    int _lNew_12667 = NOVALUE;
    int _lPos_12668 = NOVALUE;
    int _lMax_12669 = NOVALUE;
    int _7196 = NOVALUE;
    int _7195 = NOVALUE;
    int _7194 = NOVALUE;
    int _7193 = NOVALUE;
    int _7191 = NOVALUE;
    int _7189 = NOVALUE;
    int _7188 = NOVALUE;
    int _7186 = NOVALUE;
    int _7182 = NOVALUE;
    int _7181 = NOVALUE;
    int _7179 = NOVALUE;
    int _7177 = NOVALUE;
    int _7176 = NOVALUE;
    int _7175 = NOVALUE;
    int _7174 = NOVALUE;
    int _7172 = NOVALUE;
    int _7170 = NOVALUE;
    int _7169 = NOVALUE;
    int _7168 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lNew = 0*/
    _lNew_12667 = 0;

    /** 	integer lMax = -1*/
    _lMax_12669 = -1;

    /** 	if atom(data_set) then*/
    _7168 = IS_ATOM(_data_set_12663);
    if (_7168 == 0)
    {
        _7168 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _7168 = NOVALUE;
    }

    /** 		return {{1,data_set}}*/
    Ref(_data_set_12663);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _data_set_12663;
    _7169 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _7169;
    _7170 = MAKE_SEQ(_1);
    _7169 = NOVALUE;
    DeRef(_data_set_12663);
    DeRef(_subseq_opt_12664);
    DeRef(_lCounts_12665);
    DeRef(_lKeys_12666);
    return _7170;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12663);
    Ref(_subseq_opt_12664);
    _0 = _data_set_12663;
    _data_set_12663 = _35massage(_data_set_12663, _subseq_opt_12664);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12663)){
            _7172 = SEQ_PTR(_data_set_12663)->length;
    }
    else {
        _7172 = 1;
    }
    if (_7172 != 0)
    goto L2; // [46] 65

    /** 		return {{1,data_set}}*/
    Ref(_data_set_12663);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _data_set_12663;
    _7174 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _7174;
    _7175 = MAKE_SEQ(_1);
    _7174 = NOVALUE;
    DeRef(_data_set_12663);
    DeRef(_subseq_opt_12664);
    DeRef(_lCounts_12665);
    DeRef(_lKeys_12666);
    DeRef(_7170);
    _7170 = NOVALUE;
    return _7175;
L2: 

    /** 	lCounts = repeat({0,0}, length(data_set))*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7176 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_data_set_12663)){
            _7177 = SEQ_PTR(_data_set_12663)->length;
    }
    else {
        _7177 = 1;
    }
    DeRef(_lCounts_12665);
    _lCounts_12665 = Repeat(_7176, _7177);
    DeRefDS(_7176);
    _7176 = NOVALUE;
    _7177 = NOVALUE;

    /** 	lKeys   = repeat(0, length(data_set))*/
    if (IS_SEQUENCE(_data_set_12663)){
            _7179 = SEQ_PTR(_data_set_12663)->length;
    }
    else {
        _7179 = 1;
    }
    DeRef(_lKeys_12666);
    _lKeys_12666 = Repeat(0, _7179);
    _7179 = NOVALUE;

    /** 	for i = 1 to length(data_set) do*/
    if (IS_SEQUENCE(_data_set_12663)){
            _7181 = SEQ_PTR(_data_set_12663)->length;
    }
    else {
        _7181 = 1;
    }
    {
        int _i_12686;
        _i_12686 = 1;
L3: 
        if (_i_12686 > _7181){
            goto L4; // [92] 191
        }

        /** 		lPos = find(data_set[i], lKeys)*/
        _2 = (int)SEQ_PTR(_data_set_12663);
        _7182 = (int)*(((s1_ptr)_2)->base + _i_12686);
        _lPos_12668 = find_from(_7182, _lKeys_12666, 1);
        _7182 = NOVALUE;

        /** 		if lPos = 0 then*/
        if (_lPos_12668 != 0)
        goto L5; // [112] 165

        /** 			lNew += 1*/
        _lNew_12667 = _lNew_12667 + 1;

        /** 			lPos = lNew*/
        _lPos_12668 = _lNew_12667;

        /** 			lCounts[lPos][2] = data_set[i]*/
        _2 = (int)SEQ_PTR(_lCounts_12665);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lCounts_12665 = MAKE_SEQ(_2);
        }
        _3 = (int)(_lPos_12668 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_data_set_12663);
        _7188 = (int)*(((s1_ptr)_2)->base + _i_12686);
        Ref(_7188);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7188;
        if( _1 != _7188 ){
            DeRef(_1);
        }
        _7188 = NOVALUE;
        _7186 = NOVALUE;

        /** 			lKeys[lPos] = data_set[i]*/
        _2 = (int)SEQ_PTR(_data_set_12663);
        _7189 = (int)*(((s1_ptr)_2)->base + _i_12686);
        Ref(_7189);
        _2 = (int)SEQ_PTR(_lKeys_12666);
        _2 = (int)(((s1_ptr)_2)->base + _lPos_12668);
        _1 = *(int *)_2;
        *(int *)_2 = _7189;
        if( _1 != _7189 ){
            DeRef(_1);
        }
        _7189 = NOVALUE;

        /** 			if lPos > lMax then*/
        if (_lPos_12668 <= _lMax_12669)
        goto L6; // [154] 164

        /** 				lMax = lPos*/
        _lMax_12669 = _lPos_12668;
L6: 
L5: 

        /** 		lCounts[lPos][1] += 1*/
        _2 = (int)SEQ_PTR(_lCounts_12665);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _lCounts_12665 = MAKE_SEQ(_2);
        }
        _3 = (int)(_lPos_12668 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7193 = (int)*(((s1_ptr)_2)->base + 1);
        _7191 = NOVALUE;
        if (IS_ATOM_INT(_7193)) {
            _7194 = _7193 + 1;
            if (_7194 > MAXINT){
                _7194 = NewDouble((double)_7194);
            }
        }
        else
        _7194 = binary_op(PLUS, 1, _7193);
        _7193 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7194;
        if( _1 != _7194 ){
            DeRef(_1);
        }
        _7194 = NOVALUE;
        _7191 = NOVALUE;

        /** 	end for*/
        _i_12686 = _i_12686 + 1;
        goto L3; // [186] 99
L4: 
        ;
    }

    /** 	return stdsort:sort(lCounts[1..lMax], stdsort:DESCENDING)*/
    rhs_slice_target = (object_ptr)&_7195;
    RHS_Slice(_lCounts_12665, 1, _lMax_12669);
    _7196 = _24sort(_7195, -1);
    _7195 = NOVALUE;
    DeRef(_data_set_12663);
    DeRef(_subseq_opt_12664);
    DeRefDS(_lCounts_12665);
    DeRef(_lKeys_12666);
    DeRef(_7170);
    _7170 = NOVALUE;
    DeRef(_7175);
    _7175 = NOVALUE;
    return _7196;
    ;
}
int raw_frequency() __attribute__ ((alias ("_35raw_frequency")));


int _35mode(int _data_set_12707, int _subseq_opt_12708)
{
    int _lCounts_12709 = NOVALUE;
    int _lRes_12710 = NOVALUE;
    int _7211 = NOVALUE;
    int _7210 = NOVALUE;
    int _7208 = NOVALUE;
    int _7207 = NOVALUE;
    int _7206 = NOVALUE;
    int _7205 = NOVALUE;
    int _7204 = NOVALUE;
    int _7202 = NOVALUE;
    int _7201 = NOVALUE;
    int _7198 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12707);
    Ref(_subseq_opt_12708);
    _0 = _data_set_12707;
    _data_set_12707 = _35massage(_data_set_12707, _subseq_opt_12708);
    DeRefDS(_0);

    /** 	if not length( data_set ) then*/
    if (IS_SEQUENCE(_data_set_12707)){
            _7198 = SEQ_PTR(_data_set_12707)->length;
    }
    else {
        _7198 = 1;
    }
    if (_7198 != 0)
    goto L1; // [17] 27
    _7198 = NOVALUE;

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_data_set_12707);
    DeRef(_subseq_opt_12708);
    DeRef(_lCounts_12709);
    DeRef(_lRes_12710);
    return _5;
L1: 

    /** 	lCounts = raw_frequency(data_set, subseq_opt)*/
    RefDS(_data_set_12707);
    Ref(_subseq_opt_12708);
    _0 = _lCounts_12709;
    _lCounts_12709 = _35raw_frequency(_data_set_12707, _subseq_opt_12708);
    DeRef(_0);

    /** 	lRes = {lCounts[1][2]}*/
    _2 = (int)SEQ_PTR(_lCounts_12709);
    _7201 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_7201);
    _7202 = (int)*(((s1_ptr)_2)->base + 2);
    _7201 = NOVALUE;
    _0 = _lRes_12710;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7202);
    *((int *)(_2+4)) = _7202;
    _lRes_12710 = MAKE_SEQ(_1);
    DeRef(_0);
    _7202 = NOVALUE;

    /** 	for i = 2 to length(lCounts) do*/
    if (IS_SEQUENCE(_lCounts_12709)){
            _7204 = SEQ_PTR(_lCounts_12709)->length;
    }
    else {
        _7204 = 1;
    }
    {
        int _i_12720;
        _i_12720 = 2;
L2: 
        if (_i_12720 > _7204){
            goto L3; // [55] 110
        }

        /** 		if lCounts[i][1] < lCounts[1][1] then*/
        _2 = (int)SEQ_PTR(_lCounts_12709);
        _7205 = (int)*(((s1_ptr)_2)->base + _i_12720);
        _2 = (int)SEQ_PTR(_7205);
        _7206 = (int)*(((s1_ptr)_2)->base + 1);
        _7205 = NOVALUE;
        _2 = (int)SEQ_PTR(_lCounts_12709);
        _7207 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_7207);
        _7208 = (int)*(((s1_ptr)_2)->base + 1);
        _7207 = NOVALUE;
        if (binary_op_a(GREATEREQ, _7206, _7208)){
            _7206 = NOVALUE;
            _7208 = NOVALUE;
            goto L4; // [80] 89
        }
        _7206 = NOVALUE;
        _7208 = NOVALUE;

        /** 			exit*/
        goto L3; // [86] 110
L4: 

        /** 		lRes = append(lRes, lCounts[i][2])*/
        _2 = (int)SEQ_PTR(_lCounts_12709);
        _7210 = (int)*(((s1_ptr)_2)->base + _i_12720);
        _2 = (int)SEQ_PTR(_7210);
        _7211 = (int)*(((s1_ptr)_2)->base + 2);
        _7210 = NOVALUE;
        Ref(_7211);
        Append(&_lRes_12710, _lRes_12710, _7211);
        _7211 = NOVALUE;

        /** 	end for*/
        _i_12720 = _i_12720 + 1;
        goto L2; // [105] 62
L3: 
        ;
    }

    /** 	return lRes*/
    DeRefDS(_data_set_12707);
    DeRef(_subseq_opt_12708);
    DeRef(_lCounts_12709);
    return _lRes_12710;
    ;
}
int mode() __attribute__ ((alias ("_35mode")));


int _35central_moment(int _data_set_12733, int _datum_12734, int _order_mag_12735, int _subseq_opt_12736)
{
    int _lMean_12737 = NOVALUE;
    int _7218 = NOVALUE;
    int _7217 = NOVALUE;
    int _7214 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_mag_12735)) {
        _1 = (long)(DBL_PTR(_order_mag_12735)->dbl);
        DeRefDS(_order_mag_12735);
        _order_mag_12735 = _1;
    }

    /** 	data_set = massage(data_set, subseq_opt)*/
    RefDS(_data_set_12733);
    Ref(_subseq_opt_12736);
    _0 = _data_set_12733;
    _data_set_12733 = _35massage(_data_set_12733, _subseq_opt_12736);
    DeRefDS(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12733)){
            _7214 = SEQ_PTR(_data_set_12733)->length;
    }
    else {
        _7214 = 1;
    }
    if (_7214 != 0)
    goto L1; // [19] 30

    /** 		return 0*/
    DeRefDS(_data_set_12733);
    DeRef(_datum_12734);
    DeRef(_subseq_opt_12736);
    DeRef(_lMean_12737);
    return 0;
L1: 

    /** 	lMean = average(data_set)*/
    RefDS(_data_set_12733);
    _0 = _lMean_12737;
    _lMean_12737 = _35average(_data_set_12733, 1);
    DeRef(_0);

    /** 	return power( datum - lMean, order_mag)*/
    if (IS_ATOM_INT(_datum_12734) && IS_ATOM_INT(_lMean_12737)) {
        _7217 = _datum_12734 - _lMean_12737;
        if ((long)((unsigned long)_7217 +(unsigned long) HIGH_BITS) >= 0){
            _7217 = NewDouble((double)_7217);
        }
    }
    else {
        _7217 = binary_op(MINUS, _datum_12734, _lMean_12737);
    }
    if (IS_ATOM_INT(_7217)) {
        _7218 = power(_7217, _order_mag_12735);
    }
    else {
        _7218 = binary_op(POWER, _7217, _order_mag_12735);
    }
    DeRef(_7217);
    _7217 = NOVALUE;
    DeRefDS(_data_set_12733);
    DeRef(_datum_12734);
    DeRef(_subseq_opt_12736);
    DeRef(_lMean_12737);
    return _7218;
    ;
}
int central_moment() __attribute__ ((alias ("_35central_moment")));


int _35sum_central_moments(int _data_set_12747, int _order_mag_12748, int _subseq_opt_12749)
{
    int _7220 = NOVALUE;
    int _7219 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_order_mag_12748)) {
        _1 = (long)(DBL_PTR(_order_mag_12748)->dbl);
        DeRefDS(_order_mag_12748);
        _order_mag_12748 = _1;
    }

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12747);
    Ref(_data_set_12747);
    Ref(_subseq_opt_12749);
    _7219 = _35central_moment(_data_set_12747, _data_set_12747, _order_mag_12748, _subseq_opt_12749);
    _7220 = _35sum(_7219, 1);
    _7219 = NOVALUE;
    DeRef(_data_set_12747);
    DeRef(_subseq_opt_12749);
    return _7220;
    ;
}
int sum_central_moments() __attribute__ ((alias ("_35sum_central_moments")));


int _35skewness(int _data_set_12754, int _subseq_opt_12755)
{
    int _sum_central_moments_1__tmp_at40_12764 = NOVALUE;
    int _sum_central_moments_inlined_sum_central_moments_at_40_12763 = NOVALUE;
    int _7230 = NOVALUE;
    int _7229 = NOVALUE;
    int _7228 = NOVALUE;
    int _7227 = NOVALUE;
    int _7226 = NOVALUE;
    int _7225 = NOVALUE;
    int _7223 = NOVALUE;
    int _7221 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7221 = IS_ATOM(_data_set_12754);
    if (_7221 == 0)
    {
        _7221 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7221 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12755);
    return _data_set_12754;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12754);
    Ref(_subseq_opt_12755);
    _0 = _data_set_12754;
    _data_set_12754 = _35massage(_data_set_12754, _subseq_opt_12755);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12754)){
            _7223 = SEQ_PTR(_data_set_12754)->length;
    }
    else {
        _7223 = 1;
    }
    if (_7223 != 0)
    goto L2; // [28] 39

    /** 		return data_set*/
    DeRef(_subseq_opt_12755);
    return _data_set_12754;
L2: 

    /** 	return sum_central_moments(data_set, 3) / ((length(data_set) - 1) * power(stdev(data_set), 3))*/

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12754);
    Ref(_data_set_12754);
    _0 = _sum_central_moments_1__tmp_at40_12764;
    _sum_central_moments_1__tmp_at40_12764 = _35central_moment(_data_set_12754, _data_set_12754, 3, 1);
    DeRef(_0);
    Ref(_sum_central_moments_1__tmp_at40_12764);
    _0 = _sum_central_moments_inlined_sum_central_moments_at_40_12763;
    _sum_central_moments_inlined_sum_central_moments_at_40_12763 = _35sum(_sum_central_moments_1__tmp_at40_12764, 1);
    DeRef(_0);
    DeRef(_sum_central_moments_1__tmp_at40_12764);
    _sum_central_moments_1__tmp_at40_12764 = NOVALUE;
    if (IS_SEQUENCE(_data_set_12754)){
            _7225 = SEQ_PTR(_data_set_12754)->length;
    }
    else {
        _7225 = 1;
    }
    _7226 = _7225 - 1;
    _7225 = NOVALUE;
    Ref(_data_set_12754);
    _7227 = _35stdev(_data_set_12754, 1, 2);
    if (IS_ATOM_INT(_7227)) {
        _7228 = power(_7227, 3);
    }
    else {
        _7228 = binary_op(POWER, _7227, 3);
    }
    DeRef(_7227);
    _7227 = NOVALUE;
    if (IS_ATOM_INT(_7228)) {
        if (_7226 == (short)_7226 && _7228 <= INT15 && _7228 >= -INT15)
        _7229 = _7226 * _7228;
        else
        _7229 = NewDouble(_7226 * (double)_7228);
    }
    else {
        _7229 = binary_op(MULTIPLY, _7226, _7228);
    }
    _7226 = NOVALUE;
    DeRef(_7228);
    _7228 = NOVALUE;
    if (IS_ATOM_INT(_sum_central_moments_inlined_sum_central_moments_at_40_12763) && IS_ATOM_INT(_7229)) {
        _7230 = (_sum_central_moments_inlined_sum_central_moments_at_40_12763 % _7229) ? NewDouble((double)_sum_central_moments_inlined_sum_central_moments_at_40_12763 / _7229) : (_sum_central_moments_inlined_sum_central_moments_at_40_12763 / _7229);
    }
    else {
        _7230 = binary_op(DIVIDE, _sum_central_moments_inlined_sum_central_moments_at_40_12763, _7229);
    }
    DeRef(_7229);
    _7229 = NOVALUE;
    DeRef(_data_set_12754);
    DeRef(_subseq_opt_12755);
    return _7230;
    ;
}
int skewness() __attribute__ ((alias ("_35skewness")));


int _35kurtosis(int _data_set_12773, int _subseq_opt_12774)
{
    int _sd_12775 = NOVALUE;
    int _sum_central_moments_1__tmp_at65_12789 = NOVALUE;
    int _sum_central_moments_inlined_sum_central_moments_at_65_12788 = NOVALUE;
    int _7245 = NOVALUE;
    int _7244 = NOVALUE;
    int _7243 = NOVALUE;
    int _7242 = NOVALUE;
    int _7241 = NOVALUE;
    int _7240 = NOVALUE;
    int _7239 = NOVALUE;
    int _7235 = NOVALUE;
    int _7233 = NOVALUE;
    int _7231 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(data_set) then*/
    _7231 = IS_ATOM(_data_set_12773);
    if (_7231 == 0)
    {
        _7231 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _7231 = NOVALUE;
    }

    /** 		return data_set*/
    DeRef(_subseq_opt_12774);
    DeRef(_sd_12775);
    return _data_set_12773;
L1: 

    /** 	data_set = massage(data_set, subseq_opt)*/
    Ref(_data_set_12773);
    Ref(_subseq_opt_12774);
    _0 = _data_set_12773;
    _data_set_12773 = _35massage(_data_set_12773, _subseq_opt_12774);
    DeRef(_0);

    /** 	if length(data_set) = 0 then*/
    if (IS_SEQUENCE(_data_set_12773)){
            _7233 = SEQ_PTR(_data_set_12773)->length;
    }
    else {
        _7233 = 1;
    }
    if (_7233 != 0)
    goto L2; // [28] 43

    /** 		return {0}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _7235 = MAKE_SEQ(_1);
    DeRef(_data_set_12773);
    DeRef(_subseq_opt_12774);
    DeRef(_sd_12775);
    return _7235;
L2: 

    /** 	sd = stdev(data_set)*/
    Ref(_data_set_12773);
    _0 = _sd_12775;
    _sd_12775 = _35stdev(_data_set_12773, 1, 2);
    DeRef(_0);

    /** 	if sd = 0 then*/
    if (binary_op_a(NOTEQ, _sd_12775, 0)){
        goto L3; // [53] 64
    }

    /** 		return {1}*/
    RefDS(_7238);
    DeRef(_data_set_12773);
    DeRef(_subseq_opt_12774);
    DeRef(_sd_12775);
    DeRef(_7235);
    _7235 = NOVALUE;
    return _7238;
L3: 

    /** 	return (sum_central_moments(data_set, 4) / ((length(data_set) - 1) * power(stdev(data_set), 4))) - 3*/

    /** 	return sum( central_moment(data_set, data_set, order_mag, subseq_opt) )*/
    Ref(_data_set_12773);
    Ref(_data_set_12773);
    _0 = _sum_central_moments_1__tmp_at65_12789;
    _sum_central_moments_1__tmp_at65_12789 = _35central_moment(_data_set_12773, _data_set_12773, 4, 1);
    DeRef(_0);
    Ref(_sum_central_moments_1__tmp_at65_12789);
    _0 = _sum_central_moments_inlined_sum_central_moments_at_65_12788;
    _sum_central_moments_inlined_sum_central_moments_at_65_12788 = _35sum(_sum_central_moments_1__tmp_at65_12789, 1);
    DeRef(_0);
    DeRef(_sum_central_moments_1__tmp_at65_12789);
    _sum_central_moments_1__tmp_at65_12789 = NOVALUE;
    if (IS_SEQUENCE(_data_set_12773)){
            _7239 = SEQ_PTR(_data_set_12773)->length;
    }
    else {
        _7239 = 1;
    }
    _7240 = _7239 - 1;
    _7239 = NOVALUE;
    Ref(_data_set_12773);
    _7241 = _35stdev(_data_set_12773, 1, 2);
    if (IS_ATOM_INT(_7241)) {
        _7242 = power(_7241, 4);
    }
    else {
        _7242 = binary_op(POWER, _7241, 4);
    }
    DeRef(_7241);
    _7241 = NOVALUE;
    if (IS_ATOM_INT(_7242)) {
        if (_7240 == (short)_7240 && _7242 <= INT15 && _7242 >= -INT15)
        _7243 = _7240 * _7242;
        else
        _7243 = NewDouble(_7240 * (double)_7242);
    }
    else {
        _7243 = binary_op(MULTIPLY, _7240, _7242);
    }
    _7240 = NOVALUE;
    DeRef(_7242);
    _7242 = NOVALUE;
    if (IS_ATOM_INT(_sum_central_moments_inlined_sum_central_moments_at_65_12788) && IS_ATOM_INT(_7243)) {
        _7244 = (_sum_central_moments_inlined_sum_central_moments_at_65_12788 % _7243) ? NewDouble((double)_sum_central_moments_inlined_sum_central_moments_at_65_12788 / _7243) : (_sum_central_moments_inlined_sum_central_moments_at_65_12788 / _7243);
    }
    else {
        _7244 = binary_op(DIVIDE, _sum_central_moments_inlined_sum_central_moments_at_65_12788, _7243);
    }
    DeRef(_7243);
    _7243 = NOVALUE;
    if (IS_ATOM_INT(_7244)) {
        _7245 = _7244 - 3;
        if ((long)((unsigned long)_7245 +(unsigned long) HIGH_BITS) >= 0){
            _7245 = NewDouble((double)_7245);
        }
    }
    else {
        _7245 = binary_op(MINUS, _7244, 3);
    }
    DeRef(_7244);
    _7244 = NOVALUE;
    DeRef(_data_set_12773);
    DeRef(_subseq_opt_12774);
    DeRef(_sd_12775);
    DeRef(_7235);
    _7235 = NOVALUE;
    return _7245;
    ;
}
int kurtosis() __attribute__ ((alias ("_35kurtosis")));



// 0x6021CBF0
