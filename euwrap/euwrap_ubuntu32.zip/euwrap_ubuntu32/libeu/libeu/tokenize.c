// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _29report_error(int _err_11245)
{
    int _0, _1, _2;
    

    /** 	Look = io:EOF*/
    _29Look_11214 = -1;

    /** 	ERR = err*/
    _29ERR_11215 = _err_11245;

    /** 	ERR_LNUM = Token[TLNUM]*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _29ERR_LNUM_11216 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_29ERR_LNUM_11216))
    _29ERR_LNUM_11216 = (long)DBL_PTR(_29ERR_LNUM_11216)->dbl;

    /** 	ERR_LPOS = Token[TLPOS]*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _29ERR_LPOS_11217 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29ERR_LPOS_11217))
    _29ERR_LPOS_11217 = (long)DBL_PTR(_29ERR_LPOS_11217)->dbl;

    /** end procedure*/
    return;
    ;
}


int _29error_string(int _err_11250)
{
    int _6336 = NOVALUE;
    int _6335 = NOVALUE;
    int _6334 = NOVALUE;
    int _6333 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_err_11250)) {
        _1 = (long)(DBL_PTR(_err_11250)->dbl);
        DeRefDS(_err_11250);
        _err_11250 = _1;
    }

    /** 	if err >= ERR_OPEN and err <= ERR_EOF then*/
    _6333 = (_err_11250 >= 1);
    if (_6333 == 0) {
        goto L1; // [9] 36
    }
    _6335 = (_err_11250 <= 9);
    if (_6335 == 0)
    {
        DeRef(_6335);
        _6335 = NOVALUE;
        goto L1; // [18] 36
    }
    else{
        DeRef(_6335);
        _6335 = NOVALUE;
    }

    /** 		return ERROR_STRING[err]*/
    _2 = (int)SEQ_PTR(_29ERROR_STRING_11230);
    _6336 = (int)*(((s1_ptr)_2)->base + _err_11250);
    RefDS(_6336);
    DeRef(_6333);
    _6333 = NOVALUE;
    return _6336;
    goto L2; // [33] 43
L1: 

    /** 		return ""*/
    RefDS(_5);
    DeRef(_6333);
    _6333 = NOVALUE;
    _6336 = NOVALUE;
    return _5;
L2: 
    ;
}
int error_string() __attribute__ ((alias ("_29error_string")));


void _29keep_newlines(int _val_11262)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11262)) {
        _1 = (long)(DBL_PTR(_val_11262)->dbl);
        DeRefDS(_val_11262);
        _val_11262 = _1;
    }

    /** 	IGNORE_NEWLINES = not val*/
    _29IGNORE_NEWLINES_11257 = (_val_11262 == 0);

    /** end procedure*/
    return;
    ;
}
void keep_newlines() __attribute__ ((alias ("_29keep_newlines")));


void _29keep_comments(int _val_11266)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11266)) {
        _1 = (long)(DBL_PTR(_val_11266)->dbl);
        DeRefDS(_val_11266);
        _val_11266 = _1;
    }

    /** 	IGNORE_COMMENTS = not val*/
    _29IGNORE_COMMENTS_11258 = (_val_11266 == 0);

    /** end procedure*/
    return;
    ;
}
void keep_comments() __attribute__ ((alias ("_29keep_comments")));


void _29string_numbers(int _val_11270)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_11270)) {
        _1 = (long)(DBL_PTR(_val_11270)->dbl);
        DeRefDS(_val_11270);
        _val_11270 = _1;
    }

    /** 	STRING_NUMBERS = val*/
    _29STRING_NUMBERS_11259 = _val_11270;

    /** end procedure*/
    return;
    ;
}
void string_numbers() __attribute__ ((alias ("_29string_numbers")));


int _29White_Char(int _c_11273)
{
    int _6343 = NOVALUE;
    int _6342 = NOVALUE;
    int _6341 = NOVALUE;
    int _6340 = NOVALUE;
    int _6339 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (c >= 0) and (c <= ' ')*/
    _6339 = 1;
    _6340 = (_c_11273 >= 0);
    _6341 = (_6339 != 0 && _6340 != 0);
    _6339 = NOVALUE;
    _6340 = NOVALUE;
    _6342 = (_c_11273 <= 32);
    _6343 = (_6341 != 0 && _6342 != 0);
    _6341 = NOVALUE;
    _6342 = NOVALUE;
    return _6343;
    ;
}


int _29Digit_Char(int _c_11281)
{
    int _6350 = NOVALUE;
    int _6349 = NOVALUE;
    int _6348 = NOVALUE;
    int _6347 = NOVALUE;
    int _6346 = NOVALUE;
    int _6345 = NOVALUE;
    int _6344 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ((('0' <= c) and (c <= '9')) or (c = '_'))*/
    _6344 = 1;
    _6345 = (48 <= _c_11281);
    _6346 = (_c_11281 <= 57);
    _6347 = (_6345 != 0 && _6346 != 0);
    _6345 = NOVALUE;
    _6346 = NOVALUE;
    _6348 = (_c_11281 == 95);
    _6349 = (_6347 != 0 || _6348 != 0);
    _6347 = NOVALUE;
    _6348 = NOVALUE;
    _6350 = (_6344 != 0 && _6349 != 0);
    _6344 = NOVALUE;
    _6349 = NOVALUE;
    return _6350;
    ;
}


int _29uHex_Char(int _c_11291)
{
    int _6355 = NOVALUE;
    int _6354 = NOVALUE;
    int _6353 = NOVALUE;
    int _6352 = NOVALUE;
    int _6351 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('A' <= c) and (c <= 'F')*/
    _6351 = 1;
    _6352 = (65 <= _c_11291);
    _6353 = (_6351 != 0 && _6352 != 0);
    _6351 = NOVALUE;
    _6352 = NOVALUE;
    _6354 = (_c_11291 <= 70);
    _6355 = (_6353 != 0 && _6354 != 0);
    _6353 = NOVALUE;
    _6354 = NOVALUE;
    return _6355;
    ;
}


int _29lHex_Char(int _c_11299)
{
    int _6360 = NOVALUE;
    int _6359 = NOVALUE;
    int _6358 = NOVALUE;
    int _6357 = NOVALUE;
    int _6356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('a' <= c) and (c <= 'f')*/
    _6356 = 1;
    _6357 = (97 <= _c_11299);
    _6358 = (_6356 != 0 && _6357 != 0);
    _6356 = NOVALUE;
    _6357 = NOVALUE;
    _6359 = (_c_11299 <= 102);
    _6360 = (_6358 != 0 && _6359 != 0);
    _6358 = NOVALUE;
    _6359 = NOVALUE;
    return _6360;
    ;
}


int _29Hex_Char(int _c_11307)
{
    int _6367 = NOVALUE;
    int _6366 = NOVALUE;
    int _6365 = NOVALUE;
    int _6364 = NOVALUE;
    int _6363 = NOVALUE;
    int _6362 = NOVALUE;
    int _6361 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (Digit_Char(c) or uHex_Char(c) or lHex_Char(c))*/
    _6361 = 1;
    _6362 = _29Digit_Char(_c_11307);
    _6363 = _29uHex_Char(_c_11307);
    if (IS_ATOM_INT(_6362) && IS_ATOM_INT(_6363)) {
        _6364 = (_6362 != 0 || _6363 != 0);
    }
    else {
        _6364 = binary_op(OR, _6362, _6363);
    }
    DeRef(_6362);
    _6362 = NOVALUE;
    DeRef(_6363);
    _6363 = NOVALUE;
    _6365 = _29lHex_Char(_c_11307);
    if (IS_ATOM_INT(_6364) && IS_ATOM_INT(_6365)) {
        _6366 = (_6364 != 0 || _6365 != 0);
    }
    else {
        _6366 = binary_op(OR, _6364, _6365);
    }
    DeRef(_6364);
    _6364 = NOVALUE;
    DeRef(_6365);
    _6365 = NOVALUE;
    if (IS_ATOM_INT(_6366)) {
        _6367 = (_6361 != 0 && _6366 != 0);
    }
    else {
        _6367 = binary_op(AND, _6361, _6366);
    }
    _6361 = NOVALUE;
    DeRef(_6366);
    _6366 = NOVALUE;
    return _6367;
    ;
}


int _29uAlpha_Char(int _c_11317)
{
    int _6372 = NOVALUE;
    int _6371 = NOVALUE;
    int _6370 = NOVALUE;
    int _6369 = NOVALUE;
    int _6368 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('A' <= c) and (c <= 'Z')*/
    _6368 = 1;
    _6369 = (65 <= _c_11317);
    _6370 = (_6368 != 0 && _6369 != 0);
    _6368 = NOVALUE;
    _6369 = NOVALUE;
    _6371 = (_c_11317 <= 90);
    _6372 = (_6370 != 0 && _6371 != 0);
    _6370 = NOVALUE;
    _6371 = NOVALUE;
    return _6372;
    ;
}


int _29lAlpha_Char(int _c_11325)
{
    int _6377 = NOVALUE;
    int _6376 = NOVALUE;
    int _6375 = NOVALUE;
    int _6374 = NOVALUE;
    int _6373 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and ('a' <= c) and (c <= 'z')*/
    _6373 = 1;
    _6374 = (97 <= _c_11325);
    _6375 = (_6373 != 0 && _6374 != 0);
    _6373 = NOVALUE;
    _6374 = NOVALUE;
    _6376 = (_c_11325 <= 122);
    _6377 = (_6375 != 0 && _6376 != 0);
    _6375 = NOVALUE;
    _6376 = NOVALUE;
    return _6377;
    ;
}


int _29Alpha_Char(int _c_11333)
{
    int _6382 = NOVALUE;
    int _6381 = NOVALUE;
    int _6380 = NOVALUE;
    int _6379 = NOVALUE;
    int _6378 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (uAlpha_Char(c) or lAlpha_Char(c))*/
    _6378 = 1;
    _6379 = _29uAlpha_Char(_c_11333);
    _6380 = _29lAlpha_Char(_c_11333);
    if (IS_ATOM_INT(_6379) && IS_ATOM_INT(_6380)) {
        _6381 = (_6379 != 0 || _6380 != 0);
    }
    else {
        _6381 = binary_op(OR, _6379, _6380);
    }
    DeRef(_6379);
    _6379 = NOVALUE;
    DeRef(_6380);
    _6380 = NOVALUE;
    if (IS_ATOM_INT(_6381)) {
        _6382 = (_6378 != 0 && _6381 != 0);
    }
    else {
        _6382 = binary_op(AND, _6378, _6381);
    }
    _6378 = NOVALUE;
    DeRef(_6381);
    _6381 = NOVALUE;
    return _6382;
    ;
}


int _29Alphanum_Char(int _c_11341)
{
    int _6387 = NOVALUE;
    int _6386 = NOVALUE;
    int _6385 = NOVALUE;
    int _6384 = NOVALUE;
    int _6383 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return integer(c) and (Alpha_Char(c) or Digit_Char(c))*/
    _6383 = 1;
    _6384 = _29Alpha_Char(_c_11341);
    _6385 = _29Digit_Char(_c_11341);
    if (IS_ATOM_INT(_6384) && IS_ATOM_INT(_6385)) {
        _6386 = (_6384 != 0 || _6385 != 0);
    }
    else {
        _6386 = binary_op(OR, _6384, _6385);
    }
    DeRef(_6384);
    _6384 = NOVALUE;
    DeRef(_6385);
    _6385 = NOVALUE;
    if (IS_ATOM_INT(_6386)) {
        _6387 = (_6383 != 0 && _6386 != 0);
    }
    else {
        _6387 = binary_op(AND, _6383, _6386);
    }
    _6383 = NOVALUE;
    DeRef(_6386);
    _6386 = NOVALUE;
    return _6387;
    ;
}


int _29Identifier_Char(int _c_11349)
{
    int _6388 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return Alphanum_Char(c)*/
    _6388 = _29Alphanum_Char(_c_11349);
    return _6388;
    ;
}


void _29scan_char()
{
    int _6396 = NOVALUE;
    int _6392 = NOVALUE;
    int _6391 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Look = EOL then*/
    if (_29Look_11214 != 10)
    goto L1; // [5] 57

    /** 		LNum += 1*/
    _29LNum_11212 = _29LNum_11212 + 1;

    /** 		LPos = 0*/
    _29LPos_11213 = 0;

    /** 		if length(Token[TDATA]) = 0 then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6391 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6391)){
            _6392 = SEQ_PTR(_6391)->length;
    }
    else {
        _6392 = 1;
    }
    _6391 = NOVALUE;
    if (_6392 != 0)
    goto L2; // [33] 56

    /** 			Token[TLNUM] = LNum*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29LNum_11212;
    DeRef(_1);

    /** 			Token[TLPOS] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
L2: 
L1: 

    /** 	LPos += 1*/
    _29LPos_11213 = _29LPos_11213 + 1;

    /** 	sti += 1*/
    _29sti_11211 = _29sti_11211 + 1;

    /** 	if sti > length(source_text) then*/
    if (IS_SEQUENCE(_29source_text_11210)){
            _6396 = SEQ_PTR(_29source_text_11210)->length;
    }
    else {
        _6396 = 1;
    }
    if (_29sti_11211 <= _6396)
    goto L3; // [82] 94

    /** 		Look = io:EOF*/
    _29Look_11214 = -1;
    goto L4; // [91] 105
L3: 

    /** 		Look = source_text[sti]*/
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _29Look_11214 = (int)*(((s1_ptr)_2)->base + _29sti_11211);
    if (!IS_ATOM_INT(_29Look_11214))
    _29Look_11214 = (long)DBL_PTR(_29Look_11214)->dbl;
L4: 

    /** end procedure*/
    _6391 = NOVALUE;
    return;
    ;
}


int _29lookahead(int _dist_11369)
{
    int _6403 = NOVALUE;
    int _6402 = NOVALUE;
    int _6400 = NOVALUE;
    int _6399 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sti + dist <= length(source_text) then*/
    _6399 = _29sti_11211 + _dist_11369;
    if ((long)((unsigned long)_6399 + (unsigned long)HIGH_BITS) >= 0) 
    _6399 = NewDouble((double)_6399);
    if (IS_SEQUENCE(_29source_text_11210)){
            _6400 = SEQ_PTR(_29source_text_11210)->length;
    }
    else {
        _6400 = 1;
    }
    if (binary_op_a(GREATER, _6399, _6400)){
        DeRef(_6399);
        _6399 = NOVALUE;
        _6400 = NOVALUE;
        goto L1; // [16] 41
    }
    DeRef(_6399);
    _6399 = NOVALUE;
    _6400 = NOVALUE;

    /** 		return source_text[sti + dist]*/
    _6402 = _29sti_11211 + _dist_11369;
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _6403 = (int)*(((s1_ptr)_2)->base + _6402);
    Ref(_6403);
    _6402 = NOVALUE;
    return _6403;
    goto L2; // [38] 48
L1: 

    /** 		return io:EOF*/
    DeRef(_6402);
    _6402 = NOVALUE;
    _6403 = NOVALUE;
    return -1;
L2: 
    ;
}


int _29scan_white()
{
    int _6404 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TTYPE] = T_NEWLINE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	while White_Char(Look) do*/
L1: 
    _6404 = _29White_Char(_29Look_11214);
    if (_6404 <= 0) {
        if (_6404 == 0) {
            DeRef(_6404);
            _6404 = NOVALUE;
            goto L2; // [28] 55
        }
        else {
            if (!IS_ATOM_INT(_6404) && DBL_PTR(_6404)->dbl == 0.0){
                DeRef(_6404);
                _6404 = NOVALUE;
                goto L2; // [28] 55
            }
            DeRef(_6404);
            _6404 = NOVALUE;
        }
    }
    DeRef(_6404);
    _6404 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		if Look = EOL then*/
    if (_29Look_11214 != 10)
    goto L1; // [39] 22

    /** 			return TRUE*/
    return 1;

    /** 	end while*/
    goto L1; // [52] 22
L2: 

    /** 	return FALSE*/
    return 0;
    ;
}


int _29scan_multicomment()
{
    int _6415 = NOVALUE;
    int _6414 = NOVALUE;
    int _6413 = NOVALUE;
    int _6412 = NOVALUE;
    int _6411 = NOVALUE;
    int _6410 = NOVALUE;
    int _6409 = NOVALUE;
    int _6408 = NOVALUE;
    int _6407 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TTYPE] = T_COMMENT*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 	Token[TDATA] = "/"*/
    RefDS(_3761);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3761;
    DeRef(_1);

    /** 	Token[TFORM] = TF_COMMENT_MULTIPLE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	while 1 do*/
L1: 

    /** 		if (Look = io:EOF) then*/
    if (_29Look_11214 != -1)
    goto L2; // [34] 50

    /** 			report_error(ERR_EOF)*/
    _29report_error(9);

    /** 			return TRUE */
    return 1;
L2: 

    /** 		if (Look = '*') and source_text[sti + 1] = '/' then*/
    _6407 = (_29Look_11214 == 42);
    if (_6407 == 0) {
        goto L3; // [58] 111
    }
    _6409 = _29sti_11211 + 1;
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _6410 = (int)*(((s1_ptr)_2)->base + _6409);
    if (IS_ATOM_INT(_6410)) {
        _6411 = (_6410 == 47);
    }
    else {
        _6411 = binary_op(EQUALS, _6410, 47);
    }
    _6410 = NOVALUE;
    if (_6411 == 0) {
        DeRef(_6411);
        _6411 = NOVALUE;
        goto L3; // [79] 111
    }
    else {
        if (!IS_ATOM_INT(_6411) && DBL_PTR(_6411)->dbl == 0.0){
            DeRef(_6411);
            _6411 = NOVALUE;
            goto L3; // [79] 111
        }
        DeRef(_6411);
        _6411 = NOVALUE;
    }
    DeRef(_6411);
    _6411 = NOVALUE;

    //			Token[TDATA] &= "*/"
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6412 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6412) && IS_ATOM(_6239)) {
    }
    else if (IS_ATOM(_6412) && IS_SEQUENCE(_6239)) {
        Ref(_6412);
        Prepend(&_6413, _6239, _6412);
    }
    else {
        Concat((object_ptr)&_6413, _6412, _6239);
        _6412 = NOVALUE;
    }
    _6412 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6413;
    if( _1 != _6413 ){
        DeRef(_1);
    }
    _6413 = NOVALUE;

    //			scan_char() -- skip the */
    _29scan_char();

    /** 			scan_char()*/
    _29scan_char();

    /** 			exit*/
    goto L4; // [108] 138
L3: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6414 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6414) && IS_ATOM(_29Look_11214)) {
        Append(&_6415, _6414, _29Look_11214);
    }
    else if (IS_ATOM(_6414) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6415, _6414, _29Look_11214);
        _6414 = NOVALUE;
    }
    _6414 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6415;
    if( _1 != _6415 ){
        DeRef(_1);
    }
    _6415 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L1; // [135] 30
L4: 

    /** 	return TRUE*/
    DeRef(_6407);
    _6407 = NOVALUE;
    DeRef(_6409);
    _6409 = NOVALUE;
    return 1;
    ;
}


void _29scan_escaped_char()
{
    int _f_11402 = NOVALUE;
    int _6423 = NOVALUE;
    int _6422 = NOVALUE;
    int _6418 = NOVALUE;
    int _6417 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6417 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6417) && IS_ATOM(_29Look_11214)) {
        Append(&_6418, _6417, _29Look_11214);
    }
    else if (IS_ATOM(_6417) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6418, _6417, _29Look_11214);
        _6417 = NOVALUE;
    }
    _6417 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6418;
    if( _1 != _6418 ){
        DeRef(_1);
    }
    _6418 = NOVALUE;

    /** 	if (Look = '\\') then*/
    if (_29Look_11214 != 92)
    goto L1; // [23] 71

    /** 		scan_char()*/
    _29scan_char();

    /** 		f = find(Look,QFLAGS)*/
    _f_11402 = find_from(_29Look_11214, _29QFLAGS_11398, 1);

    /** 		if not f then report_error(ERR_ESCAPE) return end if*/
    if (_f_11402 != 0)
    goto L2; // [42] 52
    _29report_error(2);
    return;
L2: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6422 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6422) && IS_ATOM(_29Look_11214)) {
        Append(&_6423, _6422, _29Look_11214);
    }
    else if (IS_ATOM(_6422) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6423, _6422, _29Look_11214);
        _6422 = NOVALUE;
    }
    _6422 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6423;
    if( _1 != _6423 ){
        DeRef(_1);
    }
    _6423 = NOVALUE;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** end procedure*/
    return;
    ;
}


int _29scan_qchar()
{
    int _0, _1, _2;
    

    /** 	if (Look != '\'') then return FALSE end if*/
    if (_29Look_11214 == 39)
    goto L1; // [5] 14
    return 0;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	Token[TTYPE] = T_CHAR*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 7;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	if (Look = EOL) then report_error(ERR_EOL_CHAR) return TRUE end if*/
    if (_29Look_11214 != 10)
    goto L2; // [38] 50
    _29report_error(3);
    return 1;
L2: 

    /** 	scan_escaped_char()*/
    _29scan_escaped_char();

    /** 	if ERR then return 1 end if*/
    if (_29ERR_11215 == 0)
    {
        goto L3; // [58] 66
    }
    else{
    }
    return 1;
L3: 

    /** 	if (Look != '\'') then report_error(ERR_CLOSE_CHAR) return TRUE end if*/
    if (_29Look_11214 == 39)
    goto L4; // [70] 82
    _29report_error(4);
    return 1;
L4: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    return 1;
    ;
}


int _29scan_string()
{
    int _6447 = NOVALUE;
    int _6446 = NOVALUE;
    int _6445 = NOVALUE;
    int _6444 = NOVALUE;
    int _6442 = NOVALUE;
    int _6441 = NOVALUE;
    int _6440 = NOVALUE;
    int _6439 = NOVALUE;
    int _6438 = NOVALUE;
    int _6437 = NOVALUE;
    int _6436 = NOVALUE;
    int _6435 = NOVALUE;
    int _6433 = NOVALUE;
    int _6432 = NOVALUE;
    int _6431 = NOVALUE;
    int _6429 = NOVALUE;
    int _6428 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '"') then */
    if (_29Look_11214 == 34)
    goto L1; // [5] 16

    /** 		return FALSE */
    return 0;
L1: 

    /** 	if sti + 3 < length(source_text) then*/
    _6428 = _29sti_11211 + 3;
    if ((long)((unsigned long)_6428 + (unsigned long)HIGH_BITS) >= 0) 
    _6428 = NewDouble((double)_6428);
    if (IS_SEQUENCE(_29source_text_11210)){
            _6429 = SEQ_PTR(_29source_text_11210)->length;
    }
    else {
        _6429 = 1;
    }
    if (binary_op_a(GREATEREQ, _6428, _6429)){
        DeRef(_6428);
        _6428 = NOVALUE;
        _6429 = NOVALUE;
        goto L2; // [29] 239
    }
    DeRef(_6428);
    _6428 = NOVALUE;
    _6429 = NOVALUE;

    /** 		if equal(source_text[sti .. sti + 2], "\"\"\"") then*/
    _6431 = _29sti_11211 + 2;
    rhs_slice_target = (object_ptr)&_6432;
    RHS_Slice(_29source_text_11210, _29sti_11211, _6431);
    if (_6432 == _6279)
    _6433 = 1;
    else if (IS_ATOM_INT(_6432) && IS_ATOM_INT(_6279))
    _6433 = 0;
    else
    _6433 = (compare(_6432, _6279) == 0);
    DeRefDS(_6432);
    _6432 = NOVALUE;
    if (_6433 == 0)
    {
        _6433 = NOVALUE;
        goto L3; // [54] 238
    }
    else{
        _6433 = NOVALUE;
    }

    /** 			Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 			Token[TFORM] = TF_STRING_TRIPLE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 			sti += 2*/
    _29sti_11211 = _29sti_11211 + 2;

    /** 			scan_char()*/
    _29scan_char();

    /** 			while (sti < length(source_text) - 2) and*/
L4: 
    if (IS_SEQUENCE(_29source_text_11210)){
            _6435 = SEQ_PTR(_29source_text_11210)->length;
    }
    else {
        _6435 = 1;
    }
    _6436 = _6435 - 2;
    _6435 = NOVALUE;
    _6437 = (_29sti_11211 < _6436);
    _6436 = NOVALUE;
    if (_6437 == 0) {
        goto L5; // [113] 190
    }
    _6439 = _29sti_11211 + 2;
    rhs_slice_target = (object_ptr)&_6440;
    RHS_Slice(_29source_text_11210, _29sti_11211, _6439);
    if (_6440 == _6279)
    _6441 = 1;
    else if (IS_ATOM_INT(_6440) && IS_ATOM_INT(_6279))
    _6441 = 0;
    else
    _6441 = (compare(_6440, _6279) == 0);
    DeRefDS(_6440);
    _6440 = NOVALUE;
    _6442 = (_6441 == 0);
    _6441 = NOVALUE;
    if (_6442 == 0)
    {
        DeRef(_6442);
        _6442 = NOVALUE;
        goto L5; // [140] 190
    }
    else{
        DeRef(_6442);
        _6442 = NOVALUE;
    }

    /** 				if (Look = io:EOF) then*/
    if (_29Look_11214 != -1)
    goto L6; // [147] 163

    /** 					report_error(ERR_EOF)*/
    _29report_error(9);

    /** 					return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    return 1;
L6: 

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6444 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6444) && IS_ATOM(_29Look_11214)) {
        Append(&_6445, _6444, _29Look_11214);
    }
    else if (IS_ATOM(_6444) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6445, _6444, _29Look_11214);
        _6444 = NOVALUE;
    }
    _6444 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6445;
    if( _1 != _6445 ){
        DeRef(_1);
    }
    _6445 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L4; // [187] 98
L5: 

    /** 			if sti > length(source_text) - 2 then*/
    if (IS_SEQUENCE(_29source_text_11210)){
            _6446 = SEQ_PTR(_29source_text_11210)->length;
    }
    else {
        _6446 = 1;
    }
    _6447 = _6446 - 2;
    _6446 = NOVALUE;
    if (_29sti_11211 <= _6447)
    goto L7; // [203] 219

    /** 				report_error(ERR_EOF)*/
    _29report_error(9);

    /** 				return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    _6447 = NOVALUE;
    return 1;
L7: 

    /** 			sti += 2*/
    _29sti_11211 = _29sti_11211 + 2;

    /** 			scan_char()*/
    _29scan_char();

    /** 			return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    DeRef(_6447);
    _6447 = NOVALUE;
    return 1;
L3: 
L2: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TFORM] = TF_STRING_SINGLE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 	while (Look != '"') do*/
L8: 
    if (_29Look_11214 == 34)
    goto L9; // [274] 321

    /** 		if (Look = EOL) then */
    if (_29Look_11214 != 10)
    goto LA; // [282] 298

    /** 			report_error(ERR_EOL_STRING) */
    _29report_error(5);

    /** 			return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    DeRef(_6447);
    _6447 = NOVALUE;
    return 1;
LA: 

    /** 		scan_escaped_char()*/
    _29scan_escaped_char();

    /** 		if ERR then */
    if (_29ERR_11215 == 0)
    {
        goto L8; // [306] 272
    }
    else{
    }

    /** 			return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    DeRef(_6447);
    _6447 = NOVALUE;
    return 1;

    /** 	end while*/
    goto L8; // [318] 272
L9: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    DeRef(_6431);
    _6431 = NOVALUE;
    DeRef(_6439);
    _6439 = NOVALUE;
    DeRef(_6437);
    _6437 = NOVALUE;
    DeRef(_6447);
    _6447 = NOVALUE;
    return 1;
    ;
}


int _29scan_multistring()
{
    int _end_of_string_11459 = NOVALUE;
    int _6456 = NOVALUE;
    int _6455 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '`') then*/
    if (_29Look_11214 == 96)
    goto L1; // [5] 16

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	end_of_string = '`'*/
    _end_of_string_11459 = 96;

    /** 	Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TFORM] = TF_STRING_BACKTICK*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	while (Look != end_of_string) do*/
L2: 
    if (_29Look_11214 == _end_of_string_11459)
    goto L3; // [56] 107

    /** 		if (Look = io:EOF) then*/
    if (_29Look_11214 != -1)
    goto L4; // [64] 80

    /** 			report_error(ERR_EOF)*/
    _29report_error(9);

    /** 			return TRUE*/
    return 1;
L4: 

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6455 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6455) && IS_ATOM(_29Look_11214)) {
        Append(&_6456, _6455, _29Look_11214);
    }
    else if (IS_ATOM(_6455) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6456, _6455, _29Look_11214);
        _6455 = NOVALUE;
    }
    _6455 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6456;
    if( _1 != _6456 ){
        DeRef(_1);
    }
    _6456 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L2; // [104] 54
L3: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	return TRUE*/
    return 1;
    ;
}


int _29hex_val(int _h_11470)
{
    int _6463 = NOVALUE;
    int _6462 = NOVALUE;
    int _6461 = NOVALUE;
    int _6459 = NOVALUE;
    int _6458 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if h >= 'a' then*/
    if (_h_11470 < 97)
    goto L1; // [5] 26

    /** 		return h - 'a' + 10*/
    _6458 = _h_11470 - 97;
    if ((long)((unsigned long)_6458 +(unsigned long) HIGH_BITS) >= 0){
        _6458 = NewDouble((double)_6458);
    }
    if (IS_ATOM_INT(_6458)) {
        _6459 = _6458 + 10;
        if ((long)((unsigned long)_6459 + (unsigned long)HIGH_BITS) >= 0) 
        _6459 = NewDouble((double)_6459);
    }
    else {
        _6459 = NewDouble(DBL_PTR(_6458)->dbl + (double)10);
    }
    DeRef(_6458);
    _6458 = NOVALUE;
    return _6459;
    goto L2; // [23] 60
L1: 

    /** 	elsif h >= 'A' then*/
    if (_h_11470 < 65)
    goto L3; // [28] 49

    /** 		return h - 'A' + 10*/
    _6461 = _h_11470 - 65;
    if ((long)((unsigned long)_6461 +(unsigned long) HIGH_BITS) >= 0){
        _6461 = NewDouble((double)_6461);
    }
    if (IS_ATOM_INT(_6461)) {
        _6462 = _6461 + 10;
        if ((long)((unsigned long)_6462 + (unsigned long)HIGH_BITS) >= 0) 
        _6462 = NewDouble((double)_6462);
    }
    else {
        _6462 = NewDouble(DBL_PTR(_6461)->dbl + (double)10);
    }
    DeRef(_6461);
    _6461 = NOVALUE;
    DeRef(_6459);
    _6459 = NOVALUE;
    return _6462;
    goto L2; // [46] 60
L3: 

    /** 		return h - '0'*/
    _6463 = _h_11470 - 48;
    if ((long)((unsigned long)_6463 +(unsigned long) HIGH_BITS) >= 0){
        _6463 = NewDouble((double)_6463);
    }
    DeRef(_6459);
    _6459 = NOVALUE;
    DeRef(_6462);
    _6462 = NOVALUE;
    return _6463;
L2: 
    ;
}


int _29scan_hex()
{
    int _startSti_11485 = NOVALUE;
    int _6476 = NOVALUE;
    int _6475 = NOVALUE;
    int _6474 = NOVALUE;
    int _6473 = NOVALUE;
    int _6471 = NOVALUE;
    int _6470 = NOVALUE;
    int _6469 = NOVALUE;
    int _6468 = NOVALUE;
    int _6467 = NOVALUE;
    int _6465 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if (Look != '#') then*/
    if (_29Look_11214 == 35)
    goto L1; // [5] 16

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	integer startSti = sti*/
    _startSti_11485 = _29sti_11211;

    /** 	scan_char()*/
    _29scan_char();

    /** 	if not Hex_Char(Look) then*/
    _6465 = _29Hex_Char(_29Look_11214);
    if (IS_ATOM_INT(_6465)) {
        if (_6465 != 0){
            DeRef(_6465);
            _6465 = NOVALUE;
            goto L2; // [35] 48
        }
    }
    else {
        if (DBL_PTR(_6465)->dbl != 0.0){
            DeRef(_6465);
            _6465 = NOVALUE;
            goto L2; // [35] 48
        }
    }
    DeRef(_6465);
    _6465 = NOVALUE;

    /** 		report_error(ERR_HEX) return TRUE*/
    _29report_error(6);
    return 1;
L2: 

    /** 	Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	Token[TFORM] = TF_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11259 == 0)
    {
        goto L3; // [68] 118
    }
    else{
    }

    /** 		while Hex_Char(Look) do*/
L4: 
    _6467 = _29Hex_Char(_29Look_11214);
    if (_6467 <= 0) {
        if (_6467 == 0) {
            DeRef(_6467);
            _6467 = NOVALUE;
            goto L5; // [82] 94
        }
        else {
            if (!IS_ATOM_INT(_6467) && DBL_PTR(_6467)->dbl == 0.0){
                DeRef(_6467);
                _6467 = NOVALUE;
                goto L5; // [82] 94
            }
            DeRef(_6467);
            _6467 = NOVALUE;
        }
    }
    DeRef(_6467);
    _6467 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L4; // [91] 76
L5: 

    /** 		Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6468 = _29sti_11211 - 1;
    rhs_slice_target = (object_ptr)&_6469;
    RHS_Slice(_29source_text_11210, _startSti_11485, _6468);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6469;
    if( _1 != _6469 ){
        DeRef(_1);
    }
    _6469 = NOVALUE;
    goto L6; // [115] 197
L3: 

    /** 		Token[TDATA] = hex_val(Look)*/
    _6470 = _29hex_val(_29Look_11214);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6470;
    if( _1 != _6470 ){
        DeRef(_1);
    }
    _6470 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		while Hex_Char(Look) do*/
L7: 
    _6471 = _29Hex_Char(_29Look_11214);
    if (_6471 <= 0) {
        if (_6471 == 0) {
            DeRef(_6471);
            _6471 = NOVALUE;
            goto L8; // [147] 196
        }
        else {
            if (!IS_ATOM_INT(_6471) && DBL_PTR(_6471)->dbl == 0.0){
                DeRef(_6471);
                _6471 = NOVALUE;
                goto L8; // [147] 196
            }
            DeRef(_6471);
            _6471 = NOVALUE;
        }
    }
    DeRef(_6471);
    _6471 = NOVALUE;

    /** 			if Look != '_' then*/
    if (_29Look_11214 == 95)
    goto L9; // [154] 187

    /** 				Token[TDATA] = Token[TDATA] * 16 + hex_val(Look)*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6473 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6473)) {
        if (_6473 == (short)_6473)
        _6474 = _6473 * 16;
        else
        _6474 = NewDouble(_6473 * (double)16);
    }
    else {
        _6474 = binary_op(MULTIPLY, _6473, 16);
    }
    _6473 = NOVALUE;
    _6475 = _29hex_val(_29Look_11214);
    if (IS_ATOM_INT(_6474) && IS_ATOM_INT(_6475)) {
        _6476 = _6474 + _6475;
        if ((long)((unsigned long)_6476 + (unsigned long)HIGH_BITS) >= 0) 
        _6476 = NewDouble((double)_6476);
    }
    else {
        _6476 = binary_op(PLUS, _6474, _6475);
    }
    DeRef(_6474);
    _6474 = NOVALUE;
    DeRef(_6475);
    _6475 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6476;
    if( _1 != _6476 ){
        DeRef(_1);
    }
    _6476 = NOVALUE;
L9: 

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L7; // [193] 141
L8: 
L6: 

    /** 	return TRUE*/
    DeRef(_6468);
    _6468 = NOVALUE;
    return 1;
    ;
}


int _29scan_integer()
{
    int _i_11507 = NOVALUE;
    int _6480 = NOVALUE;
    int _6479 = NOVALUE;
    int _6477 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom i = 0*/
    DeRef(_i_11507);
    _i_11507 = 0;

    /** 	while Digit_Char(Look) do*/
L1: 
    _6477 = _29Digit_Char(_29Look_11214);
    if (_6477 <= 0) {
        if (_6477 == 0) {
            DeRef(_6477);
            _6477 = NOVALUE;
            goto L2; // [17] 54
        }
        else {
            if (!IS_ATOM_INT(_6477) && DBL_PTR(_6477)->dbl == 0.0){
                DeRef(_6477);
                _6477 = NOVALUE;
                goto L2; // [17] 54
            }
            DeRef(_6477);
            _6477 = NOVALUE;
        }
    }
    DeRef(_6477);
    _6477 = NOVALUE;

    /** 		if (Look != '_') then*/
    if (_29Look_11214 == 95)
    goto L3; // [24] 45

    /** 			i = (i * 10) + (Look - '0')*/
    if (IS_ATOM_INT(_i_11507)) {
        if (_i_11507 == (short)_i_11507)
        _6479 = _i_11507 * 10;
        else
        _6479 = NewDouble(_i_11507 * (double)10);
    }
    else {
        _6479 = NewDouble(DBL_PTR(_i_11507)->dbl * (double)10);
    }
    _6480 = _29Look_11214 - 48;
    if ((long)((unsigned long)_6480 +(unsigned long) HIGH_BITS) >= 0){
        _6480 = NewDouble((double)_6480);
    }
    DeRef(_i_11507);
    if (IS_ATOM_INT(_6479) && IS_ATOM_INT(_6480)) {
        _i_11507 = _6479 + _6480;
        if ((long)((unsigned long)_i_11507 + (unsigned long)HIGH_BITS) >= 0) 
        _i_11507 = NewDouble((double)_i_11507);
    }
    else {
        if (IS_ATOM_INT(_6479)) {
            _i_11507 = NewDouble((double)_6479 + DBL_PTR(_6480)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6480)) {
                _i_11507 = NewDouble(DBL_PTR(_6479)->dbl + (double)_6480);
            }
            else
            _i_11507 = NewDouble(DBL_PTR(_6479)->dbl + DBL_PTR(_6480)->dbl);
        }
    }
    DeRef(_6479);
    _6479 = NOVALUE;
    DeRef(_6480);
    _6480 = NOVALUE;
L3: 

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L1; // [51] 11
L2: 

    /** 	return i*/
    return _i_11507;
    ;
}


int _29scan_fraction(int _v_11517)
{
    int _d_11521 = NOVALUE;
    int _6487 = NOVALUE;
    int _6486 = NOVALUE;
    int _6484 = NOVALUE;
    int _6482 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Digit_Char(Look) then report_error(ERR_DECIMAL) return 0 end if*/
    _6482 = _29Digit_Char(_29Look_11214);
    if (IS_ATOM_INT(_6482)) {
        if (_6482 != 0){
            DeRef(_6482);
            _6482 = NOVALUE;
            goto L1; // [9] 20
        }
    }
    else {
        if (DBL_PTR(_6482)->dbl != 0.0){
            DeRef(_6482);
            _6482 = NOVALUE;
            goto L1; // [9] 20
        }
    }
    DeRef(_6482);
    _6482 = NOVALUE;
    _29report_error(7);
    DeRef(_v_11517);
    DeRef(_d_11521);
    return 0;
L1: 

    /** 	atom d = 10*/
    DeRef(_d_11521);
    _d_11521 = 10;

    /** 	while Digit_Char(Look) do*/
L2: 
    _6484 = _29Digit_Char(_29Look_11214);
    if (_6484 <= 0) {
        if (_6484 == 0) {
            DeRef(_6484);
            _6484 = NOVALUE;
            goto L3; // [36] 79
        }
        else {
            if (!IS_ATOM_INT(_6484) && DBL_PTR(_6484)->dbl == 0.0){
                DeRef(_6484);
                _6484 = NOVALUE;
                goto L3; // [36] 79
            }
            DeRef(_6484);
            _6484 = NOVALUE;
        }
    }
    DeRef(_6484);
    _6484 = NOVALUE;

    /** 		if Look != '_' then*/
    if (_29Look_11214 == 95)
    goto L4; // [43] 70

    /** 			v += (Look - '0') / d*/
    _6486 = _29Look_11214 - 48;
    if ((long)((unsigned long)_6486 +(unsigned long) HIGH_BITS) >= 0){
        _6486 = NewDouble((double)_6486);
    }
    if (IS_ATOM_INT(_6486) && IS_ATOM_INT(_d_11521)) {
        _6487 = (_6486 % _d_11521) ? NewDouble((double)_6486 / _d_11521) : (_6486 / _d_11521);
    }
    else {
        if (IS_ATOM_INT(_6486)) {
            _6487 = NewDouble((double)_6486 / DBL_PTR(_d_11521)->dbl);
        }
        else {
            if (IS_ATOM_INT(_d_11521)) {
                _6487 = NewDouble(DBL_PTR(_6486)->dbl / (double)_d_11521);
            }
            else
            _6487 = NewDouble(DBL_PTR(_6486)->dbl / DBL_PTR(_d_11521)->dbl);
        }
    }
    DeRef(_6486);
    _6486 = NOVALUE;
    _0 = _v_11517;
    if (IS_ATOM_INT(_v_11517) && IS_ATOM_INT(_6487)) {
        _v_11517 = _v_11517 + _6487;
        if ((long)((unsigned long)_v_11517 + (unsigned long)HIGH_BITS) >= 0) 
        _v_11517 = NewDouble((double)_v_11517);
    }
    else {
        if (IS_ATOM_INT(_v_11517)) {
            _v_11517 = NewDouble((double)_v_11517 + DBL_PTR(_6487)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6487)) {
                _v_11517 = NewDouble(DBL_PTR(_v_11517)->dbl + (double)_6487);
            }
            else
            _v_11517 = NewDouble(DBL_PTR(_v_11517)->dbl + DBL_PTR(_6487)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6487);
    _6487 = NOVALUE;

    /** 			d *= 10*/
    _0 = _d_11521;
    if (IS_ATOM_INT(_d_11521)) {
        if (_d_11521 == (short)_d_11521)
        _d_11521 = _d_11521 * 10;
        else
        _d_11521 = NewDouble(_d_11521 * (double)10);
    }
    else {
        _d_11521 = NewDouble(DBL_PTR(_d_11521)->dbl * (double)10);
    }
    DeRef(_0);
L4: 

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L2; // [76] 30
L3: 

    /** 	return v*/
    DeRef(_d_11521);
    return _v_11517;
    ;
}


int _29scan_exponent(int _v_11532)
{
    int _e_11533 = NOVALUE;
    int _6504 = NOVALUE;
    int _6502 = NOVALUE;
    int _6499 = NOVALUE;
    int _6494 = NOVALUE;
    int _6492 = NOVALUE;
    int _6491 = NOVALUE;
    int _6490 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ((Look != 'e') and (Look != 'E')) then return v end if*/
    _6490 = (_29Look_11214 != 101);
    if (_6490 == 0) {
        _6491 = 0;
        goto L1; // [9] 23
    }
    _6492 = (_29Look_11214 != 69);
    _6491 = (_6492 != 0);
L1: 
    if (_6491 == 0)
    {
        _6491 = NOVALUE;
        goto L2; // [23] 31
    }
    else{
        _6491 = NOVALUE;
    }
    DeRef(_e_11533);
    DeRef(_6490);
    _6490 = NOVALUE;
    DeRef(_6492);
    _6492 = NOVALUE;
    return _v_11532;
L2: 

    /** 	scan_char()*/
    _29scan_char();

    /** 	if (Look = '-') then*/
    if (_29Look_11214 != 45)
    goto L3; // [39] 58

    /** 		scan_char()*/
    _29scan_char();

    /** 		e = -scan_integer()*/
    _6494 = _29scan_integer();
    DeRef(_e_11533);
    if (IS_ATOM_INT(_6494)) {
        if ((unsigned long)_6494 == 0xC0000000)
        _e_11533 = (int)NewDouble((double)-0xC0000000);
        else
        _e_11533 = - _6494;
    }
    else {
        _e_11533 = unary_op(UMINUS, _6494);
    }
    DeRef(_6494);
    _6494 = NOVALUE;
    goto L4; // [55] 75
L3: 

    /** 		if (Look = '+') then scan_char() end if*/
    if (_29Look_11214 != 43)
    goto L5; // [62] 69
    _29scan_char();
L5: 

    /** 		e = scan_integer()*/
    _0 = _e_11533;
    _e_11533 = _29scan_integer();
    DeRef(_0);
L4: 

    /** 	if e > 308 then*/
    if (binary_op_a(LESSEQ, _e_11533, 308)){
        goto L6; // [79] 132
    }

    /** 		v *= power(10, 308)*/
    _6499 = power(10, 308);
    _0 = _v_11532;
    if (IS_ATOM_INT(_v_11532) && IS_ATOM_INT(_6499)) {
        if (_v_11532 == (short)_v_11532 && _6499 <= INT15 && _6499 >= -INT15)
        _v_11532 = _v_11532 * _6499;
        else
        _v_11532 = NewDouble(_v_11532 * (double)_6499);
    }
    else {
        if (IS_ATOM_INT(_v_11532)) {
            _v_11532 = NewDouble((double)_v_11532 * DBL_PTR(_6499)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6499)) {
                _v_11532 = NewDouble(DBL_PTR(_v_11532)->dbl * (double)_6499);
            }
            else
            _v_11532 = NewDouble(DBL_PTR(_v_11532)->dbl * DBL_PTR(_6499)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6499);
    _6499 = NOVALUE;

    /** 		if e > 1000 then e = 1000 end if*/
    if (binary_op_a(LESSEQ, _e_11533, 1000)){
        goto L7; // [95] 103
    }
    DeRef(_e_11533);
    _e_11533 = 1000;
L7: 

    /** 		for i = 1 to e - 308 do*/
    if (IS_ATOM_INT(_e_11533)) {
        _6502 = _e_11533 - 308;
        if ((long)((unsigned long)_6502 +(unsigned long) HIGH_BITS) >= 0){
            _6502 = NewDouble((double)_6502);
        }
    }
    else {
        _6502 = NewDouble(DBL_PTR(_e_11533)->dbl - (double)308);
    }
    {
        int _i_11553;
        _i_11553 = 1;
L8: 
        if (binary_op_a(GREATER, _i_11553, _6502)){
            goto L9; // [109] 129
        }

        /** 			v *= 10*/
        _0 = _v_11532;
        if (IS_ATOM_INT(_v_11532)) {
            if (_v_11532 == (short)_v_11532)
            _v_11532 = _v_11532 * 10;
            else
            _v_11532 = NewDouble(_v_11532 * (double)10);
        }
        else {
            _v_11532 = NewDouble(DBL_PTR(_v_11532)->dbl * (double)10);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _i_11553;
        if (IS_ATOM_INT(_i_11553)) {
            _i_11553 = _i_11553 + 1;
            if ((long)((unsigned long)_i_11553 +(unsigned long) HIGH_BITS) >= 0){
                _i_11553 = NewDouble((double)_i_11553);
            }
        }
        else {
            _i_11553 = binary_op_a(PLUS, _i_11553, 1);
        }
        DeRef(_0);
        goto L8; // [124] 116
L9: 
        ;
        DeRef(_i_11553);
    }
    goto LA; // [129] 143
L6: 

    /** 		v *= power(10, e)*/
    if (IS_ATOM_INT(_e_11533)) {
        _6504 = power(10, _e_11533);
    }
    else {
        temp_d.dbl = (double)10;
        _6504 = Dpower(&temp_d, DBL_PTR(_e_11533));
    }
    _0 = _v_11532;
    if (IS_ATOM_INT(_v_11532) && IS_ATOM_INT(_6504)) {
        if (_v_11532 == (short)_v_11532 && _6504 <= INT15 && _6504 >= -INT15)
        _v_11532 = _v_11532 * _6504;
        else
        _v_11532 = NewDouble(_v_11532 * (double)_6504);
    }
    else {
        if (IS_ATOM_INT(_v_11532)) {
            _v_11532 = NewDouble((double)_v_11532 * DBL_PTR(_6504)->dbl);
        }
        else {
            if (IS_ATOM_INT(_6504)) {
                _v_11532 = NewDouble(DBL_PTR(_v_11532)->dbl * (double)_6504);
            }
            else
            _v_11532 = NewDouble(DBL_PTR(_v_11532)->dbl * DBL_PTR(_6504)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_6504);
    _6504 = NOVALUE;
LA: 

    /** 	return v*/
    DeRef(_e_11533);
    DeRef(_6490);
    _6490 = NOVALUE;
    DeRef(_6492);
    _6492 = NOVALUE;
    DeRef(_6502);
    _6502 = NOVALUE;
    return _v_11532;
    ;
}


int _29scan_number()
{
    int _startSti_11565 = NOVALUE;
    int _v_11578 = NOVALUE;
    int _6526 = NOVALUE;
    int _6525 = NOVALUE;
    int _6524 = NOVALUE;
    int _6523 = NOVALUE;
    int _6522 = NOVALUE;
    int _6520 = NOVALUE;
    int _6516 = NOVALUE;
    int _6515 = NOVALUE;
    int _6514 = NOVALUE;
    int _6513 = NOVALUE;
    int _6512 = NOVALUE;
    int _6511 = NOVALUE;
    int _6510 = NOVALUE;
    int _6509 = NOVALUE;
    int _6508 = NOVALUE;
    int _6506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Digit_Char(Look) then*/
    _6506 = _29Digit_Char(_29Look_11214);
    if (IS_ATOM_INT(_6506)) {
        if (_6506 != 0){
            DeRef(_6506);
            _6506 = NOVALUE;
            goto L1; // [9] 19
        }
    }
    else {
        if (DBL_PTR(_6506)->dbl != 0.0){
            DeRef(_6506);
            _6506 = NOVALUE;
            goto L1; // [9] 19
        }
    }
    DeRef(_6506);
    _6506 = NOVALUE;

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 	Token[TFORM] = TF_INT*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);

    /** 	if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11259 == 0)
    {
        goto L2; // [39] 158
    }
    else{
    }

    /** 		integer startSti = sti*/
    _startSti_11565 = _29sti_11211;

    /** 		while Digit_Char(Look) do*/
L3: 
    _6508 = _29Digit_Char(_29Look_11214);
    if (_6508 <= 0) {
        if (_6508 == 0) {
            DeRef(_6508);
            _6508 = NOVALUE;
            goto L4; // [60] 72
        }
        else {
            if (!IS_ATOM_INT(_6508) && DBL_PTR(_6508)->dbl == 0.0){
                DeRef(_6508);
                _6508 = NOVALUE;
                goto L4; // [60] 72
            }
            DeRef(_6508);
            _6508 = NOVALUE;
        }
    }
    DeRef(_6508);
    _6508 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L3; // [69] 54
L4: 

    /** 		if Look = '.' and lookahead(1) != '.' then*/
    _6509 = (_29Look_11214 == 46);
    if (_6509 == 0) {
        goto L5; // [80] 132
    }
    _6511 = _29lookahead(1);
    if (IS_ATOM_INT(_6511)) {
        _6512 = (_6511 != 46);
    }
    else {
        _6512 = binary_op(NOTEQ, _6511, 46);
    }
    DeRef(_6511);
    _6511 = NOVALUE;
    if (_6512 == 0) {
        DeRef(_6512);
        _6512 = NOVALUE;
        goto L5; // [93] 132
    }
    else {
        if (!IS_ATOM_INT(_6512) && DBL_PTR(_6512)->dbl == 0.0){
            DeRef(_6512);
            _6512 = NOVALUE;
            goto L5; // [93] 132
        }
        DeRef(_6512);
        _6512 = NOVALUE;
    }
    DeRef(_6512);
    _6512 = NOVALUE;

    /** 			Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 			scan_char()*/
    _29scan_char();

    /** 			while Digit_Char(Look) do*/
L6: 
    _6513 = _29Digit_Char(_29Look_11214);
    if (_6513 <= 0) {
        if (_6513 == 0) {
            DeRef(_6513);
            _6513 = NOVALUE;
            goto L7; // [119] 131
        }
        else {
            if (!IS_ATOM_INT(_6513) && DBL_PTR(_6513)->dbl == 0.0){
                DeRef(_6513);
                _6513 = NOVALUE;
                goto L7; // [119] 131
            }
            DeRef(_6513);
            _6513 = NOVALUE;
        }
    }
    DeRef(_6513);
    _6513 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L6; // [128] 113
L7: 
L5: 

    /** 		Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6514 = _29sti_11211 - 1;
    rhs_slice_target = (object_ptr)&_6515;
    RHS_Slice(_29source_text_11210, _startSti_11565, _6514);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6515;
    if( _1 != _6515 ){
        DeRef(_1);
    }
    _6515 = NOVALUE;
    goto L8; // [155] 289
L2: 

    /** 		atom v*/

    /** 		Token[TDATA] = scan_integer()*/
    _6516 = _29scan_integer();
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6516;
    if( _1 != _6516 ){
        DeRef(_1);
    }
    _6516 = NOVALUE;

    /** 		if not SUBSCRIPT then*/
    if (_29SUBSCRIPT_11504 != 0)
    goto L9; // [175] 286

    /** 			v = Token[TDATA]*/
    DeRef(_v_11578);
    _2 = (int)SEQ_PTR(_29Token_11208);
    _v_11578 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_v_11578);

    /** 			if Look = '.' then*/
    if (_29Look_11214 != 46)
    goto LA; // [190] 246

    /** 				if lookahead() = '.' then*/
    _6520 = _29lookahead(1);
    if (binary_op_a(NOTEQ, _6520, 46)){
        DeRef(_6520);
        _6520 = NOVALUE;
        goto LB; // [200] 211
    }
    DeRef(_6520);
    _6520 = NOVALUE;

    /** 					return TRUE*/
    DeRef(_v_11578);
    DeRef(_6509);
    _6509 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    return 1;
LB: 

    /** 				scan_char()*/
    _29scan_char();

    /** 				Token[TDATA] = scan_fraction(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6522 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6522);
    _6523 = _29scan_fraction(_6522);
    _6522 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6523;
    if( _1 != _6523 ){
        DeRef(_1);
    }
    _6523 = NOVALUE;

    /** 				if ERR then return TRUE end if*/
    if (_29ERR_11215 == 0)
    {
        goto LC; // [237] 245
    }
    else{
    }
    DeRef(_v_11578);
    DeRef(_6509);
    _6509 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    return 1;
LC: 
LA: 

    /** 			Token[TDATA] = scan_exponent(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6524 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6524);
    _6525 = _29scan_exponent(_6524);
    _6524 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6525;
    if( _1 != _6525 ){
        DeRef(_1);
    }
    _6525 = NOVALUE;

    /** 			if v != Token[TDATA] then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6526 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _v_11578, _6526)){
        _6526 = NOVALUE;
        goto LD; // [272] 285
    }
    _6526 = NOVALUE;

    /** 				Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
LD: 
L9: 
    DeRef(_v_11578);
    _v_11578 = NOVALUE;
L8: 

    /** 	return TRUE*/
    DeRef(_6509);
    _6509 = NOVALUE;
    DeRef(_6514);
    _6514 = NOVALUE;
    return 1;
    ;
}


int _29scan_prefixed_number()
{
    int _pfxCh_11601 = NOVALUE;
    int _firstCh_11607 = NOVALUE;
    int _startSti_11613 = NOVALUE;
    int _6548 = NOVALUE;
    int _6547 = NOVALUE;
    int _6546 = NOVALUE;
    int _6545 = NOVALUE;
    int _6544 = NOVALUE;
    int _6543 = NOVALUE;
    int _6542 = NOVALUE;
    int _6540 = NOVALUE;
    int _6537 = NOVALUE;
    int _6535 = NOVALUE;
    int _6532 = NOVALUE;
    int _6528 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not (Look = '0') then*/
    _6528 = (_29Look_11214 == 48);
    if (_6528 != 0)
    goto L1; // [9] 19
    _6528 = NOVALUE;

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	integer pfxCh = lookahead(1)*/
    _pfxCh_11601 = _29lookahead(1);
    if (!IS_ATOM_INT(_pfxCh_11601)) {
        _1 = (long)(DBL_PTR(_pfxCh_11601)->dbl);
        DeRefDS(_pfxCh_11601);
        _pfxCh_11601 = _1;
    }

    /** 	if find(pfxCh, "btdx") = 0 then*/
    _6532 = find_from(_pfxCh_11601, _6531, 1);
    if (_6532 != 0)
    goto L2; // [34] 45

    /** 		return FALSE*/
    return 0;
L2: 

    /** 	integer firstCh = lookahead(2)*/
    _firstCh_11607 = _29lookahead(2);
    if (!IS_ATOM_INT(_firstCh_11607)) {
        _1 = (long)(DBL_PTR(_firstCh_11607)->dbl);
        DeRefDS(_firstCh_11607);
        _firstCh_11607 = _1;
    }

    /** 	if Digit_Char(firstCh) or Hex_Char(firstCh) then*/
    _6535 = _29Digit_Char(_firstCh_11607);
    if (IS_ATOM_INT(_6535)) {
        if (_6535 != 0) {
            goto L3; // [59] 72
        }
    }
    else {
        if (DBL_PTR(_6535)->dbl != 0.0) {
            goto L3; // [59] 72
        }
    }
    _6537 = _29Hex_Char(_firstCh_11607);
    if (_6537 == 0) {
        DeRef(_6537);
        _6537 = NOVALUE;
        goto L4; // [68] 225
    }
    else {
        if (!IS_ATOM_INT(_6537) && DBL_PTR(_6537)->dbl == 0.0){
            DeRef(_6537);
            _6537 = NOVALUE;
            goto L4; // [68] 225
        }
        DeRef(_6537);
        _6537 = NOVALUE;
    }
    DeRef(_6537);
    _6537 = NOVALUE;
L3: 

    /** 		integer startSti = sti*/
    _startSti_11613 = _29sti_11211;

    /** 		scan_char() -- skip the leading zero*/
    _29scan_char();

    /** 		scan_char() -- skip prefix character*/
    _29scan_char();

    /** 		Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 		if pfxCh = 'x' then*/
    if (_pfxCh_11601 != 120)
    goto L5; // [97] 112

    /** 			Token[TFORM] = TF_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    goto L6; // [109] 121
L5: 

    /** 			Token[TFORM] = TF_INT*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
L6: 

    /** 		while Hex_Char(Look) or Digit_Char(Look) do*/
L7: 
    _6540 = _29Hex_Char(_29Look_11214);
    if (IS_ATOM_INT(_6540)) {
        if (_6540 != 0) {
            goto L8; // [132] 147
        }
    }
    else {
        if (DBL_PTR(_6540)->dbl != 0.0) {
            goto L8; // [132] 147
        }
    }
    _6542 = _29Digit_Char(_29Look_11214);
    if (_6542 <= 0) {
        if (_6542 == 0) {
            DeRef(_6542);
            _6542 = NOVALUE;
            goto L9; // [143] 156
        }
        else {
            if (!IS_ATOM_INT(_6542) && DBL_PTR(_6542)->dbl == 0.0){
                DeRef(_6542);
                _6542 = NOVALUE;
                goto L9; // [143] 156
            }
            DeRef(_6542);
            _6542 = NOVALUE;
        }
    }
    DeRef(_6542);
    _6542 = NOVALUE;
L8: 

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L7; // [153] 126
L9: 

    /** 		if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11259 == 0)
    {
        goto LA; // [160] 187
    }
    else{
    }

    /** 			Token[TDATA] = source_text[startSti .. sti - 1]*/
    _6543 = _29sti_11211 - 1;
    rhs_slice_target = (object_ptr)&_6544;
    RHS_Slice(_29source_text_11210, _startSti_11613, _6543);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6544;
    if( _1 != _6544 ){
        DeRef(_1);
    }
    _6544 = NOVALUE;
    goto LB; // [184] 218
LA: 

    /** 			Token[TDATA] = convert:to_number(source_text[startSti + 2 .. sti - 1])*/
    _6545 = _startSti_11613 + 2;
    if ((long)((unsigned long)_6545 + (unsigned long)HIGH_BITS) >= 0) 
    _6545 = NewDouble((double)_6545);
    _6546 = _29sti_11211 - 1;
    rhs_slice_target = (object_ptr)&_6547;
    RHS_Slice(_29source_text_11210, _6545, _6546);
    _6548 = _8to_number(_6547, 0);
    _6547 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6548;
    if( _1 != _6548 ){
        DeRef(_1);
    }
    _6548 = NOVALUE;
LB: 

    /** 		return TRUE*/
    DeRef(_6535);
    _6535 = NOVALUE;
    DeRef(_6540);
    _6540 = NOVALUE;
    DeRef(_6543);
    _6543 = NOVALUE;
    DeRef(_6545);
    _6545 = NOVALUE;
    DeRef(_6546);
    _6546 = NOVALUE;
    return 1;
L4: 

    /** 	return FALSE*/
    DeRef(_6535);
    _6535 = NOVALUE;
    DeRef(_6540);
    _6540 = NOVALUE;
    DeRef(_6543);
    _6543 = NOVALUE;
    DeRef(_6545);
    _6545 = NOVALUE;
    DeRef(_6546);
    _6546 = NOVALUE;
    return 0;
    ;
}


int _29hex_string(int _textdata_11632, int _string_type_11633)
{
    int _ch_11634 = NOVALUE;
    int _digit_11635 = NOVALUE;
    int _val_11636 = NOVALUE;
    int _nibble_11637 = NOVALUE;
    int _maxnibbles_11638 = NOVALUE;
    int _string_text_11639 = NOVALUE;
    int _6564 = NOVALUE;
    int _6563 = NOVALUE;
    int _6553 = NOVALUE;
    int _6552 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_string_type_11633)) {
        _1 = (long)(DBL_PTR(_string_type_11633)->dbl);
        DeRefDS(_string_type_11633);
        _string_type_11633 = _1;
    }

    /** 	switch string_type do*/
    _0 = _string_type_11633;
    switch ( _0 ){ 

        /** 		case 'x' then*/
        case 120:

        /** 			maxnibbles = 2*/
        _maxnibbles_11638 = 2;
        goto L1; // [21] 60

        /** 		case 'u' then*/
        case 117:

        /** 			maxnibbles = 4*/
        _maxnibbles_11638 = 4;
        goto L1; // [32] 60

        /** 		case 'U' then*/
        case 85:

        /** 			maxnibbles = 8*/
        _maxnibbles_11638 = 8;
        goto L1; // [43] 60

        /** 		case else*/
        default:

        /** 			printf(2, "tokenize.e: Unknown base code '%s', ignored.\n", {string_type})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _string_type_11633;
        _6552 = MAKE_SEQ(_1);
        EPrintf(2, _6551, _6552);
        DeRefDS(_6552);
        _6552 = NOVALUE;
    ;}L1: 

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_11639);
    _string_text_11639 = _5;

    /** 	nibble = 1*/
    _nibble_11637 = 1;

    /** 	val = -1*/
    DeRef(_val_11636);
    _val_11636 = -1;

    /** 	for cpos = 1 to length(textdata) do*/
    if (IS_SEQUENCE(_textdata_11632)){
            _6553 = SEQ_PTR(_textdata_11632)->length;
    }
    else {
        _6553 = 1;
    }
    {
        int _cpos_11649;
        _cpos_11649 = 1;
L2: 
        if (_cpos_11649 > _6553){
            goto L3; // [82] 229
        }

        /** 		ch = textdata[cpos]*/
        _2 = (int)SEQ_PTR(_textdata_11632);
        _ch_11634 = (int)*(((s1_ptr)_2)->base + _cpos_11649);
        if (!IS_ATOM_INT(_ch_11634))
        _ch_11634 = (long)DBL_PTR(_ch_11634)->dbl;

        /** 		digit = find(ch, "0123456789ABCDEFabcdef _\t\n\r")*/
        _digit_11635 = find_from(_ch_11634, _6555, 1);

        /** 		if digit = 0 then*/
        if (_digit_11635 != 0)
        goto L4; // [104] 115

        /** 			return 0*/
        DeRefDS(_textdata_11632);
        DeRef(_val_11636);
        DeRef(_string_text_11639);
        return 0;
L4: 

        /** 		if digit < 23 then*/
        if (_digit_11635 >= 23)
        goto L5; // [117] 198

        /** 			if digit > 16 then*/
        if (_digit_11635 <= 16)
        goto L6; // [123] 134

        /** 				digit -= 6*/
        _digit_11635 = _digit_11635 - 6;
L6: 

        /** 			if nibble = 1 then*/
        if (_nibble_11637 != 1)
        goto L7; // [136] 149

        /** 				val = digit - 1*/
        DeRef(_val_11636);
        _val_11636 = _digit_11635 - 1;
        if ((long)((unsigned long)_val_11636 +(unsigned long) HIGH_BITS) >= 0){
            _val_11636 = NewDouble((double)_val_11636);
        }
        goto L8; // [146] 189
L7: 

        /** 				val = val * 16 + digit - 1*/
        if (IS_ATOM_INT(_val_11636)) {
            if (_val_11636 == (short)_val_11636)
            _6563 = _val_11636 * 16;
            else
            _6563 = NewDouble(_val_11636 * (double)16);
        }
        else {
            _6563 = NewDouble(DBL_PTR(_val_11636)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_6563)) {
            _6564 = _6563 + _digit_11635;
            if ((long)((unsigned long)_6564 + (unsigned long)HIGH_BITS) >= 0) 
            _6564 = NewDouble((double)_6564);
        }
        else {
            _6564 = NewDouble(DBL_PTR(_6563)->dbl + (double)_digit_11635);
        }
        DeRef(_6563);
        _6563 = NOVALUE;
        DeRef(_val_11636);
        if (IS_ATOM_INT(_6564)) {
            _val_11636 = _6564 - 1;
            if ((long)((unsigned long)_val_11636 +(unsigned long) HIGH_BITS) >= 0){
                _val_11636 = NewDouble((double)_val_11636);
            }
        }
        else {
            _val_11636 = NewDouble(DBL_PTR(_6564)->dbl - (double)1);
        }
        DeRef(_6564);
        _6564 = NOVALUE;

        /** 				if nibble = maxnibbles then*/
        if (_nibble_11637 != _maxnibbles_11638)
        goto L9; // [167] 188

        /** 					string_text &= val*/
        Ref(_val_11636);
        Append(&_string_text_11639, _string_text_11639, _val_11636);

        /** 					val = -1*/
        DeRef(_val_11636);
        _val_11636 = -1;

        /** 					nibble = 0*/
        _nibble_11637 = 0;
L9: 
L8: 

        /** 			nibble += 1*/
        _nibble_11637 = _nibble_11637 + 1;
        goto LA; // [195] 222
L5: 

        /** 			if val >= 0 then*/
        if (binary_op_a(LESS, _val_11636, 0)){
            goto LB; // [200] 216
        }

        /** 				string_text &= val*/
        Ref(_val_11636);
        Append(&_string_text_11639, _string_text_11639, _val_11636);

        /** 				val = -1*/
        DeRef(_val_11636);
        _val_11636 = -1;
LB: 

        /** 			nibble = 1*/
        _nibble_11637 = 1;
LA: 

        /** 	end for*/
        _cpos_11649 = _cpos_11649 + 1;
        goto L2; // [224] 89
L3: 
        ;
    }

    /** 	if val >= 0 then*/
    if (binary_op_a(LESS, _val_11636, 0)){
        goto LC; // [231] 242
    }

    /** 		string_text &= val*/
    Ref(_val_11636);
    Append(&_string_text_11639, _string_text_11639, _val_11636);
LC: 

    /** 	return string_text*/
    DeRefDS(_textdata_11632);
    DeRef(_val_11636);
    return _string_text_11639;
    ;
}


int _29scan_identifier()
{
    int _nextch_11682 = NOVALUE;
    int _startpos_11683 = NOVALUE;
    int _textdata_11684 = NOVALUE;
    int _6596 = NOVALUE;
    int _6595 = NOVALUE;
    int _6594 = NOVALUE;
    int _6593 = NOVALUE;
    int _6592 = NOVALUE;
    int _6591 = NOVALUE;
    int _6590 = NOVALUE;
    int _6589 = NOVALUE;
    int _6587 = NOVALUE;
    int _6586 = NOVALUE;
    int _6585 = NOVALUE;
    int _6584 = NOVALUE;
    int _6581 = NOVALUE;
    int _6580 = NOVALUE;
    int _6577 = NOVALUE;
    int _6576 = NOVALUE;
    int _6575 = NOVALUE;
    int _6574 = NOVALUE;
    int _6573 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not Alpha_Char(Look) and Look != '_' then*/
    _6573 = _29Alpha_Char(_29Look_11214);
    if (IS_ATOM_INT(_6573)) {
        _6574 = (_6573 == 0);
    }
    else {
        _6574 = unary_op(NOT, _6573);
    }
    DeRef(_6573);
    _6573 = NOVALUE;
    if (IS_ATOM_INT(_6574)) {
        if (_6574 == 0) {
            goto L1; // [12] 33
        }
    }
    else {
        if (DBL_PTR(_6574)->dbl == 0.0) {
            goto L1; // [12] 33
        }
    }
    _6576 = (_29Look_11214 != 95);
    if (_6576 == 0)
    {
        DeRef(_6576);
        _6576 = NOVALUE;
        goto L1; // [23] 33
    }
    else{
        DeRef(_6576);
        _6576 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_textdata_11684);
    DeRef(_6574);
    _6574 = NOVALUE;
    return 0;
L1: 

    /** 	if find(Look, "xuU") then*/
    _6577 = find_from(_29Look_11214, _6549, 1);
    if (_6577 == 0)
    {
        _6577 = NOVALUE;
        goto L2; // [42] 213
    }
    else{
        _6577 = NOVALUE;
    }

    /** 		nextch = lookahead()*/
    _nextch_11682 = _29lookahead(1);
    if (!IS_ATOM_INT(_nextch_11682)) {
        _1 = (long)(DBL_PTR(_nextch_11682)->dbl);
        DeRefDS(_nextch_11682);
        _nextch_11682 = _1;
    }

    /** 		if nextch = '"' then*/
    if (_nextch_11682 != 34)
    goto L3; // [55] 212

    /** 			textdata = ""*/
    RefDS(_5);
    DeRef(_textdata_11684);
    _textdata_11684 = _5;

    /** 			scan_char()	-- Skip over starting quote*/
    _29scan_char();

    /** 			scan_char() -- First char of string*/
    _29scan_char();

    /** 			startpos = sti*/
    _startpos_11683 = _29sti_11211;

    /** 			while not find(Look, {'"', io:EOF}) do*/
L4: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 34;
    ((int *)_2)[2] = -1;
    _6580 = MAKE_SEQ(_1);
    _6581 = find_from(_29Look_11214, _6580, 1);
    DeRefDS(_6580);
    _6580 = NOVALUE;
    if (_6581 != 0)
    goto L5; // [95] 107
    _6581 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto L4; // [104] 84
L5: 

    /** 			if Look = io:EOF then*/
    if (_29Look_11214 != -1)
    goto L6; // [111] 127

    /** 				report_error(ERR_EOF_STRING)*/
    _29report_error(10);

    /** 				return TRUE*/
    DeRef(_textdata_11684);
    DeRef(_6574);
    _6574 = NOVALUE;
    return 1;
L6: 

    /** 			textdata = hex_string(source_text[startpos .. sti-1], source_text[startpos - 2])*/
    _6584 = _29sti_11211 - 1;
    rhs_slice_target = (object_ptr)&_6585;
    RHS_Slice(_29source_text_11210, _startpos_11683, _6584);
    _6586 = _startpos_11683 - 2;
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _6587 = (int)*(((s1_ptr)_2)->base + _6586);
    Ref(_6587);
    _0 = _textdata_11684;
    _textdata_11684 = _29hex_string(_6585, _6587);
    DeRef(_0);
    _6585 = NOVALUE;
    _6587 = NOVALUE;

    /** 			if atom(textdata) then*/
    _6589 = IS_ATOM(_textdata_11684);
    if (_6589 == 0)
    {
        _6589 = NOVALUE;
        goto L7; // [162] 177
    }
    else{
        _6589 = NOVALUE;
    }

    /** 				report_error(ERR_HEX_STRING)*/
    _29report_error(11);

    /** 				return TRUE*/
    DeRef(_textdata_11684);
    DeRef(_6574);
    _6574 = NOVALUE;
    _6584 = NOVALUE;
    _6586 = NOVALUE;
    return 1;
L7: 

    /** 			Token[TTYPE] = T_STRING*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			Token[TDATA] = textdata*/
    Ref(_textdata_11684);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _textdata_11684;
    DeRef(_1);

    /** 			Token[TFORM] = TF_STRING_HEX*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 7;
    DeRef(_1);

    /** 			scan_char()	-- go to next char after end of string*/
    _29scan_char();

    /** 			return TRUE*/
    DeRef(_textdata_11684);
    DeRef(_6574);
    _6574 = NOVALUE;
    DeRef(_6584);
    _6584 = NOVALUE;
    DeRef(_6586);
    _6586 = NOVALUE;
    return 1;
L3: 
L2: 

    /** 	Token[TTYPE] = T_IDENTIFIER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	while Identifier_Char(Look) do*/
L8: 
    _6590 = _29Identifier_Char(_29Look_11214);
    if (_6590 <= 0) {
        if (_6590 == 0) {
            DeRef(_6590);
            _6590 = NOVALUE;
            goto L9; // [240] 270
        }
        else {
            if (!IS_ATOM_INT(_6590) && DBL_PTR(_6590)->dbl == 0.0){
                DeRef(_6590);
                _6590 = NOVALUE;
                goto L9; // [240] 270
            }
            DeRef(_6590);
            _6590 = NOVALUE;
        }
    }
    DeRef(_6590);
    _6590 = NOVALUE;

    /** 		Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6591 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6591) && IS_ATOM(_29Look_11214)) {
        Append(&_6592, _6591, _29Look_11214);
    }
    else if (IS_ATOM(_6591) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6592, _6591, _29Look_11214);
        _6591 = NOVALUE;
    }
    _6591 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6592;
    if( _1 != _6592 ){
        DeRef(_1);
    }
    _6592 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 	end while*/
    goto L8; // [267] 234
L9: 

    /** 	if find(Token[TDATA],keywords) then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6593 = (int)*(((s1_ptr)_2)->base + 2);
    _6594 = find_from(_6593, _4keywords_296, 1);
    _6593 = NOVALUE;
    if (_6594 == 0)
    {
        _6594 = NOVALUE;
        goto LA; // [285] 318
    }
    else{
        _6594 = NOVALUE;
    }

    /** 		Token[TTYPE] = T_KEYWORD*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);

    /** 		if equal(Token[TDATA],"include") then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6595 = (int)*(((s1_ptr)_2)->base + 2);
    if (_6595 == _118)
    _6596 = 1;
    else if (IS_ATOM_INT(_6595) && IS_ATOM_INT(_118))
    _6596 = 0;
    else
    _6596 = (compare(_6595, _118) == 0);
    _6595 = NOVALUE;
    if (_6596 == 0)
    {
        _6596 = NOVALUE;
        goto LB; // [308] 317
    }
    else{
        _6596 = NOVALUE;
    }

    /** 			INCLUDE_NEXT = TRUE*/
    _29INCLUDE_NEXT_11679 = 1;
LB: 
LA: 

    /** 	return TRUE*/
    DeRef(_textdata_11684);
    DeRef(_6574);
    _6574 = NOVALUE;
    DeRef(_6584);
    _6584 = NOVALUE;
    DeRef(_6586);
    _6586 = NOVALUE;
    return 1;
    ;
}


int _29scan_include()
{
    int _6603 = NOVALUE;
    int _6602 = NOVALUE;
    int _6600 = NOVALUE;
    int _6598 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not INCLUDE_NEXT then*/
    if (_29INCLUDE_NEXT_11679 != 0)
    goto L1; // [5] 15

    /** 		return FALSE*/
    return 0;
L1: 

    /** 	INCLUDE_NEXT = FALSE*/
    _29INCLUDE_NEXT_11679 = 0;

    /** 	Token[TTYPE] = T_IDENTIFIER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 9;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	if not scan_string() then*/
    _6598 = _29scan_string();
    if (IS_ATOM_INT(_6598)) {
        if (_6598 != 0){
            DeRef(_6598);
            _6598 = NOVALUE;
            goto L2; // [41] 86
        }
    }
    else {
        if (DBL_PTR(_6598)->dbl != 0.0){
            DeRef(_6598);
            _6598 = NOVALUE;
            goto L2; // [41] 86
        }
    }
    DeRef(_6598);
    _6598 = NOVALUE;

    /** 		while not White_Char(Look) do*/
L3: 
    _6600 = _29White_Char(_29Look_11214);
    if (IS_ATOM_INT(_6600)) {
        if (_6600 != 0){
            DeRef(_6600);
            _6600 = NOVALUE;
            goto L4; // [55] 85
        }
    }
    else {
        if (DBL_PTR(_6600)->dbl != 0.0){
            DeRef(_6600);
            _6600 = NOVALUE;
            goto L4; // [55] 85
        }
    }
    DeRef(_6600);
    _6600 = NOVALUE;

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6602 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6602) && IS_ATOM(_29Look_11214)) {
        Append(&_6603, _6602, _29Look_11214);
    }
    else if (IS_ATOM(_6602) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6603, _6602, _29Look_11214);
        _6602 = NOVALUE;
    }
    _6602 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6603;
    if( _1 != _6603 ){
        DeRef(_1);
    }
    _6603 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L3; // [82] 49
L4: 
L2: 

    /** 	return TRUE*/
    return 1;
    ;
}


void _29next_token()
{
    int _6666 = NOVALUE;
    int _6665 = NOVALUE;
    int _6664 = NOVALUE;
    int _6663 = NOVALUE;
    int _6662 = NOVALUE;
    int _6661 = NOVALUE;
    int _6660 = NOVALUE;
    int _6659 = NOVALUE;
    int _6658 = NOVALUE;
    int _6657 = NOVALUE;
    int _6656 = NOVALUE;
    int _6655 = NOVALUE;
    int _6654 = NOVALUE;
    int _6653 = NOVALUE;
    int _6650 = NOVALUE;
    int _6649 = NOVALUE;
    int _6648 = NOVALUE;
    int _6647 = NOVALUE;
    int _6646 = NOVALUE;
    int _6645 = NOVALUE;
    int _6644 = NOVALUE;
    int _6642 = NOVALUE;
    int _6641 = NOVALUE;
    int _6640 = NOVALUE;
    int _6639 = NOVALUE;
    int _6638 = NOVALUE;
    int _6637 = NOVALUE;
    int _6636 = NOVALUE;
    int _6635 = NOVALUE;
    int _6634 = NOVALUE;
    int _6633 = NOVALUE;
    int _6630 = NOVALUE;
    int _6629 = NOVALUE;
    int _6628 = NOVALUE;
    int _6627 = NOVALUE;
    int _6626 = NOVALUE;
    int _6625 = NOVALUE;
    int _6624 = NOVALUE;
    int _6623 = NOVALUE;
    int _6622 = NOVALUE;
    int _6621 = NOVALUE;
    int _6618 = NOVALUE;
    int _6615 = NOVALUE;
    int _6614 = NOVALUE;
    int _6613 = NOVALUE;
    int _6612 = NOVALUE;
    int _6611 = NOVALUE;
    int _6610 = NOVALUE;
    int _6609 = NOVALUE;
    int _6608 = NOVALUE;
    int _6607 = NOVALUE;
    int _6606 = NOVALUE;
    int _6605 = NOVALUE;
    int _6604 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Token[TLNUM] = LNum*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29LNum_11212;
    DeRef(_1);

    /** 	Token[TLPOS] = LPos*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _29LPos_11213;
    DeRef(_1);

    /** 	Token[TFORM] = -1*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	if Look = EOL and not IGNORE_NEWLINES then*/
    _6604 = (_29Look_11214 == 10);
    if (_6604 == 0) {
        goto L1; // [37] 76
    }
    _6606 = (_29IGNORE_NEWLINES_11257 == 0);
    if (_6606 == 0)
    {
        DeRef(_6606);
        _6606 = NOVALUE;
        goto L1; // [47] 76
    }
    else{
        DeRef(_6606);
        _6606 = NOVALUE;
    }

    /** 		Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 		Token[TTYPE] = T_NEWLINE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);

    /** 		scan_char() -- advance past this newline*/
    _29scan_char();

    /** 		return*/
    DeRef(_6604);
    _6604 = NOVALUE;
    return;
L1: 

    /** 	if scan_white() then*/
    _6607 = _29scan_white();
    if (_6607 == 0) {
        DeRef(_6607);
        _6607 = NOVALUE;
        goto L2; // [81] 100
    }
    else {
        if (!IS_ATOM_INT(_6607) && DBL_PTR(_6607)->dbl == 0.0){
            DeRef(_6607);
            _6607 = NOVALUE;
            goto L2; // [81] 100
        }
        DeRef(_6607);
        _6607 = NOVALUE;
    }
    DeRef(_6607);
    _6607 = NOVALUE;

    /** 		if IGNORE_NEWLINES then next_token() end if*/
    if (_29IGNORE_NEWLINES_11257 == 0)
    {
        goto L3; // [88] 94
    }
    else{
    }
    _29next_token();
L3: 

    /** 		return*/
    DeRef(_6604);
    _6604 = NOVALUE;
    return;
L2: 

    /** 	if scan_include() then*/
    _6608 = _29scan_include();
    if (_6608 == 0) {
        DeRef(_6608);
        _6608 = NOVALUE;
        goto L4; // [105] 114
    }
    else {
        if (!IS_ATOM_INT(_6608) && DBL_PTR(_6608)->dbl == 0.0){
            DeRef(_6608);
            _6608 = NOVALUE;
            goto L4; // [105] 114
        }
        DeRef(_6608);
        _6608 = NOVALUE;
    }
    DeRef(_6608);
    _6608 = NOVALUE;

    /** 		return*/
    DeRef(_6604);
    _6604 = NOVALUE;
    return;
L4: 

    /** 	Token[TTYPE] = find(Look, Delimiters)*/
    _6609 = find_from(_29Look_11214, _29Delimiters_11199, 1);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6609;
    if( _1 != _6609 ){
        DeRef(_1);
    }
    _6609 = NOVALUE;

    /** 	if Token[TTYPE] then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6610 = (int)*(((s1_ptr)_2)->base + 1);
    if (_6610 == 0) {
        _6610 = NOVALUE;
        goto L5; // [139] 626
    }
    else {
        if (!IS_ATOM_INT(_6610) && DBL_PTR(_6610)->dbl == 0.0){
            _6610 = NOVALUE;
            goto L5; // [139] 626
        }
        _6610 = NOVALUE;
    }
    _6610 = NOVALUE;

    /** 		Token[TTYPE] += T_DELIMITER - 1*/
    _6611 = 18;
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6612 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6612)) {
        _6613 = _6612 + 18;
        if ((long)((unsigned long)_6613 + (unsigned long)HIGH_BITS) >= 0) 
        _6613 = NewDouble((double)_6613);
    }
    else {
        _6613 = binary_op(PLUS, _6612, 18);
    }
    _6612 = NOVALUE;
    _6611 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6613;
    if( _1 != _6613 ){
        DeRef(_1);
    }
    _6613 = NOVALUE;

    /** 		Token[TDATA] = { Look }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29Look_11214;
    _6614 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6614;
    if( _1 != _6614 ){
        DeRef(_1);
    }
    _6614 = NOVALUE;

    /** 		scan_char()*/
    _29scan_char();

    /** 		if (Token[TTYPE] = T_LBRACKET) then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6615 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6615, 32)){
        _6615 = NOVALUE;
        goto L6; // [188] 203
    }
    _6615 = NOVALUE;

    /** 			SUBSCRIPT += 1 -- push subscript stack counter*/
    _29SUBSCRIPT_11504 = _29SUBSCRIPT_11504 + 1;
    goto L7; // [200] 736
L6: 

    /** 		elsif (Token[TTYPE] = T_RBRACKET) then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6618 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6618, 33)){
        _6618 = NOVALUE;
        goto L8; // [211] 226
    }
    _6618 = NOVALUE;

    /** 			SUBSCRIPT -= 1 -- pop subscript stack counter*/
    _29SUBSCRIPT_11504 = _29SUBSCRIPT_11504 - 1;
    goto L7; // [223] 736
L8: 

    /** 		elsif (Look = '=') and (Token[TTYPE] <= T_SINGLE_OPS) then*/
    _6621 = (_29Look_11214 == 61);
    if (_6621 == 0) {
        goto L9; // [234] 297
    }
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6623 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6623)) {
        _6624 = (_6623 <= 27);
    }
    else {
        _6624 = binary_op(LESSEQ, _6623, 27);
    }
    _6623 = NOVALUE;
    if (_6624 == 0) {
        DeRef(_6624);
        _6624 = NOVALUE;
        goto L9; // [249] 297
    }
    else {
        if (!IS_ATOM_INT(_6624) && DBL_PTR(_6624)->dbl == 0.0){
            DeRef(_6624);
            _6624 = NOVALUE;
            goto L9; // [249] 297
        }
        DeRef(_6624);
        _6624 = NOVALUE;
    }
    DeRef(_6624);
    _6624 = NOVALUE;

    /** 			Token[TTYPE] -= T_DOUBLE_OPS - 3*/
    _6625 = 8;
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6626 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6626)) {
        _6627 = _6626 - 8;
        if ((long)((unsigned long)_6627 +(unsigned long) HIGH_BITS) >= 0){
            _6627 = NewDouble((double)_6627);
        }
    }
    else {
        _6627 = binary_op(MINUS, _6626, 8);
    }
    _6626 = NOVALUE;
    _6625 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _6627;
    if( _1 != _6627 ){
        DeRef(_1);
    }
    _6627 = NOVALUE;

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6628 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6628) && IS_ATOM(_29Look_11214)) {
        Append(&_6629, _6628, _29Look_11214);
    }
    else if (IS_ATOM(_6628) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6629, _6628, _29Look_11214);
        _6628 = NOVALUE;
    }
    _6628 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6629;
    if( _1 != _6629 ){
        DeRef(_1);
    }
    _6629 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();
    goto L7; // [294] 736
L9: 

    /** 		elsif (Token[TTYPE] = T_PERIOD) then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6630 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _6630, 36)){
        _6630 = NOVALUE;
        goto LA; // [305] 483
    }
    _6630 = NOVALUE;

    /** 			if (Look = '.') then*/
    if (_29Look_11214 != 46)
    goto LB; // [313] 350

    /** 				Token[TTYPE] = T_SLICE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 39;
    DeRef(_1);

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6633 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6633) && IS_ATOM(_29Look_11214)) {
        Append(&_6634, _6633, _29Look_11214);
    }
    else if (IS_ATOM(_6633) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6634, _6633, _29Look_11214);
        _6633 = NOVALUE;
    }
    _6633 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6634;
    if( _1 != _6634 ){
        DeRef(_1);
    }
    _6634 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();
    goto L7; // [347] 736
LB: 

    /** 				Token[TTYPE] = T_NUMBER*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);

    /** 				Token[TDATA] = scan_fraction(0)*/
    _6635 = _29scan_fraction(0);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6635;
    if( _1 != _6635 ){
        DeRef(_1);
    }
    _6635 = NOVALUE;

    /** 				Token[TFORM] = TF_ATOM*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 				if ERR then*/
    if (_29ERR_11215 == 0)
    {
        goto LC; // [382] 391
    }
    else{
    }

    /** 					return*/
    DeRef(_6604);
    _6604 = NOVALUE;
    DeRef(_6621);
    _6621 = NOVALUE;
    return;
LC: 

    /** 				Token[TDATA] = scan_exponent(Token[TDATA])*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6636 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6636);
    _6637 = _29scan_exponent(_6636);
    _6636 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6637;
    if( _1 != _6637 ){
        DeRef(_1);
    }
    _6637 = NOVALUE;

    /** 				if STRING_NUMBERS then*/
    if (_29STRING_NUMBERS_11259 == 0)
    {
        goto L7; // [413] 736
    }
    else{
    }

    /** 					if integer(Token[TDATA]) then*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6638 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6638))
    _6639 = 1;
    else if (IS_ATOM_DBL(_6638))
    _6639 = IS_ATOM_INT(DoubleToInt(_6638));
    else
    _6639 = 0;
    _6638 = NOVALUE;
    if (_6639 == 0)
    {
        _6639 = NOVALUE;
        goto LD; // [427] 455
    }
    else{
        _6639 = NOVALUE;
    }

    /** 						Token[TDATA] = sprintf("%d",{Token[TDATA]})*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6640 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6640);
    *((int *)(_2+4)) = _6640;
    _6641 = MAKE_SEQ(_1);
    _6640 = NOVALUE;
    _6642 = EPrintf(-9999999, _919, _6641);
    DeRefDS(_6641);
    _6641 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6642;
    if( _1 != _6642 ){
        DeRef(_1);
    }
    _6642 = NOVALUE;
    goto L7; // [452] 736
LD: 

    /** 						Token[TDATA] = sprintf("%g",{Token[TDATA]})*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6644 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6644);
    *((int *)(_2+4)) = _6644;
    _6645 = MAKE_SEQ(_1);
    _6644 = NOVALUE;
    _6646 = EPrintf(-9999999, _6643, _6645);
    DeRefDS(_6645);
    _6645 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6646;
    if( _1 != _6646 ){
        DeRef(_1);
    }
    _6646 = NOVALUE;
    goto L7; // [480] 736
LA: 

    /** 		elsif (Look = '-') and (Token[TTYPE] = T_MINUS) then*/
    _6647 = (_29Look_11214 == 45);
    if (_6647 == 0) {
        goto LE; // [491] 590
    }
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6649 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6649)) {
        _6650 = (_6649 == 20);
    }
    else {
        _6650 = binary_op(EQUALS, _6649, 20);
    }
    _6649 = NOVALUE;
    if (_6650 == 0) {
        DeRef(_6650);
        _6650 = NOVALUE;
        goto LE; // [506] 590
    }
    else {
        if (!IS_ATOM_INT(_6650) && DBL_PTR(_6650)->dbl == 0.0){
            DeRef(_6650);
            _6650 = NOVALUE;
            goto LE; // [506] 590
        }
        DeRef(_6650);
        _6650 = NOVALUE;
    }
    DeRef(_6650);
    _6650 = NOVALUE;

    /** 			Token[TTYPE] = T_COMMENT*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);

    /** 			Token[TDATA] = "--"*/
    RefDS(_6651);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6651;
    DeRef(_1);

    /** 			Token[TFORM] = TF_COMMENT_SINGLE*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);

    /** 			scan_char()*/
    _29scan_char();

    /** 			while (Look != EOL) do*/
LF: 
    if (_29Look_11214 == 10)
    goto L10; // [544] 575

    /** 				Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6653 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6653) && IS_ATOM(_29Look_11214)) {
        Append(&_6654, _6653, _29Look_11214);
    }
    else if (IS_ATOM(_6653) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6654, _6653, _29Look_11214);
        _6653 = NOVALUE;
    }
    _6653 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6654;
    if( _1 != _6654 ){
        DeRef(_1);
    }
    _6654 = NOVALUE;

    /** 				scan_char()*/
    _29scan_char();

    /** 			end while*/
    goto LF; // [572] 542
L10: 

    /** 			if IGNORE_COMMENTS then*/
    if (_29IGNORE_COMMENTS_11258 == 0)
    {
        goto L7; // [579] 736
    }
    else{
    }

    /** 				next_token()*/
    _29next_token();
    goto L7; // [587] 736
LE: 

    /** 		elsif (Look = '*') and (Token[TTYPE] = T_DIVIDE) then*/
    _6655 = (_29Look_11214 == 42);
    if (_6655 == 0) {
        goto L7; // [598] 736
    }
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6657 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_6657)) {
        _6658 = (_6657 == 22);
    }
    else {
        _6658 = binary_op(EQUALS, _6657, 22);
    }
    _6657 = NOVALUE;
    if (_6658 == 0) {
        DeRef(_6658);
        _6658 = NOVALUE;
        goto L7; // [613] 736
    }
    else {
        if (!IS_ATOM_INT(_6658) && DBL_PTR(_6658)->dbl == 0.0){
            DeRef(_6658);
            _6658 = NOVALUE;
            goto L7; // [613] 736
        }
        DeRef(_6658);
        _6658 = NOVALUE;
    }
    DeRef(_6658);
    _6658 = NOVALUE;

    /** 			scan_multicomment()*/
    _6659 = _29scan_multicomment();
    goto L7; // [623] 736
L5: 

    /** 	elsif scan_identifier() then*/
    _6660 = _29scan_identifier();
    if (_6660 == 0) {
        DeRef(_6660);
        _6660 = NOVALUE;
        goto L11; // [631] 637
    }
    else {
        if (!IS_ATOM_INT(_6660) && DBL_PTR(_6660)->dbl == 0.0){
            DeRef(_6660);
            _6660 = NOVALUE;
            goto L11; // [631] 637
        }
        DeRef(_6660);
        _6660 = NOVALUE;
    }
    DeRef(_6660);
    _6660 = NOVALUE;
    goto L7; // [634] 736
L11: 

    /** 	elsif scan_qchar() then*/
    _6661 = _29scan_qchar();
    if (_6661 == 0) {
        DeRef(_6661);
        _6661 = NOVALUE;
        goto L12; // [642] 648
    }
    else {
        if (!IS_ATOM_INT(_6661) && DBL_PTR(_6661)->dbl == 0.0){
            DeRef(_6661);
            _6661 = NOVALUE;
            goto L12; // [642] 648
        }
        DeRef(_6661);
        _6661 = NOVALUE;
    }
    DeRef(_6661);
    _6661 = NOVALUE;
    goto L7; // [645] 736
L12: 

    /** 	elsif scan_string() then*/
    _6662 = _29scan_string();
    if (_6662 == 0) {
        DeRef(_6662);
        _6662 = NOVALUE;
        goto L13; // [653] 659
    }
    else {
        if (!IS_ATOM_INT(_6662) && DBL_PTR(_6662)->dbl == 0.0){
            DeRef(_6662);
            _6662 = NOVALUE;
            goto L13; // [653] 659
        }
        DeRef(_6662);
        _6662 = NOVALUE;
    }
    DeRef(_6662);
    _6662 = NOVALUE;
    goto L7; // [656] 736
L13: 

    /** 	elsif scan_multistring() then*/
    _6663 = _29scan_multistring();
    if (_6663 == 0) {
        DeRef(_6663);
        _6663 = NOVALUE;
        goto L14; // [664] 670
    }
    else {
        if (!IS_ATOM_INT(_6663) && DBL_PTR(_6663)->dbl == 0.0){
            DeRef(_6663);
            _6663 = NOVALUE;
            goto L14; // [664] 670
        }
        DeRef(_6663);
        _6663 = NOVALUE;
    }
    DeRef(_6663);
    _6663 = NOVALUE;
    goto L7; // [667] 736
L14: 

    /** 	elsif scan_prefixed_number() then*/
    _6664 = _29scan_prefixed_number();
    if (_6664 == 0) {
        DeRef(_6664);
        _6664 = NOVALUE;
        goto L15; // [675] 681
    }
    else {
        if (!IS_ATOM_INT(_6664) && DBL_PTR(_6664)->dbl == 0.0){
            DeRef(_6664);
            _6664 = NOVALUE;
            goto L15; // [675] 681
        }
        DeRef(_6664);
        _6664 = NOVALUE;
    }
    DeRef(_6664);
    _6664 = NOVALUE;
    goto L7; // [678] 736
L15: 

    /** 	elsif scan_hex() then*/
    _6665 = _29scan_hex();
    if (_6665 == 0) {
        DeRef(_6665);
        _6665 = NOVALUE;
        goto L16; // [686] 692
    }
    else {
        if (!IS_ATOM_INT(_6665) && DBL_PTR(_6665)->dbl == 0.0){
            DeRef(_6665);
            _6665 = NOVALUE;
            goto L16; // [686] 692
        }
        DeRef(_6665);
        _6665 = NOVALUE;
    }
    DeRef(_6665);
    _6665 = NOVALUE;
    goto L7; // [689] 736
L16: 

    /** 	elsif scan_number() then*/
    _6666 = _29scan_number();
    if (_6666 == 0) {
        DeRef(_6666);
        _6666 = NOVALUE;
        goto L17; // [697] 703
    }
    else {
        if (!IS_ATOM_INT(_6666) && DBL_PTR(_6666)->dbl == 0.0){
            DeRef(_6666);
            _6666 = NOVALUE;
            goto L17; // [697] 703
        }
        DeRef(_6666);
        _6666 = NOVALUE;
    }
    DeRef(_6666);
    _6666 = NOVALUE;
    goto L7; // [700] 736
L17: 

    /** 		Token[TTYPE] = T_EOF*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 		Token[TDATA] = Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29Look_11214;
    DeRef(_1);

    /** 		if (Look != io:EOF) then*/
    if (_29Look_11214 == -1)
    goto L18; // [725] 735

    /** 			report_error(ERR_UNKNOWN)*/
    _29report_error(8);
L18: 
L7: 

    /** end procedure*/
    DeRef(_6604);
    _6604 = NOVALUE;
    DeRef(_6621);
    _6621 = NOVALUE;
    DeRef(_6647);
    _6647 = NOVALUE;
    DeRef(_6655);
    _6655 = NOVALUE;
    DeRef(_6659);
    _6659 = NOVALUE;
    return;
    ;
}


int _29tokenize_string(int _code_11827)
{
    int _tokens_11828 = NOVALUE;
    int _6687 = NOVALUE;
    int _6685 = NOVALUE;
    int _6683 = NOVALUE;
    int _6680 = NOVALUE;
    int _6679 = NOVALUE;
    int _6678 = NOVALUE;
    int _6676 = NOVALUE;
    int _6674 = NOVALUE;
    int _6673 = NOVALUE;
    int _6672 = NOVALUE;
    int _6671 = NOVALUE;
    int _6670 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ERR = FALSE*/
    _29ERR_11215 = 0;

    /** 	ERR_LNUM = 0*/
    _29ERR_LNUM_11216 = 0;

    /** 	ERR_LPOS = 0*/
    _29ERR_LPOS_11217 = 0;

    /** 	tokens = {}*/
    RefDS(_5);
    DeRef(_tokens_11828);
    _tokens_11828 = _5;

    /** 	source_text = code & EOL & io:EOF*/
    {
        int concat_list[3];

        concat_list[0] = -1;
        concat_list[1] = 10;
        concat_list[2] = _code_11827;
        Concat_N((object_ptr)&_29source_text_11210, concat_list, 3);
    }

    /** 	LNum = 1*/
    _29LNum_11212 = 1;

    /** 	LPos = 1*/
    _29LPos_11213 = 1;

    /** 	sti = 1*/
    _29sti_11211 = 1;

    /** 	Look = source_text[sti]*/
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _29Look_11214 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_29Look_11214))
    _29Look_11214 = (long)DBL_PTR(_29Look_11214)->dbl;

    /** 	Token[TTYPE] = io:EOF*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	Token[TDATA] = ""*/
    RefDS(_5);
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);

    /** 	Token[TLNUM] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	Token[TLPOS] = 1*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	if (Look = '#') and (source_text[sti+1] = '!') then*/
    _6670 = (_29Look_11214 == 35);
    if (_6670 == 0) {
        goto L1; // [98] 202
    }
    _6672 = 2;
    _2 = (int)SEQ_PTR(_29source_text_11210);
    _6673 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6673)) {
        _6674 = (_6673 == 33);
    }
    else {
        _6674 = binary_op(EQUALS, _6673, 33);
    }
    _6673 = NOVALUE;
    if (_6674 == 0) {
        DeRef(_6674);
        _6674 = NOVALUE;
        goto L1; // [119] 202
    }
    else {
        if (!IS_ATOM_INT(_6674) && DBL_PTR(_6674)->dbl == 0.0){
            DeRef(_6674);
            _6674 = NOVALUE;
            goto L1; // [119] 202
        }
        DeRef(_6674);
        _6674 = NOVALUE;
    }
    DeRef(_6674);
    _6674 = NOVALUE;

    /** 		sti += 1*/
    _29sti_11211 = _29sti_11211 + 1;

    /** 		scan_char()*/
    _29scan_char();

    /** 		scan_white()*/
    _6676 = _29scan_white();

    /** 		Token[TTYPE] = T_SHBANG*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);

    /** 		while Look != EOL do*/
L2: 
    if (_29Look_11214 == 10)
    goto L3; // [154] 185

    /** 			Token[TDATA] &= Look*/
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6678 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_6678) && IS_ATOM(_29Look_11214)) {
        Append(&_6679, _6678, _29Look_11214);
    }
    else if (IS_ATOM(_6678) && IS_SEQUENCE(_29Look_11214)) {
    }
    else {
        Concat((object_ptr)&_6679, _6678, _29Look_11214);
        _6678 = NOVALUE;
    }
    _6678 = NOVALUE;
    _2 = (int)SEQ_PTR(_29Token_11208);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29Token_11208 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6679;
    if( _1 != _6679 ){
        DeRef(_1);
    }
    _6679 = NOVALUE;

    /** 			scan_char()*/
    _29scan_char();

    /** 		end while*/
    goto L2; // [182] 152
L3: 

    /** 		scan_char()*/
    _29scan_char();

    /** 		tokens &= { Token }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_29Token_11208);
    *((int *)(_2+4)) = _29Token_11208;
    _6680 = MAKE_SEQ(_1);
    Concat((object_ptr)&_tokens_11828, _tokens_11828, _6680);
    DeRefDS(_6680);
    _6680 = NOVALUE;
L1: 

    /** 	next_token()*/
    _29next_token();

    /** 	if not ERR then*/
    if (_29ERR_11215 != 0)
    goto L4; // [210] 262

    /** 		while Token[TTYPE] != T_EOF do*/
L5: 
    _2 = (int)SEQ_PTR(_29Token_11208);
    _6683 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _6683, 1)){
        _6683 = NOVALUE;
        goto L6; // [224] 261
    }
    _6683 = NOVALUE;

    /** 			tokens &= { Token }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_29Token_11208);
    *((int *)(_2+4)) = _29Token_11208;
    _6685 = MAKE_SEQ(_1);
    Concat((object_ptr)&_tokens_11828, _tokens_11828, _6685);
    DeRefDS(_6685);
    _6685 = NOVALUE;

    /** 			next_token()*/
    _29next_token();

    /** 			if ERR then*/
    if (_29ERR_11215 == 0)
    {
        goto L5; // [248] 218
    }
    else{
    }

    /** 				exit */
    goto L6; // [253] 261

    /** 		end while*/
    goto L5; // [258] 218
L6: 
L4: 

    /** 	return { tokens, ERR, ERR_LNUM, ERR_LPOS }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_tokens_11828);
    *((int *)(_2+4)) = _tokens_11828;
    *((int *)(_2+8)) = _29ERR_11215;
    *((int *)(_2+12)) = _29ERR_LNUM_11216;
    *((int *)(_2+16)) = _29ERR_LPOS_11217;
    _6687 = MAKE_SEQ(_1);
    DeRefDS(_code_11827);
    DeRefDS(_tokens_11828);
    DeRef(_6670);
    _6670 = NOVALUE;
    DeRef(_6672);
    _6672 = NOVALUE;
    DeRef(_6676);
    _6676 = NOVALUE;
    return _6687;
    ;
}
int tokenize_string() __attribute__ ((alias ("_29tokenize_string")));


int _29tokenize_file(int _fname_11856)
{
    int _txt_11857 = NOVALUE;
    int _6693 = NOVALUE;
    int _6692 = NOVALUE;
    int _6691 = NOVALUE;
    int _6690 = NOVALUE;
    int _6689 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object txt = io:read_file(fname, io:TEXT_MODE)*/
    RefDS(_fname_11856);
    _0 = _txt_11857;
    _txt_11857 = _18read_file(_fname_11856, 2);
    DeRef(_0);

    /** 	if atom(txt) and txt = -1 then*/
    _6689 = IS_ATOM(_txt_11857);
    if (_6689 == 0) {
        goto L1; // [15] 45
    }
    if (IS_ATOM_INT(_txt_11857)) {
        _6691 = (_txt_11857 == -1);
    }
    else {
        _6691 = binary_op(EQUALS, _txt_11857, -1);
    }
    if (_6691 == 0) {
        DeRef(_6691);
        _6691 = NOVALUE;
        goto L1; // [24] 45
    }
    else {
        if (!IS_ATOM_INT(_6691) && DBL_PTR(_6691)->dbl == 0.0){
            DeRef(_6691);
            _6691 = NOVALUE;
            goto L1; // [24] 45
        }
        DeRef(_6691);
        _6691 = NOVALUE;
    }
    DeRef(_6691);
    _6691 = NOVALUE;

    /** 		return {{}, ERR_OPEN, ERR_LNUM, ERR_LPOS}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5);
    *((int *)(_2+4)) = _5;
    *((int *)(_2+8)) = 1;
    *((int *)(_2+12)) = _29ERR_LNUM_11216;
    *((int *)(_2+16)) = _29ERR_LPOS_11217;
    _6692 = MAKE_SEQ(_1);
    DeRefDS(_fname_11856);
    DeRef(_txt_11857);
    return _6692;
L1: 

    /** 	return tokenize_string(txt)*/
    Ref(_txt_11857);
    _6693 = _29tokenize_string(_txt_11857);
    DeRefDS(_fname_11856);
    DeRef(_txt_11857);
    DeRef(_6692);
    _6692 = NOVALUE;
    return _6693;
    ;
}
int tokenize_file() __attribute__ ((alias ("_29tokenize_file")));


void _29show_tokens(int _fh_11919, int _tokens_11920)
{
    int _v_11937 = NOVALUE;
    int _6789 = NOVALUE;
    int _6788 = NOVALUE;
    int _6787 = NOVALUE;
    int _6786 = NOVALUE;
    int _6785 = NOVALUE;
    int _6784 = NOVALUE;
    int _6782 = NOVALUE;
    int _6781 = NOVALUE;
    int _6780 = NOVALUE;
    int _6778 = NOVALUE;
    int _6777 = NOVALUE;
    int _6776 = NOVALUE;
    int _6775 = NOVALUE;
    int _6773 = NOVALUE;
    int _6772 = NOVALUE;
    int _6771 = NOVALUE;
    int _6769 = NOVALUE;
    int _6768 = NOVALUE;
    int _6767 = NOVALUE;
    int _6766 = NOVALUE;
    int _6763 = NOVALUE;
    int _6761 = NOVALUE;
    int _6759 = NOVALUE;
    int _6758 = NOVALUE;
    int _6756 = NOVALUE;
    int _6755 = NOVALUE;
    int _6754 = NOVALUE;
    int _6753 = NOVALUE;
    int _6752 = NOVALUE;
    int _6751 = NOVALUE;
    int _6750 = NOVALUE;
    int _6746 = NOVALUE;
    int _6745 = NOVALUE;
    int _6744 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fh_11919)) {
        _1 = (long)(DBL_PTR(_fh_11919)->dbl);
        DeRefDS(_fh_11919);
        _fh_11919 = _1;
    }

    /** 	for i = 1 to length(tokens) do*/
    if (IS_SEQUENCE(_tokens_11920)){
            _6744 = SEQ_PTR(_tokens_11920)->length;
    }
    else {
        _6744 = 1;
    }
    {
        int _i_11922;
        _i_11922 = 1;
L1: 
        if (_i_11922 > _6744){
            goto L2; // [10] 271
        }

        /** 		switch tokens[i][TTYPE] do*/
        _2 = (int)SEQ_PTR(_tokens_11920);
        _6745 = (int)*(((s1_ptr)_2)->base + _i_11922);
        _2 = (int)SEQ_PTR(_6745);
        _6746 = (int)*(((s1_ptr)_2)->base + 1);
        _6745 = NOVALUE;
        if (IS_SEQUENCE(_6746) ){
            goto L3; // [27] 167
        }
        if(!IS_ATOM_INT(_6746)){
            if( (DBL_PTR(_6746)->dbl != (double) ((int) DBL_PTR(_6746)->dbl) ) ){
                goto L3; // [27] 167
            }
            _0 = (int) DBL_PTR(_6746)->dbl;
        }
        else {
            _0 = _6746;
        };
        _6746 = NOVALUE;
        switch ( _0 ){ 

            /** 			case T_STRING then*/
            case 8:

            /** 				printf(fh, "T_STRING %20s : [[[%s]]]\n", { */
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6750 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6750);
            _6751 = (int)*(((s1_ptr)_2)->base + 5);
            _6750 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_forms_11906);
            if (!IS_ATOM_INT(_6751)){
                _6752 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6751)->dbl));
            }
            else{
                _6752 = (int)*(((s1_ptr)_2)->base + _6751);
            }
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6753 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6753);
            _6754 = (int)*(((s1_ptr)_2)->base + 2);
            _6753 = NOVALUE;
            Ref(_6754);
            RefDS(_6752);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6752;
            ((int *)_2)[2] = _6754;
            _6755 = MAKE_SEQ(_1);
            _6754 = NOVALUE;
            _6752 = NOVALUE;
            EPrintf(_fh_11919, _6749, _6755);
            DeRefDS(_6755);
            _6755 = NOVALUE;
            goto L4; // [68] 264

            /** 			case T_NUMBER then*/
            case 6:

            /** 				object v = tokens[i][TDATA]*/
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6756 = (int)*(((s1_ptr)_2)->base + _i_11922);
            DeRef(_v_11937);
            _2 = (int)SEQ_PTR(_6756);
            _v_11937 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_v_11937);
            _6756 = NOVALUE;

            /** 				if integer(v) then*/
            if (IS_ATOM_INT(_v_11937))
            _6758 = 1;
            else if (IS_ATOM_DBL(_v_11937))
            _6758 = IS_ATOM_INT(DoubleToInt(_v_11937));
            else
            _6758 = 0;
            if (_6758 == 0)
            {
                _6758 = NOVALUE;
                goto L5; // [89] 105
            }
            else{
                _6758 = NOVALUE;
            }

            /** 					v = sprintf("%d", { v })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_v_11937);
            *((int *)(_2+4)) = _v_11937;
            _6759 = MAKE_SEQ(_1);
            DeRef(_v_11937);
            _v_11937 = EPrintf(-9999999, _919, _6759);
            DeRefDS(_6759);
            _6759 = NOVALUE;
            goto L6; // [102] 125
L5: 

            /** 				elsif atom(v) then*/
            _6761 = IS_ATOM(_v_11937);
            if (_6761 == 0)
            {
                _6761 = NOVALUE;
                goto L7; // [110] 124
            }
            else{
                _6761 = NOVALUE;
            }

            /** 					v = sprintf("%f", { v })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_v_11937);
            *((int *)(_2+4)) = _v_11937;
            _6763 = MAKE_SEQ(_1);
            DeRef(_v_11937);
            _v_11937 = EPrintf(-9999999, _6762, _6763);
            DeRefDS(_6763);
            _6763 = NOVALUE;
L7: 
L6: 

            /** 				printf(fh, "T_NUMBER %20s : %s\n", { */
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6766 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6766);
            _6767 = (int)*(((s1_ptr)_2)->base + 5);
            _6766 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_forms_11906);
            if (!IS_ATOM_INT(_6767)){
                _6768 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6767)->dbl));
            }
            else{
                _6768 = (int)*(((s1_ptr)_2)->base + _6767);
            }
            Ref(_v_11937);
            RefDS(_6768);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6768;
            ((int *)_2)[2] = _v_11937;
            _6769 = MAKE_SEQ(_1);
            _6768 = NOVALUE;
            EPrintf(_fh_11919, _6765, _6769);
            DeRefDS(_6769);
            _6769 = NOVALUE;
            DeRef(_v_11937);
            _v_11937 = NOVALUE;
            goto L4; // [151] 264

            /** 			case T_NEWLINE then*/
            case 4:

            /** 				printf(fh, "T_NEWLINE                     : \\n\n", {})*/
            EPrintf(_fh_11919, _6770, _5);
            goto L4; // [163] 264

            /** 			case else*/
            default:
L3: 

            /** 				if tokens[i][TTYPE] < 1 or tokens[i][TTYPE] > length(token_names) then*/
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6771 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6771);
            _6772 = (int)*(((s1_ptr)_2)->base + 1);
            _6771 = NOVALUE;
            if (IS_ATOM_INT(_6772)) {
                _6773 = (_6772 < 1);
            }
            else {
                _6773 = binary_op(LESS, _6772, 1);
            }
            _6772 = NOVALUE;
            if (IS_ATOM_INT(_6773)) {
                if (_6773 != 0) {
                    goto L8; // [183] 209
                }
            }
            else {
                if (DBL_PTR(_6773)->dbl != 0.0) {
                    goto L8; // [183] 209
                }
            }
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6775 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6775);
            _6776 = (int)*(((s1_ptr)_2)->base + 1);
            _6775 = NOVALUE;
            _6777 = 39;
            if (IS_ATOM_INT(_6776)) {
                _6778 = (_6776 > 39);
            }
            else {
                _6778 = binary_op(GREATER, _6776, 39);
            }
            _6776 = NOVALUE;
            _6777 = NOVALUE;
            if (_6778 == 0) {
                DeRef(_6778);
                _6778 = NOVALUE;
                goto L9; // [205] 230
            }
            else {
                if (!IS_ATOM_INT(_6778) && DBL_PTR(_6778)->dbl == 0.0){
                    DeRef(_6778);
                    _6778 = NOVALUE;
                    goto L9; // [205] 230
                }
                DeRef(_6778);
                _6778 = NOVALUE;
            }
            DeRef(_6778);
            _6778 = NOVALUE;
L8: 

            /** 					printf(fh, "UNKNOWN                       : %d\n", { tokens[i][TTYPE] })*/
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6780 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6780);
            _6781 = (int)*(((s1_ptr)_2)->base + 1);
            _6780 = NOVALUE;
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_6781);
            *((int *)(_2+4)) = _6781;
            _6782 = MAKE_SEQ(_1);
            _6781 = NOVALUE;
            EPrintf(_fh_11919, _6779, _6782);
            DeRefDS(_6782);
            _6782 = NOVALUE;
            goto LA; // [227] 263
L9: 

            /** 					printf(fh, "%-29s : %s\n", { */
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6784 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6784);
            _6785 = (int)*(((s1_ptr)_2)->base + 1);
            _6784 = NOVALUE;
            _2 = (int)SEQ_PTR(_29token_names_11865);
            if (!IS_ATOM_INT(_6785)){
                _6786 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_6785)->dbl));
            }
            else{
                _6786 = (int)*(((s1_ptr)_2)->base + _6785);
            }
            _2 = (int)SEQ_PTR(_tokens_11920);
            _6787 = (int)*(((s1_ptr)_2)->base + _i_11922);
            _2 = (int)SEQ_PTR(_6787);
            _6788 = (int)*(((s1_ptr)_2)->base + 2);
            _6787 = NOVALUE;
            Ref(_6788);
            RefDS(_6786);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _6786;
            ((int *)_2)[2] = _6788;
            _6789 = MAKE_SEQ(_1);
            _6788 = NOVALUE;
            _6786 = NOVALUE;
            EPrintf(_fh_11919, _6783, _6789);
            DeRefDS(_6789);
            _6789 = NOVALUE;
LA: 
        ;}L4: 

        /** 	end for*/
        _i_11922 = _i_11922 + 1;
        goto L1; // [266] 17
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_tokens_11920);
    _6751 = NOVALUE;
    _6767 = NOVALUE;
    _6785 = NOVALUE;
    DeRef(_6773);
    _6773 = NOVALUE;
    return;
    ;
}
void show_tokens() __attribute__ ((alias ("_29show_tokens")));



// 0x5083FB99
