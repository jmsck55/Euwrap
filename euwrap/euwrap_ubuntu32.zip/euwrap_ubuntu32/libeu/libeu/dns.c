// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _53host_by_name(int _name_22649)
{
    int _12611 = NOVALUE;
    int _12610 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETHOSTBYNAME, { name })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_22649);
    *((int *)(_2+4)) = _name_22649;
    _12610 = MAKE_SEQ(_1);
    _12611 = machine(79, _12610);
    DeRefDS(_12610);
    _12610 = NOVALUE;
    DeRefDS(_name_22649);
    return _12611;
    ;
}
int host_by_name() __attribute__ ((alias ("_53host_by_name")));


int _53host_by_addr(int _address_22654)
{
    int _12613 = NOVALUE;
    int _12612 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SOCK_GETHOSTBYADDR, { address })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_address_22654);
    *((int *)(_2+4)) = _address_22654;
    _12612 = MAKE_SEQ(_1);
    _12613 = machine(80, _12612);
    DeRefDS(_12612);
    _12612 = NOVALUE;
    DeRefDS(_address_22654);
    return _12613;
    ;
}
int host_by_addr() __attribute__ ((alias ("_53host_by_addr")));



// 0xBC9E9582
