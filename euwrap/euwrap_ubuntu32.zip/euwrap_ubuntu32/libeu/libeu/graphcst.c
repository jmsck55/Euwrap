// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _36color(int _x_14159)
{
    int _8041 = NOVALUE;
    int _8040 = NOVALUE;
    int _8039 = NOVALUE;
    int _8038 = NOVALUE;
    int _8037 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) and x >= 0 and x <= 255 then*/
    if (IS_ATOM_INT(_x_14159))
    _8037 = 1;
    else if (IS_ATOM_DBL(_x_14159))
    _8037 = IS_ATOM_INT(DoubleToInt(_x_14159));
    else
    _8037 = 0;
    if (_8037 == 0) {
        _8038 = 0;
        goto L1; // [6] 18
    }
    if (IS_ATOM_INT(_x_14159)) {
        _8039 = (_x_14159 >= 0);
    }
    else {
        _8039 = binary_op(GREATEREQ, _x_14159, 0);
    }
    if (IS_ATOM_INT(_8039))
    _8038 = (_8039 != 0);
    else
    _8038 = DBL_PTR(_8039)->dbl != 0.0;
L1: 
    if (_8038 == 0) {
        goto L2; // [18] 39
    }
    if (IS_ATOM_INT(_x_14159)) {
        _8041 = (_x_14159 <= 255);
    }
    else {
        _8041 = binary_op(LESSEQ, _x_14159, 255);
    }
    if (_8041 == 0) {
        DeRef(_8041);
        _8041 = NOVALUE;
        goto L2; // [27] 39
    }
    else {
        if (!IS_ATOM_INT(_8041) && DBL_PTR(_8041)->dbl == 0.0){
            DeRef(_8041);
            _8041 = NOVALUE;
            goto L2; // [27] 39
        }
        DeRef(_8041);
        _8041 = NOVALUE;
    }
    DeRef(_8041);
    _8041 = NOVALUE;

    /** 		return 1*/
    DeRef(_x_14159);
    DeRef(_8039);
    _8039 = NOVALUE;
    return 1;
    goto L3; // [36] 46
L2: 

    /** 		return 0*/
    DeRef(_x_14159);
    DeRef(_8039);
    _8039 = NOVALUE;
    return 0;
L3: 
    ;
}
int color() __attribute__ ((alias ("_36color")));


int _36mixture(int _s_14169)
{
    int _8050 = NOVALUE;
    int _8048 = NOVALUE;
    int _8046 = NOVALUE;
    int _8045 = NOVALUE;
    int _8043 = NOVALUE;
    int _8042 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _8042 = IS_ATOM(_s_14169);
    if (_8042 == 0)
    {
        _8042 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _8042 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_s_14169);
    return 0;
L1: 

    /** 	if length(s) != 3 then*/
    if (IS_SEQUENCE(_s_14169)){
            _8043 = SEQ_PTR(_s_14169)->length;
    }
    else {
        _8043 = 1;
    }
    if (_8043 == 3)
    goto L2; // [21] 32

    /** 		return 0*/
    DeRef(_s_14169);
    return 0;
L2: 

    /** 	for i=1 to 3 do*/
    {
        int _i_14176;
        _i_14176 = 1;
L3: 
        if (_i_14176 > 3){
            goto L4; // [34] 87
        }

        /** 		if not integer(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_14169);
        _8045 = (int)*(((s1_ptr)_2)->base + _i_14176);
        if (IS_ATOM_INT(_8045))
        _8046 = 1;
        else if (IS_ATOM_DBL(_8045))
        _8046 = IS_ATOM_INT(DoubleToInt(_8045));
        else
        _8046 = 0;
        _8045 = NOVALUE;
        if (_8046 != 0)
        goto L5; // [50] 60
        _8046 = NOVALUE;

        /** 			return 0*/
        DeRef(_s_14169);
        return 0;
L5: 

        /**   		if and_bits(s[i],#FFFFFFC0) then*/
        _2 = (int)SEQ_PTR(_s_14169);
        _8048 = (int)*(((s1_ptr)_2)->base + _i_14176);
        _8050 = binary_op(AND_BITS, _8048, _8049);
        _8048 = NOVALUE;
        if (_8050 == 0) {
            DeRef(_8050);
            _8050 = NOVALUE;
            goto L6; // [70] 80
        }
        else {
            if (!IS_ATOM_INT(_8050) && DBL_PTR(_8050)->dbl == 0.0){
                DeRef(_8050);
                _8050 = NOVALUE;
                goto L6; // [70] 80
            }
            DeRef(_8050);
            _8050 = NOVALUE;
        }
        DeRef(_8050);
        _8050 = NOVALUE;

        /**   			return 0*/
        DeRef(_s_14169);
        return 0;
L6: 

        /** 	end for*/
        _i_14176 = _i_14176 + 1;
        goto L3; // [82] 41
L4: 
        ;
    }

    /** 	return 1*/
    DeRef(_s_14169);
    return 1;
    ;
}
int mixture() __attribute__ ((alias ("_36mixture")));


int _36video_config()
{
    int _8051 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_VIDEO_CONFIG, 0)*/
    _8051 = machine(13, 0);
    return _8051;
    ;
}
int video_config() __attribute__ ((alias ("_36video_config")));



// 0x7B906EB7
