// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _51task_delay(int _delaytime_22557)
{
    int _t_22558 = NOVALUE;
    int _12598 = NOVALUE;
    int _12597 = NOVALUE;
    int _0, _1, _2;
    

    /** 	t = time()*/
    DeRef(_t_22558);
    _t_22558 = NewDouble(current_time());

    /** 	while time() - t < delaytime do*/
L1: 
    DeRef(_12597);
    _12597 = NewDouble(current_time());
    if (IS_ATOM_INT(_t_22558)) {
        _12598 = NewDouble(DBL_PTR(_12597)->dbl - (double)_t_22558);
    }
    else
    _12598 = NewDouble(DBL_PTR(_12597)->dbl - DBL_PTR(_t_22558)->dbl);
    DeRefDS(_12597);
    _12597 = NOVALUE;
    if (binary_op_a(GREATEREQ, _12598, _delaytime_22557)){
        DeRefDS(_12598);
        _12598 = NOVALUE;
        goto L2; // [16] 33
    }
    DeRef(_12598);
    _12598 = NOVALUE;

    /** 		machine_proc(M_SLEEP, 0.01)*/
    machine(64, _12600);

    /** 		task_yield()*/

    /** 	end while*/
    goto L1; // [30] 10
L2: 

    /** end procedure*/
    DeRef(_delaytime_22557);
    DeRef(_t_22558);
    return;
    ;
}
void task_delay() __attribute__ ((alias ("_51task_delay")));



// 0x427E417D
