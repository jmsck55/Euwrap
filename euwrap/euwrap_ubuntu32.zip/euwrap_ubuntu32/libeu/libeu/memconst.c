// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _15valid_memory_protection_constant(int _x_1842)
{
    int _951 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _951 = find_from(_x_1842, _15MEMORY_PROTECTION_1838, 1);
    DeRef(_x_1842);
    return _951;
    ;
}


int _15test_read(int _protection_1846)
{
    int _953 = NOVALUE;
    int _952 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_READ,protection) != 0*/
    if (IS_ATOM_INT(_protection_1846)) {
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_protection_1846;
             _952 = MAKE_UINT(tu);
        }
    }
    else {
        _952 = binary_op(AND_BITS, 1, _protection_1846);
    }
    if (IS_ATOM_INT(_952)) {
        _953 = (_952 != 0);
    }
    else {
        _953 = binary_op(NOTEQ, _952, 0);
    }
    DeRef(_952);
    _952 = NOVALUE;
    DeRef(_protection_1846);
    return _953;
    ;
}


int _15test_write(int _protection_1851)
{
    int _955 = NOVALUE;
    int _954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_WRITE,protection) != 0*/
    if (IS_ATOM_INT(_protection_1851)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_protection_1851;
             _954 = MAKE_UINT(tu);
        }
    }
    else {
        _954 = binary_op(AND_BITS, 2, _protection_1851);
    }
    if (IS_ATOM_INT(_954)) {
        _955 = (_954 != 0);
    }
    else {
        _955 = binary_op(NOTEQ, _954, 0);
    }
    DeRef(_954);
    _954 = NOVALUE;
    DeRef(_protection_1851);
    return _955;
    ;
}


int _15test_exec(int _protection_1856)
{
    int _957 = NOVALUE;
    int _956 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_EXEC,protection) != 0*/
    if (IS_ATOM_INT(_protection_1856)) {
        {unsigned long tu;
             tu = (unsigned long)4 & (unsigned long)_protection_1856;
             _956 = MAKE_UINT(tu);
        }
    }
    else {
        _956 = binary_op(AND_BITS, 4, _protection_1856);
    }
    if (IS_ATOM_INT(_956)) {
        _957 = (_956 != 0);
    }
    else {
        _957 = binary_op(NOTEQ, _956, 0);
    }
    DeRef(_956);
    _956 = NOVALUE;
    DeRef(_protection_1856);
    return _957;
    ;
}


int _15valid_wordsize(int _i_1861)
{
    int _959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _959 = find_from(_i_1861, _958, 1);
    DeRef(_i_1861);
    return _959;
    ;
}



// 0x5FDA24A0
