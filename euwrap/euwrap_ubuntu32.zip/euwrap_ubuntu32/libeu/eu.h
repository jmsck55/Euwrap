// Copyright (C) 2020 James J. Cook


// To be able to execute on Linux, do the following:
/*

LD_LIBRARY_PATH=$PWD
export LD_LIBRARY_PATH
gcc -o testdl testdl.c -ldl
./testdl

*/


#pragma once
#ifndef euwrap_h__
#define euwrap_h__

// comment this line out for Linux:
#define WIN32

#ifndef USE_PRECOMPILED_HEADERS
#ifdef WIN32
//#include <direct.h>
#include <windows.h>
#else
//#include <sys/types.h>
#include <dlfcn.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#endif


typedef struct mylinked_list {
	size_t length; // +0
	void * data; // +4
	struct mylinked_list *prev; // +8
	struct mylinked_list *next; // +12
} linked_list, *lplinked_list;


// Pass a single variables to these functions, NOT a complex expression
#define TO_LOW(A) (((unsigned int)(A))&0x0000FFFF)
#define TO_HIGH(A) (((unsigned int)(A))>>16)
#define TO_LOW_HIGH(A) TO_LOW(A),TO_HIGH(A)
//#define TO_LOW_HIGH(A) (((unsigned int)(A))&0x0000FFFF),(((unsigned int)(A))>>16)
#define TO_DWORD(low,high) ((unsigned int)(((high)<<16)|(low)))
#define TO_POINTER(low,high) ((void *)TO_DWORD(low,high))



#ifdef WIN32
#define libname "libeu.dll"
#define lib_type HINSTANCE
#define open_dll(name) LoadLibrary(TEXT(name))
#define close_dll(lib) FreeLibrary(lib)
#define define_c_func(lib,name) GetProcAddress(lib,name);
//#define reset_error_dll() // nothing
//#define error_dll() GetLastError()
#else
#define WINAPI
#define libname "libeu.so"
#define lib_type void *
#define open_dll(name) dlopen(name, RTLD_LAZY)
#define close_dll(lib) dlclose(lib)
#define dl_prefix "_1"
#define define_c_func(lib,name) dlsym(lib,dl_prefix name);
//#define reset_error_dll() dlerror()
#endif


typedef void (WINAPI *one_void_ret_void)(void);
typedef int (WINAPI *one_void_ret_int)(void);
typedef void (WINAPI *one_int_ret_void)(int);
typedef int (WINAPI *one_int_ret_int)(int);
typedef void (WINAPI *two_int_ret_void)(int,int);
typedef int (WINAPI *two_int_ret_int)(int,int);
typedef void (WINAPI *three_int_ret_void)(int,int,int);
typedef int (WINAPI *three_int_ret_int)(int,int,int);

typedef void (WINAPI *four_int_ret_void)(int,int,int,int);
typedef int (WINAPI *four_int_ret_int)(int,int,int,int);

typedef void (WINAPI *five_int_ret_void)(int,int,int,int,int);


lib_type lib_handle;

// Where retType is the pointer to a return type of the function
// This return type can be int, float, double, etc or a struct or class.

//typedef int* func_t;

one_void_ret_int access_free_list; // access_free_list
one_int_ret_int access_linked_list; // access_linked_list
two_int_ret_int at_linked_list; // at_linked_list
one_int_ret_void delete_linked_list; // delete_linked_list

one_int_ret_void set_return_linked_list;
one_void_ret_int get_return_linked_list;

one_int_ret_void eu_abort; // eu_abort
two_int_ret_int eu_add; // eu_add
two_int_ret_int eu_and; // eu_and
two_int_ret_int eu_and_bits; // eu_and_bits
two_int_ret_int eu_append; // eu_append
one_int_ret_int eu_arctan; // eu_arctan
one_int_ret_int eu_atom; // eu_atom
two_int_ret_int eu_c_func; // eu_c_func
two_int_ret_void eu_c_proc; // eu_c_proc
two_int_ret_void eu_call; // eu_call
two_int_ret_int eu_call_func; // eu_call_func
two_int_ret_void eu_call_proc; // eu_call_proc
one_void_ret_void eu_clear_screen; // eu_clear_screen
one_int_ret_void eu_close; // eu_close
one_void_ret_int eu_command_line; // eu_command_line
two_int_ret_int eu_compare; // eu_compare
two_int_ret_int eu_concat; // eu_concat
one_int_ret_int eu_cos; // eu_cos
one_void_ret_int eu_date; // eu_date
two_int_ret_int eu_divide; // eu_divide
two_int_ret_int eu_equal; // use to find out if two objects are equal // eu_equal
two_int_ret_int eu_equals; // boolean // eu_equals
three_int_ret_int eu_find; // same as find_from // eu_find
three_int_ret_int eu_find_from; // sequence indexes start at 1, array pointers start at 0 // eu_find_from
one_int_ret_int eu_floor; // eu_floor
one_void_ret_int eu_get_key; // eu_get_key
one_int_ret_int eu_getc; // eu_getc
one_int_ret_int eu_getenv; // eu_getenv
one_int_ret_int eu_gets; // eu_gets
two_int_ret_int eu_hash; // eu_hash
two_int_ret_int eu_head; // eu_head
one_int_ret_int eu_include_paths; // eu_include_paths
three_int_ret_int eu_insert; // eu_insert
one_int_ret_int eu_integer; // eu_integer
two_int_ret_int eu_integer_division; // eu_integer_division
one_int_ret_int eu_length; // eu_length
one_int_ret_int eu_log; // eu_log
two_int_ret_int eu_machine_func; // Euphoria specific: (look in files in Euphoria's include directory) // eu_machine_func
two_int_ret_void eu_machine_proc; // Euphoria specific: (look in files in Euphoria's include directory) // eu_machine_proc
three_int_ret_int eu_match; // same as match_from // eu_match
three_int_ret_int eu_match_from; // eu_match_from
five_int_ret_void eu_mem_copy; // eu_mem_copy
four_int_ret_void eu_mem_set; // eu_mem_set
two_int_ret_int eu_multiply; // eu_multiply
one_int_ret_int eu_negate; // eu_negate
one_int_ret_int eu_not; // eu_not
one_int_ret_int eu_not_bits; // eu_not_bits
one_int_ret_int eu_object; // eu_object
two_int_ret_int eu_open; // eu_open
three_int_ret_int eu_open_str; // eu_open_str
two_int_ret_int eu_or; // eu_or
two_int_ret_int eu_or_bits; // eu_or_bits
one_int_ret_int eu_peek; // eu_peek
one_int_ret_int eu_peek2s; // eu_peek2s
one_int_ret_int eu_peek2u; // eu_peek2u
one_int_ret_int eu_peek4s; // eu_peek4s
one_int_ret_int eu_peek4u; // eu_peek4u
one_int_ret_int eu_peek_string; // eu_peek_string
one_int_ret_int eu_peeks; // eu_peeks
one_void_ret_int eu_platform; // eu_platform
two_int_ret_void eu_poke; // eu_poke
two_int_ret_void eu_poke2; // eu_poke2
two_int_ret_void eu_poke4; // eu_poke4
two_int_ret_void eu_position; // eu_position
two_int_ret_int eu_power; // eu_power
two_int_ret_int eu_prepend; // eu_prepend
two_int_ret_void eu_print; // eu_print
three_int_ret_void eu_printf; // eu_printf
two_int_ret_void eu_puts; // eu_puts
one_int_ret_void eu_question_mark; // eu_question_mark
one_int_ret_int eu_rand; // eu_rand
two_int_ret_int eu_remainder; // eu_remainder
three_int_ret_int eu_remove; // eu_remove
two_int_ret_int eu_repeat; // eu_repeat
four_int_ret_int eu_replace; // eu_replace
one_int_ret_int eu_routine_id; // eu_routine_id
two_int_ret_int eu_routine_id_str; // eu_routine_id_str
one_int_ret_int eu_sequence; // eu_sequence
one_int_ret_int eu_sin; // eu_sin
three_int_ret_int eu_splice; // eu_splice
two_int_ret_int eu_sprintf; // eu_sprintf
one_int_ret_int eu_sqrt; // eu_sqrt
three_int_ret_int eu_subscript; // eu_subscript
two_int_ret_int eu_subtract; // eu_subtract
two_int_ret_void eu_system; // eu_system
two_int_ret_int eu_system_exec; // eu_system_exec
two_int_ret_int eu_tail; // eu_tail
one_int_ret_int eu_tan; // eu_tan
one_void_ret_int eu_time; // eu_time
two_int_ret_int eu_xor; // eu_xor
two_int_ret_int eu_xor_bits; // eu_xor_bits

two_int_ret_void free_linked_list_dll; // free_linked_list_dll
three_int_ret_void free_linked_lists; // free_linked_lists
two_int_ret_void generic_free; // generic_free
one_void_ret_int get_high_address; // get_high_address
one_void_ret_int get_version; // get_version
one_void_ret_void init; // init
one_int_ret_int is_free; // is_free
one_int_ret_int length_linked_list; // length_linked_list
one_void_ret_int length_of_data; // length_of_data
two_int_ret_int new_linked_list; // new_linked_list
two_int_ret_int register_linked_list; // register_linked_list
four_int_ret_void store_at_linked_list; // store_at_linked_list
three_int_ret_void store_linked_list; // store_linked_list


two_int_ret_int eu_call_func_std; // eu_call_func_std


// new functions:



//one_void_ret_int eu_platform;



// load the library   -----------------------------------------------

void init_lib(void) {

	lib_handle = open_dll(libname);
	if (!lib_handle) {
		printf("Cannot load library: %s\n", libname);
		//exit(1);
	}

	// load the symbols -------------------------------------------------

access_free_list = (one_void_ret_int)define_c_func(lib_handle, "access_free_list");
access_linked_list = (one_int_ret_int)define_c_func(lib_handle, "access_linked_list");
at_linked_list = (two_int_ret_int)define_c_func(lib_handle, "at_linked_list");
delete_linked_list = (one_int_ret_void)define_c_func(lib_handle, "delete_linked_list");

set_return_linked_list = (one_int_ret_void)define_c_func(lib_handle, "set_return_linked_list");
get_return_linked_list = (one_void_ret_int)define_c_func(lib_handle, "get_return_linked_list");

eu_abort = (one_int_ret_void)define_c_func(lib_handle, "eu_abort");
eu_add = (two_int_ret_int)define_c_func(lib_handle, "eu_add");
eu_and = (two_int_ret_int)define_c_func(lib_handle, "eu_and");
eu_and_bits = (two_int_ret_int)define_c_func(lib_handle, "eu_and_bits");
eu_append = (two_int_ret_int)define_c_func(lib_handle, "eu_append");
eu_arctan = (one_int_ret_int)define_c_func(lib_handle, "eu_arctan");
eu_atom = (one_int_ret_int)define_c_func(lib_handle, "eu_atom");
eu_c_func = (two_int_ret_int)define_c_func(lib_handle, "eu_c_func");
eu_c_proc = (two_int_ret_void)define_c_func(lib_handle, "eu_c_proc");
eu_call = (two_int_ret_void)define_c_func(lib_handle, "eu_call");
eu_call_func = (two_int_ret_int)define_c_func(lib_handle, "eu_call_func");
eu_call_proc = (two_int_ret_void)define_c_func(lib_handle, "eu_call_proc");
eu_clear_screen = (one_void_ret_void)define_c_func(lib_handle, "eu_clear_screen");
eu_close = (one_int_ret_void)define_c_func(lib_handle, "eu_close");
eu_command_line = (one_void_ret_int)define_c_func(lib_handle, "eu_command_line");
eu_compare = (two_int_ret_int)define_c_func(lib_handle, "eu_compare");
eu_concat = (two_int_ret_int)define_c_func(lib_handle, "eu_concat");
eu_cos = (one_int_ret_int)define_c_func(lib_handle, "eu_cos");
eu_date = (one_void_ret_int)define_c_func(lib_handle, "eu_date");
eu_divide = (two_int_ret_int)define_c_func(lib_handle, "eu_divide");
eu_equal  = (two_int_ret_int)define_c_func(lib_handle, "eu_equal");
eu_equals  = (two_int_ret_int)define_c_func(lib_handle, "eu_equals");
eu_find  = (three_int_ret_int)define_c_func(lib_handle, "eu_find");
eu_find_from  = (three_int_ret_int)define_c_func(lib_handle, "eu_find_from");
eu_floor = (one_int_ret_int)define_c_func(lib_handle, "eu_floor");
eu_get_key = (one_void_ret_int)define_c_func(lib_handle, "eu_get_key");
eu_getc = (one_int_ret_int)define_c_func(lib_handle, "eu_getc");
eu_getenv = (one_int_ret_int)define_c_func(lib_handle, "eu_getenv");
eu_gets = (one_int_ret_int)define_c_func(lib_handle, "eu_gets");
eu_hash = (two_int_ret_int)define_c_func(lib_handle, "eu_hash");
eu_head = (two_int_ret_int)define_c_func(lib_handle, "eu_head");
eu_include_paths = (one_int_ret_int)define_c_func(lib_handle, "eu_include_paths");
eu_insert = (three_int_ret_int)define_c_func(lib_handle, "eu_insert");
eu_integer = (one_int_ret_int)define_c_func(lib_handle, "eu_integer");
eu_integer_division = (two_int_ret_int)define_c_func(lib_handle, "eu_integer_division");
eu_length = (one_int_ret_int)define_c_func(lib_handle, "eu_length");
eu_log = (one_int_ret_int)define_c_func(lib_handle, "eu_log");
eu_machine_func = (two_int_ret_int)define_c_func(lib_handle, "eu_machine_func");
eu_machine_proc = (two_int_ret_void)define_c_func(lib_handle, "eu_machine_proc");
eu_match = (three_int_ret_int)define_c_func(lib_handle, "eu_match");
eu_match_from = (three_int_ret_int)define_c_func(lib_handle, "eu_match_from");
eu_mem_copy = (five_int_ret_void)define_c_func(lib_handle, "eu_mem_copy");
eu_mem_set = (four_int_ret_void)define_c_func(lib_handle, "eu_mem_set");
eu_multiply = (two_int_ret_int)define_c_func(lib_handle, "eu_multiply");
eu_negate = (one_int_ret_int)define_c_func(lib_handle, "eu_negate");
eu_not = (one_int_ret_int)define_c_func(lib_handle, "eu_not");
eu_not_bits = (one_int_ret_int)define_c_func(lib_handle, "eu_not_bits");
eu_object = (one_int_ret_int)define_c_func(lib_handle, "eu_object");
eu_open = (two_int_ret_int)define_c_func(lib_handle, "eu_open");
eu_open_str = (three_int_ret_int)define_c_func(lib_handle, "eu_open_str");
eu_or = (two_int_ret_int)define_c_func(lib_handle, "eu_or");
eu_or_bits = (two_int_ret_int)define_c_func(lib_handle, "eu_or_bits");
eu_peek = (one_int_ret_int)define_c_func(lib_handle, "eu_peek");
eu_peek2s = (one_int_ret_int)define_c_func(lib_handle, "eu_peek2s");
eu_peek2u = (one_int_ret_int)define_c_func(lib_handle, "eu_peek2u");
eu_peek4s = (one_int_ret_int)define_c_func(lib_handle, "eu_peek4s");
eu_peek4u = (one_int_ret_int)define_c_func(lib_handle, "eu_peek4u");
eu_peek_string = (one_int_ret_int)define_c_func(lib_handle, "eu_peek_string");
eu_peeks = (one_int_ret_int)define_c_func(lib_handle, "eu_peeks");
eu_platform = (one_void_ret_int)define_c_func(lib_handle, "eu_platform");
eu_poke = (two_int_ret_void)define_c_func(lib_handle, "eu_poke");
eu_poke2 = (two_int_ret_void)define_c_func(lib_handle, "eu_poke2");
eu_poke4 = (two_int_ret_void)define_c_func(lib_handle, "eu_poke4");
eu_position = (two_int_ret_void)define_c_func(lib_handle, "eu_position");
eu_power = (two_int_ret_int)define_c_func(lib_handle, "eu_power");
eu_prepend = (two_int_ret_int)define_c_func(lib_handle, "eu_prepend");
eu_print = (two_int_ret_void)define_c_func(lib_handle, "eu_print");
eu_printf = (three_int_ret_void)define_c_func(lib_handle, "eu_printf");
eu_puts = (two_int_ret_void)define_c_func(lib_handle, "eu_puts");
eu_question_mark = (one_int_ret_void)define_c_func(lib_handle, "eu_question_mark");
eu_rand = (one_int_ret_int)define_c_func(lib_handle, "eu_rand");
eu_remainder = (two_int_ret_int)define_c_func(lib_handle, "eu_remainder");
eu_remove = (three_int_ret_int)define_c_func(lib_handle, "eu_remove");
eu_repeat = (two_int_ret_int)define_c_func(lib_handle, "eu_repeat");
eu_replace = (four_int_ret_int)define_c_func(lib_handle, "eu_replace");
eu_routine_id = (one_int_ret_int)define_c_func(lib_handle, "eu_routine_id");
eu_routine_id_str = (two_int_ret_int)define_c_func(lib_handle, "eu_routine_id_str");
eu_sequence = (one_int_ret_int)define_c_func(lib_handle, "eu_sequence");
eu_sin = (one_int_ret_int)define_c_func(lib_handle, "eu_sin");
eu_splice = (three_int_ret_int)define_c_func(lib_handle, "eu_splice");
eu_sprintf = (two_int_ret_int)define_c_func(lib_handle, "eu_sprintf");
eu_sqrt = (one_int_ret_int)define_c_func(lib_handle, "eu_sqrt");
eu_subscript = (three_int_ret_int)define_c_func(lib_handle, "eu_subscript");
eu_subtract = (two_int_ret_int)define_c_func(lib_handle, "eu_subtract");
eu_system = (two_int_ret_void)define_c_func(lib_handle, "eu_system");
eu_system_exec = (two_int_ret_int)define_c_func(lib_handle, "eu_system_exec");
eu_tail = (two_int_ret_int)define_c_func(lib_handle, "eu_tail");
eu_tan = (one_int_ret_int)define_c_func(lib_handle, "eu_tan");
eu_time = (one_void_ret_int)define_c_func(lib_handle, "eu_time");
eu_xor = (two_int_ret_int)define_c_func(lib_handle, "eu_xor");
eu_xor_bits = (two_int_ret_int)define_c_func(lib_handle, "eu_xor_bits");

free_linked_list_dll = (two_int_ret_void)define_c_func(lib_handle, "free_linked_list_dll");
free_linked_lists = (three_int_ret_void)define_c_func(lib_handle, "free_linked_lists");
generic_free = (two_int_ret_void)define_c_func(lib_handle, "generic_free");
get_high_address = (one_void_ret_int)define_c_func(lib_handle, "get_high_address");
get_version = (one_void_ret_int)define_c_func(lib_handle, "get_version");
init = (one_void_ret_void)define_c_func(lib_handle, "init");
is_free = (one_int_ret_int)define_c_func(lib_handle, "is_free");
length_linked_list = (one_int_ret_int)define_c_func(lib_handle, "length_linked_list");
length_of_data = (one_void_ret_int)define_c_func(lib_handle, "length_of_data");
new_linked_list = (two_int_ret_int)define_c_func(lib_handle, "new_linked_list");
register_linked_list = (two_int_ret_int)define_c_func(lib_handle, "register_linked_list");
store_at_linked_list = (four_int_ret_void)define_c_func(lib_handle, "store_at_linked_list");
store_linked_list = (three_int_ret_void)define_c_func(lib_handle, "store_linked_list");



// Load your own symbols:

eu_call_func_std = (two_int_ret_int)define_c_func(lib_handle, "eu_call_func_std");


}

/*
#ifdef WIN32
func_t* fn_handle = (func_t*) GetProcAddress(lib_handle, "superfunctionx");
if (!fn_handle) {
cerr << "Cannot load symbol superfunctionx: " << GetLastError() << endl;
}
#else
// reset errors
dlerror();

// load the symbols (handle to function "superfunctionx")
func_t* fn_handle= (func_t*) dlsym(lib_handle, "superfunctionx");
const char* dlsym_error = dlerror();
if (dlsym_error) {
cerr << "Cannot load symbol superfunctionx: " << dlsym_error << endl;
}
#endif
*/


// unload the library -----------------------------------------------

void close_lib(void) {
	close_dll(lib_handle);
}



// end of file.


#endif // euwrap_h__
