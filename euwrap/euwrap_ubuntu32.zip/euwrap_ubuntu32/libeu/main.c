// Copyright (C) 2020 James J. Cook


// To be able to execute on Linux, do the following:
/*

LD_LIBRARY_PATH=$PWD
export LD_LIBRARY_PATH
gcc -o testdl testdl.c -ldl
./testdl

*/

#include <stdio.h>
#include <stdlib.h>

#include "eu.h"

int main() {
	char con_pause[] = "pause";
	char con_prompt_string[] = "prompt_string";
	char message[] = "Type a string and then press enter: ";
	int did;
	int prompt_string_rid;
	lplinked_list p[2];
	
	char myfunc_name[] = "eu_platform";
	int func_id;
	int empty_seq;
	linked_list a = {0,0,0,0};
	linked_list b = {0,0,0,0};
	int bb;
	
	puts("Loading...");
	
	init_lib();
	
	prompt_string_rid = eu_routine_id_str(TO_LOW_HIGH(con_prompt_string));
	printf("prompt_string_rid is %d\n", prompt_string_rid);
	
	puts("Done loading.\n");
	
	b.length = 0xFFFFFFFF;
	b.data = (void *)message;
	
	//eu_clear_screen();
	a.length = 1;
	p[0] = &b;
	p[1] = &b;
	a.data = (void *)p;
	did = register_linked_list(TO_LOW_HIGH(&a));
	puts(message);
	eu_question_mark(did);
	
	did = eu_call_func_std(prompt_string_rid, did);
	eu_puts(1, did);
	eu_question_mark(did);
	
	b.length = 0xFFFFFFFF;
	b.data = (void *)con_pause;
	did = register_linked_list(TO_LOW_HIGH(&b));
	eu_system(did,2);
	
	close_lib();
	printf("Done: Program Terminated.\n");
	return 0;
}
