// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _2allocate(int _n_234)
{
    int _52 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_234)) {
        _1 = (long)(DBL_PTR(_n_234)->dbl);
        DeRefDS(_n_234);
        _n_234 = _1;
    }

    /**     return machine_func(M_ALLOC, n)*/
    _52 = machine(16, _n_234);
    return _52;
    ;
}


void _2free(int _a_238)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_238);

    /** end procedure*/
    DeRef(_a_238);
    return;
    ;
}


int _2allocate_low(int _n_241)
{
    int _allocate_inlined_allocate_at_4_243 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_241)) {
        _1 = (long)(DBL_PTR(_n_241)->dbl);
        DeRefDS(_n_241);
        _n_241 = _1;
    }

    /**     return allocate( n )*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef(_allocate_inlined_allocate_at_4_243);
    _allocate_inlined_allocate_at_4_243 = machine(16, _n_241);
    return _allocate_inlined_allocate_at_4_243;
    ;
}


void _2free_low(int _a_246)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_246)) {
        _1 = (long)(DBL_PTR(_a_246)->dbl);
        DeRefDS(_a_246);
        _a_246 = _1;
    }

    /**     free( a )*/

    /**     machine_proc(M_FREE, a)*/
    machine(17, _a_246);

    /** end procedure*/
    goto L1; // [12] 15
L1: 

    /** end procedure*/
    return;
    ;
}


int _2int_to_bytes(int _x_250)
{
    int _a_251 = NOVALUE;
    int _b_252 = NOVALUE;
    int _c_253 = NOVALUE;
    int _d_254 = NOVALUE;
    int _61 = NOVALUE;
    int _0, _1, _2;
    

    /**     a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_250)) {
        _a_251 = (_x_250 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_251 = Dremainder(DBL_PTR(_x_250), &temp_d);
    }
    if (!IS_ATOM_INT(_a_251)) {
        _1 = (long)(DBL_PTR(_a_251)->dbl);
        DeRefDS(_a_251);
        _a_251 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_250;
    if (IS_ATOM_INT(_x_250)) {
        if (256 > 0 && _x_250 >= 0) {
            _x_250 = _x_250 / 256;
        }
        else {
            temp_dbl = floor((double)_x_250 / (double)256);
            if (_x_250 != MININT)
            _x_250 = (long)temp_dbl;
            else
            _x_250 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_250, 256);
        _x_250 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_250)) {
        _b_252 = (_x_250 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_252 = Dremainder(DBL_PTR(_x_250), &temp_d);
    }
    if (!IS_ATOM_INT(_b_252)) {
        _1 = (long)(DBL_PTR(_b_252)->dbl);
        DeRefDS(_b_252);
        _b_252 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_250;
    if (IS_ATOM_INT(_x_250)) {
        if (256 > 0 && _x_250 >= 0) {
            _x_250 = _x_250 / 256;
        }
        else {
            temp_dbl = floor((double)_x_250 / (double)256);
            if (_x_250 != MININT)
            _x_250 = (long)temp_dbl;
            else
            _x_250 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_250, 256);
        _x_250 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_250)) {
        _c_253 = (_x_250 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_253 = Dremainder(DBL_PTR(_x_250), &temp_d);
    }
    if (!IS_ATOM_INT(_c_253)) {
        _1 = (long)(DBL_PTR(_c_253)->dbl);
        DeRefDS(_c_253);
        _c_253 = _1;
    }

    /**     x = floor(x / #100)*/
    _0 = _x_250;
    if (IS_ATOM_INT(_x_250)) {
        if (256 > 0 && _x_250 >= 0) {
            _x_250 = _x_250 / 256;
        }
        else {
            temp_dbl = floor((double)_x_250 / (double)256);
            if (_x_250 != MININT)
            _x_250 = (long)temp_dbl;
            else
            _x_250 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_250, 256);
        _x_250 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /**     d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_250)) {
        _d_254 = (_x_250 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_254 = Dremainder(DBL_PTR(_x_250), &temp_d);
    }
    if (!IS_ATOM_INT(_d_254)) {
        _1 = (long)(DBL_PTR(_d_254)->dbl);
        DeRefDS(_d_254);
        _d_254 = _1;
    }

    /**     return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_251;
    *((int *)(_2+8)) = _b_252;
    *((int *)(_2+12)) = _c_253;
    *((int *)(_2+16)) = _d_254;
    _61 = MAKE_SEQ(_1);
    DeRef(_x_250);
    return _61;
    ;
}


int _2bytes_to_int(int _s_269)
{
    int _65 = NOVALUE;
    int _64 = NOVALUE;
    int _62 = NOVALUE;
    int _0, _1, _2;
    

    /**     if length(s) = 4 then*/
    if (IS_SEQUENCE(_s_269)){
            _62 = SEQ_PTR(_s_269)->length;
    }
    else {
        _62 = 1;
    }
    if (_62 != 4)
    goto L1; // [8] 22

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_2mem_264)){
        poke_addr = (unsigned char *)_2mem_264;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_2mem_264)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_269);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    goto L2; // [19] 35
L1: 

    /** 	poke(mem, s[1..4]) -- avoid breaking old code*/
    rhs_slice_target = (object_ptr)&_64;
    RHS_Slice(_s_269, 1, 4);
    if (IS_ATOM_INT(_2mem_264)){
        poke_addr = (unsigned char *)_2mem_264;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_2mem_264)->dbl);
    }
    _1 = (int)SEQ_PTR(_64);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }
    DeRefDS(_64);
    _64 = NOVALUE;
L2: 

    /**     return peek4u(mem)*/
    if (IS_ATOM_INT(_2mem_264)) {
        _65 = *(unsigned long *)_2mem_264;
        if ((unsigned)_65 > (unsigned)MAXINT)
        _65 = NewDouble((double)(unsigned long)_65);
    }
    else {
        _65 = *(unsigned long *)(unsigned long)(DBL_PTR(_2mem_264)->dbl);
        if ((unsigned)_65 > (unsigned)MAXINT)
        _65 = NewDouble((double)(unsigned long)_65);
    }
    DeRefDS(_s_269);
    return _65;
    ;
}


int _2int_to_bits(int _x_278, int _nbits_279)
{
    int _bits_280 = NOVALUE;
    int _mask_281 = NOVALUE;
    int _79 = NOVALUE;
    int _78 = NOVALUE;
    int _76 = NOVALUE;
    int _73 = NOVALUE;
    int _72 = NOVALUE;
    int _71 = NOVALUE;
    int _70 = NOVALUE;
    int _68 = NOVALUE;
    int _67 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nbits_279)) {
        _1 = (long)(DBL_PTR(_nbits_279)->dbl);
        DeRefDS(_nbits_279);
        _nbits_279 = _1;
    }

    /**     bits = repeat(0, nbits)*/
    DeRef(_bits_280);
    _bits_280 = Repeat(0, _nbits_279);

    /**     if integer(x) and nbits < 30 then*/
    if (IS_ATOM_INT(_x_278))
    _67 = 1;
    else if (IS_ATOM_DBL(_x_278))
    _67 = IS_ATOM_INT(DoubleToInt(_x_278));
    else
    _67 = 0;
    if (_67 == 0) {
        goto L1; // [14] 73
    }
    _70 = (_nbits_279 < 30);
    if (_70 == 0)
    {
        DeRef(_70);
        _70 = NOVALUE;
        goto L1; // [23] 73
    }
    else{
        DeRef(_70);
        _70 = NOVALUE;
    }

    /** 	mask = 1*/
    _mask_281 = 1;

    /** 	for i = 1 to nbits do*/
    _71 = _nbits_279;
    {
        int _i_289;
        _i_289 = 1;
L2: 
        if (_i_289 > _71){
            goto L3; // [36] 70
        }

        /** 	    bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_278)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_278 & (unsigned long)_mask_281;
                 _72 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_281;
            _72 = Dand_bits(DBL_PTR(_x_278), &temp_d);
        }
        if (IS_ATOM_INT(_72)) {
            _73 = (_72 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _73 = Dand(DBL_PTR(_72), &temp_d);
        }
        DeRef(_72);
        _72 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_280);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_280 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_289);
        _1 = *(int *)_2;
        *(int *)_2 = _73;
        if( _1 != _73 ){
            DeRef(_1);
        }
        _73 = NOVALUE;

        /** 	    mask *= 2*/
        _mask_281 = _mask_281 + _mask_281;

        /** 	end for*/
        _i_289 = _i_289 + 1;
        goto L2; // [65] 43
L3: 
        ;
    }
    goto L4; // [70] 126
L1: 

    /** 	if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_278, 0)){
        goto L5; // [75] 90
    }

    /** 	    x += power(2, nbits) -- for 2's complement bit pattern*/
    _76 = power(2, _nbits_279);
    _0 = _x_278;
    if (IS_ATOM_INT(_x_278) && IS_ATOM_INT(_76)) {
        _x_278 = _x_278 + _76;
        if ((long)((unsigned long)_x_278 + (unsigned long)HIGH_BITS) >= 0) 
        _x_278 = NewDouble((double)_x_278);
    }
    else {
        if (IS_ATOM_INT(_x_278)) {
            _x_278 = NewDouble((double)_x_278 + DBL_PTR(_76)->dbl);
        }
        else {
            if (IS_ATOM_INT(_76)) {
                _x_278 = NewDouble(DBL_PTR(_x_278)->dbl + (double)_76);
            }
            else
            _x_278 = NewDouble(DBL_PTR(_x_278)->dbl + DBL_PTR(_76)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_76);
    _76 = NOVALUE;
L5: 

    /** 	for i = 1 to nbits do*/
    _78 = _nbits_279;
    {
        int _i_300;
        _i_300 = 1;
L6: 
        if (_i_300 > _78){
            goto L7; // [95] 125
        }

        /** 	    bits[i] = remainder(x, 2) */
        if (IS_ATOM_INT(_x_278)) {
            _79 = (_x_278 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _79 = Dremainder(DBL_PTR(_x_278), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_280);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_280 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_300);
        _1 = *(int *)_2;
        *(int *)_2 = _79;
        if( _1 != _79 ){
            DeRef(_1);
        }
        _79 = NOVALUE;

        /** 	    x = floor(x / 2)*/
        _0 = _x_278;
        if (IS_ATOM_INT(_x_278)) {
            _x_278 = _x_278 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_278, 2);
            _x_278 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 	end for*/
        _i_300 = _i_300 + 1;
        goto L6; // [120] 102
L7: 
        ;
    }
L4: 

    /**     return bits*/
    DeRef(_x_278);
    return _bits_280;
    ;
}


int _2bits_to_int(int _bits_306)
{
    int _value_307 = NOVALUE;
    int _p_308 = NOVALUE;
    int _82 = NOVALUE;
    int _81 = NOVALUE;
    int _0, _1, _2;
    

    /**     value = 0*/
    DeRef(_value_307);
    _value_307 = 0;

    /**     p = 1*/
    DeRef(_p_308);
    _p_308 = 1;

    /**     for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_306)){
            _81 = SEQ_PTR(_bits_306)->length;
    }
    else {
        _81 = 1;
    }
    {
        int _i_310;
        _i_310 = 1;
L1: 
        if (_i_310 > _81){
            goto L2; // [18] 54
        }

        /** 	if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_306);
        _82 = (int)*(((s1_ptr)_2)->base + _i_310);
        if (_82 == 0) {
            _82 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_82) && DBL_PTR(_82)->dbl == 0.0){
                _82 = NOVALUE;
                goto L3; // [31] 41
            }
            _82 = NOVALUE;
        }
        _82 = NOVALUE;

        /** 	    value += p*/
        _0 = _value_307;
        if (IS_ATOM_INT(_value_307) && IS_ATOM_INT(_p_308)) {
            _value_307 = _value_307 + _p_308;
            if ((long)((unsigned long)_value_307 + (unsigned long)HIGH_BITS) >= 0) 
            _value_307 = NewDouble((double)_value_307);
        }
        else {
            if (IS_ATOM_INT(_value_307)) {
                _value_307 = NewDouble((double)_value_307 + DBL_PTR(_p_308)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_308)) {
                    _value_307 = NewDouble(DBL_PTR(_value_307)->dbl + (double)_p_308);
                }
                else
                _value_307 = NewDouble(DBL_PTR(_value_307)->dbl + DBL_PTR(_p_308)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 	p += p*/
        _0 = _p_308;
        if (IS_ATOM_INT(_p_308) && IS_ATOM_INT(_p_308)) {
            _p_308 = _p_308 + _p_308;
            if ((long)((unsigned long)_p_308 + (unsigned long)HIGH_BITS) >= 0) 
            _p_308 = NewDouble((double)_p_308);
        }
        else {
            if (IS_ATOM_INT(_p_308)) {
                _p_308 = NewDouble((double)_p_308 + DBL_PTR(_p_308)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_308)) {
                    _p_308 = NewDouble(DBL_PTR(_p_308)->dbl + (double)_p_308);
                }
                else
                _p_308 = NewDouble(DBL_PTR(_p_308)->dbl + DBL_PTR(_p_308)->dbl);
            }
        }
        DeRef(_0);

        /**     end for*/
        _i_310 = _i_310 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /**     return value*/
    DeRefDS(_bits_306);
    DeRef(_p_308);
    return _value_307;
    ;
}


void _2set_rand(int _seed_318)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_seed_318)) {
        _1 = (long)(DBL_PTR(_seed_318)->dbl);
        DeRefDS(_seed_318);
        _seed_318 = _1;
    }

    /**     machine_proc(M_SET_RAND, seed)*/
    machine(35, _seed_318);

    /** end procedure*/
    return;
    ;
}


void _2crash_message(int _msg_321)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_MESSAGE, msg)*/
    machine(37, _msg_321);

    /** end procedure*/
    DeRefDS(_msg_321);
    return;
    ;
}


void _2crash_file(int _file_path_324)
{
    int _0, _1, _2;
    

    /**     machine_proc(M_CRASH_FILE, file_path)*/
    machine(57, _file_path_324);

    /** end procedure*/
    DeRefDS(_file_path_324);
    return;
    ;
}


void _2crash_routine(int _proc_327)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_327)) {
        _1 = (long)(DBL_PTR(_proc_327)->dbl);
        DeRefDS(_proc_327);
        _proc_327 = _1;
    }

    /**     machine_proc(M_CRASH_ROUTINE, proc)*/
    machine(66, _proc_327);

    /** end procedure*/
    return;
    ;
}


int _2atom_to_float64(int _a_330)
{
    int _85 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F64, a)*/
    _85 = machine(46, _a_330);
    DeRef(_a_330);
    return _85;
    ;
}


int _2atom_to_float32(int _a_334)
{
    int _86 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_A_TO_F32, a)*/
    _86 = machine(48, _a_334);
    DeRef(_a_334);
    return _86;
    ;
}


int _2float64_to_atom(int _ieee64_338)
{
    int _87 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F64_TO_A, ieee64)*/
    _87 = machine(47, _ieee64_338);
    DeRefDS(_ieee64_338);
    return _87;
    ;
}


int _2float32_to_atom(int _ieee32_342)
{
    int _88 = NOVALUE;
    int _0, _1, _2;
    

    /**     return machine_func(M_F32_TO_A, ieee32)*/
    _88 = machine(49, _ieee32_342);
    DeRefDS(_ieee32_342);
    return _88;
    ;
}


int _2allocate_string(int _s_346)
{
    int _mem_347 = NOVALUE;
    int _93 = NOVALUE;
    int _92 = NOVALUE;
    int _90 = NOVALUE;
    int _89 = NOVALUE;
    int _0, _1, _2;
    

    /**     mem = machine_func(M_ALLOC, length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_346)){
            _89 = SEQ_PTR(_s_346)->length;
    }
    else {
        _89 = 1;
    }
    _90 = _89 + 1;
    _89 = NOVALUE;
    DeRef(_mem_347);
    _mem_347 = machine(16, _90);
    _90 = NOVALUE;

    /**     if mem then*/
    if (_mem_347 == 0) {
        goto L1; // [18] 39
    }
    else {
        if (!IS_ATOM_INT(_mem_347) && DBL_PTR(_mem_347)->dbl == 0.0){
            goto L1; // [18] 39
        }
    }

    /** 	poke(mem, s)*/
    if (IS_ATOM_INT(_mem_347)){
        poke_addr = (unsigned char *)_mem_347;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_347)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_346);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 	poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_346)){
            _92 = SEQ_PTR(_s_346)->length;
    }
    else {
        _92 = 1;
    }
    if (IS_ATOM_INT(_mem_347)) {
        _93 = _mem_347 + _92;
        if ((long)((unsigned long)_93 + (unsigned long)HIGH_BITS) >= 0) 
        _93 = NewDouble((double)_93);
    }
    else {
        _93 = NewDouble(DBL_PTR(_mem_347)->dbl + (double)_92);
    }
    _92 = NOVALUE;
    if (IS_ATOM_INT(_93)){
        poke_addr = (unsigned char *)_93;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_93)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_93);
    _93 = NOVALUE;
L1: 

    /**     return mem*/
    DeRefDS(_s_346);
    return _mem_347;
    ;
}


void _2register_block(int _block_addr_357, int _block_len_358)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _2unregister_block(int _block_addr_361)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _2check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}



// 0x5375D7FA
