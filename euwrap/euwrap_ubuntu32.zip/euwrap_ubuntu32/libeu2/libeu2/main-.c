// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include <time.h>
#include "include/euphoria.h"
#include "main-.h"

#include <unistd.h>


int Argc;
char **Argv;
unsigned long *peek4_addr;
unsigned char *poke_addr;
unsigned short *poke2_addr;
unsigned long *poke4_addr;
struct d temp_d;
double temp_dbl;
char *stack_base;
int total_stack_size = 262144;

void __attribute__ ((constructor)) eu_init()
{
    s1_ptr _0switch_ptr;
    int _30 = 0;
    int _27 = 0;
    int _0, _1, _2;
    
    
    Argc = 0;

    _02 = (unsigned char**) malloc( 4 * 4 );
    _02[0] = (unsigned char*) malloc( 4 );
    _02[0][0] = 3;
    _02[1] = "\x01\x02\x03\x03";
    _02[2] = "\x02\x00\x02\x00";
    _02[3] = "\x03\x00\x03\x02";

#ifdef CLK_TCK
    eu_startup(_00, _01, _02, (int)CLOCKS_PER_SEC, (int)CLK_TCK);
#else
    eu_startup(_00, _01, _02, (int)CLOCKS_PER_SEC, (int)sysconf(_SC_CLK_TCK));
#endif
    _0switch_ptr = (s1_ptr) NewS1( 4 );
    _0switch_ptr->base[1] = NewString("-keep    ");
    _0switch_ptr->base[2] = NewString("-dll    ");
    _0switch_ptr->base[3] = NewString("-i    ");
    _0switch_ptr->base[4] = NewString("/usr/share/euphoria/include    ");
    _0switches = MAKE_SEQ( _0switch_ptr );

    init_literal();
    _27 = power(2, 32);
    if (IS_ATOM_INT(_27)) {
        _2MAX_ADDR_178 = _27 - 1;
        if ((long)((unsigned long)_2MAX_ADDR_178 +(unsigned long) HIGH_BITS) >= 0){
            _2MAX_ADDR_178 = NewDouble((double)_2MAX_ADDR_178);
        }
    }
    else {
        _2MAX_ADDR_178 = NewDouble(DBL_PTR(_27)->dbl - (double)1);
    }
    DeRef1(_27);
    _27 = NOVALUE;
    _30 = 1048576;
    _2LOW_ADDR_182 = 1048575;
    _30 = NOVALUE;

    /** mem = allocate(4)*/

    /**     return machine_func(M_ALLOC, n)*/
    DeRef1(_2mem_264);
    _2mem_264 = machine(16, 4);

    /** check_calls = 1*/
    _2check_calls_354 = 1;

    /** always_linked_list = 0*/
    _3always_linked_list_366 = 0;

    /** init()*/

    /** 	high_address = 0*/
    _1high_address_750 = 0;

    /** 	data = {} -- objects*/
    RefDS(_5);
    DeRef1(_1data_751);
    _1data_751 = _5;

    /** 	free_list = {} -- list of free "data" objects*/
    RefDS(_5);
    DeRef1(_1free_list_752);
    _1free_list_752 = _5;

    /** end procedure*/
    goto L1; // [79] 82
L1: 
    ;
}
// GenerateUserRoutines

// 0xED8286C6
