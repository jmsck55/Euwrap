// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _42exe_path()
{
    int _25662 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(exe_path_cache) then*/
    _25662 = IS_SEQUENCE(_42exe_path_cache_49202);
    if (_25662 == 0)
    {
        _25662 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25662 = NOVALUE;
    }

    /** 		return exe_path_cache*/
    Ref(_42exe_path_cache_49202);
    return _42exe_path_cache_49202;
L1: 

    /** 	exe_path_cache = command_line()*/
    DeRef(_42exe_path_cache_49202);
    _42exe_path_cache_49202 = Command_Line();

    /** 	exe_path_cache = exe_path_cache[1]*/
    _0 = _42exe_path_cache_49202;
    _2 = (int)SEQ_PTR(_42exe_path_cache_49202);
    _42exe_path_cache_49202 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_42exe_path_cache_49202);
    DeRefDS(_0);

    /** 	return exe_path_cache*/
    RefDS(_42exe_path_cache_49202);
    return _42exe_path_cache_49202;
    ;
}


int _42check_cache(int _env_49214, int _inc_path_49215)
{
    int _delim_49216 = NOVALUE;
    int _pos_49217 = NOVALUE;
    int _25710 = NOVALUE;
    int _25709 = NOVALUE;
    int _25708 = NOVALUE;
    int _25707 = NOVALUE;
    int _25705 = NOVALUE;
    int _25704 = NOVALUE;
    int _25703 = NOVALUE;
    int _25702 = NOVALUE;
    int _25701 = NOVALUE;
    int _25700 = NOVALUE;
    int _25699 = NOVALUE;
    int _25698 = NOVALUE;
    int _25697 = NOVALUE;
    int _25693 = NOVALUE;
    int _25692 = NOVALUE;
    int _25691 = NOVALUE;
    int _25690 = NOVALUE;
    int _25689 = NOVALUE;
    int _25688 = NOVALUE;
    int _25687 = NOVALUE;
    int _25686 = NOVALUE;
    int _25684 = NOVALUE;
    int _25683 = NOVALUE;
    int _25682 = NOVALUE;
    int _25681 = NOVALUE;
    int _25680 = NOVALUE;
    int _25679 = NOVALUE;
    int _25677 = NOVALUE;
    int _25676 = NOVALUE;
    int _25675 = NOVALUE;
    int _25674 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not num_var then -- first time the var is accessed, add cache entry*/
    if (_42num_var_49191 != 0)
    goto L1; // [9] 86

    /** 		cache_vars = append(cache_vars,env)*/
    RefDS(_env_49214);
    Append(&_42cache_vars_49192, _42cache_vars_49192, _env_49214);

    /** 		cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_49215);
    Append(&_42cache_strings_49193, _42cache_strings_49193, _inc_path_49215);

    /** 		cache_substrings = append(cache_substrings,{})*/
    RefDS(_21815);
    Append(&_42cache_substrings_49194, _42cache_substrings_49194, _21815);

    /** 		cache_starts = append(cache_starts,{})*/
    RefDS(_21815);
    Append(&_42cache_starts_49195, _42cache_starts_49195, _21815);

    /** 		cache_ends = append(cache_ends,{})*/
    RefDS(_21815);
    Append(&_42cache_ends_49196, _42cache_ends_49196, _21815);

    /** 		ifdef WINDOWS then*/

    /** 		num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_42cache_vars_49192)){
            _42num_var_49191 = SEQ_PTR(_42cache_vars_49192)->length;
    }
    else {
        _42num_var_49191 = 1;
    }

    /** 		cache_complete &= 0*/
    Append(&_42cache_complete_49198, _42cache_complete_49198, 0);

    /** 		cache_delims &= 0*/
    Append(&_42cache_delims_49199, _42cache_delims_49199, 0);

    /** 		return 0*/
    DeRefDS(_env_49214);
    DeRefDSi(_inc_path_49215);
    return 0;
    goto L2; // [83] 425
L1: 

    /** 		if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (int)SEQ_PTR(_42cache_strings_49193);
    _25674 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    if (IS_ATOM_INT(_inc_path_49215) && IS_ATOM_INT(_25674)){
        _25675 = (_inc_path_49215 < _25674) ? -1 : (_inc_path_49215 > _25674);
    }
    else{
        _25675 = compare(_inc_path_49215, _25674);
    }
    _25674 = NOVALUE;
    if (_25675 == 0)
    {
        _25675 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25675 = NOVALUE;
    }

    /** 			cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_49215);
    _2 = (int)SEQ_PTR(_42cache_strings_49193);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_strings_49193 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
    _1 = *(int *)_2;
    *(int *)_2 = _inc_path_49215;
    DeRefDS(_1);

    /** 			cache_complete[num_var] = 0*/
    _2 = (int)SEQ_PTR(_42cache_complete_49198);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49198 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
    *(int *)_2 = 0;

    /** 			if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (int)SEQ_PTR(_42cache_strings_49193);
    _25676 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    _25677 = e_match_from(_25676, _inc_path_49215, 1);
    _25676 = NOVALUE;
    if (_25677 == 1)
    goto L4; // [138] 423

    /** 				pos = -1*/
    _pos_49217 = -1;

    /** 				for i=1 to length(cache_strings[num_var]) do*/
    _2 = (int)SEQ_PTR(_42cache_strings_49193);
    _25679 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    if (IS_SEQUENCE(_25679)){
            _25680 = SEQ_PTR(_25679)->length;
    }
    else {
        _25680 = 1;
    }
    _25679 = NOVALUE;
    {
        int _i_49237;
        _i_49237 = 1;
L5: 
        if (_i_49237 > _25680){
            goto L6; // [160] 422
        }

        /** 					if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25681 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        _2 = (int)SEQ_PTR(_25681);
        _25682 = (int)*(((s1_ptr)_2)->base + _i_49237);
        _25681 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_49215)){
                _25683 = SEQ_PTR(_inc_path_49215)->length;
        }
        else {
            _25683 = 1;
        }
        if (IS_ATOM_INT(_25682)) {
            _25684 = (_25682 > _25683);
        }
        else {
            _25684 = binary_op(GREATER, _25682, _25683);
        }
        _25682 = NOVALUE;
        _25683 = NOVALUE;
        if (IS_ATOM_INT(_25684)) {
            if (_25684 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25684)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        _25686 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        _2 = (int)SEQ_PTR(_25686);
        _25687 = (int)*(((s1_ptr)_2)->base + _i_49237);
        _25686 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        _25688 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        _2 = (int)SEQ_PTR(_25688);
        _25689 = (int)*(((s1_ptr)_2)->base + _i_49237);
        _25688 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25690 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        _2 = (int)SEQ_PTR(_25690);
        _25691 = (int)*(((s1_ptr)_2)->base + _i_49237);
        _25690 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25692;
        RHS_Slice(_inc_path_49215, _25689, _25691);
        if (IS_ATOM_INT(_25687) && IS_ATOM_INT(_25692)){
            _25693 = (_25687 < _25692) ? -1 : (_25687 > _25692);
        }
        else{
            _25693 = compare(_25687, _25692);
        }
        _25687 = NOVALUE;
        DeRefDS(_25692);
        _25692 = NOVALUE;
        if (_25693 == 0)
        {
            _25693 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25693 = NOVALUE;
        }
L7: 

        /** 						pos = i-1*/
        _pos_49217 = _i_49237 - 1;

        /** 						exit*/
        goto L6; // [250] 422
L8: 

        /** 					if pos = 0 then*/
        if (_pos_49217 != 0)
        goto L9; // [255] 268

        /** 						return 0*/
        DeRefDS(_env_49214);
        DeRefDSi(_inc_path_49215);
        _25679 = NOVALUE;
        DeRef(_25684);
        _25684 = NOVALUE;
        _25689 = NOVALUE;
        _25691 = NOVALUE;
        return 0;
        goto LA; // [265] 415
L9: 

        /** 					elsif pos >0 then -- crop cache data*/
        if (_pos_49217 <= 0)
        goto LB; // [270] 414

        /** 						cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        _25697 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        rhs_slice_target = (object_ptr)&_25698;
        RHS_Slice(_25697, 1, _pos_49217);
        _25697 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49194 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25698;
        if( _1 != _25698 ){
            DeRefDS(_1);
        }
        _25698 = NOVALUE;

        /** 						cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        _25699 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        rhs_slice_target = (object_ptr)&_25700;
        RHS_Slice(_25699, 1, _pos_49217);
        _25699 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25700;
        if( _1 != _25700 ){
            DeRef(_1);
        }
        _25700 = NOVALUE;

        /** 						cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25701 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        rhs_slice_target = (object_ptr)&_25702;
        RHS_Slice(_25701, 1, _pos_49217);
        _25701 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49196 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25702;
        if( _1 != _25702 ){
            DeRef(_1);
        }
        _25702 = NOVALUE;

        /** 						ifdef WINDOWS then*/

        /** 						delim = cache_ends[num_var][$]+1*/
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25703 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        if (IS_SEQUENCE(_25703)){
                _25704 = SEQ_PTR(_25703)->length;
        }
        else {
            _25704 = 1;
        }
        _2 = (int)SEQ_PTR(_25703);
        _25705 = (int)*(((s1_ptr)_2)->base + _25704);
        _25703 = NOVALUE;
        if (IS_ATOM_INT(_25705)) {
            _delim_49216 = _25705 + 1;
        }
        else
        { // coercing _delim_49216 to an integer 1
            _delim_49216 = 1+(long)(DBL_PTR(_25705)->dbl);
            if( !IS_ATOM_INT(_delim_49216) ){
                _delim_49216 = (object)DBL_PTR(_delim_49216)->dbl;
            }
        }
        _25705 = NOVALUE;

        /** 						while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_49215)){
                _25707 = SEQ_PTR(_inc_path_49215)->length;
        }
        else {
            _25707 = 1;
        }
        _25708 = (_delim_49216 <= _25707);
        _25707 = NOVALUE;
        if (_25708 == 0) {
            goto LD; // [378] 403
        }
        _25710 = (_delim_49216 != 58);
        if (_25710 == 0)
        {
            DeRef(_25710);
            _25710 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25710);
            _25710 = NOVALUE;
        }

        /** 							delim+=1*/
        _delim_49216 = _delim_49216 + 1;

        /** 						end while*/
        goto LC; // [400] 371
LD: 

        /** 						cache_delims[num_var] = delim*/
        _2 = (int)SEQ_PTR(_42cache_delims_49199);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49199 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        *(int *)_2 = _delim_49216;
LB: 
LA: 

        /** 				end for*/
        _i_49237 = _i_49237 + 1;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** 	return 1*/
    DeRefDS(_env_49214);
    DeRefDSi(_inc_path_49215);
    _25679 = NOVALUE;
    DeRef(_25708);
    _25708 = NOVALUE;
    DeRef(_25684);
    _25684 = NOVALUE;
    _25689 = NOVALUE;
    _25691 = NOVALUE;
    return 1;
    ;
}


int _42get_conf_dirs()
{
    int _delimiter_49278 = NOVALUE;
    int _dirs_49279 = NOVALUE;
    int _25715 = NOVALUE;
    int _25713 = NOVALUE;
    int _25712 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		delimiter = ':'*/
    _delimiter_49278 = 58;

    /** 	dirs = ""*/
    RefDS(_21815);
    DeRef(_dirs_49279);
    _dirs_49279 = _21815;

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_42config_inc_paths_49200)){
            _25712 = SEQ_PTR(_42config_inc_paths_49200)->length;
    }
    else {
        _25712 = 1;
    }
    {
        int _i_49281;
        _i_49281 = 1;
L1: 
        if (_i_49281 > _25712){
            goto L2; // [22] 68
        }

        /** 		dirs &= config_inc_paths[i]*/
        _2 = (int)SEQ_PTR(_42config_inc_paths_49200);
        _25713 = (int)*(((s1_ptr)_2)->base + _i_49281);
        Concat((object_ptr)&_dirs_49279, _dirs_49279, _25713);
        _25713 = NOVALUE;

        /** 		if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_42config_inc_paths_49200)){
                _25715 = SEQ_PTR(_42config_inc_paths_49200)->length;
        }
        else {
            _25715 = 1;
        }
        if (_i_49281 == _25715)
        goto L3; // [48] 61

        /** 			dirs &= delimiter*/
        Append(&_dirs_49279, _dirs_49279, _delimiter_49278);
L3: 

        /** 	end for*/
        _i_49281 = _i_49281 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** 	return dirs*/
    return _dirs_49279;
    ;
}


int _42strip_file_from_path(int _full_path_49291)
{
    int _25721 = NOVALUE;
    int _25719 = NOVALUE;
    int _25718 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_49291)){
            _25718 = SEQ_PTR(_full_path_49291)->length;
    }
    else {
        _25718 = 1;
    }
    {
        int _i_49293;
        _i_49293 = _25718;
L1: 
        if (_i_49293 < 1){
            goto L2; // [8] 46
        }

        /** 		if full_path[i] = SLASH then*/
        _2 = (int)SEQ_PTR(_full_path_49291);
        _25719 = (int)*(((s1_ptr)_2)->base + _i_49293);
        if (binary_op_a(NOTEQ, _25719, 47)){
            _25719 = NOVALUE;
            goto L3; // [23] 39
        }
        _25719 = NOVALUE;

        /** 			return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25721;
        RHS_Slice(_full_path_49291, 1, _i_49293);
        DeRefDS(_full_path_49291);
        return _25721;
L3: 

        /** 	end for*/
        _i_49293 = _i_49293 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** 	return ""*/
    RefDS(_21815);
    DeRefDS(_full_path_49291);
    DeRef(_25721);
    _25721 = NOVALUE;
    return _21815;
    ;
}


int _42expand_path(int _path_49302, int _prefix_49303)
{
    int _absolute_49304 = NOVALUE;
    int _home_49308 = NOVALUE;
    int _25745 = NOVALUE;
    int _25744 = NOVALUE;
    int _25743 = NOVALUE;
    int _25742 = NOVALUE;
    int _25741 = NOVALUE;
    int _25740 = NOVALUE;
    int _25736 = NOVALUE;
    int _25734 = NOVALUE;
    int _25733 = NOVALUE;
    int _25732 = NOVALUE;
    int _25731 = NOVALUE;
    int _25730 = NOVALUE;
    int _25727 = NOVALUE;
    int _25726 = NOVALUE;
    int _25725 = NOVALUE;
    int _25724 = NOVALUE;
    int _25722 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(path) then*/
    if (IS_SEQUENCE(_path_49302)){
            _25722 = SEQ_PTR(_path_49302)->length;
    }
    else {
        _25722 = 1;
    }
    if (_25722 != 0)
    goto L1; // [10] 22
    _25722 = NOVALUE;

    /** 		return pwd*/
    RefDS(_42pwd_49203);
    DeRefDS(_path_49302);
    DeRefDS(_prefix_49303);
    DeRefi(_home_49308);
    return _42pwd_49203;
L1: 

    /** 	ifdef UNIX then*/

    /** 		object home*/

    /** 		if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_49302)){
            _25724 = SEQ_PTR(_path_49302)->length;
    }
    else {
        _25724 = 1;
    }
    if (_25724 == 0) {
        goto L2; // [31] 84
    }
    _2 = (int)SEQ_PTR(_path_49302);
    _25726 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25726)) {
        _25727 = (_25726 == 126);
    }
    else {
        _25727 = binary_op(EQUALS, _25726, 126);
    }
    _25726 = NOVALUE;
    if (_25727 == 0) {
        DeRef(_25727);
        _25727 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25727) && DBL_PTR(_25727)->dbl == 0.0){
            DeRef(_25727);
            _25727 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25727);
        _25727 = NOVALUE;
    }
    DeRef(_25727);
    _25727 = NOVALUE;

    /** 			home = getenv("HOME")*/
    DeRefi(_home_49308);
    _home_49308 = EGetEnv(_25728);

    /** 			if sequence(home) and length(home) then*/
    _25730 = IS_SEQUENCE(_home_49308);
    if (_25730 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_49308)){
            _25732 = SEQ_PTR(_home_49308)->length;
    }
    else {
        _25732 = 1;
    }
    if (_25732 == 0)
    {
        _25732 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25732 = NOVALUE;
    }

    /** 				path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_49302)){
            _25733 = SEQ_PTR(_path_49302)->length;
    }
    else {
        _25733 = 1;
    }
    rhs_slice_target = (object_ptr)&_25734;
    RHS_Slice(_path_49302, 2, _25733);
    if (IS_SEQUENCE(_home_49308) && IS_ATOM(_25734)) {
    }
    else if (IS_ATOM(_home_49308) && IS_SEQUENCE(_25734)) {
        Ref(_home_49308);
        Prepend(&_path_49302, _25734, _home_49308);
    }
    else {
        Concat((object_ptr)&_path_49302, _home_49308, _25734);
    }
    DeRefDS(_25734);
    _25734 = NOVALUE;
L3: 
L2: 

    /** 		absolute = find(path[1], SLASH_CHARS)*/
    _2 = (int)SEQ_PTR(_path_49302);
    _25736 = (int)*(((s1_ptr)_2)->base + 1);
    _absolute_49304 = find_from(_25736, _40SLASH_CHARS_16126, 1);
    _25736 = NOVALUE;

    /** 	if not absolute then*/
    if (_absolute_49304 != 0)
    goto L4; // [101] 115

    /** 		path = prefix & SLASH & path*/
    {
        int concat_list[3];

        concat_list[0] = _path_49302;
        concat_list[1] = 47;
        concat_list[2] = _prefix_49303;
        Concat_N((object_ptr)&_path_49302, concat_list, 3);
    }
L4: 

    /** 	if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_49302)){
            _25740 = SEQ_PTR(_path_49302)->length;
    }
    else {
        _25740 = 1;
    }
    if (_25740 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_49302)){
            _25742 = SEQ_PTR(_path_49302)->length;
    }
    else {
        _25742 = 1;
    }
    _2 = (int)SEQ_PTR(_path_49302);
    _25743 = (int)*(((s1_ptr)_2)->base + _25742);
    _25744 = find_from(_25743, _40SLASH_CHARS_16126, 1);
    _25743 = NOVALUE;
    _25745 = (_25744 == 0);
    _25744 = NOVALUE;
    if (_25745 == 0)
    {
        DeRef(_25745);
        _25745 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25745);
        _25745 = NOVALUE;
    }

    /** 		path &= SLASH*/
    Append(&_path_49302, _path_49302, 47);
L5: 

    /** 	return path*/
    DeRefDS(_prefix_49303);
    DeRefi(_home_49308);
    return _path_49302;
    ;
}


void _42add_include_directory(int _path_49342)
{
    int _25748 = NOVALUE;
    int _0, _1, _2;
    

    /** 	path = expand_path( path, pwd )*/
    RefDS(_path_49342);
    RefDS(_42pwd_49203);
    _0 = _path_49342;
    _path_49342 = _42expand_path(_path_49342, _42pwd_49203);
    DeRefDS(_0);

    /** 	if not find( path, config_inc_paths ) then*/
    _25748 = find_from(_path_49342, _42config_inc_paths_49200, 1);
    if (_25748 != 0)
    goto L1; // [23] 35
    _25748 = NOVALUE;

    /** 		config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_49342);
    Append(&_42config_inc_paths_49200, _42config_inc_paths_49200, _path_49342);
L1: 

    /** end procedure*/
    DeRefDS(_path_49342);
    return;
    ;
}


int _42load_euphoria_config(int _file_49351)
{
    int _fn_49352 = NOVALUE;
    int _in_49353 = NOVALUE;
    int _spos_49354 = NOVALUE;
    int _epos_49355 = NOVALUE;
    int _conf_path_49356 = NOVALUE;
    int _new_args_49357 = NOVALUE;
    int _arg_49358 = NOVALUE;
    int _parm_49359 = NOVALUE;
    int _section_49360 = NOVALUE;
    int _needed_49457 = NOVALUE;
    int _25845 = NOVALUE;
    int _25844 = NOVALUE;
    int _25841 = NOVALUE;
    int _25839 = NOVALUE;
    int _25838 = NOVALUE;
    int _25816 = NOVALUE;
    int _25813 = NOVALUE;
    int _25812 = NOVALUE;
    int _25810 = NOVALUE;
    int _25806 = NOVALUE;
    int _25804 = NOVALUE;
    int _25802 = NOVALUE;
    int _25800 = NOVALUE;
    int _25798 = NOVALUE;
    int _25796 = NOVALUE;
    int _25795 = NOVALUE;
    int _25794 = NOVALUE;
    int _25793 = NOVALUE;
    int _25792 = NOVALUE;
    int _25791 = NOVALUE;
    int _25790 = NOVALUE;
    int _25789 = NOVALUE;
    int _25787 = NOVALUE;
    int _25785 = NOVALUE;
    int _25783 = NOVALUE;
    int _25779 = NOVALUE;
    int _25778 = NOVALUE;
    int _25773 = NOVALUE;
    int _25771 = NOVALUE;
    int _25769 = NOVALUE;
    int _25768 = NOVALUE;
    int _25760 = NOVALUE;
    int _25754 = NOVALUE;
    int _25753 = NOVALUE;
    int _25751 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_args = {}*/
    RefDS(_21815);
    DeRef(_new_args_49357);
    _new_args_49357 = _21815;

    /** 	if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_49351);
    _25751 = _17file_type(_file_49351);
    if (binary_op_a(NOTEQ, _25751, 2)){
        DeRef(_25751);
        _25751 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25751);
    _25751 = NOVALUE;

    /** 		if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_49351)){
            _25753 = SEQ_PTR(_file_49351)->length;
    }
    else {
        _25753 = 1;
    }
    _2 = (int)SEQ_PTR(_file_49351);
    _25754 = (int)*(((s1_ptr)_2)->base + _25753);
    if (binary_op_a(EQUALS, _25754, 47)){
        _25754 = NOVALUE;
        goto L2; // [33] 46
    }
    _25754 = NOVALUE;

    /** 			file &= SLASH*/
    Append(&_file_49351, _file_49351, 47);
L2: 

    /** 		file &= "eu.cfg"*/
    Concat((object_ptr)&_file_49351, _file_49351, _25757);
L1: 

    /** 	conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_49351);
    _0 = _conf_path_49356;
    _conf_path_49356 = _17canonical_path(_file_49351, 0, 2);
    DeRef(_0);

    /** 	if find(conf_path, seen_conf) != 0 then*/
    _25760 = find_from(_conf_path_49356, _42seen_conf_49348, 1);
    if (_25760 == 0)
    goto L3; // [74] 85

    /** 		return {}*/
    RefDS(_21815);
    DeRefDS(_file_49351);
    DeRefi(_in_49353);
    DeRefDS(_conf_path_49356);
    DeRef(_new_args_49357);
    DeRefi(_arg_49358);
    DeRefi(_parm_49359);
    DeRef(_section_49360);
    return _21815;
L3: 

    /** 	seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_49356);
    Append(&_42seen_conf_49348, _42seen_conf_49348, _conf_path_49356);

    /** 	section = "all"*/
    RefDS(_25763);
    DeRef(_section_49360);
    _section_49360 = _25763;

    /** 	fn = open( conf_path, "r" )*/
    _fn_49352 = EOpen(_conf_path_49356, _25764, 0);

    /** 	if fn = -1 then return {} end if*/
    if (_fn_49352 != -1)
    goto L4; // [109] 118
    RefDS(_21815);
    DeRefDS(_file_49351);
    DeRefi(_in_49353);
    DeRefDS(_conf_path_49356);
    DeRef(_new_args_49357);
    DeRefi(_arg_49358);
    DeRefi(_parm_49359);
    DeRefDSi(_section_49360);
    return _21815;
L4: 

    /** 	in = gets( fn )*/
    DeRefi(_in_49353);
    _in_49353 = EGets(_fn_49352);

    /** 	while sequence( in ) do*/
L5: 
    _25768 = IS_SEQUENCE(_in_49353);
    if (_25768 == 0)
    {
        _25768 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25768 = NOVALUE;
    }

    /** 		spos = 1*/
    _spos_49354 = 1;

    /** 		while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_49353)){
            _25769 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _25769 = 1;
    }
    if (_spos_49354 > _25769)
    goto L8; // [147] 182

    /** 			if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49353);
    _25771 = (int)*(((s1_ptr)_2)->base + _spos_49354);
    _25773 = find_from(_25771, _25772, 1);
    _25771 = NOVALUE;
    if (_25773 != 0)
    goto L9; // [162] 171

    /** 				exit*/
    goto L8; // [168] 182
L9: 

    /** 			spos += 1*/
    _spos_49354 = _spos_49354 + 1;

    /** 		end while*/
    goto L7; // [179] 144
L8: 

    /** 		epos = length(in)*/
    if (IS_SEQUENCE(_in_49353)){
            _epos_49355 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _epos_49355 = 1;
    }

    /** 		while epos >= spos do*/
LA: 
    if (_epos_49355 < _spos_49354)
    goto LB; // [192] 227

    /** 			if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49353);
    _25778 = (int)*(((s1_ptr)_2)->base + _epos_49355);
    _25779 = find_from(_25778, _25772, 1);
    _25778 = NOVALUE;
    if (_25779 != 0)
    goto LC; // [207] 216

    /** 				exit*/
    goto LB; // [213] 227
LC: 

    /** 			epos -= 1*/
    _epos_49355 = _epos_49355 - 1;

    /** 		end while*/
    goto LA; // [224] 192
LB: 

    /** 		in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_49353;
    RHS_Slice(_in_49353, _spos_49354, _epos_49355);

    /** 		arg = ""*/
    RefDS(_21815);
    DeRefi(_arg_49358);
    _arg_49358 = _21815;

    /** 		parm = ""*/
    RefDS(_21815);
    DeRefi(_parm_49359);
    _parm_49359 = _21815;

    /** 		if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_49353)){
            _25783 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _25783 = 1;
    }
    if (_25783 <= 0)
    goto LD; // [253] 477

    /** 			if in[1] = '[' then*/
    _2 = (int)SEQ_PTR(_in_49353);
    _25785 = (int)*(((s1_ptr)_2)->base + 1);
    if (_25785 != 91)
    goto LE; // [263] 354

    /** 				section = in[2..$]*/
    if (IS_SEQUENCE(_in_49353)){
            _25787 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _25787 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_49360;
    RHS_Slice(_in_49353, 2, _25787);

    /** 				if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_49360)){
            _25789 = SEQ_PTR(_section_49360)->length;
    }
    else {
        _25789 = 1;
    }
    _25790 = (_25789 > 0);
    _25789 = NOVALUE;
    if (_25790 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_49360)){
            _25792 = SEQ_PTR(_section_49360)->length;
    }
    else {
        _25792 = 1;
    }
    _2 = (int)SEQ_PTR(_section_49360);
    _25793 = (int)*(((s1_ptr)_2)->base + _25792);
    _25794 = (_25793 == 93);
    _25793 = NOVALUE;
    if (_25794 == 0)
    {
        DeRef(_25794);
        _25794 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_25794);
        _25794 = NOVALUE;
    }

    /** 					section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_49360)){
            _25795 = SEQ_PTR(_section_49360)->length;
    }
    else {
        _25795 = 1;
    }
    _25796 = _25795 - 1;
    _25795 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_49360;
    RHS_Slice(_section_49360, 1, _25796);
LF: 

    /** 				section = lower(trim(section))*/
    RefDS(_section_49360);
    RefDS(_3815);
    _25798 = _14trim(_section_49360, _3815, 0);
    _0 = _section_49360;
    _section_49360 = _14lower(_25798);
    DeRefDS(_0);
    _25798 = NOVALUE;

    /** 				if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_49360)){
            _25800 = SEQ_PTR(_section_49360)->length;
    }
    else {
        _25800 = 1;
    }
    if (_25800 != 0)
    goto L10; // [339] 476

    /** 					section = "all"*/
    RefDS(_25763);
    DeRefDS(_section_49360);
    _section_49360 = _25763;
    goto L10; // [351] 476
LE: 

    /** 			elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_49353)){
            _25802 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _25802 = 1;
    }
    if (_25802 <= 2)
    goto L11; // [359] 461

    /** 				if in[1] = '-' then*/
    _2 = (int)SEQ_PTR(_in_49353);
    _25804 = (int)*(((s1_ptr)_2)->base + 1);
    if (_25804 != 45)
    goto L12; // [369] 443

    /** 					if in[2] != '-' then*/
    _2 = (int)SEQ_PTR(_in_49353);
    _25806 = (int)*(((s1_ptr)_2)->base + 2);
    if (_25806 == 45)
    goto L10; // [379] 476

    /** 						spos = find(' ', in)*/
    _spos_49354 = find_from(32, _in_49353, 1);

    /** 						if spos = 0 then*/
    if (_spos_49354 != 0)
    goto L13; // [392] 413

    /** 							arg = in*/
    Ref(_in_49353);
    DeRefi(_arg_49358);
    _arg_49358 = _in_49353;

    /** 							parm = ""*/
    RefDS(_21815);
    DeRefi(_parm_49359);
    _parm_49359 = _21815;
    goto L10; // [410] 476
L13: 

    /** 							arg = in[1..spos - 1]*/
    _25810 = _spos_49354 - 1;
    rhs_slice_target = (object_ptr)&_arg_49358;
    RHS_Slice(_in_49353, 1, _25810);

    /** 							parm = in[spos + 1 .. $]*/
    _25812 = _spos_49354 + 1;
    if (_25812 > MAXINT){
        _25812 = NewDouble((double)_25812);
    }
    if (IS_SEQUENCE(_in_49353)){
            _25813 = SEQ_PTR(_in_49353)->length;
    }
    else {
        _25813 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_49359;
    RHS_Slice(_in_49353, _25812, _25813);
    goto L10; // [440] 476
L12: 

    /** 					arg = "-i"*/
    RefDS(_25815);
    DeRefi(_arg_49358);
    _arg_49358 = _25815;

    /** 					parm = in*/
    Ref(_in_49353);
    DeRefi(_parm_49359);
    _parm_49359 = _in_49353;
    goto L10; // [458] 476
L11: 

    /** 				arg = "-i"*/
    RefDS(_25815);
    DeRefi(_arg_49358);
    _arg_49358 = _25815;

    /** 				parm = in*/
    Ref(_in_49353);
    DeRefi(_parm_49359);
    _parm_49359 = _in_49353;
L10: 
LD: 

    /** 		if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_49358)){
            _25816 = SEQ_PTR(_arg_49358)->length;
    }
    else {
        _25816 = 1;
    }
    if (_25816 <= 0)
    goto L14; // [482] 756

    /** 			integer needed = 0*/
    _needed_49457 = 0;

    /** 			switch section do*/
    _1 = find(_section_49360, _25818);
    switch ( _1 ){ 

        /** 				case "all" then*/
        case 1:

        /** 					needed = 1*/
        _needed_49457 = 1;
        goto L15; // [507] 691

        /** 				case "windows" then*/
        case 2:

        /** 					needed = TWINDOWS*/
        _needed_49457 = _40TWINDOWS_16112;
        goto L15; // [522] 691

        /** 				case "unix" then*/
        case 3:

        /** 					needed = TUNIX*/
        _needed_49457 = _40TUNIX_16116;
        goto L15; // [537] 691

        /** 				case "translate" then*/
        case 4:

        /** 					needed = TRANSLATE*/
        _needed_49457 = _35TRANSLATE_15611;
        goto L15; // [552] 691

        /** 				case "translate:windows" then*/
        case 5:

        /** 					needed = TRANSLATE and TWINDOWS*/
        _needed_49457 = (_35TRANSLATE_15611 != 0 && _40TWINDOWS_16112 != 0);
        goto L15; // [570] 691

        /** 				case "translate:unix" then*/
        case 6:

        /** 					needed = TRANSLATE and TUNIX*/
        _needed_49457 = (_35TRANSLATE_15611 != 0 && _40TUNIX_16116 != 0);
        goto L15; // [588] 691

        /** 				case "interpret" then*/
        case 7:

        /** 					needed = INTERPRET*/
        _needed_49457 = _35INTERPRET_15608;
        goto L15; // [603] 691

        /** 				case "interpret:windows" then*/
        case 8:

        /** 					needed = INTERPRET and TWINDOWS*/
        _needed_49457 = (_35INTERPRET_15608 != 0 && _40TWINDOWS_16112 != 0);
        goto L15; // [621] 691

        /** 				case "interpret:unix" then*/
        case 9:

        /** 					needed = INTERPRET and TUNIX*/
        _needed_49457 = (_35INTERPRET_15608 != 0 && _40TUNIX_16116 != 0);
        goto L15; // [639] 691

        /** 				case "bind" then*/
        case 10:

        /** 					needed = BIND*/
        _needed_49457 = _35BIND_15614;
        goto L15; // [654] 691

        /** 				case "bind:windows" then*/
        case 11:

        /** 					needed = BIND and TWINDOWS*/
        _needed_49457 = (_35BIND_15614 != 0 && _40TWINDOWS_16112 != 0);
        goto L15; // [672] 691

        /** 				case "bind:unix" then*/
        case 12:

        /** 					needed = BIND and TUNIX*/
        _needed_49457 = (_35BIND_15614 != 0 && _40TUNIX_16116 != 0);
    ;}L15: 

    /** 			if needed then*/
    if (_needed_49457 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** 				if equal(arg, "-c") then*/
    if (_arg_49358 == _25837)
    _25838 = 1;
    else if (IS_ATOM_INT(_arg_49358) && IS_ATOM_INT(_25837))
    _25838 = 0;
    else
    _25838 = (compare(_arg_49358, _25837) == 0);
    if (_25838 == 0)
    {
        _25838 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _25838 = NOVALUE;
    }

    /** 					if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_49359)){
            _25839 = SEQ_PTR(_parm_49359)->length;
    }
    else {
        _25839 = 1;
    }
    if (_25839 <= 0)
    goto L18; // [710] 754

    /** 						new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_49359);
    _25841 = _42load_euphoria_config(_parm_49359);
    if (IS_SEQUENCE(_new_args_49357) && IS_ATOM(_25841)) {
        Ref(_25841);
        Append(&_new_args_49357, _new_args_49357, _25841);
    }
    else if (IS_ATOM(_new_args_49357) && IS_SEQUENCE(_25841)) {
    }
    else {
        Concat((object_ptr)&_new_args_49357, _new_args_49357, _25841);
    }
    DeRef(_25841);
    _25841 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** 					new_args = append(new_args, arg)*/
    RefDS(_arg_49358);
    Append(&_new_args_49357, _new_args_49357, _arg_49358);

    /** 					if length(parm > 0) then*/
    _25844 = binary_op(GREATER, _parm_49359, 0);
    if (IS_SEQUENCE(_25844)){
            _25845 = SEQ_PTR(_25844)->length;
    }
    else {
        _25845 = 1;
    }
    DeRefDS(_25844);
    _25844 = NOVALUE;
    if (_25845 == 0)
    {
        _25845 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _25845 = NOVALUE;
    }

    /** 						new_args = append(new_args, parm)*/
    RefDS(_parm_49359);
    Append(&_new_args_49357, _new_args_49357, _parm_49359);
L19: 
L18: 
L16: 
L14: 

    /** 		in = gets( fn )*/
    DeRefi(_in_49353);
    _in_49353 = EGets(_fn_49352);

    /** 	end while*/
    goto L5; // [765] 128
L6: 

    /** 	close(fn)*/
    EClose(_fn_49352);

    /** 	return new_args*/
    DeRefDS(_file_49351);
    DeRefi(_in_49353);
    DeRef(_conf_path_49356);
    DeRefi(_arg_49358);
    DeRefi(_parm_49359);
    DeRef(_section_49360);
    _25785 = NOVALUE;
    DeRef(_25790);
    _25790 = NOVALUE;
    DeRef(_25796);
    _25796 = NOVALUE;
    _25804 = NOVALUE;
    _25806 = NOVALUE;
    DeRef(_25810);
    _25810 = NOVALUE;
    DeRef(_25812);
    _25812 = NOVALUE;
    _25844 = NOVALUE;
    return _new_args_49357;
    ;
}


int _42GetDefaultArgs(int _user_files_49524)
{
    int _env_49525 = NOVALUE;
    int _default_args_49526 = NOVALUE;
    int _conf_file_49527 = NOVALUE;
    int _cmd_options_49529 = NOVALUE;
    int _user_config_49535 = NOVALUE;
    int _25880 = NOVALUE;
    int _25879 = NOVALUE;
    int _25878 = NOVALUE;
    int _25870 = NOVALUE;
    int _25869 = NOVALUE;
    int _25867 = NOVALUE;
    int _25864 = NOVALUE;
    int _25863 = NOVALUE;
    int _25860 = NOVALUE;
    int _25859 = NOVALUE;
    int _25857 = NOVALUE;
    int _25855 = NOVALUE;
    int _25854 = NOVALUE;
    int _25850 = NOVALUE;
    int _25849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence default_args = {}*/
    RefDS(_21815);
    DeRef(_default_args_49526);
    _default_args_49526 = _21815;

    /** 	sequence conf_file = "eu.cfg"*/
    RefDS(_25757);
    DeRefi(_conf_file_49527);
    _conf_file_49527 = _25757;

    /** 	if loaded_config_inc_paths then return "" end if*/
    if (_42loaded_config_inc_paths_49201 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_21815);
    DeRefDS(_user_files_49524);
    DeRef(_env_49525);
    DeRefDS(_default_args_49526);
    DeRefDSi(_conf_file_49527);
    DeRef(_cmd_options_49529);
    return _21815;
L1: 

    /** 	loaded_config_inc_paths = 1*/
    _42loaded_config_inc_paths_49201 = 1;

    /** 	sequence cmd_options = get_options()*/
    _0 = _cmd_options_49529;
    _cmd_options_49529 = _43get_options();
    DeRef(_0);

    /** 	default_args = {}*/
    RefDS(_21815);
    DeRef(_default_args_49526);
    _default_args_49526 = _21815;

    /** 	for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_49524)){
            _25849 = SEQ_PTR(_user_files_49524)->length;
    }
    else {
        _25849 = 1;
    }
    {
        int _i_49533;
        _i_49533 = 1;
L2: 
        if (_i_49533 > _25849){
            goto L3; // [53] 92
        }

        /** 		sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (int)SEQ_PTR(_user_files_49524);
        _25850 = (int)*(((s1_ptr)_2)->base + _i_49533);
        Ref(_25850);
        _0 = _user_config_49535;
        _user_config_49535 = _42load_euphoria_config(_25850);
        DeRef(_0);
        _25850 = NOVALUE;

        /** 		default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_49535);
        RefDS(_default_args_49526);
        RefDS(_cmd_options_49529);
        _0 = _default_args_49526;
        _default_args_49526 = _43merge_parameters(_user_config_49535, _default_args_49526, _cmd_options_49529, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_49535);
        _user_config_49535 = NOVALUE;

        /** 	end for*/
        _i_49533 = _i_49533 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** 	default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_25854, _25853, _conf_file_49527);
    _25855 = _42load_euphoria_config(_25854);
    _25854 = NOVALUE;
    RefDS(_default_args_49526);
    RefDS(_cmd_options_49529);
    _0 = _default_args_49526;
    _default_args_49526 = _43merge_parameters(_25855, _default_args_49526, _cmd_options_49529, 1);
    DeRefDS(_0);
    _25855 = NOVALUE;

    /** 	env = strip_file_from_path( exe_path() )*/
    _25857 = _42exe_path();
    _0 = _env_49525;
    _env_49525 = _42strip_file_from_path(_25857);
    DeRef(_0);
    _25857 = NOVALUE;

    /** 	default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_49525) && IS_ATOM(_conf_file_49527)) {
    }
    else if (IS_ATOM(_env_49525) && IS_SEQUENCE(_conf_file_49527)) {
        Ref(_env_49525);
        Prepend(&_25859, _conf_file_49527, _env_49525);
    }
    else {
        Concat((object_ptr)&_25859, _env_49525, _conf_file_49527);
    }
    _25860 = _42load_euphoria_config(_25859);
    _25859 = NOVALUE;
    RefDS(_default_args_49526);
    RefDS(_cmd_options_49529);
    _0 = _default_args_49526;
    _default_args_49526 = _43merge_parameters(_25860, _default_args_49526, _cmd_options_49529, 1);
    DeRefDS(_0);
    _25860 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_25863, _25862, _conf_file_49527);
    _25864 = _42load_euphoria_config(_25863);
    _25863 = NOVALUE;
    RefDS(_default_args_49526);
    RefDS(_cmd_options_49529);
    _0 = _default_args_49526;
    _default_args_49526 = _43merge_parameters(_25864, _default_args_49526, _cmd_options_49529, 1);
    DeRefDS(_0);
    _25864 = NOVALUE;

    /** 		env = getenv( "HOME" )*/
    DeRef(_env_49525);
    _env_49525 = EGetEnv(_25728);

    /** 		if sequence(env) then*/
    _25867 = IS_SEQUENCE(_env_49525);
    if (_25867 == 0)
    {
        _25867 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _25867 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49527;
        concat_list[1] = _25868;
        concat_list[2] = _env_49525;
        Concat_N((object_ptr)&_25869, concat_list, 3);
    }
    _25870 = _42load_euphoria_config(_25869);
    _25869 = NOVALUE;
    RefDS(_default_args_49526);
    RefDS(_cmd_options_49529);
    _0 = _default_args_49526;
    _default_args_49526 = _43merge_parameters(_25870, _default_args_49526, _cmd_options_49529, 1);
    DeRefDS(_0);
    _25870 = NOVALUE;
L4: 

    /** 	env = get_eudir()*/
    _0 = _env_49525;
    _env_49525 = _36get_eudir();
    DeRef(_0);

    /** 	if sequence(env) then*/
    _25878 = IS_SEQUENCE(_env_49525);
    if (_25878 == 0)
    {
        _25878 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _25878 = NOVALUE;
    }

    /** 		default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49527;
        concat_list[1] = _23263;
        concat_list[2] = _env_49525;
        Concat_N((object_ptr)&_25879, concat_list, 3);
    }
    _25880 = _42load_euphoria_config(_25879);
    _25879 = NOVALUE;
    RefDS(_default_args_49526);
    RefDS(_cmd_options_49529);
    _0 = _default_args_49526;
    _default_args_49526 = _43merge_parameters(_25880, _default_args_49526, _cmd_options_49529, 1);
    DeRefDS(_0);
    _25880 = NOVALUE;
L5: 

    /** 	return default_args*/
    DeRefDS(_user_files_49524);
    DeRef(_env_49525);
    DeRefi(_conf_file_49527);
    DeRef(_cmd_options_49529);
    return _default_args_49526;
    ;
}


int _42ConfPath(int _file_name_49579)
{
    int _file_path_49580 = NOVALUE;
    int _try_49581 = NOVALUE;
    int _25887 = NOVALUE;
    int _25883 = NOVALUE;
    int _25882 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_42config_inc_paths_49200)){
            _25882 = SEQ_PTR(_42config_inc_paths_49200)->length;
    }
    else {
        _25882 = 1;
    }
    {
        int _i_49583;
        _i_49583 = 1;
L1: 
        if (_i_49583 > _25882){
            goto L2; // [10] 60
        }

        /** 		file_path = config_inc_paths[i] & file_name*/
        _2 = (int)SEQ_PTR(_42config_inc_paths_49200);
        _25883 = (int)*(((s1_ptr)_2)->base + _i_49583);
        Concat((object_ptr)&_file_path_49580, _25883, _file_name_49579);
        _25883 = NOVALUE;
        _25883 = NOVALUE;

        /** 		try = open( file_path, "r" )*/
        _try_49581 = EOpen(_file_path_49580, _25764, 0);

        /** 		if try != -1 then*/
        if (_try_49581 == -1)
        goto L3; // [38] 53

        /** 			return {file_path, try}*/
        RefDS(_file_path_49580);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49580;
        ((int *)_2)[2] = _try_49581;
        _25887 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49579);
        DeRefDS(_file_path_49580);
        return _25887;
L3: 

        /** 	end for*/
        _i_49583 = _i_49583 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** 	return -1*/
    DeRefDS(_file_name_49579);
    DeRef(_file_path_49580);
    DeRef(_25887);
    _25887 = NOVALUE;
    return -1;
    ;
}


int _42ScanPath(int _file_name_49593, int _env_49594, int _flag_49595)
{
    int _inc_path_49596 = NOVALUE;
    int _full_path_49597 = NOVALUE;
    int _file_path_49598 = NOVALUE;
    int _strings_49599 = NOVALUE;
    int _end_path_49600 = NOVALUE;
    int _start_path_49601 = NOVALUE;
    int _try_49602 = NOVALUE;
    int _use_cache_49603 = NOVALUE;
    int _pos_49604 = NOVALUE;
    int _25935 = NOVALUE;
    int _25934 = NOVALUE;
    int _25933 = NOVALUE;
    int _25932 = NOVALUE;
    int _25931 = NOVALUE;
    int _25930 = NOVALUE;
    int _25929 = NOVALUE;
    int _25928 = NOVALUE;
    int _25924 = NOVALUE;
    int _25923 = NOVALUE;
    int _25922 = NOVALUE;
    int _25921 = NOVALUE;
    int _25920 = NOVALUE;
    int _25919 = NOVALUE;
    int _25917 = NOVALUE;
    int _25915 = NOVALUE;
    int _25914 = NOVALUE;
    int _25912 = NOVALUE;
    int _25911 = NOVALUE;
    int _25910 = NOVALUE;
    int _25907 = NOVALUE;
    int _25906 = NOVALUE;
    int _25904 = NOVALUE;
    int _25903 = NOVALUE;
    int _25902 = NOVALUE;
    int _25897 = NOVALUE;
    int _25889 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_flag_49595)) {
        _1 = (long)(DBL_PTR(_flag_49595)->dbl);
        DeRefDS(_flag_49595);
        _flag_49595 = _1;
    }

    /** 	inc_path = getenv(env)*/
    DeRefi(_inc_path_49596);
    _inc_path_49596 = EGetEnv(_env_49594);

    /** 	if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_49596) && IS_ATOM_INT(_21815)){
        _25889 = (_inc_path_49596 < _21815) ? -1 : (_inc_path_49596 > _21815);
    }
    else{
        _25889 = compare(_inc_path_49596, _21815);
    }
    if (_25889 == 1)
    goto L1; // [18] 29

    /** 		return -1*/
    DeRefDS(_file_name_49593);
    DeRefDS(_env_49594);
    DeRefi(_inc_path_49596);
    DeRef(_full_path_49597);
    DeRef(_file_path_49598);
    DeRef(_strings_49599);
    return -1;
L1: 

    /** 	num_var = find(env,cache_vars)*/
    _42num_var_49191 = find_from(_env_49594, _42cache_vars_49192, 1);

    /** 	use_cache = check_cache(env,inc_path)*/
    RefDS(_env_49594);
    Ref(_inc_path_49596);
    _use_cache_49603 = _42check_cache(_env_49594, _inc_path_49596);
    if (!IS_ATOM_INT(_use_cache_49603)) {
        _1 = (long)(DBL_PTR(_use_cache_49603)->dbl);
        DeRefDS(_use_cache_49603);
        _use_cache_49603 = _1;
    }

    /** 	inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_49596, _inc_path_49596, 58);

    /** 	file_name = SLASH & file_name*/
    Prepend(&_file_name_49593, _file_name_49593, 47);

    /** 	if flag then*/
    if (_flag_49595 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** 		file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_49593, _42include_subfolder_49187, _file_name_49593);
L2: 

    /** 	strings = cache_substrings[num_var]*/
    DeRef(_strings_49599);
    _2 = (int)SEQ_PTR(_42cache_substrings_49194);
    _strings_49599 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    RefDS(_strings_49599);

    /** 	if use_cache then*/
    if (_use_cache_49603 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** 		for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_49599)){
            _25897 = SEQ_PTR(_strings_49599)->length;
    }
    else {
        _25897 = 1;
    }
    {
        int _i_49620;
        _i_49620 = 1;
L4: 
        if (_i_49620 > _25897){
            goto L5; // [99] 154
        }

        /** 			full_path = strings[i]*/
        DeRef(_full_path_49597);
        _2 = (int)SEQ_PTR(_strings_49599);
        _full_path_49597 = (int)*(((s1_ptr)_2)->base + _i_49620);
        Ref(_full_path_49597);

        /** 			file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_49598, _full_path_49597, _file_name_49593);

        /** 			try = open_locked(file_path)    */
        RefDS(_file_path_49598);
        _try_49602 = _36open_locked(_file_path_49598);
        if (!IS_ATOM_INT(_try_49602)) {
            _1 = (long)(DBL_PTR(_try_49602)->dbl);
            DeRefDS(_try_49602);
            _try_49602 = _1;
        }

        /** 			if try != -1 then*/
        if (_try_49602 == -1)
        goto L6; // [130] 145

        /** 				return {file_path,try}*/
        RefDS(_file_path_49598);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49598;
        ((int *)_2)[2] = _try_49602;
        _25902 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49593);
        DeRefDS(_env_49594);
        DeRefi(_inc_path_49596);
        DeRefDS(_full_path_49597);
        DeRefDS(_file_path_49598);
        DeRefDS(_strings_49599);
        return _25902;
L6: 

        /** 			ifdef WINDOWS then */

        /** 		end for*/
        _i_49620 = _i_49620 + 1;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** 		if cache_complete[num_var] then -- nothing to scan*/
    _2 = (int)SEQ_PTR(_42cache_complete_49198);
    _25903 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    if (_25903 == 0)
    {
        _25903 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _25903 = NOVALUE;
    }

    /** 			return -1*/
    DeRefDS(_file_name_49593);
    DeRefDS(_env_49594);
    DeRefi(_inc_path_49596);
    DeRef(_full_path_49597);
    DeRef(_file_path_49598);
    DeRef(_strings_49599);
    DeRef(_25902);
    _25902 = NOVALUE;
    return -1;
    goto L8; // [173] 200
L7: 

    /** 			pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (int)SEQ_PTR(_42cache_delims_49199);
    _25904 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    _pos_49604 = _25904 + 1;
    _25904 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** 		pos = 1*/
    _pos_49604 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_49601 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_49596)){
            _25906 = SEQ_PTR(_inc_path_49596)->length;
    }
    else {
        _25906 = 1;
    }
    {
        int _p_49636;
        _p_49636 = _pos_49604;
L9: 
        if (_p_49636 > _25906){
            goto LA; // [212] 460
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_49596);
        _25907 = (int)*(((s1_ptr)_2)->base + _p_49636);
        if (_25907 != 58)
        goto LB; // [227] 409

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_42cache_delims_49199);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49199 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        *(int *)_2 = _p_49636;

        /** 			end_path = p-1*/
        _end_path_49600 = _p_49636 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _25910 = (_end_path_49600 >= _start_path_49601);
        if (_25910 == 0) {
            goto LD; // [256] 290
        }
        _2 = (int)SEQ_PTR(_inc_path_49596);
        _25912 = (int)*(((s1_ptr)_2)->base + _end_path_49600);
        Concat((object_ptr)&_25914, _25913, _40SLASH_CHARS_16126);
        _25915 = find_from(_25912, _25914, 1);
        _25912 = NOVALUE;
        DeRefDS(_25914);
        _25914 = NOVALUE;
        if (_25915 == 0)
        {
            _25915 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _25915 = NOVALUE;
        }

        /** 				end_path-=1*/
        _end_path_49600 = _end_path_49600 - 1;

        /** 			end while*/
        goto LC; // [287] 252
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_49601 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_49600 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_49597;
        RHS_Slice(_inc_path_49596, _start_path_49601, _end_path_49600);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        _25919 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        RefDS(_full_path_49597);
        Append(&_25920, _25919, _full_path_49597);
        _25919 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49194 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25920;
        if( _1 != _25920 ){
            DeRefDS(_1);
        }
        _25920 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        _25921 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        if (IS_SEQUENCE(_25921) && IS_ATOM(_start_path_49601)) {
            Append(&_25922, _25921, _start_path_49601);
        }
        else if (IS_ATOM(_25921) && IS_SEQUENCE(_start_path_49601)) {
        }
        else {
            Concat((object_ptr)&_25922, _25921, _start_path_49601);
            _25921 = NOVALUE;
        }
        _25921 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25922;
        if( _1 != _25922 ){
            DeRef(_1);
        }
        _25922 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25923 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        if (IS_SEQUENCE(_25923) && IS_ATOM(_end_path_49600)) {
            Append(&_25924, _25923, _end_path_49600);
        }
        else if (IS_ATOM(_25923) && IS_SEQUENCE(_end_path_49600)) {
        }
        else {
            Concat((object_ptr)&_25924, _25923, _end_path_49600);
            _25923 = NOVALUE;
        }
        _25923 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49196 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25924;
        if( _1 != _25924 ){
            DeRef(_1);
        }
        _25924 = NOVALUE;

        /** 				file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_49598, _full_path_49597, _file_name_49593);

        /** 				try = open_locked(file_path)*/
        RefDS(_file_path_49598);
        _try_49602 = _36open_locked(_file_path_49598);
        if (!IS_ATOM_INT(_try_49602)) {
            _1 = (long)(DBL_PTR(_try_49602)->dbl);
            DeRefDS(_try_49602);
            _try_49602 = _1;
        }

        /** 				if try != -1 then -- valid path, no point trying to convert*/
        if (_try_49602 == -1)
        goto LF; // [381] 398

        /** 					ifdef WINDOWS then*/

        /** 					return {file_path,try}*/
        RefDS(_file_path_49598);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49598;
        ((int *)_2)[2] = _try_49602;
        _25928 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49593);
        DeRefDS(_env_49594);
        DeRefi(_inc_path_49596);
        DeRefDSi(_full_path_49597);
        DeRefDS(_file_path_49598);
        DeRef(_strings_49599);
        DeRef(_25902);
        _25902 = NOVALUE;
        _25907 = NOVALUE;
        DeRef(_25910);
        _25910 = NOVALUE;
        return _25928;
LF: 

        /** 				ifdef WINDOWS then*/

        /** 				start_path = 0*/
        _start_path_49601 = 0;
        goto LE; // [406] 453
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _25929 = (_start_path_49601 == 0);
        if (_25929 == 0) {
            goto L10; // [414] 452
        }
        _2 = (int)SEQ_PTR(_inc_path_49596);
        _25931 = (int)*(((s1_ptr)_2)->base + _p_49636);
        _25932 = (_25931 != 32);
        _25931 = NOVALUE;
        if (_25932 == 0) {
            DeRef(_25933);
            _25933 = 0;
            goto L11; // [426] 442
        }
        _2 = (int)SEQ_PTR(_inc_path_49596);
        _25934 = (int)*(((s1_ptr)_2)->base + _p_49636);
        _25935 = (_25934 != 9);
        _25934 = NOVALUE;
        _25933 = (_25935 != 0);
L11: 
        if (_25933 == 0)
        {
            _25933 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _25933 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_49601 = _p_49636;
L10: 
LE: 

        /** 	end for*/
        _p_49636 = _p_49636 + 1;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_42cache_complete_49198);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49198 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
    *(int *)_2 = 1;

    /** 	return -1*/
    DeRefDS(_file_name_49593);
    DeRefDS(_env_49594);
    DeRefi(_inc_path_49596);
    DeRef(_full_path_49597);
    DeRef(_file_path_49598);
    DeRef(_strings_49599);
    DeRef(_25902);
    _25902 = NOVALUE;
    _25907 = NOVALUE;
    DeRef(_25910);
    _25910 = NOVALUE;
    DeRef(_25928);
    _25928 = NOVALUE;
    DeRef(_25929);
    _25929 = NOVALUE;
    DeRef(_25932);
    _25932 = NOVALUE;
    DeRef(_25935);
    _25935 = NOVALUE;
    return -1;
    ;
}


int _42Include_paths(int _add_converted_49678)
{
    int _status_49679 = NOVALUE;
    int _pos_49680 = NOVALUE;
    int _inc_path_49681 = NOVALUE;
    int _full_path_49682 = NOVALUE;
    int _start_path_49683 = NOVALUE;
    int _end_path_49684 = NOVALUE;
    int _eudir_path_49700 = NOVALUE;
    int _25981 = NOVALUE;
    int _25980 = NOVALUE;
    int _25979 = NOVALUE;
    int _25978 = NOVALUE;
    int _25977 = NOVALUE;
    int _25976 = NOVALUE;
    int _25975 = NOVALUE;
    int _25974 = NOVALUE;
    int _25973 = NOVALUE;
    int _25972 = NOVALUE;
    int _25971 = NOVALUE;
    int _25970 = NOVALUE;
    int _25969 = NOVALUE;
    int _25968 = NOVALUE;
    int _25966 = NOVALUE;
    int _25964 = NOVALUE;
    int _25963 = NOVALUE;
    int _25962 = NOVALUE;
    int _25961 = NOVALUE;
    int _25960 = NOVALUE;
    int _25957 = NOVALUE;
    int _25956 = NOVALUE;
    int _25954 = NOVALUE;
    int _25952 = NOVALUE;
    int _25950 = NOVALUE;
    int _25949 = NOVALUE;
    int _25947 = NOVALUE;
    int _25944 = NOVALUE;
    int _25942 = NOVALUE;
    int _25937 = NOVALUE;
    int _25936 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_49678)) {
        _1 = (long)(DBL_PTR(_add_converted_49678)->dbl);
        DeRefDS(_add_converted_49678);
        _add_converted_49678 = _1;
    }

    /** 	if length(include_Paths) then*/
    if (IS_SEQUENCE(_42include_Paths_49675)){
            _25936 = SEQ_PTR(_42include_Paths_49675)->length;
    }
    else {
        _25936 = 1;
    }
    if (_25936 == 0)
    {
        _25936 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _25936 = NOVALUE;
    }

    /** 		return include_Paths*/
    RefDS(_42include_Paths_49675);
    DeRefi(_inc_path_49681);
    DeRefi(_full_path_49682);
    DeRef(_eudir_path_49700);
    return _42include_Paths_49675;
L1: 

    /** 	include_Paths = append(config_inc_paths, current_dir())*/
    _25937 = _17current_dir();
    Ref(_25937);
    Append(&_42include_Paths_49675, _42config_inc_paths_49200, _25937);
    DeRef(_25937);
    _25937 = NOVALUE;

    /** 	num_var = find("EUINC", cache_vars)*/
    _42num_var_49191 = find_from(_25939, _42cache_vars_49192, 1);

    /** 	inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_49681);
    _inc_path_49681 = EGetEnv(_25939);

    /** 	if atom(inc_path) then*/
    _25942 = IS_ATOM(_inc_path_49681);
    if (_25942 == 0)
    {
        _25942 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _25942 = NOVALUE;
    }

    /** 		inc_path = ""*/
    RefDS(_21815);
    DeRefi(_inc_path_49681);
    _inc_path_49681 = _21815;
L2: 

    /** 	status = check_cache("EUINC", inc_path)*/
    RefDS(_25939);
    Ref(_inc_path_49681);
    _status_49679 = _42check_cache(_25939, _inc_path_49681);
    if (!IS_ATOM_INT(_status_49679)) {
        _1 = (long)(DBL_PTR(_status_49679)->dbl);
        DeRefDS(_status_49679);
        _status_49679 = _1;
    }

    /** 	if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_49681)){
            _25944 = SEQ_PTR(_inc_path_49681)->length;
    }
    else {
        _25944 = 1;
    }
    if (_25944 == 0)
    {
        _25944 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _25944 = NOVALUE;
    }

    /** 		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_49681, _inc_path_49681, 58);
L3: 

    /** 	object eudir_path = get_eudir()*/
    _0 = _eudir_path_49700;
    _eudir_path_49700 = _36get_eudir();
    DeRef(_0);

    /** 	if sequence(eudir_path) then*/
    _25947 = IS_SEQUENCE(_eudir_path_49700);
    if (_25947 == 0)
    {
        _25947 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _25947 = NOVALUE;
    }

    /** 		include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_eudir_path_49700);
    *((int *)(_2+4)) = _eudir_path_49700;
    _25949 = MAKE_SEQ(_1);
    _25950 = EPrintf(-9999999, _25948, _25949);
    DeRefDS(_25949);
    _25949 = NOVALUE;
    RefDS(_25950);
    Append(&_42include_Paths_49675, _42include_Paths_49675, _25950);
    DeRefDS(_25950);
    _25950 = NOVALUE;
L4: 

    /** 	if status then*/
    if (_status_49679 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** 		if cache_complete[num_var] then*/
    _2 = (int)SEQ_PTR(_42cache_complete_49198);
    _25952 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    if (_25952 == 0)
    {
        _25952 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _25952 = NOVALUE;
    }

    /** 			goto "cache done"*/
    goto G7;
L6: 

    /** 		pos = cache_delims[num_var]+1*/
    _2 = (int)SEQ_PTR(_42cache_delims_49199);
    _25954 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    _pos_49680 = _25954 + 1;
    _25954 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /**         pos = 1*/
    _pos_49680 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_49683 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_49681)){
            _25956 = SEQ_PTR(_inc_path_49681)->length;
    }
    else {
        _25956 = 1;
    }
    {
        int _p_49717;
        _p_49717 = _pos_49680;
L9: 
        if (_p_49717 > _25956){
            goto LA; // [179] 394
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_49681);
        _25957 = (int)*(((s1_ptr)_2)->base + _p_49717);
        if (_25957 != 58)
        goto LB; // [194] 343

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_42cache_delims_49199);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_delims_49199 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        *(int *)_2 = _p_49717;

        /** 			end_path = p-1*/
        _end_path_49684 = _p_49717 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _25960 = (_end_path_49684 >= _start_path_49683);
        if (_25960 == 0) {
            goto LD; // [223] 257
        }
        _2 = (int)SEQ_PTR(_inc_path_49681);
        _25962 = (int)*(((s1_ptr)_2)->base + _end_path_49684);
        Concat((object_ptr)&_25963, _25913, _40SLASH_CHARS_16126);
        _25964 = find_from(_25962, _25963, 1);
        _25962 = NOVALUE;
        DeRefDS(_25963);
        _25963 = NOVALUE;
        if (_25964 == 0)
        {
            _25964 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _25964 = NOVALUE;
        }

        /** 				end_path -= 1*/
        _end_path_49684 = _end_path_49684 - 1;

        /** 			end while*/
        goto LC; // [254] 219
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_49683 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_49684 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_49682;
        RHS_Slice(_inc_path_49681, _start_path_49683, _end_path_49684);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        _25968 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        RefDS(_full_path_49682);
        Append(&_25969, _25968, _full_path_49682);
        _25968 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_substrings_49194);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_substrings_49194 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25969;
        if( _1 != _25969 ){
            DeRefDS(_1);
        }
        _25969 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        _25970 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        if (IS_SEQUENCE(_25970) && IS_ATOM(_start_path_49683)) {
            Append(&_25971, _25970, _start_path_49683);
        }
        else if (IS_ATOM(_25970) && IS_SEQUENCE(_start_path_49683)) {
        }
        else {
            Concat((object_ptr)&_25971, _25970, _start_path_49683);
            _25970 = NOVALUE;
        }
        _25970 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_starts_49195);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_starts_49195 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25971;
        if( _1 != _25971 ){
            DeRef(_1);
        }
        _25971 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        _25972 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
        if (IS_SEQUENCE(_25972) && IS_ATOM(_end_path_49684)) {
            Append(&_25973, _25972, _end_path_49684);
        }
        else if (IS_ATOM(_25972) && IS_SEQUENCE(_end_path_49684)) {
        }
        else {
            Concat((object_ptr)&_25973, _25972, _end_path_49684);
            _25972 = NOVALUE;
        }
        _25972 = NOVALUE;
        _2 = (int)SEQ_PTR(_42cache_ends_49196);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _42cache_ends_49196 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
        _1 = *(int *)_2;
        *(int *)_2 = _25973;
        if( _1 != _25973 ){
            DeRef(_1);
        }
        _25973 = NOVALUE;

        /** 				ifdef WINDOWS then*/

        /** 				start_path = 0*/
        _start_path_49683 = 0;
        goto LE; // [340] 387
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _25974 = (_start_path_49683 == 0);
        if (_25974 == 0) {
            goto LF; // [348] 386
        }
        _2 = (int)SEQ_PTR(_inc_path_49681);
        _25976 = (int)*(((s1_ptr)_2)->base + _p_49717);
        _25977 = (_25976 != 32);
        _25976 = NOVALUE;
        if (_25977 == 0) {
            DeRef(_25978);
            _25978 = 0;
            goto L10; // [360] 376
        }
        _2 = (int)SEQ_PTR(_inc_path_49681);
        _25979 = (int)*(((s1_ptr)_2)->base + _p_49717);
        _25980 = (_25979 != 9);
        _25979 = NOVALUE;
        _25978 = (_25980 != 0);
L10: 
        if (_25978 == 0)
        {
            _25978 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _25978 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_49683 = _p_49717;
LF: 
LE: 

        /** 	end for*/
        _p_49717 = _p_49717 + 1;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** label "cache done"*/
G7:

    /** 	include_Paths &= cache_substrings[num_var]*/
    _2 = (int)SEQ_PTR(_42cache_substrings_49194);
    _25981 = (int)*(((s1_ptr)_2)->base + _42num_var_49191);
    Concat((object_ptr)&_42include_Paths_49675, _42include_Paths_49675, _25981);
    _25981 = NOVALUE;

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_42cache_complete_49198);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _42cache_complete_49198 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _42num_var_49191);
    *(int *)_2 = 1;

    /** 	ifdef WINDOWS then*/

    /** 	return include_Paths*/
    RefDS(_42include_Paths_49675);
    DeRefi(_inc_path_49681);
    DeRefi(_full_path_49682);
    DeRef(_eudir_path_49700);
    _25957 = NOVALUE;
    DeRef(_25960);
    _25960 = NOVALUE;
    DeRef(_25974);
    _25974 = NOVALUE;
    DeRef(_25977);
    _25977 = NOVALUE;
    DeRef(_25980);
    _25980 = NOVALUE;
    return _42include_Paths_49675;
    ;
}


int _42e_path_find(int _name_49753)
{
    int _scan_result_49754 = NOVALUE;
    int _25991 = NOVALUE;
    int _25990 = NOVALUE;
    int _25989 = NOVALUE;
    int _25986 = NOVALUE;
    int _25985 = NOVALUE;
    int _25984 = NOVALUE;
    int _25983 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if file_exists(name) then*/
    RefDS(_name_49753);
    _25983 = _17file_exists(_name_49753);
    if (_25983 == 0) {
        DeRef(_25983);
        _25983 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_25983) && DBL_PTR(_25983)->dbl == 0.0){
            DeRef(_25983);
            _25983 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_25983);
        _25983 = NOVALUE;
    }
    DeRef(_25983);
    _25983 = NOVALUE;

    /** 		return name*/
    DeRef(_scan_result_49754);
    return _name_49753;
L1: 

    /** 	for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_40SLASH_CHARS_16126)){
            _25984 = SEQ_PTR(_40SLASH_CHARS_16126)->length;
    }
    else {
        _25984 = 1;
    }
    {
        int _i_49759;
        _i_49759 = 1;
L2: 
        if (_i_49759 > _25984){
            goto L3; // [26] 63
        }

        /** 		if find(SLASH_CHARS[i], name) then*/
        _2 = (int)SEQ_PTR(_40SLASH_CHARS_16126);
        _25985 = (int)*(((s1_ptr)_2)->base + _i_49759);
        _25986 = find_from(_25985, _name_49753, 1);
        _25985 = NOVALUE;
        if (_25986 == 0)
        {
            _25986 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _25986 = NOVALUE;
        }

        /** 			return -1*/
        DeRefDS(_name_49753);
        DeRef(_scan_result_49754);
        return -1;
L4: 

        /** 	end for*/
        _i_49759 = _i_49759 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** 	scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_49753);
    RefDS(_25987);
    _0 = _scan_result_49754;
    _scan_result_49754 = _42ScanPath(_name_49753, _25987, 0);
    DeRef(_0);

    /** 	if sequence(scan_result) then*/
    _25989 = IS_SEQUENCE(_scan_result_49754);
    if (_25989 == 0)
    {
        _25989 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _25989 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_49754);
    _25990 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25990))
    EClose(_25990);
    else
    EClose((int)DBL_PTR(_25990)->dbl);
    _25990 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_49754);
    _25991 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_25991);
    DeRefDS(_name_49753);
    DeRef(_scan_result_49754);
    return _25991;
L5: 

    /** 	return -1*/
    DeRefDS(_name_49753);
    DeRef(_scan_result_49754);
    _25991 = NOVALUE;
    return -1;
    ;
}



// 0x97331FA8
