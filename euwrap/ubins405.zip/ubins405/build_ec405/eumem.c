// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _29malloc(int _mem_struct_p_10566, int _cleanup_p_10567)
{
    int _temp__10568 = NOVALUE;
    int _5908 = NOVALUE;
    int _5906 = NOVALUE;
    int _5905 = NOVALUE;
    int _5904 = NOVALUE;
    int _5900 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_cleanup_p_10567)) {
        _1 = (long)(DBL_PTR(_cleanup_p_10567)->dbl);
        DeRefDS(_cleanup_p_10567);
        _cleanup_p_10567 = _1;
    }

    /** 	if atom(mem_struct_p) then*/
    _5900 = IS_ATOM(_mem_struct_p_10566);
    if (_5900 == 0)
    {
        _5900 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _5900 = NOVALUE;
    }

    /** 		mem_struct_p = repeat(0, mem_struct_p)*/
    _0 = _mem_struct_p_10566;
    _mem_struct_p_10566 = Repeat(0, _mem_struct_p_10566);
    DeRef(_0);
L1: 

    /** 	if ram_free_list = 0 then*/
    if (_29ram_free_list_10562 != 0)
    goto L2; // [22] 72

    /** 		ram_space = append(ram_space, mem_struct_p)*/
    Ref(_mem_struct_p_10566);
    Append(&_29ram_space_10561, _29ram_space_10561, _mem_struct_p_10566);

    /** 		if cleanup_p then*/
    if (_cleanup_p_10567 == 0)
    {
        goto L3; // [36] 59
    }
    else{
    }

    /** 			return delete_routine( length(ram_space), free_rid )*/
    if (IS_SEQUENCE(_29ram_space_10561)){
            _5904 = SEQ_PTR(_29ram_space_10561)->length;
    }
    else {
        _5904 = 1;
    }
    _5905 = NewDouble( (double) _5904 );
    _1 = (int) _00[_29free_rid_10563].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_29free_rid_10563].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _29free_rid_10563;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_5905)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_5905)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_5905)) ){
        DeRefDS(_5905);
        _5905 = NewDouble( DBL_PTR(_5905)->dbl );
    }
    DBL_PTR(_5905)->cleanup = (cleanup_ptr)_1;
    _5904 = NOVALUE;
    DeRef(_mem_struct_p_10566);
    return _5905;
    goto L4; // [56] 71
L3: 

    /** 			return length(ram_space)*/
    if (IS_SEQUENCE(_29ram_space_10561)){
            _5906 = SEQ_PTR(_29ram_space_10561)->length;
    }
    else {
        _5906 = 1;
    }
    DeRef(_mem_struct_p_10566);
    DeRef(_5905);
    _5905 = NOVALUE;
    return _5906;
L4: 
L2: 

    /** 	temp_ = ram_free_list*/
    _temp__10568 = _29ram_free_list_10562;

    /** 	ram_free_list = ram_space[temp_]*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _29ram_free_list_10562 = (int)*(((s1_ptr)_2)->base + _temp__10568);
    if (!IS_ATOM_INT(_29ram_free_list_10562))
    _29ram_free_list_10562 = (long)DBL_PTR(_29ram_free_list_10562)->dbl;

    /** 	ram_space[temp_] = mem_struct_p*/
    Ref(_mem_struct_p_10566);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp__10568);
    _1 = *(int *)_2;
    *(int *)_2 = _mem_struct_p_10566;
    DeRef(_1);

    /** 	if cleanup_p then*/
    if (_cleanup_p_10567 == 0)
    {
        goto L5; // [97] 115
    }
    else{
    }

    /** 		return delete_routine( temp_, free_rid )*/
    _5908 = NewDouble( (double) _temp__10568 );
    _1 = (int) _00[_29free_rid_10563].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_29free_rid_10563].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _29free_rid_10563;
    ((cleanup_ptr)_1)->next = 0;
    if(DBL_PTR(_5908)->cleanup != 0 ){
        _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_5908)->cleanup );
    }
    else if( !UNIQUE(DBL_PTR(_5908)) ){
        DeRefDS(_5908);
        _5908 = NewDouble( DBL_PTR(_5908)->dbl );
    }
    DBL_PTR(_5908)->cleanup = (cleanup_ptr)_1;
    DeRef(_mem_struct_p_10566);
    DeRef(_5905);
    _5905 = NOVALUE;
    return _5908;
    goto L6; // [112] 122
L5: 

    /** 		return temp_*/
    DeRef(_mem_struct_p_10566);
    DeRef(_5905);
    _5905 = NOVALUE;
    DeRef(_5908);
    _5908 = NOVALUE;
    return _temp__10568;
L6: 
    ;
}


void _29free(int _mem_p_10586)
{
    int _5910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if mem_p < 1 then return end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10586, 1)){
        goto L1; // [3] 11
    }
    DeRef(_mem_p_10586);
    return;
L1: 

    /** 	if mem_p > length(ram_space) then return end if*/
    if (IS_SEQUENCE(_29ram_space_10561)){
            _5910 = SEQ_PTR(_29ram_space_10561)->length;
    }
    else {
        _5910 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10586, _5910)){
        _5910 = NOVALUE;
        goto L2; // [18] 26
    }
    _5910 = NOVALUE;
    DeRef(_mem_p_10586);
    return;
L2: 

    /** 	ram_space[mem_p] = ram_free_list*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_mem_p_10586))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10586)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _mem_p_10586);
    _1 = *(int *)_2;
    *(int *)_2 = _29ram_free_list_10562;
    DeRef(_1);

    /** 	ram_free_list = floor(mem_p)*/
    if (IS_ATOM_INT(_mem_p_10586))
    _29ram_free_list_10562 = e_floor(_mem_p_10586);
    else
    _29ram_free_list_10562 = unary_op(FLOOR, _mem_p_10586);
    if (!IS_ATOM_INT(_29ram_free_list_10562)) {
        _1 = (long)(DBL_PTR(_29ram_free_list_10562)->dbl);
        DeRefDS(_29ram_free_list_10562);
        _29ram_free_list_10562 = _1;
    }

    /** end procedure*/
    DeRef(_mem_p_10586);
    return;
    ;
}


int _29valid(int _mem_p_10596, int _mem_struct_p_10597)
{
    int _5924 = NOVALUE;
    int _5923 = NOVALUE;
    int _5921 = NOVALUE;
    int _5920 = NOVALUE;
    int _5919 = NOVALUE;
    int _5917 = NOVALUE;
    int _5914 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(mem_p) then return 0 end if*/
    if (IS_ATOM_INT(_mem_p_10596))
    _5914 = 1;
    else if (IS_ATOM_DBL(_mem_p_10596))
    _5914 = IS_ATOM_INT(DoubleToInt(_mem_p_10596));
    else
    _5914 = 0;
    if (_5914 != 0)
    goto L1; // [6] 14
    _5914 = NOVALUE;
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 0;
L1: 

    /** 	if mem_p < 1 then return 0 end if*/
    if (binary_op_a(GREATEREQ, _mem_p_10596, 1)){
        goto L2; // [16] 25
    }
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 0;
L2: 

    /** 	if mem_p > length(ram_space) then return 0 end if*/
    if (IS_SEQUENCE(_29ram_space_10561)){
            _5917 = SEQ_PTR(_29ram_space_10561)->length;
    }
    else {
        _5917 = 1;
    }
    if (binary_op_a(LESSEQ, _mem_p_10596, _5917)){
        _5917 = NOVALUE;
        goto L3; // [32] 41
    }
    _5917 = NOVALUE;
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 0;
L3: 

    /** 	if sequence(mem_struct_p) then return 1 end if*/
    _5919 = IS_SEQUENCE(_mem_struct_p_10597);
    if (_5919 == 0)
    {
        _5919 = NOVALUE;
        goto L4; // [46] 54
    }
    else{
        _5919 = NOVALUE;
    }
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 1;
L4: 

    /** 	if atom(ram_space[mem_p]) then */
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_mem_p_10596)){
        _5920 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10596)->dbl));
    }
    else{
        _5920 = (int)*(((s1_ptr)_2)->base + _mem_p_10596);
    }
    _5921 = IS_ATOM(_5920);
    _5920 = NOVALUE;
    if (_5921 == 0)
    {
        _5921 = NOVALUE;
        goto L5; // [65] 88
    }
    else{
        _5921 = NOVALUE;
    }

    /** 		if mem_struct_p >= 0 then*/
    if (binary_op_a(LESS, _mem_struct_p_10597, 0)){
        goto L6; // [70] 81
    }

    /** 			return 0*/
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 0;
L6: 

    /** 		return 1*/
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    return 1;
L5: 

    /** 	if length(ram_space[mem_p]) != mem_struct_p then*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_mem_p_10596)){
        _5923 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_mem_p_10596)->dbl));
    }
    else{
        _5923 = (int)*(((s1_ptr)_2)->base + _mem_p_10596);
    }
    if (IS_SEQUENCE(_5923)){
            _5924 = SEQ_PTR(_5923)->length;
    }
    else {
        _5924 = 1;
    }
    _5923 = NOVALUE;
    if (binary_op_a(EQUALS, _5924, _mem_struct_p_10597)){
        _5924 = NOVALUE;
        goto L7; // [99] 110
    }
    _5924 = NOVALUE;

    /** 		return 0*/
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    _5923 = NOVALUE;
    return 0;
L7: 

    /** 	return 1*/
    DeRef(_mem_p_10596);
    DeRef(_mem_struct_p_10597);
    _5923 = NOVALUE;
    return 1;
    ;
}



// 0xA6F9324E
