// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _49fatal(int _errcode_17081, int _msg_17082, int _routine_name_17083, int _parms_17084)
{
    int _9694 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_17081;
    RefDS(_msg_17082);
    *((int *)(_2+8)) = _msg_17082;
    RefDS(_routine_name_17083);
    *((int *)(_2+12)) = _routine_name_17083;
    RefDS(_parms_17084);
    *((int *)(_2+16)) = _parms_17084;
    _9694 = MAKE_SEQ(_1);
    RefDS(_9694);
    Append(&_49vLastErrors_17078, _49vLastErrors_17078, _9694);
    DeRefDS(_9694);
    _9694 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_17082);
    DeRefDSi(_routine_name_17083);
    DeRefDS(_parms_17084);
    return;
    ;
}


int _49get4()
{
    int _9710 = NOVALUE;
    int _9709 = NOVALUE;
    int _9708 = NOVALUE;
    int _9707 = NOVALUE;
    int _9706 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9706 = getc((FILE*)xstdin);
        }
        else
        _9706 = getc(last_r_file_ptr);
    }
    else
    _9706 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem0_17096)){
        poke_addr = (unsigned char *)_49mem0_17096;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke_addr = (unsigned char)_9706;
    _9706 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9707 = getc((FILE*)xstdin);
        }
        else
        _9707 = getc(last_r_file_ptr);
    }
    else
    _9707 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem1_17097)){
        poke_addr = (unsigned char *)_49mem1_17097;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem1_17097)->dbl);
    }
    *poke_addr = (unsigned char)_9707;
    _9707 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9708 = getc((FILE*)xstdin);
        }
        else
        _9708 = getc(last_r_file_ptr);
    }
    else
    _9708 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem2_17098)){
        poke_addr = (unsigned char *)_49mem2_17098;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem2_17098)->dbl);
    }
    *poke_addr = (unsigned char)_9708;
    _9708 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9709 = getc((FILE*)xstdin);
        }
        else
        _9709 = getc(last_r_file_ptr);
    }
    else
    _9709 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_49mem3_17099)){
        poke_addr = (unsigned char *)_49mem3_17099;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_49mem3_17099)->dbl);
    }
    *poke_addr = (unsigned char)_9709;
    _9709 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_49mem0_17096)) {
        _9710 = *(unsigned long *)_49mem0_17096;
        if ((unsigned)_9710 > (unsigned)MAXINT)
        _9710 = NewDouble((double)(unsigned long)_9710);
    }
    else {
        _9710 = *(unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        if ((unsigned)_9710 > (unsigned)MAXINT)
        _9710 = NewDouble((double)(unsigned long)_9710);
    }
    return _9710;
    ;
}


int _49get_string()
{
    int _where_inlined_where_at_31_17124 = NOVALUE;
    int _s_17113 = NOVALUE;
    int _c_17114 = NOVALUE;
    int _i_17115 = NOVALUE;
    int _9723 = NOVALUE;
    int _9720 = NOVALUE;
    int _9718 = NOVALUE;
    int _9716 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_17113);
    _s_17113 = Repeat(0, 256);

    /** 	i = 0*/
    _i_17115 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_17114 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17114 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_17124);
    _where_inlined_where_at_31_17124 = machine(20, _49current_db_17054);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_17124);
    *((int *)(_2+4)) = _where_inlined_where_at_31_17124;
    _9716 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9715);
    _49fatal(900, _9714, _9715, _9716);
    _9716 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_17115 = _i_17115 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_17113)){
            _9718 = SEQ_PTR(_s_17113)->length;
    }
    else {
        _9718 = 1;
    }
    if (_i_17115 <= _9718)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9720 = Repeat(0, 256);
    Concat((object_ptr)&_s_17113, _s_17113, _9720);
    DeRefDS(_9720);
    _9720 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_17113);
    _2 = (int)(((s1_ptr)_2)->base + _i_17115);
    *(int *)_2 = _c_17114;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17114 = getc((FILE*)xstdin);
        }
        else
        _c_17114 = getc(last_r_file_ptr);
    }
    else
    _c_17114 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9723;
    RHS_Slice(_s_17113, 1, _i_17115);
    DeRefDSi(_s_17113);
    return _9723;
    ;
}


int _49equal_string(int _target_17136)
{
    int _c_17137 = NOVALUE;
    int _i_17138 = NOVALUE;
    int _where_inlined_where_at_27_17144 = NOVALUE;
    int _9734 = NOVALUE;
    int _9733 = NOVALUE;
    int _9730 = NOVALUE;
    int _9728 = NOVALUE;
    int _9726 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_17138 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_17137 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17137 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_17144);
    _where_inlined_where_at_27_17144 = machine(20, _49current_db_17054);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_17144);
    *((int *)(_2+4)) = _where_inlined_where_at_27_17144;
    _9726 = MAKE_SEQ(_1);
    RefDS(_9714);
    RefDS(_9725);
    _49fatal(900, _9714, _9725, _9726);
    _9726 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_17136);
    return -404;
L4: 

    /** 		i += 1*/
    _i_17138 = _i_17138 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_17136)){
            _9728 = SEQ_PTR(_target_17136)->length;
    }
    else {
        _9728 = 1;
    }
    if (_i_17138 <= _9728)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_17136);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_17136);
    _9730 = (int)*(((s1_ptr)_2)->base + _i_17138);
    if (binary_op_a(EQUALS, _9730, _c_17137)){
        _9730 = NOVALUE;
        goto L6; // [80] 91
    }
    _9730 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_17136);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17137 = getc((FILE*)xstdin);
        }
        else
        _c_17137 = getc(last_r_file_ptr);
    }
    else
    _c_17137 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_17136)){
            _9733 = SEQ_PTR(_target_17136)->length;
    }
    else {
        _9733 = 1;
    }
    _9734 = (_i_17138 == _9733);
    _9733 = NOVALUE;
    DeRefDS(_target_17136);
    return _9734;
    ;
}


int _49decompress(int _c_17195)
{
    int _s_17196 = NOVALUE;
    int _len_17197 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_17233 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_17232 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_17246 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_17245 = NOVALUE;
    int _9803 = NOVALUE;
    int _9802 = NOVALUE;
    int _9801 = NOVALUE;
    int _9798 = NOVALUE;
    int _9793 = NOVALUE;
    int _9792 = NOVALUE;
    int _9791 = NOVALUE;
    int _9790 = NOVALUE;
    int _9789 = NOVALUE;
    int _9788 = NOVALUE;
    int _9787 = NOVALUE;
    int _9786 = NOVALUE;
    int _9785 = NOVALUE;
    int _9784 = NOVALUE;
    int _9783 = NOVALUE;
    int _9782 = NOVALUE;
    int _9781 = NOVALUE;
    int _9780 = NOVALUE;
    int _9779 = NOVALUE;
    int _9778 = NOVALUE;
    int _9777 = NOVALUE;
    int _9776 = NOVALUE;
    int _9775 = NOVALUE;
    int _9774 = NOVALUE;
    int _9772 = NOVALUE;
    int _9771 = NOVALUE;
    int _9770 = NOVALUE;
    int _9769 = NOVALUE;
    int _9768 = NOVALUE;
    int _9767 = NOVALUE;
    int _9766 = NOVALUE;
    int _9765 = NOVALUE;
    int _9764 = NOVALUE;
    int _9761 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_17195 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_49current_db_17054 != last_r_file_no) {
        last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
        last_r_file_no = _49current_db_17054;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17195 = getc((FILE*)xstdin);
        }
        else
        _c_17195 = getc(last_r_file_ptr);
    }
    else
    _c_17195 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_17195 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9761 = _c_17195 + -9;
    DeRef(_s_17196);
    return _9761;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_17195;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9764 = getc((FILE*)xstdin);
            }
            else
            _9764 = getc(last_r_file_ptr);
        }
        else
        _9764 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9765 = getc((FILE*)xstdin);
            }
            else
            _9765 = getc(last_r_file_ptr);
        }
        else
        _9765 = getc(last_r_file_ptr);
        _9766 = 256 * _9765;
        _9765 = NOVALUE;
        _9767 = _9764 + _9766;
        _9764 = NOVALUE;
        _9766 = NOVALUE;
        _9768 = _9767 + _49MIN2B_17175;
        if ((long)((unsigned long)_9768 + (unsigned long)HIGH_BITS) >= 0) 
        _9768 = NewDouble((double)_9768);
        _9767 = NOVALUE;
        DeRef(_s_17196);
        DeRef(_9761);
        _9761 = NOVALUE;
        return _9768;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9769 = getc((FILE*)xstdin);
            }
            else
            _9769 = getc(last_r_file_ptr);
        }
        else
        _9769 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9770 = getc((FILE*)xstdin);
            }
            else
            _9770 = getc(last_r_file_ptr);
        }
        else
        _9770 = getc(last_r_file_ptr);
        _9771 = 256 * _9770;
        _9770 = NOVALUE;
        _9772 = _9769 + _9771;
        _9769 = NOVALUE;
        _9771 = NOVALUE;
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9774 = getc((FILE*)xstdin);
            }
            else
            _9774 = getc(last_r_file_ptr);
        }
        else
        _9774 = getc(last_r_file_ptr);
        _9775 = 65536 * _9774;
        _9774 = NOVALUE;
        _9776 = _9772 + _9775;
        _9772 = NOVALUE;
        _9775 = NOVALUE;
        _9777 = _9776 + _49MIN3B_17182;
        if ((long)((unsigned long)_9777 + (unsigned long)HIGH_BITS) >= 0) 
        _9777 = NewDouble((double)_9777);
        _9776 = NOVALUE;
        DeRef(_s_17196);
        DeRef(_9761);
        _9761 = NOVALUE;
        DeRef(_9768);
        _9768 = NOVALUE;
        return _9777;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9778 = _49get4();
        if (IS_ATOM_INT(_9778) && IS_ATOM_INT(_49MIN4B_17189)) {
            _9779 = _9778 + _49MIN4B_17189;
            if ((long)((unsigned long)_9779 + (unsigned long)HIGH_BITS) >= 0) 
            _9779 = NewDouble((double)_9779);
        }
        else {
            _9779 = binary_op(PLUS, _9778, _49MIN4B_17189);
        }
        DeRef(_9778);
        _9778 = NOVALUE;
        DeRef(_s_17196);
        DeRef(_9761);
        _9761 = NOVALUE;
        DeRef(_9768);
        _9768 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        return _9779;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9780 = getc((FILE*)xstdin);
            }
            else
            _9780 = getc(last_r_file_ptr);
        }
        else
        _9780 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9781 = getc((FILE*)xstdin);
            }
            else
            _9781 = getc(last_r_file_ptr);
        }
        else
        _9781 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9782 = getc((FILE*)xstdin);
            }
            else
            _9782 = getc(last_r_file_ptr);
        }
        else
        _9782 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9783 = getc((FILE*)xstdin);
            }
            else
            _9783 = getc(last_r_file_ptr);
        }
        else
        _9783 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9780;
        *((int *)(_2+8)) = _9781;
        *((int *)(_2+12)) = _9782;
        *((int *)(_2+16)) = _9783;
        _9784 = MAKE_SEQ(_1);
        _9783 = NOVALUE;
        _9782 = NOVALUE;
        _9781 = NOVALUE;
        _9780 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17232);
        _ieee32_inlined_float32_to_atom_at_173_17232 = _9784;
        _9784 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17233);
        _float32_to_atom_inlined_float32_to_atom_at_176_17233 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17232);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17232);
        _ieee32_inlined_float32_to_atom_at_173_17232 = NOVALUE;
        DeRef(_s_17196);
        DeRef(_9761);
        _9761 = NOVALUE;
        DeRef(_9768);
        _9768 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        DeRef(_9779);
        _9779 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17233;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9785 = getc((FILE*)xstdin);
            }
            else
            _9785 = getc(last_r_file_ptr);
        }
        else
        _9785 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9786 = getc((FILE*)xstdin);
            }
            else
            _9786 = getc(last_r_file_ptr);
        }
        else
        _9786 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9787 = getc((FILE*)xstdin);
            }
            else
            _9787 = getc(last_r_file_ptr);
        }
        else
        _9787 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9788 = getc((FILE*)xstdin);
            }
            else
            _9788 = getc(last_r_file_ptr);
        }
        else
        _9788 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9789 = getc((FILE*)xstdin);
            }
            else
            _9789 = getc(last_r_file_ptr);
        }
        else
        _9789 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9790 = getc((FILE*)xstdin);
            }
            else
            _9790 = getc(last_r_file_ptr);
        }
        else
        _9790 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9791 = getc((FILE*)xstdin);
            }
            else
            _9791 = getc(last_r_file_ptr);
        }
        else
        _9791 = getc(last_r_file_ptr);
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9792 = getc((FILE*)xstdin);
            }
            else
            _9792 = getc(last_r_file_ptr);
        }
        else
        _9792 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9785;
        *((int *)(_2+8)) = _9786;
        *((int *)(_2+12)) = _9787;
        *((int *)(_2+16)) = _9788;
        *((int *)(_2+20)) = _9789;
        *((int *)(_2+24)) = _9790;
        *((int *)(_2+28)) = _9791;
        *((int *)(_2+32)) = _9792;
        _9793 = MAKE_SEQ(_1);
        _9792 = NOVALUE;
        _9791 = NOVALUE;
        _9790 = NOVALUE;
        _9789 = NOVALUE;
        _9788 = NOVALUE;
        _9787 = NOVALUE;
        _9786 = NOVALUE;
        _9785 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17245);
        _ieee64_inlined_float64_to_atom_at_248_17245 = _9793;
        _9793 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17246);
        _float64_to_atom_inlined_float64_to_atom_at_251_17246 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17245);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17245);
        _ieee64_inlined_float64_to_atom_at_248_17245 = NOVALUE;
        DeRef(_s_17196);
        DeRef(_9761);
        _9761 = NOVALUE;
        DeRef(_9768);
        _9768 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        DeRef(_9779);
        _9779 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17246;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_17195 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_49current_db_17054 != last_r_file_no) {
            last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
            last_r_file_no = _49current_db_17054;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_17197 = getc((FILE*)xstdin);
            }
            else
            _len_17197 = getc(last_r_file_ptr);
        }
        else
        _len_17197 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_17197 = _49get4();
        if (!IS_ATOM_INT(_len_17197)) {
            _1 = (long)(DBL_PTR(_len_17197)->dbl);
            DeRefDS(_len_17197);
            _len_17197 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_17196);
        _s_17196 = Repeat(0, _len_17197);

        /** 			for i = 1 to len do*/
        _9798 = _len_17197;
        {
            int _i_17255;
            _i_17255 = 1;
L5: 
            if (_i_17255 > _9798){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_49current_db_17054 != last_r_file_no) {
                last_r_file_ptr = which_file(_49current_db_17054, EF_READ);
                last_r_file_no = _49current_db_17054;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_17195 = getc((FILE*)xstdin);
                }
                else
                _c_17195 = getc(last_r_file_ptr);
            }
            else
            _c_17195 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_17195 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9801 = _c_17195 + -9;
            _2 = (int)SEQ_PTR(_s_17196);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17196 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17255);
            _1 = *(int *)_2;
            *(int *)_2 = _9801;
            if( _1 != _9801 ){
                DeRef(_1);
            }
            _9801 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9802);
            _9802 = _c_17195;
            _9803 = _49decompress(_9802);
            _9802 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_17196);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17196 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17255);
            _1 = *(int *)_2;
            *(int *)_2 = _9803;
            if( _1 != _9803 ){
                DeRef(_1);
            }
            _9803 = NOVALUE;
L8: 

            /** 			end for*/
            _i_17255 = _i_17255 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9761);
        _9761 = NOVALUE;
        DeRef(_9768);
        _9768 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        DeRef(_9779);
        _9779 = NOVALUE;
        return _s_17196;
    ;}    ;
}


int _49compress(int _x_17266)
{
    int _x4_17267 = NOVALUE;
    int _s_17268 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_17302 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_17305 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_17310 = NOVALUE;
    int _9842 = NOVALUE;
    int _9841 = NOVALUE;
    int _9840 = NOVALUE;
    int _9838 = NOVALUE;
    int _9837 = NOVALUE;
    int _9835 = NOVALUE;
    int _9833 = NOVALUE;
    int _9832 = NOVALUE;
    int _9831 = NOVALUE;
    int _9829 = NOVALUE;
    int _9828 = NOVALUE;
    int _9827 = NOVALUE;
    int _9826 = NOVALUE;
    int _9825 = NOVALUE;
    int _9824 = NOVALUE;
    int _9823 = NOVALUE;
    int _9822 = NOVALUE;
    int _9821 = NOVALUE;
    int _9819 = NOVALUE;
    int _9818 = NOVALUE;
    int _9817 = NOVALUE;
    int _9816 = NOVALUE;
    int _9815 = NOVALUE;
    int _9814 = NOVALUE;
    int _9812 = NOVALUE;
    int _9811 = NOVALUE;
    int _9810 = NOVALUE;
    int _9809 = NOVALUE;
    int _9808 = NOVALUE;
    int _9807 = NOVALUE;
    int _9806 = NOVALUE;
    int _9805 = NOVALUE;
    int _9804 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_17266))
    _9804 = 1;
    else if (IS_ATOM_DBL(_x_17266))
    _9804 = IS_ATOM_INT(DoubleToInt(_x_17266));
    else
    _9804 = 0;
    if (_9804 == 0)
    {
        _9804 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9804 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_17266)) {
        _9805 = (_x_17266 >= -9);
    }
    else {
        _9805 = binary_op(GREATEREQ, _x_17266, -9);
    }
    if (IS_ATOM_INT(_9805)) {
        if (_9805 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9805)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_17266)) {
        _9807 = (_x_17266 <= 239);
    }
    else {
        _9807 = binary_op(LESSEQ, _x_17266, 239);
    }
    if (_9807 == 0) {
        DeRef(_9807);
        _9807 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9807) && DBL_PTR(_9807)->dbl == 0.0){
            DeRef(_9807);
            _9807 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9807);
        _9807 = NOVALUE;
    }
    DeRef(_9807);
    _9807 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_17266)) {
        _9808 = _x_17266 - -9;
        if ((long)((unsigned long)_9808 +(unsigned long) HIGH_BITS) >= 0){
            _9808 = NewDouble((double)_9808);
        }
    }
    else {
        _9808 = binary_op(MINUS, _x_17266, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9808;
    _9809 = MAKE_SEQ(_1);
    _9808 = NOVALUE;
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    return _9809;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_17266)) {
        _9810 = (_x_17266 >= _49MIN2B_17175);
    }
    else {
        _9810 = binary_op(GREATEREQ, _x_17266, _49MIN2B_17175);
    }
    if (IS_ATOM_INT(_9810)) {
        if (_9810 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9810)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_17266)) {
        _9812 = (_x_17266 <= 32767);
    }
    else {
        _9812 = binary_op(LESSEQ, _x_17266, 32767);
    }
    if (_9812 == 0) {
        DeRef(_9812);
        _9812 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9812) && DBL_PTR(_9812)->dbl == 0.0){
            DeRef(_9812);
            _9812 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9812);
        _9812 = NOVALUE;
    }
    DeRef(_9812);
    _9812 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_17266;
    if (IS_ATOM_INT(_x_17266)) {
        _x_17266 = _x_17266 - _49MIN2B_17175;
        if ((long)((unsigned long)_x_17266 +(unsigned long) HIGH_BITS) >= 0){
            _x_17266 = NewDouble((double)_x_17266);
        }
    }
    else {
        _x_17266 = binary_op(MINUS, _x_17266, _49MIN2B_17175);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_17266)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17266 & (unsigned long)255;
             _9814 = MAKE_UINT(tu);
        }
    }
    else {
        _9814 = binary_op(AND_BITS, _x_17266, 255);
    }
    if (IS_ATOM_INT(_x_17266)) {
        if (256 > 0 && _x_17266 >= 0) {
            _9815 = _x_17266 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17266 / (double)256);
            if (_x_17266 != MININT)
            _9815 = (long)temp_dbl;
            else
            _9815 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17266, 256);
        _9815 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _9814;
    *((int *)(_2+12)) = _9815;
    _9816 = MAKE_SEQ(_1);
    _9815 = NOVALUE;
    _9814 = NOVALUE;
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    return _9816;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_17266)) {
        _9817 = (_x_17266 >= _49MIN3B_17182);
    }
    else {
        _9817 = binary_op(GREATEREQ, _x_17266, _49MIN3B_17182);
    }
    if (IS_ATOM_INT(_9817)) {
        if (_9817 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9817)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_17266)) {
        _9819 = (_x_17266 <= 8388607);
    }
    else {
        _9819 = binary_op(LESSEQ, _x_17266, 8388607);
    }
    if (_9819 == 0) {
        DeRef(_9819);
        _9819 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9819) && DBL_PTR(_9819)->dbl == 0.0){
            DeRef(_9819);
            _9819 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9819);
        _9819 = NOVALUE;
    }
    DeRef(_9819);
    _9819 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_17266;
    if (IS_ATOM_INT(_x_17266)) {
        _x_17266 = _x_17266 - _49MIN3B_17182;
        if ((long)((unsigned long)_x_17266 +(unsigned long) HIGH_BITS) >= 0){
            _x_17266 = NewDouble((double)_x_17266);
        }
    }
    else {
        _x_17266 = binary_op(MINUS, _x_17266, _49MIN3B_17182);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_17266)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17266 & (unsigned long)255;
             _9821 = MAKE_UINT(tu);
        }
    }
    else {
        _9821 = binary_op(AND_BITS, _x_17266, 255);
    }
    if (IS_ATOM_INT(_x_17266)) {
        if (256 > 0 && _x_17266 >= 0) {
            _9822 = _x_17266 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17266 / (double)256);
            if (_x_17266 != MININT)
            _9822 = (long)temp_dbl;
            else
            _9822 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17266, 256);
        _9822 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9822)) {
        {unsigned long tu;
             tu = (unsigned long)_9822 & (unsigned long)255;
             _9823 = MAKE_UINT(tu);
        }
    }
    else {
        _9823 = binary_op(AND_BITS, _9822, 255);
    }
    DeRef(_9822);
    _9822 = NOVALUE;
    if (IS_ATOM_INT(_x_17266)) {
        if (65536 > 0 && _x_17266 >= 0) {
            _9824 = _x_17266 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_17266 / (double)65536);
            if (_x_17266 != MININT)
            _9824 = (long)temp_dbl;
            else
            _9824 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17266, 65536);
        _9824 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _9821;
    *((int *)(_2+12)) = _9823;
    *((int *)(_2+16)) = _9824;
    _9825 = MAKE_SEQ(_1);
    _9824 = NOVALUE;
    _9823 = NOVALUE;
    _9821 = NOVALUE;
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9816);
    _9816 = NOVALUE;
    DeRef(_9817);
    _9817 = NOVALUE;
    return _9825;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_17266) && IS_ATOM_INT(_49MIN4B_17189)) {
        _9826 = _x_17266 - _49MIN4B_17189;
        if ((long)((unsigned long)_9826 +(unsigned long) HIGH_BITS) >= 0){
            _9826 = NewDouble((double)_9826);
        }
    }
    else {
        _9826 = binary_op(MINUS, _x_17266, _49MIN4B_17189);
    }
    _9827 = _15int_to_bytes(_9826);
    _9826 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9827)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9827)) {
        Prepend(&_9828, _9827, 251);
    }
    else {
        Concat((object_ptr)&_9828, 251, _9827);
    }
    DeRef(_9827);
    _9827 = NOVALUE;
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9816);
    _9816 = NOVALUE;
    DeRef(_9817);
    _9817 = NOVALUE;
    DeRef(_9825);
    _9825 = NOVALUE;
    return _9828;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _9829 = IS_ATOM(_x_17266);
    if (_9829 == 0)
    {
        _9829 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _9829 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_17267);
    _x4_17267 = machine(48, _x_17266);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_17305);
    _float32_to_atom_inlined_float32_to_atom_at_203_17305 = machine(49, _x4_17267);
    if (binary_op_a(NOTEQ, _x_17266, _float32_to_atom_inlined_float32_to_atom_at_203_17305)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_9831, _x4_17267, 252);
    DeRef(_x_17266);
    DeRefDSi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9816);
    _9816 = NOVALUE;
    DeRef(_9817);
    _9817 = NOVALUE;
    DeRef(_9825);
    _9825 = NOVALUE;
    DeRef(_9828);
    _9828 = NOVALUE;
    return _9831;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_17310);
    _atom_to_float64_inlined_atom_to_float64_at_229_17310 = machine(46, _x_17266);
    Prepend(&_9832, _atom_to_float64_inlined_atom_to_float64_at_229_17310, 253);
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_s_17268);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9816);
    _9816 = NOVALUE;
    DeRef(_9817);
    _9817 = NOVALUE;
    DeRef(_9825);
    _9825 = NOVALUE;
    DeRef(_9828);
    _9828 = NOVALUE;
    DeRef(_9831);
    _9831 = NOVALUE;
    return _9832;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_17266)){
            _9833 = SEQ_PTR(_x_17266)->length;
    }
    else {
        _9833 = 1;
    }
    if (_9833 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_17266)){
            _9835 = SEQ_PTR(_x_17266)->length;
    }
    else {
        _9835 = 1;
    }
    DeRef(_s_17268);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _9835;
    _s_17268 = MAKE_SEQ(_1);
    _9835 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_17266)){
            _9837 = SEQ_PTR(_x_17266)->length;
    }
    else {
        _9837 = 1;
    }
    _9838 = _15int_to_bytes(_9837);
    _9837 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9838)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9838)) {
        Prepend(&_s_17268, _9838, 255);
    }
    else {
        Concat((object_ptr)&_s_17268, 255, _9838);
    }
    DeRef(_9838);
    _9838 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_17266)){
            _9840 = SEQ_PTR(_x_17266)->length;
    }
    else {
        _9840 = 1;
    }
    {
        int _i_17323;
        _i_17323 = 1;
LA: 
        if (_i_17323 > _9840){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_17266);
        _9841 = (int)*(((s1_ptr)_2)->base + _i_17323);
        Ref(_9841);
        _9842 = _49compress(_9841);
        _9841 = NOVALUE;
        if (IS_SEQUENCE(_s_17268) && IS_ATOM(_9842)) {
            Ref(_9842);
            Append(&_s_17268, _s_17268, _9842);
        }
        else if (IS_ATOM(_s_17268) && IS_SEQUENCE(_9842)) {
        }
        else {
            Concat((object_ptr)&_s_17268, _s_17268, _9842);
        }
        DeRef(_9842);
        _9842 = NOVALUE;

        /** 		end for*/
        _i_17323 = _i_17323 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_17266);
    DeRefi(_x4_17267);
    DeRef(_9805);
    _9805 = NOVALUE;
    DeRef(_9809);
    _9809 = NOVALUE;
    DeRef(_9810);
    _9810 = NOVALUE;
    DeRef(_9816);
    _9816 = NOVALUE;
    DeRef(_9817);
    _9817 = NOVALUE;
    DeRef(_9825);
    _9825 = NOVALUE;
    DeRef(_9828);
    _9828 = NOVALUE;
    DeRef(_9831);
    _9831 = NOVALUE;
    DeRef(_9832);
    _9832 = NOVALUE;
    return _s_17268;
L3: 
    ;
}


int _49db_allocate(int _n_17707)
{
    int _free_list_17708 = NOVALUE;
    int _size_17709 = NOVALUE;
    int _size_ptr_17710 = NOVALUE;
    int _addr_17711 = NOVALUE;
    int _free_count_17712 = NOVALUE;
    int _remaining_17713 = NOVALUE;
    int _seek_1__tmp_at4_17716 = NOVALUE;
    int _seek_inlined_seek_at_4_17715 = NOVALUE;
    int _seek_1__tmp_at39_17723 = NOVALUE;
    int _seek_inlined_seek_at_39_17722 = NOVALUE;
    int _seek_1__tmp_at111_17740 = NOVALUE;
    int _seek_inlined_seek_at_111_17739 = NOVALUE;
    int _pos_inlined_seek_at_108_17738 = NOVALUE;
    int _put4_1__tmp_at137_17745 = NOVALUE;
    int _x_inlined_put4_at_134_17744 = NOVALUE;
    int _seek_1__tmp_at167_17748 = NOVALUE;
    int _seek_inlined_seek_at_167_17747 = NOVALUE;
    int _put4_1__tmp_at193_17753 = NOVALUE;
    int _x_inlined_put4_at_190_17752 = NOVALUE;
    int _seek_1__tmp_at244_17761 = NOVALUE;
    int _seek_inlined_seek_at_244_17760 = NOVALUE;
    int _pos_inlined_seek_at_241_17759 = NOVALUE;
    int _put4_1__tmp_at266_17765 = NOVALUE;
    int _x_inlined_put4_at_263_17764 = NOVALUE;
    int _seek_1__tmp_at333_17776 = NOVALUE;
    int _seek_inlined_seek_at_333_17775 = NOVALUE;
    int _pos_inlined_seek_at_330_17774 = NOVALUE;
    int _seek_1__tmp_at364_17780 = NOVALUE;
    int _seek_inlined_seek_at_364_17779 = NOVALUE;
    int _put4_1__tmp_at386_17784 = NOVALUE;
    int _x_inlined_put4_at_383_17783 = NOVALUE;
    int _seek_1__tmp_at423_17789 = NOVALUE;
    int _seek_inlined_seek_at_423_17788 = NOVALUE;
    int _pos_inlined_seek_at_420_17787 = NOVALUE;
    int _put4_1__tmp_at438_17791 = NOVALUE;
    int _seek_1__tmp_at490_17795 = NOVALUE;
    int _seek_inlined_seek_at_490_17794 = NOVALUE;
    int _put4_1__tmp_at512_17799 = NOVALUE;
    int _x_inlined_put4_at_509_17798 = NOVALUE;
    int _where_inlined_where_at_542_17801 = NOVALUE;
    int _10054 = NOVALUE;
    int _10052 = NOVALUE;
    int _10051 = NOVALUE;
    int _10050 = NOVALUE;
    int _10049 = NOVALUE;
    int _10048 = NOVALUE;
    int _10046 = NOVALUE;
    int _10045 = NOVALUE;
    int _10044 = NOVALUE;
    int _10043 = NOVALUE;
    int _10041 = NOVALUE;
    int _10040 = NOVALUE;
    int _10039 = NOVALUE;
    int _10038 = NOVALUE;
    int _10037 = NOVALUE;
    int _10036 = NOVALUE;
    int _10035 = NOVALUE;
    int _10033 = NOVALUE;
    int _10031 = NOVALUE;
    int _10028 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17716);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_17716 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17715 = machine(19, _seek_1__tmp_at4_17716);
    DeRefi(_seek_1__tmp_at4_17716);
    _seek_1__tmp_at4_17716 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17712 = _49get4();
    if (!IS_ATOM_INT(_free_count_17712)) {
        _1 = (long)(DBL_PTR(_free_count_17712)->dbl);
        DeRefDS(_free_count_17712);
        _free_count_17712 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_17712 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_17708;
    _free_list_17708 = _49get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17708);
    DeRef(_seek_1__tmp_at39_17723);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _free_list_17708;
    _seek_1__tmp_at39_17723 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_17722 = machine(19, _seek_1__tmp_at39_17723);
    DeRef(_seek_1__tmp_at39_17723);
    _seek_1__tmp_at39_17723 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_17710);
    if (IS_ATOM_INT(_free_list_17708)) {
        _size_ptr_17710 = _free_list_17708 + 4;
        if ((long)((unsigned long)_size_ptr_17710 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_17710 = NewDouble((double)_size_ptr_17710);
    }
    else {
        _size_ptr_17710 = NewDouble(DBL_PTR(_free_list_17708)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _10028 = _free_count_17712;
    {
        int _i_17726;
        _i_17726 = 1;
L2: 
        if (_i_17726 > _10028){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_17711;
        _addr_17711 = _49get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_17709;
        _size_17709 = _49get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_17707)) {
            _10031 = _n_17707 + 4;
            if ((long)((unsigned long)_10031 + (unsigned long)HIGH_BITS) >= 0) 
            _10031 = NewDouble((double)_10031);
        }
        else {
            _10031 = NewDouble(DBL_PTR(_n_17707)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_17709, _10031)){
            DeRef(_10031);
            _10031 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_10031);
        _10031 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_17707)) {
            _10033 = _n_17707 + 16;
            if ((long)((unsigned long)_10033 + (unsigned long)HIGH_BITS) >= 0) 
            _10033 = NewDouble((double)_10033);
        }
        else {
            _10033 = NewDouble(DBL_PTR(_n_17707)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_17709, _10033)){
            DeRef(_10033);
            _10033 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_10033);
        _10033 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17711)) {
            _10035 = _addr_17711 - 4;
            if ((long)((unsigned long)_10035 +(unsigned long) HIGH_BITS) >= 0){
                _10035 = NewDouble((double)_10035);
            }
        }
        else {
            _10035 = NewDouble(DBL_PTR(_addr_17711)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_17738);
        _pos_inlined_seek_at_108_17738 = _10035;
        _10035 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_17738);
        DeRef(_seek_1__tmp_at111_17740);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_17738;
        _seek_1__tmp_at111_17740 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_17739 = machine(19, _seek_1__tmp_at111_17740);
        DeRef(_pos_inlined_seek_at_108_17738);
        _pos_inlined_seek_at_108_17738 = NOVALUE;
        DeRef(_seek_1__tmp_at111_17740);
        _seek_1__tmp_at111_17740 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_17709) && IS_ATOM_INT(_n_17707)) {
            _10036 = _size_17709 - _n_17707;
            if ((long)((unsigned long)_10036 +(unsigned long) HIGH_BITS) >= 0){
                _10036 = NewDouble((double)_10036);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17709)) {
                _10036 = NewDouble((double)_size_17709 - DBL_PTR(_n_17707)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17707)) {
                    _10036 = NewDouble(DBL_PTR(_size_17709)->dbl - (double)_n_17707);
                }
                else
                _10036 = NewDouble(DBL_PTR(_size_17709)->dbl - DBL_PTR(_n_17707)->dbl);
            }
        }
        if (IS_ATOM_INT(_10036)) {
            _10037 = _10036 - 4;
            if ((long)((unsigned long)_10037 +(unsigned long) HIGH_BITS) >= 0){
                _10037 = NewDouble((double)_10037);
            }
        }
        else {
            _10037 = NewDouble(DBL_PTR(_10036)->dbl - (double)4);
        }
        DeRef(_10036);
        _10036 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_17744);
        _x_inlined_put4_at_134_17744 = _10037;
        _10037 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_17744)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_17744;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_17744)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_17745);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_17745 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at137_17745); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_17744);
        _x_inlined_put4_at_134_17744 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_17745);
        _put4_1__tmp_at137_17745 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_17710);
        DeRef(_seek_1__tmp_at167_17748);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _size_ptr_17710;
        _seek_1__tmp_at167_17748 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_17747 = machine(19, _seek_1__tmp_at167_17748);
        DeRef(_seek_1__tmp_at167_17748);
        _seek_1__tmp_at167_17748 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_17709) && IS_ATOM_INT(_n_17707)) {
            _10038 = _size_17709 - _n_17707;
            if ((long)((unsigned long)_10038 +(unsigned long) HIGH_BITS) >= 0){
                _10038 = NewDouble((double)_10038);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17709)) {
                _10038 = NewDouble((double)_size_17709 - DBL_PTR(_n_17707)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17707)) {
                    _10038 = NewDouble(DBL_PTR(_size_17709)->dbl - (double)_n_17707);
                }
                else
                _10038 = NewDouble(DBL_PTR(_size_17709)->dbl - DBL_PTR(_n_17707)->dbl);
            }
        }
        if (IS_ATOM_INT(_10038)) {
            _10039 = _10038 - 4;
            if ((long)((unsigned long)_10039 +(unsigned long) HIGH_BITS) >= 0){
                _10039 = NewDouble((double)_10039);
            }
        }
        else {
            _10039 = NewDouble(DBL_PTR(_10038)->dbl - (double)4);
        }
        DeRef(_10038);
        _10038 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_17752);
        _x_inlined_put4_at_190_17752 = _10039;
        _10039 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_17752)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_17752;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_17752)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_17753);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_17753 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at193_17753); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_17752);
        _x_inlined_put4_at_190_17752 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_17753);
        _put4_1__tmp_at193_17753 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_17709) && IS_ATOM_INT(_n_17707)) {
            _10040 = _size_17709 - _n_17707;
            if ((long)((unsigned long)_10040 +(unsigned long) HIGH_BITS) >= 0){
                _10040 = NewDouble((double)_10040);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17709)) {
                _10040 = NewDouble((double)_size_17709 - DBL_PTR(_n_17707)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17707)) {
                    _10040 = NewDouble(DBL_PTR(_size_17709)->dbl - (double)_n_17707);
                }
                else
                _10040 = NewDouble(DBL_PTR(_size_17709)->dbl - DBL_PTR(_n_17707)->dbl);
            }
        }
        if (IS_ATOM_INT(_10040)) {
            _10041 = _10040 - 4;
            if ((long)((unsigned long)_10041 +(unsigned long) HIGH_BITS) >= 0){
                _10041 = NewDouble((double)_10041);
            }
        }
        else {
            _10041 = NewDouble(DBL_PTR(_10040)->dbl - (double)4);
        }
        DeRef(_10040);
        _10040 = NOVALUE;
        _0 = _addr_17711;
        if (IS_ATOM_INT(_addr_17711) && IS_ATOM_INT(_10041)) {
            _addr_17711 = _addr_17711 + _10041;
            if ((long)((unsigned long)_addr_17711 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_17711 = NewDouble((double)_addr_17711);
        }
        else {
            if (IS_ATOM_INT(_addr_17711)) {
                _addr_17711 = NewDouble((double)_addr_17711 + DBL_PTR(_10041)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10041)) {
                    _addr_17711 = NewDouble(DBL_PTR(_addr_17711)->dbl + (double)_10041);
                }
                else
                _addr_17711 = NewDouble(DBL_PTR(_addr_17711)->dbl + DBL_PTR(_10041)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_10041);
        _10041 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_17711)) {
            _10043 = _addr_17711 - 4;
            if ((long)((unsigned long)_10043 +(unsigned long) HIGH_BITS) >= 0){
                _10043 = NewDouble((double)_10043);
            }
        }
        else {
            _10043 = NewDouble(DBL_PTR(_addr_17711)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_17759);
        _pos_inlined_seek_at_241_17759 = _10043;
        _10043 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_17759);
        DeRef(_seek_1__tmp_at244_17761);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_17759;
        _seek_1__tmp_at244_17761 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_17760 = machine(19, _seek_1__tmp_at244_17761);
        DeRef(_pos_inlined_seek_at_241_17759);
        _pos_inlined_seek_at_241_17759 = NOVALUE;
        DeRef(_seek_1__tmp_at244_17761);
        _seek_1__tmp_at244_17761 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_17707)) {
            _10044 = _n_17707 + 4;
            if ((long)((unsigned long)_10044 + (unsigned long)HIGH_BITS) >= 0) 
            _10044 = NewDouble((double)_10044);
        }
        else {
            _10044 = NewDouble(DBL_PTR(_n_17707)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_17764);
        _x_inlined_put4_at_263_17764 = _10044;
        _10044 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_17764)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_17764;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_17764)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_17765);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_17765 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at266_17765); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_17764);
        _x_inlined_put4_at_263_17764 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_17765);
        _put4_1__tmp_at266_17765 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _10045 = _free_count_17712 - _i_17726;
        if ((long)((unsigned long)_10045 +(unsigned long) HIGH_BITS) >= 0){
            _10045 = NewDouble((double)_10045);
        }
        if (IS_ATOM_INT(_10045)) {
            if (_10045 == (short)_10045)
            _10046 = _10045 * 8;
            else
            _10046 = NewDouble(_10045 * (double)8);
        }
        else {
            _10046 = NewDouble(DBL_PTR(_10045)->dbl * (double)8);
        }
        DeRef(_10045);
        _10045 = NOVALUE;
        _0 = _remaining_17713;
        _remaining_17713 = _8get_bytes(_49current_db_17054, _10046);
        DeRef(_0);
        _10046 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _10048 = _i_17726 - 1;
        if (_10048 <= INT15)
        _10049 = 8 * _10048;
        else
        _10049 = NewDouble(8 * (double)_10048);
        _10048 = NOVALUE;
        if (IS_ATOM_INT(_free_list_17708) && IS_ATOM_INT(_10049)) {
            _10050 = _free_list_17708 + _10049;
            if ((long)((unsigned long)_10050 + (unsigned long)HIGH_BITS) >= 0) 
            _10050 = NewDouble((double)_10050);
        }
        else {
            if (IS_ATOM_INT(_free_list_17708)) {
                _10050 = NewDouble((double)_free_list_17708 + DBL_PTR(_10049)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10049)) {
                    _10050 = NewDouble(DBL_PTR(_free_list_17708)->dbl + (double)_10049);
                }
                else
                _10050 = NewDouble(DBL_PTR(_free_list_17708)->dbl + DBL_PTR(_10049)->dbl);
            }
        }
        DeRef(_10049);
        _10049 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_17774);
        _pos_inlined_seek_at_330_17774 = _10050;
        _10050 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_17774);
        DeRef(_seek_1__tmp_at333_17776);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_17774;
        _seek_1__tmp_at333_17776 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_17775 = machine(19, _seek_1__tmp_at333_17776);
        DeRef(_pos_inlined_seek_at_330_17774);
        _pos_inlined_seek_at_330_17774 = NOVALUE;
        DeRef(_seek_1__tmp_at333_17776);
        _seek_1__tmp_at333_17776 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_49current_db_17054, _remaining_17713); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_17780);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_17780 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_17779 = machine(19, _seek_1__tmp_at364_17780);
        DeRefi(_seek_1__tmp_at364_17780);
        _seek_1__tmp_at364_17780 = NOVALUE;

        /** 					put4(free_count-1)*/
        _10051 = _free_count_17712 - 1;
        if ((long)((unsigned long)_10051 +(unsigned long) HIGH_BITS) >= 0){
            _10051 = NewDouble((double)_10051);
        }
        DeRef(_x_inlined_put4_at_383_17783);
        _x_inlined_put4_at_383_17783 = _10051;
        _10051 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_17783)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_17783;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_17783)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_17784);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_17784 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at386_17784); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_17783);
        _x_inlined_put4_at_383_17783 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_17784);
        _put4_1__tmp_at386_17784 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17711)) {
            _10052 = _addr_17711 - 4;
            if ((long)((unsigned long)_10052 +(unsigned long) HIGH_BITS) >= 0){
                _10052 = NewDouble((double)_10052);
            }
        }
        else {
            _10052 = NewDouble(DBL_PTR(_addr_17711)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_17787);
        _pos_inlined_seek_at_420_17787 = _10052;
        _10052 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_17787);
        DeRef(_seek_1__tmp_at423_17789);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_17787;
        _seek_1__tmp_at423_17789 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_17788 = machine(19, _seek_1__tmp_at423_17789);
        DeRef(_pos_inlined_seek_at_420_17787);
        _pos_inlined_seek_at_420_17787 = NOVALUE;
        DeRef(_seek_1__tmp_at423_17789);
        _seek_1__tmp_at423_17789 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_size_17709)) {
            *poke4_addr = (unsigned long)_size_17709;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_17709)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_17791);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_17791 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at438_17791); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_17791);
        _put4_1__tmp_at438_17791 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_17707);
        DeRef(_free_list_17708);
        DeRef(_size_17709);
        DeRef(_size_ptr_17710);
        DeRef(_remaining_17713);
        return _addr_17711;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_17710;
        if (IS_ATOM_INT(_size_ptr_17710)) {
            _size_ptr_17710 = _size_ptr_17710 + 8;
            if ((long)((unsigned long)_size_ptr_17710 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_17710 = NewDouble((double)_size_ptr_17710);
        }
        else {
            _size_ptr_17710 = NewDouble(DBL_PTR(_size_ptr_17710)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_17726 = _i_17726 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_17795);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_17795 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_17794 = machine(19, _seek_1__tmp_at490_17795);
    DeRefi(_seek_1__tmp_at490_17795);
    _seek_1__tmp_at490_17795 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_17707)) {
        _10054 = _n_17707 + 4;
        if ((long)((unsigned long)_10054 + (unsigned long)HIGH_BITS) >= 0) 
        _10054 = NewDouble((double)_10054);
    }
    else {
        _10054 = NewDouble(DBL_PTR(_n_17707)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_17798);
    _x_inlined_put4_at_509_17798 = _10054;
    _10054 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_17798)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_17798;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_17798)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_17799);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_17799 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at512_17799); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_17798);
    _x_inlined_put4_at_509_17798 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_17799);
    _put4_1__tmp_at512_17799 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_17801);
    _where_inlined_where_at_542_17801 = machine(20, _49current_db_17054);
    DeRef(_n_17707);
    DeRef(_free_list_17708);
    DeRef(_size_17709);
    DeRef(_size_ptr_17710);
    DeRef(_addr_17711);
    DeRef(_remaining_17713);
    return _where_inlined_where_at_542_17801;
    ;
}


void _49db_free(int _p_17804)
{
    int _psize_17805 = NOVALUE;
    int _i_17806 = NOVALUE;
    int _size_17807 = NOVALUE;
    int _addr_17808 = NOVALUE;
    int _free_list_17809 = NOVALUE;
    int _free_list_space_17810 = NOVALUE;
    int _new_space_17811 = NOVALUE;
    int _to_be_freed_17812 = NOVALUE;
    int _prev_addr_17813 = NOVALUE;
    int _prev_size_17814 = NOVALUE;
    int _free_count_17815 = NOVALUE;
    int _remaining_17816 = NOVALUE;
    int _seek_1__tmp_at11_17821 = NOVALUE;
    int _seek_inlined_seek_at_11_17820 = NOVALUE;
    int _pos_inlined_seek_at_8_17819 = NOVALUE;
    int _seek_1__tmp_at33_17825 = NOVALUE;
    int _seek_inlined_seek_at_33_17824 = NOVALUE;
    int _seek_1__tmp_at69_17832 = NOVALUE;
    int _seek_inlined_seek_at_69_17831 = NOVALUE;
    int _pos_inlined_seek_at_66_17830 = NOVALUE;
    int _seek_1__tmp_at133_17845 = NOVALUE;
    int _seek_inlined_seek_at_133_17844 = NOVALUE;
    int _seek_1__tmp_at157_17849 = NOVALUE;
    int _seek_inlined_seek_at_157_17848 = NOVALUE;
    int _put4_1__tmp_at172_17851 = NOVALUE;
    int _seek_1__tmp_at202_17854 = NOVALUE;
    int _seek_inlined_seek_at_202_17853 = NOVALUE;
    int _seek_1__tmp_at234_17859 = NOVALUE;
    int _seek_inlined_seek_at_234_17858 = NOVALUE;
    int _s_inlined_putn_at_274_17865 = NOVALUE;
    int _seek_1__tmp_at297_17868 = NOVALUE;
    int _seek_inlined_seek_at_297_17867 = NOVALUE;
    int _seek_1__tmp_at430_17889 = NOVALUE;
    int _seek_inlined_seek_at_430_17888 = NOVALUE;
    int _pos_inlined_seek_at_427_17887 = NOVALUE;
    int _put4_1__tmp_at482_17899 = NOVALUE;
    int _x_inlined_put4_at_479_17898 = NOVALUE;
    int _seek_1__tmp_at523_17905 = NOVALUE;
    int _seek_inlined_seek_at_523_17904 = NOVALUE;
    int _pos_inlined_seek_at_520_17903 = NOVALUE;
    int _seek_1__tmp_at574_17915 = NOVALUE;
    int _seek_inlined_seek_at_574_17914 = NOVALUE;
    int _pos_inlined_seek_at_571_17913 = NOVALUE;
    int _seek_1__tmp_at611_17920 = NOVALUE;
    int _seek_inlined_seek_at_611_17919 = NOVALUE;
    int _put4_1__tmp_at626_17922 = NOVALUE;
    int _put4_1__tmp_at664_17927 = NOVALUE;
    int _x_inlined_put4_at_661_17926 = NOVALUE;
    int _seek_1__tmp_at737_17939 = NOVALUE;
    int _seek_inlined_seek_at_737_17938 = NOVALUE;
    int _pos_inlined_seek_at_734_17937 = NOVALUE;
    int _put4_1__tmp_at752_17941 = NOVALUE;
    int _put4_1__tmp_at789_17945 = NOVALUE;
    int _x_inlined_put4_at_786_17944 = NOVALUE;
    int _seek_1__tmp_at837_17953 = NOVALUE;
    int _seek_inlined_seek_at_837_17952 = NOVALUE;
    int _pos_inlined_seek_at_834_17951 = NOVALUE;
    int _seek_1__tmp_at883_17961 = NOVALUE;
    int _seek_inlined_seek_at_883_17960 = NOVALUE;
    int _put4_1__tmp_at898_17963 = NOVALUE;
    int _seek_1__tmp_at943_17970 = NOVALUE;
    int _seek_inlined_seek_at_943_17969 = NOVALUE;
    int _pos_inlined_seek_at_940_17968 = NOVALUE;
    int _put4_1__tmp_at958_17972 = NOVALUE;
    int _put4_1__tmp_at986_17974 = NOVALUE;
    int _10122 = NOVALUE;
    int _10121 = NOVALUE;
    int _10120 = NOVALUE;
    int _10117 = NOVALUE;
    int _10116 = NOVALUE;
    int _10115 = NOVALUE;
    int _10114 = NOVALUE;
    int _10113 = NOVALUE;
    int _10112 = NOVALUE;
    int _10111 = NOVALUE;
    int _10110 = NOVALUE;
    int _10109 = NOVALUE;
    int _10108 = NOVALUE;
    int _10107 = NOVALUE;
    int _10106 = NOVALUE;
    int _10105 = NOVALUE;
    int _10104 = NOVALUE;
    int _10103 = NOVALUE;
    int _10101 = NOVALUE;
    int _10100 = NOVALUE;
    int _10099 = NOVALUE;
    int _10097 = NOVALUE;
    int _10096 = NOVALUE;
    int _10095 = NOVALUE;
    int _10094 = NOVALUE;
    int _10093 = NOVALUE;
    int _10092 = NOVALUE;
    int _10091 = NOVALUE;
    int _10090 = NOVALUE;
    int _10089 = NOVALUE;
    int _10088 = NOVALUE;
    int _10087 = NOVALUE;
    int _10086 = NOVALUE;
    int _10085 = NOVALUE;
    int _10084 = NOVALUE;
    int _10083 = NOVALUE;
    int _10082 = NOVALUE;
    int _10081 = NOVALUE;
    int _10080 = NOVALUE;
    int _10074 = NOVALUE;
    int _10073 = NOVALUE;
    int _10072 = NOVALUE;
    int _10070 = NOVALUE;
    int _10066 = NOVALUE;
    int _10065 = NOVALUE;
    int _10063 = NOVALUE;
    int _10062 = NOVALUE;
    int _10060 = NOVALUE;
    int _10059 = NOVALUE;
    int _10055 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_17804)) {
        _10055 = _p_17804 - 4;
        if ((long)((unsigned long)_10055 +(unsigned long) HIGH_BITS) >= 0){
            _10055 = NewDouble((double)_10055);
        }
    }
    else {
        _10055 = NewDouble(DBL_PTR(_p_17804)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_17819);
    _pos_inlined_seek_at_8_17819 = _10055;
    _10055 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17819);
    DeRef(_seek_1__tmp_at11_17821);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_17819;
    _seek_1__tmp_at11_17821 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17820 = machine(19, _seek_1__tmp_at11_17821);
    DeRef(_pos_inlined_seek_at_8_17819);
    _pos_inlined_seek_at_8_17819 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17821);
    _seek_1__tmp_at11_17821 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_17805;
    _psize_17805 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_17825);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_17825 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_17824 = machine(19, _seek_1__tmp_at33_17825);
    DeRefi(_seek_1__tmp_at33_17825);
    _seek_1__tmp_at33_17825 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17815 = _49get4();
    if (!IS_ATOM_INT(_free_count_17815)) {
        _1 = (long)(DBL_PTR(_free_count_17815)->dbl);
        DeRefDS(_free_count_17815);
        _free_count_17815 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_17809;
    _free_list_17809 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_17809)) {
        _10059 = _free_list_17809 - 4;
        if ((long)((unsigned long)_10059 +(unsigned long) HIGH_BITS) >= 0){
            _10059 = NewDouble((double)_10059);
        }
    }
    else {
        _10059 = NewDouble(DBL_PTR(_free_list_17809)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_17830);
    _pos_inlined_seek_at_66_17830 = _10059;
    _10059 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_17830);
    DeRef(_seek_1__tmp_at69_17832);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_17830;
    _seek_1__tmp_at69_17832 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_17831 = machine(19, _seek_1__tmp_at69_17832);
    DeRef(_pos_inlined_seek_at_66_17830);
    _pos_inlined_seek_at_66_17830 = NOVALUE;
    DeRef(_seek_1__tmp_at69_17832);
    _seek_1__tmp_at69_17832 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _10060 = _49get4();
    DeRef(_free_list_space_17810);
    if (IS_ATOM_INT(_10060)) {
        _free_list_space_17810 = _10060 - 4;
        if ((long)((unsigned long)_free_list_space_17810 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_17810 = NewDouble((double)_free_list_space_17810);
        }
    }
    else {
        _free_list_space_17810 = binary_op(MINUS, _10060, 4);
    }
    DeRef(_10060);
    _10060 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _10062 = _free_count_17815 + 1;
    if (_10062 > MAXINT){
        _10062 = NewDouble((double)_10062);
    }
    if (IS_ATOM_INT(_10062)) {
        if (_10062 <= INT15 && _10062 >= -INT15)
        _10063 = 8 * _10062;
        else
        _10063 = NewDouble(8 * (double)_10062);
    }
    else {
        _10063 = NewDouble((double)8 * DBL_PTR(_10062)->dbl);
    }
    DeRef(_10062);
    _10062 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_17810, _10063)){
        DeRef(_10063);
        _10063 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_10063);
    _10063 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_17810)) {
        if (_free_list_space_17810 & 1) {
            _10065 = NewDouble((_free_list_space_17810 >> 1) + 0.5);
        }
        else
        _10065 = _free_list_space_17810 >> 1;
    }
    else {
        _10065 = binary_op(DIVIDE, _free_list_space_17810, 2);
    }
    if (IS_ATOM_INT(_free_list_space_17810) && IS_ATOM_INT(_10065)) {
        _10066 = _free_list_space_17810 + _10065;
        if ((long)((unsigned long)_10066 + (unsigned long)HIGH_BITS) >= 0) 
        _10066 = NewDouble((double)_10066);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_17810)) {
            _10066 = NewDouble((double)_free_list_space_17810 + DBL_PTR(_10065)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10065)) {
                _10066 = NewDouble(DBL_PTR(_free_list_space_17810)->dbl + (double)_10065);
            }
            else
            _10066 = NewDouble(DBL_PTR(_free_list_space_17810)->dbl + DBL_PTR(_10065)->dbl);
        }
    }
    DeRef(_10065);
    _10065 = NOVALUE;
    DeRef(_new_space_17811);
    if (IS_ATOM_INT(_10066))
    _new_space_17811 = e_floor(_10066);
    else
    _new_space_17811 = unary_op(FLOOR, _10066);
    DeRef(_10066);
    _10066 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_17809);
    DeRef(_to_be_freed_17812);
    _to_be_freed_17812 = _free_list_17809;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_17811);
    _0 = _free_list_17809;
    _free_list_17809 = _49db_allocate(_new_space_17811);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_17845);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_17845 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_17844 = machine(19, _seek_1__tmp_at133_17845);
    DeRefi(_seek_1__tmp_at133_17845);
    _seek_1__tmp_at133_17845 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_17815 = _49get4();
    if (!IS_ATOM_INT(_free_count_17815)) {
        _1 = (long)(DBL_PTR(_free_count_17815)->dbl);
        DeRefDS(_free_count_17815);
        _free_count_17815 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_17849);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_17849 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_17848 = machine(19, _seek_1__tmp_at157_17849);
    DeRefi(_seek_1__tmp_at157_17849);
    _seek_1__tmp_at157_17849 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_free_list_17809)) {
        *poke4_addr = (unsigned long)_free_list_17809;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_17809)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_17851);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_17851 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at172_17851); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_17851);
    _put4_1__tmp_at172_17851 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_17812);
    DeRef(_seek_1__tmp_at202_17854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _to_be_freed_17812;
    _seek_1__tmp_at202_17854 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_17853 = machine(19, _seek_1__tmp_at202_17854);
    DeRef(_seek_1__tmp_at202_17854);
    _seek_1__tmp_at202_17854 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_17815 <= INT15 && _free_count_17815 >= -INT15)
    _10070 = 8 * _free_count_17815;
    else
    _10070 = NewDouble(8 * (double)_free_count_17815);
    _0 = _remaining_17816;
    _remaining_17816 = _8get_bytes(_49current_db_17054, _10070);
    DeRef(_0);
    _10070 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17809);
    DeRef(_seek_1__tmp_at234_17859);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _free_list_17809;
    _seek_1__tmp_at234_17859 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_17858 = machine(19, _seek_1__tmp_at234_17859);
    DeRef(_seek_1__tmp_at234_17859);
    _seek_1__tmp_at234_17859 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_17816); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_17816)){
            _10072 = SEQ_PTR(_remaining_17816)->length;
    }
    else {
        _10072 = 1;
    }
    if (IS_ATOM_INT(_new_space_17811)) {
        _10073 = _new_space_17811 - _10072;
    }
    else {
        _10073 = NewDouble(DBL_PTR(_new_space_17811)->dbl - (double)_10072);
    }
    _10072 = NOVALUE;
    _10074 = Repeat(0, _10073);
    DeRef(_10073);
    _10073 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_17865);
    _s_inlined_putn_at_274_17865 = _10074;
    _10074 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_274_17865); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_17865);
    _s_inlined_putn_at_274_17865 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17809);
    DeRef(_seek_1__tmp_at297_17868);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _free_list_17809;
    _seek_1__tmp_at297_17868 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_17867 = machine(19, _seek_1__tmp_at297_17868);
    DeRef(_seek_1__tmp_at297_17868);
    _seek_1__tmp_at297_17868 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_17811);
    _new_space_17811 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_17806);
    _i_17806 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_17813);
    _prev_addr_17813 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_17814);
    _prev_size_17814 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_17806, _free_count_17815)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_17808;
    _addr_17808 = _49get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_17807;
    _size_17807 = _49get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_17804, _addr_17808)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_17808);
    DeRef(_prev_addr_17813);
    _prev_addr_17813 = _addr_17808;

    /** 		prev_size = size*/
    Ref(_size_17807);
    DeRef(_prev_size_17814);
    _prev_size_17814 = _size_17807;

    /** 		i += 1*/
    _0 = _i_17806;
    if (IS_ATOM_INT(_i_17806)) {
        _i_17806 = _i_17806 + 1;
        if (_i_17806 > MAXINT){
            _i_17806 = NewDouble((double)_i_17806);
        }
    }
    else
    _i_17806 = binary_op(PLUS, 1, _i_17806);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_17806)) {
        _10080 = (_i_17806 > 1);
    }
    else {
        _10080 = (DBL_PTR(_i_17806)->dbl > (double)1);
    }
    if (_10080 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_17813) && IS_ATOM_INT(_prev_size_17814)) {
        _10082 = _prev_addr_17813 + _prev_size_17814;
        if ((long)((unsigned long)_10082 + (unsigned long)HIGH_BITS) >= 0) 
        _10082 = NewDouble((double)_10082);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_17813)) {
            _10082 = NewDouble((double)_prev_addr_17813 + DBL_PTR(_prev_size_17814)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_17814)) {
                _10082 = NewDouble(DBL_PTR(_prev_addr_17813)->dbl + (double)_prev_size_17814);
            }
            else
            _10082 = NewDouble(DBL_PTR(_prev_addr_17813)->dbl + DBL_PTR(_prev_size_17814)->dbl);
        }
    }
    if (IS_ATOM_INT(_10082) && IS_ATOM_INT(_p_17804)) {
        _10083 = (_10082 == _p_17804);
    }
    else {
        if (IS_ATOM_INT(_10082)) {
            _10083 = ((double)_10082 == DBL_PTR(_p_17804)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_17804)) {
                _10083 = (DBL_PTR(_10082)->dbl == (double)_p_17804);
            }
            else
            _10083 = (DBL_PTR(_10082)->dbl == DBL_PTR(_p_17804)->dbl);
        }
    }
    DeRef(_10082);
    _10082 = NOVALUE;
    if (_10083 == 0)
    {
        DeRef(_10083);
        _10083 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_10083);
        _10083 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10084 = _i_17806 - 2;
        if ((long)((unsigned long)_10084 +(unsigned long) HIGH_BITS) >= 0){
            _10084 = NewDouble((double)_10084);
        }
    }
    else {
        _10084 = NewDouble(DBL_PTR(_i_17806)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_10084)) {
        if (_10084 == (short)_10084)
        _10085 = _10084 * 8;
        else
        _10085 = NewDouble(_10084 * (double)8);
    }
    else {
        _10085 = NewDouble(DBL_PTR(_10084)->dbl * (double)8);
    }
    DeRef(_10084);
    _10084 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10085)) {
        _10086 = _free_list_17809 + _10085;
        if ((long)((unsigned long)_10086 + (unsigned long)HIGH_BITS) >= 0) 
        _10086 = NewDouble((double)_10086);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10086 = NewDouble((double)_free_list_17809 + DBL_PTR(_10085)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10085)) {
                _10086 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10085);
            }
            else
            _10086 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10085)->dbl);
        }
    }
    DeRef(_10085);
    _10085 = NOVALUE;
    if (IS_ATOM_INT(_10086)) {
        _10087 = _10086 + 4;
        if ((long)((unsigned long)_10087 + (unsigned long)HIGH_BITS) >= 0) 
        _10087 = NewDouble((double)_10087);
    }
    else {
        _10087 = NewDouble(DBL_PTR(_10086)->dbl + (double)4);
    }
    DeRef(_10086);
    _10086 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_17887);
    _pos_inlined_seek_at_427_17887 = _10087;
    _10087 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_17887);
    DeRef(_seek_1__tmp_at430_17889);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_17887;
    _seek_1__tmp_at430_17889 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_17888 = machine(19, _seek_1__tmp_at430_17889);
    DeRef(_pos_inlined_seek_at_427_17887);
    _pos_inlined_seek_at_427_17887 = NOVALUE;
    DeRef(_seek_1__tmp_at430_17889);
    _seek_1__tmp_at430_17889 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17806)) {
        _10088 = (_i_17806 < _free_count_17815);
    }
    else {
        _10088 = (DBL_PTR(_i_17806)->dbl < (double)_free_count_17815);
    }
    if (_10088 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_17804) && IS_ATOM_INT(_psize_17805)) {
        _10090 = _p_17804 + _psize_17805;
        if ((long)((unsigned long)_10090 + (unsigned long)HIGH_BITS) >= 0) 
        _10090 = NewDouble((double)_10090);
    }
    else {
        if (IS_ATOM_INT(_p_17804)) {
            _10090 = NewDouble((double)_p_17804 + DBL_PTR(_psize_17805)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17805)) {
                _10090 = NewDouble(DBL_PTR(_p_17804)->dbl + (double)_psize_17805);
            }
            else
            _10090 = NewDouble(DBL_PTR(_p_17804)->dbl + DBL_PTR(_psize_17805)->dbl);
        }
    }
    if (IS_ATOM_INT(_10090) && IS_ATOM_INT(_addr_17808)) {
        _10091 = (_10090 == _addr_17808);
    }
    else {
        if (IS_ATOM_INT(_10090)) {
            _10091 = ((double)_10090 == DBL_PTR(_addr_17808)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17808)) {
                _10091 = (DBL_PTR(_10090)->dbl == (double)_addr_17808);
            }
            else
            _10091 = (DBL_PTR(_10090)->dbl == DBL_PTR(_addr_17808)->dbl);
        }
    }
    DeRef(_10090);
    _10090 = NOVALUE;
    if (_10091 == 0)
    {
        DeRef(_10091);
        _10091 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_10091);
        _10091 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17814) && IS_ATOM_INT(_psize_17805)) {
        _10092 = _prev_size_17814 + _psize_17805;
        if ((long)((unsigned long)_10092 + (unsigned long)HIGH_BITS) >= 0) 
        _10092 = NewDouble((double)_10092);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17814)) {
            _10092 = NewDouble((double)_prev_size_17814 + DBL_PTR(_psize_17805)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17805)) {
                _10092 = NewDouble(DBL_PTR(_prev_size_17814)->dbl + (double)_psize_17805);
            }
            else
            _10092 = NewDouble(DBL_PTR(_prev_size_17814)->dbl + DBL_PTR(_psize_17805)->dbl);
        }
    }
    if (IS_ATOM_INT(_10092) && IS_ATOM_INT(_size_17807)) {
        _10093 = _10092 + _size_17807;
        if ((long)((unsigned long)_10093 + (unsigned long)HIGH_BITS) >= 0) 
        _10093 = NewDouble((double)_10093);
    }
    else {
        if (IS_ATOM_INT(_10092)) {
            _10093 = NewDouble((double)_10092 + DBL_PTR(_size_17807)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17807)) {
                _10093 = NewDouble(DBL_PTR(_10092)->dbl + (double)_size_17807);
            }
            else
            _10093 = NewDouble(DBL_PTR(_10092)->dbl + DBL_PTR(_size_17807)->dbl);
        }
    }
    DeRef(_10092);
    _10092 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_17898);
    _x_inlined_put4_at_479_17898 = _10093;
    _10093 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_17898)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_17898;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_17898)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_17899);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_17899 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at482_17899); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_17898);
    _x_inlined_put4_at_479_17898 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_17899);
    _put4_1__tmp_at482_17899 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        if (_i_17806 == (short)_i_17806)
        _10094 = _i_17806 * 8;
        else
        _10094 = NewDouble(_i_17806 * (double)8);
    }
    else {
        _10094 = NewDouble(DBL_PTR(_i_17806)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10094)) {
        _10095 = _free_list_17809 + _10094;
        if ((long)((unsigned long)_10095 + (unsigned long)HIGH_BITS) >= 0) 
        _10095 = NewDouble((double)_10095);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10095 = NewDouble((double)_free_list_17809 + DBL_PTR(_10094)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10094)) {
                _10095 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10094);
            }
            else
            _10095 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10094)->dbl);
        }
    }
    DeRef(_10094);
    _10094 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_17903);
    _pos_inlined_seek_at_520_17903 = _10095;
    _10095 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_17903);
    DeRef(_seek_1__tmp_at523_17905);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_17903;
    _seek_1__tmp_at523_17905 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_17904 = machine(19, _seek_1__tmp_at523_17905);
    DeRef(_pos_inlined_seek_at_520_17903);
    _pos_inlined_seek_at_520_17903 = NOVALUE;
    DeRef(_seek_1__tmp_at523_17905);
    _seek_1__tmp_at523_17905 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10096 = _free_count_17815 - _i_17806;
        if ((long)((unsigned long)_10096 +(unsigned long) HIGH_BITS) >= 0){
            _10096 = NewDouble((double)_10096);
        }
    }
    else {
        _10096 = NewDouble((double)_free_count_17815 - DBL_PTR(_i_17806)->dbl);
    }
    if (IS_ATOM_INT(_10096)) {
        if (_10096 == (short)_10096)
        _10097 = _10096 * 8;
        else
        _10097 = NewDouble(_10096 * (double)8);
    }
    else {
        _10097 = NewDouble(DBL_PTR(_10096)->dbl * (double)8);
    }
    DeRef(_10096);
    _10096 = NOVALUE;
    _0 = _remaining_17816;
    _remaining_17816 = _8get_bytes(_49current_db_17054, _10097);
    DeRef(_0);
    _10097 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10099 = _i_17806 - 1;
        if ((long)((unsigned long)_10099 +(unsigned long) HIGH_BITS) >= 0){
            _10099 = NewDouble((double)_10099);
        }
    }
    else {
        _10099 = NewDouble(DBL_PTR(_i_17806)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10099)) {
        if (_10099 == (short)_10099)
        _10100 = _10099 * 8;
        else
        _10100 = NewDouble(_10099 * (double)8);
    }
    else {
        _10100 = NewDouble(DBL_PTR(_10099)->dbl * (double)8);
    }
    DeRef(_10099);
    _10099 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10100)) {
        _10101 = _free_list_17809 + _10100;
        if ((long)((unsigned long)_10101 + (unsigned long)HIGH_BITS) >= 0) 
        _10101 = NewDouble((double)_10101);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10101 = NewDouble((double)_free_list_17809 + DBL_PTR(_10100)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10100)) {
                _10101 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10100);
            }
            else
            _10101 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10100)->dbl);
        }
    }
    DeRef(_10100);
    _10100 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_17913);
    _pos_inlined_seek_at_571_17913 = _10101;
    _10101 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_17913);
    DeRef(_seek_1__tmp_at574_17915);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_17913;
    _seek_1__tmp_at574_17915 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_17914 = machine(19, _seek_1__tmp_at574_17915);
    DeRef(_pos_inlined_seek_at_571_17913);
    _pos_inlined_seek_at_571_17913 = NOVALUE;
    DeRef(_seek_1__tmp_at574_17915);
    _seek_1__tmp_at574_17915 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_17816); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_17815 = _free_count_17815 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_17920);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_17920 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_17919 = machine(19, _seek_1__tmp_at611_17920);
    DeRefi(_seek_1__tmp_at611_17920);
    _seek_1__tmp_at611_17920 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17815;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_17922);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_17922 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at626_17922); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_17922);
    _put4_1__tmp_at626_17922 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17814) && IS_ATOM_INT(_psize_17805)) {
        _10103 = _prev_size_17814 + _psize_17805;
        if ((long)((unsigned long)_10103 + (unsigned long)HIGH_BITS) >= 0) 
        _10103 = NewDouble((double)_10103);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17814)) {
            _10103 = NewDouble((double)_prev_size_17814 + DBL_PTR(_psize_17805)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17805)) {
                _10103 = NewDouble(DBL_PTR(_prev_size_17814)->dbl + (double)_psize_17805);
            }
            else
            _10103 = NewDouble(DBL_PTR(_prev_size_17814)->dbl + DBL_PTR(_psize_17805)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_17926);
    _x_inlined_put4_at_661_17926 = _10103;
    _10103 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_17926)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_17926;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_17926)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_17927);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_17927 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at664_17927); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_17926);
    _x_inlined_put4_at_661_17926 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_17927);
    _put4_1__tmp_at664_17927 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17806)) {
        _10104 = (_i_17806 < _free_count_17815);
    }
    else {
        _10104 = (DBL_PTR(_i_17806)->dbl < (double)_free_count_17815);
    }
    if (_10104 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_17804) && IS_ATOM_INT(_psize_17805)) {
        _10106 = _p_17804 + _psize_17805;
        if ((long)((unsigned long)_10106 + (unsigned long)HIGH_BITS) >= 0) 
        _10106 = NewDouble((double)_10106);
    }
    else {
        if (IS_ATOM_INT(_p_17804)) {
            _10106 = NewDouble((double)_p_17804 + DBL_PTR(_psize_17805)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17805)) {
                _10106 = NewDouble(DBL_PTR(_p_17804)->dbl + (double)_psize_17805);
            }
            else
            _10106 = NewDouble(DBL_PTR(_p_17804)->dbl + DBL_PTR(_psize_17805)->dbl);
        }
    }
    if (IS_ATOM_INT(_10106) && IS_ATOM_INT(_addr_17808)) {
        _10107 = (_10106 == _addr_17808);
    }
    else {
        if (IS_ATOM_INT(_10106)) {
            _10107 = ((double)_10106 == DBL_PTR(_addr_17808)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17808)) {
                _10107 = (DBL_PTR(_10106)->dbl == (double)_addr_17808);
            }
            else
            _10107 = (DBL_PTR(_10106)->dbl == DBL_PTR(_addr_17808)->dbl);
        }
    }
    DeRef(_10106);
    _10106 = NOVALUE;
    if (_10107 == 0)
    {
        DeRef(_10107);
        _10107 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_10107);
        _10107 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10108 = _i_17806 - 1;
        if ((long)((unsigned long)_10108 +(unsigned long) HIGH_BITS) >= 0){
            _10108 = NewDouble((double)_10108);
        }
    }
    else {
        _10108 = NewDouble(DBL_PTR(_i_17806)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10108)) {
        if (_10108 == (short)_10108)
        _10109 = _10108 * 8;
        else
        _10109 = NewDouble(_10108 * (double)8);
    }
    else {
        _10109 = NewDouble(DBL_PTR(_10108)->dbl * (double)8);
    }
    DeRef(_10108);
    _10108 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10109)) {
        _10110 = _free_list_17809 + _10109;
        if ((long)((unsigned long)_10110 + (unsigned long)HIGH_BITS) >= 0) 
        _10110 = NewDouble((double)_10110);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10110 = NewDouble((double)_free_list_17809 + DBL_PTR(_10109)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10109)) {
                _10110 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10109);
            }
            else
            _10110 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10109)->dbl);
        }
    }
    DeRef(_10109);
    _10109 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_17937);
    _pos_inlined_seek_at_734_17937 = _10110;
    _10110 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_17937);
    DeRef(_seek_1__tmp_at737_17939);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_17937;
    _seek_1__tmp_at737_17939 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_17938 = machine(19, _seek_1__tmp_at737_17939);
    DeRef(_pos_inlined_seek_at_734_17937);
    _pos_inlined_seek_at_734_17937 = NOVALUE;
    DeRef(_seek_1__tmp_at737_17939);
    _seek_1__tmp_at737_17939 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_p_17804)) {
        *poke4_addr = (unsigned long)_p_17804;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17804)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_17941);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_17941 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at752_17941); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_17941);
    _put4_1__tmp_at752_17941 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_17805) && IS_ATOM_INT(_size_17807)) {
        _10111 = _psize_17805 + _size_17807;
        if ((long)((unsigned long)_10111 + (unsigned long)HIGH_BITS) >= 0) 
        _10111 = NewDouble((double)_10111);
    }
    else {
        if (IS_ATOM_INT(_psize_17805)) {
            _10111 = NewDouble((double)_psize_17805 + DBL_PTR(_size_17807)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17807)) {
                _10111 = NewDouble(DBL_PTR(_psize_17805)->dbl + (double)_size_17807);
            }
            else
            _10111 = NewDouble(DBL_PTR(_psize_17805)->dbl + DBL_PTR(_size_17807)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_17944);
    _x_inlined_put4_at_786_17944 = _10111;
    _10111 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_17944)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_17944;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_17944)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_17945);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_17945 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at789_17945); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_17944);
    _x_inlined_put4_at_786_17944 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_17945);
    _put4_1__tmp_at789_17945 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10112 = _i_17806 - 1;
        if ((long)((unsigned long)_10112 +(unsigned long) HIGH_BITS) >= 0){
            _10112 = NewDouble((double)_10112);
        }
    }
    else {
        _10112 = NewDouble(DBL_PTR(_i_17806)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10112)) {
        if (_10112 == (short)_10112)
        _10113 = _10112 * 8;
        else
        _10113 = NewDouble(_10112 * (double)8);
    }
    else {
        _10113 = NewDouble(DBL_PTR(_10112)->dbl * (double)8);
    }
    DeRef(_10112);
    _10112 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10113)) {
        _10114 = _free_list_17809 + _10113;
        if ((long)((unsigned long)_10114 + (unsigned long)HIGH_BITS) >= 0) 
        _10114 = NewDouble((double)_10114);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10114 = NewDouble((double)_free_list_17809 + DBL_PTR(_10113)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10113)) {
                _10114 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10113);
            }
            else
            _10114 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10113)->dbl);
        }
    }
    DeRef(_10113);
    _10113 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_17951);
    _pos_inlined_seek_at_834_17951 = _10114;
    _10114 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_17951);
    DeRef(_seek_1__tmp_at837_17953);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_17951;
    _seek_1__tmp_at837_17953 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_17952 = machine(19, _seek_1__tmp_at837_17953);
    DeRef(_pos_inlined_seek_at_834_17951);
    _pos_inlined_seek_at_834_17951 = NOVALUE;
    DeRef(_seek_1__tmp_at837_17953);
    _seek_1__tmp_at837_17953 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10115 = _free_count_17815 - _i_17806;
        if ((long)((unsigned long)_10115 +(unsigned long) HIGH_BITS) >= 0){
            _10115 = NewDouble((double)_10115);
        }
    }
    else {
        _10115 = NewDouble((double)_free_count_17815 - DBL_PTR(_i_17806)->dbl);
    }
    if (IS_ATOM_INT(_10115)) {
        _10116 = _10115 + 1;
        if (_10116 > MAXINT){
            _10116 = NewDouble((double)_10116);
        }
    }
    else
    _10116 = binary_op(PLUS, 1, _10115);
    DeRef(_10115);
    _10115 = NOVALUE;
    if (IS_ATOM_INT(_10116)) {
        if (_10116 == (short)_10116)
        _10117 = _10116 * 8;
        else
        _10117 = NewDouble(_10116 * (double)8);
    }
    else {
        _10117 = NewDouble(DBL_PTR(_10116)->dbl * (double)8);
    }
    DeRef(_10116);
    _10116 = NOVALUE;
    _0 = _remaining_17816;
    _remaining_17816 = _8get_bytes(_49current_db_17054, _10117);
    DeRef(_0);
    _10117 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_17815 = _free_count_17815 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_17961);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_17961 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_17960 = machine(19, _seek_1__tmp_at883_17961);
    DeRefi(_seek_1__tmp_at883_17961);
    _seek_1__tmp_at883_17961 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17815;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_17963);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_17963 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at898_17963); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_17963);
    _put4_1__tmp_at898_17963 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17806)) {
        _10120 = _i_17806 - 1;
        if ((long)((unsigned long)_10120 +(unsigned long) HIGH_BITS) >= 0){
            _10120 = NewDouble((double)_10120);
        }
    }
    else {
        _10120 = NewDouble(DBL_PTR(_i_17806)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10120)) {
        if (_10120 == (short)_10120)
        _10121 = _10120 * 8;
        else
        _10121 = NewDouble(_10120 * (double)8);
    }
    else {
        _10121 = NewDouble(DBL_PTR(_10120)->dbl * (double)8);
    }
    DeRef(_10120);
    _10120 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17809) && IS_ATOM_INT(_10121)) {
        _10122 = _free_list_17809 + _10121;
        if ((long)((unsigned long)_10122 + (unsigned long)HIGH_BITS) >= 0) 
        _10122 = NewDouble((double)_10122);
    }
    else {
        if (IS_ATOM_INT(_free_list_17809)) {
            _10122 = NewDouble((double)_free_list_17809 + DBL_PTR(_10121)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10121)) {
                _10122 = NewDouble(DBL_PTR(_free_list_17809)->dbl + (double)_10121);
            }
            else
            _10122 = NewDouble(DBL_PTR(_free_list_17809)->dbl + DBL_PTR(_10121)->dbl);
        }
    }
    DeRef(_10121);
    _10121 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_17968);
    _pos_inlined_seek_at_940_17968 = _10122;
    _10122 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_17968);
    DeRef(_seek_1__tmp_at943_17970);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_17968;
    _seek_1__tmp_at943_17970 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_17969 = machine(19, _seek_1__tmp_at943_17970);
    DeRef(_pos_inlined_seek_at_940_17968);
    _pos_inlined_seek_at_940_17968 = NOVALUE;
    DeRef(_seek_1__tmp_at943_17970);
    _seek_1__tmp_at943_17970 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_p_17804)) {
        *poke4_addr = (unsigned long)_p_17804;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17804)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_17972);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_17972 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at958_17972); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_17972);
    _put4_1__tmp_at958_17972 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_psize_17805)) {
        *poke4_addr = (unsigned long)_psize_17805;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_17805)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_17974);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_17974 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at986_17974); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_17974);
    _put4_1__tmp_at986_17974 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_17816); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_17811 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_17811) && DBL_PTR(_new_space_17811)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_17812);
    _49db_free(_to_be_freed_17812);
L17: 

    /** end procedure*/
    DeRef(_p_17804);
    DeRef(_psize_17805);
    DeRef(_i_17806);
    DeRef(_size_17807);
    DeRef(_addr_17808);
    DeRef(_free_list_17809);
    DeRef(_free_list_space_17810);
    DeRef(_new_space_17811);
    DeRef(_to_be_freed_17812);
    DeRef(_prev_addr_17813);
    DeRef(_prev_size_17814);
    DeRef(_remaining_17816);
    DeRef(_10080);
    _10080 = NOVALUE;
    DeRef(_10088);
    _10088 = NOVALUE;
    DeRef(_10104);
    _10104 = NOVALUE;
    return;
    ;
}


void _49save_keys()
{
    int _k_17979 = NOVALUE;
    int _10129 = NOVALUE;
    int _10125 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _49current_table_pos_17055, 0)){
        goto L1; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_49current_table_pos_17055);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _49current_table_pos_17055;
    _10125 = MAKE_SEQ(_1);
    _k_17979 = find_from(_10125, _49cache_index_17063, 1);
    DeRefDS(_10125);
    _10125 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_17979 == 0)
    goto L2; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_49key_pointers_17061);
    _2 = (int)SEQ_PTR(_49key_cache_17062);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _49key_cache_17062 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_17979);
    _1 = *(int *)_2;
    *(int *)_2 = _49key_pointers_17061;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_49key_pointers_17061);
    Append(&_49key_cache_17062, _49key_cache_17062, _49key_pointers_17061);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_49current_table_pos_17055);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _49current_table_pos_17055;
    _10129 = MAKE_SEQ(_1);
    RefDS(_10129);
    Append(&_49cache_index_17063, _49cache_index_17063, _10129);
    DeRefDS(_10129);
    _10129 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _49db_create(int _path_18076, int _lock_method_18077, int _init_tables_18078, int _init_free_18079)
{
    int _db_18080 = NOVALUE;
    int _lock_file_1__tmp_at222_18120 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_18119 = NOVALUE;
    int _put4_1__tmp_at342_18129 = NOVALUE;
    int _put4_1__tmp_at370_18131 = NOVALUE;
    int _put4_1__tmp_at413_18137 = NOVALUE;
    int _x_inlined_put4_at_410_18136 = NOVALUE;
    int _put4_1__tmp_at452_18142 = NOVALUE;
    int _x_inlined_put4_at_449_18141 = NOVALUE;
    int _put4_1__tmp_at480_18144 = NOVALUE;
    int _s_inlined_putn_at_516_18148 = NOVALUE;
    int _put4_1__tmp_at548_18153 = NOVALUE;
    int _x_inlined_put4_at_545_18152 = NOVALUE;
    int _s_inlined_putn_at_584_18157 = NOVALUE;
    int _10228 = NOVALUE;
    int _10227 = NOVALUE;
    int _10226 = NOVALUE;
    int _10225 = NOVALUE;
    int _10224 = NOVALUE;
    int _10223 = NOVALUE;
    int _10222 = NOVALUE;
    int _10221 = NOVALUE;
    int _10220 = NOVALUE;
    int _10219 = NOVALUE;
    int _10218 = NOVALUE;
    int _10200 = NOVALUE;
    int _10198 = NOVALUE;
    int _10197 = NOVALUE;
    int _10195 = NOVALUE;
    int _10194 = NOVALUE;
    int _10192 = NOVALUE;
    int _10191 = NOVALUE;
    int _10189 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18080 = find_from(_path_18076, _49Known_Aliases_17075, 1);

    /** 	if db then*/
    if (_db_18080 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10189 = (int)*(((s1_ptr)_2)->base + _db_18080);
    DeRefDS(_path_18076);
    _2 = (int)SEQ_PTR(_10189);
    _path_18076 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18076);
    _10189 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10191 = (int)*(((s1_ptr)_2)->base + _db_18080);
    _2 = (int)SEQ_PTR(_10191);
    _10192 = (int)*(((s1_ptr)_2)->base + 2);
    _10191 = NOVALUE;
    _2 = (int)SEQ_PTR(_10192);
    _lock_method_18077 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18077)){
        _lock_method_18077 = (long)DBL_PTR(_lock_method_18077)->dbl;
    }
    _10192 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10194 = (int)*(((s1_ptr)_2)->base + _db_18080);
    _2 = (int)SEQ_PTR(_10194);
    _10195 = (int)*(((s1_ptr)_2)->base + 2);
    _10194 = NOVALUE;
    _2 = (int)SEQ_PTR(_10195);
    _init_tables_18078 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_18078)){
        _init_tables_18078 = (long)DBL_PTR(_init_tables_18078)->dbl;
    }
    _10195 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10197 = (int)*(((s1_ptr)_2)->base + _db_18080);
    _2 = (int)SEQ_PTR(_10197);
    _10198 = (int)*(((s1_ptr)_2)->base + 2);
    _10197 = NOVALUE;
    _2 = (int)SEQ_PTR(_10198);
    _init_free_18079 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_18079)){
        _init_free_18079 = (long)DBL_PTR(_init_free_18079)->dbl;
    }
    _10198 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_18076);
    RefDS(_10183);
    _10200 = _17defaultext(_path_18076, _10183);
    _0 = _path_18076;
    _path_18076 = _17canonical_path(_10200, 0, 0);
    DeRefDS(_0);
    _10200 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_18078 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_18078 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_18079 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_18079 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_18080 = EOpen(_path_18076, _3632, 0);

    /** 	if db != -1 then*/
    if (_db_18080 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_18080);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_18076);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_18080 = EOpen(_path_18076, _10206, 0);

    /** 	if db = -1 then*/
    if (_db_18080 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18076);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_18080);

    /** 	db = open(path, "ub")*/
    _db_18080 = EOpen(_path_18076, _10209, 0);

    /** 	if db = -1 then*/
    if (_db_18080 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18076);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18077 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_18077 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18077 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_18120;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18080;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_18120 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_18119 = machine(61, _lock_file_1__tmp_at222_18120);
    DeRef(_lock_file_1__tmp_at222_18120);
    _lock_file_1__tmp_at222_18120 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_18119 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18076);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db*/
    _49current_db_17054 = _db_18080;

    /** 	current_lock = lock_method*/
    _49current_lock_17060 = _lock_method_18077;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17055);
    _49current_table_pos_17055 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17056);
    _49current_table_name_17056 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18076);
    Append(&_49db_names_17057, _49db_names_17057, _path_18076);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_49db_lock_methods_17059, _49db_lock_methods_17059, _lock_method_18077);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_49db_file_nums_17058, _49db_file_nums_17058, _db_18080);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17054, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17054, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_49current_db_17054, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_18129);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_18129 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at342_18129); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_18129);
    _put4_1__tmp_at342_18129 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_18131);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_18131 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at370_18131); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_18131);
    _put4_1__tmp_at370_18131 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_18078 == (short)_init_tables_18078)
    _10218 = _init_tables_18078 * 16;
    else
    _10218 = NewDouble(_init_tables_18078 * (double)16);
    if (IS_ATOM_INT(_10218)) {
        _10219 = 23 + _10218;
        if ((long)((unsigned long)_10219 + (unsigned long)HIGH_BITS) >= 0) 
        _10219 = NewDouble((double)_10219);
    }
    else {
        _10219 = NewDouble((double)23 + DBL_PTR(_10218)->dbl);
    }
    DeRef(_10218);
    _10218 = NOVALUE;
    if (IS_ATOM_INT(_10219)) {
        _10220 = _10219 + 4;
        if ((long)((unsigned long)_10220 + (unsigned long)HIGH_BITS) >= 0) 
        _10220 = NewDouble((double)_10220);
    }
    else {
        _10220 = NewDouble(DBL_PTR(_10219)->dbl + (double)4);
    }
    DeRef(_10219);
    _10219 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_18136);
    _x_inlined_put4_at_410_18136 = _10220;
    _10220 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_18136)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_18136;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_18136)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_18137);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_18137 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at413_18137); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_18136);
    _x_inlined_put4_at_410_18136 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_18137);
    _put4_1__tmp_at413_18137 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_18078 == (short)_init_tables_18078)
    _10221 = _init_tables_18078 * 16;
    else
    _10221 = NewDouble(_init_tables_18078 * (double)16);
    if (IS_ATOM_INT(_10221)) {
        _10222 = 8 + _10221;
        if ((long)((unsigned long)_10222 + (unsigned long)HIGH_BITS) >= 0) 
        _10222 = NewDouble((double)_10222);
    }
    else {
        _10222 = NewDouble((double)8 + DBL_PTR(_10221)->dbl);
    }
    DeRef(_10221);
    _10221 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_18141);
    _x_inlined_put4_at_449_18141 = _10222;
    _10222 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_18141)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_18141;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_18141)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_18142);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_18142 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at452_18142); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_18141);
    _x_inlined_put4_at_449_18141 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_18142);
    _put4_1__tmp_at452_18142 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_18144);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_18144 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at480_18144); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_18144);
    _put4_1__tmp_at480_18144 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _10223 = _init_tables_18078 * 16;
    _10224 = Repeat(0, _10223);
    _10223 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_18148);
    _s_inlined_putn_at_516_18148 = _10224;
    _10224 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_516_18148); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_18148);
    _s_inlined_putn_at_516_18148 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_18079 == (short)_init_free_18079)
    _10225 = _init_free_18079 * 8;
    else
    _10225 = NewDouble(_init_free_18079 * (double)8);
    if (IS_ATOM_INT(_10225)) {
        _10226 = 4 + _10225;
        if ((long)((unsigned long)_10226 + (unsigned long)HIGH_BITS) >= 0) 
        _10226 = NewDouble((double)_10226);
    }
    else {
        _10226 = NewDouble((double)4 + DBL_PTR(_10225)->dbl);
    }
    DeRef(_10225);
    _10225 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_18152);
    _x_inlined_put4_at_545_18152 = _10226;
    _10226 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_18152)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_18152;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_18152)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_18153);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_18153 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at548_18153); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_18152);
    _x_inlined_put4_at_545_18152 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_18153);
    _put4_1__tmp_at548_18153 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _10227 = _init_free_18079 * 8;
    _10228 = Repeat(0, _10227);
    _10227 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_18157);
    _s_inlined_putn_at_584_18157 = _10228;
    _10228 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_584_18157); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_18157);
    _s_inlined_putn_at_584_18157 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_18076);
    return 0;
    ;
}


int _49db_open(int _path_18160, int _lock_method_18161)
{
    int _db_18162 = NOVALUE;
    int _magic_18163 = NOVALUE;
    int _lock_file_1__tmp_at129_18188 = NOVALUE;
    int _lock_file_inlined_lock_file_at_129_18187 = NOVALUE;
    int _lock_file_1__tmp_at169_18195 = NOVALUE;
    int _lock_file_inlined_lock_file_at_169_18194 = NOVALUE;
    int _10239 = NOVALUE;
    int _10237 = NOVALUE;
    int _10235 = NOVALUE;
    int _10233 = NOVALUE;
    int _10232 = NOVALUE;
    int _10230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18162 = find_from(_path_18160, _49Known_Aliases_17075, 1);

    /** 	if db then*/
    if (_db_18162 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10230 = (int)*(((s1_ptr)_2)->base + _db_18162);
    DeRefDS(_path_18160);
    _2 = (int)SEQ_PTR(_10230);
    _path_18160 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18160);
    _10230 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10232 = (int)*(((s1_ptr)_2)->base + _db_18162);
    _2 = (int)SEQ_PTR(_10232);
    _10233 = (int)*(((s1_ptr)_2)->base + 2);
    _10232 = NOVALUE;
    _2 = (int)SEQ_PTR(_10233);
    _lock_method_18161 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18161)){
        _lock_method_18161 = (long)DBL_PTR(_lock_method_18161)->dbl;
    }
    _10233 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18160);
    RefDS(_10183);
    _10235 = _17defaultext(_path_18160, _10183);
    _0 = _path_18160;
    _path_18160 = _17canonical_path(_10235, 0, 0);
    DeRefDS(_0);
    _10235 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _10237 = (_lock_method_18161 == 0);
    if (_10237 != 0) {
        goto L3; // [76] 89
    }
    _10239 = (_lock_method_18161 == 2);
    if (_10239 == 0)
    {
        DeRef(_10239);
        _10239 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10239);
        _10239 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_18162 = EOpen(_path_18160, _10209, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_18162 = EOpen(_path_18160, _3632, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if db = -1 then*/
    if (_db_18162 != -1)
    goto L6; // [111] 122

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18160);
    DeRef(_10237);
    _10237 = NOVALUE;
    return -1;
L6: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18161 != 2)
    goto L7; // [124] 162

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at129_18188;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18162;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at129_18188 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_129_18187 = machine(61, _lock_file_1__tmp_at129_18188);
    DeRef(_lock_file_1__tmp_at129_18188);
    _lock_file_1__tmp_at129_18188 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_129_18187 != 0)
    goto L8; // [145] 201

    /** 			close(db)*/
    EClose(_db_18162);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18160);
    DeRef(_10237);
    _10237 = NOVALUE;
    return -3;
    goto L8; // [159] 201
L7: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18161 != 1)
    goto L9; // [164] 200

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at169_18195;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18162;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at169_18195 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_169_18194 = machine(61, _lock_file_1__tmp_at169_18195);
    DeRef(_lock_file_1__tmp_at169_18195);
    _lock_file_1__tmp_at169_18195 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_169_18194 != 0)
    goto LA; // [185] 199

    /** 			close(db)*/
    EClose(_db_18162);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18160);
    DeRef(_10237);
    _10237 = NOVALUE;
    return -3;
LA: 
L9: 
L8: 

    /** 	magic = getc(db)*/
    if (_db_18162 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_18162, EF_READ);
        last_r_file_no = _db_18162;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_18163 = getc((FILE*)xstdin);
        }
        else
        _magic_18163 = getc(last_r_file_ptr);
    }
    else
    _magic_18163 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_18163 == 77)
    goto LB; // [208] 223

    /** 		close(db)*/
    EClose(_db_18162);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18160);
    DeRef(_10237);
    _10237 = NOVALUE;
    return -1;
LB: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db */
    _49current_db_17054 = _db_18162;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17055);
    _49current_table_pos_17055 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17056);
    _49current_table_name_17056 = _5;

    /** 	current_lock = lock_method*/
    _49current_lock_17060 = _lock_method_18161;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18160);
    Append(&_49db_names_17057, _49db_names_17057, _path_18160);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_49db_lock_methods_17059, _49db_lock_methods_17059, _lock_method_18161);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_49db_file_nums_17058, _49db_file_nums_17058, _db_18162);

    /** 	return DB_OK*/
    DeRefDS(_path_18160);
    DeRef(_10237);
    _10237 = NOVALUE;
    return 0;
    ;
}


int _49db_select(int _path_18205, int _lock_method_18206)
{
    int _index_18207 = NOVALUE;
    int _10258 = NOVALUE;
    int _10256 = NOVALUE;
    int _10255 = NOVALUE;
    int _10253 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find(path, Known_Aliases)*/
    _index_18207 = find_from(_path_18205, _49Known_Aliases_17075, 1);

    /** 	if index then*/
    if (_index_18207 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10253 = (int)*(((s1_ptr)_2)->base + _index_18207);
    DeRefDS(_path_18205);
    _2 = (int)SEQ_PTR(_10253);
    _path_18205 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18205);
    _10253 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_49Alias_Details_17076);
    _10255 = (int)*(((s1_ptr)_2)->base + _index_18207);
    _2 = (int)SEQ_PTR(_10255);
    _10256 = (int)*(((s1_ptr)_2)->base + 2);
    _10255 = NOVALUE;
    _2 = (int)SEQ_PTR(_10256);
    _lock_method_18206 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18206)){
        _lock_method_18206 = (long)DBL_PTR(_lock_method_18206)->dbl;
    }
    _10256 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18205);
    RefDS(_10183);
    _10258 = _17defaultext(_path_18205, _10183);
    _0 = _path_18205;
    _path_18205 = _17canonical_path(_10258, 0, 0);
    DeRefDS(_0);
    _10258 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_18207 = find_from(_path_18205, _49db_names_17057, 1);

    /** 	if index = 0 then*/
    if (_index_18207 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_18206 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_18205);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_18205);
    _index_18207 = _49db_open(_path_18205, _lock_method_18206);
    if (!IS_ATOM_INT(_index_18207)) {
        _1 = (long)(DBL_PTR(_index_18207)->dbl);
        DeRefDS(_index_18207);
        _index_18207 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_18207 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_18205);
    return _index_18207;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_18207 = find_from(_path_18205, _49db_names_17057, 1);
L3: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_49db_file_nums_17058);
    _49current_db_17054 = (int)*(((s1_ptr)_2)->base + _index_18207);
    if (!IS_ATOM_INT(_49current_db_17054))
    _49current_db_17054 = (long)DBL_PTR(_49current_db_17054)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_49db_lock_methods_17059);
    _49current_lock_17060 = (int)*(((s1_ptr)_2)->base + _index_18207);
    if (!IS_ATOM_INT(_49current_lock_17060))
    _49current_lock_17060 = (long)DBL_PTR(_49current_lock_17060)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17055);
    _49current_table_pos_17055 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_49current_table_name_17056);
    _49current_table_name_17056 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_49key_pointers_17061);
    _49key_pointers_17061 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_18205);
    return 0;
    ;
}


void _49db_close()
{
    int _unlock_file_1__tmp_at25_18236 = NOVALUE;
    int _index_18231 = NOVALUE;
    int _10275 = NOVALUE;
    int _10274 = NOVALUE;
    int _10273 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_49current_db_17054 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_49current_lock_17060 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18236);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18236 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18236);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18236);
    _unlock_file_1__tmp_at25_18236 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_49current_db_17054);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18231 = find_from(_49current_db_17054, _49db_file_nums_17058, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_names_17057);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        int stop = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_names_17057), start, &_49db_names_17057 );
            }
            else Tail(SEQ_PTR(_49db_names_17057), stop+1, &_49db_names_17057);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_names_17057), start, &_49db_names_17057);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_names_17057 = Remove_elements(start, stop, (SEQ_PTR(_49db_names_17057)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_file_nums_17058);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        int stop = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_file_nums_17058), start, &_49db_file_nums_17058 );
            }
            else Tail(SEQ_PTR(_49db_file_nums_17058), stop+1, &_49db_file_nums_17058);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_file_nums_17058), start, &_49db_file_nums_17058);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_file_nums_17058 = Remove_elements(start, stop, (SEQ_PTR(_49db_file_nums_17058)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_49db_lock_methods_17059);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        int stop = (IS_ATOM_INT(_index_18231)) ? _index_18231 : (long)(DBL_PTR(_index_18231)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_49db_lock_methods_17059), start, &_49db_lock_methods_17059 );
            }
            else Tail(SEQ_PTR(_49db_lock_methods_17059), stop+1, &_49db_lock_methods_17059);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_49db_lock_methods_17059), start, &_49db_lock_methods_17059);
        }
        else {
            assign_slice_seq = &assign_space;
            _49db_lock_methods_17059 = Remove_elements(start, stop, (SEQ_PTR(_49db_lock_methods_17059)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_49cache_index_17063)){
            _10273 = SEQ_PTR(_49cache_index_17063)->length;
    }
    else {
        _10273 = 1;
    }
    {
        int _i_18242;
        _i_18242 = _10273;
L4: 
        if (_i_18242 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_49cache_index_17063);
        _10274 = (int)*(((s1_ptr)_2)->base + _i_18242);
        _2 = (int)SEQ_PTR(_10274);
        _10275 = (int)*(((s1_ptr)_2)->base + 1);
        _10274 = NOVALUE;
        if (binary_op_a(NOTEQ, _10275, _49current_db_17054)){
            _10275 = NOVALUE;
            goto L6; // [115] 138
        }
        _10275 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_49cache_index_17063);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18242)) ? _i_18242 : (long)(DBL_PTR(_i_18242)->dbl);
            int stop = (IS_ATOM_INT(_i_18242)) ? _i_18242 : (long)(DBL_PTR(_i_18242)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49cache_index_17063), start, &_49cache_index_17063 );
                }
                else Tail(SEQ_PTR(_49cache_index_17063), stop+1, &_49cache_index_17063);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49cache_index_17063), start, &_49cache_index_17063);
            }
            else {
                assign_slice_seq = &assign_space;
                _49cache_index_17063 = Remove_elements(start, stop, (SEQ_PTR(_49cache_index_17063)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_49key_cache_17062);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18242)) ? _i_18242 : (long)(DBL_PTR(_i_18242)->dbl);
            int stop = (IS_ATOM_INT(_i_18242)) ? _i_18242 : (long)(DBL_PTR(_i_18242)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49key_cache_17062), start, &_49key_cache_17062 );
                }
                else Tail(SEQ_PTR(_49key_cache_17062), stop+1, &_49key_cache_17062);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49key_cache_17062), start, &_49key_cache_17062);
            }
            else {
                assign_slice_seq = &assign_space;
                _49key_cache_17062 = Remove_elements(start, stop, (SEQ_PTR(_49key_cache_17062)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_18242 = _i_18242 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_49current_table_pos_17055);
    _49current_table_pos_17055 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_49current_table_name_17056);
    _49current_table_name_17056 = _5;

    /** 	current_db = -1*/
    _49current_db_17054 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_49key_pointers_17061);
    _49key_pointers_17061 = _5;

    /** end procedure*/
    return;
    ;
}


int _49table_find(int _name_18252)
{
    int _tables_18253 = NOVALUE;
    int _nt_18254 = NOVALUE;
    int _t_header_18255 = NOVALUE;
    int _name_ptr_18256 = NOVALUE;
    int _seek_1__tmp_at6_18259 = NOVALUE;
    int _seek_inlined_seek_at_6_18258 = NOVALUE;
    int _seek_1__tmp_at44_18266 = NOVALUE;
    int _seek_inlined_seek_at_44_18265 = NOVALUE;
    int _seek_1__tmp_at84_18274 = NOVALUE;
    int _seek_inlined_seek_at_84_18273 = NOVALUE;
    int _seek_1__tmp_at106_18278 = NOVALUE;
    int _seek_inlined_seek_at_106_18277 = NOVALUE;
    int _10286 = NOVALUE;
    int _10284 = NOVALUE;
    int _10279 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18259);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_18259 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18258 = machine(19, _seek_1__tmp_at6_18259);
    DeRefi(_seek_1__tmp_at6_18259);
    _seek_1__tmp_at6_18259 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_49vLastErrors_17078)){
            _10279 = SEQ_PTR(_49vLastErrors_17078)->length;
    }
    else {
        _10279 = 1;
    }
    if (_10279 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18252);
    DeRef(_tables_18253);
    DeRef(_nt_18254);
    DeRef(_t_header_18255);
    DeRef(_name_ptr_18256);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18253;
    _tables_18253 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18253);
    DeRef(_seek_1__tmp_at44_18266);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _tables_18253;
    _seek_1__tmp_at44_18266 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18265 = machine(19, _seek_1__tmp_at44_18266);
    DeRef(_seek_1__tmp_at44_18266);
    _seek_1__tmp_at44_18266 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18254;
    _nt_18254 = _49get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_18255);
    if (IS_ATOM_INT(_tables_18253)) {
        _t_header_18255 = _tables_18253 + 4;
        if ((long)((unsigned long)_t_header_18255 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_18255 = NewDouble((double)_t_header_18255);
    }
    else {
        _t_header_18255 = NewDouble(DBL_PTR(_tables_18253)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_18254);
    DeRef(_10284);
    _10284 = _nt_18254;
    {
        int _i_18270;
        _i_18270 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18270, _10284)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18255);
        DeRef(_seek_1__tmp_at84_18274);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _t_header_18255;
        _seek_1__tmp_at84_18274 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18273 = machine(19, _seek_1__tmp_at84_18274);
        DeRef(_seek_1__tmp_at84_18274);
        _seek_1__tmp_at84_18274 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_18256;
        _name_ptr_18256 = _49get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18256);
        DeRef(_seek_1__tmp_at106_18278);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _name_ptr_18256;
        _seek_1__tmp_at106_18278 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18277 = machine(19, _seek_1__tmp_at106_18278);
        DeRef(_seek_1__tmp_at106_18278);
        _seek_1__tmp_at106_18278 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_18252);
        _10286 = _49equal_string(_name_18252);
        if (binary_op_a(LESSEQ, _10286, 0)){
            DeRef(_10286);
            _10286 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10286);
        _10286 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_18270);
        DeRefDS(_name_18252);
        DeRef(_tables_18253);
        DeRef(_nt_18254);
        DeRef(_name_ptr_18256);
        return _t_header_18255;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18255;
        if (IS_ATOM_INT(_t_header_18255)) {
            _t_header_18255 = _t_header_18255 + 16;
            if ((long)((unsigned long)_t_header_18255 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_18255 = NewDouble((double)_t_header_18255);
        }
        else {
            _t_header_18255 = NewDouble(DBL_PTR(_t_header_18255)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_18270;
        if (IS_ATOM_INT(_i_18270)) {
            _i_18270 = _i_18270 + 1;
            if ((long)((unsigned long)_i_18270 +(unsigned long) HIGH_BITS) >= 0){
                _i_18270 = NewDouble((double)_i_18270);
            }
        }
        else {
            _i_18270 = binary_op_a(PLUS, _i_18270, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18270);
    }

    /** 	return -1*/
    DeRefDS(_name_18252);
    DeRef(_tables_18253);
    DeRef(_nt_18254);
    DeRef(_t_header_18255);
    DeRef(_name_ptr_18256);
    return -1;
    ;
}


int _49db_select_table(int _name_18285)
{
    int _table_18286 = NOVALUE;
    int _nkeys_18287 = NOVALUE;
    int _index_18288 = NOVALUE;
    int _block_ptr_18289 = NOVALUE;
    int _block_size_18290 = NOVALUE;
    int _blocks_18291 = NOVALUE;
    int _k_18292 = NOVALUE;
    int _seek_1__tmp_at120_18311 = NOVALUE;
    int _seek_inlined_seek_at_120_18310 = NOVALUE;
    int _pos_inlined_seek_at_117_18309 = NOVALUE;
    int _seek_1__tmp_at178_18321 = NOVALUE;
    int _seek_inlined_seek_at_178_18320 = NOVALUE;
    int _seek_1__tmp_at205_18326 = NOVALUE;
    int _seek_inlined_seek_at_205_18325 = NOVALUE;
    int _10307 = NOVALUE;
    int _10306 = NOVALUE;
    int _10303 = NOVALUE;
    int _10298 = NOVALUE;
    int _10293 = NOVALUE;
    int _10289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_49current_table_name_17056 == _name_18285)
    _10289 = 1;
    else if (IS_ATOM_INT(_49current_table_name_17056) && IS_ATOM_INT(_name_18285))
    _10289 = 0;
    else
    _10289 = (compare(_49current_table_name_17056, _name_18285) == 0);
    if (_10289 == 0)
    {
        _10289 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10289 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_18285);
    DeRef(_table_18286);
    DeRef(_nkeys_18287);
    DeRef(_index_18288);
    DeRef(_block_ptr_18289);
    DeRef(_block_size_18290);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18285);
    _0 = _table_18286;
    _table_18286 = _49table_find(_name_18285);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18286, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_18285);
    DeRef(_table_18286);
    DeRef(_nkeys_18287);
    DeRef(_index_18288);
    DeRef(_block_ptr_18289);
    DeRef(_block_size_18290);
    return -1;
L2: 

    /** 	save_keys()*/
    _49save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_18286);
    DeRef(_49current_table_pos_17055);
    _49current_table_pos_17055 = _table_18286;

    /** 	current_table_name = name*/
    RefDS(_name_18285);
    DeRef(_49current_table_name_17056);
    _49current_table_name_17056 = _name_18285;

    /** 	k = 0*/
    _k_18292 = 0;

    /** 	if caching_option = 1 then*/

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_49current_table_pos_17055);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _49current_table_pos_17055;
    _10293 = MAKE_SEQ(_1);
    _k_18292 = find_from(_10293, _49cache_index_17063, 1);
    DeRefDS(_10293);
    _10293 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_18292 == 0)
    goto L3; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_49key_pointers_17061);
    _2 = (int)SEQ_PTR(_49key_cache_17062);
    _49key_pointers_17061 = (int)*(((s1_ptr)_2)->base + _k_18292);
    Ref(_49key_pointers_17061);
L3: 

    /** 	if k = 0 then*/
    if (_k_18292 != 0)
    goto L4; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18286)) {
        _10298 = _table_18286 + 4;
        if ((long)((unsigned long)_10298 + (unsigned long)HIGH_BITS) >= 0) 
        _10298 = NewDouble((double)_10298);
    }
    else {
        _10298 = NewDouble(DBL_PTR(_table_18286)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_18309);
    _pos_inlined_seek_at_117_18309 = _10298;
    _10298 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18309);
    DeRef(_seek_1__tmp_at120_18311);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_18309;
    _seek_1__tmp_at120_18311 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18310 = machine(19, _seek_1__tmp_at120_18311);
    DeRef(_pos_inlined_seek_at_117_18309);
    _pos_inlined_seek_at_117_18309 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18311);
    _seek_1__tmp_at120_18311 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_18287;
    _nkeys_18287 = _49get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_18291 = _49get4();
    if (!IS_ATOM_INT(_blocks_18291)) {
        _1 = (long)(DBL_PTR(_blocks_18291)->dbl);
        DeRefDS(_blocks_18291);
        _blocks_18291 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_18288;
    _index_18288 = _49get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_49key_pointers_17061);
    _49key_pointers_17061 = Repeat(0, _nkeys_18287);

    /** 		k = 1*/
    _k_18292 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _10303 = _blocks_18291 - 1;
    if ((long)((unsigned long)_10303 +(unsigned long) HIGH_BITS) >= 0){
        _10303 = NewDouble((double)_10303);
    }
    {
        int _b_18317;
        _b_18317 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18317, _10303)){
            goto L6; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18288);
        DeRef(_seek_1__tmp_at178_18321);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _index_18288;
        _seek_1__tmp_at178_18321 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18320 = machine(19, _seek_1__tmp_at178_18321);
        DeRef(_seek_1__tmp_at178_18321);
        _seek_1__tmp_at178_18321 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_18290;
        _block_size_18290 = _49get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_18289;
        _block_ptr_18289 = _49get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18289);
        DeRef(_seek_1__tmp_at205_18326);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _block_ptr_18289;
        _seek_1__tmp_at205_18326 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18325 = machine(19, _seek_1__tmp_at205_18326);
        DeRef(_seek_1__tmp_at205_18326);
        _seek_1__tmp_at205_18326 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_18290);
        DeRef(_10306);
        _10306 = _block_size_18290;
        {
            int _j_18328;
            _j_18328 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18328, _10306)){
                goto L8; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _10307 = _49get4();
            _2 = (int)SEQ_PTR(_49key_pointers_17061);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _49key_pointers_17061 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_18292);
            _1 = *(int *)_2;
            *(int *)_2 = _10307;
            if( _1 != _10307 ){
                DeRef(_1);
            }
            _10307 = NOVALUE;

            /** 				k += 1*/
            _k_18292 = _k_18292 + 1;

            /** 			end for*/
            _0 = _j_18328;
            if (IS_ATOM_INT(_j_18328)) {
                _j_18328 = _j_18328 + 1;
                if ((long)((unsigned long)_j_18328 +(unsigned long) HIGH_BITS) >= 0){
                    _j_18328 = NewDouble((double)_j_18328);
                }
            }
            else {
                _j_18328 = binary_op_a(PLUS, _j_18328, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18328);
        }

        /** 			index += 8*/
        _0 = _index_18288;
        if (IS_ATOM_INT(_index_18288)) {
            _index_18288 = _index_18288 + 8;
            if ((long)((unsigned long)_index_18288 + (unsigned long)HIGH_BITS) >= 0) 
            _index_18288 = NewDouble((double)_index_18288);
        }
        else {
            _index_18288 = NewDouble(DBL_PTR(_index_18288)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_18317;
        if (IS_ATOM_INT(_b_18317)) {
            _b_18317 = _b_18317 + 1;
            if ((long)((unsigned long)_b_18317 +(unsigned long) HIGH_BITS) >= 0){
                _b_18317 = NewDouble((double)_b_18317);
            }
        }
        else {
            _b_18317 = binary_op_a(PLUS, _b_18317, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18317);
    }
L4: 

    /** 	return DB_OK*/
    DeRefDS(_name_18285);
    DeRef(_table_18286);
    DeRef(_nkeys_18287);
    DeRef(_index_18288);
    DeRef(_block_ptr_18289);
    DeRef(_block_size_18290);
    DeRef(_10303);
    _10303 = NOVALUE;
    return 0;
    ;
}


int _49db_create_table(int _name_18337, int _init_records_18338)
{
    int _name_ptr_18339 = NOVALUE;
    int _nt_18340 = NOVALUE;
    int _tables_18341 = NOVALUE;
    int _newtables_18342 = NOVALUE;
    int _table_18343 = NOVALUE;
    int _records_ptr_18344 = NOVALUE;
    int _size_18345 = NOVALUE;
    int _newsize_18346 = NOVALUE;
    int _index_ptr_18347 = NOVALUE;
    int _remaining_18348 = NOVALUE;
    int _init_index_18349 = NOVALUE;
    int _seek_1__tmp_at68_18363 = NOVALUE;
    int _seek_inlined_seek_at_68_18362 = NOVALUE;
    int _seek_1__tmp_at97_18369 = NOVALUE;
    int _seek_inlined_seek_at_97_18368 = NOVALUE;
    int _pos_inlined_seek_at_94_18367 = NOVALUE;
    int _put4_1__tmp_at159_18382 = NOVALUE;
    int _seek_1__tmp_at196_18387 = NOVALUE;
    int _seek_inlined_seek_at_196_18386 = NOVALUE;
    int _pos_inlined_seek_at_193_18385 = NOVALUE;
    int _seek_1__tmp_at239_18395 = NOVALUE;
    int _seek_inlined_seek_at_239_18394 = NOVALUE;
    int _pos_inlined_seek_at_236_18393 = NOVALUE;
    int _s_inlined_putn_at_288_18403 = NOVALUE;
    int _seek_1__tmp_at316_18406 = NOVALUE;
    int _seek_inlined_seek_at_316_18405 = NOVALUE;
    int _put4_1__tmp_at331_18408 = NOVALUE;
    int _seek_1__tmp_at369_18412 = NOVALUE;
    int _seek_inlined_seek_at_369_18411 = NOVALUE;
    int _put4_1__tmp_at384_18414 = NOVALUE;
    int _s_inlined_putn_at_431_18420 = NOVALUE;
    int _put4_1__tmp_at462_18424 = NOVALUE;
    int _put4_1__tmp_at490_18426 = NOVALUE;
    int _s_inlined_putn_at_530_18431 = NOVALUE;
    int _s_inlined_putn_at_568_18437 = NOVALUE;
    int _seek_1__tmp_at610_18445 = NOVALUE;
    int _seek_inlined_seek_at_610_18444 = NOVALUE;
    int _pos_inlined_seek_at_607_18443 = NOVALUE;
    int _put4_1__tmp_at625_18447 = NOVALUE;
    int _put4_1__tmp_at653_18449 = NOVALUE;
    int _put4_1__tmp_at681_18451 = NOVALUE;
    int _put4_1__tmp_at709_18453 = NOVALUE;
    int _10356 = NOVALUE;
    int _10355 = NOVALUE;
    int _10354 = NOVALUE;
    int _10353 = NOVALUE;
    int _10352 = NOVALUE;
    int _10351 = NOVALUE;
    int _10349 = NOVALUE;
    int _10348 = NOVALUE;
    int _10347 = NOVALUE;
    int _10346 = NOVALUE;
    int _10345 = NOVALUE;
    int _10343 = NOVALUE;
    int _10342 = NOVALUE;
    int _10341 = NOVALUE;
    int _10339 = NOVALUE;
    int _10338 = NOVALUE;
    int _10337 = NOVALUE;
    int _10336 = NOVALUE;
    int _10335 = NOVALUE;
    int _10334 = NOVALUE;
    int _10333 = NOVALUE;
    int _10331 = NOVALUE;
    int _10330 = NOVALUE;
    int _10329 = NOVALUE;
    int _10326 = NOVALUE;
    int _10325 = NOVALUE;
    int _10323 = NOVALUE;
    int _10322 = NOVALUE;
    int _10320 = NOVALUE;
    int _10318 = NOVALUE;
    int _10315 = NOVALUE;
    int _10310 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not cstring(name) then*/
    RefDS(_name_18337);
    _10310 = _13cstring(_name_18337);
    if (IS_ATOM_INT(_10310)) {
        if (_10310 != 0){
            DeRef(_10310);
            _10310 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_10310)->dbl != 0.0){
            DeRef(_10310);
            _10310 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_10310);
    _10310 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_18337);
    DeRef(_name_ptr_18339);
    DeRef(_nt_18340);
    DeRef(_tables_18341);
    DeRef(_newtables_18342);
    DeRef(_table_18343);
    DeRef(_records_ptr_18344);
    DeRef(_size_18345);
    DeRef(_newsize_18346);
    DeRef(_index_ptr_18347);
    DeRef(_remaining_18348);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18337);
    _0 = _table_18343;
    _table_18343 = _49table_find(_name_18337);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_18343, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_18337);
    DeRef(_name_ptr_18339);
    DeRef(_nt_18340);
    DeRef(_tables_18341);
    DeRef(_newtables_18342);
    DeRef(_table_18343);
    DeRef(_records_ptr_18344);
    DeRef(_size_18345);
    DeRef(_newsize_18346);
    DeRef(_index_ptr_18347);
    DeRef(_remaining_18348);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_18338 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_18338 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_18338;
    ((int *)_2)[2] = 10;
    _10315 = MAKE_SEQ(_1);
    _init_index_18349 = _20min(_10315);
    _10315 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_18349)) {
        _1 = (long)(DBL_PTR(_init_index_18349)->dbl);
        DeRefDS(_init_index_18349);
        _init_index_18349 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_18363);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_18363 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_18362 = machine(19, _seek_1__tmp_at68_18363);
    DeRefi(_seek_1__tmp_at68_18363);
    _seek_1__tmp_at68_18363 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_18341;
    _tables_18341 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_18341)) {
        _10318 = _tables_18341 - 4;
        if ((long)((unsigned long)_10318 +(unsigned long) HIGH_BITS) >= 0){
            _10318 = NewDouble((double)_10318);
        }
    }
    else {
        _10318 = NewDouble(DBL_PTR(_tables_18341)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_18367);
    _pos_inlined_seek_at_94_18367 = _10318;
    _10318 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_18367);
    DeRef(_seek_1__tmp_at97_18369);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_18367;
    _seek_1__tmp_at97_18369 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_18368 = machine(19, _seek_1__tmp_at97_18369);
    DeRef(_pos_inlined_seek_at_94_18367);
    _pos_inlined_seek_at_94_18367 = NOVALUE;
    DeRef(_seek_1__tmp_at97_18369);
    _seek_1__tmp_at97_18369 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_18345;
    _size_18345 = _49get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _10320 = _49get4();
    DeRef(_nt_18340);
    if (IS_ATOM_INT(_10320)) {
        _nt_18340 = _10320 + 1;
        if (_nt_18340 > MAXINT){
            _nt_18340 = NewDouble((double)_nt_18340);
        }
    }
    else
    _nt_18340 = binary_op(PLUS, 1, _10320);
    DeRef(_10320);
    _10320 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_18340)) {
        if (_nt_18340 == (short)_nt_18340)
        _10322 = _nt_18340 * 16;
        else
        _10322 = NewDouble(_nt_18340 * (double)16);
    }
    else {
        _10322 = NewDouble(DBL_PTR(_nt_18340)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10322)) {
        _10323 = _10322 + 8;
        if ((long)((unsigned long)_10323 + (unsigned long)HIGH_BITS) >= 0) 
        _10323 = NewDouble((double)_10323);
    }
    else {
        _10323 = NewDouble(DBL_PTR(_10322)->dbl + (double)8);
    }
    DeRef(_10322);
    _10322 = NOVALUE;
    if (binary_op_a(LESSEQ, _10323, _size_18345)){
        DeRef(_10323);
        _10323 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_10323);
    _10323 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_18345)) {
        if (_size_18345 & 1) {
            _10325 = NewDouble((_size_18345 >> 1) + 0.5);
        }
        else
        _10325 = _size_18345 >> 1;
    }
    else {
        _10325 = binary_op(DIVIDE, _size_18345, 2);
    }
    if (IS_ATOM_INT(_size_18345) && IS_ATOM_INT(_10325)) {
        _10326 = _size_18345 + _10325;
        if ((long)((unsigned long)_10326 + (unsigned long)HIGH_BITS) >= 0) 
        _10326 = NewDouble((double)_10326);
    }
    else {
        if (IS_ATOM_INT(_size_18345)) {
            _10326 = NewDouble((double)_size_18345 + DBL_PTR(_10325)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10325)) {
                _10326 = NewDouble(DBL_PTR(_size_18345)->dbl + (double)_10325);
            }
            else
            _10326 = NewDouble(DBL_PTR(_size_18345)->dbl + DBL_PTR(_10325)->dbl);
        }
    }
    DeRef(_10325);
    _10325 = NOVALUE;
    DeRef(_newsize_18346);
    if (IS_ATOM_INT(_10326))
    _newsize_18346 = e_floor(_10326);
    else
    _newsize_18346 = unary_op(FLOOR, _10326);
    DeRef(_10326);
    _10326 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_18346);
    _0 = _newtables_18342;
    _newtables_18342 = _49db_allocate(_newsize_18346);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_nt_18340)) {
        *poke4_addr = (unsigned long)_nt_18340;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18340)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_18382);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_18382 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at159_18382); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_18382);
    _put4_1__tmp_at159_18382 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_18341)) {
        _10329 = _tables_18341 + 4;
        if ((long)((unsigned long)_10329 + (unsigned long)HIGH_BITS) >= 0) 
        _10329 = NewDouble((double)_10329);
    }
    else {
        _10329 = NewDouble(DBL_PTR(_tables_18341)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_18385);
    _pos_inlined_seek_at_193_18385 = _10329;
    _10329 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_18385);
    DeRef(_seek_1__tmp_at196_18387);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_18385;
    _seek_1__tmp_at196_18387 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_18386 = machine(19, _seek_1__tmp_at196_18387);
    DeRef(_pos_inlined_seek_at_193_18385);
    _pos_inlined_seek_at_193_18385 = NOVALUE;
    DeRef(_seek_1__tmp_at196_18387);
    _seek_1__tmp_at196_18387 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_18340)) {
        _10330 = _nt_18340 - 1;
        if ((long)((unsigned long)_10330 +(unsigned long) HIGH_BITS) >= 0){
            _10330 = NewDouble((double)_10330);
        }
    }
    else {
        _10330 = NewDouble(DBL_PTR(_nt_18340)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10330)) {
        if (_10330 == (short)_10330)
        _10331 = _10330 * 16;
        else
        _10331 = NewDouble(_10330 * (double)16);
    }
    else {
        _10331 = NewDouble(DBL_PTR(_10330)->dbl * (double)16);
    }
    DeRef(_10330);
    _10330 = NOVALUE;
    _0 = _remaining_18348;
    _remaining_18348 = _8get_bytes(_49current_db_17054, _10331);
    DeRef(_0);
    _10331 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_18342)) {
        _10333 = _newtables_18342 + 4;
        if ((long)((unsigned long)_10333 + (unsigned long)HIGH_BITS) >= 0) 
        _10333 = NewDouble((double)_10333);
    }
    else {
        _10333 = NewDouble(DBL_PTR(_newtables_18342)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_18393);
    _pos_inlined_seek_at_236_18393 = _10333;
    _10333 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_18393);
    DeRef(_seek_1__tmp_at239_18395);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_18393;
    _seek_1__tmp_at239_18395 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_18394 = machine(19, _seek_1__tmp_at239_18395);
    DeRef(_pos_inlined_seek_at_236_18393);
    _pos_inlined_seek_at_236_18393 = NOVALUE;
    DeRef(_seek_1__tmp_at239_18395);
    _seek_1__tmp_at239_18395 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_18348); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_18346)) {
        _10334 = _newsize_18346 - 4;
        if ((long)((unsigned long)_10334 +(unsigned long) HIGH_BITS) >= 0){
            _10334 = NewDouble((double)_10334);
        }
    }
    else {
        _10334 = NewDouble(DBL_PTR(_newsize_18346)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_18340)) {
        _10335 = _nt_18340 - 1;
        if ((long)((unsigned long)_10335 +(unsigned long) HIGH_BITS) >= 0){
            _10335 = NewDouble((double)_10335);
        }
    }
    else {
        _10335 = NewDouble(DBL_PTR(_nt_18340)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10335)) {
        if (_10335 == (short)_10335)
        _10336 = _10335 * 16;
        else
        _10336 = NewDouble(_10335 * (double)16);
    }
    else {
        _10336 = NewDouble(DBL_PTR(_10335)->dbl * (double)16);
    }
    DeRef(_10335);
    _10335 = NOVALUE;
    if (IS_ATOM_INT(_10334) && IS_ATOM_INT(_10336)) {
        _10337 = _10334 - _10336;
    }
    else {
        if (IS_ATOM_INT(_10334)) {
            _10337 = NewDouble((double)_10334 - DBL_PTR(_10336)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10336)) {
                _10337 = NewDouble(DBL_PTR(_10334)->dbl - (double)_10336);
            }
            else
            _10337 = NewDouble(DBL_PTR(_10334)->dbl - DBL_PTR(_10336)->dbl);
        }
    }
    DeRef(_10334);
    _10334 = NOVALUE;
    DeRef(_10336);
    _10336 = NOVALUE;
    _10338 = Repeat(0, _10337);
    DeRef(_10337);
    _10337 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_18403);
    _s_inlined_putn_at_288_18403 = _10338;
    _10338 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_288_18403); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_18403);
    _s_inlined_putn_at_288_18403 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_18341);
    _49db_free(_tables_18341);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_18406);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_18406 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_18405 = machine(19, _seek_1__tmp_at316_18406);
    DeRefi(_seek_1__tmp_at316_18406);
    _seek_1__tmp_at316_18406 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_newtables_18342)) {
        *poke4_addr = (unsigned long)_newtables_18342;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_18342)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_18408);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_18408 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at331_18408); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_18408);
    _put4_1__tmp_at331_18408 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_18342);
    DeRef(_tables_18341);
    _tables_18341 = _newtables_18342;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18341);
    DeRef(_seek_1__tmp_at369_18412);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _tables_18341;
    _seek_1__tmp_at369_18412 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_18411 = machine(19, _seek_1__tmp_at369_18412);
    DeRef(_seek_1__tmp_at369_18412);
    _seek_1__tmp_at369_18412 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_nt_18340)) {
        *poke4_addr = (unsigned long)_nt_18340;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18340)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_18414);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_18414 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at384_18414); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_18414);
    _put4_1__tmp_at384_18414 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_18338 == (short)_init_records_18338)
    _10339 = _init_records_18338 * 4;
    else
    _10339 = NewDouble(_init_records_18338 * (double)4);
    _0 = _records_ptr_18344;
    _records_ptr_18344 = _49db_allocate(_10339);
    DeRef(_0);
    _10339 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10341 = _init_records_18338 * 4;
    _10342 = Repeat(0, _10341);
    _10341 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_18420);
    _s_inlined_putn_at_431_18420 = _10342;
    _10342 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_431_18420); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_18420);
    _s_inlined_putn_at_431_18420 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_18349 == (short)_init_index_18349)
    _10343 = _init_index_18349 * 8;
    else
    _10343 = NewDouble(_init_index_18349 * (double)8);
    _0 = _index_ptr_18347;
    _index_ptr_18347 = _49db_allocate(_10343);
    DeRef(_0);
    _10343 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_18424);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_18424 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at462_18424); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_18424);
    _put4_1__tmp_at462_18424 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_18344)) {
        *poke4_addr = (unsigned long)_records_ptr_18344;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_18344)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_18426);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_18426 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at490_18426); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_18426);
    _put4_1__tmp_at490_18426 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10345 = _init_index_18349 - 1;
    if ((long)((unsigned long)_10345 +(unsigned long) HIGH_BITS) >= 0){
        _10345 = NewDouble((double)_10345);
    }
    if (IS_ATOM_INT(_10345)) {
        _10346 = _10345 * 8;
    }
    else {
        _10346 = NewDouble(DBL_PTR(_10345)->dbl * (double)8);
    }
    DeRef(_10345);
    _10345 = NOVALUE;
    _10347 = Repeat(0, _10346);
    DeRef(_10346);
    _10346 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_18431);
    _s_inlined_putn_at_530_18431 = _10347;
    _10347 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_530_18431); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_18431);
    _s_inlined_putn_at_530_18431 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_18337)){
            _10348 = SEQ_PTR(_name_18337)->length;
    }
    else {
        _10348 = 1;
    }
    _10349 = _10348 + 1;
    _10348 = NOVALUE;
    _0 = _name_ptr_18339;
    _name_ptr_18339 = _49db_allocate(_10349);
    DeRef(_0);
    _10349 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_10351, _name_18337, 0);
    DeRef(_s_inlined_putn_at_568_18437);
    _s_inlined_putn_at_568_18437 = _10351;
    _10351 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_568_18437); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_18437);
    _s_inlined_putn_at_568_18437 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_18341)) {
        _10352 = _tables_18341 + 4;
        if ((long)((unsigned long)_10352 + (unsigned long)HIGH_BITS) >= 0) 
        _10352 = NewDouble((double)_10352);
    }
    else {
        _10352 = NewDouble(DBL_PTR(_tables_18341)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_18340)) {
        _10353 = _nt_18340 - 1;
        if ((long)((unsigned long)_10353 +(unsigned long) HIGH_BITS) >= 0){
            _10353 = NewDouble((double)_10353);
        }
    }
    else {
        _10353 = NewDouble(DBL_PTR(_nt_18340)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10353)) {
        if (_10353 == (short)_10353)
        _10354 = _10353 * 16;
        else
        _10354 = NewDouble(_10353 * (double)16);
    }
    else {
        _10354 = NewDouble(DBL_PTR(_10353)->dbl * (double)16);
    }
    DeRef(_10353);
    _10353 = NOVALUE;
    if (IS_ATOM_INT(_10352) && IS_ATOM_INT(_10354)) {
        _10355 = _10352 + _10354;
        if ((long)((unsigned long)_10355 + (unsigned long)HIGH_BITS) >= 0) 
        _10355 = NewDouble((double)_10355);
    }
    else {
        if (IS_ATOM_INT(_10352)) {
            _10355 = NewDouble((double)_10352 + DBL_PTR(_10354)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10354)) {
                _10355 = NewDouble(DBL_PTR(_10352)->dbl + (double)_10354);
            }
            else
            _10355 = NewDouble(DBL_PTR(_10352)->dbl + DBL_PTR(_10354)->dbl);
        }
    }
    DeRef(_10352);
    _10352 = NOVALUE;
    DeRef(_10354);
    _10354 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_18443);
    _pos_inlined_seek_at_607_18443 = _10355;
    _10355 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_18443);
    DeRef(_seek_1__tmp_at610_18445);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_18443;
    _seek_1__tmp_at610_18445 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_18444 = machine(19, _seek_1__tmp_at610_18445);
    DeRef(_pos_inlined_seek_at_607_18443);
    _pos_inlined_seek_at_607_18443 = NOVALUE;
    DeRef(_seek_1__tmp_at610_18445);
    _seek_1__tmp_at610_18445 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_18339)) {
        *poke4_addr = (unsigned long)_name_ptr_18339;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_18339)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_18447);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_18447 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at625_18447); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_18447);
    _put4_1__tmp_at625_18447 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_18449);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_18449 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at653_18449); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_18449);
    _put4_1__tmp_at653_18449 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_18451);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_18451 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at681_18451); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_18451);
    _put4_1__tmp_at681_18451 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_18347)) {
        *poke4_addr = (unsigned long)_index_ptr_18347;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_18347)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_18453);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_18453 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at709_18453); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_18453);
    _put4_1__tmp_at709_18453 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_18337);
    _10356 = _49db_select_table(_name_18337);
    if (_10356 == 0) {
        DeRef(_10356);
        _10356 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_10356) && DBL_PTR(_10356)->dbl == 0.0){
            DeRef(_10356);
            _10356 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_10356);
        _10356 = NOVALUE;
    }
    DeRef(_10356);
    _10356 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_18337);
    DeRef(_name_ptr_18339);
    DeRef(_nt_18340);
    DeRef(_tables_18341);
    DeRef(_newtables_18342);
    DeRef(_table_18343);
    DeRef(_records_ptr_18344);
    DeRef(_size_18345);
    DeRef(_newsize_18346);
    DeRef(_index_ptr_18347);
    DeRef(_remaining_18348);
    return 0;
    ;
}


int _49db_table_list()
{
    int _seek_1__tmp_at120_18712 = NOVALUE;
    int _seek_inlined_seek_at_120_18711 = NOVALUE;
    int _seek_1__tmp_at98_18708 = NOVALUE;
    int _seek_inlined_seek_at_98_18707 = NOVALUE;
    int _pos_inlined_seek_at_95_18706 = NOVALUE;
    int _seek_1__tmp_at42_18696 = NOVALUE;
    int _seek_inlined_seek_at_42_18695 = NOVALUE;
    int _seek_1__tmp_at4_18689 = NOVALUE;
    int _seek_inlined_seek_at_4_18688 = NOVALUE;
    int _table_names_18683 = NOVALUE;
    int _tables_18684 = NOVALUE;
    int _nt_18685 = NOVALUE;
    int _name_18686 = NOVALUE;
    int _10455 = NOVALUE;
    int _10454 = NOVALUE;
    int _10452 = NOVALUE;
    int _10451 = NOVALUE;
    int _10450 = NOVALUE;
    int _10449 = NOVALUE;
    int _10444 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18689);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_18689 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18688 = machine(19, _seek_1__tmp_at4_18689);
    DeRefi(_seek_1__tmp_at4_18689);
    _seek_1__tmp_at4_18689 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_49vLastErrors_17078)){
            _10444 = SEQ_PTR(_49vLastErrors_17078)->length;
    }
    else {
        _10444 = 1;
    }
    if (_10444 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18683);
    DeRef(_tables_18684);
    DeRef(_nt_18685);
    DeRef(_name_18686);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18684;
    _tables_18684 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18684);
    DeRef(_seek_1__tmp_at42_18696);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _tables_18684;
    _seek_1__tmp_at42_18696 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18695 = machine(19, _seek_1__tmp_at42_18696);
    DeRef(_seek_1__tmp_at42_18696);
    _seek_1__tmp_at42_18696 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18685;
    _nt_18685 = _49get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_18683);
    _table_names_18683 = Repeat(0, _nt_18685);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18685)) {
        _10449 = _nt_18685 - 1;
        if ((long)((unsigned long)_10449 +(unsigned long) HIGH_BITS) >= 0){
            _10449 = NewDouble((double)_10449);
        }
    }
    else {
        _10449 = NewDouble(DBL_PTR(_nt_18685)->dbl - (double)1);
    }
    {
        int _i_18700;
        _i_18700 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18700, _10449)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18684)) {
            _10450 = _tables_18684 + 4;
            if ((long)((unsigned long)_10450 + (unsigned long)HIGH_BITS) >= 0) 
            _10450 = NewDouble((double)_10450);
        }
        else {
            _10450 = NewDouble(DBL_PTR(_tables_18684)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_18700)) {
            if (_i_18700 == (short)_i_18700)
            _10451 = _i_18700 * 16;
            else
            _10451 = NewDouble(_i_18700 * (double)16);
        }
        else {
            _10451 = NewDouble(DBL_PTR(_i_18700)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10450) && IS_ATOM_INT(_10451)) {
            _10452 = _10450 + _10451;
            if ((long)((unsigned long)_10452 + (unsigned long)HIGH_BITS) >= 0) 
            _10452 = NewDouble((double)_10452);
        }
        else {
            if (IS_ATOM_INT(_10450)) {
                _10452 = NewDouble((double)_10450 + DBL_PTR(_10451)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10451)) {
                    _10452 = NewDouble(DBL_PTR(_10450)->dbl + (double)_10451);
                }
                else
                _10452 = NewDouble(DBL_PTR(_10450)->dbl + DBL_PTR(_10451)->dbl);
            }
        }
        DeRef(_10450);
        _10450 = NOVALUE;
        DeRef(_10451);
        _10451 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18706);
        _pos_inlined_seek_at_95_18706 = _10452;
        _10452 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18706);
        DeRef(_seek_1__tmp_at98_18708);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_18706;
        _seek_1__tmp_at98_18708 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18707 = machine(19, _seek_1__tmp_at98_18708);
        DeRef(_pos_inlined_seek_at_95_18706);
        _pos_inlined_seek_at_95_18706 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18708);
        _seek_1__tmp_at98_18708 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_18686;
        _name_18686 = _49get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18686);
        DeRef(_seek_1__tmp_at120_18712);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _49current_db_17054;
        ((int *)_2)[2] = _name_18686;
        _seek_1__tmp_at120_18712 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18711 = machine(19, _seek_1__tmp_at120_18712);
        DeRef(_seek_1__tmp_at120_18712);
        _seek_1__tmp_at120_18712 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18700)) {
            _10454 = _i_18700 + 1;
            if (_10454 > MAXINT){
                _10454 = NewDouble((double)_10454);
            }
        }
        else
        _10454 = binary_op(PLUS, 1, _i_18700);
        _10455 = _49get_string();
        _2 = (int)SEQ_PTR(_table_names_18683);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_18683 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10454))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10454)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10454);
        _1 = *(int *)_2;
        *(int *)_2 = _10455;
        if( _1 != _10455 ){
            DeRef(_1);
        }
        _10455 = NOVALUE;

        /** 	end for*/
        _0 = _i_18700;
        if (IS_ATOM_INT(_i_18700)) {
            _i_18700 = _i_18700 + 1;
            if ((long)((unsigned long)_i_18700 +(unsigned long) HIGH_BITS) >= 0){
                _i_18700 = NewDouble((double)_i_18700);
            }
        }
        else {
            _i_18700 = binary_op_a(PLUS, _i_18700, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18700);
    }

    /** 	return table_names*/
    DeRef(_tables_18684);
    DeRef(_nt_18685);
    DeRef(_name_18686);
    DeRef(_10449);
    _10449 = NOVALUE;
    DeRef(_10454);
    _10454 = NOVALUE;
    return _table_names_18683;
    ;
}


int _49key_value(int _ptr_18717)
{
    int _seek_1__tmp_at11_18722 = NOVALUE;
    int _seek_inlined_seek_at_11_18721 = NOVALUE;
    int _pos_inlined_seek_at_8_18720 = NOVALUE;
    int _10457 = NOVALUE;
    int _10456 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18717)) {
        _10456 = _ptr_18717 + 4;
        if ((long)((unsigned long)_10456 + (unsigned long)HIGH_BITS) >= 0) 
        _10456 = NewDouble((double)_10456);
    }
    else {
        _10456 = NewDouble(DBL_PTR(_ptr_18717)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18720);
    _pos_inlined_seek_at_8_18720 = _10456;
    _10456 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18720);
    DeRef(_seek_1__tmp_at11_18722);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18720;
    _seek_1__tmp_at11_18722 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18721 = machine(19, _seek_1__tmp_at11_18722);
    DeRef(_pos_inlined_seek_at_8_18720);
    _pos_inlined_seek_at_8_18720 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18722);
    _seek_1__tmp_at11_18722 = NOVALUE;

    /** 	return decompress(0)*/
    _10457 = _49decompress(0);
    DeRef(_ptr_18717);
    return _10457;
    ;
}


int _49db_find_key(int _key_18726, int _table_name_18727)
{
    int _lo_18728 = NOVALUE;
    int _hi_18729 = NOVALUE;
    int _mid_18730 = NOVALUE;
    int _c_18731 = NOVALUE;
    int _10481 = NOVALUE;
    int _10473 = NOVALUE;
    int _10472 = NOVALUE;
    int _10470 = NOVALUE;
    int _10467 = NOVALUE;
    int _10464 = NOVALUE;
    int _10460 = NOVALUE;
    int _10458 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18727 == _49current_table_name_17056)
    _10458 = 1;
    else if (IS_ATOM_INT(_table_name_18727) && IS_ATOM_INT(_49current_table_name_17056))
    _10458 = 0;
    else
    _10458 = (compare(_table_name_18727, _49current_table_name_17056) == 0);
    if (_10458 != 0)
    goto L1; // [9] 42
    _10458 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18727);
    _10460 = _49db_select_table(_table_name_18727);
    if (binary_op_a(EQUALS, _10460, 0)){
        DeRef(_10460);
        _10460 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10460);
    _10460 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_18727);
    Ref(_key_18726);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18726;
    ((int *)_2)[2] = _table_name_18727;
    _10464 = MAKE_SEQ(_1);
    RefDS(_10462);
    RefDS(_10463);
    _49fatal(903, _10462, _10463, _10464);
    _10464 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18726);
    DeRefDS(_table_name_18727);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17055, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18727);
    Ref(_key_18726);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18726;
    ((int *)_2)[2] = _table_name_18727;
    _10467 = MAKE_SEQ(_1);
    RefDS(_10466);
    RefDS(_10463);
    _49fatal(903, _10466, _10463, _10467);
    _10467 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18726);
    DeRef(_table_name_18727);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18728 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _hi_18729 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _hi_18729 = 1;
    }

    /** 	mid = 1*/
    _mid_18730 = 1;

    /** 	c = 0*/
    _c_18731 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18728 > _hi_18729)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10470 = _lo_18728 + _hi_18729;
    if ((long)((unsigned long)_10470 + (unsigned long)HIGH_BITS) >= 0) 
    _10470 = NewDouble((double)_10470);
    if (IS_ATOM_INT(_10470)) {
        _mid_18730 = _10470 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10470, 2);
        _mid_18730 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10470);
    _10470 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18730)) {
        _1 = (long)(DBL_PTR(_mid_18730)->dbl);
        DeRefDS(_mid_18730);
        _mid_18730 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_49key_pointers_17061);
    _10472 = (int)*(((s1_ptr)_2)->base + _mid_18730);
    Ref(_10472);
    _10473 = _49key_value(_10472);
    _10472 = NOVALUE;
    if (IS_ATOM_INT(_key_18726) && IS_ATOM_INT(_10473)){
        _c_18731 = (_key_18726 < _10473) ? -1 : (_key_18726 > _10473);
    }
    else{
        _c_18731 = compare(_key_18726, _10473);
    }
    DeRef(_10473);
    _10473 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18731 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18729 = _mid_18730 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18731 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18728 = _mid_18730 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_18726);
    DeRef(_table_name_18727);
    return _mid_18730;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_18731 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_18730 = _mid_18730 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_18730 == 0xC0000000)
    _10481 = (int)NewDouble((double)-0xC0000000);
    else
    _10481 = - _mid_18730;
    DeRef(_key_18726);
    DeRef(_table_name_18727);
    return _10481;
    ;
}


int _49db_insert(int _key_18766, int _data_18767, int _table_name_18768)
{
    int _key_string_18769 = NOVALUE;
    int _data_string_18770 = NOVALUE;
    int _last_part_18771 = NOVALUE;
    int _remaining_18772 = NOVALUE;
    int _key_ptr_18773 = NOVALUE;
    int _data_ptr_18774 = NOVALUE;
    int _records_ptr_18775 = NOVALUE;
    int _nrecs_18776 = NOVALUE;
    int _current_block_18777 = NOVALUE;
    int _size_18778 = NOVALUE;
    int _new_size_18779 = NOVALUE;
    int _key_location_18780 = NOVALUE;
    int _new_block_18781 = NOVALUE;
    int _index_ptr_18782 = NOVALUE;
    int _new_index_ptr_18783 = NOVALUE;
    int _total_recs_18784 = NOVALUE;
    int _r_18785 = NOVALUE;
    int _blocks_18786 = NOVALUE;
    int _new_recs_18787 = NOVALUE;
    int _n_18788 = NOVALUE;
    int _put4_1__tmp_at79_18802 = NOVALUE;
    int _seek_1__tmp_at132_18808 = NOVALUE;
    int _seek_inlined_seek_at_132_18807 = NOVALUE;
    int _pos_inlined_seek_at_129_18806 = NOVALUE;
    int _seek_1__tmp_at174_18816 = NOVALUE;
    int _seek_inlined_seek_at_174_18815 = NOVALUE;
    int _pos_inlined_seek_at_171_18814 = NOVALUE;
    int _put4_1__tmp_at189_18818 = NOVALUE;
    int _seek_1__tmp_at317_18836 = NOVALUE;
    int _seek_inlined_seek_at_317_18835 = NOVALUE;
    int _pos_inlined_seek_at_314_18834 = NOVALUE;
    int _seek_1__tmp_at339_18840 = NOVALUE;
    int _seek_inlined_seek_at_339_18839 = NOVALUE;
    int _where_inlined_where_at_404_18849 = NOVALUE;
    int _seek_1__tmp_at448_18859 = NOVALUE;
    int _seek_inlined_seek_at_448_18858 = NOVALUE;
    int _pos_inlined_seek_at_445_18857 = NOVALUE;
    int _put4_1__tmp_at493_18868 = NOVALUE;
    int _x_inlined_put4_at_490_18867 = NOVALUE;
    int _seek_1__tmp_at530_18871 = NOVALUE;
    int _seek_inlined_seek_at_530_18870 = NOVALUE;
    int _put4_1__tmp_at551_18874 = NOVALUE;
    int _seek_1__tmp_at588_18879 = NOVALUE;
    int _seek_inlined_seek_at_588_18878 = NOVALUE;
    int _pos_inlined_seek_at_585_18877 = NOVALUE;
    int _seek_1__tmp_at690_18904 = NOVALUE;
    int _seek_inlined_seek_at_690_18903 = NOVALUE;
    int _pos_inlined_seek_at_687_18902 = NOVALUE;
    int _s_inlined_putn_at_751_18913 = NOVALUE;
    int _seek_1__tmp_at774_18916 = NOVALUE;
    int _seek_inlined_seek_at_774_18915 = NOVALUE;
    int _put4_1__tmp_at796_18920 = NOVALUE;
    int _x_inlined_put4_at_793_18919 = NOVALUE;
    int _seek_1__tmp_at833_18925 = NOVALUE;
    int _seek_inlined_seek_at_833_18924 = NOVALUE;
    int _pos_inlined_seek_at_830_18923 = NOVALUE;
    int _seek_1__tmp_at884_18935 = NOVALUE;
    int _seek_inlined_seek_at_884_18934 = NOVALUE;
    int _pos_inlined_seek_at_881_18933 = NOVALUE;
    int _put4_1__tmp_at899_18937 = NOVALUE;
    int _put4_1__tmp_at927_18939 = NOVALUE;
    int _seek_1__tmp_at980_18945 = NOVALUE;
    int _seek_inlined_seek_at_980_18944 = NOVALUE;
    int _pos_inlined_seek_at_977_18943 = NOVALUE;
    int _put4_1__tmp_at1001_18948 = NOVALUE;
    int _seek_1__tmp_at1038_18953 = NOVALUE;
    int _seek_inlined_seek_at_1038_18952 = NOVALUE;
    int _pos_inlined_seek_at_1035_18951 = NOVALUE;
    int _s_inlined_putn_at_1136_18971 = NOVALUE;
    int _seek_1__tmp_at1173_18976 = NOVALUE;
    int _seek_inlined_seek_at_1173_18975 = NOVALUE;
    int _pos_inlined_seek_at_1170_18974 = NOVALUE;
    int _put4_1__tmp_at1188_18978 = NOVALUE;
    int _10577 = NOVALUE;
    int _10576 = NOVALUE;
    int _10575 = NOVALUE;
    int _10574 = NOVALUE;
    int _10571 = NOVALUE;
    int _10570 = NOVALUE;
    int _10568 = NOVALUE;
    int _10566 = NOVALUE;
    int _10565 = NOVALUE;
    int _10563 = NOVALUE;
    int _10562 = NOVALUE;
    int _10560 = NOVALUE;
    int _10559 = NOVALUE;
    int _10557 = NOVALUE;
    int _10556 = NOVALUE;
    int _10555 = NOVALUE;
    int _10554 = NOVALUE;
    int _10553 = NOVALUE;
    int _10552 = NOVALUE;
    int _10551 = NOVALUE;
    int _10550 = NOVALUE;
    int _10549 = NOVALUE;
    int _10546 = NOVALUE;
    int _10545 = NOVALUE;
    int _10544 = NOVALUE;
    int _10543 = NOVALUE;
    int _10540 = NOVALUE;
    int _10537 = NOVALUE;
    int _10536 = NOVALUE;
    int _10535 = NOVALUE;
    int _10534 = NOVALUE;
    int _10530 = NOVALUE;
    int _10529 = NOVALUE;
    int _10527 = NOVALUE;
    int _10526 = NOVALUE;
    int _10524 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10521 = NOVALUE;
    int _10520 = NOVALUE;
    int _10519 = NOVALUE;
    int _10518 = NOVALUE;
    int _10516 = NOVALUE;
    int _10513 = NOVALUE;
    int _10508 = NOVALUE;
    int _10506 = NOVALUE;
    int _10505 = NOVALUE;
    int _10503 = NOVALUE;
    int _10502 = NOVALUE;
    int _10501 = NOVALUE;
    int _10498 = NOVALUE;
    int _10496 = NOVALUE;
    int _10493 = NOVALUE;
    int _10492 = NOVALUE;
    int _10490 = NOVALUE;
    int _10489 = NOVALUE;
    int _10487 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_18766);
    RefDS(_table_name_18768);
    _0 = _key_location_18780;
    _key_location_18780 = _49db_find_key(_key_18766, _table_name_18768);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_18780, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_18766);
    DeRefDS(_table_name_18768);
    DeRef(_key_string_18769);
    DeRef(_data_string_18770);
    DeRef(_last_part_18771);
    DeRef(_remaining_18772);
    DeRef(_key_ptr_18773);
    DeRef(_data_ptr_18774);
    DeRef(_records_ptr_18775);
    DeRef(_nrecs_18776);
    DeRef(_current_block_18777);
    DeRef(_size_18778);
    DeRef(_new_size_18779);
    DeRef(_key_location_18780);
    DeRef(_new_block_18781);
    DeRef(_index_ptr_18782);
    DeRef(_new_index_ptr_18783);
    DeRef(_total_recs_18784);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_18780;
    if (IS_ATOM_INT(_key_location_18780)) {
        if ((unsigned long)_key_location_18780 == 0xC0000000)
        _key_location_18780 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_18780 = - _key_location_18780;
    }
    else {
        _key_location_18780 = unary_op(UMINUS, _key_location_18780);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    _0 = _data_string_18770;
    _data_string_18770 = _49compress(_data_18767);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_18766);
    _0 = _key_string_18769;
    _key_string_18769 = _49compress(_key_18766);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_18770)){
            _10487 = SEQ_PTR(_data_string_18770)->length;
    }
    else {
        _10487 = 1;
    }
    _0 = _data_ptr_18774;
    _data_ptr_18774 = _49db_allocate(_10487);
    DeRef(_0);
    _10487 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _data_string_18770); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_18769)){
            _10489 = SEQ_PTR(_key_string_18769)->length;
    }
    else {
        _10489 = 1;
    }
    _10490 = 4 + _10489;
    _10489 = NOVALUE;
    _0 = _key_ptr_18773;
    _key_ptr_18773 = _49db_allocate(_10490);
    DeRef(_0);
    _10490 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18774)) {
        *poke4_addr = (unsigned long)_data_ptr_18774;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18774)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_18802);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_18802 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at79_18802); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_18802);
    _put4_1__tmp_at79_18802 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _key_string_18769); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_49current_table_pos_17055)) {
        _10492 = _49current_table_pos_17055 + 4;
        if ((long)((unsigned long)_10492 + (unsigned long)HIGH_BITS) >= 0) 
        _10492 = NewDouble((double)_10492);
    }
    else {
        _10492 = NewDouble(DBL_PTR(_49current_table_pos_17055)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_18806);
    _pos_inlined_seek_at_129_18806 = _10492;
    _10492 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_18806);
    DeRef(_seek_1__tmp_at132_18808);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_18806;
    _seek_1__tmp_at132_18808 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_18807 = machine(19, _seek_1__tmp_at132_18808);
    DeRef(_pos_inlined_seek_at_129_18806);
    _pos_inlined_seek_at_129_18806 = NOVALUE;
    DeRef(_seek_1__tmp_at132_18808);
    _seek_1__tmp_at132_18808 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10493 = _49get4();
    DeRef(_total_recs_18784);
    if (IS_ATOM_INT(_10493)) {
        _total_recs_18784 = _10493 + 1;
        if (_total_recs_18784 > MAXINT){
            _total_recs_18784 = NewDouble((double)_total_recs_18784);
        }
    }
    else
    _total_recs_18784 = binary_op(PLUS, 1, _10493);
    DeRef(_10493);
    _10493 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18786 = _49get4();
    if (!IS_ATOM_INT(_blocks_18786)) {
        _1 = (long)(DBL_PTR(_blocks_18786)->dbl);
        DeRefDS(_blocks_18786);
        _blocks_18786 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_49current_table_pos_17055)) {
        _10496 = _49current_table_pos_17055 + 4;
        if ((long)((unsigned long)_10496 + (unsigned long)HIGH_BITS) >= 0) 
        _10496 = NewDouble((double)_10496);
    }
    else {
        _10496 = NewDouble(DBL_PTR(_49current_table_pos_17055)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_18814);
    _pos_inlined_seek_at_171_18814 = _10496;
    _10496 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_18814);
    DeRef(_seek_1__tmp_at174_18816);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_18814;
    _seek_1__tmp_at174_18816 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_18815 = machine(19, _seek_1__tmp_at174_18816);
    DeRef(_pos_inlined_seek_at_171_18814);
    _pos_inlined_seek_at_171_18814 = NOVALUE;
    DeRef(_seek_1__tmp_at174_18816);
    _seek_1__tmp_at174_18816 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_18784)) {
        *poke4_addr = (unsigned long)_total_recs_18784;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_18784)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_18818);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_18818 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at189_18818); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_18818);
    _put4_1__tmp_at189_18818 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _n_18788 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _n_18788 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10498 = _n_18788 >> 1;
    if (binary_op_a(LESS, _key_location_18780, _10498)){
        _10498 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10498);
    _10498 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_49key_pointers_17061, _49key_pointers_17061, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_18780)) {
        _10501 = _key_location_18780 + 1;
        if (_10501 > MAXINT){
            _10501 = NewDouble((double)_10501);
        }
    }
    else
    _10501 = binary_op(PLUS, 1, _key_location_18780);
    _10502 = _n_18788 + 1;
    rhs_slice_target = (object_ptr)&_10503;
    RHS_Slice(_49key_pointers_17061, _key_location_18780, _n_18788);
    assign_slice_seq = (s1_ptr *)&_49key_pointers_17061;
    AssignSlice(_10501, _10502, _10503);
    DeRef(_10501);
    _10501 = NOVALUE;
    _10502 = NOVALUE;
    DeRefDS(_10503);
    _10503 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_49key_pointers_17061, _49key_pointers_17061, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_18780)) {
        _10505 = _key_location_18780 - 1;
        if ((long)((unsigned long)_10505 +(unsigned long) HIGH_BITS) >= 0){
            _10505 = NewDouble((double)_10505);
        }
    }
    else {
        _10505 = NewDouble(DBL_PTR(_key_location_18780)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10506;
    RHS_Slice(_49key_pointers_17061, 2, _key_location_18780);
    assign_slice_seq = (s1_ptr *)&_49key_pointers_17061;
    AssignSlice(1, _10505, _10506);
    DeRef(_10505);
    _10505 = NOVALUE;
    DeRefDS(_10506);
    _10506 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_18773);
    _2 = (int)SEQ_PTR(_49key_pointers_17061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _49key_pointers_17061 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_18780))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_18780)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_18780);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_18773;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_49current_table_pos_17055)) {
        _10508 = _49current_table_pos_17055 + 12;
        if ((long)((unsigned long)_10508 + (unsigned long)HIGH_BITS) >= 0) 
        _10508 = NewDouble((double)_10508);
    }
    else {
        _10508 = NewDouble(DBL_PTR(_49current_table_pos_17055)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_18834);
    _pos_inlined_seek_at_314_18834 = _10508;
    _10508 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_18834);
    DeRef(_seek_1__tmp_at317_18836);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_18834;
    _seek_1__tmp_at317_18836 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_18835 = machine(19, _seek_1__tmp_at317_18836);
    DeRef(_pos_inlined_seek_at_314_18834);
    _pos_inlined_seek_at_314_18834 = NOVALUE;
    DeRef(_seek_1__tmp_at317_18836);
    _seek_1__tmp_at317_18836 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18782;
    _index_ptr_18782 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18782);
    DeRef(_seek_1__tmp_at339_18840);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _index_ptr_18782;
    _seek_1__tmp_at339_18840 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_18839 = machine(19, _seek_1__tmp_at339_18840);
    DeRef(_seek_1__tmp_at339_18840);
    _seek_1__tmp_at339_18840 = NOVALUE;

    /** 	r = 0*/
    _r_18785 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18776;
    _nrecs_18776 = _49get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18775;
    _records_ptr_18775 = _49get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _r_18785 = _r_18785 + _nrecs_18776;
    }
    else {
        _r_18785 = NewDouble((double)_r_18785 + DBL_PTR(_nrecs_18776)->dbl);
    }
    if (!IS_ATOM_INT(_r_18785)) {
        _1 = (long)(DBL_PTR(_r_18785)->dbl);
        DeRefDS(_r_18785);
        _r_18785 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10513 = _r_18785 + 1;
    if (_10513 > MAXINT){
        _10513 = NewDouble((double)_10513);
    }
    if (binary_op_a(LESS, _10513, _key_location_18780)){
        DeRef(_10513);
        _10513 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10513);
    _10513 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_18849);
    _where_inlined_where_at_404_18849 = machine(20, _49current_db_17054);
    DeRef(_current_block_18777);
    if (IS_ATOM_INT(_where_inlined_where_at_404_18849)) {
        _current_block_18777 = _where_inlined_where_at_404_18849 - 8;
        if ((long)((unsigned long)_current_block_18777 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18777 = NewDouble((double)_current_block_18777);
        }
    }
    else {
        _current_block_18777 = NewDouble(DBL_PTR(_where_inlined_where_at_404_18849)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _10516 = _r_18785 - _nrecs_18776;
        if ((long)((unsigned long)_10516 +(unsigned long) HIGH_BITS) >= 0){
            _10516 = NewDouble((double)_10516);
        }
    }
    else {
        _10516 = NewDouble((double)_r_18785 - DBL_PTR(_nrecs_18776)->dbl);
    }
    _0 = _key_location_18780;
    if (IS_ATOM_INT(_key_location_18780) && IS_ATOM_INT(_10516)) {
        _key_location_18780 = _key_location_18780 - _10516;
        if ((long)((unsigned long)_key_location_18780 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_18780 = NewDouble((double)_key_location_18780);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_18780)) {
            _key_location_18780 = NewDouble((double)_key_location_18780 - DBL_PTR(_10516)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10516)) {
                _key_location_18780 = NewDouble(DBL_PTR(_key_location_18780)->dbl - (double)_10516);
            }
            else
            _key_location_18780 = NewDouble(DBL_PTR(_key_location_18780)->dbl - DBL_PTR(_10516)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10516);
    _10516 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_18780)) {
        _10518 = _key_location_18780 - 1;
        if ((long)((unsigned long)_10518 +(unsigned long) HIGH_BITS) >= 0){
            _10518 = NewDouble((double)_10518);
        }
    }
    else {
        _10518 = NewDouble(DBL_PTR(_key_location_18780)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10518)) {
        if (_10518 <= INT15 && _10518 >= -INT15)
        _10519 = 4 * _10518;
        else
        _10519 = NewDouble(4 * (double)_10518);
    }
    else {
        _10519 = NewDouble((double)4 * DBL_PTR(_10518)->dbl);
    }
    DeRef(_10518);
    _10518 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18775) && IS_ATOM_INT(_10519)) {
        _10520 = _records_ptr_18775 + _10519;
        if ((long)((unsigned long)_10520 + (unsigned long)HIGH_BITS) >= 0) 
        _10520 = NewDouble((double)_10520);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18775)) {
            _10520 = NewDouble((double)_records_ptr_18775 + DBL_PTR(_10519)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10519)) {
                _10520 = NewDouble(DBL_PTR(_records_ptr_18775)->dbl + (double)_10519);
            }
            else
            _10520 = NewDouble(DBL_PTR(_records_ptr_18775)->dbl + DBL_PTR(_10519)->dbl);
        }
    }
    DeRef(_10519);
    _10519 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_18857);
    _pos_inlined_seek_at_445_18857 = _10520;
    _10520 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_18857);
    DeRef(_seek_1__tmp_at448_18859);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_18857;
    _seek_1__tmp_at448_18859 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_18858 = machine(19, _seek_1__tmp_at448_18859);
    DeRef(_pos_inlined_seek_at_445_18857);
    _pos_inlined_seek_at_445_18857 = NOVALUE;
    DeRef(_seek_1__tmp_at448_18859);
    _seek_1__tmp_at448_18859 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _10521 = _nrecs_18776 + 1;
        if (_10521 > MAXINT){
            _10521 = NewDouble((double)_10521);
        }
    }
    else
    _10521 = binary_op(PLUS, 1, _nrecs_18776);
    {
        int _i_18861;
        Ref(_key_location_18780);
        _i_18861 = _key_location_18780;
LA: 
        if (binary_op_a(GREATER, _i_18861, _10521)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_18861)) {
            _10522 = _i_18861 + _r_18785;
            if ((long)((unsigned long)_10522 + (unsigned long)HIGH_BITS) >= 0) 
            _10522 = NewDouble((double)_10522);
        }
        else {
            _10522 = NewDouble(DBL_PTR(_i_18861)->dbl + (double)_r_18785);
        }
        if (IS_ATOM_INT(_10522) && IS_ATOM_INT(_nrecs_18776)) {
            _10523 = _10522 - _nrecs_18776;
        }
        else {
            if (IS_ATOM_INT(_10522)) {
                _10523 = NewDouble((double)_10522 - DBL_PTR(_nrecs_18776)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_18776)) {
                    _10523 = NewDouble(DBL_PTR(_10522)->dbl - (double)_nrecs_18776);
                }
                else
                _10523 = NewDouble(DBL_PTR(_10522)->dbl - DBL_PTR(_nrecs_18776)->dbl);
            }
        }
        DeRef(_10522);
        _10522 = NOVALUE;
        _2 = (int)SEQ_PTR(_49key_pointers_17061);
        if (!IS_ATOM_INT(_10523)){
            _10524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10523)->dbl));
        }
        else{
            _10524 = (int)*(((s1_ptr)_2)->base + _10523);
        }
        Ref(_10524);
        DeRef(_x_inlined_put4_at_490_18867);
        _x_inlined_put4_at_490_18867 = _10524;
        _10524 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_49mem0_17096)){
            poke4_addr = (unsigned long *)_49mem0_17096;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_18867)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_18867;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_18867)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_18867)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_18867);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_18868);
        _1 = (int)SEQ_PTR(_49memseq_17331);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_18868 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_49current_db_17054, _put4_1__tmp_at493_18868); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_18867);
        _x_inlined_put4_at_490_18867 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_18868);
        _put4_1__tmp_at493_18868 = NOVALUE;

        /** 	end for*/
        _0 = _i_18861;
        if (IS_ATOM_INT(_i_18861)) {
            _i_18861 = _i_18861 + 1;
            if ((long)((unsigned long)_i_18861 +(unsigned long) HIGH_BITS) >= 0){
                _i_18861 = NewDouble((double)_i_18861);
            }
        }
        else {
            _i_18861 = binary_op_a(PLUS, _i_18861, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_18861);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18777);
    DeRef(_seek_1__tmp_at530_18871);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _current_block_18777;
    _seek_1__tmp_at530_18871 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_18870 = machine(19, _seek_1__tmp_at530_18871);
    DeRef(_seek_1__tmp_at530_18871);
    _seek_1__tmp_at530_18871 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_18776;
    if (IS_ATOM_INT(_nrecs_18776)) {
        _nrecs_18776 = _nrecs_18776 + 1;
        if (_nrecs_18776 > MAXINT){
            _nrecs_18776 = NewDouble((double)_nrecs_18776);
        }
    }
    else
    _nrecs_18776 = binary_op(PLUS, 1, _nrecs_18776);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18776)) {
        *poke4_addr = (unsigned long)_nrecs_18776;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18776)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_18874);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_18874 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at551_18874); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_18874);
    _put4_1__tmp_at551_18874 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_18775)) {
        _10526 = _records_ptr_18775 - 4;
        if ((long)((unsigned long)_10526 +(unsigned long) HIGH_BITS) >= 0){
            _10526 = NewDouble((double)_10526);
        }
    }
    else {
        _10526 = NewDouble(DBL_PTR(_records_ptr_18775)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_18877);
    _pos_inlined_seek_at_585_18877 = _10526;
    _10526 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_18877);
    DeRef(_seek_1__tmp_at588_18879);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_18877;
    _seek_1__tmp_at588_18879 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_18878 = machine(19, _seek_1__tmp_at588_18879);
    DeRef(_pos_inlined_seek_at_585_18877);
    _pos_inlined_seek_at_585_18877 = NOVALUE;
    DeRef(_seek_1__tmp_at588_18879);
    _seek_1__tmp_at588_18879 = NOVALUE;

    /** 	size = get4() - 4*/
    _10527 = _49get4();
    DeRef(_size_18778);
    if (IS_ATOM_INT(_10527)) {
        _size_18778 = _10527 - 4;
        if ((long)((unsigned long)_size_18778 +(unsigned long) HIGH_BITS) >= 0){
            _size_18778 = NewDouble((double)_size_18778);
        }
    }
    else {
        _size_18778 = binary_op(MINUS, _10527, 4);
    }
    DeRef(_10527);
    _10527 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        if (_nrecs_18776 == (short)_nrecs_18776)
        _10529 = _nrecs_18776 * 4;
        else
        _10529 = NewDouble(_nrecs_18776 * (double)4);
    }
    else {
        _10529 = NewDouble(DBL_PTR(_nrecs_18776)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_18778)) {
        _10530 = _size_18778 - 4;
        if ((long)((unsigned long)_10530 +(unsigned long) HIGH_BITS) >= 0){
            _10530 = NewDouble((double)_10530);
        }
    }
    else {
        _10530 = NewDouble(DBL_PTR(_size_18778)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10529, _10530)){
        DeRef(_10529);
        _10529 = NOVALUE;
        DeRef(_10530);
        _10530 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10529);
    _10529 = NOVALUE;
    DeRef(_10530);
    _10530 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_18784)) {
        _10534 = NewDouble(DBL_PTR(_10533)->dbl * (double)_total_recs_18784);
    }
    else
    _10534 = NewDouble(DBL_PTR(_10533)->dbl * DBL_PTR(_total_recs_18784)->dbl);
    _10535 = unary_op(SQRT, _10534);
    DeRefDS(_10534);
    _10534 = NOVALUE;
    _10536 = unary_op(FLOOR, _10535);
    DeRefDS(_10535);
    _10535 = NOVALUE;
    if (IS_ATOM_INT(_10536)) {
        _10537 = 20 + _10536;
        if ((long)((unsigned long)_10537 + (unsigned long)HIGH_BITS) >= 0) 
        _10537 = NewDouble((double)_10537);
    }
    else {
        _10537 = NewDouble((double)20 + DBL_PTR(_10536)->dbl);
    }
    DeRef(_10536);
    _10536 = NOVALUE;
    DeRef(_new_size_18779);
    if (IS_ATOM_INT(_10537)) {
        if (_10537 <= INT15 && _10537 >= -INT15)
        _new_size_18779 = 8 * _10537;
        else
        _new_size_18779 = NewDouble(8 * (double)_10537);
    }
    else {
        _new_size_18779 = NewDouble((double)8 * DBL_PTR(_10537)->dbl);
    }
    DeRef(_10537);
    _10537 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_18779)) {
        if (8 > 0 && _new_size_18779 >= 0) {
            _new_recs_18787 = _new_size_18779 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_18779 / (double)8);
            _new_recs_18787 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_18779, 8);
        _new_recs_18787 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_18787)) {
        _1 = (long)(DBL_PTR(_new_recs_18787)->dbl);
        DeRefDS(_new_recs_18787);
        _new_recs_18787 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _10540 = _nrecs_18776 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18776, 2);
        _10540 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_18787, _10540)){
        DeRef(_10540);
        _10540 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10540);
    _10540 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _new_recs_18787 = _nrecs_18776 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18776, 2);
        _new_recs_18787 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_18787)) {
        _1 = (long)(DBL_PTR(_new_recs_18787)->dbl);
        DeRefDS(_new_recs_18787);
        _new_recs_18787 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _10543 = _nrecs_18776 - _new_recs_18787;
        if ((long)((unsigned long)_10543 +(unsigned long) HIGH_BITS) >= 0){
            _10543 = NewDouble((double)_10543);
        }
    }
    else {
        _10543 = NewDouble(DBL_PTR(_nrecs_18776)->dbl - (double)_new_recs_18787);
    }
    if (IS_ATOM_INT(_10543)) {
        if (_10543 == (short)_10543)
        _10544 = _10543 * 4;
        else
        _10544 = NewDouble(_10543 * (double)4);
    }
    else {
        _10544 = NewDouble(DBL_PTR(_10543)->dbl * (double)4);
    }
    DeRef(_10543);
    _10543 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18775) && IS_ATOM_INT(_10544)) {
        _10545 = _records_ptr_18775 + _10544;
        if ((long)((unsigned long)_10545 + (unsigned long)HIGH_BITS) >= 0) 
        _10545 = NewDouble((double)_10545);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18775)) {
            _10545 = NewDouble((double)_records_ptr_18775 + DBL_PTR(_10544)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10544)) {
                _10545 = NewDouble(DBL_PTR(_records_ptr_18775)->dbl + (double)_10544);
            }
            else
            _10545 = NewDouble(DBL_PTR(_records_ptr_18775)->dbl + DBL_PTR(_10544)->dbl);
        }
    }
    DeRef(_10544);
    _10544 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_18902);
    _pos_inlined_seek_at_687_18902 = _10545;
    _10545 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_18902);
    DeRef(_seek_1__tmp_at690_18904);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_18902;
    _seek_1__tmp_at690_18904 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_18903 = machine(19, _seek_1__tmp_at690_18904);
    DeRef(_pos_inlined_seek_at_687_18902);
    _pos_inlined_seek_at_687_18902 = NOVALUE;
    DeRef(_seek_1__tmp_at690_18904);
    _seek_1__tmp_at690_18904 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_18787 == (short)_new_recs_18787)
    _10546 = _new_recs_18787 * 4;
    else
    _10546 = NewDouble(_new_recs_18787 * (double)4);
    _0 = _last_part_18771;
    _last_part_18771 = _8get_bytes(_49current_db_17054, _10546);
    DeRef(_0);
    _10546 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_18779);
    _0 = _new_block_18781;
    _new_block_18781 = _49db_allocate(_new_size_18779);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _last_part_18771); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_18771)){
            _10549 = SEQ_PTR(_last_part_18771)->length;
    }
    else {
        _10549 = 1;
    }
    if (IS_ATOM_INT(_new_size_18779)) {
        _10550 = _new_size_18779 - _10549;
    }
    else {
        _10550 = NewDouble(DBL_PTR(_new_size_18779)->dbl - (double)_10549);
    }
    _10549 = NOVALUE;
    _10551 = Repeat(0, _10550);
    DeRef(_10550);
    _10550 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_18913);
    _s_inlined_putn_at_751_18913 = _10551;
    _10551 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_751_18913); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_18913);
    _s_inlined_putn_at_751_18913 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18777);
    DeRef(_seek_1__tmp_at774_18916);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _current_block_18777;
    _seek_1__tmp_at774_18916 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_18915 = machine(19, _seek_1__tmp_at774_18916);
    DeRef(_seek_1__tmp_at774_18916);
    _seek_1__tmp_at774_18916 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_18776)) {
        _10552 = _nrecs_18776 - _new_recs_18787;
        if ((long)((unsigned long)_10552 +(unsigned long) HIGH_BITS) >= 0){
            _10552 = NewDouble((double)_10552);
        }
    }
    else {
        _10552 = NewDouble(DBL_PTR(_nrecs_18776)->dbl - (double)_new_recs_18787);
    }
    DeRef(_x_inlined_put4_at_793_18919);
    _x_inlined_put4_at_793_18919 = _10552;
    _10552 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_18919)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_18919;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_18919)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_18920);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_18920 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at796_18920); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_18919);
    _x_inlined_put4_at_793_18919 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_18920);
    _put4_1__tmp_at796_18920 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18777)) {
        _10553 = _current_block_18777 + 8;
        if ((long)((unsigned long)_10553 + (unsigned long)HIGH_BITS) >= 0) 
        _10553 = NewDouble((double)_10553);
    }
    else {
        _10553 = NewDouble(DBL_PTR(_current_block_18777)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_18923);
    _pos_inlined_seek_at_830_18923 = _10553;
    _10553 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_18923);
    DeRef(_seek_1__tmp_at833_18925);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_18923;
    _seek_1__tmp_at833_18925 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_18924 = machine(19, _seek_1__tmp_at833_18925);
    DeRef(_pos_inlined_seek_at_830_18923);
    _pos_inlined_seek_at_830_18923 = NOVALUE;
    DeRef(_seek_1__tmp_at833_18925);
    _seek_1__tmp_at833_18925 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18786 == (short)_blocks_18786)
    _10554 = _blocks_18786 * 8;
    else
    _10554 = NewDouble(_blocks_18786 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18782) && IS_ATOM_INT(_10554)) {
        _10555 = _index_ptr_18782 + _10554;
        if ((long)((unsigned long)_10555 + (unsigned long)HIGH_BITS) >= 0) 
        _10555 = NewDouble((double)_10555);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18782)) {
            _10555 = NewDouble((double)_index_ptr_18782 + DBL_PTR(_10554)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10554)) {
                _10555 = NewDouble(DBL_PTR(_index_ptr_18782)->dbl + (double)_10554);
            }
            else
            _10555 = NewDouble(DBL_PTR(_index_ptr_18782)->dbl + DBL_PTR(_10554)->dbl);
        }
    }
    DeRef(_10554);
    _10554 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18777)) {
        _10556 = _current_block_18777 + 8;
        if ((long)((unsigned long)_10556 + (unsigned long)HIGH_BITS) >= 0) 
        _10556 = NewDouble((double)_10556);
    }
    else {
        _10556 = NewDouble(DBL_PTR(_current_block_18777)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10555) && IS_ATOM_INT(_10556)) {
        _10557 = _10555 - _10556;
        if ((long)((unsigned long)_10557 +(unsigned long) HIGH_BITS) >= 0){
            _10557 = NewDouble((double)_10557);
        }
    }
    else {
        if (IS_ATOM_INT(_10555)) {
            _10557 = NewDouble((double)_10555 - DBL_PTR(_10556)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10556)) {
                _10557 = NewDouble(DBL_PTR(_10555)->dbl - (double)_10556);
            }
            else
            _10557 = NewDouble(DBL_PTR(_10555)->dbl - DBL_PTR(_10556)->dbl);
        }
    }
    DeRef(_10555);
    _10555 = NOVALUE;
    DeRef(_10556);
    _10556 = NOVALUE;
    _0 = _remaining_18772;
    _remaining_18772 = _8get_bytes(_49current_db_17054, _10557);
    DeRef(_0);
    _10557 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18777)) {
        _10559 = _current_block_18777 + 8;
        if ((long)((unsigned long)_10559 + (unsigned long)HIGH_BITS) >= 0) 
        _10559 = NewDouble((double)_10559);
    }
    else {
        _10559 = NewDouble(DBL_PTR(_current_block_18777)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_18933);
    _pos_inlined_seek_at_881_18933 = _10559;
    _10559 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_18933);
    DeRef(_seek_1__tmp_at884_18935);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_18933;
    _seek_1__tmp_at884_18935 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_18934 = machine(19, _seek_1__tmp_at884_18935);
    DeRef(_pos_inlined_seek_at_881_18933);
    _pos_inlined_seek_at_881_18933 = NOVALUE;
    DeRef(_seek_1__tmp_at884_18935);
    _seek_1__tmp_at884_18935 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_18787;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_18937);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_18937 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at899_18937); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_18937);
    _put4_1__tmp_at899_18937 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_new_block_18781)) {
        *poke4_addr = (unsigned long)_new_block_18781;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_18781)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_18939);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_18939 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at927_18939); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_18939);
    _put4_1__tmp_at927_18939 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_18772); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_49current_table_pos_17055)) {
        _10560 = _49current_table_pos_17055 + 8;
        if ((long)((unsigned long)_10560 + (unsigned long)HIGH_BITS) >= 0) 
        _10560 = NewDouble((double)_10560);
    }
    else {
        _10560 = NewDouble(DBL_PTR(_49current_table_pos_17055)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_18943);
    _pos_inlined_seek_at_977_18943 = _10560;
    _10560 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_18943);
    DeRef(_seek_1__tmp_at980_18945);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_18943;
    _seek_1__tmp_at980_18945 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_18944 = machine(19, _seek_1__tmp_at980_18945);
    DeRef(_pos_inlined_seek_at_977_18943);
    _pos_inlined_seek_at_977_18943 = NOVALUE;
    DeRef(_seek_1__tmp_at980_18945);
    _seek_1__tmp_at980_18945 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_18786 = _blocks_18786 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_18786;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_18948);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_18948 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at1001_18948); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_18948);
    _put4_1__tmp_at1001_18948 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_18782)) {
        _10562 = _index_ptr_18782 - 4;
        if ((long)((unsigned long)_10562 +(unsigned long) HIGH_BITS) >= 0){
            _10562 = NewDouble((double)_10562);
        }
    }
    else {
        _10562 = NewDouble(DBL_PTR(_index_ptr_18782)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_18951);
    _pos_inlined_seek_at_1035_18951 = _10562;
    _10562 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_18951);
    DeRef(_seek_1__tmp_at1038_18953);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_18951;
    _seek_1__tmp_at1038_18953 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_18952 = machine(19, _seek_1__tmp_at1038_18953);
    DeRef(_pos_inlined_seek_at_1035_18951);
    _pos_inlined_seek_at_1035_18951 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_18953);
    _seek_1__tmp_at1038_18953 = NOVALUE;

    /** 		size = get4() - 4*/
    _10563 = _49get4();
    DeRef(_size_18778);
    if (IS_ATOM_INT(_10563)) {
        _size_18778 = _10563 - 4;
        if ((long)((unsigned long)_size_18778 +(unsigned long) HIGH_BITS) >= 0){
            _size_18778 = NewDouble((double)_size_18778);
        }
    }
    else {
        _size_18778 = binary_op(MINUS, _10563, 4);
    }
    DeRef(_10563);
    _10563 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_18786 == (short)_blocks_18786)
    _10565 = _blocks_18786 * 8;
    else
    _10565 = NewDouble(_blocks_18786 * (double)8);
    if (IS_ATOM_INT(_size_18778)) {
        _10566 = _size_18778 - 8;
        if ((long)((unsigned long)_10566 +(unsigned long) HIGH_BITS) >= 0){
            _10566 = NewDouble((double)_10566);
        }
    }
    else {
        _10566 = NewDouble(DBL_PTR(_size_18778)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10565, _10566)){
        DeRef(_10565);
        _10565 = NOVALUE;
        DeRef(_10566);
        _10566 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10565);
    _10565 = NOVALUE;
    DeRef(_10566);
    _10566 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_18786 == (short)_blocks_18786)
    _10568 = _blocks_18786 * 8;
    else
    _10568 = NewDouble(_blocks_18786 * (double)8);
    _0 = _remaining_18772;
    _remaining_18772 = _8get_bytes(_49current_db_17054, _10568);
    DeRef(_0);
    _10568 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_18778)) {
        if (_size_18778 & 1) {
            _10570 = NewDouble((_size_18778 >> 1) + 0.5);
        }
        else
        _10570 = _size_18778 >> 1;
    }
    else {
        _10570 = binary_op(DIVIDE, _size_18778, 2);
    }
    if (IS_ATOM_INT(_size_18778) && IS_ATOM_INT(_10570)) {
        _10571 = _size_18778 + _10570;
        if ((long)((unsigned long)_10571 + (unsigned long)HIGH_BITS) >= 0) 
        _10571 = NewDouble((double)_10571);
    }
    else {
        if (IS_ATOM_INT(_size_18778)) {
            _10571 = NewDouble((double)_size_18778 + DBL_PTR(_10570)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10570)) {
                _10571 = NewDouble(DBL_PTR(_size_18778)->dbl + (double)_10570);
            }
            else
            _10571 = NewDouble(DBL_PTR(_size_18778)->dbl + DBL_PTR(_10570)->dbl);
        }
    }
    DeRef(_10570);
    _10570 = NOVALUE;
    DeRef(_new_size_18779);
    if (IS_ATOM_INT(_10571))
    _new_size_18779 = e_floor(_10571);
    else
    _new_size_18779 = unary_op(FLOOR, _10571);
    DeRef(_10571);
    _10571 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_18779);
    _0 = _new_index_ptr_18783;
    _new_index_ptr_18783 = _49db_allocate(_new_size_18779);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _remaining_18772); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_18786 == (short)_blocks_18786)
    _10574 = _blocks_18786 * 8;
    else
    _10574 = NewDouble(_blocks_18786 * (double)8);
    if (IS_ATOM_INT(_new_size_18779) && IS_ATOM_INT(_10574)) {
        _10575 = _new_size_18779 - _10574;
    }
    else {
        if (IS_ATOM_INT(_new_size_18779)) {
            _10575 = NewDouble((double)_new_size_18779 - DBL_PTR(_10574)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10574)) {
                _10575 = NewDouble(DBL_PTR(_new_size_18779)->dbl - (double)_10574);
            }
            else
            _10575 = NewDouble(DBL_PTR(_new_size_18779)->dbl - DBL_PTR(_10574)->dbl);
        }
    }
    DeRef(_10574);
    _10574 = NOVALUE;
    _10576 = Repeat(0, _10575);
    DeRef(_10575);
    _10575 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_18971);
    _s_inlined_putn_at_1136_18971 = _10576;
    _10576 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _s_inlined_putn_at_1136_18971); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_18971);
    _s_inlined_putn_at_1136_18971 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_18782);
    _49db_free(_index_ptr_18782);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_49current_table_pos_17055)) {
        _10577 = _49current_table_pos_17055 + 12;
        if ((long)((unsigned long)_10577 + (unsigned long)HIGH_BITS) >= 0) 
        _10577 = NewDouble((double)_10577);
    }
    else {
        _10577 = NewDouble(DBL_PTR(_49current_table_pos_17055)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_18974);
    _pos_inlined_seek_at_1170_18974 = _10577;
    _10577 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_18974);
    DeRef(_seek_1__tmp_at1173_18976);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_18974;
    _seek_1__tmp_at1173_18976 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_18975 = machine(19, _seek_1__tmp_at1173_18976);
    DeRef(_pos_inlined_seek_at_1170_18974);
    _pos_inlined_seek_at_1170_18974 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_18976);
    _seek_1__tmp_at1173_18976 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_18783)) {
        *poke4_addr = (unsigned long)_new_index_ptr_18783;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_18783)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_18978);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_18978 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at1188_18978); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_18978);
    _put4_1__tmp_at1188_18978 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_18766);
    DeRef(_table_name_18768);
    DeRef(_key_string_18769);
    DeRef(_data_string_18770);
    DeRef(_last_part_18771);
    DeRef(_remaining_18772);
    DeRef(_key_ptr_18773);
    DeRef(_data_ptr_18774);
    DeRef(_records_ptr_18775);
    DeRef(_nrecs_18776);
    DeRef(_current_block_18777);
    DeRef(_size_18778);
    DeRef(_new_size_18779);
    DeRef(_key_location_18780);
    DeRef(_new_block_18781);
    DeRef(_index_ptr_18782);
    DeRef(_new_index_ptr_18783);
    DeRef(_total_recs_18784);
    DeRef(_10521);
    _10521 = NOVALUE;
    DeRef(_10523);
    _10523 = NOVALUE;
    return 0;
    ;
}


void _49db_replace_data(int _key_location_19113, int _data_19114, int _table_name_19115)
{
    int _10651 = NOVALUE;
    int _10650 = NOVALUE;
    int _10649 = NOVALUE;
    int _10648 = NOVALUE;
    int _10646 = NOVALUE;
    int _10645 = NOVALUE;
    int _10643 = NOVALUE;
    int _10640 = NOVALUE;
    int _10638 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19115 == _49current_table_name_17056)
    _10638 = 1;
    else if (IS_ATOM_INT(_table_name_19115) && IS_ATOM_INT(_49current_table_name_17056))
    _10638 = 0;
    else
    _10638 = (compare(_table_name_19115, _49current_table_name_17056) == 0);
    if (_10638 != 0)
    goto L1; // [11] 45
    _10638 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19115);
    _10640 = _49db_select_table(_table_name_19115);
    if (binary_op_a(EQUALS, _10640, 0)){
        DeRef(_10640);
        _10640 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10640);
    _10640 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19113;
    *((int *)(_2+8)) = _data_19114;
    RefDS(_table_name_19115);
    *((int *)(_2+12)) = _table_name_19115;
    _10643 = MAKE_SEQ(_1);
    RefDS(_10462);
    RefDS(_10642);
    _49fatal(903, _10462, _10642, _10643);
    _10643 = NOVALUE;

    /** 			return*/
    DeRefDS(_table_name_19115);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17055, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19113;
    *((int *)(_2+8)) = _data_19114;
    Ref(_table_name_19115);
    *((int *)(_2+12)) = _table_name_19115;
    _10645 = MAKE_SEQ(_1);
    RefDS(_10466);
    RefDS(_10642);
    _49fatal(903, _10466, _10642, _10645);
    _10645 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19115);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10646 = (_key_location_19113 < 1);
    if (_10646 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _10648 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _10648 = 1;
    }
    _10649 = (_key_location_19113 > _10648);
    _10648 = NOVALUE;
    if (_10649 == 0)
    {
        DeRef(_10649);
        _10649 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10649);
        _10649 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19113;
    *((int *)(_2+8)) = _data_19114;
    Ref(_table_name_19115);
    *((int *)(_2+12)) = _table_name_19115;
    _10650 = MAKE_SEQ(_1);
    RefDS(_10590);
    RefDS(_10642);
    _49fatal(905, _10590, _10642, _10650);
    _10650 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19115);
    DeRef(_10646);
    _10646 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_49key_pointers_17061);
    _10651 = (int)*(((s1_ptr)_2)->base + _key_location_19113);
    Ref(_10651);
    _49db_replace_recid(_10651, _data_19114);
    _10651 = NOVALUE;

    /** end procedure*/
    DeRef(_table_name_19115);
    DeRef(_10646);
    _10646 = NOVALUE;
    return;
    ;
}


int _49db_table_size(int _table_name_19137)
{
    int _10660 = NOVALUE;
    int _10659 = NOVALUE;
    int _10657 = NOVALUE;
    int _10654 = NOVALUE;
    int _10652 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19137 == _49current_table_name_17056)
    _10652 = 1;
    else if (IS_ATOM_INT(_table_name_19137) && IS_ATOM_INT(_49current_table_name_17056))
    _10652 = 0;
    else
    _10652 = (compare(_table_name_19137, _49current_table_name_17056) == 0);
    if (_10652 != 0)
    goto L1; // [9] 42
    _10652 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19137);
    _10654 = _49db_select_table(_table_name_19137);
    if (binary_op_a(EQUALS, _10654, 0)){
        DeRef(_10654);
        _10654 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10654);
    _10654 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_19137);
    *((int *)(_2+4)) = _table_name_19137;
    _10657 = MAKE_SEQ(_1);
    RefDS(_10462);
    RefDS(_10656);
    _49fatal(903, _10462, _10656, _10657);
    _10657 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19137);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17055, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_19137);
    *((int *)(_2+4)) = _table_name_19137;
    _10659 = MAKE_SEQ(_1);
    RefDS(_10466);
    RefDS(_10656);
    _49fatal(903, _10466, _10656, _10659);
    _10659 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19137);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _10660 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _10660 = 1;
    }
    DeRef(_table_name_19137);
    return _10660;
    ;
}


int _49db_record_data(int _key_location_19152, int _table_name_19153)
{
    int _data_ptr_19154 = NOVALUE;
    int _data_value_19155 = NOVALUE;
    int _seek_1__tmp_at126_19177 = NOVALUE;
    int _seek_inlined_seek_at_126_19176 = NOVALUE;
    int _pos_inlined_seek_at_123_19175 = NOVALUE;
    int _seek_1__tmp_at164_19184 = NOVALUE;
    int _seek_inlined_seek_at_164_19183 = NOVALUE;
    int _10675 = NOVALUE;
    int _10674 = NOVALUE;
    int _10673 = NOVALUE;
    int _10672 = NOVALUE;
    int _10671 = NOVALUE;
    int _10669 = NOVALUE;
    int _10668 = NOVALUE;
    int _10666 = NOVALUE;
    int _10663 = NOVALUE;
    int _10661 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19152)) {
        _1 = (long)(DBL_PTR(_key_location_19152)->dbl);
        DeRefDS(_key_location_19152);
        _key_location_19152 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19153 == _49current_table_name_17056)
    _10661 = 1;
    else if (IS_ATOM_INT(_table_name_19153) && IS_ATOM_INT(_49current_table_name_17056))
    _10661 = 0;
    else
    _10661 = (compare(_table_name_19153, _49current_table_name_17056) == 0);
    if (_10661 != 0)
    goto L1; // [11] 44
    _10661 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19153);
    _10663 = _49db_select_table(_table_name_19153);
    if (binary_op_a(EQUALS, _10663, 0)){
        DeRef(_10663);
        _10663 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10663);
    _10663 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_19153);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19152;
    ((int *)_2)[2] = _table_name_19153;
    _10666 = MAKE_SEQ(_1);
    RefDS(_10462);
    RefDS(_10665);
    _49fatal(903, _10462, _10665, _10666);
    _10666 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19153);
    DeRef(_data_ptr_19154);
    DeRef(_data_value_19155);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17055, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19153);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19152;
    ((int *)_2)[2] = _table_name_19153;
    _10668 = MAKE_SEQ(_1);
    RefDS(_10466);
    RefDS(_10665);
    _49fatal(903, _10466, _10665, _10668);
    _10668 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19153);
    DeRef(_data_ptr_19154);
    DeRef(_data_value_19155);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10669 = (_key_location_19152 < 1);
    if (_10669 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _10671 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _10671 = 1;
    }
    _10672 = (_key_location_19152 > _10671);
    _10671 = NOVALUE;
    if (_10672 == 0)
    {
        DeRef(_10672);
        _10672 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10672);
        _10672 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19153);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19152;
    ((int *)_2)[2] = _table_name_19153;
    _10673 = MAKE_SEQ(_1);
    RefDS(_10590);
    RefDS(_10665);
    _49fatal(905, _10590, _10665, _10673);
    _10673 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19153);
    DeRef(_data_ptr_19154);
    DeRef(_data_value_19155);
    DeRef(_10669);
    _10669 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_49key_pointers_17061);
    _10674 = (int)*(((s1_ptr)_2)->base + _key_location_19152);
    Ref(_10674);
    DeRef(_pos_inlined_seek_at_123_19175);
    _pos_inlined_seek_at_123_19175 = _10674;
    _10674 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_19175);
    DeRef(_seek_1__tmp_at126_19177);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_19175;
    _seek_1__tmp_at126_19177 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_19176 = machine(19, _seek_1__tmp_at126_19177);
    DeRef(_pos_inlined_seek_at_123_19175);
    _pos_inlined_seek_at_123_19175 = NOVALUE;
    DeRef(_seek_1__tmp_at126_19177);
    _seek_1__tmp_at126_19177 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_49vLastErrors_17078)){
            _10675 = SEQ_PTR(_49vLastErrors_17078)->length;
    }
    else {
        _10675 = 1;
    }
    if (_10675 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_19153);
    DeRef(_data_ptr_19154);
    DeRef(_data_value_19155);
    DeRef(_10669);
    _10669 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19154;
    _data_ptr_19154 = _49get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_19154);
    DeRef(_seek_1__tmp_at164_19184);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _49current_db_17054;
    ((int *)_2)[2] = _data_ptr_19154;
    _seek_1__tmp_at164_19184 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_19183 = machine(19, _seek_1__tmp_at164_19184);
    DeRef(_seek_1__tmp_at164_19184);
    _seek_1__tmp_at164_19184 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_19155;
    _data_value_19155 = _49decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_19153);
    DeRef(_data_ptr_19154);
    DeRef(_10669);
    _10669 = NOVALUE;
    return _data_value_19155;
    ;
}


int _49db_fetch_record(int _key_19188, int _table_name_19189)
{
    int _pos_19190 = NOVALUE;
    int _10681 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_19188);
    RefDS(_table_name_19189);
    _pos_19190 = _49db_find_key(_key_19188, _table_name_19189);
    if (!IS_ATOM_INT(_pos_19190)) {
        _1 = (long)(DBL_PTR(_pos_19190)->dbl);
        DeRefDS(_pos_19190);
        _pos_19190 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_19190 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    RefDS(_table_name_19189);
    _10681 = _49db_record_data(_pos_19190, _table_name_19189);
    DeRef(_key_19188);
    DeRefDS(_table_name_19189);
    return _10681;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_19188);
    DeRef(_table_name_19189);
    DeRef(_10681);
    _10681 = NOVALUE;
    return _pos_19190;
L2: 
    ;
}


int _49db_record_key(int _key_location_19198, int _table_name_19199)
{
    int _10696 = NOVALUE;
    int _10695 = NOVALUE;
    int _10694 = NOVALUE;
    int _10693 = NOVALUE;
    int _10692 = NOVALUE;
    int _10690 = NOVALUE;
    int _10689 = NOVALUE;
    int _10687 = NOVALUE;
    int _10684 = NOVALUE;
    int _10682 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19198)) {
        _1 = (long)(DBL_PTR(_key_location_19198)->dbl);
        DeRefDS(_key_location_19198);
        _key_location_19198 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19199 == _49current_table_name_17056)
    _10682 = 1;
    else if (IS_ATOM_INT(_table_name_19199) && IS_ATOM_INT(_49current_table_name_17056))
    _10682 = 0;
    else
    _10682 = (compare(_table_name_19199, _49current_table_name_17056) == 0);
    if (_10682 != 0)
    goto L1; // [11] 44
    _10682 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19199);
    _10684 = _49db_select_table(_table_name_19199);
    if (binary_op_a(EQUALS, _10684, 0)){
        DeRef(_10684);
        _10684 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10684);
    _10684 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_19199);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19198;
    ((int *)_2)[2] = _table_name_19199;
    _10687 = MAKE_SEQ(_1);
    RefDS(_10462);
    RefDS(_10686);
    _49fatal(903, _10462, _10686, _10687);
    _10687 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19199);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _49current_table_pos_17055, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19199);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19198;
    ((int *)_2)[2] = _table_name_19199;
    _10689 = MAKE_SEQ(_1);
    RefDS(_10466);
    RefDS(_10686);
    _49fatal(903, _10466, _10686, _10689);
    _10689 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19199);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10690 = (_key_location_19198 < 1);
    if (_10690 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_49key_pointers_17061)){
            _10692 = SEQ_PTR(_49key_pointers_17061)->length;
    }
    else {
        _10692 = 1;
    }
    _10693 = (_key_location_19198 > _10692);
    _10692 = NOVALUE;
    if (_10693 == 0)
    {
        DeRef(_10693);
        _10693 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10693);
        _10693 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19199);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19198;
    ((int *)_2)[2] = _table_name_19199;
    _10694 = MAKE_SEQ(_1);
    RefDS(_10590);
    RefDS(_10686);
    _49fatal(905, _10590, _10686, _10694);
    _10694 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19199);
    DeRef(_10690);
    _10690 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_49key_pointers_17061);
    _10695 = (int)*(((s1_ptr)_2)->base + _key_location_19198);
    Ref(_10695);
    _10696 = _49key_value(_10695);
    _10695 = NOVALUE;
    DeRef(_table_name_19199);
    DeRef(_10690);
    _10690 = NOVALUE;
    return _10696;
    ;
}


void _49db_replace_recid(int _recid_19312, int _data_19313)
{
    int _old_size_19314 = NOVALUE;
    int _new_size_19315 = NOVALUE;
    int _data_ptr_19316 = NOVALUE;
    int _data_string_19317 = NOVALUE;
    int _put4_1__tmp_at111_19337 = NOVALUE;
    int _10795 = NOVALUE;
    int _10794 = NOVALUE;
    int _10793 = NOVALUE;
    int _10792 = NOVALUE;
    int _10791 = NOVALUE;
    int _10763 = NOVALUE;
    int _10761 = NOVALUE;
    int _10760 = NOVALUE;
    int _10759 = NOVALUE;
    int _10758 = NOVALUE;
    int _10757 = NOVALUE;
    int _10753 = NOVALUE;
    int _10752 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_19312)) {
        _1 = (long)(DBL_PTR(_recid_19312)->dbl);
        DeRefDS(_recid_19312);
        _recid_19312 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10795 = _8seek(_49current_db_17054, _recid_19312);
    DeRef(_10795);
    _10795 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19316;
    _data_ptr_19316 = _49get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_19316)) {
        _10752 = _data_ptr_19316 - 4;
        if ((long)((unsigned long)_10752 +(unsigned long) HIGH_BITS) >= 0){
            _10752 = NewDouble((double)_10752);
        }
    }
    else {
        _10752 = NewDouble(DBL_PTR(_data_ptr_19316)->dbl - (double)4);
    }
    _10794 = _8seek(_49current_db_17054, _10752);
    _10752 = NOVALUE;
    DeRef(_10794);
    _10794 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10753 = _49get4();
    DeRef(_old_size_19314);
    if (IS_ATOM_INT(_10753)) {
        _old_size_19314 = _10753 - 4;
        if ((long)((unsigned long)_old_size_19314 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_19314 = NewDouble((double)_old_size_19314);
        }
    }
    else {
        _old_size_19314 = binary_op(MINUS, _10753, 4);
    }
    DeRef(_10753);
    _10753 = NOVALUE;

    /** 	data_string = compress(data)*/
    _0 = _data_string_19317;
    _data_string_19317 = _49compress(_data_19313);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_19317)){
            _new_size_19315 = SEQ_PTR(_data_string_19317)->length;
    }
    else {
        _new_size_19315 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_19314)) {
        _10757 = (_new_size_19315 <= _old_size_19314);
    }
    else {
        _10757 = ((double)_new_size_19315 <= DBL_PTR(_old_size_19314)->dbl);
    }
    if (_10757 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_19314)) {
        _10759 = _old_size_19314 - 16;
        if ((long)((unsigned long)_10759 +(unsigned long) HIGH_BITS) >= 0){
            _10759 = NewDouble((double)_10759);
        }
    }
    else {
        _10759 = NewDouble(DBL_PTR(_old_size_19314)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10759)) {
        _10760 = (_new_size_19315 >= _10759);
    }
    else {
        _10760 = ((double)_new_size_19315 >= DBL_PTR(_10759)->dbl);
    }
    DeRef(_10759);
    _10759 = NOVALUE;
    if (_10760 == 0)
    {
        DeRef(_10760);
        _10760 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10760);
        _10760 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19316);
    _10793 = _8seek(_49current_db_17054, _data_ptr_19316);
    DeRef(_10793);
    _10793 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_19316);
    _49db_free(_data_ptr_19316);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10761 = _new_size_19315 + 8;
    if ((long)((unsigned long)_10761 + (unsigned long)HIGH_BITS) >= 0) 
    _10761 = NewDouble((double)_10761);
    _0 = _data_ptr_19316;
    _data_ptr_19316 = _49db_allocate(_10761);
    DeRef(_0);
    _10761 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10792 = _8seek(_49current_db_17054, _recid_19312);
    DeRef(_10792);
    _10792 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_49mem0_17096)){
        poke4_addr = (unsigned long *)_49mem0_17096;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_49mem0_17096)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19316)) {
        *poke4_addr = (unsigned long)_data_ptr_19316;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19316)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_19337);
    _1 = (int)SEQ_PTR(_49memseq_17331);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_19337 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_49current_db_17054, _put4_1__tmp_at111_19337); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_19337);
    _put4_1__tmp_at111_19337 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19316);
    _10791 = _8seek(_49current_db_17054, _data_ptr_19316);
    DeRef(_10791);
    _10791 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10763 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_19317, _data_string_19317, _10763);
    DeRefDS(_10763);
    _10763 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_49current_db_17054, _data_string_19317); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_old_size_19314);
    DeRef(_data_ptr_19316);
    DeRef(_data_string_19317);
    DeRef(_10757);
    _10757 = NOVALUE;
    return;
    ;
}



// 0xFC1B44AD
