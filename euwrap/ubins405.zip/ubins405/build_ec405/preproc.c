// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _64is_file_newer(int _f1_23343, int _f2_23344)
{
    int _d1_23345 = NOVALUE;
    int _d2_23348 = NOVALUE;
    int _diff_2__tmp_at33_23357 = NOVALUE;
    int _diff_1__tmp_at33_23356 = NOVALUE;
    int _diff_inlined_diff_at_33_23355 = NOVALUE;
    int _13462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_23343);
    _0 = _d1_23345;
    _d1_23345 = _17file_timestamp(_f1_23343);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_23344);
    _0 = _d2_23348;
    _d2_23348 = _17file_timestamp(_f2_23344);
    DeRef(_0);

    /** 	if atom(d2) then return 1 end if*/
    _13462 = IS_ATOM(_d2_23348);
    if (_13462 == 0)
    {
        _13462 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13462 = NOVALUE;
    }
    DeRefDS(_f1_23343);
    DeRefDS(_f2_23344);
    DeRef(_d1_23345);
    DeRef(_d2_23348);
    return 1;
L1: 

    /** 	if dt:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_23348);
    _0 = _diff_1__tmp_at33_23356;
    _diff_1__tmp_at33_23356 = _18datetimeToSeconds(_d2_23348);
    DeRef(_0);
    Ref(_d1_23345);
    _0 = _diff_2__tmp_at33_23357;
    _diff_2__tmp_at33_23357 = _18datetimeToSeconds(_d1_23345);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_23355);
    if (IS_ATOM_INT(_diff_1__tmp_at33_23356) && IS_ATOM_INT(_diff_2__tmp_at33_23357)) {
        _diff_inlined_diff_at_33_23355 = _diff_1__tmp_at33_23356 - _diff_2__tmp_at33_23357;
        if ((long)((unsigned long)_diff_inlined_diff_at_33_23355 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_23355 = NewDouble((double)_diff_inlined_diff_at_33_23355);
        }
    }
    else {
        _diff_inlined_diff_at_33_23355 = binary_op(MINUS, _diff_1__tmp_at33_23356, _diff_2__tmp_at33_23357);
    }
    DeRef(_diff_1__tmp_at33_23356);
    _diff_1__tmp_at33_23356 = NOVALUE;
    DeRef(_diff_2__tmp_at33_23357);
    _diff_2__tmp_at33_23357 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_23355, 0)){
        goto L2; // [49] 60
    }

    /** 		return 1*/
    DeRefDS(_f1_23343);
    DeRefDS(_f2_23344);
    DeRef(_d1_23345);
    DeRef(_d2_23348);
    return 1;
L2: 

    /** 	return 0*/
    DeRefDS(_f1_23343);
    DeRefDS(_f2_23344);
    DeRef(_d1_23345);
    DeRef(_d2_23348);
    return 0;
    ;
}


void _64add_preprocessor(int _file_ext_23361, int _command_23362, int _params_23363)
{
    int _tmp_23366 = NOVALUE;
    int _file_exts_23376 = NOVALUE;
    int _exts_23382 = NOVALUE;
    int _13479 = NOVALUE;
    int _13478 = NOVALUE;
    int _13477 = NOVALUE;
    int _13476 = NOVALUE;
    int _13474 = NOVALUE;
    int _13469 = NOVALUE;
    int _13464 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(command) then*/
    _13464 = 1;
    if (_13464 == 0)
    {
        _13464 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13464 = NOVALUE;
    }

    /** 		sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_23361);
    RefDS(_13465);
    _0 = _tmp_23366;
    _tmp_23366 = _23split(_file_ext_23361, _13465, 0, 0);
    DeRef(_0);

    /** 		file_ext = tmp[1]*/
    DeRefDS(_file_ext_23361);
    _2 = (int)SEQ_PTR(_tmp_23366);
    _file_ext_23361 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_23361);

    /** 		command = tmp[2]*/
    _2 = (int)SEQ_PTR(_tmp_23366);
    _command_23362 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_command_23362);

    /** 		if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_23366)){
            _13469 = SEQ_PTR(_tmp_23366)->length;
    }
    else {
        _13469 = 1;
    }
    if (_13469 < 3)
    goto L2; // [41] 52

    /** 			params = tmp[3]*/
    _2 = (int)SEQ_PTR(_tmp_23366);
    _params_23363 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_params_23363);
L2: 
L1: 
    DeRef(_tmp_23366);
    _tmp_23366 = NOVALUE;

    /** 	sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_23361);
    RefDS(_13472);
    _0 = _file_exts_23376;
    _file_exts_23376 = _23split(_file_ext_23361, _13472, 0, 0);
    DeRef(_0);

    /** 	if atom(params) then*/
    _13474 = IS_ATOM(_params_23363);
    if (_13474 == 0)
    {
        _13474 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13474 = NOVALUE;
    }

    /** 		params = ""*/
    RefDS(_5);
    DeRef(_params_23363);
    _params_23363 = _5;
L3: 

    /** 	sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_23361);
    RefDS(_13472);
    _0 = _exts_23382;
    _exts_23382 = _23split(_file_ext_23361, _13472, 0, 0);
    DeRef(_0);

    /** 	for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_23382)){
            _13476 = SEQ_PTR(_exts_23382)->length;
    }
    else {
        _13476 = 1;
    }
    {
        int _i_23386;
        _i_23386 = 1;
L4: 
        if (_i_23386 > _13476){
            goto L5; // [96] 135
        }

        /** 		preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (int)SEQ_PTR(_exts_23382);
        _13477 = (int)*(((s1_ptr)_2)->base + _i_23386);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13477);
        *((int *)(_2+4)) = _13477;
        Ref(_command_23362);
        *((int *)(_2+8)) = _command_23362;
        Ref(_params_23363);
        *((int *)(_2+12)) = _params_23363;
        *((int *)(_2+16)) = -1;
        _13478 = MAKE_SEQ(_1);
        _13477 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _13478;
        _13479 = MAKE_SEQ(_1);
        _13478 = NOVALUE;
        Concat((object_ptr)&_36preprocessors_14998, _36preprocessors_14998, _13479);
        DeRefDS(_13479);
        _13479 = NOVALUE;

        /** 	end for*/
        _i_23386 = _i_23386 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** end procedure */
    DeRefDS(_file_ext_23361);
    DeRef(_command_23362);
    DeRef(_params_23363);
    DeRef(_file_exts_23376);
    DeRef(_exts_23382);
    return;
    ;
}


int _64maybe_preprocess(int _fname_23395)
{
    int _pp_23396 = NOVALUE;
    int _pp_id_23397 = NOVALUE;
    int _fext_23401 = NOVALUE;
    int _post_fname_23418 = NOVALUE;
    int _rid_23446 = NOVALUE;
    int _dll_id_23450 = NOVALUE;
    int _public_cmd_args_23486 = NOVALUE;
    int _cmd_args_23489 = NOVALUE;
    int _cmd_23518 = NOVALUE;
    int _pcmd_23523 = NOVALUE;
    int _result_23528 = NOVALUE;
    int _13558 = NOVALUE;
    int _13557 = NOVALUE;
    int _13552 = NOVALUE;
    int _13551 = NOVALUE;
    int _13549 = NOVALUE;
    int _13548 = NOVALUE;
    int _13546 = NOVALUE;
    int _13544 = NOVALUE;
    int _13543 = NOVALUE;
    int _13541 = NOVALUE;
    int _13538 = NOVALUE;
    int _13536 = NOVALUE;
    int _13534 = NOVALUE;
    int _13532 = NOVALUE;
    int _13531 = NOVALUE;
    int _13529 = NOVALUE;
    int _13528 = NOVALUE;
    int _13526 = NOVALUE;
    int _13523 = NOVALUE;
    int _13522 = NOVALUE;
    int _13521 = NOVALUE;
    int _13519 = NOVALUE;
    int _13515 = NOVALUE;
    int _13513 = NOVALUE;
    int _13512 = NOVALUE;
    int _13511 = NOVALUE;
    int _13507 = NOVALUE;
    int _13504 = NOVALUE;
    int _13503 = NOVALUE;
    int _13502 = NOVALUE;
    int _13500 = NOVALUE;
    int _13497 = NOVALUE;
    int _13495 = NOVALUE;
    int _13494 = NOVALUE;
    int _13492 = NOVALUE;
    int _13490 = NOVALUE;
    int _13488 = NOVALUE;
    int _13486 = NOVALUE;
    int _13485 = NOVALUE;
    int _13484 = NOVALUE;
    int _13483 = NOVALUE;
    int _13481 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_23396);
    _pp_23396 = _5;

    /** 	if length(preprocessors) then*/
    if (IS_SEQUENCE(_36preprocessors_14998)){
            _13481 = SEQ_PTR(_36preprocessors_14998)->length;
    }
    else {
        _13481 = 1;
    }
    if (_13481 == 0)
    {
        _13481 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13481 = NOVALUE;
    }

    /** 		sequence fext = fileext(fname)*/
    RefDS(_fname_23395);
    _0 = _fext_23401;
    _fext_23401 = _17fileext(_fname_23395);
    DeRef(_0);

    /** 		for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_36preprocessors_14998)){
            _13483 = SEQ_PTR(_36preprocessors_14998)->length;
    }
    else {
        _13483 = 1;
    }
    {
        int _i_23405;
        _i_23405 = 1;
L2: 
        if (_i_23405 > _13483){
            goto L3; // [35] 88
        }

        /** 			if equal(fext, preprocessors[i][1]) then*/
        _2 = (int)SEQ_PTR(_36preprocessors_14998);
        _13484 = (int)*(((s1_ptr)_2)->base + _i_23405);
        _2 = (int)SEQ_PTR(_13484);
        _13485 = (int)*(((s1_ptr)_2)->base + 1);
        _13484 = NOVALUE;
        if (_fext_23401 == _13485)
        _13486 = 1;
        else if (IS_ATOM_INT(_fext_23401) && IS_ATOM_INT(_13485))
        _13486 = 0;
        else
        _13486 = (compare(_fext_23401, _13485) == 0);
        _13485 = NOVALUE;
        if (_13486 == 0)
        {
            _13486 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13486 = NOVALUE;
        }

        /** 				pp_id = i*/
        _pp_id_23397 = _i_23405;

        /** 				pp = preprocessors[pp_id]*/
        DeRef(_pp_23396);
        _2 = (int)SEQ_PTR(_36preprocessors_14998);
        _pp_23396 = (int)*(((s1_ptr)_2)->base + _pp_id_23397);
        RefDS(_pp_23396);

        /** 				exit*/
        goto L3; // [78] 88
L4: 

        /** 		end for*/
        _i_23405 = _i_23405 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_23401);
    _fext_23401 = NOVALUE;

    /** 	if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_23396)){
            _13488 = SEQ_PTR(_pp_23396)->length;
    }
    else {
        _13488 = 1;
    }
    if (_13488 != 0)
    goto L5; // [96] 107

    /** 		return fname*/
    DeRefDS(_pp_23396);
    DeRef(_post_fname_23418);
    return _fname_23395;
L5: 

    /** 	sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_23395);
    _13490 = _17filebase(_fname_23395);
    RefDS(_fname_23395);
    _13492 = _17fileext(_fname_23395);
    {
        int concat_list[3];

        concat_list[0] = _13492;
        concat_list[1] = _13491;
        concat_list[2] = _13490;
        Concat_N((object_ptr)&_post_fname_23418, concat_list, 3);
    }
    DeRef(_13492);
    _13492 = NOVALUE;
    DeRef(_13490);
    _13490 = NOVALUE;

    /** 	if length(dirname(fname)) > 0 then*/
    RefDS(_fname_23395);
    _13494 = _17dirname(_fname_23395, 0);
    if (IS_SEQUENCE(_13494)){
            _13495 = SEQ_PTR(_13494)->length;
    }
    else {
        _13495 = 1;
    }
    DeRef(_13494);
    _13494 = NOVALUE;
    if (_13495 <= 0)
    goto L6; // [133] 153

    /** 		post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_23395);
    _13497 = _17dirname(_fname_23395, 0);
    {
        int concat_list[3];

        concat_list[0] = _post_fname_23418;
        concat_list[1] = 47;
        concat_list[2] = _13497;
        Concat_N((object_ptr)&_post_fname_23418, concat_list, 3);
    }
    DeRef(_13497);
    _13497 = NOVALUE;
L6: 

    /** 	if not force_preprocessor then*/
    if (_36force_preprocessor_14999 != 0)
    goto L7; // [157] 178

    /** 		if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_23395);
    RefDS(_post_fname_23418);
    _13500 = _64is_file_newer(_fname_23395, _post_fname_23418);
    if (IS_ATOM_INT(_13500)) {
        if (_13500 != 0){
            DeRef(_13500);
            _13500 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13500)->dbl != 0.0){
            DeRef(_13500);
            _13500 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13500);
    _13500 = NOVALUE;

    /** 			return post_fname*/
    DeRefDS(_fname_23395);
    DeRef(_pp_23396);
    _13494 = NOVALUE;
    return _post_fname_23418;
L8: 
L7: 

    /** 	if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13502 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13502);
    _13503 = _17fileext(_13502);
    _13502 = NOVALUE;
    if (_13503 == _17SHARED_LIB_EXT_5870)
    _13504 = 1;
    else if (IS_ATOM_INT(_13503) && IS_ATOM_INT(_17SHARED_LIB_EXT_5870))
    _13504 = 0;
    else
    _13504 = (compare(_13503, _17SHARED_LIB_EXT_5870) == 0);
    DeRef(_13503);
    _13503 = NOVALUE;
    if (_13504 == 0)
    {
        _13504 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13504 = NOVALUE;
    }

    /** 		integer rid = pp[PP_RID]*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _rid_23446 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_23446))
    _rid_23446 = (long)DBL_PTR(_rid_23446)->dbl;

    /** 		if rid = -1 then*/
    if (_rid_23446 != -1)
    goto LA; // [205] 307

    /** 			integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13507 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13507);
    _dll_id_23450 = _12open_dll(_13507);
    _13507 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_23450)) {
        _1 = (long)(DBL_PTR(_dll_id_23450)->dbl);
        DeRefDS(_dll_id_23450);
        _dll_id_23450 = _1;
    }

    /** 			if dll_id = -1 then*/
    if (_dll_id_23450 != -1)
    goto LB; // [223] 247

    /** 				CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13511 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13511);
    *((int *)(_2+4)) = _13511;
    _13512 = MAKE_SEQ(_1);
    _13511 = NOVALUE;
    _13513 = EPrintf(-9999999, _13510, _13512);
    DeRefDS(_13512);
    _13512 = NOVALUE;
    RefDS(_21815);
    _44CompileErr(_13513, _21815, 1);
    _13513 = NOVALUE;
LB: 

    /** 			rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 134217732;
    *((int *)(_2+8)) = 134217732;
    *((int *)(_2+12)) = 134217732;
    _13515 = MAKE_SEQ(_1);
    RefDS(_13514);
    _rid_23446 = _12define_c_func(_dll_id_23450, _13514, _13515, 100663300);
    _13515 = NOVALUE;
    if (!IS_ATOM_INT(_rid_23446)) {
        _1 = (long)(DBL_PTR(_rid_23446)->dbl);
        DeRefDS(_rid_23446);
        _rid_23446 = _1;
    }

    /** 			if rid = -1 then*/
    if (_rid_23446 != -1)
    goto LC; // [274] 291

    /** 				CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13518);
    RefDS(_21815);
    _44CompileErr(_13518, _21815, 1);

    /** 				Cleanup(1)*/
    _44Cleanup(1);
LC: 

    /** 			preprocessors[pp_id][PP_RID] = rid*/
    _2 = (int)SEQ_PTR(_36preprocessors_14998);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36preprocessors_14998 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pp_id_23397 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _rid_23446;
    DeRef(_1);
    _13519 = NOVALUE;
LA: 

    /** 		if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13521 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_fname_23395);
    *((int *)(_2+4)) = _fname_23395;
    RefDS(_post_fname_23418);
    *((int *)(_2+8)) = _post_fname_23418;
    Ref(_13521);
    *((int *)(_2+12)) = _13521;
    _13522 = MAKE_SEQ(_1);
    _13521 = NOVALUE;
    _13523 = call_c(1, _rid_23446, _13522);
    DeRefDS(_13522);
    _13522 = NOVALUE;
    if (binary_op_a(EQUALS, _13523, 0)){
        DeRef(_13523);
        _13523 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13523);
    _13523 = NOVALUE;

    /** 			CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13525);
    RefDS(_21815);
    _44CompileErr(_13525, _21815, 1);

    /** 			Cleanup(1)*/
    _44Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** 		sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13526 = (int)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_23486;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13526);
    *((int *)(_2+4)) = _13526;
    _public_cmd_args_23486 = MAKE_SEQ(_1);
    DeRef(_0);
    _13526 = NOVALUE;

    /** 		sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13528 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13528);
    _13529 = _17canonical_path(_13528, 0, 4);
    _13528 = NOVALUE;
    _0 = _cmd_args_23489;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13529;
    _cmd_args_23489 = MAKE_SEQ(_1);
    DeRef(_0);
    _13529 = NOVALUE;

    /** 		if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (int)SEQ_PTR(_pp_23396);
    _13531 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13531);
    _13532 = _17fileext(_13531);
    _13531 = NOVALUE;
    if (_13532 == _13533)
    _13534 = 1;
    else if (IS_ATOM_INT(_13532) && IS_ATOM_INT(_13533))
    _13534 = 0;
    else
    _13534 = (compare(_13532, _13533) == 0);
    DeRef(_13532);
    _13532 = NOVALUE;
    if (_13534 == 0)
    {
        _13534 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13534 = NOVALUE;
    }

    /** 			public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13535);
    *((int *)(_2+4)) = _13535;
    _13536 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23486, _13536, _public_cmd_args_23486);
    DeRefDS(_13536);
    _13536 = NOVALUE;
    DeRef(_13536);
    _13536 = NOVALUE;

    /** 			cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13535);
    *((int *)(_2+4)) = _13535;
    _13538 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_23489, _13538, _cmd_args_23489);
    DeRefDS(_13538);
    _13538 = NOVALUE;
    DeRef(_13538);
    _13538 = NOVALUE;
LF: 

    /** 		cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_23395);
    _13541 = _17canonical_path(_fname_23395, 0, 4);
    RefDS(_post_fname_23418);
    _13543 = _17canonical_path(_post_fname_23418, 0, 4);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13540);
    *((int *)(_2+4)) = _13540;
    *((int *)(_2+8)) = _13541;
    RefDS(_13542);
    *((int *)(_2+12)) = _13542;
    *((int *)(_2+16)) = _13543;
    _13544 = MAKE_SEQ(_1);
    _13543 = NOVALUE;
    _13541 = NOVALUE;
    Concat((object_ptr)&_cmd_args_23489, _cmd_args_23489, _13544);
    DeRefDS(_13544);
    _13544 = NOVALUE;

    /** 		public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13540);
    *((int *)(_2+4)) = _13540;
    RefDS(_fname_23395);
    *((int *)(_2+8)) = _fname_23395;
    RefDS(_13542);
    *((int *)(_2+12)) = _13542;
    RefDS(_post_fname_23418);
    *((int *)(_2+16)) = _post_fname_23418;
    _13546 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23486, _public_cmd_args_23486, _13546);
    DeRefDS(_13546);
    _13546 = NOVALUE;

    /** 		sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_23489);
    _13548 = _4build_commandline(_cmd_args_23489);
    _2 = (int)SEQ_PTR(_pp_23396);
    _13549 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13548) && IS_ATOM(_13549)) {
        Ref(_13549);
        Append(&_cmd_23518, _13548, _13549);
    }
    else if (IS_ATOM(_13548) && IS_SEQUENCE(_13549)) {
        Ref(_13548);
        Prepend(&_cmd_23518, _13549, _13548);
    }
    else {
        Concat((object_ptr)&_cmd_23518, _13548, _13549);
        DeRef(_13548);
        _13548 = NOVALUE;
    }
    DeRef(_13548);
    _13548 = NOVALUE;
    _13549 = NOVALUE;

    /** 		sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_23486);
    _13551 = _4build_commandline(_public_cmd_args_23486);
    _2 = (int)SEQ_PTR(_pp_23396);
    _13552 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13551) && IS_ATOM(_13552)) {
        Ref(_13552);
        Append(&_pcmd_23523, _13551, _13552);
    }
    else if (IS_ATOM(_13551) && IS_SEQUENCE(_13552)) {
        Ref(_13551);
        Prepend(&_pcmd_23523, _13552, _13551);
    }
    else {
        Concat((object_ptr)&_pcmd_23523, _13551, _13552);
        DeRef(_13551);
        _13551 = NOVALUE;
    }
    DeRef(_13551);
    _13551 = NOVALUE;
    _13552 = NOVALUE;

    /** 		integer result = system_exec(cmd, 2)*/
    _result_23528 = system_exec_call(_cmd_23518, 2);

    /** 		if result != 0 then*/
    if (_result_23528 == 0)
    goto L10; // [492] 517

    /** 			CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_23523);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _result_23528;
    ((int *)_2)[2] = _pcmd_23523;
    _13557 = MAKE_SEQ(_1);
    _13558 = EPrintf(-9999999, _13556, _13557);
    DeRefDS(_13557);
    _13557 = NOVALUE;
    RefDS(_21815);
    _44CompileErr(_13558, _21815, 1);
    _13558 = NOVALUE;

    /** 			Cleanup(1)*/
    _44Cleanup(1);
L10: 
    DeRef(_public_cmd_args_23486);
    _public_cmd_args_23486 = NOVALUE;
    DeRef(_cmd_args_23489);
    _cmd_args_23489 = NOVALUE;
    DeRef(_cmd_23518);
    _cmd_23518 = NOVALUE;
    DeRef(_pcmd_23523);
    _pcmd_23523 = NOVALUE;
LE: 

    /** 	return post_fname*/
    DeRefDS(_fname_23395);
    DeRef(_pp_23396);
    _13494 = NOVALUE;
    return _post_fname_23418;
    ;
}



// 0x912F067F
