// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _8get_bytes(int _fn_9638, int _n_9639)
{
    int _s_9640 = NOVALUE;
    int _c_9641 = NOVALUE;
    int _first_9642 = NOVALUE;
    int _last_9643 = NOVALUE;
    int _5430 = NOVALUE;
    int _5427 = NOVALUE;
    int _5425 = NOVALUE;
    int _5424 = NOVALUE;
    int _5423 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_9639)) {
        _1 = (long)(DBL_PTR(_n_9639)->dbl);
        DeRefDS(_n_9639);
        _n_9639 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_9639 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_9640);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_9638 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_9638, EF_READ);
        last_r_file_no = _fn_9638;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_9641 = getc((FILE*)xstdin);
        }
        else
        _c_9641 = getc(last_r_file_ptr);
    }
    else
    _c_9641 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_9641 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_9640);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_9640);
    _s_9640 = Repeat(_c_9641, _n_9639);

    /** 	last = 1*/
    _last_9643 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_9643 >= _n_9639)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_9642 = _last_9643 + 1;

    /** 		last  = last+CHUNK*/
    _last_9643 = _last_9643 + 100;

    /** 		if last > n then*/
    if (_last_9643 <= _n_9639)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_9643 = _n_9639;
L5: 

    /** 		for i = first to last do*/
    _5423 = _last_9643;
    {
        int _i_9657;
        _i_9657 = _first_9642;
L6: 
        if (_i_9657 > _5423){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_9638 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_9638, EF_READ);
            last_r_file_no = _fn_9638;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _5424 = getc((FILE*)xstdin);
            }
            else
            _5424 = getc(last_r_file_ptr);
        }
        else
        _5424 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_9640);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_9640 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_9657);
        *(int *)_2 = _5424;
        if( _1 != _5424 ){
        }
        _5424 = NOVALUE;

        /** 		end for*/
        _i_9657 = _i_9657 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_9640);
    _5425 = (int)*(((s1_ptr)_2)->base + _last_9643);
    if (_5425 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_9640);
    _5427 = (int)*(((s1_ptr)_2)->base + _last_9643);
    if (_5427 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_9643 = _last_9643 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_5430;
    RHS_Slice(_s_9640, 1, _last_9643);
    DeRefDSi(_s_9640);
    _5425 = NOVALUE;
    _5427 = NOVALUE;
    return _5430;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _5425 = NOVALUE;
    _5427 = NOVALUE;
    DeRef(_5430);
    _5430 = NOVALUE;
    return _s_9640;
    ;
}


int _8get_integer32(int _fh_9678)
{
    int _5439 = NOVALUE;
    int _5438 = NOVALUE;
    int _5437 = NOVALUE;
    int _5436 = NOVALUE;
    int _5435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_9678 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9678, EF_READ);
        last_r_file_no = _fh_9678;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5435 = getc((FILE*)xstdin);
        }
        else
        _5435 = getc(last_r_file_ptr);
    }
    else
    _5435 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem0_9668)){
        poke_addr = (unsigned char *)_8mem0_9668;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem0_9668)->dbl);
    }
    *poke_addr = (unsigned char)_5435;
    _5435 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_9678 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9678, EF_READ);
        last_r_file_no = _fh_9678;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5436 = getc((FILE*)xstdin);
        }
        else
        _5436 = getc(last_r_file_ptr);
    }
    else
    _5436 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem1_9669)){
        poke_addr = (unsigned char *)_8mem1_9669;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem1_9669)->dbl);
    }
    *poke_addr = (unsigned char)_5436;
    _5436 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_9678 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9678, EF_READ);
        last_r_file_no = _fh_9678;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5437 = getc((FILE*)xstdin);
        }
        else
        _5437 = getc(last_r_file_ptr);
    }
    else
    _5437 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem2_9670)){
        poke_addr = (unsigned char *)_8mem2_9670;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem2_9670)->dbl);
    }
    *poke_addr = (unsigned char)_5437;
    _5437 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_9678 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9678, EF_READ);
        last_r_file_no = _fh_9678;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5438 = getc((FILE*)xstdin);
        }
        else
        _5438 = getc(last_r_file_ptr);
    }
    else
    _5438 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem3_9671)){
        poke_addr = (unsigned char *)_8mem3_9671;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem3_9671)->dbl);
    }
    *poke_addr = (unsigned char)_5438;
    _5438 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9668)) {
        _5439 = *(unsigned long *)_8mem0_9668;
        if ((unsigned)_5439 > (unsigned)MAXINT)
        _5439 = NewDouble((double)(unsigned long)_5439);
    }
    else {
        _5439 = *(unsigned long *)(unsigned long)(DBL_PTR(_8mem0_9668)->dbl);
        if ((unsigned)_5439 > (unsigned)MAXINT)
        _5439 = NewDouble((double)(unsigned long)_5439);
    }
    return _5439;
    ;
}


int _8get_integer16(int _fh_9686)
{
    int _5442 = NOVALUE;
    int _5441 = NOVALUE;
    int _5440 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_9686 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9686, EF_READ);
        last_r_file_no = _fh_9686;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5440 = getc((FILE*)xstdin);
        }
        else
        _5440 = getc(last_r_file_ptr);
    }
    else
    _5440 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem0_9668)){
        poke_addr = (unsigned char *)_8mem0_9668;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem0_9668)->dbl);
    }
    *poke_addr = (unsigned char)_5440;
    _5440 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_9686 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_9686, EF_READ);
        last_r_file_no = _fh_9686;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _5441 = getc((FILE*)xstdin);
        }
        else
        _5441 = getc(last_r_file_ptr);
    }
    else
    _5441 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_8mem1_9669)){
        poke_addr = (unsigned char *)_8mem1_9669;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_8mem1_9669)->dbl);
    }
    *poke_addr = (unsigned char)_5441;
    _5441 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_8mem0_9668)) {
        _5442 = *(unsigned short *)_8mem0_9668;
    }
    else {
        _5442 = *(unsigned short *)(unsigned long)(DBL_PTR(_8mem0_9668)->dbl);
    }
    return _5442;
    ;
}


int _8seek(int _fn_9779, int _pos_9780)
{
    int _5488 = NOVALUE;
    int _5487 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_9780);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_9779;
    ((int *)_2)[2] = _pos_9780;
    _5487 = MAKE_SEQ(_1);
    _5488 = machine(19, _5487);
    DeRefDS(_5487);
    _5487 = NOVALUE;
    DeRef(_pos_9780);
    return _5488;
    ;
}


int _8where(int _fn_9785)
{
    int _5489 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _5489 = machine(20, _fn_9785);
    return _5489;
    ;
}


int _8read_lines(int _file_9804)
{
    int _fn_9805 = NOVALUE;
    int _ret_9806 = NOVALUE;
    int _y_9807 = NOVALUE;
    int _5518 = NOVALUE;
    int _5517 = NOVALUE;
    int _5516 = NOVALUE;
    int _5515 = NOVALUE;
    int _5510 = NOVALUE;
    int _5509 = NOVALUE;
    int _5507 = NOVALUE;
    int _5506 = NOVALUE;
    int _5505 = NOVALUE;
    int _5503 = NOVALUE;
    int _5502 = NOVALUE;
    int _5500 = NOVALUE;
    int _5499 = NOVALUE;
    int _5498 = NOVALUE;
    int _5494 = NOVALUE;
    int _5493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _5493 = 1;
    if (_5493 == 0)
    {
        _5493 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _5493 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_9804)){
            _5494 = SEQ_PTR(_file_9804)->length;
    }
    else {
        _5494 = 1;
    }
    if (_5494 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_9805);
    _fn_9805 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_9805);
    _fn_9805 = EOpen(_file_9804, _3810, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_9804);
    DeRef(_fn_9805);
    _fn_9805 = _file_9804;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_9805, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_9804);
    DeRef(_fn_9805);
    DeRef(_ret_9806);
    DeRefi(_y_9807);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_9806);
    _ret_9806 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 162
L6: 
    _5498 = IS_SEQUENCE(_y_9807);
    if (_5498 == 0)
    {
        _5498 = NOVALUE;
        goto L7; // [71] 172
    }
    else{
        _5498 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_9807)){
            _5499 = SEQ_PTR(_y_9807)->length;
    }
    else {
        _5499 = 1;
    }
    _2 = (int)SEQ_PTR(_y_9807);
    _5500 = (int)*(((s1_ptr)_2)->base + _5499);
    if (_5500 != 10)
    goto L8; // [83] 141

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_9807)){
            _5502 = SEQ_PTR(_y_9807)->length;
    }
    else {
        _5502 = 1;
    }
    _5503 = _5502 - 1;
    _5502 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_9807;
    RHS_Slice(_y_9807, 1, _5503);

    /** 			ifdef UNIX then*/

    /** 				if length(y) then*/
    if (IS_SEQUENCE(_y_9807)){
            _5505 = SEQ_PTR(_y_9807)->length;
    }
    else {
        _5505 = 1;
    }
    if (_5505 == 0)
    {
        _5505 = NOVALUE;
        goto L9; // [108] 140
    }
    else{
        _5505 = NOVALUE;
    }

    /** 					if y[$] = '\r' then*/
    if (IS_SEQUENCE(_y_9807)){
            _5506 = SEQ_PTR(_y_9807)->length;
    }
    else {
        _5506 = 1;
    }
    _2 = (int)SEQ_PTR(_y_9807);
    _5507 = (int)*(((s1_ptr)_2)->base + _5506);
    if (_5507 != 13)
    goto LA; // [120] 139

    /** 						y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_9807)){
            _5509 = SEQ_PTR(_y_9807)->length;
    }
    else {
        _5509 = 1;
    }
    _5510 = _5509 - 1;
    _5509 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_9807;
    RHS_Slice(_y_9807, 1, _5510);
LA: 
L9: 
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_9807);
    Append(&_ret_9806, _ret_9806, _y_9807);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_9805, 0)){
        goto LB; // [149] 159
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
LB: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_9807);
    _y_9807 = EGets(_fn_9805);

    /** 	end while*/
    goto L6; // [169] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _5515 = IS_SEQUENCE(_file_9804);
    if (_5515 == 0) {
        goto LC; // [177] 197
    }
    if (IS_SEQUENCE(_file_9804)){
            _5517 = SEQ_PTR(_file_9804)->length;
    }
    else {
        _5517 = 1;
    }
    _5518 = (_5517 != 0);
    _5517 = NOVALUE;
    if (_5518 == 0)
    {
        DeRef(_5518);
        _5518 = NOVALUE;
        goto LC; // [189] 197
    }
    else{
        DeRef(_5518);
        _5518 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_9805))
    EClose(_fn_9805);
    else
    EClose((int)DBL_PTR(_fn_9805)->dbl);
LC: 

    /** 	return ret*/
    DeRef(_file_9804);
    DeRef(_fn_9805);
    DeRefi(_y_9807);
    _5500 = NOVALUE;
    DeRef(_5503);
    _5503 = NOVALUE;
    _5507 = NOVALUE;
    DeRef(_5510);
    _5510 = NOVALUE;
    return _ret_9806;
    ;
}


int _8write_lines(int _file_9898, int _lines_9899)
{
    int _fn_9900 = NOVALUE;
    int _5555 = NOVALUE;
    int _5554 = NOVALUE;
    int _5553 = NOVALUE;
    int _5549 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _5549 = 1;
    if (_5549 == 0)
    {
        _5549 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _5549 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_9900);
    _fn_9900 = EOpen(_file_9898, _5550, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_9898);
    DeRef(_fn_9900);
    _fn_9900 = _file_9898;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_9900, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_9898);
    DeRefDS(_lines_9899);
    DeRef(_fn_9900);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_9899)){
            _5553 = SEQ_PTR(_lines_9899)->length;
    }
    else {
        _5553 = 1;
    }
    {
        int _i_9909;
        _i_9909 = 1;
L4: 
        if (_i_9909 > _5553){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_9899);
        _5554 = (int)*(((s1_ptr)_2)->base + _i_9909);
        EPuts(_fn_9900, _5554); // DJP 
        _5554 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_9900, 10); // DJP 

        /** 	end for*/
        _i_9909 = _i_9909 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _5555 = IS_SEQUENCE(_file_9898);
    if (_5555 == 0)
    {
        _5555 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _5555 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_9900))
    EClose(_fn_9900);
    else
    EClose((int)DBL_PTR(_fn_9900)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_9898);
    DeRefDS(_lines_9899);
    DeRef(_fn_9900);
    return 1;
    ;
}


int _8write_file(int _file_9977, int _data_9978, int _as_text_9979)
{
    int _fn_9980 = NOVALUE;
    int _5601 = NOVALUE;
    int _5596 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if as_text != BINARY_MODE then*/

    /** 	if sequence(file) then*/
    _5596 = 1;
    if (_5596 == 0)
    {
        _5596 = NOVALUE;
        goto L1; // [151] 181
    }
    else{
        _5596 = NOVALUE;
    }

    /** 		if as_text = TEXT_MODE then*/

    /** 			fn = open(file, "wb")*/
    _fn_9980 = EOpen(_file_9977, _3203, 0);
    goto L2; // [178] 189
L1: 

    /** 		fn = file*/
    Ref(_file_9977);
    _fn_9980 = _file_9977;
    if (!IS_ATOM_INT(_fn_9980)) {
        _1 = (long)(DBL_PTR(_fn_9980)->dbl);
        DeRefDS(_fn_9980);
        _fn_9980 = _1;
    }
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (_fn_9980 >= 0)
    goto L3; // [193] 202
    DeRefi(_file_9977);
    DeRefDS(_data_9978);
    return -1;
L3: 

    /** 	puts(fn, data)*/
    EPuts(_fn_9980, _data_9978); // DJP 

    /** 	if sequence(file) then*/
    _5601 = IS_SEQUENCE(_file_9977);
    if (_5601 == 0)
    {
        _5601 = NOVALUE;
        goto L4; // [212] 220
    }
    else{
        _5601 = NOVALUE;
    }

    /** 		close(fn)*/
    EClose(_fn_9980);
L4: 

    /** 	return 1*/
    DeRefi(_file_9977);
    DeRefDS(_data_9978);
    return 1;
    ;
}


void _8writef(int _fm_10020, int _data_10021, int _fn_10022, int _data_not_string_10023)
{
    int _real_fn_10024 = NOVALUE;
    int _close_fn_10025 = NOVALUE;
    int _out_style_10026 = NOVALUE;
    int _ts_10029 = NOVALUE;
    int _msg_inlined_crash_at_163_10054 = NOVALUE;
    int _data_inlined_crash_at_160_10053 = NOVALUE;
    int _5621 = NOVALUE;
    int _5619 = NOVALUE;
    int _5618 = NOVALUE;
    int _5617 = NOVALUE;
    int _5611 = NOVALUE;
    int _5610 = NOVALUE;
    int _5609 = NOVALUE;
    int _5608 = NOVALUE;
    int _5607 = NOVALUE;
    int _5606 = NOVALUE;
    int _5604 = NOVALUE;
    int _5603 = NOVALUE;
    int _5602 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_10024 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_10025 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_5550);
    DeRefi(_out_style_10026);
    _out_style_10026 = _5550;

    /** 	if integer(fm) then*/
    _5602 = 1;
    if (_5602 == 0)
    {
        _5602 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _5602 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    _ts_10029 = _fm_10020;

    /** 		fm = data*/
    RefDS(_data_10021);
    _fm_10020 = _data_10021;

    /** 		data = fn*/
    RefDS(_fn_10022);
    DeRefDS(_data_10021);
    _data_10021 = _fn_10022;

    /** 		fn = ts*/
    DeRefDS(_fn_10022);
    _fn_10022 = _ts_10029;
L1: 

    /** 	if sequence(fn) then*/
    _5603 = IS_SEQUENCE(_fn_10022);
    if (_5603 == 0)
    {
        _5603 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _5603 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_10022)){
            _5604 = SEQ_PTR(_fn_10022)->length;
    }
    else {
        _5604 = 1;
    }
    if (_5604 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_10022);
    _5606 = (int)*(((s1_ptr)_2)->base + 1);
    _5607 = IS_SEQUENCE(_5606);
    _5606 = NOVALUE;
    if (_5607 == 0)
    {
        _5607 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _5607 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_10022);
    _5608 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5608 == 97)
    _5609 = 1;
    else if (IS_ATOM_INT(_5608) && IS_ATOM_INT(97))
    _5609 = 0;
    else
    _5609 = (compare(_5608, 97) == 0);
    _5608 = NOVALUE;
    if (_5609 == 0)
    {
        _5609 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _5609 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_5556);
    DeRefi(_out_style_10026);
    _out_style_10026 = _5556;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_10022);
    _5610 = (int)*(((s1_ptr)_2)->base + 2);
    if (_5610 == _5556)
    _5611 = 1;
    else if (IS_ATOM_INT(_5610) && IS_ATOM_INT(_5556))
    _5611 = 0;
    else
    _5611 = (compare(_5610, _5556) == 0);
    _5610 = NOVALUE;
    if (_5611 != 0)
    goto L7; // [113] 126
    _5611 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_5550);
    DeRefi(_out_style_10026);
    _out_style_10026 = _5550;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_5556);
    DeRefi(_out_style_10026);
    _out_style_10026 = _5556;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_10022;
    _2 = (int)SEQ_PTR(_fn_10022);
    _fn_10022 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_10022);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_10024 = EOpen(_fn_10022, _out_style_10026, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_10024 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_10022);
    *((int *)(_2+4)) = _fn_10022;
    _5617 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_10053);
    _data_inlined_crash_at_160_10053 = _5617;
    _5617 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_10054);
    _msg_inlined_crash_at_163_10054 = EPrintf(-9999999, _5616, _data_inlined_crash_at_160_10053);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_10054);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_10053);
    _data_inlined_crash_at_160_10053 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_10054);
    _msg_inlined_crash_at_163_10054 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_10025 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_10022);
    _real_fn_10024 = _fn_10022;
    if (!IS_ATOM_INT(_real_fn_10024)) {
        _1 = (long)(DBL_PTR(_real_fn_10024)->dbl);
        DeRefDS(_real_fn_10024);
        _real_fn_10024 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_10023 == 0)
    _5618 = 1;
    else if (IS_ATOM_INT(_data_not_string_10023) && IS_ATOM_INT(0))
    _5618 = 0;
    else
    _5618 = (compare(_data_not_string_10023, 0) == 0);
    if (_5618 == 0)
    {
        _5618 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _5618 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_10021);
    _5619 = _13t_display(_data_10021);
    if (_5619 == 0) {
        DeRef(_5619);
        _5619 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_5619) && DBL_PTR(_5619)->dbl == 0.0){
            DeRef(_5619);
            _5619 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_5619);
        _5619 = NOVALUE;
    }
    DeRef(_5619);
    _5619 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_10021;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_10021);
    *((int *)(_2+4)) = _data_10021;
    _data_10021 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_10020);
    Ref(_data_10021);
    _5621 = _14format(_fm_10020, _data_10021);
    EPuts(_real_fn_10024, _5621); // DJP 
    DeRef(_5621);
    _5621 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_10025 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_10024);
LD: 

    /** end procedure*/
    DeRef(_fm_10020);
    DeRef(_data_10021);
    DeRef(_fn_10022);
    DeRefi(_out_style_10026);
    return;
    ;
}



// 0x1501F4A7
