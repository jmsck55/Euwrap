// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _45GetMsgText(int _MsgNum_20817, int _WithNum_20818, int _Args_20819)
{
    int _idx_20820 = NOVALUE;
    int _msgtext_20821 = NOVALUE;
    int _12049 = NOVALUE;
    int _12048 = NOVALUE;
    int _12044 = NOVALUE;
    int _12043 = NOVALUE;
    int _12041 = NOVALUE;
    int _12039 = NOVALUE;
    int _12037 = NOVALUE;
    int _12036 = NOVALUE;
    int _12035 = NOVALUE;
    int _12034 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_20817)) {
        _1 = (long)(DBL_PTR(_MsgNum_20817)->dbl);
        DeRefDS(_MsgNum_20817);
        _MsgNum_20817 = _1;
    }

    /** 	integer idx = 1*/
    _idx_20820 = 1;

    /** 	msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    RefDS(_36LocalizeQual_15000);
    RefDS(_36LocalDB_15001);
    _0 = _msgtext_20821;
    _msgtext_20821 = _46get_text(_MsgNum_20817, _36LocalizeQual_15000, _36LocalDB_15001);
    DeRef(_0);

    /** 	if atom(msgtext) then*/
    _12034 = IS_ATOM(_msgtext_20821);
    if (_12034 == 0)
    {
        _12034 = NOVALUE;
        goto L1; // [27] 90
    }
    else{
        _12034 = NOVALUE;
    }

    /** 		for i = 1 to length(StdErrMsgs) do*/
    _12035 = 354;
    {
        int _i_20829;
        _i_20829 = 1;
L2: 
        if (_i_20829 > 354){
            goto L3; // [37] 77
        }

        /** 			if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (int)SEQ_PTR(_45StdErrMsgs_19824);
        _12036 = (int)*(((s1_ptr)_2)->base + _i_20829);
        _2 = (int)SEQ_PTR(_12036);
        _12037 = (int)*(((s1_ptr)_2)->base + 1);
        _12036 = NOVALUE;
        if (binary_op_a(NOTEQ, _12037, _MsgNum_20817)){
            _12037 = NOVALUE;
            goto L4; // [56] 70
        }
        _12037 = NOVALUE;

        /** 				idx = i*/
        _idx_20820 = _i_20829;

        /** 				exit*/
        goto L3; // [67] 77
L4: 

        /** 		end for*/
        _i_20829 = _i_20829 + 1;
        goto L2; // [72] 44
L3: 
        ;
    }

    /** 		msgtext = StdErrMsgs[idx][2]*/
    _2 = (int)SEQ_PTR(_45StdErrMsgs_19824);
    _12039 = (int)*(((s1_ptr)_2)->base + _idx_20820);
    DeRef(_msgtext_20821);
    _2 = (int)SEQ_PTR(_12039);
    _msgtext_20821 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_20821);
    _12039 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12041 = IS_ATOM(_Args_20819);
    if (_12041 != 0) {
        goto L5; // [95] 111
    }
    if (IS_SEQUENCE(_Args_20819)){
            _12043 = SEQ_PTR(_Args_20819)->length;
    }
    else {
        _12043 = 1;
    }
    _12044 = (_12043 != 0);
    _12043 = NOVALUE;
    if (_12044 == 0)
    {
        DeRef(_12044);
        _12044 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        DeRef(_12044);
        _12044 = NOVALUE;
    }
L5: 

    /** 		msgtext = format(msgtext, Args)*/
    Ref(_msgtext_20821);
    Ref(_Args_20819);
    _0 = _msgtext_20821;
    _msgtext_20821 = _14format(_msgtext_20821, _Args_20819);
    DeRef(_0);
L6: 

    /** 	if WithNum != 0 then*/
    if (_WithNum_20818 == 0)
    goto L7; // [121] 142

    /** 		return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_20821);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _MsgNum_20817;
    ((int *)_2)[2] = _msgtext_20821;
    _12048 = MAKE_SEQ(_1);
    _12049 = EPrintf(-9999999, _12047, _12048);
    DeRefDS(_12048);
    _12048 = NOVALUE;
    DeRef(_Args_20819);
    DeRef(_msgtext_20821);
    return _12049;
    goto L8; // [139] 149
L7: 

    /** 		return msgtext*/
    DeRef(_Args_20819);
    DeRef(_12049);
    _12049 = NOVALUE;
    return _msgtext_20821;
L8: 
    ;
}


void _45ShowMsg(int _Cons_20852, int _Msg_20853, int _Args_20854, int _NL_20855)
{
    int _12056 = NOVALUE;
    int _12055 = NOVALUE;
    int _12053 = NOVALUE;
    int _12051 = NOVALUE;
    int _12050 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(Msg) then*/
    _12050 = 1;
    if (_12050 == 0)
    {
        _12050 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12050 = NOVALUE;
    }

    /** 		Msg = GetMsgText(floor(Msg), 0)*/
    _12051 = e_floor(_Msg_20853);
    RefDS(_5);
    _Msg_20853 = _45GetMsgText(_12051, 0, _5);
    _12051 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12053 = IS_ATOM(_Args_20854);
    if (_12053 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_20854)){
            _12055 = SEQ_PTR(_Args_20854)->length;
    }
    else {
        _12055 = 1;
    }
    _12056 = (_12055 != 0);
    _12055 = NOVALUE;
    if (_12056 == 0)
    {
        DeRef(_12056);
        _12056 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12056);
        _12056 = NOVALUE;
    }
L2: 

    /** 		Msg = format(Msg, Args)*/
    Ref(_Msg_20853);
    Ref(_Args_20854);
    _0 = _Msg_20853;
    _Msg_20853 = _14format(_Msg_20853, _Args_20854);
    DeRef(_0);
L3: 

    /** 	puts(Cons, Msg)*/
    EPuts(_Cons_20852, _Msg_20853); // DJP 

    /** 	if NL then*/
    if (_NL_20855 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** 		puts(Cons, '\n')*/
    EPuts(_Cons_20852, 10); // DJP 
L4: 

    /** end procedure*/
    DeRef(_Msg_20853);
    DeRef(_Args_20854);
    return;
    ;
}



// 0x47E820EA
