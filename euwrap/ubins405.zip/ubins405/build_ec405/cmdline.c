// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _4local_abort(int _lvl_13872)
{
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_17_13877 = NOVALUE;
    int _7707 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(pause_msg) != 0 then*/
    _7707 = 0;

    /** 	abort(lvl)*/
    UserCleanup(_lvl_13872);

    /** end procedure*/
    return;
    ;
}


int _4standardize_opts(int _opts_13880, int _auto_help_switches_13881)
{
    int _lExtras_13882 = NOVALUE;
    int _opt_13886 = NOVALUE;
    int _updated_13888 = NOVALUE;
    int _msg_inlined_crash_at_178_13920 = NOVALUE;
    int _msg_inlined_crash_at_354_13951 = NOVALUE;
    int _msg_inlined_crash_at_410_13960 = NOVALUE;
    int _msg_inlined_crash_at_460_13969 = NOVALUE;
    int _msg_inlined_crash_at_510_13978 = NOVALUE;
    int _msg_inlined_crash_at_560_13987 = NOVALUE;
    int _opt_14021 = NOVALUE;
    int _msg_inlined_crash_at_878_14040 = NOVALUE;
    int _data_inlined_crash_at_875_14039 = NOVALUE;
    int _msg_inlined_crash_at_967_14058 = NOVALUE;
    int _data_inlined_crash_at_964_14057 = NOVALUE;
    int _has_h_14059 = NOVALUE;
    int _has_help_14060 = NOVALUE;
    int _has_question_14061 = NOVALUE;
    int _appended_opts_14081 = NOVALUE;
    int _7884 = NOVALUE;
    int _7883 = NOVALUE;
    int _7881 = NOVALUE;
    int _7880 = NOVALUE;
    int _7879 = NOVALUE;
    int _7878 = NOVALUE;
    int _7877 = NOVALUE;
    int _7876 = NOVALUE;
    int _7875 = NOVALUE;
    int _7874 = NOVALUE;
    int _7873 = NOVALUE;
    int _7872 = NOVALUE;
    int _7871 = NOVALUE;
    int _7870 = NOVALUE;
    int _7868 = NOVALUE;
    int _7867 = NOVALUE;
    int _7866 = NOVALUE;
    int _7865 = NOVALUE;
    int _7864 = NOVALUE;
    int _7863 = NOVALUE;
    int _7862 = NOVALUE;
    int _7861 = NOVALUE;
    int _7860 = NOVALUE;
    int _7859 = NOVALUE;
    int _7858 = NOVALUE;
    int _7857 = NOVALUE;
    int _7855 = NOVALUE;
    int _7853 = NOVALUE;
    int _7852 = NOVALUE;
    int _7851 = NOVALUE;
    int _7850 = NOVALUE;
    int _7848 = NOVALUE;
    int _7846 = NOVALUE;
    int _7843 = NOVALUE;
    int _7840 = NOVALUE;
    int _7837 = NOVALUE;
    int _7835 = NOVALUE;
    int _7834 = NOVALUE;
    int _7833 = NOVALUE;
    int _7832 = NOVALUE;
    int _7830 = NOVALUE;
    int _7829 = NOVALUE;
    int _7828 = NOVALUE;
    int _7826 = NOVALUE;
    int _7825 = NOVALUE;
    int _7824 = NOVALUE;
    int _7822 = NOVALUE;
    int _7821 = NOVALUE;
    int _7820 = NOVALUE;
    int _7819 = NOVALUE;
    int _7818 = NOVALUE;
    int _7816 = NOVALUE;
    int _7815 = NOVALUE;
    int _7814 = NOVALUE;
    int _7813 = NOVALUE;
    int _7812 = NOVALUE;
    int _7811 = NOVALUE;
    int _7810 = NOVALUE;
    int _7809 = NOVALUE;
    int _7808 = NOVALUE;
    int _7807 = NOVALUE;
    int _7805 = NOVALUE;
    int _7804 = NOVALUE;
    int _7803 = NOVALUE;
    int _7802 = NOVALUE;
    int _7801 = NOVALUE;
    int _7800 = NOVALUE;
    int _7799 = NOVALUE;
    int _7798 = NOVALUE;
    int _7796 = NOVALUE;
    int _7795 = NOVALUE;
    int _7794 = NOVALUE;
    int _7793 = NOVALUE;
    int _7792 = NOVALUE;
    int _7791 = NOVALUE;
    int _7790 = NOVALUE;
    int _7789 = NOVALUE;
    int _7788 = NOVALUE;
    int _7787 = NOVALUE;
    int _7786 = NOVALUE;
    int _7785 = NOVALUE;
    int _7784 = NOVALUE;
    int _7783 = NOVALUE;
    int _7782 = NOVALUE;
    int _7780 = NOVALUE;
    int _7778 = NOVALUE;
    int _7777 = NOVALUE;
    int _7776 = NOVALUE;
    int _7775 = NOVALUE;
    int _7773 = NOVALUE;
    int _7772 = NOVALUE;
    int _7771 = NOVALUE;
    int _7770 = NOVALUE;
    int _7768 = NOVALUE;
    int _7767 = NOVALUE;
    int _7766 = NOVALUE;
    int _7765 = NOVALUE;
    int _7763 = NOVALUE;
    int _7762 = NOVALUE;
    int _7761 = NOVALUE;
    int _7760 = NOVALUE;
    int _7758 = NOVALUE;
    int _7757 = NOVALUE;
    int _7756 = NOVALUE;
    int _7755 = NOVALUE;
    int _7752 = NOVALUE;
    int _7751 = NOVALUE;
    int _7750 = NOVALUE;
    int _7749 = NOVALUE;
    int _7748 = NOVALUE;
    int _7747 = NOVALUE;
    int _7746 = NOVALUE;
    int _7745 = NOVALUE;
    int _7743 = NOVALUE;
    int _7742 = NOVALUE;
    int _7741 = NOVALUE;
    int _7740 = NOVALUE;
    int _7739 = NOVALUE;
    int _7738 = NOVALUE;
    int _7737 = NOVALUE;
    int _7736 = NOVALUE;
    int _7733 = NOVALUE;
    int _7732 = NOVALUE;
    int _7731 = NOVALUE;
    int _7730 = NOVALUE;
    int _7729 = NOVALUE;
    int _7728 = NOVALUE;
    int _7727 = NOVALUE;
    int _7726 = NOVALUE;
    int _7725 = NOVALUE;
    int _7724 = NOVALUE;
    int _7723 = NOVALUE;
    int _7722 = NOVALUE;
    int _7721 = NOVALUE;
    int _7720 = NOVALUE;
    int _7719 = NOVALUE;
    int _7718 = NOVALUE;
    int _7717 = NOVALUE;
    int _7715 = NOVALUE;
    int _7714 = NOVALUE;
    int _7713 = NOVALUE;
    int _7711 = NOVALUE;
    int _7709 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer lExtras = 0 -- Ensure that there is zero or one 'extras' record only.*/
    _lExtras_13882 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_13880)){
            _7709 = SEQ_PTR(_opts_13880)->length;
    }
    else {
        _7709 = 1;
    }
    {
        int _i_13884;
        _i_13884 = 1;
L1: 
        if (_i_13884 > _7709){
            goto L2; // [15] 795
        }

        /** 		sequence opt = opts[i]*/
        DeRef(_opt_13886);
        _2 = (int)SEQ_PTR(_opts_13880);
        _opt_13886 = (int)*(((s1_ptr)_2)->base + _i_13884);
        Ref(_opt_13886);

        /** 		integer updated = 0*/
        _updated_13888 = 0;

        /** 		if length(opt) < MAPNAME then*/
        if (IS_SEQUENCE(_opt_13886)){
                _7711 = SEQ_PTR(_opt_13886)->length;
        }
        else {
            _7711 = 1;
        }
        if (_7711 >= 6)
        goto L3; // [40] 67

        /** 			opt &= repeat(-1, MAPNAME - length(opt))*/
        if (IS_SEQUENCE(_opt_13886)){
                _7713 = SEQ_PTR(_opt_13886)->length;
        }
        else {
            _7713 = 1;
        }
        _7714 = 6 - _7713;
        _7713 = NOVALUE;
        _7715 = Repeat(-1, _7714);
        _7714 = NOVALUE;
        Concat((object_ptr)&_opt_13886, _opt_13886, _7715);
        DeRefDS(_7715);
        _7715 = NOVALUE;

        /** 			updated = 1*/
        _updated_13888 = 1;
L3: 

        /** 		if sequence(opt[SHORTNAME]) and length(opt[SHORTNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7717 = (int)*(((s1_ptr)_2)->base + 1);
        _7718 = IS_SEQUENCE(_7717);
        _7717 = NOVALUE;
        if (_7718 == 0) {
            goto L4; // [76] 107
        }
        _2 = (int)SEQ_PTR(_opt_13886);
        _7720 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_SEQUENCE(_7720)){
                _7721 = SEQ_PTR(_7720)->length;
        }
        else {
            _7721 = 1;
        }
        _7720 = NOVALUE;
        _7722 = (_7721 == 0);
        _7721 = NOVALUE;
        if (_7722 == 0)
        {
            DeRef(_7722);
            _7722 = NOVALUE;
            goto L4; // [92] 107
        }
        else{
            DeRef(_7722);
            _7722 = NOVALUE;
        }

        /** 			opt[SHORTNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
L4: 

        /** 		if sequence(opt[LONGNAME]) and length(opt[LONGNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7723 = (int)*(((s1_ptr)_2)->base + 2);
        _7724 = IS_SEQUENCE(_7723);
        _7723 = NOVALUE;
        if (_7724 == 0) {
            goto L5; // [116] 147
        }
        _2 = (int)SEQ_PTR(_opt_13886);
        _7726 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_7726)){
                _7727 = SEQ_PTR(_7726)->length;
        }
        else {
            _7727 = 1;
        }
        _7726 = NOVALUE;
        _7728 = (_7727 == 0);
        _7727 = NOVALUE;
        if (_7728 == 0)
        {
            DeRef(_7728);
            _7728 = NOVALUE;
            goto L5; // [132] 147
        }
        else{
            DeRef(_7728);
            _7728 = NOVALUE;
        }

        /** 			opt[LONGNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
L5: 

        /** 		if atom(opt[LONGNAME]) and atom(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7729 = (int)*(((s1_ptr)_2)->base + 2);
        _7730 = IS_ATOM(_7729);
        _7729 = NOVALUE;
        if (_7730 == 0) {
            goto L6; // [156] 233
        }
        _2 = (int)SEQ_PTR(_opt_13886);
        _7732 = (int)*(((s1_ptr)_2)->base + 1);
        _7733 = IS_ATOM(_7732);
        _7732 = NOVALUE;
        if (_7733 == 0)
        {
            _7733 = NOVALUE;
            goto L6; // [168] 233
        }
        else{
            _7733 = NOVALUE;
        }

        /** 			if lExtras != 0 then*/
        if (_lExtras_13882 == 0)
        goto L7; // [173] 200

        /** 				error:crash("cmd_opts: There must be less than two 'extras' option records.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_178_13920);
        _msg_inlined_crash_at_178_13920 = EPrintf(-9999999, _7735, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_178_13920);

        /** end procedure*/
        goto L8; // [192] 195
L8: 
        DeRefi(_msg_inlined_crash_at_178_13920);
        _msg_inlined_crash_at_178_13920 = NOVALUE;
        goto L9; // [197] 232
L7: 

        /** 				lExtras = i*/
        _lExtras_13882 = _i_13884;

        /** 				if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7736 = (int)*(((s1_ptr)_2)->base + 6);
        _7737 = IS_ATOM(_7736);
        _7736 = NOVALUE;
        if (_7737 == 0)
        {
            _7737 = NOVALUE;
            goto LA; // [214] 231
        }
        else{
            _7737 = NOVALUE;
        }

        /** 					opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_13858);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _4EXTRAS_13858;
        DeRef(_1);

        /** 					updated = 1*/
        _updated_13888 = 1;
LA: 
L9: 
L6: 

        /** 		if atom(opt[DESCRIPTION]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7738 = (int)*(((s1_ptr)_2)->base + 3);
        _7739 = IS_ATOM(_7738);
        _7738 = NOVALUE;
        if (_7739 == 0)
        {
            _7739 = NOVALUE;
            goto LB; // [242] 257
        }
        else{
            _7739 = NOVALUE;
        }

        /** 			opt[DESCRIPTION] = ""*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
LB: 

        /** 		if atom(opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7740 = (int)*(((s1_ptr)_2)->base + 4);
        _7741 = IS_ATOM(_7740);
        _7740 = NOVALUE;
        if (_7741 == 0)
        {
            _7741 = NOVALUE;
            goto LC; // [266] 310
        }
        else{
            _7741 = NOVALUE;
        }

        /** 			if equal(opt[OPTIONS], HAS_PARAMETER) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7742 = (int)*(((s1_ptr)_2)->base + 4);
        if (_7742 == 112)
        _7743 = 1;
        else if (IS_ATOM_INT(_7742) && IS_ATOM_INT(112))
        _7743 = 0;
        else
        _7743 = (compare(_7742, 112) == 0);
        _7742 = NOVALUE;
        if (_7743 == 0)
        {
            _7743 = NOVALUE;
            goto LD; // [279] 295
        }
        else{
            _7743 = NOVALUE;
        }

        /** 				opt[OPTIONS] = {HAS_PARAMETER,"x"}*/
        RefDS(_7744);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 112;
        ((int *)_2)[2] = _7744;
        _7745 = MAKE_SEQ(_1);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _7745;
        if( _1 != _7745 ){
            DeRef(_1);
        }
        _7745 = NOVALUE;
        goto LE; // [292] 302
LD: 

        /** 				opt[OPTIONS] = {}*/
        RefDS(_5);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _5;
        DeRef(_1);
LE: 

        /** 			updated = 1*/
        _updated_13888 = 1;
        goto LF; // [307] 582
LC: 

        /** 			for j = 1 to length(opt[OPTIONS]) do*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7746 = (int)*(((s1_ptr)_2)->base + 4);
        if (IS_SEQUENCE(_7746)){
                _7747 = SEQ_PTR(_7746)->length;
        }
        else {
            _7747 = 1;
        }
        _7746 = NOVALUE;
        {
            int _j_13939;
            _j_13939 = 1;
L10: 
            if (_j_13939 > _7747){
                goto L11; // [319] 381
            }

            /** 				if find(opt[OPTIONS][j], opt[OPTIONS], j + 1) != 0 then*/
            _2 = (int)SEQ_PTR(_opt_13886);
            _7748 = (int)*(((s1_ptr)_2)->base + 4);
            _2 = (int)SEQ_PTR(_7748);
            _7749 = (int)*(((s1_ptr)_2)->base + _j_13939);
            _7748 = NOVALUE;
            _2 = (int)SEQ_PTR(_opt_13886);
            _7750 = (int)*(((s1_ptr)_2)->base + 4);
            _7751 = _j_13939 + 1;
            _7752 = find_from(_7749, _7750, _7751);
            _7749 = NOVALUE;
            _7750 = NOVALUE;
            _7751 = NOVALUE;
            if (_7752 == 0)
            goto L12; // [349] 374

            /** 					error:crash("cmd_opts: Duplicate processing options are not allowed in an option record.\n")*/

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_354_13951);
            _msg_inlined_crash_at_354_13951 = EPrintf(-9999999, _7754, _5);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_354_13951);

            /** end procedure*/
            goto L13; // [368] 371
L13: 
            DeRefi(_msg_inlined_crash_at_354_13951);
            _msg_inlined_crash_at_354_13951 = NOVALUE;
L12: 

            /** 			end for*/
            _j_13939 = _j_13939 + 1;
            goto L10; // [376] 326
L11: 
            ;
        }

        /** 			if find(HAS_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7755 = (int)*(((s1_ptr)_2)->base + 4);
        _7756 = find_from(112, _7755, 1);
        _7755 = NOVALUE;
        if (_7756 == 0)
        {
            _7756 = NOVALUE;
            goto L14; // [392] 431
        }
        else{
            _7756 = NOVALUE;
        }

        /** 				if find(NO_PARAMETER, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7757 = (int)*(((s1_ptr)_2)->base + 4);
        _7758 = find_from(110, _7757, 1);
        _7757 = NOVALUE;
        if (_7758 == 0)
        {
            _7758 = NOVALUE;
            goto L15; // [406] 430
        }
        else{
            _7758 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_PARAMETER and NO_PARAMETER in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_410_13960);
        _msg_inlined_crash_at_410_13960 = EPrintf(-9999999, _7759, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_410_13960);

        /** end procedure*/
        goto L16; // [424] 427
L16: 
        DeRefi(_msg_inlined_crash_at_410_13960);
        _msg_inlined_crash_at_410_13960 = NOVALUE;
L15: 
L14: 

        /** 			if find(HAS_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7760 = (int)*(((s1_ptr)_2)->base + 4);
        _7761 = find_from(99, _7760, 1);
        _7760 = NOVALUE;
        if (_7761 == 0)
        {
            _7761 = NOVALUE;
            goto L17; // [442] 481
        }
        else{
            _7761 = NOVALUE;
        }

        /** 				if find(NO_CASE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7762 = (int)*(((s1_ptr)_2)->base + 4);
        _7763 = find_from(105, _7762, 1);
        _7762 = NOVALUE;
        if (_7763 == 0)
        {
            _7763 = NOVALUE;
            goto L18; // [456] 480
        }
        else{
            _7763 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both HAS_CASE and NO_CASE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_460_13969);
        _msg_inlined_crash_at_460_13969 = EPrintf(-9999999, _7764, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_460_13969);

        /** end procedure*/
        goto L19; // [474] 477
L19: 
        DeRefi(_msg_inlined_crash_at_460_13969);
        _msg_inlined_crash_at_460_13969 = NOVALUE;
L18: 
L17: 

        /** 			if find(MANDATORY, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7765 = (int)*(((s1_ptr)_2)->base + 4);
        _7766 = find_from(109, _7765, 1);
        _7765 = NOVALUE;
        if (_7766 == 0)
        {
            _7766 = NOVALUE;
            goto L1A; // [492] 531
        }
        else{
            _7766 = NOVALUE;
        }

        /** 				if find(OPTIONAL, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7767 = (int)*(((s1_ptr)_2)->base + 4);
        _7768 = find_from(111, _7767, 1);
        _7767 = NOVALUE;
        if (_7768 == 0)
        {
            _7768 = NOVALUE;
            goto L1B; // [506] 530
        }
        else{
            _7768 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both MANDATORY and OPTIONAL in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_510_13978);
        _msg_inlined_crash_at_510_13978 = EPrintf(-9999999, _7769, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_510_13978);

        /** end procedure*/
        goto L1C; // [524] 527
L1C: 
        DeRefi(_msg_inlined_crash_at_510_13978);
        _msg_inlined_crash_at_510_13978 = NOVALUE;
L1B: 
L1A: 

        /** 			if find(ONCE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7770 = (int)*(((s1_ptr)_2)->base + 4);
        _7771 = find_from(49, _7770, 1);
        _7770 = NOVALUE;
        if (_7771 == 0)
        {
            _7771 = NOVALUE;
            goto L1D; // [542] 581
        }
        else{
            _7771 = NOVALUE;
        }

        /** 				if find(MULTIPLE, opt[OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7772 = (int)*(((s1_ptr)_2)->base + 4);
        _7773 = find_from(42, _7772, 1);
        _7772 = NOVALUE;
        if (_7773 == 0)
        {
            _7773 = NOVALUE;
            goto L1E; // [556] 580
        }
        else{
            _7773 = NOVALUE;
        }

        /** 					error:crash("cmd_opts: Cannot have both ONCE and MULTIPLE in an option record.\n")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_560_13987);
        _msg_inlined_crash_at_560_13987 = EPrintf(-9999999, _7774, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_560_13987);

        /** end procedure*/
        goto L1F; // [574] 577
L1F: 
        DeRefi(_msg_inlined_crash_at_560_13987);
        _msg_inlined_crash_at_560_13987 = NOVALUE;
L1E: 
L1D: 
LF: 

        /** 		if sequence(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7775 = (int)*(((s1_ptr)_2)->base + 5);
        _7776 = IS_SEQUENCE(_7775);
        _7775 = NOVALUE;
        if (_7776 == 0)
        {
            _7776 = NOVALUE;
            goto L20; // [591] 608
        }
        else{
            _7776 = NOVALUE;
        }

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
        goto L21; // [605] 657
L20: 

        /** 		elsif not integer(opt[CALLBACK]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7777 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_7777))
        _7778 = 1;
        else if (IS_ATOM_DBL(_7777))
        _7778 = IS_ATOM_INT(DoubleToInt(_7777));
        else
        _7778 = 0;
        _7777 = NOVALUE;
        if (_7778 != 0)
        goto L22; // [617] 634
        _7778 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
        goto L21; // [631] 657
L22: 

        /** 		elsif opt[CALLBACK] < 0 then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7780 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(GREATEREQ, _7780, 0)){
            _7780 = NOVALUE;
            goto L23; // [640] 656
        }
        _7780 = NOVALUE;

        /** 			opt[CALLBACK] = -1*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
L23: 
L21: 

        /** 		if sequence(opt[MAPNAME]) and length(opt[MAPNAME]) = 0 then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7782 = (int)*(((s1_ptr)_2)->base + 6);
        _7783 = IS_SEQUENCE(_7782);
        _7782 = NOVALUE;
        if (_7783 == 0) {
            goto L24; // [666] 697
        }
        _2 = (int)SEQ_PTR(_opt_13886);
        _7785 = (int)*(((s1_ptr)_2)->base + 6);
        if (IS_SEQUENCE(_7785)){
                _7786 = SEQ_PTR(_7785)->length;
        }
        else {
            _7786 = 1;
        }
        _7785 = NOVALUE;
        _7787 = (_7786 == 0);
        _7786 = NOVALUE;
        if (_7787 == 0)
        {
            DeRef(_7787);
            _7787 = NOVALUE;
            goto L24; // [682] 697
        }
        else{
            DeRef(_7787);
            _7787 = NOVALUE;
        }

        /** 			opt[MAPNAME] = 0*/
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 			updated = 1*/
        _updated_13888 = 1;
L24: 

        /** 		if atom(opt[MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7788 = (int)*(((s1_ptr)_2)->base + 6);
        _7789 = IS_ATOM(_7788);
        _7788 = NOVALUE;
        if (_7789 == 0)
        {
            _7789 = NOVALUE;
            goto L25; // [706] 774
        }
        else{
            _7789 = NOVALUE;
        }

        /** 			if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7790 = (int)*(((s1_ptr)_2)->base + 2);
        _7791 = IS_SEQUENCE(_7790);
        _7790 = NOVALUE;
        if (_7791 == 0)
        {
            _7791 = NOVALUE;
            goto L26; // [718] 734
        }
        else{
            _7791 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[LONGNAME]*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7792 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_7792);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _7792;
        if( _1 != _7792 ){
            DeRef(_1);
        }
        _7792 = NOVALUE;
        goto L27; // [731] 768
L26: 

        /** 			elsif sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7793 = (int)*(((s1_ptr)_2)->base + 1);
        _7794 = IS_SEQUENCE(_7793);
        _7793 = NOVALUE;
        if (_7794 == 0)
        {
            _7794 = NOVALUE;
            goto L28; // [743] 759
        }
        else{
            _7794 = NOVALUE;
        }

        /** 				opt[MAPNAME] = opt[SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opt_13886);
        _7795 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_7795);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _7795;
        if( _1 != _7795 ){
            DeRef(_1);
        }
        _7795 = NOVALUE;
        goto L27; // [756] 768
L28: 

        /** 				opt[MAPNAME] = EXTRAS*/
        RefDS(_4EXTRAS_13858);
        _2 = (int)SEQ_PTR(_opt_13886);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_13886 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 6);
        _1 = *(int *)_2;
        *(int *)_2 = _4EXTRAS_13858;
        DeRef(_1);
L27: 

        /** 			updated = 1*/
        _updated_13888 = 1;
L25: 

        /** 		if updated then*/
        if (_updated_13888 == 0)
        {
            goto L29; // [776] 786
        }
        else{
        }

        /** 			opts[i] = opt*/
        RefDS(_opt_13886);
        _2 = (int)SEQ_PTR(_opts_13880);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_13880 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13884);
        _1 = *(int *)_2;
        *(int *)_2 = _opt_13886;
        DeRef(_1);
L29: 
        DeRef(_opt_13886);
        _opt_13886 = NOVALUE;

        /** 	end for*/
        _i_13884 = _i_13884 + 1;
        goto L1; // [790] 22
L2: 
        ;
    }

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_13880)){
            _7796 = SEQ_PTR(_opts_13880)->length;
    }
    else {
        _7796 = 1;
    }
    {
        int _i_14019;
        _i_14019 = 1;
L2A: 
        if (_i_14019 > _7796){
            goto L2B; // [800] 1004
        }

        /** 		sequence opt*/

        /** 		opt = opts[i]*/
        DeRef(_opt_14021);
        _2 = (int)SEQ_PTR(_opts_13880);
        _opt_14021 = (int)*(((s1_ptr)_2)->base + _i_14019);
        Ref(_opt_14021);

        /** 		if sequence(opt[SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14021);
        _7798 = (int)*(((s1_ptr)_2)->base + 1);
        _7799 = IS_SEQUENCE(_7798);
        _7798 = NOVALUE;
        if (_7799 == 0)
        {
            _7799 = NOVALUE;
            goto L2C; // [826] 906
        }
        else{
            _7799 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _7800 = _i_14019 + 1;
        if (IS_SEQUENCE(_opts_13880)){
                _7801 = SEQ_PTR(_opts_13880)->length;
        }
        else {
            _7801 = 1;
        }
        {
            int _j_14027;
            _j_14027 = _7800;
L2D: 
            if (_j_14027 > _7801){
                goto L2E; // [838] 905
            }

            /** 				if equal(opt[SHORTNAME], opts[j][SHORTNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_14021);
            _7802 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_opts_13880);
            _7803 = (int)*(((s1_ptr)_2)->base + _j_14027);
            _2 = (int)SEQ_PTR(_7803);
            _7804 = (int)*(((s1_ptr)_2)->base + 1);
            _7803 = NOVALUE;
            if (_7802 == _7804)
            _7805 = 1;
            else if (IS_ATOM_INT(_7802) && IS_ATOM_INT(_7804))
            _7805 = 0;
            else
            _7805 = (compare(_7802, _7804) == 0);
            _7802 = NOVALUE;
            _7804 = NOVALUE;
            if (_7805 == 0)
            {
                _7805 = NOVALUE;
                goto L2F; // [863] 898
            }
            else{
                _7805 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Short Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_14021);
            _7807 = (int)*(((s1_ptr)_2)->base + 1);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_7807);
            *((int *)(_2+4)) = _7807;
            _7808 = MAKE_SEQ(_1);
            _7807 = NOVALUE;
            DeRef(_data_inlined_crash_at_875_14039);
            _data_inlined_crash_at_875_14039 = _7808;
            _7808 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_878_14040);
            _msg_inlined_crash_at_878_14040 = EPrintf(-9999999, _7806, _data_inlined_crash_at_875_14039);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_878_14040);

            /** end procedure*/
            goto L30; // [892] 895
L30: 
            DeRef(_data_inlined_crash_at_875_14039);
            _data_inlined_crash_at_875_14039 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_878_14040);
            _msg_inlined_crash_at_878_14040 = NOVALUE;
L2F: 

            /** 			end for*/
            _j_14027 = _j_14027 + 1;
            goto L2D; // [900] 845
L2E: 
            ;
        }
L2C: 

        /** 		if sequence(opt[LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opt_14021);
        _7809 = (int)*(((s1_ptr)_2)->base + 2);
        _7810 = IS_SEQUENCE(_7809);
        _7809 = NOVALUE;
        if (_7810 == 0)
        {
            _7810 = NOVALUE;
            goto L31; // [915] 995
        }
        else{
            _7810 = NOVALUE;
        }

        /** 			for j = i + 1 to length(opts) do*/
        _7811 = _i_14019 + 1;
        if (IS_SEQUENCE(_opts_13880)){
                _7812 = SEQ_PTR(_opts_13880)->length;
        }
        else {
            _7812 = 1;
        }
        {
            int _j_14045;
            _j_14045 = _7811;
L32: 
            if (_j_14045 > _7812){
                goto L33; // [927] 994
            }

            /** 				if equal(opt[LONGNAME], opts[j][LONGNAME]) then*/
            _2 = (int)SEQ_PTR(_opt_14021);
            _7813 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_opts_13880);
            _7814 = (int)*(((s1_ptr)_2)->base + _j_14045);
            _2 = (int)SEQ_PTR(_7814);
            _7815 = (int)*(((s1_ptr)_2)->base + 2);
            _7814 = NOVALUE;
            if (_7813 == _7815)
            _7816 = 1;
            else if (IS_ATOM_INT(_7813) && IS_ATOM_INT(_7815))
            _7816 = 0;
            else
            _7816 = (compare(_7813, _7815) == 0);
            _7813 = NOVALUE;
            _7815 = NOVALUE;
            if (_7816 == 0)
            {
                _7816 = NOVALUE;
                goto L34; // [952] 987
            }
            else{
                _7816 = NOVALUE;
            }

            /** 					error:crash("cmd_opts: Duplicate Long Names (%s) are not allowed in an option record.\n",*/
            _2 = (int)SEQ_PTR(_opt_14021);
            _7818 = (int)*(((s1_ptr)_2)->base + 2);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_7818);
            *((int *)(_2+4)) = _7818;
            _7819 = MAKE_SEQ(_1);
            _7818 = NOVALUE;
            DeRef(_data_inlined_crash_at_964_14057);
            _data_inlined_crash_at_964_14057 = _7819;
            _7819 = NOVALUE;

            /** 	msg = sprintf(fmt, data)*/
            DeRefi(_msg_inlined_crash_at_967_14058);
            _msg_inlined_crash_at_967_14058 = EPrintf(-9999999, _7817, _data_inlined_crash_at_964_14057);

            /** 	machine_proc(M_CRASH, msg)*/
            machine(67, _msg_inlined_crash_at_967_14058);

            /** end procedure*/
            goto L35; // [981] 984
L35: 
            DeRef(_data_inlined_crash_at_964_14057);
            _data_inlined_crash_at_964_14057 = NOVALUE;
            DeRefi(_msg_inlined_crash_at_967_14058);
            _msg_inlined_crash_at_967_14058 = NOVALUE;
L34: 

            /** 			end for*/
            _j_14045 = _j_14045 + 1;
            goto L32; // [989] 934
L33: 
            ;
        }
L31: 
        DeRef(_opt_14021);
        _opt_14021 = NOVALUE;

        /** 	end for*/
        _i_14019 = _i_14019 + 1;
        goto L2A; // [999] 807
L2B: 
        ;
    }

    /** 	integer has_h = 0, has_help = 0, has_question = 0*/
    _has_h_14059 = 0;
    _has_help_14060 = 0;
    _has_question_14061 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_13880)){
            _7820 = SEQ_PTR(_opts_13880)->length;
    }
    else {
        _7820 = 1;
    }
    {
        int _i_14063;
        _i_14063 = 1;
L36: 
        if (_i_14063 > _7820){
            goto L37; // [1020] 1106
        }

        /** 		if equal(opts[i][SHORTNAME], "h") then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7821 = (int)*(((s1_ptr)_2)->base + _i_14063);
        _2 = (int)SEQ_PTR(_7821);
        _7822 = (int)*(((s1_ptr)_2)->base + 1);
        _7821 = NOVALUE;
        if (_7822 == _7823)
        _7824 = 1;
        else if (IS_ATOM_INT(_7822) && IS_ATOM_INT(_7823))
        _7824 = 0;
        else
        _7824 = (compare(_7822, _7823) == 0);
        _7822 = NOVALUE;
        if (_7824 == 0)
        {
            _7824 = NOVALUE;
            goto L38; // [1041] 1052
        }
        else{
            _7824 = NOVALUE;
        }

        /** 			has_h = 1*/
        _has_h_14059 = 1;
        goto L39; // [1049] 1076
L38: 

        /** 		elsif equal(opts[i][SHORTNAME], "?") then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7825 = (int)*(((s1_ptr)_2)->base + _i_14063);
        _2 = (int)SEQ_PTR(_7825);
        _7826 = (int)*(((s1_ptr)_2)->base + 1);
        _7825 = NOVALUE;
        if (_7826 == _7827)
        _7828 = 1;
        else if (IS_ATOM_INT(_7826) && IS_ATOM_INT(_7827))
        _7828 = 0;
        else
        _7828 = (compare(_7826, _7827) == 0);
        _7826 = NOVALUE;
        if (_7828 == 0)
        {
            _7828 = NOVALUE;
            goto L3A; // [1066] 1075
        }
        else{
            _7828 = NOVALUE;
        }

        /** 			has_question = 1*/
        _has_question_14061 = 1;
L3A: 
L39: 

        /** 		if equal(opts[i][LONGNAME], "help") then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7829 = (int)*(((s1_ptr)_2)->base + _i_14063);
        _2 = (int)SEQ_PTR(_7829);
        _7830 = (int)*(((s1_ptr)_2)->base + 2);
        _7829 = NOVALUE;
        if (_7830 == _7831)
        _7832 = 1;
        else if (IS_ATOM_INT(_7830) && IS_ATOM_INT(_7831))
        _7832 = 0;
        else
        _7832 = (compare(_7830, _7831) == 0);
        _7830 = NOVALUE;
        if (_7832 == 0)
        {
            _7832 = NOVALUE;
            goto L3B; // [1090] 1099
        }
        else{
            _7832 = NOVALUE;
        }

        /** 			has_help = 1*/
        _has_help_14060 = 1;
L3B: 

        /** 	end for*/
        _i_14063 = _i_14063 + 1;
        goto L36; // [1101] 1027
L37: 
        ;
    }

    /** 	if auto_help_switches then*/
    if (_auto_help_switches_13881 == 0)
    {
        goto L3C; // [1108] 1251
    }
    else{
    }

    /** 		integer appended_opts = 0*/
    _appended_opts_14081 = 0;

    /** 		if not has_h and not has_help then*/
    _7833 = (_has_h_14059 == 0);
    if (_7833 == 0) {
        goto L3D; // [1121] 1154
    }
    _7835 = (_has_help_14060 == 0);
    if (_7835 == 0)
    {
        DeRef(_7835);
        _7835 = NOVALUE;
        goto L3D; // [1129] 1154
    }
    else{
        DeRef(_7835);
        _7835 = NOVALUE;
    }

    /** 			opts = append(opts, {"h", "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7823);
    *((int *)(_2+4)) = _7823;
    RefDS(_7831);
    *((int *)(_2+8)) = _7831;
    RefDS(_7836);
    *((int *)(_2+12)) = _7836;
    RefDS(_7823);
    *((int *)(_2+16)) = _7823;
    *((int *)(_2+20)) = -1;
    _7837 = MAKE_SEQ(_1);
    RefDS(_7837);
    Append(&_opts_13880, _opts_13880, _7837);
    DeRefDS(_7837);
    _7837 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14081 = 1;
    goto L3E; // [1151] 1207
L3D: 

    /** 		elsif not has_h then*/
    if (_has_h_14059 != 0)
    goto L3F; // [1156] 1181

    /** 			opts = append(opts, {"h", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7823);
    *((int *)(_2+4)) = _7823;
    *((int *)(_2+8)) = 0;
    RefDS(_7836);
    *((int *)(_2+12)) = _7836;
    RefDS(_7823);
    *((int *)(_2+16)) = _7823;
    *((int *)(_2+20)) = -1;
    _7840 = MAKE_SEQ(_1);
    RefDS(_7840);
    Append(&_opts_13880, _opts_13880, _7840);
    DeRefDS(_7840);
    _7840 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14081 = 1;
    goto L3E; // [1178] 1207
L3F: 

    /** 		elsif not has_help then*/
    if (_has_help_14060 != 0)
    goto L40; // [1183] 1206

    /** 			opts = append(opts, {0, "help", "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_7831);
    *((int *)(_2+8)) = _7831;
    RefDS(_7836);
    *((int *)(_2+12)) = _7836;
    RefDS(_7823);
    *((int *)(_2+16)) = _7823;
    *((int *)(_2+20)) = -1;
    _7843 = MAKE_SEQ(_1);
    RefDS(_7843);
    Append(&_opts_13880, _opts_13880, _7843);
    DeRefDS(_7843);
    _7843 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14081 = 1;
L40: 
L3E: 

    /** 		if not has_question then			*/
    if (_has_question_14061 != 0)
    goto L41; // [1209] 1232

    /** 			opts = append(opts, {"?", 0, "Display the command options", {HELP}, -1})*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7827);
    *((int *)(_2+4)) = _7827;
    *((int *)(_2+8)) = 0;
    RefDS(_7836);
    *((int *)(_2+12)) = _7836;
    RefDS(_7823);
    *((int *)(_2+16)) = _7823;
    *((int *)(_2+20)) = -1;
    _7846 = MAKE_SEQ(_1);
    RefDS(_7846);
    Append(&_opts_13880, _opts_13880, _7846);
    DeRefDS(_7846);
    _7846 = NOVALUE;

    /** 			appended_opts = 1*/
    _appended_opts_14081 = 1;
L41: 

    /** 		if appended_opts then*/
    if (_appended_opts_14081 == 0)
    {
        goto L42; // [1234] 1250
    }
    else{
    }

    /** 			opts = standardize_opts(opts, 0)*/
    RefDS(_opts_13880);
    DeRef(_7848);
    _7848 = _opts_13880;
    _0 = _opts_13880;
    _opts_13880 = _4standardize_opts(_7848, 0);
    DeRefDS(_0);
    _7848 = NOVALUE;
L42: 
L3C: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_13880)){
            _7850 = SEQ_PTR(_opts_13880)->length;
    }
    else {
        _7850 = 1;
    }
    {
        int _i_14105;
        _i_14105 = 1;
L43: 
        if (_i_14105 > _7850){
            goto L44; // [1258] 1434
        }

        /** 		if not find(HAS_PARAMETER, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7851 = (int)*(((s1_ptr)_2)->base + _i_14105);
        _2 = (int)SEQ_PTR(_7851);
        _7852 = (int)*(((s1_ptr)_2)->base + 4);
        _7851 = NOVALUE;
        _7853 = find_from(112, _7852, 1);
        _7852 = NOVALUE;
        if (_7853 != 0)
        goto L45; // [1280] 1303
        _7853 = NOVALUE;

        /** 			opts[i][OPTIONS] &= NO_PARAMETER*/
        _2 = (int)SEQ_PTR(_opts_13880);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_13880 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14105 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7857 = (int)*(((s1_ptr)_2)->base + 4);
        _7855 = NOVALUE;
        if (IS_SEQUENCE(_7857) && IS_ATOM(110)) {
            Append(&_7858, _7857, 110);
        }
        else if (IS_ATOM(_7857) && IS_SEQUENCE(110)) {
        }
        else {
            Concat((object_ptr)&_7858, _7857, 110);
            _7857 = NOVALUE;
        }
        _7857 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _7858;
        if( _1 != _7858 ){
            DeRef(_1);
        }
        _7858 = NOVALUE;
        _7855 = NOVALUE;
L45: 

        /** 		if not find(MULTIPLE, opts[i][OPTIONS]) and not find(ONCE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7859 = (int)*(((s1_ptr)_2)->base + _i_14105);
        _2 = (int)SEQ_PTR(_7859);
        _7860 = (int)*(((s1_ptr)_2)->base + 4);
        _7859 = NOVALUE;
        _7861 = find_from(42, _7860, 1);
        _7860 = NOVALUE;
        _7862 = (_7861 == 0);
        _7861 = NOVALUE;
        if (_7862 == 0) {
            goto L46; // [1321] 1365
        }
        _2 = (int)SEQ_PTR(_opts_13880);
        _7864 = (int)*(((s1_ptr)_2)->base + _i_14105);
        _2 = (int)SEQ_PTR(_7864);
        _7865 = (int)*(((s1_ptr)_2)->base + 4);
        _7864 = NOVALUE;
        _7866 = find_from(49, _7865, 1);
        _7865 = NOVALUE;
        _7867 = (_7866 == 0);
        _7866 = NOVALUE;
        if (_7867 == 0)
        {
            DeRef(_7867);
            _7867 = NOVALUE;
            goto L46; // [1342] 1365
        }
        else{
            DeRef(_7867);
            _7867 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= ONCE*/
        _2 = (int)SEQ_PTR(_opts_13880);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_13880 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14105 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7870 = (int)*(((s1_ptr)_2)->base + 4);
        _7868 = NOVALUE;
        if (IS_SEQUENCE(_7870) && IS_ATOM(49)) {
            Append(&_7871, _7870, 49);
        }
        else if (IS_ATOM(_7870) && IS_SEQUENCE(49)) {
        }
        else {
            Concat((object_ptr)&_7871, _7870, 49);
            _7870 = NOVALUE;
        }
        _7870 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _7871;
        if( _1 != _7871 ){
            DeRef(_1);
        }
        _7871 = NOVALUE;
        _7868 = NOVALUE;
L46: 

        /** 		if not find(HAS_CASE, opts[i][OPTIONS]) and not find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_13880);
        _7872 = (int)*(((s1_ptr)_2)->base + _i_14105);
        _2 = (int)SEQ_PTR(_7872);
        _7873 = (int)*(((s1_ptr)_2)->base + 4);
        _7872 = NOVALUE;
        _7874 = find_from(99, _7873, 1);
        _7873 = NOVALUE;
        _7875 = (_7874 == 0);
        _7874 = NOVALUE;
        if (_7875 == 0) {
            goto L47; // [1383] 1427
        }
        _2 = (int)SEQ_PTR(_opts_13880);
        _7877 = (int)*(((s1_ptr)_2)->base + _i_14105);
        _2 = (int)SEQ_PTR(_7877);
        _7878 = (int)*(((s1_ptr)_2)->base + 4);
        _7877 = NOVALUE;
        _7879 = find_from(105, _7878, 1);
        _7878 = NOVALUE;
        _7880 = (_7879 == 0);
        _7879 = NOVALUE;
        if (_7880 == 0)
        {
            DeRef(_7880);
            _7880 = NOVALUE;
            goto L47; // [1404] 1427
        }
        else{
            DeRef(_7880);
            _7880 = NOVALUE;
        }

        /** 			opts[i][OPTIONS] &= NO_CASE*/
        _2 = (int)SEQ_PTR(_opts_13880);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opts_13880 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_14105 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7883 = (int)*(((s1_ptr)_2)->base + 4);
        _7881 = NOVALUE;
        if (IS_SEQUENCE(_7883) && IS_ATOM(105)) {
            Append(&_7884, _7883, 105);
        }
        else if (IS_ATOM(_7883) && IS_SEQUENCE(105)) {
        }
        else {
            Concat((object_ptr)&_7884, _7883, 105);
            _7883 = NOVALUE;
        }
        _7883 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = _7884;
        if( _1 != _7884 ){
            DeRef(_1);
        }
        _7884 = NOVALUE;
        _7881 = NOVALUE;
L47: 

        /** 	end for*/
        _i_14105 = _i_14105 + 1;
        goto L43; // [1429] 1265
L44: 
        ;
    }

    /** 	return opts*/
    _7720 = NOVALUE;
    _7726 = NOVALUE;
    _7746 = NOVALUE;
    _7785 = NOVALUE;
    DeRef(_7800);
    _7800 = NOVALUE;
    DeRef(_7811);
    _7811 = NOVALUE;
    DeRef(_7833);
    _7833 = NOVALUE;
    DeRef(_7862);
    _7862 = NOVALUE;
    DeRef(_7875);
    _7875 = NOVALUE;
    return _opts_13880;
    ;
}


void _4local_help(int _opts_14146, int _add_help_rid_14147, int _cmds_14148, int _std_14150, int _parse_options_14151)
{
    int _pad_size_14152 = NOVALUE;
    int _this_size_14153 = NOVALUE;
    int _cmd_14154 = NOVALUE;
    int _param_name_14155 = NOVALUE;
    int _has_param_14156 = NOVALUE;
    int _is_mandatory_14157 = NOVALUE;
    int _extras_mandatory_14158 = NOVALUE;
    int _extras_opt_14159 = NOVALUE;
    int _auto_help_14160 = NOVALUE;
    int _po_14161 = NOVALUE;
    int _msg_inlined_crash_at_94_14180 = NOVALUE;
    int _8073 = NOVALUE;
    int _8072 = NOVALUE;
    int _8071 = NOVALUE;
    int _8070 = NOVALUE;
    int _8068 = NOVALUE;
    int _8067 = NOVALUE;
    int _8066 = NOVALUE;
    int _8065 = NOVALUE;
    int _8064 = NOVALUE;
    int _8062 = NOVALUE;
    int _8060 = NOVALUE;
    int _8058 = NOVALUE;
    int _8056 = NOVALUE;
    int _8055 = NOVALUE;
    int _8054 = NOVALUE;
    int _8052 = NOVALUE;
    int _8051 = NOVALUE;
    int _8050 = NOVALUE;
    int _8047 = NOVALUE;
    int _8046 = NOVALUE;
    int _8045 = NOVALUE;
    int _8043 = NOVALUE;
    int _8042 = NOVALUE;
    int _8041 = NOVALUE;
    int _8039 = NOVALUE;
    int _8038 = NOVALUE;
    int _8037 = NOVALUE;
    int _8036 = NOVALUE;
    int _8035 = NOVALUE;
    int _8034 = NOVALUE;
    int _8033 = NOVALUE;
    int _8032 = NOVALUE;
    int _8029 = NOVALUE;
    int _8025 = NOVALUE;
    int _8022 = NOVALUE;
    int _8021 = NOVALUE;
    int _8020 = NOVALUE;
    int _8015 = NOVALUE;
    int _8014 = NOVALUE;
    int _8013 = NOVALUE;
    int _8012 = NOVALUE;
    int _8008 = NOVALUE;
    int _8005 = NOVALUE;
    int _8004 = NOVALUE;
    int _8003 = NOVALUE;
    int _8000 = NOVALUE;
    int _7999 = NOVALUE;
    int _7998 = NOVALUE;
    int _7996 = NOVALUE;
    int _7995 = NOVALUE;
    int _7994 = NOVALUE;
    int _7992 = NOVALUE;
    int _7991 = NOVALUE;
    int _7990 = NOVALUE;
    int _7989 = NOVALUE;
    int _7988 = NOVALUE;
    int _7987 = NOVALUE;
    int _7984 = NOVALUE;
    int _7983 = NOVALUE;
    int _7982 = NOVALUE;
    int _7979 = NOVALUE;
    int _7978 = NOVALUE;
    int _7977 = NOVALUE;
    int _7976 = NOVALUE;
    int _7975 = NOVALUE;
    int _7974 = NOVALUE;
    int _7973 = NOVALUE;
    int _7972 = NOVALUE;
    int _7971 = NOVALUE;
    int _7970 = NOVALUE;
    int _7969 = NOVALUE;
    int _7968 = NOVALUE;
    int _7963 = NOVALUE;
    int _7962 = NOVALUE;
    int _7960 = NOVALUE;
    int _7959 = NOVALUE;
    int _7958 = NOVALUE;
    int _7957 = NOVALUE;
    int _7956 = NOVALUE;
    int _7955 = NOVALUE;
    int _7953 = NOVALUE;
    int _7952 = NOVALUE;
    int _7951 = NOVALUE;
    int _7947 = NOVALUE;
    int _7946 = NOVALUE;
    int _7944 = NOVALUE;
    int _7943 = NOVALUE;
    int _7942 = NOVALUE;
    int _7941 = NOVALUE;
    int _7940 = NOVALUE;
    int _7939 = NOVALUE;
    int _7938 = NOVALUE;
    int _7935 = NOVALUE;
    int _7934 = NOVALUE;
    int _7933 = NOVALUE;
    int _7931 = NOVALUE;
    int _7930 = NOVALUE;
    int _7929 = NOVALUE;
    int _7928 = NOVALUE;
    int _7927 = NOVALUE;
    int _7926 = NOVALUE;
    int _7925 = NOVALUE;
    int _7922 = NOVALUE;
    int _7921 = NOVALUE;
    int _7920 = NOVALUE;
    int _7918 = NOVALUE;
    int _7917 = NOVALUE;
    int _7916 = NOVALUE;
    int _7915 = NOVALUE;
    int _7914 = NOVALUE;
    int _7913 = NOVALUE;
    int _7912 = NOVALUE;
    int _7911 = NOVALUE;
    int _7910 = NOVALUE;
    int _7909 = NOVALUE;
    int _7908 = NOVALUE;
    int _7907 = NOVALUE;
    int _7906 = NOVALUE;
    int _7905 = NOVALUE;
    int _7904 = NOVALUE;
    int _7903 = NOVALUE;
    int _7902 = NOVALUE;
    int _7901 = NOVALUE;
    int _7893 = NOVALUE;
    int _7890 = NOVALUE;
    int _7888 = NOVALUE;
    int _7886 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer extras_mandatory = 0*/
    _extras_mandatory_14158 = 0;

    /** 	integer extras_opt = 0*/
    _extras_opt_14159 = 0;

    /** 	integer auto_help = 1*/
    _auto_help_14160 = 1;

    /** 	integer po = 1*/
    _po_14161 = 1;

    /** 	if atom(parse_options) then*/
    _7886 = IS_ATOM(_parse_options_14151);
    if (_7886 == 0)
    {
        _7886 = NOVALUE;
        goto L1; // [32] 42
    }
    else{
        _7886 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _0 = _parse_options_14151;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_parse_options_14151);
    *((int *)(_2+4)) = _parse_options_14151;
    _parse_options_14151 = MAKE_SEQ(_1);
    DeRefi(_0);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    if (IS_SEQUENCE(_parse_options_14151)){
            _7888 = SEQ_PTR(_parse_options_14151)->length;
    }
    else {
        _7888 = 1;
    }
    if (_po_14161 > _7888)
    goto L3; // [50] 143

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_14151);
    _7890 = (int)*(((s1_ptr)_2)->base + _po_14161);
    if (IS_SEQUENCE(_7890) ){
        goto L4; // [60] 129
    }
    if(!IS_ATOM_INT(_7890)){
        if( (DBL_PTR(_7890)->dbl != (double) ((int) DBL_PTR(_7890)->dbl) ) ){
            goto L4; // [60] 129
        }
        _0 = (int) DBL_PTR(_7890)->dbl;
    }
    else {
        _0 = _7890;
    };
    _7890 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        if (IS_SEQUENCE(_parse_options_14151)){
                _7893 = SEQ_PTR(_parse_options_14151)->length;
        }
        else {
            _7893 = 1;
        }
        if (_po_14161 >= _7893)
        goto L5; // [74] 93

        /** 					po += 1*/
        _po_14161 = _po_14161 + 1;

        /** 					add_help_rid = parse_options[po]*/
        DeRef(_add_help_rid_14147);
        _2 = (int)SEQ_PTR(_parse_options_14151);
        _add_help_rid_14147 = (int)*(((s1_ptr)_2)->base + _po_14161);
        Ref(_add_help_rid_14147);
        goto L6; // [90] 132
L5: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_94_14180);
        _msg_inlined_crash_at_94_14180 = EPrintf(-9999999, _7897, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_94_14180);

        /** end procedure*/
        goto L7; // [108] 111
L7: 
        DeRefi(_msg_inlined_crash_at_94_14180);
        _msg_inlined_crash_at_94_14180 = NOVALUE;
        goto L6; // [114] 132

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_14160 = 0;
        goto L6; // [125] 132

        /** 			case else*/
        default:
L4: 
    ;}L6: 

    /** 		po += 1*/
    _po_14161 = _po_14161 + 1;

    /** 	end while*/
    goto L2; // [140] 47
L3: 

    /** 	if std = 0 then*/
    if (_std_14150 != 0)
    goto L8; // [145] 159

    /** 		opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_14146);
    _0 = _opts_14146;
    _opts_14146 = _4standardize_opts(_opts_14146, _auto_help_14160);
    DeRefDS(_0);
L8: 

    /** 	pad_size = 0*/
    _pad_size_14152 = 0;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14146)){
            _7901 = SEQ_PTR(_opts_14146)->length;
    }
    else {
        _7901 = 1;
    }
    {
        int _i_14188;
        _i_14188 = 1;
L9: 
        if (_i_14188 > _7901){
            goto LA; // [169] 562
        }

        /** 		this_size = 0*/
        _this_size_14153 = 0;

        /** 		param_name = ""*/
        RefDS(_5);
        DeRef(_param_name_14155);
        _param_name_14155 = _5;

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7902 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7902);
        _7903 = (int)*(((s1_ptr)_2)->base + 1);
        _7902 = NOVALUE;
        _7904 = IS_ATOM(_7903);
        _7903 = NOVALUE;
        if (_7904 == 0) {
            goto LB; // [201] 254
        }
        _2 = (int)SEQ_PTR(_opts_14146);
        _7906 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7906);
        _7907 = (int)*(((s1_ptr)_2)->base + 2);
        _7906 = NOVALUE;
        _7908 = IS_ATOM(_7907);
        _7907 = NOVALUE;
        if (_7908 == 0)
        {
            _7908 = NOVALUE;
            goto LB; // [217] 254
        }
        else{
            _7908 = NOVALUE;
        }

        /** 			extras_opt = i*/
        _extras_opt_14159 = _i_14188;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7909 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7909);
        _7910 = (int)*(((s1_ptr)_2)->base + 4);
        _7909 = NOVALUE;
        _7911 = find_from(109, _7910, 1);
        _7910 = NOVALUE;
        if (_7911 == 0)
        {
            _7911 = NOVALUE;
            goto LC; // [240] 557
        }
        else{
            _7911 = NOVALUE;
        }

        /** 				extras_mandatory = 1*/
        _extras_mandatory_14158 = 1;

        /** 			continue*/
        goto LC; // [251] 557
LB: 

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7912 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7912);
        _7913 = (int)*(((s1_ptr)_2)->base + 1);
        _7912 = NOVALUE;
        _7914 = IS_SEQUENCE(_7913);
        _7913 = NOVALUE;
        if (_7914 == 0)
        {
            _7914 = NOVALUE;
            goto LD; // [267] 320
        }
        else{
            _7914 = NOVALUE;
        }

        /** 			this_size += length(opts[i][SHORTNAME]) + 1 -- Allow for "-"*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7915 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7915);
        _7916 = (int)*(((s1_ptr)_2)->base + 1);
        _7915 = NOVALUE;
        if (IS_SEQUENCE(_7916)){
                _7917 = SEQ_PTR(_7916)->length;
        }
        else {
            _7917 = 1;
        }
        _7916 = NOVALUE;
        _7918 = _7917 + 1;
        _7917 = NOVALUE;
        _this_size_14153 = _this_size_14153 + _7918;
        _7918 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7920 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7920);
        _7921 = (int)*(((s1_ptr)_2)->base + 4);
        _7920 = NOVALUE;
        _7922 = find_from(109, _7921, 1);
        _7921 = NOVALUE;
        if (_7922 != 0)
        goto LE; // [308] 319

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_14153 = _this_size_14153 + 2;
LE: 
LD: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7925 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7925);
        _7926 = (int)*(((s1_ptr)_2)->base + 2);
        _7925 = NOVALUE;
        _7927 = IS_SEQUENCE(_7926);
        _7926 = NOVALUE;
        if (_7927 == 0)
        {
            _7927 = NOVALUE;
            goto LF; // [333] 386
        }
        else{
            _7927 = NOVALUE;
        }

        /** 			this_size += length(opts[i][LONGNAME]) + 2 -- Allow for "--"*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7928 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7928);
        _7929 = (int)*(((s1_ptr)_2)->base + 2);
        _7928 = NOVALUE;
        if (IS_SEQUENCE(_7929)){
                _7930 = SEQ_PTR(_7929)->length;
        }
        else {
            _7930 = 1;
        }
        _7929 = NOVALUE;
        _7931 = _7930 + 2;
        _7930 = NOVALUE;
        _this_size_14153 = _this_size_14153 + _7931;
        _7931 = NOVALUE;

        /** 			if find(MANDATORY, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7933 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7933);
        _7934 = (int)*(((s1_ptr)_2)->base + 4);
        _7933 = NOVALUE;
        _7935 = find_from(109, _7934, 1);
        _7934 = NOVALUE;
        if (_7935 != 0)
        goto L10; // [374] 385

        /** 				this_size += 2 -- Allow for '[' ']'*/
        _this_size_14153 = _this_size_14153 + 2;
L10: 
LF: 

        /** 		if sequence(opts[i][SHORTNAME]) and sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7938 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7938);
        _7939 = (int)*(((s1_ptr)_2)->base + 1);
        _7938 = NOVALUE;
        _7940 = IS_SEQUENCE(_7939);
        _7939 = NOVALUE;
        if (_7940 == 0) {
            goto L11; // [399] 425
        }
        _2 = (int)SEQ_PTR(_opts_14146);
        _7942 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7942);
        _7943 = (int)*(((s1_ptr)_2)->base + 2);
        _7942 = NOVALUE;
        _7944 = IS_SEQUENCE(_7943);
        _7943 = NOVALUE;
        if (_7944 == 0)
        {
            _7944 = NOVALUE;
            goto L11; // [415] 425
        }
        else{
            _7944 = NOVALUE;
        }

        /** 			this_size += 2 -- Allow for ", " between short and long names*/
        _this_size_14153 = _this_size_14153 + 2;
L11: 

        /** 		has_param = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7946 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7946);
        _7947 = (int)*(((s1_ptr)_2)->base + 4);
        _7946 = NOVALUE;
        _has_param_14156 = find_from(112, _7947, 1);
        _7947 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_14156 == 0)
        goto L12; // [442] 543

        /** 			this_size += 1 -- Allow for " "*/
        _this_size_14153 = _this_size_14153 + 1;

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7951 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7951);
        _7952 = (int)*(((s1_ptr)_2)->base + 4);
        _7951 = NOVALUE;
        if (IS_SEQUENCE(_7952)){
                _7953 = SEQ_PTR(_7952)->length;
        }
        else {
            _7953 = 1;
        }
        _7952 = NOVALUE;
        if (_has_param_14156 >= _7953)
        goto L13; // [465] 519

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7955 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7955);
        _7956 = (int)*(((s1_ptr)_2)->base + 4);
        _7955 = NOVALUE;
        _2 = (int)SEQ_PTR(_7956);
        _7957 = (int)*(((s1_ptr)_2)->base + _has_param_14156);
        _7956 = NOVALUE;
        _7958 = IS_SEQUENCE(_7957);
        _7957 = NOVALUE;
        if (_7958 == 0)
        {
            _7958 = NOVALUE;
            goto L14; // [486] 508
        }
        else{
            _7958 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7959 = (int)*(((s1_ptr)_2)->base + _i_14188);
        _2 = (int)SEQ_PTR(_7959);
        _7960 = (int)*(((s1_ptr)_2)->base + 4);
        _7959 = NOVALUE;
        DeRef(_param_name_14155);
        _2 = (int)SEQ_PTR(_7960);
        _param_name_14155 = (int)*(((s1_ptr)_2)->base + _has_param_14156);
        Ref(_param_name_14155);
        _7960 = NOVALUE;
        goto L15; // [505] 527
L14: 

        /** 					param_name = "x"*/
        RefDS(_7744);
        DeRef(_param_name_14155);
        _param_name_14155 = _7744;
        goto L15; // [516] 527
L13: 

        /** 				param_name = "x"*/
        RefDS(_7744);
        DeRef(_param_name_14155);
        _param_name_14155 = _7744;
L15: 

        /** 			this_size += 2 + length(param_name)*/
        if (IS_SEQUENCE(_param_name_14155)){
                _7962 = SEQ_PTR(_param_name_14155)->length;
        }
        else {
            _7962 = 1;
        }
        _7963 = 2 + _7962;
        _7962 = NOVALUE;
        _this_size_14153 = _this_size_14153 + _7963;
        _7963 = NOVALUE;
L12: 

        /** 		if pad_size < this_size then*/
        if (_pad_size_14152 >= _this_size_14153)
        goto L16; // [545] 555

        /** 			pad_size = this_size*/
        _pad_size_14152 = _this_size_14153;
L16: 

        /** 	end for*/
LC: 
        _i_14188 = _i_14188 + 1;
        goto L9; // [557] 176
LA: 
        ;
    }

    /** 	pad_size += 3 -- Allow for minimum gap between cmd and its description*/
    _pad_size_14152 = _pad_size_14152 + 3;

    /** 	printf(1, "%s options:\n", {cmds[2]})*/
    _2 = (int)SEQ_PTR(_cmds_14148);
    _7968 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_7968);
    *((int *)(_2+4)) = _7968;
    _7969 = MAKE_SEQ(_1);
    _7968 = NOVALUE;
    EPrintf(1, _7967, _7969);
    DeRefDS(_7969);
    _7969 = NOVALUE;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14146)){
            _7970 = SEQ_PTR(_opts_14146)->length;
    }
    else {
        _7970 = 1;
    }
    {
        int _i_14272;
        _i_14272 = 1;
L17: 
        if (_i_14272 > _7970){
            goto L18; // [587] 1006
        }

        /** 		if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7971 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7971);
        _7972 = (int)*(((s1_ptr)_2)->base + 1);
        _7971 = NOVALUE;
        _7973 = IS_ATOM(_7972);
        _7972 = NOVALUE;
        if (_7973 == 0) {
            goto L19; // [607] 631
        }
        _2 = (int)SEQ_PTR(_opts_14146);
        _7975 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7975);
        _7976 = (int)*(((s1_ptr)_2)->base + 2);
        _7975 = NOVALUE;
        _7977 = IS_ATOM(_7976);
        _7976 = NOVALUE;
        if (_7977 == 0)
        {
            _7977 = NOVALUE;
            goto L19; // [623] 631
        }
        else{
            _7977 = NOVALUE;
        }

        /** 			continue*/
        goto L1A; // [628] 1001
L19: 

        /** 		has_param    = find(HAS_PARAMETER, opts[i][OPTIONS])*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7978 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7978);
        _7979 = (int)*(((s1_ptr)_2)->base + 4);
        _7978 = NOVALUE;
        _has_param_14156 = find_from(112, _7979, 1);
        _7979 = NOVALUE;

        /** 		if has_param != 0 then*/
        if (_has_param_14156 == 0)
        goto L1B; // [648] 734

        /** 			if has_param < length(opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7982 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7982);
        _7983 = (int)*(((s1_ptr)_2)->base + 4);
        _7982 = NOVALUE;
        if (IS_SEQUENCE(_7983)){
                _7984 = SEQ_PTR(_7983)->length;
        }
        else {
            _7984 = 1;
        }
        _7983 = NOVALUE;
        if (_has_param_14156 >= _7984)
        goto L1C; // [665] 725

        /** 				has_param += 1*/
        _has_param_14156 = _has_param_14156 + 1;

        /** 				if sequence(opts[i][OPTIONS][has_param]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7987 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7987);
        _7988 = (int)*(((s1_ptr)_2)->base + 4);
        _7987 = NOVALUE;
        _2 = (int)SEQ_PTR(_7988);
        _7989 = (int)*(((s1_ptr)_2)->base + _has_param_14156);
        _7988 = NOVALUE;
        _7990 = IS_SEQUENCE(_7989);
        _7989 = NOVALUE;
        if (_7990 == 0)
        {
            _7990 = NOVALUE;
            goto L1D; // [692] 714
        }
        else{
            _7990 = NOVALUE;
        }

        /** 					param_name = opts[i][OPTIONS][has_param]*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7991 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7991);
        _7992 = (int)*(((s1_ptr)_2)->base + 4);
        _7991 = NOVALUE;
        DeRef(_param_name_14155);
        _2 = (int)SEQ_PTR(_7992);
        _param_name_14155 = (int)*(((s1_ptr)_2)->base + _has_param_14156);
        Ref(_param_name_14155);
        _7992 = NOVALUE;
        goto L1E; // [711] 733
L1D: 

        /** 					param_name = "x"*/
        RefDS(_7744);
        DeRef(_param_name_14155);
        _param_name_14155 = _7744;
        goto L1E; // [722] 733
L1C: 

        /** 				param_name = "x"*/
        RefDS(_7744);
        DeRef(_param_name_14155);
        _param_name_14155 = _7744;
L1E: 
L1B: 

        /** 		is_mandatory = (find(MANDATORY,     opts[i][OPTIONS]) != 0)*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7994 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7994);
        _7995 = (int)*(((s1_ptr)_2)->base + 4);
        _7994 = NOVALUE;
        _7996 = find_from(109, _7995, 1);
        _7995 = NOVALUE;
        _is_mandatory_14157 = (_7996 != 0);
        _7996 = NOVALUE;

        /** 		cmd = ""*/
        RefDS(_5);
        DeRef(_cmd_14154);
        _cmd_14154 = _5;

        /** 		if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _7998 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_7998);
        _7999 = (int)*(((s1_ptr)_2)->base + 1);
        _7998 = NOVALUE;
        _8000 = IS_SEQUENCE(_7999);
        _7999 = NOVALUE;
        if (_8000 == 0)
        {
            _8000 = NOVALUE;
            goto L1F; // [773] 838
        }
        else{
            _8000 = NOVALUE;
        }

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14157 != 0)
        goto L20; // [778] 788

        /** 				cmd &= '['*/
        Append(&_cmd_14154, _cmd_14154, 91);
L20: 

        /** 			cmd &= '-' & opts[i][SHORTNAME]*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _8003 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_8003);
        _8004 = (int)*(((s1_ptr)_2)->base + 1);
        _8003 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_8004)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_8004)) {
            Prepend(&_8005, _8004, 45);
        }
        else {
            Concat((object_ptr)&_8005, 45, _8004);
        }
        _8004 = NOVALUE;
        Concat((object_ptr)&_cmd_14154, _cmd_14154, _8005);
        DeRefDS(_8005);
        _8005 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_14156 == 0)
        goto L21; // [808] 825

        /** 				cmd &= ' ' & param_name*/
        Prepend(&_8008, _param_name_14155, 32);
        Concat((object_ptr)&_cmd_14154, _cmd_14154, _8008);
        DeRefDS(_8008);
        _8008 = NOVALUE;
L21: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14157 != 0)
        goto L22; // [827] 837

        /** 				cmd &= ']'*/
        Append(&_cmd_14154, _cmd_14154, 93);
L22: 
L1F: 

        /** 		if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _8012 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_8012);
        _8013 = (int)*(((s1_ptr)_2)->base + 2);
        _8012 = NOVALUE;
        _8014 = IS_SEQUENCE(_8013);
        _8013 = NOVALUE;
        if (_8014 == 0)
        {
            _8014 = NOVALUE;
            goto L23; // [851] 930
        }
        else{
            _8014 = NOVALUE;
        }

        /** 			if length(cmd) > 0 then cmd &= ", " end if*/
        if (IS_SEQUENCE(_cmd_14154)){
                _8015 = SEQ_PTR(_cmd_14154)->length;
        }
        else {
            _8015 = 1;
        }
        if (_8015 <= 0)
        goto L24; // [859] 868
        Concat((object_ptr)&_cmd_14154, _cmd_14154, _933);
L24: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14157 != 0)
        goto L25; // [870] 880

        /** 				cmd &= '['*/
        Append(&_cmd_14154, _cmd_14154, 91);
L25: 

        /** 			cmd &= "--" & opts[i][LONGNAME]*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _8020 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_8020);
        _8021 = (int)*(((s1_ptr)_2)->base + 2);
        _8020 = NOVALUE;
        if (IS_SEQUENCE(_7016) && IS_ATOM(_8021)) {
            Ref(_8021);
            Append(&_8022, _7016, _8021);
        }
        else if (IS_ATOM(_7016) && IS_SEQUENCE(_8021)) {
        }
        else {
            Concat((object_ptr)&_8022, _7016, _8021);
        }
        _8021 = NOVALUE;
        Concat((object_ptr)&_cmd_14154, _cmd_14154, _8022);
        DeRefDS(_8022);
        _8022 = NOVALUE;

        /** 			if has_param != 0 then*/
        if (_has_param_14156 == 0)
        goto L26; // [900] 917

        /** 				cmd &= '=' & param_name*/
        Prepend(&_8025, _param_name_14155, 61);
        Concat((object_ptr)&_cmd_14154, _cmd_14154, _8025);
        DeRefDS(_8025);
        _8025 = NOVALUE;
L26: 

        /** 			if not is_mandatory then*/
        if (_is_mandatory_14157 != 0)
        goto L27; // [919] 929

        /** 				cmd &= ']'*/
        Append(&_cmd_14154, _cmd_14154, 93);
L27: 
L23: 

        /** 		if length(cmd) > pad_size then*/
        if (IS_SEQUENCE(_cmd_14154)){
                _8029 = SEQ_PTR(_cmd_14154)->length;
        }
        else {
            _8029 = 1;
        }
        if (_8029 <= _pad_size_14152)
        goto L28; // [935] 966

        /** 			puts(1, "   " & cmd & '\n')*/
        {
            int concat_list[3];

            concat_list[0] = 10;
            concat_list[1] = _cmd_14154;
            concat_list[2] = _8031;
            Concat_N((object_ptr)&_8032, concat_list, 3);
        }
        EPuts(1, _8032); // DJP 
        DeRefDS(_8032);
        _8032 = NOVALUE;

        /** 			puts(1, repeat(' ', pad_size + 3))*/
        _8033 = _pad_size_14152 + 3;
        _8034 = Repeat(32, _8033);
        _8033 = NOVALUE;
        EPuts(1, _8034); // DJP 
        DeRefDS(_8034);
        _8034 = NOVALUE;
        goto L29; // [963] 982
L28: 

        /** 			puts(1, "   " & stdseq:pad_tail(cmd, pad_size))*/
        RefDS(_cmd_14154);
        _8035 = _23pad_tail(_cmd_14154, _pad_size_14152, 32);
        if (IS_SEQUENCE(_8031) && IS_ATOM(_8035)) {
            Ref(_8035);
            Append(&_8036, _8031, _8035);
        }
        else if (IS_ATOM(_8031) && IS_SEQUENCE(_8035)) {
        }
        else {
            Concat((object_ptr)&_8036, _8031, _8035);
        }
        DeRef(_8035);
        _8035 = NOVALUE;
        EPuts(1, _8036); // DJP 
        DeRefDS(_8036);
        _8036 = NOVALUE;
L29: 

        /** 		puts(1, opts[i][DESCRIPTION] & '\n')*/
        _2 = (int)SEQ_PTR(_opts_14146);
        _8037 = (int)*(((s1_ptr)_2)->base + _i_14272);
        _2 = (int)SEQ_PTR(_8037);
        _8038 = (int)*(((s1_ptr)_2)->base + 3);
        _8037 = NOVALUE;
        if (IS_SEQUENCE(_8038) && IS_ATOM(10)) {
            Append(&_8039, _8038, 10);
        }
        else if (IS_ATOM(_8038) && IS_SEQUENCE(10)) {
        }
        else {
            Concat((object_ptr)&_8039, _8038, 10);
            _8038 = NOVALUE;
        }
        _8038 = NOVALUE;
        EPuts(1, _8039); // DJP 
        DeRefDS(_8039);
        _8039 = NOVALUE;

        /** 	end for*/
L1A: 
        _i_14272 = _i_14272 + 1;
        goto L17; // [1001] 594
L18: 
        ;
    }

    /** 	if extras_mandatory != 0 then*/
    if (_extras_mandatory_14158 == 0)
    goto L2A; // [1008] 1063

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_14146);
    _8041 = (int)*(((s1_ptr)_2)->base + _extras_opt_14159);
    _2 = (int)SEQ_PTR(_8041);
    _8042 = (int)*(((s1_ptr)_2)->base + 3);
    _8041 = NOVALUE;
    if (IS_SEQUENCE(_8042)){
            _8043 = SEQ_PTR(_8042)->length;
    }
    else {
        _8043 = 1;
    }
    _8042 = NOVALUE;
    if (_8043 <= 0)
    goto L2B; // [1025] 1054

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_14146);
    _8045 = (int)*(((s1_ptr)_2)->base + _extras_opt_14159);
    _2 = (int)SEQ_PTR(_8045);
    _8046 = (int)*(((s1_ptr)_2)->base + 3);
    _8045 = NOVALUE;
    if (IS_SEQUENCE(_3073) && IS_ATOM(_8046)) {
        Ref(_8046);
        Append(&_8047, _3073, _8046);
    }
    else if (IS_ATOM(_3073) && IS_SEQUENCE(_8046)) {
    }
    else {
        Concat((object_ptr)&_8047, _3073, _8046);
    }
    _8046 = NOVALUE;
    EPuts(1, _8047); // DJP 
    DeRefDS(_8047);
    _8047 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2C; // [1051] 1119
L2B: 

    /** 			puts(1, "One or more additional arguments are also required\n")*/
    EPuts(1, _8048); // DJP 
    goto L2C; // [1060] 1119
L2A: 

    /** 	elsif extras_opt > 0 then*/
    if (_extras_opt_14159 <= 0)
    goto L2D; // [1065] 1118

    /** 		if length(opts[extras_opt][DESCRIPTION]) > 0 then*/
    _2 = (int)SEQ_PTR(_opts_14146);
    _8050 = (int)*(((s1_ptr)_2)->base + _extras_opt_14159);
    _2 = (int)SEQ_PTR(_8050);
    _8051 = (int)*(((s1_ptr)_2)->base + 3);
    _8050 = NOVALUE;
    if (IS_SEQUENCE(_8051)){
            _8052 = SEQ_PTR(_8051)->length;
    }
    else {
        _8052 = 1;
    }
    _8051 = NOVALUE;
    if (_8052 <= 0)
    goto L2E; // [1082] 1111

    /** 			puts(1, "\n" & opts[extras_opt][DESCRIPTION])*/
    _2 = (int)SEQ_PTR(_opts_14146);
    _8054 = (int)*(((s1_ptr)_2)->base + _extras_opt_14159);
    _2 = (int)SEQ_PTR(_8054);
    _8055 = (int)*(((s1_ptr)_2)->base + 3);
    _8054 = NOVALUE;
    if (IS_SEQUENCE(_3073) && IS_ATOM(_8055)) {
        Ref(_8055);
        Append(&_8056, _3073, _8055);
    }
    else if (IS_ATOM(_3073) && IS_SEQUENCE(_8055)) {
    }
    else {
        Concat((object_ptr)&_8056, _3073, _8055);
    }
    _8055 = NOVALUE;
    EPuts(1, _8056); // DJP 
    DeRefDS(_8056);
    _8056 = NOVALUE;

    /** 			puts(1, '\n')*/
    EPuts(1, 10); // DJP 
    goto L2F; // [1108] 1117
L2E: 

    /** 			puts(1, "One or more additional arguments can be supplied.\n")*/
    EPuts(1, _8057); // DJP 
L2F: 
L2D: 
L2C: 

    /** 	if atom(add_help_rid) then*/
    _8058 = IS_ATOM(_add_help_rid_14147);
    if (_8058 == 0)
    {
        _8058 = NOVALUE;
        goto L30; // [1124] 1152
    }
    else{
        _8058 = NOVALUE;
    }

    /** 		if add_help_rid >= 0 then*/
    if (binary_op_a(LESS, _add_help_rid_14147, 0)){
        goto L31; // [1129] 1260
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3073); // DJP 

    /** 			call_proc(add_help_rid, {})*/
    _0 = (int)_00[_add_help_rid_14147].addr;
    (*(int (*)())_0)(
                         );

    /** 			puts(1, "\n")*/
    EPuts(1, _3073); // DJP 
    goto L31; // [1149] 1260
L30: 

    /** 		if length(add_help_rid) > 0 then*/
    if (IS_SEQUENCE(_add_help_rid_14147)){
            _8060 = SEQ_PTR(_add_help_rid_14147)->length;
    }
    else {
        _8060 = 1;
    }
    if (_8060 <= 0)
    goto L32; // [1157] 1259

    /** 			puts(1, "\n")*/
    EPuts(1, _3073); // DJP 

    /** 			if types:t_display(add_help_rid) then*/
    Ref(_add_help_rid_14147);
    _8062 = _13t_display(_add_help_rid_14147);
    if (_8062 == 0) {
        DeRef(_8062);
        _8062 = NOVALUE;
        goto L33; // [1172] 1182
    }
    else {
        if (!IS_ATOM_INT(_8062) && DBL_PTR(_8062)->dbl == 0.0){
            DeRef(_8062);
            _8062 = NOVALUE;
            goto L33; // [1172] 1182
        }
        DeRef(_8062);
        _8062 = NOVALUE;
    }
    DeRef(_8062);
    _8062 = NOVALUE;

    /** 				add_help_rid = {add_help_rid}*/
    _0 = _add_help_rid_14147;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_add_help_rid_14147);
    *((int *)(_2+4)) = _add_help_rid_14147;
    _add_help_rid_14147 = MAKE_SEQ(_1);
    DeRef(_0);
L33: 

    /** 			for i = 1 to length(add_help_rid) do*/
    if (IS_SEQUENCE(_add_help_rid_14147)){
            _8064 = SEQ_PTR(_add_help_rid_14147)->length;
    }
    else {
        _8064 = 1;
    }
    {
        int _i_14396;
        _i_14396 = 1;
L34: 
        if (_i_14396 > _8064){
            goto L35; // [1187] 1253
        }

        /** 				puts(1, add_help_rid[i])*/
        _2 = (int)SEQ_PTR(_add_help_rid_14147);
        _8065 = (int)*(((s1_ptr)_2)->base + _i_14396);
        EPuts(1, _8065); // DJP 
        _8065 = NOVALUE;

        /** 				if length(add_help_rid[i]) = 0 or add_help_rid[i][$] != '\n' then*/
        _2 = (int)SEQ_PTR(_add_help_rid_14147);
        _8066 = (int)*(((s1_ptr)_2)->base + _i_14396);
        if (IS_SEQUENCE(_8066)){
                _8067 = SEQ_PTR(_8066)->length;
        }
        else {
            _8067 = 1;
        }
        _8066 = NOVALUE;
        _8068 = (_8067 == 0);
        _8067 = NOVALUE;
        if (_8068 != 0) {
            goto L36; // [1216] 1240
        }
        _2 = (int)SEQ_PTR(_add_help_rid_14147);
        _8070 = (int)*(((s1_ptr)_2)->base + _i_14396);
        if (IS_SEQUENCE(_8070)){
                _8071 = SEQ_PTR(_8070)->length;
        }
        else {
            _8071 = 1;
        }
        _2 = (int)SEQ_PTR(_8070);
        _8072 = (int)*(((s1_ptr)_2)->base + _8071);
        _8070 = NOVALUE;
        if (IS_ATOM_INT(_8072)) {
            _8073 = (_8072 != 10);
        }
        else {
            _8073 = binary_op(NOTEQ, _8072, 10);
        }
        _8072 = NOVALUE;
        if (_8073 == 0) {
            DeRef(_8073);
            _8073 = NOVALUE;
            goto L37; // [1236] 1246
        }
        else {
            if (!IS_ATOM_INT(_8073) && DBL_PTR(_8073)->dbl == 0.0){
                DeRef(_8073);
                _8073 = NOVALUE;
                goto L37; // [1236] 1246
            }
            DeRef(_8073);
            _8073 = NOVALUE;
        }
        DeRef(_8073);
        _8073 = NOVALUE;
L36: 

        /** 					puts(1, '\n')*/
        EPuts(1, 10); // DJP 
L37: 

        /** 			end for*/
        _i_14396 = _i_14396 + 1;
        goto L34; // [1248] 1194
L35: 
        ;
    }

    /** 			puts(1, "\n")*/
    EPuts(1, _3073); // DJP 
L32: 
L31: 

    /** end procedure*/
    DeRefDS(_opts_14146);
    DeRef(_add_help_rid_14147);
    DeRefDS(_cmds_14148);
    DeRef(_parse_options_14151);
    DeRef(_cmd_14154);
    DeRef(_param_name_14155);
    _7916 = NOVALUE;
    _7929 = NOVALUE;
    _7952 = NOVALUE;
    _7983 = NOVALUE;
    _8042 = NOVALUE;
    _8051 = NOVALUE;
    _8066 = NOVALUE;
    DeRef(_8068);
    _8068 = NOVALUE;
    return;
    ;
}


int _4find_opt(int _opts_14417, int _opt_style_14418, int _cmd_text_14419)
{
    int _opt_name_14420 = NOVALUE;
    int _opt_param_14421 = NOVALUE;
    int _param_found_14422 = NOVALUE;
    int _reversed_14423 = NOVALUE;
    int _8176 = NOVALUE;
    int _8174 = NOVALUE;
    int _8173 = NOVALUE;
    int _8171 = NOVALUE;
    int _8170 = NOVALUE;
    int _8169 = NOVALUE;
    int _8168 = NOVALUE;
    int _8167 = NOVALUE;
    int _8164 = NOVALUE;
    int _8163 = NOVALUE;
    int _8162 = NOVALUE;
    int _8160 = NOVALUE;
    int _8159 = NOVALUE;
    int _8158 = NOVALUE;
    int _8157 = NOVALUE;
    int _8155 = NOVALUE;
    int _8154 = NOVALUE;
    int _8153 = NOVALUE;
    int _8152 = NOVALUE;
    int _8151 = NOVALUE;
    int _8150 = NOVALUE;
    int _8149 = NOVALUE;
    int _8148 = NOVALUE;
    int _8147 = NOVALUE;
    int _8146 = NOVALUE;
    int _8145 = NOVALUE;
    int _8144 = NOVALUE;
    int _8138 = NOVALUE;
    int _8137 = NOVALUE;
    int _8136 = NOVALUE;
    int _8128 = NOVALUE;
    int _8127 = NOVALUE;
    int _8125 = NOVALUE;
    int _8123 = NOVALUE;
    int _8122 = NOVALUE;
    int _8120 = NOVALUE;
    int _8119 = NOVALUE;
    int _8118 = NOVALUE;
    int _8117 = NOVALUE;
    int _8116 = NOVALUE;
    int _8114 = NOVALUE;
    int _8113 = NOVALUE;
    int _8111 = NOVALUE;
    int _8109 = NOVALUE;
    int _8108 = NOVALUE;
    int _8106 = NOVALUE;
    int _8105 = NOVALUE;
    int _8104 = NOVALUE;
    int _8103 = NOVALUE;
    int _8101 = NOVALUE;
    int _8100 = NOVALUE;
    int _8097 = NOVALUE;
    int _8095 = NOVALUE;
    int _8094 = NOVALUE;
    int _8092 = NOVALUE;
    int _8090 = NOVALUE;
    int _8088 = NOVALUE;
    int _8086 = NOVALUE;
    int _8084 = NOVALUE;
    int _8083 = NOVALUE;
    int _8082 = NOVALUE;
    int _8081 = NOVALUE;
    int _8080 = NOVALUE;
    int _8078 = NOVALUE;
    int _8077 = NOVALUE;
    int _8075 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer param_found = 0*/
    _param_found_14422 = 0;

    /** 	integer reversed = 0*/
    _reversed_14423 = 0;

    /** 	if length(cmd_text) >= 2 then*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8075 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8075 = 1;
    }
    if (_8075 < 2)
    goto L1; // [20] 85

    /** 		if cmd_text[1] = '\'' or cmd_text[1] = '"' then*/
    _2 = (int)SEQ_PTR(_cmd_text_14419);
    _8077 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8077)) {
        _8078 = (_8077 == 39);
    }
    else {
        _8078 = binary_op(EQUALS, _8077, 39);
    }
    _8077 = NOVALUE;
    if (IS_ATOM_INT(_8078)) {
        if (_8078 != 0) {
            goto L2; // [34] 51
        }
    }
    else {
        if (DBL_PTR(_8078)->dbl != 0.0) {
            goto L2; // [34] 51
        }
    }
    _2 = (int)SEQ_PTR(_cmd_text_14419);
    _8080 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8080)) {
        _8081 = (_8080 == 34);
    }
    else {
        _8081 = binary_op(EQUALS, _8080, 34);
    }
    _8080 = NOVALUE;
    if (_8081 == 0) {
        DeRef(_8081);
        _8081 = NOVALUE;
        goto L3; // [47] 84
    }
    else {
        if (!IS_ATOM_INT(_8081) && DBL_PTR(_8081)->dbl == 0.0){
            DeRef(_8081);
            _8081 = NOVALUE;
            goto L3; // [47] 84
        }
        DeRef(_8081);
        _8081 = NOVALUE;
    }
    DeRef(_8081);
    _8081 = NOVALUE;
L2: 

    /** 			if cmd_text[$] = cmd_text[1] then*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8082 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8082 = 1;
    }
    _2 = (int)SEQ_PTR(_cmd_text_14419);
    _8083 = (int)*(((s1_ptr)_2)->base + _8082);
    _2 = (int)SEQ_PTR(_cmd_text_14419);
    _8084 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8083, _8084)){
        _8083 = NOVALUE;
        _8084 = NOVALUE;
        goto L4; // [64] 83
    }
    _8083 = NOVALUE;
    _8084 = NOVALUE;

    /** 				cmd_text = cmd_text[2 .. $-1]*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8086 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8086 = 1;
    }
    _8088 = _8086 - 1;
    _8086 = NOVALUE;
    rhs_slice_target = (object_ptr)&_cmd_text_14419;
    RHS_Slice(_cmd_text_14419, 2, _8088);
L4: 
L3: 
L1: 

    /** 	if length(cmd_text) > 0 then*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8090 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8090 = 1;
    }
    if (_8090 <= 0)
    goto L5; // [90] 125

    /** 		if find(cmd_text[1], "!-") then*/
    _2 = (int)SEQ_PTR(_cmd_text_14419);
    _8092 = (int)*(((s1_ptr)_2)->base + 1);
    _8094 = find_from(_8092, _8093, 1);
    _8092 = NOVALUE;
    if (_8094 == 0)
    {
        _8094 = NOVALUE;
        goto L6; // [105] 124
    }
    else{
        _8094 = NOVALUE;
    }

    /** 			reversed = 1*/
    _reversed_14423 = 1;

    /** 			cmd_text = cmd_text[2 .. $]*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8095 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8095 = 1;
    }
    rhs_slice_target = (object_ptr)&_cmd_text_14419;
    RHS_Slice(_cmd_text_14419, 2, _8095);
L6: 
L5: 

    /** 	if length(cmd_text) < 1 then*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8097 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8097 = 1;
    }
    if (_8097 >= 1)
    goto L7; // [130] 145

    /** 		return {-1, "Empty command text"}*/
    RefDS(_8099);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _8099;
    _8100 = MAKE_SEQ(_1);
    DeRefDS(_opts_14417);
    DeRefDS(_opt_style_14418);
    DeRef(_cmd_text_14419);
    DeRef(_opt_name_14420);
    DeRef(_opt_param_14421);
    DeRef(_8088);
    _8088 = NOVALUE;
    DeRef(_8078);
    _8078 = NOVALUE;
    return _8100;
L7: 

    /** 	opt_name = repeat(' ', length(cmd_text))*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8101 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8101 = 1;
    }
    DeRef(_opt_name_14420);
    _opt_name_14420 = Repeat(32, _8101);
    _8101 = NOVALUE;

    /** 	opt_param = 0*/
    DeRef(_opt_param_14421);
    _opt_param_14421 = 0;

    /** 	for i = 1 to length(cmd_text) do*/
    if (IS_SEQUENCE(_cmd_text_14419)){
            _8103 = SEQ_PTR(_cmd_text_14419)->length;
    }
    else {
        _8103 = 1;
    }
    {
        int _i_14458;
        _i_14458 = 1;
L8: 
        if (_i_14458 > _8103){
            goto L9; // [164] 320
        }

        /** 		if find(cmd_text[i], ":=") then*/
        _2 = (int)SEQ_PTR(_cmd_text_14419);
        _8104 = (int)*(((s1_ptr)_2)->base + _i_14458);
        _8105 = find_from(_8104, _4622, 1);
        _8104 = NOVALUE;
        if (_8105 == 0)
        {
            _8105 = NOVALUE;
            goto LA; // [182] 302
        }
        else{
            _8105 = NOVALUE;
        }

        /** 			opt_name = opt_name[1 .. i - 1]*/
        _8106 = _i_14458 - 1;
        rhs_slice_target = (object_ptr)&_opt_name_14420;
        RHS_Slice(_opt_name_14420, 1, _8106);

        /** 			opt_param = cmd_text[i + 1 .. $]*/
        _8108 = _i_14458 + 1;
        if (IS_SEQUENCE(_cmd_text_14419)){
                _8109 = SEQ_PTR(_cmd_text_14419)->length;
        }
        else {
            _8109 = 1;
        }
        rhs_slice_target = (object_ptr)&_opt_param_14421;
        RHS_Slice(_cmd_text_14419, _8108, _8109);

        /** 			if length(opt_param) >= 2 then*/
        if (IS_SEQUENCE(_opt_param_14421)){
                _8111 = SEQ_PTR(_opt_param_14421)->length;
        }
        else {
            _8111 = 1;
        }
        if (_8111 < 2)
        goto LB; // [215] 280

        /** 				if opt_param[1] = '\'' or opt_param[1] = '"' then*/
        _2 = (int)SEQ_PTR(_opt_param_14421);
        _8113 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8113)) {
            _8114 = (_8113 == 39);
        }
        else {
            _8114 = binary_op(EQUALS, _8113, 39);
        }
        _8113 = NOVALUE;
        if (IS_ATOM_INT(_8114)) {
            if (_8114 != 0) {
                goto LC; // [229] 246
            }
        }
        else {
            if (DBL_PTR(_8114)->dbl != 0.0) {
                goto LC; // [229] 246
            }
        }
        _2 = (int)SEQ_PTR(_opt_param_14421);
        _8116 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_8116)) {
            _8117 = (_8116 == 34);
        }
        else {
            _8117 = binary_op(EQUALS, _8116, 34);
        }
        _8116 = NOVALUE;
        if (_8117 == 0) {
            DeRef(_8117);
            _8117 = NOVALUE;
            goto LD; // [242] 279
        }
        else {
            if (!IS_ATOM_INT(_8117) && DBL_PTR(_8117)->dbl == 0.0){
                DeRef(_8117);
                _8117 = NOVALUE;
                goto LD; // [242] 279
            }
            DeRef(_8117);
            _8117 = NOVALUE;
        }
        DeRef(_8117);
        _8117 = NOVALUE;
LC: 

        /** 					if opt_param[$] = opt_param[1] then*/
        if (IS_SEQUENCE(_opt_param_14421)){
                _8118 = SEQ_PTR(_opt_param_14421)->length;
        }
        else {
            _8118 = 1;
        }
        _2 = (int)SEQ_PTR(_opt_param_14421);
        _8119 = (int)*(((s1_ptr)_2)->base + _8118);
        _2 = (int)SEQ_PTR(_opt_param_14421);
        _8120 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _8119, _8120)){
            _8119 = NOVALUE;
            _8120 = NOVALUE;
            goto LE; // [259] 278
        }
        _8119 = NOVALUE;
        _8120 = NOVALUE;

        /** 						opt_param = opt_param[2 .. $-1]*/
        if (IS_SEQUENCE(_opt_param_14421)){
                _8122 = SEQ_PTR(_opt_param_14421)->length;
        }
        else {
            _8122 = 1;
        }
        _8123 = _8122 - 1;
        _8122 = NOVALUE;
        rhs_slice_target = (object_ptr)&_opt_param_14421;
        RHS_Slice(_opt_param_14421, 2, _8123);
LE: 
LD: 
LB: 

        /** 			if length(opt_param) > 0 then*/
        if (IS_SEQUENCE(_opt_param_14421)){
                _8125 = SEQ_PTR(_opt_param_14421)->length;
        }
        else {
            _8125 = 1;
        }
        if (_8125 <= 0)
        goto L9; // [285] 320

        /** 				param_found = 1*/
        _param_found_14422 = 1;

        /** 			exit*/
        goto L9; // [297] 320
        goto LF; // [299] 313
LA: 

        /** 			opt_name[i] = cmd_text[i]*/
        _2 = (int)SEQ_PTR(_cmd_text_14419);
        _8127 = (int)*(((s1_ptr)_2)->base + _i_14458);
        Ref(_8127);
        _2 = (int)SEQ_PTR(_opt_name_14420);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _opt_name_14420 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_14458);
        _1 = *(int *)_2;
        *(int *)_2 = _8127;
        if( _1 != _8127 ){
            DeRef(_1);
        }
        _8127 = NOVALUE;
LF: 

        /** 	end for*/
        _i_14458 = _i_14458 + 1;
        goto L8; // [315] 171
L9: 
        ;
    }

    /** 	if param_found then*/
    if (_param_found_14422 == 0)
    {
        goto L10; // [322] 388
    }
    else{
    }

    /** 		if find( text:lower(opt_param), {"1", "on", "yes", "y", "true", "ok", "+"}) then*/
    Ref(_opt_param_14421);
    _8128 = _14lower(_opt_param_14421);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8129);
    *((int *)(_2+4)) = _8129;
    RefDS(_8130);
    *((int *)(_2+8)) = _8130;
    RefDS(_8131);
    *((int *)(_2+12)) = _8131;
    RefDS(_8132);
    *((int *)(_2+16)) = _8132;
    RefDS(_8133);
    *((int *)(_2+20)) = _8133;
    RefDS(_8134);
    *((int *)(_2+24)) = _8134;
    RefDS(_8135);
    *((int *)(_2+28)) = _8135;
    _8136 = MAKE_SEQ(_1);
    _8137 = find_from(_8128, _8136, 1);
    DeRef(_8128);
    _8128 = NOVALUE;
    DeRefDS(_8136);
    _8136 = NOVALUE;
    if (_8137 == 0)
    {
        _8137 = NOVALUE;
        goto L11; // [346] 357
    }
    else{
        _8137 = NOVALUE;
    }

    /** 			opt_param = 1*/
    DeRef(_opt_param_14421);
    _opt_param_14421 = 1;
    goto L12; // [354] 387
L11: 

    /** 		elsif find( text:lower(opt_param), {"0", "off", "no", "n", "false", "-"}) then*/
    Ref(_opt_param_14421);
    _8138 = _14lower(_opt_param_14421);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8139);
    *((int *)(_2+4)) = _8139;
    RefDS(_8140);
    *((int *)(_2+8)) = _8140;
    RefDS(_8141);
    *((int *)(_2+12)) = _8141;
    RefDS(_8142);
    *((int *)(_2+16)) = _8142;
    RefDS(_8143);
    *((int *)(_2+20)) = _8143;
    RefDS(_6992);
    *((int *)(_2+24)) = _6992;
    _8144 = MAKE_SEQ(_1);
    _8145 = find_from(_8138, _8144, 1);
    DeRef(_8138);
    _8138 = NOVALUE;
    DeRefDS(_8144);
    _8144 = NOVALUE;
    if (_8145 == 0)
    {
        _8145 = NOVALUE;
        goto L13; // [377] 386
    }
    else{
        _8145 = NOVALUE;
    }

    /** 			opt_param = 0*/
    DeRef(_opt_param_14421);
    _opt_param_14421 = 0;
L13: 
L12: 
L10: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14417)){
            _8146 = SEQ_PTR(_opts_14417)->length;
    }
    else {
        _8146 = 1;
    }
    {
        int _i_14512;
        _i_14512 = 1;
L14: 
        if (_i_14512 > _8146){
            goto L15; // [393] 592
        }

        /** 		if find(NO_CASE,  opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14417);
        _8147 = (int)*(((s1_ptr)_2)->base + _i_14512);
        _2 = (int)SEQ_PTR(_8147);
        _8148 = (int)*(((s1_ptr)_2)->base + 4);
        _8147 = NOVALUE;
        _8149 = find_from(105, _8148, 1);
        _8148 = NOVALUE;
        if (_8149 == 0)
        {
            _8149 = NOVALUE;
            goto L16; // [415] 455
        }
        else{
            _8149 = NOVALUE;
        }

        /** 			if not equal( text:lower(opt_name), text:lower(opts[i][opt_style[1]])) then*/
        RefDS(_opt_name_14420);
        _8150 = _14lower(_opt_name_14420);
        _2 = (int)SEQ_PTR(_opts_14417);
        _8151 = (int)*(((s1_ptr)_2)->base + _i_14512);
        _2 = (int)SEQ_PTR(_opt_style_14418);
        _8152 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8151);
        if (!IS_ATOM_INT(_8152)){
            _8153 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8152)->dbl));
        }
        else{
            _8153 = (int)*(((s1_ptr)_2)->base + _8152);
        }
        _8151 = NOVALUE;
        Ref(_8153);
        _8154 = _14lower(_8153);
        _8153 = NOVALUE;
        if (_8150 == _8154)
        _8155 = 1;
        else if (IS_ATOM_INT(_8150) && IS_ATOM_INT(_8154))
        _8155 = 0;
        else
        _8155 = (compare(_8150, _8154) == 0);
        DeRef(_8150);
        _8150 = NOVALUE;
        DeRef(_8154);
        _8154 = NOVALUE;
        if (_8155 != 0)
        goto L17; // [444] 482
        _8155 = NOVALUE;

        /** 				continue*/
        goto L18; // [449] 587
        goto L17; // [452] 482
L16: 

        /** 			if not equal(opt_name, opts[i][opt_style[1]]) then*/
        _2 = (int)SEQ_PTR(_opts_14417);
        _8157 = (int)*(((s1_ptr)_2)->base + _i_14512);
        _2 = (int)SEQ_PTR(_opt_style_14418);
        _8158 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_8157);
        if (!IS_ATOM_INT(_8158)){
            _8159 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8158)->dbl));
        }
        else{
            _8159 = (int)*(((s1_ptr)_2)->base + _8158);
        }
        _8157 = NOVALUE;
        if (_opt_name_14420 == _8159)
        _8160 = 1;
        else if (IS_ATOM_INT(_opt_name_14420) && IS_ATOM_INT(_8159))
        _8160 = 0;
        else
        _8160 = (compare(_opt_name_14420, _8159) == 0);
        _8159 = NOVALUE;
        if (_8160 != 0)
        goto L19; // [473] 481
        _8160 = NOVALUE;

        /** 				continue*/
        goto L18; // [478] 587
L19: 
L17: 

        /** 		if find(HAS_PARAMETER,  opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14417);
        _8162 = (int)*(((s1_ptr)_2)->base + _i_14512);
        _2 = (int)SEQ_PTR(_8162);
        _8163 = (int)*(((s1_ptr)_2)->base + 4);
        _8162 = NOVALUE;
        _8164 = find_from(112, _8163, 1);
        _8163 = NOVALUE;
        if (_8164 != 0)
        goto L1A; // [497] 518

        /** 			if param_found then*/
        if (_param_found_14422 == 0)
        {
            goto L1B; // [503] 517
        }
        else{
        }

        /** 				return {0, "Option should not have a parameter"}*/
        RefDS(_8166);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 0;
        ((int *)_2)[2] = _8166;
        _8167 = MAKE_SEQ(_1);
        DeRefDS(_opts_14417);
        DeRefDS(_opt_style_14418);
        DeRef(_cmd_text_14419);
        DeRef(_opt_name_14420);
        DeRef(_opt_param_14421);
        DeRef(_8088);
        _8088 = NOVALUE;
        DeRef(_8078);
        _8078 = NOVALUE;
        DeRef(_8100);
        _8100 = NOVALUE;
        DeRef(_8106);
        _8106 = NOVALUE;
        DeRef(_8108);
        _8108 = NOVALUE;
        DeRef(_8123);
        _8123 = NOVALUE;
        DeRef(_8114);
        _8114 = NOVALUE;
        _8158 = NOVALUE;
        _8152 = NOVALUE;
        return _8167;
L1B: 
L1A: 

        /** 		if param_found then*/
        if (_param_found_14422 == 0)
        {
            goto L1C; // [520] 539
        }
        else{
        }

        /** 			return {i, opt_name, reversed, opt_param}*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14512;
        RefDS(_opt_name_14420);
        *((int *)(_2+8)) = _opt_name_14420;
        *((int *)(_2+12)) = _reversed_14423;
        Ref(_opt_param_14421);
        *((int *)(_2+16)) = _opt_param_14421;
        _8168 = MAKE_SEQ(_1);
        DeRefDS(_opts_14417);
        DeRefDS(_opt_style_14418);
        DeRef(_cmd_text_14419);
        DeRefDS(_opt_name_14420);
        DeRef(_opt_param_14421);
        DeRef(_8088);
        _8088 = NOVALUE;
        DeRef(_8078);
        _8078 = NOVALUE;
        DeRef(_8100);
        _8100 = NOVALUE;
        DeRef(_8106);
        _8106 = NOVALUE;
        DeRef(_8108);
        _8108 = NOVALUE;
        DeRef(_8123);
        _8123 = NOVALUE;
        DeRef(_8114);
        _8114 = NOVALUE;
        DeRef(_8167);
        _8167 = NOVALUE;
        _8158 = NOVALUE;
        _8152 = NOVALUE;
        return _8168;
        goto L1D; // [536] 585
L1C: 

        /** 			if find(HAS_PARAMETER, opts[i][OPTIONS]) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14417);
        _8169 = (int)*(((s1_ptr)_2)->base + _i_14512);
        _2 = (int)SEQ_PTR(_8169);
        _8170 = (int)*(((s1_ptr)_2)->base + 4);
        _8169 = NOVALUE;
        _8171 = find_from(112, _8170, 1);
        _8170 = NOVALUE;
        if (_8171 != 0)
        goto L1E; // [554] 572

        /** 				return {i, opt_name, reversed, 1 }*/
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14512;
        RefDS(_opt_name_14420);
        *((int *)(_2+8)) = _opt_name_14420;
        *((int *)(_2+12)) = _reversed_14423;
        *((int *)(_2+16)) = 1;
        _8173 = MAKE_SEQ(_1);
        DeRefDS(_opts_14417);
        DeRefDS(_opt_style_14418);
        DeRef(_cmd_text_14419);
        DeRefDS(_opt_name_14420);
        DeRef(_opt_param_14421);
        DeRef(_8088);
        _8088 = NOVALUE;
        DeRef(_8078);
        _8078 = NOVALUE;
        DeRef(_8100);
        _8100 = NOVALUE;
        DeRef(_8106);
        _8106 = NOVALUE;
        DeRef(_8108);
        _8108 = NOVALUE;
        DeRef(_8123);
        _8123 = NOVALUE;
        DeRef(_8114);
        _8114 = NOVALUE;
        DeRef(_8167);
        _8167 = NOVALUE;
        _8158 = NOVALUE;
        _8152 = NOVALUE;
        DeRef(_8168);
        _8168 = NOVALUE;
        return _8173;
L1E: 

        /** 			return {i, opt_name, reversed}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _i_14512;
        RefDS(_opt_name_14420);
        *((int *)(_2+8)) = _opt_name_14420;
        *((int *)(_2+12)) = _reversed_14423;
        _8174 = MAKE_SEQ(_1);
        DeRefDS(_opts_14417);
        DeRefDS(_opt_style_14418);
        DeRef(_cmd_text_14419);
        DeRefDS(_opt_name_14420);
        DeRef(_opt_param_14421);
        DeRef(_8088);
        _8088 = NOVALUE;
        DeRef(_8078);
        _8078 = NOVALUE;
        DeRef(_8100);
        _8100 = NOVALUE;
        DeRef(_8106);
        _8106 = NOVALUE;
        DeRef(_8108);
        _8108 = NOVALUE;
        DeRef(_8123);
        _8123 = NOVALUE;
        DeRef(_8114);
        _8114 = NOVALUE;
        DeRef(_8167);
        _8167 = NOVALUE;
        _8158 = NOVALUE;
        _8152 = NOVALUE;
        DeRef(_8168);
        _8168 = NOVALUE;
        DeRef(_8173);
        _8173 = NOVALUE;
        return _8174;
L1D: 

        /** 	end for*/
L18: 
        _i_14512 = _i_14512 + 1;
        goto L14; // [587] 400
L15: 
        ;
    }

    /** 	return {0, "Unrecognised"}*/
    RefDS(_8175);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _8175;
    _8176 = MAKE_SEQ(_1);
    DeRefDS(_opts_14417);
    DeRefDS(_opt_style_14418);
    DeRef(_cmd_text_14419);
    DeRef(_opt_name_14420);
    DeRef(_opt_param_14421);
    DeRef(_8088);
    _8088 = NOVALUE;
    DeRef(_8078);
    _8078 = NOVALUE;
    DeRef(_8100);
    _8100 = NOVALUE;
    DeRef(_8106);
    _8106 = NOVALUE;
    DeRef(_8108);
    _8108 = NOVALUE;
    DeRef(_8123);
    _8123 = NOVALUE;
    DeRef(_8114);
    _8114 = NOVALUE;
    DeRef(_8167);
    _8167 = NOVALUE;
    _8158 = NOVALUE;
    _8152 = NOVALUE;
    DeRef(_8168);
    _8168 = NOVALUE;
    DeRef(_8173);
    _8173 = NOVALUE;
    DeRef(_8174);
    _8174 = NOVALUE;
    return _8176;
    ;
}


int _4cmd_parse(int _opts_14555, int _parse_options_14556, int _cmds_14557)
{
    int _arg_idx_14559 = NOVALUE;
    int _opts_done_14560 = NOVALUE;
    int _cmd_14561 = NOVALUE;
    int _param_14562 = NOVALUE;
    int _find_result_14563 = NOVALUE;
    int _type__14564 = NOVALUE;
    int _from__14565 = NOVALUE;
    int _help_opts_14566 = NOVALUE;
    int _call_count_14567 = NOVALUE;
    int _add_help_rid_14568 = NOVALUE;
    int _validation_14569 = NOVALUE;
    int _has_extra_14570 = NOVALUE;
    int _use_at_14571 = NOVALUE;
    int _auto_help_14572 = NOVALUE;
    int _help_on_error_14573 = NOVALUE;
    int _po_14574 = NOVALUE;
    int _msg_inlined_crash_at_107_14592 = NOVALUE;
    int _msg_inlined_crash_at_237_14609 = NOVALUE;
    int _msg_inlined_crash_at_275_14616 = NOVALUE;
    int _fmt_inlined_crash_at_272_14615 = NOVALUE;
    int _parsed_opts_14621 = NOVALUE;
    int _at_cmds_14668 = NOVALUE;
    int _j_14669 = NOVALUE;
    int _cmdex_14754 = NOVALUE;
    int _opt_14818 = NOVALUE;
    int _map_add_operation_14821 = NOVALUE;
    int _pos_14860 = NOVALUE;
    int _ver_pos_14907 = NOVALUE;
    int _msg_inlined_crash_at_2040_14925 = NOVALUE;
    int _fmt_inlined_crash_at_2037_14924 = NOVALUE;
    int _8458 = NOVALUE;
    int _8457 = NOVALUE;
    int _8456 = NOVALUE;
    int _8453 = NOVALUE;
    int _8452 = NOVALUE;
    int _8451 = NOVALUE;
    int _8448 = NOVALUE;
    int _8447 = NOVALUE;
    int _8446 = NOVALUE;
    int _8445 = NOVALUE;
    int _8444 = NOVALUE;
    int _8443 = NOVALUE;
    int _8442 = NOVALUE;
    int _8441 = NOVALUE;
    int _8440 = NOVALUE;
    int _8439 = NOVALUE;
    int _8438 = NOVALUE;
    int _8437 = NOVALUE;
    int _8436 = NOVALUE;
    int _8435 = NOVALUE;
    int _8434 = NOVALUE;
    int _8433 = NOVALUE;
    int _8430 = NOVALUE;
    int _8429 = NOVALUE;
    int _8428 = NOVALUE;
    int _8425 = NOVALUE;
    int _8424 = NOVALUE;
    int _8422 = NOVALUE;
    int _8421 = NOVALUE;
    int _8420 = NOVALUE;
    int _8419 = NOVALUE;
    int _8418 = NOVALUE;
    int _8417 = NOVALUE;
    int _8416 = NOVALUE;
    int _8415 = NOVALUE;
    int _8413 = NOVALUE;
    int _8412 = NOVALUE;
    int _8410 = NOVALUE;
    int _8409 = NOVALUE;
    int _8408 = NOVALUE;
    int _8407 = NOVALUE;
    int _8406 = NOVALUE;
    int _8405 = NOVALUE;
    int _8404 = NOVALUE;
    int _8403 = NOVALUE;
    int _8401 = NOVALUE;
    int _8400 = NOVALUE;
    int _8399 = NOVALUE;
    int _8397 = NOVALUE;
    int _8395 = NOVALUE;
    int _8394 = NOVALUE;
    int _8393 = NOVALUE;
    int _8392 = NOVALUE;
    int _8391 = NOVALUE;
    int _8390 = NOVALUE;
    int _8389 = NOVALUE;
    int _8388 = NOVALUE;
    int _8387 = NOVALUE;
    int _8384 = NOVALUE;
    int _8381 = NOVALUE;
    int _8380 = NOVALUE;
    int _8378 = NOVALUE;
    int _8377 = NOVALUE;
    int _8376 = NOVALUE;
    int _8375 = NOVALUE;
    int _8374 = NOVALUE;
    int _8373 = NOVALUE;
    int _8372 = NOVALUE;
    int _8371 = NOVALUE;
    int _8370 = NOVALUE;
    int _8369 = NOVALUE;
    int _8368 = NOVALUE;
    int _8365 = NOVALUE;
    int _8362 = NOVALUE;
    int _8360 = NOVALUE;
    int _8359 = NOVALUE;
    int _8357 = NOVALUE;
    int _8356 = NOVALUE;
    int _8355 = NOVALUE;
    int _8353 = NOVALUE;
    int _8352 = NOVALUE;
    int _8351 = NOVALUE;
    int _8349 = NOVALUE;
    int _8347 = NOVALUE;
    int _8345 = NOVALUE;
    int _8343 = NOVALUE;
    int _8342 = NOVALUE;
    int _8341 = NOVALUE;
    int _8340 = NOVALUE;
    int _8339 = NOVALUE;
    int _8335 = NOVALUE;
    int _8333 = NOVALUE;
    int _8332 = NOVALUE;
    int _8331 = NOVALUE;
    int _8330 = NOVALUE;
    int _8329 = NOVALUE;
    int _8328 = NOVALUE;
    int _8326 = NOVALUE;
    int _8325 = NOVALUE;
    int _8324 = NOVALUE;
    int _8323 = NOVALUE;
    int _8322 = NOVALUE;
    int _8321 = NOVALUE;
    int _8320 = NOVALUE;
    int _8316 = NOVALUE;
    int _8315 = NOVALUE;
    int _8312 = NOVALUE;
    int _8311 = NOVALUE;
    int _8310 = NOVALUE;
    int _8309 = NOVALUE;
    int _8308 = NOVALUE;
    int _8307 = NOVALUE;
    int _8306 = NOVALUE;
    int _8305 = NOVALUE;
    int _8304 = NOVALUE;
    int _8303 = NOVALUE;
    int _8302 = NOVALUE;
    int _8301 = NOVALUE;
    int _8300 = NOVALUE;
    int _8299 = NOVALUE;
    int _8298 = NOVALUE;
    int _8297 = NOVALUE;
    int _8296 = NOVALUE;
    int _8295 = NOVALUE;
    int _8294 = NOVALUE;
    int _8293 = NOVALUE;
    int _8292 = NOVALUE;
    int _8291 = NOVALUE;
    int _8290 = NOVALUE;
    int _8289 = NOVALUE;
    int _8288 = NOVALUE;
    int _8287 = NOVALUE;
    int _8286 = NOVALUE;
    int _8285 = NOVALUE;
    int _8284 = NOVALUE;
    int _8283 = NOVALUE;
    int _8282 = NOVALUE;
    int _8281 = NOVALUE;
    int _8278 = NOVALUE;
    int _8277 = NOVALUE;
    int _8276 = NOVALUE;
    int _8275 = NOVALUE;
    int _8274 = NOVALUE;
    int _8272 = NOVALUE;
    int _8271 = NOVALUE;
    int _8268 = NOVALUE;
    int _8267 = NOVALUE;
    int _8266 = NOVALUE;
    int _8265 = NOVALUE;
    int _8264 = NOVALUE;
    int _8262 = NOVALUE;
    int _8261 = NOVALUE;
    int _8260 = NOVALUE;
    int _8259 = NOVALUE;
    int _8256 = NOVALUE;
    int _8254 = NOVALUE;
    int _8253 = NOVALUE;
    int _8252 = NOVALUE;
    int _8250 = NOVALUE;
    int _8248 = NOVALUE;
    int _8247 = NOVALUE;
    int _8244 = NOVALUE;
    int _8242 = NOVALUE;
    int _8241 = NOVALUE;
    int _8240 = NOVALUE;
    int _8239 = NOVALUE;
    int _8238 = NOVALUE;
    int _8237 = NOVALUE;
    int _8236 = NOVALUE;
    int _8235 = NOVALUE;
    int _8234 = NOVALUE;
    int _8233 = NOVALUE;
    int _8231 = NOVALUE;
    int _8227 = NOVALUE;
    int _8225 = NOVALUE;
    int _8224 = NOVALUE;
    int _8223 = NOVALUE;
    int _8220 = NOVALUE;
    int _8219 = NOVALUE;
    int _8218 = NOVALUE;
    int _8216 = NOVALUE;
    int _8215 = NOVALUE;
    int _8214 = NOVALUE;
    int _8213 = NOVALUE;
    int _8212 = NOVALUE;
    int _8210 = NOVALUE;
    int _8209 = NOVALUE;
    int _8208 = NOVALUE;
    int _8207 = NOVALUE;
    int _8206 = NOVALUE;
    int _8205 = NOVALUE;
    int _8204 = NOVALUE;
    int _8203 = NOVALUE;
    int _8202 = NOVALUE;
    int _8199 = NOVALUE;
    int _8196 = NOVALUE;
    int _8195 = NOVALUE;
    int _8189 = NOVALUE;
    int _8185 = NOVALUE;
    int _8182 = NOVALUE;
    int _8180 = NOVALUE;
    int _8178 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object add_help_rid = -1*/
    _add_help_rid_14568 = -1;

    /** 	integer validation = VALIDATE_ALL*/
    _validation_14569 = 2;

    /** 	integer has_extra = 0*/
    _has_extra_14570 = 0;

    /** 	integer use_at = 1*/
    _use_at_14571 = 1;

    /** 	integer auto_help = 1*/
    _auto_help_14572 = 1;

    /** 	integer help_on_error = 1*/
    _help_on_error_14573 = 1;

    /** 	integer po = 1*/
    _po_14574 = 1;

    /** 	if atom(parse_options) then*/
    _8178 = 1;
    if (_8178 == 0)
    {
        _8178 = NOVALUE;
        goto L1; // [45] 55
    }
    else{
        _8178 = NOVALUE;
    }

    /** 		parse_options = {parse_options}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    _parse_options_14556 = MAKE_SEQ(_1);
L1: 

    /** 	while po <= length(parse_options) do*/
L2: 
    _8180 = 1;
    if (_po_14574 > 1)
    goto L3; // [63] 308

    /** 		switch parse_options[po] do*/
    _2 = (int)SEQ_PTR(_parse_options_14556);
    _8182 = (int)*(((s1_ptr)_2)->base + _po_14574);
    _0 = _8182;
    _8182 = NOVALUE;
    switch ( _0 ){ 

        /** 			case HELP_RID then*/
        case 1:

        /** 				if po < length(parse_options) then*/
        _8185 = 1;
        if (_po_14574 >= 1)
        goto L4; // [87] 106

        /** 					po += 1*/
        _po_14574 = _po_14574 + 1;

        /** 					add_help_rid = parse_options[po]*/
        _2 = (int)SEQ_PTR(_parse_options_14556);
        _add_help_rid_14568 = (int)*(((s1_ptr)_2)->base + _po_14574);
        goto L5; // [103] 297
L4: 

        /** 					error:crash("HELP_RID was given to cmd_parse with no routine_id")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_107_14592);
        _msg_inlined_crash_at_107_14592 = EPrintf(-9999999, _7897, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_107_14592);

        /** end procedure*/
        goto L6; // [121] 124
L6: 
        DeRefi(_msg_inlined_crash_at_107_14592);
        _msg_inlined_crash_at_107_14592 = NOVALUE;
        goto L5; // [127] 297

        /** 			case NO_HELP then*/
        case 9:

        /** 				auto_help = 0*/
        _auto_help_14572 = 0;
        goto L5; // [138] 297

        /** 			case NO_HELP_ON_ERROR then*/
        case 10:

        /** 				help_on_error = 0*/
        _help_on_error_14573 = 0;
        goto L5; // [149] 297

        /** 			case VALIDATE_ALL then*/
        case 2:

        /** 				validation = VALIDATE_ALL*/
        _validation_14569 = 2;
        goto L5; // [160] 297

        /** 			case NO_VALIDATION then*/
        case 3:

        /** 				validation = NO_VALIDATION*/
        _validation_14569 = 3;
        goto L5; // [171] 297

        /** 			case NO_VALIDATION_AFTER_FIRST_EXTRA then*/
        case 4:

        /** 				validation = NO_VALIDATION_AFTER_FIRST_EXTRA*/
        _validation_14569 = 4;
        goto L5; // [182] 297

        /** 			case NO_AT_EXPANSION then*/
        case 7:

        /** 				use_at = 0*/
        _use_at_14571 = 0;
        goto L5; // [193] 297

        /** 			case AT_EXPANSION then*/
        case 6:

        /** 				use_at = 1*/
        _use_at_14571 = 1;
        goto L5; // [204] 297

        /** 			case PAUSE_MSG then*/
        case 8:

        /** 				if po < length(parse_options) then*/
        _8189 = 1;
        if (_po_14574 >= 1)
        goto L7; // [215] 236

        /** 					po += 1*/
        _po_14574 = _po_14574 + 1;

        /** 					pause_msg = parse_options[po]*/
        DeRef(_4pause_msg_13869);
        _2 = (int)SEQ_PTR(_parse_options_14556);
        _4pause_msg_13869 = (int)*(((s1_ptr)_2)->base + _po_14574);
        goto L5; // [233] 297
L7: 

        /** 					error:crash("PAUSE_MSG was given to cmd_parse with no actually message text")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_237_14609);
        _msg_inlined_crash_at_237_14609 = EPrintf(-9999999, _8193, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_237_14609);

        /** end procedure*/
        goto L8; // [251] 254
L8: 
        DeRefi(_msg_inlined_crash_at_237_14609);
        _msg_inlined_crash_at_237_14609 = NOVALUE;
        goto L5; // [257] 297

        /** 			case else*/
        default:

        /** 				error:crash(sprintf("Unrecognised cmdline PARSE OPTION - %d", parse_options[po]) )*/
        _2 = (int)SEQ_PTR(_parse_options_14556);
        _8195 = (int)*(((s1_ptr)_2)->base + _po_14574);
        _8196 = EPrintf(-9999999, _8194, _8195);
        _8195 = NOVALUE;
        DeRefi(_fmt_inlined_crash_at_272_14615);
        _fmt_inlined_crash_at_272_14615 = _8196;
        _8196 = NOVALUE;

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_275_14616);
        _msg_inlined_crash_at_275_14616 = EPrintf(-9999999, _fmt_inlined_crash_at_272_14615, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_275_14616);

        /** end procedure*/
        goto L9; // [291] 294
L9: 
        DeRefi(_fmt_inlined_crash_at_272_14615);
        _fmt_inlined_crash_at_272_14615 = NOVALUE;
        DeRefi(_msg_inlined_crash_at_275_14616);
        _msg_inlined_crash_at_275_14616 = NOVALUE;
    ;}L5: 

    /** 		po += 1*/
    _po_14574 = _po_14574 + 1;

    /** 	end while*/
    goto L2; // [305] 60
L3: 

    /** 	opts = standardize_opts(opts, auto_help)*/
    RefDS(_opts_14555);
    _0 = _opts_14555;
    _opts_14555 = _4standardize_opts(_opts_14555, _auto_help_14572);
    DeRefDS(_0);

    /** 	call_count = repeat(0, length(opts))*/
    if (IS_SEQUENCE(_opts_14555)){
            _8199 = SEQ_PTR(_opts_14555)->length;
    }
    else {
        _8199 = 1;
    }
    DeRef(_call_count_14567);
    _call_count_14567 = Repeat(0, _8199);
    _8199 = NOVALUE;

    /** 	map:map parsed_opts = map:new()*/
    _0 = _parsed_opts_14621;
    _parsed_opts_14621 = _28new(690);
    DeRef(_0);

    /** 	map:put(parsed_opts, EXTRAS, {})*/
    Ref(_parsed_opts_14621);
    RefDS(_4EXTRAS_13858);
    RefDS(_5);
    _28put(_parsed_opts_14621, _4EXTRAS_13858, _5, 1, 23);

    /** 	help_opts = {}*/
    RefDS(_5);
    DeRef(_help_opts_14566);
    _help_opts_14566 = _5;

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14555)){
            _8202 = SEQ_PTR(_opts_14555)->length;
    }
    else {
        _8202 = 1;
    }
    {
        int _i_14624;
        _i_14624 = 1;
LA: 
        if (_i_14624 > _8202){
            goto LB; // [357] 517
        }

        /** 		if find(HELP, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8203 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8203);
        _8204 = (int)*(((s1_ptr)_2)->base + 4);
        _8203 = NOVALUE;
        _8205 = find_from(104, _8204, 1);
        _8204 = NOVALUE;
        if (_8205 == 0)
        {
            _8205 = NOVALUE;
            goto LC; // [379] 510
        }
        else{
            _8205 = NOVALUE;
        }

        /** 			if sequence(opts[i][SHORTNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8206 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8206);
        _8207 = (int)*(((s1_ptr)_2)->base + 1);
        _8206 = NOVALUE;
        _8208 = IS_SEQUENCE(_8207);
        _8207 = NOVALUE;
        if (_8208 == 0)
        {
            _8208 = NOVALUE;
            goto LD; // [395] 413
        }
        else{
            _8208 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][SHORTNAME])*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8209 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8209);
        _8210 = (int)*(((s1_ptr)_2)->base + 1);
        _8209 = NOVALUE;
        Ref(_8210);
        Append(&_help_opts_14566, _help_opts_14566, _8210);
        _8210 = NOVALUE;
LD: 

        /** 			if sequence(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8212 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8212);
        _8213 = (int)*(((s1_ptr)_2)->base + 2);
        _8212 = NOVALUE;
        _8214 = IS_SEQUENCE(_8213);
        _8213 = NOVALUE;
        if (_8214 == 0)
        {
            _8214 = NOVALUE;
            goto LE; // [426] 444
        }
        else{
            _8214 = NOVALUE;
        }

        /** 				help_opts = append(help_opts, opts[i][LONGNAME])*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8215 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8215);
        _8216 = (int)*(((s1_ptr)_2)->base + 2);
        _8215 = NOVALUE;
        Ref(_8216);
        Append(&_help_opts_14566, _help_opts_14566, _8216);
        _8216 = NOVALUE;
LE: 

        /** 			if find(NO_CASE, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8218 = (int)*(((s1_ptr)_2)->base + _i_14624);
        _2 = (int)SEQ_PTR(_8218);
        _8219 = (int)*(((s1_ptr)_2)->base + 4);
        _8218 = NOVALUE;
        _8220 = find_from(105, _8219, 1);
        _8219 = NOVALUE;
        if (_8220 == 0)
        {
            _8220 = NOVALUE;
            goto LF; // [459] 509
        }
        else{
            _8220 = NOVALUE;
        }

        /** 				help_opts = text:lower(help_opts)*/
        RefDS(_help_opts_14566);
        _0 = _help_opts_14566;
        _help_opts_14566 = _14lower(_help_opts_14566);
        DeRefDS(_0);

        /** 				arg_idx = length(help_opts)*/
        if (IS_SEQUENCE(_help_opts_14566)){
                _arg_idx_14559 = SEQ_PTR(_help_opts_14566)->length;
        }
        else {
            _arg_idx_14559 = 1;
        }

        /** 				for j = 1 to arg_idx do*/
        _8223 = _arg_idx_14559;
        {
            int _j_14651;
            _j_14651 = 1;
L10: 
            if (_j_14651 > _8223){
                goto L11; // [480] 508
            }

            /** 					help_opts = append( help_opts, text:upper(help_opts[j]) )*/
            _2 = (int)SEQ_PTR(_help_opts_14566);
            _8224 = (int)*(((s1_ptr)_2)->base + _j_14651);
            Ref(_8224);
            _8225 = _14upper(_8224);
            _8224 = NOVALUE;
            Ref(_8225);
            Append(&_help_opts_14566, _help_opts_14566, _8225);
            DeRef(_8225);
            _8225 = NOVALUE;

            /** 				end for*/
            _j_14651 = _j_14651 + 1;
            goto L10; // [503] 487
L11: 
            ;
        }
LF: 
LC: 

        /** 	end for*/
        _i_14624 = _i_14624 + 1;
        goto LA; // [512] 364
LB: 
        ;
    }

    /** 	arg_idx = 2*/
    _arg_idx_14559 = 2;

    /** 	opts_done = 0*/
    _opts_done_14560 = 0;

    /** 	while arg_idx < length(cmds) do*/
L12: 
    if (IS_SEQUENCE(_cmds_14557)){
            _8227 = SEQ_PTR(_cmds_14557)->length;
    }
    else {
        _8227 = 1;
    }
    if (_arg_idx_14559 >= _8227)
    goto L13; // [535] 2072

    /** 		arg_idx += 1*/
    _arg_idx_14559 = _arg_idx_14559 + 1;

    /** 		cmd = cmds[arg_idx]*/
    DeRef(_cmd_14561);
    _2 = (int)SEQ_PTR(_cmds_14557);
    _cmd_14561 = (int)*(((s1_ptr)_2)->base + _arg_idx_14559);
    Ref(_cmd_14561);

    /** 		if length(cmd) = 0 then*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8231 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8231 = 1;
    }
    if (_8231 != 0)
    goto L14; // [558] 567

    /** 			continue*/
    goto L12; // [564] 532
L14: 

    /** 		if cmd[1] = '@' and use_at then*/
    _2 = (int)SEQ_PTR(_cmd_14561);
    _8233 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8233)) {
        _8234 = (_8233 == 64);
    }
    else {
        _8234 = binary_op(EQUALS, _8233, 64);
    }
    _8233 = NOVALUE;
    if (IS_ATOM_INT(_8234)) {
        if (_8234 == 0) {
            goto L15; // [577] 1095
        }
    }
    else {
        if (DBL_PTR(_8234)->dbl == 0.0) {
            goto L15; // [577] 1095
        }
    }
    if (_use_at_14571 == 0)
    {
        goto L15; // [582] 1095
    }
    else{
    }

    /** 			object at_cmds*/

    /** 			integer j*/

    /** 			if length(cmd) > 2 and cmd[2] = '@' then*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8236 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8236 = 1;
    }
    _8237 = (_8236 > 2);
    _8236 = NOVALUE;
    if (_8237 == 0) {
        goto L16; // [598] 660
    }
    _2 = (int)SEQ_PTR(_cmd_14561);
    _8239 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8239)) {
        _8240 = (_8239 == 64);
    }
    else {
        _8240 = binary_op(EQUALS, _8239, 64);
    }
    _8239 = NOVALUE;
    if (_8240 == 0) {
        DeRef(_8240);
        _8240 = NOVALUE;
        goto L16; // [611] 660
    }
    else {
        if (!IS_ATOM_INT(_8240) && DBL_PTR(_8240)->dbl == 0.0){
            DeRef(_8240);
            _8240 = NOVALUE;
            goto L16; // [611] 660
        }
        DeRef(_8240);
        _8240 = NOVALUE;
    }
    DeRef(_8240);
    _8240 = NOVALUE;

    /** 				at_cmds = io:read_lines(cmd[3..$])*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8241 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8241 = 1;
    }
    rhs_slice_target = (object_ptr)&_8242;
    RHS_Slice(_cmd_14561, 3, _8241);
    _0 = _at_cmds_14668;
    _at_cmds_14668 = _8read_lines(_8242);
    DeRef(_0);
    _8242 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_14668 == -1)
    _8244 = 1;
    else if (IS_ATOM_INT(_at_cmds_14668) && IS_ATOM_INT(-1))
    _8244 = 0;
    else
    _8244 = (compare(_at_cmds_14668, -1) == 0);
    if (_8244 == 0)
    {
        _8244 = NOVALUE;
        goto L17; // [634] 738
    }
    else{
        _8244 = NOVALUE;
    }

    /** 					cmds = eu:remove(cmds, arg_idx)*/
    {
        s1_ptr assign_space = SEQ_PTR(_cmds_14557);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_arg_idx_14559)) ? _arg_idx_14559 : (long)(DBL_PTR(_arg_idx_14559)->dbl);
        int stop = (IS_ATOM_INT(_arg_idx_14559)) ? _arg_idx_14559 : (long)(DBL_PTR(_arg_idx_14559)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_cmds_14557), start, &_cmds_14557 );
            }
            else Tail(SEQ_PTR(_cmds_14557), stop+1, &_cmds_14557);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_cmds_14557), start, &_cmds_14557);
        }
        else {
            assign_slice_seq = &assign_space;
            _cmds_14557 = Remove_elements(start, stop, (SEQ_PTR(_cmds_14557)->ref == 1));
        }
    }

    /** 					arg_idx -= 1*/
    _arg_idx_14559 = _arg_idx_14559 - 1;

    /** 					continue*/
    DeRef(_at_cmds_14668);
    _at_cmds_14668 = NOVALUE;
    goto L12; // [654] 532
    goto L17; // [657] 738
L16: 

    /** 				at_cmds = io:read_lines(cmd[2..$])*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8247 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8247 = 1;
    }
    rhs_slice_target = (object_ptr)&_8248;
    RHS_Slice(_cmd_14561, 2, _8247);
    _0 = _at_cmds_14668;
    _at_cmds_14668 = _8read_lines(_8248);
    DeRef(_0);
    _8248 = NOVALUE;

    /** 				if equal(at_cmds, -1) then*/
    if (_at_cmds_14668 == -1)
    _8250 = 1;
    else if (IS_ATOM_INT(_at_cmds_14668) && IS_ATOM_INT(-1))
    _8250 = 0;
    else
    _8250 = (compare(_at_cmds_14668, -1) == 0);
    if (_8250 == 0)
    {
        _8250 = NOVALUE;
        goto L18; // [680] 737
    }
    else{
        _8250 = NOVALUE;
    }

    /** 					printf(2, "Cannot access '@' argument file '%s'\n", {cmd[2..$]})*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8252 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8252 = 1;
    }
    rhs_slice_target = (object_ptr)&_8253;
    RHS_Slice(_cmd_14561, 2, _8252);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8253;
    _8254 = MAKE_SEQ(_1);
    _8253 = NOVALUE;
    EPrintf(2, _8251, _8254);
    DeRefDS(_8254);
    _8254 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_14573 == 0)
    {
        goto L19; // [703] 718
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14555);
    RefDS(_cmds_14557);
    Ref(_parse_options_14556);
    _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
    goto L1A; // [715] 731
L19: 

    /** 					elsif auto_help then*/
    if (_auto_help_14572 == 0)
    {
        goto L1B; // [720] 730
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})*/
    EPrintf(2, _8255, _5);
L1B: 
L1A: 

    /** 					local_abort(1)*/
    _4local_abort(1);
L18: 
L17: 

    /** 			j = 0*/
    _j_14669 = 0;

    /** 			while j < length(at_cmds) do*/
L1C: 
    if (IS_SEQUENCE(_at_cmds_14668)){
            _8256 = SEQ_PTR(_at_cmds_14668)->length;
    }
    else {
        _8256 = 1;
    }
    if (_j_14669 >= _8256)
    goto L1D; // [753] 1074

    /** 				j += 1*/
    _j_14669 = _j_14669 + 1;

    /** 				at_cmds[j] = text:trim(at_cmds[j])*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8259 = (int)*(((s1_ptr)_2)->base + _j_14669);
    Ref(_8259);
    RefDS(_3815);
    _8260 = _14trim(_8259, _3815, 0);
    _8259 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_14668 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_14669);
    _1 = *(int *)_2;
    *(int *)_2 = _8260;
    if( _1 != _8260 ){
        DeRef(_1);
    }
    _8260 = NOVALUE;

    /** 				if length(at_cmds[j]) = 0 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8261 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8261)){
            _8262 = SEQ_PTR(_8261)->length;
    }
    else {
        _8262 = 1;
    }
    _8261 = NOVALUE;
    if (_8262 != 0)
    goto L1E; // [788] 828

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8264 = _j_14669 - 1;
    rhs_slice_target = (object_ptr)&_8265;
    RHS_Slice(_at_cmds_14668, 1, _8264);
    _8266 = _j_14669 + 1;
    if (_8266 > MAXINT){
        _8266 = NewDouble((double)_8266);
    }
    if (IS_SEQUENCE(_at_cmds_14668)){
            _8267 = SEQ_PTR(_at_cmds_14668)->length;
    }
    else {
        _8267 = 1;
    }
    rhs_slice_target = (object_ptr)&_8268;
    RHS_Slice(_at_cmds_14668, _8266, _8267);
    Concat((object_ptr)&_at_cmds_14668, _8265, _8268);
    DeRefDS(_8265);
    _8265 = NOVALUE;
    DeRef(_8265);
    _8265 = NOVALUE;
    DeRefDS(_8268);
    _8268 = NOVALUE;

    /** 					j -= 1*/
    _j_14669 = _j_14669 - 1;
    goto L1C; // [825] 748
L1E: 

    /** 				elsif at_cmds[j][1] = '#' then*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8271 = (int)*(((s1_ptr)_2)->base + _j_14669);
    _2 = (int)SEQ_PTR(_8271);
    _8272 = (int)*(((s1_ptr)_2)->base + 1);
    _8271 = NOVALUE;
    if (binary_op_a(NOTEQ, _8272, 35)){
        _8272 = NOVALUE;
        goto L1F; // [838] 878
    }
    _8272 = NOVALUE;

    /** 					at_cmds = at_cmds[1 .. j-1] & at_cmds[j+1 ..$]*/
    _8274 = _j_14669 - 1;
    rhs_slice_target = (object_ptr)&_8275;
    RHS_Slice(_at_cmds_14668, 1, _8274);
    _8276 = _j_14669 + 1;
    if (_8276 > MAXINT){
        _8276 = NewDouble((double)_8276);
    }
    if (IS_SEQUENCE(_at_cmds_14668)){
            _8277 = SEQ_PTR(_at_cmds_14668)->length;
    }
    else {
        _8277 = 1;
    }
    rhs_slice_target = (object_ptr)&_8278;
    RHS_Slice(_at_cmds_14668, _8276, _8277);
    Concat((object_ptr)&_at_cmds_14668, _8275, _8278);
    DeRefDS(_8275);
    _8275 = NOVALUE;
    DeRef(_8275);
    _8275 = NOVALUE;
    DeRefDS(_8278);
    _8278 = NOVALUE;

    /** 					j -= 1*/
    _j_14669 = _j_14669 - 1;
    goto L1C; // [875] 748
L1F: 

    /** 				elsif at_cmds[j][1] = '"' and at_cmds[j][$] = '"' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8281 = (int)*(((s1_ptr)_2)->base + _j_14669);
    _2 = (int)SEQ_PTR(_8281);
    _8282 = (int)*(((s1_ptr)_2)->base + 1);
    _8281 = NOVALUE;
    if (IS_ATOM_INT(_8282)) {
        _8283 = (_8282 == 34);
    }
    else {
        _8283 = binary_op(EQUALS, _8282, 34);
    }
    _8282 = NOVALUE;
    if (IS_ATOM_INT(_8283)) {
        if (_8283 == 0) {
            DeRef(_8284);
            _8284 = 0;
            goto L20; // [892] 915
        }
    }
    else {
        if (DBL_PTR(_8283)->dbl == 0.0) {
            DeRef(_8284);
            _8284 = 0;
            goto L20; // [892] 915
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8285 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8285)){
            _8286 = SEQ_PTR(_8285)->length;
    }
    else {
        _8286 = 1;
    }
    _2 = (int)SEQ_PTR(_8285);
    _8287 = (int)*(((s1_ptr)_2)->base + _8286);
    _8285 = NOVALUE;
    if (IS_ATOM_INT(_8287)) {
        _8288 = (_8287 == 34);
    }
    else {
        _8288 = binary_op(EQUALS, _8287, 34);
    }
    _8287 = NOVALUE;
    DeRef(_8284);
    if (IS_ATOM_INT(_8288))
    _8284 = (_8288 != 0);
    else
    _8284 = DBL_PTR(_8288)->dbl != 0.0;
L20: 
    if (_8284 == 0) {
        goto L21; // [915] 959
    }
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8290 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8290)){
            _8291 = SEQ_PTR(_8290)->length;
    }
    else {
        _8291 = 1;
    }
    _8290 = NOVALUE;
    _8292 = (_8291 >= 2);
    _8291 = NOVALUE;
    if (_8292 == 0)
    {
        DeRef(_8292);
        _8292 = NOVALUE;
        goto L21; // [931] 959
    }
    else{
        DeRef(_8292);
        _8292 = NOVALUE;
    }

    /** 					at_cmds[j] = at_cmds[j][2 .. $-1]*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8293 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8293)){
            _8294 = SEQ_PTR(_8293)->length;
    }
    else {
        _8294 = 1;
    }
    _8295 = _8294 - 1;
    _8294 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8296;
    RHS_Slice(_8293, 2, _8295);
    _8293 = NOVALUE;
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _at_cmds_14668 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _j_14669);
    _1 = *(int *)_2;
    *(int *)_2 = _8296;
    if( _1 != _8296 ){
        DeRef(_1);
    }
    _8296 = NOVALUE;
    goto L1C; // [956] 748
L21: 

    /** 				elsif at_cmds[j][1] = '\'' and at_cmds[j][$] = '\'' and length(at_cmds[j]) >= 2 then*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8297 = (int)*(((s1_ptr)_2)->base + _j_14669);
    _2 = (int)SEQ_PTR(_8297);
    _8298 = (int)*(((s1_ptr)_2)->base + 1);
    _8297 = NOVALUE;
    if (IS_ATOM_INT(_8298)) {
        _8299 = (_8298 == 39);
    }
    else {
        _8299 = binary_op(EQUALS, _8298, 39);
    }
    _8298 = NOVALUE;
    if (IS_ATOM_INT(_8299)) {
        if (_8299 == 0) {
            DeRef(_8300);
            _8300 = 0;
            goto L22; // [973] 996
        }
    }
    else {
        if (DBL_PTR(_8299)->dbl == 0.0) {
            DeRef(_8300);
            _8300 = 0;
            goto L22; // [973] 996
        }
    }
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8301 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8301)){
            _8302 = SEQ_PTR(_8301)->length;
    }
    else {
        _8302 = 1;
    }
    _2 = (int)SEQ_PTR(_8301);
    _8303 = (int)*(((s1_ptr)_2)->base + _8302);
    _8301 = NOVALUE;
    if (IS_ATOM_INT(_8303)) {
        _8304 = (_8303 == 39);
    }
    else {
        _8304 = binary_op(EQUALS, _8303, 39);
    }
    _8303 = NOVALUE;
    DeRef(_8300);
    if (IS_ATOM_INT(_8304))
    _8300 = (_8304 != 0);
    else
    _8300 = DBL_PTR(_8304)->dbl != 0.0;
L22: 
    if (_8300 == 0) {
        goto L23; // [996] 1066
    }
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8306 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8306)){
            _8307 = SEQ_PTR(_8306)->length;
    }
    else {
        _8307 = 1;
    }
    _8306 = NOVALUE;
    _8308 = (_8307 >= 2);
    _8307 = NOVALUE;
    if (_8308 == 0)
    {
        DeRef(_8308);
        _8308 = NOVALUE;
        goto L23; // [1012] 1066
    }
    else{
        DeRef(_8308);
        _8308 = NOVALUE;
    }

    /** 					sequence cmdex = stdseq:split(at_cmds[j][2 .. $-1],' ', 1) -- Empty words removed.*/
    _2 = (int)SEQ_PTR(_at_cmds_14668);
    _8309 = (int)*(((s1_ptr)_2)->base + _j_14669);
    if (IS_SEQUENCE(_8309)){
            _8310 = SEQ_PTR(_8309)->length;
    }
    else {
        _8310 = 1;
    }
    _8311 = _8310 - 1;
    _8310 = NOVALUE;
    rhs_slice_target = (object_ptr)&_8312;
    RHS_Slice(_8309, 2, _8311);
    _8309 = NOVALUE;
    _0 = _cmdex_14754;
    _cmdex_14754 = _23split(_8312, 32, 1, 0);
    DeRef(_0);
    _8312 = NOVALUE;

    /** 					at_cmds = replace(at_cmds, cmdex, j)*/
    {
        int p1 = _at_cmds_14668;
        int p2 = _cmdex_14754;
        int p3 = _j_14669;
        int p4 = _j_14669;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_at_cmds_14668;
        Replace( &replace_params );
    }

    /** 					j = j + length(cmdex) - 1*/
    if (IS_SEQUENCE(_cmdex_14754)){
            _8315 = SEQ_PTR(_cmdex_14754)->length;
    }
    else {
        _8315 = 1;
    }
    _8316 = _j_14669 + _8315;
    if ((long)((unsigned long)_8316 + (unsigned long)HIGH_BITS) >= 0) 
    _8316 = NewDouble((double)_8316);
    _8315 = NOVALUE;
    if (IS_ATOM_INT(_8316)) {
        _j_14669 = _8316 - 1;
    }
    else {
        _j_14669 = NewDouble(DBL_PTR(_8316)->dbl - (double)1);
    }
    DeRef(_8316);
    _8316 = NOVALUE;
    if (!IS_ATOM_INT(_j_14669)) {
        _1 = (long)(DBL_PTR(_j_14669)->dbl);
        DeRefDS(_j_14669);
        _j_14669 = _1;
    }
L23: 
    DeRef(_cmdex_14754);
    _cmdex_14754 = NOVALUE;

    /** 			end while*/
    goto L1C; // [1071] 748
L1D: 

    /** 			cmds = replace(cmds, at_cmds, arg_idx)*/
    {
        int p1 = _cmds_14557;
        int p2 = _at_cmds_14668;
        int p3 = _arg_idx_14559;
        int p4 = _arg_idx_14559;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_cmds_14557;
        Replace( &replace_params );
    }

    /** 			arg_idx -= 1*/
    _arg_idx_14559 = _arg_idx_14559 - 1;

    /** 			continue*/
    DeRef(_at_cmds_14668);
    _at_cmds_14668 = NOVALUE;
    goto L12; // [1092] 532
L15: 
    DeRef(_at_cmds_14668);
    _at_cmds_14668 = NOVALUE;

    /** 		if (opts_done or find(cmd[1], os:CMD_SWITCHES) = 0 or length(cmd) = 1)*/
    if (_opts_done_14560 != 0) {
        _8320 = 1;
        goto L24; // [1099] 1120
    }
    _2 = (int)SEQ_PTR(_cmd_14561);
    _8321 = (int)*(((s1_ptr)_2)->base + 1);
    _8322 = find_from(_8321, _34CMD_SWITCHES_13763, 1);
    _8321 = NOVALUE;
    _8323 = (_8322 == 0);
    _8322 = NOVALUE;
    _8320 = (_8323 != 0);
L24: 
    if (_8320 != 0) {
        DeRef(_8324);
        _8324 = 1;
        goto L25; // [1120] 1135
    }
    if (IS_SEQUENCE(_cmd_14561)){
            _8325 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8325 = 1;
    }
    _8326 = (_8325 == 1);
    _8325 = NOVALUE;
    _8324 = (_8326 != 0);
L25: 
    if (_8324 == 0)
    {
        _8324 = NOVALUE;
        goto L26; // [1135] 1215
    }
    else{
        _8324 = NOVALUE;
    }

    /** 			map:put(parsed_opts, EXTRAS, cmd, map:APPEND)*/
    Ref(_parsed_opts_14621);
    RefDS(_4EXTRAS_13858);
    RefDS(_cmd_14561);
    _28put(_parsed_opts_14621, _4EXTRAS_13858, _cmd_14561, 6, 23);

    /** 			has_extra = 1*/
    _has_extra_14570 = 1;

    /** 			if validation = NO_VALIDATION_AFTER_FIRST_EXTRA then*/
    if (_validation_14569 != 4)
    goto L12; // [1158] 532

    /** 				for i = arg_idx + 1 to length(cmds) do*/
    _8328 = _arg_idx_14559 + 1;
    if (_8328 > MAXINT){
        _8328 = NewDouble((double)_8328);
    }
    if (IS_SEQUENCE(_cmds_14557)){
            _8329 = SEQ_PTR(_cmds_14557)->length;
    }
    else {
        _8329 = 1;
    }
    {
        int _i_14777;
        Ref(_8328);
        _i_14777 = _8328;
L27: 
        if (binary_op_a(GREATER, _i_14777, _8329)){
            goto L28; // [1171] 1202
        }

        /** 					map:put(parsed_opts, EXTRAS, cmds[i], map:APPEND)*/
        _2 = (int)SEQ_PTR(_cmds_14557);
        if (!IS_ATOM_INT(_i_14777)){
            _8330 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_14777)->dbl));
        }
        else{
            _8330 = (int)*(((s1_ptr)_2)->base + _i_14777);
        }
        Ref(_parsed_opts_14621);
        RefDS(_4EXTRAS_13858);
        Ref(_8330);
        _28put(_parsed_opts_14621, _4EXTRAS_13858, _8330, 6, 23);
        _8330 = NOVALUE;

        /** 				end for*/
        _0 = _i_14777;
        if (IS_ATOM_INT(_i_14777)) {
            _i_14777 = _i_14777 + 1;
            if ((long)((unsigned long)_i_14777 +(unsigned long) HIGH_BITS) >= 0){
                _i_14777 = NewDouble((double)_i_14777);
            }
        }
        else {
            _i_14777 = binary_op_a(PLUS, _i_14777, 1);
        }
        DeRef(_0);
        goto L27; // [1197] 1178
L28: 
        ;
        DeRef(_i_14777);
    }

    /** 				exit*/
    goto L13; // [1204] 2072
    goto L29; // [1206] 1214

    /** 				continue*/
    goto L12; // [1211] 532
L29: 
L26: 

    /** 		if equal(cmd, "--") then*/
    if (_cmd_14561 == _7016)
    _8331 = 1;
    else if (IS_ATOM_INT(_cmd_14561) && IS_ATOM_INT(_7016))
    _8331 = 0;
    else
    _8331 = (compare(_cmd_14561, _7016) == 0);
    if (_8331 == 0)
    {
        _8331 = NOVALUE;
        goto L2A; // [1221] 1234
    }
    else{
        _8331 = NOVALUE;
    }

    /** 			opts_done = 1*/
    _opts_done_14560 = 1;

    /** 			continue*/
    goto L12; // [1231] 532
L2A: 

    /** 		if equal(cmd[1..2], "--") then	  -- found --opt-name*/
    rhs_slice_target = (object_ptr)&_8332;
    RHS_Slice(_cmd_14561, 1, 2);
    if (_8332 == _7016)
    _8333 = 1;
    else if (IS_ATOM_INT(_8332) && IS_ATOM_INT(_7016))
    _8333 = 0;
    else
    _8333 = (compare(_8332, _7016) == 0);
    DeRefDS(_8332);
    _8332 = NOVALUE;
    if (_8333 == 0)
    {
        _8333 = NOVALUE;
        goto L2B; // [1245] 1262
    }
    else{
        _8333 = NOVALUE;
    }

    /** 			type_ = {LONGNAME, "--"}*/
    RefDS(_7016);
    DeRef(_type__14564);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = _7016;
    _type__14564 = MAKE_SEQ(_1);

    /** 			from_ = 3*/
    _from__14565 = 3;
    goto L2C; // [1259] 1298
L2B: 

    /** 		elsif cmd[1] = '-' then -- found -opt*/
    _2 = (int)SEQ_PTR(_cmd_14561);
    _8335 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8335, 45)){
        _8335 = NOVALUE;
        goto L2D; // [1268] 1286
    }
    _8335 = NOVALUE;

    /** 			type_ = {SHORTNAME, "-"}*/
    RefDS(_6992);
    DeRef(_type__14564);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _6992;
    _type__14564 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__14565 = 2;
    goto L2C; // [1283] 1298
L2D: 

    /** 			type_ = {SHORTNAME, "/"}*/
    RefDS(_3072);
    DeRef(_type__14564);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _3072;
    _type__14564 = MAKE_SEQ(_1);

    /** 			from_ = 2*/
    _from__14565 = 2;
L2C: 

    /** 		if find(cmd[from_..$], help_opts) then*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8339 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8339 = 1;
    }
    rhs_slice_target = (object_ptr)&_8340;
    RHS_Slice(_cmd_14561, _from__14565, _8339);
    _8341 = find_from(_8340, _help_opts_14566, 1);
    DeRefDS(_8340);
    _8340 = NOVALUE;
    if (_8341 == 0)
    {
        _8341 = NOVALUE;
        goto L2E; // [1315] 1335
    }
    else{
        _8341 = NOVALUE;
    }

    /** 				local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14555);
    RefDS(_cmds_14557);
    Ref(_parse_options_14556);
    _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);

    /** 			ifdef UNITTEST then*/

    /** 			local_abort(0)*/
    _4local_abort(0);
L2E: 

    /** 		find_result = find_opt(opts, type_, cmd[from_..$])*/
    if (IS_SEQUENCE(_cmd_14561)){
            _8342 = SEQ_PTR(_cmd_14561)->length;
    }
    else {
        _8342 = 1;
    }
    rhs_slice_target = (object_ptr)&_8343;
    RHS_Slice(_cmd_14561, _from__14565, _8342);
    RefDS(_opts_14555);
    RefDS(_type__14564);
    _0 = _find_result_14563;
    _find_result_14563 = _4find_opt(_opts_14555, _type__14564, _8343);
    DeRef(_0);
    _8343 = NOVALUE;

    /** 		if find_result[1] < 0 then*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8345 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _8345, 0)){
        _8345 = NOVALUE;
        goto L2F; // [1361] 1370
    }
    _8345 = NOVALUE;

    /** 			continue -- Couldn't use this command argument for anything.*/
    goto L12; // [1367] 532
L2F: 

    /** 		if find_result[1] = 0 then*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8347 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _8347, 0)){
        _8347 = NOVALUE;
        goto L30; // [1376] 1471
    }
    _8347 = NOVALUE;

    /** 			if validation = VALIDATE_ALL or*/
    _8349 = (_validation_14569 == 2);
    if (_8349 != 0) {
        goto L31; // [1386] 1411
    }
    _8351 = (_validation_14569 == 4);
    if (_8351 == 0) {
        DeRef(_8352);
        _8352 = 0;
        goto L32; // [1394] 1406
    }
    _8353 = (_has_extra_14570 == 0);
    _8352 = (_8353 != 0);
L32: 
    if (_8352 == 0)
    {
        _8352 = NOVALUE;
        goto L12; // [1407] 532
    }
    else{
        _8352 = NOVALUE;
    }
L31: 

    /** 				printf(1, "option '%s': %s\n", {cmd, find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8355 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8355);
    RefDS(_cmd_14561);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _cmd_14561;
    ((int *)_2)[2] = _8355;
    _8356 = MAKE_SEQ(_1);
    _8355 = NOVALUE;
    EPrintf(1, _8354, _8356);
    DeRefDS(_8356);
    _8356 = NOVALUE;

    /** 				if help_on_error then*/
    if (_help_on_error_14573 == 0)
    {
        goto L33; // [1427] 1447
    }
    else{
    }

    /** 					puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 					local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14555);
    RefDS(_cmds_14557);
    Ref(_parse_options_14556);
    _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
    goto L34; // [1444] 1460
L33: 

    /** 				elsif auto_help then*/
    if (_auto_help_14572 == 0)
    {
        goto L35; // [1449] 1459
    }
    else{
    }

    /** 					printf(2,"Try '--help' for more information.\n",{})               */
    EPrintf(2, _8255, _5);
L35: 
L34: 

    /** 				local_abort(1)*/
    _4local_abort(1);

    /** 			continue*/
    goto L12; // [1468] 532
L30: 

    /** 		sequence opt = opts[find_result[1]]*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8357 = (int)*(((s1_ptr)_2)->base + 1);
    DeRef(_opt_14818);
    _2 = (int)SEQ_PTR(_opts_14555);
    if (!IS_ATOM_INT(_8357)){
        _opt_14818 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_8357)->dbl));
    }
    else{
        _opt_14818 = (int)*(((s1_ptr)_2)->base + _8357);
    }
    Ref(_opt_14818);

    /** 		integer map_add_operation = map:ADD*/
    _map_add_operation_14821 = 2;

    /** 		if find(HAS_PARAMETER, opt[OPTIONS]) != 0 then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8359 = (int)*(((s1_ptr)_2)->base + 4);
    _8360 = find_from(112, _8359, 1);
    _8359 = NOVALUE;
    if (_8360 == 0)
    goto L36; // [1499] 1677

    /** 			map_add_operation = map:APPEND*/
    _map_add_operation_14821 = 6;

    /** 			if length(find_result) < 4 then*/
    if (IS_SEQUENCE(_find_result_14563)){
            _8362 = SEQ_PTR(_find_result_14563)->length;
    }
    else {
        _8362 = 1;
    }
    if (_8362 >= 4)
    goto L37; // [1513] 1667

    /** 				arg_idx += 1*/
    _arg_idx_14559 = _arg_idx_14559 + 1;

    /** 				if arg_idx <= length(cmds) then*/
    if (IS_SEQUENCE(_cmds_14557)){
            _8365 = SEQ_PTR(_cmds_14557)->length;
    }
    else {
        _8365 = 1;
    }
    if (_arg_idx_14559 > _8365)
    goto L38; // [1528] 1573

    /** 					param = cmds[arg_idx]*/
    DeRef(_param_14562);
    _2 = (int)SEQ_PTR(_cmds_14557);
    _param_14562 = (int)*(((s1_ptr)_2)->base + _arg_idx_14559);
    Ref(_param_14562);

    /** 					if length(param) = 2 and find(param[1], "-/") then*/
    if (IS_SEQUENCE(_param_14562)){
            _8368 = SEQ_PTR(_param_14562)->length;
    }
    else {
        _8368 = 1;
    }
    _8369 = (_8368 == 2);
    _8368 = NOVALUE;
    if (_8369 == 0) {
        goto L39; // [1547] 1579
    }
    _2 = (int)SEQ_PTR(_param_14562);
    _8371 = (int)*(((s1_ptr)_2)->base + 1);
    _8372 = find_from(_8371, _7669, 1);
    _8371 = NOVALUE;
    if (_8372 == 0)
    {
        _8372 = NOVALUE;
        goto L39; // [1561] 1579
    }
    else{
        _8372 = NOVALUE;
    }

    /** 						param = ""*/
    RefDS(_5);
    DeRef(_param_14562);
    _param_14562 = _5;
    goto L39; // [1570] 1579
L38: 

    /** 					param = ""*/
    RefDS(_5);
    DeRef(_param_14562);
    _param_14562 = _5;
L39: 

    /** 				if length(param) = 0 and (validation = VALIDATE_ALL or (*/
    if (IS_SEQUENCE(_param_14562)){
            _8373 = SEQ_PTR(_param_14562)->length;
    }
    else {
        _8373 = 1;
    }
    _8374 = (_8373 == 0);
    _8373 = NOVALUE;
    if (_8374 == 0) {
        goto L3A; // [1590] 1684
    }
    _8376 = (_validation_14569 == 2);
    if (_8376 != 0) {
        DeRef(_8377);
        _8377 = 1;
        goto L3B; // [1598] 1610
    }
    _8378 = (_validation_14569 == 4);
    _8377 = (_8378 != 0);
L3B: 
    if (_8377 == 0)
    {
        _8377 = NOVALUE;
        goto L3A; // [1611] 1684
    }
    else{
        _8377 = NOVALUE;
    }

    /** 					printf(1, "option '%s' must have a parameter\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8380 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8380);
    *((int *)(_2+4)) = _8380;
    _8381 = MAKE_SEQ(_1);
    _8380 = NOVALUE;
    EPrintf(1, _8379, _8381);
    DeRefDS(_8381);
    _8381 = NOVALUE;

    /** 					if help_on_error then*/
    if (_help_on_error_14573 == 0)
    {
        goto L3C; // [1630] 1645
    }
    else{
    }

    /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14555);
    RefDS(_cmds_14557);
    Ref(_parse_options_14556);
    _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
    goto L3D; // [1642] 1658
L3C: 

    /** 					elsif auto_help then*/
    if (_auto_help_14572 == 0)
    {
        goto L3E; // [1647] 1657
    }
    else{
    }

    /** 						printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8255, _5);
L3E: 
L3D: 

    /** 					local_abort(1)*/
    _4local_abort(1);
    goto L3A; // [1664] 1684
L37: 

    /** 				param = find_result[4]*/
    DeRef(_param_14562);
    _2 = (int)SEQ_PTR(_find_result_14563);
    _param_14562 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_14562);
    goto L3A; // [1674] 1684
L36: 

    /** 			param = find_result[4]*/
    DeRef(_param_14562);
    _2 = (int)SEQ_PTR(_find_result_14563);
    _param_14562 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_param_14562);
L3A: 

    /** 		if opt[CALLBACK] >= 0 then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8384 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESS, _8384, 0)){
        _8384 = NOVALUE;
        goto L3F; // [1690] 1763
    }
    _8384 = NOVALUE;

    /** 			integer pos = find_result[1]*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _pos_14860 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_pos_14860))
    _pos_14860 = (long)DBL_PTR(_pos_14860)->dbl;

    /** 			call_count[pos] += 1*/
    _2 = (int)SEQ_PTR(_call_count_14567);
    _8387 = (int)*(((s1_ptr)_2)->base + _pos_14860);
    if (IS_ATOM_INT(_8387)) {
        _8388 = _8387 + 1;
        if (_8388 > MAXINT){
            _8388 = NewDouble((double)_8388);
        }
    }
    else
    _8388 = binary_op(PLUS, 1, _8387);
    _8387 = NOVALUE;
    _2 = (int)SEQ_PTR(_call_count_14567);
    _2 = (int)(((s1_ptr)_2)->base + _pos_14860);
    _1 = *(int *)_2;
    *(int *)_2 = _8388;
    if( _1 != _8388 ){
        DeRef(_1);
    }
    _8388 = NOVALUE;

    /** 			if call_func(opt[CALLBACK], {{find_result[1], call_count[pos], param,  find_result[3]}}) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8389 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8390 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_call_count_14567);
    _8391 = (int)*(((s1_ptr)_2)->base + _pos_14860);
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8392 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8390);
    *((int *)(_2+4)) = _8390;
    Ref(_8391);
    *((int *)(_2+8)) = _8391;
    Ref(_param_14562);
    *((int *)(_2+12)) = _param_14562;
    Ref(_8392);
    *((int *)(_2+16)) = _8392;
    _8393 = MAKE_SEQ(_1);
    _8392 = NOVALUE;
    _8391 = NOVALUE;
    _8390 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _8393;
    _8394 = MAKE_SEQ(_1);
    _8393 = NOVALUE;
    _1 = (int)SEQ_PTR(_8394);
    _2 = (int)((s1_ptr)_1)->base;
    _0 = (int)_00[_8389].addr;
    Ref(*(int *)(_2+4));
    _1 = (*(int (*)())_0)(
                        *(int *)(_2+4)
                         );
    DeRef(_8395);
    _8395 = _1;
    DeRefDS(_8394);
    _8394 = NOVALUE;
    if (binary_op_a(NOTEQ, _8395, 0)){
        DeRef(_8395);
        _8395 = NOVALUE;
        goto L40; // [1749] 1762
    }
    DeRef(_8395);
    _8395 = NOVALUE;

    /** 				continue*/
    DeRefDS(_opt_14818);
    _opt_14818 = NOVALUE;
    goto L12; // [1759] 532
L40: 
L3F: 

    /** 		if find_result[3] = 1 then*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8397 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _8397, 1)){
        _8397 = NOVALUE;
        goto L41; // [1771] 1788
    }
    _8397 = NOVALUE;

    /** 			map:remove(parsed_opts, opt[MAPNAME])*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8399 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14621);
    Ref(_8399);
    _28remove(_parsed_opts_14621, _8399);
    _8399 = NOVALUE;
    goto L42; // [1785] 1965
L41: 

    /** 			if find(MULTIPLE, opt[OPTIONS]) = 0 then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8400 = (int)*(((s1_ptr)_2)->base + 4);
    _8401 = find_from(42, _8400, 1);
    _8400 = NOVALUE;
    if (_8401 != 0)
    goto L43; // [1799] 1946

    /** 				if map:has(parsed_opts, opt[MAPNAME]) and (validation = VALIDATE_ALL or*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8403 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14621);
    Ref(_8403);
    _8404 = _28has(_parsed_opts_14621, _8403);
    _8403 = NOVALUE;
    if (IS_ATOM_INT(_8404)) {
        if (_8404 == 0) {
            goto L44; // [1814] 1925
        }
    }
    else {
        if (DBL_PTR(_8404)->dbl == 0.0) {
            goto L44; // [1814] 1925
        }
    }
    _8406 = (_validation_14569 == 2);
    if (_8406 != 0) {
        DeRef(_8407);
        _8407 = 1;
        goto L45; // [1822] 1834
    }
    _8408 = (_validation_14569 == 4);
    _8407 = (_8408 != 0);
L45: 
    if (_8407 == 0)
    {
        _8407 = NOVALUE;
        goto L44; // [1835] 1925
    }
    else{
        _8407 = NOVALUE;
    }

    /** 					if find(HAS_PARAMETER, opt[OPTIONS]) or find(ONCE, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8409 = (int)*(((s1_ptr)_2)->base + 4);
    _8410 = find_from(112, _8409, 1);
    _8409 = NOVALUE;
    if (_8410 != 0) {
        goto L46; // [1849] 1867
    }
    _2 = (int)SEQ_PTR(_opt_14818);
    _8412 = (int)*(((s1_ptr)_2)->base + 4);
    _8413 = find_from(49, _8412, 1);
    _8412 = NOVALUE;
    if (_8413 == 0)
    {
        _8413 = NOVALUE;
        goto L47; // [1863] 1964
    }
    else{
        _8413 = NOVALUE;
    }
L46: 

    /** 						printf(1, "option '%s' must not occur more than once in the command line.\n", {find_result[2]})*/
    _2 = (int)SEQ_PTR(_find_result_14563);
    _8415 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8415);
    *((int *)(_2+4)) = _8415;
    _8416 = MAKE_SEQ(_1);
    _8415 = NOVALUE;
    EPrintf(1, _8414, _8416);
    DeRefDS(_8416);
    _8416 = NOVALUE;

    /** 						if help_on_error then*/
    if (_help_on_error_14573 == 0)
    {
        goto L48; // [1883] 1903
    }
    else{
    }

    /** 							puts(2,10)*/
    EPuts(2, 10); // DJP 

    /** 							local_help(opts, add_help_rid, cmds, 1, parse_options)*/
    RefDS(_opts_14555);
    RefDS(_cmds_14557);
    Ref(_parse_options_14556);
    _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
    goto L49; // [1900] 1916
L48: 

    /** 						elsif auto_help then*/
    if (_auto_help_14572 == 0)
    {
        goto L4A; // [1905] 1915
    }
    else{
    }

    /** 							printf(2,"Try '--help' for more information.\n",{})          */
    EPrintf(2, _8255, _5);
L4A: 
L49: 

    /** 						local_abort(1)*/
    _4local_abort(1);
    goto L47; // [1922] 1964
L44: 

    /** 					map:put(parsed_opts, opt[MAPNAME], param)*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8417 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14621);
    Ref(_8417);
    Ref(_param_14562);
    _28put(_parsed_opts_14621, _8417, _param_14562, 1, 23);
    _8417 = NOVALUE;
    goto L47; // [1943] 1964
L43: 

    /** 				map:put(parsed_opts, opt[MAPNAME], param, map_add_operation)*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8418 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_parsed_opts_14621);
    Ref(_8418);
    Ref(_param_14562);
    _28put(_parsed_opts_14621, _8418, _param_14562, _map_add_operation_14821, 23);
    _8418 = NOVALUE;
L47: 
L42: 

    /**         if find(VERSIONING, opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8419 = (int)*(((s1_ptr)_2)->base + 4);
    _8420 = find_from(118, _8419, 1);
    _8419 = NOVALUE;
    if (_8420 == 0)
    {
        _8420 = NOVALUE;
        goto L4B; // [1976] 2063
    }
    else{
        _8420 = NOVALUE;
    }

    /**             integer ver_pos = find(VERSIONING, opt[OPTIONS]) + 1*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8421 = (int)*(((s1_ptr)_2)->base + 4);
    _8422 = find_from(118, _8421, 1);
    _8421 = NOVALUE;
    _ver_pos_14907 = _8422 + 1;
    _8422 = NOVALUE;

    /**             if length(opt[OPTIONS]) >= ver_pos then*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8424 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_8424)){
            _8425 = SEQ_PTR(_8424)->length;
    }
    else {
        _8425 = 1;
    }
    _8424 = NOVALUE;
    if (_8425 < _ver_pos_14907)
    goto L4C; // [2003] 2032

    /**                 printf(1, "%s\n", { opt[OPTIONS][ver_pos] })*/
    _2 = (int)SEQ_PTR(_opt_14818);
    _8428 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_8428);
    _8429 = (int)*(((s1_ptr)_2)->base + _ver_pos_14907);
    _8428 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_8429);
    *((int *)(_2+4)) = _8429;
    _8430 = MAKE_SEQ(_1);
    _8429 = NOVALUE;
    EPrintf(1, _8427, _8430);
    DeRefDS(_8430);
    _8430 = NOVALUE;

    /**                 abort(0)*/
    UserCleanup(0);
    goto L4D; // [2029] 2062
L4C: 

    /**                 error:crash("help options are incorrect,\n" &*/
    Concat((object_ptr)&_8433, _8431, _8432);
    DeRefi(_fmt_inlined_crash_at_2037_14924);
    _fmt_inlined_crash_at_2037_14924 = _8433;
    _8433 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_2040_14925);
    _msg_inlined_crash_at_2040_14925 = EPrintf(-9999999, _fmt_inlined_crash_at_2037_14924, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_2040_14925);

    /** end procedure*/
    goto L4E; // [2056] 2059
L4E: 
    DeRefi(_fmt_inlined_crash_at_2037_14924);
    _fmt_inlined_crash_at_2037_14924 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_2040_14925);
    _msg_inlined_crash_at_2040_14925 = NOVALUE;
L4D: 
L4B: 
    DeRef(_opt_14818);
    _opt_14818 = NOVALUE;

    /** 	end while*/
    goto L12; // [2069] 532
L13: 

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_14555)){
            _8434 = SEQ_PTR(_opts_14555)->length;
    }
    else {
        _8434 = 1;
    }
    {
        int _i_14927;
        _i_14927 = 1;
L4F: 
        if (_i_14927 > _8434){
            goto L50; // [2077] 2292
        }

        /** 		if find(MANDATORY, opts[i][OPTIONS]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8435 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8435);
        _8436 = (int)*(((s1_ptr)_2)->base + 4);
        _8435 = NOVALUE;
        _8437 = find_from(109, _8436, 1);
        _8436 = NOVALUE;
        if (_8437 == 0)
        {
            _8437 = NOVALUE;
            goto L51; // [2099] 2285
        }
        else{
            _8437 = NOVALUE;
        }

        /** 			if atom(opts[i][SHORTNAME]) and atom(opts[i][LONGNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8438 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8438);
        _8439 = (int)*(((s1_ptr)_2)->base + 1);
        _8438 = NOVALUE;
        _8440 = IS_ATOM(_8439);
        _8439 = NOVALUE;
        if (_8440 == 0) {
            goto L52; // [2115] 2206
        }
        _2 = (int)SEQ_PTR(_opts_14555);
        _8442 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8442);
        _8443 = (int)*(((s1_ptr)_2)->base + 2);
        _8442 = NOVALUE;
        _8444 = IS_ATOM(_8443);
        _8443 = NOVALUE;
        if (_8444 == 0)
        {
            _8444 = NOVALUE;
            goto L52; // [2131] 2206
        }
        else{
            _8444 = NOVALUE;
        }

        /** 				if length(map:get(parsed_opts, opts[i][MAPNAME])) = 0 then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8445 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8445);
        _8446 = (int)*(((s1_ptr)_2)->base + 6);
        _8445 = NOVALUE;
        Ref(_parsed_opts_14621);
        Ref(_8446);
        _8447 = _28get(_parsed_opts_14621, _8446, 0);
        _8446 = NOVALUE;
        if (IS_SEQUENCE(_8447)){
                _8448 = SEQ_PTR(_8447)->length;
        }
        else {
            _8448 = 1;
        }
        DeRef(_8447);
        _8447 = NOVALUE;
        if (_8448 != 0)
        goto L53; // [2153] 2284

        /** 					puts(1, "Additional arguments were expected.\n")*/
        EPuts(1, _8450); // DJP 

        /** 					if help_on_error then*/
        if (_help_on_error_14573 == 0)
        {
            goto L54; // [2164] 2184
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_14555);
        RefDS(_cmds_14557);
        Ref(_parse_options_14556);
        _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
        goto L55; // [2181] 2197
L54: 

        /** 					elsif auto_help then*/
        if (_auto_help_14572 == 0)
        {
            goto L56; // [2186] 2196
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8255, _5);
L56: 
L55: 

        /** 					local_abort(1)*/
        _4local_abort(1);
        goto L53; // [2203] 2284
L52: 

        /** 				if not map:has(parsed_opts, opts[i][MAPNAME]) then*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8451 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8451);
        _8452 = (int)*(((s1_ptr)_2)->base + 6);
        _8451 = NOVALUE;
        Ref(_parsed_opts_14621);
        Ref(_8452);
        _8453 = _28has(_parsed_opts_14621, _8452);
        _8452 = NOVALUE;
        if (IS_ATOM_INT(_8453)) {
            if (_8453 != 0){
                DeRef(_8453);
                _8453 = NOVALUE;
                goto L57; // [2221] 2283
            }
        }
        else {
            if (DBL_PTR(_8453)->dbl != 0.0){
                DeRef(_8453);
                _8453 = NOVALUE;
                goto L57; // [2221] 2283
            }
        }
        DeRef(_8453);
        _8453 = NOVALUE;

        /** 					printf(1, "option '%s' is mandatory but was not supplied.\n", {opts[i][MAPNAME]})*/
        _2 = (int)SEQ_PTR(_opts_14555);
        _8456 = (int)*(((s1_ptr)_2)->base + _i_14927);
        _2 = (int)SEQ_PTR(_8456);
        _8457 = (int)*(((s1_ptr)_2)->base + 6);
        _8456 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_8457);
        *((int *)(_2+4)) = _8457;
        _8458 = MAKE_SEQ(_1);
        _8457 = NOVALUE;
        EPrintf(1, _8455, _8458);
        DeRefDS(_8458);
        _8458 = NOVALUE;

        /** 					if help_on_error then*/
        if (_help_on_error_14573 == 0)
        {
            goto L58; // [2244] 2264
        }
        else{
        }

        /** 						puts(2,10)*/
        EPuts(2, 10); // DJP 

        /** 						local_help(opts, add_help_rid, cmds, 1, parse_options)*/
        RefDS(_opts_14555);
        RefDS(_cmds_14557);
        Ref(_parse_options_14556);
        _4local_help(_opts_14555, _add_help_rid_14568, _cmds_14557, 1, _parse_options_14556);
        goto L59; // [2261] 2277
L58: 

        /** 					elsif auto_help then*/
        if (_auto_help_14572 == 0)
        {
            goto L5A; // [2266] 2276
        }
        else{
        }

        /** 						printf(2,"Try '--help' for more information.\n",{})          */
        EPrintf(2, _8255, _5);
L5A: 
L59: 

        /** 					local_abort(1)*/
        _4local_abort(1);
L57: 
L53: 
L51: 

        /** 	end for*/
        _i_14927 = _i_14927 + 1;
        goto L4F; // [2287] 2084
L50: 
        ;
    }

    /** 	return parsed_opts*/
    DeRefDS(_opts_14555);
    DeRefi(_parse_options_14556);
    DeRefDS(_cmds_14557);
    DeRef(_cmd_14561);
    DeRef(_param_14562);
    DeRef(_find_result_14563);
    DeRef(_type__14564);
    DeRef(_help_opts_14566);
    DeRef(_call_count_14567);
    DeRef(_8295);
    _8295 = NOVALUE;
    DeRef(_8404);
    _8404 = NOVALUE;
    DeRef(_8351);
    _8351 = NOVALUE;
    DeRef(_8323);
    _8323 = NOVALUE;
    DeRef(_8406);
    _8406 = NOVALUE;
    _8389 = NOVALUE;
    _8261 = NOVALUE;
    DeRef(_8276);
    _8276 = NOVALUE;
    DeRef(_8326);
    _8326 = NOVALUE;
    DeRef(_8274);
    _8274 = NOVALUE;
    DeRef(_8288);
    _8288 = NOVALUE;
    DeRef(_8237);
    _8237 = NOVALUE;
    _8290 = NOVALUE;
    DeRef(_8266);
    _8266 = NOVALUE;
    DeRef(_8374);
    _8374 = NOVALUE;
    DeRef(_8408);
    _8408 = NOVALUE;
    DeRef(_8304);
    _8304 = NOVALUE;
    DeRef(_8353);
    _8353 = NOVALUE;
    DeRef(_8378);
    _8378 = NOVALUE;
    DeRef(_8299);
    _8299 = NOVALUE;
    DeRef(_8234);
    _8234 = NOVALUE;
    _8357 = NOVALUE;
    DeRef(_8376);
    _8376 = NOVALUE;
    DeRef(_8369);
    _8369 = NOVALUE;
    _8447 = NOVALUE;
    DeRef(_8311);
    _8311 = NOVALUE;
    DeRef(_8283);
    _8283 = NOVALUE;
    DeRef(_8328);
    _8328 = NOVALUE;
    _8424 = NOVALUE;
    DeRef(_8349);
    _8349 = NOVALUE;
    _8306 = NOVALUE;
    DeRef(_8264);
    _8264 = NOVALUE;
    return _parsed_opts_14621;
    ;
}


int _4build_commandline(int _cmds_14964)
{
    int _8461 = NOVALUE;
    int _8460 = NOVALUE;
    int _8459 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return stdseq:flatten( text:quote( cmds,,'\\'," " ), " ")*/
    RefDS(_4798);
    RefDS(_4798);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4798;
    ((int *)_2)[2] = _4798;
    _8459 = MAKE_SEQ(_1);
    RefDS(_cmds_14964);
    RefDS(_2630);
    _8460 = _14quote(_cmds_14964, _8459, 92, _2630);
    _8459 = NOVALUE;
    RefDS(_2630);
    _8461 = _23flatten(_8460, _2630);
    _8460 = NOVALUE;
    DeRefDS(_cmds_14964);
    return _8461;
    ;
}



// 0x1AE689C4
