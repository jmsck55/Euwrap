// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _25qmatch(int _p_5735, int _s_5736)
{
    int _k_5737 = NOVALUE;
    int _3000 = NOVALUE;
    int _2999 = NOVALUE;
    int _2998 = NOVALUE;
    int _2997 = NOVALUE;
    int _2996 = NOVALUE;
    int _2995 = NOVALUE;
    int _2994 = NOVALUE;
    int _2993 = NOVALUE;
    int _2992 = NOVALUE;
    int _2991 = NOVALUE;
    int _2990 = NOVALUE;
    int _2989 = NOVALUE;
    int _2987 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find('?', p) then*/
    _2987 = find_from(63, _p_5735, 1);
    if (_2987 != 0)
    goto L1; // [12] 27
    _2987 = NOVALUE;

    /** 		return match(p, s) -- fast*/
    _2989 = e_match_from(_p_5735, _s_5736, 1);
    DeRefDS(_p_5735);
    DeRefDS(_s_5736);
    return _2989;
L1: 

    /** 	for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_5736)){
            _2990 = SEQ_PTR(_s_5736)->length;
    }
    else {
        _2990 = 1;
    }
    if (IS_SEQUENCE(_p_5735)){
            _2991 = SEQ_PTR(_p_5735)->length;
    }
    else {
        _2991 = 1;
    }
    _2992 = _2990 - _2991;
    _2990 = NOVALUE;
    _2991 = NOVALUE;
    _2993 = _2992 + 1;
    _2992 = NOVALUE;
    {
        int _i_5743;
        _i_5743 = 1;
L2: 
        if (_i_5743 > _2993){
            goto L3; // [43] 142
        }

        /** 		k = i*/
        _k_5737 = _i_5743;

        /** 		for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_5735)){
                _2994 = SEQ_PTR(_p_5735)->length;
        }
        else {
            _2994 = 1;
        }
        {
            int _j_5749;
            _j_5749 = 1;
L4: 
            if (_j_5749 > _2994){
                goto L5; // [62] 122
            }

            /** 			if p[j] != s[k] and p[j] != '?' then*/
            _2 = (int)SEQ_PTR(_p_5735);
            _2995 = (int)*(((s1_ptr)_2)->base + _j_5749);
            _2 = (int)SEQ_PTR(_s_5736);
            _2996 = (int)*(((s1_ptr)_2)->base + _k_5737);
            if (IS_ATOM_INT(_2995) && IS_ATOM_INT(_2996)) {
                _2997 = (_2995 != _2996);
            }
            else {
                _2997 = binary_op(NOTEQ, _2995, _2996);
            }
            _2995 = NOVALUE;
            _2996 = NOVALUE;
            if (IS_ATOM_INT(_2997)) {
                if (_2997 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_2997)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (int)SEQ_PTR(_p_5735);
            _2999 = (int)*(((s1_ptr)_2)->base + _j_5749);
            if (IS_ATOM_INT(_2999)) {
                _3000 = (_2999 != 63);
            }
            else {
                _3000 = binary_op(NOTEQ, _2999, 63);
            }
            _2999 = NOVALUE;
            if (_3000 == 0) {
                DeRef(_3000);
                _3000 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_3000) && DBL_PTR(_3000)->dbl == 0.0){
                    DeRef(_3000);
                    _3000 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_3000);
                _3000 = NOVALUE;
            }
            DeRef(_3000);
            _3000 = NOVALUE;

            /** 				k = 0*/
            _k_5737 = 0;

            /** 				exit*/
            goto L5; // [106] 122
L6: 

            /** 			k += 1*/
            _k_5737 = _k_5737 + 1;

            /** 		end for*/
            _j_5749 = _j_5749 + 1;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** 		if k != 0 then*/
        if (_k_5737 == 0)
        goto L7; // [124] 135

        /** 			return i*/
        DeRefDS(_p_5735);
        DeRefDS(_s_5736);
        DeRef(_2993);
        _2993 = NOVALUE;
        DeRef(_2997);
        _2997 = NOVALUE;
        return _i_5743;
L7: 

        /** 	end for*/
        _i_5743 = _i_5743 + 1;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_p_5735);
    DeRefDS(_s_5736);
    DeRef(_2993);
    _2993 = NOVALUE;
    DeRef(_2997);
    _2997 = NOVALUE;
    return 0;
    ;
}


int _25is_match(int _pattern_5764, int _string_5765)
{
    int _p_5766 = NOVALUE;
    int _f_5767 = NOVALUE;
    int _t_5768 = NOVALUE;
    int _match_string_5769 = NOVALUE;
    int _3042 = NOVALUE;
    int _3041 = NOVALUE;
    int _3039 = NOVALUE;
    int _3035 = NOVALUE;
    int _3034 = NOVALUE;
    int _3033 = NOVALUE;
    int _3030 = NOVALUE;
    int _3029 = NOVALUE;
    int _3026 = NOVALUE;
    int _3023 = NOVALUE;
    int _3021 = NOVALUE;
    int _3019 = NOVALUE;
    int _3017 = NOVALUE;
    int _3014 = NOVALUE;
    int _3012 = NOVALUE;
    int _3010 = NOVALUE;
    int _3009 = NOVALUE;
    int _3008 = NOVALUE;
    int _3007 = NOVALUE;
    int _3005 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pattern = pattern & END_MARKER*/
    Append(&_pattern_5764, _pattern_5764, -1);

    /** 	string = string & END_MARKER*/
    Append(&_string_5765, _string_5765, -1);

    /** 	p = 1*/
    _p_5766 = 1;

    /** 	f = 1*/
    _f_5767 = 1;

    /** 	while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_5765)){
            _3005 = SEQ_PTR(_string_5765)->length;
    }
    else {
        _3005 = 1;
    }
    if (_f_5767 > _3005)
    goto L2; // [35] 288

    /** 		if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3007 = (int)*(((s1_ptr)_2)->base + _p_5766);
    _2 = (int)SEQ_PTR(_string_5765);
    _3008 = (int)*(((s1_ptr)_2)->base + _f_5767);
    Ref(_3008);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3008;
    ((int *)_2)[2] = 63;
    _3009 = MAKE_SEQ(_1);
    _3008 = NOVALUE;
    _3010 = find_from(_3007, _3009, 1);
    _3007 = NOVALUE;
    DeRefDS(_3009);
    _3009 = NOVALUE;
    if (_3010 != 0)
    goto L3; // [58] 248
    _3010 = NOVALUE;

    /** 			if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3012 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(NOTEQ, _3012, 42)){
        _3012 = NOVALUE;
        goto L4; // [67] 240
    }
    _3012 = NOVALUE;

    /** 				while pattern[p] = '*' do*/
L5: 
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3014 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(NOTEQ, _3014, 42)){
        _3014 = NOVALUE;
        goto L6; // [80] 95
    }
    _3014 = NOVALUE;

    /** 					p += 1*/
    _p_5766 = _p_5766 + 1;

    /** 				end while*/
    goto L5; // [92] 76
L6: 

    /** 				if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3017 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(NOTEQ, _3017, -1)){
        _3017 = NOVALUE;
        goto L7; // [101] 112
    }
    _3017 = NOVALUE;

    /** 					return 1*/
    DeRefDS(_pattern_5764);
    DeRefDS(_string_5765);
    DeRef(_match_string_5769);
    return 1;
L7: 

    /** 				match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_5769);
    _match_string_5769 = _5;

    /** 				while pattern[p] != '*' do*/
L8: 
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3019 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(EQUALS, _3019, 42)){
        _3019 = NOVALUE;
        goto L9; // [128] 168
    }
    _3019 = NOVALUE;

    /** 					match_string = match_string & pattern[p]*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3021 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (IS_SEQUENCE(_match_string_5769) && IS_ATOM(_3021)) {
        Ref(_3021);
        Append(&_match_string_5769, _match_string_5769, _3021);
    }
    else if (IS_ATOM(_match_string_5769) && IS_SEQUENCE(_3021)) {
    }
    else {
        Concat((object_ptr)&_match_string_5769, _match_string_5769, _3021);
    }
    _3021 = NOVALUE;

    /** 					if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3023 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(NOTEQ, _3023, -1)){
        _3023 = NOVALUE;
        goto LA; // [148] 157
    }
    _3023 = NOVALUE;

    /** 						exit*/
    goto L9; // [154] 168
LA: 

    /** 					p += 1*/
    _p_5766 = _p_5766 + 1;

    /** 				end while*/
    goto L8; // [165] 124
L9: 

    /** 				if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_5764);
    _3026 = (int)*(((s1_ptr)_2)->base + _p_5766);
    if (binary_op_a(NOTEQ, _3026, 42)){
        _3026 = NOVALUE;
        goto LB; // [174] 185
    }
    _3026 = NOVALUE;

    /** 					p -= 1*/
    _p_5766 = _p_5766 - 1;
LB: 

    /** 				t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_5765)){
            _3029 = SEQ_PTR(_string_5765)->length;
    }
    else {
        _3029 = 1;
    }
    rhs_slice_target = (object_ptr)&_3030;
    RHS_Slice(_string_5765, _f_5767, _3029);
    RefDS(_match_string_5769);
    _t_5768 = _25qmatch(_match_string_5769, _3030);
    _3030 = NOVALUE;
    if (!IS_ATOM_INT(_t_5768)) {
        _1 = (long)(DBL_PTR(_t_5768)->dbl);
        DeRefDS(_t_5768);
        _t_5768 = _1;
    }

    /** 				if t = 0 then*/
    if (_t_5768 != 0)
    goto LC; // [204] 217

    /** 					return 0*/
    DeRefDS(_pattern_5764);
    DeRefDS(_string_5765);
    DeRefDS(_match_string_5769);
    return 0;
    goto LD; // [214] 247
LC: 

    /** 					f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_5769)){
            _3033 = SEQ_PTR(_match_string_5769)->length;
    }
    else {
        _3033 = 1;
    }
    _3034 = _t_5768 + _3033;
    if ((long)((unsigned long)_3034 + (unsigned long)HIGH_BITS) >= 0) 
    _3034 = NewDouble((double)_3034);
    _3033 = NOVALUE;
    if (IS_ATOM_INT(_3034)) {
        _3035 = _3034 - 2;
        if ((long)((unsigned long)_3035 +(unsigned long) HIGH_BITS) >= 0){
            _3035 = NewDouble((double)_3035);
        }
    }
    else {
        _3035 = NewDouble(DBL_PTR(_3034)->dbl - (double)2);
    }
    DeRef(_3034);
    _3034 = NOVALUE;
    if (IS_ATOM_INT(_3035)) {
        _f_5767 = _f_5767 + _3035;
    }
    else {
        _f_5767 = NewDouble((double)_f_5767 + DBL_PTR(_3035)->dbl);
    }
    DeRef(_3035);
    _3035 = NOVALUE;
    if (!IS_ATOM_INT(_f_5767)) {
        _1 = (long)(DBL_PTR(_f_5767)->dbl);
        DeRefDS(_f_5767);
        _f_5767 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** 				return 0*/
    DeRefDS(_pattern_5764);
    DeRefDS(_string_5765);
    DeRef(_match_string_5769);
    return 0;
LD: 
L3: 

    /** 		p += 1*/
    _p_5766 = _p_5766 + 1;

    /** 		f += 1*/
    _f_5767 = _f_5767 + 1;

    /** 		if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_5764)){
            _3039 = SEQ_PTR(_pattern_5764)->length;
    }
    else {
        _3039 = 1;
    }
    if (_p_5766 <= _3039)
    goto L1; // [265] 32

    /** 			return f > length(string) */
    if (IS_SEQUENCE(_string_5765)){
            _3041 = SEQ_PTR(_string_5765)->length;
    }
    else {
        _3041 = 1;
    }
    _3042 = (_f_5767 > _3041);
    _3041 = NOVALUE;
    DeRefDS(_pattern_5764);
    DeRefDS(_string_5765);
    DeRef(_match_string_5769);
    return _3042;

    /** 	end while*/
    goto L1; // [285] 32
L2: 

    /** 	return 0*/
    DeRefDS(_pattern_5764);
    DeRefDS(_string_5765);
    DeRef(_match_string_5769);
    DeRef(_3042);
    _3042 = NOVALUE;
    return 0;
    ;
}



// 0xB9423766
