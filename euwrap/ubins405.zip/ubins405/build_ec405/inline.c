// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _67advance(int _pc_52239, int _code_52240)
{
    int _26938 = NOVALUE;
    int _26936 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prev_pc = pc*/
    _67prev_pc_52224 = _pc_52239;

    /** 	if pc > length( code ) then*/
    if (IS_SEQUENCE(_code_52240)){
            _26936 = SEQ_PTR(_code_52240)->length;
    }
    else {
        _26936 = 1;
    }
    if (_pc_52239 <= _26936)
    goto L1; // [15] 26

    /** 		return pc*/
    DeRefDS(_code_52240);
    return _pc_52239;
L1: 

    /** 	return shift:advance( pc, code )*/
    RefDS(_code_52240);
    _26938 = _65advance(_pc_52239, _code_52240);
    DeRefDS(_code_52240);
    return _26938;
    ;
}


void _67shift(int _start_52247, int _amount_52248, int _bound_52249)
{
    int _temp_LineTable_52250 = NOVALUE;
    int _temp_Code_52252 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_52248)) {
        _1 = (long)(DBL_PTR(_amount_52248)->dbl);
        DeRefDS(_amount_52248);
        _amount_52248 = _1;
    }

    /** 		temp_LineTable = LineTable,*/
    RefDS(_35LineTable_16057);
    DeRef(_temp_LineTable_52250);
    _temp_LineTable_52250 = _35LineTable_16057;

    /** 		temp_Code = Code*/
    RefDS(_35Code_16056);
    DeRef(_temp_Code_52252);
    _temp_Code_52252 = _35Code_16056;

    /** 	LineTable = {}*/
    RefDS(_21815);
    DeRefDS(_35LineTable_16057);
    _35LineTable_16057 = _21815;

    /** 	Code = inline_code*/
    RefDS(_67inline_code_52216);
    DeRefDS(_35Code_16056);
    _35Code_16056 = _67inline_code_52216;

    /** 	inline_code = {}*/
    RefDS(_21815);
    DeRefDS(_67inline_code_52216);
    _67inline_code_52216 = _21815;

    /** 	shift:shift( start, amount, bound )*/
    _65shift(_start_52247, _amount_52248, _bound_52249);

    /** 	LineTable = temp_LineTable*/
    RefDS(_temp_LineTable_52250);
    DeRefDS(_35LineTable_16057);
    _35LineTable_16057 = _temp_LineTable_52250;

    /** 	inline_code = Code*/
    RefDS(_35Code_16056);
    DeRefDS(_67inline_code_52216);
    _67inline_code_52216 = _35Code_16056;

    /** 	Code = temp_Code*/
    RefDS(_temp_Code_52252);
    DeRefDS(_35Code_16056);
    _35Code_16056 = _temp_Code_52252;

    /** end procedure*/
    DeRefDS(_temp_LineTable_52250);
    DeRefDS(_temp_Code_52252);
    return;
    ;
}


void _67insert_code(int _code_52261, int _index_52262)
{
    int _26940 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_52262)) {
        _1 = (long)(DBL_PTR(_index_52262)->dbl);
        DeRefDS(_index_52262);
        _index_52262 = _1;
    }

    /** 	inline_code = splice( inline_code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_52262;
        if (insert_pos <= 0) {
            Concat(&_67inline_code_52216,_code_52261,_67inline_code_52216);
        }
        else if (insert_pos > SEQ_PTR(_67inline_code_52216)->length){
            Concat(&_67inline_code_52216,_67inline_code_52216,_code_52261);
        }
        else if (IS_SEQUENCE(_code_52261)) {
            if( _67inline_code_52216 != _67inline_code_52216 || SEQ_PTR( _67inline_code_52216 )->ref != 1 ){
                DeRef( _67inline_code_52216 );
                RefDS( _67inline_code_52216 );
            }
            assign_space = Add_internal_space( _67inline_code_52216, insert_pos,((s1_ptr)SEQ_PTR(_code_52261))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_52261), _67inline_code_52216 == _67inline_code_52216 );
            _67inline_code_52216 = MAKE_SEQ( assign_space );
        }
        else {
            if( _67inline_code_52216 != _67inline_code_52216 && SEQ_PTR( _67inline_code_52216 )->ref != 1 ){
                _67inline_code_52216 = Insert( _67inline_code_52216, _code_52261, insert_pos);
            }
            else {
                DeRef( _67inline_code_52216 );
                RefDS( _67inline_code_52216 );
                _67inline_code_52216 = Insert( _67inline_code_52216, _code_52261, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_52261)){
            _26940 = SEQ_PTR(_code_52261)->length;
    }
    else {
        _26940 = 1;
    }
    _67shift(_index_52262, _26940, _index_52262);
    _26940 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52261);
    return;
    ;
}


void _67replace_code(int _code_52267, int _start_52268, int _finish_52269)
{
    int _26945 = NOVALUE;
    int _26944 = NOVALUE;
    int _26943 = NOVALUE;
    int _26942 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_52268)) {
        _1 = (long)(DBL_PTR(_start_52268)->dbl);
        DeRefDS(_start_52268);
        _start_52268 = _1;
    }
    if (!IS_ATOM_INT(_finish_52269)) {
        _1 = (long)(DBL_PTR(_finish_52269)->dbl);
        DeRefDS(_finish_52269);
        _finish_52269 = _1;
    }

    /** 	inline_code = replace( inline_code, code, start, finish )*/
    {
        int p1 = _67inline_code_52216;
        int p2 = _code_52267;
        int p3 = _start_52268;
        int p4 = _finish_52269;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_67inline_code_52216;
        Replace( &replace_params );
    }

    /** 	shift( start , length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_52267)){
            _26942 = SEQ_PTR(_code_52267)->length;
    }
    else {
        _26942 = 1;
    }
    _26943 = _finish_52269 - _start_52268;
    if ((long)((unsigned long)_26943 +(unsigned long) HIGH_BITS) >= 0){
        _26943 = NewDouble((double)_26943);
    }
    if (IS_ATOM_INT(_26943)) {
        _26944 = _26943 + 1;
        if (_26944 > MAXINT){
            _26944 = NewDouble((double)_26944);
        }
    }
    else
    _26944 = binary_op(PLUS, 1, _26943);
    DeRef(_26943);
    _26943 = NOVALUE;
    if (IS_ATOM_INT(_26944)) {
        _26945 = _26942 - _26944;
        if ((long)((unsigned long)_26945 +(unsigned long) HIGH_BITS) >= 0){
            _26945 = NewDouble((double)_26945);
        }
    }
    else {
        _26945 = NewDouble((double)_26942 - DBL_PTR(_26944)->dbl);
    }
    _26942 = NOVALUE;
    DeRef(_26944);
    _26944 = NOVALUE;
    _67shift(_start_52268, _26945, _finish_52269);
    _26945 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_52267);
    return;
    ;
}


void _67defer()
{
    int _dx_52277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dx = find( inline_sub, deferred_inline_decisions )*/
    _dx_52277 = find_from(_67inline_sub_52230, _67deferred_inline_decisions_52232, 1);

    /** 	if not dx then*/
    if (_dx_52277 != 0)
    goto L1; // [14] 36

    /** 		deferred_inline_decisions &= inline_sub*/
    Append(&_67deferred_inline_decisions_52232, _67deferred_inline_decisions_52232, _67inline_sub_52230);

    /** 		deferred_inline_calls = append( deferred_inline_calls, {} )*/
    RefDS(_21815);
    Append(&_67deferred_inline_calls_52233, _67deferred_inline_calls_52233, _21815);
L1: 

    /** end procedure*/
    return;
    ;
}


int _67new_inline_temp(int _sym_52286)
{
    int _26951 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_temps &= sym*/
    Append(&_67inline_temps_52218, _67inline_temps_52218, _sym_52286);

    /** 	return length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_52218)){
            _26951 = SEQ_PTR(_67inline_temps_52218)->length;
    }
    else {
        _26951 = 1;
    }
    return _26951;
    ;
}


int _67get_inline_temp(int _sym_52292)
{
    int _temp_num_52293 = NOVALUE;
    int _26955 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = find( sym, inline_params )*/
    _temp_num_52293 = find_from(_sym_52292, _67inline_params_52221, 1);

    /** 	if temp_num then*/
    if (_temp_num_52293 == 0)
    {
        goto L1; // [14] 24
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52293;
L1: 

    /** 	temp_num = find( sym, proc_vars )*/
    _temp_num_52293 = find_from(_sym_52292, _67proc_vars_52217, 1);

    /** 	if temp_num then*/
    if (_temp_num_52293 == 0)
    {
        goto L2; // [35] 45
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52293;
L2: 

    /** 	temp_num = find( sym, inline_temps )*/
    _temp_num_52293 = find_from(_sym_52292, _67inline_temps_52218, 1);

    /** 	if temp_num then*/
    if (_temp_num_52293 == 0)
    {
        goto L3; // [56] 66
    }
    else{
    }

    /** 		return temp_num*/
    return _temp_num_52293;
L3: 

    /** 	return new_inline_temp( sym )*/
    _26955 = _67new_inline_temp(_sym_52292);
    return _26955;
    ;
}


int _67generic_symbol(int _sym_52304)
{
    int _inline_type_52305 = NOVALUE;
    int _px_52306 = NOVALUE;
    int _eentry_52313 = NOVALUE;
    int _26964 = NOVALUE;
    int _26963 = NOVALUE;
    int _26962 = NOVALUE;
    int _26961 = NOVALUE;
    int _26959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer px = find( sym, inline_params )*/
    _px_52306 = find_from(_sym_52304, _67inline_params_52221, 1);

    /** 	if px then*/
    if (_px_52306 == 0)
    {
        goto L1; // [14] 25
    }
    else{
    }

    /** 		inline_type = INLINE_PARAM*/
    _inline_type_52305 = 1;
    goto L2; // [22] 100
L1: 

    /** 		px = find( sym, proc_vars )*/
    _px_52306 = find_from(_sym_52304, _67proc_vars_52217, 1);

    /** 		if px then*/
    if (_px_52306 == 0)
    {
        goto L3; // [36] 47
    }
    else{
    }

    /** 			inline_type = INLINE_VAR*/
    _inline_type_52305 = 6;
    goto L4; // [44] 99
L3: 

    /** 			sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52313);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _eentry_52313 = (int)*(((s1_ptr)_2)->base + _sym_52304);
    Ref(_eentry_52313);

    /** 			if is_literal( sym ) or eentry[S_SCOPE] > SC_PRIVATE then*/
    _26959 = _67is_literal(_sym_52304);
    if (IS_ATOM_INT(_26959)) {
        if (_26959 != 0) {
            goto L5; // [63] 84
        }
    }
    else {
        if (DBL_PTR(_26959)->dbl != 0.0) {
            goto L5; // [63] 84
        }
    }
    _2 = (int)SEQ_PTR(_eentry_52313);
    _26961 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_26961)) {
        _26962 = (_26961 > 3);
    }
    else {
        _26962 = binary_op(GREATER, _26961, 3);
    }
    _26961 = NOVALUE;
    if (_26962 == 0) {
        DeRef(_26962);
        _26962 = NOVALUE;
        goto L6; // [80] 91
    }
    else {
        if (!IS_ATOM_INT(_26962) && DBL_PTR(_26962)->dbl == 0.0){
            DeRef(_26962);
            _26962 = NOVALUE;
            goto L6; // [80] 91
        }
        DeRef(_26962);
        _26962 = NOVALUE;
    }
    DeRef(_26962);
    _26962 = NOVALUE;
L5: 

    /** 				return sym*/
    DeRef(_eentry_52313);
    DeRef(_26959);
    _26959 = NOVALUE;
    return _sym_52304;
L6: 

    /** 			inline_type = INLINE_TEMP*/
    _inline_type_52305 = 2;
    DeRef(_eentry_52313);
    _eentry_52313 = NOVALUE;
L4: 
L2: 

    /** 	return { inline_type, get_inline_temp( sym ) }*/
    _26963 = _67get_inline_temp(_sym_52304);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _inline_type_52305;
    ((int *)_2)[2] = _26963;
    _26964 = MAKE_SEQ(_1);
    _26963 = NOVALUE;
    DeRef(_26959);
    _26959 = NOVALUE;
    return _26964;
    ;
}


int _67adjust_symbol(int _pc_52328)
{
    int _sym_52330 = NOVALUE;
    int _eentry_52336 = NOVALUE;
    int _26972 = NOVALUE;
    int _26970 = NOVALUE;
    int _26969 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52328)) {
        _1 = (long)(DBL_PTR(_pc_52328)->dbl);
        DeRefDS(_pc_52328);
        _pc_52328 = _1;
    }

    /** 	symtab_index sym = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _sym_52330 = (int)*(((s1_ptr)_2)->base + _pc_52328);
    if (!IS_ATOM_INT(_sym_52330)){
        _sym_52330 = (long)DBL_PTR(_sym_52330)->dbl;
    }

    /** 	if sym < 0 then*/
    if (_sym_52330 >= 0)
    goto L1; // [15] 28

    /** 		return 0*/
    DeRef(_eentry_52336);
    return 0;
    goto L2; // [25] 41
L1: 

    /** 	elsif not sym then*/
    if (_sym_52330 != 0)
    goto L3; // [30] 40

    /** 		return 1*/
    DeRef(_eentry_52336);
    return 1;
L3: 
L2: 

    /** 	sequence eentry = SymTab[sym]*/
    DeRef(_eentry_52336);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _eentry_52336 = (int)*(((s1_ptr)_2)->base + _sym_52330);
    Ref(_eentry_52336);

    /** 	if is_literal( sym ) then*/
    _26969 = _67is_literal(_sym_52330);
    if (_26969 == 0) {
        DeRef(_26969);
        _26969 = NOVALUE;
        goto L4; // [57] 69
    }
    else {
        if (!IS_ATOM_INT(_26969) && DBL_PTR(_26969)->dbl == 0.0){
            DeRef(_26969);
            _26969 = NOVALUE;
            goto L4; // [57] 69
        }
        DeRef(_26969);
        _26969 = NOVALUE;
    }
    DeRef(_26969);
    _26969 = NOVALUE;

    /** 		return 1*/
    DeRefDS(_eentry_52336);
    return 1;
    goto L5; // [66] 95
L4: 

    /** 	elsif eentry[S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_eentry_52336);
    _26970 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _26970, 9)){
        _26970 = NOVALUE;
        goto L6; // [79] 94
    }
    _26970 = NOVALUE;

    /** 		defer()*/
    _67defer();

    /** 		return 0*/
    DeRefDS(_eentry_52336);
    return 0;
L6: 
L5: 

    /** 	inline_code[pc] = generic_symbol( sym )*/
    _26972 = _67generic_symbol(_sym_52330);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52328);
    _1 = *(int *)_2;
    *(int *)_2 = _26972;
    if( _1 != _26972 ){
        DeRef(_1);
    }
    _26972 = NOVALUE;

    /** 	return 1*/
    DeRef(_eentry_52336);
    return 1;
    ;
}


int _67check_for_param(int _pc_52350)
{
    int _px_52351 = NOVALUE;
    int _26975 = NOVALUE;
    int _26973 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52350)) {
        _1 = (long)(DBL_PTR(_pc_52350)->dbl);
        DeRefDS(_pc_52350);
        _pc_52350 = _1;
    }

    /** 	integer px = find( inline_code[pc], inline_params )*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _26973 = (int)*(((s1_ptr)_2)->base + _pc_52350);
    _px_52351 = find_from(_26973, _67inline_params_52221, 1);
    _26973 = NOVALUE;

    /** 	if px then*/
    if (_px_52351 == 0)
    {
        goto L1; // [20] 51
    }
    else{
    }

    /** 		if not find( px, assigned_params ) then*/
    _26975 = find_from(_px_52351, _67assigned_params_52222, 1);
    if (_26975 != 0)
    goto L2; // [32] 44
    _26975 = NOVALUE;

    /** 			assigned_params &= px*/
    Append(&_67assigned_params_52222, _67assigned_params_52222, _px_52351);
L2: 

    /** 		return 1*/
    return 1;
L1: 

    /** 	return 0*/
    return 0;
    ;
}


void _67check_target(int _pc_52361, int _op_52362)
{
    int _targets_52363 = NOVALUE;
    int _26984 = NOVALUE;
    int _26983 = NOVALUE;
    int _26982 = NOVALUE;
    int _26981 = NOVALUE;
    int _26980 = NOVALUE;
    int _26978 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence targets = op_info[op][OP_TARGET]*/
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _26978 = (int)*(((s1_ptr)_2)->base + _op_52362);
    DeRef(_targets_52363);
    _2 = (int)SEQ_PTR(_26978);
    _targets_52363 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_targets_52363);
    _26978 = NOVALUE;

    /** 	if length( targets ) then*/
    if (IS_SEQUENCE(_targets_52363)){
            _26980 = SEQ_PTR(_targets_52363)->length;
    }
    else {
        _26980 = 1;
    }
    if (_26980 == 0)
    {
        _26980 = NOVALUE;
        goto L1; // [26] 72
    }
    else{
        _26980 = NOVALUE;
    }

    /** 	for i = 1 to length( targets ) do*/
    if (IS_SEQUENCE(_targets_52363)){
            _26981 = SEQ_PTR(_targets_52363)->length;
    }
    else {
        _26981 = 1;
    }
    {
        int _i_52371;
        _i_52371 = 1;
L2: 
        if (_i_52371 > _26981){
            goto L3; // [34] 71
        }

        /** 			if check_for_param( pc + targets[i] ) then*/
        _2 = (int)SEQ_PTR(_targets_52363);
        _26982 = (int)*(((s1_ptr)_2)->base + _i_52371);
        if (IS_ATOM_INT(_26982)) {
            _26983 = _pc_52361 + _26982;
            if ((long)((unsigned long)_26983 + (unsigned long)HIGH_BITS) >= 0) 
            _26983 = NewDouble((double)_26983);
        }
        else {
            _26983 = binary_op(PLUS, _pc_52361, _26982);
        }
        _26982 = NOVALUE;
        _26984 = _67check_for_param(_26983);
        _26983 = NOVALUE;
        if (_26984 == 0) {
            DeRef(_26984);
            _26984 = NOVALUE;
            goto L4; // [55] 64
        }
        else {
            if (!IS_ATOM_INT(_26984) && DBL_PTR(_26984)->dbl == 0.0){
                DeRef(_26984);
                _26984 = NOVALUE;
                goto L4; // [55] 64
            }
            DeRef(_26984);
            _26984 = NOVALUE;
        }
        DeRef(_26984);
        _26984 = NOVALUE;

        /** 				return*/
        DeRefDS(_targets_52363);
        return;
L4: 

        /** 		end for*/
        _i_52371 = _i_52371 + 1;
        goto L2; // [66] 41
L3: 
        ;
    }
L1: 

    /** end procedure*/
    DeRef(_targets_52363);
    return;
    ;
}


int _67adjust_il(int _pc_52379, int _op_52380)
{
    int _addr_52388 = NOVALUE;
    int _sub_52394 = NOVALUE;
    int _27009 = NOVALUE;
    int _27008 = NOVALUE;
    int _27007 = NOVALUE;
    int _27006 = NOVALUE;
    int _27005 = NOVALUE;
    int _27004 = NOVALUE;
    int _27003 = NOVALUE;
    int _27001 = NOVALUE;
    int _27000 = NOVALUE;
    int _26999 = NOVALUE;
    int _26998 = NOVALUE;
    int _26997 = NOVALUE;
    int _26996 = NOVALUE;
    int _26995 = NOVALUE;
    int _26994 = NOVALUE;
    int _26992 = NOVALUE;
    int _26991 = NOVALUE;
    int _26989 = NOVALUE;
    int _26988 = NOVALUE;
    int _26987 = NOVALUE;
    int _26986 = NOVALUE;
    int _26985 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to op_info[op][OP_SIZE] - 1 do*/
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _26985 = (int)*(((s1_ptr)_2)->base + _op_52380);
    _2 = (int)SEQ_PTR(_26985);
    _26986 = (int)*(((s1_ptr)_2)->base + 2);
    _26985 = NOVALUE;
    if (IS_ATOM_INT(_26986)) {
        _26987 = _26986 - 1;
        if ((long)((unsigned long)_26987 +(unsigned long) HIGH_BITS) >= 0){
            _26987 = NewDouble((double)_26987);
        }
    }
    else {
        _26987 = binary_op(MINUS, _26986, 1);
    }
    _26986 = NOVALUE;
    {
        int _i_52382;
        _i_52382 = 1;
L1: 
        if (binary_op_a(GREATER, _i_52382, _26987)){
            goto L2; // [23] 214
        }

        /** 		integer addr = find( i, op_info[op][OP_ADDR] )*/
        _2 = (int)SEQ_PTR(_65op_info_26251);
        _26988 = (int)*(((s1_ptr)_2)->base + _op_52380);
        _2 = (int)SEQ_PTR(_26988);
        _26989 = (int)*(((s1_ptr)_2)->base + 3);
        _26988 = NOVALUE;
        _addr_52388 = find_from(_i_52382, _26989, 1);
        _26989 = NOVALUE;

        /** 		integer sub  = find( i, op_info[op][OP_SUB] )*/
        _2 = (int)SEQ_PTR(_65op_info_26251);
        _26991 = (int)*(((s1_ptr)_2)->base + _op_52380);
        _2 = (int)SEQ_PTR(_26991);
        _26992 = (int)*(((s1_ptr)_2)->base + 5);
        _26991 = NOVALUE;
        _sub_52394 = find_from(_i_52382, _26992, 1);
        _26992 = NOVALUE;

        /** 		if addr then*/
        if (_addr_52388 == 0)
        {
            goto L3; // [70] 121
        }
        else{
        }

        /** 			if integer( inline_code[pc+i] ) then*/
        if (IS_ATOM_INT(_i_52382)) {
            _26994 = _pc_52379 + _i_52382;
        }
        else {
            _26994 = NewDouble((double)_pc_52379 + DBL_PTR(_i_52382)->dbl);
        }
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!IS_ATOM_INT(_26994)){
            _26995 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26994)->dbl));
        }
        else{
            _26995 = (int)*(((s1_ptr)_2)->base + _26994);
        }
        if (IS_ATOM_INT(_26995))
        _26996 = 1;
        else if (IS_ATOM_DBL(_26995))
        _26996 = IS_ATOM_INT(DoubleToInt(_26995));
        else
        _26996 = 0;
        _26995 = NOVALUE;
        if (_26996 == 0)
        {
            _26996 = NOVALUE;
            goto L4; // [88] 205
        }
        else{
            _26996 = NOVALUE;
        }

        /** 				inline_code[pc + i] = { INLINE_ADDR, inline_code[pc + i] }*/
        if (IS_ATOM_INT(_i_52382)) {
            _26997 = _pc_52379 + _i_52382;
            if ((long)((unsigned long)_26997 + (unsigned long)HIGH_BITS) >= 0) 
            _26997 = NewDouble((double)_26997);
        }
        else {
            _26997 = NewDouble((double)_pc_52379 + DBL_PTR(_i_52382)->dbl);
        }
        if (IS_ATOM_INT(_i_52382)) {
            _26998 = _pc_52379 + _i_52382;
        }
        else {
            _26998 = NewDouble((double)_pc_52379 + DBL_PTR(_i_52382)->dbl);
        }
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!IS_ATOM_INT(_26998)){
            _26999 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26998)->dbl));
        }
        else{
            _26999 = (int)*(((s1_ptr)_2)->base + _26998);
        }
        Ref(_26999);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 4;
        ((int *)_2)[2] = _26999;
        _27000 = MAKE_SEQ(_1);
        _26999 = NOVALUE;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52216 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_26997))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_26997)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _26997);
        _1 = *(int *)_2;
        *(int *)_2 = _27000;
        if( _1 != _27000 ){
            DeRef(_1);
        }
        _27000 = NOVALUE;
        goto L4; // [118] 205
L3: 

        /** 		elsif sub then*/
        if (_sub_52394 == 0)
        {
            goto L5; // [123] 141
        }
        else{
        }

        /** 			inline_code[pc+i] = {INLINE_SUB}*/
        if (IS_ATOM_INT(_i_52382)) {
            _27001 = _pc_52379 + _i_52382;
        }
        else {
            _27001 = NewDouble((double)_pc_52379 + DBL_PTR(_i_52382)->dbl);
        }
        RefDS(_27002);
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52216 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_27001))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27001)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _27001);
        _1 = *(int *)_2;
        *(int *)_2 = _27002;
        DeRef(_1);
        goto L4; // [138] 205
L5: 

        /** 			if op != STARTLINE and op != COVERAGE_LINE and op != COVERAGE_ROUTINE then*/
        _27003 = (_op_52380 != 58);
        if (_27003 == 0) {
            _27004 = 0;
            goto L6; // [149] 163
        }
        _27005 = (_op_52380 != 210);
        _27004 = (_27005 != 0);
L6: 
        if (_27004 == 0) {
            goto L7; // [163] 204
        }
        _27007 = (_op_52380 != 211);
        if (_27007 == 0)
        {
            DeRef(_27007);
            _27007 = NOVALUE;
            goto L7; // [174] 204
        }
        else{
            DeRef(_27007);
            _27007 = NOVALUE;
        }

        /** 				check_target( pc, op )*/
        _67check_target(_pc_52379, _op_52380);

        /** 				if not adjust_symbol( pc + i ) then*/
        if (IS_ATOM_INT(_i_52382)) {
            _27008 = _pc_52379 + _i_52382;
            if ((long)((unsigned long)_27008 + (unsigned long)HIGH_BITS) >= 0) 
            _27008 = NewDouble((double)_27008);
        }
        else {
            _27008 = NewDouble((double)_pc_52379 + DBL_PTR(_i_52382)->dbl);
        }
        _27009 = _67adjust_symbol(_27008);
        _27008 = NOVALUE;
        if (IS_ATOM_INT(_27009)) {
            if (_27009 != 0){
                DeRef(_27009);
                _27009 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        else {
            if (DBL_PTR(_27009)->dbl != 0.0){
                DeRef(_27009);
                _27009 = NOVALUE;
                goto L8; // [193] 203
            }
        }
        DeRef(_27009);
        _27009 = NOVALUE;

        /** 					return 0*/
        DeRef(_i_52382);
        DeRef(_26994);
        _26994 = NOVALUE;
        DeRef(_26987);
        _26987 = NOVALUE;
        DeRef(_26997);
        _26997 = NOVALUE;
        DeRef(_26998);
        _26998 = NOVALUE;
        DeRef(_27001);
        _27001 = NOVALUE;
        DeRef(_27003);
        _27003 = NOVALUE;
        DeRef(_27005);
        _27005 = NOVALUE;
        return 0;
L8: 
L7: 
L4: 

        /** 	end for*/
        _0 = _i_52382;
        if (IS_ATOM_INT(_i_52382)) {
            _i_52382 = _i_52382 + 1;
            if ((long)((unsigned long)_i_52382 +(unsigned long) HIGH_BITS) >= 0){
                _i_52382 = NewDouble((double)_i_52382);
            }
        }
        else {
            _i_52382 = binary_op_a(PLUS, _i_52382, 1);
        }
        DeRef(_0);
        goto L1; // [209] 30
L2: 
        ;
        DeRef(_i_52382);
    }

    /** 	return 1*/
    DeRef(_26994);
    _26994 = NOVALUE;
    DeRef(_26987);
    _26987 = NOVALUE;
    DeRef(_26997);
    _26997 = NOVALUE;
    DeRef(_26998);
    _26998 = NOVALUE;
    DeRef(_27001);
    _27001 = NOVALUE;
    DeRef(_27003);
    _27003 = NOVALUE;
    DeRef(_27005);
    _27005 = NOVALUE;
    return 1;
    ;
}


int _67is_temp(int _sym_52429)
{
    int _27020 = NOVALUE;
    int _27019 = NOVALUE;
    int _27018 = NOVALUE;
    int _27017 = NOVALUE;
    int _27016 = NOVALUE;
    int _27015 = NOVALUE;
    int _27014 = NOVALUE;
    int _27013 = NOVALUE;
    int _27012 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52429 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	return (SymTab[sym][S_MODE] = M_TEMP) and (not TRANSLATE or equal( NOVALUE, SymTab[sym][S_OBJ]) )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27012 = (int)*(((s1_ptr)_2)->base + _sym_52429);
    _2 = (int)SEQ_PTR(_27012);
    _27013 = (int)*(((s1_ptr)_2)->base + 3);
    _27012 = NOVALUE;
    if (IS_ATOM_INT(_27013)) {
        _27014 = (_27013 == 3);
    }
    else {
        _27014 = binary_op(EQUALS, _27013, 3);
    }
    _27013 = NOVALUE;
    _27015 = (_35TRANSLATE_15611 == 0);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27016 = (int)*(((s1_ptr)_2)->base + _sym_52429);
    _2 = (int)SEQ_PTR(_27016);
    _27017 = (int)*(((s1_ptr)_2)->base + 1);
    _27016 = NOVALUE;
    if (_35NOVALUE_15823 == _27017)
    _27018 = 1;
    else if (IS_ATOM_INT(_35NOVALUE_15823) && IS_ATOM_INT(_27017))
    _27018 = 0;
    else
    _27018 = (compare(_35NOVALUE_15823, _27017) == 0);
    _27017 = NOVALUE;
    _27019 = (_27015 != 0 || _27018 != 0);
    _27015 = NOVALUE;
    _27018 = NOVALUE;
    if (IS_ATOM_INT(_27014)) {
        _27020 = (_27014 != 0 && _27019 != 0);
    }
    else {
        _27020 = binary_op(AND, _27014, _27019);
    }
    DeRef(_27014);
    _27014 = NOVALUE;
    _27019 = NOVALUE;
    return _27020;
    ;
}


int _67is_literal(int _sym_52451)
{
    int _mode_52454 = NOVALUE;
    int _27035 = NOVALUE;
    int _27034 = NOVALUE;
    int _27033 = NOVALUE;
    int _27032 = NOVALUE;
    int _27031 = NOVALUE;
    int _27030 = NOVALUE;
    int _27028 = NOVALUE;
    int _27027 = NOVALUE;
    int _27026 = NOVALUE;
    int _27025 = NOVALUE;
    int _27024 = NOVALUE;
    int _27022 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym <= 0 then*/
    if (_sym_52451 > 0)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	integer mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27022 = (int)*(((s1_ptr)_2)->base + _sym_52451);
    _2 = (int)SEQ_PTR(_27022);
    _mode_52454 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_52454)){
        _mode_52454 = (long)DBL_PTR(_mode_52454)->dbl;
    }
    _27022 = NOVALUE;

    /** 	if (mode = M_CONSTANT and eu:compare( NOVALUE, SymTab[sym][S_OBJ]) ) */
    _27024 = (_mode_52454 == 2);
    if (_27024 == 0) {
        _27025 = 0;
        goto L2; // [40] 66
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27026 = (int)*(((s1_ptr)_2)->base + _sym_52451);
    _2 = (int)SEQ_PTR(_27026);
    _27027 = (int)*(((s1_ptr)_2)->base + 1);
    _27026 = NOVALUE;
    if (IS_ATOM_INT(_35NOVALUE_15823) && IS_ATOM_INT(_27027)){
        _27028 = (_35NOVALUE_15823 < _27027) ? -1 : (_35NOVALUE_15823 > _27027);
    }
    else{
        _27028 = compare(_35NOVALUE_15823, _27027);
    }
    _27027 = NOVALUE;
    _27025 = (_27028 != 0);
L2: 
    if (_27025 != 0) {
        goto L3; // [66] 117
    }
    if (_35TRANSLATE_15611 == 0) {
        _27030 = 0;
        goto L4; // [72] 86
    }
    _27031 = (_mode_52454 == 3);
    _27030 = (_27031 != 0);
L4: 
    if (_27030 == 0) {
        DeRef(_27032);
        _27032 = 0;
        goto L5; // [86] 112
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27033 = (int)*(((s1_ptr)_2)->base + _sym_52451);
    _2 = (int)SEQ_PTR(_27033);
    _27034 = (int)*(((s1_ptr)_2)->base + 1);
    _27033 = NOVALUE;
    if (IS_ATOM_INT(_27034) && IS_ATOM_INT(_35NOVALUE_15823)){
        _27035 = (_27034 < _35NOVALUE_15823) ? -1 : (_27034 > _35NOVALUE_15823);
    }
    else{
        _27035 = compare(_27034, _35NOVALUE_15823);
    }
    _27034 = NOVALUE;
    _27032 = (_27035 != 0);
L5: 
    if (_27032 == 0)
    {
        _27032 = NOVALUE;
        goto L6; // [113] 126
    }
    else{
        _27032 = NOVALUE;
    }
L3: 

    /** 		return 1*/
    DeRef(_27024);
    _27024 = NOVALUE;
    DeRef(_27031);
    _27031 = NOVALUE;
    return 1;
    goto L7; // [123] 133
L6: 

    /** 		return 0*/
    DeRef(_27024);
    _27024 = NOVALUE;
    DeRef(_27031);
    _27031 = NOVALUE;
    return 0;
L7: 
    ;
}


int _67returnf(int _pc_52501)
{
    int _retsym_52503 = NOVALUE;
    int _code_52536 = NOVALUE;
    int _ret_pc_52537 = NOVALUE;
    int _code_52582 = NOVALUE;
    int _ret_pc_52596 = NOVALUE;
    int _27108 = NOVALUE;
    int _27107 = NOVALUE;
    int _27105 = NOVALUE;
    int _27103 = NOVALUE;
    int _27102 = NOVALUE;
    int _27100 = NOVALUE;
    int _27099 = NOVALUE;
    int _27097 = NOVALUE;
    int _27096 = NOVALUE;
    int _27095 = NOVALUE;
    int _27093 = NOVALUE;
    int _27092 = NOVALUE;
    int _27090 = NOVALUE;
    int _27088 = NOVALUE;
    int _27087 = NOVALUE;
    int _27085 = NOVALUE;
    int _27084 = NOVALUE;
    int _27082 = NOVALUE;
    int _27081 = NOVALUE;
    int _27080 = NOVALUE;
    int _27078 = NOVALUE;
    int _27077 = NOVALUE;
    int _27076 = NOVALUE;
    int _27075 = NOVALUE;
    int _27074 = NOVALUE;
    int _27072 = NOVALUE;
    int _27071 = NOVALUE;
    int _27070 = NOVALUE;
    int _27069 = NOVALUE;
    int _27067 = NOVALUE;
    int _27065 = NOVALUE;
    int _27064 = NOVALUE;
    int _27063 = NOVALUE;
    int _27062 = NOVALUE;
    int _27061 = NOVALUE;
    int _27060 = NOVALUE;
    int _27059 = NOVALUE;
    int _27058 = NOVALUE;
    int _27057 = NOVALUE;
    int _27055 = NOVALUE;
    int _27054 = NOVALUE;
    int _27053 = NOVALUE;
    int _27051 = NOVALUE;
    int _27050 = NOVALUE;
    int _27049 = NOVALUE;
    int _27048 = NOVALUE;
    int _27047 = NOVALUE;
    int _27046 = NOVALUE;
    int _27044 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index retsym = inline_code[pc+3]*/
    _27044 = _pc_52501 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _retsym_52503 = (int)*(((s1_ptr)_2)->base + _27044);
    if (!IS_ATOM_INT(_retsym_52503)){
        _retsym_52503 = (long)DBL_PTR(_retsym_52503)->dbl;
    }

    /** 	if equal( inline_code[$], BADRETURNF ) then*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27046 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27046 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27047 = (int)*(((s1_ptr)_2)->base + _27046);
    if (_27047 == 43)
    _27048 = 1;
    else if (IS_ATOM_INT(_27047) && IS_ATOM_INT(43))
    _27048 = 0;
    else
    _27048 = (compare(_27047, 43) == 0);
    _27047 = NOVALUE;
    if (_27048 == 0)
    {
        _27048 = NOVALUE;
        goto L1; // [34] 102
    }
    else{
        _27048 = NOVALUE;
    }

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [41] 60
    }
    else{
    }

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27049 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27049 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27049);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [57] 101
L2: 

    /** 		elsif SymTab[inline_sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27050 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52230);
    _2 = (int)SEQ_PTR(_27050);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _27051 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _27051 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _27050 = NOVALUE;
    if (binary_op_a(NOTEQ, _27051, 27)){
        _27051 = NOVALUE;
        goto L4; // [78] 100
    }
    _27051 = NOVALUE;

    /** 			replace_code( {}, length(inline_code), length(inline_code) )*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27053 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27053 = 1;
    }
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27054 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27054 = 1;
    }
    RefDS(_21815);
    _67replace_code(_21815, _27053, _27054);
    _27053 = NOVALUE;
    _27054 = NOVALUE;
L4: 
L3: 
L1: 

    /** 	if is_temp( retsym ) */
    _27055 = _67is_temp(_retsym_52503);
    if (IS_ATOM_INT(_27055)) {
        if (_27055 != 0) {
            goto L5; // [108] 150
        }
    }
    else {
        if (DBL_PTR(_27055)->dbl != 0.0) {
            goto L5; // [108] 150
        }
    }
    _27057 = _67is_literal(_retsym_52503);
    if (IS_ATOM_INT(_27057)) {
        _27058 = (_27057 == 0);
    }
    else {
        _27058 = unary_op(NOT, _27057);
    }
    DeRef(_27057);
    _27057 = NOVALUE;
    if (IS_ATOM_INT(_27058)) {
        if (_27058 == 0) {
            DeRef(_27059);
            _27059 = 0;
            goto L6; // [119] 145
        }
    }
    else {
        if (DBL_PTR(_27058)->dbl == 0.0) {
            DeRef(_27059);
            _27059 = 0;
            goto L6; // [119] 145
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27060 = (int)*(((s1_ptr)_2)->base + _retsym_52503);
    _2 = (int)SEQ_PTR(_27060);
    _27061 = (int)*(((s1_ptr)_2)->base + 4);
    _27060 = NOVALUE;
    if (IS_ATOM_INT(_27061)) {
        _27062 = (_27061 <= 3);
    }
    else {
        _27062 = binary_op(LESSEQ, _27061, 3);
    }
    _27061 = NOVALUE;
    DeRef(_27059);
    if (IS_ATOM_INT(_27062))
    _27059 = (_27062 != 0);
    else
    _27059 = DBL_PTR(_27062)->dbl != 0.0;
L6: 
    if (_27059 == 0)
    {
        _27059 = NOVALUE;
        goto L7; // [146] 393
    }
    else{
        _27059 = NOVALUE;
    }
L5: 

    /** 		sequence code = {}*/
    RefDS(_21815);
    DeRef(_code_52536);
    _code_52536 = _21815;

    /** 		integer ret_pc = 0*/
    _ret_pc_52537 = 0;

    /** 		if not (find( retsym, inline_params ) or find( retsym, proc_vars )) then*/
    _27063 = find_from(_retsym_52503, _67inline_params_52221, 1);
    if (_27063 != 0) {
        DeRef(_27064);
        _27064 = 1;
        goto L8; // [171] 186
    }
    _27065 = find_from(_retsym_52503, _67proc_vars_52217, 1);
    _27064 = (_27065 != 0);
L8: 
    if (_27064 != 0)
    goto L9; // [186] 206
    _27064 = NOVALUE;

    /** 			ret_pc = rfind( generic_symbol( retsym ), inline_code, pc )*/
    _27067 = _67generic_symbol(_retsym_52503);
    RefDS(_67inline_code_52216);
    _ret_pc_52537 = _16rfind(_27067, _67inline_code_52216, _pc_52501);
    _27067 = NOVALUE;
    if (!IS_ATOM_INT(_ret_pc_52537)) {
        _1 = (long)(DBL_PTR(_ret_pc_52537)->dbl);
        DeRefDS(_ret_pc_52537);
        _ret_pc_52537 = _1;
    }
L9: 

    /** 		if ret_pc and eu:compare( inline_code[ret_pc-1], PRIVATE_INIT_CHECK ) then*/
    if (_ret_pc_52537 == 0) {
        goto LA; // [208] 277
    }
    _27070 = _ret_pc_52537 - 1;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27071 = (int)*(((s1_ptr)_2)->base + _27070);
    if (IS_ATOM_INT(_27071) && IS_ATOM_INT(30)){
        _27072 = (_27071 < 30) ? -1 : (_27071 > 30);
    }
    else{
        _27072 = compare(_27071, 30);
    }
    _27071 = NOVALUE;
    if (_27072 == 0)
    {
        _27072 = NOVALUE;
        goto LA; // [229] 277
    }
    else{
        _27072 = NOVALUE;
    }

    /** 			inline_code[ret_pc] = {INLINE_TARGET}*/
    RefDS(_27073);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ret_pc_52537);
    _1 = *(int *)_2;
    *(int *)_2 = _27073;
    DeRef(_1);

    /** 			if equal( inline_code[ret_pc-1], REF_TEMP ) then*/
    _27074 = _ret_pc_52537 - 1;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27075 = (int)*(((s1_ptr)_2)->base + _27074);
    if (_27075 == 207)
    _27076 = 1;
    else if (IS_ATOM_INT(_27075) && IS_ATOM_INT(207))
    _27076 = 0;
    else
    _27076 = (compare(_27075, 207) == 0);
    _27075 = NOVALUE;
    if (_27076 == 0)
    {
        _27076 = NOVALUE;
        goto LB; // [258] 292
    }
    else{
        _27076 = NOVALUE;
    }

    /** 				inline_code[ret_pc-2] = {INLINE_TARGET}*/
    _27077 = _ret_pc_52537 - 2;
    RefDS(_27073);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27077);
    _1 = *(int *)_2;
    *(int *)_2 = _27073;
    DeRef(_1);
    goto LB; // [274] 292
LA: 

    /** 			code = {ASSIGN, generic_symbol( retsym ), {INLINE_TARGET}}*/
    _27078 = _67generic_symbol(_retsym_52503);
    _0 = _code_52536;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _27078;
    RefDS(_27073);
    *((int *)(_2+12)) = _27073;
    _code_52536 = MAKE_SEQ(_1);
    DeRef(_0);
    _27078 = NOVALUE;
LB: 

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27080 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27080 = 1;
    }
    _27081 = 3 + _35TRANSLATE_15611;
    _27082 = _27080 - _27081;
    _27080 = NOVALUE;
    _27081 = NOVALUE;
    if (_pc_52501 == _27082)
    goto LC; // [309] 330

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27084 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27084;
    _27085 = MAKE_SEQ(_1);
    _27084 = NOVALUE;
    Concat((object_ptr)&_code_52536, _code_52536, _27085);
    DeRefDS(_27085);
    _27085 = NOVALUE;
LC: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27087 = _pc_52501 + 3;
    if ((long)((unsigned long)_27087 + (unsigned long)HIGH_BITS) >= 0) 
    _27087 = NewDouble((double)_27087);
    RefDS(_code_52536);
    _67replace_code(_code_52536, _pc_52501, _27087);
    _27087 = NOVALUE;

    /** 		ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27088 = MAKE_SEQ(_1);
    _ret_pc_52537 = find_from(_27088, _67inline_code_52216, _pc_52501);
    DeRefDS(_27088);
    _27088 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_52537 == 0)
    {
        goto LD; // [356] 382
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_52537 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27092 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27092 = 1;
    }
    _27093 = _27092 + 1;
    _27092 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27093;
    if( _1 != _27093 ){
        DeRef(_1);
    }
    _27093 = NOVALUE;
    _27090 = NOVALUE;
LD: 

    /** 		return 1*/
    DeRef(_code_52536);
    DeRef(_27044);
    _27044 = NOVALUE;
    DeRef(_27055);
    _27055 = NOVALUE;
    DeRef(_27058);
    _27058 = NOVALUE;
    DeRef(_27070);
    _27070 = NOVALUE;
    DeRef(_27062);
    _27062 = NOVALUE;
    DeRef(_27074);
    _27074 = NOVALUE;
    DeRef(_27077);
    _27077 = NOVALUE;
    DeRef(_27082);
    _27082 = NOVALUE;
    return 1;
    goto LE; // [390] 502
L7: 

    /** 		sequence code = {ASSIGN, retsym, {INLINE_TARGET}}*/
    _0 = _code_52582;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _retsym_52503;
    RefDS(_27073);
    *((int *)(_2+12)) = _27073;
    _code_52582 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if pc != length( inline_code ) - ( 3 + TRANSLATE ) then*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27095 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27095 = 1;
    }
    _27096 = 3 + _35TRANSLATE_15611;
    _27097 = _27095 - _27096;
    _27095 = NOVALUE;
    _27096 = NOVALUE;
    if (_pc_52501 == _27097)
    goto LF; // [420] 441

    /** 			code &= { ELSE, {INLINE_ADDR, -1 }}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27099 = MAKE_SEQ(_1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27099;
    _27100 = MAKE_SEQ(_1);
    _27099 = NOVALUE;
    Concat((object_ptr)&_code_52582, _code_52582, _27100);
    DeRefDS(_27100);
    _27100 = NOVALUE;
LF: 

    /** 		replace_code( code, pc, pc + 3 )*/
    _27102 = _pc_52501 + 3;
    if ((long)((unsigned long)_27102 + (unsigned long)HIGH_BITS) >= 0) 
    _27102 = NewDouble((double)_27102);
    RefDS(_code_52582);
    _67replace_code(_code_52582, _pc_52501, _27102);
    _27102 = NOVALUE;

    /** 		integer ret_pc = find( { INLINE_ADDR, -1 }, inline_code, pc )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = -1;
    _27103 = MAKE_SEQ(_1);
    _ret_pc_52596 = find_from(_27103, _67inline_code_52216, _pc_52501);
    DeRefDS(_27103);
    _27103 = NOVALUE;

    /** 		if ret_pc then*/
    if (_ret_pc_52596 == 0)
    {
        goto L10; // [467] 493
    }
    else{
    }

    /** 			inline_code[ret_pc][2] = length(inline_code) + 1*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ret_pc_52596 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27107 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27107 = 1;
    }
    _27108 = _27107 + 1;
    _27107 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27108;
    if( _1 != _27108 ){
        DeRef(_1);
    }
    _27108 = NOVALUE;
    _27105 = NOVALUE;
L10: 

    /** 		return 1*/
    DeRef(_code_52582);
    DeRef(_27044);
    _27044 = NOVALUE;
    DeRef(_27055);
    _27055 = NOVALUE;
    DeRef(_27058);
    _27058 = NOVALUE;
    DeRef(_27070);
    _27070 = NOVALUE;
    DeRef(_27062);
    _27062 = NOVALUE;
    DeRef(_27074);
    _27074 = NOVALUE;
    DeRef(_27077);
    _27077 = NOVALUE;
    DeRef(_27082);
    _27082 = NOVALUE;
    DeRef(_27097);
    _27097 = NOVALUE;
    return 1;
LE: 

    /** 	return 0*/
    DeRef(_27044);
    _27044 = NOVALUE;
    DeRef(_27055);
    _27055 = NOVALUE;
    DeRef(_27058);
    _27058 = NOVALUE;
    DeRef(_27070);
    _27070 = NOVALUE;
    DeRef(_27062);
    _27062 = NOVALUE;
    DeRef(_27074);
    _27074 = NOVALUE;
    DeRef(_27077);
    _27077 = NOVALUE;
    DeRef(_27082);
    _27082 = NOVALUE;
    DeRef(_27097);
    _27097 = NOVALUE;
    return 0;
    ;
}


int _67inline_op(int _pc_52606)
{
    int _op_52607 = NOVALUE;
    int _code_52612 = NOVALUE;
    int _stlen_52645 = NOVALUE;
    int _file_52650 = NOVALUE;
    int _ok_52655 = NOVALUE;
    int _original_table_52678 = NOVALUE;
    int _jump_table_52682 = NOVALUE;
    int _27169 = NOVALUE;
    int _27168 = NOVALUE;
    int _27167 = NOVALUE;
    int _27166 = NOVALUE;
    int _27165 = NOVALUE;
    int _27164 = NOVALUE;
    int _27163 = NOVALUE;
    int _27162 = NOVALUE;
    int _27161 = NOVALUE;
    int _27160 = NOVALUE;
    int _27159 = NOVALUE;
    int _27158 = NOVALUE;
    int _27155 = NOVALUE;
    int _27154 = NOVALUE;
    int _27153 = NOVALUE;
    int _27152 = NOVALUE;
    int _27150 = NOVALUE;
    int _27148 = NOVALUE;
    int _27147 = NOVALUE;
    int _27145 = NOVALUE;
    int _27141 = NOVALUE;
    int _27140 = NOVALUE;
    int _27139 = NOVALUE;
    int _27138 = NOVALUE;
    int _27137 = NOVALUE;
    int _27136 = NOVALUE;
    int _27133 = NOVALUE;
    int _27132 = NOVALUE;
    int _27130 = NOVALUE;
    int _27129 = NOVALUE;
    int _27127 = NOVALUE;
    int _27125 = NOVALUE;
    int _27124 = NOVALUE;
    int _27123 = NOVALUE;
    int _27122 = NOVALUE;
    int _27121 = NOVALUE;
    int _27120 = NOVALUE;
    int _27119 = NOVALUE;
    int _27117 = NOVALUE;
    int _27116 = NOVALUE;
    int _27115 = NOVALUE;
    int _27113 = NOVALUE;
    int _27112 = NOVALUE;
    int _27111 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _op_52607 = (int)*(((s1_ptr)_2)->base + _pc_52606);
    if (!IS_ATOM_INT(_op_52607))
    _op_52607 = (long)DBL_PTR(_op_52607)->dbl;

    /** 	if op = RETURNP then*/
    if (_op_52607 != 29)
    goto L1; // [15] 150

    /** 		sequence code = ""*/
    RefDS(_21815);
    DeRef(_code_52612);
    _code_52612 = _21815;

    /** 		if pc != length( inline_code ) - 1 - TRANSLATE then*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27111 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27111 = 1;
    }
    _27112 = _27111 - 1;
    _27111 = NOVALUE;
    _27113 = _27112 - _35TRANSLATE_15611;
    _27112 = NOVALUE;
    if (_pc_52606 == _27113)
    goto L2; // [43] 92

    /** 			code = { ELSE, {INLINE_ADDR, length( inline_code ) + 1 }}*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27115 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27115 = 1;
    }
    _27116 = _27115 + 1;
    _27115 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = _27116;
    _27117 = MAKE_SEQ(_1);
    _27116 = NOVALUE;
    DeRefDS(_code_52612);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 23;
    ((int *)_2)[2] = _27117;
    _code_52612 = MAKE_SEQ(_1);
    _27117 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [72] 134
    }
    else{
    }

    /** 				inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27119 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27119 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27119);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
    goto L3; // [89] 134
L2: 

    /** 		elsif TRANSLATE and inline_code[$] = BADRETURNF then*/
    if (_35TRANSLATE_15611 == 0) {
        goto L4; // [96] 133
    }
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27121 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27121 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27122 = (int)*(((s1_ptr)_2)->base + _27121);
    if (IS_ATOM_INT(_27122)) {
        _27123 = (_27122 == 43);
    }
    else {
        _27123 = binary_op(EQUALS, _27122, 43);
    }
    _27122 = NOVALUE;
    if (_27123 == 0) {
        DeRef(_27123);
        _27123 = NOVALUE;
        goto L4; // [116] 133
    }
    else {
        if (!IS_ATOM_INT(_27123) && DBL_PTR(_27123)->dbl == 0.0){
            DeRef(_27123);
            _27123 = NOVALUE;
            goto L4; // [116] 133
        }
        DeRef(_27123);
        _27123 = NOVALUE;
    }
    DeRef(_27123);
    _27123 = NOVALUE;

    /** 			inline_code[$] = NOP1*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27124 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27124 = 1;
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27124);
    _1 = *(int *)_2;
    *(int *)_2 = 159;
    DeRef(_1);
L4: 
L3: 

    /** 		replace_code( code, pc, pc + 2 )*/
    _27125 = _pc_52606 + 2;
    if ((long)((unsigned long)_27125 + (unsigned long)HIGH_BITS) >= 0) 
    _27125 = NewDouble((double)_27125);
    RefDS(_code_52612);
    _67replace_code(_code_52612, _pc_52606, _27125);
    _27125 = NOVALUE;
    DeRefDS(_code_52612);
    _code_52612 = NOVALUE;
    goto L5; // [147] 526
L1: 

    /** 	elsif op = RETURNF then*/
    if (_op_52607 != 28)
    goto L6; // [154] 171

    /** 		return returnf( pc )*/
    _27127 = _67returnf(_pc_52606);
    DeRef(_27113);
    _27113 = NOVALUE;
    return _27127;
    goto L5; // [168] 526
L6: 

    /** 	elsif op = ROUTINE_ID then*/
    if (_op_52607 != 134)
    goto L7; // [175] 273

    /** 		integer*/

    /** 			stlen = inline_code[pc+2+TRANSLATE],*/
    _27129 = _pc_52606 + 2;
    if ((long)((unsigned long)_27129 + (unsigned long)HIGH_BITS) >= 0) 
    _27129 = NewDouble((double)_27129);
    if (IS_ATOM_INT(_27129)) {
        _27130 = _27129 + _35TRANSLATE_15611;
    }
    else {
        _27130 = NewDouble(DBL_PTR(_27129)->dbl + (double)_35TRANSLATE_15611);
    }
    DeRef(_27129);
    _27129 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!IS_ATOM_INT(_27130)){
        _stlen_52645 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27130)->dbl));
    }
    else{
        _stlen_52645 = (int)*(((s1_ptr)_2)->base + _27130);
    }
    if (!IS_ATOM_INT(_stlen_52645))
    _stlen_52645 = (long)DBL_PTR(_stlen_52645)->dbl;

    /** 			file  = inline_code[pc+4+TRANSLATE],*/
    _27132 = _pc_52606 + 4;
    if ((long)((unsigned long)_27132 + (unsigned long)HIGH_BITS) >= 0) 
    _27132 = NewDouble((double)_27132);
    if (IS_ATOM_INT(_27132)) {
        _27133 = _27132 + _35TRANSLATE_15611;
    }
    else {
        _27133 = NewDouble(DBL_PTR(_27132)->dbl + (double)_35TRANSLATE_15611);
    }
    DeRef(_27132);
    _27132 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!IS_ATOM_INT(_27133)){
        _file_52650 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27133)->dbl));
    }
    else{
        _file_52650 = (int)*(((s1_ptr)_2)->base + _27133);
    }
    if (!IS_ATOM_INT(_file_52650))
    _file_52650 = (long)DBL_PTR(_file_52650)->dbl;

    /** 			ok    = adjust_il( pc, op )*/
    _ok_52655 = _67adjust_il(_pc_52606, _op_52607);
    if (!IS_ATOM_INT(_ok_52655)) {
        _1 = (long)(DBL_PTR(_ok_52655)->dbl);
        DeRefDS(_ok_52655);
        _ok_52655 = _1;
    }

    /** 		inline_code[pc+2+TRANSLATE] = stlen*/
    _27136 = _pc_52606 + 2;
    if ((long)((unsigned long)_27136 + (unsigned long)HIGH_BITS) >= 0) 
    _27136 = NewDouble((double)_27136);
    if (IS_ATOM_INT(_27136)) {
        _27137 = _27136 + _35TRANSLATE_15611;
    }
    else {
        _27137 = NewDouble(DBL_PTR(_27136)->dbl + (double)_35TRANSLATE_15611);
    }
    DeRef(_27136);
    _27136 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27137))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27137)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27137);
    _1 = *(int *)_2;
    *(int *)_2 = _stlen_52645;
    DeRef(_1);

    /** 		inline_code[pc+4+TRANSLATE] = file*/
    _27138 = _pc_52606 + 4;
    if ((long)((unsigned long)_27138 + (unsigned long)HIGH_BITS) >= 0) 
    _27138 = NewDouble((double)_27138);
    if (IS_ATOM_INT(_27138)) {
        _27139 = _27138 + _35TRANSLATE_15611;
    }
    else {
        _27139 = NewDouble(DBL_PTR(_27138)->dbl + (double)_35TRANSLATE_15611);
    }
    DeRef(_27138);
    _27138 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_27139))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_27139)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _27139);
    _1 = *(int *)_2;
    *(int *)_2 = _file_52650;
    DeRef(_1);

    /** 		return ok*/
    DeRef(_27127);
    _27127 = NOVALUE;
    DeRef(_27113);
    _27113 = NOVALUE;
    DeRef(_27130);
    _27130 = NOVALUE;
    DeRef(_27133);
    _27133 = NOVALUE;
    DeRef(_27137);
    _27137 = NOVALUE;
    DeRef(_27139);
    _27139 = NOVALUE;
    return _ok_52655;
    goto L5; // [270] 526
L7: 

    /** 	elsif op_info[op][OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _27140 = (int)*(((s1_ptr)_2)->base + _op_52607);
    _2 = (int)SEQ_PTR(_27140);
    _27141 = (int)*(((s1_ptr)_2)->base + 1);
    _27140 = NOVALUE;
    if (binary_op_a(NOTEQ, _27141, 1)){
        _27141 = NOVALUE;
        goto L8; // [289] 397
    }
    _27141 = NOVALUE;

    /** 		switch op do*/
    _0 = _op_52607;
    switch ( _0 ){ 

        /** 			case SWITCH, SWITCH_RT, SWITCH_I, SWITCH_SPI then*/
        case 185:
        case 202:
        case 193:
        case 192:

        /** 				symtab_index original_table = inline_code[pc + 3]*/
        _27145 = _pc_52606 + 3;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _original_table_52678 = (int)*(((s1_ptr)_2)->base + _27145);
        if (!IS_ATOM_INT(_original_table_52678)){
            _original_table_52678 = (long)DBL_PTR(_original_table_52678)->dbl;
        }

        /** 				symtab_index jump_table = NewStringSym( {-2, length(SymTab) } )*/
        if (IS_SEQUENCE(_36SymTab_14981)){
                _27147 = SEQ_PTR(_36SymTab_14981)->length;
        }
        else {
            _27147 = 1;
        }
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = _27147;
        _27148 = MAKE_SEQ(_1);
        _27147 = NOVALUE;
        _jump_table_52682 = _53NewStringSym(_27148);
        _27148 = NOVALUE;
        if (!IS_ATOM_INT(_jump_table_52682)) {
            _1 = (long)(DBL_PTR(_jump_table_52682)->dbl);
            DeRefDS(_jump_table_52682);
            _jump_table_52682 = _1;
        }

        /** 				SymTab[jump_table][S_OBJ] = SymTab[original_table][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_jump_table_52682 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27152 = (int)*(((s1_ptr)_2)->base + _original_table_52678);
        _2 = (int)SEQ_PTR(_27152);
        _27153 = (int)*(((s1_ptr)_2)->base + 1);
        _27152 = NOVALUE;
        Ref(_27153);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _27153;
        if( _1 != _27153 ){
            DeRef(_1);
        }
        _27153 = NOVALUE;
        _27150 = NOVALUE;

        /** 				inline_code[pc+3] = jump_table*/
        _27154 = _pc_52606 + 3;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27154);
        _1 = *(int *)_2;
        *(int *)_2 = _jump_table_52682;
        DeRef(_1);
    ;}
    /** 		return adjust_il( pc, op )*/
    _27155 = _67adjust_il(_pc_52606, _op_52607);
    DeRef(_27127);
    _27127 = NOVALUE;
    DeRef(_27113);
    _27113 = NOVALUE;
    DeRef(_27145);
    _27145 = NOVALUE;
    DeRef(_27130);
    _27130 = NOVALUE;
    DeRef(_27133);
    _27133 = NOVALUE;
    DeRef(_27137);
    _27137 = NOVALUE;
    DeRef(_27139);
    _27139 = NOVALUE;
    DeRef(_27154);
    _27154 = NOVALUE;
    return _27155;
    goto L5; // [394] 526
L8: 

    /** 		switch op with fallthru do*/
    _0 = _op_52607;
    switch ( _0 ){ 

        /** 			case REF_TEMP then*/
        case 207:

        /** 				inline_code[pc+1] = {INLINE_TARGET}*/
        _27158 = _pc_52606 + 1;
        RefDS(_27073);
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67inline_code_52216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _27158);
        _1 = *(int *)_2;
        *(int *)_2 = _27073;
        DeRef(_1);

        /** 			case CONCAT_N then*/
        case 157:
        case 31:

        /** 				if check_for_param( pc + 2 + inline_code[pc+1] ) then*/
        _27159 = _pc_52606 + 2;
        if ((long)((unsigned long)_27159 + (unsigned long)HIGH_BITS) >= 0) 
        _27159 = NewDouble((double)_27159);
        _27160 = _pc_52606 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27161 = (int)*(((s1_ptr)_2)->base + _27160);
        if (IS_ATOM_INT(_27159) && IS_ATOM_INT(_27161)) {
            _27162 = _27159 + _27161;
            if ((long)((unsigned long)_27162 + (unsigned long)HIGH_BITS) >= 0) 
            _27162 = NewDouble((double)_27162);
        }
        else {
            _27162 = binary_op(PLUS, _27159, _27161);
        }
        DeRef(_27159);
        _27159 = NOVALUE;
        _27161 = NOVALUE;
        _27163 = _67check_for_param(_27162);
        _27162 = NOVALUE;
        if (_27163 == 0) {
            DeRef(_27163);
            _27163 = NOVALUE;
            goto L9; // [450] 454
        }
        else {
            if (!IS_ATOM_INT(_27163) && DBL_PTR(_27163)->dbl == 0.0){
                DeRef(_27163);
                _27163 = NOVALUE;
                goto L9; // [450] 454
            }
            DeRef(_27163);
            _27163 = NOVALUE;
        }
        DeRef(_27163);
        _27163 = NOVALUE;
L9: 

        /** 				for i = pc + 2 to pc + 2 + inline_code[pc+1] do*/
        _27164 = _pc_52606 + 2;
        if ((long)((unsigned long)_27164 + (unsigned long)HIGH_BITS) >= 0) 
        _27164 = NewDouble((double)_27164);
        _27165 = _pc_52606 + 2;
        if ((long)((unsigned long)_27165 + (unsigned long)HIGH_BITS) >= 0) 
        _27165 = NewDouble((double)_27165);
        _27166 = _pc_52606 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27167 = (int)*(((s1_ptr)_2)->base + _27166);
        if (IS_ATOM_INT(_27165) && IS_ATOM_INT(_27167)) {
            _27168 = _27165 + _27167;
            if ((long)((unsigned long)_27168 + (unsigned long)HIGH_BITS) >= 0) 
            _27168 = NewDouble((double)_27168);
        }
        else {
            _27168 = binary_op(PLUS, _27165, _27167);
        }
        DeRef(_27165);
        _27165 = NOVALUE;
        _27167 = NOVALUE;
        {
            int _i_52714;
            Ref(_27164);
            _i_52714 = _27164;
LA: 
            if (binary_op_a(GREATER, _i_52714, _27168)){
                goto LB; // [478] 508
            }

            /** 					if not adjust_symbol( i ) then*/
            Ref(_i_52714);
            _27169 = _67adjust_symbol(_i_52714);
            if (IS_ATOM_INT(_27169)) {
                if (_27169 != 0){
                    DeRef(_27169);
                    _27169 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            else {
                if (DBL_PTR(_27169)->dbl != 0.0){
                    DeRef(_27169);
                    _27169 = NOVALUE;
                    goto LC; // [491] 501
                }
            }
            DeRef(_27169);
            _27169 = NOVALUE;

            /** 						return 0*/
            DeRef(_i_52714);
            DeRef(_27127);
            _27127 = NOVALUE;
            DeRef(_27113);
            _27113 = NOVALUE;
            DeRef(_27145);
            _27145 = NOVALUE;
            DeRef(_27130);
            _27130 = NOVALUE;
            DeRef(_27133);
            _27133 = NOVALUE;
            DeRef(_27137);
            _27137 = NOVALUE;
            DeRef(_27139);
            _27139 = NOVALUE;
            DeRef(_27154);
            _27154 = NOVALUE;
            DeRef(_27155);
            _27155 = NOVALUE;
            DeRef(_27158);
            _27158 = NOVALUE;
            DeRef(_27164);
            _27164 = NOVALUE;
            DeRef(_27160);
            _27160 = NOVALUE;
            DeRef(_27166);
            _27166 = NOVALUE;
            DeRef(_27168);
            _27168 = NOVALUE;
            return 0;
LC: 

            /** 				end for*/
            _0 = _i_52714;
            if (IS_ATOM_INT(_i_52714)) {
                _i_52714 = _i_52714 + 1;
                if ((long)((unsigned long)_i_52714 +(unsigned long) HIGH_BITS) >= 0){
                    _i_52714 = NewDouble((double)_i_52714);
                }
            }
            else {
                _i_52714 = binary_op_a(PLUS, _i_52714, 1);
            }
            DeRef(_0);
            goto LA; // [503] 485
LB: 
            ;
            DeRef(_i_52714);
        }

        /** 				return 1*/
        DeRef(_27127);
        _27127 = NOVALUE;
        DeRef(_27113);
        _27113 = NOVALUE;
        DeRef(_27145);
        _27145 = NOVALUE;
        DeRef(_27130);
        _27130 = NOVALUE;
        DeRef(_27133);
        _27133 = NOVALUE;
        DeRef(_27137);
        _27137 = NOVALUE;
        DeRef(_27139);
        _27139 = NOVALUE;
        DeRef(_27154);
        _27154 = NOVALUE;
        DeRef(_27155);
        _27155 = NOVALUE;
        DeRef(_27158);
        _27158 = NOVALUE;
        DeRef(_27164);
        _27164 = NOVALUE;
        DeRef(_27160);
        _27160 = NOVALUE;
        DeRef(_27166);
        _27166 = NOVALUE;
        DeRef(_27168);
        _27168 = NOVALUE;
        return 1;

        /** 			case else*/
        default:

        /** 				return 0*/
        DeRef(_27127);
        _27127 = NOVALUE;
        DeRef(_27113);
        _27113 = NOVALUE;
        DeRef(_27145);
        _27145 = NOVALUE;
        DeRef(_27130);
        _27130 = NOVALUE;
        DeRef(_27133);
        _27133 = NOVALUE;
        DeRef(_27137);
        _27137 = NOVALUE;
        DeRef(_27139);
        _27139 = NOVALUE;
        DeRef(_27154);
        _27154 = NOVALUE;
        DeRef(_27155);
        _27155 = NOVALUE;
        DeRef(_27158);
        _27158 = NOVALUE;
        DeRef(_27164);
        _27164 = NOVALUE;
        DeRef(_27160);
        _27160 = NOVALUE;
        DeRef(_27166);
        _27166 = NOVALUE;
        DeRef(_27168);
        _27168 = NOVALUE;
        return 0;
    ;}L5: 

    /** 	return 1*/
    DeRef(_27127);
    _27127 = NOVALUE;
    DeRef(_27113);
    _27113 = NOVALUE;
    DeRef(_27145);
    _27145 = NOVALUE;
    DeRef(_27130);
    _27130 = NOVALUE;
    DeRef(_27133);
    _27133 = NOVALUE;
    DeRef(_27137);
    _27137 = NOVALUE;
    DeRef(_27139);
    _27139 = NOVALUE;
    DeRef(_27154);
    _27154 = NOVALUE;
    DeRef(_27155);
    _27155 = NOVALUE;
    DeRef(_27158);
    _27158 = NOVALUE;
    DeRef(_27164);
    _27164 = NOVALUE;
    DeRef(_27160);
    _27160 = NOVALUE;
    DeRef(_27166);
    _27166 = NOVALUE;
    DeRef(_27168);
    _27168 = NOVALUE;
    return 1;
    ;
}


void _67restore_code()
{
    int _27171 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( temp_code ) then*/
    if (IS_SEQUENCE(_67temp_code_52724)){
            _27171 = SEQ_PTR(_67temp_code_52724)->length;
    }
    else {
        _27171 = 1;
    }
    if (_27171 == 0)
    {
        _27171 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _27171 = NOVALUE;
    }

    /** 		Code = temp_code*/
    RefDS(_67temp_code_52724);
    DeRef(_35Code_16056);
    _35Code_16056 = _67temp_code_52724;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67check_inline(int _sub_52733)
{
    int _pc_52762 = NOVALUE;
    int _s_52764 = NOVALUE;
    int _backpatch_op_52802 = NOVALUE;
    int _op_52806 = NOVALUE;
    int _rtn_idx_52817 = NOVALUE;
    int _args_52822 = NOVALUE;
    int _args_52854 = NOVALUE;
    int _values_52883 = NOVALUE;
    int _27258 = NOVALUE;
    int _27257 = NOVALUE;
    int _27255 = NOVALUE;
    int _27252 = NOVALUE;
    int _27250 = NOVALUE;
    int _27249 = NOVALUE;
    int _27248 = NOVALUE;
    int _27246 = NOVALUE;
    int _27245 = NOVALUE;
    int _27244 = NOVALUE;
    int _27243 = NOVALUE;
    int _27242 = NOVALUE;
    int _27241 = NOVALUE;
    int _27240 = NOVALUE;
    int _27239 = NOVALUE;
    int _27238 = NOVALUE;
    int _27236 = NOVALUE;
    int _27235 = NOVALUE;
    int _27234 = NOVALUE;
    int _27233 = NOVALUE;
    int _27232 = NOVALUE;
    int _27230 = NOVALUE;
    int _27229 = NOVALUE;
    int _27228 = NOVALUE;
    int _27227 = NOVALUE;
    int _27226 = NOVALUE;
    int _27224 = NOVALUE;
    int _27223 = NOVALUE;
    int _27222 = NOVALUE;
    int _27221 = NOVALUE;
    int _27220 = NOVALUE;
    int _27219 = NOVALUE;
    int _27218 = NOVALUE;
    int _27217 = NOVALUE;
    int _27216 = NOVALUE;
    int _27215 = NOVALUE;
    int _27214 = NOVALUE;
    int _27213 = NOVALUE;
    int _27212 = NOVALUE;
    int _27211 = NOVALUE;
    int _27209 = NOVALUE;
    int _27206 = NOVALUE;
    int _27201 = NOVALUE;
    int _27199 = NOVALUE;
    int _27196 = NOVALUE;
    int _27195 = NOVALUE;
    int _27194 = NOVALUE;
    int _27193 = NOVALUE;
    int _27192 = NOVALUE;
    int _27191 = NOVALUE;
    int _27190 = NOVALUE;
    int _27189 = NOVALUE;
    int _27187 = NOVALUE;
    int _27185 = NOVALUE;
    int _27184 = NOVALUE;
    int _27182 = NOVALUE;
    int _27180 = NOVALUE;
    int _27178 = NOVALUE;
    int _27176 = NOVALUE;
    int _27175 = NOVALUE;
    int _27174 = NOVALUE;
    int _27173 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_52733)) {
        _1 = (long)(DBL_PTR(_sub_52733)->dbl);
        DeRefDS(_sub_52733);
        _sub_52733 = _1;
    }

    /** 	if OpTrace or SymTab[sub][S_TOKEN] = TYPE then*/
    if (_35OpTrace_16037 != 0) {
        goto L1; // [7] 34
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27173 = (int)*(((s1_ptr)_2)->base + _sub_52733);
    _2 = (int)SEQ_PTR(_27173);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _27174 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _27174 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _27173 = NOVALUE;
    if (IS_ATOM_INT(_27174)) {
        _27175 = (_27174 == 504);
    }
    else {
        _27175 = binary_op(EQUALS, _27174, 504);
    }
    _27174 = NOVALUE;
    if (_27175 == 0) {
        DeRef(_27175);
        _27175 = NOVALUE;
        goto L2; // [30] 40
    }
    else {
        if (!IS_ATOM_INT(_27175) && DBL_PTR(_27175)->dbl == 0.0){
            DeRef(_27175);
            _27175 = NOVALUE;
            goto L2; // [30] 40
        }
        DeRef(_27175);
        _27175 = NOVALUE;
    }
    DeRef(_27175);
    _27175 = NOVALUE;
L1: 

    /** 		return*/
    DeRefi(_backpatch_op_52802);
    return;
L2: 

    /** 	inline_sub      = sub*/
    _67inline_sub_52230 = _sub_52733;

    /** 	if get_fwdref_count() then*/
    _27176 = _38get_fwdref_count();
    if (_27176 == 0) {
        DeRef(_27176);
        _27176 = NOVALUE;
        goto L3; // [52] 65
    }
    else {
        if (!IS_ATOM_INT(_27176) && DBL_PTR(_27176)->dbl == 0.0){
            DeRef(_27176);
            _27176 = NOVALUE;
            goto L3; // [52] 65
        }
        DeRef(_27176);
        _27176 = NOVALUE;
    }
    DeRef(_27176);
    _27176 = NOVALUE;

    /** 		defer()*/
    _67defer();

    /** 		return*/
    DeRefi(_backpatch_op_52802);
    return;
L3: 

    /** 	temp_code = ""*/
    RefDS(_21815);
    DeRef(_67temp_code_52724);
    _67temp_code_52724 = _21815;

    /** 	if sub != CurrentSub then*/
    if (_sub_52733 == _35CurrentSub_15976)
    goto L4; // [76] 99

    /** 		Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27178 = (int)*(((s1_ptr)_2)->base + _sub_52733);
    DeRef(_35Code_16056);
    _2 = (int)SEQ_PTR(_27178);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    Ref(_35Code_16056);
    _27178 = NOVALUE;
    goto L5; // [96] 109
L4: 

    /** 		temp_code = Code*/
    RefDS(_35Code_16056);
    DeRef(_67temp_code_52724);
    _67temp_code_52724 = _35Code_16056;
L5: 

    /** 	if length(Code) > OpInline then*/
    if (IS_SEQUENCE(_35Code_16056)){
            _27180 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _27180 = 1;
    }
    if (_27180 <= _35OpInline_16042)
    goto L6; // [118] 128

    /** 		return*/
    DeRefi(_backpatch_op_52802);
    return;
L6: 

    /** 	inline_code     = Code*/
    RefDS(_35Code_16056);
    DeRef(_67inline_code_52216);
    _67inline_code_52216 = _35Code_16056;

    /** 	return_gotos    = 0*/
    _67return_gotos_52225 = 0;

    /** 	prev_pc         = 1*/
    _67prev_pc_52224 = 1;

    /** 	proc_vars       = {}*/
    RefDS(_21815);
    DeRefi(_67proc_vars_52217);
    _67proc_vars_52217 = _21815;

    /** 	inline_temps    = {}*/
    RefDS(_21815);
    DeRef(_67inline_temps_52218);
    _67inline_temps_52218 = _21815;

    /** 	inline_params   = {}*/
    RefDS(_21815);
    DeRefi(_67inline_params_52221);
    _67inline_params_52221 = _21815;

    /** 	assigned_params = {}*/
    RefDS(_21815);
    DeRef(_67assigned_params_52222);
    _67assigned_params_52222 = _21815;

    /** 	integer pc = 1*/
    _pc_52762 = 1;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27182 = (int)*(((s1_ptr)_2)->base + _sub_52733);
    _2 = (int)SEQ_PTR(_27182);
    _s_52764 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_52764)){
        _s_52764 = (long)DBL_PTR(_s_52764)->dbl;
    }
    _27182 = NOVALUE;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27184 = (int)*(((s1_ptr)_2)->base + _sub_52733);
    _2 = (int)SEQ_PTR(_27184);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _27185 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _27185 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _27184 = NOVALUE;
    {
        int _p_52770;
        _p_52770 = 1;
L7: 
        if (binary_op_a(GREATER, _p_52770, _27185)){
            goto L8; // [210] 248
        }

        /** 		inline_params &= s*/
        Append(&_67inline_params_52221, _67inline_params_52221, _s_52764);

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27187 = (int)*(((s1_ptr)_2)->base + _s_52764);
        _2 = (int)SEQ_PTR(_27187);
        _s_52764 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_52764)){
            _s_52764 = (long)DBL_PTR(_s_52764)->dbl;
        }
        _27187 = NOVALUE;

        /** 	end for*/
        _0 = _p_52770;
        if (IS_ATOM_INT(_p_52770)) {
            _p_52770 = _p_52770 + 1;
            if ((long)((unsigned long)_p_52770 +(unsigned long) HIGH_BITS) >= 0){
                _p_52770 = NewDouble((double)_p_52770);
            }
        }
        else {
            _p_52770 = binary_op_a(PLUS, _p_52770, 1);
        }
        DeRef(_0);
        goto L7; // [243] 217
L8: 
        ;
        DeRef(_p_52770);
    }

    /** 	while s != 0 and */
L9: 
    _27189 = (_s_52764 != 0);
    if (_27189 == 0) {
        goto LA; // [257] 335
    }
    _27191 = _53sym_scope(_s_52764);
    if (IS_ATOM_INT(_27191)) {
        _27192 = (_27191 <= 3);
    }
    else {
        _27192 = binary_op(LESSEQ, _27191, 3);
    }
    DeRef(_27191);
    _27191 = NOVALUE;
    if (IS_ATOM_INT(_27192)) {
        if (_27192 != 0) {
            DeRef(_27193);
            _27193 = 1;
            goto LB; // [271] 289
        }
    }
    else {
        if (DBL_PTR(_27192)->dbl != 0.0) {
            DeRef(_27193);
            _27193 = 1;
            goto LB; // [271] 289
        }
    }
    _27194 = _53sym_scope(_s_52764);
    if (IS_ATOM_INT(_27194)) {
        _27195 = (_27194 == 9);
    }
    else {
        _27195 = binary_op(EQUALS, _27194, 9);
    }
    DeRef(_27194);
    _27194 = NOVALUE;
    DeRef(_27193);
    if (IS_ATOM_INT(_27195))
    _27193 = (_27195 != 0);
    else
    _27193 = DBL_PTR(_27195)->dbl != 0.0;
LB: 
    if (_27193 == 0)
    {
        _27193 = NOVALUE;
        goto LA; // [290] 335
    }
    else{
        _27193 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27196 = _53sym_scope(_s_52764);
    if (binary_op_a(EQUALS, _27196, 9)){
        DeRef(_27196);
        _27196 = NOVALUE;
        goto LC; // [301] 314
    }
    DeRef(_27196);
    _27196 = NOVALUE;

    /** 			proc_vars &= s*/
    Append(&_67proc_vars_52217, _67proc_vars_52217, _s_52764);
LC: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27199 = (int)*(((s1_ptr)_2)->base + _s_52764);
    _2 = (int)SEQ_PTR(_27199);
    _s_52764 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_52764)){
        _s_52764 = (long)DBL_PTR(_s_52764)->dbl;
    }
    _27199 = NOVALUE;

    /** 	end while*/
    goto L9; // [332] 253
LA: 

    /** 	sequence backpatch_op = {}*/
    RefDS(_21815);
    DeRefi(_backpatch_op_52802);
    _backpatch_op_52802 = _21815;

    /** 	while pc < length( inline_code ) do*/
LD: 
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27201 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27201 = 1;
    }
    if (_pc_52762 >= _27201)
    goto LE; // [352] 869

    /** 		integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _op_52806 = (int)*(((s1_ptr)_2)->base + _pc_52762);
    if (!IS_ATOM_INT(_op_52806))
    _op_52806 = (long)DBL_PTR(_op_52806)->dbl;

    /** 		switch op do*/
    _0 = _op_52806;
    switch ( _0 ){ 

        /** 			case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 				defer()*/
        _67defer();

        /** 				restore_code()*/
        _67restore_code();

        /** 				return*/
        DeRefi(_backpatch_op_52802);
        _27185 = NOVALUE;
        DeRef(_27189);
        _27189 = NOVALUE;
        DeRef(_27192);
        _27192 = NOVALUE;
        DeRef(_27195);
        _27195 = NOVALUE;
        return;
        goto LF; // [390] 851

        /** 			case PROC, FUNC then*/
        case 27:
        case 501:

        /** 				symtab_index rtn_idx = inline_code[pc+1]*/
        _27206 = _pc_52762 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _rtn_idx_52817 = (int)*(((s1_ptr)_2)->base + _27206);
        if (!IS_ATOM_INT(_rtn_idx_52817)){
            _rtn_idx_52817 = (long)DBL_PTR(_rtn_idx_52817)->dbl;
        }

        /** 				if rtn_idx = sub then*/
        if (_rtn_idx_52817 != _sub_52733)
        goto L10; // [414] 428

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52802);
        _27185 = NOVALUE;
        DeRef(_27189);
        _27189 = NOVALUE;
        _27206 = NOVALUE;
        DeRef(_27192);
        _27192 = NOVALUE;
        DeRef(_27195);
        _27195 = NOVALUE;
        return;
L10: 

        /** 				integer args = SymTab[rtn_idx][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27209 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52817);
        _2 = (int)SEQ_PTR(_27209);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
            _args_52822 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
        }
        else{
            _args_52822 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
        }
        if (!IS_ATOM_INT(_args_52822)){
            _args_52822 = (long)DBL_PTR(_args_52822)->dbl;
        }
        _27209 = NOVALUE;

        /** 				if SymTab[rtn_idx][S_TOKEN] != PROC and check_for_param( pc + args + 2 ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27211 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52817);
        _2 = (int)SEQ_PTR(_27211);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _27212 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _27212 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _27211 = NOVALUE;
        if (IS_ATOM_INT(_27212)) {
            _27213 = (_27212 != 27);
        }
        else {
            _27213 = binary_op(NOTEQ, _27212, 27);
        }
        _27212 = NOVALUE;
        if (IS_ATOM_INT(_27213)) {
            if (_27213 == 0) {
                goto L11; // [464] 485
            }
        }
        else {
            if (DBL_PTR(_27213)->dbl == 0.0) {
                goto L11; // [464] 485
            }
        }
        _27215 = _pc_52762 + _args_52822;
        if ((long)((unsigned long)_27215 + (unsigned long)HIGH_BITS) >= 0) 
        _27215 = NewDouble((double)_27215);
        if (IS_ATOM_INT(_27215)) {
            _27216 = _27215 + 2;
            if ((long)((unsigned long)_27216 + (unsigned long)HIGH_BITS) >= 0) 
            _27216 = NewDouble((double)_27216);
        }
        else {
            _27216 = NewDouble(DBL_PTR(_27215)->dbl + (double)2);
        }
        DeRef(_27215);
        _27215 = NOVALUE;
        _27217 = _67check_for_param(_27216);
        _27216 = NOVALUE;
        if (_27217 == 0) {
            DeRef(_27217);
            _27217 = NOVALUE;
            goto L11; // [481] 485
        }
        else {
            if (!IS_ATOM_INT(_27217) && DBL_PTR(_27217)->dbl == 0.0){
                DeRef(_27217);
                _27217 = NOVALUE;
                goto L11; // [481] 485
            }
            DeRef(_27217);
            _27217 = NOVALUE;
        }
        DeRef(_27217);
        _27217 = NOVALUE;
L11: 

        /** 				for i = 2 to args + 1 + (SymTab[rtn_idx][S_TOKEN] != PROC) do*/
        _27218 = _args_52822 + 1;
        if (_27218 > MAXINT){
            _27218 = NewDouble((double)_27218);
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27219 = (int)*(((s1_ptr)_2)->base + _rtn_idx_52817);
        _2 = (int)SEQ_PTR(_27219);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _27220 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _27220 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _27219 = NOVALUE;
        if (IS_ATOM_INT(_27220)) {
            _27221 = (_27220 != 27);
        }
        else {
            _27221 = binary_op(NOTEQ, _27220, 27);
        }
        _27220 = NOVALUE;
        if (IS_ATOM_INT(_27218) && IS_ATOM_INT(_27221)) {
            _27222 = _27218 + _27221;
            if ((long)((unsigned long)_27222 + (unsigned long)HIGH_BITS) >= 0) 
            _27222 = NewDouble((double)_27222);
        }
        else {
            _27222 = binary_op(PLUS, _27218, _27221);
        }
        DeRef(_27218);
        _27218 = NOVALUE;
        DeRef(_27221);
        _27221 = NOVALUE;
        {
            int _i_52839;
            _i_52839 = 2;
L12: 
            if (binary_op_a(GREATER, _i_52839, _27222)){
                goto L13; // [513] 550
            }

            /** 					if not adjust_symbol( pc + i ) then */
            if (IS_ATOM_INT(_i_52839)) {
                _27223 = _pc_52762 + _i_52839;
                if ((long)((unsigned long)_27223 + (unsigned long)HIGH_BITS) >= 0) 
                _27223 = NewDouble((double)_27223);
            }
            else {
                _27223 = NewDouble((double)_pc_52762 + DBL_PTR(_i_52839)->dbl);
            }
            _27224 = _67adjust_symbol(_27223);
            _27223 = NOVALUE;
            if (IS_ATOM_INT(_27224)) {
                if (_27224 != 0){
                    DeRef(_27224);
                    _27224 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            else {
                if (DBL_PTR(_27224)->dbl != 0.0){
                    DeRef(_27224);
                    _27224 = NOVALUE;
                    goto L14; // [530] 543
                }
            }
            DeRef(_27224);
            _27224 = NOVALUE;

            /** 						defer()*/
            _67defer();

            /** 						return*/
            DeRef(_i_52839);
            DeRefi(_backpatch_op_52802);
            _27185 = NOVALUE;
            DeRef(_27189);
            _27189 = NOVALUE;
            DeRef(_27206);
            _27206 = NOVALUE;
            DeRef(_27192);
            _27192 = NOVALUE;
            DeRef(_27195);
            _27195 = NOVALUE;
            DeRef(_27213);
            _27213 = NOVALUE;
            DeRef(_27222);
            _27222 = NOVALUE;
            return;
L14: 

            /** 				end for*/
            _0 = _i_52839;
            if (IS_ATOM_INT(_i_52839)) {
                _i_52839 = _i_52839 + 1;
                if ((long)((unsigned long)_i_52839 +(unsigned long) HIGH_BITS) >= 0){
                    _i_52839 = NewDouble((double)_i_52839);
                }
            }
            else {
                _i_52839 = binary_op_a(PLUS, _i_52839, 1);
            }
            DeRef(_0);
            goto L12; // [545] 520
L13: 
            ;
            DeRef(_i_52839);
        }
        goto LF; // [552] 851

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				sequence args = inline_code[pc+2..inline_code[pc+1] + pc + 1]*/
        _27226 = _pc_52762 + 2;
        if ((long)((unsigned long)_27226 + (unsigned long)HIGH_BITS) >= 0) 
        _27226 = NewDouble((double)_27226);
        _27227 = _pc_52762 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27228 = (int)*(((s1_ptr)_2)->base + _27227);
        if (IS_ATOM_INT(_27228)) {
            _27229 = _27228 + _pc_52762;
            if ((long)((unsigned long)_27229 + (unsigned long)HIGH_BITS) >= 0) 
            _27229 = NewDouble((double)_27229);
        }
        else {
            _27229 = binary_op(PLUS, _27228, _pc_52762);
        }
        _27228 = NOVALUE;
        if (IS_ATOM_INT(_27229)) {
            _27230 = _27229 + 1;
        }
        else
        _27230 = binary_op(PLUS, 1, _27229);
        DeRef(_27229);
        _27229 = NOVALUE;
        rhs_slice_target = (object_ptr)&_args_52854;
        RHS_Slice(_67inline_code_52216, _27226, _27230);

        /** 				for i = 1 to length(args) - 1 do*/
        if (IS_SEQUENCE(_args_52854)){
                _27232 = SEQ_PTR(_args_52854)->length;
        }
        else {
            _27232 = 1;
        }
        _27233 = _27232 - 1;
        _27232 = NOVALUE;
        {
            int _i_52862;
            _i_52862 = 1;
L15: 
            if (_i_52862 > _27233){
                goto L16; // [598] 644
            }

            /** 					if find( args[i], args, i + 1 ) then*/
            _2 = (int)SEQ_PTR(_args_52854);
            _27234 = (int)*(((s1_ptr)_2)->base + _i_52862);
            _27235 = _i_52862 + 1;
            _27236 = find_from(_27234, _args_52854, _27235);
            _27234 = NOVALUE;
            _27235 = NOVALUE;
            if (_27236 == 0)
            {
                _27236 = NOVALUE;
                goto L17; // [620] 637
            }
            else{
                _27236 = NOVALUE;
            }

            /** 						defer()*/
            _67defer();

            /** 						restore_code()*/
            _67restore_code();

            /** 						return*/
            DeRefDS(_args_52854);
            DeRefi(_backpatch_op_52802);
            _27185 = NOVALUE;
            DeRef(_27189);
            _27189 = NOVALUE;
            DeRef(_27206);
            _27206 = NOVALUE;
            DeRef(_27192);
            _27192 = NOVALUE;
            DeRef(_27195);
            _27195 = NOVALUE;
            DeRef(_27226);
            _27226 = NOVALUE;
            DeRef(_27213);
            _27213 = NOVALUE;
            DeRef(_27222);
            _27222 = NOVALUE;
            DeRef(_27227);
            _27227 = NOVALUE;
            DeRef(_27230);
            _27230 = NOVALUE;
            DeRef(_27233);
            _27233 = NOVALUE;
            return;
L17: 

            /** 				end for*/
            _i_52862 = _i_52862 + 1;
            goto L15; // [639] 605
L16: 
            ;
        }

        /** 				goto "inline op"*/
        DeRef(_args_52854);
        _args_52854 = NOVALUE;
        goto G18;
        goto LF; // [654] 851

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				if equal( inline_code[pc+1], inline_code[pc+2] ) then*/
        _27238 = _pc_52762 + 1;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27239 = (int)*(((s1_ptr)_2)->base + _27238);
        _27240 = _pc_52762 + 2;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27241 = (int)*(((s1_ptr)_2)->base + _27240);
        if (_27239 == _27241)
        _27242 = 1;
        else if (IS_ATOM_INT(_27239) && IS_ATOM_INT(_27241))
        _27242 = 0;
        else
        _27242 = (compare(_27239, _27241) == 0);
        _27239 = NOVALUE;
        _27241 = NOVALUE;
        if (_27242 == 0)
        {
            _27242 = NOVALUE;
            goto L19; // [686] 703
        }
        else{
            _27242 = NOVALUE;
        }

        /** 					defer()*/
        _67defer();

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52802);
        _27185 = NOVALUE;
        DeRef(_27189);
        _27189 = NOVALUE;
        DeRef(_27206);
        _27206 = NOVALUE;
        DeRef(_27192);
        _27192 = NOVALUE;
        DeRef(_27195);
        _27195 = NOVALUE;
        DeRef(_27226);
        _27226 = NOVALUE;
        DeRef(_27213);
        _27213 = NOVALUE;
        DeRef(_27222);
        _27222 = NOVALUE;
        DeRef(_27227);
        _27227 = NOVALUE;
        DeRef(_27230);
        _27230 = NOVALUE;
        DeRef(_27233);
        _27233 = NOVALUE;
        _27238 = NOVALUE;
        _27240 = NOVALUE;
        return;
L19: 

        /** 				goto "inline op"*/
        goto G18;
        goto LF; // [711] 851

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				replace_code( "", pc, pc + 1 )*/
        _27243 = _pc_52762 + 1;
        if (_27243 > MAXINT){
            _27243 = NewDouble((double)_27243);
        }
        RefDS(_21815);
        _67replace_code(_21815, _pc_52762, _27243);
        _27243 = NOVALUE;

        /** 				continue*/
        goto LD; // [732] 347
        goto LF; // [734] 851

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				sequence values = SymTab[inline_code[pc+2]][S_OBJ]*/
        _27244 = _pc_52762 + 2;
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27245 = (int)*(((s1_ptr)_2)->base + _27244);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_27245)){
            _27246 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27245)->dbl));
        }
        else{
            _27246 = (int)*(((s1_ptr)_2)->base + _27245);
        }
        DeRef(_values_52883);
        _2 = (int)SEQ_PTR(_27246);
        _values_52883 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_values_52883);
        _27246 = NOVALUE;

        /** 				for i = 1 to length( values ) do*/
        if (IS_SEQUENCE(_values_52883)){
                _27248 = SEQ_PTR(_values_52883)->length;
        }
        else {
            _27248 = 1;
        }
        {
            int _i_52891;
            _i_52891 = 1;
L1A: 
            if (_i_52891 > _27248){
                goto L1B; // [771] 811
            }

            /** 					if sequence( values[i] ) then*/
            _2 = (int)SEQ_PTR(_values_52883);
            _27249 = (int)*(((s1_ptr)_2)->base + _i_52891);
            _27250 = IS_SEQUENCE(_27249);
            _27249 = NOVALUE;
            if (_27250 == 0)
            {
                _27250 = NOVALUE;
                goto L1C; // [787] 804
            }
            else{
                _27250 = NOVALUE;
            }

            /** 						defer()*/
            _67defer();

            /** 						restore_code()*/
            _67restore_code();

            /** 						return*/
            DeRefDS(_values_52883);
            DeRefi(_backpatch_op_52802);
            _27185 = NOVALUE;
            DeRef(_27189);
            _27189 = NOVALUE;
            DeRef(_27206);
            _27206 = NOVALUE;
            DeRef(_27192);
            _27192 = NOVALUE;
            DeRef(_27195);
            _27195 = NOVALUE;
            DeRef(_27226);
            _27226 = NOVALUE;
            DeRef(_27213);
            _27213 = NOVALUE;
            DeRef(_27222);
            _27222 = NOVALUE;
            DeRef(_27227);
            _27227 = NOVALUE;
            DeRef(_27230);
            _27230 = NOVALUE;
            DeRef(_27233);
            _27233 = NOVALUE;
            DeRef(_27238);
            _27238 = NOVALUE;
            DeRef(_27244);
            _27244 = NOVALUE;
            DeRef(_27240);
            _27240 = NOVALUE;
            _27245 = NOVALUE;
            return;
L1C: 

            /** 				end for*/
            _i_52891 = _i_52891 + 1;
            goto L1A; // [806] 778
L1B: 
            ;
        }

        /** 				backpatch_op = append( backpatch_op, pc )*/
        Append(&_backpatch_op_52802, _backpatch_op_52802, _pc_52762);
        DeRef(_values_52883);
        _values_52883 = NOVALUE;

        /** 			case else*/
        default:

        /** 			label "inline op"*/
G18:

        /** 				if not inline_op( pc ) then*/
        _27252 = _67inline_op(_pc_52762);
        if (IS_ATOM_INT(_27252)) {
            if (_27252 != 0){
                DeRef(_27252);
                _27252 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        else {
            if (DBL_PTR(_27252)->dbl != 0.0){
                DeRef(_27252);
                _27252 = NOVALUE;
                goto L1D; // [833] 850
            }
        }
        DeRef(_27252);
        _27252 = NOVALUE;

        /** 					defer()*/
        _67defer();

        /** 					restore_code()*/
        _67restore_code();

        /** 					return*/
        DeRefi(_backpatch_op_52802);
        _27185 = NOVALUE;
        DeRef(_27189);
        _27189 = NOVALUE;
        DeRef(_27206);
        _27206 = NOVALUE;
        DeRef(_27192);
        _27192 = NOVALUE;
        DeRef(_27195);
        _27195 = NOVALUE;
        DeRef(_27226);
        _27226 = NOVALUE;
        DeRef(_27213);
        _27213 = NOVALUE;
        DeRef(_27222);
        _27222 = NOVALUE;
        DeRef(_27227);
        _27227 = NOVALUE;
        DeRef(_27230);
        _27230 = NOVALUE;
        DeRef(_27233);
        _27233 = NOVALUE;
        DeRef(_27238);
        _27238 = NOVALUE;
        DeRef(_27244);
        _27244 = NOVALUE;
        DeRef(_27240);
        _27240 = NOVALUE;
        _27245 = NOVALUE;
        return;
L1D: 
    ;}LF: 

    /** 		pc = advance( pc, inline_code )*/
    RefDS(_67inline_code_52216);
    _pc_52762 = _67advance(_pc_52762, _67inline_code_52216);
    if (!IS_ATOM_INT(_pc_52762)) {
        _1 = (long)(DBL_PTR(_pc_52762)->dbl);
        DeRefDS(_pc_52762);
        _pc_52762 = _1;
    }

    /** 	end while*/
    goto LD; // [866] 347
LE: 

    /** 	SymTab[sub][S_INLINE] = { sort( assigned_params ), inline_code, backpatch_op }*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_52733 + ((s1_ptr)_2)->base);
    RefDS(_67assigned_params_52222);
    _27257 = _24sort(_67assigned_params_52222, 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27257;
    RefDS(_67inline_code_52216);
    *((int *)(_2+8)) = _67inline_code_52216;
    RefDS(_backpatch_op_52802);
    *((int *)(_2+12)) = _backpatch_op_52802;
    _27258 = MAKE_SEQ(_1);
    _27257 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _27258;
    if( _1 != _27258 ){
        DeRef(_1);
    }
    _27258 = NOVALUE;
    _27255 = NOVALUE;

    /** 	restore_code()*/
    _67restore_code();

    /** end procedure*/
    DeRefDSi(_backpatch_op_52802);
    _27185 = NOVALUE;
    DeRef(_27189);
    _27189 = NOVALUE;
    DeRef(_27206);
    _27206 = NOVALUE;
    DeRef(_27192);
    _27192 = NOVALUE;
    DeRef(_27195);
    _27195 = NOVALUE;
    DeRef(_27226);
    _27226 = NOVALUE;
    DeRef(_27213);
    _27213 = NOVALUE;
    DeRef(_27222);
    _27222 = NOVALUE;
    DeRef(_27227);
    _27227 = NOVALUE;
    DeRef(_27230);
    _27230 = NOVALUE;
    DeRef(_27233);
    _27233 = NOVALUE;
    DeRef(_27238);
    _27238 = NOVALUE;
    DeRef(_27244);
    _27244 = NOVALUE;
    DeRef(_27240);
    _27240 = NOVALUE;
    _27245 = NOVALUE;
    return;
    ;
}


void _67replace_temp(int _pc_52911)
{
    int _temp_num_52912 = NOVALUE;
    int _needed_52915 = NOVALUE;
    int _27271 = NOVALUE;
    int _27270 = NOVALUE;
    int _27269 = NOVALUE;
    int _27268 = NOVALUE;
    int _27266 = NOVALUE;
    int _27264 = NOVALUE;
    int _27261 = NOVALUE;
    int _27259 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer temp_num = inline_code[pc][2]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27259 = (int)*(((s1_ptr)_2)->base + _pc_52911);
    _2 = (int)SEQ_PTR(_27259);
    _temp_num_52912 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_temp_num_52912)){
        _temp_num_52912 = (long)DBL_PTR(_temp_num_52912)->dbl;
    }
    _27259 = NOVALUE;

    /** 	integer needed = temp_num - length( inline_temps )*/
    if (IS_SEQUENCE(_67inline_temps_52218)){
            _27261 = SEQ_PTR(_67inline_temps_52218)->length;
    }
    else {
        _27261 = 1;
    }
    _needed_52915 = _temp_num_52912 - _27261;
    _27261 = NOVALUE;

    /** 	if needed > 0 then*/
    if (_needed_52915 <= 0)
    goto L1; // [30] 47

    /** 		inline_temps &= repeat( 0, needed )*/
    _27264 = Repeat(0, _needed_52915);
    Concat((object_ptr)&_67inline_temps_52218, _67inline_temps_52218, _27264);
    DeRefDS(_27264);
    _27264 = NOVALUE;
L1: 

    /** 	if not inline_temps[temp_num] then*/
    _2 = (int)SEQ_PTR(_67inline_temps_52218);
    _27266 = (int)*(((s1_ptr)_2)->base + _temp_num_52912);
    if (IS_ATOM_INT(_27266)) {
        if (_27266 != 0){
            _27266 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    else {
        if (DBL_PTR(_27266)->dbl != 0.0){
            _27266 = NOVALUE;
            goto L2; // [55] 100
        }
    }
    _27266 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [62] 84
    }
    else{
    }

    /** 			inline_temps[temp_num] = new_inline_var( -temp_num, 0 )*/
    if ((unsigned long)_temp_num_52912 == 0xC0000000)
    _27268 = (int)NewDouble((double)-0xC0000000);
    else
    _27268 = - _temp_num_52912;
    _27269 = _67new_inline_var(_27268, 0);
    _27268 = NOVALUE;
    _2 = (int)SEQ_PTR(_67inline_temps_52218);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_temps_52218 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_52912);
    _1 = *(int *)_2;
    *(int *)_2 = _27269;
    if( _1 != _27269 ){
        DeRef(_1);
    }
    _27269 = NOVALUE;
    goto L4; // [81] 99
L3: 

    /** 			inline_temps[temp_num] = NewTempSym( TRUE )*/
    _27270 = _53NewTempSym(_13TRUE_437);
    _2 = (int)SEQ_PTR(_67inline_temps_52218);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_temps_52218 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _temp_num_52912);
    _1 = *(int *)_2;
    *(int *)_2 = _27270;
    if( _1 != _27270 ){
        DeRef(_1);
    }
    _27270 = NOVALUE;
L4: 
L2: 

    /** 	inline_code[pc] = inline_temps[temp_num]*/
    _2 = (int)SEQ_PTR(_67inline_temps_52218);
    _27271 = (int)*(((s1_ptr)_2)->base + _temp_num_52912);
    Ref(_27271);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52911);
    _1 = *(int *)_2;
    *(int *)_2 = _27271;
    if( _1 != _27271 ){
        DeRef(_1);
    }
    _27271 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _67get_param_sym(int _pc_52937)
{
    int _il_52938 = NOVALUE;
    int _px_52946 = NOVALUE;
    int _27278 = NOVALUE;
    int _27275 = NOVALUE;
    int _27274 = NOVALUE;
    int _27273 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object il = inline_code[pc]*/
    DeRef(_il_52938);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _il_52938 = (int)*(((s1_ptr)_2)->base + _pc_52937);
    Ref(_il_52938);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_52938))
    _27273 = 1;
    else if (IS_ATOM_DBL(_il_52938))
    _27273 = IS_ATOM_INT(DoubleToInt(_il_52938));
    else
    _27273 = 0;
    if (_27273 == 0)
    {
        _27273 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27273 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27274 = (int)*(((s1_ptr)_2)->base + _pc_52937);
    Ref(_27274);
    DeRef(_il_52938);
    return _27274;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_52938)){
            _27275 = SEQ_PTR(_il_52938)->length;
    }
    else {
        _27275 = 1;
    }
    if (_27275 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_52938);
    _27274 = NOVALUE;
    return _67inline_target_52223;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_52938);
    _px_52946 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_52946)){
        _px_52946 = (long)DBL_PTR(_px_52946)->dbl;
    }

    /** 	return passed_params[px]*/
    _2 = (int)SEQ_PTR(_67passed_params_52219);
    _27278 = (int)*(((s1_ptr)_2)->base + _px_52946);
    Ref(_27278);
    DeRef(_il_52938);
    _27274 = NOVALUE;
    return _27278;
    ;
}


int _67get_original_sym(int _pc_52951)
{
    int _il_52952 = NOVALUE;
    int _px_52960 = NOVALUE;
    int _27285 = NOVALUE;
    int _27282 = NOVALUE;
    int _27281 = NOVALUE;
    int _27280 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_52951)) {
        _1 = (long)(DBL_PTR(_pc_52951)->dbl);
        DeRefDS(_pc_52951);
        _pc_52951 = _1;
    }

    /** 	object il = inline_code[pc]*/
    DeRef(_il_52952);
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _il_52952 = (int)*(((s1_ptr)_2)->base + _pc_52951);
    Ref(_il_52952);

    /** 	if integer( il ) then*/
    if (IS_ATOM_INT(_il_52952))
    _27280 = 1;
    else if (IS_ATOM_DBL(_il_52952))
    _27280 = IS_ATOM_INT(DoubleToInt(_il_52952));
    else
    _27280 = 0;
    if (_27280 == 0)
    {
        _27280 = NOVALUE;
        goto L1; // [16] 34
    }
    else{
        _27280 = NOVALUE;
    }

    /** 		return inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27281 = (int)*(((s1_ptr)_2)->base + _pc_52951);
    Ref(_27281);
    DeRef(_il_52952);
    return _27281;
    goto L2; // [31] 53
L1: 

    /** 	elsif length( il ) = 1 then*/
    if (IS_SEQUENCE(_il_52952)){
            _27282 = SEQ_PTR(_il_52952)->length;
    }
    else {
        _27282 = 1;
    }
    if (_27282 != 1)
    goto L3; // [39] 52

    /** 		return inline_target*/
    DeRef(_il_52952);
    _27281 = NOVALUE;
    return _67inline_target_52223;
L3: 
L2: 

    /** 	integer px = il[2]*/
    _2 = (int)SEQ_PTR(_il_52952);
    _px_52960 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_px_52960)){
        _px_52960 = (long)DBL_PTR(_px_52960)->dbl;
    }

    /** 	return original_params[px]*/
    _2 = (int)SEQ_PTR(_67original_params_52220);
    _27285 = (int)*(((s1_ptr)_2)->base + _px_52960);
    Ref(_27285);
    DeRef(_il_52952);
    _27281 = NOVALUE;
    return _27285;
    ;
}


void _67replace_var(int _pc_52969)
{
    int _27289 = NOVALUE;
    int _27288 = NOVALUE;
    int _27287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inline_code[pc] = proc_vars[inline_code[pc][2]]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27287 = (int)*(((s1_ptr)_2)->base + _pc_52969);
    _2 = (int)SEQ_PTR(_27287);
    _27288 = (int)*(((s1_ptr)_2)->base + 2);
    _27287 = NOVALUE;
    _2 = (int)SEQ_PTR(_67proc_vars_52217);
    if (!IS_ATOM_INT(_27288)){
        _27289 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27288)->dbl));
    }
    else{
        _27289 = (int)*(((s1_ptr)_2)->base + _27288);
    }
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_52969);
    _1 = *(int *)_2;
    *(int *)_2 = _27289;
    if( _1 != _27289 ){
        DeRef(_1);
    }
    _27289 = NOVALUE;

    /** end procedure*/
    _27288 = NOVALUE;
    return;
    ;
}


void _67fix_switch_rt(int _pc_52975)
{
    int _value_table_52977 = NOVALUE;
    int _jump_table_52984 = NOVALUE;
    int _27309 = NOVALUE;
    int _27308 = NOVALUE;
    int _27307 = NOVALUE;
    int _27306 = NOVALUE;
    int _27305 = NOVALUE;
    int _27304 = NOVALUE;
    int _27302 = NOVALUE;
    int _27301 = NOVALUE;
    int _27300 = NOVALUE;
    int _27299 = NOVALUE;
    int _27298 = NOVALUE;
    int _27296 = NOVALUE;
    int _27294 = NOVALUE;
    int _27293 = NOVALUE;
    int _27291 = NOVALUE;
    int _27290 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index value_table = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _27290 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _27290 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27290;
    _27291 = MAKE_SEQ(_1);
    _27290 = NOVALUE;
    _value_table_52977 = _53NewStringSym(_27291);
    _27291 = NOVALUE;
    if (!IS_ATOM_INT(_value_table_52977)) {
        _1 = (long)(DBL_PTR(_value_table_52977)->dbl);
        DeRefDS(_value_table_52977);
        _value_table_52977 = _1;
    }

    /** 	symtab_index jump_table  = NewStringSym( {-1, length(SymTab)} )*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _27293 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _27293 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _27293;
    _27294 = MAKE_SEQ(_1);
    _27293 = NOVALUE;
    _jump_table_52984 = _53NewStringSym(_27294);
    _27294 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_52984)) {
        _1 = (long)(DBL_PTR(_jump_table_52984)->dbl);
        DeRefDS(_jump_table_52984);
        _jump_table_52984 = _1;
    }

    /** 	SymTab[value_table][S_OBJ] = SymTab[inline_code[pc+2]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_value_table_52977 + ((s1_ptr)_2)->base);
    _27298 = _pc_52975 + 2;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27299 = (int)*(((s1_ptr)_2)->base + _27298);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_27299)){
        _27300 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27299)->dbl));
    }
    else{
        _27300 = (int)*(((s1_ptr)_2)->base + _27299);
    }
    _2 = (int)SEQ_PTR(_27300);
    _27301 = (int)*(((s1_ptr)_2)->base + 1);
    _27300 = NOVALUE;
    Ref(_27301);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27301;
    if( _1 != _27301 ){
        DeRef(_1);
    }
    _27301 = NOVALUE;
    _27296 = NOVALUE;

    /** 	SymTab[jump_table][S_OBJ]  = SymTab[inline_code[pc+3]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_52984 + ((s1_ptr)_2)->base);
    _27304 = _pc_52975 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _27305 = (int)*(((s1_ptr)_2)->base + _27304);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_27305)){
        _27306 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27305)->dbl));
    }
    else{
        _27306 = (int)*(((s1_ptr)_2)->base + _27305);
    }
    _2 = (int)SEQ_PTR(_27306);
    _27307 = (int)*(((s1_ptr)_2)->base + 1);
    _27306 = NOVALUE;
    Ref(_27307);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _27307;
    if( _1 != _27307 ){
        DeRef(_1);
    }
    _27307 = NOVALUE;
    _27302 = NOVALUE;

    /** 	inline_code[pc+2] = value_table*/
    _27308 = _pc_52975 + 2;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27308);
    _1 = *(int *)_2;
    *(int *)_2 = _value_table_52977;
    DeRef(_1);

    /** 	inline_code[pc+3] = jump_table*/
    _27309 = _pc_52975 + 3;
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67inline_code_52216 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27309);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_table_52984;
    DeRef(_1);

    /** end procedure*/
    _27308 = NOVALUE;
    _27298 = NOVALUE;
    _27299 = NOVALUE;
    _27304 = NOVALUE;
    _27305 = NOVALUE;
    _27309 = NOVALUE;
    return;
    ;
}


void _67fixup_special_op(int _pc_53014)
{
    int _op_53015 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_53014)) {
        _1 = (long)(DBL_PTR(_pc_53014)->dbl);
        DeRefDS(_pc_53014);
        _pc_53014 = _1;
    }

    /** 	integer op = inline_code[pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _op_53015 = (int)*(((s1_ptr)_2)->base + _pc_53014);
    if (!IS_ATOM_INT(_op_53015))
    _op_53015 = (long)DBL_PTR(_op_53015)->dbl;

    /** 	switch op with fallthru do*/
    _0 = _op_53015;
    switch ( _0 ){ 

        /** 		case SWITCH_RT then*/
        case 202:

        /** 			fix_switch_rt( pc )*/
        _67fix_switch_rt(_pc_53014);

        /** 			break*/
        goto L1; // [29] 32
    ;}L1: 

    /** end procedure*/
    return;
    ;
}


int _67new_inline_var(int _ps_53026, int _reuse_53027)
{
    int _var_53029 = NOVALUE;
    int _vtype_53030 = NOVALUE;
    int _name_53031 = NOVALUE;
    int _s_53033 = NOVALUE;
    int _27372 = NOVALUE;
    int _27371 = NOVALUE;
    int _27369 = NOVALUE;
    int _27366 = NOVALUE;
    int _27365 = NOVALUE;
    int _27363 = NOVALUE;
    int _27360 = NOVALUE;
    int _27359 = NOVALUE;
    int _27358 = NOVALUE;
    int _27356 = NOVALUE;
    int _27351 = NOVALUE;
    int _27346 = NOVALUE;
    int _27345 = NOVALUE;
    int _27344 = NOVALUE;
    int _27343 = NOVALUE;
    int _27340 = NOVALUE;
    int _27338 = NOVALUE;
    int _27335 = NOVALUE;
    int _27330 = NOVALUE;
    int _27329 = NOVALUE;
    int _27328 = NOVALUE;
    int _27327 = NOVALUE;
    int _27326 = NOVALUE;
    int _27323 = NOVALUE;
    int _27322 = NOVALUE;
    int _27321 = NOVALUE;
    int _27320 = NOVALUE;
    int _27319 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ps_53026)) {
        _1 = (long)(DBL_PTR(_ps_53026)->dbl);
        DeRefDS(_ps_53026);
        _ps_53026 = _1;
    }

    /** 		var = 0, */
    _var_53029 = 0;

    /** 	sequence name*/

    /** 	if reuse then*/

    /** 	if not var then*/

    /** 		if ps > 0 then*/
    if (_ps_53026 <= 0)
    goto L1; // [45] 222

    /** 			s = ps*/
    _s_53033 = _ps_53026;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [60] 102
    }
    else{
    }

    /** 				name = sprintf( "%s_inlined_%s", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27319 = (int)*(((s1_ptr)_2)->base + _s_53033);
    _2 = (int)SEQ_PTR(_27319);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27320 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27320 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27319 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27321 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52230);
    _2 = (int)SEQ_PTR(_27321);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27322 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27322 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27321 = NOVALUE;
    Ref(_27322);
    Ref(_27320);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27320;
    ((int *)_2)[2] = _27322;
    _27323 = MAKE_SEQ(_1);
    _27322 = NOVALUE;
    _27320 = NOVALUE;
    DeRefi(_name_53031);
    _name_53031 = EPrintf(-9999999, _27318, _27323);
    DeRefDS(_27323);
    _27323 = NOVALUE;
    goto L3; // [99] 139
L2: 

    /** 				name = sprintf( "%s (from inlined routine '%s'", {SymTab[s][S_NAME], SymTab[inline_sub][S_NAME] })*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27326 = (int)*(((s1_ptr)_2)->base + _s_53033);
    _2 = (int)SEQ_PTR(_27326);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27327 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27327 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27326 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27328 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52230);
    _2 = (int)SEQ_PTR(_27328);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27329 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27329 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27328 = NOVALUE;
    Ref(_27329);
    Ref(_27327);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27327;
    ((int *)_2)[2] = _27329;
    _27330 = MAKE_SEQ(_1);
    _27329 = NOVALUE;
    _27327 = NOVALUE;
    DeRefi(_name_53031);
    _name_53031 = EPrintf(-9999999, _27325, _27330);
    DeRefDS(_27330);
    _27330 = NOVALUE;
L3: 

    /** 			if reuse then*/
    if (_reuse_53027 == 0)
    {
        goto L4; // [141] 163
    }
    else{
    }

    /** 				if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L5; // [148] 203

    /** 					name &= ")"*/
    Concat((object_ptr)&_name_53031, _name_53031, _26113);
    goto L5; // [160] 203
L4: 

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [167] 187
    }
    else{
    }

    /** 					name &= sprintf( "_at_%d", inline_start)*/
    _27335 = EPrintf(-9999999, _27334, _67inline_start_52228);
    Concat((object_ptr)&_name_53031, _name_53031, _27335);
    DeRefDS(_27335);
    _27335 = NOVALUE;
    goto L7; // [184] 202
L6: 

    /** 					name &= sprintf( " at %d)", inline_start)*/
    _27338 = EPrintf(-9999999, _27337, _67inline_start_52228);
    Concat((object_ptr)&_name_53031, _name_53031, _27338);
    DeRefDS(_27338);
    _27338 = NOVALUE;
L7: 
L5: 

    /** 			vtype = SymTab[s][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27340 = (int)*(((s1_ptr)_2)->base + _s_53033);
    _2 = (int)SEQ_PTR(_27340);
    _vtype_53030 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_vtype_53030)){
        _vtype_53030 = (long)DBL_PTR(_vtype_53030)->dbl;
    }
    _27340 = NOVALUE;
    goto L8; // [219] 286
L1: 

    /** 			name = sprintf( "%s_%d", {SymTab[inline_sub][S_NAME], -ps})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27343 = (int)*(((s1_ptr)_2)->base + _67inline_sub_52230);
    _2 = (int)SEQ_PTR(_27343);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27344 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27344 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27343 = NOVALUE;
    if ((unsigned long)_ps_53026 == 0xC0000000)
    _27345 = (int)NewDouble((double)-0xC0000000);
    else
    _27345 = - _ps_53026;
    Ref(_27344);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27344;
    ((int *)_2)[2] = _27345;
    _27346 = MAKE_SEQ(_1);
    _27345 = NOVALUE;
    _27344 = NOVALUE;
    DeRefi(_name_53031);
    _name_53031 = EPrintf(-9999999, _27342, _27346);
    DeRefDS(_27346);
    _27346 = NOVALUE;

    /** 			if reuse then*/
    if (_reuse_53027 == 0)
    {
        goto L9; // [251] 263
    }
    else{
    }

    /** 				name &= "__tmp"*/
    Concat((object_ptr)&_name_53031, _name_53031, _27348);
    goto LA; // [260] 276
L9: 

    /** 				name &= sprintf( "__tmp_at%d", inline_start)*/
    _27351 = EPrintf(-9999999, _27350, _67inline_start_52228);
    Concat((object_ptr)&_name_53031, _name_53031, _27351);
    DeRefDS(_27351);
    _27351 = NOVALUE;
LA: 

    /** 			vtype = object_type*/
    _vtype_53030 = _53object_type_45715;
L8: 

    /** 		if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_15976 != _35TopLevelSub_15975)
    goto LB; // [292] 325

    /** 			var = NewEntry( name, varnum, SC_LOCAL, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53031);
    _var_53029 = _53NewEntry(_name_53031, _67varnum_52227, 5, -100, 2004, 0, _vtype_53030);
    if (!IS_ATOM_INT(_var_53029)) {
        _1 = (long)(DBL_PTR(_var_53029)->dbl);
        DeRefDS(_var_53029);
        _var_53029 = _1;
    }
    goto LC; // [322] 416
LB: 

    /** 			var = NewBasicEntry( name, varnum, SC_PRIVATE, VARIABLE, INLINE_HASHVAL, 0, vtype )*/
    RefDS(_name_53031);
    _var_53029 = _53NewBasicEntry(_name_53031, _67varnum_52227, 3, -100, 2004, 0, _vtype_53030);
    if (!IS_ATOM_INT(_var_53029)) {
        _1 = (long)(DBL_PTR(_var_53029)->dbl);
        DeRefDS(_var_53029);
        _var_53029 = _1;
    }

    /** 			SymTab[var][S_NEXT] = SymTab[last_param][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53029 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27358 = (int)*(((s1_ptr)_2)->base + _67last_param_52231);
    _2 = (int)SEQ_PTR(_27358);
    _27359 = (int)*(((s1_ptr)_2)->base + 2);
    _27358 = NOVALUE;
    Ref(_27359);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _27359;
    if( _1 != _27359 ){
        DeRef(_1);
    }
    _27359 = NOVALUE;
    _27356 = NOVALUE;

    /** 			SymTab[last_param][S_NEXT] = var*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67last_param_52231 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _var_53029;
    DeRef(_1);
    _27360 = NOVALUE;

    /** 			if last_param = last_sym then*/
    if (_67last_param_52231 != _53last_sym_45724)
    goto LD; // [403] 415

    /** 				last_sym = var*/
    _53last_sym_45724 = _var_53029;
LD: 
LC: 

    /** 		if deferred_inlining then*/
    if (_67deferred_inlining_52226 == 0)
    {
        goto LE; // [420] 451
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701)){
        _27365 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    }
    else{
        _27365 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    }
    _27363 = NOVALUE;
    if (IS_ATOM_INT(_27365)) {
        _27366 = _27365 + 1;
        if (_27366 > MAXINT){
            _27366 = NewDouble((double)_27366);
        }
    }
    else
    _27366 = binary_op(PLUS, 1, _27365);
    _27365 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    _1 = *(int *)_2;
    *(int *)_2 = _27366;
    if( _1 != _27366 ){
        DeRef(_1);
    }
    _27366 = NOVALUE;
    _27363 = NOVALUE;
    goto LF; // [448] 471
LE: 

    /** 			if param_num != -1 then*/
    if (_39param_num_53678 == -1)
    goto L10; // [455] 470

    /** 				param_num += 1*/
    _39param_num_53678 = _39param_num_53678 + 1;
L10: 
LF: 

    /** 		SymTab[var][S_USAGE] = U_USED*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_var_53029 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _27369 = NOVALUE;

    /** 		if reuse then*/
    if (_reuse_53027 == 0)
    {
        goto L11; // [490] 513
    }
    else{
    }

    /** 			map:nested_put( inline_var_map, {CurrentSub, ps }, var )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35CurrentSub_15976;
    ((int *)_2)[2] = _ps_53026;
    _27371 = MAKE_SEQ(_1);
    Ref(_67inline_var_map_52235);
    _28nested_put(_67inline_var_map_52235, _27371, _var_53029, 1, 23);
    _27371 = NOVALUE;
L11: 

    /** 	Block_var( var )*/
    _66Block_var(_var_53029);

    /** 	if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L12; // [523] 538
    }
    else{
    }

    /** 		add_ref( {VARIABLE, var} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _var_53029;
    _27372 = MAKE_SEQ(_1);
    _53add_ref(_27372);
    _27372 = NOVALUE;
L12: 

    /** 	return var*/
    DeRefi(_name_53031);
    return _var_53029;
    ;
}


int _67get_inlined_code(int _sub_53163, int _start_53164, int _deferred_53165)
{
    int _is_proc_53166 = NOVALUE;
    int _backpatches_53184 = NOVALUE;
    int _prolog_53190 = NOVALUE;
    int _epilog_53191 = NOVALUE;
    int _s_53207 = NOVALUE;
    int _last_sym_53230 = NOVALUE;
    int _int_sym_53257 = NOVALUE;
    int _param_53265 = NOVALUE;
    int _ax_53268 = NOVALUE;
    int _var_53275 = NOVALUE;
    int _final_target_53290 = NOVALUE;
    int _var_53309 = NOVALUE;
    int _create_target_var_53322 = NOVALUE;
    int _check_pc_53345 = NOVALUE;
    int _op_53349 = NOVALUE;
    int _sym_53358 = NOVALUE;
    int _check_result_53363 = NOVALUE;
    int _inline_type_53441 = NOVALUE;
    int _replace_param_1__tmp_at1341_53452 = NOVALUE;
    int _27527 = NOVALUE;
    int _27526 = NOVALUE;
    int _27525 = NOVALUE;
    int _27524 = NOVALUE;
    int _27523 = NOVALUE;
    int _27522 = NOVALUE;
    int _27521 = NOVALUE;
    int _27520 = NOVALUE;
    int _27518 = NOVALUE;
    int _27515 = NOVALUE;
    int _27512 = NOVALUE;
    int _27511 = NOVALUE;
    int _27510 = NOVALUE;
    int _27509 = NOVALUE;
    int _27508 = NOVALUE;
    int _27507 = NOVALUE;
    int _27506 = NOVALUE;
    int _27505 = NOVALUE;
    int _27501 = NOVALUE;
    int _27500 = NOVALUE;
    int _27499 = NOVALUE;
    int _27498 = NOVALUE;
    int _27494 = NOVALUE;
    int _27493 = NOVALUE;
    int _27492 = NOVALUE;
    int _27491 = NOVALUE;
    int _27490 = NOVALUE;
    int _27489 = NOVALUE;
    int _27488 = NOVALUE;
    int _27486 = NOVALUE;
    int _27485 = NOVALUE;
    int _27484 = NOVALUE;
    int _27483 = NOVALUE;
    int _27482 = NOVALUE;
    int _27481 = NOVALUE;
    int _27480 = NOVALUE;
    int _27479 = NOVALUE;
    int _27478 = NOVALUE;
    int _27477 = NOVALUE;
    int _27476 = NOVALUE;
    int _27474 = NOVALUE;
    int _27472 = NOVALUE;
    int _27470 = NOVALUE;
    int _27469 = NOVALUE;
    int _27467 = NOVALUE;
    int _27466 = NOVALUE;
    int _27463 = NOVALUE;
    int _27462 = NOVALUE;
    int _27460 = NOVALUE;
    int _27458 = NOVALUE;
    int _27453 = NOVALUE;
    int _27449 = NOVALUE;
    int _27446 = NOVALUE;
    int _27442 = NOVALUE;
    int _27435 = NOVALUE;
    int _27434 = NOVALUE;
    int _27433 = NOVALUE;
    int _27432 = NOVALUE;
    int _27431 = NOVALUE;
    int _27430 = NOVALUE;
    int _27429 = NOVALUE;
    int _27427 = NOVALUE;
    int _27422 = NOVALUE;
    int _27419 = NOVALUE;
    int _27414 = NOVALUE;
    int _27413 = NOVALUE;
    int _27411 = NOVALUE;
    int _27410 = NOVALUE;
    int _27409 = NOVALUE;
    int _27406 = NOVALUE;
    int _27405 = NOVALUE;
    int _27404 = NOVALUE;
    int _27403 = NOVALUE;
    int _27402 = NOVALUE;
    int _27401 = NOVALUE;
    int _27400 = NOVALUE;
    int _27398 = NOVALUE;
    int _27397 = NOVALUE;
    int _27396 = NOVALUE;
    int _27394 = NOVALUE;
    int _27392 = NOVALUE;
    int _27391 = NOVALUE;
    int _27390 = NOVALUE;
    int _27389 = NOVALUE;
    int _27388 = NOVALUE;
    int _27387 = NOVALUE;
    int _27386 = NOVALUE;
    int _27383 = NOVALUE;
    int _27382 = NOVALUE;
    int _27380 = NOVALUE;
    int _27379 = NOVALUE;
    int _27377 = NOVALUE;
    int _27376 = NOVALUE;
    int _27374 = NOVALUE;
    int _27373 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sub_53163)) {
        _1 = (long)(DBL_PTR(_sub_53163)->dbl);
        DeRefDS(_sub_53163);
        _sub_53163 = _1;
    }
    if (!IS_ATOM_INT(_start_53164)) {
        _1 = (long)(DBL_PTR(_start_53164)->dbl);
        DeRefDS(_start_53164);
        _start_53164 = _1;
    }
    if (!IS_ATOM_INT(_deferred_53165)) {
        _1 = (long)(DBL_PTR(_deferred_53165)->dbl);
        DeRefDS(_deferred_53165);
        _deferred_53165 = _1;
    }

    /** 	integer is_proc = SymTab[sub][S_TOKEN] = PROC*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27373 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27373);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _27374 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _27374 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _27373 = NOVALUE;
    if (IS_ATOM_INT(_27374)) {
        _is_proc_53166 = (_27374 == 27);
    }
    else {
        _is_proc_53166 = binary_op(EQUALS, _27374, 27);
    }
    _27374 = NOVALUE;
    if (!IS_ATOM_INT(_is_proc_53166)) {
        _1 = (long)(DBL_PTR(_is_proc_53166)->dbl);
        DeRefDS(_is_proc_53166);
        _is_proc_53166 = _1;
    }

    /** 	clear_inline_targets()*/
    _41clear_inline_targets();

    /** 	inline_temps = {}*/
    RefDS(_21815);
    DeRef(_67inline_temps_52218);
    _67inline_temps_52218 = _21815;

    /** 	inline_params = {}*/
    RefDS(_21815);
    DeRefi(_67inline_params_52221);
    _67inline_params_52221 = _21815;

    /** 	assigned_params      = SymTab[sub][S_INLINE][1]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27376 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27376);
    _27377 = (int)*(((s1_ptr)_2)->base + 29);
    _27376 = NOVALUE;
    DeRef(_67assigned_params_52222);
    _2 = (int)SEQ_PTR(_27377);
    _67assigned_params_52222 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_67assigned_params_52222);
    _27377 = NOVALUE;

    /** 	inline_code          = SymTab[sub][S_INLINE][2]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27379 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27379);
    _27380 = (int)*(((s1_ptr)_2)->base + 29);
    _27379 = NOVALUE;
    DeRef(_67inline_code_52216);
    _2 = (int)SEQ_PTR(_27380);
    _67inline_code_52216 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_67inline_code_52216);
    _27380 = NOVALUE;

    /** 	sequence backpatches = SymTab[sub][S_INLINE][3]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27382 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27382);
    _27383 = (int)*(((s1_ptr)_2)->base + 29);
    _27382 = NOVALUE;
    DeRef(_backpatches_53184);
    _2 = (int)SEQ_PTR(_27383);
    _backpatches_53184 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_backpatches_53184);
    _27383 = NOVALUE;

    /** 	passed_params = {}*/
    RefDS(_21815);
    DeRef(_67passed_params_52219);
    _67passed_params_52219 = _21815;

    /** 	original_params = {}*/
    RefDS(_21815);
    DeRef(_67original_params_52220);
    _67original_params_52220 = _21815;

    /** 	proc_vars = {}*/
    RefDS(_21815);
    DeRefi(_67proc_vars_52217);
    _67proc_vars_52217 = _21815;

    /** 	sequence prolog = {}*/
    RefDS(_21815);
    DeRefi(_prolog_53190);
    _prolog_53190 = _21815;

    /** 	sequence epilog = {}*/
    RefDS(_21815);
    DeRef(_epilog_53191);
    _epilog_53191 = _21815;

    /** 	Start_block( EXIT_BLOCK, sprintf("Inline-%s from %s @ %d", */
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27386 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27386);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27387 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27387 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27386 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27388 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_27388);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _27389 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _27389 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _27388 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27387);
    *((int *)(_2+4)) = _27387;
    Ref(_27389);
    *((int *)(_2+8)) = _27389;
    *((int *)(_2+12)) = _start_53164;
    _27390 = MAKE_SEQ(_1);
    _27389 = NOVALUE;
    _27387 = NOVALUE;
    _27391 = EPrintf(-9999999, _27385, _27390);
    DeRefDS(_27390);
    _27390 = NOVALUE;
    _66Start_block(206, _27391);
    _27391 = NOVALUE;

    /** 	symtab_index s = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27392 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27392);
    _s_53207 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53207)){
        _s_53207 = (long)DBL_PTR(_s_53207)->dbl;
    }
    _27392 = NOVALUE;

    /** 	varnum = SymTab[CurrentSub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27394 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_27394);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _67varnum_52227 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _67varnum_52227 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    if (!IS_ATOM_INT(_67varnum_52227)){
        _67varnum_52227 = (long)DBL_PTR(_67varnum_52227)->dbl;
    }
    _27394 = NOVALUE;

    /** 	inline_start = start*/
    _67inline_start_52228 = _start_53164;

    /** 	last_param = CurrentSub*/
    _67last_param_52231 = _35CurrentSub_15976;

    /** 	for p = 1 to SymTab[CurrentSub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27396 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_27396);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _27397 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _27397 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _27396 = NOVALUE;
    {
        int _p_53219;
        _p_53219 = 1;
L1: 
        if (binary_op_a(GREATER, _p_53219, _27397)){
            goto L2; // [250] 282
        }

        /** 		last_param = SymTab[last_param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27398 = (int)*(((s1_ptr)_2)->base + _67last_param_52231);
        _2 = (int)SEQ_PTR(_27398);
        _67last_param_52231 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_67last_param_52231)){
            _67last_param_52231 = (long)DBL_PTR(_67last_param_52231)->dbl;
        }
        _27398 = NOVALUE;

        /** 	end for*/
        _0 = _p_53219;
        if (IS_ATOM_INT(_p_53219)) {
            _p_53219 = _p_53219 + 1;
            if ((long)((unsigned long)_p_53219 +(unsigned long) HIGH_BITS) >= 0){
                _p_53219 = NewDouble((double)_p_53219);
            }
        }
        else {
            _p_53219 = binary_op_a(PLUS, _p_53219, 1);
        }
        DeRef(_0);
        goto L1; // [277] 257
L2: 
        ;
        DeRef(_p_53219);
    }

    /** 	symtab_index last_sym = last_param*/
    _last_sym_53230 = _67last_param_52231;

    /** 	while last_sym and */
L3: 
    if (_last_sym_53230 == 0) {
        goto L4; // [296] 368
    }
    _27401 = _53sym_scope(_last_sym_53230);
    if (IS_ATOM_INT(_27401)) {
        _27402 = (_27401 <= 3);
    }
    else {
        _27402 = binary_op(LESSEQ, _27401, 3);
    }
    DeRef(_27401);
    _27401 = NOVALUE;
    if (IS_ATOM_INT(_27402)) {
        if (_27402 != 0) {
            DeRef(_27403);
            _27403 = 1;
            goto L5; // [310] 328
        }
    }
    else {
        if (DBL_PTR(_27402)->dbl != 0.0) {
            DeRef(_27403);
            _27403 = 1;
            goto L5; // [310] 328
        }
    }
    _27404 = _53sym_scope(_last_sym_53230);
    if (IS_ATOM_INT(_27404)) {
        _27405 = (_27404 == 9);
    }
    else {
        _27405 = binary_op(EQUALS, _27404, 9);
    }
    DeRef(_27404);
    _27404 = NOVALUE;
    DeRef(_27403);
    if (IS_ATOM_INT(_27405))
    _27403 = (_27405 != 0);
    else
    _27403 = DBL_PTR(_27405)->dbl != 0.0;
L5: 
    if (_27403 == 0)
    {
        _27403 = NOVALUE;
        goto L4; // [329] 368
    }
    else{
        _27403 = NOVALUE;
    }

    /** 		last_param = last_sym*/
    _67last_param_52231 = _last_sym_53230;

    /** 		last_sym = SymTab[last_sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27406 = (int)*(((s1_ptr)_2)->base + _last_sym_53230);
    _2 = (int)SEQ_PTR(_27406);
    _last_sym_53230 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_last_sym_53230)){
        _last_sym_53230 = (long)DBL_PTR(_last_sym_53230)->dbl;
    }
    _27406 = NOVALUE;

    /** 		varnum += 1*/
    _67varnum_52227 = _67varnum_52227 + 1;

    /** 	end while*/
    goto L3; // [365] 296
L4: 

    /** 	for p = SymTab[sub][S_NUM_ARGS] to 1 by -1 do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27409 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27409);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _27410 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _27410 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _27409 = NOVALUE;
    {
        int _p_53248;
        Ref(_27410);
        _p_53248 = _27410;
L6: 
        if (binary_op_a(LESS, _p_53248, 1)){
            goto L7; // [382] 407
        }

        /** 		passed_params = prepend( passed_params, Pop() )*/
        _27411 = _41Pop();
        Ref(_27411);
        Prepend(&_67passed_params_52219, _67passed_params_52219, _27411);
        DeRef(_27411);
        _27411 = NOVALUE;

        /** 	end for*/
        _0 = _p_53248;
        if (IS_ATOM_INT(_p_53248)) {
            _p_53248 = _p_53248 + -1;
            if ((long)((unsigned long)_p_53248 +(unsigned long) HIGH_BITS) >= 0){
                _p_53248 = NewDouble((double)_p_53248);
            }
        }
        else {
            _p_53248 = binary_op_a(PLUS, _p_53248, -1);
        }
        DeRef(_0);
        goto L6; // [402] 389
L7: 
        ;
        DeRef(_p_53248);
    }

    /** 	original_params = passed_params*/
    RefDS(_67passed_params_52219);
    DeRef(_67original_params_52220);
    _67original_params_52220 = _67passed_params_52219;

    /** 	symtab_index int_sym = 0*/
    _int_sym_53257 = 0;

    /** 	for p = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27413 = (int)*(((s1_ptr)_2)->base + _sub_53163);
    _2 = (int)SEQ_PTR(_27413);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _27414 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _27414 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _27413 = NOVALUE;
    {
        int _p_53259;
        _p_53259 = 1;
L8: 
        if (binary_op_a(GREATER, _p_53259, _27414)){
            goto L9; // [437] 575
        }

        /** 		symtab_index param = passed_params[p]*/
        _2 = (int)SEQ_PTR(_67passed_params_52219);
        if (!IS_ATOM_INT(_p_53259)){
            _param_53265 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53259)->dbl));
        }
        else{
            _param_53265 = (int)*(((s1_ptr)_2)->base + _p_53259);
        }
        if (!IS_ATOM_INT(_param_53265)){
            _param_53265 = (long)DBL_PTR(_param_53265)->dbl;
        }

        /** 		inline_params &= s*/
        Append(&_67inline_params_52221, _67inline_params_52221, _s_53207);

        /** 		integer ax = find( p, assigned_params )*/
        _ax_53268 = find_from(_p_53259, _67assigned_params_52222, 1);

        /** 		if ax or is_temp( param ) then*/
        if (_ax_53268 != 0) {
            goto LA; // [473] 486
        }
        _27419 = _67is_temp(_param_53265);
        if (_27419 == 0) {
            DeRef(_27419);
            _27419 = NOVALUE;
            goto LB; // [482] 548
        }
        else {
            if (!IS_ATOM_INT(_27419) && DBL_PTR(_27419)->dbl == 0.0){
                DeRef(_27419);
                _27419 = NOVALUE;
                goto LB; // [482] 548
            }
            DeRef(_27419);
            _27419 = NOVALUE;
        }
        DeRef(_27419);
        _27419 = NOVALUE;
LA: 

        /** 			varnum += 1*/
        _67varnum_52227 = _67varnum_52227 + 1;

        /** 			symtab_index var = new_inline_var( s, 0 )*/
        _var_53275 = _67new_inline_var(_s_53207, 0);
        if (!IS_ATOM_INT(_var_53275)) {
            _1 = (long)(DBL_PTR(_var_53275)->dbl);
            DeRefDS(_var_53275);
            _var_53275 = _1;
        }

        /** 			prolog &= {ASSIGN, param, var}*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 18;
        *((int *)(_2+8)) = _param_53265;
        *((int *)(_2+12)) = _var_53275;
        _27422 = MAKE_SEQ(_1);
        Concat((object_ptr)&_prolog_53190, _prolog_53190, _27422);
        DeRefDS(_27422);
        _27422 = NOVALUE;

        /** 			if not int_sym then*/
        if (_int_sym_53257 != 0)
        goto LC; // [519] 531

        /** 				int_sym = NewIntSym( 0 )*/
        _int_sym_53257 = _53NewIntSym(0);
        if (!IS_ATOM_INT(_int_sym_53257)) {
            _1 = (long)(DBL_PTR(_int_sym_53257)->dbl);
            DeRefDS(_int_sym_53257);
            _int_sym_53257 = _1;
        }
LC: 

        /** 			inline_start += 3*/
        _67inline_start_52228 = _67inline_start_52228 + 3;

        /** 			passed_params[p] = var*/
        _2 = (int)SEQ_PTR(_67passed_params_52219);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67passed_params_52219 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_p_53259))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_p_53259)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _p_53259);
        _1 = *(int *)_2;
        *(int *)_2 = _var_53275;
        DeRef(_1);
LB: 

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27427 = (int)*(((s1_ptr)_2)->base + _s_53207);
        _2 = (int)SEQ_PTR(_27427);
        _s_53207 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_53207)){
            _s_53207 = (long)DBL_PTR(_s_53207)->dbl;
        }
        _27427 = NOVALUE;

        /** 	end for*/
        _0 = _p_53259;
        if (IS_ATOM_INT(_p_53259)) {
            _p_53259 = _p_53259 + 1;
            if ((long)((unsigned long)_p_53259 +(unsigned long) HIGH_BITS) >= 0){
                _p_53259 = NewDouble((double)_p_53259);
            }
        }
        else {
            _p_53259 = binary_op_a(PLUS, _p_53259, 1);
        }
        DeRef(_0);
        goto L8; // [570] 444
L9: 
        ;
        DeRef(_p_53259);
    }

    /** 	symtab_index final_target = 0*/
    _final_target_53290 = 0;

    /** 	while s and */
LD: 
    if (_s_53207 == 0) {
        goto LE; // [587] 699
    }
    _27430 = _53sym_scope(_s_53207);
    if (IS_ATOM_INT(_27430)) {
        _27431 = (_27430 <= 3);
    }
    else {
        _27431 = binary_op(LESSEQ, _27430, 3);
    }
    DeRef(_27430);
    _27430 = NOVALUE;
    if (IS_ATOM_INT(_27431)) {
        if (_27431 != 0) {
            DeRef(_27432);
            _27432 = 1;
            goto LF; // [601] 619
        }
    }
    else {
        if (DBL_PTR(_27431)->dbl != 0.0) {
            DeRef(_27432);
            _27432 = 1;
            goto LF; // [601] 619
        }
    }
    _27433 = _53sym_scope(_s_53207);
    if (IS_ATOM_INT(_27433)) {
        _27434 = (_27433 == 9);
    }
    else {
        _27434 = binary_op(EQUALS, _27433, 9);
    }
    DeRef(_27433);
    _27433 = NOVALUE;
    DeRef(_27432);
    if (IS_ATOM_INT(_27434))
    _27432 = (_27434 != 0);
    else
    _27432 = DBL_PTR(_27434)->dbl != 0.0;
LF: 
    if (_27432 == 0)
    {
        _27432 = NOVALUE;
        goto LE; // [620] 699
    }
    else{
        _27432 = NOVALUE;
    }

    /** 		if sym_scope( s ) != SC_UNDEFINED then*/
    _27435 = _53sym_scope(_s_53207);
    if (binary_op_a(EQUALS, _27435, 9)){
        DeRef(_27435);
        _27435 = NOVALUE;
        goto L10; // [631] 676
    }
    DeRef(_27435);
    _27435 = NOVALUE;

    /** 			varnum += 1*/
    _67varnum_52227 = _67varnum_52227 + 1;

    /** 			symtab_index var = new_inline_var( s, 0 )*/
    _var_53309 = _67new_inline_var(_s_53207, 0);
    if (!IS_ATOM_INT(_var_53309)) {
        _1 = (long)(DBL_PTR(_var_53309)->dbl);
        DeRefDS(_var_53309);
        _var_53309 = _1;
    }

    /** 			proc_vars &= var*/
    Append(&_67proc_vars_52217, _67proc_vars_52217, _var_53309);

    /** 			if int_sym = 0 then*/
    if (_int_sym_53257 != 0)
    goto L11; // [662] 675

    /** 				int_sym = NewIntSym( 0 )*/
    _int_sym_53257 = _53NewIntSym(0);
    if (!IS_ATOM_INT(_int_sym_53257)) {
        _1 = (long)(DBL_PTR(_int_sym_53257)->dbl);
        DeRefDS(_int_sym_53257);
        _int_sym_53257 = _1;
    }
L11: 
L10: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27442 = (int)*(((s1_ptr)_2)->base + _s_53207);
    _2 = (int)SEQ_PTR(_27442);
    _s_53207 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_53207)){
        _s_53207 = (long)DBL_PTR(_s_53207)->dbl;
    }
    _27442 = NOVALUE;

    /** 	end while*/
    goto LD; // [696] 587
LE: 

    /** 	if not is_proc then*/
    if (_is_proc_53166 != 0)
    goto L12; // [701] 831

    /** 		integer create_target_var = 1*/
    _create_target_var_53322 = 1;

    /** 		if deferred then*/
    if (_deferred_53165 == 0)
    {
        goto L13; // [711] 751
    }
    else{
    }

    /** 			inline_target = Pop()*/
    _0 = _41Pop();
    _67inline_target_52223 = _0;
    if (!IS_ATOM_INT(_67inline_target_52223)) {
        _1 = (long)(DBL_PTR(_67inline_target_52223)->dbl);
        DeRefDS(_67inline_target_52223);
        _67inline_target_52223 = _1;
    }

    /** 			if is_temp( inline_target ) then*/
    _27446 = _67is_temp(_67inline_target_52223);
    if (_27446 == 0) {
        DeRef(_27446);
        _27446 = NOVALUE;
        goto L14; // [729] 744
    }
    else {
        if (!IS_ATOM_INT(_27446) && DBL_PTR(_27446)->dbl == 0.0){
            DeRef(_27446);
            _27446 = NOVALUE;
            goto L14; // [729] 744
        }
        DeRef(_27446);
        _27446 = NOVALUE;
    }
    DeRef(_27446);
    _27446 = NOVALUE;

    /** 				final_target = inline_target*/
    _final_target_53290 = _67inline_target_52223;
    goto L15; // [741] 750
L14: 

    /** 				create_target_var = 0*/
    _create_target_var_53322 = 0;
L15: 
L13: 

    /** 		if create_target_var then*/
    if (_create_target_var_53322 == 0)
    {
        goto L16; // [753] 816
    }
    else{
    }

    /** 			varnum += 1*/
    _67varnum_52227 = _67varnum_52227 + 1;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L17; // [768] 806
    }
    else{
    }

    /** 				inline_target = new_inline_var( sub, 0 )*/
    _0 = _67new_inline_var(_sub_53163, 0);
    _67inline_target_52223 = _0;
    if (!IS_ATOM_INT(_67inline_target_52223)) {
        _1 = (long)(DBL_PTR(_67inline_target_52223)->dbl);
        DeRefDS(_67inline_target_52223);
        _67inline_target_52223 = _1;
    }

    /** 				SymTab[inline_target][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67inline_target_52223 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_45715;
    DeRef(_1);
    _27449 = NOVALUE;

    /** 				Pop_block_var()*/
    _66Pop_block_var();
    goto L18; // [803] 815
L17: 

    /** 				inline_target = NewTempSym()*/
    _0 = _53NewTempSym(0);
    _67inline_target_52223 = _0;
    if (!IS_ATOM_INT(_67inline_target_52223)) {
        _1 = (long)(DBL_PTR(_67inline_target_52223)->dbl);
        DeRefDS(_67inline_target_52223);
        _67inline_target_52223 = _1;
    }
L18: 
L16: 

    /** 		proc_vars &= inline_target*/
    Append(&_67proc_vars_52217, _67proc_vars_52217, _67inline_target_52223);
    goto L19; // [828] 837
L12: 

    /** 		inline_target = 0*/
    _67inline_target_52223 = 0;
L19: 

    /** 	integer check_pc = 1*/
    _check_pc_53345 = 1;

    /** 	while length(inline_code) > check_pc do*/
L1A: 
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27453 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27453 = 1;
    }
    if (_27453 <= _check_pc_53345)
    goto L1B; // [852] 1216

    /** 		integer op = inline_code[check_pc]*/
    _2 = (int)SEQ_PTR(_67inline_code_52216);
    _op_53349 = (int)*(((s1_ptr)_2)->base + _check_pc_53345);
    if (!IS_ATOM_INT(_op_53349))
    _op_53349 = (long)DBL_PTR(_op_53349)->dbl;

    /** 		switch op with fallthru do*/
    _0 = _op_53349;
    switch ( _0 ){ 

        /** 			case ATOM_CHECK then*/
        case 101:
        case 97:
        case 96:

        /** 				symtab_index sym = get_original_sym( check_pc + 1 )*/
        _27458 = _check_pc_53345 + 1;
        if (_27458 > MAXINT){
            _27458 = NewDouble((double)_27458);
        }
        _sym_53358 = _67get_original_sym(_27458);
        _27458 = NOVALUE;
        if (!IS_ATOM_INT(_sym_53358)) {
            _1 = (long)(DBL_PTR(_sym_53358)->dbl);
            DeRefDS(_sym_53358);
            _sym_53358 = _1;
        }

        /** 				if is_literal( sym ) then*/
        _27460 = _67is_literal(_sym_53358);
        if (_27460 == 0) {
            DeRef(_27460);
            _27460 = NOVALUE;
            goto L1C; // [897] 1010
        }
        else {
            if (!IS_ATOM_INT(_27460) && DBL_PTR(_27460)->dbl == 0.0){
                DeRef(_27460);
                _27460 = NOVALUE;
                goto L1C; // [897] 1010
            }
            DeRef(_27460);
            _27460 = NOVALUE;
        }
        DeRef(_27460);
        _27460 = NOVALUE;

        /** 					integer check_result*/

        /** 					if op = INTEGER_CHECK then*/
        if (_op_53349 != 96)
        goto L1D; // [906] 930

        /** 						check_result = integer( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27462 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27462);
        _27463 = (int)*(((s1_ptr)_2)->base + 1);
        _27462 = NOVALUE;
        if (IS_ATOM_INT(_27463))
        _check_result_53363 = 1;
        else if (IS_ATOM_DBL(_27463))
        _check_result_53363 = IS_ATOM_INT(DoubleToInt(_27463));
        else
        _check_result_53363 = 0;
        _27463 = NOVALUE;
        goto L1E; // [927] 976
L1D: 

        /** 					elsif op = SEQUENCE_CHECK then*/
        if (_op_53349 != 97)
        goto L1F; // [934] 958

        /** 						check_result = sequence( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27466 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27466);
        _27467 = (int)*(((s1_ptr)_2)->base + 1);
        _27466 = NOVALUE;
        _check_result_53363 = IS_SEQUENCE(_27467);
        _27467 = NOVALUE;
        goto L1E; // [955] 976
L1F: 

        /** 						check_result = atom( SymTab[sym][S_OBJ] )*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27469 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27469);
        _27470 = (int)*(((s1_ptr)_2)->base + 1);
        _27469 = NOVALUE;
        _check_result_53363 = IS_ATOM(_27470);
        _27470 = NOVALUE;
L1E: 

        /** 					if check_result then*/
        if (_check_result_53363 == 0)
        {
            goto L20; // [980] 997
        }
        else{
        }

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27472 = _check_pc_53345 + 1;
        if (_27472 > MAXINT){
            _27472 = NewDouble((double)_27472);
        }
        RefDS(_21815);
        _67replace_code(_21815, _check_pc_53345, _27472);
        _27472 = NOVALUE;
        goto L21; // [994] 1005
L20: 

        /** 						CompileErr(146)*/
        RefDS(_21815);
        _44CompileErr(146, _21815, 0);
L21: 
        goto L22; // [1007] 1172
L1C: 

        /** 				elsif not is_temp( sym ) then*/
        _27474 = _67is_temp(_sym_53358);
        if (IS_ATOM_INT(_27474)) {
            if (_27474 != 0){
                DeRef(_27474);
                _27474 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        else {
            if (DBL_PTR(_27474)->dbl != 0.0){
                DeRef(_27474);
                _27474 = NOVALUE;
                goto L23; // [1016] 1165
            }
        }
        DeRef(_27474);
        _27474 = NOVALUE;

        /** 					if (op = INTEGER_CHECK and SymTab[sym][S_VTYPE] = integer_type )*/
        _27476 = (_op_53349 == 96);
        if (_27476 == 0) {
            _27477 = 0;
            goto L24; // [1027] 1053
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27478 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27478);
        _27479 = (int)*(((s1_ptr)_2)->base + 15);
        _27478 = NOVALUE;
        if (IS_ATOM_INT(_27479)) {
            _27480 = (_27479 == _53integer_type_45721);
        }
        else {
            _27480 = binary_op(EQUALS, _27479, _53integer_type_45721);
        }
        _27479 = NOVALUE;
        if (IS_ATOM_INT(_27480))
        _27477 = (_27480 != 0);
        else
        _27477 = DBL_PTR(_27480)->dbl != 0.0;
L24: 
        if (_27477 != 0) {
            _27481 = 1;
            goto L25; // [1053] 1093
        }
        _27482 = (_op_53349 == 97);
        if (_27482 == 0) {
            _27483 = 0;
            goto L26; // [1063] 1089
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27484 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27484);
        _27485 = (int)*(((s1_ptr)_2)->base + 15);
        _27484 = NOVALUE;
        if (IS_ATOM_INT(_27485)) {
            _27486 = (_27485 == _53sequence_type_45719);
        }
        else {
            _27486 = binary_op(EQUALS, _27485, _53sequence_type_45719);
        }
        _27485 = NOVALUE;
        if (IS_ATOM_INT(_27486))
        _27483 = (_27486 != 0);
        else
        _27483 = DBL_PTR(_27486)->dbl != 0.0;
L26: 
        _27481 = (_27483 != 0);
L25: 
        if (_27481 != 0) {
            goto L27; // [1093] 1141
        }
        _27488 = (_op_53349 == 101);
        if (_27488 == 0) {
            DeRef(_27489);
            _27489 = 0;
            goto L28; // [1103] 1136
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27490 = (int)*(((s1_ptr)_2)->base + _sym_53358);
        _2 = (int)SEQ_PTR(_27490);
        _27491 = (int)*(((s1_ptr)_2)->base + 15);
        _27490 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _53integer_type_45721;
        ((int *)_2)[2] = _53atom_type_45717;
        _27492 = MAKE_SEQ(_1);
        _27493 = find_from(_27491, _27492, 1);
        _27491 = NOVALUE;
        DeRefDS(_27492);
        _27492 = NOVALUE;
        _27489 = (_27493 != 0);
L28: 
        if (_27489 == 0)
        {
            _27489 = NOVALUE;
            goto L29; // [1137] 1155
        }
        else{
            _27489 = NOVALUE;
        }
L27: 

        /** 						replace_code( {}, check_pc, check_pc+1 )*/
        _27494 = _check_pc_53345 + 1;
        if (_27494 > MAXINT){
            _27494 = NewDouble((double)_27494);
        }
        RefDS(_21815);
        _67replace_code(_21815, _check_pc_53345, _27494);
        _27494 = NOVALUE;
        goto L22; // [1152] 1172
L29: 

        /** 						check_pc += 2*/
        _check_pc_53345 = _check_pc_53345 + 2;
        goto L22; // [1162] 1172
L23: 

        /** 					check_pc += 2*/
        _check_pc_53345 = _check_pc_53345 + 2;
L22: 

        /** 				continue*/
        goto L1A; // [1178] 847

        /** 			case STARTLINE then*/
        case 58:

        /** 				check_pc += 2*/
        _check_pc_53345 = _check_pc_53345 + 2;

        /** 				continue*/
        goto L1A; // [1196] 847

        /** 			case else*/
        default:

        /** 				exit*/
        goto L1B; // [1206] 1216
    ;}
    /** 	end while*/
    goto L1A; // [1213] 847
L1B: 

    /** 	for pc = 1 to length( inline_code ) do*/
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27498 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27498 = 1;
    }
    {
        int _pc_53436;
        _pc_53436 = 1;
L2A: 
        if (_pc_53436 > _27498){
            goto L2B; // [1223] 1420
        }

        /** 		if sequence( inline_code[pc] ) then*/
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27499 = (int)*(((s1_ptr)_2)->base + _pc_53436);
        _27500 = IS_SEQUENCE(_27499);
        _27499 = NOVALUE;
        if (_27500 == 0)
        {
            _27500 = NOVALUE;
            goto L2C; // [1241] 1411
        }
        else{
            _27500 = NOVALUE;
        }

        /** 			integer inline_type = inline_code[pc][1]*/
        _2 = (int)SEQ_PTR(_67inline_code_52216);
        _27501 = (int)*(((s1_ptr)_2)->base + _pc_53436);
        _2 = (int)SEQ_PTR(_27501);
        _inline_type_53441 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_inline_type_53441)){
            _inline_type_53441 = (long)DBL_PTR(_inline_type_53441)->dbl;
        }
        _27501 = NOVALUE;

        /** 			switch inline_type do*/
        _0 = _inline_type_53441;
        switch ( _0 ){ 

            /** 				case INLINE_SUB then*/
            case 5:

            /** 					inline_code[pc] = CurrentSub*/
            _2 = (int)SEQ_PTR(_67inline_code_52216);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52216 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53436);
            _1 = *(int *)_2;
            *(int *)_2 = _35CurrentSub_15976;
            DeRef(_1);
            goto L2D; // [1279] 1410

            /** 				case INLINE_VAR then*/
            case 6:

            /** 					replace_var( pc )*/
            _67replace_var(_pc_53436);

            /** 					break*/
            goto L2D; // [1292] 1410
            goto L2D; // [1294] 1410

            /** 				case INLINE_TEMP then*/
            case 2:

            /** 					replace_temp( pc )*/
            _67replace_temp(_pc_53436);
            goto L2D; // [1305] 1410

            /** 				case INLINE_PARAM then*/
            case 1:

            /** 					replace_param( pc )*/

            /** 	inline_code[pc] = get_param_sym( pc )*/
            _0 = _replace_param_1__tmp_at1341_53452;
            _replace_param_1__tmp_at1341_53452 = _67get_param_sym(_pc_53436);
            DeRef(_0);
            Ref(_replace_param_1__tmp_at1341_53452);
            _2 = (int)SEQ_PTR(_67inline_code_52216);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52216 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53436);
            _1 = *(int *)_2;
            *(int *)_2 = _replace_param_1__tmp_at1341_53452;
            DeRef(_1);

            /** end procedure*/
            goto L2E; // [1327] 1330
L2E: 
            DeRef(_replace_param_1__tmp_at1341_53452);
            _replace_param_1__tmp_at1341_53452 = NOVALUE;
            goto L2D; // [1332] 1410

            /** 				case INLINE_ADDR then*/
            case 4:

            /** 					inline_code[pc] = inline_start + inline_code[pc][2]*/
            _2 = (int)SEQ_PTR(_67inline_code_52216);
            _27505 = (int)*(((s1_ptr)_2)->base + _pc_53436);
            _2 = (int)SEQ_PTR(_27505);
            _27506 = (int)*(((s1_ptr)_2)->base + 2);
            _27505 = NOVALUE;
            if (IS_ATOM_INT(_27506)) {
                _27507 = _67inline_start_52228 + _27506;
                if ((long)((unsigned long)_27507 + (unsigned long)HIGH_BITS) >= 0) 
                _27507 = NewDouble((double)_27507);
            }
            else {
                _27507 = binary_op(PLUS, _67inline_start_52228, _27506);
            }
            _27506 = NOVALUE;
            _2 = (int)SEQ_PTR(_67inline_code_52216);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52216 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53436);
            _1 = *(int *)_2;
            *(int *)_2 = _27507;
            if( _1 != _27507 ){
                DeRef(_1);
            }
            _27507 = NOVALUE;
            goto L2D; // [1362] 1410

            /** 				case INLINE_TARGET then*/
            case 3:

            /** 					inline_code[pc] = inline_target*/
            _2 = (int)SEQ_PTR(_67inline_code_52216);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _67inline_code_52216 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pc_53436);
            _1 = *(int *)_2;
            *(int *)_2 = _67inline_target_52223;
            DeRef(_1);

            /** 					add_inline_target( pc + inline_start )*/
            _27508 = _pc_53436 + _67inline_start_52228;
            if ((long)((unsigned long)_27508 + (unsigned long)HIGH_BITS) >= 0) 
            _27508 = NewDouble((double)_27508);
            _41add_inline_target(_27508);
            _27508 = NOVALUE;

            /** 					break*/
            goto L2D; // [1391] 1410
            goto L2D; // [1393] 1410

            /** 				case else*/
            default:

            /** 					InternalErr( 265, {inline_type} )*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _inline_type_53441;
            _27509 = MAKE_SEQ(_1);
            _44InternalErr(265, _27509);
            _27509 = NOVALUE;
        ;}L2D: 
L2C: 

        /** 	end for*/
        _pc_53436 = _pc_53436 + 1;
        goto L2A; // [1415] 1230
L2B: 
        ;
    }

    /** 	for i = 1 to length(backpatches) do*/
    if (IS_SEQUENCE(_backpatches_53184)){
            _27510 = SEQ_PTR(_backpatches_53184)->length;
    }
    else {
        _27510 = 1;
    }
    {
        int _i_53464;
        _i_53464 = 1;
L2F: 
        if (_i_53464 > _27510){
            goto L30; // [1425] 1448
        }

        /** 		fixup_special_op( backpatches[i] )*/
        _2 = (int)SEQ_PTR(_backpatches_53184);
        _27511 = (int)*(((s1_ptr)_2)->base + _i_53464);
        Ref(_27511);
        _67fixup_special_op(_27511);
        _27511 = NOVALUE;

        /** 	end for*/
        _i_53464 = _i_53464 + 1;
        goto L2F; // [1443] 1432
L30: 
        ;
    }

    /** 	epilog &= End_inline_block( EXIT_BLOCK )*/
    _27512 = _66End_inline_block(206);
    if (IS_SEQUENCE(_epilog_53191) && IS_ATOM(_27512)) {
        Ref(_27512);
        Append(&_epilog_53191, _epilog_53191, _27512);
    }
    else if (IS_ATOM(_epilog_53191) && IS_SEQUENCE(_27512)) {
    }
    else {
        Concat((object_ptr)&_epilog_53191, _epilog_53191, _27512);
    }
    DeRef(_27512);
    _27512 = NOVALUE;

    /** 	if is_proc then*/
    if (_is_proc_53166 == 0)
    {
        goto L31; // [1462] 1472
    }
    else{
    }

    /** 		clear_op()*/
    _41clear_op();
    goto L32; // [1469] 1595
L31: 

    /** 		if not deferred then*/
    if (_deferred_53165 != 0)
    goto L33; // [1474] 1489

    /** 			Push( inline_target )*/
    _41Push(_67inline_target_52223);

    /** 			inlined_function()*/
    _41inlined_function();
L33: 

    /** 		if final_target then*/
    if (_final_target_53290 == 0)
    {
        goto L34; // [1491] 1521
    }
    else{
    }

    /** 			epilog &= { ASSIGN, inline_target, final_target }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    *((int *)(_2+8)) = _67inline_target_52223;
    *((int *)(_2+12)) = _final_target_53290;
    _27515 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53191, _epilog_53191, _27515);
    DeRefDS(_27515);
    _27515 = NOVALUE;

    /** 			emit_temp( final_target, NEW_REFERENCE )*/
    _41emit_temp(_final_target_53290, 1);
    goto L35; // [1518] 1594
L34: 

    /** 			emit_temp( inline_target, NEW_REFERENCE )*/
    _41emit_temp(_67inline_target_52223, 1);

    /** 			if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L36; // [1535] 1593

    /** 				epilog &= { ELSE, 0, PRIVATE_INIT_CHECK, inline_target }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 23;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 30;
    *((int *)(_2+16)) = _67inline_target_52223;
    _27518 = MAKE_SEQ(_1);
    Concat((object_ptr)&_epilog_53191, _epilog_53191, _27518);
    DeRefDS(_27518);
    _27518 = NOVALUE;

    /** 				epilog[$-2] = length(inline_code) + length(epilog) + inline_start + 1*/
    if (IS_SEQUENCE(_epilog_53191)){
            _27520 = SEQ_PTR(_epilog_53191)->length;
    }
    else {
        _27520 = 1;
    }
    _27521 = _27520 - 2;
    _27520 = NOVALUE;
    if (IS_SEQUENCE(_67inline_code_52216)){
            _27522 = SEQ_PTR(_67inline_code_52216)->length;
    }
    else {
        _27522 = 1;
    }
    if (IS_SEQUENCE(_epilog_53191)){
            _27523 = SEQ_PTR(_epilog_53191)->length;
    }
    else {
        _27523 = 1;
    }
    _27524 = _27522 + _27523;
    if ((long)((unsigned long)_27524 + (unsigned long)HIGH_BITS) >= 0) 
    _27524 = NewDouble((double)_27524);
    _27522 = NOVALUE;
    _27523 = NOVALUE;
    if (IS_ATOM_INT(_27524)) {
        _27525 = _27524 + _67inline_start_52228;
        if ((long)((unsigned long)_27525 + (unsigned long)HIGH_BITS) >= 0) 
        _27525 = NewDouble((double)_27525);
    }
    else {
        _27525 = NewDouble(DBL_PTR(_27524)->dbl + (double)_67inline_start_52228);
    }
    DeRef(_27524);
    _27524 = NOVALUE;
    if (IS_ATOM_INT(_27525)) {
        _27526 = _27525 + 1;
        if (_27526 > MAXINT){
            _27526 = NewDouble((double)_27526);
        }
    }
    else
    _27526 = binary_op(PLUS, 1, _27525);
    DeRef(_27525);
    _27525 = NOVALUE;
    _2 = (int)SEQ_PTR(_epilog_53191);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _epilog_53191 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _27521);
    _1 = *(int *)_2;
    *(int *)_2 = _27526;
    if( _1 != _27526 ){
        DeRef(_1);
    }
    _27526 = NOVALUE;
L36: 
L35: 
L32: 

    /** 	return prolog & inline_code & epilog*/
    {
        int concat_list[3];

        concat_list[0] = _epilog_53191;
        concat_list[1] = _67inline_code_52216;
        concat_list[2] = _prolog_53190;
        Concat_N((object_ptr)&_27527, concat_list, 3);
    }
    DeRef(_backpatches_53184);
    DeRefDSi(_prolog_53190);
    DeRefDS(_epilog_53191);
    _27397 = NOVALUE;
    _27410 = NOVALUE;
    DeRef(_27402);
    _27402 = NOVALUE;
    DeRef(_27405);
    _27405 = NOVALUE;
    _27414 = NOVALUE;
    DeRef(_27476);
    _27476 = NOVALUE;
    DeRef(_27431);
    _27431 = NOVALUE;
    DeRef(_27434);
    _27434 = NOVALUE;
    DeRef(_27482);
    _27482 = NOVALUE;
    DeRef(_27480);
    _27480 = NOVALUE;
    DeRef(_27488);
    _27488 = NOVALUE;
    DeRef(_27486);
    _27486 = NOVALUE;
    DeRef(_27521);
    _27521 = NOVALUE;
    return _27527;
    ;
}


void _67defer_call()
{
    int _defer_53504 = NOVALUE;
    int _27530 = NOVALUE;
    int _27529 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer defer = find( inline_sub, deferred_inline_decisions )*/
    _defer_53504 = find_from(_67inline_sub_52230, _67deferred_inline_decisions_52232, 1);

    /** 	if defer then*/
    if (_defer_53504 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		deferred_inline_calls[defer] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_67deferred_inline_calls_52233);
    _27529 = (int)*(((s1_ptr)_2)->base + _defer_53504);
    if (IS_SEQUENCE(_27529) && IS_ATOM(_35CurrentSub_15976)) {
        Append(&_27530, _27529, _35CurrentSub_15976);
    }
    else if (IS_ATOM(_27529) && IS_SEQUENCE(_35CurrentSub_15976)) {
    }
    else {
        Concat((object_ptr)&_27530, _27529, _35CurrentSub_15976);
        _27529 = NOVALUE;
    }
    _27529 = NOVALUE;
    _2 = (int)SEQ_PTR(_67deferred_inline_calls_52233);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67deferred_inline_calls_52233 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _defer_53504);
    _1 = *(int *)_2;
    *(int *)_2 = _27530;
    if( _1 != _27530 ){
        DeRef(_1);
    }
    _27530 = NOVALUE;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67emit_or_inline()
{
    int _sub_53513 = NOVALUE;
    int _code_53532 = NOVALUE;
    int _27537 = NOVALUE;
    int _27536 = NOVALUE;
    int _27534 = NOVALUE;
    int _27533 = NOVALUE;
    int _27532 = NOVALUE;
    int _0, _1, _2;
    

    /** 	symtab_index sub = op_info1*/
    _sub_53513 = _41op_info1_49774;

    /** 	inline_sub = sub*/
    _67inline_sub_52230 = _sub_53513;

    /** 	if Parser_mode != PAM_NORMAL then*/
    if (_35Parser_mode_16073 == 0)
    goto L1; // [23] 42

    /** 		emit_op( PROC )*/
    _41emit_op(27);

    /** 		return*/
    DeRef(_code_53532);
    return;
    goto L2; // [39] 90
L1: 

    /** 	elsif atom( SymTab[sub][S_INLINE] ) or has_forward_params(sub) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27532 = (int)*(((s1_ptr)_2)->base + _sub_53513);
    _2 = (int)SEQ_PTR(_27532);
    _27533 = (int)*(((s1_ptr)_2)->base + 29);
    _27532 = NOVALUE;
    _27534 = IS_ATOM(_27533);
    _27533 = NOVALUE;
    if (_27534 != 0) {
        goto L3; // [59] 72
    }
    _27536 = _41has_forward_params(_sub_53513);
    if (_27536 == 0) {
        DeRef(_27536);
        _27536 = NOVALUE;
        goto L4; // [68] 89
    }
    else {
        if (!IS_ATOM_INT(_27536) && DBL_PTR(_27536)->dbl == 0.0){
            DeRef(_27536);
            _27536 = NOVALUE;
            goto L4; // [68] 89
        }
        DeRef(_27536);
        _27536 = NOVALUE;
    }
    DeRef(_27536);
    _27536 = NOVALUE;
L3: 

    /** 		defer_call()*/
    _67defer_call();

    /** 		emit_op( PROC )*/
    _41emit_op(27);

    /** 		return*/
    DeRef(_code_53532);
    return;
L4: 
L2: 

    /** 	sequence code = get_inlined_code( sub, length(Code) )*/
    if (IS_SEQUENCE(_35Code_16056)){
            _27537 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _27537 = 1;
    }
    _0 = _code_53532;
    _code_53532 = _67get_inlined_code(_sub_53513, _27537, 0);
    DeRef(_0);
    _27537 = NOVALUE;

    /** 	emit_inline( code )*/
    RefDS(_code_53532);
    _41emit_inline(_code_53532);

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    DeRefDS(_code_53532);
    return;
    ;
}


void _67inline_deferred_calls()
{
    int _sub_53546 = NOVALUE;
    int _ix_53558 = NOVALUE;
    int _calling_sub_53560 = NOVALUE;
    int _code_53574 = NOVALUE;
    int _calls_53575 = NOVALUE;
    int _is_func_53579 = NOVALUE;
    int _offset_53586 = NOVALUE;
    int _op_53597 = NOVALUE;
    int _size_53600 = NOVALUE;
    int _27595 = NOVALUE;
    int _27593 = NOVALUE;
    int _27591 = NOVALUE;
    int _27590 = NOVALUE;
    int _27589 = NOVALUE;
    int _27587 = NOVALUE;
    int _27586 = NOVALUE;
    int _27585 = NOVALUE;
    int _27584 = NOVALUE;
    int _27583 = NOVALUE;
    int _27582 = NOVALUE;
    int _27581 = NOVALUE;
    int _27580 = NOVALUE;
    int _27579 = NOVALUE;
    int _27578 = NOVALUE;
    int _27576 = NOVALUE;
    int _27575 = NOVALUE;
    int _27574 = NOVALUE;
    int _27573 = NOVALUE;
    int _27571 = NOVALUE;
    int _27570 = NOVALUE;
    int _27569 = NOVALUE;
    int _27567 = NOVALUE;
    int _27565 = NOVALUE;
    int _27563 = NOVALUE;
    int _27561 = NOVALUE;
    int _27560 = NOVALUE;
    int _27559 = NOVALUE;
    int _27558 = NOVALUE;
    int _27556 = NOVALUE;
    int _27555 = NOVALUE;
    int _27552 = NOVALUE;
    int _27550 = NOVALUE;
    int _27548 = NOVALUE;
    int _27547 = NOVALUE;
    int _27546 = NOVALUE;
    int _27545 = NOVALUE;
    int _27544 = NOVALUE;
    int _27543 = NOVALUE;
    int _27541 = NOVALUE;
    int _27540 = NOVALUE;
    int _27539 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	deferred_inlining = 1*/
    _67deferred_inlining_52226 = 1;

    /** 	for i = 1 to length( deferred_inline_decisions ) do*/
    if (IS_SEQUENCE(_67deferred_inline_decisions_52232)){
            _27539 = SEQ_PTR(_67deferred_inline_decisions_52232)->length;
    }
    else {
        _27539 = 1;
    }
    {
        int _i_53541;
        _i_53541 = 1;
L1: 
        if (_i_53541 > _27539){
            goto L2; // [13] 476
        }

        /** 		if length( deferred_inline_calls[i] ) then*/
        _2 = (int)SEQ_PTR(_67deferred_inline_calls_52233);
        _27540 = (int)*(((s1_ptr)_2)->base + _i_53541);
        if (IS_SEQUENCE(_27540)){
                _27541 = SEQ_PTR(_27540)->length;
        }
        else {
            _27541 = 1;
        }
        _27540 = NOVALUE;
        if (_27541 == 0)
        {
            _27541 = NOVALUE;
            goto L3; // [31] 467
        }
        else{
            _27541 = NOVALUE;
        }

        /** 			integer sub = deferred_inline_decisions[i]*/
        _2 = (int)SEQ_PTR(_67deferred_inline_decisions_52232);
        _sub_53546 = (int)*(((s1_ptr)_2)->base + _i_53541);

        /** 			check_inline( sub )*/
        _67check_inline(_sub_53546);

        /** 			if atom( SymTab[sub][S_INLINE] ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _27543 = (int)*(((s1_ptr)_2)->base + _sub_53546);
        _2 = (int)SEQ_PTR(_27543);
        _27544 = (int)*(((s1_ptr)_2)->base + 29);
        _27543 = NOVALUE;
        _27545 = IS_ATOM(_27544);
        _27544 = NOVALUE;
        if (_27545 == 0)
        {
            _27545 = NOVALUE;
            goto L4; // [64] 74
        }
        else{
            _27545 = NOVALUE;
        }

        /** 				continue*/
        goto L5; // [71] 471
L4: 

        /** 			for cx = 1 to length( deferred_inline_calls[i] ) do*/
        _2 = (int)SEQ_PTR(_67deferred_inline_calls_52233);
        _27546 = (int)*(((s1_ptr)_2)->base + _i_53541);
        if (IS_SEQUENCE(_27546)){
                _27547 = SEQ_PTR(_27546)->length;
        }
        else {
            _27547 = 1;
        }
        _27546 = NOVALUE;
        {
            int _cx_53555;
            _cx_53555 = 1;
L6: 
            if (_cx_53555 > _27547){
                goto L7; // [85] 466
            }

            /** 				integer ix = 1*/
            _ix_53558 = 1;

            /** 				symtab_index calling_sub = deferred_inline_calls[i][cx]*/
            _2 = (int)SEQ_PTR(_67deferred_inline_calls_52233);
            _27548 = (int)*(((s1_ptr)_2)->base + _i_53541);
            _2 = (int)SEQ_PTR(_27548);
            _calling_sub_53560 = (int)*(((s1_ptr)_2)->base + _cx_53555);
            if (!IS_ATOM_INT(_calling_sub_53560)){
                _calling_sub_53560 = (long)DBL_PTR(_calling_sub_53560)->dbl;
            }
            _27548 = NOVALUE;

            /** 				CurrentSub = calling_sub*/
            _35CurrentSub_15976 = _calling_sub_53560;

            /** 				Code = SymTab[calling_sub][S_CODE]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _27550 = (int)*(((s1_ptr)_2)->base + _calling_sub_53560);
            DeRef(_35Code_16056);
            _2 = (int)SEQ_PTR(_27550);
            if (!IS_ATOM_INT(_35S_CODE_15653)){
                _35Code_16056 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
            }
            else{
                _35Code_16056 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
            }
            Ref(_35Code_16056);
            _27550 = NOVALUE;

            /** 				LineTable = SymTab[calling_sub][S_LINETAB]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _27552 = (int)*(((s1_ptr)_2)->base + _calling_sub_53560);
            DeRef(_35LineTable_16057);
            _2 = (int)SEQ_PTR(_27552);
            if (!IS_ATOM_INT(_35S_LINETAB_15676)){
                _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
            }
            else{
                _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15676);
            }
            Ref(_35LineTable_16057);
            _27552 = NOVALUE;

            /** 				sequence code = {}*/
            RefDS(_21815);
            DeRef(_code_53574);
            _code_53574 = _21815;

            /** 				sequence calls = find_ops( 1, PROC )*/
            RefDS(_35Code_16056);
            _0 = _calls_53575;
            _calls_53575 = _65find_ops(1, 27, _35Code_16056);
            DeRef(_0);

            /** 				integer is_func = SymTab[sub][S_TOKEN] != PROC */
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _27555 = (int)*(((s1_ptr)_2)->base + _sub_53546);
            _2 = (int)SEQ_PTR(_27555);
            if (!IS_ATOM_INT(_35S_TOKEN_15646)){
                _27556 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
            }
            else{
                _27556 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
            }
            _27555 = NOVALUE;
            if (IS_ATOM_INT(_27556)) {
                _is_func_53579 = (_27556 != 27);
            }
            else {
                _is_func_53579 = binary_op(NOTEQ, _27556, 27);
            }
            _27556 = NOVALUE;
            if (!IS_ATOM_INT(_is_func_53579)) {
                _1 = (long)(DBL_PTR(_is_func_53579)->dbl);
                DeRefDS(_is_func_53579);
                _is_func_53579 = _1;
            }

            /** 				integer offset = 0*/
            _offset_53586 = 0;

            /** 				for o = 1 to length( calls ) do*/
            if (IS_SEQUENCE(_calls_53575)){
                    _27558 = SEQ_PTR(_calls_53575)->length;
            }
            else {
                _27558 = 1;
            }
            {
                int _o_53588;
                _o_53588 = 1;
L8: 
                if (_o_53588 > _27558){
                    goto L9; // [203] 423
                }

                /** 					if calls[o][2][2] = sub then*/
                _2 = (int)SEQ_PTR(_calls_53575);
                _27559 = (int)*(((s1_ptr)_2)->base + _o_53588);
                _2 = (int)SEQ_PTR(_27559);
                _27560 = (int)*(((s1_ptr)_2)->base + 2);
                _27559 = NOVALUE;
                _2 = (int)SEQ_PTR(_27560);
                _27561 = (int)*(((s1_ptr)_2)->base + 2);
                _27560 = NOVALUE;
                if (binary_op_a(NOTEQ, _27561, _sub_53546)){
                    _27561 = NOVALUE;
                    goto LA; // [224] 414
                }
                _27561 = NOVALUE;

                /** 						ix = calls[o][1]*/
                _2 = (int)SEQ_PTR(_calls_53575);
                _27563 = (int)*(((s1_ptr)_2)->base + _o_53588);
                _2 = (int)SEQ_PTR(_27563);
                _ix_53558 = (int)*(((s1_ptr)_2)->base + 1);
                if (!IS_ATOM_INT(_ix_53558)){
                    _ix_53558 = (long)DBL_PTR(_ix_53558)->dbl;
                }
                _27563 = NOVALUE;

                /** 						sequence op = calls[o][2]*/
                _2 = (int)SEQ_PTR(_calls_53575);
                _27565 = (int)*(((s1_ptr)_2)->base + _o_53588);
                DeRef(_op_53597);
                _2 = (int)SEQ_PTR(_27565);
                _op_53597 = (int)*(((s1_ptr)_2)->base + 2);
                Ref(_op_53597);
                _27565 = NOVALUE;

                /** 						integer size = length( op ) - 1*/
                if (IS_SEQUENCE(_op_53597)){
                        _27567 = SEQ_PTR(_op_53597)->length;
                }
                else {
                    _27567 = 1;
                }
                _size_53600 = _27567 - 1;
                _27567 = NOVALUE;

                /** 						if is_func then*/
                if (_is_func_53579 == 0)
                {
                    goto LB; // [263] 289
                }
                else{
                }

                /** 							Push( op[$] )*/
                if (IS_SEQUENCE(_op_53597)){
                        _27569 = SEQ_PTR(_op_53597)->length;
                }
                else {
                    _27569 = 1;
                }
                _2 = (int)SEQ_PTR(_op_53597);
                _27570 = (int)*(((s1_ptr)_2)->base + _27569);
                Ref(_27570);
                _41Push(_27570);
                _27570 = NOVALUE;

                /** 							op = remove( op, length(op) )*/
                if (IS_SEQUENCE(_op_53597)){
                        _27571 = SEQ_PTR(_op_53597)->length;
                }
                else {
                    _27571 = 1;
                }
                {
                    s1_ptr assign_space = SEQ_PTR(_op_53597);
                    int len = assign_space->length;
                    int start = (IS_ATOM_INT(_27571)) ? _27571 : (long)(DBL_PTR(_27571)->dbl);
                    int stop = (IS_ATOM_INT(_27571)) ? _27571 : (long)(DBL_PTR(_27571)->dbl);
                    if (stop > len){
                        stop = len;
                    }
                    if (start > len || start > stop || stop<0) {
                    }
                    else if (start < 2) {
                        if (stop >= len) {
                            Head( SEQ_PTR(_op_53597), start, &_op_53597 );
                        }
                        else Tail(SEQ_PTR(_op_53597), stop+1, &_op_53597);
                    }
                    else if (stop >= len){
                        Head(SEQ_PTR(_op_53597), start, &_op_53597);
                    }
                    else {
                        assign_slice_seq = &assign_space;
                        _op_53597 = Remove_elements(start, stop, (SEQ_PTR(_op_53597)->ref == 1));
                    }
                }
                _27571 = NOVALUE;
                _27571 = NOVALUE;
LB: 

                /** 						for p = 3 to length( op ) do*/
                if (IS_SEQUENCE(_op_53597)){
                        _27573 = SEQ_PTR(_op_53597)->length;
                }
                else {
                    _27573 = 1;
                }
                {
                    int _p_53610;
                    _p_53610 = 3;
LC: 
                    if (_p_53610 > _27573){
                        goto LD; // [294] 317
                    }

                    /** 							Push( op[p] )*/
                    _2 = (int)SEQ_PTR(_op_53597);
                    _27574 = (int)*(((s1_ptr)_2)->base + _p_53610);
                    Ref(_27574);
                    _41Push(_27574);
                    _27574 = NOVALUE;

                    /** 						end for*/
                    _p_53610 = _p_53610 + 1;
                    goto LC; // [312] 301
LD: 
                    ;
                }

                /** 						code = get_inlined_code( sub, ix + offset - 1, 1 )*/
                _27575 = _ix_53558 + _offset_53586;
                if ((long)((unsigned long)_27575 + (unsigned long)HIGH_BITS) >= 0) 
                _27575 = NewDouble((double)_27575);
                if (IS_ATOM_INT(_27575)) {
                    _27576 = _27575 - 1;
                    if ((long)((unsigned long)_27576 +(unsigned long) HIGH_BITS) >= 0){
                        _27576 = NewDouble((double)_27576);
                    }
                }
                else {
                    _27576 = NewDouble(DBL_PTR(_27575)->dbl - (double)1);
                }
                DeRef(_27575);
                _27575 = NOVALUE;
                _0 = _code_53574;
                _code_53574 = _67get_inlined_code(_sub_53546, _27576, 1);
                DeRef(_0);
                _27576 = NOVALUE;

                /** 						shift:replace_code( repeat( NOP1, length(code) ), ix + offset, ix + offset + size )*/
                if (IS_SEQUENCE(_code_53574)){
                        _27578 = SEQ_PTR(_code_53574)->length;
                }
                else {
                    _27578 = 1;
                }
                _27579 = Repeat(159, _27578);
                _27578 = NOVALUE;
                _27580 = _ix_53558 + _offset_53586;
                if ((long)((unsigned long)_27580 + (unsigned long)HIGH_BITS) >= 0) 
                _27580 = NewDouble((double)_27580);
                _27581 = _ix_53558 + _offset_53586;
                if ((long)((unsigned long)_27581 + (unsigned long)HIGH_BITS) >= 0) 
                _27581 = NewDouble((double)_27581);
                if (IS_ATOM_INT(_27581)) {
                    _27582 = _27581 + _size_53600;
                    if ((long)((unsigned long)_27582 + (unsigned long)HIGH_BITS) >= 0) 
                    _27582 = NewDouble((double)_27582);
                }
                else {
                    _27582 = NewDouble(DBL_PTR(_27581)->dbl + (double)_size_53600);
                }
                DeRef(_27581);
                _27581 = NOVALUE;
                _65replace_code(_27579, _27580, _27582);
                _27579 = NOVALUE;
                _27580 = NOVALUE;
                _27582 = NOVALUE;

                /** 						Code = eu:replace( Code, code, ix + offset, ix + offset + length( code ) -1 )*/
                _27583 = _ix_53558 + _offset_53586;
                if ((long)((unsigned long)_27583 + (unsigned long)HIGH_BITS) >= 0) 
                _27583 = NewDouble((double)_27583);
                _27584 = _ix_53558 + _offset_53586;
                if ((long)((unsigned long)_27584 + (unsigned long)HIGH_BITS) >= 0) 
                _27584 = NewDouble((double)_27584);
                if (IS_SEQUENCE(_code_53574)){
                        _27585 = SEQ_PTR(_code_53574)->length;
                }
                else {
                    _27585 = 1;
                }
                if (IS_ATOM_INT(_27584)) {
                    _27586 = _27584 + _27585;
                    if ((long)((unsigned long)_27586 + (unsigned long)HIGH_BITS) >= 0) 
                    _27586 = NewDouble((double)_27586);
                }
                else {
                    _27586 = NewDouble(DBL_PTR(_27584)->dbl + (double)_27585);
                }
                DeRef(_27584);
                _27584 = NOVALUE;
                _27585 = NOVALUE;
                if (IS_ATOM_INT(_27586)) {
                    _27587 = _27586 - 1;
                    if ((long)((unsigned long)_27587 +(unsigned long) HIGH_BITS) >= 0){
                        _27587 = NewDouble((double)_27587);
                    }
                }
                else {
                    _27587 = NewDouble(DBL_PTR(_27586)->dbl - (double)1);
                }
                DeRef(_27586);
                _27586 = NOVALUE;
                {
                    int p1 = _35Code_16056;
                    int p2 = _code_53574;
                    int p3 = _27583;
                    int p4 = _27587;
                    struct replace_block replace_params;
                    replace_params.copy_to   = &p1;
                    replace_params.copy_from = &p2;
                    replace_params.start     = &p3;
                    replace_params.stop      = &p4;
                    replace_params.target    = &_35Code_16056;
                    Replace( &replace_params );
                }
                DeRef(_27583);
                _27583 = NOVALUE;
                DeRef(_27587);
                _27587 = NOVALUE;

                /** 						offset += length(code) - size - 1*/
                if (IS_SEQUENCE(_code_53574)){
                        _27589 = SEQ_PTR(_code_53574)->length;
                }
                else {
                    _27589 = 1;
                }
                _27590 = _27589 - _size_53600;
                if ((long)((unsigned long)_27590 +(unsigned long) HIGH_BITS) >= 0){
                    _27590 = NewDouble((double)_27590);
                }
                _27589 = NOVALUE;
                if (IS_ATOM_INT(_27590)) {
                    _27591 = _27590 - 1;
                    if ((long)((unsigned long)_27591 +(unsigned long) HIGH_BITS) >= 0){
                        _27591 = NewDouble((double)_27591);
                    }
                }
                else {
                    _27591 = NewDouble(DBL_PTR(_27590)->dbl - (double)1);
                }
                DeRef(_27590);
                _27590 = NOVALUE;
                if (IS_ATOM_INT(_27591)) {
                    _offset_53586 = _offset_53586 + _27591;
                }
                else {
                    _offset_53586 = NewDouble((double)_offset_53586 + DBL_PTR(_27591)->dbl);
                }
                DeRef(_27591);
                _27591 = NOVALUE;
                if (!IS_ATOM_INT(_offset_53586)) {
                    _1 = (long)(DBL_PTR(_offset_53586)->dbl);
                    DeRefDS(_offset_53586);
                    _offset_53586 = _1;
                }
LA: 
                DeRef(_op_53597);
                _op_53597 = NOVALUE;

                /** 				end for*/
                _o_53588 = _o_53588 + 1;
                goto L8; // [418] 210
L9: 
                ;
            }

            /** 				SymTab[calling_sub][S_CODE] = Code*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_14981 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_53560 + ((s1_ptr)_2)->base);
            RefDS(_35Code_16056);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_35S_CODE_15653))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
            _1 = *(int *)_2;
            *(int *)_2 = _35Code_16056;
            DeRef(_1);
            _27593 = NOVALUE;

            /** 				SymTab[calling_sub][S_LINETAB] = LineTable*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_14981 = MAKE_SEQ(_2);
            }
            _3 = (int)(_calling_sub_53560 + ((s1_ptr)_2)->base);
            RefDS(_35LineTable_16057);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_35S_LINETAB_15676))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
            _1 = *(int *)_2;
            *(int *)_2 = _35LineTable_16057;
            DeRef(_1);
            _27595 = NOVALUE;
            DeRef(_code_53574);
            _code_53574 = NOVALUE;
            DeRef(_calls_53575);
            _calls_53575 = NOVALUE;

            /** 			end for*/
            _cx_53555 = _cx_53555 + 1;
            goto L6; // [461] 92
L7: 
            ;
        }
L3: 

        /** 	end for*/
L5: 
        _i_53541 = _i_53541 + 1;
        goto L1; // [471] 20
L2: 
        ;
    }

    /** end procedure*/
    _27540 = NOVALUE;
    _27546 = NOVALUE;
    return;
    ;
}



// 0x14970B0A
