// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _41Push(int _x_50029)
{
    int _26147 = NOVALUE;
    int _26145 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_50029)) {
        _1 = (long)(DBL_PTR(_x_50029)->dbl);
        DeRefDS(_x_50029);
        _x_50029 = _1;
    }

    /** 	cgi += 1*/
    _41cgi_49790 = _41cgi_49790 + 1;

    /** 	if cgi > length(cg_stack) then*/
    if (IS_SEQUENCE(_41cg_stack_49789)){
            _26145 = SEQ_PTR(_41cg_stack_49789)->length;
    }
    else {
        _26145 = 1;
    }
    if (_41cgi_49790 <= _26145)
    goto L1; // [20] 37

    /** 		cg_stack &= repeat(0, 400)*/
    _26147 = Repeat(0, 400);
    Concat((object_ptr)&_41cg_stack_49789, _41cg_stack_49789, _26147);
    DeRefDS(_26147);
    _26147 = NOVALUE;
L1: 

    /** 	cg_stack[cgi] = x*/
    _2 = (int)SEQ_PTR(_41cg_stack_49789);
    _2 = (int)(((s1_ptr)_2)->base + _41cgi_49790);
    _1 = *(int *)_2;
    *(int *)_2 = _x_50029;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


int _41Top()
{
    int _26149 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_41cg_stack_49789);
    _26149 = (int)*(((s1_ptr)_2)->base + _41cgi_49790);
    Ref(_26149);
    return _26149;
    ;
}


int _41Pop()
{
    int _t_50042 = NOVALUE;
    int _s_50048 = NOVALUE;
    int _26161 = NOVALUE;
    int _26159 = NOVALUE;
    int _26157 = NOVALUE;
    int _26154 = NOVALUE;
    int _26153 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	t = cg_stack[cgi]*/
    _2 = (int)SEQ_PTR(_41cg_stack_49789);
    _t_50042 = (int)*(((s1_ptr)_2)->base + _41cgi_49790);
    if (!IS_ATOM_INT(_t_50042)){
        _t_50042 = (long)DBL_PTR(_t_50042)->dbl;
    }

    /** 	cgi -= 1*/
    _41cgi_49790 = _41cgi_49790 - 1;

    /** 	if t > 0 then*/
    if (_t_50042 <= 0)
    goto L1; // [23] 116

    /** 		symtab_index s = t -- for type checking*/
    _s_50048 = _t_50042;

    /** 		if SymTab[t][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26153 = (int)*(((s1_ptr)_2)->base + _t_50042);
    _2 = (int)SEQ_PTR(_26153);
    _26154 = (int)*(((s1_ptr)_2)->base + 3);
    _26153 = NOVALUE;
    if (binary_op_a(NOTEQ, _26154, 3)){
        _26154 = NOVALUE;
        goto L2; // [50] 115
    }
    _26154 = NOVALUE;

    /** 			if use_private_list = 0 then  -- no problem with reusing the temp*/
    if (_35use_private_list_16081 != 0)
    goto L3; // [58] 82

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26157 = NOVALUE;
    goto L4; // [79] 114
L3: 

    /** 			elsif find(t, private_sym) = 0 then*/
    _26159 = find_from(_t_50042, _35private_sym_16080, 1);
    if (_26159 != 0)
    goto L5; // [91] 113

    /** 				SymTab[t][S_SCOPE] = FREE -- mark it as being free*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_t_50042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26161 = NOVALUE;
L5: 
L4: 
L2: 
L1: 

    /** 	return t*/
    return _t_50042;
    ;
}


void _41TempKeep(int _x_50076)
{
    int _26168 = NOVALUE;
    int _26167 = NOVALUE;
    int _26166 = NOVALUE;
    int _26165 = NOVALUE;
    int _26164 = NOVALUE;
    int _26163 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50076)) {
        _1 = (long)(DBL_PTR(_x_50076)->dbl);
        DeRefDS(_x_50076);
        _x_50076 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26163 = (_x_50076 > 0);
    if (_26163 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26165 = (int)*(((s1_ptr)_2)->base + _x_50076);
    _2 = (int)SEQ_PTR(_26165);
    _26166 = (int)*(((s1_ptr)_2)->base + 3);
    _26165 = NOVALUE;
    if (IS_ATOM_INT(_26166)) {
        _26167 = (_26166 == 3);
    }
    else {
        _26167 = binary_op(EQUALS, _26166, 3);
    }
    _26166 = NOVALUE;
    if (_26167 == 0) {
        DeRef(_26167);
        _26167 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26167) && DBL_PTR(_26167)->dbl == 0.0){
            DeRef(_26167);
            _26167 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26167);
        _26167 = NOVALUE;
    }
    DeRef(_26167);
    _26167 = NOVALUE;

    /** 		SymTab[x][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50076 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26168 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26163);
    _26163 = NOVALUE;
    return;
    ;
}


void _41TempFree(int _x_50094)
{
    int _26174 = NOVALUE;
    int _26172 = NOVALUE;
    int _26171 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50094)) {
        _1 = (long)(DBL_PTR(_x_50094)->dbl);
        DeRefDS(_x_50094);
        _x_50094 = _1;
    }

    /** 	if x > 0 then*/
    if (_x_50094 <= 0)
    goto L1; // [5] 53

    /** 		if SymTab[x][S_MODE] = M_TEMP then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26171 = (int)*(((s1_ptr)_2)->base + _x_50094);
    _2 = (int)SEQ_PTR(_26171);
    _26172 = (int)*(((s1_ptr)_2)->base + 3);
    _26171 = NOVALUE;
    if (binary_op_a(NOTEQ, _26172, 3)){
        _26172 = NOVALUE;
        goto L2; // [25] 52
    }
    _26172 = NOVALUE;

    /** 			SymTab[x][S_SCOPE] = FREE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50094 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _26174 = NOVALUE;

    /** 			clear_temp( x )*/
    _41clear_temp(_x_50094);
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


void _41TempInteger(int _x_50113)
{
    int _26181 = NOVALUE;
    int _26180 = NOVALUE;
    int _26179 = NOVALUE;
    int _26178 = NOVALUE;
    int _26177 = NOVALUE;
    int _26176 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_x_50113)) {
        _1 = (long)(DBL_PTR(_x_50113)->dbl);
        DeRefDS(_x_50113);
        _x_50113 = _1;
    }

    /** 	if x > 0 and SymTab[x][S_MODE] = M_TEMP then*/
    _26176 = (_x_50113 > 0);
    if (_26176 == 0) {
        goto L1; // [9] 53
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26178 = (int)*(((s1_ptr)_2)->base + _x_50113);
    _2 = (int)SEQ_PTR(_26178);
    _26179 = (int)*(((s1_ptr)_2)->base + 3);
    _26178 = NOVALUE;
    if (IS_ATOM_INT(_26179)) {
        _26180 = (_26179 == 3);
    }
    else {
        _26180 = binary_op(EQUALS, _26179, 3);
    }
    _26179 = NOVALUE;
    if (_26180 == 0) {
        DeRef(_26180);
        _26180 = NOVALUE;
        goto L1; // [32] 53
    }
    else {
        if (!IS_ATOM_INT(_26180) && DBL_PTR(_26180)->dbl == 0.0){
            DeRef(_26180);
            _26180 = NOVALUE;
            goto L1; // [32] 53
        }
        DeRef(_26180);
        _26180 = NOVALUE;
    }
    DeRef(_26180);
    _26180 = NOVALUE;

    /** 		SymTab[x][S_USAGE] = T_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_x_50113 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _26181 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_26176);
    _26176 = NOVALUE;
    return;
    ;
}


int _41LexName(int _t_50130, int _defname_50131)
{
    int _name_50133 = NOVALUE;
    int _26190 = NOVALUE;
    int _26188 = NOVALUE;
    int _26186 = NOVALUE;
    int _26185 = NOVALUE;
    int _26184 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t_50130)) {
        _1 = (long)(DBL_PTR(_t_50130)->dbl);
        DeRefDS(_t_50130);
        _t_50130 = _1;
    }

    /** 	for i = 1 to length(token_name) do*/
    _26184 = 80;
    {
        int _i_50135;
        _i_50135 = 1;
L1: 
        if (_i_50135 > 80){
            goto L2; // [12] 82
        }

        /** 		if t = token_name[i][LEX_NUMBER] then*/
        _2 = (int)SEQ_PTR(_41token_name_49797);
        _26185 = (int)*(((s1_ptr)_2)->base + _i_50135);
        _2 = (int)SEQ_PTR(_26185);
        _26186 = (int)*(((s1_ptr)_2)->base + 1);
        _26185 = NOVALUE;
        if (binary_op_a(NOTEQ, _t_50130, _26186)){
            _26186 = NOVALUE;
            goto L3; // [31] 75
        }
        _26186 = NOVALUE;

        /** 			name = token_name[i][LEX_NAME]*/
        _2 = (int)SEQ_PTR(_41token_name_49797);
        _26188 = (int)*(((s1_ptr)_2)->base + _i_50135);
        DeRef(_name_50133);
        _2 = (int)SEQ_PTR(_26188);
        _name_50133 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_name_50133);
        _26188 = NOVALUE;

        /** 			if not find(' ', name) then*/
        _26190 = find_from(32, _name_50133, 1);
        if (_26190 != 0)
        goto L4; // [56] 68
        _26190 = NOVALUE;

        /** 				name = "'" & name & "'"*/
        {
            int concat_list[3];

            concat_list[0] = _26192;
            concat_list[1] = _name_50133;
            concat_list[2] = _26192;
            Concat_N((object_ptr)&_name_50133, concat_list, 3);
        }
L4: 

        /** 			return name*/
        DeRefDS(_defname_50131);
        return _name_50133;
L3: 

        /** 	end for*/
        _i_50135 = _i_50135 + 1;
        goto L1; // [77] 19
L2: 
        ;
    }

    /** 	return defname -- try to avoid this case*/
    DeRef(_name_50133);
    return _defname_50131;
    ;
}


void _41InitEmit()
{
    int _0, _1, _2;
    

    /** 	cg_stack = repeat(0, 400)*/
    DeRef(_41cg_stack_49789);
    _41cg_stack_49789 = Repeat(0, 400);

    /** 	cgi = 0*/
    _41cgi_49790 = 0;

    /** end procedure*/
    return;
    ;
}


int _41IsInteger(int _sym_50154)
{
    int _mode_50155 = NOVALUE;
    int _t_50157 = NOVALUE;
    int _pt_50158 = NOVALUE;
    int _26215 = NOVALUE;
    int _26214 = NOVALUE;
    int _26212 = NOVALUE;
    int _26211 = NOVALUE;
    int _26210 = NOVALUE;
    int _26208 = NOVALUE;
    int _26207 = NOVALUE;
    int _26206 = NOVALUE;
    int _26205 = NOVALUE;
    int _26203 = NOVALUE;
    int _26199 = NOVALUE;
    int _26196 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_50154)) {
        _1 = (long)(DBL_PTR(_sym_50154)->dbl);
        DeRefDS(_sym_50154);
        _sym_50154 = _1;
    }

    /** 	if sym < 1 then*/
    if (_sym_50154 >= 1)
    goto L1; // [5] 16

    /** 		return 0*/
    return 0;
L1: 

    /** 	mode = SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26196 = (int)*(((s1_ptr)_2)->base + _sym_50154);
    _2 = (int)SEQ_PTR(_26196);
    _mode_50155 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_50155)){
        _mode_50155 = (long)DBL_PTR(_mode_50155)->dbl;
    }
    _26196 = NOVALUE;

    /** 	if mode = M_NORMAL then*/
    if (_mode_50155 != 1)
    goto L2; // [36] 136

    /** 		t = SymTab[sym][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26199 = (int)*(((s1_ptr)_2)->base + _sym_50154);
    _2 = (int)SEQ_PTR(_26199);
    _t_50157 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_50157)){
        _t_50157 = (long)DBL_PTR(_t_50157)->dbl;
    }
    _26199 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_50157 != _53integer_type_45721)
    goto L3; // [60] 73

    /** 			return TRUE*/
    return _13TRUE_437;
L3: 

    /** 		if t > 0 then*/
    if (_t_50157 <= 0)
    goto L4; // [75] 215

    /** 			pt = SymTab[t][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26203 = (int)*(((s1_ptr)_2)->base + _t_50157);
    _2 = (int)SEQ_PTR(_26203);
    _pt_50158 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_pt_50158)){
        _pt_50158 = (long)DBL_PTR(_pt_50158)->dbl;
    }
    _26203 = NOVALUE;

    /** 			if pt and SymTab[pt][S_VTYPE] = integer_type then*/
    if (_pt_50158 == 0) {
        goto L4; // [97] 215
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26206 = (int)*(((s1_ptr)_2)->base + _pt_50158);
    _2 = (int)SEQ_PTR(_26206);
    _26207 = (int)*(((s1_ptr)_2)->base + 15);
    _26206 = NOVALUE;
    if (IS_ATOM_INT(_26207)) {
        _26208 = (_26207 == _53integer_type_45721);
    }
    else {
        _26208 = binary_op(EQUALS, _26207, _53integer_type_45721);
    }
    _26207 = NOVALUE;
    if (_26208 == 0) {
        DeRef(_26208);
        _26208 = NOVALUE;
        goto L4; // [120] 215
    }
    else {
        if (!IS_ATOM_INT(_26208) && DBL_PTR(_26208)->dbl == 0.0){
            DeRef(_26208);
            _26208 = NOVALUE;
            goto L4; // [120] 215
        }
        DeRef(_26208);
        _26208 = NOVALUE;
    }
    DeRef(_26208);
    _26208 = NOVALUE;

    /** 				return TRUE   -- usertype(integer x)*/
    return _13TRUE_437;
    goto L4; // [133] 215
L2: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_50155 != 2)
    goto L5; // [140] 176

    /** 		if integer(SymTab[sym][S_OBJ]) then  -- bug fixed: can't allow PLUS1_I op*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26210 = (int)*(((s1_ptr)_2)->base + _sym_50154);
    _2 = (int)SEQ_PTR(_26210);
    _26211 = (int)*(((s1_ptr)_2)->base + 1);
    _26210 = NOVALUE;
    if (IS_ATOM_INT(_26211))
    _26212 = 1;
    else if (IS_ATOM_DBL(_26211))
    _26212 = IS_ATOM_INT(DoubleToInt(_26211));
    else
    _26212 = 0;
    _26211 = NOVALUE;
    if (_26212 == 0)
    {
        _26212 = NOVALUE;
        goto L4; // [161] 215
    }
    else{
        _26212 = NOVALUE;
    }

    /** 			return TRUE*/
    return _13TRUE_437;
    goto L4; // [173] 215
L5: 

    /** 	elsif mode = M_TEMP then*/
    if (_mode_50155 != 3)
    goto L6; // [180] 214

    /** 		if SymTab[sym][S_USAGE] = T_INTEGER then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26214 = (int)*(((s1_ptr)_2)->base + _sym_50154);
    _2 = (int)SEQ_PTR(_26214);
    _26215 = (int)*(((s1_ptr)_2)->base + 5);
    _26214 = NOVALUE;
    if (binary_op_a(NOTEQ, _26215, 1)){
        _26215 = NOVALUE;
        goto L7; // [200] 213
    }
    _26215 = NOVALUE;

    /** 			return TRUE*/
    return _13TRUE_437;
L7: 
L6: 
L4: 

    /** 	return FALSE*/
    return _13FALSE_435;
    ;
}


void _41emit(int _val_50215)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_val_50215)) {
        _1 = (long)(DBL_PTR(_val_50215)->dbl);
        DeRefDS(_val_50215);
        _val_50215 = _1;
    }

    /** 	Code = append(Code, val)*/
    Append(&_35Code_16056, _35Code_16056, _val_50215);

    /** end procedure*/
    return;
    ;
}


void _41emit_opnd(int _opnd_50222)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opnd_50222)) {
        _1 = (long)(DBL_PTR(_opnd_50222)->dbl);
        DeRefDS(_opnd_50222);
        _opnd_50222 = _1;
    }

    /** 		Push(opnd)*/
    _41Push(_opnd_50222);

    /** 		previous_op = -1  -- N.B.*/
    _35previous_op_16066 = -1;

    /** end procedure*/
    return;
    ;
}


void _41emit_addr(int _x_50226)
{
    int _0, _1, _2;
    

    /** 		Code = append(Code, x)*/
    Ref(_x_50226);
    Append(&_35Code_16056, _35Code_16056, _x_50226);

    /** end procedure*/
    DeRef(_x_50226);
    return;
    ;
}


void _41emit_opcode(int _op_50232)
{
    int _0, _1, _2;
    

    /** 	Code = append(Code, op)*/
    Append(&_35Code_16056, _35Code_16056, _op_50232);

    /** end procedure*/
    return;
    ;
}


void _41emit_temp(int _tempsym_50266, int _referenced_50267)
{
    int _26246 = NOVALUE;
    int _26245 = NOVALUE;
    int _26244 = NOVALUE;
    int _26243 = NOVALUE;
    int _26242 = NOVALUE;
    int _26241 = NOVALUE;
    int _26240 = NOVALUE;
    int _26239 = NOVALUE;
    int _26238 = NOVALUE;
    int _26237 = NOVALUE;
    int _26236 = NOVALUE;
    int _26235 = NOVALUE;
    int _26234 = NOVALUE;
    int _26233 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_referenced_50267)) {
        _1 = (long)(DBL_PTR(_referenced_50267)->dbl);
        DeRefDS(_referenced_50267);
        _referenced_50267 = _1;
    }

    /** 	if not TRANSLATE  then -- translator has its own way of handling temps*/
    if (_35TRANSLATE_15611 != 0)
    goto L1; // [7] 129

    /** 		if sequence(tempsym) then*/
    _26233 = IS_SEQUENCE(_tempsym_50266);
    if (_26233 == 0)
    {
        _26233 = NOVALUE;
        goto L2; // [15] 53
    }
    else{
        _26233 = NOVALUE;
    }

    /** 			for i = 1 to length(tempsym) do*/
    if (IS_SEQUENCE(_tempsym_50266)){
            _26234 = SEQ_PTR(_tempsym_50266)->length;
    }
    else {
        _26234 = 1;
    }
    {
        int _i_50274;
        _i_50274 = 1;
L3: 
        if (_i_50274 > _26234){
            goto L4; // [23] 50
        }

        /** 				emit_temp( tempsym[i], referenced )*/
        _2 = (int)SEQ_PTR(_tempsym_50266);
        _26235 = (int)*(((s1_ptr)_2)->base + _i_50274);
        DeRef(_26236);
        _26236 = _referenced_50267;
        Ref(_26235);
        _41emit_temp(_26235, _26236);
        _26235 = NOVALUE;
        _26236 = NOVALUE;

        /** 			end for*/
        _i_50274 = _i_50274 + 1;
        goto L3; // [45] 30
L4: 
        ;
    }
    goto L5; // [50] 128
L2: 

    /** 		elsif tempsym > 0*/
    if (IS_ATOM_INT(_tempsym_50266)) {
        _26237 = (_tempsym_50266 > 0);
    }
    else {
        _26237 = binary_op(GREATER, _tempsym_50266, 0);
    }
    if (IS_ATOM_INT(_26237)) {
        if (_26237 == 0) {
            DeRef(_26238);
            _26238 = 0;
            goto L6; // [59] 77
        }
    }
    else {
        if (DBL_PTR(_26237)->dbl == 0.0) {
            DeRef(_26238);
            _26238 = 0;
            goto L6; // [59] 77
        }
    }
    Ref(_tempsym_50266);
    _26239 = _53sym_mode(_tempsym_50266);
    if (IS_ATOM_INT(_26239)) {
        _26240 = (_26239 == 3);
    }
    else {
        _26240 = binary_op(EQUALS, _26239, 3);
    }
    DeRef(_26239);
    _26239 = NOVALUE;
    DeRef(_26238);
    if (IS_ATOM_INT(_26240))
    _26238 = (_26240 != 0);
    else
    _26238 = DBL_PTR(_26240)->dbl != 0.0;
L6: 
    if (_26238 == 0) {
        _26241 = 0;
        goto L7; // [77] 92
    }
    Ref(_tempsym_50266);
    _26242 = _41IsInteger(_tempsym_50266);
    if (IS_ATOM_INT(_26242)) {
        _26243 = (_26242 == 0);
    }
    else {
        _26243 = unary_op(NOT, _26242);
    }
    DeRef(_26242);
    _26242 = NOVALUE;
    if (IS_ATOM_INT(_26243))
    _26241 = (_26243 != 0);
    else
    _26241 = DBL_PTR(_26243)->dbl != 0.0;
L7: 
    if (_26241 == 0) {
        goto L8; // [92] 127
    }
    _26245 = find_from(_tempsym_50266, _41emitted_temps_50262, 1);
    _26246 = (_26245 == 0);
    _26245 = NOVALUE;
    if (_26246 == 0)
    {
        DeRef(_26246);
        _26246 = NOVALUE;
        goto L8; // [107] 127
    }
    else{
        DeRef(_26246);
        _26246 = NOVALUE;
    }

    /** 			emitted_temps &= tempsym*/
    if (IS_SEQUENCE(_41emitted_temps_50262) && IS_ATOM(_tempsym_50266)) {
        Ref(_tempsym_50266);
        Append(&_41emitted_temps_50262, _41emitted_temps_50262, _tempsym_50266);
    }
    else if (IS_ATOM(_41emitted_temps_50262) && IS_SEQUENCE(_tempsym_50266)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temps_50262, _41emitted_temps_50262, _tempsym_50266);
    }

    /** 			emitted_temp_referenced &= referenced*/
    Append(&_41emitted_temp_referenced_50263, _41emitted_temp_referenced_50263, _referenced_50267);
L8: 
L5: 
L1: 

    /** end procedure*/
    DeRef(_tempsym_50266);
    DeRef(_26237);
    _26237 = NOVALUE;
    DeRef(_26243);
    _26243 = NOVALUE;
    DeRef(_26240);
    _26240 = NOVALUE;
    return;
    ;
}


void _41flush_temps(int _except_for_50296)
{
    int _refs_50299 = NOVALUE;
    int _novalues_50300 = NOVALUE;
    int _sym_50305 = NOVALUE;
    int _26261 = NOVALUE;
    int _26260 = NOVALUE;
    int _26259 = NOVALUE;
    int _26258 = NOVALUE;
    int _26256 = NOVALUE;
    int _26252 = NOVALUE;
    int _26251 = NOVALUE;
    int _26249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [7] 16
    }
    else{
    }

    /** 		return*/
    DeRefDS(_except_for_50296);
    DeRef(_refs_50299);
    DeRefi(_novalues_50300);
    return;
L1: 

    /** 	sequence*/

    /** 		refs = {},*/
    RefDS(_21815);
    DeRef(_refs_50299);
    _refs_50299 = _21815;

    /** 		novalues = {}*/
    RefDS(_21815);
    DeRefi(_novalues_50300);
    _novalues_50300 = _21815;

    /** 	derefs = {}*/
    RefDS(_21815);
    DeRefi(_41derefs_50293);
    _41derefs_50293 = _21815;

    /** 	for i = 1 to length( emitted_temps ) do*/
    if (IS_SEQUENCE(_41emitted_temps_50262)){
            _26249 = SEQ_PTR(_41emitted_temps_50262)->length;
    }
    else {
        _26249 = 1;
    }
    {
        int _i_50302;
        _i_50302 = 1;
L2: 
        if (_i_50302 > _26249){
            goto L3; // [46] 119
        }

        /** 		symtab_index sym = emitted_temps[i]*/
        _2 = (int)SEQ_PTR(_41emitted_temps_50262);
        _sym_50305 = (int)*(((s1_ptr)_2)->base + _i_50302);
        if (!IS_ATOM_INT(_sym_50305)){
            _sym_50305 = (long)DBL_PTR(_sym_50305)->dbl;
        }

        /** 		if find( sym, except_for ) then*/
        _26251 = find_from(_sym_50305, _except_for_50296, 1);
        if (_26251 == 0)
        {
            _26251 = NOVALUE;
            goto L4; // [70] 80
        }
        else{
            _26251 = NOVALUE;
        }

        /** 			continue*/
        goto L5; // [77] 114
L4: 

        /** 		if emitted_temp_referenced[i] = NEW_REFERENCE then*/
        _2 = (int)SEQ_PTR(_41emitted_temp_referenced_50263);
        _26252 = (int)*(((s1_ptr)_2)->base + _i_50302);
        if (binary_op_a(NOTEQ, _26252, 1)){
            _26252 = NOVALUE;
            goto L6; // [88] 103
        }
        _26252 = NOVALUE;

        /** 			derefs &= sym*/
        Append(&_41derefs_50293, _41derefs_50293, _sym_50305);
        goto L7; // [100] 110
L6: 

        /** 			novalues &= sym*/
        Append(&_novalues_50300, _novalues_50300, _sym_50305);
L7: 

        /** 	end for*/
L5: 
        _i_50302 = _i_50302 + 1;
        goto L2; // [114] 53
L3: 
        ;
    }

    /** 	if not length( except_for ) then*/
    if (IS_SEQUENCE(_except_for_50296)){
            _26256 = SEQ_PTR(_except_for_50296)->length;
    }
    else {
        _26256 = 1;
    }
    if (_26256 != 0)
    goto L8; // [124] 132
    _26256 = NOVALUE;

    /** 		clear_last()*/
    _41clear_last();
L8: 

    /** 	for i = 1 to length( derefs ) do*/
    if (IS_SEQUENCE(_41derefs_50293)){
            _26258 = SEQ_PTR(_41derefs_50293)->length;
    }
    else {
        _26258 = 1;
    }
    {
        int _i_50320;
        _i_50320 = 1;
L9: 
        if (_i_50320 > _26258){
            goto LA; // [139] 171
        }

        /** 		emit( DEREF_TEMP )*/
        _41emit(208);

        /** 		emit( derefs[i] )*/
        _2 = (int)SEQ_PTR(_41derefs_50293);
        _26259 = (int)*(((s1_ptr)_2)->base + _i_50320);
        _41emit(_26259);
        _26259 = NOVALUE;

        /** 	end for*/
        _i_50320 = _i_50320 + 1;
        goto L9; // [166] 146
LA: 
        ;
    }

    /** 	for i = 1 to length( novalues ) do*/
    if (IS_SEQUENCE(_novalues_50300)){
            _26260 = SEQ_PTR(_novalues_50300)->length;
    }
    else {
        _26260 = 1;
    }
    {
        int _i_50325;
        _i_50325 = 1;
LB: 
        if (_i_50325 > _26260){
            goto LC; // [176] 206
        }

        /** 		emit( NOVALUE_TEMP )*/
        _41emit(209);

        /** 		emit( novalues[i] )*/
        _2 = (int)SEQ_PTR(_novalues_50300);
        _26261 = (int)*(((s1_ptr)_2)->base + _i_50325);
        _41emit(_26261);
        _26261 = NOVALUE;

        /** 	end for*/
        _i_50325 = _i_50325 + 1;
        goto LB; // [201] 183
LC: 
        ;
    }

    /** 	emitted_temps = {}*/
    RefDS(_21815);
    DeRef(_41emitted_temps_50262);
    _41emitted_temps_50262 = _21815;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_21815);
    DeRef(_41emitted_temp_referenced_50263);
    _41emitted_temp_referenced_50263 = _21815;

    /** end procedure*/
    DeRefDS(_except_for_50296);
    DeRef(_refs_50299);
    DeRefi(_novalues_50300);
    return;
    ;
}


void _41flush_temp(int _temp_50332)
{
    int _except_for_50333 = NOVALUE;
    int _ix_50334 = NOVALUE;
    int _26263 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_temp_50332)) {
        _1 = (long)(DBL_PTR(_temp_50332)->dbl);
        DeRefDS(_temp_50332);
        _temp_50332 = _1;
    }

    /** 	sequence except_for = emitted_temps*/
    RefDS(_41emitted_temps_50262);
    DeRef(_except_for_50333);
    _except_for_50333 = _41emitted_temps_50262;

    /** 	integer ix = find( temp, emitted_temps )*/
    _ix_50334 = find_from(_temp_50332, _41emitted_temps_50262, 1);

    /** 	if ix then*/
    if (_ix_50334 == 0)
    {
        goto L1; // [23] 37
    }
    else{
    }

    /** 		flush_temps( remove( except_for, ix ) )*/
    {
        s1_ptr assign_space = SEQ_PTR(_except_for_50333);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50334)) ? _ix_50334 : (long)(DBL_PTR(_ix_50334)->dbl);
        int stop = (IS_ATOM_INT(_ix_50334)) ? _ix_50334 : (long)(DBL_PTR(_ix_50334)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_except_for_50333);
            DeRef(_26263);
            _26263 = _except_for_50333;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_except_for_50333), start, &_26263 );
            }
            else Tail(SEQ_PTR(_except_for_50333), stop+1, &_26263);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_except_for_50333), start, &_26263);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_26263);
            _26263 = _1;
        }
    }
    _41flush_temps(_26263);
    _26263 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_except_for_50333);
    return;
    ;
}


void _41check_for_temps()
{
    int _26270 = NOVALUE;
    int _26269 = NOVALUE;
    int _26268 = NOVALUE;
    int _26267 = NOVALUE;
    int _26265 = NOVALUE;
    int _26264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE or last_op < 1 or last_pc < 1 then*/
    if (_35TRANSLATE_15611 != 0) {
        _26264 = 1;
        goto L1; // [5] 19
    }
    _26265 = (_41last_op_50668 < 1);
    _26264 = (_26265 != 0);
L1: 
    if (_26264 != 0) {
        goto L2; // [19] 34
    }
    _26267 = (_41last_pc_50669 < 1);
    if (_26267 == 0)
    {
        DeRef(_26267);
        _26267 = NOVALUE;
        goto L3; // [30] 40
    }
    else{
        DeRef(_26267);
        _26267 = NOVALUE;
    }
L2: 

    /** 		return*/
    DeRef(_26265);
    _26265 = NOVALUE;
    return;
L3: 

    /** 	emit_temp( get_target_sym( current_op( last_pc ) ), op_temp_ref[last_op] )*/
    RefDS(_35Code_16056);
    _26268 = _65current_op(_41last_pc_50669, _35Code_16056);
    _26269 = _65get_target_sym(_26268);
    _26268 = NOVALUE;
    _2 = (int)SEQ_PTR(_41op_temp_ref_50484);
    _26270 = (int)*(((s1_ptr)_2)->base + _41last_op_50668);
    _41emit_temp(_26269, _26270);
    _26269 = NOVALUE;
    _26270 = NOVALUE;

    /** end procedure*/
    DeRef(_26265);
    _26265 = NOVALUE;
    return;
    ;
}


void _41clear_temp(int _tempsym_50359)
{
    int _ix_50360 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tempsym_50359)) {
        _1 = (long)(DBL_PTR(_tempsym_50359)->dbl);
        DeRefDS(_tempsym_50359);
        _tempsym_50359 = _1;
    }

    /** 	integer ix = find( tempsym, emitted_temps )*/
    _ix_50360 = find_from(_tempsym_50359, _41emitted_temps_50262, 1);

    /** 	if ix then*/
    if (_ix_50360 == 0)
    {
        goto L1; // [14] 36
    }
    else{
    }

    /** 		emitted_temps = remove( emitted_temps, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_41emitted_temps_50262);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50360)) ? _ix_50360 : (long)(DBL_PTR(_ix_50360)->dbl);
        int stop = (IS_ATOM_INT(_ix_50360)) ? _ix_50360 : (long)(DBL_PTR(_ix_50360)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41emitted_temps_50262), start, &_41emitted_temps_50262 );
            }
            else Tail(SEQ_PTR(_41emitted_temps_50262), stop+1, &_41emitted_temps_50262);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41emitted_temps_50262), start, &_41emitted_temps_50262);
        }
        else {
            assign_slice_seq = &assign_space;
            _41emitted_temps_50262 = Remove_elements(start, stop, (SEQ_PTR(_41emitted_temps_50262)->ref == 1));
        }
    }

    /** 		emitted_temp_referenced = remove( emitted_temp_referenced, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_41emitted_temp_referenced_50263);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_50360)) ? _ix_50360 : (long)(DBL_PTR(_ix_50360)->dbl);
        int stop = (IS_ATOM_INT(_ix_50360)) ? _ix_50360 : (long)(DBL_PTR(_ix_50360)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_41emitted_temp_referenced_50263), start, &_41emitted_temp_referenced_50263 );
            }
            else Tail(SEQ_PTR(_41emitted_temp_referenced_50263), stop+1, &_41emitted_temp_referenced_50263);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_41emitted_temp_referenced_50263), start, &_41emitted_temp_referenced_50263);
        }
        else {
            assign_slice_seq = &assign_space;
            _41emitted_temp_referenced_50263 = Remove_elements(start, stop, (SEQ_PTR(_41emitted_temp_referenced_50263)->ref == 1));
        }
    }
L1: 

    /** end procedure*/
    return;
    ;
}


int _41pop_temps()
{
    int _new_emitted_50367 = NOVALUE;
    int _new_referenced_50368 = NOVALUE;
    int _26274 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_emitted  = emitted_temps*/
    RefDS(_41emitted_temps_50262);
    DeRef(_new_emitted_50367);
    _new_emitted_50367 = _41emitted_temps_50262;

    /** 	sequence new_referenced = emitted_temp_referenced*/
    RefDS(_41emitted_temp_referenced_50263);
    DeRef(_new_referenced_50368);
    _new_referenced_50368 = _41emitted_temp_referenced_50263;

    /** 	emitted_temps  = {}*/
    RefDS(_21815);
    DeRefDS(_41emitted_temps_50262);
    _41emitted_temps_50262 = _21815;

    /** 	emitted_temp_referenced = {}*/
    RefDS(_21815);
    DeRefDS(_41emitted_temp_referenced_50263);
    _41emitted_temp_referenced_50263 = _21815;

    /** 	return { new_emitted, new_referenced }*/
    RefDS(_new_referenced_50368);
    RefDS(_new_emitted_50367);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _new_emitted_50367;
    ((int *)_2)[2] = _new_referenced_50368;
    _26274 = MAKE_SEQ(_1);
    DeRefDS(_new_emitted_50367);
    DeRefDS(_new_referenced_50368);
    return _26274;
    ;
}


int _41get_temps(int _add_to_50372)
{
    int _26279 = NOVALUE;
    int _26278 = NOVALUE;
    int _26277 = NOVALUE;
    int _26276 = NOVALUE;
    int _0, _1, _2;
    

    /** 	add_to[1] &= emitted_temps*/
    _2 = (int)SEQ_PTR(_add_to_50372);
    _26276 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_26276) && IS_ATOM(_41emitted_temps_50262)) {
    }
    else if (IS_ATOM(_26276) && IS_SEQUENCE(_41emitted_temps_50262)) {
        Ref(_26276);
        Prepend(&_26277, _41emitted_temps_50262, _26276);
    }
    else {
        Concat((object_ptr)&_26277, _26276, _41emitted_temps_50262);
        _26276 = NOVALUE;
    }
    _26276 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _26277;
    if( _1 != _26277 ){
        DeRef(_1);
    }
    _26277 = NOVALUE;

    /** 	add_to[2] &= emitted_temp_referenced*/
    _2 = (int)SEQ_PTR(_add_to_50372);
    _26278 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_26278) && IS_ATOM(_41emitted_temp_referenced_50263)) {
    }
    else if (IS_ATOM(_26278) && IS_SEQUENCE(_41emitted_temp_referenced_50263)) {
        Ref(_26278);
        Prepend(&_26279, _41emitted_temp_referenced_50263, _26278);
    }
    else {
        Concat((object_ptr)&_26279, _26278, _41emitted_temp_referenced_50263);
        _26278 = NOVALUE;
    }
    _26278 = NOVALUE;
    _2 = (int)SEQ_PTR(_add_to_50372);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _add_to_50372 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _26279;
    if( _1 != _26279 ){
        DeRef(_1);
    }
    _26279 = NOVALUE;

    /** 	return add_to*/
    return _add_to_50372;
    ;
}


void _41push_temps(int _temps_50380)
{
    int _26282 = NOVALUE;
    int _26280 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emitted_temps &= temps[1]*/
    _2 = (int)SEQ_PTR(_temps_50380);
    _26280 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_41emitted_temps_50262) && IS_ATOM(_26280)) {
        Ref(_26280);
        Append(&_41emitted_temps_50262, _41emitted_temps_50262, _26280);
    }
    else if (IS_ATOM(_41emitted_temps_50262) && IS_SEQUENCE(_26280)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temps_50262, _41emitted_temps_50262, _26280);
    }
    _26280 = NOVALUE;

    /** 	emitted_temp_referenced &= temps[2]*/
    _2 = (int)SEQ_PTR(_temps_50380);
    _26282 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_41emitted_temp_referenced_50263) && IS_ATOM(_26282)) {
        Ref(_26282);
        Append(&_41emitted_temp_referenced_50263, _41emitted_temp_referenced_50263, _26282);
    }
    else if (IS_ATOM(_41emitted_temp_referenced_50263) && IS_SEQUENCE(_26282)) {
    }
    else {
        Concat((object_ptr)&_41emitted_temp_referenced_50263, _41emitted_temp_referenced_50263, _26282);
    }
    _26282 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** end procedure*/
    DeRefDS(_temps_50380);
    return;
    ;
}


void _41backpatch(int _index_50387, int _val_50388)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_50387)) {
        _1 = (long)(DBL_PTR(_index_50387)->dbl);
        DeRefDS(_index_50387);
        _index_50387 = _1;
    }
    if (!IS_ATOM_INT(_val_50388)) {
        _1 = (long)(DBL_PTR(_val_50388)->dbl);
        DeRefDS(_val_50388);
        _val_50388 = _1;
    }

    /** 		Code[index] = val*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index_50387);
    _1 = *(int *)_2;
    *(int *)_2 = _val_50388;
    DeRef(_1);

    /** end procedure*/
    return;
    ;
}


void _41cont11ii(int _op_50569, int _ii_50571)
{
    int _t_50572 = NOVALUE;
    int _source_50573 = NOVALUE;
    int _c_50574 = NOVALUE;
    int _26291 = NOVALUE;
    int _26290 = NOVALUE;
    int _26288 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_opcode(op)*/
    _41emit_opcode(_op_50569);

    /** 	source = Pop()*/
    _source_50573 = _41Pop();
    if (!IS_ATOM_INT(_source_50573)) {
        _1 = (long)(DBL_PTR(_source_50573)->dbl);
        DeRefDS(_source_50573);
        _source_50573 = _1;
    }

    /** 	emit_addr(source)*/
    _41emit_addr(_source_50573);

    /** 	assignable = TRUE*/
    _41assignable_49792 = _13TRUE_437;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_41op_result_50390);
    _t_50572 = (int)*(((s1_ptr)_2)->base + _op_50569);

    /** 	if t = T_INTEGER or (ii and IsInteger(source)) then*/
    _26288 = (_t_50572 == 1);
    if (_26288 != 0) {
        goto L1; // [43] 64
    }
    if (_ii_50571 == 0) {
        _26290 = 0;
        goto L2; // [47] 59
    }
    _26291 = _41IsInteger(_source_50573);
    if (IS_ATOM_INT(_26291))
    _26290 = (_26291 != 0);
    else
    _26290 = DBL_PTR(_26291)->dbl != 0.0;
L2: 
    if (_26290 == 0)
    {
        _26290 = NOVALUE;
        goto L3; // [60] 80
    }
    else{
        _26290 = NOVALUE;
    }
L1: 

    /** 		c = NewTempSym()*/
    _c_50574 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_50574)) {
        _1 = (long)(DBL_PTR(_c_50574)->dbl);
        DeRefDS(_c_50574);
        _c_50574 = _1;
    }

    /** 		TempInteger(c)*/
    _41TempInteger(_c_50574);
    goto L4; // [77] 95
L3: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd type*/
    _c_50574 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_50574)) {
        _1 = (long)(DBL_PTR(_c_50574)->dbl);
        DeRefDS(_c_50574);
        _c_50574 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _41emit_temp(_c_50574, 1);
L4: 

    /** 	Push(c)*/
    _41Push(_c_50574);

    /** 	emit_addr(c)*/
    _41emit_addr(_c_50574);

    /** end procedure*/
    DeRef(_26288);
    _26288 = NOVALUE;
    DeRef(_26291);
    _26291 = NOVALUE;
    return;
    ;
}


void _41cont21d(int _op_50591, int _a_50592, int _b_50593, int _ii_50595)
{
    int _c_50596 = NOVALUE;
    int _t_50597 = NOVALUE;
    int _26301 = NOVALUE;
    int _26300 = NOVALUE;
    int _26299 = NOVALUE;
    int _26298 = NOVALUE;
    int _26296 = NOVALUE;
    int _0, _1, _2;
    

    /** 	assignable = TRUE*/
    _41assignable_49792 = _13TRUE_437;

    /** 	t = op_result[op]*/
    _2 = (int)SEQ_PTR(_41op_result_50390);
    _t_50597 = (int)*(((s1_ptr)_2)->base + _op_50591);

    /** 	if op = C_FUNC then*/
    if (_op_50591 != 133)
    goto L1; // [26] 38

    /** 		emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_15976);
L1: 

    /** 	if t = T_INTEGER or (ii and IsInteger(a) and IsInteger(b)) then*/
    _26296 = (_t_50597 == 1);
    if (_26296 != 0) {
        goto L2; // [46] 79
    }
    if (_ii_50595 == 0) {
        _26298 = 0;
        goto L3; // [50] 62
    }
    _26299 = _41IsInteger(_a_50592);
    if (IS_ATOM_INT(_26299))
    _26298 = (_26299 != 0);
    else
    _26298 = DBL_PTR(_26299)->dbl != 0.0;
L3: 
    if (_26298 == 0) {
        DeRef(_26300);
        _26300 = 0;
        goto L4; // [62] 74
    }
    _26301 = _41IsInteger(_b_50593);
    if (IS_ATOM_INT(_26301))
    _26300 = (_26301 != 0);
    else
    _26300 = DBL_PTR(_26301)->dbl != 0.0;
L4: 
    if (_26300 == 0)
    {
        _26300 = NOVALUE;
        goto L5; // [75] 95
    }
    else{
        _26300 = NOVALUE;
    }
L2: 

    /** 		c = NewTempSym()*/
    _c_50596 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_50596)) {
        _1 = (long)(DBL_PTR(_c_50596)->dbl);
        DeRefDS(_c_50596);
        _c_50596 = _1;
    }

    /** 		TempInteger(c)*/
    _41TempInteger(_c_50596);
    goto L6; // [92] 110
L5: 

    /** 		c = NewTempSym() -- allocate *after* checking opnd types*/
    _c_50596 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_50596)) {
        _1 = (long)(DBL_PTR(_c_50596)->dbl);
        DeRefDS(_c_50596);
        _c_50596 = _1;
    }

    /** 		emit_temp( c, NEW_REFERENCE )*/
    _41emit_temp(_c_50596, 1);
L6: 

    /** 	Push(c)*/
    _41Push(_c_50596);

    /** 	emit_addr(c)*/
    _41emit_addr(_c_50596);

    /** end procedure*/
    DeRef(_26296);
    _26296 = NOVALUE;
    DeRef(_26299);
    _26299 = NOVALUE;
    DeRef(_26301);
    _26301 = NOVALUE;
    return;
    ;
}


void _41cont21ii(int _op_50619, int _ii_50621)
{
    int _a_50622 = NOVALUE;
    int _b_50623 = NOVALUE;
    int _0, _1, _2;
    

    /** 	b = Pop()*/
    _b_50623 = _41Pop();
    if (!IS_ATOM_INT(_b_50623)) {
        _1 = (long)(DBL_PTR(_b_50623)->dbl);
        DeRefDS(_b_50623);
        _b_50623 = _1;
    }

    /** 	emit_opcode(op)*/
    _41emit_opcode(_op_50619);

    /** 	a = Pop()*/
    _a_50622 = _41Pop();
    if (!IS_ATOM_INT(_a_50622)) {
        _1 = (long)(DBL_PTR(_a_50622)->dbl);
        DeRefDS(_a_50622);
        _a_50622 = _1;
    }

    /** 	emit_addr(a)*/
    _41emit_addr(_a_50622);

    /** 	emit_addr(b)*/
    _41emit_addr(_b_50623);

    /** 	cont21d(op, a, b, ii)*/
    _41cont21d(_op_50619, _a_50622, _b_50623, _ii_50621);

    /** end procedure*/
    return;
    ;
}


int _41good_string(int _elements_50628)
{
    int _obj_50629 = NOVALUE;
    int _ep_50631 = NOVALUE;
    int _e_50633 = NOVALUE;
    int _element_vals_50634 = NOVALUE;
    int _26324 = NOVALUE;
    int _26323 = NOVALUE;
    int _26322 = NOVALUE;
    int _26321 = NOVALUE;
    int _26320 = NOVALUE;
    int _26319 = NOVALUE;
    int _26318 = NOVALUE;
    int _26317 = NOVALUE;
    int _26316 = NOVALUE;
    int _26315 = NOVALUE;
    int _26314 = NOVALUE;
    int _26312 = NOVALUE;
    int _26309 = NOVALUE;
    int _26308 = NOVALUE;
    int _26307 = NOVALUE;
    int _26306 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence element_vals*/

    /** 	if TRANSLATE and length(elements) > 10000 then*/
    if (_35TRANSLATE_15611 == 0) {
        goto L1; // [9] 31
    }
    if (IS_SEQUENCE(_elements_50628)){
            _26307 = SEQ_PTR(_elements_50628)->length;
    }
    else {
        _26307 = 1;
    }
    _26308 = (_26307 > 10000);
    _26307 = NOVALUE;
    if (_26308 == 0)
    {
        DeRef(_26308);
        _26308 = NOVALUE;
        goto L1; // [21] 31
    }
    else{
        DeRef(_26308);
        _26308 = NOVALUE;
    }

    /** 		return -1 -- A huge string might upset the C compiler.*/
    DeRefDS(_elements_50628);
    DeRef(_obj_50629);
    DeRef(_element_vals_50634);
    return -1;
L1: 

    /** 	element_vals = {}*/
    RefDS(_21815);
    DeRef(_element_vals_50634);
    _element_vals_50634 = _21815;

    /** 	for i = 1 to length(elements) do*/
    if (IS_SEQUENCE(_elements_50628)){
            _26309 = SEQ_PTR(_elements_50628)->length;
    }
    else {
        _26309 = 1;
    }
    {
        int _i_50641;
        _i_50641 = 1;
L2: 
        if (_i_50641 > _26309){
            goto L3; // [43] 183
        }

        /** 		ep = elements[i]*/
        _2 = (int)SEQ_PTR(_elements_50628);
        _ep_50631 = (int)*(((s1_ptr)_2)->base + _i_50641);
        if (!IS_ATOM_INT(_ep_50631)){
            _ep_50631 = (long)DBL_PTR(_ep_50631)->dbl;
        }

        /** 		if ep < 1 then*/
        if (_ep_50631 >= 1)
        goto L4; // [60] 71

        /** 			return -1*/
        DeRefDS(_elements_50628);
        DeRef(_obj_50629);
        DeRef(_element_vals_50634);
        return -1;
L4: 

        /** 		e = ep*/
        _e_50633 = _ep_50631;

        /** 		obj = SymTab[e][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26312 = (int)*(((s1_ptr)_2)->base + _e_50633);
        DeRef(_obj_50629);
        _2 = (int)SEQ_PTR(_26312);
        _obj_50629 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_50629);
        _26312 = NOVALUE;

        /** 		if SymTab[e][S_MODE] = M_CONSTANT and*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26314 = (int)*(((s1_ptr)_2)->base + _e_50633);
        _2 = (int)SEQ_PTR(_26314);
        _26315 = (int)*(((s1_ptr)_2)->base + 3);
        _26314 = NOVALUE;
        if (IS_ATOM_INT(_26315)) {
            _26316 = (_26315 == 2);
        }
        else {
            _26316 = binary_op(EQUALS, _26315, 2);
        }
        _26315 = NOVALUE;
        if (IS_ATOM_INT(_26316)) {
            if (_26316 == 0) {
                DeRef(_26317);
                _26317 = 0;
                goto L5; // [112] 123
            }
        }
        else {
            if (DBL_PTR(_26316)->dbl == 0.0) {
                DeRef(_26317);
                _26317 = 0;
                goto L5; // [112] 123
            }
        }
        if (IS_ATOM_INT(_obj_50629))
        _26318 = 1;
        else if (IS_ATOM_DBL(_obj_50629))
        _26318 = IS_ATOM_INT(DoubleToInt(_obj_50629));
        else
        _26318 = 0;
        DeRef(_26317);
        _26317 = (_26318 != 0);
L5: 
        if (_26317 == 0) {
            goto L6; // [123] 169
        }
        _26320 = (_35TRANSLATE_15611 == 0);
        if (_26320 != 0) {
            DeRef(_26321);
            _26321 = 1;
            goto L7; // [132] 156
        }
        if (IS_ATOM_INT(_obj_50629)) {
            _26322 = (_obj_50629 >= 1);
        }
        else {
            _26322 = binary_op(GREATEREQ, _obj_50629, 1);
        }
        if (IS_ATOM_INT(_26322)) {
            if (_26322 == 0) {
                DeRef(_26323);
                _26323 = 0;
                goto L8; // [140] 152
            }
        }
        else {
            if (DBL_PTR(_26322)->dbl == 0.0) {
                DeRef(_26323);
                _26323 = 0;
                goto L8; // [140] 152
            }
        }
        if (IS_ATOM_INT(_obj_50629)) {
            _26324 = (_obj_50629 <= 255);
        }
        else {
            _26324 = binary_op(LESSEQ, _obj_50629, 255);
        }
        DeRef(_26323);
        if (IS_ATOM_INT(_26324))
        _26323 = (_26324 != 0);
        else
        _26323 = DBL_PTR(_26324)->dbl != 0.0;
L8: 
        DeRef(_26321);
        _26321 = (_26323 != 0);
L7: 
        if (_26321 == 0)
        {
            _26321 = NOVALUE;
            goto L6; // [157] 169
        }
        else{
            _26321 = NOVALUE;
        }

        /** 			element_vals = prepend(element_vals, obj)*/
        Ref(_obj_50629);
        Prepend(&_element_vals_50634, _element_vals_50634, _obj_50629);
        goto L9; // [166] 176
L6: 

        /** 			return -1*/
        DeRefDS(_elements_50628);
        DeRef(_obj_50629);
        DeRef(_element_vals_50634);
        DeRef(_26320);
        _26320 = NOVALUE;
        DeRef(_26316);
        _26316 = NOVALUE;
        DeRef(_26322);
        _26322 = NOVALUE;
        DeRef(_26324);
        _26324 = NOVALUE;
        return -1;
L9: 

        /** 	end for*/
        _i_50641 = _i_50641 + 1;
        goto L2; // [178] 50
L3: 
        ;
    }

    /** 	return element_vals*/
    DeRefDS(_elements_50628);
    DeRef(_obj_50629);
    DeRef(_26320);
    _26320 = NOVALUE;
    DeRef(_26316);
    _26316 = NOVALUE;
    DeRef(_26322);
    _26322 = NOVALUE;
    DeRef(_26324);
    _26324 = NOVALUE;
    return _element_vals_50634;
    ;
}


int _41Last_op()
{
    int _0, _1, _2;
    

    /** 	return last_op*/
    return _41last_op_50668;
    ;
}


int _41Last_pc()
{
    int _0, _1, _2;
    

    /** 	return last_pc*/
    return _41last_pc_50669;
    ;
}


void _41move_last_pc(int _amount_50676)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_amount_50676)) {
        _1 = (long)(DBL_PTR(_amount_50676)->dbl);
        DeRefDS(_amount_50676);
        _amount_50676 = _1;
    }

    /** 	if last_pc > 0 then*/
    if (_41last_pc_50669 <= 0)
    goto L1; // [7] 20

    /** 		last_pc += amount*/
    _41last_pc_50669 = _41last_pc_50669 + _amount_50676;
L1: 

    /** end procedure*/
    return;
    ;
}


void _41clear_last()
{
    int _0, _1, _2;
    

    /** 	last_op = 0*/
    _41last_op_50668 = 0;

    /** 	last_pc = 0*/
    _41last_pc_50669 = 0;

    /** end procedure*/
    return;
    ;
}


void _41clear_op()
{
    int _0, _1, _2;
    

    /** 	previous_op = -1*/
    _35previous_op_16066 = -1;

    /** 	assignable = FALSE*/
    _41assignable_49792 = _13FALSE_435;

    /** end procedure*/
    return;
    ;
}


void _41inlined_function()
{
    int _0, _1, _2;
    

    /** 	previous_op = PROC*/
    _35previous_op_16066 = 27;

    /** 	assignable = TRUE*/
    _41assignable_49792 = _13TRUE_437;

    /** 	inlined = TRUE*/
    _41inlined_50687 = _13TRUE_437;

    /** end procedure*/
    return;
    ;
}


void _41add_inline_target(int _pc_50698)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_50698)) {
        _1 = (long)(DBL_PTR(_pc_50698)->dbl);
        DeRefDS(_pc_50698);
        _pc_50698 = _1;
    }

    /** 	inlined_targets &= pc*/
    Append(&_41inlined_targets_50695, _41inlined_targets_50695, _pc_50698);

    /** end procedure*/
    return;
    ;
}


void _41clear_inline_targets()
{
    int _0, _1, _2;
    

    /** 	inlined_targets = {}*/
    RefDS(_21815);
    DeRefi(_41inlined_targets_50695);
    _41inlined_targets_50695 = _21815;

    /** end procedure*/
    return;
    ;
}


void _41emit_inline(int _code_50704)
{
    int _0, _1, _2;
    

    /** 	last_pc = 0*/
    _41last_pc_50669 = 0;

    /** 	last_op = 0*/
    _41last_op_50668 = 0;

    /** 	Code &= code*/
    Concat((object_ptr)&_35Code_16056, _35Code_16056, _code_50704);

    /** end procedure*/
    DeRefDS(_code_50704);
    return;
    ;
}


void _41emit_op(int _op_50709)
{
    int _a_50711 = NOVALUE;
    int _b_50712 = NOVALUE;
    int _c_50713 = NOVALUE;
    int _d_50714 = NOVALUE;
    int _source_50715 = NOVALUE;
    int _target_50716 = NOVALUE;
    int _subsym_50717 = NOVALUE;
    int _lhs_var_50719 = NOVALUE;
    int _ib_50720 = NOVALUE;
    int _ic_50721 = NOVALUE;
    int _n_50722 = NOVALUE;
    int _obj_50723 = NOVALUE;
    int _elements_50724 = NOVALUE;
    int _element_vals_50725 = NOVALUE;
    int _last_pc_backup_50726 = NOVALUE;
    int _last_op_backup_50727 = NOVALUE;
    int _temp_50736 = NOVALUE;
    int _real_op_51024 = NOVALUE;
    int _ref_51031 = NOVALUE;
    int _paths_51061 = NOVALUE;
    int _if_code_51141 = NOVALUE;
    int _if_code_51180 = NOVALUE;
    int _Top_inlined_Top_at_5195_51747 = NOVALUE;
    int _element_51818 = NOVALUE;
    int _Top_inlined_Top_at_6750_51965 = NOVALUE;
    int _31376 = NOVALUE;
    int _31375 = NOVALUE;
    int _26905 = NOVALUE;
    int _26901 = NOVALUE;
    int _26898 = NOVALUE;
    int _26896 = NOVALUE;
    int _26890 = NOVALUE;
    int _26889 = NOVALUE;
    int _26888 = NOVALUE;
    int _26886 = NOVALUE;
    int _26884 = NOVALUE;
    int _26883 = NOVALUE;
    int _26882 = NOVALUE;
    int _26881 = NOVALUE;
    int _26880 = NOVALUE;
    int _26879 = NOVALUE;
    int _26878 = NOVALUE;
    int _26877 = NOVALUE;
    int _26876 = NOVALUE;
    int _26875 = NOVALUE;
    int _26874 = NOVALUE;
    int _26872 = NOVALUE;
    int _26871 = NOVALUE;
    int _26870 = NOVALUE;
    int _26868 = NOVALUE;
    int _26867 = NOVALUE;
    int _26866 = NOVALUE;
    int _26865 = NOVALUE;
    int _26864 = NOVALUE;
    int _26863 = NOVALUE;
    int _26862 = NOVALUE;
    int _26861 = NOVALUE;
    int _26860 = NOVALUE;
    int _26857 = NOVALUE;
    int _26854 = NOVALUE;
    int _26853 = NOVALUE;
    int _26852 = NOVALUE;
    int _26851 = NOVALUE;
    int _26849 = NOVALUE;
    int _26847 = NOVALUE;
    int _26835 = NOVALUE;
    int _26827 = NOVALUE;
    int _26824 = NOVALUE;
    int _26823 = NOVALUE;
    int _26822 = NOVALUE;
    int _26821 = NOVALUE;
    int _26818 = NOVALUE;
    int _26817 = NOVALUE;
    int _26816 = NOVALUE;
    int _26815 = NOVALUE;
    int _26814 = NOVALUE;
    int _26813 = NOVALUE;
    int _26812 = NOVALUE;
    int _26811 = NOVALUE;
    int _26810 = NOVALUE;
    int _26809 = NOVALUE;
    int _26808 = NOVALUE;
    int _26806 = NOVALUE;
    int _26802 = NOVALUE;
    int _26801 = NOVALUE;
    int _26800 = NOVALUE;
    int _26799 = NOVALUE;
    int _26798 = NOVALUE;
    int _26797 = NOVALUE;
    int _26796 = NOVALUE;
    int _26795 = NOVALUE;
    int _26794 = NOVALUE;
    int _26793 = NOVALUE;
    int _26792 = NOVALUE;
    int _26790 = NOVALUE;
    int _26785 = NOVALUE;
    int _26784 = NOVALUE;
    int _26782 = NOVALUE;
    int _26781 = NOVALUE;
    int _26780 = NOVALUE;
    int _26778 = NOVALUE;
    int _26775 = NOVALUE;
    int _26771 = NOVALUE;
    int _26768 = NOVALUE;
    int _26767 = NOVALUE;
    int _26766 = NOVALUE;
    int _26765 = NOVALUE;
    int _26764 = NOVALUE;
    int _26763 = NOVALUE;
    int _26761 = NOVALUE;
    int _26760 = NOVALUE;
    int _26758 = NOVALUE;
    int _26757 = NOVALUE;
    int _26756 = NOVALUE;
    int _26755 = NOVALUE;
    int _26754 = NOVALUE;
    int _26753 = NOVALUE;
    int _26752 = NOVALUE;
    int _26751 = NOVALUE;
    int _26750 = NOVALUE;
    int _26749 = NOVALUE;
    int _26747 = NOVALUE;
    int _26746 = NOVALUE;
    int _26745 = NOVALUE;
    int _26744 = NOVALUE;
    int _26743 = NOVALUE;
    int _26742 = NOVALUE;
    int _26741 = NOVALUE;
    int _26740 = NOVALUE;
    int _26739 = NOVALUE;
    int _26738 = NOVALUE;
    int _26737 = NOVALUE;
    int _26736 = NOVALUE;
    int _26735 = NOVALUE;
    int _26734 = NOVALUE;
    int _26733 = NOVALUE;
    int _26731 = NOVALUE;
    int _26728 = NOVALUE;
    int _26727 = NOVALUE;
    int _26726 = NOVALUE;
    int _26725 = NOVALUE;
    int _26724 = NOVALUE;
    int _26723 = NOVALUE;
    int _26722 = NOVALUE;
    int _26721 = NOVALUE;
    int _26720 = NOVALUE;
    int _26719 = NOVALUE;
    int _26718 = NOVALUE;
    int _26717 = NOVALUE;
    int _26716 = NOVALUE;
    int _26715 = NOVALUE;
    int _26714 = NOVALUE;
    int _26712 = NOVALUE;
    int _26708 = NOVALUE;
    int _26705 = NOVALUE;
    int _26703 = NOVALUE;
    int _26702 = NOVALUE;
    int _26700 = NOVALUE;
    int _26699 = NOVALUE;
    int _26698 = NOVALUE;
    int _26697 = NOVALUE;
    int _26696 = NOVALUE;
    int _26695 = NOVALUE;
    int _26694 = NOVALUE;
    int _26693 = NOVALUE;
    int _26692 = NOVALUE;
    int _26691 = NOVALUE;
    int _26690 = NOVALUE;
    int _26689 = NOVALUE;
    int _26688 = NOVALUE;
    int _26687 = NOVALUE;
    int _26686 = NOVALUE;
    int _26685 = NOVALUE;
    int _26684 = NOVALUE;
    int _26683 = NOVALUE;
    int _26682 = NOVALUE;
    int _26680 = NOVALUE;
    int _26678 = NOVALUE;
    int _26677 = NOVALUE;
    int _26675 = NOVALUE;
    int _26665 = NOVALUE;
    int _26664 = NOVALUE;
    int _26663 = NOVALUE;
    int _26662 = NOVALUE;
    int _26661 = NOVALUE;
    int _26660 = NOVALUE;
    int _26659 = NOVALUE;
    int _26658 = NOVALUE;
    int _26657 = NOVALUE;
    int _26656 = NOVALUE;
    int _26655 = NOVALUE;
    int _26654 = NOVALUE;
    int _26653 = NOVALUE;
    int _26652 = NOVALUE;
    int _26651 = NOVALUE;
    int _26650 = NOVALUE;
    int _26649 = NOVALUE;
    int _26648 = NOVALUE;
    int _26647 = NOVALUE;
    int _26646 = NOVALUE;
    int _26645 = NOVALUE;
    int _26644 = NOVALUE;
    int _26643 = NOVALUE;
    int _26642 = NOVALUE;
    int _26636 = NOVALUE;
    int _26635 = NOVALUE;
    int _26632 = NOVALUE;
    int _26629 = NOVALUE;
    int _26628 = NOVALUE;
    int _26627 = NOVALUE;
    int _26626 = NOVALUE;
    int _26625 = NOVALUE;
    int _26624 = NOVALUE;
    int _26623 = NOVALUE;
    int _26622 = NOVALUE;
    int _26621 = NOVALUE;
    int _26620 = NOVALUE;
    int _26618 = NOVALUE;
    int _26617 = NOVALUE;
    int _26616 = NOVALUE;
    int _26614 = NOVALUE;
    int _26612 = NOVALUE;
    int _26611 = NOVALUE;
    int _26610 = NOVALUE;
    int _26609 = NOVALUE;
    int _26608 = NOVALUE;
    int _26607 = NOVALUE;
    int _26606 = NOVALUE;
    int _26605 = NOVALUE;
    int _26604 = NOVALUE;
    int _26603 = NOVALUE;
    int _26601 = NOVALUE;
    int _26600 = NOVALUE;
    int _26598 = NOVALUE;
    int _26597 = NOVALUE;
    int _26596 = NOVALUE;
    int _26595 = NOVALUE;
    int _26594 = NOVALUE;
    int _26592 = NOVALUE;
    int _26591 = NOVALUE;
    int _26590 = NOVALUE;
    int _26589 = NOVALUE;
    int _26588 = NOVALUE;
    int _26587 = NOVALUE;
    int _26586 = NOVALUE;
    int _26585 = NOVALUE;
    int _26583 = NOVALUE;
    int _26582 = NOVALUE;
    int _26581 = NOVALUE;
    int _26580 = NOVALUE;
    int _26579 = NOVALUE;
    int _26577 = NOVALUE;
    int _26576 = NOVALUE;
    int _26574 = NOVALUE;
    int _26573 = NOVALUE;
    int _26572 = NOVALUE;
    int _26571 = NOVALUE;
    int _26570 = NOVALUE;
    int _26568 = NOVALUE;
    int _26566 = NOVALUE;
    int _26564 = NOVALUE;
    int _26563 = NOVALUE;
    int _26561 = NOVALUE;
    int _26560 = NOVALUE;
    int _26559 = NOVALUE;
    int _26558 = NOVALUE;
    int _26557 = NOVALUE;
    int _26556 = NOVALUE;
    int _26555 = NOVALUE;
    int _26554 = NOVALUE;
    int _26553 = NOVALUE;
    int _26552 = NOVALUE;
    int _26551 = NOVALUE;
    int _26550 = NOVALUE;
    int _26549 = NOVALUE;
    int _26548 = NOVALUE;
    int _26547 = NOVALUE;
    int _26546 = NOVALUE;
    int _26545 = NOVALUE;
    int _26542 = NOVALUE;
    int _26541 = NOVALUE;
    int _26539 = NOVALUE;
    int _26538 = NOVALUE;
    int _26537 = NOVALUE;
    int _26536 = NOVALUE;
    int _26535 = NOVALUE;
    int _26533 = NOVALUE;
    int _26531 = NOVALUE;
    int _26530 = NOVALUE;
    int _26529 = NOVALUE;
    int _26528 = NOVALUE;
    int _26527 = NOVALUE;
    int _26526 = NOVALUE;
    int _26525 = NOVALUE;
    int _26524 = NOVALUE;
    int _26523 = NOVALUE;
    int _26520 = NOVALUE;
    int _26519 = NOVALUE;
    int _26517 = NOVALUE;
    int _26516 = NOVALUE;
    int _26515 = NOVALUE;
    int _26514 = NOVALUE;
    int _26513 = NOVALUE;
    int _26510 = NOVALUE;
    int _26509 = NOVALUE;
    int _26508 = NOVALUE;
    int _26507 = NOVALUE;
    int _26506 = NOVALUE;
    int _26505 = NOVALUE;
    int _26504 = NOVALUE;
    int _26499 = NOVALUE;
    int _26498 = NOVALUE;
    int _26497 = NOVALUE;
    int _26495 = NOVALUE;
    int _26494 = NOVALUE;
    int _26492 = NOVALUE;
    int _26491 = NOVALUE;
    int _26486 = NOVALUE;
    int _26485 = NOVALUE;
    int _26484 = NOVALUE;
    int _26483 = NOVALUE;
    int _26482 = NOVALUE;
    int _26476 = NOVALUE;
    int _26475 = NOVALUE;
    int _26473 = NOVALUE;
    int _26472 = NOVALUE;
    int _26471 = NOVALUE;
    int _26470 = NOVALUE;
    int _26469 = NOVALUE;
    int _26468 = NOVALUE;
    int _26466 = NOVALUE;
    int _26465 = NOVALUE;
    int _26464 = NOVALUE;
    int _26463 = NOVALUE;
    int _26462 = NOVALUE;
    int _26461 = NOVALUE;
    int _26460 = NOVALUE;
    int _26459 = NOVALUE;
    int _26458 = NOVALUE;
    int _26457 = NOVALUE;
    int _26456 = NOVALUE;
    int _26455 = NOVALUE;
    int _26454 = NOVALUE;
    int _26453 = NOVALUE;
    int _26451 = NOVALUE;
    int _26450 = NOVALUE;
    int _26449 = NOVALUE;
    int _26448 = NOVALUE;
    int _26445 = NOVALUE;
    int _26444 = NOVALUE;
    int _26443 = NOVALUE;
    int _26442 = NOVALUE;
    int _26440 = NOVALUE;
    int _26439 = NOVALUE;
    int _26438 = NOVALUE;
    int _26437 = NOVALUE;
    int _26435 = NOVALUE;
    int _26434 = NOVALUE;
    int _26433 = NOVALUE;
    int _26432 = NOVALUE;
    int _26431 = NOVALUE;
    int _26430 = NOVALUE;
    int _26429 = NOVALUE;
    int _26428 = NOVALUE;
    int _26427 = NOVALUE;
    int _26426 = NOVALUE;
    int _26425 = NOVALUE;
    int _26424 = NOVALUE;
    int _26423 = NOVALUE;
    int _26422 = NOVALUE;
    int _26420 = NOVALUE;
    int _26419 = NOVALUE;
    int _26418 = NOVALUE;
    int _26417 = NOVALUE;
    int _26416 = NOVALUE;
    int _26414 = NOVALUE;
    int _26413 = NOVALUE;
    int _26412 = NOVALUE;
    int _26411 = NOVALUE;
    int _26410 = NOVALUE;
    int _26406 = NOVALUE;
    int _26405 = NOVALUE;
    int _26404 = NOVALUE;
    int _26403 = NOVALUE;
    int _26402 = NOVALUE;
    int _26400 = NOVALUE;
    int _26399 = NOVALUE;
    int _26398 = NOVALUE;
    int _26397 = NOVALUE;
    int _26396 = NOVALUE;
    int _26395 = NOVALUE;
    int _26394 = NOVALUE;
    int _26393 = NOVALUE;
    int _26392 = NOVALUE;
    int _26391 = NOVALUE;
    int _26390 = NOVALUE;
    int _26389 = NOVALUE;
    int _26388 = NOVALUE;
    int _26387 = NOVALUE;
    int _26386 = NOVALUE;
    int _26385 = NOVALUE;
    int _26384 = NOVALUE;
    int _26383 = NOVALUE;
    int _26381 = NOVALUE;
    int _26380 = NOVALUE;
    int _26379 = NOVALUE;
    int _26378 = NOVALUE;
    int _26377 = NOVALUE;
    int _26376 = NOVALUE;
    int _26375 = NOVALUE;
    int _26374 = NOVALUE;
    int _26373 = NOVALUE;
    int _26371 = NOVALUE;
    int _26370 = NOVALUE;
    int _26369 = NOVALUE;
    int _26367 = NOVALUE;
    int _26366 = NOVALUE;
    int _26364 = NOVALUE;
    int _26362 = NOVALUE;
    int _26361 = NOVALUE;
    int _26360 = NOVALUE;
    int _26359 = NOVALUE;
    int _26358 = NOVALUE;
    int _26357 = NOVALUE;
    int _26353 = NOVALUE;
    int _26352 = NOVALUE;
    int _26351 = NOVALUE;
    int _26349 = NOVALUE;
    int _26348 = NOVALUE;
    int _26347 = NOVALUE;
    int _26346 = NOVALUE;
    int _26345 = NOVALUE;
    int _26344 = NOVALUE;
    int _26343 = NOVALUE;
    int _26342 = NOVALUE;
    int _26341 = NOVALUE;
    int _26340 = NOVALUE;
    int _26339 = NOVALUE;
    int _26338 = NOVALUE;
    int _26337 = NOVALUE;
    int _26336 = NOVALUE;
    int _26335 = NOVALUE;
    int _26330 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_op_50709)) {
        _1 = (long)(DBL_PTR(_op_50709)->dbl);
        DeRefDS(_op_50709);
        _op_50709 = _1;
    }

    /** 	integer ib, ic, n*/

    /** 	object obj*/

    /** 	sequence elements*/

    /** 	object element_vals*/

    /** 	check_for_temps()*/
    _41check_for_temps();

    /** 	integer last_pc_backup = last_pc*/
    _last_pc_backup_50726 = _41last_pc_50669;

    /** 	integer last_op_backup = last_op*/
    _last_op_backup_50727 = _41last_op_50668;

    /** 	last_op = op*/
    _41last_op_50668 = _op_50709;

    /** 	last_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _26330 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _26330 = 1;
    }
    _41last_pc_50669 = _26330 + 1;
    _26330 = NOVALUE;

    /** 	switch op label "EMIT" do*/
    _0 = _op_50709;
    switch ( _0 ){ 

        /** 	case ASSIGN then*/
        case 18:

        /** 		sequence temp = {}*/
        RefDS(_21815);
        DeRef(_temp_50736);
        _temp_50736 = _21815;

        /** 		if not TRANSLATE and*/
        _26335 = (_35TRANSLATE_15611 == 0);
        if (_26335 == 0) {
            goto L1; // [70] 202
        }
        _26337 = (_35previous_op_16066 == 92);
        if (_26337 != 0) {
            DeRef(_26338);
            _26338 = 1;
            goto L2; // [82] 98
        }
        _26339 = (_35previous_op_16066 == 25);
        _26338 = (_26339 != 0);
L2: 
        if (_26338 == 0)
        {
            _26338 = NOVALUE;
            goto L1; // [99] 202
        }
        else{
            _26338 = NOVALUE;
        }

        /** 			while Code[$-1] = DEREF_TEMP and find( Code[$], derefs ) do*/
L3: 
        if (IS_SEQUENCE(_35Code_16056)){
                _26340 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26340 = 1;
        }
        _26341 = _26340 - 1;
        _26340 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26342 = (int)*(((s1_ptr)_2)->base + _26341);
        if (IS_ATOM_INT(_26342)) {
            _26343 = (_26342 == 208);
        }
        else {
            _26343 = binary_op(EQUALS, _26342, 208);
        }
        _26342 = NOVALUE;
        if (IS_ATOM_INT(_26343)) {
            if (_26343 == 0) {
                goto L4; // [126] 201
            }
        }
        else {
            if (DBL_PTR(_26343)->dbl == 0.0) {
                goto L4; // [126] 201
            }
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _26345 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26345 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26346 = (int)*(((s1_ptr)_2)->base + _26345);
        _26347 = find_from(_26346, _41derefs_50293, 1);
        _26346 = NOVALUE;
        if (_26347 == 0)
        {
            _26347 = NOVALUE;
            goto L4; // [147] 201
        }
        else{
            _26347 = NOVALUE;
        }

        /** 				temp &= Code[$]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26348 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26348 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26349 = (int)*(((s1_ptr)_2)->base + _26348);
        if (IS_SEQUENCE(_temp_50736) && IS_ATOM(_26349)) {
            Ref(_26349);
            Append(&_temp_50736, _temp_50736, _26349);
        }
        else if (IS_ATOM(_temp_50736) && IS_SEQUENCE(_26349)) {
        }
        else {
            Concat((object_ptr)&_temp_50736, _temp_50736, _26349);
        }
        _26349 = NOVALUE;

        /** 				Code = remove( Code, length(Code)-1, length(Code) )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26351 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26351 = 1;
        }
        _26352 = _26351 - 1;
        _26351 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16056)){
                _26353 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26353 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_35Code_16056);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26352)) ? _26352 : (long)(DBL_PTR(_26352)->dbl);
            int stop = (IS_ATOM_INT(_26353)) ? _26353 : (long)(DBL_PTR(_26353)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_35Code_16056), start, &_35Code_16056 );
                }
                else Tail(SEQ_PTR(_35Code_16056), stop+1, &_35Code_16056);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_35Code_16056), start, &_35Code_16056);
            }
            else {
                assign_slice_seq = &assign_space;
                _35Code_16056 = Remove_elements(start, stop, (SEQ_PTR(_35Code_16056)->ref == 1));
            }
        }
        _26352 = NOVALUE;
        _26353 = NOVALUE;

        /** 				emit_temp( temp, NEW_REFERENCE )*/
        RefDS(_temp_50736);
        _41emit_temp(_temp_50736, 1);

        /** 			end while*/
        goto L3; // [198] 107
L4: 
L1: 

        /** 		source = Pop()*/
        _source_50715 = _41Pop();
        if (!IS_ATOM_INT(_source_50715)) {
            _1 = (long)(DBL_PTR(_source_50715)->dbl);
            DeRefDS(_source_50715);
            _source_50715 = _1;
        }

        /** 		target = Pop()*/
        _target_50716 = _41Pop();
        if (!IS_ATOM_INT(_target_50716)) {
            _1 = (long)(DBL_PTR(_target_50716)->dbl);
            DeRefDS(_target_50716);
            _target_50716 = _1;
        }

        /** 		if assignable then*/
        if (_41assignable_49792 == 0)
        {
            goto L5; // [220] 601
        }
        else{
        }

        /** 			if inlined then*/
        if (_41inlined_50687 == 0)
        {
            goto L6; // [227] 326
        }
        else{
        }

        /** 				inlined = 0*/
        _41inlined_50687 = 0;

        /** 				if length( inlined_targets ) then*/
        if (IS_SEQUENCE(_41inlined_targets_50695)){
                _26357 = SEQ_PTR(_41inlined_targets_50695)->length;
        }
        else {
            _26357 = 1;
        }
        if (_26357 == 0)
        {
            _26357 = NOVALUE;
            goto L7; // [242] 295
        }
        else{
            _26357 = NOVALUE;
        }

        /** 					for i = 1 to length( inlined_targets ) do*/
        if (IS_SEQUENCE(_41inlined_targets_50695)){
                _26358 = SEQ_PTR(_41inlined_targets_50695)->length;
        }
        else {
            _26358 = 1;
        }
        {
            int _i_50779;
            _i_50779 = 1;
L8: 
            if (_i_50779 > _26358){
                goto L9; // [252] 280
            }

            /** 						Code[inlined_targets[i]] = target*/
            _2 = (int)SEQ_PTR(_41inlined_targets_50695);
            _26359 = (int)*(((s1_ptr)_2)->base + _i_50779);
            _2 = (int)SEQ_PTR(_35Code_16056);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _35Code_16056 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _26359);
            _1 = *(int *)_2;
            *(int *)_2 = _target_50716;
            DeRef(_1);

            /** 					end for*/
            _i_50779 = _i_50779 + 1;
            goto L8; // [275] 259
L9: 
            ;
        }

        /** 					clear_inline_targets()*/

        /** 	inlined_targets = {}*/
        RefDS(_21815);
        DeRefi(_41inlined_targets_50695);
        _41inlined_targets_50695 = _21815;

        /** end procedure*/
        goto LA; // [291] 294
LA: 
L7: 

        /** 				assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 				clear_last()*/

        /** 	last_op = 0*/
        _41last_op_50668 = 0;

        /** 	last_pc = 0*/
        _41last_pc_50669 = 0;

        /** end procedure*/
        goto LB; // [316] 319
LB: 

        /** 				break "EMIT"*/
        DeRef(_temp_50736);
        _temp_50736 = NOVALUE;
        goto LC; // [323] 7412
L6: 

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26360 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26360 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26361 = (int)*(((s1_ptr)_2)->base + _26360);
        Ref(_26361);
        _41clear_temp(_26361);
        _26361 = NOVALUE;

        /** 			Code = remove( Code, length( Code ) ) -- drop previous target*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26362 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26362 = 1;
        }
        {
            s1_ptr assign_space = SEQ_PTR(_35Code_16056);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_26362)) ? _26362 : (long)(DBL_PTR(_26362)->dbl);
            int stop = (IS_ATOM_INT(_26362)) ? _26362 : (long)(DBL_PTR(_26362)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_35Code_16056), start, &_35Code_16056 );
                }
                else Tail(SEQ_PTR(_35Code_16056), stop+1, &_35Code_16056);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_35Code_16056), start, &_35Code_16056);
            }
            else {
                assign_slice_seq = &assign_space;
                _35Code_16056 = Remove_elements(start, stop, (SEQ_PTR(_35Code_16056)->ref == 1));
            }
        }
        _26362 = NOVALUE;
        _26362 = NOVALUE;

        /** 			op = previous_op -- keep same previous op*/
        _op_50709 = _35previous_op_16066;

        /** 			if IsInteger(target) then*/
        _26364 = _41IsInteger(_target_50716);
        if (_26364 == 0) {
            DeRef(_26364);
            _26364 = NOVALUE;
            goto LD; // [372] 588
        }
        else {
            if (!IS_ATOM_INT(_26364) && DBL_PTR(_26364)->dbl == 0.0){
                DeRef(_26364);
                _26364 = NOVALUE;
                goto LD; // [372] 588
            }
            DeRef(_26364);
            _26364 = NOVALUE;
        }
        DeRef(_26364);
        _26364 = NOVALUE;

        /** 				if previous_op = RHS_SUBS then*/
        if (_35previous_op_16066 != 25)
        goto LE; // [381] 412

        /** 					op = RHS_SUBS_I*/
        _op_50709 = 114;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26366 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26366 = 1;
        }
        _26367 = _26366 - 2;
        _26366 = NOVALUE;
        _41backpatch(_26367, 114);
        _26367 = NOVALUE;
        goto LF; // [409] 587
LE: 

        /** 				elsif previous_op = PLUS1 then*/
        if (_35previous_op_16066 != 93)
        goto L10; // [418] 449

        /** 					op = PLUS1_I*/
        _op_50709 = 117;

        /** 					backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26369 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26369 = 1;
        }
        _26370 = _26369 - 2;
        _26369 = NOVALUE;
        _41backpatch(_26370, 117);
        _26370 = NOVALUE;
        goto LF; // [446] 587
L10: 

        /** 				elsif previous_op = PLUS or previous_op = MINUS then*/
        _26371 = (_35previous_op_16066 == 11);
        if (_26371 != 0) {
            goto L11; // [459] 476
        }
        _26373 = (_35previous_op_16066 == 10);
        if (_26373 == 0)
        {
            DeRef(_26373);
            _26373 = NOVALUE;
            goto L12; // [472] 567
        }
        else{
            DeRef(_26373);
            _26373 = NOVALUE;
        }
L11: 

        /** 					if IsInteger(Code[$]) and*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26374 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26374 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26375 = (int)*(((s1_ptr)_2)->base + _26374);
        Ref(_26375);
        _26376 = _41IsInteger(_26375);
        _26375 = NOVALUE;
        if (IS_ATOM_INT(_26376)) {
            if (_26376 == 0) {
                goto LF; // [491] 587
            }
        }
        else {
            if (DBL_PTR(_26376)->dbl == 0.0) {
                goto LF; // [491] 587
            }
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _26378 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26378 = 1;
        }
        _26379 = _26378 - 1;
        _26378 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26380 = (int)*(((s1_ptr)_2)->base + _26379);
        Ref(_26380);
        _26381 = _41IsInteger(_26380);
        _26380 = NOVALUE;
        if (_26381 == 0) {
            DeRef(_26381);
            _26381 = NOVALUE;
            goto LF; // [513] 587
        }
        else {
            if (!IS_ATOM_INT(_26381) && DBL_PTR(_26381)->dbl == 0.0){
                DeRef(_26381);
                _26381 = NOVALUE;
                goto LF; // [513] 587
            }
            DeRef(_26381);
            _26381 = NOVALUE;
        }
        DeRef(_26381);
        _26381 = NOVALUE;

        /** 						if previous_op = PLUS then*/
        if (_35previous_op_16066 != 11)
        goto L13; // [522] 538

        /** 							op = PLUS_I*/
        _op_50709 = 115;
        goto L14; // [535] 548
L13: 

        /** 							op = MINUS_I*/
        _op_50709 = 116;
L14: 

        /** 						backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26383 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26383 = 1;
        }
        _26384 = _26383 - 2;
        _26383 = NOVALUE;
        _41backpatch(_26384, _op_50709);
        _26384 = NOVALUE;
        goto LF; // [564] 587
L12: 

        /** 					if IsInteger(source) then*/
        _26385 = _41IsInteger(_source_50715);
        if (_26385 == 0) {
            DeRef(_26385);
            _26385 = NOVALUE;
            goto L15; // [573] 586
        }
        else {
            if (!IS_ATOM_INT(_26385) && DBL_PTR(_26385)->dbl == 0.0){
                DeRef(_26385);
                _26385 = NOVALUE;
                goto L15; // [573] 586
            }
            DeRef(_26385);
            _26385 = NOVALUE;
        }
        DeRef(_26385);
        _26385 = NOVALUE;

        /** 						op = ASSIGN_I -- fake to avoid subsequent check*/
        _op_50709 = 113;
L15: 
LF: 
LD: 

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto L16; // [598] 743
L5: 

        /** 			if IsInteger(source) and IsInteger(target) then*/
        _26386 = _41IsInteger(_source_50715);
        if (IS_ATOM_INT(_26386)) {
            if (_26386 == 0) {
                goto L17; // [607] 629
            }
        }
        else {
            if (DBL_PTR(_26386)->dbl == 0.0) {
                goto L17; // [607] 629
            }
        }
        _26388 = _41IsInteger(_target_50716);
        if (_26388 == 0) {
            DeRef(_26388);
            _26388 = NOVALUE;
            goto L17; // [616] 629
        }
        else {
            if (!IS_ATOM_INT(_26388) && DBL_PTR(_26388)->dbl == 0.0){
                DeRef(_26388);
                _26388 = NOVALUE;
                goto L17; // [616] 629
            }
            DeRef(_26388);
            _26388 = NOVALUE;
        }
        DeRef(_26388);
        _26388 = NOVALUE;

        /** 				op = ASSIGN_I*/
        _op_50709 = 113;
L17: 

        /** 			if source > 0 and target > 0 and*/
        _26389 = (_source_50715 > 0);
        if (_26389 == 0) {
            _26390 = 0;
            goto L18; // [635] 647
        }
        _26391 = (_target_50716 > 0);
        _26390 = (_26391 != 0);
L18: 
        if (_26390 == 0) {
            _26392 = 0;
            goto L19; // [647] 673
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26393 = (int)*(((s1_ptr)_2)->base + _source_50715);
        _2 = (int)SEQ_PTR(_26393);
        _26394 = (int)*(((s1_ptr)_2)->base + 3);
        _26393 = NOVALUE;
        if (IS_ATOM_INT(_26394)) {
            _26395 = (_26394 == 2);
        }
        else {
            _26395 = binary_op(EQUALS, _26394, 2);
        }
        _26394 = NOVALUE;
        if (IS_ATOM_INT(_26395))
        _26392 = (_26395 != 0);
        else
        _26392 = DBL_PTR(_26395)->dbl != 0.0;
L19: 
        if (_26392 == 0) {
            goto L1A; // [673] 727
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26397 = (int)*(((s1_ptr)_2)->base + _target_50716);
        _2 = (int)SEQ_PTR(_26397);
        _26398 = (int)*(((s1_ptr)_2)->base + 3);
        _26397 = NOVALUE;
        if (IS_ATOM_INT(_26398)) {
            _26399 = (_26398 == 2);
        }
        else {
            _26399 = binary_op(EQUALS, _26398, 2);
        }
        _26398 = NOVALUE;
        if (_26399 == 0) {
            DeRef(_26399);
            _26399 = NOVALUE;
            goto L1A; // [696] 727
        }
        else {
            if (!IS_ATOM_INT(_26399) && DBL_PTR(_26399)->dbl == 0.0){
                DeRef(_26399);
                _26399 = NOVALUE;
                goto L1A; // [696] 727
            }
            DeRef(_26399);
            _26399 = NOVALUE;
        }
        DeRef(_26399);
        _26399 = NOVALUE;

        /** 				SymTab[target][S_OBJ] = SymTab[source][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_target_50716 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26402 = (int)*(((s1_ptr)_2)->base + _source_50715);
        _2 = (int)SEQ_PTR(_26402);
        _26403 = (int)*(((s1_ptr)_2)->base + 1);
        _26402 = NOVALUE;
        Ref(_26403);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _26403;
        if( _1 != _26403 ){
            DeRef(_1);
        }
        _26403 = NOVALUE;
        _26400 = NOVALUE;
L1A: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(source)*/
        _41emit_addr(_source_50715);

        /** 			last_op = op*/
        _41last_op_50668 = _op_50709;
L16: 

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		emit_addr(target)*/
        _41emit_addr(_target_50716);

        /** 		if length(temp) then*/
        if (IS_SEQUENCE(_temp_50736)){
                _26404 = SEQ_PTR(_temp_50736)->length;
        }
        else {
            _26404 = 1;
        }
        if (_26404 == 0)
        {
            _26404 = NOVALUE;
            goto L1B; // [760] 792
        }
        else{
            _26404 = NOVALUE;
        }

        /** 			for i = 1 to length( temp ) do*/
        if (IS_SEQUENCE(_temp_50736)){
                _26405 = SEQ_PTR(_temp_50736)->length;
        }
        else {
            _26405 = 1;
        }
        {
            int _i_50882;
            _i_50882 = 1;
L1C: 
            if (_i_50882 > _26405){
                goto L1D; // [768] 791
            }

            /** 				flush_temp( temp[i] )*/
            _2 = (int)SEQ_PTR(_temp_50736);
            _26406 = (int)*(((s1_ptr)_2)->base + _i_50882);
            Ref(_26406);
            _41flush_temp(_26406);
            _26406 = NOVALUE;

            /** 			end for*/
            _i_50882 = _i_50882 + 1;
            goto L1C; // [786] 775
L1D: 
            ;
        }
L1B: 
        DeRef(_temp_50736);
        _temp_50736 = NOVALUE;
        goto LC; // [794] 7412

        /** 	case RHS_SUBS then*/
        case 25:

        /** 		b = Pop() -- subscript*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		target = NewTempSym() -- target*/
        _target_50716 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_target_50716)) {
            _1 = (long)(DBL_PTR(_target_50716)->dbl);
            DeRefDS(_target_50716);
            _target_50716 = _1;
        }

        /** 		if c < 0 or length(SymTab[c]) < S_VTYPE or SymTab[c][S_VTYPE] < 0 then -- forward reference*/
        _26410 = (_c_50713 < 0);
        if (_26410 != 0) {
            _26411 = 1;
            goto L1E; // [828] 851
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26412 = (int)*(((s1_ptr)_2)->base + _c_50713);
        if (IS_SEQUENCE(_26412)){
                _26413 = SEQ_PTR(_26412)->length;
        }
        else {
            _26413 = 1;
        }
        _26412 = NOVALUE;
        _26414 = (_26413 < 15);
        _26413 = NOVALUE;
        _26411 = (_26414 != 0);
L1E: 
        if (_26411 != 0) {
            goto L1F; // [851] 876
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26416 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26416);
        _26417 = (int)*(((s1_ptr)_2)->base + 15);
        _26416 = NOVALUE;
        if (IS_ATOM_INT(_26417)) {
            _26418 = (_26417 < 0);
        }
        else {
            _26418 = binary_op(LESS, _26417, 0);
        }
        _26417 = NOVALUE;
        if (_26418 == 0) {
            DeRef(_26418);
            _26418 = NOVALUE;
            goto L20; // [872] 888
        }
        else {
            if (!IS_ATOM_INT(_26418) && DBL_PTR(_26418)->dbl == 0.0){
                DeRef(_26418);
                _26418 = NOVALUE;
                goto L20; // [872] 888
            }
            DeRef(_26418);
            _26418 = NOVALUE;
        }
        DeRef(_26418);
        _26418 = NOVALUE;
L1F: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_50709 = 92;
        goto L21; // [885] 1049
L20: 

        /** 		elsif SymTab[c][S_MODE] = M_NORMAL then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26419 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26419);
        _26420 = (int)*(((s1_ptr)_2)->base + 3);
        _26419 = NOVALUE;
        if (binary_op_a(NOTEQ, _26420, 1)){
            _26420 = NOVALUE;
            goto L22; // [904] 991
        }
        _26420 = NOVALUE;

        /** 			if SymTab[c][S_VTYPE] != sequence_type and*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26422 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26422);
        _26423 = (int)*(((s1_ptr)_2)->base + 15);
        _26422 = NOVALUE;
        if (IS_ATOM_INT(_26423)) {
            _26424 = (_26423 != _53sequence_type_45719);
        }
        else {
            _26424 = binary_op(NOTEQ, _26423, _53sequence_type_45719);
        }
        _26423 = NOVALUE;
        if (IS_ATOM_INT(_26424)) {
            if (_26424 == 0) {
                goto L21; // [928] 1049
            }
        }
        else {
            if (DBL_PTR(_26424)->dbl == 0.0) {
                goto L21; // [928] 1049
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26426 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26426);
        _26427 = (int)*(((s1_ptr)_2)->base + 15);
        _26426 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_26427)){
            _26428 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26427)->dbl));
        }
        else{
            _26428 = (int)*(((s1_ptr)_2)->base + _26427);
        }
        _2 = (int)SEQ_PTR(_26428);
        _26429 = (int)*(((s1_ptr)_2)->base + 2);
        _26428 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_26429)){
            _26430 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26429)->dbl));
        }
        else{
            _26430 = (int)*(((s1_ptr)_2)->base + _26429);
        }
        _2 = (int)SEQ_PTR(_26430);
        _26431 = (int)*(((s1_ptr)_2)->base + 15);
        _26430 = NOVALUE;
        if (IS_ATOM_INT(_26431)) {
            _26432 = (_26431 != _53sequence_type_45719);
        }
        else {
            _26432 = binary_op(NOTEQ, _26431, _53sequence_type_45719);
        }
        _26431 = NOVALUE;
        if (_26432 == 0) {
            DeRef(_26432);
            _26432 = NOVALUE;
            goto L21; // [975] 1049
        }
        else {
            if (!IS_ATOM_INT(_26432) && DBL_PTR(_26432)->dbl == 0.0){
                DeRef(_26432);
                _26432 = NOVALUE;
                goto L21; // [975] 1049
            }
            DeRef(_26432);
            _26432 = NOVALUE;
        }
        DeRef(_26432);
        _26432 = NOVALUE;

        /** 				op = RHS_SUBS_CHECK*/
        _op_50709 = 92;
        goto L21; // [988] 1049
L22: 

        /** 		elsif SymTab[c][S_MODE] != M_CONSTANT or*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26433 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26433);
        _26434 = (int)*(((s1_ptr)_2)->base + 3);
        _26433 = NOVALUE;
        if (IS_ATOM_INT(_26434)) {
            _26435 = (_26434 != 2);
        }
        else {
            _26435 = binary_op(NOTEQ, _26434, 2);
        }
        _26434 = NOVALUE;
        if (IS_ATOM_INT(_26435)) {
            if (_26435 != 0) {
                goto L23; // [1011] 1038
            }
        }
        else {
            if (DBL_PTR(_26435)->dbl != 0.0) {
                goto L23; // [1011] 1038
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26437 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26437);
        _26438 = (int)*(((s1_ptr)_2)->base + 1);
        _26437 = NOVALUE;
        _26439 = IS_SEQUENCE(_26438);
        _26438 = NOVALUE;
        _26440 = (_26439 == 0);
        _26439 = NOVALUE;
        if (_26440 == 0)
        {
            DeRef(_26440);
            _26440 = NOVALUE;
            goto L24; // [1034] 1048
        }
        else{
            DeRef(_26440);
            _26440 = NOVALUE;
        }
L23: 

        /** 			op = RHS_SUBS_CHECK*/
        _op_50709 = 92;
L24: 
L21: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		Push(target)*/
        _41Push(_target_50716);

        /** 		emit_addr(target)*/
        _41emit_addr(_target_50716);

        /** 		emit_temp(target, NEW_REFERENCE)*/
        _41emit_temp(_target_50716, 1);

        /** 		current_sequence = append(current_sequence, target)*/
        Append(&_41current_sequence_49782, _41current_sequence_49782, _target_50716);

        /** 		flush_temp( Code[$-2] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26442 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26442 = 1;
        }
        _26443 = _26442 - 2;
        _26442 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26444 = (int)*(((s1_ptr)_2)->base + _26443);
        Ref(_26444);
        _41flush_temp(_26444);
        _26444 = NOVALUE;
        goto LC; // [1113] 7412

        /** 	case PROC then -- procedure, function and type calls*/
        case 27:

        /** 		assignable = FALSE -- assume for now*/
        _41assignable_49792 = _13FALSE_435;

        /** 		subsym = op_info1*/
        _subsym_50717 = _41op_info1_49774;

        /** 		n = SymTab[subsym][S_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26445 = (int)*(((s1_ptr)_2)->base + _subsym_50717);
        _2 = (int)SEQ_PTR(_26445);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
            _n_50722 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
        }
        else{
            _n_50722 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
        }
        if (!IS_ATOM_INT(_n_50722)){
            _n_50722 = (long)DBL_PTR(_n_50722)->dbl;
        }
        _26445 = NOVALUE;

        /** 		if subsym = CurrentSub then*/
        if (_subsym_50717 != _35CurrentSub_15976)
        goto L25; // [1155] 1340

        /** 			for i = cgi-n+1 to cgi do*/
        _26448 = _41cgi_49790 - _n_50722;
        if ((long)((unsigned long)_26448 +(unsigned long) HIGH_BITS) >= 0){
            _26448 = NewDouble((double)_26448);
        }
        if (IS_ATOM_INT(_26448)) {
            _26449 = _26448 + 1;
            if (_26449 > MAXINT){
                _26449 = NewDouble((double)_26449);
            }
        }
        else
        _26449 = binary_op(PLUS, 1, _26448);
        DeRef(_26448);
        _26448 = NOVALUE;
        _26450 = _41cgi_49790;
        {
            int _i_50968;
            Ref(_26449);
            _i_50968 = _26449;
L26: 
            if (binary_op_a(GREATER, _i_50968, _26450)){
                goto L27; // [1176] 1339
            }

            /** 				if cg_stack[i] > 0 then -- if it's a forward reference, it's not a private*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26451 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26451 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            if (binary_op_a(LESSEQ, _26451, 0)){
                _26451 = NOVALUE;
                goto L28; // [1191] 1332
            }
            _26451 = NOVALUE;

            /** 					if SymTab[cg_stack[i]][S_SCOPE] = SC_PRIVATE and*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26453 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26453 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!IS_ATOM_INT(_26453)){
                _26454 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26453)->dbl));
            }
            else{
                _26454 = (int)*(((s1_ptr)_2)->base + _26453);
            }
            _2 = (int)SEQ_PTR(_26454);
            _26455 = (int)*(((s1_ptr)_2)->base + 4);
            _26454 = NOVALUE;
            if (IS_ATOM_INT(_26455)) {
                _26456 = (_26455 == 3);
            }
            else {
                _26456 = binary_op(EQUALS, _26455, 3);
            }
            _26455 = NOVALUE;
            if (IS_ATOM_INT(_26456)) {
                if (_26456 == 0) {
                    goto L29; // [1221] 1299
                }
            }
            else {
                if (DBL_PTR(_26456)->dbl == 0.0) {
                    goto L29; // [1221] 1299
                }
            }
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26458 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26458 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!IS_ATOM_INT(_26458)){
                _26459 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26458)->dbl));
            }
            else{
                _26459 = (int)*(((s1_ptr)_2)->base + _26458);
            }
            _2 = (int)SEQ_PTR(_26459);
            _26460 = (int)*(((s1_ptr)_2)->base + 16);
            _26459 = NOVALUE;
            if (IS_ATOM_INT(_26460) && IS_ATOM_INT(_i_50968)) {
                _26461 = (_26460 < _i_50968);
            }
            else {
                _26461 = binary_op(LESS, _26460, _i_50968);
            }
            _26460 = NOVALUE;
            if (_26461 == 0) {
                DeRef(_26461);
                _26461 = NOVALUE;
                goto L29; // [1248] 1299
            }
            else {
                if (!IS_ATOM_INT(_26461) && DBL_PTR(_26461)->dbl == 0.0){
                    DeRef(_26461);
                    _26461 = NOVALUE;
                    goto L29; // [1248] 1299
                }
                DeRef(_26461);
                _26461 = NOVALUE;
            }
            DeRef(_26461);
            _26461 = NOVALUE;

            /** 						emit_opcode(ASSIGN)*/
            _41emit_opcode(18);

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26462 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26462 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            Ref(_26462);
            _41emit_addr(_26462);
            _26462 = NOVALUE;

            /** 						cg_stack[i] = NewTempSym()*/
            _26463 = _53NewTempSym(0);
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _i_50968);
            _1 = *(int *)_2;
            *(int *)_2 = _26463;
            if( _1 != _26463 ){
                DeRef(_1);
            }
            _26463 = NOVALUE;

            /** 						emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26464 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26464 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            Ref(_26464);
            _41emit_addr(_26464);
            _26464 = NOVALUE;

            /** 						check_for_temps()*/
            _41check_for_temps();
            goto L2A; // [1296] 1331
L29: 

            /** 					elsif sym_mode( cg_stack[i] ) = M_TEMP then*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26465 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26465 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            Ref(_26465);
            _26466 = _53sym_mode(_26465);
            _26465 = NOVALUE;
            if (binary_op_a(NOTEQ, _26466, 3)){
                DeRef(_26466);
                _26466 = NOVALUE;
                goto L2B; // [1313] 1330
            }
            DeRef(_26466);
            _26466 = NOVALUE;

            /** 						emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_50968)){
                _26468 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_50968)->dbl));
            }
            else{
                _26468 = (int)*(((s1_ptr)_2)->base + _i_50968);
            }
            Ref(_26468);
            _41emit_temp(_26468, 1);
            _26468 = NOVALUE;
L2B: 
L2A: 
L28: 

            /** 			end for*/
            _0 = _i_50968;
            if (IS_ATOM_INT(_i_50968)) {
                _i_50968 = _i_50968 + 1;
                if ((long)((unsigned long)_i_50968 +(unsigned long) HIGH_BITS) >= 0){
                    _i_50968 = NewDouble((double)_i_50968);
                }
            }
            else {
                _i_50968 = binary_op_a(PLUS, _i_50968, 1);
            }
            DeRef(_0);
            goto L26; // [1334] 1183
L27: 
            ;
            DeRef(_i_50968);
        }
L25: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(subsym)*/
        _41emit_addr(_subsym_50717);

        /** 		for i = cgi-n+1 to cgi do*/
        _26469 = _41cgi_49790 - _n_50722;
        if ((long)((unsigned long)_26469 +(unsigned long) HIGH_BITS) >= 0){
            _26469 = NewDouble((double)_26469);
        }
        if (IS_ATOM_INT(_26469)) {
            _26470 = _26469 + 1;
            if (_26470 > MAXINT){
                _26470 = NewDouble((double)_26470);
            }
        }
        else
        _26470 = binary_op(PLUS, 1, _26469);
        DeRef(_26469);
        _26469 = NOVALUE;
        _26471 = _41cgi_49790;
        {
            int _i_51003;
            Ref(_26470);
            _i_51003 = _26470;
L2C: 
            if (binary_op_a(GREATER, _i_51003, _26471)){
                goto L2D; // [1367] 1404
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_51003)){
                _26472 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51003)->dbl));
            }
            else{
                _26472 = (int)*(((s1_ptr)_2)->base + _i_51003);
            }
            Ref(_26472);
            _41emit_addr(_26472);
            _26472 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_51003)){
                _26473 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51003)->dbl));
            }
            else{
                _26473 = (int)*(((s1_ptr)_2)->base + _i_51003);
            }
            Ref(_26473);
            _41emit_temp(_26473, 1);
            _26473 = NOVALUE;

            /** 		end for*/
            _0 = _i_51003;
            if (IS_ATOM_INT(_i_51003)) {
                _i_51003 = _i_51003 + 1;
                if ((long)((unsigned long)_i_51003 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51003 = NewDouble((double)_i_51003);
                }
            }
            else {
                _i_51003 = binary_op_a(PLUS, _i_51003, 1);
            }
            DeRef(_0);
            goto L2C; // [1399] 1374
L2D: 
            ;
            DeRef(_i_51003);
        }

        /** 		cgi -= n*/
        _41cgi_49790 = _41cgi_49790 - _n_50722;

        /** 		if SymTab[subsym][S_TOKEN] != PROC then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26475 = (int)*(((s1_ptr)_2)->base + _subsym_50717);
        _2 = (int)SEQ_PTR(_26475);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _26476 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _26476 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _26475 = NOVALUE;
        if (binary_op_a(EQUALS, _26476, 27)){
            _26476 = NOVALUE;
            goto LC; // [1428] 7412
        }
        _26476 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);

        /** 			Push(c)*/
        _41Push(_c_50713);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);
        goto LC; // [1464] 7412

        /** 	case PROC_FORWARD, FUNC_FORWARD then*/
        case 195:
        case 196:

        /** 		assignable = FALSE -- assume for now*/
        _41assignable_49792 = _13FALSE_435;

        /** 		integer real_op*/

        /** 		if op = PROC_FORWARD then*/
        if (_op_50709 != 195)
        goto L2E; // [1485] 1501

        /** 			real_op = PROC*/
        _real_op_51024 = 27;
        goto L2F; // [1498] 1511
L2E: 

        /** 			real_op = FUNC*/
        _real_op_51024 = 501;
L2F: 

        /** 		integer ref*/

        /** 		ref = new_forward_reference( real_op, op_info1, real_op )*/
        _ref_51031 = _38new_forward_reference(_real_op_51024, _41op_info1_49774, _real_op_51024);
        if (!IS_ATOM_INT(_ref_51031)) {
            _1 = (long)(DBL_PTR(_ref_51031)->dbl);
            DeRefDS(_ref_51031);
            _ref_51031 = _1;
        }

        /** 		n = Pop() -- number of known args*/
        _n_50722 = _41Pop();
        if (!IS_ATOM_INT(_n_50722)) {
            _1 = (long)(DBL_PTR(_n_50722)->dbl);
            DeRefDS(_n_50722);
            _n_50722 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(ref)*/
        _41emit_addr(_ref_51031);

        /** 		emit_addr( n ) -- this changes to be the "next" instruction*/
        _41emit_addr(_n_50722);

        /** 		for i = cgi-n+1 to cgi do*/
        _26482 = _41cgi_49790 - _n_50722;
        if ((long)((unsigned long)_26482 +(unsigned long) HIGH_BITS) >= 0){
            _26482 = NewDouble((double)_26482);
        }
        if (IS_ATOM_INT(_26482)) {
            _26483 = _26482 + 1;
            if (_26483 > MAXINT){
                _26483 = NewDouble((double)_26483);
            }
        }
        else
        _26483 = binary_op(PLUS, 1, _26482);
        DeRef(_26482);
        _26482 = NOVALUE;
        _26484 = _41cgi_49790;
        {
            int _i_51036;
            Ref(_26483);
            _i_51036 = _26483;
L30: 
            if (binary_op_a(GREATER, _i_51036, _26484)){
                goto L31; // [1566] 1603
            }

            /** 			emit_addr(cg_stack[i])*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_51036)){
                _26485 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51036)->dbl));
            }
            else{
                _26485 = (int)*(((s1_ptr)_2)->base + _i_51036);
            }
            Ref(_26485);
            _41emit_addr(_26485);
            _26485 = NOVALUE;

            /** 			emit_temp( cg_stack[i], NEW_REFERENCE )*/
            _2 = (int)SEQ_PTR(_41cg_stack_49789);
            if (!IS_ATOM_INT(_i_51036)){
                _26486 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_51036)->dbl));
            }
            else{
                _26486 = (int)*(((s1_ptr)_2)->base + _i_51036);
            }
            Ref(_26486);
            _41emit_temp(_26486, 1);
            _26486 = NOVALUE;

            /** 		end for*/
            _0 = _i_51036;
            if (IS_ATOM_INT(_i_51036)) {
                _i_51036 = _i_51036 + 1;
                if ((long)((unsigned long)_i_51036 +(unsigned long) HIGH_BITS) >= 0){
                    _i_51036 = NewDouble((double)_i_51036);
                }
            }
            else {
                _i_51036 = binary_op_a(PLUS, _i_51036, 1);
            }
            DeRef(_0);
            goto L30; // [1598] 1573
L31: 
            ;
            DeRef(_i_51036);
        }

        /** 		cgi -= n*/
        _41cgi_49790 = _41cgi_49790 - _n_50722;

        /** 		if op != PROC_FORWARD then*/
        if (_op_50709 == 195)
        goto L32; // [1615] 1651

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 			c = NewTempSym() -- put final result in temp*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			Push(c)*/
        _41Push(_c_50713);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);
L32: 
        goto LC; // [1653] 7412

        /** 	case WARNING then*/
        case 506:

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 	    a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		Warning(SymTab[a][S_OBJ], custom_warning_flag,"")*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26491 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26491);
        _26492 = (int)*(((s1_ptr)_2)->base + 1);
        _26491 = NOVALUE;
        Ref(_26492);
        RefDS(_21815);
        _44Warning(_26492, 64, _21815);
        _26492 = NOVALUE;
        goto LC; // [1694] 7412

        /** 	case INCLUDE_PATHS then*/
        case 507:

        /** 		sequence paths*/

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 	    a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 	    emit_opcode(RIGHT_BRACE_N)*/
        _41emit_opcode(31);

        /** 	    paths = Include_paths(SymTab[a][S_OBJ])*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26494 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26494);
        _26495 = (int)*(((s1_ptr)_2)->base + 1);
        _26494 = NOVALUE;
        Ref(_26495);
        _0 = _paths_51061;
        _paths_51061 = _42Include_paths(_26495);
        DeRef(_0);
        _26495 = NOVALUE;

        /** 	    emit(length(paths))*/
        if (IS_SEQUENCE(_paths_51061)){
                _26497 = SEQ_PTR(_paths_51061)->length;
        }
        else {
            _26497 = 1;
        }
        _41emit(_26497);
        _26497 = NOVALUE;

        /** 	    for i=length(paths) to 1 by -1 do*/
        if (IS_SEQUENCE(_paths_51061)){
                _26498 = SEQ_PTR(_paths_51061)->length;
        }
        else {
            _26498 = 1;
        }
        {
            int _i_51073;
            _i_51073 = _26498;
L33: 
            if (_i_51073 < 1){
                goto L34; // [1756] 1787
            }

            /** 	        c = NewStringSym(paths[i])*/
            _2 = (int)SEQ_PTR(_paths_51061);
            _26499 = (int)*(((s1_ptr)_2)->base + _i_51073);
            Ref(_26499);
            _c_50713 = _53NewStringSym(_26499);
            _26499 = NOVALUE;
            if (!IS_ATOM_INT(_c_50713)) {
                _1 = (long)(DBL_PTR(_c_50713)->dbl);
                DeRefDS(_c_50713);
                _c_50713 = _1;
            }

            /** 	        emit_addr(c)*/
            _41emit_addr(_c_50713);

            /** 	    end for*/
            _i_51073 = _i_51073 + -1;
            goto L33; // [1782] 1763
L34: 
            ;
        }

        /** 	    b = NewTempSym()*/
        _b_50712 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_temp(b, NEW_REFERENCE)*/
        _41emit_temp(_b_50712, 1);

        /** 	    Push(b)*/
        _41Push(_b_50712);

        /** 	    emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		last_op = RIGHT_BRACE_N*/
        _41last_op_50668 = 31;

        /** 		op = last_op*/
        _op_50709 = 31;
        DeRef(_paths_51061);
        _paths_51061 = NOVALUE;
        goto LC; // [1829] 7412

        /** 	case NOP1, NOP2, NOPWHILE, PRIVATE_INIT_CHECK, GLOBAL_INIT_CHECK,*/
        case 159:
        case 110:
        case 158:
        case 30:
        case 109:
        case 58:
        case 59:
        case 61:
        case 184:
        case 22:
        case 23:
        case 188:
        case 189:
        case 88:
        case 43:
        case 90:
        case 89:
        case 87:
        case 135:
        case 156:
        case 169:
        case 175:
        case 174:
        case 187:
        case 210:
        case 211:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		if op = UPDATE_GLOBALS then*/
        if (_op_50709 != 89)
        goto LC; // [1901] 7412

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [1916] 7412

        /** 	case IF, WHILE then*/
        case 20:
        case 47:

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		if previous_op >= LESS and previous_op <= NOT then*/
        _26504 = (_35previous_op_16066 >= 1);
        if (_26504 == 0) {
            goto L35; // [1948] 2240
        }
        _26506 = (_35previous_op_16066 <= 7);
        if (_26506 == 0)
        {
            DeRef(_26506);
            _26506 = NOVALUE;
            goto L35; // [1961] 2240
        }
        else{
            DeRef(_26506);
            _26506 = NOVALUE;
        }

        /** 			clear_temp( Code[$] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26507 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26507 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26508 = (int)*(((s1_ptr)_2)->base + _26507);
        Ref(_26508);
        _41clear_temp(_26508);
        _26508 = NOVALUE;

        /** 			Code = Code[1..$-1]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26509 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26509 = 1;
        }
        _26510 = _26509 - 1;
        _26509 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16056;
        RHS_Slice(_35Code_16056, 1, _26510);

        /** 			if previous_op = NOT then*/
        if (_35previous_op_16066 != 7)
        goto L36; // [2002] 2082

        /** 				op = NOT_IFW*/
        _op_50709 = 108;

        /** 				backpatch(length(Code) - 1, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26513 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26513 = 1;
        }
        _26514 = _26513 - 1;
        _26513 = NOVALUE;
        _41backpatch(_26514, 108);
        _26514 = NOVALUE;

        /** 				sequence if_code = Code[$-1..$]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26515 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26515 = 1;
        }
        _26516 = _26515 - 1;
        _26515 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16056)){
                _26517 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26517 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51141;
        RHS_Slice(_35Code_16056, _26516, _26517);

        /** 				Code = Code[1..$-2]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26519 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26519 = 1;
        }
        _26520 = _26519 - 2;
        _26519 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16056;
        RHS_Slice(_35Code_16056, 1, _26520);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_35Code_16056, _35Code_16056, _if_code_51141);
        DeRefDS(_if_code_51141);
        _if_code_51141 = NOVALUE;
        goto L37; // [2079] 2227
L36: 

        /** 				if IsInteger(Code[$-1]) and IsInteger(Code[$]) then*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26523 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26523 = 1;
        }
        _26524 = _26523 - 1;
        _26523 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26525 = (int)*(((s1_ptr)_2)->base + _26524);
        Ref(_26525);
        _26526 = _41IsInteger(_26525);
        _26525 = NOVALUE;
        if (IS_ATOM_INT(_26526)) {
            if (_26526 == 0) {
                goto L38; // [2101] 2143
            }
        }
        else {
            if (DBL_PTR(_26526)->dbl == 0.0) {
                goto L38; // [2101] 2143
            }
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _26528 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26528 = 1;
        }
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26529 = (int)*(((s1_ptr)_2)->base + _26528);
        Ref(_26529);
        _26530 = _41IsInteger(_26529);
        _26529 = NOVALUE;
        if (_26530 == 0) {
            DeRef(_26530);
            _26530 = NOVALUE;
            goto L38; // [2119] 2143
        }
        else {
            if (!IS_ATOM_INT(_26530) && DBL_PTR(_26530)->dbl == 0.0){
                DeRef(_26530);
                _26530 = NOVALUE;
                goto L38; // [2119] 2143
            }
            DeRef(_26530);
            _26530 = NOVALUE;
        }
        DeRef(_26530);
        _26530 = NOVALUE;

        /** 					op = previous_op + LESS_IFW_I - LESS*/
        _26531 = _35previous_op_16066 + 119;
        if ((long)((unsigned long)_26531 + (unsigned long)HIGH_BITS) >= 0) 
        _26531 = NewDouble((double)_26531);
        if (IS_ATOM_INT(_26531)) {
            _op_50709 = _26531 - 1;
        }
        else {
            _op_50709 = NewDouble(DBL_PTR(_26531)->dbl - (double)1);
        }
        DeRef(_26531);
        _26531 = NOVALUE;
        if (!IS_ATOM_INT(_op_50709)) {
            _1 = (long)(DBL_PTR(_op_50709)->dbl);
            DeRefDS(_op_50709);
            _op_50709 = _1;
        }
        goto L39; // [2140] 2162
L38: 

        /** 					op = previous_op + LESS_IFW - LESS*/
        _26533 = _35previous_op_16066 + 102;
        if ((long)((unsigned long)_26533 + (unsigned long)HIGH_BITS) >= 0) 
        _26533 = NewDouble((double)_26533);
        if (IS_ATOM_INT(_26533)) {
            _op_50709 = _26533 - 1;
        }
        else {
            _op_50709 = NewDouble(DBL_PTR(_26533)->dbl - (double)1);
        }
        DeRef(_26533);
        _26533 = NOVALUE;
        if (!IS_ATOM_INT(_op_50709)) {
            _1 = (long)(DBL_PTR(_op_50709)->dbl);
            DeRefDS(_op_50709);
            _op_50709 = _1;
        }
L39: 

        /** 				backpatch(length(Code) - 2, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26535 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26535 = 1;
        }
        _26536 = _26535 - 2;
        _26535 = NOVALUE;
        _41backpatch(_26536, _op_50709);
        _26536 = NOVALUE;

        /** 				sequence if_code = Code[$-2..$]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26537 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26537 = 1;
        }
        _26538 = _26537 - 2;
        _26537 = NOVALUE;
        if (IS_SEQUENCE(_35Code_16056)){
                _26539 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26539 = 1;
        }
        rhs_slice_target = (object_ptr)&_if_code_51180;
        RHS_Slice(_35Code_16056, _26538, _26539);

        /** 				Code = Code[1..$-3]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26541 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26541 = 1;
        }
        _26542 = _26541 - 3;
        _26541 = NOVALUE;
        rhs_slice_target = (object_ptr)&_35Code_16056;
        RHS_Slice(_35Code_16056, 1, _26542);

        /** 				Code &= if_code*/
        Concat((object_ptr)&_35Code_16056, _35Code_16056, _if_code_51180);
        DeRefDS(_if_code_51180);
        _if_code_51180 = NOVALUE;
L37: 

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;

        /** 			last_op = op*/
        _41last_op_50668 = _op_50709;
        goto LC; // [2237] 7412
L35: 

        /** 		elsif op = WHILE and*/
        _26545 = (_op_50709 == 47);
        if (_26545 == 0) {
            _26546 = 0;
            goto L3A; // [2248] 2260
        }
        _26547 = (_a_50711 > 0);
        _26546 = (_26547 != 0);
L3A: 
        if (_26546 == 0) {
            _26548 = 0;
            goto L3B; // [2260] 2286
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26549 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26549);
        _26550 = (int)*(((s1_ptr)_2)->base + 3);
        _26549 = NOVALUE;
        if (IS_ATOM_INT(_26550)) {
            _26551 = (_26550 == 2);
        }
        else {
            _26551 = binary_op(EQUALS, _26550, 2);
        }
        _26550 = NOVALUE;
        if (IS_ATOM_INT(_26551))
        _26548 = (_26551 != 0);
        else
        _26548 = DBL_PTR(_26551)->dbl != 0.0;
L3B: 
        if (_26548 == 0) {
            _26552 = 0;
            goto L3C; // [2286] 2309
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26553 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26553);
        _26554 = (int)*(((s1_ptr)_2)->base + 1);
        _26553 = NOVALUE;
        if (IS_ATOM_INT(_26554))
        _26555 = 1;
        else if (IS_ATOM_DBL(_26554))
        _26555 = IS_ATOM_INT(DoubleToInt(_26554));
        else
        _26555 = 0;
        _26554 = NOVALUE;
        _26552 = (_26555 != 0);
L3C: 
        if (_26552 == 0) {
            goto L3D; // [2309] 2358
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26557 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26557);
        _26558 = (int)*(((s1_ptr)_2)->base + 1);
        _26557 = NOVALUE;
        if (_26558 == 0)
        _26559 = 1;
        else if (IS_ATOM_INT(_26558) && IS_ATOM_INT(0))
        _26559 = 0;
        else
        _26559 = (compare(_26558, 0) == 0);
        _26558 = NOVALUE;
        _26560 = (_26559 == 0);
        _26559 = NOVALUE;
        if (_26560 == 0)
        {
            DeRef(_26560);
            _26560 = NOVALUE;
            goto L3D; // [2333] 2358
        }
        else{
            DeRef(_26560);
            _26560 = NOVALUE;
        }

        /** 			optimized_while = TRUE   -- while TRUE ... emit nothing*/
        _41optimized_while_49776 = _13TRUE_437;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;
        goto LC; // [2355] 7412
L3D: 

        /** 			flush_temps( {a} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _a_50711;
        _26561 = MAKE_SEQ(_1);
        _41flush_temps(_26561);
        _26561 = NOVALUE;

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);
        goto LC; // [2378] 7412

        /** 	case INTEGER_CHECK then*/
        case 96:

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16066 != 18)
        goto L3E; // [2397] 2456

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26563 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26563 = 1;
        }
        _26564 = _26563 - 1;
        _26563 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _c_50713 = (int)*(((s1_ptr)_2)->base + _26564);
        if (!IS_ATOM_INT(_c_50713)){
            _c_50713 = (long)DBL_PTR(_c_50713)->dbl;
        }

        /** 			if not IsInteger(c) then*/
        _26566 = _41IsInteger(_c_50713);
        if (IS_ATOM_INT(_26566)) {
            if (_26566 != 0){
                DeRef(_26566);
                _26566 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        else {
            if (DBL_PTR(_26566)->dbl != 0.0){
                DeRef(_26566);
                _26566 = NOVALUE;
                goto L3F; // [2424] 2442
            }
        }
        DeRef(_26566);
        _26566 = NOVALUE;

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);
        goto L40; // [2439] 2513
L3F: 

        /** 				last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto L40; // [2453] 2513
L3E: 

        /** 		elsif previous_op = -1 or*/
        _26568 = (_35previous_op_16066 == -1);
        if (_26568 != 0) {
            goto L41; // [2464] 2487
        }
        _2 = (int)SEQ_PTR(_41op_result_50390);
        _26570 = (int)*(((s1_ptr)_2)->base + _35previous_op_16066);
        _26571 = (_26570 != 1);
        _26570 = NOVALUE;
        if (_26571 == 0)
        {
            DeRef(_26571);
            _26571 = NOVALUE;
            goto L42; // [2483] 2502
        }
        else{
            DeRef(_26571);
            _26571 = NOVALUE;
        }
L41: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);
        goto L40; // [2499] 2513
L42: 

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
L40: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26572 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26572 = 1;
        }
        _26573 = _26572 - 1;
        _26572 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26574 = (int)*(((s1_ptr)_2)->base + _26573);
        Ref(_26574);
        _41clear_temp(_26574);
        _26574 = NOVALUE;
        goto LC; // [2531] 7412

        /** 	case SEQUENCE_CHECK then*/
        case 97:

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16066 != 18)
        goto L43; // [2550] 2677

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26576 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26576 = 1;
        }
        _26577 = _26576 - 1;
        _26576 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _c_50713 = (int)*(((s1_ptr)_2)->base + _26577);
        if (!IS_ATOM_INT(_c_50713)){
            _c_50713 = (long)DBL_PTR(_c_50713)->dbl;
        }

        /** 			if c < 1 or*/
        _26579 = (_c_50713 < 1);
        if (_26579 != 0) {
            _26580 = 1;
            goto L44; // [2577] 2603
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26581 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26581);
        _26582 = (int)*(((s1_ptr)_2)->base + 3);
        _26581 = NOVALUE;
        if (IS_ATOM_INT(_26582)) {
            _26583 = (_26582 != 2);
        }
        else {
            _26583 = binary_op(NOTEQ, _26582, 2);
        }
        _26582 = NOVALUE;
        if (IS_ATOM_INT(_26583))
        _26580 = (_26583 != 0);
        else
        _26580 = DBL_PTR(_26583)->dbl != 0.0;
L44: 
        if (_26580 != 0) {
            goto L45; // [2603] 2630
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26585 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26585);
        _26586 = (int)*(((s1_ptr)_2)->base + 1);
        _26585 = NOVALUE;
        _26587 = IS_SEQUENCE(_26586);
        _26586 = NOVALUE;
        _26588 = (_26587 == 0);
        _26587 = NOVALUE;
        if (_26588 == 0)
        {
            DeRef(_26588);
            _26588 = NOVALUE;
            goto L46; // [2626] 2663
        }
        else{
            DeRef(_26588);
            _26588 = NOVALUE;
        }
L45: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);

        /** 				clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26589 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26589 = 1;
        }
        _26590 = _26589 - 1;
        _26589 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26591 = (int)*(((s1_ptr)_2)->base + _26590);
        Ref(_26591);
        _41clear_temp(_26591);
        _26591 = NOVALUE;
        goto LC; // [2660] 7412
L46: 

        /** 				last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [2674] 7412
L43: 

        /** 		elsif previous_op = -1 or op_result[previous_op] != T_SEQUENCE then*/
        _26592 = (_35previous_op_16066 == -1);
        if (_26592 != 0) {
            goto L47; // [2685] 2708
        }
        _2 = (int)SEQ_PTR(_41op_result_50390);
        _26594 = (int)*(((s1_ptr)_2)->base + _35previous_op_16066);
        _26595 = (_26594 != 2);
        _26594 = NOVALUE;
        if (_26595 == 0)
        {
            DeRef(_26595);
            _26595 = NOVALUE;
            goto L48; // [2704] 2741
        }
        else{
            DeRef(_26595);
            _26595 = NOVALUE;
        }
L47: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);

        /** 			clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26596 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26596 = 1;
        }
        _26597 = _26596 - 1;
        _26596 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26598 = (int)*(((s1_ptr)_2)->base + _26597);
        Ref(_26598);
        _41clear_temp(_26598);
        _26598 = NOVALUE;
        goto LC; // [2738] 7412
L48: 

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [2752] 7412

        /** 	case ATOM_CHECK then*/
        case 101:

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		if previous_op = ASSIGN then*/
        if (_35previous_op_16066 != 18)
        goto L49; // [2771] 2970

        /** 			c = Code[$-1]*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26600 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26600 = 1;
        }
        _26601 = _26600 - 1;
        _26600 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _c_50713 = (int)*(((s1_ptr)_2)->base + _26601);
        if (!IS_ATOM_INT(_c_50713)){
            _c_50713 = (long)DBL_PTR(_c_50713)->dbl;
        }

        /** 			if c > 1*/
        _26603 = (_c_50713 > 1);
        if (_26603 == 0) {
            goto L4A; // [2798] 2919
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26605 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26605);
        _26606 = (int)*(((s1_ptr)_2)->base + 3);
        _26605 = NOVALUE;
        if (IS_ATOM_INT(_26606)) {
            _26607 = (_26606 == 2);
        }
        else {
            _26607 = binary_op(EQUALS, _26606, 2);
        }
        _26606 = NOVALUE;
        if (_26607 == 0) {
            DeRef(_26607);
            _26607 = NOVALUE;
            goto L4A; // [2821] 2919
        }
        else {
            if (!IS_ATOM_INT(_26607) && DBL_PTR(_26607)->dbl == 0.0){
                DeRef(_26607);
                _26607 = NOVALUE;
                goto L4A; // [2821] 2919
            }
            DeRef(_26607);
            _26607 = NOVALUE;
        }
        DeRef(_26607);
        _26607 = NOVALUE;

        /** 				if sequence( SymTab[c][S_OBJ] ) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26608 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26608);
        _26609 = (int)*(((s1_ptr)_2)->base + 1);
        _26608 = NOVALUE;
        _26610 = IS_SEQUENCE(_26609);
        _26609 = NOVALUE;
        if (_26610 == 0)
        {
            _26610 = NOVALUE;
            goto L4B; // [2841] 2870
        }
        else{
            _26610 = NOVALUE;
        }

        /** 					ThisLine = ExprLine*/
        RefDS(_39ExprLine_55721);
        DeRef(_44ThisLine_48142);
        _44ThisLine_48142 = _39ExprLine_55721;

        /** 					bp = expr_bp*/
        _44bp_48146 = _39expr_bp_55722;

        /** 					CompileErr( 346 )*/
        RefDS(_21815);
        _44CompileErr(346, _21815, 0);
        goto L4C; // [2867] 3049
L4B: 

        /** 				elsif SymTab[c][S_OBJ] = NOVALUE then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26611 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26611);
        _26612 = (int)*(((s1_ptr)_2)->base + 1);
        _26611 = NOVALUE;
        if (binary_op_a(NOTEQ, _26612, _35NOVALUE_15823)){
            _26612 = NOVALUE;
            goto L4D; // [2886] 2905
        }
        _26612 = NOVALUE;

        /** 					emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 					emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);
        goto L4C; // [2902] 3049
L4D: 

        /** 					last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 					last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto L4C; // [2916] 3049
L4A: 

        /** 			elsif c < 1 */
        _26614 = (_c_50713 < 1);
        if (_26614 != 0) {
            goto L4E; // [2925] 2941
        }
        _26616 = _41IsInteger(_c_50713);
        if (IS_ATOM_INT(_26616)) {
            _26617 = (_26616 == 0);
        }
        else {
            _26617 = unary_op(NOT, _26616);
        }
        DeRef(_26616);
        _26616 = NOVALUE;
        if (_26617 == 0) {
            DeRef(_26617);
            _26617 = NOVALUE;
            goto L4F; // [2937] 2956
        }
        else {
            if (!IS_ATOM_INT(_26617) && DBL_PTR(_26617)->dbl == 0.0){
                DeRef(_26617);
                _26617 = NOVALUE;
                goto L4F; // [2937] 2956
            }
            DeRef(_26617);
            _26617 = NOVALUE;
        }
        DeRef(_26617);
        _26617 = NOVALUE;
L4E: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 				emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);
        goto L4C; // [2953] 3049
L4F: 

        /** 				last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 				last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto L4C; // [2967] 3049
L49: 

        /** 		elsif previous_op = -1 or*/
        _26618 = (_35previous_op_16066 == -1);
        if (_26618 != 0) {
            goto L50; // [2978] 3023
        }
        _2 = (int)SEQ_PTR(_41op_result_50390);
        _26620 = (int)*(((s1_ptr)_2)->base + _35previous_op_16066);
        _26621 = (_26620 != 1);
        _26620 = NOVALUE;
        if (_26621 == 0) {
            DeRef(_26622);
            _26622 = 0;
            goto L51; // [2996] 3018
        }
        _2 = (int)SEQ_PTR(_41op_result_50390);
        _26623 = (int)*(((s1_ptr)_2)->base + _35previous_op_16066);
        _26624 = (_26623 != 3);
        _26623 = NOVALUE;
        _26622 = (_26624 != 0);
L51: 
        if (_26622 == 0)
        {
            _26622 = NOVALUE;
            goto L52; // [3019] 3038
        }
        else{
            _26622 = NOVALUE;
        }
L50: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(op_info1)*/
        _41emit_addr(_41op_info1_49774);
        goto L4C; // [3035] 3049
L52: 

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
L4C: 

        /** 		clear_temp( Code[$-1] )*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26625 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26625 = 1;
        }
        _26626 = _26625 - 1;
        _26625 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26627 = (int)*(((s1_ptr)_2)->base + _26626);
        Ref(_26627);
        _41clear_temp(_26627);
        _26627 = NOVALUE;
        goto LC; // [3067] 7412

        /** 	case RIGHT_BRACE_N then*/
        case 31:

        /** 		n = op_info1*/
        _n_50722 = _41op_info1_49774;

        /** 		elements = {}*/
        RefDS(_21815);
        DeRef(_elements_50724);
        _elements_50724 = _21815;

        /** 		for i = 1 to n do*/
        _26628 = _n_50722;
        {
            int _i_51360;
            _i_51360 = 1;
L53: 
            if (_i_51360 > _26628){
                goto L54; // [3092] 3115
            }

            /** 			elements = append(elements, Pop())*/
            _26629 = _41Pop();
            Ref(_26629);
            Append(&_elements_50724, _elements_50724, _26629);
            DeRef(_26629);
            _26629 = NOVALUE;

            /** 		end for*/
            _i_51360 = _i_51360 + 1;
            goto L53; // [3110] 3099
L54: 
            ;
        }

        /** 		element_vals = good_string(elements)*/
        RefDS(_elements_50724);
        _0 = _element_vals_50725;
        _element_vals_50725 = _41good_string(_elements_50724);
        DeRef(_0);

        /** 		if sequence(element_vals) then*/
        _26632 = IS_SEQUENCE(_element_vals_50725);
        if (_26632 == 0)
        {
            _26632 = NOVALUE;
            goto L55; // [3126] 3157
        }
        else{
            _26632 = NOVALUE;
        }

        /** 			c = NewStringSym(element_vals)  -- make a string literal*/
        Ref(_element_vals_50725);
        _c_50713 = _53NewStringSym(_element_vals_50725);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 			last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto L56; // [3154] 3248
L55: 

        /** 			if n = 2 then*/
        if (_n_50722 != 2)
        goto L57; // [3159] 3182

        /** 				emit_opcode(RIGHT_BRACE_2) -- faster op for two items*/
        _41emit_opcode(85);

        /** 				last_op = RIGHT_BRACE_2*/
        _41last_op_50668 = 85;
        goto L58; // [3179] 3193
L57: 

        /** 				emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 				emit(n)*/
        _41emit(_n_50722);
L58: 

        /** 			for i = 1 to n do*/
        _26635 = _n_50722;
        {
            int _i_51377;
            _i_51377 = 1;
L59: 
            if (_i_51377 > _26635){
                goto L5A; // [3198] 3221
            }

            /** 				emit_addr(elements[i])*/
            _2 = (int)SEQ_PTR(_elements_50724);
            _26636 = (int)*(((s1_ptr)_2)->base + _i_51377);
            Ref(_26636);
            _41emit_addr(_26636);
            _26636 = NOVALUE;

            /** 			end for*/
            _i_51377 = _i_51377 + 1;
            goto L59; // [3216] 3205
L5A: 
            ;
        }

        /** 			c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;
L56: 

        /** 		Push(c)*/
        _41Push(_c_50713);
        goto LC; // [3253] 7412

        /** 	case ASSIGN_SUBS2,      -- can't change the op*/
        case 148:
        case 16:
        case 162:

        /** 		b = Pop() -- rhs value*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop() -- subscript*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		c = Pop() -- sequence*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		if op = ASSIGN_SUBS then*/
        if (_op_50709 != 16)
        goto L5B; // [3288] 3480

        /** 			if (previous_op != LHS_SUBS) and*/
        _26642 = (_35previous_op_16066 != 95);
        if (_26642 == 0) {
            _26643 = 0;
            goto L5C; // [3302] 3314
        }
        _26644 = (_c_50713 > 0);
        _26643 = (_26644 != 0);
L5C: 
        if (_26643 == 0) {
            goto L5D; // [3314] 3452
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26646 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26646);
        _26647 = (int)*(((s1_ptr)_2)->base + 3);
        _26646 = NOVALUE;
        if (IS_ATOM_INT(_26647)) {
            _26648 = (_26647 != 1);
        }
        else {
            _26648 = binary_op(NOTEQ, _26647, 1);
        }
        _26647 = NOVALUE;
        if (IS_ATOM_INT(_26648)) {
            if (_26648 != 0) {
                DeRef(_26649);
                _26649 = 1;
                goto L5E; // [3336] 3436
            }
        }
        else {
            if (DBL_PTR(_26648)->dbl != 0.0) {
                DeRef(_26649);
                _26649 = 1;
                goto L5E; // [3336] 3436
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26650 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26650);
        _26651 = (int)*(((s1_ptr)_2)->base + 15);
        _26650 = NOVALUE;
        if (IS_ATOM_INT(_26651)) {
            _26652 = (_26651 != _53sequence_type_45719);
        }
        else {
            _26652 = binary_op(NOTEQ, _26651, _53sequence_type_45719);
        }
        _26651 = NOVALUE;
        if (IS_ATOM_INT(_26652)) {
            if (_26652 == 0) {
                DeRef(_26653);
                _26653 = 0;
                goto L5F; // [3358] 3432
            }
        }
        else {
            if (DBL_PTR(_26652)->dbl == 0.0) {
                DeRef(_26653);
                _26653 = 0;
                goto L5F; // [3358] 3432
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26654 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26654);
        _26655 = (int)*(((s1_ptr)_2)->base + 15);
        _26654 = NOVALUE;
        if (IS_ATOM_INT(_26655)) {
            _26656 = (_26655 > 0);
        }
        else {
            _26656 = binary_op(GREATER, _26655, 0);
        }
        _26655 = NOVALUE;
        if (IS_ATOM_INT(_26656)) {
            if (_26656 == 0) {
                DeRef(_26657);
                _26657 = 0;
                goto L60; // [3378] 3428
            }
        }
        else {
            if (DBL_PTR(_26656)->dbl == 0.0) {
                DeRef(_26657);
                _26657 = 0;
                goto L60; // [3378] 3428
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26658 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26658);
        _26659 = (int)*(((s1_ptr)_2)->base + 15);
        _26658 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_26659)){
            _26660 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26659)->dbl));
        }
        else{
            _26660 = (int)*(((s1_ptr)_2)->base + _26659);
        }
        _2 = (int)SEQ_PTR(_26660);
        _26661 = (int)*(((s1_ptr)_2)->base + 2);
        _26660 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_26661)){
            _26662 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26661)->dbl));
        }
        else{
            _26662 = (int)*(((s1_ptr)_2)->base + _26661);
        }
        _2 = (int)SEQ_PTR(_26662);
        _26663 = (int)*(((s1_ptr)_2)->base + 15);
        _26662 = NOVALUE;
        if (IS_ATOM_INT(_26663)) {
            _26664 = (_26663 != _53sequence_type_45719);
        }
        else {
            _26664 = binary_op(NOTEQ, _26663, _53sequence_type_45719);
        }
        _26663 = NOVALUE;
        DeRef(_26657);
        if (IS_ATOM_INT(_26664))
        _26657 = (_26664 != 0);
        else
        _26657 = DBL_PTR(_26664)->dbl != 0.0;
L60: 
        DeRef(_26653);
        _26653 = (_26657 != 0);
L5F: 
        DeRef(_26649);
        _26649 = (_26653 != 0);
L5E: 
        if (_26649 == 0)
        {
            _26649 = NOVALUE;
            goto L5D; // [3437] 3452
        }
        else{
            _26649 = NOVALUE;
        }

        /** 				op = ASSIGN_SUBS_CHECK*/
        _op_50709 = 84;
        goto L61; // [3449] 3472
L5D: 

        /** 				if IsInteger(b) then*/
        _26665 = _41IsInteger(_b_50712);
        if (_26665 == 0) {
            DeRef(_26665);
            _26665 = NOVALUE;
            goto L62; // [3458] 3471
        }
        else {
            if (!IS_ATOM_INT(_26665) && DBL_PTR(_26665)->dbl == 0.0){
                DeRef(_26665);
                _26665 = NOVALUE;
                goto L62; // [3458] 3471
            }
            DeRef(_26665);
            _26665 = NOVALUE;
        }
        DeRef(_26665);
        _26665 = NOVALUE;

        /** 					op = ASSIGN_SUBS_I*/
        _op_50709 = 118;
L62: 
L61: 

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);
        goto L63; // [3477] 3506
L5B: 

        /** 		elsif op = PASSIGN_SUBS then*/
        if (_op_50709 != 162)
        goto L64; // [3484] 3498

        /** 			emit_opcode(PASSIGN_SUBS) -- always*/
        _41emit_opcode(162);
        goto L63; // [3495] 3506
L64: 

        /** 			emit_opcode(ASSIGN_SUBS) -- always*/
        _41emit_opcode(16);
L63: 

        /** 		emit_addr(c) -- sequence*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(a) -- subscript*/
        _41emit_addr(_a_50711);

        /** 		emit_addr(b) -- rhs value*/
        _41emit_addr(_b_50712);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [3528] 7412

        /** 	case LHS_SUBS, LHS_SUBS1, LHS_SUBS1_COPY then*/
        case 95:
        case 161:
        case 166:

        /** 		a = Pop() -- subs*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		lhs_var = Pop() -- sequence*/
        _lhs_var_50719 = _41Pop();
        if (!IS_ATOM_INT(_lhs_var_50719)) {
            _1 = (long)(DBL_PTR(_lhs_var_50719)->dbl);
            DeRefDS(_lhs_var_50719);
            _lhs_var_50719 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(lhs_var)*/
        _41emit_addr(_lhs_var_50719);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		if op = LHS_SUBS then*/
        if (_op_50709 != 95)
        goto L65; // [3571] 3602

        /** 			TempKeep(lhs_var) -- should be lhs_target_temp*/
        _41TempKeep(_lhs_var_50719);

        /** 			emit_addr(lhs_target_temp)*/
        _41emit_addr(_41lhs_target_temp_49788);

        /** 			Push(lhs_target_temp)*/
        _41Push(_41lhs_target_temp_49788);

        /** 			emit_addr(0) -- place holder*/
        _41emit_addr(0);
        goto L66; // [3599] 3656
L65: 

        /** 			lhs_target_temp = NewTempSym() -- use same temp for all subscripts*/
        _0 = _53NewTempSym(0);
        _41lhs_target_temp_49788 = _0;
        if (!IS_ATOM_INT(_41lhs_target_temp_49788)) {
            _1 = (long)(DBL_PTR(_41lhs_target_temp_49788)->dbl);
            DeRefDS(_41lhs_target_temp_49788);
            _41lhs_target_temp_49788 = _1;
        }

        /** 			emit_addr(lhs_target_temp) -- target temp holds pointer to sequence*/
        _41emit_addr(_41lhs_target_temp_49788);

        /** 			emit_temp(lhs_target_temp, NEW_REFERENCE )*/
        _41emit_temp(_41lhs_target_temp_49788, 1);

        /** 			Push(lhs_target_temp)*/
        _41Push(_41lhs_target_temp_49788);

        /** 			lhs_subs1_copy_temp = NewTempSym() -- place to copy (may be ignored)*/
        _0 = _53NewTempSym(0);
        _41lhs_subs1_copy_temp_49787 = _0;
        if (!IS_ATOM_INT(_41lhs_subs1_copy_temp_49787)) {
            _1 = (long)(DBL_PTR(_41lhs_subs1_copy_temp_49787)->dbl);
            DeRefDS(_41lhs_subs1_copy_temp_49787);
            _41lhs_subs1_copy_temp_49787 = _1;
        }

        /** 			emit_addr(lhs_subs1_copy_temp)*/
        _41emit_addr(_41lhs_subs1_copy_temp_49787);

        /** 			emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
        _41emit_temp(_41lhs_subs1_copy_temp_49787, 1);
L66: 

        /** 		current_sequence = append(current_sequence, lhs_target_temp)*/
        Append(&_41current_sequence_49782, _41current_sequence_49782, _41lhs_target_temp_49788);

        /** 		assignable = FALSE  -- need to update current_sequence like in RHS_SUBS*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [3673] 7412

        /** 	case RAND, PEEK, PEEK4S, PEEK4U, NOT_BITS, NOT,*/
        case 62:
        case 127:
        case 139:
        case 140:
        case 51:
        case 7:
        case 173:
        case 180:
        case 179:
        case 181:
        case 182:

        /** 		cont11ii(op, TRUE)*/
        _41cont11ii(_op_50709, _13TRUE_437);
        goto LC; // [3707] 7412

        /** 	case UMINUS then*/
        case 12:

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if a > 0 then*/
        if (_a_50711 <= 0)
        goto L67; // [3722] 3968

        /** 			obj = SymTab[a][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26675 = (int)*(((s1_ptr)_2)->base + _a_50711);
        DeRef(_obj_50723);
        _2 = (int)SEQ_PTR(_26675);
        _obj_50723 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_obj_50723);
        _26675 = NOVALUE;

        /** 			if SymTab[a][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26677 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26677);
        _26678 = (int)*(((s1_ptr)_2)->base + 3);
        _26677 = NOVALUE;
        if (binary_op_a(NOTEQ, _26678, 2)){
            _26678 = NOVALUE;
            goto L68; // [3756] 3880
        }
        _26678 = NOVALUE;

        /** 				if integer(obj) then*/
        if (IS_ATOM_INT(_obj_50723))
        _26680 = 1;
        else if (IS_ATOM_DBL(_obj_50723))
        _26680 = IS_ATOM_INT(DoubleToInt(_obj_50723));
        else
        _26680 = 0;
        if (_26680 == 0)
        {
            _26680 = NOVALUE;
            goto L69; // [3765] 3819
        }
        else{
            _26680 = NOVALUE;
        }

        /** 					if obj = MININT then*/
        if (binary_op_a(NOTEQ, _obj_50723, -1073741824)){
            goto L6A; // [3772] 3793
        }

        /** 						Push(NewDoubleSym(-MININT))*/
        if ((unsigned long)-1073741824 == 0xC0000000)
        _26682 = (int)NewDouble((double)-0xC0000000);
        else
        _26682 = - -1073741824;
        _26683 = _53NewDoubleSym(_26682);
        _26682 = NOVALUE;
        _41Push(_26683);
        _26683 = NOVALUE;
        goto L6B; // [3790] 3806
L6A: 

        /** 						Push(NewIntSym(-obj))*/
        if (IS_ATOM_INT(_obj_50723)) {
            if ((unsigned long)_obj_50723 == 0xC0000000)
            _26684 = (int)NewDouble((double)-0xC0000000);
            else
            _26684 = - _obj_50723;
        }
        else {
            _26684 = unary_op(UMINUS, _obj_50723);
        }
        _26685 = _53NewIntSym(_26684);
        _26684 = NOVALUE;
        _41Push(_26685);
        _26685 = NOVALUE;
L6B: 

        /** 					last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;

        /** 					last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;
        goto LC; // [3816] 7412
L69: 

        /** 				elsif atom(obj) and obj != NOVALUE then*/
        _26686 = IS_ATOM(_obj_50723);
        if (_26686 == 0) {
            goto L6C; // [3824] 3863
        }
        if (IS_ATOM_INT(_obj_50723) && IS_ATOM_INT(_35NOVALUE_15823)) {
            _26688 = (_obj_50723 != _35NOVALUE_15823);
        }
        else {
            _26688 = binary_op(NOTEQ, _obj_50723, _35NOVALUE_15823);
        }
        if (_26688 == 0) {
            DeRef(_26688);
            _26688 = NOVALUE;
            goto L6C; // [3835] 3863
        }
        else {
            if (!IS_ATOM_INT(_26688) && DBL_PTR(_26688)->dbl == 0.0){
                DeRef(_26688);
                _26688 = NOVALUE;
                goto L6C; // [3835] 3863
            }
            DeRef(_26688);
            _26688 = NOVALUE;
        }
        DeRef(_26688);
        _26688 = NOVALUE;

        /** 					Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_50723)) {
            if ((unsigned long)_obj_50723 == 0xC0000000)
            _26689 = (int)NewDouble((double)-0xC0000000);
            else
            _26689 = - _obj_50723;
        }
        else {
            _26689 = unary_op(UMINUS, _obj_50723);
        }
        _26690 = _53NewDoubleSym(_26689);
        _26689 = NOVALUE;
        _41Push(_26690);
        _26690 = NOVALUE;

        /** 					last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;

        /** 					last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;
        goto LC; // [3860] 7412
L6C: 

        /** 					Push(a)*/
        _41Push(_a_50711);

        /** 					cont11ii(op, FALSE)*/
        _41cont11ii(_op_50709, _13FALSE_435);
        goto LC; // [3877] 7412
L68: 

        /** 			elsif TRANSLATE and SymTab[a][S_MODE] = M_TEMP and*/
        if (_35TRANSLATE_15611 == 0) {
            _26691 = 0;
            goto L6D; // [3884] 3910
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26692 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26692);
        _26693 = (int)*(((s1_ptr)_2)->base + 3);
        _26692 = NOVALUE;
        if (IS_ATOM_INT(_26693)) {
            _26694 = (_26693 == 3);
        }
        else {
            _26694 = binary_op(EQUALS, _26693, 3);
        }
        _26693 = NOVALUE;
        if (IS_ATOM_INT(_26694))
        _26691 = (_26694 != 0);
        else
        _26691 = DBL_PTR(_26694)->dbl != 0.0;
L6D: 
        if (_26691 == 0) {
            goto L6E; // [3910] 3951
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26696 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26696);
        _26697 = (int)*(((s1_ptr)_2)->base + 36);
        _26696 = NOVALUE;
        if (IS_ATOM_INT(_26697)) {
            _26698 = (_26697 == 2);
        }
        else {
            _26698 = binary_op(EQUALS, _26697, 2);
        }
        _26697 = NOVALUE;
        if (_26698 == 0) {
            DeRef(_26698);
            _26698 = NOVALUE;
            goto L6E; // [3933] 3951
        }
        else {
            if (!IS_ATOM_INT(_26698) && DBL_PTR(_26698)->dbl == 0.0){
                DeRef(_26698);
                _26698 = NOVALUE;
                goto L6E; // [3933] 3951
            }
            DeRef(_26698);
            _26698 = NOVALUE;
        }
        DeRef(_26698);
        _26698 = NOVALUE;

        /** 				Push(NewDoubleSym(-obj))*/
        if (IS_ATOM_INT(_obj_50723)) {
            if ((unsigned long)_obj_50723 == 0xC0000000)
            _26699 = (int)NewDouble((double)-0xC0000000);
            else
            _26699 = - _obj_50723;
        }
        else {
            _26699 = unary_op(UMINUS, _obj_50723);
        }
        _26700 = _53NewDoubleSym(_26699);
        _26699 = NOVALUE;
        _41Push(_26700);
        _26700 = NOVALUE;
        goto LC; // [3948] 7412
L6E: 

        /** 				Push(a)*/
        _41Push(_a_50711);

        /** 				cont11ii(op, FALSE)*/
        _41cont11ii(_op_50709, _13FALSE_435);
        goto LC; // [3965] 7412
L67: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			cont11ii(op, FALSE)*/
        _41cont11ii(_op_50709, _13FALSE_435);
        goto LC; // [3982] 7412

        /** 	case LENGTH, GETC, SQRT, SIN, COS, TAN, ARCTAN, LOG, GETS, GETENV then*/
        case 42:
        case 33:
        case 41:
        case 80:
        case 81:
        case 82:
        case 73:
        case 74:
        case 17:
        case 91:

        /** 		cont11ii(op, FALSE)*/
        _41cont11ii(_op_50709, _13FALSE_435);
        goto LC; // [4014] 7412

        /** 	case IS_AN_INTEGER, IS_AN_ATOM, IS_A_SEQUENCE, IS_AN_OBJECT then*/
        case 94:
        case 67:
        case 68:
        case 40:

        /** 		cont11ii(op, FALSE)*/
        _41cont11ii(_op_50709, _13FALSE_435);
        goto LC; // [4034] 7412

        /** 	case ROUTINE_ID then*/
        case 134:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		source = Pop()*/
        _source_50715 = _41Pop();
        if (!IS_ATOM_INT(_source_50715)) {
            _1 = (long)(DBL_PTR(_source_50715)->dbl);
            DeRefDS(_source_50715);
            _source_50715 = _1;
        }

        /** 		if TRANSLATE then*/
        if (_35TRANSLATE_15611 == 0)
        {
            goto L6F; // [4056] 4100
        }
        else{
        }

        /** 			emit_addr(num_routines-1)*/
        _26702 = _35num_routines_15977 - 1;
        if ((long)((unsigned long)_26702 +(unsigned long) HIGH_BITS) >= 0){
            _26702 = NewDouble((double)_26702);
        }
        _41emit_addr(_26702);
        _26702 = NOVALUE;

        /** 			last_routine_id = num_routines*/
        _41last_routine_id_49779 = _35num_routines_15977;

        /** 			last_max_params = max_params*/
        _41last_max_params_49781 = _41max_params_49780;

        /** 			MarkTargets(source, S_RI_TARGET)*/
        _31376 = _53MarkTargets(_source_50715, 53);
        DeRef(_31376);
        _31376 = NOVALUE;
        goto L70; // [4097] 4137
L6F: 

        /** 			emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_15976);

        /** 			emit_addr(length(SymTab))*/
        if (IS_SEQUENCE(_36SymTab_14981)){
                _26703 = SEQ_PTR(_36SymTab_14981)->length;
        }
        else {
            _26703 = 1;
        }
        _41emit_addr(_26703);
        _26703 = NOVALUE;

        /** 			if BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto L71; // [4121] 4136
        }
        else{
        }

        /** 				MarkTargets(source, S_NREFS)*/
        _31375 = _53MarkTargets(_source_50715, 12);
        DeRef(_31375);
        _31375 = NOVALUE;
L71: 
L70: 

        /** 		emit_addr(source)*/
        _41emit_addr(_source_50715);

        /** 		emit_addr(current_file_no)  -- necessary at top level*/
        _41emit_addr(_35current_file_no_15968);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempInteger(c) -- result will always be an integer*/
        _41TempInteger(_c_50713);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);
        goto LC; // [4179] 7412

        /** 	case SC1_OR, SC1_AND then*/
        case 143:
        case 141:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(Pop())*/
        _26705 = _41Pop();
        _41emit_addr(_26705);
        _26705 = NOVALUE;

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [4225] 7412

        /** 	case SYSTEM, PUTS, PRINT, QPRINT, POSITION, MACHINE_PROC,*/
        case 99:
        case 44:
        case 19:
        case 36:
        case 60:
        case 112:
        case 132:
        case 128:
        case 138:
        case 168:
        case 178:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26708 = _41Pop();
        _41emit_addr(_26708);
        _26708 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		if op = C_PROC then*/
        if (_op_50709 != 132)
        goto L72; // [4280] 4292

        /** 			emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_15976);
L72: 

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [4299] 7412

        /** 	case EQUALS, LESS, GREATER, NOTEQ, LESSEQ, GREATEREQ,*/
        case 3:
        case 1:
        case 6:
        case 4:
        case 5:
        case 2:
        case 8:
        case 9:
        case 152:
        case 71:
        case 56:
        case 24:
        case 26:

        /** 		cont21ii(op, TRUE)  -- both integer args => integer result*/
        _41cont21ii(_op_50709, _13TRUE_437);
        goto LC; // [4337] 7412

        /** 	case PLUS then -- elsif op = PLUS then*/
        case 11:

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if b < 1 or a < 1 then*/
        _26712 = (_b_50712 < 1);
        if (_26712 != 0) {
            goto L73; // [4363] 4376
        }
        _26714 = (_a_50711 < 1);
        if (_26714 == 0)
        {
            DeRef(_26714);
            _26714 = NOVALUE;
            goto L74; // [4372] 4397
        }
        else{
            DeRef(_26714);
            _26714 = NOVALUE;
        }
L73: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [4394] 7412
L74: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26715 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26715);
        _26716 = (int)*(((s1_ptr)_2)->base + 3);
        _26715 = NOVALUE;
        if (IS_ATOM_INT(_26716)) {
            _26717 = (_26716 == 2);
        }
        else {
            _26717 = binary_op(EQUALS, _26716, 2);
        }
        _26716 = NOVALUE;
        if (IS_ATOM_INT(_26717)) {
            if (_26717 == 0) {
                goto L75; // [4417] 4478
            }
        }
        else {
            if (DBL_PTR(_26717)->dbl == 0.0) {
                goto L75; // [4417] 4478
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26719 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26719);
        _26720 = (int)*(((s1_ptr)_2)->base + 1);
        _26719 = NOVALUE;
        if (_26720 == 1)
        _26721 = 1;
        else if (IS_ATOM_INT(_26720) && IS_ATOM_INT(1))
        _26721 = 0;
        else
        _26721 = (compare(_26720, 1) == 0);
        _26720 = NOVALUE;
        if (_26721 == 0)
        {
            _26721 = NOVALUE;
            goto L75; // [4438] 4478
        }
        else{
            _26721 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_50709 = 93;

        /** 			emit_opcode(op)*/
        _41emit_opcode(93);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(93, _a_50711, _b_50712, _13FALSE_435);
        goto LC; // [4475] 7412
L75: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 1) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26722 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26722);
        _26723 = (int)*(((s1_ptr)_2)->base + 3);
        _26722 = NOVALUE;
        if (IS_ATOM_INT(_26723)) {
            _26724 = (_26723 == 2);
        }
        else {
            _26724 = binary_op(EQUALS, _26723, 2);
        }
        _26723 = NOVALUE;
        if (IS_ATOM_INT(_26724)) {
            if (_26724 == 0) {
                goto L76; // [4498] 4559
            }
        }
        else {
            if (DBL_PTR(_26724)->dbl == 0.0) {
                goto L76; // [4498] 4559
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26726 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26726);
        _26727 = (int)*(((s1_ptr)_2)->base + 1);
        _26726 = NOVALUE;
        if (_26727 == 1)
        _26728 = 1;
        else if (IS_ATOM_INT(_26727) && IS_ATOM_INT(1))
        _26728 = 0;
        else
        _26728 = (compare(_26727, 1) == 0);
        _26727 = NOVALUE;
        if (_26728 == 0)
        {
            _26728 = NOVALUE;
            goto L76; // [4519] 4559
        }
        else{
            _26728 = NOVALUE;
        }

        /** 			op = PLUS1*/
        _op_50709 = 93;

        /** 			emit_opcode(op)*/
        _41emit_opcode(93);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(93, _a_50711, _b_50712, _13FALSE_435);
        goto LC; // [4556] 7412
L76: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [4578] 7412

        /** 	case rw:MULTIPLY then*/
        case 13:

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if a < 1 or b < 1 then*/
        _26731 = (_a_50711 < 1);
        if (_26731 != 0) {
            goto L77; // [4604] 4617
        }
        _26733 = (_b_50712 < 1);
        if (_26733 == 0)
        {
            DeRef(_26733);
            _26733 = NOVALUE;
            goto L78; // [4613] 4638
        }
        else{
            DeRef(_26733);
            _26733 = NOVALUE;
        }
L77: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [4635] 7412
L78: 

        /** 		elsif SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26734 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26734);
        _26735 = (int)*(((s1_ptr)_2)->base + 3);
        _26734 = NOVALUE;
        if (IS_ATOM_INT(_26735)) {
            _26736 = (_26735 == 2);
        }
        else {
            _26736 = binary_op(EQUALS, _26735, 2);
        }
        _26735 = NOVALUE;
        if (IS_ATOM_INT(_26736)) {
            if (_26736 == 0) {
                goto L79; // [4658] 4719
            }
        }
        else {
            if (DBL_PTR(_26736)->dbl == 0.0) {
                goto L79; // [4658] 4719
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26738 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26738);
        _26739 = (int)*(((s1_ptr)_2)->base + 1);
        _26738 = NOVALUE;
        if (_26739 == 2)
        _26740 = 1;
        else if (IS_ATOM_INT(_26739) && IS_ATOM_INT(2))
        _26740 = 0;
        else
        _26740 = (compare(_26739, 2) == 0);
        _26739 = NOVALUE;
        if (_26740 == 0)
        {
            _26740 = NOVALUE;
            goto L79; // [4679] 4719
        }
        else{
            _26740 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_50709 = 11;

        /** 			emit_opcode(op)*/
        _41emit_opcode(11);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(11, _a_50711, _b_50712, _13FALSE_435);
        goto LC; // [4716] 7412
L79: 

        /** 		elsif SymTab[a][S_MODE] = M_CONSTANT and equal(SymTab[a][S_OBJ], 2) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26741 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26741);
        _26742 = (int)*(((s1_ptr)_2)->base + 3);
        _26741 = NOVALUE;
        if (IS_ATOM_INT(_26742)) {
            _26743 = (_26742 == 2);
        }
        else {
            _26743 = binary_op(EQUALS, _26742, 2);
        }
        _26742 = NOVALUE;
        if (IS_ATOM_INT(_26743)) {
            if (_26743 == 0) {
                goto L7A; // [4739] 4800
            }
        }
        else {
            if (DBL_PTR(_26743)->dbl == 0.0) {
                goto L7A; // [4739] 4800
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26745 = (int)*(((s1_ptr)_2)->base + _a_50711);
        _2 = (int)SEQ_PTR(_26745);
        _26746 = (int)*(((s1_ptr)_2)->base + 1);
        _26745 = NOVALUE;
        if (_26746 == 2)
        _26747 = 1;
        else if (IS_ATOM_INT(_26746) && IS_ATOM_INT(2))
        _26747 = 0;
        else
        _26747 = (compare(_26746, 2) == 0);
        _26746 = NOVALUE;
        if (_26747 == 0)
        {
            _26747 = NOVALUE;
            goto L7A; // [4760] 4800
        }
        else{
            _26747 = NOVALUE;
        }

        /** 			op = PLUS*/
        _op_50709 = 11;

        /** 			emit_opcode(op)*/
        _41emit_opcode(11);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(11, _a_50711, _b_50712, _13FALSE_435);
        goto LC; // [4797] 7412
L7A: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [4819] 7412

        /** 	case rw:DIVIDE then*/
        case 14:

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26749 = (_b_50712 > 0);
        if (_26749 == 0) {
            _26750 = 0;
            goto L7B; // [4838] 4864
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26751 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26751);
        _26752 = (int)*(((s1_ptr)_2)->base + 3);
        _26751 = NOVALUE;
        if (IS_ATOM_INT(_26752)) {
            _26753 = (_26752 == 2);
        }
        else {
            _26753 = binary_op(EQUALS, _26752, 2);
        }
        _26752 = NOVALUE;
        if (IS_ATOM_INT(_26753))
        _26750 = (_26753 != 0);
        else
        _26750 = DBL_PTR(_26753)->dbl != 0.0;
L7B: 
        if (_26750 == 0) {
            goto L7C; // [4864] 4935
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26755 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26755);
        _26756 = (int)*(((s1_ptr)_2)->base + 1);
        _26755 = NOVALUE;
        if (_26756 == 2)
        _26757 = 1;
        else if (IS_ATOM_INT(_26756) && IS_ATOM_INT(2))
        _26757 = 0;
        else
        _26757 = (compare(_26756, 2) == 0);
        _26756 = NOVALUE;
        if (_26757 == 0)
        {
            _26757 = NOVALUE;
            goto L7C; // [4885] 4935
        }
        else{
            _26757 = NOVALUE;
        }

        /** 			op = DIV2*/
        _op_50709 = 98;

        /** 			emit_opcode(op)*/
        _41emit_opcode(98);

        /** 			emit_addr(Pop()) -- n.b. "a" hasn't been set*/
        _26758 = _41Pop();
        _41emit_addr(_26758);
        _26758 = NOVALUE;

        /** 			a = 0*/
        _a_50711 = 0;

        /** 			emit_addr(0)*/
        _41emit_addr(0);

        /** 			cont21d(op, a, b, FALSE)  -- could have fractional result*/
        _41cont21d(98, 0, _b_50712, _13FALSE_435);
        goto LC; // [4932] 7412
L7C: 

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [4949] 7412

        /** 	case FLOOR then*/
        case 83:

        /** 		if previous_op = rw:DIVIDE then*/
        if (_35previous_op_16066 != 14)
        goto L7D; // [4959] 5007

        /** 			op = FLOOR_DIV*/
        _op_50709 = 63;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26760 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26760 = 1;
        }
        _26761 = _26760 - 3;
        _26760 = NOVALUE;
        _41backpatch(_26761, 63);
        _26761 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 			last_op = op*/
        _41last_op_50668 = 63;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [5004] 7412
L7D: 

        /** 		elsif previous_op = DIV2 then*/
        if (_35previous_op_16066 != 98)
        goto L7E; // [5013] 5100

        /** 			op = FLOOR_DIV2*/
        _op_50709 = 66;

        /** 			backpatch(length(Code) - 3, op)*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26763 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26763 = 1;
        }
        _26764 = _26763 - 3;
        _26763 = NOVALUE;
        _41backpatch(_26764, 66);
        _26764 = NOVALUE;

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 			if IsInteger(Code[$-2]) then*/
        if (IS_SEQUENCE(_35Code_16056)){
                _26765 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _26765 = 1;
        }
        _26766 = _26765 - 2;
        _26765 = NOVALUE;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _26767 = (int)*(((s1_ptr)_2)->base + _26766);
        Ref(_26767);
        _26768 = _41IsInteger(_26767);
        _26767 = NOVALUE;
        if (_26768 == 0) {
            DeRef(_26768);
            _26768 = NOVALUE;
            goto L7F; // [5067] 5087
        }
        else {
            if (!IS_ATOM_INT(_26768) && DBL_PTR(_26768)->dbl == 0.0){
                DeRef(_26768);
                _26768 = NOVALUE;
                goto L7F; // [5067] 5087
            }
            DeRef(_26768);
            _26768 = NOVALUE;
        }
        DeRef(_26768);
        _26768 = NOVALUE;

        /** 				TempInteger(Top()) --mark temp as integer type*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_5195_51747);
        _2 = (int)SEQ_PTR(_41cg_stack_49789);
        _Top_inlined_Top_at_5195_51747 = (int)*(((s1_ptr)_2)->base + _41cgi_49790);
        Ref(_Top_inlined_Top_at_5195_51747);
        Ref(_Top_inlined_Top_at_5195_51747);
        _41TempInteger(_Top_inlined_Top_at_5195_51747);
L7F: 

        /** 			last_op = op*/
        _41last_op_50668 = _op_50709;

        /** 			last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [5097] 7412
L7E: 

        /** 			cont11ii(op, TRUE)*/
        _41cont11ii(_op_50709, _13TRUE_437);
        goto LC; // [5109] 7412

        /** 	case MINUS, rw:APPEND, PREPEND, COMPARE, EQUAL,*/
        case 10:
        case 35:
        case 57:
        case 76:
        case 153:
        case 154:
        case 15:
        case 32:
        case 111:
        case 133:
        case 53:
        case 167:
        case 194:
        case 198:
        case 199:
        case 204:

        /** 		cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [5153] 7412

        /** 	case SC2_NULL then  -- correct the stack - we aren't emitting anything*/
        case 145:

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_50713);

        /** 		b = Pop()  -- remove SC1's temp*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;

        /** 		last_op = last_op_backup*/
        _41last_op_50668 = _last_op_backup_50727;

        /** 		last_pc = last_pc_backup*/
        _41last_pc_50669 = _last_pc_backup_50726;
        goto LC; // [5200] 7412

        /** 	case SC2_AND, SC2_OR then*/
        case 142:
        case 144:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(Pop())*/
        _26771 = _41Pop();
        _41emit_addr(_26771);
        _26771 = NOVALUE;

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_50713);

        /** 		emit_addr(c) -- target*/
        _41emit_addr(_c_50713);

        /** 		TempInteger(c)*/
        _41TempInteger(_c_50713);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [5255] 7412

        /** 	case MEM_COPY, MEM_SET, PRINTF then*/
        case 130:
        case 131:
        case 38:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26775 = _41Pop();
        _41emit_addr(_26775);
        _26775 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [5309] 7412

        /** 	case RHS_SLICE, FIND, MATCH, FIND_FROM, MATCH_FROM, SPLICE, INSERT, REMOVE, OPEN then*/
        case 46:
        case 77:
        case 78:
        case 176:
        case 177:
        case 190:
        case 191:
        case 200:
        case 37:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26778 = _41Pop();
        _41emit_addr(_26778);
        _26778 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		if op = FIND or op = FIND_FROM or op = OPEN then*/
        _26780 = (_op_50709 == 77);
        if (_26780 != 0) {
            _26781 = 1;
            goto L80; // [5384] 5398
        }
        _26782 = (_op_50709 == 176);
        _26781 = (_26782 != 0);
L80: 
        if (_26781 != 0) {
            goto L81; // [5398] 5413
        }
        _26784 = (_op_50709 == 37);
        if (_26784 == 0)
        {
            DeRef(_26784);
            _26784 = NOVALUE;
            goto L82; // [5409] 5421
        }
        else{
            DeRef(_26784);
            _26784 = NOVALUE;
        }
L81: 

        /** 			TempInteger( c )*/
        _41TempInteger(_c_50713);
        goto L83; // [5418] 5428
L82: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);
L83: 

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);
        goto LC; // [5445] 7412

        /** 	case CONCAT_N then     -- concatenate 3 or more items*/
        case 157:

        /** 		n = op_info1  -- number of items to concatenate*/
        _n_50722 = _41op_info1_49774;

        /** 		emit_opcode(CONCAT_N)*/
        _41emit_opcode(157);

        /** 		emit(n)*/
        _41emit(_n_50722);

        /** 		for i = 1 to n do*/
        _26785 = _n_50722;
        {
            int _i_51815;
            _i_51815 = 1;
L84: 
            if (_i_51815 > _26785){
                goto L85; // [5475] 5503
            }

            /** 			symtab_index element = Pop()*/
            _element_51818 = _41Pop();
            if (!IS_ATOM_INT(_element_51818)) {
                _1 = (long)(DBL_PTR(_element_51818)->dbl);
                DeRefDS(_element_51818);
                _element_51818 = _1;
            }

            /** 			emit_addr( element )  -- reverse order*/
            _41emit_addr(_element_51818);

            /** 		end for*/
            _i_51815 = _i_51815 + 1;
            goto L84; // [5498] 5482
L85: 
            ;
        }

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		Push(c)*/
        _41Push(_c_50713);
        goto LC; // [5534] 7412

        /** 	case FOR then*/
        case 21:

        /** 		c = Pop() -- increment*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_50713);

        /** 		ic = IsInteger(c)*/
        _ic_50721 = _41IsInteger(_c_50713);
        if (!IS_ATOM_INT(_ic_50721)) {
            _1 = (long)(DBL_PTR(_ic_50721)->dbl);
            DeRefDS(_ic_50721);
            _ic_50721 = _1;
        }

        /** 		if c < 1 or*/
        _26790 = (_c_50713 < 1);
        if (_26790 != 0) {
            goto L86; // [5566] 5645
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26792 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26792);
        _26793 = (int)*(((s1_ptr)_2)->base + 3);
        _26792 = NOVALUE;
        if (IS_ATOM_INT(_26793)) {
            _26794 = (_26793 == 1);
        }
        else {
            _26794 = binary_op(EQUALS, _26793, 1);
        }
        _26793 = NOVALUE;
        if (IS_ATOM_INT(_26794)) {
            if (_26794 == 0) {
                DeRef(_26795);
                _26795 = 0;
                goto L87; // [5588] 5614
            }
        }
        else {
            if (DBL_PTR(_26794)->dbl == 0.0) {
                DeRef(_26795);
                _26795 = 0;
                goto L87; // [5588] 5614
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26796 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26796);
        _26797 = (int)*(((s1_ptr)_2)->base + 4);
        _26796 = NOVALUE;
        if (IS_ATOM_INT(_26797)) {
            _26798 = (_26797 != 2);
        }
        else {
            _26798 = binary_op(NOTEQ, _26797, 2);
        }
        _26797 = NOVALUE;
        DeRef(_26795);
        if (IS_ATOM_INT(_26798))
        _26795 = (_26798 != 0);
        else
        _26795 = DBL_PTR(_26798)->dbl != 0.0;
L87: 
        if (_26795 == 0) {
            DeRef(_26799);
            _26799 = 0;
            goto L88; // [5614] 5640
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26800 = (int)*(((s1_ptr)_2)->base + _c_50713);
        _2 = (int)SEQ_PTR(_26800);
        _26801 = (int)*(((s1_ptr)_2)->base + 4);
        _26800 = NOVALUE;
        if (IS_ATOM_INT(_26801)) {
            _26802 = (_26801 != 4);
        }
        else {
            _26802 = binary_op(NOTEQ, _26801, 4);
        }
        _26801 = NOVALUE;
        if (IS_ATOM_INT(_26802))
        _26799 = (_26802 != 0);
        else
        _26799 = DBL_PTR(_26802)->dbl != 0.0;
L88: 
        if (_26799 == 0)
        {
            _26799 = NOVALUE;
            goto L89; // [5641] 5682
        }
        else{
            _26799 = NOVALUE;
        }
L86: 

        /** 			emit_opcode(ASSIGN)*/
        _41emit_opcode(18);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 			c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			if ic then*/
        if (_ic_50721 == 0)
        {
            goto L8A; // [5667] 5676
        }
        else{
        }

        /** 				TempInteger( c )*/
        _41TempInteger(_c_50713);
L8A: 

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);
L89: 

        /** 		b = Pop() -- limit*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_50712);

        /** 		ib = IsInteger(b)*/
        _ib_50720 = _41IsInteger(_b_50712);
        if (!IS_ATOM_INT(_ib_50720)) {
            _1 = (long)(DBL_PTR(_ib_50720)->dbl);
            DeRefDS(_ib_50720);
            _ib_50720 = _1;
        }

        /** 		if b < 1 or*/
        _26806 = (_b_50712 < 1);
        if (_26806 != 0) {
            goto L8B; // [5708] 5787
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26808 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26808);
        _26809 = (int)*(((s1_ptr)_2)->base + 3);
        _26808 = NOVALUE;
        if (IS_ATOM_INT(_26809)) {
            _26810 = (_26809 == 1);
        }
        else {
            _26810 = binary_op(EQUALS, _26809, 1);
        }
        _26809 = NOVALUE;
        if (IS_ATOM_INT(_26810)) {
            if (_26810 == 0) {
                DeRef(_26811);
                _26811 = 0;
                goto L8C; // [5730] 5756
            }
        }
        else {
            if (DBL_PTR(_26810)->dbl == 0.0) {
                DeRef(_26811);
                _26811 = 0;
                goto L8C; // [5730] 5756
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26812 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26812);
        _26813 = (int)*(((s1_ptr)_2)->base + 4);
        _26812 = NOVALUE;
        if (IS_ATOM_INT(_26813)) {
            _26814 = (_26813 != 2);
        }
        else {
            _26814 = binary_op(NOTEQ, _26813, 2);
        }
        _26813 = NOVALUE;
        DeRef(_26811);
        if (IS_ATOM_INT(_26814))
        _26811 = (_26814 != 0);
        else
        _26811 = DBL_PTR(_26814)->dbl != 0.0;
L8C: 
        if (_26811 == 0) {
            DeRef(_26815);
            _26815 = 0;
            goto L8D; // [5756] 5782
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26816 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26816);
        _26817 = (int)*(((s1_ptr)_2)->base + 4);
        _26816 = NOVALUE;
        if (IS_ATOM_INT(_26817)) {
            _26818 = (_26817 != 4);
        }
        else {
            _26818 = binary_op(NOTEQ, _26817, 4);
        }
        _26817 = NOVALUE;
        if (IS_ATOM_INT(_26818))
        _26815 = (_26818 != 0);
        else
        _26815 = DBL_PTR(_26818)->dbl != 0.0;
L8D: 
        if (_26815 == 0)
        {
            _26815 = NOVALUE;
            goto L8E; // [5783] 5824
        }
        else{
            _26815 = NOVALUE;
        }
L8B: 

        /** 			emit_opcode(ASSIGN)*/
        _41emit_opcode(18);

        /** 			emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 			b = NewTempSym()*/
        _b_50712 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 			if ib then*/
        if (_ib_50720 == 0)
        {
            goto L8F; // [5809] 5818
        }
        else{
        }

        /** 				TempInteger( b )*/
        _41TempInteger(_b_50712);
L8F: 

        /** 			emit_addr(b)*/
        _41emit_addr(_b_50712);
L8E: 

        /** 		a = Pop() -- initial value*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if IsInteger(a) and ib and ic then*/
        _26821 = _41IsInteger(_a_50711);
        if (IS_ATOM_INT(_26821)) {
            if (_26821 == 0) {
                DeRef(_26822);
                _26822 = 0;
                goto L90; // [5837] 5845
            }
        }
        else {
            if (DBL_PTR(_26821)->dbl == 0.0) {
                DeRef(_26822);
                _26822 = 0;
                goto L90; // [5837] 5845
            }
        }
        DeRef(_26822);
        _26822 = (_ib_50720 != 0);
L90: 
        if (_26822 == 0) {
            goto L91; // [5845] 5884
        }
        if (_ic_50721 == 0)
        {
            goto L91; // [5850] 5884
        }
        else{
        }

        /** 			SymTab[op_info1][S_VTYPE] = integer_type*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_41op_info1_49774 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _53integer_type_45721;
        DeRef(_1);
        _26824 = NOVALUE;

        /** 			op = FOR_I*/
        _op_50709 = 125;
        goto L92; // [5881] 5894
L91: 

        /** 			op = FOR*/
        _op_50709 = 21;
L92: 

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		emit_addr(CurrentSub) -- in case recursion check is needed*/
        _41emit_addr(_35CurrentSub_15976);

        /** 		Push(b)*/
        _41Push(_b_50712);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [5938] 7412

        /** 	case ENDFOR_GENERAL, ENDFOR_INT_UP1 then  -- all ENDFORs*/
        case 39:
        case 54:

        /** 		emit_opcode(op) -- will be patched at runtime*/
        _41emit_opcode(_op_50709);

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		emit_addr(op_info2) -- address of top of loop*/
        _41emit_addr(_41op_info2_49775);

        /** 		emit_addr(Pop())    -- limit*/
        _26827 = _41Pop();
        _41emit_addr(_26827);
        _26827 = NOVALUE;

        /** 		emit_addr(op_info1) -- loop var*/
        _41emit_addr(_41op_info1_49774);

        /** 		emit_addr(a)        -- increment - not always used -*/
        _41emit_addr(_a_50711);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [5992] 7412

        /** 	case ASSIGN_OP_SUBS, PASSIGN_OP_SUBS then*/
        case 149:
        case 164:

        /** 		b = Pop()      -- rhs value, keep on stack*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_50712);

        /** 		a = Pop()      -- subscript, keep on stack*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		TempKeep(a)*/
        _41TempKeep(_a_50711);

        /** 		c = Pop()      -- lhs sequence, keep on stack*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_50713);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		d = NewTempSym()*/
        _d_50714 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_d_50714)) {
            _1 = (long)(DBL_PTR(_d_50714)->dbl);
            DeRefDS(_d_50714);
            _d_50714 = _1;
        }

        /** 		emit_addr(d)   -- place to store result*/
        _41emit_addr(_d_50714);

        /** 		emit_temp( d, NEW_REFERENCE )*/
        _41emit_temp(_d_50714, 1);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		Push(a)*/
        _41Push(_a_50711);

        /** 		Push(d)*/
        _41Push(_d_50714);

        /** 		Push(b)*/
        _41Push(_b_50712);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6097] 7412

        /** 	case ASSIGN_SLICE, PASSIGN_SLICE then*/
        case 45:
        case 163:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop() -- rhs value*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop() -- 2nd subs*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		c = Pop() -- 1st subs*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		emit_addr(Pop()) -- sequence*/
        _26835 = _41Pop();
        _41emit_addr(_26835);
        _26835 = NOVALUE;

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6161] 7412

        /** 	case REPLACE then*/
        case 201:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop()  -- source*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop()  -- replacement*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		c = Pop()  -- start of replaced slice*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		d = Pop()  -- end of replaced slice*/
        _d_50714 = _41Pop();
        if (!IS_ATOM_INT(_d_50714)) {
            _1 = (long)(DBL_PTR(_d_50714)->dbl);
            DeRefDS(_d_50714);
            _d_50714 = _1;
        }

        /** 		emit_addr(d)*/
        _41emit_addr(_d_50714);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)     -- place to store result*/
        _41emit_addr(_c_50713);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;
        goto LC; // [6251] 7412

        /** 	case ASSIGN_OP_SLICE, PASSIGN_OP_SLICE then*/
        case 150:
        case 165:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop()        -- rhs value not used*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		TempKeep(b)*/
        _41TempKeep(_b_50712);

        /** 		a = Pop()        -- 2nd subs*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		TempKeep(a)*/
        _41TempKeep(_a_50711);

        /** 		c = Pop()        -- 1st subs*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempKeep(c)*/
        _41TempKeep(_c_50713);

        /** 		d = Pop()*/
        _d_50714 = _41Pop();
        if (!IS_ATOM_INT(_d_50714)) {
            _1 = (long)(DBL_PTR(_d_50714)->dbl);
            DeRefDS(_d_50714);
            _d_50714 = _1;
        }

        /** 		TempKeep(d)      -- sequence*/
        _41TempKeep(_d_50714);

        /** 		emit_addr(d)*/
        _41emit_addr(_d_50714);

        /** 		Push(d)*/
        _41Push(_d_50714);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		Push(a)*/
        _41Push(_a_50711);

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)     -- place to store result*/
        _41emit_addr(_c_50713);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);

        /** 		Push(b)*/
        _41Push(_b_50712);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6378] 7412

        /** 	case CALL_PROC then*/
        case 136:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26847 = _41Pop();
        _41emit_addr(_26847);
        _26847 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6416] 7412

        /** 	case CALL_FUNC then*/
        case 137:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		emit_addr(Pop())*/
        _26849 = _41Pop();
        _41emit_addr(_26849);
        _26849 = NOVALUE;

        /** 		emit_addr(b)*/
        _41emit_addr(_b_50712);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);
        goto LC; // [6478] 7412

        /** 	case EXIT_BLOCK then*/
        case 206:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr( Pop() )*/
        _26851 = _41Pop();
        _41emit_addr(_26851);
        _26851 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6504] 7412

        /** 	case RETURNP then*/
        case 29:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_15976);

        /** 		emit_addr(top_block())*/
        _26852 = _66top_block(0);
        _41emit_addr(_26852);
        _26852 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6538] 7412

        /** 	case RETURNF then*/
        case 28:

        /** 		clear_temp( Top() )*/

        /** 	return cg_stack[cgi]*/
        DeRef(_Top_inlined_Top_at_6750_51965);
        _2 = (int)SEQ_PTR(_41cg_stack_49789);
        _Top_inlined_Top_at_6750_51965 = (int)*(((s1_ptr)_2)->base + _41cgi_49790);
        Ref(_Top_inlined_Top_at_6750_51965);
        Ref(_Top_inlined_Top_at_6750_51965);
        _41clear_temp(_Top_inlined_Top_at_6750_51965);

        /** 		flush_temps()*/
        RefDS(_21815);
        _41flush_temps(_21815);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(CurrentSub)*/
        _41emit_addr(_35CurrentSub_15976);

        /** 		emit_addr(Least_block())*/
        _26853 = _66Least_block();
        _41emit_addr(_26853);
        _26853 = NOVALUE;

        /** 		emit_addr(Pop())*/
        _26854 = _41Pop();
        _41emit_addr(_26854);
        _26854 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6600] 7412

        /** 	case RETURNT then*/
        case 34:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6618] 7412

        /** 	case DATE, TIME, SPACE_USED, GET_KEY, TASK_LIST,*/
        case 69:
        case 70:
        case 75:
        case 79:
        case 172:
        case 100:
        case 183:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;

        /** 		if op = GET_KEY then  -- it's in op_result as integer*/
        if (_op_50709 != 79)
        goto L93; // [6660] 6672

        /** 			TempInteger(c)*/
        _41TempInteger(_c_50713);
        goto L94; // [6669] 6679
L93: 

        /** 			emit_temp( c, NEW_REFERENCE )*/
        _41emit_temp(_c_50713, 1);
L94: 

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);
        goto LC; // [6689] 7412

        /** 	case CLOSE, ABORT, CALL, DELETE_OBJECT then*/
        case 86:
        case 126:
        case 129:
        case 205:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(Pop())*/
        _26857 = _41Pop();
        _41emit_addr(_26857);
        _26857 = NOVALUE;

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6721] 7412

        /** 	case POWER then*/
        case 72:

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if b > 0 and SymTab[b][S_MODE] = M_CONSTANT and equal(SymTab[b][S_OBJ], 2) then*/
        _26860 = (_b_50712 > 0);
        if (_26860 == 0) {
            _26861 = 0;
            goto L95; // [6747] 6773
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26862 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26862);
        _26863 = (int)*(((s1_ptr)_2)->base + 3);
        _26862 = NOVALUE;
        if (IS_ATOM_INT(_26863)) {
            _26864 = (_26863 == 2);
        }
        else {
            _26864 = binary_op(EQUALS, _26863, 2);
        }
        _26863 = NOVALUE;
        if (IS_ATOM_INT(_26864))
        _26861 = (_26864 != 0);
        else
        _26861 = DBL_PTR(_26864)->dbl != 0.0;
L95: 
        if (_26861 == 0) {
            goto L96; // [6773] 6830
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _26866 = (int)*(((s1_ptr)_2)->base + _b_50712);
        _2 = (int)SEQ_PTR(_26866);
        _26867 = (int)*(((s1_ptr)_2)->base + 1);
        _26866 = NOVALUE;
        if (_26867 == 2)
        _26868 = 1;
        else if (IS_ATOM_INT(_26867) && IS_ATOM_INT(2))
        _26868 = 0;
        else
        _26868 = (compare(_26867, 2) == 0);
        _26867 = NOVALUE;
        if (_26868 == 0)
        {
            _26868 = NOVALUE;
            goto L96; // [6794] 6830
        }
        else{
            _26868 = NOVALUE;
        }

        /** 			op = rw:MULTIPLY*/
        _op_50709 = 13;

        /** 			emit_opcode(op)*/
        _41emit_opcode(13);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			cont21d(op, a, b, FALSE)*/
        _41cont21d(13, _a_50711, _b_50712, _13FALSE_435);
        goto LC; // [6827] 7412
L96: 

        /** 			Push(a)*/
        _41Push(_a_50711);

        /** 			Push(b)*/
        _41Push(_b_50712);

        /** 			cont21ii(op, FALSE)*/
        _41cont21ii(_op_50709, _13FALSE_435);
        goto LC; // [6849] 7412

        /** 	case TYPE_CHECK then*/
        case 65:

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [6874] 7412

        /** 	case DOLLAR then*/
        case -22:

        /** 		if current_sequence[$] < 0 or SymTab[current_sequence[$]][S_SCOPE] = SC_UNDEFINED then*/
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26870 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26870 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_49782);
        _26871 = (int)*(((s1_ptr)_2)->base + _26870);
        if (IS_ATOM_INT(_26871)) {
            _26872 = (_26871 < 0);
        }
        else {
            _26872 = binary_op(LESS, _26871, 0);
        }
        _26871 = NOVALUE;
        if (IS_ATOM_INT(_26872)) {
            if (_26872 != 0) {
                goto L97; // [6895] 6931
            }
        }
        else {
            if (DBL_PTR(_26872)->dbl != 0.0) {
                goto L97; // [6895] 6931
            }
        }
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26874 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26874 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_49782);
        _26875 = (int)*(((s1_ptr)_2)->base + _26874);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_26875)){
            _26876 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_26875)->dbl));
        }
        else{
            _26876 = (int)*(((s1_ptr)_2)->base + _26875);
        }
        _2 = (int)SEQ_PTR(_26876);
        _26877 = (int)*(((s1_ptr)_2)->base + 4);
        _26876 = NOVALUE;
        if (IS_ATOM_INT(_26877)) {
            _26878 = (_26877 == 9);
        }
        else {
            _26878 = binary_op(EQUALS, _26877, 9);
        }
        _26877 = NOVALUE;
        if (_26878 == 0) {
            DeRef(_26878);
            _26878 = NOVALUE;
            goto L98; // [6927] 7001
        }
        else {
            if (!IS_ATOM_INT(_26878) && DBL_PTR(_26878)->dbl == 0.0){
                DeRef(_26878);
                _26878 = NOVALUE;
                goto L98; // [6927] 7001
            }
            DeRef(_26878);
            _26878 = NOVALUE;
        }
        DeRef(_26878);
        _26878 = NOVALUE;
L97: 

        /** 			if lhs_ptr and length(current_sequence) = 1 then*/
        if (_41lhs_ptr_49784 == 0) {
            goto L99; // [6935] 6964
        }
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26880 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26880 = 1;
        }
        _26881 = (_26880 == 1);
        _26880 = NOVALUE;
        if (_26881 == 0)
        {
            DeRef(_26881);
            _26881 = NOVALUE;
            goto L99; // [6949] 6964
        }
        else{
            DeRef(_26881);
            _26881 = NOVALUE;
        }

        /** 				c = PLENGTH*/
        _c_50713 = 160;
        goto L9A; // [6961] 6974
L99: 

        /** 				c = LENGTH*/
        _c_50713 = 42;
L9A: 

        /** 			c = - new_forward_reference( VARIABLE, current_sequence[$], c )*/
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26882 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26882 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_49782);
        _26883 = (int)*(((s1_ptr)_2)->base + _26882);
        Ref(_26883);
        _26884 = _38new_forward_reference(-100, _26883, _c_50713);
        _26883 = NOVALUE;
        if (IS_ATOM_INT(_26884)) {
            if ((unsigned long)_26884 == 0xC0000000)
            _c_50713 = (int)NewDouble((double)-0xC0000000);
            else
            _c_50713 = - _26884;
        }
        else {
            _c_50713 = unary_op(UMINUS, _26884);
        }
        DeRef(_26884);
        _26884 = NOVALUE;
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }
        goto L9B; // [6998] 7015
L98: 

        /** 			c = current_sequence[$]*/
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26886 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26886 = 1;
        }
        _2 = (int)SEQ_PTR(_41current_sequence_49782);
        _c_50713 = (int)*(((s1_ptr)_2)->base + _26886);
        if (!IS_ATOM_INT(_c_50713)){
            _c_50713 = (long)DBL_PTR(_c_50713)->dbl;
        }
L9B: 

        /** 		if lhs_ptr and length(current_sequence) = 1 then*/
        if (_41lhs_ptr_49784 == 0) {
            goto L9C; // [7019] 7046
        }
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _26889 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _26889 = 1;
        }
        _26890 = (_26889 == 1);
        _26889 = NOVALUE;
        if (_26890 == 0)
        {
            DeRef(_26890);
            _26890 = NOVALUE;
            goto L9C; // [7033] 7046
        }
        else{
            DeRef(_26890);
            _26890 = NOVALUE;
        }

        /** 			emit_opcode(PLENGTH)*/
        _41emit_opcode(160);
        goto L9D; // [7043] 7054
L9C: 

        /** 			emit_opcode(LENGTH)*/
        _41emit_opcode(42);
L9D: 

        /** 		emit_addr( c )*/
        _41emit_addr(_c_50713);

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		TempInteger(c)*/
        _41TempInteger(_c_50713);

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		assignable = FALSE -- it wouldn't be assigned anyway*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [7089] 7412

        /** 	case TASK_SELF then*/
        case 170:

        /** 		c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		Push(c)*/
        _41Push(_c_50713);

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 		assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;
        goto LC; // [7125] 7412

        /** 	case SWITCH then*/
        case 185:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_50709);

        /** 		c = Pop()*/
        _c_50713 = _41Pop();
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 		b = Pop()*/
        _b_50712 = _41Pop();
        if (!IS_ATOM_INT(_b_50712)) {
            _1 = (long)(DBL_PTR(_b_50712)->dbl);
            DeRefDS(_b_50712);
            _b_50712 = _1;
        }

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		emit_addr( a ) -- Switch Expr*/
        _41emit_addr(_a_50711);

        /** 		emit_addr( b ) -- Case values*/
        _41emit_addr(_b_50712);

        /** 		emit_addr( c ) -- Jump table*/
        _41emit_addr(_c_50713);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [7179] 7412

        /** 	case CASE then*/
        case 186:

        /** 		emit_opcode( op )*/
        _41emit_opcode(_op_50709);

        /** 		emit( cg_stack[cgi] )  -- the case index*/
        _2 = (int)SEQ_PTR(_41cg_stack_49789);
        _26896 = (int)*(((s1_ptr)_2)->base + _41cgi_49790);
        Ref(_26896);
        _41emit(_26896);
        _26896 = NOVALUE;

        /** 		cgi -= 1*/
        _41cgi_49790 = _41cgi_49790 - 1;
        goto LC; // [7211] 7412

        /** 	case PLATFORM then*/
        case 155:

        /** 		if BIND and shroud_only then*/
        if (_35BIND_15614 == 0) {
            goto L9E; // [7221] 7269
        }
        if (_35shroud_only_15966 == 0)
        {
            goto L9E; // [7228] 7269
        }
        else{
        }

        /** 			c = NewTempSym()*/
        _c_50713 = _53NewTempSym(0);
        if (!IS_ATOM_INT(_c_50713)) {
            _1 = (long)(DBL_PTR(_c_50713)->dbl);
            DeRefDS(_c_50713);
            _c_50713 = _1;
        }

        /** 			TempInteger(c)*/
        _41TempInteger(_c_50713);

        /** 			Push(c)*/
        _41Push(_c_50713);

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(c)*/
        _41emit_addr(_c_50713);

        /** 			assignable = TRUE*/
        _41assignable_49792 = _13TRUE_437;
        goto LC; // [7266] 7412
L9E: 

        /** 			n = host_platform()*/
        _n_50722 = _40host_platform();
        if (!IS_ATOM_INT(_n_50722)) {
            _1 = (long)(DBL_PTR(_n_50722)->dbl);
            DeRefDS(_n_50722);
            _n_50722 = _1;
        }

        /** 			Push(NewIntSym(n))*/
        _26901 = _53NewIntSym(_n_50722);
        _41Push(_26901);
        _26901 = NOVALUE;

        /** 			assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [7293] 7412

        /** 	case PROFILE, TASK_SUSPEND then*/
        case 151:
        case 171:

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 		emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [7325] 7412

        /** 	case TRACE then*/
        case 64:

        /** 		a = Pop()*/
        _a_50711 = _41Pop();
        if (!IS_ATOM_INT(_a_50711)) {
            _1 = (long)(DBL_PTR(_a_50711)->dbl);
            DeRefDS(_a_50711);
            _a_50711 = _1;
        }

        /** 		if OpTrace then*/
        if (_35OpTrace_16037 == 0)
        {
            goto L9F; // [7342] 7388
        }
        else{
        }

        /** 			emit_opcode(op)*/
        _41emit_opcode(_op_50709);

        /** 			emit_addr(a)*/
        _41emit_addr(_a_50711);

        /** 			if TRANSLATE then*/
        if (_35TRANSLATE_15611 == 0)
        {
            goto LA0; // [7359] 7387
        }
        else{
        }

        /** 				if not trace_called then*/
        if (_41trace_called_49777 != 0)
        goto LA1; // [7366] 7377

        /** 					Warning(217,0)*/
        RefDS(_21815);
        _44Warning(217, 0, _21815);
LA1: 

        /** 				trace_called = TRUE*/
        _41trace_called_49777 = _13TRUE_437;
LA0: 
L9F: 

        /** 		assignable = FALSE*/
        _41assignable_49792 = _13FALSE_435;
        goto LC; // [7395] 7412

        /** 	case else*/
        default:

        /** 		InternalErr(259, {op})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_50709;
        _26905 = MAKE_SEQ(_1);
        _44InternalErr(259, _26905);
        _26905 = NOVALUE;
    ;}LC: 

    /** 	previous_op = op*/
    _35previous_op_16066 = _op_50709;

    /** 	inlined = 0*/
    _41inlined_50687 = 0;

    /** end procedure*/
    DeRef(_obj_50723);
    DeRef(_elements_50724);
    DeRef(_element_vals_50725);
    DeRef(_26391);
    _26391 = NOVALUE;
    DeRef(_26743);
    _26743 = NOVALUE;
    DeRef(_26766);
    _26766 = NOVALUE;
    DeRef(_26551);
    _26551 = NOVALUE;
    DeRef(_26724);
    _26724 = NOVALUE;
    DeRef(_26780);
    _26780 = NOVALUE;
    DeRef(_26449);
    _26449 = NOVALUE;
    DeRef(_26542);
    _26542 = NOVALUE;
    DeRef(_26545);
    _26545 = NOVALUE;
    DeRef(_26806);
    _26806 = NOVALUE;
    DeRef(_26814);
    _26814 = NOVALUE;
    _26875 = NOVALUE;
    DeRef(_26644);
    _26644 = NOVALUE;
    DeRef(_26782);
    _26782 = NOVALUE;
    DeRef(_26524);
    _26524 = NOVALUE;
    DeRef(_26652);
    _26652 = NOVALUE;
    _26661 = NOVALUE;
    DeRef(_26642);
    _26642 = NOVALUE;
    DeRef(_26386);
    _26386 = NOVALUE;
    DeRef(_26597);
    _26597 = NOVALUE;
    DeRef(_26389);
    _26389 = NOVALUE;
    DeRef(_26516);
    _26516 = NOVALUE;
    DeRef(_26376);
    _26376 = NOVALUE;
    DeRef(_26435);
    _26435 = NOVALUE;
    _26659 = NOVALUE;
    DeRef(_26790);
    _26790 = NOVALUE;
    DeRef(_26798);
    _26798 = NOVALUE;
    DeRef(_26583);
    _26583 = NOVALUE;
    DeRef(_26395);
    _26395 = NOVALUE;
    DeRef(_26749);
    _26749 = NOVALUE;
    _26412 = NOVALUE;
    DeRef(_26414);
    _26414 = NOVALUE;
    _26453 = NOVALUE;
    DeRef(_26510);
    _26510 = NOVALUE;
    DeRef(_26753);
    _26753 = NOVALUE;
    DeRef(_26810);
    _26810 = NOVALUE;
    DeRef(_26337);
    _26337 = NOVALUE;
    DeRef(_26343);
    _26343 = NOVALUE;
    DeRef(_26379);
    _26379 = NOVALUE;
    DeRef(_26456);
    _26456 = NOVALUE;
    DeRef(_26538);
    _26538 = NOVALUE;
    DeRef(_26736);
    _26736 = NOVALUE;
    DeRef(_26504);
    _26504 = NOVALUE;
    DeRef(_26712);
    _26712 = NOVALUE;
    DeRef(_26626);
    _26626 = NOVALUE;
    DeRef(_26335);
    _26335 = NOVALUE;
    DeRef(_26526);
    _26526 = NOVALUE;
    DeRef(_26547);
    _26547 = NOVALUE;
    DeRef(_26520);
    _26520 = NOVALUE;
    DeRef(_26794);
    _26794 = NOVALUE;
    DeRef(_26818);
    _26818 = NOVALUE;
    DeRef(_26717);
    _26717 = NOVALUE;
    _26359 = NOVALUE;
    DeRef(_26470);
    _26470 = NOVALUE;
    DeRef(_26648);
    _26648 = NOVALUE;
    DeRef(_26821);
    _26821 = NOVALUE;
    DeRef(_26577);
    _26577 = NOVALUE;
    DeRef(_26443);
    _26443 = NOVALUE;
    DeRef(_26568);
    _26568 = NOVALUE;
    DeRef(_26573);
    _26573 = NOVALUE;
    DeRef(_26590);
    _26590 = NOVALUE;
    DeRef(_26592);
    _26592 = NOVALUE;
    DeRef(_26601);
    _26601 = NOVALUE;
    DeRef(_26621);
    _26621 = NOVALUE;
    DeRef(_26564);
    _26564 = NOVALUE;
    DeRef(_26624);
    _26624 = NOVALUE;
    _26429 = NOVALUE;
    DeRef(_26664);
    _26664 = NOVALUE;
    DeRef(_26339);
    _26339 = NOVALUE;
    DeRef(_26410);
    _26410 = NOVALUE;
    DeRef(_26371);
    _26371 = NOVALUE;
    DeRef(_26424);
    _26424 = NOVALUE;
    DeRef(_26603);
    _26603 = NOVALUE;
    DeRef(_26341);
    _26341 = NOVALUE;
    DeRef(_26614);
    _26614 = NOVALUE;
    DeRef(_26731);
    _26731 = NOVALUE;
    _26458 = NOVALUE;
    DeRef(_26483);
    _26483 = NOVALUE;
    DeRef(_26656);
    _26656 = NOVALUE;
    _26427 = NOVALUE;
    DeRef(_26579);
    _26579 = NOVALUE;
    DeRef(_26864);
    _26864 = NOVALUE;
    DeRef(_26618);
    _26618 = NOVALUE;
    DeRef(_26694);
    _26694 = NOVALUE;
    DeRef(_26802);
    _26802 = NOVALUE;
    DeRef(_26860);
    _26860 = NOVALUE;
    DeRef(_26872);
    _26872 = NOVALUE;
    return;
    ;
}


void _41emit_assign_op(int _op_52116)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_52116)) {
        _1 = (long)(DBL_PTR(_op_52116)->dbl);
        DeRefDS(_op_52116);
        _op_52116 = _1;
    }

    /** 	if op = PLUS_EQUALS then*/
    if (_op_52116 != 515)
    goto L1; // [7] 21

    /** 		emit_op(PLUS)*/
    _41emit_op(11);
    goto L2; // [18] 86
L1: 

    /** 	elsif op = MINUS_EQUALS then*/
    if (_op_52116 != 516)
    goto L3; // [25] 39

    /** 		emit_op(MINUS)*/
    _41emit_op(10);
    goto L2; // [36] 86
L3: 

    /** 	elsif op = MULTIPLY_EQUALS then*/
    if (_op_52116 != 517)
    goto L4; // [43] 55

    /** 		emit_op(rw:MULTIPLY)*/
    _41emit_op(13);
    goto L2; // [52] 86
L4: 

    /** 	elsif op = DIVIDE_EQUALS then*/
    if (_op_52116 != 518)
    goto L5; // [59] 71

    /** 		emit_op(rw:DIVIDE)*/
    _41emit_op(14);
    goto L2; // [68] 86
L5: 

    /** 	elsif op = CONCAT_EQUALS then*/
    if (_op_52116 != 519)
    goto L6; // [75] 85

    /** 		emit_op(rw:CONCAT)*/
    _41emit_op(15);
L6: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _41StartSourceLine(int _sl_52136, int _dup_ok_52137, int _emit_coverage_52138)
{
    int _line_span_52141 = NOVALUE;
    int _26927 = NOVALUE;
    int _26925 = NOVALUE;
    int _26924 = NOVALUE;
    int _26923 = NOVALUE;
    int _26922 = NOVALUE;
    int _26921 = NOVALUE;
    int _26919 = NOVALUE;
    int _26916 = NOVALUE;
    int _26914 = NOVALUE;
    int _26913 = NOVALUE;
    int _26912 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sl_52136)) {
        _1 = (long)(DBL_PTR(_sl_52136)->dbl);
        DeRefDS(_sl_52136);
        _sl_52136 = _1;
    }
    if (!IS_ATOM_INT(_dup_ok_52137)) {
        _1 = (long)(DBL_PTR(_dup_ok_52137)->dbl);
        DeRefDS(_dup_ok_52137);
        _dup_ok_52137 = _1;
    }
    if (!IS_ATOM_INT(_emit_coverage_52138)) {
        _1 = (long)(DBL_PTR(_emit_coverage_52138)->dbl);
        DeRefDS(_emit_coverage_52138);
        _emit_coverage_52138 = _1;
    }

    /** 	if gline_number = LastLineNumber then*/
    if (_35gline_number_15973 != _61LastLineNumber_23550)
    goto L1; // [13] 66

    /** 		if length(LineTable) then*/
    if (IS_SEQUENCE(_35LineTable_16057)){
            _26912 = SEQ_PTR(_35LineTable_16057)->length;
    }
    else {
        _26912 = 1;
    }
    if (_26912 == 0)
    {
        _26912 = NOVALUE;
        goto L2; // [24] 55
    }
    else{
        _26912 = NOVALUE;
    }

    /** 			if dup_ok then*/
    if (_dup_ok_52137 == 0)
    {
        goto L3; // [29] 47
    }
    else{
    }

    /** 				emit_op( STARTLINE )*/
    _41emit_op(58);

    /** 				emit_addr( gline_number )*/
    _41emit_addr(_35gline_number_15973);
L3: 

    /** 			return -- ignore duplicates*/
    return;
    goto L4; // [52] 65
L2: 

    /** 			sl = FALSE -- top-level new statement to execute on same line*/
    _sl_52136 = _13FALSE_435;
L4: 
L1: 

    /** 	LastLineNumber = gline_number*/
    _61LastLineNumber_23550 = _35gline_number_15973;

    /** 	line_span = gline_number - SymTab[CurrentSub][S_FIRSTLINE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26913 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_26913);
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15681)){
        _26914 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15681)->dbl));
    }
    else{
        _26914 = (int)*(((s1_ptr)_2)->base + _35S_FIRSTLINE_15681);
    }
    _26913 = NOVALUE;
    if (IS_ATOM_INT(_26914)) {
        _line_span_52141 = _35gline_number_15973 - _26914;
    }
    else {
        _line_span_52141 = binary_op(MINUS, _35gline_number_15973, _26914);
    }
    _26914 = NOVALUE;
    if (!IS_ATOM_INT(_line_span_52141)) {
        _1 = (long)(DBL_PTR(_line_span_52141)->dbl);
        DeRefDS(_line_span_52141);
        _line_span_52141 = _1;
    }

    /** 	while length(LineTable) < line_span do*/
L5: 
    if (IS_SEQUENCE(_35LineTable_16057)){
            _26916 = SEQ_PTR(_35LineTable_16057)->length;
    }
    else {
        _26916 = 1;
    }
    if (_26916 >= _line_span_52141)
    goto L6; // [109] 128

    /** 		LineTable = append(LineTable, -1) -- filler*/
    Append(&_35LineTable_16057, _35LineTable_16057, -1);

    /** 	end while*/
    goto L5; // [125] 104
L6: 

    /** 	LineTable = append(LineTable, length(Code))*/
    if (IS_SEQUENCE(_35Code_16056)){
            _26919 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _26919 = 1;
    }
    Append(&_35LineTable_16057, _35LineTable_16057, _26919);
    _26919 = NOVALUE;

    /** 	if sl and (TRANSLATE or (OpTrace or OpProfileStatement)) then*/
    if (_sl_52136 == 0) {
        goto L7; // [145] 190
    }
    if (_35TRANSLATE_15611 != 0) {
        DeRef(_26922);
        _26922 = 1;
        goto L8; // [151] 171
    }
    if (_35OpTrace_16037 != 0) {
        _26923 = 1;
        goto L9; // [157] 167
    }
    _26923 = (_35OpProfileStatement_16039 != 0);
L9: 
    DeRef(_26922);
    _26922 = (_26923 != 0);
L8: 
    if (_26922 == 0)
    {
        _26922 = NOVALUE;
        goto L7; // [172] 190
    }
    else{
        _26922 = NOVALUE;
    }

    /** 		emit_op(STARTLINE)*/
    _41emit_op(58);

    /** 		emit_addr(gline_number)*/
    _41emit_addr(_35gline_number_15973);
L7: 

    /** 	if (sl and emit_coverage = COVERAGE_INCLUDE) or emit_coverage = COVERAGE_OVERRIDE then*/
    if (_sl_52136 == 0) {
        _26924 = 0;
        goto LA; // [192] 206
    }
    _26925 = (_emit_coverage_52138 == 2);
    _26924 = (_26925 != 0);
LA: 
    if (_26924 != 0) {
        goto LB; // [206] 221
    }
    _26927 = (_emit_coverage_52138 == 3);
    if (_26927 == 0)
    {
        DeRef(_26927);
        _26927 = NOVALUE;
        goto LC; // [217] 229
    }
    else{
        DeRef(_26927);
        _26927 = NOVALUE;
    }
LB: 

    /** 		include_line( gline_number )*/
    _50include_line(_35gline_number_15973);
LC: 

    /** end procedure*/
    DeRef(_26925);
    _26925 = NOVALUE;
    return;
    ;
}


int _41has_forward_params(int _sym_52195)
{
    int _26933 = NOVALUE;
    int _26932 = NOVALUE;
    int _26931 = NOVALUE;
    int _26930 = NOVALUE;
    int _26929 = NOVALUE;
    int _26928 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_52195)) {
        _1 = (long)(DBL_PTR(_sym_52195)->dbl);
        DeRefDS(_sym_52195);
        _sym_52195 = _1;
    }

    /** 	for i = cgi - (SymTab[sym][S_NUM_ARGS]-1) to cgi do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _26928 = (int)*(((s1_ptr)_2)->base + _sym_52195);
    _2 = (int)SEQ_PTR(_26928);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _26929 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _26929 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _26928 = NOVALUE;
    if (IS_ATOM_INT(_26929)) {
        _26930 = _26929 - 1;
        if ((long)((unsigned long)_26930 +(unsigned long) HIGH_BITS) >= 0){
            _26930 = NewDouble((double)_26930);
        }
    }
    else {
        _26930 = binary_op(MINUS, _26929, 1);
    }
    _26929 = NOVALUE;
    if (IS_ATOM_INT(_26930)) {
        _26931 = _41cgi_49790 - _26930;
        if ((long)((unsigned long)_26931 +(unsigned long) HIGH_BITS) >= 0){
            _26931 = NewDouble((double)_26931);
        }
    }
    else {
        _26931 = binary_op(MINUS, _41cgi_49790, _26930);
    }
    DeRef(_26930);
    _26930 = NOVALUE;
    _26932 = _41cgi_49790;
    {
        int _i_52197;
        Ref(_26931);
        _i_52197 = _26931;
L1: 
        if (binary_op_a(GREATER, _i_52197, _26932)){
            goto L2; // [32] 65
        }

        /** 		if cg_stack[i] < 0 then*/
        _2 = (int)SEQ_PTR(_41cg_stack_49789);
        if (!IS_ATOM_INT(_i_52197)){
            _26933 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_52197)->dbl));
        }
        else{
            _26933 = (int)*(((s1_ptr)_2)->base + _i_52197);
        }
        if (binary_op_a(GREATEREQ, _26933, 0)){
            _26933 = NOVALUE;
            goto L3; // [47] 58
        }
        _26933 = NOVALUE;

        /** 			return 1*/
        DeRef(_i_52197);
        DeRef(_26931);
        _26931 = NOVALUE;
        return 1;
L3: 

        /** 	end for*/
        _0 = _i_52197;
        if (IS_ATOM_INT(_i_52197)) {
            _i_52197 = _i_52197 + 1;
            if ((long)((unsigned long)_i_52197 +(unsigned long) HIGH_BITS) >= 0){
                _i_52197 = NewDouble((double)_i_52197);
            }
        }
        else {
            _i_52197 = binary_op_a(PLUS, _i_52197, 1);
        }
        DeRef(_0);
        goto L1; // [60] 39
L2: 
        ;
        DeRef(_i_52197);
    }

    /** 	return 0*/
    DeRef(_26931);
    _26931 = NOVALUE;
    return 0;
    ;
}



// 0xA958C081
