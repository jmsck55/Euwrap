// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _15int_to_bytes(int _x_1748)
{
    int _a_1749 = NOVALUE;
    int _b_1750 = NOVALUE;
    int _c_1751 = NOVALUE;
    int _d_1752 = NOVALUE;
    int _734 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1748)) {
        _a_1749 = (_x_1748 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_1749 = Dremainder(DBL_PTR(_x_1748), &temp_d);
    }
    if (!IS_ATOM_INT(_a_1749)) {
        _1 = (long)(DBL_PTR(_a_1749)->dbl);
        DeRefDS(_a_1749);
        _a_1749 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1748;
    if (IS_ATOM_INT(_x_1748)) {
        if (256 > 0 && _x_1748 >= 0) {
            _x_1748 = _x_1748 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1748 / (double)256);
            if (_x_1748 != MININT)
            _x_1748 = (long)temp_dbl;
            else
            _x_1748 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1748, 256);
        _x_1748 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1748)) {
        _b_1750 = (_x_1748 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_1750 = Dremainder(DBL_PTR(_x_1748), &temp_d);
    }
    if (!IS_ATOM_INT(_b_1750)) {
        _1 = (long)(DBL_PTR(_b_1750)->dbl);
        DeRefDS(_b_1750);
        _b_1750 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1748;
    if (IS_ATOM_INT(_x_1748)) {
        if (256 > 0 && _x_1748 >= 0) {
            _x_1748 = _x_1748 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1748 / (double)256);
            if (_x_1748 != MININT)
            _x_1748 = (long)temp_dbl;
            else
            _x_1748 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1748, 256);
        _x_1748 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1748)) {
        _c_1751 = (_x_1748 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_1751 = Dremainder(DBL_PTR(_x_1748), &temp_d);
    }
    if (!IS_ATOM_INT(_c_1751)) {
        _1 = (long)(DBL_PTR(_c_1751)->dbl);
        DeRefDS(_c_1751);
        _c_1751 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_1748;
    if (IS_ATOM_INT(_x_1748)) {
        if (256 > 0 && _x_1748 >= 0) {
            _x_1748 = _x_1748 / 256;
        }
        else {
            temp_dbl = floor((double)_x_1748 / (double)256);
            if (_x_1748 != MININT)
            _x_1748 = (long)temp_dbl;
            else
            _x_1748 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_1748, 256);
        _x_1748 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_1748)) {
        _d_1752 = (_x_1748 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_1752 = Dremainder(DBL_PTR(_x_1748), &temp_d);
    }
    if (!IS_ATOM_INT(_d_1752)) {
        _1 = (long)(DBL_PTR(_d_1752)->dbl);
        DeRefDS(_d_1752);
        _d_1752 = _1;
    }

    /** 	return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_1749;
    *((int *)(_2+8)) = _b_1750;
    *((int *)(_2+12)) = _c_1751;
    *((int *)(_2+16)) = _d_1752;
    _734 = MAKE_SEQ(_1);
    DeRef(_x_1748);
    return _734;
    ;
}


int _15int_to_bits(int _x_1790, int _nbits_1791)
{
    int _bits_1792 = NOVALUE;
    int _mask_1793 = NOVALUE;
    int _760 = NOVALUE;
    int _759 = NOVALUE;
    int _757 = NOVALUE;
    int _754 = NOVALUE;
    int _753 = NOVALUE;
    int _752 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if nbits < 1 then*/

    /** 	bits = repeat(0, nbits)*/
    DeRef(_bits_1792);
    _bits_1792 = Repeat(0, _nbits_1791);

    /** 	if nbits <= 32 then*/

    /** 		mask = 1*/
    DeRef(_mask_1793);
    _mask_1793 = 1;

    /** 		for i = 1 to nbits do*/
    _752 = _nbits_1791;
    {
        int _i_1800;
        _i_1800 = 1;
L1: 
        if (_i_1800 > _752){
            goto L2; // [38] 72
        }

        /** 			bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_1790) && IS_ATOM_INT(_mask_1793)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_1790 & (unsigned long)_mask_1793;
                 _753 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_1790)) {
                temp_d.dbl = (double)_x_1790;
                _753 = Dand_bits(&temp_d, DBL_PTR(_mask_1793));
            }
            else {
                if (IS_ATOM_INT(_mask_1793)) {
                    temp_d.dbl = (double)_mask_1793;
                    _753 = Dand_bits(DBL_PTR(_x_1790), &temp_d);
                }
                else
                _753 = Dand_bits(DBL_PTR(_x_1790), DBL_PTR(_mask_1793));
            }
        }
        if (IS_ATOM_INT(_753)) {
            _754 = (_753 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _754 = Dand(DBL_PTR(_753), &temp_d);
        }
        DeRef(_753);
        _753 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_1792);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1792 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1800);
        _1 = *(int *)_2;
        *(int *)_2 = _754;
        if( _1 != _754 ){
            DeRef(_1);
        }
        _754 = NOVALUE;

        /** 			mask *= 2*/
        _0 = _mask_1793;
        if (IS_ATOM_INT(_mask_1793) && IS_ATOM_INT(_mask_1793)) {
            _mask_1793 = _mask_1793 + _mask_1793;
            if ((long)((unsigned long)_mask_1793 + (unsigned long)HIGH_BITS) >= 0) 
            _mask_1793 = NewDouble((double)_mask_1793);
        }
        else {
            if (IS_ATOM_INT(_mask_1793)) {
                _mask_1793 = NewDouble((double)_mask_1793 + DBL_PTR(_mask_1793)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_1793)) {
                    _mask_1793 = NewDouble(DBL_PTR(_mask_1793)->dbl + (double)_mask_1793);
                }
                else
                _mask_1793 = NewDouble(DBL_PTR(_mask_1793)->dbl + DBL_PTR(_mask_1793)->dbl);
            }
        }
        DeRef(_0);

        /** 		end for*/
        _i_1800 = _i_1800 + 1;
        goto L1; // [67] 45
L2: 
        ;
    }
    goto L3; // [72] 128

    /** 		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_1790, 0)){
        goto L4; // [77] 92
    }

    /** 			x += power(2, nbits) -- for 2's complement bit pattern*/
    _757 = power(2, _nbits_1791);
    _0 = _x_1790;
    if (IS_ATOM_INT(_x_1790) && IS_ATOM_INT(_757)) {
        _x_1790 = _x_1790 + _757;
        if ((long)((unsigned long)_x_1790 + (unsigned long)HIGH_BITS) >= 0) 
        _x_1790 = NewDouble((double)_x_1790);
    }
    else {
        if (IS_ATOM_INT(_x_1790)) {
            _x_1790 = NewDouble((double)_x_1790 + DBL_PTR(_757)->dbl);
        }
        else {
            if (IS_ATOM_INT(_757)) {
                _x_1790 = NewDouble(DBL_PTR(_x_1790)->dbl + (double)_757);
            }
            else
            _x_1790 = NewDouble(DBL_PTR(_x_1790)->dbl + DBL_PTR(_757)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_757);
    _757 = NOVALUE;
L4: 

    /** 		for i = 1 to nbits do*/
    _759 = _nbits_1791;
    {
        int _i_1811;
        _i_1811 = 1;
L5: 
        if (_i_1811 > _759){
            goto L6; // [97] 127
        }

        /** 			bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_1790)) {
            _760 = (_x_1790 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _760 = Dremainder(DBL_PTR(_x_1790), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_1792);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_1792 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_1811);
        _1 = *(int *)_2;
        *(int *)_2 = _760;
        if( _1 != _760 ){
            DeRef(_1);
        }
        _760 = NOVALUE;

        /** 			x = floor(x / 2)*/
        _0 = _x_1790;
        if (IS_ATOM_INT(_x_1790)) {
            _x_1790 = _x_1790 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_1790, 2);
            _x_1790 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 		end for*/
        _i_1811 = _i_1811 + 1;
        goto L5; // [122] 104
L6: 
        ;
    }
L3: 

    /** 	return bits*/
    DeRef(_x_1790);
    DeRef(_mask_1793);
    return _bits_1792;
    ;
}


int _15bits_to_int(int _bits_1817)
{
    int _value_1818 = NOVALUE;
    int _p_1819 = NOVALUE;
    int _763 = NOVALUE;
    int _762 = NOVALUE;
    int _0, _1, _2;
    

    /** 	value = 0*/
    DeRef(_value_1818);
    _value_1818 = 0;

    /** 	p = 1*/
    DeRef(_p_1819);
    _p_1819 = 1;

    /** 	for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_1817)){
            _762 = SEQ_PTR(_bits_1817)->length;
    }
    else {
        _762 = 1;
    }
    {
        int _i_1821;
        _i_1821 = 1;
L1: 
        if (_i_1821 > _762){
            goto L2; // [18] 54
        }

        /** 		if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_1817);
        _763 = (int)*(((s1_ptr)_2)->base + _i_1821);
        if (_763 == 0) {
            _763 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_763) && DBL_PTR(_763)->dbl == 0.0){
                _763 = NOVALUE;
                goto L3; // [31] 41
            }
            _763 = NOVALUE;
        }
        _763 = NOVALUE;

        /** 			value += p*/
        _0 = _value_1818;
        if (IS_ATOM_INT(_value_1818) && IS_ATOM_INT(_p_1819)) {
            _value_1818 = _value_1818 + _p_1819;
            if ((long)((unsigned long)_value_1818 + (unsigned long)HIGH_BITS) >= 0) 
            _value_1818 = NewDouble((double)_value_1818);
        }
        else {
            if (IS_ATOM_INT(_value_1818)) {
                _value_1818 = NewDouble((double)_value_1818 + DBL_PTR(_p_1819)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1819)) {
                    _value_1818 = NewDouble(DBL_PTR(_value_1818)->dbl + (double)_p_1819);
                }
                else
                _value_1818 = NewDouble(DBL_PTR(_value_1818)->dbl + DBL_PTR(_p_1819)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 		p += p*/
        _0 = _p_1819;
        if (IS_ATOM_INT(_p_1819) && IS_ATOM_INT(_p_1819)) {
            _p_1819 = _p_1819 + _p_1819;
            if ((long)((unsigned long)_p_1819 + (unsigned long)HIGH_BITS) >= 0) 
            _p_1819 = NewDouble((double)_p_1819);
        }
        else {
            if (IS_ATOM_INT(_p_1819)) {
                _p_1819 = NewDouble((double)_p_1819 + DBL_PTR(_p_1819)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_1819)) {
                    _p_1819 = NewDouble(DBL_PTR(_p_1819)->dbl + (double)_p_1819);
                }
                else
                _p_1819 = NewDouble(DBL_PTR(_p_1819)->dbl + DBL_PTR(_p_1819)->dbl);
            }
        }
        DeRef(_0);

        /** 	end for*/
        _i_1821 = _i_1821 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** 	return value*/
    DeRefDS(_bits_1817);
    DeRef(_p_1819);
    return _value_1818;
    ;
}


int _15atom_to_float64(int _a_1829)
{
    int _766 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F64, a)*/
    _766 = machine(46, _a_1829);
    DeRef(_a_1829);
    return _766;
    ;
}


int _15atom_to_float32(int _a_1833)
{
    int _767 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F32, a)*/
    _767 = machine(48, _a_1833);
    DeRef(_a_1833);
    return _767;
    ;
}


int _15float64_to_atom(int _ieee64_1837)
{
    int _768 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F64_TO_A, ieee64)*/
    _768 = machine(47, _ieee64_1837);
    DeRefDS(_ieee64_1837);
    return _768;
    ;
}


int _15float32_to_atom(int _ieee32_1841)
{
    int _769 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    _769 = machine(49, _ieee32_1841);
    DeRefDS(_ieee32_1841);
    return _769;
    ;
}


int _15to_number(int _text_in_1920, int _return_bad_pos_1921)
{
    int _lDotFound_1922 = NOVALUE;
    int _lSignFound_1923 = NOVALUE;
    int _lCharValue_1924 = NOVALUE;
    int _lBadPos_1925 = NOVALUE;
    int _lLeftSize_1926 = NOVALUE;
    int _lRightSize_1927 = NOVALUE;
    int _lLeftValue_1928 = NOVALUE;
    int _lRightValue_1929 = NOVALUE;
    int _lBase_1930 = NOVALUE;
    int _lPercent_1931 = NOVALUE;
    int _lResult_1932 = NOVALUE;
    int _lDigitCount_1933 = NOVALUE;
    int _lCurrencyFound_1934 = NOVALUE;
    int _lLastDigit_1935 = NOVALUE;
    int _lChar_1936 = NOVALUE;
    int _892 = NOVALUE;
    int _891 = NOVALUE;
    int _884 = NOVALUE;
    int _882 = NOVALUE;
    int _881 = NOVALUE;
    int _876 = NOVALUE;
    int _875 = NOVALUE;
    int _874 = NOVALUE;
    int _873 = NOVALUE;
    int _872 = NOVALUE;
    int _871 = NOVALUE;
    int _867 = NOVALUE;
    int _863 = NOVALUE;
    int _855 = NOVALUE;
    int _843 = NOVALUE;
    int _842 = NOVALUE;
    int _836 = NOVALUE;
    int _834 = NOVALUE;
    int _828 = NOVALUE;
    int _827 = NOVALUE;
    int _826 = NOVALUE;
    int _825 = NOVALUE;
    int _824 = NOVALUE;
    int _823 = NOVALUE;
    int _822 = NOVALUE;
    int _821 = NOVALUE;
    int _820 = NOVALUE;
    int _812 = NOVALUE;
    int _811 = NOVALUE;
    int _810 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lDotFound = 0*/
    _lDotFound_1922 = 0;

    /** 	integer lSignFound = 2*/
    _lSignFound_1923 = 2;

    /** 	integer lBadPos = 0*/
    _lBadPos_1925 = 0;

    /** 	atom    lLeftSize = 0*/
    DeRef(_lLeftSize_1926);
    _lLeftSize_1926 = 0;

    /** 	atom    lRightSize = 1*/
    DeRef(_lRightSize_1927);
    _lRightSize_1927 = 1;

    /** 	atom    lLeftValue = 0*/
    DeRef(_lLeftValue_1928);
    _lLeftValue_1928 = 0;

    /** 	atom    lRightValue = 0*/
    DeRef(_lRightValue_1929);
    _lRightValue_1929 = 0;

    /** 	integer lBase = 10*/
    _lBase_1930 = 10;

    /** 	integer lPercent = 1*/
    _lPercent_1931 = 1;

    /** 	integer lDigitCount = 0*/
    _lDigitCount_1933 = 0;

    /** 	integer lCurrencyFound = 0*/
    _lCurrencyFound_1934 = 0;

    /** 	integer lLastDigit = 0*/
    _lLastDigit_1935 = 0;

    /** 	for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_1920)){
            _810 = SEQ_PTR(_text_in_1920)->length;
    }
    else {
        _810 = 1;
    }
    {
        int _i_1938;
        _i_1938 = 1;
L1: 
        if (_i_1938 > _810){
            goto L2; // [70] 672
        }

        /** 		if not integer(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_1920);
        _811 = (int)*(((s1_ptr)_2)->base + _i_1938);
        if (IS_ATOM_INT(_811))
        _812 = 1;
        else if (IS_ATOM_DBL(_811))
        _812 = IS_ATOM_INT(DoubleToInt(_811));
        else
        _812 = 0;
        _811 = NOVALUE;
        if (_812 != 0)
        goto L3; // [86] 94
        _812 = NOVALUE;

        /** 			exit*/
        goto L2; // [91] 672
L3: 

        /** 		lChar = text_in[i]*/
        _2 = (int)SEQ_PTR(_text_in_1920);
        _lChar_1936 = (int)*(((s1_ptr)_2)->base + _i_1938);
        if (!IS_ATOM_INT(_lChar_1936))
        _lChar_1936 = (long)DBL_PTR(_lChar_1936)->dbl;

        /** 		switch lChar do*/
        _0 = _lChar_1936;
        switch ( _0 ){ 

            /** 			case '-' then*/
            case 45:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_1923 != 2)
            goto L4; // [113] 130

            /** 					lSignFound = -1*/
            _lSignFound_1923 = -1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1935 = _lDigitCount_1933;
            goto L5; // [127] 654
L4: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [136] 654

            /** 			case '+' then*/
            case 43:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_1923 != 2)
            goto L6; // [144] 161

            /** 					lSignFound = 1*/
            _lSignFound_1923 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1935 = _lDigitCount_1933;
            goto L5; // [158] 654
L6: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [167] 654

            /** 			case '#' then*/
            case 35:

            /** 				if lDigitCount = 0 and lBase = 10 then*/
            _820 = (_lDigitCount_1933 == 0);
            if (_820 == 0) {
                goto L7; // [179] 199
            }
            _822 = (_lBase_1930 == 10);
            if (_822 == 0)
            {
                DeRef(_822);
                _822 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_822);
                _822 = NOVALUE;
            }

            /** 					lBase = 16*/
            _lBase_1930 = 16;
            goto L5; // [196] 654
L7: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [205] 654

            /** 			case '@' then*/
            case 64:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _823 = (_lDigitCount_1933 == 0);
            if (_823 == 0) {
                goto L8; // [217] 237
            }
            _825 = (_lBase_1930 == 10);
            if (_825 == 0)
            {
                DeRef(_825);
                _825 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_825);
                _825 = NOVALUE;
            }

            /** 					lBase = 8*/
            _lBase_1930 = 8;
            goto L5; // [234] 654
L8: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [243] 654

            /** 			case '!' then*/
            case 33:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _826 = (_lDigitCount_1933 == 0);
            if (_826 == 0) {
                goto L9; // [255] 275
            }
            _828 = (_lBase_1930 == 10);
            if (_828 == 0)
            {
                DeRef(_828);
                _828 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_828);
                _828 = NOVALUE;
            }

            /** 					lBase = 2*/
            _lBase_1930 = 2;
            goto L5; // [272] 654
L9: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [281] 654

            /** 			case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** 				if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_1934 != 0)
            goto LA; // [297] 314

            /** 					lCurrencyFound = 1*/
            _lCurrencyFound_1934 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_1935 = _lDigitCount_1933;
            goto L5; // [311] 654
LA: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [320] 654

            /** 			case '_' then -- grouping character*/
            case 95:

            /** 				if lDigitCount = 0 or lLastDigit != 0 then*/
            _834 = (_lDigitCount_1933 == 0);
            if (_834 != 0) {
                goto LB; // [332] 345
            }
            _836 = (_lLastDigit_1935 != 0);
            if (_836 == 0)
            {
                DeRef(_836);
                _836 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_836);
                _836 = NOVALUE;
            }
LB: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [351] 654

            /** 			case '.', ',' then*/
            case 46:
            case 44:

            /** 				if lLastDigit = 0 then*/
            if (_lLastDigit_1935 != 0)
            goto LC; // [361] 400

            /** 					if decimal_mark = lChar then*/
            if (46 != _lChar_1936)
            goto L5; // [369] 654

            /** 						if lDotFound = 0 then*/
            if (_lDotFound_1922 != 0)
            goto LD; // [375] 387

            /** 							lDotFound = 1*/
            _lDotFound_1922 = 1;
            goto L5; // [384] 654
LD: 

            /** 							lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [406] 654

            /** 			case '%' then*/
            case 37:

            /** 				lLastDigit = lDigitCount*/
            _lLastDigit_1935 = _lDigitCount_1933;

            /** 				if lPercent = 1 then*/
            if (_lPercent_1931 != 1)
            goto LE; // [419] 431

            /** 					lPercent = 100*/
            _lPercent_1931 = 100;
            goto L5; // [428] 654
LE: 

            /** 					if text_in[i-1] = '%' then*/
            _842 = _i_1938 - 1;
            _2 = (int)SEQ_PTR(_text_in_1920);
            _843 = (int)*(((s1_ptr)_2)->base + _842);
            if (binary_op_a(NOTEQ, _843, 37)){
                _843 = NOVALUE;
                goto LF; // [441] 456
            }
            _843 = NOVALUE;

            /** 						lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_1931 = _lPercent_1931 * 10;
            goto L5; // [453] 654
LF: 

            /** 						lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [463] 654

            /** 			case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** 				if lDigitCount = 0 then*/
            if (_lDigitCount_1933 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** 					lLastDigit = i*/
            _lLastDigit_1935 = _i_1938;
            goto L5; // [488] 654

            /** 			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** 	            lCharValue = find(lChar, vDigits) - 1*/
            _855 = find_from(_lChar_1936, _15vDigits_1906, 1);
            _lCharValue_1924 = _855 - 1;
            _855 = NOVALUE;

            /** 	            if lCharValue > 15 then*/
            if (_lCharValue_1924 <= 15)
            goto L11; // [549] 560

            /** 	            	lCharValue -= 6*/
            _lCharValue_1924 = _lCharValue_1924 - 6;
L11: 

            /** 	            if lCharValue >= lBase then*/
            if (_lCharValue_1924 < _lBase_1930)
            goto L12; // [562] 574

            /** 	                lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [571] 654
L12: 

            /** 	            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_1935 == 0)
            goto L13; // [576] 588

            /** 					lBadPos = i*/
            _lBadPos_1925 = _i_1938;
            goto L5; // [585] 654
L13: 

            /** 				elsif lDotFound = 1 then*/
            if (_lDotFound_1922 != 1)
            goto L14; // [590] 619

            /** 					lRightSize *= lBase*/
            _0 = _lRightSize_1927;
            if (IS_ATOM_INT(_lRightSize_1927)) {
                if (_lRightSize_1927 == (short)_lRightSize_1927 && _lBase_1930 <= INT15 && _lBase_1930 >= -INT15)
                _lRightSize_1927 = _lRightSize_1927 * _lBase_1930;
                else
                _lRightSize_1927 = NewDouble(_lRightSize_1927 * (double)_lBase_1930);
            }
            else {
                _lRightSize_1927 = NewDouble(DBL_PTR(_lRightSize_1927)->dbl * (double)_lBase_1930);
            }
            DeRef(_0);

            /** 					lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_1929)) {
                if (_lRightValue_1929 == (short)_lRightValue_1929 && _lBase_1930 <= INT15 && _lBase_1930 >= -INT15)
                _863 = _lRightValue_1929 * _lBase_1930;
                else
                _863 = NewDouble(_lRightValue_1929 * (double)_lBase_1930);
            }
            else {
                _863 = NewDouble(DBL_PTR(_lRightValue_1929)->dbl * (double)_lBase_1930);
            }
            DeRef(_lRightValue_1929);
            if (IS_ATOM_INT(_863)) {
                _lRightValue_1929 = _863 + _lCharValue_1924;
                if ((long)((unsigned long)_lRightValue_1929 + (unsigned long)HIGH_BITS) >= 0) 
                _lRightValue_1929 = NewDouble((double)_lRightValue_1929);
            }
            else {
                _lRightValue_1929 = NewDouble(DBL_PTR(_863)->dbl + (double)_lCharValue_1924);
            }
            DeRef(_863);
            _863 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_1933 = _lDigitCount_1933 + 1;
            goto L5; // [616] 654
L14: 

            /** 					lLeftSize += 1*/
            _0 = _lLeftSize_1926;
            if (IS_ATOM_INT(_lLeftSize_1926)) {
                _lLeftSize_1926 = _lLeftSize_1926 + 1;
                if (_lLeftSize_1926 > MAXINT){
                    _lLeftSize_1926 = NewDouble((double)_lLeftSize_1926);
                }
            }
            else
            _lLeftSize_1926 = binary_op(PLUS, 1, _lLeftSize_1926);
            DeRef(_0);

            /** 					lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_1928)) {
                if (_lLeftValue_1928 == (short)_lLeftValue_1928 && _lBase_1930 <= INT15 && _lBase_1930 >= -INT15)
                _867 = _lLeftValue_1928 * _lBase_1930;
                else
                _867 = NewDouble(_lLeftValue_1928 * (double)_lBase_1930);
            }
            else {
                _867 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl * (double)_lBase_1930);
            }
            DeRef(_lLeftValue_1928);
            if (IS_ATOM_INT(_867)) {
                _lLeftValue_1928 = _867 + _lCharValue_1924;
                if ((long)((unsigned long)_lLeftValue_1928 + (unsigned long)HIGH_BITS) >= 0) 
                _lLeftValue_1928 = NewDouble((double)_lLeftValue_1928);
            }
            else {
                _lLeftValue_1928 = NewDouble(DBL_PTR(_867)->dbl + (double)_lCharValue_1924);
            }
            DeRef(_867);
            _867 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_1933 = _lDigitCount_1933 + 1;
            goto L5; // [642] 654

            /** 			case else*/
            default:

            /** 				lBadPos = i*/
            _lBadPos_1925 = _i_1938;
        ;}L5: 

        /** 		if lBadPos != 0 then*/
        if (_lBadPos_1925 == 0)
        goto L15; // [656] 665

        /** 			exit*/
        goto L2; // [662] 672
L15: 

        /** 	end for*/
        _i_1938 = _i_1938 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** 	if lBadPos = 0 and lDigitCount = 0 then*/
    _871 = (_lBadPos_1925 == 0);
    if (_871 == 0) {
        goto L16; // [678] 696
    }
    _873 = (_lDigitCount_1933 == 0);
    if (_873 == 0)
    {
        DeRef(_873);
        _873 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_873);
        _873 = NOVALUE;
    }

    /** 		lBadPos = 1*/
    _lBadPos_1925 = 1;
L16: 

    /** 	if return_bad_pos = 0 and lBadPos != 0 then*/
    _874 = (_return_bad_pos_1921 == 0);
    if (_874 == 0) {
        goto L17; // [702] 721
    }
    _876 = (_lBadPos_1925 != 0);
    if (_876 == 0)
    {
        DeRef(_876);
        _876 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_876);
        _876 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_text_in_1920);
    DeRef(_lLeftSize_1926);
    DeRef(_lRightSize_1927);
    DeRef(_lLeftValue_1928);
    DeRef(_lRightValue_1929);
    DeRef(_lResult_1932);
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_826);
    _826 = NOVALUE;
    DeRef(_834);
    _834 = NOVALUE;
    DeRef(_842);
    _842 = NOVALUE;
    DeRef(_871);
    _871 = NOVALUE;
    DeRef(_874);
    _874 = NOVALUE;
    return 0;
L17: 

    /** 	if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_1929, 0)){
        goto L18; // [723] 751
    }

    /** 	    if lPercent != 1 then*/
    if (_lPercent_1931 == 1)
    goto L19; // [729] 742

    /** 			lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_1932);
    if (IS_ATOM_INT(_lLeftValue_1928)) {
        _lResult_1932 = (_lLeftValue_1928 % _lPercent_1931) ? NewDouble((double)_lLeftValue_1928 / _lPercent_1931) : (_lLeftValue_1928 / _lPercent_1931);
    }
    else {
        _lResult_1932 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl / (double)_lPercent_1931);
    }
    goto L1A; // [739] 786
L19: 

    /** 	        lResult = lLeftValue*/
    Ref(_lLeftValue_1928);
    DeRef(_lResult_1932);
    _lResult_1932 = _lLeftValue_1928;
    goto L1A; // [748] 786
L18: 

    /** 	    if lPercent != 1 then*/
    if (_lPercent_1931 == 1)
    goto L1B; // [753] 774

    /** 	        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_1929) && IS_ATOM_INT(_lRightSize_1927)) {
        _881 = (_lRightValue_1929 % _lRightSize_1927) ? NewDouble((double)_lRightValue_1929 / _lRightSize_1927) : (_lRightValue_1929 / _lRightSize_1927);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_1929)) {
            _881 = NewDouble((double)_lRightValue_1929 / DBL_PTR(_lRightSize_1927)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_1927)) {
                _881 = NewDouble(DBL_PTR(_lRightValue_1929)->dbl / (double)_lRightSize_1927);
            }
            else
            _881 = NewDouble(DBL_PTR(_lRightValue_1929)->dbl / DBL_PTR(_lRightSize_1927)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_1928) && IS_ATOM_INT(_881)) {
        _882 = _lLeftValue_1928 + _881;
        if ((long)((unsigned long)_882 + (unsigned long)HIGH_BITS) >= 0) 
        _882 = NewDouble((double)_882);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_1928)) {
            _882 = NewDouble((double)_lLeftValue_1928 + DBL_PTR(_881)->dbl);
        }
        else {
            if (IS_ATOM_INT(_881)) {
                _882 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl + (double)_881);
            }
            else
            _882 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl + DBL_PTR(_881)->dbl);
        }
    }
    DeRef(_881);
    _881 = NOVALUE;
    DeRef(_lResult_1932);
    if (IS_ATOM_INT(_882)) {
        _lResult_1932 = (_882 % _lPercent_1931) ? NewDouble((double)_882 / _lPercent_1931) : (_882 / _lPercent_1931);
    }
    else {
        _lResult_1932 = NewDouble(DBL_PTR(_882)->dbl / (double)_lPercent_1931);
    }
    DeRef(_882);
    _882 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** 	        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_1929) && IS_ATOM_INT(_lRightSize_1927)) {
        _884 = (_lRightValue_1929 % _lRightSize_1927) ? NewDouble((double)_lRightValue_1929 / _lRightSize_1927) : (_lRightValue_1929 / _lRightSize_1927);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_1929)) {
            _884 = NewDouble((double)_lRightValue_1929 / DBL_PTR(_lRightSize_1927)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_1927)) {
                _884 = NewDouble(DBL_PTR(_lRightValue_1929)->dbl / (double)_lRightSize_1927);
            }
            else
            _884 = NewDouble(DBL_PTR(_lRightValue_1929)->dbl / DBL_PTR(_lRightSize_1927)->dbl);
        }
    }
    DeRef(_lResult_1932);
    if (IS_ATOM_INT(_lLeftValue_1928) && IS_ATOM_INT(_884)) {
        _lResult_1932 = _lLeftValue_1928 + _884;
        if ((long)((unsigned long)_lResult_1932 + (unsigned long)HIGH_BITS) >= 0) 
        _lResult_1932 = NewDouble((double)_lResult_1932);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_1928)) {
            _lResult_1932 = NewDouble((double)_lLeftValue_1928 + DBL_PTR(_884)->dbl);
        }
        else {
            if (IS_ATOM_INT(_884)) {
                _lResult_1932 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl + (double)_884);
            }
            else
            _lResult_1932 = NewDouble(DBL_PTR(_lLeftValue_1928)->dbl + DBL_PTR(_884)->dbl);
        }
    }
    DeRef(_884);
    _884 = NOVALUE;
L1C: 
L1A: 

    /** 	if lSignFound < 0 then*/
    if (_lSignFound_1923 >= 0)
    goto L1D; // [788] 800

    /** 		lResult = -lResult*/
    _0 = _lResult_1932;
    if (IS_ATOM_INT(_lResult_1932)) {
        if ((unsigned long)_lResult_1932 == 0xC0000000)
        _lResult_1932 = (int)NewDouble((double)-0xC0000000);
        else
        _lResult_1932 = - _lResult_1932;
    }
    else {
        _lResult_1932 = unary_op(UMINUS, _lResult_1932);
    }
    DeRef(_0);
L1D: 

    /** 	if return_bad_pos = 0 then*/
    if (_return_bad_pos_1921 != 0)
    goto L1E; // [802] 815

    /** 		return lResult*/
    DeRefDS(_text_in_1920);
    DeRef(_lLeftSize_1926);
    DeRef(_lRightSize_1927);
    DeRef(_lLeftValue_1928);
    DeRef(_lRightValue_1929);
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_826);
    _826 = NOVALUE;
    DeRef(_834);
    _834 = NOVALUE;
    DeRef(_842);
    _842 = NOVALUE;
    DeRef(_871);
    _871 = NOVALUE;
    DeRef(_874);
    _874 = NOVALUE;
    return _lResult_1932;
L1E: 

    /** 	if return_bad_pos = -1 then*/
    if (_return_bad_pos_1921 != -1)
    goto L1F; // [817] 850

    /** 		if lBadPos = 0 then*/
    if (_lBadPos_1925 != 0)
    goto L20; // [823] 838

    /** 			return lResult*/
    DeRefDS(_text_in_1920);
    DeRef(_lLeftSize_1926);
    DeRef(_lRightSize_1927);
    DeRef(_lLeftValue_1928);
    DeRef(_lRightValue_1929);
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_826);
    _826 = NOVALUE;
    DeRef(_834);
    _834 = NOVALUE;
    DeRef(_842);
    _842 = NOVALUE;
    DeRef(_871);
    _871 = NOVALUE;
    DeRef(_874);
    _874 = NOVALUE;
    return _lResult_1932;
    goto L21; // [835] 849
L20: 

    /** 			return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _lBadPos_1925;
    _891 = MAKE_SEQ(_1);
    DeRefDS(_text_in_1920);
    DeRef(_lLeftSize_1926);
    DeRef(_lRightSize_1927);
    DeRef(_lLeftValue_1928);
    DeRef(_lRightValue_1929);
    DeRef(_lResult_1932);
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_826);
    _826 = NOVALUE;
    DeRef(_834);
    _834 = NOVALUE;
    DeRef(_842);
    _842 = NOVALUE;
    DeRef(_871);
    _871 = NOVALUE;
    DeRef(_874);
    _874 = NOVALUE;
    return _891;
L21: 
L1F: 

    /** 	return {lResult, lBadPos}*/
    Ref(_lResult_1932);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_1932;
    ((int *)_2)[2] = _lBadPos_1925;
    _892 = MAKE_SEQ(_1);
    DeRefDS(_text_in_1920);
    DeRef(_lLeftSize_1926);
    DeRef(_lRightSize_1927);
    DeRef(_lLeftValue_1928);
    DeRef(_lRightValue_1929);
    DeRef(_lResult_1932);
    DeRef(_820);
    _820 = NOVALUE;
    DeRef(_823);
    _823 = NOVALUE;
    DeRef(_826);
    _826 = NOVALUE;
    DeRef(_834);
    _834 = NOVALUE;
    DeRef(_842);
    _842 = NOVALUE;
    DeRef(_871);
    _871 = NOVALUE;
    DeRef(_874);
    _874 = NOVALUE;
    DeRef(_891);
    _891 = NOVALUE;
    return _892;
    ;
}



// 0x6374C021
