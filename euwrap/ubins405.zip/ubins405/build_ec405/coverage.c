// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _50check_coverage()
{
    int _24959 = NOVALUE;
    int _24958 = NOVALUE;
    int _24957 = NOVALUE;
    int _24956 = NOVALUE;
    int _24955 = NOVALUE;
    int _24954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_50file_coverage_47724)){
            _24954 = SEQ_PTR(_50file_coverage_47724)->length;
    }
    else {
        _24954 = 1;
    }
    _24955 = _24954 + 1;
    _24954 = NOVALUE;
    if (IS_SEQUENCE(_36known_files_14982)){
            _24956 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _24956 = 1;
    }
    {
        int _i_47735;
        _i_47735 = _24955;
L1: 
        if (_i_47735 > _24956){
            goto L2; // [17] 58
        }

        /** 		file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_36known_files_14982);
        _24957 = (int)*(((s1_ptr)_2)->base + _i_47735);
        Ref(_24957);
        _24958 = _17canonical_path(_24957, 0, 1);
        _24957 = NOVALUE;
        _24959 = find_from(_24958, _50covered_files_47723, 1);
        DeRef(_24958);
        _24958 = NOVALUE;
        Append(&_50file_coverage_47724, _50file_coverage_47724, _24959);
        _24959 = NOVALUE;

        /** 	end for*/
        _i_47735 = _i_47735 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_24955);
    _24955 = NOVALUE;
    return;
    ;
}


void _50init_coverage()
{
    int _cmd_47759 = NOVALUE;
    int _24977 = NOVALUE;
    int _24976 = NOVALUE;
    int _24974 = NOVALUE;
    int _24973 = NOVALUE;
    int _24972 = NOVALUE;
    int _24970 = NOVALUE;
    int _24968 = NOVALUE;
    int _24967 = NOVALUE;
    int _24965 = NOVALUE;
    int _24964 = NOVALUE;
    int _24963 = NOVALUE;
    int _24962 = NOVALUE;
    int _24961 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initialized_coverage then*/
    if (_50initialized_coverage_47731 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return*/
    return;
L1: 

    /** 	initialized_coverage = 1*/
    _50initialized_coverage_47731 = 1;

    /** 	for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_50file_coverage_47724)){
            _24961 = SEQ_PTR(_50file_coverage_47724)->length;
    }
    else {
        _24961 = 1;
    }
    {
        int _i_47750;
        _i_47750 = 1;
L2: 
        if (_i_47750 > _24961){
            goto L3; // [26] 67
        }

        /** 		file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_36known_files_14982);
        _24962 = (int)*(((s1_ptr)_2)->base + _i_47750);
        Ref(_24962);
        _24963 = _17canonical_path(_24962, 0, 1);
        _24962 = NOVALUE;
        _24964 = find_from(_24963, _50covered_files_47723, 1);
        DeRef(_24963);
        _24963 = NOVALUE;
        _2 = (int)SEQ_PTR(_50file_coverage_47724);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _50file_coverage_47724 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_47750);
        *(int *)_2 = _24964;
        if( _1 != _24964 ){
        }
        _24964 = NOVALUE;

        /** 	end for*/
        _i_47750 = _i_47750 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** 	if equal( coverage_db_name, "" ) then*/
    if (_50coverage_db_name_47725 == _21815)
    _24965 = 1;
    else if (IS_ATOM_INT(_50coverage_db_name_47725) && IS_ATOM_INT(_21815))
    _24965 = 0;
    else
    _24965 = (compare(_50coverage_db_name_47725, _21815) == 0);
    if (_24965 == 0)
    {
        _24965 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _24965 = NOVALUE;
    }

    /** 		sequence cmd = command_line()*/
    DeRef(_cmd_47759);
    _cmd_47759 = Command_Line();

    /** 		coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (int)SEQ_PTR(_cmd_47759);
    _24967 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_24967);
    _24968 = _17filebase(_24967);
    _24967 = NOVALUE;
    if (IS_SEQUENCE(_24968) && IS_ATOM(_24969)) {
    }
    else if (IS_ATOM(_24968) && IS_SEQUENCE(_24969)) {
        Ref(_24968);
        Prepend(&_24970, _24969, _24968);
    }
    else {
        Concat((object_ptr)&_24970, _24968, _24969);
        DeRef(_24968);
        _24968 = NOVALUE;
    }
    DeRef(_24968);
    _24968 = NOVALUE;
    _0 = _17canonical_path(_24970, 0, 0);
    DeRefDS(_50coverage_db_name_47725);
    _50coverage_db_name_47725 = _0;
    _24970 = NOVALUE;
L4: 
    DeRef(_cmd_47759);
    _cmd_47759 = NOVALUE;

    /** 	if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_50coverage_erase_47726 == 0) {
        goto L5; // [111] 151
    }
    RefDS(_50coverage_db_name_47725);
    _24973 = _17file_exists(_50coverage_db_name_47725);
    if (_24973 == 0) {
        DeRef(_24973);
        _24973 = NOVALUE;
        goto L5; // [122] 151
    }
    else {
        if (!IS_ATOM_INT(_24973) && DBL_PTR(_24973)->dbl == 0.0){
            DeRef(_24973);
            _24973 = NOVALUE;
            goto L5; // [122] 151
        }
        DeRef(_24973);
        _24973 = NOVALUE;
    }
    DeRef(_24973);
    _24973 = NOVALUE;

    /** 		if not delete_file( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_47725);
    _24974 = _17delete_file(_50coverage_db_name_47725);
    if (IS_ATOM_INT(_24974)) {
        if (_24974 != 0){
            DeRef(_24974);
            _24974 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    else {
        if (DBL_PTR(_24974)->dbl != 0.0){
            DeRef(_24974);
            _24974 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    DeRef(_24974);
    _24974 = NOVALUE;

    /** 			CompileErr( 335, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_47725);
    *((int *)(_2+4)) = _50coverage_db_name_47725;
    _24976 = MAKE_SEQ(_1);
    _44CompileErr(335, _24976, 0);
    _24976 = NOVALUE;
L6: 
L5: 

    /** 	if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_50coverage_db_name_47725);
    _24977 = _49db_open(_50coverage_db_name_47725, 0);
    if (binary_op_a(NOTEQ, _24977, 0)){
        DeRef(_24977);
        _24977 = NOVALUE;
        goto L7; // [162] 175
    }
    DeRef(_24977);
    _24977 = NOVALUE;

    /** 		read_coverage_db()*/
    _50read_coverage_db();

    /** 		db_close()*/
    _49db_close();
L7: 

    /** end procedure*/
    return;
    ;
}


void _50write_map(int _coverage_47788, int _table_name_47789)
{
    int _keys_47811 = NOVALUE;
    int _rec_47816 = NOVALUE;
    int _val_47820 = NOVALUE;
    int _31378 = NOVALUE;
    int _24994 = NOVALUE;
    int _24991 = NOVALUE;
    int _24989 = NOVALUE;
    int _24988 = NOVALUE;
    int _24986 = NOVALUE;
    int _24985 = NOVALUE;
    int _24983 = NOVALUE;
    int _24981 = NOVALUE;
    int _24979 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_50coverage_db_name_47725);
    _24979 = _49db_select(_50coverage_db_name_47725, 2);
    if (binary_op_a(NOTEQ, _24979, 0)){
        DeRef(_24979);
        _24979 = NOVALUE;
        goto L1; // [16] 61
    }
    DeRef(_24979);
    _24979 = NOVALUE;

    /** 		if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_47789);
    _24981 = _49db_select_table(_table_name_47789);
    if (binary_op_a(EQUALS, _24981, 0)){
        DeRef(_24981);
        _24981 = NOVALUE;
        goto L2; // [28] 73
    }
    DeRef(_24981);
    _24981 = NOVALUE;

    /** 			if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_47789);
    _24983 = _49db_create_table(_table_name_47789, 50);
    if (binary_op_a(EQUALS, _24983, 0)){
        DeRef(_24983);
        _24983 = NOVALUE;
        goto L2; // [41] 73
    }
    DeRef(_24983);
    _24983 = NOVALUE;

    /** 				CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_47789);
    *((int *)(_2+4)) = _table_name_47789;
    _24985 = MAKE_SEQ(_1);
    _44CompileErr(336, _24985, 0);
    _24985 = NOVALUE;
    goto L2; // [58] 73
L1: 

    /** 		CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_47789);
    *((int *)(_2+4)) = _table_name_47789;
    _24986 = MAKE_SEQ(_1);
    _44CompileErr(336, _24986, 0);
    _24986 = NOVALUE;
L2: 

    /** 	sequence keys = map:keys( coverage )*/
    Ref(_coverage_47788);
    _0 = _keys_47811;
    _keys_47811 = _28keys(_coverage_47788, 0);
    DeRef(_0);

    /** 	for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_47811)){
            _24988 = SEQ_PTR(_keys_47811)->length;
    }
    else {
        _24988 = 1;
    }
    {
        int _i_47814;
        _i_47814 = 1;
L3: 
        if (_i_47814 > _24988){
            goto L4; // [87] 167
        }

        /** 		integer rec = db_find_key( keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_47811);
        _24989 = (int)*(((s1_ptr)_2)->base + _i_47814);
        Ref(_24989);
        RefDS(_49current_table_name_17056);
        _rec_47816 = _49db_find_key(_24989, _49current_table_name_17056);
        _24989 = NOVALUE;
        if (!IS_ATOM_INT(_rec_47816)) {
            _1 = (long)(DBL_PTR(_rec_47816)->dbl);
            DeRefDS(_rec_47816);
            _rec_47816 = _1;
        }

        /** 		integer val = map:get( coverage, keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_47811);
        _24991 = (int)*(((s1_ptr)_2)->base + _i_47814);
        Ref(_coverage_47788);
        Ref(_24991);
        _val_47820 = _28get(_coverage_47788, _24991, 0);
        _24991 = NOVALUE;
        if (!IS_ATOM_INT(_val_47820)) {
            _1 = (long)(DBL_PTR(_val_47820)->dbl);
            DeRefDS(_val_47820);
            _val_47820 = _1;
        }

        /** 		if rec > 0 then*/
        if (_rec_47816 <= 0)
        goto L5; // [125] 141

        /** 			db_replace_data( rec, val )*/
        RefDS(_49current_table_name_17056);
        _49db_replace_data(_rec_47816, _val_47820, _49current_table_name_17056);
        goto L6; // [138] 158
L5: 

        /** 			db_insert( keys[i], val )*/
        _2 = (int)SEQ_PTR(_keys_47811);
        _24994 = (int)*(((s1_ptr)_2)->base + _i_47814);
        Ref(_24994);
        RefDS(_49current_table_name_17056);
        _31378 = _49db_insert(_24994, _val_47820, _49current_table_name_17056);
        _24994 = NOVALUE;
        DeRef(_31378);
        _31378 = NOVALUE;
L6: 

        /** 	end for*/
        _i_47814 = _i_47814 + 1;
        goto L3; // [162] 94
L4: 
        ;
    }

    /** end procedure*/
    DeRef(_coverage_47788);
    DeRefDS(_table_name_47789);
    DeRef(_keys_47811);
    return;
    ;
}


int _50write_coverage_db()
{
    int _25009 = NOVALUE;
    int _25008 = NOVALUE;
    int _25007 = NOVALUE;
    int _25006 = NOVALUE;
    int _25005 = NOVALUE;
    int _25004 = NOVALUE;
    int _25003 = NOVALUE;
    int _25002 = NOVALUE;
    int _24999 = NOVALUE;
    int _24997 = NOVALUE;
    int _24995 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if wrote_coverage then*/
    if (_50wrote_coverage_47829 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** 		return 1*/
    return 1;
L1: 

    /** 	wrote_coverage = 1*/
    _50wrote_coverage_47829 = 1;

    /** 	init_coverage()*/
    _50init_coverage();

    /** 	if not length( covered_files ) then*/
    if (IS_SEQUENCE(_50covered_files_47723)){
            _24995 = SEQ_PTR(_50covered_files_47723)->length;
    }
    else {
        _24995 = 1;
    }
    if (_24995 != 0)
    goto L2; // [31] 41
    _24995 = NOVALUE;

    /** 		return 1*/
    return 1;
L2: 

    /** 	if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_50coverage_db_name_47725);
    _24997 = _49db_open(_50coverage_db_name_47725, 2);
    if (binary_op_a(EQUALS, 0, _24997)){
        DeRef(_24997);
        _24997 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_24997);
    _24997 = NOVALUE;

    /** 		if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_50coverage_db_name_47725);
    _24999 = _49db_create(_50coverage_db_name_47725, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _24999)){
        DeRef(_24999);
        _24999 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_24999);
    _24999 = NOVALUE;

    /** 			printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_50coverage_db_name_47725);
    *((int *)(_2+4)) = _50coverage_db_name_47725;
    _25002 = MAKE_SEQ(_1);
    EPrintf(2, _25001, _25002);
    DeRefDS(_25002);
    _25002 = NOVALUE;

    /** 			return 0*/
    return 0;
L4: 
L3: 

    /** 	process_lines()*/
    _50process_lines();

    /** 	for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_50routine_map_47729)){
            _25003 = SEQ_PTR(_50routine_map_47729)->length;
    }
    else {
        _25003 = 1;
    }
    {
        int _tx_47851;
        _tx_47851 = 1;
L5: 
        if (_tx_47851 > _25003){
            goto L6; // [106] 164
        }

        /** 		write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_50routine_map_47729);
        _25004 = (int)*(((s1_ptr)_2)->base + _tx_47851);
        _2 = (int)SEQ_PTR(_50covered_files_47723);
        _25005 = (int)*(((s1_ptr)_2)->base + _tx_47851);
        if (IS_SEQUENCE(114) && IS_ATOM(_25005)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25005)) {
            Prepend(&_25006, _25005, 114);
        }
        else {
            Concat((object_ptr)&_25006, 114, _25005);
        }
        _25005 = NOVALUE;
        Ref(_25004);
        _50write_map(_25004, _25006);
        _25004 = NOVALUE;
        _25006 = NOVALUE;

        /** 		write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_50line_map_47728);
        _25007 = (int)*(((s1_ptr)_2)->base + _tx_47851);
        _2 = (int)SEQ_PTR(_50covered_files_47723);
        _25008 = (int)*(((s1_ptr)_2)->base + _tx_47851);
        if (IS_SEQUENCE(108) && IS_ATOM(_25008)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25008)) {
            Prepend(&_25009, _25008, 108);
        }
        else {
            Concat((object_ptr)&_25009, 108, _25008);
        }
        _25008 = NOVALUE;
        Ref(_25007);
        _50write_map(_25007, _25009);
        _25007 = NOVALUE;
        _25009 = NOVALUE;

        /** 	end for*/
        _tx_47851 = _tx_47851 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** 	db_close()*/
    _49db_close();

    /** 	routine_map = {}*/
    RefDS(_21815);
    DeRef(_50routine_map_47729);
    _50routine_map_47729 = _21815;

    /** 	line_map    = {}*/
    RefDS(_21815);
    DeRef(_50line_map_47728);
    _50line_map_47728 = _21815;

    /** 	return 1*/
    return 1;
    ;
}


void _50read_coverage_db()
{
    int _tables_47862 = NOVALUE;
    int _name_47868 = NOVALUE;
    int _fx_47872 = NOVALUE;
    int _the_map_47879 = NOVALUE;
    int _31377 = NOVALUE;
    int _25025 = NOVALUE;
    int _25024 = NOVALUE;
    int _25023 = NOVALUE;
    int _25019 = NOVALUE;
    int _25018 = NOVALUE;
    int _25017 = NOVALUE;
    int _25013 = NOVALUE;
    int _25012 = NOVALUE;
    int _25011 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tables = db_table_list()*/
    _0 = _tables_47862;
    _tables_47862 = _49db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_47862)){
            _25011 = SEQ_PTR(_tables_47862)->length;
    }
    else {
        _25011 = 1;
    }
    {
        int _i_47866;
        _i_47866 = 1;
L1: 
        if (_i_47866 > _25011){
            goto L2; // [13] 159
        }

        /** 		sequence name = tables[i][2..$]*/
        _2 = (int)SEQ_PTR(_tables_47862);
        _25012 = (int)*(((s1_ptr)_2)->base + _i_47866);
        if (IS_SEQUENCE(_25012)){
                _25013 = SEQ_PTR(_25012)->length;
        }
        else {
            _25013 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_47868;
        RHS_Slice(_25012, 2, _25013);
        _25012 = NOVALUE;

        /** 		integer fx = find( name, covered_files )*/
        _fx_47872 = find_from(_name_47868, _50covered_files_47723, 1);

        /** 		if not fx then*/
        if (_fx_47872 != 0)
        goto L3; // [45] 55

        /** 			continue*/
        DeRefDS(_name_47868);
        _name_47868 = NOVALUE;
        DeRef(_the_map_47879);
        _the_map_47879 = NOVALUE;
        goto L4; // [52] 154
L3: 

        /** 		db_select_table( tables[i] )*/
        _2 = (int)SEQ_PTR(_tables_47862);
        _25017 = (int)*(((s1_ptr)_2)->base + _i_47866);
        Ref(_25017);
        _31377 = _49db_select_table(_25017);
        _25017 = NOVALUE;
        DeRef(_31377);
        _31377 = NOVALUE;

        /** 		if tables[i][1] = 'r' then*/
        _2 = (int)SEQ_PTR(_tables_47862);
        _25018 = (int)*(((s1_ptr)_2)->base + _i_47866);
        _2 = (int)SEQ_PTR(_25018);
        _25019 = (int)*(((s1_ptr)_2)->base + 1);
        _25018 = NOVALUE;
        if (binary_op_a(NOTEQ, _25019, 114)){
            _25019 = NOVALUE;
            goto L5; // [77] 92
        }
        _25019 = NOVALUE;

        /** 			the_map = routine_map[fx]*/
        DeRef(_the_map_47879);
        _2 = (int)SEQ_PTR(_50routine_map_47729);
        _the_map_47879 = (int)*(((s1_ptr)_2)->base + _fx_47872);
        Ref(_the_map_47879);
        goto L6; // [89] 101
L5: 

        /** 			the_map = line_map[fx]*/
        DeRef(_the_map_47879);
        _2 = (int)SEQ_PTR(_50line_map_47728);
        _the_map_47879 = (int)*(((s1_ptr)_2)->base + _fx_47872);
        Ref(_the_map_47879);
L6: 

        /** 		for j = 1 to db_table_size() do*/
        RefDS(_49current_table_name_17056);
        _25023 = _49db_table_size(_49current_table_name_17056);
        {
            int _j_47888;
            _j_47888 = 1;
L7: 
            if (binary_op_a(GREATER, _j_47888, _25023)){
                goto L8; // [109] 150
            }

            /** 			map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_47888);
            RefDS(_49current_table_name_17056);
            _25024 = _49db_record_key(_j_47888, _49current_table_name_17056);
            Ref(_j_47888);
            RefDS(_49current_table_name_17056);
            _25025 = _49db_record_data(_j_47888, _49current_table_name_17056);
            Ref(_the_map_47879);
            _28put(_the_map_47879, _25024, _25025, 2, 23);
            _25024 = NOVALUE;
            _25025 = NOVALUE;

            /** 		end for*/
            _0 = _j_47888;
            if (IS_ATOM_INT(_j_47888)) {
                _j_47888 = _j_47888 + 1;
                if ((long)((unsigned long)_j_47888 +(unsigned long) HIGH_BITS) >= 0){
                    _j_47888 = NewDouble((double)_j_47888);
                }
            }
            else {
                _j_47888 = binary_op_a(PLUS, _j_47888, 1);
            }
            DeRef(_0);
            goto L7; // [145] 116
L8: 
            ;
            DeRef(_j_47888);
        }
        DeRef(_name_47868);
        _name_47868 = NOVALUE;
        DeRef(_the_map_47879);
        _the_map_47879 = NOVALUE;

        /** 	end for*/
L4: 
        _i_47866 = _i_47866 + 1;
        goto L1; // [154] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_tables_47862);
    DeRef(_25023);
    _25023 = NOVALUE;
    return;
    ;
}


void _50coverage_db(int _name_47897)
{
    int _0, _1, _2;
    

    /** 	coverage_db_name = name*/
    RefDS(_name_47897);
    DeRef(_50coverage_db_name_47725);
    _50coverage_db_name_47725 = _name_47897;

    /** end procedure*/
    DeRefDS(_name_47897);
    return;
    ;
}


int _50coverage_on()
{
    int _25026 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return file_coverage[current_file_no]*/
    _2 = (int)SEQ_PTR(_50file_coverage_47724);
    _25026 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    return _25026;
    ;
}


void _50new_covered_path(int _name_47909)
{
    int _25032 = NOVALUE;
    int _25030 = NOVALUE;
    int _0, _1, _2;
    

    /** 	covered_files = append( covered_files, name )*/
    RefDS(_name_47909);
    Append(&_50covered_files_47723, _50covered_files_47723, _name_47909);

    /** 	routine_map &= map:new()*/
    _25030 = _28new(690);
    if (IS_SEQUENCE(_50routine_map_47729) && IS_ATOM(_25030)) {
        Ref(_25030);
        Append(&_50routine_map_47729, _50routine_map_47729, _25030);
    }
    else if (IS_ATOM(_50routine_map_47729) && IS_SEQUENCE(_25030)) {
    }
    else {
        Concat((object_ptr)&_50routine_map_47729, _50routine_map_47729, _25030);
    }
    DeRef(_25030);
    _25030 = NOVALUE;

    /** 	line_map    &= map:new()*/
    _25032 = _28new(690);
    if (IS_SEQUENCE(_50line_map_47728) && IS_ATOM(_25032)) {
        Ref(_25032);
        Append(&_50line_map_47728, _50line_map_47728, _25032);
    }
    else if (IS_ATOM(_50line_map_47728) && IS_SEQUENCE(_25032)) {
    }
    else {
        Concat((object_ptr)&_50line_map_47728, _50line_map_47728, _25032);
    }
    DeRef(_25032);
    _25032 = NOVALUE;

    /** end procedure*/
    DeRefDS(_name_47909);
    return;
    ;
}


void _50add_coverage(int _cover_this_47917)
{
    int _path_47918 = NOVALUE;
    int _files_47927 = NOVALUE;
    int _subpath_47955 = NOVALUE;
    int _25067 = NOVALUE;
    int _25066 = NOVALUE;
    int _25065 = NOVALUE;
    int _25064 = NOVALUE;
    int _25063 = NOVALUE;
    int _25062 = NOVALUE;
    int _25061 = NOVALUE;
    int _25060 = NOVALUE;
    int _25059 = NOVALUE;
    int _25058 = NOVALUE;
    int _25057 = NOVALUE;
    int _25056 = NOVALUE;
    int _25054 = NOVALUE;
    int _25053 = NOVALUE;
    int _25052 = NOVALUE;
    int _25051 = NOVALUE;
    int _25050 = NOVALUE;
    int _25049 = NOVALUE;
    int _25048 = NOVALUE;
    int _25047 = NOVALUE;
    int _25045 = NOVALUE;
    int _25044 = NOVALUE;
    int _25043 = NOVALUE;
    int _25042 = NOVALUE;
    int _25041 = NOVALUE;
    int _25040 = NOVALUE;
    int _25039 = NOVALUE;
    int _25038 = NOVALUE;
    int _25035 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_47917);
    _0 = _path_47918;
    _path_47918 = _17canonical_path(_cover_this_47917, 0, 2);
    DeRef(_0);

    /** 	if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_47918);
    _25035 = _17file_type(_path_47918);
    if (binary_op_a(NOTEQ, _25035, 2)){
        DeRef(_25035);
        _25035 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25035);
    _25035 = NOVALUE;

    /** 		sequence files = dir( path  )*/
    RefDS(_path_47918);
    _0 = _files_47927;
    _files_47927 = _17dir(_path_47918);
    DeRef(_0);

    /** 		for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_47927)){
            _25038 = SEQ_PTR(_files_47927)->length;
    }
    else {
        _25038 = 1;
    }
    {
        int _i_47931;
        _i_47931 = 1;
L2: 
        if (_i_47931 > _25038){
            goto L3; // [40] 206
        }

        /** 			if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (int)SEQ_PTR(_files_47927);
        _25039 = (int)*(((s1_ptr)_2)->base + _i_47931);
        _2 = (int)SEQ_PTR(_25039);
        _25040 = (int)*(((s1_ptr)_2)->base + 2);
        _25039 = NOVALUE;
        _25041 = find_from(100, _25040, 1);
        _25040 = NOVALUE;
        if (_25041 == 0)
        {
            _25041 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25041 = NOVALUE;
        }

        /** 				if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_files_47927);
        _25042 = (int)*(((s1_ptr)_2)->base + _i_47931);
        _2 = (int)SEQ_PTR(_25042);
        _25043 = (int)*(((s1_ptr)_2)->base + 1);
        _25042 = NOVALUE;
        RefDS(_22893);
        RefDS(_22894);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _22894;
        ((int *)_2)[2] = _22893;
        _25044 = MAKE_SEQ(_1);
        _25045 = find_from(_25043, _25044, 1);
        _25043 = NOVALUE;
        DeRefDS(_25044);
        _25044 = NOVALUE;
        if (_25045 != 0)
        goto L5; // [88] 199
        _25045 = NOVALUE;

        /** 					add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (int)SEQ_PTR(_files_47927);
        _25047 = (int)*(((s1_ptr)_2)->base + _i_47931);
        _2 = (int)SEQ_PTR(_25047);
        _25048 = (int)*(((s1_ptr)_2)->base + 1);
        _25047 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25048;
            concat_list[1] = 47;
            concat_list[2] = _cover_this_47917;
            Concat_N((object_ptr)&_25049, concat_list, 3);
        }
        _25048 = NOVALUE;
        _50add_coverage(_25049);
        _25049 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** 			elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (int)SEQ_PTR(_files_47927);
        _25050 = (int)*(((s1_ptr)_2)->base + _i_47931);
        _2 = (int)SEQ_PTR(_25050);
        _25051 = (int)*(((s1_ptr)_2)->base + 1);
        _25050 = NOVALUE;
        Ref(_50eu_file_47903);
        Ref(_25051);
        _25052 = _51has_match(_50eu_file_47903, _25051, 1, 0);
        _25051 = NOVALUE;
        if (_25052 == 0) {
            DeRef(_25052);
            _25052 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25052) && DBL_PTR(_25052)->dbl == 0.0){
                DeRef(_25052);
                _25052 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25052);
            _25052 = NOVALUE;
        }
        DeRef(_25052);
        _25052 = NOVALUE;

        /** 				sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_47927);
        _25053 = (int)*(((s1_ptr)_2)->base + _i_47931);
        _2 = (int)SEQ_PTR(_25053);
        _25054 = (int)*(((s1_ptr)_2)->base + 1);
        _25053 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25054;
            concat_list[1] = 47;
            concat_list[2] = _path_47918;
            Concat_N((object_ptr)&_subpath_47955, concat_list, 3);
        }
        _25054 = NOVALUE;

        /** 				if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25056 = find_from(_subpath_47955, _50covered_files_47723, 1);
        _25057 = (_25056 == 0);
        _25056 = NOVALUE;
        if (_25057 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_47955);
        _25059 = _50excluded(_subpath_47955);
        if (IS_ATOM_INT(_25059)) {
            _25060 = (_25059 == 0);
        }
        else {
            _25060 = unary_op(NOT, _25059);
        }
        DeRef(_25059);
        _25059 = NOVALUE;
        if (_25060 == 0) {
            DeRef(_25060);
            _25060 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25060) && DBL_PTR(_25060)->dbl == 0.0){
                DeRef(_25060);
                _25060 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25060);
            _25060 = NOVALUE;
        }
        DeRef(_25060);
        _25060 = NOVALUE;

        /** 					new_covered_path( subpath )*/
        RefDS(_subpath_47955);
        _50new_covered_path(_subpath_47955);
L7: 
L6: 
        DeRef(_subpath_47955);
        _subpath_47955 = NOVALUE;
L5: 

        /** 		end for*/
        _i_47931 = _i_47931 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_47927);
    _files_47927 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** 	elsif regex:has_match( eu_file, path ) and*/
    Ref(_50eu_file_47903);
    RefDS(_path_47918);
    _25061 = _51has_match(_50eu_file_47903, _path_47918, 1, 0);
    if (IS_ATOM_INT(_25061)) {
        if (_25061 == 0) {
            DeRef(_25062);
            _25062 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25061)->dbl == 0.0) {
            DeRef(_25062);
            _25062 = 0;
            goto L9; // [222] 240
        }
    }
    _25063 = find_from(_path_47918, _50covered_files_47723, 1);
    _25064 = (_25063 == 0);
    _25063 = NOVALUE;
    DeRef(_25062);
    _25062 = (_25064 != 0);
L9: 
    if (_25062 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_47918);
    _25066 = _50excluded(_path_47918);
    if (IS_ATOM_INT(_25066)) {
        _25067 = (_25066 == 0);
    }
    else {
        _25067 = unary_op(NOT, _25066);
    }
    DeRef(_25066);
    _25066 = NOVALUE;
    if (_25067 == 0) {
        DeRef(_25067);
        _25067 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25067) && DBL_PTR(_25067)->dbl == 0.0){
            DeRef(_25067);
            _25067 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25067);
        _25067 = NOVALUE;
    }
    DeRef(_25067);
    _25067 = NOVALUE;

    /** 		new_covered_path( path )*/
    RefDS(_path_47918);
    _50new_covered_path(_path_47918);
LA: 
L8: 

    /** end procedure*/
    DeRefDS(_cover_this_47917);
    DeRef(_path_47918);
    DeRef(_25057);
    _25057 = NOVALUE;
    DeRef(_25061);
    _25061 = NOVALUE;
    DeRef(_25064);
    _25064 = NOVALUE;
    return;
    ;
}


int _50excluded(int _file_47979)
{
    int _25070 = NOVALUE;
    int _25069 = NOVALUE;
    int _25068 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_50exclusion_patterns_47727)){
            _25068 = SEQ_PTR(_50exclusion_patterns_47727)->length;
    }
    else {
        _25068 = 1;
    }
    {
        int _i_47981;
        _i_47981 = 1;
L1: 
        if (_i_47981 > _25068){
            goto L2; // [10] 49
        }

        /** 		if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (int)SEQ_PTR(_50exclusion_patterns_47727);
        _25069 = (int)*(((s1_ptr)_2)->base + _i_47981);
        Ref(_25069);
        RefDS(_file_47979);
        _25070 = _51has_match(_25069, _file_47979, 1, 0);
        _25069 = NOVALUE;
        if (_25070 == 0) {
            DeRef(_25070);
            _25070 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25070) && DBL_PTR(_25070)->dbl == 0.0){
                DeRef(_25070);
                _25070 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25070);
            _25070 = NOVALUE;
        }
        DeRef(_25070);
        _25070 = NOVALUE;

        /** 			return 1*/
        DeRefDS(_file_47979);
        return 1;
L3: 

        /** 	end for*/
        _i_47981 = _i_47981 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_47979);
    return 0;
    ;
}


void _50coverage_exclude(int _patterns_47988)
{
    int _ex_47993 = NOVALUE;
    int _fx_48000 = NOVALUE;
    int _25088 = NOVALUE;
    int _25087 = NOVALUE;
    int _25086 = NOVALUE;
    int _25085 = NOVALUE;
    int _25079 = NOVALUE;
    int _25078 = NOVALUE;
    int _25076 = NOVALUE;
    int _25074 = NOVALUE;
    int _25072 = NOVALUE;
    int _25071 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_47988)){
            _25071 = SEQ_PTR(_patterns_47988)->length;
    }
    else {
        _25071 = 1;
    }
    {
        int _i_47990;
        _i_47990 = 1;
L1: 
        if (_i_47990 > _25071){
            goto L2; // [8] 161
        }

        /** 		regex ex = regex:new( patterns[i] )*/
        _2 = (int)SEQ_PTR(_patterns_47988);
        _25072 = (int)*(((s1_ptr)_2)->base + _i_47990);
        Ref(_25072);
        _0 = _ex_47993;
        _ex_47993 = _51new(_25072, 0);
        DeRef(_0);
        _25072 = NOVALUE;

        /** 		if regex( ex ) then*/
        Ref(_ex_47993);
        _25074 = _51regex(_ex_47993);
        if (_25074 == 0) {
            DeRef(_25074);
            _25074 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25074) && DBL_PTR(_25074)->dbl == 0.0){
                DeRef(_25074);
                _25074 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25074);
            _25074 = NOVALUE;
        }
        DeRef(_25074);
        _25074 = NOVALUE;

        /** 			exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_47993);
        Append(&_50exclusion_patterns_47727, _50exclusion_patterns_47727, _ex_47993);

        /** 			integer fx = 1*/
        _fx_48000 = 1;

        /** 			while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_50covered_files_47723)){
                _25076 = SEQ_PTR(_50covered_files_47723)->length;
        }
        else {
            _25076 = 1;
        }
        if (_fx_48000 > _25076)
        goto L5; // [58] 122

        /** 				if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (int)SEQ_PTR(_50covered_files_47723);
        _25078 = (int)*(((s1_ptr)_2)->base + _fx_48000);
        Ref(_ex_47993);
        Ref(_25078);
        _25079 = _51has_match(_ex_47993, _25078, 1, 0);
        _25078 = NOVALUE;
        if (_25079 == 0) {
            DeRef(_25079);
            _25079 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25079) && DBL_PTR(_25079)->dbl == 0.0){
                DeRef(_25079);
                _25079 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25079);
            _25079 = NOVALUE;
        }
        DeRef(_25079);
        _25079 = NOVALUE;

        /** 					covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50covered_files_47723);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            int stop = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50covered_files_47723), start, &_50covered_files_47723 );
                }
                else Tail(SEQ_PTR(_50covered_files_47723), stop+1, &_50covered_files_47723);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50covered_files_47723), start, &_50covered_files_47723);
            }
            else {
                assign_slice_seq = &assign_space;
                _50covered_files_47723 = Remove_elements(start, stop, (SEQ_PTR(_50covered_files_47723)->ref == 1));
            }
        }

        /** 					routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50routine_map_47729);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            int stop = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50routine_map_47729), start, &_50routine_map_47729 );
                }
                else Tail(SEQ_PTR(_50routine_map_47729), stop+1, &_50routine_map_47729);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50routine_map_47729), start, &_50routine_map_47729);
            }
            else {
                assign_slice_seq = &assign_space;
                _50routine_map_47729 = Remove_elements(start, stop, (SEQ_PTR(_50routine_map_47729)->ref == 1));
            }
        }

        /** 					line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_50line_map_47728);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            int stop = (IS_ATOM_INT(_fx_48000)) ? _fx_48000 : (long)(DBL_PTR(_fx_48000)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_50line_map_47728), start, &_50line_map_47728 );
                }
                else Tail(SEQ_PTR(_50line_map_47728), stop+1, &_50line_map_47728);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_50line_map_47728), start, &_50line_map_47728);
            }
            else {
                assign_slice_seq = &assign_space;
                _50line_map_47728 = Remove_elements(start, stop, (SEQ_PTR(_50line_map_47728)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** 					fx += 1*/
        _fx_48000 = _fx_48000 + 1;

        /** 			end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 152
L3: 

        /** 			printf( 2,"%s\n", { GetMsgText( 339, 1, {patterns[i]}) } )*/
        _2 = (int)SEQ_PTR(_patterns_47988);
        _25085 = (int)*(((s1_ptr)_2)->base + _i_47990);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25085);
        *((int *)(_2+4)) = _25085;
        _25086 = MAKE_SEQ(_1);
        _25085 = NOVALUE;
        _25087 = _45GetMsgText(339, 1, _25086);
        _25086 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _25087;
        _25088 = MAKE_SEQ(_1);
        _25087 = NOVALUE;
        EPrintf(2, _25084, _25088);
        DeRefDS(_25088);
        _25088 = NOVALUE;
L7: 
        DeRef(_ex_47993);
        _ex_47993 = NOVALUE;

        /** 	end for*/
        _i_47990 = _i_47990 + 1;
        goto L1; // [156] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_patterns_47988);
    return;
    ;
}


void _50new_coverage_db()
{
    int _0, _1, _2;
    

    /** 	coverage_erase = 1*/
    _50coverage_erase_47726 = 1;

    /** end procedure*/
    return;
    ;
}


void _50include_line(int _line_number_48023)
{
    int _25089 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line_number_48023)) {
        _1 = (long)(DBL_PTR(_line_number_48023)->dbl);
        DeRefDS(_line_number_48023);
        _line_number_48023 = _1;
    }

    /** 	if coverage_on() then*/
    _25089 = _50coverage_on();
    if (_25089 == 0) {
        DeRef(_25089);
        _25089 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25089) && DBL_PTR(_25089)->dbl == 0.0){
            DeRef(_25089);
            _25089 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25089);
        _25089 = NOVALUE;
    }
    DeRef(_25089);
    _25089 = NOVALUE;

    /** 		emit_op( COVERAGE_LINE )*/
    _41emit_op(210);

    /** 		emit_addr( gline_number )*/
    _41emit_addr(_35gline_number_15973);

    /** 		included_lines &= line_number*/
    Append(&_50included_lines_47730, _50included_lines_47730, _line_number_48023);
L1: 

    /** end procedure*/
    return;
    ;
}


void _50include_routine()
{
    int _file_no_48039 = NOVALUE;
    int _25096 = NOVALUE;
    int _25095 = NOVALUE;
    int _25094 = NOVALUE;
    int _25092 = NOVALUE;
    int _25091 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if coverage_on() then*/
    _25091 = _50coverage_on();
    if (_25091 == 0) {
        DeRef(_25091);
        _25091 = NOVALUE;
        goto L1; // [6] 71
    }
    else {
        if (!IS_ATOM_INT(_25091) && DBL_PTR(_25091)->dbl == 0.0){
            DeRef(_25091);
            _25091 = NOVALUE;
            goto L1; // [6] 71
        }
        DeRef(_25091);
        _25091 = NOVALUE;
    }
    DeRef(_25091);
    _25091 = NOVALUE;

    /** 		emit_op( COVERAGE_ROUTINE )*/
    _41emit_op(211);

    /** 		emit_addr( CurrentSub )*/
    _41emit_addr(_35CurrentSub_15976);

    /** 		integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _25092 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_25092);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _file_no_48039 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _file_no_48039 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_file_no_48039)){
        _file_no_48039 = (long)DBL_PTR(_file_no_48039)->dbl;
    }
    _25092 = NOVALUE;

    /** 		map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (int)SEQ_PTR(_50file_coverage_47724);
    _25094 = (int)*(((s1_ptr)_2)->base + _file_no_48039);
    _2 = (int)SEQ_PTR(_50routine_map_47729);
    _25095 = (int)*(((s1_ptr)_2)->base + _25094);
    _25096 = _53sym_name(_35CurrentSub_15976);
    Ref(_25095);
    _28put(_25095, _25096, 0, 2, 23);
    _25095 = NOVALUE;
    _25096 = NOVALUE;
L1: 

    /** end procedure*/
    _25094 = NOVALUE;
    return;
    ;
}


void _50process_lines()
{
    int _sline_48067 = NOVALUE;
    int _file_48071 = NOVALUE;
    int _line_48081 = NOVALUE;
    int _25114 = NOVALUE;
    int _25112 = NOVALUE;
    int _25111 = NOVALUE;
    int _25110 = NOVALUE;
    int _25109 = NOVALUE;
    int _25108 = NOVALUE;
    int _25106 = NOVALUE;
    int _25104 = NOVALUE;
    int _25103 = NOVALUE;
    int _25101 = NOVALUE;
    int _25100 = NOVALUE;
    int _25099 = NOVALUE;
    int _25097 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( included_lines ) then*/
    if (IS_SEQUENCE(_50included_lines_47730)){
            _25097 = SEQ_PTR(_50included_lines_47730)->length;
    }
    else {
        _25097 = 1;
    }
    if (_25097 != 0)
    goto L1; // [8] 17
    _25097 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_35slist_16058)){
            _25099 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _25099 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16058);
    _25100 = (int)*(((s1_ptr)_2)->base + _25099);
    _25101 = IS_ATOM(_25100);
    _25100 = NOVALUE;
    if (_25101 == 0)
    {
        _25101 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25101 = NOVALUE;
    }

    /** 		slist = s_expand( slist )*/
    RefDS(_35slist_16058);
    _0 = _61s_expand(_35slist_16058);
    DeRefDS(_35slist_16058);
    _35slist_16058 = _0;
L2: 

    /** 	for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_50included_lines_47730)){
            _25103 = SEQ_PTR(_50included_lines_47730)->length;
    }
    else {
        _25103 = 1;
    }
    {
        int _i_48065;
        _i_48065 = 1;
L3: 
        if (_i_48065 > _25103){
            goto L4; // [52] 159
        }

        /** 		sequence sline = slist[included_lines[i]]*/
        _2 = (int)SEQ_PTR(_50included_lines_47730);
        _25104 = (int)*(((s1_ptr)_2)->base + _i_48065);
        DeRef(_sline_48067);
        _2 = (int)SEQ_PTR(_35slist_16058);
        _sline_48067 = (int)*(((s1_ptr)_2)->base + _25104);
        Ref(_sline_48067);

        /** 		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_sline_48067);
        _25106 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_50file_coverage_47724);
        if (!IS_ATOM_INT(_25106)){
            _file_48071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25106)->dbl));
        }
        else{
            _file_48071 = (int)*(((s1_ptr)_2)->base + _25106);
        }

        /** 		if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_48071 == 0) {
            _25108 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_50line_map_47728)){
                _25109 = SEQ_PTR(_50line_map_47728)->length;
        }
        else {
            _25109 = 1;
        }
        _25110 = (_file_48071 <= _25109);
        _25109 = NOVALUE;
        _25108 = (_25110 != 0);
L5: 
        if (_25108 == 0) {
            goto L6; // [108] 148
        }
        _2 = (int)SEQ_PTR(_50line_map_47728);
        _25112 = (int)*(((s1_ptr)_2)->base + _file_48071);
        if (_25112 == 0) {
            _25112 = NOVALUE;
            goto L6; // [119] 148
        }
        else {
            if (!IS_ATOM_INT(_25112) && DBL_PTR(_25112)->dbl == 0.0){
                _25112 = NOVALUE;
                goto L6; // [119] 148
            }
            _25112 = NOVALUE;
        }
        _25112 = NOVALUE;

        /** 			integer line = sline[LINE]*/
        _2 = (int)SEQ_PTR(_sline_48067);
        _line_48081 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_48081))
        _line_48081 = (long)DBL_PTR(_line_48081)->dbl;

        /** 			map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (int)SEQ_PTR(_50line_map_47728);
        _25114 = (int)*(((s1_ptr)_2)->base + _file_48071);
        Ref(_25114);
        _28put(_25114, _line_48081, 0, 2, 23);
        _25114 = NOVALUE;
L6: 
        DeRef(_sline_48067);
        _sline_48067 = NOVALUE;

        /** 	end for*/
        _i_48065 = _i_48065 + 1;
        goto L3; // [154] 59
L4: 
        ;
    }

    /** end procedure*/
    _25104 = NOVALUE;
    _25106 = NOVALUE;
    DeRef(_25110);
    _25110 = NOVALUE;
    return;
    ;
}


void _50cover_line(int _gline_number_48087)
{
    int _sline_48097 = NOVALUE;
    int _file_48100 = NOVALUE;
    int _line_48105 = NOVALUE;
    int _25123 = NOVALUE;
    int _25120 = NOVALUE;
    int _25117 = NOVALUE;
    int _25116 = NOVALUE;
    int _25115 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_48087)) {
        _1 = (long)(DBL_PTR(_gline_number_48087)->dbl);
        DeRefDS(_gline_number_48087);
        _gline_number_48087 = _1;
    }

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_35slist_16058)){
            _25115 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _25115 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16058);
    _25116 = (int)*(((s1_ptr)_2)->base + _25115);
    _25117 = IS_ATOM(_25116);
    _25116 = NOVALUE;
    if (_25117 == 0)
    {
        _25117 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25117 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_35slist_16058);
    _0 = _61s_expand(_35slist_16058);
    DeRefDS(_35slist_16058);
    _35slist_16058 = _0;
L1: 

    /** 	sequence sline = slist[gline_number]*/
    DeRef(_sline_48097);
    _2 = (int)SEQ_PTR(_35slist_16058);
    _sline_48097 = (int)*(((s1_ptr)_2)->base + _gline_number_48087);
    Ref(_sline_48097);

    /** 	integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (int)SEQ_PTR(_sline_48097);
    _25120 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_50file_coverage_47724);
    if (!IS_ATOM_INT(_25120)){
        _file_48100 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25120)->dbl));
    }
    else{
        _file_48100 = (int)*(((s1_ptr)_2)->base + _25120);
    }

    /** 	if file then*/
    if (_file_48100 == 0)
    {
        goto L2; // [57] 86
    }
    else{
    }

    /** 		integer line = sline[LINE]*/
    _2 = (int)SEQ_PTR(_sline_48097);
    _line_48105 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_48105))
    _line_48105 = (long)DBL_PTR(_line_48105)->dbl;

    /** 		map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_50line_map_47728);
    _25123 = (int)*(((s1_ptr)_2)->base + _file_48100);
    Ref(_25123);
    _28put(_25123, _line_48105, 1, 2, 23);
    _25123 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_sline_48097);
    _25120 = NOVALUE;
    return;
    ;
}


void _50cover_routine(int _sub_48112)
{
    int _file_no_48113 = NOVALUE;
    int _25128 = NOVALUE;
    int _25127 = NOVALUE;
    int _25126 = NOVALUE;
    int _25124 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48112)) {
        _1 = (long)(DBL_PTR(_sub_48112)->dbl);
        DeRefDS(_sub_48112);
        _sub_48112 = _1;
    }

    /** 	integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _25124 = (int)*(((s1_ptr)_2)->base + _sub_48112);
    _2 = (int)SEQ_PTR(_25124);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _file_no_48113 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _file_no_48113 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_file_no_48113)){
        _file_no_48113 = (long)DBL_PTR(_file_no_48113)->dbl;
    }
    _25124 = NOVALUE;

    /** 	map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_50file_coverage_47724);
    _25126 = (int)*(((s1_ptr)_2)->base + _file_no_48113);
    _2 = (int)SEQ_PTR(_50routine_map_47729);
    _25127 = (int)*(((s1_ptr)_2)->base + _25126);
    _25128 = _53sym_name(_sub_48112);
    Ref(_25127);
    _28put(_25127, _25128, 1, 2, 23);
    _25127 = NOVALUE;
    _25128 = NOVALUE;

    /** end procedure*/
    _25126 = NOVALUE;
    return;
    ;
}


int _50has_coverage()
{
    int _25129 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length( covered_files )*/
    if (IS_SEQUENCE(_50covered_files_47723)){
            _25129 = SEQ_PTR(_50covered_files_47723)->length;
    }
    else {
        _25129 = 1;
    }
    return _25129;
    ;
}



// 0xED21FB0A
