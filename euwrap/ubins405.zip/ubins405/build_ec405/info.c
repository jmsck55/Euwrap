// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _32version_major()
{
    int _6310 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MAJ_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6310 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_6310);
    return _6310;
    ;
}


int _32version_minor()
{
    int _6311 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[MIN_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6311 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_6311);
    return _6311;
    ;
}


int _32version_patch()
{
    int _6312 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return version_info[PAT_VER]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6312 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_6312);
    return _6312;
    ;
}


int _32version_node(int _full_11334)
{
    int _6319 = NOVALUE;
    int _6318 = NOVALUE;
    int _6317 = NOVALUE;
    int _6316 = NOVALUE;
    int _6315 = NOVALUE;
    int _6314 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or length(version_info[NODE]) < 12 then*/
    if (0 != 0) {
        goto L1; // [5] 27
    }
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6314 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6314)){
            _6315 = SEQ_PTR(_6314)->length;
    }
    else {
        _6315 = 1;
    }
    _6314 = NOVALUE;
    _6316 = (_6315 < 12);
    _6315 = NOVALUE;
    if (_6316 == 0)
    {
        DeRef(_6316);
        _6316 = NOVALUE;
        goto L2; // [23] 40
    }
    else{
        DeRef(_6316);
        _6316 = NOVALUE;
    }
L1: 

    /** 		return version_info[NODE]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6317 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_6317);
    _6314 = NOVALUE;
    return _6317;
L2: 

    /** 	return version_info[NODE][1..12]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6318 = (int)*(((s1_ptr)_2)->base + 5);
    rhs_slice_target = (object_ptr)&_6319;
    RHS_Slice(_6318, 1, 12);
    _6318 = NOVALUE;
    _6314 = NOVALUE;
    _6317 = NOVALUE;
    return _6319;
    ;
}


int _32version_date(int _full_11348)
{
    int _6328 = NOVALUE;
    int _6327 = NOVALUE;
    int _6326 = NOVALUE;
    int _6325 = NOVALUE;
    int _6324 = NOVALUE;
    int _6323 = NOVALUE;
    int _6321 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental or length(version_info[REVISION_DATE]) < 10 then*/
    if (_full_11348 != 0) {
        _6321 = 1;
        goto L1; // [5] 15
    }
    _6321 = (_32is_developmental_11298 != 0);
L1: 
    if (_6321 != 0) {
        goto L2; // [15] 37
    }
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6323 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6323)){
            _6324 = SEQ_PTR(_6323)->length;
    }
    else {
        _6324 = 1;
    }
    _6323 = NOVALUE;
    _6325 = (_6324 < 10);
    _6324 = NOVALUE;
    if (_6325 == 0)
    {
        DeRef(_6325);
        _6325 = NOVALUE;
        goto L3; // [33] 50
    }
    else{
        DeRef(_6325);
        _6325 = NOVALUE;
    }
L2: 

    /** 		return version_info[REVISION_DATE]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6326 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_6326);
    _6323 = NOVALUE;
    return _6326;
L3: 

    /** 	return version_info[REVISION_DATE][1..10]*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6327 = (int)*(((s1_ptr)_2)->base + 7);
    rhs_slice_target = (object_ptr)&_6328;
    RHS_Slice(_6327, 1, 10);
    _6327 = NOVALUE;
    _6323 = NOVALUE;
    _6326 = NOVALUE;
    return _6328;
    ;
}


int _32version_string(int _full_11363)
{
    int _version_revision_inlined_version_revision_at_41_11372 = NOVALUE;
    int _6348 = NOVALUE;
    int _6347 = NOVALUE;
    int _6346 = NOVALUE;
    int _6345 = NOVALUE;
    int _6344 = NOVALUE;
    int _6343 = NOVALUE;
    int _6342 = NOVALUE;
    int _6341 = NOVALUE;
    int _6339 = NOVALUE;
    int _6338 = NOVALUE;
    int _6337 = NOVALUE;
    int _6336 = NOVALUE;
    int _6335 = NOVALUE;
    int _6334 = NOVALUE;
    int _6333 = NOVALUE;
    int _6332 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if full or is_developmental then*/
    if (0 != 0) {
        goto L1; // [5] 16
    }
    if (_32is_developmental_11298 == 0)
    {
        goto L2; // [12] 80
    }
    else{
    }
L1: 

    /** 		return sprintf("%d.%d.%d %s (%d:%s, %s)", {*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6332 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6333 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6334 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6335 = (int)*(((s1_ptr)_2)->base + 4);

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_41_11372);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _version_revision_inlined_version_revision_at_41_11372 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_41_11372);
    _6336 = _32version_node(0);
    _6337 = _32version_date(_full_11363);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6332);
    *((int *)(_2+4)) = _6332;
    Ref(_6333);
    *((int *)(_2+8)) = _6333;
    Ref(_6334);
    *((int *)(_2+12)) = _6334;
    Ref(_6335);
    *((int *)(_2+16)) = _6335;
    Ref(_version_revision_inlined_version_revision_at_41_11372);
    *((int *)(_2+20)) = _version_revision_inlined_version_revision_at_41_11372;
    *((int *)(_2+24)) = _6336;
    *((int *)(_2+28)) = _6337;
    _6338 = MAKE_SEQ(_1);
    _6337 = NOVALUE;
    _6336 = NOVALUE;
    _6335 = NOVALUE;
    _6334 = NOVALUE;
    _6333 = NOVALUE;
    _6332 = NOVALUE;
    _6339 = EPrintf(-9999999, _6331, _6338);
    DeRefDS(_6338);
    _6338 = NOVALUE;
    return _6339;
    goto L3; // [77] 132
L2: 

    /** 		return sprintf("%d.%d.%d %s (%s, %s)", {*/
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6341 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6342 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6343 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _6344 = (int)*(((s1_ptr)_2)->base + 4);
    _6345 = _32version_node(0);
    _6346 = _32version_date(_full_11363);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_6341);
    *((int *)(_2+4)) = _6341;
    Ref(_6342);
    *((int *)(_2+8)) = _6342;
    Ref(_6343);
    *((int *)(_2+12)) = _6343;
    Ref(_6344);
    *((int *)(_2+16)) = _6344;
    *((int *)(_2+20)) = _6345;
    *((int *)(_2+24)) = _6346;
    _6347 = MAKE_SEQ(_1);
    _6346 = NOVALUE;
    _6345 = NOVALUE;
    _6344 = NOVALUE;
    _6343 = NOVALUE;
    _6342 = NOVALUE;
    _6341 = NOVALUE;
    _6348 = EPrintf(-9999999, _6340, _6347);
    DeRefDS(_6347);
    _6347 = NOVALUE;
    DeRef(_6339);
    _6339 = NOVALUE;
    return _6348;
L3: 
    ;
}


int _32euphoria_copyright()
{
    int _version_string_long_1__tmp_at2_11406 = NOVALUE;
    int _version_string_long_inlined_version_string_long_at_2_11405 = NOVALUE;
    int _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404 = NOVALUE;
    int _6358 = NOVALUE;
    int _6356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/

    /** 	return version_string(full) & " for " & platform_name()*/
    _0 = _version_string_long_1__tmp_at2_11406;
    _version_string_long_1__tmp_at2_11406 = _32version_string(0);
    DeRef(_0);

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_6296);
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404 = _6296;
    {
        int concat_list[3];

        concat_list[0] = _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404;
        concat_list[1] = _6353;
        concat_list[2] = _version_string_long_1__tmp_at2_11406;
        Concat_N((object_ptr)&_version_string_long_inlined_version_string_long_at_2_11405, concat_list, 3);
    }
    DeRefi(_platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404);
    _platform_name_inlined_platform_name_at_8_inlined_version_string_long_at_2_11404 = NOVALUE;
    DeRef(_version_string_long_1__tmp_at2_11406);
    _version_string_long_1__tmp_at2_11406 = NOVALUE;
    Concat((object_ptr)&_6356, _6355, _version_string_long_inlined_version_string_long_at_2_11405);
    RefDS(_6357);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6356;
    ((int *)_2)[2] = _6357;
    _6358 = MAKE_SEQ(_1);
    _6356 = NOVALUE;
    return _6358;
    ;
}


int _32all_copyrights()
{
    int _pcre_copyright_inlined_pcre_copyright_at_5_11419 = NOVALUE;
    int _6363 = NOVALUE;
    int _6362 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {*/
    _6362 = _32euphoria_copyright();

    /** 	return {*/
    RefDS(_6360);
    RefDS(_6359);
    DeRef(_pcre_copyright_inlined_pcre_copyright_at_5_11419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6359;
    ((int *)_2)[2] = _6360;
    _pcre_copyright_inlined_pcre_copyright_at_5_11419 = MAKE_SEQ(_1);
    RefDS(_pcre_copyright_inlined_pcre_copyright_at_5_11419);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _6362;
    ((int *)_2)[2] = _pcre_copyright_inlined_pcre_copyright_at_5_11419;
    _6363 = MAKE_SEQ(_1);
    _6362 = NOVALUE;
    return _6363;
    ;
}



// 0xC6FDECE8
