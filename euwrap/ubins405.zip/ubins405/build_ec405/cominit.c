// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _43add_options(int _new_options_48587)
{
    int _0, _1, _2;
    

    /** 	options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 15;
        if (insert_pos <= 0) {
            Concat(&_43options_48583,_new_options_48587,_43options_48583);
        }
        else if (insert_pos > SEQ_PTR(_43options_48583)->length){
            Concat(&_43options_48583,_43options_48583,_new_options_48587);
        }
        else if (IS_SEQUENCE(_new_options_48587)) {
            if( _43options_48583 != _43options_48583 || SEQ_PTR( _43options_48583 )->ref != 1 ){
                DeRef( _43options_48583 );
                RefDS( _43options_48583 );
            }
            assign_space = Add_internal_space( _43options_48583, insert_pos,((s1_ptr)SEQ_PTR(_new_options_48587))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_48587), _43options_48583 == _43options_48583 );
            _43options_48583 = MAKE_SEQ( assign_space );
        }
        else {
            if( _43options_48583 != _43options_48583 && SEQ_PTR( _43options_48583 )->ref != 1 ){
                _43options_48583 = Insert( _43options_48583, _new_options_48587, insert_pos);
            }
            else {
                DeRef( _43options_48583 );
                RefDS( _43options_48583 );
                _43options_48583 = Insert( _43options_48583, _new_options_48587, insert_pos);
            }
        }
    }

    /** end procedure*/
    DeRefDS(_new_options_48587);
    return;
    ;
}


int _43get_options()
{
    int _0, _1, _2;
    

    /** 	return options*/
    RefDS(_43options_48583);
    return _43options_48583;
    ;
}


int _43get_common_options()
{
    int _0, _1, _2;
    

    /** 	return COMMON_OPTIONS*/
    RefDS(_43COMMON_OPTIONS_48481);
    return _43COMMON_OPTIONS_48481;
    ;
}


int _43get_switches()
{
    int _0, _1, _2;
    

    /** 	return switches*/
    RefDS(_43switches_48480);
    return _43switches_48480;
    ;
}


void _43show_copyrights()
{
    int _notices_48597 = NOVALUE;
    int _25360 = NOVALUE;
    int _25359 = NOVALUE;
    int _25357 = NOVALUE;
    int _25356 = NOVALUE;
    int _25355 = NOVALUE;
    int _25354 = NOVALUE;
    int _25352 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence notices = all_copyrights()*/
    _0 = _notices_48597;
    _notices_48597 = _32all_copyrights();
    DeRef(_0);

    /** 	for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_48597)){
            _25352 = SEQ_PTR(_notices_48597)->length;
    }
    else {
        _25352 = 1;
    }
    {
        int _i_48601;
        _i_48601 = 1;
L1: 
        if (_i_48601 > _25352){
            goto L2; // [13] 60
        }

        /** 		printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (int)SEQ_PTR(_notices_48597);
        _25354 = (int)*(((s1_ptr)_2)->base + _i_48601);
        _2 = (int)SEQ_PTR(_25354);
        _25355 = (int)*(((s1_ptr)_2)->base + 1);
        _25354 = NOVALUE;
        _2 = (int)SEQ_PTR(_notices_48597);
        _25356 = (int)*(((s1_ptr)_2)->base + _i_48601);
        _2 = (int)SEQ_PTR(_25356);
        _25357 = (int)*(((s1_ptr)_2)->base + 2);
        _25356 = NOVALUE;
        RefDS(_21967);
        Ref(_25357);
        RefDS(_25358);
        _25359 = _16match_replace(_21967, _25357, _25358, 0);
        _25357 = NOVALUE;
        Ref(_25355);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25355;
        ((int *)_2)[2] = _25359;
        _25360 = MAKE_SEQ(_1);
        _25359 = NOVALUE;
        _25355 = NOVALUE;
        EPrintf(2, _25353, _25360);
        DeRefDS(_25360);
        _25360 = NOVALUE;

        /** 	end for*/
        _i_48601 = _i_48601 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_notices_48597);
    return;
    ;
}


void _43show_banner()
{
    int _version_type_inlined_version_type_at_206_48664 = NOVALUE;
    int _version_string_short_1__tmp_at190_48662 = NOVALUE;
    int _version_string_short_inlined_version_string_short_at_190_48661 = NOVALUE;
    int _version_revision_inlined_version_revision_at_121_48643 = NOVALUE;
    int _platform_name_inlined_platform_name_at_83_48635 = NOVALUE;
    int _prod_name_48614 = NOVALUE;
    int _memory_type_48615 = NOVALUE;
    int _misc_info_48633 = NOVALUE;
    int _EuConsole_48647 = NOVALUE;
    int _25384 = NOVALUE;
    int _25383 = NOVALUE;
    int _25382 = NOVALUE;
    int _25379 = NOVALUE;
    int _25378 = NOVALUE;
    int _25374 = NOVALUE;
    int _25373 = NOVALUE;
    int _25372 = NOVALUE;
    int _25370 = NOVALUE;
    int _25368 = NOVALUE;
    int _25367 = NOVALUE;
    int _25362 = NOVALUE;
    int _25361 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if INTERPRET and not BIND then*/
    if (_35INTERPRET_15608 == 0) {
        goto L1; // [5] 31
    }
    _25362 = (_35BIND_15614 == 0);
    if (_25362 == 0)
    {
        DeRef(_25362);
        _25362 = NOVALUE;
        goto L1; // [15] 31
    }
    else{
        DeRef(_25362);
        _25362 = NOVALUE;
    }

    /** 		prod_name = GetMsgText(270,0)*/
    RefDS(_21815);
    _0 = _prod_name_48614;
    _prod_name_48614 = _45GetMsgText(270, 0, _21815);
    DeRef(_0);
    goto L2; // [28] 70
L1: 

    /** 	elsif TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [35] 51
    }
    else{
    }

    /** 		prod_name = GetMsgText(271,0)*/
    RefDS(_21815);
    _0 = _prod_name_48614;
    _prod_name_48614 = _45GetMsgText(271, 0, _21815);
    DeRef(_0);
    goto L2; // [48] 70
L3: 

    /** 	elsif BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L4; // [55] 69
    }
    else{
    }

    /** 		prod_name = GetMsgText(272,0)*/
    RefDS(_21815);
    _0 = _prod_name_48614;
    _prod_name_48614 = _45GetMsgText(272, 0, _21815);
    DeRef(_0);
L4: 
L2: 

    /** 	ifdef EU_MANAGED_MEM then*/

    /** 		memory_type = GetMsgText(274,0)*/
    RefDS(_21815);
    _0 = _memory_type_48615;
    _memory_type_48615 = _45GetMsgText(274, 0, _21815);
    DeRef(_0);

    /** 	sequence misc_info = {*/

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_6296);
    DeRefi(_platform_name_inlined_platform_name_at_83_48635);
    _platform_name_inlined_platform_name_at_83_48635 = _6296;
    _25367 = _32version_date(0);
    _25368 = _32version_node(0);
    _0 = _misc_info_48633;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_platform_name_inlined_platform_name_at_83_48635);
    *((int *)(_2+4)) = _platform_name_inlined_platform_name_at_83_48635;
    RefDS(_memory_type_48615);
    *((int *)(_2+8)) = _memory_type_48615;
    RefDS(_21815);
    *((int *)(_2+12)) = _21815;
    *((int *)(_2+16)) = _25367;
    *((int *)(_2+20)) = _25368;
    _misc_info_48633 = MAKE_SEQ(_1);
    DeRef(_0);
    _25368 = NOVALUE;
    _25367 = NOVALUE;

    /** 	if info:is_developmental then*/
    if (_32is_developmental_11298 == 0)
    {
        goto L5; // [114] 148
    }
    else{
    }

    /** 		misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25370 = 5;

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_121_48643);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _version_revision_inlined_version_revision_at_121_48643 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_121_48643);
    _25372 = _32version_node(0);
    Ref(_version_revision_inlined_version_revision_at_121_48643);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _version_revision_inlined_version_revision_at_121_48643;
    ((int *)_2)[2] = _25372;
    _25373 = MAKE_SEQ(_1);
    _25372 = NOVALUE;
    _25374 = EPrintf(-9999999, _25371, _25373);
    DeRefDS(_25373);
    _25373 = NOVALUE;
    _2 = (int)SEQ_PTR(_misc_info_48633);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _25374;
    if( _1 != _25374 ){
        DeRef(_1);
    }
    _25374 = NOVALUE;
L5: 

    /** 	object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_48647);
    _EuConsole_48647 = EGetEnv(_25375);

    /** 	if equal(EuConsole, "1") then*/
    if (_EuConsole_48647 == _25377)
    _25378 = 1;
    else if (IS_ATOM_INT(_EuConsole_48647) && IS_ATOM_INT(_25377))
    _25378 = 0;
    else
    _25378 = (compare(_EuConsole_48647, _25377) == 0);
    if (_25378 == 0)
    {
        _25378 = NOVALUE;
        goto L6; // [159] 177
    }
    else{
        _25378 = NOVALUE;
    }

    /** 		misc_info[3] = GetMsgText(275,0)*/
    RefDS(_21815);
    _25379 = _45GetMsgText(275, 0, _21815);
    _2 = (int)SEQ_PTR(_misc_info_48633);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _25379;
    if( _1 != _25379 ){
        DeRef(_1);
    }
    _25379 = NOVALUE;
    goto L7; // [174] 185
L6: 

    /** 		misc_info = remove(misc_info, 3)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_48633);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        int stop = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_48633), start, &_misc_info_48633 );
            }
            else Tail(SEQ_PTR(_misc_info_48633), stop+1, &_misc_info_48633);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_48633), start, &_misc_info_48633);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_48633 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_48633)->ref == 1));
        }
    }
L7: 

    /** 	screen_output(STDERR, sprintf("%s v%s %s\n   %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** 	return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at190_48662;
    RHS_Slice(_32version_info_11296, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_190_48661);
    _version_string_short_inlined_version_string_short_at_190_48661 = EPrintf(-9999999, _6349, _version_string_short_1__tmp_at190_48662);
    DeRef(_version_string_short_1__tmp_at190_48662);
    _version_string_short_1__tmp_at190_48662 = NOVALUE;

    /** 	return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_206_48664);
    _2 = (int)SEQ_PTR(_32version_info_11296);
    _version_type_inlined_version_type_at_206_48664 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_206_48664);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_prod_name_48614);
    *((int *)(_2+4)) = _prod_name_48614;
    RefDS(_version_string_short_inlined_version_string_short_at_190_48661);
    *((int *)(_2+8)) = _version_string_short_inlined_version_string_short_at_190_48661;
    Ref(_version_type_inlined_version_type_at_206_48664);
    *((int *)(_2+12)) = _version_type_inlined_version_type_at_206_48664;
    _25382 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25383, _25382, _misc_info_48633);
    DeRefDS(_25382);
    _25382 = NOVALUE;
    DeRef(_25382);
    _25382 = NOVALUE;
    _25384 = EPrintf(-9999999, _25381, _25383);
    DeRefDS(_25383);
    _25383 = NOVALUE;
    _44screen_output(2, _25384);
    _25384 = NOVALUE;

    /** end procedure*/
    DeRefDS(_prod_name_48614);
    DeRef(_memory_type_48615);
    DeRefDS(_misc_info_48633);
    DeRefi(_EuConsole_48647);
    return;
    ;
}


int _43find_opt(int _name_type_48676, int _opt_48677, int _opts_48678)
{
    int _o_48682 = NOVALUE;
    int _has_case_48684 = NOVALUE;
    int _25397 = NOVALUE;
    int _25396 = NOVALUE;
    int _25395 = NOVALUE;
    int _25394 = NOVALUE;
    int _25393 = NOVALUE;
    int _25392 = NOVALUE;
    int _25391 = NOVALUE;
    int _25390 = NOVALUE;
    int _25389 = NOVALUE;
    int _25387 = NOVALUE;
    int _25385 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_48678)){
            _25385 = SEQ_PTR(_opts_48678)->length;
    }
    else {
        _25385 = 1;
    }
    {
        int _i_48680;
        _i_48680 = 1;
L1: 
        if (_i_48680 > _25385){
            goto L2; // [12] 113
        }

        /** 		sequence o = opts[i]		*/
        DeRef(_o_48682);
        _2 = (int)SEQ_PTR(_opts_48678);
        _o_48682 = (int)*(((s1_ptr)_2)->base + _i_48680);
        Ref(_o_48682);

        /** 		integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (int)SEQ_PTR(_o_48682);
        _25387 = (int)*(((s1_ptr)_2)->base + 4);
        _has_case_48684 = find_from(99, _25387, 1);
        _25387 = NOVALUE;

        /** 		if has_case and equal(o[name_type], opt) then*/
        if (_has_case_48684 == 0) {
            goto L3; // [42] 67
        }
        _2 = (int)SEQ_PTR(_o_48682);
        _25390 = (int)*(((s1_ptr)_2)->base + _name_type_48676);
        if (_25390 == _opt_48677)
        _25391 = 1;
        else if (IS_ATOM_INT(_25390) && IS_ATOM_INT(_opt_48677))
        _25391 = 0;
        else
        _25391 = (compare(_25390, _opt_48677) == 0);
        _25390 = NOVALUE;
        if (_25391 == 0)
        {
            _25391 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25391 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_48677);
        DeRefDS(_opts_48678);
        return _o_48682;
        goto L4; // [64] 104
L3: 

        /** 		elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25392 = (_has_case_48684 == 0);
        if (_25392 == 0) {
            goto L5; // [72] 103
        }
        _2 = (int)SEQ_PTR(_o_48682);
        _25394 = (int)*(((s1_ptr)_2)->base + _name_type_48676);
        Ref(_25394);
        _25395 = _14lower(_25394);
        _25394 = NOVALUE;
        RefDS(_opt_48677);
        _25396 = _14lower(_opt_48677);
        if (_25395 == _25396)
        _25397 = 1;
        else if (IS_ATOM_INT(_25395) && IS_ATOM_INT(_25396))
        _25397 = 0;
        else
        _25397 = (compare(_25395, _25396) == 0);
        DeRef(_25395);
        _25395 = NOVALUE;
        DeRef(_25396);
        _25396 = NOVALUE;
        if (_25397 == 0)
        {
            _25397 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25397 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_48677);
        DeRefDS(_opts_48678);
        DeRef(_25392);
        _25392 = NOVALUE;
        return _o_48682;
L5: 
L4: 
        DeRef(_o_48682);
        _o_48682 = NOVALUE;

        /** 	end for*/
        _i_48680 = _i_48680 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** 	return {}*/
    RefDS(_21815);
    DeRefDS(_opt_48677);
    DeRefDS(_opts_48678);
    DeRef(_25392);
    _25392 = NOVALUE;
    return _21815;
    ;
}


int _43merge_parameters(int _a_48701, int _b_48702, int _opts_48703, int _dedupe_48704)
{
    int _i_48705 = NOVALUE;
    int _opt_48709 = NOVALUE;
    int _this_opt_48715 = NOVALUE;
    int _bi_48716 = NOVALUE;
    int _beginLen_48776 = NOVALUE;
    int _first_extra_48798 = NOVALUE;
    int _opt_48802 = NOVALUE;
    int _this_opt_48807 = NOVALUE;
    int _25491 = NOVALUE;
    int _25490 = NOVALUE;
    int _25487 = NOVALUE;
    int _25486 = NOVALUE;
    int _25485 = NOVALUE;
    int _25483 = NOVALUE;
    int _25482 = NOVALUE;
    int _25481 = NOVALUE;
    int _25480 = NOVALUE;
    int _25478 = NOVALUE;
    int _25477 = NOVALUE;
    int _25475 = NOVALUE;
    int _25474 = NOVALUE;
    int _25473 = NOVALUE;
    int _25472 = NOVALUE;
    int _25471 = NOVALUE;
    int _25470 = NOVALUE;
    int _25469 = NOVALUE;
    int _25467 = NOVALUE;
    int _25464 = NOVALUE;
    int _25463 = NOVALUE;
    int _25458 = NOVALUE;
    int _25456 = NOVALUE;
    int _25455 = NOVALUE;
    int _25454 = NOVALUE;
    int _25453 = NOVALUE;
    int _25452 = NOVALUE;
    int _25451 = NOVALUE;
    int _25450 = NOVALUE;
    int _25449 = NOVALUE;
    int _25445 = NOVALUE;
    int _25444 = NOVALUE;
    int _25443 = NOVALUE;
    int _25442 = NOVALUE;
    int _25441 = NOVALUE;
    int _25440 = NOVALUE;
    int _25439 = NOVALUE;
    int _25438 = NOVALUE;
    int _25437 = NOVALUE;
    int _25436 = NOVALUE;
    int _25435 = NOVALUE;
    int _25434 = NOVALUE;
    int _25433 = NOVALUE;
    int _25432 = NOVALUE;
    int _25431 = NOVALUE;
    int _25429 = NOVALUE;
    int _25428 = NOVALUE;
    int _25427 = NOVALUE;
    int _25426 = NOVALUE;
    int _25425 = NOVALUE;
    int _25424 = NOVALUE;
    int _25423 = NOVALUE;
    int _25422 = NOVALUE;
    int _25420 = NOVALUE;
    int _25419 = NOVALUE;
    int _25418 = NOVALUE;
    int _25417 = NOVALUE;
    int _25415 = NOVALUE;
    int _25414 = NOVALUE;
    int _25413 = NOVALUE;
    int _25412 = NOVALUE;
    int _25411 = NOVALUE;
    int _25410 = NOVALUE;
    int _25409 = NOVALUE;
    int _25407 = NOVALUE;
    int _25406 = NOVALUE;
    int _25404 = NOVALUE;
    int _25401 = NOVALUE;
    int _25398 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dedupe_48704)) {
        _1 = (long)(DBL_PTR(_dedupe_48704)->dbl);
        DeRefDS(_dedupe_48704);
        _dedupe_48704 = _1;
    }

    /** 	integer i = 1*/
    _i_48705 = 1;

    /** 	while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_48701)){
            _25398 = SEQ_PTR(_a_48701)->length;
    }
    else {
        _25398 = 1;
    }
    if (_i_48705 > _25398)
    goto L2; // [22] 465

    /** 		sequence opt = a[i]*/
    DeRef(_opt_48709);
    _2 = (int)SEQ_PTR(_a_48701);
    _opt_48709 = (int)*(((s1_ptr)_2)->base + _i_48705);
    Ref(_opt_48709);

    /** 		if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_48709)){
            _25401 = SEQ_PTR(_opt_48709)->length;
    }
    else {
        _25401 = 1;
    }
    if (_25401 >= 2)
    goto L3; // [39] 56

    /** 			i += 1*/
    _i_48705 = _i_48705 + 1;

    /** 			continue*/
    DeRefDS(_opt_48709);
    _opt_48709 = NOVALUE;
    DeRef(_this_opt_48715);
    _this_opt_48715 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** 		sequence this_opt = {}*/
    RefDS(_21815);
    DeRef(_this_opt_48715);
    _this_opt_48715 = _21815;

    /** 		integer bi = 0*/
    _bi_48716 = 0;

    /** 		if opt[2] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_48709);
    _25404 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25404, 45)){
        _25404 = NOVALUE;
        goto L4; // [74] 149
    }
    _25404 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_48709)){
            _25406 = SEQ_PTR(_opt_48709)->length;
    }
    else {
        _25406 = 1;
    }
    rhs_slice_target = (object_ptr)&_25407;
    RHS_Slice(_opt_48709, 3, _25406);
    RefDS(_opts_48703);
    _0 = _this_opt_48715;
    _this_opt_48715 = _43find_opt(2, _25407, _opts_48703);
    DeRefDS(_0);
    _25407 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_48702)){
            _25409 = SEQ_PTR(_b_48702)->length;
    }
    else {
        _25409 = 1;
    }
    {
        int _j_48724;
        _j_48724 = 1;
L5: 
        if (_j_48724 > _25409){
            goto L6; // [101] 146
        }

        /** 				if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (int)SEQ_PTR(_b_48702);
        _25410 = (int)*(((s1_ptr)_2)->base + _j_48724);
        Ref(_25410);
        _25411 = _14lower(_25410);
        _25410 = NOVALUE;
        RefDS(_opt_48709);
        _25412 = _14lower(_opt_48709);
        if (_25411 == _25412)
        _25413 = 1;
        else if (IS_ATOM_INT(_25411) && IS_ATOM_INT(_25412))
        _25413 = 0;
        else
        _25413 = (compare(_25411, _25412) == 0);
        DeRef(_25411);
        _25411 = NOVALUE;
        DeRef(_25412);
        _25412 = NOVALUE;
        if (_25413 == 0)
        {
            _25413 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25413 = NOVALUE;
        }

        /** 					bi = j*/
        _bi_48716 = _j_48724;

        /** 					exit*/
        goto L6; // [136] 146
L7: 

        /** 			end for*/
        _j_48724 = _j_48724 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_48709);
    _25414 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25414)) {
        _25415 = (_25414 == 45);
    }
    else {
        _25415 = binary_op(EQUALS, _25414, 45);
    }
    _25414 = NOVALUE;
    if (IS_ATOM_INT(_25415)) {
        if (_25415 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25415)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (int)SEQ_PTR(_opt_48709);
    _25417 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25417)) {
        _25418 = (_25417 == 47);
    }
    else {
        _25418 = binary_op(EQUALS, _25417, 47);
    }
    _25417 = NOVALUE;
    if (_25418 == 0) {
        DeRef(_25418);
        _25418 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25418) && DBL_PTR(_25418)->dbl == 0.0){
            DeRef(_25418);
            _25418 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25418);
        _25418 = NOVALUE;
    }
    DeRef(_25418);
    _25418 = NOVALUE;
L9: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_48709)){
            _25419 = SEQ_PTR(_opt_48709)->length;
    }
    else {
        _25419 = 1;
    }
    rhs_slice_target = (object_ptr)&_25420;
    RHS_Slice(_opt_48709, 2, _25419);
    RefDS(_opts_48703);
    _0 = _this_opt_48715;
    _this_opt_48715 = _43find_opt(1, _25420, _opts_48703);
    DeRef(_0);
    _25420 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_48702)){
            _25422 = SEQ_PTR(_b_48702)->length;
    }
    else {
        _25422 = 1;
    }
    {
        int _j_48741;
        _j_48741 = 1;
LB: 
        if (_j_48741 > _25422){
            goto LC; // [199] 290
        }

        /** 				if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (int)SEQ_PTR(_b_48702);
        _25423 = (int)*(((s1_ptr)_2)->base + _j_48741);
        Ref(_25423);
        _25424 = _14lower(_25423);
        _25423 = NOVALUE;
        if (IS_SEQUENCE(_opt_48709)){
                _25425 = SEQ_PTR(_opt_48709)->length;
        }
        else {
            _25425 = 1;
        }
        rhs_slice_target = (object_ptr)&_25426;
        RHS_Slice(_opt_48709, 2, _25425);
        _25427 = _14lower(_25426);
        _25426 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25427)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25427)) {
            Prepend(&_25428, _25427, 45);
        }
        else {
            Concat((object_ptr)&_25428, 45, _25427);
        }
        DeRef(_25427);
        _25427 = NOVALUE;
        if (_25424 == _25428)
        _25429 = 1;
        else if (IS_ATOM_INT(_25424) && IS_ATOM_INT(_25428))
        _25429 = 0;
        else
        _25429 = (compare(_25424, _25428) == 0);
        DeRef(_25424);
        _25424 = NOVALUE;
        DeRefDS(_25428);
        _25428 = NOVALUE;
        if (_25429 != 0) {
            goto LD; // [236] 273
        }
        _2 = (int)SEQ_PTR(_b_48702);
        _25431 = (int)*(((s1_ptr)_2)->base + _j_48741);
        Ref(_25431);
        _25432 = _14lower(_25431);
        _25431 = NOVALUE;
        if (IS_SEQUENCE(_opt_48709)){
                _25433 = SEQ_PTR(_opt_48709)->length;
        }
        else {
            _25433 = 1;
        }
        rhs_slice_target = (object_ptr)&_25434;
        RHS_Slice(_opt_48709, 2, _25433);
        _25435 = _14lower(_25434);
        _25434 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25435)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25435)) {
            Prepend(&_25436, _25435, 47);
        }
        else {
            Concat((object_ptr)&_25436, 47, _25435);
        }
        DeRef(_25435);
        _25435 = NOVALUE;
        if (_25432 == _25436)
        _25437 = 1;
        else if (IS_ATOM_INT(_25432) && IS_ATOM_INT(_25436))
        _25437 = 0;
        else
        _25437 = (compare(_25432, _25436) == 0);
        DeRef(_25432);
        _25432 = NOVALUE;
        DeRefDS(_25436);
        _25436 = NOVALUE;
        if (_25437 == 0)
        {
            _25437 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25437 = NOVALUE;
        }
LD: 

        /** 					bi = j*/
        _bi_48716 = _j_48741;

        /** 					exit*/
        goto LC; // [280] 290
LE: 

        /** 			end for*/
        _j_48741 = _j_48741 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** 		if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_48715)){
            _25438 = SEQ_PTR(_this_opt_48715)->length;
    }
    else {
        _25438 = 1;
    }
    if (_25438 == 0) {
        goto LF; // [297] 451
    }
    _2 = (int)SEQ_PTR(_this_opt_48715);
    _25440 = (int)*(((s1_ptr)_2)->base + 4);
    _25441 = find_from(42, _25440, 1);
    _25440 = NOVALUE;
    _25442 = (_25441 == 0);
    _25441 = NOVALUE;
    if (_25442 == 0)
    {
        DeRef(_25442);
        _25442 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25442);
        _25442 = NOVALUE;
    }

    /** 			if bi then*/
    if (_bi_48716 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** 				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_48715);
    _25443 = (int)*(((s1_ptr)_2)->base + 4);
    _25444 = find_from(112, _25443, 1);
    _25443 = NOVALUE;
    if (_25444 == 0)
    {
        _25444 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25444 = NOVALUE;
    }

    /** 					a = remove(a, i, i + 1)*/
    _25445 = _i_48705 + 1;
    if (_25445 > MAXINT){
        _25445 = NewDouble((double)_25445);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_48701);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_48705)) ? _i_48705 : (long)(DBL_PTR(_i_48705)->dbl);
        int stop = (IS_ATOM_INT(_25445)) ? _25445 : (long)(DBL_PTR(_25445)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_48701), start, &_a_48701 );
            }
            else Tail(SEQ_PTR(_a_48701), stop+1, &_a_48701);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_48701), start, &_a_48701);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_48701 = Remove_elements(start, stop, (SEQ_PTR(_a_48701)->ref == 1));
        }
    }
    DeRef(_25445);
    _25445 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** 					a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_48701);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_48705)) ? _i_48705 : (long)(DBL_PTR(_i_48705)->dbl);
        int stop = (IS_ATOM_INT(_i_48705)) ? _i_48705 : (long)(DBL_PTR(_i_48705)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_48701), start, &_a_48701 );
            }
            else Tail(SEQ_PTR(_a_48701), stop+1, &_a_48701);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_48701), start, &_a_48701);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_48701 = Remove_elements(start, stop, (SEQ_PTR(_a_48701)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** 				integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_48701)){
            _beginLen_48776 = SEQ_PTR(_a_48701)->length;
    }
    else {
        _beginLen_48776 = 1;
    }

    /** 				if dedupe = 0 and i < beginLen then*/
    _25449 = (_dedupe_48704 == 0);
    if (_25449 == 0) {
        goto L13; // [376] 438
    }
    _25451 = (_i_48705 < _beginLen_48776);
    if (_25451 == 0)
    {
        DeRef(_25451);
        _25451 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25451);
        _25451 = NOVALUE;
    }

    /** 					a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25452 = _i_48705 + 1;
    if (_25452 > MAXINT){
        _25452 = NewDouble((double)_25452);
    }
    if (IS_SEQUENCE(_a_48701)){
            _25453 = SEQ_PTR(_a_48701)->length;
    }
    else {
        _25453 = 1;
    }
    rhs_slice_target = (object_ptr)&_25454;
    RHS_Slice(_a_48701, _25452, _25453);
    rhs_slice_target = (object_ptr)&_25455;
    RHS_Slice(_a_48701, 1, _i_48705);
    RefDS(_opts_48703);
    DeRef(_25456);
    _25456 = _opts_48703;
    _0 = _a_48701;
    _a_48701 = _43merge_parameters(_25454, _25455, _25456, 1);
    DeRefDS(_0);
    _25454 = NOVALUE;
    _25455 = NOVALUE;
    _25456 = NOVALUE;

    /** 					if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_48701)){
            _25458 = SEQ_PTR(_a_48701)->length;
    }
    else {
        _25458 = 1;
    }
    if (_beginLen_48776 != _25458)
    goto L14; // [424] 445

    /** 						i += 1*/
    _i_48705 = _i_48705 + 1;
    goto L14; // [435] 445
L13: 

    /** 					i += 1*/
    _i_48705 = _i_48705 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** 			i += 1*/
    _i_48705 = _i_48705 + 1;
L12: 
    DeRef(_opt_48709);
    _opt_48709 = NOVALUE;
    DeRef(_this_opt_48715);
    _this_opt_48715 = NOVALUE;

    /** 	end while*/
    goto L1; // [462] 19
L2: 

    /** 	if dedupe then*/
    if (_dedupe_48704 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** 		return b & a*/
    Concat((object_ptr)&_25463, _b_48702, _a_48701);
    DeRefDS(_a_48701);
    DeRefDS(_b_48702);
    DeRefDS(_opts_48703);
    DeRef(_25449);
    _25449 = NOVALUE;
    DeRef(_25415);
    _25415 = NOVALUE;
    DeRef(_25452);
    _25452 = NOVALUE;
    return _25463;
L15: 

    /** 	integer first_extra = 0*/
    _first_extra_48798 = 0;

    /** 	i = 1*/
    _i_48705 = 1;

    /** 	while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_48702)){
            _25464 = SEQ_PTR(_b_48702)->length;
    }
    else {
        _25464 = 1;
    }
    if (_i_48705 > _25464)
    goto L17; // [499] 692

    /** 		sequence opt = b[i]*/
    DeRef(_opt_48802);
    _2 = (int)SEQ_PTR(_b_48702);
    _opt_48802 = (int)*(((s1_ptr)_2)->base + _i_48705);
    Ref(_opt_48802);

    /** 		if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_48802)){
            _25467 = SEQ_PTR(_opt_48802)->length;
    }
    else {
        _25467 = 1;
    }
    if (_25467 > 1)
    goto L18; // [516] 532

    /** 			first_extra = i*/
    _first_extra_48798 = _i_48705;

    /** 			exit*/
    DeRefDS(_opt_48802);
    _opt_48802 = NOVALUE;
    DeRef(_this_opt_48807);
    _this_opt_48807 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** 		sequence this_opt = {}*/
    RefDS(_21815);
    DeRef(_this_opt_48807);
    _this_opt_48807 = _21815;

    /** 		if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_48802);
    _25469 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25469)) {
        _25470 = (_25469 == 45);
    }
    else {
        _25470 = binary_op(EQUALS, _25469, 45);
    }
    _25469 = NOVALUE;
    if (IS_ATOM_INT(_25470)) {
        if (_25470 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25470)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (int)SEQ_PTR(_opt_48802);
    _25472 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25472)) {
        _25473 = (_25472 == 45);
    }
    else {
        _25473 = binary_op(EQUALS, _25472, 45);
    }
    _25472 = NOVALUE;
    if (_25473 == 0) {
        DeRef(_25473);
        _25473 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25473) && DBL_PTR(_25473)->dbl == 0.0){
            DeRef(_25473);
            _25473 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25473);
        _25473 = NOVALUE;
    }
    DeRef(_25473);
    _25473 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_48802)){
            _25474 = SEQ_PTR(_opt_48802)->length;
    }
    else {
        _25474 = 1;
    }
    rhs_slice_target = (object_ptr)&_25475;
    RHS_Slice(_opt_48802, 3, _25474);
    RefDS(_opts_48703);
    _0 = _this_opt_48807;
    _this_opt_48807 = _43find_opt(2, _25475, _opts_48703);
    DeRef(_0);
    _25475 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_48802);
    _25477 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25477)) {
        _25478 = (_25477 == 45);
    }
    else {
        _25478 = binary_op(EQUALS, _25477, 45);
    }
    _25477 = NOVALUE;
    if (IS_ATOM_INT(_25478)) {
        if (_25478 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25478)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (int)SEQ_PTR(_opt_48802);
    _25480 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25480)) {
        _25481 = (_25480 == 47);
    }
    else {
        _25481 = binary_op(EQUALS, _25480, 47);
    }
    _25480 = NOVALUE;
    if (_25481 == 0) {
        DeRef(_25481);
        _25481 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25481) && DBL_PTR(_25481)->dbl == 0.0){
            DeRef(_25481);
            _25481 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25481);
        _25481 = NOVALUE;
    }
    DeRef(_25481);
    _25481 = NOVALUE;
L1B: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_48802)){
            _25482 = SEQ_PTR(_opt_48802)->length;
    }
    else {
        _25482 = 1;
    }
    rhs_slice_target = (object_ptr)&_25483;
    RHS_Slice(_opt_48802, 2, _25482);
    RefDS(_opts_48703);
    _0 = _this_opt_48807;
    _this_opt_48807 = _43find_opt(1, _25483, _opts_48703);
    DeRef(_0);
    _25483 = NOVALUE;
L1C: 
L1A: 

    /** 		if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_48807)){
            _25485 = SEQ_PTR(_this_opt_48807)->length;
    }
    else {
        _25485 = 1;
    }
    if (_25485 == 0)
    {
        _25485 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25485 = NOVALUE;
    }

    /** 			if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_48807);
    _25486 = (int)*(((s1_ptr)_2)->base + 4);
    _25487 = find_from(112, _25486, 1);
    _25486 = NOVALUE;
    if (_25487 == 0)
    {
        _25487 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25487 = NOVALUE;
    }

    /** 				i += 1*/
    _i_48705 = _i_48705 + 1;
    goto L1E; // [664] 679
L1D: 

    /** 			first_extra = i*/
    _first_extra_48798 = _i_48705;

    /** 			exit*/
    DeRef(_opt_48802);
    _opt_48802 = NOVALUE;
    DeRef(_this_opt_48807);
    _this_opt_48807 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** 		i += 1*/
    _i_48705 = _i_48705 + 1;
    DeRef(_opt_48802);
    _opt_48802 = NOVALUE;
    DeRef(_this_opt_48807);
    _this_opt_48807 = NOVALUE;

    /** 	end while*/
    goto L16; // [689] 496
L17: 

    /** 	if first_extra then*/
    if (_first_extra_48798 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** 		return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_48798;
        if (insert_pos <= 0) {
            Concat(&_25490,_a_48701,_b_48702);
        }
        else if (insert_pos > SEQ_PTR(_b_48702)->length){
            Concat(&_25490,_b_48702,_a_48701);
        }
        else if (IS_SEQUENCE(_a_48701)) {
            if( _25490 != _b_48702 || SEQ_PTR( _b_48702 )->ref != 1 ){
                DeRef( _25490 );
                RefDS( _b_48702 );
            }
            assign_space = Add_internal_space( _b_48702, insert_pos,((s1_ptr)SEQ_PTR(_a_48701))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_48701), _b_48702 == _25490 );
            _25490 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25490 != _b_48702 && SEQ_PTR( _b_48702 )->ref != 1 ){
                _25490 = Insert( _b_48702, _a_48701, insert_pos);
            }
            else {
                DeRef( _25490 );
                RefDS( _b_48702 );
                _25490 = Insert( _b_48702, _a_48701, insert_pos);
            }
        }
    }
    DeRefDS(_a_48701);
    DeRefDS(_b_48702);
    DeRefDS(_opts_48703);
    DeRef(_25449);
    _25449 = NOVALUE;
    DeRef(_25415);
    _25415 = NOVALUE;
    DeRef(_25452);
    _25452 = NOVALUE;
    DeRef(_25463);
    _25463 = NOVALUE;
    DeRef(_25470);
    _25470 = NOVALUE;
    DeRef(_25478);
    _25478 = NOVALUE;
    return _25490;
L1F: 

    /** 	return b & a*/
    Concat((object_ptr)&_25491, _b_48702, _a_48701);
    DeRefDS(_a_48701);
    DeRefDS(_b_48702);
    DeRefDS(_opts_48703);
    DeRef(_25449);
    _25449 = NOVALUE;
    DeRef(_25415);
    _25415 = NOVALUE;
    DeRef(_25452);
    _25452 = NOVALUE;
    DeRef(_25463);
    _25463 = NOVALUE;
    DeRef(_25490);
    _25490 = NOVALUE;
    DeRef(_25470);
    _25470 = NOVALUE;
    DeRef(_25478);
    _25478 = NOVALUE;
    return _25491;
    ;
}


int _43validate_opt(int _opt_type_48840, int _arg_48841, int _args_48842, int _ix_48843)
{
    int _opt_48844 = NOVALUE;
    int _this_opt_48852 = NOVALUE;
    int _25510 = NOVALUE;
    int _25509 = NOVALUE;
    int _25508 = NOVALUE;
    int _25507 = NOVALUE;
    int _25506 = NOVALUE;
    int _25504 = NOVALUE;
    int _25503 = NOVALUE;
    int _25502 = NOVALUE;
    int _25501 = NOVALUE;
    int _25500 = NOVALUE;
    int _25498 = NOVALUE;
    int _25495 = NOVALUE;
    int _25493 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if opt_type = SHORTNAME then*/
    if (_opt_type_48840 != 1)
    goto L1; // [11] 28

    /** 		opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_48841)){
            _25493 = SEQ_PTR(_arg_48841)->length;
    }
    else {
        _25493 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_48844;
    RHS_Slice(_arg_48841, 2, _25493);
    goto L2; // [25] 39
L1: 

    /** 		opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_48841)){
            _25495 = SEQ_PTR(_arg_48841)->length;
    }
    else {
        _25495 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_48844;
    RHS_Slice(_arg_48841, 3, _25495);
L2: 

    /** 	sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_48844);
    RefDS(_43options_48583);
    _0 = _this_opt_48852;
    _this_opt_48852 = _43find_opt(_opt_type_48840, _opt_48844, _43options_48583);
    DeRef(_0);

    /** 	if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_48852)){
            _25498 = SEQ_PTR(_this_opt_48852)->length;
    }
    else {
        _25498 = 1;
    }
    if (_25498 != 0)
    goto L3; // [58] 72
    _25498 = NOVALUE;

    /** 		return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _25500 = MAKE_SEQ(_1);
    DeRefDS(_arg_48841);
    DeRefDS(_args_48842);
    DeRefDS(_opt_48844);
    DeRefDS(_this_opt_48852);
    return _25500;
L3: 

    /** 	if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (int)SEQ_PTR(_this_opt_48852);
    _25501 = (int)*(((s1_ptr)_2)->base + 4);
    _25502 = find_from(112, _25501, 1);
    _25501 = NOVALUE;
    if (_25502 == 0)
    {
        _25502 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25502 = NOVALUE;
    }

    /** 		if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_48842)){
            _25503 = SEQ_PTR(_args_48842)->length;
    }
    else {
        _25503 = 1;
    }
    _25504 = _25503 - 1;
    _25503 = NOVALUE;
    if (_ix_48843 != _25504)
    goto L5; // [97] 117

    /** 			CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_arg_48841);
    *((int *)(_2+4)) = _arg_48841;
    _25506 = MAKE_SEQ(_1);
    _44CompileErr(353, _25506, 0);
    _25506 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** 			return { ix, ix + 2 }*/
    _25507 = _ix_48843 + 2;
    if ((long)((unsigned long)_25507 + (unsigned long)HIGH_BITS) >= 0) 
    _25507 = NewDouble((double)_25507);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_48843;
    ((int *)_2)[2] = _25507;
    _25508 = MAKE_SEQ(_1);
    _25507 = NOVALUE;
    DeRefDS(_arg_48841);
    DeRefDS(_args_48842);
    DeRef(_opt_48844);
    DeRef(_this_opt_48852);
    DeRef(_25500);
    _25500 = NOVALUE;
    DeRef(_25504);
    _25504 = NOVALUE;
    return _25508;
    goto L6; // [132] 150
L4: 

    /** 		return { ix, ix + 1 }*/
    _25509 = _ix_48843 + 1;
    if (_25509 > MAXINT){
        _25509 = NewDouble((double)_25509);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_48843;
    ((int *)_2)[2] = _25509;
    _25510 = MAKE_SEQ(_1);
    _25509 = NOVALUE;
    DeRefDS(_arg_48841);
    DeRefDS(_args_48842);
    DeRef(_opt_48844);
    DeRef(_this_opt_48852);
    DeRef(_25500);
    _25500 = NOVALUE;
    DeRef(_25504);
    _25504 = NOVALUE;
    DeRef(_25508);
    _25508 = NOVALUE;
    return _25510;
L6: 
    ;
}


int _43find_next_opt(int _ix_48877, int _args_48878)
{
    int _arg_48882 = NOVALUE;
    int _25532 = NOVALUE;
    int _25531 = NOVALUE;
    int _25529 = NOVALUE;
    int _25528 = NOVALUE;
    int _25527 = NOVALUE;
    int _25526 = NOVALUE;
    int _25525 = NOVALUE;
    int _25524 = NOVALUE;
    int _25523 = NOVALUE;
    int _25522 = NOVALUE;
    int _25520 = NOVALUE;
    int _25518 = NOVALUE;
    int _25516 = NOVALUE;
    int _25514 = NOVALUE;
    int _25511 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_48878)){
            _25511 = SEQ_PTR(_args_48878)->length;
    }
    else {
        _25511 = 1;
    }
    if (_ix_48877 >= _25511)
    goto L2; // [13] 157

    /** 		sequence arg = args[ix]*/
    DeRef(_arg_48882);
    _2 = (int)SEQ_PTR(_args_48878);
    _arg_48882 = (int)*(((s1_ptr)_2)->base + _ix_48877);
    Ref(_arg_48882);

    /** 		if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_48882)){
            _25514 = SEQ_PTR(_arg_48882)->length;
    }
    else {
        _25514 = 1;
    }
    if (_25514 <= 1)
    goto L3; // [30] 129

    /** 			if arg[1] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_48882);
    _25516 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25516, 45)){
        _25516 = NOVALUE;
        goto L4; // [40] 111
    }
    _25516 = NOVALUE;

    /** 				if arg[2] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_48882);
    _25518 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25518, 45)){
        _25518 = NOVALUE;
        goto L5; // [50] 94
    }
    _25518 = NOVALUE;

    /** 					if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_48882)){
            _25520 = SEQ_PTR(_arg_48882)->length;
    }
    else {
        _25520 = 1;
    }
    if (_25520 != 2)
    goto L6; // [59] 78

    /** 						return { 0, ix - 1 }*/
    _25522 = _ix_48877 - 1;
    if ((long)((unsigned long)_25522 +(unsigned long) HIGH_BITS) >= 0){
        _25522 = NewDouble((double)_25522);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25522;
    _25523 = MAKE_SEQ(_1);
    _25522 = NOVALUE;
    DeRefDS(_arg_48882);
    DeRefDS(_args_48878);
    return _25523;
L6: 

    /** 					return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_48882);
    RefDS(_args_48878);
    _25524 = _43validate_opt(2, _arg_48882, _args_48878, _ix_48877);
    DeRefDS(_arg_48882);
    DeRefDS(_args_48878);
    DeRef(_25523);
    _25523 = NOVALUE;
    return _25524;
    goto L7; // [91] 144
L5: 

    /** 					return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_48882);
    RefDS(_args_48878);
    _25525 = _43validate_opt(1, _arg_48882, _args_48878, _ix_48877);
    DeRefDS(_arg_48882);
    DeRefDS(_args_48878);
    DeRef(_25523);
    _25523 = NOVALUE;
    DeRef(_25524);
    _25524 = NOVALUE;
    return _25525;
    goto L7; // [108] 144
L4: 

    /** 				return {0, ix-1}*/
    _25526 = _ix_48877 - 1;
    if ((long)((unsigned long)_25526 +(unsigned long) HIGH_BITS) >= 0){
        _25526 = NewDouble((double)_25526);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25526;
    _25527 = MAKE_SEQ(_1);
    _25526 = NOVALUE;
    DeRef(_arg_48882);
    DeRefDS(_args_48878);
    DeRef(_25523);
    _25523 = NOVALUE;
    DeRef(_25524);
    _25524 = NOVALUE;
    DeRef(_25525);
    _25525 = NOVALUE;
    return _25527;
    goto L7; // [126] 144
L3: 

    /** 			return { 0, ix-1 }*/
    _25528 = _ix_48877 - 1;
    if ((long)((unsigned long)_25528 +(unsigned long) HIGH_BITS) >= 0){
        _25528 = NewDouble((double)_25528);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25528;
    _25529 = MAKE_SEQ(_1);
    _25528 = NOVALUE;
    DeRef(_arg_48882);
    DeRefDS(_args_48878);
    DeRef(_25523);
    _25523 = NOVALUE;
    DeRef(_25524);
    _25524 = NOVALUE;
    DeRef(_25525);
    _25525 = NOVALUE;
    DeRef(_25527);
    _25527 = NOVALUE;
    return _25529;
L7: 

    /** 		ix += 1*/
    _ix_48877 = _ix_48877 + 1;
    DeRef(_arg_48882);
    _arg_48882 = NOVALUE;

    /** 	end while*/
    goto L1; // [154] 10
L2: 

    /** 	return {0, ix-1}*/
    _25531 = _ix_48877 - 1;
    if ((long)((unsigned long)_25531 +(unsigned long) HIGH_BITS) >= 0){
        _25531 = NewDouble((double)_25531);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25531;
    _25532 = MAKE_SEQ(_1);
    _25531 = NOVALUE;
    DeRefDS(_args_48878);
    DeRef(_25523);
    _25523 = NOVALUE;
    DeRef(_25524);
    _25524 = NOVALUE;
    DeRef(_25525);
    _25525 = NOVALUE;
    DeRef(_25527);
    _25527 = NOVALUE;
    DeRef(_25529);
    _25529 = NOVALUE;
    return _25532;
    ;
}


int _43expand_config_options(int _args_48912)
{
    int _idx_48913 = NOVALUE;
    int _next_idx_48914 = NOVALUE;
    int _files_48915 = NOVALUE;
    int _cmd_1_2_48916 = NOVALUE;
    int _25555 = NOVALUE;
    int _25554 = NOVALUE;
    int _25553 = NOVALUE;
    int _25552 = NOVALUE;
    int _25551 = NOVALUE;
    int _25550 = NOVALUE;
    int _25549 = NOVALUE;
    int _25548 = NOVALUE;
    int _25547 = NOVALUE;
    int _25542 = NOVALUE;
    int _25540 = NOVALUE;
    int _25539 = NOVALUE;
    int _25538 = NOVALUE;
    int _25536 = NOVALUE;
    int _25535 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer idx = 1*/
    _idx_48913 = 1;

    /** 	sequence files = {}*/
    RefDS(_21815);
    DeRef(_files_48915);
    _files_48915 = _21815;

    /** 	sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_48916;
    RHS_Slice(_args_48912, 1, 2);

    /** 	args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_48912);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (long)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (long)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_48912), start, &_args_48912 );
            }
            else Tail(SEQ_PTR(_args_48912), stop+1, &_args_48912);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_48912), start, &_args_48912);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_48912 = Remove_elements(start, stop, (SEQ_PTR(_args_48912)->ref == 1));
        }
    }

    /** 	while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_48913 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** 		if equal(upper(args[idx]), "-C") then*/
    _2 = (int)SEQ_PTR(_args_48912);
    _25535 = (int)*(((s1_ptr)_2)->base + _idx_48913);
    Ref(_25535);
    _25536 = _14upper(_25535);
    _25535 = NOVALUE;
    if (_25536 == _25537)
    _25538 = 1;
    else if (IS_ATOM_INT(_25536) && IS_ATOM_INT(_25537))
    _25538 = 0;
    else
    _25538 = (compare(_25536, _25537) == 0);
    DeRef(_25536);
    _25536 = NOVALUE;
    if (_25538 == 0)
    {
        _25538 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25538 = NOVALUE;
    }

    /** 			files = append( files, args[idx+1] )*/
    _25539 = _idx_48913 + 1;
    _2 = (int)SEQ_PTR(_args_48912);
    _25540 = (int)*(((s1_ptr)_2)->base + _25539);
    Ref(_25540);
    Append(&_files_48915, _files_48915, _25540);
    _25540 = NOVALUE;

    /** 			args = remove( args, idx, idx + 1 )*/
    _25542 = _idx_48913 + 1;
    if (_25542 > MAXINT){
        _25542 = NewDouble((double)_25542);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_48912);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_48913)) ? _idx_48913 : (long)(DBL_PTR(_idx_48913)->dbl);
        int stop = (IS_ATOM_INT(_25542)) ? _25542 : (long)(DBL_PTR(_25542)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_48912), start, &_args_48912 );
            }
            else Tail(SEQ_PTR(_args_48912), stop+1, &_args_48912);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_48912), start, &_args_48912);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_48912 = Remove_elements(start, stop, (SEQ_PTR(_args_48912)->ref == 1));
        }
    }
    DeRef(_25542);
    _25542 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** 			idx = next_idx[2]*/
    _2 = (int)SEQ_PTR(_next_idx_48914);
    _idx_48913 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_48913))
    _idx_48913 = (long)DBL_PTR(_idx_48913)->dbl;
L5: 

    /** 	entry*/
L1: 

    /** 		next_idx = find_next_opt( idx, args )*/
    RefDS(_args_48912);
    _0 = _next_idx_48914;
    _next_idx_48914 = _43find_next_opt(_idx_48913, _args_48912);
    DeRef(_0);

    /** 		idx = next_idx[1]*/
    _2 = (int)SEQ_PTR(_next_idx_48914);
    _idx_48913 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_48913))
    _idx_48913 = (long)DBL_PTR(_idx_48913)->dbl;

    /** 	end while*/
    goto L2; // [111] 34
L3: 

    /** 	return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_48915);
    _25547 = _42GetDefaultArgs(_files_48915);
    _2 = (int)SEQ_PTR(_next_idx_48914);
    _25548 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25549;
    RHS_Slice(_args_48912, 1, _25548);
    RefDS(_43options_48583);
    _25550 = _43merge_parameters(_25547, _25549, _43options_48583, 1);
    _25547 = NOVALUE;
    _25549 = NOVALUE;
    _2 = (int)SEQ_PTR(_next_idx_48914);
    _25551 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25551)) {
        _25552 = _25551 + 1;
        if (_25552 > MAXINT){
            _25552 = NewDouble((double)_25552);
        }
    }
    else
    _25552 = binary_op(PLUS, 1, _25551);
    _25551 = NOVALUE;
    if (IS_SEQUENCE(_args_48912)){
            _25553 = SEQ_PTR(_args_48912)->length;
    }
    else {
        _25553 = 1;
    }
    rhs_slice_target = (object_ptr)&_25554;
    RHS_Slice(_args_48912, _25552, _25553);
    {
        int concat_list[3];

        concat_list[0] = _25554;
        concat_list[1] = _25550;
        concat_list[2] = _cmd_1_2_48916;
        Concat_N((object_ptr)&_25555, concat_list, 3);
    }
    DeRefDS(_25554);
    _25554 = NOVALUE;
    DeRef(_25550);
    _25550 = NOVALUE;
    DeRefDS(_args_48912);
    DeRefDS(_next_idx_48914);
    DeRefDS(_files_48915);
    DeRefDS(_cmd_1_2_48916);
    DeRef(_25539);
    _25539 = NOVALUE;
    _25548 = NOVALUE;
    DeRef(_25552);
    _25552 = NOVALUE;
    return _25555;
    ;
}


void _43handle_common_options(int _opts_48947)
{
    int _opt_keys_48948 = NOVALUE;
    int _option_w_48950 = NOVALUE;
    int _key_48954 = NOVALUE;
    int _val_48956 = NOVALUE;
    int _this_warn_49002 = NOVALUE;
    int _auto_add_warn_49004 = NOVALUE;
    int _n_49010 = NOVALUE;
    int _this_warn_49033 = NOVALUE;
    int _auto_add_warn_49035 = NOVALUE;
    int _n_49041 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_615_49076 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_689_49088 = NOVALUE;
    int _25608 = NOVALUE;
    int _25607 = NOVALUE;
    int _25606 = NOVALUE;
    int _25605 = NOVALUE;
    int _25604 = NOVALUE;
    int _25603 = NOVALUE;
    int _25602 = NOVALUE;
    int _25601 = NOVALUE;
    int _25600 = NOVALUE;
    int _25598 = NOVALUE;
    int _25596 = NOVALUE;
    int _25595 = NOVALUE;
    int _25594 = NOVALUE;
    int _25589 = NOVALUE;
    int _25587 = NOVALUE;
    int _25585 = NOVALUE;
    int _25582 = NOVALUE;
    int _25581 = NOVALUE;
    int _25576 = NOVALUE;
    int _25574 = NOVALUE;
    int _25572 = NOVALUE;
    int _25570 = NOVALUE;
    int _25569 = NOVALUE;
    int _25568 = NOVALUE;
    int _25567 = NOVALUE;
    int _25566 = NOVALUE;
    int _25565 = NOVALUE;
    int _25563 = NOVALUE;
    int _25562 = NOVALUE;
    int _25557 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence opt_keys = m:keys(opts)*/
    Ref(_opts_48947);
    _0 = _opt_keys_48948;
    _opt_keys_48948 = _28keys(_opts_48947, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_48950 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_48948)){
            _25557 = SEQ_PTR(_opt_keys_48948)->length;
    }
    else {
        _25557 = 1;
    }
    {
        int _idx_48952;
        _idx_48952 = 1;
L1: 
        if (_idx_48952 > _25557){
            goto L2; // [20] 731
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_48954);
        _2 = (int)SEQ_PTR(_opt_keys_48948);
        _key_48954 = (int)*(((s1_ptr)_2)->base + _idx_48952);
        Ref(_key_48954);

        /** 		object val = m:get(opts, key)*/
        Ref(_opts_48947);
        RefDS(_key_48954);
        _0 = _val_48956;
        _val_48956 = _28get(_opts_48947, _key_48954, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_48954, _25560);
        switch ( _1 ){ 

            /** 			case "i" then*/
            case 1:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48956)){
                    _25562 = SEQ_PTR(_val_48956)->length;
            }
            else {
                _25562 = 1;
            }
            {
                int _i_48962;
                _i_48962 = 1;
L3: 
                if (_i_48962 > _25562){
                    goto L4; // [59] 82
                }

                /** 					add_include_directory(val[i])*/
                _2 = (int)SEQ_PTR(_val_48956);
                _25563 = (int)*(((s1_ptr)_2)->base + _i_48962);
                Ref(_25563);
                _42add_include_directory(_25563);
                _25563 = NOVALUE;

                /** 				end for*/
                _i_48962 = _i_48962 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 722

            /** 			case "d" then*/
            case 2:

            /** 				OpDefines &= val*/
            if (IS_SEQUENCE(_35OpDefines_16041) && IS_ATOM(_val_48956)) {
                Ref(_val_48956);
                Append(&_35OpDefines_16041, _35OpDefines_16041, _val_48956);
            }
            else if (IS_ATOM(_35OpDefines_16041) && IS_SEQUENCE(_val_48956)) {
            }
            else {
                Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _val_48956);
            }
            goto L5; // [98] 722

            /** 			case "batch" then*/
            case 3:

            /** 				batch_job = 1*/
            _35batch_job_15981 = 1;
            goto L5; // [111] 722

            /** 			case "test" then*/
            case 4:

            /** 				test_only = 1*/
            _35test_only_15980 = 1;
            goto L5; // [124] 722

            /** 			case "strict" then*/
            case 5:

            /** 				Strict_is_on = 1*/
            _35Strict_is_on_16033 = 1;
            goto L5; // [137] 722

            /** 			case "p" then*/
            case 6:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48956)){
                    _25565 = SEQ_PTR(_val_48956)->length;
            }
            else {
                _25565 = 1;
            }
            {
                int _i_48977;
                _i_48977 = 1;
L6: 
                if (_i_48977 > _25565){
                    goto L7; // [148] 173
                }

                /** 					add_preprocessor(val[i])*/
                _2 = (int)SEQ_PTR(_val_48956);
                _25566 = (int)*(((s1_ptr)_2)->base + _i_48977);
                Ref(_25566);
                _64add_preprocessor(_25566, 0, 0);
                _25566 = NOVALUE;

                /** 				end for*/
                _i_48977 = _i_48977 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 722

            /** 			case "pf" then*/
            case 7:

            /** 				force_preprocessor = 1*/
            _36force_preprocessor_14999 = 1;
            goto L5; // [186] 722

            /** 			case "l" then*/
            case 8:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48956)){
                    _25567 = SEQ_PTR(_val_48956)->length;
            }
            else {
                _25567 = 1;
            }
            {
                int _i_48985;
                _i_48985 = 1;
L8: 
                if (_i_48985 > _25567){
                    goto L9; // [197] 238
                }

                /** 					LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (int)SEQ_PTR(_val_48956);
                _25568 = (int)*(((s1_ptr)_2)->base + _i_48985);
                Ref(_25568);
                _25569 = _14lower(_25568);
                _25568 = NOVALUE;
                RefDS(_21815);
                RefDS(_5);
                _25570 = _23filter(_25569, _23STDFLTR_ALPHA_4993, _21815, _5);
                _25569 = NOVALUE;
                Ref(_25570);
                Append(&_36LocalizeQual_15000, _36LocalizeQual_15000, _25570);
                DeRef(_25570);
                _25570 = NOVALUE;

                /** 				end for*/
                _i_48985 = _i_48985 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 722

            /** 			case "ldb" then*/
            case 9:

            /** 				LocalDB = val*/
            Ref(_val_48956);
            DeRef(_36LocalDB_15001);
            _36LocalDB_15001 = _val_48956;
            goto L5; // [251] 722

            /** 			case "w" then*/
            case 10:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48956)){
                    _25572 = SEQ_PTR(_val_48956)->length;
            }
            else {
                _25572 = 1;
            }
            {
                int _i_49000;
                _i_49000 = 1;
LA: 
                if (_i_49000 > _25572){
                    goto LB; // [262] 392
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49002);
                _2 = (int)SEQ_PTR(_val_48956);
                _this_warn_49002 = (int)*(((s1_ptr)_2)->base + _i_49000);
                Ref(_this_warn_49002);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49004 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49002);
                _25574 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25574, 43)){
                    _25574 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25574 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49004 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49002)){
                        _25576 = SEQ_PTR(_this_warn_49002)->length;
                }
                else {
                    _25576 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49002;
                RHS_Slice(_this_warn_49002, 2, _25576);
LC: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49010 = find_from(_this_warn_49002, _35warning_names_16012, 1);

                /** 					if n != 0 then*/
                if (_n_49010 == 0)
                goto LD; // [319] 383

                /** 						if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_49004 != 0) {
                    goto LE; // [325] 338
                }
                _25581 = (_option_w_48950 == 1);
                if (_25581 == 0)
                {
                    DeRef(_25581);
                    _25581 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25581);
                    _25581 = NOVALUE;
                }
LE: 

                /** 							OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (int)SEQ_PTR(_35warning_flags_16010);
                _25582 = (int)*(((s1_ptr)_2)->base + _n_49010);
                {unsigned long tu;
                     tu = (unsigned long)_35OpWarning_16035 | (unsigned long)_25582;
                     _35OpWarning_16035 = MAKE_UINT(tu);
                }
                _25582 = NOVALUE;
                if (!IS_ATOM_INT(_35OpWarning_16035)) {
                    _1 = (long)(DBL_PTR(_35OpWarning_16035)->dbl);
                    DeRefDS(_35OpWarning_16035);
                    _35OpWarning_16035 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** 							option_w = 1*/
                _option_w_48950 = 1;

                /** 							OpWarning = warning_flags[n]*/
                _2 = (int)SEQ_PTR(_35warning_flags_16010);
                _35OpWarning_16035 = (int)*(((s1_ptr)_2)->base + _n_49010);
L10: 

                /** 						prev_OpWarning = OpWarning*/
                _35prev_OpWarning_16036 = _35OpWarning_16035;
LD: 
                DeRef(_this_warn_49002);
                _this_warn_49002 = NOVALUE;

                /** 				end for*/
                _i_49000 = _i_49000 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 722

            /** 			case "x" then*/
            case 11:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48956)){
                    _25585 = SEQ_PTR(_val_48956)->length;
            }
            else {
                _25585 = 1;
            }
            {
                int _i_49031;
                _i_49031 = 1;
L11: 
                if (_i_49031 > _25585){
                    goto L12; // [403] 542
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49033);
                _2 = (int)SEQ_PTR(_val_48956);
                _this_warn_49033 = (int)*(((s1_ptr)_2)->base + _i_49031);
                Ref(_this_warn_49033);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49035 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49033);
                _25587 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25587, 43)){
                    _25587 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25587 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49035 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49033)){
                        _25589 = SEQ_PTR(_this_warn_49033)->length;
                }
                else {
                    _25589 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49033;
                RHS_Slice(_this_warn_49033, 2, _25589);
L13: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49041 = find_from(_this_warn_49033, _35warning_names_16012, 1);

                /** 					if n != 0 then*/
                if (_n_49041 == 0)
                goto L14; // [460] 533

                /** 						if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_49035 != 0) {
                    goto L15; // [466] 479
                }
                _25594 = (_option_w_48950 == -1);
                if (_25594 == 0)
                {
                    DeRef(_25594);
                    _25594 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25594);
                    _25594 = NOVALUE;
                }
L15: 

                /** 							OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (int)SEQ_PTR(_35warning_flags_16010);
                _25595 = (int)*(((s1_ptr)_2)->base + _n_49041);
                _25596 = not_bits(_25595);
                _25595 = NOVALUE;
                if (IS_ATOM_INT(_25596)) {
                    {unsigned long tu;
                         tu = (unsigned long)_35OpWarning_16035 & (unsigned long)_25596;
                         _35OpWarning_16035 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (double)_35OpWarning_16035;
                    _35OpWarning_16035 = Dand_bits(&temp_d, DBL_PTR(_25596));
                }
                DeRef(_25596);
                _25596 = NOVALUE;
                if (!IS_ATOM_INT(_35OpWarning_16035)) {
                    _1 = (long)(DBL_PTR(_35OpWarning_16035)->dbl);
                    DeRefDS(_35OpWarning_16035);
                    _35OpWarning_16035 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** 							option_w = -1*/
                _option_w_48950 = -1;

                /** 							OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (int)SEQ_PTR(_35warning_flags_16010);
                _25598 = (int)*(((s1_ptr)_2)->base + _n_49041);
                _35OpWarning_16035 = 32767 - _25598;
                _25598 = NOVALUE;
L17: 

                /** 						prev_OpWarning = OpWarning*/
                _35prev_OpWarning_16036 = _35OpWarning_16035;
L14: 
                DeRef(_this_warn_49033);
                _this_warn_49033 = NOVALUE;

                /** 				end for*/
                _i_49031 = _i_49031 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 722

            /** 			case "wf" then*/
            case 12:

            /** 				TempWarningName = val*/
            Ref(_val_48956);
            DeRef(_35TempWarningName_15982);
            _35TempWarningName_15982 = _val_48956;

            /** 			  	error:warning_file(TempWarningName)*/
            Ref(_35TempWarningName_15982);
            _7warning_file(_35TempWarningName_15982);
            goto L5; // [560] 722

            /** 			case "v", "version" then*/
            case 13:
            case 14:

            /** 				show_banner()*/
            _43show_banner();

            /** 				if not batch_job and not test_only then*/
            _25600 = (_35batch_job_15981 == 0);
            if (_25600 == 0) {
                goto L18; // [579] 632
            }
            _25602 = (_35test_only_15980 == 0);
            if (_25602 == 0)
            {
                DeRef(_25602);
                _25602 = NOVALUE;
                goto L18; // [589] 632
            }
            else{
                DeRef(_25602);
                _25602 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_21815);
            _25603 = _45GetMsgText(278, 0, _21815);
            DeRef(_prompt_inlined_maybe_any_key_at_615_49076);
            _prompt_inlined_maybe_any_key_at_615_49076 = _25603;
            _25603 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077 != 0){
                    goto L19; // [614] 629
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077)->dbl != 0.0){
                    goto L19; // [614] 629
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_615_49076);
            _5any_key(_prompt_inlined_maybe_any_key_at_615_49076, 2);

            /** end procedure*/
            goto L19; // [626] 629
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_615_49076);
            _prompt_inlined_maybe_any_key_at_615_49076 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49077 = NOVALUE;
L18: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [636] 722

            /** 			case "copyright" then*/
            case 15:

            /** 				show_copyrights()*/
            _43show_copyrights();

            /** 				if not batch_job and not test_only then*/
            _25604 = (_35batch_job_15981 == 0);
            if (_25604 == 0) {
                goto L1A; // [653] 706
            }
            _25606 = (_35test_only_15980 == 0);
            if (_25606 == 0)
            {
                DeRef(_25606);
                _25606 = NOVALUE;
                goto L1A; // [663] 706
            }
            else{
                DeRef(_25606);
                _25606 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_21815);
            _25607 = _45GetMsgText(278, 0, _21815);
            DeRef(_prompt_inlined_maybe_any_key_at_689_49088);
            _prompt_inlined_maybe_any_key_at_689_49088 = _25607;
            _25607 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089 != 0){
                    goto L1B; // [688] 703
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089)->dbl != 0.0){
                    goto L1B; // [688] 703
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_689_49088);
            _5any_key(_prompt_inlined_maybe_any_key_at_689_49088, 2);

            /** end procedure*/
            goto L1B; // [700] 703
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_689_49088);
            _prompt_inlined_maybe_any_key_at_689_49088 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49089 = NOVALUE;
L1A: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [710] 722

            /** 			case "eudir" then*/
            case 16:

            /** 				set_eudir( val )*/
            Ref(_val_48956);
            _36set_eudir(_val_48956);
        ;}L5: 
        DeRef(_key_48954);
        _key_48954 = NOVALUE;
        DeRef(_val_48956);
        _val_48956 = NOVALUE;

        /** 	end for*/
        _idx_48952 = _idx_48952 + 1;
        goto L1; // [726] 27
L2: 
        ;
    }

    /** 	if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_36LocalizeQual_15000)){
            _25608 = SEQ_PTR(_36LocalizeQual_15000)->length;
    }
    else {
        _25608 = 1;
    }
    if (_25608 != 0)
    goto L1C; // [738] 751

    /** 		LocalizeQual = {"en"}*/
    _0 = _36LocalizeQual_15000;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_25610);
    *((int *)(_2+4)) = _25610;
    _36LocalizeQual_15000 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1C: 

    /** end procedure*/
    DeRef(_opts_48947);
    DeRef(_opt_keys_48948);
    DeRef(_25600);
    _25600 = NOVALUE;
    DeRef(_25604);
    _25604 = NOVALUE;
    return;
    ;
}


void _43finalize_command_line(int _opts_49101)
{
    int _extras_49108 = NOVALUE;
    int _pairs_49113 = NOVALUE;
    int _pair_49118 = NOVALUE;
    int _25640 = NOVALUE;
    int _25638 = NOVALUE;
    int _25635 = NOVALUE;
    int _25634 = NOVALUE;
    int _25633 = NOVALUE;
    int _25632 = NOVALUE;
    int _25631 = NOVALUE;
    int _25630 = NOVALUE;
    int _25629 = NOVALUE;
    int _25628 = NOVALUE;
    int _25627 = NOVALUE;
    int _25626 = NOVALUE;
    int _25625 = NOVALUE;
    int _25624 = NOVALUE;
    int _25623 = NOVALUE;
    int _25622 = NOVALUE;
    int _25621 = NOVALUE;
    int _25620 = NOVALUE;
    int _25619 = NOVALUE;
    int _25618 = NOVALUE;
    int _25616 = NOVALUE;
    int _25613 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Strict_is_on then -- overrides any -W/-X switches*/
    if (_35Strict_is_on_16033 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** 		OpWarning = all_warning_flag*/
    _35OpWarning_16035 = 32767;

    /** 		prev_OpWarning = OpWarning*/
    _35prev_OpWarning_16036 = 32767;
L1: 

    /** 	sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_49101);
    RefDS(_4EXTRAS_13858);
    _0 = _extras_49108;
    _extras_49108 = _28get(_opts_49101, _4EXTRAS_13858, 0);
    DeRef(_0);

    /** 	if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_49108)){
            _25613 = SEQ_PTR(_extras_49108)->length;
    }
    else {
        _25613 = 1;
    }
    if (_25613 <= 0)
    goto L2; // [44] 270

    /** 		sequence pairs = m:pairs( opts )*/
    Ref(_opts_49101);
    _0 = _pairs_49113;
    _pairs_49113 = _28pairs(_opts_49101, 0);
    DeRef(_0);

    /** 		for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_49113)){
            _25616 = SEQ_PTR(_pairs_49113)->length;
    }
    else {
        _25616 = 1;
    }
    {
        int _i_49116;
        _i_49116 = 1;
L3: 
        if (_i_49116 > _25616){
            goto L4; // [62] 237
        }

        /** 			sequence pair = pairs[i]*/
        DeRef(_pair_49118);
        _2 = (int)SEQ_PTR(_pairs_49113);
        _pair_49118 = (int)*(((s1_ptr)_2)->base + _i_49116);
        Ref(_pair_49118);

        /** 			if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25618 = (int)*(((s1_ptr)_2)->base + 1);
        if (_25618 == _4EXTRAS_13858)
        _25619 = 1;
        else if (IS_ATOM_INT(_25618) && IS_ATOM_INT(_4EXTRAS_13858))
        _25619 = 0;
        else
        _25619 = (compare(_25618, _4EXTRAS_13858) == 0);
        _25618 = NOVALUE;
        if (_25619 == 0)
        {
            _25619 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25619 = NOVALUE;
        }

        /** 				continue*/
        DeRefDS(_pair_49118);
        _pair_49118 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** 			pair[1] = prepend( pair[1], '-' )*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25620 = (int)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25621, _25620, 45);
        _25620 = NOVALUE;
        _2 = (int)SEQ_PTR(_pair_49118);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _pair_49118 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _25621;
        if( _1 != _25621 ){
            DeRef(_1);
        }
        _25621 = NOVALUE;

        /** 			if sequence( pair[2] ) then*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25622 = (int)*(((s1_ptr)_2)->base + 2);
        _25623 = IS_SEQUENCE(_25622);
        _25622 = NOVALUE;
        if (_25623 == 0)
        {
            _25623 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25623 = NOVALUE;
        }

        /** 				if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25624 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25624)){
                _25625 = SEQ_PTR(_25624)->length;
        }
        else {
            _25625 = 1;
        }
        _25624 = NOVALUE;
        if (_25625 == 0) {
            goto L8; // [134] 203
        }
        _2 = (int)SEQ_PTR(_pair_49118);
        _25627 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_25627);
        _25628 = (int)*(((s1_ptr)_2)->base + 1);
        _25627 = NOVALUE;
        _25629 = IS_SEQUENCE(_25628);
        _25628 = NOVALUE;
        if (_25629 == 0)
        {
            _25629 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25629 = NOVALUE;
        }

        /** 					for j = 1 to length( pair[2] ) do*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25630 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25630)){
                _25631 = SEQ_PTR(_25630)->length;
        }
        else {
            _25631 = 1;
        }
        _25630 = NOVALUE;
        {
            int _j_49136;
            _j_49136 = 1;
L9: 
            if (_j_49136 > _25631){
                goto LA; // [162] 200
            }

            /** 						switches &= { pair[1], pair[2][j] }*/
            _2 = (int)SEQ_PTR(_pair_49118);
            _25632 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_pair_49118);
            _25633 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_25633);
            _25634 = (int)*(((s1_ptr)_2)->base + _j_49136);
            _25633 = NOVALUE;
            Ref(_25634);
            Ref(_25632);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _25632;
            ((int *)_2)[2] = _25634;
            _25635 = MAKE_SEQ(_1);
            _25634 = NOVALUE;
            _25632 = NOVALUE;
            Concat((object_ptr)&_43switches_48480, _43switches_48480, _25635);
            DeRefDS(_25635);
            _25635 = NOVALUE;

            /** 					end for*/
            _j_49136 = _j_49136 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** 					switches &= pair*/
        Concat((object_ptr)&_43switches_48480, _43switches_48480, _pair_49118);
        goto LB; // [212] 228
L7: 

        /** 				switches = append( switches, pair[1] )*/
        _2 = (int)SEQ_PTR(_pair_49118);
        _25638 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_25638);
        Append(&_43switches_48480, _43switches_48480, _25638);
        _25638 = NOVALUE;
LB: 
        DeRef(_pair_49118);
        _pair_49118 = NOVALUE;

        /** 		end for*/
L6: 
        _i_49116 = _i_49116 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** 		Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25640;
    RHS_Slice(_35Argv_15979, 2, 3);
    Concat((object_ptr)&_35Argv_15979, _25640, _extras_49108);
    DeRefDS(_25640);
    _25640 = NOVALUE;
    DeRef(_25640);
    _25640 = NOVALUE;

    /** 		Argc = length(Argv)*/
    if (IS_SEQUENCE(_35Argv_15979)){
            _35Argc_15978 = SEQ_PTR(_35Argv_15979)->length;
    }
    else {
        _35Argc_15978 = 1;
    }

    /** 		src_name = extras[1]*/
    DeRef(_43src_name_48479);
    _2 = (int)SEQ_PTR(_extras_49108);
    _43src_name_48479 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_43src_name_48479);
L2: 
    DeRef(_pairs_49113);
    _pairs_49113 = NOVALUE;

    /** end procedure*/
    DeRef(_opts_49101);
    DeRef(_extras_49108);
    _25624 = NOVALUE;
    _25630 = NOVALUE;
    return;
    ;
}



// 0x1592187D
