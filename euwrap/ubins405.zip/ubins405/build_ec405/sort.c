// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _24sort(int _x_3855, int _order_3856)
{
    int _gap_3857 = NOVALUE;
    int _j_3858 = NOVALUE;
    int _first_3859 = NOVALUE;
    int _last_3860 = NOVALUE;
    int _tempi_3861 = NOVALUE;
    int _tempj_3862 = NOVALUE;
    int _1896 = NOVALUE;
    int _1892 = NOVALUE;
    int _1889 = NOVALUE;
    int _1885 = NOVALUE;
    int _1882 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3856 = -1;
    goto L1; // [16] 25

    /** 		order = 1*/
    _order_3856 = 1;
L1: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3855)){
            _last_3860 = SEQ_PTR(_x_3855)->length;
    }
    else {
        _last_3860 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3860 >= 0) {
        _1882 = _last_3860 / 10;
    }
    else {
        temp_dbl = floor((double)_last_3860 / (double)10);
        _1882 = (long)temp_dbl;
    }
    _gap_3857 = _1882 + 1;
    _1882 = NOVALUE;

    /** 	while 1 do*/
L2: 

    /** 		first = gap + 1*/
    _first_3859 = _gap_3857 + 1;

    /** 		for i = first to last do*/
    _1885 = _last_3860;
    {
        int _i_3872;
        _i_3872 = _first_3859;
L3: 
        if (_i_3872 > _1885){
            goto L4; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_3861);
        _2 = (int)SEQ_PTR(_x_3855);
        _tempi_3861 = (int)*(((s1_ptr)_2)->base + _i_3872);
        Ref(_tempi_3861);

        /** 			j = i - gap*/
        _j_3858 = _i_3872 - _gap_3857;

        /** 			while 1 do*/
L5: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_3862);
        _2 = (int)SEQ_PTR(_x_3855);
        _tempj_3862 = (int)*(((s1_ptr)_2)->base + _j_3858);
        Ref(_tempj_3862);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_3861) && IS_ATOM_INT(_tempj_3862)){
            _1889 = (_tempi_3861 < _tempj_3862) ? -1 : (_tempi_3861 > _tempj_3862);
        }
        else{
            _1889 = compare(_tempi_3861, _tempj_3862);
        }
        if (_1889 == _order_3856)
        goto L6; // [92] 107

        /** 					j += gap*/
        _j_3858 = _j_3858 + _gap_3857;

        /** 					exit*/
        goto L7; // [104] 139
L6: 

        /** 				x[j+gap] = tempj*/
        _1892 = _j_3858 + _gap_3857;
        Ref(_tempj_3862);
        _2 = (int)SEQ_PTR(_x_3855);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3855 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1892);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3862;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3858 > _gap_3857)
        goto L8; // [119] 128

        /** 					exit*/
        goto L7; // [125] 139
L8: 

        /** 				j -= gap*/
        _j_3858 = _j_3858 - _gap_3857;

        /** 			end while*/
        goto L5; // [136] 80
L7: 

        /** 			x[j] = tempi*/
        Ref(_tempi_3861);
        _2 = (int)SEQ_PTR(_x_3855);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3855 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3858);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3861;
        DeRef(_1);

        /** 		end for*/
        _i_3872 = _i_3872 + 1;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3857 != 1)
    goto L9; // [154] 167

    /** 			return x*/
    DeRef(_tempi_3861);
    DeRef(_tempj_3862);
    DeRef(_1892);
    _1892 = NOVALUE;
    return _x_3855;
    goto L2; // [164] 45
L9: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3857 >= 0) {
        _1896 = _gap_3857 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3857 / (double)7);
        _1896 = (long)temp_dbl;
    }
    _gap_3857 = _1896 + 1;
    _1896 = NOVALUE;

    /** 	end while*/
    goto L2; // [180] 45
    ;
}


int _24custom_sort(int _custom_compare_3893, int _x_3894, int _data_3895, int _order_3896)
{
    int _gap_3897 = NOVALUE;
    int _j_3898 = NOVALUE;
    int _first_3899 = NOVALUE;
    int _last_3900 = NOVALUE;
    int _tempi_3901 = NOVALUE;
    int _tempj_3902 = NOVALUE;
    int _result_3903 = NOVALUE;
    int _args_3904 = NOVALUE;
    int _1924 = NOVALUE;
    int _1920 = NOVALUE;
    int _1917 = NOVALUE;
    int _1915 = NOVALUE;
    int _1914 = NOVALUE;
    int _1909 = NOVALUE;
    int _1906 = NOVALUE;
    int _1902 = NOVALUE;
    int _1900 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence args = {0, 0}*/
    DeRef(_args_3904);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_3904 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3896 = -1;
    goto L1; // [24] 33

    /** 		order = 1*/
    _order_3896 = 1;
L1: 

    /** 	if atom(data) then*/
    _1900 = IS_ATOM(_data_3895);
    if (_1900 == 0)
    {
        _1900 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1900 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_3904) && IS_ATOM(_data_3895)) {
        Ref(_data_3895);
        Append(&_args_3904, _args_3904, _data_3895);
    }
    else if (IS_ATOM(_args_3904) && IS_SEQUENCE(_data_3895)) {
    }
    else {
        Concat((object_ptr)&_args_3904, _args_3904, _data_3895);
    }
    goto L3; // [47] 70
L2: 

    /** 	elsif length(data) then*/
    _1902 = 0;
L3: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3894)){
            _last_3900 = SEQ_PTR(_x_3894)->length;
    }
    else {
        _last_3900 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3900 >= 0) {
        _1906 = _last_3900 / 10;
    }
    else {
        temp_dbl = floor((double)_last_3900 / (double)10);
        _1906 = (long)temp_dbl;
    }
    _gap_3897 = _1906 + 1;
    _1906 = NOVALUE;

    /** 	while 1 do*/
L4: 

    /** 		first = gap + 1*/
    _first_3899 = _gap_3897 + 1;

    /** 		for i = first to last do*/
    _1909 = _last_3900;
    {
        int _i_3922;
        _i_3922 = _first_3899;
L5: 
        if (_i_3922 > _1909){
            goto L6; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_3901);
        _2 = (int)SEQ_PTR(_x_3894);
        _tempi_3901 = (int)*(((s1_ptr)_2)->base + _i_3922);
        Ref(_tempi_3901);

        /** 			args[1] = tempi*/
        Ref(_tempi_3901);
        _2 = (int)SEQ_PTR(_args_3904);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3901;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_3898 = _i_3922 - _gap_3897;

        /** 			while 1 do*/
L7: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_3902);
        _2 = (int)SEQ_PTR(_x_3894);
        _tempj_3902 = (int)*(((s1_ptr)_2)->base + _j_3898);
        Ref(_tempj_3902);

        /** 				args[2] = tempj*/
        Ref(_tempj_3902);
        _2 = (int)SEQ_PTR(_args_3904);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3902;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_3904);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_3893].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
            case 7:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28)
                                     );
                break;
            case 8:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32)
                                     );
                break;
            case 9:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                Ref(*(int *)(_2+36));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32), 
                                    *(int *)(_2+36)
                                     );
                break;
        }
        DeRef(_result_3903);
        _result_3903 = _1;

        /** 				if sequence(result) then*/
        _1914 = IS_SEQUENCE(_result_3903);
        if (_1914 == 0)
        {
            _1914 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1914 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_3903);
        _1915 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_1915);
        _2 = (int)SEQ_PTR(_args_3904);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _1915;
        if( _1 != _1915 ){
            DeRef(_1);
        }
        _1915 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_3903;
        _2 = (int)SEQ_PTR(_result_3903);
        _result_3903 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_3903);
        DeRef(_0);
L8: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_3903) && IS_ATOM_INT(0)){
            _1917 = (_result_3903 < 0) ? -1 : (_result_3903 > 0);
        }
        else{
            _1917 = compare(_result_3903, 0);
        }
        if (_1917 == _order_3896)
        goto L9; // [180] 195

        /** 					j += gap*/
        _j_3898 = _j_3898 + _gap_3897;

        /** 					exit*/
        goto LA; // [192] 227
L9: 

        /** 				x[j+gap] = tempj*/
        _1920 = _j_3898 + _gap_3897;
        Ref(_tempj_3902);
        _2 = (int)SEQ_PTR(_x_3894);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3894 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1920);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3902;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3898 > _gap_3897)
        goto LB; // [207] 216

        /** 					exit*/
        goto LA; // [213] 227
LB: 

        /** 				j -= gap*/
        _j_3898 = _j_3898 - _gap_3897;

        /** 			end while*/
        goto L7; // [224] 131
LA: 

        /** 			x[j] = tempi*/
        Ref(_tempi_3901);
        _2 = (int)SEQ_PTR(_x_3894);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3894 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3898);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3901;
        DeRef(_1);

        /** 		end for*/
        _i_3922 = _i_3922 + 1;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3897 != 1)
    goto LC; // [242] 255

    /** 			return x*/
    DeRef(_data_3895);
    DeRef(_tempi_3901);
    DeRef(_tempj_3902);
    DeRef(_result_3903);
    DeRef(_args_3904);
    DeRef(_1920);
    _1920 = NOVALUE;
    return _x_3894;
    goto L4; // [252] 90
LC: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3897 >= 0) {
        _1924 = _gap_3897 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3897 / (double)7);
        _1924 = (long)temp_dbl;
    }
    _gap_3897 = _1924 + 1;
    _1924 = NOVALUE;

    /** 	end while*/
    goto L4; // [268] 90
    ;
}


int _24column_compare(int _a_3948, int _b_3949, int _cols_3950)
{
    int _sign_3951 = NOVALUE;
    int _column_3952 = NOVALUE;
    int _1947 = NOVALUE;
    int _1945 = NOVALUE;
    int _1944 = NOVALUE;
    int _1943 = NOVALUE;
    int _1942 = NOVALUE;
    int _1941 = NOVALUE;
    int _1940 = NOVALUE;
    int _1938 = NOVALUE;
    int _1937 = NOVALUE;
    int _1936 = NOVALUE;
    int _1934 = NOVALUE;
    int _1932 = NOVALUE;
    int _1929 = NOVALUE;
    int _1927 = NOVALUE;
    int _1926 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_3950)){
            _1926 = SEQ_PTR(_cols_3950)->length;
    }
    else {
        _1926 = 1;
    }
    {
        int _i_3954;
        _i_3954 = 1;
L1: 
        if (_i_3954 > _1926){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_3950);
        _1927 = (int)*(((s1_ptr)_2)->base + _i_3954);
        if (binary_op_a(GREATEREQ, _1927, 0)){
            _1927 = NOVALUE;
            goto L3; // [19] 42
        }
        _1927 = NOVALUE;

        /** 			sign = -1*/
        _sign_3951 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_3950);
        _1929 = (int)*(((s1_ptr)_2)->base + _i_3954);
        if (IS_ATOM_INT(_1929)) {
            if ((unsigned long)_1929 == 0xC0000000)
            _column_3952 = (int)NewDouble((double)-0xC0000000);
            else
            _column_3952 = - _1929;
        }
        else {
            _column_3952 = unary_op(UMINUS, _1929);
        }
        _1929 = NOVALUE;
        if (!IS_ATOM_INT(_column_3952)) {
            _1 = (long)(DBL_PTR(_column_3952)->dbl);
            DeRefDS(_column_3952);
            _column_3952 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_3951 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_3950);
        _column_3952 = (int)*(((s1_ptr)_2)->base + _i_3954);
        if (!IS_ATOM_INT(_column_3952)){
            _column_3952 = (long)DBL_PTR(_column_3952)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_3948)){
                _1932 = SEQ_PTR(_a_3948)->length;
        }
        else {
            _1932 = 1;
        }
        if (_column_3952 > _1932)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3949)){
                _1934 = SEQ_PTR(_b_3949)->length;
        }
        else {
            _1934 = 1;
        }
        if (_column_3952 > _1934)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_3948);
        _1936 = (int)*(((s1_ptr)_2)->base + _column_3952);
        _2 = (int)SEQ_PTR(_b_3949);
        _1937 = (int)*(((s1_ptr)_2)->base + _column_3952);
        if (_1936 == _1937)
        _1938 = 1;
        else if (IS_ATOM_INT(_1936) && IS_ATOM_INT(_1937))
        _1938 = 0;
        else
        _1938 = (compare(_1936, _1937) == 0);
        _1936 = NOVALUE;
        _1937 = NOVALUE;
        if (_1938 != 0)
        goto L7; // [90] 169
        _1938 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_3948);
        _1940 = (int)*(((s1_ptr)_2)->base + _column_3952);
        _2 = (int)SEQ_PTR(_b_3949);
        _1941 = (int)*(((s1_ptr)_2)->base + _column_3952);
        if (IS_ATOM_INT(_1940) && IS_ATOM_INT(_1941)){
            _1942 = (_1940 < _1941) ? -1 : (_1940 > _1941);
        }
        else{
            _1942 = compare(_1940, _1941);
        }
        _1940 = NOVALUE;
        _1941 = NOVALUE;
        if (_sign_3951 == (short)_sign_3951)
        _1943 = _sign_3951 * _1942;
        else
        _1943 = NewDouble(_sign_3951 * (double)_1942);
        _1942 = NOVALUE;
        DeRef(_a_3948);
        DeRef(_b_3949);
        DeRef(_cols_3950);
        return _1943;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_3951 == (short)_sign_3951)
        _1944 = _sign_3951 * -1;
        else
        _1944 = NewDouble(_sign_3951 * (double)-1);
        DeRef(_a_3948);
        DeRef(_b_3949);
        DeRef(_cols_3950);
        DeRef(_1943);
        _1943 = NOVALUE;
        return _1944;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3949)){
                _1945 = SEQ_PTR(_b_3949)->length;
        }
        else {
            _1945 = 1;
        }
        if (_column_3952 > _1945)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _1947 = _sign_3951 * 1;
        DeRef(_a_3948);
        DeRef(_b_3949);
        DeRef(_cols_3950);
        DeRef(_1943);
        _1943 = NOVALUE;
        DeRef(_1944);
        _1944 = NOVALUE;
        return _1947;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_3948);
        DeRef(_b_3949);
        DeRef(_cols_3950);
        DeRef(_1943);
        _1943 = NOVALUE;
        DeRef(_1944);
        _1944 = NOVALUE;
        DeRef(_1947);
        _1947 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_3954 = _i_3954 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_3948);
    DeRef(_b_3949);
    DeRef(_cols_3950);
    DeRef(_1943);
    _1943 = NOVALUE;
    DeRef(_1944);
    _1944 = NOVALUE;
    DeRef(_1947);
    _1947 = NOVALUE;
    return 0;
    ;
}



// 0x7803F9A6
