// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _56iif(int _test_21542, int _ifTrue_21543, int _ifFalse_21544)
{
    int _0, _1, _2;
    

    /** 	if test then*/
    if (_test_21542 == 0)
    {
        goto L1; // [3] 13
    }
    else{
    }

    /** 		return ifTrue*/
    DeRefDS(_ifFalse_21544);
    return _ifTrue_21543;
L1: 

    /** 	return ifFalse*/
    DeRef(_ifTrue_21543);
    return _ifFalse_21544;
    ;
}



// 0x424BAF34
