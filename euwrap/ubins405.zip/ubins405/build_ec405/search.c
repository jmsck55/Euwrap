// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _16find_all(int _needle_1306, int _haystack_1307, int _start_1308)
{
    int _kx_1309 = NOVALUE;
    int _504 = NOVALUE;
    int _503 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer kx = 0*/
    _kx_1309 = 0;

    /** 	while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1308 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** 		kx += 1*/
    _kx_1309 = _kx_1309 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_1307);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1307 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_1309);
    _1 = *(int *)_2;
    *(int *)_2 = _start_1308;
    DeRef(_1);

    /** 		start += 1*/
    _start_1308 = _start_1308 + 1;

    /** 	entry*/
L1: 

    /** 		start = find(needle, haystack, start)*/
    _start_1308 = find_from(_needle_1306, _haystack_1307, _start_1308);

    /** 	end while*/
    goto L2; // [48] 15
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _503 = _kx_1309 + 1;
    if (_503 > MAXINT){
        _503 = NewDouble((double)_503);
    }
    if (IS_SEQUENCE(_haystack_1307)){
            _504 = SEQ_PTR(_haystack_1307)->length;
    }
    else {
        _504 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1307);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_503)) ? _503 : (long)(DBL_PTR(_503)->dbl);
        int stop = (IS_ATOM_INT(_504)) ? _504 : (long)(DBL_PTR(_504)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1307), start, &_haystack_1307 );
            }
            else Tail(SEQ_PTR(_haystack_1307), stop+1, &_haystack_1307);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1307), start, &_haystack_1307);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1307 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1307)->ref == 1));
        }
    }
    DeRef(_503);
    _503 = NOVALUE;
    _504 = NOVALUE;

    /** 	return haystack*/
    return _haystack_1307;
    ;
}


int _16rfind(int _needle_1424, int _haystack_1425, int _start_1426)
{
    int _len_1428 = NOVALUE;
    int _565 = NOVALUE;
    int _564 = NOVALUE;
    int _561 = NOVALUE;
    int _560 = NOVALUE;
    int _558 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1425)){
            _len_1428 = SEQ_PTR(_haystack_1425)->length;
    }
    else {
        _len_1428 = 1;
    }

    /** 	if start = 0 then start = len end if*/
    if (_start_1426 != 0)
    goto L1; // [12] 20
    _start_1426 = _len_1428;
L1: 

    /** 	if (start > len) or (len + start < 1) then*/
    _558 = (_start_1426 > _len_1428);
    if (_558 != 0) {
        goto L2; // [26] 43
    }
    _560 = _len_1428 + _start_1426;
    if ((long)((unsigned long)_560 + (unsigned long)HIGH_BITS) >= 0) 
    _560 = NewDouble((double)_560);
    if (IS_ATOM_INT(_560)) {
        _561 = (_560 < 1);
    }
    else {
        _561 = (DBL_PTR(_560)->dbl < (double)1);
    }
    DeRef(_560);
    _560 = NOVALUE;
    if (_561 == 0)
    {
        DeRef(_561);
        _561 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_561);
        _561 = NOVALUE;
    }
L2: 

    /** 		return 0*/
    DeRef(_needle_1424);
    DeRefDS(_haystack_1425);
    DeRef(_558);
    _558 = NOVALUE;
    return 0;
L3: 

    /** 	if start < 1 then*/
    if (_start_1426 >= 1)
    goto L4; // [52] 63

    /** 		start = len + start*/
    _start_1426 = _len_1428 + _start_1426;
L4: 

    /** 	for i = start to 1 by -1 do*/
    {
        int _i_1441;
        _i_1441 = _start_1426;
L5: 
        if (_i_1441 < 1){
            goto L6; // [65] 99
        }

        /** 		if equal(haystack[i], needle) then*/
        _2 = (int)SEQ_PTR(_haystack_1425);
        _564 = (int)*(((s1_ptr)_2)->base + _i_1441);
        if (_564 == _needle_1424)
        _565 = 1;
        else if (IS_ATOM_INT(_564) && IS_ATOM_INT(_needle_1424))
        _565 = 0;
        else
        _565 = (compare(_564, _needle_1424) == 0);
        _564 = NOVALUE;
        if (_565 == 0)
        {
            _565 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _565 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needle_1424);
        DeRefDS(_haystack_1425);
        DeRef(_558);
        _558 = NOVALUE;
        return _i_1441;
L7: 

        /** 	end for*/
        _i_1441 = _i_1441 + -1;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** 	return 0*/
    DeRef(_needle_1424);
    DeRefDS(_haystack_1425);
    DeRef(_558);
    _558 = NOVALUE;
    return 0;
    ;
}


int _16find_replace(int _needle_1447, int _haystack_1448, int _replacement_1449, int _max_1450)
{
    int _posn_1451 = NOVALUE;
    int _569 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer posn = 0*/
    _posn_1451 = 0;

    /** 	while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1451 == 0)
    goto L3; // [15] 61

    /** 		haystack[posn] = replacement*/
    Ref(_replacement_1449);
    _2 = (int)SEQ_PTR(_haystack_1448);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1448 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _posn_1451);
    _1 = *(int *)_2;
    *(int *)_2 = _replacement_1449;
    DeRef(_1);

    /** 		max -= 1*/
    _max_1450 = _max_1450 - 1;

    /** 		if max = 0 then*/
    if (_max_1450 != 0)
    goto L4; // [33] 42

    /** 			exit*/
    goto L3; // [39] 61
L4: 

    /** 	entry*/
L1: 

    /** 		posn = find(needle, haystack, posn + 1)*/
    _569 = _posn_1451 + 1;
    if (_569 > MAXINT){
        _569 = NewDouble((double)_569);
    }
    _posn_1451 = find_from(_needle_1447, _haystack_1448, _569);
    DeRef(_569);
    _569 = NOVALUE;

    /** 	end while*/
    goto L2; // [58] 15
L3: 

    /** 	return haystack*/
    DeRef(_needle_1447);
    DeRefi(_replacement_1449);
    return _haystack_1448;
    ;
}


int _16match_replace(int _needle_1461, int _haystack_1462, int _replacement_1463, int _max_1464)
{
    int _posn_1465 = NOVALUE;
    int _needle_len_1466 = NOVALUE;
    int _replacement_len_1467 = NOVALUE;
    int _scan_from_1468 = NOVALUE;
    int _cnt_1469 = NOVALUE;
    int _581 = NOVALUE;
    int _578 = NOVALUE;
    int _576 = NOVALUE;
    int _574 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if max < 0 then*/

    /** 	cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1462)){
            _cnt_1469 = SEQ_PTR(_haystack_1462)->length;
    }
    else {
        _cnt_1469 = 1;
    }

    /** 	if max != 0 then*/

    /** 	if atom(needle) then*/
    _574 = IS_ATOM(_needle_1461);
    if (_574 == 0)
    {
        _574 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _574 = NOVALUE;
    }

    /** 		needle = {needle}*/
    _0 = _needle_1461;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needle_1461);
    *((int *)(_2+4)) = _needle_1461;
    _needle_1461 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if atom(replacement) then*/
    _576 = IS_ATOM(_replacement_1463);
    if (_576 == 0)
    {
        _576 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _576 = NOVALUE;
    }

    /** 		replacement = {replacement}*/
    _0 = _replacement_1463;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_replacement_1463);
    *((int *)(_2+4)) = _replacement_1463;
    _replacement_1463 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1461)){
            _578 = SEQ_PTR(_needle_1461)->length;
    }
    else {
        _578 = 1;
    }
    _needle_len_1466 = _578 - 1;
    _578 = NOVALUE;

    /** 	replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1463)){
            _replacement_len_1467 = SEQ_PTR(_replacement_1463)->length;
    }
    else {
        _replacement_len_1467 = 1;
    }

    /** 	scan_from = 1*/
    _scan_from_1468 = 1;

    /** 	while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1465 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** 		haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _581 = _posn_1465 + _needle_len_1466;
    if ((long)((unsigned long)_581 + (unsigned long)HIGH_BITS) >= 0) 
    _581 = NewDouble((double)_581);
    {
        int p1 = _haystack_1462;
        int p2 = _replacement_1463;
        int p3 = _posn_1465;
        int p4 = _581;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1462;
        Replace( &replace_params );
    }
    DeRef(_581);
    _581 = NOVALUE;

    /** 		cnt -= 1*/
    _cnt_1469 = _cnt_1469 - 1;

    /** 		if cnt = 0 then*/
    if (_cnt_1469 != 0)
    goto L6; // [114] 123

    /** 			exit*/
    goto L5; // [120] 144
L6: 

    /** 		scan_from = posn + replacement_len*/
    _scan_from_1468 = _posn_1465 + _replacement_len_1467;

    /** 	entry*/
L3: 

    /** 		posn = match(needle, haystack, scan_from)*/
    _posn_1465 = e_match_from(_needle_1461, _haystack_1462, _scan_from_1468);

    /** 	end while*/
    goto L4; // [141] 89
L5: 

    /** 	return haystack*/
    DeRef(_needle_1461);
    DeRef(_replacement_1463);
    return _haystack_1462;
    ;
}


int _16binary_search(int _needle_1494, int _haystack_1495, int _start_point_1496, int _end_point_1497)
{
    int _lo_1498 = NOVALUE;
    int _hi_1499 = NOVALUE;
    int _mid_1500 = NOVALUE;
    int _c_1501 = NOVALUE;
    int _607 = NOVALUE;
    int _599 = NOVALUE;
    int _597 = NOVALUE;
    int _594 = NOVALUE;
    int _593 = NOVALUE;
    int _592 = NOVALUE;
    int _591 = NOVALUE;
    int _588 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lo = start_point*/
    _lo_1498 = 1;

    /** 	if end_point <= 0 then*/
    if (_end_point_1497 > 0)
    goto L1; // [14] 30

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_1495)){
            _588 = SEQ_PTR(_haystack_1495)->length;
    }
    else {
        _588 = 1;
    }
    _hi_1499 = _588 + _end_point_1497;
    _588 = NOVALUE;
    goto L2; // [27] 36
L1: 

    /** 		hi = end_point*/
    _hi_1499 = _end_point_1497;
L2: 

    /** 	if lo<1 then*/
    if (_lo_1498 >= 1)
    goto L3; // [38] 48

    /** 		lo=1*/
    _lo_1498 = 1;
L3: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _591 = (_lo_1498 > _hi_1499);
    if (_591 == 0) {
        goto L4; // [56] 77
    }
    if (IS_SEQUENCE(_haystack_1495)){
            _593 = SEQ_PTR(_haystack_1495)->length;
    }
    else {
        _593 = 1;
    }
    _594 = (_593 > 0);
    _593 = NOVALUE;
    if (_594 == 0)
    {
        DeRef(_594);
        _594 = NOVALUE;
        goto L4; // [68] 77
    }
    else{
        DeRef(_594);
        _594 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1495)){
            _hi_1499 = SEQ_PTR(_haystack_1495)->length;
    }
    else {
        _hi_1499 = 1;
    }
L4: 

    /** 	mid = start_point*/
    _mid_1500 = _start_point_1496;

    /** 	c = 0*/
    _c_1501 = 0;

    /** 	while lo <= hi do*/
L5: 
    if (_lo_1498 > _hi_1499)
    goto L6; // [92] 160

    /** 		mid = floor((lo + hi) / 2)*/
    _597 = _lo_1498 + _hi_1499;
    if ((long)((unsigned long)_597 + (unsigned long)HIGH_BITS) >= 0) 
    _597 = NewDouble((double)_597);
    if (IS_ATOM_INT(_597)) {
        _mid_1500 = _597 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _597, 2);
        _mid_1500 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_597);
    _597 = NOVALUE;
    if (!IS_ATOM_INT(_mid_1500)) {
        _1 = (long)(DBL_PTR(_mid_1500)->dbl);
        DeRefDS(_mid_1500);
        _mid_1500 = _1;
    }

    /** 		c = eu:compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_1495);
    _599 = (int)*(((s1_ptr)_2)->base + _mid_1500);
    if (IS_ATOM_INT(_needle_1494) && IS_ATOM_INT(_599)){
        _c_1501 = (_needle_1494 < _599) ? -1 : (_needle_1494 > _599);
    }
    else{
        _c_1501 = compare(_needle_1494, _599);
    }
    _599 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_1501 >= 0)
    goto L7; // [120] 133

    /** 			hi = mid - 1*/
    _hi_1499 = _mid_1500 - 1;
    goto L5; // [130] 92
L7: 

    /** 		elsif c > 0 then*/
    if (_c_1501 <= 0)
    goto L8; // [135] 148

    /** 			lo = mid + 1*/
    _lo_1498 = _mid_1500 + 1;
    goto L5; // [145] 92
L8: 

    /** 			return mid*/
    DeRefDS(_haystack_1495);
    DeRef(_591);
    _591 = NOVALUE;
    return _mid_1500;

    /** 	end while*/
    goto L5; // [157] 92
L6: 

    /** 	if c > 0 then*/
    if (_c_1501 <= 0)
    goto L9; // [162] 173

    /** 		mid += 1*/
    _mid_1500 = _mid_1500 + 1;
L9: 

    /** 	return -mid*/
    if ((unsigned long)_mid_1500 == 0xC0000000)
    _607 = (int)NewDouble((double)-0xC0000000);
    else
    _607 = - _mid_1500;
    DeRefDS(_haystack_1495);
    DeRef(_591);
    _591 = NOVALUE;
    return _607;
    ;
}


int _16begins(int _sub_text_1582, int _full_text_1583)
{
    int _645 = NOVALUE;
    int _644 = NOVALUE;
    int _643 = NOVALUE;
    int _641 = NOVALUE;
    int _640 = NOVALUE;
    int _639 = NOVALUE;
    int _638 = NOVALUE;
    int _637 = NOVALUE;
    int _635 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1583)){
            _635 = SEQ_PTR(_full_text_1583)->length;
    }
    else {
        _635 = 1;
    }
    if (_635 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _637 = IS_ATOM(_sub_text_1582);
    if (_637 == 0)
    {
        _637 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _637 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[1]) then*/
    _2 = (int)SEQ_PTR(_full_text_1583);
    _638 = (int)*(((s1_ptr)_2)->base + 1);
    if (_sub_text_1582 == _638)
    _639 = 1;
    else if (IS_ATOM_INT(_sub_text_1582) && IS_ATOM_INT(_638))
    _639 = 0;
    else
    _639 = (compare(_sub_text_1582, _638) == 0);
    _638 = NOVALUE;
    if (_639 == 0)
    {
        _639 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _639 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 1;
    goto L4; // [46] 56
L3: 

    /** 			return 0*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1582)){
            _640 = SEQ_PTR(_sub_text_1582)->length;
    }
    else {
        _640 = 1;
    }
    if (IS_SEQUENCE(_full_text_1583)){
            _641 = SEQ_PTR(_full_text_1583)->length;
    }
    else {
        _641 = 1;
    }
    if (_640 <= _641)
    goto L5; // [65] 76

    /** 		return 0*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1582)){
            _643 = SEQ_PTR(_sub_text_1582)->length;
    }
    else {
        _643 = 1;
    }
    rhs_slice_target = (object_ptr)&_644;
    RHS_Slice(_full_text_1583, 1, _643);
    if (_sub_text_1582 == _644)
    _645 = 1;
    else if (IS_ATOM_INT(_sub_text_1582) && IS_ATOM_INT(_644))
    _645 = 0;
    else
    _645 = (compare(_sub_text_1582, _644) == 0);
    DeRefDS(_644);
    _644 = NOVALUE;
    if (_645 == 0)
    {
        _645 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _645 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 1;
    goto L7; // [99] 109
L6: 

    /** 		return 0*/
    DeRef(_sub_text_1582);
    DeRefDS(_full_text_1583);
    return 0;
L7: 
    ;
}


int _16ends(int _sub_text_1604, int _full_text_1605)
{
    int _661 = NOVALUE;
    int _660 = NOVALUE;
    int _659 = NOVALUE;
    int _658 = NOVALUE;
    int _657 = NOVALUE;
    int _656 = NOVALUE;
    int _655 = NOVALUE;
    int _653 = NOVALUE;
    int _652 = NOVALUE;
    int _651 = NOVALUE;
    int _650 = NOVALUE;
    int _649 = NOVALUE;
    int _648 = NOVALUE;
    int _646 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1605)){
            _646 = SEQ_PTR(_full_text_1605)->length;
    }
    else {
        _646 = 1;
    }
    if (_646 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDSi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _648 = IS_ATOM(_sub_text_1604);
    if (_648 == 0)
    {
        _648 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _648 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1605)){
            _649 = SEQ_PTR(_full_text_1605)->length;
    }
    else {
        _649 = 1;
    }
    _2 = (int)SEQ_PTR(_full_text_1605);
    _650 = (int)*(((s1_ptr)_2)->base + _649);
    if (_sub_text_1604 == _650)
    _651 = 1;
    else if (IS_ATOM_INT(_sub_text_1604) && IS_ATOM_INT(_650))
    _651 = 0;
    else
    _651 = (compare(_sub_text_1604, _650) == 0);
    _650 = NOVALUE;
    if (_651 == 0)
    {
        _651 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _651 = NOVALUE;
    }

    /** 			return 1*/
    DeRefi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    return 1;
    goto L4; // [49] 59
L3: 

    /** 			return 0*/
    DeRefi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1604)){
            _652 = SEQ_PTR(_sub_text_1604)->length;
    }
    else {
        _652 = 1;
    }
    if (IS_SEQUENCE(_full_text_1605)){
            _653 = SEQ_PTR(_full_text_1605)->length;
    }
    else {
        _653 = 1;
    }
    if (_652 <= _653)
    goto L5; // [68] 79

    /** 		return 0*/
    DeRefi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1605)){
            _655 = SEQ_PTR(_full_text_1605)->length;
    }
    else {
        _655 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1604)){
            _656 = SEQ_PTR(_sub_text_1604)->length;
    }
    else {
        _656 = 1;
    }
    _657 = _655 - _656;
    _655 = NOVALUE;
    _656 = NOVALUE;
    _658 = _657 + 1;
    _657 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1605)){
            _659 = SEQ_PTR(_full_text_1605)->length;
    }
    else {
        _659 = 1;
    }
    rhs_slice_target = (object_ptr)&_660;
    RHS_Slice(_full_text_1605, _658, _659);
    if (_sub_text_1604 == _660)
    _661 = 1;
    else if (IS_ATOM_INT(_sub_text_1604) && IS_ATOM_INT(_660))
    _661 = 0;
    else
    _661 = (compare(_sub_text_1604, _660) == 0);
    DeRefDS(_660);
    _660 = NOVALUE;
    if (_661 == 0)
    {
        _661 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _661 = NOVALUE;
    }

    /** 		return 1*/
    DeRefi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    _658 = NOVALUE;
    return 1;
    goto L7; // [116] 126
L6: 

    /** 		return 0*/
    DeRefi(_sub_text_1604);
    DeRefDS(_full_text_1605);
    DeRef(_658);
    _658 = NOVALUE;
    return 0;
L7: 
    ;
}



// 0x6E924A1A
