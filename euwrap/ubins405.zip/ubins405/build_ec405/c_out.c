// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _54c_putc(int _c_45132)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_45132)) {
        _1 = (long)(DBL_PTR(_c_45132)->dbl);
        DeRefDS(_c_45132);
        _c_45132 = _1;
    }

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c)*/
    EPuts(_54c_code_45122, _c_45132); // DJP 

    /** 		update_checksum( c )*/
    _55update_checksum(_c_45132);
L1: 

    /** end procedure*/
    return;
    ;
}


void _54c_hputs(int _c_source_45137)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		puts(c_h, c_source)    */
    EPuts(_54c_h_45123, _c_source_45137); // DJP 
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45137);
    return;
    ;
}


void _54c_puts(int _c_source_45141)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [7] 23
    }
    else{
    }

    /** 		puts(c_code, c_source)*/
    EPuts(_54c_code_45122, _c_source_45141); // DJP 

    /** 		update_checksum( c_source )*/
    RefDS(_c_source_45141);
    _55update_checksum(_c_source_45141);
L1: 

    /** end procedure*/
    DeRefDS(_c_source_45141);
    return;
    ;
}


void _54c_hprintf(int _format_45146, int _value_45147)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_value_45147)) {
        _1 = (long)(DBL_PTR(_value_45147)->dbl);
        DeRefDS(_value_45147);
        _value_45147 = _1;
    }

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		printf(c_h, format, value)*/
    EPrintf(_54c_h_45123, _format_45146, _value_45147);
L1: 

    /** end procedure*/
    DeRefDS(_format_45146);
    return;
    ;
}


void _54c_printf(int _format_45151, int _value_45152)
{
    int _text_45154 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [7] 29
    }
    else{
    }

    /** 		sequence text = sprintf( format, value )*/
    DeRefi(_text_45154);
    _text_45154 = EPrintf(-9999999, _format_45151, _value_45152);

    /** 		puts(c_code, text)*/
    EPuts(_54c_code_45122, _text_45154); // DJP 

    /** 		update_checksum( text )*/
    RefDS(_text_45154);
    _55update_checksum(_text_45154);
L1: 
    DeRefi(_text_45154);
    _text_45154 = NOVALUE;

    /** end procedure*/
    DeRefDS(_format_45151);
    DeRef(_value_45152);
    return;
    ;
}


void _54c_printf8(int _value_45165)
{
    int _buff_45166 = NOVALUE;
    int _neg_45167 = NOVALUE;
    int _p_45168 = NOVALUE;
    int _23884 = NOVALUE;
    int _23883 = NOVALUE;
    int _23881 = NOVALUE;
    int _23880 = NOVALUE;
    int _23878 = NOVALUE;
    int _23877 = NOVALUE;
    int _23875 = NOVALUE;
    int _23874 = NOVALUE;
    int _23872 = NOVALUE;
    int _23870 = NOVALUE;
    int _23868 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [5] 182
    }
    else{
    }

    /** 		neg = 0*/
    _neg_45167 = 0;

    /** 		buff = sprintf("%.16e", value)*/
    DeRef(_buff_45166);
    _buff_45166 = EPrintf(-9999999, _23866, _value_45165);

    /** 		if length(buff) < 10 then*/
    if (IS_SEQUENCE(_buff_45166)){
            _23868 = SEQ_PTR(_buff_45166)->length;
    }
    else {
        _23868 = 1;
    }
    if (_23868 >= 10)
    goto L2; // [24] 174

    /** 			p = 1*/
    _p_45168 = 1;

    /** 			while p <= length(buff) do*/
L3: 
    if (IS_SEQUENCE(_buff_45166)){
            _23870 = SEQ_PTR(_buff_45166)->length;
    }
    else {
        _23870 = 1;
    }
    if (_p_45168 > _23870)
    goto L4; // [41] 173

    /** 				if buff[p] = '-' then*/
    _2 = (int)SEQ_PTR(_buff_45166);
    _23872 = (int)*(((s1_ptr)_2)->base + _p_45168);
    if (binary_op_a(NOTEQ, _23872, 45)){
        _23872 = NOVALUE;
        goto L5; // [51] 63
    }
    _23872 = NOVALUE;

    /** 					neg = 1*/
    _neg_45167 = 1;
    goto L6; // [60] 162
L5: 

    /** 				elsif buff[p] = 'i' or buff[p] = 'I' then*/
    _2 = (int)SEQ_PTR(_buff_45166);
    _23874 = (int)*(((s1_ptr)_2)->base + _p_45168);
    if (IS_ATOM_INT(_23874)) {
        _23875 = (_23874 == 105);
    }
    else {
        _23875 = binary_op(EQUALS, _23874, 105);
    }
    _23874 = NOVALUE;
    if (IS_ATOM_INT(_23875)) {
        if (_23875 != 0) {
            goto L7; // [73] 90
        }
    }
    else {
        if (DBL_PTR(_23875)->dbl != 0.0) {
            goto L7; // [73] 90
        }
    }
    _2 = (int)SEQ_PTR(_buff_45166);
    _23877 = (int)*(((s1_ptr)_2)->base + _p_45168);
    if (IS_ATOM_INT(_23877)) {
        _23878 = (_23877 == 73);
    }
    else {
        _23878 = binary_op(EQUALS, _23877, 73);
    }
    _23877 = NOVALUE;
    if (_23878 == 0) {
        DeRef(_23878);
        _23878 = NOVALUE;
        goto L8; // [86] 114
    }
    else {
        if (!IS_ATOM_INT(_23878) && DBL_PTR(_23878)->dbl == 0.0){
            DeRef(_23878);
            _23878 = NOVALUE;
            goto L8; // [86] 114
        }
        DeRef(_23878);
        _23878 = NOVALUE;
    }
    DeRef(_23878);
    _23878 = NOVALUE;
L7: 

    /** 					buff = CREATE_INF*/
    RefDS(_54CREATE_INF_45157);
    DeRef(_buff_45166);
    _buff_45166 = _54CREATE_INF_45157;

    /** 					if neg then*/
    if (_neg_45167 == 0)
    {
        goto L4; // [97] 173
    }
    else{
    }

    /** 						buff = prepend(buff, '-')*/
    Prepend(&_buff_45166, _buff_45166, 45);

    /** 					exit*/
    goto L4; // [109] 173
    goto L6; // [111] 162
L8: 

    /** 				elsif buff[p] = 'n' or buff[p] = 'N' then*/
    _2 = (int)SEQ_PTR(_buff_45166);
    _23880 = (int)*(((s1_ptr)_2)->base + _p_45168);
    if (IS_ATOM_INT(_23880)) {
        _23881 = (_23880 == 110);
    }
    else {
        _23881 = binary_op(EQUALS, _23880, 110);
    }
    _23880 = NOVALUE;
    if (IS_ATOM_INT(_23881)) {
        if (_23881 != 0) {
            goto L9; // [124] 141
        }
    }
    else {
        if (DBL_PTR(_23881)->dbl != 0.0) {
            goto L9; // [124] 141
        }
    }
    _2 = (int)SEQ_PTR(_buff_45166);
    _23883 = (int)*(((s1_ptr)_2)->base + _p_45168);
    if (IS_ATOM_INT(_23883)) {
        _23884 = (_23883 == 78);
    }
    else {
        _23884 = binary_op(EQUALS, _23883, 78);
    }
    _23883 = NOVALUE;
    if (_23884 == 0) {
        DeRef(_23884);
        _23884 = NOVALUE;
        goto LA; // [137] 161
    }
    else {
        if (!IS_ATOM_INT(_23884) && DBL_PTR(_23884)->dbl == 0.0){
            DeRef(_23884);
            _23884 = NOVALUE;
            goto LA; // [137] 161
        }
        DeRef(_23884);
        _23884 = NOVALUE;
    }
    DeRef(_23884);
    _23884 = NOVALUE;
L9: 

    /** 					ifdef UNIX then*/

    /** 						buff = CREATE_NAN1*/
    RefDS(_54CREATE_NAN1_45159);
    DeRef(_buff_45166);
    _buff_45166 = _54CREATE_NAN1_45159;

    /** 						if neg then*/
    if (_neg_45167 == 0)
    {
        goto LB; // [150] 160
    }
    else{
    }

    /** 							buff = prepend(buff, '-')*/
    Prepend(&_buff_45166, _buff_45166, 45);
LB: 
LA: 
L6: 

    /** 				p += 1*/
    _p_45168 = _p_45168 + 1;

    /** 			end while*/
    goto L3; // [170] 38
L4: 
L2: 

    /** 		puts(c_code, buff)*/
    EPuts(_54c_code_45122, _buff_45166); // DJP 
L1: 

    /** end procedure*/
    DeRef(_value_45165);
    DeRef(_buff_45166);
    DeRef(_23875);
    _23875 = NOVALUE;
    DeRef(_23881);
    _23881 = NOVALUE;
    return;
    ;
}


void _54adjust_indent_before(int _stmt_45204)
{
    int _i_45205 = NOVALUE;
    int _lb_45207 = NOVALUE;
    int _rb_45208 = NOVALUE;
    int _23899 = NOVALUE;
    int _23897 = NOVALUE;
    int _23895 = NOVALUE;
    int _23889 = NOVALUE;
    int _23888 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lb = FALSE*/
    _lb_45207 = _13FALSE_435;

    /** 	rb = FALSE*/
    _rb_45208 = _13FALSE_435;

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45204)){
            _23888 = SEQ_PTR(_stmt_45204)->length;
    }
    else {
        _23888 = 1;
    }
    {
        int _p_45212;
        _p_45212 = 1;
L1: 
        if (_p_45212 > _23888){
            goto L2; // [22] 102
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45204);
        _23889 = (int)*(((s1_ptr)_2)->base + _p_45212);
        if (IS_SEQUENCE(_23889) ){
            goto L3; // [35] 95
        }
        if(!IS_ATOM_INT(_23889)){
            if( (DBL_PTR(_23889)->dbl != (double) ((int) DBL_PTR(_23889)->dbl) ) ){
                goto L3; // [35] 95
            }
            _0 = (int) DBL_PTR(_23889)->dbl;
        }
        else {
            _0 = _23889;
        };
        _23889 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [46] 102
            goto L3; // [48] 95

            /** 			case  '}' then*/
            case 125:

            /** 				rb = TRUE*/
            _rb_45208 = _13TRUE_437;

            /** 				if lb then*/
            if (_lb_45207 == 0)
            {
                goto L3; // [63] 95
            }
            else{
            }

            /** 					exit*/
            goto L2; // [68] 102
            goto L3; // [71] 95

            /** 			case '{' then*/
            case 123:

            /** 				lb = TRUE*/
            _lb_45207 = _13TRUE_437;

            /** 				if rb then */
            if (_rb_45208 == 0)
            {
                goto L4; // [86] 94
            }
            else{
            }

            /** 					exit*/
            goto L2; // [91] 102
L4: 
        ;}L3: 

        /** 	end for*/
        _p_45212 = _p_45212 + 1;
        goto L1; // [97] 29
L2: 
        ;
    }

    /** 	if rb then*/
    if (_rb_45208 == 0)
    {
        goto L5; // [104] 122
    }
    else{
    }

    /** 		if not lb then*/
    if (_lb_45207 != 0)
    goto L6; // [109] 121

    /** 			indent -= 4*/
    _54indent_45198 = _54indent_45198 - 4;
L6: 
L5: 

    /** 	i = indent + temp_indent*/
    _i_45205 = _54indent_45198 + _54temp_indent_45199;

    /** 	while i >= length(big_blanks) do*/
L7: 
    if (IS_SEQUENCE(_54big_blanks_45200)){
            _23895 = SEQ_PTR(_54big_blanks_45200)->length;
    }
    else {
        _23895 = 1;
    }
    if (_i_45205 < _23895)
    goto L8; // [140] 163

    /** 		c_puts(big_blanks)*/
    RefDS(_54big_blanks_45200);
    _54c_puts(_54big_blanks_45200);

    /** 		i -= length(big_blanks)*/
    if (IS_SEQUENCE(_54big_blanks_45200)){
            _23897 = SEQ_PTR(_54big_blanks_45200)->length;
    }
    else {
        _23897 = 1;
    }
    _i_45205 = _i_45205 - _23897;
    _23897 = NOVALUE;

    /** 	end while*/
    goto L7; // [160] 137
L8: 

    /** 	c_puts(big_blanks[1..i])*/
    rhs_slice_target = (object_ptr)&_23899;
    RHS_Slice(_54big_blanks_45200, 1, _i_45205);
    _54c_puts(_23899);
    _23899 = NOVALUE;

    /** 	temp_indent = 0    */
    _54temp_indent_45199 = 0;

    /** end procedure*/
    DeRefDS(_stmt_45204);
    return;
    ;
}


void _54adjust_indent_after(int _stmt_45237)
{
    int _23920 = NOVALUE;
    int _23919 = NOVALUE;
    int _23917 = NOVALUE;
    int _23915 = NOVALUE;
    int _23914 = NOVALUE;
    int _23911 = NOVALUE;
    int _23909 = NOVALUE;
    int _23908 = NOVALUE;
    int _23905 = NOVALUE;
    int _23901 = NOVALUE;
    int _23900 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for p = 1 to length(stmt) do*/
    if (IS_SEQUENCE(_stmt_45237)){
            _23900 = SEQ_PTR(_stmt_45237)->length;
    }
    else {
        _23900 = 1;
    }
    {
        int _p_45239;
        _p_45239 = 1;
L1: 
        if (_p_45239 > _23900){
            goto L2; // [8] 61
        }

        /** 		switch stmt[p] do*/
        _2 = (int)SEQ_PTR(_stmt_45237);
        _23901 = (int)*(((s1_ptr)_2)->base + _p_45239);
        if (IS_SEQUENCE(_23901) ){
            goto L3; // [21] 54
        }
        if(!IS_ATOM_INT(_23901)){
            if( (DBL_PTR(_23901)->dbl != (double) ((int) DBL_PTR(_23901)->dbl) ) ){
                goto L3; // [21] 54
            }
            _0 = (int) DBL_PTR(_23901)->dbl;
        }
        else {
            _0 = _23901;
        };
        _23901 = NOVALUE;
        switch ( _0 ){ 

            /** 			case '\n' then*/
            case 10:

            /** 				exit*/
            goto L2; // [32] 61
            goto L3; // [34] 54

            /** 			case '{' then*/
            case 123:

            /** 				indent += 4*/
            _54indent_45198 = _54indent_45198 + 4;

            /** 				return*/
            DeRefDS(_stmt_45237);
            return;
        ;}L3: 

        /** 	end for*/
        _p_45239 = _p_45239 + 1;
        goto L1; // [56] 15
L2: 
        ;
    }

    /** 	if length(stmt) < 3 then*/
    if (IS_SEQUENCE(_stmt_45237)){
            _23905 = SEQ_PTR(_stmt_45237)->length;
    }
    else {
        _23905 = 1;
    }
    if (_23905 >= 3)
    goto L4; // [66] 76

    /** 		return*/
    DeRefDS(_stmt_45237);
    return;
L4: 

    /** 	if not equal("if ", stmt[1..3]) then*/
    rhs_slice_target = (object_ptr)&_23908;
    RHS_Slice(_stmt_45237, 1, 3);
    if (_23907 == _23908)
    _23909 = 1;
    else if (IS_ATOM_INT(_23907) && IS_ATOM_INT(_23908))
    _23909 = 0;
    else
    _23909 = (compare(_23907, _23908) == 0);
    DeRefDS(_23908);
    _23908 = NOVALUE;
    if (_23909 != 0)
    goto L5; // [87] 96
    _23909 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45237);
    return;
L5: 

    /** 	if length(stmt) < 5 then*/
    if (IS_SEQUENCE(_stmt_45237)){
            _23911 = SEQ_PTR(_stmt_45237)->length;
    }
    else {
        _23911 = 1;
    }
    if (_23911 >= 5)
    goto L6; // [101] 111

    /** 		return*/
    DeRefDS(_stmt_45237);
    return;
L6: 

    /** 	if not equal("else", stmt[1..4]) then*/
    rhs_slice_target = (object_ptr)&_23914;
    RHS_Slice(_stmt_45237, 1, 4);
    if (_23913 == _23914)
    _23915 = 1;
    else if (IS_ATOM_INT(_23913) && IS_ATOM_INT(_23914))
    _23915 = 0;
    else
    _23915 = (compare(_23913, _23914) == 0);
    DeRefDS(_23914);
    _23914 = NOVALUE;
    if (_23915 != 0)
    goto L7; // [122] 131
    _23915 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45237);
    return;
L7: 

    /** 	if not find(stmt[5], {" \n"}) then*/
    _2 = (int)SEQ_PTR(_stmt_45237);
    _23917 = (int)*(((s1_ptr)_2)->base + 5);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_23918);
    *((int *)(_2+4)) = _23918;
    _23919 = MAKE_SEQ(_1);
    _23920 = find_from(_23917, _23919, 1);
    _23917 = NOVALUE;
    DeRefDS(_23919);
    _23919 = NOVALUE;
    if (_23920 != 0)
    goto L8; // [146] 155
    _23920 = NOVALUE;

    /** 		return*/
    DeRefDS(_stmt_45237);
    return;
L8: 

    /** 	temp_indent = 4*/
    _54temp_indent_45199 = 4;

    /** end procedure*/
    DeRefDS(_stmt_45237);
    return;
    ;
}



// 0x5908339C
