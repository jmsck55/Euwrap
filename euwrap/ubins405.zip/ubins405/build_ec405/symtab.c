// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _53hashfn(int _name_45730)
{
    int _len_45731 = NOVALUE;
    int _val_45732 = NOVALUE;
    int _int_45733 = NOVALUE;
    int _24160 = NOVALUE;
    int _24159 = NOVALUE;
    int _24156 = NOVALUE;
    int _24155 = NOVALUE;
    int _24144 = NOVALUE;
    int _24140 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = length(name)*/
    if (IS_SEQUENCE(_name_45730)){
            _len_45731 = SEQ_PTR(_name_45730)->length;
    }
    else {
        _len_45731 = 1;
    }

    /** 	val = name[1]*/
    _2 = (int)SEQ_PTR(_name_45730);
    _val_45732 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_45732))
    _val_45732 = (long)DBL_PTR(_val_45732)->dbl;

    /** 	int = name[$]*/
    if (IS_SEQUENCE(_name_45730)){
            _24140 = SEQ_PTR(_name_45730)->length;
    }
    else {
        _24140 = 1;
    }
    _2 = (int)SEQ_PTR(_name_45730);
    _int_45733 = (int)*(((s1_ptr)_2)->base + _24140);
    if (!IS_ATOM_INT(_int_45733))
    _int_45733 = (long)DBL_PTR(_int_45733)->dbl;

    /** 	int *= 256*/
    _int_45733 = _int_45733 * 256;

    /** 	val *= 2*/
    _val_45732 = _val_45732 + _val_45732;

    /** 	val += int + len*/
    _24144 = _int_45733 + _len_45731;
    if ((long)((unsigned long)_24144 + (unsigned long)HIGH_BITS) >= 0) 
    _24144 = NewDouble((double)_24144);
    if (IS_ATOM_INT(_24144)) {
        _val_45732 = _val_45732 + _24144;
    }
    else {
        _val_45732 = NewDouble((double)_val_45732 + DBL_PTR(_24144)->dbl);
    }
    DeRef(_24144);
    _24144 = NOVALUE;
    if (!IS_ATOM_INT(_val_45732)) {
        _1 = (long)(DBL_PTR(_val_45732)->dbl);
        DeRefDS(_val_45732);
        _val_45732 = _1;
    }

    /** 	if len = 3 then*/
    if (_len_45731 != 3)
    goto L1; // [51] 78

    /** 		val *= 32*/
    _val_45732 = _val_45732 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_45730);
    _int_45733 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_45733))
    _int_45733 = (long)DBL_PTR(_int_45733)->dbl;

    /** 		val += int*/
    _val_45732 = _val_45732 + _int_45733;
    goto L2; // [75] 133
L1: 

    /** 	elsif len > 3 then*/
    if (_len_45731 <= 3)
    goto L3; // [80] 132

    /** 		val *= 32*/
    _val_45732 = _val_45732 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_45730);
    _int_45733 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_45733))
    _int_45733 = (long)DBL_PTR(_int_45733)->dbl;

    /** 		val += int*/
    _val_45732 = _val_45732 + _int_45733;

    /** 		val *= 32*/
    _val_45732 = _val_45732 * 32;

    /** 		int = name[$-1]*/
    if (IS_SEQUENCE(_name_45730)){
            _24155 = SEQ_PTR(_name_45730)->length;
    }
    else {
        _24155 = 1;
    }
    _24156 = _24155 - 1;
    _24155 = NOVALUE;
    _2 = (int)SEQ_PTR(_name_45730);
    _int_45733 = (int)*(((s1_ptr)_2)->base + _24156);
    if (!IS_ATOM_INT(_int_45733))
    _int_45733 = (long)DBL_PTR(_int_45733)->dbl;

    /** 		val += int*/
    _val_45732 = _val_45732 + _int_45733;
L3: 
L2: 

    /** 	return remainder(val, NBUCKETS) + 1*/
    _24159 = (_val_45732 % 2003);
    _24160 = _24159 + 1;
    _24159 = NOVALUE;
    DeRefDS(_name_45730);
    DeRef(_24156);
    _24156 = NOVALUE;
    return _24160;
    ;
}


void _53remove_symbol(int _sym_45762)
{
    int _hash_45763 = NOVALUE;
    int _st_ptr_45764 = NOVALUE;
    int _24175 = NOVALUE;
    int _24174 = NOVALUE;
    int _24172 = NOVALUE;
    int _24171 = NOVALUE;
    int _24170 = NOVALUE;
    int _24168 = NOVALUE;
    int _24166 = NOVALUE;
    int _24165 = NOVALUE;
    int _24164 = NOVALUE;
    int _24161 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45762)) {
        _1 = (long)(DBL_PTR(_sym_45762)->dbl);
        DeRefDS(_sym_45762);
        _sym_45762 = _1;
    }

    /** 	hash = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24161 = (int)*(((s1_ptr)_2)->base + _sym_45762);
    _2 = (int)SEQ_PTR(_24161);
    _hash_45763 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_45763)){
        _hash_45763 = (long)DBL_PTR(_hash_45763)->dbl;
    }
    _24161 = NOVALUE;

    /** 	st_ptr = buckets[hash]*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _st_ptr_45764 = (int)*(((s1_ptr)_2)->base + _hash_45763);
    if (!IS_ATOM_INT(_st_ptr_45764))
    _st_ptr_45764 = (long)DBL_PTR(_st_ptr_45764)->dbl;

    /** 	while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_45764 == 0) {
        goto L2; // [32] 65
    }
    _24165 = (_st_ptr_45764 != _sym_45762);
    if (_24165 == 0)
    {
        DeRef(_24165);
        _24165 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24165);
        _24165 = NOVALUE;
    }

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24166 = (int)*(((s1_ptr)_2)->base + _st_ptr_45764);
    _2 = (int)SEQ_PTR(_24166);
    _st_ptr_45764 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_45764)){
        _st_ptr_45764 = (long)DBL_PTR(_st_ptr_45764)->dbl;
    }
    _24166 = NOVALUE;

    /** 	end while*/
    goto L1; // [62] 32
L2: 

    /** 	if st_ptr then*/
    if (_st_ptr_45764 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** 		if st_ptr = buckets[hash] then*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _24168 = (int)*(((s1_ptr)_2)->base + _hash_45763);
    if (binary_op_a(NOTEQ, _st_ptr_45764, _24168)){
        _24168 = NOVALUE;
        goto L4; // [78] 105
    }
    _24168 = NOVALUE;

    /** 			buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24170 = (int)*(((s1_ptr)_2)->base + _st_ptr_45764);
    _2 = (int)SEQ_PTR(_24170);
    _24171 = (int)*(((s1_ptr)_2)->base + 9);
    _24170 = NOVALUE;
    Ref(_24171);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _2 = (int)(((s1_ptr)_2)->base + _hash_45763);
    _1 = *(int *)_2;
    *(int *)_2 = _24171;
    if( _1 != _24171 ){
        DeRef(_1);
    }
    _24171 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** 			SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_st_ptr_45764 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24174 = (int)*(((s1_ptr)_2)->base + _sym_45762);
    _2 = (int)SEQ_PTR(_24174);
    _24175 = (int)*(((s1_ptr)_2)->base + 9);
    _24174 = NOVALUE;
    Ref(_24175);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24175;
    if( _1 != _24175 ){
        DeRef(_1);
    }
    _24175 = NOVALUE;
    _24172 = NOVALUE;
L5: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _53NewBasicEntry(int _name_45796, int _varnum_45797, int _scope_45798, int _token_45799, int _hashval_45800, int _samehash_45802, int _type_sym_45804)
{
    int _new_45805 = NOVALUE;
    int _24184 = NOVALUE;
    int _24182 = NOVALUE;
    int _24181 = NOVALUE;
    int _24180 = NOVALUE;
    int _24179 = NOVALUE;
    int _24178 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_varnum_45797)) {
        _1 = (long)(DBL_PTR(_varnum_45797)->dbl);
        DeRefDS(_varnum_45797);
        _varnum_45797 = _1;
    }
    if (!IS_ATOM_INT(_scope_45798)) {
        _1 = (long)(DBL_PTR(_scope_45798)->dbl);
        DeRefDS(_scope_45798);
        _scope_45798 = _1;
    }
    if (!IS_ATOM_INT(_token_45799)) {
        _1 = (long)(DBL_PTR(_token_45799)->dbl);
        DeRefDS(_token_45799);
        _token_45799 = _1;
    }
    if (!IS_ATOM_INT(_hashval_45800)) {
        _1 = (long)(DBL_PTR(_hashval_45800)->dbl);
        DeRefDS(_hashval_45800);
        _hashval_45800 = _1;
    }
    if (!IS_ATOM_INT(_samehash_45802)) {
        _1 = (long)(DBL_PTR(_samehash_45802)->dbl);
        DeRefDS(_samehash_45802);
        _samehash_45802 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_45804)) {
        _1 = (long)(DBL_PTR(_type_sym_45804)->dbl);
        DeRefDS(_type_sym_45804);
        _type_sym_45804 = _1;
    }

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** 		new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_45805);
    _new_45805 = Repeat(0, _35SIZEOF_ROUTINE_ENTRY_15767);
    goto L2; // [30] 42
L1: 

    /** 		new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_45805);
    _new_45805 = Repeat(0, _35SIZEOF_VAR_ENTRY_15770);
L2: 

    /** 	new[S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_NAME] = name*/
    RefDS(_name_45796);
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15641))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15641);
    _1 = *(int *)_2;
    *(int *)_2 = _name_45796;
    DeRef(_1);

    /** 	new[S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_45798;
    DeRef(_1);

    /** 	new[S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	new[S_USAGE] = U_UNUSED*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15637))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** 		new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_MIN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 		new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _24178 = (int)NewDouble((double)-0xC0000000);
        else
        _24178 = - _35NOVALUE_15823;
    }
    else {
        _24178 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _24178;
    if( _1 != _24178 ){
        DeRef(_1);
    }
    _24178 = NOVALUE;

    /** 		new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _24179 = (int)NewDouble((double)-0xC0000000);
        else
        _24179 = - _35NOVALUE_15823;
    }
    else {
        _24179 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _24179;
    if( _1 != _24179 ){
        DeRef(_1);
    }
    _24179 = NOVALUE;

    /** 		new[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 		new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _24180 = (int)NewDouble((double)-0xC0000000);
        else
        _24180 = - _35NOVALUE_15823;
    }
    else {
        _24180 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _24180;
    if( _1 != _24180 ){
        DeRef(_1);
    }
    _24180 = NOVALUE;

    /** 		new[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _13TRUE_437;
    DeRef(_1);

    /** 		new[S_RI_TARGET] = 0*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 		new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _24181 = (int)NewDouble((double)-0xC0000000);
        else
        _24181 = - _35NOVALUE_15823;
    }
    else {
        _24181 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _24181;
    if( _1 != _24181 ){
        DeRef(_1);
    }
    _24181 = NOVALUE;

    /** 		new[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);

    /** 		new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _24182 = (int)NewDouble((double)-0xC0000000);
        else
        _24182 = - _35NOVALUE_15823;
    }
    else {
        _24182 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _24182;
    if( _1 != _24182 ){
        DeRef(_1);
    }
    _24182 = NOVALUE;
L3: 

    /** 	new[S_TOKEN] = token*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    _1 = *(int *)_2;
    *(int *)_2 = _token_45799;
    DeRef(_1);

    /** 	new[S_VARNUM] = varnum*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _varnum_45797;
    DeRef(_1);

    /** 	new[S_INITLEVEL] = -1*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	new[S_VTYPE] = type_sym*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_sym_45804;
    DeRef(_1);

    /** 	new[S_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_45800;
    DeRef(_1);

    /** 	new[S_SAMEHASH] = samehash*/
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _samehash_45802;
    DeRef(_1);

    /** 	new[S_OBJ] = NOVALUE -- important*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_new_45805);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45805 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 	SymTab = append(SymTab, new)*/
    RefDS(_new_45805);
    Append(&_36SymTab_14981, _36SymTab_14981, _new_45805);

    /** 	return length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _24184 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _24184 = 1;
    }
    DeRefDS(_name_45796);
    DeRefDS(_new_45805);
    return _24184;
    ;
}


int _53NewEntry(int _name_45884, int _varnum_45885, int _scope_45886, int _token_45887, int _hashval_45888, int _samehash_45890, int _type_sym_45892)
{
    int _new_45894 = NOVALUE;
    int _24186 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_varnum_45885)) {
        _1 = (long)(DBL_PTR(_varnum_45885)->dbl);
        DeRefDS(_varnum_45885);
        _varnum_45885 = _1;
    }
    if (!IS_ATOM_INT(_scope_45886)) {
        _1 = (long)(DBL_PTR(_scope_45886)->dbl);
        DeRefDS(_scope_45886);
        _scope_45886 = _1;
    }
    if (!IS_ATOM_INT(_token_45887)) {
        _1 = (long)(DBL_PTR(_token_45887)->dbl);
        DeRefDS(_token_45887);
        _token_45887 = _1;
    }
    if (!IS_ATOM_INT(_hashval_45888)) {
        _1 = (long)(DBL_PTR(_hashval_45888)->dbl);
        DeRefDS(_hashval_45888);
        _hashval_45888 = _1;
    }
    if (!IS_ATOM_INT(_samehash_45890)) {
        _1 = (long)(DBL_PTR(_samehash_45890)->dbl);
        DeRefDS(_samehash_45890);
        _samehash_45890 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_45892)) {
        _1 = (long)(DBL_PTR(_type_sym_45892)->dbl);
        DeRefDS(_type_sym_45892);
        _type_sym_45892 = _1;
    }

    /** 	symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_45884);
    _new_45894 = _53NewBasicEntry(_name_45884, _varnum_45885, _scope_45886, _token_45887, _hashval_45888, _samehash_45890, _type_sym_45892);
    if (!IS_ATOM_INT(_new_45894)) {
        _1 = (long)(DBL_PTR(_new_45894)->dbl);
        DeRefDS(_new_45894);
        _new_45894 = _1;
    }

    /** 	if last_sym then*/
    if (_53last_sym_45724 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** 		SymTab[last_sym][S_NEXT] = new*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_45724 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_45894;
    DeRef(_1);
    _24186 = NOVALUE;
L1: 

    /** 	last_sym = new*/
    _53last_sym_45724 = _new_45894;

    /** 	if type_sym < 0 then*/
    if (_type_sym_45892 >= 0)
    goto L2; // [63] 76

    /** 		register_forward_type( last_sym, type_sym )*/
    _38register_forward_type(_53last_sym_45724, _type_sym_45892);
L2: 

    /** 	return last_sym*/
    DeRefDS(_name_45884);
    return _53last_sym_45724;
    ;
}


int _53tmp_alloc()
{
    int _new_entry_45909 = NOVALUE;
    int _24200 = NOVALUE;
    int _24198 = NOVALUE;
    int _24195 = NOVALUE;
    int _24192 = NOVALUE;
    int _24191 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_45909);
    _new_entry_45909 = Repeat(0, _35SIZEOF_TEMP_ENTRY_15776);

    /** 	new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    *(int *)_2 = 4;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** 		new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = 16;

    /** 		new_entry[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    *(int *)_2 = -1073741824;

    /** 		new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    *(int *)_2 = 1073741823;

    /** 		new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = _35NOVALUE_15823;

    /** 		new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_35temp_name_type_16050)){
            _24191 = SEQ_PTR(_35temp_name_type_16050)->length;
    }
    else {
        _24191 = 1;
    }
    _24192 = _24191 + 1;
    _24191 = NOVALUE;
    if (_24192 != 8087)
    goto L2; // [87] 106

    /** 			temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _24195 = MAKE_SEQ(_1);
    RefDS(_24195);
    Append(&_35temp_name_type_16050, _35temp_name_type_16050, _24195);
    DeRefDS(_24195);
    _24195 = NOVALUE;
L2: 

    /** 		temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_54TYPES_OBNL_45116);
    Append(&_35temp_name_type_16050, _35temp_name_type_16050, _54TYPES_OBNL_45116);

    /** 		new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_35temp_name_type_16050)){
            _24198 = SEQ_PTR(_35temp_name_type_16050)->length;
    }
    else {
        _24198 = 1;
    }
    _2 = (int)SEQ_PTR(_new_entry_45909);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45909 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24198;
    if( _1 != _24198 ){
        DeRef(_1);
    }
    _24198 = NOVALUE;
L1: 

    /** 	SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_45909);
    Append(&_36SymTab_14981, _36SymTab_14981, _new_entry_45909);

    /** 	return length( SymTab )*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _24200 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _24200 = 1;
    }
    DeRefDS(_new_entry_45909);
    DeRef(_24192);
    _24192 = NOVALUE;
    return _24200;
    ;
}


void _53DefinedYet(int _sym_45978)
{
    int _24220 = NOVALUE;
    int _24219 = NOVALUE;
    int _24218 = NOVALUE;
    int _24216 = NOVALUE;
    int _24215 = NOVALUE;
    int _24213 = NOVALUE;
    int _24212 = NOVALUE;
    int _24211 = NOVALUE;
    int _24210 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_45978)) {
        _1 = (long)(DBL_PTR(_sym_45978)->dbl);
        DeRefDS(_sym_45978);
        _sym_45978 = _1;
    }

    /** 	if not find(SymTab[sym][S_SCOPE],*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24210 = (int)*(((s1_ptr)_2)->base + _sym_45978);
    _2 = (int)SEQ_PTR(_24210);
    _24211 = (int)*(((s1_ptr)_2)->base + 4);
    _24210 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 9;
    *((int *)(_2+8)) = 10;
    *((int *)(_2+12)) = 7;
    _24212 = MAKE_SEQ(_1);
    _24213 = find_from(_24211, _24212, 1);
    _24211 = NOVALUE;
    DeRefDS(_24212);
    _24212 = NOVALUE;
    if (_24213 != 0)
    goto L1; // [34] 82
    _24213 = NOVALUE;

    /** 		if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24215 = (int)*(((s1_ptr)_2)->base + _sym_45978);
    _2 = (int)SEQ_PTR(_24215);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24216 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24216 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24215 = NOVALUE;
    if (binary_op_a(NOTEQ, _24216, _35current_file_no_15968)){
        _24216 = NOVALUE;
        goto L2; // [53] 81
    }
    _24216 = NOVALUE;

    /** 			CompileErr(31, {SymTab[sym][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24218 = (int)*(((s1_ptr)_2)->base + _sym_45978);
    _2 = (int)SEQ_PTR(_24218);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24219 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24219 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24218 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24219);
    *((int *)(_2+4)) = _24219;
    _24220 = MAKE_SEQ(_1);
    _24219 = NOVALUE;
    _44CompileErr(31, _24220, 0);
    _24220 = NOVALUE;
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _53name_ext(int _s_46005)
{
    int _24227 = NOVALUE;
    int _24226 = NOVALUE;
    int _24225 = NOVALUE;
    int _24224 = NOVALUE;
    int _24222 = NOVALUE;
    int _24221 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_46005)){
            _24221 = SEQ_PTR(_s_46005)->length;
    }
    else {
        _24221 = 1;
    }
    {
        int _i_46007;
        _i_46007 = _24221;
L1: 
        if (_i_46007 < 1){
            goto L2; // [8] 55
        }

        /** 		if find(s[i], "/\\:") then*/
        _2 = (int)SEQ_PTR(_s_46005);
        _24222 = (int)*(((s1_ptr)_2)->base + _i_46007);
        _24224 = find_from(_24222, _24223, 1);
        _24222 = NOVALUE;
        if (_24224 == 0)
        {
            _24224 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24224 = NOVALUE;
        }

        /** 			return s[i+1 .. $]*/
        _24225 = _i_46007 + 1;
        if (IS_SEQUENCE(_s_46005)){
                _24226 = SEQ_PTR(_s_46005)->length;
        }
        else {
            _24226 = 1;
        }
        rhs_slice_target = (object_ptr)&_24227;
        RHS_Slice(_s_46005, _24225, _24226);
        DeRefDS(_s_46005);
        _24225 = NOVALUE;
        return _24227;
L3: 

        /** 	end for*/
        _i_46007 = _i_46007 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** 	return s*/
    DeRef(_24225);
    _24225 = NOVALUE;
    DeRef(_24227);
    _24227 = NOVALUE;
    return _s_46005;
    ;
}


int _53NewStringSym(int _s_46024)
{
    int _p_46026 = NOVALUE;
    int _tp_46027 = NOVALUE;
    int _prev_46028 = NOVALUE;
    int _search_count_46029 = NOVALUE;
    int _24271 = NOVALUE;
    int _24269 = NOVALUE;
    int _24268 = NOVALUE;
    int _24267 = NOVALUE;
    int _24265 = NOVALUE;
    int _24264 = NOVALUE;
    int _24261 = NOVALUE;
    int _24259 = NOVALUE;
    int _24257 = NOVALUE;
    int _24256 = NOVALUE;
    int _24255 = NOVALUE;
    int _24253 = NOVALUE;
    int _24251 = NOVALUE;
    int _24249 = NOVALUE;
    int _24247 = NOVALUE;
    int _24244 = NOVALUE;
    int _24242 = NOVALUE;
    int _24241 = NOVALUE;
    int _24240 = NOVALUE;
    int _24238 = NOVALUE;
    int _24236 = NOVALUE;
    int _24235 = NOVALUE;
    int _24234 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46027 = _53literal_init_45723;

    /** 	prev = 0*/
    _prev_46028 = 0;

    /** 	search_count = 0*/
    _search_count_46029 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46027 == 0)
    goto L2; // [31] 170

    /** 		search_count += 1*/
    _search_count_46029 = _search_count_46029 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46029, _53SEARCH_LIMIT_46016)){
        goto L3; // [45] 54
    }

    /** 			exit*/
    goto L2; // [51] 170
L3: 

    /** 		if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24234 = (int)*(((s1_ptr)_2)->base + _tp_46027);
    _2 = (int)SEQ_PTR(_24234);
    _24235 = (int)*(((s1_ptr)_2)->base + 1);
    _24234 = NOVALUE;
    if (_s_46024 == _24235)
    _24236 = 1;
    else if (IS_ATOM_INT(_s_46024) && IS_ATOM_INT(_24235))
    _24236 = 0;
    else
    _24236 = (compare(_s_46024, _24235) == 0);
    _24235 = NOVALUE;
    if (_24236 == 0)
    {
        _24236 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24236 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46027 == _53literal_init_45723)
    goto L5; // [79] 135

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46028 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24240 = (int)*(((s1_ptr)_2)->base + _tp_46027);
    _2 = (int)SEQ_PTR(_24240);
    _24241 = (int)*(((s1_ptr)_2)->base + 2);
    _24240 = NOVALUE;
    Ref(_24241);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24241;
    if( _1 != _24241 ){
        DeRef(_1);
    }
    _24241 = NOVALUE;
    _24238 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46027 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_45723;
    DeRef(_1);
    _24242 = NOVALUE;

    /** 				literal_init = tp*/
    _53literal_init_45723 = _tp_46027;
L5: 

    /** 			return tp*/
    DeRefDS(_s_46024);
    return _tp_46027;
L4: 

    /** 		prev = tp*/
    _prev_46028 = _tp_46027;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24244 = (int)*(((s1_ptr)_2)->base + _tp_46027);
    _2 = (int)SEQ_PTR(_24244);
    _tp_46027 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46027)){
        _tp_46027 = (long)DBL_PTR(_tp_46027)->dbl;
    }
    _24244 = NOVALUE;

    /** 	end while*/
    goto L1; // [167] 31
L2: 

    /** 	p = tmp_alloc()*/
    _p_46026 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46026)) {
        _1 = (long)(DBL_PTR(_p_46026)->dbl);
        DeRefDS(_p_46026);
        _p_46026 = _1;
    }

    /** 	SymTab[p][S_OBJ] = s*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    RefDS(_s_46024);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_46024;
    DeRef(_1);
    _24247 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24249 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _24251 = NOVALUE;

    /** 		SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_46024)){
            _24255 = SEQ_PTR(_s_46024)->length;
    }
    else {
        _24255 = 1;
    }
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _24255;
    if( _1 != _24255 ){
        DeRef(_1);
    }
    _24255 = NOVALUE;
    _24253 = NOVALUE;

    /** 		if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24256 = (int)*(((s1_ptr)_2)->base + _p_46026);
    _2 = (int)SEQ_PTR(_24256);
    _24257 = (int)*(((s1_ptr)_2)->base + 32);
    _24256 = NOVALUE;
    if (binary_op_a(LESSEQ, _24257, 0)){
        _24257 = NOVALUE;
        goto L7; // [265] 289
    }
    _24257 = NOVALUE;

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24259 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24261 = NOVALUE;
L8: 

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24264 = (int)*(((s1_ptr)_2)->base + _p_46026);
    _2 = (int)SEQ_PTR(_24264);
    _24265 = (int)*(((s1_ptr)_2)->base + 34);
    _24264 = NOVALUE;
    RefDS(_24263);
    Ref(_24265);
    _54c_printf(_24263, _24265);
    _24265 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24267 = (int)*(((s1_ptr)_2)->base + _p_46026);
    _2 = (int)SEQ_PTR(_24267);
    _24268 = (int)*(((s1_ptr)_2)->base + 34);
    _24267 = NOVALUE;
    RefDS(_24266);
    Ref(_24268);
    _54c_hprintf(_24266, _24268);
    _24268 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24269 = NOVALUE;
L9: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46026 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_45723;
    DeRef(_1);
    _24271 = NOVALUE;

    /** 	literal_init = p*/
    _53literal_init_45723 = _p_46026;

    /** 	return p*/
    DeRefDS(_s_46024);
    return _p_46026;
    ;
}


int _53NewIntSym(int _int_val_46122)
{
    int _p_46124 = NOVALUE;
    int _x_46125 = NOVALUE;
    int _24290 = NOVALUE;
    int _24288 = NOVALUE;
    int _24284 = NOVALUE;
    int _24282 = NOVALUE;
    int _24280 = NOVALUE;
    int _24278 = NOVALUE;
    int _24276 = NOVALUE;
    int _24274 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_int_val_46122)) {
        _1 = (long)(DBL_PTR(_int_val_46122)->dbl);
        DeRefDS(_int_val_46122);
        _int_val_46122 = _1;
    }

    /** 	integer x*/

    /** 	x = find(int_val, lastintval)*/
    _x_46125 = find_from(_int_val_46122, _53lastintval_45725, 1);

    /** 	if x then*/
    if (_x_46125 == 0)
    {
        goto L1; // [16] 34
    }
    else{
    }

    /** 		return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (int)SEQ_PTR(_53lastintsym_45726);
    _24274 = (int)*(((s1_ptr)_2)->base + _x_46125);
    return _24274;
    goto L2; // [31] 180
L1: 

    /** 		p = tmp_alloc()*/
    _p_46124 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46124)) {
        _1 = (long)(DBL_PTR(_p_46124)->dbl);
        DeRefDS(_p_46124);
        _p_46124 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24276 = NOVALUE;

    /** 		SymTab[p][S_OBJ] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46122;
    DeRef(_1);
    _24278 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [77] 128
    }
    else{
    }

    /** 			SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46122;
    DeRef(_1);
    _24280 = NOVALUE;

    /** 			SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46122;
    DeRef(_1);
    _24282 = NOVALUE;

    /** 			SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46124 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24284 = NOVALUE;
L3: 

    /** 		lastintval = prepend(lastintval, int_val)*/
    Prepend(&_53lastintval_45725, _53lastintval_45725, _int_val_46122);

    /** 		lastintsym = prepend(lastintsym, p)*/
    Prepend(&_53lastintsym_45726, _53lastintsym_45726, _p_46124);

    /** 		if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_53lastintval_45725)){
            _24288 = SEQ_PTR(_53lastintval_45725)->length;
    }
    else {
        _24288 = 1;
    }
    if (binary_op_a(LESSEQ, _24288, _53SEARCH_LIMIT_46016)){
        _24288 = NOVALUE;
        goto L4; // [153] 173
    }
    _24288 = NOVALUE;

    /** 			lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_53SEARCH_LIMIT_46016)) {
        _24290 = _53SEARCH_LIMIT_46016 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _53SEARCH_LIMIT_46016, 2);
        _24290 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_53lastintval_45725;
    RHS_Slice(_53lastintval_45725, 1, _24290);
L4: 

    /** 		return p*/
    _24274 = NOVALUE;
    DeRef(_24290);
    _24290 = NOVALUE;
    return _p_46124;
L2: 
    ;
}


int _53NewDoubleSym(int _d_46164)
{
    int _p_46166 = NOVALUE;
    int _tp_46167 = NOVALUE;
    int _prev_46168 = NOVALUE;
    int _search_count_46169 = NOVALUE;
    int _24320 = NOVALUE;
    int _24319 = NOVALUE;
    int _24318 = NOVALUE;
    int _24317 = NOVALUE;
    int _24316 = NOVALUE;
    int _24314 = NOVALUE;
    int _24312 = NOVALUE;
    int _24310 = NOVALUE;
    int _24308 = NOVALUE;
    int _24305 = NOVALUE;
    int _24303 = NOVALUE;
    int _24302 = NOVALUE;
    int _24301 = NOVALUE;
    int _24299 = NOVALUE;
    int _24297 = NOVALUE;
    int _24296 = NOVALUE;
    int _24295 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46167 = _53literal_init_45723;

    /** 	prev = 0*/
    _prev_46168 = 0;

    /** 	search_count = 0*/
    _search_count_46169 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46167 == 0)
    goto L2; // [29] 168

    /** 		search_count += 1*/
    _search_count_46169 = _search_count_46169 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46169, _53SEARCH_LIMIT_46016)){
        goto L3; // [43] 52
    }

    /** 			exit*/
    goto L2; // [49] 168
L3: 

    /** 		if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24295 = (int)*(((s1_ptr)_2)->base + _tp_46167);
    _2 = (int)SEQ_PTR(_24295);
    _24296 = (int)*(((s1_ptr)_2)->base + 1);
    _24295 = NOVALUE;
    if (_d_46164 == _24296)
    _24297 = 1;
    else if (IS_ATOM_INT(_d_46164) && IS_ATOM_INT(_24296))
    _24297 = 0;
    else
    _24297 = (compare(_d_46164, _24296) == 0);
    _24296 = NOVALUE;
    if (_24297 == 0)
    {
        _24297 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24297 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46167 == _53literal_init_45723)
    goto L5; // [77] 133

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46168 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24301 = (int)*(((s1_ptr)_2)->base + _tp_46167);
    _2 = (int)SEQ_PTR(_24301);
    _24302 = (int)*(((s1_ptr)_2)->base + 2);
    _24301 = NOVALUE;
    Ref(_24302);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24302;
    if( _1 != _24302 ){
        DeRef(_1);
    }
    _24302 = NOVALUE;
    _24299 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46167 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_45723;
    DeRef(_1);
    _24303 = NOVALUE;

    /** 				literal_init = tp*/
    _53literal_init_45723 = _tp_46167;
L5: 

    /** 			return tp*/
    DeRef(_d_46164);
    return _tp_46167;
L4: 

    /** 		prev = tp*/
    _prev_46168 = _tp_46167;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24305 = (int)*(((s1_ptr)_2)->base + _tp_46167);
    _2 = (int)SEQ_PTR(_24305);
    _tp_46167 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46167)){
        _tp_46167 = (long)DBL_PTR(_tp_46167)->dbl;
    }
    _24305 = NOVALUE;

    /** 	end while*/
    goto L1; // [165] 29
L2: 

    /** 	p = tmp_alloc()*/
    _p_46166 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46166)) {
        _1 = (long)(DBL_PTR(_p_46166)->dbl);
        DeRefDS(_p_46166);
        _p_46166 = _1;
    }

    /** 	SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46166 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24308 = NOVALUE;

    /** 	SymTab[p][S_OBJ] = d*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46166 + ((s1_ptr)_2)->base);
    Ref(_d_46164);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _d_46164;
    DeRef(_1);
    _24310 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46166 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24312 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46166 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24314 = NOVALUE;

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24316 = (int)*(((s1_ptr)_2)->base + _p_46166);
    _2 = (int)SEQ_PTR(_24316);
    _24317 = (int)*(((s1_ptr)_2)->base + 34);
    _24316 = NOVALUE;
    RefDS(_24263);
    Ref(_24317);
    _54c_printf(_24263, _24317);
    _24317 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24318 = (int)*(((s1_ptr)_2)->base + _p_46166);
    _2 = (int)SEQ_PTR(_24318);
    _24319 = (int)*(((s1_ptr)_2)->base + 34);
    _24318 = NOVALUE;
    RefDS(_24266);
    Ref(_24319);
    _54c_hprintf(_24266, _24319);
    _24319 = NOVALUE;
L6: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46166 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _53literal_init_45723;
    DeRef(_1);
    _24320 = NOVALUE;

    /** 	literal_init = p*/
    _53literal_init_45723 = _p_46166;

    /** 	return p*/
    DeRef(_d_46164);
    return _p_46166;
    ;
}


int _53NewTempSym(int _inlining_46238)
{
    int _p_46240 = NOVALUE;
    int _q_46241 = NOVALUE;
    int _24369 = NOVALUE;
    int _24367 = NOVALUE;
    int _24365 = NOVALUE;
    int _24363 = NOVALUE;
    int _24361 = NOVALUE;
    int _24359 = NOVALUE;
    int _24358 = NOVALUE;
    int _24357 = NOVALUE;
    int _24355 = NOVALUE;
    int _24354 = NOVALUE;
    int _24353 = NOVALUE;
    int _24351 = NOVALUE;
    int _24349 = NOVALUE;
    int _24346 = NOVALUE;
    int _24345 = NOVALUE;
    int _24344 = NOVALUE;
    int _24342 = NOVALUE;
    int _24340 = NOVALUE;
    int _24339 = NOVALUE;
    int _24338 = NOVALUE;
    int _24336 = NOVALUE;
    int _24334 = NOVALUE;
    int _24329 = NOVALUE;
    int _24328 = NOVALUE;
    int _24327 = NOVALUE;
    int _24326 = NOVALUE;
    int _24325 = NOVALUE;
    int _24324 = NOVALUE;
    int _24322 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_inlining_46238)) {
        _1 = (long)(DBL_PTR(_inlining_46238)->dbl);
        DeRefDS(_inlining_46238);
        _inlining_46238 = _1;
    }

    /** 	if inlining then*/
    if (_inlining_46238 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** 		p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24322 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24322);
    if (!IS_ATOM_INT(_35S_TEMPS_15686)){
        _p_46240 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    }
    else{
        _p_46240 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    }
    if (!IS_ATOM_INT(_p_46240)){
        _p_46240 = (long)DBL_PTR(_p_46240)->dbl;
    }
    _24322 = NOVALUE;

    /** 		while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24324 = (_p_46240 != 0);
    if (_24324 == 0) {
        goto L3; // [35] 93
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24326 = (int)*(((s1_ptr)_2)->base + _p_46240);
    _2 = (int)SEQ_PTR(_24326);
    _24327 = (int)*(((s1_ptr)_2)->base + 4);
    _24326 = NOVALUE;
    if (IS_ATOM_INT(_24327)) {
        _24328 = (_24327 != 0);
    }
    else {
        _24328 = binary_op(NOTEQ, _24327, 0);
    }
    _24327 = NOVALUE;
    if (_24328 <= 0) {
        if (_24328 == 0) {
            DeRef(_24328);
            _24328 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24328) && DBL_PTR(_24328)->dbl == 0.0){
                DeRef(_24328);
                _24328 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24328);
            _24328 = NOVALUE;
        }
    }
    DeRef(_24328);
    _24328 = NOVALUE;

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24329 = (int)*(((s1_ptr)_2)->base + _p_46240);
    _2 = (int)SEQ_PTR(_24329);
    _p_46240 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46240)){
        _p_46240 = (long)DBL_PTR(_p_46240)->dbl;
    }
    _24329 = NOVALUE;

    /** 		end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** 		p = 0*/
    _p_46240 = 0;
L3: 

    /** 	if p = 0 then*/
    if (_p_46240 != 0)
    goto L4; // [97] 213

    /** 		temps_allocated += 1*/
    _53temps_allocated_46235 = _53temps_allocated_46235 + 1;

    /** 		p = tmp_alloc()*/
    _p_46240 = _53tmp_alloc();
    if (!IS_ATOM_INT(_p_46240)) {
        _1 = (long)(DBL_PTR(_p_46240)->dbl);
        DeRefDS(_p_46240);
        _p_46240 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24334 = NOVALUE;

    /** 		SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24338 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24338);
    if (!IS_ATOM_INT(_35S_TEMPS_15686)){
        _24339 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    }
    else{
        _24339 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    }
    _24338 = NOVALUE;
    Ref(_24339);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24339;
    if( _1 != _24339 ){
        DeRef(_1);
    }
    _24339 = NOVALUE;
    _24336 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15686))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    _1 = *(int *)_2;
    *(int *)_2 = _p_46240;
    DeRef(_1);
    _24340 = NOVALUE;

    /** 		if inlining then*/
    if (_inlining_46238 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701)){
        _24344 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    }
    else{
        _24344 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    }
    _24342 = NOVALUE;
    if (IS_ATOM_INT(_24344)) {
        _24345 = _24344 + 1;
        if (_24345 > MAXINT){
            _24345 = NewDouble((double)_24345);
        }
    }
    else
    _24345 = binary_op(PLUS, 1, _24344);
    _24344 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    _1 = *(int *)_2;
    *(int *)_2 = _24345;
    if( _1 != _24345 ){
        DeRef(_1);
    }
    _24345 = NOVALUE;
    _24342 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** 	elsif TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** 		SymTab[p][S_SCOPE] = DELETED*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24346 = NOVALUE;

    /** 		q = tmp_alloc()*/
    _q_46241 = _53tmp_alloc();
    if (!IS_ATOM_INT(_q_46241)) {
        _1 = (long)(DBL_PTR(_q_46241)->dbl);
        DeRefDS(_q_46241);
        _q_46241 = _1;
    }

    /** 		SymTab[q][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46241 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24349 = NOVALUE;

    /** 		SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46241 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24353 = (int)*(((s1_ptr)_2)->base + _p_46240);
    _2 = (int)SEQ_PTR(_24353);
    _24354 = (int)*(((s1_ptr)_2)->base + 34);
    _24353 = NOVALUE;
    Ref(_24354);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24354;
    if( _1 != _24354 ){
        DeRef(_1);
    }
    _24354 = NOVALUE;
    _24351 = NOVALUE;

    /** 		SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46241 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24357 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24357);
    if (!IS_ATOM_INT(_35S_TEMPS_15686)){
        _24358 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    }
    else{
        _24358 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    }
    _24357 = NOVALUE;
    Ref(_24358);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24358;
    if( _1 != _24358 ){
        DeRef(_1);
    }
    _24358 = NOVALUE;
    _24355 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15686))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    _1 = *(int *)_2;
    *(int *)_2 = _q_46241;
    DeRef(_1);
    _24359 = NOVALUE;

    /** 		p = q*/
    _p_46240 = _q_46241;
L6: 
L5: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** 		SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24361 = NOVALUE;

    /** 		SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24363 = NOVALUE;
L7: 

    /** 	SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    _24365 = NOVALUE;

    /** 	SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24367 = NOVALUE;

    /** 	SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46240 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24369 = NOVALUE;

    /** 	return p*/
    DeRef(_24324);
    _24324 = NOVALUE;
    return _p_46240;
    ;
}


void _53InitSymTab()
{
    int _hashval_46357 = NOVALUE;
    int _len_46358 = NOVALUE;
    int _s_46360 = NOVALUE;
    int _st_index_46361 = NOVALUE;
    int _kname_46362 = NOVALUE;
    int _fixups_46363 = NOVALUE;
    int _si_46503 = NOVALUE;
    int _sj_46504 = NOVALUE;
    int _24953 = NOVALUE;
    int _24952 = NOVALUE;
    int _24485 = NOVALUE;
    int _24484 = NOVALUE;
    int _24483 = NOVALUE;
    int _24482 = NOVALUE;
    int _24481 = NOVALUE;
    int _24479 = NOVALUE;
    int _24478 = NOVALUE;
    int _24477 = NOVALUE;
    int _24476 = NOVALUE;
    int _24474 = NOVALUE;
    int _24472 = NOVALUE;
    int _24470 = NOVALUE;
    int _24469 = NOVALUE;
    int _24467 = NOVALUE;
    int _24465 = NOVALUE;
    int _24463 = NOVALUE;
    int _24462 = NOVALUE;
    int _24460 = NOVALUE;
    int _24459 = NOVALUE;
    int _24458 = NOVALUE;
    int _24457 = NOVALUE;
    int _24456 = NOVALUE;
    int _24453 = NOVALUE;
    int _24452 = NOVALUE;
    int _24451 = NOVALUE;
    int _24449 = NOVALUE;
    int _24448 = NOVALUE;
    int _24447 = NOVALUE;
    int _24445 = NOVALUE;
    int _24444 = NOVALUE;
    int _24443 = NOVALUE;
    int _24440 = NOVALUE;
    int _24438 = NOVALUE;
    int _24436 = NOVALUE;
    int _24435 = NOVALUE;
    int _24432 = NOVALUE;
    int _24431 = NOVALUE;
    int _24429 = NOVALUE;
    int _24427 = NOVALUE;
    int _24425 = NOVALUE;
    int _24422 = NOVALUE;
    int _24421 = NOVALUE;
    int _24420 = NOVALUE;
    int _24417 = NOVALUE;
    int _24416 = NOVALUE;
    int _24414 = NOVALUE;
    int _24413 = NOVALUE;
    int _24411 = NOVALUE;
    int _24410 = NOVALUE;
    int _24409 = NOVALUE;
    int _24407 = NOVALUE;
    int _24405 = NOVALUE;
    int _24404 = NOVALUE;
    int _24402 = NOVALUE;
    int _24401 = NOVALUE;
    int _24400 = NOVALUE;
    int _24398 = NOVALUE;
    int _24397 = NOVALUE;
    int _24396 = NOVALUE;
    int _24394 = NOVALUE;
    int _24393 = NOVALUE;
    int _24392 = NOVALUE;
    int _24390 = NOVALUE;
    int _24389 = NOVALUE;
    int _24388 = NOVALUE;
    int _24387 = NOVALUE;
    int _24386 = NOVALUE;
    int _24385 = NOVALUE;
    int _24384 = NOVALUE;
    int _24383 = NOVALUE;
    int _24382 = NOVALUE;
    int _24381 = NOVALUE;
    int _24379 = NOVALUE;
    int _24378 = NOVALUE;
    int _24377 = NOVALUE;
    int _24376 = NOVALUE;
    int _24372 = NOVALUE;
    int _24371 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence kname, fixups = {}*/
    RefDS(_21815);
    DeRefi(_fixups_46363);
    _fixups_46363 = _21815;

    /** 	for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22479)){
            _24371 = SEQ_PTR(_63keylist_22479)->length;
    }
    else {
        _24371 = 1;
    }
    {
        int _k_46365;
        _k_46365 = 1;
L1: 
        if (_k_46365 > _24371){
            goto L2; // [15] 560
        }

        /** 		kname = keylist[k][K_NAME]*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24372 = (int)*(((s1_ptr)_2)->base + _k_46365);
        DeRef(_kname_46362);
        _2 = (int)SEQ_PTR(_24372);
        _kname_46362 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_46362);
        _24372 = NOVALUE;

        /** 		len = length(kname)*/
        if (IS_SEQUENCE(_kname_46362)){
                _len_46358 = SEQ_PTR(_kname_46362)->length;
        }
        else {
            _len_46358 = 1;
        }

        /** 		hashval = hashfn(kname)*/
        RefDS(_kname_46362);
        _hashval_46357 = _53hashfn(_kname_46362);
        if (!IS_ATOM_INT(_hashval_46357)) {
            _1 = (long)(DBL_PTR(_hashval_46357)->dbl);
            DeRefDS(_hashval_46357);
            _hashval_46357 = _1;
        }

        /** 		st_index = NewEntry(kname,*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24376 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24376);
        _24377 = (int)*(((s1_ptr)_2)->base + 2);
        _24376 = NOVALUE;
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24378 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24378);
        _24379 = (int)*(((s1_ptr)_2)->base + 3);
        _24378 = NOVALUE;
        RefDS(_kname_46362);
        Ref(_24377);
        Ref(_24379);
        _st_index_46361 = _53NewEntry(_kname_46362, 0, _24377, _24379, _hashval_46357, 0, 0);
        _24377 = NOVALUE;
        _24379 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_46361)) {
            _1 = (long)(DBL_PTR(_st_index_46361)->dbl);
            DeRefDS(_st_index_46361);
            _st_index_46361 = _1;
        }

        /** 		if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24381 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24381);
        _24382 = (int)*(((s1_ptr)_2)->base + 3);
        _24381 = NOVALUE;
        _24383 = find_from(_24382, _37RTN_TOKS_15594, 1);
        _24382 = NOVALUE;
        if (_24383 == 0)
        {
            _24383 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24383 = NOVALUE;
        }

        /** 			SymTab[st_index] = SymTab[st_index] &*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24384 = (int)*(((s1_ptr)_2)->base + _st_index_46361);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24385 = (int)*(((s1_ptr)_2)->base + _st_index_46361);
        if (IS_SEQUENCE(_24385)){
                _24386 = SEQ_PTR(_24385)->length;
        }
        else {
            _24386 = 1;
        }
        _24385 = NOVALUE;
        _24387 = _35SIZEOF_ROUTINE_ENTRY_15767 - _24386;
        _24386 = NOVALUE;
        _24388 = Repeat(0, _24387);
        _24387 = NOVALUE;
        if (IS_SEQUENCE(_24384) && IS_ATOM(_24388)) {
        }
        else if (IS_ATOM(_24384) && IS_SEQUENCE(_24388)) {
            Ref(_24384);
            Prepend(&_24389, _24388, _24384);
        }
        else {
            Concat((object_ptr)&_24389, _24384, _24388);
            _24384 = NOVALUE;
        }
        _24384 = NOVALUE;
        DeRefDS(_24388);
        _24388 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _st_index_46361);
        _1 = *(int *)_2;
        *(int *)_2 = _24389;
        if( _1 != _24389 ){
            DeRef(_1);
        }
        _24389 = NOVALUE;

        /** 			SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24392 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24392);
        _24393 = (int)*(((s1_ptr)_2)->base + 5);
        _24392 = NOVALUE;
        Ref(_24393);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15692))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
        _1 = *(int *)_2;
        *(int *)_2 = _24393;
        if( _1 != _24393 ){
            DeRef(_1);
        }
        _24393 = NOVALUE;
        _24390 = NOVALUE;

        /** 			SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24396 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24396);
        _24397 = (int)*(((s1_ptr)_2)->base + 4);
        _24396 = NOVALUE;
        Ref(_24397);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 21);
        _1 = *(int *)_2;
        *(int *)_2 = _24397;
        if( _1 != _24397 ){
            DeRef(_1);
        }
        _24397 = NOVALUE;
        _24394 = NOVALUE;

        /** 			SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24400 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24400);
        _24401 = (int)*(((s1_ptr)_2)->base + 6);
        _24400 = NOVALUE;
        Ref(_24401);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 23);
        _1 = *(int *)_2;
        *(int *)_2 = _24401;
        if( _1 != _24401 ){
            DeRef(_1);
        }
        _24401 = NOVALUE;
        _24398 = NOVALUE;

        /** 			SymTab[st_index][S_REFLIST] = {}*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        RefDS(_21815);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 24);
        _1 = *(int *)_2;
        *(int *)_2 = _21815;
        DeRef(_1);
        _24402 = NOVALUE;

        /** 			if length(keylist[k]) > K_EFFECT then*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24404 = (int)*(((s1_ptr)_2)->base + _k_46365);
        if (IS_SEQUENCE(_24404)){
                _24405 = SEQ_PTR(_24404)->length;
        }
        else {
            _24405 = 1;
        }
        _24404 = NOVALUE;
        if (_24405 <= 6)
        goto L4; // [259] 324

        /** 			    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24409 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24409);
        _24410 = (int)*(((s1_ptr)_2)->base + 7);
        _24409 = NOVALUE;
        Ref(_24410);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15653))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
        _1 = *(int *)_2;
        *(int *)_2 = _24410;
        if( _1 != _24410 ){
            DeRef(_1);
        }
        _24410 = NOVALUE;
        _24407 = NOVALUE;

        /** 			    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24413 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24413);
        _24414 = (int)*(((s1_ptr)_2)->base + 8);
        _24413 = NOVALUE;
        Ref(_24414);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 28);
        _1 = *(int *)_2;
        *(int *)_2 = _24414;
        if( _1 != _24414 ){
            DeRef(_1);
        }
        _24414 = NOVALUE;
        _24411 = NOVALUE;

        /** 			    fixups &= st_index*/
        Append(&_fixups_46363, _fixups_46363, _st_index_46361);
L4: 
L3: 

        /** 		if keylist[k][K_TOKEN] = PROC then*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24416 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24416);
        _24417 = (int)*(((s1_ptr)_2)->base + 3);
        _24416 = NOVALUE;
        if (binary_op_a(NOTEQ, _24417, 27)){
            _24417 = NOVALUE;
            goto L5; // [341] 365
        }
        _24417 = NOVALUE;

        /** 			if equal(kname, "<TopLevel>") then*/
        if (_kname_46362 == _24419)
        _24420 = 1;
        else if (IS_ATOM_INT(_kname_46362) && IS_ATOM_INT(_24419))
        _24420 = 0;
        else
        _24420 = (compare(_kname_46362, _24419) == 0);
        if (_24420 == 0)
        {
            _24420 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24420 = NOVALUE;
        }

        /** 				TopLevelSub = st_index*/
        _35TopLevelSub_15975 = _st_index_46361;
        goto L6; // [362] 462
L5: 

        /** 		elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _24421 = (int)*(((s1_ptr)_2)->base + _k_46365);
        _2 = (int)SEQ_PTR(_24421);
        _24422 = (int)*(((s1_ptr)_2)->base + 3);
        _24421 = NOVALUE;
        if (binary_op_a(NOTEQ, _24422, 504)){
            _24422 = NOVALUE;
            goto L7; // [381] 461
        }
        _24422 = NOVALUE;

        /** 			if equal(kname, "object") then*/
        if (_kname_46362 == _24424)
        _24425 = 1;
        else if (IS_ATOM_INT(_kname_46362) && IS_ATOM_INT(_24424))
        _24425 = 0;
        else
        _24425 = (compare(_kname_46362, _24424) == 0);
        if (_24425 == 0)
        {
            _24425 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24425 = NOVALUE;
        }

        /** 				object_type = st_index*/
        _53object_type_45715 = _st_index_46361;
        goto L9; // [401] 460
L8: 

        /** 			elsif equal(kname, "atom") then*/
        if (_kname_46362 == _24426)
        _24427 = 1;
        else if (IS_ATOM_INT(_kname_46362) && IS_ATOM_INT(_24426))
        _24427 = 0;
        else
        _24427 = (compare(_kname_46362, _24426) == 0);
        if (_24427 == 0)
        {
            _24427 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24427 = NOVALUE;
        }

        /** 				atom_type = st_index*/
        _53atom_type_45717 = _st_index_46361;
        goto L9; // [420] 460
LA: 

        /** 			elsif equal(kname, "integer") then*/
        if (_kname_46362 == _24428)
        _24429 = 1;
        else if (IS_ATOM_INT(_kname_46362) && IS_ATOM_INT(_24428))
        _24429 = 0;
        else
        _24429 = (compare(_kname_46362, _24428) == 0);
        if (_24429 == 0)
        {
            _24429 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24429 = NOVALUE;
        }

        /** 				integer_type = st_index*/
        _53integer_type_45721 = _st_index_46361;
        goto L9; // [439] 460
LB: 

        /** 			elsif equal(kname, "sequence") then*/
        if (_kname_46362 == _24430)
        _24431 = 1;
        else if (IS_ATOM_INT(_kname_46362) && IS_ATOM_INT(_24430))
        _24431 = 0;
        else
        _24431 = (compare(_kname_46362, _24430) == 0);
        if (_24431 == 0)
        {
            _24431 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24431 = NOVALUE;
        }

        /** 				sequence_type = st_index*/
        _53sequence_type_45719 = _st_index_46361;
LC: 
L9: 
L7: 
L6: 

        /** 		if buckets[hashval] = 0 then*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _24432 = (int)*(((s1_ptr)_2)->base + _hashval_46357);
        if (binary_op_a(NOTEQ, _24432, 0)){
            _24432 = NOVALUE;
            goto LD; // [470] 485
        }
        _24432 = NOVALUE;

        /** 			buckets[hashval] = st_index*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_46357);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46361;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** 			s = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _s_46360 = (int)*(((s1_ptr)_2)->base + _hashval_46357);
        if (!IS_ATOM_INT(_s_46360)){
            _s_46360 = (long)DBL_PTR(_s_46360)->dbl;
        }

        /** 			while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24435 = (int)*(((s1_ptr)_2)->base + _s_46360);
        _2 = (int)SEQ_PTR(_24435);
        _24436 = (int)*(((s1_ptr)_2)->base + 9);
        _24435 = NOVALUE;
        if (binary_op_a(EQUALS, _24436, 0)){
            _24436 = NOVALUE;
            goto L10; // [512] 537
        }
        _24436 = NOVALUE;

        /** 				s = SymTab[s][S_SAMEHASH]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24438 = (int)*(((s1_ptr)_2)->base + _s_46360);
        _2 = (int)SEQ_PTR(_24438);
        _s_46360 = (int)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_46360)){
            _s_46360 = (long)DBL_PTR(_s_46360)->dbl;
        }
        _24438 = NOVALUE;

        /** 			end while*/
        goto LF; // [534] 500
L10: 

        /** 			SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_46360 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46361;
        DeRef(_1);
        _24440 = NOVALUE;
LE: 

        /** 	end for*/
        _k_46365 = _k_46365 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** 	file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _35file_start_sym_15974 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _35file_start_sym_15974 = 1;
    }

    /** 	sequence si, sj*/

    /** 	CurrentSub = TopLevelSub*/
    _35CurrentSub_15976 = _35TopLevelSub_15975;

    /** 	for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_46363)){
            _24443 = SEQ_PTR(_fixups_46363)->length;
    }
    else {
        _24443 = 1;
    }
    {
        int _i_46508;
        _i_46508 = 1;
L11: 
        if (_i_46508 > _24443){
            goto L12; // [585] 945
        }

        /** 	    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (int)SEQ_PTR(_fixups_46363);
        _24444 = (int)*(((s1_ptr)_2)->base + _i_46508);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24445 = (int)*(((s1_ptr)_2)->base + _24444);
        DeRef(_si_46503);
        _2 = (int)SEQ_PTR(_24445);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _si_46503 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _si_46503 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        Ref(_si_46503);
        _24445 = NOVALUE;

        /** 	    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_46503)){
                _24447 = SEQ_PTR(_si_46503)->length;
        }
        else {
            _24447 = 1;
        }
        {
            int _j_46516;
            _j_46516 = 1;
L13: 
            if (_j_46516 > _24447){
                goto L14; // [617] 919
            }

            /** 	        if sequence(si[j]) then*/
            _2 = (int)SEQ_PTR(_si_46503);
            _24448 = (int)*(((s1_ptr)_2)->base + _j_46516);
            _24449 = IS_SEQUENCE(_24448);
            _24448 = NOVALUE;
            if (_24449 == 0)
            {
                _24449 = NOVALUE;
                goto L15; // [633] 912
            }
            else{
                _24449 = NOVALUE;
            }

            /** 	            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_46504);
            _2 = (int)SEQ_PTR(_si_46503);
            _sj_46504 = (int)*(((s1_ptr)_2)->base + _j_46516);
            Ref(_sj_46504);

            /** 				for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_46504)){
                    _24451 = SEQ_PTR(_sj_46504)->length;
            }
            else {
                _24451 = 1;
            }
            {
                int _ij_46523;
                _ij_46523 = 1;
L16: 
                if (_ij_46523 > _24451){
                    goto L17; // [649] 905
                }

                /** 	                switch sj[ij][T_ID] with fallthru do*/
                _2 = (int)SEQ_PTR(_sj_46504);
                _24452 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                _2 = (int)SEQ_PTR(_24452);
                _24453 = (int)*(((s1_ptr)_2)->base + 1);
                _24452 = NOVALUE;
                if (IS_SEQUENCE(_24453) ){
                    goto L18; // [668] 898
                }
                if(!IS_ATOM_INT(_24453)){
                    if( (DBL_PTR(_24453)->dbl != (double) ((int) DBL_PTR(_24453)->dbl) ) ){
                        goto L18; // [668] 898
                    }
                    _0 = (int) DBL_PTR(_24453)->dbl;
                }
                else {
                    _0 = _24453;
                };
                _24453 = NOVALUE;
                switch ( _0 ){ 

                    /** 	                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** 	                    	if integer(sj[ij][T_SYM]) then*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    _24456 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                    _2 = (int)SEQ_PTR(_24456);
                    _24457 = (int)*(((s1_ptr)_2)->base + 2);
                    _24456 = NOVALUE;
                    if (IS_ATOM_INT(_24457))
                    _24458 = 1;
                    else if (IS_ATOM_DBL(_24457))
                    _24458 = IS_ATOM_INT(DoubleToInt(_24457));
                    else
                    _24458 = 0;
                    _24457 = NOVALUE;
                    if (_24458 == 0)
                    {
                        _24458 = NOVALUE;
                        goto L19; // [692] 716
                    }
                    else{
                        _24458 = NOVALUE;
                    }

                    /** 								st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    _24459 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                    _2 = (int)SEQ_PTR(_24459);
                    _24460 = (int)*(((s1_ptr)_2)->base + 2);
                    _24459 = NOVALUE;
                    Ref(_24460);
                    _st_index_46361 = _53NewIntSym(_24460);
                    _24460 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46361)) {
                        _1 = (long)(DBL_PTR(_st_index_46361)->dbl);
                        DeRefDS(_st_index_46361);
                        _st_index_46361 = _1;
                    }
                    goto L1A; // [713] 735
L19: 

                    /** 								st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    _24462 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                    _2 = (int)SEQ_PTR(_24462);
                    _24463 = (int)*(((s1_ptr)_2)->base + 2);
                    _24462 = NOVALUE;
                    Ref(_24463);
                    _st_index_46361 = _53NewDoubleSym(_24463);
                    _24463 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46361)) {
                        _1 = (long)(DBL_PTR(_st_index_46361)->dbl);
                        DeRefDS(_st_index_46361);
                        _st_index_46361 = _1;
                    }
L1A: 

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_36SymTab_14981);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _36SymTab_14981 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24465 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46504 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46523 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46361;
                    DeRef(_1);
                    _24467 = NOVALUE;

                    /** 							break*/
                    goto L18; // [769] 898

                    /** 						case STRING then -- same*/
                    case 503:

                    /** 	                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    _24469 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                    _2 = (int)SEQ_PTR(_24469);
                    _24470 = (int)*(((s1_ptr)_2)->base + 2);
                    _24469 = NOVALUE;
                    Ref(_24470);
                    _st_index_46361 = _53NewStringSym(_24470);
                    _24470 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46361)) {
                        _1 = (long)(DBL_PTR(_st_index_46361)->dbl);
                        DeRefDS(_st_index_46361);
                        _st_index_46361 = _1;
                    }

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_36SymTab_14981);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _36SymTab_14981 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46361 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24472 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46504 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46523 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46361;
                    DeRef(_1);
                    _24474 = NOVALUE;

                    /** 							break*/
                    goto L18; // [825] 898

                    /** 						case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /**                             sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    _24476 = (int)*(((s1_ptr)_2)->base + _ij_46523);
                    _2 = (int)SEQ_PTR(_24476);
                    _24477 = (int)*(((s1_ptr)_2)->base + 2);
                    _24476 = NOVALUE;
                    Ref(_24477);
                    DeRef(_24952);
                    _24952 = _24477;
                    _24953 = _53hashfn(_24952);
                    _24952 = NOVALUE;
                    Ref(_24477);
                    _24478 = _53keyfind(_24477, -1, _35current_file_no_15968, 0, _24953);
                    _24477 = NOVALUE;
                    _24953 = NOVALUE;
                    _2 = (int)SEQ_PTR(_sj_46504);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46504 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + _ij_46523);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24478;
                    if( _1 != _24478 ){
                        DeRef(_1);
                    }
                    _24478 = NOVALUE;

                    /** 							break*/
                    goto L18; // [866] 898

                    /** 						case DEF_PARAM then*/
                    case 510:

                    /** 							sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (int)SEQ_PTR(_sj_46504);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46504 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46523 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(_fixups_46363);
                    _24481 = (int)*(((s1_ptr)_2)->base + _i_46508);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    _24482 = (int)*(((s1_ptr)_2)->base + 2);
                    _24479 = NOVALUE;
                    if (IS_SEQUENCE(_24482) && IS_ATOM(_24481)) {
                        Append(&_24483, _24482, _24481);
                    }
                    else if (IS_ATOM(_24482) && IS_SEQUENCE(_24481)) {
                    }
                    else {
                        Concat((object_ptr)&_24483, _24482, _24481);
                        _24482 = NOVALUE;
                    }
                    _24482 = NOVALUE;
                    _24481 = NOVALUE;
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24483;
                    if( _1 != _24483 ){
                        DeRef(_1);
                    }
                    _24483 = NOVALUE;
                    _24479 = NOVALUE;
                ;}L18: 

                /** 				end for*/
                _ij_46523 = _ij_46523 + 1;
                goto L16; // [900] 656
L17: 
                ;
            }

            /** 				si[j] = sj*/
            RefDS(_sj_46504);
            _2 = (int)SEQ_PTR(_si_46503);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _si_46503 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_46516);
            _1 = *(int *)_2;
            *(int *)_2 = _sj_46504;
            DeRef(_1);
L15: 

            /** 		end for*/
            _j_46516 = _j_46516 + 1;
            goto L13; // [914] 624
L14: 
            ;
        }

        /** 		SymTab[fixups[i]][S_CODE] = si*/
        _2 = (int)SEQ_PTR(_fixups_46363);
        _24484 = (int)*(((s1_ptr)_2)->base + _i_46508);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_24484 + ((s1_ptr)_2)->base);
        RefDS(_si_46503);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15653))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
        _1 = *(int *)_2;
        *(int *)_2 = _si_46503;
        DeRef(_1);
        _24485 = NOVALUE;

        /** 	end for*/
        _i_46508 = _i_46508 + 1;
        goto L11; // [940] 592
L12: 
        ;
    }

    /** end procedure*/
    DeRef(_kname_46362);
    DeRefi(_fixups_46363);
    DeRef(_si_46503);
    DeRef(_sj_46504);
    _24404 = NOVALUE;
    _24385 = NOVALUE;
    _24444 = NOVALUE;
    _24484 = NOVALUE;
    return;
    ;
}


void _53add_ref(int _tok_46591)
{
    int _s_46593 = NOVALUE;
    int _24501 = NOVALUE;
    int _24500 = NOVALUE;
    int _24498 = NOVALUE;
    int _24497 = NOVALUE;
    int _24496 = NOVALUE;
    int _24494 = NOVALUE;
    int _24493 = NOVALUE;
    int _24492 = NOVALUE;
    int _24491 = NOVALUE;
    int _24490 = NOVALUE;
    int _24489 = NOVALUE;
    int _24488 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_46591);
    _s_46593 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_46593)){
        _s_46593 = (long)DBL_PTR(_s_46593)->dbl;
    }

    /** 	if s != CurrentSub and -- ignore self-ref's*/
    _24488 = (_s_46593 != _35CurrentSub_15976);
    if (_24488 == 0) {
        goto L1; // [19] 98
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24490 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24490);
    _24491 = (int)*(((s1_ptr)_2)->base + 24);
    _24490 = NOVALUE;
    _24492 = find_from(_s_46593, _24491, 1);
    _24491 = NOVALUE;
    _24493 = (_24492 == 0);
    _24492 = NOVALUE;
    if (_24493 == 0)
    {
        DeRef(_24493);
        _24493 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24493);
        _24493 = NOVALUE;
    }

    /** 		SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_46593 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24496 = (int)*(((s1_ptr)_2)->base + 12);
    _24494 = NOVALUE;
    if (IS_ATOM_INT(_24496)) {
        _24497 = _24496 + 1;
        if (_24497 > MAXINT){
            _24497 = NewDouble((double)_24497);
        }
    }
    else
    _24497 = binary_op(PLUS, 1, _24496);
    _24496 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _24497;
    if( _1 != _24497 ){
        DeRef(_1);
    }
    _24497 = NOVALUE;
    _24494 = NOVALUE;

    /** 		SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24500 = (int)*(((s1_ptr)_2)->base + 24);
    _24498 = NOVALUE;
    if (IS_SEQUENCE(_24500) && IS_ATOM(_s_46593)) {
        Append(&_24501, _24500, _s_46593);
    }
    else if (IS_ATOM(_24500) && IS_SEQUENCE(_s_46593)) {
    }
    else {
        Concat((object_ptr)&_24501, _24500, _s_46593);
        _24500 = NOVALUE;
    }
    _24500 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _24501;
    if( _1 != _24501 ){
        DeRef(_1);
    }
    _24501 = NOVALUE;
    _24498 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_tok_46591);
    DeRef(_24488);
    _24488 = NOVALUE;
    return;
    ;
}


void _53mark_all(int _attribute_46623)
{
    int _p_46626 = NOVALUE;
    int _sym_file_46633 = NOVALUE;
    int _scope_46650 = NOVALUE;
    int _24533 = NOVALUE;
    int _24532 = NOVALUE;
    int _24531 = NOVALUE;
    int _24529 = NOVALUE;
    int _24527 = NOVALUE;
    int _24526 = NOVALUE;
    int _24525 = NOVALUE;
    int _24524 = NOVALUE;
    int _24523 = NOVALUE;
    int _24521 = NOVALUE;
    int _24520 = NOVALUE;
    int _24519 = NOVALUE;
    int _24518 = NOVALUE;
    int _24514 = NOVALUE;
    int _24513 = NOVALUE;
    int _24512 = NOVALUE;
    int _24510 = NOVALUE;
    int _24509 = NOVALUE;
    int _24507 = NOVALUE;
    int _24505 = NOVALUE;
    int _24502 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if just_mark_everything_from then*/
    if (_53just_mark_everything_from_46620 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** 		symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24502 = (int)*(((s1_ptr)_2)->base + _53just_mark_everything_from_46620);
    _2 = (int)SEQ_PTR(_24502);
    _p_46626 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46626)){
        _p_46626 = (long)DBL_PTR(_p_46626)->dbl;
    }
    _24502 = NOVALUE;

    /** 		while p != 0 do*/
L2: 
    if (_p_46626 == 0)
    goto L3; // [33] 269

    /** 			integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24505 = (int)*(((s1_ptr)_2)->base + _p_46626);
    _2 = (int)SEQ_PTR(_24505);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _sym_file_46633 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _sym_file_46633 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_sym_file_46633)){
        _sym_file_46633 = (long)DBL_PTR(_sym_file_46633)->dbl;
    }
    _24505 = NOVALUE;

    /** 			just_mark_everything_from = p*/
    _53just_mark_everything_from_46620 = _p_46626;

    /** 			if sym_file = current_file_no or find( sym_file, recheck_files ) then*/
    _24507 = (_sym_file_46633 == _35current_file_no_15968);
    if (_24507 != 0) {
        goto L4; // [68] 84
    }
    _24509 = find_from(_sym_file_46633, _53recheck_files_46693, 1);
    if (_24509 == 0)
    {
        _24509 = NOVALUE;
        goto L5; // [80] 108
    }
    else{
        _24509 = NOVALUE;
    }
L4: 

    /** 				SymTab[p][attribute] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46626 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24512 = (int)*(((s1_ptr)_2)->base + _attribute_46623);
    _24510 = NOVALUE;
    if (IS_ATOM_INT(_24512)) {
        _24513 = _24512 + 1;
        if (_24513 > MAXINT){
            _24513 = NewDouble((double)_24513);
        }
    }
    else
    _24513 = binary_op(PLUS, 1, _24512);
    _24512 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_46623);
    _1 = *(int *)_2;
    *(int *)_2 = _24513;
    if( _1 != _24513 ){
        DeRef(_1);
    }
    _24513 = NOVALUE;
    _24510 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** 				integer scope = SymTab[p][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24514 = (int)*(((s1_ptr)_2)->base + _p_46626);
    _2 = (int)SEQ_PTR(_24514);
    _scope_46650 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46650)){
        _scope_46650 = (long)DBL_PTR(_scope_46650)->dbl;
    }
    _24514 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_46650;
    switch ( _0 ){ 

        /** 					case SC_PUBLIC then*/
        case 13:

        /** 						if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24518 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
        _2 = (int)SEQ_PTR(_24518);
        _24519 = (int)*(((s1_ptr)_2)->base + _sym_file_46633);
        _24518 = NOVALUE;
        if (IS_ATOM_INT(_24519)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24519;
                 _24520 = MAKE_UINT(tu);
            }
        }
        else {
            _24520 = binary_op(AND_BITS, 6, _24519);
        }
        _24519 = NOVALUE;
        if (_24520 == 0) {
            DeRef(_24520);
            _24520 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24520) && DBL_PTR(_24520)->dbl == 0.0){
                DeRef(_24520);
                _24520 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24520);
            _24520 = NOVALUE;
        }
        DeRef(_24520);
        _24520 = NOVALUE;

        /** 							SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_46626 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24523 = (int)*(((s1_ptr)_2)->base + _attribute_46623);
        _24521 = NOVALUE;
        if (IS_ATOM_INT(_24523)) {
            _24524 = _24523 + 1;
            if (_24524 > MAXINT){
                _24524 = NewDouble((double)_24524);
            }
        }
        else
        _24524 = binary_op(PLUS, 1, _24523);
        _24523 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46623);
        _1 = *(int *)_2;
        *(int *)_2 = _24524;
        if( _1 != _24524 ){
            DeRef(_1);
        }
        _24524 = NOVALUE;
        _24521 = NOVALUE;

        /** 						break*/
        goto L7; // [182] 243

        /** 					case SC_EXPORT then*/
        case 11:

        /** 						if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24525 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
        _2 = (int)SEQ_PTR(_24525);
        _24526 = (int)*(((s1_ptr)_2)->base + _sym_file_46633);
        _24525 = NOVALUE;
        if (IS_ATOM_INT(_24526)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24526;
                 _24527 = MAKE_UINT(tu);
            }
        }
        else {
            _24527 = binary_op(AND_BITS, 2, _24526);
        }
        _24526 = NOVALUE;
        if (IS_ATOM_INT(_24527)) {
            if (_24527 != 0){
                DeRef(_24527);
                _24527 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24527)->dbl != 0.0){
                DeRef(_24527);
                _24527 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24527);
        _24527 = NOVALUE;

        /** 							break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** 					case SC_GLOBAL then*/
        case 6:

        /** 						SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_46626 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24531 = (int)*(((s1_ptr)_2)->base + _attribute_46623);
        _24529 = NOVALUE;
        if (IS_ATOM_INT(_24531)) {
            _24532 = _24531 + 1;
            if (_24532 > MAXINT){
                _24532 = NewDouble((double)_24532);
            }
        }
        else
        _24532 = binary_op(PLUS, 1, _24531);
        _24531 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46623);
        _1 = *(int *)_2;
        *(int *)_2 = _24532;
        if( _1 != _24532 ){
            DeRef(_1);
        }
        _24532 = NOVALUE;
        _24529 = NOVALUE;
    ;}L7: 
L6: 

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24533 = (int)*(((s1_ptr)_2)->base + _p_46626);
    _2 = (int)SEQ_PTR(_24533);
    _p_46626 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46626)){
        _p_46626 = (long)DBL_PTR(_p_46626)->dbl;
    }
    _24533 = NOVALUE;

    /** 		end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** end procedure*/
    DeRef(_24507);
    _24507 = NOVALUE;
    return;
    ;
}


void _53mark_final_targets()
{
    int _marked_46708 = NOVALUE;
    int _24539 = NOVALUE;
    int _24537 = NOVALUE;
    int _24536 = NOVALUE;
    int _24535 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if just_mark_everything_from then*/
    if (_53just_mark_everything_from_46620 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** 			mark_all( S_RI_TARGET )*/
    _53mark_all(53);
    goto L3; // [22] 152
L2: 

    /** 		elsif BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L3; // [29] 152
    }
    else{
    }

    /** 			mark_all( S_NREFS )*/
    _53mark_all(12);
    goto L3; // [41] 152
L1: 

    /** 	elsif length( recheck_targets ) then*/
    if (IS_SEQUENCE(_53recheck_targets_46692)){
            _24535 = SEQ_PTR(_53recheck_targets_46692)->length;
    }
    else {
        _24535 = 1;
    }
    if (_24535 == 0)
    {
        _24535 = NOVALUE;
        goto L4; // [51] 151
    }
    else{
        _24535 = NOVALUE;
    }

    /** 		for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_53recheck_targets_46692)){
            _24536 = SEQ_PTR(_53recheck_targets_46692)->length;
    }
    else {
        _24536 = 1;
    }
    {
        int _i_46706;
        _i_46706 = _24536;
L5: 
        if (_i_46706 < 1){
            goto L6; // [61] 150
        }

        /** 			integer marked = 0*/
        _marked_46708 = 0;

        /** 			if TRANSLATE then*/
        if (_35TRANSLATE_15611 == 0)
        {
            goto L7; // [77] 100
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (int)SEQ_PTR(_53recheck_targets_46692);
        _24537 = (int)*(((s1_ptr)_2)->base + _i_46706);
        Ref(_24537);
        _marked_46708 = _53MarkTargets(_24537, 53);
        _24537 = NOVALUE;
        if (!IS_ATOM_INT(_marked_46708)) {
            _1 = (long)(DBL_PTR(_marked_46708)->dbl);
            DeRefDS(_marked_46708);
            _marked_46708 = _1;
        }
        goto L8; // [97] 126
L7: 

        /** 			elsif BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto L9; // [104] 125
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (int)SEQ_PTR(_53recheck_targets_46692);
        _24539 = (int)*(((s1_ptr)_2)->base + _i_46706);
        Ref(_24539);
        _marked_46708 = _53MarkTargets(_24539, 12);
        _24539 = NOVALUE;
        if (!IS_ATOM_INT(_marked_46708)) {
            _1 = (long)(DBL_PTR(_marked_46708)->dbl);
            DeRefDS(_marked_46708);
            _marked_46708 = _1;
        }
L9: 
L8: 

        /** 			if marked then*/
        if (_marked_46708 == 0)
        {
            goto LA; // [128] 141
        }
        else{
        }

        /** 				recheck_targets = remove( recheck_targets, i )*/
        {
            s1_ptr assign_space = SEQ_PTR(_53recheck_targets_46692);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_46706)) ? _i_46706 : (long)(DBL_PTR(_i_46706)->dbl);
            int stop = (IS_ATOM_INT(_i_46706)) ? _i_46706 : (long)(DBL_PTR(_i_46706)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_53recheck_targets_46692), start, &_53recheck_targets_46692 );
                }
                else Tail(SEQ_PTR(_53recheck_targets_46692), stop+1, &_53recheck_targets_46692);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_53recheck_targets_46692), start, &_53recheck_targets_46692);
            }
            else {
                assign_slice_seq = &assign_space;
                _53recheck_targets_46692 = Remove_elements(start, stop, (SEQ_PTR(_53recheck_targets_46692)->ref == 1));
            }
        }
LA: 

        /** 		end for*/
        _i_46706 = _i_46706 + -1;
        goto L5; // [145] 68
L6: 
        ;
    }
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _53is_routine(int _sym_46726)
{
    int _tok_46727 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer tok = sym_token( sym )*/
    _tok_46727 = _53sym_token(_sym_46726);
    if (!IS_ATOM_INT(_tok_46727)) {
        _1 = (long)(DBL_PTR(_tok_46727)->dbl);
        DeRefDS(_tok_46727);
        _tok_46727 = _1;
    }

    /** 	switch tok do*/
    _0 = _tok_46727;
    switch ( _0 ){ 

        /** 		case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** 			return 1*/
        return 1;
        goto L1; // [32] 45

        /** 		case else*/
        default:

        /** 			return 0*/
        return 0;
    ;}L1: 
    ;
}


int _53is_visible(int _sym_46740, int _from_file_46741)
{
    int _scope_46742 = NOVALUE;
    int _sym_file_46745 = NOVALUE;
    int _visible_mask_46750 = NOVALUE;
    int _24553 = NOVALUE;
    int _24552 = NOVALUE;
    int _24551 = NOVALUE;
    int _24550 = NOVALUE;
    int _24546 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer scope = sym_scope( sym )*/
    _scope_46742 = _53sym_scope(_sym_46740);
    if (!IS_ATOM_INT(_scope_46742)) {
        _1 = (long)(DBL_PTR(_scope_46742)->dbl);
        DeRefDS(_scope_46742);
        _scope_46742 = _1;
    }

    /** 	integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24546 = (int)*(((s1_ptr)_2)->base + _sym_46740);
    _2 = (int)SEQ_PTR(_24546);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _sym_file_46745 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _sym_file_46745 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_sym_file_46745)){
        _sym_file_46745 = (long)DBL_PTR(_sym_file_46745)->dbl;
    }
    _24546 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_46742;
    switch ( _0 ){ 

        /** 		case SC_PUBLIC then*/
        case 13:

        /** 			visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_46750 = 6;
        goto L1; // [49] 93

        /** 		case SC_EXPORT then*/
        case 11:

        /** 			visible_mask = DIRECT_INCLUDE*/
        _visible_mask_46750 = 2;
        goto L1; // [64] 93

        /** 		case SC_GLOBAL then*/
        case 6:

        /** 			return 1*/
        return 1;
        goto L1; // [76] 93

        /** 		case else*/
        default:

        /** 			return from_file = sym_file*/
        _24550 = (_from_file_46741 == _sym_file_46745);
        return _24550;
    ;}L1: 

    /** 	return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _24551 = (int)*(((s1_ptr)_2)->base + _from_file_46741);
    _2 = (int)SEQ_PTR(_24551);
    _24552 = (int)*(((s1_ptr)_2)->base + _sym_file_46745);
    _24551 = NOVALUE;
    if (IS_ATOM_INT(_24552)) {
        {unsigned long tu;
             tu = (unsigned long)_visible_mask_46750 & (unsigned long)_24552;
             _24553 = MAKE_UINT(tu);
        }
    }
    else {
        _24553 = binary_op(AND_BITS, _visible_mask_46750, _24552);
    }
    _24552 = NOVALUE;
    DeRef(_24550);
    _24550 = NOVALUE;
    return _24553;
    ;
}


int _53MarkTargets(int _s_46770, int _attribute_46771)
{
    int _p_46773 = NOVALUE;
    int _sname_46774 = NOVALUE;
    int _string_46775 = NOVALUE;
    int _colon_46776 = NOVALUE;
    int _h_46777 = NOVALUE;
    int _scope_46778 = NOVALUE;
    int _found_46799 = NOVALUE;
    int _24605 = NOVALUE;
    int _24601 = NOVALUE;
    int _24599 = NOVALUE;
    int _24598 = NOVALUE;
    int _24597 = NOVALUE;
    int _24596 = NOVALUE;
    int _24594 = NOVALUE;
    int _24593 = NOVALUE;
    int _24592 = NOVALUE;
    int _24591 = NOVALUE;
    int _24590 = NOVALUE;
    int _24588 = NOVALUE;
    int _24587 = NOVALUE;
    int _24586 = NOVALUE;
    int _24584 = NOVALUE;
    int _24582 = NOVALUE;
    int _24580 = NOVALUE;
    int _24579 = NOVALUE;
    int _24578 = NOVALUE;
    int _24577 = NOVALUE;
    int _24575 = NOVALUE;
    int _24574 = NOVALUE;
    int _24573 = NOVALUE;
    int _24572 = NOVALUE;
    int _24570 = NOVALUE;
    int _24569 = NOVALUE;
    int _24565 = NOVALUE;
    int _24564 = NOVALUE;
    int _24563 = NOVALUE;
    int _24562 = NOVALUE;
    int _24561 = NOVALUE;
    int _24560 = NOVALUE;
    int _24559 = NOVALUE;
    int _24558 = NOVALUE;
    int _24557 = NOVALUE;
    int _24556 = NOVALUE;
    int _24555 = NOVALUE;
    int _24554 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_46770)) {
        _1 = (long)(DBL_PTR(_s_46770)->dbl);
        DeRefDS(_s_46770);
        _s_46770 = _1;
    }
    if (!IS_ATOM_INT(_attribute_46771)) {
        _1 = (long)(DBL_PTR(_attribute_46771)->dbl);
        DeRefDS(_attribute_46771);
        _attribute_46771 = _1;
    }

    /** 	sequence sname*/

    /** 	sequence string*/

    /** 	integer colon, h*/

    /** 	integer scope*/

    /** 	if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24554 = (int)*(((s1_ptr)_2)->base + _s_46770);
    _2 = (int)SEQ_PTR(_24554);
    _24555 = (int)*(((s1_ptr)_2)->base + 3);
    _24554 = NOVALUE;
    if (IS_ATOM_INT(_24555)) {
        _24556 = (_24555 == 3);
    }
    else {
        _24556 = binary_op(EQUALS, _24555, 3);
    }
    _24555 = NOVALUE;
    if (IS_ATOM_INT(_24556)) {
        if (_24556 != 0) {
            _24557 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24556)->dbl != 0.0) {
            _24557 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24558 = (int)*(((s1_ptr)_2)->base + _s_46770);
    _2 = (int)SEQ_PTR(_24558);
    _24559 = (int)*(((s1_ptr)_2)->base + 3);
    _24558 = NOVALUE;
    if (IS_ATOM_INT(_24559)) {
        _24560 = (_24559 == 2);
    }
    else {
        _24560 = binary_op(EQUALS, _24559, 2);
    }
    _24559 = NOVALUE;
    DeRef(_24557);
    if (IS_ATOM_INT(_24560))
    _24557 = (_24560 != 0);
    else
    _24557 = DBL_PTR(_24560)->dbl != 0.0;
L1: 
    if (_24557 == 0) {
        goto L2; // [59] 440
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24562 = (int)*(((s1_ptr)_2)->base + _s_46770);
    _2 = (int)SEQ_PTR(_24562);
    _24563 = (int)*(((s1_ptr)_2)->base + 1);
    _24562 = NOVALUE;
    _24564 = IS_SEQUENCE(_24563);
    _24563 = NOVALUE;
    if (_24564 == 0)
    {
        _24564 = NOVALUE;
        goto L2; // [79] 440
    }
    else{
        _24564 = NOVALUE;
    }

    /** 		integer found = 0*/
    _found_46799 = 0;

    /** 		string = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24565 = (int)*(((s1_ptr)_2)->base + _s_46770);
    DeRef(_string_46775);
    _2 = (int)SEQ_PTR(_24565);
    _string_46775 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_string_46775);
    _24565 = NOVALUE;

    /** 		colon = find(':', string)*/
    _colon_46776 = find_from(58, _string_46775, 1);

    /** 		if colon = 0 then*/
    if (_colon_46776 != 0)
    goto L3; // [112] 126

    /** 			sname = string*/
    RefDS(_string_46775);
    DeRef(_sname_46774);
    _sname_46774 = _string_46775;
    goto L4; // [123] 200
L3: 

    /** 			sname = string[colon+1..$]  -- ignore namespace part*/
    _24569 = _colon_46776 + 1;
    if (_24569 > MAXINT){
        _24569 = NewDouble((double)_24569);
    }
    if (IS_SEQUENCE(_string_46775)){
            _24570 = SEQ_PTR(_string_46775)->length;
    }
    else {
        _24570 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_46774;
    RHS_Slice(_string_46775, _24569, _24570);

    /** 			while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_46774)){
            _24572 = SEQ_PTR(_sname_46774)->length;
    }
    else {
        _24572 = 1;
    }
    if (_24572 == 0) {
        _24573 = 0;
        goto L6; // [148] 164
    }
    _2 = (int)SEQ_PTR(_sname_46774);
    _24574 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24574)) {
        _24575 = (_24574 == 32);
    }
    else {
        _24575 = binary_op(EQUALS, _24574, 32);
    }
    _24574 = NOVALUE;
    if (IS_ATOM_INT(_24575))
    _24573 = (_24575 != 0);
    else
    _24573 = DBL_PTR(_24575)->dbl != 0.0;
L6: 
    if (_24573 != 0) {
        goto L7; // [164] 181
    }
    _2 = (int)SEQ_PTR(_sname_46774);
    _24577 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24577)) {
        _24578 = (_24577 == 9);
    }
    else {
        _24578 = binary_op(EQUALS, _24577, 9);
    }
    _24577 = NOVALUE;
    if (_24578 <= 0) {
        if (_24578 == 0) {
            DeRef(_24578);
            _24578 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24578) && DBL_PTR(_24578)->dbl == 0.0){
                DeRef(_24578);
                _24578 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24578);
            _24578 = NOVALUE;
        }
    }
    DeRef(_24578);
    _24578 = NOVALUE;
L7: 

    /** 				sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_46774)){
            _24579 = SEQ_PTR(_sname_46774)->length;
    }
    else {
        _24579 = 1;
    }
    _24580 = _24579 - 1;
    _24579 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_46774)->length;
        int size = (IS_ATOM_INT(_24580)) ? _24580 : (long)(DBL_PTR(_24580)->dbl);
        if (size <= 0) {
            DeRef(_sname_46774);
            _sname_46774 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_46774);
            DeRef(_sname_46774);
            _sname_46774 = _sname_46774;
        }
        else Tail(SEQ_PTR(_sname_46774), len-size+1, &_sname_46774);
    }
    _24580 = NOVALUE;

    /** 			end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** 		if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_46774)){
            _24582 = SEQ_PTR(_sname_46774)->length;
    }
    else {
        _24582 = 1;
    }
    if (_24582 != 0)
    goto L9; // [207] 218

    /** 			return 1*/
    DeRefDS(_sname_46774);
    DeRef(_string_46775);
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24556);
    _24556 = NOVALUE;
    DeRef(_24560);
    _24560 = NOVALUE;
    DeRef(_24575);
    _24575 = NOVALUE;
    return 1;
L9: 

    /** 		h = buckets[hashfn(sname)]*/
    RefDS(_sname_46774);
    _24584 = _53hashfn(_sname_46774);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_24584)){
        _h_46777 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24584)->dbl));
    }
    else{
        _h_46777 = (int)*(((s1_ptr)_2)->base + _24584);
    }
    if (!IS_ATOM_INT(_h_46777))
    _h_46777 = (long)DBL_PTR(_h_46777)->dbl;

    /** 		while h do*/
LA: 
    if (_h_46777 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** 			if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24586 = (int)*(((s1_ptr)_2)->base + _h_46777);
    _2 = (int)SEQ_PTR(_24586);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24587 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24587 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24586 = NOVALUE;
    if (_sname_46774 == _24587)
    _24588 = 1;
    else if (IS_ATOM_INT(_sname_46774) && IS_ATOM_INT(_24587))
    _24588 = 0;
    else
    _24588 = (compare(_sname_46774, _24587) == 0);
    _24587 = NOVALUE;
    if (_24588 == 0)
    {
        _24588 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24588 = NOVALUE;
    }

    /** 				if attribute = S_NREFS then*/
    if (_attribute_46771 != 12)
    goto LD; // [263] 289

    /** 					if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** 						add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 27;
    ((int *)_2)[2] = _h_46777;
    _24590 = MAKE_SEQ(_1);
    _53add_ref(_24590);
    _24590 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** 				elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24591 = _53is_routine(_h_46777);
    if (IS_ATOM_INT(_24591)) {
        if (_24591 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24591)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24593 = _53is_visible(_h_46777, _35current_file_no_15968);
    if (_24593 == 0) {
        DeRef(_24593);
        _24593 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24593) && DBL_PTR(_24593)->dbl == 0.0){
            DeRef(_24593);
            _24593 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24593);
        _24593 = NOVALUE;
    }
    DeRef(_24593);
    _24593 = NOVALUE;

    /** 					SymTab[h][attribute] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_h_46777 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24596 = (int)*(((s1_ptr)_2)->base + _attribute_46771);
    _24594 = NOVALUE;
    if (IS_ATOM_INT(_24596)) {
        _24597 = _24596 + 1;
        if (_24597 > MAXINT){
            _24597 = NewDouble((double)_24597);
        }
    }
    else
    _24597 = binary_op(PLUS, 1, _24596);
    _24596 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_46771);
    _1 = *(int *)_2;
    *(int *)_2 = _24597;
    if( _1 != _24597 ){
        DeRef(_1);
    }
    _24597 = NOVALUE;
    _24594 = NOVALUE;

    /** 					if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24598 = (int)*(((s1_ptr)_2)->base + _h_46777);
    _2 = (int)SEQ_PTR(_24598);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24599 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24599 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24598 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_15968, _24599)){
        _24599 = NOVALUE;
        goto L10; // [347] 357
    }
    _24599 = NOVALUE;

    /** 						found = 1*/
    _found_46799 = 1;
L10: 
LF: 
LE: 
LC: 

    /** 			h = SymTab[h][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24601 = (int)*(((s1_ptr)_2)->base + _h_46777);
    _2 = (int)SEQ_PTR(_24601);
    _h_46777 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_46777)){
        _h_46777 = (long)DBL_PTR(_h_46777)->dbl;
    }
    _24601 = NOVALUE;

    /** 		end while*/
    goto LA; // [378] 235
LB: 

    /** 		if not found then*/
    if (_found_46799 != 0)
    goto L11; // [383] 429

    /** 			just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_46620 = _35TopLevelSub_15975;

    /** 			recheck_targets &= s*/
    Append(&_53recheck_targets_46692, _53recheck_targets_46692, _s_46770);

    /** 			if not find( current_file_no, recheck_files ) then*/
    _24605 = find_from(_35current_file_no_15968, _53recheck_files_46693, 1);
    if (_24605 != 0)
    goto L12; // [414] 428
    _24605 = NOVALUE;

    /** 				recheck_files &= current_file_no*/
    Append(&_53recheck_files_46693, _53recheck_files_46693, _35current_file_no_15968);
L12: 
L11: 

    /** 		return found*/
    DeRef(_sname_46774);
    DeRef(_string_46775);
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24556);
    _24556 = NOVALUE;
    DeRef(_24560);
    _24560 = NOVALUE;
    DeRef(_24584);
    _24584 = NOVALUE;
    DeRef(_24575);
    _24575 = NOVALUE;
    DeRef(_24591);
    _24591 = NOVALUE;
    return _found_46799;
    goto L13; // [437] 469
L2: 

    /** 		if not just_mark_everything_from then*/
    if (_53just_mark_everything_from_46620 != 0)
    goto L14; // [444] 457

    /** 			just_mark_everything_from = TopLevelSub*/
    _53just_mark_everything_from_46620 = _35TopLevelSub_15975;
L14: 

    /** 		mark_all( attribute )*/
    _53mark_all(_attribute_46771);

    /** 		return 1*/
    DeRef(_sname_46774);
    DeRef(_string_46775);
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24556);
    _24556 = NOVALUE;
    DeRef(_24560);
    _24560 = NOVALUE;
    DeRef(_24584);
    _24584 = NOVALUE;
    DeRef(_24575);
    _24575 = NOVALUE;
    DeRef(_24591);
    _24591 = NOVALUE;
    return 1;
L13: 
    ;
}


void _53resolve_unincluded_globals(int _ok_46884)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ok_46884)) {
        _1 = (long)(DBL_PTR(_ok_46884)->dbl);
        DeRefDS(_ok_46884);
        _ok_46884 = _1;
    }

    /** 	Resolve_unincluded_globals = ok*/
    _53Resolve_unincluded_globals_46881 = _ok_46884;

    /** end procedure*/
    return;
    ;
}


int _53get_resolve_unincluded_globals()
{
    int _0, _1, _2;
    

    /** 	return Resolve_unincluded_globals*/
    return _53Resolve_unincluded_globals_46881;
    ;
}


int _53keyfind(int _word_46890, int _file_no_46891, int _scanning_file_46892, int _namespace_ok_46895, int _hashval_46896)
{
    int _msg_46898 = NOVALUE;
    int _b_name_46899 = NOVALUE;
    int _scope_46900 = NOVALUE;
    int _defined_46901 = NOVALUE;
    int _ix_46902 = NOVALUE;
    int _st_ptr_46904 = NOVALUE;
    int _st_builtin_46905 = NOVALUE;
    int _tok_46907 = NOVALUE;
    int _gtok_46908 = NOVALUE;
    int _any_symbol_46911 = NOVALUE;
    int _tok_file_47079 = NOVALUE;
    int _good_47086 = NOVALUE;
    int _include_type_47096 = NOVALUE;
    int _msg_file_47152 = NOVALUE;
    int _24800 = NOVALUE;
    int _24799 = NOVALUE;
    int _24797 = NOVALUE;
    int _24795 = NOVALUE;
    int _24794 = NOVALUE;
    int _24793 = NOVALUE;
    int _24792 = NOVALUE;
    int _24791 = NOVALUE;
    int _24789 = NOVALUE;
    int _24787 = NOVALUE;
    int _24786 = NOVALUE;
    int _24785 = NOVALUE;
    int _24784 = NOVALUE;
    int _24783 = NOVALUE;
    int _24782 = NOVALUE;
    int _24781 = NOVALUE;
    int _24780 = NOVALUE;
    int _24778 = NOVALUE;
    int _24777 = NOVALUE;
    int _24776 = NOVALUE;
    int _24775 = NOVALUE;
    int _24774 = NOVALUE;
    int _24773 = NOVALUE;
    int _24772 = NOVALUE;
    int _24771 = NOVALUE;
    int _24770 = NOVALUE;
    int _24769 = NOVALUE;
    int _24768 = NOVALUE;
    int _24767 = NOVALUE;
    int _24766 = NOVALUE;
    int _24765 = NOVALUE;
    int _24764 = NOVALUE;
    int _24763 = NOVALUE;
    int _24762 = NOVALUE;
    int _24760 = NOVALUE;
    int _24759 = NOVALUE;
    int _24756 = NOVALUE;
    int _24752 = NOVALUE;
    int _24750 = NOVALUE;
    int _24749 = NOVALUE;
    int _24748 = NOVALUE;
    int _24747 = NOVALUE;
    int _24746 = NOVALUE;
    int _24744 = NOVALUE;
    int _24743 = NOVALUE;
    int _24742 = NOVALUE;
    int _24741 = NOVALUE;
    int _24739 = NOVALUE;
    int _24736 = NOVALUE;
    int _24735 = NOVALUE;
    int _24734 = NOVALUE;
    int _24733 = NOVALUE;
    int _24731 = NOVALUE;
    int _24728 = NOVALUE;
    int _24727 = NOVALUE;
    int _24726 = NOVALUE;
    int _24725 = NOVALUE;
    int _24724 = NOVALUE;
    int _24723 = NOVALUE;
    int _24722 = NOVALUE;
    int _24719 = NOVALUE;
    int _24718 = NOVALUE;
    int _24716 = NOVALUE;
    int _24714 = NOVALUE;
    int _24712 = NOVALUE;
    int _24711 = NOVALUE;
    int _24710 = NOVALUE;
    int _24706 = NOVALUE;
    int _24705 = NOVALUE;
    int _24700 = NOVALUE;
    int _24698 = NOVALUE;
    int _24696 = NOVALUE;
    int _24695 = NOVALUE;
    int _24691 = NOVALUE;
    int _24690 = NOVALUE;
    int _24688 = NOVALUE;
    int _24687 = NOVALUE;
    int _24685 = NOVALUE;
    int _24684 = NOVALUE;
    int _24683 = NOVALUE;
    int _24682 = NOVALUE;
    int _24681 = NOVALUE;
    int _24679 = NOVALUE;
    int _24678 = NOVALUE;
    int _24677 = NOVALUE;
    int _24676 = NOVALUE;
    int _24675 = NOVALUE;
    int _24674 = NOVALUE;
    int _24673 = NOVALUE;
    int _24672 = NOVALUE;
    int _24671 = NOVALUE;
    int _24670 = NOVALUE;
    int _24669 = NOVALUE;
    int _24668 = NOVALUE;
    int _24667 = NOVALUE;
    int _24666 = NOVALUE;
    int _24665 = NOVALUE;
    int _24664 = NOVALUE;
    int _24663 = NOVALUE;
    int _24662 = NOVALUE;
    int _24661 = NOVALUE;
    int _24660 = NOVALUE;
    int _24659 = NOVALUE;
    int _24658 = NOVALUE;
    int _24656 = NOVALUE;
    int _24655 = NOVALUE;
    int _24653 = NOVALUE;
    int _24652 = NOVALUE;
    int _24651 = NOVALUE;
    int _24650 = NOVALUE;
    int _24649 = NOVALUE;
    int _24647 = NOVALUE;
    int _24646 = NOVALUE;
    int _24645 = NOVALUE;
    int _24643 = NOVALUE;
    int _24642 = NOVALUE;
    int _24641 = NOVALUE;
    int _24640 = NOVALUE;
    int _24639 = NOVALUE;
    int _24638 = NOVALUE;
    int _24637 = NOVALUE;
    int _24635 = NOVALUE;
    int _24634 = NOVALUE;
    int _24629 = NOVALUE;
    int _24626 = NOVALUE;
    int _24625 = NOVALUE;
    int _24624 = NOVALUE;
    int _24623 = NOVALUE;
    int _24622 = NOVALUE;
    int _24621 = NOVALUE;
    int _24620 = NOVALUE;
    int _24619 = NOVALUE;
    int _24618 = NOVALUE;
    int _24617 = NOVALUE;
    int _24616 = NOVALUE;
    int _24615 = NOVALUE;
    int _24614 = NOVALUE;
    int _24613 = NOVALUE;
    int _24612 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_46891)) {
        _1 = (long)(DBL_PTR(_file_no_46891)->dbl);
        DeRefDS(_file_no_46891);
        _file_no_46891 = _1;
    }
    if (!IS_ATOM_INT(_scanning_file_46892)) {
        _1 = (long)(DBL_PTR(_scanning_file_46892)->dbl);
        DeRefDS(_scanning_file_46892);
        _scanning_file_46892 = _1;
    }
    if (!IS_ATOM_INT(_namespace_ok_46895)) {
        _1 = (long)(DBL_PTR(_namespace_ok_46895)->dbl);
        DeRefDS(_namespace_ok_46895);
        _namespace_ok_46895 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46896)) {
        _1 = (long)(DBL_PTR(_hashval_46896)->dbl);
        DeRefDS(_hashval_46896);
        _hashval_46896 = _1;
    }

    /** 	dup_globals = {}*/
    RefDS(_21815);
    DeRef(_53dup_globals_46876);
    _53dup_globals_46876 = _21815;

    /** 	dup_overrides = {}*/
    RefDS(_21815);
    DeRefi(_53dup_overrides_46877);
    _53dup_overrides_46877 = _21815;

    /** 	in_include_path = {}*/
    RefDS(_21815);
    DeRef(_53in_include_path_46878);
    _53in_include_path_46878 = _21815;

    /** 	symbol_resolution_warning = ""*/
    RefDS(_21815);
    DeRef(_35symbol_resolution_warning_16069);
    _35symbol_resolution_warning_16069 = _21815;

    /** 	st_builtin = 0*/
    _st_builtin_46905 = 0;

    /** 	ifdef EUDIS then*/

    /** 	st_ptr = buckets[hashval]*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _st_ptr_46904 = (int)*(((s1_ptr)_2)->base + _hashval_46896);
    if (!IS_ATOM_INT(_st_ptr_46904)){
        _st_ptr_46904 = (long)DBL_PTR(_st_ptr_46904)->dbl;
    }

    /** 	integer any_symbol = namespace_ok = -1*/
    _any_symbol_46911 = (_namespace_ok_46895 == -1);

    /** 	while st_ptr do*/
L1: 
    if (_st_ptr_46904 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** 		if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24612 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24612);
    _24613 = (int)*(((s1_ptr)_2)->base + 4);
    _24612 = NOVALUE;
    if (IS_ATOM_INT(_24613)) {
        _24614 = (_24613 != 9);
    }
    else {
        _24614 = binary_op(NOTEQ, _24613, 9);
    }
    _24613 = NOVALUE;
    if (IS_ATOM_INT(_24614)) {
        if (_24614 == 0) {
            DeRef(_24615);
            _24615 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24614)->dbl == 0.0) {
            DeRef(_24615);
            _24615 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24616 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24616);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24617 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24617 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24616 = NOVALUE;
    if (_word_46890 == _24617)
    _24618 = 1;
    else if (IS_ATOM_INT(_word_46890) && IS_ATOM_INT(_24617))
    _24618 = 0;
    else
    _24618 = (compare(_word_46890, _24617) == 0);
    _24617 = NOVALUE;
    DeRef(_24615);
    _24615 = (_24618 != 0);
L3: 
    if (_24615 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_46911 != 0) {
        DeRef(_24620);
        _24620 = 1;
        goto L5; // [120] 150
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24621 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24621);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24622 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24622 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24621 = NOVALUE;
    if (IS_ATOM_INT(_24622)) {
        _24623 = (_24622 == 523);
    }
    else {
        _24623 = binary_op(EQUALS, _24622, 523);
    }
    _24622 = NOVALUE;
    if (IS_ATOM_INT(_24623)) {
        _24624 = (_namespace_ok_46895 == _24623);
    }
    else {
        _24624 = binary_op(EQUALS, _namespace_ok_46895, _24623);
    }
    DeRef(_24623);
    _24623 = NOVALUE;
    if (IS_ATOM_INT(_24624))
    _24620 = (_24624 != 0);
    else
    _24620 = DBL_PTR(_24624)->dbl != 0.0;
L5: 
    if (_24620 == 0)
    {
        _24620 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24620 = NOVALUE;
    }

    /** 			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24625 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24625);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24626 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24626 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24625 = NOVALUE;
    Ref(_24626);
    DeRef(_tok_46907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24626;
    ((int *)_2)[2] = _st_ptr_46904;
    _tok_46907 = MAKE_SEQ(_1);
    _24626 = NOVALUE;

    /** 			if file_no = -1 then*/
    if (_file_no_46891 != -1)
    goto L6; // [174] 714

    /** 				scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24629 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24629);
    _scope_46900 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46900)){
        _scope_46900 = (long)DBL_PTR(_scope_46900)->dbl;
    }
    _24629 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_46900;
    switch ( _0 ){ 

        /** 				case SC_OVERRIDE then*/
        case 12:

        /** 					dup_overrides &= st_ptr*/
        Append(&_53dup_overrides_46877, _53dup_overrides_46877, _st_ptr_46904);

        /** 					break*/
        goto L7; // [215] 1011

        /** 				case SC_PREDEF then*/
        case 7:

        /** 					st_builtin = st_ptr*/
        _st_builtin_46905 = _st_ptr_46904;

        /** 					break*/
        goto L7; // [230] 1011

        /** 				case SC_GLOBAL then*/
        case 6:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24634 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24634);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24635 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24635 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24634 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46892, _24635)){
            _24635 = NOVALUE;
            goto L8; // [250] 274
        }
        _24635 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46907);
        _53add_ref(_tok_46907);
L9: 

        /** 						return tok*/
        DeRefDS(_word_46890);
        DeRef(_msg_46898);
        DeRef(_b_name_46899);
        DeRef(_gtok_46908);
        DeRef(_24624);
        _24624 = NOVALUE;
        DeRef(_24614);
        _24614 = NOVALUE;
        return _tok_46907;
L8: 

        /** 					if Resolve_unincluded_globals */
        if (_53Resolve_unincluded_globals_46881 != 0) {
            _24637 = 1;
            goto LA; // [278] 322
        }
        _2 = (int)SEQ_PTR(_36finished_files_14984);
        _24638 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        if (_24638 == 0) {
            _24639 = 0;
            goto LB; // [288] 318
        }
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24640 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24641 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24641);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24642 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24642 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24641 = NOVALUE;
        _2 = (int)SEQ_PTR(_24640);
        if (!IS_ATOM_INT(_24642)){
            _24643 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24642)->dbl));
        }
        else{
            _24643 = (int)*(((s1_ptr)_2)->base + _24642);
        }
        _24640 = NOVALUE;
        if (IS_ATOM_INT(_24643))
        _24639 = (_24643 != 0);
        else
        _24639 = DBL_PTR(_24643)->dbl != 0.0;
LB: 
        _24637 = (_24639 != 0);
LA: 
        if (_24637 != 0) {
            goto LC; // [322] 349
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24645 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24645);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _24646 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _24646 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _24645 = NOVALUE;
        if (IS_ATOM_INT(_24646)) {
            _24647 = (_24646 == 523);
        }
        else {
            _24647 = binary_op(EQUALS, _24646, 523);
        }
        _24646 = NOVALUE;
        if (_24647 == 0) {
            DeRef(_24647);
            _24647 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24647) && DBL_PTR(_24647)->dbl == 0.0){
                DeRef(_24647);
                _24647 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24647);
            _24647 = NOVALUE;
        }
        DeRef(_24647);
        _24647 = NOVALUE;
LC: 

        /** 						gtok = tok*/
        Ref(_tok_46907);
        DeRef(_gtok_46908);
        _gtok_46908 = _tok_46907;

        /** 						dup_globals &= st_ptr*/
        Append(&_53dup_globals_46876, _53dup_globals_46876, _st_ptr_46904);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24649 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24650 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24650);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24651 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24651 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24650 = NOVALUE;
        _2 = (int)SEQ_PTR(_24649);
        if (!IS_ATOM_INT(_24651)){
            _24652 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24651)->dbl));
        }
        else{
            _24652 = (int)*(((s1_ptr)_2)->base + _24651);
        }
        _24649 = NOVALUE;
        if (IS_ATOM_INT(_24652)) {
            _24653 = (_24652 != 0);
        }
        else {
            _24653 = binary_op(NOTEQ, _24652, 0);
        }
        _24652 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_46878) && IS_ATOM(_24653)) {
            Ref(_24653);
            Append(&_53in_include_path_46878, _53in_include_path_46878, _24653);
        }
        else if (IS_ATOM(_53in_include_path_46878) && IS_SEQUENCE(_24653)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_46878, _53in_include_path_46878, _24653);
        }
        DeRef(_24653);
        _24653 = NOVALUE;

        /** 					break*/
        goto L7; // [399] 1011

        /** 				case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24655 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24655);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24656 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24656 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24655 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46892, _24656)){
            _24656 = NOVALUE;
            goto LD; // [421] 445
        }
        _24656 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46907);
        _53add_ref(_tok_46907);
LE: 

        /** 						return tok*/
        DeRefDS(_word_46890);
        DeRef(_msg_46898);
        DeRef(_b_name_46899);
        DeRef(_gtok_46908);
        DeRef(_24624);
        _24624 = NOVALUE;
        DeRef(_24614);
        _24614 = NOVALUE;
        _24638 = NOVALUE;
        _24643 = NOVALUE;
        _24642 = NOVALUE;
        _24651 = NOVALUE;
        return _tok_46907;
LD: 

        /** 					if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (int)SEQ_PTR(_36finished_files_14984);
        _24658 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        if (_24658 != 0) {
            _24659 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_46895 == 0) {
            _24660 = 0;
            goto L10; // [457] 483
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24661 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24661);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _24662 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _24662 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _24661 = NOVALUE;
        if (IS_ATOM_INT(_24662)) {
            _24663 = (_24662 == 523);
        }
        else {
            _24663 = binary_op(EQUALS, _24662, 523);
        }
        _24662 = NOVALUE;
        if (IS_ATOM_INT(_24663))
        _24660 = (_24663 != 0);
        else
        _24660 = DBL_PTR(_24663)->dbl != 0.0;
L10: 
        _24659 = (_24660 != 0);
LF: 
        if (_24659 == 0) {
            goto L7; // [487] 1011
        }
        _24665 = (_scope_46900 == 13);
        if (_24665 == 0) {
            _24666 = 0;
            goto L11; // [497] 533
        }
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24667 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24668 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24668);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24669 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24669 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24668 = NOVALUE;
        _2 = (int)SEQ_PTR(_24667);
        if (!IS_ATOM_INT(_24669)){
            _24670 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24669)->dbl));
        }
        else{
            _24670 = (int)*(((s1_ptr)_2)->base + _24669);
        }
        _24667 = NOVALUE;
        if (IS_ATOM_INT(_24670)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24670;
                 _24671 = MAKE_UINT(tu);
            }
        }
        else {
            _24671 = binary_op(AND_BITS, 6, _24670);
        }
        _24670 = NOVALUE;
        if (IS_ATOM_INT(_24671))
        _24666 = (_24671 != 0);
        else
        _24666 = DBL_PTR(_24671)->dbl != 0.0;
L11: 
        if (_24666 != 0) {
            DeRef(_24672);
            _24672 = 1;
            goto L12; // [533] 583
        }
        _24673 = (_scope_46900 == 11);
        if (_24673 == 0) {
            _24674 = 0;
            goto L13; // [543] 579
        }
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24675 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24676 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24676);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24677 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24677 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24676 = NOVALUE;
        _2 = (int)SEQ_PTR(_24675);
        if (!IS_ATOM_INT(_24677)){
            _24678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24677)->dbl));
        }
        else{
            _24678 = (int)*(((s1_ptr)_2)->base + _24677);
        }
        _24675 = NOVALUE;
        if (IS_ATOM_INT(_24678)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24678;
                 _24679 = MAKE_UINT(tu);
            }
        }
        else {
            _24679 = binary_op(AND_BITS, 2, _24678);
        }
        _24678 = NOVALUE;
        if (IS_ATOM_INT(_24679))
        _24674 = (_24679 != 0);
        else
        _24674 = DBL_PTR(_24679)->dbl != 0.0;
L13: 
        DeRef(_24672);
        _24672 = (_24674 != 0);
L12: 
        if (_24672 == 0)
        {
            _24672 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24672 = NOVALUE;
        }

        /** 						gtok = tok*/
        Ref(_tok_46907);
        DeRef(_gtok_46908);
        _gtok_46908 = _tok_46907;

        /** 						dup_globals &= st_ptr*/
        Append(&_53dup_globals_46876, _53dup_globals_46876, _st_ptr_46904);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _24681 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24682 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24682);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24683 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24682 = NOVALUE;
        _2 = (int)SEQ_PTR(_24681);
        if (!IS_ATOM_INT(_24683)){
            _24684 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24683)->dbl));
        }
        else{
            _24684 = (int)*(((s1_ptr)_2)->base + _24683);
        }
        _24681 = NOVALUE;
        if (IS_ATOM_INT(_24684)) {
            _24685 = (_24684 != 0);
        }
        else {
            _24685 = binary_op(NOTEQ, _24684, 0);
        }
        _24684 = NOVALUE;
        if (IS_SEQUENCE(_53in_include_path_46878) && IS_ATOM(_24685)) {
            Ref(_24685);
            Append(&_53in_include_path_46878, _53in_include_path_46878, _24685);
        }
        else if (IS_ATOM(_53in_include_path_46878) && IS_SEQUENCE(_24685)) {
        }
        else {
            Concat((object_ptr)&_53in_include_path_46878, _53in_include_path_46878, _24685);
        }
        DeRef(_24685);
        _24685 = NOVALUE;

        /** ifdef STDDEBUG then*/

        /** 					break*/
        goto L7; // [639] 1011

        /** 				case SC_LOCAL then*/
        case 5:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24687 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
        _2 = (int)SEQ_PTR(_24687);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24688 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24688 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24687 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46892, _24688)){
            _24688 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24688 = NOVALUE;

        /** 						if BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46907);
        _53add_ref(_tok_46907);
L14: 

        /** 						return tok*/
        DeRefDS(_word_46890);
        DeRef(_msg_46898);
        DeRef(_b_name_46899);
        DeRef(_gtok_46908);
        DeRef(_24624);
        _24624 = NOVALUE;
        DeRef(_24614);
        _24614 = NOVALUE;
        _24638 = NOVALUE;
        _24643 = NOVALUE;
        _24642 = NOVALUE;
        _24658 = NOVALUE;
        _24651 = NOVALUE;
        DeRef(_24665);
        _24665 = NOVALUE;
        DeRef(_24663);
        _24663 = NOVALUE;
        DeRef(_24673);
        _24673 = NOVALUE;
        _24669 = NOVALUE;
        DeRef(_24671);
        _24671 = NOVALUE;
        _24677 = NOVALUE;
        DeRef(_24679);
        _24679 = NOVALUE;
        _24683 = NOVALUE;
        return _tok_46907;

        /** 					break*/
        goto L7; // [685] 1011

        /** 				case else*/
        default:

        /** 					if BIND then*/
        if (_35BIND_15614 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** 						add_ref(tok)*/
        Ref(_tok_46907);
        _53add_ref(_tok_46907);
L15: 

        /** 					return tok -- keyword, private*/
        DeRefDS(_word_46890);
        DeRef(_msg_46898);
        DeRef(_b_name_46899);
        DeRef(_gtok_46908);
        DeRef(_24624);
        _24624 = NOVALUE;
        DeRef(_24614);
        _24614 = NOVALUE;
        _24638 = NOVALUE;
        _24643 = NOVALUE;
        _24642 = NOVALUE;
        _24658 = NOVALUE;
        _24651 = NOVALUE;
        DeRef(_24665);
        _24665 = NOVALUE;
        DeRef(_24663);
        _24663 = NOVALUE;
        DeRef(_24673);
        _24673 = NOVALUE;
        _24669 = NOVALUE;
        DeRef(_24671);
        _24671 = NOVALUE;
        _24677 = NOVALUE;
        DeRef(_24679);
        _24679 = NOVALUE;
        _24683 = NOVALUE;
        return _tok_46907;
    ;}    goto L7; // [711] 1011
L6: 

    /** 				scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_46907);
    _24690 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_24690)){
        _24691 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24690)->dbl));
    }
    else{
        _24691 = (int)*(((s1_ptr)_2)->base + _24690);
    }
    _2 = (int)SEQ_PTR(_24691);
    _scope_46900 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46900)){
        _scope_46900 = (long)DBL_PTR(_scope_46900)->dbl;
    }
    _24691 = NOVALUE;

    /** 				if not file_no then*/
    if (_file_no_46891 != 0)
    goto L16; // [738] 772

    /** 					if scope = SC_PREDEF then*/
    if (_scope_46900 != 7)
    goto L17; // [745] 1010

    /** 						if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** 							add_ref( tok )*/
    Ref(_tok_46907);
    _53add_ref(_tok_46907);
L18: 

    /** 						return tok*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_gtok_46908);
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    _24638 = NOVALUE;
    _24643 = NOVALUE;
    _24642 = NOVALUE;
    _24658 = NOVALUE;
    _24651 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    _24669 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    _24690 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24683 = NOVALUE;
    return _tok_46907;
    goto L17; // [769] 1010
L16: 

    /** 					integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_tok_46907);
    _24695 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_24695)){
        _24696 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24695)->dbl));
    }
    else{
        _24696 = (int)*(((s1_ptr)_2)->base + _24695);
    }
    _2 = (int)SEQ_PTR(_24696);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _tok_file_47079 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _tok_file_47079 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_tok_file_47079)){
        _tok_file_47079 = (long)DBL_PTR(_tok_file_47079)->dbl;
    }
    _24696 = NOVALUE;

    /** 					integer good = 0*/
    _good_47086 = 0;

    /** 					if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24698 = (_scope_46900 == 3);
    if (_24698 != 0) {
        goto L19; // [807] 940
    }
    _24700 = (_scope_46900 == 7);
    if (_24700 == 0)
    {
        DeRef(_24700);
        _24700 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24700);
        _24700 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** 					elsif file_no = tok_file then*/
    if (_file_no_46891 != _tok_file_47079)
    goto L1B; // [827] 839

    /** 						good = 1*/
    _good_47086 = 1;
    goto L19; // [836] 940
L1B: 

    /** 						integer include_type = 0*/
    _include_type_47096 = 0;

    /** 						switch scope do*/
    _0 = _scope_46900;
    switch ( _0 ){ 

        /** 							case SC_GLOBAL then*/
        case 6:

        /** 								if Resolve_unincluded_globals then*/
        if (_53Resolve_unincluded_globals_46881 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** 									include_type = ANY_INCLUDE*/
        _include_type_47096 = 7;
        goto L1D; // [871] 919
L1C: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47096 = 6;
        goto L1D; // [884] 919

        /** 							case SC_PUBLIC then*/
        case 13:

        /** 								if tok_file != file_no then*/
        if (_tok_file_47079 == _file_no_46891)
        goto L1E; // [892] 908

        /** 									include_type = PUBLIC_INCLUDE*/
        _include_type_47096 = 4;
        goto L1F; // [905] 918
L1E: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47096 = 6;
L1F: 
    ;}L1D: 

    /** 						good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _24705 = (int)*(((s1_ptr)_2)->base + _file_no_46891);
    _2 = (int)SEQ_PTR(_24705);
    _24706 = (int)*(((s1_ptr)_2)->base + _tok_file_47079);
    _24705 = NOVALUE;
    if (IS_ATOM_INT(_24706)) {
        {unsigned long tu;
             tu = (unsigned long)_include_type_47096 & (unsigned long)_24706;
             _good_47086 = MAKE_UINT(tu);
        }
    }
    else {
        _good_47086 = binary_op(AND_BITS, _include_type_47096, _24706);
    }
    _24706 = NOVALUE;
    if (!IS_ATOM_INT(_good_47086)) {
        _1 = (long)(DBL_PTR(_good_47086)->dbl);
        DeRefDS(_good_47086);
        _good_47086 = _1;
    }
L19: 

    /** 					if good then*/
    if (_good_47086 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** 						if file_no = tok_file then*/
    if (_file_no_46891 != _tok_file_47079)
    goto L21; // [947] 971

    /** 							if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** 								add_ref(tok)*/
    Ref(_tok_46907);
    _53add_ref(_tok_46907);
L22: 

    /** 							return tok*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_gtok_46908);
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    _24638 = NOVALUE;
    _24643 = NOVALUE;
    _24642 = NOVALUE;
    _24658 = NOVALUE;
    _24651 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    _24669 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    _24690 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24683 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    return _tok_46907;
L21: 

    /** 						gtok = tok*/
    Ref(_tok_46907);
    DeRef(_gtok_46908);
    _gtok_46908 = _tok_46907;

    /** 						dup_globals &= st_ptr*/
    Append(&_53dup_globals_46876, _53dup_globals_46876, _st_ptr_46904);

    /** 						in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _24710 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
    _2 = (int)SEQ_PTR(_24710);
    _24711 = (int)*(((s1_ptr)_2)->base + _tok_file_47079);
    _24710 = NOVALUE;
    if (IS_ATOM_INT(_24711)) {
        _24712 = (_24711 != 0);
    }
    else {
        _24712 = binary_op(NOTEQ, _24711, 0);
    }
    _24711 = NOVALUE;
    if (IS_SEQUENCE(_53in_include_path_46878) && IS_ATOM(_24712)) {
        Ref(_24712);
        Append(&_53in_include_path_46878, _53in_include_path_46878, _24712);
    }
    else if (IS_ATOM(_53in_include_path_46878) && IS_SEQUENCE(_24712)) {
    }
    else {
        Concat((object_ptr)&_53in_include_path_46878, _53in_include_path_46878, _24712);
    }
    DeRef(_24712);
    _24712 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24714 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24714);
    _st_ptr_46904 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46904)){
        _st_ptr_46904 = (long)DBL_PTR(_st_ptr_46904)->dbl;
    }
    _24714 = NOVALUE;

    /** 	end while*/
    goto L1; // [1030] 69
L2: 

    /** 	if length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_46877)){
            _24716 = SEQ_PTR(_53dup_overrides_46877)->length;
    }
    else {
        _24716 = 1;
    }
    if (_24716 == 0)
    {
        _24716 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24716 = NOVALUE;
    }

    /** 		st_ptr = dup_overrides[1]*/
    _2 = (int)SEQ_PTR(_53dup_overrides_46877);
    _st_ptr_46904 = (int)*(((s1_ptr)_2)->base + 1);

    /** 		tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24718 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24718);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24719 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24719 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24718 = NOVALUE;
    Ref(_24719);
    DeRef(_tok_46907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24719;
    ((int *)_2)[2] = _st_ptr_46904;
    _tok_46907 = MAKE_SEQ(_1);
    _24719 = NOVALUE;

    /** 			if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** 				add_ref(tok)*/
    RefDS(_tok_46907);
    _53add_ref(_tok_46907);
L24: 

    /** 			return tok*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_gtok_46908);
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    _24638 = NOVALUE;
    _24643 = NOVALUE;
    _24642 = NOVALUE;
    _24658 = NOVALUE;
    _24651 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    _24669 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    _24690 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24683 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    return _tok_46907;
    goto L25; // [1090] 1320
L23: 

    /** 	elsif st_builtin != 0 then*/
    if (_st_builtin_46905 == 0)
    goto L26; // [1095] 1319

    /** 		if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24722 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24722 = 1;
    }
    if (_24722 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24724 = (int)*(((s1_ptr)_2)->base + _st_builtin_46905);
    _2 = (int)SEQ_PTR(_24724);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24725 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24724 = NOVALUE;
    _24726 = find_from(_24725, _53builtin_warnings_46880, 1);
    _24725 = NOVALUE;
    _24727 = (_24726 == 0);
    _24726 = NOVALUE;
    if (_24727 == 0)
    {
        DeRef(_24727);
        _24727 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24727);
        _24727 = NOVALUE;
    }

    /** 			sequence msg_file */

    /** 			b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24728 = (int)*(((s1_ptr)_2)->base + _st_builtin_46905);
    DeRef(_b_name_46899);
    _2 = (int)SEQ_PTR(_24728);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _b_name_46899 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _b_name_46899 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_b_name_46899);
    _24728 = NOVALUE;

    /** 			builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_46899);
    Append(&_53builtin_warnings_46880, _53builtin_warnings_46880, _b_name_46899);

    /** 			if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24731 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24731 = 1;
    }
    if (_24731 <= 1)
    goto L28; // [1170] 1184

    /** 				msg = "\n"*/
    RefDS(_21967);
    DeRef(_msg_46898);
    _msg_46898 = _21967;
    goto L29; // [1181] 1192
L28: 

    /** 				msg = ""*/
    RefDS(_21815);
    DeRef(_msg_46898);
    _msg_46898 = _21815;
L29: 

    /** 			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24733 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24733 = 1;
    }
    {
        int _i_47163;
        _i_47163 = 1;
L2A: 
        if (_i_47163 > _24733){
            goto L2B; // [1199] 1255
        }

        /** 				msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_53dup_globals_46876);
        _24734 = (int)*(((s1_ptr)_2)->base + _i_47163);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_24734)){
            _24735 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24734)->dbl));
        }
        else{
            _24735 = (int)*(((s1_ptr)_2)->base + _24734);
        }
        _2 = (int)SEQ_PTR(_24735);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _24736 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _24736 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _24735 = NOVALUE;
        DeRef(_msg_file_47152);
        _2 = (int)SEQ_PTR(_36known_files_14982);
        if (!IS_ATOM_INT(_24736)){
            _msg_file_47152 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24736)->dbl));
        }
        else{
            _msg_file_47152 = (int)*(((s1_ptr)_2)->base + _24736);
        }
        Ref(_msg_file_47152);

        /** 				msg &= "    " & msg_file & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _21967;
            concat_list[1] = _msg_file_47152;
            concat_list[2] = _24738;
            Concat_N((object_ptr)&_24739, concat_list, 3);
        }
        Concat((object_ptr)&_msg_46898, _msg_46898, _24739);
        DeRefDS(_24739);
        _24739 = NOVALUE;

        /** 			end for*/
        _i_47163 = _i_47163 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** 			Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _24741 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_b_name_46899);
    *((int *)(_2+4)) = _b_name_46899;
    Ref(_24741);
    *((int *)(_2+8)) = _24741;
    RefDS(_msg_46898);
    *((int *)(_2+12)) = _msg_46898;
    _24742 = MAKE_SEQ(_1);
    _24741 = NOVALUE;
    _44Warning(234, 8, _24742);
    _24742 = NOVALUE;
L27: 
    DeRef(_msg_file_47152);
    _msg_file_47152 = NOVALUE;

    /** 		tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24743 = (int)*(((s1_ptr)_2)->base + _st_builtin_46905);
    _2 = (int)SEQ_PTR(_24743);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24744 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24743 = NOVALUE;
    Ref(_24744);
    DeRef(_tok_46907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24744;
    ((int *)_2)[2] = _st_builtin_46905;
    _tok_46907 = MAKE_SEQ(_1);
    _24744 = NOVALUE;

    /** 		if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** 			add_ref(tok)*/
    RefDS(_tok_46907);
    _53add_ref(_tok_46907);
L2C: 

    /** 		return tok*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_gtok_46908);
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    _24638 = NOVALUE;
    _24643 = NOVALUE;
    _24642 = NOVALUE;
    _24658 = NOVALUE;
    _24651 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    _24669 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    _24690 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24683 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    _24734 = NOVALUE;
    _24736 = NOVALUE;
    return _tok_46907;
L26: 
L25: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24746 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24746 = 1;
    }
    _24747 = (_24746 > 1);
    _24746 = NOVALUE;
    if (_24747 == 0) {
        goto L2D; // [1333] 1452
    }
    _24749 = find_from(1, _53in_include_path_46878, 1);
    if (_24749 == 0)
    {
        _24749 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24749 = NOVALUE;
    }

    /** 		ix = 1*/
    _ix_46902 = 1;

    /** 		while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24750 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24750 = 1;
    }
    if (_ix_46902 > _24750)
    goto L2F; // [1363] 1411

    /** 			if in_include_path[ix] then*/
    _2 = (int)SEQ_PTR(_53in_include_path_46878);
    _24752 = (int)*(((s1_ptr)_2)->base + _ix_46902);
    if (_24752 == 0) {
        _24752 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24752) && DBL_PTR(_24752)->dbl == 0.0){
            _24752 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24752 = NOVALUE;
    }
    _24752 = NOVALUE;

    /** 				ix += 1*/
    _ix_46902 = _ix_46902 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** 				dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53dup_globals_46876);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_46902)) ? _ix_46902 : (long)(DBL_PTR(_ix_46902)->dbl);
        int stop = (IS_ATOM_INT(_ix_46902)) ? _ix_46902 : (long)(DBL_PTR(_ix_46902)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53dup_globals_46876), start, &_53dup_globals_46876 );
            }
            else Tail(SEQ_PTR(_53dup_globals_46876), stop+1, &_53dup_globals_46876);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53dup_globals_46876), start, &_53dup_globals_46876);
        }
        else {
            assign_slice_seq = &assign_space;
            _53dup_globals_46876 = Remove_elements(start, stop, (SEQ_PTR(_53dup_globals_46876)->ref == 1));
        }
    }

    /** 				in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_53in_include_path_46878);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_46902)) ? _ix_46902 : (long)(DBL_PTR(_ix_46902)->dbl);
        int stop = (IS_ATOM_INT(_ix_46902)) ? _ix_46902 : (long)(DBL_PTR(_ix_46902)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_53in_include_path_46878), start, &_53in_include_path_46878 );
            }
            else Tail(SEQ_PTR(_53in_include_path_46878), stop+1, &_53in_include_path_46878);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_53in_include_path_46878), start, &_53in_include_path_46878);
        }
        else {
            assign_slice_seq = &assign_space;
            _53in_include_path_46878 = Remove_elements(start, stop, (SEQ_PTR(_53in_include_path_46878)->ref == 1));
        }
    }

    /** 		end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** 		if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24756 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24756 = 1;
    }
    if (_24756 != 1)
    goto L31; // [1418] 1451

    /** 				st_ptr = dup_globals[1]*/
    _2 = (int)SEQ_PTR(_53dup_globals_46876);
    _st_ptr_46904 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_46904)){
        _st_ptr_46904 = (long)DBL_PTR(_st_ptr_46904)->dbl;
    }

    /** 				gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24759 = (int)*(((s1_ptr)_2)->base + _st_ptr_46904);
    _2 = (int)SEQ_PTR(_24759);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24760 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24760 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24759 = NOVALUE;
    Ref(_24760);
    DeRef(_gtok_46908);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24760;
    ((int *)_2)[2] = _st_ptr_46904;
    _gtok_46908 = MAKE_SEQ(_1);
    _24760 = NOVALUE;
L31: 
L2D: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24762 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24762 = 1;
    }
    _24763 = (_24762 == 1);
    _24762 = NOVALUE;
    if (_24763 == 0) {
        goto L32; // [1465] 1642
    }
    _24765 = (_st_builtin_46905 == 0);
    if (_24765 == 0)
    {
        DeRef(_24765);
        _24765 = NOVALUE;
        goto L32; // [1474] 1642
    }
    else{
        DeRef(_24765);
        _24765 = NOVALUE;
    }

    /** 		if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** 			add_ref(gtok)*/
    Ref(_gtok_46908);
    _53add_ref(_gtok_46908);
L33: 

    /** 		if not in_include_path[1] and*/
    _2 = (int)SEQ_PTR(_53in_include_path_46878);
    _24766 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24766)) {
        _24767 = (_24766 == 0);
    }
    else {
        _24767 = unary_op(NOT, _24766);
    }
    _24766 = NOVALUE;
    if (IS_ATOM_INT(_24767)) {
        if (_24767 == 0) {
            goto L34; // [1503] 1635
        }
    }
    else {
        if (DBL_PTR(_24767)->dbl == 0.0) {
            goto L34; // [1503] 1635
        }
    }
    _2 = (int)SEQ_PTR(_gtok_46908);
    _24769 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_24769)){
        _24770 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24769)->dbl));
    }
    else{
        _24770 = (int)*(((s1_ptr)_2)->base + _24769);
    }
    _2 = (int)SEQ_PTR(_24770);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24771 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24770 = NOVALUE;
    Ref(_24771);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_46892;
    ((int *)_2)[2] = _24771;
    _24772 = MAKE_SEQ(_1);
    _24771 = NOVALUE;
    _24773 = find_from(_24772, _53include_warnings_46879, 1);
    DeRefDS(_24772);
    _24772 = NOVALUE;
    _24774 = (_24773 == 0);
    _24773 = NOVALUE;
    if (_24774 == 0)
    {
        DeRef(_24774);
        _24774 = NOVALUE;
        goto L34; // [1542] 1635
    }
    else{
        DeRef(_24774);
        _24774 = NOVALUE;
    }

    /** 			include_warnings = prepend( include_warnings,*/
    _2 = (int)SEQ_PTR(_gtok_46908);
    _24775 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_24775)){
        _24776 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24775)->dbl));
    }
    else{
        _24776 = (int)*(((s1_ptr)_2)->base + _24775);
    }
    _2 = (int)SEQ_PTR(_24776);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24777 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24777 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24776 = NOVALUE;
    Ref(_24777);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_46892;
    ((int *)_2)[2] = _24777;
    _24778 = MAKE_SEQ(_1);
    _24777 = NOVALUE;
    RefDS(_24778);
    Prepend(&_53include_warnings_46879, _53include_warnings_46879, _24778);
    DeRefDS(_24778);
    _24778 = NOVALUE;

    /** ifdef STDDEBUG then*/

    /** 				symbol_resolution_warning = GetMsgText(233,0,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _24780 = (int)*(((s1_ptr)_2)->base + _scanning_file_46892);
    Ref(_24780);
    _24781 = _53name_ext(_24780);
    _24780 = NOVALUE;
    _2 = (int)SEQ_PTR(_gtok_46908);
    _24782 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_24782)){
        _24783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24782)->dbl));
    }
    else{
        _24783 = (int)*(((s1_ptr)_2)->base + _24782);
    }
    _2 = (int)SEQ_PTR(_24783);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24784 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24784 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24783 = NOVALUE;
    _2 = (int)SEQ_PTR(_36known_files_14982);
    if (!IS_ATOM_INT(_24784)){
        _24785 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24784)->dbl));
    }
    else{
        _24785 = (int)*(((s1_ptr)_2)->base + _24784);
    }
    Ref(_24785);
    _24786 = _53name_ext(_24785);
    _24785 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _24781;
    *((int *)(_2+8)) = _35line_number_15969;
    RefDS(_word_46890);
    *((int *)(_2+12)) = _word_46890;
    *((int *)(_2+16)) = _24786;
    _24787 = MAKE_SEQ(_1);
    _24786 = NOVALUE;
    _24781 = NOVALUE;
    _0 = _45GetMsgText(233, 0, _24787);
    DeRef(_35symbol_resolution_warning_16069);
    _35symbol_resolution_warning_16069 = _0;
    _24787 = NOVALUE;
L34: 

    /** 		return gtok*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_tok_46907);
    _24669 = NOVALUE;
    _24651 = NOVALUE;
    _24683 = NOVALUE;
    DeRef(_24763);
    _24763 = NOVALUE;
    _24769 = NOVALUE;
    _24784 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24747);
    _24747 = NOVALUE;
    _24643 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24642 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    _24638 = NOVALUE;
    DeRef(_24767);
    _24767 = NOVALUE;
    _24658 = NOVALUE;
    _24734 = NOVALUE;
    _24782 = NOVALUE;
    _24736 = NOVALUE;
    _24775 = NOVALUE;
    return _gtok_46908;
L32: 

    /** 	if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24789 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24789 = 1;
    }
    if (_24789 != 0)
    goto L35; // [1649] 1723

    /** 		defined = SC_UNDEFINED*/
    _defined_46901 = 9;

    /** 		if fwd_line_number then*/
    if (_35fwd_line_number_15970 == 0)
    {
        goto L36; // [1666] 1695
    }
    else{
    }

    /** 			last_ForwardLine     = ForwardLine*/
    Ref(_44ForwardLine_48143);
    DeRef(_44last_ForwardLine_48145);
    _44last_ForwardLine_48145 = _44ForwardLine_48143;

    /** 			last_forward_bp      = forward_bp*/
    _44last_forward_bp_48149 = _44forward_bp_48147;

    /** 			last_fwd_line_number = fwd_line_number*/
    _35last_fwd_line_number_15972 = _35fwd_line_number_15970;
L36: 

    /** 		ForwardLine = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44ForwardLine_48143);
    _44ForwardLine_48143 = _44ThisLine_48142;

    /** 		forward_bp = bp*/
    _44forward_bp_48147 = _44bp_48146;

    /** 		fwd_line_number = line_number*/
    _35fwd_line_number_15970 = _35line_number_15969;
    goto L37; // [1720] 1766
L35: 

    /** 	elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _24791 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _24791 = 1;
    }
    if (_24791 == 0)
    {
        _24791 = NOVALUE;
        goto L38; // [1730] 1745
    }
    else{
        _24791 = NOVALUE;
    }

    /** 		defined = SC_MULTIPLY_DEFINED*/
    _defined_46901 = 10;
    goto L37; // [1742] 1766
L38: 

    /** 	elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_53dup_overrides_46877)){
            _24792 = SEQ_PTR(_53dup_overrides_46877)->length;
    }
    else {
        _24792 = 1;
    }
    if (_24792 == 0)
    {
        _24792 = NOVALUE;
        goto L39; // [1752] 1765
    }
    else{
        _24792 = NOVALUE;
    }

    /** 		defined = SC_OVERRIDE*/
    _defined_46901 = 12;
L39: 
L37: 

    /** 	if No_new_entry then*/
    if (_53No_new_entry_46887 == 0)
    {
        goto L3A; // [1770] 1793
    }
    else{
    }

    /** 		return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 509;
    RefDS(_word_46890);
    *((int *)(_2+8)) = _word_46890;
    *((int *)(_2+12)) = _defined_46901;
    RefDS(_53dup_globals_46876);
    *((int *)(_2+16)) = _53dup_globals_46876;
    _24793 = MAKE_SEQ(_1);
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_tok_46907);
    DeRef(_gtok_46908);
    _24669 = NOVALUE;
    _24651 = NOVALUE;
    _24683 = NOVALUE;
    DeRef(_24763);
    _24763 = NOVALUE;
    _24769 = NOVALUE;
    _24784 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24747);
    _24747 = NOVALUE;
    _24643 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24642 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    _24638 = NOVALUE;
    DeRef(_24767);
    _24767 = NOVALUE;
    _24658 = NOVALUE;
    _24734 = NOVALUE;
    _24782 = NOVALUE;
    _24736 = NOVALUE;
    _24775 = NOVALUE;
    return _24793;
L3A: 

    /** 	tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _24794 = (int)*(((s1_ptr)_2)->base + _hashval_46896);
    RefDS(_word_46890);
    Ref(_24794);
    _24795 = _53NewEntry(_word_46890, 0, _defined_46901, -100, _hashval_46896, _24794, 0);
    _24794 = NOVALUE;
    DeRef(_tok_46907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _24795;
    _tok_46907 = MAKE_SEQ(_1);
    _24795 = NOVALUE;

    /** 	buckets[hashval] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_46907);
    _24797 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_24797);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _2 = (int)(((s1_ptr)_2)->base + _hashval_46896);
    _1 = *(int *)_2;
    *(int *)_2 = _24797;
    if( _1 != _24797 ){
        DeRef(_1);
    }
    _24797 = NOVALUE;

    /** 	if file_no != -1 then*/
    if (_file_no_46891 == -1)
    goto L3B; // [1837] 1863

    /** 		SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (int)SEQ_PTR(_tok_46907);
    _24799 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24799))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24799)->dbl));
    else
    _3 = (int)(_24799 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15637))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    _1 = *(int *)_2;
    *(int *)_2 = _file_no_46891;
    DeRef(_1);
    _24800 = NOVALUE;
L3B: 

    /** 	return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_46890);
    DeRef(_msg_46898);
    DeRef(_b_name_46899);
    DeRef(_gtok_46908);
    _24669 = NOVALUE;
    _24651 = NOVALUE;
    _24683 = NOVALUE;
    DeRef(_24763);
    _24763 = NOVALUE;
    _24769 = NOVALUE;
    _24784 = NOVALUE;
    DeRef(_24614);
    _24614 = NOVALUE;
    DeRef(_24624);
    _24624 = NOVALUE;
    DeRef(_24747);
    _24747 = NOVALUE;
    _24643 = NOVALUE;
    _24695 = NOVALUE;
    DeRef(_24663);
    _24663 = NOVALUE;
    _24799 = NOVALUE;
    _24677 = NOVALUE;
    DeRef(_24671);
    _24671 = NOVALUE;
    DeRef(_24679);
    _24679 = NOVALUE;
    _24642 = NOVALUE;
    DeRef(_24665);
    _24665 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24793);
    _24793 = NOVALUE;
    DeRef(_24673);
    _24673 = NOVALUE;
    DeRef(_24698);
    _24698 = NOVALUE;
    _24638 = NOVALUE;
    DeRef(_24767);
    _24767 = NOVALUE;
    _24658 = NOVALUE;
    _24734 = NOVALUE;
    _24782 = NOVALUE;
    _24736 = NOVALUE;
    _24775 = NOVALUE;
    return _tok_46907;
    ;
}


void _53Hide(int _s_47300)
{
    int _prev_47302 = NOVALUE;
    int _p_47303 = NOVALUE;
    int _24820 = NOVALUE;
    int _24819 = NOVALUE;
    int _24818 = NOVALUE;
    int _24816 = NOVALUE;
    int _24815 = NOVALUE;
    int _24814 = NOVALUE;
    int _24813 = NOVALUE;
    int _24812 = NOVALUE;
    int _24808 = NOVALUE;
    int _24807 = NOVALUE;
    int _24806 = NOVALUE;
    int _24805 = NOVALUE;
    int _24803 = NOVALUE;
    int _24802 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47300)) {
        _1 = (long)(DBL_PTR(_s_47300)->dbl);
        DeRefDS(_s_47300);
        _s_47300 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24802 = (int)*(((s1_ptr)_2)->base + _s_47300);
    _2 = (int)SEQ_PTR(_24802);
    _24803 = (int)*(((s1_ptr)_2)->base + 11);
    _24802 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_24803)){
        _p_47303 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24803)->dbl));
    }
    else{
        _p_47303 = (int)*(((s1_ptr)_2)->base + _24803);
    }
    if (!IS_ATOM_INT(_p_47303)){
        _p_47303 = (long)DBL_PTR(_p_47303)->dbl;
    }

    /** 	prev = 0*/
    _prev_47302 = 0;

    /** 	while p != s and p != 0 do*/
L1: 
    _24805 = (_p_47303 != _s_47300);
    if (_24805 == 0) {
        goto L2; // [41] 81
    }
    _24807 = (_p_47303 != 0);
    if (_24807 == 0)
    {
        DeRef(_24807);
        _24807 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_24807);
        _24807 = NOVALUE;
    }

    /** 		prev = p*/
    _prev_47302 = _p_47303;

    /** 		p = SymTab[p][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24808 = (int)*(((s1_ptr)_2)->base + _p_47303);
    _2 = (int)SEQ_PTR(_24808);
    _p_47303 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_47303)){
        _p_47303 = (long)DBL_PTR(_p_47303)->dbl;
    }
    _24808 = NOVALUE;

    /** 	end while*/
    goto L1; // [78] 37
L2: 

    /** 	if p = 0 then*/
    if (_p_47303 != 0)
    goto L3; // [83] 93

    /** 		return -- already hidden*/
    _24803 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    return;
L3: 

    /** 	if prev = 0 then*/
    if (_prev_47302 != 0)
    goto L4; // [95] 134

    /** 		buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24812 = (int)*(((s1_ptr)_2)->base + _s_47300);
    _2 = (int)SEQ_PTR(_24812);
    _24813 = (int)*(((s1_ptr)_2)->base + 11);
    _24812 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24814 = (int)*(((s1_ptr)_2)->base + _s_47300);
    _2 = (int)SEQ_PTR(_24814);
    _24815 = (int)*(((s1_ptr)_2)->base + 9);
    _24814 = NOVALUE;
    Ref(_24815);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_24813))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24813)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _24813);
    _1 = *(int *)_2;
    *(int *)_2 = _24815;
    if( _1 != _24815 ){
        DeRef(_1);
    }
    _24815 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** 		SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_47302 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24818 = (int)*(((s1_ptr)_2)->base + _s_47300);
    _2 = (int)SEQ_PTR(_24818);
    _24819 = (int)*(((s1_ptr)_2)->base + 9);
    _24818 = NOVALUE;
    Ref(_24819);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24819;
    if( _1 != _24819 ){
        DeRef(_1);
    }
    _24819 = NOVALUE;
    _24816 = NOVALUE;
L5: 

    /** 	SymTab[s][S_SAMEHASH] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47300 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24820 = NOVALUE;

    /** end procedure*/
    _24803 = NOVALUE;
    DeRef(_24805);
    _24805 = NOVALUE;
    _24813 = NOVALUE;
    return;
    ;
}


void _53Show(int _s_47345)
{
    int _p_47347 = NOVALUE;
    int _24832 = NOVALUE;
    int _24831 = NOVALUE;
    int _24829 = NOVALUE;
    int _24828 = NOVALUE;
    int _24826 = NOVALUE;
    int _24825 = NOVALUE;
    int _24823 = NOVALUE;
    int _24822 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47345)) {
        _1 = (long)(DBL_PTR(_s_47345)->dbl);
        DeRefDS(_s_47345);
        _s_47345 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24822 = (int)*(((s1_ptr)_2)->base + _s_47345);
    _2 = (int)SEQ_PTR(_24822);
    _24823 = (int)*(((s1_ptr)_2)->base + 11);
    _24822 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_24823)){
        _p_47347 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24823)->dbl));
    }
    else{
        _p_47347 = (int)*(((s1_ptr)_2)->base + _24823);
    }
    if (!IS_ATOM_INT(_p_47347)){
        _p_47347 = (long)DBL_PTR(_p_47347)->dbl;
    }

    /** 	if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24825 = (int)*(((s1_ptr)_2)->base + _s_47345);
    _2 = (int)SEQ_PTR(_24825);
    _24826 = (int)*(((s1_ptr)_2)->base + 9);
    _24825 = NOVALUE;
    if (IS_ATOM_INT(_24826)) {
        if (_24826 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_24826)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _24828 = (_p_47347 == _s_47345);
    if (_24828 == 0)
    {
        DeRef(_24828);
        _24828 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_24828);
        _24828 = NOVALUE;
    }
L1: 

    /** 		return*/
    _24823 = NOVALUE;
    _24826 = NOVALUE;
    return;
L2: 

    /** 	SymTab[s][S_SAMEHASH] = p*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47345 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _p_47347;
    DeRef(_1);
    _24829 = NOVALUE;

    /** 	buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24831 = (int)*(((s1_ptr)_2)->base + _s_47345);
    _2 = (int)SEQ_PTR(_24831);
    _24832 = (int)*(((s1_ptr)_2)->base + 11);
    _24831 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_24832))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24832)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _24832);
    _1 = *(int *)_2;
    *(int *)_2 = _s_47345;
    DeRef(_1);

    /** end procedure*/
    _24823 = NOVALUE;
    _24826 = NOVALUE;
    _24832 = NOVALUE;
    return;
    ;
}


void _53hide_params(int _s_47371)
{
    int _param_47373 = NOVALUE;
    int _24835 = NOVALUE;
    int _24834 = NOVALUE;
    int _24833 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47371)) {
        _1 = (long)(DBL_PTR(_s_47371)->dbl);
        DeRefDS(_s_47371);
        _s_47371 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47373 = _s_47371;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24833 = (int)*(((s1_ptr)_2)->base + _s_47371);
    _2 = (int)SEQ_PTR(_24833);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _24834 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _24834 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _24833 = NOVALUE;
    {
        int _i_47375;
        _i_47375 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47375, _24834)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24835 = (int)*(((s1_ptr)_2)->base + _s_47371);
        _2 = (int)SEQ_PTR(_24835);
        _param_47373 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47373)){
            _param_47373 = (long)DBL_PTR(_param_47373)->dbl;
        }
        _24835 = NOVALUE;

        /** 		Hide( param )*/
        _53Hide(_param_47373);

        /** 	end for*/
        _0 = _i_47375;
        if (IS_ATOM_INT(_i_47375)) {
            _i_47375 = _i_47375 + 1;
            if ((long)((unsigned long)_i_47375 +(unsigned long) HIGH_BITS) >= 0){
                _i_47375 = NewDouble((double)_i_47375);
            }
        }
        else {
            _i_47375 = binary_op_a(PLUS, _i_47375, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47375);
    }

    /** end procedure*/
    _24834 = NOVALUE;
    return;
    ;
}


void _53show_params(int _s_47387)
{
    int _param_47389 = NOVALUE;
    int _24839 = NOVALUE;
    int _24838 = NOVALUE;
    int _24837 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47387)) {
        _1 = (long)(DBL_PTR(_s_47387)->dbl);
        DeRefDS(_s_47387);
        _s_47387 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47389 = _s_47387;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24837 = (int)*(((s1_ptr)_2)->base + _s_47387);
    _2 = (int)SEQ_PTR(_24837);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _24838 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _24838 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _24837 = NOVALUE;
    {
        int _i_47391;
        _i_47391 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47391, _24838)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24839 = (int)*(((s1_ptr)_2)->base + _s_47387);
        _2 = (int)SEQ_PTR(_24839);
        _param_47389 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47389)){
            _param_47389 = (long)DBL_PTR(_param_47389)->dbl;
        }
        _24839 = NOVALUE;

        /** 		Show( param )*/
        _53Show(_param_47389);

        /** 	end for*/
        _0 = _i_47391;
        if (IS_ATOM_INT(_i_47391)) {
            _i_47391 = _i_47391 + 1;
            if ((long)((unsigned long)_i_47391 +(unsigned long) HIGH_BITS) >= 0){
                _i_47391 = NewDouble((double)_i_47391);
            }
        }
        else {
            _i_47391 = binary_op_a(PLUS, _i_47391, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47391);
    }

    /** end procedure*/
    _24838 = NOVALUE;
    return;
    ;
}


void _53LintCheck(int _s_47403)
{
    int _warn_level_47404 = NOVALUE;
    int _file_47405 = NOVALUE;
    int _vscope_47406 = NOVALUE;
    int _vname_47407 = NOVALUE;
    int _vusage_47408 = NOVALUE;
    int _24900 = NOVALUE;
    int _24899 = NOVALUE;
    int _24898 = NOVALUE;
    int _24897 = NOVALUE;
    int _24896 = NOVALUE;
    int _24895 = NOVALUE;
    int _24893 = NOVALUE;
    int _24892 = NOVALUE;
    int _24891 = NOVALUE;
    int _24890 = NOVALUE;
    int _24889 = NOVALUE;
    int _24888 = NOVALUE;
    int _24885 = NOVALUE;
    int _24884 = NOVALUE;
    int _24883 = NOVALUE;
    int _24882 = NOVALUE;
    int _24881 = NOVALUE;
    int _24880 = NOVALUE;
    int _24878 = NOVALUE;
    int _24876 = NOVALUE;
    int _24875 = NOVALUE;
    int _24873 = NOVALUE;
    int _24872 = NOVALUE;
    int _24870 = NOVALUE;
    int _24869 = NOVALUE;
    int _24868 = NOVALUE;
    int _24867 = NOVALUE;
    int _24865 = NOVALUE;
    int _24864 = NOVALUE;
    int _24860 = NOVALUE;
    int _24857 = NOVALUE;
    int _24856 = NOVALUE;
    int _24855 = NOVALUE;
    int _24854 = NOVALUE;
    int _24851 = NOVALUE;
    int _24850 = NOVALUE;
    int _24845 = NOVALUE;
    int _24843 = NOVALUE;
    int _24841 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47403)) {
        _1 = (long)(DBL_PTR(_s_47403)->dbl);
        DeRefDS(_s_47403);
        _s_47403 = _1;
    }

    /** 	vusage = SymTab[s][S_USAGE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24841 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24841);
    _vusage_47408 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_47408)){
        _vusage_47408 = (long)DBL_PTR(_vusage_47408)->dbl;
    }
    _24841 = NOVALUE;

    /** 	vscope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24843 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24843);
    _vscope_47406 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_47406)){
        _vscope_47406 = (long)DBL_PTR(_vscope_47406)->dbl;
    }
    _24843 = NOVALUE;

    /** 	vname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24845 = (int)*(((s1_ptr)_2)->base + _s_47403);
    DeRef(_vname_47407);
    _2 = (int)SEQ_PTR(_24845);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _vname_47407 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _vname_47407 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_vname_47407);
    _24845 = NOVALUE;

    /** 	switch vusage do*/
    _0 = _vusage_47408;
    switch ( _0 ){ 

        /** 		case U_UNUSED then*/
        case 0:

        /** 			warn_level = 1*/
        _warn_level_47404 = 1;
        goto L1; // [67] 193

        /** 		case U_WRITTEN then -- Set but never read*/
        case 2:

        /** 			warn_level = 2*/
        _warn_level_47404 = 2;

        /** 			if vscope > SC_LOCAL then*/
        if (_vscope_47406 <= 5)
        goto L2; // [82] 94

        /** 				warn_level = 0 */
        _warn_level_47404 = 0;
        goto L1; // [91] 193
L2: 

        /** 			elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24850 = (int)*(((s1_ptr)_2)->base + _s_47403);
        _2 = (int)SEQ_PTR(_24850);
        _24851 = (int)*(((s1_ptr)_2)->base + 3);
        _24850 = NOVALUE;
        if (binary_op_a(NOTEQ, _24851, 2)){
            _24851 = NOVALUE;
            goto L1; // [110] 193
        }
        _24851 = NOVALUE;

        /** 				if not Strict_is_on then*/
        if (_35Strict_is_on_16033 != 0)
        goto L1; // [118] 193

        /** 					warn_level = 0 */
        _warn_level_47404 = 0;
        goto L1; // [129] 193

        /** 		case U_READ then -- Read but never set*/
        case 1:

        /** 			if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24854 = (int)*(((s1_ptr)_2)->base + _s_47403);
        _2 = (int)SEQ_PTR(_24854);
        _24855 = (int)*(((s1_ptr)_2)->base + 16);
        _24854 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24856 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
        _2 = (int)SEQ_PTR(_24856);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
            _24857 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
        }
        else{
            _24857 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
        }
        _24856 = NOVALUE;
        if (binary_op_a(LESS, _24855, _24857)){
            _24855 = NOVALUE;
            _24857 = NOVALUE;
            goto L3; // [163] 175
        }
        _24855 = NOVALUE;
        _24857 = NOVALUE;

        /** 		    	warn_level = 3*/
        _warn_level_47404 = 3;
        goto L1; // [172] 193
L3: 

        /** 		    	warn_level = 0*/
        _warn_level_47404 = 0;
        goto L1; // [181] 193

        /** 	    case else*/
        default:

        /** 	    	warn_level = 0*/
        _warn_level_47404 = 0;
    ;}L1: 

    /** 	if warn_level = 0 then*/
    if (_warn_level_47404 != 0)
    goto L4; // [197] 207

    /** 		return*/
    DeRef(_file_47405);
    DeRef(_vname_47407);
    return;
L4: 

    /** 	file = abbreviate_path(known_files[current_file_no])*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _24860 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_24860);
    RefDS(_21815);
    _0 = _file_47405;
    _file_47405 = _17abbreviate_path(_24860, _21815);
    DeRef(_0);
    _24860 = NOVALUE;

    /** 	if warn_level = 3 then*/
    if (_warn_level_47404 != 3)
    goto L5; // [226] 308

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47406 != 5)
    goto L6; // [234] 275

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24864 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24864);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24865 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24865 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24864 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_15968, _24865)){
        _24865 = NOVALUE;
        goto L7; // [254] 602
    }
    _24865 = NOVALUE;

    /** 				Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_47407);
    RefDS(_file_47405);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47405;
    ((int *)_2)[2] = _vname_47407;
    _24867 = MAKE_SEQ(_1);
    _44Warning(226, 32, _24867);
    _24867 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** 			Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24868 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24868);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24869 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24869 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24868 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47405);
    *((int *)(_2+4)) = _file_47405;
    RefDS(_vname_47407);
    *((int *)(_2+8)) = _vname_47407;
    Ref(_24869);
    *((int *)(_2+12)) = _24869;
    _24870 = MAKE_SEQ(_1);
    _24869 = NOVALUE;
    _44Warning(227, 32, _24870);
    _24870 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47406 != 5)
    goto L8; // [312] 412

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24872 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24872);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24873 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24873 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24872 = NOVALUE;
    if (binary_op_a(NOTEQ, _35current_file_no_15968, _24873)){
        _24873 = NOVALUE;
        goto L9; // [332] 601
    }
    _24873 = NOVALUE;

    /** 				if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24875 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24875);
    _24876 = (int)*(((s1_ptr)_2)->base + 3);
    _24875 = NOVALUE;
    if (binary_op_a(NOTEQ, _24876, 2)){
        _24876 = NOVALUE;
        goto LA; // [352] 372
    }
    _24876 = NOVALUE;

    /** 					Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47407);
    RefDS(_file_47405);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47405;
    ((int *)_2)[2] = _vname_47407;
    _24878 = MAKE_SEQ(_1);
    _44Warning(228, 16, _24878);
    _24878 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** 				elsif warn_level = 1 then*/
    if (_warn_level_47404 != 1)
    goto LB; // [374] 394

    /** 					Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47407);
    RefDS(_file_47405);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47405;
    ((int *)_2)[2] = _vname_47407;
    _24880 = MAKE_SEQ(_1);
    _44Warning(229, 16, _24880);
    _24880 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** 					Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47407);
    RefDS(_file_47405);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47405;
    ((int *)_2)[2] = _vname_47407;
    _24881 = MAKE_SEQ(_1);
    _44Warning(320, 16, _24881);
    _24881 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** 			if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24882 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24882);
    _24883 = (int)*(((s1_ptr)_2)->base + 16);
    _24882 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24884 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24884);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _24885 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _24885 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _24884 = NOVALUE;
    if (binary_op_a(GREATEREQ, _24883, _24885)){
        _24883 = NOVALUE;
        _24885 = NOVALUE;
        goto LC; // [440] 523
    }
    _24883 = NOVALUE;
    _24885 = NOVALUE;

    /** 				if warn_level = 1 then*/
    if (_warn_level_47404 != 1)
    goto LD; // [446] 490

    /** 					if Strict_is_on then*/
    if (_35Strict_is_on_16033 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** 						Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24888 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24888);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24889 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24889 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24888 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47405);
    *((int *)(_2+4)) = _file_47405;
    RefDS(_vname_47407);
    *((int *)(_2+8)) = _vname_47407;
    Ref(_24889);
    *((int *)(_2+12)) = _24889;
    _24890 = MAKE_SEQ(_1);
    _24889 = NOVALUE;
    _44Warning(230, 16, _24890);
    _24890 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** 					Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24891 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24891);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24892 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24892 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24891 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47405);
    *((int *)(_2+4)) = _file_47405;
    RefDS(_vname_47407);
    *((int *)(_2+8)) = _vname_47407;
    Ref(_24892);
    *((int *)(_2+12)) = _24892;
    _24893 = MAKE_SEQ(_1);
    _24892 = NOVALUE;
    _44Warning(321, 16, _24893);
    _24893 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** 				if warn_level = 1 then*/
    if (_warn_level_47404 != 1)
    goto LF; // [525] 569

    /** 					if Strict_is_on then*/
    if (_35Strict_is_on_16033 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** 						Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24895 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24895);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24896 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24896 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24895 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47405);
    *((int *)(_2+4)) = _file_47405;
    RefDS(_vname_47407);
    *((int *)(_2+8)) = _vname_47407;
    Ref(_24896);
    *((int *)(_2+12)) = _24896;
    _24897 = MAKE_SEQ(_1);
    _24896 = NOVALUE;
    _44Warning(231, 16, _24897);
    _24897 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** 					Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24898 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_24898);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24899 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24899 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24898 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47405);
    *((int *)(_2+4)) = _file_47405;
    RefDS(_vname_47407);
    *((int *)(_2+8)) = _vname_47407;
    Ref(_24899);
    *((int *)(_2+12)) = _24899;
    _24900 = MAKE_SEQ(_1);
    _24899 = NOVALUE;
    _44Warning(322, 16, _24900);
    _24900 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** end procedure*/
    DeRef(_file_47405);
    DeRef(_vname_47407);
    return;
    ;
}


void _53HideLocals()
{
    int _s_47574 = NOVALUE;
    int _24911 = NOVALUE;
    int _24909 = NOVALUE;
    int _24908 = NOVALUE;
    int _24907 = NOVALUE;
    int _24906 = NOVALUE;
    int _24905 = NOVALUE;
    int _24904 = NOVALUE;
    int _24903 = NOVALUE;
    int _24902 = NOVALUE;
    int _24901 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = file_start_sym*/
    _s_47574 = _35file_start_sym_15974;

    /** 	while s do*/
L1: 
    if (_s_47574 == 0)
    {
        goto L2; // [15] 117
    }
    else{
    }

    /** 		if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24901 = (int)*(((s1_ptr)_2)->base + _s_47574);
    _2 = (int)SEQ_PTR(_24901);
    _24902 = (int)*(((s1_ptr)_2)->base + 4);
    _24901 = NOVALUE;
    if (IS_ATOM_INT(_24902)) {
        _24903 = (_24902 == 5);
    }
    else {
        _24903 = binary_op(EQUALS, _24902, 5);
    }
    _24902 = NOVALUE;
    if (IS_ATOM_INT(_24903)) {
        if (_24903 == 0) {
            goto L3; // [38] 96
        }
    }
    else {
        if (DBL_PTR(_24903)->dbl == 0.0) {
            goto L3; // [38] 96
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24905 = (int)*(((s1_ptr)_2)->base + _s_47574);
    _2 = (int)SEQ_PTR(_24905);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _24906 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _24906 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _24905 = NOVALUE;
    if (IS_ATOM_INT(_24906)) {
        _24907 = (_24906 == _35current_file_no_15968);
    }
    else {
        _24907 = binary_op(EQUALS, _24906, _35current_file_no_15968);
    }
    _24906 = NOVALUE;
    if (_24907 == 0) {
        DeRef(_24907);
        _24907 = NOVALUE;
        goto L3; // [61] 96
    }
    else {
        if (!IS_ATOM_INT(_24907) && DBL_PTR(_24907)->dbl == 0.0){
            DeRef(_24907);
            _24907 = NOVALUE;
            goto L3; // [61] 96
        }
        DeRef(_24907);
        _24907 = NOVALUE;
    }
    DeRef(_24907);
    _24907 = NOVALUE;

    /** 			Hide(s)*/
    _53Hide(_s_47574);

    /** 			if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24908 = (int)*(((s1_ptr)_2)->base + _s_47574);
    _2 = (int)SEQ_PTR(_24908);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24909 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24909 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24908 = NOVALUE;
    if (binary_op_a(NOTEQ, _24909, -100)){
        _24909 = NOVALUE;
        goto L4; // [85] 95
    }
    _24909 = NOVALUE;

    /** 				LintCheck(s)*/
    _53LintCheck(_s_47574);
L4: 
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24911 = (int)*(((s1_ptr)_2)->base + _s_47574);
    _2 = (int)SEQ_PTR(_24911);
    _s_47574 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47574)){
        _s_47574 = (long)DBL_PTR(_s_47574)->dbl;
    }
    _24911 = NOVALUE;

    /** 	end while*/
    goto L1; // [114] 15
L2: 

    /** end procedure*/
    DeRef(_24903);
    _24903 = NOVALUE;
    return;
    ;
}


int _53sym_name(int _sym_47605)
{
    int _24914 = NOVALUE;
    int _24913 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47605)) {
        _1 = (long)(DBL_PTR(_sym_47605)->dbl);
        DeRefDS(_sym_47605);
        _sym_47605 = _1;
    }

    /** 	return SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24913 = (int)*(((s1_ptr)_2)->base + _sym_47605);
    _2 = (int)SEQ_PTR(_24913);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _24914 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _24914 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _24913 = NOVALUE;
    Ref(_24914);
    return _24914;
    ;
}


int _53sym_token(int _sym_47613)
{
    int _24916 = NOVALUE;
    int _24915 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47613)) {
        _1 = (long)(DBL_PTR(_sym_47613)->dbl);
        DeRefDS(_sym_47613);
        _sym_47613 = _1;
    }

    /** 	return SymTab[sym][S_TOKEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24915 = (int)*(((s1_ptr)_2)->base + _sym_47613);
    _2 = (int)SEQ_PTR(_24915);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _24916 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _24916 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _24915 = NOVALUE;
    Ref(_24916);
    return _24916;
    ;
}


int _53sym_scope(int _sym_47621)
{
    int _24918 = NOVALUE;
    int _24917 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47621)) {
        _1 = (long)(DBL_PTR(_sym_47621)->dbl);
        DeRefDS(_sym_47621);
        _sym_47621 = _1;
    }

    /** 	return SymTab[sym][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24917 = (int)*(((s1_ptr)_2)->base + _sym_47621);
    _2 = (int)SEQ_PTR(_24917);
    _24918 = (int)*(((s1_ptr)_2)->base + 4);
    _24917 = NOVALUE;
    Ref(_24918);
    return _24918;
    ;
}


int _53sym_mode(int _sym_47629)
{
    int _24920 = NOVALUE;
    int _24919 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47629)) {
        _1 = (long)(DBL_PTR(_sym_47629)->dbl);
        DeRefDS(_sym_47629);
        _sym_47629 = _1;
    }

    /** 	return SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24919 = (int)*(((s1_ptr)_2)->base + _sym_47629);
    _2 = (int)SEQ_PTR(_24919);
    _24920 = (int)*(((s1_ptr)_2)->base + 3);
    _24919 = NOVALUE;
    Ref(_24920);
    return _24920;
    ;
}


int _53sym_obj(int _sym_47637)
{
    int _24922 = NOVALUE;
    int _24921 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47637)) {
        _1 = (long)(DBL_PTR(_sym_47637)->dbl);
        DeRefDS(_sym_47637);
        _sym_47637 = _1;
    }

    /** 	return SymTab[sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24921 = (int)*(((s1_ptr)_2)->base + _sym_47637);
    _2 = (int)SEQ_PTR(_24921);
    _24922 = (int)*(((s1_ptr)_2)->base + 1);
    _24921 = NOVALUE;
    Ref(_24922);
    return _24922;
    ;
}


int _53sym_next(int _sym_47645)
{
    int _24924 = NOVALUE;
    int _24923 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47645)) {
        _1 = (long)(DBL_PTR(_sym_47645)->dbl);
        DeRefDS(_sym_47645);
        _sym_47645 = _1;
    }

    /** 	return SymTab[sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24923 = (int)*(((s1_ptr)_2)->base + _sym_47645);
    _2 = (int)SEQ_PTR(_24923);
    _24924 = (int)*(((s1_ptr)_2)->base + 2);
    _24923 = NOVALUE;
    Ref(_24924);
    return _24924;
    ;
}


int _53sym_block(int _sym_47653)
{
    int _24926 = NOVALUE;
    int _24925 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47653)) {
        _1 = (long)(DBL_PTR(_sym_47653)->dbl);
        DeRefDS(_sym_47653);
        _sym_47653 = _1;
    }

    /** 	return SymTab[sym][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24925 = (int)*(((s1_ptr)_2)->base + _sym_47653);
    _2 = (int)SEQ_PTR(_24925);
    if (!IS_ATOM_INT(_35S_BLOCK_15661)){
        _24926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15661)->dbl));
    }
    else{
        _24926 = (int)*(((s1_ptr)_2)->base + _35S_BLOCK_15661);
    }
    _24925 = NOVALUE;
    Ref(_24926);
    return _24926;
    ;
}


int _53sym_next_in_block(int _sym_47661)
{
    int _24928 = NOVALUE;
    int _24927 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47661)) {
        _1 = (long)(DBL_PTR(_sym_47661)->dbl);
        DeRefDS(_sym_47661);
        _sym_47661 = _1;
    }

    /** 	return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24927 = (int)*(((s1_ptr)_2)->base + _sym_47661);
    _2 = (int)SEQ_PTR(_24927);
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15633)){
        _24928 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15633)->dbl));
    }
    else{
        _24928 = (int)*(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15633);
    }
    _24927 = NOVALUE;
    Ref(_24928);
    return _24928;
    ;
}


int _53sym_usage(int _sym_47669)
{
    int _24930 = NOVALUE;
    int _24929 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47669)) {
        _1 = (long)(DBL_PTR(_sym_47669)->dbl);
        DeRefDS(_sym_47669);
        _sym_47669 = _1;
    }

    /** 	return SymTab[sym][S_USAGE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24929 = (int)*(((s1_ptr)_2)->base + _sym_47669);
    _2 = (int)SEQ_PTR(_24929);
    _24930 = (int)*(((s1_ptr)_2)->base + 5);
    _24929 = NOVALUE;
    Ref(_24930);
    return _24930;
    ;
}


int _53calc_stack_required(int _sub_47677)
{
    int _required_47678 = NOVALUE;
    int _arg_47683 = NOVALUE;
    int _24950 = NOVALUE;
    int _24946 = NOVALUE;
    int _24944 = NOVALUE;
    int _24942 = NOVALUE;
    int _24941 = NOVALUE;
    int _24940 = NOVALUE;
    int _24939 = NOVALUE;
    int _24938 = NOVALUE;
    int _24936 = NOVALUE;
    int _24935 = NOVALUE;
    int _24933 = NOVALUE;
    int _24931 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_47677)) {
        _1 = (long)(DBL_PTR(_sub_47677)->dbl);
        DeRefDS(_sub_47677);
        _sub_47677 = _1;
    }

    /** 	integer required = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24931 = (int)*(((s1_ptr)_2)->base + _sub_47677);
    _2 = (int)SEQ_PTR(_24931);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _required_47678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _required_47678 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    if (!IS_ATOM_INT(_required_47678)){
        _required_47678 = (long)DBL_PTR(_required_47678)->dbl;
    }
    _24931 = NOVALUE;

    /** 	integer arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24933 = (int)*(((s1_ptr)_2)->base + _sub_47677);
    _2 = (int)SEQ_PTR(_24933);
    _arg_47683 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47683)){
        _arg_47683 = (long)DBL_PTR(_arg_47683)->dbl;
    }
    _24933 = NOVALUE;

    /** 	for i = 1 to required do*/
    _24935 = _required_47678;
    {
        int _i_47689;
        _i_47689 = 1;
L1: 
        if (_i_47689 > _24935){
            goto L2; // [40] 70
        }

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _24936 = (int)*(((s1_ptr)_2)->base + _arg_47683);
        _2 = (int)SEQ_PTR(_24936);
        _arg_47683 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_47683)){
            _arg_47683 = (long)DBL_PTR(_arg_47683)->dbl;
        }
        _24936 = NOVALUE;

        /** 	end for*/
        _i_47689 = _i_47689 + 1;
        goto L1; // [65] 47
L2: 
        ;
    }

    /** 	while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    _24938 = (_arg_47683 != 0);
    if (_24938 == 0) {
        goto L4; // [79] 132
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24940 = (int)*(((s1_ptr)_2)->base + _arg_47683);
    _2 = (int)SEQ_PTR(_24940);
    _24941 = (int)*(((s1_ptr)_2)->base + 4);
    _24940 = NOVALUE;
    if (IS_ATOM_INT(_24941)) {
        _24942 = (_24941 <= 3);
    }
    else {
        _24942 = binary_op(LESSEQ, _24941, 3);
    }
    _24941 = NOVALUE;
    if (_24942 <= 0) {
        if (_24942 == 0) {
            DeRef(_24942);
            _24942 = NOVALUE;
            goto L4; // [102] 132
        }
        else {
            if (!IS_ATOM_INT(_24942) && DBL_PTR(_24942)->dbl == 0.0){
                DeRef(_24942);
                _24942 = NOVALUE;
                goto L4; // [102] 132
            }
            DeRef(_24942);
            _24942 = NOVALUE;
        }
    }
    DeRef(_24942);
    _24942 = NOVALUE;

    /** 		required += 1*/
    _required_47678 = _required_47678 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24944 = (int)*(((s1_ptr)_2)->base + _arg_47683);
    _2 = (int)SEQ_PTR(_24944);
    _arg_47683 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47683)){
        _arg_47683 = (long)DBL_PTR(_arg_47683)->dbl;
    }
    _24944 = NOVALUE;

    /** 	end while*/
    goto L3; // [129] 75
L4: 

    /** 	arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24946 = (int)*(((s1_ptr)_2)->base + _sub_47677);
    _2 = (int)SEQ_PTR(_24946);
    if (!IS_ATOM_INT(_35S_TEMPS_15686)){
        _arg_47683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    }
    else{
        _arg_47683 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    }
    if (!IS_ATOM_INT(_arg_47683)){
        _arg_47683 = (long)DBL_PTR(_arg_47683)->dbl;
    }
    _24946 = NOVALUE;

    /** 	while arg != 0 do*/
L5: 
    if (_arg_47683 == 0)
    goto L6; // [153] 184

    /** 		required += 1*/
    _required_47678 = _required_47678 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _24950 = (int)*(((s1_ptr)_2)->base + _arg_47683);
    _2 = (int)SEQ_PTR(_24950);
    _arg_47683 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47683)){
        _arg_47683 = (long)DBL_PTR(_arg_47683)->dbl;
    }
    _24950 = NOVALUE;

    /** 	end while*/
    goto L5; // [181] 153
L6: 

    /** 	return required*/
    DeRef(_24938);
    _24938 = NOVALUE;
    return _required_47678;
    ;
}



// 0x5EA142E4
