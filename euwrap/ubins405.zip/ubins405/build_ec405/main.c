// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _68GetSourceName()
{
    int _real_name_63413 = NOVALUE;
    int _fh_63414 = NOVALUE;
    int _has_extension_63416 = NOVALUE;
    int _31685 = NOVALUE;
    int _31683 = NOVALUE;
    int _31682 = NOVALUE;
    int _31679 = NOVALUE;
    int _31678 = NOVALUE;
    int _31677 = NOVALUE;
    int _31676 = NOVALUE;
    int _31675 = NOVALUE;
    int _31674 = NOVALUE;
    int _31671 = NOVALUE;
    int _31670 = NOVALUE;
    int _31668 = NOVALUE;
    int _31667 = NOVALUE;
    int _31666 = NOVALUE;
    int _31665 = NOVALUE;
    int _31664 = NOVALUE;
    int _31663 = NOVALUE;
    int _31660 = NOVALUE;
    int _31659 = NOVALUE;
    int _31657 = NOVALUE;
    int _31656 = NOVALUE;
    int _31654 = NOVALUE;
    int _0, _1, _2;
    

    /** 	boolean has_extension = FALSE*/
    _has_extension_63416 = _13FALSE_435;

    /** 	if length(src_name) = 0 then*/
    if (IS_SEQUENCE(_43src_name_48479)){
            _31654 = SEQ_PTR(_43src_name_48479)->length;
    }
    else {
        _31654 = 1;
    }
    if (_31654 != 0)
    goto L1; // [15] 30

    /** 		show_banner()*/
    _43show_banner();

    /** 		return -2 -- No source file*/
    DeRef(_real_name_63413);
    return -2;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 	for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_43src_name_48479)){
            _31656 = SEQ_PTR(_43src_name_48479)->length;
    }
    else {
        _31656 = 1;
    }
    {
        int _p_63424;
        _p_63424 = _31656;
L2: 
        if (_p_63424 < 1){
            goto L3; // [39] 103
        }

        /** 		if src_name[p] = '.' then*/
        _2 = (int)SEQ_PTR(_43src_name_48479);
        _31657 = (int)*(((s1_ptr)_2)->base + _p_63424);
        if (binary_op_a(NOTEQ, _31657, 46)){
            _31657 = NOVALUE;
            goto L4; // [54] 72
        }
        _31657 = NOVALUE;

        /** 		   has_extension = TRUE*/
        _has_extension_63416 = _13TRUE_437;

        /** 		   exit*/
        goto L3; // [67] 103
        goto L5; // [69] 96
L4: 

        /** 		elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_43src_name_48479);
        _31659 = (int)*(((s1_ptr)_2)->base + _p_63424);
        _31660 = find_from(_31659, _40SLASH_CHARS_16126, 1);
        _31659 = NOVALUE;
        if (_31660 == 0)
        {
            _31660 = NOVALUE;
            goto L6; // [87] 95
        }
        else{
            _31660 = NOVALUE;
        }

        /** 		   exit*/
        goto L3; // [92] 103
L6: 
L5: 

        /** 	end for*/
        _p_63424 = _p_63424 + -1;
        goto L2; // [98] 46
L3: 
        ;
    }

    /** 	if not has_extension then*/
    if (_has_extension_63416 != 0)
    goto L7; // [105] 210

    /** 		known_files = append(known_files, "")*/
    RefDS(_21815);
    Append(&_36known_files_14982, _36known_files_14982, _21815);

    /** 		for i = 1 to length( DEFAULT_EXTS ) do*/
    _31663 = 4;
    {
        int _i_63443;
        _i_63443 = 1;
L8: 
        if (_i_63443 > 4){
            goto L9; // [125] 190
        }

        /** 			known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_36known_files_14982)){
                _31664 = SEQ_PTR(_36known_files_14982)->length;
        }
        else {
            _31664 = 1;
        }
        _2 = (int)SEQ_PTR(_40DEFAULT_EXTS_16107);
        _31665 = (int)*(((s1_ptr)_2)->base + _i_63443);
        Concat((object_ptr)&_31666, _43src_name_48479, _31665);
        _31665 = NOVALUE;
        _2 = (int)SEQ_PTR(_36known_files_14982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36known_files_14982 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _31664);
        _1 = *(int *)_2;
        *(int *)_2 = _31666;
        if( _1 != _31666 ){
            DeRef(_1);
        }
        _31666 = NOVALUE;

        /** 			real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_36known_files_14982)){
                _31667 = SEQ_PTR(_36known_files_14982)->length;
        }
        else {
            _31667 = 1;
        }
        _2 = (int)SEQ_PTR(_36known_files_14982);
        _31668 = (int)*(((s1_ptr)_2)->base + _31667);
        Ref(_31668);
        _0 = _real_name_63413;
        _real_name_63413 = _42e_path_find(_31668);
        DeRef(_0);
        _31668 = NOVALUE;

        /** 			if sequence(real_name) then*/
        _31670 = IS_SEQUENCE(_real_name_63413);
        if (_31670 == 0)
        {
            _31670 = NOVALUE;
            goto LA; // [175] 183
        }
        else{
            _31670 = NOVALUE;
        }

        /** 				exit*/
        goto L9; // [180] 190
LA: 

        /** 		end for*/
        _i_63443 = _i_63443 + 1;
        goto L8; // [185] 132
L9: 
        ;
    }

    /** 		if atom(real_name) then*/
    _31671 = IS_ATOM(_real_name_63413);
    if (_31671 == 0)
    {
        _31671 = NOVALUE;
        goto LB; // [197] 246
    }
    else{
        _31671 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_63413);
    return -1;
    goto LB; // [207] 246
L7: 

    /** 		known_files = append(known_files, src_name)*/
    RefDS(_43src_name_48479);
    Append(&_36known_files_14982, _36known_files_14982, _43src_name_48479);

    /** 		real_name = e_path_find(src_name)*/
    RefDS(_43src_name_48479);
    _0 = _real_name_63413;
    _real_name_63413 = _42e_path_find(_43src_name_48479);
    DeRef(_0);

    /** 		if atom(real_name) then*/
    _31674 = IS_ATOM(_real_name_63413);
    if (_31674 == 0)
    {
        _31674 = NOVALUE;
        goto LC; // [235] 245
    }
    else{
        _31674 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_63413);
    return -1;
LC: 
LB: 

    /** 	known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31675 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31675 = 1;
    }
    Ref(_real_name_63413);
    _31676 = _17canonical_path(_real_name_63413, 0, 2);
    _2 = (int)SEQ_PTR(_36known_files_14982);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36known_files_14982 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _31675);
    _1 = *(int *)_2;
    *(int *)_2 = _31676;
    if( _1 != _31676 ){
        DeRef(_1);
    }
    _31676 = NOVALUE;

    /** 	known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31677 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31677 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31678 = (int)*(((s1_ptr)_2)->base + _31677);
    _31679 = calc_hash(_31678, -5);
    _31678 = NOVALUE;
    Ref(_31679);
    Append(&_36known_files_hash_14983, _36known_files_hash_14983, _31679);
    DeRef(_31679);
    _31679 = NOVALUE;

    /** 	finished_files &= 0*/
    Append(&_36finished_files_14984, _36finished_files_14984, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31682 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31682 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31682;
    _31683 = MAKE_SEQ(_1);
    _31682 = NOVALUE;
    RefDS(_31683);
    Append(&_36file_include_depend_14985, _36file_include_depend_14985, _31683);
    DeRefDS(_31683);
    _31683 = NOVALUE;

    /** 	if file_exists(real_name) then*/
    Ref(_real_name_63413);
    _31685 = _17file_exists(_real_name_63413);
    if (_31685 == 0) {
        DeRef(_31685);
        _31685 = NOVALUE;
        goto LD; // [325] 349
    }
    else {
        if (!IS_ATOM_INT(_31685) && DBL_PTR(_31685)->dbl == 0.0){
            DeRef(_31685);
            _31685 = NOVALUE;
            goto LD; // [325] 349
        }
        DeRef(_31685);
        _31685 = NOVALUE;
    }
    DeRef(_31685);
    _31685 = NOVALUE;

    /** 		real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_63413);
    _0 = _real_name_63413;
    _real_name_63413 = _64maybe_preprocess(_real_name_63413);
    DeRef(_0);

    /** 		fh = open_locked(real_name)*/
    Ref(_real_name_63413);
    _fh_63414 = _36open_locked(_real_name_63413);
    if (!IS_ATOM_INT(_fh_63414)) {
        _1 = (long)(DBL_PTR(_fh_63414)->dbl);
        DeRefDS(_fh_63414);
        _fh_63414 = _1;
    }

    /** 		return fh*/
    DeRef(_real_name_63413);
    return _fh_63414;
LD: 

    /** 	return -1*/
    DeRef(_real_name_63413);
    return -1;
    ;
}


void _68main()
{
    int _argc_63512 = NOVALUE;
    int _argv_63513 = NOVALUE;
    int _31725 = NOVALUE;
    int _31724 = NOVALUE;
    int _31723 = NOVALUE;
    int _31722 = NOVALUE;
    int _31721 = NOVALUE;
    int _31720 = NOVALUE;
    int _31719 = NOVALUE;
    int _31718 = NOVALUE;
    int _31717 = NOVALUE;
    int _31716 = NOVALUE;
    int _31715 = NOVALUE;
    int _31712 = NOVALUE;
    int _31710 = NOVALUE;
    int _31708 = NOVALUE;
    int _31707 = NOVALUE;
    int _31706 = NOVALUE;
    int _31705 = NOVALUE;
    int _31704 = NOVALUE;
    int _31703 = NOVALUE;
    int _31702 = NOVALUE;
    int _31701 = NOVALUE;
    int _31697 = NOVALUE;
    int _0, _1, _2;
    

    /** 	argv = command_line()*/
    DeRef(_argv_63513);
    _argv_63513 = Command_Line();

    /** 	if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		argv = extract_options(argv)*/
    RefDS(_argv_63513);
    _0 = _argv_63513;
    _argv_63513 = _2extract_options(_argv_63513);
    DeRefDS(_0);
L1: 

    /** 	argc = length(argv)*/
    if (IS_SEQUENCE(_argv_63513)){
            _argc_63512 = SEQ_PTR(_argv_63513)->length;
    }
    else {
        _argc_63512 = 1;
    }

    /** 	Argv = argv*/
    RefDS(_argv_63513);
    DeRef(_35Argv_15979);
    _35Argv_15979 = _argv_63513;

    /** 	Argc = argc*/
    _35Argc_15978 = _argc_63512;

    /** 	TempErrName = "ex.err"*/
    RefDS(_31696);
    DeRefi(_44TempErrName_48140);
    _44TempErrName_48140 = _31696;

    /** 	TempWarningName = STDERR*/
    DeRef(_35TempWarningName_15982);
    _35TempWarningName_15982 = 2;

    /** 	display_warnings = 1*/
    _44display_warnings_48141 = 1;

    /** 	InitGlobals()*/
    _39InitGlobals();

    /** 	if TRANSLATE or BIND or INTERPRET then*/
    if (_35TRANSLATE_15611 != 0) {
        _31697 = 1;
        goto L2; // [69] 79
    }
    _31697 = (_35BIND_15614 != 0);
L2: 
    if (_31697 != 0) {
        goto L3; // [79] 90
    }
    if (_35INTERPRET_15608 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** 		InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** 	src_file = GetSourceName()*/
    _0 = _68GetSourceName();
    _35src_file_16089 = _0;
    if (!IS_ATOM_INT(_35src_file_16089)) {
        _1 = (long)(DBL_PTR(_35src_file_16089)->dbl);
        DeRefDS(_35src_file_16089);
        _35src_file_16089 = _1;
    }

    /** 	if src_file = -1 then*/
    if (_35src_file_16089 != -1)
    goto L5; // [107] 181

    /** 		screen_output(STDERR, GetMsgText(51, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31701 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31701 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31702 = (int)*(((s1_ptr)_2)->base + _31701);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_31702);
    *((int *)(_2+4)) = _31702;
    _31703 = MAKE_SEQ(_1);
    _31702 = NOVALUE;
    _31704 = _45GetMsgText(51, 0, _31703);
    _31703 = NOVALUE;
    _44screen_output(2, _31704);
    _31704 = NOVALUE;

    /** 		if not batch_job and not test_only then*/
    _31705 = (_35batch_job_15981 == 0);
    if (_31705 == 0) {
        goto L6; // [145] 173
    }
    _31707 = (_35test_only_15980 == 0);
    if (_31707 == 0)
    {
        DeRef(_31707);
        _31707 = NOVALUE;
        goto L6; // [155] 173
    }
    else{
        DeRef(_31707);
        _31707 = NOVALUE;
    }

    /** 			maybe_any_key(GetMsgText(277,0), STDERR)*/
    RefDS(_21815);
    _31708 = _45GetMsgText(277, 0, _21815);
    _5maybe_any_key(_31708, 2);
    _31708 = NOVALUE;
L6: 

    /** 		Cleanup(1)*/
    _44Cleanup(1);
    goto L7; // [178] 226
L5: 

    /** 	elsif src_file >= 0 then*/
    if (_35src_file_16089 < 0)
    goto L8; // [185] 225

    /** 		main_path = known_files[$]*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31710 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31710 = 1;
    }
    DeRef(_35main_path_16088);
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _35main_path_16088 = (int)*(((s1_ptr)_2)->base + _31710);
    Ref(_35main_path_16088);

    /** 		if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_35main_path_16088)){
            _31712 = SEQ_PTR(_35main_path_16088)->length;
    }
    else {
        _31712 = 1;
    }
    if (_31712 != 0)
    goto L9; // [209] 224

    /** 			main_path = '.' & SLASH*/
    Concat((object_ptr)&_35main_path_16088, 46, 47);
L9: 
L8: 
L7: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LA; // [230] 239
    }
    else{
    }

    /** 		InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** 	CheckPlatform()*/
    _2CheckPlatform();

    /** 	InitSymTab()*/
    _53InitSymTab();

    /** 	InitEmit()*/
    _41InitEmit();

    /** 	InitLex()*/
    _61InitLex();

    /** 	InitParser()*/
    _39InitParser();

    /** 	eu_namespace()*/
    _61eu_namespace();

    /** 	ifdef TRANSLATOR then*/

    /** 		if keep and build_system_type = BUILD_DIRECT then*/
    if (_57keep_41337 == 0) {
        goto LB; // [269] 338
    }
    _31716 = (_55build_system_type_43982 == 3);
    if (_31716 == 0)
    {
        DeRef(_31716);
        _31716 = NOVALUE;
        goto LB; // [282] 338
    }
    else{
        DeRef(_31716);
        _31716 = NOVALUE;
    }

    /** 			if 0 and not quick_has_changed(known_files[$]) then*/
    if (0 == 0) {
        goto LC; // [287] 337
    }
    if (IS_SEQUENCE(_36known_files_14982)){
            _31718 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31718 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31719 = (int)*(((s1_ptr)_2)->base + _31718);
    Ref(_31719);
    _31720 = _55quick_has_changed(_31719);
    _31719 = NOVALUE;
    if (IS_ATOM_INT(_31720)) {
        _31721 = (_31720 == 0);
    }
    else {
        _31721 = unary_op(NOT, _31720);
    }
    DeRef(_31720);
    _31720 = NOVALUE;
    if (_31721 == 0) {
        DeRef(_31721);
        _31721 = NOVALUE;
        goto LC; // [308] 337
    }
    else {
        if (!IS_ATOM_INT(_31721) && DBL_PTR(_31721)->dbl == 0.0){
            DeRef(_31721);
            _31721 = NOVALUE;
            goto LC; // [308] 337
        }
        DeRef(_31721);
        _31721 = NOVALUE;
    }
    DeRef(_31721);
    _31721 = NOVALUE;

    /** 				build_direct(1, known_files[$])*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31722 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31722 = 1;
    }
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31723 = (int)*(((s1_ptr)_2)->base + _31722);
    Ref(_31723);
    _55build_direct(1, _31723);
    _31723 = NOVALUE;

    /** 				Cleanup(0)*/
    _44Cleanup(0);

    /** 				return*/
    DeRef(_argv_63513);
    DeRef(_31705);
    _31705 = NOVALUE;
    return;
LC: 
LB: 

    /** 	main_file()*/
    _61main_file();

    /** 	check_coverage()*/
    _50check_coverage();

    /** 	parser()*/
    _39parser();

    /** 	init_coverage()*/
    _50init_coverage();

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LD; // [358] 369
    }
    else{
    }

    /** 		BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LE; // [366] 409
LD: 

    /** 	elsif BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto LF; // [373] 383
    }
    else{
    }

    /** 		OutputIL()*/
    _2OutputIL();
    goto LE; // [380] 409
LF: 

    /** 	elsif INTERPRET and not test_only then*/
    if (_35INTERPRET_15608 == 0) {
        goto L10; // [387] 408
    }
    _31725 = (_35test_only_15980 == 0);
    if (_31725 == 0)
    {
        DeRef(_31725);
        _31725 = NOVALUE;
        goto L10; // [397] 408
    }
    else{
        DeRef(_31725);
        _31725 = NOVALUE;
    }

    /** 		ifdef not STDDEBUG then*/

    /** 			BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);
L10: 
LE: 

    /** 	Cleanup(0) -- does warnings*/
    _44Cleanup(0);

    /** end procedure*/
    DeRef(_argv_63513);
    DeRef(_31705);
    _31705 = NOVALUE;
    return;
    ;
}



// 0x3B96A015
