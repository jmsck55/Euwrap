// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _20abs(int _a_3230)
{
    int _t_3231 = NOVALUE;
    int _1574 = NOVALUE;
    int _1573 = NOVALUE;
    int _1572 = NOVALUE;
    int _1570 = NOVALUE;
    int _1568 = NOVALUE;
    int _1567 = NOVALUE;
    int _1565 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1565 = IS_ATOM(_a_3230);
    if (_1565 == 0)
    {
        _1565 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1565 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_3230, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_3231);
    return _a_3230;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_3230)) {
        if ((unsigned long)_a_3230 == 0xC0000000)
        _1567 = (int)NewDouble((double)-0xC0000000);
        else
        _1567 = - _a_3230;
    }
    else {
        _1567 = unary_op(UMINUS, _a_3230);
    }
    DeRef(_a_3230);
    DeRef(_t_3231);
    return _1567;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3230)){
            _1568 = SEQ_PTR(_a_3230)->length;
    }
    else {
        _1568 = 1;
    }
    {
        int _i_3239;
        _i_3239 = 1;
L4: 
        if (_i_3239 > _1568){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_3231);
        _2 = (int)SEQ_PTR(_a_3230);
        _t_3231 = (int)*(((s1_ptr)_2)->base + _i_3239);
        Ref(_t_3231);

        /** 		if atom(t) then*/
        _1570 = IS_ATOM(_t_3231);
        if (_1570 == 0)
        {
            _1570 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1570 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_3231, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_3231)) {
            if ((unsigned long)_t_3231 == 0xC0000000)
            _1572 = (int)NewDouble((double)-0xC0000000);
            else
            _1572 = - _t_3231;
        }
        else {
            _1572 = unary_op(UMINUS, _t_3231);
        }
        _2 = (int)SEQ_PTR(_a_3230);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_3230 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3239);
        _1 = *(int *)_2;
        *(int *)_2 = _1572;
        if( _1 != _1572 ){
            DeRef(_1);
        }
        _1572 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_3231);
        DeRef(_1573);
        _1573 = _t_3231;
        _1574 = _20abs(_1573);
        _1573 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_3230);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_3230 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_3239);
        _1 = *(int *)_2;
        *(int *)_2 = _1574;
        if( _1 != _1574 ){
            DeRef(_1);
        }
        _1574 = NOVALUE;
L7: 

        /** 	end for*/
        _i_3239 = _i_3239 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_3231);
    DeRef(_1567);
    _1567 = NOVALUE;
    return _a_3230;
    ;
}


int _20max(int _a_3274)
{
    int _b_3275 = NOVALUE;
    int _c_3276 = NOVALUE;
    int _1584 = NOVALUE;
    int _1583 = NOVALUE;
    int _1582 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1582 = IS_ATOM(_a_3274);
    if (_1582 == 0)
    {
        _1582 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1582 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_3275);
    DeRef(_c_3276);
    return _a_3274;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_22MINF_3208);
    DeRef(_b_3275);
    _b_3275 = _22MINF_3208;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3274)){
            _1583 = SEQ_PTR(_a_3274)->length;
    }
    else {
        _1583 = 1;
    }
    {
        int _i_3280;
        _i_3280 = 1;
L2: 
        if (_i_3280 > _1583){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_3274);
        _1584 = (int)*(((s1_ptr)_2)->base + _i_3280);
        Ref(_1584);
        _0 = _c_3276;
        _c_3276 = _20max(_1584);
        DeRef(_0);
        _1584 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_3276, _b_3275)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_3276);
        DeRef(_b_3275);
        _b_3275 = _c_3276;
L4: 

        /** 	end for*/
        _i_3280 = _i_3280 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3274);
    DeRef(_c_3276);
    return _b_3275;
    ;
}


int _20min(int _a_3288)
{
    int _b_3289 = NOVALUE;
    int _c_3290 = NOVALUE;
    int _1589 = NOVALUE;
    int _1588 = NOVALUE;
    int _1587 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1587 = IS_ATOM(_a_3288);
    if (_1587 == 0)
    {
        _1587 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1587 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_3289);
    DeRef(_c_3290);
    return _a_3288;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_22PINF_3204);
    DeRef(_b_3289);
    _b_3289 = _22PINF_3204;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3288)){
            _1588 = SEQ_PTR(_a_3288)->length;
    }
    else {
        _1588 = 1;
    }
    {
        int _i_3294;
        _i_3294 = 1;
L2: 
        if (_i_3294 > _1588){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_3288);
        _1589 = (int)*(((s1_ptr)_2)->base + _i_3294);
        Ref(_1589);
        _0 = _c_3290;
        _c_3290 = _20min(_1589);
        DeRef(_0);
        _1589 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_3290, _b_3289)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_3290);
        DeRef(_b_3289);
        _b_3289 = _c_3290;
L4: 

        /** 	end for*/
        _i_3294 = _i_3294 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3288);
    DeRef(_c_3290);
    return _b_3289;
    ;
}


int _20or_all(int _a_3667)
{
    int _b_3668 = NOVALUE;
    int _1788 = NOVALUE;
    int _1787 = NOVALUE;
    int _1785 = NOVALUE;
    int _1784 = NOVALUE;
    int _1783 = NOVALUE;
    int _1782 = NOVALUE;
    int _1781 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1781 = IS_ATOM(_a_3667);
    if (_1781 == 0)
    {
        _1781 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1781 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_3668);
    return _a_3667;
L1: 

    /** 	b = 0*/
    DeRef(_b_3668);
    _b_3668 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3667)){
            _1782 = SEQ_PTR(_a_3667)->length;
    }
    else {
        _1782 = 1;
    }
    {
        int _i_3672;
        _i_3672 = 1;
L2: 
        if (_i_3672 > _1782){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_3667);
        _1783 = (int)*(((s1_ptr)_2)->base + _i_3672);
        _1784 = IS_ATOM(_1783);
        _1783 = NOVALUE;
        if (_1784 == 0)
        {
            _1784 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1784 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_3667);
        _1785 = (int)*(((s1_ptr)_2)->base + _i_3672);
        _0 = _b_3668;
        if (IS_ATOM_INT(_b_3668) && IS_ATOM_INT(_1785)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3668 | (unsigned long)_1785;
                 _b_3668 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3668 = binary_op(OR_BITS, _b_3668, _1785);
        }
        DeRef(_0);
        _1785 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_3667);
        _1787 = (int)*(((s1_ptr)_2)->base + _i_3672);
        Ref(_1787);
        _1788 = _20or_all(_1787);
        _1787 = NOVALUE;
        _0 = _b_3668;
        if (IS_ATOM_INT(_b_3668) && IS_ATOM_INT(_1788)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3668 | (unsigned long)_1788;
                 _b_3668 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3668 = binary_op(OR_BITS, _b_3668, _1788);
        }
        DeRef(_0);
        DeRef(_1788);
        _1788 = NOVALUE;
L5: 

        /** 	end for*/
        _i_3672 = _i_3672 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3667);
    return _b_3668;
    ;
}



// 0xA1C9AD16
