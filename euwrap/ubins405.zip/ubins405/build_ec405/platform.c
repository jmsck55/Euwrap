// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _40host_platform()
{
    int _0, _1, _2;
    

    /** 	return ihost_platform*/
    return _40ihost_platform_16128;
    ;
}


void _40set_host_platform(int _plat_16135)
{
    int _8897 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ihost_platform = floor(plat)*/
    _40ihost_platform_16128 = e_floor(_plat_16135);
    if (!IS_ATOM_INT(_40ihost_platform_16128)) {
        _1 = (long)(DBL_PTR(_40ihost_platform_16128)->dbl);
        DeRefDS(_40ihost_platform_16128);
        _40ihost_platform_16128 = _1;
    }

    /** 	TUNIX    = (find(ihost_platform, unices) != 0) */
    _8897 = find_from(_40ihost_platform_16128, _40unices_16131, 1);
    _40TUNIX_16116 = (_8897 != 0);
    _8897 = NOVALUE;

    /** 	TWINDOWS = (ihost_platform = WIN32)*/
    _40TWINDOWS_16112 = (_40ihost_platform_16128 == 2);

    /** 	TBSD     = (ihost_platform = UFREEBSD)*/
    _40TBSD_16118 = (_40ihost_platform_16128 == 8);

    /** 	TOSX     = (ihost_platform = UOSX)*/
    _40TOSX_16120 = (_40ihost_platform_16128 == 4);

    /** 	TLINUX   = (ihost_platform = ULINUX)*/
    _40TLINUX_16114 = (_40ihost_platform_16128 == 3);

    /** 	TOPENBSD = (ihost_platform = UOPENBSD)*/
    _40TOPENBSD_16122 = (_40ihost_platform_16128 == 6);

    /** 	TNETBSD  = (ihost_platform = UNETBSD)*/
    _40TNETBSD_16124 = (_40ihost_platform_16128 == 7);

    /** 	IUNIX    = TUNIX*/
    _40IUNIX_16115 = _40TUNIX_16116;

    /** 	IWINDOWS = TWINDOWS*/
    _40IWINDOWS_16111 = _40TWINDOWS_16112;

    /** 	IBSD     = TBSD*/
    _40IBSD_16117 = _40TBSD_16118;

    /** 	IOSX     = TOSX*/
    _40IOSX_16119 = _40TOSX_16120;

    /** 	ILINUX   = TLINUX*/
    _40ILINUX_16113 = _40TLINUX_16114;

    /** 	IOPENBSD = TOPENBSD*/
    _40IOPENBSD_16121 = _40TOPENBSD_16122;

    /** 	INETBSD  = TNETBSD*/
    _40INETBSD_16123 = _40TNETBSD_16124;

    /** 	if TUNIX then*/
    if (_40TUNIX_16116 == 0)
    {
        goto L1; // [148] 161
    }
    else{
    }

    /** 		HOSTNL = "\n"*/
    RefDS(_3073);
    DeRefi(_40HOSTNL_16127);
    _40HOSTNL_16127 = _3073;
    goto L2; // [158] 169
L1: 

    /** 		HOSTNL = "\r\n"*/
    RefDS(_3079);
    DeRefi(_40HOSTNL_16127);
    _40HOSTNL_16127 = _3079;
L2: 

    /** end procedure*/
    return;
    ;
}


int _40GetPlatformDefines(int _for_translator_16150)
{
    int _local_defines_16151 = NOVALUE;
    int _lcmds_16161 = NOVALUE;
    int _fh_16163 = NOVALUE;
    int _sk_16183 = NOVALUE;
    int _8998 = NOVALUE;
    int _8997 = NOVALUE;
    int _8995 = NOVALUE;
    int _8992 = NOVALUE;
    int _8990 = NOVALUE;
    int _8988 = NOVALUE;
    int _8987 = NOVALUE;
    int _8985 = NOVALUE;
    int _8983 = NOVALUE;
    int _8981 = NOVALUE;
    int _8980 = NOVALUE;
    int _8978 = NOVALUE;
    int _8976 = NOVALUE;
    int _8974 = NOVALUE;
    int _8973 = NOVALUE;
    int _8971 = NOVALUE;
    int _8968 = NOVALUE;
    int _8966 = NOVALUE;
    int _8965 = NOVALUE;
    int _8963 = NOVALUE;
    int _8961 = NOVALUE;
    int _8959 = NOVALUE;
    int _8958 = NOVALUE;
    int _8955 = NOVALUE;
    int _8953 = NOVALUE;
    int _8950 = NOVALUE;
    int _8946 = NOVALUE;
    int _8945 = NOVALUE;
    int _8940 = NOVALUE;
    int _8939 = NOVALUE;
    int _8926 = NOVALUE;
    int _8923 = NOVALUE;
    int _8920 = NOVALUE;
    int _8919 = NOVALUE;
    int _8918 = NOVALUE;
    int _8914 = NOVALUE;
    int _8911 = NOVALUE;
    int _8908 = NOVALUE;
    int _8906 = NOVALUE;
    int _8905 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence local_defines = {}*/
    RefDS(_5);
    DeRef(_local_defines_16151);
    _local_defines_16151 = _5;

    /** 	if (IWINDOWS and not for_translator) or (TWINDOWS and for_translator) then*/
    if (_40IWINDOWS_16111 == 0) {
        _8905 = 0;
        goto L1; // [14] 25
    }
    _8906 = (_for_translator_16150 == 0);
    _8905 = (_8906 != 0);
L1: 
    if (_8905 != 0) {
        goto L2; // [25] 44
    }
    if (_40TWINDOWS_16112 == 0) {
        DeRef(_8908);
        _8908 = 0;
        goto L3; // [31] 39
    }
    _8908 = (_for_translator_16150 != 0);
L3: 
    if (_8908 == 0)
    {
        _8908 = NOVALUE;
        goto L4; // [40] 326
    }
    else{
        _8908 = NOVALUE;
    }
L2: 

    /** 		local_defines &= {"WINDOWS", "WIN32"}*/
    RefDS(_8910);
    RefDS(_8909);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _8909;
    ((int *)_2)[2] = _8910;
    _8911 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8911);
    DeRefDS(_8911);
    _8911 = NOVALUE;

    /** 		sequence lcmds = command_line()*/
    DeRef(_lcmds_16161);
    _lcmds_16161 = Command_Line();

    /** 		integer fh*/

    /** 		fh = open(lcmds[1], "rb")*/
    _2 = (int)SEQ_PTR(_lcmds_16161);
    _8914 = (int)*(((s1_ptr)_2)->base + 1);
    _fh_16163 = EOpen(_8914, _3632, 0);
    _8914 = NOVALUE;

    /** 		if fh = -1 then*/
    if (_fh_16163 != -1)
    goto L5; // [73] 123

    /**  			if match("euiw", lower(lcmds[1])) != 0 then*/
    _2 = (int)SEQ_PTR(_lcmds_16161);
    _8918 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_8918);
    _8919 = _14lower(_8918);
    _8918 = NOVALUE;
    _8920 = e_match_from(_8917, _8919, 1);
    DeRef(_8919);
    _8919 = NOVALUE;
    if (_8920 == 0)
    goto L6; // [92] 109

    /**  				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8922);
    *((int *)(_2+4)) = _8922;
    _8923 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8923);
    DeRefDS(_8923);
    _8923 = NOVALUE;
    goto L7; // [106] 321
L6: 

    /**  				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8925);
    *((int *)(_2+4)) = _8925;
    _8926 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8926);
    DeRefDS(_8926);
    _8926 = NOVALUE;
    goto L7; // [120] 321
L5: 

    /** 			atom sk*/

    /** 			sk = seek(fh, #18) -- Fixed location of relocation table.*/
    _0 = _sk_16183;
    _sk_16183 = _8seek(_fh_16163, 24);
    DeRef(_0);

    /** 			sk = get_integer16(fh)*/
    _0 = _sk_16183;
    _sk_16183 = _8get_integer16(_fh_16163);
    DeRef(_0);

    /** 			if sk = #40 then*/
    if (binary_op_a(NOTEQ, _sk_16183, 64)){
        goto L8; // [140] 259
    }

    /** 				sk = seek(fh, #3C) -- Fixed location of COFF signature offset.*/
    _0 = _sk_16183;
    _sk_16183 = _8seek(_fh_16163, 60);
    DeRef(_0);

    /** 				sk = get_integer32(fh)*/
    _0 = _sk_16183;
    _sk_16183 = _8get_integer32(_fh_16163);
    DeRef(_0);

    /** 				sk = seek(fh, sk)*/
    Ref(_sk_16183);
    _0 = _sk_16183;
    _sk_16183 = _8seek(_fh_16163, _sk_16183);
    DeRef(_0);

    /** 				sk = get_integer16(fh)*/
    _0 = _sk_16183;
    _sk_16183 = _8get_integer16(_fh_16163);
    DeRef(_0);

    /** 				if sk = #4550 then -- "PE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_16183, 17744)){
        goto L9; // [172] 221
    }

    /** 					sk = get_integer16(fh)*/
    _0 = _sk_16183;
    _sk_16183 = _8get_integer16(_fh_16163);
    DeRef(_0);

    /** 					if sk = 0 then*/
    if (binary_op_a(NOTEQ, _sk_16183, 0)){
        goto LA; // [184] 212
    }

    /** 						sk = seek(fh, where(fh) + 88 )*/
    _8939 = _8where(_fh_16163);
    if (IS_ATOM_INT(_8939)) {
        _8940 = _8939 + 88;
        if ((long)((unsigned long)_8940 + (unsigned long)HIGH_BITS) >= 0) 
        _8940 = NewDouble((double)_8940);
    }
    else {
        _8940 = binary_op(PLUS, _8939, 88);
    }
    DeRef(_8939);
    _8939 = NOVALUE;
    _0 = _sk_16183;
    _sk_16183 = _8seek(_fh_16163, _8940);
    DeRef(_0);
    _8940 = NOVALUE;

    /** 						sk = get_integer16(fh)*/
    _0 = _sk_16183;
    _sk_16183 = _8get_integer16(_fh_16163);
    DeRef(_0);
    goto LB; // [209] 265
LA: 

    /** 						sk = 0	-- Don't know this format.*/
    DeRef(_sk_16183);
    _sk_16183 = 0;
    goto LB; // [218] 265
L9: 

    /** 				elsif sk = #454E then -- "NE" in intel endian*/
    if (binary_op_a(NOTEQ, _sk_16183, 17742)){
        goto LC; // [223] 250
    }

    /** 					sk = seek(fh, where(fh) + 54 )*/
    _8945 = _8where(_fh_16163);
    if (IS_ATOM_INT(_8945)) {
        _8946 = _8945 + 54;
        if ((long)((unsigned long)_8946 + (unsigned long)HIGH_BITS) >= 0) 
        _8946 = NewDouble((double)_8946);
    }
    else {
        _8946 = binary_op(PLUS, _8945, 54);
    }
    DeRef(_8945);
    _8945 = NOVALUE;
    _0 = _sk_16183;
    _sk_16183 = _8seek(_fh_16163, _8946);
    DeRef(_0);
    _8946 = NOVALUE;

    /** 					sk = getc(fh)*/
    DeRef(_sk_16183);
    if (_fh_16163 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_16163, EF_READ);
        last_r_file_no = _fh_16163;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _sk_16183 = getc((FILE*)xstdin);
        }
        else
        _sk_16183 = getc(last_r_file_ptr);
    }
    else
    _sk_16183 = getc(last_r_file_ptr);
    goto LB; // [247] 265
LC: 

    /** 					sk = 0*/
    DeRef(_sk_16183);
    _sk_16183 = 0;
    goto LB; // [256] 265
L8: 

    /** 				sk = 0*/
    DeRef(_sk_16183);
    _sk_16183 = 0;
LB: 

    /** 			if sk = 2 then*/
    if (binary_op_a(NOTEQ, _sk_16183, 2)){
        goto LD; // [267] 284
    }

    /** 				local_defines &= { "GUI" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8922);
    *((int *)(_2+4)) = _8922;
    _8950 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8950);
    DeRefDS(_8950);
    _8950 = NOVALUE;
    goto LE; // [281] 314
LD: 

    /** 			elsif sk = 3 then*/
    if (binary_op_a(NOTEQ, _sk_16183, 3)){
        goto LF; // [286] 303
    }

    /** 				local_defines &= { "CONSOLE" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8925);
    *((int *)(_2+4)) = _8925;
    _8953 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8953);
    DeRefDS(_8953);
    _8953 = NOVALUE;
    goto LE; // [300] 314
LF: 

    /** 				local_defines &= { "UNKNOWN" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_7698);
    *((int *)(_2+4)) = _7698;
    _8955 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8955);
    DeRefDS(_8955);
    _8955 = NOVALUE;
LE: 

    /** 			close(fh)*/
    EClose(_fh_16163);
    DeRef(_sk_16183);
    _sk_16183 = NOVALUE;
L7: 
    DeRef(_lcmds_16161);
    _lcmds_16161 = NOVALUE;
    goto L10; // [323] 575
L4: 

    /** 		local_defines = append( local_defines, "CONSOLE" )*/
    RefDS(_8925);
    Append(&_local_defines_16151, _local_defines_16151, _8925);

    /** 		if (ILINUX and not for_translator) or (TLINUX and for_translator) then*/
    if (_40ILINUX_16113 == 0) {
        _8958 = 0;
        goto L11; // [336] 347
    }
    _8959 = (_for_translator_16150 == 0);
    _8958 = (_8959 != 0);
L11: 
    if (_8958 != 0) {
        goto L12; // [347] 366
    }
    if (_40TLINUX_16114 == 0) {
        DeRef(_8961);
        _8961 = 0;
        goto L13; // [353] 361
    }
    _8961 = (_for_translator_16150 != 0);
L13: 
    if (_8961 == 0)
    {
        _8961 = NOVALUE;
        goto L14; // [362] 379
    }
    else{
        _8961 = NOVALUE;
    }
L12: 

    /** 			local_defines &= {"UNIX", "LINUX"}*/
    RefDS(_8962);
    RefDS(_8722);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _8722;
    ((int *)_2)[2] = _8962;
    _8963 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8963);
    DeRefDS(_8963);
    _8963 = NOVALUE;
    goto L15; // [376] 574
L14: 

    /** 		elsif (IOSX and not for_translator) or (TOSX and for_translator) then*/
    if (_40IOSX_16119 == 0) {
        _8965 = 0;
        goto L16; // [383] 394
    }
    _8966 = (_for_translator_16150 == 0);
    _8965 = (_8966 != 0);
L16: 
    if (_8965 != 0) {
        goto L17; // [394] 413
    }
    if (_40TOSX_16120 == 0) {
        DeRef(_8968);
        _8968 = 0;
        goto L18; // [400] 408
    }
    _8968 = (_for_translator_16150 != 0);
L18: 
    if (_8968 == 0)
    {
        _8968 = NOVALUE;
        goto L19; // [409] 428
    }
    else{
        _8968 = NOVALUE;
    }
L17: 

    /** 			local_defines &= {"UNIX", "BSD", "OSX"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8722);
    *((int *)(_2+4)) = _8722;
    RefDS(_8969);
    *((int *)(_2+8)) = _8969;
    RefDS(_8970);
    *((int *)(_2+12)) = _8970;
    _8971 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8971);
    DeRefDS(_8971);
    _8971 = NOVALUE;
    goto L15; // [425] 574
L19: 

    /** 		elsif (IOPENBSD and not for_translator) or (TOPENBSD and for_translator) then*/
    if (_40IOPENBSD_16121 == 0) {
        _8973 = 0;
        goto L1A; // [432] 443
    }
    _8974 = (_for_translator_16150 == 0);
    _8973 = (_8974 != 0);
L1A: 
    if (_8973 != 0) {
        goto L1B; // [443] 462
    }
    if (_40TOPENBSD_16122 == 0) {
        DeRef(_8976);
        _8976 = 0;
        goto L1C; // [449] 457
    }
    _8976 = (_for_translator_16150 != 0);
L1C: 
    if (_8976 == 0)
    {
        _8976 = NOVALUE;
        goto L1D; // [458] 477
    }
    else{
        _8976 = NOVALUE;
    }
L1B: 

    /** 			local_defines &= { "UNIX", "BSD", "OPENBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8722);
    *((int *)(_2+4)) = _8722;
    RefDS(_8969);
    *((int *)(_2+8)) = _8969;
    RefDS(_8977);
    *((int *)(_2+12)) = _8977;
    _8978 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8978);
    DeRefDS(_8978);
    _8978 = NOVALUE;
    goto L15; // [474] 574
L1D: 

    /** 		elsif (INETBSD and not for_translator) or (TNETBSD and for_translator) then*/
    if (_40INETBSD_16123 == 0) {
        _8980 = 0;
        goto L1E; // [481] 492
    }
    _8981 = (_for_translator_16150 == 0);
    _8980 = (_8981 != 0);
L1E: 
    if (_8980 != 0) {
        goto L1F; // [492] 511
    }
    if (_40TNETBSD_16124 == 0) {
        DeRef(_8983);
        _8983 = 0;
        goto L20; // [498] 506
    }
    _8983 = (_for_translator_16150 != 0);
L20: 
    if (_8983 == 0)
    {
        _8983 = NOVALUE;
        goto L21; // [507] 526
    }
    else{
        _8983 = NOVALUE;
    }
L1F: 

    /** 			local_defines &= { "UNIX", "BSD", "NETBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8722);
    *((int *)(_2+4)) = _8722;
    RefDS(_8969);
    *((int *)(_2+8)) = _8969;
    RefDS(_8984);
    *((int *)(_2+12)) = _8984;
    _8985 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8985);
    DeRefDS(_8985);
    _8985 = NOVALUE;
    goto L15; // [523] 574
L21: 

    /** 		elsif (IBSD and not for_translator) or (TBSD and for_translator) then*/
    if (_40IBSD_16117 == 0) {
        _8987 = 0;
        goto L22; // [530] 541
    }
    _8988 = (_for_translator_16150 == 0);
    _8987 = (_8988 != 0);
L22: 
    if (_8987 != 0) {
        goto L23; // [541] 560
    }
    if (_40TBSD_16118 == 0) {
        DeRef(_8990);
        _8990 = 0;
        goto L24; // [547] 555
    }
    _8990 = (_for_translator_16150 != 0);
L24: 
    if (_8990 == 0)
    {
        _8990 = NOVALUE;
        goto L25; // [556] 573
    }
    else{
        _8990 = NOVALUE;
    }
L23: 

    /** 			local_defines &= {"UNIX", "BSD", "FREEBSD"}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8722);
    *((int *)(_2+4)) = _8722;
    RefDS(_8969);
    *((int *)(_2+8)) = _8969;
    RefDS(_8991);
    *((int *)(_2+12)) = _8991;
    _8992 = MAKE_SEQ(_1);
    Concat((object_ptr)&_local_defines_16151, _local_defines_16151, _8992);
    DeRefDS(_8992);
    _8992 = NOVALUE;
L25: 
L15: 
L10: 

    /** 	return { "_PLAT_START" } & local_defines & { "_PLAT_STOP" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8994);
    *((int *)(_2+4)) = _8994;
    _8995 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8996);
    *((int *)(_2+4)) = _8996;
    _8997 = MAKE_SEQ(_1);
    {
        int concat_list[3];

        concat_list[0] = _8997;
        concat_list[1] = _local_defines_16151;
        concat_list[2] = _8995;
        Concat_N((object_ptr)&_8998, concat_list, 3);
    }
    DeRefDS(_8997);
    _8997 = NOVALUE;
    DeRefDS(_8995);
    _8995 = NOVALUE;
    DeRefDS(_local_defines_16151);
    DeRef(_8906);
    _8906 = NOVALUE;
    DeRef(_8959);
    _8959 = NOVALUE;
    DeRef(_8966);
    _8966 = NOVALUE;
    DeRef(_8974);
    _8974 = NOVALUE;
    DeRef(_8981);
    _8981 = NOVALUE;
    DeRef(_8988);
    _8988 = NOVALUE;
    return _8998;
    ;
}



// 0x14EA9AC3
