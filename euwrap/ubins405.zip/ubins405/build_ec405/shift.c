// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _65init_op_info()
{
    int _SHORT_CIRCUIT_26649 = NOVALUE;
    int _15056 = NOVALUE;
    int _15055 = NOVALUE;
    int _15054 = NOVALUE;
    int _15053 = NOVALUE;
    int _15052 = NOVALUE;
    int _15051 = NOVALUE;
    int _15050 = NOVALUE;
    int _15049 = NOVALUE;
    int _15048 = NOVALUE;
    int _15047 = NOVALUE;
    int _15046 = NOVALUE;
    int _15045 = NOVALUE;
    int _15044 = NOVALUE;
    int _15043 = NOVALUE;
    int _15042 = NOVALUE;
    int _15041 = NOVALUE;
    int _15040 = NOVALUE;
    int _15038 = NOVALUE;
    int _15037 = NOVALUE;
    int _15036 = NOVALUE;
    int _15035 = NOVALUE;
    int _15034 = NOVALUE;
    int _15033 = NOVALUE;
    int _15032 = NOVALUE;
    int _15031 = NOVALUE;
    int _15030 = NOVALUE;
    int _15029 = NOVALUE;
    int _15028 = NOVALUE;
    int _15027 = NOVALUE;
    int _15026 = NOVALUE;
    int _15025 = NOVALUE;
    int _15024 = NOVALUE;
    int _15023 = NOVALUE;
    int _15022 = NOVALUE;
    int _15021 = NOVALUE;
    int _15020 = NOVALUE;
    int _15019 = NOVALUE;
    int _15018 = NOVALUE;
    int _15017 = NOVALUE;
    int _15016 = NOVALUE;
    int _15015 = NOVALUE;
    int _15014 = NOVALUE;
    int _15013 = NOVALUE;
    int _15012 = NOVALUE;
    int _15011 = NOVALUE;
    int _15010 = NOVALUE;
    int _15009 = NOVALUE;
    int _15008 = NOVALUE;
    int _15007 = NOVALUE;
    int _15006 = NOVALUE;
    int _15005 = NOVALUE;
    int _15004 = NOVALUE;
    int _15003 = NOVALUE;
    int _15002 = NOVALUE;
    int _15001 = NOVALUE;
    int _15000 = NOVALUE;
    int _14999 = NOVALUE;
    int _14998 = NOVALUE;
    int _14997 = NOVALUE;
    int _14996 = NOVALUE;
    int _14995 = NOVALUE;
    int _14994 = NOVALUE;
    int _14993 = NOVALUE;
    int _14992 = NOVALUE;
    int _14991 = NOVALUE;
    int _14990 = NOVALUE;
    int _14989 = NOVALUE;
    int _14988 = NOVALUE;
    int _14987 = NOVALUE;
    int _14986 = NOVALUE;
    int _14985 = NOVALUE;
    int _14984 = NOVALUE;
    int _14983 = NOVALUE;
    int _14982 = NOVALUE;
    int _14981 = NOVALUE;
    int _14980 = NOVALUE;
    int _14979 = NOVALUE;
    int _14978 = NOVALUE;
    int _14977 = NOVALUE;
    int _14976 = NOVALUE;
    int _14975 = NOVALUE;
    int _14974 = NOVALUE;
    int _14973 = NOVALUE;
    int _14972 = NOVALUE;
    int _14971 = NOVALUE;
    int _14970 = NOVALUE;
    int _14969 = NOVALUE;
    int _14968 = NOVALUE;
    int _14967 = NOVALUE;
    int _14966 = NOVALUE;
    int _14965 = NOVALUE;
    int _14964 = NOVALUE;
    int _14963 = NOVALUE;
    int _14962 = NOVALUE;
    int _14961 = NOVALUE;
    int _14960 = NOVALUE;
    int _14959 = NOVALUE;
    int _14958 = NOVALUE;
    int _14957 = NOVALUE;
    int _14956 = NOVALUE;
    int _14955 = NOVALUE;
    int _14954 = NOVALUE;
    int _14953 = NOVALUE;
    int _14952 = NOVALUE;
    int _14951 = NOVALUE;
    int _14950 = NOVALUE;
    int _14949 = NOVALUE;
    int _14948 = NOVALUE;
    int _14947 = NOVALUE;
    int _14946 = NOVALUE;
    int _14945 = NOVALUE;
    int _14944 = NOVALUE;
    int _14943 = NOVALUE;
    int _14942 = NOVALUE;
    int _14941 = NOVALUE;
    int _14940 = NOVALUE;
    int _14939 = NOVALUE;
    int _14938 = NOVALUE;
    int _14937 = NOVALUE;
    int _14936 = NOVALUE;
    int _14935 = NOVALUE;
    int _14934 = NOVALUE;
    int _14933 = NOVALUE;
    int _14932 = NOVALUE;
    int _14931 = NOVALUE;
    int _14930 = NOVALUE;
    int _14929 = NOVALUE;
    int _14928 = NOVALUE;
    int _14927 = NOVALUE;
    int _14925 = NOVALUE;
    int _14924 = NOVALUE;
    int _14923 = NOVALUE;
    int _14922 = NOVALUE;
    int _14921 = NOVALUE;
    int _14920 = NOVALUE;
    int _14919 = NOVALUE;
    int _14918 = NOVALUE;
    int _14917 = NOVALUE;
    int _14916 = NOVALUE;
    int _14915 = NOVALUE;
    int _14914 = NOVALUE;
    int _14913 = NOVALUE;
    int _14912 = NOVALUE;
    int _14911 = NOVALUE;
    int _14910 = NOVALUE;
    int _14909 = NOVALUE;
    int _14908 = NOVALUE;
    int _14907 = NOVALUE;
    int _14906 = NOVALUE;
    int _14905 = NOVALUE;
    int _14904 = NOVALUE;
    int _14903 = NOVALUE;
    int _14902 = NOVALUE;
    int _14901 = NOVALUE;
    int _14900 = NOVALUE;
    int _14899 = NOVALUE;
    int _14897 = NOVALUE;
    int _14896 = NOVALUE;
    int _14895 = NOVALUE;
    int _14894 = NOVALUE;
    int _14893 = NOVALUE;
    int _14892 = NOVALUE;
    int _14891 = NOVALUE;
    int _14890 = NOVALUE;
    int _14889 = NOVALUE;
    int _14888 = NOVALUE;
    int _14887 = NOVALUE;
    int _14886 = NOVALUE;
    int _14885 = NOVALUE;
    int _14884 = NOVALUE;
    int _14883 = NOVALUE;
    int _14882 = NOVALUE;
    int _14881 = NOVALUE;
    int _14880 = NOVALUE;
    int _14879 = NOVALUE;
    int _14878 = NOVALUE;
    int _14877 = NOVALUE;
    int _14876 = NOVALUE;
    int _14875 = NOVALUE;
    int _14874 = NOVALUE;
    int _14873 = NOVALUE;
    int _14872 = NOVALUE;
    int _14871 = NOVALUE;
    int _14870 = NOVALUE;
    int _14869 = NOVALUE;
    int _14868 = NOVALUE;
    int _14867 = NOVALUE;
    int _14866 = NOVALUE;
    int _14865 = NOVALUE;
    int _14864 = NOVALUE;
    int _14863 = NOVALUE;
    int _14862 = NOVALUE;
    int _14861 = NOVALUE;
    int _14860 = NOVALUE;
    int _14859 = NOVALUE;
    int _14858 = NOVALUE;
    int _14857 = NOVALUE;
    int _14856 = NOVALUE;
    int _14855 = NOVALUE;
    int _14854 = NOVALUE;
    int _14853 = NOVALUE;
    int _14852 = NOVALUE;
    int _14851 = NOVALUE;
    int _14850 = NOVALUE;
    int _14849 = NOVALUE;
    int _14848 = NOVALUE;
    int _14847 = NOVALUE;
    int _14846 = NOVALUE;
    int _14845 = NOVALUE;
    int _14844 = NOVALUE;
    int _14843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	op_info = repeat( 0, MAX_OPCODE )*/
    DeRef(_65op_info_26251);
    _65op_info_26251 = Repeat(0, 213);

    /** 	op_info[ABORT               ] = { FIXED_SIZE, 2, {}, {}, {} }   -- ary: pun*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14843 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 126);
    *(int *)_2 = _14843;
    if( _1 != _14843 ){
    }
    _14843 = NOVALUE;

    /** 	op_info[AND                 ] = { FIXED_SIZE, 4, {}, {}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14844 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _14844;
    if( _1 != _14844 ){
        DeRef(_1);
    }
    _14844 = NOVALUE;

    /** 	op_info[AND_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14845 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 56);
    _1 = *(int *)_2;
    *(int *)_2 = _14845;
    if( _1 != _14845 ){
        DeRef(_1);
    }
    _14845 = NOVALUE;

    /** 	op_info[APPEND              ] = { FIXED_SIZE, 4, {}, {3}, {} }   -- ary: bin*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14846 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _14846;
    if( _1 != _14846 ){
        DeRef(_1);
    }
    _14846 = NOVALUE;

    /** 	op_info[ARCTAN              ] = { FIXED_SIZE, 3, {}, {2}, {} }   -- ary: un*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14847 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 73);
    _1 = *(int *)_2;
    *(int *)_2 = _14847;
    if( _1 != _14847 ){
        DeRef(_1);
    }
    _14847 = NOVALUE;

    /** 	op_info[ASSIGN              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14848 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _14848;
    if( _1 != _14848 ){
        DeRef(_1);
    }
    _14848 = NOVALUE;

    /** 	op_info[ASSIGN_I            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14849 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 113);
    _1 = *(int *)_2;
    *(int *)_2 = _14849;
    if( _1 != _14849 ){
        DeRef(_1);
    }
    _14849 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SLICE     ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14850 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 150);
    _1 = *(int *)_2;
    *(int *)_2 = _14850;
    if( _1 != _14850 ){
        DeRef(_1);
    }
    _14850 = NOVALUE;

    /** 	op_info[ASSIGN_OP_SUBS      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14851 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 149);
    _1 = *(int *)_2;
    *(int *)_2 = _14851;
    if( _1 != _14851 ){
        DeRef(_1);
    }
    _14851 = NOVALUE;

    /** 	op_info[ASSIGN_SLICE        ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14852 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _14852;
    if( _1 != _14852 ){
        DeRef(_1);
    }
    _14852 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS         ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14853 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _14853;
    if( _1 != _14853 ){
        DeRef(_1);
    }
    _14853 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_CHECK   ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14854 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 84);
    _1 = *(int *)_2;
    *(int *)_2 = _14854;
    if( _1 != _14854 ){
        DeRef(_1);
    }
    _14854 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS_I       ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14855 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 118);
    _1 = *(int *)_2;
    *(int *)_2 = _14855;
    if( _1 != _14855 ){
        DeRef(_1);
    }
    _14855 = NOVALUE;

    /** 	op_info[BADRETURNF          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14856 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _14856;
    if( _1 != _14856 ){
        DeRef(_1);
    }
    _14856 = NOVALUE;

    /** 	op_info[CALL                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14857 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 129);
    _1 = *(int *)_2;
    *(int *)_2 = _14857;
    if( _1 != _14857 ){
        DeRef(_1);
    }
    _14857 = NOVALUE;

    /** 	op_info[CALL_PROC           ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14858 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 136);
    _1 = *(int *)_2;
    *(int *)_2 = _14858;
    if( _1 != _14858 ){
        DeRef(_1);
    }
    _14858 = NOVALUE;

    /** 	op_info[CALL_FUNC           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14859 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 137);
    _1 = *(int *)_2;
    *(int *)_2 = _14859;
    if( _1 != _14859 ){
        DeRef(_1);
    }
    _14859 = NOVALUE;

    /** 	op_info[CASE                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14860 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 186);
    _1 = *(int *)_2;
    *(int *)_2 = _14860;
    if( _1 != _14860 ){
        DeRef(_1);
    }
    _14860 = NOVALUE;

    /** 	op_info[CLEAR_SCREEN        ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14861 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 59);
    _1 = *(int *)_2;
    *(int *)_2 = _14861;
    if( _1 != _14861 ){
        DeRef(_1);
    }
    _14861 = NOVALUE;

    /** 	op_info[CLOSE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14862 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 86);
    _1 = *(int *)_2;
    *(int *)_2 = _14862;
    if( _1 != _14862 ){
        DeRef(_1);
    }
    _14862 = NOVALUE;

    /** 	op_info[COMMAND_LINE        ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14863 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 100);
    _1 = *(int *)_2;
    *(int *)_2 = _14863;
    if( _1 != _14863 ){
        DeRef(_1);
    }
    _14863 = NOVALUE;

    /** 	op_info[COMPARE             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14864 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 76);
    _1 = *(int *)_2;
    *(int *)_2 = _14864;
    if( _1 != _14864 ){
        DeRef(_1);
    }
    _14864 = NOVALUE;

    /** 	op_info[CONCAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14865 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _14865;
    if( _1 != _14865 ){
        DeRef(_1);
    }
    _14865 = NOVALUE;

    /** 	op_info[COS                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14866 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 81);
    _1 = *(int *)_2;
    *(int *)_2 = _14866;
    if( _1 != _14866 ){
        DeRef(_1);
    }
    _14866 = NOVALUE;

    /** 	op_info[COVERAGE_LINE       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14867 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 210);
    _1 = *(int *)_2;
    *(int *)_2 = _14867;
    if( _1 != _14867 ){
        DeRef(_1);
    }
    _14867 = NOVALUE;

    /** 	op_info[COVERAGE_ROUTINE    ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14868 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 211);
    _1 = *(int *)_2;
    *(int *)_2 = _14868;
    if( _1 != _14868 ){
        DeRef(_1);
    }
    _14868 = NOVALUE;

    /** 	op_info[C_FUNC              ] = { FIXED_SIZE, 5, {}, {4}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_13205);
    *((int *)(_2+20)) = _13205;
    _14869 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 133);
    _1 = *(int *)_2;
    *(int *)_2 = _14869;
    if( _1 != _14869 ){
        DeRef(_1);
    }
    _14869 = NOVALUE;

    /** 	op_info[C_PROC              ] = { FIXED_SIZE, 4, {}, {}, {3} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 2);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    RefDS(_13205);
    *((int *)(_2+20)) = _13205;
    _14870 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 132);
    _1 = *(int *)_2;
    *(int *)_2 = _14870;
    if( _1 != _14870 ){
        DeRef(_1);
    }
    _14870 = NOVALUE;

    /** 	op_info[DATE                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14871 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 69);
    _1 = *(int *)_2;
    *(int *)_2 = _14871;
    if( _1 != _14871 ){
        DeRef(_1);
    }
    _14871 = NOVALUE;

    /** 	op_info[DELETE_ROUTINE      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14872 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 204);
    _1 = *(int *)_2;
    *(int *)_2 = _14872;
    if( _1 != _14872 ){
        DeRef(_1);
    }
    _14872 = NOVALUE;

    /** 	op_info[DELETE_OBJECT       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14873 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 205);
    _1 = *(int *)_2;
    *(int *)_2 = _14873;
    if( _1 != _14873 ){
        DeRef(_1);
    }
    _14873 = NOVALUE;

    /** 	op_info[DIV2                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14874 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 98);
    _1 = *(int *)_2;
    *(int *)_2 = _14874;
    if( _1 != _14874 ){
        DeRef(_1);
    }
    _14874 = NOVALUE;

    /** 	op_info[DIVIDE              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14875 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _14875;
    if( _1 != _14875 ){
        DeRef(_1);
    }
    _14875 = NOVALUE;

    /** 	op_info[ELSE                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14876 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _14876;
    if( _1 != _14876 ){
        DeRef(_1);
    }
    _14876 = NOVALUE;

    /** 	op_info[EXIT                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14877 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 61);
    _1 = *(int *)_2;
    *(int *)_2 = _14877;
    if( _1 != _14877 ){
        DeRef(_1);
    }
    _14877 = NOVALUE;

    /** 	op_info[EXIT_BLOCK          ] = { FIXED_SIZE, 2, {},  {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14878 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 206);
    _1 = *(int *)_2;
    *(int *)_2 = _14878;
    if( _1 != _14878 ){
        DeRef(_1);
    }
    _14878 = NOVALUE;

    /** 	op_info[ENDWHILE            ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14879 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 22);
    _1 = *(int *)_2;
    *(int *)_2 = _14879;
    if( _1 != _14879 ){
        DeRef(_1);
    }
    _14879 = NOVALUE;

    /** 	op_info[RETRY               ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14880 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 184);
    _1 = *(int *)_2;
    *(int *)_2 = _14880;
    if( _1 != _14880 ){
        DeRef(_1);
    }
    _14880 = NOVALUE;

    /** 	op_info[GOTO                ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14881 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 188);
    _1 = *(int *)_2;
    *(int *)_2 = _14881;
    if( _1 != _14881 ){
        DeRef(_1);
    }
    _14881 = NOVALUE;

    /** 	op_info[ENDFOR_GENERAL      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14882 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _14882;
    if( _1 != _14882 ){
        DeRef(_1);
    }
    _14882 = NOVALUE;

    /** 	op_info[ENDFOR_UP           ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14883 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _14883;
    if( _1 != _14883 ){
        DeRef(_1);
    }
    _14883 = NOVALUE;

    /** 	op_info[ENDFOR_DOWN         ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14884 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 50);
    _1 = *(int *)_2;
    *(int *)_2 = _14884;
    if( _1 != _14884 ){
        DeRef(_1);
    }
    _14884 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP       ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14885 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _14885;
    if( _1 != _14885 ){
        DeRef(_1);
    }
    _14885 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN     ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14886 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _14886;
    if( _1 != _14886 ){
        DeRef(_1);
    }
    _14886 = NOVALUE;

    /** 	op_info[ENDFOR_INT_DOWN1    ] = { FIXED_SIZE, 4, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14887 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 55);
    _1 = *(int *)_2;
    *(int *)_2 = _14887;
    if( _1 != _14887 ){
        DeRef(_1);
    }
    _14887 = NOVALUE;

    /** 	op_info[ENDFOR_INT_UP1      ] = { FIXED_SIZE, 5, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14888 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _14888;
    if( _1 != _14888 ){
        DeRef(_1);
    }
    _14888 = NOVALUE;

    /** 	op_info[EQUAL               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14889 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 153);
    _1 = *(int *)_2;
    *(int *)_2 = _14889;
    if( _1 != _14889 ){
        DeRef(_1);
    }
    _14889 = NOVALUE;

    /** 	op_info[EQUALS              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14890 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _14890;
    if( _1 != _14890 ){
        DeRef(_1);
    }
    _14890 = NOVALUE;

    /** 	op_info[EQUALS_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14891 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 104);
    _1 = *(int *)_2;
    *(int *)_2 = _14891;
    if( _1 != _14891 ){
        DeRef(_1);
    }
    _14891 = NOVALUE;

    /** 	op_info[EQUALS_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14892 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 121);
    _1 = *(int *)_2;
    *(int *)_2 = _14892;
    if( _1 != _14892 ){
        DeRef(_1);
    }
    _14892 = NOVALUE;

    /** 	op_info[FIND                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14893 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 77);
    _1 = *(int *)_2;
    *(int *)_2 = _14893;
    if( _1 != _14893 ){
        DeRef(_1);
    }
    _14893 = NOVALUE;

    /** 	op_info[FIND_FROM           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14894 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 176);
    _1 = *(int *)_2;
    *(int *)_2 = _14894;
    if( _1 != _14894 ){
        DeRef(_1);
    }
    _14894 = NOVALUE;

    /** 	op_info[FLOOR               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14895 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 83);
    _1 = *(int *)_2;
    *(int *)_2 = _14895;
    if( _1 != _14895 ){
        DeRef(_1);
    }
    _14895 = NOVALUE;

    /** 	op_info[FLOOR_DIV           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14896 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 63);
    _1 = *(int *)_2;
    *(int *)_2 = _14896;
    if( _1 != _14896 ){
        DeRef(_1);
    }
    _14896 = NOVALUE;

    /** 	op_info[FLOOR_DIV2          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14897 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 66);
    _1 = *(int *)_2;
    *(int *)_2 = _14897;
    if( _1 != _14897 ){
        DeRef(_1);
    }
    _14897 = NOVALUE;

    /** 	op_info[FOR                 ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_14898);
    *((int *)(_2+12)) = _14898;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14899 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 21);
    _1 = *(int *)_2;
    *(int *)_2 = _14899;
    if( _1 != _14899 ){
        DeRef(_1);
    }
    _14899 = NOVALUE;

    /** 	op_info[FOR_I               ] = { FIXED_SIZE, 7, {6}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 7;
    RefDS(_14898);
    *((int *)(_2+12)) = _14898;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14900 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 125);
    _1 = *(int *)_2;
    *(int *)_2 = _14900;
    if( _1 != _14900 ){
        DeRef(_1);
    }
    _14900 = NOVALUE;

    /** 	op_info[GETC                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14901 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _14901;
    if( _1 != _14901 ){
        DeRef(_1);
    }
    _14901 = NOVALUE;

    /** 	op_info[GETENV              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14902 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 91);
    _1 = *(int *)_2;
    *(int *)_2 = _14902;
    if( _1 != _14902 ){
        DeRef(_1);
    }
    _14902 = NOVALUE;

    /** 	op_info[GETS                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14903 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _14903;
    if( _1 != _14903 ){
        DeRef(_1);
    }
    _14903 = NOVALUE;

    /** 	op_info[GET_KEY             ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14904 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 79);
    _1 = *(int *)_2;
    *(int *)_2 = _14904;
    if( _1 != _14904 ){
        DeRef(_1);
    }
    _14904 = NOVALUE;

    /** 	op_info[GLABEL              ] = { FIXED_SIZE, 2, {1}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_12887);
    *((int *)(_2+12)) = _12887;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14905 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 189);
    _1 = *(int *)_2;
    *(int *)_2 = _14905;
    if( _1 != _14905 ){
        DeRef(_1);
    }
    _14905 = NOVALUE;

    /** 	op_info[GLOBAL_INIT_CHECK   ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14906 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 109);
    _1 = *(int *)_2;
    *(int *)_2 = _14906;
    if( _1 != _14906 ){
        DeRef(_1);
    }
    _14906 = NOVALUE;

    /** 	op_info[PRIVATE_INIT_CHECK  ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14907 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _14907;
    if( _1 != _14907 ){
        DeRef(_1);
    }
    _14907 = NOVALUE;

    /** 	op_info[GREATER             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14908 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _14908;
    if( _1 != _14908 ){
        DeRef(_1);
    }
    _14908 = NOVALUE;

    /** 	op_info[GREATEREQ           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14909 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _14909;
    if( _1 != _14909 ){
        DeRef(_1);
    }
    _14909 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14910 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 103);
    _1 = *(int *)_2;
    *(int *)_2 = _14910;
    if( _1 != _14910 ){
        DeRef(_1);
    }
    _14910 = NOVALUE;

    /** 	op_info[GREATEREQ_IFW_I     ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14911 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 120);
    _1 = *(int *)_2;
    *(int *)_2 = _14911;
    if( _1 != _14911 ){
        DeRef(_1);
    }
    _14911 = NOVALUE;

    /** 	op_info[GREATER_IFW         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14912 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 107);
    _1 = *(int *)_2;
    *(int *)_2 = _14912;
    if( _1 != _14912 ){
        DeRef(_1);
    }
    _14912 = NOVALUE;

    /** 	op_info[GREATER_IFW_I       ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14913 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 124);
    _1 = *(int *)_2;
    *(int *)_2 = _14913;
    if( _1 != _14913 ){
        DeRef(_1);
    }
    _14913 = NOVALUE;

    /** 	op_info[HASH                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14914 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 194);
    _1 = *(int *)_2;
    *(int *)_2 = _14914;
    if( _1 != _14914 ){
        DeRef(_1);
    }
    _14914 = NOVALUE;

    /** 	op_info[HEAD                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14915 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 198);
    _1 = *(int *)_2;
    *(int *)_2 = _14915;
    if( _1 != _14915 ){
        DeRef(_1);
    }
    _14915 = NOVALUE;

    /** 	op_info[IF                  ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13268);
    *((int *)(_2+12)) = _13268;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14916 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 20);
    _1 = *(int *)_2;
    *(int *)_2 = _14916;
    if( _1 != _14916 ){
        DeRef(_1);
    }
    _14916 = NOVALUE;

    /** 	op_info[INSERT              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14917 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 191);
    _1 = *(int *)_2;
    *(int *)_2 = _14917;
    if( _1 != _14917 ){
        DeRef(_1);
    }
    _14917 = NOVALUE;

    /** 	op_info[LENGTH              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14918 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _14918;
    if( _1 != _14918 ){
        DeRef(_1);
    }
    _14918 = NOVALUE;

    /** 	op_info[LESS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14919 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _14919;
    if( _1 != _14919 ){
        DeRef(_1);
    }
    _14919 = NOVALUE;

    /** 	op_info[LESSEQ              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14920 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _14920;
    if( _1 != _14920 ){
        DeRef(_1);
    }
    _14920 = NOVALUE;

    /** 	op_info[LESSEQ_IFW          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14921 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 106);
    _1 = *(int *)_2;
    *(int *)_2 = _14921;
    if( _1 != _14921 ){
        DeRef(_1);
    }
    _14921 = NOVALUE;

    /** 	op_info[LESSEQ_IFW_I        ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14922 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 123);
    _1 = *(int *)_2;
    *(int *)_2 = _14922;
    if( _1 != _14922 ){
        DeRef(_1);
    }
    _14922 = NOVALUE;

    /** 	op_info[LESS_IFW            ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14923 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 102);
    _1 = *(int *)_2;
    *(int *)_2 = _14923;
    if( _1 != _14923 ){
        DeRef(_1);
    }
    _14923 = NOVALUE;

    /** 	op_info[LESS_IFW_I          ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14924 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 119);
    _1 = *(int *)_2;
    *(int *)_2 = _14924;
    if( _1 != _14924 ){
        DeRef(_1);
    }
    _14924 = NOVALUE;

    /** 	op_info[LHS_SUBS            ] = { FIXED_SIZE, 5, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14925 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 95);
    _1 = *(int *)_2;
    *(int *)_2 = _14925;
    if( _1 != _14925 ){
        DeRef(_1);
    }
    _14925 = NOVALUE;

    /** 	op_info[LHS_SUBS1           ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_14926);
    *((int *)(_2+16)) = _14926;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14927 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 161);
    _1 = *(int *)_2;
    *(int *)_2 = _14927;
    if( _1 != _14927 ){
        DeRef(_1);
    }
    _14927 = NOVALUE;

    /** 	op_info[LHS_SUBS1_COPY      ] = { FIXED_SIZE, 5, {}, {3,4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_14926);
    *((int *)(_2+16)) = _14926;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14928 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 166);
    _1 = *(int *)_2;
    *(int *)_2 = _14928;
    if( _1 != _14928 ){
        DeRef(_1);
    }
    _14928 = NOVALUE;

    /** 	op_info[LOG                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14929 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 74);
    _1 = *(int *)_2;
    *(int *)_2 = _14929;
    if( _1 != _14929 ){
        DeRef(_1);
    }
    _14929 = NOVALUE;

    /** 	op_info[MACHINE_FUNC        ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14930 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 111);
    _1 = *(int *)_2;
    *(int *)_2 = _14930;
    if( _1 != _14930 ){
        DeRef(_1);
    }
    _14930 = NOVALUE;

    /** 	op_info[MACHINE_PROC        ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14931 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 112);
    _1 = *(int *)_2;
    *(int *)_2 = _14931;
    if( _1 != _14931 ){
        DeRef(_1);
    }
    _14931 = NOVALUE;

    /** 	op_info[MATCH               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14932 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 78);
    _1 = *(int *)_2;
    *(int *)_2 = _14932;
    if( _1 != _14932 ){
        DeRef(_1);
    }
    _14932 = NOVALUE;

    /** 	op_info[MATCH_FROM          ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14933 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 177);
    _1 = *(int *)_2;
    *(int *)_2 = _14933;
    if( _1 != _14933 ){
        DeRef(_1);
    }
    _14933 = NOVALUE;

    /** 	op_info[MEM_COPY            ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14934 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 130);
    _1 = *(int *)_2;
    *(int *)_2 = _14934;
    if( _1 != _14934 ){
        DeRef(_1);
    }
    _14934 = NOVALUE;

    /** 	op_info[MEM_SET             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14935 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 131);
    _1 = *(int *)_2;
    *(int *)_2 = _14935;
    if( _1 != _14935 ){
        DeRef(_1);
    }
    _14935 = NOVALUE;

    /** 	op_info[MINUS               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14936 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _14936;
    if( _1 != _14936 ){
        DeRef(_1);
    }
    _14936 = NOVALUE;

    /** 	op_info[MINUS_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14937 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 116);
    _1 = *(int *)_2;
    *(int *)_2 = _14937;
    if( _1 != _14937 ){
        DeRef(_1);
    }
    _14937 = NOVALUE;

    /** 	op_info[MULTIPLY            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14938 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _14938;
    if( _1 != _14938 ){
        DeRef(_1);
    }
    _14938 = NOVALUE;

    /** 	op_info[NOP1                ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14939 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 159);
    _1 = *(int *)_2;
    *(int *)_2 = _14939;
    if( _1 != _14939 ){
        DeRef(_1);
    }
    _14939 = NOVALUE;

    /** 	op_info[NOPWHILE            ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14940 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 158);
    _1 = *(int *)_2;
    *(int *)_2 = _14940;
    if( _1 != _14940 ){
        DeRef(_1);
    }
    _14940 = NOVALUE;

    /** 	op_info[NOP2                ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14941 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 110);
    _1 = *(int *)_2;
    *(int *)_2 = _14941;
    if( _1 != _14941 ){
        DeRef(_1);
    }
    _14941 = NOVALUE;

    /** 	op_info[SC2_NULL            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14942 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 145);
    _1 = *(int *)_2;
    *(int *)_2 = _14942;
    if( _1 != _14942 ){
        DeRef(_1);
    }
    _14942 = NOVALUE;

    /** 	op_info[ASSIGN_SUBS2        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14943 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 148);
    _1 = *(int *)_2;
    *(int *)_2 = _14943;
    if( _1 != _14943 ){
        DeRef(_1);
    }
    _14943 = NOVALUE;

    /** 	op_info[PLATFORM            ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14944 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 155);
    _1 = *(int *)_2;
    *(int *)_2 = _14944;
    if( _1 != _14944 ){
        DeRef(_1);
    }
    _14944 = NOVALUE;

    /** 	op_info[END_PARAM_CHECK     ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14945 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 156);
    _1 = *(int *)_2;
    *(int *)_2 = _14945;
    if( _1 != _14945 ){
        DeRef(_1);
    }
    _14945 = NOVALUE;

    /** 	op_info[NOPSWITCH           ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14946 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 187);
    _1 = *(int *)_2;
    *(int *)_2 = _14946;
    if( _1 != _14946 ){
        DeRef(_1);
    }
    _14946 = NOVALUE;

    /** 	op_info[NOT                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14947 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _14947;
    if( _1 != _14947 ){
        DeRef(_1);
    }
    _14947 = NOVALUE;

    /** 	op_info[NOTEQ               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14948 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _14948;
    if( _1 != _14948 ){
        DeRef(_1);
    }
    _14948 = NOVALUE;

    /** 	op_info[NOTEQ_IFW           ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14949 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 105);
    _1 = *(int *)_2;
    *(int *)_2 = _14949;
    if( _1 != _14949 ){
        DeRef(_1);
    }
    _14949 = NOVALUE;

    /** 	op_info[NOTEQ_IFW_I         ] = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14950 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 122);
    _1 = *(int *)_2;
    *(int *)_2 = _14950;
    if( _1 != _14950 ){
        DeRef(_1);
    }
    _14950 = NOVALUE;

    /** 	op_info[NOT_BITS            ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14951 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _14951;
    if( _1 != _14951 ){
        DeRef(_1);
    }
    _14951 = NOVALUE;

    /** 	op_info[NOT_IFW             ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13268);
    *((int *)(_2+12)) = _13268;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14952 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 108);
    _1 = *(int *)_2;
    *(int *)_2 = _14952;
    if( _1 != _14952 ){
        DeRef(_1);
    }
    _14952 = NOVALUE;

    /** 	op_info[OPEN                ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14953 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 37);
    _1 = *(int *)_2;
    *(int *)_2 = _14953;
    if( _1 != _14953 ){
        DeRef(_1);
    }
    _14953 = NOVALUE;

    /** 	op_info[OPTION_SWITCHES     ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14954 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 183);
    _1 = *(int *)_2;
    *(int *)_2 = _14954;
    if( _1 != _14954 ){
        DeRef(_1);
    }
    _14954 = NOVALUE;

    /** 	op_info[OR                  ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14955 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _14955;
    if( _1 != _14955 ){
        DeRef(_1);
    }
    _14955 = NOVALUE;

    /** 	op_info[OR_BITS             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14956 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _14956;
    if( _1 != _14956 ){
        DeRef(_1);
    }
    _14956 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SLICE    ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14957 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 165);
    _1 = *(int *)_2;
    *(int *)_2 = _14957;
    if( _1 != _14957 ){
        DeRef(_1);
    }
    _14957 = NOVALUE;

    /** 	op_info[PASSIGN_OP_SUBS     ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14958 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 164);
    _1 = *(int *)_2;
    *(int *)_2 = _14958;
    if( _1 != _14958 ){
        DeRef(_1);
    }
    _14958 = NOVALUE;

    /** 	op_info[PASSIGN_SLICE       ] = { FIXED_SIZE, 5, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14959 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 163);
    _1 = *(int *)_2;
    *(int *)_2 = _14959;
    if( _1 != _14959 ){
        DeRef(_1);
    }
    _14959 = NOVALUE;

    /** 	op_info[PASSIGN_SUBS        ] = { FIXED_SIZE, 4, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14960 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 162);
    _1 = *(int *)_2;
    *(int *)_2 = _14960;
    if( _1 != _14960 ){
        DeRef(_1);
    }
    _14960 = NOVALUE;

    /** 	op_info[PEEK_STRING         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14961 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 182);
    _1 = *(int *)_2;
    *(int *)_2 = _14961;
    if( _1 != _14961 ){
        DeRef(_1);
    }
    _14961 = NOVALUE;

    /** 	op_info[PEEK2U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14962 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 180);
    _1 = *(int *)_2;
    *(int *)_2 = _14962;
    if( _1 != _14962 ){
        DeRef(_1);
    }
    _14962 = NOVALUE;

    /** 	op_info[PEEK2S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14963 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 179);
    _1 = *(int *)_2;
    *(int *)_2 = _14963;
    if( _1 != _14963 ){
        DeRef(_1);
    }
    _14963 = NOVALUE;

    /** 	op_info[PEEK4U              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14964 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 140);
    _1 = *(int *)_2;
    *(int *)_2 = _14964;
    if( _1 != _14964 ){
        DeRef(_1);
    }
    _14964 = NOVALUE;

    /** 	op_info[PEEK4S              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14965 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 139);
    _1 = *(int *)_2;
    *(int *)_2 = _14965;
    if( _1 != _14965 ){
        DeRef(_1);
    }
    _14965 = NOVALUE;

    /** 	op_info[PEEKS               ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14966 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 181);
    _1 = *(int *)_2;
    *(int *)_2 = _14966;
    if( _1 != _14966 ){
        DeRef(_1);
    }
    _14966 = NOVALUE;

    /** 	op_info[PEEK                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14967 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 127);
    _1 = *(int *)_2;
    *(int *)_2 = _14967;
    if( _1 != _14967 ){
        DeRef(_1);
    }
    _14967 = NOVALUE;

    /** 	op_info[PLENGTH             ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14968 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 160);
    _1 = *(int *)_2;
    *(int *)_2 = _14968;
    if( _1 != _14968 ){
        DeRef(_1);
    }
    _14968 = NOVALUE;

    /** 	op_info[PLUS                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14969 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _14969;
    if( _1 != _14969 ){
        DeRef(_1);
    }
    _14969 = NOVALUE;

    /** 	op_info[PLUS_I              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14970 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 115);
    _1 = *(int *)_2;
    *(int *)_2 = _14970;
    if( _1 != _14970 ){
        DeRef(_1);
    }
    _14970 = NOVALUE;

    /** 	op_info[PLUS1               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14971 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 93);
    _1 = *(int *)_2;
    *(int *)_2 = _14971;
    if( _1 != _14971 ){
        DeRef(_1);
    }
    _14971 = NOVALUE;

    /** 	op_info[PLUS1_I             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14972 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 117);
    _1 = *(int *)_2;
    *(int *)_2 = _14972;
    if( _1 != _14972 ){
        DeRef(_1);
    }
    _14972 = NOVALUE;

    /** 	op_info[POKE                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14973 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 128);
    _1 = *(int *)_2;
    *(int *)_2 = _14973;
    if( _1 != _14973 ){
        DeRef(_1);
    }
    _14973 = NOVALUE;

    /** 	op_info[POKE2               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14974 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 178);
    _1 = *(int *)_2;
    *(int *)_2 = _14974;
    if( _1 != _14974 ){
        DeRef(_1);
    }
    _14974 = NOVALUE;

    /** 	op_info[POKE4               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14975 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 138);
    _1 = *(int *)_2;
    *(int *)_2 = _14975;
    if( _1 != _14975 ){
        DeRef(_1);
    }
    _14975 = NOVALUE;

    /** 	op_info[POSITION            ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14976 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 60);
    _1 = *(int *)_2;
    *(int *)_2 = _14976;
    if( _1 != _14976 ){
        DeRef(_1);
    }
    _14976 = NOVALUE;

    /** 	op_info[POWER               ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14977 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 72);
    _1 = *(int *)_2;
    *(int *)_2 = _14977;
    if( _1 != _14977 ){
        DeRef(_1);
    }
    _14977 = NOVALUE;

    /** 	op_info[PREPEND             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14978 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 57);
    _1 = *(int *)_2;
    *(int *)_2 = _14978;
    if( _1 != _14978 ){
        DeRef(_1);
    }
    _14978 = NOVALUE;

    /** 	op_info[PRINT               ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14979 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _14979;
    if( _1 != _14979 ){
        DeRef(_1);
    }
    _14979 = NOVALUE;

    /** 	op_info[PRINTF              ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14980 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _14980;
    if( _1 != _14980 ){
        DeRef(_1);
    }
    _14980 = NOVALUE;

    /** 	op_info[PROFILE             ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14981 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 151);
    _1 = *(int *)_2;
    *(int *)_2 = _14981;
    if( _1 != _14981 ){
        DeRef(_1);
    }
    _14981 = NOVALUE;

    /** 	op_info[DISPLAY_VAR         ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14982 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 87);
    _1 = *(int *)_2;
    *(int *)_2 = _14982;
    if( _1 != _14982 ){
        DeRef(_1);
    }
    _14982 = NOVALUE;

    /** 	op_info[ERASE_PRIVATE_NAMES ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14983 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 88);
    _1 = *(int *)_2;
    *(int *)_2 = _14983;
    if( _1 != _14983 ){
        DeRef(_1);
    }
    _14983 = NOVALUE;

    /** 	op_info[ERASE_SYMBOL        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14984 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 90);
    _1 = *(int *)_2;
    *(int *)_2 = _14984;
    if( _1 != _14984 ){
        DeRef(_1);
    }
    _14984 = NOVALUE;

    /** 	op_info[PUTS                ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14985 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = _14985;
    if( _1 != _14985 ){
        DeRef(_1);
    }
    _14985 = NOVALUE;

    /** 	op_info[QPRINT              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14986 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _14986;
    if( _1 != _14986 ){
        DeRef(_1);
    }
    _14986 = NOVALUE;

    /** 	op_info[RAND                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14987 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 62);
    _1 = *(int *)_2;
    *(int *)_2 = _14987;
    if( _1 != _14987 ){
        DeRef(_1);
    }
    _14987 = NOVALUE;

    /** 	op_info[REMAINDER           ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14988 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 71);
    _1 = *(int *)_2;
    *(int *)_2 = _14988;
    if( _1 != _14988 ){
        DeRef(_1);
    }
    _14988 = NOVALUE;

    /** 	op_info[REMOVE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14989 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 200);
    _1 = *(int *)_2;
    *(int *)_2 = _14989;
    if( _1 != _14989 ){
        DeRef(_1);
    }
    _14989 = NOVALUE;

    /** 	op_info[REPEAT              ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14990 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _14990;
    if( _1 != _14990 ){
        DeRef(_1);
    }
    _14990 = NOVALUE;

    /** 	op_info[REPLACE             ] = { FIXED_SIZE, 6, {}, {5}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 6;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12916);
    *((int *)(_2+16)) = _12916;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14991 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 201);
    _1 = *(int *)_2;
    *(int *)_2 = _14991;
    if( _1 != _14991 ){
        DeRef(_1);
    }
    _14991 = NOVALUE;

    /** 	op_info[RETURNF             ] = { FIXED_SIZE, 4, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14992 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _14992;
    if( _1 != _14992 ){
        DeRef(_1);
    }
    _14992 = NOVALUE;

    /** 	op_info[RETURNP             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14993 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 29);
    _1 = *(int *)_2;
    *(int *)_2 = _14993;
    if( _1 != _14993 ){
        DeRef(_1);
    }
    _14993 = NOVALUE;

    /** 	op_info[RETURNT             ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _14994 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _14994;
    if( _1 != _14994 ){
        DeRef(_1);
    }
    _14994 = NOVALUE;

    /** 	op_info[RHS_SLICE           ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14995 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = _14995;
    if( _1 != _14995 ){
        DeRef(_1);
    }
    _14995 = NOVALUE;

    /** 	op_info[RHS_SUBS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14996 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _14996;
    if( _1 != _14996 ){
        DeRef(_1);
    }
    _14996 = NOVALUE;

    /** 	op_info[RHS_SUBS_I          ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14997 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 114);
    _1 = *(int *)_2;
    *(int *)_2 = _14997;
    if( _1 != _14997 ){
        DeRef(_1);
    }
    _14997 = NOVALUE;

    /** 	op_info[RHS_SUBS_CHECK      ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14998 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 92);
    _1 = *(int *)_2;
    *(int *)_2 = _14998;
    if( _1 != _14998 ){
        DeRef(_1);
    }
    _14998 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_2       ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _14999 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 85);
    _1 = *(int *)_2;
    *(int *)_2 = _14999;
    if( _1 != _14999 ){
        DeRef(_1);
    }
    _14999 = NOVALUE;

    /** 	op_info[ROUTINE_ID          ] = { FIXED_SIZE, 6 - TRANSLATE, {}, { 4 + not TRANSLATE }, {} }*/
    _15000 = 6 - _35TRANSLATE_15611;
    _15001 = (_35TRANSLATE_15611 == 0);
    _15002 = 4 + _15001;
    if ((long)((unsigned long)_15002 + (unsigned long)HIGH_BITS) >= 0) 
    _15002 = NewDouble((double)_15002);
    _15001 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _15002;
    _15003 = MAKE_SEQ(_1);
    _15002 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _15000;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _15003;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15004 = MAKE_SEQ(_1);
    _15003 = NOVALUE;
    _15000 = NOVALUE;
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 134);
    _1 = *(int *)_2;
    *(int *)_2 = _15004;
    if( _1 != _15004 ){
        DeRef(_1);
    }
    _15004 = NOVALUE;

    /** 	op_info[SC2_OR              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15005 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 144);
    _1 = *(int *)_2;
    *(int *)_2 = _15005;
    if( _1 != _15005 ){
        DeRef(_1);
    }
    _15005 = NOVALUE;

    /** 	op_info[SC2_AND             ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15006 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 142);
    _1 = *(int *)_2;
    *(int *)_2 = _15006;
    if( _1 != _15006 ){
        DeRef(_1);
    }
    _15006 = NOVALUE;

    /** 	op_info[SIN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15007 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 80);
    _1 = *(int *)_2;
    *(int *)_2 = _15007;
    if( _1 != _15007 ){
        DeRef(_1);
    }
    _15007 = NOVALUE;

    /** 	op_info[SPACE_USED          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15008 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 75);
    _1 = *(int *)_2;
    *(int *)_2 = _15008;
    if( _1 != _15008 ){
        DeRef(_1);
    }
    _15008 = NOVALUE;

    /** 	op_info[SPLICE              ] = { FIXED_SIZE, 5, {}, {4}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13428);
    *((int *)(_2+16)) = _13428;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15009 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 190);
    _1 = *(int *)_2;
    *(int *)_2 = _15009;
    if( _1 != _15009 ){
        DeRef(_1);
    }
    _15009 = NOVALUE;

    /** 	op_info[SPRINTF             ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15010 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = _15010;
    if( _1 != _15010 ){
        DeRef(_1);
    }
    _15010 = NOVALUE;

    /** 	op_info[SQRT                ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15011 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _15011;
    if( _1 != _15011 ){
        DeRef(_1);
    }
    _15011 = NOVALUE;

    /** 	op_info[STARTLINE           ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15012 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 58);
    _1 = *(int *)_2;
    *(int *)_2 = _15012;
    if( _1 != _15012 ){
        DeRef(_1);
    }
    _15012 = NOVALUE;

    /** 	op_info[SWITCH              ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13428);
    *((int *)(_2+12)) = _13428;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15013 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 185);
    _1 = *(int *)_2;
    *(int *)_2 = _15013;
    if( _1 != _15013 ){
        DeRef(_1);
    }
    _15013 = NOVALUE;

    /** 	op_info[SWITCH_I            ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13428);
    *((int *)(_2+12)) = _13428;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15014 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 193);
    _1 = *(int *)_2;
    *(int *)_2 = _15014;
    if( _1 != _15014 ){
        DeRef(_1);
    }
    _15014 = NOVALUE;

    /** 	op_info[SWITCH_SPI          ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13428);
    *((int *)(_2+12)) = _13428;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15015 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 192);
    _1 = *(int *)_2;
    *(int *)_2 = _15015;
    if( _1 != _15015 ){
        DeRef(_1);
    }
    _15015 = NOVALUE;

    /** 	op_info[SWITCH_RT           ] = { FIXED_SIZE, 5, {4}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 5;
    RefDS(_13428);
    *((int *)(_2+12)) = _13428;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15016 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 202);
    _1 = *(int *)_2;
    *(int *)_2 = _15016;
    if( _1 != _15016 ){
        DeRef(_1);
    }
    _15016 = NOVALUE;

    /** 	op_info[SYSTEM              ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15017 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 99);
    _1 = *(int *)_2;
    *(int *)_2 = _15017;
    if( _1 != _15017 ){
        DeRef(_1);
    }
    _15017 = NOVALUE;

    /** 	op_info[SYSTEM_EXEC         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15018 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 154);
    _1 = *(int *)_2;
    *(int *)_2 = _15018;
    if( _1 != _15018 ){
        DeRef(_1);
    }
    _15018 = NOVALUE;

    /** 	op_info[TAIL                ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15019 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 199);
    _1 = *(int *)_2;
    *(int *)_2 = _15019;
    if( _1 != _15019 ){
        DeRef(_1);
    }
    _15019 = NOVALUE;

    /** 	op_info[TAN                 ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15020 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 82);
    _1 = *(int *)_2;
    *(int *)_2 = _15020;
    if( _1 != _15020 ){
        DeRef(_1);
    }
    _15020 = NOVALUE;

    /** 	op_info[TASK_CLOCK_START    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15021 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 175);
    _1 = *(int *)_2;
    *(int *)_2 = _15021;
    if( _1 != _15021 ){
        DeRef(_1);
    }
    _15021 = NOVALUE;

    /** 	op_info[TASK_CLOCK_STOP     ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15022 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 174);
    _1 = *(int *)_2;
    *(int *)_2 = _15022;
    if( _1 != _15022 ){
        DeRef(_1);
    }
    _15022 = NOVALUE;

    /** 	op_info[TASK_CREATE         ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15023 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 167);
    _1 = *(int *)_2;
    *(int *)_2 = _15023;
    if( _1 != _15023 ){
        DeRef(_1);
    }
    _15023 = NOVALUE;

    /** 	op_info[TASK_LIST           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15024 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 172);
    _1 = *(int *)_2;
    *(int *)_2 = _15024;
    if( _1 != _15024 ){
        DeRef(_1);
    }
    _15024 = NOVALUE;

    /** 	op_info[TASK_SCHEDULE       ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15025 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 168);
    _1 = *(int *)_2;
    *(int *)_2 = _15025;
    if( _1 != _15025 ){
        DeRef(_1);
    }
    _15025 = NOVALUE;

    /** 	op_info[TASK_SELF           ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15026 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 170);
    _1 = *(int *)_2;
    *(int *)_2 = _15026;
    if( _1 != _15026 ){
        DeRef(_1);
    }
    _15026 = NOVALUE;

    /** 	op_info[TASK_STATUS         ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15027 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 173);
    _1 = *(int *)_2;
    *(int *)_2 = _15027;
    if( _1 != _15027 ){
        DeRef(_1);
    }
    _15027 = NOVALUE;

    /** 	op_info[TASK_SUSPEND        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15028 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 171);
    _1 = *(int *)_2;
    *(int *)_2 = _15028;
    if( _1 != _15028 ){
        DeRef(_1);
    }
    _15028 = NOVALUE;

    /** 	op_info[TASK_YIELD          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15029 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 169);
    _1 = *(int *)_2;
    *(int *)_2 = _15029;
    if( _1 != _15029 ){
        DeRef(_1);
    }
    _15029 = NOVALUE;

    /** 	op_info[TIME                ] = { FIXED_SIZE, 2, {}, {1}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_12887);
    *((int *)(_2+16)) = _12887;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15030 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 70);
    _1 = *(int *)_2;
    *(int *)_2 = _15030;
    if( _1 != _15030 ){
        DeRef(_1);
    }
    _15030 = NOVALUE;

    /** 	op_info[TRACE               ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15031 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 64);
    _1 = *(int *)_2;
    *(int *)_2 = _15031;
    if( _1 != _15031 ){
        DeRef(_1);
    }
    _15031 = NOVALUE;

    /** 	op_info[TYPE_CHECK          ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15032 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 65);
    _1 = *(int *)_2;
    *(int *)_2 = _15032;
    if( _1 != _15032 ){
        DeRef(_1);
    }
    _15032 = NOVALUE;

    /** 	op_info[UMINUS              ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15033 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _15033;
    if( _1 != _15033 ){
        DeRef(_1);
    }
    _15033 = NOVALUE;

    /** 	op_info[UPDATE_GLOBALS      ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15034 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 89);
    _1 = *(int *)_2;
    *(int *)_2 = _15034;
    if( _1 != _15034 ){
        DeRef(_1);
    }
    _15034 = NOVALUE;

    /** 	op_info[WHILE               ] = { FIXED_SIZE, 3, {2}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_13268);
    *((int *)(_2+12)) = _13268;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15035 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _15035;
    if( _1 != _15035 ){
        DeRef(_1);
    }
    _15035 = NOVALUE;

    /** 	op_info[XOR                 ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15036 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 152);
    _1 = *(int *)_2;
    *(int *)_2 = _15036;
    if( _1 != _15036 ){
        DeRef(_1);
    }
    _15036 = NOVALUE;

    /** 	op_info[XOR_BITS            ] = { FIXED_SIZE, 4, {}, {3}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13205);
    *((int *)(_2+16)) = _13205;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15037 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _15037;
    if( _1 != _15037 ){
        DeRef(_1);
    }
    _15037 = NOVALUE;

    /** 	op_info[TYPE_CHECK_FORWARD  ] = { FIXED_SIZE, 3, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15038 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 197);
    _1 = *(int *)_2;
    *(int *)_2 = _15038;
    if( _1 != _15038 ){
        DeRef(_1);
    }
    _15038 = NOVALUE;

    /** 	sequence SHORT_CIRCUIT = { FIXED_SIZE, 4, {3}, {}, {} }*/
    _0 = _SHORT_CIRCUIT_26649;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 4;
    RefDS(_13205);
    *((int *)(_2+12)) = _13205;
    RefDSn(_5, 2);
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _SHORT_CIRCUIT_26649 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	op_info[SC1_AND_IF          ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26649);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 146);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26649;
    DeRef(_1);

    /** 	op_info[SC1_OR_IF           ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26649);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 147);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26649;
    DeRef(_1);

    /** 	op_info[SC1_AND             ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26649);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 141);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26649;
    DeRef(_1);

    /** 	op_info[SC1_OR              ] = SHORT_CIRCUIT*/
    RefDS(_SHORT_CIRCUIT_26649);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 143);
    _1 = *(int *)_2;
    *(int *)_2 = _SHORT_CIRCUIT_26649;
    DeRef(_1);

    /** 	op_info[ATOM_CHECK          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15040 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 101);
    _1 = *(int *)_2;
    *(int *)_2 = _15040;
    if( _1 != _15040 ){
        DeRef(_1);
    }
    _15040 = NOVALUE;

    /** 	op_info[INTEGER_CHECK       ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15041 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 96);
    _1 = *(int *)_2;
    *(int *)_2 = _15041;
    if( _1 != _15041 ){
        DeRef(_1);
    }
    _15041 = NOVALUE;

    /** 	op_info[SEQUENCE_CHECK      ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15042 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 97);
    _1 = *(int *)_2;
    *(int *)_2 = _15042;
    if( _1 != _15042 ){
        DeRef(_1);
    }
    _15042 = NOVALUE;

    /** 	op_info[IS_AN_INTEGER       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15043 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 94);
    _1 = *(int *)_2;
    *(int *)_2 = _15043;
    if( _1 != _15043 ){
        DeRef(_1);
    }
    _15043 = NOVALUE;

    /** 	op_info[IS_AN_ATOM          ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15044 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 67);
    _1 = *(int *)_2;
    *(int *)_2 = _15044;
    if( _1 != _15044 ){
        DeRef(_1);
    }
    _15044 = NOVALUE;

    /** 	op_info[IS_A_SEQUENCE       ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15045 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 68);
    _1 = *(int *)_2;
    *(int *)_2 = _15045;
    if( _1 != _15045 ){
        DeRef(_1);
    }
    _15045 = NOVALUE;

    /** 	op_info[IS_AN_OBJECT        ] = { FIXED_SIZE, 3, {}, {2}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 3;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    RefDS(_13268);
    *((int *)(_2+16)) = _13268;
    RefDS(_5);
    *((int *)(_2+20)) = _5;
    _15046 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _15046;
    if( _1 != _15046 ){
        DeRef(_1);
    }
    _15046 = NOVALUE;

    /** 	op_info[CALL_BACK_RETURN    ] = { FIXED_SIZE, 1, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 1;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15047 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 135);
    _1 = *(int *)_2;
    *(int *)_2 = _15047;
    if( _1 != _15047 ){
        DeRef(_1);
    }
    _15047 = NOVALUE;

    /** 	op_info[REF_TEMP            ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15048 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 207);
    _1 = *(int *)_2;
    *(int *)_2 = _15048;
    if( _1 != _15048 ){
        DeRef(_1);
    }
    _15048 = NOVALUE;

    /** 	op_info[DEREF_TEMP          ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15049 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 208);
    _1 = *(int *)_2;
    *(int *)_2 = _15049;
    if( _1 != _15049 ){
        DeRef(_1);
    }
    _15049 = NOVALUE;

    /** 	op_info[NOVALUE_TEMP        ] = { FIXED_SIZE, 2, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15050 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 209);
    _1 = *(int *)_2;
    *(int *)_2 = _15050;
    if( _1 != _15050 ){
        DeRef(_1);
    }
    _15050 = NOVALUE;

    /** 	op_info[PROC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15051 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 195);
    _1 = *(int *)_2;
    *(int *)_2 = _15051;
    if( _1 != _15051 ){
        DeRef(_1);
    }
    _15051 = NOVALUE;

    /** 	op_info[FUNC_FORWARD        ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15052 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 196);
    _1 = *(int *)_2;
    *(int *)_2 = _15052;
    if( _1 != _15052 ){
        DeRef(_1);
    }
    _15052 = NOVALUE;

    /** 	op_info[RIGHT_BRACE_N       ] = { VARIABLE_SIZE, 3, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 3;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15053 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _15053;
    if( _1 != _15053 ){
        DeRef(_1);
    }
    _15053 = NOVALUE;

    /** 	op_info[CONCAT_N            ] = { VARIABLE_SIZE, 0, {}, {}, {} } -- target: [pc+1] + 2*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15054 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 157);
    _1 = *(int *)_2;
    *(int *)_2 = _15054;
    if( _1 != _15054 ){
        DeRef(_1);
    }
    _15054 = NOVALUE;

    /** 	op_info[PROC                ] = { VARIABLE_SIZE, 0, {}, {}, {} }*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    RefDSn(_5, 3);
    *((int *)(_2+12)) = _5;
    *((int *)(_2+16)) = _5;
    *((int *)(_2+20)) = _5;
    _15055 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 27);
    _1 = *(int *)_2;
    *(int *)_2 = _15055;
    if( _1 != _15055 ){
        DeRef(_1);
    }
    _15055 = NOVALUE;

    /** 	op_info[PROC_TAIL           ] = op_info[PROC]*/
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _15056 = (int)*(((s1_ptr)_2)->base + 27);
    Ref(_15056);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _65op_info_26251 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 203);
    _1 = *(int *)_2;
    *(int *)_2 = _15056;
    if( _1 != _15056 ){
        DeRef(_1);
    }
    _15056 = NOVALUE;

    /** end procedure*/
    DeRefDS(_SHORT_CIRCUIT_26649);
    return;
    ;
}


int _65op_size(int _pc_26692, int _code_26693)
{
    int _op_26696 = NOVALUE;
    int _info_26698 = NOVALUE;
    int _int_26700 = NOVALUE;
    int _15081 = NOVALUE;
    int _15078 = NOVALUE;
    int _15075 = NOVALUE;
    int _15072 = NOVALUE;
    int _15071 = NOVALUE;
    int _15070 = NOVALUE;
    int _15069 = NOVALUE;
    int _15068 = NOVALUE;
    int _15067 = NOVALUE;
    int _15065 = NOVALUE;
    int _15064 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer op = code[pc]*/
    _2 = (int)SEQ_PTR(_code_26693);
    _op_26696 = (int)*(((s1_ptr)_2)->base + _pc_26692);
    if (!IS_ATOM_INT(_op_26696))
    _op_26696 = (long)DBL_PTR(_op_26696)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_26698);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _info_26698 = (int)*(((s1_ptr)_2)->base + _op_26696);
    Ref(_info_26698);

    /** 	integer int = info[OP_SIZE_TYPE]*/
    _2 = (int)SEQ_PTR(_info_26698);
    _int_26700 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_26700))
    _int_26700 = (long)DBL_PTR(_int_26700)->dbl;

    /** 	if int = FIXED_SIZE then*/
    if (_int_26700 != 1)
    goto L1; // [29] 48

    /** 		int = info[OP_SIZE]*/
    _2 = (int)SEQ_PTR(_info_26698);
    _int_26700 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_26700))
    _int_26700 = (long)DBL_PTR(_int_26700)->dbl;

    /** 		return int*/
    DeRefDS(_code_26693);
    DeRefDS(_info_26698);
    return _int_26700;
    goto L2; // [45] 203
L1: 

    /** 		switch op do*/
    _0 = _op_26696;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				info = SymTab[code[pc+1]]*/
        _15064 = _pc_26692 + 1;
        _2 = (int)SEQ_PTR(_code_26693);
        _15065 = (int)*(((s1_ptr)_2)->base + _15064);
        DeRef(_info_26698);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_15065)){
            _info_26698 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15065)->dbl));
        }
        else{
            _info_26698 = (int)*(((s1_ptr)_2)->base + _15065);
        }
        Ref(_info_26698);

        /** 				return info[S_NUM_ARGS] + 2 + (info[S_TOKEN] != PROC)*/
        _2 = (int)SEQ_PTR(_info_26698);
        if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
            _15067 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
        }
        else{
            _15067 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
        }
        if (IS_ATOM_INT(_15067)) {
            _15068 = _15067 + 2;
            if ((long)((unsigned long)_15068 + (unsigned long)HIGH_BITS) >= 0) 
            _15068 = NewDouble((double)_15068);
        }
        else {
            _15068 = binary_op(PLUS, _15067, 2);
        }
        _15067 = NOVALUE;
        _2 = (int)SEQ_PTR(_info_26698);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _15069 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _15069 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        if (IS_ATOM_INT(_15069)) {
            _15070 = (_15069 != 27);
        }
        else {
            _15070 = binary_op(NOTEQ, _15069, 27);
        }
        _15069 = NOVALUE;
        if (IS_ATOM_INT(_15068) && IS_ATOM_INT(_15070)) {
            _15071 = _15068 + _15070;
            if ((long)((unsigned long)_15071 + (unsigned long)HIGH_BITS) >= 0) 
            _15071 = NewDouble((double)_15071);
        }
        else {
            _15071 = binary_op(PLUS, _15068, _15070);
        }
        DeRef(_15068);
        _15068 = NOVALUE;
        DeRef(_15070);
        _15070 = NOVALUE;
        DeRefDS(_code_26693);
        DeRefDS(_info_26698);
        _15064 = NOVALUE;
        _15065 = NOVALUE;
        return _15071;
        goto L3; // [111] 196

        /** 			case PROC_FORWARD then*/
        case 195:

        /** 				int = code[pc+2]*/
        _15072 = _pc_26692 + 2;
        _2 = (int)SEQ_PTR(_code_26693);
        _int_26700 = (int)*(((s1_ptr)_2)->base + _15072);
        if (!IS_ATOM_INT(_int_26700))
        _int_26700 = (long)DBL_PTR(_int_26700)->dbl;

        /** 				int += 3*/
        _int_26700 = _int_26700 + 3;
        goto L3; // [133] 196

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				int = code[pc+2]*/
        _15075 = _pc_26692 + 2;
        _2 = (int)SEQ_PTR(_code_26693);
        _int_26700 = (int)*(((s1_ptr)_2)->base + _15075);
        if (!IS_ATOM_INT(_int_26700))
        _int_26700 = (long)DBL_PTR(_int_26700)->dbl;

        /** 				int += 4*/
        _int_26700 = _int_26700 + 4;
        goto L3; // [155] 196

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				int = code[pc+1]*/
        _15078 = _pc_26692 + 1;
        _2 = (int)SEQ_PTR(_code_26693);
        _int_26700 = (int)*(((s1_ptr)_2)->base + _15078);
        if (!IS_ATOM_INT(_int_26700))
        _int_26700 = (long)DBL_PTR(_int_26700)->dbl;

        /** 				int += 3*/
        _int_26700 = _int_26700 + 3;
        goto L3; // [179] 196

        /** 			case else*/
        default:

        /** 				InternalErr( 269, {op} )*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _op_26696;
        _15081 = MAKE_SEQ(_1);
        _44InternalErr(269, _15081);
        _15081 = NOVALUE;
    ;}L3: 

    /** 		return int*/
    DeRefDS(_code_26693);
    DeRef(_info_26698);
    DeRef(_15064);
    _15064 = NOVALUE;
    _15065 = NOVALUE;
    DeRef(_15071);
    _15071 = NOVALUE;
    DeRef(_15072);
    _15072 = NOVALUE;
    DeRef(_15075);
    _15075 = NOVALUE;
    DeRef(_15078);
    _15078 = NOVALUE;
    return _int_26700;
L2: 
    ;
}


int _65advance(int _pc_26744, int _code_26745)
{
    int _15082 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26744)) {
        _1 = (long)(DBL_PTR(_pc_26744)->dbl);
        DeRefDS(_pc_26744);
        _pc_26744 = _1;
    }

    /** 	pc += op_size( pc, code )*/
    RefDS(_code_26745);
    _15082 = _65op_size(_pc_26744, _code_26745);
    if (IS_ATOM_INT(_15082)) {
        _pc_26744 = _pc_26744 + _15082;
    }
    else {
        _pc_26744 = binary_op(PLUS, _pc_26744, _15082);
    }
    DeRef(_15082);
    _15082 = NOVALUE;
    if (!IS_ATOM_INT(_pc_26744)) {
        _1 = (long)(DBL_PTR(_pc_26744)->dbl);
        DeRefDS(_pc_26744);
        _pc_26744 = _1;
    }

    /** 	return pc*/
    DeRefDS(_code_26745);
    return _pc_26744;
    ;
}


void _65shift_switch(int _pc_26752, int _start_26753, int _amount_26754)
{
    int _addr_26755 = NOVALUE;
    int _jump_26787 = NOVALUE;
    int _15118 = NOVALUE;
    int _15117 = NOVALUE;
    int _15116 = NOVALUE;
    int _15115 = NOVALUE;
    int _15114 = NOVALUE;
    int _15113 = NOVALUE;
    int _15112 = NOVALUE;
    int _15111 = NOVALUE;
    int _15110 = NOVALUE;
    int _15109 = NOVALUE;
    int _15108 = NOVALUE;
    int _15106 = NOVALUE;
    int _15105 = NOVALUE;
    int _15104 = NOVALUE;
    int _15103 = NOVALUE;
    int _15102 = NOVALUE;
    int _15101 = NOVALUE;
    int _15100 = NOVALUE;
    int _15099 = NOVALUE;
    int _15097 = NOVALUE;
    int _15096 = NOVALUE;
    int _15095 = NOVALUE;
    int _15094 = NOVALUE;
    int _15093 = NOVALUE;
    int _15090 = NOVALUE;
    int _15088 = NOVALUE;
    int _15087 = NOVALUE;
    int _15086 = NOVALUE;
    int _15085 = NOVALUE;
    int _15084 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sequence( Code[pc+4] ) then*/
    _15084 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15085 = (int)*(((s1_ptr)_2)->base + _15084);
    _15086 = IS_SEQUENCE(_15085);
    _15085 = NOVALUE;
    if (_15086 == 0)
    {
        _15086 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        _15086 = NOVALUE;
    }

    /** 		addr = Code[pc+4][2]*/
    _15087 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15088 = (int)*(((s1_ptr)_2)->base + _15087);
    _2 = (int)SEQ_PTR(_15088);
    _addr_26755 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_addr_26755)){
        _addr_26755 = (long)DBL_PTR(_addr_26755)->dbl;
    }
    _15088 = NOVALUE;
    goto L2; // [43] 61
L1: 

    /** 		addr = Code[pc+4]*/
    _15090 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _addr_26755 = (int)*(((s1_ptr)_2)->base + _15090);
    if (!IS_ATOM_INT(_addr_26755)){
        _addr_26755 = (long)DBL_PTR(_addr_26755)->dbl;
    }
L2: 

    /** 	if start < addr then*/
    if (_start_26753 >= _addr_26755)
    goto L3; // [65] 137

    /** 		if sequence( Code[pc+4] ) then*/
    _15093 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15094 = (int)*(((s1_ptr)_2)->base + _15093);
    _15095 = IS_SEQUENCE(_15094);
    _15094 = NOVALUE;
    if (_15095 == 0)
    {
        _15095 = NOVALUE;
        goto L4; // [84] 115
    }
    else{
        _15095 = NOVALUE;
    }

    /** 			Code[pc+4][2] += amount*/
    _15096 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _3 = (int)(_15096 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _15099 = (int)*(((s1_ptr)_2)->base + 2);
    _15097 = NOVALUE;
    if (IS_ATOM_INT(_15099)) {
        _15100 = _15099 + _amount_26754;
        if ((long)((unsigned long)_15100 + (unsigned long)HIGH_BITS) >= 0) 
        _15100 = NewDouble((double)_15100);
    }
    else {
        _15100 = binary_op(PLUS, _15099, _amount_26754);
    }
    _15099 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _15100;
    if( _1 != _15100 ){
        DeRef(_1);
    }
    _15100 = NOVALUE;
    _15097 = NOVALUE;
    goto L5; // [112] 136
L4: 

    /** 			Code[pc+4] += amount*/
    _15101 = _pc_26752 + 4;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15102 = (int)*(((s1_ptr)_2)->base + _15101);
    if (IS_ATOM_INT(_15102)) {
        _15103 = _15102 + _amount_26754;
        if ((long)((unsigned long)_15103 + (unsigned long)HIGH_BITS) >= 0) 
        _15103 = NewDouble((double)_15103);
    }
    else {
        _15103 = binary_op(PLUS, _15102, _amount_26754);
    }
    _15102 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _15101);
    _1 = *(int *)_2;
    *(int *)_2 = _15103;
    if( _1 != _15103 ){
        DeRef(_1);
    }
    _15103 = NOVALUE;
L5: 
L3: 

    /** 	sequence jump = SymTab[Code[pc+3]][S_OBJ]*/
    _15104 = _pc_26752 + 3;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15105 = (int)*(((s1_ptr)_2)->base + _15104);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_15105)){
        _15106 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15105)->dbl));
    }
    else{
        _15106 = (int)*(((s1_ptr)_2)->base + _15105);
    }
    DeRef(_jump_26787);
    _2 = (int)SEQ_PTR(_15106);
    _jump_26787 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_jump_26787);
    _15106 = NOVALUE;

    /** 	for i = 1 to length(jump) do*/
    if (IS_SEQUENCE(_jump_26787)){
            _15108 = SEQ_PTR(_jump_26787)->length;
    }
    else {
        _15108 = 1;
    }
    {
        int _i_26796;
        _i_26796 = 1;
L6: 
        if (_i_26796 > _15108){
            goto L7; // [168] 223
        }

        /** 		if start > pc and start < pc + jump[i] then*/
        _15109 = (_start_26753 > _pc_26752);
        if (_15109 == 0) {
            goto L8; // [181] 216
        }
        _2 = (int)SEQ_PTR(_jump_26787);
        _15111 = (int)*(((s1_ptr)_2)->base + _i_26796);
        if (IS_ATOM_INT(_15111)) {
            _15112 = _pc_26752 + _15111;
            if ((long)((unsigned long)_15112 + (unsigned long)HIGH_BITS) >= 0) 
            _15112 = NewDouble((double)_15112);
        }
        else {
            _15112 = binary_op(PLUS, _pc_26752, _15111);
        }
        _15111 = NOVALUE;
        if (IS_ATOM_INT(_15112)) {
            _15113 = (_start_26753 < _15112);
        }
        else {
            _15113 = binary_op(LESS, _start_26753, _15112);
        }
        DeRef(_15112);
        _15112 = NOVALUE;
        if (_15113 == 0) {
            DeRef(_15113);
            _15113 = NOVALUE;
            goto L8; // [198] 216
        }
        else {
            if (!IS_ATOM_INT(_15113) && DBL_PTR(_15113)->dbl == 0.0){
                DeRef(_15113);
                _15113 = NOVALUE;
                goto L8; // [198] 216
            }
            DeRef(_15113);
            _15113 = NOVALUE;
        }
        DeRef(_15113);
        _15113 = NOVALUE;

        /** 			jump[i] += amount*/
        _2 = (int)SEQ_PTR(_jump_26787);
        _15114 = (int)*(((s1_ptr)_2)->base + _i_26796);
        if (IS_ATOM_INT(_15114)) {
            _15115 = _15114 + _amount_26754;
            if ((long)((unsigned long)_15115 + (unsigned long)HIGH_BITS) >= 0) 
            _15115 = NewDouble((double)_15115);
        }
        else {
            _15115 = binary_op(PLUS, _15114, _amount_26754);
        }
        _15114 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_26787);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _jump_26787 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_26796);
        _1 = *(int *)_2;
        *(int *)_2 = _15115;
        if( _1 != _15115 ){
            DeRef(_1);
        }
        _15115 = NOVALUE;
L8: 

        /** 	end for*/
        _i_26796 = _i_26796 + 1;
        goto L6; // [218] 175
L7: 
        ;
    }

    /** 	SymTab[Code[pc+3]][S_OBJ] = jump*/
    _15116 = _pc_26752 + 3;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15117 = (int)*(((s1_ptr)_2)->base + _15116);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_15117))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_15117)->dbl));
    else
    _3 = (int)(_15117 + ((s1_ptr)_2)->base);
    RefDS(_jump_26787);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _jump_26787;
    DeRef(_1);
    _15118 = NOVALUE;

    /** end procedure*/
    DeRefDS(_jump_26787);
    DeRef(_15084);
    _15084 = NOVALUE;
    DeRef(_15087);
    _15087 = NOVALUE;
    DeRef(_15090);
    _15090 = NOVALUE;
    DeRef(_15093);
    _15093 = NOVALUE;
    DeRef(_15096);
    _15096 = NOVALUE;
    DeRef(_15101);
    _15101 = NOVALUE;
    DeRef(_15104);
    _15104 = NOVALUE;
    _15105 = NOVALUE;
    DeRef(_15109);
    _15109 = NOVALUE;
    _15116 = NOVALUE;
    _15117 = NOVALUE;
    return;
    ;
}


void _65shift_addr(int _pc_26815, int _amount_26816, int _start_26817, int _bound_26818)
{
    int _int_26819 = NOVALUE;
    int _15133 = NOVALUE;
    int _15130 = NOVALUE;
    int _15126 = NOVALUE;
    int _15121 = NOVALUE;
    int _15120 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_pc_26815)) {
        _1 = (long)(DBL_PTR(_pc_26815)->dbl);
        DeRefDS(_pc_26815);
        _pc_26815 = _1;
    }

    /** 	if atom( Code[pc] ) then*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15120 = (int)*(((s1_ptr)_2)->base + _pc_26815);
    _15121 = IS_ATOM(_15120);
    _15120 = NOVALUE;
    if (_15121 == 0)
    {
        _15121 = NOVALUE;
        goto L1; // [20] 75
    }
    else{
        _15121 = NOVALUE;
    }

    /** 		int = Code[pc]*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _int_26819 = (int)*(((s1_ptr)_2)->base + _pc_26815);
    if (!IS_ATOM_INT(_int_26819)){
        _int_26819 = (long)DBL_PTR(_int_26819)->dbl;
    }

    /** 		if int >= start then*/
    if (_int_26819 < _start_26817)
    goto L2; // [35] 139

    /** 			if int < bound then*/
    if (_int_26819 >= _bound_26818)
    goto L3; // [41] 56

    /** 				Code[pc] = start*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_26815);
    _1 = *(int *)_2;
    *(int *)_2 = _start_26817;
    DeRef(_1);
    goto L2; // [53] 139
L3: 

    /** 				int += amount*/
    _int_26819 = _int_26819 + _amount_26816;

    /** 				Code[pc] = int*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _pc_26815);
    _1 = *(int *)_2;
    *(int *)_2 = _int_26819;
    DeRef(_1);
    goto L2; // [72] 139
L1: 

    /** 		int = Code[pc][2]*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _15126 = (int)*(((s1_ptr)_2)->base + _pc_26815);
    _2 = (int)SEQ_PTR(_15126);
    _int_26819 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_26819)){
        _int_26819 = (long)DBL_PTR(_int_26819)->dbl;
    }
    _15126 = NOVALUE;

    /** 		if int >= start then*/
    if (_int_26819 < _start_26817)
    goto L4; // [91] 138

    /** 			if int < bound then*/
    if (_int_26819 >= _bound_26818)
    goto L5; // [97] 117

    /** 				Code[pc][2] = start*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_26815 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _start_26817;
    DeRef(_1);
    _15130 = NOVALUE;
    goto L6; // [114] 137
L5: 

    /** 				int += amount*/
    _int_26819 = _int_26819 + _amount_26816;

    /** 				Code[pc][2] = int*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pc_26815 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _int_26819;
    DeRef(_1);
    _15133 = NOVALUE;
L6: 
L4: 
L2: 

    /** end procedure*/
    return;
    ;
}


void _65shift(int _start_26852, int _amount_26853, int _bound_26854)
{
    int _int_26857 = NOVALUE;
    int _pc_26870 = NOVALUE;
    int _op_26871 = NOVALUE;
    int _finish_26872 = NOVALUE;
    int _len_26875 = NOVALUE;
    int _addrs_26886 = NOVALUE;
    int _15155 = NOVALUE;
    int _15151 = NOVALUE;
    int _15149 = NOVALUE;
    int _15147 = NOVALUE;
    int _15145 = NOVALUE;
    int _15141 = NOVALUE;
    int _15136 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_26852)) {
        _1 = (long)(DBL_PTR(_start_26852)->dbl);
        DeRefDS(_start_26852);
        _start_26852 = _1;
    }
    if (!IS_ATOM_INT(_amount_26853)) {
        _1 = (long)(DBL_PTR(_amount_26853)->dbl);
        DeRefDS(_amount_26853);
        _amount_26853 = _1;
    }
    if (!IS_ATOM_INT(_bound_26854)) {
        _1 = (long)(DBL_PTR(_bound_26854)->dbl);
        DeRefDS(_bound_26854);
        _bound_26854 = _1;
    }

    /** 	if amount = 0 then*/
    if (_amount_26853 != 0)
    goto L1; // [9] 19

    /** 		return*/
    return;
L1: 

    /** 	integer int*/

    /** 	for i = length( LineTable ) to 1 by -1 do*/
    if (IS_SEQUENCE(_35LineTable_16057)){
            _15136 = SEQ_PTR(_35LineTable_16057)->length;
    }
    else {
        _15136 = 1;
    }
    {
        int _i_26859;
        _i_26859 = _15136;
L2: 
        if (_i_26859 < 1){
            goto L3; // [28] 84
        }

        /** 		int = LineTable[i]*/
        _2 = (int)SEQ_PTR(_35LineTable_16057);
        _int_26857 = (int)*(((s1_ptr)_2)->base + _i_26859);
        if (!IS_ATOM_INT(_int_26857)){
            _int_26857 = (long)DBL_PTR(_int_26857)->dbl;
        }

        /** 		if int > 0 then*/
        if (_int_26857 <= 0)
        goto L4; // [47] 77

        /** 			if int < start then*/
        if (_int_26857 >= _start_26852)
        goto L5; // [53] 62

        /** 				exit*/
        goto L3; // [59] 84
L5: 

        /** 			int += amount*/
        _int_26857 = _int_26857 + _amount_26853;

        /** 			LineTable[i] = int*/
        _2 = (int)SEQ_PTR(_35LineTable_16057);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35LineTable_16057 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_26859);
        _1 = *(int *)_2;
        *(int *)_2 = _int_26857;
        DeRef(_1);
L4: 

        /** 	end for*/
        _i_26859 = _i_26859 + -1;
        goto L2; // [79] 35
L3: 
        ;
    }

    /** 	integer pc = 1*/
    _pc_26870 = 1;

    /** 	integer op*/

    /** 	integer finish = start + amount - 1*/
    _15141 = _start_26852 + _amount_26853;
    if ((long)((unsigned long)_15141 + (unsigned long)HIGH_BITS) >= 0) 
    _15141 = NewDouble((double)_15141);
    if (IS_ATOM_INT(_15141)) {
        _finish_26872 = _15141 - 1;
    }
    else {
        _finish_26872 = NewDouble(DBL_PTR(_15141)->dbl - (double)1);
    }
    DeRef(_15141);
    _15141 = NOVALUE;
    if (!IS_ATOM_INT(_finish_26872)) {
        _1 = (long)(DBL_PTR(_finish_26872)->dbl);
        DeRefDS(_finish_26872);
        _finish_26872 = _1;
    }

    /** 	integer len = length( Code )*/
    if (IS_SEQUENCE(_35Code_16056)){
            _len_26875 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _len_26875 = 1;
    }

    /** 	while pc <= len do*/
L6: 
    if (_pc_26870 > _len_26875)
    goto L7; // [115] 251

    /** 		if pc < start or pc > finish then*/
    _15145 = (_pc_26870 < _start_26852);
    if (_15145 != 0) {
        goto L8; // [125] 138
    }
    _15147 = (_pc_26870 > _finish_26872);
    if (_15147 == 0)
    {
        DeRef(_15147);
        _15147 = NOVALUE;
        goto L9; // [134] 233
    }
    else{
        DeRef(_15147);
        _15147 = NOVALUE;
    }
L8: 

    /** 			op = Code[pc]*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _op_26871 = (int)*(((s1_ptr)_2)->base + _pc_26870);
    if (!IS_ATOM_INT(_op_26871)){
        _op_26871 = (long)DBL_PTR(_op_26871)->dbl;
    }

    /** 			sequence addrs = op_info[op][OP_ADDR]*/
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _15149 = (int)*(((s1_ptr)_2)->base + _op_26871);
    DeRef(_addrs_26886);
    _2 = (int)SEQ_PTR(_15149);
    _addrs_26886 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_addrs_26886);
    _15149 = NOVALUE;

    /** 			for i = 1 to length( addrs ) do*/
    if (IS_SEQUENCE(_addrs_26886)){
            _15151 = SEQ_PTR(_addrs_26886)->length;
    }
    else {
        _15151 = 1;
    }
    {
        int _i_26890;
        _i_26890 = 1;
LA: 
        if (_i_26890 > _15151){
            goto LB; // [167] 232
        }

        /** 				switch op with fallthru do*/
        _0 = _op_26871;
        switch ( _0 ){ 

            /** 					case SWITCH then*/
            case 185:
            case 193:
            case 192:
            case 202:

            /** 						shift_switch( pc, start, amount )*/
            _65shift_switch(_pc_26870, _start_26852, _amount_26853);

            /** 						break*/
            goto LC; // [200] 225

            /** 					case else*/
            default:

            /** 						int = addrs[i]*/
            _2 = (int)SEQ_PTR(_addrs_26886);
            _int_26857 = (int)*(((s1_ptr)_2)->base + _i_26890);
            if (!IS_ATOM_INT(_int_26857))
            _int_26857 = (long)DBL_PTR(_int_26857)->dbl;

            /** 						shift_addr( pc + int, amount, start, bound )*/
            _15155 = _pc_26870 + _int_26857;
            if ((long)((unsigned long)_15155 + (unsigned long)HIGH_BITS) >= 0) 
            _15155 = NewDouble((double)_15155);
            _65shift_addr(_15155, _amount_26853, _start_26852, _bound_26854);
            _15155 = NOVALUE;
        ;}LC: 

        /** 			end for*/
        _i_26890 = _i_26890 + 1;
        goto LA; // [227] 174
LB: 
        ;
    }
L9: 
    DeRef(_addrs_26886);
    _addrs_26886 = NOVALUE;

    /** 		pc = advance( pc )*/
    RefDS(_35Code_16056);
    _pc_26870 = _65advance(_pc_26870, _35Code_16056);
    if (!IS_ATOM_INT(_pc_26870)) {
        _1 = (long)(DBL_PTR(_pc_26870)->dbl);
        DeRefDS(_pc_26870);
        _pc_26870 = _1;
    }

    /** 	end while*/
    goto L6; // [248] 115
L7: 

    /** 	shift_fwd_refs( start, amount )*/
    _38shift_fwd_refs(_start_26852, _amount_26853);

    /** 	move_last_pc( amount )*/
    _41move_last_pc(_amount_26853);

    /** end procedure*/
    DeRef(_15145);
    _15145 = NOVALUE;
    return;
    ;
}


void _65insert_code(int _code_26908, int _index_26909)
{
    int _15158 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_index_26909)) {
        _1 = (long)(DBL_PTR(_index_26909)->dbl);
        DeRefDS(_index_26909);
        _index_26909 = _1;
    }

    /** 	Code = splice( Code, code, index )*/
    {
        s1_ptr assign_space;
        insert_pos = _index_26909;
        if (insert_pos <= 0) {
            Concat(&_35Code_16056,_code_26908,_35Code_16056);
        }
        else if (insert_pos > SEQ_PTR(_35Code_16056)->length){
            Concat(&_35Code_16056,_35Code_16056,_code_26908);
        }
        else if (IS_SEQUENCE(_code_26908)) {
            if( _35Code_16056 != _35Code_16056 || SEQ_PTR( _35Code_16056 )->ref != 1 ){
                DeRef( _35Code_16056 );
                RefDS( _35Code_16056 );
            }
            assign_space = Add_internal_space( _35Code_16056, insert_pos,((s1_ptr)SEQ_PTR(_code_26908))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_code_26908), _35Code_16056 == _35Code_16056 );
            _35Code_16056 = MAKE_SEQ( assign_space );
        }
        else {
            if( _35Code_16056 != _35Code_16056 && SEQ_PTR( _35Code_16056 )->ref != 1 ){
                _35Code_16056 = Insert( _35Code_16056, _code_26908, insert_pos);
            }
            else {
                DeRef( _35Code_16056 );
                RefDS( _35Code_16056 );
                _35Code_16056 = Insert( _35Code_16056, _code_26908, insert_pos);
            }
        }
    }

    /** 	shift( index, length( code ) )*/
    if (IS_SEQUENCE(_code_26908)){
            _15158 = SEQ_PTR(_code_26908)->length;
    }
    else {
        _15158 = 1;
    }
    _65shift(_index_26909, _15158, _index_26909);
    _15158 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_26908);
    return;
    ;
}


void _65replace_code(int _code_26916, int _start_26917, int _finish_26918)
{
    int _15163 = NOVALUE;
    int _15162 = NOVALUE;
    int _15161 = NOVALUE;
    int _15160 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_26917)) {
        _1 = (long)(DBL_PTR(_start_26917)->dbl);
        DeRefDS(_start_26917);
        _start_26917 = _1;
    }
    if (!IS_ATOM_INT(_finish_26918)) {
        _1 = (long)(DBL_PTR(_finish_26918)->dbl);
        DeRefDS(_finish_26918);
        _finish_26918 = _1;
    }

    /** 	Code = replace( Code, code, start, finish )*/
    {
        int p1 = _35Code_16056;
        int p2 = _code_26916;
        int p3 = _start_26917;
        int p4 = _finish_26918;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_35Code_16056;
        Replace( &replace_params );
    }

    /** 	shift( start, length( code ) - (finish - start + 1), finish )*/
    if (IS_SEQUENCE(_code_26916)){
            _15160 = SEQ_PTR(_code_26916)->length;
    }
    else {
        _15160 = 1;
    }
    _15161 = _finish_26918 - _start_26917;
    if ((long)((unsigned long)_15161 +(unsigned long) HIGH_BITS) >= 0){
        _15161 = NewDouble((double)_15161);
    }
    if (IS_ATOM_INT(_15161)) {
        _15162 = _15161 + 1;
        if (_15162 > MAXINT){
            _15162 = NewDouble((double)_15162);
        }
    }
    else
    _15162 = binary_op(PLUS, 1, _15161);
    DeRef(_15161);
    _15161 = NOVALUE;
    if (IS_ATOM_INT(_15162)) {
        _15163 = _15160 - _15162;
        if ((long)((unsigned long)_15163 +(unsigned long) HIGH_BITS) >= 0){
            _15163 = NewDouble((double)_15163);
        }
    }
    else {
        _15163 = NewDouble((double)_15160 - DBL_PTR(_15162)->dbl);
    }
    _15160 = NOVALUE;
    DeRef(_15162);
    _15162 = NOVALUE;
    _65shift(_start_26917, _15163, _finish_26918);
    _15163 = NOVALUE;

    /** end procedure*/
    DeRefDS(_code_26916);
    return;
    ;
}


int _65current_op(int _pc_26928, int _code_26929)
{
    int _15171 = NOVALUE;
    int _15170 = NOVALUE;
    int _15169 = NOVALUE;
    int _15168 = NOVALUE;
    int _15167 = NOVALUE;
    int _15165 = NOVALUE;
    int _15164 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26928)) {
        _1 = (long)(DBL_PTR(_pc_26928)->dbl);
        DeRefDS(_pc_26928);
        _pc_26928 = _1;
    }

    /** 	if pc > length(code) or pc < 1 then*/
    if (IS_SEQUENCE(_code_26929)){
            _15164 = SEQ_PTR(_code_26929)->length;
    }
    else {
        _15164 = 1;
    }
    _15165 = (_pc_26928 > _15164);
    _15164 = NOVALUE;
    if (_15165 != 0) {
        goto L1; // [14] 27
    }
    _15167 = (_pc_26928 < 1);
    if (_15167 == 0)
    {
        DeRef(_15167);
        _15167 = NOVALUE;
        goto L2; // [23] 34
    }
    else{
        DeRef(_15167);
        _15167 = NOVALUE;
    }
L1: 

    /** 		return {}*/
    RefDS(_5);
    DeRefDS(_code_26929);
    DeRef(_15165);
    _15165 = NOVALUE;
    return _5;
L2: 

    /** 	return code[pc..pc-1+op_size( pc, code )]*/
    _15168 = _pc_26928 - 1;
    if ((long)((unsigned long)_15168 +(unsigned long) HIGH_BITS) >= 0){
        _15168 = NewDouble((double)_15168);
    }
    RefDS(_code_26929);
    _15169 = _65op_size(_pc_26928, _code_26929);
    if (IS_ATOM_INT(_15168) && IS_ATOM_INT(_15169)) {
        _15170 = _15168 + _15169;
    }
    else {
        _15170 = binary_op(PLUS, _15168, _15169);
    }
    DeRef(_15168);
    _15168 = NOVALUE;
    DeRef(_15169);
    _15169 = NOVALUE;
    rhs_slice_target = (object_ptr)&_15171;
    RHS_Slice(_code_26929, _pc_26928, _15170);
    DeRefDS(_code_26929);
    DeRef(_15165);
    _15165 = NOVALUE;
    DeRef(_15170);
    _15170 = NOVALUE;
    return _15171;
    ;
}


int _65get_ops(int _pc_26943, int _offset_26944, int _num_ops_26945, int _code_26946)
{
    int _sign_26949 = NOVALUE;
    int _ops_26958 = NOVALUE;
    int _opx_26960 = NOVALUE;
    int _15188 = NOVALUE;
    int _15187 = NOVALUE;
    int _15183 = NOVALUE;
    int _15182 = NOVALUE;
    int _15181 = NOVALUE;
    int _15180 = NOVALUE;
    int _15179 = NOVALUE;
    int _15178 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26943)) {
        _1 = (long)(DBL_PTR(_pc_26943)->dbl);
        DeRefDS(_pc_26943);
        _pc_26943 = _1;
    }
    if (!IS_ATOM_INT(_offset_26944)) {
        _1 = (long)(DBL_PTR(_offset_26944)->dbl);
        DeRefDS(_offset_26944);
        _offset_26944 = _1;
    }
    if (!IS_ATOM_INT(_num_ops_26945)) {
        _1 = (long)(DBL_PTR(_num_ops_26945)->dbl);
        DeRefDS(_num_ops_26945);
        _num_ops_26945 = _1;
    }

    /** 	integer sign = offset >= 0*/
    _sign_26949 = (_offset_26944 >= 0);

    /** 	if not sign then*/
    if (_sign_26949 != 0)
    goto L1; // [17] 33

    /** 		offset = -offset*/
    _offset_26944 = - _offset_26944;

    /** 		sign = -1*/
    _sign_26949 = -1;
L1: 

    /** 	while offset do*/
L2: 
    if (_offset_26944 == 0)
    {
        goto L3; // [38] 63
    }
    else{
    }

    /** 		pc = advance( pc )*/
    RefDS(_35Code_16056);
    _pc_26943 = _65advance(_pc_26943, _35Code_16056);
    if (!IS_ATOM_INT(_pc_26943)) {
        _1 = (long)(DBL_PTR(_pc_26943)->dbl);
        DeRefDS(_pc_26943);
        _pc_26943 = _1;
    }

    /** 		offset -= sign*/
    _offset_26944 = _offset_26944 - _sign_26949;

    /** 	end while*/
    goto L2; // [60] 38
L3: 

    /** 	sequence ops = repeat( 0, num_ops )*/
    DeRef(_ops_26958);
    _ops_26958 = Repeat(0, _num_ops_26945);

    /** 	integer opx = 1*/
    _opx_26960 = 1;

    /** 	while num_ops and pc <= length(code) do*/
L4: 
    if (_num_ops_26945 == 0) {
        goto L5; // [79] 137
    }
    if (IS_SEQUENCE(_code_26946)){
            _15179 = SEQ_PTR(_code_26946)->length;
    }
    else {
        _15179 = 1;
    }
    _15180 = (_pc_26943 <= _15179);
    _15179 = NOVALUE;
    if (_15180 == 0)
    {
        DeRef(_15180);
        _15180 = NOVALUE;
        goto L5; // [91] 137
    }
    else{
        DeRef(_15180);
        _15180 = NOVALUE;
    }

    /** 		ops[opx] = current_op( pc )*/
    RefDS(_35Code_16056);
    _15181 = _65current_op(_pc_26943, _35Code_16056);
    _2 = (int)SEQ_PTR(_ops_26958);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _ops_26958 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _opx_26960);
    _1 = *(int *)_2;
    *(int *)_2 = _15181;
    if( _1 != _15181 ){
        DeRef(_1);
    }
    _15181 = NOVALUE;

    /** 		pc += length( ops[opx] )*/
    _2 = (int)SEQ_PTR(_ops_26958);
    _15182 = (int)*(((s1_ptr)_2)->base + _opx_26960);
    if (IS_SEQUENCE(_15182)){
            _15183 = SEQ_PTR(_15182)->length;
    }
    else {
        _15183 = 1;
    }
    _15182 = NOVALUE;
    _pc_26943 = _pc_26943 + _15183;
    _15183 = NOVALUE;

    /** 		opx += 1*/
    _opx_26960 = _opx_26960 + 1;

    /** 		num_ops -= 1*/
    _num_ops_26945 = _num_ops_26945 - 1;

    /** 	end while*/
    goto L4; // [134] 79
L5: 

    /** 	if num_ops then*/
    if (_num_ops_26945 == 0)
    {
        goto L6; // [139] 156
    }
    else{
    }

    /** 		ops = head( ops, length( ops ) - num_ops )*/
    if (IS_SEQUENCE(_ops_26958)){
            _15187 = SEQ_PTR(_ops_26958)->length;
    }
    else {
        _15187 = 1;
    }
    _15188 = _15187 - _num_ops_26945;
    if ((long)((unsigned long)_15188 +(unsigned long) HIGH_BITS) >= 0){
        _15188 = NewDouble((double)_15188);
    }
    _15187 = NOVALUE;
    {
        int len = SEQ_PTR(_ops_26958)->length;
        int size = (IS_ATOM_INT(_15188)) ? _15188 : (object)(DBL_PTR(_15188)->dbl);
        if (size <= 0){
            DeRef( _ops_26958 );
            _ops_26958 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_ops_26958);
            DeRef(_ops_26958);
            _ops_26958 = _ops_26958;
        }
        else{
            Head(SEQ_PTR(_ops_26958),size+1,&_ops_26958);
        }
    }
    DeRef(_15188);
    _15188 = NOVALUE;
L6: 

    /** 	return ops*/
    DeRefDS(_code_26946);
    _15182 = NOVALUE;
    return _ops_26958;
    ;
}


int _65find_ops(int _pc_26978, int _op_26979, int _code_26980)
{
    int _ops_26983 = NOVALUE;
    int _found_op_26987 = NOVALUE;
    int _15197 = NOVALUE;
    int _15195 = NOVALUE;
    int _15193 = NOVALUE;
    int _15190 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_26978)) {
        _1 = (long)(DBL_PTR(_pc_26978)->dbl);
        DeRefDS(_pc_26978);
        _pc_26978 = _1;
    }
    if (!IS_ATOM_INT(_op_26979)) {
        _1 = (long)(DBL_PTR(_op_26979)->dbl);
        DeRefDS(_op_26979);
        _op_26979 = _1;
    }

    /** 	sequence ops = {}*/
    RefDS(_5);
    DeRef(_ops_26983);
    _ops_26983 = _5;

    /** 	while pc <= length(code) do*/
L1: 
    if (IS_SEQUENCE(_code_26980)){
            _15190 = SEQ_PTR(_code_26980)->length;
    }
    else {
        _15190 = 1;
    }
    if (_pc_26978 > _15190)
    goto L2; // [22] 74

    /** 		sequence found_op = current_op( pc )*/
    RefDS(_35Code_16056);
    _0 = _found_op_26987;
    _found_op_26987 = _65current_op(_pc_26978, _35Code_16056);
    DeRef(_0);

    /** 		if found_op[1] = op then*/
    _2 = (int)SEQ_PTR(_found_op_26987);
    _15193 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15193, _op_26979)){
        _15193 = NOVALUE;
        goto L3; // [43] 58
    }
    _15193 = NOVALUE;

    /** 			ops = append( ops, { pc, found_op } )*/
    RefDS(_found_op_26987);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pc_26978;
    ((int *)_2)[2] = _found_op_26987;
    _15195 = MAKE_SEQ(_1);
    RefDS(_15195);
    Append(&_ops_26983, _ops_26983, _15195);
    DeRefDS(_15195);
    _15195 = NOVALUE;
L3: 

    /** 		pc += length( found_op )*/
    if (IS_SEQUENCE(_found_op_26987)){
            _15197 = SEQ_PTR(_found_op_26987)->length;
    }
    else {
        _15197 = 1;
    }
    _pc_26978 = _pc_26978 + _15197;
    _15197 = NOVALUE;
    DeRefDS(_found_op_26987);
    _found_op_26987 = NOVALUE;

    /** 	end while*/
    goto L1; // [71] 19
L2: 

    /** 	return ops*/
    DeRefDS(_code_26980);
    return _ops_26983;
    ;
}


int _65get_target_sym(int _opseq_26999)
{
    int _op_27003 = NOVALUE;
    int _info_27005 = NOVALUE;
    int _targets_27021 = NOVALUE;
    int _sub_27036 = NOVALUE;
    int _15229 = NOVALUE;
    int _15228 = NOVALUE;
    int _15227 = NOVALUE;
    int _15226 = NOVALUE;
    int _15225 = NOVALUE;
    int _15224 = NOVALUE;
    int _15223 = NOVALUE;
    int _15221 = NOVALUE;
    int _15217 = NOVALUE;
    int _15216 = NOVALUE;
    int _15215 = NOVALUE;
    int _15214 = NOVALUE;
    int _15212 = NOVALUE;
    int _15211 = NOVALUE;
    int _15210 = NOVALUE;
    int _15209 = NOVALUE;
    int _15206 = NOVALUE;
    int _15205 = NOVALUE;
    int _15203 = NOVALUE;
    int _15199 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( opseq ) then*/
    if (IS_SEQUENCE(_opseq_26999)){
            _15199 = SEQ_PTR(_opseq_26999)->length;
    }
    else {
        _15199 = 1;
    }
    if (_15199 != 0)
    goto L1; // [8] 18
    _15199 = NOVALUE;

    /** 		return 0*/
    DeRefDS(_opseq_26999);
    DeRef(_info_27005);
    return 0;
L1: 

    /** 	integer op = opseq[1]*/
    _2 = (int)SEQ_PTR(_opseq_26999);
    _op_27003 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_op_27003))
    _op_27003 = (long)DBL_PTR(_op_27003)->dbl;

    /** 	sequence info = op_info[op]*/
    DeRef(_info_27005);
    _2 = (int)SEQ_PTR(_65op_info_26251);
    _info_27005 = (int)*(((s1_ptr)_2)->base + _op_27003);
    Ref(_info_27005);

    /** 	if info[OP_SIZE_TYPE] = FIXED_SIZE then*/
    _2 = (int)SEQ_PTR(_info_27005);
    _15203 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _15203, 1)){
        _15203 = NOVALUE;
        goto L2; // [40] 157
    }
    _15203 = NOVALUE;

    /** 		switch length( info[OP_TARGET] ) do*/
    _2 = (int)SEQ_PTR(_info_27005);
    _15205 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_15205)){
            _15206 = SEQ_PTR(_15205)->length;
    }
    else {
        _15206 = 1;
    }
    _15205 = NOVALUE;
    _0 = _15206;
    _15206 = NOVALUE;
    switch ( _0 ){ 

        /** 			case 0 then*/
        case 0:

        /** 				break*/
        goto L3; // [64] 152
        goto L3; // [66] 152

        /** 			case 1 then*/
        case 1:

        /** 				return opseq[info[OP_TARGET][1]+1]*/
        _2 = (int)SEQ_PTR(_info_27005);
        _15209 = (int)*(((s1_ptr)_2)->base + 4);
        _2 = (int)SEQ_PTR(_15209);
        _15210 = (int)*(((s1_ptr)_2)->base + 1);
        _15209 = NOVALUE;
        if (IS_ATOM_INT(_15210)) {
            _15211 = _15210 + 1;
        }
        else
        _15211 = binary_op(PLUS, 1, _15210);
        _15210 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_26999);
        if (!IS_ATOM_INT(_15211)){
            _15212 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15211)->dbl));
        }
        else{
            _15212 = (int)*(((s1_ptr)_2)->base + _15211);
        }
        Ref(_15212);
        DeRefDS(_opseq_26999);
        DeRefDS(_info_27005);
        _15205 = NOVALUE;
        DeRef(_15211);
        _15211 = NOVALUE;
        return _15212;
        goto L3; // [94] 152

        /** 			case else*/
        default:

        /** 				sequence targets = info[OP_TARGET]*/
        DeRef(_targets_27021);
        _2 = (int)SEQ_PTR(_info_27005);
        _targets_27021 = (int)*(((s1_ptr)_2)->base + 4);
        Ref(_targets_27021);

        /** 				for i = 1 to length( targets ) do*/
        if (IS_SEQUENCE(_targets_27021)){
                _15214 = SEQ_PTR(_targets_27021)->length;
        }
        else {
            _15214 = 1;
        }
        {
            int _i_27024;
            _i_27024 = 1;
L4: 
            if (_i_27024 > _15214){
                goto L5; // [113] 145
            }

            /** 					targets[i] = opseq[targets[i] + 1]*/
            _2 = (int)SEQ_PTR(_targets_27021);
            _15215 = (int)*(((s1_ptr)_2)->base + _i_27024);
            if (IS_ATOM_INT(_15215)) {
                _15216 = _15215 + 1;
            }
            else
            _15216 = binary_op(PLUS, 1, _15215);
            _15215 = NOVALUE;
            _2 = (int)SEQ_PTR(_opseq_26999);
            if (!IS_ATOM_INT(_15216)){
                _15217 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15216)->dbl));
            }
            else{
                _15217 = (int)*(((s1_ptr)_2)->base + _15216);
            }
            Ref(_15217);
            _2 = (int)SEQ_PTR(_targets_27021);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _targets_27021 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_27024);
            _1 = *(int *)_2;
            *(int *)_2 = _15217;
            if( _1 != _15217 ){
                DeRef(_1);
            }
            _15217 = NOVALUE;

            /** 				end for*/
            _i_27024 = _i_27024 + 1;
            goto L4; // [140] 120
L5: 
            ;
        }

        /** 				return targets*/
        DeRefDS(_opseq_26999);
        DeRef(_info_27005);
        _15205 = NOVALUE;
        _15212 = NOVALUE;
        DeRef(_15211);
        _15211 = NOVALUE;
        DeRef(_15216);
        _15216 = NOVALUE;
        return _targets_27021;
    ;}L3: 
    DeRef(_targets_27021);
    _targets_27021 = NOVALUE;
    goto L6; // [154] 253
L2: 

    /** 		switch op do*/
    _0 = _op_27003;
    switch ( _0 ){ 

        /** 			case PROC, PROC_TAIL then*/
        case 27:
        case 203:

        /** 				symtab_index sub = opseq[2]*/
        _2 = (int)SEQ_PTR(_opseq_26999);
        _sub_27036 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sub_27036)){
            _sub_27036 = (long)DBL_PTR(_sub_27036)->dbl;
        }

        /** 				if sym_token( sub ) = FUNC then*/
        _15221 = _53sym_token(_sub_27036);
        if (binary_op_a(NOTEQ, _15221, 501)){
            DeRef(_15221);
            _15221 = NOVALUE;
            goto L7; // [186] 204
        }
        DeRef(_15221);
        _15221 = NOVALUE;

        /** 					return opseq[$]*/
        if (IS_SEQUENCE(_opseq_26999)){
                _15223 = SEQ_PTR(_opseq_26999)->length;
        }
        else {
            _15223 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_26999);
        _15224 = (int)*(((s1_ptr)_2)->base + _15223);
        Ref(_15224);
        DeRefDS(_opseq_26999);
        DeRef(_info_27005);
        _15205 = NOVALUE;
        _15212 = NOVALUE;
        DeRef(_15211);
        _15211 = NOVALUE;
        DeRef(_15216);
        _15216 = NOVALUE;
        return _15224;
L7: 
        goto L8; // [206] 252

        /** 			case FUNC_FORWARD then*/
        case 196:

        /** 				return opseq[$]*/
        if (IS_SEQUENCE(_opseq_26999)){
                _15225 = SEQ_PTR(_opseq_26999)->length;
        }
        else {
            _15225 = 1;
        }
        _2 = (int)SEQ_PTR(_opseq_26999);
        _15226 = (int)*(((s1_ptr)_2)->base + _15225);
        Ref(_15226);
        DeRefDS(_opseq_26999);
        DeRef(_info_27005);
        _15205 = NOVALUE;
        _15212 = NOVALUE;
        DeRef(_15211);
        _15211 = NOVALUE;
        _15224 = NOVALUE;
        DeRef(_15216);
        _15216 = NOVALUE;
        return _15226;
        goto L8; // [225] 252

        /** 			case RIGHT_BRACE_N, CONCAT_N then*/
        case 31:
        case 157:

        /** 				return opseq[opseq[2]+2]*/
        _2 = (int)SEQ_PTR(_opseq_26999);
        _15227 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_ATOM_INT(_15227)) {
            _15228 = _15227 + 2;
        }
        else {
            _15228 = binary_op(PLUS, _15227, 2);
        }
        _15227 = NOVALUE;
        _2 = (int)SEQ_PTR(_opseq_26999);
        if (!IS_ATOM_INT(_15228)){
            _15229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_15228)->dbl));
        }
        else{
            _15229 = (int)*(((s1_ptr)_2)->base + _15228);
        }
        Ref(_15229);
        DeRefDS(_opseq_26999);
        DeRef(_info_27005);
        _15205 = NOVALUE;
        _15212 = NOVALUE;
        DeRef(_15211);
        _15211 = NOVALUE;
        _15224 = NOVALUE;
        DeRef(_15216);
        _15216 = NOVALUE;
        _15226 = NOVALUE;
        DeRef(_15228);
        _15228 = NOVALUE;
        return _15229;
    ;}L8: 
L6: 

    /** 	return 0*/
    DeRefDS(_opseq_26999);
    DeRef(_info_27005);
    _15205 = NOVALUE;
    _15212 = NOVALUE;
    DeRef(_15211);
    _15211 = NOVALUE;
    _15224 = NOVALUE;
    DeRef(_15216);
    _15216 = NOVALUE;
    _15226 = NOVALUE;
    _15229 = NOVALUE;
    DeRef(_15228);
    _15228 = NOVALUE;
    return 0;
    ;
}



// 0xC6D33F5C
