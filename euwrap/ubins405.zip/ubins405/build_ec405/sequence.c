// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _23reverse(int _target_4369, int _pFrom_4370, int _pTo_4371)
{
    int _uppr_4372 = NOVALUE;
    int _n_4373 = NOVALUE;
    int _lLimit_4374 = NOVALUE;
    int _t_4375 = NOVALUE;
    int _2184 = NOVALUE;
    int _2183 = NOVALUE;
    int _2182 = NOVALUE;
    int _2180 = NOVALUE;
    int _2179 = NOVALUE;
    int _2177 = NOVALUE;
    int _2175 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_4369)){
            _n_4373 = SEQ_PTR(_target_4369)->length;
    }
    else {
        _n_4373 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_4373 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_4375);
    return _target_4369;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_4370 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_4370 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_4371 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_4371 = _n_4373 + _pTo_4371;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _2175 = (_pTo_4371 < _pFrom_4370);
    if (_2175 != 0) {
        goto L4; // [54] 67
    }
    _2177 = (_pFrom_4370 >= _n_4373);
    if (_2177 == 0)
    {
        DeRef(_2177);
        _2177 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_2177);
        _2177 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_4375);
    DeRef(_2175);
    _2175 = NOVALUE;
    return _target_4369;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_4371 <= _n_4373)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_4371 = _n_4373;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _2179 = _pFrom_4370 + _pTo_4371;
    if ((long)((unsigned long)_2179 + (unsigned long)HIGH_BITS) >= 0) 
    _2179 = NewDouble((double)_2179);
    if (IS_ATOM_INT(_2179)) {
        _2180 = _2179 - 1;
        if ((long)((unsigned long)_2180 +(unsigned long) HIGH_BITS) >= 0){
            _2180 = NewDouble((double)_2180);
        }
    }
    else {
        _2180 = NewDouble(DBL_PTR(_2179)->dbl - (double)1);
    }
    DeRef(_2179);
    _2179 = NOVALUE;
    if (IS_ATOM_INT(_2180)) {
        _lLimit_4374 = _2180 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _2180, 2);
        _lLimit_4374 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_2180);
    _2180 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_4374)) {
        _1 = (long)(DBL_PTR(_lLimit_4374)->dbl);
        DeRefDS(_lLimit_4374);
        _lLimit_4374 = _1;
    }

    /** 	t = target*/
    Ref(_target_4369);
    DeRef(_t_4375);
    _t_4375 = _target_4369;

    /** 	uppr = pTo*/
    _uppr_4372 = _pTo_4371;

    /** 	for lowr = pFrom to lLimit do*/
    _2182 = _lLimit_4374;
    {
        int _lowr_4394;
        _lowr_4394 = _pFrom_4370;
L7: 
        if (_lowr_4394 > _2182){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_4369);
        _2183 = (int)*(((s1_ptr)_2)->base + _lowr_4394);
        Ref(_2183);
        _2 = (int)SEQ_PTR(_t_4375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_4375 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_4372);
        _1 = *(int *)_2;
        *(int *)_2 = _2183;
        if( _1 != _2183 ){
            DeRef(_1);
        }
        _2183 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_4369);
        _2184 = (int)*(((s1_ptr)_2)->base + _uppr_4372);
        Ref(_2184);
        _2 = (int)SEQ_PTR(_t_4375);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_4375 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_4394);
        _1 = *(int *)_2;
        *(int *)_2 = _2184;
        if( _1 != _2184 ){
            DeRef(_1);
        }
        _2184 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_4372 = _uppr_4372 - 1;

        /** 	end for*/
        _lowr_4394 = _lowr_4394 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_4369);
    DeRef(_2175);
    _2175 = NOVALUE;
    return _t_4375;
    ;
}


int _23pad_tail(int _target_4470, int _size_4471, int _ch_4472)
{
    int _2221 = NOVALUE;
    int _2220 = NOVALUE;
    int _2219 = NOVALUE;
    int _2218 = NOVALUE;
    int _2216 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_4470)){
            _2216 = SEQ_PTR(_target_4470)->length;
    }
    else {
        _2216 = 1;
    }
    if (_size_4471 > _2216)
    goto L1; // [8] 19

    /** 		return target*/
    return _target_4470;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_4470)){
            _2218 = SEQ_PTR(_target_4470)->length;
    }
    else {
        _2218 = 1;
    }
    _2219 = _size_4471 - _2218;
    _2218 = NOVALUE;
    _2220 = Repeat(_ch_4472, _2219);
    _2219 = NOVALUE;
    if (IS_SEQUENCE(_target_4470) && IS_ATOM(_2220)) {
    }
    else if (IS_ATOM(_target_4470) && IS_SEQUENCE(_2220)) {
        Ref(_target_4470);
        Prepend(&_2221, _2220, _target_4470);
    }
    else {
        Concat((object_ptr)&_2221, _target_4470, _2220);
    }
    DeRefDS(_2220);
    _2220 = NOVALUE;
    DeRef(_target_4470);
    return _2221;
    ;
}


int _23filter(int _source_4724, int _rid_4725, int _userdata_4726, int _rangetype_4727)
{
    int _dest_4728 = NOVALUE;
    int _idx_4729 = NOVALUE;
    int _2535 = NOVALUE;
    int _2534 = NOVALUE;
    int _2532 = NOVALUE;
    int _2531 = NOVALUE;
    int _2530 = NOVALUE;
    int _2529 = NOVALUE;
    int _2528 = NOVALUE;
    int _2525 = NOVALUE;
    int _2524 = NOVALUE;
    int _2523 = NOVALUE;
    int _2522 = NOVALUE;
    int _2519 = NOVALUE;
    int _2518 = NOVALUE;
    int _2517 = NOVALUE;
    int _2516 = NOVALUE;
    int _2515 = NOVALUE;
    int _2512 = NOVALUE;
    int _2511 = NOVALUE;
    int _2510 = NOVALUE;
    int _2509 = NOVALUE;
    int _2506 = NOVALUE;
    int _2505 = NOVALUE;
    int _2504 = NOVALUE;
    int _2503 = NOVALUE;
    int _2502 = NOVALUE;
    int _2499 = NOVALUE;
    int _2498 = NOVALUE;
    int _2497 = NOVALUE;
    int _2496 = NOVALUE;
    int _2493 = NOVALUE;
    int _2492 = NOVALUE;
    int _2491 = NOVALUE;
    int _2490 = NOVALUE;
    int _2489 = NOVALUE;
    int _2486 = NOVALUE;
    int _2485 = NOVALUE;
    int _2484 = NOVALUE;
    int _2483 = NOVALUE;
    int _2480 = NOVALUE;
    int _2479 = NOVALUE;
    int _2478 = NOVALUE;
    int _2477 = NOVALUE;
    int _2476 = NOVALUE;
    int _2473 = NOVALUE;
    int _2472 = NOVALUE;
    int _2471 = NOVALUE;
    int _2467 = NOVALUE;
    int _2464 = NOVALUE;
    int _2463 = NOVALUE;
    int _2462 = NOVALUE;
    int _2460 = NOVALUE;
    int _2459 = NOVALUE;
    int _2458 = NOVALUE;
    int _2457 = NOVALUE;
    int _2456 = NOVALUE;
    int _2453 = NOVALUE;
    int _2452 = NOVALUE;
    int _2451 = NOVALUE;
    int _2449 = NOVALUE;
    int _2448 = NOVALUE;
    int _2447 = NOVALUE;
    int _2446 = NOVALUE;
    int _2445 = NOVALUE;
    int _2442 = NOVALUE;
    int _2441 = NOVALUE;
    int _2440 = NOVALUE;
    int _2438 = NOVALUE;
    int _2437 = NOVALUE;
    int _2436 = NOVALUE;
    int _2435 = NOVALUE;
    int _2434 = NOVALUE;
    int _2431 = NOVALUE;
    int _2430 = NOVALUE;
    int _2429 = NOVALUE;
    int _2427 = NOVALUE;
    int _2426 = NOVALUE;
    int _2425 = NOVALUE;
    int _2424 = NOVALUE;
    int _2423 = NOVALUE;
    int _2421 = NOVALUE;
    int _2420 = NOVALUE;
    int _2419 = NOVALUE;
    int _2415 = NOVALUE;
    int _2412 = NOVALUE;
    int _2411 = NOVALUE;
    int _2410 = NOVALUE;
    int _2407 = NOVALUE;
    int _2404 = NOVALUE;
    int _2403 = NOVALUE;
    int _2402 = NOVALUE;
    int _2399 = NOVALUE;
    int _2396 = NOVALUE;
    int _2395 = NOVALUE;
    int _2394 = NOVALUE;
    int _2391 = NOVALUE;
    int _2388 = NOVALUE;
    int _2387 = NOVALUE;
    int _2386 = NOVALUE;
    int _2382 = NOVALUE;
    int _2379 = NOVALUE;
    int _2378 = NOVALUE;
    int _2377 = NOVALUE;
    int _2374 = NOVALUE;
    int _2371 = NOVALUE;
    int _2370 = NOVALUE;
    int _2369 = NOVALUE;
    int _2363 = NOVALUE;
    int _2361 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4724)){
            _2361 = SEQ_PTR(_source_4724)->length;
    }
    else {
        _2361 = 1;
    }
    if (_2361 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRefDS(_userdata_4726);
    DeRefDS(_rangetype_4727);
    DeRef(_dest_4728);
    return _source_4724;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4724)){
            _2363 = SEQ_PTR(_source_4724)->length;
    }
    else {
        _2363 = 1;
    }
    DeRef(_dest_4728);
    _dest_4728 = Repeat(0, _2363);
    _2363 = NOVALUE;

    /** 	idx = 0*/
    _idx_4729 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_4725, _2365);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2369 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2369 = 1;
        }
        {
            int _a_4741;
            _a_4741 = 1;
L2: 
            if (_a_4741 > _2369){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2370 = (int)*(((s1_ptr)_2)->base + _a_4741);
            if (IS_ATOM_INT(_2370) && IS_ATOM_INT(_userdata_4726)){
                _2371 = (_2370 < _userdata_4726) ? -1 : (_2370 > _userdata_4726);
            }
            else{
                _2371 = compare(_2370, _userdata_4726);
            }
            _2370 = NOVALUE;
            if (_2371 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2374 = (int)*(((s1_ptr)_2)->base + _a_4741);
            Ref(_2374);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2374;
            if( _1 != _2374 ){
                DeRef(_1);
            }
            _2374 = NOVALUE;
L4: 

            /** 			end for*/
            _a_4741 = _a_4741 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2377 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2377 = 1;
        }
        {
            int _a_4753;
            _a_4753 = 1;
L6: 
            if (_a_4753 > _2377){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2378 = (int)*(((s1_ptr)_2)->base + _a_4753);
            if (IS_ATOM_INT(_2378) && IS_ATOM_INT(_userdata_4726)){
                _2379 = (_2378 < _userdata_4726) ? -1 : (_2378 > _userdata_4726);
            }
            else{
                _2379 = compare(_2378, _userdata_4726);
            }
            _2378 = NOVALUE;
            if (_2379 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2382 = (int)*(((s1_ptr)_2)->base + _a_4753);
            Ref(_2382);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2382;
            if( _1 != _2382 ){
                DeRef(_1);
            }
            _2382 = NOVALUE;
L8: 

            /** 			end for*/
            _a_4753 = _a_4753 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2386 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2386 = 1;
        }
        {
            int _a_4766;
            _a_4766 = 1;
L9: 
            if (_a_4766 > _2386){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2387 = (int)*(((s1_ptr)_2)->base + _a_4766);
            if (IS_ATOM_INT(_2387) && IS_ATOM_INT(_userdata_4726)){
                _2388 = (_2387 < _userdata_4726) ? -1 : (_2387 > _userdata_4726);
            }
            else{
                _2388 = compare(_2387, _userdata_4726);
            }
            _2387 = NOVALUE;
            if (_2388 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2391 = (int)*(((s1_ptr)_2)->base + _a_4766);
            Ref(_2391);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2391;
            if( _1 != _2391 ){
                DeRef(_1);
            }
            _2391 = NOVALUE;
LB: 

            /** 			end for*/
            _a_4766 = _a_4766 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2394 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2394 = 1;
        }
        {
            int _a_4778;
            _a_4778 = 1;
LC: 
            if (_a_4778 > _2394){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2395 = (int)*(((s1_ptr)_2)->base + _a_4778);
            if (IS_ATOM_INT(_2395) && IS_ATOM_INT(_userdata_4726)){
                _2396 = (_2395 < _userdata_4726) ? -1 : (_2395 > _userdata_4726);
            }
            else{
                _2396 = compare(_2395, _userdata_4726);
            }
            _2395 = NOVALUE;
            if (_2396 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2399 = (int)*(((s1_ptr)_2)->base + _a_4778);
            Ref(_2399);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2399;
            if( _1 != _2399 ){
                DeRef(_1);
            }
            _2399 = NOVALUE;
LE: 

            /** 			end for*/
            _a_4778 = _a_4778 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2402 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2402 = 1;
        }
        {
            int _a_4790;
            _a_4790 = 1;
LF: 
            if (_a_4790 > _2402){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2403 = (int)*(((s1_ptr)_2)->base + _a_4790);
            if (IS_ATOM_INT(_2403) && IS_ATOM_INT(_userdata_4726)){
                _2404 = (_2403 < _userdata_4726) ? -1 : (_2403 > _userdata_4726);
            }
            else{
                _2404 = compare(_2403, _userdata_4726);
            }
            _2403 = NOVALUE;
            if (_2404 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2407 = (int)*(((s1_ptr)_2)->base + _a_4790);
            Ref(_2407);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2407;
            if( _1 != _2407 ){
                DeRef(_1);
            }
            _2407 = NOVALUE;
L11: 

            /** 			end for*/
            _a_4790 = _a_4790 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2410 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2410 = 1;
        }
        {
            int _a_4802;
            _a_4802 = 1;
L12: 
            if (_a_4802 > _2410){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2411 = (int)*(((s1_ptr)_2)->base + _a_4802);
            if (IS_ATOM_INT(_2411) && IS_ATOM_INT(_userdata_4726)){
                _2412 = (_2411 < _userdata_4726) ? -1 : (_2411 > _userdata_4726);
            }
            else{
                _2412 = compare(_2411, _userdata_4726);
            }
            _2411 = NOVALUE;
            if (_2412 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2415 = (int)*(((s1_ptr)_2)->base + _a_4802);
            Ref(_2415);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2415;
            if( _1 != _2415 ){
                DeRef(_1);
            }
            _2415 = NOVALUE;
L14: 

            /** 			end for*/
            _a_4802 = _a_4802 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4727, _2417);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2419 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2419 = 1;
            }
            {
                int _a_4816;
                _a_4816 = 1;
L15: 
                if (_a_4816 > _2419){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2420 = (int)*(((s1_ptr)_2)->base + _a_4816);
                _2421 = find_from(_2420, _userdata_4726, 1);
                _2420 = NOVALUE;
                if (_2421 == 0)
                {
                    _2421 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2421 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2423 = (int)*(((s1_ptr)_2)->base + _a_4816);
                Ref(_2423);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2423;
                if( _1 != _2423 ){
                    DeRef(_1);
                }
                _2423 = NOVALUE;
L17: 

                /** 					end for*/
                _a_4816 = _a_4816 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2424 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2424 = 1;
            }
            {
                int _a_4825;
                _a_4825 = 1;
L18: 
                if (_a_4825 > _2424){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2425 = (int)*(((s1_ptr)_2)->base + _a_4825);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2426 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2425) && IS_ATOM_INT(_2426)){
                    _2427 = (_2425 < _2426) ? -1 : (_2425 > _2426);
                }
                else{
                    _2427 = compare(_2425, _2426);
                }
                _2425 = NOVALUE;
                _2426 = NOVALUE;
                if (_2427 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2429 = (int)*(((s1_ptr)_2)->base + _a_4825);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2430 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2429) && IS_ATOM_INT(_2430)){
                    _2431 = (_2429 < _2430) ? -1 : (_2429 > _2430);
                }
                else{
                    _2431 = compare(_2429, _2430);
                }
                _2429 = NOVALUE;
                _2430 = NOVALUE;
                if (_2431 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2434 = (int)*(((s1_ptr)_2)->base + _a_4825);
                Ref(_2434);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2434;
                if( _1 != _2434 ){
                    DeRef(_1);
                }
                _2434 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_4825 = _a_4825 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2435 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2435 = 1;
            }
            {
                int _a_4841;
                _a_4841 = 1;
L1C: 
                if (_a_4841 > _2435){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2436 = (int)*(((s1_ptr)_2)->base + _a_4841);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2437 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2436) && IS_ATOM_INT(_2437)){
                    _2438 = (_2436 < _2437) ? -1 : (_2436 > _2437);
                }
                else{
                    _2438 = compare(_2436, _2437);
                }
                _2436 = NOVALUE;
                _2437 = NOVALUE;
                if (_2438 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2440 = (int)*(((s1_ptr)_2)->base + _a_4841);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2441 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2440) && IS_ATOM_INT(_2441)){
                    _2442 = (_2440 < _2441) ? -1 : (_2440 > _2441);
                }
                else{
                    _2442 = compare(_2440, _2441);
                }
                _2440 = NOVALUE;
                _2441 = NOVALUE;
                if (_2442 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2445 = (int)*(((s1_ptr)_2)->base + _a_4841);
                Ref(_2445);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2445;
                if( _1 != _2445 ){
                    DeRef(_1);
                }
                _2445 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_4841 = _a_4841 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2446 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2446 = 1;
            }
            {
                int _a_4857;
                _a_4857 = 1;
L20: 
                if (_a_4857 > _2446){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2447 = (int)*(((s1_ptr)_2)->base + _a_4857);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2448 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2447) && IS_ATOM_INT(_2448)){
                    _2449 = (_2447 < _2448) ? -1 : (_2447 > _2448);
                }
                else{
                    _2449 = compare(_2447, _2448);
                }
                _2447 = NOVALUE;
                _2448 = NOVALUE;
                if (_2449 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2451 = (int)*(((s1_ptr)_2)->base + _a_4857);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2452 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2451) && IS_ATOM_INT(_2452)){
                    _2453 = (_2451 < _2452) ? -1 : (_2451 > _2452);
                }
                else{
                    _2453 = compare(_2451, _2452);
                }
                _2451 = NOVALUE;
                _2452 = NOVALUE;
                if (_2453 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2456 = (int)*(((s1_ptr)_2)->base + _a_4857);
                Ref(_2456);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2456;
                if( _1 != _2456 ){
                    DeRef(_1);
                }
                _2456 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_4857 = _a_4857 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2457 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2457 = 1;
            }
            {
                int _a_4873;
                _a_4873 = 1;
L24: 
                if (_a_4873 > _2457){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2458 = (int)*(((s1_ptr)_2)->base + _a_4873);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2459 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2458) && IS_ATOM_INT(_2459)){
                    _2460 = (_2458 < _2459) ? -1 : (_2458 > _2459);
                }
                else{
                    _2460 = compare(_2458, _2459);
                }
                _2458 = NOVALUE;
                _2459 = NOVALUE;
                if (_2460 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2462 = (int)*(((s1_ptr)_2)->base + _a_4873);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2463 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2462) && IS_ATOM_INT(_2463)){
                    _2464 = (_2462 < _2463) ? -1 : (_2462 > _2463);
                }
                else{
                    _2464 = compare(_2462, _2463);
                }
                _2462 = NOVALUE;
                _2463 = NOVALUE;
                if (_2464 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2467 = (int)*(((s1_ptr)_2)->base + _a_4873);
                Ref(_2467);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2467;
                if( _1 != _2467 ){
                    DeRef(_1);
                }
                _2467 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_4873 = _a_4873 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4727, _2469);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2471 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2471 = 1;
            }
            {
                int _a_4894;
                _a_4894 = 1;
L28: 
                if (_a_4894 > _2471){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2472 = (int)*(((s1_ptr)_2)->base + _a_4894);
                _2473 = find_from(_2472, _userdata_4726, 1);
                _2472 = NOVALUE;
                if (_2473 != 0)
                goto L2A; // [818] 838
                _2473 = NOVALUE;

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2476 = (int)*(((s1_ptr)_2)->base + _a_4894);
                Ref(_2476);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2476;
                if( _1 != _2476 ){
                    DeRef(_1);
                }
                _2476 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_4894 = _a_4894 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2477 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2477 = 1;
            }
            {
                int _a_4904;
                _a_4904 = 1;
L2B: 
                if (_a_4904 > _2477){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2478 = (int)*(((s1_ptr)_2)->base + _a_4904);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2479 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2478) && IS_ATOM_INT(_2479)){
                    _2480 = (_2478 < _2479) ? -1 : (_2478 > _2479);
                }
                else{
                    _2480 = compare(_2478, _2479);
                }
                _2478 = NOVALUE;
                _2479 = NOVALUE;
                if (_2480 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2483 = (int)*(((s1_ptr)_2)->base + _a_4904);
                Ref(_2483);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2483;
                if( _1 != _2483 ){
                    DeRef(_1);
                }
                _2483 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2484 = (int)*(((s1_ptr)_2)->base + _a_4904);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2485 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2484) && IS_ATOM_INT(_2485)){
                    _2486 = (_2484 < _2485) ? -1 : (_2484 > _2485);
                }
                else{
                    _2486 = compare(_2484, _2485);
                }
                _2484 = NOVALUE;
                _2485 = NOVALUE;
                if (_2486 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2489 = (int)*(((s1_ptr)_2)->base + _a_4904);
                Ref(_2489);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2489;
                if( _1 != _2489 ){
                    DeRef(_1);
                }
                _2489 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_4904 = _a_4904 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2490 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2490 = 1;
            }
            {
                int _a_4922;
                _a_4922 = 1;
L30: 
                if (_a_4922 > _2490){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2491 = (int)*(((s1_ptr)_2)->base + _a_4922);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2492 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2491) && IS_ATOM_INT(_2492)){
                    _2493 = (_2491 < _2492) ? -1 : (_2491 > _2492);
                }
                else{
                    _2493 = compare(_2491, _2492);
                }
                _2491 = NOVALUE;
                _2492 = NOVALUE;
                if (_2493 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2496 = (int)*(((s1_ptr)_2)->base + _a_4922);
                Ref(_2496);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2496;
                if( _1 != _2496 ){
                    DeRef(_1);
                }
                _2496 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2497 = (int)*(((s1_ptr)_2)->base + _a_4922);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2498 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2497) && IS_ATOM_INT(_2498)){
                    _2499 = (_2497 < _2498) ? -1 : (_2497 > _2498);
                }
                else{
                    _2499 = compare(_2497, _2498);
                }
                _2497 = NOVALUE;
                _2498 = NOVALUE;
                if (_2499 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2502 = (int)*(((s1_ptr)_2)->base + _a_4922);
                Ref(_2502);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2502;
                if( _1 != _2502 ){
                    DeRef(_1);
                }
                _2502 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_4922 = _a_4922 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2503 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2503 = 1;
            }
            {
                int _a_4940;
                _a_4940 = 1;
L35: 
                if (_a_4940 > _2503){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2504 = (int)*(((s1_ptr)_2)->base + _a_4940);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2505 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2504) && IS_ATOM_INT(_2505)){
                    _2506 = (_2504 < _2505) ? -1 : (_2504 > _2505);
                }
                else{
                    _2506 = compare(_2504, _2505);
                }
                _2504 = NOVALUE;
                _2505 = NOVALUE;
                if (_2506 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2509 = (int)*(((s1_ptr)_2)->base + _a_4940);
                Ref(_2509);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2509;
                if( _1 != _2509 ){
                    DeRef(_1);
                }
                _2509 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2510 = (int)*(((s1_ptr)_2)->base + _a_4940);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2511 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2510) && IS_ATOM_INT(_2511)){
                    _2512 = (_2510 < _2511) ? -1 : (_2510 > _2511);
                }
                else{
                    _2512 = compare(_2510, _2511);
                }
                _2510 = NOVALUE;
                _2511 = NOVALUE;
                if (_2512 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2515 = (int)*(((s1_ptr)_2)->base + _a_4940);
                Ref(_2515);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2515;
                if( _1 != _2515 ){
                    DeRef(_1);
                }
                _2515 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_4940 = _a_4940 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4724)){
                    _2516 = SEQ_PTR(_source_4724)->length;
            }
            else {
                _2516 = 1;
            }
            {
                int _a_4958;
                _a_4958 = 1;
L3A: 
                if (_a_4958 > _2516){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2517 = (int)*(((s1_ptr)_2)->base + _a_4958);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2518 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2517) && IS_ATOM_INT(_2518)){
                    _2519 = (_2517 < _2518) ? -1 : (_2517 > _2518);
                }
                else{
                    _2519 = compare(_2517, _2518);
                }
                _2517 = NOVALUE;
                _2518 = NOVALUE;
                if (_2519 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2522 = (int)*(((s1_ptr)_2)->base + _a_4958);
                Ref(_2522);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2522;
                if( _1 != _2522 ){
                    DeRef(_1);
                }
                _2522 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2523 = (int)*(((s1_ptr)_2)->base + _a_4958);
                _2 = (int)SEQ_PTR(_userdata_4726);
                _2524 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2523) && IS_ATOM_INT(_2524)){
                    _2525 = (_2523 < _2524) ? -1 : (_2523 > _2524);
                }
                else{
                    _2525 = compare(_2523, _2524);
                }
                _2523 = NOVALUE;
                _2524 = NOVALUE;
                if (_2525 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_4729 = _idx_4729 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4724);
                _2528 = (int)*(((s1_ptr)_2)->base + _a_4958);
                Ref(_2528);
                _2 = (int)SEQ_PTR(_dest_4728);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
                _1 = *(int *)_2;
                *(int *)_2 = _2528;
                if( _1 != _2528 ){
                    DeRef(_1);
                }
                _2528 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_4958 = _a_4958 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4724)){
                _2529 = SEQ_PTR(_source_4724)->length;
        }
        else {
            _2529 = 1;
        }
        {
            int _a_4977;
            _a_4977 = 1;
L3F: 
            if (_a_4977 > _2529){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2530 = (int)*(((s1_ptr)_2)->base + _a_4977);
            Ref(_userdata_4726);
            Ref(_2530);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _2530;
            ((int *)_2)[2] = _userdata_4726;
            _2531 = MAKE_SEQ(_1);
            _2530 = NOVALUE;
            _1 = (int)SEQ_PTR(_2531);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_4725].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            DeRef(_2532);
            _2532 = _1;
            DeRefDS(_2531);
            _2531 = NOVALUE;
            if (_2532 == 0) {
                DeRef(_2532);
                _2532 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2532) && DBL_PTR(_2532)->dbl == 0.0){
                    DeRef(_2532);
                    _2532 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2532);
                _2532 = NOVALUE;
            }
            DeRef(_2532);
            _2532 = NOVALUE;

            /** 					idx += 1*/
            _idx_4729 = _idx_4729 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4724);
            _2534 = (int)*(((s1_ptr)_2)->base + _a_4977);
            Ref(_2534);
            _2 = (int)SEQ_PTR(_dest_4728);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4729);
            _1 = *(int *)_2;
            *(int *)_2 = _2534;
            if( _1 != _2534 ){
                DeRef(_1);
            }
            _2534 = NOVALUE;
L41: 

            /** 			end for*/
            _a_4977 = _a_4977 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2535;
    RHS_Slice(_dest_4728, 1, _idx_4729);
    DeRefDS(_source_4724);
    DeRef(_userdata_4726);
    DeRef(_rangetype_4727);
    DeRefDS(_dest_4728);
    return _2535;
    ;
}


int _23filter_alpha(int _elem_4989, int _ud_4990)
{
    int _2536 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_4989);
    _2536 = _13t_alpha(_elem_4989);
    DeRef(_elem_4989);
    return _2536;
    ;
}


int _23split(int _st_5034, int _delim_5035, int _no_empty_5036, int _limit_5037)
{
    int _ret_5038 = NOVALUE;
    int _start_5039 = NOVALUE;
    int _pos_5040 = NOVALUE;
    int _k_5092 = NOVALUE;
    int _2604 = NOVALUE;
    int _2602 = NOVALUE;
    int _2601 = NOVALUE;
    int _2597 = NOVALUE;
    int _2596 = NOVALUE;
    int _2595 = NOVALUE;
    int _2592 = NOVALUE;
    int _2591 = NOVALUE;
    int _2586 = NOVALUE;
    int _2585 = NOVALUE;
    int _2581 = NOVALUE;
    int _2577 = NOVALUE;
    int _2575 = NOVALUE;
    int _2574 = NOVALUE;
    int _2570 = NOVALUE;
    int _2568 = NOVALUE;
    int _2567 = NOVALUE;
    int _2566 = NOVALUE;
    int _2565 = NOVALUE;
    int _2562 = NOVALUE;
    int _2561 = NOVALUE;
    int _2560 = NOVALUE;
    int _2559 = NOVALUE;
    int _2558 = NOVALUE;
    int _2556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_5038);
    _ret_5038 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_5034)){
            _2556 = SEQ_PTR(_st_5034)->length;
    }
    else {
        _2556 = 1;
    }
    if (_2556 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_5034);
    DeRefi(_delim_5035);
    return _ret_5038;
L1: 

    /** 	if sequence(delim) then*/
    _2558 = IS_SEQUENCE(_delim_5035);
    if (_2558 == 0)
    {
        _2558 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2558 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_5035 == _5)
    _2559 = 1;
    else if (IS_ATOM_INT(_delim_5035) && IS_ATOM_INT(_5))
    _2559 = 0;
    else
    _2559 = (compare(_delim_5035, _5) == 0);
    if (_2559 == 0)
    {
        _2559 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2559 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_5034)){
            _2560 = SEQ_PTR(_st_5034)->length;
    }
    else {
        _2560 = 1;
    }
    {
        int _i_5049;
        _i_5049 = 1;
L4: 
        if (_i_5049 > _2560){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_5034);
        _2561 = (int)*(((s1_ptr)_2)->base + _i_5049);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_2561);
        *((int *)(_2+4)) = _2561;
        _2562 = MAKE_SEQ(_1);
        _2561 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_5034);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_5034 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5049);
        _1 = *(int *)_2;
        *(int *)_2 = _2562;
        if( _1 != _2562 ){
            DeRef(_1);
        }
        _2562 = NOVALUE;

        /** 				limit -= 1*/
        _limit_5037 = _limit_5037 - 1;

        /** 				if limit = 0 then*/
        if (_limit_5037 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2565;
        RHS_Slice(_st_5034, 1, _i_5049);
        _2566 = _i_5049 + 1;
        if (IS_SEQUENCE(_st_5034)){
                _2567 = SEQ_PTR(_st_5034)->length;
        }
        else {
            _2567 = 1;
        }
        rhs_slice_target = (object_ptr)&_2568;
        RHS_Slice(_st_5034, _2566, _2567);
        RefDS(_2568);
        Append(&_st_5034, _2565, _2568);
        DeRefDS(_2565);
        _2565 = NOVALUE;
        DeRefDS(_2568);
        _2568 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_5049 = _i_5049 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRefi(_delim_5035);
    DeRef(_ret_5038);
    DeRef(_2566);
    _2566 = NOVALUE;
    return _st_5034;
L3: 

    /** 		start = 1*/
    _start_5039 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_5034)){
            _2570 = SEQ_PTR(_st_5034)->length;
    }
    else {
        _2570 = 1;
    }
    if (_start_5039 > _2570)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_5040 = e_match_from(_delim_5035, _st_5034, _start_5039);

    /** 			if pos = 0 then*/
    if (_pos_5040 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2574 = _pos_5040 - 1;
    rhs_slice_target = (object_ptr)&_2575;
    RHS_Slice(_st_5034, _start_5039, _2574);
    RefDS(_2575);
    Append(&_ret_5038, _ret_5038, _2575);
    DeRefDS(_2575);
    _2575 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_5035)){
            _2577 = SEQ_PTR(_delim_5035)->length;
    }
    else {
        _2577 = 1;
    }
    _start_5039 = _pos_5040 + _2577;
    _2577 = NOVALUE;

    /** 			limit -= 1*/
    _limit_5037 = _limit_5037 - 1;

    /** 			if limit = 0 then*/
    if (_limit_5037 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_5039 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_5034)){
            _2581 = SEQ_PTR(_st_5034)->length;
    }
    else {
        _2581 = 1;
    }
    if (_start_5039 > _2581)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_5040 = find_from(_delim_5035, _st_5034, _start_5039);

    /** 			if pos = 0 then*/
    if (_pos_5040 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2585 = _pos_5040 - 1;
    rhs_slice_target = (object_ptr)&_2586;
    RHS_Slice(_st_5034, _start_5039, _2585);
    RefDS(_2586);
    Append(&_ret_5038, _ret_5038, _2586);
    DeRefDS(_2586);
    _2586 = NOVALUE;

    /** 			start = pos + 1*/
    _start_5039 = _pos_5040 + 1;

    /** 			limit -= 1*/
    _limit_5037 = _limit_5037 - 1;

    /** 			if limit = 0 then*/
    if (_limit_5037 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_5034)){
            _2591 = SEQ_PTR(_st_5034)->length;
    }
    else {
        _2591 = 1;
    }
    rhs_slice_target = (object_ptr)&_2592;
    RHS_Slice(_st_5034, _start_5039, _2591);
    RefDS(_2592);
    Append(&_ret_5038, _ret_5038, _2592);
    DeRefDS(_2592);
    _2592 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_5038)){
            _k_5092 = SEQ_PTR(_ret_5038)->length;
    }
    else {
        _k_5092 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_5036 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_5092 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_5038)){
            _2595 = SEQ_PTR(_ret_5038)->length;
    }
    else {
        _2595 = 1;
    }
    {
        int _i_5096;
        _i_5096 = 1;
LE: 
        if (_i_5096 > _2595){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_5038);
        _2596 = (int)*(((s1_ptr)_2)->base + _i_5096);
        if (IS_SEQUENCE(_2596)){
                _2597 = SEQ_PTR(_2596)->length;
        }
        else {
            _2597 = 1;
        }
        _2596 = NOVALUE;
        if (_2597 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_5092 = _k_5092 + 1;

        /** 				if k != i then*/
        if (_k_5092 == _i_5096)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_5038);
        _2601 = (int)*(((s1_ptr)_2)->base + _i_5096);
        Ref(_2601);
        _2 = (int)SEQ_PTR(_ret_5038);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_5038 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_5092);
        _1 = *(int *)_2;
        *(int *)_2 = _2601;
        if( _1 != _2601 ){
            DeRef(_1);
        }
        _2601 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_5096 = _i_5096 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_5038)){
            _2602 = SEQ_PTR(_ret_5038)->length;
    }
    else {
        _2602 = 1;
    }
    if (_k_5092 >= _2602)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2604;
    RHS_Slice(_ret_5038, 1, _k_5092);
    DeRefDS(_st_5034);
    DeRefi(_delim_5035);
    DeRefDS(_ret_5038);
    DeRef(_2574);
    _2574 = NOVALUE;
    DeRef(_2566);
    _2566 = NOVALUE;
    DeRef(_2585);
    _2585 = NOVALUE;
    _2596 = NOVALUE;
    return _2604;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_5034);
    DeRefi(_delim_5035);
    DeRef(_2574);
    _2574 = NOVALUE;
    DeRef(_2566);
    _2566 = NOVALUE;
    DeRef(_2585);
    _2585 = NOVALUE;
    _2596 = NOVALUE;
    DeRef(_2604);
    _2604 = NOVALUE;
    return _ret_5038;
L13: 
    ;
}


int _23join(int _items_5161, int _delim_5162)
{
    int _ret_5164 = NOVALUE;
    int _2639 = NOVALUE;
    int _2638 = NOVALUE;
    int _2636 = NOVALUE;
    int _2635 = NOVALUE;
    int _2634 = NOVALUE;
    int _2633 = NOVALUE;
    int _2631 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_5161)){
            _2631 = SEQ_PTR(_items_5161)->length;
    }
    else {
        _2631 = 1;
    }
    if (_2631 != 0)
    goto L1; // [8] 16
    _2631 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_5161);
    DeRef(_ret_5164);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_5164);
    _ret_5164 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_5161)){
            _2633 = SEQ_PTR(_items_5161)->length;
    }
    else {
        _2633 = 1;
    }
    _2634 = _2633 - 1;
    _2633 = NOVALUE;
    {
        int _i_5169;
        _i_5169 = 1;
L2: 
        if (_i_5169 > _2634){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_5161);
        _2635 = (int)*(((s1_ptr)_2)->base + _i_5169);
        if (IS_SEQUENCE(_2635) && IS_ATOM(_delim_5162)) {
            Append(&_2636, _2635, _delim_5162);
        }
        else if (IS_ATOM(_2635) && IS_SEQUENCE(_delim_5162)) {
        }
        else {
            Concat((object_ptr)&_2636, _2635, _delim_5162);
            _2635 = NOVALUE;
        }
        _2635 = NOVALUE;
        if (IS_SEQUENCE(_ret_5164) && IS_ATOM(_2636)) {
        }
        else if (IS_ATOM(_ret_5164) && IS_SEQUENCE(_2636)) {
            Ref(_ret_5164);
            Prepend(&_ret_5164, _2636, _ret_5164);
        }
        else {
            Concat((object_ptr)&_ret_5164, _ret_5164, _2636);
        }
        DeRefDS(_2636);
        _2636 = NOVALUE;

        /** 	end for*/
        _i_5169 = _i_5169 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_5161)){
            _2638 = SEQ_PTR(_items_5161)->length;
    }
    else {
        _2638 = 1;
    }
    _2 = (int)SEQ_PTR(_items_5161);
    _2639 = (int)*(((s1_ptr)_2)->base + _2638);
    if (IS_SEQUENCE(_ret_5164) && IS_ATOM(_2639)) {
        Ref(_2639);
        Append(&_ret_5164, _ret_5164, _2639);
    }
    else if (IS_ATOM(_ret_5164) && IS_SEQUENCE(_2639)) {
        Ref(_ret_5164);
        Prepend(&_ret_5164, _2639, _ret_5164);
    }
    else {
        Concat((object_ptr)&_ret_5164, _ret_5164, _2639);
    }
    _2639 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_5161);
    DeRef(_2634);
    _2634 = NOVALUE;
    return _ret_5164;
    ;
}


int _23flatten(int _s_5271, int _delim_5272)
{
    int _ret_5273 = NOVALUE;
    int _x_5274 = NOVALUE;
    int _len_5275 = NOVALUE;
    int _pos_5276 = NOVALUE;
    int _temp_5294 = NOVALUE;
    int _2725 = NOVALUE;
    int _2724 = NOVALUE;
    int _2723 = NOVALUE;
    int _2721 = NOVALUE;
    int _2720 = NOVALUE;
    int _2719 = NOVALUE;
    int _2717 = NOVALUE;
    int _2715 = NOVALUE;
    int _2714 = NOVALUE;
    int _2713 = NOVALUE;
    int _2711 = NOVALUE;
    int _2710 = NOVALUE;
    int _2709 = NOVALUE;
    int _2708 = NOVALUE;
    int _2707 = NOVALUE;
    int _2706 = NOVALUE;
    int _2704 = NOVALUE;
    int _2703 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_5271);
    DeRef(_ret_5273);
    _ret_5273 = _s_5271;

    /** 	pos = 1*/
    _pos_5276 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_5273)){
            _len_5275 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _len_5275 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_5276 > _len_5275)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_5274);
    _2 = (int)SEQ_PTR(_ret_5273);
    _x_5274 = (int)*(((s1_ptr)_2)->base + _pos_5276);
    Ref(_x_5274);

    /** 		if sequence(x) then*/
    _2703 = IS_SEQUENCE(_x_5274);
    if (_2703 == 0)
    {
        _2703 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2703 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_5272)){
            _2704 = SEQ_PTR(_delim_5272)->length;
    }
    else {
        _2704 = 1;
    }
    if (_2704 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2706 = _pos_5276 - 1;
    rhs_slice_target = (object_ptr)&_2707;
    RHS_Slice(_ret_5273, 1, _2706);
    Ref(_x_5274);
    RefDS(_5);
    _2708 = _23flatten(_x_5274, _5);
    _2709 = _pos_5276 + 1;
    if (_2709 > MAXINT){
        _2709 = NewDouble((double)_2709);
    }
    if (IS_SEQUENCE(_ret_5273)){
            _2710 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _2710 = 1;
    }
    rhs_slice_target = (object_ptr)&_2711;
    RHS_Slice(_ret_5273, _2709, _2710);
    {
        int concat_list[3];

        concat_list[0] = _2711;
        concat_list[1] = _2708;
        concat_list[2] = _2707;
        Concat_N((object_ptr)&_ret_5273, concat_list, 3);
    }
    DeRefDS(_2711);
    _2711 = NOVALUE;
    DeRef(_2708);
    _2708 = NOVALUE;
    DeRefDS(_2707);
    _2707 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _2713 = _pos_5276 - 1;
    rhs_slice_target = (object_ptr)&_2714;
    RHS_Slice(_ret_5273, 1, _2713);
    Ref(_x_5274);
    RefDS(_5);
    _2715 = _23flatten(_x_5274, _5);
    if (IS_SEQUENCE(_2714) && IS_ATOM(_2715)) {
        Ref(_2715);
        Append(&_temp_5294, _2714, _2715);
    }
    else if (IS_ATOM(_2714) && IS_SEQUENCE(_2715)) {
    }
    else {
        Concat((object_ptr)&_temp_5294, _2714, _2715);
        DeRefDS(_2714);
        _2714 = NOVALUE;
    }
    DeRef(_2714);
    _2714 = NOVALUE;
    DeRef(_2715);
    _2715 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_5273)){
            _2717 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _2717 = 1;
    }
    if (_pos_5276 == _2717)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _2719 = _pos_5276 + 1;
    if (_2719 > MAXINT){
        _2719 = NewDouble((double)_2719);
    }
    if (IS_SEQUENCE(_ret_5273)){
            _2720 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _2720 = 1;
    }
    rhs_slice_target = (object_ptr)&_2721;
    RHS_Slice(_ret_5273, _2719, _2720);
    {
        int concat_list[3];

        concat_list[0] = _2721;
        concat_list[1] = _delim_5272;
        concat_list[2] = _temp_5294;
        Concat_N((object_ptr)&_ret_5273, concat_list, 3);
    }
    DeRefDS(_2721);
    _2721 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _2723 = _pos_5276 + 1;
    if (_2723 > MAXINT){
        _2723 = NewDouble((double)_2723);
    }
    if (IS_SEQUENCE(_ret_5273)){
            _2724 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _2724 = 1;
    }
    rhs_slice_target = (object_ptr)&_2725;
    RHS_Slice(_ret_5273, _2723, _2724);
    Concat((object_ptr)&_ret_5273, _temp_5294, _2725);
    DeRefDS(_2725);
    _2725 = NOVALUE;
L7: 
    DeRef(_temp_5294);
    _temp_5294 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_5273)){
            _len_5275 = SEQ_PTR(_ret_5273)->length;
    }
    else {
        _len_5275 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_5276 = _pos_5276 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_5271);
    DeRefi(_delim_5272);
    DeRef(_x_5274);
    DeRef(_2706);
    _2706 = NOVALUE;
    DeRef(_2713);
    _2713 = NOVALUE;
    DeRef(_2719);
    _2719 = NOVALUE;
    DeRef(_2709);
    _2709 = NOVALUE;
    DeRef(_2723);
    _2723 = NOVALUE;
    return _ret_5273;
    ;
}



// 0x23DA6E03
