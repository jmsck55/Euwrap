// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _30calc_primes(int _approx_limit_10623, int _time_limit_p_10624)
{
    int _result__10625 = NOVALUE;
    int _candidate__10626 = NOVALUE;
    int _pos__10627 = NOVALUE;
    int _time_out__10628 = NOVALUE;
    int _maxp__10629 = NOVALUE;
    int _maxf__10630 = NOVALUE;
    int _maxf_idx_10631 = NOVALUE;
    int _next_trigger_10632 = NOVALUE;
    int _growth_10633 = NOVALUE;
    int _5981 = NOVALUE;
    int _5978 = NOVALUE;
    int _5976 = NOVALUE;
    int _5973 = NOVALUE;
    int _5970 = NOVALUE;
    int _5967 = NOVALUE;
    int _5960 = NOVALUE;
    int _5958 = NOVALUE;
    int _5955 = NOVALUE;
    int _5952 = NOVALUE;
    int _5948 = NOVALUE;
    int _5947 = NOVALUE;
    int _5943 = NOVALUE;
    int _5937 = NOVALUE;
    int _5935 = NOVALUE;
    int _5933 = NOVALUE;
    int _5928 = NOVALUE;
    int _5927 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if approx_limit <= list_of_primes[$] then*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5927 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5927 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _5928 = (int)*(((s1_ptr)_2)->base + _5927);
    if (binary_op_a(GREATER, _approx_limit_10623, _5928)){
        _5928 = NOVALUE;
        goto L1; // [14] 59
    }
    _5928 = NOVALUE;

    /** 		pos_ = search:binary_search(approx_limit, list_of_primes)*/
    RefDS(_30list_of_primes_10619);
    _pos__10627 = _16binary_search(_approx_limit_10623, _30list_of_primes_10619, 1, 0);
    if (!IS_ATOM_INT(_pos__10627)) {
        _1 = (long)(DBL_PTR(_pos__10627)->dbl);
        DeRefDS(_pos__10627);
        _pos__10627 = _1;
    }

    /** 		if pos_ < 0 then*/
    if (_pos__10627 >= 0)
    goto L2; // [33] 45

    /** 			pos_ = (-pos_)*/
    _pos__10627 = - _pos__10627;
L2: 

    /** 		return list_of_primes[1..pos_]*/
    rhs_slice_target = (object_ptr)&_5933;
    RHS_Slice(_30list_of_primes_10619, 1, _pos__10627);
    DeRef(_result__10625);
    DeRef(_time_out__10628);
    return _5933;
L1: 

    /** 	pos_ = length(list_of_primes)*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _pos__10627 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _pos__10627 = 1;
    }

    /** 	candidate_ = list_of_primes[$]*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5935 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5935 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _candidate__10626 = (int)*(((s1_ptr)_2)->base + _5935);
    if (!IS_ATOM_INT(_candidate__10626))
    _candidate__10626 = (long)DBL_PTR(_candidate__10626)->dbl;

    /** 	maxf_ = floor(power(candidate_, 0.5))*/
    temp_d.dbl = (double)_candidate__10626;
    _5937 = Dpower(&temp_d, DBL_PTR(_1637));
    _maxf__10630 = unary_op(FLOOR, _5937);
    DeRefDS(_5937);
    _5937 = NOVALUE;
    if (!IS_ATOM_INT(_maxf__10630)) {
        _1 = (long)(DBL_PTR(_maxf__10630)->dbl);
        DeRefDS(_maxf__10630);
        _maxf__10630 = _1;
    }

    /** 	maxf_idx = search:binary_search(maxf_, list_of_primes)*/
    RefDS(_30list_of_primes_10619);
    _maxf_idx_10631 = _16binary_search(_maxf__10630, _30list_of_primes_10619, 1, 0);
    if (!IS_ATOM_INT(_maxf_idx_10631)) {
        _1 = (long)(DBL_PTR(_maxf_idx_10631)->dbl);
        DeRefDS(_maxf_idx_10631);
        _maxf_idx_10631 = _1;
    }

    /** 	if maxf_idx < 0 then*/
    if (_maxf_idx_10631 >= 0)
    goto L3; // [103] 123

    /** 		maxf_idx = (-maxf_idx)*/
    _maxf_idx_10631 = - _maxf_idx_10631;

    /** 		maxf_ = list_of_primes[maxf_idx]*/
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _maxf__10630 = (int)*(((s1_ptr)_2)->base + _maxf_idx_10631);
    if (!IS_ATOM_INT(_maxf__10630))
    _maxf__10630 = (long)DBL_PTR(_maxf__10630)->dbl;
L3: 

    /** 	next_trigger = list_of_primes[maxf_idx+1]*/
    _5943 = _maxf_idx_10631 + 1;
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _next_trigger_10632 = (int)*(((s1_ptr)_2)->base + _5943);
    if (!IS_ATOM_INT(_next_trigger_10632))
    _next_trigger_10632 = (long)DBL_PTR(_next_trigger_10632)->dbl;

    /** 	next_trigger *= next_trigger*/
    _next_trigger_10632 = _next_trigger_10632 * _next_trigger_10632;

    /** 	growth = floor(approx_limit  / 3.5) - length(list_of_primes)*/
    _2 = binary_op(DIVIDE, _approx_limit_10623, _5946);
    _5947 = unary_op(FLOOR, _2);
    DeRef(_2);
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5948 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5948 = 1;
    }
    if (IS_ATOM_INT(_5947)) {
        _growth_10633 = _5947 - _5948;
    }
    else {
        _growth_10633 = NewDouble(DBL_PTR(_5947)->dbl - (double)_5948);
    }
    DeRef(_5947);
    _5947 = NOVALUE;
    _5948 = NOVALUE;
    if (!IS_ATOM_INT(_growth_10633)) {
        _1 = (long)(DBL_PTR(_growth_10633)->dbl);
        DeRefDS(_growth_10633);
        _growth_10633 = _1;
    }

    /** 	if growth <= 0 then*/
    if (_growth_10633 > 0)
    goto L4; // [162] 174

    /** 		growth = length(list_of_primes)*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _growth_10633 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _growth_10633 = 1;
    }
L4: 

    /** 	result_ = list_of_primes & repeat(0, growth)*/
    _5952 = Repeat(0, _growth_10633);
    Concat((object_ptr)&_result__10625, _30list_of_primes_10619, _5952);
    DeRefDS(_5952);
    _5952 = NOVALUE;

    /** 	if time_limit_p < 0 then*/
    if (_time_limit_p_10624 >= 0)
    goto L5; // [188] 203

    /** 		time_out_ = time() + 100_000_000*/
    DeRef(_5955);
    _5955 = NewDouble(current_time());
    DeRef(_time_out__10628);
    _time_out__10628 = NewDouble(DBL_PTR(_5955)->dbl + (double)100000000);
    DeRefDS(_5955);
    _5955 = NOVALUE;
    goto L6; // [200] 212
L5: 

    /** 		time_out_ = time() + time_limit_p*/
    DeRef(_5958);
    _5958 = NewDouble(current_time());
    DeRef(_time_out__10628);
    _time_out__10628 = NewDouble(DBL_PTR(_5958)->dbl + (double)_time_limit_p_10624);
    DeRefDS(_5958);
    _5958 = NOVALUE;
L6: 

    /** 	while time_out_ >= time()  label "MW" do*/
L7: 
    DeRef(_5960);
    _5960 = NewDouble(current_time());
    if (binary_op_a(LESS, _time_out__10628, _5960)){
        DeRefDS(_5960);
        _5960 = NOVALUE;
        goto L8; // [221] 370
    }
    DeRef(_5960);
    _5960 = NOVALUE;

    /** 		task_yield()*/
    task_yield();

    /** 		candidate_ += 2*/
    _candidate__10626 = _candidate__10626 + 2;

    /** 		if candidate_ >= next_trigger then*/
    if (_candidate__10626 < _next_trigger_10632)
    goto L9; // [236] 271

    /** 			maxf_idx += 1*/
    _maxf_idx_10631 = _maxf_idx_10631 + 1;

    /** 			maxf_ = result_[maxf_idx]*/
    _2 = (int)SEQ_PTR(_result__10625);
    _maxf__10630 = (int)*(((s1_ptr)_2)->base + _maxf_idx_10631);
    if (!IS_ATOM_INT(_maxf__10630))
    _maxf__10630 = (long)DBL_PTR(_maxf__10630)->dbl;

    /** 			next_trigger = result_[maxf_idx+1]*/
    _5967 = _maxf_idx_10631 + 1;
    _2 = (int)SEQ_PTR(_result__10625);
    _next_trigger_10632 = (int)*(((s1_ptr)_2)->base + _5967);
    if (!IS_ATOM_INT(_next_trigger_10632))
    _next_trigger_10632 = (long)DBL_PTR(_next_trigger_10632)->dbl;

    /** 			next_trigger *= next_trigger*/
    _next_trigger_10632 = _next_trigger_10632 * _next_trigger_10632;
L9: 

    /** 		for i = 2 to pos_ do*/
    _5970 = _pos__10627;
    {
        int _i_10686;
        _i_10686 = 2;
LA: 
        if (_i_10686 > _5970){
            goto LB; // [276] 322
        }

        /** 			maxp_ = result_[i]*/
        _2 = (int)SEQ_PTR(_result__10625);
        _maxp__10629 = (int)*(((s1_ptr)_2)->base + _i_10686);
        if (!IS_ATOM_INT(_maxp__10629))
        _maxp__10629 = (long)DBL_PTR(_maxp__10629)->dbl;

        /** 			if maxp_ > maxf_ then*/
        if (_maxp__10629 <= _maxf__10630)
        goto LC; // [291] 300

        /** 				exit*/
        goto LB; // [297] 322
LC: 

        /** 			if remainder(candidate_, maxp_) = 0 then*/
        _5973 = (_candidate__10626 % _maxp__10629);
        if (_5973 != 0)
        goto LD; // [306] 315

        /** 				continue "MW"*/
        goto L7; // [312] 217
LD: 

        /** 		end for*/
        _i_10686 = _i_10686 + 1;
        goto LA; // [317] 283
LB: 
        ;
    }

    /** 		pos_ += 1*/
    _pos__10627 = _pos__10627 + 1;

    /** 		if pos_ >= length(result_) then*/
    if (IS_SEQUENCE(_result__10625)){
            _5976 = SEQ_PTR(_result__10625)->length;
    }
    else {
        _5976 = 1;
    }
    if (_pos__10627 < _5976)
    goto LE; // [333] 348

    /** 			result_ &= repeat(0, 1000)*/
    _5978 = Repeat(0, 1000);
    Concat((object_ptr)&_result__10625, _result__10625, _5978);
    DeRefDS(_5978);
    _5978 = NOVALUE;
LE: 

    /** 		result_[pos_] = candidate_*/
    _2 = (int)SEQ_PTR(_result__10625);
    _2 = (int)(((s1_ptr)_2)->base + _pos__10627);
    _1 = *(int *)_2;
    *(int *)_2 = _candidate__10626;
    DeRef(_1);

    /** 		if candidate_ >= approx_limit then*/
    if (_candidate__10626 < _approx_limit_10623)
    goto L7; // [356] 217

    /** 			exit*/
    goto L8; // [362] 370

    /** 	end while*/
    goto L7; // [367] 217
L8: 

    /** 	return result_[1..pos_]*/
    rhs_slice_target = (object_ptr)&_5981;
    RHS_Slice(_result__10625, 1, _pos__10627);
    DeRefDS(_result__10625);
    DeRef(_time_out__10628);
    DeRef(_5933);
    _5933 = NOVALUE;
    DeRef(_5943);
    _5943 = NOVALUE;
    DeRef(_5967);
    _5967 = NOVALUE;
    DeRef(_5973);
    _5973 = NOVALUE;
    return _5981;
    ;
}


int _30next_prime(int _n_10705, int _fail_signal_p_10706, int _time_out_p_10707)
{
    int _i_10708 = NOVALUE;
    int _6001 = NOVALUE;
    int _5995 = NOVALUE;
    int _5994 = NOVALUE;
    int _5993 = NOVALUE;
    int _5992 = NOVALUE;
    int _5991 = NOVALUE;
    int _5988 = NOVALUE;
    int _5987 = NOVALUE;
    int _5984 = NOVALUE;
    int _5983 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if n < 0 then*/
    if (_n_10705 >= 0)
    goto L1; // [5] 16

    /** 		return fail_signal_p*/
    return _fail_signal_p_10706;
L1: 

    /** 	if list_of_primes[$] < n then*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5983 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5983 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _5984 = (int)*(((s1_ptr)_2)->base + _5983);
    if (binary_op_a(GREATEREQ, _5984, _n_10705)){
        _5984 = NOVALUE;
        goto L2; // [27] 41
    }
    _5984 = NOVALUE;

    /** 		list_of_primes = calc_primes(n,time_out_p)*/
    _0 = _30calc_primes(_n_10705, _time_out_p_10707);
    DeRefDS(_30list_of_primes_10619);
    _30list_of_primes_10619 = _0;
L2: 

    /** 	if n > list_of_primes[$] then*/
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5987 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5987 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _5988 = (int)*(((s1_ptr)_2)->base + _5987);
    if (binary_op_a(LESSEQ, _n_10705, _5988)){
        _5988 = NOVALUE;
        goto L3; // [52] 63
    }
    _5988 = NOVALUE;

    /** 		return fail_signal_p*/
    return _fail_signal_p_10706;
L3: 

    /** 	if n < 1009 and 1009 <= list_of_primes[$] then*/
    _5991 = (_n_10705 < 1009);
    if (_5991 == 0) {
        goto L4; // [69] 106
    }
    if (IS_SEQUENCE(_30list_of_primes_10619)){
            _5993 = SEQ_PTR(_30list_of_primes_10619)->length;
    }
    else {
        _5993 = 1;
    }
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _5994 = (int)*(((s1_ptr)_2)->base + _5993);
    if (IS_ATOM_INT(_5994)) {
        _5995 = (1009 <= _5994);
    }
    else {
        _5995 = binary_op(LESSEQ, 1009, _5994);
    }
    _5994 = NOVALUE;
    if (_5995 == 0) {
        DeRef(_5995);
        _5995 = NOVALUE;
        goto L4; // [87] 106
    }
    else {
        if (!IS_ATOM_INT(_5995) && DBL_PTR(_5995)->dbl == 0.0){
            DeRef(_5995);
            _5995 = NOVALUE;
            goto L4; // [87] 106
        }
        DeRef(_5995);
        _5995 = NOVALUE;
    }
    DeRef(_5995);
    _5995 = NOVALUE;

    /** 		i = search:binary_search(n, list_of_primes, ,169)*/
    RefDS(_30list_of_primes_10619);
    _i_10708 = _16binary_search(_n_10705, _30list_of_primes_10619, 1, 169);
    if (!IS_ATOM_INT(_i_10708)) {
        _1 = (long)(DBL_PTR(_i_10708)->dbl);
        DeRefDS(_i_10708);
        _i_10708 = _1;
    }
    goto L5; // [103] 120
L4: 

    /** 		i = search:binary_search(n, list_of_primes)*/
    RefDS(_30list_of_primes_10619);
    _i_10708 = _16binary_search(_n_10705, _30list_of_primes_10619, 1, 0);
    if (!IS_ATOM_INT(_i_10708)) {
        _1 = (long)(DBL_PTR(_i_10708)->dbl);
        DeRefDS(_i_10708);
        _i_10708 = _1;
    }
L5: 

    /** 	if i < 0 then*/
    if (_i_10708 >= 0)
    goto L6; // [124] 136

    /** 		i = (-i)*/
    _i_10708 = - _i_10708;
L6: 

    /** 	return list_of_primes[i]*/
    _2 = (int)SEQ_PTR(_30list_of_primes_10619);
    _6001 = (int)*(((s1_ptr)_2)->base + _i_10708);
    Ref(_6001);
    DeRef(_fail_signal_p_10706);
    DeRef(_5991);
    _5991 = NOVALUE;
    return _6001;
    ;
}



// 0xCBF9B3BF
