// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _36open_locked(int _file_path_15011)
{
    int _fh_15012 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(file_path, "u")*/
    _fh_15012 = EOpen(_file_path_15011, _8472, 0);

    /** 	if fh = -1 then*/
    if (_fh_15012 != -1)
    goto L1; // [12] 24

    /** 		fh = open(file_path, "r")*/
    _fh_15012 = EOpen(_file_path_15011, _3810, 0);
L1: 

    /** 	return fh*/
    DeRefDS(_file_path_15011);
    return _fh_15012;
    ;
}


int _36get_eudir()
{
    int _possible_paths_15025 = NOVALUE;
    int _home_15030 = NOVALUE;
    int _possible_path_15044 = NOVALUE;
    int _possible_path_15058 = NOVALUE;
    int _file_check_15072 = NOVALUE;
    int _8513 = NOVALUE;
    int _8512 = NOVALUE;
    int _8511 = NOVALUE;
    int _8509 = NOVALUE;
    int _8507 = NOVALUE;
    int _8505 = NOVALUE;
    int _8504 = NOVALUE;
    int _8503 = NOVALUE;
    int _8502 = NOVALUE;
    int _8501 = NOVALUE;
    int _8499 = NOVALUE;
    int _8497 = NOVALUE;
    int _8496 = NOVALUE;
    int _8492 = NOVALUE;
    int _8486 = NOVALUE;
    int _8484 = NOVALUE;
    int _8478 = NOVALUE;
    int _8476 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(eudir) then*/
    _8476 = IS_SEQUENCE(_36eudir_15007);
    if (_8476 == 0)
    {
        _8476 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _8476 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_36eudir_15007);
    DeRef(_possible_paths_15025);
    DeRefi(_home_15030);
    return _36eudir_15007;
L1: 

    /** 	eudir = getenv("EUDIR")*/
    DeRef(_36eudir_15007);
    _36eudir_15007 = EGetEnv(_3720);

    /** 	if sequence(eudir) then*/
    _8478 = IS_SEQUENCE(_36eudir_15007);
    if (_8478 == 0)
    {
        _8478 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _8478 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_36eudir_15007);
    DeRef(_possible_paths_15025);
    DeRefi(_home_15030);
    return _36eudir_15007;
L2: 

    /** 	ifdef UNIX then*/

    /** 		sequence possible_paths = {*/
    _0 = _possible_paths_15025;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_8479);
    *((int *)(_2+4)) = _8479;
    RefDS(_8480);
    *((int *)(_2+8)) = _8480;
    RefDS(_8481);
    *((int *)(_2+12)) = _8481;
    _possible_paths_15025 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		object home = getenv("HOME")*/
    DeRefi(_home_15030);
    _home_15030 = EGetEnv(_3370);

    /** 		if sequence(home) then*/
    _8484 = IS_SEQUENCE(_home_15030);
    if (_8484 == 0)
    {
        _8484 = NOVALUE;
        goto L3; // [64] 78
    }
    else{
        _8484 = NOVALUE;
    }

    /** 			possible_paths = append(possible_paths, home & "/euphoria")*/
    if (IS_SEQUENCE(_home_15030) && IS_ATOM(_8485)) {
    }
    else if (IS_ATOM(_home_15030) && IS_SEQUENCE(_8485)) {
        Ref(_home_15030);
        Prepend(&_8486, _8485, _home_15030);
    }
    else {
        Concat((object_ptr)&_8486, _home_15030, _8485);
    }
    RefDS(_8486);
    Append(&_possible_paths_15025, _possible_paths_15025, _8486);
    DeRefDS(_8486);
    _8486 = NOVALUE;
L3: 

    /** 	for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_15025)){
            _8492 = SEQ_PTR(_possible_paths_15025)->length;
    }
    else {
        _8492 = 1;
    }
    {
        int _i_15042;
        _i_15042 = 1;
L4: 
        if (_i_15042 > _8492){
            goto L5; // [85] 144
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15044);
        _2 = (int)SEQ_PTR(_possible_paths_15025);
        _possible_path_15044 = (int)*(((s1_ptr)_2)->base + _i_15042);
        RefDS(_possible_path_15044);

        /** 		if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            int concat_list[5];

            concat_list[0] = _8495;
            concat_list[1] = 47;
            concat_list[2] = _8494;
            concat_list[3] = 47;
            concat_list[4] = _possible_path_15044;
            Concat_N((object_ptr)&_8496, concat_list, 5);
        }
        _8497 = _17file_exists(_8496);
        _8496 = NOVALUE;
        if (_8497 == 0) {
            DeRef(_8497);
            _8497 = NOVALUE;
            goto L6; // [118] 135
        }
        else {
            if (!IS_ATOM_INT(_8497) && DBL_PTR(_8497)->dbl == 0.0){
                DeRef(_8497);
                _8497 = NOVALUE;
                goto L6; // [118] 135
            }
            DeRef(_8497);
            _8497 = NOVALUE;
        }
        DeRef(_8497);
        _8497 = NOVALUE;

        /** 			eudir = possible_path*/
        RefDS(_possible_path_15044);
        DeRef(_36eudir_15007);
        _36eudir_15007 = _possible_path_15044;

        /** 			return eudir*/
        RefDS(_36eudir_15007);
        DeRefDS(_possible_path_15044);
        DeRefDS(_possible_paths_15025);
        DeRefi(_home_15030);
        return _36eudir_15007;
L6: 
        DeRef(_possible_path_15044);
        _possible_path_15044 = NOVALUE;

        /** 	end for*/
        _i_15042 = _i_15042 + 1;
        goto L4; // [139] 92
L5: 
        ;
    }

    /** 	possible_paths = include_paths(0)*/
    _0 = _possible_paths_15025;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3746);
    *((int *)(_2+4)) = _3746;
    RefDS(_3745);
    *((int *)(_2+8)) = _3745;
    RefDS(_3744);
    *((int *)(_2+12)) = _3744;
    _possible_paths_15025 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(possible_paths) do*/
    _8499 = 3;
    {
        int _i_15056;
        _i_15056 = 1;
L7: 
        if (_i_15056 > 3){
            goto L8; // [157] 282
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_15058);
        _2 = (int)SEQ_PTR(_possible_paths_15025);
        _possible_path_15058 = (int)*(((s1_ptr)_2)->base + _i_15056);
        RefDS(_possible_path_15058);

        /** 		if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_15058)){
                _8501 = SEQ_PTR(_possible_path_15058)->length;
        }
        else {
            _8501 = 1;
        }
        _2 = (int)SEQ_PTR(_possible_path_15058);
        _8502 = (int)*(((s1_ptr)_2)->base + _8501);
        if (_8502 == 47)
        _8503 = 1;
        else if (IS_ATOM_INT(_8502) && IS_ATOM_INT(47))
        _8503 = 0;
        else
        _8503 = (compare(_8502, 47) == 0);
        _8502 = NOVALUE;
        if (_8503 == 0)
        {
            _8503 = NOVALUE;
            goto L9; // [187] 205
        }
        else{
            _8503 = NOVALUE;
        }

        /** 			possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_15058)){
                _8504 = SEQ_PTR(_possible_path_15058)->length;
        }
        else {
            _8504 = 1;
        }
        _8505 = _8504 - 1;
        _8504 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_15058;
        RHS_Slice(_possible_path_15058, 1, _8505);
L9: 

        /** 		if not ends("include", possible_path) then*/
        RefDS(_8494);
        RefDS(_possible_path_15058);
        _8507 = _16ends(_8494, _possible_path_15058);
        if (IS_ATOM_INT(_8507)) {
            if (_8507 != 0){
                DeRef(_8507);
                _8507 = NOVALUE;
                goto LA; // [212] 222
            }
        }
        else {
            if (DBL_PTR(_8507)->dbl != 0.0){
                DeRef(_8507);
                _8507 = NOVALUE;
                goto LA; // [212] 222
            }
        }
        DeRef(_8507);
        _8507 = NOVALUE;

        /** 			continue*/
        DeRefDS(_possible_path_15058);
        _possible_path_15058 = NOVALUE;
        DeRef(_file_check_15072);
        _file_check_15072 = NOVALUE;
        goto LB; // [219] 277
LA: 

        /** 		sequence file_check = possible_path*/
        RefDS(_possible_path_15058);
        DeRef(_file_check_15072);
        _file_check_15072 = _possible_path_15058;

        /** 		file_check &= SLASH & "euphoria.h"*/
        Prepend(&_8509, _8495, 47);
        Concat((object_ptr)&_file_check_15072, _file_check_15072, _8509);
        DeRefDS(_8509);
        _8509 = NOVALUE;

        /** 		if file_exists(file_check) then*/
        RefDS(_file_check_15072);
        _8511 = _17file_exists(_file_check_15072);
        if (_8511 == 0) {
            DeRef(_8511);
            _8511 = NOVALUE;
            goto LC; // [247] 273
        }
        else {
            if (!IS_ATOM_INT(_8511) && DBL_PTR(_8511)->dbl == 0.0){
                DeRef(_8511);
                _8511 = NOVALUE;
                goto LC; // [247] 273
            }
            DeRef(_8511);
            _8511 = NOVALUE;
        }
        DeRef(_8511);
        _8511 = NOVALUE;

        /** 			eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_15058)){
                _8512 = SEQ_PTR(_possible_path_15058)->length;
        }
        else {
            _8512 = 1;
        }
        _8513 = _8512 - 8;
        _8512 = NOVALUE;
        rhs_slice_target = (object_ptr)&_36eudir_15007;
        RHS_Slice(_possible_path_15058, 1, _8513);

        /** 			return eudir*/
        RefDS(_36eudir_15007);
        DeRefDS(_possible_path_15058);
        DeRefDS(_file_check_15072);
        DeRef(_possible_paths_15025);
        DeRefi(_home_15030);
        DeRef(_8505);
        _8505 = NOVALUE;
        _8513 = NOVALUE;
        return _36eudir_15007;
LC: 
        DeRef(_possible_path_15058);
        _possible_path_15058 = NOVALUE;
        DeRef(_file_check_15072);
        _file_check_15072 = NOVALUE;

        /** 	end for*/
LB: 
        _i_15056 = _i_15056 + 1;
        goto L7; // [277] 164
L8: 
        ;
    }

    /** 	return ""*/
    RefDS(_5);
    DeRef(_possible_paths_15025);
    DeRefi(_home_15030);
    DeRef(_8505);
    _8505 = NOVALUE;
    DeRef(_8513);
    _8513 = NOVALUE;
    return _5;
    ;
}


void _36set_eudir(int _new_eudir_15084)
{
    int _0, _1, _2;
    

    /** 	eudir = new_eudir*/
    RefDS(_new_eudir_15084);
    DeRef(_36eudir_15007);
    _36eudir_15007 = _new_eudir_15084;

    /** 	cmdline_eudir = 1*/
    _36cmdline_eudir_15008 = 1;

    /** end procedure*/
    DeRefDS(_new_eudir_15084);
    return;
    ;
}


int _36is_eudir_from_cmdline()
{
    int _0, _1, _2;
    

    /** 	return cmdline_eudir*/
    return _36cmdline_eudir_15008;
    ;
}



// 0xF4D2287A
