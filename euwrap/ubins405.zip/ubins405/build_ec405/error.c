// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _7warning_file(int _file_path_252)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_WARNING_FILE, file_path)*/
    machine(72, _file_path_252);

    /** end procedure*/
    DeRef(_file_path_252);
    return;
    ;
}



// 0xD6879DCB
