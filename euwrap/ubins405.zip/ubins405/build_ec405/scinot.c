// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _62reverse(int _s_22062)
{
    int _lower_22063 = NOVALUE;
    int _n_22064 = NOVALUE;
    int _n2_22065 = NOVALUE;
    int _t_22066 = NOVALUE;
    int _12832 = NOVALUE;
    int _12831 = NOVALUE;
    int _12830 = NOVALUE;
    int _12827 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(s)*/
    if (IS_SEQUENCE(_s_22062)){
            _n_22064 = SEQ_PTR(_s_22062)->length;
    }
    else {
        _n_22064 = 1;
    }

    /** 	n2 = floor(n/2)+1*/
    _12827 = _n_22064 >> 1;
    _n2_22065 = _12827 + 1;
    _12827 = NOVALUE;

    /** 	t = repeat(0, n)*/
    DeRef(_t_22066);
    _t_22066 = Repeat(0, _n_22064);

    /** 	lower = 1*/
    _lower_22063 = 1;

    /** 	for upper = n to n2 by -1 do*/
    _12830 = _n2_22065;
    {
        int _upper_22072;
        _upper_22072 = _n_22064;
L1: 
        if (_upper_22072 < _12830){
            goto L2; // [34] 74
        }

        /** 		t[upper] = s[lower]*/
        _2 = (int)SEQ_PTR(_s_22062);
        _12831 = (int)*(((s1_ptr)_2)->base + _lower_22063);
        Ref(_12831);
        _2 = (int)SEQ_PTR(_t_22066);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22066 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _upper_22072);
        _1 = *(int *)_2;
        *(int *)_2 = _12831;
        if( _1 != _12831 ){
            DeRef(_1);
        }
        _12831 = NOVALUE;

        /** 		t[lower] = s[upper]*/
        _2 = (int)SEQ_PTR(_s_22062);
        _12832 = (int)*(((s1_ptr)_2)->base + _upper_22072);
        Ref(_12832);
        _2 = (int)SEQ_PTR(_t_22066);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22066 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lower_22063);
        _1 = *(int *)_2;
        *(int *)_2 = _12832;
        if( _1 != _12832 ){
            DeRef(_1);
        }
        _12832 = NOVALUE;

        /** 		lower += 1*/
        _lower_22063 = _lower_22063 + 1;

        /** 	end for*/
        _upper_22072 = _upper_22072 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** 	return t*/
    DeRefDS(_s_22062);
    return _t_22066;
    ;
}


int _62carry(int _a_22079, int _radix_22080)
{
    int _q_22081 = NOVALUE;
    int _r_22082 = NOVALUE;
    int _b_22083 = NOVALUE;
    int _rmax_22084 = NOVALUE;
    int _i_22085 = NOVALUE;
    int _12846 = NOVALUE;
    int _12845 = NOVALUE;
    int _12844 = NOVALUE;
    int _12841 = NOVALUE;
    int _12835 = NOVALUE;
    int _0, _1, _2;
    

    /** 		rmax = radix - 1*/
    DeRef(_rmax_22084);
    _rmax_22084 = _radix_22080 - 1;
    if ((long)((unsigned long)_rmax_22084 +(unsigned long) HIGH_BITS) >= 0){
        _rmax_22084 = NewDouble((double)_rmax_22084);
    }

    /** 		i = 1*/
    DeRef(_i_22085);
    _i_22085 = 1;

    /** 		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_22079)){
            _12835 = SEQ_PTR(_a_22079)->length;
    }
    else {
        _12835 = 1;
    }
    if (binary_op_a(GREATER, _i_22085, _12835)){
        _12835 = NOVALUE;
        goto L2; // [24] 104
    }
    _12835 = NOVALUE;

    /** 				b = a[i]*/
    DeRef(_b_22083);
    _2 = (int)SEQ_PTR(_a_22079);
    if (!IS_ATOM_INT(_i_22085)){
        _b_22083 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22085)->dbl));
    }
    else{
        _b_22083 = (int)*(((s1_ptr)_2)->base + _i_22085);
    }
    Ref(_b_22083);

    /** 				if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_22083, _rmax_22084)){
        goto L3; // [36] 93
    }

    /** 						q = floor( b / radix )*/
    DeRef(_q_22081);
    if (IS_ATOM_INT(_b_22083)) {
        if (_radix_22080 > 0 && _b_22083 >= 0) {
            _q_22081 = _b_22083 / _radix_22080;
        }
        else {
            temp_dbl = floor((double)_b_22083 / (double)_radix_22080);
            if (_b_22083 != MININT)
            _q_22081 = (long)temp_dbl;
            else
            _q_22081 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_22083, _radix_22080);
        _q_22081 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** 						r = remainder( b, radix )*/
    DeRef(_r_22082);
    if (IS_ATOM_INT(_b_22083)) {
        _r_22082 = (_b_22083 % _radix_22080);
    }
    else {
        temp_d.dbl = (double)_radix_22080;
        _r_22082 = Dremainder(DBL_PTR(_b_22083), &temp_d);
    }

    /** 						a[i] = r*/
    Ref(_r_22082);
    _2 = (int)SEQ_PTR(_a_22079);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22079 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_22085))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22085)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _i_22085);
    _1 = *(int *)_2;
    *(int *)_2 = _r_22082;
    DeRef(_1);

    /** 						if i = length(a) then*/
    if (IS_SEQUENCE(_a_22079)){
            _12841 = SEQ_PTR(_a_22079)->length;
    }
    else {
        _12841 = 1;
    }
    if (binary_op_a(NOTEQ, _i_22085, _12841)){
        _12841 = NOVALUE;
        goto L4; // [63] 74
    }
    _12841 = NOVALUE;

    /** 								a &= 0*/
    Append(&_a_22079, _a_22079, 0);
L4: 

    /** 						a[i+1] += q*/
    if (IS_ATOM_INT(_i_22085)) {
        _12844 = _i_22085 + 1;
    }
    else
    _12844 = binary_op(PLUS, 1, _i_22085);
    _2 = (int)SEQ_PTR(_a_22079);
    if (!IS_ATOM_INT(_12844)){
        _12845 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12844)->dbl));
    }
    else{
        _12845 = (int)*(((s1_ptr)_2)->base + _12844);
    }
    if (IS_ATOM_INT(_12845) && IS_ATOM_INT(_q_22081)) {
        _12846 = _12845 + _q_22081;
        if ((long)((unsigned long)_12846 + (unsigned long)HIGH_BITS) >= 0) 
        _12846 = NewDouble((double)_12846);
    }
    else {
        _12846 = binary_op(PLUS, _12845, _q_22081);
    }
    _12845 = NOVALUE;
    _2 = (int)SEQ_PTR(_a_22079);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22079 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12844))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12844)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12844);
    _1 = *(int *)_2;
    *(int *)_2 = _12846;
    if( _1 != _12846 ){
        DeRef(_1);
    }
    _12846 = NOVALUE;
L3: 

    /** 				i += 1*/
    _0 = _i_22085;
    if (IS_ATOM_INT(_i_22085)) {
        _i_22085 = _i_22085 + 1;
        if (_i_22085 > MAXINT){
            _i_22085 = NewDouble((double)_i_22085);
        }
    }
    else
    _i_22085 = binary_op(PLUS, 1, _i_22085);
    DeRef(_0);

    /** 		end while*/
    goto L1; // [101] 21
L2: 

    /** 		return a*/
    DeRef(_q_22081);
    DeRef(_r_22082);
    DeRef(_b_22083);
    DeRef(_rmax_22084);
    DeRef(_i_22085);
    DeRef(_12844);
    _12844 = NOVALUE;
    return _a_22079;
    ;
}


int _62add(int _a_22105, int _b_22106)
{
    int _12864 = NOVALUE;
    int _12862 = NOVALUE;
    int _12861 = NOVALUE;
    int _12860 = NOVALUE;
    int _12859 = NOVALUE;
    int _12857 = NOVALUE;
    int _12856 = NOVALUE;
    int _12854 = NOVALUE;
    int _12853 = NOVALUE;
    int _12852 = NOVALUE;
    int _12851 = NOVALUE;
    int _12849 = NOVALUE;
    int _12848 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_22105)){
            _12848 = SEQ_PTR(_a_22105)->length;
    }
    else {
        _12848 = 1;
    }
    if (IS_SEQUENCE(_b_22106)){
            _12849 = SEQ_PTR(_b_22106)->length;
    }
    else {
        _12849 = 1;
    }
    if (_12848 >= _12849)
    goto L1; // [13] 40

    /** 				a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_22106)){
            _12851 = SEQ_PTR(_b_22106)->length;
    }
    else {
        _12851 = 1;
    }
    if (IS_SEQUENCE(_a_22105)){
            _12852 = SEQ_PTR(_a_22105)->length;
    }
    else {
        _12852 = 1;
    }
    _12853 = _12851 - _12852;
    _12851 = NOVALUE;
    _12852 = NOVALUE;
    _12854 = Repeat(0, _12853);
    _12853 = NOVALUE;
    Concat((object_ptr)&_a_22105, _a_22105, _12854);
    DeRefDS(_12854);
    _12854 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** 		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_22106)){
            _12856 = SEQ_PTR(_b_22106)->length;
    }
    else {
        _12856 = 1;
    }
    if (IS_SEQUENCE(_a_22105)){
            _12857 = SEQ_PTR(_a_22105)->length;
    }
    else {
        _12857 = 1;
    }
    if (_12856 >= _12857)
    goto L3; // [48] 73

    /** 				b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_22105)){
            _12859 = SEQ_PTR(_a_22105)->length;
    }
    else {
        _12859 = 1;
    }
    if (IS_SEQUENCE(_b_22106)){
            _12860 = SEQ_PTR(_b_22106)->length;
    }
    else {
        _12860 = 1;
    }
    _12861 = _12859 - _12860;
    _12859 = NOVALUE;
    _12860 = NOVALUE;
    _12862 = Repeat(0, _12861);
    _12861 = NOVALUE;
    Concat((object_ptr)&_b_22106, _b_22106, _12862);
    DeRefDS(_12862);
    _12862 = NOVALUE;
L3: 
L2: 

    /** 		return a + b*/
    _12864 = binary_op(PLUS, _a_22105, _b_22106);
    DeRefDS(_a_22105);
    DeRefDS(_b_22106);
    return _12864;
    ;
}


int _62borrow(int _a_22128, int _radix_22129)
{
    int _12872 = NOVALUE;
    int _12871 = NOVALUE;
    int _12870 = NOVALUE;
    int _12869 = NOVALUE;
    int _12868 = NOVALUE;
    int _12866 = NOVALUE;
    int _12865 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_22128)){
            _12865 = SEQ_PTR(_a_22128)->length;
    }
    else {
        _12865 = 1;
    }
    {
        int _i_22131;
        _i_22131 = _12865;
L1: 
        if (_i_22131 < 2){
            goto L2; // [10] 67
        }

        /** 				if a[i] < 0 then*/
        _2 = (int)SEQ_PTR(_a_22128);
        _12866 = (int)*(((s1_ptr)_2)->base + _i_22131);
        if (binary_op_a(GREATEREQ, _12866, 0)){
            _12866 = NOVALUE;
            goto L3; // [23] 60
        }
        _12866 = NOVALUE;

        /** 						a[i] += radix*/
        _2 = (int)SEQ_PTR(_a_22128);
        _12868 = (int)*(((s1_ptr)_2)->base + _i_22131);
        if (IS_ATOM_INT(_12868)) {
            _12869 = _12868 + _radix_22129;
            if ((long)((unsigned long)_12869 + (unsigned long)HIGH_BITS) >= 0) 
            _12869 = NewDouble((double)_12869);
        }
        else {
            _12869 = binary_op(PLUS, _12868, _radix_22129);
        }
        _12868 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22128);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22128 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22131);
        _1 = *(int *)_2;
        *(int *)_2 = _12869;
        if( _1 != _12869 ){
            DeRef(_1);
        }
        _12869 = NOVALUE;

        /** 						a[i-1] -= 1*/
        _12870 = _i_22131 - 1;
        _2 = (int)SEQ_PTR(_a_22128);
        _12871 = (int)*(((s1_ptr)_2)->base + _12870);
        if (IS_ATOM_INT(_12871)) {
            _12872 = _12871 - 1;
            if ((long)((unsigned long)_12872 +(unsigned long) HIGH_BITS) >= 0){
                _12872 = NewDouble((double)_12872);
            }
        }
        else {
            _12872 = binary_op(MINUS, _12871, 1);
        }
        _12871 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22128);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22128 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _12870);
        _1 = *(int *)_2;
        *(int *)_2 = _12872;
        if( _1 != _12872 ){
            DeRef(_1);
        }
        _12872 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22131 = _i_22131 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** 		return a*/
    DeRef(_12870);
    _12870 = NOVALUE;
    return _a_22128;
    ;
}


int _62bits_to_bytes(int _bits_22143)
{
    int _bytes_22144 = NOVALUE;
    int _r_22145 = NOVALUE;
    int _12881 = NOVALUE;
    int _12880 = NOVALUE;
    int _12879 = NOVALUE;
    int _12878 = NOVALUE;
    int _12876 = NOVALUE;
    int _12875 = NOVALUE;
    int _12873 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_22143)){
            _12873 = SEQ_PTR(_bits_22143)->length;
    }
    else {
        _12873 = 1;
    }
    _r_22145 = (_12873 % 8);
    _12873 = NOVALUE;

    /** 		if r  then*/
    if (_r_22145 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** 				bits &= repeat( 0, 8 - r )*/
    _12875 = 8 - _r_22145;
    _12876 = Repeat(0, _12875);
    _12875 = NOVALUE;
    Concat((object_ptr)&_bits_22143, _bits_22143, _12876);
    DeRefDS(_12876);
    _12876 = NOVALUE;
L1: 

    /** 		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_22144);
    _bytes_22144 = _5;

    /** 		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_22143)){
            _12878 = SEQ_PTR(_bits_22143)->length;
    }
    else {
        _12878 = 1;
    }
    {
        int _i_22153;
        _i_22153 = 1;
L2: 
        if (_i_22153 > _12878){
            goto L3; // [44] 77
        }

        /** 				bytes &= bits_to_int( bits[i..i+7] )*/
        _12879 = _i_22153 + 7;
        rhs_slice_target = (object_ptr)&_12880;
        RHS_Slice(_bits_22143, _i_22153, _12879);
        _12881 = _15bits_to_int(_12880);
        _12880 = NOVALUE;
        if (IS_SEQUENCE(_bytes_22144) && IS_ATOM(_12881)) {
            Ref(_12881);
            Append(&_bytes_22144, _bytes_22144, _12881);
        }
        else if (IS_ATOM(_bytes_22144) && IS_SEQUENCE(_12881)) {
        }
        else {
            Concat((object_ptr)&_bytes_22144, _bytes_22144, _12881);
        }
        DeRef(_12881);
        _12881 = NOVALUE;

        /** 		end for*/
        _i_22153 = _i_22153 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** 		return bytes*/
    DeRefDS(_bits_22143);
    DeRef(_12879);
    _12879 = NOVALUE;
    return _bytes_22144;
    ;
}


int _62bytes_to_bits(int _bytes_22162)
{
    int _bits_22163 = NOVALUE;
    int _12885 = NOVALUE;
    int _12884 = NOVALUE;
    int _12883 = NOVALUE;
    int _0, _1, _2;
    

    /** 		bits = {}*/
    RefDS(_5);
    DeRef(_bits_22163);
    _bits_22163 = _5;

    /** 		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_22162)){
            _12883 = SEQ_PTR(_bytes_22162)->length;
    }
    else {
        _12883 = 1;
    }
    {
        int _i_22165;
        _i_22165 = 1;
L1: 
        if (_i_22165 > _12883){
            goto L2; // [15] 44
        }

        /** 				bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (int)SEQ_PTR(_bytes_22162);
        _12884 = (int)*(((s1_ptr)_2)->base + _i_22165);
        Ref(_12884);
        _12885 = _15int_to_bits(_12884, 8);
        _12884 = NOVALUE;
        if (IS_SEQUENCE(_bits_22163) && IS_ATOM(_12885)) {
            Ref(_12885);
            Append(&_bits_22163, _bits_22163, _12885);
        }
        else if (IS_ATOM(_bits_22163) && IS_SEQUENCE(_12885)) {
        }
        else {
            Concat((object_ptr)&_bits_22163, _bits_22163, _12885);
        }
        DeRef(_12885);
        _12885 = NOVALUE;

        /** 		end for*/
        _i_22165 = _i_22165 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** 		return bits*/
    DeRefDS(_bytes_22162);
    return _bits_22163;
    ;
}


int _62convert_radix(int _number_22173, int _from_radix_22174, int _to_radix_22175)
{
    int _target_22176 = NOVALUE;
    int _base_22177 = NOVALUE;
    int _12892 = NOVALUE;
    int _12891 = NOVALUE;
    int _12890 = NOVALUE;
    int _12889 = NOVALUE;
    int _0, _1, _2;
    

    /** 		base = {1}*/
    RefDS(_12887);
    DeRef(_base_22177);
    _base_22177 = _12887;

    /** 		target = {0}*/
    _0 = _target_22176;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _target_22176 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_22173)){
            _12889 = SEQ_PTR(_number_22173)->length;
    }
    else {
        _12889 = 1;
    }
    {
        int _i_22181;
        _i_22181 = 1;
L1: 
        if (_i_22181 > _12889){
            goto L2; // [25] 78
        }

        /** 				target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (int)SEQ_PTR(_number_22173);
        _12890 = (int)*(((s1_ptr)_2)->base + _i_22181);
        _12891 = binary_op(MULTIPLY, _base_22177, _12890);
        _12890 = NOVALUE;
        RefDS(_target_22176);
        _12892 = _62add(_12891, _target_22176);
        _12891 = NOVALUE;
        _0 = _target_22176;
        _target_22176 = _62carry(_12892, _to_radix_22175);
        DeRefDS(_0);
        _12892 = NOVALUE;

        /** 				base *= from_radix*/
        _0 = _base_22177;
        _base_22177 = binary_op(MULTIPLY, _base_22177, _from_radix_22174);
        DeRefDS(_0);

        /** 				base = carry( base, to_radix )*/
        RefDS(_base_22177);
        _0 = _base_22177;
        _base_22177 = _62carry(_base_22177, _to_radix_22175);
        DeRefDS(_0);

        /** 		end for*/
        _i_22181 = _i_22181 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** 		return target*/
    DeRefDS(_number_22173);
    DeRef(_base_22177);
    return _target_22176;
    ;
}


int _62half(int _decimal_22191)
{
    int _quotient_22192 = NOVALUE;
    int _q_22193 = NOVALUE;
    int _Q_22194 = NOVALUE;
    int _12913 = NOVALUE;
    int _12912 = NOVALUE;
    int _12911 = NOVALUE;
    int _12910 = NOVALUE;
    int _12909 = NOVALUE;
    int _12908 = NOVALUE;
    int _12905 = NOVALUE;
    int _12903 = NOVALUE;
    int _12902 = NOVALUE;
    int _12899 = NOVALUE;
    int _12898 = NOVALUE;
    int _12896 = NOVALUE;
    int _0, _1, _2;
    

    /** 		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_22191)){
            _12896 = SEQ_PTR(_decimal_22191)->length;
    }
    else {
        _12896 = 1;
    }
    DeRef(_quotient_22192);
    _quotient_22192 = Repeat(0, _12896);
    _12896 = NOVALUE;

    /** 		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_22191)){
            _12898 = SEQ_PTR(_decimal_22191)->length;
    }
    else {
        _12898 = 1;
    }
    {
        int _i_22198;
        _i_22198 = 1;
L1: 
        if (_i_22198 > _12898){
            goto L2; // [17] 101
        }

        /** 				q = decimal[i] / 2*/
        _2 = (int)SEQ_PTR(_decimal_22191);
        _12899 = (int)*(((s1_ptr)_2)->base + _i_22198);
        DeRef(_q_22193);
        if (IS_ATOM_INT(_12899)) {
            if (_12899 & 1) {
                _q_22193 = NewDouble((_12899 >> 1) + 0.5);
            }
            else
            _q_22193 = _12899 >> 1;
        }
        else {
            _q_22193 = binary_op(DIVIDE, _12899, 2);
        }
        _12899 = NOVALUE;

        /** 				Q = floor( q )*/
        DeRef(_Q_22194);
        if (IS_ATOM_INT(_q_22193))
        _Q_22194 = e_floor(_q_22193);
        else
        _Q_22194 = unary_op(FLOOR, _q_22193);

        /** 				quotient[i] +=  Q*/
        _2 = (int)SEQ_PTR(_quotient_22192);
        _12902 = (int)*(((s1_ptr)_2)->base + _i_22198);
        if (IS_ATOM_INT(_12902) && IS_ATOM_INT(_Q_22194)) {
            _12903 = _12902 + _Q_22194;
            if ((long)((unsigned long)_12903 + (unsigned long)HIGH_BITS) >= 0) 
            _12903 = NewDouble((double)_12903);
        }
        else {
            _12903 = binary_op(PLUS, _12902, _Q_22194);
        }
        _12902 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22192);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22192 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22198);
        _1 = *(int *)_2;
        *(int *)_2 = _12903;
        if( _1 != _12903 ){
            DeRef(_1);
        }
        _12903 = NOVALUE;

        /** 				if q != Q then*/
        if (binary_op_a(EQUALS, _q_22193, _Q_22194)){
            goto L3; // [55] 94
        }

        /** 						if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_22192)){
                _12905 = SEQ_PTR(_quotient_22192)->length;
        }
        else {
            _12905 = 1;
        }
        if (_12905 != _i_22198)
        goto L4; // [64] 75

        /** 								quotient &= 0*/
        Append(&_quotient_22192, _quotient_22192, 0);
L4: 

        /** 						quotient[i+1] += 5*/
        _12908 = _i_22198 + 1;
        _2 = (int)SEQ_PTR(_quotient_22192);
        _12909 = (int)*(((s1_ptr)_2)->base + _12908);
        if (IS_ATOM_INT(_12909)) {
            _12910 = _12909 + 5;
            if ((long)((unsigned long)_12910 + (unsigned long)HIGH_BITS) >= 0) 
            _12910 = NewDouble((double)_12910);
        }
        else {
            _12910 = binary_op(PLUS, _12909, 5);
        }
        _12909 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22192);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22192 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _12908);
        _1 = *(int *)_2;
        *(int *)_2 = _12910;
        if( _1 != _12910 ){
            DeRef(_1);
        }
        _12910 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22198 = _i_22198 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** 		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_22192);
    _12911 = _62reverse(_quotient_22192);
    _12912 = _62carry(_12911, 10);
    _12911 = NOVALUE;
    _12913 = _62reverse(_12912);
    _12912 = NOVALUE;
    DeRefDS(_decimal_22191);
    DeRefDS(_quotient_22192);
    DeRef(_q_22193);
    DeRef(_Q_22194);
    DeRef(_12908);
    _12908 = NOVALUE;
    return _12913;
    ;
}


int _62decimals_to_bits(int _decimals_22227)
{
    int _sub_22228 = NOVALUE;
    int _bits_22229 = NOVALUE;
    int _bit_22230 = NOVALUE;
    int _assigned_22231 = NOVALUE;
    int _12940 = NOVALUE;
    int _12936 = NOVALUE;
    int _12935 = NOVALUE;
    int _12934 = NOVALUE;
    int _12933 = NOVALUE;
    int _12931 = NOVALUE;
    int _12930 = NOVALUE;
    int _12929 = NOVALUE;
    int _12927 = NOVALUE;
    int _12925 = NOVALUE;
    int _12924 = NOVALUE;
    int _12923 = NOVALUE;
    int _12922 = NOVALUE;
    int _12920 = NOVALUE;
    int _12918 = NOVALUE;
    int _0, _1, _2;
    

    /** 		sub = {5}*/
    RefDS(_12916);
    DeRef(_sub_22228);
    _sub_22228 = _12916;

    /** 		bits = repeat( 0, 53 )*/
    DeRef(_bits_22229);
    _bits_22229 = Repeat(0, 53);

    /** 		bit = 1*/
    _bit_22230 = 1;

    /** 		assigned = 0*/
    _assigned_22231 = 0;

    /** 		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_22227) && IS_ATOM_INT(_bits_22229)){
        _12918 = (_decimals_22227 < _bits_22229) ? -1 : (_decimals_22227 > _bits_22229);
    }
    else{
        _12918 = compare(_decimals_22227, _bits_22229);
    }
    if (_12918 <= 0)
    goto L1; // [32] 160

    /** 			while (not assigned) or (bit < find( 1, bits ) + 54)  do*/
L2: 
    _12920 = (_assigned_22231 == 0);
    if (_12920 != 0) {
        goto L3; // [44] 66
    }
    _12922 = find_from(1, _bits_22229, 1);
    _12923 = _12922 + 54;
    _12922 = NOVALUE;
    _12924 = (_bit_22230 < _12923);
    _12923 = NOVALUE;
    if (_12924 == 0)
    {
        DeRef(_12924);
        _12924 = NOVALUE;
        goto L4; // [62] 159
    }
    else{
        DeRef(_12924);
        _12924 = NOVALUE;
    }
L3: 

    /** 				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_22228) && IS_ATOM_INT(_decimals_22227)){
        _12925 = (_sub_22228 < _decimals_22227) ? -1 : (_sub_22228 > _decimals_22227);
    }
    else{
        _12925 = compare(_sub_22228, _decimals_22227);
    }
    if (_12925 > 0)
    goto L5; // [72] 140

    /** 						assigned = 1*/
    _assigned_22231 = 1;

    /** 						if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_22229)){
            _12927 = SEQ_PTR(_bits_22229)->length;
    }
    else {
        _12927 = 1;
    }
    if (_12927 >= _bit_22230)
    goto L6; // [86] 108

    /** 								bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_22229)){
            _12929 = SEQ_PTR(_bits_22229)->length;
    }
    else {
        _12929 = 1;
    }
    _12930 = _bit_22230 - _12929;
    _12929 = NOVALUE;
    _12931 = Repeat(0, _12930);
    _12930 = NOVALUE;
    Concat((object_ptr)&_bits_22229, _bits_22229, _12931);
    DeRefDS(_12931);
    _12931 = NOVALUE;
L6: 

    /** 						bits[bit] += 1*/
    _2 = (int)SEQ_PTR(_bits_22229);
    _12933 = (int)*(((s1_ptr)_2)->base + _bit_22230);
    if (IS_ATOM_INT(_12933)) {
        _12934 = _12933 + 1;
        if (_12934 > MAXINT){
            _12934 = NewDouble((double)_12934);
        }
    }
    else
    _12934 = binary_op(PLUS, 1, _12933);
    _12933 = NOVALUE;
    _2 = (int)SEQ_PTR(_bits_22229);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bits_22229 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bit_22230);
    _1 = *(int *)_2;
    *(int *)_2 = _12934;
    if( _1 != _12934 ){
        DeRef(_1);
    }
    _12934 = NOVALUE;

    /** 						decimals = borrow( add( decimals, -sub ), 10 )*/
    _12935 = unary_op(UMINUS, _sub_22228);
    RefDS(_decimals_22227);
    _12936 = _62add(_decimals_22227, _12935);
    _12935 = NOVALUE;
    _0 = _decimals_22227;
    _decimals_22227 = _62borrow(_12936, 10);
    DeRefDS(_0);
    _12936 = NOVALUE;
L5: 

    /** 				sub = half( sub )*/
    RefDS(_sub_22228);
    _0 = _sub_22228;
    _sub_22228 = _62half(_sub_22228);
    DeRefDS(_0);

    /** 				bit += 1*/
    _bit_22230 = _bit_22230 + 1;

    /** 			end while*/
    goto L2; // [156] 41
L4: 
L1: 

    /** 		return reverse(bits)*/
    RefDS(_bits_22229);
    _12940 = _62reverse(_bits_22229);
    DeRefDS(_decimals_22227);
    DeRef(_sub_22228);
    DeRefDS(_bits_22229);
    DeRef(_12920);
    _12920 = NOVALUE;
    return _12940;
    ;
}


int _62string_to_int(int _s_22263)
{
    int _int_22264 = NOVALUE;
    int _12944 = NOVALUE;
    int _12943 = NOVALUE;
    int _12941 = NOVALUE;
    int _0, _1, _2;
    

    /** 		int = 0*/
    _int_22264 = 0;

    /** 		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_22263)){
            _12941 = SEQ_PTR(_s_22263)->length;
    }
    else {
        _12941 = 1;
    }
    {
        int _i_22266;
        _i_22266 = 1;
L1: 
        if (_i_22266 > _12941){
            goto L2; // [13] 51
        }

        /** 				int *= 10*/
        _int_22264 = _int_22264 * 10;

        /** 				int += s[i] - '0'*/
        _2 = (int)SEQ_PTR(_s_22263);
        _12943 = (int)*(((s1_ptr)_2)->base + _i_22266);
        if (IS_ATOM_INT(_12943)) {
            _12944 = _12943 - 48;
            if ((long)((unsigned long)_12944 +(unsigned long) HIGH_BITS) >= 0){
                _12944 = NewDouble((double)_12944);
            }
        }
        else {
            _12944 = binary_op(MINUS, _12943, 48);
        }
        _12943 = NOVALUE;
        if (IS_ATOM_INT(_12944)) {
            _int_22264 = _int_22264 + _12944;
        }
        else {
            _int_22264 = binary_op(PLUS, _int_22264, _12944);
        }
        DeRef(_12944);
        _12944 = NOVALUE;
        if (!IS_ATOM_INT(_int_22264)) {
            _1 = (long)(DBL_PTR(_int_22264)->dbl);
            DeRefDS(_int_22264);
            _int_22264 = _1;
        }

        /** 		end for*/
        _i_22266 = _i_22266 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** 		return int*/
    DeRefDS(_s_22263);
    return _int_22264;
    ;
}


int _62trim_bits(int _bits_22274)
{
    int _12952 = NOVALUE;
    int _12951 = NOVALUE;
    int _12950 = NOVALUE;
    int _12949 = NOVALUE;
    int _12948 = NOVALUE;
    int _12947 = NOVALUE;
    int _12946 = NOVALUE;
    int _0, _1, _2;
    

    /** 		while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_22274)){
            _12946 = SEQ_PTR(_bits_22274)->length;
    }
    else {
        _12946 = 1;
    }
    if (_12946 == 0) {
        goto L2; // [11] 48
    }
    if (IS_SEQUENCE(_bits_22274)){
            _12948 = SEQ_PTR(_bits_22274)->length;
    }
    else {
        _12948 = 1;
    }
    _2 = (int)SEQ_PTR(_bits_22274);
    _12949 = (int)*(((s1_ptr)_2)->base + _12948);
    if (IS_ATOM_INT(_12949)) {
        _12950 = (_12949 == 0);
    }
    else {
        _12950 = unary_op(NOT, _12949);
    }
    _12949 = NOVALUE;
    if (_12950 <= 0) {
        if (_12950 == 0) {
            DeRef(_12950);
            _12950 = NOVALUE;
            goto L2; // [26] 48
        }
        else {
            if (!IS_ATOM_INT(_12950) && DBL_PTR(_12950)->dbl == 0.0){
                DeRef(_12950);
                _12950 = NOVALUE;
                goto L2; // [26] 48
            }
            DeRef(_12950);
            _12950 = NOVALUE;
        }
    }
    DeRef(_12950);
    _12950 = NOVALUE;

    /** 				bits = bits[1..$-1]*/
    if (IS_SEQUENCE(_bits_22274)){
            _12951 = SEQ_PTR(_bits_22274)->length;
    }
    else {
        _12951 = 1;
    }
    _12952 = _12951 - 1;
    _12951 = NOVALUE;
    rhs_slice_target = (object_ptr)&_bits_22274;
    RHS_Slice(_bits_22274, 1, _12952);

    /** 		end while*/
    goto L1; // [45] 8
L2: 

    /** 		return bits*/
    DeRef(_12952);
    _12952 = NOVALUE;
    return _bits_22274;
    ;
}


int _62scientific_to_float64(int _s_22286)
{
    int _dp_22287 = NOVALUE;
    int _e_22288 = NOVALUE;
    int _exp_22289 = NOVALUE;
    int _int_bits_22290 = NOVALUE;
    int _frac_bits_22291 = NOVALUE;
    int _mbits_22292 = NOVALUE;
    int _ebits_22293 = NOVALUE;
    int _sbits_22294 = NOVALUE;
    int _13096 = NOVALUE;
    int _13095 = NOVALUE;
    int _13093 = NOVALUE;
    int _13091 = NOVALUE;
    int _13090 = NOVALUE;
    int _13089 = NOVALUE;
    int _13087 = NOVALUE;
    int _13086 = NOVALUE;
    int _13085 = NOVALUE;
    int _13084 = NOVALUE;
    int _13083 = NOVALUE;
    int _13082 = NOVALUE;
    int _13081 = NOVALUE;
    int _13079 = NOVALUE;
    int _13078 = NOVALUE;
    int _13077 = NOVALUE;
    int _13076 = NOVALUE;
    int _13074 = NOVALUE;
    int _13073 = NOVALUE;
    int _13072 = NOVALUE;
    int _13071 = NOVALUE;
    int _13070 = NOVALUE;
    int _13069 = NOVALUE;
    int _13068 = NOVALUE;
    int _13065 = NOVALUE;
    int _13062 = NOVALUE;
    int _13061 = NOVALUE;
    int _13060 = NOVALUE;
    int _13055 = NOVALUE;
    int _13054 = NOVALUE;
    int _13052 = NOVALUE;
    int _13051 = NOVALUE;
    int _13049 = NOVALUE;
    int _13047 = NOVALUE;
    int _13046 = NOVALUE;
    int _13045 = NOVALUE;
    int _13044 = NOVALUE;
    int _13043 = NOVALUE;
    int _13042 = NOVALUE;
    int _13041 = NOVALUE;
    int _13040 = NOVALUE;
    int _13038 = NOVALUE;
    int _13037 = NOVALUE;
    int _13036 = NOVALUE;
    int _13035 = NOVALUE;
    int _13033 = NOVALUE;
    int _13031 = NOVALUE;
    int _13030 = NOVALUE;
    int _13029 = NOVALUE;
    int _13028 = NOVALUE;
    int _13027 = NOVALUE;
    int _13025 = NOVALUE;
    int _13024 = NOVALUE;
    int _13023 = NOVALUE;
    int _13022 = NOVALUE;
    int _13021 = NOVALUE;
    int _13020 = NOVALUE;
    int _13018 = NOVALUE;
    int _13017 = NOVALUE;
    int _13016 = NOVALUE;
    int _13015 = NOVALUE;
    int _13014 = NOVALUE;
    int _13012 = NOVALUE;
    int _13011 = NOVALUE;
    int _13009 = NOVALUE;
    int _13008 = NOVALUE;
    int _13007 = NOVALUE;
    int _13006 = NOVALUE;
    int _13005 = NOVALUE;
    int _13003 = NOVALUE;
    int _13001 = NOVALUE;
    int _13000 = NOVALUE;
    int _12998 = NOVALUE;
    int _12997 = NOVALUE;
    int _12995 = NOVALUE;
    int _12992 = NOVALUE;
    int _12991 = NOVALUE;
    int _12990 = NOVALUE;
    int _12989 = NOVALUE;
    int _12988 = NOVALUE;
    int _12986 = NOVALUE;
    int _12985 = NOVALUE;
    int _12984 = NOVALUE;
    int _12983 = NOVALUE;
    int _12981 = NOVALUE;
    int _12980 = NOVALUE;
    int _12979 = NOVALUE;
    int _12978 = NOVALUE;
    int _12976 = NOVALUE;
    int _12975 = NOVALUE;
    int _12973 = NOVALUE;
    int _12972 = NOVALUE;
    int _12971 = NOVALUE;
    int _12970 = NOVALUE;
    int _12968 = NOVALUE;
    int _12967 = NOVALUE;
    int _12961 = NOVALUE;
    int _12959 = NOVALUE;
    int _12956 = NOVALUE;
    int _12954 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if s[1] = '-' then*/
    _2 = (int)SEQ_PTR(_s_22286);
    _12954 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12954, 45)){
        _12954 = NOVALUE;
        goto L1; // [9] 33
    }
    _12954 = NOVALUE;

    /** 				sbits = {1}*/
    RefDS(_12887);
    DeRefi(_sbits_22294);
    _sbits_22294 = _12887;

    /** 				s = s[2..$]*/
    if (IS_SEQUENCE(_s_22286)){
            _12956 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12956 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22286;
    RHS_Slice(_s_22286, 2, _12956);
    goto L2; // [30] 61
L1: 

    /** 				sbits = {0}*/
    _0 = _sbits_22294;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _sbits_22294 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** 				if s[1] = '+' then*/
    _2 = (int)SEQ_PTR(_s_22286);
    _12959 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12959, 43)){
        _12959 = NOVALUE;
        goto L3; // [45] 60
    }
    _12959 = NOVALUE;

    /** 						s = s[2..$]*/
    if (IS_SEQUENCE(_s_22286)){
            _12961 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12961 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22286;
    RHS_Slice(_s_22286, 2, _12961);
L3: 
L2: 

    /** 		dp = find('.', s)*/
    _dp_22287 = find_from(46, _s_22286, 1);

    /** 		e = find( 'e', s )*/
    _e_22288 = find_from(101, _s_22286, 1);

    /** 		if not e then*/
    if (_e_22288 != 0)
    goto L4; // [77] 88

    /** 				e = find('E', s )*/
    _e_22288 = find_from(69, _s_22286, 1);
L4: 

    /** 		exp = 0*/
    _exp_22289 = 0;

    /** 		if s[e+1] = '-' then*/
    _12967 = _e_22288 + 1;
    _2 = (int)SEQ_PTR(_s_22286);
    _12968 = (int)*(((s1_ptr)_2)->base + _12967);
    if (binary_op_a(NOTEQ, _12968, 45)){
        _12968 = NOVALUE;
        goto L5; // [103] 134
    }
    _12968 = NOVALUE;

    /** 				exp -= string_to_int( s[e+2..$] )*/
    _12970 = _e_22288 + 2;
    if ((long)((unsigned long)_12970 + (unsigned long)HIGH_BITS) >= 0) 
    _12970 = NewDouble((double)_12970);
    if (IS_SEQUENCE(_s_22286)){
            _12971 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12971 = 1;
    }
    rhs_slice_target = (object_ptr)&_12972;
    RHS_Slice(_s_22286, _12970, _12971);
    _12973 = _62string_to_int(_12972);
    _12972 = NOVALUE;
    if (IS_ATOM_INT(_12973)) {
        _exp_22289 = _exp_22289 - _12973;
    }
    else {
        _exp_22289 = binary_op(MINUS, _exp_22289, _12973);
    }
    DeRef(_12973);
    _12973 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22289)) {
        _1 = (long)(DBL_PTR(_exp_22289)->dbl);
        DeRefDS(_exp_22289);
        _exp_22289 = _1;
    }
    goto L6; // [131] 201
L5: 

    /** 				if s[e+1] = '+' then*/
    _12975 = _e_22288 + 1;
    _2 = (int)SEQ_PTR(_s_22286);
    _12976 = (int)*(((s1_ptr)_2)->base + _12975);
    if (binary_op_a(NOTEQ, _12976, 43)){
        _12976 = NOVALUE;
        goto L7; // [144] 175
    }
    _12976 = NOVALUE;

    /** 						exp += string_to_int( s[e+2..$] )*/
    _12978 = _e_22288 + 2;
    if ((long)((unsigned long)_12978 + (unsigned long)HIGH_BITS) >= 0) 
    _12978 = NewDouble((double)_12978);
    if (IS_SEQUENCE(_s_22286)){
            _12979 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12979 = 1;
    }
    rhs_slice_target = (object_ptr)&_12980;
    RHS_Slice(_s_22286, _12978, _12979);
    _12981 = _62string_to_int(_12980);
    _12980 = NOVALUE;
    if (IS_ATOM_INT(_12981)) {
        _exp_22289 = _exp_22289 + _12981;
    }
    else {
        _exp_22289 = binary_op(PLUS, _exp_22289, _12981);
    }
    DeRef(_12981);
    _12981 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22289)) {
        _1 = (long)(DBL_PTR(_exp_22289)->dbl);
        DeRefDS(_exp_22289);
        _exp_22289 = _1;
    }
    goto L8; // [172] 200
L7: 

    /** 						exp += string_to_int( s[e+1..$] )*/
    _12983 = _e_22288 + 1;
    if (_12983 > MAXINT){
        _12983 = NewDouble((double)_12983);
    }
    if (IS_SEQUENCE(_s_22286)){
            _12984 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12984 = 1;
    }
    rhs_slice_target = (object_ptr)&_12985;
    RHS_Slice(_s_22286, _12983, _12984);
    _12986 = _62string_to_int(_12985);
    _12985 = NOVALUE;
    if (IS_ATOM_INT(_12986)) {
        _exp_22289 = _exp_22289 + _12986;
    }
    else {
        _exp_22289 = binary_op(PLUS, _exp_22289, _12986);
    }
    DeRef(_12986);
    _12986 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22289)) {
        _1 = (long)(DBL_PTR(_exp_22289)->dbl);
        DeRefDS(_exp_22289);
        _exp_22289 = _1;
    }
L8: 
L6: 

    /** 		if dp then*/
    if (_dp_22287 == 0)
    {
        goto L9; // [203] 252
    }
    else{
    }

    /** 				s = s[1..dp-1] & s[dp+1..$]*/
    _12988 = _dp_22287 - 1;
    rhs_slice_target = (object_ptr)&_12989;
    RHS_Slice(_s_22286, 1, _12988);
    _12990 = _dp_22287 + 1;
    if (_12990 > MAXINT){
        _12990 = NewDouble((double)_12990);
    }
    if (IS_SEQUENCE(_s_22286)){
            _12991 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _12991 = 1;
    }
    rhs_slice_target = (object_ptr)&_12992;
    RHS_Slice(_s_22286, _12990, _12991);
    Concat((object_ptr)&_s_22286, _12989, _12992);
    DeRefDS(_12989);
    _12989 = NOVALUE;
    DeRef(_12989);
    _12989 = NOVALUE;
    DeRefDS(_12992);
    _12992 = NOVALUE;

    /** 				e -= 1*/
    _e_22288 = _e_22288 - 1;

    /** 				exp -= e - dp*/
    _12995 = _e_22288 - _dp_22287;
    if ((long)((unsigned long)_12995 +(unsigned long) HIGH_BITS) >= 0){
        _12995 = NewDouble((double)_12995);
    }
    if (IS_ATOM_INT(_12995)) {
        _exp_22289 = _exp_22289 - _12995;
    }
    else {
        _exp_22289 = NewDouble((double)_exp_22289 - DBL_PTR(_12995)->dbl);
    }
    DeRef(_12995);
    _12995 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22289)) {
        _1 = (long)(DBL_PTR(_exp_22289)->dbl);
        DeRefDS(_exp_22289);
        _exp_22289 = _1;
    }
L9: 

    /** 		s = s[1..e-1] - '0'*/
    _12997 = _e_22288 - 1;
    rhs_slice_target = (object_ptr)&_12998;
    RHS_Slice(_s_22286, 1, _12997);
    DeRefDS(_s_22286);
    _s_22286 = binary_op(MINUS, _12998, 48);
    DeRefDS(_12998);
    _12998 = NOVALUE;

    /** 		if not find(0, s = 0) then*/
    _13000 = binary_op(EQUALS, _s_22286, 0);
    _13001 = find_from(0, _13000, 1);
    DeRefDS(_13000);
    _13000 = NOVALUE;
    if (_13001 != 0)
    goto LA; // [280] 294
    _13001 = NOVALUE;

    /** 			return atom_to_float64(0)*/
    _13003 = _15atom_to_float64(0);
    DeRefDS(_s_22286);
    DeRef(_int_bits_22290);
    DeRef(_frac_bits_22291);
    DeRef(_mbits_22292);
    DeRef(_ebits_22293);
    DeRefi(_sbits_22294);
    DeRef(_12967);
    _12967 = NOVALUE;
    DeRef(_12970);
    _12970 = NOVALUE;
    DeRef(_12975);
    _12975 = NOVALUE;
    DeRef(_12978);
    _12978 = NOVALUE;
    DeRef(_12983);
    _12983 = NOVALUE;
    DeRef(_12988);
    _12988 = NOVALUE;
    _12997 = NOVALUE;
    DeRef(_12990);
    _12990 = NOVALUE;
    return _13003;
LA: 

    /** 		if exp >= 0 then*/
    if (_exp_22289 < 0)
    goto LB; // [296] 340

    /** 				int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _13005 = Repeat(0, _exp_22289);
    RefDS(_s_22286);
    _13006 = _62reverse(_s_22286);
    if (IS_SEQUENCE(_13005) && IS_ATOM(_13006)) {
        Ref(_13006);
        Append(&_13007, _13005, _13006);
    }
    else if (IS_ATOM(_13005) && IS_SEQUENCE(_13006)) {
    }
    else {
        Concat((object_ptr)&_13007, _13005, _13006);
        DeRefDS(_13005);
        _13005 = NOVALUE;
    }
    DeRef(_13005);
    _13005 = NOVALUE;
    DeRef(_13006);
    _13006 = NOVALUE;
    _13008 = _62convert_radix(_13007, 10, 256);
    _13007 = NOVALUE;
    _13009 = _62bytes_to_bits(_13008);
    _13008 = NOVALUE;
    _0 = _int_bits_22290;
    _int_bits_22290 = _62trim_bits(_13009);
    DeRef(_0);
    _13009 = NOVALUE;

    /** 				frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_22291);
    _frac_bits_22291 = _5;
    goto LC; // [337] 451
LB: 

    /** 				if -exp > length(s) then*/
    if ((unsigned long)_exp_22289 == 0xC0000000)
    _13011 = (int)NewDouble((double)-0xC0000000);
    else
    _13011 = - _exp_22289;
    if (IS_SEQUENCE(_s_22286)){
            _13012 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _13012 = 1;
    }
    if (binary_op_a(LESSEQ, _13011, _13012)){
        DeRef(_13011);
        _13011 = NOVALUE;
        _13012 = NOVALUE;
        goto LD; // [348] 388
    }
    DeRef(_13011);
    _13011 = NOVALUE;
    _13012 = NOVALUE;

    /** 						int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_22290);
    _int_bits_22290 = _5;

    /** 						frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s ) */
    if ((unsigned long)_exp_22289 == 0xC0000000)
    _13014 = (int)NewDouble((double)-0xC0000000);
    else
    _13014 = - _exp_22289;
    if (IS_SEQUENCE(_s_22286)){
            _13015 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _13015 = 1;
    }
    if (IS_ATOM_INT(_13014)) {
        _13016 = _13014 - _13015;
    }
    else {
        _13016 = NewDouble(DBL_PTR(_13014)->dbl - (double)_13015);
    }
    DeRef(_13014);
    _13014 = NOVALUE;
    _13015 = NOVALUE;
    _13017 = Repeat(0, _13016);
    DeRef(_13016);
    _13016 = NOVALUE;
    Concat((object_ptr)&_13018, _13017, _s_22286);
    DeRefDS(_13017);
    _13017 = NOVALUE;
    DeRef(_13017);
    _13017 = NOVALUE;
    _0 = _frac_bits_22291;
    _frac_bits_22291 = _62decimals_to_bits(_13018);
    DeRef(_0);
    _13018 = NOVALUE;
    goto LE; // [385] 450
LD: 

    /** 						int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_22286)){
            _13020 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _13020 = 1;
    }
    _13021 = _13020 + _exp_22289;
    _13020 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13022;
    RHS_Slice(_s_22286, 1, _13021);
    _13023 = _62reverse(_13022);
    _13022 = NOVALUE;
    _13024 = _62convert_radix(_13023, 10, 256);
    _13023 = NOVALUE;
    _13025 = _62bytes_to_bits(_13024);
    _13024 = NOVALUE;
    _0 = _int_bits_22290;
    _int_bits_22290 = _62trim_bits(_13025);
    DeRef(_0);
    _13025 = NOVALUE;

    /** 						frac_bits =  decimals_to_bits( s[$+exp+1..$] )*/
    if (IS_SEQUENCE(_s_22286)){
            _13027 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _13027 = 1;
    }
    _13028 = _13027 + _exp_22289;
    if ((long)((unsigned long)_13028 + (unsigned long)HIGH_BITS) >= 0) 
    _13028 = NewDouble((double)_13028);
    _13027 = NOVALUE;
    if (IS_ATOM_INT(_13028)) {
        _13029 = _13028 + 1;
        if (_13029 > MAXINT){
            _13029 = NewDouble((double)_13029);
        }
    }
    else
    _13029 = binary_op(PLUS, 1, _13028);
    DeRef(_13028);
    _13028 = NOVALUE;
    if (IS_SEQUENCE(_s_22286)){
            _13030 = SEQ_PTR(_s_22286)->length;
    }
    else {
        _13030 = 1;
    }
    rhs_slice_target = (object_ptr)&_13031;
    RHS_Slice(_s_22286, _13029, _13030);
    _0 = _frac_bits_22291;
    _frac_bits_22291 = _62decimals_to_bits(_13031);
    DeRef(_0);
    _13031 = NOVALUE;
LE: 
LC: 

    /** 		if length(int_bits) >= 53 then*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13033 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13033 = 1;
    }
    if (_13033 < 53)
    goto LF; // [458] 547

    /** 				mbits = int_bits[$-52..$-1]*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13035 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13035 = 1;
    }
    _13036 = _13035 - 52;
    _13035 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_22290)){
            _13037 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13037 = 1;
    }
    _13038 = _13037 - 1;
    _13037 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22292;
    RHS_Slice(_int_bits_22290, _13036, _13038);

    /** 				if length(int_bits) > 53 and int_bits[$-53] then*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13040 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13040 = 1;
    }
    _13041 = (_13040 > 53);
    _13040 = NOVALUE;
    if (_13041 == 0) {
        goto L10; // [492] 535
    }
    if (IS_SEQUENCE(_int_bits_22290)){
            _13043 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13043 = 1;
    }
    _13044 = _13043 - 53;
    _13043 = NOVALUE;
    _2 = (int)SEQ_PTR(_int_bits_22290);
    _13045 = (int)*(((s1_ptr)_2)->base + _13044);
    if (_13045 == 0) {
        _13045 = NOVALUE;
        goto L10; // [508] 535
    }
    else {
        if (!IS_ATOM_INT(_13045) && DBL_PTR(_13045)->dbl == 0.0){
            _13045 = NOVALUE;
            goto L10; // [508] 535
        }
        _13045 = NOVALUE;
    }
    _13045 = NOVALUE;

    /** 						mbits[1] += 1*/
    _2 = (int)SEQ_PTR(_mbits_22292);
    _13046 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13046)) {
        _13047 = _13046 + 1;
        if (_13047 > MAXINT){
            _13047 = NewDouble((double)_13047);
        }
    }
    else
    _13047 = binary_op(PLUS, 1, _13046);
    _13046 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22292 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _13047;
    if( _1 != _13047 ){
        DeRef(_1);
    }
    _13047 = NOVALUE;

    /** 						mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22292);
    _0 = _mbits_22292;
    _mbits_22292 = _62carry(_mbits_22292, 2);
    DeRefDS(_0);
L10: 

    /** 				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13049 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13049 = 1;
    }
    _exp_22289 = _13049 - 1;
    _13049 = NOVALUE;
    goto L11; // [544] 783
LF: 

    /** 				if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13051 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13051 = 1;
    }
    if (_13051 == 0)
    {
        _13051 = NOVALUE;
        goto L12; // [552] 567
    }
    else{
        _13051 = NOVALUE;
    }

    /** 						exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22290)){
            _13052 = SEQ_PTR(_int_bits_22290)->length;
    }
    else {
        _13052 = 1;
    }
    _exp_22289 = _13052 - 1;
    _13052 = NOVALUE;
    goto L13; // [564] 622
L12: 

    /** 						exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_22291);
    _13054 = _62reverse(_frac_bits_22291);
    _13055 = find_from(1, _13054, 1);
    DeRef(_13054);
    _13054 = NOVALUE;
    _exp_22289 = - _13055;

    /** 						if exp < -1023 then*/
    if (_exp_22289 >= -1023)
    goto L14; // [587] 597

    /** 								exp = -1023*/
    _exp_22289 = -1023;
L14: 

    /** 						if exp then*/
    if (_exp_22289 == 0)
    {
        goto L15; // [599] 621
    }
    else{
    }

    /** 								frac_bits = frac_bits[1..$+exp+1]*/
    if (IS_SEQUENCE(_frac_bits_22291)){
            _13060 = SEQ_PTR(_frac_bits_22291)->length;
    }
    else {
        _13060 = 1;
    }
    _13061 = _13060 + _exp_22289;
    if ((long)((unsigned long)_13061 + (unsigned long)HIGH_BITS) >= 0) 
    _13061 = NewDouble((double)_13061);
    _13060 = NOVALUE;
    if (IS_ATOM_INT(_13061)) {
        _13062 = _13061 + 1;
    }
    else
    _13062 = binary_op(PLUS, 1, _13061);
    DeRef(_13061);
    _13061 = NOVALUE;
    rhs_slice_target = (object_ptr)&_frac_bits_22291;
    RHS_Slice(_frac_bits_22291, 1, _13062);
L15: 
L13: 

    /** 				mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_22292, _frac_bits_22291, _int_bits_22290);

    /** 				mbits = repeat( 0, 53 ) & mbits*/
    _13065 = Repeat(0, 53);
    Concat((object_ptr)&_mbits_22292, _13065, _mbits_22292);
    DeRefDS(_13065);
    _13065 = NOVALUE;
    DeRef(_13065);
    _13065 = NOVALUE;

    /** 				if exp > -1023 then*/
    if (_exp_22289 <= -1023)
    goto L16; // [642] 717

    /** 						if mbits[$-53] then*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13068 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13068 = 1;
    }
    _13069 = _13068 - 53;
    _13068 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    _13070 = (int)*(((s1_ptr)_2)->base + _13069);
    if (_13070 == 0) {
        _13070 = NOVALUE;
        goto L17; // [659] 693
    }
    else {
        if (!IS_ATOM_INT(_13070) && DBL_PTR(_13070)->dbl == 0.0){
            _13070 = NOVALUE;
            goto L17; // [659] 693
        }
        _13070 = NOVALUE;
    }
    _13070 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13071 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13071 = 1;
    }
    _13072 = _13071 - 52;
    _13071 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    _13073 = (int)*(((s1_ptr)_2)->base + _13072);
    if (IS_ATOM_INT(_13073)) {
        _13074 = _13073 + 1;
        if (_13074 > MAXINT){
            _13074 = NewDouble((double)_13074);
        }
    }
    else
    _13074 = binary_op(PLUS, 1, _13073);
    _13073 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22292 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13072);
    _1 = *(int *)_2;
    *(int *)_2 = _13074;
    if( _1 != _13074 ){
        DeRef(_1);
    }
    _13074 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22292);
    _0 = _mbits_22292;
    _mbits_22292 = _62carry(_mbits_22292, 2);
    DeRefDS(_0);
L17: 

    /** 						mbits = mbits[$-52..$-1]*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13076 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13076 = 1;
    }
    _13077 = _13076 - 52;
    _13076 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22292)){
            _13078 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13078 = 1;
    }
    _13079 = _13078 - 1;
    _13078 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22292;
    RHS_Slice(_mbits_22292, _13077, _13079);
    goto L18; // [714] 782
L16: 

    /** 						if mbits[$-52] then*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13081 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13081 = 1;
    }
    _13082 = _13081 - 52;
    _13081 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    _13083 = (int)*(((s1_ptr)_2)->base + _13082);
    if (_13083 == 0) {
        _13083 = NOVALUE;
        goto L19; // [730] 764
    }
    else {
        if (!IS_ATOM_INT(_13083) && DBL_PTR(_13083)->dbl == 0.0){
            _13083 = NOVALUE;
            goto L19; // [730] 764
        }
        _13083 = NOVALUE;
    }
    _13083 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13084 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13084 = 1;
    }
    _13085 = _13084 - 52;
    _13084 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    _13086 = (int)*(((s1_ptr)_2)->base + _13085);
    if (IS_ATOM_INT(_13086)) {
        _13087 = _13086 + 1;
        if (_13087 > MAXINT){
            _13087 = NewDouble((double)_13087);
        }
    }
    else
    _13087 = binary_op(PLUS, 1, _13086);
    _13086 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22292);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22292 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13085);
    _1 = *(int *)_2;
    *(int *)_2 = _13087;
    if( _1 != _13087 ){
        DeRef(_1);
    }
    _13087 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22292);
    _0 = _mbits_22292;
    _mbits_22292 = _62carry(_mbits_22292, 2);
    DeRefDS(_0);
L19: 

    /** 						mbits = mbits[$-51..$]*/
    if (IS_SEQUENCE(_mbits_22292)){
            _13089 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13089 = 1;
    }
    _13090 = _13089 - 51;
    _13089 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22292)){
            _13091 = SEQ_PTR(_mbits_22292)->length;
    }
    else {
        _13091 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_22292;
    RHS_Slice(_mbits_22292, _13090, _13091);
L18: 
L11: 

    /** 		ebits = int_to_bits( exp + 1023, 11 )*/
    _13093 = _exp_22289 + 1023;
    if ((long)((unsigned long)_13093 + (unsigned long)HIGH_BITS) >= 0) 
    _13093 = NewDouble((double)_13093);
    _0 = _ebits_22293;
    _ebits_22293 = _15int_to_bits(_13093, 11);
    DeRef(_0);
    _13093 = NOVALUE;

    /** 		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        int concat_list[3];

        concat_list[0] = _sbits_22294;
        concat_list[1] = _ebits_22293;
        concat_list[2] = _mbits_22292;
        Concat_N((object_ptr)&_13095, concat_list, 3);
    }
    _13096 = _62bits_to_bytes(_13095);
    _13095 = NOVALUE;
    DeRefDS(_s_22286);
    DeRef(_int_bits_22290);
    DeRef(_frac_bits_22291);
    DeRefDS(_mbits_22292);
    DeRefDS(_ebits_22293);
    DeRefDSi(_sbits_22294);
    DeRef(_12988);
    _12988 = NOVALUE;
    DeRef(_12978);
    _12978 = NOVALUE;
    DeRef(_12983);
    _12983 = NOVALUE;
    DeRef(_13036);
    _13036 = NOVALUE;
    DeRef(_13072);
    _13072 = NOVALUE;
    DeRef(_12967);
    _12967 = NOVALUE;
    DeRef(_13003);
    _13003 = NOVALUE;
    DeRef(_13062);
    _13062 = NOVALUE;
    DeRef(_13044);
    _13044 = NOVALUE;
    DeRef(_13090);
    _13090 = NOVALUE;
    DeRef(_13085);
    _13085 = NOVALUE;
    DeRef(_13082);
    _13082 = NOVALUE;
    DeRef(_13077);
    _13077 = NOVALUE;
    DeRef(_13079);
    _13079 = NOVALUE;
    DeRef(_13021);
    _13021 = NOVALUE;
    DeRef(_13069);
    _13069 = NOVALUE;
    DeRef(_12997);
    _12997 = NOVALUE;
    DeRef(_13029);
    _13029 = NOVALUE;
    DeRef(_12970);
    _12970 = NOVALUE;
    DeRef(_12990);
    _12990 = NOVALUE;
    DeRef(_12975);
    _12975 = NOVALUE;
    DeRef(_13041);
    _13041 = NOVALUE;
    DeRef(_13038);
    _13038 = NOVALUE;
    return _13096;
    ;
}


int _62scientific_to_atom(int _s_22467)
{
    int _13098 = NOVALUE;
    int _13097 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return float64_to_atom( scientific_to_float64( s ) )*/
    RefDS(_s_22467);
    _13097 = _62scientific_to_float64(_s_22467);
    _13098 = _15float64_to_atom(_13097);
    _13097 = NOVALUE;
    DeRefDS(_s_22467);
    return _13098;
    ;
}



// 0xEBEF8F79
