// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _28map(int _obj_p_11454)
{
    int _m__11458 = NOVALUE;
    int _6422 = NOVALUE;
    int _6421 = NOVALUE;
    int _6420 = NOVALUE;
    int _6419 = NOVALUE;
    int _6418 = NOVALUE;
    int _6417 = NOVALUE;
    int _6416 = NOVALUE;
    int _6415 = NOVALUE;
    int _6414 = NOVALUE;
    int _6413 = NOVALUE;
    int _6411 = NOVALUE;
    int _6410 = NOVALUE;
    int _6409 = NOVALUE;
    int _6408 = NOVALUE;
    int _6406 = NOVALUE;
    int _6405 = NOVALUE;
    int _6404 = NOVALUE;
    int _6403 = NOVALUE;
    int _6401 = NOVALUE;
    int _6400 = NOVALUE;
    int _6399 = NOVALUE;
    int _6398 = NOVALUE;
    int _6397 = NOVALUE;
    int _6396 = NOVALUE;
    int _6395 = NOVALUE;
    int _6394 = NOVALUE;
    int _6393 = NOVALUE;
    int _6392 = NOVALUE;
    int _6390 = NOVALUE;
    int _6388 = NOVALUE;
    int _6387 = NOVALUE;
    int _6385 = NOVALUE;
    int _6383 = NOVALUE;
    int _6382 = NOVALUE;
    int _6380 = NOVALUE;
    int _6379 = NOVALUE;
    int _6377 = NOVALUE;
    int _6375 = NOVALUE;
    int _6373 = NOVALUE;
    int _6370 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_11454);
    RefDS(_5);
    _6370 = _29valid(_obj_p_11454, _5);
    if (IS_ATOM_INT(_6370)) {
        if (_6370 != 0){
            DeRef(_6370);
            _6370 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_6370)->dbl != 0.0){
            DeRef(_6370);
            _6370 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_6370);
    _6370 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__11458);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_obj_p_11454)){
        _m__11458 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_11454)->dbl));
    }
    else{
        _m__11458 = (int)*(((s1_ptr)_2)->base + _obj_p_11454);
    }
    Ref(_m__11458);

    /** 	if not sequence(m_) then return 0 end if*/
    _6373 = IS_SEQUENCE(_m__11458);
    if (_6373 != 0)
    goto L2; // [31] 39
    _6373 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__11458)){
            _6375 = SEQ_PTR(_m__11458)->length;
    }
    else {
        _6375 = 1;
    }
    if (_6375 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__11458)){
            _6377 = SEQ_PTR(_m__11458)->length;
    }
    else {
        _6377 = 1;
    }
    if (_6377 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6379 = (int)*(((s1_ptr)_2)->base + 1);
    if (_6379 == _28type_is_map_11433)
    _6380 = 1;
    else if (IS_ATOM_INT(_6379) && IS_ATOM_INT(_28type_is_map_11433))
    _6380 = 0;
    else
    _6380 = (compare(_6379, _28type_is_map_11433) == 0);
    _6379 = NOVALUE;
    if (_6380 != 0)
    goto L5; // [77] 85
    _6380 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6382 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6382))
    _6383 = 1;
    else if (IS_ATOM_DBL(_6382))
    _6383 = IS_ATOM_INT(DoubleToInt(_6382));
    else
    _6383 = 0;
    _6382 = NOVALUE;
    if (_6383 != 0)
    goto L6; // [94] 102
    _6383 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6385 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _6385, 0)){
        _6385 = NOVALUE;
        goto L7; // [108] 117
    }
    _6385 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6387 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6387))
    _6388 = 1;
    else if (IS_ATOM_DBL(_6387))
    _6388 = IS_ATOM_INT(DoubleToInt(_6387));
    else
    _6388 = 0;
    _6387 = NOVALUE;
    if (_6388 != 0)
    goto L8; // [126] 134
    _6388 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6390 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _6390, 0)){
        _6390 = NOVALUE;
        goto L9; // [140] 149
    }
    _6390 = NOVALUE;
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6392 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6392 == 115)
    _6393 = 1;
    else if (IS_ATOM_INT(_6392) && IS_ATOM_INT(115))
    _6393 = 0;
    else
    _6393 = (compare(_6392, 115) == 0);
    _6392 = NOVALUE;
    if (_6393 == 0)
    {
        _6393 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _6393 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6394 = (int)*(((s1_ptr)_2)->base + 5);
    _6395 = IS_ATOM(_6394);
    _6394 = NOVALUE;
    if (_6395 == 0)
    {
        _6395 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _6395 = NOVALUE;
    }
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6396 = (int)*(((s1_ptr)_2)->base + 6);
    _6397 = IS_ATOM(_6396);
    _6396 = NOVALUE;
    if (_6397 == 0)
    {
        _6397 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _6397 = NOVALUE;
    }
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6398 = (int)*(((s1_ptr)_2)->base + 7);
    _6399 = IS_ATOM(_6398);
    _6398 = NOVALUE;
    if (_6399 == 0)
    {
        _6399 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _6399 = NOVALUE;
    }
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6400 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6400)){
            _6401 = SEQ_PTR(_6400)->length;
    }
    else {
        _6401 = 1;
    }
    _6400 = NOVALUE;
    if (_6401 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6403 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6403)){
            _6404 = SEQ_PTR(_6403)->length;
    }
    else {
        _6404 = 1;
    }
    _6403 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11458);
    _6405 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6405)){
            _6406 = SEQ_PTR(_6405)->length;
    }
    else {
        _6406 = 1;
    }
    _6405 = NOVALUE;
    if (_6404 == _6406)
    goto LF; // [247] 256
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6408 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6408)){
            _6409 = SEQ_PTR(_6408)->length;
    }
    else {
        _6409 = 1;
    }
    _6408 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11458);
    _6410 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6410)){
            _6411 = SEQ_PTR(_6410)->length;
    }
    else {
        _6411 = 1;
    }
    _6410 = NOVALUE;
    if (_6409 == _6411)
    goto L10; // [272] 366
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6413 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6413 == 76)
    _6414 = 1;
    else if (IS_ATOM_INT(_6413) && IS_ATOM_INT(76))
    _6414 = 0;
    else
    _6414 = (compare(_6413, 76) == 0);
    _6413 = NOVALUE;
    if (_6414 == 0)
    {
        _6414 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _6414 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6415 = (int)*(((s1_ptr)_2)->base + 5);
    _6416 = IS_ATOM(_6415);
    _6415 = NOVALUE;
    if (_6416 == 0)
    {
        _6416 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _6416 = NOVALUE;
    }
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6417 = (int)*(((s1_ptr)_2)->base + 6);
    _6418 = IS_ATOM(_6417);
    _6417 = NOVALUE;
    if (_6418 == 0)
    {
        _6418 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _6418 = NOVALUE;
    }
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__11458);
    _6419 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6419)){
            _6420 = SEQ_PTR(_6419)->length;
    }
    else {
        _6420 = 1;
    }
    _6419 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__11458);
    _6421 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6421)){
            _6422 = SEQ_PTR(_6421)->length;
    }
    else {
        _6422 = 1;
    }
    _6421 = NOVALUE;
    if (_6420 == _6422)
    goto L10; // [347] 366
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    _6419 = NOVALUE;
    _6421 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    _6419 = NOVALUE;
    _6421 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_11454);
    DeRef(_m__11458);
    _6400 = NOVALUE;
    _6403 = NOVALUE;
    _6405 = NOVALUE;
    _6408 = NOVALUE;
    _6410 = NOVALUE;
    _6419 = NOVALUE;
    _6421 = NOVALUE;
    return 1;
    ;
}


void _28rehash(int _the_map_p_11554, int _requested_bucket_size_p_11555)
{
    int _size__11556 = NOVALUE;
    int _index_2__11557 = NOVALUE;
    int _old_key_buckets__11558 = NOVALUE;
    int _old_val_buckets__11559 = NOVALUE;
    int _new_key_buckets__11560 = NOVALUE;
    int _new_val_buckets__11561 = NOVALUE;
    int _key__11562 = NOVALUE;
    int _value__11563 = NOVALUE;
    int _pos_11564 = NOVALUE;
    int _new_keys_11565 = NOVALUE;
    int _in_use_11566 = NOVALUE;
    int _elem_count_11567 = NOVALUE;
    int _calc_hash_1__tmp_at227_11610 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_11609 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_11608 = NOVALUE;
    int _6490 = NOVALUE;
    int _6489 = NOVALUE;
    int _6488 = NOVALUE;
    int _6487 = NOVALUE;
    int _6486 = NOVALUE;
    int _6485 = NOVALUE;
    int _6484 = NOVALUE;
    int _6483 = NOVALUE;
    int _6482 = NOVALUE;
    int _6480 = NOVALUE;
    int _6479 = NOVALUE;
    int _6478 = NOVALUE;
    int _6475 = NOVALUE;
    int _6474 = NOVALUE;
    int _6472 = NOVALUE;
    int _6471 = NOVALUE;
    int _6470 = NOVALUE;
    int _6469 = NOVALUE;
    int _6467 = NOVALUE;
    int _6465 = NOVALUE;
    int _6463 = NOVALUE;
    int _6460 = NOVALUE;
    int _6458 = NOVALUE;
    int _6457 = NOVALUE;
    int _6456 = NOVALUE;
    int _6455 = NOVALUE;
    int _6453 = NOVALUE;
    int _6451 = NOVALUE;
    int _6449 = NOVALUE;
    int _6448 = NOVALUE;
    int _6446 = NOVALUE;
    int _6444 = NOVALUE;
    int _6441 = NOVALUE;
    int _6439 = NOVALUE;
    int _6438 = NOVALUE;
    int _6437 = NOVALUE;
    int _6436 = NOVALUE;
    int _6435 = NOVALUE;
    int _6432 = NOVALUE;
    int _6431 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6431 = (int)*(((s1_ptr)_2)->base + _the_map_p_11554);
    _2 = (int)SEQ_PTR(_6431);
    _6432 = (int)*(((s1_ptr)_2)->base + 4);
    _6431 = NOVALUE;
    if (binary_op_a(NOTEQ, _6432, 115)){
        _6432 = NOVALUE;
        goto L1; // [17] 27
    }
    _6432 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__11558);
    DeRef(_old_val_buckets__11559);
    DeRef(_new_key_buckets__11560);
    DeRef(_new_val_buckets__11561);
    DeRef(_key__11562);
    DeRef(_value__11563);
    DeRef(_new_keys_11565);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_11555 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6435 = (int)*(((s1_ptr)_2)->base + _the_map_p_11554);
    _2 = (int)SEQ_PTR(_6435);
    _6436 = (int)*(((s1_ptr)_2)->base + 5);
    _6435 = NOVALUE;
    if (IS_SEQUENCE(_6436)){
            _6437 = SEQ_PTR(_6436)->length;
    }
    else {
        _6437 = 1;
    }
    _6436 = NOVALUE;
    _6438 = NewDouble((double)_6437 * DBL_PTR(_5946)->dbl);
    _6437 = NOVALUE;
    _6439 = unary_op(FLOOR, _6438);
    DeRefDS(_6438);
    _6438 = NOVALUE;
    if (IS_ATOM_INT(_6439)) {
        _size__11556 = _6439 + 1;
    }
    else
    { // coercing _size__11556 to an integer 1
        _size__11556 = 1+(long)(DBL_PTR(_6439)->dbl);
        if( !IS_ATOM_INT(_size__11556) ){
            _size__11556 = (object)DBL_PTR(_size__11556)->dbl;
        }
    }
    DeRef(_6439);
    _6439 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__11556 = _requested_bucket_size_p_11555;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__11556 == 0xC0000000)
    _6441 = (int)NewDouble((double)-0xC0000000);
    else
    _6441 = - _size__11556;
    _size__11556 = _30next_prime(_size__11556, _6441, 2);
    _6441 = NOVALUE;
    if (!IS_ATOM_INT(_size__11556)) {
        _1 = (long)(DBL_PTR(_size__11556)->dbl);
        DeRefDS(_size__11556);
        _size__11556 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__11556 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__11558);
    DeRef(_old_val_buckets__11559);
    DeRef(_new_key_buckets__11560);
    DeRef(_new_val_buckets__11561);
    DeRef(_key__11562);
    DeRef(_value__11563);
    DeRef(_new_keys_11565);
    _6436 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6444 = (int)*(((s1_ptr)_2)->base + _the_map_p_11554);
    DeRef(_old_key_buckets__11558);
    _2 = (int)SEQ_PTR(_6444);
    _old_key_buckets__11558 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__11558);
    _6444 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6446 = (int)*(((s1_ptr)_2)->base + _the_map_p_11554);
    DeRef(_old_val_buckets__11559);
    _2 = (int)SEQ_PTR(_6446);
    _old_val_buckets__11559 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__11559);
    _6446 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _6448 = 24;
    _6449 = Repeat(1, 24);
    _6448 = NOVALUE;
    DeRef(_new_key_buckets__11560);
    _new_key_buckets__11560 = Repeat(_6449, _size__11556);
    DeRefDS(_6449);
    _6449 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _6451 = Repeat(0, 23);
    DeRef(_new_val_buckets__11561);
    _new_val_buckets__11561 = Repeat(_6451, _size__11556);
    DeRefDS(_6451);
    _6451 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6453 = (int)*(((s1_ptr)_2)->base + _the_map_p_11554);
    _2 = (int)SEQ_PTR(_6453);
    _elem_count_11567 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_11567)){
        _elem_count_11567 = (long)DBL_PTR(_elem_count_11567)->dbl;
    }
    _6453 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_11566 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11554);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__11558)){
            _6455 = SEQ_PTR(_old_key_buckets__11558)->length;
    }
    else {
        _6455 = 1;
    }
    {
        int _index_11597;
        _index_11597 = 1;
L5: 
        if (_index_11597 > _6455){
            goto L6; // [183] 373
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__11558);
        _6456 = (int)*(((s1_ptr)_2)->base + _index_11597);
        if (IS_SEQUENCE(_6456)){
                _6457 = SEQ_PTR(_6456)->length;
        }
        else {
            _6457 = 1;
        }
        _6456 = NOVALUE;
        {
            int _entry_idx_11600;
            _entry_idx_11600 = 1;
L7: 
            if (_entry_idx_11600 > _6457){
                goto L8; // [199] 366
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__11558);
            _6458 = (int)*(((s1_ptr)_2)->base + _index_11597);
            DeRef(_key__11562);
            _2 = (int)SEQ_PTR(_6458);
            _key__11562 = (int)*(((s1_ptr)_2)->base + _entry_idx_11600);
            Ref(_key__11562);
            _6458 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__11559);
            _6460 = (int)*(((s1_ptr)_2)->base + _index_11597);
            DeRef(_value__11563);
            _2 = (int)SEQ_PTR(_6460);
            _value__11563 = (int)*(((s1_ptr)_2)->base + _entry_idx_11600);
            Ref(_value__11563);
            _6460 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_11608);
            _ret__inlined_calc_hash_at_227_11608 = calc_hash(_key__11562, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_11608)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_11608)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_11608);
                _ret__inlined_calc_hash_at_227_11608 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_11610 = (_ret__inlined_calc_hash_at_227_11608 % _size__11556);
            _index_2__11557 = _calc_hash_1__tmp_at227_11610 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_11608);
            _ret__inlined_calc_hash_at_227_11608 = NOVALUE;
            if (!IS_ATOM_INT(_index_2__11557)) {
                _1 = (long)(DBL_PTR(_index_2__11557)->dbl);
                DeRefDS(_index_2__11557);
                _index_2__11557 = _1;
            }

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_11565);
            _2 = (int)SEQ_PTR(_new_key_buckets__11560);
            _new_keys_11565 = (int)*(((s1_ptr)_2)->base + _index_2__11557);
            RefDS(_new_keys_11565);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_11565)){
                    _6463 = SEQ_PTR(_new_keys_11565)->length;
            }
            else {
                _6463 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_11565);
            _pos_11564 = (int)*(((s1_ptr)_2)->base + _6463);
            if (!IS_ATOM_INT(_pos_11564))
            _pos_11564 = (long)DBL_PTR(_pos_11564)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_11565)){
                    _6465 = SEQ_PTR(_new_keys_11565)->length;
            }
            else {
                _6465 = 1;
            }
            if (_6465 != _pos_11564)
            goto L9; // [273] 310

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _6467 = Repeat(_pos_11564, 23);
            Concat((object_ptr)&_new_keys_11565, _new_keys_11565, _6467);
            DeRefDS(_6467);
            _6467 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _6469 = Repeat(0, 23);
            _2 = (int)SEQ_PTR(_new_val_buckets__11561);
            _6470 = (int)*(((s1_ptr)_2)->base + _index_2__11557);
            if (IS_SEQUENCE(_6470) && IS_ATOM(_6469)) {
            }
            else if (IS_ATOM(_6470) && IS_SEQUENCE(_6469)) {
                Ref(_6470);
                Prepend(&_6471, _6469, _6470);
            }
            else {
                Concat((object_ptr)&_6471, _6470, _6469);
                _6470 = NOVALUE;
            }
            _6470 = NOVALUE;
            DeRefDS(_6469);
            _6469 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__11561);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__11561 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__11557);
            _1 = *(int *)_2;
            *(int *)_2 = _6471;
            if( _1 != _6471 ){
                DeRef(_1);
            }
            _6471 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__11562);
            _2 = (int)SEQ_PTR(_new_keys_11565);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_11565 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_11564);
            _1 = *(int *)_2;
            *(int *)_2 = _key__11562;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__11561);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__11561 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__11557 + ((s1_ptr)_2)->base);
            Ref(_value__11563);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_11564);
            _1 = *(int *)_2;
            *(int *)_2 = _value__11563;
            DeRef(_1);
            _6472 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_11565)){
                    _6474 = SEQ_PTR(_new_keys_11565)->length;
            }
            else {
                _6474 = 1;
            }
            _6475 = _pos_11564 + 1;
            if (_6475 > MAXINT){
                _6475 = NewDouble((double)_6475);
            }
            _2 = (int)SEQ_PTR(_new_keys_11565);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_11565 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _6474);
            _1 = *(int *)_2;
            *(int *)_2 = _6475;
            if( _1 != _6475 ){
                DeRef(_1);
            }
            _6475 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_11565);
            _2 = (int)SEQ_PTR(_new_key_buckets__11560);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__11560 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__11557);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_11565;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_11564 != 1)
            goto LA; // [348] 359

            /** 				in_use += 1*/
            _in_use_11566 = _in_use_11566 + 1;
LA: 

            /** 		end for*/
            _entry_idx_11600 = _entry_idx_11600 + 1;
            goto L7; // [361] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_11597 = _index_11597 + 1;
        goto L5; // [368] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__11560)){
            _6478 = SEQ_PTR(_new_key_buckets__11560)->length;
    }
    else {
        _6478 = 1;
    }
    {
        int _index_11630;
        _index_11630 = 1;
LB: 
        if (_index_11630 > _6478){
            goto LC; // [378] 451
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__11560);
        _6479 = (int)*(((s1_ptr)_2)->base + _index_11630);
        if (IS_SEQUENCE(_6479)){
                _6480 = SEQ_PTR(_6479)->length;
        }
        else {
            _6480 = 1;
        }
        _2 = (int)SEQ_PTR(_6479);
        _pos_11564 = (int)*(((s1_ptr)_2)->base + _6480);
        if (!IS_ATOM_INT(_pos_11564)){
            _pos_11564 = (long)DBL_PTR(_pos_11564)->dbl;
        }
        _6479 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__11560);
        _6482 = (int)*(((s1_ptr)_2)->base + _index_11630);
        _2 = (int)SEQ_PTR(_new_key_buckets__11560);
        _6483 = (int)*(((s1_ptr)_2)->base + _index_11630);
        if (IS_SEQUENCE(_6483)){
                _6484 = SEQ_PTR(_6483)->length;
        }
        else {
            _6484 = 1;
        }
        _6483 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6482);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_11564)) ? _pos_11564 : (long)(DBL_PTR(_pos_11564)->dbl);
            int stop = (IS_ATOM_INT(_6484)) ? _6484 : (long)(DBL_PTR(_6484)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6482);
                DeRef(_6485);
                _6485 = _6482;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6482), start, &_6485 );
                }
                else Tail(SEQ_PTR(_6482), stop+1, &_6485);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6482), start, &_6485);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_6485);
                _6485 = _1;
            }
        }
        _6482 = NOVALUE;
        _6484 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__11560);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__11560 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_11630);
        _1 = *(int *)_2;
        *(int *)_2 = _6485;
        if( _1 != _6485 ){
            DeRefDS(_1);
        }
        _6485 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__11561);
        _6486 = (int)*(((s1_ptr)_2)->base + _index_11630);
        _2 = (int)SEQ_PTR(_new_val_buckets__11561);
        _6487 = (int)*(((s1_ptr)_2)->base + _index_11630);
        if (IS_SEQUENCE(_6487)){
                _6488 = SEQ_PTR(_6487)->length;
        }
        else {
            _6488 = 1;
        }
        _6487 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6486);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_11564)) ? _pos_11564 : (long)(DBL_PTR(_pos_11564)->dbl);
            int stop = (IS_ATOM_INT(_6488)) ? _6488 : (long)(DBL_PTR(_6488)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6486);
                DeRef(_6489);
                _6489 = _6486;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6486), start, &_6489 );
                }
                else Tail(SEQ_PTR(_6486), stop+1, &_6489);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6486), start, &_6489);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_6489);
                _6489 = _1;
            }
        }
        _6486 = NOVALUE;
        _6488 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__11561);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__11561 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_11630);
        _1 = *(int *)_2;
        *(int *)_2 = _6489;
        if( _1 != _6489 ){
            DeRef(_1);
        }
        _6489 = NOVALUE;

        /** 	end for*/
        _index_11630 = _index_11630 + 1;
        goto LB; // [446] 385
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11433);
    *((int *)(_2+4)) = _28type_is_map_11433;
    *((int *)(_2+8)) = _elem_count_11567;
    *((int *)(_2+12)) = _in_use_11566;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__11560);
    *((int *)(_2+20)) = _new_key_buckets__11560;
    RefDS(_new_val_buckets__11561);
    *((int *)(_2+24)) = _new_val_buckets__11561;
    _6490 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11554);
    _1 = *(int *)_2;
    *(int *)_2 = _6490;
    if( _1 != _6490 ){
        DeRef(_1);
    }
    _6490 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__11558);
    DeRef(_old_val_buckets__11559);
    DeRefDS(_new_key_buckets__11560);
    DeRefDS(_new_val_buckets__11561);
    DeRef(_key__11562);
    DeRef(_value__11563);
    DeRef(_new_keys_11565);
    _6436 = NOVALUE;
    _6456 = NOVALUE;
    _6483 = NOVALUE;
    _6487 = NOVALUE;
    return;
    ;
}


int _28new(int _initial_size_p_11646)
{
    int _buckets__11648 = NOVALUE;
    int _new_map__11649 = NOVALUE;
    int _temp_map__11650 = NOVALUE;
    int _6503 = NOVALUE;
    int _6502 = NOVALUE;
    int _6501 = NOVALUE;
    int _6499 = NOVALUE;
    int _6498 = NOVALUE;
    int _6495 = NOVALUE;
    int _6494 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_11646 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_11646 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_11646 <= 23)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _6494 = _initial_size_p_11646 + 23;
    if ((long)((unsigned long)_6494 + (unsigned long)HIGH_BITS) >= 0) 
    _6494 = NewDouble((double)_6494);
    if (IS_ATOM_INT(_6494)) {
        _6495 = _6494 - 1;
        if ((long)((unsigned long)_6495 +(unsigned long) HIGH_BITS) >= 0){
            _6495 = NewDouble((double)_6495);
        }
    }
    else {
        _6495 = NewDouble(DBL_PTR(_6494)->dbl - (double)1);
    }
    DeRef(_6494);
    _6494 = NOVALUE;
    if (IS_ATOM_INT(_6495)) {
        if (23 > 0 && _6495 >= 0) {
            _buckets__11648 = _6495 / 23;
        }
        else {
            temp_dbl = floor((double)_6495 / (double)23);
            _buckets__11648 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _6495, 23);
        _buckets__11648 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_6495);
    _6495 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__11648)) {
        _1 = (long)(DBL_PTR(_buckets__11648)->dbl);
        DeRefDS(_buckets__11648);
        _buckets__11648 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__11648 = _30next_prime(_buckets__11648, -1, 1);
    if (!IS_ATOM_INT(_buckets__11648)) {
        _1 = (long)(DBL_PTR(_buckets__11648)->dbl);
        DeRefDS(_buckets__11648);
        _buckets__11648 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _6498 = Repeat(_5, _buckets__11648);
    _6499 = Repeat(_5, _buckets__11648);
    _0 = _new_map__11649;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11433);
    *((int *)(_2+4)) = _28type_is_map_11433;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _6498;
    *((int *)(_2+24)) = _6499;
    _new_map__11649 = MAKE_SEQ(_1);
    DeRef(_0);
    _6499 = NOVALUE;
    _6498 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _6501 = Repeat(_28init_small_map_key_11449, _initial_size_p_11646);
    _6502 = Repeat(0, _initial_size_p_11646);
    _6503 = Repeat(0, _initial_size_p_11646);
    _0 = _new_map__11649;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11433);
    *((int *)(_2+4)) = _28type_is_map_11433;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _6501;
    *((int *)(_2+24)) = _6502;
    *((int *)(_2+28)) = _6503;
    _new_map__11649 = MAKE_SEQ(_1);
    DeRef(_0);
    _6503 = NOVALUE;
    _6502 = NOVALUE;
    _6501 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__11650;
    _temp_map__11650 = _29malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__11649);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__11650))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__11650)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__11650);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__11649;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__11649);
    return _temp_map__11650;
    ;
}


int _28new_extra(int _the_map_p_11670, int _initial_size_p_11671)
{
    int _6507 = NOVALUE;
    int _6506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_11670);
    _6506 = _28map(_the_map_p_11670);
    if (_6506 == 0) {
        DeRef(_6506);
        _6506 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_6506) && DBL_PTR(_6506)->dbl == 0.0){
            DeRef(_6506);
            _6506 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_6506);
        _6506 = NOVALUE;
    }
    DeRef(_6506);
    _6506 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_11670;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _6507 = _28new(_initial_size_p_11671);
    DeRef(_the_map_p_11670);
    return _6507;
L2: 
    ;
}


int _28has(int _the_map_p_11710, int _the_key_p_11711)
{
    int _index__11712 = NOVALUE;
    int _pos__11713 = NOVALUE;
    int _from__11714 = NOVALUE;
    int _calc_hash_1__tmp_at36_11726 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_11725 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_11724 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_11723 = NOVALUE;
    int _6545 = NOVALUE;
    int _6543 = NOVALUE;
    int _6542 = NOVALUE;
    int _6539 = NOVALUE;
    int _6538 = NOVALUE;
    int _6537 = NOVALUE;
    int _6535 = NOVALUE;
    int _6534 = NOVALUE;
    int _6532 = NOVALUE;
    int _6530 = NOVALUE;
    int _6529 = NOVALUE;
    int _6528 = NOVALUE;
    int _6527 = NOVALUE;
    int _6526 = NOVALUE;
    int _6525 = NOVALUE;
    int _6523 = NOVALUE;
    int _6522 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_11710)) {
        _1 = (long)(DBL_PTR(_the_map_p_11710)->dbl);
        DeRefDS(_the_map_p_11710);
        _the_map_p_11710 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6522 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6522);
    _6523 = (int)*(((s1_ptr)_2)->base + 4);
    _6522 = NOVALUE;
    if (binary_op_a(NOTEQ, _6523, 76)){
        _6523 = NOVALUE;
        goto L1; // [15] 86
    }
    _6523 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6525 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6525);
    _6526 = (int)*(((s1_ptr)_2)->base + 5);
    _6525 = NOVALUE;
    if (IS_SEQUENCE(_6526)){
            _6527 = SEQ_PTR(_6526)->length;
    }
    else {
        _6527 = 1;
    }
    _6526 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_11723 = _6527;
    _6527 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_11724);
    _ret__inlined_calc_hash_at_36_11724 = calc_hash(_the_key_p_11711, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_11724)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_11724)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_11724);
        _ret__inlined_calc_hash_at_36_11724 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_11726 = (_ret__inlined_calc_hash_at_36_11724 % _max_hash_p_inlined_calc_hash_at_33_11723);
    _index__11712 = _calc_hash_1__tmp_at36_11726 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_11724);
    _ret__inlined_calc_hash_at_36_11724 = NOVALUE;
    if (!IS_ATOM_INT(_index__11712)) {
        _1 = (long)(DBL_PTR(_index__11712)->dbl);
        DeRefDS(_index__11712);
        _index__11712 = _1;
    }

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6528 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6528);
    _6529 = (int)*(((s1_ptr)_2)->base + 5);
    _6528 = NOVALUE;
    _2 = (int)SEQ_PTR(_6529);
    _6530 = (int)*(((s1_ptr)_2)->base + _index__11712);
    _6529 = NOVALUE;
    _pos__11713 = find_from(_the_key_p_11711, _6530, 1);
    _6530 = NOVALUE;
    goto L2; // [83] 201
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11711 == _28init_small_map_key_11449)
    _6532 = 1;
    else if (IS_ATOM_INT(_the_key_p_11711) && IS_ATOM_INT(_28init_small_map_key_11449))
    _6532 = 0;
    else
    _6532 = (compare(_the_key_p_11711, _28init_small_map_key_11449) == 0);
    if (_6532 == 0)
    {
        _6532 = NOVALUE;
        goto L3; // [92] 182
    }
    else{
        _6532 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11714 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__11714 <= 0)
    goto L5; // [105] 200

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6534 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6534);
    _6535 = (int)*(((s1_ptr)_2)->base + 5);
    _6534 = NOVALUE;
    _pos__11713 = find_from(_the_key_p_11711, _6535, _from__11714);
    _6535 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__11713 == 0)
    {
        goto L6; // [128] 161
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6537 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6537);
    _6538 = (int)*(((s1_ptr)_2)->base + 7);
    _6537 = NOVALUE;
    _2 = (int)SEQ_PTR(_6538);
    _6539 = (int)*(((s1_ptr)_2)->base + _pos__11713);
    _6538 = NOVALUE;
    if (binary_op_a(NOTEQ, _6539, 1)){
        _6539 = NOVALUE;
        goto L7; // [147] 168
    }
    _6539 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_11711);
    _6526 = NOVALUE;
    return 1;
    goto L7; // [158] 168
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_11711);
    _6526 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__11714 = _pos__11713 + 1;

    /** 			end while*/
    goto L4; // [176] 105
    goto L5; // [179] 200
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _6542 = (int)*(((s1_ptr)_2)->base + _the_map_p_11710);
    _2 = (int)SEQ_PTR(_6542);
    _6543 = (int)*(((s1_ptr)_2)->base + 5);
    _6542 = NOVALUE;
    _pos__11713 = find_from(_the_key_p_11711, _6543, 1);
    _6543 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _6545 = (_pos__11713 != 0);
    DeRef(_the_key_p_11711);
    _6526 = NOVALUE;
    return _6545;
    ;
}


int _28get(int _the_map_p_11754, int _the_key_p_11755, int _default_value_p_11756)
{
    int _bucket__11757 = NOVALUE;
    int _pos__11758 = NOVALUE;
    int _from__11759 = NOVALUE;
    int _themap_11760 = NOVALUE;
    int _thekeys_11765 = NOVALUE;
    int _calc_hash_1__tmp_at40_11772 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_11771 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_11770 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_11769 = NOVALUE;
    int _6570 = NOVALUE;
    int _6569 = NOVALUE;
    int _6567 = NOVALUE;
    int _6565 = NOVALUE;
    int _6564 = NOVALUE;
    int _6562 = NOVALUE;
    int _6561 = NOVALUE;
    int _6559 = NOVALUE;
    int _6557 = NOVALUE;
    int _6556 = NOVALUE;
    int _6555 = NOVALUE;
    int _6554 = NOVALUE;
    int _6551 = NOVALUE;
    int _6550 = NOVALUE;
    int _6547 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_11754)) {
        _1 = (long)(DBL_PTR(_the_map_p_11754)->dbl);
        DeRefDS(_the_map_p_11754);
        _the_map_p_11754 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_11760);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _themap_11760 = (int)*(((s1_ptr)_2)->base + _the_map_p_11754);
    Ref(_themap_11760);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6547 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6547, 76)){
        _6547 = NOVALUE;
        goto L1; // [19] 113
    }
    _6547 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_11765);
    _2 = (int)SEQ_PTR(_themap_11760);
    _thekeys_11765 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_11765);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_11765)){
            _6550 = SEQ_PTR(_thekeys_11765)->length;
    }
    else {
        _6550 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_11769 = _6550;
    _6550 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_11770);
    _ret__inlined_calc_hash_at_40_11770 = calc_hash(_the_key_p_11755, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_11770)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_11770)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_11770);
        _ret__inlined_calc_hash_at_40_11770 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_11772 = (_ret__inlined_calc_hash_at_40_11770 % _max_hash_p_inlined_calc_hash_at_37_11769);
    _bucket__11757 = _calc_hash_1__tmp_at40_11772 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_11770);
    _ret__inlined_calc_hash_at_40_11770 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__11757)) {
        _1 = (long)(DBL_PTR(_bucket__11757)->dbl);
        DeRefDS(_bucket__11757);
        _bucket__11757 = _1;
    }

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_11765);
    _6551 = (int)*(((s1_ptr)_2)->base + _bucket__11757);
    _pos__11758 = find_from(_the_key_p_11755, _6551, 1);
    _6551 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__11758 <= 0)
    goto L2; // [79] 102

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6554 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6554);
    _6555 = (int)*(((s1_ptr)_2)->base + _bucket__11757);
    _6554 = NOVALUE;
    _2 = (int)SEQ_PTR(_6555);
    _6556 = (int)*(((s1_ptr)_2)->base + _pos__11758);
    _6555 = NOVALUE;
    Ref(_6556);
    DeRefDS(_thekeys_11765);
    DeRef(_the_key_p_11755);
    DeRef(_default_value_p_11756);
    DeRefDS(_themap_11760);
    return _6556;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_11765);
    DeRef(_the_key_p_11755);
    DeRef(_themap_11760);
    _6556 = NOVALUE;
    return _default_value_p_11756;
    goto L3; // [110] 238
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11755 == _28init_small_map_key_11449)
    _6557 = 1;
    else if (IS_ATOM_INT(_the_key_p_11755) && IS_ATOM_INT(_28init_small_map_key_11449))
    _6557 = 0;
    else
    _6557 = (compare(_the_key_p_11755, _28init_small_map_key_11449) == 0);
    if (_6557 == 0)
    {
        _6557 = NOVALUE;
        goto L4; // [119] 205
    }
    else{
        _6557 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11759 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__11759 <= 0)
    goto L6; // [132] 237

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6559 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__11758 = find_from(_the_key_p_11755, _6559, _from__11759);
    _6559 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__11758 == 0)
    {
        goto L7; // [149] 184
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6561 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6561);
    _6562 = (int)*(((s1_ptr)_2)->base + _pos__11758);
    _6561 = NOVALUE;
    if (binary_op_a(NOTEQ, _6562, 1)){
        _6562 = NOVALUE;
        goto L8; // [162] 191
    }
    _6562 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6564 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6564);
    _6565 = (int)*(((s1_ptr)_2)->base + _pos__11758);
    _6564 = NOVALUE;
    Ref(_6565);
    DeRef(_the_key_p_11755);
    DeRef(_default_value_p_11756);
    DeRefDS(_themap_11760);
    _6556 = NOVALUE;
    return _6565;
    goto L8; // [181] 191
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_11755);
    DeRef(_themap_11760);
    _6556 = NOVALUE;
    _6565 = NOVALUE;
    return _default_value_p_11756;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__11759 = _pos__11758 + 1;

    /** 			end while*/
    goto L5; // [199] 132
    goto L6; // [202] 237
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6567 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__11758 = find_from(_the_key_p_11755, _6567, 1);
    _6567 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__11758 == 0)
    {
        goto L9; // [218] 236
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_11760);
    _6569 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6569);
    _6570 = (int)*(((s1_ptr)_2)->base + _pos__11758);
    _6569 = NOVALUE;
    Ref(_6570);
    DeRef(_the_key_p_11755);
    DeRef(_default_value_p_11756);
    DeRefDS(_themap_11760);
    _6556 = NOVALUE;
    _6565 = NOVALUE;
    return _6570;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_11755);
    DeRef(_themap_11760);
    _6556 = NOVALUE;
    _6565 = NOVALUE;
    _6570 = NOVALUE;
    return _default_value_p_11756;
    ;
}


void _28put(int _the_map_p_11824, int _the_key_p_11825, int _the_value_p_11826, int _operation_p_11827, int _trigger_p_11828)
{
    int _index__11829 = NOVALUE;
    int _bucket__11830 = NOVALUE;
    int _average_length__11831 = NOVALUE;
    int _from__11832 = NOVALUE;
    int _map_data_11833 = NOVALUE;
    int _calc_hash_1__tmp_at46_11844 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_11843 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_11842 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_11841 = NOVALUE;
    int _data_11876 = NOVALUE;
    int _msg_inlined_crash_at_334_11892 = NOVALUE;
    int _msg_inlined_crash_at_379_11898 = NOVALUE;
    int _tmp_seqk_11912 = NOVALUE;
    int _tmp_seqv_11920 = NOVALUE;
    int _msg_inlined_crash_at_721_11956 = NOVALUE;
    int _msg_inlined_crash_at_1079_12019 = NOVALUE;
    int _6714 = NOVALUE;
    int _6713 = NOVALUE;
    int _6711 = NOVALUE;
    int _6710 = NOVALUE;
    int _6709 = NOVALUE;
    int _6708 = NOVALUE;
    int _6706 = NOVALUE;
    int _6705 = NOVALUE;
    int _6704 = NOVALUE;
    int _6702 = NOVALUE;
    int _6701 = NOVALUE;
    int _6700 = NOVALUE;
    int _6698 = NOVALUE;
    int _6697 = NOVALUE;
    int _6696 = NOVALUE;
    int _6694 = NOVALUE;
    int _6693 = NOVALUE;
    int _6692 = NOVALUE;
    int _6690 = NOVALUE;
    int _6688 = NOVALUE;
    int _6682 = NOVALUE;
    int _6681 = NOVALUE;
    int _6680 = NOVALUE;
    int _6679 = NOVALUE;
    int _6677 = NOVALUE;
    int _6675 = NOVALUE;
    int _6674 = NOVALUE;
    int _6673 = NOVALUE;
    int _6672 = NOVALUE;
    int _6671 = NOVALUE;
    int _6670 = NOVALUE;
    int _6667 = NOVALUE;
    int _6665 = NOVALUE;
    int _6662 = NOVALUE;
    int _6660 = NOVALUE;
    int _6657 = NOVALUE;
    int _6656 = NOVALUE;
    int _6654 = NOVALUE;
    int _6651 = NOVALUE;
    int _6650 = NOVALUE;
    int _6647 = NOVALUE;
    int _6644 = NOVALUE;
    int _6642 = NOVALUE;
    int _6640 = NOVALUE;
    int _6637 = NOVALUE;
    int _6635 = NOVALUE;
    int _6634 = NOVALUE;
    int _6633 = NOVALUE;
    int _6632 = NOVALUE;
    int _6631 = NOVALUE;
    int _6630 = NOVALUE;
    int _6629 = NOVALUE;
    int _6628 = NOVALUE;
    int _6627 = NOVALUE;
    int _6621 = NOVALUE;
    int _6619 = NOVALUE;
    int _6618 = NOVALUE;
    int _6616 = NOVALUE;
    int _6614 = NOVALUE;
    int _6611 = NOVALUE;
    int _6610 = NOVALUE;
    int _6609 = NOVALUE;
    int _6608 = NOVALUE;
    int _6606 = NOVALUE;
    int _6605 = NOVALUE;
    int _6604 = NOVALUE;
    int _6602 = NOVALUE;
    int _6601 = NOVALUE;
    int _6600 = NOVALUE;
    int _6598 = NOVALUE;
    int _6597 = NOVALUE;
    int _6596 = NOVALUE;
    int _6594 = NOVALUE;
    int _6592 = NOVALUE;
    int _6587 = NOVALUE;
    int _6586 = NOVALUE;
    int _6585 = NOVALUE;
    int _6584 = NOVALUE;
    int _6582 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_11824)) {
        _1 = (long)(DBL_PTR(_the_map_p_11824)->dbl);
        DeRefDS(_the_map_p_11824);
        _the_map_p_11824 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _map_data_11833 = (int)*(((s1_ptr)_2)->base + _the_map_p_11824);
    Ref(_map_data_11833);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6582 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6582, 76)){
        _6582 = NOVALUE;
        goto L1; // [31] 618
    }
    _6582 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6584 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6584)){
            _6585 = SEQ_PTR(_6584)->length;
    }
    else {
        _6585 = 1;
    }
    _6584 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_11841 = _6585;
    _6585 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_11842);
    _ret__inlined_calc_hash_at_46_11842 = calc_hash(_the_key_p_11825, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_11842)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_11842)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_11842);
        _ret__inlined_calc_hash_at_46_11842 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_11844 = (_ret__inlined_calc_hash_at_46_11842 % _max_hash_p_inlined_calc_hash_at_43_11841);
    _bucket__11830 = _calc_hash_1__tmp_at46_11844 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_11842);
    _ret__inlined_calc_hash_at_46_11842 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__11830)) {
        _1 = (long)(DBL_PTR(_bucket__11830)->dbl);
        DeRefDS(_bucket__11830);
        _bucket__11830 = _1;
    }

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6586 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6586);
    _6587 = (int)*(((s1_ptr)_2)->base + _bucket__11830);
    _6586 = NOVALUE;
    _index__11829 = find_from(_the_key_p_11825, _6587, 1);
    _6587 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__11829 <= 0)
    goto L2; // [89] 368

    /** 			switch operation_p do*/
    _0 = _operation_p_11827;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6592 = NOVALUE;
        Ref(_the_value_p_11826);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_11826;
        DeRef(_1);
        _6592 = NOVALUE;
        goto L3; // [120] 354

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6594 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6596 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6594 = NOVALUE;
        if (IS_ATOM_INT(_6596) && IS_ATOM_INT(_the_value_p_11826)) {
            _6597 = _6596 + _the_value_p_11826;
            if ((long)((unsigned long)_6597 + (unsigned long)HIGH_BITS) >= 0) 
            _6597 = NewDouble((double)_6597);
        }
        else {
            _6597 = binary_op(PLUS, _6596, _the_value_p_11826);
        }
        _6596 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6597;
        if( _1 != _6597 ){
            DeRef(_1);
        }
        _6597 = NOVALUE;
        _6594 = NOVALUE;
        goto L3; // [150] 354

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6598 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6600 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6598 = NOVALUE;
        if (IS_ATOM_INT(_6600) && IS_ATOM_INT(_the_value_p_11826)) {
            _6601 = _6600 - _the_value_p_11826;
            if ((long)((unsigned long)_6601 +(unsigned long) HIGH_BITS) >= 0){
                _6601 = NewDouble((double)_6601);
            }
        }
        else {
            _6601 = binary_op(MINUS, _6600, _the_value_p_11826);
        }
        _6600 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6601;
        if( _1 != _6601 ){
            DeRef(_1);
        }
        _6601 = NOVALUE;
        _6598 = NOVALUE;
        goto L3; // [180] 354

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6602 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6604 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6602 = NOVALUE;
        if (IS_ATOM_INT(_6604) && IS_ATOM_INT(_the_value_p_11826)) {
            if (_6604 == (short)_6604 && _the_value_p_11826 <= INT15 && _the_value_p_11826 >= -INT15)
            _6605 = _6604 * _the_value_p_11826;
            else
            _6605 = NewDouble(_6604 * (double)_the_value_p_11826);
        }
        else {
            _6605 = binary_op(MULTIPLY, _6604, _the_value_p_11826);
        }
        _6604 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6605;
        if( _1 != _6605 ){
            DeRef(_1);
        }
        _6605 = NOVALUE;
        _6602 = NOVALUE;
        goto L3; // [210] 354

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6606 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6608 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6606 = NOVALUE;
        if (IS_ATOM_INT(_6608) && IS_ATOM_INT(_the_value_p_11826)) {
            _6609 = (_6608 % _the_value_p_11826) ? NewDouble((double)_6608 / _the_value_p_11826) : (_6608 / _the_value_p_11826);
        }
        else {
            _6609 = binary_op(DIVIDE, _6608, _the_value_p_11826);
        }
        _6608 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6609;
        if( _1 != _6609 ){
            DeRef(_1);
        }
        _6609 = NOVALUE;
        _6606 = NOVALUE;
        goto L3; // [240] 354

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        _6610 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6610);
        _6611 = (int)*(((s1_ptr)_2)->base + _bucket__11830);
        _6610 = NOVALUE;
        DeRef(_data_11876);
        _2 = (int)SEQ_PTR(_6611);
        _data_11876 = (int)*(((s1_ptr)_2)->base + _index__11829);
        Ref(_data_11876);
        _6611 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_11826);
        Append(&_data_11876, _data_11876, _the_value_p_11826);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6614 = NOVALUE;
        RefDS(_data_11876);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _data_11876;
        DeRef(_1);
        _6614 = NOVALUE;
        DeRefDS(_data_11876);
        _data_11876 = NOVALUE;
        goto L3; // [286] 354

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__11830 + ((s1_ptr)_2)->base);
        _6616 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6618 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6616 = NOVALUE;
        if (IS_SEQUENCE(_6618) && IS_ATOM(_the_value_p_11826)) {
            Ref(_the_value_p_11826);
            Append(&_6619, _6618, _the_value_p_11826);
        }
        else if (IS_ATOM(_6618) && IS_SEQUENCE(_the_value_p_11826)) {
            Ref(_6618);
            Prepend(&_6619, _the_value_p_11826, _6618);
        }
        else {
            Concat((object_ptr)&_6619, _6618, _the_value_p_11826);
            _6618 = NOVALUE;
        }
        _6618 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6619;
        if( _1 != _6619 ){
            DeRef(_1);
        }
        _6619 = NOVALUE;
        _6616 = NOVALUE;
        goto L3; // [316] 354

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_11827 = _operation_p_11827;
        goto L3; // [327] 354

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_334_11892);
        _msg_inlined_crash_at_334_11892 = EPrintf(-9999999, _6620, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_334_11892);

        /** end procedure*/
        goto L4; // [348] 351
L4: 
        DeRefi(_msg_inlined_crash_at_334_11892);
        _msg_inlined_crash_at_334_11892 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11833;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_11912);
    DeRef(_tmp_seqv_11920);
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRefDS(_map_data_11833);
    _6584 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _6621 = find_from(_operation_p_11827, _28INIT_OPERATIONS_11443, 1);
    if (_6621 != 0)
    goto L5; // [375] 399
    _6621 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_379_11898);
    _msg_inlined_crash_at_379_11898 = EPrintf(-9999999, _6623, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_379_11898);

    /** end procedure*/
    goto L6; // [393] 396
L6: 
    DeRefi(_msg_inlined_crash_at_379_11898);
    _msg_inlined_crash_at_379_11898 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_11827 != 8)
    goto L7; // [401] 419

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11833;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_11912);
    DeRef(_tmp_seqv_11920);
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRefDS(_map_data_11833);
    _6584 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_11827 != 6)
    goto L8; // [421] 432

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_11826;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_11826);
    *((int *)(_2+4)) = _the_value_p_11826;
    _the_value_p_11826 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6627 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6627);
    _6628 = (int)*(((s1_ptr)_2)->base + _bucket__11830);
    _6627 = NOVALUE;
    if (IS_SEQUENCE(_6628)){
            _6629 = SEQ_PTR(_6628)->length;
    }
    else {
        _6629 = 1;
    }
    _6628 = NOVALUE;
    _6630 = (_6629 == 0);
    _6629 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6631 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6631)) {
        _6632 = _6631 + _6630;
        if ((long)((unsigned long)_6632 + (unsigned long)HIGH_BITS) >= 0) 
        _6632 = NewDouble((double)_6632);
    }
    else {
        _6632 = binary_op(PLUS, _6631, _6630);
    }
    _6631 = NOVALUE;
    _6630 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6632;
    if( _1 != _6632 ){
        DeRef(_1);
    }
    _6632 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6633 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6633)) {
        _6634 = _6633 + 1;
        if (_6634 > MAXINT){
            _6634 = NewDouble((double)_6634);
        }
    }
    else
    _6634 = binary_op(PLUS, 1, _6633);
    _6633 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6634;
    if( _1 != _6634 ){
        DeRef(_1);
    }
    _6634 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6635 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_11912);
    _2 = (int)SEQ_PTR(_6635);
    _tmp_seqk_11912 = (int)*(((s1_ptr)_2)->base + _bucket__11830);
    Ref(_tmp_seqk_11912);
    _6635 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11830);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6637 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_11825);
    Append(&_tmp_seqk_11912, _tmp_seqk_11912, _the_key_p_11825);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_11912);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11830);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_11912;
    DeRef(_1);
    _6640 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6642 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_11920);
    _2 = (int)SEQ_PTR(_6642);
    _tmp_seqv_11920 = (int)*(((s1_ptr)_2)->base + _bucket__11830);
    Ref(_tmp_seqv_11920);
    _6642 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11830);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6644 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_11826);
    Append(&_tmp_seqv_11920, _tmp_seqv_11920, _the_value_p_11826);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_11920);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__11830);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_11920;
    DeRef(_1);
    _6647 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11833;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_11828 <= 0)
    goto L9; // [569] 608

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6650 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6651 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__11831);
    if (IS_ATOM_INT(_6650) && IS_ATOM_INT(_6651)) {
        _average_length__11831 = (_6650 % _6651) ? NewDouble((double)_6650 / _6651) : (_6650 / _6651);
    }
    else {
        _average_length__11831 = binary_op(DIVIDE, _6650, _6651);
    }
    _6650 = NOVALUE;
    _6651 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__11831, _trigger_p_11828)){
        goto LA; // [589] 607
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_11833);
    _map_data_11833 = _5;

    /** 				rehash(the_map_p)*/
    _28rehash(_the_map_p_11824, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_11912);
    DeRef(_tmp_seqv_11920);
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRef(_map_data_11833);
    _6584 = NOVALUE;
    _6628 = NOVALUE;
    return;
    goto LB; // [615] 1112
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_11825 == _28init_small_map_key_11449)
    _6654 = 1;
    else if (IS_ATOM_INT(_the_key_p_11825) && IS_ATOM_INT(_28init_small_map_key_11449))
    _6654 = 0;
    else
    _6654 = (compare(_the_key_p_11825, _28init_small_map_key_11449) == 0);
    if (_6654 == 0)
    {
        _6654 = NOVALUE;
        goto LC; // [624] 690
    }
    else{
        _6654 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__11832 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [634] 671
LE: 
    if (_index__11829 <= 0)
    goto LF; // [639] 702

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6656 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6656);
    _6657 = (int)*(((s1_ptr)_2)->base + _index__11829);
    _6656 = NOVALUE;
    if (binary_op_a(NOTEQ, _6657, 1)){
        _6657 = NOVALUE;
        goto L10; // [653] 662
    }
    _6657 = NOVALUE;

    /** 					exit*/
    goto LF; // [659] 702
L10: 

    /** 				from_ = index_ + 1*/
    _from__11832 = _index__11829 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6660 = (int)*(((s1_ptr)_2)->base + 5);
    _index__11829 = find_from(_the_key_p_11825, _6660, _from__11832);
    _6660 = NOVALUE;

    /** 			end while*/
    goto LE; // [684] 637
    goto LF; // [687] 702
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6662 = (int)*(((s1_ptr)_2)->base + 5);
    _index__11829 = find_from(_the_key_p_11825, _6662, 1);
    _6662 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__11829 != 0)
    goto L11; // [706] 884

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _6665 = find_from(_operation_p_11827, _28INIT_OPERATIONS_11443, 1);
    if (_6665 != 0)
    goto L12; // [717] 741
    _6665 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_721_11956);
    _msg_inlined_crash_at_721_11956 = EPrintf(-9999999, _6623, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_721_11956);

    /** end procedure*/
    goto L13; // [735] 738
L13: 
    DeRefi(_msg_inlined_crash_at_721_11956);
    _msg_inlined_crash_at_721_11956 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6667 = (int)*(((s1_ptr)_2)->base + 7);
    _index__11829 = find_from(0, _6667, 1);
    _6667 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__11829 != 0)
    goto L14; // [754] 808

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11833;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_11833);
    _map_data_11833 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _28convert_to_large_map(_the_map_p_11824);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_6670);
    _6670 = _the_map_p_11824;
    Ref(_the_key_p_11825);
    DeRef(_6671);
    _6671 = _the_key_p_11825;
    Ref(_the_value_p_11826);
    DeRef(_6672);
    _6672 = _the_value_p_11826;
    DeRef(_6673);
    _6673 = _operation_p_11827;
    DeRef(_6674);
    _6674 = _trigger_p_11828;
    _28put(_6670, _6671, _6672, _6673, _6674);
    _6670 = NOVALUE;
    _6671 = NOVALUE;
    _6672 = NOVALUE;
    _6673 = NOVALUE;
    _6674 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRefDS(_map_data_11833);
    _6584 = NOVALUE;
    _6628 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_11825);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__11829);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_11825;
    DeRef(_1);
    _6675 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__11829);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _6677 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6679 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6679)) {
        _6680 = _6679 + 1;
        if (_6680 > MAXINT){
            _6680 = NewDouble((double)_6680);
        }
    }
    else
    _6680 = binary_op(PLUS, 1, _6679);
    _6679 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6680;
    if( _1 != _6680 ){
        DeRef(_1);
    }
    _6680 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_11833);
    _6681 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6681)) {
        _6682 = _6681 + 1;
        if (_6682 > MAXINT){
            _6682 = NewDouble((double)_6682);
        }
    }
    else
    _6682 = binary_op(PLUS, 1, _6681);
    _6681 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_11833);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_11833 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6682;
    if( _1 != _6682 ){
        DeRef(_1);
    }
    _6682 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_11827 != 6)
    goto L15; // [860] 871

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_11826;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_11826);
    *((int *)(_2+4)) = _the_value_p_11826;
    _the_value_p_11826 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_11827 == 8)
    goto L16; // [873] 883

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_11827 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_11827;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_11826);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_11826;
        DeRef(_1);
        _6688 = NOVALUE;
        goto L17; // [906] 1098

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6692 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6690 = NOVALUE;
        if (IS_ATOM_INT(_6692) && IS_ATOM_INT(_the_value_p_11826)) {
            _6693 = _6692 + _the_value_p_11826;
            if ((long)((unsigned long)_6693 + (unsigned long)HIGH_BITS) >= 0) 
            _6693 = NewDouble((double)_6693);
        }
        else {
            _6693 = binary_op(PLUS, _6692, _the_value_p_11826);
        }
        _6692 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6693;
        if( _1 != _6693 ){
            DeRef(_1);
        }
        _6693 = NOVALUE;
        _6690 = NOVALUE;
        goto L17; // [931] 1098

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6696 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6694 = NOVALUE;
        if (IS_ATOM_INT(_6696) && IS_ATOM_INT(_the_value_p_11826)) {
            _6697 = _6696 - _the_value_p_11826;
            if ((long)((unsigned long)_6697 +(unsigned long) HIGH_BITS) >= 0){
                _6697 = NewDouble((double)_6697);
            }
        }
        else {
            _6697 = binary_op(MINUS, _6696, _the_value_p_11826);
        }
        _6696 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6697;
        if( _1 != _6697 ){
            DeRef(_1);
        }
        _6697 = NOVALUE;
        _6694 = NOVALUE;
        goto L17; // [956] 1098

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6700 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6698 = NOVALUE;
        if (IS_ATOM_INT(_6700) && IS_ATOM_INT(_the_value_p_11826)) {
            if (_6700 == (short)_6700 && _the_value_p_11826 <= INT15 && _the_value_p_11826 >= -INT15)
            _6701 = _6700 * _the_value_p_11826;
            else
            _6701 = NewDouble(_6700 * (double)_the_value_p_11826);
        }
        else {
            _6701 = binary_op(MULTIPLY, _6700, _the_value_p_11826);
        }
        _6700 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6701;
        if( _1 != _6701 ){
            DeRef(_1);
        }
        _6701 = NOVALUE;
        _6698 = NOVALUE;
        goto L17; // [981] 1098

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6704 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6702 = NOVALUE;
        if (IS_ATOM_INT(_6704) && IS_ATOM_INT(_the_value_p_11826)) {
            _6705 = (_6704 % _the_value_p_11826) ? NewDouble((double)_6704 / _the_value_p_11826) : (_6704 / _the_value_p_11826);
        }
        else {
            _6705 = binary_op(DIVIDE, _6704, _the_value_p_11826);
        }
        _6704 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6705;
        if( _1 != _6705 ){
            DeRef(_1);
        }
        _6705 = NOVALUE;
        _6702 = NOVALUE;
        goto L17; // [1006] 1098

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_11833);
        _6708 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6708);
        _6709 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6708 = NOVALUE;
        Ref(_the_value_p_11826);
        Append(&_6710, _6709, _the_value_p_11826);
        _6709 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6710;
        if( _1 != _6710 ){
            DeRef(_1);
        }
        _6710 = NOVALUE;
        _6706 = NOVALUE;
        goto L17; // [1035] 1098

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_11833);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_11833 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _6713 = (int)*(((s1_ptr)_2)->base + _index__11829);
        _6711 = NOVALUE;
        if (IS_SEQUENCE(_6713) && IS_ATOM(_the_value_p_11826)) {
            Ref(_the_value_p_11826);
            Append(&_6714, _6713, _the_value_p_11826);
        }
        else if (IS_ATOM(_6713) && IS_SEQUENCE(_the_value_p_11826)) {
            Ref(_6713);
            Prepend(&_6714, _the_value_p_11826, _6713);
        }
        else {
            Concat((object_ptr)&_6714, _6713, _the_value_p_11826);
            _6713 = NOVALUE;
        }
        _6713 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__11829);
        _1 = *(int *)_2;
        *(int *)_2 = _6714;
        if( _1 != _6714 ){
            DeRef(_1);
        }
        _6714 = NOVALUE;
        _6711 = NOVALUE;
        goto L17; // [1060] 1098

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_11827 = _operation_p_11827;
        goto L17; // [1071] 1098

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1079_12019);
        _msg_inlined_crash_at_1079_12019 = EPrintf(-9999999, _6620, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1079_12019);

        /** end procedure*/
        goto L18; // [1092] 1095
L18: 
        DeRefi(_msg_inlined_crash_at_1079_12019);
        _msg_inlined_crash_at_1079_12019 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_11833);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_11824);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_11833;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRefDS(_map_data_11833);
    _6584 = NOVALUE;
    _6628 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_11825);
    DeRef(_the_value_p_11826);
    DeRef(_average_length__11831);
    DeRef(_map_data_11833);
    _6584 = NOVALUE;
    _6628 = NOVALUE;
    return;
    ;
}


void _28nested_put(int _the_map_p_12022, int _the_keys_p_12023, int _the_value_p_12024, int _operation_p_12025, int _trigger_p_12026)
{
    int _temp_map__12027 = NOVALUE;
    int _6726 = NOVALUE;
    int _6725 = NOVALUE;
    int _6724 = NOVALUE;
    int _6723 = NOVALUE;
    int _6722 = NOVALUE;
    int _6721 = NOVALUE;
    int _6719 = NOVALUE;
    int _6718 = NOVALUE;
    int _6717 = NOVALUE;
    int _6715 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_12023)){
            _6715 = SEQ_PTR(_the_keys_p_12023)->length;
    }
    else {
        _6715 = 1;
    }
    if (_6715 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12023);
    _6717 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12022);
    Ref(_6717);
    Ref(_the_value_p_12024);
    _28put(_the_map_p_12022, _6717, _the_value_p_12024, _operation_p_12025, _trigger_p_12026);
    _6717 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12023);
    _6718 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12022);
    Ref(_6718);
    _6719 = _28get(_the_map_p_12022, _6718, 0);
    _6718 = NOVALUE;
    _0 = _temp_map__12027;
    _temp_map__12027 = _28new_extra(_6719, 690);
    DeRef(_0);
    _6719 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_12023)){
            _6721 = SEQ_PTR(_the_keys_p_12023)->length;
    }
    else {
        _6721 = 1;
    }
    rhs_slice_target = (object_ptr)&_6722;
    RHS_Slice(_the_keys_p_12023, 2, _6721);
    Ref(_the_value_p_12024);
    DeRef(_6723);
    _6723 = _the_value_p_12024;
    DeRef(_6724);
    _6724 = _operation_p_12025;
    DeRef(_6725);
    _6725 = _trigger_p_12026;
    Ref(_temp_map__12027);
    _28nested_put(_temp_map__12027, _6722, _6723, _6724, _6725);
    _6722 = NOVALUE;
    _6723 = NOVALUE;
    _6724 = NOVALUE;
    _6725 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_12023);
    _6726 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_12022);
    Ref(_6726);
    Ref(_temp_map__12027);
    _28put(_the_map_p_12022, _6726, _temp_map__12027, 1, _trigger_p_12026);
    _6726 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_12022);
    DeRefDS(_the_keys_p_12023);
    DeRef(_the_value_p_12024);
    DeRef(_temp_map__12027);
    return;
    ;
}


void _28remove(int _the_map_p_12044, int _the_key_p_12045)
{
    int _index__12046 = NOVALUE;
    int _bucket__12047 = NOVALUE;
    int _temp_map__12048 = NOVALUE;
    int _from__12049 = NOVALUE;
    int _calc_hash_1__tmp_at40_12060 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_12059 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_12058 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_12057 = NOVALUE;
    int _6791 = NOVALUE;
    int _6790 = NOVALUE;
    int _6789 = NOVALUE;
    int _6788 = NOVALUE;
    int _6786 = NOVALUE;
    int _6784 = NOVALUE;
    int _6782 = NOVALUE;
    int _6780 = NOVALUE;
    int _6779 = NOVALUE;
    int _6777 = NOVALUE;
    int _6774 = NOVALUE;
    int _6773 = NOVALUE;
    int _6772 = NOVALUE;
    int _6771 = NOVALUE;
    int _6770 = NOVALUE;
    int _6769 = NOVALUE;
    int _6768 = NOVALUE;
    int _6767 = NOVALUE;
    int _6766 = NOVALUE;
    int _6765 = NOVALUE;
    int _6764 = NOVALUE;
    int _6763 = NOVALUE;
    int _6762 = NOVALUE;
    int _6760 = NOVALUE;
    int _6759 = NOVALUE;
    int _6758 = NOVALUE;
    int _6757 = NOVALUE;
    int _6756 = NOVALUE;
    int _6755 = NOVALUE;
    int _6754 = NOVALUE;
    int _6753 = NOVALUE;
    int _6752 = NOVALUE;
    int _6751 = NOVALUE;
    int _6750 = NOVALUE;
    int _6748 = NOVALUE;
    int _6746 = NOVALUE;
    int _6744 = NOVALUE;
    int _6743 = NOVALUE;
    int _6742 = NOVALUE;
    int _6740 = NOVALUE;
    int _6739 = NOVALUE;
    int _6738 = NOVALUE;
    int _6737 = NOVALUE;
    int _6736 = NOVALUE;
    int _6733 = NOVALUE;
    int _6732 = NOVALUE;
    int _6731 = NOVALUE;
    int _6730 = NOVALUE;
    int _6728 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12048);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_the_map_p_12044)){
        _temp_map__12048 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12044)->dbl));
    }
    else{
        _temp_map__12048 = (int)*(((s1_ptr)_2)->base + _the_map_p_12044);
    }
    Ref(_temp_map__12048);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12044))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12044)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12044);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6728 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6728, 76)){
        _6728 = NOVALUE;
        goto L1; // [25] 305
    }
    _6728 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6730 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6730)){
            _6731 = SEQ_PTR(_6730)->length;
    }
    else {
        _6731 = 1;
    }
    _6730 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_12057 = _6731;
    _6731 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_12058);
    _ret__inlined_calc_hash_at_40_12058 = calc_hash(_the_key_p_12045, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_12058)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_12058)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_12058);
        _ret__inlined_calc_hash_at_40_12058 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_12060 = (_ret__inlined_calc_hash_at_40_12058 % _max_hash_p_inlined_calc_hash_at_37_12057);
    _bucket__12047 = _calc_hash_1__tmp_at40_12060 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_12058);
    _ret__inlined_calc_hash_at_40_12058 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__12047)) {
        _1 = (long)(DBL_PTR(_bucket__12047)->dbl);
        DeRefDS(_bucket__12047);
        _bucket__12047 = _1;
    }

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6732 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6732);
    _6733 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6732 = NOVALUE;
    _index__12046 = find_from(_the_key_p_12045, _6733, 1);
    _6733 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__12046 == 0)
    goto L2; // [83] 431

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6736 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6736)) {
        _6737 = _6736 - 1;
        if ((long)((unsigned long)_6737 +(unsigned long) HIGH_BITS) >= 0){
            _6737 = NewDouble((double)_6737);
        }
    }
    else {
        _6737 = binary_op(MINUS, _6736, 1);
    }
    _6736 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6737;
    if( _1 != _6737 ){
        DeRef(_1);
    }
    _6737 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6738 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6738);
    _6739 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6738 = NOVALUE;
    if (IS_SEQUENCE(_6739)){
            _6740 = SEQ_PTR(_6739)->length;
    }
    else {
        _6740 = 1;
    }
    _6739 = NOVALUE;
    if (_6740 != 1)
    goto L3; // [114] 157

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6742 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6742)) {
        _6743 = _6742 - 1;
        if ((long)((unsigned long)_6743 +(unsigned long) HIGH_BITS) >= 0){
            _6743 = NewDouble((double)_6743);
        }
    }
    else {
        _6743 = binary_op(MINUS, _6742, 1);
    }
    _6742 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6743;
    if( _1 != _6743 ){
        DeRef(_1);
    }
    _6743 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12047);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _6744 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12047);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _6746 = NOVALUE;
    goto L4; // [154] 262
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6750 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6750);
    _6751 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6750 = NOVALUE;
    _6752 = _index__12046 - 1;
    rhs_slice_target = (object_ptr)&_6753;
    RHS_Slice(_6751, 1, _6752);
    _6751 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6754 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_6754);
    _6755 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6754 = NOVALUE;
    _6756 = _index__12046 + 1;
    if (_6756 > MAXINT){
        _6756 = NewDouble((double)_6756);
    }
    if (IS_SEQUENCE(_6755)){
            _6757 = SEQ_PTR(_6755)->length;
    }
    else {
        _6757 = 1;
    }
    rhs_slice_target = (object_ptr)&_6758;
    RHS_Slice(_6755, _6756, _6757);
    _6755 = NOVALUE;
    Concat((object_ptr)&_6759, _6753, _6758);
    DeRefDS(_6753);
    _6753 = NOVALUE;
    DeRef(_6753);
    _6753 = NOVALUE;
    DeRefDS(_6758);
    _6758 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12047);
    _1 = *(int *)_2;
    *(int *)_2 = _6759;
    if( _1 != _6759 ){
        DeRef(_1);
    }
    _6759 = NOVALUE;
    _6748 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6762 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6762);
    _6763 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6762 = NOVALUE;
    _6764 = _index__12046 - 1;
    rhs_slice_target = (object_ptr)&_6765;
    RHS_Slice(_6763, 1, _6764);
    _6763 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6766 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_6766);
    _6767 = (int)*(((s1_ptr)_2)->base + _bucket__12047);
    _6766 = NOVALUE;
    _6768 = _index__12046 + 1;
    if (_6768 > MAXINT){
        _6768 = NewDouble((double)_6768);
    }
    if (IS_SEQUENCE(_6767)){
            _6769 = SEQ_PTR(_6767)->length;
    }
    else {
        _6769 = 1;
    }
    rhs_slice_target = (object_ptr)&_6770;
    RHS_Slice(_6767, _6768, _6769);
    _6767 = NOVALUE;
    Concat((object_ptr)&_6771, _6765, _6770);
    DeRefDS(_6765);
    _6765 = NOVALUE;
    DeRef(_6765);
    _6765 = NOVALUE;
    DeRefDS(_6770);
    _6770 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__12047);
    _1 = *(int *)_2;
    *(int *)_2 = _6771;
    if( _1 != _6771 ){
        DeRef(_1);
    }
    _6771 = NOVALUE;
    _6760 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6772 = (int)*(((s1_ptr)_2)->base + 2);
    _6773 = 1173;
    _6774 = 11;
    _6773 = NOVALUE;
    if (binary_op_a(GREATEREQ, _6772, 11)){
        _6772 = NOVALUE;
        _6774 = NOVALUE;
        goto L2; // [278] 431
    }
    _6772 = NOVALUE;
    DeRef(_6774);
    _6774 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12048);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12044))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12044)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12044);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12048;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_12044);
    _28convert_to_small_map(_the_map_p_12044);

    /** 				return*/
    DeRef(_the_map_p_12044);
    DeRef(_the_key_p_12045);
    DeRefDS(_temp_map__12048);
    _6730 = NOVALUE;
    _6739 = NOVALUE;
    DeRef(_6752);
    _6752 = NOVALUE;
    DeRef(_6764);
    _6764 = NOVALUE;
    DeRef(_6756);
    _6756 = NOVALUE;
    DeRef(_6768);
    _6768 = NOVALUE;
    return;
    goto L2; // [302] 431
L1: 

    /** 		from_ = 1*/
    _from__12049 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__12049 <= 0)
    goto L6; // [315] 430

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6777 = (int)*(((s1_ptr)_2)->base + 5);
    _index__12046 = find_from(_the_key_p_12045, _6777, _from__12049);
    _6777 = NOVALUE;

    /** 			if index_ then*/
    if (_index__12046 == 0)
    {
        goto L6; // [332] 430
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6779 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_6779);
    _6780 = (int)*(((s1_ptr)_2)->base + _index__12046);
    _6779 = NOVALUE;
    if (binary_op_a(NOTEQ, _6780, 1)){
        _6780 = NOVALUE;
        goto L7; // [345] 419
    }
    _6780 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12046);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6782 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_28init_small_map_key_11449);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12046);
    _1 = *(int *)_2;
    *(int *)_2 = _28init_small_map_key_11449;
    DeRef(_1);
    _6784 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__12046);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _6786 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6788 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6788)) {
        _6789 = _6788 - 1;
        if ((long)((unsigned long)_6789 +(unsigned long) HIGH_BITS) >= 0){
            _6789 = NewDouble((double)_6789);
        }
    }
    else {
        _6789 = binary_op(MINUS, _6788, 1);
    }
    _6788 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _6789;
    if( _1 != _6789 ){
        DeRef(_1);
    }
    _6789 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__12048);
    _6790 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6790)) {
        _6791 = _6790 - 1;
        if ((long)((unsigned long)_6791 +(unsigned long) HIGH_BITS) >= 0){
            _6791 = NewDouble((double)_6791);
        }
    }
    else {
        _6791 = binary_op(MINUS, _6790, 1);
    }
    _6790 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12048);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12048 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _6791;
    if( _1 != _6791 ){
        DeRef(_1);
    }
    _6791 = NOVALUE;
    goto L7; // [411] 419

    /** 				exit*/
    goto L6; // [416] 430
L7: 

    /** 			from_ = index_ + 1*/
    _from__12049 = _index__12046 + 1;

    /** 		end while*/
    goto L5; // [427] 315
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12048);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12044))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12044)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12044);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12048;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_12044);
    DeRef(_the_key_p_12045);
    DeRefDS(_temp_map__12048);
    _6730 = NOVALUE;
    _6739 = NOVALUE;
    DeRef(_6752);
    _6752 = NOVALUE;
    DeRef(_6764);
    _6764 = NOVALUE;
    DeRef(_6756);
    _6756 = NOVALUE;
    DeRef(_6768);
    _6768 = NOVALUE;
    return;
    ;
}


void _28clear(int _the_map_p_12134)
{
    int _temp_map__12135 = NOVALUE;
    int _6810 = NOVALUE;
    int _6809 = NOVALUE;
    int _6808 = NOVALUE;
    int _6807 = NOVALUE;
    int _6806 = NOVALUE;
    int _6805 = NOVALUE;
    int _6804 = NOVALUE;
    int _6803 = NOVALUE;
    int _6802 = NOVALUE;
    int _6801 = NOVALUE;
    int _6800 = NOVALUE;
    int _6799 = NOVALUE;
    int _6798 = NOVALUE;
    int _6797 = NOVALUE;
    int _6796 = NOVALUE;
    int _6794 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12135);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_the_map_p_12134)){
        _temp_map__12135 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12134)->dbl));
    }
    else{
        _temp_map__12135 = (int)*(((s1_ptr)_2)->base + _the_map_p_12134);
    }
    Ref(_temp_map__12135);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6794 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6794, 76)){
        _6794 = NOVALUE;
        goto L1; // [17] 70
    }
    _6794 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6796 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6796)){
            _6797 = SEQ_PTR(_6796)->length;
    }
    else {
        _6797 = 1;
    }
    _6796 = NOVALUE;
    _6798 = Repeat(_5, _6797);
    _6797 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _6798;
    if( _1 != _6798 ){
        DeRef(_1);
    }
    _6798 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6799 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6799)){
            _6800 = SEQ_PTR(_6799)->length;
    }
    else {
        _6800 = 1;
    }
    _6799 = NOVALUE;
    _6801 = Repeat(_5, _6800);
    _6800 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _6801;
    if( _1 != _6801 ){
        DeRef(_1);
    }
    _6801 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6802 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6802)){
            _6803 = SEQ_PTR(_6802)->length;
    }
    else {
        _6803 = 1;
    }
    _6802 = NOVALUE;
    _6804 = Repeat(_28init_small_map_key_11449, _6803);
    _6803 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _6804;
    if( _1 != _6804 ){
        DeRef(_1);
    }
    _6804 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6805 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6805)){
            _6806 = SEQ_PTR(_6805)->length;
    }
    else {
        _6806 = 1;
    }
    _6805 = NOVALUE;
    _6807 = Repeat(0, _6806);
    _6806 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _6807;
    if( _1 != _6807 ){
        DeRef(_1);
    }
    _6807 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__12135);
    _6808 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6808)){
            _6809 = SEQ_PTR(_6808)->length;
    }
    else {
        _6809 = 1;
    }
    _6808 = NOVALUE;
    _6810 = Repeat(0, _6809);
    _6809 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__12135);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__12135 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _6810;
    if( _1 != _6810 ){
        DeRef(_1);
    }
    _6810 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__12135);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_12134))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12134)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12134);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__12135;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_12134);
    DeRefDS(_temp_map__12135);
    _6796 = NOVALUE;
    _6799 = NOVALUE;
    _6802 = NOVALUE;
    _6805 = NOVALUE;
    _6808 = NOVALUE;
    return;
    ;
}


int _28keys(int _the_map_p_12216, int _sorted_result_12217)
{
    int _buckets__12218 = NOVALUE;
    int _current_bucket__12219 = NOVALUE;
    int _results__12220 = NOVALUE;
    int _pos__12221 = NOVALUE;
    int _temp_map__12222 = NOVALUE;
    int _6868 = NOVALUE;
    int _6866 = NOVALUE;
    int _6865 = NOVALUE;
    int _6863 = NOVALUE;
    int _6862 = NOVALUE;
    int _6861 = NOVALUE;
    int _6860 = NOVALUE;
    int _6858 = NOVALUE;
    int _6857 = NOVALUE;
    int _6856 = NOVALUE;
    int _6855 = NOVALUE;
    int _6853 = NOVALUE;
    int _6851 = NOVALUE;
    int _6848 = NOVALUE;
    int _6846 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12222);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_the_map_p_12216)){
        _temp_map__12222 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12216)->dbl));
    }
    else{
        _temp_map__12222 = (int)*(((s1_ptr)_2)->base + _the_map_p_12216);
    }
    Ref(_temp_map__12222);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__12222);
    _6846 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12220);
    _results__12220 = Repeat(0, _6846);
    _6846 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12221 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12222);
    _6848 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6848, 76)){
        _6848 = NOVALUE;
        goto L1; // [34] 113
    }
    _6848 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__12218);
    _2 = (int)SEQ_PTR(_temp_map__12222);
    _buckets__12218 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__12218);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__12218)){
            _6851 = SEQ_PTR(_buckets__12218)->length;
    }
    else {
        _6851 = 1;
    }
    {
        int _index_12231;
        _index_12231 = 1;
L2: 
        if (_index_12231 > _6851){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__12219);
        _2 = (int)SEQ_PTR(_buckets__12218);
        _current_bucket__12219 = (int)*(((s1_ptr)_2)->base + _index_12231);
        Ref(_current_bucket__12219);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__12219)){
                _6853 = SEQ_PTR(_current_bucket__12219)->length;
        }
        else {
            _6853 = 1;
        }
        if (_6853 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__12219)){
                _6855 = SEQ_PTR(_current_bucket__12219)->length;
        }
        else {
            _6855 = 1;
        }
        _6856 = _pos__12221 + _6855;
        if ((long)((unsigned long)_6856 + (unsigned long)HIGH_BITS) >= 0) 
        _6856 = NewDouble((double)_6856);
        _6855 = NOVALUE;
        if (IS_ATOM_INT(_6856)) {
            _6857 = _6856 - 1;
        }
        else {
            _6857 = NewDouble(DBL_PTR(_6856)->dbl - (double)1);
        }
        DeRef(_6856);
        _6856 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__12220;
        AssignSlice(_pos__12221, _6857, _current_bucket__12219);
        DeRef(_6857);
        _6857 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__12219)){
                _6858 = SEQ_PTR(_current_bucket__12219)->length;
        }
        else {
            _6858 = 1;
        }
        _pos__12221 = _pos__12221 + _6858;
        _6858 = NOVALUE;
L4: 

        /** 		end for*/
        _index_12231 = _index_12231 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12222);
    _6860 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6860)){
            _6861 = SEQ_PTR(_6860)->length;
    }
    else {
        _6861 = 1;
    }
    _6860 = NOVALUE;
    {
        int _index_12244;
        _index_12244 = 1;
L6: 
        if (_index_12244 > _6861){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12222);
        _6862 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_6862);
        _6863 = (int)*(((s1_ptr)_2)->base + _index_12244);
        _6862 = NOVALUE;
        if (binary_op_a(EQUALS, _6863, 0)){
            _6863 = NOVALUE;
            goto L8; // [139] 164
        }
        _6863 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12222);
        _6865 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_6865);
        _6866 = (int)*(((s1_ptr)_2)->base + _index_12244);
        _6865 = NOVALUE;
        Ref(_6866);
        _2 = (int)SEQ_PTR(_results__12220);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12220 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__12221);
        _1 = *(int *)_2;
        *(int *)_2 = _6866;
        if( _1 != _6866 ){
            DeRef(_1);
        }
        _6866 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12221 = _pos__12221 + 1;
L8: 

        /** 		end for*/
        _index_12244 = _index_12244 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_12217 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__12220);
    _6868 = _24sort(_results__12220, 1);
    DeRef(_the_map_p_12216);
    DeRef(_buckets__12218);
    DeRef(_current_bucket__12219);
    DeRefDS(_results__12220);
    DeRef(_temp_map__12222);
    _6860 = NOVALUE;
    return _6868;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_12216);
    DeRef(_buckets__12218);
    DeRef(_current_bucket__12219);
    DeRef(_temp_map__12222);
    _6860 = NOVALUE;
    DeRef(_6868);
    _6868 = NOVALUE;
    return _results__12220;
LA: 
    ;
}


int _28values(int _the_map_12259, int _keys_12260, int _default_values_12261)
{
    int _buckets__12285 = NOVALUE;
    int _bucket__12286 = NOVALUE;
    int _results__12287 = NOVALUE;
    int _pos__12288 = NOVALUE;
    int _temp_map__12289 = NOVALUE;
    int _6908 = NOVALUE;
    int _6907 = NOVALUE;
    int _6905 = NOVALUE;
    int _6904 = NOVALUE;
    int _6903 = NOVALUE;
    int _6902 = NOVALUE;
    int _6900 = NOVALUE;
    int _6899 = NOVALUE;
    int _6898 = NOVALUE;
    int _6897 = NOVALUE;
    int _6895 = NOVALUE;
    int _6893 = NOVALUE;
    int _6890 = NOVALUE;
    int _6888 = NOVALUE;
    int _6886 = NOVALUE;
    int _6885 = NOVALUE;
    int _6884 = NOVALUE;
    int _6883 = NOVALUE;
    int _6881 = NOVALUE;
    int _6880 = NOVALUE;
    int _6879 = NOVALUE;
    int _6878 = NOVALUE;
    int _6877 = NOVALUE;
    int _6876 = NOVALUE;
    int _6874 = NOVALUE;
    int _6873 = NOVALUE;
    int _6871 = NOVALUE;
    int _6870 = NOVALUE;
    int _6869 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _6869 = 0;
    if (_6869 == 0)
    {
        _6869 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _6869 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _6870 = 1;
    if (_6870 == 0)
    {
        _6870 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _6870 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    _6871 = 1;
    _default_values_12261 = Repeat(0, 1);
    _6871 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_12261)){
            _6873 = SEQ_PTR(_default_values_12261)->length;
    }
    else {
        _6873 = 1;
    }
    if (IS_SEQUENCE(_keys_12260)){
            _6874 = SEQ_PTR(_keys_12260)->length;
    }
    else {
        _6874 = 1;
    }
    if (_6873 >= _6874)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_12261)){
            _6876 = SEQ_PTR(_default_values_12261)->length;
    }
    else {
        _6876 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_12261);
    _6877 = (int)*(((s1_ptr)_2)->base + _6876);
    if (IS_SEQUENCE(_keys_12260)){
            _6878 = SEQ_PTR(_keys_12260)->length;
    }
    else {
        _6878 = 1;
    }
    if (IS_SEQUENCE(_default_values_12261)){
            _6879 = SEQ_PTR(_default_values_12261)->length;
    }
    else {
        _6879 = 1;
    }
    _6880 = _6878 - _6879;
    _6878 = NOVALUE;
    _6879 = NOVALUE;
    _6881 = Repeat(_6877, _6880);
    _6877 = NOVALUE;
    _6880 = NOVALUE;
    if (IS_SEQUENCE(_default_values_12261) && IS_ATOM(_6881)) {
    }
    else if (IS_ATOM(_default_values_12261) && IS_SEQUENCE(_6881)) {
        Ref(_default_values_12261);
        Prepend(&_default_values_12261, _6881, _default_values_12261);
    }
    else {
        Concat((object_ptr)&_default_values_12261, _default_values_12261, _6881);
    }
    DeRefDS(_6881);
    _6881 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_12260)){
            _6883 = SEQ_PTR(_keys_12260)->length;
    }
    else {
        _6883 = 1;
    }
    {
        int _i_12280;
        _i_12280 = 1;
L5: 
        if (_i_12280 > _6883){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_12260);
        _6884 = (int)*(((s1_ptr)_2)->base + _i_12280);
        _2 = (int)SEQ_PTR(_default_values_12261);
        _6885 = (int)*(((s1_ptr)_2)->base + _i_12280);
        Ref(_6884);
        Ref(_6885);
        _6886 = _28get(_the_map_12259, _6884, _6885);
        _6884 = NOVALUE;
        _6885 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_12260);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_12260 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_12280);
        _1 = *(int *)_2;
        *(int *)_2 = _6886;
        if( _1 != _6886 ){
            DeRef(_1);
        }
        _6886 = NOVALUE;

        /** 		end for*/
        _i_12280 = _i_12280 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_default_values_12261);
    DeRef(_buckets__12285);
    DeRef(_bucket__12286);
    DeRef(_results__12287);
    DeRef(_temp_map__12289);
    return _keys_12260;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__12289);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _temp_map__12289 = (int)*(((s1_ptr)_2)->base + _the_map_12259);
    Ref(_temp_map__12289);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__12289);
    _6888 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12287);
    _results__12287 = Repeat(0, _6888);
    _6888 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12288 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12289);
    _6890 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6890, 76)){
        _6890 = NOVALUE;
        goto L7; // [157] 236
    }
    _6890 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__12285);
    _2 = (int)SEQ_PTR(_temp_map__12289);
    _buckets__12285 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__12285);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__12285)){
            _6893 = SEQ_PTR(_buckets__12285)->length;
    }
    else {
        _6893 = 1;
    }
    {
        int _index_12298;
        _index_12298 = 1;
L8: 
        if (_index_12298 > _6893){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__12286);
        _2 = (int)SEQ_PTR(_buckets__12285);
        _bucket__12286 = (int)*(((s1_ptr)_2)->base + _index_12298);
        Ref(_bucket__12286);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__12286)){
                _6895 = SEQ_PTR(_bucket__12286)->length;
        }
        else {
            _6895 = 1;
        }
        if (_6895 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__12286)){
                _6897 = SEQ_PTR(_bucket__12286)->length;
        }
        else {
            _6897 = 1;
        }
        _6898 = _pos__12288 + _6897;
        if ((long)((unsigned long)_6898 + (unsigned long)HIGH_BITS) >= 0) 
        _6898 = NewDouble((double)_6898);
        _6897 = NOVALUE;
        if (IS_ATOM_INT(_6898)) {
            _6899 = _6898 - 1;
        }
        else {
            _6899 = NewDouble(DBL_PTR(_6898)->dbl - (double)1);
        }
        DeRef(_6898);
        _6898 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__12287;
        AssignSlice(_pos__12288, _6899, _bucket__12286);
        DeRef(_6899);
        _6899 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__12286)){
                _6900 = SEQ_PTR(_bucket__12286)->length;
        }
        else {
            _6900 = 1;
        }
        _pos__12288 = _pos__12288 + _6900;
        _6900 = NOVALUE;
LA: 

        /** 		end for*/
        _index_12298 = _index_12298 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12289);
    _6902 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6902)){
            _6903 = SEQ_PTR(_6902)->length;
    }
    else {
        _6903 = 1;
    }
    _6902 = NOVALUE;
    {
        int _index_12311;
        _index_12311 = 1;
LC: 
        if (_index_12311 > _6903){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12289);
        _6904 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_6904);
        _6905 = (int)*(((s1_ptr)_2)->base + _index_12311);
        _6904 = NOVALUE;
        if (binary_op_a(EQUALS, _6905, 0)){
            _6905 = NOVALUE;
            goto LE; // [262] 287
        }
        _6905 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12289);
        _6907 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6907);
        _6908 = (int)*(((s1_ptr)_2)->base + _index_12311);
        _6907 = NOVALUE;
        Ref(_6908);
        _2 = (int)SEQ_PTR(_results__12287);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12287 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__12288);
        _1 = *(int *)_2;
        *(int *)_2 = _6908;
        if( _1 != _6908 ){
            DeRef(_1);
        }
        _6908 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12288 = _pos__12288 + 1;
LE: 

        /** 		end for*/
        _index_12311 = _index_12311 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_keys_12260);
    DeRef(_default_values_12261);
    DeRef(_buckets__12285);
    DeRef(_bucket__12286);
    DeRef(_temp_map__12289);
    _6902 = NOVALUE;
    return _results__12287;
    ;
}


int _28pairs(int _the_map_p_12323, int _sorted_result_12324)
{
    int _key_bucket__12325 = NOVALUE;
    int _value_bucket__12326 = NOVALUE;
    int _results__12327 = NOVALUE;
    int _pos__12328 = NOVALUE;
    int _temp_map__12329 = NOVALUE;
    int _6944 = NOVALUE;
    int _6942 = NOVALUE;
    int _6941 = NOVALUE;
    int _6939 = NOVALUE;
    int _6938 = NOVALUE;
    int _6937 = NOVALUE;
    int _6935 = NOVALUE;
    int _6933 = NOVALUE;
    int _6932 = NOVALUE;
    int _6931 = NOVALUE;
    int _6930 = NOVALUE;
    int _6928 = NOVALUE;
    int _6926 = NOVALUE;
    int _6925 = NOVALUE;
    int _6923 = NOVALUE;
    int _6922 = NOVALUE;
    int _6920 = NOVALUE;
    int _6918 = NOVALUE;
    int _6917 = NOVALUE;
    int _6916 = NOVALUE;
    int _6914 = NOVALUE;
    int _6912 = NOVALUE;
    int _6911 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__12329);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_the_map_p_12323)){
        _temp_map__12329 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_12323)->dbl));
    }
    else{
        _temp_map__12329 = (int)*(((s1_ptr)_2)->base + _the_map_p_12323);
    }
    Ref(_temp_map__12329);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _6911 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__12329);
    _6912 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__12327);
    _results__12327 = Repeat(_6911, _6912);
    DeRefDS(_6911);
    _6911 = NOVALUE;
    _6912 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__12328 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__12329);
    _6914 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _6914, 76)){
        _6914 = NOVALUE;
        goto L1; // [38] 147
    }
    _6914 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12329);
    _6916 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6916)){
            _6917 = SEQ_PTR(_6916)->length;
    }
    else {
        _6917 = 1;
    }
    _6916 = NOVALUE;
    {
        int _index_12338;
        _index_12338 = 1;
L2: 
        if (_index_12338 > _6917){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12329);
        _6918 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__12325);
        _2 = (int)SEQ_PTR(_6918);
        _key_bucket__12325 = (int)*(((s1_ptr)_2)->base + _index_12338);
        Ref(_key_bucket__12325);
        _6918 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__12329);
        _6920 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__12326);
        _2 = (int)SEQ_PTR(_6920);
        _value_bucket__12326 = (int)*(((s1_ptr)_2)->base + _index_12338);
        Ref(_value_bucket__12326);
        _6920 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__12325)){
                _6922 = SEQ_PTR(_key_bucket__12325)->length;
        }
        else {
            _6922 = 1;
        }
        {
            int _j_12346;
            _j_12346 = 1;
L4: 
            if (_j_12346 > _6922){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__12327);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__12327 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__12328 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__12325);
            _6925 = (int)*(((s1_ptr)_2)->base + _j_12346);
            Ref(_6925);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _6925;
            if( _1 != _6925 ){
                DeRef(_1);
            }
            _6925 = NOVALUE;
            _6923 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__12327);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__12327 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__12328 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__12326);
            _6928 = (int)*(((s1_ptr)_2)->base + _j_12346);
            Ref(_6928);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _6928;
            if( _1 != _6928 ){
                DeRef(_1);
            }
            _6928 = NOVALUE;
            _6926 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__12328 = _pos__12328 + 1;

            /** 			end for*/
            _j_12346 = _j_12346 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_12338 = _index_12338 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12329);
    _6930 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6930)){
            _6931 = SEQ_PTR(_6930)->length;
    }
    else {
        _6931 = 1;
    }
    _6930 = NOVALUE;
    {
        int _index_12357;
        _index_12357 = 1;
L7: 
        if (_index_12357 > _6931){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12329);
        _6932 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_6932);
        _6933 = (int)*(((s1_ptr)_2)->base + _index_12357);
        _6932 = NOVALUE;
        if (binary_op_a(EQUALS, _6933, 0)){
            _6933 = NOVALUE;
            goto L9; // [173] 222
        }
        _6933 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__12327);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12327 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__12328 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__12329);
        _6937 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_6937);
        _6938 = (int)*(((s1_ptr)_2)->base + _index_12357);
        _6937 = NOVALUE;
        Ref(_6938);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _6938;
        if( _1 != _6938 ){
            DeRef(_1);
        }
        _6938 = NOVALUE;
        _6935 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__12327);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__12327 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__12328 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__12329);
        _6941 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_6941);
        _6942 = (int)*(((s1_ptr)_2)->base + _index_12357);
        _6941 = NOVALUE;
        Ref(_6942);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _6942;
        if( _1 != _6942 ){
            DeRef(_1);
        }
        _6942 = NOVALUE;
        _6939 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__12328 = _pos__12328 + 1;
L9: 

        /** 		end for	*/
        _index_12357 = _index_12357 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_12324 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__12327);
    _6944 = _24sort(_results__12327, 1);
    DeRef(_the_map_p_12323);
    DeRef(_key_bucket__12325);
    DeRef(_value_bucket__12326);
    DeRefDS(_results__12327);
    DeRef(_temp_map__12329);
    _6916 = NOVALUE;
    _6930 = NOVALUE;
    return _6944;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_12323);
    DeRef(_key_bucket__12325);
    DeRef(_value_bucket__12326);
    DeRef(_temp_map__12329);
    _6916 = NOVALUE;
    _6930 = NOVALUE;
    DeRef(_6944);
    _6944 = NOVALUE;
    return _results__12327;
LB: 
    ;
}


void _28convert_to_large_map(int _the_map__12715)
{
    int _temp_map__12716 = NOVALUE;
    int _map_handle__12717 = NOVALUE;
    int _7148 = NOVALUE;
    int _7147 = NOVALUE;
    int _7146 = NOVALUE;
    int _7145 = NOVALUE;
    int _7144 = NOVALUE;
    int _7142 = NOVALUE;
    int _7141 = NOVALUE;
    int _7140 = NOVALUE;
    int _7139 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__12716);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    _temp_map__12716 = (int)*(((s1_ptr)_2)->base + _the_map__12715);
    Ref(_temp_map__12716);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__12717;
    _map_handle__12717 = _28new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__12716);
    _7139 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7139)){
            _7140 = SEQ_PTR(_7139)->length;
    }
    else {
        _7140 = 1;
    }
    _7139 = NOVALUE;
    {
        int _index_12721;
        _index_12721 = 1;
L1: 
        if (_index_12721 > _7140){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__12716);
        _7141 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7141);
        _7142 = (int)*(((s1_ptr)_2)->base + _index_12721);
        _7141 = NOVALUE;
        if (binary_op_a(EQUALS, _7142, 0)){
            _7142 = NOVALUE;
            goto L3; // [45] 77
        }
        _7142 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__12716);
        _7144 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7144);
        _7145 = (int)*(((s1_ptr)_2)->base + _index_12721);
        _7144 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__12716);
        _7146 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7146);
        _7147 = (int)*(((s1_ptr)_2)->base + _index_12721);
        _7146 = NOVALUE;
        Ref(_map_handle__12717);
        Ref(_7145);
        Ref(_7147);
        _28put(_map_handle__12717, _7145, _7147, 1, 23);
        _7145 = NOVALUE;
        _7147 = NOVALUE;
L3: 

        /** 	end for*/
        _index_12721 = _index_12721 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!IS_ATOM_INT(_map_handle__12717)){
        _7148 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__12717)->dbl));
    }
    else{
        _7148 = (int)*(((s1_ptr)_2)->base + _map_handle__12717);
    }
    Ref(_7148);
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__12715);
    _1 = *(int *)_2;
    *(int *)_2 = _7148;
    if( _1 != _7148 ){
        DeRef(_1);
    }
    _7148 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__12716);
    DeRef(_map_handle__12717);
    _7139 = NOVALUE;
    return;
    ;
}


void _28convert_to_small_map(int _the_map__12735)
{
    int _keys__12736 = NOVALUE;
    int _values__12737 = NOVALUE;
    int _7157 = NOVALUE;
    int _7156 = NOVALUE;
    int _7155 = NOVALUE;
    int _7154 = NOVALUE;
    int _7153 = NOVALUE;
    int _7152 = NOVALUE;
    int _7151 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__12735)) {
        _1 = (long)(DBL_PTR(_the_map__12735)->dbl);
        DeRefDS(_the_map__12735);
        _the_map__12735 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__12736;
    _keys__12736 = _28keys(_the_map__12735, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__12737;
    _values__12737 = _28values(_the_map__12735, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _7151 = Repeat(_28init_small_map_key_11449, 23);
    _7152 = Repeat(0, 23);
    _7153 = Repeat(0, 23);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28type_is_map_11433);
    *((int *)(_2+4)) = _28type_is_map_11433;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7151;
    *((int *)(_2+24)) = _7152;
    *((int *)(_2+28)) = _7153;
    _7154 = MAKE_SEQ(_1);
    _7153 = NOVALUE;
    _7152 = NOVALUE;
    _7151 = NOVALUE;
    _2 = (int)SEQ_PTR(_29ram_space_10561);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29ram_space_10561 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__12735);
    _1 = *(int *)_2;
    *(int *)_2 = _7154;
    if( _1 != _7154 ){
        DeRef(_1);
    }
    _7154 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__12736)){
            _7155 = SEQ_PTR(_keys__12736)->length;
    }
    else {
        _7155 = 1;
    }
    {
        int _i_12745;
        _i_12745 = 1;
L1: 
        if (_i_12745 > _7155){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__12736);
        _7156 = (int)*(((s1_ptr)_2)->base + _i_12745);
        _2 = (int)SEQ_PTR(_values__12737);
        _7157 = (int)*(((s1_ptr)_2)->base + _i_12745);
        Ref(_7156);
        Ref(_7157);
        _28put(_the_map__12735, _7156, _7157, 1, 0);
        _7156 = NOVALUE;
        _7157 = NOVALUE;

        /** 	end for*/
        _i_12745 = _i_12745 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__12736);
    DeRef(_values__12737);
    return;
    ;
}



// 0xE3BFD16E
