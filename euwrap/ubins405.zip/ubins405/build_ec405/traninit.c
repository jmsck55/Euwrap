// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _3extract_options(int _s_62810)
{
    int _0, _1, _2;
    

    /** 	return s*/
    return _s_62810;
    ;
}


void _3transoptions()
{
    int _tranopts_62937 = NOVALUE;
    int _opts_62947 = NOVALUE;
    int _opt_keys_62953 = NOVALUE;
    int _option_w_62955 = NOVALUE;
    int _key_62959 = NOVALUE;
    int _val_62961 = NOVALUE;
    int _tmp_63054 = NOVALUE;
    int _tmp_63074 = NOVALUE;
    int _31597 = NOVALUE;
    int _31596 = NOVALUE;
    int _31595 = NOVALUE;
    int _31594 = NOVALUE;
    int _31592 = NOVALUE;
    int _31591 = NOVALUE;
    int _31590 = NOVALUE;
    int _31589 = NOVALUE;
    int _31588 = NOVALUE;
    int _31587 = NOVALUE;
    int _31582 = NOVALUE;
    int _31581 = NOVALUE;
    int _31580 = NOVALUE;
    int _31577 = NOVALUE;
    int _31576 = NOVALUE;
    int _31575 = NOVALUE;
    int _31574 = NOVALUE;
    int _31573 = NOVALUE;
    int _31570 = NOVALUE;
    int _31567 = NOVALUE;
    int _31566 = NOVALUE;
    int _31565 = NOVALUE;
    int _31564 = NOVALUE;
    int _31562 = NOVALUE;
    int _31559 = NOVALUE;
    int _31558 = NOVALUE;
    int _31557 = NOVALUE;
    int _31556 = NOVALUE;
    int _31555 = NOVALUE;
    int _31554 = NOVALUE;
    int _31553 = NOVALUE;
    int _31552 = NOVALUE;
    int _31551 = NOVALUE;
    int _31550 = NOVALUE;
    int _31549 = NOVALUE;
    int _31548 = NOVALUE;
    int _31547 = NOVALUE;
    int _31545 = NOVALUE;
    int _31543 = NOVALUE;
    int _31541 = NOVALUE;
    int _31540 = NOVALUE;
    int _31539 = NOVALUE;
    int _31538 = NOVALUE;
    int _31537 = NOVALUE;
    int _31536 = NOVALUE;
    int _31533 = NOVALUE;
    int _31532 = NOVALUE;
    int _31531 = NOVALUE;
    int _31528 = NOVALUE;
    int _31525 = NOVALUE;
    int _31524 = NOVALUE;
    int _31522 = NOVALUE;
    int _31520 = NOVALUE;
    int _31518 = NOVALUE;
    int _31508 = NOVALUE;
    int _31506 = NOVALUE;
    int _31503 = NOVALUE;
    int _31501 = NOVALUE;
    int _31499 = NOVALUE;
    int _31498 = NOVALUE;
    int _31497 = NOVALUE;
    int _31496 = NOVALUE;
    int _31495 = NOVALUE;
    int _31490 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tranopts = get_options()*/
    _0 = _tranopts_62937;
    _tranopts_62937 = _43get_options();
    DeRef(_0);

    /** 	Argv = expand_config_options( Argv )*/
    RefDS(_35Argv_15979);
    _0 = _43expand_config_options(_35Argv_15979);
    DeRefDS(_35Argv_15979);
    _35Argv_15979 = _0;

    /** 	Argc = length(Argv)*/
    if (IS_SEQUENCE(_35Argv_15979)){
            _35Argc_15978 = SEQ_PTR(_35Argv_15979)->length;
    }
    else {
        _35Argc_15978 = 1;
    }

    /** 	map:map opts = cmd_parse( tranopts, NO_HELP_ON_ERROR, Argv)*/
    RefDS(_tranopts_62937);
    RefDS(_35Argv_15979);
    _0 = _opts_62947;
    _opts_62947 = _4cmd_parse(_tranopts_62937, 10, _35Argv_15979);
    DeRef(_0);

    /** 	handle_common_options(opts)*/
    Ref(_opts_62947);
    _43handle_common_options(_opts_62947);

    /** 	sequence opt_keys = map:keys(opts)*/
    Ref(_opts_62947);
    _0 = _opt_keys_62953;
    _opt_keys_62953 = _28keys(_opts_62947, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_62955 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_62953)){
            _31490 = SEQ_PTR(_opt_keys_62953)->length;
    }
    else {
        _31490 = 1;
    }
    {
        int _idx_62957;
        _idx_62957 = 1;
L1: 
        if (_idx_62957 > _31490){
            goto L2; // [63] 739
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_62959);
        _2 = (int)SEQ_PTR(_opt_keys_62953);
        _key_62959 = (int)*(((s1_ptr)_2)->base + _idx_62957);
        Ref(_key_62959);

        /** 		object val = map:get(opts, key)*/
        Ref(_opts_62947);
        RefDS(_key_62959);
        _0 = _val_62961;
        _val_62961 = _28get(_opts_62947, _key_62959, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_62959, _31493);
        switch ( _1 ){ 

            /** 			case "silent" then*/
            case 1:

            /** 				silent = TRUE*/
            _35silent_16083 = _13TRUE_437;
            goto L3; // [104] 730

            /** 			case "verbose" then*/
            case 2:

            /** 				verbose = TRUE*/
            _35verbose_16086 = _13TRUE_437;
            goto L3; // [117] 730

            /** 			case "rc-file" then*/
            case 3:

            /** 				rc_file[D_NAME] = canonical_path(val)*/
            Ref(_val_62961);
            _31495 = _17canonical_path(_val_62961, 0, 0);
            _2 = (int)SEQ_PTR(_55rc_file_43994);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _55rc_file_43994 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _31495;
            if( _1 != _31495 ){
                DeRef(_1);
            }
            _31495 = NOVALUE;

            /** 				rc_file[D_ALTNAME] = adjust_for_command_line_passing((rc_file[D_NAME]))*/
            _2 = (int)SEQ_PTR(_55rc_file_43994);
            _31496 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_31496);
            _31497 = _55adjust_for_command_line_passing(_31496);
            _31496 = NOVALUE;
            _2 = (int)SEQ_PTR(_55rc_file_43994);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _55rc_file_43994 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 11);
            _1 = *(int *)_2;
            *(int *)_2 = _31497;
            if( _1 != _31497 ){
                DeRef(_1);
            }
            _31497 = NOVALUE;

            /** 				if not file_exists(rc_file[D_NAME]) then*/
            _2 = (int)SEQ_PTR(_55rc_file_43994);
            _31498 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_31498);
            _31499 = _17file_exists(_31498);
            _31498 = NOVALUE;
            if (IS_ATOM_INT(_31499)) {
                if (_31499 != 0){
                    DeRef(_31499);
                    _31499 = NOVALUE;
                    goto L3; // [175] 730
                }
            }
            else {
                if (DBL_PTR(_31499)->dbl != 0.0){
                    DeRef(_31499);
                    _31499 = NOVALUE;
                    goto L3; // [175] 730
                }
            }
            DeRef(_31499);
            _31499 = NOVALUE;

            /** 					ShowMsg(2, 349, { val })*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_val_62961);
            *((int *)(_2+4)) = _val_62961;
            _31501 = MAKE_SEQ(_1);
            _45ShowMsg(2, 349, _31501, 1);
            _31501 = NOVALUE;

            /** 					abort(1)*/
            UserCleanup(1);
            goto L3; // [195] 730

            /** 			case "cflags" then*/
            case 4:

            /** 				cflags = val*/
            Ref(_val_62961);
            DeRef(_55cflags_44003);
            _55cflags_44003 = _val_62961;
            goto L3; // [208] 730

            /** 			case "lflags" then*/
            case 5:

            /** 				lflags = val*/
            Ref(_val_62961);
            DeRef(_55lflags_44004);
            _55lflags_44004 = _val_62961;
            goto L3; // [221] 730

            /** 			case "wat" then*/
            case 6:

            /** 				compiler_type = COMPILER_WATCOM*/
            _55compiler_type_43986 = 2;
            goto L3; // [236] 730

            /** 			case "gcc" then*/
            case 7:

            /** 				compiler_type = COMPILER_GCC*/
            _55compiler_type_43986 = 1;
            goto L3; // [251] 730

            /** 			case "com" then*/
            case 8:

            /** 				compiler_dir = val*/
            Ref(_val_62961);
            DeRef(_55compiler_dir_43987);
            _55compiler_dir_43987 = _val_62961;
            goto L3; // [264] 730

            /** 			case "con" then*/
            case 9:

            /** 				con_option = TRUE*/
            _57con_option_41332 = _13TRUE_437;

            /** 				OpDefines &= { "CONSOLE" }*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_31502);
            *((int *)(_2+4)) = _31502;
            _31503 = MAKE_SEQ(_1);
            Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _31503);
            DeRefDS(_31503);
            _31503 = NOVALUE;
            goto L3; // [291] 730

            /** 			case "dll", "so" then*/
            case 10:
            case 11:

            /** 				dll_option = TRUE*/
            _57dll_option_41330 = _13TRUE_437;

            /** 				OpDefines &= { "EUC_DLL" }*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_31505);
            *((int *)(_2+4)) = _31505;
            _31506 = MAKE_SEQ(_1);
            Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _31506);
            DeRefDS(_31506);
            _31506 = NOVALUE;
            goto L3; // [320] 730

            /** 			case "plat" then*/
            case 12:

            /** 				switch upper(val) do*/
            Ref(_val_62961);
            _31508 = _14upper(_val_62961);
            _1 = find(_31508, _31509);
            DeRef(_31508);
            _31508 = NOVALUE;
            switch ( _1 ){ 

                /** 					case "WINDOWS" then*/
                case 1:

                /** 						set_host_platform( WIN32 )*/
                _40set_host_platform(2);
                goto L3; // [348] 730

                /** 					case "LINUX" then*/
                case 2:

                /** 						set_host_platform( ULINUX )*/
                _40set_host_platform(3);
                goto L3; // [361] 730

                /** 					case "FREEBSD" then*/
                case 3:

                /** 						set_host_platform( UFREEBSD )*/
                _40set_host_platform(8);
                goto L3; // [374] 730

                /** 					case "OSX" then*/
                case 4:

                /** 						set_host_platform( UOSX )*/
                _40set_host_platform(4);
                goto L3; // [387] 730

                /** 					case "OPENBSD" then*/
                case 5:

                /** 						set_host_platform( UOPENBSD )*/
                _40set_host_platform(6);
                goto L3; // [400] 730

                /** 					case "NETBSD" then*/
                case 6:

                /** 						set_host_platform( UNETBSD )*/
                _40set_host_platform(7);
                goto L3; // [413] 730

                /** 					case else*/
                case 0:

                /** 						ShowMsg(2, 201, { val, "WINDOWS, LINUX, FREEBSD, OSX, OPENBSD, NETBSD" })*/
                RefDS(_31517);
                Ref(_val_62961);
                _1 = NewS1(2);
                _2 = (int)((s1_ptr)_1)->base;
                ((int *)_2)[1] = _val_62961;
                ((int *)_2)[2] = _31517;
                _31518 = MAKE_SEQ(_1);
                _45ShowMsg(2, 201, _31518, 1);
                _31518 = NOVALUE;

                /** 						abort(1)*/
                UserCleanup(1);
            ;}            goto L3; // [436] 730

            /** 			case "lib" then*/
            case 13:

            /** 				user_library = val*/
            Ref(_val_62961);
            DeRef(_57user_library_41342);
            _57user_library_41342 = _val_62961;
            goto L3; // [449] 730

            /** 			case "stack" then*/
            case 14:

            /** 				sequence tmp = value(val)*/
            Ref(_val_62961);
            _0 = _tmp_63054;
            _tmp_63054 = _6value(_val_62961, 1, _6GET_SHORT_ANSWER_10491);
            DeRef(_0);

            /** 				if tmp[1] = GET_SUCCESS then*/
            _2 = (int)SEQ_PTR(_tmp_63054);
            _31520 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31520, 0)){
                _31520 = NOVALUE;
                goto L4; // [475] 507
            }
            _31520 = NOVALUE;

            /** 					if tmp[2] >= 16384 then*/
            _2 = (int)SEQ_PTR(_tmp_63054);
            _31522 = (int)*(((s1_ptr)_2)->base + 2);
            if (binary_op_a(LESS, _31522, 16384)){
                _31522 = NOVALUE;
                goto L5; // [485] 506
            }
            _31522 = NOVALUE;

            /** 						total_stack_size = floor(tmp[2] / 4) * 4*/
            _2 = (int)SEQ_PTR(_tmp_63054);
            _31524 = (int)*(((s1_ptr)_2)->base + 2);
            if (IS_ATOM_INT(_31524)) {
                if (4 > 0 && _31524 >= 0) {
                    _31525 = _31524 / 4;
                }
                else {
                    temp_dbl = floor((double)_31524 / (double)4);
                    if (_31524 != MININT)
                    _31525 = (long)temp_dbl;
                    else
                    _31525 = NewDouble(temp_dbl);
                }
            }
            else {
                _2 = binary_op(DIVIDE, _31524, 4);
                _31525 = unary_op(FLOOR, _2);
                DeRef(_2);
            }
            _31524 = NOVALUE;
            if (IS_ATOM_INT(_31525)) {
                _57total_stack_size_41344 = _31525 * 4;
            }
            else {
                _57total_stack_size_41344 = binary_op(MULTIPLY, _31525, 4);
            }
            DeRef(_31525);
            _31525 = NOVALUE;
            if (!IS_ATOM_INT(_57total_stack_size_41344)) {
                _1 = (long)(DBL_PTR(_57total_stack_size_41344)->dbl);
                DeRefDS(_57total_stack_size_41344);
                _57total_stack_size_41344 = _1;
            }
L5: 
L4: 
            DeRef(_tmp_63054);
            _tmp_63054 = NOVALUE;
            goto L3; // [509] 730

            /** 			case "debug" then*/
            case 15:

            /** 				debug_option = TRUE*/
            _57debug_option_41340 = _13TRUE_437;

            /** 				keep = TRUE -- you'll need the sources to debug*/
            _57keep_41337 = _13TRUE_437;
            goto L3; // [529] 730

            /** 			case "maxsize" then*/
            case 16:

            /** 				sequence tmp = value(val)*/
            Ref(_val_62961);
            _0 = _tmp_63074;
            _tmp_63074 = _6value(_val_62961, 1, _6GET_SHORT_ANSWER_10491);
            DeRef(_0);

            /** 				if tmp[1] = GET_SUCCESS then*/
            _2 = (int)SEQ_PTR(_tmp_63074);
            _31528 = (int)*(((s1_ptr)_2)->base + 1);
            if (binary_op_a(NOTEQ, _31528, 0)){
                _31528 = NOVALUE;
                goto L6; // [555] 570
            }
            _31528 = NOVALUE;

            /** 					max_cfile_size = tmp[2]*/
            _2 = (int)SEQ_PTR(_tmp_63074);
            _55max_cfile_size_44001 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_55max_cfile_size_44001)){
                _55max_cfile_size_44001 = (long)DBL_PTR(_55max_cfile_size_44001)->dbl;
            }
            goto L7; // [567] 583
L6: 

            /** 					ShowMsg(2, 202)*/
            RefDS(_21815);
            _45ShowMsg(2, 202, _21815, 1);

            /** 					abort(1)*/
            UserCleanup(1);
L7: 
            DeRef(_tmp_63074);
            _tmp_63074 = NOVALUE;
            goto L3; // [585] 730

            /** 			case "keep" then*/
            case 17:

            /** 				keep = TRUE*/
            _57keep_41337 = _13TRUE_437;
            goto L3; // [598] 730

            /** 			case "makefile-partial" then*/
            case 18:

            /** 				build_system_type = BUILD_MAKEFILE_PARTIAL*/
            _55build_system_type_43982 = 1;
            goto L3; // [613] 730

            /** 			case "makefile" then*/
            case 19:

            /** 				build_system_type = BUILD_MAKEFILE_FULL*/
            _55build_system_type_43982 = 2;
            goto L3; // [628] 730

            /** 			case "nobuild" then*/
            case 20:

            /** 				build_system_type = BUILD_NONE*/
            _55build_system_type_43982 = 0;
            goto L3; // [643] 730

            /** 			case "build-dir" then*/
            case 21:

            /** 				output_dir = val*/
            Ref(_val_62961);
            DeRef(_57output_dir_41343);
            _57output_dir_41343 = _val_62961;

            /** 				if find(output_dir[$], "/\\") = 0 then*/
            if (IS_SEQUENCE(_57output_dir_41343)){
                    _31531 = SEQ_PTR(_57output_dir_41343)->length;
            }
            else {
                _31531 = 1;
            }
            _2 = (int)SEQ_PTR(_57output_dir_41343);
            _31532 = (int)*(((s1_ptr)_2)->base + _31531);
            _31533 = find_from(_31532, _23553, 1);
            _31532 = NOVALUE;
            if (_31533 != 0)
            goto L3; // [672] 730

            /** 					output_dir &= '/'*/
            Append(&_57output_dir_41343, _57output_dir_41343, 47);
            goto L3; // [687] 730

            /** 			case "force-build" then*/
            case 22:

            /** 				force_build = 1*/
            _55force_build_44005 = 1;
            goto L3; // [700] 730

            /** 			case "o" then*/
            case 23:

            /** 				exe_name[D_NAME] = val*/
            Ref(_val_62961);
            _2 = (int)SEQ_PTR(_55exe_name_43988);
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _val_62961;
            DeRef(_1);
            goto L3; // [716] 730

            /** 			case "no-cygwin" then*/
            case 24:

            /** 				mno_cygwin = 1*/
            _55mno_cygwin_44007 = 1;
        ;}L3: 
        DeRef(_key_62959);
        _key_62959 = NOVALUE;
        DeRef(_val_62961);
        _val_62961 = NOVALUE;

        /** 	end for*/
        _idx_62957 = _idx_62957 + 1;
        goto L1; // [734] 70
L2: 
        ;
    }

    /** 	if compiler_type != COMPILER_GCC and not equal(user_library,"") then*/
    _31536 = (_55compiler_type_43986 != 1);
    if (_31536 == 0) {
        goto L8; // [749] 840
    }
    if (_57user_library_41342 == _21815)
    _31538 = 1;
    else if (IS_ATOM_INT(_57user_library_41342) && IS_ATOM_INT(_21815))
    _31538 = 0;
    else
    _31538 = (compare(_57user_library_41342, _21815) == 0);
    _31539 = (_31538 == 0);
    _31538 = NOVALUE;
    if (_31539 == 0)
    {
        DeRef(_31539);
        _31539 = NOVALUE;
        goto L8; // [763] 840
    }
    else{
        DeRef(_31539);
        _31539 = NOVALUE;
    }

    /** 		if not file_exists(canonical_path(user_library)) then*/
    RefDS(_57user_library_41342);
    _31540 = _17canonical_path(_57user_library_41342, 0, 0);
    _31541 = _17file_exists(_31540);
    _31540 = NOVALUE;
    if (IS_ATOM_INT(_31541)) {
        if (_31541 != 0){
            DeRef(_31541);
            _31541 = NOVALUE;
            goto L9; // [780] 826
        }
    }
    else {
        if (DBL_PTR(_31541)->dbl != 0.0){
            DeRef(_31541);
            _31541 = NOVALUE;
            goto L9; // [780] 826
        }
    }
    DeRef(_31541);
    _31541 = NOVALUE;

    /** 			ShowMsg(2, 348, { user_library })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57user_library_41342);
    *((int *)(_2+4)) = _57user_library_41342;
    _31543 = MAKE_SEQ(_1);
    _45ShowMsg(2, 348, _31543, 1);
    _31543 = NOVALUE;

    /** 			if force_build or build_system_type = BUILD_DIRECT then*/
    if (_55force_build_44005 != 0) {
        goto LA; // [801] 818
    }
    _31545 = (_55build_system_type_43982 == 3);
    if (_31545 == 0)
    {
        DeRef(_31545);
        _31545 = NOVALUE;
        goto LB; // [814] 839
    }
    else{
        DeRef(_31545);
        _31545 = NOVALUE;
    }
LA: 

    /** 				abort(1)*/
    UserCleanup(1);
    goto LB; // [823] 839
L9: 

    /** 			user_library = canonical_path(user_library)*/
    RefDS(_57user_library_41342);
    _0 = _17canonical_path(_57user_library_41342, 0, 0);
    DeRefDS(_57user_library_41342);
    _57user_library_41342 = _0;
LB: 
L8: 

    /** 	if length(exe_name[D_NAME]) and not absolute_path(exe_name[D_NAME]) then*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _31547 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31547)){
            _31548 = SEQ_PTR(_31547)->length;
    }
    else {
        _31548 = 1;
    }
    _31547 = NOVALUE;
    if (_31548 == 0) {
        goto LC; // [853] 906
    }
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _31550 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31550);
    _31551 = _17absolute_path(_31550);
    _31550 = NOVALUE;
    if (IS_ATOM_INT(_31551)) {
        _31552 = (_31551 == 0);
    }
    else {
        _31552 = unary_op(NOT, _31551);
    }
    DeRef(_31551);
    _31551 = NOVALUE;
    if (_31552 == 0) {
        DeRef(_31552);
        _31552 = NOVALUE;
        goto LC; // [873] 906
    }
    else {
        if (!IS_ATOM_INT(_31552) && DBL_PTR(_31552)->dbl == 0.0){
            DeRef(_31552);
            _31552 = NOVALUE;
            goto LC; // [873] 906
        }
        DeRef(_31552);
        _31552 = NOVALUE;
    }
    DeRef(_31552);
    _31552 = NOVALUE;

    /** 		exe_name[D_NAME] = current_dir() & SLASH & exe_name[D_NAME]*/
    _31553 = _17current_dir();
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _31554 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _31554;
        concat_list[1] = 47;
        concat_list[2] = _31553;
        Concat_N((object_ptr)&_31555, concat_list, 3);
    }
    _31554 = NOVALUE;
    DeRef(_31553);
    _31553 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31555;
    if( _1 != _31555 ){
        DeRef(_1);
    }
    _31555 = NOVALUE;
LC: 

    /** 	exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _31556 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31556);
    _31557 = _55adjust_for_command_line_passing(_31556);
    _31556 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31557;
    if( _1 != _31557 ){
        DeRef(_1);
    }
    _31557 = NOVALUE;

    /** 	if length(map:get(opts, OPT_EXTRAS)) = 0 then*/
    Ref(_opts_62947);
    RefDS(_4OPT_EXTRAS_13862);
    _31558 = _28get(_opts_62947, _4OPT_EXTRAS_13862, 0);
    if (IS_SEQUENCE(_31558)){
            _31559 = SEQ_PTR(_31558)->length;
    }
    else {
        _31559 = 1;
    }
    DeRef(_31558);
    _31558 = NOVALUE;
    if (_31559 != 0)
    goto LD; // [941] 962

    /** 		show_banner()*/
    _43show_banner();

    /** 		ShowMsg(2, 203)*/
    RefDS(_21815);
    _45ShowMsg(2, 203, _21815, 1);

    /** 		abort(1)*/
    UserCleanup(1);
LD: 

    /** 	OpDefines &= { "EUC" }*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_31561);
    *((int *)(_2+4)) = _31561;
    _31562 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _31562);
    DeRefDS(_31562);
    _31562 = NOVALUE;

    /** 	if host_platform() = WIN32 and not con_option then*/
    _31564 = _40host_platform();
    if (IS_ATOM_INT(_31564)) {
        _31565 = (_31564 == 2);
    }
    else {
        _31565 = binary_op(EQUALS, _31564, 2);
    }
    DeRef(_31564);
    _31564 = NOVALUE;
    if (IS_ATOM_INT(_31565)) {
        if (_31565 == 0) {
            goto LE; // [987] 1013
        }
    }
    else {
        if (DBL_PTR(_31565)->dbl == 0.0) {
            goto LE; // [987] 1013
        }
    }
    _31567 = (_57con_option_41332 == 0);
    if (_31567 == 0)
    {
        DeRef(_31567);
        _31567 = NOVALUE;
        goto LE; // [997] 1013
    }
    else{
        DeRef(_31567);
        _31567 = NOVALUE;
    }

    /** 		OpDefines = append( OpDefines, "GUI" )*/
    RefDS(_31568);
    Append(&_35OpDefines_16041, _35OpDefines_16041, _31568);
    goto LF; // [1010] 1037
LE: 

    /** 	elsif not find( "CONSOLE", OpDefines ) then*/
    _31570 = find_from(_31502, _35OpDefines_16041, 1);
    if (_31570 != 0)
    goto L10; // [1022] 1036
    _31570 = NOVALUE;

    /** 		OpDefines = append( OpDefines, "CONSOLE" )*/
    RefDS(_31502);
    Append(&_35OpDefines_16041, _35OpDefines_16041, _31502);
L10: 
LF: 

    /** 	ifdef not EUDIS then*/

    /** 		if build_system_type = BUILD_DIRECT and length(output_dir) = 0 then*/
    _31573 = (_55build_system_type_43982 == 3);
    if (_31573 == 0) {
        goto L11; // [1049] 1147
    }
    if (IS_SEQUENCE(_57output_dir_41343)){
            _31575 = SEQ_PTR(_57output_dir_41343)->length;
    }
    else {
        _31575 = 1;
    }
    _31576 = (_31575 == 0);
    _31575 = NOVALUE;
    if (_31576 == 0)
    {
        DeRef(_31576);
        _31576 = NOVALUE;
        goto L11; // [1063] 1147
    }
    else{
        DeRef(_31576);
        _31576 = NOVALUE;
    }

    /** 			output_dir = temp_file("." & SLASH, "build-", "")*/
    Append(&_31577, _22894, 47);
    RefDS(_31578);
    RefDS(_21815);
    _0 = _17temp_file(_31577, _31578, _21815, 0);
    DeRef(_57output_dir_41343);
    _57output_dir_41343 = _0;
    _31577 = NOVALUE;

    /** 			if find(output_dir[$], "/\\") = 0 then*/
    if (IS_SEQUENCE(_57output_dir_41343)){
            _31580 = SEQ_PTR(_57output_dir_41343)->length;
    }
    else {
        _31580 = 1;
    }
    _2 = (int)SEQ_PTR(_57output_dir_41343);
    _31581 = (int)*(((s1_ptr)_2)->base + _31580);
    _31582 = find_from(_31581, _23553, 1);
    _31581 = NOVALUE;
    if (_31582 != 0)
    goto L12; // [1099] 1114

    /** 				output_dir &= '/'*/
    Append(&_57output_dir_41343, _57output_dir_41343, 47);
L12: 

    /** 			if not silent then*/
    if (_35silent_16083 != 0)
    goto L13; // [1118] 1139

    /** 				printf(1, "Build directory: %s\n", { abbreviate_path(output_dir) })*/
    RefDS(_57output_dir_41343);
    RefDS(_21815);
    _31587 = _17abbreviate_path(_57output_dir_41343, _21815);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31587;
    _31588 = MAKE_SEQ(_1);
    _31587 = NOVALUE;
    EPrintf(1, _31586, _31588);
    DeRefDS(_31588);
    _31588 = NOVALUE;
L13: 

    /** 			remove_output_dir = 1*/
    _55remove_output_dir_44006 = 1;
L11: 

    /** 	if length(rc_file[D_NAME]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _31589 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_31589)){
            _31590 = SEQ_PTR(_31589)->length;
    }
    else {
        _31590 = 1;
    }
    _31589 = NOVALUE;
    if (_31590 == 0)
    {
        _31590 = NOVALUE;
        goto L14; // [1160] 1222
    }
    else{
        _31590 = NOVALUE;
    }

    /** 		res_file[D_NAME] = canonical_path(output_dir & filebase(rc_file[D_NAME]) & ".res")*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _31591 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31591);
    _31592 = _17filebase(_31591);
    _31591 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _31593;
        concat_list[1] = _31592;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_31594, concat_list, 3);
    }
    DeRef(_31592);
    _31592 = NOVALUE;
    _31595 = _17canonical_path(_31594, 0, 0);
    _31594 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44000);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _55res_file_44000 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _31595;
    if( _1 != _31595 ){
        DeRef(_1);
    }
    _31595 = NOVALUE;

    /** 		res_file[D_ALTNAME] = adjust_for_command_line_passing(res_file[D_NAME])*/
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _31596 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31596);
    _31597 = _55adjust_for_command_line_passing(_31596);
    _31596 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44000);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _55res_file_44000 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31597;
    if( _1 != _31597 ){
        DeRef(_1);
    }
    _31597 = NOVALUE;
L14: 

    /** 	finalize_command_line(opts)*/
    Ref(_opts_62947);
    _43finalize_command_line(_opts_62947);

    /** end procedure*/
    DeRef(_tranopts_62937);
    DeRef(_opts_62947);
    DeRef(_opt_keys_62953);
    DeRef(_31536);
    _31536 = NOVALUE;
    _31547 = NOVALUE;
    _31558 = NOVALUE;
    DeRef(_31573);
    _31573 = NOVALUE;
    DeRef(_31565);
    _31565 = NOVALUE;
    _31589 = NOVALUE;
    return;
    ;
}


void _3OpenCFiles()
{
    int _31653 = NOVALUE;
    int _31609 = NOVALUE;
    int _31603 = NOVALUE;
    int _31601 = NOVALUE;
    int _31600 = NOVALUE;
    int _31599 = NOVALUE;
    int _31598 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _31598 = 1;
    if (_31598 == 0) {
        goto L1; // [8] 38
    }
    if (IS_SEQUENCE(_57output_dir_41343)){
            _31600 = SEQ_PTR(_57output_dir_41343)->length;
    }
    else {
        _31600 = 1;
    }
    _31601 = (_31600 > 0);
    _31600 = NOVALUE;
    if (_31601 == 0)
    {
        DeRef(_31601);
        _31601 = NOVALUE;
        goto L1; // [22] 38
    }
    else{
        DeRef(_31601);
        _31601 = NOVALUE;
    }

    /** 		create_directory(output_dir)*/
    RefDS(_57output_dir_41343);
    _31653 = _17create_directory(_57output_dir_41343, 448, 1);
    DeRef(_31653);
    _31653 = NOVALUE;
L1: 

    /** 	c_code = open(output_dir & "init-.c", "w")*/
    Concat((object_ptr)&_31603, _57output_dir_41343, _31602);
    _54c_code_45122 = EOpen(_31603, _21921, 0);
    DeRefDS(_31603);
    _31603 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_54c_code_45122 != -1)
    goto L2; // [57] 69

    /** 		CompileErr(55)*/
    RefDS(_21815);
    _44CompileErr(55, _21815, 0);
L2: 

    /** 	add_file("init-.c")*/
    RefDS(_31602);
    RefDS(_21815);
    _57add_file(_31602, _21815);

    /** 	emit_c_output = TRUE*/
    _54emit_c_output_45119 = _13TRUE_437;

    /** 	c_puts("#include \"")*/
    RefDS(_31606);
    _54c_puts(_31606);

    /** 	c_puts("include/euphoria.h\"\n")*/
    RefDS(_31607);
    _54c_puts(_31607);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_21926);
    _54c_puts(_21926);

    /** 	c_h = open(output_dir & "main-.h", "w")*/
    Concat((object_ptr)&_31609, _57output_dir_41343, _31608);
    _54c_h_45123 = EOpen(_31609, _21921, 0);
    DeRefDS(_31609);
    _31609 = NOVALUE;

    /** 	if c_h = -1 then*/
    if (_54c_h_45123 != -1)
    goto L3; // [116] 128

    /** 		CompileErr(47)*/
    RefDS(_21815);
    _44CompileErr(47, _21815, 0);
L3: 

    /** 	add_file("main-.h")*/
    RefDS(_31608);
    RefDS(_21815);
    _57add_file(_31608, _21815);

    /** end procedure*/
    return;
    ;
}


void _3InitBackEnd(int _c_63297)
{
    int _31642 = NOVALUE;
    int _31641 = NOVALUE;
    int _31639 = NOVALUE;
    int _31638 = NOVALUE;
    int _31637 = NOVALUE;
    int _31636 = NOVALUE;
    int _31635 = NOVALUE;
    int _31632 = NOVALUE;
    int _31631 = NOVALUE;
    int _31628 = NOVALUE;
    int _31627 = NOVALUE;
    int _31624 = NOVALUE;
    int _31623 = NOVALUE;
    int _31621 = NOVALUE;
    int _31618 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_63297)) {
        _1 = (long)(DBL_PTR(_c_63297)->dbl);
        DeRefDS(_c_63297);
        _c_63297 = _1;
    }

    /** 	if c = 1 then*/
    if (_c_63297 != 1)
    goto L1; // [5] 19

    /** 		OpenCFiles()*/
    _3OpenCFiles();

    /** 		return*/
    return;
L1: 

    /** 	init_opcodes()*/
    _58init_opcodes();

    /** 	transoptions()*/
    _3transoptions();

    /** 	if compiler_type = COMPILER_UNKNOWN then*/
    if (_55compiler_type_43986 != 0)
    goto L2; // [33] 75

    /** 		if TWINDOWS then*/
    if (_40TWINDOWS_16112 == 0)
    {
        goto L3; // [41] 56
    }
    else{
    }

    /** 			compiler_type = COMPILER_WATCOM*/
    _55compiler_type_43986 = 2;
    goto L4; // [53] 74
L3: 

    /** 		elsif TUNIX then*/
    if (_40TUNIX_16116 == 0)
    {
        goto L5; // [60] 73
    }
    else{
    }

    /** 			compiler_type = COMPILER_GCC*/
    _55compiler_type_43986 = 1;
L5: 
L4: 
L2: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_43986;
    switch ( _0 ){ 

        /** 	  	case COMPILER_GCC then*/
        case 1:

        /** 			break -- to avoid empty block warning*/
        goto L6; // [90] 328
        goto L6; // [92] 328

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			wat_path = getenv("WATCOM")*/
        DeRefi(_35wat_path_16045);
        _35wat_path_16045 = EGetEnv(_31616);

        /** 			if atom(wat_path) then*/
        _31618 = IS_ATOM(_35wat_path_16045);
        if (_31618 == 0)
        {
            _31618 = NOVALUE;
            goto L7; // [110] 146
        }
        else{
            _31618 = NOVALUE;
        }

        /** 				if build_system_type = BUILD_DIRECT then*/
        if (_55build_system_type_43982 != 3)
        goto L8; // [119] 133

        /** 					CompileErr(159)*/
        RefDS(_21815);
        _44CompileErr(159, _21815, 0);
        goto L6; // [130] 328
L8: 

        /** 					Warning(159, translator_warning_flag)*/
        RefDS(_21815);
        _44Warning(159, 128, _21815);
        goto L6; // [143] 328
L7: 

        /** 			elsif find(' ', wat_path) then*/
        _31621 = find_from(32, _35wat_path_16045, 1);
        if (_31621 == 0)
        {
            _31621 = NOVALUE;
            goto L9; // [155] 170
        }
        else{
            _31621 = NOVALUE;
        }

        /** 				Warning( 214, translator_warning_flag)*/
        RefDS(_21815);
        _44Warning(214, 128, _21815);
        goto L6; // [167] 328
L9: 

        /** 			elsif atom(getenv("INCLUDE")) then*/
        _31623 = EGetEnv(_31622);
        _31624 = IS_ATOM(_31623);
        DeRef(_31623);
        _31623 = NOVALUE;
        if (_31624 == 0)
        {
            _31624 = NOVALUE;
            goto LA; // [178] 193
        }
        else{
            _31624 = NOVALUE;
        }

        /** 				Warning( 215, translator_warning_flag )*/
        RefDS(_21815);
        _44Warning(215, 128, _21815);
        goto L6; // [190] 328
LA: 

        /** 			elsif not file_exists(wat_path & SLASH & "binnt" & SLASH & "wcc386.exe") then*/
        {
            int concat_list[5];

            concat_list[0] = _31626;
            concat_list[1] = 47;
            concat_list[2] = _31625;
            concat_list[3] = 47;
            concat_list[4] = _35wat_path_16045;
            Concat_N((object_ptr)&_31627, concat_list, 5);
        }
        _31628 = _17file_exists(_31627);
        _31627 = NOVALUE;
        if (IS_ATOM_INT(_31628)) {
            if (_31628 != 0){
                DeRef(_31628);
                _31628 = NOVALUE;
                goto LB; // [213] 261
            }
        }
        else {
            if (DBL_PTR(_31628)->dbl != 0.0){
                DeRef(_31628);
                _31628 = NOVALUE;
                goto LB; // [213] 261
            }
        }
        DeRef(_31628);
        _31628 = NOVALUE;

        /** 				if build_system_type = BUILD_DIRECT then*/
        if (_55build_system_type_43982 != 3)
        goto LC; // [222] 242

        /** 					CompileErr( 352, {wat_path})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_35wat_path_16045);
        *((int *)(_2+4)) = _35wat_path_16045;
        _31631 = MAKE_SEQ(_1);
        _44CompileErr(352, _31631, 0);
        _31631 = NOVALUE;
        goto L6; // [239] 328
LC: 

        /** 					Warning( 352, translator_warning_flag, {wat_path})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_35wat_path_16045);
        *((int *)(_2+4)) = _35wat_path_16045;
        _31632 = MAKE_SEQ(_1);
        _44Warning(352, 128, _31632);
        _31632 = NOVALUE;
        goto L6; // [258] 328
LB: 

        /** 			elsif match(upper(wat_path & "\\H;" & wat_path & "\\H\\NT"),*/
        {
            int concat_list[4];

            concat_list[0] = _31634;
            concat_list[1] = _35wat_path_16045;
            concat_list[2] = _31633;
            concat_list[3] = _35wat_path_16045;
            Concat_N((object_ptr)&_31635, concat_list, 4);
        }
        _31636 = _14upper(_31635);
        _31635 = NOVALUE;
        _31637 = EGetEnv(_31622);
        _31638 = _14upper(_31637);
        _31637 = NOVALUE;
        _31639 = e_match_from(_31636, _31638, 1);
        DeRef(_31636);
        _31636 = NOVALUE;
        DeRef(_31638);
        _31638 = NOVALUE;
        if (_31639 == 1)
        goto L6; // [290] 328

        /** 				Warning( 216, translator_warning_flag, {wat_path,getenv("INCLUDE")} )*/
        _31641 = EGetEnv(_31622);
        Ref(_35wat_path_16045);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _35wat_path_16045;
        ((int *)_2)[2] = _31641;
        _31642 = MAKE_SEQ(_1);
        _31641 = NOVALUE;
        _44Warning(216, 128, _31642);
        _31642 = NOVALUE;
        goto L6; // [314] 328

        /** 		case else*/
        default:

        /** 			CompileErr(150)*/
        RefDS(_21815);
        _44CompileErr(150, _21815, 0);
    ;}L6: 

    /** end procedure*/
    return;
    ;
}


void _3CheckPlatform()
{
    int _31649 = NOVALUE;
    int _31647 = NOVALUE;
    int _31646 = NOVALUE;
    int _0, _1, _2;
    

    /** 	OpDefines = eu:remove(OpDefines,*/
    _31646 = find_from(_25209, _35OpDefines_16041, 1);
    _31647 = find_from(_25210, _35OpDefines_16041, 1);
    {
        s1_ptr assign_space = SEQ_PTR(_35OpDefines_16041);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_31646)) ? _31646 : (long)(DBL_PTR(_31646)->dbl);
        int stop = (IS_ATOM_INT(_31647)) ? _31647 : (long)(DBL_PTR(_31647)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_35OpDefines_16041), start, &_35OpDefines_16041 );
            }
            else Tail(SEQ_PTR(_35OpDefines_16041), stop+1, &_35OpDefines_16041);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_35OpDefines_16041), start, &_35OpDefines_16041);
        }
        else {
            assign_slice_seq = &assign_space;
            _35OpDefines_16041 = Remove_elements(start, stop, (SEQ_PTR(_35OpDefines_16041)->ref == 1));
        }
    }
    _31646 = NOVALUE;
    _31647 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines(1)*/
    _31649 = _40GetPlatformDefines(1);
    if (IS_SEQUENCE(_35OpDefines_16041) && IS_ATOM(_31649)) {
        Ref(_31649);
        Append(&_35OpDefines_16041, _35OpDefines_16041, _31649);
    }
    else if (IS_ATOM(_35OpDefines_16041) && IS_SEQUENCE(_31649)) {
    }
    else {
        Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _31649);
    }
    DeRef(_31649);
    _31649 = NOVALUE;

    /** end procedure*/
    return;
    ;
}



// 0xFB8B07F8
