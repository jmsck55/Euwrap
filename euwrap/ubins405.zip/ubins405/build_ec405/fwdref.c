// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _38clear_fwd_refs()
{
    int _0, _1, _2;
    

    /** 	fwdref_count = 0*/
    _38fwdref_count_61073 = 0;

    /** end procedure*/
    return;
    ;
}


int _38get_fwdref_count()
{
    int _0, _1, _2;
    

    /** 	return fwdref_count*/
    return _38fwdref_count_61073;
    ;
}


void _38set_glabel_block(int _ref_61080, int _block_61082)
{
    int _30521 = NOVALUE;
    int _30520 = NOVALUE;
    int _30518 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61080)) {
        _1 = (long)(DBL_PTR(_ref_61080)->dbl);
        DeRefDS(_ref_61080);
        _ref_61080 = _1;
    }
    if (!IS_ATOM_INT(_block_61082)) {
        _1 = (long)(DBL_PTR(_block_61082)->dbl);
        DeRefDS(_block_61082);
        _block_61082 = _1;
    }

    /** 	forward_references[ref][FR_DATA] &= block*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61080 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30520 = (int)*(((s1_ptr)_2)->base + 12);
    _30518 = NOVALUE;
    if (IS_SEQUENCE(_30520) && IS_ATOM(_block_61082)) {
        Append(&_30521, _30520, _block_61082);
    }
    else if (IS_ATOM(_30520) && IS_SEQUENCE(_block_61082)) {
    }
    else {
        Concat((object_ptr)&_30521, _30520, _block_61082);
        _30520 = NOVALUE;
    }
    _30520 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30521;
    if( _1 != _30521 ){
        DeRef(_1);
    }
    _30521 = NOVALUE;
    _30518 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _38replace_code(int _code_61094, int _start_61095, int _finish_61096, int _subprog_61097)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_61096)) {
        _1 = (long)(DBL_PTR(_finish_61096)->dbl);
        DeRefDS(_finish_61096);
        _finish_61096 = _1;
    }
    if (!IS_ATOM_INT(_subprog_61097)) {
        _1 = (long)(DBL_PTR(_subprog_61097)->dbl);
        DeRefDS(_subprog_61097);
        _subprog_61097 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_61097;

    /** 	shift:replace_code( code, start, finish )*/
    RefDS(_code_61094);
    _65replace_code(_code_61094, _start_61095, _finish_61096);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    DeRefDS(_code_61094);
    return;
    ;
}


void _38resolved_reference(int _ref_61100)
{
    int _file_61101 = NOVALUE;
    int _subprog_61104 = NOVALUE;
    int _tx_61107 = NOVALUE;
    int _ax_61108 = NOVALUE;
    int _sp_61109 = NOVALUE;
    int _r_61124 = NOVALUE;
    int _r_61142 = NOVALUE;
    int _30545 = NOVALUE;
    int _30544 = NOVALUE;
    int _30543 = NOVALUE;
    int _30541 = NOVALUE;
    int _30538 = NOVALUE;
    int _30536 = NOVALUE;
    int _30534 = NOVALUE;
    int _30533 = NOVALUE;
    int _30531 = NOVALUE;
    int _30529 = NOVALUE;
    int _30527 = NOVALUE;
    int _30526 = NOVALUE;
    int _30524 = NOVALUE;
    int _30522 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 		file    = forward_references[ref][FR_FILE],*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30522 = (int)*(((s1_ptr)_2)->base + _ref_61100);
    _2 = (int)SEQ_PTR(_30522);
    _file_61101 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_61101)){
        _file_61101 = (long)DBL_PTR(_file_61101)->dbl;
    }
    _30522 = NOVALUE;

    /** 		subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30524 = (int)*(((s1_ptr)_2)->base + _ref_61100);
    _2 = (int)SEQ_PTR(_30524);
    _subprog_61104 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_61104)){
        _subprog_61104 = (long)DBL_PTR(_subprog_61104)->dbl;
    }
    _30524 = NOVALUE;

    /** 		tx = 0,*/
    _tx_61107 = 0;

    /** 		ax = 0,*/
    _ax_61108 = 0;

    /** 		sp = 0*/
    _sp_61109 = 0;

    /** 	if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30526 = (int)*(((s1_ptr)_2)->base + _ref_61100);
    _2 = (int)SEQ_PTR(_30526);
    _30527 = (int)*(((s1_ptr)_2)->base + 4);
    _30526 = NOVALUE;
    if (binary_op_a(NOTEQ, _30527, _35TopLevelSub_15975)){
        _30527 = NOVALUE;
        goto L1; // [60] 80
    }
    _30527 = NOVALUE;

    /** 		tx = find( ref, toplevel_references[file] )*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    _30529 = (int)*(((s1_ptr)_2)->base + _file_61101);
    _tx_61107 = find_from(_ref_61100, _30529, 1);
    _30529 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** 		sp = find( subprog, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _30531 = (int)*(((s1_ptr)_2)->base + _file_61101);
    _sp_61109 = find_from(_subprog_61104, _30531, 1);
    _30531 = NOVALUE;

    /** 		ax = find( ref, active_references[file][sp] )*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _30533 = (int)*(((s1_ptr)_2)->base + _file_61101);
    _2 = (int)SEQ_PTR(_30533);
    _30534 = (int)*(((s1_ptr)_2)->base + _sp_61109);
    _30533 = NOVALUE;
    _ax_61108 = find_from(_ref_61100, _30534, 1);
    _30534 = NOVALUE;
L2: 

    /** 	if ax then*/
    if (_ax_61108 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** 		sequence r = active_references[file][sp] */
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _30536 = (int)*(((s1_ptr)_2)->base + _file_61101);
    DeRef(_r_61124);
    _2 = (int)SEQ_PTR(_30536);
    _r_61124 = (int)*(((s1_ptr)_2)->base + _sp_61109);
    Ref(_r_61124);
    _30536 = NOVALUE;

    /** 		active_references[file][sp] = 0*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61101 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61109);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30538 = NOVALUE;

    /** 		r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_61108)) ? _ax_61108 : (long)(DBL_PTR(_ax_61108)->dbl);
        int stop = (IS_ATOM_INT(_ax_61108)) ? _ax_61108 : (long)(DBL_PTR(_ax_61108)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61124), start, &_r_61124 );
            }
            else Tail(SEQ_PTR(_r_61124), stop+1, &_r_61124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61124), start, &_r_61124);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61124 = Remove_elements(start, stop, (SEQ_PTR(_r_61124)->ref == 1));
        }
    }

    /** 		active_references[file][sp] = r*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61101 + ((s1_ptr)_2)->base);
    RefDS(_r_61124);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61109);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61124;
    DeRef(_1);
    _30541 = NOVALUE;

    /** 		if not length( active_references[file][sp] ) then*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _30543 = (int)*(((s1_ptr)_2)->base + _file_61101);
    _2 = (int)SEQ_PTR(_30543);
    _30544 = (int)*(((s1_ptr)_2)->base + _sp_61109);
    _30543 = NOVALUE;
    if (IS_SEQUENCE(_30544)){
            _30545 = SEQ_PTR(_30544)->length;
    }
    else {
        _30545 = 1;
    }
    _30544 = NOVALUE;
    if (_30545 != 0)
    goto L4; // [178] 248
    _30545 = NOVALUE;

    /** 			r = active_references[file]*/
    DeRefDS(_r_61124);
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _r_61124 = (int)*(((s1_ptr)_2)->base + _file_61101);
    Ref(_r_61124);

    /** 			active_references[file] = 0*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61109)) ? _sp_61109 : (long)(DBL_PTR(_sp_61109)->dbl);
        int stop = (IS_ATOM_INT(_sp_61109)) ? _sp_61109 : (long)(DBL_PTR(_sp_61109)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61124), start, &_r_61124 );
            }
            else Tail(SEQ_PTR(_r_61124), stop+1, &_r_61124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61124), start, &_r_61124);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61124 = Remove_elements(start, stop, (SEQ_PTR(_r_61124)->ref == 1));
        }
    }

    /** 			active_references[file] = r*/
    RefDS(_r_61124);
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61124;
    DeRef(_1);

    /** 			r = active_subprogs[file]*/
    DeRefDS(_r_61124);
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _r_61124 = (int)*(((s1_ptr)_2)->base + _file_61101);
    Ref(_r_61124);

    /** 			active_subprogs[file] = 0*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61054 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61109)) ? _sp_61109 : (long)(DBL_PTR(_sp_61109)->dbl);
        int stop = (IS_ATOM_INT(_sp_61109)) ? _sp_61109 : (long)(DBL_PTR(_sp_61109)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61124), start, &_r_61124 );
            }
            else Tail(SEQ_PTR(_r_61124), stop+1, &_r_61124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61124), start, &_r_61124);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61124 = Remove_elements(start, stop, (SEQ_PTR(_r_61124)->ref == 1));
        }
    }

    /** 			active_subprogs[file] = r*/
    RefDS(_r_61124);
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61054 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61124;
    DeRef(_1);
L4: 
    DeRef(_r_61124);
    _r_61124 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** 	elsif tx then*/
    if (_tx_61107 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** 		sequence r = toplevel_references[file]*/
    DeRef(_r_61142);
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    _r_61142 = (int)*(((s1_ptr)_2)->base + _file_61101);
    Ref(_r_61142);

    /** 		toplevel_references[file] = 0*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61142);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_61107)) ? _tx_61107 : (long)(DBL_PTR(_tx_61107)->dbl);
        int stop = (IS_ATOM_INT(_tx_61107)) ? _tx_61107 : (long)(DBL_PTR(_tx_61107)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61142), start, &_r_61142 );
            }
            else Tail(SEQ_PTR(_r_61142), stop+1, &_r_61142);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61142), start, &_r_61142);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61142 = Remove_elements(start, stop, (SEQ_PTR(_r_61142)->ref == 1));
        }
    }

    /** 		toplevel_references[file] = r*/
    RefDS(_r_61142);
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61101);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61142;
    DeRef(_1);
    DeRefDS(_r_61142);
    _r_61142 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** 		InternalErr( 260 )*/
    RefDS(_21815);
    _44InternalErr(260, _21815);
L5: 

    /** 	inactive_references &= ref*/
    Append(&_38inactive_references_61057, _38inactive_references_61057, _ref_61100);

    /** 	forward_references[ref] = 0*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_61100);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** end procedure*/
    _30544 = NOVALUE;
    return;
    ;
}


void _38set_code(int _ref_61156)
{
    int _30561 = NOVALUE;
    int _30559 = NOVALUE;
    int _30557 = NOVALUE;
    int _30554 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30554 = (int)*(((s1_ptr)_2)->base + _ref_61156);
    _2 = (int)SEQ_PTR(_30554);
    _38patch_code_sub_61151 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_38patch_code_sub_61151)){
        _38patch_code_sub_61151 = (long)DBL_PTR(_38patch_code_sub_61151)->dbl;
    }
    _30554 = NOVALUE;

    /** 	if patch_code_sub != CurrentSub then*/
    if (_38patch_code_sub_61151 == _35CurrentSub_15976)
    goto L1; // [23] 119

    /** 		patch_code_temp = Code*/
    RefDS(_35Code_16056);
    DeRef(_38patch_code_temp_61148);
    _38patch_code_temp_61148 = _35Code_16056;

    /** 		patch_linetab_temp = LineTable*/
    RefDS(_35LineTable_16057);
    DeRef(_38patch_linetab_temp_61149);
    _38patch_linetab_temp_61149 = _35LineTable_16057;

    /** 		Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30557 = (int)*(((s1_ptr)_2)->base + _38patch_code_sub_61151);
    DeRefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(_30557);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    Ref(_35Code_16056);
    _30557 = NOVALUE;

    /** 		SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61151 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30559 = NOVALUE;

    /** 		LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30561 = (int)*(((s1_ptr)_2)->base + _38patch_code_sub_61151);
    DeRefDS(_35LineTable_16057);
    _2 = (int)SEQ_PTR(_30561);
    if (!IS_ATOM_INT(_35S_LINETAB_15676)){
        _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    }
    else{
        _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    }
    Ref(_35LineTable_16057);
    _30561 = NOVALUE;

    /** 		patch_current_sub = CurrentSub*/
    _38patch_current_sub_61153 = _35CurrentSub_15976;

    /** 		CurrentSub = patch_code_sub*/
    _35CurrentSub_15976 = _38patch_code_sub_61151;
    goto L2; // [116] 129
L1: 

    /** 		patch_current_sub = patch_code_sub*/
    _38patch_current_sub_61153 = _38patch_code_sub_61151;
L2: 

    /** end procedure*/
    return;
    ;
}


void _38reset_code()
{
    int _30565 = NOVALUE;
    int _30563 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61151 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16056;
    DeRef(_1);
    _30563 = NOVALUE;

    /** 	SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_38patch_code_sub_61151 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16057);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16057;
    DeRef(_1);
    _30565 = NOVALUE;

    /** 	if patch_code_sub != patch_current_sub then*/
    if (_38patch_code_sub_61151 == _38patch_current_sub_61153)
    goto L1; // [45] 77

    /** 		CurrentSub = patch_current_sub*/
    _35CurrentSub_15976 = _38patch_current_sub_61153;

    /** 		Code = patch_code_temp*/
    RefDS(_38patch_code_temp_61148);
    DeRefDS(_35Code_16056);
    _35Code_16056 = _38patch_code_temp_61148;

    /** 		LineTable = patch_linetab_temp*/
    RefDS(_38patch_linetab_temp_61149);
    DeRefDS(_35LineTable_16057);
    _35LineTable_16057 = _38patch_linetab_temp_61149;
L1: 

    /** 	patch_code_temp = {}*/
    RefDS(_21815);
    DeRef(_38patch_code_temp_61148);
    _38patch_code_temp_61148 = _21815;

    /** 	patch_linetab_temp = {}*/
    RefDS(_21815);
    DeRef(_38patch_linetab_temp_61149);
    _38patch_linetab_temp_61149 = _21815;

    /** end procedure*/
    return;
    ;
}


void _38set_data(int _ref_61200, int _data_61201)
{
    int _30568 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61200)) {
        _1 = (long)(DBL_PTR(_ref_61200)->dbl);
        DeRefDS(_ref_61200);
        _ref_61200 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61200 + ((s1_ptr)_2)->base);
    Ref(_data_61201);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_61201;
    DeRef(_1);
    _30568 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61201);
    return;
    ;
}


void _38add_data(int _ref_61206, int _data_61207)
{
    int _30574 = NOVALUE;
    int _30573 = NOVALUE;
    int _30572 = NOVALUE;
    int _30570 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61206)) {
        _1 = (long)(DBL_PTR(_ref_61206)->dbl);
        DeRefDS(_ref_61206);
        _ref_61206 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61206 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30572 = (int)*(((s1_ptr)_2)->base + _ref_61206);
    _2 = (int)SEQ_PTR(_30572);
    _30573 = (int)*(((s1_ptr)_2)->base + 12);
    _30572 = NOVALUE;
    Ref(_data_61207);
    Append(&_30574, _30573, _data_61207);
    _30573 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30574;
    if( _1 != _30574 ){
        DeRef(_1);
    }
    _30574 = NOVALUE;
    _30570 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61207);
    return;
    ;
}


void _38set_line(int _ref_61215, int _line_no_61216, int _this_line_61217, int _bp_61218)
{
    int _30579 = NOVALUE;
    int _30577 = NOVALUE;
    int _30575 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61215)) {
        _1 = (long)(DBL_PTR(_ref_61215)->dbl);
        DeRefDS(_ref_61215);
        _ref_61215 = _1;
    }
    if (!IS_ATOM_INT(_line_no_61216)) {
        _1 = (long)(DBL_PTR(_line_no_61216)->dbl);
        DeRefDS(_line_no_61216);
        _line_no_61216 = _1;
    }
    if (!IS_ATOM_INT(_bp_61218)) {
        _1 = (long)(DBL_PTR(_bp_61218)->dbl);
        DeRefDS(_bp_61218);
        _bp_61218 = _1;
    }

    /** 	forward_references[ref][FR_LINE] = line_no*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61215 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _line_no_61216;
    DeRef(_1);
    _30575 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61215 + ((s1_ptr)_2)->base);
    RefDS(_this_line_61217);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _this_line_61217;
    DeRef(_1);
    _30577 = NOVALUE;

    /** 	forward_references[ref][FR_BP] = bp*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61215 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _bp_61218;
    DeRef(_1);
    _30579 = NOVALUE;

    /** end procedure*/
    DeRefDS(_this_line_61217);
    return;
    ;
}


void _38add_private_symbol(int _sym_61230, int _name_61231)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_61230)) {
        _1 = (long)(DBL_PTR(_sym_61230)->dbl);
        DeRefDS(_sym_61230);
        _sym_61230 = _1;
    }

    /** 	fwd_private_sym &= sym*/
    Append(&_38fwd_private_sym_61225, _38fwd_private_sym_61225, _sym_61230);

    /** 	fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_61231);
    Append(&_38fwd_private_name_61226, _38fwd_private_name_61226, _name_61231);

    /** end procedure*/
    DeRefDS(_name_61231);
    return;
    ;
}


void _38patch_forward_goto(int _tok_61239, int _ref_61240)
{
    int _fr_61241 = NOVALUE;
    int _30595 = NOVALUE;
    int _30594 = NOVALUE;
    int _30593 = NOVALUE;
    int _30592 = NOVALUE;
    int _30591 = NOVALUE;
    int _30590 = NOVALUE;
    int _30589 = NOVALUE;
    int _30588 = NOVALUE;
    int _30586 = NOVALUE;
    int _30585 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61241);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61241 = (int)*(((s1_ptr)_2)->base + _ref_61240);
    Ref(_fr_61241);

    /** 	set_code( ref )*/
    _38set_code(_ref_61240);

    /** 	shifting_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61241);
    _38shifting_sub_61072 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_38shifting_sub_61072))
    _38shifting_sub_61072 = (long)DBL_PTR(_38shifting_sub_61072)->dbl;

    /** 	if length( fr[FR_DATA] ) = 2 then*/
    _2 = (int)SEQ_PTR(_fr_61241);
    _30585 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30585)){
            _30586 = SEQ_PTR(_30585)->length;
    }
    else {
        _30586 = 1;
    }
    _30585 = NOVALUE;
    if (_30586 != 2)
    goto L1; // [33] 62

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61240);

    /** 		CompileErr( 156, { fr[FR_DATA][2] })*/
    _2 = (int)SEQ_PTR(_fr_61241);
    _30588 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30588);
    _30589 = (int)*(((s1_ptr)_2)->base + 2);
    _30588 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30589);
    *((int *)(_2+4)) = _30589;
    _30590 = MAKE_SEQ(_1);
    _30589 = NOVALUE;
    _44CompileErr(156, _30590, 0);
    _30590 = NOVALUE;
L1: 

    /** 	Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (int)SEQ_PTR(_fr_61241);
    _30591 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30591);
    _30592 = (int)*(((s1_ptr)_2)->base + 1);
    _30591 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61241);
    _30593 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30593);
    _30594 = (int)*(((s1_ptr)_2)->base + 3);
    _30593 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61241);
    _30595 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30592);
    Ref(_30594);
    Ref(_30595);
    _66Goto_block(_30592, _30594, _30595);
    _30592 = NOVALUE;
    _30594 = NOVALUE;
    _30595 = NOVALUE;

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** 	reset_code()*/
    _38reset_code();

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61240);

    /** end procedure*/
    DeRefDS(_fr_61241);
    _30585 = NOVALUE;
    return;
    ;
}


void _38patch_forward_call(int _tok_61262, int _ref_61263)
{
    int _fr_61264 = NOVALUE;
    int _sub_61267 = NOVALUE;
    int _defarg_61273 = NOVALUE;
    int _paramsym_61277 = NOVALUE;
    int _old_61280 = NOVALUE;
    int _tx_61284 = NOVALUE;
    int _code_sub_61294 = NOVALUE;
    int _args_61296 = NOVALUE;
    int _is_func_61301 = NOVALUE;
    int _real_file_61315 = NOVALUE;
    int _code_61319 = NOVALUE;
    int _temp_sub_61321 = NOVALUE;
    int _pc_61323 = NOVALUE;
    int _next_pc_61325 = NOVALUE;
    int _supplied_args_61326 = NOVALUE;
    int _name_61329 = NOVALUE;
    int _old_temps_allocated_61353 = NOVALUE;
    int _temp_target_61362 = NOVALUE;
    int _converted_code_61365 = NOVALUE;
    int _target_61381 = NOVALUE;
    int _has_defaults_61387 = NOVALUE;
    int _goto_target_61388 = NOVALUE;
    int _defarg_61391 = NOVALUE;
    int _code_len_61392 = NOVALUE;
    int _extra_default_args_61394 = NOVALUE;
    int _param_sym_61397 = NOVALUE;
    int _params_61398 = NOVALUE;
    int _orig_code_61400 = NOVALUE;
    int _orig_linetable_61401 = NOVALUE;
    int _ar_sp_61404 = NOVALUE;
    int _pre_refs_61408 = NOVALUE;
    int _old_fwd_params_61423 = NOVALUE;
    int _temp_shifting_sub_61464 = NOVALUE;
    int _new_code_61468 = NOVALUE;
    int _routine_type_61477 = NOVALUE;
    int _31348 = NOVALUE;
    int _30732 = NOVALUE;
    int _30731 = NOVALUE;
    int _30730 = NOVALUE;
    int _30728 = NOVALUE;
    int _30727 = NOVALUE;
    int _30726 = NOVALUE;
    int _30725 = NOVALUE;
    int _30724 = NOVALUE;
    int _30723 = NOVALUE;
    int _30722 = NOVALUE;
    int _30721 = NOVALUE;
    int _30720 = NOVALUE;
    int _30719 = NOVALUE;
    int _30718 = NOVALUE;
    int _30717 = NOVALUE;
    int _30716 = NOVALUE;
    int _30714 = NOVALUE;
    int _30713 = NOVALUE;
    int _30712 = NOVALUE;
    int _30711 = NOVALUE;
    int _30710 = NOVALUE;
    int _30709 = NOVALUE;
    int _30708 = NOVALUE;
    int _30707 = NOVALUE;
    int _30705 = NOVALUE;
    int _30702 = NOVALUE;
    int _30701 = NOVALUE;
    int _30700 = NOVALUE;
    int _30699 = NOVALUE;
    int _30694 = NOVALUE;
    int _30693 = NOVALUE;
    int _30692 = NOVALUE;
    int _30691 = NOVALUE;
    int _30690 = NOVALUE;
    int _30688 = NOVALUE;
    int _30687 = NOVALUE;
    int _30686 = NOVALUE;
    int _30685 = NOVALUE;
    int _30684 = NOVALUE;
    int _30683 = NOVALUE;
    int _30681 = NOVALUE;
    int _30680 = NOVALUE;
    int _30678 = NOVALUE;
    int _30677 = NOVALUE;
    int _30676 = NOVALUE;
    int _30675 = NOVALUE;
    int _30673 = NOVALUE;
    int _30671 = NOVALUE;
    int _30670 = NOVALUE;
    int _30669 = NOVALUE;
    int _30667 = NOVALUE;
    int _30666 = NOVALUE;
    int _30664 = NOVALUE;
    int _30662 = NOVALUE;
    int _30659 = NOVALUE;
    int _30655 = NOVALUE;
    int _30653 = NOVALUE;
    int _30652 = NOVALUE;
    int _30650 = NOVALUE;
    int _30649 = NOVALUE;
    int _30648 = NOVALUE;
    int _30647 = NOVALUE;
    int _30645 = NOVALUE;
    int _30644 = NOVALUE;
    int _30643 = NOVALUE;
    int _30642 = NOVALUE;
    int _30641 = NOVALUE;
    int _30639 = NOVALUE;
    int _30638 = NOVALUE;
    int _30637 = NOVALUE;
    int _30636 = NOVALUE;
    int _30635 = NOVALUE;
    int _30634 = NOVALUE;
    int _30633 = NOVALUE;
    int _30632 = NOVALUE;
    int _30631 = NOVALUE;
    int _30629 = NOVALUE;
    int _30628 = NOVALUE;
    int _30627 = NOVALUE;
    int _30626 = NOVALUE;
    int _30625 = NOVALUE;
    int _30622 = NOVALUE;
    int _30618 = NOVALUE;
    int _30617 = NOVALUE;
    int _30616 = NOVALUE;
    int _30615 = NOVALUE;
    int _30614 = NOVALUE;
    int _30613 = NOVALUE;
    int _30611 = NOVALUE;
    int _30608 = NOVALUE;
    int _30606 = NOVALUE;
    int _30605 = NOVALUE;
    int _30603 = NOVALUE;
    int _30600 = NOVALUE;
    int _30599 = NOVALUE;
    int _30598 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61264);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61264 = (int)*(((s1_ptr)_2)->base + _ref_61263);
    Ref(_fr_61264);

    /** 	symtab_index sub = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61262);
    _sub_61267 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_61267)){
        _sub_61267 = (long)DBL_PTR(_sub_61267)->dbl;
    }

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _30598 = (int)*(((s1_ptr)_2)->base + 12);
    _30599 = IS_SEQUENCE(_30598);
    _30598 = NOVALUE;
    if (_30599 == 0)
    {
        _30599 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30599 = NOVALUE;
    }

    /** 		sequence defarg = fr[FR_DATA][1]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _30600 = (int)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_61273);
    _2 = (int)SEQ_PTR(_30600);
    _defarg_61273 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_61273);
    _30600 = NOVALUE;

    /** 		symtab_index paramsym = defarg[2]*/
    _2 = (int)SEQ_PTR(_defarg_61273);
    _paramsym_61277 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_61277)){
        _paramsym_61277 = (long)DBL_PTR(_paramsym_61277)->dbl;
    }

    /** 		token old = { RECORDED, defarg[3] }*/
    _2 = (int)SEQ_PTR(_defarg_61273);
    _30603 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30603);
    DeRef(_old_61280);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _30603;
    _old_61280 = MAKE_SEQ(_1);
    _30603 = NOVALUE;

    /** 		integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30605 = (int)*(((s1_ptr)_2)->base + _paramsym_61277);
    _2 = (int)SEQ_PTR(_30605);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _30606 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _30606 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _30605 = NOVALUE;
    _tx_61284 = find_from(_old_61280, _30606, 1);
    _30606 = NOVALUE;

    /** 		SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_paramsym_61277 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _3 = (int)(_35S_CODE_15653 + ((s1_ptr)_2)->base);
    _30608 = NOVALUE;
    Ref(_tok_61262);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _tx_61284);
    _1 = *(int *)_2;
    *(int *)_2 = _tok_61262;
    DeRef(_1);
    _30608 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61263);

    /** 		return*/
    DeRefDS(_defarg_61273);
    DeRefDS(_old_61280);
    DeRef(_tok_61262);
    DeRefDS(_fr_61264);
    DeRef(_code_61319);
    DeRef(_name_61329);
    DeRef(_params_61398);
    DeRef(_orig_code_61400);
    DeRef(_orig_linetable_61401);
    DeRef(_old_fwd_params_61423);
    DeRef(_new_code_61468);
    return;
L1: 
    DeRef(_defarg_61273);
    _defarg_61273 = NOVALUE;
    DeRef(_old_61280);
    _old_61280 = NOVALUE;

    /** 	integer code_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _code_sub_61294 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_61294))
    _code_sub_61294 = (long)DBL_PTR(_code_sub_61294)->dbl;

    /** 	integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30611 = (int)*(((s1_ptr)_2)->base + _sub_61267);
    _2 = (int)SEQ_PTR(_30611);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _args_61296 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _args_61296 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    if (!IS_ATOM_INT(_args_61296)){
        _args_61296 = (long)DBL_PTR(_args_61296)->dbl;
    }
    _30611 = NOVALUE;

    /** 	integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30613 = (int)*(((s1_ptr)_2)->base + _sub_61267);
    _2 = (int)SEQ_PTR(_30613);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _30614 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _30614 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _30613 = NOVALUE;
    if (IS_ATOM_INT(_30614)) {
        _30615 = (_30614 == 501);
    }
    else {
        _30615 = binary_op(EQUALS, _30614, 501);
    }
    _30614 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30616 = (int)*(((s1_ptr)_2)->base + _sub_61267);
    _2 = (int)SEQ_PTR(_30616);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _30617 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _30617 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _30616 = NOVALUE;
    if (IS_ATOM_INT(_30617)) {
        _30618 = (_30617 == 504);
    }
    else {
        _30618 = binary_op(EQUALS, _30617, 504);
    }
    _30617 = NOVALUE;
    if (IS_ATOM_INT(_30615) && IS_ATOM_INT(_30618)) {
        _is_func_61301 = (_30615 != 0 || _30618 != 0);
    }
    else {
        _is_func_61301 = binary_op(OR, _30615, _30618);
    }
    DeRef(_30615);
    _30615 = NOVALUE;
    DeRef(_30618);
    _30618 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_61301)) {
        _1 = (long)(DBL_PTR(_is_func_61301)->dbl);
        DeRefDS(_is_func_61301);
        _is_func_61301 = _1;
    }

    /** 	integer real_file = current_file_no*/
    _real_file_61315 = _35current_file_no_15968;

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _35current_file_no_15968 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_15968)){
        _35current_file_no_15968 = (long)DBL_PTR(_35current_file_no_15968)->dbl;
    }

    /** 	set_code( ref )*/
    _38set_code(_ref_61263);

    /** 	sequence code = Code*/
    RefDS(_35Code_16056);
    DeRef(_code_61319);
    _code_61319 = _35Code_16056;

    /** 	integer temp_sub = CurrentSub*/
    _temp_sub_61321 = _35CurrentSub_15976;

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _pc_61323 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61323))
    _pc_61323 = (long)DBL_PTR(_pc_61323)->dbl;

    /** 	integer next_pc = pc*/
    _next_pc_61325 = _pc_61323;

    /** 	integer supplied_args = code[pc+2]*/
    _30622 = _pc_61323 + 2;
    _2 = (int)SEQ_PTR(_code_61319);
    _supplied_args_61326 = (int)*(((s1_ptr)_2)->base + _30622);
    if (!IS_ATOM_INT(_supplied_args_61326))
    _supplied_args_61326 = (long)DBL_PTR(_supplied_args_61326)->dbl;

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_61329);
    _2 = (int)SEQ_PTR(_fr_61264);
    _name_61329 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_61329);

    /** 	if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _30625 = (int)*(((s1_ptr)_2)->base + _pc_61323);
    if (IS_ATOM_INT(_30625)) {
        _30626 = (_30625 != 196);
    }
    else {
        _30626 = binary_op(NOTEQ, _30625, 196);
    }
    _30625 = NOVALUE;
    if (IS_ATOM_INT(_30626)) {
        if (_30626 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30626)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (int)SEQ_PTR(_35Code_16056);
    _30628 = (int)*(((s1_ptr)_2)->base + _pc_61323);
    if (IS_ATOM_INT(_30628)) {
        _30629 = (_30628 != 195);
    }
    else {
        _30629 = binary_op(NOTEQ, _30628, 195);
    }
    _30628 = NOVALUE;
    if (_30629 == 0) {
        DeRef(_30629);
        _30629 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30629) && DBL_PTR(_30629)->dbl == 0.0){
            DeRef(_30629);
            _30629 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30629);
        _30629 = NOVALUE;
    }
    DeRef(_30629);
    _30629 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61263);

    /** 		CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _30631 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _2 = (int)SEQ_PTR(_fr_61264);
    _30632 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_30632);
    _30633 = _53sym_name(_30632);
    _30632 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61264);
    _30634 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_fr_61264);
    _30635 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30631);
    *((int *)(_2+4)) = _30631;
    *((int *)(_2+8)) = _30633;
    Ref(_30634);
    *((int *)(_2+12)) = _30634;
    Ref(_30635);
    *((int *)(_2+16)) = _30635;
    _30636 = MAKE_SEQ(_1);
    _30635 = NOVALUE;
    _30634 = NOVALUE;
    _30633 = NOVALUE;
    _30631 = NOVALUE;
    RefDS(_30630);
    _44CompileErr(_30630, _30636, 0);
    _30636 = NOVALUE;
L2: 

    /** 	integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_61353 = _53temps_allocated_46235;

    /** 	temps_allocated = 0*/
    _53temps_allocated_46235 = 0;

    /** 	if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_61301 == 0) {
        goto L3; // [350] 438
    }
    _2 = (int)SEQ_PTR(_fr_61264);
    _30638 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30638)) {
        _30639 = (_30638 == 27);
    }
    else {
        _30639 = binary_op(EQUALS, _30638, 27);
    }
    _30638 = NOVALUE;
    if (_30639 == 0) {
        DeRef(_30639);
        _30639 = NOVALUE;
        goto L3; // [365] 438
    }
    else {
        if (!IS_ATOM_INT(_30639) && DBL_PTR(_30639)->dbl == 0.0){
            DeRef(_30639);
            _30639 = NOVALUE;
            goto L3; // [365] 438
        }
        DeRef(_30639);
        _30639 = NOVALUE;
    }
    DeRef(_30639);
    _30639 = NOVALUE;

    /** 		symtab_index temp_target = NewTempSym()*/
    _temp_target_61362 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_61362)) {
        _1 = (long)(DBL_PTR(_temp_target_61362)->dbl);
        DeRefDS(_temp_target_61362);
        _temp_target_61362 = _1;
    }

    /** 		sequence converted_code = */
    _30641 = _pc_61323 + 1;
    if (_30641 > MAXINT){
        _30641 = NewDouble((double)_30641);
    }
    _30642 = _pc_61323 + 2;
    if ((long)((unsigned long)_30642 + (unsigned long)HIGH_BITS) >= 0) 
    _30642 = NewDouble((double)_30642);
    if (IS_ATOM_INT(_30642)) {
        _30643 = _30642 + _supplied_args_61326;
    }
    else {
        _30643 = NewDouble(DBL_PTR(_30642)->dbl + (double)_supplied_args_61326);
    }
    DeRef(_30642);
    _30642 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30644;
    RHS_Slice(_35Code_16056, _30641, _30643);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 208;
    ((int *)_2)[2] = _temp_target_61362;
    _30645 = MAKE_SEQ(_1);
    {
        int concat_list[4];

        concat_list[0] = _30645;
        concat_list[1] = _temp_target_61362;
        concat_list[2] = _30644;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_61365, concat_list, 4);
    }
    DeRefDS(_30645);
    _30645 = NOVALUE;
    DeRefDS(_30644);
    _30644 = NOVALUE;

    /** 		replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30647 = _pc_61323 + 2;
    if ((long)((unsigned long)_30647 + (unsigned long)HIGH_BITS) >= 0) 
    _30647 = NewDouble((double)_30647);
    if (IS_ATOM_INT(_30647)) {
        _30648 = _30647 + _supplied_args_61326;
        if ((long)((unsigned long)_30648 + (unsigned long)HIGH_BITS) >= 0) 
        _30648 = NewDouble((double)_30648);
    }
    else {
        _30648 = NewDouble(DBL_PTR(_30647)->dbl + (double)_supplied_args_61326);
    }
    DeRef(_30647);
    _30647 = NOVALUE;
    RefDS(_converted_code_61365);
    _38replace_code(_converted_code_61365, _pc_61323, _30648, _code_sub_61294);
    _30648 = NOVALUE;

    /** 		code = Code*/
    RefDS(_35Code_16056);
    DeRef(_code_61319);
    _code_61319 = _35Code_16056;
L3: 
    DeRef(_converted_code_61365);
    _converted_code_61365 = NOVALUE;

    /** 	next_pc +=*/
    _30649 = 3 + _supplied_args_61326;
    if ((long)((unsigned long)_30649 + (unsigned long)HIGH_BITS) >= 0) 
    _30649 = NewDouble((double)_30649);
    if (IS_ATOM_INT(_30649)) {
        _30650 = _30649 + _is_func_61301;
        if ((long)((unsigned long)_30650 + (unsigned long)HIGH_BITS) >= 0) 
        _30650 = NewDouble((double)_30650);
    }
    else {
        _30650 = NewDouble(DBL_PTR(_30649)->dbl + (double)_is_func_61301);
    }
    DeRef(_30649);
    _30649 = NOVALUE;
    if (IS_ATOM_INT(_30650)) {
        _next_pc_61325 = _next_pc_61325 + _30650;
    }
    else {
        _next_pc_61325 = NewDouble((double)_next_pc_61325 + DBL_PTR(_30650)->dbl);
    }
    DeRef(_30650);
    _30650 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_61325)) {
        _1 = (long)(DBL_PTR(_next_pc_61325)->dbl);
        DeRefDS(_next_pc_61325);
        _next_pc_61325 = _1;
    }

    /** 	integer target*/

    /** 	if is_func then*/
    if (_is_func_61301 == 0)
    {
        goto L4; // [460] 482
    }
    else{
    }

    /** 		target = Code[pc + 3 + supplied_args]*/
    _30652 = _pc_61323 + 3;
    if ((long)((unsigned long)_30652 + (unsigned long)HIGH_BITS) >= 0) 
    _30652 = NewDouble((double)_30652);
    if (IS_ATOM_INT(_30652)) {
        _30653 = _30652 + _supplied_args_61326;
    }
    else {
        _30653 = NewDouble(DBL_PTR(_30652)->dbl + (double)_supplied_args_61326);
    }
    DeRef(_30652);
    _30652 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!IS_ATOM_INT(_30653)){
        _target_61381 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30653)->dbl));
    }
    else{
        _target_61381 = (int)*(((s1_ptr)_2)->base + _30653);
    }
    if (!IS_ATOM_INT(_target_61381)){
        _target_61381 = (long)DBL_PTR(_target_61381)->dbl;
    }
L4: 

    /** 	integer has_defaults = 0*/
    _has_defaults_61387 = 0;

    /** 	integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_61319)){
            _30655 = SEQ_PTR(_code_61319)->length;
    }
    else {
        _30655 = 1;
    }
    _goto_target_61388 = _30655 + 1;
    _30655 = NOVALUE;

    /** 	integer defarg = 0*/
    _defarg_61391 = 0;

    /** 	integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_61319)){
            _code_len_61392 = SEQ_PTR(_code_61319)->length;
    }
    else {
        _code_len_61392 = 1;
    }

    /** 	integer extra_default_args = 0*/
    _extra_default_args_61394 = 0;

    /** 	set_dont_read( 1 )*/
    _61set_dont_read(1);

    /** 	reset_private_lists()*/

    /** 	fwd_private_sym  = {}*/
    RefDS(_21815);
    DeRefi(_38fwd_private_sym_61225);
    _38fwd_private_sym_61225 = _21815;

    /** 	fwd_private_name = {}*/
    RefDS(_21815);
    DeRef(_38fwd_private_name_61226);
    _38fwd_private_name_61226 = _21815;

    /** end procedure*/
    goto L5; // [534] 537
L5: 

    /** 	integer param_sym = sub*/
    _param_sym_61397 = _sub_61267;

    /** 	sequence params = repeat( 0, args )*/
    DeRef(_params_61398);
    _params_61398 = Repeat(0, _args_61296);

    /** 	sequence orig_code = code*/
    RefDS(_code_61319);
    DeRef(_orig_code_61400);
    _orig_code_61400 = _code_61319;

    /** 	sequence orig_linetable = LineTable*/
    RefDS(_35LineTable_16057);
    DeRef(_orig_linetable_61401);
    _orig_linetable_61401 = _35LineTable_16057;

    /** 	Code = {}*/
    RefDS(_21815);
    DeRef(_35Code_16056);
    _35Code_16056 = _21815;

    /** 	integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _30659 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _ar_sp_61404 = find_from(_code_sub_61294, _30659, 1);
    _30659 = NOVALUE;

    /** 	integer pre_refs*/

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61294 != _35TopLevelSub_15975)
    goto L6; // [594] 614

    /** 		pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    _30662 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_30662)){
            _pre_refs_61408 = SEQ_PTR(_30662)->length;
    }
    else {
        _pre_refs_61408 = 1;
    }
    _30662 = NOVALUE;
    goto L7; // [611] 647
L6: 

    /** 		ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _30664 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _ar_sp_61404 = find_from(_code_sub_61294, _30664, 1);
    _30664 = NOVALUE;

    /** 		pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _30666 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _2 = (int)SEQ_PTR(_30666);
    _30667 = (int)*(((s1_ptr)_2)->base + _ar_sp_61404);
    _30666 = NOVALUE;
    if (IS_SEQUENCE(_30667)){
            _pre_refs_61408 = SEQ_PTR(_30667)->length;
    }
    else {
        _pre_refs_61408 = 1;
    }
    _30667 = NOVALUE;
L7: 

    /** 	sequence old_fwd_params = {}*/
    RefDS(_21815);
    DeRef(_old_fwd_params_61423);
    _old_fwd_params_61423 = _21815;

    /** 	for i = pc + 3 to pc + args + 2 do*/
    _30669 = _pc_61323 + 3;
    if ((long)((unsigned long)_30669 + (unsigned long)HIGH_BITS) >= 0) 
    _30669 = NewDouble((double)_30669);
    _30670 = _pc_61323 + _args_61296;
    if ((long)((unsigned long)_30670 + (unsigned long)HIGH_BITS) >= 0) 
    _30670 = NewDouble((double)_30670);
    if (IS_ATOM_INT(_30670)) {
        _30671 = _30670 + 2;
        if ((long)((unsigned long)_30671 + (unsigned long)HIGH_BITS) >= 0) 
        _30671 = NewDouble((double)_30671);
    }
    else {
        _30671 = NewDouble(DBL_PTR(_30670)->dbl + (double)2);
    }
    DeRef(_30670);
    _30670 = NOVALUE;
    {
        int _i_61425;
        Ref(_30669);
        _i_61425 = _30669;
L8: 
        if (binary_op_a(GREATER, _i_61425, _30671)){
            goto L9; // [668] 829
        }

        /** 		defarg += 1*/
        _defarg_61391 = _defarg_61391 + 1;

        /** 		param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30673 = (int)*(((s1_ptr)_2)->base + _param_sym_61397);
        _2 = (int)SEQ_PTR(_30673);
        _param_sym_61397 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_61397)){
            _param_sym_61397 = (long)DBL_PTR(_param_sym_61397)->dbl;
        }
        _30673 = NOVALUE;

        /** 		if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _30675 = (_defarg_61391 > _supplied_args_61326);
        if (_30675 != 0) {
            _30676 = 1;
            goto LA; // [703] 718
        }
        if (IS_SEQUENCE(_code_61319)){
                _30677 = SEQ_PTR(_code_61319)->length;
        }
        else {
            _30677 = 1;
        }
        if (IS_ATOM_INT(_i_61425)) {
            _30678 = (_i_61425 > _30677);
        }
        else {
            _30678 = (DBL_PTR(_i_61425)->dbl > (double)_30677);
        }
        _30677 = NOVALUE;
        _30676 = (_30678 != 0);
LA: 
        if (_30676 != 0) {
            goto LB; // [718] 734
        }
        _2 = (int)SEQ_PTR(_code_61319);
        if (!IS_ATOM_INT(_i_61425)){
            _30680 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61425)->dbl));
        }
        else{
            _30680 = (int)*(((s1_ptr)_2)->base + _i_61425);
        }
        if (IS_ATOM_INT(_30680)) {
            _30681 = (_30680 == 0);
        }
        else {
            _30681 = unary_op(NOT, _30680);
        }
        _30680 = NOVALUE;
        if (_30681 == 0) {
            DeRef(_30681);
            _30681 = NOVALUE;
            goto LC; // [730] 784
        }
        else {
            if (!IS_ATOM_INT(_30681) && DBL_PTR(_30681)->dbl == 0.0){
                DeRef(_30681);
                _30681 = NOVALUE;
                goto LC; // [730] 784
            }
            DeRef(_30681);
            _30681 = NOVALUE;
        }
        DeRef(_30681);
        _30681 = NOVALUE;
LB: 

        /** 			has_defaults = 1*/
        _has_defaults_61387 = 1;

        /** 			extra_default_args += 1*/
        _extra_default_args_61394 = _extra_default_args_61394 + 1;

        /** 			show_params( sub )*/
        _53show_params(_sub_61267);

        /** 			set_error_info( ref )*/
        _38set_error_info(_ref_61263);

        /** 			Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_38fwd_private_name_61226);
        RefDS(_38fwd_private_sym_61225);
        _39Parse_default_arg(_sub_61267, _defarg_61391, _38fwd_private_name_61226, _38fwd_private_sym_61225);

        /** 			hide_params( sub )*/
        _53hide_params(_sub_61267);

        /** 			params[defarg] = Pop()*/
        _30683 = _41Pop();
        _2 = (int)SEQ_PTR(_params_61398);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61391);
        _1 = *(int *)_2;
        *(int *)_2 = _30683;
        if( _1 != _30683 ){
            DeRef(_1);
        }
        _30683 = NOVALUE;
        goto LD; // [781] 822
LC: 

        /** 			extra_default_args = 0*/
        _extra_default_args_61394 = 0;

        /** 			add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (int)SEQ_PTR(_code_61319);
        if (!IS_ATOM_INT(_i_61425)){
            _30684 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61425)->dbl));
        }
        else{
            _30684 = (int)*(((s1_ptr)_2)->base + _i_61425);
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30685 = (int)*(((s1_ptr)_2)->base + _param_sym_61397);
        _2 = (int)SEQ_PTR(_30685);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _30686 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _30686 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        _30685 = NOVALUE;
        Ref(_30684);
        Ref(_30686);
        _38add_private_symbol(_30684, _30686);
        _30684 = NOVALUE;
        _30686 = NOVALUE;

        /** 			params[defarg] = code[i]*/
        _2 = (int)SEQ_PTR(_code_61319);
        if (!IS_ATOM_INT(_i_61425)){
            _30687 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61425)->dbl));
        }
        else{
            _30687 = (int)*(((s1_ptr)_2)->base + _i_61425);
        }
        Ref(_30687);
        _2 = (int)SEQ_PTR(_params_61398);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61391);
        _1 = *(int *)_2;
        *(int *)_2 = _30687;
        if( _1 != _30687 ){
            DeRef(_1);
        }
        _30687 = NOVALUE;
LD: 

        /** 	end for*/
        _0 = _i_61425;
        if (IS_ATOM_INT(_i_61425)) {
            _i_61425 = _i_61425 + 1;
            if ((long)((unsigned long)_i_61425 +(unsigned long) HIGH_BITS) >= 0){
                _i_61425 = NewDouble((double)_i_61425);
            }
        }
        else {
            _i_61425 = binary_op_a(PLUS, _i_61425, 1);
        }
        DeRef(_0);
        goto L8; // [824] 675
L9: 
        ;
        DeRef(_i_61425);
    }

    /** 	SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_code_sub_61294 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701)){
        _30690 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    }
    else{
        _30690 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    }
    _30688 = NOVALUE;
    if (IS_ATOM_INT(_30690)) {
        _30691 = _30690 + _53temps_allocated_46235;
        if ((long)((unsigned long)_30691 + (unsigned long)HIGH_BITS) >= 0) 
        _30691 = NewDouble((double)_30691);
    }
    else {
        _30691 = binary_op(PLUS, _30690, _53temps_allocated_46235);
    }
    _30690 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    _1 = *(int *)_2;
    *(int *)_2 = _30691;
    if( _1 != _30691 ){
        DeRef(_1);
    }
    _30691 = NOVALUE;
    _30688 = NOVALUE;

    /** 	temps_allocated = old_temps_allocated*/
    _53temps_allocated_46235 = _old_temps_allocated_61353;

    /** 	integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_61464 = _38shifting_sub_61072;

    /** 	shift( -pc, pc-1 )*/
    if ((unsigned long)_pc_61323 == 0xC0000000)
    _30692 = (int)NewDouble((double)-0xC0000000);
    else
    _30692 = - _pc_61323;
    _30693 = _pc_61323 - 1;
    if ((long)((unsigned long)_30693 +(unsigned long) HIGH_BITS) >= 0){
        _30693 = NewDouble((double)_30693);
    }
    Ref(_30692);
    DeRef(_31348);
    _31348 = _30692;
    _65shift(_30692, _30693, _31348);
    _30692 = NOVALUE;
    _30693 = NOVALUE;
    _31348 = NOVALUE;

    /** 	sequence new_code = Code*/
    RefDS(_35Code_16056);
    DeRef(_new_code_61468);
    _new_code_61468 = _35Code_16056;

    /** 	Code = orig_code*/
    RefDS(_orig_code_61400);
    DeRefDS(_35Code_16056);
    _35Code_16056 = _orig_code_61400;

    /** 	LineTable = orig_linetable*/
    RefDS(_orig_linetable_61401);
    DeRef(_35LineTable_16057);
    _35LineTable_16057 = _orig_linetable_61401;

    /** 	set_dont_read( 0 )*/
    _61set_dont_read(0);

    /** 	current_file_no = real_file*/
    _35current_file_no_15968 = _real_file_61315;

    /** 	if args != ( supplied_args + extra_default_args ) then*/
    _30694 = _supplied_args_61326 + _extra_default_args_61394;
    if ((long)((unsigned long)_30694 + (unsigned long)HIGH_BITS) >= 0) 
    _30694 = NewDouble((double)_30694);
    if (binary_op_a(EQUALS, _args_61296, _30694)){
        DeRef(_30694);
        _30694 = NOVALUE;
        goto LE; // [926] 1004
    }
    DeRef(_30694);
    _30694 = NOVALUE;

    /** 		sequence routine_type*/

    /** 		if is_func then */
    if (_is_func_61301 == 0)
    {
        goto LF; // [934] 947
    }
    else{
    }

    /** 			routine_type = "function"*/
    RefDS(_26046);
    DeRefi(_routine_type_61477);
    _routine_type_61477 = _26046;
    goto L10; // [944] 955
LF: 

    /** 			routine_type = "procedure"*/
    RefDS(_26100);
    DeRefi(_routine_type_61477);
    _routine_type_61477 = _26100;
L10: 

    /** 		current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _35current_file_no_15968 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_15968)){
        _35current_file_no_15968 = (long)DBL_PTR(_35current_file_no_15968)->dbl;
    }

    /** 		line_number = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61264);
    _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_15969)){
        _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
    }

    /** 		CompileErr( 158,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _30699 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _30700 = _supplied_args_61326 + _extra_default_args_61394;
    if ((long)((unsigned long)_30700 + (unsigned long)HIGH_BITS) >= 0) 
    _30700 = NewDouble((double)_30700);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30699);
    *((int *)(_2+4)) = _30699;
    *((int *)(_2+8)) = _35line_number_15969;
    RefDS(_routine_type_61477);
    *((int *)(_2+12)) = _routine_type_61477;
    RefDS(_name_61329);
    *((int *)(_2+16)) = _name_61329;
    *((int *)(_2+20)) = _args_61296;
    *((int *)(_2+24)) = _30700;
    _30701 = MAKE_SEQ(_1);
    _30700 = NOVALUE;
    _30699 = NOVALUE;
    _44CompileErr(158, _30701, 0);
    _30701 = NOVALUE;
LE: 
    DeRefi(_routine_type_61477);
    _routine_type_61477 = NOVALUE;

    /** 	new_code &= PROC & sub & params*/
    {
        int concat_list[3];

        concat_list[0] = _params_61398;
        concat_list[1] = _sub_61267;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_30702, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_61468, _new_code_61468, _30702);
    DeRefDS(_30702);
    _30702 = NOVALUE;

    /** 	if is_func then*/
    if (_is_func_61301 == 0)
    {
        goto L11; // [1022] 1034
    }
    else{
    }

    /** 		new_code &= target*/
    Append(&_new_code_61468, _new_code_61468, _target_61381);
L11: 

    /** 	replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _30705 = _next_pc_61325 - 1;
    if ((long)((unsigned long)_30705 +(unsigned long) HIGH_BITS) >= 0){
        _30705 = NewDouble((double)_30705);
    }
    RefDS(_new_code_61468);
    _38replace_code(_new_code_61468, _pc_61323, _30705, _code_sub_61294);
    _30705 = NOVALUE;

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61294 != _35TopLevelSub_15975)
    goto L12; // [1050] 1131

    /** 		for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _30707 = _pre_refs_61408 + 1;
    if (_30707 > MAXINT){
        _30707 = NewDouble((double)_30707);
    }
    _2 = (int)SEQ_PTR(_fr_61264);
    _30708 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    if (!IS_ATOM_INT(_30708)){
        _30709 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30708)->dbl));
    }
    else{
        _30709 = (int)*(((s1_ptr)_2)->base + _30708);
    }
    if (IS_SEQUENCE(_30709)){
            _30710 = SEQ_PTR(_30709)->length;
    }
    else {
        _30710 = 1;
    }
    _30709 = NOVALUE;
    {
        int _i_61502;
        Ref(_30707);
        _i_61502 = _30707;
L13: 
        if (binary_op_a(GREATER, _i_61502, _30710)){
            goto L14; // [1075] 1128
        }

        /** 			forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61264);
        _30711 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_38toplevel_references_61056);
        if (!IS_ATOM_INT(_30711)){
            _30712 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30711)->dbl));
        }
        else{
            _30712 = (int)*(((s1_ptr)_2)->base + _30711);
        }
        _2 = (int)SEQ_PTR(_30712);
        if (!IS_ATOM_INT(_i_61502)){
            _30713 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61502)->dbl));
        }
        else{
            _30713 = (int)*(((s1_ptr)_2)->base + _i_61502);
        }
        _30712 = NOVALUE;
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30713))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30713)->dbl));
        else
        _3 = (int)(_30713 + ((s1_ptr)_2)->base);
        _30716 = _pc_61323 - 1;
        if ((long)((unsigned long)_30716 +(unsigned long) HIGH_BITS) >= 0){
            _30716 = NewDouble((double)_30716);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _30717 = (int)*(((s1_ptr)_2)->base + 5);
        _30714 = NOVALUE;
        if (IS_ATOM_INT(_30717) && IS_ATOM_INT(_30716)) {
            _30718 = _30717 + _30716;
            if ((long)((unsigned long)_30718 + (unsigned long)HIGH_BITS) >= 0) 
            _30718 = NewDouble((double)_30718);
        }
        else {
            _30718 = binary_op(PLUS, _30717, _30716);
        }
        _30717 = NOVALUE;
        DeRef(_30716);
        _30716 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _30718;
        if( _1 != _30718 ){
            DeRef(_1);
        }
        _30718 = NOVALUE;
        _30714 = NOVALUE;

        /** 		end for*/
        _0 = _i_61502;
        if (IS_ATOM_INT(_i_61502)) {
            _i_61502 = _i_61502 + 1;
            if ((long)((unsigned long)_i_61502 +(unsigned long) HIGH_BITS) >= 0){
                _i_61502 = NewDouble((double)_i_61502);
            }
        }
        else {
            _i_61502 = binary_op_a(PLUS, _i_61502, 1);
        }
        DeRef(_0);
        goto L13; // [1123] 1082
L14: 
        ;
        DeRef(_i_61502);
    }
    goto L15; // [1128] 1214
L12: 

    /** 		for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _30719 = _pre_refs_61408 + 1;
    if (_30719 > MAXINT){
        _30719 = NewDouble((double)_30719);
    }
    _2 = (int)SEQ_PTR(_fr_61264);
    _30720 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!IS_ATOM_INT(_30720)){
        _30721 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30720)->dbl));
    }
    else{
        _30721 = (int)*(((s1_ptr)_2)->base + _30720);
    }
    _2 = (int)SEQ_PTR(_30721);
    _30722 = (int)*(((s1_ptr)_2)->base + _ar_sp_61404);
    _30721 = NOVALUE;
    if (IS_SEQUENCE(_30722)){
            _30723 = SEQ_PTR(_30722)->length;
    }
    else {
        _30723 = 1;
    }
    _30722 = NOVALUE;
    {
        int _i_61517;
        Ref(_30719);
        _i_61517 = _30719;
L16: 
        if (binary_op_a(GREATER, _i_61517, _30723)){
            goto L17; // [1156] 1213
        }

        /** 			forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61264);
        _30724 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_38active_references_61055);
        if (!IS_ATOM_INT(_30724)){
            _30725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30724)->dbl));
        }
        else{
            _30725 = (int)*(((s1_ptr)_2)->base + _30724);
        }
        _2 = (int)SEQ_PTR(_30725);
        _30726 = (int)*(((s1_ptr)_2)->base + _ar_sp_61404);
        _30725 = NOVALUE;
        _2 = (int)SEQ_PTR(_30726);
        if (!IS_ATOM_INT(_i_61517)){
            _30727 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61517)->dbl));
        }
        else{
            _30727 = (int)*(((s1_ptr)_2)->base + _i_61517);
        }
        _30726 = NOVALUE;
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30727))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30727)->dbl));
        else
        _3 = (int)(_30727 + ((s1_ptr)_2)->base);
        _30730 = _pc_61323 - 1;
        if ((long)((unsigned long)_30730 +(unsigned long) HIGH_BITS) >= 0){
            _30730 = NewDouble((double)_30730);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _30731 = (int)*(((s1_ptr)_2)->base + 5);
        _30728 = NOVALUE;
        if (IS_ATOM_INT(_30731) && IS_ATOM_INT(_30730)) {
            _30732 = _30731 + _30730;
            if ((long)((unsigned long)_30732 + (unsigned long)HIGH_BITS) >= 0) 
            _30732 = NewDouble((double)_30732);
        }
        else {
            _30732 = binary_op(PLUS, _30731, _30730);
        }
        _30731 = NOVALUE;
        DeRef(_30730);
        _30730 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _30732;
        if( _1 != _30732 ){
            DeRef(_1);
        }
        _30732 = NOVALUE;
        _30728 = NOVALUE;

        /** 		end for*/
        _0 = _i_61517;
        if (IS_ATOM_INT(_i_61517)) {
            _i_61517 = _i_61517 + 1;
            if ((long)((unsigned long)_i_61517 +(unsigned long) HIGH_BITS) >= 0){
                _i_61517 = NewDouble((double)_i_61517);
            }
        }
        else {
            _i_61517 = binary_op_a(PLUS, _i_61517, 1);
        }
        DeRef(_0);
        goto L16; // [1208] 1163
L17: 
        ;
        DeRef(_i_61517);
    }
L15: 

    /** 	reset_code()*/
    _38reset_code();

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61263);

    /** end procedure*/
    DeRef(_tok_61262);
    DeRef(_fr_61264);
    DeRef(_code_61319);
    DeRef(_name_61329);
    DeRef(_params_61398);
    DeRef(_orig_code_61400);
    DeRef(_orig_linetable_61401);
    DeRef(_old_fwd_params_61423);
    DeRef(_new_code_61468);
    DeRef(_30641);
    _30641 = NOVALUE;
    DeRef(_30671);
    _30671 = NOVALUE;
    DeRef(_30622);
    _30622 = NOVALUE;
    DeRef(_30678);
    _30678 = NOVALUE;
    _30722 = NOVALUE;
    _30724 = NOVALUE;
    _30720 = NOVALUE;
    _30711 = NOVALUE;
    DeRef(_30707);
    _30707 = NOVALUE;
    DeRef(_30643);
    _30643 = NOVALUE;
    _30709 = NOVALUE;
    _30662 = NOVALUE;
    DeRef(_30675);
    _30675 = NOVALUE;
    _30713 = NOVALUE;
    _30667 = NOVALUE;
    DeRef(_30669);
    _30669 = NOVALUE;
    _30727 = NOVALUE;
    DeRef(_30653);
    _30653 = NOVALUE;
    _30708 = NOVALUE;
    DeRef(_30719);
    _30719 = NOVALUE;
    DeRef(_30626);
    _30626 = NOVALUE;
    return;
    ;
}


void _38set_error_info(int _ref_61534)
{
    int _fr_61535 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61535);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61535 = (int)*(((s1_ptr)_2)->base + _ref_61534);
    Ref(_fr_61535);

    /** 	ThisLine        = fr[FR_THISLINE]*/
    DeRef(_44ThisLine_48142);
    _2 = (int)SEQ_PTR(_fr_61535);
    _44ThisLine_48142 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_44ThisLine_48142);

    /** 	bp              = fr[FR_BP]*/
    _2 = (int)SEQ_PTR(_fr_61535);
    _44bp_48146 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_44bp_48146)){
        _44bp_48146 = (long)DBL_PTR(_44bp_48146)->dbl;
    }

    /** 	line_number     = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61535);
    _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_15969)){
        _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
    }

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61535);
    _35current_file_no_15968 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_15968)){
        _35current_file_no_15968 = (long)DBL_PTR(_35current_file_no_15968)->dbl;
    }

    /** end procedure*/
    DeRefDS(_fr_61535);
    return;
    ;
}


void _38patch_forward_variable(int _tok_61548, int _ref_61549)
{
    int _fr_61550 = NOVALUE;
    int _sym_61553 = NOVALUE;
    int _pc_61605 = NOVALUE;
    int _vx_61609 = NOVALUE;
    int _d_61626 = NOVALUE;
    int _param_61636 = NOVALUE;
    int _old_61639 = NOVALUE;
    int _new_61644 = NOVALUE;
    int _30789 = NOVALUE;
    int _30788 = NOVALUE;
    int _30787 = NOVALUE;
    int _30785 = NOVALUE;
    int _30782 = NOVALUE;
    int _30780 = NOVALUE;
    int _30779 = NOVALUE;
    int _30778 = NOVALUE;
    int _30777 = NOVALUE;
    int _30775 = NOVALUE;
    int _30774 = NOVALUE;
    int _30773 = NOVALUE;
    int _30772 = NOVALUE;
    int _30771 = NOVALUE;
    int _30769 = NOVALUE;
    int _30767 = NOVALUE;
    int _30764 = NOVALUE;
    int _30763 = NOVALUE;
    int _30762 = NOVALUE;
    int _30760 = NOVALUE;
    int _30759 = NOVALUE;
    int _30758 = NOVALUE;
    int _30757 = NOVALUE;
    int _30755 = NOVALUE;
    int _30753 = NOVALUE;
    int _30752 = NOVALUE;
    int _30751 = NOVALUE;
    int _30750 = NOVALUE;
    int _30749 = NOVALUE;
    int _30748 = NOVALUE;
    int _30747 = NOVALUE;
    int _30746 = NOVALUE;
    int _30745 = NOVALUE;
    int _30744 = NOVALUE;
    int _30743 = NOVALUE;
    int _30742 = NOVALUE;
    int _30741 = NOVALUE;
    int _30740 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61550);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61550 = (int)*(((s1_ptr)_2)->base + _ref_61549);
    Ref(_fr_61550);

    /** 	symtab_index sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61548);
    _sym_61553 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61553)){
        _sym_61553 = (long)DBL_PTR(_sym_61553)->dbl;
    }

    /** 	if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30740 = (int)*(((s1_ptr)_2)->base + _sym_61553);
    _2 = (int)SEQ_PTR(_30740);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _30741 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _30741 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _30740 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61550);
    _30742 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_30741) && IS_ATOM_INT(_30742)) {
        _30743 = (_30741 == _30742);
    }
    else {
        _30743 = binary_op(EQUALS, _30741, _30742);
    }
    _30741 = NOVALUE;
    _30742 = NOVALUE;
    if (IS_ATOM_INT(_30743)) {
        if (_30743 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_30743)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (int)SEQ_PTR(_fr_61550);
    _30745 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30745)) {
        _30746 = (_30745 == _35TopLevelSub_15975);
    }
    else {
        _30746 = binary_op(EQUALS, _30745, _35TopLevelSub_15975);
    }
    _30745 = NOVALUE;
    if (_30746 == 0) {
        DeRef(_30746);
        _30746 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_30746) && DBL_PTR(_30746)->dbl == 0.0){
            DeRef(_30746);
            _30746 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_30746);
        _30746 = NOVALUE;
    }
    DeRef(_30746);
    _30746 = NOVALUE;

    /** 		return*/
    DeRef(_tok_61548);
    DeRef(_fr_61550);
    DeRef(_30743);
    _30743 = NOVALUE;
    return;
L1: 

    /** 	if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_fr_61550);
    _30747 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30747)) {
        _30748 = (_30747 == 18);
    }
    else {
        _30748 = binary_op(EQUALS, _30747, 18);
    }
    _30747 = NOVALUE;
    if (IS_ATOM_INT(_30748)) {
        if (_30748 == 0) {
            goto L2; // [81] 120
        }
    }
    else {
        if (DBL_PTR(_30748)->dbl == 0.0) {
            goto L2; // [81] 120
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30750 = (int)*(((s1_ptr)_2)->base + _sym_61553);
    _2 = (int)SEQ_PTR(_30750);
    _30751 = (int)*(((s1_ptr)_2)->base + 3);
    _30750 = NOVALUE;
    if (IS_ATOM_INT(_30751)) {
        _30752 = (_30751 == 2);
    }
    else {
        _30752 = binary_op(EQUALS, _30751, 2);
    }
    _30751 = NOVALUE;
    if (_30752 == 0) {
        DeRef(_30752);
        _30752 = NOVALUE;
        goto L2; // [104] 120
    }
    else {
        if (!IS_ATOM_INT(_30752) && DBL_PTR(_30752)->dbl == 0.0){
            DeRef(_30752);
            _30752 = NOVALUE;
            goto L2; // [104] 120
        }
        DeRef(_30752);
        _30752 = NOVALUE;
    }
    DeRef(_30752);
    _30752 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61549);

    /** 		CompileErr( 110 )*/
    RefDS(_21815);
    _44CompileErr(110, _21815, 0);
L2: 

    /** 	if fr[FR_OP] = ASSIGN then*/
    _2 = (int)SEQ_PTR(_fr_61550);
    _30753 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30753, 18)){
        _30753 = NOVALUE;
        goto L3; // [128] 168
    }
    _30753 = NOVALUE;

    /** 		SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_61553 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30757 = (int)*(((s1_ptr)_2)->base + _sym_61553);
    _2 = (int)SEQ_PTR(_30757);
    _30758 = (int)*(((s1_ptr)_2)->base + 5);
    _30757 = NOVALUE;
    if (IS_ATOM_INT(_30758)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_30758;
             _30759 = MAKE_UINT(tu);
        }
    }
    else {
        _30759 = binary_op(OR_BITS, 2, _30758);
    }
    _30758 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _30759;
    if( _1 != _30759 ){
        DeRef(_1);
    }
    _30759 = NOVALUE;
    _30755 = NOVALUE;
    goto L4; // [165] 202
L3: 

    /** 		SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_61553 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30762 = (int)*(((s1_ptr)_2)->base + _sym_61553);
    _2 = (int)SEQ_PTR(_30762);
    _30763 = (int)*(((s1_ptr)_2)->base + 5);
    _30762 = NOVALUE;
    if (IS_ATOM_INT(_30763)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_30763;
             _30764 = MAKE_UINT(tu);
        }
    }
    else {
        _30764 = binary_op(OR_BITS, 1, _30763);
    }
    _30763 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _30764;
    if( _1 != _30764 ){
        DeRef(_1);
    }
    _30764 = NOVALUE;
    _30760 = NOVALUE;
L4: 

    /** 	set_code( ref )*/
    _38set_code(_ref_61549);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61550);
    _pc_61605 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61605))
    _pc_61605 = (long)DBL_PTR(_pc_61605)->dbl;

    /** 	if pc < 1 then*/
    if (_pc_61605 >= 1)
    goto L5; // [215] 225

    /** 		pc = 1*/
    _pc_61605 = 1;
L5: 

    /** 	integer vx = find( -ref, Code, pc )*/
    if ((unsigned long)_ref_61549 == 0xC0000000)
    _30767 = (int)NewDouble((double)-0xC0000000);
    else
    _30767 = - _ref_61549;
    _vx_61609 = find_from(_30767, _35Code_16056, _pc_61605);
    DeRef(_30767);
    _30767 = NOVALUE;

    /** 	if vx then*/
    if (_vx_61609 == 0)
    {
        goto L6; // [239] 281
    }
    else{
    }

    /** 		while vx do*/
L7: 
    if (_vx_61609 == 0)
    {
        goto L8; // [247] 275
    }
    else{
    }

    /** 			Code[vx] = sym*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _vx_61609);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_61553;
    DeRef(_1);

    /** 			vx = find( -ref, Code, vx )*/
    if ((unsigned long)_ref_61549 == 0xC0000000)
    _30769 = (int)NewDouble((double)-0xC0000000);
    else
    _30769 = - _ref_61549;
    _vx_61609 = find_from(_30769, _35Code_16056, _vx_61609);
    DeRef(_30769);
    _30769 = NOVALUE;

    /** 		end while*/
    goto L7; // [272] 247
L8: 

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61549);
L6: 

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61550);
    _30771 = (int)*(((s1_ptr)_2)->base + 12);
    _30772 = IS_SEQUENCE(_30771);
    _30771 = NOVALUE;
    if (_30772 == 0)
    {
        _30772 = NOVALUE;
        goto L9; // [290] 422
    }
    else{
        _30772 = NOVALUE;
    }

    /** 		for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (int)SEQ_PTR(_fr_61550);
    _30773 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30773)){
            _30774 = SEQ_PTR(_30773)->length;
    }
    else {
        _30774 = 1;
    }
    _30773 = NOVALUE;
    {
        int _i_61623;
        _i_61623 = 1;
LA: 
        if (_i_61623 > _30774){
            goto LB; // [302] 416
        }

        /** 			object d = fr[FR_DATA][i]*/
        _2 = (int)SEQ_PTR(_fr_61550);
        _30775 = (int)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_61626);
        _2 = (int)SEQ_PTR(_30775);
        _d_61626 = (int)*(((s1_ptr)_2)->base + _i_61623);
        Ref(_d_61626);
        _30775 = NOVALUE;

        /** 			if sequence( d ) and d[1] = PAM_RECORD then*/
        _30777 = IS_SEQUENCE(_d_61626);
        if (_30777 == 0) {
            goto LC; // [324] 405
        }
        _2 = (int)SEQ_PTR(_d_61626);
        _30779 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30779)) {
            _30780 = (_30779 == 1);
        }
        else {
            _30780 = binary_op(EQUALS, _30779, 1);
        }
        _30779 = NOVALUE;
        if (_30780 == 0) {
            DeRef(_30780);
            _30780 = NOVALUE;
            goto LC; // [339] 405
        }
        else {
            if (!IS_ATOM_INT(_30780) && DBL_PTR(_30780)->dbl == 0.0){
                DeRef(_30780);
                _30780 = NOVALUE;
                goto LC; // [339] 405
            }
            DeRef(_30780);
            _30780 = NOVALUE;
        }
        DeRef(_30780);
        _30780 = NOVALUE;

        /** 				symtab_index param = d[2]*/
        _2 = (int)SEQ_PTR(_d_61626);
        _param_61636 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_61636)){
            _param_61636 = (long)DBL_PTR(_param_61636)->dbl;
        }

        /** 				token old = {RECORDED, d[3]}*/
        _2 = (int)SEQ_PTR(_d_61626);
        _30782 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_30782);
        DeRef(_old_61639);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 508;
        ((int *)_2)[2] = _30782;
        _old_61639 = MAKE_SEQ(_1);
        _30782 = NOVALUE;

        /** 				token new = {VARIABLE, sym}*/
        DeRefi(_new_61644);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _sym_61553;
        _new_61644 = MAKE_SEQ(_1);

        /** 				SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_param_61636 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30787 = (int)*(((s1_ptr)_2)->base + _param_61636);
        _2 = (int)SEQ_PTR(_30787);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _30788 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _30788 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        _30787 = NOVALUE;
        RefDS(_old_61639);
        Ref(_30788);
        RefDS(_new_61644);
        _30789 = _16find_replace(_old_61639, _30788, _new_61644, 0);
        _30788 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_35S_CODE_15653))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
        _1 = *(int *)_2;
        *(int *)_2 = _30789;
        if( _1 != _30789 ){
            DeRef(_1);
        }
        _30789 = NOVALUE;
        _30785 = NOVALUE;
LC: 
        DeRef(_old_61639);
        _old_61639 = NOVALUE;
        DeRefi(_new_61644);
        _new_61644 = NOVALUE;
        DeRef(_d_61626);
        _d_61626 = NOVALUE;

        /** 		end for*/
        _i_61623 = _i_61623 + 1;
        goto LA; // [411] 309
LB: 
        ;
    }

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61549);
L9: 

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_61548);
    DeRef(_fr_61550);
    _30773 = NOVALUE;
    DeRef(_30748);
    _30748 = NOVALUE;
    DeRef(_30743);
    _30743 = NOVALUE;
    return;
    ;
}


void _38patch_forward_init_check(int _tok_61660, int _ref_61661)
{
    int _fr_61662 = NOVALUE;
    int _30797 = NOVALUE;
    int _30796 = NOVALUE;
    int _30795 = NOVALUE;
    int _30793 = NOVALUE;
    int _30792 = NOVALUE;
    int _30791 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61662);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61662 = (int)*(((s1_ptr)_2)->base + _ref_61661);
    Ref(_fr_61662);

    /** 	set_code( ref )*/
    _38set_code(_ref_61661);

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61662);
    _30791 = (int)*(((s1_ptr)_2)->base + 12);
    _30792 = IS_SEQUENCE(_30791);
    _30791 = NOVALUE;
    if (_30792 == 0)
    {
        _30792 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _30792 = NOVALUE;
    }

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61661);
    goto L2; // [35] 85
L1: 

    /** 	elsif fr[FR_PC] > 0 then*/
    _2 = (int)SEQ_PTR(_fr_61662);
    _30793 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _30793, 0)){
        _30793 = NOVALUE;
        goto L3; // [44] 78
    }
    _30793 = NOVALUE;

    /** 		Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_fr_61662);
    _30795 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_30795)) {
        _30796 = _30795 + 1;
        if (_30796 > MAXINT){
            _30796 = NewDouble((double)_30796);
        }
    }
    else
    _30796 = binary_op(PLUS, 1, _30795);
    _30795 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_61660);
    _30797 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30797);
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30796))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30796)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _30796);
    _1 = *(int *)_2;
    *(int *)_2 = _30797;
    if( _1 != _30797 ){
        DeRef(_1);
    }
    _30797 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _38resolved_reference(_ref_61661);
    goto L2; // [75] 85
L3: 

    /** 		forward_error( tok, ref )*/
    Ref(_tok_61660);
    _38forward_error(_tok_61660, _ref_61661);
L2: 

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_61660);
    DeRef(_fr_61662);
    DeRef(_30796);
    _30796 = NOVALUE;
    return;
    ;
}


int _38expected_name(int _id_61679)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_61679)) {
        _1 = (long)(DBL_PTR(_id_61679)->dbl);
        DeRefDS(_id_61679);
        _id_61679 = _1;
    }

    /** 	switch id with fallthru do*/
    _0 = _id_61679;
    switch ( _0 ){ 

        /** 		case PROC then*/
        case 27:
        case 195:

        /** 			return "a procedure"*/
        RefDS(_26098);
        return _26098;

        /** 		case FUNC then*/
        case 501:
        case 196:

        /** 			return "a function"*/
        RefDS(_26044);
        return _26044;

        /** 		case VARIABLE then*/
        case -100:

        /** 			return "a variable, constant or enum"*/
        RefDS(_30800);
        return _30800;

        /** 		case else*/
        default:

        /** 			return "something"*/
        RefDS(_30801);
        return _30801;
    ;}    ;
}


void _38patch_forward_type(int _tok_61696, int _ref_61697)
{
    int _fr_61698 = NOVALUE;
    int _syms_61700 = NOVALUE;
    int _30813 = NOVALUE;
    int _30812 = NOVALUE;
    int _30810 = NOVALUE;
    int _30809 = NOVALUE;
    int _30808 = NOVALUE;
    int _30806 = NOVALUE;
    int _30805 = NOVALUE;
    int _30804 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61698);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61698 = (int)*(((s1_ptr)_2)->base + _ref_61697);
    Ref(_fr_61698);

    /** 	sequence syms = fr[FR_DATA]*/
    DeRef(_syms_61700);
    _2 = (int)SEQ_PTR(_fr_61698);
    _syms_61700 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_61700);

    /** 	for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_61700)){
            _30804 = SEQ_PTR(_syms_61700)->length;
    }
    else {
        _30804 = 1;
    }
    {
        int _i_61703;
        _i_61703 = 2;
L1: 
        if (_i_61703 > _30804){
            goto L2; // [26] 102
        }

        /** 		SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_syms_61700);
        _30805 = (int)*(((s1_ptr)_2)->base + _i_61703);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30805))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30805)->dbl));
        else
        _3 = (int)(_30805 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_61696);
        _30808 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30808);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _30808;
        if( _1 != _30808 ){
            DeRef(_1);
        }
        _30808 = NOVALUE;
        _30806 = NOVALUE;

        /** 		if TRANSLATE then*/
        if (_35TRANSLATE_15611 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** 			SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_syms_61700);
        _30809 = (int)*(((s1_ptr)_2)->base + _i_61703);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30809))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30809)->dbl));
        else
        _3 = (int)(_30809 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_61696);
        _30812 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30812);
        _30813 = _39CompileType(_30812);
        _30812 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 36);
        _1 = *(int *)_2;
        *(int *)_2 = _30813;
        if( _1 != _30813 ){
            DeRef(_1);
        }
        _30813 = NOVALUE;
        _30810 = NOVALUE;
L3: 

        /** 	end for*/
        _i_61703 = _i_61703 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61697);

    /** end procedure*/
    DeRef(_tok_61696);
    DeRef(_fr_61698);
    DeRef(_syms_61700);
    _30805 = NOVALUE;
    _30809 = NOVALUE;
    return;
    ;
}


void _38patch_forward_case(int _tok_61726, int _ref_61727)
{
    int _fr_61728 = NOVALUE;
    int _switch_pc_61730 = NOVALUE;
    int _case_sym_61733 = NOVALUE;
    int _case_values_61762 = NOVALUE;
    int _cx_61767 = NOVALUE;
    int _negative_61775 = NOVALUE;
    int _30851 = NOVALUE;
    int _30850 = NOVALUE;
    int _30849 = NOVALUE;
    int _30848 = NOVALUE;
    int _30847 = NOVALUE;
    int _30846 = NOVALUE;
    int _30844 = NOVALUE;
    int _30842 = NOVALUE;
    int _30841 = NOVALUE;
    int _30839 = NOVALUE;
    int _30838 = NOVALUE;
    int _30835 = NOVALUE;
    int _30833 = NOVALUE;
    int _30832 = NOVALUE;
    int _30831 = NOVALUE;
    int _30830 = NOVALUE;
    int _30829 = NOVALUE;
    int _30828 = NOVALUE;
    int _30827 = NOVALUE;
    int _30826 = NOVALUE;
    int _30825 = NOVALUE;
    int _30823 = NOVALUE;
    int _30822 = NOVALUE;
    int _30821 = NOVALUE;
    int _30820 = NOVALUE;
    int _30818 = NOVALUE;
    int _30816 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61728);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61728 = (int)*(((s1_ptr)_2)->base + _ref_61727);
    Ref(_fr_61728);

    /** 	integer switch_pc = fr[FR_DATA]*/
    _2 = (int)SEQ_PTR(_fr_61728);
    _switch_pc_61730 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_61730))
    _switch_pc_61730 = (long)DBL_PTR(_switch_pc_61730)->dbl;

    /** 	if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_fr_61728);
    _30816 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _30816, _35TopLevelSub_15975)){
        _30816 = NOVALUE;
        goto L1; // [27] 48
    }
    _30816 = NOVALUE;

    /** 		case_sym = Code[switch_pc + 2]*/
    _30818 = _switch_pc_61730 + 2;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _case_sym_61733 = (int)*(((s1_ptr)_2)->base + _30818);
    if (!IS_ATOM_INT(_case_sym_61733)){
        _case_sym_61733 = (long)DBL_PTR(_case_sym_61733)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** 		case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (int)SEQ_PTR(_fr_61728);
    _30820 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30820)){
        _30821 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30820)->dbl));
    }
    else{
        _30821 = (int)*(((s1_ptr)_2)->base + _30820);
    }
    _2 = (int)SEQ_PTR(_30821);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _30822 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _30822 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _30821 = NOVALUE;
    _30823 = _switch_pc_61730 + 2;
    _2 = (int)SEQ_PTR(_30822);
    _case_sym_61733 = (int)*(((s1_ptr)_2)->base + _30823);
    if (!IS_ATOM_INT(_case_sym_61733)){
        _case_sym_61733 = (long)DBL_PTR(_case_sym_61733)->dbl;
    }
    _30822 = NOVALUE;
L2: 

    /** 	if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_tok_61726);
    _30825 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30825)){
        _30826 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30825)->dbl));
    }
    else{
        _30826 = (int)*(((s1_ptr)_2)->base + _30825);
    }
    _2 = (int)SEQ_PTR(_30826);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _30827 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _30827 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _30826 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61728);
    _30828 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_30827) && IS_ATOM_INT(_30828)) {
        _30829 = (_30827 == _30828);
    }
    else {
        _30829 = binary_op(EQUALS, _30827, _30828);
    }
    _30827 = NOVALUE;
    _30828 = NOVALUE;
    if (IS_ATOM_INT(_30829)) {
        if (_30829 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_30829)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (int)SEQ_PTR(_fr_61728);
    _30831 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30831)) {
        _30832 = (_30831 == _35TopLevelSub_15975);
    }
    else {
        _30832 = binary_op(EQUALS, _30831, _35TopLevelSub_15975);
    }
    _30831 = NOVALUE;
    if (_30832 == 0) {
        DeRef(_30832);
        _30832 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_30832) && DBL_PTR(_30832)->dbl == 0.0){
            DeRef(_30832);
            _30832 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_30832);
        _30832 = NOVALUE;
    }
    DeRef(_30832);
    _30832 = NOVALUE;

    /** 		return*/
    DeRef(_tok_61726);
    DeRef(_fr_61728);
    DeRef(_case_values_61762);
    DeRef(_30818);
    _30818 = NOVALUE;
    _30820 = NOVALUE;
    _30825 = NOVALUE;
    DeRef(_30823);
    _30823 = NOVALUE;
    DeRef(_30829);
    _30829 = NOVALUE;
    return;
L3: 

    /** 	sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30833 = (int)*(((s1_ptr)_2)->base + _case_sym_61733);
    DeRef(_case_values_61762);
    _2 = (int)SEQ_PTR(_30833);
    _case_values_61762 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_61762);
    _30833 = NOVALUE;

    /** 	integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ref_61727;
    _30835 = MAKE_SEQ(_1);
    _cx_61767 = find_from(_30835, _case_values_61762, 1);
    DeRefDS(_30835);
    _30835 = NOVALUE;

    /** 	if not cx then*/
    if (_cx_61767 != 0)
    goto L4; // [160] 178

    /** 		cx = find( { -ref }, case_values )*/
    if ((unsigned long)_ref_61727 == 0xC0000000)
    _30838 = (int)NewDouble((double)-0xC0000000);
    else
    _30838 = - _ref_61727;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30838;
    _30839 = MAKE_SEQ(_1);
    _30838 = NOVALUE;
    _cx_61767 = find_from(_30839, _case_values_61762, 1);
    DeRefDS(_30839);
    _30839 = NOVALUE;
L4: 

    /**  	ifdef DEBUG then	*/

    /** 	integer negative = 0*/
    _negative_61775 = 0;

    /** 	if case_values[cx][1] < 0 then*/
    _2 = (int)SEQ_PTR(_case_values_61762);
    _30841 = (int)*(((s1_ptr)_2)->base + _cx_61767);
    _2 = (int)SEQ_PTR(_30841);
    _30842 = (int)*(((s1_ptr)_2)->base + 1);
    _30841 = NOVALUE;
    if (binary_op_a(GREATEREQ, _30842, 0)){
        _30842 = NOVALUE;
        goto L5; // [195] 224
    }
    _30842 = NOVALUE;

    /** 		negative = 1*/
    _negative_61775 = 1;

    /** 		case_values[cx][1] *= -1*/
    _2 = (int)SEQ_PTR(_case_values_61762);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61762 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cx_61767 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30846 = (int)*(((s1_ptr)_2)->base + 1);
    _30844 = NOVALUE;
    if (IS_ATOM_INT(_30846)) {
        if (_30846 == (short)_30846)
        _30847 = _30846 * -1;
        else
        _30847 = NewDouble(_30846 * (double)-1);
    }
    else {
        _30847 = binary_op(MULTIPLY, _30846, -1);
    }
    _30846 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _30847;
    if( _1 != _30847 ){
        DeRef(_1);
    }
    _30847 = NOVALUE;
    _30844 = NOVALUE;
L5: 

    /** 	if negative then*/
    if (_negative_61775 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** 		case_values[cx] = - tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61726);
    _30848 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30848)) {
        if ((unsigned long)_30848 == 0xC0000000)
        _30849 = (int)NewDouble((double)-0xC0000000);
        else
        _30849 = - _30848;
    }
    else {
        _30849 = unary_op(UMINUS, _30848);
    }
    _30848 = NOVALUE;
    _2 = (int)SEQ_PTR(_case_values_61762);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61762 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_61767);
    _1 = *(int *)_2;
    *(int *)_2 = _30849;
    if( _1 != _30849 ){
        DeRef(_1);
    }
    _30849 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** 		case_values[cx] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61726);
    _30850 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30850);
    _2 = (int)SEQ_PTR(_case_values_61762);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61762 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_61767);
    _1 = *(int *)_2;
    *(int *)_2 = _30850;
    if( _1 != _30850 ){
        DeRef(_1);
    }
    _30850 = NOVALUE;
L7: 

    /** 	SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_case_sym_61733 + ((s1_ptr)_2)->base);
    RefDS(_case_values_61762);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _case_values_61762;
    DeRef(_1);
    _30851 = NOVALUE;

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61727);

    /** end procedure*/
    DeRef(_tok_61726);
    DeRef(_fr_61728);
    DeRefDS(_case_values_61762);
    DeRef(_30818);
    _30818 = NOVALUE;
    _30820 = NOVALUE;
    _30825 = NOVALUE;
    DeRef(_30823);
    _30823 = NOVALUE;
    DeRef(_30829);
    _30829 = NOVALUE;
    return;
    ;
}


void _38patch_forward_type_check(int _tok_61798, int _ref_61799)
{
    int _fr_61800 = NOVALUE;
    int _which_type_61803 = NOVALUE;
    int _var_61805 = NOVALUE;
    int _pc_61838 = NOVALUE;
    int _with_type_check_61840 = NOVALUE;
    int _c_61870 = NOVALUE;
    int _subprog_inlined_insert_code_at_332_61879 = NOVALUE;
    int _code_inlined_insert_code_at_329_61878 = NOVALUE;
    int _subprog_inlined_insert_code_at_415_61895 = NOVALUE;
    int _code_inlined_insert_code_at_412_61894 = NOVALUE;
    int _subprog_inlined_insert_code_at_477_61905 = NOVALUE;
    int _code_inlined_insert_code_at_474_61904 = NOVALUE;
    int _subprog_inlined_insert_code_at_539_61915 = NOVALUE;
    int _code_inlined_insert_code_at_536_61914 = NOVALUE;
    int _start_pc_61922 = NOVALUE;
    int _subprog_inlined_insert_code_at_647_61939 = NOVALUE;
    int _code_inlined_insert_code_at_644_61938 = NOVALUE;
    int _c_61942 = NOVALUE;
    int _subprog_inlined_insert_code_at_741_61958 = NOVALUE;
    int _code_inlined_insert_code_at_738_61957 = NOVALUE;
    int _start_pc_61969 = NOVALUE;
    int _subprog_inlined_insert_code_at_886_61989 = NOVALUE;
    int _code_inlined_insert_code_at_883_61988 = NOVALUE;
    int _subprog_inlined_insert_code_at_987_62010 = NOVALUE;
    int _code_inlined_insert_code_at_984_62009 = NOVALUE;
    int _30941 = NOVALUE;
    int _30940 = NOVALUE;
    int _30939 = NOVALUE;
    int _30938 = NOVALUE;
    int _30937 = NOVALUE;
    int _30936 = NOVALUE;
    int _30935 = NOVALUE;
    int _30933 = NOVALUE;
    int _30931 = NOVALUE;
    int _30930 = NOVALUE;
    int _30929 = NOVALUE;
    int _30928 = NOVALUE;
    int _30927 = NOVALUE;
    int _30926 = NOVALUE;
    int _30925 = NOVALUE;
    int _30923 = NOVALUE;
    int _30922 = NOVALUE;
    int _30921 = NOVALUE;
    int _30920 = NOVALUE;
    int _30919 = NOVALUE;
    int _30918 = NOVALUE;
    int _30916 = NOVALUE;
    int _30915 = NOVALUE;
    int _30914 = NOVALUE;
    int _30913 = NOVALUE;
    int _30911 = NOVALUE;
    int _30910 = NOVALUE;
    int _30907 = NOVALUE;
    int _30906 = NOVALUE;
    int _30904 = NOVALUE;
    int _30903 = NOVALUE;
    int _30902 = NOVALUE;
    int _30901 = NOVALUE;
    int _30900 = NOVALUE;
    int _30899 = NOVALUE;
    int _30897 = NOVALUE;
    int _30896 = NOVALUE;
    int _30893 = NOVALUE;
    int _30892 = NOVALUE;
    int _30889 = NOVALUE;
    int _30888 = NOVALUE;
    int _30884 = NOVALUE;
    int _30883 = NOVALUE;
    int _30881 = NOVALUE;
    int _30880 = NOVALUE;
    int _30878 = NOVALUE;
    int _30877 = NOVALUE;
    int _30874 = NOVALUE;
    int _30871 = NOVALUE;
    int _30869 = NOVALUE;
    int _30866 = NOVALUE;
    int _30865 = NOVALUE;
    int _30862 = NOVALUE;
    int _30857 = NOVALUE;
    int _30856 = NOVALUE;
    int _30854 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61800);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _fr_61800 = (int)*(((s1_ptr)_2)->base + _ref_61799);
    Ref(_fr_61800);

    /** 	if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_fr_61800);
    _30854 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30854, 197)){
        _30854 = NOVALUE;
        goto L1; // [21] 86
    }
    _30854 = NOVALUE;

    /** 		which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_tok_61798);
    _30856 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30856)){
        _30857 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30856)->dbl));
    }
    else{
        _30857 = (int)*(((s1_ptr)_2)->base + _30856);
    }
    _2 = (int)SEQ_PTR(_30857);
    _which_type_61803 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_61803)){
        _which_type_61803 = (long)DBL_PTR(_which_type_61803)->dbl;
    }
    _30857 = NOVALUE;

    /** 		if not which_type then*/
    if (_which_type_61803 != 0)
    goto L2; // [49] 72

    /** 			which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61798);
    _which_type_61803 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_61803)){
        _which_type_61803 = (long)DBL_PTR(_which_type_61803)->dbl;
    }

    /** 			var = 0*/
    _var_61805 = 0;
    goto L3; // [69] 144
L2: 

    /** 			var = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61798);
    _var_61805 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_61805)){
        _var_61805 = (long)DBL_PTR(_var_61805)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** 	elsif fr[FR_OP] = TYPE then*/
    _2 = (int)SEQ_PTR(_fr_61800);
    _30862 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30862, 504)){
        _30862 = NOVALUE;
        goto L4; // [94] 118
    }
    _30862 = NOVALUE;

    /** 		which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61798);
    _which_type_61803 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_61803)){
        _which_type_61803 = (long)DBL_PTR(_which_type_61803)->dbl;
    }

    /** 		var = 0*/
    _var_61805 = 0;
    goto L3; // [115] 144
L4: 

    /** 		prep_forward_error( ref )*/
    _38prep_forward_error(_ref_61799);

    /** 		InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (int)SEQ_PTR(_fr_61800);
    _30865 = (int)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 65;
    *((int *)(_2+8)) = 197;
    Ref(_30865);
    *((int *)(_2+12)) = _30865;
    _30866 = MAKE_SEQ(_1);
    _30865 = NOVALUE;
    _44InternalErr(262, _30866);
    _30866 = NOVALUE;
L3: 

    /** 	if which_type < 0 then*/
    if (_which_type_61803 >= 0)
    goto L5; // [148] 158

    /** 		return*/
    DeRef(_tok_61798);
    DeRef(_fr_61800);
    _30856 = NOVALUE;
    return;
L5: 

    /** 	set_code( ref )*/
    _38set_code(_ref_61799);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61800);
    _pc_61838 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61838))
    _pc_61838 = (long)DBL_PTR(_pc_61838)->dbl;

    /** 	integer with_type_check = Code[pc + 2]*/
    _30869 = _pc_61838 + 2;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _with_type_check_61840 = (int)*(((s1_ptr)_2)->base + _30869);
    if (!IS_ATOM_INT(_with_type_check_61840)){
        _with_type_check_61840 = (long)DBL_PTR(_with_type_check_61840)->dbl;
    }

    /** 	if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _30871 = (int)*(((s1_ptr)_2)->base + _pc_61838);
    if (binary_op_a(EQUALS, _30871, 197)){
        _30871 = NOVALUE;
        goto L6; // [193] 204
    }
    _30871 = NOVALUE;

    /** 		forward_error( tok, ref )*/
    Ref(_tok_61798);
    _38forward_error(_tok_61798, _ref_61799);
L6: 

    /** 	if not var then*/
    if (_var_61805 != 0)
    goto L7; // [208] 226

    /** 		var = Code[pc+1]*/
    _30874 = _pc_61838 + 1;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _var_61805 = (int)*(((s1_ptr)_2)->base + _30874);
    if (!IS_ATOM_INT(_var_61805)){
        _var_61805 = (long)DBL_PTR(_var_61805)->dbl;
    }
L7: 

    /** 	if var < 0 then*/
    if (_var_61805 >= 0)
    goto L8; // [228] 238

    /** 		return*/
    DeRef(_tok_61798);
    DeRef(_fr_61800);
    _30856 = NOVALUE;
    DeRef(_30869);
    _30869 = NOVALUE;
    DeRef(_30874);
    _30874 = NOVALUE;
    return;
L8: 

    /** 	replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _30877 = _pc_61838 + 2;
    if ((long)((unsigned long)_30877 + (unsigned long)HIGH_BITS) >= 0) 
    _30877 = NewDouble((double)_30877);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30878 = (int)*(((s1_ptr)_2)->base + 4);
    RefDS(_21815);
    Ref(_30878);
    _38replace_code(_21815, _pc_61838, _30877, _30878);
    _30877 = NOVALUE;
    _30878 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** 		if with_type_check then*/
    if (_with_type_check_61840 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_61803 == _53object_type_45715)
    goto LA; // [270] 771

    /** 				if SymTab[which_type][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30880 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30880);
    _30881 = (int)*(((s1_ptr)_2)->base + 23);
    _30880 = NOVALUE;
    if (_30881 == 0) {
        _30881 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_30881) && DBL_PTR(_30881)->dbl == 0.0){
            _30881 = NOVALUE;
            goto LB; // [288] 357
        }
        _30881 = NOVALUE;
    }
    _30881 = NOVALUE;

    /** 					integer c = NewTempSym()*/
    _c_61870 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_61870)) {
        _1 = (long)(DBL_PTR(_c_61870)->dbl);
        DeRefDS(_c_61870);
        _c_61870 = _1;
    }

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_61803;
    *((int *)(_2+12)) = _var_61805;
    *((int *)(_2+16)) = _c_61870;
    *((int *)(_2+20)) = 65;
    _30883 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30884 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_61878);
    _code_inlined_insert_code_at_329_61878 = _30883;
    _30883 = NOVALUE;
    Ref(_30884);
    DeRef(_subprog_inlined_insert_code_at_332_61879);
    _subprog_inlined_insert_code_at_332_61879 = _30884;
    _30884 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_61879)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_332_61879)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_61879);
        _subprog_inlined_insert_code_at_332_61879 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_332_61879;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_61878);
    _65insert_code(_code_inlined_insert_code_at_329_61878, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_61878);
    _code_inlined_insert_code_at_329_61878 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_61879);
    _subprog_inlined_insert_code_at_332_61879 = NOVALUE;

    /** 					pc += 5*/
    _pc_61838 = _pc_61838 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** 		if with_type_check then*/
    if (_with_type_check_61840 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** 			if which_type = object_type then*/
    if (_which_type_61803 != _53object_type_45715)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** 				if which_type = integer_type then*/
    if (_which_type_61803 != _53integer_type_45721)
    goto L10; // [384] 442

    /** 					insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61805;
    _30888 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30889 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_61894);
    _code_inlined_insert_code_at_412_61894 = _30888;
    _30888 = NOVALUE;
    Ref(_30889);
    DeRef(_subprog_inlined_insert_code_at_415_61895);
    _subprog_inlined_insert_code_at_415_61895 = _30889;
    _30889 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_61895)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_415_61895)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_61895);
        _subprog_inlined_insert_code_at_415_61895 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_415_61895;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_61894);
    _65insert_code(_code_inlined_insert_code_at_412_61894, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_61894);
    _code_inlined_insert_code_at_412_61894 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_61895);
    _subprog_inlined_insert_code_at_415_61895 = NOVALUE;

    /** 					pc += 2*/
    _pc_61838 = _pc_61838 + 2;
    goto L12; // [439] 768
L10: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_61803 != _53sequence_type_45719)
    goto L13; // [446] 504

    /** 					insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_61805;
    _30892 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30893 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_61904);
    _code_inlined_insert_code_at_474_61904 = _30892;
    _30892 = NOVALUE;
    Ref(_30893);
    DeRef(_subprog_inlined_insert_code_at_477_61905);
    _subprog_inlined_insert_code_at_477_61905 = _30893;
    _30893 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_61905)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_477_61905)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_61905);
        _subprog_inlined_insert_code_at_477_61905 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_477_61905;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_61904);
    _65insert_code(_code_inlined_insert_code_at_474_61904, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_61904);
    _code_inlined_insert_code_at_474_61904 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_61905);
    _subprog_inlined_insert_code_at_477_61905 = NOVALUE;

    /** 					pc += 2*/
    _pc_61838 = _pc_61838 + 2;
    goto L12; // [501] 768
L13: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_61803 != _53atom_type_45717)
    goto L15; // [508] 566

    /** 					insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 101;
    ((int *)_2)[2] = _var_61805;
    _30896 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30897 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_61914);
    _code_inlined_insert_code_at_536_61914 = _30896;
    _30896 = NOVALUE;
    Ref(_30897);
    DeRef(_subprog_inlined_insert_code_at_539_61915);
    _subprog_inlined_insert_code_at_539_61915 = _30897;
    _30897 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_61915)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_539_61915)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_61915);
        _subprog_inlined_insert_code_at_539_61915 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_539_61915;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_61914);
    _65insert_code(_code_inlined_insert_code_at_536_61914, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_61914);
    _code_inlined_insert_code_at_536_61914 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_61915);
    _subprog_inlined_insert_code_at_539_61915 = NOVALUE;

    /** 					pc += 2*/
    _pc_61838 = _pc_61838 + 2;
    goto L12; // [563] 768
L15: 

    /** 				elsif SymTab[which_type][S_NEXT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30899 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30899);
    _30900 = (int)*(((s1_ptr)_2)->base + 2);
    _30899 = NOVALUE;
    if (_30900 == 0) {
        _30900 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_30900) && DBL_PTR(_30900)->dbl == 0.0){
            _30900 = NOVALUE;
            goto L17; // [580] 765
        }
        _30900 = NOVALUE;
    }
    _30900 = NOVALUE;

    /** 					integer start_pc = pc*/
    _start_pc_61922 = _pc_61838;

    /** 					if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30901 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30901);
    _30902 = (int)*(((s1_ptr)_2)->base + 2);
    _30901 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30902)){
        _30903 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30902)->dbl));
    }
    else{
        _30903 = (int)*(((s1_ptr)_2)->base + _30902);
    }
    _2 = (int)SEQ_PTR(_30903);
    _30904 = (int)*(((s1_ptr)_2)->base + 15);
    _30903 = NOVALUE;
    if (binary_op_a(NOTEQ, _30904, _53integer_type_45721)){
        _30904 = NOVALUE;
        goto L18; // [616] 672
    }
    _30904 = NOVALUE;

    /** 						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61805;
    _30906 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30907 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_61938);
    _code_inlined_insert_code_at_644_61938 = _30906;
    _30906 = NOVALUE;
    Ref(_30907);
    DeRef(_subprog_inlined_insert_code_at_647_61939);
    _subprog_inlined_insert_code_at_647_61939 = _30907;
    _30907 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_61939)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_647_61939)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_61939);
        _subprog_inlined_insert_code_at_647_61939 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_647_61939;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_61938);
    _65insert_code(_code_inlined_insert_code_at_644_61938, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_61938);
    _code_inlined_insert_code_at_644_61938 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_61939);
    _subprog_inlined_insert_code_at_647_61939 = NOVALUE;

    /** 						pc += 2*/
    _pc_61838 = _pc_61838 + 2;
L18: 

    /** 					symtab_index c = NewTempSym()*/
    _c_61942 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_c_61942)) {
        _1 = (long)(DBL_PTR(_c_61942)->dbl);
        DeRefDS(_c_61942);
        _c_61942 = _1;
    }

    /** 					SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_fr_61800);
    _30910 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30910))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30910)->dbl));
    else
    _3 = (int)(_30910 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701)){
        _30913 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    }
    else{
        _30913 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    }
    _30911 = NOVALUE;
    if (IS_ATOM_INT(_30913)) {
        _30914 = _30913 + 1;
        if (_30914 > MAXINT){
            _30914 = NewDouble((double)_30914);
        }
    }
    else
    _30914 = binary_op(PLUS, 1, _30913);
    _30913 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    _1 = *(int *)_2;
    *(int *)_2 = _30914;
    if( _1 != _30914 ){
        DeRef(_1);
    }
    _30914 = NOVALUE;
    _30911 = NOVALUE;

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_61803;
    *((int *)(_2+12)) = _var_61805;
    *((int *)(_2+16)) = _c_61942;
    *((int *)(_2+20)) = 65;
    _30915 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30916 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_61957);
    _code_inlined_insert_code_at_738_61957 = _30915;
    _30915 = NOVALUE;
    Ref(_30916);
    DeRef(_subprog_inlined_insert_code_at_741_61958);
    _subprog_inlined_insert_code_at_741_61958 = _30916;
    _30916 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_61958)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_741_61958)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_61958);
        _subprog_inlined_insert_code_at_741_61958 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_741_61958;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_61957);
    _65insert_code(_code_inlined_insert_code_at_738_61957, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_61957);
    _code_inlined_insert_code_at_738_61957 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_61958);
    _subprog_inlined_insert_code_at_741_61958 = NOVALUE;

    /** 					pc += 4*/
    _pc_61838 = _pc_61838 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** 	if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_35TRANSLATE_15611 != 0) {
        _30918 = 1;
        goto L1B; // [775] 786
    }
    _30919 = (_with_type_check_61840 == 0);
    _30918 = (_30919 != 0);
L1B: 
    if (_30918 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30921 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30921);
    _30922 = (int)*(((s1_ptr)_2)->base + 2);
    _30921 = NOVALUE;
    if (_30922 == 0) {
        _30922 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_30922) && DBL_PTR(_30922)->dbl == 0.0){
            _30922 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _30922 = NOVALUE;
    }
    _30922 = NOVALUE;

    /** 		integer start_pc = pc*/
    _start_pc_61969 = _pc_61838;

    /** 		if which_type = sequence_type or*/
    _30923 = (_which_type_61803 == _53sequence_type_45719);
    if (_30923 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30925 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30925);
    _30926 = (int)*(((s1_ptr)_2)->base + 2);
    _30925 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30926)){
        _30927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30926)->dbl));
    }
    else{
        _30927 = (int)*(((s1_ptr)_2)->base + _30926);
    }
    _2 = (int)SEQ_PTR(_30927);
    _30928 = (int)*(((s1_ptr)_2)->base + 15);
    _30927 = NOVALUE;
    if (IS_ATOM_INT(_30928)) {
        _30929 = (_30928 == _53sequence_type_45719);
    }
    else {
        _30929 = binary_op(EQUALS, _30928, _53sequence_type_45719);
    }
    _30928 = NOVALUE;
    if (_30929 == 0) {
        DeRef(_30929);
        _30929 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_30929) && DBL_PTR(_30929)->dbl == 0.0){
            DeRef(_30929);
            _30929 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_30929);
        _30929 = NOVALUE;
    }
    DeRef(_30929);
    _30929 = NOVALUE;
L1D: 

    /** 			insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_61805;
    _30930 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30931 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_61988);
    _code_inlined_insert_code_at_883_61988 = _30930;
    _30930 = NOVALUE;
    Ref(_30931);
    DeRef(_subprog_inlined_insert_code_at_886_61989);
    _subprog_inlined_insert_code_at_886_61989 = _30931;
    _30931 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_61989)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_886_61989)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_61989);
        _subprog_inlined_insert_code_at_886_61989 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_886_61989;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_61988);
    _65insert_code(_code_inlined_insert_code_at_883_61988, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_61988);
    _code_inlined_insert_code_at_883_61988 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_61989);
    _subprog_inlined_insert_code_at_886_61989 = NOVALUE;

    /** 			pc += 2*/
    _pc_61838 = _pc_61838 + 2;
    goto L20; // [909] 1012
L1E: 

    /** 		elsif which_type = integer_type or*/
    _30933 = (_which_type_61803 == _53integer_type_45721);
    if (_30933 != 0) {
        goto L21; // [920] 959
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30935 = (int)*(((s1_ptr)_2)->base + _which_type_61803);
    _2 = (int)SEQ_PTR(_30935);
    _30936 = (int)*(((s1_ptr)_2)->base + 2);
    _30935 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30936)){
        _30937 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30936)->dbl));
    }
    else{
        _30937 = (int)*(((s1_ptr)_2)->base + _30936);
    }
    _2 = (int)SEQ_PTR(_30937);
    _30938 = (int)*(((s1_ptr)_2)->base + 15);
    _30937 = NOVALUE;
    if (IS_ATOM_INT(_30938)) {
        _30939 = (_30938 == _53integer_type_45721);
    }
    else {
        _30939 = binary_op(EQUALS, _30938, _53integer_type_45721);
    }
    _30938 = NOVALUE;
    if (_30939 == 0) {
        DeRef(_30939);
        _30939 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_30939) && DBL_PTR(_30939)->dbl == 0.0){
            DeRef(_30939);
            _30939 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_30939);
        _30939 = NOVALUE;
    }
    DeRef(_30939);
    _30939 = NOVALUE;
L21: 

    /** 			insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61805;
    _30940 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61800);
    _30941 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_62009);
    _code_inlined_insert_code_at_984_62009 = _30940;
    _30940 = NOVALUE;
    Ref(_30941);
    DeRef(_subprog_inlined_insert_code_at_987_62010);
    _subprog_inlined_insert_code_at_987_62010 = _30941;
    _30941 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_62010)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_987_62010)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_62010);
        _subprog_inlined_insert_code_at_987_62010 = _1;
    }

    /** 	shifting_sub = subprog*/
    _38shifting_sub_61072 = _subprog_inlined_insert_code_at_987_62010;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_62009);
    _65insert_code(_code_inlined_insert_code_at_984_62009, _pc_61838);

    /** 	shifting_sub = 0*/
    _38shifting_sub_61072 = 0;

    /** end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_62009);
    _code_inlined_insert_code_at_984_62009 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_62010);
    _subprog_inlined_insert_code_at_987_62010 = NOVALUE;

    /** 			pc += 4*/
    _pc_61838 = _pc_61838 + 4;
L22: 
L20: 
L1C: 

    /** 	resolved_reference( ref )*/
    _38resolved_reference(_ref_61799);

    /** 	reset_code()*/
    _38reset_code();

    /** end procedure*/
    DeRef(_tok_61798);
    DeRef(_fr_61800);
    _30856 = NOVALUE;
    DeRef(_30869);
    _30869 = NOVALUE;
    DeRef(_30874);
    _30874 = NOVALUE;
    _30902 = NOVALUE;
    _30910 = NOVALUE;
    DeRef(_30919);
    _30919 = NOVALUE;
    DeRef(_30923);
    _30923 = NOVALUE;
    _30926 = NOVALUE;
    DeRef(_30933);
    _30933 = NOVALUE;
    _30936 = NOVALUE;
    return;
    ;
}


void _38prep_forward_error(int _ref_62014)
{
    int _30949 = NOVALUE;
    int _30947 = NOVALUE;
    int _30945 = NOVALUE;
    int _30943 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62014)) {
        _1 = (long)(DBL_PTR(_ref_62014)->dbl);
        DeRefDS(_ref_62014);
        _ref_62014 = _1;
    }

    /** 	ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30943 = (int)*(((s1_ptr)_2)->base + _ref_62014);
    DeRef(_44ThisLine_48142);
    _2 = (int)SEQ_PTR(_30943);
    _44ThisLine_48142 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_44ThisLine_48142);
    _30943 = NOVALUE;

    /** 	bp = forward_references[ref][FR_BP]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30945 = (int)*(((s1_ptr)_2)->base + _ref_62014);
    _2 = (int)SEQ_PTR(_30945);
    _44bp_48146 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_44bp_48146)){
        _44bp_48146 = (long)DBL_PTR(_44bp_48146)->dbl;
    }
    _30945 = NOVALUE;

    /** 	line_number = forward_references[ref][FR_LINE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30947 = (int)*(((s1_ptr)_2)->base + _ref_62014);
    _2 = (int)SEQ_PTR(_30947);
    _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35line_number_15969)){
        _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
    }
    _30947 = NOVALUE;

    /** 	current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30949 = (int)*(((s1_ptr)_2)->base + _ref_62014);
    _2 = (int)SEQ_PTR(_30949);
    _35current_file_no_15968 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35current_file_no_15968)){
        _35current_file_no_15968 = (long)DBL_PTR(_35current_file_no_15968)->dbl;
    }
    _30949 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _38forward_error(int _tok_62030, int _ref_62031)
{
    int _30956 = NOVALUE;
    int _30955 = NOVALUE;
    int _30954 = NOVALUE;
    int _30953 = NOVALUE;
    int _30952 = NOVALUE;
    int _30951 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prep_forward_error( ref )*/
    _38prep_forward_error(_ref_62031);

    /** 	CompileErr(68, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30951 = (int)*(((s1_ptr)_2)->base + _ref_62031);
    _2 = (int)SEQ_PTR(_30951);
    _30952 = (int)*(((s1_ptr)_2)->base + 1);
    _30951 = NOVALUE;
    Ref(_30952);
    _30953 = _38expected_name(_30952);
    _30952 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62030);
    _30954 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30954);
    _30955 = _38expected_name(_30954);
    _30954 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30953;
    ((int *)_2)[2] = _30955;
    _30956 = MAKE_SEQ(_1);
    _30955 = NOVALUE;
    _30953 = NOVALUE;
    _44CompileErr(68, _30956, 0);
    _30956 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_62030);
    return;
    ;
}


int _38find_reference(int _fr_62042)
{
    int _name_62043 = NOVALUE;
    int _file_62045 = NOVALUE;
    int _ns_file_62047 = NOVALUE;
    int _ix_62048 = NOVALUE;
    int _ns_62051 = NOVALUE;
    int _ns_tok_62055 = NOVALUE;
    int _tok_62067 = NOVALUE;
    int _30967 = NOVALUE;
    int _30964 = NOVALUE;
    int _30962 = NOVALUE;
    int _30960 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_62043);
    _2 = (int)SEQ_PTR(_fr_62042);
    _name_62043 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_62043);

    /** 	integer file  = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_62042);
    _file_62045 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_62045))
    _file_62045 = (long)DBL_PTR(_file_62045)->dbl;

    /** 	integer ns_file = -1*/
    _ns_file_62047 = -1;

    /** 	integer ix = find( ':', name )*/
    _ix_62048 = find_from(58, _name_62043, 1);

    /** 	if ix then*/
    if (_ix_62048 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** 		sequence ns = name[1..ix-1]*/
    _30960 = _ix_62048 - 1;
    rhs_slice_target = (object_ptr)&_ns_62051;
    RHS_Slice(_name_62043, 1, _30960);

    /** 		token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62042);
    _30962 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_62051);
    Ref(_30962);
    _0 = _ns_tok_62055;
    _ns_tok_62055 = _53keyfind(_ns_62051, -1, _file_62045, 1, _30962);
    DeRef(_0);
    _30962 = NOVALUE;

    /** 		if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_ns_tok_62055);
    _30964 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30964, 523)){
        _30964 = NOVALUE;
        goto L2; // [69] 80
    }
    _30964 = NOVALUE;

    /** 			return ns_tok*/
    DeRefDS(_ns_62051);
    DeRefDS(_fr_62042);
    DeRefDS(_name_62043);
    DeRef(_tok_62067);
    _30960 = NOVALUE;
    return _ns_tok_62055;
L2: 
    DeRef(_ns_62051);
    _ns_62051 = NOVALUE;
    DeRef(_ns_tok_62055);
    _ns_tok_62055 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** 		ns_file = fr[FR_QUALIFIED]*/
    _2 = (int)SEQ_PTR(_fr_62042);
    _ns_file_62047 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_62047))
    _ns_file_62047 = (long)DBL_PTR(_ns_file_62047)->dbl;
L3: 

    /** 	No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 	object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62042);
    _30967 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_62043);
    Ref(_30967);
    _0 = _tok_62067;
    _tok_62067 = _53keyfind(_name_62043, _ns_file_62047, _file_62045, 0, _30967);
    DeRef(_0);
    _30967 = NOVALUE;

    /** 	No_new_entry = 0*/
    _53No_new_entry_46887 = 0;

    /** 	return tok*/
    DeRefDS(_fr_62042);
    DeRefDS(_name_62043);
    DeRef(_30960);
    _30960 = NOVALUE;
    return _tok_62067;
    ;
}


void _38register_forward_type(int _sym_62075, int _ref_62076)
{
    int _30974 = NOVALUE;
    int _30973 = NOVALUE;
    int _30971 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_62075)) {
        _1 = (long)(DBL_PTR(_sym_62075)->dbl);
        DeRefDS(_sym_62075);
        _sym_62075 = _1;
    }
    if (!IS_ATOM_INT(_ref_62076)) {
        _1 = (long)(DBL_PTR(_ref_62076)->dbl);
        DeRefDS(_ref_62076);
        _ref_62076 = _1;
    }

    /** 	if ref < 0 then*/
    if (_ref_62076 >= 0)
    goto L1; // [7] 19

    /** 		ref = -ref*/
    _ref_62076 = - _ref_62076;
L1: 

    /** 	forward_references[ref][FR_DATA] &= sym*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62076 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30973 = (int)*(((s1_ptr)_2)->base + 12);
    _30971 = NOVALUE;
    if (IS_SEQUENCE(_30973) && IS_ATOM(_sym_62075)) {
        Append(&_30974, _30973, _sym_62075);
    }
    else if (IS_ATOM(_30973) && IS_SEQUENCE(_sym_62075)) {
    }
    else {
        Concat((object_ptr)&_30974, _30973, _sym_62075);
        _30973 = NOVALUE;
    }
    _30973 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30974;
    if( _1 != _30974 ){
        DeRef(_1);
    }
    _30974 = NOVALUE;
    _30971 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _38forward_reference(int _ref_62086)
{
    int _30987 = NOVALUE;
    int _30986 = NOVALUE;
    int _30985 = NOVALUE;
    int _30984 = NOVALUE;
    int _30983 = NOVALUE;
    int _30982 = NOVALUE;
    int _30981 = NOVALUE;
    int _30979 = NOVALUE;
    int _30978 = NOVALUE;
    int _30977 = NOVALUE;
    int _30976 = NOVALUE;
    int _30975 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62086)) {
        _1 = (long)(DBL_PTR(_ref_62086)->dbl);
        DeRefDS(_ref_62086);
        _ref_62086 = _1;
    }

    /** 	if 0 > ref and ref >= -length( forward_references ) then*/
    _30975 = (0 > _ref_62086);
    if (_30975 == 0) {
        goto L1; // [9] 91
    }
    if (IS_SEQUENCE(_38forward_references_61053)){
            _30977 = SEQ_PTR(_38forward_references_61053)->length;
    }
    else {
        _30977 = 1;
    }
    _30978 = - _30977;
    _30979 = (_ref_62086 >= _30978);
    _30978 = NOVALUE;
    if (_30979 == 0)
    {
        DeRef(_30979);
        _30979 = NOVALUE;
        goto L1; // [26] 91
    }
    else{
        DeRef(_30979);
        _30979 = NOVALUE;
    }

    /** 		ref = -ref*/
    _ref_62086 = - _ref_62086;

    /** 		if integer(forward_references[ref][FR_FILE]) and*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30981 = (int)*(((s1_ptr)_2)->base + _ref_62086);
    _2 = (int)SEQ_PTR(_30981);
    _30982 = (int)*(((s1_ptr)_2)->base + 3);
    _30981 = NOVALUE;
    if (IS_ATOM_INT(_30982))
    _30983 = 1;
    else if (IS_ATOM_DBL(_30982))
    _30983 = IS_ATOM_INT(DoubleToInt(_30982));
    else
    _30983 = 0;
    _30982 = NOVALUE;
    if (_30983 == 0) {
        goto L2; // [51] 81
    }
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _30985 = (int)*(((s1_ptr)_2)->base + _ref_62086);
    _2 = (int)SEQ_PTR(_30985);
    _30986 = (int)*(((s1_ptr)_2)->base + 5);
    _30985 = NOVALUE;
    if (IS_ATOM_INT(_30986))
    _30987 = 1;
    else if (IS_ATOM_DBL(_30986))
    _30987 = IS_ATOM_INT(DoubleToInt(_30986));
    else
    _30987 = 0;
    _30986 = NOVALUE;
    if (_30987 == 0)
    {
        _30987 = NOVALUE;
        goto L2; // [69] 81
    }
    else{
        _30987 = NOVALUE;
    }

    /** 				return 1*/
    DeRef(_30975);
    _30975 = NOVALUE;
    return 1;
    goto L3; // [78] 98
L2: 

    /** 			return 0*/
    DeRef(_30975);
    _30975 = NOVALUE;
    return 0;
    goto L3; // [88] 98
L1: 

    /** 		return 0*/
    DeRef(_30975);
    _30975 = NOVALUE;
    return 0;
L3: 
    ;
}


int _38new_forward_reference(int _fwd_op_62106, int _sym_62108, int _op_62109)
{
    int _ref_62110 = NOVALUE;
    int _len_62111 = NOVALUE;
    int _hashval_62141 = NOVALUE;
    int _default_sym_62216 = NOVALUE;
    int _param_62219 = NOVALUE;
    int _set_data_2__tmp_at578_62236 = NOVALUE;
    int _set_data_1__tmp_at578_62235 = NOVALUE;
    int _data_inlined_set_data_at_575_62234 = NOVALUE;
    int _31060 = NOVALUE;
    int _31059 = NOVALUE;
    int _31058 = NOVALUE;
    int _31055 = NOVALUE;
    int _31053 = NOVALUE;
    int _31052 = NOVALUE;
    int _31050 = NOVALUE;
    int _31049 = NOVALUE;
    int _31048 = NOVALUE;
    int _31046 = NOVALUE;
    int _31044 = NOVALUE;
    int _31042 = NOVALUE;
    int _31039 = NOVALUE;
    int _31038 = NOVALUE;
    int _31036 = NOVALUE;
    int _31034 = NOVALUE;
    int _31032 = NOVALUE;
    int _31030 = NOVALUE;
    int _31029 = NOVALUE;
    int _31028 = NOVALUE;
    int _31026 = NOVALUE;
    int _31023 = NOVALUE;
    int _31021 = NOVALUE;
    int _31019 = NOVALUE;
    int _31018 = NOVALUE;
    int _31017 = NOVALUE;
    int _31016 = NOVALUE;
    int _31014 = NOVALUE;
    int _31011 = NOVALUE;
    int _31010 = NOVALUE;
    int _31009 = NOVALUE;
    int _31007 = NOVALUE;
    int _31006 = NOVALUE;
    int _31005 = NOVALUE;
    int _31004 = NOVALUE;
    int _31002 = NOVALUE;
    int _31001 = NOVALUE;
    int _31000 = NOVALUE;
    int _30999 = NOVALUE;
    int _30997 = NOVALUE;
    int _30994 = NOVALUE;
    int _30993 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_fwd_op_62106)) {
        _1 = (long)(DBL_PTR(_fwd_op_62106)->dbl);
        DeRefDS(_fwd_op_62106);
        _fwd_op_62106 = _1;
    }
    if (!IS_ATOM_INT(_sym_62108)) {
        _1 = (long)(DBL_PTR(_sym_62108)->dbl);
        DeRefDS(_sym_62108);
        _sym_62108 = _1;
    }
    if (!IS_ATOM_INT(_op_62109)) {
        _1 = (long)(DBL_PTR(_op_62109)->dbl);
        DeRefDS(_op_62109);
        _op_62109 = _1;
    }

    /** 		len = length( inactive_references )*/
    if (IS_SEQUENCE(_38inactive_references_61057)){
            _len_62111 = SEQ_PTR(_38inactive_references_61057)->length;
    }
    else {
        _len_62111 = 1;
    }

    /** 	if len then*/
    if (_len_62111 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** 		ref = inactive_references[len]*/
    _2 = (int)SEQ_PTR(_38inactive_references_61057);
    _ref_62110 = (int)*(((s1_ptr)_2)->base + _len_62111);
    if (!IS_ATOM_INT(_ref_62110))
    _ref_62110 = (long)DBL_PTR(_ref_62110)->dbl;

    /** 		inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_38inactive_references_61057);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_62111)) ? _len_62111 : (long)(DBL_PTR(_len_62111)->dbl);
        int stop = (IS_ATOM_INT(_len_62111)) ? _len_62111 : (long)(DBL_PTR(_len_62111)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_38inactive_references_61057), start, &_38inactive_references_61057 );
            }
            else Tail(SEQ_PTR(_38inactive_references_61057), stop+1, &_38inactive_references_61057);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_38inactive_references_61057), start, &_38inactive_references_61057);
        }
        else {
            assign_slice_seq = &assign_space;
            _38inactive_references_61057 = Remove_elements(start, stop, (SEQ_PTR(_38inactive_references_61057)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** 		forward_references &= 0*/
    Append(&_38forward_references_61053, _38forward_references_61053, 0);

    /** 		ref = length( forward_references )*/
    if (IS_SEQUENCE(_38forward_references_61053)){
            _ref_62110 = SEQ_PTR(_38forward_references_61053)->length;
    }
    else {
        _ref_62110 = 1;
    }
L2: 

    /** 	forward_references[ref] = repeat( 0, FR_SIZE )*/
    _30993 = Repeat(0, 12);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_62110);
    _1 = *(int *)_2;
    *(int *)_2 = _30993;
    if( _1 != _30993 ){
        DeRef(_1);
    }
    _30993 = NOVALUE;

    /** 	forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _fwd_op_62106;
    DeRef(_1);
    _30994 = NOVALUE;

    /** 	if sym < 0 then*/
    if (_sym_62108 >= 0)
    goto L3; // [84] 143

    /** 		forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62108 == 0xC0000000)
    _30999 = (int)NewDouble((double)-0xC0000000);
    else
    _30999 = - _sym_62108;
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!IS_ATOM_INT(_30999)){
        _31000 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30999)->dbl));
    }
    else{
        _31000 = (int)*(((s1_ptr)_2)->base + _30999);
    }
    _2 = (int)SEQ_PTR(_31000);
    _31001 = (int)*(((s1_ptr)_2)->base + 2);
    _31000 = NOVALUE;
    Ref(_31001);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31001;
    if( _1 != _31001 ){
        DeRef(_1);
    }
    _31001 = NOVALUE;
    _30997 = NOVALUE;

    /** 		forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62108 == 0xC0000000)
    _31004 = (int)NewDouble((double)-0xC0000000);
    else
    _31004 = - _sym_62108;
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!IS_ATOM_INT(_31004)){
        _31005 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31004)->dbl));
    }
    else{
        _31005 = (int)*(((s1_ptr)_2)->base + _31004);
    }
    _2 = (int)SEQ_PTR(_31005);
    _31006 = (int)*(((s1_ptr)_2)->base + 11);
    _31005 = NOVALUE;
    Ref(_31006);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31006;
    if( _1 != _31006 ){
        DeRef(_1);
    }
    _31006 = NOVALUE;
    _31002 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** 		forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31009 = (int)*(((s1_ptr)_2)->base + _sym_62108);
    _2 = (int)SEQ_PTR(_31009);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _31010 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _31010 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _31009 = NOVALUE;
    Ref(_31010);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31010;
    if( _1 != _31010 ){
        DeRef(_1);
    }
    _31010 = NOVALUE;
    _31007 = NOVALUE;

    /** 		integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31011 = (int)*(((s1_ptr)_2)->base + _sym_62108);
    _2 = (int)SEQ_PTR(_31011);
    _hashval_62141 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_62141)){
        _hashval_62141 = (long)DBL_PTR(_hashval_62141)->dbl;
    }
    _31011 = NOVALUE;

    /** 		if 0 = hashval then*/
    if (0 != _hashval_62141)
    goto L5; // [186] 220

    /** 			forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    _31016 = (int)*(((s1_ptr)_2)->base + _ref_62110);
    _2 = (int)SEQ_PTR(_31016);
    _31017 = (int)*(((s1_ptr)_2)->base + 2);
    _31016 = NOVALUE;
    Ref(_31017);
    _31018 = _53hashfn(_31017);
    _31017 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31018;
    if( _1 != _31018 ){
        DeRef(_1);
    }
    _31018 = NOVALUE;
    _31014 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** 			forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_62141;
    DeRef(_1);
    _31019 = NOVALUE;

    /** 			remove_symbol( sym )*/
    _53remove_symbol(_sym_62108);
L6: 
L4: 

    /** 	forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);
    _31021 = NOVALUE;

    /** 	forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35CurrentSub_15976;
    DeRef(_1);
    _31023 = NOVALUE;

    /** 	if fwd_op != TYPE then*/
    if (_fwd_op_62106 == 504)
    goto L7; // [276] 303

    /** 		forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16056)){
            _31028 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _31028 = 1;
    }
    _31029 = _31028 + 1;
    _31028 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31029;
    if( _1 != _31029 ){
        DeRef(_1);
    }
    _31029 = NOVALUE;
    _31026 = NOVALUE;
L7: 

    /** 	forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _35fwd_line_number_15970;
    DeRef(_1);
    _31030 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    Ref(_44ForwardLine_48143);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _44ForwardLine_48143;
    DeRef(_1);
    _31032 = NOVALUE;

    /** 	forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _44forward_bp_48147;
    DeRef(_1);
    _31034 = NOVALUE;

    /** 	forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _31038 = _61get_qualified_fwd();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31038;
    if( _1 != _31038 ){
        DeRef(_1);
    }
    _31038 = NOVALUE;
    _31036 = NOVALUE;

    /** 	forward_references[ref][FR_OP]        = op*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _op_62109;
    DeRef(_1);
    _31039 = NOVALUE;

    /** 	if op = GOTO then*/
    if (_op_62109 != 188)
    goto L8; // [381] 403

    /** 		forward_references[ref][FR_DATA] = { sym }*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _sym_62108;
    _31044 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31044;
    if( _1 != _31044 ){
        DeRef(_1);
    }
    _31044 = NOVALUE;
    _31042 = NOVALUE;
L8: 

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_15976 != _35TopLevelSub_15975)
    goto L9; // [409] 471

    /** 		if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_38toplevel_references_61056)){
            _31046 = SEQ_PTR(_38toplevel_references_61056)->length;
    }
    else {
        _31046 = 1;
    }
    if (_31046 >= _35current_file_no_15968)
    goto LA; // [422] 450

    /** 			toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_38toplevel_references_61056)){
            _31048 = SEQ_PTR(_38toplevel_references_61056)->length;
    }
    else {
        _31048 = 1;
    }
    _31049 = _35current_file_no_15968 - _31048;
    _31048 = NOVALUE;
    _31050 = Repeat(_21815, _31049);
    _31049 = NOVALUE;
    Concat((object_ptr)&_38toplevel_references_61056, _38toplevel_references_61056, _31050);
    DeRefDS(_31050);
    _31050 = NOVALUE;
LA: 

    /** 		toplevel_references[current_file_no] &= ref*/
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    _31052 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_31052) && IS_ATOM(_ref_62110)) {
        Append(&_31053, _31052, _ref_62110);
    }
    else if (IS_ATOM(_31052) && IS_SEQUENCE(_ref_62110)) {
    }
    else {
        Concat((object_ptr)&_31053, _31052, _ref_62110);
        _31052 = NOVALUE;
    }
    _31052 = NOVALUE;
    _2 = (int)SEQ_PTR(_38toplevel_references_61056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38toplevel_references_61056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _31053;
    if( _1 != _31053 ){
        DeRef(_1);
    }
    _31053 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** 		add_active_reference( ref )*/
    _38add_active_reference(_ref_62110, _35current_file_no_15968);

    /** 		if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16073 != 1)
    goto LC; // [485] 592

    /** 			symtab_pointer default_sym = CurrentSub*/
    _default_sym_62216 = _35CurrentSub_15976;

    /** 			symtab_pointer param = 0*/
    _param_62219 = 0;

    /** 			while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_62216 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** 				if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31055 = _53sym_scope(_default_sym_62216);
    if (binary_op_a(NOTEQ, _31055, 3)){
        DeRef(_31055);
        _31055 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31055);
    _31055 = NOVALUE;

    /** 					param = default_sym*/
    _param_62219 = _default_sym_62216;
L10: 

    /** 			entry*/
LD: 

    /** 				default_sym = sym_next( default_sym )*/
    _default_sym_62216 = _53sym_next(_default_sym_62216);
    if (!IS_ATOM_INT(_default_sym_62216)) {
        _1 = (long)(DBL_PTR(_default_sym_62216)->dbl);
        DeRefDS(_default_sym_62216);
        _default_sym_62216 = _1;
    }

    /** 			end while*/
    goto LE; // [546] 510
LF: 

    /** 			set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_35Recorded_sym_16076)){
            _31058 = SEQ_PTR(_35Recorded_sym_16076)->length;
    }
    else {
        _31058 = 1;
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _param_62219;
    *((int *)(_2+12)) = _31058;
    _31059 = MAKE_SEQ(_1);
    _31058 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31059;
    _31060 = MAKE_SEQ(_1);
    _31059 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_62234);
    _data_inlined_set_data_at_575_62234 = _31060;
    _31060 = NOVALUE;

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_38forward_references_61053);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38forward_references_61053 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62110 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_62234);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_inlined_set_data_at_575_62234;
    DeRef(_1);

    /** end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_62234);
    _data_inlined_set_data_at_575_62234 = NOVALUE;
LC: 
LB: 

    /** 	fwdref_count += 1*/
    _38fwdref_count_61073 = _38fwdref_count_61073 + 1;

    /** 	return ref*/
    DeRef(_30999);
    _30999 = NOVALUE;
    DeRef(_31004);
    _31004 = NOVALUE;
    return _ref_62110;
    ;
}


void _38add_active_reference(int _ref_62240, int _file_no_62241)
{
    int _sp_62255 = NOVALUE;
    int _31084 = NOVALUE;
    int _31083 = NOVALUE;
    int _31081 = NOVALUE;
    int _31080 = NOVALUE;
    int _31079 = NOVALUE;
    int _31077 = NOVALUE;
    int _31076 = NOVALUE;
    int _31075 = NOVALUE;
    int _31072 = NOVALUE;
    int _31070 = NOVALUE;
    int _31069 = NOVALUE;
    int _31068 = NOVALUE;
    int _31066 = NOVALUE;
    int _31065 = NOVALUE;
    int _31064 = NOVALUE;
    int _31062 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_38active_references_61055)){
            _31062 = SEQ_PTR(_38active_references_61055)->length;
    }
    else {
        _31062 = 1;
    }
    if (_31062 >= _file_no_62241)
    goto L1; // [12] 59

    /** 		active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_38active_references_61055)){
            _31064 = SEQ_PTR(_38active_references_61055)->length;
    }
    else {
        _31064 = 1;
    }
    _31065 = _file_no_62241 - _31064;
    _31064 = NOVALUE;
    _31066 = Repeat(_21815, _31065);
    _31065 = NOVALUE;
    Concat((object_ptr)&_38active_references_61055, _38active_references_61055, _31066);
    DeRefDS(_31066);
    _31066 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_38active_subprogs_61054)){
            _31068 = SEQ_PTR(_38active_subprogs_61054)->length;
    }
    else {
        _31068 = 1;
    }
    _31069 = _file_no_62241 - _31068;
    _31068 = NOVALUE;
    _31070 = Repeat(_21815, _31069);
    _31069 = NOVALUE;
    Concat((object_ptr)&_38active_subprogs_61054, _38active_subprogs_61054, _31070);
    DeRefDS(_31070);
    _31070 = NOVALUE;
L1: 

    /** 	integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _31072 = (int)*(((s1_ptr)_2)->base + _file_no_62241);
    _sp_62255 = find_from(_35CurrentSub_15976, _31072, 1);
    _31072 = NOVALUE;

    /** 	if not sp then*/
    if (_sp_62255 != 0)
    goto L2; // [76] 127

    /** 		active_subprogs[file_no] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _31075 = (int)*(((s1_ptr)_2)->base + _file_no_62241);
    if (IS_SEQUENCE(_31075) && IS_ATOM(_35CurrentSub_15976)) {
        Append(&_31076, _31075, _35CurrentSub_15976);
    }
    else if (IS_ATOM(_31075) && IS_SEQUENCE(_35CurrentSub_15976)) {
    }
    else {
        Concat((object_ptr)&_31076, _31075, _35CurrentSub_15976);
        _31075 = NOVALUE;
    }
    _31075 = NOVALUE;
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_subprogs_61054 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62241);
    _1 = *(int *)_2;
    *(int *)_2 = _31076;
    if( _1 != _31076 ){
        DeRef(_1);
    }
    _31076 = NOVALUE;

    /** 		sp = length( active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _31077 = (int)*(((s1_ptr)_2)->base + _file_no_62241);
    if (IS_SEQUENCE(_31077)){
            _sp_62255 = SEQ_PTR(_31077)->length;
    }
    else {
        _sp_62255 = 1;
    }
    _31077 = NOVALUE;

    /** 		active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _31079 = (int)*(((s1_ptr)_2)->base + _file_no_62241);
    RefDS(_21815);
    Append(&_31080, _31079, _21815);
    _31079 = NOVALUE;
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62241);
    _1 = *(int *)_2;
    *(int *)_2 = _31080;
    if( _1 != _31080 ){
        DeRef(_1);
    }
    _31080 = NOVALUE;
L2: 

    /** 	active_references[file_no][sp] &= ref*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38active_references_61055 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_no_62241 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31083 = (int)*(((s1_ptr)_2)->base + _sp_62255);
    _31081 = NOVALUE;
    if (IS_SEQUENCE(_31083) && IS_ATOM(_ref_62240)) {
        Append(&_31084, _31083, _ref_62240);
    }
    else if (IS_ATOM(_31083) && IS_SEQUENCE(_ref_62240)) {
    }
    else {
        Concat((object_ptr)&_31084, _31083, _ref_62240);
        _31083 = NOVALUE;
    }
    _31083 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_62255);
    _1 = *(int *)_2;
    *(int *)_2 = _31084;
    if( _1 != _31084 ){
        DeRef(_1);
    }
    _31084 = NOVALUE;
    _31081 = NOVALUE;

    /** end procedure*/
    _31077 = NOVALUE;
    return;
    ;
}


int _38resolve_file(int _refs_62292, int _report_errors_62293, int _unincluded_ok_62294)
{
    int _errors_62295 = NOVALUE;
    int _ref_62299 = NOVALUE;
    int _fr_62301 = NOVALUE;
    int _tok_62314 = NOVALUE;
    int _code_sub_62322 = NOVALUE;
    int _fr_type_62324 = NOVALUE;
    int _sym_tok_62326 = NOVALUE;
    int _31138 = NOVALUE;
    int _31137 = NOVALUE;
    int _31136 = NOVALUE;
    int _31135 = NOVALUE;
    int _31134 = NOVALUE;
    int _31133 = NOVALUE;
    int _31128 = NOVALUE;
    int _31127 = NOVALUE;
    int _31126 = NOVALUE;
    int _31124 = NOVALUE;
    int _31123 = NOVALUE;
    int _31120 = NOVALUE;
    int _31119 = NOVALUE;
    int _31118 = NOVALUE;
    int _31114 = NOVALUE;
    int _31113 = NOVALUE;
    int _31105 = NOVALUE;
    int _31103 = NOVALUE;
    int _31102 = NOVALUE;
    int _31101 = NOVALUE;
    int _31100 = NOVALUE;
    int _31099 = NOVALUE;
    int _31098 = NOVALUE;
    int _31095 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence errors = {}*/
    RefDS(_21815);
    DeRefi(_errors_62295);
    _errors_62295 = _21815;

    /** 	for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62292)){
            _31095 = SEQ_PTR(_refs_62292)->length;
    }
    else {
        _31095 = 1;
    }
    {
        int _ar_62297;
        _ar_62297 = _31095;
L1: 
        if (_ar_62297 < 1){
            goto L2; // [19] 481
        }

        /** 		integer ref = refs[ar]*/
        _2 = (int)SEQ_PTR(_refs_62292);
        _ref_62299 = (int)*(((s1_ptr)_2)->base + _ar_62297);
        if (!IS_ATOM_INT(_ref_62299))
        _ref_62299 = (long)DBL_PTR(_ref_62299)->dbl;

        /** 		sequence fr = forward_references[ref]*/
        DeRef(_fr_62301);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        _fr_62301 = (int)*(((s1_ptr)_2)->base + _ref_62299);
        Ref(_fr_62301);

        /** 		if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (int)SEQ_PTR(_fr_62301);
        _31098 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!IS_ATOM_INT(_31098)){
            _31099 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31098)->dbl));
        }
        else{
            _31099 = (int)*(((s1_ptr)_2)->base + _31098);
        }
        _2 = (int)SEQ_PTR(_31099);
        _31100 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
        _31099 = NOVALUE;
        if (IS_ATOM_INT(_31100)) {
            _31101 = (_31100 == 0);
        }
        else {
            _31101 = binary_op(EQUALS, _31100, 0);
        }
        _31100 = NOVALUE;
        if (IS_ATOM_INT(_31101)) {
            if (_31101 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31101)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31103 = (_unincluded_ok_62294 == 0);
        if (_31103 == 0)
        {
            DeRef(_31103);
            _31103 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31103);
            _31103 = NOVALUE;
        }

        /** 			continue*/
        DeRef(_fr_62301);
        _fr_62301 = NOVALUE;
        DeRef(_tok_62314);
        _tok_62314 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** 		token tok = find_reference( fr )*/
        RefDS(_fr_62301);
        _0 = _tok_62314;
        _tok_62314 = _38find_reference(_fr_62301);
        DeRef(_0);

        /** 		if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62314);
        _31105 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31105, 509)){
            _31105 = NOVALUE;
            goto L5; // [100] 117
        }
        _31105 = NOVALUE;

        /** 			errors &= ref*/
        Append(&_errors_62295, _errors_62295, _ref_62299);

        /** 			continue*/
        DeRefDS(_fr_62301);
        _fr_62301 = NOVALUE;
        DeRef(_tok_62314);
        _tok_62314 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** 		integer code_sub = fr[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_fr_62301);
        _code_sub_62322 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_62322))
        _code_sub_62322 = (long)DBL_PTR(_code_sub_62322)->dbl;

        /** 		integer fr_type  = fr[FR_TYPE]*/
        _2 = (int)SEQ_PTR(_fr_62301);
        _fr_type_62324 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_62324))
        _fr_type_62324 = (long)DBL_PTR(_fr_type_62324)->dbl;

        /** 		integer sym_tok*/

        /** 		switch fr_type label "fr_type" do*/
        _0 = _fr_type_62324;
        switch ( _0 ){ 

            /** 			case PROC, FUNC then*/
            case 27:
            case 501:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62314);
            _31113 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!IS_ATOM_INT(_31113)){
                _31114 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31113)->dbl));
            }
            else{
                _31114 = (int)*(((s1_ptr)_2)->base + _31113);
            }
            _2 = (int)SEQ_PTR(_31114);
            if (!IS_ATOM_INT(_35S_TOKEN_15646)){
                _sym_tok_62326 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
            }
            else{
                _sym_tok_62326 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
            }
            if (!IS_ATOM_INT(_sym_tok_62326)){
                _sym_tok_62326 = (long)DBL_PTR(_sym_tok_62326)->dbl;
            }
            _31114 = NOVALUE;

            /** 				if sym_tok = TYPE then*/
            if (_sym_tok_62326 != 504)
            goto L6; // [170] 184

            /** 					sym_tok = FUNC*/
            _sym_tok_62326 = 501;
L6: 

            /** 				if sym_tok != fr_type then*/
            if (_sym_tok_62326 == _fr_type_62324)
            goto L7; // [186] 220

            /** 					if sym_tok != FUNC and fr_type != PROC then*/
            _31118 = (_sym_tok_62326 != 501);
            if (_31118 == 0) {
                goto L8; // [198] 219
            }
            _31120 = (_fr_type_62324 != 27);
            if (_31120 == 0)
            {
                DeRef(_31120);
                _31120 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31120);
                _31120 = NOVALUE;
            }

            /** 						forward_error( tok, ref )*/
            Ref(_tok_62314);
            _38forward_error(_tok_62314, _ref_62299);
L8: 
L7: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62326;
            switch ( _0 ){ 

                /** 					case PROC, FUNC then*/
                case 27:
                case 501:

                /** 						patch_forward_call( tok, ref )*/
                Ref(_tok_62314);
                _38patch_forward_call(_tok_62314, _ref_62299);

                /** 						break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62314);
                _38forward_error(_tok_62314, _ref_62299);
            ;}            goto L9; // [256] 446

            /** 			case VARIABLE then*/
            case -100:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62314);
            _31123 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!IS_ATOM_INT(_31123)){
                _31124 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31123)->dbl));
            }
            else{
                _31124 = (int)*(((s1_ptr)_2)->base + _31123);
            }
            _2 = (int)SEQ_PTR(_31124);
            if (!IS_ATOM_INT(_35S_TOKEN_15646)){
                _sym_tok_62326 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
            }
            else{
                _sym_tok_62326 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
            }
            if (!IS_ATOM_INT(_sym_tok_62326)){
                _sym_tok_62326 = (long)DBL_PTR(_sym_tok_62326)->dbl;
            }
            _31124 = NOVALUE;

            /** 				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (int)SEQ_PTR(_tok_62314);
            _31126 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!IS_ATOM_INT(_31126)){
                _31127 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31126)->dbl));
            }
            else{
                _31127 = (int)*(((s1_ptr)_2)->base + _31126);
            }
            _2 = (int)SEQ_PTR(_31127);
            _31128 = (int)*(((s1_ptr)_2)->base + 4);
            _31127 = NOVALUE;
            if (binary_op_a(NOTEQ, _31128, 9)){
                _31128 = NOVALUE;
                goto LA; // [306] 323
            }
            _31128 = NOVALUE;

            /** 					errors &= ref*/
            Append(&_errors_62295, _errors_62295, _ref_62299);

            /** 					continue*/
            DeRef(_fr_62301);
            _fr_62301 = NOVALUE;
            DeRef(_tok_62314);
            _tok_62314 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62326;
            switch ( _0 ){ 

                /** 					case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** 						patch_forward_variable( tok, ref )*/
                Ref(_tok_62314);
                _38patch_forward_variable(_tok_62314, _ref_62299);

                /** 						break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62314);
                _38forward_error(_tok_62314, _ref_62299);
            ;}            goto L9; // [361] 446

            /** 			case TYPE_CHECK then*/
            case 65:

            /** 				patch_forward_type_check( tok, ref )*/
            Ref(_tok_62314);
            _38patch_forward_type_check(_tok_62314, _ref_62299);
            goto L9; // [373] 446

            /** 			case GLOBAL_INIT_CHECK then*/
            case 109:

            /** 				patch_forward_init_check( tok, ref )*/
            Ref(_tok_62314);
            _38patch_forward_init_check(_tok_62314, _ref_62299);
            goto L9; // [385] 446

            /** 			case CASE then*/
            case 186:

            /** 				patch_forward_case( tok, ref )*/
            Ref(_tok_62314);
            _38patch_forward_case(_tok_62314, _ref_62299);
            goto L9; // [397] 446

            /** 			case TYPE then*/
            case 504:

            /** 				patch_forward_type( tok, ref )*/
            Ref(_tok_62314);
            _38patch_forward_type(_tok_62314, _ref_62299);
            goto L9; // [409] 446

            /** 			case GOTO then*/
            case 188:

            /** 				patch_forward_goto( tok, ref )*/
            Ref(_tok_62314);
            _38patch_forward_goto(_tok_62314, _ref_62299);
            goto L9; // [421] 446

            /** 			case else*/
            default:

            /** 				InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (int)SEQ_PTR(_fr_62301);
            _31133 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_fr_62301);
            _31134 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_31134);
            Ref(_31133);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _31133;
            ((int *)_2)[2] = _31134;
            _31135 = MAKE_SEQ(_1);
            _31134 = NOVALUE;
            _31133 = NOVALUE;
            _44InternalErr(263, _31135);
            _31135 = NOVALUE;
        ;}L9: 

        /** 		if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_62293 == 0) {
            goto LB; // [448] 472
        }
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        _31137 = (int)*(((s1_ptr)_2)->base + _ref_62299);
        _31138 = IS_SEQUENCE(_31137);
        _31137 = NOVALUE;
        if (_31138 == 0)
        {
            _31138 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31138 = NOVALUE;
        }

        /** 			errors &= ref*/
        Append(&_errors_62295, _errors_62295, _ref_62299);
LB: 
        DeRef(_fr_62301);
        _fr_62301 = NOVALUE;
        DeRef(_tok_62314);
        _tok_62314 = NOVALUE;

        /** 	end for*/
L4: 
        _ar_62297 = _ar_62297 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** 	return errors*/
    DeRefDS(_refs_62292);
    _31098 = NOVALUE;
    _31113 = NOVALUE;
    DeRef(_31101);
    _31101 = NOVALUE;
    DeRef(_31118);
    _31118 = NOVALUE;
    _31123 = NOVALUE;
    _31126 = NOVALUE;
    return _errors_62295;
    ;
}


int _38file_name_based_symindex_compare(int _si1_62404, int _si2_62405)
{
    int _fn1_62426 = NOVALUE;
    int _fn2_62431 = NOVALUE;
    int _31167 = NOVALUE;
    int _31166 = NOVALUE;
    int _31165 = NOVALUE;
    int _31164 = NOVALUE;
    int _31163 = NOVALUE;
    int _31162 = NOVALUE;
    int _31161 = NOVALUE;
    int _31160 = NOVALUE;
    int _31159 = NOVALUE;
    int _31158 = NOVALUE;
    int _31157 = NOVALUE;
    int _31156 = NOVALUE;
    int _31154 = NOVALUE;
    int _31152 = NOVALUE;
    int _31151 = NOVALUE;
    int _31150 = NOVALUE;
    int _31149 = NOVALUE;
    int _31148 = NOVALUE;
    int _31147 = NOVALUE;
    int _31146 = NOVALUE;
    int _31145 = NOVALUE;
    int _31144 = NOVALUE;
    int _31143 = NOVALUE;
    int _31141 = NOVALUE;
    int _31140 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_62404)) {
        _1 = (long)(DBL_PTR(_si1_62404)->dbl);
        DeRefDS(_si1_62404);
        _si1_62404 = _1;
    }
    if (!IS_ATOM_INT(_si2_62405)) {
        _1 = (long)(DBL_PTR(_si2_62405)->dbl);
        DeRefDS(_si2_62405);
        _si2_62405 = _1;
    }

    /** 	if not symtab_index(si1) or not symtab_index(si2) then*/
    _31140 = _35symtab_index(_si1_62404);
    if (IS_ATOM_INT(_31140)) {
        _31141 = (_31140 == 0);
    }
    else {
        _31141 = unary_op(NOT, _31140);
    }
    DeRef(_31140);
    _31140 = NOVALUE;
    if (IS_ATOM_INT(_31141)) {
        if (_31141 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31141)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31143 = _35symtab_index(_si2_62405);
    if (IS_ATOM_INT(_31143)) {
        _31144 = (_31143 == 0);
    }
    else {
        _31144 = unary_op(NOT, _31143);
    }
    DeRef(_31143);
    _31143 = NOVALUE;
    if (_31144 == 0) {
        DeRef(_31144);
        _31144 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31144) && DBL_PTR(_31144)->dbl == 0.0){
            DeRef(_31144);
            _31144 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31144);
        _31144 = NOVALUE;
    }
    DeRef(_31144);
    _31144 = NOVALUE;
L1: 

    /** 		return 1 -- put non symbols last*/
    DeRef(_31141);
    _31141 = NOVALUE;
    return 1;
L2: 

    /** 	if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31145 = (int)*(((s1_ptr)_2)->base + _si1_62404);
    if (IS_SEQUENCE(_31145)){
            _31146 = SEQ_PTR(_31145)->length;
    }
    else {
        _31146 = 1;
    }
    _31145 = NOVALUE;
    if (IS_ATOM_INT(_35S_FILE_NO_15637)) {
        _31147 = (_35S_FILE_NO_15637 <= _31146);
    }
    else {
        _31147 = binary_op(LESSEQ, _35S_FILE_NO_15637, _31146);
    }
    _31146 = NOVALUE;
    if (IS_ATOM_INT(_31147)) {
        if (_31147 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31147)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31149 = (int)*(((s1_ptr)_2)->base + _si2_62405);
    if (IS_SEQUENCE(_31149)){
            _31150 = SEQ_PTR(_31149)->length;
    }
    else {
        _31150 = 1;
    }
    _31149 = NOVALUE;
    if (IS_ATOM_INT(_35S_FILE_NO_15637)) {
        _31151 = (_35S_FILE_NO_15637 <= _31150);
    }
    else {
        _31151 = binary_op(LESSEQ, _35S_FILE_NO_15637, _31150);
    }
    _31150 = NOVALUE;
    if (_31151 == 0) {
        DeRef(_31151);
        _31151 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31151) && DBL_PTR(_31151)->dbl == 0.0){
            DeRef(_31151);
            _31151 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31151);
        _31151 = NOVALUE;
    }
    DeRef(_31151);
    _31151 = NOVALUE;

    /** 		integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31152 = (int)*(((s1_ptr)_2)->base + _si1_62404);
    _2 = (int)SEQ_PTR(_31152);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _fn1_62426 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _fn1_62426 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_fn1_62426)){
        _fn1_62426 = (long)DBL_PTR(_fn1_62426)->dbl;
    }
    _31152 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31154 = (int)*(((s1_ptr)_2)->base + _si2_62405);
    _2 = (int)SEQ_PTR(_31154);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _fn2_62431 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _fn2_62431 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_fn2_62431)){
        _fn2_62431 = (long)DBL_PTR(_fn2_62431)->dbl;
    }
    _31154 = NOVALUE;

    /** 		if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62426;
    ((int *)_2)[2] = _fn2_62431;
    _31156 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_36known_files_14982)){
            _31157 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31157 = 1;
    }
    _31158 = binary_op(GREATER, _31156, _31157);
    DeRefDS(_31156);
    _31156 = NOVALUE;
    _31157 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62426;
    ((int *)_2)[2] = _fn2_62431;
    _31159 = MAKE_SEQ(_1);
    _31160 = binary_op(LESSEQ, _31159, 0);
    DeRefDS(_31159);
    _31159 = NOVALUE;
    _31161 = binary_op(OR, _31158, _31160);
    DeRefDS(_31158);
    _31158 = NOVALUE;
    DeRefDS(_31160);
    _31160 = NOVALUE;
    _31162 = find_from(1, _31161, 1);
    DeRefDS(_31161);
    _31161 = NOVALUE;
    if (_31162 == 0)
    {
        _31162 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31162 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_31141);
    _31141 = NOVALUE;
    _31145 = NOVALUE;
    DeRef(_31147);
    _31147 = NOVALUE;
    _31149 = NOVALUE;
    return 1;
L4: 

    /** 		return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31163 = (int)*(((s1_ptr)_2)->base + _fn1_62426);
    Ref(_31163);
    RefDS(_21815);
    _31164 = _17abbreviate_path(_31163, _21815);
    _31163 = NOVALUE;
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _31165 = (int)*(((s1_ptr)_2)->base + _fn2_62431);
    Ref(_31165);
    RefDS(_21815);
    _31166 = _17abbreviate_path(_31165, _21815);
    _31165 = NOVALUE;
    if (IS_ATOM_INT(_31164) && IS_ATOM_INT(_31166)){
        _31167 = (_31164 < _31166) ? -1 : (_31164 > _31166);
    }
    else{
        _31167 = compare(_31164, _31166);
    }
    DeRef(_31164);
    _31164 = NOVALUE;
    DeRef(_31166);
    _31166 = NOVALUE;
    DeRef(_31141);
    _31141 = NOVALUE;
    _31145 = NOVALUE;
    DeRef(_31147);
    _31147 = NOVALUE;
    _31149 = NOVALUE;
    return _31167;
    goto L5; // [183] 193
L3: 

    /** 		return 1 -- put non-names last*/
    DeRef(_31141);
    _31141 = NOVALUE;
    _31145 = NOVALUE;
    DeRef(_31147);
    _31147 = NOVALUE;
    _31149 = NOVALUE;
    return 1;
L5: 
    ;
}


void _38Resolve_forward_references(int _report_errors_62457)
{
    int _errors_62458 = NOVALUE;
    int _unincluded_ok_62459 = NOVALUE;
    int _msg_62520 = NOVALUE;
    int _errloc_62521 = NOVALUE;
    int _ref_62526 = NOVALUE;
    int _tok_62542 = NOVALUE;
    int _THIS_SCOPE_62544 = NOVALUE;
    int _THESE_GLOBALS_62545 = NOVALUE;
    int _syms_62603 = NOVALUE;
    int _s_62624 = NOVALUE;
    int _31298 = NOVALUE;
    int _31296 = NOVALUE;
    int _31291 = NOVALUE;
    int _31288 = NOVALUE;
    int _31286 = NOVALUE;
    int _31285 = NOVALUE;
    int _31284 = NOVALUE;
    int _31283 = NOVALUE;
    int _31282 = NOVALUE;
    int _31281 = NOVALUE;
    int _31280 = NOVALUE;
    int _31278 = NOVALUE;
    int _31277 = NOVALUE;
    int _31276 = NOVALUE;
    int _31274 = NOVALUE;
    int _31272 = NOVALUE;
    int _31271 = NOVALUE;
    int _31270 = NOVALUE;
    int _31269 = NOVALUE;
    int _31268 = NOVALUE;
    int _31267 = NOVALUE;
    int _31264 = NOVALUE;
    int _31260 = NOVALUE;
    int _31259 = NOVALUE;
    int _31258 = NOVALUE;
    int _31257 = NOVALUE;
    int _31256 = NOVALUE;
    int _31255 = NOVALUE;
    int _31252 = NOVALUE;
    int _31251 = NOVALUE;
    int _31250 = NOVALUE;
    int _31249 = NOVALUE;
    int _31248 = NOVALUE;
    int _31247 = NOVALUE;
    int _31244 = NOVALUE;
    int _31243 = NOVALUE;
    int _31242 = NOVALUE;
    int _31241 = NOVALUE;
    int _31240 = NOVALUE;
    int _31239 = NOVALUE;
    int _31238 = NOVALUE;
    int _31237 = NOVALUE;
    int _31236 = NOVALUE;
    int _31235 = NOVALUE;
    int _31232 = NOVALUE;
    int _31230 = NOVALUE;
    int _31227 = NOVALUE;
    int _31225 = NOVALUE;
    int _31223 = NOVALUE;
    int _31222 = NOVALUE;
    int _31220 = NOVALUE;
    int _31219 = NOVALUE;
    int _31218 = NOVALUE;
    int _31217 = NOVALUE;
    int _31216 = NOVALUE;
    int _31214 = NOVALUE;
    int _31213 = NOVALUE;
    int _31211 = NOVALUE;
    int _31210 = NOVALUE;
    int _31208 = NOVALUE;
    int _31207 = NOVALUE;
    int _31205 = NOVALUE;
    int _31204 = NOVALUE;
    int _31203 = NOVALUE;
    int _31202 = NOVALUE;
    int _31201 = NOVALUE;
    int _31200 = NOVALUE;
    int _31199 = NOVALUE;
    int _31198 = NOVALUE;
    int _31197 = NOVALUE;
    int _31196 = NOVALUE;
    int _31195 = NOVALUE;
    int _31194 = NOVALUE;
    int _31193 = NOVALUE;
    int _31192 = NOVALUE;
    int _31191 = NOVALUE;
    int _31190 = NOVALUE;
    int _31188 = NOVALUE;
    int _31187 = NOVALUE;
    int _31186 = NOVALUE;
    int _31185 = NOVALUE;
    int _31183 = NOVALUE;
    int _31182 = NOVALUE;
    int _31180 = NOVALUE;
    int _31179 = NOVALUE;
    int _31178 = NOVALUE;
    int _31177 = NOVALUE;
    int _31175 = NOVALUE;
    int _31174 = NOVALUE;
    int _31173 = NOVALUE;
    int _31172 = NOVALUE;
    int _31170 = NOVALUE;
    int _31169 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_report_errors_62457)) {
        _1 = (long)(DBL_PTR(_report_errors_62457)->dbl);
        DeRefDS(_report_errors_62457);
        _report_errors_62457 = _1;
    }

    /** 	sequence errors = {}*/
    RefDS(_21815);
    DeRef(_errors_62458);
    _errors_62458 = _21815;

    /** 	integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_62459 = _53get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_62459)) {
        _1 = (long)(DBL_PTR(_unincluded_ok_62459)->dbl);
        DeRefDS(_unincluded_ok_62459);
        _unincluded_ok_62459 = _1;
    }

    /** 	if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_38active_references_61055)){
            _31169 = SEQ_PTR(_38active_references_61055)->length;
    }
    else {
        _31169 = 1;
    }
    if (IS_SEQUENCE(_36known_files_14982)){
            _31170 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31170 = 1;
    }
    if (_31169 >= _31170)
    goto L1; // [29] 86

    /** 		active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31172 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31172 = 1;
    }
    if (IS_SEQUENCE(_38active_references_61055)){
            _31173 = SEQ_PTR(_38active_references_61055)->length;
    }
    else {
        _31173 = 1;
    }
    _31174 = _31172 - _31173;
    _31172 = NOVALUE;
    _31173 = NOVALUE;
    _31175 = Repeat(_21815, _31174);
    _31174 = NOVALUE;
    Concat((object_ptr)&_38active_references_61055, _38active_references_61055, _31175);
    DeRefDS(_31175);
    _31175 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31177 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31177 = 1;
    }
    if (IS_SEQUENCE(_38active_subprogs_61054)){
            _31178 = SEQ_PTR(_38active_subprogs_61054)->length;
    }
    else {
        _31178 = 1;
    }
    _31179 = _31177 - _31178;
    _31177 = NOVALUE;
    _31178 = NOVALUE;
    _31180 = Repeat(_21815, _31179);
    _31179 = NOVALUE;
    Concat((object_ptr)&_38active_subprogs_61054, _38active_subprogs_61054, _31180);
    DeRefDS(_31180);
    _31180 = NOVALUE;
L1: 

    /** 	if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_38toplevel_references_61056)){
            _31182 = SEQ_PTR(_38toplevel_references_61056)->length;
    }
    else {
        _31182 = 1;
    }
    if (IS_SEQUENCE(_36known_files_14982)){
            _31183 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31183 = 1;
    }
    if (_31182 >= _31183)
    goto L2; // [98] 129

    /** 		toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _31185 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _31185 = 1;
    }
    if (IS_SEQUENCE(_38toplevel_references_61056)){
            _31186 = SEQ_PTR(_38toplevel_references_61056)->length;
    }
    else {
        _31186 = 1;
    }
    _31187 = _31185 - _31186;
    _31185 = NOVALUE;
    _31186 = NOVALUE;
    _31188 = Repeat(_21815, _31187);
    _31187 = NOVALUE;
    Concat((object_ptr)&_38toplevel_references_61056, _38toplevel_references_61056, _31188);
    DeRefDS(_31188);
    _31188 = NOVALUE;
L2: 

    /** 	for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_38active_subprogs_61054)){
            _31190 = SEQ_PTR(_38active_subprogs_61054)->length;
    }
    else {
        _31190 = 1;
    }
    {
        int _i_62491;
        _i_62491 = 1;
L3: 
        if (_i_62491 > _31190){
            goto L4; // [136] 280
        }

        /** 		if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (int)SEQ_PTR(_38active_subprogs_61054);
        _31191 = (int)*(((s1_ptr)_2)->base + _i_62491);
        if (IS_SEQUENCE(_31191)){
                _31192 = SEQ_PTR(_31191)->length;
        }
        else {
            _31192 = 1;
        }
        _31191 = NOVALUE;
        if (_31192 != 0) {
            _31193 = 1;
            goto L5; // [154] 171
        }
        _2 = (int)SEQ_PTR(_38toplevel_references_61056);
        _31194 = (int)*(((s1_ptr)_2)->base + _i_62491);
        if (IS_SEQUENCE(_31194)){
                _31195 = SEQ_PTR(_31194)->length;
        }
        else {
            _31195 = 1;
        }
        _31194 = NOVALUE;
        _31193 = (_31195 != 0);
L5: 
        if (_31193 == 0) {
            goto L6; // [171] 273
        }
        _31197 = (_i_62491 == _35current_file_no_15968);
        if (_31197 != 0) {
            _31198 = 1;
            goto L7; // [181] 195
        }
        _2 = (int)SEQ_PTR(_36finished_files_14984);
        _31199 = (int)*(((s1_ptr)_2)->base + _i_62491);
        _31198 = (_31199 != 0);
L7: 
        if (_31198 != 0) {
            DeRef(_31200);
            _31200 = 1;
            goto L8; // [195] 203
        }
        _31200 = (_unincluded_ok_62459 != 0);
L8: 
        if (_31200 == 0)
        {
            _31200 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31200 = NOVALUE;
        }

        /** 			for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (int)SEQ_PTR(_38active_references_61055);
        _31201 = (int)*(((s1_ptr)_2)->base + _i_62491);
        if (IS_SEQUENCE(_31201)){
                _31202 = SEQ_PTR(_31201)->length;
        }
        else {
            _31202 = 1;
        }
        _31201 = NOVALUE;
        {
            int _j_62507;
            _j_62507 = _31202;
L9: 
            if (_j_62507 < 1){
                goto LA; // [218] 254
            }

            /** 				errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (int)SEQ_PTR(_38active_references_61055);
            _31203 = (int)*(((s1_ptr)_2)->base + _i_62491);
            _2 = (int)SEQ_PTR(_31203);
            _31204 = (int)*(((s1_ptr)_2)->base + _j_62507);
            _31203 = NOVALUE;
            Ref(_31204);
            _31205 = _38resolve_file(_31204, _report_errors_62457, _unincluded_ok_62459);
            _31204 = NOVALUE;
            if (IS_SEQUENCE(_errors_62458) && IS_ATOM(_31205)) {
                Ref(_31205);
                Append(&_errors_62458, _errors_62458, _31205);
            }
            else if (IS_ATOM(_errors_62458) && IS_SEQUENCE(_31205)) {
            }
            else {
                Concat((object_ptr)&_errors_62458, _errors_62458, _31205);
            }
            DeRef(_31205);
            _31205 = NOVALUE;

            /** 			end for*/
            _j_62507 = _j_62507 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** 			errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (int)SEQ_PTR(_38toplevel_references_61056);
        _31207 = (int)*(((s1_ptr)_2)->base + _i_62491);
        Ref(_31207);
        _31208 = _38resolve_file(_31207, _report_errors_62457, _unincluded_ok_62459);
        _31207 = NOVALUE;
        if (IS_SEQUENCE(_errors_62458) && IS_ATOM(_31208)) {
            Ref(_31208);
            Append(&_errors_62458, _errors_62458, _31208);
        }
        else if (IS_ATOM(_errors_62458) && IS_SEQUENCE(_31208)) {
        }
        else {
            Concat((object_ptr)&_errors_62458, _errors_62458, _31208);
        }
        DeRef(_31208);
        _31208 = NOVALUE;
L6: 

        /** 	end for*/
        _i_62491 = _i_62491 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** 	if report_errors and length( errors ) then*/
    if (_report_errors_62457 == 0) {
        goto LB; // [282] 854
    }
    if (IS_SEQUENCE(_errors_62458)){
            _31211 = SEQ_PTR(_errors_62458)->length;
    }
    else {
        _31211 = 1;
    }
    if (_31211 == 0)
    {
        _31211 = NOVALUE;
        goto LB; // [290] 854
    }
    else{
        _31211 = NOVALUE;
    }

    /** 		sequence msg = ""*/
    RefDS(_21815);
    DeRefi(_msg_62520);
    _msg_62520 = _21815;

    /** 		sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31212);
    DeRefi(_errloc_62521);
    _errloc_62521 = _31212;

    /** 		for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_62458)){
            _31213 = SEQ_PTR(_errors_62458)->length;
    }
    else {
        _31213 = 1;
    }
    {
        int _e_62524;
        _e_62524 = _31213;
LC: 
        if (_e_62524 < 1){
            goto LD; // [312] 828
        }

        /** 			sequence ref = forward_references[errors[e]]*/
        _2 = (int)SEQ_PTR(_errors_62458);
        _31214 = (int)*(((s1_ptr)_2)->base + _e_62524);
        DeRef(_ref_62526);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!IS_ATOM_INT(_31214)){
            _ref_62526 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31214)->dbl));
        }
        else{
            _ref_62526 = (int)*(((s1_ptr)_2)->base + _31214);
        }
        Ref(_ref_62526);

        /** 			if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (int)SEQ_PTR(_ref_62526);
        _31216 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31216)) {
            _31217 = (_31216 == 65);
        }
        else {
            _31217 = binary_op(EQUALS, _31216, 65);
        }
        _31216 = NOVALUE;
        if (IS_ATOM_INT(_31217)) {
            if (_31217 == 0) {
                DeRef(_31218);
                _31218 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31217)->dbl == 0.0) {
                DeRef(_31218);
                _31218 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (int)SEQ_PTR(_ref_62526);
        _31219 = (int)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31219)) {
            _31220 = (_31219 == 65);
        }
        else {
            _31220 = binary_op(EQUALS, _31219, 65);
        }
        _31219 = NOVALUE;
        DeRef(_31218);
        if (IS_ATOM_INT(_31220))
        _31218 = (_31220 != 0);
        else
        _31218 = DBL_PTR(_31220)->dbl != 0.0;
LE: 
        if (_31218 != 0) {
            goto LF; // [363] 382
        }
        _2 = (int)SEQ_PTR(_ref_62526);
        _31222 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31222)) {
            _31223 = (_31222 == 109);
        }
        else {
            _31223 = binary_op(EQUALS, _31222, 109);
        }
        _31222 = NOVALUE;
        if (_31223 == 0) {
            DeRef(_31223);
            _31223 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31223) && DBL_PTR(_31223)->dbl == 0.0){
                DeRef(_31223);
                _31223 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31223);
            _31223 = NOVALUE;
        }
        DeRef(_31223);
        _31223 = NOVALUE;
LF: 

        /** 				continue*/
        DeRef(_ref_62526);
        _ref_62526 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** 				object tok = find_reference(ref)*/
        RefDS(_ref_62526);
        _0 = _tok_62542;
        _tok_62542 = _38find_reference(_ref_62526);
        DeRef(_0);

        /** 				integer THIS_SCOPE = 3*/
        _THIS_SCOPE_62544 = 3;

        /** 				integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_62545 = 4;

        /** 				if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62542);
        _31225 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31225, 509)){
            _31225 = NOVALUE;
            goto L13; // [417] 760
        }
        _31225 = NOVALUE;

        /** 					switch tok[THIS_SCOPE] do*/
        _2 = (int)SEQ_PTR(_tok_62542);
        _31227 = (int)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31227) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31227)){
            if( (DBL_PTR(_31227)->dbl != (double) ((int) DBL_PTR(_31227)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (int) DBL_PTR(_31227)->dbl;
        }
        else {
            _0 = _31227;
        };
        _31227 = NOVALUE;
        switch ( _0 ){ 

            /** 						case SC_UNDEFINED then*/
            case 9:

            /** 							if ref[FR_QUALIFIED] != -1 then*/
            _2 = (int)SEQ_PTR(_ref_62526);
            _31230 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31230, -1)){
                _31230 = NOVALUE;
                goto L15; // [442] 556
            }
            _31230 = NOVALUE;

            /** 								if ref[FR_QUALIFIED] > 0 then*/
            _2 = (int)SEQ_PTR(_ref_62526);
            _31232 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31232, 0)){
                _31232 = NOVALUE;
                goto L16; // [452] 517
            }
            _31232 = NOVALUE;

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (int)SEQ_PTR(_ref_62526);
            _31235 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62526);
            _31236 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_14982);
            if (!IS_ATOM_INT(_31236)){
                _31237 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31236)->dbl));
            }
            else{
                _31237 = (int)*(((s1_ptr)_2)->base + _31236);
            }
            Ref(_31237);
            RefDS(_21815);
            _31238 = _17abbreviate_path(_31237, _21815);
            _31237 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62526);
            _31239 = (int)*(((s1_ptr)_2)->base + 6);
            _2 = (int)SEQ_PTR(_ref_62526);
            _31240 = (int)*(((s1_ptr)_2)->base + 9);
            _2 = (int)SEQ_PTR(_36known_files_14982);
            if (!IS_ATOM_INT(_31240)){
                _31241 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31240)->dbl));
            }
            else{
                _31241 = (int)*(((s1_ptr)_2)->base + _31240);
            }
            Ref(_31241);
            RefDS(_21815);
            _31242 = _17abbreviate_path(_31241, _21815);
            _31241 = NOVALUE;
            _31243 = _16find_replace(92, _31242, 47, 0);
            _31242 = NOVALUE;
            _1 = NewS1(4);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31235);
            *((int *)(_2+4)) = _31235;
            *((int *)(_2+8)) = _31238;
            Ref(_31239);
            *((int *)(_2+12)) = _31239;
            *((int *)(_2+16)) = _31243;
            _31244 = MAKE_SEQ(_1);
            _31243 = NOVALUE;
            _31239 = NOVALUE;
            _31238 = NOVALUE;
            _31235 = NOVALUE;
            DeRefi(_errloc_62521);
            _errloc_62521 = EPrintf(-9999999, _31234, _31244);
            DeRefDS(_31244);
            _31244 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (int)SEQ_PTR(_ref_62526);
            _31247 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62526);
            _31248 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_14982);
            if (!IS_ATOM_INT(_31248)){
                _31249 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31248)->dbl));
            }
            else{
                _31249 = (int)*(((s1_ptr)_2)->base + _31248);
            }
            Ref(_31249);
            RefDS(_21815);
            _31250 = _17abbreviate_path(_31249, _21815);
            _31249 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62526);
            _31251 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31247);
            *((int *)(_2+4)) = _31247;
            *((int *)(_2+8)) = _31250;
            Ref(_31251);
            *((int *)(_2+12)) = _31251;
            _31252 = MAKE_SEQ(_1);
            _31251 = NOVALUE;
            _31250 = NOVALUE;
            _31247 = NOVALUE;
            DeRefi(_errloc_62521);
            _errloc_62521 = EPrintf(-9999999, _31246, _31252);
            DeRefDS(_31252);
            _31252 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** 								errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (int)SEQ_PTR(_ref_62526);
            _31255 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62526);
            _31256 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_14982);
            if (!IS_ATOM_INT(_31256)){
                _31257 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31256)->dbl));
            }
            else{
                _31257 = (int)*(((s1_ptr)_2)->base + _31256);
            }
            Ref(_31257);
            RefDS(_21815);
            _31258 = _17abbreviate_path(_31257, _21815);
            _31257 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62526);
            _31259 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31255);
            *((int *)(_2+4)) = _31255;
            *((int *)(_2+8)) = _31258;
            Ref(_31259);
            *((int *)(_2+12)) = _31259;
            _31260 = MAKE_SEQ(_1);
            _31259 = NOVALUE;
            _31258 = NOVALUE;
            _31255 = NOVALUE;
            DeRefi(_errloc_62521);
            _errloc_62521 = EPrintf(-9999999, _31254, _31260);
            DeRefDS(_31260);
            _31260 = NOVALUE;
            goto L17; // [592] 759

            /** 						case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** 							sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_62603);
            _2 = (int)SEQ_PTR(_tok_62542);
            _syms_62603 = (int)*(((s1_ptr)_2)->base + _THESE_GLOBALS_62545);
            Ref(_syms_62603);

            /** 							syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31264 = CRoutineId(1336, 38, _31263);
            RefDS(_syms_62603);
            RefDS(_21815);
            _0 = _syms_62603;
            _syms_62603 = _24custom_sort(_31264, _syms_62603, _21815, 1);
            DeRefDS(_0);
            _31264 = NOVALUE;

            /** 							errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (int)SEQ_PTR(_ref_62526);
            _31267 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62526);
            _31268 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_36known_files_14982);
            if (!IS_ATOM_INT(_31268)){
                _31269 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31268)->dbl));
            }
            else{
                _31269 = (int)*(((s1_ptr)_2)->base + _31268);
            }
            Ref(_31269);
            RefDS(_21815);
            _31270 = _17abbreviate_path(_31269, _21815);
            _31269 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62526);
            _31271 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31267);
            *((int *)(_2+4)) = _31267;
            *((int *)(_2+8)) = _31270;
            Ref(_31271);
            *((int *)(_2+12)) = _31271;
            _31272 = MAKE_SEQ(_1);
            _31271 = NOVALUE;
            _31270 = NOVALUE;
            _31267 = NOVALUE;
            DeRefi(_errloc_62521);
            _errloc_62521 = EPrintf(-9999999, _31266, _31272);
            DeRefDS(_31272);
            _31272 = NOVALUE;

            /** 							for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_62603)){
                    _31274 = SEQ_PTR(_syms_62603)->length;
            }
            else {
                _31274 = 1;
            }
            {
                int _si_62621;
                _si_62621 = 1;
L18: 
                if (_si_62621 > _31274){
                    goto L19; // [664] 750
                }

                /** 								symtab_index s = syms[si] */
                _2 = (int)SEQ_PTR(_syms_62603);
                _s_62624 = (int)*(((s1_ptr)_2)->base + _si_62621);
                if (!IS_ATOM_INT(_s_62624)){
                    _s_62624 = (long)DBL_PTR(_s_62624)->dbl;
                }

                /** 								if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (int)SEQ_PTR(_ref_62526);
                _31276 = (int)*(((s1_ptr)_2)->base + 2);
                _31277 = _53sym_name(_s_62624);
                if (_31276 == _31277)
                _31278 = 1;
                else if (IS_ATOM_INT(_31276) && IS_ATOM_INT(_31277))
                _31278 = 0;
                else
                _31278 = (compare(_31276, _31277) == 0);
                _31276 = NOVALUE;
                DeRef(_31277);
                _31277 = NOVALUE;
                if (_31278 == 0)
                {
                    _31278 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31278 = NOVALUE;
                }

                /** 									errloc &= sprintf("\t\tin %s\n", */
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _31280 = (int)*(((s1_ptr)_2)->base + _s_62624);
                _2 = (int)SEQ_PTR(_31280);
                if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
                    _31281 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
                }
                else{
                    _31281 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
                }
                _31280 = NOVALUE;
                _2 = (int)SEQ_PTR(_36known_files_14982);
                if (!IS_ATOM_INT(_31281)){
                    _31282 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31281)->dbl));
                }
                else{
                    _31282 = (int)*(((s1_ptr)_2)->base + _31281);
                }
                Ref(_31282);
                RefDS(_21815);
                _31283 = _17abbreviate_path(_31282, _21815);
                _31282 = NOVALUE;
                _31284 = _16find_replace(92, _31283, 47, 0);
                _31283 = NOVALUE;
                _1 = NewS1(1);
                _2 = (int)((s1_ptr)_1)->base;
                *((int *)(_2+4)) = _31284;
                _31285 = MAKE_SEQ(_1);
                _31284 = NOVALUE;
                _31286 = EPrintf(-9999999, _31279, _31285);
                DeRefDS(_31285);
                _31285 = NOVALUE;
                Concat((object_ptr)&_errloc_62521, _errloc_62521, _31286);
                DeRefDS(_31286);
                _31286 = NOVALUE;
L1A: 

                /** 							end for*/
                _si_62621 = _si_62621 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_62603);
            _syms_62603 = NOVALUE;
            goto L17; // [752] 759

            /** 						case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** 				if not match(errloc, msg) then*/
        _31288 = e_match_from(_errloc_62521, _msg_62520, 1);
        if (_31288 != 0)
        goto L1B; // [767] 786
        _31288 = NOVALUE;

        /** 					msg &= errloc*/
        Concat((object_ptr)&_msg_62520, _msg_62520, _errloc_62521);

        /** 					prep_forward_error( errors[e] )*/
        _2 = (int)SEQ_PTR(_errors_62458);
        _31291 = (int)*(((s1_ptr)_2)->base + _e_62524);
        Ref(_31291);
        _38prep_forward_error(_31291);
        _31291 = NOVALUE;
L1B: 
        DeRef(_tok_62542);
        _tok_62542 = NOVALUE;
L12: 

        /** 			ThisLine    = ref[FR_THISLINE]*/
        DeRef(_44ThisLine_48142);
        _2 = (int)SEQ_PTR(_ref_62526);
        _44ThisLine_48142 = (int)*(((s1_ptr)_2)->base + 7);
        Ref(_44ThisLine_48142);

        /** 			bp          = ref[FR_BP]*/
        _2 = (int)SEQ_PTR(_ref_62526);
        _44bp_48146 = (int)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_44bp_48146)){
            _44bp_48146 = (long)DBL_PTR(_44bp_48146)->dbl;
        }

        /** 			CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_ref_62526);
        _35CurrentSub_15976 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_35CurrentSub_15976)){
            _35CurrentSub_15976 = (long)DBL_PTR(_35CurrentSub_15976)->dbl;
        }

        /** 			line_number = ref[FR_LINE]*/
        _2 = (int)SEQ_PTR(_ref_62526);
        _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_35line_number_15969)){
            _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
        }
        DeRefDS(_ref_62526);
        _ref_62526 = NOVALUE;

        /** 		end for*/
L11: 
        _e_62524 = _e_62524 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** 		if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_62520)){
            _31296 = SEQ_PTR(_msg_62520)->length;
    }
    else {
        _31296 = 1;
    }
    if (_31296 <= 0)
    goto L1C; // [833] 849

    /** 			CompileErr( 74, {msg} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_62520);
    *((int *)(_2+4)) = _msg_62520;
    _31298 = MAKE_SEQ(_1);
    _44CompileErr(74, _31298, 0);
    _31298 = NOVALUE;
L1C: 
    DeRefi(_msg_62520);
    _msg_62520 = NOVALUE;
    DeRefi(_errloc_62521);
    _errloc_62521 = NOVALUE;
    goto L1D; // [851] 889
LB: 

    /** 	elsif report_errors then*/
    if (_report_errors_62457 == 0)
    {
        goto L1E; // [856] 888
    }
    else{
    }

    /** 		forward_references  = {}*/
    RefDS(_21815);
    DeRef(_38forward_references_61053);
    _38forward_references_61053 = _21815;

    /** 		active_references   = {}*/
    RefDS(_21815);
    DeRef(_38active_references_61055);
    _38active_references_61055 = _21815;

    /** 		toplevel_references = {}*/
    RefDS(_21815);
    DeRef(_38toplevel_references_61056);
    _38toplevel_references_61056 = _21815;

    /** 		inactive_references = {}*/
    RefDS(_21815);
    DeRef(_38inactive_references_61057);
    _38inactive_references_61057 = _21815;
L1E: 
L1D: 

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    DeRef(_errors_62458);
    _31191 = NOVALUE;
    _31194 = NOVALUE;
    DeRef(_31197);
    _31197 = NOVALUE;
    _31199 = NOVALUE;
    _31201 = NOVALUE;
    _31214 = NOVALUE;
    _31281 = NOVALUE;
    DeRef(_31217);
    _31217 = NOVALUE;
    DeRef(_31220);
    _31220 = NOVALUE;
    _31236 = NOVALUE;
    _31248 = NOVALUE;
    _31256 = NOVALUE;
    _31240 = NOVALUE;
    _31268 = NOVALUE;
    return;
    ;
}


void _38shift_these(int _refs_62668, int _pc_62669, int _amount_62670)
{
    int _fr_62674 = NOVALUE;
    int _31316 = NOVALUE;
    int _31315 = NOVALUE;
    int _31314 = NOVALUE;
    int _31313 = NOVALUE;
    int _31312 = NOVALUE;
    int _31311 = NOVALUE;
    int _31310 = NOVALUE;
    int _31309 = NOVALUE;
    int _31308 = NOVALUE;
    int _31307 = NOVALUE;
    int _31305 = NOVALUE;
    int _31303 = NOVALUE;
    int _31302 = NOVALUE;
    int _31300 = NOVALUE;
    int _31299 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62668)){
            _31299 = SEQ_PTR(_refs_62668)->length;
    }
    else {
        _31299 = 1;
    }
    {
        int _i_62672;
        _i_62672 = _31299;
L1: 
        if (_i_62672 < 1){
            goto L2; // [12] 147
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_62668);
        _31300 = (int)*(((s1_ptr)_2)->base + _i_62672);
        DeRef(_fr_62674);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!IS_ATOM_INT(_31300)){
            _fr_62674 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31300)->dbl));
        }
        else{
            _fr_62674 = (int)*(((s1_ptr)_2)->base + _31300);
        }
        Ref(_fr_62674);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_62668);
        _31302 = (int)*(((s1_ptr)_2)->base + _i_62672);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31302))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31302)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31302);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (int)SEQ_PTR(_fr_62674);
        _31303 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31303, _38shifting_sub_61072)){
            _31303 = NOVALUE;
            goto L3; // [53] 126
        }
        _31303 = NOVALUE;

        /** 			if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_62674);
        _31305 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31305, _pc_62669)){
            _31305 = NOVALUE;
            goto L4; // [63] 125
        }
        _31305 = NOVALUE;

        /** 				fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_62674);
        _31307 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31307)) {
            _31308 = _31307 + _amount_62670;
            if ((long)((unsigned long)_31308 + (unsigned long)HIGH_BITS) >= 0) 
            _31308 = NewDouble((double)_31308);
        }
        else {
            _31308 = binary_op(PLUS, _31307, _amount_62670);
        }
        _31307 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62674);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62674 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31308;
        if( _1 != _31308 ){
            DeRef(_1);
        }
        _31308 = NOVALUE;

        /** 				if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_62674);
        _31309 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31309)) {
            _31310 = (_31309 == 186);
        }
        else {
            _31310 = binary_op(EQUALS, _31309, 186);
        }
        _31309 = NOVALUE;
        if (IS_ATOM_INT(_31310)) {
            if (_31310 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31310)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (int)SEQ_PTR(_fr_62674);
        _31312 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31312)) {
            _31313 = (_31312 >= _pc_62669);
        }
        else {
            _31313 = binary_op(GREATEREQ, _31312, _pc_62669);
        }
        _31312 = NOVALUE;
        if (_31313 == 0) {
            DeRef(_31313);
            _31313 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31313) && DBL_PTR(_31313)->dbl == 0.0){
                DeRef(_31313);
                _31313 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31313);
            _31313 = NOVALUE;
        }
        DeRef(_31313);
        _31313 = NOVALUE;

        /** 					fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_62674);
        _31314 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31314)) {
            _31315 = _31314 + _amount_62670;
            if ((long)((unsigned long)_31315 + (unsigned long)HIGH_BITS) >= 0) 
            _31315 = NewDouble((double)_31315);
        }
        else {
            _31315 = binary_op(PLUS, _31314, _amount_62670);
        }
        _31314 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62674);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62674 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31315;
        if( _1 != _31315 ){
            DeRef(_1);
        }
        _31315 = NOVALUE;
L5: 
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_62668);
        _31316 = (int)*(((s1_ptr)_2)->base + _i_62672);
        RefDS(_fr_62674);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31316))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31316)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31316);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_62674;
        DeRef(_1);
        DeRefDS(_fr_62674);
        _fr_62674 = NOVALUE;

        /** 	end for*/
        _i_62672 = _i_62672 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_62668);
    _31300 = NOVALUE;
    _31302 = NOVALUE;
    _31316 = NOVALUE;
    DeRef(_31310);
    _31310 = NOVALUE;
    return;
    ;
}


void _38shift_top(int _refs_62698, int _pc_62699, int _amount_62700)
{
    int _fr_62704 = NOVALUE;
    int _31332 = NOVALUE;
    int _31331 = NOVALUE;
    int _31330 = NOVALUE;
    int _31329 = NOVALUE;
    int _31328 = NOVALUE;
    int _31327 = NOVALUE;
    int _31326 = NOVALUE;
    int _31325 = NOVALUE;
    int _31324 = NOVALUE;
    int _31323 = NOVALUE;
    int _31321 = NOVALUE;
    int _31320 = NOVALUE;
    int _31318 = NOVALUE;
    int _31317 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62698)){
            _31317 = SEQ_PTR(_refs_62698)->length;
    }
    else {
        _31317 = 1;
    }
    {
        int _i_62702;
        _i_62702 = _31317;
L1: 
        if (_i_62702 < 1){
            goto L2; // [12] 134
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_62698);
        _31318 = (int)*(((s1_ptr)_2)->base + _i_62702);
        DeRef(_fr_62704);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!IS_ATOM_INT(_31318)){
            _fr_62704 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31318)->dbl));
        }
        else{
            _fr_62704 = (int)*(((s1_ptr)_2)->base + _31318);
        }
        Ref(_fr_62704);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_62698);
        _31320 = (int)*(((s1_ptr)_2)->base + _i_62702);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31320))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31320)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31320);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_62704);
        _31321 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31321, _pc_62699)){
            _31321 = NOVALUE;
            goto L3; // [51] 113
        }
        _31321 = NOVALUE;

        /** 			fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_62704);
        _31323 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31323)) {
            _31324 = _31323 + _amount_62700;
            if ((long)((unsigned long)_31324 + (unsigned long)HIGH_BITS) >= 0) 
            _31324 = NewDouble((double)_31324);
        }
        else {
            _31324 = binary_op(PLUS, _31323, _amount_62700);
        }
        _31323 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31324;
        if( _1 != _31324 ){
            DeRef(_1);
        }
        _31324 = NOVALUE;

        /** 			if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_62704);
        _31325 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31325)) {
            _31326 = (_31325 == 186);
        }
        else {
            _31326 = binary_op(EQUALS, _31325, 186);
        }
        _31325 = NOVALUE;
        if (IS_ATOM_INT(_31326)) {
            if (_31326 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31326)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (int)SEQ_PTR(_fr_62704);
        _31328 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31328)) {
            _31329 = (_31328 >= _pc_62699);
        }
        else {
            _31329 = binary_op(GREATEREQ, _31328, _pc_62699);
        }
        _31328 = NOVALUE;
        if (_31329 == 0) {
            DeRef(_31329);
            _31329 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31329) && DBL_PTR(_31329)->dbl == 0.0){
                DeRef(_31329);
                _31329 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31329);
            _31329 = NOVALUE;
        }
        DeRef(_31329);
        _31329 = NOVALUE;

        /** 				fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_62704);
        _31330 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31330)) {
            _31331 = _31330 + _amount_62700;
            if ((long)((unsigned long)_31331 + (unsigned long)HIGH_BITS) >= 0) 
            _31331 = NewDouble((double)_31331);
        }
        else {
            _31331 = binary_op(PLUS, _31330, _amount_62700);
        }
        _31330 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31331;
        if( _1 != _31331 ){
            DeRef(_1);
        }
        _31331 = NOVALUE;
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_62698);
        _31332 = (int)*(((s1_ptr)_2)->base + _i_62702);
        RefDS(_fr_62704);
        _2 = (int)SEQ_PTR(_38forward_references_61053);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38forward_references_61053 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31332))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31332)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31332);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_62704;
        DeRef(_1);
        DeRefDS(_fr_62704);
        _fr_62704 = NOVALUE;

        /** 	end for*/
        _i_62702 = _i_62702 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_62698);
    _31318 = NOVALUE;
    _31320 = NOVALUE;
    _31332 = NOVALUE;
    DeRef(_31326);
    _31326 = NOVALUE;
    return;
    ;
}


void _38shift_fwd_refs(int _pc_62725, int _amount_62726)
{
    int _file_62737 = NOVALUE;
    int _sp_62742 = NOVALUE;
    int _31342 = NOVALUE;
    int _31341 = NOVALUE;
    int _31339 = NOVALUE;
    int _31337 = NOVALUE;
    int _31336 = NOVALUE;
    int _31335 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_62725)) {
        _1 = (long)(DBL_PTR(_pc_62725)->dbl);
        DeRefDS(_pc_62725);
        _pc_62725 = _1;
    }
    if (!IS_ATOM_INT(_amount_62726)) {
        _1 = (long)(DBL_PTR(_amount_62726)->dbl);
        DeRefDS(_amount_62726);
        _amount_62726 = _1;
    }

    /** 	if not shifting_sub then*/
    if (_38shifting_sub_61072 != 0)
    goto L1; // [9] 18

    /** 		return*/
    return;
L1: 

    /** 	if shifting_sub = TopLevelSub then*/
    if (_38shifting_sub_61072 != _35TopLevelSub_15975)
    goto L2; // [24] 65

    /** 		for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_38toplevel_references_61056)){
            _31335 = SEQ_PTR(_38toplevel_references_61056)->length;
    }
    else {
        _31335 = 1;
    }
    {
        int _file_62733;
        _file_62733 = 1;
L3: 
        if (_file_62733 > _31335){
            goto L4; // [35] 62
        }

        /** 			shift_top( toplevel_references[file], pc, amount )*/
        _2 = (int)SEQ_PTR(_38toplevel_references_61056);
        _31336 = (int)*(((s1_ptr)_2)->base + _file_62733);
        Ref(_31336);
        _38shift_top(_31336, _pc_62725, _amount_62726);
        _31336 = NOVALUE;

        /** 		end for*/
        _file_62733 = _file_62733 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** 		integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _31337 = (int)*(((s1_ptr)_2)->base + _38shifting_sub_61072);
    _2 = (int)SEQ_PTR(_31337);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _file_62737 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _file_62737 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (!IS_ATOM_INT(_file_62737)){
        _file_62737 = (long)DBL_PTR(_file_62737)->dbl;
    }
    _31337 = NOVALUE;

    /** 		integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_38active_subprogs_61054);
    _31339 = (int)*(((s1_ptr)_2)->base + _file_62737);
    _sp_62742 = find_from(_38shifting_sub_61072, _31339, 1);
    _31339 = NOVALUE;

    /** 		shift_these( active_references[file][sp], pc, amount )*/
    _2 = (int)SEQ_PTR(_38active_references_61055);
    _31341 = (int)*(((s1_ptr)_2)->base + _file_62737);
    _2 = (int)SEQ_PTR(_31341);
    _31342 = (int)*(((s1_ptr)_2)->base + _sp_62742);
    _31341 = NOVALUE;
    Ref(_31342);
    _38shift_these(_31342, _pc_62725, _amount_62726);
    _31342 = NOVALUE;
L5: 

    /** end procedure*/
    return;
    ;
}



// 0xDE6A62A9
