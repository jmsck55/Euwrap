// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _46get_text(int _MsgNum_19761, int _LocalQuals_19762, int _DBBase_19763)
{
    int _db_res_19765 = NOVALUE;
    int _lMsgText_19766 = NOVALUE;
    int _dbname_19767 = NOVALUE;
    int _11041 = NOVALUE;
    int _11039 = NOVALUE;
    int _11037 = NOVALUE;
    int _11036 = NOVALUE;
    int _11035 = NOVALUE;
    int _11033 = NOVALUE;
    int _11032 = NOVALUE;
    int _11031 = NOVALUE;
    int _11025 = NOVALUE;
    int _11024 = NOVALUE;
    int _11023 = NOVALUE;
    int _11016 = NOVALUE;
    int _11013 = NOVALUE;
    int _11011 = NOVALUE;
    int _11009 = NOVALUE;
    int _11008 = NOVALUE;
    int _11007 = NOVALUE;
    int _11006 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db_res = -1*/
    _db_res_19765 = -1;

    /** 	lMsgText = 0*/
    DeRef(_lMsgText_19766);
    _lMsgText_19766 = 0;

    /** 	if string(LocalQuals) and length(LocalQuals) > 0 then*/
    RefDS(_LocalQuals_19762);
    _11006 = _13string(_LocalQuals_19762);
    if (IS_ATOM_INT(_11006)) {
        if (_11006 == 0) {
            goto L1; // [23] 45
        }
    }
    else {
        if (DBL_PTR(_11006)->dbl == 0.0) {
            goto L1; // [23] 45
        }
    }
    if (IS_SEQUENCE(_LocalQuals_19762)){
            _11008 = SEQ_PTR(_LocalQuals_19762)->length;
    }
    else {
        _11008 = 1;
    }
    _11009 = (_11008 > 0);
    _11008 = NOVALUE;
    if (_11009 == 0)
    {
        DeRef(_11009);
        _11009 = NOVALUE;
        goto L1; // [35] 45
    }
    else{
        DeRef(_11009);
        _11009 = NOVALUE;
    }

    /** 		LocalQuals = {LocalQuals}*/
    _0 = _LocalQuals_19762;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_LocalQuals_19762);
    *((int *)(_2+4)) = _LocalQuals_19762;
    _LocalQuals_19762 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1: 

    /** 	for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19762)){
            _11011 = SEQ_PTR(_LocalQuals_19762)->length;
    }
    else {
        _11011 = 1;
    }
    {
        int _i_19776;
        _i_19776 = 1;
L2: 
        if (_i_19776 > _11011){
            goto L3; // [50] 136
        }

        /** 		dbname = DBBase & "_" & LocalQuals[i] & ".edb"*/
        _2 = (int)SEQ_PTR(_LocalQuals_19762);
        _11013 = (int)*(((s1_ptr)_2)->base + _i_19776);
        {
            int concat_list[4];

            concat_list[0] = _11014;
            concat_list[1] = _11013;
            concat_list[2] = _11012;
            concat_list[3] = _DBBase_19763;
            Concat_N((object_ptr)&_dbname_19767, concat_list, 4);
        }
        _11013 = NOVALUE;

        /** 		db_res = eds:db_select( filesys:locate_file( dbname ), eds:DB_LOCK_READ_ONLY)*/
        RefDS(_dbname_19767);
        RefDS(_5);
        RefDS(_5);
        _11016 = _17locate_file(_dbname_19767, _5, _5);
        _db_res_19765 = _49db_select(_11016, 3);
        _11016 = NOVALUE;
        if (!IS_ATOM_INT(_db_res_19765)) {
            _1 = (long)(DBL_PTR(_db_res_19765)->dbl);
            DeRefDS(_db_res_19765);
            _db_res_19765 = _1;
        }

        /** 		if db_res = eds:DB_OK then*/
        if (_db_res_19765 != 0)
        goto L4; // [87] 129

        /** 			db_res = eds:db_select_table("1")*/
        RefDS(_11019);
        _db_res_19765 = _49db_select_table(_11019);
        if (!IS_ATOM_INT(_db_res_19765)) {
            _1 = (long)(DBL_PTR(_db_res_19765)->dbl);
            DeRefDS(_db_res_19765);
            _db_res_19765 = _1;
        }

        /** 			if db_res = eds:DB_OK then*/
        if (_db_res_19765 != 0)
        goto L5; // [101] 128

        /** 				lMsgText = eds:db_fetch_record(MsgNum)*/
        RefDS(_49current_table_name_17056);
        _0 = _lMsgText_19766;
        _lMsgText_19766 = _49db_fetch_record(_MsgNum_19761, _49current_table_name_17056);
        DeRef(_0);

        /** 				if sequence(lMsgText) then*/
        _11023 = IS_SEQUENCE(_lMsgText_19766);
        if (_11023 == 0)
        {
            _11023 = NOVALUE;
            goto L6; // [119] 127
        }
        else{
            _11023 = NOVALUE;
        }

        /** 					exit*/
        goto L3; // [124] 136
L6: 
L5: 
L4: 

        /** 	end for*/
        _i_19776 = _i_19776 + 1;
        goto L2; // [131] 57
L3: 
        ;
    }

    /** 	if atom(lMsgText) then*/
    _11024 = IS_ATOM(_lMsgText_19766);
    if (_11024 == 0)
    {
        _11024 = NOVALUE;
        goto L7; // [141] 281
    }
    else{
        _11024 = NOVALUE;
    }

    /** 		dbname = filesys:locate_file( DBBase & ".edb" )*/
    Concat((object_ptr)&_11025, _DBBase_19763, _11014);
    RefDS(_5);
    RefDS(_5);
    _0 = _dbname_19767;
    _dbname_19767 = _17locate_file(_11025, _5, _5);
    DeRef(_0);
    _11025 = NOVALUE;

    /** 		db_res = eds:db_select(	dbname, DB_LOCK_READ_ONLY)*/
    RefDS(_dbname_19767);
    _db_res_19765 = _49db_select(_dbname_19767, 3);
    if (!IS_ATOM_INT(_db_res_19765)) {
        _1 = (long)(DBL_PTR(_db_res_19765)->dbl);
        DeRefDS(_db_res_19765);
        _db_res_19765 = _1;
    }

    /** 		if db_res = eds:DB_OK then*/
    if (_db_res_19765 != 0)
    goto L8; // [171] 280

    /** 			db_res = eds:db_select_table("1")*/
    RefDS(_11019);
    _db_res_19765 = _49db_select_table(_11019);
    if (!IS_ATOM_INT(_db_res_19765)) {
        _1 = (long)(DBL_PTR(_db_res_19765)->dbl);
        DeRefDS(_db_res_19765);
        _db_res_19765 = _1;
    }

    /** 			if db_res = eds:DB_OK then*/
    if (_db_res_19765 != 0)
    goto L9; // [185] 279

    /** 				for i = 1 to length(LocalQuals) do*/
    if (IS_SEQUENCE(_LocalQuals_19762)){
            _11031 = SEQ_PTR(_LocalQuals_19762)->length;
    }
    else {
        _11031 = 1;
    }
    {
        int _i_19805;
        _i_19805 = 1;
LA: 
        if (_i_19805 > _11031){
            goto LB; // [194] 238
        }

        /** 					lMsgText = eds:db_fetch_record({LocalQuals[i],MsgNum})*/
        _2 = (int)SEQ_PTR(_LocalQuals_19762);
        _11032 = (int)*(((s1_ptr)_2)->base + _i_19805);
        Ref(_11032);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _11032;
        ((int *)_2)[2] = _MsgNum_19761;
        _11033 = MAKE_SEQ(_1);
        _11032 = NOVALUE;
        RefDS(_49current_table_name_17056);
        _0 = _lMsgText_19766;
        _lMsgText_19766 = _49db_fetch_record(_11033, _49current_table_name_17056);
        DeRef(_0);
        _11033 = NOVALUE;

        /** 					if sequence(lMsgText) then*/
        _11035 = IS_SEQUENCE(_lMsgText_19766);
        if (_11035 == 0)
        {
            _11035 = NOVALUE;
            goto LC; // [223] 231
        }
        else{
            _11035 = NOVALUE;
        }

        /** 						exit*/
        goto LB; // [228] 238
LC: 

        /** 				end for*/
        _i_19805 = _i_19805 + 1;
        goto LA; // [233] 201
LB: 
        ;
    }

    /** 				if atom(lMsgText) then*/
    _11036 = IS_ATOM(_lMsgText_19766);
    if (_11036 == 0)
    {
        _11036 = NOVALUE;
        goto LD; // [243] 260
    }
    else{
        _11036 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record({"",MsgNum})*/
    RefDS(_5);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5;
    ((int *)_2)[2] = _MsgNum_19761;
    _11037 = MAKE_SEQ(_1);
    RefDS(_49current_table_name_17056);
    _0 = _lMsgText_19766;
    _lMsgText_19766 = _49db_fetch_record(_11037, _49current_table_name_17056);
    DeRef(_0);
    _11037 = NOVALUE;
LD: 

    /** 				if atom(lMsgText) then*/
    _11039 = IS_ATOM(_lMsgText_19766);
    if (_11039 == 0)
    {
        _11039 = NOVALUE;
        goto LE; // [265] 278
    }
    else{
        _11039 = NOVALUE;
    }

    /** 					lMsgText = eds:db_fetch_record(MsgNum)*/
    RefDS(_49current_table_name_17056);
    _0 = _lMsgText_19766;
    _lMsgText_19766 = _49db_fetch_record(_MsgNum_19761, _49current_table_name_17056);
    DeRef(_0);
LE: 
L9: 
L8: 
L7: 

    /** 	if atom(lMsgText) then*/
    _11041 = IS_ATOM(_lMsgText_19766);
    if (_11041 == 0)
    {
        _11041 = NOVALUE;
        goto LF; // [286] 298
    }
    else{
        _11041 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_LocalQuals_19762);
    DeRefDS(_DBBase_19763);
    DeRef(_lMsgText_19766);
    DeRef(_dbname_19767);
    DeRef(_11006);
    _11006 = NOVALUE;
    return 0;
    goto L10; // [295] 305
LF: 

    /** 		return lMsgText*/
    DeRefDS(_LocalQuals_19762);
    DeRefDS(_DBBase_19763);
    DeRef(_dbname_19767);
    DeRef(_11006);
    _11006 = NOVALUE;
    return _lMsgText_19766;
L10: 
    ;
}



// 0x1F4C40F0
