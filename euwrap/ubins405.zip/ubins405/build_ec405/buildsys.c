// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _55find_file(int _fname_43908)
{
    int _23267 = NOVALUE;
    int _23266 = NOVALUE;
    int _23265 = NOVALUE;
    int _23264 = NOVALUE;
    int _23262 = NOVALUE;
    int _23261 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(inc_dirs) do*/
    _23261 = 4;
    {
        int _i_43910;
        _i_43910 = 1;
L1: 
        if (_i_43910 > 4){
            goto L2; // [10] 64
        }

        /** 		if file_exists(inc_dirs[i] & "/" & fname) then*/
        _2 = (int)SEQ_PTR(_55inc_dirs_43899);
        _23262 = (int)*(((s1_ptr)_2)->base + _i_43910);
        {
            int concat_list[3];

            concat_list[0] = _fname_43908;
            concat_list[1] = _23263;
            concat_list[2] = _23262;
            Concat_N((object_ptr)&_23264, concat_list, 3);
        }
        _23262 = NOVALUE;
        _23265 = _17file_exists(_23264);
        _23264 = NOVALUE;
        if (_23265 == 0) {
            DeRef(_23265);
            _23265 = NOVALUE;
            goto L3; // [35] 57
        }
        else {
            if (!IS_ATOM_INT(_23265) && DBL_PTR(_23265)->dbl == 0.0){
                DeRef(_23265);
                _23265 = NOVALUE;
                goto L3; // [35] 57
            }
            DeRef(_23265);
            _23265 = NOVALUE;
        }
        DeRef(_23265);
        _23265 = NOVALUE;

        /** 			return inc_dirs[i] & "/" & fname*/
        _2 = (int)SEQ_PTR(_55inc_dirs_43899);
        _23266 = (int)*(((s1_ptr)_2)->base + _i_43910);
        {
            int concat_list[3];

            concat_list[0] = _fname_43908;
            concat_list[1] = _23263;
            concat_list[2] = _23266;
            Concat_N((object_ptr)&_23267, concat_list, 3);
        }
        _23266 = NOVALUE;
        DeRefDS(_fname_43908);
        return _23267;
L3: 

        /** 	end for*/
        _i_43910 = _i_43910 + 1;
        goto L1; // [59] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_43908);
    DeRef(_23267);
    _23267 = NOVALUE;
    return 0;
    ;
}


int _55find_all_includes(int _fname_43922, int _includes_43923)
{
    int _lines_43924 = NOVALUE;
    int _m_43930 = NOVALUE;
    int _full_fname_43935 = NOVALUE;
    int _23280 = NOVALUE;
    int _23278 = NOVALUE;
    int _23276 = NOVALUE;
    int _23275 = NOVALUE;
    int _23273 = NOVALUE;
    int _23272 = NOVALUE;
    int _23270 = NOVALUE;
    int _23269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence lines = read_lines(fname)*/
    RefDS(_fname_43922);
    _0 = _lines_43924;
    _lines_43924 = _8read_lines(_fname_43922);
    DeRef(_0);

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_43924)){
            _23269 = SEQ_PTR(_lines_43924)->length;
    }
    else {
        _23269 = 1;
    }
    {
        int _i_43928;
        _i_43928 = 1;
L1: 
        if (_i_43928 > _23269){
            goto L2; // [18] 113
        }

        /** 		object m = regex:matches(re_include, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_43924);
        _23270 = (int)*(((s1_ptr)_2)->base + _i_43928);
        Ref(_55re_include_43896);
        Ref(_23270);
        _0 = _m_43930;
        _m_43930 = _51matches(_55re_include_43896, _23270, 1, 0);
        DeRef(_0);
        _23270 = NOVALUE;

        /** 		if sequence(m) then*/
        _23272 = IS_SEQUENCE(_m_43930);
        if (_23272 == 0)
        {
            _23272 = NOVALUE;
            goto L3; // [45] 102
        }
        else{
            _23272 = NOVALUE;
        }

        /** 			object full_fname = find_file(m[3])*/
        _2 = (int)SEQ_PTR(_m_43930);
        _23273 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_23273);
        _0 = _full_fname_43935;
        _full_fname_43935 = _55find_file(_23273);
        DeRef(_0);
        _23273 = NOVALUE;

        /** 			if sequence(full_fname) then*/
        _23275 = IS_SEQUENCE(_full_fname_43935);
        if (_23275 == 0)
        {
            _23275 = NOVALUE;
            goto L4; // [63] 101
        }
        else{
            _23275 = NOVALUE;
        }

        /** 				if eu:find(full_fname, includes) = 0 then*/
        _23276 = find_from(_full_fname_43935, _includes_43923, 1);
        if (_23276 != 0)
        goto L5; // [73] 100

        /** 					includes &= { full_fname }*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_full_fname_43935);
        *((int *)(_2+4)) = _full_fname_43935;
        _23278 = MAKE_SEQ(_1);
        Concat((object_ptr)&_includes_43923, _includes_43923, _23278);
        DeRefDS(_23278);
        _23278 = NOVALUE;

        /** 					includes = find_all_includes(full_fname, includes)*/
        RefDS(_includes_43923);
        DeRef(_23280);
        _23280 = _includes_43923;
        Ref(_full_fname_43935);
        _0 = _includes_43923;
        _includes_43923 = _55find_all_includes(_full_fname_43935, _23280);
        DeRefDS(_0);
        _23280 = NOVALUE;
L5: 
L4: 
L3: 
        DeRef(_full_fname_43935);
        _full_fname_43935 = NOVALUE;
        DeRef(_m_43930);
        _m_43930 = NOVALUE;

        /** 	end for*/
        _i_43928 = _i_43928 + 1;
        goto L1; // [108] 25
L2: 
        ;
    }

    /** 	return includes*/
    DeRefDS(_fname_43922);
    DeRef(_lines_43924);
    return _includes_43923;
    ;
}


int _55quick_has_changed(int _fname_43949)
{
    int _d1_43950 = NOVALUE;
    int _all_files_43960 = NOVALUE;
    int _d2_43966 = NOVALUE;
    int _diff_2__tmp_at88_43976 = NOVALUE;
    int _diff_1__tmp_at88_43975 = NOVALUE;
    int _diff_inlined_diff_at_88_43974 = NOVALUE;
    int _23292 = NOVALUE;
    int _23290 = NOVALUE;
    int _23289 = NOVALUE;
    int _23287 = NOVALUE;
    int _23286 = NOVALUE;
    int _23284 = NOVALUE;
    int _23282 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(output_dir & filebase(fname) & ".bld")*/
    RefDS(_fname_43949);
    _23282 = _17filebase(_fname_43949);
    {
        int concat_list[3];

        concat_list[0] = _23283;
        concat_list[1] = _23282;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_23284, concat_list, 3);
    }
    DeRef(_23282);
    _23282 = NOVALUE;
    _0 = _d1_43950;
    _d1_43950 = _17file_timestamp(_23284);
    DeRef(_0);
    _23284 = NOVALUE;

    /** 	if atom(d1) then*/
    _23286 = IS_ATOM(_d1_43950);
    if (_23286 == 0)
    {
        _23286 = NOVALUE;
        goto L1; // [26] 36
    }
    else{
        _23286 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_fname_43949);
    DeRef(_d1_43950);
    DeRef(_all_files_43960);
    return 1;
L1: 

    /** 	sequence all_files = append(find_all_includes(fname), fname)*/
    RefDS(_fname_43949);
    RefDS(_21815);
    _23287 = _55find_all_includes(_fname_43949, _21815);
    RefDS(_fname_43949);
    Append(&_all_files_43960, _23287, _fname_43949);
    DeRef(_23287);
    _23287 = NOVALUE;

    /** 	for i = 1 to length(all_files) do*/
    if (IS_SEQUENCE(_all_files_43960)){
            _23289 = SEQ_PTR(_all_files_43960)->length;
    }
    else {
        _23289 = 1;
    }
    {
        int _i_43964;
        _i_43964 = 1;
L2: 
        if (_i_43964 > _23289){
            goto L3; // [52] 123
        }

        /** 		object d2 = file_timestamp(all_files[i])*/
        _2 = (int)SEQ_PTR(_all_files_43960);
        _23290 = (int)*(((s1_ptr)_2)->base + _i_43964);
        Ref(_23290);
        _0 = _d2_43966;
        _d2_43966 = _17file_timestamp(_23290);
        DeRef(_0);
        _23290 = NOVALUE;

        /** 		if atom(d2) then*/
        _23292 = IS_ATOM(_d2_43966);
        if (_23292 == 0)
        {
            _23292 = NOVALUE;
            goto L4; // [74] 84
        }
        else{
            _23292 = NOVALUE;
        }

        /** 			return 1*/
        DeRef(_d2_43966);
        DeRefDS(_fname_43949);
        DeRef(_d1_43950);
        DeRefDS(_all_files_43960);
        return 1;
L4: 

        /** 		if datetime:diff(d1, d2) > 0 then*/

        /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
        Ref(_d2_43966);
        _0 = _diff_1__tmp_at88_43975;
        _diff_1__tmp_at88_43975 = _18datetimeToSeconds(_d2_43966);
        DeRef(_0);
        Ref(_d1_43950);
        _0 = _diff_2__tmp_at88_43976;
        _diff_2__tmp_at88_43976 = _18datetimeToSeconds(_d1_43950);
        DeRef(_0);
        DeRef(_diff_inlined_diff_at_88_43974);
        if (IS_ATOM_INT(_diff_1__tmp_at88_43975) && IS_ATOM_INT(_diff_2__tmp_at88_43976)) {
            _diff_inlined_diff_at_88_43974 = _diff_1__tmp_at88_43975 - _diff_2__tmp_at88_43976;
            if ((long)((unsigned long)_diff_inlined_diff_at_88_43974 +(unsigned long) HIGH_BITS) >= 0){
                _diff_inlined_diff_at_88_43974 = NewDouble((double)_diff_inlined_diff_at_88_43974);
            }
        }
        else {
            _diff_inlined_diff_at_88_43974 = binary_op(MINUS, _diff_1__tmp_at88_43975, _diff_2__tmp_at88_43976);
        }
        DeRef(_diff_1__tmp_at88_43975);
        _diff_1__tmp_at88_43975 = NOVALUE;
        DeRef(_diff_2__tmp_at88_43976);
        _diff_2__tmp_at88_43976 = NOVALUE;
        if (binary_op_a(LESSEQ, _diff_inlined_diff_at_88_43974, 0)){
            goto L5; // [103] 114
        }

        /** 			return 1*/
        DeRef(_d2_43966);
        DeRefDS(_fname_43949);
        DeRef(_d1_43950);
        DeRef(_all_files_43960);
        return 1;
L5: 
        DeRef(_d2_43966);
        _d2_43966 = NOVALUE;

        /** 	end for*/
        _i_43964 = _i_43964 + 1;
        goto L2; // [118] 59
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_fname_43949);
    DeRef(_d1_43950);
    DeRef(_all_files_43960);
    return 0;
    ;
}


void _55update_checksum(int _raw_data_44018)
{
    int _23300 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_check = xor_bits(cfile_check, hash( raw_data, stdhash:HSIEH32))*/
    _23300 = calc_hash(_raw_data_44018, -5);
    _0 = _55cfile_check_44002;
    if (IS_ATOM_INT(_55cfile_check_44002) && IS_ATOM_INT(_23300)) {
        {unsigned long tu;
             tu = (unsigned long)_55cfile_check_44002 ^ (unsigned long)_23300;
             _55cfile_check_44002 = MAKE_UINT(tu);
        }
    }
    else {
        if (IS_ATOM_INT(_55cfile_check_44002)) {
            temp_d.dbl = (double)_55cfile_check_44002;
            _55cfile_check_44002 = Dxor_bits(&temp_d, DBL_PTR(_23300));
        }
        else {
            if (IS_ATOM_INT(_23300)) {
                temp_d.dbl = (double)_23300;
                _55cfile_check_44002 = Dxor_bits(DBL_PTR(_55cfile_check_44002), &temp_d);
            }
            else
            _55cfile_check_44002 = Dxor_bits(DBL_PTR(_55cfile_check_44002), DBL_PTR(_23300));
        }
    }
    DeRef(_0);
    DeRef(_23300);
    _23300 = NOVALUE;

    /** end procedure*/
    DeRef(_raw_data_44018);
    return;
    ;
}


void _55write_checksum(int _file_44023)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_file_44023)) {
        _1 = (long)(DBL_PTR(_file_44023)->dbl);
        DeRefDS(_file_44023);
        _file_44023 = _1;
    }

    /** 	printf( file, "\n// 0x%08x\n", cfile_check )*/
    EPrintf(_file_44023, _23302, _55cfile_check_44002);

    /** 	cfile_check = 0*/
    DeRef(_55cfile_check_44002);
    _55cfile_check_44002 = 0;

    /** end procedure*/
    return;
    ;
}


int _55adjust_for_command_line_passing(int _long_path_44071)
{
    int _slash_44072 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if compiler_type = COMPILER_GCC then*/
    if (_55compiler_type_43986 != 1)
    goto L1; // [7] 19

    /** 		slash = '/'*/
    _slash_44072 = 47;
    goto L2; // [16] 45
L1: 

    /** 	elsif compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_43986 != 2)
    goto L3; // [23] 35

    /** 		slash = '\\'*/
    _slash_44072 = 92;
    goto L2; // [32] 45
L3: 

    /** 		slash = SLASH*/
    _slash_44072 = 47;
L2: 

    /** 	ifdef UNIX then*/

    /** 		return long_path*/
    return _long_path_44071;
    ;
}


int _55adjust_for_build_file(int _long_path_44081)
{
    int _short_path_44082 = NOVALUE;
    int _23332 = NOVALUE;
    int _23331 = NOVALUE;
    int _23330 = NOVALUE;
    int _23329 = NOVALUE;
    int _23328 = NOVALUE;
    int _23327 = NOVALUE;
    int _0, _1, _2;
    

    /**     object short_path = adjust_for_command_line_passing(long_path)*/
    RefDS(_long_path_44081);
    _0 = _short_path_44082;
    _short_path_44082 = _55adjust_for_command_line_passing(_long_path_44081);
    DeRef(_0);

    /**     if atom(short_path) then*/
    _23327 = IS_ATOM(_short_path_44082);
    if (_23327 == 0)
    {
        _23327 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _23327 = NOVALUE;
    }

    /**     	return short_path*/
    DeRefDS(_long_path_44081);
    return _short_path_44082;
L1: 

    /** 	if compiler_type = COMPILER_GCC and build_system_type != BUILD_DIRECT and TWINDOWS then*/
    _23328 = (_55compiler_type_43986 == 1);
    if (_23328 == 0) {
        _23329 = 0;
        goto L2; // [32] 46
    }
    _23330 = (_55build_system_type_43982 != 3);
    _23329 = (_23330 != 0);
L2: 
    if (_23329 == 0) {
        goto L3; // [46] 69
    }
    if (_40TWINDOWS_16112 == 0)
    {
        goto L3; // [53] 69
    }
    else{
    }

    /** 		return windows_to_mingw_path(short_path)*/
    Ref(_short_path_44082);
    _23332 = _55windows_to_mingw_path(_short_path_44082);
    DeRefDS(_long_path_44081);
    DeRef(_short_path_44082);
    DeRef(_23328);
    _23328 = NOVALUE;
    DeRef(_23330);
    _23330 = NOVALUE;
    return _23332;
    goto L4; // [66] 76
L3: 

    /** 		return short_path*/
    DeRefDS(_long_path_44081);
    DeRef(_23328);
    _23328 = NOVALUE;
    DeRef(_23330);
    _23330 = NOVALUE;
    DeRef(_23332);
    _23332 = NOVALUE;
    return _short_path_44082;
L4: 
    ;
}


int _55setup_build()
{
    int _c_exe_44097 = NOVALUE;
    int _c_flags_44098 = NOVALUE;
    int _l_exe_44099 = NOVALUE;
    int _l_flags_44100 = NOVALUE;
    int _obj_ext_44101 = NOVALUE;
    int _exe_ext_44102 = NOVALUE;
    int _l_flags_begin_44103 = NOVALUE;
    int _rc_comp_44104 = NOVALUE;
    int _l_names_44105 = NOVALUE;
    int _l_ext_44106 = NOVALUE;
    int _t_slash_44107 = NOVALUE;
    int _eudir_44127 = NOVALUE;
    int _locations_44152 = NOVALUE;
    int _compile_dir_44204 = NOVALUE;
    int _23471 = NOVALUE;
    int _23470 = NOVALUE;
    int _23469 = NOVALUE;
    int _23466 = NOVALUE;
    int _23465 = NOVALUE;
    int _23462 = NOVALUE;
    int _23461 = NOVALUE;
    int _23454 = NOVALUE;
    int _23453 = NOVALUE;
    int _23448 = NOVALUE;
    int _23447 = NOVALUE;
    int _23442 = NOVALUE;
    int _23441 = NOVALUE;
    int _23438 = NOVALUE;
    int _23437 = NOVALUE;
    int _23427 = NOVALUE;
    int _23426 = NOVALUE;
    int _23411 = NOVALUE;
    int _23410 = NOVALUE;
    int _23406 = NOVALUE;
    int _23404 = NOVALUE;
    int _23403 = NOVALUE;
    int _23402 = NOVALUE;
    int _23401 = NOVALUE;
    int _23389 = NOVALUE;
    int _23388 = NOVALUE;
    int _23385 = NOVALUE;
    int _23373 = NOVALUE;
    int _23371 = NOVALUE;
    int _23370 = NOVALUE;
    int _23369 = NOVALUE;
    int _23368 = NOVALUE;
    int _23367 = NOVALUE;
    int _23366 = NOVALUE;
    int _23365 = NOVALUE;
    int _23364 = NOVALUE;
    int _23363 = NOVALUE;
    int _23362 = NOVALUE;
    int _23357 = NOVALUE;
    int _23354 = NOVALUE;
    int _23353 = NOVALUE;
    int _23352 = NOVALUE;
    int _23349 = NOVALUE;
    int _23348 = NOVALUE;
    int _23347 = NOVALUE;
    int _23344 = NOVALUE;
    int _23340 = NOVALUE;
    int _23333 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence c_exe   = "", c_flags = "", l_exe   = "", l_flags = "", obj_ext = "",*/
    RefDS(_21815);
    DeRefi(_c_exe_44097);
    _c_exe_44097 = _21815;
    RefDS(_21815);
    DeRef(_c_flags_44098);
    _c_flags_44098 = _21815;
    RefDS(_21815);
    DeRefi(_l_exe_44099);
    _l_exe_44099 = _21815;
    RefDS(_21815);
    DeRef(_l_flags_44100);
    _l_flags_44100 = _21815;
    RefDS(_21815);
    DeRefi(_obj_ext_44101);
    _obj_ext_44101 = _21815;

    /** 		exe_ext = "", l_flags_begin = "", rc_comp = "", l_names, l_ext, t_slash*/
    RefDS(_21815);
    DeRefi(_exe_ext_44102);
    _exe_ext_44102 = _21815;
    RefDS(_21815);
    DeRefi(_l_flags_begin_44103);
    _l_flags_begin_44103 = _21815;
    RefDS(_21815);
    DeRef(_rc_comp_44104);
    _rc_comp_44104 = _21815;

    /** 	if length(user_library) = 0 then*/
    if (IS_SEQUENCE(_57user_library_41342)){
            _23333 = SEQ_PTR(_57user_library_41342)->length;
    }
    else {
        _23333 = 1;
    }
    if (_23333 != 0)
    goto L1; // [52] 347

    /** 		if debug_option then*/
    if (_57debug_option_41340 == 0)
    {
        goto L2; // [60] 72
    }
    else{
    }

    /** 			l_names = { "eudbg", "eu" }*/
    RefDS(_23336);
    RefDS(_23335);
    DeRef(_l_names_44105);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23335;
    ((int *)_2)[2] = _23336;
    _l_names_44105 = MAKE_SEQ(_1);
    goto L3; // [69] 79
L2: 

    /** 			l_names = { "eu", "eudbg" }*/
    RefDS(_23335);
    RefDS(_23336);
    DeRef(_l_names_44105);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23336;
    ((int *)_2)[2] = _23335;
    _l_names_44105 = MAKE_SEQ(_1);
L3: 

    /** 		if TUNIX or compiler_type = COMPILER_GCC then*/
    if (_40TUNIX_16116 != 0) {
        goto L4; // [83] 98
    }
    _23340 = (_55compiler_type_43986 == 1);
    if (_23340 == 0)
    {
        DeRef(_23340);
        _23340 = NOVALUE;
        goto L5; // [94] 115
    }
    else{
        DeRef(_23340);
        _23340 = NOVALUE;
    }
L4: 

    /** 			l_ext = "a"*/
    RefDS(_22053);
    DeRefi(_l_ext_44106);
    _l_ext_44106 = _22053;

    /** 			t_slash = "/"*/
    RefDS(_23263);
    DeRefi(_t_slash_44107);
    _t_slash_44107 = _23263;
    goto L6; // [112] 138
L5: 

    /** 		elsif TWINDOWS then*/
    if (_40TWINDOWS_16112 == 0)
    {
        goto L7; // [119] 137
    }
    else{
    }

    /** 			l_ext = "lib"*/
    RefDS(_23341);
    DeRefi(_l_ext_44106);
    _l_ext_44106 = _23341;

    /** 			t_slash = "\\"*/
    RefDS(_23342);
    DeRefi(_t_slash_44107);
    _t_slash_44107 = _23342;
L7: 
L6: 

    /** 		object eudir = get_eucompiledir()*/
    _0 = _eudir_44127;
    _eudir_44127 = _57get_eucompiledir();
    DeRef(_0);

    /** 		if not file_exists(eudir) then*/
    Ref(_eudir_44127);
    _23344 = _17file_exists(_eudir_44127);
    if (IS_ATOM_INT(_23344)) {
        if (_23344 != 0){
            DeRef(_23344);
            _23344 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    else {
        if (DBL_PTR(_23344)->dbl != 0.0){
            DeRef(_23344);
            _23344 = NOVALUE;
            goto L8; // [149] 170
        }
    }
    DeRef(_23344);
    _23344 = NOVALUE;

    /** 			printf(2,"Supplied directory \'%s\' is not a valid EUDIR\n",{get_eucompiledir()})*/
    _23347 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23347;
    _23348 = MAKE_SEQ(_1);
    _23347 = NOVALUE;
    EPrintf(2, _23346, _23348);
    DeRefDS(_23348);
    _23348 = NOVALUE;

    /** 			abort(1)*/
    UserCleanup(1);
L8: 

    /** 		for tk = 1 to length(l_names) label "translation kind" do*/
    _23349 = 2;
    {
        int _tk_44139;
        _tk_44139 = 1;
L9: 
        if (_tk_44139 > 2){
            goto LA; // [177] 346
        }

        /** 			user_library = eudir & sprintf("%sbin%s%s.%s",{t_slash, t_slash, l_names[tk],l_ext})*/
        _2 = (int)SEQ_PTR(_l_names_44105);
        _23352 = (int)*(((s1_ptr)_2)->base + _tk_44139);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        RefDSn(_t_slash_44107, 2);
        *((int *)(_2+4)) = _t_slash_44107;
        *((int *)(_2+8)) = _t_slash_44107;
        RefDS(_23352);
        *((int *)(_2+12)) = _23352;
        RefDS(_l_ext_44106);
        *((int *)(_2+16)) = _l_ext_44106;
        _23353 = MAKE_SEQ(_1);
        _23352 = NOVALUE;
        _23354 = EPrintf(-9999999, _23351, _23353);
        DeRefDS(_23353);
        _23353 = NOVALUE;
        if (IS_SEQUENCE(_eudir_44127) && IS_ATOM(_23354)) {
        }
        else if (IS_ATOM(_eudir_44127) && IS_SEQUENCE(_23354)) {
            Ref(_eudir_44127);
            Prepend(&_57user_library_41342, _23354, _eudir_44127);
        }
        else {
            Concat((object_ptr)&_57user_library_41342, _eudir_44127, _23354);
        }
        DeRefDS(_23354);
        _23354 = NOVALUE;

        /** 			if TUNIX or compiler_type = COMPILER_GCC then*/
        if (_40TUNIX_16116 != 0) {
            goto LB; // [215] 230
        }
        _23357 = (_55compiler_type_43986 == 1);
        if (_23357 == 0)
        {
            DeRef(_23357);
            _23357 = NOVALUE;
            goto LC; // [226] 321
        }
        else{
            DeRef(_23357);
            _23357 = NOVALUE;
        }
LB: 

        /** 				ifdef UNIX then*/

        /** 					sequence locations = { "/usr/local/lib/%s.a", "/usr/lib/%s.a"}*/
        RefDS(_23359);
        RefDS(_23358);
        DeRef(_locations_44152);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23358;
        ((int *)_2)[2] = _23359;
        _locations_44152 = MAKE_SEQ(_1);

        /** 					if match( "/share/euphoria", eudir ) then*/
        _23362 = e_match_from(_23361, _eudir_44127, 1);
        if (_23362 == 0)
        {
            _23362 = NOVALUE;
            goto LD; // [245] 320
        }
        else{
            _23362 = NOVALUE;
        }

        /** 						for i = 1 to length(locations) do*/
        _23363 = 2;
        {
            int _i_44160;
            _i_44160 = 1;
LE: 
            if (_i_44160 > 2){
                goto LF; // [253] 319
            }

            /** 							if file_exists( sprintf(locations[i],{l_names[tk]}) ) then*/
            _2 = (int)SEQ_PTR(_locations_44152);
            _23364 = (int)*(((s1_ptr)_2)->base + _i_44160);
            _2 = (int)SEQ_PTR(_l_names_44105);
            _23365 = (int)*(((s1_ptr)_2)->base + _tk_44139);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_23365);
            *((int *)(_2+4)) = _23365;
            _23366 = MAKE_SEQ(_1);
            _23365 = NOVALUE;
            _23367 = EPrintf(-9999999, _23364, _23366);
            _23364 = NOVALUE;
            DeRefDS(_23366);
            _23366 = NOVALUE;
            _23368 = _17file_exists(_23367);
            _23367 = NOVALUE;
            if (_23368 == 0) {
                DeRef(_23368);
                _23368 = NOVALUE;
                goto L10; // [282] 312
            }
            else {
                if (!IS_ATOM_INT(_23368) && DBL_PTR(_23368)->dbl == 0.0){
                    DeRef(_23368);
                    _23368 = NOVALUE;
                    goto L10; // [282] 312
                }
                DeRef(_23368);
                _23368 = NOVALUE;
            }
            DeRef(_23368);
            _23368 = NOVALUE;

            /** 								user_library = sprintf(locations[i],{l_names[tk]})*/
            _2 = (int)SEQ_PTR(_locations_44152);
            _23369 = (int)*(((s1_ptr)_2)->base + _i_44160);
            _2 = (int)SEQ_PTR(_l_names_44105);
            _23370 = (int)*(((s1_ptr)_2)->base + _tk_44139);
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            RefDS(_23370);
            *((int *)(_2+4)) = _23370;
            _23371 = MAKE_SEQ(_1);
            _23370 = NOVALUE;
            DeRef(_57user_library_41342);
            _57user_library_41342 = EPrintf(-9999999, _23369, _23371);
            _23369 = NOVALUE;
            DeRefDS(_23371);
            _23371 = NOVALUE;

            /** 								exit "translation kind"*/
            DeRefDS(_locations_44152);
            _locations_44152 = NOVALUE;
            goto LA; // [309] 346
L10: 

            /** 						end for*/
            _i_44160 = _i_44160 + 1;
            goto LE; // [314] 260
LF: 
            ;
        }
LD: 
LC: 
        DeRef(_locations_44152);
        _locations_44152 = NOVALUE;

        /** 			if file_exists(user_library) then*/
        RefDS(_57user_library_41342);
        _23373 = _17file_exists(_57user_library_41342);
        if (_23373 == 0) {
            DeRef(_23373);
            _23373 = NOVALUE;
            goto L11; // [331] 339
        }
        else {
            if (!IS_ATOM_INT(_23373) && DBL_PTR(_23373)->dbl == 0.0){
                DeRef(_23373);
                _23373 = NOVALUE;
                goto L11; // [331] 339
            }
            DeRef(_23373);
            _23373 = NOVALUE;
        }
        DeRef(_23373);
        _23373 = NOVALUE;

        /** 				exit "translation kind"*/
        goto LA; // [336] 346
L11: 

        /** 		end for -- tk*/
        _tk_44139 = _tk_44139 + 1;
        goto L9; // [341] 184
LA: 
        ;
    }
L1: 
    DeRef(_eudir_44127);
    _eudir_44127 = NOVALUE;

    /** 	user_library = adjust_for_build_file(user_library)*/
    RefDS(_57user_library_41342);
    _0 = _55adjust_for_build_file(_57user_library_41342);
    DeRefDS(_57user_library_41342);
    _57user_library_41342 = _0;

    /** 	if TWINDOWS then*/
    if (_40TWINDOWS_16112 == 0)
    {
        goto L12; // [363] 418
    }
    else{
    }

    /** 		if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_43986 != 2)
    goto L13; // [370] 383

    /** 			c_flags &= " /dEWINDOWS"*/
    Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23376);
    goto L14; // [380] 390
L13: 

    /** 			c_flags &= " -DEWINDOWS"*/
    Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23378);
L14: 

    /** 		if dll_option then*/
    if (_57dll_option_41330 == 0)
    {
        goto L15; // [394] 407
    }
    else{
    }

    /** 			exe_ext = ".dll"*/
    RefDS(_23380);
    DeRefi(_exe_ext_44102);
    _exe_ext_44102 = _23380;
    goto L16; // [404] 459
L15: 

    /** 			exe_ext = ".exe"*/
    RefDS(_23381);
    DeRefi(_exe_ext_44102);
    _exe_ext_44102 = _23381;
    goto L16; // [415] 459
L12: 

    /** 	elsif TOSX then*/
    if (_40TOSX_16120 == 0)
    {
        goto L17; // [422] 443
    }
    else{
    }

    /** 		if dll_option then*/
    if (_57dll_option_41330 == 0)
    {
        goto L16; // [429] 459
    }
    else{
    }

    /** 			exe_ext = ".dylib"*/
    RefDS(_23382);
    DeRefi(_exe_ext_44102);
    _exe_ext_44102 = _23382;
    goto L16; // [440] 459
L17: 

    /** 		if dll_option then*/
    if (_57dll_option_41330 == 0)
    {
        goto L18; // [447] 458
    }
    else{
    }

    /** 			exe_ext = ".so"*/
    RefDS(_23383);
    DeRefi(_exe_ext_44102);
    _exe_ext_44102 = _23383;
L18: 
L16: 

    /** 	object compile_dir = get_eucompiledir()*/
    _0 = _compile_dir_44204;
    _compile_dir_44204 = _57get_eucompiledir();
    DeRef(_0);

    /** 	if not file_exists(compile_dir) then*/
    Ref(_compile_dir_44204);
    _23385 = _17file_exists(_compile_dir_44204);
    if (IS_ATOM_INT(_23385)) {
        if (_23385 != 0){
            DeRef(_23385);
            _23385 = NOVALUE;
            goto L19; // [470] 491
        }
    }
    else {
        if (DBL_PTR(_23385)->dbl != 0.0){
            DeRef(_23385);
            _23385 = NOVALUE;
            goto L19; // [470] 491
        }
    }
    DeRef(_23385);
    _23385 = NOVALUE;

    /** 		printf(2,"Couldn't get include directory '%s'",{get_eucompiledir()})*/
    _23388 = _57get_eucompiledir();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23388;
    _23389 = MAKE_SEQ(_1);
    _23388 = NOVALUE;
    EPrintf(2, _23387, _23389);
    DeRefDS(_23389);
    _23389 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L19: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_43986;
    switch ( _0 ){ 

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			c_exe = "gcc"*/
        RefDS(_23392);
        DeRefi(_c_exe_44097);
        _c_exe_44097 = _23392;

        /** 			l_exe = "gcc"*/
        RefDS(_23392);
        DeRefi(_l_exe_44099);
        _l_exe_44099 = _23392;

        /** 			obj_ext = "o"*/
        RefDS(_23393);
        DeRefi(_obj_ext_44101);
        _obj_ext_44101 = _23393;

        /** 			if debug_option then*/
        if (_57debug_option_41340 == 0)
        {
            goto L1A; // [529] 541
        }
        else{
        }

        /** 				c_flags &= " -g3"*/
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23394);
        goto L1B; // [538] 548
L1A: 

        /** 				c_flags &= " -fomit-frame-pointer"*/
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23396);
L1B: 

        /** 			if dll_option then*/
        if (_57dll_option_41330 == 0)
        {
            goto L1C; // [552] 562
        }
        else{
        }

        /** 				c_flags &= " -fPIC"*/
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23398);
L1C: 

        /** 			c_flags &= sprintf(" -c -w -fsigned-char -O2 -m32 -I%s -ffast-math",*/
        _23401 = _57get_eucompiledir();
        _23402 = _55adjust_for_build_file(_23401);
        _23401 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23402;
        _23403 = MAKE_SEQ(_1);
        _23402 = NOVALUE;
        _23404 = EPrintf(-9999999, _23400, _23403);
        DeRefDS(_23403);
        _23403 = NOVALUE;
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23404);
        DeRefDS(_23404);
        _23404 = NOVALUE;

        /** 			if TWINDOWS and mno_cygwin then*/
        if (_40TWINDOWS_16112 == 0) {
            goto L1D; // [587] 604
        }
        if (_55mno_cygwin_44007 == 0)
        {
            goto L1D; // [594] 604
        }
        else{
        }

        /** 				c_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23407);
L1D: 

        /** 			l_flags = sprintf( "%s -m32 ", { adjust_for_build_file(user_library) })*/
        RefDS(_57user_library_41342);
        _23410 = _55adjust_for_build_file(_57user_library_41342);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23410;
        _23411 = MAKE_SEQ(_1);
        _23410 = NOVALUE;
        DeRef(_l_flags_44100);
        _l_flags_44100 = EPrintf(-9999999, _23409, _23411);
        DeRefDS(_23411);
        _23411 = NOVALUE;

        /** 			if dll_option then*/
        if (_57dll_option_41330 == 0)
        {
            goto L1E; // [624] 634
        }
        else{
        }

        /** 				l_flags &= " -shared "*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23413);
L1E: 

        /** 			if TLINUX then*/
        if (_40TLINUX_16114 == 0)
        {
            goto L1F; // [638] 650
        }
        else{
        }

        /** 				l_flags &= " -ldl -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23415);
        goto L20; // [647] 719
L1F: 

        /** 			elsif TBSD then*/
        if (_40TBSD_16118 == 0)
        {
            goto L21; // [654] 666
        }
        else{
        }

        /** 				l_flags &= " -lm -lpthread"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23417);
        goto L20; // [663] 719
L21: 

        /** 			elsif TOSX then*/
        if (_40TOSX_16120 == 0)
        {
            goto L22; // [670] 682
        }
        else{
        }

        /** 				l_flags &= " -lresolv"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23419);
        goto L20; // [679] 719
L22: 

        /** 			elsif TWINDOWS then*/
        if (_40TWINDOWS_16112 == 0)
        {
            goto L23; // [686] 718
        }
        else{
        }

        /** 				if mno_cygwin then*/
        if (_55mno_cygwin_44007 == 0)
        {
            goto L24; // [693] 703
        }
        else{
        }

        /** 					l_flags &= " -mno-cygwin"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23407);
L24: 

        /** 				if not con_option then*/
        if (_57con_option_41332 != 0)
        goto L25; // [707] 717

        /** 					l_flags &= " -mwindows"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23423);
L25: 
L23: 
L20: 

        /** 			rc_comp = "windres -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" [1] -O coff -o [2]"*/
        _23426 = _17current_dir();
        _23427 = _55adjust_for_build_file(_23426);
        _23426 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23428;
            concat_list[1] = _23427;
            concat_list[2] = _23425;
            Concat_N((object_ptr)&_rc_comp_44104, concat_list, 3);
        }
        DeRef(_23427);
        _23427 = NOVALUE;
        goto L26; // [734] 933

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			c_exe = "wcc386"*/
        RefDS(_23430);
        DeRefi(_c_exe_44097);
        _c_exe_44097 = _23430;

        /** 			l_exe = "wlink"*/
        RefDS(_23431);
        DeRefi(_l_exe_44099);
        _l_exe_44099 = _23431;

        /** 			obj_ext = "obj"*/
        RefDS(_23432);
        DeRefi(_obj_ext_44101);
        _obj_ext_44101 = _23432;

        /** 			if debug_option then*/
        if (_57debug_option_41340 == 0)
        {
            goto L27; // [765] 782
        }
        else{
        }

        /** 				c_flags = " /d3"*/
        RefDS(_23433);
        DeRef(_c_flags_44098);
        _c_flags_44098 = _23433;

        /** 				l_flags_begin &= " DEBUG ALL "*/
        Concat((object_ptr)&_l_flags_begin_44103, _l_flags_begin_44103, _23434);
L27: 

        /** 			l_flags &= sprintf(" OPTION STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _57total_stack_size_41344;
        _23437 = MAKE_SEQ(_1);
        _23438 = EPrintf(-9999999, _23436, _23437);
        DeRefDS(_23437);
        _23437 = NOVALUE;
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23438);
        DeRefDS(_23438);
        _23438 = NOVALUE;

        /** 			l_flags &= sprintf(" COMMIT STACK=%d ", { total_stack_size })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _57total_stack_size_41344;
        _23441 = MAKE_SEQ(_1);
        _23442 = EPrintf(-9999999, _23440, _23441);
        DeRefDS(_23441);
        _23441 = NOVALUE;
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23442);
        DeRefDS(_23442);
        _23442 = NOVALUE;

        /** 			l_flags &= " OPTION QUIET OPTION ELIMINATE OPTION CASEEXACT"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23444);

        /** 			if dll_option then*/
        if (_57dll_option_41330 == 0)
        {
            goto L28; // [824] 850
        }
        else{
        }

        /** 				c_flags &= " /bd /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir) */
        Ref(_compile_dir_44204);
        _23447 = _55adjust_for_build_file(_compile_dir_44204);
        if (IS_SEQUENCE(_23446) && IS_ATOM(_23447)) {
            Ref(_23447);
            Append(&_23448, _23446, _23447);
        }
        else if (IS_ATOM(_23446) && IS_SEQUENCE(_23447)) {
        }
        else {
            Concat((object_ptr)&_23448, _23446, _23447);
        }
        DeRef(_23447);
        _23447 = NOVALUE;
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23448);
        DeRefDS(_23448);
        _23448 = NOVALUE;

        /** 				l_flags &= " SYSTEM NT_DLL initinstance terminstance"*/
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23450);
        goto L29; // [847] 888
L28: 

        /** 				c_flags &= " /bt=nt /mf /w0 /zq /j /zp4 /fp5 /fpi87 /5r /otimra /s /I" & adjust_for_build_file(compile_dir)*/
        Ref(_compile_dir_44204);
        _23453 = _55adjust_for_build_file(_compile_dir_44204);
        if (IS_SEQUENCE(_23452) && IS_ATOM(_23453)) {
            Ref(_23453);
            Append(&_23454, _23452, _23453);
        }
        else if (IS_ATOM(_23452) && IS_SEQUENCE(_23453)) {
        }
        else {
            Concat((object_ptr)&_23454, _23452, _23453);
        }
        DeRef(_23453);
        _23453 = NOVALUE;
        Concat((object_ptr)&_c_flags_44098, _c_flags_44098, _23454);
        DeRefDS(_23454);
        _23454 = NOVALUE;

        /** 				if con_option then*/
        if (_57con_option_41332 == 0)
        {
            goto L2A; // [868] 880
        }
        else{
        }

        /** 					l_flags = " SYSTEM NT" & l_flags*/
        Concat((object_ptr)&_l_flags_44100, _23456, _l_flags_44100);
        goto L2B; // [877] 887
L2A: 

        /** 					l_flags = " SYSTEM NT_WIN RUNTIME WINDOWS=4.0" & l_flags*/
        Concat((object_ptr)&_l_flags_44100, _23458, _l_flags_44100);
L2B: 
L29: 

        /** 			l_flags &= sprintf(" FILE %s", { (user_library) })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57user_library_41342);
        *((int *)(_2+4)) = _57user_library_41342;
        _23461 = MAKE_SEQ(_1);
        _23462 = EPrintf(-9999999, _23460, _23461);
        DeRefDS(_23461);
        _23461 = NOVALUE;
        Concat((object_ptr)&_l_flags_44100, _l_flags_44100, _23462);
        DeRefDS(_23462);
        _23462 = NOVALUE;

        /** 			rc_comp = "wrc -DSRCDIR=\"" & adjust_for_build_file(current_dir()) & "\" -q -fo=[2] -ad [1] [3]"*/
        _23465 = _17current_dir();
        _23466 = _55adjust_for_build_file(_23465);
        _23465 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _23467;
            concat_list[1] = _23466;
            concat_list[2] = _23464;
            Concat_N((object_ptr)&_rc_comp_44104, concat_list, 3);
        }
        DeRef(_23466);
        _23466 = NOVALUE;
        goto L26; // [919] 933

        /** 		case else*/
        default:

        /** 			CompileErr(43)*/
        RefDS(_21815);
        _44CompileErr(43, _21815, 0);
    ;}L26: 

    /** 	if length(cflags) then*/
    if (IS_SEQUENCE(_55cflags_44003)){
            _23469 = SEQ_PTR(_55cflags_44003)->length;
    }
    else {
        _23469 = 1;
    }
    if (_23469 == 0)
    {
        _23469 = NOVALUE;
        goto L2C; // [940] 953
    }
    else{
        _23469 = NOVALUE;
    }

    /** 		c_flags = cflags*/
    RefDS(_55cflags_44003);
    DeRef(_c_flags_44098);
    _c_flags_44098 = _55cflags_44003;
L2C: 

    /** 	if length(lflags) then*/
    if (IS_SEQUENCE(_55lflags_44004)){
            _23470 = SEQ_PTR(_55lflags_44004)->length;
    }
    else {
        _23470 = 1;
    }
    if (_23470 == 0)
    {
        _23470 = NOVALUE;
        goto L2D; // [960] 980
    }
    else{
        _23470 = NOVALUE;
    }

    /** 		l_flags = lflags*/
    RefDS(_55lflags_44004);
    DeRef(_l_flags_44100);
    _l_flags_44100 = _55lflags_44004;

    /** 		l_flags_begin = ""*/
    RefDS(_21815);
    DeRefi(_l_flags_begin_44103);
    _l_flags_begin_44103 = _21815;
L2D: 

    /** 	return { */
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_c_exe_44097);
    *((int *)(_2+4)) = _c_exe_44097;
    RefDS(_c_flags_44098);
    *((int *)(_2+8)) = _c_flags_44098;
    RefDS(_l_exe_44099);
    *((int *)(_2+12)) = _l_exe_44099;
    RefDS(_l_flags_44100);
    *((int *)(_2+16)) = _l_flags_44100;
    RefDS(_obj_ext_44101);
    *((int *)(_2+20)) = _obj_ext_44101;
    RefDS(_exe_ext_44102);
    *((int *)(_2+24)) = _exe_ext_44102;
    RefDS(_l_flags_begin_44103);
    *((int *)(_2+28)) = _l_flags_begin_44103;
    RefDS(_rc_comp_44104);
    *((int *)(_2+32)) = _rc_comp_44104;
    _23471 = MAKE_SEQ(_1);
    DeRefDSi(_c_exe_44097);
    DeRefDS(_c_flags_44098);
    DeRefDSi(_l_exe_44099);
    DeRefDS(_l_flags_44100);
    DeRefDSi(_obj_ext_44101);
    DeRefDSi(_exe_ext_44102);
    DeRefDSi(_l_flags_begin_44103);
    DeRefDS(_rc_comp_44104);
    DeRef(_l_names_44105);
    DeRefi(_l_ext_44106);
    DeRefi(_t_slash_44107);
    DeRef(_compile_dir_44204);
    return _23471;
    ;
}


void _55ensure_exename(int _ext_44340)
{
    int _23478 = NOVALUE;
    int _23477 = NOVALUE;
    int _23476 = NOVALUE;
    int _23475 = NOVALUE;
    int _23473 = NOVALUE;
    int _23472 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(exe_name[D_ALTNAME]) = 0 then*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23472 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23472)){
            _23473 = SEQ_PTR(_23472)->length;
    }
    else {
        _23473 = 1;
    }
    _23472 = NOVALUE;
    if (_23473 != 0)
    goto L1; // [16] 67

    /** 		exe_name[D_NAME] = current_dir() & SLASH & file0 & ext*/
    _23475 = _17current_dir();
    {
        int concat_list[4];

        concat_list[0] = _ext_44340;
        concat_list[1] = _57file0_43168;
        concat_list[2] = 47;
        concat_list[3] = _23475;
        Concat_N((object_ptr)&_23476, concat_list, 4);
    }
    DeRef(_23475);
    _23475 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _23476;
    if( _1 != _23476 ){
        DeRef(_1);
    }
    _23476 = NOVALUE;

    /** 		exe_name[D_ALTNAME] = adjust_for_command_line_passing(exe_name[D_NAME])*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23477 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23477);
    _23478 = _55adjust_for_command_line_passing(_23477);
    _23477 = NOVALUE;
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _23478;
    if( _1 != _23478 ){
        DeRef(_1);
    }
    _23478 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDS(_ext_44340);
    _23472 = NOVALUE;
    return;
    ;
}


void _55write_objlink_file()
{
    int _settings_44358 = NOVALUE;
    int _fh_44360 = NOVALUE;
    int _s_44408 = NOVALUE;
    int _23527 = NOVALUE;
    int _23525 = NOVALUE;
    int _23524 = NOVALUE;
    int _23523 = NOVALUE;
    int _23522 = NOVALUE;
    int _23521 = NOVALUE;
    int _23520 = NOVALUE;
    int _23519 = NOVALUE;
    int _23518 = NOVALUE;
    int _23517 = NOVALUE;
    int _23516 = NOVALUE;
    int _23515 = NOVALUE;
    int _23514 = NOVALUE;
    int _23512 = NOVALUE;
    int _23511 = NOVALUE;
    int _23510 = NOVALUE;
    int _23509 = NOVALUE;
    int _23507 = NOVALUE;
    int _23506 = NOVALUE;
    int _23505 = NOVALUE;
    int _23504 = NOVALUE;
    int _23503 = NOVALUE;
    int _23502 = NOVALUE;
    int _23501 = NOVALUE;
    int _23500 = NOVALUE;
    int _23499 = NOVALUE;
    int _23496 = NOVALUE;
    int _23495 = NOVALUE;
    int _23492 = NOVALUE;
    int _23491 = NOVALUE;
    int _23490 = NOVALUE;
    int _23489 = NOVALUE;
    int _23488 = NOVALUE;
    int _23486 = NOVALUE;
    int _23485 = NOVALUE;
    int _23484 = NOVALUE;
    int _23481 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44358;
    _settings_44358 = _55setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".lnk", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23480;
        concat_list[1] = _57file0_43168;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_23481, concat_list, 3);
    }
    _fh_44360 = EOpen(_23481, _23482, 0);
    DeRefDS(_23481);
    _23481 = NOVALUE;

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44358);
    _23484 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23484);
    _55ensure_exename(_23484);
    _23484 = NOVALUE;

    /** 	if length(settings[SETUP_LFLAGS_BEGIN]) > 0 then*/
    _2 = (int)SEQ_PTR(_settings_44358);
    _23485 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23485)){
            _23486 = SEQ_PTR(_23485)->length;
    }
    else {
        _23486 = 1;
    }
    _23485 = NOVALUE;
    if (_23486 <= 0)
    goto L1; // [43] 63

    /** 		puts(fh, settings[SETUP_LFLAGS_BEGIN] & HOSTNL)*/
    _2 = (int)SEQ_PTR(_settings_44358);
    _23488 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_23488) && IS_ATOM(_40HOSTNL_16127)) {
    }
    else if (IS_ATOM(_23488) && IS_SEQUENCE(_40HOSTNL_16127)) {
        Ref(_23488);
        Prepend(&_23489, _40HOSTNL_16127, _23488);
    }
    else {
        Concat((object_ptr)&_23489, _23488, _40HOSTNL_16127);
        _23488 = NOVALUE;
    }
    _23488 = NOVALUE;
    EPuts(_fh_44360, _23489); // DJP 
    DeRefDS(_23489);
    _23489 = NOVALUE;
L1: 

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23490 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23490 = 1;
    }
    {
        int _i_44376;
        _i_44376 = 1;
L2: 
        if (_i_44376 > _23490){
            goto L3; // [70] 132
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23491 = (int)*(((s1_ptr)_2)->base + _i_44376);
        _23492 = e_match_from(_22855, _23491, 1);
        _23491 = NOVALUE;
        if (_23492 == 0)
        {
            _23492 = NOVALUE;
            goto L4; // [90] 125
        }
        else{
            _23492 = NOVALUE;
        }

        /** 			if compiler_type = COMPILER_WATCOM then*/
        if (_55compiler_type_43986 != 2)
        goto L5; // [97] 107

        /** 				puts(fh, "FILE ")*/
        EPuts(_fh_44360, _23494); // DJP 
L5: 

        /** 			puts(fh, generated_files[i] & HOSTNL)*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23495 = (int)*(((s1_ptr)_2)->base + _i_44376);
        Concat((object_ptr)&_23496, _23495, _40HOSTNL_16127);
        _23495 = NOVALUE;
        _23495 = NOVALUE;
        EPuts(_fh_44360, _23496); // DJP 
        DeRefDS(_23496);
        _23496 = NOVALUE;
L4: 

        /** 	end for*/
        _i_44376 = _i_44376 + 1;
        goto L2; // [127] 77
L3: 
        ;
    }

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_43986 != 2)
    goto L6; // [136] 165

    /** 		printf(fh, "NAME '%s'" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23499, _23498, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23500 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23500);
    *((int *)(_2+4)) = _23500;
    _23501 = MAKE_SEQ(_1);
    _23500 = NOVALUE;
    EPrintf(_fh_44360, _23499, _23501);
    DeRefDS(_23499);
    _23499 = NOVALUE;
    DeRefDS(_23501);
    _23501 = NOVALUE;
L6: 

    /** 	puts(fh, trim(settings[SETUP_LFLAGS] & HOSTNL))*/
    _2 = (int)SEQ_PTR(_settings_44358);
    _23502 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_SEQUENCE(_23502) && IS_ATOM(_40HOSTNL_16127)) {
    }
    else if (IS_ATOM(_23502) && IS_SEQUENCE(_40HOSTNL_16127)) {
        Ref(_23502);
        Prepend(&_23503, _40HOSTNL_16127, _23502);
    }
    else {
        Concat((object_ptr)&_23503, _23502, _40HOSTNL_16127);
        _23502 = NOVALUE;
    }
    _23502 = NOVALUE;
    RefDS(_3815);
    _23504 = _14trim(_23503, _3815, 0);
    _23503 = NOVALUE;
    EPuts(_fh_44360, _23504); // DJP 
    DeRef(_23504);
    _23504 = NOVALUE;

    /** 	if compiler_type = COMPILER_WATCOM and dll_option then*/
    _23505 = (_55compiler_type_43986 == 2);
    if (_23505 == 0) {
        goto L7; // [194] 361
    }
    if (_57dll_option_41330 == 0)
    {
        goto L7; // [201] 361
    }
    else{
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44360, _40HOSTNL_16127); // DJP 

    /** 		object s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23507 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    DeRef(_s_44408);
    _2 = (int)SEQ_PTR(_23507);
    _s_44408 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44408);
    _23507 = NOVALUE;

    /** 		while s do*/
L8: 
    if (_s_44408 <= 0) {
        if (_s_44408 == 0) {
            goto L9; // [232] 360
        }
        else {
            if (!IS_ATOM_INT(_s_44408) && DBL_PTR(_s_44408)->dbl == 0.0){
                goto L9; // [232] 360
            }
        }
    }

    /** 			if eu:find(SymTab[s][S_TOKEN], RTN_TOKS) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23509 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23509 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    _2 = (int)SEQ_PTR(_23509);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _23510 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _23510 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _23509 = NOVALUE;
    _23511 = find_from(_23510, _37RTN_TOKS_15594, 1);
    _23510 = NOVALUE;
    if (_23511 == 0)
    {
        _23511 = NOVALUE;
        goto LA; // [256] 341
    }
    else{
        _23511 = NOVALUE;
    }

    /** 				if is_exported( s ) then*/
    Ref(_s_44408);
    _23512 = _57is_exported(_s_44408);
    if (_23512 == 0) {
        DeRef(_23512);
        _23512 = NOVALUE;
        goto LB; // [265] 340
    }
    else {
        if (!IS_ATOM_INT(_23512) && DBL_PTR(_23512)->dbl == 0.0){
            DeRef(_23512);
            _23512 = NOVALUE;
            goto LB; // [265] 340
        }
        DeRef(_23512);
        _23512 = NOVALUE;
    }
    DeRef(_23512);
    _23512 = NOVALUE;

    /** 					printf(fh, "EXPORT %s='__%d%s@%d'" & HOSTNL,*/
    Concat((object_ptr)&_23514, _23513, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23515 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23515 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    _2 = (int)SEQ_PTR(_23515);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _23516 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _23516 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _23515 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23517 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23517 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    _2 = (int)SEQ_PTR(_23517);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _23518 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _23518 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _23517 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23519 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23519 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    _2 = (int)SEQ_PTR(_23519);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _23520 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _23520 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _23519 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23521 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23521 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    _2 = (int)SEQ_PTR(_23521);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _23522 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _23522 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _23521 = NOVALUE;
    if (IS_ATOM_INT(_23522)) {
        if (_23522 == (short)_23522)
        _23523 = _23522 * 4;
        else
        _23523 = NewDouble(_23522 * (double)4);
    }
    else {
        _23523 = binary_op(MULTIPLY, _23522, 4);
    }
    _23522 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23516);
    *((int *)(_2+4)) = _23516;
    Ref(_23518);
    *((int *)(_2+8)) = _23518;
    Ref(_23520);
    *((int *)(_2+12)) = _23520;
    *((int *)(_2+16)) = _23523;
    _23524 = MAKE_SEQ(_1);
    _23523 = NOVALUE;
    _23520 = NOVALUE;
    _23518 = NOVALUE;
    _23516 = NOVALUE;
    EPrintf(_fh_44360, _23514, _23524);
    DeRefDS(_23514);
    _23514 = NOVALUE;
    DeRefDS(_23524);
    _23524 = NOVALUE;
LB: 
LA: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_s_44408)){
        _23525 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_s_44408)->dbl));
    }
    else{
        _23525 = (int)*(((s1_ptr)_2)->base + _s_44408);
    }
    DeRef(_s_44408);
    _2 = (int)SEQ_PTR(_23525);
    _s_44408 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_s_44408);
    _23525 = NOVALUE;

    /** 		end while*/
    goto L8; // [357] 232
L9: 
L7: 
    DeRef(_s_44408);
    _s_44408 = NOVALUE;

    /** 	close(fh)*/
    EClose(_fh_44360);

    /** 	generated_files = append(generated_files, file0 & ".lnk")*/
    Concat((object_ptr)&_23527, _57file0_43168, _23480);
    RefDS(_23527);
    Append(&_57generated_files_41334, _57generated_files_41334, _23527);
    DeRefDS(_23527);
    _23527 = NOVALUE;

    /** end procedure*/
    DeRef(_settings_44358);
    _23485 = NOVALUE;
    DeRef(_23505);
    _23505 = NOVALUE;
    return;
    ;
}


void _55write_makefile_srcobj_list(int _fh_44457)
{
    int _23552 = NOVALUE;
    int _23551 = NOVALUE;
    int _23550 = NOVALUE;
    int _23549 = NOVALUE;
    int _23548 = NOVALUE;
    int _23546 = NOVALUE;
    int _23545 = NOVALUE;
    int _23544 = NOVALUE;
    int _23543 = NOVALUE;
    int _23542 = NOVALUE;
    int _23541 = NOVALUE;
    int _23540 = NOVALUE;
    int _23538 = NOVALUE;
    int _23537 = NOVALUE;
    int _23535 = NOVALUE;
    int _23534 = NOVALUE;
    int _23533 = NOVALUE;
    int _23532 = NOVALUE;
    int _23531 = NOVALUE;
    int _23530 = NOVALUE;
    int _0, _1, _2;
    

    /** 	printf(fh, "%s_SOURCES =", { upper(file0) })*/
    RefDS(_57file0_43168);
    _23530 = _14upper(_57file0_43168);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23530;
    _23531 = MAKE_SEQ(_1);
    _23530 = NOVALUE;
    EPrintf(_fh_44457, _23529, _23531);
    DeRefDS(_23531);
    _23531 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23532 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23532 = 1;
    }
    {
        int _i_44464;
        _i_44464 = 1;
L1: 
        if (_i_44464 > _23532){
            goto L2; // [26] 75
        }

        /** 		if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23533 = (int)*(((s1_ptr)_2)->base + _i_44464);
        if (IS_SEQUENCE(_23533)){
                _23534 = SEQ_PTR(_23533)->length;
        }
        else {
            _23534 = 1;
        }
        _2 = (int)SEQ_PTR(_23533);
        _23535 = (int)*(((s1_ptr)_2)->base + _23534);
        _23533 = NOVALUE;
        if (binary_op_a(NOTEQ, _23535, 99)){
            _23535 = NOVALUE;
            goto L3; // [48] 68
        }
        _23535 = NOVALUE;

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23537 = (int)*(((s1_ptr)_2)->base + _i_44464);
        Concat((object_ptr)&_23538, _23095, _23537);
        _23537 = NOVALUE;
        EPuts(_fh_44457, _23538); // DJP 
        DeRefDS(_23538);
        _23538 = NOVALUE;
L3: 

        /** 	end for*/
        _i_44464 = _i_44464 + 1;
        goto L1; // [70] 33
L2: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44457, _40HOSTNL_16127); // DJP 

    /** 	printf(fh, "%s_OBJECTS =", { upper(file0) })*/
    RefDS(_57file0_43168);
    _23540 = _14upper(_57file0_43168);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23540;
    _23541 = MAKE_SEQ(_1);
    _23540 = NOVALUE;
    EPrintf(_fh_44457, _23539, _23541);
    DeRefDS(_23541);
    _23541 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23542 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23542 = 1;
    }
    {
        int _i_44483;
        _i_44483 = 1;
L4: 
        if (_i_44483 > _23542){
            goto L5; // [105] 151
        }

        /** 		if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23543 = (int)*(((s1_ptr)_2)->base + _i_44483);
        _23544 = e_match_from(_22855, _23543, 1);
        _23543 = NOVALUE;
        if (_23544 == 0)
        {
            _23544 = NOVALUE;
            goto L6; // [125] 144
        }
        else{
            _23544 = NOVALUE;
        }

        /** 			puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23545 = (int)*(((s1_ptr)_2)->base + _i_44483);
        Concat((object_ptr)&_23546, _23095, _23545);
        _23545 = NOVALUE;
        EPuts(_fh_44457, _23546); // DJP 
        DeRefDS(_23546);
        _23546 = NOVALUE;
L6: 

        /** 	end for*/
        _i_44483 = _i_44483 + 1;
        goto L4; // [146] 112
L5: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44457, _40HOSTNL_16127); // DJP 

    /** 	printf(fh, "%s_GENERATED_FILES = ", { upper(file0) })*/
    RefDS(_57file0_43168);
    _23548 = _14upper(_57file0_43168);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23548;
    _23549 = MAKE_SEQ(_1);
    _23548 = NOVALUE;
    EPrintf(_fh_44457, _23547, _23549);
    DeRefDS(_23549);
    _23549 = NOVALUE;

    /** 	for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23550 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23550 = 1;
    }
    {
        int _i_44500;
        _i_44500 = 1;
L7: 
        if (_i_44500 > _23550){
            goto L8; // [181] 210
        }

        /** 		puts(fh, " " & generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23551 = (int)*(((s1_ptr)_2)->base + _i_44500);
        Concat((object_ptr)&_23552, _23095, _23551);
        _23551 = NOVALUE;
        EPuts(_fh_44457, _23552); // DJP 
        DeRefDS(_23552);
        _23552 = NOVALUE;

        /** 	end for*/
        _i_44500 = _i_44500 + 1;
        goto L7; // [205] 188
L8: 
        ;
    }

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44457, _40HOSTNL_16127); // DJP 

    /** end procedure*/
    return;
    ;
}


int _55windows_to_mingw_path(int _s_44509)
{
    int _23554 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef TEST_FOR_WIN9X_ON_MING then*/

    /** 	return search:find_replace('\\',s,'/')*/
    RefDS(_s_44509);
    _23554 = _16find_replace(92, _s_44509, 47, 0);
    DeRefDS(_s_44509);
    return _23554;
    ;
}


void _55write_makefile_full()
{
    int _settings_44514 = NOVALUE;
    int _fh_44517 = NOVALUE;
    int _23678 = NOVALUE;
    int _23676 = NOVALUE;
    int _23674 = NOVALUE;
    int _23673 = NOVALUE;
    int _23672 = NOVALUE;
    int _23671 = NOVALUE;
    int _23670 = NOVALUE;
    int _23668 = NOVALUE;
    int _23667 = NOVALUE;
    int _23665 = NOVALUE;
    int _23664 = NOVALUE;
    int _23663 = NOVALUE;
    int _23662 = NOVALUE;
    int _23660 = NOVALUE;
    int _23659 = NOVALUE;
    int _23657 = NOVALUE;
    int _23656 = NOVALUE;
    int _23654 = NOVALUE;
    int _23653 = NOVALUE;
    int _23652 = NOVALUE;
    int _23651 = NOVALUE;
    int _23650 = NOVALUE;
    int _23649 = NOVALUE;
    int _23648 = NOVALUE;
    int _23647 = NOVALUE;
    int _23645 = NOVALUE;
    int _23644 = NOVALUE;
    int _23643 = NOVALUE;
    int _23642 = NOVALUE;
    int _23641 = NOVALUE;
    int _23640 = NOVALUE;
    int _23639 = NOVALUE;
    int _23638 = NOVALUE;
    int _23637 = NOVALUE;
    int _23636 = NOVALUE;
    int _23635 = NOVALUE;
    int _23634 = NOVALUE;
    int _23633 = NOVALUE;
    int _23631 = NOVALUE;
    int _23629 = NOVALUE;
    int _23627 = NOVALUE;
    int _23626 = NOVALUE;
    int _23625 = NOVALUE;
    int _23624 = NOVALUE;
    int _23623 = NOVALUE;
    int _23622 = NOVALUE;
    int _23621 = NOVALUE;
    int _23620 = NOVALUE;
    int _23619 = NOVALUE;
    int _23618 = NOVALUE;
    int _23617 = NOVALUE;
    int _23616 = NOVALUE;
    int _23615 = NOVALUE;
    int _23614 = NOVALUE;
    int _23612 = NOVALUE;
    int _23611 = NOVALUE;
    int _23610 = NOVALUE;
    int _23609 = NOVALUE;
    int _23608 = NOVALUE;
    int _23607 = NOVALUE;
    int _23606 = NOVALUE;
    int _23605 = NOVALUE;
    int _23604 = NOVALUE;
    int _23602 = NOVALUE;
    int _23601 = NOVALUE;
    int _23600 = NOVALUE;
    int _23599 = NOVALUE;
    int _23597 = NOVALUE;
    int _23596 = NOVALUE;
    int _23595 = NOVALUE;
    int _23594 = NOVALUE;
    int _23593 = NOVALUE;
    int _23592 = NOVALUE;
    int _23590 = NOVALUE;
    int _23589 = NOVALUE;
    int _23588 = NOVALUE;
    int _23587 = NOVALUE;
    int _23586 = NOVALUE;
    int _23585 = NOVALUE;
    int _23584 = NOVALUE;
    int _23582 = NOVALUE;
    int _23581 = NOVALUE;
    int _23580 = NOVALUE;
    int _23579 = NOVALUE;
    int _23576 = NOVALUE;
    int _23575 = NOVALUE;
    int _23574 = NOVALUE;
    int _23571 = NOVALUE;
    int _23570 = NOVALUE;
    int _23569 = NOVALUE;
    int _23567 = NOVALUE;
    int _23566 = NOVALUE;
    int _23565 = NOVALUE;
    int _23563 = NOVALUE;
    int _23562 = NOVALUE;
    int _23561 = NOVALUE;
    int _23558 = NOVALUE;
    int _23556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44514;
    _settings_44514 = _55setup_build();
    DeRef(_0);

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44514);
    _23556 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23556);
    _55ensure_exename(_23556);
    _23556 = NOVALUE;

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23557;
        concat_list[1] = _57file0_43168;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_23558, concat_list, 3);
    }
    _fh_44517 = EOpen(_23558, _23482, 0);
    DeRefDS(_23558);
    _23558 = NOVALUE;

    /** 	printf(fh, "CC     = %s" & HOSTNL, { settings[SETUP_CEXE] })*/
    Concat((object_ptr)&_23561, _23560, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_settings_44514);
    _23562 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23562);
    *((int *)(_2+4)) = _23562;
    _23563 = MAKE_SEQ(_1);
    _23562 = NOVALUE;
    EPrintf(_fh_44517, _23561, _23563);
    DeRefDS(_23561);
    _23561 = NOVALUE;
    DeRefDS(_23563);
    _23563 = NOVALUE;

    /** 	printf(fh, "CFLAGS = %s" & HOSTNL, { settings[SETUP_CFLAGS] })*/
    Concat((object_ptr)&_23565, _23564, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_settings_44514);
    _23566 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23566);
    *((int *)(_2+4)) = _23566;
    _23567 = MAKE_SEQ(_1);
    _23566 = NOVALUE;
    EPrintf(_fh_44517, _23565, _23567);
    DeRefDS(_23565);
    _23565 = NOVALUE;
    DeRefDS(_23567);
    _23567 = NOVALUE;

    /** 	printf(fh, "LINKER = %s" & HOSTNL, { settings[SETUP_LEXE] })*/
    Concat((object_ptr)&_23569, _23568, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_settings_44514);
    _23570 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23570);
    *((int *)(_2+4)) = _23570;
    _23571 = MAKE_SEQ(_1);
    _23570 = NOVALUE;
    EPrintf(_fh_44517, _23569, _23571);
    DeRefDS(_23569);
    _23569 = NOVALUE;
    DeRefDS(_23571);
    _23571 = NOVALUE;

    /** 	if compiler_type = COMPILER_GCC then*/
    if (_55compiler_type_43986 != 1)
    goto L1; // [98] 125

    /** 		printf(fh, "LFLAGS = %s" & HOSTNL, { settings[SETUP_LFLAGS] })*/
    Concat((object_ptr)&_23574, _23573, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_settings_44514);
    _23575 = (int)*(((s1_ptr)_2)->base + 4);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23575);
    *((int *)(_2+4)) = _23575;
    _23576 = MAKE_SEQ(_1);
    _23575 = NOVALUE;
    EPrintf(_fh_44517, _23574, _23576);
    DeRefDS(_23574);
    _23574 = NOVALUE;
    DeRefDS(_23576);
    _23576 = NOVALUE;
    goto L2; // [122] 130
L1: 

    /** 		write_objlink_file()*/
    _55write_objlink_file();
L2: 

    /** 	write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_44517);

    /** 	puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_43986 != 2)
    goto L3; // [146] 575

    /** 		printf(fh, "\"%s\" : $(%s_OBJECTS) %s" & HOSTNL, { */
    Concat((object_ptr)&_23579, _23578, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23580 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_43168);
    _23581 = _14upper(_57file0_43168);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23580);
    *((int *)(_2+4)) = _23580;
    *((int *)(_2+8)) = _23581;
    RefDS(_57user_library_41342);
    *((int *)(_2+12)) = _57user_library_41342;
    _23582 = MAKE_SEQ(_1);
    _23581 = NOVALUE;
    _23580 = NOVALUE;
    EPrintf(_fh_44517, _23579, _23582);
    DeRefDS(_23579);
    _23579 = NOVALUE;
    DeRefDS(_23582);
    _23582 = NOVALUE;

    /** 		printf(fh, "\t$(LINKER) @%s.lnk" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23584, _23583, _40HOSTNL_16127);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43168);
    *((int *)(_2+4)) = _57file0_43168;
    _23585 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23584, _23585);
    DeRefDS(_23584);
    _23584 = NOVALUE;
    DeRefDS(_23585);
    _23585 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23586 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23586)){
            _23587 = SEQ_PTR(_23586)->length;
    }
    else {
        _23587 = 1;
    }
    _23586 = NOVALUE;
    if (_23587 == 0) {
        goto L4; // [215] 277
    }
    _2 = (int)SEQ_PTR(_settings_44514);
    _23589 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23589)){
            _23590 = SEQ_PTR(_23589)->length;
    }
    else {
        _23590 = 1;
    }
    _23589 = NOVALUE;
    if (_23590 == 0)
    {
        _23590 = NOVALUE;
        goto L4; // [227] 277
    }
    else{
        _23590 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44514);
    _23592 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23591) && IS_ATOM(_23592)) {
        Ref(_23592);
        Append(&_23593, _23591, _23592);
    }
    else if (IS_ATOM(_23591) && IS_SEQUENCE(_23592)) {
    }
    else {
        Concat((object_ptr)&_23593, _23591, _23592);
    }
    _23592 = NOVALUE;
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23594 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23595 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23596 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23594);
    *((int *)(_2+4)) = _23594;
    Ref(_23595);
    *((int *)(_2+8)) = _23595;
    Ref(_23596);
    *((int *)(_2+12)) = _23596;
    _23597 = MAKE_SEQ(_1);
    _23596 = NOVALUE;
    _23595 = NOVALUE;
    _23594 = NOVALUE;
    _8writef(_fh_44517, _23593, _23597, 0);
    _23593 = NOVALUE;
    _23597 = NOVALUE;
L4: 

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		printf(fh, "%s-clean : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23599, _23598, _40HOSTNL_16127);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43168);
    *((int *)(_2+4)) = _57file0_43168;
    _23600 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23599, _23600);
    DeRefDS(_23599);
    _23599 = NOVALUE;
    DeRefDS(_23600);
    _23600 = NOVALUE;

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23601 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23601)){
            _23602 = SEQ_PTR(_23601)->length;
    }
    else {
        _23602 = 1;
    }
    _23601 = NOVALUE;
    if (_23602 == 0)
    {
        _23602 = NOVALUE;
        goto L5; // [315] 343
    }
    else{
        _23602 = NOVALUE;
    }

    /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23604, _23603, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23605 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23605);
    *((int *)(_2+4)) = _23605;
    _23606 = MAKE_SEQ(_1);
    _23605 = NOVALUE;
    EPrintf(_fh_44517, _23604, _23606);
    DeRefDS(_23604);
    _23604 = NOVALUE;
    DeRefDS(_23606);
    _23606 = NOVALUE;
L5: 

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23607 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23607 = 1;
    }
    {
        int _i_44599;
        _i_44599 = 1;
L6: 
        if (_i_44599 > _23607){
            goto L7; // [350] 403
        }

        /** 			if match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23608 = (int)*(((s1_ptr)_2)->base + _i_44599);
        _23609 = e_match_from(_22855, _23608, 1);
        _23608 = NOVALUE;
        if (_23609 == 0)
        {
            _23609 = NOVALUE;
            goto L8; // [370] 396
        }
        else{
            _23609 = NOVALUE;
        }

        /** 				printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23610, _23603, _40HOSTNL_16127);
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23611 = (int)*(((s1_ptr)_2)->base + _i_44599);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23611);
        *((int *)(_2+4)) = _23611;
        _23612 = MAKE_SEQ(_1);
        _23611 = NOVALUE;
        EPrintf(_fh_44517, _23610, _23612);
        DeRefDS(_23610);
        _23610 = NOVALUE;
        DeRefDS(_23612);
        _23612 = NOVALUE;
L8: 

        /** 		end for*/
        _i_44599 = _i_44599 + 1;
        goto L6; // [398] 357
L7: 
        ;
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		printf(fh, "%s-clean-all : .SYMBOLIC" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23614, _23613, _40HOSTNL_16127);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43168);
    *((int *)(_2+4)) = _57file0_43168;
    _23615 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23614, _23615);
    DeRefDS(_23614);
    _23614 = NOVALUE;
    DeRefDS(_23615);
    _23615 = NOVALUE;

    /** 		printf(fh, "\tdel \"%s\"" & HOSTNL, { exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23616, _23603, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23617 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23617);
    *((int *)(_2+4)) = _23617;
    _23618 = MAKE_SEQ(_1);
    _23617 = NOVALUE;
    EPrintf(_fh_44517, _23616, _23618);
    DeRefDS(_23616);
    _23616 = NOVALUE;
    DeRefDS(_23618);
    _23618 = NOVALUE;

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23619 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23619)){
            _23620 = SEQ_PTR(_23619)->length;
    }
    else {
        _23620 = 1;
    }
    _23619 = NOVALUE;
    if (_23620 == 0)
    {
        _23620 = NOVALUE;
        goto L9; // [465] 493
    }
    else{
        _23620 = NOVALUE;
    }

    /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23621, _23603, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23622 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23622);
    *((int *)(_2+4)) = _23622;
    _23623 = MAKE_SEQ(_1);
    _23622 = NOVALUE;
    EPrintf(_fh_44517, _23621, _23623);
    DeRefDS(_23621);
    _23621 = NOVALUE;
    DeRefDS(_23623);
    _23623 = NOVALUE;
L9: 

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23624 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23624 = 1;
    }
    {
        int _i_44632;
        _i_44632 = 1;
LA: 
        if (_i_44632 > _23624){
            goto LB; // [500] 536
        }

        /** 			printf(fh, "\tdel \"%s\"" & HOSTNL, { generated_files[i] })*/
        Concat((object_ptr)&_23625, _23603, _40HOSTNL_16127);
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23626 = (int)*(((s1_ptr)_2)->base + _i_44632);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23626);
        *((int *)(_2+4)) = _23626;
        _23627 = MAKE_SEQ(_1);
        _23626 = NOVALUE;
        EPrintf(_fh_44517, _23625, _23627);
        DeRefDS(_23625);
        _23625 = NOVALUE;
        DeRefDS(_23627);
        _23627 = NOVALUE;

        /** 		end for*/
        _i_44632 = _i_44632 + 1;
        goto LA; // [531] 507
LB: 
        ;
    }

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		puts(fh, ".c.obj : .autodepend" & HOSTNL)*/
    Concat((object_ptr)&_23629, _23628, _40HOSTNL_16127);
    EPuts(_fh_44517, _23629); // DJP 
    DeRefDS(_23629);
    _23629 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $<" & HOSTNL)*/
    Concat((object_ptr)&_23631, _23630, _40HOSTNL_16127);
    EPuts(_fh_44517, _23631); // DJP 
    DeRefDS(_23631);
    _23631 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 
    goto LC; // [572] 922
L3: 

    /** 		printf(fh, "%s: $(%s_OBJECTS) %s %s" & HOSTNL, { adjust_for_build_file(exe_name[D_ALTNAME]), upper(file0), user_library, rc_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23633, _23632, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23634 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23634);
    _23635 = _55adjust_for_build_file(_23634);
    _23634 = NOVALUE;
    RefDS(_57file0_43168);
    _23636 = _14upper(_57file0_43168);
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23637 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23635;
    *((int *)(_2+8)) = _23636;
    RefDS(_57user_library_41342);
    *((int *)(_2+12)) = _57user_library_41342;
    Ref(_23637);
    *((int *)(_2+16)) = _23637;
    _23638 = MAKE_SEQ(_1);
    _23637 = NOVALUE;
    _23636 = NOVALUE;
    _23635 = NOVALUE;
    EPrintf(_fh_44517, _23633, _23638);
    DeRefDS(_23633);
    _23633 = NOVALUE;
    DeRefDS(_23638);
    _23638 = NOVALUE;

    /** 		if length(rc_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23639 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23639)){
            _23640 = SEQ_PTR(_23639)->length;
    }
    else {
        _23640 = 1;
    }
    _23639 = NOVALUE;
    if (_23640 == 0)
    {
        _23640 = NOVALUE;
        goto LD; // [635] 679
    }
    else{
        _23640 = NOVALUE;
    }

    /** 			writef(fh, "\t" & settings[SETUP_RC_COMPILER] & HOSTNL, { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44514);
    _23641 = (int)*(((s1_ptr)_2)->base + 8);
    {
        int concat_list[3];

        concat_list[0] = _40HOSTNL_16127;
        concat_list[1] = _23641;
        concat_list[2] = _23591;
        Concat_N((object_ptr)&_23642, concat_list, 3);
    }
    _23641 = NOVALUE;
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23643 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23644 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23644);
    Ref(_23643);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23643;
    ((int *)_2)[2] = _23644;
    _23645 = MAKE_SEQ(_1);
    _23644 = NOVALUE;
    _23643 = NOVALUE;
    _8writef(_fh_44517, _23642, _23645, 0);
    _23642 = NOVALUE;
    _23645 = NOVALUE;
LD: 

    /** 		printf(fh, "\t$(LINKER) -o %s $(%s_OBJECTS) %s $(LFLAGS)" & HOSTNL, {*/
    Concat((object_ptr)&_23647, _23646, _40HOSTNL_16127);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23648 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_57file0_43168);
    _23649 = _14upper(_57file0_43168);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23650 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23650)){
            _23651 = SEQ_PTR(_23650)->length;
    }
    else {
        _23651 = 1;
    }
    _23650 = NOVALUE;
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23652 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23652);
    RefDS(_21815);
    _23653 = _56iif(_23651, _23652, _21815);
    _23651 = NOVALUE;
    _23652 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23648);
    *((int *)(_2+4)) = _23648;
    *((int *)(_2+8)) = _23649;
    *((int *)(_2+12)) = _23653;
    _23654 = MAKE_SEQ(_1);
    _23653 = NOVALUE;
    _23649 = NOVALUE;
    _23648 = NOVALUE;
    EPrintf(_fh_44517, _23647, _23654);
    DeRefDS(_23647);
    _23647 = NOVALUE;
    DeRefDS(_23654);
    _23654 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		printf(fh, ".PHONY: %s-clean %s-clean-all" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23656, _23655, _40HOSTNL_16127);
    RefDS(_57file0_43168);
    RefDS(_57file0_43168);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _57file0_43168;
    ((int *)_2)[2] = _57file0_43168;
    _23657 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23656, _23657);
    DeRefDS(_23656);
    _23656 = NOVALUE;
    DeRefDS(_23657);
    _23657 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		printf(fh, "%s-clean:" & HOSTNL, { file0 })*/
    Concat((object_ptr)&_23659, _23658, _40HOSTNL_16127);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_57file0_43168);
    *((int *)(_2+4)) = _57file0_43168;
    _23660 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23659, _23660);
    DeRefDS(_23659);
    _23659 = NOVALUE;
    DeRefDS(_23660);
    _23660 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_OBJECTS) %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME] })*/
    Concat((object_ptr)&_23662, _23661, _40HOSTNL_16127);
    RefDS(_57file0_43168);
    _23663 = _14upper(_57file0_43168);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23664 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23664);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23663;
    ((int *)_2)[2] = _23664;
    _23665 = MAKE_SEQ(_1);
    _23664 = NOVALUE;
    _23663 = NOVALUE;
    EPrintf(_fh_44517, _23662, _23665);
    DeRefDS(_23662);
    _23662 = NOVALUE;
    DeRefDS(_23665);
    _23665 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		printf(fh, "%s-clean-all: %s-clean" & HOSTNL, { file0, file0 })*/
    Concat((object_ptr)&_23667, _23666, _40HOSTNL_16127);
    RefDS(_57file0_43168);
    RefDS(_57file0_43168);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _57file0_43168;
    ((int *)_2)[2] = _57file0_43168;
    _23668 = MAKE_SEQ(_1);
    EPrintf(_fh_44517, _23667, _23668);
    DeRefDS(_23667);
    _23667 = NOVALUE;
    DeRefDS(_23668);
    _23668 = NOVALUE;

    /** 		printf(fh, "\trm -rf $(%s_SOURCES) %s %s" & HOSTNL, { upper(file0), res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    Concat((object_ptr)&_23670, _23669, _40HOSTNL_16127);
    RefDS(_57file0_43168);
    _23671 = _14upper(_57file0_43168);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23672 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23673 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23671;
    Ref(_23672);
    *((int *)(_2+8)) = _23672;
    Ref(_23673);
    *((int *)(_2+12)) = _23673;
    _23674 = MAKE_SEQ(_1);
    _23673 = NOVALUE;
    _23672 = NOVALUE;
    _23671 = NOVALUE;
    EPrintf(_fh_44517, _23670, _23674);
    DeRefDS(_23670);
    _23670 = NOVALUE;
    DeRefDS(_23674);
    _23674 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 

    /** 		puts(fh, "%.o: %.c" & HOSTNL)*/
    Concat((object_ptr)&_23676, _23675, _40HOSTNL_16127);
    EPuts(_fh_44517, _23676); // DJP 
    DeRefDS(_23676);
    _23676 = NOVALUE;

    /** 		puts(fh, "\t$(CC) $(CFLAGS) $*.c -o $*.o" & HOSTNL)*/
    Concat((object_ptr)&_23678, _23677, _40HOSTNL_16127);
    EPuts(_fh_44517, _23678); // DJP 
    DeRefDS(_23678);
    _23678 = NOVALUE;

    /** 		puts(fh, HOSTNL)*/
    EPuts(_fh_44517, _40HOSTNL_16127); // DJP 
LC: 

    /** 	close(fh)*/
    EClose(_fh_44517);

    /** end procedure*/
    DeRef(_settings_44514);
    _23586 = NOVALUE;
    _23589 = NOVALUE;
    _23601 = NOVALUE;
    _23619 = NOVALUE;
    _23639 = NOVALUE;
    _23650 = NOVALUE;
    return;
    ;
}


void _55write_makefile_partial()
{
    int _settings_44741 = NOVALUE;
    int _fh_44743 = NOVALUE;
    int _23680 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence settings = setup_build()*/
    _0 = _settings_44741;
    _settings_44741 = _55setup_build();
    DeRef(_0);

    /** 	integer fh = open(output_dir & file0 & ".mak", "wb")*/
    {
        int concat_list[3];

        concat_list[0] = _23557;
        concat_list[1] = _57file0_43168;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_23680, concat_list, 3);
    }
    _fh_44743 = EOpen(_23680, _23482, 0);
    DeRefDS(_23680);
    _23680 = NOVALUE;

    /** 	write_makefile_srcobj_list(fh)*/
    _55write_makefile_srcobj_list(_fh_44743);

    /** 	close(fh)*/
    EClose(_fh_44743);

    /** end procedure*/
    DeRefDS(_settings_44741);
    return;
    ;
}


void _55build_direct(int _link_only_44750, int _the_file0_44751)
{
    int _cmd_44757 = NOVALUE;
    int _objs_44758 = NOVALUE;
    int _settings_44759 = NOVALUE;
    int _cwd_44761 = NOVALUE;
    int _status_44764 = NOVALUE;
    int _link_files_44793 = NOVALUE;
    int _pdone_44819 = NOVALUE;
    int _files_44865 = NOVALUE;
    int _31385 = NOVALUE;
    int _31384 = NOVALUE;
    int _31383 = NOVALUE;
    int _31382 = NOVALUE;
    int _31381 = NOVALUE;
    int _31380 = NOVALUE;
    int _31379 = NOVALUE;
    int _23828 = NOVALUE;
    int _23827 = NOVALUE;
    int _23825 = NOVALUE;
    int _23824 = NOVALUE;
    int _23823 = NOVALUE;
    int _23822 = NOVALUE;
    int _23821 = NOVALUE;
    int _23820 = NOVALUE;
    int _23819 = NOVALUE;
    int _23818 = NOVALUE;
    int _23816 = NOVALUE;
    int _23815 = NOVALUE;
    int _23814 = NOVALUE;
    int _23813 = NOVALUE;
    int _23809 = NOVALUE;
    int _23808 = NOVALUE;
    int _23807 = NOVALUE;
    int _23806 = NOVALUE;
    int _23805 = NOVALUE;
    int _23804 = NOVALUE;
    int _23803 = NOVALUE;
    int _23802 = NOVALUE;
    int _23801 = NOVALUE;
    int _23800 = NOVALUE;
    int _23799 = NOVALUE;
    int _23798 = NOVALUE;
    int _23797 = NOVALUE;
    int _23796 = NOVALUE;
    int _23795 = NOVALUE;
    int _23792 = NOVALUE;
    int _23791 = NOVALUE;
    int _23790 = NOVALUE;
    int _23789 = NOVALUE;
    int _23786 = NOVALUE;
    int _23784 = NOVALUE;
    int _23783 = NOVALUE;
    int _23782 = NOVALUE;
    int _23781 = NOVALUE;
    int _23780 = NOVALUE;
    int _23779 = NOVALUE;
    int _23776 = NOVALUE;
    int _23775 = NOVALUE;
    int _23771 = NOVALUE;
    int _23770 = NOVALUE;
    int _23769 = NOVALUE;
    int _23765 = NOVALUE;
    int _23764 = NOVALUE;
    int _23763 = NOVALUE;
    int _23762 = NOVALUE;
    int _23761 = NOVALUE;
    int _23760 = NOVALUE;
    int _23759 = NOVALUE;
    int _23758 = NOVALUE;
    int _23757 = NOVALUE;
    int _23756 = NOVALUE;
    int _23755 = NOVALUE;
    int _23754 = NOVALUE;
    int _23752 = NOVALUE;
    int _23751 = NOVALUE;
    int _23750 = NOVALUE;
    int _23749 = NOVALUE;
    int _23748 = NOVALUE;
    int _23746 = NOVALUE;
    int _23745 = NOVALUE;
    int _23744 = NOVALUE;
    int _23743 = NOVALUE;
    int _23742 = NOVALUE;
    int _23740 = NOVALUE;
    int _23738 = NOVALUE;
    int _23737 = NOVALUE;
    int _23736 = NOVALUE;
    int _23735 = NOVALUE;
    int _23733 = NOVALUE;
    int _23732 = NOVALUE;
    int _23731 = NOVALUE;
    int _23728 = NOVALUE;
    int _23727 = NOVALUE;
    int _23726 = NOVALUE;
    int _23725 = NOVALUE;
    int _23724 = NOVALUE;
    int _23723 = NOVALUE;
    int _23722 = NOVALUE;
    int _23721 = NOVALUE;
    int _23720 = NOVALUE;
    int _23719 = NOVALUE;
    int _23716 = NOVALUE;
    int _23715 = NOVALUE;
    int _23712 = NOVALUE;
    int _23710 = NOVALUE;
    int _23709 = NOVALUE;
    int _23708 = NOVALUE;
    int _23707 = NOVALUE;
    int _23704 = NOVALUE;
    int _23703 = NOVALUE;
    int _23702 = NOVALUE;
    int _23701 = NOVALUE;
    int _23699 = NOVALUE;
    int _23698 = NOVALUE;
    int _23697 = NOVALUE;
    int _23696 = NOVALUE;
    int _23695 = NOVALUE;
    int _23692 = NOVALUE;
    int _23686 = NOVALUE;
    int _23682 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_link_only_44750)) {
        _1 = (long)(DBL_PTR(_link_only_44750)->dbl);
        DeRefDS(_link_only_44750);
        _link_only_44750 = _1;
    }

    /** 	if length(the_file0) then*/
    if (IS_SEQUENCE(_the_file0_44751)){
            _23682 = SEQ_PTR(_the_file0_44751)->length;
    }
    else {
        _23682 = 1;
    }
    if (_23682 == 0)
    {
        _23682 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _23682 = NOVALUE;
    }

    /** 		file0 = filebase(the_file0)*/
    RefDS(_the_file0_44751);
    _0 = _17filebase(_the_file0_44751);
    DeRef(_57file0_43168);
    _57file0_43168 = _0;
L1: 

    /** 	sequence cmd, objs = "", settings = setup_build(), cwd = current_dir()*/
    RefDS(_21815);
    DeRef(_objs_44758);
    _objs_44758 = _21815;
    _0 = _settings_44759;
    _settings_44759 = _55setup_build();
    DeRef(_0);
    _0 = _cwd_44761;
    _cwd_44761 = _17current_dir();
    DeRef(_0);

    /** 	integer status*/

    /** 	ensure_exename(settings[SETUP_EXE_EXT])*/
    _2 = (int)SEQ_PTR(_settings_44759);
    _23686 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_23686);
    _55ensure_exename(_23686);
    _23686 = NOVALUE;

    /** 	if not link_only then*/
    if (_link_only_44750 != 0)
    goto L2; // [52] 120

    /** 		switch compiler_type do*/
    _0 = _55compiler_type_43986;
    switch ( _0 ){ 

        /** 			case COMPILER_GCC then*/
        case 1:

        /** 				if not silent then*/
        if (_35silent_16083 != 0)
        goto L3; // [72] 119

        /** 					ShowMsg(1, 176, {"GCC"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23691);
        *((int *)(_2+4)) = _23691;
        _23692 = MAKE_SEQ(_1);
        _45ShowMsg(1, 176, _23692, 1);
        _23692 = NOVALUE;
        goto L3; // [88] 119

        /** 			case COMPILER_WATCOM then*/
        case 2:

        /** 				write_objlink_file()*/
        _55write_objlink_file();

        /** 				if not silent then*/
        if (_35silent_16083 != 0)
        goto L4; // [102] 118

        /** 					ShowMsg(1, 176, {"Watcom"})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23694);
        *((int *)(_2+4)) = _23694;
        _23695 = MAKE_SEQ(_1);
        _45ShowMsg(1, 176, _23695, 1);
        _23695 = NOVALUE;
L4: 
    ;}L3: 
L2: 

    /** 	if sequence(output_dir) and length(output_dir) > 0 then*/
    _23696 = 1;
    if (_23696 == 0) {
        goto L5; // [127] 155
    }
    if (IS_SEQUENCE(_57output_dir_41343)){
            _23698 = SEQ_PTR(_57output_dir_41343)->length;
    }
    else {
        _23698 = 1;
    }
    _23699 = (_23698 > 0);
    _23698 = NOVALUE;
    if (_23699 == 0)
    {
        DeRef(_23699);
        _23699 = NOVALUE;
        goto L5; // [141] 155
    }
    else{
        DeRef(_23699);
        _23699 = NOVALUE;
    }

    /** 		chdir(output_dir)*/
    RefDS(_57output_dir_41343);
    _31385 = _17chdir(_57output_dir_41343);
    DeRef(_31385);
    _31385 = NOVALUE;
L5: 

    /** 	sequence link_files = {}*/
    RefDS(_21815);
    DeRef(_link_files_44793);
    _link_files_44793 = _21815;

    /** 	if not link_only then*/
    if (_link_only_44750 != 0)
    goto L6; // [164] 468

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23701 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23701 = 1;
    }
    {
        int _i_44797;
        _i_44797 = 1;
L7: 
        if (_i_44797 > _23701){
            goto L8; // [174] 465
        }

        /** 			if generated_files[i][$] = 'c' then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23702 = (int)*(((s1_ptr)_2)->base + _i_44797);
        if (IS_SEQUENCE(_23702)){
                _23703 = SEQ_PTR(_23702)->length;
        }
        else {
            _23703 = 1;
        }
        _2 = (int)SEQ_PTR(_23702);
        _23704 = (int)*(((s1_ptr)_2)->base + _23703);
        _23702 = NOVALUE;
        if (binary_op_a(NOTEQ, _23704, 99)){
            _23704 = NOVALUE;
            goto L9; // [196] 424
        }
        _23704 = NOVALUE;

        /** 				cmd = sprintf("%s %s %s", { settings[SETUP_CEXE], settings[SETUP_CFLAGS],*/
        _2 = (int)SEQ_PTR(_settings_44759);
        _23707 = (int)*(((s1_ptr)_2)->base + 1);
        _2 = (int)SEQ_PTR(_settings_44759);
        _23708 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23709 = (int)*(((s1_ptr)_2)->base + _i_44797);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23707);
        *((int *)(_2+4)) = _23707;
        Ref(_23708);
        *((int *)(_2+8)) = _23708;
        RefDS(_23709);
        *((int *)(_2+12)) = _23709;
        _23710 = MAKE_SEQ(_1);
        _23709 = NOVALUE;
        _23708 = NOVALUE;
        _23707 = NOVALUE;
        DeRef(_cmd_44757);
        _cmd_44757 = EPrintf(-9999999, _23706, _23710);
        DeRefDS(_23710);
        _23710 = NOVALUE;

        /** 				link_files = append(link_files, generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23712 = (int)*(((s1_ptr)_2)->base + _i_44797);
        RefDS(_23712);
        Append(&_link_files_44793, _link_files_44793, _23712);
        _23712 = NOVALUE;

        /** 				if not silent then*/
        if (_35silent_16083 != 0)
        goto LA; // [242] 364

        /** 					atom pdone = 100 * (i / length(generated_files))*/
        if (IS_SEQUENCE(_57generated_files_41334)){
                _23715 = SEQ_PTR(_57generated_files_41334)->length;
        }
        else {
            _23715 = 1;
        }
        _23716 = (_i_44797 % _23715) ? NewDouble((double)_i_44797 / _23715) : (_i_44797 / _23715);
        _23715 = NOVALUE;
        DeRef(_pdone_44819);
        if (IS_ATOM_INT(_23716)) {
            if (_23716 <= INT15 && _23716 >= -INT15)
            _pdone_44819 = 100 * _23716;
            else
            _pdone_44819 = NewDouble(100 * (double)_23716);
        }
        else {
            _pdone_44819 = NewDouble((double)100 * DBL_PTR(_23716)->dbl);
        }
        DeRef(_23716);
        _23716 = NOVALUE;

        /** 					if not verbose then*/
        if (_35verbose_16086 != 0)
        goto LB; // [264] 350

        /** 						if 0 and outdated_files[i] = 0 and force_build = 0 then*/
        if (0 == 0) {
            _23719 = 0;
            goto LC; // [269] 287
        }
        _2 = (int)SEQ_PTR(_57outdated_files_41335);
        _23720 = (int)*(((s1_ptr)_2)->base + _i_44797);
        if (IS_ATOM_INT(_23720)) {
            _23721 = (_23720 == 0);
        }
        else {
            _23721 = binary_op(EQUALS, _23720, 0);
        }
        _23720 = NOVALUE;
        if (IS_ATOM_INT(_23721))
        _23719 = (_23721 != 0);
        else
        _23719 = DBL_PTR(_23721)->dbl != 0.0;
LC: 
        if (_23719 == 0) {
            goto LD; // [287] 328
        }
        _23723 = (_55force_build_44005 == 0);
        if (_23723 == 0)
        {
            DeRef(_23723);
            _23723 = NOVALUE;
            goto LD; // [298] 328
        }
        else{
            DeRef(_23723);
            _23723 = NOVALUE;
        }

        /** 							ShowMsg(1, 325, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23724 = (int)*(((s1_ptr)_2)->base + _i_44797);
        RefDS(_23724);
        Ref(_pdone_44819);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44819;
        ((int *)_2)[2] = _23724;
        _23725 = MAKE_SEQ(_1);
        _23724 = NOVALUE;
        _45ShowMsg(1, 325, _23725, 1);
        _23725 = NOVALUE;

        /** 							continue*/
        DeRef(_pdone_44819);
        _pdone_44819 = NOVALUE;
        goto LE; // [323] 460
        goto LF; // [325] 363
LD: 

        /** 							ShowMsg(1, 163, { pdone, generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23726 = (int)*(((s1_ptr)_2)->base + _i_44797);
        RefDS(_23726);
        Ref(_pdone_44819);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44819;
        ((int *)_2)[2] = _23726;
        _23727 = MAKE_SEQ(_1);
        _23726 = NOVALUE;
        _45ShowMsg(1, 163, _23727, 1);
        _23727 = NOVALUE;
        goto LF; // [347] 363
LB: 

        /** 						ShowMsg(1, 163, { pdone, cmd })*/
        RefDS(_cmd_44757);
        Ref(_pdone_44819);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _pdone_44819;
        ((int *)_2)[2] = _cmd_44757;
        _23728 = MAKE_SEQ(_1);
        _45ShowMsg(1, 163, _23728, 1);
        _23728 = NOVALUE;
LF: 
LA: 
        DeRef(_pdone_44819);
        _pdone_44819 = NOVALUE;

        /** 				status = system_exec(cmd, 0)*/
        _status_44764 = system_exec_call(_cmd_44757, 0);

        /** 				if status != 0 then*/
        if (_status_44764 == 0)
        goto L10; // [374] 458

        /** 					ShowMsg(2, 164, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23731 = (int)*(((s1_ptr)_2)->base + _i_44797);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23731);
        *((int *)(_2+4)) = _23731;
        _23732 = MAKE_SEQ(_1);
        _23731 = NOVALUE;
        _45ShowMsg(2, 164, _23732, 1);
        _23732 = NOVALUE;

        /** 					ShowMsg(2, 165, { status, cmd })*/
        RefDS(_cmd_44757);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _status_44764;
        ((int *)_2)[2] = _cmd_44757;
        _23733 = MAKE_SEQ(_1);
        _45ShowMsg(2, 165, _23733, 1);
        _23733 = NOVALUE;

        /** 					goto "build_direct_cleanup"*/
        goto G11;
        goto L10; // [421] 458
L9: 

        /** 			elsif match(".o", generated_files[i]) then*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23735 = (int)*(((s1_ptr)_2)->base + _i_44797);
        _23736 = e_match_from(_22855, _23735, 1);
        _23735 = NOVALUE;
        if (_23736 == 0)
        {
            _23736 = NOVALUE;
            goto L12; // [437] 457
        }
        else{
            _23736 = NOVALUE;
        }

        /** 				objs &= " " & generated_files[i]*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23737 = (int)*(((s1_ptr)_2)->base + _i_44797);
        Concat((object_ptr)&_23738, _23095, _23737);
        _23737 = NOVALUE;
        Concat((object_ptr)&_objs_44758, _objs_44758, _23738);
        DeRefDS(_23738);
        _23738 = NOVALUE;
L12: 
L10: 

        /** 		end for*/
LE: 
        _i_44797 = _i_44797 + 1;
        goto L7; // [460] 181
L8: 
        ;
    }
    goto L13; // [465] 527
L6: 

    /** 		object files = read_lines(file0 & ".bld")*/
    Concat((object_ptr)&_23740, _57file0_43168, _23283);
    _0 = _files_44865;
    _files_44865 = _8read_lines(_23740);
    DeRef(_0);
    _23740 = NOVALUE;

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_44865)){
            _23742 = SEQ_PTR(_files_44865)->length;
    }
    else {
        _23742 = 1;
    }
    {
        int _i_44871;
        _i_44871 = 1;
L14: 
        if (_i_44871 > _23742){
            goto L15; // [485] 524
        }

        /** 			objs &= " " & filebase(files[i]) & "." & settings[SETUP_OBJ_EXT]*/
        _2 = (int)SEQ_PTR(_files_44865);
        _23743 = (int)*(((s1_ptr)_2)->base + _i_44871);
        Ref(_23743);
        _23744 = _17filebase(_23743);
        _23743 = NOVALUE;
        _2 = (int)SEQ_PTR(_settings_44759);
        _23745 = (int)*(((s1_ptr)_2)->base + 5);
        {
            int concat_list[4];

            concat_list[0] = _23745;
            concat_list[1] = _22894;
            concat_list[2] = _23744;
            concat_list[3] = _23095;
            Concat_N((object_ptr)&_23746, concat_list, 4);
        }
        _23745 = NOVALUE;
        DeRef(_23744);
        _23744 = NOVALUE;
        Concat((object_ptr)&_objs_44758, _objs_44758, _23746);
        DeRefDS(_23746);
        _23746 = NOVALUE;

        /** 		end for*/
        _i_44871 = _i_44871 + 1;
        goto L14; // [519] 492
L15: 
        ;
    }
    DeRef(_files_44865);
    _files_44865 = NOVALUE;
L13: 

    /** 	if keep and not link_only and length(link_files) then*/
    if (_57keep_41337 == 0) {
        _23748 = 0;
        goto L16; // [531] 542
    }
    _23749 = (_link_only_44750 == 0);
    _23748 = (_23749 != 0);
L16: 
    if (_23748 == 0) {
        goto L17; // [542] 571
    }
    if (IS_SEQUENCE(_link_files_44793)){
            _23751 = SEQ_PTR(_link_files_44793)->length;
    }
    else {
        _23751 = 1;
    }
    if (_23751 == 0)
    {
        _23751 = NOVALUE;
        goto L17; // [550] 571
    }
    else{
        _23751 = NOVALUE;
    }

    /** 		write_lines(file0 & ".bld", link_files)*/
    Concat((object_ptr)&_23752, _57file0_43168, _23283);
    RefDS(_link_files_44793);
    _31384 = _8write_lines(_23752, _link_files_44793);
    _23752 = NOVALUE;
    DeRef(_31384);
    _31384 = NOVALUE;
    goto L18; // [568] 595
L17: 

    /** 	elsif keep = 0 then*/
    if (_57keep_41337 != 0)
    goto L19; // [575] 594

    /** 		delete_file(file0 & ".bld")*/
    Concat((object_ptr)&_23754, _57file0_43168, _23283);
    _31383 = _17delete_file(_23754);
    _23754 = NOVALUE;
    DeRef(_31383);
    _31383 = NOVALUE;
L19: 
L18: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_GCC then*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23755 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23755)){
            _23756 = SEQ_PTR(_23755)->length;
    }
    else {
        _23756 = 1;
    }
    _23755 = NOVALUE;
    if (_23756 == 0) {
        _23757 = 0;
        goto L1A; // [608] 623
    }
    _2 = (int)SEQ_PTR(_settings_44759);
    _23758 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23758)){
            _23759 = SEQ_PTR(_23758)->length;
    }
    else {
        _23759 = 1;
    }
    _23758 = NOVALUE;
    _23757 = (_23759 != 0);
L1A: 
    if (_23757 == 0) {
        goto L1B; // [623] 724
    }
    _23761 = (_55compiler_type_43986 == 1);
    if (_23761 == 0)
    {
        DeRef(_23761);
        _23761 = NOVALUE;
        goto L1B; // [634] 724
    }
    else{
        DeRef(_23761);
        _23761 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44759);
    _23762 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23763 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23764 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23764);
    Ref(_23763);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23763;
    ((int *)_2)[2] = _23764;
    _23765 = MAKE_SEQ(_1);
    _23764 = NOVALUE;
    _23763 = NOVALUE;
    Ref(_23762);
    _0 = _cmd_44757;
    _cmd_44757 = _14format(_23762, _23765);
    DeRef(_0);
    _23762 = NOVALUE;
    _23765 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_44764 = system_exec_call(_cmd_44757, 0);

    /** 		if status != 0 then*/
    if (_status_44764 == 0)
    goto L1C; // [678] 723

    /** 			ShowMsg(2, 350, { rc_file[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23769 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23769);
    *((int *)(_2+4)) = _23769;
    _23770 = MAKE_SEQ(_1);
    _23769 = NOVALUE;
    _45ShowMsg(2, 350, _23770, 1);
    _23770 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44757);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44764;
    ((int *)_2)[2] = _cmd_44757;
    _23771 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _23771, 1);
    _23771 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L1C: 
L1B: 

    /** 	switch compiler_type do*/
    _0 = _55compiler_type_43986;
    switch ( _0 ){ 

        /** 		case COMPILER_WATCOM then*/
        case 2:

        /** 			cmd = sprintf("%s @%s.lnk", { settings[SETUP_LEXE], file0 })*/
        _2 = (int)SEQ_PTR(_settings_44759);
        _23775 = (int)*(((s1_ptr)_2)->base + 3);
        RefDS(_57file0_43168);
        Ref(_23775);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23775;
        ((int *)_2)[2] = _57file0_43168;
        _23776 = MAKE_SEQ(_1);
        _23775 = NOVALUE;
        DeRef(_cmd_44757);
        _cmd_44757 = EPrintf(-9999999, _23774, _23776);
        DeRefDS(_23776);
        _23776 = NOVALUE;
        goto L1D; // [753] 828

        /** 		case COMPILER_GCC then*/
        case 1:

        /** 			cmd = sprintf("%s -o %s %s %s %s", { */
        _2 = (int)SEQ_PTR(_settings_44759);
        _23779 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_55exe_name_43988);
        _23780 = (int)*(((s1_ptr)_2)->base + 11);
        Ref(_23780);
        _23781 = _55adjust_for_build_file(_23780);
        _23780 = NOVALUE;
        _2 = (int)SEQ_PTR(_55res_file_44000);
        _23782 = (int)*(((s1_ptr)_2)->base + 11);
        _2 = (int)SEQ_PTR(_settings_44759);
        _23783 = (int)*(((s1_ptr)_2)->base + 4);
        _1 = NewS1(5);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_23779);
        *((int *)(_2+4)) = _23779;
        *((int *)(_2+8)) = _23781;
        RefDS(_objs_44758);
        *((int *)(_2+12)) = _objs_44758;
        Ref(_23782);
        *((int *)(_2+16)) = _23782;
        Ref(_23783);
        *((int *)(_2+20)) = _23783;
        _23784 = MAKE_SEQ(_1);
        _23783 = NOVALUE;
        _23782 = NOVALUE;
        _23781 = NOVALUE;
        _23779 = NOVALUE;
        DeRef(_cmd_44757);
        _cmd_44757 = EPrintf(-9999999, _23778, _23784);
        DeRefDS(_23784);
        _23784 = NOVALUE;
        goto L1D; // [801] 828

        /** 		case else*/
        default:

        /** 			ShowMsg(2, 167, { compiler_type })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _55compiler_type_43986;
        _23786 = MAKE_SEQ(_1);
        _45ShowMsg(2, 167, _23786, 1);
        _23786 = NOVALUE;

        /** 			goto "build_direct_cleanup"*/
        goto G11;
    ;}L1D: 

    /** 	if not silent then*/
    if (_35silent_16083 != 0)
    goto L1E; // [832] 886

    /** 		if not verbose then*/
    if (_35verbose_16086 != 0)
    goto L1F; // [839] 870

    /** 			ShowMsg(1, 166, { abbreviate_path(exe_name[D_NAME]) })*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23789 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23789);
    RefDS(_21815);
    _23790 = _17abbreviate_path(_23789, _21815);
    _23789 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23790;
    _23791 = MAKE_SEQ(_1);
    _23790 = NOVALUE;
    _45ShowMsg(1, 166, _23791, 1);
    _23791 = NOVALUE;
    goto L20; // [867] 885
L1F: 

    /** 			ShowMsg(1, 166, { cmd })*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_cmd_44757);
    *((int *)(_2+4)) = _cmd_44757;
    _23792 = MAKE_SEQ(_1);
    _45ShowMsg(1, 166, _23792, 1);
    _23792 = NOVALUE;
L20: 
L1E: 

    /** 	status = system_exec(cmd, 0)*/
    _status_44764 = system_exec_call(_cmd_44757, 0);

    /** 	if status != 0 then*/
    if (_status_44764 == 0)
    goto L21; // [896] 939

    /** 		ShowMsg(2, 168, { exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23795 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23795);
    *((int *)(_2+4)) = _23795;
    _23796 = MAKE_SEQ(_1);
    _23795 = NOVALUE;
    _45ShowMsg(2, 168, _23796, 1);
    _23796 = NOVALUE;

    /** 		ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44757);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44764;
    ((int *)_2)[2] = _cmd_44757;
    _23797 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _23797, 1);
    _23797 = NOVALUE;

    /** 		goto "build_direct_cleanup"*/
    goto G11;
L21: 

    /** 	if length(rc_file[D_ALTNAME]) and length(settings[SETUP_RC_COMPILER]) and compiler_type = COMPILER_WATCOM then*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23798 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23798)){
            _23799 = SEQ_PTR(_23798)->length;
    }
    else {
        _23799 = 1;
    }
    _23798 = NOVALUE;
    if (_23799 == 0) {
        _23800 = 0;
        goto L22; // [952] 967
    }
    _2 = (int)SEQ_PTR(_settings_44759);
    _23801 = (int)*(((s1_ptr)_2)->base + 8);
    if (IS_SEQUENCE(_23801)){
            _23802 = SEQ_PTR(_23801)->length;
    }
    else {
        _23802 = 1;
    }
    _23801 = NOVALUE;
    _23800 = (_23802 != 0);
L22: 
    if (_23800 == 0) {
        goto L23; // [967] 1086
    }
    _23804 = (_55compiler_type_43986 == 2);
    if (_23804 == 0)
    {
        DeRef(_23804);
        _23804 = NOVALUE;
        goto L23; // [978] 1086
    }
    else{
        DeRef(_23804);
        _23804 = NOVALUE;
    }

    /** 		cmd = text:format(settings[SETUP_RC_COMPILER], { rc_file[D_ALTNAME], res_file[D_ALTNAME], exe_name[D_ALTNAME] })*/
    _2 = (int)SEQ_PTR(_settings_44759);
    _23805 = (int)*(((s1_ptr)_2)->base + 8);
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23806 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23807 = (int)*(((s1_ptr)_2)->base + 11);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23808 = (int)*(((s1_ptr)_2)->base + 11);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23806);
    *((int *)(_2+4)) = _23806;
    Ref(_23807);
    *((int *)(_2+8)) = _23807;
    Ref(_23808);
    *((int *)(_2+12)) = _23808;
    _23809 = MAKE_SEQ(_1);
    _23808 = NOVALUE;
    _23807 = NOVALUE;
    _23806 = NOVALUE;
    Ref(_23805);
    _0 = _cmd_44757;
    _cmd_44757 = _14format(_23805, _23809);
    DeRef(_0);
    _23805 = NOVALUE;
    _23809 = NOVALUE;

    /** 		status = system_exec(cmd, 0)*/
    _status_44764 = system_exec_call(_cmd_44757, 0);

    /** 		if status != 0 then*/
    if (_status_44764 == 0)
    goto L24; // [1032] 1085

    /** 			ShowMsg(2, 187, { rc_file[D_NAME], exe_name[D_NAME] })*/
    _2 = (int)SEQ_PTR(_55rc_file_43994);
    _23813 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_55exe_name_43988);
    _23814 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23814);
    Ref(_23813);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23813;
    ((int *)_2)[2] = _23814;
    _23815 = MAKE_SEQ(_1);
    _23814 = NOVALUE;
    _23813 = NOVALUE;
    _45ShowMsg(2, 187, _23815, 1);
    _23815 = NOVALUE;

    /** 			ShowMsg(2, 169, { status, cmd })*/
    RefDS(_cmd_44757);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _status_44764;
    ((int *)_2)[2] = _cmd_44757;
    _23816 = MAKE_SEQ(_1);
    _45ShowMsg(2, 169, _23816, 1);
    _23816 = NOVALUE;

    /** 			goto "build_direct_cleanup"*/
    goto G11;
L24: 
L23: 

    /** label "build_direct_cleanup"*/
G11:

    /** 	if keep = 0 then*/
    if (_57keep_41337 != 0)
    goto L25; // [1094] 1241

    /** 		for i = 1 to length(generated_files) do*/
    if (IS_SEQUENCE(_57generated_files_41334)){
            _23818 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _23818 = 1;
    }
    {
        int _i_44998;
        _i_44998 = 1;
L26: 
        if (_i_44998 > _23818){
            goto L27; // [1105] 1159
        }

        /** 			if verbose then*/
        if (_35verbose_16086 == 0)
        {
            goto L28; // [1116] 1138
        }
        else{
        }

        /** 				ShowMsg(1, 347, { generated_files[i] })*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23819 = (int)*(((s1_ptr)_2)->base + _i_44998);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_23819);
        *((int *)(_2+4)) = _23819;
        _23820 = MAKE_SEQ(_1);
        _23819 = NOVALUE;
        _45ShowMsg(1, 347, _23820, 1);
        _23820 = NOVALUE;
L28: 

        /** 			delete_file(generated_files[i])*/
        _2 = (int)SEQ_PTR(_57generated_files_41334);
        _23821 = (int)*(((s1_ptr)_2)->base + _i_44998);
        RefDS(_23821);
        _31382 = _17delete_file(_23821);
        _23821 = NOVALUE;
        DeRef(_31382);
        _31382 = NOVALUE;

        /** 		end for*/
        _i_44998 = _i_44998 + 1;
        goto L26; // [1154] 1112
L27: 
        ;
    }

    /** 		if length(res_file[D_ALTNAME]) then*/
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23822 = (int)*(((s1_ptr)_2)->base + 11);
    if (IS_SEQUENCE(_23822)){
            _23823 = SEQ_PTR(_23822)->length;
    }
    else {
        _23823 = 1;
    }
    _23822 = NOVALUE;
    if (_23823 == 0)
    {
        _23823 = NOVALUE;
        goto L29; // [1172] 1192
    }
    else{
        _23823 = NOVALUE;
    }

    /** 			delete_file(res_file[D_ALTNAME])*/
    _2 = (int)SEQ_PTR(_55res_file_44000);
    _23824 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_23824);
    _31381 = _17delete_file(_23824);
    _23824 = NOVALUE;
    DeRef(_31381);
    _31381 = NOVALUE;
L29: 

    /** 		if remove_output_dir then*/
    if (_55remove_output_dir_44006 == 0)
    {
        goto L2A; // [1196] 1240
    }
    else{
    }

    /** 			chdir(cwd)*/
    RefDS(_cwd_44761);
    _31380 = _17chdir(_cwd_44761);
    DeRef(_31380);
    _31380 = NOVALUE;

    /** 			if not remove_directory(output_dir) then*/
    RefDS(_57output_dir_41343);
    _23825 = _17remove_directory(_57output_dir_41343, 0);
    if (IS_ATOM_INT(_23825)) {
        if (_23825 != 0){
            DeRef(_23825);
            _23825 = NOVALUE;
            goto L2B; // [1216] 1239
        }
    }
    else {
        if (DBL_PTR(_23825)->dbl != 0.0){
            DeRef(_23825);
            _23825 = NOVALUE;
            goto L2B; // [1216] 1239
        }
    }
    DeRef(_23825);
    _23825 = NOVALUE;

    /** 				ShowMsg(2, 194, { abbreviate_path(output_dir) })*/
    RefDS(_57output_dir_41343);
    RefDS(_21815);
    _23827 = _17abbreviate_path(_57output_dir_41343, _21815);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _23827;
    _23828 = MAKE_SEQ(_1);
    _23827 = NOVALUE;
    _45ShowMsg(2, 194, _23828, 1);
    _23828 = NOVALUE;
L2B: 
L2A: 
L25: 

    /** 	chdir(cwd)*/
    RefDS(_cwd_44761);
    _31379 = _17chdir(_cwd_44761);
    DeRef(_31379);
    _31379 = NOVALUE;

    /** end procedure*/
    DeRefDS(_the_file0_44751);
    DeRef(_cmd_44757);
    DeRef(_objs_44758);
    DeRef(_settings_44759);
    DeRefDS(_cwd_44761);
    DeRef(_link_files_44793);
    DeRef(_23749);
    _23749 = NOVALUE;
    DeRef(_23721);
    _23721 = NOVALUE;
    _23755 = NOVALUE;
    _23758 = NOVALUE;
    _23798 = NOVALUE;
    _23801 = NOVALUE;
    _23822 = NOVALUE;
    return;
    ;
}


void _55write_buildfile()
{
    int _make_command_45038 = NOVALUE;
    int _settings_45078 = NOVALUE;
    int _23851 = NOVALUE;
    int _23850 = NOVALUE;
    int _23846 = NOVALUE;
    int _23845 = NOVALUE;
    int _23844 = NOVALUE;
    int _23842 = NOVALUE;
    int _23841 = NOVALUE;
    int _23840 = NOVALUE;
    int _23839 = NOVALUE;
    int _23838 = NOVALUE;
    int _23837 = NOVALUE;
    int _23836 = NOVALUE;
    int _23835 = NOVALUE;
    int _0, _1, _2;
    

    /** 	switch build_system_type do*/
    _0 = _55build_system_type_43982;
    switch ( _0 ){ 

        /** 		case BUILD_MAKEFILE_FULL then*/
        case 2:

        /** 			write_makefile_full()*/
        _55write_makefile_full();

        /** 			if not silent then*/
        if (_35silent_16083 != 0)
        goto L1; // [22] 136

        /** 				sequence make_command*/

        /** 				if compiler_type = COMPILER_WATCOM then*/
        if (_55compiler_type_43986 != 2)
        goto L2; // [31] 45

        /** 					make_command = "wmake /f "*/
        RefDS(_23833);
        DeRefi(_make_command_45038);
        _make_command_45038 = _23833;
        goto L3; // [42] 53
L2: 

        /** 					make_command = "make -f "*/
        RefDS(_23834);
        DeRefi(_make_command_45038);
        _make_command_45038 = _23834;
L3: 

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23835 = _35cfile_count_16046 + 2;
        if ((long)((unsigned long)_23835 + (unsigned long)HIGH_BITS) >= 0) 
        _23835 = NewDouble((double)_23835);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23835;
        _23836 = MAKE_SEQ(_1);
        _23835 = NOVALUE;
        _45ShowMsg(1, 170, _23836, 1);
        _23836 = NOVALUE;

        /** 				if sequence(output_dir) and length(output_dir) > 0 then*/
        _23837 = 1;
        if (_23837 == 0) {
            goto L4; // [78] 118
        }
        if (IS_SEQUENCE(_57output_dir_41343)){
                _23839 = SEQ_PTR(_57output_dir_41343)->length;
        }
        else {
            _23839 = 1;
        }
        _23840 = (_23839 > 0);
        _23839 = NOVALUE;
        if (_23840 == 0)
        {
            DeRef(_23840);
            _23840 = NOVALUE;
            goto L4; // [92] 118
        }
        else{
            DeRef(_23840);
            _23840 = NOVALUE;
        }

        /** 					ShowMsg(1, 174, { output_dir, make_command, file0 })*/
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57output_dir_41343);
        *((int *)(_2+4)) = _57output_dir_41343;
        RefDS(_make_command_45038);
        *((int *)(_2+8)) = _make_command_45038;
        RefDS(_57file0_43168);
        *((int *)(_2+12)) = _57file0_43168;
        _23841 = MAKE_SEQ(_1);
        _45ShowMsg(1, 174, _23841, 1);
        _23841 = NOVALUE;
        goto L5; // [115] 135
L4: 

        /** 					ShowMsg(1, 172, { make_command, file0 })*/
        RefDS(_57file0_43168);
        RefDS(_make_command_45038);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _make_command_45038;
        ((int *)_2)[2] = _57file0_43168;
        _23842 = MAKE_SEQ(_1);
        _45ShowMsg(1, 172, _23842, 1);
        _23842 = NOVALUE;
L5: 
L1: 
        DeRefi(_make_command_45038);
        _make_command_45038 = NOVALUE;
        goto L6; // [138] 263

        /** 		case BUILD_MAKEFILE_PARTIAL then*/
        case 1:

        /** 			write_makefile_partial()*/
        _55write_makefile_partial();

        /** 			if not silent then*/
        if (_35silent_16083 != 0)
        goto L6; // [152] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23844 = _35cfile_count_16046 + 2;
        if ((long)((unsigned long)_23844 + (unsigned long)HIGH_BITS) >= 0) 
        _23844 = NewDouble((double)_23844);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23844;
        _23845 = MAKE_SEQ(_1);
        _23844 = NOVALUE;
        _45ShowMsg(1, 170, _23845, 1);
        _23845 = NOVALUE;

        /** 				ShowMsg(1, 173, { file0 })*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_57file0_43168);
        *((int *)(_2+4)) = _57file0_43168;
        _23846 = MAKE_SEQ(_1);
        _45ShowMsg(1, 173, _23846, 1);
        _23846 = NOVALUE;
        goto L6; // [188] 263

        /** 		case BUILD_DIRECT then*/
        case 3:

        /** 			build_direct()*/
        RefDS(_21815);
        _55build_direct(0, _21815);

        /** 			if not silent then*/
        if (_35silent_16083 != 0)
        goto L7; // [204] 215

        /** 				sequence settings = setup_build()*/
        _0 = _settings_45078;
        _settings_45078 = _55setup_build();
        DeRef(_0);
L7: 
        DeRef(_settings_45078);
        _settings_45078 = NOVALUE;
        goto L6; // [217] 263

        /** 		case BUILD_NONE then*/
        case 0:

        /** 			if not silent then*/
        if (_35silent_16083 != 0)
        goto L6; // [227] 263

        /** 				ShowMsg(1, 170, { cfile_count + 2 })*/
        _23850 = _35cfile_count_16046 + 2;
        if ((long)((unsigned long)_23850 + (unsigned long)HIGH_BITS) >= 0) 
        _23850 = NewDouble((double)_23850);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _23850;
        _23851 = MAKE_SEQ(_1);
        _23850 = NOVALUE;
        _45ShowMsg(1, 170, _23851, 1);
        _23851 = NOVALUE;
        goto L6; // [249] 263

        /** 		case else*/
        default:

        /** 			CompileErr(151)*/
        RefDS(_21815);
        _44CompileErr(151, _21815, 0);
    ;}L6: 

    /** end procedure*/
    return;
    ;
}



// 0x3DF87E91
