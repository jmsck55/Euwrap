// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _35print_sym(int _s_15735)
{
    int _s_obj_15738 = NOVALUE;
    int _8768 = NOVALUE;
    int _8767 = NOVALUE;
    int _8763 = NOVALUE;
    int _8761 = NOVALUE;
    int _8760 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_15735)) {
        _1 = (long)(DBL_PTR(_s_15735)->dbl);
        DeRefDS(_s_15735);
        _s_15735 = _1;
    }

    /** 	printf(1,"[%d]:\n", {s} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _s_15735;
    _8760 = MAKE_SEQ(_1);
    EPrintf(1, _8759, _8760);
    DeRefDS(_8760);
    _8760 = NOVALUE;

    /** 	object s_obj = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _8761 = (int)*(((s1_ptr)_2)->base + _s_15735);
    DeRef(_s_obj_15738);
    _2 = (int)SEQ_PTR(_8761);
    _s_obj_15738 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_s_obj_15738);
    _8761 = NOVALUE;

    /** 	if equal(s_obj,NOVALUE) then */
    if (_s_obj_15738 == _35NOVALUE_15823)
    _8763 = 1;
    else if (IS_ATOM_INT(_s_obj_15738) && IS_ATOM_INT(_35NOVALUE_15823))
    _8763 = 0;
    else
    _8763 = (compare(_s_obj_15738, _35NOVALUE_15823) == 0);
    if (_8763 == 0)
    {
        _8763 = NOVALUE;
        goto L1; // [33] 44
    }
    else{
        _8763 = NOVALUE;
    }

    /** 		puts(1,"S_OBJ=>NOVALUE\n")*/
    EPuts(1, _8764); // DJP 
    goto L2; // [41] 55
L1: 

    /** 		puts(1,"S_OBJ=>")*/
    EPuts(1, _8765); // DJP 

    /** 		? s_obj		*/
    StdPrint(1, _s_obj_15738, 1);
L2: 

    /** 	puts(1,"S_MODE=>")*/
    EPuts(1, _8766); // DJP 

    /** 	switch SymTab[s][S_MODE] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _8767 = (int)*(((s1_ptr)_2)->base + _s_15735);
    _2 = (int)SEQ_PTR(_8767);
    _8768 = (int)*(((s1_ptr)_2)->base + 3);
    _8767 = NOVALUE;
    if (IS_SEQUENCE(_8768) ){
        goto L3; // [72] 120
    }
    if(!IS_ATOM_INT(_8768)){
        if( (DBL_PTR(_8768)->dbl != (double) ((int) DBL_PTR(_8768)->dbl) ) ){
            goto L3; // [72] 120
        }
        _0 = (int) DBL_PTR(_8768)->dbl;
    }
    else {
        _0 = _8768;
    };
    _8768 = NOVALUE;
    switch ( _0 ){ 

        /** 		case M_NORMAL then*/
        case 1:

        /** 			puts(1,"M_NORMAL")*/
        EPuts(1, _8771); // DJP 
        goto L3; // [86] 120

        /** 		case M_TEMP then*/
        case 3:

        /** 			puts(1,"M_TEMP")*/
        EPuts(1, _8772); // DJP 
        goto L3; // [97] 120

        /** 		case M_CONSTANT then*/
        case 2:

        /** 			puts(1,"M_CONSTANT")*/
        EPuts(1, _8773); // DJP 
        goto L3; // [108] 120

        /** 		case M_BLOCK then*/
        case 4:

        /** 			puts(1,"M_BLOCK")*/
        EPuts(1, _8774); // DJP 
    ;}L3: 

    /** 	puts(1,{10,10})*/
    EPuts(1, _8775); // DJP 

    /** end procedure*/
    DeRef(_s_obj_15738);
    return;
    ;
}


int _35symtab_entry(int _x_15828)
{
    int _8794 = NOVALUE;
    int _8793 = NOVALUE;
    int _8792 = NOVALUE;
    int _8791 = NOVALUE;
    int _8790 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length(x) = SIZEOF_ROUTINE_ENTRY or*/
    if (IS_SEQUENCE(_x_15828)){
            _8790 = SEQ_PTR(_x_15828)->length;
    }
    else {
        _8790 = 1;
    }
    _8791 = (_8790 == _35SIZEOF_ROUTINE_ENTRY_15767);
    _8790 = NOVALUE;
    if (IS_SEQUENCE(_x_15828)){
            _8792 = SEQ_PTR(_x_15828)->length;
    }
    else {
        _8792 = 1;
    }
    _8793 = (_8792 == _35SIZEOF_VAR_ENTRY_15770);
    _8792 = NOVALUE;
    _8794 = (_8791 != 0 || _8793 != 0);
    _8791 = NOVALUE;
    _8793 = NOVALUE;
    DeRefDS(_x_15828);
    return _8794;
    ;
}


int _35symtab_index(int _x_15836)
{
    int _8803 = NOVALUE;
    int _8802 = NOVALUE;
    int _8801 = NOVALUE;
    int _8800 = NOVALUE;
    int _8799 = NOVALUE;
    int _8798 = NOVALUE;
    int _8796 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_15836)) {
        _1 = (long)(DBL_PTR(_x_15836)->dbl);
        DeRefDS(_x_15836);
        _x_15836 = _1;
    }

    /** 	if x = 0 then*/
    if (_x_15836 != 0)
    goto L1; // [5] 18

    /** 		return TRUE -- NULL value*/
    return _13TRUE_437;
L1: 

    /** 	if x < 0 or x > length(SymTab) then*/
    _8796 = (_x_15836 < 0);
    if (_8796 != 0) {
        goto L2; // [24] 42
    }
    if (IS_SEQUENCE(_36SymTab_14981)){
            _8798 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _8798 = 1;
    }
    _8799 = (_x_15836 > _8798);
    _8798 = NOVALUE;
    if (_8799 == 0)
    {
        DeRef(_8799);
        _8799 = NOVALUE;
        goto L3; // [38] 51
    }
    else{
        DeRef(_8799);
        _8799 = NOVALUE;
    }
L2: 

    /** 		return FALSE*/
    DeRef(_8796);
    _8796 = NOVALUE;
    return _13FALSE_435;
L3: 

    /** 	return find(length(SymTab[x]), {SIZEOF_VAR_ENTRY, SIZEOF_ROUTINE_ENTRY,*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _8800 = (int)*(((s1_ptr)_2)->base + _x_15836);
    if (IS_SEQUENCE(_8800)){
            _8801 = SEQ_PTR(_8800)->length;
    }
    else {
        _8801 = 1;
    }
    _8800 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _35SIZEOF_VAR_ENTRY_15770;
    *((int *)(_2+8)) = _35SIZEOF_ROUTINE_ENTRY_15767;
    *((int *)(_2+12)) = _35SIZEOF_TEMP_ENTRY_15776;
    *((int *)(_2+16)) = _35SIZEOF_BLOCK_ENTRY_15773;
    _8802 = MAKE_SEQ(_1);
    _8803 = find_from(_8801, _8802, 1);
    _8801 = NOVALUE;
    DeRefDS(_8802);
    _8802 = NOVALUE;
    DeRef(_8796);
    _8796 = NOVALUE;
    _8800 = NOVALUE;
    return _8803;
    ;
}


int _35temp_index(int _x_15854)
{
    int _8807 = NOVALUE;
    int _8806 = NOVALUE;
    int _8805 = NOVALUE;
    int _8804 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_15854)) {
        _1 = (long)(DBL_PTR(_x_15854)->dbl);
        DeRefDS(_x_15854);
        _x_15854 = _1;
    }

    /** 	return x >= 0 and x <= length(SymTab)*/
    _8804 = (_x_15854 >= 0);
    if (IS_SEQUENCE(_36SymTab_14981)){
            _8805 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _8805 = 1;
    }
    _8806 = (_x_15854 <= _8805);
    _8805 = NOVALUE;
    _8807 = (_8804 != 0 && _8806 != 0);
    _8804 = NOVALUE;
    _8806 = NOVALUE;
    return _8807;
    ;
}


int _35token(int _t_15864)
{
    int _8850 = NOVALUE;
    int _8849 = NOVALUE;
    int _8848 = NOVALUE;
    int _8847 = NOVALUE;
    int _8846 = NOVALUE;
    int _8845 = NOVALUE;
    int _8844 = NOVALUE;
    int _8843 = NOVALUE;
    int _8842 = NOVALUE;
    int _8841 = NOVALUE;
    int _8840 = NOVALUE;
    int _8839 = NOVALUE;
    int _8838 = NOVALUE;
    int _8837 = NOVALUE;
    int _8836 = NOVALUE;
    int _8835 = NOVALUE;
    int _8834 = NOVALUE;
    int _8833 = NOVALUE;
    int _8832 = NOVALUE;
    int _8831 = NOVALUE;
    int _8830 = NOVALUE;
    int _8829 = NOVALUE;
    int _8828 = NOVALUE;
    int _8827 = NOVALUE;
    int _8826 = NOVALUE;
    int _8825 = NOVALUE;
    int _8824 = NOVALUE;
    int _8823 = NOVALUE;
    int _8822 = NOVALUE;
    int _8821 = NOVALUE;
    int _8820 = NOVALUE;
    int _8819 = NOVALUE;
    int _8818 = NOVALUE;
    int _8817 = NOVALUE;
    int _8816 = NOVALUE;
    int _8815 = NOVALUE;
    int _8814 = NOVALUE;
    int _8812 = NOVALUE;
    int _8811 = NOVALUE;
    int _8809 = NOVALUE;
    int _8808 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(t) then*/
    _8808 = IS_ATOM(_t_15864);
    if (_8808 == 0)
    {
        _8808 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _8808 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_t_15864);
    return _13FALSE_435;
L1: 

    /** 	if length(t) != 2 then*/
    if (IS_SEQUENCE(_t_15864)){
            _8809 = SEQ_PTR(_t_15864)->length;
    }
    else {
        _8809 = 1;
    }
    if (_8809 == 2)
    goto L2; // [23] 36

    /** 		return FALSE*/
    DeRef(_t_15864);
    return _13FALSE_435;
L2: 

    /** 	if not integer(t[T_ID]) then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8811 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8811))
    _8812 = 1;
    else if (IS_ATOM_DBL(_8811))
    _8812 = IS_ATOM_INT(DoubleToInt(_8811));
    else
    _8812 = 0;
    _8811 = NOVALUE;
    if (_8812 != 0)
    goto L3; // [45] 57
    _8812 = NOVALUE;

    /** 		return FALSE*/
    DeRef(_t_15864);
    return _13FALSE_435;
L3: 

    /** 	if t[T_ID] = VARIABLE and (t[T_SYM] < 0 or symtab_index(t[T_SYM])) then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8814 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8814)) {
        _8815 = (_8814 == -100);
    }
    else {
        _8815 = binary_op(EQUALS, _8814, -100);
    }
    _8814 = NOVALUE;
    if (IS_ATOM_INT(_8815)) {
        if (_8815 == 0) {
            goto L4; // [69] 110
        }
    }
    else {
        if (DBL_PTR(_8815)->dbl == 0.0) {
            goto L4; // [69] 110
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8817 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_8817)) {
        _8818 = (_8817 < 0);
    }
    else {
        _8818 = binary_op(LESS, _8817, 0);
    }
    _8817 = NOVALUE;
    if (IS_ATOM_INT(_8818)) {
        if (_8818 != 0) {
            DeRef(_8819);
            _8819 = 1;
            goto L5; // [81] 97
        }
    }
    else {
        if (DBL_PTR(_8818)->dbl != 0.0) {
            DeRef(_8819);
            _8819 = 1;
            goto L5; // [81] 97
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8820 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8820);
    _8821 = _35symtab_index(_8820);
    _8820 = NOVALUE;
    DeRef(_8819);
    if (IS_ATOM_INT(_8821))
    _8819 = (_8821 != 0);
    else
    _8819 = DBL_PTR(_8821)->dbl != 0.0;
L5: 
    if (_8819 == 0)
    {
        _8819 = NOVALUE;
        goto L4; // [98] 110
    }
    else{
        _8819 = NOVALUE;
    }

    /** 		return TRUE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    return _13TRUE_437;
L4: 

    /** 	if QUESTION_MARK <= t[T_ID] and t[T_ID] <= -1 then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8822 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8822)) {
        _8823 = (-31 <= _8822);
    }
    else {
        _8823 = binary_op(LESSEQ, -31, _8822);
    }
    _8822 = NOVALUE;
    if (IS_ATOM_INT(_8823)) {
        if (_8823 == 0) {
            goto L6; // [122] 147
        }
    }
    else {
        if (DBL_PTR(_8823)->dbl == 0.0) {
            goto L6; // [122] 147
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8825 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8825)) {
        _8826 = (_8825 <= -1);
    }
    else {
        _8826 = binary_op(LESSEQ, _8825, -1);
    }
    _8825 = NOVALUE;
    if (_8826 == 0) {
        DeRef(_8826);
        _8826 = NOVALUE;
        goto L6; // [135] 147
    }
    else {
        if (!IS_ATOM_INT(_8826) && DBL_PTR(_8826)->dbl == 0.0){
            DeRef(_8826);
            _8826 = NOVALUE;
            goto L6; // [135] 147
        }
        DeRef(_8826);
        _8826 = NOVALUE;
    }
    DeRef(_8826);
    _8826 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    return _13TRUE_437;
L6: 

    /** 	if t[T_ID] >= 1 and t[T_ID] <= MAX_OPCODE then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8827 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8827)) {
        _8828 = (_8827 >= 1);
    }
    else {
        _8828 = binary_op(GREATEREQ, _8827, 1);
    }
    _8827 = NOVALUE;
    if (IS_ATOM_INT(_8828)) {
        if (_8828 == 0) {
            goto L7; // [157] 184
        }
    }
    else {
        if (DBL_PTR(_8828)->dbl == 0.0) {
            goto L7; // [157] 184
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8830 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8830)) {
        _8831 = (_8830 <= 213);
    }
    else {
        _8831 = binary_op(LESSEQ, _8830, 213);
    }
    _8830 = NOVALUE;
    if (_8831 == 0) {
        DeRef(_8831);
        _8831 = NOVALUE;
        goto L7; // [172] 184
    }
    else {
        if (!IS_ATOM_INT(_8831) && DBL_PTR(_8831)->dbl == 0.0){
            DeRef(_8831);
            _8831 = NOVALUE;
            goto L7; // [172] 184
        }
        DeRef(_8831);
        _8831 = NOVALUE;
    }
    DeRef(_8831);
    _8831 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    DeRef(_8828);
    _8828 = NOVALUE;
    return _13TRUE_437;
L7: 

    /** 	if END <= t[T_ID] and t[T_ID] <=  ROUTINE then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8832 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8832)) {
        _8833 = (402 <= _8832);
    }
    else {
        _8833 = binary_op(LESSEQ, 402, _8832);
    }
    _8832 = NOVALUE;
    if (IS_ATOM_INT(_8833)) {
        if (_8833 == 0) {
            goto L8; // [196] 280
        }
    }
    else {
        if (DBL_PTR(_8833)->dbl == 0.0) {
            goto L8; // [196] 280
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8835 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8835)) {
        _8836 = (_8835 <= 432);
    }
    else {
        _8836 = binary_op(LESSEQ, _8835, 432);
    }
    _8835 = NOVALUE;
    if (_8836 == 0) {
        DeRef(_8836);
        _8836 = NOVALUE;
        goto L8; // [211] 280
    }
    else {
        if (!IS_ATOM_INT(_8836) && DBL_PTR(_8836)->dbl == 0.0){
            DeRef(_8836);
            _8836 = NOVALUE;
            goto L8; // [211] 280
        }
        DeRef(_8836);
        _8836 = NOVALUE;
    }
    DeRef(_8836);
    _8836 = NOVALUE;

    /** 		if t[T_ID] != IGNORED and t[T_ID] < 500 and symtab_index(t[T_SYM]) = 0 then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8837 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8837)) {
        _8838 = (_8837 != 509);
    }
    else {
        _8838 = binary_op(NOTEQ, _8837, 509);
    }
    _8837 = NOVALUE;
    if (IS_ATOM_INT(_8838)) {
        if (_8838 == 0) {
            DeRef(_8839);
            _8839 = 0;
            goto L9; // [226] 242
        }
    }
    else {
        if (DBL_PTR(_8838)->dbl == 0.0) {
            DeRef(_8839);
            _8839 = 0;
            goto L9; // [226] 242
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8840 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8840)) {
        _8841 = (_8840 < 500);
    }
    else {
        _8841 = binary_op(LESS, _8840, 500);
    }
    _8840 = NOVALUE;
    DeRef(_8839);
    if (IS_ATOM_INT(_8841))
    _8839 = (_8841 != 0);
    else
    _8839 = DBL_PTR(_8841)->dbl != 0.0;
L9: 
    if (_8839 == 0) {
        goto LA; // [242] 271
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8843 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_8843);
    _8844 = _35symtab_index(_8843);
    _8843 = NOVALUE;
    if (IS_ATOM_INT(_8844)) {
        _8845 = (_8844 == 0);
    }
    else {
        _8845 = binary_op(EQUALS, _8844, 0);
    }
    DeRef(_8844);
    _8844 = NOVALUE;
    if (_8845 == 0) {
        DeRef(_8845);
        _8845 = NOVALUE;
        goto LA; // [259] 271
    }
    else {
        if (!IS_ATOM_INT(_8845) && DBL_PTR(_8845)->dbl == 0.0){
            DeRef(_8845);
            _8845 = NOVALUE;
            goto LA; // [259] 271
        }
        DeRef(_8845);
        _8845 = NOVALUE;
    }
    DeRef(_8845);
    _8845 = NOVALUE;

    /** 			return FALSE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    DeRef(_8828);
    _8828 = NOVALUE;
    DeRef(_8833);
    _8833 = NOVALUE;
    DeRef(_8838);
    _8838 = NOVALUE;
    DeRef(_8841);
    _8841 = NOVALUE;
    return _13FALSE_435;
LA: 

    /** 		return TRUE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    DeRef(_8828);
    _8828 = NOVALUE;
    DeRef(_8833);
    _8833 = NOVALUE;
    DeRef(_8838);
    _8838 = NOVALUE;
    DeRef(_8841);
    _8841 = NOVALUE;
    return _13TRUE_437;
L8: 

    /** 	if FUNC <= t[T_ID] and t[T_ID] <= NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_15864);
    _8846 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8846)) {
        _8847 = (501 <= _8846);
    }
    else {
        _8847 = binary_op(LESSEQ, 501, _8846);
    }
    _8846 = NOVALUE;
    if (IS_ATOM_INT(_8847)) {
        if (_8847 == 0) {
            goto LB; // [292] 319
        }
    }
    else {
        if (DBL_PTR(_8847)->dbl == 0.0) {
            goto LB; // [292] 319
        }
    }
    _2 = (int)SEQ_PTR(_t_15864);
    _8849 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_8849)) {
        _8850 = (_8849 <= 523);
    }
    else {
        _8850 = binary_op(LESSEQ, _8849, 523);
    }
    _8849 = NOVALUE;
    if (_8850 == 0) {
        DeRef(_8850);
        _8850 = NOVALUE;
        goto LB; // [307] 319
    }
    else {
        if (!IS_ATOM_INT(_8850) && DBL_PTR(_8850)->dbl == 0.0){
            DeRef(_8850);
            _8850 = NOVALUE;
            goto LB; // [307] 319
        }
        DeRef(_8850);
        _8850 = NOVALUE;
    }
    DeRef(_8850);
    _8850 = NOVALUE;

    /** 		return TRUE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    DeRef(_8828);
    _8828 = NOVALUE;
    DeRef(_8833);
    _8833 = NOVALUE;
    DeRef(_8838);
    _8838 = NOVALUE;
    DeRef(_8841);
    _8841 = NOVALUE;
    DeRef(_8847);
    _8847 = NOVALUE;
    return _13TRUE_437;
LB: 

    /** 	return FALSE*/
    DeRef(_t_15864);
    DeRef(_8815);
    _8815 = NOVALUE;
    DeRef(_8818);
    _8818 = NOVALUE;
    DeRef(_8821);
    _8821 = NOVALUE;
    DeRef(_8823);
    _8823 = NOVALUE;
    DeRef(_8828);
    _8828 = NOVALUE;
    DeRef(_8833);
    _8833 = NOVALUE;
    DeRef(_8838);
    _8838 = NOVALUE;
    DeRef(_8841);
    _8841 = NOVALUE;
    DeRef(_8847);
    _8847 = NOVALUE;
    return _13FALSE_435;
    ;
}


int _35sequence_of_tokens(int _x_15937)
{
    int _t_15938 = NOVALUE;
    int _8852 = NOVALUE;
    int _8851 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _8851 = IS_ATOM(_x_15937);
    if (_8851 == 0)
    {
        _8851 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _8851 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_x_15937);
    DeRef(_t_15938);
    return _13FALSE_435;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_15937)){
            _8852 = SEQ_PTR(_x_15937)->length;
    }
    else {
        _8852 = 1;
    }
    {
        int _i_15943;
        _i_15943 = 1;
L2: 
        if (_i_15943 > _8852){
            goto L3; // [23] 48
        }

        /** 		type_i = i*/
        _35type_i_15624 = _i_15943;

        /** 		t = x[i]*/
        DeRef(_t_15938);
        _2 = (int)SEQ_PTR(_x_15937);
        _t_15938 = (int)*(((s1_ptr)_2)->base + _i_15943);
        Ref(_t_15938);

        /** 	end for*/
        _i_15943 = _i_15943 + 1;
        goto L2; // [43] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_x_15937);
    DeRef(_t_15938);
    return _13TRUE_437;
    ;
}


int _35sequence_of_opcodes(int _s_15949)
{
    int _oc_15950 = NOVALUE;
    int _8855 = NOVALUE;
    int _8854 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(s) then*/
    _8854 = IS_ATOM(_s_15949);
    if (_8854 == 0)
    {
        _8854 = NOVALUE;
        goto L1; // [6] 18
    }
    else{
        _8854 = NOVALUE;
    }

    /** 		return FALSE*/
    DeRef(_s_15949);
    return _13FALSE_435;
L1: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_15949)){
            _8855 = SEQ_PTR(_s_15949)->length;
    }
    else {
        _8855 = 1;
    }
    {
        int _i_15955;
        _i_15955 = 1;
L2: 
        if (_i_15955 > _8855){
            goto L3; // [23] 45
        }

        /** 		oc = s[i]*/
        _2 = (int)SEQ_PTR(_s_15949);
        _oc_15950 = (int)*(((s1_ptr)_2)->base + _i_15955);
        if (!IS_ATOM_INT(_oc_15950)){
            _oc_15950 = (long)DBL_PTR(_oc_15950)->dbl;
        }

        /** 	end for*/
        _i_15955 = _i_15955 + 1;
        goto L2; // [40] 30
L3: 
        ;
    }

    /** 	return TRUE*/
    DeRef(_s_15949);
    return _13TRUE_437;
    ;
}


int _35file(int _f_15961)
{
    int _8859 = NOVALUE;
    int _8858 = NOVALUE;
    int _8857 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_15961)) {
        _1 = (long)(DBL_PTR(_f_15961)->dbl);
        DeRefDS(_f_15961);
        _f_15961 = _1;
    }

    /** 	return f >= -1 and f < 100 -- rough limit*/
    _8857 = (_f_15961 >= -1);
    _8858 = (_f_15961 < 100);
    _8859 = (_8857 != 0 && _8858 != 0);
    _8857 = NOVALUE;
    _8858 = NOVALUE;
    return _8859;
    ;
}


int _35symtab_pointer(int _x_62750)
{
    int _31347 = NOVALUE;
    int _31346 = NOVALUE;
    int _31345 = NOVALUE;
    int _31344 = NOVALUE;
    int _31343 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_62750)) {
        _1 = (long)(DBL_PTR(_x_62750)->dbl);
        DeRefDS(_x_62750);
        _x_62750 = _1;
    }

    /** 	return x = -1 or symtab_index(x) or forward_reference(x)*/
    _31343 = (_x_62750 == -1);
    _31344 = _35symtab_index(_x_62750);
    if (IS_ATOM_INT(_31344)) {
        _31345 = (_31343 != 0 || _31344 != 0);
    }
    else {
        _31345 = binary_op(OR, _31343, _31344);
    }
    _31343 = NOVALUE;
    DeRef(_31344);
    _31344 = NOVALUE;
    _31346 = _38forward_reference(_x_62750);
    if (IS_ATOM_INT(_31345) && IS_ATOM_INT(_31346)) {
        _31347 = (_31345 != 0 || _31346 != 0);
    }
    else {
        _31347 = binary_op(OR, _31345, _31346);
    }
    DeRef(_31345);
    _31345 = NOVALUE;
    DeRef(_31346);
    _31346 = NOVALUE;
    return _31347;
    ;
}



// 0x2E637E08
