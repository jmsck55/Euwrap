// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _11positive_int(int _x_356)
{
    int _64 = NOVALUE;
    int _62 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(x) then*/
    if (IS_ATOM_INT(_x_356))
    _62 = 1;
    else if (IS_ATOM_DBL(_x_356))
    _62 = IS_ATOM_INT(DoubleToInt(_x_356));
    else
    _62 = 0;
    if (_62 != 0)
    goto L1; // [6] 16
    _62 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_356);
    return 0;
L1: 

    /**     return x >= 1*/
    if (IS_ATOM_INT(_x_356)) {
        _64 = (_x_356 >= 1);
    }
    else {
        _64 = binary_op(GREATEREQ, _x_356, 1);
    }
    DeRef(_x_356);
    return _64;
    ;
}


void _11deallocate(int _addr_378)
{
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_378);

    /** end procedure*/
    DeRef(_addr_378);
    return;
    ;
}


int _11prepare_block(int _addr_404, int _a_405, int _protection_406)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_405)) {
        _1 = (long)(DBL_PTR(_a_405)->dbl);
        DeRefDS(_a_405);
        _a_405 = _1;
    }
    if (!IS_ATOM_INT(_protection_406)) {
        _1 = (long)(DBL_PTR(_protection_406)->dbl);
        DeRefDS(_protection_406);
        _protection_406 = _1;
    }

    /** 	return addr*/
    return _addr_404;
    ;
}


int _11bordered_address(int _addr_414)
{
    int _78 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(addr) then*/
    _78 = IS_ATOM(_addr_414);
    if (_78 != 0)
    goto L1; // [6] 16
    _78 = NOVALUE;

    /** 		return 0*/
    DeRef(_addr_414);
    return 0;
L1: 

    /** 	return 1*/
    DeRef(_addr_414);
    return 1;
    ;
}


int _11dep_works()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	return 1*/
    return 1;
    ;
}



// 0xA619839D
