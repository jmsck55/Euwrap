// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _6get_ch()
{
    int _5634 = NOVALUE;
    int _5633 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _5633 = IS_SEQUENCE(_6input_string_10097);
    if (_5633 == 0)
    {
        _5633 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _5633 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_6input_string_10097)){
            _5634 = SEQ_PTR(_6input_string_10097)->length;
    }
    else {
        _5634 = 1;
    }
    if (_6string_next_10098 > _5634)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_6input_string_10097);
    _6ch_10099 = (int)*(((s1_ptr)_2)->base + _6string_next_10098);
    if (!IS_ATOM_INT(_6ch_10099)){
        _6ch_10099 = (long)DBL_PTR(_6ch_10099)->dbl;
    }

    /** 			string_next += 1*/
    _6string_next_10098 = _6string_next_10098 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _6ch_10099 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_6input_file_10096 != last_r_file_no) {
        last_r_file_ptr = which_file(_6input_file_10096, EF_READ);
        last_r_file_no = _6input_file_10096;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _6ch_10099 = getc((FILE*)xstdin);
        }
        else
        _6ch_10099 = getc(last_r_file_ptr);
    }
    else
    _6ch_10099 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_6ch_10099 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _6string_next_10098 = _6string_next_10098 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _6escape_char(int _c_10126)
{
    int _i_10127 = NOVALUE;
    int _5646 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_10127 = find_from(_c_10126, _6ESCAPE_CHARS_10120, 1);

    /** 	if i = 0 then*/
    if (_i_10127 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_6ESCAPED_CHARS_10122);
    _5646 = (int)*(((s1_ptr)_2)->base + _i_10127);
    Ref(_5646);
    return _5646;
L2: 
    ;
}


int _6get_qchar()
{
    int _c_10135 = NOVALUE;
    int _5655 = NOVALUE;
    int _5654 = NOVALUE;
    int _5652 = NOVALUE;
    int _5650 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _6get_ch();

    /** 	c = ch*/
    _c_10135 = _6ch_10099;

    /** 	if ch = '\\' then*/
    if (_6ch_10099 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _6get_ch();

    /** 		c = escape_char(ch)*/
    _c_10135 = _6escape_char(_6ch_10099);
    if (!IS_ATOM_INT(_c_10135)) {
        _1 = (long)(DBL_PTR(_c_10135)->dbl);
        DeRefDS(_c_10135);
        _c_10135 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_10135 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5650 = MAKE_SEQ(_1);
    return _5650;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_6ch_10099 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5652 = MAKE_SEQ(_1);
    DeRef(_5650);
    _5650 = NOVALUE;
    return _5652;
L3: 
L2: 

    /** 	get_ch()*/
    _6get_ch();

    /** 	if ch != '\'' then*/
    if (_6ch_10099 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5654 = MAKE_SEQ(_1);
    DeRef(_5650);
    _5650 = NOVALUE;
    DeRef(_5652);
    _5652 = NOVALUE;
    return _5654;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_10135;
    _5655 = MAKE_SEQ(_1);
    DeRef(_5650);
    _5650 = NOVALUE;
    DeRef(_5652);
    _5652 = NOVALUE;
    DeRef(_5654);
    _5654 = NOVALUE;
    return _5655;
L5: 
    ;
}


int _6get_string()
{
    int _text_10152 = NOVALUE;
    int _5665 = NOVALUE;
    int _5661 = NOVALUE;
    int _5659 = NOVALUE;
    int _5658 = NOVALUE;
    int _5656 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_10152);
    _text_10152 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _5656 = (_6ch_10099 == -1);
    if (_5656 != 0) {
        goto L2; // [25] 40
    }
    _5658 = (_6ch_10099 == 10);
    if (_5658 == 0)
    {
        DeRef(_5658);
        _5658 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_5658);
        _5658 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5659 = MAKE_SEQ(_1);
    DeRefi(_text_10152);
    DeRef(_5656);
    _5656 = NOVALUE;
    return _5659;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_6ch_10099 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _6get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_10152);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_10152;
    _5661 = MAKE_SEQ(_1);
    DeRefDSi(_text_10152);
    DeRef(_5656);
    _5656 = NOVALUE;
    DeRef(_5659);
    _5659 = NOVALUE;
    return _5661;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_6ch_10099 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _6get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _6escape_char(_6ch_10099);
    _6ch_10099 = _0;
    if (!IS_ATOM_INT(_6ch_10099)) {
        _1 = (long)(DBL_PTR(_6ch_10099)->dbl);
        DeRefDS(_6ch_10099);
        _6ch_10099 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_6ch_10099 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5665 = MAKE_SEQ(_1);
    DeRefi(_text_10152);
    DeRef(_5656);
    _5656 = NOVALUE;
    DeRef(_5659);
    _5659 = NOVALUE;
    DeRef(_5661);
    _5661 = NOVALUE;
    return _5665;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_10152, _text_10152, _6ch_10099);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _6read_comment()
{
    int _5686 = NOVALUE;
    int _5685 = NOVALUE;
    int _5683 = NOVALUE;
    int _5681 = NOVALUE;
    int _5679 = NOVALUE;
    int _5678 = NOVALUE;
    int _5677 = NOVALUE;
    int _5675 = NOVALUE;
    int _5674 = NOVALUE;
    int _5673 = NOVALUE;
    int _5672 = NOVALUE;
    int _5671 = NOVALUE;
    int _5670 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _5670 = IS_ATOM(_6input_string_10097);
    if (_5670 == 0)
    {
        _5670 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _5670 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _5671 = (_6ch_10099 != 10);
    if (_5671 == 0) {
        _5672 = 0;
        goto L3; // [22] 36
    }
    _5673 = (_6ch_10099 != 13);
    _5672 = (_5673 != 0);
L3: 
    if (_5672 == 0) {
        goto L4; // [36] 59
    }
    _5675 = (_6ch_10099 != -1);
    if (_5675 == 0)
    {
        DeRef(_5675);
        _5675 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_5675);
        _5675 = NOVALUE;
    }

    /** 			get_ch()*/
    _6get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch=-1 then*/
    if (_6ch_10099 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5677 = MAKE_SEQ(_1);
    DeRef(_5671);
    _5671 = NOVALUE;
    DeRef(_5673);
    _5673 = NOVALUE;
    return _5677;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _5678 = MAKE_SEQ(_1);
    DeRef(_5671);
    _5671 = NOVALUE;
    DeRef(_5673);
    _5673 = NOVALUE;
    DeRef(_5677);
    _5677 = NOVALUE;
    return _5678;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_6input_string_10097)){
            _5679 = SEQ_PTR(_6input_string_10097)->length;
    }
    else {
        _5679 = 1;
    }
    {
        int _i_10193;
        _i_10193 = _6string_next_10098;
L7: 
        if (_i_10193 > _5679){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_6input_string_10097);
        _6ch_10099 = (int)*(((s1_ptr)_2)->base + _i_10193);
        if (!IS_ATOM_INT(_6ch_10099)){
            _6ch_10099 = (long)DBL_PTR(_6ch_10099)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _5681 = (_6ch_10099 == 10);
        if (_5681 != 0) {
            goto L9; // [132] 147
        }
        _5683 = (_6ch_10099 == 13);
        if (_5683 == 0)
        {
            DeRef(_5683);
            _5683 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_5683);
            _5683 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _6string_next_10098 = _i_10193 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _5685 = MAKE_SEQ(_1);
        DeRef(_5671);
        _5671 = NOVALUE;
        DeRef(_5673);
        _5673 = NOVALUE;
        DeRef(_5677);
        _5677 = NOVALUE;
        DeRef(_5678);
        _5678 = NOVALUE;
        DeRef(_5681);
        _5681 = NOVALUE;
        return _5685;
LA: 

        /** 		end for*/
        _i_10193 = _i_10193 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5686 = MAKE_SEQ(_1);
    DeRef(_5671);
    _5671 = NOVALUE;
    DeRef(_5673);
    _5673 = NOVALUE;
    DeRef(_5677);
    _5677 = NOVALUE;
    DeRef(_5678);
    _5678 = NOVALUE;
    DeRef(_5681);
    _5681 = NOVALUE;
    DeRef(_5685);
    _5685 = NOVALUE;
    return _5686;
L6: 
    ;
}


int _6get_number()
{
    int _sign_10205 = NOVALUE;
    int _e_sign_10206 = NOVALUE;
    int _ndigits_10207 = NOVALUE;
    int _hex_digit_10208 = NOVALUE;
    int _mantissa_10209 = NOVALUE;
    int _dec_10210 = NOVALUE;
    int _e_mag_10211 = NOVALUE;
    int _5747 = NOVALUE;
    int _5745 = NOVALUE;
    int _5743 = NOVALUE;
    int _5740 = NOVALUE;
    int _5736 = NOVALUE;
    int _5734 = NOVALUE;
    int _5733 = NOVALUE;
    int _5732 = NOVALUE;
    int _5731 = NOVALUE;
    int _5730 = NOVALUE;
    int _5728 = NOVALUE;
    int _5727 = NOVALUE;
    int _5726 = NOVALUE;
    int _5723 = NOVALUE;
    int _5721 = NOVALUE;
    int _5719 = NOVALUE;
    int _5715 = NOVALUE;
    int _5714 = NOVALUE;
    int _5712 = NOVALUE;
    int _5711 = NOVALUE;
    int _5710 = NOVALUE;
    int _5707 = NOVALUE;
    int _5706 = NOVALUE;
    int _5704 = NOVALUE;
    int _5703 = NOVALUE;
    int _5702 = NOVALUE;
    int _5701 = NOVALUE;
    int _5700 = NOVALUE;
    int _5699 = NOVALUE;
    int _5696 = NOVALUE;
    int _5692 = NOVALUE;
    int _5689 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_10205 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_10209);
    _mantissa_10209 = 0;

    /** 	ndigits = 0*/
    _ndigits_10207 = 0;

    /** 	if ch = '-' then*/
    if (_6ch_10099 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_10205 = -1;

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch='-' then*/
    if (_6ch_10099 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _5689 = _6read_comment();
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    return _5689;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_6ch_10099 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _6get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_6ch_10099 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _6get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _5692 = find_from(_6ch_10099, _6HEX_DIGITS_10079, 1);
    _hex_digit_10208 = _5692 - 1;
    _5692 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_10208 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_10207 = _ndigits_10207 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_10209)) {
        if (_mantissa_10209 == (short)_mantissa_10209)
        _5696 = _mantissa_10209 * 16;
        else
        _5696 = NewDouble(_mantissa_10209 * (double)16);
    }
    else {
        _5696 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * (double)16);
    }
    DeRef(_mantissa_10209);
    if (IS_ATOM_INT(_5696)) {
        _mantissa_10209 = _5696 + _hex_digit_10208;
        if ((long)((unsigned long)_mantissa_10209 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10209 = NewDouble((double)_mantissa_10209);
    }
    else {
        _mantissa_10209 = NewDouble(DBL_PTR(_5696)->dbl + (double)_hex_digit_10208);
    }
    DeRef(_5696);
    _5696 = NOVALUE;

    /** 				get_ch()*/
    _6get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_10207 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_10209)) {
        if (_sign_10205 == (short)_sign_10205 && _mantissa_10209 <= INT15 && _mantissa_10209 >= -INT15)
        _5699 = _sign_10205 * _mantissa_10209;
        else
        _5699 = NewDouble(_sign_10205 * (double)_mantissa_10209);
    }
    else {
        _5699 = NewDouble((double)_sign_10205 * DBL_PTR(_mantissa_10209)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _5699;
    _5700 = MAKE_SEQ(_1);
    _5699 = NOVALUE;
    DeRef(_mantissa_10209);
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    DeRef(_5689);
    _5689 = NOVALUE;
    return _5700;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5701 = MAKE_SEQ(_1);
    DeRef(_mantissa_10209);
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    DeRef(_5689);
    _5689 = NOVALUE;
    DeRef(_5700);
    _5700 = NOVALUE;
    return _5701;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _5702 = (_6ch_10099 >= 48);
    if (_5702 == 0) {
        goto L9; // [181] 226
    }
    _5704 = (_6ch_10099 <= 57);
    if (_5704 == 0)
    {
        DeRef(_5704);
        _5704 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_5704);
        _5704 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_10207 = _ndigits_10207 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_10209)) {
        if (_mantissa_10209 == (short)_mantissa_10209)
        _5706 = _mantissa_10209 * 10;
        else
        _5706 = NewDouble(_mantissa_10209 * (double)10);
    }
    else {
        _5706 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * (double)10);
    }
    _5707 = _6ch_10099 - 48;
    if ((long)((unsigned long)_5707 +(unsigned long) HIGH_BITS) >= 0){
        _5707 = NewDouble((double)_5707);
    }
    DeRef(_mantissa_10209);
    if (IS_ATOM_INT(_5706) && IS_ATOM_INT(_5707)) {
        _mantissa_10209 = _5706 + _5707;
        if ((long)((unsigned long)_mantissa_10209 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10209 = NewDouble((double)_mantissa_10209);
    }
    else {
        if (IS_ATOM_INT(_5706)) {
            _mantissa_10209 = NewDouble((double)_5706 + DBL_PTR(_5707)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5707)) {
                _mantissa_10209 = NewDouble(DBL_PTR(_5706)->dbl + (double)_5707);
            }
            else
            _mantissa_10209 = NewDouble(DBL_PTR(_5706)->dbl + DBL_PTR(_5707)->dbl);
        }
    }
    DeRef(_5706);
    _5706 = NOVALUE;
    DeRef(_5707);
    _5707 = NOVALUE;

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_6ch_10099 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _6get_ch();

    /** 		dec = 10*/
    DeRef(_dec_10210);
    _dec_10210 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _5710 = (_6ch_10099 >= 48);
    if (_5710 == 0) {
        goto LC; // [254] 305
    }
    _5712 = (_6ch_10099 <= 57);
    if (_5712 == 0)
    {
        DeRef(_5712);
        _5712 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_5712);
        _5712 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_10207 = _ndigits_10207 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _5714 = _6ch_10099 - 48;
    if ((long)((unsigned long)_5714 +(unsigned long) HIGH_BITS) >= 0){
        _5714 = NewDouble((double)_5714);
    }
    if (IS_ATOM_INT(_5714) && IS_ATOM_INT(_dec_10210)) {
        _5715 = (_5714 % _dec_10210) ? NewDouble((double)_5714 / _dec_10210) : (_5714 / _dec_10210);
    }
    else {
        if (IS_ATOM_INT(_5714)) {
            _5715 = NewDouble((double)_5714 / DBL_PTR(_dec_10210)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_10210)) {
                _5715 = NewDouble(DBL_PTR(_5714)->dbl / (double)_dec_10210);
            }
            else
            _5715 = NewDouble(DBL_PTR(_5714)->dbl / DBL_PTR(_dec_10210)->dbl);
        }
    }
    DeRef(_5714);
    _5714 = NOVALUE;
    _0 = _mantissa_10209;
    if (IS_ATOM_INT(_mantissa_10209) && IS_ATOM_INT(_5715)) {
        _mantissa_10209 = _mantissa_10209 + _5715;
        if ((long)((unsigned long)_mantissa_10209 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_10209 = NewDouble((double)_mantissa_10209);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10209)) {
            _mantissa_10209 = NewDouble((double)_mantissa_10209 + DBL_PTR(_5715)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5715)) {
                _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl + (double)_5715);
            }
            else
            _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl + DBL_PTR(_5715)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5715);
    _5715 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_10210;
    if (IS_ATOM_INT(_dec_10210)) {
        if (_dec_10210 == (short)_dec_10210)
        _dec_10210 = _dec_10210 * 10;
        else
        _dec_10210 = NewDouble(_dec_10210 * (double)10);
    }
    else {
        _dec_10210 = NewDouble(DBL_PTR(_dec_10210)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _6get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_10207 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5719 = MAKE_SEQ(_1);
    DeRef(_mantissa_10209);
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    DeRef(_5689);
    _5689 = NOVALUE;
    DeRef(_5700);
    _5700 = NOVALUE;
    DeRef(_5701);
    _5701 = NOVALUE;
    DeRef(_5702);
    _5702 = NOVALUE;
    DeRef(_5710);
    _5710 = NOVALUE;
    return _5719;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_10209;
    if (IS_ATOM_INT(_mantissa_10209)) {
        if (_sign_10205 == (short)_sign_10205 && _mantissa_10209 <= INT15 && _mantissa_10209 >= -INT15)
        _mantissa_10209 = _sign_10205 * _mantissa_10209;
        else
        _mantissa_10209 = NewDouble(_sign_10205 * (double)_mantissa_10209);
    }
    else {
        _mantissa_10209 = NewDouble((double)_sign_10205 * DBL_PTR(_mantissa_10209)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _5721 = (_6ch_10099 == 101);
    if (_5721 != 0) {
        goto LE; // [337] 352
    }
    _5723 = (_6ch_10099 == 69);
    if (_5723 == 0)
    {
        DeRef(_5723);
        _5723 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_5723);
        _5723 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_10206 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_10211);
    _e_mag_10211 = 0;

    /** 		get_ch()*/
    _6get_ch();

    /** 		if ch = '-' then*/
    if (_6ch_10099 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_10206 = -1;

    /** 			get_ch()*/
    _6get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_6ch_10099 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _6get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _5726 = (_6ch_10099 >= 48);
    if (_5726 == 0) {
        goto L13; // [408] 487
    }
    _5728 = (_6ch_10099 <= 57);
    if (_5728 == 0)
    {
        DeRef(_5728);
        _5728 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_5728);
        _5728 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_10211);
    _e_mag_10211 = _6ch_10099 - 48;
    if ((long)((unsigned long)_e_mag_10211 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_10211 = NewDouble((double)_e_mag_10211);
    }

    /** 			get_ch()*/
    _6get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _5730 = (_6ch_10099 >= 48);
    if (_5730 == 0) {
        goto L15; // [445] 498
    }
    _5732 = (_6ch_10099 <= 57);
    if (_5732 == 0)
    {
        DeRef(_5732);
        _5732 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_5732);
        _5732 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_10211)) {
        if (_e_mag_10211 == (short)_e_mag_10211)
        _5733 = _e_mag_10211 * 10;
        else
        _5733 = NewDouble(_e_mag_10211 * (double)10);
    }
    else {
        _5733 = NewDouble(DBL_PTR(_e_mag_10211)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_5733)) {
        _5734 = _5733 + _6ch_10099;
        if ((long)((unsigned long)_5734 + (unsigned long)HIGH_BITS) >= 0) 
        _5734 = NewDouble((double)_5734);
    }
    else {
        _5734 = NewDouble(DBL_PTR(_5733)->dbl + (double)_6ch_10099);
    }
    DeRef(_5733);
    _5733 = NOVALUE;
    DeRef(_e_mag_10211);
    if (IS_ATOM_INT(_5734)) {
        _e_mag_10211 = _5734 - 48;
        if ((long)((unsigned long)_e_mag_10211 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_10211 = NewDouble((double)_e_mag_10211);
        }
    }
    else {
        _e_mag_10211 = NewDouble(DBL_PTR(_5734)->dbl - (double)48);
    }
    DeRef(_5734);
    _5734 = NOVALUE;

    /** 				get_ch()*/
    _6get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5736 = MAKE_SEQ(_1);
    DeRef(_mantissa_10209);
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    DeRef(_5689);
    _5689 = NOVALUE;
    DeRef(_5700);
    _5700 = NOVALUE;
    DeRef(_5701);
    _5701 = NOVALUE;
    DeRef(_5702);
    _5702 = NOVALUE;
    DeRef(_5710);
    _5710 = NOVALUE;
    DeRef(_5719);
    _5719 = NOVALUE;
    DeRef(_5721);
    _5721 = NOVALUE;
    DeRef(_5726);
    _5726 = NOVALUE;
    DeRef(_5730);
    _5730 = NOVALUE;
    return _5736;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_10211;
    if (IS_ATOM_INT(_e_mag_10211)) {
        if (_e_mag_10211 == (short)_e_mag_10211 && _e_sign_10206 <= INT15 && _e_sign_10206 >= -INT15)
        _e_mag_10211 = _e_mag_10211 * _e_sign_10206;
        else
        _e_mag_10211 = NewDouble(_e_mag_10211 * (double)_e_sign_10206);
    }
    else {
        _e_mag_10211 = NewDouble(DBL_PTR(_e_mag_10211)->dbl * (double)_e_sign_10206);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_10211, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _5740 = power(10, 308);
    _0 = _mantissa_10209;
    if (IS_ATOM_INT(_mantissa_10209) && IS_ATOM_INT(_5740)) {
        if (_mantissa_10209 == (short)_mantissa_10209 && _5740 <= INT15 && _5740 >= -INT15)
        _mantissa_10209 = _mantissa_10209 * _5740;
        else
        _mantissa_10209 = NewDouble(_mantissa_10209 * (double)_5740);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10209)) {
            _mantissa_10209 = NewDouble((double)_mantissa_10209 * DBL_PTR(_5740)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5740)) {
                _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * (double)_5740);
            }
            else
            _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * DBL_PTR(_5740)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5740);
    _5740 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_10211, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_10211);
    _e_mag_10211 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_10211)) {
        _5743 = _e_mag_10211 - 308;
        if ((long)((unsigned long)_5743 +(unsigned long) HIGH_BITS) >= 0){
            _5743 = NewDouble((double)_5743);
        }
    }
    else {
        _5743 = NewDouble(DBL_PTR(_e_mag_10211)->dbl - (double)308);
    }
    {
        int _i_10290;
        _i_10290 = 1;
L18: 
        if (binary_op_a(GREATER, _i_10290, _5743)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_10209;
        if (IS_ATOM_INT(_mantissa_10209)) {
            if (_mantissa_10209 == (short)_mantissa_10209)
            _mantissa_10209 = _mantissa_10209 * 10;
            else
            _mantissa_10209 = NewDouble(_mantissa_10209 * (double)10);
        }
        else {
            _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_10290;
        if (IS_ATOM_INT(_i_10290)) {
            _i_10290 = _i_10290 + 1;
            if ((long)((unsigned long)_i_10290 +(unsigned long) HIGH_BITS) >= 0){
                _i_10290 = NewDouble((double)_i_10290);
            }
        }
        else {
            _i_10290 = binary_op_a(PLUS, _i_10290, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_10290);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_10211)) {
        _5745 = power(10, _e_mag_10211);
    }
    else {
        temp_d.dbl = (double)10;
        _5745 = Dpower(&temp_d, DBL_PTR(_e_mag_10211));
    }
    _0 = _mantissa_10209;
    if (IS_ATOM_INT(_mantissa_10209) && IS_ATOM_INT(_5745)) {
        if (_mantissa_10209 == (short)_mantissa_10209 && _5745 <= INT15 && _5745 >= -INT15)
        _mantissa_10209 = _mantissa_10209 * _5745;
        else
        _mantissa_10209 = NewDouble(_mantissa_10209 * (double)_5745);
    }
    else {
        if (IS_ATOM_INT(_mantissa_10209)) {
            _mantissa_10209 = NewDouble((double)_mantissa_10209 * DBL_PTR(_5745)->dbl);
        }
        else {
            if (IS_ATOM_INT(_5745)) {
                _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * (double)_5745);
            }
            else
            _mantissa_10209 = NewDouble(DBL_PTR(_mantissa_10209)->dbl * DBL_PTR(_5745)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_5745);
    _5745 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_10209);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_10209;
    _5747 = MAKE_SEQ(_1);
    DeRef(_mantissa_10209);
    DeRef(_dec_10210);
    DeRef(_e_mag_10211);
    DeRef(_5689);
    _5689 = NOVALUE;
    DeRef(_5700);
    _5700 = NOVALUE;
    DeRef(_5701);
    _5701 = NOVALUE;
    DeRef(_5702);
    _5702 = NOVALUE;
    DeRef(_5710);
    _5710 = NOVALUE;
    DeRef(_5719);
    _5719 = NOVALUE;
    DeRef(_5721);
    _5721 = NOVALUE;
    DeRef(_5726);
    _5726 = NOVALUE;
    DeRef(_5730);
    _5730 = NOVALUE;
    DeRef(_5736);
    _5736 = NOVALUE;
    DeRef(_5743);
    _5743 = NOVALUE;
    return _5747;
    ;
}


int _6Get()
{
    int _skip_blanks_1__tmp_at328_10343 = NOVALUE;
    int _skip_blanks_1__tmp_at177_10324 = NOVALUE;
    int _skip_blanks_1__tmp_at88_10315 = NOVALUE;
    int _s_10299 = NOVALUE;
    int _e_10300 = NOVALUE;
    int _e1_10301 = NOVALUE;
    int _5783 = NOVALUE;
    int _5782 = NOVALUE;
    int _5780 = NOVALUE;
    int _5778 = NOVALUE;
    int _5776 = NOVALUE;
    int _5774 = NOVALUE;
    int _5771 = NOVALUE;
    int _5769 = NOVALUE;
    int _5765 = NOVALUE;
    int _5761 = NOVALUE;
    int _5758 = NOVALUE;
    int _5757 = NOVALUE;
    int _5755 = NOVALUE;
    int _5753 = NOVALUE;
    int _5751 = NOVALUE;
    int _5750 = NOVALUE;
    int _5748 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _5748 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_5748 == 0)
    {
        _5748 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _5748 = NOVALUE;
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10099 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _5750 = MAKE_SEQ(_1);
    DeRef(_s_10299);
    DeRef(_e_10300);
    return _5750;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _5751 = find_from(_6ch_10099, _6START_NUMERIC_10082, 1);
    if (_5751 == 0)
    {
        _5751 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _5751 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_10300;
    _e_10300 = _6get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_10300);
    _5753 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5753, -2)){
        _5753 = NOVALUE;
        goto L6; // [76] 87
    }
    _5753 = NOVALUE;

    /** 				return e*/
    DeRef(_s_10299);
    DeRef(_5750);
    _5750 = NOVALUE;
    return _e_10300;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_10315 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_skip_blanks_1__tmp_at88_10315 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _5755 = (_6ch_10099 == -1);
    if (_5755 != 0) {
        goto L9; // [128] 143
    }
    _5757 = (_6ch_10099 == 125);
    if (_5757 == 0)
    {
        DeRef(_5757);
        _5757 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_5757);
        _5757 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _5758 = MAKE_SEQ(_1);
    DeRef(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    return _5758;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_6ch_10099 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_10299);
    _s_10299 = _5;

    /** 			get_ch()*/
    _6get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_10324 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_skip_blanks_1__tmp_at177_10324 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_6ch_10099 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _6get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10299);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10299;
    _5761 = MAKE_SEQ(_1);
    DeRefDS(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    return _5761;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_10300;
    _e_10300 = _6Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_10300);
    _e1_10301 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_10301))
    _e1_10301 = (long)DBL_PTR(_e1_10301)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_10301 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_10300);
    _5765 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_5765);
    Append(&_s_10299, _s_10299, _5765);
    _5765 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_10301 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_10299);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    return _e_10300;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_6ch_10099 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _6get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_10299);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10299;
    _5769 = MAKE_SEQ(_1);
    DeRefDS(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    return _5769;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_10343 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_skip_blanks_1__tmp_at328_10343 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_6ch_10099 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _6get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_10299);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_10299;
    _5771 = MAKE_SEQ(_1);
    DeRefDS(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    return _5771;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_6ch_10099 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_10300;
    _e_10300 = _6get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_10300);
    _5774 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5774, -2)){
        _5774 = NOVALUE;
        goto L13; // [413] 327
    }
    _5774 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5776 = MAKE_SEQ(_1);
    DeRef(_s_10299);
    DeRefDS(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    DeRef(_5771);
    _5771 = NOVALUE;
    return _5776;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_6ch_10099 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5778 = MAKE_SEQ(_1);
    DeRef(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    DeRef(_5771);
    _5771 = NOVALUE;
    DeRef(_5776);
    _5776 = NOVALUE;
    return _5778;
L19: 

    /** 			get_ch() -- skip comma*/
    _6get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_6ch_10099 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _5780 = _6get_string();
    DeRef(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    DeRef(_5771);
    _5771 = NOVALUE;
    DeRef(_5776);
    _5776 = NOVALUE;
    DeRef(_5778);
    _5778 = NOVALUE;
    return _5780;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_6ch_10099 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _5782 = _6get_qchar();
    DeRef(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    DeRef(_5771);
    _5771 = NOVALUE;
    DeRef(_5776);
    _5776 = NOVALUE;
    DeRef(_5778);
    _5778 = NOVALUE;
    DeRef(_5780);
    _5780 = NOVALUE;
    return _5782;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _5783 = MAKE_SEQ(_1);
    DeRef(_s_10299);
    DeRef(_e_10300);
    DeRef(_5750);
    _5750 = NOVALUE;
    DeRef(_5755);
    _5755 = NOVALUE;
    DeRef(_5758);
    _5758 = NOVALUE;
    DeRef(_5761);
    _5761 = NOVALUE;
    DeRef(_5769);
    _5769 = NOVALUE;
    DeRef(_5771);
    _5771 = NOVALUE;
    DeRef(_5776);
    _5776 = NOVALUE;
    DeRef(_5778);
    _5778 = NOVALUE;
    DeRef(_5780);
    _5780 = NOVALUE;
    DeRef(_5782);
    _5782 = NOVALUE;
    return _5783;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _6Get2()
{
    int _skip_blanks_1__tmp_at464_10440 = NOVALUE;
    int _skip_blanks_1__tmp_at233_10407 = NOVALUE;
    int _s_10369 = NOVALUE;
    int _e_10370 = NOVALUE;
    int _e1_10371 = NOVALUE;
    int _offset_10372 = NOVALUE;
    int _5875 = NOVALUE;
    int _5874 = NOVALUE;
    int _5873 = NOVALUE;
    int _5872 = NOVALUE;
    int _5871 = NOVALUE;
    int _5870 = NOVALUE;
    int _5869 = NOVALUE;
    int _5868 = NOVALUE;
    int _5867 = NOVALUE;
    int _5866 = NOVALUE;
    int _5865 = NOVALUE;
    int _5862 = NOVALUE;
    int _5861 = NOVALUE;
    int _5860 = NOVALUE;
    int _5859 = NOVALUE;
    int _5858 = NOVALUE;
    int _5857 = NOVALUE;
    int _5854 = NOVALUE;
    int _5853 = NOVALUE;
    int _5852 = NOVALUE;
    int _5851 = NOVALUE;
    int _5850 = NOVALUE;
    int _5848 = NOVALUE;
    int _5847 = NOVALUE;
    int _5846 = NOVALUE;
    int _5845 = NOVALUE;
    int _5844 = NOVALUE;
    int _5842 = NOVALUE;
    int _5839 = NOVALUE;
    int _5838 = NOVALUE;
    int _5837 = NOVALUE;
    int _5836 = NOVALUE;
    int _5835 = NOVALUE;
    int _5833 = NOVALUE;
    int _5832 = NOVALUE;
    int _5831 = NOVALUE;
    int _5830 = NOVALUE;
    int _5829 = NOVALUE;
    int _5827 = NOVALUE;
    int _5826 = NOVALUE;
    int _5825 = NOVALUE;
    int _5824 = NOVALUE;
    int _5823 = NOVALUE;
    int _5822 = NOVALUE;
    int _5819 = NOVALUE;
    int _5815 = NOVALUE;
    int _5814 = NOVALUE;
    int _5813 = NOVALUE;
    int _5812 = NOVALUE;
    int _5811 = NOVALUE;
    int _5808 = NOVALUE;
    int _5807 = NOVALUE;
    int _5806 = NOVALUE;
    int _5805 = NOVALUE;
    int _5804 = NOVALUE;
    int _5802 = NOVALUE;
    int _5801 = NOVALUE;
    int _5800 = NOVALUE;
    int _5799 = NOVALUE;
    int _5798 = NOVALUE;
    int _5797 = NOVALUE;
    int _5795 = NOVALUE;
    int _5793 = NOVALUE;
    int _5791 = NOVALUE;
    int _5790 = NOVALUE;
    int _5789 = NOVALUE;
    int _5788 = NOVALUE;
    int _5787 = NOVALUE;
    int _5785 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_10372 = _6string_next_10098 - 1;

    /** 	get_ch()*/
    _6get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _5785 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_5785 == 0)
    {
        _5785 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _5785 = NOVALUE;
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_6ch_10099 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _5787 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5787 +(unsigned long) HIGH_BITS) >= 0){
        _5787 = NewDouble((double)_5787);
    }
    if (IS_ATOM_INT(_5787)) {
        _5788 = _5787 - _offset_10372;
        if ((long)((unsigned long)_5788 +(unsigned long) HIGH_BITS) >= 0){
            _5788 = NewDouble((double)_5788);
        }
    }
    else {
        _5788 = NewDouble(DBL_PTR(_5787)->dbl - (double)_offset_10372);
    }
    DeRef(_5787);
    _5787 = NOVALUE;
    _5789 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5789 +(unsigned long) HIGH_BITS) >= 0){
        _5789 = NewDouble((double)_5789);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5788;
    *((int *)(_2+16)) = _5789;
    _5790 = MAKE_SEQ(_1);
    _5789 = NOVALUE;
    _5788 = NOVALUE;
    DeRef(_s_10369);
    DeRef(_e_10370);
    return _5790;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _5791 = _6string_next_10098 - 2;
    if ((long)((unsigned long)_5791 +(unsigned long) HIGH_BITS) >= 0){
        _5791 = NewDouble((double)_5791);
    }
    if (IS_ATOM_INT(_5791)) {
        _6leading_whitespace_10366 = _5791 - _offset_10372;
    }
    else {
        _6leading_whitespace_10366 = NewDouble(DBL_PTR(_5791)->dbl - (double)_offset_10372);
    }
    DeRef(_5791);
    _5791 = NOVALUE;
    if (!IS_ATOM_INT(_6leading_whitespace_10366)) {
        _1 = (long)(DBL_PTR(_6leading_whitespace_10366)->dbl);
        DeRefDS(_6leading_whitespace_10366);
        _6leading_whitespace_10366 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _5793 = find_from(_6ch_10099, _6START_NUMERIC_10082, 1);
    if (_5793 == 0)
    {
        _5793 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _5793 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_10370;
    _e_10370 = _6get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_10370);
    _5795 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5795, -2)){
        _5795 = NOVALUE;
        goto L6; // [121] 162
    }
    _5795 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5797 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5797 +(unsigned long) HIGH_BITS) >= 0){
        _5797 = NewDouble((double)_5797);
    }
    if (IS_ATOM_INT(_5797)) {
        _5798 = _5797 - _offset_10372;
        if ((long)((unsigned long)_5798 +(unsigned long) HIGH_BITS) >= 0){
            _5798 = NewDouble((double)_5798);
        }
    }
    else {
        _5798 = NewDouble(DBL_PTR(_5797)->dbl - (double)_offset_10372);
    }
    DeRef(_5797);
    _5797 = NOVALUE;
    _5799 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5798)) {
        _5800 = _5798 - _5799;
        if ((long)((unsigned long)_5800 +(unsigned long) HIGH_BITS) >= 0){
            _5800 = NewDouble((double)_5800);
        }
    }
    else {
        _5800 = NewDouble(DBL_PTR(_5798)->dbl - (double)_5799);
    }
    DeRef(_5798);
    _5798 = NOVALUE;
    _5799 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5800;
    ((int *)_2)[2] = _6leading_whitespace_10366;
    _5801 = MAKE_SEQ(_1);
    _5800 = NOVALUE;
    Concat((object_ptr)&_5802, _e_10370, _5801);
    DeRefDS(_5801);
    _5801 = NOVALUE;
    DeRef(_s_10369);
    DeRefDS(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    return _5802;
L6: 

    /** 			get_ch()*/
    _6get_ch();

    /** 			if ch=-1 then*/
    if (_6ch_10099 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _5804 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5804 +(unsigned long) HIGH_BITS) >= 0){
        _5804 = NewDouble((double)_5804);
    }
    if (IS_ATOM_INT(_5804)) {
        _5805 = _5804 - _offset_10372;
        if ((long)((unsigned long)_5805 +(unsigned long) HIGH_BITS) >= 0){
            _5805 = NewDouble((double)_5805);
        }
    }
    else {
        _5805 = NewDouble(DBL_PTR(_5804)->dbl - (double)_offset_10372);
    }
    DeRef(_5804);
    _5804 = NOVALUE;
    _5806 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5805)) {
        _5807 = _5805 - _5806;
        if ((long)((unsigned long)_5807 +(unsigned long) HIGH_BITS) >= 0){
            _5807 = NewDouble((double)_5807);
        }
    }
    else {
        _5807 = NewDouble(DBL_PTR(_5805)->dbl - (double)_5806);
    }
    DeRef(_5805);
    _5805 = NOVALUE;
    _5806 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5807;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5808 = MAKE_SEQ(_1);
    _5807 = NOVALUE;
    DeRef(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    return _5808;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_6ch_10099 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_10369);
    _s_10369 = _5;

    /** 			get_ch()*/
    _6get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_10407 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_skip_blanks_1__tmp_at233_10407 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_6ch_10099 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _6get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _5811 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5811 +(unsigned long) HIGH_BITS) >= 0){
        _5811 = NewDouble((double)_5811);
    }
    if (IS_ATOM_INT(_5811)) {
        _5812 = _5811 - _offset_10372;
        if ((long)((unsigned long)_5812 +(unsigned long) HIGH_BITS) >= 0){
            _5812 = NewDouble((double)_5812);
        }
    }
    else {
        _5812 = NewDouble(DBL_PTR(_5811)->dbl - (double)_offset_10372);
    }
    DeRef(_5811);
    _5811 = NOVALUE;
    _5813 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5812)) {
        _5814 = _5812 - _5813;
        if ((long)((unsigned long)_5814 +(unsigned long) HIGH_BITS) >= 0){
            _5814 = NewDouble((double)_5814);
        }
    }
    else {
        _5814 = NewDouble(DBL_PTR(_5812)->dbl - (double)_5813);
    }
    DeRef(_5812);
    _5812 = NOVALUE;
    _5813 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10369);
    *((int *)(_2+8)) = _s_10369;
    *((int *)(_2+12)) = _5814;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5815 = MAKE_SEQ(_1);
    _5814 = NOVALUE;
    DeRefDS(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    return _5815;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_10370;
    _e_10370 = _6Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_10370);
    _e1_10371 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_10371))
    _e1_10371 = (long)DBL_PTR(_e1_10371)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_10371 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_10370);
    _5819 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_5819);
    Append(&_s_10369, _s_10369, _5819);
    _5819 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_10371 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5822 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5822 +(unsigned long) HIGH_BITS) >= 0){
        _5822 = NewDouble((double)_5822);
    }
    if (IS_ATOM_INT(_5822)) {
        _5823 = _5822 - _offset_10372;
        if ((long)((unsigned long)_5823 +(unsigned long) HIGH_BITS) >= 0){
            _5823 = NewDouble((double)_5823);
        }
    }
    else {
        _5823 = NewDouble(DBL_PTR(_5822)->dbl - (double)_offset_10372);
    }
    DeRef(_5822);
    _5822 = NOVALUE;
    _5824 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5823)) {
        _5825 = _5823 - _5824;
        if ((long)((unsigned long)_5825 +(unsigned long) HIGH_BITS) >= 0){
            _5825 = NewDouble((double)_5825);
        }
    }
    else {
        _5825 = NewDouble(DBL_PTR(_5823)->dbl - (double)_5824);
    }
    DeRef(_5823);
    _5823 = NOVALUE;
    _5824 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5825;
    ((int *)_2)[2] = _6leading_whitespace_10366;
    _5826 = MAKE_SEQ(_1);
    _5825 = NOVALUE;
    Concat((object_ptr)&_5827, _e_10370, _5826);
    DeRefDS(_5826);
    _5826 = NOVALUE;
    DeRef(_s_10369);
    DeRefDS(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    return _5827;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_6ch_10099 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _6get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _5829 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5829 +(unsigned long) HIGH_BITS) >= 0){
        _5829 = NewDouble((double)_5829);
    }
    if (IS_ATOM_INT(_5829)) {
        _5830 = _5829 - _offset_10372;
        if ((long)((unsigned long)_5830 +(unsigned long) HIGH_BITS) >= 0){
            _5830 = NewDouble((double)_5830);
        }
    }
    else {
        _5830 = NewDouble(DBL_PTR(_5829)->dbl - (double)_offset_10372);
    }
    DeRef(_5829);
    _5829 = NOVALUE;
    _5831 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5830)) {
        _5832 = _5830 - _5831;
        if ((long)((unsigned long)_5832 +(unsigned long) HIGH_BITS) >= 0){
            _5832 = NewDouble((double)_5832);
        }
    }
    else {
        _5832 = NewDouble(DBL_PTR(_5830)->dbl - (double)_5831);
    }
    DeRef(_5830);
    _5830 = NOVALUE;
    _5831 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10369);
    *((int *)(_2+8)) = _s_10369;
    *((int *)(_2+12)) = _5832;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5833 = MAKE_SEQ(_1);
    _5832 = NOVALUE;
    DeRefDS(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    return _5833;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_10440 = find_from(_6ch_10099, _6white_space_10115, 1);
    if (_skip_blanks_1__tmp_at464_10440 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _6get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_6ch_10099 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _6get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5835 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5835 +(unsigned long) HIGH_BITS) >= 0){
        _5835 = NewDouble((double)_5835);
    }
    if (IS_ATOM_INT(_5835)) {
        _5836 = _5835 - _offset_10372;
        if ((long)((unsigned long)_5836 +(unsigned long) HIGH_BITS) >= 0){
            _5836 = NewDouble((double)_5836);
        }
    }
    else {
        _5836 = NewDouble(DBL_PTR(_5835)->dbl - (double)_offset_10372);
    }
    DeRef(_5835);
    _5835 = NOVALUE;
    _5837 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5836)) {
        _5838 = _5836 - _5837;
        if ((long)((unsigned long)_5838 +(unsigned long) HIGH_BITS) >= 0){
            _5838 = NewDouble((double)_5838);
        }
    }
    else {
        _5838 = NewDouble(DBL_PTR(_5836)->dbl - (double)_5837);
    }
    DeRef(_5836);
    _5836 = NOVALUE;
    _5837 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_10369);
    *((int *)(_2+8)) = _s_10369;
    *((int *)(_2+12)) = _5838;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5839 = MAKE_SEQ(_1);
    _5838 = NOVALUE;
    DeRefDS(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    return _5839;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_6ch_10099 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_10370;
    _e_10370 = _6get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_10370);
    _5842 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _5842, -2)){
        _5842 = NOVALUE;
        goto L10; // [574] 463
    }
    _5842 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _5844 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5844 +(unsigned long) HIGH_BITS) >= 0){
        _5844 = NewDouble((double)_5844);
    }
    if (IS_ATOM_INT(_5844)) {
        _5845 = _5844 - _offset_10372;
        if ((long)((unsigned long)_5845 +(unsigned long) HIGH_BITS) >= 0){
            _5845 = NewDouble((double)_5845);
        }
    }
    else {
        _5845 = NewDouble(DBL_PTR(_5844)->dbl - (double)_offset_10372);
    }
    DeRef(_5844);
    _5844 = NOVALUE;
    _5846 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5845)) {
        _5847 = _5845 - _5846;
        if ((long)((unsigned long)_5847 +(unsigned long) HIGH_BITS) >= 0){
            _5847 = NewDouble((double)_5847);
        }
    }
    else {
        _5847 = NewDouble(DBL_PTR(_5845)->dbl - (double)_5846);
    }
    DeRef(_5845);
    _5845 = NOVALUE;
    _5846 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5847;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5848 = MAKE_SEQ(_1);
    _5847 = NOVALUE;
    DeRef(_s_10369);
    DeRefDS(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5839);
    _5839 = NOVALUE;
    return _5848;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_6ch_10099 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5850 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5850 +(unsigned long) HIGH_BITS) >= 0){
        _5850 = NewDouble((double)_5850);
    }
    if (IS_ATOM_INT(_5850)) {
        _5851 = _5850 - _offset_10372;
        if ((long)((unsigned long)_5851 +(unsigned long) HIGH_BITS) >= 0){
            _5851 = NewDouble((double)_5851);
        }
    }
    else {
        _5851 = NewDouble(DBL_PTR(_5850)->dbl - (double)_offset_10372);
    }
    DeRef(_5850);
    _5850 = NOVALUE;
    _5852 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5851)) {
        _5853 = _5851 - _5852;
        if ((long)((unsigned long)_5853 +(unsigned long) HIGH_BITS) >= 0){
            _5853 = NewDouble((double)_5853);
        }
    }
    else {
        _5853 = NewDouble(DBL_PTR(_5851)->dbl - (double)_5852);
    }
    DeRef(_5851);
    _5851 = NOVALUE;
    _5852 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5853;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5854 = MAKE_SEQ(_1);
    _5853 = NOVALUE;
    DeRef(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5839);
    _5839 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    return _5854;
L16: 

    /** 			get_ch() -- skip comma*/
    _6get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_6ch_10099 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_10370;
    _e_10370 = _6get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5857 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5857 +(unsigned long) HIGH_BITS) >= 0){
        _5857 = NewDouble((double)_5857);
    }
    if (IS_ATOM_INT(_5857)) {
        _5858 = _5857 - _offset_10372;
        if ((long)((unsigned long)_5858 +(unsigned long) HIGH_BITS) >= 0){
            _5858 = NewDouble((double)_5858);
        }
    }
    else {
        _5858 = NewDouble(DBL_PTR(_5857)->dbl - (double)_offset_10372);
    }
    DeRef(_5857);
    _5857 = NOVALUE;
    _5859 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5858)) {
        _5860 = _5858 - _5859;
        if ((long)((unsigned long)_5860 +(unsigned long) HIGH_BITS) >= 0){
            _5860 = NewDouble((double)_5860);
        }
    }
    else {
        _5860 = NewDouble(DBL_PTR(_5858)->dbl - (double)_5859);
    }
    DeRef(_5858);
    _5858 = NOVALUE;
    _5859 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5860;
    ((int *)_2)[2] = _6leading_whitespace_10366;
    _5861 = MAKE_SEQ(_1);
    _5860 = NOVALUE;
    Concat((object_ptr)&_5862, _e_10370, _5861);
    DeRefDS(_5861);
    _5861 = NOVALUE;
    DeRef(_s_10369);
    DeRefDS(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5839);
    _5839 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5854);
    _5854 = NOVALUE;
    return _5862;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_6ch_10099 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_10370;
    _e_10370 = _6get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5865 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5865 +(unsigned long) HIGH_BITS) >= 0){
        _5865 = NewDouble((double)_5865);
    }
    if (IS_ATOM_INT(_5865)) {
        _5866 = _5865 - _offset_10372;
        if ((long)((unsigned long)_5866 +(unsigned long) HIGH_BITS) >= 0){
            _5866 = NewDouble((double)_5866);
        }
    }
    else {
        _5866 = NewDouble(DBL_PTR(_5865)->dbl - (double)_offset_10372);
    }
    DeRef(_5865);
    _5865 = NOVALUE;
    _5867 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5866)) {
        _5868 = _5866 - _5867;
        if ((long)((unsigned long)_5868 +(unsigned long) HIGH_BITS) >= 0){
            _5868 = NewDouble((double)_5868);
        }
    }
    else {
        _5868 = NewDouble(DBL_PTR(_5866)->dbl - (double)_5867);
    }
    DeRef(_5866);
    _5866 = NOVALUE;
    _5867 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5868;
    ((int *)_2)[2] = _6leading_whitespace_10366;
    _5869 = MAKE_SEQ(_1);
    _5868 = NOVALUE;
    Concat((object_ptr)&_5870, _e_10370, _5869);
    DeRefDS(_5869);
    _5869 = NOVALUE;
    DeRef(_s_10369);
    DeRefDS(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5839);
    _5839 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5854);
    _5854 = NOVALUE;
    DeRef(_5862);
    _5862 = NOVALUE;
    return _5870;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _5871 = _6string_next_10098 - 1;
    if ((long)((unsigned long)_5871 +(unsigned long) HIGH_BITS) >= 0){
        _5871 = NewDouble((double)_5871);
    }
    if (IS_ATOM_INT(_5871)) {
        _5872 = _5871 - _offset_10372;
        if ((long)((unsigned long)_5872 +(unsigned long) HIGH_BITS) >= 0){
            _5872 = NewDouble((double)_5872);
        }
    }
    else {
        _5872 = NewDouble(DBL_PTR(_5871)->dbl - (double)_offset_10372);
    }
    DeRef(_5871);
    _5871 = NOVALUE;
    _5873 = (_6ch_10099 != -1);
    if (IS_ATOM_INT(_5872)) {
        _5874 = _5872 - _5873;
        if ((long)((unsigned long)_5874 +(unsigned long) HIGH_BITS) >= 0){
            _5874 = NewDouble((double)_5874);
        }
    }
    else {
        _5874 = NewDouble(DBL_PTR(_5872)->dbl - (double)_5873);
    }
    DeRef(_5872);
    _5872 = NOVALUE;
    _5873 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _5874;
    *((int *)(_2+16)) = _6leading_whitespace_10366;
    _5875 = MAKE_SEQ(_1);
    _5874 = NOVALUE;
    DeRef(_s_10369);
    DeRef(_e_10370);
    DeRef(_5790);
    _5790 = NOVALUE;
    DeRef(_5802);
    _5802 = NOVALUE;
    DeRef(_5808);
    _5808 = NOVALUE;
    DeRef(_5815);
    _5815 = NOVALUE;
    DeRef(_5827);
    _5827 = NOVALUE;
    DeRef(_5833);
    _5833 = NOVALUE;
    DeRef(_5839);
    _5839 = NOVALUE;
    DeRef(_5848);
    _5848 = NOVALUE;
    DeRef(_5854);
    _5854 = NOVALUE;
    DeRef(_5862);
    _5862 = NOVALUE;
    DeRef(_5870);
    _5870 = NOVALUE;
    return _5875;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}


int _6get_value(int _target_10499, int _start_point_10500, int _answer_type_10501)
{
    int _msg_inlined_crash_at_35_10512 = NOVALUE;
    int _data_inlined_crash_at_32_10511 = NOVALUE;
    int _where_inlined_where_at_76_10518 = NOVALUE;
    int _seek_1__tmp_at90_10523 = NOVALUE;
    int _seek_inlined_seek_at_90_10522 = NOVALUE;
    int _pos_inlined_seek_at_87_10521 = NOVALUE;
    int _msg_inlined_crash_at_108_10526 = NOVALUE;
    int _5891 = NOVALUE;
    int _5888 = NOVALUE;
    int _5887 = NOVALUE;
    int _5886 = NOVALUE;
    int _5882 = NOVALUE;
    int _5881 = NOVALUE;
    int _5880 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if answer_type != GET_SHORT_ANSWER and answer_type != GET_LONG_ANSWER then*/
    _5880 = (_answer_type_10501 != _6GET_SHORT_ANSWER_10491);
    if (_5880 == 0) {
        goto L1; // [13] 55
    }
    _5882 = (_answer_type_10501 != _6GET_LONG_ANSWER_10494);
    if (_5882 == 0)
    {
        DeRef(_5882);
        _5882 = NOVALUE;
        goto L1; // [24] 55
    }
    else{
        DeRef(_5882);
        _5882 = NOVALUE;
    }

    /** 		error:crash("Invalid type of answer, please only use %s (the default) or %s.", {"GET_SHORT_ANSWER", "GET_LONG_ANSWER"})*/
    RefDS(_5885);
    RefDS(_5884);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5884;
    ((int *)_2)[2] = _5885;
    _5886 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_32_10511);
    _data_inlined_crash_at_32_10511 = _5886;
    _5886 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_35_10512);
    _msg_inlined_crash_at_35_10512 = EPrintf(-9999999, _5883, _data_inlined_crash_at_32_10511);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_35_10512);

    /** end procedure*/
    goto L2; // [49] 52
L2: 
    DeRef(_data_inlined_crash_at_32_10511);
    _data_inlined_crash_at_32_10511 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_35_10512);
    _msg_inlined_crash_at_35_10512 = NOVALUE;
L1: 

    /** 	if atom(target) then -- get()*/
    _5887 = IS_ATOM(_target_10499);
    if (_5887 == 0)
    {
        _5887 = NOVALUE;
        goto L3; // [60] 142
    }
    else{
        _5887 = NOVALUE;
    }

    /** 		input_file = target*/
    Ref(_target_10499);
    _6input_file_10096 = _target_10499;
    if (!IS_ATOM_INT(_6input_file_10096)) {
        _1 = (long)(DBL_PTR(_6input_file_10096)->dbl);
        DeRefDS(_6input_file_10096);
        _6input_file_10096 = _1;
    }

    /** 		if start_point then*/
    if (_start_point_10500 == 0)
    {
        goto L4; // [72] 129
    }
    else{
    }

    /** 			if io:seek(target, io:where(target)+start_point) then*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_76_10518);
    _where_inlined_where_at_76_10518 = machine(20, _target_10499);
    if (IS_ATOM_INT(_where_inlined_where_at_76_10518)) {
        _5888 = _where_inlined_where_at_76_10518 + _start_point_10500;
        if ((long)((unsigned long)_5888 + (unsigned long)HIGH_BITS) >= 0) 
        _5888 = NewDouble((double)_5888);
    }
    else {
        _5888 = NewDouble(DBL_PTR(_where_inlined_where_at_76_10518)->dbl + (double)_start_point_10500);
    }
    DeRef(_pos_inlined_seek_at_87_10521);
    _pos_inlined_seek_at_87_10521 = _5888;
    _5888 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_87_10521);
    Ref(_target_10499);
    DeRef(_seek_1__tmp_at90_10523);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _target_10499;
    ((int *)_2)[2] = _pos_inlined_seek_at_87_10521;
    _seek_1__tmp_at90_10523 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_90_10522 = machine(19, _seek_1__tmp_at90_10523);
    DeRef(_pos_inlined_seek_at_87_10521);
    _pos_inlined_seek_at_87_10521 = NOVALUE;
    DeRef(_seek_1__tmp_at90_10523);
    _seek_1__tmp_at90_10523 = NOVALUE;
    if (_seek_inlined_seek_at_90_10522 == 0)
    {
        goto L5; // [104] 128
    }
    else{
    }

    /** 				error:crash("Initial seek() for get() failed!")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_108_10526);
    _msg_inlined_crash_at_108_10526 = EPrintf(-9999999, _5889, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_108_10526);

    /** end procedure*/
    goto L6; // [122] 125
L6: 
    DeRefi(_msg_inlined_crash_at_108_10526);
    _msg_inlined_crash_at_108_10526 = NOVALUE;
L5: 
L4: 

    /** 		string_next = 1*/
    _6string_next_10098 = 1;

    /** 		input_string = 0*/
    DeRef(_6input_string_10097);
    _6input_string_10097 = 0;
    goto L7; // [139] 153
L3: 

    /** 		input_string = target*/
    Ref(_target_10499);
    DeRef(_6input_string_10097);
    _6input_string_10097 = _target_10499;

    /** 		string_next = start_point*/
    _6string_next_10098 = _start_point_10500;
L7: 

    /** 	if answer_type = GET_SHORT_ANSWER then*/
    if (_answer_type_10501 != _6GET_SHORT_ANSWER_10491)
    goto L8; // [157] 166

    /** 		get_ch()*/
    _6get_ch();
L8: 

    /** 	return call_func(answer_type, {})*/
    _0 = (int)_00[_answer_type_10501].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_5891);
    _5891 = _1;
    DeRef(_target_10499);
    DeRef(_5880);
    _5880 = NOVALUE;
    return _5891;
    ;
}


int _6value(int _st_10539, int _start_point_10540, int _answer_10541)
{
    int _5893 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return get_value(st, start_point, answer)*/
    RefDS(_st_10539);
    _5893 = _6get_value(_st_10539, 1, _answer_10541);
    DeRefDS(_st_10539);
    return _5893;
    ;
}



// 0xBE099FA4
