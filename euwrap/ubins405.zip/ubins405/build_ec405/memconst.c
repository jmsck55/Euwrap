// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _10valid_memory_protection_constant(int _x_299)
{
    int _46 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _46 = find_from(_x_299, _10MEMORY_PROTECTION_295, 1);
    DeRef(_x_299);
    return _46;
    ;
}


int _10test_read(int _protection_303)
{
    int _48 = NOVALUE;
    int _47 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_READ,protection) != 0*/
    if (IS_ATOM_INT(_protection_303)) {
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_protection_303;
             _47 = MAKE_UINT(tu);
        }
    }
    else {
        _47 = binary_op(AND_BITS, 1, _protection_303);
    }
    if (IS_ATOM_INT(_47)) {
        _48 = (_47 != 0);
    }
    else {
        _48 = binary_op(NOTEQ, _47, 0);
    }
    DeRef(_47);
    _47 = NOVALUE;
    DeRef(_protection_303);
    return _48;
    ;
}


int _10test_write(int _protection_308)
{
    int _50 = NOVALUE;
    int _49 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_WRITE,protection) != 0*/
    if (IS_ATOM_INT(_protection_308)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_protection_308;
             _49 = MAKE_UINT(tu);
        }
    }
    else {
        _49 = binary_op(AND_BITS, 2, _protection_308);
    }
    if (IS_ATOM_INT(_49)) {
        _50 = (_49 != 0);
    }
    else {
        _50 = binary_op(NOTEQ, _49, 0);
    }
    DeRef(_49);
    _49 = NOVALUE;
    DeRef(_protection_308);
    return _50;
    ;
}


int _10test_exec(int _protection_313)
{
    int _52 = NOVALUE;
    int _51 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_EXEC,protection) != 0*/
    if (IS_ATOM_INT(_protection_313)) {
        {unsigned long tu;
             tu = (unsigned long)4 & (unsigned long)_protection_313;
             _51 = MAKE_UINT(tu);
        }
    }
    else {
        _51 = binary_op(AND_BITS, 4, _protection_313);
    }
    if (IS_ATOM_INT(_51)) {
        _52 = (_51 != 0);
    }
    else {
        _52 = binary_op(NOTEQ, _51, 0);
    }
    DeRef(_51);
    _51 = NOVALUE;
    DeRef(_protection_313);
    return _52;
    ;
}


int _10valid_wordsize(int _i_318)
{
    int _54 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _54 = find_from(_i_318, _53, 1);
    DeRef(_i_318);
    return _54;
    ;
}



// 0x0630E3F7
