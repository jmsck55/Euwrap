// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _63find_category(int _tokid_23303)
{
    int _catname_23304 = NOVALUE;
    int _13450 = NOVALUE;
    int _13449 = NOVALUE;
    int _13447 = NOVALUE;
    int _13446 = NOVALUE;
    int _13445 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23303)) {
        _1 = (long)(DBL_PTR(_tokid_23303)->dbl);
        DeRefDS(_tokid_23303);
        _tokid_23303 = _1;
    }

    /** 	sequence catname = "reserved word"*/
    RefDS(_13444);
    DeRef(_catname_23304);
    _catname_23304 = _13444;

    /** 	for i = 1 to length(token_category) do*/
    _13445 = 73;
    {
        int _i_23307;
        _i_23307 = 1;
L1: 
        if (_i_23307 > 73){
            goto L2; // [17] 72
        }

        /** 		if token_category[i][1] = tokid then*/
        _2 = (int)SEQ_PTR(_37token_category_15521);
        _13446 = (int)*(((s1_ptr)_2)->base + _i_23307);
        _2 = (int)SEQ_PTR(_13446);
        _13447 = (int)*(((s1_ptr)_2)->base + 1);
        _13446 = NOVALUE;
        if (binary_op_a(NOTEQ, _13447, _tokid_23303)){
            _13447 = NOVALUE;
            goto L3; // [36] 65
        }
        _13447 = NOVALUE;

        /** 			catname = token_catname[token_category[i][2]]*/
        _2 = (int)SEQ_PTR(_37token_category_15521);
        _13449 = (int)*(((s1_ptr)_2)->base + _i_23307);
        _2 = (int)SEQ_PTR(_13449);
        _13450 = (int)*(((s1_ptr)_2)->base + 2);
        _13449 = NOVALUE;
        DeRef(_catname_23304);
        _2 = (int)SEQ_PTR(_37token_catname_15508);
        if (!IS_ATOM_INT(_13450)){
            _catname_23304 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13450)->dbl));
        }
        else{
            _catname_23304 = (int)*(((s1_ptr)_2)->base + _13450);
        }
        RefDS(_catname_23304);

        /** 			exit*/
        goto L2; // [62] 72
L3: 

        /** 	end for*/
        _i_23307 = _i_23307 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** 	return catname*/
    _13450 = NOVALUE;
    return _catname_23304;
    ;
}


int _63find_token_text(int _tokid_23322)
{
    int _13459 = NOVALUE;
    int _13457 = NOVALUE;
    int _13456 = NOVALUE;
    int _13454 = NOVALUE;
    int _13453 = NOVALUE;
    int _13452 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23322)) {
        _1 = (long)(DBL_PTR(_tokid_23322)->dbl);
        DeRefDS(_tokid_23322);
        _tokid_23322 = _1;
    }

    /** 	for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22479)){
            _13452 = SEQ_PTR(_63keylist_22479)->length;
    }
    else {
        _13452 = 1;
    }
    {
        int _i_23324;
        _i_23324 = 1;
L1: 
        if (_i_23324 > _13452){
            goto L2; // [10] 57
        }

        /** 		if keylist[i][3] = tokid then*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _13453 = (int)*(((s1_ptr)_2)->base + _i_23324);
        _2 = (int)SEQ_PTR(_13453);
        _13454 = (int)*(((s1_ptr)_2)->base + 3);
        _13453 = NOVALUE;
        if (binary_op_a(NOTEQ, _13454, _tokid_23322)){
            _13454 = NOVALUE;
            goto L3; // [29] 50
        }
        _13454 = NOVALUE;

        /** 			return keylist[i][1]*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _13456 = (int)*(((s1_ptr)_2)->base + _i_23324);
        _2 = (int)SEQ_PTR(_13456);
        _13457 = (int)*(((s1_ptr)_2)->base + 1);
        _13456 = NOVALUE;
        Ref(_13457);
        return _13457;
L3: 

        /** 	end for*/
        _i_23324 = _i_23324 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	return LexName(tokid, "unknown word")*/
    RefDS(_13458);
    _13459 = _41LexName(_tokid_23322, _13458);
    _13457 = NOVALUE;
    return _13459;
    ;
}



// 0xE6285E7D
