// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _9allocate(int _n_983, int _cleanup_984)
{
    int _iaddr_985 = NOVALUE;
    int _eaddr_986 = NOVALUE;
    int _373 = NOVALUE;
    int _372 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _372 = 0;
    _373 = _n_983 + 0;
    _372 = NOVALUE;
    DeRef(_iaddr_985);
    _iaddr_985 = machine(16, _373);
    _373 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_985);
    Ref(_10PAGE_READ_WRITE_290);
    _0 = _eaddr_986;
    _eaddr_986 = _11prepare_block(_iaddr_985, _n_983, _10PAGE_READ_WRITE_290);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 	return eaddr*/
    DeRef(_iaddr_985);
    return _eaddr_986;
    ;
}


int _9allocate_string(int _s_1124, int _cleanup_1125)
{
    int _mem_1126 = NOVALUE;
    int _439 = NOVALUE;
    int _438 = NOVALUE;
    int _436 = NOVALUE;
    int _435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1124)){
            _435 = SEQ_PTR(_s_1124)->length;
    }
    else {
        _435 = 1;
    }
    _436 = _435 + 1;
    _435 = NOVALUE;
    _0 = _mem_1126;
    _mem_1126 = _9allocate(_436, 0);
    DeRef(_0);
    _436 = NOVALUE;

    /** 	if mem then*/
    if (_mem_1126 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1126) && DBL_PTR(_mem_1126)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1126)){
        poke_addr = (unsigned char *)_mem_1126;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_1126)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_1124);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1124)){
            _438 = SEQ_PTR(_s_1124)->length;
    }
    else {
        _438 = 1;
    }
    if (IS_ATOM_INT(_mem_1126)) {
        _439 = _mem_1126 + _438;
        if ((long)((unsigned long)_439 + (unsigned long)HIGH_BITS) >= 0) 
        _439 = NewDouble((double)_439);
    }
    else {
        _439 = NewDouble(DBL_PTR(_mem_1126)->dbl + (double)_438);
    }
    _438 = NOVALUE;
    if (IS_ATOM_INT(_439)){
        poke_addr = (unsigned char *)_439;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_439)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_439);
    _439 = NOVALUE;

    /** 		if cleanup then*/
L1: 

    /** 	return mem*/
    DeRefDS(_s_1124);
    return _mem_1126;
    ;
}


void _9free(int _addr_1204)
{
    int _msg_inlined_crash_at_27_1213 = NOVALUE;
    int _data_inlined_crash_at_24_1212 = NOVALUE;
    int _addr_inlined_deallocate_at_64_1219 = NOVALUE;
    int _msg_inlined_crash_at_106_1224 = NOVALUE;
    int _470 = NOVALUE;
    int _469 = NOVALUE;
    int _468 = NOVALUE;
    int _467 = NOVALUE;
    int _465 = NOVALUE;
    int _464 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_1204);
    _464 = _13number_array(_addr_1204);
    if (_464 == 0) {
        DeRef(_464);
        _464 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_464) && DBL_PTR(_464)->dbl == 0.0){
            DeRef(_464);
            _464 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_464);
        _464 = NOVALUE;
    }
    DeRef(_464);
    _464 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_1204);
    _465 = _13ascii_string(_addr_1204);
    if (_465 == 0) {
        DeRef(_465);
        _465 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_465) && DBL_PTR(_465)->dbl == 0.0){
            DeRef(_465);
            _465 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_465);
        _465 = NOVALUE;
    }
    DeRef(_465);
    _465 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_1204);
    *((int *)(_2+4)) = _addr_1204;
    _467 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1212);
    _data_inlined_crash_at_24_1212 = _467;
    _467 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1213);
    _msg_inlined_crash_at_27_1213 = EPrintf(-9999999, _466, _data_inlined_crash_at_24_1212);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1213);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1212);
    _data_inlined_crash_at_24_1212 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1213);
    _msg_inlined_crash_at_27_1213 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1204)){
            _468 = SEQ_PTR(_addr_1204)->length;
    }
    else {
        _468 = 1;
    }
    {
        int _i_1215;
        _i_1215 = 1;
L4: 
        if (_i_1215 > _468){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_1204);
        _469 = (int)*(((s1_ptr)_2)->base + _i_1215);
        Ref(_469);
        DeRef(_addr_inlined_deallocate_at_64_1219);
        _addr_inlined_deallocate_at_64_1219 = _469;
        _469 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1219);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1219);
        _addr_inlined_deallocate_at_64_1219 = NOVALUE;

        /** 		end for*/
        _i_1215 = _i_1215 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_1204);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _470 = IS_SEQUENCE(_addr_1204);
    if (_470 == 0)
    {
        _470 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _470 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1224);
    _msg_inlined_crash_at_106_1224 = EPrintf(-9999999, _471, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1224);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1224);
    _msg_inlined_crash_at_106_1224 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1204, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_1204);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1204);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_1204);
    return;
    ;
}


void _9free_pointer_array(int _pointers_array_1232)
{
    int _saved_1233 = NOVALUE;
    int _ptr_1234 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_1232);
    DeRef(_saved_1233);
    _saved_1233 = _pointers_array_1232;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_1234 <= 0) {
        if (_ptr_1234 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_1234) && DBL_PTR(_ptr_1234)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1234);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1232;
    if (IS_ATOM_INT(_pointers_array_1232)) {
        _pointers_array_1232 = _pointers_array_1232 + 4;
        if ((long)((unsigned long)_pointers_array_1232 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_1232 = NewDouble((double)_pointers_array_1232);
    }
    else {
        _pointers_array_1232 = NewDouble(DBL_PTR(_pointers_array_1232)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_1234);
    if (IS_ATOM_INT(_pointers_array_1232)) {
        _ptr_1234 = *(unsigned long *)_pointers_array_1232;
        if ((unsigned)_ptr_1234 > (unsigned)MAXINT)
        _ptr_1234 = NewDouble((double)(unsigned long)_ptr_1234);
    }
    else {
        _ptr_1234 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_1232)->dbl);
        if ((unsigned)_ptr_1234 > (unsigned)MAXINT)
        _ptr_1234 = NewDouble((double)(unsigned long)_ptr_1234);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_1233);
    _9free(_saved_1233);

    /** end procedure*/
    DeRef(_pointers_array_1232);
    DeRef(_saved_1233);
    DeRef(_ptr_1234);
    return;
    ;
}



// 0x80BE40FE
