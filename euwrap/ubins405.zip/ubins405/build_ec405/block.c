// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _66block_type_name(int _opcode_45291)
{
    int _23931 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45291)) {
        _1 = (long)(DBL_PTR(_opcode_45291)->dbl);
        DeRefDS(_opcode_45291);
        _opcode_45291 = _1;
    }

    /** 	switch opcode do*/
    _0 = _opcode_45291;
    switch ( _0 ){ 

        /** 		case LOOP then*/
        case 422:

        /** 			return "LOOP"*/
        RefDS(_23929);
        return _23929;
        goto L1; // [20] 63

        /** 		case PROC then*/
        case 27:

        /** 			return "PROC"*/
        RefDS(_21573);
        return _21573;
        goto L1; // [32] 63

        /** 		case FUNC then*/
        case 501:

        /** 			return "FUNC"*/
        RefDS(_23930);
        return _23930;
        goto L1; // [44] 63

        /** 		case else*/
        default:

        /** 			return opnames[opcode]*/
        _2 = (int)SEQ_PTR(_60opnames_21845);
        _23931 = (int)*(((s1_ptr)_2)->base + _opcode_45291);
        RefDS(_23931);
        return _23931;
    ;}L1: 
    ;
}


void _66check_block(int _got_45307)
{
    int _expected_45308 = NOVALUE;
    int _23939 = NOVALUE;
    int _23938 = NOVALUE;
    int _23937 = NOVALUE;
    int _23933 = NOVALUE;
    int _23932 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer expected = block_stack[$][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _23932 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _23932 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _23933 = (int)*(((s1_ptr)_2)->base + _23932);
    _2 = (int)SEQ_PTR(_23933);
    _expected_45308 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_expected_45308)){
        _expected_45308 = (long)DBL_PTR(_expected_45308)->dbl;
    }
    _23933 = NOVALUE;

    /** 	if got = FUNC then*/
    if (_got_45307 != 501)
    goto L1; // [24] 38

    /** 		got = PROC*/
    _got_45307 = 27;
L1: 

    /** 	if got != expected then*/
    if (_got_45307 == _expected_45308)
    goto L2; // [40] 64

    /** 		CompileErr( 79, {block_type_name( expected ), block_type_name( got)} )*/
    _23937 = _66block_type_name(_expected_45308);
    _23938 = _66block_type_name(_got_45307);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23937;
    ((int *)_2)[2] = _23938;
    _23939 = MAKE_SEQ(_1);
    _23938 = NOVALUE;
    _23937 = NOVALUE;
    _44CompileErr(79, _23939, 0);
    _23939 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


void _66Block_var(int _sym_45325)
{
    int _block_45326 = NOVALUE;
    int _23960 = NOVALUE;
    int _23959 = NOVALUE;
    int _23958 = NOVALUE;
    int _23956 = NOVALUE;
    int _23955 = NOVALUE;
    int _23953 = NOVALUE;
    int _23952 = NOVALUE;
    int _23951 = NOVALUE;
    int _23950 = NOVALUE;
    int _23949 = NOVALUE;
    int _23948 = NOVALUE;
    int _23947 = NOVALUE;
    int _23945 = NOVALUE;
    int _23943 = NOVALUE;
    int _23942 = NOVALUE;
    int _23940 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45325)) {
        _1 = (long)(DBL_PTR(_sym_45325)->dbl);
        DeRefDS(_sym_45325);
        _sym_45325 = _1;
    }

    /** 	sequence block = block_stack[$]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _23940 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _23940 = 1;
    }
    DeRef(_block_45326);
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _block_45326 = (int)*(((s1_ptr)_2)->base + _23940);
    Ref(_block_45326);

    /** 	block_stack[$] = 0*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _23942 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _23942 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _2 = (int)(((s1_ptr)_2)->base + _23942);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if length(block_stack) > 1 then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _23943 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _23943 = 1;
    }
    if (_23943 <= 1)
    goto L1; // [34] 58

    /** 		SymTab[sym][S_BLOCK] = block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45325 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_block_45326);
    _23947 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_23947);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15661))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15661)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15661);
    _1 = *(int *)_2;
    *(int *)_2 = _23947;
    if( _1 != _23947 ){
        DeRef(_1);
    }
    _23947 = NOVALUE;
    _23945 = NOVALUE;
L1: 

    /** 	if length(block[BLOCK_VARS]) then*/
    _2 = (int)SEQ_PTR(_block_45326);
    _23948 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23948)){
            _23949 = SEQ_PTR(_23948)->length;
    }
    else {
        _23949 = 1;
    }
    _23948 = NOVALUE;
    if (_23949 == 0)
    {
        _23949 = NOVALUE;
        goto L2; // [67] 99
    }
    else{
        _23949 = NOVALUE;
    }

    /** 		SymTab[block[BLOCK_VARS][$]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45326);
    _23950 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23950)){
            _23951 = SEQ_PTR(_23950)->length;
    }
    else {
        _23951 = 1;
    }
    _2 = (int)SEQ_PTR(_23950);
    _23952 = (int)*(((s1_ptr)_2)->base + _23951);
    _23950 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23952))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23952)->dbl));
    else
    _3 = (int)(_23952 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15633))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15633)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15633);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45325;
    DeRef(_1);
    _23953 = NOVALUE;
    goto L3; // [96] 119
L2: 

    /** 		SymTab[block[BLOCK_SYM]][S_NEXT_IN_BLOCK] = sym*/
    _2 = (int)SEQ_PTR(_block_45326);
    _23955 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23955))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23955)->dbl));
    else
    _3 = (int)(_23955 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15633))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15633)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15633);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_45325;
    DeRef(_1);
    _23956 = NOVALUE;
L3: 

    /** 	block[BLOCK_VARS] &= sym*/
    _2 = (int)SEQ_PTR(_block_45326);
    _23958 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_23958) && IS_ATOM(_sym_45325)) {
        Append(&_23959, _23958, _sym_45325);
    }
    else if (IS_ATOM(_23958) && IS_SEQUENCE(_sym_45325)) {
    }
    else {
        Concat((object_ptr)&_23959, _23958, _sym_45325);
        _23958 = NOVALUE;
    }
    _23958 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45326 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _23959;
    if( _1 != _23959 ){
        DeRef(_1);
    }
    _23959 = NOVALUE;

    /** 	block_stack[$] = block*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _23960 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _23960 = 1;
    }
    RefDS(_block_45326);
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _2 = (int)(((s1_ptr)_2)->base + _23960);
    _1 = *(int *)_2;
    *(int *)_2 = _block_45326;
    DeRef(_1);

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRefDS(_block_45326);
    _23948 = NOVALUE;
    _23952 = NOVALUE;
    _23955 = NOVALUE;
    return;
    ;
}


void _66NewBlock(int _opcode_45360, int _block_label_45361)
{
    int _block_45379 = NOVALUE;
    int _23974 = NOVALUE;
    int _23973 = NOVALUE;
    int _23972 = NOVALUE;
    int _23970 = NOVALUE;
    int _23968 = NOVALUE;
    int _23967 = NOVALUE;
    int _23965 = NOVALUE;
    int _23964 = NOVALUE;
    int _23962 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab = append( SymTab, repeat( 0, SIZEOF_BLOCK_ENTRY ) )*/
    _23962 = Repeat(0, _35SIZEOF_BLOCK_ENTRY_15773);
    RefDS(_23962);
    Append(&_36SymTab_14981, _36SymTab_14981, _23962);
    DeRefDS(_23962);
    _23962 = NOVALUE;

    /** 	SymTab[$][S_MODE] = M_BLOCK*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _23964 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _23964 = 1;
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_23964 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _23965 = NOVALUE;

    /** 	SymTab[$][S_FIRST_LINE] = gline_number*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _23967 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _23967 = 1;
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_23967 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRST_LINE_15666))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRST_LINE_15666)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRST_LINE_15666);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_15973;
    DeRef(_1);
    _23968 = NOVALUE;

    /** 	sequence block = repeat( 0, BLOCK_SIZE-1 )*/
    _23970 = 6;
    DeRef(_block_45379);
    _block_45379 = Repeat(0, 6);
    _23970 = NOVALUE;

    /** 	block[BLOCK_SYM]    = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _23972 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _23972 = 1;
    }
    _2 = (int)SEQ_PTR(_block_45379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45379 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    *(int *)_2 = _23972;
    if( _1 != _23972 ){
    }
    _23972 = NOVALUE;

    /** 	block[BLOCK_OPCODE] = opcode*/
    _2 = (int)SEQ_PTR(_block_45379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45379 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    *(int *)_2 = _opcode_45360;

    /** 	block[BLOCK_LABEL]  = block_label*/
    Ref(_block_label_45361);
    _2 = (int)SEQ_PTR(_block_45379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45379 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    *(int *)_2 = _block_label_45361;

    /** 	block[BLOCK_START]  = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _23973 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _23973 = 1;
    }
    _23974 = _23973 + 1;
    _23973 = NOVALUE;
    _2 = (int)SEQ_PTR(_block_45379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45379 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _23974;
    if( _1 != _23974 ){
        DeRef(_1);
    }
    _23974 = NOVALUE;

    /** 	block[BLOCK_VARS]   = {}*/
    RefDS(_21815);
    _2 = (int)SEQ_PTR(_block_45379);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _block_45379 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);

    /** 	block_stack = append( block_stack, block )*/
    RefDS(_block_45379);
    Append(&_66block_stack_45281, _66block_stack_45281, _block_45379);

    /** 	current_block = length(SymTab)*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _66current_block_45288 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _66current_block_45288 = 1;
    }

    /** end procedure*/
    DeRef(_block_label_45361);
    DeRefDS(_block_45379);
    return;
    ;
}


void _66Start_block(int _opcode_45392, int _block_label_45393)
{
    int _last_block_45395 = NOVALUE;
    int _label_name_45423 = NOVALUE;
    int _23996 = NOVALUE;
    int _23995 = NOVALUE;
    int _23994 = NOVALUE;
    int _23991 = NOVALUE;
    int _23990 = NOVALUE;
    int _23988 = NOVALUE;
    int _23987 = NOVALUE;
    int _23986 = NOVALUE;
    int _23985 = NOVALUE;
    int _23984 = NOVALUE;
    int _23981 = NOVALUE;
    int _23979 = NOVALUE;
    int _23978 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_opcode_45392)) {
        _1 = (long)(DBL_PTR(_opcode_45392)->dbl);
        DeRefDS(_opcode_45392);
        _opcode_45392 = _1;
    }

    /** 	symtab_index last_block = current_block*/
    _last_block_45395 = _66current_block_45288;

    /** 	if opcode = FUNC then*/
    if (_opcode_45392 != 501)
    goto L1; // [16] 30

    /** 		opcode = PROC*/
    _opcode_45392 = 27;
L1: 

    /** 	NewBlock( opcode, block_label )*/
    Ref(_block_label_45393);
    _66NewBlock(_opcode_45392, _block_label_45393);

    /** 	if find(opcode, RTN_TOKS) then*/
    _23978 = find_from(_opcode_45392, _37RTN_TOKS_15594, 1);
    if (_23978 == 0)
    {
        _23978 = NOVALUE;
        goto L2; // [45] 105
    }
    else{
        _23978 = NOVALUE;
    }

    /** 		SymTab[block_label][S_BLOCK] = current_block*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_block_label_45393))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45393)->dbl));
    else
    _3 = (int)(_block_label_45393 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15661))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15661)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15661);
    _1 = *(int *)_2;
    *(int *)_2 = _66current_block_45288;
    DeRef(_1);
    _23979 = NOVALUE;

    /** 		SymTab[current_block][S_NAME] = sprintf("BLOCK: %s", {SymTab[block_label][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45288 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_block_label_45393)){
        _23984 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_block_label_45393)->dbl));
    }
    else{
        _23984 = (int)*(((s1_ptr)_2)->base + _block_label_45393);
    }
    _2 = (int)SEQ_PTR(_23984);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _23985 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _23985 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _23984 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_23985);
    *((int *)(_2+4)) = _23985;
    _23986 = MAKE_SEQ(_1);
    _23985 = NOVALUE;
    _23987 = EPrintf(-9999999, _23983, _23986);
    DeRefDS(_23986);
    _23986 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15641))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15641);
    _1 = *(int *)_2;
    *(int *)_2 = _23987;
    if( _1 != _23987 ){
        DeRef(_1);
    }
    _23987 = NOVALUE;
    _23981 = NOVALUE;
    goto L3; // [102] 185
L2: 

    /** 	elsif current_block then*/
    if (_66current_block_45288 == 0)
    {
        goto L4; // [109] 182
    }
    else{
    }

    /** 		SymTab[current_block][S_BLOCK] = last_block*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45288 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_BLOCK_15661))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_BLOCK_15661)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_BLOCK_15661);
    _1 = *(int *)_2;
    *(int *)_2 = _last_block_45395;
    DeRef(_1);
    _23988 = NOVALUE;

    /** 		sequence label_name = ""*/
    RefDS(_21815);
    DeRef(_label_name_45423);
    _label_name_45423 = _21815;

    /** 		if sequence(block_label) then*/
    _23990 = IS_SEQUENCE(_block_label_45393);
    if (_23990 == 0)
    {
        _23990 = NOVALUE;
        goto L5; // [141] 152
    }
    else{
        _23990 = NOVALUE;
    }

    /** 			label_name = block_label*/
    Ref(_block_label_45393);
    DeRefDS(_label_name_45423);
    _label_name_45423 = _block_label_45393;
L5: 

    /** 		SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", {block_type_name(opcode), label_name})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45288 + ((s1_ptr)_2)->base);
    _23994 = _66block_type_name(_opcode_45392);
    RefDS(_label_name_45423);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _23994;
    ((int *)_2)[2] = _label_name_45423;
    _23995 = MAKE_SEQ(_1);
    _23994 = NOVALUE;
    _23996 = EPrintf(-9999999, _23993, _23995);
    DeRefDS(_23995);
    _23995 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15641))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15641);
    _1 = *(int *)_2;
    *(int *)_2 = _23996;
    if( _1 != _23996 ){
        DeRef(_1);
    }
    _23996 = NOVALUE;
    _23991 = NOVALUE;
L4: 
    DeRef(_label_name_45423);
    _label_name_45423 = NOVALUE;
L3: 

    /** 	ifdef BDEBUG then*/

    /** end procedure*/
    DeRef(_block_label_45393);
    return;
    ;
}


void _66block_label(int _label_name_45439)
{
    int _24010 = NOVALUE;
    int _24009 = NOVALUE;
    int _24008 = NOVALUE;
    int _24007 = NOVALUE;
    int _24006 = NOVALUE;
    int _24005 = NOVALUE;
    int _24003 = NOVALUE;
    int _24001 = NOVALUE;
    int _24000 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	block_stack[$][BLOCK_LABEL] = label_name*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24000 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24000 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66block_stack_45281 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24000 + ((s1_ptr)_2)->base);
    RefDS(_label_name_45439);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _label_name_45439;
    DeRef(_1);
    _24001 = NOVALUE;

    /** 	SymTab[current_block][S_NAME] = sprintf( "BLOCK: %s-%s", */
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_66current_block_45288 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24005 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24005 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24006 = (int)*(((s1_ptr)_2)->base + _24005);
    _2 = (int)SEQ_PTR(_24006);
    _24007 = (int)*(((s1_ptr)_2)->base + 2);
    _24006 = NOVALUE;
    Ref(_24007);
    _24008 = _66block_type_name(_24007);
    _24007 = NOVALUE;
    RefDS(_label_name_45439);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24008;
    ((int *)_2)[2] = _label_name_45439;
    _24009 = MAKE_SEQ(_1);
    _24008 = NOVALUE;
    _24010 = EPrintf(-9999999, _23993, _24009);
    DeRefDS(_24009);
    _24009 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NAME_15641))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NAME_15641);
    _1 = *(int *)_2;
    *(int *)_2 = _24010;
    if( _1 != _24010 ){
        DeRef(_1);
    }
    _24010 = NOVALUE;
    _24003 = NOVALUE;

    /** end procedure*/
    DeRefDS(_label_name_45439);
    return;
    ;
}


int _66pop_block()
{
    int _block_45458 = NOVALUE;
    int _block_vars_45471 = NOVALUE;
    int _24039 = NOVALUE;
    int _24037 = NOVALUE;
    int _24036 = NOVALUE;
    int _24035 = NOVALUE;
    int _24034 = NOVALUE;
    int _24032 = NOVALUE;
    int _24031 = NOVALUE;
    int _24030 = NOVALUE;
    int _24029 = NOVALUE;
    int _24028 = NOVALUE;
    int _24027 = NOVALUE;
    int _24026 = NOVALUE;
    int _24025 = NOVALUE;
    int _24024 = NOVALUE;
    int _24023 = NOVALUE;
    int _24019 = NOVALUE;
    int _24018 = NOVALUE;
    int _24016 = NOVALUE;
    int _24015 = NOVALUE;
    int _24013 = NOVALUE;
    int _24011 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not length(block_stack) then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24011 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24011 = 1;
    }
    if (_24011 != 0)
    goto L1; // [8] 18
    _24011 = NOVALUE;

    /** 		return 0*/
    DeRef(_block_45458);
    DeRef(_block_vars_45471);
    return 0;
L1: 

    /** 	sequence  block = block_stack[$]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24013 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24013 = 1;
    }
    DeRef(_block_45458);
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _block_45458 = (int)*(((s1_ptr)_2)->base + _24013);
    Ref(_block_45458);

    /** 	block_stack = block_stack[1..$-1]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24015 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24015 = 1;
    }
    _24016 = _24015 - 1;
    _24015 = NOVALUE;
    rhs_slice_target = (object_ptr)&_66block_stack_45281;
    RHS_Slice(_66block_stack_45281, 1, _24016);

    /** 	SymTab[block[BLOCK_SYM]][S_LAST_LINE] = gline_number*/
    _2 = (int)SEQ_PTR(_block_45458);
    _24018 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24018))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24018)->dbl));
    else
    _3 = (int)(_24018 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LAST_LINE_15671))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LAST_LINE_15671)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LAST_LINE_15671);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_15973;
    DeRef(_1);
    _24019 = NOVALUE;

    /** 	ifdef BDEBUG then*/

    /** 	sequence block_vars = block[BLOCK_VARS]*/
    DeRef(_block_vars_45471);
    _2 = (int)SEQ_PTR(_block_45458);
    _block_vars_45471 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_block_vars_45471);

    /** 	for sx = 1 to length( block_vars ) do*/
    if (IS_SEQUENCE(_block_vars_45471)){
            _24023 = SEQ_PTR(_block_vars_45471)->length;
    }
    else {
        _24023 = 1;
    }
    {
        int _sx_45474;
        _sx_45474 = 1;
L2: 
        if (_sx_45474 > _24023){
            goto L3; // [83] 172
        }

        /** 		if SymTab[block_vars[sx]][S_MODE] = M_NORMAL */
        _2 = (int)SEQ_PTR(_block_vars_45471);
        _24024 = (int)*(((s1_ptr)_2)->base + _sx_45474);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_24024)){
            _24025 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24024)->dbl));
        }
        else{
            _24025 = (int)*(((s1_ptr)_2)->base + _24024);
        }
        _2 = (int)SEQ_PTR(_24025);
        _24026 = (int)*(((s1_ptr)_2)->base + 3);
        _24025 = NOVALUE;
        if (IS_ATOM_INT(_24026)) {
            _24027 = (_24026 == 1);
        }
        else {
            _24027 = binary_op(EQUALS, _24026, 1);
        }
        _24026 = NOVALUE;
        if (IS_ATOM_INT(_24027)) {
            if (_24027 == 0) {
                goto L4; // [114] 165
            }
        }
        else {
            if (DBL_PTR(_24027)->dbl == 0.0) {
                goto L4; // [114] 165
            }
        }
        _2 = (int)SEQ_PTR(_block_vars_45471);
        _24029 = (int)*(((s1_ptr)_2)->base + _sx_45474);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_24029)){
            _24030 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24029)->dbl));
        }
        else{
            _24030 = (int)*(((s1_ptr)_2)->base + _24029);
        }
        _2 = (int)SEQ_PTR(_24030);
        _24031 = (int)*(((s1_ptr)_2)->base + 4);
        _24030 = NOVALUE;
        if (IS_ATOM_INT(_24031)) {
            _24032 = (_24031 <= 5);
        }
        else {
            _24032 = binary_op(LESSEQ, _24031, 5);
        }
        _24031 = NOVALUE;
        if (_24032 == 0) {
            DeRef(_24032);
            _24032 = NOVALUE;
            goto L4; // [141] 165
        }
        else {
            if (!IS_ATOM_INT(_24032) && DBL_PTR(_24032)->dbl == 0.0){
                DeRef(_24032);
                _24032 = NOVALUE;
                goto L4; // [141] 165
            }
            DeRef(_24032);
            _24032 = NOVALUE;
        }
        DeRef(_24032);
        _24032 = NOVALUE;

        /** 			ifdef BDEBUG then*/

        /** 			Hide( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45471);
        _24034 = (int)*(((s1_ptr)_2)->base + _sx_45474);
        Ref(_24034);
        _53Hide(_24034);
        _24034 = NOVALUE;

        /** 			LintCheck( block_vars[sx] )*/
        _2 = (int)SEQ_PTR(_block_vars_45471);
        _24035 = (int)*(((s1_ptr)_2)->base + _sx_45474);
        Ref(_24035);
        _53LintCheck(_24035);
        _24035 = NOVALUE;
L4: 

        /** 	end for*/
        _sx_45474 = _sx_45474 + 1;
        goto L2; // [167] 90
L3: 
        ;
    }

    /** 	current_block = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24036 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24036 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24037 = (int)*(((s1_ptr)_2)->base + _24036);
    _2 = (int)SEQ_PTR(_24037);
    _66current_block_45288 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_66current_block_45288)){
        _66current_block_45288 = (long)DBL_PTR(_66current_block_45288)->dbl;
    }
    _24037 = NOVALUE;

    /** 	return block[BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_block_45458);
    _24039 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_24039);
    DeRefDS(_block_45458);
    DeRef(_block_vars_45471);
    DeRef(_24016);
    _24016 = NOVALUE;
    _24018 = NOVALUE;
    _24024 = NOVALUE;
    _24029 = NOVALUE;
    DeRef(_24027);
    _24027 = NOVALUE;
    return _24039;
    ;
}


int _66top_block(int _offset_45503)
{
    int _24047 = NOVALUE;
    int _24046 = NOVALUE;
    int _24045 = NOVALUE;
    int _24044 = NOVALUE;
    int _24043 = NOVALUE;
    int _24042 = NOVALUE;
    int _24040 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45503)) {
        _1 = (long)(DBL_PTR(_offset_45503)->dbl);
        DeRefDS(_offset_45503);
        _offset_45503 = _1;
    }

    /** 	if offset >= length(block_stack) then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24040 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24040 = 1;
    }
    if (_offset_45503 < _24040)
    goto L1; // [10] 33

    /** 		CompileErr(107, {offset,length(block_stack)})*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24042 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24042 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _offset_45503;
    ((int *)_2)[2] = _24042;
    _24043 = MAKE_SEQ(_1);
    _24042 = NOVALUE;
    _44CompileErr(107, _24043, 0);
    _24043 = NOVALUE;
    goto L2; // [30] 57
L1: 

    /** 		return block_stack[$-offset][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24044 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24044 = 1;
    }
    _24045 = _24044 - _offset_45503;
    _24044 = NOVALUE;
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24046 = (int)*(((s1_ptr)_2)->base + _24045);
    _2 = (int)SEQ_PTR(_24046);
    _24047 = (int)*(((s1_ptr)_2)->base + 1);
    _24046 = NOVALUE;
    Ref(_24047);
    _24045 = NOVALUE;
    return _24047;
L2: 
    ;
}


void _66End_block(int _opcode_45517)
{
    int _ix_45528 = NOVALUE;
    int _24055 = NOVALUE;
    int _24052 = NOVALUE;
    int _24051 = NOVALUE;
    int _24050 = NOVALUE;
    int _24049 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45517)) {
        _1 = (long)(DBL_PTR(_opcode_45517)->dbl);
        DeRefDS(_opcode_45517);
        _opcode_45517 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45517 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45517 = 27;
L1: 

    /** 	check_block( opcode )*/
    _66check_block(_opcode_45517);

    /** 	if not length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24049 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24049 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24050 = (int)*(((s1_ptr)_2)->base + _24049);
    _2 = (int)SEQ_PTR(_24050);
    _24051 = (int)*(((s1_ptr)_2)->base + 6);
    _24050 = NOVALUE;
    if (IS_SEQUENCE(_24051)){
            _24052 = SEQ_PTR(_24051)->length;
    }
    else {
        _24052 = 1;
    }
    _24051 = NOVALUE;
    if (_24052 != 0)
    goto L2; // [44] 64
    _24052 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_45528 = 1;

    /** 		ix = pop_block()*/
    _ix_45528 = _66pop_block();
    if (!IS_ATOM_INT(_ix_45528)) {
        _1 = (long)(DBL_PTR(_ix_45528)->dbl);
        DeRefDS(_ix_45528);
        _ix_45528 = _1;
    }
    goto L3; // [61] 80
L2: 

    /** 		Push( pop_block() )*/
    _24055 = _66pop_block();
    _41Push(_24055);
    _24055 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _41emit_op(206);
L3: 

    /** end procedure*/
    _24051 = NOVALUE;
    return;
    ;
}


int _66End_inline_block(int _opcode_45537)
{
    int _24062 = NOVALUE;
    int _24061 = NOVALUE;
    int _24060 = NOVALUE;
    int _24059 = NOVALUE;
    int _24058 = NOVALUE;
    int _24057 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45537)) {
        _1 = (long)(DBL_PTR(_opcode_45537)->dbl);
        DeRefDS(_opcode_45537);
        _opcode_45537 = _1;
    }

    /** 	if opcode = FUNC then*/
    if (_opcode_45537 != 501)
    goto L1; // [7] 21

    /** 		opcode = PROC*/
    _opcode_45537 = 27;
L1: 

    /** 	if length(block_stack[$][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24057 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24057 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24058 = (int)*(((s1_ptr)_2)->base + _24057);
    _2 = (int)SEQ_PTR(_24058);
    _24059 = (int)*(((s1_ptr)_2)->base + 6);
    _24058 = NOVALUE;
    if (IS_SEQUENCE(_24059)){
            _24060 = SEQ_PTR(_24059)->length;
    }
    else {
        _24060 = 1;
    }
    _24059 = NOVALUE;
    if (_24060 == 0)
    {
        _24060 = NOVALUE;
        goto L2; // [39] 60
    }
    else{
        _24060 = NOVALUE;
    }

    /** 		return { EXIT_BLOCK, pop_block() }*/
    _24061 = _66pop_block();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _24061;
    _24062 = MAKE_SEQ(_1);
    _24061 = NOVALUE;
    _24059 = NOVALUE;
    return _24062;
    goto L3; // [57] 72
L2: 

    /** 		Drop_block( opcode )*/
    _66Drop_block(_opcode_45537);

    /** 		return {}*/
    RefDS(_21815);
    _24059 = NOVALUE;
    DeRef(_24062);
    _24062 = NOVALUE;
    return _21815;
L3: 
    ;
}


void _66Sibling_block(int _opcode_45554)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45554)) {
        _1 = (long)(DBL_PTR(_opcode_45554)->dbl);
        DeRefDS(_opcode_45554);
        _opcode_45554 = _1;
    }

    /** 	End_block( opcode )*/
    _66End_block(_opcode_45554);

    /** 	Start_block( opcode )*/
    _66Start_block(_opcode_45554, 0);

    /** end procedure*/
    return;
    ;
}


void _66Leave_block(int _offset_45557)
{
    int _24068 = NOVALUE;
    int _24067 = NOVALUE;
    int _24066 = NOVALUE;
    int _24065 = NOVALUE;
    int _24064 = NOVALUE;
    int _24063 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_offset_45557)) {
        _1 = (long)(DBL_PTR(_offset_45557)->dbl);
        DeRefDS(_offset_45557);
        _offset_45557 = _1;
    }

    /** 	if length( block_stack[$-offset][BLOCK_VARS]) then*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24063 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24063 = 1;
    }
    _24064 = _24063 - _offset_45557;
    _24063 = NOVALUE;
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24065 = (int)*(((s1_ptr)_2)->base + _24064);
    _2 = (int)SEQ_PTR(_24065);
    _24066 = (int)*(((s1_ptr)_2)->base + 6);
    _24065 = NOVALUE;
    if (IS_SEQUENCE(_24066)){
            _24067 = SEQ_PTR(_24066)->length;
    }
    else {
        _24067 = 1;
    }
    _24066 = NOVALUE;
    if (_24067 == 0)
    {
        _24067 = NOVALUE;
        goto L1; // [25] 45
    }
    else{
        _24067 = NOVALUE;
    }

    /** 		Push( top_block( offset ) )*/
    _24068 = _66top_block(_offset_45557);
    _41Push(_24068);
    _24068 = NOVALUE;

    /** 		emit_op( EXIT_BLOCK )*/
    _41emit_op(206);
L1: 

    /** end procedure*/
    DeRef(_24064);
    _24064 = NOVALUE;
    _24066 = NOVALUE;
    return;
    ;
}


void _66Leave_blocks(int _blocks_45577, int _block_type_45578)
{
    int _bx_45579 = NOVALUE;
    int _Block_opcode_3__tmp_at29_45586 = NOVALUE;
    int _Block_opcode_2__tmp_at29_45585 = NOVALUE;
    int _Block_opcode_1__tmp_at29_45584 = NOVALUE;
    int _Block_opcode_inlined_Block_opcode_at_29_45583 = NOVALUE;
    int _24081 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_blocks_45577)) {
        _1 = (long)(DBL_PTR(_blocks_45577)->dbl);
        DeRefDS(_blocks_45577);
        _blocks_45577 = _1;
    }
    if (!IS_ATOM_INT(_block_type_45578)) {
        _1 = (long)(DBL_PTR(_block_type_45578)->dbl);
        DeRefDS(_block_type_45578);
        _block_type_45578 = _1;
    }

    /** 	integer bx = 0*/
    _bx_45579 = 0;

    /** 	while blocks do*/
L1: 
    if (_blocks_45577 == 0)
    {
        goto L2; // [15] 119
    }
    else{
    }

    /** 		Leave_block( bx )*/
    _66Leave_block(_bx_45579);

    /** 		if block_type then*/
    if (_block_type_45578 == 0)
    {
        goto L3; // [25] 101
    }
    else{
    }

    /** 			switch Block_opcode( bx ) do*/

    /** 	return block_stack[$-bx][BLOCK_OPCODE]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _Block_opcode_1__tmp_at29_45584 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _Block_opcode_1__tmp_at29_45584 = 1;
    }
    _Block_opcode_2__tmp_at29_45585 = _Block_opcode_1__tmp_at29_45584 - _bx_45579;
    DeRef(_Block_opcode_3__tmp_at29_45586);
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _Block_opcode_3__tmp_at29_45586 = (int)*(((s1_ptr)_2)->base + _Block_opcode_2__tmp_at29_45585);
    Ref(_Block_opcode_3__tmp_at29_45586);
    DeRef(_Block_opcode_inlined_Block_opcode_at_29_45583);
    _2 = (int)SEQ_PTR(_Block_opcode_3__tmp_at29_45586);
    _Block_opcode_inlined_Block_opcode_at_29_45583 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_Block_opcode_inlined_Block_opcode_at_29_45583);
    DeRef(_Block_opcode_3__tmp_at29_45586);
    _Block_opcode_3__tmp_at29_45586 = NOVALUE;
    if (IS_SEQUENCE(_Block_opcode_inlined_Block_opcode_at_29_45583) ){
        goto L4; // [52] 82
    }
    if(!IS_ATOM_INT(_Block_opcode_inlined_Block_opcode_at_29_45583)){
        if( (DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45583)->dbl != (double) ((int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45583)->dbl) ) ){
            goto L4; // [52] 82
        }
        _0 = (int) DBL_PTR(_Block_opcode_inlined_Block_opcode_at_29_45583)->dbl;
    }
    else {
        _0 = _Block_opcode_inlined_Block_opcode_at_29_45583;
    };
    switch ( _0 ){ 

        /** 				case FOR, WHILE, LOOP then*/
        case 21:
        case 47:
        case 422:

        /** 					if block_type = LOOP_BLOCK then*/
        if (_block_type_45578 != 1)
        goto L5; // [67] 108

        /** 						blocks -= 1*/
        _blocks_45577 = _blocks_45577 - 1;
        goto L5; // [78] 108

        /** 				case else*/
        default:
L4: 

        /** 					if block_type = CONDITIONAL_BLOCK then*/
        if (_block_type_45578 != 2)
        goto L6; // [86] 97

        /** 						blocks -= 1*/
        _blocks_45577 = _blocks_45577 - 1;
L6: 
    ;}    goto L5; // [98] 108
L3: 

    /** 			blocks -= 1*/
    _blocks_45577 = _blocks_45577 - 1;
L5: 

    /** 		bx += 1*/
    _bx_45579 = _bx_45579 + 1;

    /** 	end while*/
    goto L1; // [116] 15
L2: 

    /** 	for i = 0 to blocks - 1 do*/
    _24081 = _blocks_45577 - 1;
    if ((long)((unsigned long)_24081 +(unsigned long) HIGH_BITS) >= 0){
        _24081 = NewDouble((double)_24081);
    }
    {
        int _i_45604;
        _i_45604 = 0;
L7: 
        if (binary_op_a(GREATER, _i_45604, _24081)){
            goto L8; // [125] 144
        }

        /** 		Leave_block( i )*/
        Ref(_i_45604);
        _66Leave_block(_i_45604);

        /** 	end for*/
        _0 = _i_45604;
        if (IS_ATOM_INT(_i_45604)) {
            _i_45604 = _i_45604 + 1;
            if ((long)((unsigned long)_i_45604 +(unsigned long) HIGH_BITS) >= 0){
                _i_45604 = NewDouble((double)_i_45604);
            }
        }
        else {
            _i_45604 = binary_op_a(PLUS, _i_45604, 1);
        }
        DeRef(_0);
        goto L7; // [139] 132
L8: 
        ;
        DeRef(_i_45604);
    }

    /** end procedure*/
    DeRef(_24081);
    _24081 = NOVALUE;
    return;
    ;
}


void _66Drop_block(int _opcode_45608)
{
    int _x_45610 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_opcode_45608)) {
        _1 = (long)(DBL_PTR(_opcode_45608)->dbl);
        DeRefDS(_opcode_45608);
        _opcode_45608 = _1;
    }

    /** 	check_block( opcode )*/
    _66check_block(_opcode_45608);

    /** 	symtab_index x = pop_block()*/
    _x_45610 = _66pop_block();
    if (!IS_ATOM_INT(_x_45610)) {
        _1 = (long)(DBL_PTR(_x_45610)->dbl);
        DeRefDS(_x_45610);
        _x_45610 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _66Pop_block_var()
{
    int _sym_45615 = NOVALUE;
    int _block_sym_45622 = NOVALUE;
    int _24109 = NOVALUE;
    int _24108 = NOVALUE;
    int _24107 = NOVALUE;
    int _24106 = NOVALUE;
    int _24105 = NOVALUE;
    int _24104 = NOVALUE;
    int _24103 = NOVALUE;
    int _24102 = NOVALUE;
    int _24100 = NOVALUE;
    int _24099 = NOVALUE;
    int _24097 = NOVALUE;
    int _24096 = NOVALUE;
    int _24094 = NOVALUE;
    int _24091 = NOVALUE;
    int _24089 = NOVALUE;
    int _24088 = NOVALUE;
    int _24086 = NOVALUE;
    int _24085 = NOVALUE;
    int _24084 = NOVALUE;
    int _24083 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index sym = block_stack[$][BLOCK_VARS][$]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24083 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24083 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24084 = (int)*(((s1_ptr)_2)->base + _24083);
    _2 = (int)SEQ_PTR(_24084);
    _24085 = (int)*(((s1_ptr)_2)->base + 6);
    _24084 = NOVALUE;
    if (IS_SEQUENCE(_24085)){
            _24086 = SEQ_PTR(_24085)->length;
    }
    else {
        _24086 = 1;
    }
    _2 = (int)SEQ_PTR(_24085);
    _sym_45615 = (int)*(((s1_ptr)_2)->base + _24086);
    if (!IS_ATOM_INT(_sym_45615)){
        _sym_45615 = (long)DBL_PTR(_sym_45615)->dbl;
    }
    _24085 = NOVALUE;

    /** 	symtab_index block_sym = block_stack[$][BLOCK_SYM]*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24088 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24088 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24089 = (int)*(((s1_ptr)_2)->base + _24088);
    _2 = (int)SEQ_PTR(_24089);
    _block_sym_45622 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_block_sym_45622)){
        _block_sym_45622 = (long)DBL_PTR(_block_sym_45622)->dbl;
    }
    _24089 = NOVALUE;

    /** 	while sym_next_in_block( block_sym ) != sym do*/
L1: 
    _24091 = _53sym_next_in_block(_block_sym_45622);
    if (binary_op_a(EQUALS, _24091, _sym_45615)){
        DeRef(_24091);
        _24091 = NOVALUE;
        goto L2; // [51] 68
    }
    DeRef(_24091);
    _24091 = NOVALUE;

    /** 		block_sym = sym_next_in_block( block_sym )*/
    _block_sym_45622 = _53sym_next_in_block(_block_sym_45622);
    if (!IS_ATOM_INT(_block_sym_45622)) {
        _1 = (long)(DBL_PTR(_block_sym_45622)->dbl);
        DeRefDS(_block_sym_45622);
        _block_sym_45622 = _1;
    }

    /** 	end while*/
    goto L1; // [65] 47
L2: 

    /** 	SymTab[block_sym][S_NEXT_IN_BLOCK] = sym_next_in_block( sym )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_block_sym_45622 + ((s1_ptr)_2)->base);
    _24096 = _53sym_next_in_block(_sym_45615);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15633))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15633)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15633);
    _1 = *(int *)_2;
    *(int *)_2 = _24096;
    if( _1 != _24096 ){
        DeRef(_1);
    }
    _24096 = NOVALUE;
    _24094 = NOVALUE;

    /** 	SymTab[sym][S_NEXT_IN_BLOCK] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_45615 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NEXT_IN_BLOCK_15633))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NEXT_IN_BLOCK_15633)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NEXT_IN_BLOCK_15633);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24097 = NOVALUE;

    /** 	block_stack[$][BLOCK_VARS] = eu:remove( block_stack[$][BLOCK_VARS], */
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24099 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24099 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _66block_stack_45281 = MAKE_SEQ(_2);
    }
    _3 = (int)(_24099 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24102 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24102 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24103 = (int)*(((s1_ptr)_2)->base + _24102);
    _2 = (int)SEQ_PTR(_24103);
    _24104 = (int)*(((s1_ptr)_2)->base + 6);
    _24103 = NOVALUE;
    if (IS_SEQUENCE(_66block_stack_45281)){
            _24105 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _24105 = 1;
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24106 = (int)*(((s1_ptr)_2)->base + _24105);
    _2 = (int)SEQ_PTR(_24106);
    _24107 = (int)*(((s1_ptr)_2)->base + 6);
    _24106 = NOVALUE;
    if (IS_SEQUENCE(_24107)){
            _24108 = SEQ_PTR(_24107)->length;
    }
    else {
        _24108 = 1;
    }
    _24107 = NOVALUE;
    {
        s1_ptr assign_space = SEQ_PTR(_24104);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_24108)) ? _24108 : (long)(DBL_PTR(_24108)->dbl);
        int stop = (IS_ATOM_INT(_24108)) ? _24108 : (long)(DBL_PTR(_24108)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_24104);
            DeRef(_24109);
            _24109 = _24104;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_24104), start, &_24109 );
            }
            else Tail(SEQ_PTR(_24104), stop+1, &_24109);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_24104), start, &_24109);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_24109);
            _24109 = _1;
        }
    }
    _24104 = NOVALUE;
    _24108 = NOVALUE;
    _24108 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _24109;
    if( _1 != _24109 ){
        DeRef(_1);
    }
    _24109 = NOVALUE;
    _24100 = NOVALUE;

    /** end procedure*/
    _24107 = NOVALUE;
    return;
    ;
}


void _66Goto_block(int _from_block_45656, int _to_block_45658, int _pc_45659)
{
    int _code_45660 = NOVALUE;
    int _next_block_45662 = NOVALUE;
    int _24120 = NOVALUE;
    int _24117 = NOVALUE;
    int _24116 = NOVALUE;
    int _24115 = NOVALUE;
    int _24114 = NOVALUE;
    int _24113 = NOVALUE;
    int _24112 = NOVALUE;
    int _24111 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_from_block_45656)) {
        _1 = (long)(DBL_PTR(_from_block_45656)->dbl);
        DeRefDS(_from_block_45656);
        _from_block_45656 = _1;
    }
    if (!IS_ATOM_INT(_to_block_45658)) {
        _1 = (long)(DBL_PTR(_to_block_45658)->dbl);
        DeRefDS(_to_block_45658);
        _to_block_45658 = _1;
    }
    if (!IS_ATOM_INT(_pc_45659)) {
        _1 = (long)(DBL_PTR(_pc_45659)->dbl);
        DeRefDS(_pc_45659);
        _pc_45659 = _1;
    }

    /** 	sequence code = {}*/
    RefDS(_21815);
    DeRefi(_code_45660);
    _code_45660 = _21815;

    /** 	symtab_index next_block = sym_block( from_block )*/
    _next_block_45662 = _53sym_block(_from_block_45656);
    if (!IS_ATOM_INT(_next_block_45662)) {
        _1 = (long)(DBL_PTR(_next_block_45662)->dbl);
        DeRefDS(_next_block_45662);
        _next_block_45662 = _1;
    }

    /** 	while next_block */
L1: 
    if (_next_block_45662 == 0) {
        _24111 = 0;
        goto L2; // [27] 39
    }
    _24112 = (_from_block_45656 != _to_block_45658);
    _24111 = (_24112 != 0);
L2: 
    if (_24111 == 0) {
        goto L3; // [39] 93
    }
    _24114 = _53sym_token(_next_block_45662);
    _24115 = find_from(_24114, _37RTN_TOKS_15594, 1);
    DeRef(_24114);
    _24114 = NOVALUE;
    _24116 = (_24115 == 0);
    _24115 = NOVALUE;
    if (_24116 == 0)
    {
        DeRef(_24116);
        _24116 = NOVALUE;
        goto L3; // [58] 93
    }
    else{
        DeRef(_24116);
        _24116 = NOVALUE;
    }

    /** 		code &= { EXIT_BLOCK, from_block }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 206;
    ((int *)_2)[2] = _from_block_45656;
    _24117 = MAKE_SEQ(_1);
    Concat((object_ptr)&_code_45660, _code_45660, _24117);
    DeRefDS(_24117);
    _24117 = NOVALUE;

    /** 		from_block = next_block*/
    _from_block_45656 = _next_block_45662;

    /** 		next_block = sym_block( next_block )*/
    _next_block_45662 = _53sym_block(_next_block_45662);
    if (!IS_ATOM_INT(_next_block_45662)) {
        _1 = (long)(DBL_PTR(_next_block_45662)->dbl);
        DeRefDS(_next_block_45662);
        _next_block_45662 = _1;
    }

    /** 	end while*/
    goto L1; // [90] 27
L3: 

    /** 	if length(code) then*/
    if (IS_SEQUENCE(_code_45660)){
            _24120 = SEQ_PTR(_code_45660)->length;
    }
    else {
        _24120 = 1;
    }
    if (_24120 == 0)
    {
        _24120 = NOVALUE;
        goto L4; // [98] 127
    }
    else{
        _24120 = NOVALUE;
    }

    /** 		if pc then*/
    if (_pc_45659 == 0)
    {
        goto L5; // [103] 115
    }
    else{
    }

    /** 			insert_code( code, pc )*/
    RefDS(_code_45660);
    _65insert_code(_code_45660, _pc_45659);
    goto L6; // [112] 126
L5: 

    /** 			Code &= code*/
    Concat((object_ptr)&_35Code_16056, _35Code_16056, _code_45660);
L6: 
L4: 

    /** end procedure*/
    DeRefi(_code_45660);
    DeRef(_24112);
    _24112 = NOVALUE;
    return;
    ;
}


void _66blocks_info()
{
    int _0, _1, _2;
    

    /** 	? block_stack*/
    StdPrint(1, _66block_stack_45281, 1);

    /** end procedure*/
    return;
    ;
}


int _66Least_block()
{
    int _ix_45690 = NOVALUE;
    int _sub_block_45693 = NOVALUE;
    int _24134 = NOVALUE;
    int _24133 = NOVALUE;
    int _24131 = NOVALUE;
    int _24130 = NOVALUE;
    int _24129 = NOVALUE;
    int _24128 = NOVALUE;
    int _24127 = NOVALUE;
    int _24126 = NOVALUE;
    int _24125 = NOVALUE;
    int _24124 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer ix = length( block_stack )*/
    if (IS_SEQUENCE(_66block_stack_45281)){
            _ix_45690 = SEQ_PTR(_66block_stack_45281)->length;
    }
    else {
        _ix_45690 = 1;
    }

    /** 	symtab_index sub_block = sym_block( CurrentSub )*/
    _sub_block_45693 = _53sym_block(_35CurrentSub_15976);
    if (!IS_ATOM_INT(_sub_block_45693)) {
        _1 = (long)(DBL_PTR(_sub_block_45693)->dbl);
        DeRefDS(_sub_block_45693);
        _sub_block_45693 = _1;
    }

    /** 	while not length( block_stack[ix][BLOCK_VARS] ) */
L1: 
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24124 = (int)*(((s1_ptr)_2)->base + _ix_45690);
    _2 = (int)SEQ_PTR(_24124);
    _24125 = (int)*(((s1_ptr)_2)->base + 6);
    _24124 = NOVALUE;
    if (IS_SEQUENCE(_24125)){
            _24126 = SEQ_PTR(_24125)->length;
    }
    else {
        _24126 = 1;
    }
    _24125 = NOVALUE;
    _24127 = (_24126 == 0);
    _24126 = NOVALUE;
    if (_24127 == 0) {
        goto L2; // [39] 72
    }
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24129 = (int)*(((s1_ptr)_2)->base + _ix_45690);
    _2 = (int)SEQ_PTR(_24129);
    _24130 = (int)*(((s1_ptr)_2)->base + 1);
    _24129 = NOVALUE;
    if (IS_ATOM_INT(_24130)) {
        _24131 = (_24130 != _sub_block_45693);
    }
    else {
        _24131 = binary_op(NOTEQ, _24130, _sub_block_45693);
    }
    _24130 = NOVALUE;
    if (_24131 <= 0) {
        if (_24131 == 0) {
            DeRef(_24131);
            _24131 = NOVALUE;
            goto L2; // [58] 72
        }
        else {
            if (!IS_ATOM_INT(_24131) && DBL_PTR(_24131)->dbl == 0.0){
                DeRef(_24131);
                _24131 = NOVALUE;
                goto L2; // [58] 72
            }
            DeRef(_24131);
            _24131 = NOVALUE;
        }
    }
    DeRef(_24131);
    _24131 = NOVALUE;

    /** 		ix -= 1	*/
    _ix_45690 = _ix_45690 - 1;

    /** 	end while*/
    goto L1; // [69] 23
L2: 

    /** 	return block_stack[ix][BLOCK_SYM]*/
    _2 = (int)SEQ_PTR(_66block_stack_45281);
    _24133 = (int)*(((s1_ptr)_2)->base + _ix_45690);
    _2 = (int)SEQ_PTR(_24133);
    _24134 = (int)*(((s1_ptr)_2)->base + 1);
    _24133 = NOVALUE;
    Ref(_24134);
    _24125 = NOVALUE;
    DeRef(_24127);
    _24127 = NOVALUE;
    return _24134;
    ;
}



// 0x044383C5
