// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _14trim(int _source_8178, int _what_8179, int _ret_index_8180)
{
    int _rpos_8181 = NOVALUE;
    int _lpos_8182 = NOVALUE;
    int _4470 = NOVALUE;
    int _4468 = NOVALUE;
    int _4466 = NOVALUE;
    int _4464 = NOVALUE;
    int _4461 = NOVALUE;
    int _4460 = NOVALUE;
    int _4455 = NOVALUE;
    int _4454 = NOVALUE;
    int _4452 = NOVALUE;
    int _4450 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(what) then*/
    _4450 = 0;
    if (_4450 == 0)
    {
        _4450 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _4450 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_8179;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_what_8179);
    *((int *)(_2+4)) = _what_8179;
    _what_8179 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_8182 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_8178)){
            _4452 = SEQ_PTR(_source_8178)->length;
    }
    else {
        _4452 = 1;
    }
    if (_lpos_8182 > _4452)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_8178);
    _4454 = (int)*(((s1_ptr)_2)->base + _lpos_8182);
    _4455 = find_from(_4454, _what_8179, 1);
    _4454 = NOVALUE;
    if (_4455 != 0)
    goto L4; // [48] 56
    _4455 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_8182 = _lpos_8182 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_8178)){
            _rpos_8181 = SEQ_PTR(_source_8178)->length;
    }
    else {
        _rpos_8181 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_8181 <= _lpos_8182)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_8178);
    _4460 = (int)*(((s1_ptr)_2)->base + _rpos_8181);
    _4461 = find_from(_4460, _what_8179, 1);
    _4460 = NOVALUE;
    if (_4461 != 0)
    goto L7; // [92] 100
    _4461 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_8181 = _rpos_8181 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_8180 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_8182;
    ((int *)_2)[2] = _rpos_8181;
    _4464 = MAKE_SEQ(_1);
    DeRefDS(_source_8178);
    DeRef(_what_8179);
    return _4464;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_8182 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_8178)){
            _4466 = SEQ_PTR(_source_8178)->length;
    }
    else {
        _4466 = 1;
    }
    if (_rpos_8181 != _4466)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_8179);
    DeRef(_4464);
    _4464 = NOVALUE;
    return _source_8178;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_8178)){
            _4468 = SEQ_PTR(_source_8178)->length;
    }
    else {
        _4468 = 1;
    }
    if (_lpos_8182 <= _4468)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_8178);
    DeRef(_what_8179);
    DeRef(_4464);
    _4464 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_4470;
    RHS_Slice(_source_8178, _lpos_8182, _rpos_8181);
    DeRefDS(_source_8178);
    DeRef(_what_8179);
    DeRef(_4464);
    _4464 = NOVALUE;
    return _4470;
L9: 
    ;
}


int _14lower(int _x_8370)
{
    int _4582 = NOVALUE;
    int _4581 = NOVALUE;
    int _4580 = NOVALUE;
    int _4579 = NOVALUE;
    int _4578 = NOVALUE;
    int _4575 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    _4575 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return x + (x >= 'A' and x <= 'Z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_8370)) {
        _4578 = (_x_8370 >= 65);
    }
    else {
        _4578 = binary_op(GREATEREQ, _x_8370, 65);
    }
    if (IS_ATOM_INT(_x_8370)) {
        _4579 = (_x_8370 <= 90);
    }
    else {
        _4579 = binary_op(LESSEQ, _x_8370, 90);
    }
    if (IS_ATOM_INT(_4578) && IS_ATOM_INT(_4579)) {
        _4580 = (_4578 != 0 && _4579 != 0);
    }
    else {
        _4580 = binary_op(AND, _4578, _4579);
    }
    DeRef(_4578);
    _4578 = NOVALUE;
    DeRef(_4579);
    _4579 = NOVALUE;
    if (IS_ATOM_INT(_4580)) {
        if (_4580 == (short)_4580)
        _4581 = _4580 * 32;
        else
        _4581 = NewDouble(_4580 * (double)32);
    }
    else {
        _4581 = binary_op(MULTIPLY, _4580, 32);
    }
    DeRef(_4580);
    _4580 = NOVALUE;
    if (IS_ATOM_INT(_x_8370) && IS_ATOM_INT(_4581)) {
        _4582 = _x_8370 + _4581;
        if ((long)((unsigned long)_4582 + (unsigned long)HIGH_BITS) >= 0) 
        _4582 = NewDouble((double)_4582);
    }
    else {
        _4582 = binary_op(PLUS, _x_8370, _4581);
    }
    DeRef(_4581);
    _4581 = NOVALUE;
    DeRef(_x_8370);
    return _4582;
    ;
}


int _14upper(int _x_8382)
{
    int _4590 = NOVALUE;
    int _4589 = NOVALUE;
    int _4588 = NOVALUE;
    int _4587 = NOVALUE;
    int _4586 = NOVALUE;
    int _4583 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    _4583 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return x - (x >= 'a' and x <= 'z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_8382)) {
        _4586 = (_x_8382 >= 97);
    }
    else {
        _4586 = binary_op(GREATEREQ, _x_8382, 97);
    }
    if (IS_ATOM_INT(_x_8382)) {
        _4587 = (_x_8382 <= 122);
    }
    else {
        _4587 = binary_op(LESSEQ, _x_8382, 122);
    }
    if (IS_ATOM_INT(_4586) && IS_ATOM_INT(_4587)) {
        _4588 = (_4586 != 0 && _4587 != 0);
    }
    else {
        _4588 = binary_op(AND, _4586, _4587);
    }
    DeRef(_4586);
    _4586 = NOVALUE;
    DeRef(_4587);
    _4587 = NOVALUE;
    if (IS_ATOM_INT(_4588)) {
        if (_4588 == (short)_4588)
        _4589 = _4588 * 32;
        else
        _4589 = NewDouble(_4588 * (double)32);
    }
    else {
        _4589 = binary_op(MULTIPLY, _4588, 32);
    }
    DeRef(_4588);
    _4588 = NOVALUE;
    if (IS_ATOM_INT(_x_8382) && IS_ATOM_INT(_4589)) {
        _4590 = _x_8382 - _4589;
        if ((long)((unsigned long)_4590 +(unsigned long) HIGH_BITS) >= 0){
            _4590 = NewDouble((double)_4590);
        }
    }
    else {
        _4590 = binary_op(MINUS, _x_8382, _4589);
    }
    DeRef(_4589);
    _4589 = NOVALUE;
    DeRef(_x_8382);
    return _4590;
    ;
}


int _14proper(int _x_8394)
{
    int _pos_8395 = NOVALUE;
    int _inword_8396 = NOVALUE;
    int _convert_8397 = NOVALUE;
    int _res_8398 = NOVALUE;
    int _4620 = NOVALUE;
    int _4619 = NOVALUE;
    int _4618 = NOVALUE;
    int _4617 = NOVALUE;
    int _4616 = NOVALUE;
    int _4615 = NOVALUE;
    int _4614 = NOVALUE;
    int _4613 = NOVALUE;
    int _4612 = NOVALUE;
    int _4611 = NOVALUE;
    int _4609 = NOVALUE;
    int _4608 = NOVALUE;
    int _4603 = NOVALUE;
    int _4600 = NOVALUE;
    int _4597 = NOVALUE;
    int _4594 = NOVALUE;
    int _4593 = NOVALUE;
    int _4592 = NOVALUE;
    int _4591 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_8396 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_8397 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_8394);
    DeRef(_res_8398);
    _res_8398 = _x_8394;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_8398)){
            _4591 = SEQ_PTR(_res_8398)->length;
    }
    else {
        _4591 = 1;
    }
    {
        int _i_8400;
        _i_8400 = 1;
L1: 
        if (_i_8400 > _4591){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4592 = (int)*(((s1_ptr)_2)->base + _i_8400);
        if (IS_ATOM_INT(_4592))
        _4593 = 1;
        else if (IS_ATOM_DBL(_4592))
        _4593 = IS_ATOM_INT(DoubleToInt(_4592));
        else
        _4593 = 0;
        _4592 = NOVALUE;
        if (_4593 == 0)
        {
            _4593 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _4593 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_8397 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4594 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4594);
        _pos_8395 = _13t_upper(_4594);
        _4594 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8395)) {
            _1 = (long)(DBL_PTR(_pos_8395)->dbl);
            DeRefDS(_pos_8395);
            _pos_8395 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_8395 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4597 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4597);
        _pos_8395 = _13t_lower(_4597);
        _4597 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8395)) {
            _1 = (long)(DBL_PTR(_pos_8395)->dbl);
            DeRefDS(_pos_8395);
            _pos_8395 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_8395 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4600 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4600);
        _pos_8395 = _13t_digit(_4600);
        _4600 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8395)) {
            _1 = (long)(DBL_PTR(_pos_8395)->dbl);
            DeRefDS(_pos_8395);
            _pos_8395 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_8395 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4603 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4603);
        _pos_8395 = _13t_specword(_4603);
        _4603 = NOVALUE;
        if (!IS_ATOM_INT(_pos_8395)) {
            _1 = (long)(DBL_PTR(_pos_8395)->dbl);
            DeRefDS(_pos_8395);
            _pos_8395 = _1;
        }

        /** 							if pos then*/
        if (_pos_8395 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_8396 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_8396 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_8396 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_8395 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4608 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4608);
        _4609 = _14upper(_4608);
        _4608 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8398);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8398 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8400);
        _1 = *(int *)_2;
        *(int *)_2 = _4609;
        if( _1 != _4609 ){
            DeRef(_1);
        }
        _4609 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_8396 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_8396 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4611 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4611);
        _4612 = _14lower(_4611);
        _4611 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8398);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8398 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8400);
        _1 = *(int *)_2;
        *(int *)_2 = _4612;
        if( _1 != _4612 ){
            DeRef(_1);
        }
        _4612 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_8396 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_8397 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _4613 = _i_8400 - 1;
        {
            int _j_8441;
            _j_8441 = 1;
LB: 
            if (_j_8441 > _4613){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_8394);
            _4614 = (int)*(((s1_ptr)_2)->base + _j_8441);
            _4615 = IS_ATOM(_4614);
            _4614 = NOVALUE;
            if (_4615 == 0)
            {
                _4615 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _4615 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_8394);
            _4616 = (int)*(((s1_ptr)_2)->base + _j_8441);
            Ref(_4616);
            _2 = (int)SEQ_PTR(_res_8398);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_8398 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_8441);
            _1 = *(int *)_2;
            *(int *)_2 = _4616;
            if( _1 != _4616 ){
                DeRef(_1);
            }
            _4616 = NOVALUE;
LD: 

            /** 				end for*/
            _j_8441 = _j_8441 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_8397 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4617 = (int)*(((s1_ptr)_2)->base + _i_8400);
        _4618 = IS_SEQUENCE(_4617);
        _4617 = NOVALUE;
        if (_4618 == 0)
        {
            _4618 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _4618 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_8398);
        _4619 = (int)*(((s1_ptr)_2)->base + _i_8400);
        Ref(_4619);
        _4620 = _14proper(_4619);
        _4619 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_8398);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_8398 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8400);
        _1 = *(int *)_2;
        *(int *)_2 = _4620;
        if( _1 != _4620 ){
            DeRef(_1);
        }
        _4620 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_8400 = _i_8400 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_8394);
    DeRef(_4613);
    _4613 = NOVALUE;
    return _res_8398;
    ;
}


int _14quote(int _text_in_8717, int _quote_pair_8718, int _esc_8720, int _sp_8722)
{
    int _4891 = NOVALUE;
    int _4890 = NOVALUE;
    int _4889 = NOVALUE;
    int _4887 = NOVALUE;
    int _4886 = NOVALUE;
    int _4885 = NOVALUE;
    int _4883 = NOVALUE;
    int _4882 = NOVALUE;
    int _4881 = NOVALUE;
    int _4880 = NOVALUE;
    int _4879 = NOVALUE;
    int _4878 = NOVALUE;
    int _4877 = NOVALUE;
    int _4876 = NOVALUE;
    int _4875 = NOVALUE;
    int _4873 = NOVALUE;
    int _4872 = NOVALUE;
    int _4871 = NOVALUE;
    int _4869 = NOVALUE;
    int _4868 = NOVALUE;
    int _4867 = NOVALUE;
    int _4866 = NOVALUE;
    int _4865 = NOVALUE;
    int _4864 = NOVALUE;
    int _4863 = NOVALUE;
    int _4862 = NOVALUE;
    int _4861 = NOVALUE;
    int _4859 = NOVALUE;
    int _4858 = NOVALUE;
    int _4856 = NOVALUE;
    int _4855 = NOVALUE;
    int _4854 = NOVALUE;
    int _4852 = NOVALUE;
    int _4851 = NOVALUE;
    int _4850 = NOVALUE;
    int _4849 = NOVALUE;
    int _4848 = NOVALUE;
    int _4847 = NOVALUE;
    int _4846 = NOVALUE;
    int _4845 = NOVALUE;
    int _4844 = NOVALUE;
    int _4843 = NOVALUE;
    int _4842 = NOVALUE;
    int _4841 = NOVALUE;
    int _4840 = NOVALUE;
    int _4839 = NOVALUE;
    int _4838 = NOVALUE;
    int _4837 = NOVALUE;
    int _4836 = NOVALUE;
    int _4833 = NOVALUE;
    int _4832 = NOVALUE;
    int _4831 = NOVALUE;
    int _4830 = NOVALUE;
    int _4829 = NOVALUE;
    int _4828 = NOVALUE;
    int _4827 = NOVALUE;
    int _4826 = NOVALUE;
    int _4825 = NOVALUE;
    int _4824 = NOVALUE;
    int _4823 = NOVALUE;
    int _4822 = NOVALUE;
    int _4821 = NOVALUE;
    int _4820 = NOVALUE;
    int _4817 = NOVALUE;
    int _4815 = NOVALUE;
    int _4814 = NOVALUE;
    int _4812 = NOVALUE;
    int _4810 = NOVALUE;
    int _4809 = NOVALUE;
    int _4808 = NOVALUE;
    int _4806 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_8717)){
            _4806 = SEQ_PTR(_text_in_8717)->length;
    }
    else {
        _4806 = 1;
    }
    if (_4806 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_8718);
    DeRef(_sp_8722);
    return _text_in_8717;
L1: 

    /** 	if atom(quote_pair) then*/
    _4808 = IS_ATOM(_quote_pair_8718);
    if (_4808 == 0)
    {
        _4808 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _4808 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_8718);
    *((int *)(_2+4)) = _quote_pair_8718;
    _4809 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_8718);
    *((int *)(_2+4)) = _quote_pair_8718;
    _4810 = MAKE_SEQ(_1);
    DeRef(_quote_pair_8718);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4809;
    ((int *)_2)[2] = _4810;
    _quote_pair_8718 = MAKE_SEQ(_1);
    _4810 = NOVALUE;
    _4809 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_8718)){
            _4812 = SEQ_PTR(_quote_pair_8718)->length;
    }
    else {
        _4812 = 1;
    }
    if (_4812 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4814 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4815 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_4815);
    Ref(_4814);
    DeRef(_quote_pair_8718);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4814;
    ((int *)_2)[2] = _4815;
    _quote_pair_8718 = MAKE_SEQ(_1);
    _4815 = NOVALUE;
    _4814 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_8718)){
            _4817 = SEQ_PTR(_quote_pair_8718)->length;
    }
    else {
        _4817 = 1;
    }
    if (_4817 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_4798);
    RefDS(_4798);
    DeRef(_quote_pair_8718);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4798;
    ((int *)_2)[2] = _4798;
    _quote_pair_8718 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_8717);
    _4820 = (int)*(((s1_ptr)_2)->base + 1);
    _4821 = IS_SEQUENCE(_4820);
    _4820 = NOVALUE;
    if (_4821 == 0)
    {
        _4821 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _4821 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_8717)){
            _4822 = SEQ_PTR(_text_in_8717)->length;
    }
    else {
        _4822 = 1;
    }
    {
        int _i_8745;
        _i_8745 = 1;
L7: 
        if (_i_8745 > _4822){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_8717);
        _4823 = (int)*(((s1_ptr)_2)->base + _i_8745);
        _4824 = IS_SEQUENCE(_4823);
        _4823 = NOVALUE;
        if (_4824 == 0)
        {
            _4824 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _4824 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_8717);
        _4825 = (int)*(((s1_ptr)_2)->base + _i_8745);
        Ref(_quote_pair_8718);
        DeRef(_4826);
        _4826 = _quote_pair_8718;
        DeRef(_4827);
        _4827 = _esc_8720;
        Ref(_sp_8722);
        DeRef(_4828);
        _4828 = _sp_8722;
        Ref(_4825);
        _4829 = _14quote(_4825, _4826, _4827, _4828);
        _4825 = NOVALUE;
        _4826 = NOVALUE;
        _4827 = NOVALUE;
        _4828 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_8717);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_8717 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_8745);
        _1 = *(int *)_2;
        *(int *)_2 = _4829;
        if( _1 != _4829 ){
            DeRef(_1);
        }
        _4829 = NOVALUE;
L9: 

        /** 		end for*/
        _i_8745 = _i_8745 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_8718);
    DeRef(_sp_8722);
    return _text_in_8717;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_8722)){
            _4830 = SEQ_PTR(_sp_8722)->length;
    }
    else {
        _4830 = 1;
    }
    {
        int _i_8756;
        _i_8756 = 1;
LA: 
        if (_i_8756 > _4830){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_8722);
        _4831 = (int)*(((s1_ptr)_2)->base + _i_8756);
        _4832 = find_from(_4831, _text_in_8717, 1);
        _4831 = NOVALUE;
        if (_4832 == 0)
        {
            _4832 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _4832 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_8722)){
                _4833 = SEQ_PTR(_sp_8722)->length;
        }
        else {
            _4833 = 1;
        }
        if (_i_8756 != _4833)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_8718);
        DeRef(_sp_8722);
        return _text_in_8717;
LD: 

        /** 	end for*/
        _i_8756 = _i_8756 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_8720 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4836 = (int)*(((s1_ptr)_2)->base + 1);
    _4837 = IS_ATOM(_4836);
    _4836 = NOVALUE;
    if (_4837 == 0)
    {
        _4837 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _4837 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4838 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_4838);
    *((int *)(_2+4)) = _4838;
    _4839 = MAKE_SEQ(_1);
    _4838 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_8718 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _4839;
    if( _1 != _4839 ){
        DeRef(_1);
    }
    _4839 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4840 = (int)*(((s1_ptr)_2)->base + 2);
    _4841 = IS_ATOM(_4840);
    _4840 = NOVALUE;
    if (_4841 == 0)
    {
        _4841 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _4841 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4842 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_4842);
    *((int *)(_2+4)) = _4842;
    _4843 = MAKE_SEQ(_1);
    _4842 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_8718 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _4843;
    if( _1 != _4843 ){
        DeRef(_1);
    }
    _4843 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4844 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4845 = (int)*(((s1_ptr)_2)->base + 2);
    if (_4844 == _4845)
    _4846 = 1;
    else if (IS_ATOM_INT(_4844) && IS_ATOM_INT(_4845))
    _4846 = 0;
    else
    _4846 = (compare(_4844, _4845) == 0);
    _4844 = NOVALUE;
    _4845 = NOVALUE;
    if (_4846 == 0)
    {
        _4846 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _4846 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4847 = (int)*(((s1_ptr)_2)->base + 1);
    _4848 = e_match_from(_4847, _text_in_8717, 1);
    _4847 = NOVALUE;
    if (_4848 == 0)
    {
        _4848 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _4848 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4849 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4849)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4849)) {
        Prepend(&_4850, _4849, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4850, _esc_8720, _4849);
    }
    _4849 = NOVALUE;
    _4851 = e_match_from(_4850, _text_in_8717, 1);
    DeRefDS(_4850);
    _4850 = NOVALUE;
    if (_4851 == 0)
    {
        _4851 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _4851 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_4852, _esc_8720, _esc_8720);
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_esc_8720, _text_in_8717, _4852, 0);
    DeRefDS(_0);
    _4852 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4854 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4855 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4855)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4855)) {
        Prepend(&_4856, _4855, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4856, _esc_8720, _4855);
    }
    _4855 = NOVALUE;
    Ref(_4854);
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_4854, _text_in_8717, _4856, 0);
    DeRefDS(_0);
    _4854 = NOVALUE;
    _4856 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4858 = (int)*(((s1_ptr)_2)->base + 1);
    _4859 = e_match_from(_4858, _text_in_8717, 1);
    _4858 = NOVALUE;
    if (_4859 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4861 = (int)*(((s1_ptr)_2)->base + 2);
    _4862 = e_match_from(_4861, _text_in_8717, 1);
    _4861 = NOVALUE;
    if (_4862 == 0)
    {
        _4862 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _4862 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4863 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4863)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4863)) {
        Prepend(&_4864, _4863, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4864, _esc_8720, _4863);
    }
    _4863 = NOVALUE;
    _4865 = e_match_from(_4864, _text_in_8717, 1);
    DeRefDS(_4864);
    _4864 = NOVALUE;
    if (_4865 == 0)
    {
        _4865 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _4865 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4866 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4866)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4866)) {
        Prepend(&_4867, _4866, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4867, _esc_8720, _4866);
    }
    _4866 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4868 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _4868;
        concat_list[1] = _esc_8720;
        concat_list[2] = _esc_8720;
        Concat_N((object_ptr)&_4869, concat_list, 3);
    }
    _4868 = NOVALUE;
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_4867, _text_in_8717, _4869, 0);
    DeRefDS(_0);
    _4867 = NOVALUE;
    _4869 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4871 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4872 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4872)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4872)) {
        Prepend(&_4873, _4872, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4873, _esc_8720, _4872);
    }
    _4872 = NOVALUE;
    Ref(_4871);
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_4871, _text_in_8717, _4873, 0);
    DeRefDS(_0);
    _4871 = NOVALUE;
    _4873 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4875 = (int)*(((s1_ptr)_2)->base + 2);
    _4876 = e_match_from(_4875, _text_in_8717, 1);
    _4875 = NOVALUE;
    if (_4876 == 0)
    {
        _4876 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _4876 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4877 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4877)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4877)) {
        Prepend(&_4878, _4877, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4878, _esc_8720, _4877);
    }
    _4877 = NOVALUE;
    _4879 = e_match_from(_4878, _text_in_8717, 1);
    DeRefDS(_4878);
    _4878 = NOVALUE;
    if (_4879 == 0)
    {
        _4879 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _4879 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4880 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4880)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4880)) {
        Prepend(&_4881, _4880, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4881, _esc_8720, _4880);
    }
    _4880 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4882 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _4882;
        concat_list[1] = _esc_8720;
        concat_list[2] = _esc_8720;
        Concat_N((object_ptr)&_4883, concat_list, 3);
    }
    _4882 = NOVALUE;
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_4881, _text_in_8717, _4883, 0);
    DeRefDS(_0);
    _4881 = NOVALUE;
    _4883 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4885 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4886 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_8720) && IS_ATOM(_4886)) {
    }
    else if (IS_ATOM(_esc_8720) && IS_SEQUENCE(_4886)) {
        Prepend(&_4887, _4886, _esc_8720);
    }
    else {
        Concat((object_ptr)&_4887, _esc_8720, _4886);
    }
    _4886 = NOVALUE;
    Ref(_4885);
    RefDS(_text_in_8717);
    _0 = _text_in_8717;
    _text_in_8717 = _16match_replace(_4885, _text_in_8717, _4887, 0);
    DeRefDS(_0);
    _4885 = NOVALUE;
    _4887 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4889 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_8718);
    _4890 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _4890;
        concat_list[1] = _text_in_8717;
        concat_list[2] = _4889;
        Concat_N((object_ptr)&_4891, concat_list, 3);
    }
    _4890 = NOVALUE;
    _4889 = NOVALUE;
    DeRefDS(_text_in_8717);
    DeRef(_quote_pair_8718);
    DeRef(_sp_8722);
    return _4891;
    ;
}


int _14format(int _format_pattern_8938, int _arg_list_8939)
{
    int _result_8940 = NOVALUE;
    int _in_token_8941 = NOVALUE;
    int _tch_8942 = NOVALUE;
    int _i_8943 = NOVALUE;
    int _tend_8944 = NOVALUE;
    int _cap_8945 = NOVALUE;
    int _align_8946 = NOVALUE;
    int _psign_8947 = NOVALUE;
    int _msign_8948 = NOVALUE;
    int _zfill_8949 = NOVALUE;
    int _bwz_8950 = NOVALUE;
    int _spacer_8951 = NOVALUE;
    int _alt_8952 = NOVALUE;
    int _width_8953 = NOVALUE;
    int _decs_8954 = NOVALUE;
    int _pos_8955 = NOVALUE;
    int _argn_8956 = NOVALUE;
    int _argl_8957 = NOVALUE;
    int _trimming_8958 = NOVALUE;
    int _hexout_8959 = NOVALUE;
    int _binout_8960 = NOVALUE;
    int _tsep_8961 = NOVALUE;
    int _istext_8962 = NOVALUE;
    int _prevargv_8963 = NOVALUE;
    int _currargv_8964 = NOVALUE;
    int _idname_8965 = NOVALUE;
    int _envsym_8966 = NOVALUE;
    int _envvar_8967 = NOVALUE;
    int _ep_8968 = NOVALUE;
    int _sp_9041 = NOVALUE;
    int _sp_9077 = NOVALUE;
    int _argtext_9124 = NOVALUE;
    int _tempv_9347 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_9402 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_9401 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_9409 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_9408 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_9407 = NOVALUE;
    int _msg_inlined_crash_at_2631_9431 = NOVALUE;
    int _dpos_9474 = NOVALUE;
    int _dist_9475 = NOVALUE;
    int _bracketed_9476 = NOVALUE;
    int _5383 = NOVALUE;
    int _5382 = NOVALUE;
    int _5381 = NOVALUE;
    int _5379 = NOVALUE;
    int _5378 = NOVALUE;
    int _5377 = NOVALUE;
    int _5374 = NOVALUE;
    int _5373 = NOVALUE;
    int _5370 = NOVALUE;
    int _5368 = NOVALUE;
    int _5365 = NOVALUE;
    int _5364 = NOVALUE;
    int _5363 = NOVALUE;
    int _5360 = NOVALUE;
    int _5357 = NOVALUE;
    int _5356 = NOVALUE;
    int _5355 = NOVALUE;
    int _5354 = NOVALUE;
    int _5351 = NOVALUE;
    int _5350 = NOVALUE;
    int _5349 = NOVALUE;
    int _5346 = NOVALUE;
    int _5344 = NOVALUE;
    int _5341 = NOVALUE;
    int _5340 = NOVALUE;
    int _5339 = NOVALUE;
    int _5338 = NOVALUE;
    int _5335 = NOVALUE;
    int _5330 = NOVALUE;
    int _5329 = NOVALUE;
    int _5328 = NOVALUE;
    int _5327 = NOVALUE;
    int _5321 = NOVALUE;
    int _5317 = NOVALUE;
    int _5316 = NOVALUE;
    int _5314 = NOVALUE;
    int _5312 = NOVALUE;
    int _5311 = NOVALUE;
    int _5310 = NOVALUE;
    int _5309 = NOVALUE;
    int _5308 = NOVALUE;
    int _5305 = NOVALUE;
    int _5302 = NOVALUE;
    int _5301 = NOVALUE;
    int _5298 = NOVALUE;
    int _5297 = NOVALUE;
    int _5296 = NOVALUE;
    int _5293 = NOVALUE;
    int _5291 = NOVALUE;
    int _5286 = NOVALUE;
    int _5285 = NOVALUE;
    int _5277 = NOVALUE;
    int _5273 = NOVALUE;
    int _5271 = NOVALUE;
    int _5270 = NOVALUE;
    int _5269 = NOVALUE;
    int _5266 = NOVALUE;
    int _5264 = NOVALUE;
    int _5263 = NOVALUE;
    int _5262 = NOVALUE;
    int _5260 = NOVALUE;
    int _5259 = NOVALUE;
    int _5258 = NOVALUE;
    int _5257 = NOVALUE;
    int _5254 = NOVALUE;
    int _5253 = NOVALUE;
    int _5252 = NOVALUE;
    int _5250 = NOVALUE;
    int _5249 = NOVALUE;
    int _5248 = NOVALUE;
    int _5247 = NOVALUE;
    int _5245 = NOVALUE;
    int _5243 = NOVALUE;
    int _5241 = NOVALUE;
    int _5239 = NOVALUE;
    int _5237 = NOVALUE;
    int _5235 = NOVALUE;
    int _5234 = NOVALUE;
    int _5233 = NOVALUE;
    int _5232 = NOVALUE;
    int _5231 = NOVALUE;
    int _5230 = NOVALUE;
    int _5228 = NOVALUE;
    int _5227 = NOVALUE;
    int _5225 = NOVALUE;
    int _5224 = NOVALUE;
    int _5222 = NOVALUE;
    int _5220 = NOVALUE;
    int _5219 = NOVALUE;
    int _5216 = NOVALUE;
    int _5214 = NOVALUE;
    int _5210 = NOVALUE;
    int _5208 = NOVALUE;
    int _5207 = NOVALUE;
    int _5206 = NOVALUE;
    int _5204 = NOVALUE;
    int _5203 = NOVALUE;
    int _5202 = NOVALUE;
    int _5201 = NOVALUE;
    int _5200 = NOVALUE;
    int _5198 = NOVALUE;
    int _5196 = NOVALUE;
    int _5195 = NOVALUE;
    int _5194 = NOVALUE;
    int _5193 = NOVALUE;
    int _5189 = NOVALUE;
    int _5186 = NOVALUE;
    int _5185 = NOVALUE;
    int _5182 = NOVALUE;
    int _5181 = NOVALUE;
    int _5180 = NOVALUE;
    int _5178 = NOVALUE;
    int _5177 = NOVALUE;
    int _5176 = NOVALUE;
    int _5175 = NOVALUE;
    int _5173 = NOVALUE;
    int _5171 = NOVALUE;
    int _5170 = NOVALUE;
    int _5169 = NOVALUE;
    int _5168 = NOVALUE;
    int _5167 = NOVALUE;
    int _5166 = NOVALUE;
    int _5164 = NOVALUE;
    int _5163 = NOVALUE;
    int _5162 = NOVALUE;
    int _5160 = NOVALUE;
    int _5159 = NOVALUE;
    int _5158 = NOVALUE;
    int _5157 = NOVALUE;
    int _5155 = NOVALUE;
    int _5152 = NOVALUE;
    int _5151 = NOVALUE;
    int _5149 = NOVALUE;
    int _5148 = NOVALUE;
    int _5146 = NOVALUE;
    int _5143 = NOVALUE;
    int _5142 = NOVALUE;
    int _5139 = NOVALUE;
    int _5137 = NOVALUE;
    int _5133 = NOVALUE;
    int _5131 = NOVALUE;
    int _5130 = NOVALUE;
    int _5129 = NOVALUE;
    int _5127 = NOVALUE;
    int _5125 = NOVALUE;
    int _5124 = NOVALUE;
    int _5123 = NOVALUE;
    int _5122 = NOVALUE;
    int _5121 = NOVALUE;
    int _5119 = NOVALUE;
    int _5117 = NOVALUE;
    int _5116 = NOVALUE;
    int _5115 = NOVALUE;
    int _5114 = NOVALUE;
    int _5112 = NOVALUE;
    int _5109 = NOVALUE;
    int _5107 = NOVALUE;
    int _5106 = NOVALUE;
    int _5104 = NOVALUE;
    int _5103 = NOVALUE;
    int _5102 = NOVALUE;
    int _5099 = NOVALUE;
    int _5098 = NOVALUE;
    int _5097 = NOVALUE;
    int _5096 = NOVALUE;
    int _5094 = NOVALUE;
    int _5093 = NOVALUE;
    int _5092 = NOVALUE;
    int _5091 = NOVALUE;
    int _5090 = NOVALUE;
    int _5087 = NOVALUE;
    int _5086 = NOVALUE;
    int _5085 = NOVALUE;
    int _5084 = NOVALUE;
    int _5082 = NOVALUE;
    int _5081 = NOVALUE;
    int _5080 = NOVALUE;
    int _5078 = NOVALUE;
    int _5077 = NOVALUE;
    int _5076 = NOVALUE;
    int _5074 = NOVALUE;
    int _5067 = NOVALUE;
    int _5065 = NOVALUE;
    int _5064 = NOVALUE;
    int _5057 = NOVALUE;
    int _5054 = NOVALUE;
    int _5050 = NOVALUE;
    int _5048 = NOVALUE;
    int _5047 = NOVALUE;
    int _5044 = NOVALUE;
    int _5042 = NOVALUE;
    int _5040 = NOVALUE;
    int _5037 = NOVALUE;
    int _5035 = NOVALUE;
    int _5034 = NOVALUE;
    int _5033 = NOVALUE;
    int _5032 = NOVALUE;
    int _5031 = NOVALUE;
    int _5028 = NOVALUE;
    int _5025 = NOVALUE;
    int _5024 = NOVALUE;
    int _5023 = NOVALUE;
    int _5020 = NOVALUE;
    int _5018 = NOVALUE;
    int _5016 = NOVALUE;
    int _5013 = NOVALUE;
    int _5012 = NOVALUE;
    int _5005 = NOVALUE;
    int _5002 = NOVALUE;
    int _5001 = NOVALUE;
    int _4993 = NOVALUE;
    int _4988 = NOVALUE;
    int _4985 = NOVALUE;
    int _4975 = NOVALUE;
    int _4973 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _4973 = IS_ATOM(_arg_list_8939);
    if (_4973 == 0)
    {
        _4973 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _4973 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_8939;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_8939);
    *((int *)(_2+4)) = _arg_list_8939;
    _arg_list_8939 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_8940);
    _result_8940 = _5;

    /** 	in_token = 0*/
    _in_token_8941 = 0;

    /** 	i = 0*/
    _i_8943 = 0;

    /** 	tend = 0*/
    _tend_8944 = 0;

    /** 	argl = 0*/
    _argl_8957 = 0;

    /** 	spacer = 0*/
    _spacer_8951 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_8963);
    _prevargv_8963 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_8938)){
            _4975 = SEQ_PTR(_format_pattern_8938)->length;
    }
    else {
        _4975 = 1;
    }
    if (_i_8943 >= _4975)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_8943 = _i_8943 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_8938);
    _tch_8942 = (int)*(((s1_ptr)_2)->base + _i_8943);
    if (!IS_ATOM_INT(_tch_8942))
    _tch_8942 = (long)DBL_PTR(_tch_8942)->dbl;

    /**     	if not in_token then*/
    if (_in_token_8941 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_8942 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_8941 = 1;

    /**     			tend = 0*/
    _tend_8944 = 0;

    /** 				cap = 0*/
    _cap_8945 = 0;

    /** 				align = 0*/
    _align_8946 = 0;

    /** 				psign = 0*/
    _psign_8947 = 0;

    /** 				msign = 0*/
    _msign_8948 = 0;

    /** 				zfill = 0*/
    _zfill_8949 = 0;

    /** 				bwz = 0*/
    _bwz_8950 = 0;

    /** 				spacer = 0*/
    _spacer_8951 = 0;

    /** 				alt = 0*/
    _alt_8952 = 0;

    /**     			width = 0*/
    _width_8953 = 0;

    /**     			decs = -1*/
    _decs_8954 = -1;

    /**     			argn = 0*/
    _argn_8956 = 0;

    /**     			hexout = 0*/
    _hexout_8959 = 0;

    /**     			binout = 0*/
    _binout_8960 = 0;

    /**     			trimming = 0*/
    _trimming_8958 = 0;

    /**     			tsep = 0*/
    _tsep_8961 = 0;

    /**     			istext = 0*/
    _istext_8962 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_8965);
    _idname_8965 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_8967);
    _envvar_8967 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_8966);
    _envsym_8966 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_8940, _result_8940, _tch_8942);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_8942;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_8941 = 0;

        /**     				tend = i*/
        _tend_8944 = _i_8943;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_8940, _result_8940, _tch_8942);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _4985 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _4985 = 1;
        }
        if (_i_8943 >= _4985)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _4988 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _4988, 93)){
            _4988 = NOVALUE;
            goto L7; // [267] 248
        }
        _4988 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_8941 = 0;

        /** 	    					tend = 0*/
        _tend_8944 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_8945 = _tch_8942;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_8950 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_8951 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_8958 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_8949 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_8959 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_8960 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_8946 = _tch_8942;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_8947 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_8948 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_8952 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_8962 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _4993 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _4993 = 1;
        }
        if (_i_8943 >= _4993)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _tch_8942 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (!IS_ATOM_INT(_tch_8942))
        _tch_8942 = (long)DBL_PTR(_tch_8942)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_8955 = find_from(_tch_8942, _4997, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_8955 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_8943 = _i_8943 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_8953 == (short)_width_8953)
        _5001 = _width_8953 * 10;
        else
        _5001 = NewDouble(_width_8953 * (double)10);
        if (IS_ATOM_INT(_5001)) {
            _5002 = _5001 + _pos_8955;
            if ((long)((unsigned long)_5002 + (unsigned long)HIGH_BITS) >= 0) 
            _5002 = NewDouble((double)_5002);
        }
        else {
            _5002 = NewDouble(DBL_PTR(_5001)->dbl + (double)_pos_8955);
        }
        DeRef(_5001);
        _5001 = NOVALUE;
        if (IS_ATOM_INT(_5002)) {
            _width_8953 = _5002 - 1;
        }
        else {
            _width_8953 = NewDouble(DBL_PTR(_5002)->dbl - (double)1);
        }
        DeRef(_5002);
        _5002 = NOVALUE;
        if (!IS_ATOM_INT(_width_8953)) {
            _1 = (long)(DBL_PTR(_width_8953)->dbl);
            DeRefDS(_width_8953);
            _width_8953 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_8953 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_8949 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_8954 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _5005 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _5005 = 1;
        }
        if (_i_8943 >= _5005)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _tch_8942 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (!IS_ATOM_INT(_tch_8942))
        _tch_8942 = (long)DBL_PTR(_tch_8942)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_8955 = find_from(_tch_8942, _4997, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_8955 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_8943 = _i_8943 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_8954 == (short)_decs_8954)
        _5012 = _decs_8954 * 10;
        else
        _5012 = NewDouble(_decs_8954 * (double)10);
        if (IS_ATOM_INT(_5012)) {
            _5013 = _5012 + _pos_8955;
            if ((long)((unsigned long)_5013 + (unsigned long)HIGH_BITS) >= 0) 
            _5013 = NewDouble((double)_5013);
        }
        else {
            _5013 = NewDouble(DBL_PTR(_5012)->dbl + (double)_pos_8955);
        }
        DeRef(_5012);
        _5012 = NOVALUE;
        if (IS_ATOM_INT(_5013)) {
            _decs_8954 = _5013 - 1;
        }
        else {
            _decs_8954 = NewDouble(DBL_PTR(_5013)->dbl - (double)1);
        }
        DeRef(_5013);
        _5013 = NOVALUE;
        if (!IS_ATOM_INT(_decs_8954)) {
            _1 = (long)(DBL_PTR(_decs_8954)->dbl);
            DeRefDS(_decs_8954);
            _decs_8954 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_9041 = _i_8943 + 1;

        /** 	    			i = sp*/
        _i_8943 = _sp_9041;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _5016 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _5016 = 1;
        }
        if (_i_8943 >= _5016)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5018 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5018, 125)){
            _5018 = NOVALUE;
            goto LE; // [637] 646
        }
        _5018 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5020 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5020, 93)){
            _5020 = NOVALUE;
            goto LF; // [652] 661
        }
        _5020 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _5023 = _i_8943 - 1;
        rhs_slice_target = (object_ptr)&_5024;
        RHS_Slice(_format_pattern_8938, _sp_9041, _5023);
        RefDS(_3815);
        _5025 = _14trim(_5024, _3815, 0);
        _5024 = NOVALUE;
        if (IS_SEQUENCE(_5025) && IS_ATOM(61)) {
            Append(&_idname_8965, _5025, 61);
        }
        else if (IS_ATOM(_5025) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_8965, _5025, 61);
            DeRef(_5025);
            _5025 = NOVALUE;
        }
        DeRef(_5025);
        _5025 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5028 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5028, 93)){
            _5028 = NOVALUE;
            goto L10; // [699] 710
        }
        _5028 = NOVALUE;

        /**     					i -= 1*/
        _i_8943 = _i_8943 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_8939)){
                _5031 = SEQ_PTR(_arg_list_8939)->length;
        }
        else {
            _5031 = 1;
        }
        {
            int _j_9063;
            _j_9063 = 1;
L11: 
            if (_j_9063 > _5031){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_8939);
            _5032 = (int)*(((s1_ptr)_2)->base + _j_9063);
            _5033 = IS_SEQUENCE(_5032);
            _5032 = NOVALUE;
            if (_5033 == 0)
            {
                _5033 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _5033 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_8939);
            _5034 = (int)*(((s1_ptr)_2)->base + _j_9063);
            RefDS(_idname_8965);
            Ref(_5034);
            _5035 = _16begins(_idname_8965, _5034);
            _5034 = NOVALUE;
            if (_5035 == 0) {
                DeRef(_5035);
                _5035 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_5035) && DBL_PTR(_5035)->dbl == 0.0){
                    DeRef(_5035);
                    _5035 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_5035);
                _5035 = NOVALUE;
            }
            DeRef(_5035);
            _5035 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_8956 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_8956 = _j_9063;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_8939)){
                    _5037 = SEQ_PTR(_arg_list_8939)->length;
            }
            else {
                _5037 = 1;
            }
            if (_j_9063 != _5037)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_8965);
            _idname_8965 = _5;

            /**     						argn = -1*/
            _argn_8956 = -1;
L16: 

            /**     				end for*/
            _j_9063 = _j_9063 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_9077 = _i_8943 + 1;

        /** 	    			i = sp*/
        _i_8943 = _sp_9077;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _5040 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _5040 = 1;
        }
        if (_i_8943 >= _5040)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5042 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5042, 37)){
            _5042 = NOVALUE;
            goto L19; // [836] 845
        }
        _5042 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5044 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5044, 93)){
            _5044 = NOVALUE;
            goto L1A; // [851] 860
        }
        _5044 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _5047 = _i_8943 - 1;
        rhs_slice_target = (object_ptr)&_5048;
        RHS_Slice(_format_pattern_8938, _sp_9077, _5047);
        RefDS(_3815);
        _0 = _envsym_8966;
        _envsym_8966 = _14trim(_5048, _3815, 0);
        DeRef(_0);
        _5048 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _5050 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (binary_op_a(NOTEQ, _5050, 93)){
            _5050 = NOVALUE;
            goto L1B; // [894] 905
        }
        _5050 = NOVALUE;

        /**     					i -= 1*/
        _i_8943 = _i_8943 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_8967);
        _envvar_8967 = EGetEnv(_envsym_8966);

        /**     				argn = -1*/
        _argn_8956 = -1;

        /**     				if atom(envvar) then*/
        _5054 = IS_ATOM(_envvar_8967);
        if (_5054 == 0)
        {
            _5054 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _5054 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_8967);
        _envvar_8967 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_8956 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_8943 = _i_8943 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_8938)){
                _5057 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _5057 = 1;
        }
        if (_i_8943 >= _5057)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_8943 = _i_8943 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _tch_8942 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (!IS_ATOM_INT(_tch_8942))
        _tch_8942 = (long)DBL_PTR(_tch_8942)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_8955 = find_from(_tch_8942, _4997, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_8955 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_8943 = _i_8943 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_8956 == (short)_argn_8956)
        _5064 = _argn_8956 * 10;
        else
        _5064 = NewDouble(_argn_8956 * (double)10);
        if (IS_ATOM_INT(_5064)) {
            _5065 = _5064 + _pos_8955;
            if ((long)((unsigned long)_5065 + (unsigned long)HIGH_BITS) >= 0) 
            _5065 = NewDouble((double)_5065);
        }
        else {
            _5065 = NewDouble(DBL_PTR(_5064)->dbl + (double)_pos_8955);
        }
        DeRef(_5064);
        _5064 = NOVALUE;
        if (IS_ATOM_INT(_5065)) {
            _argn_8956 = _5065 - 1;
        }
        else {
            _argn_8956 = NewDouble(DBL_PTR(_5065)->dbl - (double)1);
        }
        DeRef(_5065);
        _5065 = NOVALUE;
        if (!IS_ATOM_INT(_argn_8956)) {
            _1 = (long)(DBL_PTR(_argn_8956)->dbl);
            DeRefDS(_argn_8956);
            _argn_8956 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_8938)){
                _5067 = SEQ_PTR(_format_pattern_8938)->length;
        }
        else {
            _5067 = 1;
        }
        if (_i_8943 >= _5067)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_8943 = _i_8943 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_8938);
        _tsep_8961 = (int)*(((s1_ptr)_2)->base + _i_8943);
        if (!IS_ATOM_INT(_tsep_8961))
        _tsep_8961 = (long)DBL_PTR(_tsep_8961)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_8944 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9124);
    _argtext_9124 = _5;

    /**     			if argn = 0 then*/
    if (_argn_8956 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_8956 = _argl_8957 + 1;
L20: 

    /**     			argl = argn*/
    _argl_8957 = _argn_8956;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _5074 = (_argn_8956 < 1);
    if (_5074 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_8939)){
            _5076 = SEQ_PTR(_arg_list_8939)->length;
    }
    else {
        _5076 = 1;
    }
    _5077 = (_argn_8956 > _5076);
    _5076 = NOVALUE;
    if (_5077 == 0)
    {
        DeRef(_5077);
        _5077 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_5077);
        _5077 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_8967)){
            _5078 = SEQ_PTR(_envvar_8967)->length;
    }
    else {
        _5078 = 1;
    }
    if (_5078 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_8967);
    DeRef(_argtext_9124);
    _argtext_9124 = _envvar_8967;

    /** 	    				currargv = envvar*/
    Ref(_envvar_8967);
    DeRef(_currargv_8964);
    _currargv_8964 = _envvar_8967;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_9124);
    _argtext_9124 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_8964);
    _currargv_8964 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5080 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    Ref(_5080);
    _5081 = _13string(_5080);
    _5080 = NOVALUE;
    if (_5081 == 0) {
        DeRef(_5081);
        _5081 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_5081) && DBL_PTR(_5081)->dbl == 0.0){
            DeRef(_5081);
            _5081 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_5081);
        _5081 = NOVALUE;
    }
    DeRef(_5081);
    _5081 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_8965)){
            _5082 = SEQ_PTR(_idname_8965)->length;
    }
    else {
        _5082 = 1;
    }
    if (_5082 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5084 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (IS_SEQUENCE(_idname_8965)){
            _5085 = SEQ_PTR(_idname_8965)->length;
    }
    else {
        _5085 = 1;
    }
    _5086 = _5085 + 1;
    _5085 = NOVALUE;
    if (IS_SEQUENCE(_5084)){
            _5087 = SEQ_PTR(_5084)->length;
    }
    else {
        _5087 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_5084, _5086, _5087);
    _5084 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_9124);
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _argtext_9124 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    Ref(_argtext_9124);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5090 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (IS_ATOM_INT(_5090))
    _5091 = 1;
    else if (IS_ATOM_DBL(_5090))
    _5091 = IS_ATOM_INT(DoubleToInt(_5090));
    else
    _5091 = 0;
    _5090 = NOVALUE;
    if (_5091 == 0)
    {
        _5091 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _5091 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_8962 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5092 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    Ref(_5092);
    _5093 = _20abs(_5092);
    _5092 = NOVALUE;
    _5094 = binary_op(AND_BITS, _1495, _5093);
    DeRef(_5093);
    _5093 = NOVALUE;
    _0 = _argtext_9124;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5094;
    _argtext_9124 = MAKE_SEQ(_1);
    DeRef(_0);
    _5094 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _5096 = (_bwz_8950 != 0);
    if (_5096 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5098 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (IS_ATOM_INT(_5098)) {
        _5099 = (_5098 == 0);
    }
    else {
        _5099 = binary_op(EQUALS, _5098, 0);
    }
    _5098 = NOVALUE;
    if (_5099 == 0) {
        DeRef(_5099);
        _5099 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_5099) && DBL_PTR(_5099)->dbl == 0.0){
            DeRef(_5099);
            _5099 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_5099);
        _5099 = NOVALUE;
    }
    DeRef(_5099);
    _5099 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_9124);
    _argtext_9124 = Repeat(32, _width_8953);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_8960 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5102 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    Ref(_5102);
    _5103 = _15int_to_bits(_5102, 32);
    _5102 = NOVALUE;
    _5104 = _23reverse(_5103, 1, 0);
    _5103 = NOVALUE;
    DeRef(_argtext_9124);
    if (IS_ATOM_INT(_5104)) {
        _argtext_9124 = _5104 + 48;
        if ((long)((unsigned long)_argtext_9124 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_9124 = NewDouble((double)_argtext_9124);
    }
    else {
        _argtext_9124 = binary_op(PLUS, _5104, 48);
    }
    DeRef(_5104);
    _5104 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5106 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5106 = 1;
    }
    {
        int _ib_9173;
        _ib_9173 = 1;
L2C: 
        if (_ib_9173 > _5106){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_9124);
        _5107 = (int)*(((s1_ptr)_2)->base + _ib_9173);
        if (binary_op_a(NOTEQ, _5107, 49)){
            _5107 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _5107 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_9124)){
                _5109 = SEQ_PTR(_argtext_9124)->length;
        }
        else {
            _5109 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_9124;
        RHS_Slice(_argtext_9124, _ib_9173, _5109);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_9173 = _ib_9173 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_8959 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5112 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_argtext_9124);
    _argtext_9124 = EPrintf(-9999999, _915, _5112);
    _5112 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5114 = (_zfill_8949 != 0);
    if (_5114 == 0) {
        goto L30; // [1408] 1505
    }
    _5116 = (_width_8953 > 0);
    if (_5116 == 0)
    {
        DeRef(_5116);
        _5116 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_5116);
        _5116 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5117 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5117, 45)){
        _5117 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _5117 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5119 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5119 = 1;
    }
    if (_width_8953 <= _5119)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5121 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5121 = 1;
    }
    _5122 = _width_8953 - _5121;
    _5121 = NOVALUE;
    _5123 = Repeat(48, _5122);
    _5122 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9124)){
            _5124 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5124 = 1;
    }
    rhs_slice_target = (object_ptr)&_5125;
    RHS_Slice(_argtext_9124, 2, _5124);
    {
        int concat_list[3];

        concat_list[0] = _5125;
        concat_list[1] = _5123;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5125);
    _5125 = NOVALUE;
    DeRefDS(_5123);
    _5123 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5127 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5127 = 1;
    }
    if (_width_8953 <= _5127)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5129 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5129 = 1;
    }
    _5130 = _width_8953 - _5129;
    _5129 = NOVALUE;
    _5131 = Repeat(48, _5130);
    _5130 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _5131, _argtext_9124);
    DeRefDS(_5131);
    _5131 = NOVALUE;
    DeRef(_5131);
    _5131 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5133 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (binary_op_a(LESSEQ, _5133, 0)){
        _5133 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _5133 = NOVALUE;

    /** 								if psign then*/
    if (_psign_8947 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_8949 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_9124, _argtext_9124, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5137 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5137, 48)){
        _5137 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _5137 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9124 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5139 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (binary_op_a(GREATEREQ, _5139, 0)){
        _5139 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _5139 = NOVALUE;

    /** 								if msign then*/
    if (_msign_8948 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_8949 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5142 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5142 = 1;
    }
    rhs_slice_target = (object_ptr)&_5143;
    RHS_Slice(_argtext_9124, 2, _5142);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5143;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5143);
    _5143 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5146 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5146, 48)){
        _5146 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _5146 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5148 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5148 = 1;
    }
    rhs_slice_target = (object_ptr)&_5149;
    RHS_Slice(_argtext_9124, 3, _5148);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5149;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5149);
    _5149 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5151 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5151 = 1;
    }
    rhs_slice_target = (object_ptr)&_5152;
    RHS_Slice(_argtext_9124, 2, _5151);
    Append(&_argtext_9124, _5152, 41);
    DeRefDS(_5152);
    _5152 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5155 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_argtext_9124);
    _argtext_9124 = EPrintf(-9999999, _5154, _5155);
    _5155 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _5157 = (_zfill_8949 != 0);
    if (_5157 == 0) {
        goto L27; // [1670] 2546
    }
    _5159 = (_width_8953 > 0);
    if (_5159 == 0)
    {
        DeRef(_5159);
        _5159 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_5159);
        _5159 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5160 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5160 = 1;
    }
    if (_width_8953 <= _5160)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5162 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5162 = 1;
    }
    _5163 = _width_8953 - _5162;
    _5162 = NOVALUE;
    _5164 = Repeat(48, _5163);
    _5163 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _5164, _argtext_9124);
    DeRefDS(_5164);
    _5164 = NOVALUE;
    DeRef(_5164);
    _5164 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5166 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    _5167 = IS_ATOM(_5166);
    _5166 = NOVALUE;
    if (_5167 == 0)
    {
        _5167 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _5167 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_8962 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5168 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (IS_ATOM_INT(_5168))
    _5169 = e_floor(_5168);
    else
    _5169 = unary_op(FLOOR, _5168);
    _5168 = NOVALUE;
    _5170 = _20abs(_5169);
    _5169 = NOVALUE;
    _5171 = binary_op(AND_BITS, _1495, _5170);
    DeRef(_5170);
    _5170 = NOVALUE;
    _0 = _argtext_9124;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5171;
    _argtext_9124 = MAKE_SEQ(_1);
    DeRef(_0);
    _5171 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_8959 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5173 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_argtext_9124);
    _argtext_9124 = EPrintf(-9999999, _5154, _5173);
    _5173 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _5175 = (_zfill_8949 != 0);
    if (_5175 == 0) {
        goto L27; // [1786] 2546
    }
    _5177 = (_width_8953 > 0);
    if (_5177 == 0)
    {
        DeRef(_5177);
        _5177 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_5177);
        _5177 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5178 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5178 = 1;
    }
    if (_width_8953 <= _5178)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5180 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5180 = 1;
    }
    _5181 = _width_8953 - _5180;
    _5180 = NOVALUE;
    _5182 = Repeat(48, _5181);
    _5181 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _5182, _argtext_9124);
    DeRefDS(_5182);
    _5182 = NOVALUE;
    DeRef(_5182);
    _5182 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5185 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    _5186 = EPrintf(-9999999, _5184, _5185);
    _5185 = NOVALUE;
    RefDS(_3815);
    _0 = _argtext_9124;
    _argtext_9124 = _14trim(_5186, _3815, 0);
    DeRef(_0);
    _5186 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_8968 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _5189 = _ep_8968 + 2;
    if ((long)((unsigned long)_5189 + (unsigned long)HIGH_BITS) >= 0) 
    _5189 = NewDouble((double)_5189);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5189)) ? _5189 : (long)(DBL_PTR(_5189)->dbl);
        int stop = (IS_ATOM_INT(_5189)) ? _5189 : (long)(DBL_PTR(_5189)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9124), start, &_argtext_9124 );
            }
            else Tail(SEQ_PTR(_argtext_9124), stop+1, &_argtext_9124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9124), start, &_argtext_9124);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9124 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9124)->ref == 1));
        }
    }
    DeRef(_5189);
    _5189 = NOVALUE;
    _5189 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_8968 = e_match_from(_5191, _argtext_9124, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _5193 = (_zfill_8949 != 0);
    if (_5193 == 0) {
        goto L3E; // [1896] 1981
    }
    _5195 = (_width_8953 > 0);
    if (_5195 == 0)
    {
        DeRef(_5195);
        _5195 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_5195);
        _5195 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5196 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5196 = 1;
    }
    if (_width_8953 <= _5196)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5198 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5198, 45)){
        _5198 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _5198 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5200 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5200 = 1;
    }
    _5201 = _width_8953 - _5200;
    _5200 = NOVALUE;
    _5202 = Repeat(48, _5201);
    _5201 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9124)){
            _5203 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5203 = 1;
    }
    rhs_slice_target = (object_ptr)&_5204;
    RHS_Slice(_argtext_9124, 2, _5203);
    {
        int concat_list[3];

        concat_list[0] = _5204;
        concat_list[1] = _5202;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5204);
    _5204 = NOVALUE;
    DeRefDS(_5202);
    _5202 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5206 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5206 = 1;
    }
    _5207 = _width_8953 - _5206;
    _5206 = NOVALUE;
    _5208 = Repeat(48, _5207);
    _5207 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _5208, _argtext_9124);
    DeRefDS(_5208);
    _5208 = NOVALUE;
    DeRef(_5208);
    _5208 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5210 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (binary_op_a(LESSEQ, _5210, 0)){
        _5210 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _5210 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_8947 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_8949 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_9124, _argtext_9124, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5214 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5214, 48)){
        _5214 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _5214 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9124 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5216 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (binary_op_a(GREATEREQ, _5216, 0)){
        _5216 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _5216 = NOVALUE;

    /** 									if msign then*/
    if (_msign_8948 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_8949 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5219 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5219 = 1;
    }
    rhs_slice_target = (object_ptr)&_5220;
    RHS_Slice(_argtext_9124, 2, _5219);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5220;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5220);
    _5220 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5222 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _5222, 48)){
        _5222 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _5222 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5224 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5224 = 1;
    }
    rhs_slice_target = (object_ptr)&_5225;
    RHS_Slice(_argtext_9124, 3, _5224);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _5225;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5225);
    _5225 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5227 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5227 = 1;
    }
    rhs_slice_target = (object_ptr)&_5228;
    RHS_Slice(_argtext_9124, 2, _5227);
    Append(&_argtext_9124, _5228, 41);
    DeRefDS(_5228);
    _5228 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _5230 = (_alt_8952 != 0);
    if (_5230 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5232 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    if (IS_SEQUENCE(_5232)){
            _5233 = SEQ_PTR(_5232)->length;
    }
    else {
        _5233 = 1;
    }
    _5232 = NOVALUE;
    _5234 = (_5233 == 2);
    _5233 = NOVALUE;
    if (_5234 == 0)
    {
        DeRef(_5234);
        _5234 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_5234);
        _5234 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _5235 = IS_ATOM(_prevargv_8963);
    if (_5235 == 0)
    {
        _5235 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _5235 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_8963, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5237 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_tempv_9347);
    _2 = (int)SEQ_PTR(_5237);
    _tempv_9347 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9347);
    _5237 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5239 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_tempv_9347);
    _2 = (int)SEQ_PTR(_5239);
    _tempv_9347 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9347);
    _5239 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_8963)){
            _5241 = SEQ_PTR(_prevargv_8963)->length;
    }
    else {
        _5241 = 1;
    }
    if (_5241 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5243 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_tempv_9347);
    _2 = (int)SEQ_PTR(_5243);
    _tempv_9347 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_9347);
    _5243 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5245 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    DeRef(_tempv_9347);
    _2 = (int)SEQ_PTR(_5245);
    _tempv_9347 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_9347);
    _5245 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_9347);
    _5247 = _13string(_tempv_9347);
    if (_5247 == 0) {
        DeRef(_5247);
        _5247 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_5247) && DBL_PTR(_5247)->dbl == 0.0){
            DeRef(_5247);
            _5247 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_5247);
        _5247 = NOVALUE;
    }
    DeRef(_5247);
    _5247 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_9347);
    DeRef(_argtext_9124);
    _argtext_9124 = _tempv_9347;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_9347))
    _5248 = 1;
    else if (IS_ATOM_DBL(_tempv_9347))
    _5248 = IS_ATOM_INT(DoubleToInt(_tempv_9347));
    else
    _5248 = 0;
    if (_5248 == 0)
    {
        _5248 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _5248 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_8962 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_9347);
    _5249 = _20abs(_tempv_9347);
    _5250 = binary_op(AND_BITS, _1495, _5249);
    DeRef(_5249);
    _5249 = NOVALUE;
    _0 = _argtext_9124;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5250;
    _argtext_9124 = MAKE_SEQ(_1);
    DeRef(_0);
    _5250 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5252 = (_bwz_8950 != 0);
    if (_5252 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_9347)) {
        _5254 = (_tempv_9347 == 0);
    }
    else {
        _5254 = binary_op(EQUALS, _tempv_9347, 0);
    }
    if (_5254 == 0) {
        DeRef(_5254);
        _5254 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_5254) && DBL_PTR(_5254)->dbl == 0.0){
            DeRef(_5254);
            _5254 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_5254);
        _5254 = NOVALUE;
    }
    DeRef(_5254);
    _5254 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_9124);
    _argtext_9124 = Repeat(32, _width_8953);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_9124);
    _argtext_9124 = EPrintf(-9999999, _915, _tempv_9347);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _5257 = IS_ATOM(_tempv_9347);
    if (_5257 == 0)
    {
        _5257 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _5257 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_8962 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_9347))
    _5258 = e_floor(_tempv_9347);
    else
    _5258 = unary_op(FLOOR, _tempv_9347);
    _5259 = _20abs(_5258);
    _5258 = NOVALUE;
    _5260 = binary_op(AND_BITS, _1495, _5259);
    DeRef(_5259);
    _5259 = NOVALUE;
    _0 = _argtext_9124;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5260;
    _argtext_9124 = MAKE_SEQ(_1);
    DeRef(_0);
    _5260 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _5262 = (_bwz_8950 != 0);
    if (_5262 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_9347)) {
        _5264 = (_tempv_9347 == 0);
    }
    else {
        _5264 = binary_op(EQUALS, _tempv_9347, 0);
    }
    if (_5264 == 0) {
        DeRef(_5264);
        _5264 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_5264) && DBL_PTR(_5264)->dbl == 0.0){
            DeRef(_5264);
            _5264 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_5264);
        _5264 = NOVALUE;
    }
    DeRef(_5264);
    _5264 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_9124);
    _argtext_9124 = Repeat(32, _width_8953);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _5266 = EPrintf(-9999999, _5184, _tempv_9347);
    RefDS(_3815);
    _0 = _argtext_9124;
    _argtext_9124 = _14trim(_5266, _3815, 0);
    DeRef(_0);
    _5266 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_915);
    *((int *)(_2+20)) = _915;
    RefDS(_5268);
    *((int *)(_2+24)) = _5268;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5269 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_9401);
    _options_inlined_pretty_sprint_at_2424_9401 = _5269;
    _5269 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_7442 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_9347);
    RefDS(_options_inlined_pretty_sprint_at_2424_9401);
    _26pretty(_tempv_9347, _options_inlined_pretty_sprint_at_2424_9401);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_7445);
    DeRef(_argtext_9124);
    _argtext_9124 = _26pretty_line_7445;
    DeRef(_options_inlined_pretty_sprint_at_2424_9401);
    _options_inlined_pretty_sprint_at_2424_9401 = NOVALUE;
L4D: 
    DeRef(_tempv_9347);
    _tempv_9347 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _5270 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_915);
    *((int *)(_2+20)) = _915;
    RefDS(_5268);
    *((int *)(_2+24)) = _5268;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _5271 = MAKE_SEQ(_1);
    Ref(_5270);
    DeRef(_x_inlined_pretty_sprint_at_2477_9407);
    _x_inlined_pretty_sprint_at_2477_9407 = _5270;
    _5270 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_9408);
    _options_inlined_pretty_sprint_at_2480_9408 = _5271;
    _5271 = NOVALUE;

    /** 	pretty_printing = 0*/
    _26pretty_printing_7442 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_9407);
    RefDS(_options_inlined_pretty_sprint_at_2480_9408);
    _26pretty(_x_inlined_pretty_sprint_at_2477_9407, _options_inlined_pretty_sprint_at_2480_9408);

    /** 	return pretty_line*/
    RefDS(_26pretty_line_7445);
    DeRef(_argtext_9124);
    _argtext_9124 = _26pretty_line_7445;
    DeRef(_x_inlined_pretty_sprint_at_2477_9407);
    _x_inlined_pretty_sprint_at_2477_9407 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_9408);
    _options_inlined_pretty_sprint_at_2480_9408 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_8968 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _5273 = _ep_8968 + 2;
    if ((long)((unsigned long)_5273 + (unsigned long)HIGH_BITS) >= 0) 
    _5273 = NewDouble((double)_5273);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_9124);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_5273)) ? _5273 : (long)(DBL_PTR(_5273)->dbl);
        int stop = (IS_ATOM_INT(_5273)) ? _5273 : (long)(DBL_PTR(_5273)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_9124), start, &_argtext_9124 );
            }
            else Tail(SEQ_PTR(_argtext_9124), stop+1, &_argtext_9124);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_9124), start, &_argtext_9124);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_9124 = Remove_elements(start, stop, (SEQ_PTR(_argtext_9124)->ref == 1));
        }
    }
    DeRef(_5273);
    _5273 = NOVALUE;
    _5273 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_8968 = e_match_from(_5191, _argtext_9124, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_8964);
    _2 = (int)SEQ_PTR(_arg_list_8939);
    _currargv_8964 = (int)*(((s1_ptr)_2)->base + _argn_8956);
    Ref(_currargv_8964);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5277 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5277 = 1;
    }
    if (_5277 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_8945;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_9124);
        _0 = _argtext_9124;
        _argtext_9124 = _14upper(_argtext_9124);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_9124);
        _0 = _argtext_9124;
        _argtext_9124 = _14lower(_argtext_9124);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_9124);
        _0 = _argtext_9124;
        _argtext_9124 = _14proper(_argtext_9124);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_8945 = _cap_8945;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_9431);
        _msg_inlined_crash_at_2631_9431 = EPrintf(-9999999, _5284, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_9431);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_9431);
        _msg_inlined_crash_at_2631_9431 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _5285 = IS_ATOM(_currargv_8964);
    if (_5285 == 0)
    {
        _5285 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _5285 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _5286 = find_from(101, _argtext_9124, 1);
    if (_5286 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_8954 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_8955 = find_from(46, _argtext_9124, 1);

    /** 								if pos then*/
    if (_pos_8955 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_8954 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _5291 = _pos_8955 - 1;
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, 1, _5291);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5293 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5293 = 1;
    }
    _pos_8955 = _5293 - _pos_8955;
    _5293 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_8955 <= _decs_8954)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5296 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5296 = 1;
    }
    _5297 = _5296 - _pos_8955;
    if ((long)((unsigned long)_5297 +(unsigned long) HIGH_BITS) >= 0){
        _5297 = NewDouble((double)_5297);
    }
    _5296 = NOVALUE;
    if (IS_ATOM_INT(_5297)) {
        _5298 = _5297 + _decs_8954;
    }
    else {
        _5298 = NewDouble(DBL_PTR(_5297)->dbl + (double)_decs_8954);
    }
    DeRef(_5297);
    _5297 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, 1, _5298);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_8955 >= _decs_8954)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _5301 = _decs_8954 - _pos_8955;
    _5302 = Repeat(48, _5301);
    _5301 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _argtext_9124, _5302);
    DeRefDS(_5302);
    _5302 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_8954 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _5305 = Repeat(48, _decs_8954);
    {
        int concat_list[3];

        concat_list[0] = _5305;
        concat_list[1] = 46;
        concat_list[2] = _argtext_9124;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5305);
    _5305 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_8946 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _5308 = IS_ATOM(_currargv_8964);
    if (_5308 == 0)
    {
        _5308 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _5308 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_8946 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_8946 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _5309 = IS_ATOM(_currargv_8964);
    if (_5309 == 0)
    {
        _5309 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _5309 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _5310 = (_tsep_8961 != 0);
    if (_5310 == 0) {
        goto L66; // [2842] 3029
    }
    _5312 = (_zfill_8949 == 0);
    if (_5312 == 0)
    {
        DeRef(_5312);
        _5312 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_5312);
        _5312 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_8960 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_8959 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_9475 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_9475 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    _5314 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5314)) {
        _bracketed_9476 = (_5314 == 40);
    }
    else {
        _bracketed_9476 = binary_op(EQUALS, _5314, 40);
    }
    _5314 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_9476)) {
        _1 = (long)(DBL_PTR(_bracketed_9476)->dbl);
        DeRefDS(_bracketed_9476);
        _bracketed_9476 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_9476 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5316 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5316 = 1;
    }
    _5317 = _5316 - 1;
    _5316 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, 2, _5317);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_9474 = find_from(46, _argtext_9124, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_9474 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5321 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5321 = 1;
    }
    _dpos_9474 = _5321 + 1;
    _5321 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_8961 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_9124);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_9124 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_9474);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_9474 <= _dist_9475)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_9474 = _dpos_9474 - _dist_9475;

    /** 	    						if dpos > 1 then*/
    if (_dpos_9474 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _5327 = _dpos_9474 - 1;
    rhs_slice_target = (object_ptr)&_5328;
    RHS_Slice(_argtext_9124, 1, _5327);
    if (IS_SEQUENCE(_argtext_9124)){
            _5329 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5329 = 1;
    }
    rhs_slice_target = (object_ptr)&_5330;
    RHS_Slice(_argtext_9124, _dpos_9474, _5329);
    {
        int concat_list[3];

        concat_list[0] = _5330;
        concat_list[1] = _tsep_8961;
        concat_list[2] = _5328;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5330);
    _5330 = NOVALUE;
    DeRefDS(_5328);
    _5328 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_9476 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_9124;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_8953 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_9124)){
            _width_8953 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _width_8953 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5335 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5335 = 1;
    }
    if (_width_8953 >= _5335)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_8946 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5338 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5338 = 1;
    }
    _5339 = _5338 - _width_8953;
    if ((long)((unsigned long)_5339 +(unsigned long) HIGH_BITS) >= 0){
        _5339 = NewDouble((double)_5339);
    }
    _5338 = NOVALUE;
    if (IS_ATOM_INT(_5339)) {
        _5340 = _5339 + 1;
        if (_5340 > MAXINT){
            _5340 = NewDouble((double)_5340);
        }
    }
    else
    _5340 = binary_op(PLUS, 1, _5339);
    DeRef(_5339);
    _5339 = NOVALUE;
    if (IS_SEQUENCE(_argtext_9124)){
            _5341 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5341 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, _5340, _5341);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_8946 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5344 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5344 = 1;
    }
    _pos_8955 = _5344 - _width_8953;
    _5344 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5346 = (_pos_8955 % 2);
    if (_5346 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_8955 & 1) {
        _pos_8955 = NewDouble((_pos_8955 >> 1) + 0.5);
    }
    else
    _pos_8955 = _pos_8955 >> 1;
    if (!IS_ATOM_INT(_pos_8955)) {
        _1 = (long)(DBL_PTR(_pos_8955)->dbl);
        DeRefDS(_pos_8955);
        _pos_8955 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _5349 = _pos_8955 + 1;
    if (_5349 > MAXINT){
        _5349 = NewDouble((double)_5349);
    }
    if (IS_SEQUENCE(_argtext_9124)){
            _5350 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5350 = 1;
    }
    _5351 = _5350 - _pos_8955;
    _5350 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, _5349, _5351);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_8955 = _pos_8955 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _5354 = _pos_8955 + 1;
    if (_5354 > MAXINT){
        _5354 = NewDouble((double)_5354);
    }
    if (IS_SEQUENCE(_argtext_9124)){
            _5355 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5355 = 1;
    }
    _5356 = _5355 - _pos_8955;
    if ((long)((unsigned long)_5356 +(unsigned long) HIGH_BITS) >= 0){
        _5356 = NewDouble((double)_5356);
    }
    _5355 = NOVALUE;
    if (IS_ATOM_INT(_5356)) {
        _5357 = _5356 - 1;
    }
    else {
        _5357 = NewDouble(DBL_PTR(_5356)->dbl - (double)1);
    }
    DeRef(_5356);
    _5356 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, _5354, _5357);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_9124;
    RHS_Slice(_argtext_9124, 1, _width_8953);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5360 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5360 = 1;
    }
    if (_width_8953 <= _5360)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_8946 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5363 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5363 = 1;
    }
    _5364 = _width_8953 - _5363;
    _5363 = NOVALUE;
    _5365 = Repeat(32, _5364);
    _5364 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _5365, _argtext_9124);
    DeRefDS(_5365);
    _5365 = NOVALUE;
    DeRef(_5365);
    _5365 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_8946 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5368 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5368 = 1;
    }
    _pos_8955 = _width_8953 - _5368;
    _5368 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _5370 = (_pos_8955 % 2);
    if (_5370 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_8955 & 1) {
        _pos_8955 = NewDouble((_pos_8955 >> 1) + 0.5);
    }
    else
    _pos_8955 = _pos_8955 >> 1;
    if (!IS_ATOM_INT(_pos_8955)) {
        _1 = (long)(DBL_PTR(_pos_8955)->dbl);
        DeRefDS(_pos_8955);
        _pos_8955 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _5373 = Repeat(32, _pos_8955);
    _5374 = Repeat(32, _pos_8955);
    {
        int concat_list[3];

        concat_list[0] = _5374;
        concat_list[1] = _argtext_9124;
        concat_list[2] = _5373;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5374);
    _5374 = NOVALUE;
    DeRefDS(_5373);
    _5373 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_8955 = _pos_8955 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _5377 = Repeat(32, _pos_8955);
    _5378 = _pos_8955 + 1;
    _5379 = Repeat(32, _5378);
    _5378 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _5379;
        concat_list[1] = _argtext_9124;
        concat_list[2] = _5377;
        Concat_N((object_ptr)&_argtext_9124, concat_list, 3);
    }
    DeRefDS(_5379);
    _5379 = NOVALUE;
    DeRefDS(_5377);
    _5377 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_9124)){
            _5381 = SEQ_PTR(_argtext_9124)->length;
    }
    else {
        _5381 = 1;
    }
    _5382 = _width_8953 - _5381;
    _5381 = NOVALUE;
    _5383 = Repeat(32, _5382);
    _5382 = NOVALUE;
    Concat((object_ptr)&_argtext_9124, _argtext_9124, _5383);
    DeRefDS(_5383);
    _5383 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_8940, _result_8940, _argtext_9124);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_8951 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_8940, _result_8940, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_8958 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_8940);
    RefDS(_3815);
    _0 = _result_8940;
    _result_8940 = _14trim(_result_8940, _3815, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_8944 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_8964);
    DeRef(_prevargv_8963);
    _prevargv_8963 = _currargv_8964;
L1F: 
    DeRef(_argtext_9124);
    _argtext_9124 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_8938);
    DeRef(_arg_list_8939);
    DeRef(_prevargv_8963);
    DeRef(_currargv_8964);
    DeRef(_idname_8965);
    DeRef(_envsym_8966);
    DeRefi(_envvar_8967);
    DeRef(_5096);
    _5096 = NOVALUE;
    DeRef(_5354);
    _5354 = NOVALUE;
    DeRef(_5340);
    _5340 = NOVALUE;
    DeRef(_5298);
    _5298 = NOVALUE;
    DeRef(_5291);
    _5291 = NOVALUE;
    DeRef(_5074);
    _5074 = NOVALUE;
    DeRef(_5193);
    _5193 = NOVALUE;
    DeRef(_5317);
    _5317 = NOVALUE;
    DeRef(_5157);
    _5157 = NOVALUE;
    DeRef(_5230);
    _5230 = NOVALUE;
    DeRef(_5310);
    _5310 = NOVALUE;
    DeRef(_5357);
    _5357 = NOVALUE;
    DeRef(_5023);
    _5023 = NOVALUE;
    DeRef(_5086);
    _5086 = NOVALUE;
    DeRef(_5346);
    _5346 = NOVALUE;
    DeRef(_5370);
    _5370 = NOVALUE;
    DeRef(_5351);
    _5351 = NOVALUE;
    DeRef(_5114);
    _5114 = NOVALUE;
    _5232 = NOVALUE;
    DeRef(_5262);
    _5262 = NOVALUE;
    DeRef(_5252);
    _5252 = NOVALUE;
    DeRef(_5327);
    _5327 = NOVALUE;
    DeRef(_5047);
    _5047 = NOVALUE;
    DeRef(_5349);
    _5349 = NOVALUE;
    DeRef(_5175);
    _5175 = NOVALUE;
    return _result_8940;
    ;
}



// 0x9BCBA5EA
