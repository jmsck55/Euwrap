// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _17find_first_wildcard(int _name_5892, int _from_5893)
{
    int _asterisk_at_5894 = NOVALUE;
    int _question_at_5896 = NOVALUE;
    int _first_wildcard_at_5898 = NOVALUE;
    int _3086 = NOVALUE;
    int _3085 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_5894 = find_from(42, _name_5892, _from_5893);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_5896 = find_from(63, _name_5892, _from_5893);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_5898 = _asterisk_at_5894;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_5894 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_5896 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_5896 == 0) {
        goto L3; // [37] 55
    }
    _3086 = (_question_at_5896 < _asterisk_at_5894);
    if (_3086 == 0)
    {
        DeRef(_3086);
        _3086 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_3086);
        _3086 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_5898 = _question_at_5896;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_5892);
    return _first_wildcard_at_5898;
    ;
}


int _17dir(int _name_5906)
{
    int _dir_data_5907 = NOVALUE;
    int _data_5908 = NOVALUE;
    int _the_name_5909 = NOVALUE;
    int _the_dir_5910 = NOVALUE;
    int _the_suffix_5911 = NOVALUE;
    int _idx_5912 = NOVALUE;
    int _first_wildcard_at_5913 = NOVALUE;
    int _next_slash_5928 = NOVALUE;
    int _wild_data_5960 = NOVALUE;
    int _interim_dir_5964 = NOVALUE;
    int _dir_results_5968 = NOVALUE;
    int _3129 = NOVALUE;
    int _3128 = NOVALUE;
    int _3127 = NOVALUE;
    int _3125 = NOVALUE;
    int _3124 = NOVALUE;
    int _3123 = NOVALUE;
    int _3121 = NOVALUE;
    int _3119 = NOVALUE;
    int _3118 = NOVALUE;
    int _3117 = NOVALUE;
    int _3116 = NOVALUE;
    int _3114 = NOVALUE;
    int _3112 = NOVALUE;
    int _3111 = NOVALUE;
    int _3110 = NOVALUE;
    int _3109 = NOVALUE;
    int _3108 = NOVALUE;
    int _3107 = NOVALUE;
    int _3104 = NOVALUE;
    int _3103 = NOVALUE;
    int _3101 = NOVALUE;
    int _3099 = NOVALUE;
    int _3098 = NOVALUE;
    int _3091 = NOVALUE;
    int _3089 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	ifdef WINDOWS then*/

    /** 		object dir_data, data, the_name, the_dir, the_suffix = 0*/
    DeRef(_the_suffix_5911);
    _the_suffix_5911 = 0;

    /** 		integer idx*/

    /** 		integer first_wildcard_at = find_first_wildcard( name )*/
    RefDS(_name_5906);
    _first_wildcard_at_5913 = _17find_first_wildcard(_name_5906, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_5913)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_5913)->dbl);
        DeRefDS(_first_wildcard_at_5913);
        _first_wildcard_at_5913 = _1;
    }

    /** 		if first_wildcard_at = 0 then*/
    if (_first_wildcard_at_5913 != 0)
    goto L1; // [23] 38

    /** 			return machine_func(M_DIR, name)*/
    _3089 = machine(22, _name_5906);
    DeRefDS(_name_5906);
    DeRef(_dir_data_5907);
    DeRef(_data_5908);
    DeRef(_the_name_5909);
    DeRef(_the_dir_5910);
    return _3089;
L1: 

    /** 		if first_wildcard_at then*/
    if (_first_wildcard_at_5913 == 0)
    {
        goto L2; // [40] 56
    }
    else{
    }

    /** 			idx = search:rfind(SLASH, name, first_wildcard_at )*/
    RefDS(_name_5906);
    _idx_5912 = _16rfind(47, _name_5906, _first_wildcard_at_5913);
    if (!IS_ATOM_INT(_idx_5912)) {
        _1 = (long)(DBL_PTR(_idx_5912)->dbl);
        DeRefDS(_idx_5912);
        _idx_5912 = _1;
    }
    goto L3; // [53] 70
L2: 

    /** 			idx = search:rfind(SLASH, name )*/
    if (IS_SEQUENCE(_name_5906)){
            _3091 = SEQ_PTR(_name_5906)->length;
    }
    else {
        _3091 = 1;
    }
    RefDS(_name_5906);
    _idx_5912 = _16rfind(47, _name_5906, _3091);
    _3091 = NOVALUE;
    if (!IS_ATOM_INT(_idx_5912)) {
        _1 = (long)(DBL_PTR(_idx_5912)->dbl);
        DeRefDS(_idx_5912);
        _idx_5912 = _1;
    }
L3: 

    /** 		if idx = 0 then*/
    if (_idx_5912 != 0)
    goto L4; // [74] 91

    /** 			the_dir = "."*/
    RefDS(_3094);
    DeRef(_the_dir_5910);
    _the_dir_5910 = _3094;

    /** 			the_name = name*/
    RefDS(_name_5906);
    DeRef(_the_name_5909);
    _the_name_5909 = _name_5906;
    goto L5; // [88] 187
L4: 

    /** 			the_dir = name[1 .. idx]*/
    rhs_slice_target = (object_ptr)&_the_dir_5910;
    RHS_Slice(_name_5906, 1, _idx_5912);

    /** 			integer next_slash = 0*/
    _next_slash_5928 = 0;

    /** 			if first_wildcard_at then*/
    if (_first_wildcard_at_5913 == 0)
    {
        goto L6; // [105] 116
    }
    else{
    }

    /** 				next_slash = eu:find( SLASH, name, first_wildcard_at )*/
    _next_slash_5928 = find_from(47, _name_5906, _first_wildcard_at_5913);
L6: 

    /** 			if next_slash then*/
    if (_next_slash_5928 == 0)
    {
        goto L7; // [118] 164
    }
    else{
    }

    /** 				first_wildcard_at = find_first_wildcard( name, next_slash )*/
    RefDS(_name_5906);
    _first_wildcard_at_5913 = _17find_first_wildcard(_name_5906, _next_slash_5928);
    if (!IS_ATOM_INT(_first_wildcard_at_5913)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_5913)->dbl);
        DeRefDS(_first_wildcard_at_5913);
        _first_wildcard_at_5913 = _1;
    }

    /** 				if first_wildcard_at then*/
    if (_first_wildcard_at_5913 == 0)
    {
        goto L8; // [132] 184
    }
    else{
    }

    /** 					the_name = name[idx+1..next_slash-1]*/
    _3098 = _idx_5912 + 1;
    if (_3098 > MAXINT){
        _3098 = NewDouble((double)_3098);
    }
    _3099 = _next_slash_5928 - 1;
    rhs_slice_target = (object_ptr)&_the_name_5909;
    RHS_Slice(_name_5906, _3098, _3099);

    /** 					the_suffix = name[next_slash..$]*/
    if (IS_SEQUENCE(_name_5906)){
            _3101 = SEQ_PTR(_name_5906)->length;
    }
    else {
        _3101 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_suffix_5911;
    RHS_Slice(_name_5906, _next_slash_5928, _3101);
    goto L8; // [161] 184
L7: 

    /** 				the_name = name[idx+1 .. $]*/
    _3103 = _idx_5912 + 1;
    if (_3103 > MAXINT){
        _3103 = NewDouble((double)_3103);
    }
    if (IS_SEQUENCE(_name_5906)){
            _3104 = SEQ_PTR(_name_5906)->length;
    }
    else {
        _3104 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_name_5909;
    RHS_Slice(_name_5906, _3103, _3104);

    /** 				the_suffix = 0*/
    DeRef(_the_suffix_5911);
    _the_suffix_5911 = 0;
L8: 
L5: 

    /** 		dir_data = dir( the_dir )*/
    Ref(_the_dir_5910);
    _0 = _dir_data_5907;
    _dir_data_5907 = _17dir(_the_dir_5910);
    DeRef(_0);

    /** 		if atom(dir_data) then*/
    _3107 = IS_ATOM(_dir_data_5907);
    if (_3107 == 0)
    {
        _3107 = NOVALUE;
        goto L9; // [200] 210
    }
    else{
        _3107 = NOVALUE;
    }

    /** 			return dir_data*/
    DeRefDS(_name_5906);
    DeRef(_data_5908);
    DeRef(_the_name_5909);
    DeRef(_the_dir_5910);
    DeRef(_the_suffix_5911);
    DeRef(_3089);
    _3089 = NOVALUE;
    DeRef(_3098);
    _3098 = NOVALUE;
    DeRef(_3099);
    _3099 = NOVALUE;
    DeRef(_3103);
    _3103 = NOVALUE;
    return _dir_data_5907;
L9: 

    /** 		data = {}*/
    RefDS(_5);
    DeRef(_data_5908);
    _data_5908 = _5;

    /** 		for i = 1 to length(dir_data) do*/
    if (IS_SEQUENCE(_dir_data_5907)){
            _3108 = SEQ_PTR(_dir_data_5907)->length;
    }
    else {
        _3108 = 1;
    }
    {
        int _i_5947;
        _i_5947 = 1;
LA: 
        if (_i_5947 > _3108){
            goto LB; // [220] 265
        }

        /** 			if wildcard:is_match(the_name, dir_data[i][1]) then*/
        _2 = (int)SEQ_PTR(_dir_data_5907);
        _3109 = (int)*(((s1_ptr)_2)->base + _i_5947);
        _2 = (int)SEQ_PTR(_3109);
        _3110 = (int)*(((s1_ptr)_2)->base + 1);
        _3109 = NOVALUE;
        Ref(_the_name_5909);
        Ref(_3110);
        _3111 = _25is_match(_the_name_5909, _3110);
        _3110 = NOVALUE;
        if (_3111 == 0) {
            DeRef(_3111);
            _3111 = NOVALUE;
            goto LC; // [244] 258
        }
        else {
            if (!IS_ATOM_INT(_3111) && DBL_PTR(_3111)->dbl == 0.0){
                DeRef(_3111);
                _3111 = NOVALUE;
                goto LC; // [244] 258
            }
            DeRef(_3111);
            _3111 = NOVALUE;
        }
        DeRef(_3111);
        _3111 = NOVALUE;

        /** 					data = append(data, dir_data[i])*/
        _2 = (int)SEQ_PTR(_dir_data_5907);
        _3112 = (int)*(((s1_ptr)_2)->base + _i_5947);
        Ref(_3112);
        Append(&_data_5908, _data_5908, _3112);
        _3112 = NOVALUE;
LC: 

        /** 		end for*/
        _i_5947 = _i_5947 + 1;
        goto LA; // [260] 227
LB: 
        ;
    }

    /** 		if not length(data) then*/
    if (IS_SEQUENCE(_data_5908)){
            _3114 = SEQ_PTR(_data_5908)->length;
    }
    else {
        _3114 = 1;
    }
    if (_3114 != 0)
    goto LD; // [270] 280
    _3114 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_name_5906);
    DeRef(_dir_data_5907);
    DeRef(_data_5908);
    DeRef(_the_name_5909);
    DeRef(_the_dir_5910);
    DeRef(_the_suffix_5911);
    DeRef(_3089);
    _3089 = NOVALUE;
    DeRef(_3098);
    _3098 = NOVALUE;
    DeRef(_3099);
    _3099 = NOVALUE;
    DeRef(_3103);
    _3103 = NOVALUE;
    return -1;
LD: 

    /** 		if sequence( the_suffix ) then*/
    _3116 = IS_SEQUENCE(_the_suffix_5911);
    if (_3116 == 0)
    {
        _3116 = NOVALUE;
        goto LE; // [285] 406
    }
    else{
        _3116 = NOVALUE;
    }

    /** 			sequence wild_data = {}*/
    RefDS(_5);
    DeRef(_wild_data_5960);
    _wild_data_5960 = _5;

    /** 			for i = 1 to length( dir_data ) do*/
    if (IS_SEQUENCE(_dir_data_5907)){
            _3117 = SEQ_PTR(_dir_data_5907)->length;
    }
    else {
        _3117 = 1;
    }
    {
        int _i_5962;
        _i_5962 = 1;
LF: 
        if (_i_5962 > _3117){
            goto L10; // [300] 399
        }

        /** 				sequence interim_dir = the_dir & dir_data[i][D_NAME] & SLASH*/
        _2 = (int)SEQ_PTR(_dir_data_5907);
        _3118 = (int)*(((s1_ptr)_2)->base + _i_5962);
        _2 = (int)SEQ_PTR(_3118);
        _3119 = (int)*(((s1_ptr)_2)->base + 1);
        _3118 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _3119;
            concat_list[2] = _the_dir_5910;
            Concat_N((object_ptr)&_interim_dir_5964, concat_list, 3);
        }
        _3119 = NOVALUE;

        /** 				object dir_results = dir( interim_dir & the_suffix )*/
        if (IS_SEQUENCE(_interim_dir_5964) && IS_ATOM(_the_suffix_5911)) {
            Ref(_the_suffix_5911);
            Append(&_3121, _interim_dir_5964, _the_suffix_5911);
        }
        else if (IS_ATOM(_interim_dir_5964) && IS_SEQUENCE(_the_suffix_5911)) {
        }
        else {
            Concat((object_ptr)&_3121, _interim_dir_5964, _the_suffix_5911);
        }
        _0 = _dir_results_5968;
        _dir_results_5968 = _17dir(_3121);
        DeRef(_0);
        _3121 = NOVALUE;

        /** 				if sequence( dir_results ) then*/
        _3123 = IS_SEQUENCE(_dir_results_5968);
        if (_3123 == 0)
        {
            _3123 = NOVALUE;
            goto L11; // [338] 390
        }
        else{
            _3123 = NOVALUE;
        }

        /** 					for j = 1 to length( dir_results ) do*/
        if (IS_SEQUENCE(_dir_results_5968)){
                _3124 = SEQ_PTR(_dir_results_5968)->length;
        }
        else {
            _3124 = 1;
        }
        {
            int _j_5974;
            _j_5974 = 1;
L12: 
            if (_j_5974 > _3124){
                goto L13; // [346] 383
            }

            /** 						dir_results[j][D_NAME] = interim_dir & dir_results[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_dir_results_5968);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _dir_results_5968 = MAKE_SEQ(_2);
            }
            _3 = (int)(_j_5974 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_dir_results_5968);
            _3127 = (int)*(((s1_ptr)_2)->base + _j_5974);
            _2 = (int)SEQ_PTR(_3127);
            _3128 = (int)*(((s1_ptr)_2)->base + 1);
            _3127 = NOVALUE;
            if (IS_SEQUENCE(_interim_dir_5964) && IS_ATOM(_3128)) {
                Ref(_3128);
                Append(&_3129, _interim_dir_5964, _3128);
            }
            else if (IS_ATOM(_interim_dir_5964) && IS_SEQUENCE(_3128)) {
            }
            else {
                Concat((object_ptr)&_3129, _interim_dir_5964, _3128);
            }
            _3128 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _3129;
            if( _1 != _3129 ){
                DeRef(_1);
            }
            _3129 = NOVALUE;
            _3125 = NOVALUE;

            /** 					end for*/
            _j_5974 = _j_5974 + 1;
            goto L12; // [378] 353
L13: 
            ;
        }

        /** 					wild_data &= dir_results*/
        if (IS_SEQUENCE(_wild_data_5960) && IS_ATOM(_dir_results_5968)) {
            Ref(_dir_results_5968);
            Append(&_wild_data_5960, _wild_data_5960, _dir_results_5968);
        }
        else if (IS_ATOM(_wild_data_5960) && IS_SEQUENCE(_dir_results_5968)) {
        }
        else {
            Concat((object_ptr)&_wild_data_5960, _wild_data_5960, _dir_results_5968);
        }
L11: 
        DeRef(_interim_dir_5964);
        _interim_dir_5964 = NOVALUE;
        DeRef(_dir_results_5968);
        _dir_results_5968 = NOVALUE;

        /** 			end for*/
        _i_5962 = _i_5962 + 1;
        goto LF; // [394] 307
L10: 
        ;
    }

    /** 			return wild_data*/
    DeRefDS(_name_5906);
    DeRef(_dir_data_5907);
    DeRef(_data_5908);
    DeRef(_the_name_5909);
    DeRef(_the_dir_5910);
    DeRef(_the_suffix_5911);
    DeRef(_3089);
    _3089 = NOVALUE;
    DeRef(_3098);
    _3098 = NOVALUE;
    DeRef(_3099);
    _3099 = NOVALUE;
    DeRef(_3103);
    _3103 = NOVALUE;
    return _wild_data_5960;
LE: 
    DeRef(_wild_data_5960);
    _wild_data_5960 = NOVALUE;

    /** 		return data*/
    DeRefDS(_name_5906);
    DeRef(_dir_data_5907);
    DeRef(_the_name_5909);
    DeRef(_the_dir_5910);
    DeRef(_the_suffix_5911);
    DeRef(_3089);
    _3089 = NOVALUE;
    DeRef(_3098);
    _3098 = NOVALUE;
    DeRef(_3099);
    _3099 = NOVALUE;
    DeRef(_3103);
    _3103 = NOVALUE;
    return _data_5908;
    ;
}


int _17current_dir()
{
    int _3131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _3131 = machine(23, 0);
    return _3131;
    ;
}


int _17chdir(int _newdir_5987)
{
    int _3132 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _3132 = machine(63, _newdir_5987);
    DeRefDS(_newdir_5987);
    return _3132;
    ;
}


int _17create_directory(int _name_6075, int _mode_6076, int _mkparent_6078)
{
    int _pname_6079 = NOVALUE;
    int _ret_6080 = NOVALUE;
    int _pos_6081 = NOVALUE;
    int _3201 = NOVALUE;
    int _3200 = NOVALUE;
    int _3197 = NOVALUE;
    int _3196 = NOVALUE;
    int _3195 = NOVALUE;
    int _3194 = NOVALUE;
    int _3191 = NOVALUE;
    int _3188 = NOVALUE;
    int _3187 = NOVALUE;
    int _3185 = NOVALUE;
    int _3184 = NOVALUE;
    int _3182 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(name) = 0 then*/
    if (IS_SEQUENCE(_name_6075)){
            _3182 = SEQ_PTR(_name_6075)->length;
    }
    else {
        _3182 = 1;
    }
    if (_3182 != 0)
    goto L1; // [12] 23

    /** 		return 0 -- failed*/
    DeRefDS(_name_6075);
    DeRef(_pname_6079);
    DeRef(_ret_6080);
    return 0;
L1: 

    /** 	if name[$] = SLASH then*/
    if (IS_SEQUENCE(_name_6075)){
            _3184 = SEQ_PTR(_name_6075)->length;
    }
    else {
        _3184 = 1;
    }
    _2 = (int)SEQ_PTR(_name_6075);
    _3185 = (int)*(((s1_ptr)_2)->base + _3184);
    if (binary_op_a(NOTEQ, _3185, 47)){
        _3185 = NOVALUE;
        goto L2; // [32] 51
    }
    _3185 = NOVALUE;

    /** 		name = name[1 .. $-1]*/
    if (IS_SEQUENCE(_name_6075)){
            _3187 = SEQ_PTR(_name_6075)->length;
    }
    else {
        _3187 = 1;
    }
    _3188 = _3187 - 1;
    _3187 = NOVALUE;
    rhs_slice_target = (object_ptr)&_name_6075;
    RHS_Slice(_name_6075, 1, _3188);
L2: 

    /** 	if mkparent != 0 then*/
    if (_mkparent_6078 == 0)
    goto L3; // [53] 101

    /** 		pos = search:rfind(SLASH, name)*/
    if (IS_SEQUENCE(_name_6075)){
            _3191 = SEQ_PTR(_name_6075)->length;
    }
    else {
        _3191 = 1;
    }
    RefDS(_name_6075);
    _pos_6081 = _16rfind(47, _name_6075, _3191);
    _3191 = NOVALUE;
    if (!IS_ATOM_INT(_pos_6081)) {
        _1 = (long)(DBL_PTR(_pos_6081)->dbl);
        DeRefDS(_pos_6081);
        _pos_6081 = _1;
    }

    /** 		if pos != 0 then*/
    if (_pos_6081 == 0)
    goto L4; // [72] 100

    /** 			ret = create_directory(name[1.. pos-1], mode, mkparent)*/
    _3194 = _pos_6081 - 1;
    rhs_slice_target = (object_ptr)&_3195;
    RHS_Slice(_name_6075, 1, _3194);
    DeRef(_3196);
    _3196 = _mode_6076;
    DeRef(_3197);
    _3197 = _mkparent_6078;
    _0 = _ret_6080;
    _ret_6080 = _17create_directory(_3195, _3196, _3197);
    DeRef(_0);
    _3195 = NOVALUE;
    _3196 = NOVALUE;
    _3197 = NOVALUE;
L4: 
L3: 

    /** 	pname = machine:allocate_string(name)*/
    RefDS(_name_6075);
    _0 = _pname_6079;
    _pname_6079 = _9allocate_string(_name_6075, 0);
    DeRef(_0);

    /** 	ifdef UNIX then*/

    /** 		ret = not c_func(xCreateDirectory, {pname, mode})*/
    Ref(_pname_6079);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pname_6079;
    ((int *)_2)[2] = _mode_6076;
    _3200 = MAKE_SEQ(_1);
    _3201 = call_c(1, _17xCreateDirectory_5842, _3200);
    DeRefDS(_3200);
    _3200 = NOVALUE;
    DeRef(_ret_6080);
    if (IS_ATOM_INT(_3201)) {
        _ret_6080 = (_3201 == 0);
    }
    else {
        _ret_6080 = unary_op(NOT, _3201);
    }
    DeRef(_3201);
    _3201 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_name_6075);
    DeRef(_pname_6079);
    DeRef(_3188);
    _3188 = NOVALUE;
    DeRef(_3194);
    _3194 = NOVALUE;
    return _ret_6080;
    ;
}


int _17delete_file(int _name_6118)
{
    int _pfilename_6119 = NOVALUE;
    int _success_6121 = NOVALUE;
    int _3207 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_6118);
    _0 = _pfilename_6119;
    _pfilename_6119 = _9allocate_string(_name_6118, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_6119);
    *((int *)(_2+4)) = _pfilename_6119;
    _3207 = MAKE_SEQ(_1);
    _success_6121 = call_c(1, _17xDeleteFile_5838, _3207);
    DeRefDS(_3207);
    _3207 = NOVALUE;
    if (!IS_ATOM_INT(_success_6121)) {
        _1 = (long)(DBL_PTR(_success_6121)->dbl);
        DeRefDS(_success_6121);
        _success_6121 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 		success = not success*/
    _success_6121 = (_success_6121 == 0);

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_6119);
    _9free(_pfilename_6119);

    /** 	return success*/
    DeRefDS(_name_6118);
    DeRef(_pfilename_6119);
    return _success_6121;
    ;
}


int _17curdir(int _drive_id_6127)
{
    int _lCurDir_6128 = NOVALUE;
    int _current_dir_inlined_current_dir_at_6_6130 = NOVALUE;
    int _3211 = NOVALUE;
    int _3210 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef not LINUX then*/

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_6128);
    _lCurDir_6128 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_6128)){
            _3210 = SEQ_PTR(_lCurDir_6128)->length;
    }
    else {
        _3210 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_6128);
    _3211 = (int)*(((s1_ptr)_2)->base + _3210);
    if (_3211 == 47)
    goto L1; // [27] 38

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_6128, _lCurDir_6128, 47);
L1: 

    /** 	return lCurDir*/
    _3211 = NOVALUE;
    return _lCurDir_6128;
    ;
}


int _17remove_directory(int _dir_name_6199, int _force_6200)
{
    int _pname_6201 = NOVALUE;
    int _ret_6202 = NOVALUE;
    int _files_6203 = NOVALUE;
    int _D_NAME_6204 = NOVALUE;
    int _D_ATTRIBUTES_6205 = NOVALUE;
    int _3285 = NOVALUE;
    int _3281 = NOVALUE;
    int _3280 = NOVALUE;
    int _3279 = NOVALUE;
    int _3277 = NOVALUE;
    int _3276 = NOVALUE;
    int _3275 = NOVALUE;
    int _3274 = NOVALUE;
    int _3273 = NOVALUE;
    int _3272 = NOVALUE;
    int _3271 = NOVALUE;
    int _3270 = NOVALUE;
    int _3269 = NOVALUE;
    int _3268 = NOVALUE;
    int _3267 = NOVALUE;
    int _3266 = NOVALUE;
    int _3263 = NOVALUE;
    int _3262 = NOVALUE;
    int _3259 = NOVALUE;
    int _3257 = NOVALUE;
    int _3256 = NOVALUE;
    int _3254 = NOVALUE;
    int _3253 = NOVALUE;
    int _3251 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer D_NAME = 1, D_ATTRIBUTES = 2*/
    _D_NAME_6204 = 1;
    _D_ATTRIBUTES_6205 = 2;

    /**  	if length(dir_name) > 0 then*/
    if (IS_SEQUENCE(_dir_name_6199)){
            _3251 = SEQ_PTR(_dir_name_6199)->length;
    }
    else {
        _3251 = 1;
    }
    if (_3251 <= 0)
    goto L1; // [18] 51

    /** 		if dir_name[$] = SLASH then*/
    if (IS_SEQUENCE(_dir_name_6199)){
            _3253 = SEQ_PTR(_dir_name_6199)->length;
    }
    else {
        _3253 = 1;
    }
    _2 = (int)SEQ_PTR(_dir_name_6199);
    _3254 = (int)*(((s1_ptr)_2)->base + _3253);
    if (binary_op_a(NOTEQ, _3254, 47)){
        _3254 = NOVALUE;
        goto L2; // [31] 50
    }
    _3254 = NOVALUE;

    /** 			dir_name = dir_name[1 .. $-1]*/
    if (IS_SEQUENCE(_dir_name_6199)){
            _3256 = SEQ_PTR(_dir_name_6199)->length;
    }
    else {
        _3256 = 1;
    }
    _3257 = _3256 - 1;
    _3256 = NOVALUE;
    rhs_slice_target = (object_ptr)&_dir_name_6199;
    RHS_Slice(_dir_name_6199, 1, _3257);
L2: 
L1: 

    /** 	if length(dir_name) = 0 then*/
    if (IS_SEQUENCE(_dir_name_6199)){
            _3259 = SEQ_PTR(_dir_name_6199)->length;
    }
    else {
        _3259 = 1;
    }
    if (_3259 != 0)
    goto L3; // [56] 67

    /** 		return 0	-- nothing specified to delete.*/
    DeRefDS(_dir_name_6199);
    DeRef(_pname_6201);
    DeRef(_ret_6202);
    DeRef(_files_6203);
    DeRef(_3257);
    _3257 = NOVALUE;
    return 0;
L3: 

    /** 	ifdef WINDOWS then*/

    /** 	files = dir(dir_name)*/
    RefDS(_dir_name_6199);
    _0 = _files_6203;
    _files_6203 = _17dir(_dir_name_6199);
    DeRef(_0);

    /** 	if atom(files) then*/
    _3262 = IS_ATOM(_files_6203);
    if (_3262 == 0)
    {
        _3262 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3262 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_dir_name_6199);
    DeRef(_pname_6201);
    DeRef(_ret_6202);
    DeRef(_files_6203);
    DeRef(_3257);
    _3257 = NOVALUE;
    return 0;
L4: 

    /** 	if length( files ) < 2 then*/
    if (IS_SEQUENCE(_files_6203)){
            _3263 = SEQ_PTR(_files_6203)->length;
    }
    else {
        _3263 = 1;
    }
    if (_3263 >= 2)
    goto L5; // [95] 106

    /** 		return 0	-- Supplied dir_name was not a directory*/
    DeRefDS(_dir_name_6199);
    DeRef(_pname_6201);
    DeRef(_ret_6202);
    DeRef(_files_6203);
    DeRef(_3257);
    _3257 = NOVALUE;
    return 0;
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	dir_name &= SLASH*/
    Append(&_dir_name_6199, _dir_name_6199, 47);

    /** 	ifdef WINDOWS then*/

    /** 		for i = 1 to length(files) do*/
    if (IS_SEQUENCE(_files_6203)){
            _3266 = SEQ_PTR(_files_6203)->length;
    }
    else {
        _3266 = 1;
    }
    {
        int _i_6227;
        _i_6227 = 1;
L6: 
        if (_i_6227 > _3266){
            goto L7; // [121] 240
        }

        /** 			if find( files[i][D_NAME], {".",".."}) then*/
        _2 = (int)SEQ_PTR(_files_6203);
        _3267 = (int)*(((s1_ptr)_2)->base + _i_6227);
        _2 = (int)SEQ_PTR(_3267);
        _3268 = (int)*(((s1_ptr)_2)->base + _D_NAME_6204);
        _3267 = NOVALUE;
        RefDS(_3161);
        RefDS(_3094);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _3094;
        ((int *)_2)[2] = _3161;
        _3269 = MAKE_SEQ(_1);
        _3270 = find_from(_3268, _3269, 1);
        _3268 = NOVALUE;
        DeRefDS(_3269);
        _3269 = NOVALUE;
        if (_3270 == 0)
        {
            _3270 = NOVALUE;
            goto L8; // [147] 155
        }
        else{
            _3270 = NOVALUE;
        }

        /** 				continue*/
        goto L9; // [152] 235
L8: 

        /** 			if eu:find('d', files[i][D_ATTRIBUTES]) then*/
        _2 = (int)SEQ_PTR(_files_6203);
        _3271 = (int)*(((s1_ptr)_2)->base + _i_6227);
        _2 = (int)SEQ_PTR(_3271);
        _3272 = (int)*(((s1_ptr)_2)->base + _D_ATTRIBUTES_6205);
        _3271 = NOVALUE;
        _3273 = find_from(100, _3272, 1);
        _3272 = NOVALUE;
        if (_3273 == 0)
        {
            _3273 = NOVALUE;
            goto LA; // [170] 200
        }
        else{
            _3273 = NOVALUE;
        }

        /** 				ret = remove_directory(dir_name & files[i][D_NAME] & SLASH, force)*/
        _2 = (int)SEQ_PTR(_files_6203);
        _3274 = (int)*(((s1_ptr)_2)->base + _i_6227);
        _2 = (int)SEQ_PTR(_3274);
        _3275 = (int)*(((s1_ptr)_2)->base + _D_NAME_6204);
        _3274 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _3275;
            concat_list[2] = _dir_name_6199;
            Concat_N((object_ptr)&_3276, concat_list, 3);
        }
        _3275 = NOVALUE;
        DeRef(_3277);
        _3277 = _force_6200;
        _0 = _ret_6202;
        _ret_6202 = _17remove_directory(_3276, _3277);
        DeRef(_0);
        _3276 = NOVALUE;
        _3277 = NOVALUE;
        goto LB; // [197] 219
LA: 

        /** 				ret = delete_file(dir_name & files[i][D_NAME])*/
        _2 = (int)SEQ_PTR(_files_6203);
        _3279 = (int)*(((s1_ptr)_2)->base + _i_6227);
        _2 = (int)SEQ_PTR(_3279);
        _3280 = (int)*(((s1_ptr)_2)->base + _D_NAME_6204);
        _3279 = NOVALUE;
        if (IS_SEQUENCE(_dir_name_6199) && IS_ATOM(_3280)) {
            Ref(_3280);
            Append(&_3281, _dir_name_6199, _3280);
        }
        else if (IS_ATOM(_dir_name_6199) && IS_SEQUENCE(_3280)) {
        }
        else {
            Concat((object_ptr)&_3281, _dir_name_6199, _3280);
        }
        _3280 = NOVALUE;
        _0 = _ret_6202;
        _ret_6202 = _17delete_file(_3281);
        DeRef(_0);
        _3281 = NOVALUE;
LB: 

        /** 			if not ret then*/
        if (IS_ATOM_INT(_ret_6202)) {
            if (_ret_6202 != 0){
                goto LC; // [223] 233
            }
        }
        else {
            if (DBL_PTR(_ret_6202)->dbl != 0.0){
                goto LC; // [223] 233
            }
        }

        /** 				return 0*/
        DeRefDS(_dir_name_6199);
        DeRef(_pname_6201);
        DeRef(_ret_6202);
        DeRef(_files_6203);
        DeRef(_3257);
        _3257 = NOVALUE;
        return 0;
LC: 

        /** 		end for*/
L9: 
        _i_6227 = _i_6227 + 1;
        goto L6; // [235] 128
L7: 
        ;
    }

    /** 	pname = machine:allocate_string(dir_name)*/
    RefDS(_dir_name_6199);
    _0 = _pname_6201;
    _pname_6201 = _9allocate_string(_dir_name_6199, 0);
    DeRef(_0);

    /** 	ret = c_func(xRemoveDirectory, {pname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pname_6201);
    *((int *)(_2+4)) = _pname_6201;
    _3285 = MAKE_SEQ(_1);
    DeRef(_ret_6202);
    _ret_6202 = call_c(1, _17xRemoveDirectory_5846, _3285);
    DeRefDS(_3285);
    _3285 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 			ret = not ret */
    _0 = _ret_6202;
    if (IS_ATOM_INT(_ret_6202)) {
        _ret_6202 = (_ret_6202 == 0);
    }
    else {
        _ret_6202 = unary_op(NOT, _ret_6202);
    }
    DeRef(_0);

    /** 	machine:free(pname)*/
    Ref(_pname_6201);
    _9free(_pname_6201);

    /** 	return ret*/
    DeRefDS(_dir_name_6199);
    DeRef(_pname_6201);
    DeRef(_files_6203);
    DeRef(_3257);
    _3257 = NOVALUE;
    return _ret_6202;
    ;
}


int _17pathinfo(int _path_6261, int _std_slash_6262)
{
    int _slash_6263 = NOVALUE;
    int _period_6264 = NOVALUE;
    int _ch_6265 = NOVALUE;
    int _dir_name_6266 = NOVALUE;
    int _file_name_6267 = NOVALUE;
    int _file_ext_6268 = NOVALUE;
    int _file_full_6269 = NOVALUE;
    int _drive_id_6270 = NOVALUE;
    int _from_slash_6302 = NOVALUE;
    int _3313 = NOVALUE;
    int _3306 = NOVALUE;
    int _3305 = NOVALUE;
    int _3302 = NOVALUE;
    int _3301 = NOVALUE;
    int _3299 = NOVALUE;
    int _3298 = NOVALUE;
    int _3295 = NOVALUE;
    int _3293 = NOVALUE;
    int _3292 = NOVALUE;
    int _3291 = NOVALUE;
    int _3290 = NOVALUE;
    int _3288 = NOVALUE;
    int _0, _1, _2;
    

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_6266);
    _dir_name_6266 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_6267);
    _file_name_6267 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_6268);
    _file_ext_6268 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_6269);
    _file_full_6269 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_6270);
    _drive_id_6270 = _5;

    /** 	slash = 0*/
    _slash_6263 = 0;

    /** 	period = 0*/
    _period_6264 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6261)){
            _3288 = SEQ_PTR(_path_6261)->length;
    }
    else {
        _3288 = 1;
    }
    {
        int _i_6272;
        _i_6272 = _3288;
L1: 
        if (_i_6272 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_6261);
        _ch_6265 = (int)*(((s1_ptr)_2)->base + _i_6272);
        if (!IS_ATOM_INT(_ch_6265))
        _ch_6265 = (long)DBL_PTR(_ch_6265)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _3290 = (_period_6264 == 0);
        if (_3290 == 0) {
            goto L3; // [74] 94
        }
        _3292 = (_ch_6265 == 46);
        if (_3292 == 0)
        {
            DeRef(_3292);
            _3292 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_3292);
            _3292 = NOVALUE;
        }

        /** 			period = i*/
        _period_6264 = _i_6272;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _3293 = find_from(_ch_6265, _17SLASHES_5862, 1);
        if (_3293 == 0)
        {
            _3293 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _3293 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_6263 = _i_6272;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_6272 = _i_6272 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_6263 <= 0)
    goto L6; // [124] 142

    /** 		dir_name = path[1..slash-1]*/
    _3295 = _slash_6263 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_6266;
    RHS_Slice(_path_6261, 1, _3295);

    /** 		ifdef not UNIX then*/
L6: 

    /** 	if period > 0 then*/
    if (_period_6264 <= 0)
    goto L7; // [144] 188

    /** 		file_name = path[slash+1..period-1]*/
    _3298 = _slash_6263 + 1;
    if (_3298 > MAXINT){
        _3298 = NewDouble((double)_3298);
    }
    _3299 = _period_6264 - 1;
    rhs_slice_target = (object_ptr)&_file_name_6267;
    RHS_Slice(_path_6261, _3298, _3299);

    /** 		file_ext = path[period+1..$]*/
    _3301 = _period_6264 + 1;
    if (_3301 > MAXINT){
        _3301 = NewDouble((double)_3301);
    }
    if (IS_SEQUENCE(_path_6261)){
            _3302 = SEQ_PTR(_path_6261)->length;
    }
    else {
        _3302 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_6268;
    RHS_Slice(_path_6261, _3301, _3302);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_6268;
        concat_list[1] = 46;
        concat_list[2] = _file_name_6267;
        Concat_N((object_ptr)&_file_full_6269, concat_list, 3);
    }
    goto L8; // [185] 210
L7: 

    /** 		file_name = path[slash+1..$]*/
    _3305 = _slash_6263 + 1;
    if (_3305 > MAXINT){
        _3305 = NewDouble((double)_3305);
    }
    if (IS_SEQUENCE(_path_6261)){
            _3306 = SEQ_PTR(_path_6261)->length;
    }
    else {
        _3306 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_6267;
    RHS_Slice(_path_6261, _3305, _3306);

    /** 		file_full = file_name*/
    RefDS(_file_name_6267);
    DeRef(_file_full_6269);
    _file_full_6269 = _file_name_6267;
L8: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_6262 == 0)
    goto L9; // [212] 278

    /** 		if std_slash < 0 then*/
    if (_std_slash_6262 >= 0)
    goto LA; // [218] 254

    /** 			std_slash = SLASH*/
    _std_slash_6262 = 47;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "\\"*/
    RefDS(_906);
    DeRefi(_from_slash_6302);
    _from_slash_6302 = _906;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_6302);
    RefDS(_dir_name_6266);
    _0 = _dir_name_6266;
    _dir_name_6266 = _16match_replace(_from_slash_6302, _dir_name_6266, 47, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_6302);
    _from_slash_6302 = NOVALUE;
    goto LB; // [251] 277
LA: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_906);
    RefDS(_dir_name_6266);
    _0 = _dir_name_6266;
    _dir_name_6266 = _16match_replace(_906, _dir_name_6266, _std_slash_6262, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_3072);
    RefDS(_dir_name_6266);
    _0 = _dir_name_6266;
    _dir_name_6266 = _16match_replace(_3072, _dir_name_6266, _std_slash_6262, 0);
    DeRefDS(_0);
LB: 
L9: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_6266);
    *((int *)(_2+4)) = _dir_name_6266;
    RefDS(_file_full_6269);
    *((int *)(_2+8)) = _file_full_6269;
    RefDS(_file_name_6267);
    *((int *)(_2+12)) = _file_name_6267;
    RefDS(_file_ext_6268);
    *((int *)(_2+16)) = _file_ext_6268;
    RefDS(_drive_id_6270);
    *((int *)(_2+20)) = _drive_id_6270;
    _3313 = MAKE_SEQ(_1);
    DeRefDS(_path_6261);
    DeRefDS(_dir_name_6266);
    DeRefDS(_file_name_6267);
    DeRefDS(_file_ext_6268);
    DeRefDS(_file_full_6269);
    DeRefDS(_drive_id_6270);
    DeRef(_3290);
    _3290 = NOVALUE;
    DeRef(_3295);
    _3295 = NOVALUE;
    DeRef(_3298);
    _3298 = NOVALUE;
    DeRef(_3299);
    _3299 = NOVALUE;
    DeRef(_3301);
    _3301 = NOVALUE;
    DeRef(_3305);
    _3305 = NOVALUE;
    return _3313;
    ;
}


int _17dirname(int _path_6310, int _pcd_6311)
{
    int _data_6312 = NOVALUE;
    int _3318 = NOVALUE;
    int _3316 = NOVALUE;
    int _3315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6310);
    _0 = _data_6312;
    _data_6312 = _17pathinfo(_path_6310, 0);
    DeRef(_0);

    /** 	if pcd then*/
    if (_pcd_6311 == 0)
    {
        goto L1; // [16] 40
    }
    else{
    }

    /** 		if length(data[1]) = 0 then*/
    _2 = (int)SEQ_PTR(_data_6312);
    _3315 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_3315)){
            _3316 = SEQ_PTR(_3315)->length;
    }
    else {
        _3316 = 1;
    }
    _3315 = NOVALUE;
    if (_3316 != 0)
    goto L2; // [28] 39

    /** 			return "."*/
    RefDS(_3094);
    DeRefDS(_path_6310);
    DeRefDS(_data_6312);
    _3315 = NOVALUE;
    return _3094;
L2: 
L1: 

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_6312);
    _3318 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3318);
    DeRefDS(_path_6310);
    DeRefDS(_data_6312);
    _3315 = NOVALUE;
    return _3318;
    ;
}


int _17filebase(int _path_6339)
{
    int _data_6340 = NOVALUE;
    int _3327 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6339);
    _0 = _data_6340;
    _data_6340 = _17pathinfo(_path_6339, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_6340);
    _3327 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_3327);
    DeRefDS(_path_6339);
    DeRefDS(_data_6340);
    return _3327;
    ;
}


int _17fileext(int _path_6345)
{
    int _data_6346 = NOVALUE;
    int _3329 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_6345);
    _0 = _data_6346;
    _data_6346 = _17pathinfo(_path_6345, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_6346);
    _3329 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_3329);
    DeRefDS(_path_6345);
    DeRefDS(_data_6346);
    return _3329;
    ;
}


int _17defaultext(int _path_6357, int _defext_6358)
{
    int _3344 = NOVALUE;
    int _3341 = NOVALUE;
    int _3339 = NOVALUE;
    int _3338 = NOVALUE;
    int _3337 = NOVALUE;
    int _3335 = NOVALUE;
    int _3334 = NOVALUE;
    int _3332 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    _3332 = 3;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_6357)){
            _3334 = SEQ_PTR(_path_6357)->length;
    }
    else {
        _3334 = 1;
    }
    {
        int _i_6363;
        _i_6363 = _3334;
L1: 
        if (_i_6363 < 1){
            goto L2; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_6357);
        _3335 = (int)*(((s1_ptr)_2)->base + _i_6363);
        if (binary_op_a(NOTEQ, _3335, 46)){
            _3335 = NOVALUE;
            goto L3; // [39] 50
        }
        _3335 = NOVALUE;

        /** 			return path*/
        DeRefDSi(_defext_6358);
        return _path_6357;
L3: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_6357);
        _3337 = (int)*(((s1_ptr)_2)->base + _i_6363);
        _3338 = find_from(_3337, _17SLASHES_5862, 1);
        _3337 = NOVALUE;
        if (_3338 == 0)
        {
            _3338 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _3338 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_6357)){
                _3339 = SEQ_PTR(_path_6357)->length;
        }
        else {
            _3339 = 1;
        }
        if (_i_6363 != _3339)
        goto L2; // [69] 95

        /** 				return path*/
        DeRefDSi(_defext_6358);
        return _path_6357;
        goto L5; // [79] 87

        /** 				exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** 	end for*/
        _i_6363 = _i_6363 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_6358);
    _3341 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3341 == 46)
    goto L6; // [101] 112

    /** 		path &= '.'*/
    Append(&_path_6357, _path_6357, 46);
L6: 

    /** 	return path & defext*/
    Concat((object_ptr)&_3344, _path_6357, _defext_6358);
    DeRefDS(_path_6357);
    DeRefDSi(_defext_6358);
    _3341 = NOVALUE;
    return _3344;
    ;
}


int _17absolute_path(int _filename_6382)
{
    int _3348 = NOVALUE;
    int _3347 = NOVALUE;
    int _3345 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_6382)){
            _3345 = SEQ_PTR(_filename_6382)->length;
    }
    else {
        _3345 = 1;
    }
    if (_3345 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_6382);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_6382);
    _3347 = (int)*(((s1_ptr)_2)->base + 1);
    _3348 = find_from(_3347, _17SLASHES_5862, 1);
    _3347 = NOVALUE;
    if (_3348 == 0)
    {
        _3348 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _3348 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_6382);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	return 0*/
    DeRefDS(_filename_6382);
    return 0;
    ;
}


int _17canonical_path(int _path_in_6402, int _directory_given_6403, int _case_flags_6404)
{
    int _lPath_6405 = NOVALUE;
    int _lPosA_6406 = NOVALUE;
    int _lPosB_6407 = NOVALUE;
    int _lLevel_6408 = NOVALUE;
    int _lHome_6409 = NOVALUE;
    int _wildcard_suffix_6451 = NOVALUE;
    int _first_wildcard_at_6452 = NOVALUE;
    int _last_slash_6455 = NOVALUE;
    int _sl_6508 = NOVALUE;
    int _short_name_6511 = NOVALUE;
    int _correct_name_6514 = NOVALUE;
    int _lower_name_6517 = NOVALUE;
    int _part_6533 = NOVALUE;
    int _list_6537 = NOVALUE;
    int _supplied_name_6540 = NOVALUE;
    int _read_name_6559 = NOVALUE;
    int _read_name_6584 = NOVALUE;
    int _3528 = NOVALUE;
    int _3526 = NOVALUE;
    int _3525 = NOVALUE;
    int _3524 = NOVALUE;
    int _3523 = NOVALUE;
    int _3522 = NOVALUE;
    int _3520 = NOVALUE;
    int _3519 = NOVALUE;
    int _3518 = NOVALUE;
    int _3517 = NOVALUE;
    int _3516 = NOVALUE;
    int _3515 = NOVALUE;
    int _3514 = NOVALUE;
    int _3513 = NOVALUE;
    int _3511 = NOVALUE;
    int _3510 = NOVALUE;
    int _3509 = NOVALUE;
    int _3508 = NOVALUE;
    int _3507 = NOVALUE;
    int _3506 = NOVALUE;
    int _3505 = NOVALUE;
    int _3504 = NOVALUE;
    int _3503 = NOVALUE;
    int _3501 = NOVALUE;
    int _3500 = NOVALUE;
    int _3499 = NOVALUE;
    int _3498 = NOVALUE;
    int _3497 = NOVALUE;
    int _3496 = NOVALUE;
    int _3495 = NOVALUE;
    int _3494 = NOVALUE;
    int _3493 = NOVALUE;
    int _3492 = NOVALUE;
    int _3491 = NOVALUE;
    int _3490 = NOVALUE;
    int _3489 = NOVALUE;
    int _3488 = NOVALUE;
    int _3487 = NOVALUE;
    int _3485 = NOVALUE;
    int _3484 = NOVALUE;
    int _3483 = NOVALUE;
    int _3482 = NOVALUE;
    int _3481 = NOVALUE;
    int _3479 = NOVALUE;
    int _3478 = NOVALUE;
    int _3477 = NOVALUE;
    int _3476 = NOVALUE;
    int _3475 = NOVALUE;
    int _3474 = NOVALUE;
    int _3473 = NOVALUE;
    int _3472 = NOVALUE;
    int _3471 = NOVALUE;
    int _3470 = NOVALUE;
    int _3469 = NOVALUE;
    int _3468 = NOVALUE;
    int _3467 = NOVALUE;
    int _3465 = NOVALUE;
    int _3464 = NOVALUE;
    int _3462 = NOVALUE;
    int _3461 = NOVALUE;
    int _3460 = NOVALUE;
    int _3459 = NOVALUE;
    int _3458 = NOVALUE;
    int _3456 = NOVALUE;
    int _3455 = NOVALUE;
    int _3454 = NOVALUE;
    int _3453 = NOVALUE;
    int _3452 = NOVALUE;
    int _3450 = NOVALUE;
    int _3448 = NOVALUE;
    int _3447 = NOVALUE;
    int _3445 = NOVALUE;
    int _3444 = NOVALUE;
    int _3442 = NOVALUE;
    int _3441 = NOVALUE;
    int _3440 = NOVALUE;
    int _3438 = NOVALUE;
    int _3437 = NOVALUE;
    int _3435 = NOVALUE;
    int _3433 = NOVALUE;
    int _3431 = NOVALUE;
    int _3424 = NOVALUE;
    int _3421 = NOVALUE;
    int _3420 = NOVALUE;
    int _3419 = NOVALUE;
    int _3418 = NOVALUE;
    int _3412 = NOVALUE;
    int _3408 = NOVALUE;
    int _3407 = NOVALUE;
    int _3406 = NOVALUE;
    int _3405 = NOVALUE;
    int _3404 = NOVALUE;
    int _3402 = NOVALUE;
    int _3401 = NOVALUE;
    int _3400 = NOVALUE;
    int _3398 = NOVALUE;
    int _3397 = NOVALUE;
    int _3396 = NOVALUE;
    int _3395 = NOVALUE;
    int _3393 = NOVALUE;
    int _3391 = NOVALUE;
    int _3387 = NOVALUE;
    int _3386 = NOVALUE;
    int _3384 = NOVALUE;
    int _3383 = NOVALUE;
    int _3382 = NOVALUE;
    int _3381 = NOVALUE;
    int _3380 = NOVALUE;
    int _3379 = NOVALUE;
    int _3378 = NOVALUE;
    int _3375 = NOVALUE;
    int _3374 = NOVALUE;
    int _3369 = NOVALUE;
    int _3368 = NOVALUE;
    int _3367 = NOVALUE;
    int _3366 = NOVALUE;
    int _3365 = NOVALUE;
    int _3363 = NOVALUE;
    int _3362 = NOVALUE;
    int _3361 = NOVALUE;
    int _3360 = NOVALUE;
    int _3359 = NOVALUE;
    int _3358 = NOVALUE;
    int _3357 = NOVALUE;
    int _3356 = NOVALUE;
    int _3355 = NOVALUE;
    int _3354 = NOVALUE;
    int _3353 = NOVALUE;
    int _0, _1, _2;
    

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_6405);
    _lPath_6405 = _5;

    /**     integer lPosA = -1*/
    _lPosA_6406 = -1;

    /**     integer lPosB = -1*/
    _lPosB_6407 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_6408);
    _lLevel_6408 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_6402);
    DeRefDS(_path_in_6402);
    _path_in_6402 = _path_in_6402;

    /** 	ifdef UNIX then*/

    /** 		lPath = path_in*/
    RefDS(_path_in_6402);
    DeRefDS(_lPath_6405);
    _lPath_6405 = _path_in_6402;

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3353 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3353 = 1;
    }
    _3354 = (_3353 > 2);
    _3353 = NOVALUE;
    if (_3354 == 0) {
        _3355 = 0;
        goto L1; // [56] 72
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3356 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3356)) {
        _3357 = (_3356 == 34);
    }
    else {
        _3357 = binary_op(EQUALS, _3356, 34);
    }
    _3356 = NOVALUE;
    if (IS_ATOM_INT(_3357))
    _3355 = (_3357 != 0);
    else
    _3355 = DBL_PTR(_3357)->dbl != 0.0;
L1: 
    if (_3355 == 0) {
        DeRef(_3358);
        _3358 = 0;
        goto L2; // [72] 91
    }
    if (IS_SEQUENCE(_lPath_6405)){
            _3359 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3359 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3360 = (int)*(((s1_ptr)_2)->base + _3359);
    if (IS_ATOM_INT(_3360)) {
        _3361 = (_3360 == 34);
    }
    else {
        _3361 = binary_op(EQUALS, _3360, 34);
    }
    _3360 = NOVALUE;
    if (IS_ATOM_INT(_3361))
    _3358 = (_3361 != 0);
    else
    _3358 = DBL_PTR(_3361)->dbl != 0.0;
L2: 
    if (_3358 == 0)
    {
        _3358 = NOVALUE;
        goto L3; // [91] 109
    }
    else{
        _3358 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3362 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3362 = 1;
    }
    _3363 = _3362 - 1;
    _3362 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_6405;
    RHS_Slice(_lPath_6405, 2, _3363);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3365 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3365 = 1;
    }
    _3366 = (_3365 > 0);
    _3365 = NOVALUE;
    if (_3366 == 0) {
        DeRef(_3367);
        _3367 = 0;
        goto L4; // [118] 134
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3368 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3368)) {
        _3369 = (_3368 == 126);
    }
    else {
        _3369 = binary_op(EQUALS, _3368, 126);
    }
    _3368 = NOVALUE;
    if (IS_ATOM_INT(_3369))
    _3367 = (_3369 != 0);
    else
    _3367 = DBL_PTR(_3369)->dbl != 0.0;
L4: 
    if (_3367 == 0)
    {
        _3367 = NOVALUE;
        goto L5; // [134] 222
    }
    else{
        _3367 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRefi(_lHome_6409);
    _lHome_6409 = EGetEnv(_3370);

    /** 		ifdef WINDOWS then*/

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_6409)){
            _3374 = SEQ_PTR(_lHome_6409)->length;
    }
    else {
        _3374 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_6409);
    _3375 = (int)*(((s1_ptr)_2)->base + _3374);
    if (_3375 == 47)
    goto L6; // [153] 164

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_6409) && IS_ATOM(47)) {
        Append(&_lHome_6409, _lHome_6409, 47);
    }
    else if (IS_ATOM(_lHome_6409) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_lHome_6409, _lHome_6409, 47);
    }
L6: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3378 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3378 = 1;
    }
    _3379 = (_3378 > 1);
    _3378 = NOVALUE;
    if (_3379 == 0) {
        goto L7; // [173] 206
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3381 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3381)) {
        _3382 = (_3381 == 47);
    }
    else {
        _3382 = binary_op(EQUALS, _3381, 47);
    }
    _3381 = NOVALUE;
    if (_3382 == 0) {
        DeRef(_3382);
        _3382 = NOVALUE;
        goto L7; // [186] 206
    }
    else {
        if (!IS_ATOM_INT(_3382) && DBL_PTR(_3382)->dbl == 0.0){
            DeRef(_3382);
            _3382 = NOVALUE;
            goto L7; // [186] 206
        }
        DeRef(_3382);
        _3382 = NOVALUE;
    }
    DeRef(_3382);
    _3382 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3383 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3383 = 1;
    }
    rhs_slice_target = (object_ptr)&_3384;
    RHS_Slice(_lPath_6405, 3, _3383);
    if (IS_SEQUENCE(_lHome_6409) && IS_ATOM(_3384)) {
    }
    else if (IS_ATOM(_lHome_6409) && IS_SEQUENCE(_3384)) {
        Ref(_lHome_6409);
        Prepend(&_lPath_6405, _3384, _lHome_6409);
    }
    else {
        Concat((object_ptr)&_lPath_6405, _lHome_6409, _3384);
    }
    DeRefDS(_3384);
    _3384 = NOVALUE;
    goto L8; // [203] 221
L7: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3386 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3386 = 1;
    }
    rhs_slice_target = (object_ptr)&_3387;
    RHS_Slice(_lPath_6405, 2, _3386);
    if (IS_SEQUENCE(_lHome_6409) && IS_ATOM(_3387)) {
    }
    else if (IS_ATOM(_lHome_6409) && IS_SEQUENCE(_3387)) {
        Ref(_lHome_6409);
        Prepend(&_lPath_6405, _3387, _lHome_6409);
    }
    else {
        Concat((object_ptr)&_lPath_6405, _lHome_6409, _3387);
    }
    DeRefDS(_3387);
    _3387 = NOVALUE;
L8: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_6405);
    _first_wildcard_at_6452 = _17find_first_wildcard(_lPath_6405, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_6452)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_6452)->dbl);
        DeRefDS(_first_wildcard_at_6452);
        _first_wildcard_at_6452 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_6452 == 0)
    {
        goto L9; // [237] 298
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_6405);
    _last_slash_6455 = _16rfind(47, _lPath_6405, _first_wildcard_at_6452);
    if (!IS_ATOM_INT(_last_slash_6455)) {
        _1 = (long)(DBL_PTR(_last_slash_6455)->dbl);
        DeRefDS(_last_slash_6455);
        _last_slash_6455 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_6455 == 0)
    {
        goto LA; // [252] 278
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3391 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3391 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_6451;
    RHS_Slice(_lPath_6405, _last_slash_6455, _3391);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3393 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3393 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6405);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_6455)) ? _last_slash_6455 : (long)(DBL_PTR(_last_slash_6455)->dbl);
        int stop = (IS_ATOM_INT(_3393)) ? _3393 : (long)(DBL_PTR(_3393)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6405), start, &_lPath_6405 );
            }
            else Tail(SEQ_PTR(_lPath_6405), stop+1, &_lPath_6405);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6405), start, &_lPath_6405);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6405 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6405)->ref == 1));
        }
    }
    _3393 = NOVALUE;
    goto LB; // [275] 293
LA: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_6405);
    DeRef(_wildcard_suffix_6451);
    _wildcard_suffix_6451 = _lPath_6405;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_6405);
    _lPath_6405 = _5;
LB: 
    goto LC; // [295] 306
L9: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_6451);
    _wildcard_suffix_6451 = _5;
LC: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3395 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3395 = 1;
    }
    _3396 = (_3395 == 0);
    _3395 = NOVALUE;
    if (_3396 != 0) {
        DeRef(_3397);
        _3397 = 1;
        goto LD; // [315] 335
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3398 = (int)*(((s1_ptr)_2)->base + 1);
    _3400 = find_from(_3398, _3399, 1);
    _3398 = NOVALUE;
    _3401 = (_3400 == 0);
    _3400 = NOVALUE;
    _3397 = (_3401 != 0);
LD: 
    if (_3397 == 0)
    {
        _3397 = NOVALUE;
        goto LE; // [335] 351
    }
    else{
        _3397 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			lPath = curdir() & lPath*/
    _3402 = _17curdir(0);
    if (IS_SEQUENCE(_3402) && IS_ATOM(_lPath_6405)) {
    }
    else if (IS_ATOM(_3402) && IS_SEQUENCE(_lPath_6405)) {
        Ref(_3402);
        Prepend(&_lPath_6405, _lPath_6405, _3402);
    }
    else {
        Concat((object_ptr)&_lPath_6405, _3402, _lPath_6405);
        DeRef(_3402);
        _3402 = NOVALUE;
    }
    DeRef(_3402);
    _3402 = NOVALUE;
LE: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _3404 = (_directory_given_6403 != 0);
    if (_3404 == 0) {
        DeRef(_3405);
        _3405 = 0;
        goto LF; // [357] 376
    }
    if (IS_SEQUENCE(_lPath_6405)){
            _3406 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3406 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3407 = (int)*(((s1_ptr)_2)->base + _3406);
    if (IS_ATOM_INT(_3407)) {
        _3408 = (_3407 != 47);
    }
    else {
        _3408 = binary_op(NOTEQ, _3407, 47);
    }
    _3407 = NOVALUE;
    if (IS_ATOM_INT(_3408))
    _3405 = (_3408 != 0);
    else
    _3405 = DBL_PTR(_3408)->dbl != 0.0;
LF: 
    if (_3405 == 0)
    {
        _3405 = NOVALUE;
        goto L10; // [376] 386
    }
    else{
        _3405 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_6405, _lPath_6405, 47);
L10: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = 46;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_6408, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_6406 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L11; // [401] 422
L12: 
    if (_lPosA_6406 == 0)
    goto L13; // [404] 434

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _3412 = _lPosA_6406 + 1;
    if (_3412 > MAXINT){
        _3412 = NewDouble((double)_3412);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6405);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_6406)) ? _lPosA_6406 : (long)(DBL_PTR(_lPosA_6406)->dbl);
        int stop = (IS_ATOM_INT(_3412)) ? _3412 : (long)(DBL_PTR(_3412)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6405), start, &_lPath_6405 );
            }
            else Tail(SEQ_PTR(_lPath_6405), stop+1, &_lPath_6405);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6405), start, &_lPath_6405);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6405 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6405)->ref == 1));
        }
    }
    DeRef(_3412);
    _3412 = NOVALUE;

    /** 	  entry*/
L11: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_6406 = e_match_from(_lLevel_6408, _lPath_6405, _lPosA_6406);

    /** 	end while*/
    goto L12; // [431] 404
L13: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = _3161;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_6408, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_6407 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L14; // [449] 527
L15: 
    if (_lPosA_6406 == 0)
    goto L16; // [452] 539

    /** 		lPosB = lPosA-1*/
    _lPosB_6407 = _lPosA_6406 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L17: 
    _3418 = (_lPosB_6407 > 0);
    if (_3418 == 0) {
        DeRef(_3419);
        _3419 = 0;
        goto L18; // [471] 487
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3420 = (int)*(((s1_ptr)_2)->base + _lPosB_6407);
    if (IS_ATOM_INT(_3420)) {
        _3421 = (_3420 != 47);
    }
    else {
        _3421 = binary_op(NOTEQ, _3420, 47);
    }
    _3420 = NOVALUE;
    if (IS_ATOM_INT(_3421))
    _3419 = (_3421 != 0);
    else
    _3419 = DBL_PTR(_3421)->dbl != 0.0;
L18: 
    if (_3419 == 0)
    {
        _3419 = NOVALUE;
        goto L19; // [487] 501
    }
    else{
        _3419 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_6407 = _lPosB_6407 - 1;

    /** 		end while*/
    goto L17; // [498] 467
L19: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_6407 > 0)
    goto L1A; // [503] 513

    /** 			lPosB = 1*/
    _lPosB_6407 = 1;
L1A: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _3424 = _lPosA_6406 + 2;
    if ((long)((unsigned long)_3424 + (unsigned long)HIGH_BITS) >= 0) 
    _3424 = NewDouble((double)_3424);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_6405);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_6407)) ? _lPosB_6407 : (long)(DBL_PTR(_lPosB_6407)->dbl);
        int stop = (IS_ATOM_INT(_3424)) ? _3424 : (long)(DBL_PTR(_3424)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_6405), start, &_lPath_6405 );
            }
            else Tail(SEQ_PTR(_lPath_6405), stop+1, &_lPath_6405);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_6405), start, &_lPath_6405);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_6405 = Remove_elements(start, stop, (SEQ_PTR(_lPath_6405)->ref == 1));
        }
    }
    DeRef(_3424);
    _3424 = NOVALUE;

    /** 	  entry*/
L14: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_6406 = e_match_from(_lLevel_6408, _lPath_6405, _lPosB_6407);

    /** 	end while*/
    goto L15; // [536] 452
L16: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_6404 != 1)
    goto L1B; // [541] 556

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_6405);
    _0 = _lPath_6405;
    _lPath_6405 = _14lower(_lPath_6405);
    DeRefDS(_0);
    goto L1C; // [553] 1149
L1B: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_6404 == 0)
    goto L1D; // [558] 1146

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_6405);
    _0 = _sl_6508;
    _sl_6508 = _16find_all(47, _lPath_6405, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_6404;
         _3431 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3431)) {
        _short_name_6511 = (_3431 == 4);
    }
    else {
        _short_name_6511 = (DBL_PTR(_3431)->dbl == (double)4);
    }
    DeRef(_3431);
    _3431 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_6404 & (unsigned long)2;
         _3433 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3433)) {
        _correct_name_6514 = (_3433 == 2);
    }
    else {
        _correct_name_6514 = (DBL_PTR(_3433)->dbl == (double)2);
    }
    DeRef(_3433);
    _3433 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_6404;
         _3435 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3435)) {
        _lower_name_6517 = (_3435 == 1);
    }
    else {
        _lower_name_6517 = (DBL_PTR(_3435)->dbl == (double)1);
    }
    DeRef(_3435);
    _3435 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3437 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3437 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_6405);
    _3438 = (int)*(((s1_ptr)_2)->base + _3437);
    if (binary_op_a(EQUALS, _3438, 47)){
        _3438 = NOVALUE;
        goto L1E; // [611] 633
    }
    _3438 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_6405)){
            _3440 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3440 = 1;
    }
    _3441 = _3440 + 1;
    _3440 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3441;
    _3442 = MAKE_SEQ(_1);
    _3441 = NOVALUE;
    Concat((object_ptr)&_sl_6508, _sl_6508, _3442);
    DeRefDS(_3442);
    _3442 = NOVALUE;
L1E: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_6508)){
            _3444 = SEQ_PTR(_sl_6508)->length;
    }
    else {
        _3444 = 1;
    }
    _3445 = _3444 - 1;
    _3444 = NOVALUE;
    {
        int _i_6529;
        _i_6529 = _3445;
L1F: 
        if (_i_6529 < 1){
            goto L20; // [642] 1111
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_6508);
        _3447 = (int)*(((s1_ptr)_2)->base + _i_6529);
        if (IS_ATOM_INT(_3447)) {
            _3448 = _3447 - 1;
        }
        else {
            _3448 = binary_op(MINUS, _3447, 1);
        }
        _3447 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_6533;
        RHS_Slice(_lPath_6405, 1, _3448);

        /** 			object list = dir( part & SLASH )*/
        Append(&_3450, _part_6533, 47);
        _0 = _list_6537;
        _list_6537 = _17dir(_3450);
        DeRef(_0);
        _3450 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_6508);
        _3452 = (int)*(((s1_ptr)_2)->base + _i_6529);
        if (IS_ATOM_INT(_3452)) {
            _3453 = _3452 + 1;
            if (_3453 > MAXINT){
                _3453 = NewDouble((double)_3453);
            }
        }
        else
        _3453 = binary_op(PLUS, 1, _3452);
        _3452 = NOVALUE;
        _3454 = _i_6529 + 1;
        _2 = (int)SEQ_PTR(_sl_6508);
        _3455 = (int)*(((s1_ptr)_2)->base + _3454);
        if (IS_ATOM_INT(_3455)) {
            _3456 = _3455 - 1;
        }
        else {
            _3456 = binary_op(MINUS, _3455, 1);
        }
        _3455 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_6540;
        RHS_Slice(_lPath_6405, _3453, _3456);

        /** 			if atom(list) then*/
        _3458 = IS_ATOM(_list_6537);
        if (_3458 == 0)
        {
            _3458 = NOVALUE;
            goto L21; // [706] 744
        }
        else{
            _3458 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_6517 == 0)
        {
            goto L22; // [711] 737
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_6508);
        _3459 = (int)*(((s1_ptr)_2)->base + _i_6529);
        if (IS_SEQUENCE(_lPath_6405)){
                _3460 = SEQ_PTR(_lPath_6405)->length;
        }
        else {
            _3460 = 1;
        }
        rhs_slice_target = (object_ptr)&_3461;
        RHS_Slice(_lPath_6405, _3459, _3460);
        _3462 = _14lower(_3461);
        _3461 = NOVALUE;
        if (IS_SEQUENCE(_part_6533) && IS_ATOM(_3462)) {
            Ref(_3462);
            Append(&_lPath_6405, _part_6533, _3462);
        }
        else if (IS_ATOM(_part_6533) && IS_SEQUENCE(_3462)) {
        }
        else {
            Concat((object_ptr)&_lPath_6405, _part_6533, _3462);
        }
        DeRef(_3462);
        _3462 = NOVALUE;
L22: 

        /** 				continue*/
        DeRef(_part_6533);
        _part_6533 = NOVALUE;
        DeRef(_list_6537);
        _list_6537 = NOVALUE;
        DeRef(_supplied_name_6540);
        _supplied_name_6540 = NOVALUE;
        goto L23; // [741] 1106
L21: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6537)){
                _3464 = SEQ_PTR(_list_6537)->length;
        }
        else {
            _3464 = 1;
        }
        {
            int _j_6557;
            _j_6557 = 1;
L24: 
            if (_j_6557 > _3464){
                goto L25; // [749] 874
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_6537);
            _3465 = (int)*(((s1_ptr)_2)->base + _j_6557);
            DeRef(_read_name_6559);
            _2 = (int)SEQ_PTR(_3465);
            _read_name_6559 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_6559);
            _3465 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_6559 == _supplied_name_6540)
            _3467 = 1;
            else if (IS_ATOM_INT(_read_name_6559) && IS_ATOM_INT(_supplied_name_6540))
            _3467 = 0;
            else
            _3467 = (compare(_read_name_6559, _supplied_name_6540) == 0);
            if (_3467 == 0)
            {
                _3467 = NOVALUE;
                goto L26; // [774] 865
            }
            else{
                _3467 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6511 == 0) {
                goto L27; // [779] 856
            }
            _2 = (int)SEQ_PTR(_list_6537);
            _3469 = (int)*(((s1_ptr)_2)->base + _j_6557);
            _2 = (int)SEQ_PTR(_3469);
            _3470 = (int)*(((s1_ptr)_2)->base + 11);
            _3469 = NOVALUE;
            _3471 = IS_SEQUENCE(_3470);
            _3470 = NOVALUE;
            if (_3471 == 0)
            {
                _3471 = NOVALUE;
                goto L27; // [795] 856
            }
            else{
                _3471 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6508);
            _3472 = (int)*(((s1_ptr)_2)->base + _i_6529);
            rhs_slice_target = (object_ptr)&_3473;
            RHS_Slice(_lPath_6405, 1, _3472);
            _2 = (int)SEQ_PTR(_list_6537);
            _3474 = (int)*(((s1_ptr)_2)->base + _j_6557);
            _2 = (int)SEQ_PTR(_3474);
            _3475 = (int)*(((s1_ptr)_2)->base + 11);
            _3474 = NOVALUE;
            _3476 = _i_6529 + 1;
            _2 = (int)SEQ_PTR(_sl_6508);
            _3477 = (int)*(((s1_ptr)_2)->base + _3476);
            if (IS_SEQUENCE(_lPath_6405)){
                    _3478 = SEQ_PTR(_lPath_6405)->length;
            }
            else {
                _3478 = 1;
            }
            rhs_slice_target = (object_ptr)&_3479;
            RHS_Slice(_lPath_6405, _3477, _3478);
            {
                int concat_list[3];

                concat_list[0] = _3479;
                concat_list[1] = _3475;
                concat_list[2] = _3473;
                Concat_N((object_ptr)&_lPath_6405, concat_list, 3);
            }
            DeRefDS(_3479);
            _3479 = NOVALUE;
            _3475 = NOVALUE;
            DeRefDS(_3473);
            _3473 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6508)){
                    _3481 = SEQ_PTR(_sl_6508)->length;
            }
            else {
                _3481 = 1;
            }
            if (IS_SEQUENCE(_lPath_6405)){
                    _3482 = SEQ_PTR(_lPath_6405)->length;
            }
            else {
                _3482 = 1;
            }
            _3483 = _3482 + 1;
            _3482 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_6508);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_6508 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _3481);
            _1 = *(int *)_2;
            *(int *)_2 = _3483;
            if( _1 != _3483 ){
                DeRef(_1);
            }
            _3483 = NOVALUE;
L27: 

            /** 					continue "partloop"*/
            DeRef(_read_name_6559);
            _read_name_6559 = NOVALUE;
            DeRef(_part_6533);
            _part_6533 = NOVALUE;
            DeRef(_list_6537);
            _list_6537 = NOVALUE;
            DeRef(_supplied_name_6540);
            _supplied_name_6540 = NOVALUE;
            goto L23; // [862] 1106
L26: 
            DeRef(_read_name_6559);
            _read_name_6559 = NOVALUE;

            /** 			end for*/
            _j_6557 = _j_6557 + 1;
            goto L24; // [869] 756
L25: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_6537)){
                _3484 = SEQ_PTR(_list_6537)->length;
        }
        else {
            _3484 = 1;
        }
        {
            int _j_6582;
            _j_6582 = 1;
L28: 
            if (_j_6582 > _3484){
                goto L29; // [879] 1051
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_6537);
            _3485 = (int)*(((s1_ptr)_2)->base + _j_6582);
            DeRef(_read_name_6584);
            _2 = (int)SEQ_PTR(_3485);
            _read_name_6584 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_6584);
            _3485 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_6584);
            _3487 = _14lower(_read_name_6584);
            RefDS(_supplied_name_6540);
            _3488 = _14lower(_supplied_name_6540);
            if (_3487 == _3488)
            _3489 = 1;
            else if (IS_ATOM_INT(_3487) && IS_ATOM_INT(_3488))
            _3489 = 0;
            else
            _3489 = (compare(_3487, _3488) == 0);
            DeRef(_3487);
            _3487 = NOVALUE;
            DeRef(_3488);
            _3488 = NOVALUE;
            if (_3489 == 0)
            {
                _3489 = NOVALUE;
                goto L2A; // [912] 1042
            }
            else{
                _3489 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_6511 == 0) {
                goto L2B; // [917] 994
            }
            _2 = (int)SEQ_PTR(_list_6537);
            _3491 = (int)*(((s1_ptr)_2)->base + _j_6582);
            _2 = (int)SEQ_PTR(_3491);
            _3492 = (int)*(((s1_ptr)_2)->base + 11);
            _3491 = NOVALUE;
            _3493 = IS_SEQUENCE(_3492);
            _3492 = NOVALUE;
            if (_3493 == 0)
            {
                _3493 = NOVALUE;
                goto L2B; // [933] 994
            }
            else{
                _3493 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6508);
            _3494 = (int)*(((s1_ptr)_2)->base + _i_6529);
            rhs_slice_target = (object_ptr)&_3495;
            RHS_Slice(_lPath_6405, 1, _3494);
            _2 = (int)SEQ_PTR(_list_6537);
            _3496 = (int)*(((s1_ptr)_2)->base + _j_6582);
            _2 = (int)SEQ_PTR(_3496);
            _3497 = (int)*(((s1_ptr)_2)->base + 11);
            _3496 = NOVALUE;
            _3498 = _i_6529 + 1;
            _2 = (int)SEQ_PTR(_sl_6508);
            _3499 = (int)*(((s1_ptr)_2)->base + _3498);
            if (IS_SEQUENCE(_lPath_6405)){
                    _3500 = SEQ_PTR(_lPath_6405)->length;
            }
            else {
                _3500 = 1;
            }
            rhs_slice_target = (object_ptr)&_3501;
            RHS_Slice(_lPath_6405, _3499, _3500);
            {
                int concat_list[3];

                concat_list[0] = _3501;
                concat_list[1] = _3497;
                concat_list[2] = _3495;
                Concat_N((object_ptr)&_lPath_6405, concat_list, 3);
            }
            DeRefDS(_3501);
            _3501 = NOVALUE;
            _3497 = NOVALUE;
            DeRefDS(_3495);
            _3495 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_6508)){
                    _3503 = SEQ_PTR(_sl_6508)->length;
            }
            else {
                _3503 = 1;
            }
            if (IS_SEQUENCE(_lPath_6405)){
                    _3504 = SEQ_PTR(_lPath_6405)->length;
            }
            else {
                _3504 = 1;
            }
            _3505 = _3504 + 1;
            _3504 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_6508);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_6508 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _3503);
            _1 = *(int *)_2;
            *(int *)_2 = _3505;
            if( _1 != _3505 ){
                DeRef(_1);
            }
            _3505 = NOVALUE;
L2B: 

            /** 					if correct_name then*/
            if (_correct_name_6514 == 0)
            {
                goto L2C; // [996] 1033
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_6508);
            _3506 = (int)*(((s1_ptr)_2)->base + _i_6529);
            rhs_slice_target = (object_ptr)&_3507;
            RHS_Slice(_lPath_6405, 1, _3506);
            _3508 = _i_6529 + 1;
            _2 = (int)SEQ_PTR(_sl_6508);
            _3509 = (int)*(((s1_ptr)_2)->base + _3508);
            if (IS_SEQUENCE(_lPath_6405)){
                    _3510 = SEQ_PTR(_lPath_6405)->length;
            }
            else {
                _3510 = 1;
            }
            rhs_slice_target = (object_ptr)&_3511;
            RHS_Slice(_lPath_6405, _3509, _3510);
            {
                int concat_list[3];

                concat_list[0] = _3511;
                concat_list[1] = _read_name_6584;
                concat_list[2] = _3507;
                Concat_N((object_ptr)&_lPath_6405, concat_list, 3);
            }
            DeRefDS(_3511);
            _3511 = NOVALUE;
            DeRefDS(_3507);
            _3507 = NOVALUE;
L2C: 

            /** 					continue "partloop"*/
            DeRef(_read_name_6584);
            _read_name_6584 = NOVALUE;
            DeRef(_part_6533);
            _part_6533 = NOVALUE;
            DeRef(_list_6537);
            _list_6537 = NOVALUE;
            DeRef(_supplied_name_6540);
            _supplied_name_6540 = NOVALUE;
            goto L23; // [1039] 1106
L2A: 
            DeRef(_read_name_6584);
            _read_name_6584 = NOVALUE;

            /** 			end for*/
            _j_6582 = _j_6582 + 1;
            goto L28; // [1046] 886
L29: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_6404;
             _3513 = MAKE_UINT(tu);
        }
        if (_3513 == 0) {
            DeRef(_3513);
            _3513 = NOVALUE;
            goto L2D; // [1057] 1096
        }
        else {
            if (!IS_ATOM_INT(_3513) && DBL_PTR(_3513)->dbl == 0.0){
                DeRef(_3513);
                _3513 = NOVALUE;
                goto L2D; // [1057] 1096
            }
            DeRef(_3513);
            _3513 = NOVALUE;
        }
        DeRef(_3513);
        _3513 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_6508);
        _3514 = (int)*(((s1_ptr)_2)->base + _i_6529);
        if (IS_ATOM_INT(_3514)) {
            _3515 = _3514 - 1;
        }
        else {
            _3515 = binary_op(MINUS, _3514, 1);
        }
        _3514 = NOVALUE;
        rhs_slice_target = (object_ptr)&_3516;
        RHS_Slice(_lPath_6405, 1, _3515);
        _2 = (int)SEQ_PTR(_sl_6508);
        _3517 = (int)*(((s1_ptr)_2)->base + _i_6529);
        if (IS_SEQUENCE(_lPath_6405)){
                _3518 = SEQ_PTR(_lPath_6405)->length;
        }
        else {
            _3518 = 1;
        }
        rhs_slice_target = (object_ptr)&_3519;
        RHS_Slice(_lPath_6405, _3517, _3518);
        _3520 = _14lower(_3519);
        _3519 = NOVALUE;
        if (IS_SEQUENCE(_3516) && IS_ATOM(_3520)) {
            Ref(_3520);
            Append(&_lPath_6405, _3516, _3520);
        }
        else if (IS_ATOM(_3516) && IS_SEQUENCE(_3520)) {
        }
        else {
            Concat((object_ptr)&_lPath_6405, _3516, _3520);
            DeRefDS(_3516);
            _3516 = NOVALUE;
        }
        DeRef(_3516);
        _3516 = NOVALUE;
        DeRef(_3520);
        _3520 = NOVALUE;
L2D: 

        /** 			exit*/
        DeRef(_part_6533);
        _part_6533 = NOVALUE;
        DeRef(_list_6537);
        _list_6537 = NOVALUE;
        DeRef(_supplied_name_6540);
        _supplied_name_6540 = NOVALUE;
        goto L20; // [1100] 1111

        /** 		end for*/
L23: 
        _i_6529 = _i_6529 + -1;
        goto L1F; // [1106] 649
L20: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _3522 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_3522)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_6404 & (unsigned long)_3522;
             _3523 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_6404;
        _3523 = Dand_bits(&temp_d, DBL_PTR(_3522));
    }
    DeRef(_3522);
    _3522 = NOVALUE;
    if (IS_ATOM_INT(_3523)) {
        _3524 = (_3523 == 1);
    }
    else {
        _3524 = (DBL_PTR(_3523)->dbl == (double)1);
    }
    DeRef(_3523);
    _3523 = NOVALUE;
    if (_3524 == 0) {
        goto L2E; // [1125] 1145
    }
    if (IS_SEQUENCE(_lPath_6405)){
            _3526 = SEQ_PTR(_lPath_6405)->length;
    }
    else {
        _3526 = 1;
    }
    if (_3526 == 0)
    {
        _3526 = NOVALUE;
        goto L2E; // [1133] 1145
    }
    else{
        _3526 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_6405);
    _0 = _lPath_6405;
    _lPath_6405 = _14lower(_lPath_6405);
    DeRefDS(_0);
L2E: 
L1D: 
    DeRef(_sl_6508);
    _sl_6508 = NOVALUE;
L1C: 

    /** 	ifdef WINDOWS then*/

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_3528, _lPath_6405, _wildcard_suffix_6451);
    DeRefDS(_path_in_6402);
    DeRefDS(_lPath_6405);
    DeRefi(_lLevel_6408);
    DeRefi(_lHome_6409);
    DeRefDS(_wildcard_suffix_6451);
    DeRef(_3396);
    _3396 = NOVALUE;
    DeRef(_3421);
    _3421 = NOVALUE;
    DeRef(_3453);
    _3453 = NOVALUE;
    _3477 = NOVALUE;
    DeRef(_3369);
    _3369 = NOVALUE;
    DeRef(_3404);
    _3404 = NOVALUE;
    DeRef(_3361);
    _3361 = NOVALUE;
    DeRef(_3366);
    _3366 = NOVALUE;
    DeRef(_3454);
    _3454 = NOVALUE;
    _3494 = NOVALUE;
    DeRef(_3498);
    _3498 = NOVALUE;
    DeRef(_3508);
    _3508 = NOVALUE;
    DeRef(_3357);
    _3357 = NOVALUE;
    DeRef(_3456);
    _3456 = NOVALUE;
    _3459 = NOVALUE;
    _3499 = NOVALUE;
    _3517 = NOVALUE;
    DeRef(_3515);
    _3515 = NOVALUE;
    _3509 = NOVALUE;
    DeRef(_3363);
    _3363 = NOVALUE;
    DeRef(_3445);
    _3445 = NOVALUE;
    DeRef(_3418);
    _3418 = NOVALUE;
    DeRef(_3401);
    _3401 = NOVALUE;
    DeRef(_3524);
    _3524 = NOVALUE;
    DeRef(_3354);
    _3354 = NOVALUE;
    _3375 = NOVALUE;
    DeRef(_3408);
    _3408 = NOVALUE;
    _3506 = NOVALUE;
    DeRef(_3379);
    _3379 = NOVALUE;
    DeRef(_3448);
    _3448 = NOVALUE;
    DeRef(_3476);
    _3476 = NOVALUE;
    _3472 = NOVALUE;
    return _3528;
    ;
}


int _17abbreviate_path(int _orig_path_6643, int _base_paths_6644)
{
    int _expanded_path_6645 = NOVALUE;
    int _fs_case_inlined_fs_case_at_61_6655 = NOVALUE;
    int _lowered_expanded_path_6656 = NOVALUE;
    int _fs_case_inlined_fs_case_at_73_6658 = NOVALUE;
    int _fs_case_inlined_fs_case_at_216_6685 = NOVALUE;
    int _s_inlined_fs_case_at_213_6684 = NOVALUE;
    int _3564 = NOVALUE;
    int _3563 = NOVALUE;
    int _3560 = NOVALUE;
    int _3559 = NOVALUE;
    int _3558 = NOVALUE;
    int _3557 = NOVALUE;
    int _3556 = NOVALUE;
    int _3554 = NOVALUE;
    int _3553 = NOVALUE;
    int _3552 = NOVALUE;
    int _3551 = NOVALUE;
    int _3550 = NOVALUE;
    int _3549 = NOVALUE;
    int _3548 = NOVALUE;
    int _3547 = NOVALUE;
    int _3544 = NOVALUE;
    int _3543 = NOVALUE;
    int _3542 = NOVALUE;
    int _3541 = NOVALUE;
    int _3540 = NOVALUE;
    int _3539 = NOVALUE;
    int _3538 = NOVALUE;
    int _3537 = NOVALUE;
    int _3536 = NOVALUE;
    int _3535 = NOVALUE;
    int _3534 = NOVALUE;
    int _3533 = NOVALUE;
    int _3532 = NOVALUE;
    int _3530 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_6643);
    _0 = _expanded_path_6645;
    _expanded_path_6645 = _17canonical_path(_orig_path_6643, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _3530 = _17curdir(0);
    Ref(_3530);
    Append(&_base_paths_6644, _base_paths_6644, _3530);
    DeRef(_3530);
    _3530 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    _3532 = 1;
    {
        int _i_6650;
        _i_6650 = 1;
L1: 
        if (_i_6650 > 1){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_6644);
        _3533 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_3533);
        _3534 = _17canonical_path(_3533, 1, 0);
        _3533 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_6644);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_6644 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _3534;
        if( _1 != _3534 ){
            DeRef(_1);
        }
        _3534 = NOVALUE;

        /** 	end for*/
        _i_6650 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_base_paths_6644);
    DeRefDS(_base_paths_6644);
    _base_paths_6644 = _base_paths_6644;

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_expanded_path_6645);
    DeRef(_lowered_expanded_path_6656);
    _lowered_expanded_path_6656 = _expanded_path_6645;

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_6644)){
            _3535 = SEQ_PTR(_base_paths_6644)->length;
    }
    else {
        _3535 = 1;
    }
    {
        int _i_6660;
        _i_6660 = 1;
L3: 
        if (_i_6660 > _3535){
            goto L4; // [89] 143
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_6644);
        _3536 = (int)*(((s1_ptr)_2)->base + _i_6660);
        Ref(_3536);
        RefDS(_lowered_expanded_path_6656);
        _3537 = _16begins(_3536, _lowered_expanded_path_6656);
        _3536 = NOVALUE;
        if (_3537 == 0) {
            DeRef(_3537);
            _3537 = NOVALUE;
            goto L5; // [107] 136
        }
        else {
            if (!IS_ATOM_INT(_3537) && DBL_PTR(_3537)->dbl == 0.0){
                DeRef(_3537);
                _3537 = NOVALUE;
                goto L5; // [107] 136
            }
            DeRef(_3537);
            _3537 = NOVALUE;
        }
        DeRef(_3537);
        _3537 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_6644);
        _3538 = (int)*(((s1_ptr)_2)->base + _i_6660);
        if (IS_SEQUENCE(_3538)){
                _3539 = SEQ_PTR(_3538)->length;
        }
        else {
            _3539 = 1;
        }
        _3538 = NOVALUE;
        _3540 = _3539 + 1;
        _3539 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6645)){
                _3541 = SEQ_PTR(_expanded_path_6645)->length;
        }
        else {
            _3541 = 1;
        }
        rhs_slice_target = (object_ptr)&_3542;
        RHS_Slice(_expanded_path_6645, _3540, _3541);
        DeRefDS(_orig_path_6643);
        DeRefDS(_base_paths_6644);
        DeRefDS(_expanded_path_6645);
        DeRefDS(_lowered_expanded_path_6656);
        _3538 = NOVALUE;
        _3540 = NOVALUE;
        return _3542;
L5: 

        /** 	end for*/
        _i_6660 = _i_6660 + 1;
        goto L3; // [138] 96
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_6644)){
            _3543 = SEQ_PTR(_base_paths_6644)->length;
    }
    else {
        _3543 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_6644);
    _3544 = (int)*(((s1_ptr)_2)->base + _3543);
    Ref(_3544);
    _0 = _base_paths_6644;
    _base_paths_6644 = _23split(_3544, 47, 0, 0);
    DeRefDS(_0);
    _3544 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_6645);
    _0 = _expanded_path_6645;
    _expanded_path_6645 = _23split(_expanded_path_6645, 47, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_6656);
    _lowered_expanded_path_6656 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_6645)){
            _3547 = SEQ_PTR(_expanded_path_6645)->length;
    }
    else {
        _3547 = 1;
    }
    if (IS_SEQUENCE(_base_paths_6644)){
            _3548 = SEQ_PTR(_base_paths_6644)->length;
    }
    else {
        _3548 = 1;
    }
    _3549 = _3548 - 1;
    _3548 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3547;
    ((int *)_2)[2] = _3549;
    _3550 = MAKE_SEQ(_1);
    _3549 = NOVALUE;
    _3547 = NOVALUE;
    _3551 = _20min(_3550);
    _3550 = NOVALUE;
    {
        int _i_6675;
        _i_6675 = 1;
L6: 
        if (binary_op_a(GREATER, _i_6675, _3551)){
            goto L7; // [201] 305
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_6645);
        if (!IS_ATOM_INT(_i_6675)){
            _3552 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_6675)->dbl));
        }
        else{
            _3552 = (int)*(((s1_ptr)_2)->base + _i_6675);
        }
        Ref(_3552);
        DeRef(_s_inlined_fs_case_at_213_6684);
        _s_inlined_fs_case_at_213_6684 = _3552;
        _3552 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return s*/
        Ref(_s_inlined_fs_case_at_213_6684);
        DeRef(_fs_case_inlined_fs_case_at_216_6685);
        _fs_case_inlined_fs_case_at_216_6685 = _s_inlined_fs_case_at_213_6684;
        DeRef(_s_inlined_fs_case_at_213_6684);
        _s_inlined_fs_case_at_213_6684 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_6644);
        if (!IS_ATOM_INT(_i_6675)){
            _3553 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_6675)->dbl));
        }
        else{
            _3553 = (int)*(((s1_ptr)_2)->base + _i_6675);
        }
        if (_fs_case_inlined_fs_case_at_216_6685 == _3553)
        _3554 = 1;
        else if (IS_ATOM_INT(_fs_case_inlined_fs_case_at_216_6685) && IS_ATOM_INT(_3553))
        _3554 = 0;
        else
        _3554 = (compare(_fs_case_inlined_fs_case_at_216_6685, _3553) == 0);
        _3553 = NOVALUE;
        if (_3554 != 0)
        goto L8; // [237] 298
        _3554 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_6644)){
                _3556 = SEQ_PTR(_base_paths_6644)->length;
        }
        else {
            _3556 = 1;
        }
        if (IS_ATOM_INT(_i_6675)) {
            _3557 = _3556 - _i_6675;
        }
        else {
            _3557 = NewDouble((double)_3556 - DBL_PTR(_i_6675)->dbl);
        }
        _3556 = NOVALUE;
        _3558 = Repeat(_3161, _3557);
        DeRef(_3557);
        _3557 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_6645)){
                _3559 = SEQ_PTR(_expanded_path_6645)->length;
        }
        else {
            _3559 = 1;
        }
        rhs_slice_target = (object_ptr)&_3560;
        RHS_Slice(_expanded_path_6645, _i_6675, _3559);
        Concat((object_ptr)&_expanded_path_6645, _3558, _3560);
        DeRefDS(_3558);
        _3558 = NOVALUE;
        DeRef(_3558);
        _3558 = NOVALUE;
        DeRefDS(_3560);
        _3560 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_6645);
        _0 = _expanded_path_6645;
        _expanded_path_6645 = _23join(_expanded_path_6645, 47);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_6645)){
                _3563 = SEQ_PTR(_expanded_path_6645)->length;
        }
        else {
            _3563 = 1;
        }
        if (IS_SEQUENCE(_orig_path_6643)){
                _3564 = SEQ_PTR(_orig_path_6643)->length;
        }
        else {
            _3564 = 1;
        }
        if (_3563 >= _3564)
        goto L7; // [282] 305

        /** 		  		return expanded_path*/
        DeRef(_i_6675);
        DeRefDS(_orig_path_6643);
        DeRefDS(_base_paths_6644);
        DeRef(_lowered_expanded_path_6656);
        _3538 = NOVALUE;
        DeRef(_3540);
        _3540 = NOVALUE;
        DeRef(_3542);
        _3542 = NOVALUE;
        DeRef(_3551);
        _3551 = NOVALUE;
        return _expanded_path_6645;

        /** 			exit*/
        goto L7; // [295] 305
L8: 

        /** 	end for*/
        _0 = _i_6675;
        if (IS_ATOM_INT(_i_6675)) {
            _i_6675 = _i_6675 + 1;
            if ((long)((unsigned long)_i_6675 +(unsigned long) HIGH_BITS) >= 0){
                _i_6675 = NewDouble((double)_i_6675);
            }
        }
        else {
            _i_6675 = binary_op_a(PLUS, _i_6675, 1);
        }
        DeRef(_0);
        goto L6; // [300] 208
L7: 
        ;
        DeRef(_i_6675);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_6644);
    DeRef(_expanded_path_6645);
    DeRef(_lowered_expanded_path_6656);
    _3538 = NOVALUE;
    DeRef(_3540);
    _3540 = NOVALUE;
    DeRef(_3542);
    _3542 = NOVALUE;
    DeRef(_3551);
    _3551 = NOVALUE;
    return _orig_path_6643;
    ;
}


int _17file_type(int _filename_6733)
{
    int _dirfil_6734 = NOVALUE;
    int _3597 = NOVALUE;
    int _3596 = NOVALUE;
    int _3595 = NOVALUE;
    int _3594 = NOVALUE;
    int _3593 = NOVALUE;
    int _3591 = NOVALUE;
    int _3590 = NOVALUE;
    int _3589 = NOVALUE;
    int _3588 = NOVALUE;
    int _3587 = NOVALUE;
    int _3586 = NOVALUE;
    int _3585 = NOVALUE;
    int _3583 = NOVALUE;
    int _3581 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _3581 = find_from(42, _filename_6733, 1);
    if (_3581 != 0) {
        goto L1; // [10] 24
    }
    _3583 = find_from(63, _filename_6733, 1);
    if (_3583 == 0)
    {
        _3583 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _3583 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_6733);
    DeRef(_dirfil_6734);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	dirfil = dir(filename)*/
    RefDS(_filename_6733);
    _0 = _dirfil_6734;
    _dirfil_6734 = _17dir(_filename_6733);
    DeRef(_0);

    /** 	if sequence(dirfil) then*/
    _3585 = IS_SEQUENCE(_dirfil_6734);
    if (_3585 == 0)
    {
        _3585 = NOVALUE;
        goto L3; // [42] 126
    }
    else{
        _3585 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_6734)){
            _3586 = SEQ_PTR(_dirfil_6734)->length;
    }
    else {
        _3586 = 1;
    }
    _3587 = (_3586 > 1);
    _3586 = NOVALUE;
    if (_3587 != 0) {
        _3588 = 1;
        goto L4; // [54] 75
    }
    _2 = (int)SEQ_PTR(_dirfil_6734);
    _3589 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3589);
    _3590 = (int)*(((s1_ptr)_2)->base + 2);
    _3589 = NOVALUE;
    _3591 = find_from(100, _3590, 1);
    _3590 = NOVALUE;
    _3588 = (_3591 != 0);
L4: 
    if (_3588 != 0) {
        goto L5; // [75] 107
    }
    if (IS_SEQUENCE(_filename_6733)){
            _3593 = SEQ_PTR(_filename_6733)->length;
    }
    else {
        _3593 = 1;
    }
    _3594 = (_3593 == 3);
    _3593 = NOVALUE;
    if (_3594 == 0) {
        DeRef(_3595);
        _3595 = 0;
        goto L6; // [86] 102
    }
    _2 = (int)SEQ_PTR(_filename_6733);
    _3596 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_3596)) {
        _3597 = (_3596 == 58);
    }
    else {
        _3597 = binary_op(EQUALS, _3596, 58);
    }
    _3596 = NOVALUE;
    if (IS_ATOM_INT(_3597))
    _3595 = (_3597 != 0);
    else
    _3595 = DBL_PTR(_3597)->dbl != 0.0;
L6: 
    if (_3595 == 0)
    {
        _3595 = NOVALUE;
        goto L7; // [103] 116
    }
    else{
        _3595 = NOVALUE;
    }
L5: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_6733);
    DeRef(_dirfil_6734);
    DeRef(_3587);
    _3587 = NOVALUE;
    DeRef(_3594);
    _3594 = NOVALUE;
    DeRef(_3597);
    _3597 = NOVALUE;
    return 2;
    goto L8; // [113] 133
L7: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_6733);
    DeRef(_dirfil_6734);
    DeRef(_3587);
    _3587 = NOVALUE;
    DeRef(_3594);
    _3594 = NOVALUE;
    DeRef(_3597);
    _3597 = NOVALUE;
    return 1;
    goto L8; // [123] 133
L3: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_6733);
    DeRef(_dirfil_6734);
    DeRef(_3587);
    _3587 = NOVALUE;
    DeRef(_3594);
    _3594 = NOVALUE;
    DeRef(_3597);
    _3597 = NOVALUE;
    return 0;
L8: 
    ;
}


int _17file_exists(int _name_6773)
{
    int _pName_6776 = NOVALUE;
    int _r_6778 = NOVALUE;
    int _3602 = NOVALUE;
    int _3600 = NOVALUE;
    int _3598 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _3598 = IS_ATOM(_name_6773);
    if (_3598 == 0)
    {
        _3598 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _3598 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_6773);
    DeRef(_pName_6776);
    DeRef(_r_6778);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = machine:allocate_string(name)*/
    Ref(_name_6773);
    _0 = _pName_6776;
    _pName_6776 = _9allocate_string(_name_6773, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName, 0})*/
    Ref(_pName_6776);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pName_6776;
    ((int *)_2)[2] = 0;
    _3600 = MAKE_SEQ(_1);
    DeRef(_r_6778);
    _r_6778 = call_c(1, _17xGetFileAttributes_5850, _3600);
    DeRefDS(_3600);
    _3600 = NOVALUE;

    /** 		machine:free(pName)*/
    Ref(_pName_6776);
    _9free(_pName_6776);

    /** 		return r = 0*/
    if (IS_ATOM_INT(_r_6778)) {
        _3602 = (_r_6778 == 0);
    }
    else {
        _3602 = (DBL_PTR(_r_6778)->dbl == (double)0);
    }
    DeRef(_name_6773);
    DeRef(_pName_6776);
    DeRef(_r_6778);
    return _3602;
    ;
}


int _17file_timestamp(int _fname_6784)
{
    int _d_6785 = NOVALUE;
    int _3617 = NOVALUE;
    int _3616 = NOVALUE;
    int _3615 = NOVALUE;
    int _3614 = NOVALUE;
    int _3613 = NOVALUE;
    int _3612 = NOVALUE;
    int _3611 = NOVALUE;
    int _3610 = NOVALUE;
    int _3609 = NOVALUE;
    int _3608 = NOVALUE;
    int _3607 = NOVALUE;
    int _3606 = NOVALUE;
    int _3605 = NOVALUE;
    int _3604 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/
    RefDS(_fname_6784);
    _0 = _d_6785;
    _d_6785 = _17dir(_fname_6784);
    DeRef(_0);

    /** 	if atom(d) then return -1 end if*/
    _3604 = IS_ATOM(_d_6785);
    if (_3604 == 0)
    {
        _3604 = NOVALUE;
        goto L1; // [14] 22
    }
    else{
        _3604 = NOVALUE;
    }
    DeRefDS(_fname_6784);
    DeRef(_d_6785);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_6785);
    _3605 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3605);
    _3606 = (int)*(((s1_ptr)_2)->base + 4);
    _3605 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6785);
    _3607 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3607);
    _3608 = (int)*(((s1_ptr)_2)->base + 5);
    _3607 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6785);
    _3609 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3609);
    _3610 = (int)*(((s1_ptr)_2)->base + 6);
    _3609 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6785);
    _3611 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3611);
    _3612 = (int)*(((s1_ptr)_2)->base + 7);
    _3611 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6785);
    _3613 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3613);
    _3614 = (int)*(((s1_ptr)_2)->base + 8);
    _3613 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_6785);
    _3615 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_3615);
    _3616 = (int)*(((s1_ptr)_2)->base + 9);
    _3615 = NOVALUE;
    Ref(_3606);
    Ref(_3608);
    Ref(_3610);
    Ref(_3612);
    Ref(_3614);
    Ref(_3616);
    _3617 = _18new(_3606, _3608, _3610, _3612, _3614, _3616);
    _3606 = NOVALUE;
    _3608 = NOVALUE;
    _3610 = NOVALUE;
    _3612 = NOVALUE;
    _3614 = NOVALUE;
    _3616 = NOVALUE;
    DeRefDS(_fname_6784);
    DeRef(_d_6785);
    return _3617;
    ;
}


int _17locate_file(int _filename_6973, int _search_list_6974, int _subdir_6975)
{
    int _extra_paths_6976 = NOVALUE;
    int _this_path_6977 = NOVALUE;
    int _3785 = NOVALUE;
    int _3784 = NOVALUE;
    int _3782 = NOVALUE;
    int _3780 = NOVALUE;
    int _3778 = NOVALUE;
    int _3777 = NOVALUE;
    int _3776 = NOVALUE;
    int _3774 = NOVALUE;
    int _3773 = NOVALUE;
    int _3772 = NOVALUE;
    int _3770 = NOVALUE;
    int _3769 = NOVALUE;
    int _3768 = NOVALUE;
    int _3765 = NOVALUE;
    int _3764 = NOVALUE;
    int _3762 = NOVALUE;
    int _3760 = NOVALUE;
    int _3759 = NOVALUE;
    int _3756 = NOVALUE;
    int _3751 = NOVALUE;
    int _3747 = NOVALUE;
    int _3738 = NOVALUE;
    int _3735 = NOVALUE;
    int _3732 = NOVALUE;
    int _3731 = NOVALUE;
    int _3727 = NOVALUE;
    int _3724 = NOVALUE;
    int _3722 = NOVALUE;
    int _3718 = NOVALUE;
    int _3716 = NOVALUE;
    int _3715 = NOVALUE;
    int _3711 = NOVALUE;
    int _3710 = NOVALUE;
    int _3707 = NOVALUE;
    int _3705 = NOVALUE;
    int _3704 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_6973);
    _3704 = _17absolute_path(_filename_6973);
    if (_3704 == 0) {
        DeRef(_3704);
        _3704 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_3704) && DBL_PTR(_3704)->dbl == 0.0){
            DeRef(_3704);
            _3704 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_3704);
        _3704 = NOVALUE;
    }
    DeRef(_3704);
    _3704 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_6974);
    DeRefDS(_subdir_6975);
    DeRef(_extra_paths_6976);
    DeRef(_this_path_6977);
    return _filename_6973;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_6974)){
            _3705 = SEQ_PTR(_search_list_6974)->length;
    }
    else {
        _3705 = 1;
    }
    if (_3705 != 0)
    goto L2; // [28] 282

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_3707, _3094, 47);
    RefDS(_3707);
    Append(&_search_list_6974, _search_list_6974, _3707);
    DeRefDS(_3707);
    _3707 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_6976);
    _3710 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_3710);
    _3711 = _17dirname(_3710, 0);
    _3710 = NOVALUE;
    _0 = _extra_paths_6976;
    _extra_paths_6976 = _17canonical_path(_3711, 1, 0);
    DeRefDS(_0);
    _3711 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_6976);
    Append(&_search_list_6974, _search_list_6974, _extra_paths_6976);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOME")*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = EGetEnv(_3370);

    /** 		if sequence(extra_paths) then*/
    _3715 = IS_SEQUENCE(_extra_paths_6976);
    if (_3715 == 0)
    {
        _3715 = NOVALUE;
        goto L3; // [81] 95
    }
    else{
        _3715 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_6976) && IS_ATOM(47)) {
        Append(&_3716, _extra_paths_6976, 47);
    }
    else if (IS_ATOM(_extra_paths_6976) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_3716, _extra_paths_6976, 47);
    }
    RefDS(_3716);
    Append(&_search_list_6974, _search_list_6974, _3716);
    DeRefDS(_3716);
    _3716 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_3718, _3161, 47);
    RefDS(_3718);
    Append(&_search_list_6974, _search_list_6974, _3718);
    DeRefDS(_3718);
    _3718 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = EGetEnv(_3720);

    /** 		if sequence(extra_paths) then*/
    _3722 = IS_SEQUENCE(_extra_paths_6976);
    if (_3722 == 0)
    {
        _3722 = NOVALUE;
        goto L4; // [115] 145
    }
    else{
        _3722 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _3723;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_6976;
        Concat_N((object_ptr)&_3724, concat_list, 4);
    }
    RefDS(_3724);
    Append(&_search_list_6974, _search_list_6974, _3724);
    DeRefDS(_3724);
    _3724 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _3726;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_6976;
        Concat_N((object_ptr)&_3727, concat_list, 4);
    }
    RefDS(_3727);
    Append(&_search_list_6974, _search_list_6974, _3727);
    DeRefDS(_3727);
    _3727 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = EGetEnv(_3729);

    /** 		if sequence(extra_paths) then*/
    _3731 = IS_SEQUENCE(_extra_paths_6976);
    if (_3731 == 0)
    {
        _3731 = NOVALUE;
        goto L5; // [155] 195
    }
    else{
        _3731 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_6976) && IS_ATOM(47)) {
        Append(&_3732, _extra_paths_6976, 47);
    }
    else if (IS_ATOM(_extra_paths_6976) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_3732, _extra_paths_6976, 47);
    }
    RefDS(_3732);
    Append(&_search_list_6974, _search_list_6974, _3732);
    DeRefDS(_3732);
    _3732 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _3734;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_6976;
        Concat_N((object_ptr)&_3735, concat_list, 4);
    }
    RefDS(_3735);
    Append(&_search_list_6974, _search_list_6974, _3735);
    DeRefDS(_3735);
    _3735 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _3737;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_6976;
        Concat_N((object_ptr)&_3738, concat_list, 4);
    }
    RefDS(_3738);
    Append(&_search_list_6974, _search_list_6974, _3738);
    DeRefDS(_3738);
    _3738 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 			search_list = append( search_list, "/usr/local/share/euphoria/bin/" )*/
    RefDS(_3740);
    Append(&_search_list_6974, _search_list_6974, _3740);

    /** 			search_list = append( search_list, "/usr/share/euphoria/bin/" )*/
    RefDS(_3742);
    Append(&_search_list_6974, _search_list_6974, _3742);

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_3746);
    *((int *)(_2+4)) = _3746;
    RefDS(_3745);
    *((int *)(_2+8)) = _3745;
    RefDS(_3744);
    *((int *)(_2+12)) = _3744;
    _3747 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_6974, _search_list_6974, _3747);
    DeRefDS(_3747);
    _3747 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = EGetEnv(_3749);

    /** 		if sequence(extra_paths) then*/
    _3751 = IS_SEQUENCE(_extra_paths_6976);
    if (_3751 == 0)
    {
        _3751 = NOVALUE;
        goto L6; // [231] 250
    }
    else{
        _3751 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_6976);
    _0 = _extra_paths_6976;
    _extra_paths_6976 = _23split(_extra_paths_6976, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_6974) && IS_ATOM(_extra_paths_6976)) {
        Ref(_extra_paths_6976);
        Append(&_search_list_6974, _search_list_6974, _extra_paths_6976);
    }
    else if (IS_ATOM(_search_list_6974) && IS_SEQUENCE(_extra_paths_6976)) {
    }
    else {
        Concat((object_ptr)&_search_list_6974, _search_list_6974, _extra_paths_6976);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_6976);
    _extra_paths_6976 = EGetEnv(_3754);

    /** 		if sequence(extra_paths) then*/
    _3756 = IS_SEQUENCE(_extra_paths_6976);
    if (_3756 == 0)
    {
        _3756 = NOVALUE;
        goto L7; // [260] 307
    }
    else{
        _3756 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_6976);
    _0 = _extra_paths_6976;
    _extra_paths_6976 = _23split(_extra_paths_6976, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_6974) && IS_ATOM(_extra_paths_6976)) {
        Ref(_extra_paths_6976);
        Append(&_search_list_6974, _search_list_6974, _extra_paths_6976);
    }
    else if (IS_ATOM(_search_list_6974) && IS_SEQUENCE(_extra_paths_6976)) {
    }
    else {
        Concat((object_ptr)&_search_list_6974, _search_list_6974, _extra_paths_6976);
    }
    goto L7; // [279] 307
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_6974);
    _3759 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3759))
    _3760 = 1;
    else if (IS_ATOM_DBL(_3759))
    _3760 = IS_ATOM_INT(DoubleToInt(_3759));
    else
    _3760 = 0;
    _3759 = NOVALUE;
    if (_3760 == 0)
    {
        _3760 = NOVALUE;
        goto L8; // [291] 306
    }
    else{
        _3760 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_6974);
    _0 = _search_list_6974;
    _search_list_6974 = _23split(_search_list_6974, 58, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_6975)){
            _3762 = SEQ_PTR(_subdir_6975)->length;
    }
    else {
        _3762 = 1;
    }
    if (_3762 <= 0)
    goto L9; // [312] 337

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_6975)){
            _3764 = SEQ_PTR(_subdir_6975)->length;
    }
    else {
        _3764 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_6975);
    _3765 = (int)*(((s1_ptr)_2)->base + _3764);
    if (binary_op_a(EQUALS, _3765, 47)){
        _3765 = NOVALUE;
        goto LA; // [325] 336
    }
    _3765 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_6975, _subdir_6975, 47);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_6974)){
            _3768 = SEQ_PTR(_search_list_6974)->length;
    }
    else {
        _3768 = 1;
    }
    {
        int _i_7054;
        _i_7054 = 1;
LB: 
        if (_i_7054 > _3768){
            goto LC; // [342] 465
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_6974);
        _3769 = (int)*(((s1_ptr)_2)->base + _i_7054);
        if (IS_SEQUENCE(_3769)){
                _3770 = SEQ_PTR(_3769)->length;
        }
        else {
            _3770 = 1;
        }
        _3769 = NOVALUE;
        if (_3770 != 0)
        goto LD; // [358] 367

        /** 			continue*/
        goto LE; // [364] 460
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_6974);
        _3772 = (int)*(((s1_ptr)_2)->base + _i_7054);
        if (IS_SEQUENCE(_3772)){
                _3773 = SEQ_PTR(_3772)->length;
        }
        else {
            _3773 = 1;
        }
        _2 = (int)SEQ_PTR(_3772);
        _3774 = (int)*(((s1_ptr)_2)->base + _3773);
        _3772 = NOVALUE;
        if (binary_op_a(EQUALS, _3774, 47)){
            _3774 = NOVALUE;
            goto LF; // [380] 399
        }
        _3774 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_6974);
        _3776 = (int)*(((s1_ptr)_2)->base + _i_7054);
        if (IS_SEQUENCE(_3776) && IS_ATOM(47)) {
            Append(&_3777, _3776, 47);
        }
        else if (IS_ATOM(_3776) && IS_SEQUENCE(47)) {
        }
        else {
            Concat((object_ptr)&_3777, _3776, 47);
            _3776 = NOVALUE;
        }
        _3776 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_6974);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_6974 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_7054);
        _1 = *(int *)_2;
        *(int *)_2 = _3777;
        if( _1 != _3777 ){
            DeRef(_1);
        }
        _3777 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_6975)){
                _3778 = SEQ_PTR(_subdir_6975)->length;
        }
        else {
            _3778 = 1;
        }
        if (_3778 <= 0)
        goto L10; // [404] 423

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_6974);
        _3780 = (int)*(((s1_ptr)_2)->base + _i_7054);
        {
            int concat_list[3];

            concat_list[0] = _filename_6973;
            concat_list[1] = _subdir_6975;
            concat_list[2] = _3780;
            Concat_N((object_ptr)&_this_path_6977, concat_list, 3);
        }
        _3780 = NOVALUE;
        goto L11; // [420] 434
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_6974);
        _3782 = (int)*(((s1_ptr)_2)->base + _i_7054);
        if (IS_SEQUENCE(_3782) && IS_ATOM(_filename_6973)) {
        }
        else if (IS_ATOM(_3782) && IS_SEQUENCE(_filename_6973)) {
            Ref(_3782);
            Prepend(&_this_path_6977, _filename_6973, _3782);
        }
        else {
            Concat((object_ptr)&_this_path_6977, _3782, _filename_6973);
            _3782 = NOVALUE;
        }
        _3782 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_6977);
        _3784 = _17file_exists(_this_path_6977);
        if (_3784 == 0) {
            DeRef(_3784);
            _3784 = NOVALUE;
            goto L12; // [442] 458
        }
        else {
            if (!IS_ATOM_INT(_3784) && DBL_PTR(_3784)->dbl == 0.0){
                DeRef(_3784);
                _3784 = NOVALUE;
                goto L12; // [442] 458
            }
            DeRef(_3784);
            _3784 = NOVALUE;
        }
        DeRef(_3784);
        _3784 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_6977);
        _3785 = _17canonical_path(_this_path_6977, 0, 0);
        DeRefDS(_filename_6973);
        DeRefDS(_search_list_6974);
        DeRefDS(_subdir_6975);
        DeRef(_extra_paths_6976);
        DeRefDS(_this_path_6977);
        _3769 = NOVALUE;
        return _3785;
L12: 

        /** 	end for*/
LE: 
        _i_7054 = _i_7054 + 1;
        goto LB; // [460] 349
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_6974);
    DeRefDS(_subdir_6975);
    DeRef(_extra_paths_6976);
    DeRef(_this_path_6977);
    _3769 = NOVALUE;
    DeRef(_3785);
    _3785 = NOVALUE;
    return _filename_6973;
    ;
}


int _17count_files(int _orig_path_7159, int _dir_info_7160, int _inst_7161)
{
    int _pos_7162 = NOVALUE;
    int _ext_7163 = NOVALUE;
    int _fileext_inlined_fileext_at_218_7204 = NOVALUE;
    int _data_inlined_fileext_at_218_7203 = NOVALUE;
    int _path_inlined_fileext_at_215_7202 = NOVALUE;
    int _3893 = NOVALUE;
    int _3892 = NOVALUE;
    int _3891 = NOVALUE;
    int _3889 = NOVALUE;
    int _3888 = NOVALUE;
    int _3887 = NOVALUE;
    int _3886 = NOVALUE;
    int _3884 = NOVALUE;
    int _3883 = NOVALUE;
    int _3881 = NOVALUE;
    int _3880 = NOVALUE;
    int _3879 = NOVALUE;
    int _3878 = NOVALUE;
    int _3877 = NOVALUE;
    int _3876 = NOVALUE;
    int _3875 = NOVALUE;
    int _3873 = NOVALUE;
    int _3872 = NOVALUE;
    int _3870 = NOVALUE;
    int _3869 = NOVALUE;
    int _3868 = NOVALUE;
    int _3867 = NOVALUE;
    int _3866 = NOVALUE;
    int _3865 = NOVALUE;
    int _3864 = NOVALUE;
    int _3863 = NOVALUE;
    int _3862 = NOVALUE;
    int _3861 = NOVALUE;
    int _3860 = NOVALUE;
    int _3859 = NOVALUE;
    int _3858 = NOVALUE;
    int _3856 = NOVALUE;
    int _3855 = NOVALUE;
    int _3854 = NOVALUE;
    int _3853 = NOVALUE;
    int _3851 = NOVALUE;
    int _3850 = NOVALUE;
    int _3849 = NOVALUE;
    int _3848 = NOVALUE;
    int _3847 = NOVALUE;
    int _3846 = NOVALUE;
    int _3845 = NOVALUE;
    int _3843 = NOVALUE;
    int _3842 = NOVALUE;
    int _3841 = NOVALUE;
    int _3840 = NOVALUE;
    int _3839 = NOVALUE;
    int _3838 = NOVALUE;
    int _3835 = NOVALUE;
    int _3834 = NOVALUE;
    int _3833 = NOVALUE;
    int _3832 = NOVALUE;
    int _3831 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_7162 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_7159);
    DeRefDS(_orig_path_7159);
    _orig_path_7159 = _orig_path_7159;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3831 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3831 == _3094)
    _3832 = 1;
    else if (IS_ATOM_INT(_3831) && IS_ATOM_INT(_3094))
    _3832 = 0;
    else
    _3832 = (compare(_3831, _3094) == 0);
    _3831 = NOVALUE;
    if (_3832 == 0)
    {
        _3832 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _3832 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_7159);
    DeRefDS(_dir_info_7160);
    DeRefDS(_inst_7161);
    DeRef(_ext_7163);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3833 = (int)*(((s1_ptr)_2)->base + 1);
    if (_3833 == _3161)
    _3834 = 1;
    else if (IS_ATOM_INT(_3833) && IS_ATOM_INT(_3161))
    _3834 = 0;
    else
    _3834 = (compare(_3833, _3161) == 0);
    _3833 = NOVALUE;
    if (_3834 == 0)
    {
        _3834 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _3834 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_7159);
    DeRefDS(_dir_info_7160);
    DeRefDS(_inst_7161);
    DeRef(_ext_7163);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3835 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3835, 0)){
        _3835 = NOVALUE;
        goto L3; // [65] 112
    }
    _3835 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3838 = (int)*(((s1_ptr)_2)->base + 2);
    _3839 = find_from(104, _3838, 1);
    _3838 = NOVALUE;
    if (_3839 == 0)
    {
        _3839 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _3839 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_7159);
    DeRefDS(_dir_info_7160);
    DeRefDS(_inst_7161);
    DeRef(_ext_7163);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3840 = (int)*(((s1_ptr)_2)->base + 2);
    _3841 = find_from(115, _3840, 1);
    _3840 = NOVALUE;
    if (_3841 == 0)
    {
        _3841 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _3841 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_7159);
    DeRefDS(_dir_info_7160);
    DeRefDS(_inst_7161);
    DeRef(_ext_7163);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3842 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3842))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3842)->dbl));
    else
    _3 = (int)(_3842 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3845 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3846 = (int)*(((s1_ptr)_2)->base + 3);
    _3843 = NOVALUE;
    if (IS_ATOM_INT(_3846) && IS_ATOM_INT(_3845)) {
        _3847 = _3846 + _3845;
        if ((long)((unsigned long)_3847 + (unsigned long)HIGH_BITS) >= 0) 
        _3847 = NewDouble((double)_3847);
    }
    else {
        _3847 = binary_op(PLUS, _3846, _3845);
    }
    _3846 = NOVALUE;
    _3845 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _3847;
    if( _1 != _3847 ){
        DeRef(_1);
    }
    _3847 = NOVALUE;
    _3843 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3848 = (int)*(((s1_ptr)_2)->base + 2);
    _3849 = find_from(100, _3848, 1);
    _3848 = NOVALUE;
    if (_3849 == 0)
    {
        _3849 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _3849 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3850 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3850))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3850)->dbl));
    else
    _3 = (int)(_3850 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3853 = (int)*(((s1_ptr)_2)->base + 1);
    _3851 = NOVALUE;
    if (IS_ATOM_INT(_3853)) {
        _3854 = _3853 + 1;
        if (_3854 > MAXINT){
            _3854 = NewDouble((double)_3854);
        }
    }
    else
    _3854 = binary_op(PLUS, 1, _3853);
    _3853 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _3854;
    if( _1 != _3854 ){
        DeRef(_1);
    }
    _3854 = NOVALUE;
    _3851 = NOVALUE;
    goto L7; // [180] 460
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3855 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3855))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3855)->dbl));
    else
    _3 = (int)(_3855 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3858 = (int)*(((s1_ptr)_2)->base + 2);
    _3856 = NOVALUE;
    if (IS_ATOM_INT(_3858)) {
        _3859 = _3858 + 1;
        if (_3859 > MAXINT){
            _3859 = NewDouble((double)_3859);
        }
    }
    else
    _3859 = binary_op(PLUS, 1, _3858);
    _3858 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3859;
    if( _1 != _3859 ){
        DeRef(_1);
    }
    _3859 = NOVALUE;
    _3856 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(dir_info[D_NAME])*/
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3860 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3860);
    DeRef(_path_inlined_fileext_at_215_7202);
    _path_inlined_fileext_at_215_7202 = _3860;
    _3860 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_215_7202);
    _0 = _data_inlined_fileext_at_218_7203;
    _data_inlined_fileext_at_218_7203 = _17pathinfo(_path_inlined_fileext_at_215_7202, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_7163);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_218_7203);
    _ext_7163 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_7163);
    DeRef(_path_inlined_fileext_at_215_7202);
    _path_inlined_fileext_at_215_7202 = NOVALUE;
    DeRef(_data_inlined_fileext_at_218_7203);
    _data_inlined_fileext_at_218_7203 = NOVALUE;

    /** 		pos = 0*/
    _pos_7162 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3861 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!IS_ATOM_INT(_3861)){
        _3862 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3861)->dbl));
    }
    else{
        _3862 = (int)*(((s1_ptr)_2)->base + _3861);
    }
    _2 = (int)SEQ_PTR(_3862);
    _3863 = (int)*(((s1_ptr)_2)->base + 4);
    _3862 = NOVALUE;
    if (IS_SEQUENCE(_3863)){
            _3864 = SEQ_PTR(_3863)->length;
    }
    else {
        _3864 = 1;
    }
    _3863 = NOVALUE;
    {
        int _i_7206;
        _i_7206 = 1;
L8: 
        if (_i_7206 > _3864){
            goto L9; // [265] 322
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_7161);
        _3865 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_17file_counters_7156);
        if (!IS_ATOM_INT(_3865)){
            _3866 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3865)->dbl));
        }
        else{
            _3866 = (int)*(((s1_ptr)_2)->base + _3865);
        }
        _2 = (int)SEQ_PTR(_3866);
        _3867 = (int)*(((s1_ptr)_2)->base + 4);
        _3866 = NOVALUE;
        _2 = (int)SEQ_PTR(_3867);
        _3868 = (int)*(((s1_ptr)_2)->base + _i_7206);
        _3867 = NOVALUE;
        _2 = (int)SEQ_PTR(_3868);
        _3869 = (int)*(((s1_ptr)_2)->base + 1);
        _3868 = NOVALUE;
        if (_3869 == _ext_7163)
        _3870 = 1;
        else if (IS_ATOM_INT(_3869) && IS_ATOM_INT(_ext_7163))
        _3870 = 0;
        else
        _3870 = (compare(_3869, _ext_7163) == 0);
        _3869 = NOVALUE;
        if (_3870 == 0)
        {
            _3870 = NOVALUE;
            goto LA; // [302] 315
        }
        else{
            _3870 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_7162 = _i_7206;

        /** 				exit*/
        goto L9; // [312] 322
LA: 

        /** 		end for*/
        _i_7206 = _i_7206 + 1;
        goto L8; // [317] 272
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_7162 != 0)
    goto LB; // [324] 385

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3872 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3872))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3872)->dbl));
    else
    _3 = (int)(_3872 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_7163);
    *((int *)(_2+4)) = _ext_7163;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _3875 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3875;
    _3876 = MAKE_SEQ(_1);
    _3875 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3877 = (int)*(((s1_ptr)_2)->base + 4);
    _3873 = NOVALUE;
    if (IS_SEQUENCE(_3877) && IS_ATOM(_3876)) {
    }
    else if (IS_ATOM(_3877) && IS_SEQUENCE(_3876)) {
        Ref(_3877);
        Prepend(&_3878, _3876, _3877);
    }
    else {
        Concat((object_ptr)&_3878, _3877, _3876);
        _3877 = NOVALUE;
    }
    _3877 = NOVALUE;
    DeRefDS(_3876);
    _3876 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _3878;
    if( _1 != _3878 ){
        DeRef(_1);
    }
    _3878 = NOVALUE;
    _3873 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3879 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!IS_ATOM_INT(_3879)){
        _3880 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_3879)->dbl));
    }
    else{
        _3880 = (int)*(((s1_ptr)_2)->base + _3879);
    }
    _2 = (int)SEQ_PTR(_3880);
    _3881 = (int)*(((s1_ptr)_2)->base + 4);
    _3880 = NOVALUE;
    if (IS_SEQUENCE(_3881)){
            _pos_7162 = SEQ_PTR(_3881)->length;
    }
    else {
        _pos_7162 = 1;
    }
    _3881 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3883 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3883))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3883)->dbl));
    else
    _3 = (int)(_3883 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _3884 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_7162 + ((s1_ptr)_2)->base);
    _3884 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3886 = (int)*(((s1_ptr)_2)->base + 2);
    _3884 = NOVALUE;
    if (IS_ATOM_INT(_3886)) {
        _3887 = _3886 + 1;
        if (_3887 > MAXINT){
            _3887 = NewDouble((double)_3887);
        }
    }
    else
    _3887 = binary_op(PLUS, 1, _3886);
    _3886 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3887;
    if( _1 != _3887 ){
        DeRef(_1);
    }
    _3887 = NOVALUE;
    _3884 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_7161);
    _3888 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_17file_counters_7156);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _17file_counters_7156 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_3888))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_3888)->dbl));
    else
    _3 = (int)(_3888 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _3889 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_7162 + ((s1_ptr)_2)->base);
    _3889 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_7160);
    _3891 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _3892 = (int)*(((s1_ptr)_2)->base + 3);
    _3889 = NOVALUE;
    if (IS_ATOM_INT(_3892) && IS_ATOM_INT(_3891)) {
        _3893 = _3892 + _3891;
        if ((long)((unsigned long)_3893 + (unsigned long)HIGH_BITS) >= 0) 
        _3893 = NewDouble((double)_3893);
    }
    else {
        _3893 = binary_op(PLUS, _3892, _3891);
    }
    _3892 = NOVALUE;
    _3891 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _3893;
    if( _1 != _3893 ){
        DeRef(_1);
    }
    _3893 = NOVALUE;
    _3889 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_7159);
    DeRefDS(_dir_info_7160);
    DeRefDS(_inst_7161);
    DeRef(_ext_7163);
    _3842 = NOVALUE;
    _3850 = NOVALUE;
    _3855 = NOVALUE;
    _3861 = NOVALUE;
    _3863 = NOVALUE;
    _3865 = NOVALUE;
    _3872 = NOVALUE;
    _3879 = NOVALUE;
    _3881 = NOVALUE;
    _3883 = NOVALUE;
    _3888 = NOVALUE;
    return 0;
    ;
}


int _17temp_file(int _temp_location_7264, int _temp_prefix_7265, int _temp_extn_7266, int _reserve_temp_7268)
{
    int _randname_7269 = NOVALUE;
    int _envtmp_7273 = NOVALUE;
    int _tdir_7292 = NOVALUE;
    int _5899 = NOVALUE;
    int _3945 = NOVALUE;
    int _3943 = NOVALUE;
    int _3941 = NOVALUE;
    int _3939 = NOVALUE;
    int _3938 = NOVALUE;
    int _3937 = NOVALUE;
    int _3933 = NOVALUE;
    int _3932 = NOVALUE;
    int _3931 = NOVALUE;
    int _3930 = NOVALUE;
    int _3927 = NOVALUE;
    int _3926 = NOVALUE;
    int _3925 = NOVALUE;
    int _3920 = NOVALUE;
    int _3918 = NOVALUE;
    int _3914 = NOVALUE;
    int _3910 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(temp_location) = 0 then*/
    if (IS_SEQUENCE(_temp_location_7264)){
            _3910 = SEQ_PTR(_temp_location_7264)->length;
    }
    else {
        _3910 = 1;
    }
    if (_3910 != 0)
    goto L1; // [14] 67

    /** 		object envtmp*/

    /** 		envtmp = getenv("TEMP")*/
    DeRefi(_envtmp_7273);
    _envtmp_7273 = EGetEnv(_3912);

    /** 		if atom(envtmp) then*/
    _3914 = IS_ATOM(_envtmp_7273);
    if (_3914 == 0)
    {
        _3914 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _3914 = NOVALUE;
    }

    /** 			envtmp = getenv("TMP")*/
    DeRefi(_envtmp_7273);
    _envtmp_7273 = EGetEnv(_3915);
L2: 

    /** 		ifdef WINDOWS then			*/

    /** 			if atom(envtmp) then*/
    _3918 = IS_ATOM(_envtmp_7273);
    if (_3918 == 0)
    {
        _3918 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        _3918 = NOVALUE;
    }

    /** 				envtmp = "/tmp/"*/
    RefDS(_3919);
    DeRefi(_envtmp_7273);
    _envtmp_7273 = _3919;
L3: 

    /** 		temp_location = envtmp*/
    Ref(_envtmp_7273);
    DeRefDS(_temp_location_7264);
    _temp_location_7264 = _envtmp_7273;
    DeRefi(_envtmp_7273);
    _envtmp_7273 = NOVALUE;
    goto L4; // [64] 161
L1: 

    /** 		switch file_type(temp_location) do*/
    RefDS(_temp_location_7264);
    _3920 = _17file_type(_temp_location_7264);
    if (IS_SEQUENCE(_3920) ){
        goto L5; // [73] 150
    }
    if(!IS_ATOM_INT(_3920)){
        if( (DBL_PTR(_3920)->dbl != (double) ((int) DBL_PTR(_3920)->dbl) ) ){
            goto L5; // [73] 150
        }
        _0 = (int) DBL_PTR(_3920)->dbl;
    }
    else {
        _0 = _3920;
    };
    DeRef(_3920);
    _3920 = NOVALUE;
    switch ( _0 ){ 

        /** 			case FILETYPE_FILE then*/
        case 1:

        /** 				temp_location = dirname(temp_location, 1)*/
        RefDS(_temp_location_7264);
        _0 = _temp_location_7264;
        _temp_location_7264 = _17dirname(_temp_location_7264, 1);
        DeRefDS(_0);
        goto L6; // [91] 160

        /** 			case FILETYPE_DIRECTORY then*/
        case 2:

        /** 				temp_location = temp_location*/
        RefDS(_temp_location_7264);
        DeRefDS(_temp_location_7264);
        _temp_location_7264 = _temp_location_7264;
        goto L6; // [104] 160

        /** 			case FILETYPE_NOT_FOUND then*/
        case 0:

        /** 				object tdir = dirname(temp_location, 1)*/
        RefDS(_temp_location_7264);
        _0 = _tdir_7292;
        _tdir_7292 = _17dirname(_temp_location_7264, 1);
        DeRef(_0);

        /** 				if file_exists(tdir) then*/
        Ref(_tdir_7292);
        _3925 = _17file_exists(_tdir_7292);
        if (_3925 == 0) {
            DeRef(_3925);
            _3925 = NOVALUE;
            goto L7; // [123] 136
        }
        else {
            if (!IS_ATOM_INT(_3925) && DBL_PTR(_3925)->dbl == 0.0){
                DeRef(_3925);
                _3925 = NOVALUE;
                goto L7; // [123] 136
            }
            DeRef(_3925);
            _3925 = NOVALUE;
        }
        DeRef(_3925);
        _3925 = NOVALUE;

        /** 					temp_location = tdir*/
        Ref(_tdir_7292);
        DeRefDS(_temp_location_7264);
        _temp_location_7264 = _tdir_7292;
        goto L8; // [133] 144
L7: 

        /** 					temp_location = "."*/
        RefDS(_3094);
        DeRefDS(_temp_location_7264);
        _temp_location_7264 = _3094;
L8: 
        DeRef(_tdir_7292);
        _tdir_7292 = NOVALUE;
        goto L6; // [146] 160

        /** 			case else*/
        default:
L5: 

        /** 				temp_location = "."*/
        RefDS(_3094);
        DeRefDS(_temp_location_7264);
        _temp_location_7264 = _3094;
    ;}L6: 
L4: 

    /** 	if temp_location[$] != SLASH then*/
    if (IS_SEQUENCE(_temp_location_7264)){
            _3926 = SEQ_PTR(_temp_location_7264)->length;
    }
    else {
        _3926 = 1;
    }
    _2 = (int)SEQ_PTR(_temp_location_7264);
    _3927 = (int)*(((s1_ptr)_2)->base + _3926);
    if (binary_op_a(EQUALS, _3927, 47)){
        _3927 = NOVALUE;
        goto L9; // [170] 181
    }
    _3927 = NOVALUE;

    /** 		temp_location &= SLASH*/
    Append(&_temp_location_7264, _temp_location_7264, 47);
L9: 

    /** 	if length(temp_extn) and temp_extn[1] != '.' then*/
    if (IS_SEQUENCE(_temp_extn_7266)){
            _3930 = SEQ_PTR(_temp_extn_7266)->length;
    }
    else {
        _3930 = 1;
    }
    if (_3930 == 0) {
        goto LA; // [186] 209
    }
    _2 = (int)SEQ_PTR(_temp_extn_7266);
    _3932 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3932)) {
        _3933 = (_3932 != 46);
    }
    else {
        _3933 = binary_op(NOTEQ, _3932, 46);
    }
    _3932 = NOVALUE;
    if (_3933 == 0) {
        DeRef(_3933);
        _3933 = NOVALUE;
        goto LA; // [199] 209
    }
    else {
        if (!IS_ATOM_INT(_3933) && DBL_PTR(_3933)->dbl == 0.0){
            DeRef(_3933);
            _3933 = NOVALUE;
            goto LA; // [199] 209
        }
        DeRef(_3933);
        _3933 = NOVALUE;
    }
    DeRef(_3933);
    _3933 = NOVALUE;

    /** 		temp_extn = '.' & temp_extn*/
    Prepend(&_temp_extn_7266, _temp_extn_7266, 46);
LA: 

    /** 	while 1 do*/
LB: 

    /** 		randname = sprintf("%s%s%06d%s", {temp_location, temp_prefix, rand(1_000_000) - 1, temp_extn})*/
    _3937 = good_rand() % ((unsigned)1000000) + 1;
    _3938 = _3937 - 1;
    _3937 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_temp_location_7264);
    *((int *)(_2+4)) = _temp_location_7264;
    RefDS(_temp_prefix_7265);
    *((int *)(_2+8)) = _temp_prefix_7265;
    *((int *)(_2+12)) = _3938;
    RefDS(_temp_extn_7266);
    *((int *)(_2+16)) = _temp_extn_7266;
    _3939 = MAKE_SEQ(_1);
    _3938 = NOVALUE;
    DeRefi(_randname_7269);
    _randname_7269 = EPrintf(-9999999, _3935, _3939);
    DeRefDS(_3939);
    _3939 = NOVALUE;

    /** 		if not file_exists( randname ) then*/
    RefDS(_randname_7269);
    _3941 = _17file_exists(_randname_7269);
    if (IS_ATOM_INT(_3941)) {
        if (_3941 != 0){
            DeRef(_3941);
            _3941 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    else {
        if (DBL_PTR(_3941)->dbl != 0.0){
            DeRef(_3941);
            _3941 = NOVALUE;
            goto LB; // [240] 214
        }
    }
    DeRef(_3941);
    _3941 = NOVALUE;

    /** 			exit*/
    goto LC; // [245] 253

    /** 	end while*/
    goto LB; // [250] 214
LC: 

    /** 	if reserve_temp then*/
    if (_reserve_temp_7268 == 0)
    {
        goto LD; // [255] 300
    }
    else{
    }

    /** 		if not file_exists(temp_location) then*/
    RefDS(_temp_location_7264);
    _3943 = _17file_exists(_temp_location_7264);
    if (IS_ATOM_INT(_3943)) {
        if (_3943 != 0){
            DeRef(_3943);
            _3943 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    else {
        if (DBL_PTR(_3943)->dbl != 0.0){
            DeRef(_3943);
            _3943 = NOVALUE;
            goto LE; // [264] 287
        }
    }
    DeRef(_3943);
    _3943 = NOVALUE;

    /** 			if create_directory(temp_location) = 0 then*/
    RefDS(_temp_location_7264);
    _3945 = _17create_directory(_temp_location_7264, 448, 1);
    if (binary_op_a(NOTEQ, _3945, 0)){
        DeRef(_3945);
        _3945 = NOVALUE;
        goto LF; // [275] 286
    }
    DeRef(_3945);
    _3945 = NOVALUE;

    /** 				return ""*/
    RefDS(_5);
    DeRefDS(_temp_location_7264);
    DeRefDSi(_temp_prefix_7265);
    DeRefDS(_temp_extn_7266);
    DeRefi(_randname_7269);
    return _5;
LF: 
LE: 

    /** 		io:write_file(randname, "")*/
    RefDS(_randname_7269);
    RefDS(_5);
    _5899 = _8write_file(_randname_7269, _5, 1);
    DeRef(_5899);
    _5899 = NOVALUE;
LD: 

    /** 	return randname*/
    DeRefDS(_temp_location_7264);
    DeRefDSi(_temp_prefix_7265);
    DeRefDS(_temp_extn_7266);
    return _randname_7269;
    ;
}



// 0xEA23A7EB
