// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _5any_key(int _prompt_13484, int _con_13486)
{
    int _wait_key_inlined_wait_key_at_27_13491 = NOVALUE;
    int _7518 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find(con, {1,2}) then*/
    _7518 = find_from(_con_13486, _7040, 1);
    if (_7518 != 0)
    goto L1; // [12] 21
    _7518 = NOVALUE;

    /** 		con = 1*/
    _con_13486 = 1;
L1: 

    /** 	puts(con, prompt)*/
    EPuts(_con_13486, _prompt_13484); // DJP 

    /** 	wait_key()*/

    /** 	return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_13491 = machine(26, 0);

    /** 	puts(con, "\n")*/
    EPuts(_con_13486, _3073); // DJP 

    /** end procedure*/
    DeRefDS(_prompt_13484);
    return;
    ;
}


void _5maybe_any_key(int _prompt_13494, int _con_13495)
{
    int _has_console_inlined_has_console_at_6_13498 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_13498);
    _has_console_inlined_has_console_at_6_13498 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_13498)) {
        if (_has_console_inlined_has_console_at_6_13498 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_13498)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_prompt_13494);
    _5any_key(_prompt_13494, _con_13495);
L1: 

    /** end procedure*/
    DeRefDS(_prompt_13494);
    return;
    ;
}



// 0x76F8D2A9
