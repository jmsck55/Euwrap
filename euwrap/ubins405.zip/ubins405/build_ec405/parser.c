// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _39EndLineTable()
{
    int _0, _1, _2;
    

    /** 	LineTable = append(LineTable, -2)*/
    Append(&_35LineTable_16057, _35LineTable_16057, -2);

    /** end procedure*/
    return;
    ;
}


void _39CreateTopLevel()
{
    int _27619 = NOVALUE;
    int _27617 = NOVALUE;
    int _27615 = NOVALUE;
    int _27613 = NOVALUE;
    int _27611 = NOVALUE;
    int _27609 = NOVALUE;
    int _27607 = NOVALUE;
    int _27605 = NOVALUE;
    int _27603 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27603 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15686))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27605 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _27607 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _27609 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15681))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15681)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15681);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27611 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _27613 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27615 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27617 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _27619 = NOVALUE;

    /** 	Start_block( PROC, TopLevelSub )*/
    _66Start_block(27, _35TopLevelSub_15975);

    /** end procedure*/
    return;
    ;
}


void _39CheckForUndefinedGotoLabels()
{
    int _27634 = NOVALUE;
    int _27633 = NOVALUE;
    int _27629 = NOVALUE;
    int _27627 = NOVALUE;
    int _27625 = NOVALUE;
    int _27623 = NOVALUE;
    int _27622 = NOVALUE;
    int _27621 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_35goto_delay_16078)){
            _27621 = SEQ_PTR(_35goto_delay_16078)->length;
    }
    else {
        _27621 = 1;
    }
    {
        int _i_53773;
        _i_53773 = 1;
L1: 
        if (_i_53773 > _27621){
            goto L2; // [8] 104
        }

        /** 		if not equal(goto_delay[i],"") then*/
        _2 = (int)SEQ_PTR(_35goto_delay_16078);
        _27622 = (int)*(((s1_ptr)_2)->base + _i_53773);
        if (_27622 == _21815)
        _27623 = 1;
        else if (IS_ATOM_INT(_27622) && IS_ATOM_INT(_21815))
        _27623 = 0;
        else
        _27623 = (compare(_27622, _21815) == 0);
        _27622 = NOVALUE;
        if (_27623 != 0)
        goto L3; // [27] 97
        _27623 = NOVALUE;

        /** 			line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_53679);
        _27625 = (int)*(((s1_ptr)_2)->base + _i_53773);
        _2 = (int)SEQ_PTR(_27625);
        _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_35line_number_15969)){
            _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
        }
        _27625 = NOVALUE;

        /** 			gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_53679);
        _27627 = (int)*(((s1_ptr)_2)->base + _i_53773);
        _2 = (int)SEQ_PTR(_27627);
        _35gline_number_15973 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_35gline_number_15973)){
            _35gline_number_15973 = (long)DBL_PTR(_35gline_number_15973)->dbl;
        }
        _27627 = NOVALUE;

        /** 			ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_39goto_line_53679);
        _27629 = (int)*(((s1_ptr)_2)->base + _i_53773);
        DeRef(_44ThisLine_48142);
        _2 = (int)SEQ_PTR(_27629);
        _44ThisLine_48142 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_44ThisLine_48142);
        _27629 = NOVALUE;

        /** 			bp = length(ThisLine)*/
        if (IS_SEQUENCE(_44ThisLine_48142)){
                _44bp_48146 = SEQ_PTR(_44ThisLine_48142)->length;
        }
        else {
            _44bp_48146 = 1;
        }

        /** 				CompileErr(156, {goto_delay[i]})*/
        _2 = (int)SEQ_PTR(_35goto_delay_16078);
        _27633 = (int)*(((s1_ptr)_2)->base + _i_53773);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_27633);
        *((int *)(_2+4)) = _27633;
        _27634 = MAKE_SEQ(_1);
        _27633 = NOVALUE;
        _44CompileErr(156, _27634, 0);
        _27634 = NOVALUE;
L3: 

        /** 	end for*/
        _i_53773 = _i_53773 + 1;
        goto L1; // [99] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _39PushGoto()
{
    int _27635 = NOVALUE;
    int _0, _1, _2;
    

    /** 	goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_39goto_addr_53681);
    *((int *)(_2+4)) = _39goto_addr_53681;
    RefDS(_35goto_list_16079);
    *((int *)(_2+8)) = _35goto_list_16079;
    RefDS(_39goto_labels_53680);
    *((int *)(_2+12)) = _39goto_labels_53680;
    RefDS(_35goto_delay_16078);
    *((int *)(_2+16)) = _35goto_delay_16078;
    RefDS(_39goto_line_53679);
    *((int *)(_2+20)) = _39goto_line_53679;
    RefDS(_39goto_ref_53683);
    *((int *)(_2+24)) = _39goto_ref_53683;
    RefDS(_39label_block_53684);
    *((int *)(_2+28)) = _39label_block_53684;
    Ref(_39goto_init_53686);
    *((int *)(_2+32)) = _39goto_init_53686;
    _27635 = MAKE_SEQ(_1);
    RefDS(_27635);
    Append(&_39goto_stack_53682, _39goto_stack_53682, _27635);
    DeRefDS(_27635);
    _27635 = NOVALUE;

    /** 	goto_addr = {}*/
    RefDS(_21815);
    DeRefDS(_39goto_addr_53681);
    _39goto_addr_53681 = _21815;

    /** 	goto_list = {}*/
    RefDS(_21815);
    DeRefDS(_35goto_list_16079);
    _35goto_list_16079 = _21815;

    /** 	goto_labels = {}*/
    RefDS(_21815);
    DeRefDS(_39goto_labels_53680);
    _39goto_labels_53680 = _21815;

    /** 	goto_delay = {}*/
    RefDS(_21815);
    DeRefDS(_35goto_delay_16078);
    _35goto_delay_16078 = _21815;

    /** 	goto_line = {}*/
    RefDS(_21815);
    DeRefDS(_39goto_line_53679);
    _39goto_line_53679 = _21815;

    /** 	goto_ref = {}*/
    RefDS(_21815);
    DeRefDS(_39goto_ref_53683);
    _39goto_ref_53683 = _21815;

    /** 	label_block = {}*/
    RefDS(_21815);
    DeRefDS(_39label_block_53684);
    _39label_block_53684 = _21815;

    /** 	goto_init = map:new()*/
    _0 = _28new(690);
    DeRef(_39goto_init_53686);
    _39goto_init_53686 = _0;

    /** end procedure*/
    return;
    ;
}


void _39PopGoto()
{
    int _27662 = NOVALUE;
    int _27660 = NOVALUE;
    int _27659 = NOVALUE;
    int _27657 = NOVALUE;
    int _27656 = NOVALUE;
    int _27654 = NOVALUE;
    int _27653 = NOVALUE;
    int _27651 = NOVALUE;
    int _27650 = NOVALUE;
    int _27648 = NOVALUE;
    int _27647 = NOVALUE;
    int _27645 = NOVALUE;
    int _27644 = NOVALUE;
    int _27642 = NOVALUE;
    int _27641 = NOVALUE;
    int _27639 = NOVALUE;
    int _27638 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CheckForUndefinedGotoLabels()*/
    _39CheckForUndefinedGotoLabels();

    /** 	goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27638 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27638 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27639 = (int)*(((s1_ptr)_2)->base + _27638);
    DeRef(_39goto_addr_53681);
    _2 = (int)SEQ_PTR(_27639);
    _39goto_addr_53681 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_39goto_addr_53681);
    _27639 = NOVALUE;

    /** 	goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27641 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27641 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27642 = (int)*(((s1_ptr)_2)->base + _27641);
    DeRef(_35goto_list_16079);
    _2 = (int)SEQ_PTR(_27642);
    _35goto_list_16079 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_35goto_list_16079);
    _27642 = NOVALUE;

    /** 	goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27644 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27644 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27645 = (int)*(((s1_ptr)_2)->base + _27644);
    DeRef(_39goto_labels_53680);
    _2 = (int)SEQ_PTR(_27645);
    _39goto_labels_53680 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_39goto_labels_53680);
    _27645 = NOVALUE;

    /** 	goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27647 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27647 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27648 = (int)*(((s1_ptr)_2)->base + _27647);
    DeRef(_35goto_delay_16078);
    _2 = (int)SEQ_PTR(_27648);
    _35goto_delay_16078 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_35goto_delay_16078);
    _27648 = NOVALUE;

    /** 	goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27650 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27650 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27651 = (int)*(((s1_ptr)_2)->base + _27650);
    DeRef(_39goto_line_53679);
    _2 = (int)SEQ_PTR(_27651);
    _39goto_line_53679 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_39goto_line_53679);
    _27651 = NOVALUE;

    /** 	goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27653 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27653 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27654 = (int)*(((s1_ptr)_2)->base + _27653);
    DeRef(_39goto_ref_53683);
    _2 = (int)SEQ_PTR(_27654);
    _39goto_ref_53683 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_39goto_ref_53683);
    _27654 = NOVALUE;

    /** 	label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27656 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27656 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27657 = (int)*(((s1_ptr)_2)->base + _27656);
    DeRef(_39label_block_53684);
    _2 = (int)SEQ_PTR(_27657);
    _39label_block_53684 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_39label_block_53684);
    _27657 = NOVALUE;

    /** 	goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27659 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27659 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_stack_53682);
    _27660 = (int)*(((s1_ptr)_2)->base + _27659);
    DeRef(_39goto_init_53686);
    _2 = (int)SEQ_PTR(_27660);
    _39goto_init_53686 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_39goto_init_53686);
    _27660 = NOVALUE;

    /** 	goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27662 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27662 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39goto_stack_53682);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27662)) ? _27662 : (long)(DBL_PTR(_27662)->dbl);
        int stop = (IS_ATOM_INT(_27662)) ? _27662 : (long)(DBL_PTR(_27662)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39goto_stack_53682), start, &_39goto_stack_53682 );
            }
            else Tail(SEQ_PTR(_39goto_stack_53682), stop+1, &_39goto_stack_53682);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39goto_stack_53682), start, &_39goto_stack_53682);
        }
        else {
            assign_slice_seq = &assign_space;
            _39goto_stack_53682 = Remove_elements(start, stop, (SEQ_PTR(_39goto_stack_53682)->ref == 1));
        }
    }
    _27662 = NOVALUE;
    _27662 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39EnterTopLevel(int _end_line_table_53839)
{
    int _27677 = NOVALUE;
    int _27676 = NOVALUE;
    int _27674 = NOVALUE;
    int _27673 = NOVALUE;
    int _27671 = NOVALUE;
    int _27669 = NOVALUE;
    int _27668 = NOVALUE;
    int _27666 = NOVALUE;
    int _27664 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if CurrentSub then*/
    if (_35CurrentSub_15976 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** 		if end_line_table then*/
    if (_end_line_table_53839 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** 			EndLineTable()*/
    _39EndLineTable();

    /** 			SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16057);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16057;
    DeRef(_1);
    _27664 = NOVALUE;

    /** 			SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16056;
    DeRef(_1);
    _27666 = NOVALUE;
L2: 
L1: 

    /** 	if length(goto_stack) then*/
    if (IS_SEQUENCE(_39goto_stack_53682)){
            _27668 = SEQ_PTR(_39goto_stack_53682)->length;
    }
    else {
        _27668 = 1;
    }
    if (_27668 == 0)
    {
        _27668 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27668 = NOVALUE;
    }

    /** 		PopGoto()*/
    _39PopGoto();
L3: 

    /** 	LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27669 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    DeRef(_35LineTable_16057);
    _2 = (int)SEQ_PTR(_27669);
    if (!IS_ATOM_INT(_35S_LINETAB_15676)){
        _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    }
    else{
        _35LineTable_16057 = (int)*(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    }
    Ref(_35LineTable_16057);
    _27669 = NOVALUE;

    /** 	Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27671 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    DeRef(_35Code_16056);
    _2 = (int)SEQ_PTR(_27671);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _35Code_16056 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    Ref(_35Code_16056);
    _27671 = NOVALUE;

    /** 	previous_op = -1*/
    _35previous_op_16066 = -1;

    /** 	CurrentSub = TopLevelSub*/
    _35CurrentSub_15976 = _35TopLevelSub_15975;

    /** 	clear_last()*/
    _41clear_last();

    /** 	if length( branch_stack ) then*/
    if (IS_SEQUENCE(_39branch_stack_53668)){
            _27673 = SEQ_PTR(_39branch_stack_53668)->length;
    }
    else {
        _27673 = 1;
    }
    if (_27673 == 0)
    {
        _27673 = NOVALUE;
        goto L4; // [137] 171
    }
    else{
        _27673 = NOVALUE;
    }

    /** 		branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_39branch_stack_53668)){
            _27674 = SEQ_PTR(_39branch_stack_53668)->length;
    }
    else {
        _27674 = 1;
    }
    DeRef(_39branch_list_53667);
    _2 = (int)SEQ_PTR(_39branch_stack_53668);
    _39branch_list_53667 = (int)*(((s1_ptr)_2)->base + _27674);
    Ref(_39branch_list_53667);

    /** 		branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_39branch_stack_53668)){
            _27676 = SEQ_PTR(_39branch_stack_53668)->length;
    }
    else {
        _27676 = 1;
    }
    _27677 = _27676 - 1;
    _27676 = NOVALUE;
    {
        int len = SEQ_PTR(_39branch_stack_53668)->length;
        int size = (IS_ATOM_INT(_27677)) ? _27677 : (long)(DBL_PTR(_27677)->dbl);
        if (size <= 0) {
            DeRef(_39branch_stack_53668);
            _39branch_stack_53668 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_39branch_stack_53668);
            DeRef(_39branch_stack_53668);
            _39branch_stack_53668 = _39branch_stack_53668;
        }
        else Tail(SEQ_PTR(_39branch_stack_53668), len-size+1, &_39branch_stack_53668);
    }
    _27677 = NOVALUE;
L4: 

    /** end procedure*/
    return;
    ;
}


void _39LeaveTopLevel()
{
    int _27682 = NOVALUE;
    int _27680 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	branch_stack = append( branch_stack, branch_list )*/
    RefDS(_39branch_list_53667);
    Append(&_39branch_stack_53668, _39branch_stack_53668, _39branch_list_53667);

    /** 	branch_list = {}*/
    RefDS(_21815);
    DeRefDS(_39branch_list_53667);
    _39branch_list_53667 = _21815;

    /** 	PushGoto()*/
    _39PushGoto();

    /** 	LastLineNumber = -1*/
    _61LastLineNumber_23550 = -1;

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16057);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16057;
    DeRef(_1);
    _27680 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16056;
    DeRef(_1);
    _27682 = NOVALUE;

    /** 	LineTable = {}*/
    RefDS(_21815);
    DeRefDS(_35LineTable_16057);
    _35LineTable_16057 = _21815;

    /** 	Code = {}*/
    RefDS(_21815);
    DeRefDS(_35Code_16056);
    _35Code_16056 = _21815;

    /** 	previous_op = -1*/
    _35previous_op_16066 = -1;

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    return;
    ;
}


void _39InitParser()
{
    int _0, _1, _2;
    

    /** 	goto_stack = {}*/
    RefDS(_21815);
    DeRef(_39goto_stack_53682);
    _39goto_stack_53682 = _21815;

    /** 	goto_labels = {}*/
    RefDS(_21815);
    DeRef(_39goto_labels_53680);
    _39goto_labels_53680 = _21815;

    /** 	label_block = {}*/
    RefDS(_21815);
    DeRef(_39label_block_53684);
    _39label_block_53684 = _21815;

    /** 	goto_ref = {}*/
    RefDS(_21815);
    DeRef(_39goto_ref_53683);
    _39goto_ref_53683 = _21815;

    /** 	goto_addr = {}*/
    RefDS(_21815);
    DeRef(_39goto_addr_53681);
    _39goto_addr_53681 = _21815;

    /** 	goto_line = {}*/
    RefDS(_21815);
    DeRef(_39goto_line_53679);
    _39goto_line_53679 = _21815;

    /** 	break_list = {}*/
    RefDS(_21815);
    DeRefi(_39break_list_53687);
    _39break_list_53687 = _21815;

    /** 	break_delay = {}*/
    RefDS(_21815);
    DeRef(_39break_delay_53688);
    _39break_delay_53688 = _21815;

    /** 	exit_list = {}*/
    RefDS(_21815);
    DeRefi(_39exit_list_53689);
    _39exit_list_53689 = _21815;

    /** 	exit_delay = {}*/
    RefDS(_21815);
    DeRef(_39exit_delay_53690);
    _39exit_delay_53690 = _21815;

    /** 	continue_list = {}*/
    RefDS(_21815);
    DeRefi(_39continue_list_53691);
    _39continue_list_53691 = _21815;

    /** 	continue_delay = {}*/
    RefDS(_21815);
    DeRef(_39continue_delay_53692);
    _39continue_delay_53692 = _21815;

    /** 	init_stack = {}*/
    RefDS(_21815);
    DeRefi(_39init_stack_53702);
    _39init_stack_53702 = _21815;

    /** 	CurrentSub = 0*/
    _35CurrentSub_15976 = 0;

    /** 	CreateTopLevel()*/
    _39CreateTopLevel();

    /** 	EnterTopLevel()*/
    _39EnterTopLevel(1);

    /** 	backed_up_tok = {}*/
    RefDS(_21815);
    DeRef(_39backed_up_tok_53676);
    _39backed_up_tok_53676 = _21815;

    /** 	loop_stack = {}*/
    RefDS(_21815);
    DeRefi(_39loop_stack_53703);
    _39loop_stack_53703 = _21815;

    /** 	stmt_nest = 0*/
    _39stmt_nest_53701 = 0;

    /** 	loop_labels = {}*/
    RefDS(_21815);
    DeRef(_39loop_labels_53697);
    _39loop_labels_53697 = _21815;

    /** 	if_labels = {}*/
    RefDS(_21815);
    DeRef(_39if_labels_53698);
    _39if_labels_53698 = _21815;

    /** 	if_stack = {}*/
    RefDS(_21815);
    DeRefi(_39if_stack_53704);
    _39if_stack_53704 = _21815;

    /** 	continue_addr = {}*/
    RefDS(_21815);
    DeRefi(_39continue_addr_53694);
    _39continue_addr_53694 = _21815;

    /** 	retry_addr = {}*/
    RefDS(_21815);
    DeRefi(_39retry_addr_53695);
    _39retry_addr_53695 = _21815;

    /** 	entry_addr = {}*/
    RefDS(_21815);
    DeRefi(_39entry_addr_53693);
    _39entry_addr_53693 = _21815;

    /** 	block_list = {}*/
    RefDS(_21815);
    DeRefi(_39block_list_53699);
    _39block_list_53699 = _21815;

    /** 	block_index = 0*/
    _39block_index_53700 = 0;

    /** 	param_num = -1*/
    _39param_num_53678 = -1;

    /** 	entry_stack = {}*/
    RefDS(_21815);
    DeRef(_39entry_stack_53696);
    _39entry_stack_53696 = _21815;

    /** 	goto_init = map:new()*/
    _0 = _28new(690);
    DeRef(_39goto_init_53686);
    _39goto_init_53686 = _0;

    /** end procedure*/
    return;
    ;
}


void _39NotReached(int _tok_53913, int _keyword_53914)
{
    int _27698 = NOVALUE;
    int _27697 = NOVALUE;
    int _27696 = NOVALUE;
    int _27695 = NOVALUE;
    int _27694 = NOVALUE;
    int _27693 = NOVALUE;
    int _27691 = NOVALUE;
    int _27690 = NOVALUE;
    int _27689 = NOVALUE;
    int _27688 = NOVALUE;
    int _27686 = NOVALUE;
    int _27685 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_53913)) {
        _1 = (long)(DBL_PTR(_tok_53913)->dbl);
        DeRefDS(_tok_53913);
        _tok_53913 = _1;
    }

    /** 	if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 402;
    *((int *)(_2+8)) = 23;
    *((int *)(_2+12)) = 414;
    *((int *)(_2+16)) = -21;
    *((int *)(_2+20)) = 186;
    *((int *)(_2+24)) = 407;
    *((int *)(_2+28)) = 408;
    *((int *)(_2+32)) = 409;
    _27685 = MAKE_SEQ(_1);
    _27686 = find_from(_tok_53913, _27685, 1);
    DeRefDS(_27685);
    _27685 = NOVALUE;
    if (_27686 != 0)
    goto L1; // [39] 135
    _27686 = NOVALUE;

    /** 		if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_53914 == _26052)
    _27688 = 1;
    else if (IS_ATOM_INT(_keyword_53914) && IS_ATOM_INT(_26052))
    _27688 = 0;
    else
    _27688 = (compare(_keyword_53914, _26052) == 0);
    if (_27688 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 422;
    *((int *)(_2+8)) = 419;
    *((int *)(_2+12)) = 47;
    _27690 = MAKE_SEQ(_1);
    _27691 = find_from(_tok_53913, _27690, 1);
    DeRefDS(_27690);
    _27690 = NOVALUE;
    if (_27691 == 0)
    {
        _27691 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27691 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_53914);
    return;
L2: 

    /** 		if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_53914 == _27692)
    _27693 = 1;
    else if (IS_ATOM_INT(_keyword_53914) && IS_ATOM_INT(_27692))
    _27693 = 0;
    else
    _27693 = (compare(_keyword_53914, _27692) == 0);
    if (_27693 == 0) {
        goto L3; // [85] 105
    }
    _27695 = (_tok_53913 == 419);
    if (_27695 == 0)
    {
        DeRef(_27695);
        _27695 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27695);
        _27695 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_53914);
    return;
L3: 

    /** 		Warning(218, not_reached_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _27696 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_27696);
    _27697 = _53name_ext(_27696);
    _27696 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27697;
    *((int *)(_2+8)) = _35line_number_15969;
    RefDS(_keyword_53914);
    *((int *)(_2+12)) = _keyword_53914;
    _27698 = MAKE_SEQ(_1);
    _27697 = NOVALUE;
    _44Warning(218, 512, _27698);
    _27698 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDSi(_keyword_53914);
    return;
    ;
}


void _39Forward_InitCheck(int _tok_53953, int _ref_53954)
{
    int _sym_53956 = NOVALUE;
    int _27704 = NOVALUE;
    int _27703 = NOVALUE;
    int _27702 = NOVALUE;
    int _27700 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ref then*/
    if (_ref_53954 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** 		integer sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_53953);
    _sym_53956 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_53956)){
        _sym_53956 = (long)DBL_PTR(_sym_53956)->dbl;
    }

    /** 		if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_53953);
    _27700 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27700, 512)){
        _27700 = NOVALUE;
        goto L2; // [28] 50
    }
    _27700 = NOVALUE;

    /** 			set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27702 = (int)*(((s1_ptr)_2)->base + _sym_53956);
    _2 = (int)SEQ_PTR(_27702);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _27703 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _27703 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _27702 = NOVALUE;
    Ref(_27703);
    _61set_qualified_fwd(_27703);
    _27703 = NOVALUE;
L2: 

    /** 		ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (int)SEQ_PTR(_tok_53953);
    _27704 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_27704);
    _ref_53954 = _38new_forward_reference(109, _27704, 109);
    _27704 = NOVALUE;
    if (!IS_ATOM_INT(_ref_53954)) {
        _1 = (long)(DBL_PTR(_ref_53954)->dbl);
        DeRefDS(_ref_53954);
        _ref_53954 = _1;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _41emit_op(109);

    /** 		emit_addr( sym )*/
    _41emit_addr(_sym_53956);
L1: 

    /** end procedure*/
    DeRef(_tok_53953);
    return;
    ;
}


void _39InitCheck(int _sym_53981, int _ref_53982)
{
    int _27781 = NOVALUE;
    int _27780 = NOVALUE;
    int _27779 = NOVALUE;
    int _27778 = NOVALUE;
    int _27777 = NOVALUE;
    int _27776 = NOVALUE;
    int _27775 = NOVALUE;
    int _27774 = NOVALUE;
    int _27772 = NOVALUE;
    int _27770 = NOVALUE;
    int _27769 = NOVALUE;
    int _27767 = NOVALUE;
    int _27766 = NOVALUE;
    int _27765 = NOVALUE;
    int _27764 = NOVALUE;
    int _27763 = NOVALUE;
    int _27762 = NOVALUE;
    int _27761 = NOVALUE;
    int _27760 = NOVALUE;
    int _27759 = NOVALUE;
    int _27758 = NOVALUE;
    int _27757 = NOVALUE;
    int _27756 = NOVALUE;
    int _27755 = NOVALUE;
    int _27754 = NOVALUE;
    int _27752 = NOVALUE;
    int _27751 = NOVALUE;
    int _27750 = NOVALUE;
    int _27749 = NOVALUE;
    int _27748 = NOVALUE;
    int _27747 = NOVALUE;
    int _27746 = NOVALUE;
    int _27745 = NOVALUE;
    int _27744 = NOVALUE;
    int _27742 = NOVALUE;
    int _27741 = NOVALUE;
    int _27740 = NOVALUE;
    int _27739 = NOVALUE;
    int _27738 = NOVALUE;
    int _27737 = NOVALUE;
    int _27736 = NOVALUE;
    int _27735 = NOVALUE;
    int _27734 = NOVALUE;
    int _27733 = NOVALUE;
    int _27732 = NOVALUE;
    int _27731 = NOVALUE;
    int _27730 = NOVALUE;
    int _27729 = NOVALUE;
    int _27728 = NOVALUE;
    int _27727 = NOVALUE;
    int _27726 = NOVALUE;
    int _27725 = NOVALUE;
    int _27724 = NOVALUE;
    int _27723 = NOVALUE;
    int _27722 = NOVALUE;
    int _27721 = NOVALUE;
    int _27719 = NOVALUE;
    int _27718 = NOVALUE;
    int _27717 = NOVALUE;
    int _27716 = NOVALUE;
    int _27715 = NOVALUE;
    int _27714 = NOVALUE;
    int _27713 = NOVALUE;
    int _27712 = NOVALUE;
    int _27711 = NOVALUE;
    int _27710 = NOVALUE;
    int _27709 = NOVALUE;
    int _27708 = NOVALUE;
    int _27706 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27706 = (_sym_53981 < 0);
    if (_27706 != 0) {
        goto L1; // [11] 90
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27708 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27708);
    _27709 = (int)*(((s1_ptr)_2)->base + 3);
    _27708 = NOVALUE;
    if (IS_ATOM_INT(_27709)) {
        _27710 = (_27709 == 1);
    }
    else {
        _27710 = binary_op(EQUALS, _27709, 1);
    }
    _27709 = NOVALUE;
    if (IS_ATOM_INT(_27710)) {
        if (_27710 == 0) {
            _27711 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27710)->dbl == 0.0) {
            _27711 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27712 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27712);
    _27713 = (int)*(((s1_ptr)_2)->base + 4);
    _27712 = NOVALUE;
    if (IS_ATOM_INT(_27713)) {
        _27714 = (_27713 != 2);
    }
    else {
        _27714 = binary_op(NOTEQ, _27713, 2);
    }
    _27713 = NOVALUE;
    DeRef(_27711);
    if (IS_ATOM_INT(_27714))
    _27711 = (_27714 != 0);
    else
    _27711 = DBL_PTR(_27714)->dbl != 0.0;
L2: 
    if (_27711 == 0) {
        DeRef(_27715);
        _27715 = 0;
        goto L3; // [59] 85
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27716 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27716);
    _27717 = (int)*(((s1_ptr)_2)->base + 4);
    _27716 = NOVALUE;
    if (IS_ATOM_INT(_27717)) {
        _27718 = (_27717 != 4);
    }
    else {
        _27718 = binary_op(NOTEQ, _27717, 4);
    }
    _27717 = NOVALUE;
    if (IS_ATOM_INT(_27718))
    _27715 = (_27718 != 0);
    else
    _27715 = DBL_PTR(_27718)->dbl != 0.0;
L3: 
    if (_27715 == 0)
    {
        _27715 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27715 = NOVALUE;
    }
L1: 

    /** 		if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _27719 = (_sym_53981 < 0);
    if (_27719 != 0) {
        goto L5; // [96] 213
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27721 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27721);
    _27722 = (int)*(((s1_ptr)_2)->base + 4);
    _27721 = NOVALUE;
    if (IS_ATOM_INT(_27722)) {
        _27723 = (_27722 != 3);
    }
    else {
        _27723 = binary_op(NOTEQ, _27722, 3);
    }
    _27722 = NOVALUE;
    if (IS_ATOM_INT(_27723)) {
        if (_27723 == 0) {
            DeRef(_27724);
            _27724 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_27723)->dbl == 0.0) {
            DeRef(_27724);
            _27724 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27725 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27725);
    _27726 = (int)*(((s1_ptr)_2)->base + 1);
    _27725 = NOVALUE;
    if (_27726 == _35NOVALUE_15823)
    _27727 = 1;
    else if (IS_ATOM_INT(_27726) && IS_ATOM_INT(_35NOVALUE_15823))
    _27727 = 0;
    else
    _27727 = (compare(_27726, _35NOVALUE_15823) == 0);
    _27726 = NOVALUE;
    DeRef(_27724);
    _27724 = (_27727 != 0);
L6: 
    if (_27724 != 0) {
        DeRef(_27728);
        _27728 = 1;
        goto L7; // [144] 208
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27729 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27729);
    _27730 = (int)*(((s1_ptr)_2)->base + 4);
    _27729 = NOVALUE;
    if (IS_ATOM_INT(_27730)) {
        _27731 = (_27730 == 3);
    }
    else {
        _27731 = binary_op(EQUALS, _27730, 3);
    }
    _27730 = NOVALUE;
    if (IS_ATOM_INT(_27731)) {
        if (_27731 == 0) {
            DeRef(_27732);
            _27732 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_27731)->dbl == 0.0) {
            DeRef(_27732);
            _27732 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27733 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27733);
    _27734 = (int)*(((s1_ptr)_2)->base + 16);
    _27733 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27735 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_27735);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _27736 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _27736 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _27735 = NOVALUE;
    if (IS_ATOM_INT(_27734) && IS_ATOM_INT(_27736)) {
        _27737 = (_27734 >= _27736);
    }
    else {
        _27737 = binary_op(GREATEREQ, _27734, _27736);
    }
    _27734 = NOVALUE;
    _27736 = NOVALUE;
    DeRef(_27732);
    if (IS_ATOM_INT(_27737))
    _27732 = (_27737 != 0);
    else
    _27732 = DBL_PTR(_27737)->dbl != 0.0;
L8: 
    DeRef(_27728);
    _27728 = (_27732 != 0);
L7: 
    if (_27728 == 0)
    {
        _27728 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _27728 = NOVALUE;
    }
L5: 

    /** 			if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _27738 = (_sym_53981 < 0);
    if (_27738 != 0) {
        _27739 = 1;
        goto LA; // [219] 243
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27740 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27740);
    _27741 = (int)*(((s1_ptr)_2)->base + 14);
    _27740 = NOVALUE;
    if (IS_ATOM_INT(_27741)) {
        _27742 = (_27741 == -1);
    }
    else {
        _27742 = binary_op(EQUALS, _27741, -1);
    }
    _27741 = NOVALUE;
    if (IS_ATOM_INT(_27742))
    _27739 = (_27742 != 0);
    else
    _27739 = DBL_PTR(_27742)->dbl != 0.0;
LA: 
    if (_27739 != 0) {
        goto LB; // [243] 270
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27744 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27744);
    _27745 = (int)*(((s1_ptr)_2)->base + 4);
    _27744 = NOVALUE;
    if (IS_ATOM_INT(_27745)) {
        _27746 = (_27745 != 3);
    }
    else {
        _27746 = binary_op(NOTEQ, _27745, 3);
    }
    _27745 = NOVALUE;
    if (_27746 == 0) {
        DeRef(_27746);
        _27746 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_27746) && DBL_PTR(_27746)->dbl == 0.0){
            DeRef(_27746);
            _27746 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_27746);
        _27746 = NOVALUE;
    }
    DeRef(_27746);
    _27746 = NOVALUE;
LB: 

    /** 				if ref then*/
    if (_ref_53982 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** 					if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _27747 = (_sym_53981 > 0);
    if (_27747 == 0) {
        goto LD; // [281] 317
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27749 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27749);
    _27750 = (int)*(((s1_ptr)_2)->base + 4);
    _27749 = NOVALUE;
    if (IS_ATOM_INT(_27750)) {
        _27751 = (_27750 == 9);
    }
    else {
        _27751 = binary_op(EQUALS, _27750, 9);
    }
    _27750 = NOVALUE;
    if (_27751 == 0) {
        DeRef(_27751);
        _27751 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_27751) && DBL_PTR(_27751)->dbl == 0.0){
            DeRef(_27751);
            _27751 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_27751);
        _27751 = NOVALUE;
    }
    DeRef(_27751);
    _27751 = NOVALUE;

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _41emit_op(30);
    goto LE; // [314] 369
LD: 

    /** 					elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _27752 = (_sym_53981 < 0);
    if (_27752 != 0) {
        goto LF; // [323] 351
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27754 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27754);
    _27755 = (int)*(((s1_ptr)_2)->base + 4);
    _27754 = NOVALUE;
    _27756 = find_from(_27755, _39SCOPE_TYPES_53660, 1);
    _27755 = NOVALUE;
    if (_27756 == 0)
    {
        _27756 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _27756 = NOVALUE;
    }
LF: 

    /** 						emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _41emit_op(109);
    goto LE; // [358] 369
L10: 

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _41emit_op(30);
LE: 

    /** 					emit_addr(sym)*/
    _41emit_addr(_sym_53981);
LC: 

    /** 				if sym > 0 */
    _27757 = (_sym_53981 > 0);
    if (_27757 == 0) {
        _27758 = 0;
        goto L11; // [381] 411
    }
    _27759 = (_39short_circuit_53669 <= 0);
    if (_27759 != 0) {
        _27760 = 1;
        goto L12; // [391] 407
    }
    _27761 = (_39short_circuit_B_53671 == _13FALSE_435);
    _27760 = (_27761 != 0);
L12: 
    _27758 = (_27760 != 0);
L11: 
    if (_27758 == 0) {
        goto L9; // [411] 566
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27763 = (int)*(((s1_ptr)_2)->base + _sym_53981);
    _2 = (int)SEQ_PTR(_27763);
    _27764 = (int)*(((s1_ptr)_2)->base + 4);
    _27763 = NOVALUE;
    if (IS_ATOM_INT(_27764)) {
        _27765 = (_27764 != 3);
    }
    else {
        _27765 = binary_op(NOTEQ, _27764, 3);
    }
    _27764 = NOVALUE;
    if (IS_ATOM_INT(_27765)) {
        _27766 = (_27765 == 0);
    }
    else {
        _27766 = unary_op(NOT, _27765);
    }
    DeRef(_27765);
    _27765 = NOVALUE;
    if (_27766 == 0) {
        DeRef(_27766);
        _27766 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_27766) && DBL_PTR(_27766)->dbl == 0.0){
            DeRef(_27766);
            _27766 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_27766);
        _27766 = NOVALUE;
    }
    DeRef(_27766);
    _27766 = NOVALUE;

    /** 					if CurrentSub != TopLevelSub */
    _27767 = (_35CurrentSub_15976 != _35TopLevelSub_15975);
    if (_27767 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_36known_files_14982)){
            _27769 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _27769 = 1;
    }
    _27770 = (_35current_file_no_15968 == _27769);
    _27769 = NOVALUE;
    if (_27770 == 0)
    {
        DeRef(_27770);
        _27770 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_27770);
        _27770 = NOVALUE;
    }
L13: 

    /** 						init_stack = append(init_stack, sym)*/
    Append(&_39init_stack_53702, _39init_stack_53702, _sym_53981);

    /** 						SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_53981 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _39stmt_nest_53701;
    DeRef(_1);
    _27772 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** 	elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_53982 == 0) {
        _27774 = 0;
        goto L14; // [504] 516
    }
    _27775 = (_sym_53981 > 0);
    _27774 = (_27775 != 0);
L14: 
    if (_27774 == 0) {
        _27776 = 0;
        goto L15; // [516] 534
    }
    _27777 = _53sym_mode(_sym_53981);
    if (IS_ATOM_INT(_27777)) {
        _27778 = (_27777 == 2);
    }
    else {
        _27778 = binary_op(EQUALS, _27777, 2);
    }
    DeRef(_27777);
    _27777 = NOVALUE;
    if (IS_ATOM_INT(_27778))
    _27776 = (_27778 != 0);
    else
    _27776 = DBL_PTR(_27778)->dbl != 0.0;
L15: 
    if (_27776 == 0) {
        goto L16; // [534] 565
    }
    _27780 = _53sym_obj(_sym_53981);
    if (_35NOVALUE_15823 == _27780)
    _27781 = 1;
    else if (IS_ATOM_INT(_35NOVALUE_15823) && IS_ATOM_INT(_27780))
    _27781 = 0;
    else
    _27781 = (compare(_35NOVALUE_15823, _27780) == 0);
    DeRef(_27780);
    _27780 = NOVALUE;
    if (_27781 == 0)
    {
        _27781 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _27781 = NOVALUE;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _41emit_op(109);

    /** 		emit_addr(sym)*/
    _41emit_addr(_sym_53981);
L16: 
L9: 

    /** end procedure*/
    DeRef(_27706);
    _27706 = NOVALUE;
    DeRef(_27719);
    _27719 = NOVALUE;
    DeRef(_27710);
    _27710 = NOVALUE;
    DeRef(_27714);
    _27714 = NOVALUE;
    DeRef(_27718);
    _27718 = NOVALUE;
    DeRef(_27738);
    _27738 = NOVALUE;
    DeRef(_27723);
    _27723 = NOVALUE;
    DeRef(_27731);
    _27731 = NOVALUE;
    DeRef(_27747);
    _27747 = NOVALUE;
    DeRef(_27737);
    _27737 = NOVALUE;
    DeRef(_27742);
    _27742 = NOVALUE;
    DeRef(_27752);
    _27752 = NOVALUE;
    DeRef(_27757);
    _27757 = NOVALUE;
    DeRef(_27759);
    _27759 = NOVALUE;
    DeRef(_27761);
    _27761 = NOVALUE;
    DeRef(_27767);
    _27767 = NOVALUE;
    DeRef(_27775);
    _27775 = NOVALUE;
    DeRef(_27778);
    _27778 = NOVALUE;
    return;
    ;
}


void _39InitDelete()
{
    int _27794 = NOVALUE;
    int _27793 = NOVALUE;
    int _27791 = NOVALUE;
    int _27790 = NOVALUE;
    int _27789 = NOVALUE;
    int _27788 = NOVALUE;
    int _27787 = NOVALUE;
    int _27786 = NOVALUE;
    int _27785 = NOVALUE;
    int _27784 = NOVALUE;
    int _27783 = NOVALUE;
    int _27782 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_39init_stack_53702)){
            _27782 = SEQ_PTR(_39init_stack_53702)->length;
    }
    else {
        _27782 = 1;
    }
    if (_27782 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_39init_stack_53702)){
            _27784 = SEQ_PTR(_39init_stack_53702)->length;
    }
    else {
        _27784 = 1;
    }
    _2 = (int)SEQ_PTR(_39init_stack_53702);
    _27785 = (int)*(((s1_ptr)_2)->base + _27784);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27786 = (int)*(((s1_ptr)_2)->base + _27785);
    _2 = (int)SEQ_PTR(_27786);
    _27787 = (int)*(((s1_ptr)_2)->base + 14);
    _27786 = NOVALUE;
    if (IS_ATOM_INT(_27787)) {
        _27788 = (_27787 > _39stmt_nest_53701);
    }
    else {
        _27788 = binary_op(GREATER, _27787, _39stmt_nest_53701);
    }
    _27787 = NOVALUE;
    if (_27788 <= 0) {
        if (_27788 == 0) {
            DeRef(_27788);
            _27788 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_27788) && DBL_PTR(_27788)->dbl == 0.0){
                DeRef(_27788);
                _27788 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_27788);
            _27788 = NOVALUE;
        }
    }
    DeRef(_27788);
    _27788 = NOVALUE;

    /** 		SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_39init_stack_53702)){
            _27789 = SEQ_PTR(_39init_stack_53702)->length;
    }
    else {
        _27789 = 1;
    }
    _2 = (int)SEQ_PTR(_39init_stack_53702);
    _27790 = (int)*(((s1_ptr)_2)->base + _27789);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_27790 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _27791 = NOVALUE;

    /** 		init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_39init_stack_53702)){
            _27793 = SEQ_PTR(_39init_stack_53702)->length;
    }
    else {
        _27793 = 1;
    }
    _27794 = _27793 - 1;
    _27793 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39init_stack_53702;
    RHS_Slice(_39init_stack_53702, 1, _27794);

    /** 	end while*/
    goto L1; // [88] 6
L2: 

    /** end procedure*/
    _27785 = NOVALUE;
    _27790 = NOVALUE;
    DeRef(_27794);
    _27794 = NOVALUE;
    return;
    ;
}


void _39emit_forward_addr()
{
    int _27796 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_35Code_16056)){
            _27796 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _27796 = 1;
    }
    Append(&_39branch_list_53667, _39branch_list_53667, _27796);
    _27796 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39StraightenBranches()
{
    int _br_54155 = NOVALUE;
    int _target_54156 = NOVALUE;
    int _27817 = NOVALUE;
    int _27816 = NOVALUE;
    int _27815 = NOVALUE;
    int _27814 = NOVALUE;
    int _27812 = NOVALUE;
    int _27811 = NOVALUE;
    int _27810 = NOVALUE;
    int _27808 = NOVALUE;
    int _27807 = NOVALUE;
    int _27806 = NOVALUE;
    int _27805 = NOVALUE;
    int _27803 = NOVALUE;
    int _27800 = NOVALUE;
    int _27799 = NOVALUE;
    int _27798 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return -- do it in back-end*/
    return;
L1: 

    /** 	for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_39branch_list_53667)){
            _27798 = SEQ_PTR(_39branch_list_53667)->length;
    }
    else {
        _27798 = 1;
    }
    {
        int _i_54160;
        _i_54160 = _27798;
L2: 
        if (_i_54160 < 1){
            goto L3; // [21] 170
        }

        /** 		if branch_list[i] > length(Code) then*/
        _2 = (int)SEQ_PTR(_39branch_list_53667);
        _27799 = (int)*(((s1_ptr)_2)->base + _i_54160);
        if (IS_SEQUENCE(_35Code_16056)){
                _27800 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _27800 = 1;
        }
        if (binary_op_a(LESSEQ, _27799, _27800)){
            _27799 = NOVALUE;
            _27800 = NOVALUE;
            goto L4; // [41] 53
        }
        _27799 = NOVALUE;
        _27800 = NOVALUE;

        /** 			CompileErr("wtf")*/
        RefDS(_27802);
        RefDS(_21815);
        _44CompileErr(_27802, _21815, 0);
L4: 

        /** 		target = Code[branch_list[i]]*/
        _2 = (int)SEQ_PTR(_39branch_list_53667);
        _27803 = (int)*(((s1_ptr)_2)->base + _i_54160);
        _2 = (int)SEQ_PTR(_35Code_16056);
        if (!IS_ATOM_INT(_27803)){
            _target_54156 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27803)->dbl));
        }
        else{
            _target_54156 = (int)*(((s1_ptr)_2)->base + _27803);
        }
        if (!IS_ATOM_INT(_target_54156)){
            _target_54156 = (long)DBL_PTR(_target_54156)->dbl;
        }

        /** 		if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_35Code_16056)){
                _27805 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _27805 = 1;
        }
        _27806 = (_target_54156 <= _27805);
        _27805 = NOVALUE;
        if (_27806 == 0) {
            goto L5; // [80] 163
        }
        _27808 = (_target_54156 > 0);
        if (_27808 == 0)
        {
            DeRef(_27808);
            _27808 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_27808);
            _27808 = NOVALUE;
        }

        /** 			br = Code[target]*/
        _2 = (int)SEQ_PTR(_35Code_16056);
        _br_54155 = (int)*(((s1_ptr)_2)->base + _target_54156);
        if (!IS_ATOM_INT(_br_54155)){
            _br_54155 = (long)DBL_PTR(_br_54155)->dbl;
        }

        /** 			if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _27810 = (_br_54155 == 23);
        if (_27810 != 0) {
            _27811 = 1;
            goto L6; // [110] 124
        }
        _27812 = (_br_54155 == 22);
        _27811 = (_27812 != 0);
L6: 
        if (_27811 != 0) {
            goto L7; // [124] 139
        }
        _27814 = (_br_54155 == 61);
        if (_27814 == 0)
        {
            DeRef(_27814);
            _27814 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_27814);
            _27814 = NOVALUE;
        }
L7: 

        /** 				backpatch(branch_list[i], Code[target+1])*/
        _2 = (int)SEQ_PTR(_39branch_list_53667);
        _27815 = (int)*(((s1_ptr)_2)->base + _i_54160);
        _27816 = _target_54156 + 1;
        _2 = (int)SEQ_PTR(_35Code_16056);
        _27817 = (int)*(((s1_ptr)_2)->base + _27816);
        Ref(_27815);
        Ref(_27817);
        _41backpatch(_27815, _27817);
        _27815 = NOVALUE;
        _27817 = NOVALUE;
L8: 
L5: 

        /** 	end for*/
        _i_54160 = _i_54160 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** 	branch_list = {}*/
    RefDS(_21815);
    DeRef(_39branch_list_53667);
    _39branch_list_53667 = _21815;

    /** end procedure*/
    _27803 = NOVALUE;
    DeRef(_27806);
    _27806 = NOVALUE;
    DeRef(_27810);
    _27810 = NOVALUE;
    DeRef(_27812);
    _27812 = NOVALUE;
    DeRef(_27816);
    _27816 = NOVALUE;
    return;
    ;
}


void _39PatchEList(int _base_54208)
{
    int _break_top_54209 = NOVALUE;
    int _n_54210 = NOVALUE;
    int _27834 = NOVALUE;
    int _27833 = NOVALUE;
    int _27832 = NOVALUE;
    int _27828 = NOVALUE;
    int _27827 = NOVALUE;
    int _27826 = NOVALUE;
    int _27824 = NOVALUE;
    int _27823 = NOVALUE;
    int _27821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(break_list) then*/
    if (IS_SEQUENCE(_39break_list_53687)){
            _27821 = SEQ_PTR(_39break_list_53687)->length;
    }
    else {
        _27821 = 1;
    }
    if (_27821 != 0)
    goto L1; // [10] 19
    _27821 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	break_top = 0*/
    _break_top_54209 = 0;

    /** 	for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39break_list_53687)){
            _27823 = SEQ_PTR(_39break_list_53687)->length;
    }
    else {
        _27823 = 1;
    }
    _27824 = _base_54208 + 1;
    if (_27824 > MAXINT){
        _27824 = NewDouble((double)_27824);
    }
    {
        int _i_54215;
        _i_54215 = _27823;
L2: 
        if (binary_op_a(LESS, _i_54215, _27824)){
            goto L3; // [35] 129
        }

        /** 		n=break_delay[i]*/
        _2 = (int)SEQ_PTR(_39break_delay_53688);
        if (!IS_ATOM_INT(_i_54215)){
            _n_54210 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54215)->dbl));
        }
        else{
            _n_54210 = (int)*(((s1_ptr)_2)->base + _i_54215);
        }
        if (!IS_ATOM_INT(_n_54210))
        _n_54210 = (long)DBL_PTR(_n_54210)->dbl;

        /** 		break_delay[i] -= (n>0)*/
        _27826 = (_n_54210 > 0);
        _2 = (int)SEQ_PTR(_39break_delay_53688);
        if (!IS_ATOM_INT(_i_54215)){
            _27827 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54215)->dbl));
        }
        else{
            _27827 = (int)*(((s1_ptr)_2)->base + _i_54215);
        }
        if (IS_ATOM_INT(_27827)) {
            _27828 = _27827 - _27826;
            if ((long)((unsigned long)_27828 +(unsigned long) HIGH_BITS) >= 0){
                _27828 = NewDouble((double)_27828);
            }
        }
        else {
            _27828 = binary_op(MINUS, _27827, _27826);
        }
        _27827 = NOVALUE;
        _27826 = NOVALUE;
        _2 = (int)SEQ_PTR(_39break_delay_53688);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39break_delay_53688 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54215))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54215)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54215);
        _1 = *(int *)_2;
        *(int *)_2 = _27828;
        if( _1 != _27828 ){
            DeRef(_1);
        }
        _27828 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54210 <= 1)
        goto L4; // [72] 93

        /** 			if break_top = 0 then*/
        if (_break_top_54209 != 0)
        goto L5; // [78] 122

        /** 				break_top = i*/
        Ref(_i_54215);
        _break_top_54209 = _i_54215;
        if (!IS_ATOM_INT(_break_top_54209)) {
            _1 = (long)(DBL_PTR(_break_top_54209)->dbl);
            DeRefDS(_break_top_54209);
            _break_top_54209 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54210 != 1)
        goto L6; // [95] 121

        /** 			backpatch(break_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39break_list_53687);
        if (!IS_ATOM_INT(_i_54215)){
            _27832 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54215)->dbl));
        }
        else{
            _27832 = (int)*(((s1_ptr)_2)->base + _i_54215);
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _27833 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _27833 = 1;
        }
        _27834 = _27833 + 1;
        _27833 = NOVALUE;
        _41backpatch(_27832, _27834);
        _27832 = NOVALUE;
        _27834 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54215;
        if (IS_ATOM_INT(_i_54215)) {
            _i_54215 = _i_54215 + -1;
            if ((long)((unsigned long)_i_54215 +(unsigned long) HIGH_BITS) >= 0){
                _i_54215 = NewDouble((double)_i_54215);
            }
        }
        else {
            _i_54215 = binary_op_a(PLUS, _i_54215, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54215);
    }

    /** 	if break_top=0 then*/
    if (_break_top_54209 != 0)
    goto L7; // [131] 141

    /** 	    break_top=base*/
    _break_top_54209 = _base_54208;
L7: 

    /** 	break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_39break_delay_53688;
    RHS_Slice(_39break_delay_53688, 1, _break_top_54209);

    /** 	break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_39break_list_53687;
    RHS_Slice(_39break_list_53687, 1, _break_top_54209);

    /** end procedure*/
    DeRef(_27824);
    _27824 = NOVALUE;
    return;
    ;
}


void _39PatchNList(int _base_54239)
{
    int _next_top_54240 = NOVALUE;
    int _n_54241 = NOVALUE;
    int _27851 = NOVALUE;
    int _27850 = NOVALUE;
    int _27849 = NOVALUE;
    int _27845 = NOVALUE;
    int _27844 = NOVALUE;
    int _27843 = NOVALUE;
    int _27841 = NOVALUE;
    int _27840 = NOVALUE;
    int _27838 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(continue_list) then*/
    if (IS_SEQUENCE(_39continue_list_53691)){
            _27838 = SEQ_PTR(_39continue_list_53691)->length;
    }
    else {
        _27838 = 1;
    }
    if (_27838 != 0)
    goto L1; // [10] 19
    _27838 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	next_top = 0*/
    _next_top_54240 = 0;

    /** 	for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39continue_list_53691)){
            _27840 = SEQ_PTR(_39continue_list_53691)->length;
    }
    else {
        _27840 = 1;
    }
    _27841 = _base_54239 + 1;
    if (_27841 > MAXINT){
        _27841 = NewDouble((double)_27841);
    }
    {
        int _i_54246;
        _i_54246 = _27840;
L2: 
        if (binary_op_a(LESS, _i_54246, _27841)){
            goto L3; // [35] 129
        }

        /** 		n=continue_delay[i]*/
        _2 = (int)SEQ_PTR(_39continue_delay_53692);
        if (!IS_ATOM_INT(_i_54246)){
            _n_54241 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54246)->dbl));
        }
        else{
            _n_54241 = (int)*(((s1_ptr)_2)->base + _i_54246);
        }
        if (!IS_ATOM_INT(_n_54241))
        _n_54241 = (long)DBL_PTR(_n_54241)->dbl;

        /** 		continue_delay[i] -= (n>0)*/
        _27843 = (_n_54241 > 0);
        _2 = (int)SEQ_PTR(_39continue_delay_53692);
        if (!IS_ATOM_INT(_i_54246)){
            _27844 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54246)->dbl));
        }
        else{
            _27844 = (int)*(((s1_ptr)_2)->base + _i_54246);
        }
        if (IS_ATOM_INT(_27844)) {
            _27845 = _27844 - _27843;
            if ((long)((unsigned long)_27845 +(unsigned long) HIGH_BITS) >= 0){
                _27845 = NewDouble((double)_27845);
            }
        }
        else {
            _27845 = binary_op(MINUS, _27844, _27843);
        }
        _27844 = NOVALUE;
        _27843 = NOVALUE;
        _2 = (int)SEQ_PTR(_39continue_delay_53692);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39continue_delay_53692 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54246))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54246)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54246);
        _1 = *(int *)_2;
        *(int *)_2 = _27845;
        if( _1 != _27845 ){
            DeRef(_1);
        }
        _27845 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54241 <= 1)
        goto L4; // [72] 93

        /** 			if next_top = 0 then*/
        if (_next_top_54240 != 0)
        goto L5; // [78] 122

        /** 				next_top = i*/
        Ref(_i_54246);
        _next_top_54240 = _i_54246;
        if (!IS_ATOM_INT(_next_top_54240)) {
            _1 = (long)(DBL_PTR(_next_top_54240)->dbl);
            DeRefDS(_next_top_54240);
            _next_top_54240 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54241 != 1)
        goto L6; // [95] 121

        /** 			backpatch(continue_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39continue_list_53691);
        if (!IS_ATOM_INT(_i_54246)){
            _27849 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54246)->dbl));
        }
        else{
            _27849 = (int)*(((s1_ptr)_2)->base + _i_54246);
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _27850 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _27850 = 1;
        }
        _27851 = _27850 + 1;
        _27850 = NOVALUE;
        _41backpatch(_27849, _27851);
        _27849 = NOVALUE;
        _27851 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54246;
        if (IS_ATOM_INT(_i_54246)) {
            _i_54246 = _i_54246 + -1;
            if ((long)((unsigned long)_i_54246 +(unsigned long) HIGH_BITS) >= 0){
                _i_54246 = NewDouble((double)_i_54246);
            }
        }
        else {
            _i_54246 = binary_op_a(PLUS, _i_54246, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54246);
    }

    /** 	if next_top=0 then*/
    if (_next_top_54240 != 0)
    goto L7; // [131] 141

    /** 	    next_top=base*/
    _next_top_54240 = _base_54239;
L7: 

    /** 	continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_39continue_delay_53692;
    RHS_Slice(_39continue_delay_53692, 1, _next_top_54240);

    /** 	continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_39continue_list_53691;
    RHS_Slice(_39continue_list_53691, 1, _next_top_54240);

    /** end procedure*/
    DeRef(_27841);
    _27841 = NOVALUE;
    return;
    ;
}


void _39PatchXList(int _base_54270)
{
    int _exit_top_54271 = NOVALUE;
    int _n_54272 = NOVALUE;
    int _27868 = NOVALUE;
    int _27867 = NOVALUE;
    int _27866 = NOVALUE;
    int _27862 = NOVALUE;
    int _27861 = NOVALUE;
    int _27860 = NOVALUE;
    int _27858 = NOVALUE;
    int _27857 = NOVALUE;
    int _27855 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(exit_list) then*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _27855 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _27855 = 1;
    }
    if (_27855 != 0)
    goto L1; // [10] 19
    _27855 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	exit_top = 0*/
    _exit_top_54271 = 0;

    /** 	for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _27857 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _27857 = 1;
    }
    _27858 = _base_54270 + 1;
    if (_27858 > MAXINT){
        _27858 = NewDouble((double)_27858);
    }
    {
        int _i_54277;
        _i_54277 = _27857;
L2: 
        if (binary_op_a(LESS, _i_54277, _27858)){
            goto L3; // [35] 129
        }

        /** 		n=exit_delay[i]*/
        _2 = (int)SEQ_PTR(_39exit_delay_53690);
        if (!IS_ATOM_INT(_i_54277)){
            _n_54272 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54277)->dbl));
        }
        else{
            _n_54272 = (int)*(((s1_ptr)_2)->base + _i_54277);
        }
        if (!IS_ATOM_INT(_n_54272))
        _n_54272 = (long)DBL_PTR(_n_54272)->dbl;

        /** 		exit_delay[i] -= (n>0)*/
        _27860 = (_n_54272 > 0);
        _2 = (int)SEQ_PTR(_39exit_delay_53690);
        if (!IS_ATOM_INT(_i_54277)){
            _27861 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54277)->dbl));
        }
        else{
            _27861 = (int)*(((s1_ptr)_2)->base + _i_54277);
        }
        if (IS_ATOM_INT(_27861)) {
            _27862 = _27861 - _27860;
            if ((long)((unsigned long)_27862 +(unsigned long) HIGH_BITS) >= 0){
                _27862 = NewDouble((double)_27862);
            }
        }
        else {
            _27862 = binary_op(MINUS, _27861, _27860);
        }
        _27861 = NOVALUE;
        _27860 = NOVALUE;
        _2 = (int)SEQ_PTR(_39exit_delay_53690);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39exit_delay_53690 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54277))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54277)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54277);
        _1 = *(int *)_2;
        *(int *)_2 = _27862;
        if( _1 != _27862 ){
            DeRef(_1);
        }
        _27862 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54272 <= 1)
        goto L4; // [72] 93

        /** 			if exit_top = 0 then*/
        if (_exit_top_54271 != 0)
        goto L5; // [78] 122

        /** 				exit_top = i*/
        Ref(_i_54277);
        _exit_top_54271 = _i_54277;
        if (!IS_ATOM_INT(_exit_top_54271)) {
            _1 = (long)(DBL_PTR(_exit_top_54271)->dbl);
            DeRefDS(_exit_top_54271);
            _exit_top_54271 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54272 != 1)
        goto L6; // [95] 121

        /** 			backpatch(exit_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_39exit_list_53689);
        if (!IS_ATOM_INT(_i_54277)){
            _27866 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54277)->dbl));
        }
        else{
            _27866 = (int)*(((s1_ptr)_2)->base + _i_54277);
        }
        if (IS_SEQUENCE(_35Code_16056)){
                _27867 = SEQ_PTR(_35Code_16056)->length;
        }
        else {
            _27867 = 1;
        }
        _27868 = _27867 + 1;
        _27867 = NOVALUE;
        _41backpatch(_27866, _27868);
        _27866 = NOVALUE;
        _27868 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54277;
        if (IS_ATOM_INT(_i_54277)) {
            _i_54277 = _i_54277 + -1;
            if ((long)((unsigned long)_i_54277 +(unsigned long) HIGH_BITS) >= 0){
                _i_54277 = NewDouble((double)_i_54277);
            }
        }
        else {
            _i_54277 = binary_op_a(PLUS, _i_54277, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54277);
    }

    /** 	if exit_top=0 then*/
    if (_exit_top_54271 != 0)
    goto L7; // [131] 141

    /** 	    exit_top=base*/
    _exit_top_54271 = _base_54270;
L7: 

    /** 	exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_39exit_delay_53690;
    RHS_Slice(_39exit_delay_53690, 1, _exit_top_54271);

    /** 	exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_39exit_list_53689;
    RHS_Slice(_39exit_list_53689, 1, _exit_top_54271);

    /** end procedure*/
    DeRef(_27858);
    _27858 = NOVALUE;
    return;
    ;
}


void _39putback(int _t_54302)
{
    int _27873 = NOVALUE;
    int _0, _1, _2;
    

    /** 	backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_54302);
    Append(&_39backed_up_tok_53676, _39backed_up_tok_53676, _t_54302);

    /** 	if t[T_SYM] then*/
    _2 = (int)SEQ_PTR(_t_54302);
    _27873 = (int)*(((s1_ptr)_2)->base + 2);
    if (_27873 == 0) {
        _27873 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_27873) && DBL_PTR(_27873)->dbl == 0.0){
            _27873 = NOVALUE;
            goto L1; // [17] 79
        }
        _27873 = NOVALUE;
    }
    _27873 = NOVALUE;

    /** 		putback_ForwardLine     = ForwardLine*/
    Ref(_44ForwardLine_48143);
    DeRef(_44putback_ForwardLine_48144);
    _44putback_ForwardLine_48144 = _44ForwardLine_48143;

    /** 		putback_forward_bp      = forward_bp*/
    _44putback_forward_bp_48148 = _44forward_bp_48147;

    /** 		putback_fwd_line_number = fwd_line_number*/
    _35putback_fwd_line_number_15971 = _35fwd_line_number_15970;

    /** 		if last_fwd_line_number then*/
    if (_35last_fwd_line_number_15972 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** 			ForwardLine     = last_ForwardLine*/
    Ref(_44last_ForwardLine_48145);
    DeRef(_44ForwardLine_48143);
    _44ForwardLine_48143 = _44last_ForwardLine_48145;

    /** 			forward_bp      = last_forward_bp*/
    _44forward_bp_48147 = _44last_forward_bp_48149;

    /** 			fwd_line_number = last_fwd_line_number*/
    _35fwd_line_number_15970 = _35last_fwd_line_number_15972;
L2: 
L1: 

    /** end procedure*/
    DeRef(_t_54302);
    return;
    ;
}


void _39start_recording()
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_39psm_stack_54321, _39psm_stack_54321, _35Parser_mode_16073);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_39canned_tokens_53713);
    Append(&_39can_stack_54322, _39can_stack_54322, _39canned_tokens_53713);

    /** 	idx_stack &= canned_index*/
    Append(&_39idx_stack_54323, _39idx_stack_54323, _39canned_index_53714);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_39backed_up_tok_53676);
    Append(&_39tok_stack_54324, _39tok_stack_54324, _39backed_up_tok_53676);

    /** 	canned_tokens = {}*/
    RefDS(_21815);
    DeRef(_39canned_tokens_53713);
    _39canned_tokens_53713 = _21815;

    /** 	Parser_mode = PAM_RECORD*/
    _35Parser_mode_16073 = 1;

    /** 	clear_last()*/
    _41clear_last();

    /** end procedure*/
    return;
    ;
}


int _39restore_parser()
{
    int _n_54337 = NOVALUE;
    int _tok_54338 = NOVALUE;
    int _x_54339 = NOVALUE;
    int _27904 = NOVALUE;
    int _27903 = NOVALUE;
    int _27902 = NOVALUE;
    int _27900 = NOVALUE;
    int _27896 = NOVALUE;
    int _27895 = NOVALUE;
    int _27893 = NOVALUE;
    int _27891 = NOVALUE;
    int _27890 = NOVALUE;
    int _27888 = NOVALUE;
    int _27886 = NOVALUE;
    int _27885 = NOVALUE;
    int _27883 = NOVALUE;
    int _27881 = NOVALUE;
    int _27880 = NOVALUE;
    int _27878 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n=Parser_mode*/
    _n_54337 = _35Parser_mode_16073;

    /** 	x = canned_tokens*/
    Ref(_39canned_tokens_53713);
    DeRef(_x_54339);
    _x_54339 = _39canned_tokens_53713;

    /** 	canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_39can_stack_54322)){
            _27878 = SEQ_PTR(_39can_stack_54322)->length;
    }
    else {
        _27878 = 1;
    }
    DeRef(_39canned_tokens_53713);
    _2 = (int)SEQ_PTR(_39can_stack_54322);
    _39canned_tokens_53713 = (int)*(((s1_ptr)_2)->base + _27878);
    Ref(_39canned_tokens_53713);

    /** 	can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_39can_stack_54322)){
            _27880 = SEQ_PTR(_39can_stack_54322)->length;
    }
    else {
        _27880 = 1;
    }
    _27881 = _27880 - 1;
    _27880 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39can_stack_54322;
    RHS_Slice(_39can_stack_54322, 1, _27881);

    /** 	canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_39idx_stack_54323)){
            _27883 = SEQ_PTR(_39idx_stack_54323)->length;
    }
    else {
        _27883 = 1;
    }
    _2 = (int)SEQ_PTR(_39idx_stack_54323);
    _39canned_index_53714 = (int)*(((s1_ptr)_2)->base + _27883);

    /** 	idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_39idx_stack_54323)){
            _27885 = SEQ_PTR(_39idx_stack_54323)->length;
    }
    else {
        _27885 = 1;
    }
    _27886 = _27885 - 1;
    _27885 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39idx_stack_54323;
    RHS_Slice(_39idx_stack_54323, 1, _27886);

    /** 	Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_39psm_stack_54321)){
            _27888 = SEQ_PTR(_39psm_stack_54321)->length;
    }
    else {
        _27888 = 1;
    }
    _2 = (int)SEQ_PTR(_39psm_stack_54321);
    _35Parser_mode_16073 = (int)*(((s1_ptr)_2)->base + _27888);

    /** 	psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_39psm_stack_54321)){
            _27890 = SEQ_PTR(_39psm_stack_54321)->length;
    }
    else {
        _27890 = 1;
    }
    _27891 = _27890 - 1;
    _27890 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39psm_stack_54321;
    RHS_Slice(_39psm_stack_54321, 1, _27891);

    /** 	tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_39tok_stack_54324)){
            _27893 = SEQ_PTR(_39tok_stack_54324)->length;
    }
    else {
        _27893 = 1;
    }
    DeRef(_tok_54338);
    _2 = (int)SEQ_PTR(_39tok_stack_54324);
    _tok_54338 = (int)*(((s1_ptr)_2)->base + _27893);
    RefDS(_tok_54338);

    /** 	tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_39tok_stack_54324)){
            _27895 = SEQ_PTR(_39tok_stack_54324)->length;
    }
    else {
        _27895 = 1;
    }
    _27896 = _27895 - 1;
    _27895 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39tok_stack_54324;
    RHS_Slice(_39tok_stack_54324, 1, _27896);

    /** 	clear_last()*/
    _41clear_last();

    /** 	if n=PAM_PLAYBACK then*/
    if (_n_54337 != -1)
    goto L1; // [137] 150

    /** 		return {}*/
    RefDS(_21815);
    DeRefDS(_tok_54338);
    DeRefDS(_x_54339);
    _27881 = NOVALUE;
    _27886 = NOVALUE;
    _27891 = NOVALUE;
    _27896 = NOVALUE;
    return _21815;
    goto L2; // [147] 167
L1: 

    /** 	elsif n = PAM_NORMAL then*/
    if (_n_54337 != 0)
    goto L3; // [154] 166

    /** 		use_private_list = 0*/
    _35use_private_list_16081 = 0;
L3: 
L2: 

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_39backed_up_tok_53676)){
            _27900 = SEQ_PTR(_39backed_up_tok_53676)->length;
    }
    else {
        _27900 = 1;
    }
    if (_27900 <= 0)
    goto L4; // [174] 199

    /** 		return x[1..$-1]*/
    if (IS_SEQUENCE(_x_54339)){
            _27902 = SEQ_PTR(_x_54339)->length;
    }
    else {
        _27902 = 1;
    }
    _27903 = _27902 - 1;
    _27902 = NOVALUE;
    rhs_slice_target = (object_ptr)&_27904;
    RHS_Slice(_x_54339, 1, _27903);
    DeRef(_tok_54338);
    DeRefDS(_x_54339);
    DeRef(_27881);
    _27881 = NOVALUE;
    DeRef(_27886);
    _27886 = NOVALUE;
    DeRef(_27891);
    _27891 = NOVALUE;
    DeRef(_27896);
    _27896 = NOVALUE;
    _27903 = NOVALUE;
    return _27904;
    goto L5; // [196] 206
L4: 

    /** 		return x*/
    DeRef(_tok_54338);
    DeRef(_27881);
    _27881 = NOVALUE;
    DeRef(_27886);
    _27886 = NOVALUE;
    DeRef(_27891);
    _27891 = NOVALUE;
    DeRef(_27896);
    _27896 = NOVALUE;
    DeRef(_27903);
    _27903 = NOVALUE;
    DeRef(_27904);
    _27904 = NOVALUE;
    return _x_54339;
L5: 
    ;
}


void _39start_playback(int _s_54379)
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_39psm_stack_54321, _39psm_stack_54321, _35Parser_mode_16073);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_39canned_tokens_53713);
    Append(&_39can_stack_54322, _39can_stack_54322, _39canned_tokens_53713);

    /** 	idx_stack &= canned_index*/
    Append(&_39idx_stack_54323, _39idx_stack_54323, _39canned_index_53714);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_39backed_up_tok_53676);
    Append(&_39tok_stack_54324, _39tok_stack_54324, _39backed_up_tok_53676);

    /** 	canned_index = 1*/
    _39canned_index_53714 = 1;

    /** 	canned_tokens = s*/
    RefDS(_s_54379);
    DeRef(_39canned_tokens_53713);
    _39canned_tokens_53713 = _s_54379;

    /** 	backed_up_tok = {}*/
    RefDS(_21815);
    DeRefDS(_39backed_up_tok_53676);
    _39backed_up_tok_53676 = _21815;

    /** 	Parser_mode = PAM_PLAYBACK*/
    _35Parser_mode_16073 = -1;

    /** end procedure*/
    DeRefDS(_s_54379);
    return;
    ;
}


void _39restore_parseargs_states()
{
    int _s_54398 = NOVALUE;
    int _n_54399 = NOVALUE;
    int _27921 = NOVALUE;
    int _27920 = NOVALUE;
    int _27912 = NOVALUE;
    int _27911 = NOVALUE;
    int _27909 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = parseargs_states[$]*/
    if (IS_SEQUENCE(_39parseargs_states_54387)){
            _27909 = SEQ_PTR(_39parseargs_states_54387)->length;
    }
    else {
        _27909 = 1;
    }
    DeRef(_s_54398);
    _2 = (int)SEQ_PTR(_39parseargs_states_54387);
    _s_54398 = (int)*(((s1_ptr)_2)->base + _27909);
    RefDS(_s_54398);

    /** 	parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_39parseargs_states_54387)){
            _27911 = SEQ_PTR(_39parseargs_states_54387)->length;
    }
    else {
        _27911 = 1;
    }
    _27912 = _27911 - 1;
    _27911 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39parseargs_states_54387;
    RHS_Slice(_39parseargs_states_54387, 1, _27912);

    /** 	n=s[PS_POSITION]*/
    _2 = (int)SEQ_PTR(_s_54398);
    _n_54399 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54399))
    _n_54399 = (long)DBL_PTR(_n_54399)->dbl;

    /** 	private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_39private_list_54392;
    RHS_Slice(_39private_list_54392, 1, _n_54399);

    /** 	private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_35private_sym_16080;
    RHS_Slice(_35private_sym_16080, 1, _n_54399);

    /** 	lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (int)SEQ_PTR(_s_54398);
    _39lock_scanner_54393 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_39lock_scanner_54393))
    _39lock_scanner_54393 = (long)DBL_PTR(_39lock_scanner_54393)->dbl;

    /** 	use_private_list = s[PS_USE_LIST]*/
    _2 = (int)SEQ_PTR(_s_54398);
    _35use_private_list_16081 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35use_private_list_16081)){
        _35use_private_list_16081 = (long)DBL_PTR(_35use_private_list_16081)->dbl;
    }

    /** 	on_arg = s[PS_ON_ARG]*/
    _2 = (int)SEQ_PTR(_s_54398);
    _39on_arg_54394 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_39on_arg_54394))
    _39on_arg_54394 = (long)DBL_PTR(_39on_arg_54394)->dbl;

    /** 	nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_39nested_calls_54395)){
            _27920 = SEQ_PTR(_39nested_calls_54395)->length;
    }
    else {
        _27920 = 1;
    }
    _27921 = _27920 - 1;
    _27920 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39nested_calls_54395;
    RHS_Slice(_39nested_calls_54395, 1, _27921);

    /** end procedure*/
    DeRefDS(_s_54398);
    _27912 = NOVALUE;
    _27921 = NOVALUE;
    return;
    ;
}


int _39read_recorded_token(int _n_54419)
{
    int _t_54421 = NOVALUE;
    int _p_54422 = NOVALUE;
    int _prev_Nne_54423 = NOVALUE;
    int _ts_54452 = NOVALUE;
    int _31374 = NOVALUE;
    int _31373 = NOVALUE;
    int _31372 = NOVALUE;
    int _31371 = NOVALUE;
    int _31370 = NOVALUE;
    int _31369 = NOVALUE;
    int _31368 = NOVALUE;
    int _31367 = NOVALUE;
    int _27995 = NOVALUE;
    int _27994 = NOVALUE;
    int _27993 = NOVALUE;
    int _27992 = NOVALUE;
    int _27988 = NOVALUE;
    int _27986 = NOVALUE;
    int _27985 = NOVALUE;
    int _27984 = NOVALUE;
    int _27983 = NOVALUE;
    int _27981 = NOVALUE;
    int _27980 = NOVALUE;
    int _27978 = NOVALUE;
    int _27977 = NOVALUE;
    int _27975 = NOVALUE;
    int _27972 = NOVALUE;
    int _27970 = NOVALUE;
    int _27968 = NOVALUE;
    int _27967 = NOVALUE;
    int _27966 = NOVALUE;
    int _27965 = NOVALUE;
    int _27962 = NOVALUE;
    int _27960 = NOVALUE;
    int _27956 = NOVALUE;
    int _27954 = NOVALUE;
    int _27952 = NOVALUE;
    int _27951 = NOVALUE;
    int _27950 = NOVALUE;
    int _27949 = NOVALUE;
    int _27948 = NOVALUE;
    int _27947 = NOVALUE;
    int _27946 = NOVALUE;
    int _27945 = NOVALUE;
    int _27944 = NOVALUE;
    int _27943 = NOVALUE;
    int _27942 = NOVALUE;
    int _27941 = NOVALUE;
    int _27939 = NOVALUE;
    int _27938 = NOVALUE;
    int _27936 = NOVALUE;
    int _27935 = NOVALUE;
    int _27934 = NOVALUE;
    int _27933 = NOVALUE;
    int _27932 = NOVALUE;
    int _27931 = NOVALUE;
    int _27930 = NOVALUE;
    int _27929 = NOVALUE;
    int _27926 = NOVALUE;
    int _27924 = NOVALUE;
    int _27923 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_54419)) {
        _1 = (long)(DBL_PTR(_n_54419)->dbl);
        DeRefDS(_n_54419);
        _n_54419 = _1;
    }

    /** 	integer p, prev_Nne*/

    /** 	if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16075);
    _27923 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _27924 = IS_ATOM(_27923);
    _27923 = NOVALUE;
    if (_27924 == 0)
    {
        _27924 = NOVALUE;
        goto L1; // [16] 403
    }
    else{
        _27924 = NOVALUE;
    }

    /** 		if use_private_list then*/
    if (_35use_private_list_16081 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** 			p = find( Recorded[n], private_list)*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27926 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _p_54422 = find_from(_27926, _39private_list_54392, 1);
    _27926 = NOVALUE;

    /** 			if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_54422 <= 0)
    goto L3; // [43] 170

    /** 				if TRANSLATE*/
    if (_35TRANSLATE_15611 == 0) {
        goto L4; // [51] 150
    }
    _2 = (int)SEQ_PTR(_35private_sym_16080);
    _27930 = (int)*(((s1_ptr)_2)->base + _p_54422);
    if (IS_ATOM_INT(_27930)) {
        _27931 = (_27930 < 0);
    }
    else {
        _27931 = binary_op(LESS, _27930, 0);
    }
    _27930 = NOVALUE;
    if (IS_ATOM_INT(_27931)) {
        if (_27931 != 0) {
            _27932 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_27931)->dbl != 0.0) {
            _27932 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (int)SEQ_PTR(_35private_sym_16080);
    _27933 = (int)*(((s1_ptr)_2)->base + _p_54422);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_27933)){
        _27934 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27933)->dbl));
    }
    else{
        _27934 = (int)*(((s1_ptr)_2)->base + _27933);
    }
    _2 = (int)SEQ_PTR(_27934);
    _27935 = (int)*(((s1_ptr)_2)->base + 3);
    _27934 = NOVALUE;
    if (IS_ATOM_INT(_27935)) {
        _27936 = (_27935 == 3);
    }
    else {
        _27936 = binary_op(EQUALS, _27935, 3);
    }
    _27935 = NOVALUE;
    DeRef(_27932);
    if (IS_ATOM_INT(_27936))
    _27932 = (_27936 != 0);
    else
    _27932 = DBL_PTR(_27936)->dbl != 0.0;
L5: 
    if (_27932 == 0)
    {
        _27932 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _27932 = NOVALUE;
    }

    /** 					symtab_index ts = NewTempSym()*/
    _ts_54452 = _53NewTempSym(0);
    if (!IS_ATOM_INT(_ts_54452)) {
        _1 = (long)(DBL_PTR(_ts_54452)->dbl);
        DeRefDS(_ts_54452);
        _ts_54452 = _1;
    }

    /** 					Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (int)SEQ_PTR(_35private_sym_16080);
    _27938 = (int)*(((s1_ptr)_2)->base + _p_54422);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    Ref(_27938);
    *((int *)(_2+8)) = _27938;
    *((int *)(_2+12)) = _ts_54452;
    _27939 = MAKE_SEQ(_1);
    _27938 = NOVALUE;
    Concat((object_ptr)&_35Code_16056, _35Code_16056, _27939);
    DeRefDS(_27939);
    _27939 = NOVALUE;

    /** 					return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _ts_54452;
    _27941 = MAKE_SEQ(_1);
    DeRef(_t_54421);
    _27933 = NOVALUE;
    DeRef(_27931);
    _27931 = NOVALUE;
    DeRef(_27936);
    _27936 = NOVALUE;
    return _27941;
    goto L6; // [147] 169
L4: 

    /** 					return {VARIABLE, private_sym[p]}*/
    _2 = (int)SEQ_PTR(_35private_sym_16080);
    _27942 = (int)*(((s1_ptr)_2)->base + _p_54422);
    Ref(_27942);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _27942;
    _27943 = MAKE_SEQ(_1);
    _27942 = NOVALUE;
    DeRef(_t_54421);
    _27933 = NOVALUE;
    DeRef(_27931);
    _27931 = NOVALUE;
    DeRef(_27941);
    _27941 = NOVALUE;
    DeRef(_27936);
    _27936 = NOVALUE;
    return _27943;
L6: 
L3: 
L2: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54423 = _53No_new_entry_46887;

    /** 		No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 		if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _27944 = (int)*(((s1_ptr)_2)->base + _n_54419);
    if (IS_ATOM_INT(_27944)) {
        _27945 = (_27944 > 0);
    }
    else {
        _27945 = binary_op(GREATER, _27944, 0);
    }
    _27944 = NOVALUE;
    if (IS_ATOM_INT(_27945)) {
        if (_27945 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_27945)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _27947 = (int)*(((s1_ptr)_2)->base + _n_54419);
    Ref(_27947);
    _27948 = _53sym_scope(_27947);
    _27947 = NOVALUE;
    if (IS_ATOM_INT(_27948)) {
        _27949 = (_27948 != 9);
    }
    else {
        _27949 = binary_op(NOTEQ, _27948, 9);
    }
    DeRef(_27948);
    _27948 = NOVALUE;
    if (_27949 == 0) {
        DeRef(_27949);
        _27949 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_27949) && DBL_PTR(_27949)->dbl == 0.0){
            DeRef(_27949);
            _27949 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_27949);
        _27949 = NOVALUE;
    }
    DeRef(_27949);
    _27949 = NOVALUE;

    /** 			t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _27950 = (int)*(((s1_ptr)_2)->base + _n_54419);
    Ref(_27950);
    _27951 = _53sym_token(_27950);
    _27950 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _27952 = (int)*(((s1_ptr)_2)->base + _n_54419);
    Ref(_27952);
    DeRef(_t_54421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27951;
    ((int *)_2)[2] = _27952;
    _t_54421 = MAKE_SEQ(_1);
    _27952 = NOVALUE;
    _27951 = NOVALUE;

    /** 			break "top if"*/
    goto L8; // [247] 728
L7: 

    /** 		t = keyfind(Recorded[n],-1)*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27954 = (int)*(((s1_ptr)_2)->base + _n_54419);
    RefDS(_27954);
    DeRef(_31373);
    _31373 = _27954;
    _31374 = _53hashfn(_31373);
    _31373 = NOVALUE;
    RefDS(_27954);
    _0 = _t_54421;
    _t_54421 = _53keyfind(_27954, -1, _35current_file_no_15968, 0, _31374);
    DeRef(_0);
    _27954 = NOVALUE;
    _31374 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54421);
    _27956 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27956, 509)){
        _27956 = NOVALUE;
        goto L8; // [286] 728
    }
    _27956 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _p_54422 = (int)*(((s1_ptr)_2)->base + _n_54419);
    if (!IS_ATOM_INT(_p_54422)){
        _p_54422 = (long)DBL_PTR(_p_54422)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54422 != 0)
    goto L9; // [302] 380

    /** 				No_new_entry = 0*/
    _53No_new_entry_46887 = 0;

    /** 				t = keyfind( Recorded[n], -1 )*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27960 = (int)*(((s1_ptr)_2)->base + _n_54419);
    RefDS(_27960);
    DeRef(_31371);
    _31371 = _27960;
    _31372 = _53hashfn(_31371);
    _31371 = NOVALUE;
    RefDS(_27960);
    _0 = _t_54421;
    _t_54421 = _53keyfind(_27960, -1, _35current_file_no_15968, 0, _31372);
    DeRef(_0);
    _27960 = NOVALUE;
    _31372 = NOVALUE;

    /** 				No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 				if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54421);
    _27962 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27962, 509)){
        _27962 = NOVALUE;
        goto L8; // [355] 728
    }
    _27962 = NOVALUE;

    /** 					CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27965 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_27965);
    *((int *)(_2+4)) = _27965;
    _27966 = MAKE_SEQ(_1);
    _27965 = NOVALUE;
    _44CompileErr(157, _27966, 0);
    _27966 = NOVALUE;
    goto L8; // [377] 728
L9: 

    /** 				t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27967 = (int)*(((s1_ptr)_2)->base + _p_54422);
    _2 = (int)SEQ_PTR(_27967);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _27968 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _27968 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _27967 = NOVALUE;
    Ref(_27968);
    DeRef(_t_54421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27968;
    ((int *)_2)[2] = _p_54422;
    _t_54421 = MAKE_SEQ(_1);
    _27968 = NOVALUE;
    goto L8; // [400] 728
L1: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54423 = _53No_new_entry_46887;

    /** 		No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 		t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16075);
    _27970 = (int)*(((s1_ptr)_2)->base + _n_54419);
    Ref(_27970);
    DeRef(_31369);
    _31369 = _27970;
    _31370 = _53hashfn(_31369);
    _31369 = NOVALUE;
    Ref(_27970);
    _0 = _t_54421;
    _t_54421 = _53keyfind(_27970, -1, _35current_file_no_15968, 1, _31370);
    DeRef(_0);
    _27970 = NOVALUE;
    _31370 = NOVALUE;

    /** 		if t[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_54421);
    _27972 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _27972, 523)){
        _27972 = NOVALUE;
        goto LA; // [454] 520
    }
    _27972 = NOVALUE;

    /** 			p = Ns_recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_sym_16077);
    _p_54422 = (int)*(((s1_ptr)_2)->base + _n_54419);
    if (!IS_ATOM_INT(_p_54422)){
        _p_54422 = (long)DBL_PTR(_p_54422)->dbl;
    }

    /** 			if p = 0 or sym_token( p ) != NAMESPACE then*/
    _27975 = (_p_54422 == 0);
    if (_27975 != 0) {
        goto LB; // [474] 493
    }
    _27977 = _53sym_token(_p_54422);
    if (IS_ATOM_INT(_27977)) {
        _27978 = (_27977 != 523);
    }
    else {
        _27978 = binary_op(NOTEQ, _27977, 523);
    }
    DeRef(_27977);
    _27977 = NOVALUE;
    if (_27978 == 0) {
        DeRef(_27978);
        _27978 = NOVALUE;
        goto LC; // [489] 511
    }
    else {
        if (!IS_ATOM_INT(_27978) && DBL_PTR(_27978)->dbl == 0.0){
            DeRef(_27978);
            _27978 = NOVALUE;
            goto LC; // [489] 511
        }
        DeRef(_27978);
        _27978 = NOVALUE;
    }
    DeRef(_27978);
    _27978 = NOVALUE;
LB: 

    /** 				CompileErr(153, {Ns_recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Ns_recorded_16075);
    _27980 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27980);
    *((int *)(_2+4)) = _27980;
    _27981 = MAKE_SEQ(_1);
    _27980 = NOVALUE;
    _44CompileErr(153, _27981, 0);
    _27981 = NOVALUE;
LC: 

    /** 			t = {NAMESPACE, p}*/
    DeRef(_t_54421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 523;
    ((int *)_2)[2] = _p_54422;
    _t_54421 = MAKE_SEQ(_1);
LA: 

    /** 		t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27983 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _2 = (int)SEQ_PTR(_t_54421);
    _27984 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_27984)){
        _27985 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27984)->dbl));
    }
    else{
        _27985 = (int)*(((s1_ptr)_2)->base + _27984);
    }
    _2 = (int)SEQ_PTR(_27985);
    _27986 = (int)*(((s1_ptr)_2)->base + 1);
    _27985 = NOVALUE;
    RefDS(_27983);
    DeRef(_31367);
    _31367 = _27983;
    _31368 = _53hashfn(_31367);
    _31367 = NOVALUE;
    RefDS(_27983);
    Ref(_27986);
    _0 = _t_54421;
    _t_54421 = _53keyfind(_27983, _27986, _35current_file_no_15968, 0, _31368);
    DeRef(_0);
    _27983 = NOVALUE;
    _27986 = NOVALUE;
    _31368 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54421);
    _27988 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27988, 509)){
        _27988 = NOVALUE;
        goto LD; // [573] 630
    }
    _27988 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_35Recorded_sym_16076);
    _p_54422 = (int)*(((s1_ptr)_2)->base + _n_54419);
    if (!IS_ATOM_INT(_p_54422)){
        _p_54422 = (long)DBL_PTR(_p_54422)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54422 != 0)
    goto LE; // [589] 611

    /** 	        	CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_35Recorded_16074);
    _27992 = (int)*(((s1_ptr)_2)->base + _n_54419);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_27992);
    *((int *)(_2+4)) = _27992;
    _27993 = MAKE_SEQ(_1);
    _27992 = NOVALUE;
    _44CompileErr(157, _27993, 0);
    _27993 = NOVALUE;
LE: 

    /** 		    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _27994 = (int)*(((s1_ptr)_2)->base + _p_54422);
    _2 = (int)SEQ_PTR(_27994);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _27995 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _27995 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _27994 = NOVALUE;
    Ref(_27995);
    DeRef(_t_54421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27995;
    ((int *)_2)[2] = _p_54422;
    _t_54421 = MAKE_SEQ(_1);
    _27995 = NOVALUE;
LD: 

    /** 		n = t[T_ID]*/
    _2 = (int)SEQ_PTR(_t_54421);
    _n_54419 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54419)){
        _n_54419 = (long)DBL_PTR(_n_54419)->dbl;
    }

    /** 		if n = VARIABLE then*/
    if (_n_54419 != -100)
    goto LF; // [644] 660

    /** 			n = QUALIFIED_VARIABLE*/
    _n_54419 = 512;
    goto L10; // [657] 719
LF: 

    /** 		elsif n = FUNC then*/
    if (_n_54419 != 501)
    goto L11; // [664] 680

    /** 			n = QUALIFIED_FUNC*/
    _n_54419 = 520;
    goto L10; // [677] 719
L11: 

    /** 		elsif n = PROC then*/
    if (_n_54419 != 27)
    goto L12; // [684] 700

    /** 			n = QUALIFIED_PROC*/
    _n_54419 = 521;
    goto L10; // [697] 719
L12: 

    /** 		elsif n = TYPE then*/
    if (_n_54419 != 504)
    goto L13; // [704] 718

    /** 			n = QUALIFIED_TYPE*/
    _n_54419 = 522;
L13: 
L10: 

    /** 		t[T_ID] = n*/
    _2 = (int)SEQ_PTR(_t_54421);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_54421 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _n_54419;
    DeRef(_1);
L8: 

    /** 	No_new_entry = prev_Nne*/
    _53No_new_entry_46887 = _prev_Nne_54423;

    /**   	return t*/
    _27933 = NOVALUE;
    DeRef(_27931);
    _27931 = NOVALUE;
    DeRef(_27941);
    _27941 = NOVALUE;
    DeRef(_27936);
    _27936 = NOVALUE;
    DeRef(_27943);
    _27943 = NOVALUE;
    DeRef(_27975);
    _27975 = NOVALUE;
    DeRef(_27945);
    _27945 = NOVALUE;
    _27984 = NOVALUE;
    return _t_54421;
    ;
}


int _39next_token()
{
    int _t_54602 = NOVALUE;
    int _s_54603 = NOVALUE;
    int _28034 = NOVALUE;
    int _28033 = NOVALUE;
    int _28032 = NOVALUE;
    int _28031 = NOVALUE;
    int _28030 = NOVALUE;
    int _28029 = NOVALUE;
    int _28028 = NOVALUE;
    int _28027 = NOVALUE;
    int _28025 = NOVALUE;
    int _28024 = NOVALUE;
    int _28023 = NOVALUE;
    int _28022 = NOVALUE;
    int _28020 = NOVALUE;
    int _28018 = NOVALUE;
    int _28016 = NOVALUE;
    int _28012 = NOVALUE;
    int _28009 = NOVALUE;
    int _28006 = NOVALUE;
    int _28004 = NOVALUE;
    int _28002 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence s*/

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_39backed_up_tok_53676)){
            _28002 = SEQ_PTR(_39backed_up_tok_53676)->length;
    }
    else {
        _28002 = 1;
    }
    if (_28002 <= 0)
    goto L1; // [10] 82

    /** 		t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_39backed_up_tok_53676)){
            _28004 = SEQ_PTR(_39backed_up_tok_53676)->length;
    }
    else {
        _28004 = 1;
    }
    DeRef(_t_54602);
    _2 = (int)SEQ_PTR(_39backed_up_tok_53676);
    _t_54602 = (int)*(((s1_ptr)_2)->base + _28004);
    Ref(_t_54602);

    /** 		backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_39backed_up_tok_53676)){
            _28006 = SEQ_PTR(_39backed_up_tok_53676)->length;
    }
    else {
        _28006 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39backed_up_tok_53676);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28006)) ? _28006 : (long)(DBL_PTR(_28006)->dbl);
        int stop = (IS_ATOM_INT(_28006)) ? _28006 : (long)(DBL_PTR(_28006)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39backed_up_tok_53676), start, &_39backed_up_tok_53676 );
            }
            else Tail(SEQ_PTR(_39backed_up_tok_53676), stop+1, &_39backed_up_tok_53676);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39backed_up_tok_53676), start, &_39backed_up_tok_53676);
        }
        else {
            assign_slice_seq = &assign_space;
            _39backed_up_tok_53676 = Remove_elements(start, stop, (SEQ_PTR(_39backed_up_tok_53676)->ref == 1));
        }
    }
    _28006 = NOVALUE;
    _28006 = NOVALUE;

    /** 		if putback_fwd_line_number then*/
    if (_35putback_fwd_line_number_15971 == 0)
    {
        goto L2; // [43] 347
    }
    else{
    }

    /** 			ForwardLine     = putback_ForwardLine*/
    Ref(_44putback_ForwardLine_48144);
    DeRef(_44ForwardLine_48143);
    _44ForwardLine_48143 = _44putback_ForwardLine_48144;

    /** 			forward_bp      = putback_forward_bp*/
    _44forward_bp_48147 = _44putback_forward_bp_48148;

    /** 			fwd_line_number = putback_fwd_line_number*/
    _35fwd_line_number_15970 = _35putback_fwd_line_number_15971;

    /** 			putback_fwd_line_number = 0*/
    _35putback_fwd_line_number_15971 = 0;
    goto L2; // [79] 347
L1: 

    /** 	elsif Parser_mode = PAM_PLAYBACK then*/
    if (_35Parser_mode_16073 != -1)
    goto L3; // [88] 300

    /** 		if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_39canned_tokens_53713)){
            _28009 = SEQ_PTR(_39canned_tokens_53713)->length;
    }
    else {
        _28009 = 1;
    }
    if (_39canned_index_53714 > _28009)
    goto L4; // [101] 150

    /** 			t = canned_tokens[canned_index]*/
    DeRef(_t_54602);
    _2 = (int)SEQ_PTR(_39canned_tokens_53713);
    _t_54602 = (int)*(((s1_ptr)_2)->base + _39canned_index_53714);
    Ref(_t_54602);

    /** 			if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_39canned_tokens_53713)){
            _28012 = SEQ_PTR(_39canned_tokens_53713)->length;
    }
    else {
        _28012 = 1;
    }
    if (_39canned_index_53714 >= _28012)
    goto L5; // [124] 139

    /** 				canned_index += 1*/
    _39canned_index_53714 = _39canned_index_53714 + 1;
    goto L6; // [136] 157
L5: 

    /** 	            s = restore_parser()*/
    _0 = _s_54603;
    _s_54603 = _39restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** 	    	InternalErr(266)*/
    RefDS(_21815);
    _44InternalErr(266, _21815);
L6: 

    /** 		if t[T_ID] = RECORDED then*/
    _2 = (int)SEQ_PTR(_t_54602);
    _28016 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28016, 508)){
        _28016 = NOVALUE;
        goto L7; // [169] 188
    }
    _28016 = NOVALUE;

    /** 			t=read_recorded_token(t[T_SYM])*/
    _2 = (int)SEQ_PTR(_t_54602);
    _28018 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28018);
    _0 = _t_54602;
    _t_54602 = _39read_recorded_token(_28018);
    DeRef(_0);
    _28018 = NOVALUE;
    goto L2; // [185] 347
L7: 

    /** 		elsif t[T_ID] = DEF_PARAM then*/
    _2 = (int)SEQ_PTR(_t_54602);
    _28020 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28020, 510)){
        _28020 = NOVALUE;
        goto L2; // [198] 347
    }
    _28020 = NOVALUE;

    /**         	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_39nested_calls_54395)){
            _28022 = SEQ_PTR(_39nested_calls_54395)->length;
    }
    else {
        _28022 = 1;
    }
    {
        int _i_54650;
        _i_54650 = _28022;
L8: 
        if (_i_54650 < 1){
            goto L9; // [209] 288
        }

        /**         	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (int)SEQ_PTR(_39nested_calls_54395);
        _28023 = (int)*(((s1_ptr)_2)->base + _i_54650);
        _2 = (int)SEQ_PTR(_t_54602);
        _28024 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28024);
        _28025 = (int)*(((s1_ptr)_2)->base + 2);
        _28024 = NOVALUE;
        if (binary_op_a(NOTEQ, _28023, _28025)){
            _28023 = NOVALUE;
            _28025 = NOVALUE;
            goto LA; // [234] 281
        }
        _28023 = NOVALUE;
        _28025 = NOVALUE;

        /** 					return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (int)SEQ_PTR(_39parseargs_states_54387);
        _28027 = (int)*(((s1_ptr)_2)->base + _i_54650);
        _2 = (int)SEQ_PTR(_28027);
        _28028 = (int)*(((s1_ptr)_2)->base + 1);
        _28027 = NOVALUE;
        _2 = (int)SEQ_PTR(_t_54602);
        _28029 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28029);
        _28030 = (int)*(((s1_ptr)_2)->base + 1);
        _28029 = NOVALUE;
        if (IS_ATOM_INT(_28028) && IS_ATOM_INT(_28030)) {
            _28031 = _28028 + _28030;
        }
        else {
            _28031 = binary_op(PLUS, _28028, _28030);
        }
        _28028 = NOVALUE;
        _28030 = NOVALUE;
        _2 = (int)SEQ_PTR(_35private_sym_16080);
        if (!IS_ATOM_INT(_28031)){
            _28032 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28031)->dbl));
        }
        else{
            _28032 = (int)*(((s1_ptr)_2)->base + _28031);
        }
        Ref(_28032);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _28032;
        _28033 = MAKE_SEQ(_1);
        _28032 = NOVALUE;
        DeRef(_t_54602);
        DeRef(_s_54603);
        DeRef(_28031);
        _28031 = NOVALUE;
        return _28033;
LA: 

        /** 			end for*/
        _i_54650 = _i_54650 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** 			CompileErr(98)*/
    RefDS(_21815);
    _44CompileErr(98, _21815, 0);
    goto L2; // [297] 347
L3: 

    /** 	elsif lock_scanner then*/
    if (_39lock_scanner_54393 == 0)
    {
        goto LB; // [304] 322
    }
    else{
    }

    /** 		return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 505;
    ((int *)_2)[2] = 0;
    _28034 = MAKE_SEQ(_1);
    DeRef(_t_54602);
    DeRef(_s_54603);
    DeRef(_28033);
    _28033 = NOVALUE;
    DeRef(_28031);
    _28031 = NOVALUE;
    return _28034;
    goto L2; // [319] 347
LB: 

    /** 	    t = Scanner()*/
    _0 = _t_54602;
    _t_54602 = _61Scanner();
    DeRef(_0);

    /** 	    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16073 != 1)
    goto LC; // [333] 346

    /** 	        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_54602);
    Append(&_39canned_tokens_53713, _39canned_tokens_53713, _t_54602);
LC: 
L2: 

    /** 	putback_fwd_line_number = 0*/
    _35putback_fwd_line_number_15971 = 0;

    /** 	return t*/
    DeRef(_s_54603);
    DeRef(_28033);
    _28033 = NOVALUE;
    DeRef(_28034);
    _28034 = NOVALUE;
    DeRef(_28031);
    _28031 = NOVALUE;
    return _t_54602;
    ;
}


int _39Expr_list()
{
    int _tok_54685 = NOVALUE;
    int _n_54686 = NOVALUE;
    int _28050 = NOVALUE;
    int _28047 = NOVALUE;
    int _28046 = NOVALUE;
    int _28044 = NOVALUE;
    int _28043 = NOVALUE;
    int _28039 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_54685;
    _tok_54685 = _39next_token();
    DeRef(_0);

    /** 	putback(tok)*/
    Ref(_tok_54685);
    _39putback(_tok_54685);

    /** 	if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_54685);
    _28039 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28039, -25)){
        _28039 = NOVALUE;
        goto L1; // [23] 36
    }
    _28039 = NOVALUE;

    /** 		return 0*/
    DeRef(_tok_54685);
    return 0;
    goto L2; // [33] 142
L1: 

    /** 		n = 0*/
    _n_54686 = 0;

    /** 		short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 		while TRUE do*/
L3: 
    if (_13TRUE_437 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** 			gListItem &= 1*/
    Append(&_39gListItem_53705, _39gListItem_53705, 1);

    /** 			Expr()*/
    _39Expr();

    /** 			n += gListItem[$]*/
    if (IS_SEQUENCE(_39gListItem_53705)){
            _28043 = SEQ_PTR(_39gListItem_53705)->length;
    }
    else {
        _28043 = 1;
    }
    _2 = (int)SEQ_PTR(_39gListItem_53705);
    _28044 = (int)*(((s1_ptr)_2)->base + _28043);
    _n_54686 = _n_54686 + _28044;
    _28044 = NOVALUE;

    /** 			gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_39gListItem_53705)){
            _28046 = SEQ_PTR(_39gListItem_53705)->length;
    }
    else {
        _28046 = 1;
    }
    _28047 = _28046 - 1;
    _28046 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39gListItem_53705;
    RHS_Slice(_39gListItem_53705, 1, _28047);

    /** 			tok = next_token()*/
    _0 = _tok_54685;
    _tok_54685 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_54685);
    _28050 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28050, -30)){
        _28050 = NOVALUE;
        goto L3; // [119] 54
    }
    _28050 = NOVALUE;

    /** 				exit*/
    goto L4; // [125] 133

    /** 		end while*/
    goto L3; // [130] 54
L4: 

    /** 		short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;
L2: 

    /** 	putback(tok)*/
    Ref(_tok_54685);
    _39putback(_tok_54685);

    /** 	return n*/
    DeRef(_tok_54685);
    DeRef(_28047);
    _28047 = NOVALUE;
    return _n_54686;
    ;
}


void _39tok_match(int _tok_54714, int _prevtok_54715)
{
    int _t_54717 = NOVALUE;
    int _expected_54718 = NOVALUE;
    int _actual_54719 = NOVALUE;
    int _prevname_54720 = NOVALUE;
    int _28062 = NOVALUE;
    int _28060 = NOVALUE;
    int _28057 = NOVALUE;
    int _28054 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence expected, actual, prevname*/

    /** 	t = next_token()*/
    _0 = _t_54717;
    _t_54717 = _39next_token();
    DeRef(_0);

    /** 	if t[T_ID] != tok then*/
    _2 = (int)SEQ_PTR(_t_54717);
    _28054 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28054, _tok_54714)){
        _28054 = NOVALUE;
        goto L1; // [20] 92
    }
    _28054 = NOVALUE;

    /** 		expected = LexName(tok)*/
    RefDS(_26183);
    _0 = _expected_54718;
    _expected_54718 = _41LexName(_tok_54714, _26183);
    DeRef(_0);

    /** 		actual = LexName(t[T_ID])*/
    _2 = (int)SEQ_PTR(_t_54717);
    _28057 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28057);
    RefDS(_26183);
    _0 = _actual_54719;
    _actual_54719 = _41LexName(_28057, _26183);
    DeRef(_0);
    _28057 = NOVALUE;

    /** 		if prevtok = 0 then*/
    if (_prevtok_54715 != 0)
    goto L2; // [50] 68

    /** 			CompileErr(132, {expected, actual})*/
    RefDS(_actual_54719);
    RefDS(_expected_54718);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _expected_54718;
    ((int *)_2)[2] = _actual_54719;
    _28060 = MAKE_SEQ(_1);
    _44CompileErr(132, _28060, 0);
    _28060 = NOVALUE;
    goto L3; // [65] 91
L2: 

    /** 			prevname = LexName(prevtok)*/
    RefDS(_26183);
    _0 = _prevname_54720;
    _prevname_54720 = _41LexName(_prevtok_54715, _26183);
    DeRef(_0);

    /** 			CompileErr(138, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_expected_54718);
    *((int *)(_2+4)) = _expected_54718;
    RefDS(_prevname_54720);
    *((int *)(_2+8)) = _prevname_54720;
    RefDS(_actual_54719);
    *((int *)(_2+12)) = _actual_54719;
    _28062 = MAKE_SEQ(_1);
    _44CompileErr(138, _28062, 0);
    _28062 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    DeRef(_t_54717);
    DeRef(_expected_54718);
    DeRef(_actual_54719);
    DeRef(_prevname_54720);
    return;
    ;
}


void _39UndefinedVar(int _s_54754)
{
    int _dup_54756 = NOVALUE;
    int _errmsg_54757 = NOVALUE;
    int _rname_54758 = NOVALUE;
    int _fname_54759 = NOVALUE;
    int _28085 = NOVALUE;
    int _28084 = NOVALUE;
    int _28082 = NOVALUE;
    int _28080 = NOVALUE;
    int _28079 = NOVALUE;
    int _28077 = NOVALUE;
    int _28075 = NOVALUE;
    int _28073 = NOVALUE;
    int _28072 = NOVALUE;
    int _28071 = NOVALUE;
    int _28070 = NOVALUE;
    int _28069 = NOVALUE;
    int _28067 = NOVALUE;
    int _28066 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_54754)) {
        _1 = (long)(DBL_PTR(_s_54754)->dbl);
        DeRefDS(_s_54754);
        _s_54754 = _1;
    }

    /** 	sequence errmsg*/

    /** 	sequence rname*/

    /** 	sequence fname*/

    /** 	if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28066 = (int)*(((s1_ptr)_2)->base + _s_54754);
    _2 = (int)SEQ_PTR(_28066);
    _28067 = (int)*(((s1_ptr)_2)->base + 4);
    _28066 = NOVALUE;
    if (binary_op_a(NOTEQ, _28067, 9)){
        _28067 = NOVALUE;
        goto L1; // [25] 55
    }
    _28067 = NOVALUE;

    /** 		CompileErr(19, {SymTab[s][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28069 = (int)*(((s1_ptr)_2)->base + _s_54754);
    _2 = (int)SEQ_PTR(_28069);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28070 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28070 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28069 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28070);
    *((int *)(_2+4)) = _28070;
    _28071 = MAKE_SEQ(_1);
    _28070 = NOVALUE;
    _44CompileErr(19, _28071, 0);
    _28071 = NOVALUE;
    goto L2; // [52] 202
L1: 

    /** 	elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28072 = (int)*(((s1_ptr)_2)->base + _s_54754);
    _2 = (int)SEQ_PTR(_28072);
    _28073 = (int)*(((s1_ptr)_2)->base + 4);
    _28072 = NOVALUE;
    if (binary_op_a(NOTEQ, _28073, 10)){
        _28073 = NOVALUE;
        goto L3; // [71] 179
    }
    _28073 = NOVALUE;

    /** 		rname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28075 = (int)*(((s1_ptr)_2)->base + _s_54754);
    DeRef(_rname_54758);
    _2 = (int)SEQ_PTR(_28075);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _rname_54758 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _rname_54758 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_rname_54758);
    _28075 = NOVALUE;

    /** 		errmsg = ""*/
    RefDS(_21815);
    DeRef(_errmsg_54757);
    _errmsg_54757 = _21815;

    /** 		for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_53dup_globals_46876)){
            _28077 = SEQ_PTR(_53dup_globals_46876)->length;
    }
    else {
        _28077 = 1;
    }
    {
        int _i_54785;
        _i_54785 = 1;
L4: 
        if (_i_54785 > _28077){
            goto L5; // [105] 163
        }

        /** 			dup = dup_globals[i]*/
        _2 = (int)SEQ_PTR(_53dup_globals_46876);
        _dup_54756 = (int)*(((s1_ptr)_2)->base + _i_54785);
        if (!IS_ATOM_INT(_dup_54756)){
            _dup_54756 = (long)DBL_PTR(_dup_54756)->dbl;
        }

        /** 			fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28079 = (int)*(((s1_ptr)_2)->base + _dup_54756);
        _2 = (int)SEQ_PTR(_28079);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _28080 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _28080 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _28079 = NOVALUE;
        DeRef(_fname_54759);
        _2 = (int)SEQ_PTR(_36known_files_14982);
        if (!IS_ATOM_INT(_28080)){
            _fname_54759 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28080)->dbl));
        }
        else{
            _fname_54759 = (int)*(((s1_ptr)_2)->base + _28080);
        }
        Ref(_fname_54759);

        /** 			errmsg &= "    " & fname & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _21967;
            concat_list[1] = _fname_54759;
            concat_list[2] = _24738;
            Concat_N((object_ptr)&_28082, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_54757, _errmsg_54757, _28082);
        DeRefDS(_28082);
        _28082 = NOVALUE;

        /** 		end for*/
        _i_54785 = _i_54785 + 1;
        goto L4; // [158] 112
L5: 
        ;
    }

    /** 		CompileErr(23, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_rname_54758, 2);
    *((int *)(_2+4)) = _rname_54758;
    *((int *)(_2+8)) = _rname_54758;
    RefDS(_errmsg_54757);
    *((int *)(_2+12)) = _errmsg_54757;
    _28084 = MAKE_SEQ(_1);
    _44CompileErr(23, _28084, 0);
    _28084 = NOVALUE;
    goto L2; // [176] 202
L3: 

    /** 	elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_35symbol_resolution_warning_16069)){
            _28085 = SEQ_PTR(_35symbol_resolution_warning_16069)->length;
    }
    else {
        _28085 = 1;
    }
    if (_28085 == 0)
    {
        _28085 = NOVALUE;
        goto L6; // [186] 201
    }
    else{
        _28085 = NOVALUE;
    }

    /** 		Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_35symbol_resolution_warning_16069);
    RefDS(_21815);
    _44Warning(_35symbol_resolution_warning_16069, 1, _21815);
L6: 
L2: 

    /** end procedure*/
    DeRef(_errmsg_54757);
    DeRef(_rname_54758);
    DeRef(_fname_54759);
    _28080 = NOVALUE;
    return;
    ;
}


void _39WrongNumberArgs(int _subsym_54809, int _only_54810)
{
    int _msgno_54811 = NOVALUE;
    int _28097 = NOVALUE;
    int _28096 = NOVALUE;
    int _28095 = NOVALUE;
    int _28094 = NOVALUE;
    int _28093 = NOVALUE;
    int _28091 = NOVALUE;
    int _28089 = NOVALUE;
    int _28087 = NOVALUE;
    int _28086 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54809)) {
        _1 = (long)(DBL_PTR(_subsym_54809)->dbl);
        DeRefDS(_subsym_54809);
        _subsym_54809 = _1;
    }

    /** 	if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28086 = (int)*(((s1_ptr)_2)->base + _subsym_54809);
    _2 = (int)SEQ_PTR(_28086);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _28087 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _28087 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _28086 = NOVALUE;
    if (binary_op_a(NOTEQ, _28087, 1)){
        _28087 = NOVALUE;
        goto L1; // [19] 49
    }
    _28087 = NOVALUE;

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_54810)){
            _28089 = SEQ_PTR(_only_54810)->length;
    }
    else {
        _28089 = 1;
    }
    if (_28089 != 0)
    goto L2; // [28] 40

    /** 			msgno = 20*/
    _msgno_54811 = 20;
    goto L3; // [37] 73
L2: 

    /** 			msgno = 237*/
    _msgno_54811 = 237;
    goto L3; // [46] 73
L1: 

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_54810)){
            _28091 = SEQ_PTR(_only_54810)->length;
    }
    else {
        _28091 = 1;
    }
    if (_28091 != 0)
    goto L4; // [54] 66

    /** 			msgno = 236*/
    _msgno_54811 = 236;
    goto L5; // [63] 72
L4: 

    /** 			msgno = 238*/
    _msgno_54811 = 238;
L5: 
L3: 

    /** 	CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28093 = (int)*(((s1_ptr)_2)->base + _subsym_54809);
    _2 = (int)SEQ_PTR(_28093);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28094 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28094 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28093 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28095 = (int)*(((s1_ptr)_2)->base + _subsym_54809);
    _2 = (int)SEQ_PTR(_28095);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _28096 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _28096 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _28095 = NOVALUE;
    Ref(_28096);
    Ref(_28094);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28094;
    ((int *)_2)[2] = _28096;
    _28097 = MAKE_SEQ(_1);
    _28096 = NOVALUE;
    _28094 = NOVALUE;
    _44CompileErr(_msgno_54811, _28097, 0);
    _28097 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_only_54810);
    return;
    ;
}


void _39MissingArgs(int _subsym_54840)
{
    int _eentry_54841 = NOVALUE;
    int _28102 = NOVALUE;
    int _28101 = NOVALUE;
    int _28100 = NOVALUE;
    int _28099 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_54841);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _eentry_54841 = (int)*(((s1_ptr)_2)->base + _subsym_54840);
    Ref(_eentry_54841);

    /** 	CompileErr(235, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (int)SEQ_PTR(_eentry_54841);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28099 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28099 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _2 = (int)SEQ_PTR(_eentry_54841);
    _28100 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_28100);
    _28101 = (int)*(((s1_ptr)_2)->base + 2);
    _28100 = NOVALUE;
    Ref(_28101);
    Ref(_28099);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28099;
    ((int *)_2)[2] = _28101;
    _28102 = MAKE_SEQ(_1);
    _28101 = NOVALUE;
    _28099 = NOVALUE;
    _44CompileErr(235, _28102, 0);
    _28102 = NOVALUE;

    /** end procedure*/
    DeRefDS(_eentry_54841);
    return;
    ;
}


void _39Parse_default_arg(int _subsym_54854, int _arg_54855, int _fwd_private_list_54856, int _fwd_private_sym_54857)
{
    int _param_54859 = NOVALUE;
    int _28122 = NOVALUE;
    int _28121 = NOVALUE;
    int _28120 = NOVALUE;
    int _28119 = NOVALUE;
    int _28118 = NOVALUE;
    int _28117 = NOVALUE;
    int _28116 = NOVALUE;
    int _28115 = NOVALUE;
    int _28114 = NOVALUE;
    int _28113 = NOVALUE;
    int _28112 = NOVALUE;
    int _28111 = NOVALUE;
    int _28110 = NOVALUE;
    int _28108 = NOVALUE;
    int _28107 = NOVALUE;
    int _28104 = NOVALUE;
    int _28103 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54854)) {
        _1 = (long)(DBL_PTR(_subsym_54854)->dbl);
        DeRefDS(_subsym_54854);
        _subsym_54854 = _1;
    }
    if (!IS_ATOM_INT(_arg_54855)) {
        _1 = (long)(DBL_PTR(_arg_54855)->dbl);
        DeRefDS(_arg_54855);
        _arg_54855 = _1;
    }

    /** 	symtab_index param = subsym*/
    _param_54859 = _subsym_54854;

    /** 	on_arg = arg*/
    _39on_arg_54394 = _arg_54855;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_39private_list_54392)){
            _28103 = SEQ_PTR(_39private_list_54392)->length;
    }
    else {
        _28103 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28103;
    *((int *)(_2+8)) = _39lock_scanner_54393;
    *((int *)(_2+12)) = _35use_private_list_16081;
    *((int *)(_2+16)) = _39on_arg_54394;
    _28104 = MAKE_SEQ(_1);
    _28103 = NOVALUE;
    RefDS(_28104);
    Append(&_39parseargs_states_54387, _39parseargs_states_54387, _28104);
    DeRefDS(_28104);
    _28104 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_39nested_calls_54395, _39nested_calls_54395, _subsym_54854);

    /** 	for i = 1 to arg do*/
    _28107 = _arg_54855;
    {
        int _i_54866;
        _i_54866 = 1;
L1: 
        if (_i_54866 > _28107){
            goto L2; // [60] 90
        }

        /** 		param = SymTab[param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28108 = (int)*(((s1_ptr)_2)->base + _param_54859);
        _2 = (int)SEQ_PTR(_28108);
        _param_54859 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_54859)){
            _param_54859 = (long)DBL_PTR(_param_54859)->dbl;
        }
        _28108 = NOVALUE;

        /** 	end for*/
        _i_54866 = _i_54866 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** 	private_list = fwd_private_list*/
    RefDS(_fwd_private_list_54856);
    DeRef(_39private_list_54392);
    _39private_list_54392 = _fwd_private_list_54856;

    /** 	private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_54857);
    DeRef(_35private_sym_16080);
    _35private_sym_16080 = _fwd_private_sym_54857;

    /** 	if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28110 = (int)*(((s1_ptr)_2)->base + _param_54859);
    _2 = (int)SEQ_PTR(_28110);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _28111 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _28111 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _28110 = NOVALUE;
    _28112 = IS_ATOM(_28111);
    _28111 = NOVALUE;
    if (_28112 == 0)
    {
        _28112 = NOVALUE;
        goto L3; // [121] 162
    }
    else{
        _28112 = NOVALUE;
    }

    /** 		CompileErr(26, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28113 = (int)*(((s1_ptr)_2)->base + _subsym_54854);
    _2 = (int)SEQ_PTR(_28113);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28114 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28114 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28113 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28115 = (int)*(((s1_ptr)_2)->base + _param_54859);
    _2 = (int)SEQ_PTR(_28115);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28116 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28116 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28115 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _arg_54855;
    Ref(_28114);
    *((int *)(_2+8)) = _28114;
    Ref(_28116);
    *((int *)(_2+12)) = _28116;
    _28117 = MAKE_SEQ(_1);
    _28116 = NOVALUE;
    _28114 = NOVALUE;
    _44CompileErr(26, _28117, 0);
    _28117 = NOVALUE;
L3: 

    /** 	use_private_list = 1*/
    _35use_private_list_16081 = 1;

    /** 	lock_scanner = 1*/
    _39lock_scanner_54393 = 1;

    /** 	start_playback(SymTab[param][S_CODE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28118 = (int)*(((s1_ptr)_2)->base + _param_54859);
    _2 = (int)SEQ_PTR(_28118);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _28119 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _28119 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _28118 = NOVALUE;
    Ref(_28119);
    _39start_playback(_28119);
    _28119 = NOVALUE;

    /** 	call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_54681].addr;
    (*(int (*)())_0)(
                         );

    /** 	add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28120 = _41Top();
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28121 = (int)*(((s1_ptr)_2)->base + _param_54859);
    _2 = (int)SEQ_PTR(_28121);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28122 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28122 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28121 = NOVALUE;
    Ref(_28122);
    _38add_private_symbol(_28120, _28122);
    _28120 = NOVALUE;
    _28122 = NOVALUE;

    /** 	lock_scanner = 0*/
    _39lock_scanner_54393 = 0;

    /** 	restore_parseargs_states()*/
    _39restore_parseargs_states();

    /** end procedure*/
    DeRefDS(_fwd_private_list_54856);
    DeRefDS(_fwd_private_sym_54857);
    return;
    ;
}


void _39ParseArgs(int _subsym_54904)
{
    int _n_54905 = NOVALUE;
    int _fda_54906 = NOVALUE;
    int _lnda_54907 = NOVALUE;
    int _tok_54909 = NOVALUE;
    int _s_54911 = NOVALUE;
    int _var_code_54912 = NOVALUE;
    int _name_54913 = NOVALUE;
    int _28216 = NOVALUE;
    int _28214 = NOVALUE;
    int _28210 = NOVALUE;
    int _28209 = NOVALUE;
    int _28208 = NOVALUE;
    int _28205 = NOVALUE;
    int _28202 = NOVALUE;
    int _28200 = NOVALUE;
    int _28198 = NOVALUE;
    int _28196 = NOVALUE;
    int _28194 = NOVALUE;
    int _28193 = NOVALUE;
    int _28192 = NOVALUE;
    int _28191 = NOVALUE;
    int _28190 = NOVALUE;
    int _28189 = NOVALUE;
    int _28188 = NOVALUE;
    int _28182 = NOVALUE;
    int _28180 = NOVALUE;
    int _28177 = NOVALUE;
    int _28174 = NOVALUE;
    int _28169 = NOVALUE;
    int _28167 = NOVALUE;
    int _28166 = NOVALUE;
    int _28165 = NOVALUE;
    int _28163 = NOVALUE;
    int _28160 = NOVALUE;
    int _28157 = NOVALUE;
    int _28155 = NOVALUE;
    int _28153 = NOVALUE;
    int _28151 = NOVALUE;
    int _28149 = NOVALUE;
    int _28148 = NOVALUE;
    int _28147 = NOVALUE;
    int _28146 = NOVALUE;
    int _28145 = NOVALUE;
    int _28144 = NOVALUE;
    int _28143 = NOVALUE;
    int _28141 = NOVALUE;
    int _28139 = NOVALUE;
    int _28135 = NOVALUE;
    int _28134 = NOVALUE;
    int _28132 = NOVALUE;
    int _28131 = NOVALUE;
    int _28129 = NOVALUE;
    int _28128 = NOVALUE;
    int _28127 = NOVALUE;
    int _28126 = NOVALUE;
    int _28125 = NOVALUE;
    int _28123 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54904)) {
        _1 = (long)(DBL_PTR(_subsym_54904)->dbl);
        DeRefDS(_subsym_54904);
        _subsym_54904 = _1;
    }

    /** 	object var_code*/

    /** 	sequence name*/

    /** 	n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28123 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
    _2 = (int)SEQ_PTR(_28123);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _n_54905 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _n_54905 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    if (!IS_ATOM_INT(_n_54905)){
        _n_54905 = (long)DBL_PTR(_n_54905)->dbl;
    }
    _28123 = NOVALUE;

    /** 	if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28125 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
    _2 = (int)SEQ_PTR(_28125);
    _28126 = (int)*(((s1_ptr)_2)->base + 28);
    _28125 = NOVALUE;
    _28127 = IS_SEQUENCE(_28126);
    _28126 = NOVALUE;
    if (_28127 == 0)
    {
        _28127 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28127 = NOVALUE;
    }

    /** 		fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28128 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
    _2 = (int)SEQ_PTR(_28128);
    _28129 = (int)*(((s1_ptr)_2)->base + 28);
    _28128 = NOVALUE;
    _2 = (int)SEQ_PTR(_28129);
    _fda_54906 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_54906)){
        _fda_54906 = (long)DBL_PTR(_fda_54906)->dbl;
    }
    _28129 = NOVALUE;

    /** 		lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28131 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
    _2 = (int)SEQ_PTR(_28131);
    _28132 = (int)*(((s1_ptr)_2)->base + 28);
    _28131 = NOVALUE;
    _2 = (int)SEQ_PTR(_28132);
    _lnda_54907 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_54907)){
        _lnda_54907 = (long)DBL_PTR(_lnda_54907)->dbl;
    }
    _28132 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** 		fda = 0*/
    _fda_54906 = 0;

    /** 		lnda = 0*/
    _lnda_54907 = 0;
L2: 

    /** 	s = subsym*/
    _s_54911 = _subsym_54904;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_39private_list_54392)){
            _28134 = SEQ_PTR(_39private_list_54392)->length;
    }
    else {
        _28134 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28134;
    *((int *)(_2+8)) = _39lock_scanner_54393;
    *((int *)(_2+12)) = _35use_private_list_16081;
    *((int *)(_2+16)) = _39on_arg_54394;
    _28135 = MAKE_SEQ(_1);
    _28134 = NOVALUE;
    RefDS(_28135);
    Append(&_39parseargs_states_54387, _39parseargs_states_54387, _28135);
    DeRefDS(_28135);
    _28135 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_39nested_calls_54395, _39nested_calls_54395, _subsym_54904);

    /** 	lock_scanner = 0*/
    _39lock_scanner_54393 = 0;

    /** 	on_arg = 0*/
    _39on_arg_54394 = 0;

    /** 	short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 	for i = 1 to n do*/
    _28139 = _n_54905;
    {
        int _i_54942;
        _i_54942 = 1;
L3: 
        if (_i_54942 > _28139){
            goto L4; // [161] 915
        }

        /** 	  	tok = next_token()*/
        _0 = _tok_54909;
        _tok_54909 = _39next_token();
        DeRef(_0);

        /** 		if tok[T_ID] = COMMA then*/
        _2 = (int)SEQ_PTR(_tok_54909);
        _28141 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28141, -30)){
            _28141 = NOVALUE;
            goto L5; // [183] 392
        }
        _28141 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28143 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28143);
        _28144 = (int)*(((s1_ptr)_2)->base + 21);
        _28143 = NOVALUE;
        if (_28144 == 0) {
            _28144 = NOVALUE;
            goto L6; // [201] 261
        }
        else {
            if (!IS_ATOM_INT(_28144) && DBL_PTR(_28144)->dbl == 0.0){
                _28144 = NOVALUE;
                goto L6; // [201] 261
            }
            _28144 = NOVALUE;
        }
        _28144 = NOVALUE;

        /** 				if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28145 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28145);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _28146 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _28146 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        _28145 = NOVALUE;
        _28147 = IS_ATOM(_28146);
        _28146 = NOVALUE;
        if (_28147 == 0)
        {
            _28147 = NOVALUE;
            goto L7; // [221] 232
        }
        else{
            _28147 = NOVALUE;
        }

        /** 					var_code = 0*/
        DeRef(_var_code_54912);
        _var_code_54912 = 0;
        goto L8; // [229] 251
L7: 

        /** 					var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28148 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28148);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _28149 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _28149 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        _28148 = NOVALUE;
        DeRef(_var_code_54912);
        _2 = (int)SEQ_PTR(_28149);
        _var_code_54912 = (int)*(((s1_ptr)_2)->base + _i_54942);
        Ref(_var_code_54912);
        _28149 = NOVALUE;
L8: 

        /** 				name = ""*/
        RefDS(_21815);
        DeRef(_name_54913);
        _name_54913 = _21815;
        goto L9; // [258] 308
L6: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28151 = (int)*(((s1_ptr)_2)->base + _s_54911);
        _2 = (int)SEQ_PTR(_28151);
        _s_54911 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54911)){
            _s_54911 = (long)DBL_PTR(_s_54911)->dbl;
        }
        _28151 = NOVALUE;

        /** 				var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28153 = (int)*(((s1_ptr)_2)->base + _s_54911);
        DeRef(_var_code_54912);
        _2 = (int)SEQ_PTR(_28153);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _var_code_54912 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _var_code_54912 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        Ref(_var_code_54912);
        _28153 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28155 = (int)*(((s1_ptr)_2)->base + _s_54911);
        DeRef(_name_54913);
        _2 = (int)SEQ_PTR(_28155);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _name_54913 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _name_54913 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        Ref(_name_54913);
        _28155 = NOVALUE;
L9: 

        /** 			if atom(var_code) then  -- but no default set*/
        _28157 = IS_ATOM(_var_code_54912);
        if (_28157 == 0)
        {
            _28157 = NOVALUE;
            goto LA; // [315] 326
        }
        else{
            _28157 = NOVALUE;
        }

        /** 				CompileErr(29,i)*/
        _44CompileErr(29, _i_54942, 0);
LA: 

        /** 			use_private_list = 1*/
        _35use_private_list_16081 = 1;

        /** 			start_playback(var_code)*/
        Ref(_var_code_54912);
        _39start_playback(_var_code_54912);

        /** 			lock_scanner=1*/
        _39lock_scanner_54393 = 1;

        /** 			Expr()*/
        _39Expr();

        /** 			lock_scanner=0*/
        _39lock_scanner_54393 = 0;

        /** 			on_arg += 1*/
        _39on_arg_54394 = _39on_arg_54394 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_54913);
        Append(&_39private_list_54392, _39private_list_54392, _name_54913);

        /** 			private_sym &= Top()*/
        _28160 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16080) && IS_ATOM(_28160)) {
            Ref(_28160);
            Append(&_35private_sym_16080, _35private_sym_16080, _28160);
        }
        else if (IS_ATOM(_35private_sym_16080) && IS_SEQUENCE(_28160)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16080, _35private_sym_16080, _28160);
        }
        DeRef(_28160);
        _28160 = NOVALUE;

        /** 			backed_up_tok = {tok} -- ????*/
        _0 = _39backed_up_tok_53676;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_tok_54909);
        *((int *)(_2+4)) = _tok_54909;
        _39backed_up_tok_53676 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LB; // [389] 520
L5: 

        /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54909);
        _28163 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28163, -27)){
            _28163 = NOVALUE;
            goto LC; // [402] 519
        }
        _28163 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28165 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28165);
        _28166 = (int)*(((s1_ptr)_2)->base + 21);
        _28165 = NOVALUE;
        if (_28166 == 0) {
            _28166 = NOVALUE;
            goto LD; // [420] 433
        }
        else {
            if (!IS_ATOM_INT(_28166) && DBL_PTR(_28166)->dbl == 0.0){
                _28166 = NOVALUE;
                goto LD; // [420] 433
            }
            _28166 = NOVALUE;
        }
        _28166 = NOVALUE;

        /** 				name = ""*/
        RefDS(_21815);
        DeRef(_name_54913);
        _name_54913 = _21815;
        goto LE; // [430] 466
LD: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28167 = (int)*(((s1_ptr)_2)->base + _s_54911);
        _2 = (int)SEQ_PTR(_28167);
        _s_54911 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54911)){
            _s_54911 = (long)DBL_PTR(_s_54911)->dbl;
        }
        _28167 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28169 = (int)*(((s1_ptr)_2)->base + _s_54911);
        DeRef(_name_54913);
        _2 = (int)SEQ_PTR(_28169);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _name_54913 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _name_54913 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        Ref(_name_54913);
        _28169 = NOVALUE;
LE: 

        /** 			use_private_list = Parser_mode != PAM_NORMAL*/
        _35use_private_list_16081 = (_35Parser_mode_16073 != 0);

        /** 			putback(tok)*/
        Ref(_tok_54909);
        _39putback(_tok_54909);

        /** 			Expr()*/
        _39Expr();

        /** 			on_arg += 1*/
        _39on_arg_54394 = _39on_arg_54394 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_54913);
        Append(&_39private_list_54392, _39private_list_54392, _name_54913);

        /** 			private_sym &= Top()*/
        _28174 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16080) && IS_ATOM(_28174)) {
            Ref(_28174);
            Append(&_35private_sym_16080, _35private_sym_16080, _28174);
        }
        else if (IS_ATOM(_35private_sym_16080) && IS_SEQUENCE(_28174)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16080, _35private_sym_16080, _28174);
        }
        DeRef(_28174);
        _28174 = NOVALUE;
LC: 
LB: 

        /** 		if on_arg != n then*/
        if (_39on_arg_54394 == _n_54905)
        goto LF; // [524] 908

        /** 			if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54909);
        _28177 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28177, -27)){
            _28177 = NOVALUE;
            goto L10; // [538] 548
        }
        _28177 = NOVALUE;

        /** 				putback( tok )*/
        Ref(_tok_54909);
        _39putback(_tok_54909);
L10: 

        /** 			tok = next_token()*/
        _0 = _tok_54909;
        _tok_54909 = _39next_token();
        DeRef(_0);

        /** 			if tok[T_ID] != COMMA then*/
        _2 = (int)SEQ_PTR(_tok_54909);
        _28180 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28180, -30)){
            _28180 = NOVALUE;
            goto L11; // [563] 907
        }
        _28180 = NOVALUE;

        /** 		  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54909);
        _28182 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28182, -27)){
            _28182 = NOVALUE;
            goto L12; // [577] 892
        }
        _28182 = NOVALUE;

        /** 					if fda=0 then*/
        if (_fda_54906 != 0)
        goto L13; // [585] 598

        /** 						WrongNumberArgs(subsym, "")*/
        RefDS(_21815);
        _39WrongNumberArgs(_subsym_54904, _21815);
        goto L14; // [595] 613
L13: 

        /** 					elsif i<lnda then*/
        if (_i_54942 >= _lnda_54907)
        goto L15; // [602] 612

        /** 						MissingArgs(subsym)*/
        _39MissingArgs(_subsym_54904);
L15: 
L14: 

        /** 					lock_scanner = 1*/
        _39lock_scanner_54393 = 1;

        /** 					use_private_list = 1*/
        _35use_private_list_16081 = 1;

        /** 					while on_arg < n do*/
L16: 
        if (_39on_arg_54394 >= _n_54905)
        goto L17; // [632] 841

        /** 						on_arg += 1*/
        _39on_arg_54394 = _39on_arg_54394 + 1;

        /** 						if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28188 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28188);
        _28189 = (int)*(((s1_ptr)_2)->base + 21);
        _28188 = NOVALUE;
        if (_28189 == 0) {
            _28189 = NOVALUE;
            goto L18; // [658] 720
        }
        else {
            if (!IS_ATOM_INT(_28189) && DBL_PTR(_28189)->dbl == 0.0){
                _28189 = NOVALUE;
                goto L18; // [658] 720
            }
            _28189 = NOVALUE;
        }
        _28189 = NOVALUE;

        /** 							if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28190 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28190);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _28191 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _28191 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        _28190 = NOVALUE;
        _28192 = IS_ATOM(_28191);
        _28191 = NOVALUE;
        if (_28192 == 0)
        {
            _28192 = NOVALUE;
            goto L19; // [678] 689
        }
        else{
            _28192 = NOVALUE;
        }

        /** 								var_code = 0*/
        DeRef(_var_code_54912);
        _var_code_54912 = 0;
        goto L1A; // [686] 710
L19: 

        /** 								var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28193 = (int)*(((s1_ptr)_2)->base + _subsym_54904);
        _2 = (int)SEQ_PTR(_28193);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _28194 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _28194 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        _28193 = NOVALUE;
        DeRef(_var_code_54912);
        _2 = (int)SEQ_PTR(_28194);
        _var_code_54912 = (int)*(((s1_ptr)_2)->base + _39on_arg_54394);
        Ref(_var_code_54912);
        _28194 = NOVALUE;
L1A: 

        /** 							name = ""*/
        RefDS(_21815);
        DeRef(_name_54913);
        _name_54913 = _21815;
        goto L1B; // [717] 767
L18: 

        /** 							s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28196 = (int)*(((s1_ptr)_2)->base + _s_54911);
        _2 = (int)SEQ_PTR(_28196);
        _s_54911 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54911)){
            _s_54911 = (long)DBL_PTR(_s_54911)->dbl;
        }
        _28196 = NOVALUE;

        /** 							var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28198 = (int)*(((s1_ptr)_2)->base + _s_54911);
        DeRef(_var_code_54912);
        _2 = (int)SEQ_PTR(_28198);
        if (!IS_ATOM_INT(_35S_CODE_15653)){
            _var_code_54912 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
        }
        else{
            _var_code_54912 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
        }
        Ref(_var_code_54912);
        _28198 = NOVALUE;

        /** 							name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28200 = (int)*(((s1_ptr)_2)->base + _s_54911);
        DeRef(_name_54913);
        _2 = (int)SEQ_PTR(_28200);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _name_54913 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _name_54913 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        Ref(_name_54913);
        _28200 = NOVALUE;
L1B: 

        /** 						if sequence(var_code) then*/
        _28202 = IS_SEQUENCE(_var_code_54912);
        if (_28202 == 0)
        {
            _28202 = NOVALUE;
            goto L1C; // [774] 826
        }
        else{
            _28202 = NOVALUE;
        }

        /** 							putback( tok )*/
        Ref(_tok_54909);
        _39putback(_tok_54909);

        /** 							start_playback(var_code)*/
        Ref(_var_code_54912);
        _39start_playback(_var_code_54912);

        /** 							Expr()*/
        _39Expr();

        /** 							if on_arg < n then*/
        if (_39on_arg_54394 >= _n_54905)
        goto L16; // [795] 630

        /** 								private_list = append(private_list,name)*/
        RefDS(_name_54913);
        Append(&_39private_list_54392, _39private_list_54392, _name_54913);

        /** 								private_sym &= Top()*/
        _28205 = _41Top();
        if (IS_SEQUENCE(_35private_sym_16080) && IS_ATOM(_28205)) {
            Ref(_28205);
            Append(&_35private_sym_16080, _35private_sym_16080, _28205);
        }
        else if (IS_ATOM(_35private_sym_16080) && IS_SEQUENCE(_28205)) {
        }
        else {
            Concat((object_ptr)&_35private_sym_16080, _35private_sym_16080, _28205);
        }
        DeRef(_28205);
        _28205 = NOVALUE;
        goto L16; // [823] 630
L1C: 

        /** 							CompileErr(29, on_arg)*/
        _44CompileErr(29, _39on_arg_54394, 0);

        /** 		  		    end while*/
        goto L16; // [838] 630
L17: 

        /** 					short_circuit += 1*/
        _39short_circuit_53669 = _39short_circuit_53669 + 1;

        /** 					if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_39backed_up_tok_53676)){
                _28208 = SEQ_PTR(_39backed_up_tok_53676)->length;
        }
        else {
            _28208 = 1;
        }
        _2 = (int)SEQ_PTR(_39backed_up_tok_53676);
        _28209 = (int)*(((s1_ptr)_2)->base + _28208);
        _2 = (int)SEQ_PTR(_28209);
        _28210 = (int)*(((s1_ptr)_2)->base + 1);
        _28209 = NOVALUE;
        if (binary_op_a(NOTEQ, _28210, 505)){
            _28210 = NOVALUE;
            goto L1D; // [868] 880
        }
        _28210 = NOVALUE;

        /** 						backed_up_tok = {}*/
        RefDS(_21815);
        DeRefDS(_39backed_up_tok_53676);
        _39backed_up_tok_53676 = _21815;
L1D: 

        /** 					restore_parseargs_states()*/
        _39restore_parseargs_states();

        /** 					return*/
        DeRef(_tok_54909);
        DeRef(_var_code_54912);
        DeRef(_name_54913);
        return;
        goto L1E; // [889] 906
L12: 

        /** 					putback(tok)*/
        Ref(_tok_54909);
        _39putback(_tok_54909);

        /** 					tok_match(COMMA)*/
        _39tok_match(-30, 0);
L1E: 
L11: 
LF: 

        /** 	end for*/
        _i_54942 = _i_54942 + 1;
        goto L3; // [910] 168
L4: 
        ;
    }

    /** 	tok = next_token()*/
    _0 = _tok_54909;
    _tok_54909 = _39next_token();
    DeRef(_0);

    /** 	short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** 	if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_54909);
    _28214 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28214, -27)){
        _28214 = NOVALUE;
        goto L1F; // [938] 980
    }
    _28214 = NOVALUE;

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_54909);
    _28216 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28216, -30)){
        _28216 = NOVALUE;
        goto L20; // [952] 965
    }
    _28216 = NOVALUE;

    /** 			WrongNumberArgs(subsym, "only ")*/
    RefDS(_28218);
    _39WrongNumberArgs(_subsym_54904, _28218);
    goto L21; // [962] 979
L20: 

    /** 			putback(tok)*/
    Ref(_tok_54909);
    _39putback(_tok_54909);

    /** 			tok_match(RIGHT_ROUND)*/
    _39tok_match(-27, 0);
L21: 
L1F: 

    /** 	restore_parseargs_states()*/
    _39restore_parseargs_states();

    /** end procedure*/
    DeRef(_tok_54909);
    DeRef(_var_code_54912);
    DeRef(_name_54913);
    return;
    ;
}


void _39Forward_var(int _tok_55118, int _init_check_55119, int _op_55120)
{
    int _ref_55124 = NOVALUE;
    int _28222 = NOVALUE;
    int _28220 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_55120)) {
        _1 = (long)(DBL_PTR(_op_55120)->dbl);
        DeRefDS(_op_55120);
        _op_55120 = _1;
    }

    /** 	ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (int)SEQ_PTR(_tok_55118);
    _28220 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28220);
    _ref_55124 = _38new_forward_reference(-100, _28220, _op_55120);
    _28220 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55124)) {
        _1 = (long)(DBL_PTR(_ref_55124)->dbl);
        DeRefDS(_ref_55124);
        _ref_55124 = _1;
    }

    /** 	emit_opnd( - ref )*/
    if ((unsigned long)_ref_55124 == 0xC0000000)
    _28222 = (int)NewDouble((double)-0xC0000000);
    else
    _28222 = - _ref_55124;
    _41emit_opnd(_28222);
    _28222 = NOVALUE;

    /** 	if init_check != -1 then*/
    if (_init_check_55119 == -1)
    goto L1; // [33] 44

    /** 		Forward_InitCheck( tok, init_check )*/
    Ref(_tok_55118);
    _39Forward_InitCheck(_tok_55118, _init_check_55119);
L1: 

    /** end procedure*/
    DeRef(_tok_55118);
    return;
    ;
}


void _39Forward_call(int _tok_55137, int _opcode_55138)
{
    int _args_55141 = NOVALUE;
    int _proc_55143 = NOVALUE;
    int _tok_id_55146 = NOVALUE;
    int _id_55153 = NOVALUE;
    int _fc_pc_55176 = NOVALUE;
    int _28241 = NOVALUE;
    int _28240 = NOVALUE;
    int _28237 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer args = 0*/
    _args_55141 = 0;

    /** 	symtab_index proc = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55137);
    _proc_55143 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_55143)){
        _proc_55143 = (long)DBL_PTR(_proc_55143)->dbl;
    }

    /** 	integer tok_id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55137);
    _tok_id_55146 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_55146)){
        _tok_id_55146 = (long)DBL_PTR(_tok_id_55146)->dbl;
    }

    /** 	remove_symbol( proc )*/
    _53remove_symbol(_proc_55143);

    /** 	short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 	while 1 do*/
L1: 

    /** 		tok = next_token()*/
    _0 = _tok_55137;
    _tok_55137 = _39next_token();
    DeRef(_0);

    /** 		integer id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55137);
    _id_55153 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55153)){
        _id_55153 = (long)DBL_PTR(_id_55153)->dbl;
    }

    /** 		switch id do*/
    _0 = _id_55153;
    switch ( _0 ){ 

        /** 			case COMMA then*/
        case -30:

        /** 				emit_opnd( 0 ) -- clean this up later*/
        _41emit_opnd(0);

        /** 				args += 1*/
        _args_55141 = _args_55141 + 1;
        goto L2; // [83] 166

        /** 			case RIGHT_ROUND then*/
        case -27:

        /** 				exit*/
        goto L3; // [93] 173
        goto L2; // [95] 166

        /** 			case else*/
        default:

        /** 				putback( tok )*/
        Ref(_tok_55137);
        _39putback(_tok_55137);

        /** 				call_proc( forward_expr, {} )*/
        _0 = (int)_00[_39forward_expr_54681].addr;
        (*(int (*)())_0)(
                             );

        /** 				args += 1*/
        _args_55141 = _args_55141 + 1;

        /** 				tok = next_token()*/
        _0 = _tok_55137;
        _tok_55137 = _39next_token();
        DeRef(_0);

        /** 				id = tok[T_ID]*/
        _2 = (int)SEQ_PTR(_tok_55137);
        _id_55153 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_55153)){
            _id_55153 = (long)DBL_PTR(_id_55153)->dbl;
        }

        /** 				if id = RIGHT_ROUND then*/
        if (_id_55153 != -27)
        goto L4; // [138] 149

        /** 					exit*/
        goto L3; // [146] 173
L4: 

        /** 				if id != COMMA then*/
        if (_id_55153 == -30)
        goto L5; // [153] 165

        /** 						CompileErr(69)*/
        RefDS(_21815);
        _44CompileErr(69, _21815, 0);
L5: 
    ;}L2: 

    /** 	end while*/
    goto L1; // [170] 46
L3: 

    /** 	integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28237 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28237 = 1;
    }
    _fc_pc_55176 = _28237 + 1;
    _28237 = NOVALUE;

    /** 	emit_opnd( args )*/
    _41emit_opnd(_args_55141);

    /** 	op_info1 = proc*/
    _41op_info1_49774 = _proc_55143;

    /** 	if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_55146 != 512)
    goto L6; // [200] 224

    /** 		set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28240 = (int)*(((s1_ptr)_2)->base + _proc_55143);
    _2 = (int)SEQ_PTR(_28240);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _28241 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _28241 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _28240 = NOVALUE;
    Ref(_28241);
    _61set_qualified_fwd(_28241);
    _28241 = NOVALUE;
    goto L7; // [221] 230
L6: 

    /** 		set_qualified_fwd( -1 )*/
    _61set_qualified_fwd(-1);
L7: 

    /** 	emit_op( opcode )*/
    _41emit_op(_opcode_55138);

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L8; // [239] 258

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L9; // [246] 257
    }
    else{
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
L9: 
L8: 

    /** 	short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** end procedure*/
    DeRef(_tok_55137);
    return;
    ;
}


void _39Object_call(int _tok_55204)
{
    int _tok2_55206 = NOVALUE;
    int _tok3_55207 = NOVALUE;
    int _save_factors_55208 = NOVALUE;
    int _save_lhs_subs_level_55209 = NOVALUE;
    int _sym_55211 = NOVALUE;
    int _28301 = NOVALUE;
    int _28299 = NOVALUE;
    int _28298 = NOVALUE;
    int _28295 = NOVALUE;
    int _28294 = NOVALUE;
    int _28290 = NOVALUE;
    int _28284 = NOVALUE;
    int _28281 = NOVALUE;
    int _28280 = NOVALUE;
    int _28279 = NOVALUE;
    int _28277 = NOVALUE;
    int _28276 = NOVALUE;
    int _28274 = NOVALUE;
    int _28273 = NOVALUE;
    int _28270 = NOVALUE;
    int _28269 = NOVALUE;
    int _28268 = NOVALUE;
    int _28266 = NOVALUE;
    int _28265 = NOVALUE;
    int _28263 = NOVALUE;
    int _28262 = NOVALUE;
    int _28261 = NOVALUE;
    int _28260 = NOVALUE;
    int _28258 = NOVALUE;
    int _28257 = NOVALUE;
    int _28255 = NOVALUE;
    int _28254 = NOVALUE;
    int _28251 = NOVALUE;
    int _28249 = NOVALUE;
    int _28248 = NOVALUE;
    int _28246 = NOVALUE;
    int _28245 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	tok2 = next_token()*/
    _0 = _tok2_55206;
    _tok2_55206 = _39next_token();
    DeRef(_0);

    /** 	if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28245 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28245)) {
        _28246 = (_28245 == -100);
    }
    else {
        _28246 = binary_op(EQUALS, _28245, -100);
    }
    _28245 = NOVALUE;
    if (IS_ATOM_INT(_28246)) {
        if (_28246 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28246)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28248 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28248)) {
        _28249 = (_28248 == 512);
    }
    else {
        _28249 = binary_op(EQUALS, _28248, 512);
    }
    _28248 = NOVALUE;
    if (_28249 == 0) {
        DeRef(_28249);
        _28249 = NOVALUE;
        goto L2; // [39] 586
    }
    else {
        if (!IS_ATOM_INT(_28249) && DBL_PTR(_28249)->dbl == 0.0){
            DeRef(_28249);
            _28249 = NOVALUE;
            goto L2; // [39] 586
        }
        DeRef(_28249);
        _28249 = NOVALUE;
    }
    DeRef(_28249);
    _28249 = NOVALUE;
L1: 

    /** 		tok3 = next_token()*/
    _0 = _tok3_55207;
    _tok3_55207 = _39next_token();
    DeRef(_0);

    /** 		if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55207);
    _28251 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28251, -27)){
        _28251 = NOVALUE;
        goto L3; // [58] 155
    }
    _28251 = NOVALUE;

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _sym_55211 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55211)){
        _sym_55211 = (long)DBL_PTR(_sym_55211)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28254 = (int)*(((s1_ptr)_2)->base + _sym_55211);
    _2 = (int)SEQ_PTR(_28254);
    _28255 = (int)*(((s1_ptr)_2)->base + 4);
    _28254 = NOVALUE;
    if (binary_op_a(NOTEQ, _28255, 9)){
        _28255 = NOVALUE;
        goto L4; // [88] 108
    }
    _28255 = NOVALUE;

    /** 				Forward_var( tok2 )*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28257 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55206);
    Ref(_28257);
    _39Forward_var(_tok2_55206, -1, _28257);
    _28257 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55211 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28260 = (int)*(((s1_ptr)_2)->base + _sym_55211);
    _2 = (int)SEQ_PTR(_28260);
    _28261 = (int)*(((s1_ptr)_2)->base + 5);
    _28260 = NOVALUE;
    if (IS_ATOM_INT(_28261)) {
        {unsigned long tu;
             tu = (unsigned long)_28261 | (unsigned long)1;
             _28262 = MAKE_UINT(tu);
        }
    }
    else {
        _28262 = binary_op(OR_BITS, _28261, 1);
    }
    _28261 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28262;
    if( _1 != _28262 ){
        DeRef(_1);
    }
    _28262 = NOVALUE;
    _28258 = NOVALUE;

    /** 				emit_opnd(sym)*/
    _41emit_opnd(_sym_55211);
L5: 

    /** 			putback( tok3 )*/
    Ref(_tok3_55207);
    _39putback(_tok3_55207);
    goto L6; // [152] 575
L3: 

    /** 		elsif tok3[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok3_55207);
    _28263 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28263, -30)){
        _28263 = NOVALUE;
        goto L7; // [165] 184
    }
    _28263 = NOVALUE;

    /** 			WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (int)SEQ_PTR(_tok_55204);
    _28265 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28265);
    RefDS(_21815);
    _39WrongNumberArgs(_28265, _21815);
    _28265 = NOVALUE;
    goto L6; // [181] 575
L7: 

    /** 		elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55207);
    _28266 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28266, -26)){
        _28266 = NOVALUE;
        goto L8; // [194] 244
    }
    _28266 = NOVALUE;

    /** 			if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28268 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28268)){
        _28269 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28268)->dbl));
    }
    else{
        _28269 = (int)*(((s1_ptr)_2)->base + _28268);
    }
    _2 = (int)SEQ_PTR(_28269);
    _28270 = (int)*(((s1_ptr)_2)->base + 4);
    _28269 = NOVALUE;
    if (binary_op_a(NOTEQ, _28270, 9)){
        _28270 = NOVALUE;
        goto L9; // [220] 235
    }
    _28270 = NOVALUE;

    /** 				Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_55206);
    _39Forward_call(_tok2_55206, 196);
    goto L6; // [232] 575
L9: 

    /** 				Function_call( tok2 )*/
    Ref(_tok2_55206);
    _39Function_call(_tok2_55206);
    goto L6; // [241] 575
L8: 

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _sym_55211 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55211)){
        _sym_55211 = (long)DBL_PTR(_sym_55211)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28273 = (int)*(((s1_ptr)_2)->base + _sym_55211);
    _2 = (int)SEQ_PTR(_28273);
    _28274 = (int)*(((s1_ptr)_2)->base + 4);
    _28273 = NOVALUE;
    if (binary_op_a(NOTEQ, _28274, 9)){
        _28274 = NOVALUE;
        goto LA; // [270] 292
    }
    _28274 = NOVALUE;

    /** 				Forward_var( tok2, TRUE )*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28276 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55206);
    Ref(_28276);
    _39Forward_var(_tok2_55206, _13TRUE_437, _28276);
    _28276 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55211 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28279 = (int)*(((s1_ptr)_2)->base + _sym_55211);
    _2 = (int)SEQ_PTR(_28279);
    _28280 = (int)*(((s1_ptr)_2)->base + 5);
    _28279 = NOVALUE;
    if (IS_ATOM_INT(_28280)) {
        {unsigned long tu;
             tu = (unsigned long)_28280 | (unsigned long)1;
             _28281 = MAKE_UINT(tu);
        }
    }
    else {
        _28281 = binary_op(OR_BITS, _28280, 1);
    }
    _28280 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28281;
    if( _1 != _28281 ){
        DeRef(_1);
    }
    _28281 = NOVALUE;
    _28277 = NOVALUE;

    /** 				InitCheck(sym, TRUE)*/
    _39InitCheck(_sym_55211, _13TRUE_437);

    /** 				emit_opnd(sym)*/
    _41emit_opnd(_sym_55211);
LB: 

    /** 			if sym = left_sym then*/
    if (_sym_55211 != _39left_sym_53710)
    goto LC; // [343] 353

    /** 				lhs_subs_level = 0*/
    _39lhs_subs_level_53708 = 0;
LC: 

    /** 			tok2 = tok3*/
    Ref(_tok3_55207);
    DeRef(_tok2_55206);
    _tok2_55206 = _tok3_55207;

    /** 			current_sequence = append(current_sequence, sym)*/
    Append(&_41current_sequence_49782, _41current_sequence_49782, _sym_55211);

    /** 			while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28284 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28284, -28)){
        _28284 = NOVALUE;
        goto LE; // [381] 551
    }
    _28284 = NOVALUE;

    /** 				subs_depth += 1*/
    _39subs_depth_53711 = _39subs_depth_53711 + 1;

    /** 				if lhs_subs_level >= 0 then*/
    if (_39lhs_subs_level_53708 < 0)
    goto LF; // [397] 410

    /** 					lhs_subs_level += 1*/
    _39lhs_subs_level_53708 = _39lhs_subs_level_53708 + 1;
LF: 

    /** 				save_factors = factors*/
    _save_factors_55208 = _39factors_53707;

    /** 				save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_55209 = _39lhs_subs_level_53708;

    /** 				call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_54681].addr;
    (*(int (*)())_0)(
                         );

    /** 				tok2 = next_token()*/
    _0 = _tok2_55206;
    _tok2_55206 = _39next_token();
    DeRef(_0);

    /** 				if tok2[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok2_55206);
    _28290 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28290, 513)){
        _28290 = NOVALUE;
        goto L10; // [446] 484
    }
    _28290 = NOVALUE;

    /** 					call_proc(forward_expr, {})*/
    _0 = (int)_00[_39forward_expr_54681].addr;
    (*(int (*)())_0)(
                         );

    /** 					emit_op(RHS_SLICE)*/
    _41emit_op(46);

    /** 					tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 					tok2 = next_token()*/
    _0 = _tok2_55206;
    _tok2_55206 = _39next_token();
    DeRef(_0);

    /** 					exit*/
    goto LE; // [479] 551
    goto L11; // [481] 531
L10: 

    /** 					putback(tok2)*/
    Ref(_tok2_55206);
    _39putback(_tok2_55206);

    /** 					tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 					subs_depth -= 1*/
    _39subs_depth_53711 = _39subs_depth_53711 - 1;

    /** 					current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_41current_sequence_49782)){
            _28294 = SEQ_PTR(_41current_sequence_49782)->length;
    }
    else {
        _28294 = 1;
    }
    _28295 = _28294 - 1;
    _28294 = NOVALUE;
    rhs_slice_target = (object_ptr)&_41current_sequence_49782;
    RHS_Slice(_41current_sequence_49782, 1, _28295);

    /** 					emit_op(RHS_SUBS)*/
    _41emit_op(25);
L11: 

    /** 				factors = save_factors*/
    _39factors_53707 = _save_factors_55208;

    /** 				lhs_subs_level = save_lhs_subs_level*/
    _39lhs_subs_level_53708 = _save_lhs_subs_level_55209;

    /** 				tok2 = next_token()*/
    _0 = _tok2_55206;
    _tok2_55206 = _39next_token();
    DeRef(_0);

    /** 			end while*/
    goto LD; // [548] 373
LE: 

    /** 			current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_41current_sequence_49782)){
            _28298 = SEQ_PTR(_41current_sequence_49782)->length;
    }
    else {
        _28298 = 1;
    }
    _28299 = _28298 - 1;
    _28298 = NOVALUE;
    rhs_slice_target = (object_ptr)&_41current_sequence_49782;
    RHS_Slice(_41current_sequence_49782, 1, _28299);

    /** 			putback(tok2)*/
    Ref(_tok2_55206);
    _39putback(_tok2_55206);
L6: 

    /** 		tok_match( RIGHT_ROUND )*/
    _39tok_match(-27, 0);
    goto L12; // [583] 603
L2: 

    /** 		putback(tok2)*/
    Ref(_tok2_55206);
    _39putback(_tok2_55206);

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55204);
    _28301 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28301);
    _39ParseArgs(_28301);
    _28301 = NOVALUE;
L12: 

    /** end procedure*/
    DeRef(_tok_55204);
    DeRef(_tok2_55206);
    DeRef(_tok3_55207);
    _28268 = NOVALUE;
    DeRef(_28246);
    _28246 = NOVALUE;
    DeRef(_28295);
    _28295 = NOVALUE;
    DeRef(_28299);
    _28299 = NOVALUE;
    return;
    ;
}


void _39Function_call(int _tok_55349)
{
    int _id_55350 = NOVALUE;
    int _scope_55351 = NOVALUE;
    int _opcode_55352 = NOVALUE;
    int _e_55353 = NOVALUE;
    int _28342 = NOVALUE;
    int _28341 = NOVALUE;
    int _28340 = NOVALUE;
    int _28339 = NOVALUE;
    int _28338 = NOVALUE;
    int _28337 = NOVALUE;
    int _28336 = NOVALUE;
    int _28334 = NOVALUE;
    int _28333 = NOVALUE;
    int _28331 = NOVALUE;
    int _28330 = NOVALUE;
    int _28329 = NOVALUE;
    int _28328 = NOVALUE;
    int _28327 = NOVALUE;
    int _28326 = NOVALUE;
    int _28325 = NOVALUE;
    int _28324 = NOVALUE;
    int _28323 = NOVALUE;
    int _28322 = NOVALUE;
    int _28321 = NOVALUE;
    int _28320 = NOVALUE;
    int _28319 = NOVALUE;
    int _28318 = NOVALUE;
    int _28317 = NOVALUE;
    int _28315 = NOVALUE;
    int _28313 = NOVALUE;
    int _28312 = NOVALUE;
    int _28310 = NOVALUE;
    int _28308 = NOVALUE;
    int _28307 = NOVALUE;
    int _28306 = NOVALUE;
    int _28305 = NOVALUE;
    int _28303 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _id_55350 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55350)){
        _id_55350 = (long)DBL_PTR(_id_55350)->dbl;
    }

    /** 	if id = FUNC or id = TYPE then*/
    _28303 = (_id_55350 == 501);
    if (_28303 != 0) {
        goto L1; // [19] 34
    }
    _28305 = (_id_55350 == 504);
    if (_28305 == 0)
    {
        DeRef(_28305);
        _28305 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28305);
        _28305 = NOVALUE;
    }
L1: 

    /** 		UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28306 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28306);
    _39UndefinedVar(_28306);
    _28306 = NOVALUE;
L2: 

    /** 	e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28307 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28307)){
        _28308 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28307)->dbl));
    }
    else{
        _28308 = (int)*(((s1_ptr)_2)->base + _28307);
    }
    _2 = (int)SEQ_PTR(_28308);
    _e_55353 = (int)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_55353)){
        _e_55353 = (long)DBL_PTR(_e_55353)->dbl;
    }
    _28308 = NOVALUE;

    /** 	if e then*/
    if (_e_55353 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** 		if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28310 = (_e_55353 == 1073741823);
    if (_28310 != 0) {
        goto L4; // [81] 102
    }
    _2 = (int)SEQ_PTR(_tok_55349);
    _28312 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28312)) {
        _28313 = (_28312 > _39left_sym_53710);
    }
    else {
        _28313 = binary_op(GREATER, _28312, _39left_sym_53710);
    }
    _28312 = NOVALUE;
    if (_28313 == 0) {
        DeRef(_28313);
        _28313 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28313) && DBL_PTR(_28313)->dbl == 0.0){
            DeRef(_28313);
            _28313 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28313);
        _28313 = NOVALUE;
    }
    DeRef(_28313);
    _28313 = NOVALUE;
L4: 

    /** 			side_effect_calls = or_bits(side_effect_calls, e)*/
    {unsigned long tu;
         tu = (unsigned long)_39side_effect_calls_53706 | (unsigned long)_e_55353;
         _39side_effect_calls_53706 = MAKE_UINT(tu);
    }
L5: 

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28317 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_28317);
    _28318 = (int)*(((s1_ptr)_2)->base + 23);
    _28317 = NOVALUE;
    if (IS_ATOM_INT(_28318)) {
        {unsigned long tu;
             tu = (unsigned long)_28318 | (unsigned long)_e_55353;
             _28319 = MAKE_UINT(tu);
        }
    }
    else {
        _28319 = binary_op(OR_BITS, _28318, _e_55353);
    }
    _28318 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28319;
    if( _1 != _28319 ){
        DeRef(_1);
    }
    _28319 = NOVALUE;
    _28315 = NOVALUE;

    /** 		if short_circuit > 0 and short_circuit_B and*/
    _28320 = (_39short_circuit_53669 > 0);
    if (_28320 == 0) {
        _28321 = 0;
        goto L6; // [154] 164
    }
    _28321 = (_39short_circuit_B_53671 != 0);
L6: 
    if (_28321 == 0) {
        goto L7; // [164] 228
    }
    _28323 = find_from(_id_55350, _37FUNC_TOKS_15606, 1);
    if (_28323 == 0)
    {
        _28323 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28323 = NOVALUE;
    }

    /** 			Warning(219, short_circuit_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _28324 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_28324);
    RefDS(_21815);
    _28325 = _17abbreviate_path(_28324, _21815);
    _28324 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_55349);
    _28326 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28326)){
        _28327 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28326)->dbl));
    }
    else{
        _28327 = (int)*(((s1_ptr)_2)->base + _28326);
    }
    _2 = (int)SEQ_PTR(_28327);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28328 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28328 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28327 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28325;
    *((int *)(_2+8)) = _35line_number_15969;
    Ref(_28328);
    *((int *)(_2+12)) = _28328;
    _28329 = MAKE_SEQ(_1);
    _28328 = NOVALUE;
    _28325 = NOVALUE;
    _44Warning(219, 2, _28329);
    _28329 = NOVALUE;
L7: 
L3: 

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28330 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28330)){
        _28331 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28330)->dbl));
    }
    else{
        _28331 = (int)*(((s1_ptr)_2)->base + _28330);
    }
    _2 = (int)SEQ_PTR(_28331);
    _scope_55351 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_55351)){
        _scope_55351 = (long)DBL_PTR(_scope_55351)->dbl;
    }
    _28331 = NOVALUE;

    /** 	opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28333 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28333)){
        _28334 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28333)->dbl));
    }
    else{
        _28334 = (int)*(((s1_ptr)_2)->base + _28333);
    }
    _2 = (int)SEQ_PTR(_28334);
    _opcode_55352 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_55352)){
        _opcode_55352 = (long)DBL_PTR(_opcode_55352)->dbl;
    }
    _28334 = NOVALUE;

    /** 	if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28336 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28336)){
        _28337 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28336)->dbl));
    }
    else{
        _28337 = (int)*(((s1_ptr)_2)->base + _28336);
    }
    _2 = (int)SEQ_PTR(_28337);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _28338 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _28338 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _28337 = NOVALUE;
    if (_28338 == _24424)
    _28339 = 1;
    else if (IS_ATOM_INT(_28338) && IS_ATOM_INT(_24424))
    _28339 = 0;
    else
    _28339 = (compare(_28338, _24424) == 0);
    _28338 = NOVALUE;
    if (_28339 == 0) {
        goto L8; // [305] 327
    }
    _28341 = (_scope_55351 == 7);
    if (_28341 == 0)
    {
        DeRef(_28341);
        _28341 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28341);
        _28341 = NOVALUE;
    }

    /** 		Object_call( tok )*/
    Ref(_tok_55349);
    _39Object_call(_tok_55349);
    goto L9; // [324] 339
L8: 

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _28342 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28342);
    _39ParseArgs(_28342);
    _28342 = NOVALUE;
L9: 

    /** 	if scope = SC_PREDEF then*/
    if (_scope_55351 != 7)
    goto LA; // [343] 355

    /** 		emit_op(opcode)*/
    _41emit_op(_opcode_55352);
    goto LB; // [352] 393
LA: 

    /** 		op_info1 = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55349);
    _41op_info1_49774 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_41op_info1_49774)){
        _41op_info1_49774 = (long)DBL_PTR(_41op_info1_49774)->dbl;
    }

    /** 		emit_or_inline()*/
    _67emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto LC; // [373] 392

    /** 			if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
LD: 
LC: 
LB: 

    /** end procedure*/
    DeRef(_tok_55349);
    DeRef(_28303);
    _28303 = NOVALUE;
    _28307 = NOVALUE;
    DeRef(_28310);
    _28310 = NOVALUE;
    DeRef(_28320);
    _28320 = NOVALUE;
    _28326 = NOVALUE;
    _28330 = NOVALUE;
    _28333 = NOVALUE;
    _28336 = NOVALUE;
    return;
    ;
}


void _39Factor()
{
    int _tok_55457 = NOVALUE;
    int _id_55458 = NOVALUE;
    int _n_55459 = NOVALUE;
    int _save_factors_55460 = NOVALUE;
    int _save_lhs_subs_level_55461 = NOVALUE;
    int _sym_55463 = NOVALUE;
    int _forward_55494 = NOVALUE;
    int _28404 = NOVALUE;
    int _28403 = NOVALUE;
    int _28402 = NOVALUE;
    int _28400 = NOVALUE;
    int _28399 = NOVALUE;
    int _28398 = NOVALUE;
    int _28397 = NOVALUE;
    int _28396 = NOVALUE;
    int _28394 = NOVALUE;
    int _28390 = NOVALUE;
    int _28389 = NOVALUE;
    int _28386 = NOVALUE;
    int _28385 = NOVALUE;
    int _28381 = NOVALUE;
    int _28375 = NOVALUE;
    int _28370 = NOVALUE;
    int _28369 = NOVALUE;
    int _28368 = NOVALUE;
    int _28366 = NOVALUE;
    int _28365 = NOVALUE;
    int _28363 = NOVALUE;
    int _28361 = NOVALUE;
    int _28360 = NOVALUE;
    int _28359 = NOVALUE;
    int _28357 = NOVALUE;
    int _28350 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer id, n*/

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	factors += 1*/
    _39factors_53707 = _39factors_53707 + 1;

    /** 	tok = next_token()*/
    _0 = _tok_55457;
    _tok_55457 = _39next_token();
    DeRef(_0);

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55457);
    _id_55458 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55458)){
        _id_55458 = (long)DBL_PTR(_id_55458)->dbl;
    }

    /** 	if id = RECORDED then*/
    if (_id_55458 != 508)
    goto L1; // [32] 59

    /** 		tok = read_recorded_token(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55457);
    _28350 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28350);
    _0 = _tok_55457;
    _tok_55457 = _39read_recorded_token(_28350);
    DeRef(_0);
    _28350 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55457);
    _id_55458 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55458)){
        _id_55458 = (long)DBL_PTR(_id_55458)->dbl;
    }
L1: 

    /** 	switch id label "factor" do*/
    _0 = _id_55458;
    switch ( _0 ){ 

        /** 		case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** 			sym = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _sym_55463 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_55463)){
            _sym_55463 = (long)DBL_PTR(_sym_55463)->dbl;
        }

        /** 			if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28357 = (_sym_55463 < 0);
        if (_28357 != 0) {
            goto L2; // [88] 115
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28359 = (int)*(((s1_ptr)_2)->base + _sym_55463);
        _2 = (int)SEQ_PTR(_28359);
        _28360 = (int)*(((s1_ptr)_2)->base + 4);
        _28359 = NOVALUE;
        if (IS_ATOM_INT(_28360)) {
            _28361 = (_28360 == 9);
        }
        else {
            _28361 = binary_op(EQUALS, _28360, 9);
        }
        _28360 = NOVALUE;
        if (_28361 == 0) {
            DeRef(_28361);
            _28361 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28361) && DBL_PTR(_28361)->dbl == 0.0){
                DeRef(_28361);
                _28361 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28361);
            _28361 = NOVALUE;
        }
        DeRef(_28361);
        _28361 = NOVALUE;
L2: 

        /** 				token forward = next_token()*/
        _0 = _forward_55494;
        _forward_55494 = _39next_token();
        DeRef(_0);

        /** 				if forward[T_ID] = LEFT_ROUND then*/
        _2 = (int)SEQ_PTR(_forward_55494);
        _28363 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28363, -26)){
            _28363 = NOVALUE;
            goto L4; // [130] 151
        }
        _28363 = NOVALUE;

        /** 					Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_55457);
        _39Forward_call(_tok_55457, 196);

        /** 					break "factor"*/
        DeRef(_forward_55494);
        _forward_55494 = NOVALUE;
        goto L5; // [146] 696
        goto L6; // [148] 172
L4: 

        /** 					putback( forward )*/
        Ref(_forward_55494);
        _39putback(_forward_55494);

        /** 					Forward_var( tok, TRUE )*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _28365 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_55457);
        Ref(_28365);
        _39Forward_var(_tok_55457, _13TRUE_437, _28365);
        _28365 = NOVALUE;
L6: 
        DeRef(_forward_55494);
        _forward_55494 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** 				UndefinedVar(sym)*/
        _39UndefinedVar(_sym_55463);

        /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_sym_55463 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28368 = (int)*(((s1_ptr)_2)->base + _sym_55463);
        _2 = (int)SEQ_PTR(_28368);
        _28369 = (int)*(((s1_ptr)_2)->base + 5);
        _28368 = NOVALUE;
        if (IS_ATOM_INT(_28369)) {
            {unsigned long tu;
                 tu = (unsigned long)_28369 | (unsigned long)1;
                 _28370 = MAKE_UINT(tu);
            }
        }
        else {
            _28370 = binary_op(OR_BITS, _28369, 1);
        }
        _28369 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _28370;
        if( _1 != _28370 ){
            DeRef(_1);
        }
        _28370 = NOVALUE;
        _28366 = NOVALUE;

        /** 				InitCheck(sym, TRUE)*/
        _39InitCheck(_sym_55463, _13TRUE_437);

        /** 				emit_opnd(sym)*/
        _41emit_opnd(_sym_55463);
L7: 

        /** 			if sym = left_sym then*/
        if (_sym_55463 != _39left_sym_53710)
        goto L8; // [233] 243

        /** 				lhs_subs_level = 0 -- start counting subscripts*/
        _39lhs_subs_level_53708 = 0;
L8: 

        /** 			short_circuit -= 1*/
        _39short_circuit_53669 = _39short_circuit_53669 - 1;

        /** 			tok = next_token()*/
        _0 = _tok_55457;
        _tok_55457 = _39next_token();
        DeRef(_0);

        /** 			current_sequence = append(current_sequence, sym)*/
        Append(&_41current_sequence_49782, _41current_sequence_49782, _sym_55463);

        /** 			while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (int)SEQ_PTR(_tok_55457);
        _28375 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28375, -28)){
            _28375 = NOVALUE;
            goto LA; // [279] 450
        }
        _28375 = NOVALUE;

        /** 				subs_depth += 1*/
        _39subs_depth_53711 = _39subs_depth_53711 + 1;

        /** 				if lhs_subs_level >= 0 then*/
        if (_39lhs_subs_level_53708 < 0)
        goto LB; // [295] 308

        /** 					lhs_subs_level += 1*/
        _39lhs_subs_level_53708 = _39lhs_subs_level_53708 + 1;
LB: 

        /** 				save_factors = factors*/
        _save_factors_55460 = _39factors_53707;

        /** 				save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_55461 = _39lhs_subs_level_53708;

        /** 				call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_54681].addr;
        (*(int (*)())_0)(
                             );

        /** 				tok = next_token()*/
        _0 = _tok_55457;
        _tok_55457 = _39next_token();
        DeRef(_0);

        /** 				if tok[T_ID] = SLICE then*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _28381 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28381, 513)){
            _28381 = NOVALUE;
            goto LC; // [344] 382
        }
        _28381 = NOVALUE;

        /** 					call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_54681].addr;
        (*(int (*)())_0)(
                             );

        /** 					emit_op(RHS_SLICE)*/
        _41emit_op(46);

        /** 					tok_match(RIGHT_SQUARE)*/
        _39tok_match(-29, 0);

        /** 					tok = next_token()*/
        _0 = _tok_55457;
        _tok_55457 = _39next_token();
        DeRef(_0);

        /** 					exit*/
        goto LA; // [377] 450
        goto LD; // [379] 430
LC: 

        /** 					putback(tok)*/
        Ref(_tok_55457);
        _39putback(_tok_55457);

        /** 					tok_match(RIGHT_SQUARE)*/
        _39tok_match(-29, 0);

        /** 					subs_depth -= 1*/
        _39subs_depth_53711 = _39subs_depth_53711 - 1;

        /** 					current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _28385 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _28385 = 1;
        }
        _28386 = _28385 - 1;
        _28385 = NOVALUE;
        {
            int len = SEQ_PTR(_41current_sequence_49782)->length;
            int size = (IS_ATOM_INT(_28386)) ? _28386 : (object)(DBL_PTR(_28386)->dbl);
            if (size <= 0){
                DeRef( _41current_sequence_49782 );
                _41current_sequence_49782 = MAKE_SEQ(NewS1(0));
            }
            else if (len <= size) {
                RefDS(_41current_sequence_49782);
                DeRef(_41current_sequence_49782);
                _41current_sequence_49782 = _41current_sequence_49782;
            }
            else{
                Head(SEQ_PTR(_41current_sequence_49782),size+1,&_41current_sequence_49782);
            }
        }
        _28386 = NOVALUE;

        /** 					emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _41emit_op(25);
LD: 

        /** 				factors = save_factors*/
        _39factors_53707 = _save_factors_55460;

        /** 				lhs_subs_level = save_lhs_subs_level*/
        _39lhs_subs_level_53708 = _save_lhs_subs_level_55461;

        /** 				tok = next_token()*/
        _0 = _tok_55457;
        _tok_55457 = _39next_token();
        DeRef(_0);

        /** 			end while*/
        goto L9; // [447] 271
LA: 

        /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _28389 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _28389 = 1;
        }
        _28390 = _28389 - 1;
        _28389 = NOVALUE;
        {
            int len = SEQ_PTR(_41current_sequence_49782)->length;
            int size = (IS_ATOM_INT(_28390)) ? _28390 : (object)(DBL_PTR(_28390)->dbl);
            if (size <= 0){
                DeRef( _41current_sequence_49782 );
                _41current_sequence_49782 = MAKE_SEQ(NewS1(0));
            }
            else if (len <= size) {
                RefDS(_41current_sequence_49782);
                DeRef(_41current_sequence_49782);
                _41current_sequence_49782 = _41current_sequence_49782;
            }
            else{
                Head(SEQ_PTR(_41current_sequence_49782),size+1,&_41current_sequence_49782);
            }
        }
        _28390 = NOVALUE;

        /** 			putback(tok)*/
        Ref(_tok_55457);
        _39putback(_tok_55457);

        /** 			short_circuit += 1*/
        _39short_circuit_53669 = _39short_circuit_53669 + 1;
        goto L5; // [482] 696

        /** 		case DOLLAR then*/
        case -22:

        /** 			tok = next_token()*/
        _0 = _tok_55457;
        _tok_55457 = _39next_token();
        DeRef(_0);

        /** 			putback(tok)*/
        Ref(_tok_55457);
        _39putback(_tok_55457);

        /** 			if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _28394 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28394, -25)){
            _28394 = NOVALUE;
            goto LE; // [508] 526
        }
        _28394 = NOVALUE;

        /** 				gListItem[$] = 0*/
        if (IS_SEQUENCE(_39gListItem_53705)){
                _28396 = SEQ_PTR(_39gListItem_53705)->length;
        }
        else {
            _28396 = 1;
        }
        _2 = (int)SEQ_PTR(_39gListItem_53705);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39gListItem_53705 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _28396);
        *(int *)_2 = 0;
        goto L5; // [523] 696
LE: 

        /** 				if subs_depth > 0 and length(current_sequence) then*/
        _28397 = (_39subs_depth_53711 > 0);
        if (_28397 == 0) {
            goto LF; // [534] 557
        }
        if (IS_SEQUENCE(_41current_sequence_49782)){
                _28399 = SEQ_PTR(_41current_sequence_49782)->length;
        }
        else {
            _28399 = 1;
        }
        if (_28399 == 0)
        {
            _28399 = NOVALUE;
            goto LF; // [544] 557
        }
        else{
            _28399 = NOVALUE;
        }

        /** 					emit_op(DOLLAR)*/
        _41emit_op(-22);
        goto L5; // [554] 696
LF: 

        /** 					CompileErr(21)*/
        RefDS(_21815);
        _44CompileErr(21, _21815, 0);
        goto L5; // [566] 696

        /** 		case ATOM then*/
        case 502:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _28400 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28400);
        _41emit_opnd(_28400);
        _28400 = NOVALUE;
        goto L5; // [583] 696

        /** 		case LEFT_BRACE then*/
        case -24:

        /** 			n = Expr_list()*/
        _n_55459 = _39Expr_list();
        if (!IS_ATOM_INT(_n_55459)) {
            _1 = (long)(DBL_PTR(_n_55459)->dbl);
            DeRefDS(_n_55459);
            _n_55459 = _1;
        }

        /** 			tok_match(RIGHT_BRACE)*/
        _39tok_match(-25, 0);

        /** 			op_info1 = n*/
        _41op_info1_49774 = _n_55459;

        /** 			emit_op(RIGHT_BRACE_N)*/
        _41emit_op(31);
        goto L5; // [618] 696

        /** 		case STRING then*/
        case 503:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55457);
        _28402 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28402);
        _41emit_opnd(_28402);
        _28402 = NOVALUE;
        goto L5; // [635] 696

        /** 		case LEFT_ROUND then*/
        case -26:

        /** 			call_proc(forward_expr, {})*/
        _0 = (int)_00[_39forward_expr_54681].addr;
        (*(int (*)())_0)(
                             );

        /** 			tok_match(RIGHT_ROUND)*/
        _39tok_match(-27, 0);
        goto L5; // [656] 696

        /** 		case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** 			Function_call( tok )*/
        Ref(_tok_55457);
        _39Function_call(_tok_55457);
        goto L5; // [673] 696

        /** 		case else*/
        default:

        /** 			CompileErr(135, {LexName(id)})*/
        RefDS(_26183);
        _28403 = _41LexName(_id_55458, _26183);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _28403;
        _28404 = MAKE_SEQ(_1);
        _28403 = NOVALUE;
        _44CompileErr(135, _28404, 0);
        _28404 = NOVALUE;
    ;}L5: 

    /** end procedure*/
    DeRef(_tok_55457);
    DeRef(_28357);
    _28357 = NOVALUE;
    DeRef(_28397);
    _28397 = NOVALUE;
    return;
    ;
}


void _39UFactor()
{
    int _tok_55616 = NOVALUE;
    int _28410 = NOVALUE;
    int _28408 = NOVALUE;
    int _28406 = NOVALUE;
    int _0, _1, _2;
    

    /** 	tok = next_token()*/
    _0 = _tok_55616;
    _tok_55616 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_55616);
    _28406 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28406, 10)){
        _28406 = NOVALUE;
        goto L1; // [16] 34
    }
    _28406 = NOVALUE;

    /** 		Factor()*/
    _39Factor();

    /** 		emit_op(UMINUS)*/
    _41emit_op(12);
    goto L2; // [31] 93
L1: 

    /** 	elsif tok[T_ID] = NOT then*/
    _2 = (int)SEQ_PTR(_tok_55616);
    _28408 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28408, 7)){
        _28408 = NOVALUE;
        goto L3; // [44] 62
    }
    _28408 = NOVALUE;

    /** 		Factor()*/
    _39Factor();

    /** 		emit_op(NOT)*/
    _41emit_op(7);
    goto L2; // [59] 93
L3: 

    /** 	elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_55616);
    _28410 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28410, 11)){
        _28410 = NOVALUE;
        goto L4; // [72] 83
    }
    _28410 = NOVALUE;

    /** 		Factor()*/
    _39Factor();
    goto L2; // [80] 93
L4: 

    /** 		putback(tok)*/
    Ref(_tok_55616);
    _39putback(_tok_55616);

    /** 		Factor()*/
    _39Factor();
L2: 

    /** end procedure*/
    DeRef(_tok_55616);
    return;
    ;
}


int _39Term()
{
    int _tok_55641 = NOVALUE;
    int _28418 = NOVALUE;
    int _28417 = NOVALUE;
    int _28416 = NOVALUE;
    int _28414 = NOVALUE;
    int _28413 = NOVALUE;
    int _0, _1, _2;
    

    /** 	UFactor()*/
    _39UFactor();

    /** 	tok = next_token()*/
    _0 = _tok_55641;
    _tok_55641 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55641);
    _28413 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28413)) {
        _28414 = (_28413 == 13);
    }
    else {
        _28414 = binary_op(EQUALS, _28413, 13);
    }
    _28413 = NOVALUE;
    if (IS_ATOM_INT(_28414)) {
        if (_28414 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28414)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (int)SEQ_PTR(_tok_55641);
    _28416 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28416)) {
        _28417 = (_28416 == 14);
    }
    else {
        _28417 = binary_op(EQUALS, _28416, 14);
    }
    _28416 = NOVALUE;
    if (_28417 <= 0) {
        if (_28417 == 0) {
            DeRef(_28417);
            _28417 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28417) && DBL_PTR(_28417)->dbl == 0.0){
                DeRef(_28417);
                _28417 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28417);
            _28417 = NOVALUE;
        }
    }
    DeRef(_28417);
    _28417 = NOVALUE;
L2: 

    /** 		UFactor()*/
    _39UFactor();

    /** 		emit_op(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_55641);
    _28418 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28418);
    _41emit_op(_28418);
    _28418 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_55641;
    _tok_55641 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L1; // [66] 15
L3: 

    /** 	return tok*/
    DeRef(_28414);
    _28414 = NOVALUE;
    return _tok_55641;
    ;
}


int _39aexpr()
{
    int _tok_55658 = NOVALUE;
    int _id_55659 = NOVALUE;
    int _28425 = NOVALUE;
    int _28424 = NOVALUE;
    int _28422 = NOVALUE;
    int _28421 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = Term()*/
    _0 = _tok_55658;
    _tok_55658 = _39Term();
    DeRef(_0);

    /** 	while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55658);
    _28421 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28421)) {
        _28422 = (_28421 == 11);
    }
    else {
        _28422 = binary_op(EQUALS, _28421, 11);
    }
    _28421 = NOVALUE;
    if (IS_ATOM_INT(_28422)) {
        if (_28422 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28422)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (int)SEQ_PTR(_tok_55658);
    _28424 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28424)) {
        _28425 = (_28424 == 10);
    }
    else {
        _28425 = binary_op(EQUALS, _28424, 10);
    }
    _28424 = NOVALUE;
    if (_28425 <= 0) {
        if (_28425 == 0) {
            DeRef(_28425);
            _28425 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28425) && DBL_PTR(_28425)->dbl == 0.0){
                DeRef(_28425);
                _28425 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28425);
            _28425 = NOVALUE;
        }
    }
    DeRef(_28425);
    _28425 = NOVALUE;
L2: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55658);
    _id_55659 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55659)){
        _id_55659 = (long)DBL_PTR(_id_55659)->dbl;
    }

    /** 		tok = Term()*/
    _0 = _tok_55658;
    _tok_55658 = _39Term();
    DeRef(_0);

    /** 		emit_op(id)*/
    _41emit_op(_id_55659);

    /** 	end while*/
    goto L1; // [68] 13
L3: 

    /** 	return tok*/
    DeRef(_28422);
    _28422 = NOVALUE;
    return _tok_55658;
    ;
}


int _39cexpr()
{
    int _tok_55678 = NOVALUE;
    int _concat_count_55679 = NOVALUE;
    int _28429 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer concat_count*/

    /** 	tok = aexpr()*/
    _0 = _tok_55678;
    _tok_55678 = _39aexpr();
    DeRef(_0);

    /** 	concat_count = 0*/
    _concat_count_55679 = 0;

    /** 	while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55678);
    _28429 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28429, 15)){
        _28429 = NOVALUE;
        goto L2; // [24] 44
    }
    _28429 = NOVALUE;

    /** 		tok = aexpr()*/
    _0 = _tok_55678;
    _tok_55678 = _39aexpr();
    DeRef(_0);

    /** 		concat_count += 1*/
    _concat_count_55679 = _concat_count_55679 + 1;

    /** 	end while*/
    goto L1; // [41] 18
L2: 

    /** 	if concat_count = 1 then*/
    if (_concat_count_55679 != 1)
    goto L3; // [46] 58

    /** 		emit_op( reserved:CONCAT )*/
    _41emit_op(15);
    goto L4; // [55] 81
L3: 

    /** 	elsif concat_count > 1 then*/
    if (_concat_count_55679 <= 1)
    goto L5; // [60] 80

    /** 		op_info1 = concat_count+1*/
    _41op_info1_49774 = _concat_count_55679 + 1;

    /** 		emit_op(CONCAT_N)*/
    _41emit_op(157);
L5: 
L4: 

    /** 	return tok*/
    return _tok_55678;
    ;
}


int _39rexpr()
{
    int _tok_55699 = NOVALUE;
    int _id_55700 = NOVALUE;
    int _28441 = NOVALUE;
    int _28440 = NOVALUE;
    int _28439 = NOVALUE;
    int _28438 = NOVALUE;
    int _28437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = cexpr()*/
    _0 = _tok_55699;
    _tok_55699 = _39cexpr();
    DeRef(_0);

    /** 	while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55699);
    _28437 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28437)) {
        _28438 = (_28437 <= 6);
    }
    else {
        _28438 = binary_op(LESSEQ, _28437, 6);
    }
    _28437 = NOVALUE;
    if (IS_ATOM_INT(_28438)) {
        if (_28438 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28438)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (int)SEQ_PTR(_tok_55699);
    _28440 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28440)) {
        _28441 = (_28440 >= 1);
    }
    else {
        _28441 = binary_op(GREATEREQ, _28440, 1);
    }
    _28440 = NOVALUE;
    if (_28441 <= 0) {
        if (_28441 == 0) {
            DeRef(_28441);
            _28441 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28441) && DBL_PTR(_28441)->dbl == 0.0){
                DeRef(_28441);
                _28441 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28441);
            _28441 = NOVALUE;
        }
    }
    DeRef(_28441);
    _28441 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55699);
    _id_55700 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55700)){
        _id_55700 = (long)DBL_PTR(_id_55700)->dbl;
    }

    /** 		tok = cexpr()*/
    _0 = _tok_55699;
    _tok_55699 = _39cexpr();
    DeRef(_0);

    /** 		emit_op(id)*/
    _41emit_op(_id_55700);

    /** 	end while*/
    goto L1; // [67] 13
L2: 

    /** 	return tok*/
    DeRef(_28438);
    _28438 = NOVALUE;
    return _tok_55699;
    ;
}


void _39Expr()
{
    int _tok_55726 = NOVALUE;
    int _id_55727 = NOVALUE;
    int _patch_55728 = NOVALUE;
    int _28464 = NOVALUE;
    int _28462 = NOVALUE;
    int _28461 = NOVALUE;
    int _28459 = NOVALUE;
    int _28458 = NOVALUE;
    int _28457 = NOVALUE;
    int _28456 = NOVALUE;
    int _28455 = NOVALUE;
    int _28449 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	integer patch*/

    /** 	ExprLine = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_39ExprLine_55721);
    _39ExprLine_55721 = _44ThisLine_48142;

    /** 	expr_bp = bp*/
    _39expr_bp_55722 = _44bp_48146;

    /** 	id = -1*/
    _id_55727 = -1;

    /** 	patch = 0*/
    _patch_55728 = 0;

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_437 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** 		if id != -1 then*/
    if (_id_55727 == -1)
    goto L3; // [45] 116

    /** 			if id != XOR then*/
    if (_id_55727 == 152)
    goto L4; // [53] 115

    /** 				if short_circuit > 0 then*/
    if (_39short_circuit_53669 <= 0)
    goto L5; // [61] 114

    /** 					if id = OR then*/
    if (_id_55727 != 9)
    goto L6; // [69] 83

    /** 						emit_op(SC1_OR)*/
    _41emit_op(143);
    goto L7; // [80] 91
L6: 

    /** 						emit_op(SC1_AND)*/
    _41emit_op(141);
L7: 

    /** 					patch = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28449 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28449 = 1;
    }
    _patch_55728 = _28449 + 1;
    _28449 = NOVALUE;

    /** 					emit_forward_addr()*/
    _39emit_forward_addr();

    /** 					short_circuit_B = TRUE*/
    _39short_circuit_B_53671 = _13TRUE_437;
L5: 
L4: 
L3: 

    /** 		tok = rexpr()*/
    _0 = _tok_55726;
    _tok_55726 = _39rexpr();
    DeRef(_0);

    /** 		if id != -1 then*/
    if (_id_55727 == -1)
    goto L8; // [123] 268

    /** 			if id != XOR then*/
    if (_id_55727 == 152)
    goto L9; // [131] 261

    /** 				if short_circuit > 0 then*/
    if (_39short_circuit_53669 <= 0)
    goto LA; // [139] 252

    /** 					if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (int)SEQ_PTR(_tok_55726);
    _28455 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28455)) {
        _28456 = (_28455 != 410);
    }
    else {
        _28456 = binary_op(NOTEQ, _28455, 410);
    }
    _28455 = NOVALUE;
    if (IS_ATOM_INT(_28456)) {
        if (_28456 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28456)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (int)SEQ_PTR(_tok_55726);
    _28458 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28458)) {
        _28459 = (_28458 != 411);
    }
    else {
        _28459 = binary_op(NOTEQ, _28458, 411);
    }
    _28458 = NOVALUE;
    if (_28459 == 0) {
        DeRef(_28459);
        _28459 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28459) && DBL_PTR(_28459)->dbl == 0.0){
            DeRef(_28459);
            _28459 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28459);
        _28459 = NOVALUE;
    }
    DeRef(_28459);
    _28459 = NOVALUE;

    /** 						if id = OR then*/
    if (_id_55727 != 9)
    goto LC; // [181] 195

    /** 							emit_op(SC2_OR)*/
    _41emit_op(144);
    goto LD; // [192] 219
LC: 

    /** 							emit_op(SC2_AND)*/
    _41emit_op(142);
    goto LD; // [203] 219
LB: 

    /** 						SC1_type = id -- if/while/elsif must patch*/
    _39SC1_type_53674 = _id_55727;

    /** 						emit_op(SC2_NULL)*/
    _41emit_op(145);
LD: 

    /** 					if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** 						emit_op(NOP1)   -- to get label here*/
    _41emit_op(159);
LE: 

    /** 					backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28461 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28461 = 1;
    }
    _28462 = _28461 + 1;
    _28461 = NOVALUE;
    _41backpatch(_patch_55728, _28462);
    _28462 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** 					emit_op(id)*/
    _41emit_op(_id_55727);
    goto LF; // [258] 267
L9: 

    /** 				emit_op(id)*/
    _41emit_op(_id_55727);
LF: 
L8: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55726);
    _id_55727 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55727)){
        _id_55727 = (long)DBL_PTR(_id_55727)->dbl;
    }

    /** 		if not find(id, boolOps) then*/
    _28464 = find_from(_id_55727, _39boolOps_55716, 1);
    if (_28464 != 0)
    goto L1; // [287] 38
    _28464 = NOVALUE;

    /** 			exit*/
    goto L2; // [292] 300

    /** 	end while*/
    goto L1; // [297] 38
L2: 

    /** 	putback(tok)*/
    Ref(_tok_55726);
    _39putback(_tok_55726);

    /** 	SC1_patch = patch -- extra line*/
    _39SC1_patch_53673 = _patch_55728;

    /** end procedure*/
    DeRef(_tok_55726);
    DeRef(_28456);
    _28456 = NOVALUE;
    return;
    ;
}


void _39TypeCheck(int _var_55803)
{
    int _which_type_55804 = NOVALUE;
    int _ref_55814 = NOVALUE;
    int _ref_55847 = NOVALUE;
    int _28520 = NOVALUE;
    int _28519 = NOVALUE;
    int _28518 = NOVALUE;
    int _28517 = NOVALUE;
    int _28516 = NOVALUE;
    int _28514 = NOVALUE;
    int _28513 = NOVALUE;
    int _28512 = NOVALUE;
    int _28511 = NOVALUE;
    int _28510 = NOVALUE;
    int _28509 = NOVALUE;
    int _28507 = NOVALUE;
    int _28506 = NOVALUE;
    int _28503 = NOVALUE;
    int _28502 = NOVALUE;
    int _28501 = NOVALUE;
    int _28500 = NOVALUE;
    int _28495 = NOVALUE;
    int _28494 = NOVALUE;
    int _28490 = NOVALUE;
    int _28488 = NOVALUE;
    int _28487 = NOVALUE;
    int _28486 = NOVALUE;
    int _28484 = NOVALUE;
    int _28483 = NOVALUE;
    int _28482 = NOVALUE;
    int _28481 = NOVALUE;
    int _28480 = NOVALUE;
    int _28479 = NOVALUE;
    int _28476 = NOVALUE;
    int _28474 = NOVALUE;
    int _28472 = NOVALUE;
    int _28471 = NOVALUE;
    int _28470 = NOVALUE;
    int _28468 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28468 = (_var_55803 < 0);
    if (_28468 != 0) {
        goto L1; // [9] 36
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28470 = (int)*(((s1_ptr)_2)->base + _var_55803);
    _2 = (int)SEQ_PTR(_28470);
    _28471 = (int)*(((s1_ptr)_2)->base + 4);
    _28470 = NOVALUE;
    if (IS_ATOM_INT(_28471)) {
        _28472 = (_28471 == 9);
    }
    else {
        _28472 = binary_op(EQUALS, _28471, 9);
    }
    _28471 = NOVALUE;
    if (_28472 == 0) {
        DeRef(_28472);
        _28472 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28472) && DBL_PTR(_28472)->dbl == 0.0){
            DeRef(_28472);
            _28472 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28472);
        _28472 = NOVALUE;
    }
    DeRef(_28472);
    _28472 = NOVALUE;
L1: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_55814 = _38new_forward_reference(65, _var_55803, 197);
    if (!IS_ATOM_INT(_ref_55814)) {
        _1 = (long)(DBL_PTR(_ref_55814)->dbl);
        DeRefDS(_ref_55814);
        _ref_55814 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_55803;
    *((int *)(_2+12)) = _35OpTypeCheck_16038;
    _28474 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35Code_16056, _35Code_16056, _28474);
    DeRefDS(_28474);
    _28474 = NOVALUE;

    /** 		return*/
    DeRef(_28468);
    _28468 = NOVALUE;
    return;
L2: 

    /** 	which_type = SymTab[var][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28476 = (int)*(((s1_ptr)_2)->base + _var_55803);
    _2 = (int)SEQ_PTR(_28476);
    _which_type_55804 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_55804)){
        _which_type_55804 = (long)DBL_PTR(_which_type_55804)->dbl;
    }
    _28476 = NOVALUE;

    /** 	if which_type = 0 then*/
    if (_which_type_55804 != 0)
    goto L3; // [96] 106

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28468);
    _28468 = NOVALUE;
    return;
L3: 

    /** 	if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28479 = (_which_type_55804 > 0);
    if (_28479 == 0) {
        goto L4; // [112] 141
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28481 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
    if (IS_SEQUENCE(_28481)){
            _28482 = SEQ_PTR(_28481)->length;
    }
    else {
        _28482 = 1;
    }
    _28481 = NOVALUE;
    if (IS_ATOM_INT(_35S_TOKEN_15646)) {
        _28483 = (_28482 < _35S_TOKEN_15646);
    }
    else {
        _28483 = binary_op(LESS, _28482, _35S_TOKEN_15646);
    }
    _28482 = NOVALUE;
    if (_28483 == 0) {
        DeRef(_28483);
        _28483 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28483) && DBL_PTR(_28483)->dbl == 0.0){
            DeRef(_28483);
            _28483 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28483);
        _28483 = NOVALUE;
    }
    DeRef(_28483);
    _28483 = NOVALUE;

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28468);
    _28468 = NOVALUE;
    DeRef(_28479);
    _28479 = NOVALUE;
    _28481 = NOVALUE;
    return;
L4: 

    /** 	if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28484 = (_which_type_55804 < 0);
    if (_28484 != 0) {
        goto L5; // [147] 174
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28486 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
    _2 = (int)SEQ_PTR(_28486);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _28487 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _28487 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _28486 = NOVALUE;
    if (IS_ATOM_INT(_28487)) {
        _28488 = (_28487 == -100);
    }
    else {
        _28488 = binary_op(EQUALS, _28487, -100);
    }
    _28487 = NOVALUE;
    if (_28488 == 0) {
        DeRef(_28488);
        _28488 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28488) && DBL_PTR(_28488)->dbl == 0.0){
            DeRef(_28488);
            _28488 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28488);
        _28488 = NOVALUE;
    }
    DeRef(_28488);
    _28488 = NOVALUE;
L5: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_55847 = _38new_forward_reference(65, _which_type_55804, 504);
    if (!IS_ATOM_INT(_ref_55847)) {
        _1 = (long)(DBL_PTR(_ref_55847)->dbl);
        DeRefDS(_ref_55847);
        _ref_55847 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_55803;
    *((int *)(_2+12)) = _35OpTypeCheck_16038;
    _28490 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35Code_16056, _35Code_16056, _28490);
    DeRefDS(_28490);
    _28490 = NOVALUE;

    /** 		return*/
    DeRef(_28468);
    _28468 = NOVALUE;
    DeRef(_28479);
    _28479 = NOVALUE;
    _28481 = NOVALUE;
    DeRef(_28484);
    _28484 = NOVALUE;
    return;
L6: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** 		if OpTypeCheck then*/
    if (_35OpTypeCheck_16038 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** 			switch which_type do*/
    if( _39_55861_cases == 0 ){
        _39_55861_cases = 1;
        SEQ_PTR( _28492 )->base[1] = _53object_type_45715;
        SEQ_PTR( _28492 )->base[2] = _53sequence_type_45719;
        SEQ_PTR( _28492 )->base[3] = _53atom_type_45717;
        SEQ_PTR( _28492 )->base[4] = _53integer_type_45721;
    }
    _1 = find(_which_type_55804, _28492);
    switch ( _1 ){ 

        /** 				case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** 				case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** 					op_info1 = var*/
        _41op_info1_49774 = _var_55803;

        /** 					emit_op(INTEGER_CHECK)*/
        _41emit_op(96);
        goto L8; // [265] 481

        /** 				case else*/
        case 0:

        /** 					if SymTab[which_type][S_EFFECT] then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _28494 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
        _2 = (int)SEQ_PTR(_28494);
        _28495 = (int)*(((s1_ptr)_2)->base + 23);
        _28494 = NOVALUE;
        if (_28495 == 0) {
            _28495 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28495) && DBL_PTR(_28495)->dbl == 0.0){
                _28495 = NOVALUE;
                goto L9; // [285] 312
            }
            _28495 = NOVALUE;
        }
        _28495 = NOVALUE;

        /** 						emit_opnd(var)*/
        _41emit_opnd(_var_55803);

        /** 						op_info1 = which_type*/
        _41op_info1_49774 = _which_type_55804;

        /** 						emit_or_inline()*/
        _67emit_or_inline();

        /** 						emit_op(TYPE_CHECK)*/
        _41emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** 		if OpTypeCheck then*/
    if (_35OpTypeCheck_16038 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_55804 == _53object_type_45715)
    goto LB; // [328] 479

    /** 				if which_type = integer_type then*/
    if (_which_type_55804 != _53integer_type_45721)
    goto LC; // [336] 357

    /** 						op_info1 = var*/
    _41op_info1_49774 = _var_55803;

    /** 						emit_op(INTEGER_CHECK)*/
    _41emit_op(96);
    goto LD; // [354] 478
LC: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_55804 != _53sequence_type_45719)
    goto LE; // [361] 382

    /** 						op_info1 = var*/
    _41op_info1_49774 = _var_55803;

    /** 						emit_op(SEQUENCE_CHECK)*/
    _41emit_op(97);
    goto LD; // [379] 478
LE: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_55804 != _53atom_type_45717)
    goto LF; // [386] 407

    /** 						op_info1 = var*/
    _41op_info1_49774 = _var_55803;

    /** 						emit_op(ATOM_CHECK)*/
    _41emit_op(101);
    goto LD; // [404] 478
LF: 

    /** 						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28500 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
    _2 = (int)SEQ_PTR(_28500);
    _28501 = (int)*(((s1_ptr)_2)->base + 2);
    _28500 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28501)){
        _28502 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28501)->dbl));
    }
    else{
        _28502 = (int)*(((s1_ptr)_2)->base + _28501);
    }
    _2 = (int)SEQ_PTR(_28502);
    _28503 = (int)*(((s1_ptr)_2)->base + 15);
    _28502 = NOVALUE;
    if (binary_op_a(NOTEQ, _28503, _53integer_type_45721)){
        _28503 = NOVALUE;
        goto L10; // [435] 454
    }
    _28503 = NOVALUE;

    /** 							op_info1 = var*/
    _41op_info1_49774 = _var_55803;

    /** 							emit_op(INTEGER_CHECK) -- need integer conversion*/
    _41emit_op(96);
L10: 

    /** 						emit_opnd(var)*/
    _41emit_opnd(_var_55803);

    /** 						op_info1 = which_type*/
    _41op_info1_49774 = _which_type_55804;

    /** 						emit_or_inline()*/
    _67emit_or_inline();

    /** 						emit_op(TYPE_CHECK)*/
    _41emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** 	if TRANSLATE or not OpTypeCheck then*/
    if (_35TRANSLATE_15611 != 0) {
        goto L11; // [485] 499
    }
    _28506 = (_35OpTypeCheck_16038 == 0);
    if (_28506 == 0)
    {
        DeRef(_28506);
        _28506 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28506);
        _28506 = NOVALUE;
    }
L11: 

    /** 		op_info1 = var*/
    _41op_info1_49774 = _var_55803;

    /** 		if which_type = sequence_type or*/
    _28507 = (_which_type_55804 == _53sequence_type_45719);
    if (_28507 != 0) {
        goto L13; // [514] 553
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28509 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
    _2 = (int)SEQ_PTR(_28509);
    _28510 = (int)*(((s1_ptr)_2)->base + 2);
    _28509 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28510)){
        _28511 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28510)->dbl));
    }
    else{
        _28511 = (int)*(((s1_ptr)_2)->base + _28510);
    }
    _2 = (int)SEQ_PTR(_28511);
    _28512 = (int)*(((s1_ptr)_2)->base + 15);
    _28511 = NOVALUE;
    if (IS_ATOM_INT(_28512)) {
        _28513 = (_28512 == _53sequence_type_45719);
    }
    else {
        _28513 = binary_op(EQUALS, _28512, _53sequence_type_45719);
    }
    _28512 = NOVALUE;
    if (_28513 == 0) {
        DeRef(_28513);
        _28513 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28513) && DBL_PTR(_28513)->dbl == 0.0){
            DeRef(_28513);
            _28513 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28513);
        _28513 = NOVALUE;
    }
    DeRef(_28513);
    _28513 = NOVALUE;
L13: 

    /** 			emit_op(SEQUENCE_CHECK)*/
    _41emit_op(97);
    goto L15; // [560] 619
L14: 

    /** 		elsif which_type = integer_type or*/
    _28514 = (_which_type_55804 == _53integer_type_45721);
    if (_28514 != 0) {
        goto L16; // [571] 610
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28516 = (int)*(((s1_ptr)_2)->base + _which_type_55804);
    _2 = (int)SEQ_PTR(_28516);
    _28517 = (int)*(((s1_ptr)_2)->base + 2);
    _28516 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28517)){
        _28518 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28517)->dbl));
    }
    else{
        _28518 = (int)*(((s1_ptr)_2)->base + _28517);
    }
    _2 = (int)SEQ_PTR(_28518);
    _28519 = (int)*(((s1_ptr)_2)->base + 15);
    _28518 = NOVALUE;
    if (IS_ATOM_INT(_28519)) {
        _28520 = (_28519 == _53integer_type_45721);
    }
    else {
        _28520 = binary_op(EQUALS, _28519, _53integer_type_45721);
    }
    _28519 = NOVALUE;
    if (_28520 == 0) {
        DeRef(_28520);
        _28520 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28520) && DBL_PTR(_28520)->dbl == 0.0){
            DeRef(_28520);
            _28520 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28520);
        _28520 = NOVALUE;
    }
    DeRef(_28520);
    _28520 = NOVALUE;
L16: 

    /** 			emit_op(INTEGER_CHECK)*/
    _41emit_op(96);
L17: 
L15: 
L12: 

    /** end procedure*/
    DeRef(_28468);
    _28468 = NOVALUE;
    DeRef(_28479);
    _28479 = NOVALUE;
    _28481 = NOVALUE;
    DeRef(_28484);
    _28484 = NOVALUE;
    _28501 = NOVALUE;
    DeRef(_28507);
    _28507 = NOVALUE;
    _28510 = NOVALUE;
    DeRef(_28514);
    _28514 = NOVALUE;
    _28517 = NOVALUE;
    return;
    ;
}


void _39Assignment(int _left_var_55968)
{
    int _tok_55970 = NOVALUE;
    int _subs_55971 = NOVALUE;
    int _slice_55972 = NOVALUE;
    int _assign_op_55973 = NOVALUE;
    int _subs1_patch_55974 = NOVALUE;
    int _dangerous_55976 = NOVALUE;
    int _lname_56100 = NOVALUE;
    int _temp_len_56117 = NOVALUE;
    int _28619 = NOVALUE;
    int _28618 = NOVALUE;
    int _28617 = NOVALUE;
    int _28616 = NOVALUE;
    int _28615 = NOVALUE;
    int _28614 = NOVALUE;
    int _28613 = NOVALUE;
    int _28612 = NOVALUE;
    int _28603 = NOVALUE;
    int _28602 = NOVALUE;
    int _28601 = NOVALUE;
    int _28600 = NOVALUE;
    int _28599 = NOVALUE;
    int _28598 = NOVALUE;
    int _28597 = NOVALUE;
    int _28596 = NOVALUE;
    int _28595 = NOVALUE;
    int _28594 = NOVALUE;
    int _28593 = NOVALUE;
    int _28592 = NOVALUE;
    int _28591 = NOVALUE;
    int _28590 = NOVALUE;
    int _28589 = NOVALUE;
    int _28587 = NOVALUE;
    int _28586 = NOVALUE;
    int _28585 = NOVALUE;
    int _28583 = NOVALUE;
    int _28578 = NOVALUE;
    int _28577 = NOVALUE;
    int _28574 = NOVALUE;
    int _28573 = NOVALUE;
    int _28571 = NOVALUE;
    int _28565 = NOVALUE;
    int _28560 = NOVALUE;
    int _28557 = NOVALUE;
    int _28556 = NOVALUE;
    int _28553 = NOVALUE;
    int _28550 = NOVALUE;
    int _28549 = NOVALUE;
    int _28548 = NOVALUE;
    int _28546 = NOVALUE;
    int _28545 = NOVALUE;
    int _28544 = NOVALUE;
    int _28543 = NOVALUE;
    int _28542 = NOVALUE;
    int _28541 = NOVALUE;
    int _28539 = NOVALUE;
    int _28538 = NOVALUE;
    int _28537 = NOVALUE;
    int _28536 = NOVALUE;
    int _28534 = NOVALUE;
    int _28533 = NOVALUE;
    int _28532 = NOVALUE;
    int _28531 = NOVALUE;
    int _28530 = NOVALUE;
    int _28528 = NOVALUE;
    int _28527 = NOVALUE;
    int _28526 = NOVALUE;
    int _28523 = NOVALUE;
    int _28522 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer subs, slice, assign_op, subs1_patch*/

    /** 	left_sym = left_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_left_var_55968);
    _39left_sym_53710 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_39left_sym_53710)){
        _39left_sym_53710 = (long)DBL_PTR(_39left_sym_53710)->dbl;
    }

    /** 	if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28522 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28522);
    _28523 = (int)*(((s1_ptr)_2)->base + 4);
    _28522 = NOVALUE;
    if (binary_op_a(NOTEQ, _28523, 9)){
        _28523 = NOVALUE;
        goto L1; // [31] 54
    }
    _28523 = NOVALUE;

    /** 		Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_55968);
    _39Forward_var(_left_var_55968, -1, 18);

    /** 		left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _41Pop();
    _39left_sym_53710 = _0;
    if (!IS_ATOM_INT(_39left_sym_53710)) {
        _1 = (long)(DBL_PTR(_39left_sym_53710)->dbl);
        DeRefDS(_39left_sym_53710);
        _39left_sym_53710 = _1;
    }
    goto L2; // [51] 267
L1: 

    /** 		UndefinedVar(left_sym)*/
    _39UndefinedVar(_39left_sym_53710);

    /** 		if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28526 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28526);
    _28527 = (int)*(((s1_ptr)_2)->base + 4);
    _28526 = NOVALUE;
    if (IS_ATOM_INT(_28527)) {
        _28528 = (_28527 == 2);
    }
    else {
        _28528 = binary_op(EQUALS, _28527, 2);
    }
    _28527 = NOVALUE;
    if (IS_ATOM_INT(_28528)) {
        if (_28528 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28528)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28530 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28530);
    _28531 = (int)*(((s1_ptr)_2)->base + 4);
    _28530 = NOVALUE;
    if (IS_ATOM_INT(_28531)) {
        _28532 = (_28531 == 4);
    }
    else {
        _28532 = binary_op(EQUALS, _28531, 4);
    }
    _28531 = NOVALUE;
    if (_28532 == 0) {
        DeRef(_28532);
        _28532 = NOVALUE;
        goto L4; // [108] 122
    }
    else {
        if (!IS_ATOM_INT(_28532) && DBL_PTR(_28532)->dbl == 0.0){
            DeRef(_28532);
            _28532 = NOVALUE;
            goto L4; // [108] 122
        }
        DeRef(_28532);
        _28532 = NOVALUE;
    }
    DeRef(_28532);
    _28532 = NOVALUE;
L3: 

    /** 			CompileErr(109)*/
    RefDS(_21815);
    _44CompileErr(109, _21815, 0);
    goto L5; // [119] 229
L4: 

    /** 		elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28533 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28533);
    _28534 = (int)*(((s1_ptr)_2)->base + 3);
    _28533 = NOVALUE;
    if (binary_op_a(NOTEQ, _28534, 2)){
        _28534 = NOVALUE;
        goto L6; // [140] 154
    }
    _28534 = NOVALUE;

    /** 			CompileErr(110)*/
    RefDS(_21815);
    _44CompileErr(110, _21815, 0);
    goto L5; // [151] 229
L6: 

    /** 		elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28536 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28536);
    _28537 = (int)*(((s1_ptr)_2)->base + 4);
    _28536 = NOVALUE;
    _28538 = find_from(_28537, _39SCOPE_TYPES_53660, 1);
    _28537 = NOVALUE;
    if (_28538 == 0)
    {
        _28538 = NOVALUE;
        goto L7; // [177] 228
    }
    else{
        _28538 = NOVALUE;
    }

    /** 			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28541 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_28541);
    _28542 = (int)*(((s1_ptr)_2)->base + 23);
    _28541 = NOVALUE;
    _28543 = (_39left_sym_53710 % 29);
    _28544 = power(2, _28543);
    _28543 = NOVALUE;
    if (IS_ATOM_INT(_28542) && IS_ATOM_INT(_28544)) {
        {unsigned long tu;
             tu = (unsigned long)_28542 | (unsigned long)_28544;
             _28545 = MAKE_UINT(tu);
        }
    }
    else {
        _28545 = binary_op(OR_BITS, _28542, _28544);
    }
    _28542 = NOVALUE;
    DeRef(_28544);
    _28544 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28545;
    if( _1 != _28545 ){
        DeRef(_1);
    }
    _28545 = NOVALUE;
    _28539 = NOVALUE;
L7: 
L5: 

    /** 		SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_39left_sym_53710 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28548 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28548);
    _28549 = (int)*(((s1_ptr)_2)->base + 5);
    _28548 = NOVALUE;
    if (IS_ATOM_INT(_28549)) {
        {unsigned long tu;
             tu = (unsigned long)_28549 | (unsigned long)2;
             _28550 = MAKE_UINT(tu);
        }
    }
    else {
        _28550 = binary_op(OR_BITS, _28549, 2);
    }
    _28549 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28550;
    if( _1 != _28550 ){
        DeRef(_1);
    }
    _28550 = NOVALUE;
    _28546 = NOVALUE;
L2: 

    /** 	tok = next_token()*/
    _0 = _tok_55970;
    _tok_55970 = _39next_token();
    DeRef(_0);

    /** 	subs = 0*/
    _subs_55971 = 0;

    /** 	slice = FALSE*/
    _slice_55972 = _13FALSE_435;

    /** 	dangerous = FALSE*/
    _dangerous_55976 = _13FALSE_435;

    /** 	side_effect_calls = 0*/
    _39side_effect_calls_53706 = 0;

    /** 	emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_53710);

    /** 	current_sequence = append(current_sequence, left_sym)*/
    Append(&_41current_sequence_49782, _41current_sequence_49782, _39left_sym_53710);

    /** 	while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (int)SEQ_PTR(_tok_55970);
    _28553 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28553, -28)){
        _28553 = NOVALUE;
        goto L9; // [330] 522
    }
    _28553 = NOVALUE;

    /** 		subs_depth += 1*/
    _39subs_depth_53711 = _39subs_depth_53711 + 1;

    /** 		if lhs_ptr then*/
    if (_41lhs_ptr_49784 == 0)
    {
        goto LA; // [346] 404
    }
    else{
    }

    /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_41current_sequence_49782)){
            _28556 = SEQ_PTR(_41current_sequence_49782)->length;
    }
    else {
        _28556 = 1;
    }
    _28557 = _28556 - 1;
    _28556 = NOVALUE;
    {
        int len = SEQ_PTR(_41current_sequence_49782)->length;
        int size = (IS_ATOM_INT(_28557)) ? _28557 : (object)(DBL_PTR(_28557)->dbl);
        if (size <= 0){
            DeRef( _41current_sequence_49782 );
            _41current_sequence_49782 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_41current_sequence_49782);
            DeRef(_41current_sequence_49782);
            _41current_sequence_49782 = _41current_sequence_49782;
        }
        else{
            Head(SEQ_PTR(_41current_sequence_49782),size+1,&_41current_sequence_49782);
        }
    }
    _28557 = NOVALUE;

    /** 			if subs = 1 then*/
    if (_subs_55971 != 1)
    goto LB; // [370] 395

    /** 				subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28560 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28560 = 1;
    }
    _subs1_patch_55974 = _28560 + 1;
    _28560 = NOVALUE;

    /** 				emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _41emit_op(161);
    goto LC; // [392] 403
LB: 

    /** 				emit_op(LHS_SUBS) -- adds to current_sequence*/
    _41emit_op(95);
LC: 
LA: 

    /** 		subs += 1*/
    _subs_55971 = _subs_55971 + 1;

    /** 		if subs = 1 then*/
    if (_subs_55971 != 1)
    goto LD; // [412] 427

    /** 			InitCheck(left_sym, TRUE)*/
    _39InitCheck(_39left_sym_53710, _13TRUE_437);
LD: 

    /** 		Expr()*/
    _39Expr();

    /** 		tok = next_token()*/
    _0 = _tok_55970;
    _tok_55970 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok_55970);
    _28565 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28565, 513)){
        _28565 = NOVALUE;
        goto LE; // [446] 483
    }
    _28565 = NOVALUE;

    /** 			Expr()*/
    _39Expr();

    /** 			slice = TRUE*/
    _slice_55972 = _13TRUE_437;

    /** 			tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 			tok = next_token()*/
    _0 = _tok_55970;
    _tok_55970 = _39next_token();
    DeRef(_0);

    /** 			exit  -- no further subs or slices allowed*/
    goto L9; // [478] 522
    goto LF; // [480] 505
LE: 

    /** 			putback(tok)*/
    Ref(_tok_55970);
    _39putback(_tok_55970);

    /** 			tok_match(RIGHT_SQUARE)*/
    _39tok_match(-29, 0);

    /** 			subs_depth -= 1*/
    _39subs_depth_53711 = _39subs_depth_53711 - 1;
LF: 

    /** 		tok = next_token()*/
    _0 = _tok_55970;
    _tok_55970 = _39next_token();
    DeRef(_0);

    /** 		lhs_ptr = TRUE*/
    _41lhs_ptr_49784 = _13TRUE_437;

    /** 	end while*/
    goto L8; // [519] 322
L9: 

    /** 	lhs_ptr = FALSE*/
    _41lhs_ptr_49784 = _13FALSE_435;

    /** 	assign_op = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55970);
    _assign_op_55973 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_55973)){
        _assign_op_55973 = (long)DBL_PTR(_assign_op_55973)->dbl;
    }

    /** 	if not find(assign_op, ASSIGN_OPS) then*/
    _28571 = find_from(_assign_op_55973, _39ASSIGN_OPS_53652, 1);
    if (_28571 != 0)
    goto L10; // [548] 608
    _28571 = NOVALUE;

    /** 		sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_left_var_55968);
    _28573 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28573)){
        _28574 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28573)->dbl));
    }
    else{
        _28574 = (int)*(((s1_ptr)_2)->base + _28573);
    }
    DeRef(_lname_56100);
    _2 = (int)SEQ_PTR(_28574);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _lname_56100 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _lname_56100 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_lname_56100);
    _28574 = NOVALUE;

    /** 		if assign_op = COLON then*/
    if (_assign_op_55973 != -23)
    goto L11; // [577] 595

    /** 			CompileErr(133, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56100);
    *((int *)(_2+4)) = _lname_56100;
    _28577 = MAKE_SEQ(_1);
    _44CompileErr(133, _28577, 0);
    _28577 = NOVALUE;
    goto L12; // [592] 607
L11: 

    /** 			CompileErr(76, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56100);
    *((int *)(_2+4)) = _lname_56100;
    _28578 = MAKE_SEQ(_1);
    _44CompileErr(76, _28578, 0);
    _28578 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_56100);
    _lname_56100 = NOVALUE;

    /** 	if subs = 0 then*/
    if (_subs_55971 != 0)
    goto L13; // [612] 740

    /** 		integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _temp_len_56117 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _temp_len_56117 = 1;
    }

    /** 		if assign_op = EQUALS then*/
    if (_assign_op_55973 != 3)
    goto L14; // [627] 648

    /** 			Expr() -- RHS expression*/
    _39Expr();

    /** 			InitCheck(left_sym, FALSE)*/
    _39InitCheck(_39left_sym_53710, _13FALSE_435);
    goto L15; // [645] 721
L14: 

    /** 			InitCheck(left_sym, TRUE)*/
    _39InitCheck(_39left_sym_53710, _13TRUE_437);

    /** 			if left_sym > 0 then*/
    if (_39left_sym_53710 <= 0)
    goto L16; // [662] 704

    /** 				SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_39left_sym_53710 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28585 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28585);
    _28586 = (int)*(((s1_ptr)_2)->base + 5);
    _28585 = NOVALUE;
    if (IS_ATOM_INT(_28586)) {
        {unsigned long tu;
             tu = (unsigned long)_28586 | (unsigned long)1;
             _28587 = MAKE_UINT(tu);
        }
    }
    else {
        _28587 = binary_op(OR_BITS, _28586, 1);
    }
    _28586 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28587;
    if( _1 != _28587 ){
        DeRef(_1);
    }
    _28587 = NOVALUE;
    _28583 = NOVALUE;
L16: 

    /** 			emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_53710);

    /** 			Expr() -- RHS expression*/
    _39Expr();

    /** 			emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_55973);
L15: 

    /** 		emit_op(ASSIGN)*/
    _41emit_op(18);

    /** 		TypeCheck(left_sym)*/
    _39TypeCheck(_39left_sym_53710);
    goto L17; // [737] 1164
L13: 

    /** 		factors = 0*/
    _39factors_53707 = 0;

    /** 		lhs_subs_level = -1*/
    _39lhs_subs_level_53708 = -1;

    /** 		Expr() -- RHS expression*/
    _39Expr();

    /** 		if subs > 1 then*/
    if (_subs_55971 <= 1)
    goto L18; // [756] 895

    /** 			if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28589 = (_39left_sym_53710 < 0);
    if (_28589 != 0) {
        _28590 = 1;
        goto L19; // [768] 796
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28591 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28591);
    _28592 = (int)*(((s1_ptr)_2)->base + 4);
    _28591 = NOVALUE;
    if (IS_ATOM_INT(_28592)) {
        _28593 = (_28592 != 3);
    }
    else {
        _28593 = binary_op(NOTEQ, _28592, 3);
    }
    _28592 = NOVALUE;
    if (IS_ATOM_INT(_28593))
    _28590 = (_28593 != 0);
    else
    _28590 = DBL_PTR(_28593)->dbl != 0.0;
L19: 
    if (_28590 == 0) {
        goto L1A; // [796] 830
    }
    _28595 = (_39left_sym_53710 % 29);
    _28596 = power(2, _28595);
    _28595 = NOVALUE;
    if (IS_ATOM_INT(_28596)) {
        {unsigned long tu;
             tu = (unsigned long)_39side_effect_calls_53706 & (unsigned long)_28596;
             _28597 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_39side_effect_calls_53706;
        _28597 = Dand_bits(&temp_d, DBL_PTR(_28596));
    }
    DeRef(_28596);
    _28596 = NOVALUE;
    if (_28597 == 0) {
        DeRef(_28597);
        _28597 = NOVALUE;
        goto L1A; // [819] 830
    }
    else {
        if (!IS_ATOM_INT(_28597) && DBL_PTR(_28597)->dbl == 0.0){
            DeRef(_28597);
            _28597 = NOVALUE;
            goto L1A; // [819] 830
        }
        DeRef(_28597);
        _28597 = NOVALUE;
    }
    DeRef(_28597);
    _28597 = NOVALUE;

    /** 				dangerous = TRUE*/
    _dangerous_55976 = _13TRUE_437;
L1A: 

    /** 			if factors = 1 and*/
    _28598 = (_39factors_53707 == 1);
    if (_28598 == 0) {
        _28599 = 0;
        goto L1B; // [838] 852
    }
    _28600 = (_39lhs_subs_level_53708 >= 0);
    _28599 = (_28600 != 0);
L1B: 
    if (_28599 == 0) {
        goto L1C; // [852] 878
    }
    _28602 = _subs_55971 + _slice_55972;
    if ((long)((unsigned long)_28602 + (unsigned long)HIGH_BITS) >= 0) 
    _28602 = NewDouble((double)_28602);
    if (IS_ATOM_INT(_28602)) {
        _28603 = (_39lhs_subs_level_53708 < _28602);
    }
    else {
        _28603 = ((double)_39lhs_subs_level_53708 < DBL_PTR(_28602)->dbl);
    }
    DeRef(_28602);
    _28602 = NOVALUE;
    if (_28603 == 0)
    {
        DeRef(_28603);
        _28603 = NOVALUE;
        goto L1C; // [867] 878
    }
    else{
        DeRef(_28603);
        _28603 = NOVALUE;
    }

    /** 				dangerous = TRUE*/
    _dangerous_55976 = _13TRUE_437;
L1C: 

    /** 			if dangerous then*/
    if (_dangerous_55976 == 0)
    {
        goto L1D; // [880] 894
    }
    else{
    }

    /** 				backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _41backpatch(_subs1_patch_55974, 166);
L1D: 
L18: 

    /** 		if slice then*/
    if (_slice_55972 == 0)
    {
        goto L1E; // [897] 965
    }
    else{
    }

    /** 			if assign_op != EQUALS then*/
    if (_assign_op_55973 == 3)
    goto L1F; // [904] 938

    /** 				if subs = 1 then*/
    if (_subs_55971 != 1)
    goto L20; // [910] 924

    /** 					emit_op(ASSIGN_OP_SLICE)*/
    _41emit_op(150);
    goto L21; // [921] 932
L20: 

    /** 					emit_op(PASSIGN_OP_SLICE)*/
    _41emit_op(165);
L21: 

    /** 				emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_55973);
L1F: 

    /** 			if subs = 1 then*/
    if (_subs_55971 != 1)
    goto L22; // [940] 954

    /** 				emit_op(ASSIGN_SLICE)*/
    _41emit_op(45);
    goto L23; // [951] 1055
L22: 

    /** 				emit_op(PASSIGN_SLICE)*/
    _41emit_op(163);
    goto L23; // [962] 1055
L1E: 

    /** 			if assign_op = EQUALS then*/
    if (_assign_op_55973 != 3)
    goto L24; // [969] 1000

    /** 				if subs = 1 then*/
    if (_subs_55971 != 1)
    goto L25; // [975] 989

    /** 					emit_op(ASSIGN_SUBS)*/
    _41emit_op(16);
    goto L26; // [986] 1054
L25: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _41emit_op(162);
    goto L26; // [997] 1054
L24: 

    /** 				if subs = 1 then*/
    if (_subs_55971 != 1)
    goto L27; // [1002] 1016

    /** 					emit_op(ASSIGN_OP_SUBS)*/
    _41emit_op(149);
    goto L28; // [1013] 1024
L27: 

    /** 					emit_op(PASSIGN_OP_SUBS)*/
    _41emit_op(164);
L28: 

    /** 				emit_assign_op(assign_op)*/
    _41emit_assign_op(_assign_op_55973);

    /** 				if subs = 1 then*/
    if (_subs_55971 != 1)
    goto L29; // [1031] 1045

    /** 					emit_op(ASSIGN_SUBS2)*/
    _41emit_op(148);
    goto L2A; // [1042] 1053
L29: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _41emit_op(162);
L2A: 
L26: 
L23: 

    /** 		if subs > 1 then*/
    if (_subs_55971 <= 1)
    goto L2B; // [1057] 1109

    /** 			if dangerous then*/
    if (_dangerous_55976 == 0)
    {
        goto L2C; // [1063] 1100
    }
    else{
    }

    /** 				emit_opnd(left_sym)*/
    _41emit_opnd(_39left_sym_53710);

    /** 				emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _41emit_opnd(_41lhs_subs1_copy_temp_49787);

    /** 				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _41emit_temp(_41lhs_subs1_copy_temp_49787, 1);

    /** 				emit_op(ASSIGN)*/
    _41emit_op(18);
    goto L2D; // [1097] 1108
L2C: 

    /** 				TempFree(lhs_subs1_copy_temp)*/
    _41TempFree(_41lhs_subs1_copy_temp_49787);
L2D: 
L2B: 

    /** 		if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_35OpTypeCheck_16038 == 0) {
        goto L2E; // [1113] 1163
    }
    _28613 = (_39left_sym_53710 < 0);
    if (_28613 != 0) {
        DeRef(_28614);
        _28614 = 1;
        goto L2F; // [1123] 1151
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28615 = (int)*(((s1_ptr)_2)->base + _39left_sym_53710);
    _2 = (int)SEQ_PTR(_28615);
    _28616 = (int)*(((s1_ptr)_2)->base + 15);
    _28615 = NOVALUE;
    if (IS_ATOM_INT(_28616)) {
        _28617 = (_28616 != _53sequence_type_45719);
    }
    else {
        _28617 = binary_op(NOTEQ, _28616, _53sequence_type_45719);
    }
    _28616 = NOVALUE;
    if (IS_ATOM_INT(_28617))
    _28614 = (_28617 != 0);
    else
    _28614 = DBL_PTR(_28617)->dbl != 0.0;
L2F: 
    if (_28614 == 0)
    {
        _28614 = NOVALUE;
        goto L2E; // [1152] 1163
    }
    else{
        _28614 = NOVALUE;
    }

    /** 			TypeCheck(left_sym)*/
    _39TypeCheck(_39left_sym_53710);
L2E: 
L17: 

    /** 	current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_41current_sequence_49782)){
            _28618 = SEQ_PTR(_41current_sequence_49782)->length;
    }
    else {
        _28618 = 1;
    }
    _28619 = _28618 - 1;
    _28618 = NOVALUE;
    {
        int len = SEQ_PTR(_41current_sequence_49782)->length;
        int size = (IS_ATOM_INT(_28619)) ? _28619 : (object)(DBL_PTR(_28619)->dbl);
        if (size <= 0){
            DeRef( _41current_sequence_49782 );
            _41current_sequence_49782 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_41current_sequence_49782);
            DeRef(_41current_sequence_49782);
            _41current_sequence_49782 = _41current_sequence_49782;
        }
        else{
            Head(SEQ_PTR(_41current_sequence_49782),size+1,&_41current_sequence_49782);
        }
    }
    _28619 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L30; // [1187] 1213

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L31; // [1194] 1212
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _41emit_op(87);

    /** 			emit_addr(left_sym)*/
    _41emit_addr(_39left_sym_53710);
L31: 
L30: 

    /** end procedure*/
    DeRef(_left_var_55968);
    DeRef(_tok_55970);
    _28573 = NOVALUE;
    DeRef(_28528);
    _28528 = NOVALUE;
    DeRef(_28589);
    _28589 = NOVALUE;
    DeRef(_28598);
    _28598 = NOVALUE;
    DeRef(_28593);
    _28593 = NOVALUE;
    DeRef(_28600);
    _28600 = NOVALUE;
    DeRef(_28613);
    _28613 = NOVALUE;
    DeRef(_28617);
    _28617 = NOVALUE;
    return;
    ;
}


void _39Return_statement()
{
    int _tok_56259 = NOVALUE;
    int _pop_56260 = NOVALUE;
    int _last_op_56266 = NOVALUE;
    int _last_pc_56269 = NOVALUE;
    int _is_tail_56272 = NOVALUE;
    int _28653 = NOVALUE;
    int _28651 = NOVALUE;
    int _28650 = NOVALUE;
    int _28649 = NOVALUE;
    int _28648 = NOVALUE;
    int _28646 = NOVALUE;
    int _28645 = NOVALUE;
    int _28644 = NOVALUE;
    int _28643 = NOVALUE;
    int _28642 = NOVALUE;
    int _28641 = NOVALUE;
    int _28640 = NOVALUE;
    int _28639 = NOVALUE;
    int _28635 = NOVALUE;
    int _28634 = NOVALUE;
    int _28632 = NOVALUE;
    int _28631 = NOVALUE;
    int _28630 = NOVALUE;
    int _28629 = NOVALUE;
    int _28628 = NOVALUE;
    int _28627 = NOVALUE;
    int _28626 = NOVALUE;
    int _28625 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer pop*/

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_15976 != _35TopLevelSub_15975)
    goto L1; // [9] 21

    /** 		CompileErr(130)*/
    RefDS(_21815);
    _44CompileErr(130, _21815, 0);
L1: 

    /** 	integer*/

    /** 		last_op = Last_op(),*/
    _last_op_56266 = _41Last_op();
    if (!IS_ATOM_INT(_last_op_56266)) {
        _1 = (long)(DBL_PTR(_last_op_56266)->dbl);
        DeRefDS(_last_op_56266);
        _last_op_56266 = _1;
    }

    /** 		last_pc = Last_pc(),*/
    _last_pc_56269 = _41Last_pc();
    if (!IS_ATOM_INT(_last_pc_56269)) {
        _1 = (long)(DBL_PTR(_last_pc_56269)->dbl);
        DeRefDS(_last_pc_56269);
        _last_pc_56269 = _1;
    }

    /** 		is_tail = 0*/
    _is_tail_56272 = 0;

    /** 	if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28625 = (_last_op_56266 == 27);
    if (_28625 == 0) {
        _28626 = 0;
        goto L2; // [50] 67
    }
    if (IS_SEQUENCE(_35Code_16056)){
            _28627 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28627 = 1;
    }
    _28628 = (_28627 > _last_pc_56269);
    _28627 = NOVALUE;
    _28626 = (_28628 != 0);
L2: 
    if (_28626 == 0) {
        goto L3; // [67] 97
    }
    _28630 = _last_pc_56269 + 1;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _28631 = (int)*(((s1_ptr)_2)->base + _28630);
    if (IS_ATOM_INT(_28631)) {
        _28632 = (_28631 == _35CurrentSub_15976);
    }
    else {
        _28632 = binary_op(EQUALS, _28631, _35CurrentSub_15976);
    }
    _28631 = NOVALUE;
    if (_28632 == 0) {
        DeRef(_28632);
        _28632 = NOVALUE;
        goto L3; // [88] 97
    }
    else {
        if (!IS_ATOM_INT(_28632) && DBL_PTR(_28632)->dbl == 0.0){
            DeRef(_28632);
            _28632 = NOVALUE;
            goto L3; // [88] 97
        }
        DeRef(_28632);
        _28632 = NOVALUE;
    }
    DeRef(_28632);
    _28632 = NOVALUE;

    /** 		is_tail = 1*/
    _is_tail_56272 = 1;
L3: 

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L4; // [101] 127

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L5; // [108] 126
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 			emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_15976);
L5: 
L4: 

    /** 	if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _28634 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_28634);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _28635 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _28635 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _28634 = NOVALUE;
    if (binary_op_a(EQUALS, _28635, 27)){
        _28635 = NOVALUE;
        goto L6; // [145] 271
    }
    _28635 = NOVALUE;

    /** 		Expr()*/
    _39Expr();

    /** 		last_op = Last_op()*/
    _last_op_56266 = _41Last_op();
    if (!IS_ATOM_INT(_last_op_56266)) {
        _1 = (long)(DBL_PTR(_last_op_56266)->dbl);
        DeRefDS(_last_op_56266);
        _last_op_56266 = _1;
    }

    /** 		last_pc = Last_pc()*/
    _last_pc_56269 = _41Last_pc();
    if (!IS_ATOM_INT(_last_pc_56269)) {
        _1 = (long)(DBL_PTR(_last_pc_56269)->dbl);
        DeRefDS(_last_pc_56269);
        _last_pc_56269 = _1;
    }

    /** 		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28639 = (_last_op_56266 == 27);
    if (_28639 == 0) {
        _28640 = 0;
        goto L7; // [175] 192
    }
    if (IS_SEQUENCE(_35Code_16056)){
            _28641 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28641 = 1;
    }
    _28642 = (_28641 > _last_pc_56269);
    _28641 = NOVALUE;
    _28640 = (_28642 != 0);
L7: 
    if (_28640 == 0) {
        goto L8; // [192] 251
    }
    _28644 = _last_pc_56269 + 1;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _28645 = (int)*(((s1_ptr)_2)->base + _28644);
    if (IS_ATOM_INT(_28645)) {
        _28646 = (_28645 == _35CurrentSub_15976);
    }
    else {
        _28646 = binary_op(EQUALS, _28645, _35CurrentSub_15976);
    }
    _28645 = NOVALUE;
    if (_28646 == 0) {
        DeRef(_28646);
        _28646 = NOVALUE;
        goto L8; // [213] 251
    }
    else {
        if (!IS_ATOM_INT(_28646) && DBL_PTR(_28646)->dbl == 0.0){
            DeRef(_28646);
            _28646 = NOVALUE;
            goto L8; // [213] 251
        }
        DeRef(_28646);
        _28646 = NOVALUE;
    }
    DeRef(_28646);
    _28646 = NOVALUE;

    /** 			pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_56260 = _41Pop();
    if (!IS_ATOM_INT(_pop_56260)) {
        _1 = (long)(DBL_PTR(_pop_56260)->dbl);
        DeRefDS(_pop_56260);
        _pop_56260 = _1;
    }

    /** 			Code[Last_pc()] = PROC_TAIL*/
    _28648 = _41Last_pc();
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28648))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28648)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _28648);
    _1 = *(int *)_2;
    *(int *)_2 = 203;
    DeRef(_1);

    /** 			if object(pop_temps()) then end if*/
    _28649 = _41pop_temps();
    if( NOVALUE == _28649 ){
        _28650 = 0;
    }
    else{
        if (IS_ATOM_INT(_28649))
        _28650 = 1;
        else if (IS_ATOM_DBL(_28649)) {
             if (IS_ATOM_INT(DoubleToInt(_28649))) {
                 _28650 = 1;
                 } else {
                     _28650 = 2;
                } } else if (IS_SEQUENCE(_28649))
                _28650 = 3;
                else
                _28650 = 0;
            }
            DeRef(_28649);
            _28649 = NOVALUE;
            if (_28650 == 0)
            {
                _28650 = NOVALUE;
                goto L9; // [244] 298
            }
            else{
                _28650 = NOVALUE;
            }
            goto L9; // [248] 298
L8: 

            /** 			FuncReturn = TRUE*/
            _39FuncReturn_53677 = _13TRUE_437;

            /** 			emit_op(RETURNF)*/
            _41emit_op(28);
            goto L9; // [268] 298
L6: 

            /** 		if is_tail then*/
            if (_is_tail_56272 == 0)
            {
                goto LA; // [273] 290
            }
            else{
            }

            /** 			Code[Last_pc()] = PROC_TAIL*/
            _28651 = _41Last_pc();
            _2 = (int)SEQ_PTR(_35Code_16056);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _35Code_16056 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28651))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28651)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _28651);
            _1 = *(int *)_2;
            *(int *)_2 = 203;
            DeRef(_1);
LA: 

            /** 		emit_op(RETURNP)*/
            _41emit_op(29);
L9: 

            /** 	tok = next_token()*/
            _0 = _tok_56259;
            _tok_56259 = _39next_token();
            DeRef(_0);

            /** 	putback(tok)*/
            Ref(_tok_56259);
            _39putback(_tok_56259);

            /** 	NotReached(tok[T_ID], "return")*/
            _2 = (int)SEQ_PTR(_tok_56259);
            _28653 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_28653);
            RefDS(_26110);
            _39NotReached(_28653, _26110);
            _28653 = NOVALUE;

            /** end procedure*/
            DeRef(_tok_56259);
            DeRef(_28625);
            _28625 = NOVALUE;
            DeRef(_28628);
            _28628 = NOVALUE;
            DeRef(_28630);
            _28630 = NOVALUE;
            DeRef(_28639);
            _28639 = NOVALUE;
            DeRef(_28642);
            _28642 = NOVALUE;
            DeRef(_28644);
            _28644 = NOVALUE;
            DeRef(_28648);
            _28648 = NOVALUE;
            DeRef(_28651);
            _28651 = NOVALUE;
            return;
    ;
}


int _39exit_level(int _tok_56348, int _flag_56349)
{
    int _arg_56350 = NOVALUE;
    int _n_56351 = NOVALUE;
    int _num_labels_56352 = NOVALUE;
    int _negative_56353 = NOVALUE;
    int _labels_56354 = NOVALUE;
    int _28683 = NOVALUE;
    int _28682 = NOVALUE;
    int _28681 = NOVALUE;
    int _28680 = NOVALUE;
    int _28679 = NOVALUE;
    int _28675 = NOVALUE;
    int _28674 = NOVALUE;
    int _28673 = NOVALUE;
    int _28671 = NOVALUE;
    int _28670 = NOVALUE;
    int _28669 = NOVALUE;
    int _28668 = NOVALUE;
    int _28666 = NOVALUE;
    int _28661 = NOVALUE;
    int _28660 = NOVALUE;
    int _28658 = NOVALUE;
    int _28655 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer negative = 0*/
    _negative_56353 = 0;

    /** 	if flag then*/
    if (_flag_56349 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** 		labels = if_labels*/
    RefDS(_39if_labels_53698);
    DeRef(_labels_56354);
    _labels_56354 = _39if_labels_53698;
    goto L2; // [22] 35
L1: 

    /** 		labels = loop_labels*/
    RefDS(_39loop_labels_53697);
    DeRef(_labels_56354);
    _labels_56354 = _39loop_labels_53697;
L2: 

    /** 	num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_56354)){
            _num_labels_56352 = SEQ_PTR(_labels_56354)->length;
    }
    else {
        _num_labels_56352 = 1;
    }

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56348);
    _28655 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28655, 10)){
        _28655 = NOVALUE;
        goto L3; // [52] 67
    }
    _28655 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56348;
    _tok_56348 = _39next_token();
    DeRef(_0);

    /** 		negative = 1*/
    _negative_56353 = 1;
L3: 

    /** 	if tok[T_ID]=ATOM then*/
    _2 = (int)SEQ_PTR(_tok_56348);
    _28658 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28658, 502)){
        _28658 = NOVALUE;
        goto L4; // [77] 178
    }
    _28658 = NOVALUE;

    /** 		arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56348);
    _28660 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28660)){
        _28661 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28660)->dbl));
    }
    else{
        _28661 = (int)*(((s1_ptr)_2)->base + _28660);
    }
    DeRef(_arg_56350);
    _2 = (int)SEQ_PTR(_28661);
    _arg_56350 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_56350);
    _28661 = NOVALUE;

    /** 		n = floor(arg)*/
    if (IS_ATOM_INT(_arg_56350))
    _n_56351 = e_floor(_arg_56350);
    else
    _n_56351 = unary_op(FLOOR, _arg_56350);
    if (!IS_ATOM_INT(_n_56351)) {
        _1 = (long)(DBL_PTR(_n_56351)->dbl);
        DeRefDS(_n_56351);
        _n_56351 = _1;
    }

    /** 		if negative then*/
    if (_negative_56353 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** 			n = num_labels - n*/
    _n_56351 = _num_labels_56352 - _n_56351;
    goto L6; // [119] 135
L5: 

    /** 		elsif n = 0 then*/
    if (_n_56351 != 0)
    goto L7; // [124] 134

    /** 			n = num_labels*/
    _n_56351 = _num_labels_56352;
L7: 
L6: 

    /** 		if n<=0 or n>num_labels then*/
    _28666 = (_n_56351 <= 0);
    if (_28666 != 0) {
        goto L8; // [141] 154
    }
    _28668 = (_n_56351 > _num_labels_56352);
    if (_28668 == 0)
    {
        DeRef(_28668);
        _28668 = NOVALUE;
        goto L9; // [150] 162
    }
    else{
        DeRef(_28668);
        _28668 = NOVALUE;
    }
L8: 

    /** 			CompileErr(87)*/
    RefDS(_21815);
    _44CompileErr(87, _21815, 0);
L9: 

    /** 		return {n, next_token()}*/
    _28669 = _39next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _n_56351;
    ((int *)_2)[2] = _28669;
    _28670 = MAKE_SEQ(_1);
    _28669 = NOVALUE;
    DeRef(_tok_56348);
    DeRef(_arg_56350);
    DeRef(_labels_56354);
    _28660 = NOVALUE;
    DeRef(_28666);
    _28666 = NOVALUE;
    return _28670;
    goto LA; // [175] 266
L4: 

    /** 	elsif tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56348);
    _28671 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28671, 503)){
        _28671 = NOVALUE;
        goto LB; // [188] 255
    }
    _28671 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (int)SEQ_PTR(_tok_56348);
    _28673 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28673)){
        _28674 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28673)->dbl));
    }
    else{
        _28674 = (int)*(((s1_ptr)_2)->base + _28673);
    }
    _2 = (int)SEQ_PTR(_28674);
    _28675 = (int)*(((s1_ptr)_2)->base + 1);
    _28674 = NOVALUE;
    _n_56351 = find_from(_28675, _labels_56354, 1);
    _28675 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56351 != 0)
    goto LC; // [219] 231

    /** 			CompileErr(152)*/
    RefDS(_21815);
    _44CompileErr(152, _21815, 0);
LC: 

    /** 		return {num_labels + 1 - n, next_token()}*/
    _28679 = _num_labels_56352 + 1;
    if (_28679 > MAXINT){
        _28679 = NewDouble((double)_28679);
    }
    if (IS_ATOM_INT(_28679)) {
        _28680 = _28679 - _n_56351;
        if ((long)((unsigned long)_28680 +(unsigned long) HIGH_BITS) >= 0){
            _28680 = NewDouble((double)_28680);
        }
    }
    else {
        _28680 = NewDouble(DBL_PTR(_28679)->dbl - (double)_n_56351);
    }
    DeRef(_28679);
    _28679 = NOVALUE;
    _28681 = _39next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28680;
    ((int *)_2)[2] = _28681;
    _28682 = MAKE_SEQ(_1);
    _28681 = NOVALUE;
    _28680 = NOVALUE;
    DeRef(_tok_56348);
    DeRef(_arg_56350);
    DeRef(_labels_56354);
    _28660 = NOVALUE;
    DeRef(_28666);
    _28666 = NOVALUE;
    DeRef(_28670);
    _28670 = NOVALUE;
    _28673 = NOVALUE;
    return _28682;
    goto LA; // [252] 266
LB: 

    /** 		return {1, tok} -- no parameters*/
    Ref(_tok_56348);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _tok_56348;
    _28683 = MAKE_SEQ(_1);
    DeRef(_tok_56348);
    DeRef(_arg_56350);
    DeRef(_labels_56354);
    _28660 = NOVALUE;
    DeRef(_28666);
    _28666 = NOVALUE;
    DeRef(_28670);
    _28670 = NOVALUE;
    _28673 = NOVALUE;
    DeRef(_28682);
    _28682 = NOVALUE;
    return _28683;
LA: 
    ;
}


void _39GLabel_statement()
{
    int _tok_56412 = NOVALUE;
    int _labbel_56413 = NOVALUE;
    int _laddr_56414 = NOVALUE;
    int _n_56415 = NOVALUE;
    int _28702 = NOVALUE;
    int _28700 = NOVALUE;
    int _28699 = NOVALUE;
    int _28698 = NOVALUE;
    int _28697 = NOVALUE;
    int _28695 = NOVALUE;
    int _28692 = NOVALUE;
    int _28690 = NOVALUE;
    int _28688 = NOVALUE;
    int _28687 = NOVALUE;
    int _28685 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object labbel*/

    /** 	object laddr*/

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_56412;
    _tok_56412 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56412);
    _28685 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28685, 503)){
        _28685 = NOVALUE;
        goto L1; // [22] 34
    }
    _28685 = NOVALUE;

    /** 		CompileErr(35)*/
    RefDS(_21815);
    _44CompileErr(35, _21815, 0);
L1: 

    /** 	labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56412);
    _28687 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28687)){
        _28688 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28687)->dbl));
    }
    else{
        _28688 = (int)*(((s1_ptr)_2)->base + _28687);
    }
    DeRef(_labbel_56413);
    _2 = (int)SEQ_PTR(_28688);
    _labbel_56413 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56413);
    _28688 = NOVALUE;

    /** 	laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28690 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28690 = 1;
    }
    _laddr_56414 = _28690 + 1;
    _28690 = NOVALUE;

    /** 	if find(labbel, goto_labels) then*/
    _28692 = find_from(_labbel_56413, _39goto_labels_53680, 1);
    if (_28692 == 0)
    {
        _28692 = NOVALUE;
        goto L2; // [74] 85
    }
    else{
        _28692 = NOVALUE;
    }

    /** 		CompileErr(59)*/
    RefDS(_21815);
    _44CompileErr(59, _21815, 0);
L2: 

    /** 	goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_56413);
    Append(&_39goto_labels_53680, _39goto_labels_53680, _labbel_56413);

    /** 	goto_addr = append(goto_addr, laddr)*/
    Append(&_39goto_addr_53681, _39goto_addr_53681, _laddr_56414);

    /** 	label_block = append( label_block, top_block() )*/
    _28695 = _66top_block(0);
    Ref(_28695);
    Append(&_39label_block_53684, _39label_block_53684, _28695);
    DeRef(_28695);
    _28695 = NOVALUE;

    /** 	while n with entry do*/
    goto L3; // [115] 174
L4: 
    if (_n_56415 == 0)
    {
        goto L5; // [120] 188
    }
    else{
    }

    /** 		backpatch(goto_list[n], laddr)*/
    _2 = (int)SEQ_PTR(_35goto_list_16079);
    _28697 = (int)*(((s1_ptr)_2)->base + _n_56415);
    Ref(_28697);
    _41backpatch(_28697, _laddr_56414);
    _28697 = NOVALUE;

    /** 		set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (int)SEQ_PTR(_39goto_ref_53683);
    _28698 = (int)*(((s1_ptr)_2)->base + _n_56415);
    _28699 = _66top_block(0);
    Ref(_28698);
    _38set_glabel_block(_28698, _28699);
    _28698 = NOVALUE;
    _28699 = NOVALUE;

    /** 		goto_delay[n] = "" --clear it*/
    RefDS(_21815);
    _2 = (int)SEQ_PTR(_35goto_delay_16078);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35goto_delay_16078 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56415);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);

    /** 		goto_line[n] = {-1,""} --clear it*/
    RefDS(_21815);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _21815;
    _28700 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_39goto_line_53679);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39goto_line_53679 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56415);
    _1 = *(int *)_2;
    *(int *)_2 = _28700;
    if( _1 != _28700 ){
        DeRef(_1);
    }
    _28700 = NOVALUE;

    /** 	entry*/
L3: 

    /** 		n = find(labbel, goto_delay)*/
    _n_56415 = find_from(_labbel_56413, _35goto_delay_16078, 1);

    /** 	end while*/
    goto L4; // [185] 118
L5: 

    /** 	force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_39goto_init_53686);
    Ref(_labbel_56413);
    RefDS(_21815);
    _28702 = _28get(_39goto_init_53686, _labbel_56413, _21815);
    _39force_uninitialize(_28702);
    _28702 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [205] 221
    }
    else{
    }

    /** 		emit_op(GLABEL)*/
    _41emit_op(189);

    /** 		emit_addr(laddr)*/
    _41emit_addr(_laddr_56414);
L6: 

    /** end procedure*/
    DeRef(_tok_56412);
    DeRef(_labbel_56413);
    _28687 = NOVALUE;
    return;
    ;
}


void _39Goto_statement()
{
    int _tok_56462 = NOVALUE;
    int _n_56463 = NOVALUE;
    int _num_labels_56464 = NOVALUE;
    int _31366 = NOVALUE;
    int _28741 = NOVALUE;
    int _28740 = NOVALUE;
    int _28737 = NOVALUE;
    int _28736 = NOVALUE;
    int _28735 = NOVALUE;
    int _28734 = NOVALUE;
    int _28733 = NOVALUE;
    int _28732 = NOVALUE;
    int _28731 = NOVALUE;
    int _28730 = NOVALUE;
    int _28729 = NOVALUE;
    int _28728 = NOVALUE;
    int _28727 = NOVALUE;
    int _28726 = NOVALUE;
    int _28724 = NOVALUE;
    int _28723 = NOVALUE;
    int _28721 = NOVALUE;
    int _28720 = NOVALUE;
    int _28718 = NOVALUE;
    int _28717 = NOVALUE;
    int _28715 = NOVALUE;
    int _28714 = NOVALUE;
    int _28713 = NOVALUE;
    int _28712 = NOVALUE;
    int _28709 = NOVALUE;
    int _28708 = NOVALUE;
    int _28707 = NOVALUE;
    int _28705 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	integer num_labels*/

    /** 	tok = next_token()*/
    _0 = _tok_56462;
    _tok_56462 = _39next_token();
    DeRef(_0);

    /** 	num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_39goto_labels_53680)){
            _num_labels_56464 = SEQ_PTR(_39goto_labels_53680)->length;
    }
    else {
        _num_labels_56464 = 1;
    }

    /** 	if tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56462);
    _28705 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28705, 503)){
        _28705 = NOVALUE;
        goto L1; // [27] 269
    }
    _28705 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (int)SEQ_PTR(_tok_56462);
    _28707 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28707)){
        _28708 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28707)->dbl));
    }
    else{
        _28708 = (int)*(((s1_ptr)_2)->base + _28707);
    }
    _2 = (int)SEQ_PTR(_28708);
    _28709 = (int)*(((s1_ptr)_2)->base + 1);
    _28708 = NOVALUE;
    _n_56463 = find_from(_28709, _39goto_labels_53680, 1);
    _28709 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56463 != 0)
    goto L2; // [60] 243

    /** 			goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (int)SEQ_PTR(_tok_56462);
    _28712 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28712)){
        _28713 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28712)->dbl));
    }
    else{
        _28713 = (int)*(((s1_ptr)_2)->base + _28712);
    }
    _2 = (int)SEQ_PTR(_28713);
    _28714 = (int)*(((s1_ptr)_2)->base + 1);
    _28713 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28714);
    *((int *)(_2+4)) = _28714;
    _28715 = MAKE_SEQ(_1);
    _28714 = NOVALUE;
    Concat((object_ptr)&_35goto_delay_16078, _35goto_delay_16078, _28715);
    DeRefDS(_28715);
    _28715 = NOVALUE;

    /** 			goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28717 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28717 = 1;
    }
    _28718 = _28717 + 2;
    _28717 = NOVALUE;
    Append(&_35goto_list_16079, _35goto_list_16079, _28718);
    _28718 = NOVALUE;

    /** 			goto_line &= {{line_number,ThisLine}}*/
    Ref(_44ThisLine_48142);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35line_number_15969;
    ((int *)_2)[2] = _44ThisLine_48142;
    _28720 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28720;
    _28721 = MAKE_SEQ(_1);
    _28720 = NOVALUE;
    Concat((object_ptr)&_39goto_line_53679, _39goto_line_53679, _28721);
    DeRefDS(_28721);
    _28721 = NOVALUE;

    /** 			goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _28723 = _66top_block(0);
    _31366 = 188;
    _28724 = _38new_forward_reference(188, _28723, 188);
    _28723 = NOVALUE;
    _31366 = NOVALUE;
    if (IS_SEQUENCE(_39goto_ref_53683) && IS_ATOM(_28724)) {
        Ref(_28724);
        Append(&_39goto_ref_53683, _39goto_ref_53683, _28724);
    }
    else if (IS_ATOM(_39goto_ref_53683) && IS_SEQUENCE(_28724)) {
    }
    else {
        Concat((object_ptr)&_39goto_ref_53683, _39goto_ref_53683, _28724);
    }
    DeRef(_28724);
    _28724 = NOVALUE;

    /** 			map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (int)SEQ_PTR(_tok_56462);
    _28726 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28726)){
        _28727 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28726)->dbl));
    }
    else{
        _28727 = (int)*(((s1_ptr)_2)->base + _28726);
    }
    _2 = (int)SEQ_PTR(_28727);
    _28728 = (int)*(((s1_ptr)_2)->base + 1);
    _28727 = NOVALUE;
    _28729 = _39get_private_uninitialized();
    Ref(_39goto_init_53686);
    Ref(_28728);
    _28put(_39goto_init_53686, _28728, _28729, 1, 23);
    _28728 = NOVALUE;
    _28729 = NOVALUE;

    /** 			add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_39goto_ref_53683)){
            _28730 = SEQ_PTR(_39goto_ref_53683)->length;
    }
    else {
        _28730 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_ref_53683);
    _28731 = (int)*(((s1_ptr)_2)->base + _28730);
    _2 = (int)SEQ_PTR(_tok_56462);
    _28732 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28732);
    _28733 = _53sym_obj(_28732);
    _28732 = NOVALUE;
    Ref(_28731);
    _38add_data(_28731, _28733);
    _28731 = NOVALUE;
    _28733 = NOVALUE;

    /** 			set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_39goto_ref_53683)){
            _28734 = SEQ_PTR(_39goto_ref_53683)->length;
    }
    else {
        _28734 = 1;
    }
    _2 = (int)SEQ_PTR(_39goto_ref_53683);
    _28735 = (int)*(((s1_ptr)_2)->base + _28734);
    Ref(_28735);
    Ref(_44ThisLine_48142);
    _38set_line(_28735, _35line_number_15969, _44ThisLine_48142, _44bp_48146);
    _28735 = NOVALUE;
    goto L3; // [240] 261
L2: 

    /** 			Goto_block( top_block(), label_block[n] )*/
    _28736 = _66top_block(0);
    _2 = (int)SEQ_PTR(_39label_block_53684);
    _28737 = (int)*(((s1_ptr)_2)->base + _n_56463);
    Ref(_28737);
    _66Goto_block(_28736, _28737, 0);
    _28736 = NOVALUE;
    _28737 = NOVALUE;
L3: 

    /** 		tok = next_token()*/
    _0 = _tok_56462;
    _tok_56462 = _39next_token();
    DeRef(_0);
    goto L4; // [266] 277
L1: 

    /** 		CompileErr(96)*/
    RefDS(_21815);
    _44CompileErr(96, _21815, 0);
L4: 

    /** 	emit_op(GOTO)*/
    _41emit_op(188);

    /** 	if n = 0 then*/
    if (_n_56463 != 0)
    goto L5; // [288] 300

    /** 		emit_addr(0) -- to be back-patched*/
    _41emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** 		emit_addr(goto_addr[n])*/
    _2 = (int)SEQ_PTR(_39goto_addr_53681);
    _28740 = (int)*(((s1_ptr)_2)->base + _n_56463);
    Ref(_28740);
    _41emit_addr(_28740);
    _28740 = NOVALUE;
L6: 

    /** 	putback(tok)*/
    Ref(_tok_56462);
    _39putback(_tok_56462);

    /** 	NotReached(tok[T_ID], "goto")*/
    _2 = (int)SEQ_PTR(_tok_56462);
    _28741 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28741);
    RefDS(_26052);
    _39NotReached(_28741, _26052);
    _28741 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56462);
    _28707 = NOVALUE;
    _28712 = NOVALUE;
    _28726 = NOVALUE;
    return;
    ;
}


void _39Exit_statement()
{
    int _addr_inlined_AppendXList_at_63_56565 = NOVALUE;
    int _tok_56548 = NOVALUE;
    int _by_ref_56549 = NOVALUE;
    int _28749 = NOVALUE;
    int _28748 = NOVALUE;
    int _28747 = NOVALUE;
    int _28746 = NOVALUE;
    int _28744 = NOVALUE;
    int _28742 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _28742 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _28742 = 1;
    }
    if (_28742 != 0)
    goto L1; // [10] 21
    _28742 = NOVALUE;

    /** 		CompileErr(88)*/
    RefDS(_21815);
    _44CompileErr(88, _21815, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28744 = _39next_token();
    _0 = _by_ref_56549;
    _by_ref_56549 = _39exit_level(_28744, 0);
    DeRef(_0);
    _28744 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56549);
    _28746 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28746);
    _66Leave_blocks(_28746, 1);
    _28746 = NOVALUE;

    /** 	emit_op(EXIT)*/
    _41emit_op(61);

    /** 	AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28747 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28747 = 1;
    }
    _28748 = _28747 + 1;
    _28747 = NOVALUE;
    _addr_inlined_AppendXList_at_63_56565 = _28748;
    _28748 = NOVALUE;

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_39exit_list_53689, _39exit_list_53689, _addr_inlined_AppendXList_at_63_56565);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	exit_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56549);
    _28749 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_39exit_delay_53690) && IS_ATOM(_28749)) {
        Ref(_28749);
        Append(&_39exit_delay_53690, _39exit_delay_53690, _28749);
    }
    else if (IS_ATOM(_39exit_delay_53690) && IS_SEQUENCE(_28749)) {
    }
    else {
        Concat((object_ptr)&_39exit_delay_53690, _39exit_delay_53690, _28749);
    }
    _28749 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56548);
    _2 = (int)SEQ_PTR(_by_ref_56549);
    _tok_56548 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56548);

    /** 	putback(tok)*/
    Ref(_tok_56548);
    _39putback(_tok_56548);

    /** end procedure*/
    DeRef(_tok_56548);
    DeRefDS(_by_ref_56549);
    return;
    ;
}


void _39Continue_statement()
{
    int _addr_inlined_AppendNList_at_149_56609 = NOVALUE;
    int _tok_56572 = NOVALUE;
    int _by_ref_56573 = NOVALUE;
    int _loop_level_56574 = NOVALUE;
    int _28775 = NOVALUE;
    int _28772 = NOVALUE;
    int _28771 = NOVALUE;
    int _28770 = NOVALUE;
    int _28769 = NOVALUE;
    int _28768 = NOVALUE;
    int _28767 = NOVALUE;
    int _28765 = NOVALUE;
    int _28764 = NOVALUE;
    int _28763 = NOVALUE;
    int _28762 = NOVALUE;
    int _28761 = NOVALUE;
    int _28760 = NOVALUE;
    int _28759 = NOVALUE;
    int _28758 = NOVALUE;
    int _28756 = NOVALUE;
    int _28754 = NOVALUE;
    int _28752 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	integer loop_level*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _28752 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _28752 = 1;
    }
    if (_28752 != 0)
    goto L1; // [12] 23
    _28752 = NOVALUE;

    /** 		CompileErr(49)*/
    RefDS(_21815);
    _44CompileErr(49, _21815, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28754 = _39next_token();
    _0 = _by_ref_56573;
    _by_ref_56573 = _39exit_level(_28754, 0);
    DeRef(_0);
    _28754 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56573);
    _28756 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28756);
    _66Leave_blocks(_28756, 1);
    _28756 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _41emit_op(23);

    /** 	loop_level = by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56573);
    _loop_level_56574 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_56574))
    _loop_level_56574 = (long)DBL_PTR(_loop_level_56574)->dbl;

    /** 	if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_39continue_addr_53694)){
            _28758 = SEQ_PTR(_39continue_addr_53694)->length;
    }
    else {
        _28758 = 1;
    }
    _28759 = _28758 + 1;
    _28758 = NOVALUE;
    _28760 = _28759 - _loop_level_56574;
    _28759 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_53694);
    _28761 = (int)*(((s1_ptr)_2)->base + _28760);
    if (_28761 == 0)
    {
        _28761 = NOVALUE;
        goto L2; // [79] 138
    }
    else{
        _28761 = NOVALUE;
    }

    /** 		if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_39continue_addr_53694)){
            _28762 = SEQ_PTR(_39continue_addr_53694)->length;
    }
    else {
        _28762 = 1;
    }
    _28763 = _28762 + 1;
    _28762 = NOVALUE;
    _28764 = _28763 - _loop_level_56574;
    _28763 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_53694);
    _28765 = (int)*(((s1_ptr)_2)->base + _28764);
    if (_28765 >= 0)
    goto L3; // [101] 113

    /** 			CompileErr(49)*/
    RefDS(_21815);
    _44CompileErr(49, _21815, 0);
L3: 

    /** 		emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_39continue_addr_53694)){
            _28767 = SEQ_PTR(_39continue_addr_53694)->length;
    }
    else {
        _28767 = 1;
    }
    _28768 = _28767 + 1;
    _28767 = NOVALUE;
    _28769 = _28768 - _loop_level_56574;
    _28768 = NOVALUE;
    _2 = (int)SEQ_PTR(_39continue_addr_53694);
    _28770 = (int)*(((s1_ptr)_2)->base + _28769);
    _41emit_addr(_28770);
    _28770 = NOVALUE;
    goto L4; // [135] 182
L2: 

    /** 		AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28771 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28771 = 1;
    }
    _28772 = _28771 + 1;
    _28771 = NOVALUE;
    _addr_inlined_AppendNList_at_149_56609 = _28772;
    _28772 = NOVALUE;

    /** 	continue_list = append(continue_list, addr)*/
    Append(&_39continue_list_53691, _39continue_list_53691, _addr_inlined_AppendNList_at_149_56609);

    /** end procedure*/
    goto L5; // [164] 167
L5: 

    /** 		continue_delay &= loop_level*/
    Append(&_39continue_delay_53692, _39continue_delay_53692, _loop_level_56574);

    /** 		emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();
L4: 

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56572);
    _2 = (int)SEQ_PTR(_by_ref_56573);
    _tok_56572 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56572);

    /** 	putback(tok)*/
    Ref(_tok_56572);
    _39putback(_tok_56572);

    /** 	NotReached(tok[T_ID], "continue")*/
    _2 = (int)SEQ_PTR(_tok_56572);
    _28775 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28775);
    RefDS(_26014);
    _39NotReached(_28775, _26014);
    _28775 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56572);
    DeRefDS(_by_ref_56573);
    _28765 = NOVALUE;
    DeRef(_28760);
    _28760 = NOVALUE;
    DeRef(_28764);
    _28764 = NOVALUE;
    DeRef(_28769);
    _28769 = NOVALUE;
    return;
    ;
}


void _39Retry_statement()
{
    int _by_ref_56616 = NOVALUE;
    int _tok_56618 = NOVALUE;
    int _28799 = NOVALUE;
    int _28797 = NOVALUE;
    int _28796 = NOVALUE;
    int _28795 = NOVALUE;
    int _28794 = NOVALUE;
    int _28793 = NOVALUE;
    int _28791 = NOVALUE;
    int _28790 = NOVALUE;
    int _28789 = NOVALUE;
    int _28788 = NOVALUE;
    int _28787 = NOVALUE;
    int _28785 = NOVALUE;
    int _28784 = NOVALUE;
    int _28783 = NOVALUE;
    int _28782 = NOVALUE;
    int _28781 = NOVALUE;
    int _28780 = NOVALUE;
    int _28778 = NOVALUE;
    int _28776 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _28776 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _28776 = 1;
    }
    if (_28776 != 0)
    goto L1; // [8] 19
    _28776 = NOVALUE;

    /** 		CompileErr(131)*/
    RefDS(_21815);
    _44CompileErr(131, _21815, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28778 = _39next_token();
    _0 = _by_ref_56616;
    _by_ref_56616 = _39exit_level(_28778, 0);
    DeRef(_0);
    _28778 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56616);
    _28780 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28780);
    _66Leave_blocks(_28780, 1);
    _28780 = NOVALUE;

    /** 	if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _28781 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _28781 = 1;
    }
    _28782 = _28781 + 1;
    _28781 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56616);
    _28783 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28783)) {
        _28784 = _28782 - _28783;
    }
    else {
        _28784 = binary_op(MINUS, _28782, _28783);
    }
    _28782 = NOVALUE;
    _28783 = NOVALUE;
    _2 = (int)SEQ_PTR(_39loop_stack_53703);
    if (!IS_ATOM_INT(_28784)){
        _28785 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28784)->dbl));
    }
    else{
        _28785 = (int)*(((s1_ptr)_2)->base + _28784);
    }
    if (_28785 != 21)
    goto L2; // [68] 82

    /** 		emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _41emit_op(184);
    goto L3; // [79] 125
L2: 

    /** 		if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_39retry_addr_53695)){
            _28787 = SEQ_PTR(_39retry_addr_53695)->length;
    }
    else {
        _28787 = 1;
    }
    _28788 = _28787 + 1;
    _28787 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56616);
    _28789 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28789)) {
        _28790 = _28788 - _28789;
    }
    else {
        _28790 = binary_op(MINUS, _28788, _28789);
    }
    _28788 = NOVALUE;
    _28789 = NOVALUE;
    _2 = (int)SEQ_PTR(_39retry_addr_53695);
    if (!IS_ATOM_INT(_28790)){
        _28791 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28790)->dbl));
    }
    else{
        _28791 = (int)*(((s1_ptr)_2)->base + _28790);
    }
    if (_28791 >= 0)
    goto L4; // [105] 117

    /** 			CompileErr(131)*/
    RefDS(_21815);
    _44CompileErr(131, _21815, 0);
L4: 

    /** 		emit_op(ELSE)*/
    _41emit_op(23);
L3: 

    /** 	emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_39retry_addr_53695)){
            _28793 = SEQ_PTR(_39retry_addr_53695)->length;
    }
    else {
        _28793 = 1;
    }
    _28794 = _28793 + 1;
    _28793 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56616);
    _28795 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28795)) {
        _28796 = _28794 - _28795;
    }
    else {
        _28796 = binary_op(MINUS, _28794, _28795);
    }
    _28794 = NOVALUE;
    _28795 = NOVALUE;
    _2 = (int)SEQ_PTR(_39retry_addr_53695);
    if (!IS_ATOM_INT(_28796)){
        _28797 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28796)->dbl));
    }
    else{
        _28797 = (int)*(((s1_ptr)_2)->base + _28796);
    }
    _41emit_addr(_28797);
    _28797 = NOVALUE;

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56618);
    _2 = (int)SEQ_PTR(_by_ref_56616);
    _tok_56618 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56618);

    /** 	putback(tok)*/
    Ref(_tok_56618);
    _39putback(_tok_56618);

    /** 	NotReached(tok[T_ID], "retry")*/
    _2 = (int)SEQ_PTR(_tok_56618);
    _28799 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28799);
    RefDS(_26108);
    _39NotReached(_28799, _26108);
    _28799 = NOVALUE;

    /** end procedure*/
    DeRefDS(_by_ref_56616);
    DeRef(_tok_56618);
    _28785 = NOVALUE;
    _28791 = NOVALUE;
    DeRef(_28784);
    _28784 = NOVALUE;
    DeRef(_28790);
    _28790 = NOVALUE;
    DeRef(_28796);
    _28796 = NOVALUE;
    return;
    ;
}


int _39in_switch()
{
    int _28804 = NOVALUE;
    int _28803 = NOVALUE;
    int _28802 = NOVALUE;
    int _28801 = NOVALUE;
    int _28800 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _28800 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _28800 = 1;
    }
    if (_28800 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_39if_stack_53704)){
            _28802 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _28802 = 1;
    }
    _2 = (int)SEQ_PTR(_39if_stack_53704);
    _28803 = (int)*(((s1_ptr)_2)->base + _28802);
    _28804 = (_28803 == 185);
    _28803 = NOVALUE;
    if (_28804 == 0)
    {
        DeRef(_28804);
        _28804 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_28804);
        _28804 = NOVALUE;
    }

    /** 		return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** 		return 0*/
    return 0;
L2: 
    ;
}


void _39Break_statement()
{
    int _addr_inlined_AppendEList_at_63_56688 = NOVALUE;
    int _tok_56671 = NOVALUE;
    int _by_ref_56672 = NOVALUE;
    int _28815 = NOVALUE;
    int _28812 = NOVALUE;
    int _28811 = NOVALUE;
    int _28810 = NOVALUE;
    int _28809 = NOVALUE;
    int _28807 = NOVALUE;
    int _28805 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(if_labels) then*/
    if (IS_SEQUENCE(_39if_labels_53698)){
            _28805 = SEQ_PTR(_39if_labels_53698)->length;
    }
    else {
        _28805 = 1;
    }
    if (_28805 != 0)
    goto L1; // [10] 21
    _28805 = NOVALUE;

    /** 		CompileErr(40)*/
    RefDS(_21815);
    _44CompileErr(40, _21815, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),1)*/
    _28807 = _39next_token();
    _0 = _by_ref_56672;
    _by_ref_56672 = _39exit_level(_28807, 1);
    DeRef(_0);
    _28807 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56672);
    _28809 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28809);
    _66Leave_blocks(_28809, 2);
    _28809 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _41emit_op(23);

    /** 	AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28810 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28810 = 1;
    }
    _28811 = _28810 + 1;
    _28810 = NOVALUE;
    _addr_inlined_AppendEList_at_63_56688 = _28811;
    _28811 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_53687, _39break_list_53687, _addr_inlined_AppendEList_at_63_56688);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	break_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56672);
    _28812 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_39break_delay_53688) && IS_ATOM(_28812)) {
        Ref(_28812);
        Append(&_39break_delay_53688, _39break_delay_53688, _28812);
    }
    else if (IS_ATOM(_39break_delay_53688) && IS_SEQUENCE(_28812)) {
    }
    else {
        Concat((object_ptr)&_39break_delay_53688, _39break_delay_53688, _28812);
    }
    _28812 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _39emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56671);
    _2 = (int)SEQ_PTR(_by_ref_56672);
    _tok_56671 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56671);

    /** 	putback(tok)*/
    Ref(_tok_56671);
    _39putback(_tok_56671);

    /** 	NotReached(tok[T_ID], "break")*/
    _2 = (int)SEQ_PTR(_tok_56671);
    _28815 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28815);
    RefDS(_25998);
    _39NotReached(_28815, _25998);
    _28815 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56671);
    DeRefDS(_by_ref_56672);
    return;
    ;
}


int _39finish_block_header(int _opcode_56697)
{
    int _tok_56699 = NOVALUE;
    int _labbel_56700 = NOVALUE;
    int _has_entry_56701 = NOVALUE;
    int _28869 = NOVALUE;
    int _28868 = NOVALUE;
    int _28867 = NOVALUE;
    int _28866 = NOVALUE;
    int _28863 = NOVALUE;
    int _28858 = NOVALUE;
    int _28855 = NOVALUE;
    int _28853 = NOVALUE;
    int _28850 = NOVALUE;
    int _28849 = NOVALUE;
    int _28847 = NOVALUE;
    int _28844 = NOVALUE;
    int _28841 = NOVALUE;
    int _28840 = NOVALUE;
    int _28838 = NOVALUE;
    int _28836 = NOVALUE;
    int _28833 = NOVALUE;
    int _28830 = NOVALUE;
    int _28829 = NOVALUE;
    int _28827 = NOVALUE;
    int _28825 = NOVALUE;
    int _28824 = NOVALUE;
    int _28823 = NOVALUE;
    int _28820 = NOVALUE;
    int _28817 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	object labbel*/

    /** 	integer has_entry*/

    /** 	tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);

    /** 	has_entry=0*/
    _has_entry_56701 = 0;

    /** 	if tok[T_ID] = WITH then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28817 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28817, 420)){
        _28817 = NOVALUE;
        goto L1; // [27] 154
    }
    _28817 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);

    /** 		switch tok[T_ID] do*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28820 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_28820) ){
        goto L2; // [44] 136
    }
    if(!IS_ATOM_INT(_28820)){
        if( (DBL_PTR(_28820)->dbl != (double) ((int) DBL_PTR(_28820)->dbl) ) ){
            goto L2; // [44] 136
        }
        _0 = (int) DBL_PTR(_28820)->dbl;
    }
    else {
        _0 = _28820;
    };
    _28820 = NOVALUE;
    switch ( _0 ){ 

        /** 		    case ENTRY then*/
        case 424:

        /** 				if not (opcode = WHILE or opcode = LOOP) then*/
        _28823 = (_opcode_56697 == 47);
        if (_28823 != 0) {
            DeRef(_28824);
            _28824 = 1;
            goto L3; // [61] 75
        }
        _28825 = (_opcode_56697 == 422);
        _28824 = (_28825 != 0);
L3: 
        if (_28824 != 0)
        goto L4; // [75] 86
        _28824 = NOVALUE;

        /** 					CompileErr(14)*/
        RefDS(_21815);
        _44CompileErr(14, _21815, 0);
L4: 

        /** 			    has_entry = 1*/
        _has_entry_56701 = 1;
        goto L5; // [91] 146

        /** 			case FALLTHRU then*/
        case 431:

        /** 				if not opcode = SWITCH then*/
        _28827 = (_opcode_56697 == 0);
        if (_28827 != 185)
        goto L6; // [104] 116

        /** 					CompileErr(13)*/
        RefDS(_21815);
        _44CompileErr(13, _21815, 0);
L6: 

        /** 				switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_39switch_stack_53904)){
                _28829 = SEQ_PTR(_39switch_stack_53904)->length;
        }
        else {
            _28829 = 1;
        }
        _2 = (int)SEQ_PTR(_39switch_stack_53904);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _39switch_stack_53904 = MAKE_SEQ(_2);
        }
        _3 = (int)(_28829 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);
        _28830 = NOVALUE;
        goto L5; // [132] 146

        /** 			case else*/
        default:
L2: 

        /** 			    CompileErr(27)*/
        RefDS(_21815);
        _44CompileErr(27, _21815, 0);
    ;}L5: 

    /**         tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);
    goto L7; // [151] 240
L1: 

    /** 	elsif tok[T_ID] = WITHOUT then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28833 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28833, 421)){
        _28833 = NOVALUE;
        goto L8; // [164] 239
    }
    _28833 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = FALLTHRU then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28836 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28836, 431)){
        _28836 = NOVALUE;
        goto L9; // [183] 225
    }
    _28836 = NOVALUE;

    /** 			if not opcode = SWITCH then*/
    _28838 = (_opcode_56697 == 0);
    if (_28838 != 185)
    goto LA; // [194] 206

    /** 				CompileErr(15)*/
    RefDS(_21815);
    _44CompileErr(15, _21815, 0);
LA: 

    /** 			switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28840 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28840 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28840 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _28841 = NOVALUE;
    goto LB; // [222] 233
L9: 

    /** 			CompileErr(27)*/
    RefDS(_21815);
    _44CompileErr(27, _21815, 0);
LB: 

    /**         tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);
L8: 
L7: 

    /** 	labbel=0*/
    DeRef(_labbel_56700);
    _labbel_56700 = 0;

    /** 	if tok[T_ID]=LABEL then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28844 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28844, 419)){
        _28844 = NOVALUE;
        goto LC; // [255] 317
    }
    _28844 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28847 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28847, 503)){
        _28847 = NOVALUE;
        goto LD; // [274] 286
    }
    _28847 = NOVALUE;

    /** 			CompileErr(38)*/
    RefDS(_21815);
    _44CompileErr(38, _21815, 0);
LD: 

    /** 		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28849 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_28849)){
        _28850 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28849)->dbl));
    }
    else{
        _28850 = (int)*(((s1_ptr)_2)->base + _28849);
    }
    DeRef(_labbel_56700);
    _2 = (int)SEQ_PTR(_28850);
    _labbel_56700 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56700);
    _28850 = NOVALUE;

    /** 		block_label( labbel )*/
    Ref(_labbel_56700);
    _66block_label(_labbel_56700);

    /** 		tok = next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);
LC: 

    /** 	if opcode = IF or opcode = SWITCH then*/
    _28853 = (_opcode_56697 == 20);
    if (_28853 != 0) {
        goto LE; // [325] 340
    }
    _28855 = (_opcode_56697 == 185);
    if (_28855 == 0)
    {
        DeRef(_28855);
        _28855 = NOVALUE;
        goto LF; // [336] 351
    }
    else{
        DeRef(_28855);
        _28855 = NOVALUE;
    }
LE: 

    /** 		if_labels = append(if_labels,labbel)*/
    Ref(_labbel_56700);
    Append(&_39if_labels_53698, _39if_labels_53698, _labbel_56700);
    goto L10; // [348] 360
LF: 

    /** 		loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_56700);
    Append(&_39loop_labels_53697, _39loop_labels_53697, _labbel_56700);
L10: 

    /** 	if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_39block_list_53699)){
            _28858 = SEQ_PTR(_39block_list_53699)->length;
    }
    else {
        _28858 = 1;
    }
    if (_39block_index_53700 != _28858)
    goto L11; // [369] 392

    /** 	    block_list &= opcode*/
    Append(&_39block_list_53699, _39block_list_53699, _opcode_56697);

    /** 	    block_index += 1*/
    _39block_index_53700 = _39block_index_53700 + 1;
    goto L12; // [389] 411
L11: 

    /** 	    block_index += 1*/
    _39block_index_53700 = _39block_index_53700 + 1;

    /** 	    block_list[block_index] = opcode*/
    _2 = (int)SEQ_PTR(_39block_list_53699);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39block_list_53699 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _39block_index_53700);
    *(int *)_2 = _opcode_56697;
L12: 

    /** 	if tok[T_ID]=ENTRY then*/
    _2 = (int)SEQ_PTR(_tok_56699);
    _28863 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28863, 424)){
        _28863 = NOVALUE;
        goto L13; // [421] 449
    }
    _28863 = NOVALUE;

    /** 	    if has_entry then*/
    if (_has_entry_56701 == 0)
    {
        goto L14; // [427] 438
    }
    else{
    }

    /** 	        CompileErr(64)*/
    RefDS(_21815);
    _44CompileErr(64, _21815, 0);
L14: 

    /** 	    has_entry=1*/
    _has_entry_56701 = 1;

    /** 	    tok=next_token()*/
    _0 = _tok_56699;
    _tok_56699 = _39next_token();
    DeRef(_0);
L13: 

    /** 	if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_56701 == 0) {
        goto L15; // [451] 487
    }
    _28867 = (_opcode_56697 == 20);
    if (_28867 != 0) {
        DeRef(_28868);
        _28868 = 1;
        goto L16; // [461] 475
    }
    _28869 = (_opcode_56697 == 185);
    _28868 = (_28869 != 0);
L16: 
    if (_28868 == 0)
    {
        _28868 = NOVALUE;
        goto L15; // [476] 487
    }
    else{
        _28868 = NOVALUE;
    }

    /** 		CompileErr(80)*/
    RefDS(_21815);
    _44CompileErr(80, _21815, 0);
L15: 

    /** 	if opcode = IF then*/
    if (_opcode_56697 != 20)
    goto L17; // [491] 507

    /** 		opcode = THEN*/
    _opcode_56697 = 410;
    goto L18; // [504] 517
L17: 

    /** 		opcode = DO*/
    _opcode_56697 = 411;
L18: 

    /** 	putback(tok)*/
    Ref(_tok_56699);
    _39putback(_tok_56699);

    /** 	tok_match(opcode)*/
    _39tok_match(_opcode_56697, 0);

    /** 	return has_entry*/
    DeRef(_tok_56699);
    DeRef(_labbel_56700);
    DeRef(_28823);
    _28823 = NOVALUE;
    DeRef(_28825);
    _28825 = NOVALUE;
    DeRef(_28827);
    _28827 = NOVALUE;
    DeRef(_28838);
    _28838 = NOVALUE;
    _28849 = NOVALUE;
    DeRef(_28853);
    _28853 = NOVALUE;
    DeRef(_28867);
    _28867 = NOVALUE;
    DeRef(_28869);
    _28869 = NOVALUE;
    return _has_entry_56701;
    ;
}


void _39If_statement()
{
    int _addr_inlined_AppendEList_at_624_56947 = NOVALUE;
    int _addr_inlined_AppendEList_at_260_56876 = NOVALUE;
    int _tok_56819 = NOVALUE;
    int _prev_false_56820 = NOVALUE;
    int _prev_false2_56821 = NOVALUE;
    int _elist_base_56822 = NOVALUE;
    int _temps_56830 = NOVALUE;
    int _31365 = NOVALUE;
    int _28935 = NOVALUE;
    int _28934 = NOVALUE;
    int _28931 = NOVALUE;
    int _28930 = NOVALUE;
    int _28928 = NOVALUE;
    int _28927 = NOVALUE;
    int _28926 = NOVALUE;
    int _28924 = NOVALUE;
    int _28923 = NOVALUE;
    int _28921 = NOVALUE;
    int _28920 = NOVALUE;
    int _28919 = NOVALUE;
    int _28917 = NOVALUE;
    int _28916 = NOVALUE;
    int _28914 = NOVALUE;
    int _28913 = NOVALUE;
    int _28912 = NOVALUE;
    int _28911 = NOVALUE;
    int _28909 = NOVALUE;
    int _28908 = NOVALUE;
    int _28905 = NOVALUE;
    int _28903 = NOVALUE;
    int _28902 = NOVALUE;
    int _28901 = NOVALUE;
    int _28898 = NOVALUE;
    int _28895 = NOVALUE;
    int _28894 = NOVALUE;
    int _28892 = NOVALUE;
    int _28891 = NOVALUE;
    int _28889 = NOVALUE;
    int _28888 = NOVALUE;
    int _28886 = NOVALUE;
    int _28883 = NOVALUE;
    int _28881 = NOVALUE;
    int _28880 = NOVALUE;
    int _28879 = NOVALUE;
    int _28875 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer prev_false*/

    /** 	integer prev_false2*/

    /** 	integer elist_base*/

    /** 	if_stack &= IF*/
    Append(&_39if_stack_53704, _39if_stack_53704, 20);

    /** 	Start_block( IF )*/
    _66Start_block(20, 0);

    /** 	elist_base = length(break_list)*/
    if (IS_SEQUENCE(_39break_list_53687)){
            _elist_base_56822 = SEQ_PTR(_39break_list_53687)->length;
    }
    else {
        _elist_base_56822 = 1;
    }

    /** 	short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_53671 = _13FALSE_435;

    /** 	SC1_type = 0*/
    _39SC1_type_53674 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	sequence temps = get_temps()*/
    _31365 = Repeat(_21815, 2);
    _0 = _temps_56830;
    _temps_56830 = _41get_temps(_31365);
    DeRef(_0);
    _31365 = NOVALUE;

    /** 	emit_op(IF)*/
    _41emit_op(20);

    /** 	prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28875 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28875 = 1;
    }
    _prev_false_56820 = _28875 + 1;
    _28875 = NOVALUE;

    /** 	emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 	prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_56821 = _39finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_56821)) {
        _1 = (long)(DBL_PTR(_prev_false2_56821)->dbl);
        DeRefDS(_prev_false2_56821);
        _prev_false2_56821 = _1;
    }

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_53674 != 9)
    goto L1; // [106] 159

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _28879 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_28879 +(unsigned long) HIGH_BITS) >= 0){
        _28879 = NewDouble((double)_28879);
    }
    _41backpatch(_28879, 147);
    _28879 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** 			emit_op(NOP1)  -- to get label here*/
    _41emit_op(159);
L2: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28880 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28880 = 1;
    }
    _28881 = _28880 + 1;
    _28880 = NOVALUE;
    _41backpatch(_39SC1_patch_53673, _28881);
    _28881 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_53674 != 8)
    goto L4; // [165] 191

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _28883 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_28883 +(unsigned long) HIGH_BITS) >= 0){
        _28883 = NewDouble((double)_28883);
    }
    _41backpatch(_28883, 146);
    _28883 = NOVALUE;

    /** 		prev_false2 = SC1_patch*/
    _prev_false2_56821 = _39SC1_patch_53673;
L4: 
L3: 

    /** 	short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	tok = next_token()*/
    _0 = _tok_56819;
    _tok_56819 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (int)SEQ_PTR(_tok_56819);
    _28886 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28886, 414)){
        _28886 = NOVALUE;
        goto L6; // [222] 530
    }
    _28886 = NOVALUE;

    /** 		Sibling_block( IF )*/
    _66Sibling_block(20);

    /** 		emit_op(ELSE)*/
    _41emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28888 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28888 = 1;
    }
    _28889 = _28888 + 1;
    _28888 = NOVALUE;
    _addr_inlined_AppendEList_at_260_56876 = _28889;
    _28889 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_53687, _39break_list_53687, _addr_inlined_AppendEList_at_260_56876);

    /** end procedure*/
    goto L7; // [266] 269
L7: 

    /** 		break_delay &= 1*/
    Append(&_39break_delay_53688, _39break_delay_53688, 1);

    /** 		emit_forward_addr()  -- to be patched*/
    _39emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L8: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28891 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28891 = 1;
    }
    _28892 = _28891 + 1;
    _28891 = NOVALUE;
    _41backpatch(_prev_false_56820, _28892);
    _28892 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56821 == 0)
    goto L9; // [315] 335

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28894 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28894 = 1;
    }
    _28895 = _28894 + 1;
    _28894 = NOVALUE;
    _41backpatch(_prev_false2_56821, _28895);
    _28895 = NOVALUE;
L9: 

    /** 		StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 		short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** 		short_circuit_B = FALSE*/
    _39short_circuit_B_53671 = _13FALSE_435;

    /** 		SC1_type = 0*/
    _39SC1_type_53674 = 0;

    /** 		push_temps( temps )*/
    RefDS(_temps_56830);
    _41push_temps(_temps_56830);

    /** 		Expr()*/
    _39Expr();

    /** 		temps = get_temps( temps )*/
    RefDS(_temps_56830);
    _0 = _temps_56830;
    _temps_56830 = _41get_temps(_temps_56830);
    DeRefDS(_0);

    /** 		emit_op(IF)*/
    _41emit_op(20);

    /** 		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28898 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28898 = 1;
    }
    _prev_false_56820 = _28898 + 1;
    _28898 = NOVALUE;

    /** 		prev_false2 = 0*/
    _prev_false2_56821 = 0;

    /** 		emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 		if SC1_type = OR then*/
    if (_39SC1_type_53674 != 9)
    goto LA; // [414] 467

    /** 			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _28901 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_28901 +(unsigned long) HIGH_BITS) >= 0){
        _28901 = NewDouble((double)_28901);
    }
    _41backpatch(_28901, 147);
    _28901 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** 				emit_op(NOP1)*/
    _41emit_op(159);
LB: 

    /** 			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28902 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28902 = 1;
    }
    _28903 = _28902 + 1;
    _28902 = NOVALUE;
    _41backpatch(_39SC1_patch_53673, _28903);
    _28903 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** 		elsif SC1_type = AND then*/
    if (_39SC1_type_53674 != 8)
    goto LD; // [473] 499

    /** 			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _28905 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_28905 +(unsigned long) HIGH_BITS) >= 0){
        _28905 = NewDouble((double)_28905);
    }
    _41backpatch(_28905, 146);
    _28905 = NOVALUE;

    /** 			prev_false2 = SC1_patch*/
    _prev_false2_56821 = _39SC1_patch_53673;
LD: 
LC: 

    /** 		short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 		tok_match(THEN)*/
    _39tok_match(410, 0);

    /** 		Statement_list()*/
    _39Statement_list();

    /** 		tok = next_token()*/
    _0 = _tok_56819;
    _tok_56819 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L5; // [527] 214
L6: 

    /** 	if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (int)SEQ_PTR(_tok_56819);
    _28908 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28908)) {
        _28909 = (_28908 == 23);
    }
    else {
        _28909 = binary_op(EQUALS, _28908, 23);
    }
    _28908 = NOVALUE;
    if (IS_ATOM_INT(_28909)) {
        if (_28909 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_28909)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (int)SEQ_PTR(_temps_56830);
    _28911 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_28911)){
            _28912 = SEQ_PTR(_28911)->length;
    }
    else {
        _28912 = 1;
    }
    _28911 = NOVALUE;
    if (_28912 == 0)
    {
        _28912 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _28912 = NOVALUE;
    }
LE: 

    /** 		Sibling_block( IF )*/
    _66Sibling_block(20);

    /** 		StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13FALSE_435, 0, 1);

    /** 		emit_op(ELSE)*/
    _41emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28913 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28913 = 1;
    }
    _28914 = _28913 + 1;
    _28913 = NOVALUE;
    _addr_inlined_AppendEList_at_624_56947 = _28914;
    _28914 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_39break_list_53687, _39break_list_53687, _addr_inlined_AppendEList_at_624_56947);

    /** end procedure*/
    goto L10; // [611] 614
L10: 

    /** 		break_delay &= 1*/
    Append(&_39break_delay_53688, _39break_delay_53688, 1);

    /** 		emit_forward_addr() -- to be patched*/
    _39emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L11: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28916 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28916 = 1;
    }
    _28917 = _28916 + 1;
    _28916 = NOVALUE;
    _41backpatch(_prev_false_56820, _28917);
    _28917 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56821 == 0)
    goto L12; // [660] 680

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28919 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28919 = 1;
    }
    _28920 = _28919 + 1;
    _28919 = NOVALUE;
    _41backpatch(_prev_false2_56821, _28920);
    _28920 = NOVALUE;
L12: 

    /** 		push_temps( temps )*/
    RefDS(_temps_56830);
    _41push_temps(_temps_56830);

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_56819);
    _28921 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28921, 23)){
        _28921 = NOVALUE;
        goto L13; // [695] 706
    }
    _28921 = NOVALUE;

    /** 			Statement_list()*/
    _39Statement_list();
    goto L14; // [703] 773
L13: 

    /** 			putback(tok)*/
    Ref(_tok_56819);
    _39putback(_tok_56819);
    goto L14; // [712] 773
LF: 

    /** 		putback(tok)*/
    Ref(_tok_56819);
    _39putback(_tok_56819);

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L15: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28923 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28923 = 1;
    }
    _28924 = _28923 + 1;
    _28923 = NOVALUE;
    _41backpatch(_prev_false_56820, _28924);
    _28924 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56821 == 0)
    goto L16; // [752] 772

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _28926 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28926 = 1;
    }
    _28927 = _28926 + 1;
    _28926 = NOVALUE;
    _41backpatch(_prev_false2_56821, _28927);
    _28927 = NOVALUE;
L16: 
L14: 

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(IF, END)*/
    _39tok_match(20, 402);

    /** 	End_block( IF )*/
    _66End_block(20);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** 		if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_39break_list_53687)){
            _28928 = SEQ_PTR(_39break_list_53687)->length;
    }
    else {
        _28928 = 1;
    }
    if (_28928 <= _elist_base_56822)
    goto L18; // [812] 824

    /** 			emit_op(NOP1)  -- to emit label here*/
    _41emit_op(159);
L18: 
L17: 

    /** 	PatchEList(elist_base)*/
    _39PatchEList(_elist_base_56822);

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_39if_labels_53698)){
            _28930 = SEQ_PTR(_39if_labels_53698)->length;
    }
    else {
        _28930 = 1;
    }
    _28931 = _28930 - 1;
    _28930 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_labels_53698;
    RHS_Slice(_39if_labels_53698, 1, _28931);

    /** 	block_index -= 1*/
    _39block_index_53700 = _39block_index_53700 - 1;

    /** 	if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _28934 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _28934 = 1;
    }
    _28935 = _28934 - 1;
    _28934 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_stack_53704;
    RHS_Slice(_39if_stack_53704, 1, _28935);

    /** end procedure*/
    DeRef(_tok_56819);
    DeRef(_temps_56830);
    _28911 = NOVALUE;
    DeRef(_28909);
    _28909 = NOVALUE;
    _28931 = NOVALUE;
    _28935 = NOVALUE;
    return;
    ;
}


void _39exit_loop(int _exit_base_57007)
{
    int _28950 = NOVALUE;
    int _28949 = NOVALUE;
    int _28947 = NOVALUE;
    int _28946 = NOVALUE;
    int _28944 = NOVALUE;
    int _28943 = NOVALUE;
    int _28941 = NOVALUE;
    int _28940 = NOVALUE;
    int _28938 = NOVALUE;
    int _28937 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchXList(exit_base)*/
    _39PatchXList(_exit_base_57007);

    /** 	loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_39loop_labels_53697)){
            _28937 = SEQ_PTR(_39loop_labels_53697)->length;
    }
    else {
        _28937 = 1;
    }
    _28938 = _28937 - 1;
    _28937 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39loop_labels_53697;
    RHS_Slice(_39loop_labels_53697, 1, _28938);

    /** 	loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _28940 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _28940 = 1;
    }
    _28941 = _28940 - 1;
    _28940 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39loop_stack_53703;
    RHS_Slice(_39loop_stack_53703, 1, _28941);

    /** 	continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_39continue_addr_53694)){
            _28943 = SEQ_PTR(_39continue_addr_53694)->length;
    }
    else {
        _28943 = 1;
    }
    _28944 = _28943 - 1;
    _28943 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39continue_addr_53694;
    RHS_Slice(_39continue_addr_53694, 1, _28944);

    /** 	retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_39retry_addr_53695)){
            _28946 = SEQ_PTR(_39retry_addr_53695)->length;
    }
    else {
        _28946 = 1;
    }
    _28947 = _28946 - 1;
    _28946 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39retry_addr_53695;
    RHS_Slice(_39retry_addr_53695, 1, _28947);

    /** 	entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_39entry_addr_53693)){
            _28949 = SEQ_PTR(_39entry_addr_53693)->length;
    }
    else {
        _28949 = 1;
    }
    _28950 = _28949 - 1;
    _28949 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39entry_addr_53693;
    RHS_Slice(_39entry_addr_53693, 1, _28950);

    /** 	block_index -= 1*/
    _39block_index_53700 = _39block_index_53700 - 1;

    /** end procedure*/
    _28938 = NOVALUE;
    _28941 = NOVALUE;
    _28944 = NOVALUE;
    _28947 = NOVALUE;
    _28950 = NOVALUE;
    return;
    ;
}


void _39push_switch()
{
    int _28954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if_stack &= SWITCH*/
    Append(&_39if_stack_53704, _39if_stack_53704, 185);

    /** 	switch_stack = append( switch_stack, { {}, {}, 0, 0, 0, 0 })*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_21815, 2);
    *((int *)(_2+4)) = _21815;
    *((int *)(_2+8)) = _21815;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _28954 = MAKE_SEQ(_1);
    RefDS(_28954);
    Append(&_39switch_stack_53904, _39switch_stack_53904, _28954);
    DeRefDS(_28954);
    _28954 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39pop_switch(int _break_base_57032)
{
    int _28969 = NOVALUE;
    int _28968 = NOVALUE;
    int _28966 = NOVALUE;
    int _28965 = NOVALUE;
    int _28963 = NOVALUE;
    int _28962 = NOVALUE;
    int _28960 = NOVALUE;
    int _28959 = NOVALUE;
    int _28958 = NOVALUE;
    int _28957 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchEList( break_base )*/
    _39PatchEList(_break_base_57032);

    /** 	block_index -= 1*/
    _39block_index_53700 = _39block_index_53700 - 1;

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28957 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28957 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _28958 = (int)*(((s1_ptr)_2)->base + _28957);
    _2 = (int)SEQ_PTR(_28958);
    _28959 = (int)*(((s1_ptr)_2)->base + 1);
    _28958 = NOVALUE;
    if (IS_SEQUENCE(_28959)){
            _28960 = SEQ_PTR(_28959)->length;
    }
    else {
        _28960 = 1;
    }
    _28959 = NOVALUE;
    if (_28960 <= 0)
    goto L1; // [34] 46

    /** 		End_block( CASE )*/
    _66End_block(186);
L1: 

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_39if_labels_53698)){
            _28962 = SEQ_PTR(_39if_labels_53698)->length;
    }
    else {
        _28962 = 1;
    }
    _28963 = _28962 - 1;
    _28962 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_labels_53698;
    RHS_Slice(_39if_labels_53698, 1, _28963);

    /** 	if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _28965 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _28965 = 1;
    }
    _28966 = _28965 - 1;
    _28965 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39if_stack_53704;
    RHS_Slice(_39if_stack_53704, 1, _28966);

    /** 	switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28968 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28968 = 1;
    }
    _28969 = _28968 - 1;
    _28968 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39switch_stack_53904;
    RHS_Slice(_39switch_stack_53904, 1, _28969);

    /** end procedure*/
    _28959 = NOVALUE;
    _28963 = NOVALUE;
    _28966 = NOVALUE;
    _28969 = NOVALUE;
    return;
    ;
}


void _39add_case(int _sym_57053, int _sign_57054)
{
    int _28995 = NOVALUE;
    int _28994 = NOVALUE;
    int _28993 = NOVALUE;
    int _28992 = NOVALUE;
    int _28991 = NOVALUE;
    int _28990 = NOVALUE;
    int _28989 = NOVALUE;
    int _28988 = NOVALUE;
    int _28986 = NOVALUE;
    int _28985 = NOVALUE;
    int _28984 = NOVALUE;
    int _28983 = NOVALUE;
    int _28982 = NOVALUE;
    int _28981 = NOVALUE;
    int _28979 = NOVALUE;
    int _28978 = NOVALUE;
    int _28976 = NOVALUE;
    int _28975 = NOVALUE;
    int _28974 = NOVALUE;
    int _28973 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sign < 0 then*/
    if (_sign_57054 >= 0)
    goto L1; // [5] 15

    /** 		sym = -sym*/
    _0 = _sym_57053;
    if (IS_ATOM_INT(_sym_57053)) {
        if ((unsigned long)_sym_57053 == 0xC0000000)
        _sym_57053 = (int)NewDouble((double)-0xC0000000);
        else
        _sym_57053 = - _sym_57053;
    }
    else {
        _sym_57053 = unary_op(UMINUS, _sym_57053);
    }
    DeRefi(_0);
L1: 

    /** 	if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28973 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28973 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _28974 = (int)*(((s1_ptr)_2)->base + _28973);
    _2 = (int)SEQ_PTR(_28974);
    _28975 = (int)*(((s1_ptr)_2)->base + 1);
    _28974 = NOVALUE;
    _28976 = find_from(_sym_57053, _28975, 1);
    _28975 = NOVALUE;
    if (_28976 != 0)
    goto L2; // [35] 144

    /** 		switch_stack[$][SWITCH_CASES]       = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28978 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28978 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28978 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28981 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28981 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _28982 = (int)*(((s1_ptr)_2)->base + _28981);
    _2 = (int)SEQ_PTR(_28982);
    _28983 = (int)*(((s1_ptr)_2)->base + 1);
    _28982 = NOVALUE;
    Ref(_sym_57053);
    Append(&_28984, _28983, _sym_57053);
    _28983 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _28984;
    if( _1 != _28984 ){
        DeRef(_1);
    }
    _28984 = NOVALUE;
    _28979 = NOVALUE;

    /** 		switch_stack[$][SWITCH_JUMP_TABLE] &= length(Code) + 1*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28985 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28985 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28985 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16056)){
            _28988 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _28988 = 1;
    }
    _28989 = _28988 + 1;
    _28988 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _28990 = (int)*(((s1_ptr)_2)->base + 2);
    _28986 = NOVALUE;
    if (IS_SEQUENCE(_28990) && IS_ATOM(_28989)) {
        Append(&_28991, _28990, _28989);
    }
    else if (IS_ATOM(_28990) && IS_SEQUENCE(_28989)) {
    }
    else {
        Concat((object_ptr)&_28991, _28990, _28989);
        _28990 = NOVALUE;
    }
    _28990 = NOVALUE;
    _28989 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _28991;
    if( _1 != _28991 ){
        DeRef(_1);
    }
    _28991 = NOVALUE;
    _28986 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [109] 152
    }
    else{
    }

    /** 			emit_addr( CASE )*/
    _41emit_addr(186);

    /** 			emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28992 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28992 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _28993 = (int)*(((s1_ptr)_2)->base + _28992);
    _2 = (int)SEQ_PTR(_28993);
    _28994 = (int)*(((s1_ptr)_2)->base + 1);
    _28993 = NOVALUE;
    if (IS_SEQUENCE(_28994)){
            _28995 = SEQ_PTR(_28994)->length;
    }
    else {
        _28995 = 1;
    }
    _28994 = NOVALUE;
    _41emit_addr(_28995);
    _28995 = NOVALUE;
    goto L3; // [141] 152
L2: 

    /** 		CompileErr( 63 )*/
    RefDS(_21815);
    _44CompileErr(63, _21815, 0);
L3: 

    /** end procedure*/
    DeRef(_sym_57053);
    _28994 = NOVALUE;
    return;
    ;
}


void _39case_else()
{
    int _29003 = NOVALUE;
    int _29002 = NOVALUE;
    int _29000 = NOVALUE;
    int _28999 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _28999 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _28999 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28999 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_35Code_16056)){
            _29002 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29002 = 1;
    }
    _29003 = _29002 + 1;
    _29002 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29003;
    if( _1 != _29003 ){
        DeRef(_1);
    }
    _29003 = NOVALUE;
    _29000 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** 		emit_addr( CASE )*/
    _41emit_addr(186);

    /** 		emit_addr( 0 )*/
    _41emit_addr(0);
L1: 

    /** end procedure*/
    return;
    ;
}


void _39Case_statement()
{
    int _else_case_2__tmp_at145_57150 = NOVALUE;
    int _else_case_1__tmp_at145_57149 = NOVALUE;
    int _else_case_inlined_else_case_at_145_57148 = NOVALUE;
    int _tok_57112 = NOVALUE;
    int _condition_57114 = NOVALUE;
    int _start_line_57143 = NOVALUE;
    int _sign_57154 = NOVALUE;
    int _fwd_57167 = NOVALUE;
    int _symi_57177 = NOVALUE;
    int _fwdref_57246 = NOVALUE;
    int _31364 = NOVALUE;
    int _29085 = NOVALUE;
    int _29084 = NOVALUE;
    int _29083 = NOVALUE;
    int _29082 = NOVALUE;
    int _29081 = NOVALUE;
    int _29080 = NOVALUE;
    int _29078 = NOVALUE;
    int _29077 = NOVALUE;
    int _29076 = NOVALUE;
    int _29075 = NOVALUE;
    int _29074 = NOVALUE;
    int _29073 = NOVALUE;
    int _29071 = NOVALUE;
    int _29068 = NOVALUE;
    int _29065 = NOVALUE;
    int _29064 = NOVALUE;
    int _29063 = NOVALUE;
    int _29062 = NOVALUE;
    int _29059 = NOVALUE;
    int _29058 = NOVALUE;
    int _29057 = NOVALUE;
    int _29056 = NOVALUE;
    int _29053 = NOVALUE;
    int _29052 = NOVALUE;
    int _29051 = NOVALUE;
    int _29050 = NOVALUE;
    int _29048 = NOVALUE;
    int _29047 = NOVALUE;
    int _29046 = NOVALUE;
    int _29044 = NOVALUE;
    int _29043 = NOVALUE;
    int _29042 = NOVALUE;
    int _29041 = NOVALUE;
    int _29040 = NOVALUE;
    int _29038 = NOVALUE;
    int _29037 = NOVALUE;
    int _29035 = NOVALUE;
    int _29034 = NOVALUE;
    int _29033 = NOVALUE;
    int _29032 = NOVALUE;
    int _29028 = NOVALUE;
    int _29027 = NOVALUE;
    int _29026 = NOVALUE;
    int _29023 = NOVALUE;
    int _29020 = NOVALUE;
    int _29017 = NOVALUE;
    int _29016 = NOVALUE;
    int _29015 = NOVALUE;
    int _29014 = NOVALUE;
    int _29013 = NOVALUE;
    int _29012 = NOVALUE;
    int _29011 = NOVALUE;
    int _29009 = NOVALUE;
    int _29008 = NOVALUE;
    int _29007 = NOVALUE;
    int _29006 = NOVALUE;
    int _29004 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not in_switch() then*/
    _29004 = _39in_switch();
    if (IS_ATOM_INT(_29004)) {
        if (_29004 != 0){
            DeRef(_29004);
            _29004 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29004)->dbl != 0.0){
            DeRef(_29004);
            _29004 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29004);
    _29004 = NOVALUE;

    /** 		CompileErr( 34 )*/
    RefDS(_21815);
    _44CompileErr(34, _21815, 0);
L1: 

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29006 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29006 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29007 = (int)*(((s1_ptr)_2)->base + _29006);
    _2 = (int)SEQ_PTR(_29007);
    _29008 = (int)*(((s1_ptr)_2)->base + 1);
    _29007 = NOVALUE;
    if (IS_SEQUENCE(_29008)){
            _29009 = SEQ_PTR(_29008)->length;
    }
    else {
        _29009 = 1;
    }
    _29008 = NOVALUE;
    if (_29009 <= 0)
    goto L2; // [35] 101

    /** 		Sibling_block( CASE )*/
    _66Sibling_block(186);

    /** 		if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29011 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29011 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29012 = (int)*(((s1_ptr)_2)->base + _29011);
    _2 = (int)SEQ_PTR(_29012);
    _29013 = (int)*(((s1_ptr)_2)->base + 5);
    _29012 = NOVALUE;
    if (IS_ATOM_INT(_29013)) {
        _29014 = (_29013 == 0);
    }
    else {
        _29014 = unary_op(NOT, _29013);
    }
    _29013 = NOVALUE;
    if (IS_ATOM_INT(_29014)) {
        if (_29014 == 0) {
            goto L3; // [64] 110
        }
    }
    else {
        if (DBL_PTR(_29014)->dbl == 0.0) {
            goto L3; // [64] 110
        }
    }
    _29016 = (_39fallthru_case_57108 == 0);
    if (_29016 == 0)
    {
        DeRef(_29016);
        _29016 = NOVALUE;
        goto L3; // [74] 110
    }
    else{
        DeRef(_29016);
        _29016 = NOVALUE;
    }

    /** 			putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 186;
    ((int *)_2)[2] = 0;
    _29017 = MAKE_SEQ(_1);
    _39putback(_29017);
    _29017 = NOVALUE;

    /** 			Break_statement()*/
    _39Break_statement();

    /** 			tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);
    goto L3; // [98] 110
L2: 

    /** 		Start_block( CASE )*/
    _66Start_block(186, 0);
L3: 

    /** 	StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 	fallthru_case = 0*/
    _39fallthru_case_57108 = 0;

    /** 	integer start_line = line_number*/
    _start_line_57143 = _35line_number_15969;

    /** 	while 1 do*/
L4: 

    /** 		if else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _else_case_1__tmp_at145_57149 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _else_case_1__tmp_at145_57149 = 1;
    }
    DeRef(_else_case_2__tmp_at145_57150);
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _else_case_2__tmp_at145_57150 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at145_57149);
    RefDS(_else_case_2__tmp_at145_57150);
    DeRef(_else_case_inlined_else_case_at_145_57148);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at145_57150);
    _else_case_inlined_else_case_at_145_57148 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_145_57148);
    DeRef(_else_case_2__tmp_at145_57150);
    _else_case_2__tmp_at145_57150 = NOVALUE;
    if (_else_case_inlined_else_case_at_145_57148 == 0) {
        goto L5; // [160] 171
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_145_57148) && DBL_PTR(_else_case_inlined_else_case_at_145_57148)->dbl == 0.0){
            goto L5; // [160] 171
        }
    }

    /** 			CompileErr( 33 )*/
    RefDS(_21815);
    _44CompileErr(33, _21815, 0);
L5: 

    /** 		maybe_namespace()*/
    _61maybe_namespace();

    /** 		tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);

    /** 		integer sign = 1*/
    _sign_57154 = 1;

    /** 		if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29020 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29020, 10)){
        _29020 = NOVALUE;
        goto L6; // [195] 212
    }
    _29020 = NOVALUE;

    /** 			sign = -1*/
    _sign_57154 = -1;

    /** 			tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);
    goto L7; // [209] 233
L6: 

    /** 		elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29023 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29023, 11)){
        _29023 = NOVALUE;
        goto L8; // [222] 232
    }
    _29023 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);
L8: 
L7: 

    /** 		integer fwd*/

    /** 		if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29026 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 502;
    *((int *)(_2+8)) = 503;
    *((int *)(_2+12)) = 23;
    _29027 = MAKE_SEQ(_1);
    _29028 = find_from(_29026, _29027, 1);
    _29026 = NOVALUE;
    DeRefDS(_29027);
    _29027 = NOVALUE;
    if (_29028 != 0)
    goto L9; // [260] 435
    _29028 = NOVALUE;

    /** 			integer symi = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _symi_57177 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_57177)){
        _symi_57177 = (long)DBL_PTR(_symi_57177)->dbl;
    }

    /** 			fwd = -1*/
    _fwd_57167 = -1;

    /** 			if symi > 0 then*/
    if (_symi_57177 <= 0)
    goto LA; // [280] 430

    /** 				if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29032 = (int)*(((s1_ptr)_2)->base + 1);
    _29033 = find_from(_29032, _37VAR_TOKS_15604, 1);
    _29032 = NOVALUE;
    if (_29033 == 0)
    {
        _29033 = NOVALUE;
        goto LB; // [299] 429
    }
    else{
        _29033 = NOVALUE;
    }

    /** 					if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29034 = (int)*(((s1_ptr)_2)->base + _symi_57177);
    _2 = (int)SEQ_PTR(_29034);
    _29035 = (int)*(((s1_ptr)_2)->base + 4);
    _29034 = NOVALUE;
    if (binary_op_a(NOTEQ, _29035, 9)){
        _29035 = NOVALUE;
        goto LC; // [318] 330
    }
    _29035 = NOVALUE;

    /** 						fwd = symi*/
    _fwd_57167 = _symi_57177;
    goto LD; // [327] 428
LC: 

    /** 					elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29037 = (int)*(((s1_ptr)_2)->base + _symi_57177);
    _2 = (int)SEQ_PTR(_29037);
    _29038 = (int)*(((s1_ptr)_2)->base + 3);
    _29037 = NOVALUE;
    if (binary_op_a(NOTEQ, _29038, 2)){
        _29038 = NOVALUE;
        goto LE; // [346] 427
    }
    _29038 = NOVALUE;

    /** 						fwd = 0*/
    _fwd_57167 = 0;

    /** 						if SymTab[symi][S_CODE] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29040 = (int)*(((s1_ptr)_2)->base + _symi_57177);
    _2 = (int)SEQ_PTR(_29040);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _29041 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _29041 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _29040 = NOVALUE;
    if (_29041 == 0) {
        _29041 = NOVALUE;
        goto LF; // [369] 393
    }
    else {
        if (!IS_ATOM_INT(_29041) && DBL_PTR(_29041)->dbl == 0.0){
            _29041 = NOVALUE;
            goto LF; // [369] 393
        }
        _29041 = NOVALUE;
    }
    _29041 = NOVALUE;

    /** 							tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29042 = (int)*(((s1_ptr)_2)->base + _symi_57177);
    _2 = (int)SEQ_PTR(_29042);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _29043 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _29043 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _29042 = NOVALUE;
    Ref(_29043);
    _2 = (int)SEQ_PTR(_tok_57112);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_57112 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29043;
    if( _1 != _29043 ){
        DeRef(_1);
    }
    _29043 = NOVALUE;
LF: 

    /** 						SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_symi_57177 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29046 = (int)*(((s1_ptr)_2)->base + _symi_57177);
    _2 = (int)SEQ_PTR(_29046);
    _29047 = (int)*(((s1_ptr)_2)->base + 5);
    _29046 = NOVALUE;
    if (IS_ATOM_INT(_29047)) {
        {unsigned long tu;
             tu = (unsigned long)_29047 | (unsigned long)1;
             _29048 = MAKE_UINT(tu);
        }
    }
    else {
        _29048 = binary_op(OR_BITS, _29047, 1);
    }
    _29047 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29048;
    if( _1 != _29048 ){
        DeRef(_1);
    }
    _29048 = NOVALUE;
    _29044 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [432] 441
L9: 

    /** 			fwd = 0*/
    _fwd_57167 = 0;
L10: 

    /** 		if fwd < 0 then*/
    if (_fwd_57167 >= 0)
    goto L11; // [445] 471

    /** 			CompileErr( 91, {find_category(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29050 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29050);
    _29051 = _63find_category(_29050);
    _29050 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29051;
    _29052 = MAKE_SEQ(_1);
    _29051 = NOVALUE;
    _44CompileErr(91, _29052, 0);
    _29052 = NOVALUE;
L11: 

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29053 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29053, 23)){
        _29053 = NOVALUE;
        goto L12; // [481] 542
    }
    _29053 = NOVALUE;

    /** 			if sign = -1 then*/
    if (_sign_57154 != -1)
    goto L13; // [487] 499

    /** 				CompileErr( 71 )*/
    RefDS(_21815);
    _44CompileErr(71, _21815, 0);
L13: 

    /** 			if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29056 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29056 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29057 = (int)*(((s1_ptr)_2)->base + _29056);
    _2 = (int)SEQ_PTR(_29057);
    _29058 = (int)*(((s1_ptr)_2)->base + 1);
    _29057 = NOVALUE;
    if (IS_SEQUENCE(_29058)){
            _29059 = SEQ_PTR(_29058)->length;
    }
    else {
        _29059 = 1;
    }
    _29058 = NOVALUE;
    if (_29059 != 0)
    goto L14; // [517] 529

    /** 				CompileErr( 44 )*/
    RefDS(_21815);
    _44CompileErr(44, _21815, 0);
L14: 

    /** 			case_else()*/
    _39case_else();

    /** 			exit*/
    goto L15; // [537] 777
    goto L16; // [539] 613
L12: 

    /** 		elsif fwd then*/
    if (_fwd_57167 == 0)
    {
        goto L17; // [544] 596
    }
    else{
    }

    /** 			integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31364);
    _31364 = 186;
    _fwdref_57246 = _38new_forward_reference(186, _fwd_57167, 186);
    _31364 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_57246)) {
        _1 = (long)(DBL_PTR(_fwdref_57246)->dbl);
        DeRefDS(_fwdref_57246);
        _fwdref_57246 = _1;
    }

    /** 			add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _fwdref_57246;
    _29062 = MAKE_SEQ(_1);
    _39add_case(_29062, _sign_57154);
    _29062 = NOVALUE;

    /** 			fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29063 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29063 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29064 = (int)*(((s1_ptr)_2)->base + _29063);
    _2 = (int)SEQ_PTR(_29064);
    _29065 = (int)*(((s1_ptr)_2)->base + 4);
    _29064 = NOVALUE;
    Ref(_29065);
    _38set_data(_fwdref_57246, _29065);
    _29065 = NOVALUE;
    goto L16; // [593] 613
L17: 

    /** 			condition = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _condition_57114 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_57114)){
        _condition_57114 = (long)DBL_PTR(_condition_57114)->dbl;
    }

    /** 			add_case( condition, sign )*/
    _39add_case(_condition_57114, _sign_57154);
L16: 

    /** 		tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = THEN then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29068 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29068, 410)){
        _29068 = NOVALUE;
        goto L18; // [628] 732
    }
    _29068 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57112;
    _tok_57112 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29071 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29071, 186)){
        _29071 = NOVALUE;
        goto L19; // [647] 717
    }
    _29071 = NOVALUE;

    /** 				if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29073 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29073 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29074 = (int)*(((s1_ptr)_2)->base + _29073);
    _2 = (int)SEQ_PTR(_29074);
    _29075 = (int)*(((s1_ptr)_2)->base + 5);
    _29074 = NOVALUE;
    if (_29075 == 0) {
        _29075 = NOVALUE;
        goto L1A; // [666] 681
    }
    else {
        if (!IS_ATOM_INT(_29075) && DBL_PTR(_29075)->dbl == 0.0){
            _29075 = NOVALUE;
            goto L1A; // [666] 681
        }
        _29075 = NOVALUE;
    }
    _29075 = NOVALUE;

    /** 					start_line = line_number*/
    _start_line_57143 = _35line_number_15969;
    goto L1B; // [678] 770
L1A: 

    /** 					putback( tok )*/
    Ref(_tok_57112);
    _39putback(_tok_57112);

    /** 					Warning(220, empty_case_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _29076 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_29076);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29076;
    ((int *)_2)[2] = _start_line_57143;
    _29077 = MAKE_SEQ(_1);
    _29076 = NOVALUE;
    _44Warning(220, 2048, _29077);
    _29077 = NOVALUE;

    /** 					exit*/
    goto L15; // [711] 777
    goto L1B; // [714] 770
L19: 

    /** 				putback( tok )*/
    Ref(_tok_57112);
    _39putback(_tok_57112);

    /** 				exit*/
    goto L15; // [726] 777
    goto L1B; // [729] 770
L18: 

    /** 		elsif tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29078 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29078, -30)){
        _29078 = NOVALUE;
        goto L1C; // [742] 769
    }
    _29078 = NOVALUE;

    /** 			CompileErr(66,{LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57112);
    _29080 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29080);
    RefDS(_26183);
    _29081 = _41LexName(_29080, _26183);
    _29080 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29081;
    _29082 = MAKE_SEQ(_1);
    _29081 = NOVALUE;
    _44CompileErr(66, _29082, 0);
    _29082 = NOVALUE;
L1C: 
L1B: 

    /** 	end while*/
    goto L4; // [774] 140
L15: 

    /** 	StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 	emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29083 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29083 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29084 = (int)*(((s1_ptr)_2)->base + _29083);
    _2 = (int)SEQ_PTR(_29084);
    _29085 = (int)*(((s1_ptr)_2)->base + 6);
    _29084 = NOVALUE;
    Ref(_29085);
    _41emit_temp(_29085, 1);
    _29085 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** end procedure*/
    DeRef(_tok_57112);
    _29008 = NOVALUE;
    DeRef(_29014);
    _29014 = NOVALUE;
    _29058 = NOVALUE;
    return;
    ;
}


void _39Fallthru_statement()
{
    int _29086 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not in_switch() then*/
    _29086 = _39in_switch();
    if (IS_ATOM_INT(_29086)) {
        if (_29086 != 0){
            DeRef(_29086);
            _29086 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29086)->dbl != 0.0){
            DeRef(_29086);
            _29086 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29086);
    _29086 = NOVALUE;

    /** 		CompileErr( 22 )*/
    RefDS(_21815);
    _44CompileErr(22, _21815, 0);
L1: 

    /** 	tok_match( CASE )*/
    _39tok_match(186, 0);

    /** 	fallthru_case = 1*/
    _39fallthru_case_57108 = 1;

    /** 	Case_statement()*/
    _39Case_statement();

    /** end procedure*/
    return;
    ;
}


void _39update_translator_info(int _sym_57312, int _all_ints_57313, int _has_integer_57314, int _has_atom_57315, int _has_sequence_57316)
{
    int _29111 = NOVALUE;
    int _29109 = NOVALUE;
    int _29107 = NOVALUE;
    int _29105 = NOVALUE;
    int _29103 = NOVALUE;
    int _29102 = NOVALUE;
    int _29100 = NOVALUE;
    int _29098 = NOVALUE;
    int _29097 = NOVALUE;
    int _29096 = NOVALUE;
    int _29095 = NOVALUE;
    int _29094 = NOVALUE;
    int _29092 = NOVALUE;
    int _29090 = NOVALUE;
    int _29088 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _29088 = NOVALUE;

    /** 	SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29090 = NOVALUE;

    /** 	SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29094 = (int)*(((s1_ptr)_2)->base + _sym_57312);
    _2 = (int)SEQ_PTR(_29094);
    _29095 = (int)*(((s1_ptr)_2)->base + 1);
    _29094 = NOVALUE;
    if (IS_SEQUENCE(_29095)){
            _29096 = SEQ_PTR(_29095)->length;
    }
    else {
        _29096 = 1;
    }
    _29095 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29096;
    if( _1 != _29096 ){
        DeRef(_1);
    }
    _29096 = NOVALUE;
    _29092 = NOVALUE;

    /** 	if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29097 = (int)*(((s1_ptr)_2)->base + _sym_57312);
    _2 = (int)SEQ_PTR(_29097);
    _29098 = (int)*(((s1_ptr)_2)->base + 32);
    _29097 = NOVALUE;
    if (binary_op_a(LESSEQ, _29098, 0)){
        _29098 = NOVALUE;
        goto L1; // [89] 198
    }
    _29098 = NOVALUE;

    /** 		if all_ints then*/
    if (_all_ints_57313 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29100 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** 		elsif has_atom + has_sequence + has_integer > 1 then*/
    _29102 = _has_atom_57315 + _has_sequence_57316;
    if ((long)((unsigned long)_29102 + (unsigned long)HIGH_BITS) >= 0) 
    _29102 = NewDouble((double)_29102);
    if (IS_ATOM_INT(_29102)) {
        _29103 = _29102 + _has_integer_57314;
        if ((long)((unsigned long)_29103 + (unsigned long)HIGH_BITS) >= 0) 
        _29103 = NewDouble((double)_29103);
    }
    else {
        _29103 = NewDouble(DBL_PTR(_29102)->dbl + (double)_has_integer_57314);
    }
    DeRef(_29102);
    _29102 = NOVALUE;
    if (binary_op_a(LESSEQ, _29103, 1)){
        DeRef(_29103);
        _29103 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29103);
    _29103 = NOVALUE;

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29105 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** 		elsif has_atom then*/
    if (_has_atom_57315 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29107 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29109 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** 		SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57312 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29111 = NOVALUE;
L3: 

    /** end procedure*/
    _29095 = NOVALUE;
    return;
    ;
}


void _39optimize_switch(int _switch_pc_57377, int _else_bp_57378, int _cases_57379, int _jump_table_57380)
{
    int _values_57381 = NOVALUE;
    int _min_57385 = NOVALUE;
    int _max_57387 = NOVALUE;
    int _all_ints_57389 = NOVALUE;
    int _has_integer_57390 = NOVALUE;
    int _has_atom_57391 = NOVALUE;
    int _has_sequence_57392 = NOVALUE;
    int _has_unassigned_57393 = NOVALUE;
    int _has_fwdref_57394 = NOVALUE;
    int _sym_57401 = NOVALUE;
    int _sign_57403 = NOVALUE;
    int _else_target_57467 = NOVALUE;
    int _opcode_57470 = NOVALUE;
    int _delta_57476 = NOVALUE;
    int _jump_57486 = NOVALUE;
    int _switch_table_57490 = NOVALUE;
    int _offset_57493 = NOVALUE;
    int _29189 = NOVALUE;
    int _29188 = NOVALUE;
    int _29187 = NOVALUE;
    int _29186 = NOVALUE;
    int _29184 = NOVALUE;
    int _29182 = NOVALUE;
    int _29179 = NOVALUE;
    int _29178 = NOVALUE;
    int _29177 = NOVALUE;
    int _29176 = NOVALUE;
    int _29175 = NOVALUE;
    int _29174 = NOVALUE;
    int _29173 = NOVALUE;
    int _29170 = NOVALUE;
    int _29168 = NOVALUE;
    int _29167 = NOVALUE;
    int _29166 = NOVALUE;
    int _29165 = NOVALUE;
    int _29164 = NOVALUE;
    int _29163 = NOVALUE;
    int _29162 = NOVALUE;
    int _29158 = NOVALUE;
    int _29157 = NOVALUE;
    int _29155 = NOVALUE;
    int _29154 = NOVALUE;
    int _29153 = NOVALUE;
    int _29152 = NOVALUE;
    int _29151 = NOVALUE;
    int _29150 = NOVALUE;
    int _29149 = NOVALUE;
    int _29148 = NOVALUE;
    int _29147 = NOVALUE;
    int _29146 = NOVALUE;
    int _29144 = NOVALUE;
    int _29143 = NOVALUE;
    int _29139 = NOVALUE;
    int _29136 = NOVALUE;
    int _29135 = NOVALUE;
    int _29134 = NOVALUE;
    int _29132 = NOVALUE;
    int _29131 = NOVALUE;
    int _29130 = NOVALUE;
    int _29129 = NOVALUE;
    int _29128 = NOVALUE;
    int _29126 = NOVALUE;
    int _29125 = NOVALUE;
    int _29124 = NOVALUE;
    int _29120 = NOVALUE;
    int _29119 = NOVALUE;
    int _29118 = NOVALUE;
    int _29114 = NOVALUE;
    int _29113 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29113 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29113 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29114 = (int)*(((s1_ptr)_2)->base + _29113);
    DeRef(_values_57381);
    _2 = (int)SEQ_PTR(_29114);
    _values_57381 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57381);
    _29114 = NOVALUE;

    /** 	atom min =  1e+300*/
    RefDS(_29116);
    DeRef(_min_57385);
    _min_57385 = _29116;

    /** 	atom max = -1e+300*/
    RefDS(_29117);
    DeRef(_max_57387);
    _max_57387 = _29117;

    /** 	integer all_ints = 1*/
    _all_ints_57389 = 1;

    /** 	integer has_integer    = 0*/
    _has_integer_57390 = 0;

    /** 	integer has_atom       = 0*/
    _has_atom_57391 = 0;

    /** 	integer has_sequence   = 0*/
    _has_sequence_57392 = 0;

    /** 	integer has_unassigned = 0*/
    _has_unassigned_57393 = 0;

    /** 	integer has_fwdref     = 0*/
    _has_fwdref_57394 = 0;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57381)){
            _29118 = SEQ_PTR(_values_57381)->length;
    }
    else {
        _29118 = 1;
    }
    {
        int _i_57396;
        _i_57396 = 1;
L1: 
        if (_i_57396 > _29118){
            goto L2; // [71] 292
        }

        /** 		if sequence( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29119 = (int)*(((s1_ptr)_2)->base + _i_57396);
        _29120 = IS_SEQUENCE(_29119);
        _29119 = NOVALUE;
        if (_29120 == 0)
        {
            _29120 = NOVALUE;
            goto L3; // [87] 100
        }
        else{
            _29120 = NOVALUE;
        }

        /** 			has_fwdref = 1*/
        _has_fwdref_57394 = 1;

        /** 			exit*/
        goto L2; // [97] 292
L3: 

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_57381);
        _sym_57401 = (int)*(((s1_ptr)_2)->base + _i_57396);
        if (!IS_ATOM_INT(_sym_57401))
        _sym_57401 = (long)DBL_PTR(_sym_57401)->dbl;

        /** 		integer sign*/

        /** 		if sym < 0 then*/
        if (_sym_57401 >= 0)
        goto L4; // [110] 129

        /** 			sign = -1*/
        _sign_57403 = -1;

        /** 			sym = -sym*/
        _sym_57401 = - _sym_57401;
        goto L5; // [126] 135
L4: 

        /** 			sign = 1*/
        _sign_57403 = 1;
L5: 

        /** 		if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _29124 = (int)*(((s1_ptr)_2)->base + _sym_57401);
        _2 = (int)SEQ_PTR(_29124);
        _29125 = (int)*(((s1_ptr)_2)->base + 1);
        _29124 = NOVALUE;
        if (_29125 == _35NOVALUE_15823)
        _29126 = 1;
        else if (IS_ATOM_INT(_29125) && IS_ATOM_INT(_35NOVALUE_15823))
        _29126 = 0;
        else
        _29126 = (compare(_29125, _35NOVALUE_15823) == 0);
        _29125 = NOVALUE;
        if (_29126 != 0)
        goto L6; // [155] 271
        _29126 = NOVALUE;

        /** 			values[i] = sign * SymTab[sym][S_OBJ]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _29128 = (int)*(((s1_ptr)_2)->base + _sym_57401);
        _2 = (int)SEQ_PTR(_29128);
        _29129 = (int)*(((s1_ptr)_2)->base + 1);
        _29128 = NOVALUE;
        if (IS_ATOM_INT(_29129)) {
            if (_sign_57403 == (short)_sign_57403 && _29129 <= INT15 && _29129 >= -INT15)
            _29130 = _sign_57403 * _29129;
            else
            _29130 = NewDouble(_sign_57403 * (double)_29129);
        }
        else {
            _29130 = binary_op(MULTIPLY, _sign_57403, _29129);
        }
        _29129 = NOVALUE;
        _2 = (int)SEQ_PTR(_values_57381);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_57381 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_57396);
        _1 = *(int *)_2;
        *(int *)_2 = _29130;
        if( _1 != _29130 ){
            DeRef(_1);
        }
        _29130 = NOVALUE;

        /** 			if not integer( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29131 = (int)*(((s1_ptr)_2)->base + _i_57396);
        if (IS_ATOM_INT(_29131))
        _29132 = 1;
        else if (IS_ATOM_DBL(_29131))
        _29132 = IS_ATOM_INT(DoubleToInt(_29131));
        else
        _29132 = 0;
        _29131 = NOVALUE;
        if (_29132 != 0)
        goto L7; // [191] 228
        _29132 = NOVALUE;

        /** 				all_ints = 0*/
        _all_ints_57389 = 0;

        /** 				if atom( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29134 = (int)*(((s1_ptr)_2)->base + _i_57396);
        _29135 = IS_ATOM(_29134);
        _29134 = NOVALUE;
        if (_29135 == 0)
        {
            _29135 = NOVALUE;
            goto L8; // [208] 219
        }
        else{
            _29135 = NOVALUE;
        }

        /** 					has_atom = 1*/
        _has_atom_57391 = 1;
        goto L9; // [216] 283
L8: 

        /** 					has_sequence = 1*/
        _has_sequence_57392 = 1;
        goto L9; // [225] 283
L7: 

        /** 				has_integer = 1*/
        _has_integer_57390 = 1;

        /** 				if values[i] < min then*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29136 = (int)*(((s1_ptr)_2)->base + _i_57396);
        if (binary_op_a(GREATEREQ, _29136, _min_57385)){
            _29136 = NOVALUE;
            goto LA; // [239] 250
        }
        _29136 = NOVALUE;

        /** 					min = values[i]*/
        DeRef(_min_57385);
        _2 = (int)SEQ_PTR(_values_57381);
        _min_57385 = (int)*(((s1_ptr)_2)->base + _i_57396);
        Ref(_min_57385);
LA: 

        /** 				if values[i] > max then*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29139 = (int)*(((s1_ptr)_2)->base + _i_57396);
        if (binary_op_a(LESSEQ, _29139, _max_57387)){
            _29139 = NOVALUE;
            goto L9; // [256] 283
        }
        _29139 = NOVALUE;

        /** 					max = values[i]*/
        DeRef(_max_57387);
        _2 = (int)SEQ_PTR(_values_57381);
        _max_57387 = (int)*(((s1_ptr)_2)->base + _i_57396);
        Ref(_max_57387);
        goto L9; // [268] 283
L6: 

        /** 			has_unassigned = 1*/
        _has_unassigned_57393 = 1;

        /** 			exit*/
        goto L2; // [280] 292
L9: 

        /** 	end for*/
        _i_57396 = _i_57396 + 1;
        goto L1; // [287] 78
L2: 
        ;
    }

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57393 != 0) {
        goto LB; // [294] 303
    }
    if (_has_fwdref_57394 == 0)
    {
        goto LC; // [299] 321
    }
    else{
    }
LB: 

    /** 		values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29143 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29143 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29144 = (int)*(((s1_ptr)_2)->base + _29143);
    DeRef(_values_57381);
    _2 = (int)SEQ_PTR(_29144);
    _values_57381 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57381);
    _29144 = NOVALUE;
LC: 

    /** 	if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29146 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29146 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29147 = (int)*(((s1_ptr)_2)->base + _29146);
    _2 = (int)SEQ_PTR(_29147);
    _29148 = (int)*(((s1_ptr)_2)->base + 3);
    _29147 = NOVALUE;
    if (_29148 == 0) {
        _29148 = NOVALUE;
        goto LD; // [336] 363
    }
    else {
        if (!IS_ATOM_INT(_29148) && DBL_PTR(_29148)->dbl == 0.0){
            _29148 = NOVALUE;
            goto LD; // [336] 363
        }
        _29148 = NOVALUE;
    }
    _29148 = NOVALUE;

    /** 			Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29149 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29149 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29150 = (int)*(((s1_ptr)_2)->base + _29149);
    _2 = (int)SEQ_PTR(_29150);
    _29151 = (int)*(((s1_ptr)_2)->base + 3);
    _29150 = NOVALUE;
    Ref(_29151);
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57378);
    _1 = *(int *)_2;
    *(int *)_2 = _29151;
    if( _1 != _29151 ){
        DeRef(_1);
    }
    _29151 = NOVALUE;
    goto LE; // [360] 387
LD: 

    /** 		Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29152 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29152 = 1;
    }
    _29153 = _29152 + 1;
    _29152 = NOVALUE;
    _29154 = _29153 + _35TRANSLATE_15611;
    _29153 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57378);
    _1 = *(int *)_2;
    *(int *)_2 = _29154;
    if( _1 != _29154 ){
        DeRef(_1);
    }
    _29154 = NOVALUE;
LE: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LF; // [391] 418
    }
    else{
    }

    /** 		SymTab[cases][S_OBJ] &= 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57379 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29157 = (int)*(((s1_ptr)_2)->base + 1);
    _29155 = NOVALUE;
    if (IS_SEQUENCE(_29157) && IS_ATOM(0)) {
        Append(&_29158, _29157, 0);
    }
    else if (IS_ATOM(_29157) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29158, _29157, 0);
        _29157 = NOVALUE;
    }
    _29157 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29158;
    if( _1 != _29158 ){
        DeRef(_1);
    }
    _29158 = NOVALUE;
    _29155 = NOVALUE;
LF: 

    /** 	integer else_target = Code[else_bp]*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    _else_target_57467 = (int)*(((s1_ptr)_2)->base + _else_bp_57378);
    if (!IS_ATOM_INT(_else_target_57467)){
        _else_target_57467 = (long)DBL_PTR(_else_target_57467)->dbl;
    }

    /** 	integer opcode = SWITCH*/
    _opcode_57470 = 185;

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57393 != 0) {
        goto L10; // [439] 448
    }
    if (_has_fwdref_57394 == 0)
    {
        goto L11; // [444] 460
    }
    else{
    }
L10: 

    /** 		opcode = SWITCH_RT*/
    _opcode_57470 = 202;
    goto L12; // [457] 630
L11: 

    /** 	elsif all_ints then*/
    if (_all_ints_57389 == 0)
    {
        goto L13; // [462] 627
    }
    else{
    }

    /** 		atom delta = max - min*/
    DeRef(_delta_57476);
    if (IS_ATOM_INT(_max_57387) && IS_ATOM_INT(_min_57385)) {
        _delta_57476 = _max_57387 - _min_57385;
        if ((long)((unsigned long)_delta_57476 +(unsigned long) HIGH_BITS) >= 0){
            _delta_57476 = NewDouble((double)_delta_57476);
        }
    }
    else {
        if (IS_ATOM_INT(_max_57387)) {
            _delta_57476 = NewDouble((double)_max_57387 - DBL_PTR(_min_57385)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_57385)) {
                _delta_57476 = NewDouble(DBL_PTR(_max_57387)->dbl - (double)_min_57385);
            }
            else
            _delta_57476 = NewDouble(DBL_PTR(_max_57387)->dbl - DBL_PTR(_min_57385)->dbl);
        }
    }

    /** 		if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29162 = (_35TRANSLATE_15611 == 0);
    if (_29162 == 0) {
        _29163 = 0;
        goto L14; // [478] 490
    }
    if (IS_ATOM_INT(_delta_57476)) {
        _29164 = (_delta_57476 < 1024);
    }
    else {
        _29164 = (DBL_PTR(_delta_57476)->dbl < (double)1024);
    }
    _29163 = (_29164 != 0);
L14: 
    if (_29163 == 0) {
        goto L15; // [490] 616
    }
    if (IS_ATOM_INT(_delta_57476)) {
        _29166 = (_delta_57476 >= 0);
    }
    else {
        _29166 = (DBL_PTR(_delta_57476)->dbl >= (double)0);
    }
    if (_29166 == 0)
    {
        DeRef(_29166);
        _29166 = NOVALUE;
        goto L15; // [499] 616
    }
    else{
        DeRef(_29166);
        _29166 = NOVALUE;
    }

    /** 			opcode = SWITCH_SPI*/
    _opcode_57470 = 192;

    /** 			sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29167 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29167 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29168 = (int)*(((s1_ptr)_2)->base + _29167);
    DeRef(_jump_57486);
    _2 = (int)SEQ_PTR(_29168);
    _jump_57486 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_57486);
    _29168 = NOVALUE;

    /** 			sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_57476)) {
        _29170 = _delta_57476 + 1;
    }
    else
    _29170 = binary_op(PLUS, 1, _delta_57476);
    DeRef(_switch_table_57490);
    _switch_table_57490 = Repeat(_else_target_57467, _29170);
    DeRef(_29170);
    _29170 = NOVALUE;

    /** 			integer offset = min - 1*/
    if (IS_ATOM_INT(_min_57385)) {
        _offset_57493 = _min_57385 - 1;
    }
    else {
        _offset_57493 = NewDouble(DBL_PTR(_min_57385)->dbl - (double)1);
    }
    if (!IS_ATOM_INT(_offset_57493)) {
        _1 = (long)(DBL_PTR(_offset_57493)->dbl);
        DeRefDS(_offset_57493);
        _offset_57493 = _1;
    }

    /** 			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57381)){
            _29173 = SEQ_PTR(_values_57381)->length;
    }
    else {
        _29173 = 1;
    }
    {
        int _i_57496;
        _i_57496 = 1;
L16: 
        if (_i_57496 > _29173){
            goto L17; // [551] 583
        }

        /** 				switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_57381);
        _29174 = (int)*(((s1_ptr)_2)->base + _i_57496);
        if (IS_ATOM_INT(_29174)) {
            _29175 = _29174 - _offset_57493;
            if ((long)((unsigned long)_29175 +(unsigned long) HIGH_BITS) >= 0){
                _29175 = NewDouble((double)_29175);
            }
        }
        else {
            _29175 = binary_op(MINUS, _29174, _offset_57493);
        }
        _29174 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_57486);
        _29176 = (int)*(((s1_ptr)_2)->base + _i_57496);
        Ref(_29176);
        _2 = (int)SEQ_PTR(_switch_table_57490);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_57490 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29175))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29175)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _29175);
        _1 = *(int *)_2;
        *(int *)_2 = _29176;
        if( _1 != _29176 ){
            DeRef(_1);
        }
        _29176 = NOVALUE;

        /** 			end for*/
        _i_57496 = _i_57496 + 1;
        goto L16; // [578] 558
L17: 
        ;
    }

    /** 			Code[switch_pc + 2] = offset*/
    _29177 = _switch_pc_57377 + 2;
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29177);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_57493;
    DeRef(_1);

    /** 			switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29178 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29178 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29178 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_57490);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_table_57490;
    DeRef(_1);
    _29179 = NOVALUE;
    DeRef(_jump_57486);
    _jump_57486 = NOVALUE;
    DeRefDS(_switch_table_57490);
    _switch_table_57490 = NOVALUE;
    goto L18; // [613] 626
L15: 

    /** 			opcode = SWITCH_I*/
    _opcode_57470 = 193;
L18: 
L13: 
    DeRef(_delta_57476);
    _delta_57476 = NOVALUE;
L12: 

    /** 	Code[switch_pc] = opcode*/
    _2 = (int)SEQ_PTR(_35Code_16056);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35Code_16056 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _switch_pc_57377);
    _1 = *(int *)_2;
    *(int *)_2 = _opcode_57470;
    DeRef(_1);

    /** 	if opcode != SWITCH_SPI then*/
    if (_opcode_57470 == 192)
    goto L19; // [642] 679

    /** 		SymTab[cases][S_OBJ] = values*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57379 + ((s1_ptr)_2)->base);
    RefDS(_values_57381);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _values_57381;
    DeRef(_1);
    _29182 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1A; // [665] 678
    }
    else{
    }

    /** 			update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _39update_translator_info(_cases_57379, _all_ints_57389, _has_integer_57390, _has_atom_57391, _has_sequence_57392);
L1A: 
L19: 

    /** 	SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_57380 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29186 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29186 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29187 = (int)*(((s1_ptr)_2)->base + _29186);
    _2 = (int)SEQ_PTR(_29187);
    _29188 = (int)*(((s1_ptr)_2)->base + 2);
    _29187 = NOVALUE;
    if (IS_ATOM_INT(_29188)) {
        _29189 = _29188 - _switch_pc_57377;
        if ((long)((unsigned long)_29189 +(unsigned long) HIGH_BITS) >= 0){
            _29189 = NewDouble((double)_29189);
        }
    }
    else {
        _29189 = binary_op(MINUS, _29188, _switch_pc_57377);
    }
    _29188 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29189;
    if( _1 != _29189 ){
        DeRef(_1);
    }
    _29189 = NOVALUE;
    _29184 = NOVALUE;

    /** end procedure*/
    DeRef(_values_57381);
    DeRef(_min_57385);
    DeRef(_max_57387);
    DeRef(_29162);
    _29162 = NOVALUE;
    DeRef(_29164);
    _29164 = NOVALUE;
    DeRef(_29177);
    _29177 = NOVALUE;
    DeRef(_29175);
    _29175 = NOVALUE;
    return;
    ;
}


void _39Switch_statement()
{
    int _else_case_2__tmp_at250_57590 = NOVALUE;
    int _else_case_1__tmp_at250_57589 = NOVALUE;
    int _else_case_inlined_else_case_at_250_57588 = NOVALUE;
    int _break_base_57528 = NOVALUE;
    int _cases_57530 = NOVALUE;
    int _jump_table_57531 = NOVALUE;
    int _else_bp_57532 = NOVALUE;
    int _switch_pc_57533 = NOVALUE;
    int _t_57570 = NOVALUE;
    int _29220 = NOVALUE;
    int _29219 = NOVALUE;
    int _29218 = NOVALUE;
    int _29217 = NOVALUE;
    int _29216 = NOVALUE;
    int _29212 = NOVALUE;
    int _29208 = NOVALUE;
    int _29207 = NOVALUE;
    int _29205 = NOVALUE;
    int _29204 = NOVALUE;
    int _29202 = NOVALUE;
    int _29201 = NOVALUE;
    int _29199 = NOVALUE;
    int _29198 = NOVALUE;
    int _29197 = NOVALUE;
    int _29196 = NOVALUE;
    int _29195 = NOVALUE;
    int _29194 = NOVALUE;
    int _29192 = NOVALUE;
    int _29191 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer else_bp*/

    /** 	integer switch_pc*/

    /** 	push_switch()*/
    _39push_switch();

    /** 	break_base = length(break_list)*/
    if (IS_SEQUENCE(_39break_list_53687)){
            _break_base_57528 = SEQ_PTR(_39break_list_53687)->length;
    }
    else {
        _break_base_57528 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29191 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29191 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29191 + ((s1_ptr)_2)->base);
    _29194 = _41Top();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _29194;
    if( _1 != _29194 ){
        DeRef(_1);
    }
    _29194 = NOVALUE;
    _29192 = NOVALUE;

    /** 	clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29195 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29195 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29196 = (int)*(((s1_ptr)_2)->base + _29195);
    _2 = (int)SEQ_PTR(_29196);
    _29197 = (int)*(((s1_ptr)_2)->base + 6);
    _29196 = NOVALUE;
    Ref(_29197);
    _41clear_temp(_29197);
    _29197 = NOVALUE;

    /** 	cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _29198 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _29198 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _29198;
    _29199 = MAKE_SEQ(_1);
    _29198 = NOVALUE;
    _cases_57530 = _53NewStringSym(_29199);
    _29199 = NOVALUE;
    if (!IS_ATOM_INT(_cases_57530)) {
        _1 = (long)(DBL_PTR(_cases_57530)->dbl);
        DeRefDS(_cases_57530);
        _cases_57530 = _1;
    }

    /** 	emit_opnd( cases )*/
    _41emit_opnd(_cases_57530);

    /** 	jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_36SymTab_14981)){
            _29201 = SEQ_PTR(_36SymTab_14981)->length;
    }
    else {
        _29201 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _29201;
    _29202 = MAKE_SEQ(_1);
    _29201 = NOVALUE;
    _jump_table_57531 = _53NewStringSym(_29202);
    _29202 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_57531)) {
        _1 = (long)(DBL_PTR(_jump_table_57531)->dbl);
        DeRefDS(_jump_table_57531);
        _jump_table_57531 = _1;
    }

    /** 	emit_opnd( jump_table )*/
    _41emit_opnd(_jump_table_57531);

    /** 	if finish_block_header(SWITCH) then end if*/
    _29204 = _39finish_block_header(185);
    if (_29204 == 0) {
        DeRef(_29204);
        _29204 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29204) && DBL_PTR(_29204)->dbl == 0.0){
            DeRef(_29204);
            _29204 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29204);
        _29204 = NOVALUE;
    }
    DeRef(_29204);
    _29204 = NOVALUE;
L1: 

    /** 	switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29205 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29205 = 1;
    }
    _switch_pc_57533 = _29205 + 1;
    _29205 = NOVALUE;

    /** 	switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29207 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29207 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39switch_stack_53904 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_pc_57533;
    DeRef(_1);
    _29208 = NOVALUE;

    /** 	emit_op(SWITCH)*/
    _41emit_op(185);

    /** 	emit_forward_addr()  -- the else*/
    _39emit_forward_addr();

    /** 	else_bp = length( Code )*/
    if (IS_SEQUENCE(_35Code_16056)){
            _else_bp_57532 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _else_bp_57532 = 1;
    }

    /** 	t = next_token()*/
    _0 = _t_57570;
    _t_57570 = _39next_token();
    DeRef(_0);

    /** 	if t[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_t_57570);
    _29212 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29212, 186)){
        _29212 = NOVALUE;
        goto L2; // [173] 188
    }
    _29212 = NOVALUE;

    /** 		Case_statement()*/
    _39Case_statement();

    /** 		Statement_list()*/
    _39Statement_list();
    goto L3; // [185] 194
L2: 

    /** 		putback(t)*/
    Ref(_t_57570);
    _39putback(_t_57570);
L3: 

    /** 	optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _39optimize_switch(_switch_pc_57533, _else_bp_57532, _cases_57530, _jump_table_57531);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(SWITCH, END)*/
    _39tok_match(185, 402);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** 		emit_op(NOPSWITCH)*/
    _41emit_op(187);
L4: 

    /** 	if not else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _else_case_1__tmp_at250_57589 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _else_case_1__tmp_at250_57589 = 1;
    }
    DeRef(_else_case_2__tmp_at250_57590);
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _else_case_2__tmp_at250_57590 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_57589);
    RefDS(_else_case_2__tmp_at250_57590);
    DeRef(_else_case_inlined_else_case_at_250_57588);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at250_57590);
    _else_case_inlined_else_case_at_250_57588 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_57588);
    DeRef(_else_case_2__tmp_at250_57590);
    _else_case_2__tmp_at250_57590 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_57588)) {
        if (_else_case_inlined_else_case_at_250_57588 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_57588)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L6; // [262] 303

    /** 			StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 			emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_39switch_stack_53904)){
            _29216 = SEQ_PTR(_39switch_stack_53904)->length;
    }
    else {
        _29216 = 1;
    }
    _2 = (int)SEQ_PTR(_39switch_stack_53904);
    _29217 = (int)*(((s1_ptr)_2)->base + _29216);
    _2 = (int)SEQ_PTR(_29217);
    _29218 = (int)*(((s1_ptr)_2)->base + 6);
    _29217 = NOVALUE;
    Ref(_29218);
    _41emit_temp(_29218, 1);
    _29218 = NOVALUE;

    /** 			flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);
L6: 

    /** 		Warning(221, no_case_else_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _29219 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_29219);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29219;
    ((int *)_2)[2] = _35line_number_15969;
    _29220 = MAKE_SEQ(_1);
    _29219 = NOVALUE;
    _44Warning(221, 4096, _29220);
    _29220 = NOVALUE;
L5: 

    /** 	pop_switch( break_base )*/
    _39pop_switch(_break_base_57528);

    /** end procedure*/
    DeRef(_t_57570);
    return;
    ;
}


int _39get_private_uninitialized()
{
    int _uninitialized_57613 = NOVALUE;
    int _s_57619 = NOVALUE;
    int _pu_57625 = NOVALUE;
    int _29237 = NOVALUE;
    int _29235 = NOVALUE;
    int _29234 = NOVALUE;
    int _29233 = NOVALUE;
    int _29232 = NOVALUE;
    int _29231 = NOVALUE;
    int _29230 = NOVALUE;
    int _29229 = NOVALUE;
    int _29228 = NOVALUE;
    int _29227 = NOVALUE;
    int _29226 = NOVALUE;
    int _29225 = NOVALUE;
    int _29222 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = {}*/
    RefDS(_21815);
    DeRefi(_uninitialized_57613);
    _uninitialized_57613 = _21815;

    /** 	if CurrentSub != TopLevelSub then*/
    if (_35CurrentSub_15976 == _35TopLevelSub_15975)
    goto L1; // [14] 149

    /** 		symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29222 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_29222);
    _s_57619 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_57619)){
        _s_57619 = (long)DBL_PTR(_s_57619)->dbl;
    }
    _29222 = NOVALUE;

    /** 		sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_57625);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3;
    ((int *)_2)[2] = 9;
    _pu_57625 = MAKE_SEQ(_1);

    /** 		while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_57619 == 0) {
        goto L3; // [51] 148
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29226 = (int)*(((s1_ptr)_2)->base + _s_57619);
    _2 = (int)SEQ_PTR(_29226);
    _29227 = (int)*(((s1_ptr)_2)->base + 4);
    _29226 = NOVALUE;
    _29228 = find_from(_29227, _pu_57625, 1);
    _29227 = NOVALUE;
    if (_29228 == 0)
    {
        _29228 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29228 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29229 = (int)*(((s1_ptr)_2)->base + _s_57619);
    _2 = (int)SEQ_PTR(_29229);
    _29230 = (int)*(((s1_ptr)_2)->base + 4);
    _29229 = NOVALUE;
    if (IS_ATOM_INT(_29230)) {
        _29231 = (_29230 == 3);
    }
    else {
        _29231 = binary_op(EQUALS, _29230, 3);
    }
    _29230 = NOVALUE;
    if (IS_ATOM_INT(_29231)) {
        if (_29231 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29231)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29233 = (int)*(((s1_ptr)_2)->base + _s_57619);
    _2 = (int)SEQ_PTR(_29233);
    _29234 = (int)*(((s1_ptr)_2)->base + 14);
    _29233 = NOVALUE;
    if (IS_ATOM_INT(_29234)) {
        _29235 = (_29234 == -1);
    }
    else {
        _29235 = binary_op(EQUALS, _29234, -1);
    }
    _29234 = NOVALUE;
    if (_29235 == 0) {
        DeRef(_29235);
        _29235 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29235) && DBL_PTR(_29235)->dbl == 0.0){
            DeRef(_29235);
            _29235 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29235);
        _29235 = NOVALUE;
    }
    DeRef(_29235);
    _29235 = NOVALUE;

    /** 				uninitialized &= s*/
    Append(&_uninitialized_57613, _uninitialized_57613, _s_57619);
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29237 = (int)*(((s1_ptr)_2)->base + _s_57619);
    _2 = (int)SEQ_PTR(_29237);
    _s_57619 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_57619)){
        _s_57619 = (long)DBL_PTR(_s_57619)->dbl;
    }
    _29237 = NOVALUE;

    /** 		end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_57625);
    _pu_57625 = NOVALUE;

    /** 	return uninitialized*/
    DeRef(_29231);
    _29231 = NOVALUE;
    return _uninitialized_57613;
    ;
}


void _39While_statement()
{
    int _bp1_57656 = NOVALUE;
    int _bp2_57657 = NOVALUE;
    int _exit_base_57658 = NOVALUE;
    int _next_base_57659 = NOVALUE;
    int _uninitialized_57660 = NOVALUE;
    int _temps_57730 = NOVALUE;
    int _29273 = NOVALUE;
    int _29272 = NOVALUE;
    int _29271 = NOVALUE;
    int _29267 = NOVALUE;
    int _29266 = NOVALUE;
    int _29264 = NOVALUE;
    int _29262 = NOVALUE;
    int _29261 = NOVALUE;
    int _29260 = NOVALUE;
    int _29256 = NOVALUE;
    int _29254 = NOVALUE;
    int _29252 = NOVALUE;
    int _29246 = NOVALUE;
    int _29244 = NOVALUE;
    int _29243 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_57660;
    _uninitialized_57660 = _39get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_57660);
    Append(&_39entry_stack_53696, _39entry_stack_53696, _uninitialized_57660);

    /** 	Start_block( WHILE )*/
    _66Start_block(47, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _exit_base_57658 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _exit_base_57658 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_53691)){
            _next_base_57659 = SEQ_PTR(_39continue_list_53691)->length;
    }
    else {
        _next_base_57659 = 1;
    }

    /** 	entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29243 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29243 = 1;
    }
    _29244 = _29243 + 1;
    _29243 = NOVALUE;
    Append(&_39entry_addr_53693, _39entry_addr_53693, _29244);
    _29244 = NOVALUE;

    /** 	emit_op(NOP2) -- Entry_statement may patch this later*/
    _41emit_op(110);

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** 		emit_op(NOPWHILE)*/
    _41emit_op(158);
L1: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29246 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29246 = 1;
    }
    _bp1_57656 = _29246 + 1;
    _29246 = NOVALUE;

    /** 	continue_addr &= bp1*/
    Append(&_39continue_addr_53694, _39continue_addr_53694, _bp1_57656);

    /** 	short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_53671 = _13FALSE_435;

    /** 	SC1_type = 0*/
    _39SC1_type_53674 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	optimized_while = FALSE*/
    _41optimized_while_49776 = _13FALSE_435;

    /** 	emit_op(WHILE)*/
    _41emit_op(47);

    /** 	short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 	if not optimized_while then*/
    if (_41optimized_while_49776 != 0)
    goto L2; // [153] 174

    /** 		bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29252 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29252 = 1;
    }
    _bp2_57657 = _29252 + 1;
    _29252 = NOVALUE;

    /** 		emit_forward_addr() -- will be patched*/
    _39emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** 		bp2 = 0*/
    _bp2_57657 = 0;
L3: 

    /** 	if finish_block_header(WHILE)=0 then*/
    _29254 = _39finish_block_header(47);
    if (binary_op_a(NOTEQ, _29254, 0)){
        DeRef(_29254);
        _29254 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29254);
    _29254 = NOVALUE;

    /** 		entry_addr[$]=-1*/
    if (IS_SEQUENCE(_39entry_addr_53693)){
            _29256 = SEQ_PTR(_39entry_addr_53693)->length;
    }
    else {
        _29256 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_53693);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39entry_addr_53693 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29256);
    *(int *)_2 = -1;
L4: 

    /** 	loop_stack &= WHILE*/
    Append(&_39loop_stack_53703, _39loop_stack_53703, 47);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _exit_base_57658 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _exit_base_57658 = 1;
    }

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_53674 != 9)
    goto L5; // [227] 280

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29260 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_29260 +(unsigned long) HIGH_BITS) >= 0){
        _29260 = NewDouble((double)_29260);
    }
    _41backpatch(_29260, 147);
    _29260 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _41emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29261 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29261 = 1;
    }
    _29262 = _29261 + 1;
    _29261 = NOVALUE;
    _41backpatch(_39SC1_patch_53673, _29262);
    _29262 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_53674 != 8)
    goto L8; // [286] 330

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29264 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_29264 +(unsigned long) HIGH_BITS) >= 0){
        _29264 = NewDouble((double)_29264);
    }
    _41backpatch(_29264, 146);
    _29264 = NOVALUE;

    /** 		AppendXList(SC1_patch)*/

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_39exit_list_53689, _39exit_list_53689, _39SC1_patch_53673);

    /** end procedure*/
    goto L9; // [318] 321
L9: 

    /** 		exit_delay &= 1*/
    Append(&_39exit_delay_53690, _39exit_delay_53690, 1);
L8: 
L7: 

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29266 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29266 = 1;
    }
    _29267 = _29266 + 1;
    _29266 = NOVALUE;
    Append(&_39retry_addr_53695, _39retry_addr_53695, _29267);
    _29267 = NOVALUE;

    /** 	sequence temps = pop_temps()*/
    _0 = _temps_57730;
    _temps_57730 = _41pop_temps();
    DeRef(_0);

    /** 	push_temps( temps )*/
    RefDS(_temps_57730);
    _41push_temps(_temps_57730);

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_57659);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(WHILE, END)*/
    _39tok_match(47, 402);

    /** 	End_block( WHILE )*/
    _66End_block(47);

    /** 	StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 	emit_op(ENDWHILE)*/
    _41emit_op(22);

    /** 	emit_addr(bp1)*/
    _41emit_addr(_bp1_57656);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
LA: 

    /** 	if bp2 != 0 then*/
    if (_bp2_57657 == 0)
    goto LB; // [434] 454

    /** 		backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29271 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29271 = 1;
    }
    _29272 = _29271 + 1;
    _29271 = NOVALUE;
    _41backpatch(_bp2_57657, _29272);
    _29272 = NOVALUE;
LB: 

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_57658);

    /** 	entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_39entry_stack_53696)){
            _29273 = SEQ_PTR(_39entry_stack_53696)->length;
    }
    else {
        _29273 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_39entry_stack_53696);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29273)) ? _29273 : (long)(DBL_PTR(_29273)->dbl);
        int stop = (IS_ATOM_INT(_29273)) ? _29273 : (long)(DBL_PTR(_29273)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_39entry_stack_53696), start, &_39entry_stack_53696 );
            }
            else Tail(SEQ_PTR(_39entry_stack_53696), stop+1, &_39entry_stack_53696);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_39entry_stack_53696), start, &_39entry_stack_53696);
        }
        else {
            assign_slice_seq = &assign_space;
            _39entry_stack_53696 = Remove_elements(start, stop, (SEQ_PTR(_39entry_stack_53696)->ref == 1));
        }
    }
    _29273 = NOVALUE;
    _29273 = NOVALUE;

    /** 	push_temps( temps )*/
    RefDS(_temps_57730);
    _41push_temps(_temps_57730);

    /** end procedure*/
    DeRef(_uninitialized_57660);
    DeRefDS(_temps_57730);
    return;
    ;
}


void _39Loop_statement()
{
    int _bp1_57760 = NOVALUE;
    int _exit_base_57761 = NOVALUE;
    int _next_base_57762 = NOVALUE;
    int _t_57764 = NOVALUE;
    int _uninitialized_57767 = NOVALUE;
    int _29297 = NOVALUE;
    int _29295 = NOVALUE;
    int _29294 = NOVALUE;
    int _29293 = NOVALUE;
    int _29287 = NOVALUE;
    int _29286 = NOVALUE;
    int _29284 = NOVALUE;
    int _29281 = NOVALUE;
    int _29280 = NOVALUE;
    int _29279 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Start_block( LOOP )*/
    _66Start_block(422, 0);

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_57767;
    _uninitialized_57767 = _39get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_57767);
    Append(&_39entry_stack_53696, _39entry_stack_53696, _uninitialized_57767);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _exit_base_57761 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _exit_base_57761 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_53691)){
            _next_base_57762 = SEQ_PTR(_39continue_list_53691)->length;
    }
    else {
        _next_base_57762 = 1;
    }

    /** 	emit_op(NOP2) -- Entry_statement() may patch this*/
    _41emit_op(110);

    /** 	emit_addr(0)*/
    _41emit_addr(0);

    /** 	if finish_block_header(LOOP) then*/
    _29279 = _39finish_block_header(422);
    if (_29279 == 0) {
        DeRef(_29279);
        _29279 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29279) && DBL_PTR(_29279)->dbl == 0.0){
            DeRef(_29279);
            _29279 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29279);
        _29279 = NOVALUE;
    }
    DeRef(_29279);
    _29279 = NOVALUE;

    /** 	    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29280 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29280 = 1;
    }
    _29281 = _29280 - 1;
    _29280 = NOVALUE;
    Append(&_39entry_addr_53693, _39entry_addr_53693, _29281);
    _29281 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** 		entry_addr &= -1*/
    Append(&_39entry_addr_53693, _39entry_addr_53693, -1);
L2: 

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L3: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29284 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29284 = 1;
    }
    _bp1_57760 = _29284 + 1;
    _29284 = NOVALUE;

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29286 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29286 = 1;
    }
    _29287 = _29286 + 1;
    _29286 = NOVALUE;
    Append(&_39retry_addr_53695, _39retry_addr_53695, _29287);
    _29287 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_39continue_addr_53694, _39continue_addr_53694, 0);

    /** 	loop_stack &= LOOP*/
    Append(&_39loop_stack_53703, _39loop_stack_53703, 422);

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	End_block( LOOP )*/
    _66End_block(422);

    /** 	tok_match(UNTIL)*/
    _39tok_match(423, 0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L4: 

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_57762);

    /** 	StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 	short_circuit += 1*/
    _39short_circuit_53669 = _39short_circuit_53669 + 1;

    /** 	short_circuit_B = FALSE*/
    _39short_circuit_B_53671 = _13FALSE_435;

    /** 	SC1_type = 0*/
    _39SC1_type_53674 = 0;

    /** 	Expr()*/
    _39Expr();

    /** 	if SC1_type = OR then*/
    if (_39SC1_type_53674 != 9)
    goto L5; // [229] 282

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29293 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_29293 +(unsigned long) HIGH_BITS) >= 0){
        _29293 = NewDouble((double)_29293);
    }
    _41backpatch(_29293, 147);
    _29293 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** 		    emit_op(NOP1)  -- to get label here*/
    _41emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29294 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29294 = 1;
    }
    _29295 = _29294 + 1;
    _29294 = NOVALUE;
    _41backpatch(_39SC1_patch_53673, _29295);
    _29295 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_39SC1_type_53674 != 8)
    goto L8; // [288] 307

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29297 = _39SC1_patch_53673 - 3;
    if ((long)((unsigned long)_29297 +(unsigned long) HIGH_BITS) >= 0){
        _29297 = NewDouble((double)_29297);
    }
    _41backpatch(_29297, 146);
    _29297 = NOVALUE;
L8: 
L7: 

    /** 	short_circuit -= 1*/
    _39short_circuit_53669 = _39short_circuit_53669 - 1;

    /** 	emit_op(IF)*/
    _41emit_op(20);

    /** 	emit_addr(bp1)*/
    _41emit_addr(_bp1_57760);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _41emit_op(159);
L9: 

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_57761);

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(LOOP, END)*/
    _39tok_match(422, 402);

    /** end procedure*/
    DeRef(_uninitialized_57767);
    return;
    ;
}


void _39Ifdef_statement()
{
    int _option_57846 = NOVALUE;
    int _matched_57847 = NOVALUE;
    int _has_matched_57848 = NOVALUE;
    int _in_matched_57849 = NOVALUE;
    int _dead_ifdef_57850 = NOVALUE;
    int _in_elsedef_57851 = NOVALUE;
    int _tok_57853 = NOVALUE;
    int _keyw_57854 = NOVALUE;
    int _parser_id_57858 = NOVALUE;
    int _negate_57874 = NOVALUE;
    int _conjunction_57875 = NOVALUE;
    int _at_start_57876 = NOVALUE;
    int _prev_conj_57877 = NOVALUE;
    int _this_matched_57950 = NOVALUE;
    int _gotword_57966 = NOVALUE;
    int _gotthen_57967 = NOVALUE;
    int _if_lvl_57968 = NOVALUE;
    int _29414 = NOVALUE;
    int _29413 = NOVALUE;
    int _29409 = NOVALUE;
    int _29407 = NOVALUE;
    int _29404 = NOVALUE;
    int _29402 = NOVALUE;
    int _29401 = NOVALUE;
    int _29397 = NOVALUE;
    int _29394 = NOVALUE;
    int _29391 = NOVALUE;
    int _29387 = NOVALUE;
    int _29385 = NOVALUE;
    int _29384 = NOVALUE;
    int _29383 = NOVALUE;
    int _29382 = NOVALUE;
    int _29381 = NOVALUE;
    int _29380 = NOVALUE;
    int _29379 = NOVALUE;
    int _29375 = NOVALUE;
    int _29372 = NOVALUE;
    int _29371 = NOVALUE;
    int _29370 = NOVALUE;
    int _29366 = NOVALUE;
    int _29365 = NOVALUE;
    int _29364 = NOVALUE;
    int _29361 = NOVALUE;
    int _29358 = NOVALUE;
    int _29357 = NOVALUE;
    int _29356 = NOVALUE;
    int _29354 = NOVALUE;
    int _29343 = NOVALUE;
    int _29341 = NOVALUE;
    int _29340 = NOVALUE;
    int _29339 = NOVALUE;
    int _29338 = NOVALUE;
    int _29337 = NOVALUE;
    int _29336 = NOVALUE;
    int _29335 = NOVALUE;
    int _29332 = NOVALUE;
    int _29331 = NOVALUE;
    int _29329 = NOVALUE;
    int _29327 = NOVALUE;
    int _29326 = NOVALUE;
    int _29324 = NOVALUE;
    int _29322 = NOVALUE;
    int _29321 = NOVALUE;
    int _29319 = NOVALUE;
    int _29318 = NOVALUE;
    int _29317 = NOVALUE;
    int _29314 = NOVALUE;
    int _29312 = NOVALUE;
    int _29309 = NOVALUE;
    int _29308 = NOVALUE;
    int _29307 = NOVALUE;
    int _29305 = NOVALUE;
    int _29303 = NOVALUE;
    int _29302 = NOVALUE;
    int _29301 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_57847 = 0;
    _has_matched_57848 = 0;
    _in_matched_57849 = 0;
    _dead_ifdef_57850 = 0;
    _in_elsedef_57851 = 0;

    /** 	sequence keyw ="ifdef"*/
    RefDS(_26060);
    DeRefi(_keyw_57854);
    _keyw_57854 = _26060;

    /** 	live_ifdef += 1*/
    _39live_ifdef_57842 = _39live_ifdef_57842 + 1;

    /** 	ifdef_lineno &= line_number*/
    Append(&_39ifdef_lineno_57843, _39ifdef_lineno_57843, _35line_number_15969);

    /** 	integer parser_id*/

    /** 	if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29301 = (_35CurrentSub_15976 != _35TopLevelSub_15975);
    if (_29301 != 0) {
        _29302 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_39if_labels_53698)){
            _29303 = SEQ_PTR(_39if_labels_53698)->length;
    }
    else {
        _29303 = 1;
    }
    _29302 = (_29303 != 0);
L1: 
    if (_29302 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_39loop_labels_53697)){
            _29305 = SEQ_PTR(_39loop_labels_53697)->length;
    }
    else {
        _29305 = 1;
    }
    if (_29305 == 0)
    {
        _29305 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29305 = NOVALUE;
    }
L2: 

    /** 		parser_id = forward_Statement_list*/
    _parser_id_57858 = _39forward_Statement_list_56694;
    goto L4; // [89] 100
L3: 

    /** 		parser_id = top_level_parser*/
    _parser_id_57858 = _39top_level_parser_57841;
L4: 

    /** 	while 1 label "top" do*/
L5: 

    /** 		if matched = 0 and in_elsedef = 0 then*/
    _29307 = (_matched_57847 == 0);
    if (_29307 == 0) {
        goto L6; // [111] 632
    }
    _29309 = (_in_elsedef_57851 == 0);
    if (_29309 == 0)
    {
        DeRef(_29309);
        _29309 = NOVALUE;
        goto L6; // [120] 632
    }
    else{
        DeRef(_29309);
        _29309 = NOVALUE;
    }

    /** 			integer negate = 0, conjunction = 0*/
    _negate_57874 = 0;
    _conjunction_57875 = 0;

    /** 			integer at_start = 1*/
    _at_start_57876 = 1;

    /** 			sequence prev_conj = ""*/
    RefDS(_21815);
    DeRef(_prev_conj_57877);
    _prev_conj_57877 = _21815;

    /** 			while 1 label "deflist" do*/
L7: 

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_57846;
    _option_57846 = _61StringToken(_5);
    DeRef(_0);

    /** 				if equal(option, "then") then*/
    if (_option_57846 == _26127)
    _29312 = 1;
    else if (IS_ATOM_INT(_option_57846) && IS_ATOM_INT(_26127))
    _29312 = 0;
    else
    _29312 = (compare(_option_57846, _26127) == 0);
    if (_29312 == 0)
    {
        _29312 = NOVALUE;
        goto L8; // [162] 234
    }
    else{
        _29312 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57876 != 1)
    goto L9; // [167] 185

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29314 = MAKE_SEQ(_1);
    _44CompileErr(6, _29314, 0);
    _29314 = NOVALUE;
    goto LA; // [182] 518
L9: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57875 != 0)
    goto LB; // [187] 219

    /** 						if negate = 0 then*/
    if (_negate_57874 != 0)
    goto LC; // [193] 204

    /** 							exit "deflist"*/
    goto LD; // [199] 606
    goto LA; // [201] 518
LC: 

    /** 							CompileErr(11, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29317 = MAKE_SEQ(_1);
    _44CompileErr(11, _29317, 0);
    _29317 = NOVALUE;
    goto LA; // [216] 518
LB: 

    /** 						CompileErr(8, {keyw, prev_conj})*/
    RefDS(_prev_conj_57877);
    RefDS(_keyw_57854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57854;
    ((int *)_2)[2] = _prev_conj_57877;
    _29318 = MAKE_SEQ(_1);
    _44CompileErr(8, _29318, 0);
    _29318 = NOVALUE;
    goto LA; // [231] 518
L8: 

    /** 				elsif equal(option, "not") then*/
    if (_option_57846 == _26088)
    _29319 = 1;
    else if (IS_ATOM_INT(_option_57846) && IS_ATOM_INT(_26088))
    _29319 = 0;
    else
    _29319 = (compare(_option_57846, _26088) == 0);
    if (_29319 == 0)
    {
        _29319 = NOVALUE;
        goto LE; // [240] 276
    }
    else{
        _29319 = NOVALUE;
    }

    /** 					if negate = 0 then*/
    if (_negate_57874 != 0)
    goto LF; // [245] 261

    /** 						negate = 1*/
    _negate_57874 = 1;

    /** 						continue "deflist"*/
    goto L7; // [256] 148
    goto LA; // [258] 518
LF: 

    /** 						CompileErr(7, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29321 = MAKE_SEQ(_1);
    _44CompileErr(7, _29321, 0);
    _29321 = NOVALUE;
    goto LA; // [273] 518
LE: 

    /** 				elsif equal(option, "and") then*/
    if (_option_57846 == _25992)
    _29322 = 1;
    else if (IS_ATOM_INT(_option_57846) && IS_ATOM_INT(_25992))
    _29322 = 0;
    else
    _29322 = (compare(_option_57846, _25992) == 0);
    if (_29322 == 0)
    {
        _29322 = NOVALUE;
        goto L10; // [282] 345
    }
    else{
        _29322 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57876 != 1)
    goto L11; // [287] 305

    /** 						CompileErr(2, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29324 = MAKE_SEQ(_1);
    _44CompileErr(2, _29324, 0);
    _29324 = NOVALUE;
    goto LA; // [302] 518
L11: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57875 != 0)
    goto L12; // [307] 330

    /** 						conjunction = 1*/
    _conjunction_57875 = 1;

    /** 						prev_conj = option*/
    RefDS(_option_57846);
    DeRef(_prev_conj_57877);
    _prev_conj_57877 = _option_57846;

    /** 						continue "deflist"*/
    goto L7; // [325] 148
    goto LA; // [327] 518
L12: 

    /** 						CompileErr(10,{keyw,prev_conj})*/
    RefDS(_prev_conj_57877);
    RefDS(_keyw_57854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57854;
    ((int *)_2)[2] = _prev_conj_57877;
    _29326 = MAKE_SEQ(_1);
    _44CompileErr(10, _29326, 0);
    _29326 = NOVALUE;
    goto LA; // [342] 518
L10: 

    /** 				elsif equal(option, "or") then*/
    if (_option_57846 == _26092)
    _29327 = 1;
    else if (IS_ATOM_INT(_option_57846) && IS_ATOM_INT(_26092))
    _29327 = 0;
    else
    _29327 = (compare(_option_57846, _26092) == 0);
    if (_29327 == 0)
    {
        _29327 = NOVALUE;
        goto L13; // [351] 414
    }
    else{
        _29327 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57876 != 1)
    goto L14; // [356] 374

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29329 = MAKE_SEQ(_1);
    _44CompileErr(6, _29329, 0);
    _29329 = NOVALUE;
    goto LA; // [371] 518
L14: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57875 != 0)
    goto L15; // [376] 399

    /** 						conjunction = 2*/
    _conjunction_57875 = 2;

    /** 						prev_conj = option*/
    RefDS(_option_57846);
    DeRef(_prev_conj_57877);
    _prev_conj_57877 = _option_57846;

    /** 						continue "deflist"*/
    goto L7; // [394] 148
    goto LA; // [396] 518
L15: 

    /** 						CompileErr(9, {keyw, prev_conj})*/
    RefDS(_prev_conj_57877);
    RefDS(_keyw_57854);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57854;
    ((int *)_2)[2] = _prev_conj_57877;
    _29331 = MAKE_SEQ(_1);
    _44CompileErr(9, _29331, 0);
    _29331 = NOVALUE;
    goto LA; // [411] 518
L13: 

    /** 				elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_57846)){
            _29332 = SEQ_PTR(_option_57846)->length;
    }
    else {
        _29332 = 1;
    }
    if (_29332 != 0)
    goto L16; // [419] 454

    /** 					if at_start = 1 then*/
    if (_at_start_57876 != 1)
    goto L17; // [425] 443

    /** 						CompileErr(122, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29335 = MAKE_SEQ(_1);
    _44CompileErr(122, _29335, 0);
    _29335 = NOVALUE;
    goto LA; // [440] 518
L17: 

    /** 						CompileErr(82)*/
    RefDS(_21815);
    _44CompileErr(82, _21815, 0);
    goto LA; // [451] 518
L16: 

    /** 				elsif not at_start and length(prev_conj) = 0 then*/
    _29336 = (_at_start_57876 == 0);
    if (_29336 == 0) {
        goto L18; // [459] 488
    }
    if (IS_SEQUENCE(_prev_conj_57877)){
            _29338 = SEQ_PTR(_prev_conj_57877)->length;
    }
    else {
        _29338 = 1;
    }
    _29339 = (_29338 == 0);
    _29338 = NOVALUE;
    if (_29339 == 0)
    {
        DeRef(_29339);
        _29339 = NOVALUE;
        goto L18; // [471] 488
    }
    else{
        DeRef(_29339);
        _29339 = NOVALUE;
    }

    /** 					CompileErr(4, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29340 = MAKE_SEQ(_1);
    _44CompileErr(4, _29340, 0);
    _29340 = NOVALUE;
    goto LA; // [485] 518
L18: 

    /** 				elsif t_identifier(option) = 0 then*/
    RefDS(_option_57846);
    _29341 = _13t_identifier(_option_57846);
    if (binary_op_a(NOTEQ, _29341, 0)){
        DeRef(_29341);
        _29341 = NOVALUE;
        goto L19; // [494] 512
    }
    DeRef(_29341);
    _29341 = NOVALUE;

    /** 					CompileErr(3, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57854);
    *((int *)(_2+4)) = _keyw_57854;
    _29343 = MAKE_SEQ(_1);
    _44CompileErr(3, _29343, 0);
    _29343 = NOVALUE;
    goto LA; // [509] 518
L19: 

    /** 					at_start = 0*/
    _at_start_57876 = 0;
LA: 

    /** 				integer this_matched = find(option, OpDefines)*/
    _this_matched_57950 = find_from(_option_57846, _35OpDefines_16041, 1);

    /** 				if negate then*/
    if (_negate_57874 == 0)
    {
        goto L1A; // [529] 543
    }
    else{
    }

    /** 					this_matched = not this_matched*/
    _this_matched_57950 = (_this_matched_57950 == 0);

    /** 					negate = 0*/
    _negate_57874 = 0;
L1A: 

    /** 				if conjunction = 0 then*/
    if (_conjunction_57875 != 0)
    goto L1B; // [545] 557

    /** 					matched = this_matched*/
    _matched_57847 = _this_matched_57950;
    goto L1C; // [554] 599
L1B: 

    /** 					if conjunction = 1 then*/
    if (_conjunction_57875 != 1)
    goto L1D; // [559] 572

    /** 						matched = matched and this_matched*/
    _matched_57847 = (_matched_57847 != 0 && _this_matched_57950 != 0);
    goto L1E; // [569] 586
L1D: 

    /** 					elsif conjunction = 2 then*/
    if (_conjunction_57875 != 2)
    goto L1F; // [574] 585

    /** 						matched = matched or this_matched*/
    _matched_57847 = (_matched_57847 != 0 || _this_matched_57950 != 0);
L1F: 
L1E: 

    /** 					conjunction = 0*/
    _conjunction_57875 = 0;

    /** 					prev_conj = ""*/
    RefDS(_21815);
    DeRef(_prev_conj_57877);
    _prev_conj_57877 = _21815;
L1C: 

    /** 			end while*/
    goto L7; // [603] 148
LD: 

    /** 			in_matched = matched*/
    _in_matched_57849 = _matched_57847;

    /** 			if matched then*/
    if (_matched_57847 == 0)
    {
        goto L20; // [613] 631
    }
    else{
    }

    /** 				No_new_entry = 0*/
    _53No_new_entry_46887 = 0;

    /** 				call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_57858].addr;
    (*(int (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_57877);
    _prev_conj_57877 = NOVALUE;

    /** 		integer gotword = 0*/
    _gotword_57966 = 0;

    /** 		integer gotthen = 0*/
    _gotthen_57967 = 0;

    /** 		integer if_lvl  = 0*/
    _if_lvl_57968 = 0;

    /** 		No_new_entry = not matched*/
    _53No_new_entry_46887 = (_matched_57847 == 0);

    /** 		has_matched = has_matched or matched*/
    _has_matched_57848 = (_has_matched_57848 != 0 || _matched_57847 != 0);

    /** 		keyw = "elsifdef"*/
    RefDS(_26028);
    DeRefi(_keyw_57854);
    _keyw_57854 = _26028;

    /** 		while 1 do*/
L21: 

    /** 			tok = next_token()*/
    _0 = _tok_57853;
    _tok_57853 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29354 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29354, -21)){
        _29354 = NOVALUE;
        goto L22; // [689] 712
    }
    _29354 = NOVALUE;

    /** 				CompileErr(65, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29356 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29356 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29357 = (int)*(((s1_ptr)_2)->base + _29356);
    _44CompileErr(65, _29357, 0);
    _29357 = NOVALUE;
    goto L21; // [709] 674
L22: 

    /** 			elsif tok[T_ID] = END then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29358 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29358, 402)){
        _29358 = NOVALUE;
        goto L23; // [722] 844
    }
    _29358 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_57853;
    _tok_57853 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29361 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29361, 407)){
        _29361 = NOVALUE;
        goto L24; // [741] 769
    }
    _29361 = NOVALUE;

    /** 					if dead_ifdef then*/
    if (_dead_ifdef_57850 == 0)
    {
        goto L25; // [747] 759
    }
    else{
    }

    /** 						dead_ifdef -= 1*/
    _dead_ifdef_57850 = _dead_ifdef_57850 - 1;
    goto L21; // [756] 674
L25: 

    /** 						exit "top"*/
    goto L26; // [763] 1312
    goto L21; // [766] 674
L24: 

    /** 				elsif in_matched then*/
    if (_in_matched_57849 == 0)
    {
        goto L27; // [771] 793
    }
    else{
    }

    /** 					CompileErr(75, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29364 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29364 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29365 = (int)*(((s1_ptr)_2)->base + _29364);
    _44CompileErr(75, _29365, 0);
    _29365 = NOVALUE;
    goto L21; // [790] 674
L27: 

    /** 					if tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29366 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29366, 20)){
        _29366 = NOVALUE;
        goto L21; // [803] 674
    }
    _29366 = NOVALUE;

    /** 						if if_lvl > 0 then*/
    if (_if_lvl_57968 <= 0)
    goto L28; // [809] 822

    /** 							if_lvl -= 1*/
    _if_lvl_57968 = _if_lvl_57968 - 1;
    goto L21; // [819] 674
L28: 

    /** 							CompileErr(111, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29370 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29370 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29371 = (int)*(((s1_ptr)_2)->base + _29370);
    _44CompileErr(111, _29371, 0);
    _29371 = NOVALUE;
    goto L21; // [841] 674
L23: 

    /** 			elsif tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29372 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29372, 20)){
        _29372 = NOVALUE;
        goto L29; // [854] 867
    }
    _29372 = NOVALUE;

    /** 				if_lvl += 1*/
    _if_lvl_57968 = _if_lvl_57968 + 1;
    goto L21; // [864] 674
L29: 

    /** 			elsif tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29375 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29375, 23)){
        _29375 = NOVALUE;
        goto L2A; // [877] 913
    }
    _29375 = NOVALUE;

    /** 				if not in_matched then*/
    if (_in_matched_57849 != 0)
    goto L21; // [883] 674

    /** 					if if_lvl = 0 then*/
    if (_if_lvl_57968 != 0)
    goto L21; // [888] 674

    /** 						CompileErr(108, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29379 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29379 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29380 = (int)*(((s1_ptr)_2)->base + _29379);
    _44CompileErr(108, _29380, 0);
    _29380 = NOVALUE;
    goto L21; // [910] 674
L2A: 

    /** 			elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29381 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29381)) {
        _29382 = (_29381 == 408);
    }
    else {
        _29382 = binary_op(EQUALS, _29381, 408);
    }
    _29381 = NOVALUE;
    if (IS_ATOM_INT(_29382)) {
        if (_29382 == 0) {
            goto L2B; // [927] 1065
        }
    }
    else {
        if (DBL_PTR(_29382)->dbl == 0.0) {
            goto L2B; // [927] 1065
        }
    }
    _29384 = (_dead_ifdef_57850 == 0);
    if (_29384 == 0)
    {
        DeRef(_29384);
        _29384 = NOVALUE;
        goto L2B; // [935] 1065
    }
    else{
        DeRef(_29384);
        _29384 = NOVALUE;
    }

    /** 				if has_matched then*/
    if (_has_matched_57848 == 0)
    {
        goto L2C; // [940] 1305
    }
    else{
    }

    /** 					in_matched = 0*/
    _in_matched_57849 = 0;

    /** 					No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 					gotword = 0*/
    _gotword_57966 = 0;

    /** 					gotthen = 0*/
    _gotthen_57967 = 0;

    /** 					while length(option) > 0 with entry do*/
    goto L2D; // [967] 1009
L2E: 
    if (IS_SEQUENCE(_option_57846)){
            _29385 = SEQ_PTR(_option_57846)->length;
    }
    else {
        _29385 = 1;
    }
    if (_29385 <= 0)
    goto L2F; // [975] 1022

    /** 						if equal(option, "then") then*/
    if (_option_57846 == _26127)
    _29387 = 1;
    else if (IS_ATOM_INT(_option_57846) && IS_ATOM_INT(_26127))
    _29387 = 0;
    else
    _29387 = (compare(_option_57846, _26127) == 0);
    if (_29387 == 0)
    {
        _29387 = NOVALUE;
        goto L30; // [985] 1000
    }
    else{
        _29387 = NOVALUE;
    }

    /** 							gotthen = 1*/
    _gotthen_57967 = 1;

    /** 							exit*/
    goto L2F; // [995] 1022
    goto L31; // [997] 1006
L30: 

    /** 							gotword = 1*/
    _gotword_57966 = 1;
L31: 

    /** 					entry*/
L2D: 

    /** 						option = StringToken()*/
    RefDS(_5);
    _0 = _option_57846;
    _option_57846 = _61StringToken(_5);
    DeRef(_0);

    /** 					end while*/
    goto L2E; // [1019] 970
L2F: 

    /** 					if gotword = 0 then*/
    if (_gotword_57966 != 0)
    goto L32; // [1024] 1036

    /** 						CompileErr(78)*/
    RefDS(_21815);
    _44CompileErr(78, _21815, 0);
L32: 

    /** 					if gotthen = 0 then*/
    if (_gotthen_57967 != 0)
    goto L33; // [1038] 1050

    /** 						CompileErr(77)*/
    RefDS(_21815);
    _44CompileErr(77, _21815, 0);
L33: 

    /** 					read_line()*/
    _61read_line();
    goto L21; // [1054] 674

    /** 					exit*/
    goto L2C; // [1059] 1305
    goto L21; // [1062] 674
L2B: 

    /** 			elsif tok[T_ID] = ELSEDEF then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29391 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29391, 409)){
        _29391 = NOVALUE;
        goto L34; // [1075] 1235
    }
    _29391 = NOVALUE;

    /** 				gotword = line_number*/
    _gotword_57966 = _35line_number_15969;

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_57846;
    _option_57846 = _61StringToken(_5);
    DeRef(_0);

    /** 				if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_57846)){
            _29394 = SEQ_PTR(_option_57846)->length;
    }
    else {
        _29394 = 1;
    }
    if (_29394 <= 0)
    goto L35; // [1101] 1135

    /** 					if line_number = gotword then*/
    if (_35line_number_15969 != _gotword_57966)
    goto L36; // [1109] 1121

    /** 						CompileErr(116)*/
    RefDS(_21815);
    _44CompileErr(116, _21815, 0);
L36: 

    /** 					bp -= length(option)*/
    if (IS_SEQUENCE(_option_57846)){
            _29397 = SEQ_PTR(_option_57846)->length;
    }
    else {
        _29397 = 1;
    }
    _44bp_48146 = _44bp_48146 - _29397;
    _29397 = NOVALUE;
L35: 

    /** 				if not dead_ifdef then*/
    if (_dead_ifdef_57850 != 0)
    goto L21; // [1137] 674

    /** 					if has_matched then*/
    if (_has_matched_57848 == 0)
    {
        goto L37; // [1142] 1164
    }
    else{
    }

    /** 						in_matched = 0*/
    _in_matched_57849 = 0;

    /** 						No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 						read_line()*/
    _61read_line();
    goto L21; // [1161] 674
L37: 

    /** 						No_new_entry = 0*/
    _53No_new_entry_46887 = 0;

    /** 						in_elsedef = 1*/
    _in_elsedef_57851 = 1;

    /** 						call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_57858].addr;
    (*(int (*)())_0)(
                         );

    /** 						tok_match(END)*/
    _39tok_match(402, 0);

    /** 						tok_match(IFDEF, END)*/
    _39tok_match(407, 402);

    /** 						live_ifdef -= 1*/
    _39live_ifdef_57842 = _39live_ifdef_57842 - 1;

    /** 						ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29401 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29401 = 1;
    }
    _29402 = _29401 - 1;
    _29401 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39ifdef_lineno_57843;
    RHS_Slice(_39ifdef_lineno_57843, 1, _29402);

    /** 						return*/
    DeRef(_option_57846);
    DeRef(_tok_57853);
    DeRefi(_keyw_57854);
    DeRef(_29301);
    _29301 = NOVALUE;
    DeRef(_29307);
    _29307 = NOVALUE;
    DeRef(_29336);
    _29336 = NOVALUE;
    _29402 = NOVALUE;
    DeRef(_29382);
    _29382 = NOVALUE;
    return;
    goto L21; // [1232] 674
L34: 

    /** 			elsif tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29404 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29404, 407)){
        _29404 = NOVALUE;
        goto L38; // [1245] 1258
    }
    _29404 = NOVALUE;

    /** 				dead_ifdef += 1*/
    _dead_ifdef_57850 = _dead_ifdef_57850 + 1;
    goto L21; // [1255] 674
L38: 

    /** 			elsif tok[T_ID] = INCLUDE then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29407 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29407, 418)){
        _29407 = NOVALUE;
        goto L39; // [1268] 1279
    }
    _29407 = NOVALUE;

    /** 				read_line()*/
    _61read_line();
    goto L21; // [1276] 674
L39: 

    /** 			elsif tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57853);
    _29409 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29409, 186)){
        _29409 = NOVALUE;
        goto L21; // [1289] 674
    }
    _29409 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_57853;
    _tok_57853 = _39next_token();
    DeRef(_0);

    /** 		end while*/
    goto L21; // [1302] 674
L2C: 

    /** 	end while*/
    goto L5; // [1309] 105
L26: 

    /** 	live_ifdef -= 1*/
    _39live_ifdef_57842 = _39live_ifdef_57842 - 1;

    /** 	ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29413 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29413 = 1;
    }
    _29414 = _29413 - 1;
    _29413 = NOVALUE;
    rhs_slice_target = (object_ptr)&_39ifdef_lineno_57843;
    RHS_Slice(_39ifdef_lineno_57843, 1, _29414);

    /** 	No_new_entry = 0*/
    _53No_new_entry_46887 = 0;

    /** end procedure*/
    DeRef(_option_57846);
    DeRef(_tok_57853);
    DeRefi(_keyw_57854);
    DeRef(_29301);
    _29301 = NOVALUE;
    DeRef(_29307);
    _29307 = NOVALUE;
    DeRef(_29336);
    _29336 = NOVALUE;
    DeRef(_29402);
    _29402 = NOVALUE;
    DeRef(_29382);
    _29382 = NOVALUE;
    _29414 = NOVALUE;
    return;
    ;
}


int _39SetPrivateScope(int _s_58114, int _type_sym_58116, int _n_58117)
{
    int _hashval_58118 = NOVALUE;
    int _scope_58119 = NOVALUE;
    int _t_58121 = NOVALUE;
    int _29435 = NOVALUE;
    int _29434 = NOVALUE;
    int _29433 = NOVALUE;
    int _29432 = NOVALUE;
    int _29431 = NOVALUE;
    int _29430 = NOVALUE;
    int _29427 = NOVALUE;
    int _29424 = NOVALUE;
    int _29422 = NOVALUE;
    int _29420 = NOVALUE;
    int _29416 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_58114)) {
        _1 = (long)(DBL_PTR(_s_58114)->dbl);
        DeRefDS(_s_58114);
        _s_58114 = _1;
    }

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29416 = (int)*(((s1_ptr)_2)->base + _s_58114);
    _2 = (int)SEQ_PTR(_29416);
    _scope_58119 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_58119)){
        _scope_58119 = (long)DBL_PTR(_scope_58119)->dbl;
    }
    _29416 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_58119;
    switch ( _0 ){ 

        /** 		case SC_PRIVATE then*/
        case 3:

        /** 			DefinedYet(s)*/
        _53DefinedYet(_s_58114);

        /** 			Block_var( s )*/
        _66Block_var(_s_58114);

        /** 			return s*/
        return _s_58114;
        goto L1; // [50] 260

        /** 		case SC_LOOP_VAR then*/
        case 2:

        /** 			DefinedYet(s)*/
        _53DefinedYet(_s_58114);

        /** 			return s*/
        return _s_58114;
        goto L1; // [67] 260

        /** 		case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** 			SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58114 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = 3;
        DeRef(_1);
        _29420 = NOVALUE;

        /** 			SymTab[s][S_VARNUM] = n*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58114 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 16);
        _1 = *(int *)_2;
        *(int *)_2 = _n_58117;
        DeRef(_1);
        _29422 = NOVALUE;

        /** 			SymTab[s][S_VTYPE] = type_sym*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58114 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _type_sym_58116;
        DeRef(_1);
        _29424 = NOVALUE;

        /** 			if type_sym < 0 then*/
        if (_type_sym_58116 >= 0)
        goto L2; // [124] 135

        /** 				register_forward_type( s, type_sym )*/
        _38register_forward_type(_s_58114, _type_sym_58116);
L2: 

        /** 			Block_var( s )*/
        _66Block_var(_s_58114);

        /** 			return s*/
        return _s_58114;
        goto L1; // [146] 260

        /** 		case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** 			hashval = SymTab[s][S_HASHVAL]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _29427 = (int)*(((s1_ptr)_2)->base + _s_58114);
        _2 = (int)SEQ_PTR(_29427);
        _hashval_58118 = (int)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_58118)){
            _hashval_58118 = (long)DBL_PTR(_hashval_58118)->dbl;
        }
        _29427 = NOVALUE;

        /** 			t = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _t_58121 = (int)*(((s1_ptr)_2)->base + _hashval_58118);
        if (!IS_ATOM_INT(_t_58121)){
            _t_58121 = (long)DBL_PTR(_t_58121)->dbl;
        }

        /** 			buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _29430 = (int)*(((s1_ptr)_2)->base + _s_58114);
        _2 = (int)SEQ_PTR(_29430);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _29431 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _29431 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        _29430 = NOVALUE;
        Ref(_29431);
        _29432 = _53NewEntry(_29431, _n_58117, 3, -100, _hashval_58118, _t_58121, _type_sym_58116);
        _29431 = NOVALUE;
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_58118);
        _1 = *(int *)_2;
        *(int *)_2 = _29432;
        if( _1 != _29432 ){
            DeRef(_1);
        }
        _29432 = NOVALUE;

        /** 			Block_var( buckets[hashval] )*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _29433 = (int)*(((s1_ptr)_2)->base + _hashval_58118);
        Ref(_29433);
        _66Block_var(_29433);
        _29433 = NOVALUE;

        /** 			return buckets[hashval]*/
        _2 = (int)SEQ_PTR(_53buckets_45711);
        _29434 = (int)*(((s1_ptr)_2)->base + _hashval_58118);
        Ref(_29434);
        return _29434;
        goto L1; // [243] 260

        /** 		case else*/
        default:

        /** 			InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _scope_58119;
        _29435 = MAKE_SEQ(_1);
        _44InternalErr(267, _29435);
        _29435 = NOVALUE;
    ;}L1: 

    /** 	return 0*/
    _29434 = NOVALUE;
    return 0;
    ;
}


void _39For_statement()
{
    int _bp1_58186 = NOVALUE;
    int _bp2_58187 = NOVALUE;
    int _exit_base_58188 = NOVALUE;
    int _next_base_58189 = NOVALUE;
    int _end_op_58190 = NOVALUE;
    int _tok_58192 = NOVALUE;
    int _loop_var_58193 = NOVALUE;
    int _loop_var_sym_58195 = NOVALUE;
    int _save_syms_58196 = NOVALUE;
    int _29482 = NOVALUE;
    int _29480 = NOVALUE;
    int _29479 = NOVALUE;
    int _29473 = NOVALUE;
    int _29471 = NOVALUE;
    int _29469 = NOVALUE;
    int _29468 = NOVALUE;
    int _29467 = NOVALUE;
    int _29466 = NOVALUE;
    int _29464 = NOVALUE;
    int _29462 = NOVALUE;
    int _29461 = NOVALUE;
    int _29460 = NOVALUE;
    int _29459 = NOVALUE;
    int _29457 = NOVALUE;
    int _29455 = NOVALUE;
    int _29451 = NOVALUE;
    int _29449 = NOVALUE;
    int _29446 = NOVALUE;
    int _29444 = NOVALUE;
    int _29438 = NOVALUE;
    int _29437 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence save_syms*/

    /** 	Start_block( FOR )*/
    _66Start_block(21, 0);

    /** 	loop_var = next_token()*/
    _0 = _loop_var_58193;
    _loop_var_58193 = _39next_token();
    DeRef(_0);

    /** 	if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_loop_var_58193);
    _29437 = (int)*(((s1_ptr)_2)->base + 1);
    _29438 = find_from(_29437, _37ADDR_TOKS_15598, 1);
    _29437 = NOVALUE;
    if (_29438 != 0)
    goto L1; // [31] 42
    _29438 = NOVALUE;

    /** 		CompileErr(28)*/
    RefDS(_21815);
    _44CompileErr(28, _21815, 0);
L1: 

    /** 	if BIND then*/
    if (_35BIND_15614 == 0)
    {
        goto L2; // [46] 55
    }
    else{
    }

    /** 		add_ref(loop_var)*/
    Ref(_loop_var_58193);
    _53add_ref(_loop_var_58193);
L2: 

    /** 	tok_match(EQUALS)*/
    _39tok_match(3, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _exit_base_58188 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _exit_base_58188 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_39continue_list_53691)){
            _next_base_58189 = SEQ_PTR(_39continue_list_53691)->length;
    }
    else {
        _next_base_58189 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	tok_match(TO)*/
    _39tok_match(403, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_39exit_list_53689)){
            _exit_base_58188 = SEQ_PTR(_39exit_list_53689)->length;
    }
    else {
        _exit_base_58188 = 1;
    }

    /** 	Expr()*/
    _39Expr();

    /** 	tok = next_token()*/
    _0 = _tok_58192;
    _tok_58192 = _39next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_tok_58192);
    _29444 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29444, 404)){
        _29444 = NOVALUE;
        goto L3; // [115] 135
    }
    _29444 = NOVALUE;

    /** 		Expr()*/
    _39Expr();

    /** 		end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_58190 = 39;
    goto L4; // [132] 159
L3: 

    /** 		emit_opnd(NewIntSym(1))*/
    _29446 = _53NewIntSym(1);
    _41emit_opnd(_29446);
    _29446 = NOVALUE;

    /** 		putback(tok)*/
    Ref(_tok_58192);
    _39putback(_tok_58192);

    /** 		end_op = ENDFOR_INT_UP1*/
    _end_op_58190 = 54;
L4: 

    /** 	loop_var_sym = loop_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_loop_var_58193);
    _loop_var_sym_58195 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_58195)){
        _loop_var_sym_58195 = (long)DBL_PTR(_loop_var_sym_58195)->dbl;
    }

    /** 	if CurrentSub = TopLevelSub then*/
    if (_35CurrentSub_15976 != _35TopLevelSub_15975)
    goto L5; // [175] 221

    /** 		DefinedYet(loop_var_sym)*/
    _53DefinedYet(_loop_var_sym_58195);

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58195 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29449 = NOVALUE;

    /** 		SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58195 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_45715;
    DeRef(_1);
    _29451 = NOVALUE;
    goto L6; // [218] 265
L5: 

    /** 		loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_58195 = _39SetPrivateScope(_loop_var_sym_58195, _53object_type_45715, _39param_num_53678);
    if (!IS_ATOM_INT(_loop_var_sym_58195)) {
        _1 = (long)(DBL_PTR(_loop_var_sym_58195)->dbl);
        DeRefDS(_loop_var_sym_58195);
        _loop_var_sym_58195 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_53678 = _39param_num_53678 + 1;

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58195 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29455 = NOVALUE;

    /** 		Pop_block_var()*/
    _66Pop_block_var();
L6: 

    /** 	SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58195 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29459 = (int)*(((s1_ptr)_2)->base + _loop_var_sym_58195);
    _2 = (int)SEQ_PTR(_29459);
    _29460 = (int)*(((s1_ptr)_2)->base + 5);
    _29459 = NOVALUE;
    if (IS_ATOM_INT(_29460)) {
        {unsigned long tu;
             tu = (unsigned long)_29460 | (unsigned long)3;
             _29461 = MAKE_UINT(tu);
        }
    }
    else {
        _29461 = binary_op(OR_BITS, _29460, 3);
    }
    _29460 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29461;
    if( _1 != _29461 ){
        DeRef(_1);
    }
    _29461 = NOVALUE;
    _29457 = NOVALUE;

    /** 	op_info1 = loop_var_sym*/
    _41op_info1_49774 = _loop_var_sym_58195;

    /** 	emit_op(FOR)*/
    _41emit_op(21);

    /** 	emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58195);

    /** 	if finish_block_header(FOR) then*/
    _29462 = _39finish_block_header(21);
    if (_29462 == 0) {
        DeRef(_29462);
        _29462 = NOVALUE;
        goto L7; // [325] 336
    }
    else {
        if (!IS_ATOM_INT(_29462) && DBL_PTR(_29462)->dbl == 0.0){
            DeRef(_29462);
            _29462 = NOVALUE;
            goto L7; // [325] 336
        }
        DeRef(_29462);
        _29462 = NOVALUE;
    }
    DeRef(_29462);
    _29462 = NOVALUE;

    /** 		CompileErr(83)*/
    RefDS(_21815);
    _44CompileErr(83, _21815, 0);
L7: 

    /** 	entry_addr &= 0*/
    Append(&_39entry_addr_53693, _39entry_addr_53693, 0);

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29464 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29464 = 1;
    }
    _bp1_58186 = _29464 + 1;
    _29464 = NOVALUE;

    /** 	emit_addr(0) -- will be patched - don't straighten*/
    _41emit_addr(0);

    /** 	save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29466 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29466 = 1;
    }
    _29467 = _29466 - 5;
    _29466 = NOVALUE;
    if (IS_SEQUENCE(_35Code_16056)){
            _29468 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29468 = 1;
    }
    _29469 = _29468 - 3;
    _29468 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_58196;
    RHS_Slice(_35Code_16056, _29467, _29469);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58284;
        _i_58284 = 1;
L8: 
        if (_i_58284 > 3){
            goto L9; // [385] 408
        }

        /** 		clear_temp( save_syms[i] )*/
        _2 = (int)SEQ_PTR(_save_syms_58196);
        _29471 = (int)*(((s1_ptr)_2)->base + _i_58284);
        Ref(_29471);
        _41clear_temp(_29471);
        _29471 = NOVALUE;

        /** 	end for*/
        _i_58284 = _i_58284 + 1;
        goto L8; // [403] 392
L9: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** 	bp2 = length(Code)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _bp2_58187 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _bp2_58187 = 1;
    }

    /** 	retry_addr &= bp2 + 1*/
    _29473 = _bp2_58187 + 1;
    Append(&_39retry_addr_53695, _39retry_addr_53695, _29473);
    _29473 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_39continue_addr_53694, _39continue_addr_53694, 0);

    /** 	loop_stack &= FOR*/
    Append(&_39loop_stack_53703, _39loop_stack_53703, 21);

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto LA; // [454] 478

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto LB; // [461] 477
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _41emit_op(87);

    /** 			emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58195);
LB: 
LA: 

    /** 	Statement_list()*/
    _39Statement_list();

    /** 	tok_match(END)*/
    _39tok_match(402, 0);

    /** 	tok_match(FOR, END)*/
    _39tok_match(21, 402);

    /** 	End_block( FOR )*/
    _66End_block(21);

    /** 	StartSourceLine(TRUE, TRANSLATE)*/
    _41StartSourceLine(_13TRUE_437, _35TRANSLATE_15611, 2);

    /** 	op_info1 = loop_var_sym*/
    _41op_info1_49774 = _loop_var_sym_58195;

    /** 	op_info2 = bp2 + 1*/
    _41op_info2_49775 = _bp2_58187 + 1;

    /** 	PatchNList(next_base)*/
    _39PatchNList(_next_base_58189);

    /** 	emit_op(end_op)*/
    _41emit_op(_end_op_58190);

    /** 	backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29479 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29479 = 1;
    }
    _29480 = _29479 + 1;
    _29479 = NOVALUE;
    _41backpatch(_bp1_58186, _29480);
    _29480 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto LC; // [564] 588

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto LD; // [571] 587
    }
    else{
    }

    /** 			emit_op(ERASE_SYMBOL)*/
    _41emit_op(90);

    /** 			emit_addr(loop_var_sym)*/
    _41emit_addr(_loop_var_sym_58195);
LD: 
LC: 

    /** 	Hide(loop_var_sym)*/
    _53Hide(_loop_var_sym_58195);

    /** 	exit_loop(exit_base)*/
    _39exit_loop(_exit_base_58188);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58330;
        _i_58330 = 1;
LE: 
        if (_i_58330 > 3){
            goto LF; // [600] 626
        }

        /** 		emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (int)SEQ_PTR(_save_syms_58196);
        _29482 = (int)*(((s1_ptr)_2)->base + _i_58330);
        Ref(_29482);
        _41emit_temp(_29482, 1);
        _29482 = NOVALUE;

        /** 	end for*/
        _i_58330 = _i_58330 + 1;
        goto LE; // [621] 607
LF: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** end procedure*/
    DeRef(_tok_58192);
    DeRef(_loop_var_58193);
    DeRef(_save_syms_58196);
    DeRef(_29467);
    _29467 = NOVALUE;
    DeRef(_29469);
    _29469 = NOVALUE;
    return;
    ;
}


int _39CompileType(int _type_ptr_58338)
{
    int _t_58339 = NOVALUE;
    int _29493 = NOVALUE;
    int _29492 = NOVALUE;
    int _29491 = NOVALUE;
    int _29485 = NOVALUE;
    int _29484 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_58338)) {
        _1 = (long)(DBL_PTR(_type_ptr_58338)->dbl);
        DeRefDS(_type_ptr_58338);
        _type_ptr_58338 = _1;
    }

    /** 	if type_ptr < 0 then*/
    if (_type_ptr_58338 >= 0)
    goto L1; // [5] 16

    /** 		return type_ptr*/
    return _type_ptr_58338;
L1: 

    /** 	if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29484 = (int)*(((s1_ptr)_2)->base + _type_ptr_58338);
    _2 = (int)SEQ_PTR(_29484);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _29485 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _29485 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _29484 = NOVALUE;
    if (binary_op_a(NOTEQ, _29485, 415)){
        _29485 = NOVALUE;
        goto L2; // [32] 47
    }
    _29485 = NOVALUE;

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** 	elsif type_ptr = integer_type then*/
    if (_type_ptr_58338 != _53integer_type_45721)
    goto L4; // [51] 66

    /** 		return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** 	elsif type_ptr = atom_type then*/
    if (_type_ptr_58338 != _53atom_type_45717)
    goto L5; // [70] 85

    /** 		return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** 	elsif type_ptr = sequence_type then*/
    if (_type_ptr_58338 != _53sequence_type_45719)
    goto L6; // [89] 104

    /** 		return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** 	elsif type_ptr = object_type then*/
    if (_type_ptr_58338 != _53object_type_45715)
    goto L7; // [108] 123

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** 		t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29491 = (int)*(((s1_ptr)_2)->base + _type_ptr_58338);
    _2 = (int)SEQ_PTR(_29491);
    _29492 = (int)*(((s1_ptr)_2)->base + 2);
    _29491 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_29492)){
        _29493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29492)->dbl));
    }
    else{
        _29493 = (int)*(((s1_ptr)_2)->base + _29492);
    }
    _2 = (int)SEQ_PTR(_29493);
    _t_58339 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_58339)){
        _t_58339 = (long)DBL_PTR(_t_58339)->dbl;
    }
    _29493 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_58339 != _53integer_type_45721)
    goto L8; // [155] 170

    /** 			return TYPE_INTEGER*/
    _29492 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** 		elsif t = atom_type then*/
    if (_t_58339 != _53atom_type_45717)
    goto LA; // [174] 189

    /** 			return TYPE_ATOM*/
    _29492 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** 		elsif t = sequence_type then*/
    if (_t_58339 != _53sequence_type_45719)
    goto LB; // [193] 208

    /** 			return TYPE_SEQUENCE*/
    _29492 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** 			return TYPE_OBJECT*/
    _29492 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


int _39get_assigned_sym()
{
    int _29506 = NOVALUE;
    int _29505 = NOVALUE;
    int _29504 = NOVALUE;
    int _29502 = NOVALUE;
    int _29501 = NOVALUE;
    int _29500 = NOVALUE;
    int _29499 = NOVALUE;
    int _29498 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29498 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29498 = 1;
    }
    _29499 = _29498 - 2;
    _29498 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _29500 = (int)*(((s1_ptr)_2)->base + _29499);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 18;
    ((int *)_2)[2] = 113;
    _29501 = MAKE_SEQ(_1);
    _29502 = find_from(_29500, _29501, 1);
    _29500 = NOVALUE;
    DeRefDS(_29501);
    _29501 = NOVALUE;
    if (_29502 != 0)
    goto L1; // [29] 39
    _29502 = NOVALUE;

    /** 		return 0*/
    _29499 = NOVALUE;
    return 0;
L1: 

    /** 	return Code[$-1]*/
    if (IS_SEQUENCE(_35Code_16056)){
            _29504 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29504 = 1;
    }
    _29505 = _29504 - 1;
    _29504 = NOVALUE;
    _2 = (int)SEQ_PTR(_35Code_16056);
    _29506 = (int)*(((s1_ptr)_2)->base + _29505);
    Ref(_29506);
    DeRef(_29499);
    _29499 = NOVALUE;
    _29505 = NOVALUE;
    return _29506;
    ;
}


void _39Assign_Constant(int _sym_58408)
{
    int _valsym_58410 = NOVALUE;
    int _val_58413 = NOVALUE;
    int _29533 = NOVALUE;
    int _29532 = NOVALUE;
    int _29530 = NOVALUE;
    int _29529 = NOVALUE;
    int _29528 = NOVALUE;
    int _29526 = NOVALUE;
    int _29525 = NOVALUE;
    int _29524 = NOVALUE;
    int _29522 = NOVALUE;
    int _29521 = NOVALUE;
    int _29520 = NOVALUE;
    int _29518 = NOVALUE;
    int _29517 = NOVALUE;
    int _29516 = NOVALUE;
    int _29514 = NOVALUE;
    int _29512 = NOVALUE;
    int _29510 = NOVALUE;
    int _29508 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_58410 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58410)) {
        _1 = (long)(DBL_PTR(_valsym_58410)->dbl);
        DeRefDS(_valsym_58410);
        _valsym_58410 = _1;
    }

    /** 	object val = SymTab[valsym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29508 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    DeRef(_val_58413);
    _2 = (int)SEQ_PTR(_29508);
    _val_58413 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_val_58413);
    _29508 = NOVALUE;

    /** 	SymTab[sym][S_OBJ] = val*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    Ref(_val_58413);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _val_58413;
    DeRef(_1);
    _29510 = NOVALUE;

    /** 	SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29512 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** 		SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29516 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    _2 = (int)SEQ_PTR(_29516);
    _29517 = (int)*(((s1_ptr)_2)->base + 36);
    _29516 = NOVALUE;
    Ref(_29517);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29517;
    if( _1 != _29517 ){
        DeRef(_1);
    }
    _29517 = NOVALUE;
    _29514 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29520 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    _2 = (int)SEQ_PTR(_29520);
    _29521 = (int)*(((s1_ptr)_2)->base + 33);
    _29520 = NOVALUE;
    Ref(_29521);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29521;
    if( _1 != _29521 ){
        DeRef(_1);
    }
    _29521 = NOVALUE;
    _29518 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29524 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    _2 = (int)SEQ_PTR(_29524);
    _29525 = (int)*(((s1_ptr)_2)->base + 30);
    _29524 = NOVALUE;
    Ref(_29525);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _29525;
    if( _1 != _29525 ){
        DeRef(_1);
    }
    _29525 = NOVALUE;
    _29522 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29528 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    _2 = (int)SEQ_PTR(_29528);
    _29529 = (int)*(((s1_ptr)_2)->base + 31);
    _29528 = NOVALUE;
    Ref(_29529);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _29529;
    if( _1 != _29529 ){
        DeRef(_1);
    }
    _29529 = NOVALUE;
    _29526 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58408 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29532 = (int)*(((s1_ptr)_2)->base + _valsym_58410);
    _2 = (int)SEQ_PTR(_29532);
    _29533 = (int)*(((s1_ptr)_2)->base + 32);
    _29532 = NOVALUE;
    Ref(_29533);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29533;
    if( _1 != _29533 ){
        DeRef(_1);
    }
    _29533 = NOVALUE;
    _29530 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_val_58413);
    return;
    ;
}


int _39Global_declaration(int _type_ptr_58470, int _scope_58471)
{
    int _new_symbols_58472 = NOVALUE;
    int _tok_58474 = NOVALUE;
    int _tsym_58475 = NOVALUE;
    int _prevtok_58476 = NOVALUE;
    int _sym_58478 = NOVALUE;
    int _valsym_58479 = NOVALUE;
    int _h_58480 = NOVALUE;
    int _count_58481 = NOVALUE;
    int _val_58482 = NOVALUE;
    int _usedval_58483 = NOVALUE;
    int _deltafunc_58484 = NOVALUE;
    int _delta_58485 = NOVALUE;
    int _is_fwd_ref_58486 = NOVALUE;
    int _ptok_58503 = NOVALUE;
    int _negate_58519 = NOVALUE;
    int _negate_58765 = NOVALUE;
    int _31363 = NOVALUE;
    int _31362 = NOVALUE;
    int _31361 = NOVALUE;
    int _29773 = NOVALUE;
    int _29771 = NOVALUE;
    int _29769 = NOVALUE;
    int _29767 = NOVALUE;
    int _29765 = NOVALUE;
    int _29762 = NOVALUE;
    int _29760 = NOVALUE;
    int _29759 = NOVALUE;
    int _29758 = NOVALUE;
    int _29757 = NOVALUE;
    int _29756 = NOVALUE;
    int _29755 = NOVALUE;
    int _29753 = NOVALUE;
    int _29749 = NOVALUE;
    int _29747 = NOVALUE;
    int _29745 = NOVALUE;
    int _29743 = NOVALUE;
    int _29741 = NOVALUE;
    int _29739 = NOVALUE;
    int _29738 = NOVALUE;
    int _29736 = NOVALUE;
    int _29735 = NOVALUE;
    int _29734 = NOVALUE;
    int _29732 = NOVALUE;
    int _29730 = NOVALUE;
    int _29728 = NOVALUE;
    int _29727 = NOVALUE;
    int _29726 = NOVALUE;
    int _29724 = NOVALUE;
    int _29723 = NOVALUE;
    int _29722 = NOVALUE;
    int _29720 = NOVALUE;
    int _29718 = NOVALUE;
    int _29716 = NOVALUE;
    int _29715 = NOVALUE;
    int _29714 = NOVALUE;
    int _29713 = NOVALUE;
    int _29712 = NOVALUE;
    int _29709 = NOVALUE;
    int _29707 = NOVALUE;
    int _29705 = NOVALUE;
    int _29704 = NOVALUE;
    int _29703 = NOVALUE;
    int _29699 = NOVALUE;
    int _29698 = NOVALUE;
    int _29697 = NOVALUE;
    int _29693 = NOVALUE;
    int _29692 = NOVALUE;
    int _29691 = NOVALUE;
    int _29689 = NOVALUE;
    int _29688 = NOVALUE;
    int _29687 = NOVALUE;
    int _29686 = NOVALUE;
    int _29685 = NOVALUE;
    int _29684 = NOVALUE;
    int _29683 = NOVALUE;
    int _29682 = NOVALUE;
    int _29681 = NOVALUE;
    int _29678 = NOVALUE;
    int _29676 = NOVALUE;
    int _29675 = NOVALUE;
    int _29673 = NOVALUE;
    int _29672 = NOVALUE;
    int _29670 = NOVALUE;
    int _29669 = NOVALUE;
    int _29668 = NOVALUE;
    int _29667 = NOVALUE;
    int _29665 = NOVALUE;
    int _29663 = NOVALUE;
    int _29661 = NOVALUE;
    int _29658 = NOVALUE;
    int _29655 = NOVALUE;
    int _29652 = NOVALUE;
    int _29650 = NOVALUE;
    int _29649 = NOVALUE;
    int _29648 = NOVALUE;
    int _29647 = NOVALUE;
    int _29645 = NOVALUE;
    int _29644 = NOVALUE;
    int _29643 = NOVALUE;
    int _29642 = NOVALUE;
    int _29638 = NOVALUE;
    int _29637 = NOVALUE;
    int _29636 = NOVALUE;
    int _29635 = NOVALUE;
    int _29634 = NOVALUE;
    int _29633 = NOVALUE;
    int _29630 = NOVALUE;
    int _29628 = NOVALUE;
    int _29627 = NOVALUE;
    int _29626 = NOVALUE;
    int _29625 = NOVALUE;
    int _29624 = NOVALUE;
    int _29621 = NOVALUE;
    int _29619 = NOVALUE;
    int _29617 = NOVALUE;
    int _29616 = NOVALUE;
    int _29615 = NOVALUE;
    int _29614 = NOVALUE;
    int _29613 = NOVALUE;
    int _29612 = NOVALUE;
    int _29611 = NOVALUE;
    int _29609 = NOVALUE;
    int _29606 = NOVALUE;
    int _29604 = NOVALUE;
    int _29603 = NOVALUE;
    int _29602 = NOVALUE;
    int _29601 = NOVALUE;
    int _29600 = NOVALUE;
    int _29599 = NOVALUE;
    int _29598 = NOVALUE;
    int _29597 = NOVALUE;
    int _29594 = NOVALUE;
    int _29593 = NOVALUE;
    int _29592 = NOVALUE;
    int _29590 = NOVALUE;
    int _29589 = NOVALUE;
    int _29588 = NOVALUE;
    int _29587 = NOVALUE;
    int _29586 = NOVALUE;
    int _29584 = NOVALUE;
    int _29583 = NOVALUE;
    int _29582 = NOVALUE;
    int _29580 = NOVALUE;
    int _29579 = NOVALUE;
    int _29577 = NOVALUE;
    int _29574 = NOVALUE;
    int _29572 = NOVALUE;
    int _29570 = NOVALUE;
    int _29562 = NOVALUE;
    int _29561 = NOVALUE;
    int _29559 = NOVALUE;
    int _29556 = NOVALUE;
    int _29549 = NOVALUE;
    int _29546 = NOVALUE;
    int _29545 = NOVALUE;
    int _29543 = NOVALUE;
    int _29539 = NOVALUE;
    int _29538 = NOVALUE;
    int _29537 = NOVALUE;
    int _29536 = NOVALUE;
    int _29535 = NOVALUE;
    int _29534 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_58470)) {
        _1 = (long)(DBL_PTR(_type_ptr_58470)->dbl);
        DeRefDS(_type_ptr_58470);
        _type_ptr_58470 = _1;
    }

    /** 	object tsym*/

    /** 	object prevtok = 0*/
    DeRef(_prevtok_58476);
    _prevtok_58476 = 0;

    /** 	integer h, count = 0*/
    _count_58481 = 0;

    /** 	atom val = 1, usedval*/
    DeRef(_val_58482);
    _val_58482 = 1;

    /** 	integer deltafunc = '+'*/
    _deltafunc_58484 = 43;

    /** 	atom delta = 1*/
    DeRef(_delta_58485);
    _delta_58485 = 1;

    /** 	new_symbols = {}*/
    RefDS(_21815);
    DeRefi(_new_symbols_58472);
    _new_symbols_58472 = _21815;

    /** 	integer is_fwd_ref = 0*/
    _is_fwd_ref_58486 = 0;

    /** 	if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29534 = (_type_ptr_58470 > 0);
    if (_29534 == 0) {
        goto L1; // [50] 105
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29536 = (int)*(((s1_ptr)_2)->base + _type_ptr_58470);
    _2 = (int)SEQ_PTR(_29536);
    _29537 = (int)*(((s1_ptr)_2)->base + 4);
    _29536 = NOVALUE;
    if (IS_ATOM_INT(_29537)) {
        _29538 = (_29537 == 9);
    }
    else {
        _29538 = binary_op(EQUALS, _29537, 9);
    }
    _29537 = NOVALUE;
    if (_29538 == 0) {
        DeRef(_29538);
        _29538 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29538) && DBL_PTR(_29538)->dbl == 0.0){
            DeRef(_29538);
            _29538 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29538);
        _29538 = NOVALUE;
    }
    DeRef(_29538);
    _29538 = NOVALUE;

    /** 		is_fwd_ref = 1*/
    _is_fwd_ref_58486 = 1;

    /** 		Hide(type_ptr)*/
    _53Hide(_type_ptr_58470);

    /** 		type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31363);
    _31363 = 504;
    _29539 = _38new_forward_reference(504, _type_ptr_58470, 504);
    _31363 = NOVALUE;
    if (IS_ATOM_INT(_29539)) {
        if ((unsigned long)_29539 == 0xC0000000)
        _type_ptr_58470 = (int)NewDouble((double)-0xC0000000);
        else
        _type_ptr_58470 = - _29539;
    }
    else {
        _type_ptr_58470 = unary_op(UMINUS, _29539);
    }
    DeRef(_29539);
    _29539 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_58470)) {
        _1 = (long)(DBL_PTR(_type_ptr_58470)->dbl);
        DeRefDS(_type_ptr_58470);
        _type_ptr_58470 = _1;
    }
L1: 

    /** 	if type_ptr = -1 then*/
    if (_type_ptr_58470 != -1)
    goto L2; // [107] 423

    /** 		sequence ptok = next_token()*/
    _0 = _ptok_58503;
    _ptok_58503 = _39next_token();
    DeRef(_0);

    /** 		if ptok[T_ID] = TYPE_DECL then*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29543 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29543, 416)){
        _29543 = NOVALUE;
        goto L3; // [128] 171
    }
    _29543 = NOVALUE;

    /** 			putback(keyfind("enum",-1))*/
    RefDS(_26036);
    DeRef(_31361);
    _31361 = _26036;
    _31362 = _53hashfn(_31361);
    _31361 = NOVALUE;
    RefDS(_26036);
    _29545 = _53keyfind(_26036, -1, _35current_file_no_15968, 0, _31362);
    _31362 = NOVALUE;
    _39putback(_29545);
    _29545 = NOVALUE;

    /** 			SubProg(TYPE_DECL, scope)*/
    _39SubProg(416, _scope_58471);

    /** 			return {}*/
    RefDS(_21815);
    DeRefDS(_ptok_58503);
    DeRefi(_new_symbols_58472);
    DeRef(_tok_58474);
    DeRef(_tsym_58475);
    DeRef(_prevtok_58476);
    DeRef(_val_58482);
    DeRef(_usedval_58483);
    DeRef(_delta_58485);
    DeRef(_29534);
    _29534 = NOVALUE;
    return _21815;
    goto L4; // [168] 422
L3: 

    /** 		elsif ptok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29546 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29546, 404)){
        _29546 = NOVALUE;
        goto L5; // [181] 416
    }
    _29546 = NOVALUE;

    /** 			integer negate = 0*/
    _negate_58519 = 0;

    /** 			ptok = next_token()*/
    _0 = _ptok_58503;
    _ptok_58503 = _39next_token();
    DeRefDS(_0);

    /** 			switch ptok[T_ID] do*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29549 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29549) ){
        goto L6; // [205] 284
    }
    if(!IS_ATOM_INT(_29549)){
        if( (DBL_PTR(_29549)->dbl != (double) ((int) DBL_PTR(_29549)->dbl) ) ){
            goto L6; // [205] 284
        }
        _0 = (int) DBL_PTR(_29549)->dbl;
    }
    else {
        _0 = _29549;
    };
    _29549 = NOVALUE;
    switch ( _0 ){ 

        /** 				case reserved:MULTIPLY then*/
        case 13:

        /** 					deltafunc = '*'*/
        _deltafunc_58484 = 42;

        /** 					ptok = next_token()*/
        _0 = _ptok_58503;
        _ptok_58503 = _39next_token();
        DeRef(_0);
        goto L7; // [226] 292

        /** 				case reserved:DIVIDE then*/
        case 14:

        /** 					deltafunc = '/'*/
        _deltafunc_58484 = 47;

        /** 					ptok = next_token()*/
        _0 = _ptok_58503;
        _ptok_58503 = _39next_token();
        DeRef(_0);
        goto L7; // [244] 292

        /** 				case MINUS then*/
        case 10:

        /** 					deltafunc = '-'*/
        _deltafunc_58484 = 45;

        /** 					ptok = next_token()*/
        _0 = _ptok_58503;
        _ptok_58503 = _39next_token();
        DeRef(_0);
        goto L7; // [262] 292

        /** 				case PLUS then*/
        case 11:

        /** 					deltafunc = '+'*/
        _deltafunc_58484 = 43;

        /** 					ptok = next_token()*/
        _0 = _ptok_58503;
        _ptok_58503 = _39next_token();
        DeRef(_0);
        goto L7; // [280] 292

        /** 				case else*/
        default:
L6: 

        /** 					deltafunc = '+'*/
        _deltafunc_58484 = 43;
    ;}L7: 

    /** 			if ptok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29556 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29556, 10)){
        _29556 = NOVALUE;
        goto L8; // [302] 319
    }
    _29556 = NOVALUE;

    /** 				negate = 1*/
    _negate_58519 = 1;

    /** 				ptok = next_token()*/
    _0 = _ptok_58503;
    _ptok_58503 = _39next_token();
    DeRefDS(_0);
L8: 

    /** 			if ptok[T_ID] != ATOM then*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29559 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29559, 502)){
        _29559 = NOVALUE;
        goto L9; // [329] 341
    }
    _29559 = NOVALUE;

    /** 				CompileErr( 344 )*/
    RefDS(_21815);
    _44CompileErr(344, _21815, 0);
L9: 

    /** 			delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_ptok_58503);
    _29561 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_29561)){
        _29562 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29561)->dbl));
    }
    else{
        _29562 = (int)*(((s1_ptr)_2)->base + _29561);
    }
    DeRef(_delta_58485);
    _2 = (int)SEQ_PTR(_29562);
    _delta_58485 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_58485);
    _29562 = NOVALUE;

    /** 			if negate then*/
    if (_negate_58519 == 0)
    {
        goto LA; // [363] 372
    }
    else{
    }

    /** 				delta = -delta*/
    _0 = _delta_58485;
    if (IS_ATOM_INT(_delta_58485)) {
        if ((unsigned long)_delta_58485 == 0xC0000000)
        _delta_58485 = (int)NewDouble((double)-0xC0000000);
        else
        _delta_58485 = - _delta_58485;
    }
    else {
        _delta_58485 = unary_op(UMINUS, _delta_58485);
    }
    DeRef(_0);
LA: 

    /** 			switch deltafunc do*/
    _0 = _deltafunc_58484;
    switch ( _0 ){ 

        /** 				case '/' then*/
        case 47:

        /** 					delta = 1 / delta*/
        _0 = _delta_58485;
        if (IS_ATOM_INT(_delta_58485)) {
            _delta_58485 = (1 % _delta_58485) ? NewDouble((double)1 / _delta_58485) : (1 / _delta_58485);
        }
        else {
            _delta_58485 = NewDouble((double)1 / DBL_PTR(_delta_58485)->dbl);
        }
        DeRef(_0);

        /** 					deltafunc = '*'*/
        _deltafunc_58484 = 42;
        goto LB; // [394] 411

        /** 				case '-' then*/
        case 45:

        /** 					delta = -delta*/
        _0 = _delta_58485;
        if (IS_ATOM_INT(_delta_58485)) {
            if ((unsigned long)_delta_58485 == 0xC0000000)
            _delta_58485 = (int)NewDouble((double)-0xC0000000);
            else
            _delta_58485 = - _delta_58485;
        }
        else {
            _delta_58485 = unary_op(UMINUS, _delta_58485);
        }
        DeRef(_0);

        /** 					deltafunc = '+'*/
        _deltafunc_58484 = 43;
    ;}LB: 
    goto L4; // [413] 422
L5: 

    /** 			putback(ptok)*/
    RefDS(_ptok_58503);
    _39putback(_ptok_58503);
L4: 
L2: 
    DeRef(_ptok_58503);
    _ptok_58503 = NOVALUE;

    /** 	valsym = 0*/
    _valsym_58479 = 0;

    /** 	while TRUE do*/
LC: 
    if (_13TRUE_437 == 0)
    {
        goto LD; // [439] 2282
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = DOLLAR then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29570 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29570, -22)){
        _29570 = NOVALUE;
        goto LE; // [457] 496
    }
    _29570 = NOVALUE;

    /** 			if not equal(prevtok, 0) then*/
    if (_prevtok_58476 == 0)
    _29572 = 1;
    else if (IS_ATOM_INT(_prevtok_58476) && IS_ATOM_INT(0))
    _29572 = 0;
    else
    _29572 = (compare(_prevtok_58476, 0) == 0);
    if (_29572 != 0)
    goto LF; // [467] 495
    _29572 = NOVALUE;

    /** 				if prevtok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_prevtok_58476);
    _29574 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29574, -30)){
        _29574 = NOVALUE;
        goto L10; // [480] 494
    }
    _29574 = NOVALUE;

    /** 					tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /** 					exit*/
    goto LD; // [491] 2282
L10: 
LF: 
LE: 

    /** 		if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29577 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29577, -21)){
        _29577 = NOVALUE;
        goto L11; // [506] 518
    }
    _29577 = NOVALUE;

    /** 			CompileErr( 32 )*/
    RefDS(_21815);
    _44CompileErr(32, _21815, 0);
L11: 

    /** 		if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29579 = (int)*(((s1_ptr)_2)->base + 1);
    _29580 = find_from(_29579, _37ADDR_TOKS_15598, 1);
    _29579 = NOVALUE;
    if (_29580 != 0)
    goto L12; // [533] 558
    _29580 = NOVALUE;

    /** 			CompileErr(25, {find_category(tok[T_ID])} )*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29582 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29582);
    _29583 = _63find_category(_29582);
    _29582 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29583;
    _29584 = MAKE_SEQ(_1);
    _29583 = NOVALUE;
    _44CompileErr(25, _29584, 0);
    _29584 = NOVALUE;
L12: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _sym_58478 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_58478)){
        _sym_58478 = (long)DBL_PTR(_sym_58478)->dbl;
    }

    /** 		DefinedYet(sym)*/
    _53DefinedYet(_sym_58478);

    /** 		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29586 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29586);
    _29587 = (int)*(((s1_ptr)_2)->base + 4);
    _29586 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 7;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    _29588 = MAKE_SEQ(_1);
    _29589 = find_from(_29587, _29588, 1);
    _29587 = NOVALUE;
    DeRefDS(_29588);
    _29588 = NOVALUE;
    if (_29589 == 0)
    {
        _29589 = NOVALUE;
        goto L13; // [607] 669
    }
    else{
        _29589 = NOVALUE;
    }

    /** 			h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29590 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29590);
    _h_58480 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_58480)){
        _h_58480 = (long)DBL_PTR(_h_58480)->dbl;
    }
    _29590 = NOVALUE;

    /** 			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29592 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29592);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _29593 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _29593 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _29592 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _29594 = (int)*(((s1_ptr)_2)->base + _h_58480);
    Ref(_29593);
    Ref(_29594);
    _sym_58478 = _53NewEntry(_29593, 0, 0, -100, _h_58480, _29594, 0);
    _29593 = NOVALUE;
    _29594 = NOVALUE;
    if (!IS_ATOM_INT(_sym_58478)) {
        _1 = (long)(DBL_PTR(_sym_58478)->dbl);
        DeRefDS(_sym_58478);
        _sym_58478 = _1;
    }

    /** 			buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _2 = (int)(((s1_ptr)_2)->base + _h_58480);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58478;
    DeRef(_1);
L13: 

    /** 		new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_58472, _new_symbols_58472, _sym_58478);

    /** 		Block_var( sym )*/
    _66Block_var(_sym_58478);

    /** 		if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29597 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29597);
    _29598 = (int)*(((s1_ptr)_2)->base + 4);
    _29597 = NOVALUE;
    if (IS_ATOM_INT(_29598)) {
        _29599 = (_29598 == 9);
    }
    else {
        _29599 = binary_op(EQUALS, _29598, 9);
    }
    _29598 = NOVALUE;
    if (IS_ATOM_INT(_29599)) {
        if (_29599 == 0) {
            goto L14; // [700] 744
        }
    }
    else {
        if (DBL_PTR(_29599)->dbl == 0.0) {
            goto L14; // [700] 744
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29601 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29601);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _29602 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _29602 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _29601 = NOVALUE;
    if (IS_ATOM_INT(_29602)) {
        _29603 = (_29602 != _35current_file_no_15968);
    }
    else {
        _29603 = binary_op(NOTEQ, _29602, _35current_file_no_15968);
    }
    _29602 = NOVALUE;
    if (_29603 == 0) {
        DeRef(_29603);
        _29603 = NOVALUE;
        goto L14; // [723] 744
    }
    else {
        if (!IS_ATOM_INT(_29603) && DBL_PTR(_29603)->dbl == 0.0){
            DeRef(_29603);
            _29603 = NOVALUE;
            goto L14; // [723] 744
        }
        DeRef(_29603);
        _29603 = NOVALUE;
    }
    DeRef(_29603);
    _29603 = NOVALUE;

    /** 			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15637))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);
    _29604 = NOVALUE;
L14: 

    /** 		SymTab[sym][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_58471;
    DeRef(_1);
    _29606 = NOVALUE;

    /** 		if type_ptr = 0 then*/
    if (_type_ptr_58470 != 0)
    goto L15; // [761] 1096

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29609 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29611 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29611);
    _29612 = (int)*(((s1_ptr)_2)->base + 11);
    _29611 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29613 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29613);
    _29614 = (int)*(((s1_ptr)_2)->base + 9);
    _29613 = NOVALUE;
    Ref(_29614);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_29612))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29612)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29612);
    _1 = *(int *)_2;
    *(int *)_2 = _29614;
    if( _1 != _29614 ){
        DeRef(_1);
    }
    _29614 = NOVALUE;

    /** 			tok_match(EQUALS)*/
    _39tok_match(3, 0);

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _41StartSourceLine(_13FALSE_435, 0, 3);

    /** 			emit_opnd(sym)*/
    _41emit_opnd(_sym_58478);

    /** 			Expr()  -- no new symbols can be defined in here*/
    _39Expr();

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29615 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29615);
    _29616 = (int)*(((s1_ptr)_2)->base + 11);
    _29615 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_29616))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29616)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29616);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58478;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29617 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L16; // [883] 921
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29619 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    _29621 = NOVALUE;
L16: 

    /** 			valsym = Top()*/
    _valsym_58479 = _41Top();
    if (!IS_ATOM_INT(_valsym_58479)) {
        _1 = (long)(DBL_PTR(_valsym_58479)->dbl);
        DeRefDS(_valsym_58479);
        _valsym_58479 = _1;
    }

    /** 			if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29624 = (_valsym_58479 > 0);
    if (_29624 == 0) {
        goto L17; // [934] 975
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29626 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29626);
    _29627 = (int)*(((s1_ptr)_2)->base + 1);
    _29626 = NOVALUE;
    if (IS_ATOM_INT(_29627) && IS_ATOM_INT(_35NOVALUE_15823)){
        _29628 = (_29627 < _35NOVALUE_15823) ? -1 : (_29627 > _35NOVALUE_15823);
    }
    else{
        _29628 = compare(_29627, _35NOVALUE_15823);
    }
    _29627 = NOVALUE;
    if (_29628 == 0)
    {
        _29628 = NOVALUE;
        goto L17; // [957] 975
    }
    else{
        _29628 = NOVALUE;
    }

    /** 				Assign_Constant( sym )*/
    _39Assign_Constant(_sym_58478);

    /** 				sym = Pop()*/
    _sym_58478 = _41Pop();
    if (!IS_ATOM_INT(_sym_58478)) {
        _1 = (long)(DBL_PTR(_sym_58478)->dbl);
        DeRefDS(_sym_58478);
        _sym_58478 = _1;
    }
    goto L18; // [972] 2248
L17: 

    /** 				emit_op(ASSIGN)*/
    _41emit_op(18);

    /** 				if Last_op() = ASSIGN then*/
    _29630 = _41Last_op();
    if (binary_op_a(NOTEQ, _29630, 18)){
        DeRef(_29630);
        _29630 = NOVALUE;
        goto L19; // [989] 1003
    }
    DeRef(_29630);
    _29630 = NOVALUE;

    /** 					valsym = get_assigned_sym()*/
    _valsym_58479 = _39get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_58479)) {
        _1 = (long)(DBL_PTR(_valsym_58479)->dbl);
        DeRefDS(_valsym_58479);
        _valsym_58479 = _1;
    }
    goto L1A; // [1000] 1011
L19: 

    /** 					valsym = -1*/
    _valsym_58479 = -1;
L1A: 

    /** 				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29633 = (_valsym_58479 > 0);
    if (_29633 == 0) {
        goto L1B; // [1017] 1059
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29635 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29635);
    _29636 = (int)*(((s1_ptr)_2)->base + 1);
    _29635 = NOVALUE;
    if (IS_ATOM_INT(_29636) && IS_ATOM_INT(_35NOVALUE_15823)){
        _29637 = (_29636 < _35NOVALUE_15823) ? -1 : (_29636 > _35NOVALUE_15823);
    }
    else{
        _29637 = compare(_29636, _35NOVALUE_15823);
    }
    _29636 = NOVALUE;
    if (_29637 == 0)
    {
        _29637 = NOVALUE;
        goto L1B; // [1040] 1059
    }
    else{
        _29637 = NOVALUE;
    }

    /** 					SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58479;
    DeRef(_1);
    _29638 = NOVALUE;
L1B: 

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L18; // [1063] 2248
    }
    else{
    }

    /** 					count += 1*/
    _count_58481 = _count_58481 + 1;

    /** 					if count = 10 then*/
    if (_count_58481 != 10)
    goto L18; // [1074] 2248

    /** 						count = 0*/
    _count_58481 = 0;

    /** 						emit_op( RETURNT )*/
    _41emit_op(34);
    goto L18; // [1093] 2248
L15: 

    /** 		elsif type_ptr = -1 and not is_fwd_ref then*/
    _29642 = (_type_ptr_58470 == -1);
    if (_29642 == 0) {
        goto L1C; // [1102] 2075
    }
    _29644 = (_is_fwd_ref_58486 == 0);
    if (_29644 == 0)
    {
        DeRef(_29644);
        _29644 = NOVALUE;
        goto L1C; // [1110] 2075
    }
    else{
        DeRef(_29644);
        _29644 = NOVALUE;
    }

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_435, 0, 3);

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29645 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29647 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29647);
    _29648 = (int)*(((s1_ptr)_2)->base + 11);
    _29647 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29649 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29649);
    _29650 = (int)*(((s1_ptr)_2)->base + 9);
    _29649 = NOVALUE;
    Ref(_29650);
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_29648))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29648)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29648);
    _1 = *(int *)_2;
    *(int *)_2 = _29650;
    if( _1 != _29650 ){
        DeRef(_1);
    }
    _29650 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /** 			emit_opnd(sym)*/
    _41emit_opnd(_sym_58478);

    /** 			if tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29652 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29652, 3)){
        _29652 = NOVALUE;
        goto L1D; // [1193] 1588
    }
    _29652 = NOVALUE;

    /** 				integer negate = 1*/
    _negate_58765 = 1;

    /** 				tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29655 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29655, 10)){
        _29655 = NOVALUE;
        goto L1E; // [1217] 1232
    }
    _29655 = NOVALUE;

    /** 					negate = -1*/
    _negate_58765 = -1;

    /** 					tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);
L1E: 

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29658 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29658, 502)){
        _29658 = NOVALUE;
        goto L1F; // [1242] 1259
    }
    _29658 = NOVALUE;

    /** 					valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _valsym_58479 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58479)){
        _valsym_58479 = (long)DBL_PTR(_valsym_58479)->dbl;
    }
    goto L20; // [1256] 1448
L1F: 

    /** 				elsif tok[T_SYM] > 0 then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29661 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _29661, 0)){
        _29661 = NOVALUE;
        goto L21; // [1267] 1440
    }
    _29661 = NOVALUE;

    /** 					tsym = SymTab[tok[T_SYM]]*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29663 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_58475);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_29663)){
        _tsym_58475 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29663)->dbl));
    }
    else{
        _tsym_58475 = (int)*(((s1_ptr)_2)->base + _29663);
    }
    Ref(_tsym_58475);

    /** 					if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_tsym_58475);
    _29665 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _29665, 2)){
        _29665 = NOVALUE;
        goto L22; // [1295] 1403
    }
    _29665 = NOVALUE;

    /** 						if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_58475)){
            _29667 = SEQ_PTR(_tsym_58475)->length;
    }
    else {
        _29667 = 1;
    }
    if (IS_ATOM_INT(_35S_CODE_15653)) {
        _29668 = (_29667 >= _35S_CODE_15653);
    }
    else {
        _29668 = binary_op(GREATEREQ, _29667, _35S_CODE_15653);
    }
    _29667 = NOVALUE;
    if (IS_ATOM_INT(_29668)) {
        if (_29668 == 0) {
            goto L23; // [1310] 1337
        }
    }
    else {
        if (DBL_PTR(_29668)->dbl == 0.0) {
            goto L23; // [1310] 1337
        }
    }
    _2 = (int)SEQ_PTR(_tsym_58475);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _29670 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _29670 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    if (_29670 == 0) {
        _29670 = NOVALUE;
        goto L23; // [1321] 1337
    }
    else {
        if (!IS_ATOM_INT(_29670) && DBL_PTR(_29670)->dbl == 0.0){
            _29670 = NOVALUE;
            goto L23; // [1321] 1337
        }
        _29670 = NOVALUE;
    }
    _29670 = NOVALUE;

    /** 							valsym = tsym[S_CODE]*/
    _2 = (int)SEQ_PTR(_tsym_58475);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _valsym_58479 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _valsym_58479 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    if (!IS_ATOM_INT(_valsym_58479)){
        _valsym_58479 = (long)DBL_PTR(_valsym_58479)->dbl;
    }
    goto L20; // [1334] 1448
L23: 

    /** 						elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_tsym_58475);
    _29672 = (int)*(((s1_ptr)_2)->base + 1);
    if (_29672 == _35NOVALUE_15823)
    _29673 = 1;
    else if (IS_ATOM_INT(_29672) && IS_ATOM_INT(_35NOVALUE_15823))
    _29673 = 0;
    else
    _29673 = (compare(_29672, _35NOVALUE_15823) == 0);
    _29672 = NOVALUE;
    if (_29673 != 0)
    goto L24; // [1351] 1392
    _29673 = NOVALUE;

    /** 							if integer(tsym[S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tsym_58475);
    _29675 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29675))
    _29676 = 1;
    else if (IS_ATOM_DBL(_29675))
    _29676 = IS_ATOM_INT(DoubleToInt(_29675));
    else
    _29676 = 0;
    _29675 = NOVALUE;
    if (_29676 == 0)
    {
        _29676 = NOVALUE;
        goto L25; // [1365] 1381
    }
    else{
        _29676 = NOVALUE;
    }

    /** 								valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _valsym_58479 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58479)){
        _valsym_58479 = (long)DBL_PTR(_valsym_58479)->dbl;
    }
    goto L20; // [1378] 1448
L25: 

    /** 								CompileErr(30)*/
    RefDS(_21815);
    _44CompileErr(30, _21815, 0);
    goto L20; // [1389] 1448
L24: 

    /** 							CompileErr(70)*/
    RefDS(_21815);
    _44CompileErr(70, _21815, 0);
    goto L20; // [1400] 1448
L22: 

    /** 					elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_tsym_58475);
    _29678 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29678, _35NOVALUE_15823)){
        _29678 = NOVALUE;
        goto L26; // [1413] 1429
    }
    _29678 = NOVALUE;

    /** 						CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_21815);
    _44CompileErr(331, _21815, 0);
    goto L20; // [1426] 1448
L26: 

    /** 						CompileErr(99)*/
    RefDS(_21815);
    _44CompileErr(99, _21815, 0);
    goto L20; // [1437] 1448
L21: 

    /** 						CompileErr(99)*/
    RefDS(_21815);
    _44CompileErr(99, _21815, 0);
L20: 

    /** 				valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _valsym_58479 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58479)){
        _valsym_58479 = (long)DBL_PTR(_valsym_58479)->dbl;
    }

    /** 				if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29681 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29681);
    _29682 = (int)*(((s1_ptr)_2)->base + 1);
    _29681 = NOVALUE;
    _29683 = IS_ATOM(_29682);
    _29682 = NOVALUE;
    _29684 = (_29683 == 0);
    _29683 = NOVALUE;
    if (_29684 == 0) {
        goto L27; // [1478] 1508
    }
    _2 = (int)SEQ_PTR(_tsym_58475);
    _29686 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_29686)) {
        _29687 = (_29686 != 9);
    }
    else {
        _29687 = binary_op(NOTEQ, _29686, 9);
    }
    _29686 = NOVALUE;
    if (_29687 == 0) {
        DeRef(_29687);
        _29687 = NOVALUE;
        goto L27; // [1497] 1508
    }
    else {
        if (!IS_ATOM_INT(_29687) && DBL_PTR(_29687)->dbl == 0.0){
            DeRef(_29687);
            _29687 = NOVALUE;
            goto L27; // [1497] 1508
        }
        DeRef(_29687);
        _29687 = NOVALUE;
    }
    DeRef(_29687);
    _29687 = NOVALUE;

    /** 					CompileErr(84)*/
    RefDS(_21815);
    _44CompileErr(84, _21815, 0);
L27: 

    /** 				val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29688 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29688);
    _29689 = (int)*(((s1_ptr)_2)->base + 1);
    _29688 = NOVALUE;
    DeRef(_val_58482);
    if (IS_ATOM_INT(_29689)) {
        if (_29689 == (short)_29689 && _negate_58765 <= INT15 && _negate_58765 >= -INT15)
        _val_58482 = _29689 * _negate_58765;
        else
        _val_58482 = NewDouble(_29689 * (double)_negate_58765);
    }
    else {
        _val_58482 = binary_op(MULTIPLY, _29689, _negate_58765);
    }
    _29689 = NOVALUE;

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58482))
    _29691 = 1;
    else if (IS_ATOM_DBL(_val_58482))
    _29691 = IS_ATOM_INT(DoubleToInt(_val_58482));
    else
    _29691 = 0;
    if (_29691 == 0)
    {
        _29691 = NOVALUE;
        goto L28; // [1531] 1546
    }
    else{
        _29691 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58482);
    _29692 = _53NewIntSym(_val_58482);
    _41Push(_29692);
    _29692 = NOVALUE;
    goto L29; // [1543] 1556
L28: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58482);
    _29693 = _53NewDoubleSym(_val_58482);
    _41Push(_29693);
    _29693 = NOVALUE;
L29: 

    /** 				usedval = val*/
    Ref(_val_58482);
    DeRef(_usedval_58483);
    _usedval_58483 = _val_58482;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58484 != 43)
    goto L2A; // [1563] 1576

    /** 					val += delta*/
    _0 = _val_58482;
    if (IS_ATOM_INT(_val_58482) && IS_ATOM_INT(_delta_58485)) {
        _val_58482 = _val_58482 + _delta_58485;
        if ((long)((unsigned long)_val_58482 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58482 = NewDouble((double)_val_58482);
    }
    else {
        if (IS_ATOM_INT(_val_58482)) {
            _val_58482 = NewDouble((double)_val_58482 + DBL_PTR(_delta_58485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58485)) {
                _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl + (double)_delta_58485);
            }
            else
            _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl + DBL_PTR(_delta_58485)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1573] 1583
L2A: 

    /** 					val *= delta*/
    _0 = _val_58482;
    if (IS_ATOM_INT(_val_58482) && IS_ATOM_INT(_delta_58485)) {
        if (_val_58482 == (short)_val_58482 && _delta_58485 <= INT15 && _delta_58485 >= -INT15)
        _val_58482 = _val_58482 * _delta_58485;
        else
        _val_58482 = NewDouble(_val_58482 * (double)_delta_58485);
    }
    else {
        if (IS_ATOM_INT(_val_58482)) {
            _val_58482 = NewDouble((double)_val_58482 * DBL_PTR(_delta_58485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58485)) {
                _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl * (double)_delta_58485);
            }
            else
            _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl * DBL_PTR(_delta_58485)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1585] 1658
L1D: 

    /** 				putback(tok)*/
    Ref(_tok_58474);
    _39putback(_tok_58474);

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58482))
    _29697 = 1;
    else if (IS_ATOM_DBL(_val_58482))
    _29697 = IS_ATOM_INT(DoubleToInt(_val_58482));
    else
    _29697 = 0;
    if (_29697 == 0)
    {
        _29697 = NOVALUE;
        goto L2D; // [1598] 1613
    }
    else{
        _29697 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58482);
    _29698 = _53NewIntSym(_val_58482);
    _41Push(_29698);
    _29698 = NOVALUE;
    goto L2E; // [1610] 1623
L2D: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58482);
    _29699 = _53NewDoubleSym(_val_58482);
    _41Push(_29699);
    _29699 = NOVALUE;
L2E: 

    /** 				usedval = val*/
    Ref(_val_58482);
    DeRef(_usedval_58483);
    _usedval_58483 = _val_58482;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58484 != 43)
    goto L2F; // [1630] 1643

    /** 					val += delta*/
    _0 = _val_58482;
    if (IS_ATOM_INT(_val_58482) && IS_ATOM_INT(_delta_58485)) {
        _val_58482 = _val_58482 + _delta_58485;
        if ((long)((unsigned long)_val_58482 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58482 = NewDouble((double)_val_58482);
    }
    else {
        if (IS_ATOM_INT(_val_58482)) {
            _val_58482 = NewDouble((double)_val_58482 + DBL_PTR(_delta_58485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58485)) {
                _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl + (double)_delta_58485);
            }
            else
            _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl + DBL_PTR(_delta_58485)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1640] 1650
L2F: 

    /** 					val *= delta*/
    _0 = _val_58482;
    if (IS_ATOM_INT(_val_58482) && IS_ATOM_INT(_delta_58485)) {
        if (_val_58482 == (short)_val_58482 && _delta_58485 <= INT15 && _delta_58485 >= -INT15)
        _val_58482 = _val_58482 * _delta_58485;
        else
        _val_58482 = NewDouble(_val_58482 * (double)_delta_58485);
    }
    else {
        if (IS_ATOM_INT(_val_58482)) {
            _val_58482 = NewDouble((double)_val_58482 * DBL_PTR(_delta_58485)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58485)) {
                _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl * (double)_delta_58485);
            }
            else
            _val_58482 = NewDouble(DBL_PTR(_val_58482)->dbl * DBL_PTR(_delta_58485)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** 				valsym = 0*/
    _valsym_58479 = 0;
L2C: 

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29703 = (int)*(((s1_ptr)_2)->base + _sym_58478);
    _2 = (int)SEQ_PTR(_29703);
    _29704 = (int)*(((s1_ptr)_2)->base + 11);
    _29703 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    if (!IS_ATOM_INT(_29704))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29704)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29704);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58478;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29705 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L31; // [1699] 1737
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29707 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    _29709 = NOVALUE;
L31: 

    /** 			if valsym < 0 then*/
    if (_valsym_58479 >= 0)
    goto L32; // [1739] 1744
L32: 

    /** 			if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_58479 == 0) {
        goto L33; // [1746] 1926
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29713 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29713);
    _29714 = (int)*(((s1_ptr)_2)->base + 1);
    _29713 = NOVALUE;
    if (IS_ATOM_INT(_29714) && IS_ATOM_INT(_35NOVALUE_15823)){
        _29715 = (_29714 < _35NOVALUE_15823) ? -1 : (_29714 > _35NOVALUE_15823);
    }
    else{
        _29715 = compare(_29714, _35NOVALUE_15823);
    }
    _29714 = NOVALUE;
    if (_29715 == 0)
    {
        _29715 = NOVALUE;
        goto L33; // [1769] 1926
    }
    else{
        _29715 = NOVALUE;
    }

    /** 				SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58479;
    DeRef(_1);
    _29716 = NOVALUE;

    /** 				SymTab[sym][S_OBJ]  = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29718 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L34; // [1808] 2058
    }
    else{
    }

    /** 					SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29722 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29722);
    _29723 = (int)*(((s1_ptr)_2)->base + 36);
    _29722 = NOVALUE;
    Ref(_29723);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29723;
    if( _1 != _29723 ){
        DeRef(_1);
    }
    _29723 = NOVALUE;
    _29720 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29726 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29726);
    _29727 = (int)*(((s1_ptr)_2)->base + 33);
    _29726 = NOVALUE;
    Ref(_29727);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29727;
    if( _1 != _29727 ){
        DeRef(_1);
    }
    _29727 = NOVALUE;
    _29724 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29728 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29730 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29734 = (int)*(((s1_ptr)_2)->base + _valsym_58479);
    _2 = (int)SEQ_PTR(_29734);
    _29735 = (int)*(((s1_ptr)_2)->base + 32);
    _29734 = NOVALUE;
    Ref(_29735);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29735;
    if( _1 != _29735 ){
        DeRef(_1);
    }
    _29735 = NOVALUE;
    _29732 = NOVALUE;
    goto L34; // [1923] 2058
L33: 

    /** 				SymTab[sym][S_OBJ] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29736 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L35; // [1947] 2057
    }
    else{
    }

    /** 					if integer( usedval ) then*/
    if (IS_ATOM_INT(_usedval_58483))
    _29738 = 1;
    else if (IS_ATOM_DBL(_usedval_58483))
    _29738 = IS_ATOM_INT(DoubleToInt(_usedval_58483));
    else
    _29738 = 0;
    if (_29738 == 0)
    {
        _29738 = NOVALUE;
        goto L36; // [1955] 1978
    }
    else{
        _29738 = NOVALUE;
    }

    /** 						SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29739 = NOVALUE;
    goto L37; // [1975] 1996
L36: 

    /** 						SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29741 = NOVALUE;
L37: 

    /** 					SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29743 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29745 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    Ref(_usedval_58483);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58483;
    DeRef(_1);
    _29747 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29749 = NOVALUE;
L35: 
L34: 

    /** 			valsym = Pop()*/
    _valsym_58479 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58479)) {
        _1 = (long)(DBL_PTR(_valsym_58479)->dbl);
        DeRefDS(_valsym_58479);
        _valsym_58479 = _1;
    }

    /** 			valsym = Pop()*/
    _valsym_58479 = _41Pop();
    if (!IS_ATOM_INT(_valsym_58479)) {
        _1 = (long)(DBL_PTR(_valsym_58479)->dbl);
        DeRefDS(_valsym_58479);
        _valsym_58479 = _1;
    }
    goto L18; // [2072] 2248
L1C: 

    /** 			SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29753 = NOVALUE;

    /** 			if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _29755 = (_type_ptr_58470 > 0);
    if (_29755 == 0) {
        goto L38; // [2098] 2144
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29757 = (int)*(((s1_ptr)_2)->base + _type_ptr_58470);
    _2 = (int)SEQ_PTR(_29757);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _29758 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _29758 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _29757 = NOVALUE;
    if (IS_ATOM_INT(_29758)) {
        _29759 = (_29758 == 415);
    }
    else {
        _29759 = binary_op(EQUALS, _29758, 415);
    }
    _29758 = NOVALUE;
    if (_29759 == 0) {
        DeRef(_29759);
        _29759 = NOVALUE;
        goto L38; // [2121] 2144
    }
    else {
        if (!IS_ATOM_INT(_29759) && DBL_PTR(_29759)->dbl == 0.0){
            DeRef(_29759);
            _29759 = NOVALUE;
            goto L38; // [2121] 2144
        }
        DeRef(_29759);
        _29759 = NOVALUE;
    }
    DeRef(_29759);
    _29759 = NOVALUE;

    /** 				SymTab[sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _53object_type_45715;
    DeRef(_1);
    _29760 = NOVALUE;
    goto L39; // [2141] 2173
L38: 

    /** 				SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_ptr_58470;
    DeRef(_1);
    _29762 = NOVALUE;

    /** 				if type_ptr < 0 then*/
    if (_type_ptr_58470 >= 0)
    goto L3A; // [2161] 2172

    /** 					register_forward_type( sym, type_ptr )*/
    _38register_forward_type(_sym_58478, _type_ptr_58470);
L3A: 
L39: 

    /** 			if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L3B; // [2177] 2200
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58478 + ((s1_ptr)_2)->base);
    _29767 = _39CompileType(_type_ptr_58470);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29767;
    if( _1 != _29767 ){
        DeRef(_1);
    }
    _29767 = NOVALUE;
    _29765 = NOVALUE;
L3B: 

    /** 	   		tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /**    			putback(tok)*/
    Ref(_tok_58474);
    _39putback(_tok_58474);

    /** 	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29769 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29769, 3)){
        _29769 = NOVALUE;
        goto L3C; // [2220] 2247
    }
    _29769 = NOVALUE;

    /** 	   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_435, 0, 3);

    /** 	   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_58478;
    _29771 = MAKE_SEQ(_1);
    _39Assignment(_29771);
    _29771 = NOVALUE;
L3C: 
L18: 

    /** 		tok = next_token()*/
    _0 = _tok_58474;
    _tok_58474 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_58474);
    _29773 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29773, -30)){
        _29773 = NOVALUE;
        goto L3D; // [2263] 2272
    }
    _29773 = NOVALUE;

    /** 			exit*/
    goto LD; // [2269] 2282
L3D: 

    /** 		prevtok = tok*/
    Ref(_tok_58474);
    DeRef(_prevtok_58476);
    _prevtok_58476 = _tok_58474;

    /** 	end while*/
    goto LC; // [2279] 437
LD: 

    /** 	putback(tok)*/
    Ref(_tok_58474);
    _39putback(_tok_58474);

    /** 	return new_symbols*/
    DeRef(_tok_58474);
    DeRef(_tsym_58475);
    DeRef(_prevtok_58476);
    DeRef(_val_58482);
    DeRef(_usedval_58483);
    DeRef(_delta_58485);
    DeRef(_29534);
    _29534 = NOVALUE;
    _29561 = NOVALUE;
    _29612 = NOVALUE;
    DeRef(_29599);
    _29599 = NOVALUE;
    _29616 = NOVALUE;
    DeRef(_29624);
    _29624 = NOVALUE;
    DeRef(_29633);
    _29633 = NOVALUE;
    DeRef(_29642);
    _29642 = NOVALUE;
    _29648 = NOVALUE;
    _29663 = NOVALUE;
    DeRef(_29668);
    _29668 = NOVALUE;
    DeRef(_29684);
    _29684 = NOVALUE;
    _29704 = NOVALUE;
    DeRef(_29755);
    _29755 = NOVALUE;
    return _new_symbols_58472;
    ;
}


void _39Private_declaration(int _type_sym_59047)
{
    int _tok_59049 = NOVALUE;
    int _sym_59051 = NOVALUE;
    int _31360 = NOVALUE;
    int _31359 = NOVALUE;
    int _31358 = NOVALUE;
    int _29799 = NOVALUE;
    int _29797 = NOVALUE;
    int _29795 = NOVALUE;
    int _29793 = NOVALUE;
    int _29791 = NOVALUE;
    int _29789 = NOVALUE;
    int _29787 = NOVALUE;
    int _29784 = NOVALUE;
    int _29782 = NOVALUE;
    int _29781 = NOVALUE;
    int _29778 = NOVALUE;
    int _29776 = NOVALUE;
    int _29775 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_59047)) {
        _1 = (long)(DBL_PTR(_type_sym_59047)->dbl);
        DeRefDS(_type_sym_59047);
        _type_sym_59047 = _1;
    }

    /** 	if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29775 = (int)*(((s1_ptr)_2)->base + _type_sym_59047);
    _2 = (int)SEQ_PTR(_29775);
    _29776 = (int)*(((s1_ptr)_2)->base + 4);
    _29775 = NOVALUE;
    if (binary_op_a(NOTEQ, _29776, 9)){
        _29776 = NOVALUE;
        goto L1; // [19] 47
    }
    _29776 = NOVALUE;

    /** 		Hide( type_sym )*/
    _53Hide(_type_sym_59047);

    /** 		type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31360 = 504;
    _29778 = _38new_forward_reference(504, _type_sym_59047, 504);
    _31360 = NOVALUE;
    if (IS_ATOM_INT(_29778)) {
        if ((unsigned long)_29778 == 0xC0000000)
        _type_sym_59047 = (int)NewDouble((double)-0xC0000000);
        else
        _type_sym_59047 = - _29778;
    }
    else {
        _type_sym_59047 = unary_op(UMINUS, _29778);
    }
    DeRef(_29778);
    _29778 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_59047)) {
        _1 = (long)(DBL_PTR(_type_sym_59047)->dbl);
        DeRefDS(_type_sym_59047);
        _type_sym_59047 = _1;
    }
L1: 

    /** 	while TRUE do*/
L2: 
    if (_13TRUE_437 == 0)
    {
        goto L3; // [54] 255
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59049;
    _tok_59049 = _39next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29781 = (int)*(((s1_ptr)_2)->base + 1);
    _29782 = find_from(_29781, _37ID_TOKS_15600, 1);
    _29781 = NOVALUE;
    if (_29782 != 0)
    goto L4; // [77] 88
    _29782 = NOVALUE;

    /** 			CompileErr(24)*/
    RefDS(_21815);
    _44CompileErr(24, _21815, 0);
L4: 

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29784 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29784);
    _sym_59051 = _39SetPrivateScope(_29784, _type_sym_59047, _39param_num_53678);
    _29784 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59051)) {
        _1 = (long)(DBL_PTR(_sym_59051)->dbl);
        DeRefDS(_sym_59051);
        _sym_59051 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_53678 = _39param_num_53678 + 1;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L5; // [118] 141
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59051 + ((s1_ptr)_2)->base);
    _29789 = _39CompileType(_type_sym_59047);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29789;
    if( _1 != _29789 ){
        DeRef(_1);
    }
    _29789 = NOVALUE;
    _29787 = NOVALUE;
L5: 

    /**    		tok = next_token()*/
    _0 = _tok_59049;
    _tok_59049 = _39next_token();
    DeRef(_0);

    /**    		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29791 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29791, 3)){
        _29791 = NOVALUE;
        goto L6; // [156] 231
    }
    _29791 = NOVALUE;

    /** 		    putback(tok)*/
    Ref(_tok_59049);
    _39putback(_tok_59049);

    /** 		    StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 		    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_59051;
    _29793 = MAKE_SEQ(_1);
    _39Assignment(_29793);
    _29793 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59049;
    _tok_59049 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID]=IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29795 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29795, 509)){
        _29795 = NOVALUE;
        goto L7; // [200] 230
    }
    _29795 = NOVALUE;

    /** 				tok = keyfind(tok[T_SYM],-1)*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29797 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29797);
    DeRef(_31358);
    _31358 = _29797;
    _31359 = _53hashfn(_31358);
    _31358 = NOVALUE;
    Ref(_29797);
    _0 = _tok_59049;
    _tok_59049 = _53keyfind(_29797, -1, _35current_file_no_15968, 0, _31359);
    DeRef(_0);
    _29797 = NOVALUE;
    _31359 = NOVALUE;
L7: 
L6: 

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59049);
    _29799 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29799, -30)){
        _29799 = NOVALUE;
        goto L2; // [241] 52
    }
    _29799 = NOVALUE;

    /** 			exit*/
    goto L3; // [247] 255

    /** 	end while*/
    goto L2; // [252] 52
L3: 

    /** 	putback(tok)*/
    Ref(_tok_59049);
    _39putback(_tok_59049);

    /** end procedure*/
    DeRef(_tok_59049);
    return;
    ;
}


void _39Procedure_call(int _tok_59113)
{
    int _n_59114 = NOVALUE;
    int _scope_59115 = NOVALUE;
    int _opcode_59116 = NOVALUE;
    int _temp_tok_59118 = NOVALUE;
    int _s_59120 = NOVALUE;
    int _sub_59121 = NOVALUE;
    int _29835 = NOVALUE;
    int _29830 = NOVALUE;
    int _29829 = NOVALUE;
    int _29828 = NOVALUE;
    int _29827 = NOVALUE;
    int _29826 = NOVALUE;
    int _29825 = NOVALUE;
    int _29824 = NOVALUE;
    int _29823 = NOVALUE;
    int _29822 = NOVALUE;
    int _29821 = NOVALUE;
    int _29820 = NOVALUE;
    int _29818 = NOVALUE;
    int _29817 = NOVALUE;
    int _29816 = NOVALUE;
    int _29815 = NOVALUE;
    int _29814 = NOVALUE;
    int _29813 = NOVALUE;
    int _29812 = NOVALUE;
    int _29810 = NOVALUE;
    int _29809 = NOVALUE;
    int _29808 = NOVALUE;
    int _29806 = NOVALUE;
    int _29804 = NOVALUE;
    int _29802 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59113);
    _s_59120 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59120)){
        _s_59120 = (long)DBL_PTR(_s_59120)->dbl;
    }

    /** 	sub=s*/
    _sub_59121 = _s_59120;

    /** 	n = SymTab[s][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29802 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29802);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _n_59114 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _n_59114 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    if (!IS_ATOM_INT(_n_59114)){
        _n_59114 = (long)DBL_PTR(_n_59114)->dbl;
    }
    _29802 = NOVALUE;

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29804 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29804);
    _scope_59115 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_59115)){
        _scope_59115 = (long)DBL_PTR(_scope_59115)->dbl;
    }
    _29804 = NOVALUE;

    /** 	opcode = SymTab[s][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29806 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29806);
    _opcode_59116 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_59116)){
        _opcode_59116 = (long)DBL_PTR(_opcode_59116)->dbl;
    }
    _29806 = NOVALUE;

    /** 	if SymTab[s][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29808 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29808);
    _29809 = (int)*(((s1_ptr)_2)->base + 23);
    _29808 = NOVALUE;
    if (_29809 == 0) {
        _29809 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_29809) && DBL_PTR(_29809)->dbl == 0.0){
            _29809 = NOVALUE;
            goto L1; // [88] 139
        }
        _29809 = NOVALUE;
    }
    _29809 = NOVALUE;

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29812 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_29812);
    _29813 = (int)*(((s1_ptr)_2)->base + 23);
    _29812 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29814 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29814);
    _29815 = (int)*(((s1_ptr)_2)->base + 23);
    _29814 = NOVALUE;
    if (IS_ATOM_INT(_29813) && IS_ATOM_INT(_29815)) {
        {unsigned long tu;
             tu = (unsigned long)_29813 | (unsigned long)_29815;
             _29816 = MAKE_UINT(tu);
        }
    }
    else {
        _29816 = binary_op(OR_BITS, _29813, _29815);
    }
    _29813 = NOVALUE;
    _29815 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _29816;
    if( _1 != _29816 ){
        DeRef(_1);
    }
    _29816 = NOVALUE;
    _29810 = NOVALUE;
L1: 

    /** 	ParseArgs(s)*/
    _39ParseArgs(_s_59120);

    /** 	for i=1 to n+1 do*/
    _29817 = _n_59114 + 1;
    if (_29817 > MAXINT){
        _29817 = NewDouble((double)_29817);
    }
    {
        int _i_59158;
        _i_59158 = 1;
L2: 
        if (binary_op_a(GREATER, _i_59158, _29817)){
            goto L3; // [150] 180
        }

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _29818 = (int)*(((s1_ptr)_2)->base + _s_59120);
        _2 = (int)SEQ_PTR(_29818);
        _s_59120 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_59120)){
            _s_59120 = (long)DBL_PTR(_s_59120)->dbl;
        }
        _29818 = NOVALUE;

        /** 	end for*/
        _0 = _i_59158;
        if (IS_ATOM_INT(_i_59158)) {
            _i_59158 = _i_59158 + 1;
            if ((long)((unsigned long)_i_59158 +(unsigned long) HIGH_BITS) >= 0){
                _i_59158 = NewDouble((double)_i_59158);
            }
        }
        else {
            _i_59158 = binary_op_a(PLUS, _i_59158, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_59158);
    }

    /** 	while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_59120 == 0) {
        goto L5; // [185] 281
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29821 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29821);
    _29822 = (int)*(((s1_ptr)_2)->base + 4);
    _29821 = NOVALUE;
    if (IS_ATOM_INT(_29822)) {
        _29823 = (_29822 == 3);
    }
    else {
        _29823 = binary_op(EQUALS, _29822, 3);
    }
    _29822 = NOVALUE;
    if (_29823 <= 0) {
        if (_29823 == 0) {
            DeRef(_29823);
            _29823 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_29823) && DBL_PTR(_29823)->dbl == 0.0){
                DeRef(_29823);
                _29823 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_29823);
            _29823 = NOVALUE;
        }
    }
    DeRef(_29823);
    _29823 = NOVALUE;

    /** 		if sequence(SymTab[s][S_CODE]) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29824 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29824);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _29825 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _29825 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _29824 = NOVALUE;
    _29826 = IS_SEQUENCE(_29825);
    _29825 = NOVALUE;
    if (_29826 == 0)
    {
        _29826 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _29826 = NOVALUE;
    }

    /** 			start_playback(SymTab[s][S_CODE])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29827 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29827);
    if (!IS_ATOM_INT(_35S_CODE_15653)){
        _29828 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    }
    else{
        _29828 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
    }
    _29827 = NOVALUE;
    Ref(_29828);
    _39start_playback(_29828);
    _29828 = NOVALUE;

    /** 			Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _s_59120;
    _29829 = MAKE_SEQ(_1);
    _39Assignment(_29829);
    _29829 = NOVALUE;
L6: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29830 = (int)*(((s1_ptr)_2)->base + _s_59120);
    _2 = (int)SEQ_PTR(_29830);
    _s_59120 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59120)){
        _s_59120 = (long)DBL_PTR(_s_59120)->dbl;
    }
    _29830 = NOVALUE;

    /** 	end while*/
    goto L4; // [278] 185
L5: 

    /** 	s = sub*/
    _s_59120 = _sub_59121;

    /** 	if scope = SC_PREDEF then*/
    if (_scope_59115 != 7)
    goto L7; // [292] 335

    /** 		emit_op(opcode)*/
    _41emit_op(_opcode_59116);

    /** 		if opcode = ABORT then*/
    if (_opcode_59116 != 126)
    goto L8; // [305] 370

    /** 			temp_tok = next_token()*/
    _0 = _temp_tok_59118;
    _temp_tok_59118 = _39next_token();
    DeRef(_0);

    /** 			putback(temp_tok)*/
    Ref(_temp_tok_59118);
    _39putback(_temp_tok_59118);

    /** 			NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (int)SEQ_PTR(_temp_tok_59118);
    _29835 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29835);
    RefDS(_27692);
    _39NotReached(_29835, _27692);
    _29835 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** 		op_info1 = s*/
    _41op_info1_49774 = _s_59120;

    /** 		emit_or_inline()*/
    _67emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L9; // [350] 369

    /** 			if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
LA: 
L9: 
L8: 

    /** end procedure*/
    DeRef(_tok_59113);
    DeRef(_temp_tok_59118);
    DeRef(_29817);
    _29817 = NOVALUE;
    return;
    ;
}


void _39Print_statement()
{
    int _29842 = NOVALUE;
    int _29841 = NOVALUE;
    int _29840 = NOVALUE;
    int _29838 = NOVALUE;
    int _29837 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	emit_opnd(NewIntSym(1)) -- stdout*/
    _29837 = _53NewIntSym(1);
    _41emit_opnd(_29837);
    _29837 = NOVALUE;

    /** 	Expr()*/
    _39Expr();

    /** 	emit_op(QPRINT)*/
    _41emit_op(36);

    /** 	SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35CurrentSub_15976 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29840 = (int)*(((s1_ptr)_2)->base + _35CurrentSub_15976);
    _2 = (int)SEQ_PTR(_29840);
    _29841 = (int)*(((s1_ptr)_2)->base + 23);
    _29840 = NOVALUE;
    if (IS_ATOM_INT(_29841)) {
        {unsigned long tu;
             tu = (unsigned long)_29841 | (unsigned long)536870912;
             _29842 = MAKE_UINT(tu);
        }
    }
    else {
        _29842 = binary_op(OR_BITS, _29841, 536870912);
    }
    _29841 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _29842;
    if( _1 != _29842 ){
        DeRef(_1);
    }
    _29842 = NOVALUE;
    _29838 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _39Entry_statement()
{
    int _addr_59229 = NOVALUE;
    int _29867 = NOVALUE;
    int _29866 = NOVALUE;
    int _29865 = NOVALUE;
    int _29864 = NOVALUE;
    int _29863 = NOVALUE;
    int _29862 = NOVALUE;
    int _29861 = NOVALUE;
    int _29860 = NOVALUE;
    int _29856 = NOVALUE;
    int _29854 = NOVALUE;
    int _29853 = NOVALUE;
    int _29851 = NOVALUE;
    int _29850 = NOVALUE;
    int _29848 = NOVALUE;
    int _29847 = NOVALUE;
    int _29846 = NOVALUE;
    int _29844 = NOVALUE;
    int _29843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _29843 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _29843 = 1;
    }
    _29844 = (_29843 == 0);
    _29843 = NOVALUE;
    if (_29844 != 0) {
        goto L1; // [11] 26
    }
    _29846 = (_39block_index_53700 == 0);
    if (_29846 == 0)
    {
        DeRef(_29846);
        _29846 = NOVALUE;
        goto L2; // [22] 34
    }
    else{
        DeRef(_29846);
        _29846 = NOVALUE;
    }
L1: 

    /** 		CompileErr(144)*/
    RefDS(_21815);
    _44CompileErr(144, _21815, 0);
L2: 

    /** 	if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (int)SEQ_PTR(_39block_list_53699);
    _29847 = (int)*(((s1_ptr)_2)->base + _39block_index_53700);
    _29848 = (_29847 == 20);
    _29847 = NOVALUE;
    if (_29848 != 0) {
        goto L3; // [50] 73
    }
    _2 = (int)SEQ_PTR(_39block_list_53699);
    _29850 = (int)*(((s1_ptr)_2)->base + _39block_index_53700);
    _29851 = (_29850 == 185);
    _29850 = NOVALUE;
    if (_29851 == 0)
    {
        DeRef(_29851);
        _29851 = NOVALUE;
        goto L4; // [69] 83
    }
    else{
        DeRef(_29851);
        _29851 = NOVALUE;
    }
L3: 

    /** 		CompileErr(143)*/
    RefDS(_21815);
    _44CompileErr(143, _21815, 0);
    goto L5; // [80] 109
L4: 

    /** 	elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_39loop_stack_53703)){
            _29853 = SEQ_PTR(_39loop_stack_53703)->length;
    }
    else {
        _29853 = 1;
    }
    _2 = (int)SEQ_PTR(_39loop_stack_53703);
    _29854 = (int)*(((s1_ptr)_2)->base + _29853);
    if (_29854 != 21)
    goto L6; // [96] 108

    /** 		CompileErr(142)*/
    RefDS(_21815);
    _44CompileErr(142, _21815, 0);
L6: 
L5: 

    /** 	addr = entry_addr[$]*/
    if (IS_SEQUENCE(_39entry_addr_53693)){
            _29856 = SEQ_PTR(_39entry_addr_53693)->length;
    }
    else {
        _29856 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_53693);
    _addr_59229 = (int)*(((s1_ptr)_2)->base + _29856);

    /** 	if addr=0  then*/
    if (_addr_59229 != 0)
    goto L7; // [122] 136

    /** 		CompileErr(141)*/
    RefDS(_21815);
    _44CompileErr(141, _21815, 0);
    goto L8; // [133] 151
L7: 

    /** 	elsif addr<0 then*/
    if (_addr_59229 >= 0)
    goto L9; // [138] 150

    /** 		CompileErr(73)*/
    RefDS(_21815);
    _44CompileErr(73, _21815, 0);
L9: 
L8: 

    /** 	backpatch(addr,ELSE)*/
    _41backpatch(_addr_59229, 23);

    /** 	backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _29860 = _addr_59229 + 1;
    if (_29860 > MAXINT){
        _29860 = NewDouble((double)_29860);
    }
    if (IS_SEQUENCE(_35Code_16056)){
            _29861 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _29861 = 1;
    }
    _29862 = _29861 + 1;
    _29861 = NOVALUE;
    _29863 = (_35TRANSLATE_15611 > 0);
    _29864 = _29862 + _29863;
    _29862 = NOVALUE;
    _29863 = NOVALUE;
    _41backpatch(_29860, _29864);
    _29860 = NOVALUE;
    _29864 = NOVALUE;

    /** 	entry_addr[$] = 0*/
    if (IS_SEQUENCE(_39entry_addr_53693)){
            _29865 = SEQ_PTR(_39entry_addr_53693)->length;
    }
    else {
        _29865 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_addr_53693);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _39entry_addr_53693 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29865);
    *(int *)_2 = 0;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto LA; // [203] 214
    }
    else{
    }

    /** 	    emit_op(NOP1)*/
    _41emit_op(159);
LA: 

    /** 	force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_39entry_stack_53696)){
            _29866 = SEQ_PTR(_39entry_stack_53696)->length;
    }
    else {
        _29866 = 1;
    }
    _2 = (int)SEQ_PTR(_39entry_stack_53696);
    _29867 = (int)*(((s1_ptr)_2)->base + _29866);
    Ref(_29867);
    _39force_uninitialize(_29867);
    _29867 = NOVALUE;

    /** end procedure*/
    DeRef(_29844);
    _29844 = NOVALUE;
    _29854 = NOVALUE;
    DeRef(_29848);
    _29848 = NOVALUE;
    return;
    ;
}


void _39force_uninitialize(int _uninitialized_59280)
{
    int _29870 = NOVALUE;
    int _29869 = NOVALUE;
    int _29868 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_59280)){
            _29868 = SEQ_PTR(_uninitialized_59280)->length;
    }
    else {
        _29868 = 1;
    }
    {
        int _i_59282;
        _i_59282 = 1;
L1: 
        if (_i_59282 > _29868){
            goto L2; // [8] 41
        }

        /** 		SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (int)SEQ_PTR(_uninitialized_59280);
        _29869 = (int)*(((s1_ptr)_2)->base + _i_59282);
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29869))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29869)->dbl));
        else
        _3 = (int)(_29869 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 14);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);
        _29870 = NOVALUE;

        /** 	end for*/
        _i_59282 = _i_59282 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_uninitialized_59280);
    _29869 = NOVALUE;
    return;
    ;
}


void _39Statement_list()
{
    int _tok_59292 = NOVALUE;
    int _id_59293 = NOVALUE;
    int _forward_59316 = NOVALUE;
    int _test_59465 = NOVALUE;
    int _29942 = NOVALUE;
    int _29941 = NOVALUE;
    int _29938 = NOVALUE;
    int _29936 = NOVALUE;
    int _29935 = NOVALUE;
    int _29932 = NOVALUE;
    int _29930 = NOVALUE;
    int _29929 = NOVALUE;
    int _29928 = NOVALUE;
    int _29925 = NOVALUE;
    int _29923 = NOVALUE;
    int _29921 = NOVALUE;
    int _29919 = NOVALUE;
    int _29901 = NOVALUE;
    int _29900 = NOVALUE;
    int _29898 = NOVALUE;
    int _29896 = NOVALUE;
    int _29895 = NOVALUE;
    int _29893 = NOVALUE;
    int _29891 = NOVALUE;
    int _29890 = NOVALUE;
    int _29889 = NOVALUE;
    int _29888 = NOVALUE;
    int _29883 = NOVALUE;
    int _29880 = NOVALUE;
    int _29879 = NOVALUE;
    int _29878 = NOVALUE;
    int _29877 = NOVALUE;
    int _29875 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	stmt_nest += 1*/
    _39stmt_nest_53701 = _39stmt_nest_53701 + 1;

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_437 == 0)
    {
        goto L2; // [18] 1093
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59292;
    _tok_59292 = _39next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _id_59293 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_59293)){
        _id_59293 = (long)DBL_PTR(_id_59293)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _29875 = (_id_59293 == -100);
    if (_29875 != 0) {
        goto L3; // [44] 59
    }
    _29877 = (_id_59293 == 512);
    if (_29877 == 0)
    {
        DeRef(_29877);
        _29877 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_29877);
        _29877 = NOVALUE;
    }
L3: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _29878 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_29878)){
        _29879 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29878)->dbl));
    }
    else{
        _29879 = (int)*(((s1_ptr)_2)->base + _29878);
    }
    _2 = (int)SEQ_PTR(_29879);
    _29880 = (int)*(((s1_ptr)_2)->base + 4);
    _29879 = NOVALUE;
    if (binary_op_a(NOTEQ, _29880, 9)){
        _29880 = NOVALUE;
        goto L5; // [81] 210
    }
    _29880 = NOVALUE;

    /** 				token forward = next_token()*/
    _0 = _forward_59316;
    _forward_59316 = _39next_token();
    DeRef(_0);

    /** 				switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_59316);
    _29883 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29883) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_29883)){
        if( (DBL_PTR(_29883)->dbl != (double) ((int) DBL_PTR(_29883)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (int) DBL_PTR(_29883)->dbl;
    }
    else {
        _0 = _29883;
    };
    _29883 = NOVALUE;
    switch ( _0 ){ 

        /** 					case LEFT_ROUND then*/
        case -26:

        /** 						StartSourceLine( TRUE )*/
        _41StartSourceLine(_13TRUE_437, 0, 2);

        /** 						Forward_call( tok )*/
        Ref(_tok_59292);
        _39Forward_call(_tok_59292, 195);

        /** 						flush_temps()*/
        RefDS(_21815);
        _41flush_temps(_21815);

        /** 						continue*/
        DeRef(_forward_59316);
        _forward_59316 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** 					case VARIABLE then*/
        case -100:

        /** 						putback( forward )*/
        Ref(_forward_59316);
        _39putback(_forward_59316);

        /** 						if param_num != -1 then*/
        if (_39param_num_53678 == -1)
        goto L7; // [150] 176

        /** 							param_num += 1*/
        _39param_num_53678 = _39param_num_53678 + 1;

        /** 							Private_declaration( tok[T_SYM] )*/
        _2 = (int)SEQ_PTR(_tok_59292);
        _29888 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_29888);
        _39Private_declaration(_29888);
        _29888 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** 							Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (int)SEQ_PTR(_tok_59292);
        _29889 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_29889);
        _29890 = _39Global_declaration(_29889, 5);
        _29889 = NOVALUE;
L8: 

        /** 						flush_temps()*/
        RefDS(_21815);
        _41flush_temps(_21815);

        /** 						continue*/
        DeRef(_forward_59316);
        _forward_59316 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** 				putback( forward )*/
    Ref(_forward_59316);
    _39putback(_forward_59316);
L5: 
    DeRef(_forward_59316);
    _forward_59316 = NOVALUE;

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_59292);
    _39Assignment(_tok_59292);
    goto L9; // [226] 1083
L4: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _29891 = (_id_59293 == 27);
    if (_29891 != 0) {
        goto LA; // [237] 252
    }
    _29893 = (_id_59293 == 521);
    if (_29893 == 0)
    {
        DeRef(_29893);
        _29893 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_29893);
        _29893 = NOVALUE;
    }
LA: 

    /** 			if id = PROC then*/
    if (_id_59293 != 27)
    goto LC; // [256] 272

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _29895 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29895);
    _39UndefinedVar(_29895);
    _29895 = NOVALUE;
LC: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59292);
    _39Procedure_call(_tok_59292);
    goto L9; // [286] 1083
LB: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _29896 = (_id_59293 == 501);
    if (_29896 != 0) {
        goto LD; // [297] 312
    }
    _29898 = (_id_59293 == 520);
    if (_29898 == 0)
    {
        DeRef(_29898);
        _29898 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_29898);
        _29898 = NOVALUE;
    }
LD: 

    /** 			if id = FUNC then*/
    if (_id_59293 != 501)
    goto LF; // [316] 332

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _29900 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29900);
    _39UndefinedVar(_29900);
    _29900 = NOVALUE;
LF: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59292);
    _39Procedure_call(_tok_59292);

    /** 			clear_op()*/
    _41clear_op();

    /** 			if Pop() then end if*/
    _29901 = _41Pop();
    if (_29901 == 0) {
        DeRef(_29901);
        _29901 = NOVALUE;
        goto L9; // [355] 1083
    }
    else {
        if (!IS_ATOM_INT(_29901) && DBL_PTR(_29901)->dbl == 0.0){
            DeRef(_29901);
            _29901 = NOVALUE;
            goto L9; // [355] 1083
        }
        DeRef(_29901);
        _29901 = NOVALUE;
    }
    DeRef(_29901);
    _29901 = NOVALUE;
    goto L9; // [359] 1083
LE: 

    /** 		elsif id = IF then*/
    if (_id_59293 != 20)
    goto L10; // [366] 386

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			If_statement()*/
    _39If_statement();
    goto L9; // [383] 1083
L10: 

    /** 		elsif id = FOR then*/
    if (_id_59293 != 21)
    goto L11; // [390] 410

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			For_statement()*/
    _39For_statement();
    goto L9; // [407] 1083
L11: 

    /** 		elsif id = RETURN then*/
    if (_id_59293 != 413)
    goto L12; // [414] 434

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Return_statement()*/
    _39Return_statement();
    goto L9; // [431] 1083
L12: 

    /** 		elsif id = LABEL then*/
    if (_id_59293 != 419)
    goto L13; // [438] 460

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 			GLabel_statement()*/
    _39GLabel_statement();
    goto L9; // [457] 1083
L13: 

    /** 		elsif id = GOTO then*/
    if (_id_59293 != 188)
    goto L14; // [464] 484

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Goto_statement()*/
    _39Goto_statement();
    goto L9; // [481] 1083
L14: 

    /** 		elsif id = EXIT then*/
    if (_id_59293 != 61)
    goto L15; // [488] 508

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Exit_statement()*/
    _39Exit_statement();
    goto L9; // [505] 1083
L15: 

    /** 		elsif id = BREAK then*/
    if (_id_59293 != 425)
    goto L16; // [512] 532

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Break_statement()*/
    _39Break_statement();
    goto L9; // [529] 1083
L16: 

    /** 		elsif id = WHILE then*/
    if (_id_59293 != 47)
    goto L17; // [536] 556

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			While_statement()*/
    _39While_statement();
    goto L9; // [553] 1083
L17: 

    /** 		elsif id = LOOP then*/
    if (_id_59293 != 422)
    goto L18; // [560] 580

    /** 		    StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 	        Loop_statement()*/
    _39Loop_statement();
    goto L9; // [577] 1083
L18: 

    /** 		elsif id = ENTRY then*/
    if (_id_59293 != 424)
    goto L19; // [584] 606

    /** 		    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 		    Entry_statement()*/
    _39Entry_statement();
    goto L9; // [603] 1083
L19: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_59293 != -31)
    goto L1A; // [610] 630

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Print_statement()*/
    _39Print_statement();
    goto L9; // [627] 1083
L1A: 

    /** 		elsif id = CONTINUE then*/
    if (_id_59293 != 426)
    goto L1B; // [634] 654

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Continue_statement()*/
    _39Continue_statement();
    goto L9; // [651] 1083
L1B: 

    /** 		elsif id = RETRY then*/
    if (_id_59293 != 184)
    goto L1C; // [658] 678

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Retry_statement()*/
    _39Retry_statement();
    goto L9; // [675] 1083
L1C: 

    /** 		elsif id = IFDEF then*/
    if (_id_59293 != 407)
    goto L1D; // [682] 702

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Ifdef_statement()*/
    _39Ifdef_statement();
    goto L9; // [699] 1083
L1D: 

    /** 		elsif id = CASE then*/
    if (_id_59293 != 186)
    goto L1E; // [706] 717

    /** 			Case_statement()*/
    _39Case_statement();
    goto L9; // [714] 1083
L1E: 

    /** 		elsif id = SWITCH then*/
    if (_id_59293 != 185)
    goto L1F; // [721] 741

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Switch_statement()*/
    _39Switch_statement();
    goto L9; // [738] 1083
L1F: 

    /** 		elsif id = FALLTHRU then*/
    if (_id_59293 != 431)
    goto L20; // [745] 756

    /** 			Fallthru_statement()*/
    _39Fallthru_statement();
    goto L9; // [753] 1083
L20: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _29919 = (_id_59293 == 504);
    if (_29919 != 0) {
        goto L21; // [764] 779
    }
    _29921 = (_id_59293 == 522);
    if (_29921 == 0)
    {
        DeRef(_29921);
        _29921 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_29921);
        _29921 = NOVALUE;
    }
L21: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			token test = next_token()*/
    _0 = _test_59465;
    _test_59465 = _39next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_59465);
    _39putback(_test_59465);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_59465);
    _29923 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29923, -26)){
        _29923 = NOVALUE;
        goto L23; // [808] 852
    }
    _29923 = NOVALUE;

    /** 				StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 				Procedure_call(tok)*/
    Ref(_tok_59292);
    _39Procedure_call(_tok_59292);

    /** 				clear_op()*/
    _41clear_op();

    /** 				if Pop() then end if*/
    _29925 = _41Pop();
    if (_29925 == 0) {
        DeRef(_29925);
        _29925 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_29925) && DBL_PTR(_29925)->dbl == 0.0){
            DeRef(_29925);
            _29925 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_29925);
        _29925 = NOVALUE;
    }
    DeRef(_29925);
    _29925 = NOVALUE;
L24: 

    /** 				ExecCommand()*/
    _39ExecCommand();

    /** 				continue*/
    DeRef(_test_59465);
    _test_59465 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** 				if param_num != -1 then*/
    if (_39param_num_53678 == -1)
    goto L26; // [856] 882

    /** 					param_num += 1*/
    _39param_num_53678 = _39param_num_53678 + 1;

    /** 					Private_declaration( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _29928 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29928);
    _39Private_declaration(_29928);
    _29928 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** 					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_59292);
    _29929 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29929);
    _29930 = _39Global_declaration(_29929, 5);
    _29929 = NOVALUE;
L27: 
L25: 
    DeRef(_test_59465);
    _test_59465 = NOVALUE;
    goto L9; // [901] 1083
L22: 

    /** 			if id = ELSE then*/
    if (_id_59293 != 23)
    goto L28; // [908] 962

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _29932 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _29932 = 1;
    }
    if (_29932 != 0)
    goto L29; // [919] 1019

    /** 					if live_ifdef > 0 then*/
    if (_39live_ifdef_57842 <= 0)
    goto L2A; // [927] 950

    /** 						CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29935 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29935 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29936 = (int)*(((s1_ptr)_2)->base + _29935);
    _44CompileErr(134, _29936, 0);
    _29936 = NOVALUE;
    goto L29; // [947] 1019
L2A: 

    /** 						CompileErr(118)*/
    RefDS(_21815);
    _44CompileErr(118, _21815, 0);
    goto L29; // [959] 1019
L28: 

    /** 			elsif id = ELSIF then*/
    if (_id_59293 != 414)
    goto L2B; // [966] 1018

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _29938 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _29938 = 1;
    }
    if (_29938 != 0)
    goto L2C; // [977] 1017

    /** 					if live_ifdef > 0 then*/
    if (_39live_ifdef_57842 <= 0)
    goto L2D; // [985] 1008

    /** 						CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _29941 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _29941 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _29942 = (int)*(((s1_ptr)_2)->base + _29941);
    _44CompileErr(139, _29942, 0);
    _29942 = NOVALUE;
    goto L2E; // [1005] 1016
L2D: 

    /** 						CompileErr(119)*/
    RefDS(_21815);
    _44CompileErr(119, _21815, 0);
L2E: 
L2C: 
L2B: 
L29: 

    /** 			putback( tok )*/
    Ref(_tok_59292);
    _39putback(_tok_59292);

    /** 			switch id do*/
    _0 = _id_59293;
    switch ( _0 ){ 

        /** 				case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** 					stmt_nest -= 1*/
        _39stmt_nest_53701 = _39stmt_nest_53701 - 1;

        /** 					InitDelete()*/
        _39InitDelete();

        /** 					flush_temps()*/
        RefDS(_21815);
        _41flush_temps(_21815);

        /** 					return*/
        DeRef(_tok_59292);
        DeRef(_29875);
        _29875 = NOVALUE;
        _29878 = NOVALUE;
        DeRef(_29891);
        _29891 = NOVALUE;
        DeRef(_29890);
        _29890 = NOVALUE;
        DeRef(_29896);
        _29896 = NOVALUE;
        DeRef(_29919);
        _29919 = NOVALUE;
        DeRef(_29930);
        _29930 = NOVALUE;
        return;
        goto L2F; // [1067] 1082

        /** 				case else*/
        default:

        /** 					tok_match( END )*/
        _39tok_match(402, 0);
    ;}L2F: 
L9: 

    /** 		flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** 	end while*/
    goto L1; // [1090] 16
L2: 

    /** end procedure*/
    DeRef(_tok_59292);
    DeRef(_29875);
    _29875 = NOVALUE;
    _29878 = NOVALUE;
    DeRef(_29891);
    _29891 = NOVALUE;
    DeRef(_29890);
    _29890 = NOVALUE;
    DeRef(_29896);
    _29896 = NOVALUE;
    DeRef(_29919);
    _29919 = NOVALUE;
    DeRef(_29930);
    _29930 = NOVALUE;
    return;
    ;
}


void _39SubProg(int _prog_type_59535, int _scope_59536)
{
    int _h_59537 = NOVALUE;
    int _pt_59538 = NOVALUE;
    int _p_59540 = NOVALUE;
    int _type_sym_59541 = NOVALUE;
    int _sym_59542 = NOVALUE;
    int _tok_59544 = NOVALUE;
    int _prog_name_59545 = NOVALUE;
    int _first_def_arg_59546 = NOVALUE;
    int _again_59547 = NOVALUE;
    int _type_enum_59548 = NOVALUE;
    int _seq_sym_59549 = NOVALUE;
    int _i1_sym_59550 = NOVALUE;
    int _enum_syms_59551 = NOVALUE;
    int _type_enum_gline_59552 = NOVALUE;
    int _real_gline_59553 = NOVALUE;
    int _tsym_59564 = NOVALUE;
    int _seq_symbol_59575 = NOVALUE;
    int _middle_def_args_59774 = NOVALUE;
    int _last_nda_59775 = NOVALUE;
    int _start_def_59776 = NOVALUE;
    int _last_link_59778 = NOVALUE;
    int _temptok_59805 = NOVALUE;
    int _undef_type_59807 = NOVALUE;
    int _tokcat_59856 = NOVALUE;
    int _31357 = NOVALUE;
    int _31356 = NOVALUE;
    int _31355 = NOVALUE;
    int _31354 = NOVALUE;
    int _31353 = NOVALUE;
    int _31352 = NOVALUE;
    int _31351 = NOVALUE;
    int _31350 = NOVALUE;
    int _31349 = NOVALUE;
    int _30207 = NOVALUE;
    int _30205 = NOVALUE;
    int _30204 = NOVALUE;
    int _30202 = NOVALUE;
    int _30201 = NOVALUE;
    int _30200 = NOVALUE;
    int _30199 = NOVALUE;
    int _30198 = NOVALUE;
    int _30196 = NOVALUE;
    int _30195 = NOVALUE;
    int _30192 = NOVALUE;
    int _30191 = NOVALUE;
    int _30190 = NOVALUE;
    int _30189 = NOVALUE;
    int _30187 = NOVALUE;
    int _30177 = NOVALUE;
    int _30175 = NOVALUE;
    int _30174 = NOVALUE;
    int _30173 = NOVALUE;
    int _30172 = NOVALUE;
    int _30169 = NOVALUE;
    int _30168 = NOVALUE;
    int _30167 = NOVALUE;
    int _30165 = NOVALUE;
    int _30162 = NOVALUE;
    int _30161 = NOVALUE;
    int _30160 = NOVALUE;
    int _30158 = NOVALUE;
    int _30157 = NOVALUE;
    int _30154 = NOVALUE;
    int _30152 = NOVALUE;
    int _30150 = NOVALUE;
    int _30149 = NOVALUE;
    int _30148 = NOVALUE;
    int _30147 = NOVALUE;
    int _30145 = NOVALUE;
    int _30144 = NOVALUE;
    int _30143 = NOVALUE;
    int _30142 = NOVALUE;
    int _30141 = NOVALUE;
    int _30140 = NOVALUE;
    int _30137 = NOVALUE;
    int _30135 = NOVALUE;
    int _30133 = NOVALUE;
    int _30131 = NOVALUE;
    int _30129 = NOVALUE;
    int _30126 = NOVALUE;
    int _30124 = NOVALUE;
    int _30123 = NOVALUE;
    int _30120 = NOVALUE;
    int _30116 = NOVALUE;
    int _30115 = NOVALUE;
    int _30113 = NOVALUE;
    int _30111 = NOVALUE;
    int _30109 = NOVALUE;
    int _30107 = NOVALUE;
    int _30105 = NOVALUE;
    int _30103 = NOVALUE;
    int _30102 = NOVALUE;
    int _30101 = NOVALUE;
    int _30100 = NOVALUE;
    int _30099 = NOVALUE;
    int _30098 = NOVALUE;
    int _30097 = NOVALUE;
    int _30096 = NOVALUE;
    int _30095 = NOVALUE;
    int _30094 = NOVALUE;
    int _30093 = NOVALUE;
    int _30092 = NOVALUE;
    int _30089 = NOVALUE;
    int _30088 = NOVALUE;
    int _30087 = NOVALUE;
    int _30086 = NOVALUE;
    int _30085 = NOVALUE;
    int _30084 = NOVALUE;
    int _30083 = NOVALUE;
    int _30082 = NOVALUE;
    int _30081 = NOVALUE;
    int _30080 = NOVALUE;
    int _30079 = NOVALUE;
    int _30078 = NOVALUE;
    int _30077 = NOVALUE;
    int _30076 = NOVALUE;
    int _30075 = NOVALUE;
    int _30073 = NOVALUE;
    int _30071 = NOVALUE;
    int _30070 = NOVALUE;
    int _30065 = NOVALUE;
    int _30064 = NOVALUE;
    int _30062 = NOVALUE;
    int _30061 = NOVALUE;
    int _30060 = NOVALUE;
    int _30059 = NOVALUE;
    int _30058 = NOVALUE;
    int _30057 = NOVALUE;
    int _30056 = NOVALUE;
    int _30055 = NOVALUE;
    int _30054 = NOVALUE;
    int _30053 = NOVALUE;
    int _30051 = NOVALUE;
    int _30050 = NOVALUE;
    int _30048 = NOVALUE;
    int _30047 = NOVALUE;
    int _30046 = NOVALUE;
    int _30045 = NOVALUE;
    int _30044 = NOVALUE;
    int _30043 = NOVALUE;
    int _30042 = NOVALUE;
    int _30040 = NOVALUE;
    int _30037 = NOVALUE;
    int _30035 = NOVALUE;
    int _30033 = NOVALUE;
    int _30031 = NOVALUE;
    int _30029 = NOVALUE;
    int _30027 = NOVALUE;
    int _30025 = NOVALUE;
    int _30023 = NOVALUE;
    int _30021 = NOVALUE;
    int _30020 = NOVALUE;
    int _30019 = NOVALUE;
    int _30018 = NOVALUE;
    int _30017 = NOVALUE;
    int _30016 = NOVALUE;
    int _30015 = NOVALUE;
    int _30013 = NOVALUE;
    int _30012 = NOVALUE;
    int _30010 = NOVALUE;
    int _30008 = NOVALUE;
    int _30006 = NOVALUE;
    int _30005 = NOVALUE;
    int _30002 = NOVALUE;
    int _30001 = NOVALUE;
    int _30000 = NOVALUE;
    int _29999 = NOVALUE;
    int _29998 = NOVALUE;
    int _29996 = NOVALUE;
    int _29995 = NOVALUE;
    int _29994 = NOVALUE;
    int _29993 = NOVALUE;
    int _29992 = NOVALUE;
    int _29990 = NOVALUE;
    int _29989 = NOVALUE;
    int _29988 = NOVALUE;
    int _29986 = NOVALUE;
    int _29985 = NOVALUE;
    int _29984 = NOVALUE;
    int _29983 = NOVALUE;
    int _29979 = NOVALUE;
    int _29978 = NOVALUE;
    int _29977 = NOVALUE;
    int _29975 = NOVALUE;
    int _29974 = NOVALUE;
    int _29973 = NOVALUE;
    int _29972 = NOVALUE;
    int _29971 = NOVALUE;
    int _29970 = NOVALUE;
    int _29966 = NOVALUE;
    int _29965 = NOVALUE;
    int _29964 = NOVALUE;
    int _29962 = NOVALUE;
    int _29961 = NOVALUE;
    int _29960 = NOVALUE;
    int _29958 = NOVALUE;
    int _29957 = NOVALUE;
    int _29955 = NOVALUE;
    int _29954 = NOVALUE;
    int _29953 = NOVALUE;
    int _29949 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_59535)) {
        _1 = (long)(DBL_PTR(_prog_type_59535)->dbl);
        DeRefDS(_prog_type_59535);
        _prog_type_59535 = _1;
    }

    /** 	integer first_def_arg*/

    /** 	integer again*/

    /** 	integer type_enum*/

    /** 	object seq_sym*/

    /** 	object i1_sym*/

    /** 	sequence enum_syms = {}*/
    RefDS(_21815);
    DeRef(_enum_syms_59551);
    _enum_syms_59551 = _21815;

    /** 	integer type_enum_gline, real_gline*/

    /** 	LeaveTopLevel()*/
    _39LeaveTopLevel();

    /** 	prog_name = next_token()*/
    _0 = _prog_name_59545;
    _prog_name_59545 = _39next_token();
    DeRef(_0);

    /** 	if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29949 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29949, -21)){
        _29949 = NOVALUE;
        goto L1; // [43] 55
    }
    _29949 = NOVALUE;

    /** 		CompileErr( 32 )*/
    RefDS(_21815);
    _44CompileErr(32, _21815, 0);
L1: 

    /** 	type_enum =  0*/
    _type_enum_59548 = 0;

    /** 	if prog_type = TYPE_DECL then*/
    if (_prog_type_59535 != 416)
    goto L2; // [64] 316

    /** 		object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_59564);
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _tsym_59564 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_59564);

    /** 		if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29953 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29953);
    _29954 = _53sym_name(_29953);
    _29953 = NOVALUE;
    if (_29954 == _26036)
    _29955 = 1;
    else if (IS_ATOM_INT(_29954) && IS_ATOM_INT(_26036))
    _29955 = 0;
    else
    _29955 = (compare(_29954, _26036) == 0);
    DeRef(_29954);
    _29954 = NOVALUE;
    if (_29955 == 0)
    {
        _29955 = NOVALUE;
        goto L3; // [92] 313
    }
    else{
        _29955 = NOVALUE;
    }

    /** 			EnterTopLevel( FALSE )*/
    _39EnterTopLevel(_13FALSE_435);

    /** 			type_enum_gline = gline_number*/
    _type_enum_gline_59552 = _35gline_number_15973;

    /** 			type_enum = 1*/
    _type_enum_59548 = 1;

    /** 			sequence seq_symbol*/

    /** 			prog_name = next_token()*/
    _0 = _prog_name_59545;
    _prog_name_59545 = _39next_token();
    DeRef(_0);

    /** 			if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29957 = (int)*(((s1_ptr)_2)->base + 1);
    _29958 = find_from(_29957, _37ADDR_TOKS_15598, 1);
    _29957 = NOVALUE;
    if (_29958 != 0)
    goto L4; // [138] 163
    _29958 = NOVALUE;

    /** 				CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29960 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29960);
    _29961 = _63find_category(_29960);
    _29960 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29961;
    _29962 = MAKE_SEQ(_1);
    _29961 = NOVALUE;
    _44CompileErr(25, _29962, 0);
    _29962 = NOVALUE;
L4: 

    /** 			enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_59551;
    _enum_syms_59551 = _39Global_declaration(-1, _scope_59536);
    DeRef(_0);

    /** 			seq_symbol = enum_syms*/
    RefDS(_enum_syms_59551);
    DeRef(_seq_symbol_59575);
    _seq_symbol_59575 = _enum_syms_59551;

    /** 			for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_59551)){
            _29964 = SEQ_PTR(_enum_syms_59551)->length;
    }
    else {
        _29964 = 1;
    }
    {
        int _i_59591;
        _i_59591 = 1;
L5: 
        if (_i_59591 > _29964){
            goto L6; // [184] 212
        }

        /** 				seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (int)SEQ_PTR(_enum_syms_59551);
        _29965 = (int)*(((s1_ptr)_2)->base + _i_59591);
        Ref(_29965);
        _29966 = _53sym_obj(_29965);
        _29965 = NOVALUE;
        _2 = (int)SEQ_PTR(_seq_symbol_59575);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_symbol_59575 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_59591);
        _1 = *(int *)_2;
        *(int *)_2 = _29966;
        if( _1 != _29966 ){
            DeRef(_1);
        }
        _29966 = NOVALUE;

        /** 			end for*/
        _i_59591 = _i_59591 + 1;
        goto L5; // [207] 191
L6: 
        ;
    }

    /** 			i1_sym = keyfind("i1",-1)*/
    RefDS(_29967);
    DeRef(_31356);
    _31356 = _29967;
    _31357 = _53hashfn(_31356);
    _31356 = NOVALUE;
    RefDS(_29967);
    _0 = _i1_sym_59550;
    _i1_sym_59550 = _53keyfind(_29967, -1, _35current_file_no_15968, 0, _31357);
    DeRef(_0);
    _31357 = NOVALUE;

    /** 			seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_59575);
    _0 = _seq_sym_59549;
    _seq_sym_59549 = _53NewStringSym(_seq_symbol_59575);
    DeRef(_0);

    /** 			putback(keyfind("return",-1))*/
    RefDS(_26110);
    DeRef(_31354);
    _31354 = _26110;
    _31355 = _53hashfn(_31354);
    _31354 = NOVALUE;
    RefDS(_26110);
    _29970 = _53keyfind(_26110, -1, _35current_file_no_15968, 0, _31355);
    _31355 = NOVALUE;
    _39putback(_29970);
    _29970 = NOVALUE;

    /** 			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _29971 = MAKE_SEQ(_1);
    _39putback(_29971);
    _29971 = NOVALUE;

    /** 			putback(i1_sym)*/
    Ref(_i1_sym_59550);
    _39putback(_i1_sym_59550);

    /** 			putback(keyfind("object",-1))*/
    RefDS(_24424);
    DeRef(_31352);
    _31352 = _24424;
    _31353 = _53hashfn(_31352);
    _31352 = NOVALUE;
    RefDS(_24424);
    _29972 = _53keyfind(_24424, -1, _35current_file_no_15968, 0, _31353);
    _31353 = NOVALUE;
    _39putback(_29972);
    _29972 = NOVALUE;

    /** 			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _29973 = MAKE_SEQ(_1);
    _39putback(_29973);
    _29973 = NOVALUE;

    /** 			LeaveTopLevel()*/
    _39LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_59575);
    _seq_symbol_59575 = NOVALUE;
L2: 
    DeRef(_tsym_59564);
    _tsym_59564 = NOVALUE;

    /** 	if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29974 = (int)*(((s1_ptr)_2)->base + 1);
    _29975 = find_from(_29974, _37ADDR_TOKS_15598, 1);
    _29974 = NOVALUE;
    if (_29975 != 0)
    goto L7; // [333] 358
    _29975 = NOVALUE;

    /** 		CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _29977 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29977);
    _29978 = _63find_category(_29977);
    _29977 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29978;
    _29979 = MAKE_SEQ(_1);
    _29978 = NOVALUE;
    _44CompileErr(25, _29979, 0);
    _29979 = NOVALUE;
L7: 

    /** 	p = prog_name[T_SYM]*/
    _2 = (int)SEQ_PTR(_prog_name_59545);
    _p_59540 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_59540)){
        _p_59540 = (long)DBL_PTR(_p_59540)->dbl;
    }

    /** 	DefinedYet(p)*/
    _53DefinedYet(_p_59540);

    /** 	if prog_type = PROCEDURE then*/
    if (_prog_type_59535 != 405)
    goto L8; // [377] 393

    /** 		pt = PROC*/
    _pt_59538 = 27;
    goto L9; // [390] 423
L8: 

    /** 	elsif prog_type = FUNCTION then*/
    if (_prog_type_59535 != 406)
    goto LA; // [397] 413

    /** 		pt = FUNC*/
    _pt_59538 = 501;
    goto L9; // [410] 423
LA: 

    /** 		pt = TYPE*/
    _pt_59538 = 504;
L9: 

    /** 	clear_fwd_refs()*/
    _38clear_fwd_refs();

    /** 	if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29983 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_29983);
    _29984 = (int)*(((s1_ptr)_2)->base + 4);
    _29983 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 7;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    *((int *)(_2+20)) = 12;
    _29985 = MAKE_SEQ(_1);
    _29986 = find_from(_29984, _29985, 1);
    _29984 = NOVALUE;
    DeRefDS(_29985);
    _29985 = NOVALUE;
    if (_29986 == 0)
    {
        _29986 = NOVALUE;
        goto LB; // [464] 660
    }
    else{
        _29986 = NOVALUE;
    }

    /** 		if scope = SC_OVERRIDE then*/
    if (_scope_59536 != 12)
    goto LC; // [471] 597

    /** 			if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29988 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_29988);
    _29989 = (int)*(((s1_ptr)_2)->base + 4);
    _29988 = NOVALUE;
    if (IS_ATOM_INT(_29989)) {
        _29990 = (_29989 == 7);
    }
    else {
        _29990 = binary_op(EQUALS, _29989, 7);
    }
    _29989 = NOVALUE;
    if (IS_ATOM_INT(_29990)) {
        if (_29990 != 0) {
            goto LD; // [495] 522
        }
    }
    else {
        if (DBL_PTR(_29990)->dbl != 0.0) {
            goto LD; // [495] 522
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29992 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_29992);
    _29993 = (int)*(((s1_ptr)_2)->base + 4);
    _29992 = NOVALUE;
    if (IS_ATOM_INT(_29993)) {
        _29994 = (_29993 == 12);
    }
    else {
        _29994 = binary_op(EQUALS, _29993, 12);
    }
    _29993 = NOVALUE;
    if (_29994 == 0) {
        DeRef(_29994);
        _29994 = NOVALUE;
        goto LE; // [518] 596
    }
    else {
        if (!IS_ATOM_INT(_29994) && DBL_PTR(_29994)->dbl == 0.0){
            DeRef(_29994);
            _29994 = NOVALUE;
            goto LE; // [518] 596
        }
        DeRef(_29994);
        _29994 = NOVALUE;
    }
    DeRef(_29994);
    _29994 = NOVALUE;
LD: 

    /** 					if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29995 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_29995);
    _29996 = (int)*(((s1_ptr)_2)->base + 4);
    _29995 = NOVALUE;
    if (binary_op_a(NOTEQ, _29996, 12)){
        _29996 = NOVALUE;
        goto LF; // [538] 550
    }
    _29996 = NOVALUE;

    /** 						again = 223*/
    _again_59547 = 223;
    goto L10; // [547] 556
LF: 

    /** 						again = 222*/
    _again_59547 = 222;
L10: 

    /** 					Warning(again, override_warning_flag,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _29998 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _29999 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_29999);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _30000 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _30000 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _29999 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_29998);
    *((int *)(_2+4)) = _29998;
    *((int *)(_2+8)) = _35line_number_15969;
    Ref(_30000);
    *((int *)(_2+12)) = _30000;
    _30001 = MAKE_SEQ(_1);
    _30000 = NOVALUE;
    _29998 = NOVALUE;
    _44Warning(_again_59547, 4, _30001);
    _30001 = NOVALUE;
LE: 
LC: 

    /** 		h = SymTab[p][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30002 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30002);
    _h_59537 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_59537)){
        _h_59537 = (long)DBL_PTR(_h_59537)->dbl;
    }
    _30002 = NOVALUE;

    /** 		sym = buckets[h]*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _sym_59542 = (int)*(((s1_ptr)_2)->base + _h_59537);
    if (!IS_ATOM_INT(_sym_59542)){
        _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
    }

    /** 		p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30005 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30005);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _30006 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _30006 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _30005 = NOVALUE;
    Ref(_30006);
    _p_59540 = _53NewEntry(_30006, 0, 0, _pt_59538, _h_59537, _sym_59542, 0);
    _30006 = NOVALUE;
    if (!IS_ATOM_INT(_p_59540)) {
        _1 = (long)(DBL_PTR(_p_59540)->dbl);
        DeRefDS(_p_59540);
        _p_59540 = _1;
    }

    /** 		buckets[h] = p*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _2 = (int)(((s1_ptr)_2)->base + _h_59537);
    _1 = *(int *)_2;
    *(int *)_2 = _p_59540;
    DeRef(_1);
LB: 

    /** 	Start_block( pt, p )*/
    _66Start_block(_pt_59538, _p_59540);

    /** 	CurrentSub = p*/
    _35CurrentSub_15976 = _p_59540;

    /** 	first_def_arg = 0*/
    _first_def_arg_59546 = 0;

    /** 	temps_allocated = 0*/
    _53temps_allocated_46235 = 0;

    /** 	SymTab[p][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_59536;
    DeRef(_1);
    _30008 = NOVALUE;

    /** 	SymTab[p][S_TOKEN] = pt*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    _1 = *(int *)_2;
    *(int *)_2 = _pt_59538;
    DeRef(_1);
    _30010 = NOVALUE;

    /** 	if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30012 = (int)*(((s1_ptr)_2)->base + _p_59540);
    if (IS_SEQUENCE(_30012)){
            _30013 = SEQ_PTR(_30012)->length;
    }
    else {
        _30013 = 1;
    }
    _30012 = NOVALUE;
    if (_30013 >= _35SIZEOF_ROUTINE_ENTRY_15767)
    goto L11; // [730] 772

    /** 		SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30015 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30016 = (int)*(((s1_ptr)_2)->base + _p_59540);
    if (IS_SEQUENCE(_30016)){
            _30017 = SEQ_PTR(_30016)->length;
    }
    else {
        _30017 = 1;
    }
    _30016 = NOVALUE;
    _30018 = _35SIZEOF_ROUTINE_ENTRY_15767 - _30017;
    _30017 = NOVALUE;
    _30019 = Repeat(0, _30018);
    _30018 = NOVALUE;
    if (IS_SEQUENCE(_30015) && IS_ATOM(_30019)) {
    }
    else if (IS_ATOM(_30015) && IS_SEQUENCE(_30019)) {
        Ref(_30015);
        Prepend(&_30020, _30019, _30015);
    }
    else {
        Concat((object_ptr)&_30020, _30015, _30019);
        _30015 = NOVALUE;
    }
    _30015 = NOVALUE;
    DeRefDS(_30019);
    _30019 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_59540);
    _1 = *(int *)_2;
    *(int *)_2 = _30020;
    if( _1 != _30020 ){
        DeRef(_1);
    }
    _30020 = NOVALUE;
L11: 

    /** 	SymTab[p][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30021 = NOVALUE;

    /** 	SymTab[p][S_LINETAB] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30023 = NOVALUE;

    /** 	SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30025 = NOVALUE;

    /** 	SymTab[p][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _30027 = NOVALUE;

    /** 	SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15681))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15681)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15681);
    _1 = *(int *)_2;
    *(int *)_2 = _35gline_number_15973;
    DeRef(_1);
    _30029 = NOVALUE;

    /** 	SymTab[p][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TEMPS_15686))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TEMPS_15686);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30031 = NOVALUE;

    /** 	SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30033 = NOVALUE;

    /** 	SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    RefDS(_21815);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _21815;
    DeRef(_1);
    _30035 = NOVALUE;

    /** 	if type_enum then*/
    if (_type_enum_59548 == 0)
    {
        goto L12; // [898] 955
    }
    else{
    }

    /** 		SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FIRSTLINE_15681))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FIRSTLINE_15681)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FIRSTLINE_15681);
    _1 = *(int *)_2;
    *(int *)_2 = _type_enum_gline_59552;
    DeRef(_1);
    _30037 = NOVALUE;

    /** 		real_gline = gline_number*/
    _real_gline_59553 = _35gline_number_15973;

    /** 		gline_number = type_enum_gline*/
    _35gline_number_15973 = _type_enum_gline_59552;

    /** 		StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _41StartSourceLine(_13FALSE_435, 0, 3);

    /** 		gline_number = real_gline*/
    _35gline_number_15973 = _real_gline_59553;
    goto L13; // [952] 967
L12: 

    /** 		StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _41StartSourceLine(_13FALSE_435, 0, 3);
L13: 

    /** 	tok_match(LEFT_ROUND)*/
    _39tok_match(-26, 0);

    /** 	tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 	param_num = 0*/
    _39param_num_53678 = 0;

    /** 	sequence middle_def_args = {}*/
    RefDS(_21815);
    DeRef(_middle_def_args_59774);
    _middle_def_args_59774 = _21815;

    /** 	integer last_nda = 0, start_def = 0*/
    _last_nda_59775 = 0;
    _start_def_59776 = 0;

    /** 	symtab_index last_link = p*/
    _last_link_59778 = _p_59540;

    /** 	while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (int)SEQ_PTR(_tok_59544);
    _30040 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30040, -27)){
        _30040 = NOVALUE;
        goto L15; // [1020] 1793
    }
    _30040 = NOVALUE;

    /** 		if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30042 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30042)) {
        _30043 = (_30042 != 504);
    }
    else {
        _30043 = binary_op(NOTEQ, _30042, 504);
    }
    _30042 = NOVALUE;
    if (IS_ATOM_INT(_30043)) {
        if (_30043 == 0) {
            goto L16; // [1038] 1262
        }
    }
    else {
        if (DBL_PTR(_30043)->dbl == 0.0) {
            goto L16; // [1038] 1262
        }
    }
    _2 = (int)SEQ_PTR(_tok_59544);
    _30045 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30045)) {
        _30046 = (_30045 != 522);
    }
    else {
        _30046 = binary_op(NOTEQ, _30045, 522);
    }
    _30045 = NOVALUE;
    if (_30046 == 0) {
        DeRef(_30046);
        _30046 = NOVALUE;
        goto L16; // [1055] 1262
    }
    else {
        if (!IS_ATOM_INT(_30046) && DBL_PTR(_30046)->dbl == 0.0){
            DeRef(_30046);
            _30046 = NOVALUE;
            goto L16; // [1055] 1262
        }
        DeRef(_30046);
        _30046 = NOVALUE;
    }
    DeRef(_30046);
    _30046 = NOVALUE;

    /** 			if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30047 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30047)) {
        _30048 = (_30047 == -100);
    }
    else {
        _30048 = binary_op(EQUALS, _30047, -100);
    }
    _30047 = NOVALUE;
    if (IS_ATOM_INT(_30048)) {
        if (_30048 != 0) {
            goto L17; // [1072] 1093
        }
    }
    else {
        if (DBL_PTR(_30048)->dbl != 0.0) {
            goto L17; // [1072] 1093
        }
    }
    _2 = (int)SEQ_PTR(_tok_59544);
    _30050 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30050)) {
        _30051 = (_30050 == 512);
    }
    else {
        _30051 = binary_op(EQUALS, _30050, 512);
    }
    _30050 = NOVALUE;
    if (_30051 == 0) {
        DeRef(_30051);
        _30051 = NOVALUE;
        goto L18; // [1089] 1253
    }
    else {
        if (!IS_ATOM_INT(_30051) && DBL_PTR(_30051)->dbl == 0.0){
            DeRef(_30051);
            _30051 = NOVALUE;
            goto L18; // [1089] 1253
        }
        DeRef(_30051);
        _30051 = NOVALUE;
    }
    DeRef(_30051);
    _30051 = NOVALUE;
L17: 

    /** 				token temptok = next_token()*/
    _0 = _temptok_59805;
    _temptok_59805 = _39next_token();
    DeRef(_0);

    /** 				integer undef_type = 0*/
    _undef_type_59807 = 0;

    /** 				if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_temptok_59805);
    _30053 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30053)) {
        _30054 = (_30053 != 504);
    }
    else {
        _30054 = binary_op(NOTEQ, _30053, 504);
    }
    _30053 = NOVALUE;
    if (IS_ATOM_INT(_30054)) {
        if (_30054 == 0) {
            goto L19; // [1117] 1218
        }
    }
    else {
        if (DBL_PTR(_30054)->dbl == 0.0) {
            goto L19; // [1117] 1218
        }
    }
    _2 = (int)SEQ_PTR(_temptok_59805);
    _30056 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30056)) {
        _30057 = (_30056 != 522);
    }
    else {
        _30057 = binary_op(NOTEQ, _30056, 522);
    }
    _30056 = NOVALUE;
    if (_30057 == 0) {
        DeRef(_30057);
        _30057 = NOVALUE;
        goto L19; // [1134] 1218
    }
    else {
        if (!IS_ATOM_INT(_30057) && DBL_PTR(_30057)->dbl == 0.0){
            DeRef(_30057);
            _30057 = NOVALUE;
            goto L19; // [1134] 1218
        }
        DeRef(_30057);
        _30057 = NOVALUE;
    }
    DeRef(_30057);
    _30057 = NOVALUE;

    /** 					if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_temptok_59805);
    _30058 = (int)*(((s1_ptr)_2)->base + 1);
    _30059 = find_from(_30058, _37FULL_ID_TOKS_15602, 1);
    _30058 = NOVALUE;
    if (_30059 == 0)
    {
        _30059 = NOVALUE;
        goto L1A; // [1152] 1217
    }
    else{
        _30059 = NOVALUE;
    }

    /** 						if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30060 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30060)){
        _30061 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30060)->dbl));
    }
    else{
        _30061 = (int)*(((s1_ptr)_2)->base + _30060);
    }
    _2 = (int)SEQ_PTR(_30061);
    _30062 = (int)*(((s1_ptr)_2)->base + 4);
    _30061 = NOVALUE;
    if (binary_op_a(NOTEQ, _30062, 9)){
        _30062 = NOVALUE;
        goto L1B; // [1177] 1208
    }
    _30062 = NOVALUE;

    /** 							undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30064 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_31351);
    _31351 = 504;
    Ref(_30064);
    _30065 = _38new_forward_reference(504, _30064, 504);
    _30064 = NOVALUE;
    _31351 = NOVALUE;
    if (IS_ATOM_INT(_30065)) {
        if ((unsigned long)_30065 == 0xC0000000)
        _undef_type_59807 = (int)NewDouble((double)-0xC0000000);
        else
        _undef_type_59807 = - _30065;
    }
    else {
        _undef_type_59807 = unary_op(UMINUS, _30065);
    }
    DeRef(_30065);
    _30065 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_59807)) {
        _1 = (long)(DBL_PTR(_undef_type_59807)->dbl);
        DeRefDS(_undef_type_59807);
        _undef_type_59807 = _1;
    }
    goto L1C; // [1205] 1216
L1B: 

    /** 							CompileErr(37)*/
    RefDS(_21815);
    _44CompileErr(37, _21815, 0);
L1C: 
L1A: 
L19: 

    /** 				putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_59805);
    _39putback(_temptok_59805);

    /** 				if undef_type != 0 then*/
    if (_undef_type_59807 == 0)
    goto L1D; // [1225] 1240

    /** 					tok[T_SYM] = undef_type*/
    _2 = (int)SEQ_PTR(_tok_59544);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_59544 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _undef_type_59807;
    DeRef(_1);
    goto L1E; // [1237] 1248
L1D: 

    /** 					CompileErr(37)*/
    RefDS(_21815);
    _44CompileErr(37, _21815, 0);
L1E: 
    DeRef(_temptok_59805);
    _temptok_59805 = NOVALUE;
    goto L1F; // [1250] 1261
L18: 

    /** 				CompileErr(37)*/
    RefDS(_21815);
    _44CompileErr(37, _21815, 0);
L1F: 
L16: 

    /** 		type_sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _type_sym_59541 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_59541)){
        _type_sym_59541 = (long)DBL_PTR(_type_sym_59541)->dbl;
    }

    /** 		tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30070 = (int)*(((s1_ptr)_2)->base + 1);
    _30071 = find_from(_30070, _37ID_TOKS_15600, 1);
    _30070 = NOVALUE;
    if (_30071 != 0)
    goto L20; // [1292] 1406
    _30071 = NOVALUE;

    /** 			sequence tokcat = find_category(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30073 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30073);
    _0 = _tokcat_59856;
    _tokcat_59856 = _63find_category(_30073);
    DeRef(_0);
    _30073 = NOVALUE;

    /** 			if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30075 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30075)) {
        _30076 = (_30075 != 0);
    }
    else {
        _30076 = binary_op(NOTEQ, _30075, 0);
    }
    _30075 = NOVALUE;
    if (IS_ATOM_INT(_30076)) {
        if (_30076 == 0) {
            goto L21; // [1321] 1382
        }
    }
    else {
        if (DBL_PTR(_30076)->dbl == 0.0) {
            goto L21; // [1321] 1382
        }
    }
    _2 = (int)SEQ_PTR(_tok_59544);
    _30078 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30078)){
        _30079 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30078)->dbl));
    }
    else{
        _30079 = (int)*(((s1_ptr)_2)->base + _30078);
    }
    if (IS_SEQUENCE(_30079)){
            _30080 = SEQ_PTR(_30079)->length;
    }
    else {
        _30080 = 1;
    }
    _30079 = NOVALUE;
    if (IS_ATOM_INT(_35S_NAME_15641)) {
        _30081 = (_30080 >= _35S_NAME_15641);
    }
    else {
        _30081 = binary_op(GREATEREQ, _30080, _35S_NAME_15641);
    }
    _30080 = NOVALUE;
    if (_30081 == 0) {
        DeRef(_30081);
        _30081 = NOVALUE;
        goto L21; // [1347] 1382
    }
    else {
        if (!IS_ATOM_INT(_30081) && DBL_PTR(_30081)->dbl == 0.0){
            DeRef(_30081);
            _30081 = NOVALUE;
            goto L21; // [1347] 1382
        }
        DeRef(_30081);
        _30081 = NOVALUE;
    }
    DeRef(_30081);
    _30081 = NOVALUE;

    /** 				CompileErr(90, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30082 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30082)){
        _30083 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30082)->dbl));
    }
    else{
        _30083 = (int)*(((s1_ptr)_2)->base + _30082);
    }
    _2 = (int)SEQ_PTR(_30083);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _30084 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _30084 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _30083 = NOVALUE;
    Ref(_30084);
    RefDS(_tokcat_59856);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tokcat_59856;
    ((int *)_2)[2] = _30084;
    _30085 = MAKE_SEQ(_1);
    _30084 = NOVALUE;
    _44CompileErr(90, _30085, 0);
    _30085 = NOVALUE;
    goto L22; // [1379] 1405
L21: 

    /** 				CompileErr(92, {LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30086 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30086);
    RefDS(_26183);
    _30087 = _41LexName(_30086, _26183);
    _30086 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30087;
    _30088 = MAKE_SEQ(_1);
    _30087 = NOVALUE;
    _44CompileErr(92, _30088, 0);
    _30088 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_59856);
    _tokcat_59856 = NOVALUE;

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30089 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30089);
    _sym_59542 = _39SetPrivateScope(_30089, _type_sym_59541, _39param_num_53678);
    _30089 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59542)) {
        _1 = (long)(DBL_PTR(_sym_59542)->dbl);
        DeRefDS(_sym_59542);
        _sym_59542 = _1;
    }

    /** 		param_num += 1*/
    _39param_num_53678 = _39param_num_53678 + 1;

    /** 		if SymTab[last_link][S_NEXT] != sym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30092 = (int)*(((s1_ptr)_2)->base + _last_link_59778);
    _2 = (int)SEQ_PTR(_30092);
    _30093 = (int)*(((s1_ptr)_2)->base + 2);
    _30092 = NOVALUE;
    if (IS_ATOM_INT(_30093)) {
        _30094 = (_30093 != _sym_59542);
    }
    else {
        _30094 = binary_op(NOTEQ, _30093, _sym_59542);
    }
    _30093 = NOVALUE;
    if (IS_ATOM_INT(_30094)) {
        if (_30094 == 0) {
            goto L23; // [1452] 1533
        }
    }
    else {
        if (DBL_PTR(_30094)->dbl == 0.0) {
            goto L23; // [1452] 1533
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30096 = (int)*(((s1_ptr)_2)->base + _last_link_59778);
    _2 = (int)SEQ_PTR(_30096);
    _30097 = (int)*(((s1_ptr)_2)->base + 2);
    _30096 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30097)){
        _30098 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30097)->dbl));
    }
    else{
        _30098 = (int)*(((s1_ptr)_2)->base + _30097);
    }
    _2 = (int)SEQ_PTR(_30098);
    _30099 = (int)*(((s1_ptr)_2)->base + 4);
    _30098 = NOVALUE;
    if (IS_ATOM_INT(_30099)) {
        _30100 = (_30099 == 9);
    }
    else {
        _30100 = binary_op(EQUALS, _30099, 9);
    }
    _30099 = NOVALUE;
    if (_30100 == 0) {
        DeRef(_30100);
        _30100 = NOVALUE;
        goto L23; // [1487] 1533
    }
    else {
        if (!IS_ATOM_INT(_30100) && DBL_PTR(_30100)->dbl == 0.0){
            DeRef(_30100);
            _30100 = NOVALUE;
            goto L23; // [1487] 1533
        }
        DeRef(_30100);
        _30100 = NOVALUE;
    }
    DeRef(_30100);
    _30100 = NOVALUE;

    /** 			SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30101 = (int)*(((s1_ptr)_2)->base + _last_link_59778);
    _2 = (int)SEQ_PTR(_30101);
    _30102 = (int)*(((s1_ptr)_2)->base + 2);
    _30101 = NOVALUE;
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30102))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30102)->dbl));
    else
    _3 = (int)(_30102 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30103 = NOVALUE;

    /** 			SymTab[last_link][S_NEXT] = sym*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_last_link_59778 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_59542;
    DeRef(_1);
    _30105 = NOVALUE;
L23: 

    /** 		last_link = sym*/
    _last_link_59778 = _sym_59542;

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L24; // [1544] 1567
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59542 + ((s1_ptr)_2)->base);
    _30109 = _39CompileType(_type_sym_59541);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30109;
    if( _1 != _30109 ){
        DeRef(_1);
    }
    _30109 = NOVALUE;
    _30107 = NOVALUE;
L24: 

    /** 		tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30111 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30111, 3)){
        _30111 = NOVALUE;
        goto L25; // [1582] 1664
    }
    _30111 = NOVALUE;

    /** 			start_recording()*/
    _39start_recording();

    /** 			Expr()*/
    _39Expr();

    /** 			SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59542 + ((s1_ptr)_2)->base);
    _30115 = _39restore_parser();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _30115;
    if( _1 != _30115 ){
        DeRef(_1);
    }
    _30115 = NOVALUE;
    _30113 = NOVALUE;

    /** 			if Pop() then end if -- don't leak the default argument*/
    _30116 = _41Pop();
    if (_30116 == 0) {
        DeRef(_30116);
        _30116 = NOVALUE;
        goto L26; // [1617] 1621
    }
    else {
        if (!IS_ATOM_INT(_30116) && DBL_PTR(_30116)->dbl == 0.0){
            DeRef(_30116);
            _30116 = NOVALUE;
            goto L26; // [1617] 1621
        }
        DeRef(_30116);
        _30116 = NOVALUE;
    }
    DeRef(_30116);
    _30116 = NOVALUE;
L26: 

    /** 			tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 			if first_def_arg = 0 then*/
    if (_first_def_arg_59546 != 0)
    goto L27; // [1628] 1640

    /** 				first_def_arg = param_num*/
    _first_def_arg_59546 = _39param_num_53678;
L27: 

    /** 			previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _35previous_op_16066 = -1;

    /** 			if start_def = 0 then*/
    if (_start_def_59776 != 0)
    goto L28; // [1649] 1721

    /** 				start_def = param_num*/
    _start_def_59776 = _39param_num_53678;
    goto L28; // [1661] 1721
L25: 

    /** 			last_nda = param_num*/
    _last_nda_59775 = _39param_num_53678;

    /** 			if start_def then*/
    if (_start_def_59776 == 0)
    {
        goto L29; // [1673] 1720
    }
    else{
    }

    /** 				if start_def = param_num-1 then*/
    _30120 = _39param_num_53678 - 1;
    if ((long)((unsigned long)_30120 +(unsigned long) HIGH_BITS) >= 0){
        _30120 = NewDouble((double)_30120);
    }
    if (binary_op_a(NOTEQ, _start_def_59776, _30120)){
        DeRef(_30120);
        _30120 = NOVALUE;
        goto L2A; // [1684] 1697
    }
    DeRef(_30120);
    _30120 = NOVALUE;

    /** 					middle_def_args &= start_def*/
    Append(&_middle_def_args_59774, _middle_def_args_59774, _start_def_59776);
    goto L2B; // [1694] 1714
L2A: 

    /** 					middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30123 = _39param_num_53678 - 1;
    if ((long)((unsigned long)_30123 +(unsigned long) HIGH_BITS) >= 0){
        _30123 = NewDouble((double)_30123);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _start_def_59776;
    ((int *)_2)[2] = _30123;
    _30124 = MAKE_SEQ(_1);
    _30123 = NOVALUE;
    RefDS(_30124);
    Append(&_middle_def_args_59774, _middle_def_args_59774, _30124);
    DeRefDS(_30124);
    _30124 = NOVALUE;
L2B: 

    /** 				start_def = 0*/
    _start_def_59776 = 0;
L29: 
L28: 

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30126 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30126, -30)){
        _30126 = NOVALUE;
        goto L2C; // [1731] 1765
    }
    _30126 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30129 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30129, -27)){
        _30129 = NOVALUE;
        goto L14; // [1750] 1012
    }
    _30129 = NOVALUE;

    /** 				CompileErr(85)*/
    RefDS(_21815);
    _44CompileErr(85, _21815, 0);
    goto L14; // [1762] 1012
L2C: 

    /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30131 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30131, -27)){
        _30131 = NOVALUE;
        goto L14; // [1775] 1012
    }
    _30131 = NOVALUE;

    /** 			CompileErr(41)*/
    RefDS(_21815);
    _44CompileErr(41, _21815, 0);

    /** 	end while*/
    goto L14; // [1790] 1012
L15: 

    /** 	Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_21815);
    DeRef(_35Code_16056);
    _35Code_16056 = _21815;

    /** 	SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    _1 = *(int *)_2;
    *(int *)_2 = _39param_num_53678;
    DeRef(_1);
    _30133 = NOVALUE;

    /** 	SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _first_def_arg_59546;
    *((int *)(_2+8)) = _last_nda_59775;
    RefDS(_middle_def_args_59774);
    *((int *)(_2+12)) = _middle_def_args_59774;
    _30137 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _30137;
    if( _1 != _30137 ){
        DeRef(_1);
    }
    _30137 = NOVALUE;
    _30135 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2D; // [1842] 1876
    }
    else{
    }

    /** 		if param_num > max_params then*/
    if (_39param_num_53678 <= _41max_params_49780)
    goto L2E; // [1851] 1865

    /** 			max_params = param_num*/
    _41max_params_49780 = _39param_num_53678;
L2E: 

    /** 		num_routines += 1*/
    _35num_routines_15977 = _35num_routines_15977 + 1;
L2D: 

    /** 	if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30140 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30140);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _30141 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _30141 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _30140 = NOVALUE;
    if (IS_ATOM_INT(_30141)) {
        _30142 = (_30141 == 504);
    }
    else {
        _30142 = binary_op(EQUALS, _30141, 504);
    }
    _30141 = NOVALUE;
    if (IS_ATOM_INT(_30142)) {
        if (_30142 == 0) {
            goto L2F; // [1896] 1918
        }
    }
    else {
        if (DBL_PTR(_30142)->dbl == 0.0) {
            goto L2F; // [1896] 1918
        }
    }
    _30144 = (_39param_num_53678 != 1);
    if (_30144 == 0)
    {
        DeRef(_30144);
        _30144 = NOVALUE;
        goto L2F; // [1907] 1918
    }
    else{
        DeRef(_30144);
        _30144 = NOVALUE;
    }

    /** 		CompileErr(148)*/
    RefDS(_21815);
    _44CompileErr(148, _21815, 0);
L2F: 

    /** 	include_routine()*/
    _50include_routine();

    /** 	sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30145 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30145);
    _sym_59542 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59542)){
        _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
    }
    _30145 = NOVALUE;

    /** 	for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30147 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30147);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _30148 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _30148 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _30147 = NOVALUE;
    {
        int _i_60010;
        _i_60010 = 1;
L30: 
        if (binary_op_a(GREATER, _i_60010, _30148)){
            goto L31; // [1952] 2031
        }

        /** 		while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30149 = (int)*(((s1_ptr)_2)->base + _sym_59542);
        _2 = (int)SEQ_PTR(_30149);
        _30150 = (int)*(((s1_ptr)_2)->base + 4);
        _30149 = NOVALUE;
        if (binary_op_a(EQUALS, _30150, 3)){
            _30150 = NOVALUE;
            goto L33; // [1978] 2003
        }
        _30150 = NOVALUE;

        /** 			sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30152 = (int)*(((s1_ptr)_2)->base + _sym_59542);
        _2 = (int)SEQ_PTR(_30152);
        _sym_59542 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59542)){
            _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
        }
        _30152 = NOVALUE;

        /** 		end while*/
        goto L32; // [2000] 1964
L33: 

        /** 		TypeCheck(sym)*/
        _39TypeCheck(_sym_59542);

        /** 		sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30154 = (int)*(((s1_ptr)_2)->base + _sym_59542);
        _2 = (int)SEQ_PTR(_30154);
        _sym_59542 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59542)){
            _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
        }
        _30154 = NOVALUE;

        /** 	end for*/
        _0 = _i_60010;
        if (IS_ATOM_INT(_i_60010)) {
            _i_60010 = _i_60010 + 1;
            if ((long)((unsigned long)_i_60010 +(unsigned long) HIGH_BITS) >= 0){
                _i_60010 = NewDouble((double)_i_60010);
            }
        }
        else {
            _i_60010 = binary_op_a(PLUS, _i_60010, 1);
        }
        DeRef(_0);
        goto L30; // [2026] 1959
L31: 
        ;
        DeRef(_i_60010);
    }

    /** 	tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (int)SEQ_PTR(_tok_59544);
    _30157 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30157)) {
        _30158 = (_30157 == 504);
    }
    else {
        _30158 = binary_op(EQUALS, _30157, 504);
    }
    _30157 = NOVALUE;
    if (IS_ATOM_INT(_30158)) {
        if (_30158 != 0) {
            goto L35; // [2053] 2074
        }
    }
    else {
        if (DBL_PTR(_30158)->dbl != 0.0) {
            goto L35; // [2053] 2074
        }
    }
    _2 = (int)SEQ_PTR(_tok_59544);
    _30160 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30160)) {
        _30161 = (_30160 == 522);
    }
    else {
        _30161 = binary_op(EQUALS, _30160, 522);
    }
    _30160 = NOVALUE;
    if (_30161 <= 0) {
        if (_30161 == 0) {
            DeRef(_30161);
            _30161 = NOVALUE;
            goto L36; // [2070] 2095
        }
        else {
            if (!IS_ATOM_INT(_30161) && DBL_PTR(_30161)->dbl == 0.0){
                DeRef(_30161);
                _30161 = NOVALUE;
                goto L36; // [2070] 2095
            }
            DeRef(_30161);
            _30161 = NOVALUE;
        }
    }
    DeRef(_30161);
    _30161 = NOVALUE;
L35: 

    /** 		Private_declaration(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_59544);
    _30162 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30162);
    _39Private_declaration(_30162);
    _30162 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_59544;
    _tok_59544 = _39next_token();
    DeRef(_0);

    /** 	end while*/
    goto L34; // [2092] 2041
L36: 

    /** 	if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L37; // [2099] 2202

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L38; // [2106] 2201
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 			emit_addr(p)*/
    _41emit_addr(_p_59540);

    /** 			sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30165 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30165);
    _sym_59542 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59542)){
        _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
    }
    _30165 = NOVALUE;

    /** 			for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _30167 = (int)*(((s1_ptr)_2)->base + _p_59540);
    _2 = (int)SEQ_PTR(_30167);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _30168 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _30168 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _30167 = NOVALUE;
    {
        int _i_60057;
        _i_60057 = 1;
L39: 
        if (binary_op_a(GREATER, _i_60057, _30168)){
            goto L3A; // [2151] 2193
        }

        /** 				emit_op(DISPLAY_VAR)*/
        _41emit_op(87);

        /** 				emit_addr(sym)*/
        _41emit_addr(_sym_59542);

        /** 				sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _30169 = (int)*(((s1_ptr)_2)->base + _sym_59542);
        _2 = (int)SEQ_PTR(_30169);
        _sym_59542 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59542)){
            _sym_59542 = (long)DBL_PTR(_sym_59542)->dbl;
        }
        _30169 = NOVALUE;

        /** 			end for*/
        _0 = _i_60057;
        if (IS_ATOM_INT(_i_60057)) {
            _i_60057 = _i_60057 + 1;
            if ((long)((unsigned long)_i_60057 +(unsigned long) HIGH_BITS) >= 0){
                _i_60057 = NewDouble((double)_i_60057);
            }
        }
        else {
            _i_60057 = binary_op_a(PLUS, _i_60057, 1);
        }
        DeRef(_0);
        goto L39; // [2188] 2158
L3A: 
        ;
        DeRef(_i_60057);
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _41emit_op(89);
L38: 
L37: 

    /** 	putback(tok)*/
    Ref(_tok_59544);
    _39putback(_tok_59544);

    /** 	FuncReturn = FALSE*/
    _39FuncReturn_53677 = _13FALSE_435;

    /** 	if type_enum then*/
    if (_type_enum_59548 == 0)
    {
        goto L3B; // [2218] 2387
    }
    else{
    }

    /** 		stmt_nest += 1*/
    _39stmt_nest_53701 = _39stmt_nest_53701 + 1;

    /** 		tok_match(RETURN)*/
    _39tok_match(413, 0);

    /** 		putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30172 = MAKE_SEQ(_1);
    _39putback(_30172);
    _30172 = NOVALUE;

    /** 		putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_59549);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _seq_sym_59549;
    _30173 = MAKE_SEQ(_1);
    _39putback(_30173);
    _30173 = NOVALUE;

    /** 		putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -30;
    ((int *)_2)[2] = 0;
    _30174 = MAKE_SEQ(_1);
    _39putback(_30174);
    _30174 = NOVALUE;

    /** 		putback(i1_sym)*/
    Ref(_i1_sym_59550);
    _39putback(_i1_sym_59550);

    /** 		putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30175 = MAKE_SEQ(_1);
    _39putback(_30175);
    _30175 = NOVALUE;

    /** 		putback(keyfind("find",-1))*/
    RefDS(_30176);
    DeRef(_31349);
    _31349 = _30176;
    _31350 = _53hashfn(_31349);
    _31349 = NOVALUE;
    RefDS(_30176);
    _30177 = _53keyfind(_30176, -1, _35current_file_no_15968, 0, _31350);
    _31350 = NOVALUE;
    _39putback(_30177);
    _30177 = NOVALUE;

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L3C; // [2316] 2342

    /** 			if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L3D; // [2323] 2341
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 				emit_addr(CurrentSub)*/
    _41emit_addr(_35CurrentSub_15976);
L3D: 
L3C: 

    /** 		Expr()*/
    _39Expr();

    /** 		FuncReturn = TRUE*/
    _39FuncReturn_53677 = _13TRUE_437;

    /** 		emit_op(RETURNF)*/
    _41emit_op(28);

    /** 		flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** 		stmt_nest -= 1*/
    _39stmt_nest_53701 = _39stmt_nest_53701 - 1;

    /** 		InitDelete()*/
    _39InitDelete();

    /** 		flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);
    goto L3E; // [2384] 2400
L3B: 

    /** 		Statement_list()*/
    _39Statement_list();

    /** 		tok_match(END)*/
    _39tok_match(402, 0);
L3E: 

    /** 	tok_match(prog_type, END)*/
    _39tok_match(_prog_type_59535, 402);

    /** 	if prog_type != PROCEDURE then*/
    if (_prog_type_59535 == 405)
    goto L3F; // [2412] 2460

    /** 		if not FuncReturn then*/
    if (_39FuncReturn_53677 != 0)
    goto L40; // [2420] 2450

    /** 			if prog_type = FUNCTION then*/
    if (_prog_type_59535 != 406)
    goto L41; // [2427] 2441

    /** 				CompileErr(120)*/
    RefDS(_21815);
    _44CompileErr(120, _21815, 0);
    goto L42; // [2438] 2449
L41: 

    /** 				CompileErr(149)*/
    RefDS(_21815);
    _44CompileErr(149, _21815, 0);
L42: 
L40: 

    /** 		emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _41emit_op(43);
    goto L43; // [2457] 2520
L3F: 

    /** 		StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 		if not TRANSLATE then*/
    if (_35TRANSLATE_15611 != 0)
    goto L44; // [2473] 2497

    /** 			if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L45; // [2480] 2496
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _41emit_op(88);

    /** 				emit_addr(p)*/
    _41emit_addr(_p_59540);
L45: 
L44: 

    /** 		emit_op(RETURNP)*/
    _41emit_op(29);

    /** 		if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L46; // [2508] 2519
    }
    else{
    }

    /** 			emit_op(BADRETURNF) -- just to mark end of procedure*/
    _41emit_op(43);
L46: 
L43: 

    /** 	Drop_block( pt )*/
    _66Drop_block(_pt_59538);

    /** 	if Strict_Override > 0 then*/
    if (_35Strict_Override_16034 <= 0)
    goto L47; // [2529] 2544

    /** 		Strict_Override -= 1	-- Reset at the end of each routine.*/
    _35Strict_Override_16034 = _35Strict_Override_16034 - 1;
L47: 

    /** 	SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    _30189 = _53temps_allocated_46235 + _39param_num_53678;
    if ((long)((unsigned long)_30189 + (unsigned long)HIGH_BITS) >= 0) 
    _30189 = NewDouble((double)_30189);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701)){
        _30190 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    }
    else{
        _30190 = (int)*(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    }
    _30187 = NOVALUE;
    if (IS_ATOM_INT(_30190) && IS_ATOM_INT(_30189)) {
        _30191 = _30190 + _30189;
        if ((long)((unsigned long)_30191 + (unsigned long)HIGH_BITS) >= 0) 
        _30191 = NewDouble((double)_30191);
    }
    else {
        _30191 = binary_op(PLUS, _30190, _30189);
    }
    _30190 = NOVALUE;
    DeRef(_30189);
    _30189 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_STACK_SPACE_15701))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_STACK_SPACE_15701)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_STACK_SPACE_15701);
    _1 = *(int *)_2;
    *(int *)_2 = _30191;
    if( _1 != _30191 ){
        DeRef(_1);
    }
    _30191 = NOVALUE;
    _30187 = NOVALUE;

    /** 	if temps_allocated + param_num > max_stack_per_call then*/
    _30192 = _53temps_allocated_46235 + _39param_num_53678;
    if ((long)((unsigned long)_30192 + (unsigned long)HIGH_BITS) >= 0) 
    _30192 = NewDouble((double)_30192);
    if (binary_op_a(LESSEQ, _30192, _35max_stack_per_call_16067)){
        DeRef(_30192);
        _30192 = NOVALUE;
        goto L48; // [2587] 2604
    }
    DeRef(_30192);
    _30192 = NOVALUE;

    /** 		max_stack_per_call = temps_allocated + param_num*/
    _35max_stack_per_call_16067 = _53temps_allocated_46235 + _39param_num_53678;
L48: 

    /** 	param_num = -1*/
    _39param_num_53678 = -1;

    /** 	StraightenBranches()*/
    _39StraightenBranches();

    /** 	check_inline( p )*/
    _67check_inline(_p_59540);

    /** 	param_num = -1*/
    _39param_num_53678 = -1;

    /** 	EnterTopLevel()*/
    _39EnterTopLevel(1);

    /** 	if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_59551)){
            _30195 = SEQ_PTR(_enum_syms_59551)->length;
    }
    else {
        _30195 = 1;
    }
    if (_30195 == 0)
    {
        _30195 = NOVALUE;
        goto L49; // [2633] 2720
    }
    else{
        _30195 = NOVALUE;
    }

    /** 		SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59540 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_59551)){
            _30198 = SEQ_PTR(_enum_syms_59551)->length;
    }
    else {
        _30198 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59551);
    _30199 = (int)*(((s1_ptr)_2)->base + _30198);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30199)){
        _30200 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30199)->dbl));
    }
    else{
        _30200 = (int)*(((s1_ptr)_2)->base + _30199);
    }
    _2 = (int)SEQ_PTR(_30200);
    _30201 = (int)*(((s1_ptr)_2)->base + 2);
    _30200 = NOVALUE;
    Ref(_30201);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30201;
    if( _1 != _30201 ){
        DeRef(_1);
    }
    _30201 = NOVALUE;
    _30196 = NOVALUE;

    /** 		SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_45724 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_enum_syms_59551);
    _30204 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30204);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30204;
    if( _1 != _30204 ){
        DeRef(_1);
    }
    _30204 = NOVALUE;
    _30202 = NOVALUE;

    /** 		last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_59551)){
            _30205 = SEQ_PTR(_enum_syms_59551)->length;
    }
    else {
        _30205 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59551);
    _53last_sym_45724 = (int)*(((s1_ptr)_2)->base + _30205);
    if (!IS_ATOM_INT(_53last_sym_45724)){
        _53last_sym_45724 = (long)DBL_PTR(_53last_sym_45724)->dbl;
    }

    /** 		SymTab[last_sym][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_53last_sym_45724 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30207 = NOVALUE;
L49: 

    /** end procedure*/
    DeRef(_tok_59544);
    DeRef(_prog_name_59545);
    DeRef(_seq_sym_59549);
    DeRef(_i1_sym_59550);
    DeRef(_enum_syms_59551);
    DeRef(_middle_def_args_59774);
    _30012 = NOVALUE;
    DeRef(_29990);
    _29990 = NOVALUE;
    _30060 = NOVALUE;
    _30016 = NOVALUE;
    DeRef(_30043);
    _30043 = NOVALUE;
    DeRef(_30048);
    _30048 = NOVALUE;
    DeRef(_30054);
    _30054 = NOVALUE;
    _30078 = NOVALUE;
    DeRef(_30076);
    _30076 = NOVALUE;
    _30079 = NOVALUE;
    _30082 = NOVALUE;
    _30097 = NOVALUE;
    DeRef(_30094);
    _30094 = NOVALUE;
    _30102 = NOVALUE;
    _30148 = NOVALUE;
    DeRef(_30142);
    _30142 = NOVALUE;
    _30168 = NOVALUE;
    DeRef(_30158);
    _30158 = NOVALUE;
    _30199 = NOVALUE;
    return;
    ;
}


void _39InitGlobals()
{
    int _30226 = NOVALUE;
    int _30224 = NOVALUE;
    int _30223 = NOVALUE;
    int _30222 = NOVALUE;
    int _30221 = NOVALUE;
    int _30220 = NOVALUE;
    int _30219 = NOVALUE;
    int _30217 = NOVALUE;
    int _30216 = NOVALUE;
    int _30215 = NOVALUE;
    int _30214 = NOVALUE;
    int _30212 = NOVALUE;
    int _30211 = NOVALUE;
    int _30210 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ResetTP()*/
    _61ResetTP();

    /** 	OpTypeCheck = TRUE*/
    _35OpTypeCheck_16038 = _13TRUE_437;

    /** 	OpDefines &= {*/
    _30210 = _32version_major();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30210;
    _30211 = MAKE_SEQ(_1);
    _30210 = NOVALUE;
    _30212 = EPrintf(-9999999, _30209, _30211);
    DeRefDS(_30211);
    _30211 = NOVALUE;
    _30214 = _32version_major();
    _30215 = _32version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30214;
    ((int *)_2)[2] = _30215;
    _30216 = MAKE_SEQ(_1);
    _30215 = NOVALUE;
    _30214 = NOVALUE;
    _30217 = EPrintf(-9999999, _30213, _30216);
    DeRefDS(_30216);
    _30216 = NOVALUE;
    _30219 = _32version_major();
    _30220 = _32version_minor();
    _30221 = _32version_patch();
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30219;
    *((int *)(_2+8)) = _30220;
    *((int *)(_2+12)) = _30221;
    _30222 = MAKE_SEQ(_1);
    _30221 = NOVALUE;
    _30220 = NOVALUE;
    _30219 = NOVALUE;
    _30223 = EPrintf(-9999999, _30218, _30222);
    DeRefDS(_30222);
    _30222 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30212;
    *((int *)(_2+8)) = _30217;
    *((int *)(_2+12)) = _30223;
    _30224 = MAKE_SEQ(_1);
    _30223 = NOVALUE;
    _30217 = NOVALUE;
    _30212 = NOVALUE;
    Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _30224);
    DeRefDS(_30224);
    _30224 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines()*/
    _30226 = _40GetPlatformDefines(0);
    if (IS_SEQUENCE(_35OpDefines_16041) && IS_ATOM(_30226)) {
        Ref(_30226);
        Append(&_35OpDefines_16041, _35OpDefines_16041, _30226);
    }
    else if (IS_ATOM(_35OpDefines_16041) && IS_SEQUENCE(_30226)) {
    }
    else {
        Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _30226);
    }
    DeRef(_30226);
    _30226 = NOVALUE;

    /** 	OpInline = DEFAULT_INLINE*/
    _35OpInline_16042 = 30;

    /** 	OpIndirectInclude = 1*/
    _35OpIndirectInclude_16043 = 1;

    /** end procedure*/
    return;
    ;
}


void _39not_supported_compile(int _feature_60222)
{
    int _30228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CompileErr(5, {feature, version_name})*/
    RefDS(_35version_name_15625);
    RefDS(_feature_60222);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _feature_60222;
    ((int *)_2)[2] = _35version_name_15625;
    _30228 = MAKE_SEQ(_1);
    _44CompileErr(5, _30228, 0);
    _30228 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_feature_60222);
    return;
    ;
}


void _39SetWith(int _on_off_60228)
{
    int _option_60229 = NOVALUE;
    int _idx_60230 = NOVALUE;
    int _reset_flags_60231 = NOVALUE;
    int _tok_60283 = NOVALUE;
    int _good_sofar_60331 = NOVALUE;
    int _tok_60334 = NOVALUE;
    int _warning_extra_60336 = NOVALUE;
    int _endlist_60427 = NOVALUE;
    int _tok_60571 = NOVALUE;
    int _30375 = NOVALUE;
    int _30373 = NOVALUE;
    int _30372 = NOVALUE;
    int _30371 = NOVALUE;
    int _30370 = NOVALUE;
    int _30367 = NOVALUE;
    int _30366 = NOVALUE;
    int _30365 = NOVALUE;
    int _30363 = NOVALUE;
    int _30361 = NOVALUE;
    int _30358 = NOVALUE;
    int _30356 = NOVALUE;
    int _30355 = NOVALUE;
    int _30354 = NOVALUE;
    int _30353 = NOVALUE;
    int _30352 = NOVALUE;
    int _30348 = NOVALUE;
    int _30346 = NOVALUE;
    int _30344 = NOVALUE;
    int _30340 = NOVALUE;
    int _30335 = NOVALUE;
    int _30334 = NOVALUE;
    int _30328 = NOVALUE;
    int _30327 = NOVALUE;
    int _30326 = NOVALUE;
    int _30325 = NOVALUE;
    int _30324 = NOVALUE;
    int _30323 = NOVALUE;
    int _30322 = NOVALUE;
    int _30321 = NOVALUE;
    int _30320 = NOVALUE;
    int _30319 = NOVALUE;
    int _30317 = NOVALUE;
    int _30316 = NOVALUE;
    int _30314 = NOVALUE;
    int _30313 = NOVALUE;
    int _30312 = NOVALUE;
    int _30310 = NOVALUE;
    int _30309 = NOVALUE;
    int _30307 = NOVALUE;
    int _30304 = NOVALUE;
    int _30302 = NOVALUE;
    int _30299 = NOVALUE;
    int _30298 = NOVALUE;
    int _30297 = NOVALUE;
    int _30296 = NOVALUE;
    int _30289 = NOVALUE;
    int _30288 = NOVALUE;
    int _30286 = NOVALUE;
    int _30283 = NOVALUE;
    int _30282 = NOVALUE;
    int _30280 = NOVALUE;
    int _30279 = NOVALUE;
    int _30278 = NOVALUE;
    int _30277 = NOVALUE;
    int _30276 = NOVALUE;
    int _30275 = NOVALUE;
    int _30272 = NOVALUE;
    int _30271 = NOVALUE;
    int _30270 = NOVALUE;
    int _30269 = NOVALUE;
    int _30268 = NOVALUE;
    int _30267 = NOVALUE;
    int _30264 = NOVALUE;
    int _30263 = NOVALUE;
    int _30262 = NOVALUE;
    int _30260 = NOVALUE;
    int _30257 = NOVALUE;
    int _30255 = NOVALUE;
    int _30254 = NOVALUE;
    int _30252 = NOVALUE;
    int _30251 = NOVALUE;
    int _30250 = NOVALUE;
    int _30249 = NOVALUE;
    int _30248 = NOVALUE;
    int _30247 = NOVALUE;
    int _30245 = NOVALUE;
    int _30242 = NOVALUE;
    int _30241 = NOVALUE;
    int _30240 = NOVALUE;
    int _30239 = NOVALUE;
    int _30237 = NOVALUE;
    int _30236 = NOVALUE;
    int _30235 = NOVALUE;
    int _30234 = NOVALUE;
    int _30232 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer reset_flags = 1*/
    _reset_flags_60231 = 1;

    /** 	option = StringToken("&+=")*/
    RefDS(_30229);
    _0 = _option_60229;
    _option_60229 = _61StringToken(_30229);
    DeRef(_0);

    /** 	if equal(option, "type_check") then*/
    if (_option_60229 == _30231)
    _30232 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30231))
    _30232 = 0;
    else
    _30232 = (compare(_option_60229, _30231) == 0);
    if (_30232 == 0)
    {
        _30232 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30232 = NOVALUE;
    }

    /** 		OpTypeCheck = on_off*/
    _35OpTypeCheck_16038 = _on_off_60228;
    goto L2; // [32] 1521
L1: 

    /** 	elsif equal(option, "profile") then*/
    if (_option_60229 == _30233)
    _30234 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30233))
    _30234 = 0;
    else
    _30234 = (compare(_option_60229, _30233) == 0);
    if (_30234 == 0)
    {
        _30234 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30234 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30235 = (_35TRANSLATE_15611 == 0);
    if (_30235 == 0) {
        goto L2; // [51] 1521
    }
    _30237 = (_35BIND_15614 == 0);
    if (_30237 == 0)
    {
        DeRef(_30237);
        _30237 = NOVALUE;
        goto L2; // [61] 1521
    }
    else{
        DeRef(_30237);
        _30237 = NOVALUE;
    }

    /** 			OpProfileStatement = on_off*/
    _35OpProfileStatement_16039 = _on_off_60228;

    /** 			if OpProfileStatement then*/
    if (_35OpProfileStatement_16039 == 0)
    {
        goto L2; // [75] 1521
    }
    else{
    }

    /** 				if AnyTimeProfile then*/
    if (_36AnyTimeProfile_15003 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** 					Warning(224, mixed_profile_warning_flag)*/
    RefDS(_21815);
    _44Warning(224, 1024, _21815);

    /** 					OpProfileStatement = FALSE*/
    _35OpProfileStatement_16039 = _13FALSE_435;
    goto L2; // [103] 1521
L4: 

    /** 					AnyStatementProfile = TRUE*/
    _36AnyStatementProfile_15004 = _13TRUE_437;
    goto L2; // [118] 1521
L3: 

    /** 	elsif equal(option, "profile_time") then*/
    if (_option_60229 == _30238)
    _30239 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30238))
    _30239 = 0;
    else
    _30239 = (compare(_option_60229, _30238) == 0);
    if (_30239 == 0)
    {
        _30239 = NOVALUE;
        goto L5; // [127] 361
    }
    else{
        _30239 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30240 = (_35TRANSLATE_15611 == 0);
    if (_30240 == 0) {
        goto L2; // [137] 1521
    }
    _30242 = (_35BIND_15614 == 0);
    if (_30242 == 0)
    {
        DeRef(_30242);
        _30242 = NOVALUE;
        goto L2; // [147] 1521
    }
    else{
        DeRef(_30242);
        _30242 = NOVALUE;
    }

    /** 			if not IWINDOWS then*/
    if (_40IWINDOWS_16111 != 0)
    goto L6; // [154] 169

    /** 				if on_off then*/
    if (_on_off_60228 == 0)
    {
        goto L7; // [159] 168
    }
    else{
    }

    /** 					not_supported_compile("profile_time")*/
    RefDS(_30238);
    _39not_supported_compile(_30238);
L7: 
L6: 

    /** 			OpProfileTime = on_off*/
    _35OpProfileTime_16040 = _on_off_60228;

    /** 			if OpProfileTime then*/
    if (_35OpProfileTime_16040 == 0)
    {
        goto L8; // [180] 355
    }
    else{
    }

    /** 				if AnyStatementProfile then*/
    if (_36AnyStatementProfile_15004 == 0)
    {
        goto L9; // [187] 209
    }
    else{
    }

    /** 					Warning(224,mixed_profile_warning_flag)*/
    RefDS(_21815);
    _44Warning(224, 1024, _21815);

    /** 					OpProfileTime = FALSE*/
    _35OpProfileTime_16040 = _13FALSE_435;
L9: 

    /** 				token tok = next_token()*/
    _0 = _tok_60283;
    _tok_60283 = _39next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60283);
    _30245 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30245, 502)){
        _30245 = NOVALUE;
        goto LA; // [224] 316
    }
    _30245 = NOVALUE;

    /** 					if integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tok_60283);
    _30247 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30247)){
        _30248 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30247)->dbl));
    }
    else{
        _30248 = (int)*(((s1_ptr)_2)->base + _30247);
    }
    _2 = (int)SEQ_PTR(_30248);
    _30249 = (int)*(((s1_ptr)_2)->base + 1);
    _30248 = NOVALUE;
    if (IS_ATOM_INT(_30249))
    _30250 = 1;
    else if (IS_ATOM_DBL(_30249))
    _30250 = IS_ATOM_INT(DoubleToInt(_30249));
    else
    _30250 = 0;
    _30249 = NOVALUE;
    if (_30250 == 0)
    {
        _30250 = NOVALUE;
        goto LB; // [251] 279
    }
    else{
        _30250 = NOVALUE;
    }

    /** 						sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60283);
    _30251 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30251)){
        _30252 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30251)->dbl));
    }
    else{
        _30252 = (int)*(((s1_ptr)_2)->base + _30251);
    }
    _2 = (int)SEQ_PTR(_30252);
    _35sample_size_16068 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_35sample_size_16068)){
        _35sample_size_16068 = (long)DBL_PTR(_35sample_size_16068)->dbl;
    }
    _30252 = NOVALUE;
    goto LC; // [276] 287
LB: 

    /** 						sample_size = -1*/
    _35sample_size_16068 = -1;
LC: 

    /** 					if sample_size < 1 and OpProfileTime then*/
    _30254 = (_35sample_size_16068 < 1);
    if (_30254 == 0) {
        goto LD; // [295] 329
    }
    if (_35OpProfileTime_16040 == 0)
    {
        goto LD; // [302] 329
    }
    else{
    }

    /** 						CompileErr(136)*/
    RefDS(_21815);
    _44CompileErr(136, _21815, 0);
    goto LD; // [313] 329
LA: 

    /** 					putback(tok)*/
    Ref(_tok_60283);
    _39putback(_tok_60283);

    /** 					sample_size = DEFAULT_SAMPLE_SIZE*/
    _35sample_size_16068 = 25000;
LD: 

    /** 				if OpProfileTime then*/
    if (_35OpProfileTime_16040 == 0)
    {
        goto LE; // [333] 354
    }
    else{
    }

    /** 					if IWINDOWS then*/
    if (_40IWINDOWS_16111 == 0)
    {
        goto LF; // [340] 353
    }
    else{
    }

    /** 						AnyTimeProfile = TRUE*/
    _36AnyTimeProfile_15003 = _13TRUE_437;
LF: 
LE: 
L8: 
    DeRef(_tok_60283);
    _tok_60283 = NOVALUE;
    goto L2; // [358] 1521
L5: 

    /** 	elsif equal(option, "trace") then*/
    if (_option_60229 == _30256)
    _30257 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30256))
    _30257 = 0;
    else
    _30257 = (compare(_option_60229, _30256) == 0);
    if (_30257 == 0)
    {
        _30257 = NOVALUE;
        goto L10; // [367] 388
    }
    else{
        _30257 = NOVALUE;
    }

    /** 		if not BIND then*/
    if (_35BIND_15614 != 0)
    goto L2; // [374] 1521

    /** 			OpTrace = on_off*/
    _35OpTrace_16037 = _on_off_60228;
    goto L2; // [385] 1521
L10: 

    /** 	elsif equal(option, "warning") then*/
    if (_option_60229 == _30259)
    _30260 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30259))
    _30260 = 0;
    else
    _30260 = (compare(_option_60229, _30259) == 0);
    if (_30260 == 0)
    {
        _30260 = NOVALUE;
        goto L11; // [394] 1234
    }
    else{
        _30260 = NOVALUE;
    }

    /** 		integer good_sofar = line_number*/
    _good_sofar_60331 = _35line_number_15969;

    /** 		reset_flags = 1*/
    _reset_flags_60231 = 1;

    /** 		token tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 		integer warning_extra = 1*/
    _warning_extra_60336 = 1;

    /** 		if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30262 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 515;
    _30263 = MAKE_SEQ(_1);
    _30264 = find_from(_30262, _30263, 1);
    _30262 = NOVALUE;
    DeRefDS(_30263);
    _30263 = NOVALUE;
    if (_30264 == 0)
    goto L12; // [442] 501

    /** 			tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30267 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30267)) {
        _30268 = (_30267 != -24);
    }
    else {
        _30268 = binary_op(NOTEQ, _30267, -24);
    }
    _30267 = NOVALUE;
    if (IS_ATOM_INT(_30268)) {
        if (_30268 == 0) {
            goto L13; // [465] 493
        }
    }
    else {
        if (DBL_PTR(_30268)->dbl == 0.0) {
            goto L13; // [465] 493
        }
    }
    _2 = (int)SEQ_PTR(_tok_60334);
    _30270 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30270)) {
        _30271 = (_30270 != -26);
    }
    else {
        _30271 = binary_op(NOTEQ, _30270, -26);
    }
    _30270 = NOVALUE;
    if (_30271 == 0) {
        DeRef(_30271);
        _30271 = NOVALUE;
        goto L13; // [482] 493
    }
    else {
        if (!IS_ATOM_INT(_30271) && DBL_PTR(_30271)->dbl == 0.0){
            DeRef(_30271);
            _30271 = NOVALUE;
            goto L13; // [482] 493
        }
        DeRef(_30271);
        _30271 = NOVALUE;
    }
    DeRef(_30271);
    _30271 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_21815);
    _44CompileErr(160, _21815, 0);
L13: 

    /** 			reset_flags = 0*/
    _reset_flags_60231 = 0;
    goto L14; // [498] 727
L12: 

    /** 		elsif tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30272 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30272, 3)){
        _30272 = NOVALUE;
        goto L15; // [511] 570
    }
    _30272 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30275 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30275)) {
        _30276 = (_30275 != -24);
    }
    else {
        _30276 = binary_op(NOTEQ, _30275, -24);
    }
    _30275 = NOVALUE;
    if (IS_ATOM_INT(_30276)) {
        if (_30276 == 0) {
            goto L16; // [534] 562
        }
    }
    else {
        if (DBL_PTR(_30276)->dbl == 0.0) {
            goto L16; // [534] 562
        }
    }
    _2 = (int)SEQ_PTR(_tok_60334);
    _30278 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30278)) {
        _30279 = (_30278 != -26);
    }
    else {
        _30279 = binary_op(NOTEQ, _30278, -26);
    }
    _30278 = NOVALUE;
    if (_30279 == 0) {
        DeRef(_30279);
        _30279 = NOVALUE;
        goto L16; // [551] 562
    }
    else {
        if (!IS_ATOM_INT(_30279) && DBL_PTR(_30279)->dbl == 0.0){
            DeRef(_30279);
            _30279 = NOVALUE;
            goto L16; // [551] 562
        }
        DeRef(_30279);
        _30279 = NOVALUE;
    }
    DeRef(_30279);
    _30279 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_21815);
    _44CompileErr(160, _21815, 0);
L16: 

    /** 			reset_flags = 1*/
    _reset_flags_60231 = 1;
    goto L14; // [567] 727
L15: 

    /** 		elsif tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30280 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30280, -100)){
        _30280 = NOVALUE;
        goto L17; // [580] 726
    }
    _30280 = NOVALUE;

    /** 			option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30282 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30282)){
        _30283 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30282)->dbl));
    }
    else{
        _30283 = (int)*(((s1_ptr)_2)->base + _30282);
    }
    DeRef(_option_60229);
    _2 = (int)SEQ_PTR(_30283);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _option_60229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _option_60229 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_option_60229);
    _30283 = NOVALUE;

    /** 			if equal(option, "save") then*/
    if (_option_60229 == _30285)
    _30286 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30285))
    _30286 = 0;
    else
    _30286 = (compare(_option_60229, _30285) == 0);
    if (_30286 == 0)
    {
        _30286 = NOVALUE;
        goto L18; // [612] 636
    }
    else{
        _30286 = NOVALUE;
    }

    /** 				prev_OpWarning = OpWarning*/
    _35prev_OpWarning_16036 = _35OpWarning_16035;

    /** 				warning_extra = FALSE*/
    _warning_extra_60336 = _13FALSE_435;
    goto L19; // [633] 725
L18: 

    /** 			elsif equal(option, "restore") then*/
    if (_option_60229 == _30287)
    _30288 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30287))
    _30288 = 0;
    else
    _30288 = (compare(_option_60229, _30287) == 0);
    if (_30288 == 0)
    {
        _30288 = NOVALUE;
        goto L1A; // [642] 666
    }
    else{
        _30288 = NOVALUE;
    }

    /** 				OpWarning = prev_OpWarning*/
    _35OpWarning_16035 = _35prev_OpWarning_16036;

    /** 				warning_extra = FALSE*/
    _warning_extra_60336 = _13FALSE_435;
    goto L19; // [663] 725
L1A: 

    /** 			elsif equal(option, "strict") then*/
    if (_option_60229 == _25334)
    _30289 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_25334))
    _30289 = 0;
    else
    _30289 = (compare(_option_60229, _25334) == 0);
    if (_30289 == 0)
    {
        _30289 = NOVALUE;
        goto L1B; // [672] 724
    }
    else{
        _30289 = NOVALUE;
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60228 != 0)
    goto L1C; // [677] 694

    /** 					Strict_Override += 1*/
    _35Strict_Override_16034 = _35Strict_Override_16034 + 1;
    goto L1D; // [691] 714
L1C: 

    /** 				elsif Strict_Override > 0 then*/
    if (_35Strict_Override_16034 <= 0)
    goto L1E; // [698] 713

    /** 					Strict_Override -= 1*/
    _35Strict_Override_16034 = _35Strict_Override_16034 - 1;
L1E: 
L1D: 

    /** 				warning_extra = FALSE*/
    _warning_extra_60336 = _13FALSE_435;
L1B: 
L19: 
L17: 
L14: 

    /** 		if warning_extra = TRUE then*/
    if (_warning_extra_60336 != _13TRUE_437)
    goto L1F; // [731] 1229

    /** 			if reset_flags then*/
    if (_reset_flags_60231 == 0)
    {
        goto L20; // [737] 769
    }
    else{
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60228 != 0)
    goto L21; // [742] 758

    /** 					OpWarning = no_warning_flag*/
    _35OpWarning_16035 = 0;
    goto L22; // [755] 768
L21: 

    /** 					OpWarning = all_warning_flag*/
    _35OpWarning_16035 = 32767;
L22: 
L20: 

    /** 			if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30296 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -24;
    ((int *)_2)[2] = -26;
    _30297 = MAKE_SEQ(_1);
    _30298 = find_from(_30296, _30297, 1);
    _30296 = NOVALUE;
    DeRefDS(_30297);
    _30297 = NOVALUE;
    if (_30298 == 0)
    {
        _30298 = NOVALUE;
        goto L23; // [790] 1222
    }
    else{
        _30298 = NOVALUE;
    }

    /** 				integer endlist*/

    /** 				if tok[T_ID] = LEFT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30299 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30299, -24)){
        _30299 = NOVALUE;
        goto L24; // [805] 821
    }
    _30299 = NOVALUE;

    /** 					endlist = RIGHT_BRACE*/
    _endlist_60427 = -25;
    goto L25; // [818] 831
L24: 

    /** 					endlist = RIGHT_ROUND*/
    _endlist_60427 = -27;
L25: 

    /** 				tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 				while tok[T_ID] != endlist do*/
L26: 
    _2 = (int)SEQ_PTR(_tok_60334);
    _30302 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30302, _endlist_60427)){
        _30302 = NOVALUE;
        goto L27; // [849] 1217
    }
    _30302 = NOVALUE;

    /** 					if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30304 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30304, -30)){
        _30304 = NOVALUE;
        goto L28; // [863] 877
    }
    _30304 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [874] 841
L28: 

    /** 					if tok[T_ID] = STRING then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30307 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30307, 503)){
        _30307 = NOVALUE;
        goto L29; // [887] 916
    }
    _30307 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30309 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30309)){
        _30310 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30309)->dbl));
    }
    else{
        _30310 = (int)*(((s1_ptr)_2)->base + _30309);
    }
    DeRef(_option_60229);
    _2 = (int)SEQ_PTR(_30310);
    _option_60229 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_option_60229);
    _30310 = NOVALUE;
    goto L2A; // [913] 1064
L29: 

    /** 					elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30312 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30312)){
        _30313 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30312)->dbl));
    }
    else{
        _30313 = (int)*(((s1_ptr)_2)->base + _30312);
    }
    if (IS_SEQUENCE(_30313)){
            _30314 = SEQ_PTR(_30313)->length;
    }
    else {
        _30314 = 1;
    }
    _30313 = NOVALUE;
    if (binary_op_a(LESS, _30314, _35S_NAME_15641)){
        _30314 = NOVALUE;
        goto L2B; // [935] 964
    }
    _30314 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60334);
    _30316 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30316)){
        _30317 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30316)->dbl));
    }
    else{
        _30317 = (int)*(((s1_ptr)_2)->base + _30316);
    }
    DeRef(_option_60229);
    _2 = (int)SEQ_PTR(_30317);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _option_60229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _option_60229 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_option_60229);
    _30317 = NOVALUE;
    goto L2A; // [961] 1064
L2B: 

    /** 						option = ""*/
    RefDS(_21815);
    DeRef(_option_60229);
    _option_60229 = _21815;

    /** 						for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_63keylist_22479)){
            _30319 = SEQ_PTR(_63keylist_22479)->length;
    }
    else {
        _30319 = 1;
    }
    {
        int _k_60474;
        _k_60474 = 1;
L2C: 
        if (_k_60474 > _30319){
            goto L2D; // [978] 1063
        }

        /** 							if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _30320 = (int)*(((s1_ptr)_2)->base + _k_60474);
        _2 = (int)SEQ_PTR(_30320);
        _30321 = (int)*(((s1_ptr)_2)->base + 4);
        _30320 = NOVALUE;
        if (IS_ATOM_INT(_30321)) {
            _30322 = (_30321 == 8);
        }
        else {
            _30322 = binary_op(EQUALS, _30321, 8);
        }
        _30321 = NOVALUE;
        if (IS_ATOM_INT(_30322)) {
            if (_30322 == 0) {
                goto L2E; // [1005] 1056
            }
        }
        else {
            if (DBL_PTR(_30322)->dbl == 0.0) {
                goto L2E; // [1005] 1056
            }
        }
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _30324 = (int)*(((s1_ptr)_2)->base + _k_60474);
        _2 = (int)SEQ_PTR(_30324);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _30325 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _30325 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _30324 = NOVALUE;
        _2 = (int)SEQ_PTR(_tok_60334);
        _30326 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30325) && IS_ATOM_INT(_30326)) {
            _30327 = (_30325 == _30326);
        }
        else {
            _30327 = binary_op(EQUALS, _30325, _30326);
        }
        _30325 = NOVALUE;
        _30326 = NOVALUE;
        if (_30327 == 0) {
            DeRef(_30327);
            _30327 = NOVALUE;
            goto L2E; // [1032] 1056
        }
        else {
            if (!IS_ATOM_INT(_30327) && DBL_PTR(_30327)->dbl == 0.0){
                DeRef(_30327);
                _30327 = NOVALUE;
                goto L2E; // [1032] 1056
            }
            DeRef(_30327);
            _30327 = NOVALUE;
        }
        DeRef(_30327);
        _30327 = NOVALUE;

        /** 									option = keylist[k][S_NAME]*/
        _2 = (int)SEQ_PTR(_63keylist_22479);
        _30328 = (int)*(((s1_ptr)_2)->base + _k_60474);
        DeRef(_option_60229);
        _2 = (int)SEQ_PTR(_30328);
        if (!IS_ATOM_INT(_35S_NAME_15641)){
            _option_60229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
        }
        else{
            _option_60229 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
        }
        Ref(_option_60229);
        _30328 = NOVALUE;

        /** 									exit*/
        goto L2D; // [1053] 1063
L2E: 

        /** 						end for*/
        _k_60474 = _k_60474 + 1;
        goto L2C; // [1058] 985
L2D: 
        ;
    }
L2A: 

    /** 					idx = find(option, warning_names)*/
    _idx_60230 = find_from(_option_60229, _35warning_names_16012, 1);

    /** 					if idx = 0 then*/
    if (_idx_60230 != 0)
    goto L2F; // [1075] 1128

    /** 	 					if good_sofar != line_number then*/
    if (_good_sofar_60331 == _35line_number_15969)
    goto L30; // [1083] 1095

    /**  							CompileErr(147)*/
    RefDS(_21815);
    _44CompileErr(147, _21815, 0);
L30: 

    /** 						Warning(225, 0,*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _30334 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30334);
    *((int *)(_2+4)) = _30334;
    *((int *)(_2+8)) = _35line_number_15969;
    RefDS(_option_60229);
    *((int *)(_2+12)) = _option_60229;
    _30335 = MAKE_SEQ(_1);
    _30334 = NOVALUE;
    _44Warning(225, 0, _30335);
    _30335 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 						continue*/
    goto L26; // [1125] 841
L2F: 

    /** 					idx = warning_flags[idx]*/
    _2 = (int)SEQ_PTR(_35warning_flags_16010);
    _idx_60230 = (int)*(((s1_ptr)_2)->base + _idx_60230);

    /** 					if idx = 0 then*/
    if (_idx_60230 != 0)
    goto L31; // [1140] 1174

    /** 						if on_off then*/
    if (_on_off_60228 == 0)
    {
        goto L32; // [1146] 1161
    }
    else{
    }

    /** 							OpWarning = no_warning_flag*/
    _35OpWarning_16035 = 0;
    goto L33; // [1158] 1207
L32: 

    /** 						    OpWarning = all_warning_flag*/
    _35OpWarning_16035 = 32767;
    goto L33; // [1171] 1207
L31: 

    /** 						if on_off then*/
    if (_on_off_60228 == 0)
    {
        goto L34; // [1176] 1192
    }
    else{
    }

    /** 							OpWarning = or_bits(OpWarning, idx)*/
    {unsigned long tu;
         tu = (unsigned long)_35OpWarning_16035 | (unsigned long)_idx_60230;
         _35OpWarning_16035 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_35OpWarning_16035)) {
        _1 = (long)(DBL_PTR(_35OpWarning_16035)->dbl);
        DeRefDS(_35OpWarning_16035);
        _35OpWarning_16035 = _1;
    }
    goto L35; // [1189] 1206
L34: 

    /** 						    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30340 = not_bits(_idx_60230);
    if (IS_ATOM_INT(_30340)) {
        {unsigned long tu;
             tu = (unsigned long)_35OpWarning_16035 & (unsigned long)_30340;
             _35OpWarning_16035 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_35OpWarning_16035;
        _35OpWarning_16035 = Dand_bits(&temp_d, DBL_PTR(_30340));
    }
    DeRef(_30340);
    _30340 = NOVALUE;
    if (!IS_ATOM_INT(_35OpWarning_16035)) {
        _1 = (long)(DBL_PTR(_35OpWarning_16035)->dbl);
        DeRefDS(_35OpWarning_16035);
        _35OpWarning_16035 = _1;
    }
L35: 
L33: 

    /** 					tok = next_token()*/
    _0 = _tok_60334;
    _tok_60334 = _39next_token();
    DeRef(_0);

    /** 				end while*/
    goto L26; // [1214] 841
L27: 
    goto L36; // [1219] 1228
L23: 

    /** 				putback(tok)*/
    Ref(_tok_60334);
    _39putback(_tok_60334);
L36: 
L1F: 
    DeRef(_tok_60334);
    _tok_60334 = NOVALUE;
    goto L2; // [1231] 1521
L11: 

    /** 	elsif equal(option, "define") then*/
    if (_option_60229 == _30343)
    _30344 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30343))
    _30344 = 0;
    else
    _30344 = (compare(_option_60229, _30343) == 0);
    if (_30344 == 0)
    {
        _30344 = NOVALUE;
        goto L37; // [1240] 1363
    }
    else{
        _30344 = NOVALUE;
    }

    /** 		option = StringToken()*/
    RefDS(_5);
    _0 = _option_60229;
    _option_60229 = _61StringToken(_5);
    DeRefDS(_0);

    /** 		if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_60229)){
            _30346 = SEQ_PTR(_option_60229)->length;
    }
    else {
        _30346 = 1;
    }
    if (_30346 != 0)
    goto L38; // [1256] 1270

    /** 			CompileErr(81)*/
    RefDS(_21815);
    _44CompileErr(81, _21815, 0);
    goto L39; // [1267] 1288
L38: 

    /** 		elsif not t_identifier(option) then*/
    RefDS(_option_60229);
    _30348 = _13t_identifier(_option_60229);
    if (IS_ATOM_INT(_30348)) {
        if (_30348 != 0){
            DeRef(_30348);
            _30348 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    else {
        if (DBL_PTR(_30348)->dbl != 0.0){
            DeRef(_30348);
            _30348 = NOVALUE;
            goto L3A; // [1276] 1287
        }
    }
    DeRef(_30348);
    _30348 = NOVALUE;

    /** 			CompileErr(61)*/
    RefDS(_21815);
    _44CompileErr(61, _21815, 0);
L3A: 
L39: 

    /** 		if on_off = 0 then*/
    if (_on_off_60228 != 0)
    goto L3B; // [1290] 1345

    /** 			idx = find(option, OpDefines)*/
    _idx_60230 = find_from(_option_60229, _35OpDefines_16041, 1);

    /** 			if idx then*/
    if (_idx_60230 == 0)
    {
        goto L2; // [1305] 1521
    }
    else{
    }

    /** 				OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30352 = _idx_60230 - 1;
    rhs_slice_target = (object_ptr)&_30353;
    RHS_Slice(_35OpDefines_16041, 1, _30352);
    _30354 = _idx_60230 + 1;
    if (IS_SEQUENCE(_35OpDefines_16041)){
            _30355 = SEQ_PTR(_35OpDefines_16041)->length;
    }
    else {
        _30355 = 1;
    }
    rhs_slice_target = (object_ptr)&_30356;
    RHS_Slice(_35OpDefines_16041, _30354, _30355);
    Concat((object_ptr)&_35OpDefines_16041, _30353, _30356);
    DeRefDS(_30353);
    _30353 = NOVALUE;
    DeRef(_30353);
    _30353 = NOVALUE;
    DeRefDS(_30356);
    _30356 = NOVALUE;
    goto L2; // [1342] 1521
L3B: 

    /** 			OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60229);
    *((int *)(_2+4)) = _option_60229;
    _30358 = MAKE_SEQ(_1);
    Concat((object_ptr)&_35OpDefines_16041, _35OpDefines_16041, _30358);
    DeRefDS(_30358);
    _30358 = NOVALUE;
    goto L2; // [1360] 1521
L37: 

    /** 	elsif equal(option, "inline") then*/
    if (_option_60229 == _30360)
    _30361 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30360))
    _30361 = 0;
    else
    _30361 = (compare(_option_60229, _30360) == 0);
    if (_30361 == 0)
    {
        _30361 = NOVALUE;
        goto L3C; // [1369] 1455
    }
    else{
        _30361 = NOVALUE;
    }

    /** 		if on_off then*/
    if (_on_off_60228 == 0)
    {
        goto L3D; // [1374] 1444
    }
    else{
    }

    /** 			token tok = next_token()*/
    _0 = _tok_60571;
    _tok_60571 = _39next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60571);
    _30363 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30363, 502)){
        _30363 = NOVALUE;
        goto L3E; // [1392] 1424
    }
    _30363 = NOVALUE;

    /** 				OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_60571);
    _30365 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30365)){
        _30366 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30365)->dbl));
    }
    else{
        _30366 = (int)*(((s1_ptr)_2)->base + _30365);
    }
    _2 = (int)SEQ_PTR(_30366);
    _30367 = (int)*(((s1_ptr)_2)->base + 1);
    _30366 = NOVALUE;
    if (IS_ATOM_INT(_30367))
    _35OpInline_16042 = e_floor(_30367);
    else
    _35OpInline_16042 = unary_op(FLOOR, _30367);
    _30367 = NOVALUE;
    if (!IS_ATOM_INT(_35OpInline_16042)) {
        _1 = (long)(DBL_PTR(_35OpInline_16042)->dbl);
        DeRefDS(_35OpInline_16042);
        _35OpInline_16042 = _1;
    }
    goto L3F; // [1421] 1439
L3E: 

    /** 				putback(tok)*/
    Ref(_tok_60571);
    _39putback(_tok_60571);

    /** 				OpInline = DEFAULT_INLINE*/
    _35OpInline_16042 = 30;
L3F: 
    DeRef(_tok_60571);
    _tok_60571 = NOVALUE;
    goto L2; // [1441] 1521
L3D: 

    /** 			OpInline = 0*/
    _35OpInline_16042 = 0;
    goto L2; // [1452] 1521
L3C: 

    /** 	elsif equal( option, "indirect_includes" ) then*/
    if (_option_60229 == _30369)
    _30370 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_30369))
    _30370 = 0;
    else
    _30370 = (compare(_option_60229, _30369) == 0);
    if (_30370 == 0)
    {
        _30370 = NOVALUE;
        goto L40; // [1461] 1474
    }
    else{
        _30370 = NOVALUE;
    }

    /** 		OpIndirectInclude = on_off*/
    _35OpIndirectInclude_16043 = _on_off_60228;
    goto L2; // [1471] 1521
L40: 

    /** 	elsif equal(option, "batch") then*/
    if (_option_60229 == _25331)
    _30371 = 1;
    else if (IS_ATOM_INT(_option_60229) && IS_ATOM_INT(_25331))
    _30371 = 0;
    else
    _30371 = (compare(_option_60229, _25331) == 0);
    if (_30371 == 0)
    {
        _30371 = NOVALUE;
        goto L41; // [1480] 1493
    }
    else{
        _30371 = NOVALUE;
    }

    /** 		batch_job = on_off*/
    _35batch_job_15981 = _on_off_60228;
    goto L2; // [1490] 1521
L41: 

    /** 	elsif integer(to_number(option, -1)) then*/
    RefDS(_option_60229);
    _30372 = _15to_number(_option_60229, -1);
    if (IS_ATOM_INT(_30372))
    _30373 = 1;
    else if (IS_ATOM_DBL(_30372))
    _30373 = IS_ATOM_INT(DoubleToInt(_30372));
    else
    _30373 = 0;
    DeRef(_30372);
    _30372 = NOVALUE;
    if (_30373 == 0)
    {
        _30373 = NOVALUE;
        goto L42; // [1503] 1509
    }
    else{
        _30373 = NOVALUE;
    }
    goto L2; // [1506] 1521
L42: 

    /** 		CompileErr(154, {option})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60229);
    *((int *)(_2+4)) = _option_60229;
    _30375 = MAKE_SEQ(_1);
    _44CompileErr(154, _30375, 0);
    _30375 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_option_60229);
    DeRef(_30235);
    _30235 = NOVALUE;
    DeRef(_30240);
    _30240 = NOVALUE;
    _30247 = NOVALUE;
    _30251 = NOVALUE;
    DeRef(_30254);
    _30254 = NOVALUE;
    _30282 = NOVALUE;
    DeRef(_30268);
    _30268 = NOVALUE;
    DeRef(_30276);
    _30276 = NOVALUE;
    _30309 = NOVALUE;
    _30312 = NOVALUE;
    _30313 = NOVALUE;
    _30316 = NOVALUE;
    DeRef(_30352);
    _30352 = NOVALUE;
    DeRef(_30322);
    _30322 = NOVALUE;
    _30365 = NOVALUE;
    DeRef(_30354);
    _30354 = NOVALUE;
    return;
    ;
}


void _39ExecCommand()
{
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** 		emit_op(RETURNT)*/
    _41emit_op(34);
L1: 

    /** 	StraightenBranches()  -- straighten top-level*/
    _39StraightenBranches();

    /** end procedure*/
    return;
    ;
}


int _39undefined_var(int _tok_60615, int _scope_60616)
{
    int _forward_60618 = NOVALUE;
    int _30381 = NOVALUE;
    int _30380 = NOVALUE;
    int _30377 = NOVALUE;
    int _0, _1, _2;
    

    /** 	token forward = next_token()*/
    _0 = _forward_60618;
    _forward_60618 = _39next_token();
    DeRef(_0);

    /** 		switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_60618);
    _30377 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30377) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30377)){
        if( (DBL_PTR(_30377)->dbl != (double) ((int) DBL_PTR(_30377)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (int) DBL_PTR(_30377)->dbl;
    }
    else {
        _0 = _30377;
    };
    _30377 = NOVALUE;
    switch ( _0 ){ 

        /** 			case LEFT_ROUND then*/
        case -26:

        /** 				StartSourceLine( TRUE )*/
        _41StartSourceLine(_13TRUE_437, 0, 2);

        /** 				Forward_call( tok )*/
        Ref(_tok_60615);
        _39Forward_call(_tok_60615, 195);

        /** 				return 1*/
        DeRef(_tok_60615);
        DeRef(_forward_60618);
        return 1;
        goto L2; // [48] 96

        /** 			case VARIABLE then*/
        case -100:

        /** 				putback( forward )*/
        Ref(_forward_60618);
        _39putback(_forward_60618);

        /** 				Global_declaration( tok[T_SYM], scope )*/
        _2 = (int)SEQ_PTR(_tok_60615);
        _30380 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30380);
        _30381 = _39Global_declaration(_30380, _scope_60616);
        _30380 = NOVALUE;

        /** 				return 1*/
        DeRef(_tok_60615);
        DeRef(_forward_60618);
        DeRef(_30381);
        _30381 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** 			case else*/
        default:
L1: 

        /** 				putback( forward )*/
        Ref(_forward_60618);
        _39putback(_forward_60618);

        /** 				return 0*/
        DeRef(_tok_60615);
        DeRef(_forward_60618);
        DeRef(_30381);
        _30381 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _39real_parser(int _nested_60637)
{
    int _tok_60639 = NOVALUE;
    int _id_60640 = NOVALUE;
    int _scope_60641 = NOVALUE;
    int _test_60782 = NOVALUE;
    int _30514 = NOVALUE;
    int _30512 = NOVALUE;
    int _30511 = NOVALUE;
    int _30510 = NOVALUE;
    int _30509 = NOVALUE;
    int _30508 = NOVALUE;
    int _30507 = NOVALUE;
    int _30506 = NOVALUE;
    int _30501 = NOVALUE;
    int _30500 = NOVALUE;
    int _30497 = NOVALUE;
    int _30495 = NOVALUE;
    int _30494 = NOVALUE;
    int _30491 = NOVALUE;
    int _30478 = NOVALUE;
    int _30471 = NOVALUE;
    int _30470 = NOVALUE;
    int _30468 = NOVALUE;
    int _30466 = NOVALUE;
    int _30465 = NOVALUE;
    int _30463 = NOVALUE;
    int _30461 = NOVALUE;
    int _30456 = NOVALUE;
    int _30454 = NOVALUE;
    int _30452 = NOVALUE;
    int _30451 = NOVALUE;
    int _30450 = NOVALUE;
    int _30448 = NOVALUE;
    int _30446 = NOVALUE;
    int _30444 = NOVALUE;
    int _30442 = NOVALUE;
    int _30441 = NOVALUE;
    int _30440 = NOVALUE;
    int _30439 = NOVALUE;
    int _30438 = NOVALUE;
    int _30437 = NOVALUE;
    int _30436 = NOVALUE;
    int _30435 = NOVALUE;
    int _30434 = NOVALUE;
    int _30433 = NOVALUE;
    int _30432 = NOVALUE;
    int _30431 = NOVALUE;
    int _30430 = NOVALUE;
    int _30429 = NOVALUE;
    int _30427 = NOVALUE;
    int _30426 = NOVALUE;
    int _30425 = NOVALUE;
    int _30424 = NOVALUE;
    int _30422 = NOVALUE;
    int _30420 = NOVALUE;
    int _30419 = NOVALUE;
    int _30418 = NOVALUE;
    int _30416 = NOVALUE;
    int _30409 = NOVALUE;
    int _30407 = NOVALUE;
    int _30406 = NOVALUE;
    int _30405 = NOVALUE;
    int _30404 = NOVALUE;
    int _30403 = NOVALUE;
    int _30402 = NOVALUE;
    int _30401 = NOVALUE;
    int _30399 = NOVALUE;
    int _30398 = NOVALUE;
    int _30397 = NOVALUE;
    int _30396 = NOVALUE;
    int _30395 = NOVALUE;
    int _30394 = NOVALUE;
    int _30393 = NOVALUE;
    int _30392 = NOVALUE;
    int _30391 = NOVALUE;
    int _30390 = NOVALUE;
    int _30388 = NOVALUE;
    int _30384 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_nested_60637)) {
        _1 = (long)(DBL_PTR(_nested_60637)->dbl);
        DeRefDS(_nested_60637);
        _nested_60637 = _1;
    }

    /** 	integer id*/

    /** 	integer scope*/

    /** 	while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_13TRUE_437 == 0)
    {
        goto L2; // [14] 1811
    }
    else{
    }

    /** 		if OpInline = 25000 then*/
    if (_35OpInline_16042 != 25000)
    goto L3; // [21] 35

    /** 			CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30383);
    _44CompileErr(_30383, _35OpInline_16042, 0);
L3: 

    /** 		start_index = length(Code)+1*/
    if (IS_SEQUENCE(_35Code_16056)){
            _30384 = SEQ_PTR(_35Code_16056)->length;
    }
    else {
        _30384 = 1;
    }
    _39start_index_53675 = _30384 + 1;
    _30384 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_60639;
    _tok_60639 = _39next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _id_60640 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_60640)){
        _id_60640 = (long)DBL_PTR(_id_60640)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30388 = (_id_60640 == -100);
    if (_30388 != 0) {
        goto L4; // [69] 84
    }
    _30390 = (_id_60640 == 512);
    if (_30390 == 0)
    {
        DeRef(_30390);
        _30390 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30390);
        _30390 = NOVALUE;
    }
L4: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30391 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30391)){
        _30392 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30391)->dbl));
    }
    else{
        _30392 = (int)*(((s1_ptr)_2)->base + _30391);
    }
    _2 = (int)SEQ_PTR(_30392);
    _30393 = (int)*(((s1_ptr)_2)->base + 4);
    _30392 = NOVALUE;
    if (IS_ATOM_INT(_30393)) {
        _30394 = (_30393 == 9);
    }
    else {
        _30394 = binary_op(EQUALS, _30393, 9);
    }
    _30393 = NOVALUE;
    if (IS_ATOM_INT(_30394)) {
        if (_30394 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30394)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_60639);
    _30396 = _39undefined_var(_tok_60639, 5);
    if (_30396 == 0) {
        DeRef(_30396);
        _30396 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30396) && DBL_PTR(_30396)->dbl == 0.0){
            DeRef(_30396);
            _30396 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30396);
        _30396 = NOVALUE;
    }
    DeRef(_30396);
    _30396 = NOVALUE;

    /** 				continue*/
    goto L1; // [127] 12
L6: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_60639);
    _39Assignment(_tok_60639);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [148] 1801
L5: 

    /** 		elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30397 = (_id_60640 == 405);
    if (_30397 != 0) {
        _30398 = 1;
        goto L8; // [159] 173
    }
    _30399 = (_id_60640 == 406);
    _30398 = (_30399 != 0);
L8: 
    if (_30398 != 0) {
        goto L9; // [173] 188
    }
    _30401 = (_id_60640 == 416);
    if (_30401 == 0)
    {
        DeRef(_30401);
        _30401 = NOVALUE;
        goto LA; // [184] 205
    }
    else{
        DeRef(_30401);
        _30401 = NOVALUE;
    }
L9: 

    /** 			SubProg(tok[T_ID], SC_LOCAL)*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30402 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30402);
    _39SubProg(_30402, 5);
    _30402 = NOVALUE;
    goto L7; // [202] 1801
LA: 

    /** 		elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC then*/
    _30403 = (_id_60640 == 412);
    if (_30403 != 0) {
        _30404 = 1;
        goto LB; // [213] 227
    }
    _30405 = (_id_60640 == 428);
    _30404 = (_30405 != 0);
LB: 
    if (_30404 != 0) {
        _30406 = 1;
        goto LC; // [227] 241
    }
    _30407 = (_id_60640 == 429);
    _30406 = (_30407 != 0);
LC: 
    if (_30406 != 0) {
        goto LD; // [241] 256
    }
    _30409 = (_id_60640 == 430);
    if (_30409 == 0)
    {
        DeRef(_30409);
        _30409 = NOVALUE;
        goto LE; // [252] 626
    }
    else{
        DeRef(_30409);
        _30409 = NOVALUE;
    }
LD: 

    /** 			if id = GLOBAL then*/
    if (_id_60640 != 412)
    goto LF; // [260] 276

    /** 			    scope = SC_GLOBAL*/
    _scope_60641 = 6;
    goto L10; // [273] 335
LF: 

    /** 			elsif id = EXPORT then*/
    if (_id_60640 != 428)
    goto L11; // [280] 296

    /** 				scope = SC_EXPORT*/
    _scope_60641 = 11;
    goto L10; // [293] 335
L11: 

    /** 			elsif id = OVERRIDE then*/
    if (_id_60640 != 429)
    goto L12; // [300] 316

    /** 				scope = SC_OVERRIDE*/
    _scope_60641 = 12;
    goto L10; // [313] 335
L12: 

    /** 			elsif id = PUBLIC then*/
    if (_id_60640 != 430)
    goto L13; // [320] 334

    /** 				scope = SC_PUBLIC*/
    _scope_60641 = 13;
L13: 
L10: 

    /** 			tok = next_token()*/
    _0 = _tok_60639;
    _tok_60639 = _39next_token();
    DeRef(_0);

    /** 			id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _id_60640 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_60640)){
        _id_60640 = (long)DBL_PTR(_id_60640)->dbl;
    }

    /** 			if id = TYPE or id = QUALIFIED_TYPE then*/
    _30416 = (_id_60640 == 504);
    if (_30416 != 0) {
        goto L14; // [358] 373
    }
    _30418 = (_id_60640 == 522);
    if (_30418 == 0)
    {
        DeRef(_30418);
        _30418 = NOVALUE;
        goto L15; // [369] 391
    }
    else{
        DeRef(_30418);
        _30418 = NOVALUE;
    }
L14: 

    /** 				Global_declaration(tok[T_SYM], scope )*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30419 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30419);
    _30420 = _39Global_declaration(_30419, _scope_60641);
    _30419 = NOVALUE;
    goto L7; // [388] 1801
L15: 

    /** 			elsif id = CONSTANT then*/
    if (_id_60640 != 417)
    goto L16; // [395] 415

    /** 				Global_declaration(0, scope )*/
    _30422 = _39Global_declaration(0, _scope_60641);

    /** 				ExecCommand()*/
    _39ExecCommand();
    goto L7; // [412] 1801
L16: 

    /** 			elsif id = ENUM then*/
    if (_id_60640 != 427)
    goto L17; // [419] 439

    /** 				Global_declaration(-1, scope )*/
    _30424 = _39Global_declaration(-1, _scope_60641);

    /** 				ExecCommand()*/
    _39ExecCommand();
    goto L7; // [436] 1801
L17: 

    /** 			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30425 = (_id_60640 == 405);
    if (_30425 != 0) {
        _30426 = 1;
        goto L18; // [447] 461
    }
    _30427 = (_id_60640 == 406);
    _30426 = (_30427 != 0);
L18: 
    if (_30426 != 0) {
        goto L19; // [461] 476
    }
    _30429 = (_id_60640 == 416);
    if (_30429 == 0)
    {
        DeRef(_30429);
        _30429 = NOVALUE;
        goto L1A; // [472] 487
    }
    else{
        DeRef(_30429);
        _30429 = NOVALUE;
    }
L19: 

    /** 				SubProg(id, scope )*/
    _39SubProg(_id_60640, _scope_60641);
    goto L7; // [484] 1801
L1A: 

    /** 			elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30430 = (_scope_60641 == 13);
    if (_30430 == 0) {
        goto L1B; // [497] 523
    }
    _30432 = (_id_60640 == 418);
    if (_30432 == 0)
    {
        DeRef(_30432);
        _30432 = NOVALUE;
        goto L1B; // [508] 523
    }
    else{
        DeRef(_30432);
        _30432 = NOVALUE;
    }

    /** 				IncludeScan( 1 )*/
    _61IncludeScan(1);

    /** 				PushGoto()*/
    _39PushGoto();
    goto L7; // [520] 1801
L1B: 

    /** 			elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30433 = (_id_60640 == -100);
    if (_30433 != 0) {
        _30434 = 1;
        goto L1C; // [531] 545
    }
    _30435 = (_id_60640 == 512);
    _30434 = (_30435 != 0);
L1C: 
    if (_30434 == 0) {
        _30436 = 0;
        goto L1D; // [545] 577
    }
    _2 = (int)SEQ_PTR(_tok_60639);
    _30437 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_30437)){
        _30438 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30437)->dbl));
    }
    else{
        _30438 = (int)*(((s1_ptr)_2)->base + _30437);
    }
    _2 = (int)SEQ_PTR(_30438);
    _30439 = (int)*(((s1_ptr)_2)->base + 4);
    _30438 = NOVALUE;
    if (IS_ATOM_INT(_30439)) {
        _30440 = (_30439 == 9);
    }
    else {
        _30440 = binary_op(EQUALS, _30439, 9);
    }
    _30439 = NOVALUE;
    if (IS_ATOM_INT(_30440))
    _30436 = (_30440 != 0);
    else
    _30436 = DBL_PTR(_30440)->dbl != 0.0;
L1D: 
    if (_30436 == 0) {
        goto L1E; // [577] 597
    }
    Ref(_tok_60639);
    _30442 = _39undefined_var(_tok_60639, _scope_60641);
    if (_30442 == 0) {
        DeRef(_30442);
        _30442 = NOVALUE;
        goto L1E; // [587] 597
    }
    else {
        if (!IS_ATOM_INT(_30442) && DBL_PTR(_30442)->dbl == 0.0){
            DeRef(_30442);
            _30442 = NOVALUE;
            goto L1E; // [587] 597
        }
        DeRef(_30442);
        _30442 = NOVALUE;
    }
    DeRef(_30442);
    _30442 = NOVALUE;

    /** 				continue*/
    goto L1; // [592] 12
    goto L7; // [594] 1801
L1E: 

    /** 			elsif scope = SC_GLOBAL then*/
    if (_scope_60641 != 6)
    goto L1F; // [601] 615

    /** 				CompileErr( 18 )*/
    RefDS(_21815);
    _44CompileErr(18, _21815, 0);
    goto L7; // [612] 1801
L1F: 

    /** 				CompileErr( 16 )*/
    RefDS(_21815);
    _44CompileErr(16, _21815, 0);
    goto L7; // [623] 1801
LE: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30444 = (_id_60640 == 504);
    if (_30444 != 0) {
        goto L20; // [634] 649
    }
    _30446 = (_id_60640 == 522);
    if (_30446 == 0)
    {
        DeRef(_30446);
        _30446 = NOVALUE;
        goto L21; // [645] 734
    }
    else{
        DeRef(_30446);
        _30446 = NOVALUE;
    }
L20: 

    /** 			token test = next_token()*/
    _0 = _test_60782;
    _test_60782 = _39next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_60782);
    _39putback(_test_60782);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_60782);
    _30448 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30448, -26)){
        _30448 = NOVALUE;
        goto L22; // [669] 707
    }
    _30448 = NOVALUE;

    /** 					StartSourceLine( TRUE )*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 					Procedure_call(tok)*/
    Ref(_tok_60639);
    _39Procedure_call(_tok_60639);

    /** 					clear_op()*/
    _41clear_op();

    /** 					if Pop() then end if*/
    _30450 = _41Pop();
    if (_30450 == 0) {
        DeRef(_30450);
        _30450 = NOVALUE;
        goto L23; // [696] 700
    }
    else {
        if (!IS_ATOM_INT(_30450) && DBL_PTR(_30450)->dbl == 0.0){
            DeRef(_30450);
            _30450 = NOVALUE;
            goto L23; // [696] 700
        }
        DeRef(_30450);
        _30450 = NOVALUE;
    }
    DeRef(_30450);
    _30450 = NOVALUE;
L23: 

    /** 					ExecCommand()*/
    _39ExecCommand();
    goto L24; // [704] 723
L22: 

    /** 				Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30451 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30451);
    _30452 = _39Global_declaration(_30451, 5);
    _30451 = NOVALUE;
L24: 

    /** 			continue*/
    DeRef(_test_60782);
    _test_60782 = NOVALUE;
    goto L1; // [727] 12
    goto L7; // [731] 1801
L21: 

    /** 		elsif id = CONSTANT then*/
    if (_id_60640 != 417)
    goto L25; // [738] 758

    /** 			Global_declaration(0, SC_LOCAL)*/
    _30454 = _39Global_declaration(0, 5);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [755] 1801
L25: 

    /** 		elsif id = ENUM then*/
    if (_id_60640 != 427)
    goto L26; // [762] 782

    /** 			Global_declaration(-1, SC_LOCAL)*/
    _30456 = _39Global_declaration(-1, 5);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [779] 1801
L26: 

    /** 		elsif id = IF then*/
    if (_id_60640 != 20)
    goto L27; // [786] 810

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			If_statement()*/
    _39If_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [807] 1801
L27: 

    /** 		elsif id = FOR then*/
    if (_id_60640 != 21)
    goto L28; // [814] 838

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			For_statement()*/
    _39For_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [835] 1801
L28: 

    /** 		elsif id = WHILE then*/
    if (_id_60640 != 47)
    goto L29; // [842] 866

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			While_statement()*/
    _39While_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [863] 1801
L29: 

    /** 		elsif id = LOOP then*/
    if (_id_60640 != 422)
    goto L2A; // [870] 894

    /** 		    StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 		    Loop_statement()*/
    _39Loop_statement();

    /** 		    ExecCommand()*/
    _39ExecCommand();
    goto L7; // [891] 1801
L2A: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30461 = (_id_60640 == 27);
    if (_30461 != 0) {
        goto L2B; // [902] 917
    }
    _30463 = (_id_60640 == 521);
    if (_30463 == 0)
    {
        DeRef(_30463);
        _30463 = NOVALUE;
        goto L2C; // [913] 958
    }
    else{
        DeRef(_30463);
        _30463 = NOVALUE;
    }
L2B: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			if id = PROC then*/
    if (_id_60640 != 27)
    goto L2D; // [930] 946

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30465 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30465);
    _39UndefinedVar(_30465);
    _30465 = NOVALUE;
L2D: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_60639);
    _39Procedure_call(_tok_60639);

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [955] 1801
L2C: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30466 = (_id_60640 == 501);
    if (_30466 != 0) {
        goto L2E; // [966] 981
    }
    _30468 = (_id_60640 == 520);
    if (_30468 == 0)
    {
        DeRef(_30468);
        _30468 = NOVALUE;
        goto L2F; // [977] 1035
    }
    else{
        DeRef(_30468);
        _30468 = NOVALUE;
    }
L2E: 

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			if id = FUNC then*/
    if (_id_60640 != 501)
    goto L30; // [994] 1010

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30470 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30470);
    _39UndefinedVar(_30470);
    _30470 = NOVALUE;
L30: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_60639);
    _39Procedure_call(_tok_60639);

    /** 			clear_op()*/
    _41clear_op();

    /** 			if Pop() then end if*/
    _30471 = _41Pop();
    if (_30471 == 0) {
        DeRef(_30471);
        _30471 = NOVALUE;
        goto L31; // [1024] 1028
    }
    else {
        if (!IS_ATOM_INT(_30471) && DBL_PTR(_30471)->dbl == 0.0){
            DeRef(_30471);
            _30471 = NOVALUE;
            goto L31; // [1024] 1028
        }
        DeRef(_30471);
        _30471 = NOVALUE;
    }
    DeRef(_30471);
    _30471 = NOVALUE;
L31: 

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [1032] 1801
L2F: 

    /** 		elsif id = RETURN then*/
    if (_id_60640 != 413)
    goto L32; // [1039] 1050

    /** 			Return_statement() -- will fail - not allowed at top level*/
    _39Return_statement();
    goto L7; // [1047] 1801
L32: 

    /** 		elsif id = EXIT then*/
    if (_id_60640 != 61)
    goto L33; // [1054] 1090

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L34; // [1060] 1079
    }
    else{
    }

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Exit_statement()*/
    _39Exit_statement();
    goto L7; // [1076] 1801
L34: 

    /** 			CompileErr(89)*/
    RefDS(_21815);
    _44CompileErr(89, _21815, 0);
    goto L7; // [1087] 1801
L33: 

    /** 		elsif id = INCLUDE then*/
    if (_id_60640 != 418)
    goto L35; // [1094] 1110

    /** 			IncludeScan( 0 )*/
    _61IncludeScan(0);

    /** 			PushGoto()*/
    _39PushGoto();
    goto L7; // [1107] 1801
L35: 

    /** 		elsif id = WITH then*/
    if (_id_60640 != 420)
    goto L36; // [1114] 1128

    /** 			SetWith(TRUE)*/
    _39SetWith(_13TRUE_437);
    goto L7; // [1125] 1801
L36: 

    /** 		elsif id = WITHOUT then*/
    if (_id_60640 != 421)
    goto L37; // [1132] 1146

    /** 			SetWith(FALSE)*/
    _39SetWith(_13FALSE_435);
    goto L7; // [1143] 1801
L37: 

    /** 		elsif id = END_OF_FILE then*/
    if (_id_60640 != -21)
    goto L38; // [1150] 1267

    /** 			if IncludePop() then*/
    _30478 = _61IncludePop();
    if (_30478 == 0) {
        DeRef(_30478);
        _30478 = NOVALUE;
        goto L39; // [1159] 1255
    }
    else {
        if (!IS_ATOM_INT(_30478) && DBL_PTR(_30478)->dbl == 0.0){
            DeRef(_30478);
            _30478 = NOVALUE;
            goto L39; // [1159] 1255
        }
        DeRef(_30478);
        _30478 = NOVALUE;
    }
    DeRef(_30478);
    _30478 = NOVALUE;

    /** 				backed_up_tok = {}*/
    RefDS(_21815);
    DeRef(_39backed_up_tok_53676);
    _39backed_up_tok_53676 = _21815;

    /** 				PopGoto()*/
    _39PopGoto();

    /** 				read_line()*/
    _61read_line();

    /** 				last_ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44last_ForwardLine_48145);
    _44last_ForwardLine_48145 = _44ThisLine_48142;

    /** 				last_fwd_line_number = line_number*/
    _35last_fwd_line_number_15972 = _35line_number_15969;

    /** 				last_forward_bp      = bp*/
    _44last_forward_bp_48149 = _44bp_48146;

    /** 				putback_ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44putback_ForwardLine_48144);
    _44putback_ForwardLine_48144 = _44ThisLine_48142;

    /** 				putback_fwd_line_number = line_number*/
    _35putback_fwd_line_number_15971 = _35line_number_15969;

    /** 				putback_forward_bp      = bp*/
    _44putback_forward_bp_48148 = _44bp_48146;

    /** 				ForwardLine     = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44ForwardLine_48143);
    _44ForwardLine_48143 = _44ThisLine_48142;

    /** 				fwd_line_number = line_number*/
    _35fwd_line_number_15970 = _35line_number_15969;

    /** 				forward_bp      = bp*/
    _44forward_bp_48147 = _44bp_48146;
    goto L7; // [1252] 1801
L39: 

    /** 				CheckForUndefinedGotoLabels()*/
    _39CheckForUndefinedGotoLabels();

    /** 				exit -- all finished*/
    goto L2; // [1261] 1811
    goto L7; // [1264] 1801
L38: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_60640 != -31)
    goto L3A; // [1271] 1295

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Print_statement()*/
    _39Print_statement();

    /** 			ExecCommand()*/
    _39ExecCommand();
    goto L7; // [1292] 1801
L3A: 

    /** 		elsif id = LABEL then*/
    if (_id_60640 != 419)
    goto L3B; // [1299] 1321

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 			GLabel_statement()*/
    _39GLabel_statement();
    goto L7; // [1318] 1801
L3B: 

    /** 		elsif id = GOTO then*/
    if (_id_60640 != 188)
    goto L3C; // [1325] 1345

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Goto_statement()*/
    _39Goto_statement();
    goto L7; // [1342] 1801
L3C: 

    /** 		elsif id = CONTINUE then*/
    if (_id_60640 != 426)
    goto L3D; // [1349] 1385

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L3E; // [1355] 1374
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 				Continue_statement()*/
    _39Continue_statement();
    goto L7; // [1371] 1801
L3E: 

    /** 				CompileErr(50)*/
    RefDS(_21815);
    _44CompileErr(50, _21815, 0);
    goto L7; // [1382] 1801
L3D: 

    /** 		elsif id = RETRY then*/
    if (_id_60640 != 184)
    goto L3F; // [1389] 1425

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L40; // [1395] 1414
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 				Retry_statement()*/
    _39Retry_statement();
    goto L7; // [1411] 1801
L40: 

    /** 				CompileErr(128)*/
    RefDS(_21815);
    _44CompileErr(128, _21815, 0);
    goto L7; // [1422] 1801
L3F: 

    /** 		elsif id = BREAK then*/
    if (_id_60640 != 425)
    goto L41; // [1429] 1465

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L42; // [1435] 1454
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 				Break_statement()*/
    _39Break_statement();
    goto L7; // [1451] 1801
L42: 

    /** 				CompileErr(39)*/
    RefDS(_21815);
    _44CompileErr(39, _21815, 0);
    goto L7; // [1462] 1801
L41: 

    /** 		elsif id = ENTRY then*/
    if (_id_60640 != 424)
    goto L43; // [1469] 1507

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L44; // [1475] 1496
    }
    else{
    }

    /** 			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _41StartSourceLine(_13TRUE_437, 0, 1);

    /** 			    Entry_statement()*/
    _39Entry_statement();
    goto L7; // [1493] 1801
L44: 

    /** 				CompileErr(72)*/
    RefDS(_21815);
    _44CompileErr(72, _21815, 0);
    goto L7; // [1504] 1801
L43: 

    /** 		elsif id = IFDEF then*/
    if (_id_60640 != 407)
    goto L45; // [1511] 1531

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Ifdef_statement()*/
    _39Ifdef_statement();
    goto L7; // [1528] 1801
L45: 

    /** 		elsif id = CASE then*/
    if (_id_60640 != 186)
    goto L46; // [1535] 1546

    /** 			Case_statement()*/
    _39Case_statement();
    goto L7; // [1543] 1801
L46: 

    /** 		elsif id = SWITCH then*/
    if (_id_60640 != 185)
    goto L47; // [1550] 1570

    /** 			StartSourceLine(TRUE)*/
    _41StartSourceLine(_13TRUE_437, 0, 2);

    /** 			Switch_statement()*/
    _39Switch_statement();
    goto L7; // [1567] 1801
L47: 

    /** 		elsif id = ILLEGAL_CHAR then*/
    if (_id_60640 != -20)
    goto L48; // [1574] 1588

    /** 			CompileErr(102)*/
    RefDS(_21815);
    _44CompileErr(102, _21815, 0);
    goto L7; // [1585] 1801
L48: 

    /** 			if nested then*/
    if (_nested_60637 == 0)
    {
        goto L49; // [1590] 1742
    }
    else{
    }

    /** 				if id = ELSE then*/
    if (_id_60640 != 23)
    goto L4A; // [1597] 1651

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _30491 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _30491 = 1;
    }
    if (_30491 != 0)
    goto L4B; // [1608] 1708

    /** 						if live_ifdef > 0 then*/
    if (_39live_ifdef_57842 <= 0)
    goto L4C; // [1616] 1639

    /** 							CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _30494 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _30494 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _30495 = (int)*(((s1_ptr)_2)->base + _30494);
    _44CompileErr(134, _30495, 0);
    _30495 = NOVALUE;
    goto L4B; // [1636] 1708
L4C: 

    /** 							CompileErr(118)*/
    RefDS(_21815);
    _44CompileErr(118, _21815, 0);
    goto L4B; // [1648] 1708
L4A: 

    /** 				elsif id = ELSIF then*/
    if (_id_60640 != 414)
    goto L4D; // [1655] 1707

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_39if_stack_53704)){
            _30497 = SEQ_PTR(_39if_stack_53704)->length;
    }
    else {
        _30497 = 1;
    }
    if (_30497 != 0)
    goto L4E; // [1666] 1706

    /** 						if live_ifdef > 0 then*/
    if (_39live_ifdef_57842 <= 0)
    goto L4F; // [1674] 1697

    /** 							CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_39ifdef_lineno_57843)){
            _30500 = SEQ_PTR(_39ifdef_lineno_57843)->length;
    }
    else {
        _30500 = 1;
    }
    _2 = (int)SEQ_PTR(_39ifdef_lineno_57843);
    _30501 = (int)*(((s1_ptr)_2)->base + _30500);
    _44CompileErr(139, _30501, 0);
    _30501 = NOVALUE;
    goto L50; // [1694] 1705
L4F: 

    /** 							CompileErr(119)*/
    RefDS(_21815);
    _44CompileErr(119, _21815, 0);
L50: 
L4E: 
L4D: 
L4B: 

    /** 				putback(tok)*/
    Ref(_tok_60639);
    _39putback(_tok_60639);

    /** 				if stmt_nest > 0 then*/
    if (_39stmt_nest_53701 <= 0)
    goto L51; // [1717] 1734

    /** 					stmt_nest -= 1*/
    _39stmt_nest_53701 = _39stmt_nest_53701 - 1;

    /** 					InitDelete()*/
    _39InitDelete();
L51: 

    /** 				return*/
    DeRef(_tok_60639);
    DeRef(_30403);
    _30403 = NOVALUE;
    DeRef(_30425);
    _30425 = NOVALUE;
    DeRef(_30422);
    _30422 = NOVALUE;
    DeRef(_30440);
    _30440 = NOVALUE;
    DeRef(_30433);
    _30433 = NOVALUE;
    _30437 = NOVALUE;
    DeRef(_30388);
    _30388 = NOVALUE;
    DeRef(_30397);
    _30397 = NOVALUE;
    DeRef(_30416);
    _30416 = NOVALUE;
    DeRef(_30452);
    _30452 = NOVALUE;
    DeRef(_30461);
    _30461 = NOVALUE;
    DeRef(_30427);
    _30427 = NOVALUE;
    DeRef(_30435);
    _30435 = NOVALUE;
    DeRef(_30407);
    _30407 = NOVALUE;
    DeRef(_30444);
    _30444 = NOVALUE;
    _30391 = NOVALUE;
    DeRef(_30456);
    _30456 = NOVALUE;
    DeRef(_30420);
    _30420 = NOVALUE;
    DeRef(_30454);
    _30454 = NOVALUE;
    DeRef(_30466);
    _30466 = NOVALUE;
    DeRef(_30405);
    _30405 = NOVALUE;
    DeRef(_30394);
    _30394 = NOVALUE;
    DeRef(_30424);
    _30424 = NOVALUE;
    DeRef(_30430);
    _30430 = NOVALUE;
    DeRef(_30399);
    _30399 = NOVALUE;
    return;
    goto L52; // [1739] 1800
L49: 

    /** 				if id = END then*/
    if (_id_60640 != 402)
    goto L53; // [1746] 1777

    /** 					tok = next_token()*/
    _0 = _tok_60639;
    _tok_60639 = _39next_token();
    DeRef(_0);

    /** 					CompileErr(17, {find_token_text(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_60639);
    _30506 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30506);
    _30507 = _63find_token_text(_30506);
    _30506 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30507;
    _30508 = MAKE_SEQ(_1);
    _30507 = NOVALUE;
    _44CompileErr(17, _30508, 0);
    _30508 = NOVALUE;
L53: 

    /** 				CompileErr(117, { match_replace(",", find_token_text(id), "") })*/
    _30509 = _63find_token_text(_id_60640);
    RefDS(_26006);
    RefDS(_21815);
    _30510 = _16match_replace(_26006, _30509, _21815, 0);
    _30509 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30510;
    _30511 = MAKE_SEQ(_1);
    _30510 = NOVALUE;
    _44CompileErr(117, _30511, 0);
    _30511 = NOVALUE;
L52: 
L7: 

    /** 		flush_temps()*/
    RefDS(_21815);
    _41flush_temps(_21815);

    /** 	end while*/
    goto L1; // [1808] 12
L2: 

    /** 	emit_op(RETURNT)*/
    _41emit_op(34);

    /** 	clear_last()*/
    _41clear_last();

    /** 	StraightenBranches()*/
    _39StraightenBranches();

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16056;
    DeRef(_1);
    _30512 = NOVALUE;

    /** 	EndLineTable()*/
    _39EndLineTable();

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_35LineTable_16057);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_LINETAB_15676))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_LINETAB_15676)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_LINETAB_15676);
    _1 = *(int *)_2;
    *(int *)_2 = _35LineTable_16057;
    DeRef(_1);
    _30514 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_60639);
    DeRef(_30403);
    _30403 = NOVALUE;
    DeRef(_30425);
    _30425 = NOVALUE;
    DeRef(_30422);
    _30422 = NOVALUE;
    DeRef(_30440);
    _30440 = NOVALUE;
    DeRef(_30433);
    _30433 = NOVALUE;
    _30437 = NOVALUE;
    DeRef(_30388);
    _30388 = NOVALUE;
    DeRef(_30397);
    _30397 = NOVALUE;
    DeRef(_30416);
    _30416 = NOVALUE;
    DeRef(_30452);
    _30452 = NOVALUE;
    DeRef(_30461);
    _30461 = NOVALUE;
    DeRef(_30427);
    _30427 = NOVALUE;
    DeRef(_30435);
    _30435 = NOVALUE;
    DeRef(_30407);
    _30407 = NOVALUE;
    DeRef(_30444);
    _30444 = NOVALUE;
    _30391 = NOVALUE;
    DeRef(_30456);
    _30456 = NOVALUE;
    DeRef(_30420);
    _30420 = NOVALUE;
    DeRef(_30454);
    _30454 = NOVALUE;
    DeRef(_30466);
    _30466 = NOVALUE;
    DeRef(_30405);
    _30405 = NOVALUE;
    DeRef(_30394);
    _30394 = NOVALUE;
    DeRef(_30424);
    _30424 = NOVALUE;
    DeRef(_30430);
    _30430 = NOVALUE;
    DeRef(_30399);
    _30399 = NOVALUE;
    return;
    ;
}


void _39parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(0)*/
    _39real_parser(0);

    /** 	mark_final_targets()*/
    _53mark_final_targets();

    /** 	resolve_unincluded_globals( 1 )*/
    _53resolve_unincluded_globals(1);

    /** 	Resolve_forward_references( 1 )*/
    _38Resolve_forward_references(1);

    /** 	inline_deferred_calls()*/
    _67inline_deferred_calls();

    /** 	End_block( PROC )*/
    _66End_block(27);

    /** 	Code = {}*/
    RefDS(_21815);
    DeRef(_35Code_16056);
    _35Code_16056 = _21815;

    /** 	LineTable = {}*/
    RefDS(_21815);
    DeRef(_35LineTable_16057);
    _35LineTable_16057 = _21815;

    /** end procedure*/
    return;
    ;
}


void _39nested_parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(1)*/
    _39real_parser(1);

    /** end procedure*/
    return;
    ;
}



// 0x6943D9B2
