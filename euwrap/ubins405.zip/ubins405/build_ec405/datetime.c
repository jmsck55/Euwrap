// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _18isLeap(int _year_2216)
{
    int _ly_2217 = NOVALUE;
    int _989 = NOVALUE;
    int _988 = NOVALUE;
    int _987 = NOVALUE;
    int _986 = NOVALUE;
    int _985 = NOVALUE;
    int _984 = NOVALUE;
    int _983 = NOVALUE;
    int _982 = NOVALUE;
    int _981 = NOVALUE;
    int _978 = NOVALUE;
    int _976 = NOVALUE;
    int _975 = NOVALUE;
    int _0, _1, _2;
    

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _975 = MAKE_SEQ(_1);
    _976 = binary_op(REMAINDER, _year_2216, _975);
    DeRefDS(_975);
    _975 = NOVALUE;
    DeRefi(_ly_2217);
    _ly_2217 = binary_op(EQUALS, _976, 0);
    DeRefDS(_976);
    _976 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_2217);
    _978 = (int)*(((s1_ptr)_2)->base + 1);
    if (_978 != 0)
    goto L1; // [29] 37
    _978 = NOVALUE;
    DeRefDSi(_ly_2217);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_2216 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_2217);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_2217);
    _981 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_2217);
    _982 = (int)*(((s1_ptr)_2)->base + 2);
    _983 = _981 - _982;
    if ((long)((unsigned long)_983 +(unsigned long) HIGH_BITS) >= 0){
        _983 = NewDouble((double)_983);
    }
    _981 = NOVALUE;
    _982 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2217);
    _984 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_983)) {
        _985 = _983 + _984;
        if ((long)((unsigned long)_985 + (unsigned long)HIGH_BITS) >= 0) 
        _985 = NewDouble((double)_985);
    }
    else {
        _985 = NewDouble(DBL_PTR(_983)->dbl + (double)_984);
    }
    DeRef(_983);
    _983 = NOVALUE;
    _984 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2217);
    _986 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_985)) {
        _987 = _985 - _986;
        if ((long)((unsigned long)_987 +(unsigned long) HIGH_BITS) >= 0){
            _987 = NewDouble((double)_987);
        }
    }
    else {
        _987 = NewDouble(DBL_PTR(_985)->dbl - (double)_986);
    }
    DeRef(_985);
    _985 = NOVALUE;
    _986 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_2217);
    _988 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_987)) {
        _989 = _987 + _988;
        if ((long)((unsigned long)_989 + (unsigned long)HIGH_BITS) >= 0) 
        _989 = NewDouble((double)_989);
    }
    else {
        _989 = NewDouble(DBL_PTR(_987)->dbl + (double)_988);
    }
    DeRef(_987);
    _987 = NOVALUE;
    _988 = NOVALUE;
    DeRefDSi(_ly_2217);
    return _989;
L3: 
    ;
}


int _18daysInMonth(int _year_2241, int _month_2242)
{
    int _997 = NOVALUE;
    int _996 = NOVALUE;
    int _995 = NOVALUE;
    int _994 = NOVALUE;
    int _992 = NOVALUE;
    int _991 = NOVALUE;
    int _990 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_2242)) {
        _1 = (long)(DBL_PTR(_month_2242)->dbl);
        DeRefDS(_month_2242);
        _month_2242 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _990 = (_year_2241 == 1752);
    if (_990 == 0) {
        goto L1; // [11] 32
    }
    _992 = (_month_2242 == 9);
    if (_992 == 0)
    {
        DeRef(_992);
        _992 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_992);
        _992 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_990);
    _990 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_2242 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_18DaysPerMonth_2198);
    _994 = (int)*(((s1_ptr)_2)->base + _month_2242);
    Ref(_994);
    DeRef(_990);
    _990 = NOVALUE;
    return _994;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_18DaysPerMonth_2198);
    _995 = (int)*(((s1_ptr)_2)->base + _month_2242);
    _996 = _18isLeap(_year_2241);
    if (IS_ATOM_INT(_995) && IS_ATOM_INT(_996)) {
        _997 = _995 + _996;
        if ((long)((unsigned long)_997 + (unsigned long)HIGH_BITS) >= 0) 
        _997 = NewDouble((double)_997);
    }
    else {
        _997 = binary_op(PLUS, _995, _996);
    }
    _995 = NOVALUE;
    DeRef(_996);
    _996 = NOVALUE;
    DeRef(_990);
    _990 = NOVALUE;
    _994 = NOVALUE;
    return _997;
L2: 
    ;
}


int _18julianDayOfYear(int _ymd_2265)
{
    int _year_2266 = NOVALUE;
    int _month_2267 = NOVALUE;
    int _day_2268 = NOVALUE;
    int _d_2269 = NOVALUE;
    int _1013 = NOVALUE;
    int _1012 = NOVALUE;
    int _1011 = NOVALUE;
    int _1008 = NOVALUE;
    int _1007 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_2265);
    _year_2266 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_2266)){
        _year_2266 = (long)DBL_PTR(_year_2266)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_2265);
    _month_2267 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_2267)){
        _month_2267 = (long)DBL_PTR(_month_2267)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_2265);
    _day_2268 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_2268)){
        _day_2268 = (long)DBL_PTR(_day_2268)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_2267 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_2265);
    return _day_2268;
L1: 

    /** 	d = 0*/
    _d_2269 = 0;

    /** 	for i = 1 to month - 1 do*/
    _1007 = _month_2267 - 1;
    if ((long)((unsigned long)_1007 +(unsigned long) HIGH_BITS) >= 0){
        _1007 = NewDouble((double)_1007);
    }
    {
        int _i_2276;
        _i_2276 = 1;
L2: 
        if (binary_op_a(GREATER, _i_2276, _1007)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_2276);
        _1008 = _18daysInMonth(_year_2266, _i_2276);
        if (IS_ATOM_INT(_1008)) {
            _d_2269 = _d_2269 + _1008;
        }
        else {
            _d_2269 = binary_op(PLUS, _d_2269, _1008);
        }
        DeRef(_1008);
        _1008 = NOVALUE;
        if (!IS_ATOM_INT(_d_2269)) {
            _1 = (long)(DBL_PTR(_d_2269)->dbl);
            DeRefDS(_d_2269);
            _d_2269 = _1;
        }

        /** 	end for*/
        _0 = _i_2276;
        if (IS_ATOM_INT(_i_2276)) {
            _i_2276 = _i_2276 + 1;
            if ((long)((unsigned long)_i_2276 +(unsigned long) HIGH_BITS) >= 0){
                _i_2276 = NewDouble((double)_i_2276);
            }
        }
        else {
            _i_2276 = binary_op_a(PLUS, _i_2276, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_2276);
    }

    /** 	d += day*/
    _d_2269 = _d_2269 + _day_2268;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _1011 = (_year_2266 == 1752);
    if (_1011 == 0) {
        goto L4; // [86] 128
    }
    _1013 = (_month_2267 == 9);
    if (_1013 == 0)
    {
        DeRef(_1013);
        _1013 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_1013);
        _1013 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_2268 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_2269 = _d_2269 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_2268 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_2265);
    DeRef(_1007);
    _1007 = NOVALUE;
    DeRef(_1011);
    _1011 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_2265);
    DeRef(_1007);
    _1007 = NOVALUE;
    DeRef(_1011);
    _1011 = NOVALUE;
    return _d_2269;
    ;
}


int _18julianDay(int _ymd_2292)
{
    int _year_2293 = NOVALUE;
    int _j_2294 = NOVALUE;
    int _greg00_2295 = NOVALUE;
    int _1042 = NOVALUE;
    int _1039 = NOVALUE;
    int _1036 = NOVALUE;
    int _1035 = NOVALUE;
    int _1034 = NOVALUE;
    int _1033 = NOVALUE;
    int _1032 = NOVALUE;
    int _1031 = NOVALUE;
    int _1030 = NOVALUE;
    int _1029 = NOVALUE;
    int _1027 = NOVALUE;
    int _1026 = NOVALUE;
    int _1025 = NOVALUE;
    int _1024 = NOVALUE;
    int _1023 = NOVALUE;
    int _1022 = NOVALUE;
    int _1021 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_2292);
    _year_2293 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_2293)){
        _year_2293 = (long)DBL_PTR(_year_2293)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_2292);
    _j_2294 = _18julianDayOfYear(_ymd_2292);
    if (!IS_ATOM_INT(_j_2294)) {
        _1 = (long)(DBL_PTR(_j_2294)->dbl);
        DeRefDS(_j_2294);
        _j_2294 = _1;
    }

    /** 	year  -= 1*/
    _year_2293 = _year_2293 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_2295 = _year_2293 - 1700;

    /** 	j += (*/
    if (_year_2293 <= INT15 && _year_2293 >= -INT15)
    _1021 = 365 * _year_2293;
    else
    _1021 = NewDouble(365 * (double)_year_2293);
    if (4 > 0 && _year_2293 >= 0) {
        _1022 = _year_2293 / 4;
    }
    else {
        temp_dbl = floor((double)_year_2293 / (double)4);
        _1022 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_1021)) {
        _1023 = _1021 + _1022;
        if ((long)((unsigned long)_1023 + (unsigned long)HIGH_BITS) >= 0) 
        _1023 = NewDouble((double)_1023);
    }
    else {
        _1023 = NewDouble(DBL_PTR(_1021)->dbl + (double)_1022);
    }
    DeRef(_1021);
    _1021 = NOVALUE;
    _1022 = NOVALUE;
    _1024 = (_greg00_2295 > 0);
    if (100 > 0 && _greg00_2295 >= 0) {
        _1025 = _greg00_2295 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_2295 / (double)100);
        _1025 = (long)temp_dbl;
    }
    _1026 = - _1025;
    _1027 = (_greg00_2295 % 400) ? NewDouble((double)_greg00_2295 / 400) : (_greg00_2295 / 400);
    if (IS_ATOM_INT(_1027)) {
        _1029 = NewDouble((double)_1027 + DBL_PTR(_1028)->dbl);
    }
    else {
        _1029 = NewDouble(DBL_PTR(_1027)->dbl + DBL_PTR(_1028)->dbl);
    }
    DeRef(_1027);
    _1027 = NOVALUE;
    _1030 = unary_op(FLOOR, _1029);
    DeRefDS(_1029);
    _1029 = NOVALUE;
    if (IS_ATOM_INT(_1030)) {
        _1031 = _1026 + _1030;
        if ((long)((unsigned long)_1031 + (unsigned long)HIGH_BITS) >= 0) 
        _1031 = NewDouble((double)_1031);
    }
    else {
        _1031 = NewDouble((double)_1026 + DBL_PTR(_1030)->dbl);
    }
    _1026 = NOVALUE;
    DeRef(_1030);
    _1030 = NOVALUE;
    if (IS_ATOM_INT(_1031)) {
        if (_1031 <= INT15 && _1031 >= -INT15)
        _1032 = _1024 * _1031;
        else
        _1032 = NewDouble(_1024 * (double)_1031);
    }
    else {
        _1032 = NewDouble((double)_1024 * DBL_PTR(_1031)->dbl);
    }
    _1024 = NOVALUE;
    DeRef(_1031);
    _1031 = NOVALUE;
    if (IS_ATOM_INT(_1023) && IS_ATOM_INT(_1032)) {
        _1033 = _1023 + _1032;
        if ((long)((unsigned long)_1033 + (unsigned long)HIGH_BITS) >= 0) 
        _1033 = NewDouble((double)_1033);
    }
    else {
        if (IS_ATOM_INT(_1023)) {
            _1033 = NewDouble((double)_1023 + DBL_PTR(_1032)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1032)) {
                _1033 = NewDouble(DBL_PTR(_1023)->dbl + (double)_1032);
            }
            else
            _1033 = NewDouble(DBL_PTR(_1023)->dbl + DBL_PTR(_1032)->dbl);
        }
    }
    DeRef(_1023);
    _1023 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    _1034 = (_year_2293 >= 1752);
    _1035 = 11 * _1034;
    _1034 = NOVALUE;
    if (IS_ATOM_INT(_1033)) {
        _1036 = _1033 - _1035;
        if ((long)((unsigned long)_1036 +(unsigned long) HIGH_BITS) >= 0){
            _1036 = NewDouble((double)_1036);
        }
    }
    else {
        _1036 = NewDouble(DBL_PTR(_1033)->dbl - (double)_1035);
    }
    DeRef(_1033);
    _1033 = NOVALUE;
    _1035 = NOVALUE;
    if (IS_ATOM_INT(_1036)) {
        _j_2294 = _j_2294 + _1036;
    }
    else {
        _j_2294 = NewDouble((double)_j_2294 + DBL_PTR(_1036)->dbl);
    }
    DeRef(_1036);
    _1036 = NOVALUE;
    if (!IS_ATOM_INT(_j_2294)) {
        _1 = (long)(DBL_PTR(_j_2294)->dbl);
        DeRefDS(_j_2294);
        _j_2294 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_2293 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_2293 >= 0) {
        _1039 = _year_2293 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_2293 / (double)3200);
        _1039 = (long)temp_dbl;
    }
    _j_2294 = _j_2294 - _1039;
    _1039 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_2293 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_2293 >= 0) {
        _1042 = _year_2293 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_2293 / (double)80000);
        _1042 = (long)temp_dbl;
    }
    _j_2294 = _j_2294 + _1042;
    _1042 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_2292);
    DeRef(_1025);
    _1025 = NOVALUE;
    return _j_2294;
    ;
}


int _18datetimeToSeconds(int _dt_2381)
{
    int _1086 = NOVALUE;
    int _1085 = NOVALUE;
    int _1084 = NOVALUE;
    int _1083 = NOVALUE;
    int _1082 = NOVALUE;
    int _1081 = NOVALUE;
    int _1080 = NOVALUE;
    int _1078 = NOVALUE;
    int _1077 = NOVALUE;
    int _1076 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_2381);
    _1076 = _18julianDay(_dt_2381);
    if (IS_ATOM_INT(_1076)) {
        _1077 = NewDouble(_1076 * (double)86400);
    }
    else {
        _1077 = binary_op(MULTIPLY, _1076, 86400);
    }
    DeRef(_1076);
    _1076 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2381);
    _1078 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_1078)) {
        if (_1078 == (short)_1078)
        _1080 = _1078 * 60;
        else
        _1080 = NewDouble(_1078 * (double)60);
    }
    else {
        _1080 = binary_op(MULTIPLY, _1078, 60);
    }
    _1078 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2381);
    _1081 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_1080) && IS_ATOM_INT(_1081)) {
        _1082 = _1080 + _1081;
        if ((long)((unsigned long)_1082 + (unsigned long)HIGH_BITS) >= 0) 
        _1082 = NewDouble((double)_1082);
    }
    else {
        _1082 = binary_op(PLUS, _1080, _1081);
    }
    DeRef(_1080);
    _1080 = NOVALUE;
    _1081 = NOVALUE;
    if (IS_ATOM_INT(_1082)) {
        if (_1082 == (short)_1082)
        _1083 = _1082 * 60;
        else
        _1083 = NewDouble(_1082 * (double)60);
    }
    else {
        _1083 = binary_op(MULTIPLY, _1082, 60);
    }
    DeRef(_1082);
    _1082 = NOVALUE;
    if (IS_ATOM_INT(_1077) && IS_ATOM_INT(_1083)) {
        _1084 = _1077 + _1083;
        if ((long)((unsigned long)_1084 + (unsigned long)HIGH_BITS) >= 0) 
        _1084 = NewDouble((double)_1084);
    }
    else {
        _1084 = binary_op(PLUS, _1077, _1083);
    }
    DeRef(_1077);
    _1077 = NOVALUE;
    DeRef(_1083);
    _1083 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_2381);
    _1085 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_1084) && IS_ATOM_INT(_1085)) {
        _1086 = _1084 + _1085;
        if ((long)((unsigned long)_1086 + (unsigned long)HIGH_BITS) >= 0) 
        _1086 = NewDouble((double)_1086);
    }
    else {
        _1086 = binary_op(PLUS, _1084, _1085);
    }
    DeRef(_1084);
    _1084 = NOVALUE;
    _1085 = NOVALUE;
    DeRef(_dt_2381);
    return _1086;
    ;
}


int _18from_date(int _src_2548)
{
    int _1201 = NOVALUE;
    int _1200 = NOVALUE;
    int _1199 = NOVALUE;
    int _1198 = NOVALUE;
    int _1197 = NOVALUE;
    int _1196 = NOVALUE;
    int _1195 = NOVALUE;
    int _1193 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_2548);
    _1193 = (int)*(((s1_ptr)_2)->base + 1);
    _1195 = _1193 + 1900;
    if ((long)((unsigned long)_1195 + (unsigned long)HIGH_BITS) >= 0) 
    _1195 = NewDouble((double)_1195);
    _1193 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_2548);
    _1196 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_2548);
    _1197 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_2548);
    _1198 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_2548);
    _1199 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_2548);
    _1200 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _1195;
    *((int *)(_2+8)) = _1196;
    *((int *)(_2+12)) = _1197;
    *((int *)(_2+16)) = _1198;
    *((int *)(_2+20)) = _1199;
    *((int *)(_2+24)) = _1200;
    _1201 = MAKE_SEQ(_1);
    _1200 = NOVALUE;
    _1199 = NOVALUE;
    _1198 = NOVALUE;
    _1197 = NOVALUE;
    _1196 = NOVALUE;
    _1195 = NOVALUE;
    DeRefDSi(_src_2548);
    return _1201;
    ;
}


int _18new(int _year_2580, int _month_2581, int _day_2582, int _hour_2583, int _minute_2584, int _second_2585)
{
    int _d_2586 = NOVALUE;
    int _now_1__tmp_at41_2593 = NOVALUE;
    int _now_inlined_now_at_41_2592 = NOVALUE;
    int _1216 = NOVALUE;
    int _1215 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_2580)) {
        _1 = (long)(DBL_PTR(_year_2580)->dbl);
        DeRefDS(_year_2580);
        _year_2580 = _1;
    }
    if (!IS_ATOM_INT(_month_2581)) {
        _1 = (long)(DBL_PTR(_month_2581)->dbl);
        DeRefDS(_month_2581);
        _month_2581 = _1;
    }
    if (!IS_ATOM_INT(_day_2582)) {
        _1 = (long)(DBL_PTR(_day_2582)->dbl);
        DeRefDS(_day_2582);
        _day_2582 = _1;
    }
    if (!IS_ATOM_INT(_hour_2583)) {
        _1 = (long)(DBL_PTR(_hour_2583)->dbl);
        DeRefDS(_hour_2583);
        _hour_2583 = _1;
    }
    if (!IS_ATOM_INT(_minute_2584)) {
        _1 = (long)(DBL_PTR(_minute_2584)->dbl);
        DeRefDS(_minute_2584);
        _minute_2584 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_2586;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_2580;
    *((int *)(_2+8)) = _month_2581;
    *((int *)(_2+12)) = _day_2582;
    *((int *)(_2+16)) = _hour_2583;
    *((int *)(_2+20)) = _minute_2584;
    Ref(_second_2585);
    *((int *)(_2+24)) = _second_2585;
    _d_2586 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _1215 = MAKE_SEQ(_1);
    if (_d_2586 == _1215)
    _1216 = 1;
    else if (IS_ATOM_INT(_d_2586) && IS_ATOM_INT(_1215))
    _1216 = 0;
    else
    _1216 = (compare(_d_2586, _1215) == 0);
    DeRefDS(_1215);
    _1215 = NOVALUE;
    if (_1216 == 0)
    {
        _1216 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _1216 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_2593);
    _now_1__tmp_at41_2593 = Date();
    RefDS(_now_1__tmp_at41_2593);
    _0 = _now_inlined_now_at_41_2592;
    _now_inlined_now_at_41_2592 = _18from_date(_now_1__tmp_at41_2593);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_2593);
    _now_1__tmp_at41_2593 = NOVALUE;
    DeRef(_second_2585);
    DeRef(_d_2586);
    return _now_inlined_now_at_41_2592;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_2585);
    return _d_2586;
L2: 
    ;
}



// 0x67FD0A2C
