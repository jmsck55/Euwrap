// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _57get_eucompiledir()
{
    int _x_41347 = NOVALUE;
    int _22145 = NOVALUE;
    int _22143 = NOVALUE;
    int _22140 = NOVALUE;
    int _22138 = NOVALUE;
    int _22136 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_41347);
    _x_41347 = EGetEnv(_22134);

    /** 	if is_eudir_from_cmdline() then*/
    _22136 = _36is_eudir_from_cmdline();
    if (_22136 == 0) {
        DeRef(_22136);
        _22136 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22136) && DBL_PTR(_22136)->dbl == 0.0){
            DeRef(_22136);
            _22136 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22136);
        _22136 = NOVALUE;
    }
    DeRef(_22136);
    _22136 = NOVALUE;

    /** 		x = get_eudir()*/
    _0 = _x_41347;
    _x_41347 = _36get_eudir();
    DeRefi(_0);
L1: 

    /** 	ifdef UNIX then*/

    /** 		if equal(x, -1) then*/
    if (_x_41347 == -1)
    _22138 = 1;
    else if (IS_ATOM_INT(_x_41347) && IS_ATOM_INT(-1))
    _22138 = 0;
    else
    _22138 = (compare(_x_41347, -1) == 0);
    if (_22138 == 0)
    {
        _22138 = NOVALUE;
        goto L2; // [28] 67
    }
    else{
        _22138 = NOVALUE;
    }

    /** 			x = "/usr/local/share/euphoria"*/
    RefDS(_22139);
    DeRef(_x_41347);
    _x_41347 = _22139;

    /** 			if not file_exists( x ) then*/
    RefDS(_x_41347);
    _22140 = _17file_exists(_x_41347);
    if (IS_ATOM_INT(_22140)) {
        if (_22140 != 0){
            DeRef(_22140);
            _22140 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    else {
        if (DBL_PTR(_22140)->dbl != 0.0){
            DeRef(_22140);
            _22140 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    DeRef(_22140);
    _22140 = NOVALUE;

    /** 				x = "/usr/share/euphoria"*/
    RefDS(_22142);
    DeRefDSi(_x_41347);
    _x_41347 = _22142;

    /** 				if not file_exists( x ) then*/
    RefDS(_x_41347);
    _22143 = _17file_exists(_x_41347);
    if (IS_ATOM_INT(_22143)) {
        if (_22143 != 0){
            DeRef(_22143);
            _22143 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    else {
        if (DBL_PTR(_22143)->dbl != 0.0){
            DeRef(_22143);
            _22143 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    DeRef(_22143);
    _22143 = NOVALUE;

    /** 					x = -1*/
    DeRefDSi(_x_41347);
    _x_41347 = -1;
L4: 
L3: 
L2: 

    /** 	if equal(x, -1) then*/
    if (_x_41347 == -1)
    _22145 = 1;
    else if (IS_ATOM_INT(_x_41347) && IS_ATOM_INT(-1))
    _22145 = 0;
    else
    _22145 = (compare(_x_41347, -1) == 0);
    if (_22145 == 0)
    {
        _22145 = NOVALUE;
        goto L5; // [73] 82
    }
    else{
        _22145 = NOVALUE;
    }

    /** 		x = get_eudir()*/
    _0 = _x_41347;
    _x_41347 = _36get_eudir();
    DeRef(_0);
L5: 

    /** 	return x*/
    return _x_41347;
    ;
}


void _57NewBB(int _a_call_41373, int _mask_41374, int _sub_41376)
{
    int _s_41378 = NOVALUE;
    int _22178 = NOVALUE;
    int _22177 = NOVALUE;
    int _22175 = NOVALUE;
    int _22174 = NOVALUE;
    int _22172 = NOVALUE;
    int _22171 = NOVALUE;
    int _22170 = NOVALUE;
    int _22169 = NOVALUE;
    int _22168 = NOVALUE;
    int _22167 = NOVALUE;
    int _22166 = NOVALUE;
    int _22165 = NOVALUE;
    int _22164 = NOVALUE;
    int _22163 = NOVALUE;
    int _22162 = NOVALUE;
    int _22161 = NOVALUE;
    int _22160 = NOVALUE;
    int _22159 = NOVALUE;
    int _22158 = NOVALUE;
    int _22157 = NOVALUE;
    int _22156 = NOVALUE;
    int _22155 = NOVALUE;
    int _22154 = NOVALUE;
    int _22153 = NOVALUE;
    int _22152 = NOVALUE;
    int _22151 = NOVALUE;
    int _22150 = NOVALUE;
    int _22148 = NOVALUE;
    int _22147 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_a_call_41373)) {
        _1 = (long)(DBL_PTR(_a_call_41373)->dbl);
        DeRefDS(_a_call_41373);
        _a_call_41373 = _1;
    }
    if (!IS_ATOM_INT(_mask_41374)) {
        _1 = (long)(DBL_PTR(_mask_41374)->dbl);
        DeRefDS(_mask_41374);
        _mask_41374 = _1;
    }
    if (!IS_ATOM_INT(_sub_41376)) {
        _1 = (long)(DBL_PTR(_sub_41376)->dbl);
        DeRefDS(_sub_41376);
        _sub_41376 = _1;
    }

    /** 	if a_call then*/
    if (_a_call_41373 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** 		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22147 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22147 = 1;
    }
    {
        int _i_41381;
        _i_41381 = 1;
L2: 
        if (_i_41381 > _22147){
            goto L3; // [19] 249
        }

        /** 			s = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22148 = (int)*(((s1_ptr)_2)->base + _i_41381);
        _2 = (int)SEQ_PTR(_22148);
        _s_41378 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_41378)){
            _s_41378 = (long)DBL_PTR(_s_41378)->dbl;
        }
        _22148 = NOVALUE;

        /** 			if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22150 = (int)*(((s1_ptr)_2)->base + _s_41378);
        _2 = (int)SEQ_PTR(_22150);
        _22151 = (int)*(((s1_ptr)_2)->base + 3);
        _22150 = NOVALUE;
        if (IS_ATOM_INT(_22151)) {
            _22152 = (_22151 == 1);
        }
        else {
            _22152 = binary_op(EQUALS, _22151, 1);
        }
        _22151 = NOVALUE;
        if (IS_ATOM_INT(_22152)) {
            if (_22152 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22152)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22154 = (int)*(((s1_ptr)_2)->base + _s_41378);
        _2 = (int)SEQ_PTR(_22154);
        _22155 = (int)*(((s1_ptr)_2)->base + 4);
        _22154 = NOVALUE;
        if (IS_ATOM_INT(_22155)) {
            _22156 = (_22155 == 6);
        }
        else {
            _22156 = binary_op(EQUALS, _22155, 6);
        }
        _22155 = NOVALUE;
        if (IS_ATOM_INT(_22156)) {
            if (_22156 != 0) {
                DeRef(_22157);
                _22157 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22156)->dbl != 0.0) {
                DeRef(_22157);
                _22157 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22158 = (int)*(((s1_ptr)_2)->base + _s_41378);
        _2 = (int)SEQ_PTR(_22158);
        _22159 = (int)*(((s1_ptr)_2)->base + 4);
        _22158 = NOVALUE;
        if (IS_ATOM_INT(_22159)) {
            _22160 = (_22159 == 5);
        }
        else {
            _22160 = binary_op(EQUALS, _22159, 5);
        }
        _22159 = NOVALUE;
        DeRef(_22157);
        if (IS_ATOM_INT(_22160))
        _22157 = (_22160 != 0);
        else
        _22157 = DBL_PTR(_22160)->dbl != 0.0;
L5: 
        if (_22157 != 0) {
            _22161 = 1;
            goto L6; // [108] 134
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22162 = (int)*(((s1_ptr)_2)->base + _s_41378);
        _2 = (int)SEQ_PTR(_22162);
        _22163 = (int)*(((s1_ptr)_2)->base + 4);
        _22162 = NOVALUE;
        if (IS_ATOM_INT(_22163)) {
            _22164 = (_22163 == 11);
        }
        else {
            _22164 = binary_op(EQUALS, _22163, 11);
        }
        _22163 = NOVALUE;
        if (IS_ATOM_INT(_22164))
        _22161 = (_22164 != 0);
        else
        _22161 = DBL_PTR(_22164)->dbl != 0.0;
L6: 
        if (_22161 != 0) {
            DeRef(_22165);
            _22165 = 1;
            goto L7; // [134] 160
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22166 = (int)*(((s1_ptr)_2)->base + _s_41378);
        _2 = (int)SEQ_PTR(_22166);
        _22167 = (int)*(((s1_ptr)_2)->base + 4);
        _22166 = NOVALUE;
        if (IS_ATOM_INT(_22167)) {
            _22168 = (_22167 == 13);
        }
        else {
            _22168 = binary_op(EQUALS, _22167, 13);
        }
        _22167 = NOVALUE;
        if (IS_ATOM_INT(_22168))
        _22165 = (_22168 != 0);
        else
        _22165 = DBL_PTR(_22168)->dbl != 0.0;
L7: 
        if (_22165 == 0)
        {
            _22165 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22165 = NOVALUE;
        }

        /** 				  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22169 = (_s_41378 % 29);
        _22170 = power(2, _22169);
        _22169 = NOVALUE;
        if (IS_ATOM_INT(_22170)) {
            {unsigned long tu;
                 tu = (unsigned long)_mask_41374 & (unsigned long)_22170;
                 _22171 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_41374;
            _22171 = Dand_bits(&temp_d, DBL_PTR(_22170));
        }
        DeRef(_22170);
        _22170 = NOVALUE;
        if (_22171 == 0) {
            DeRef(_22171);
            _22171 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22171) && DBL_PTR(_22171)->dbl == 0.0){
                DeRef(_22171);
                _22171 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22171);
            _22171 = NOVALUE;
        }
        DeRef(_22171);
        _22171 = NOVALUE;

        /** 					  if mask = E_ALL_EFFECT or s < sub then*/
        _22172 = (_mask_41374 == 1073741823);
        if (_22172 != 0) {
            goto L9; // [191] 204
        }
        _22174 = (_s_41378 < _sub_41376);
        if (_22174 == 0)
        {
            DeRef(_22174);
            _22174 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22174);
            _22174 = NOVALUE;
        }
L9: 

        /** 						  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _57BB_info_41326 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_41381 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -1073741824;
        ((int *)_2)[2] = 1073741823;
        _22177 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        *((int *)(_2+8)) = 0;
        Ref(_35NOVALUE_15823);
        *((int *)(_2+12)) = _35NOVALUE_15823;
        *((int *)(_2+16)) = _22177;
        _22178 = MAKE_SEQ(_1);
        _22177 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22178);
        DeRefDS(_22178);
        _22178 = NOVALUE;
LA: 
L8: 
L4: 

        /** 		end for*/
        _i_41381 = _i_41381 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** 		BB_info = {}*/
    RefDS(_21815);
    DeRef(_57BB_info_41326);
    _57BB_info_41326 = _21815;
LB: 

    /** end procedure*/
    DeRef(_22172);
    _22172 = NOVALUE;
    DeRef(_22152);
    _22152 = NOVALUE;
    DeRef(_22156);
    _22156 = NOVALUE;
    DeRef(_22160);
    _22160 = NOVALUE;
    DeRef(_22164);
    _22164 = NOVALUE;
    DeRef(_22168);
    _22168 = NOVALUE;
    DeRef(_22175);
    _22175 = NOVALUE;
    return;
    ;
}


int _57BB_var_obj(int _var_41446)
{
    int _bbi_41447 = NOVALUE;
    int _22189 = NOVALUE;
    int _22187 = NOVALUE;
    int _22185 = NOVALUE;
    int _22184 = NOVALUE;
    int _22182 = NOVALUE;
    int _22180 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41446)) {
        _1 = (long)(DBL_PTR(_var_41446)->dbl);
        DeRefDS(_var_41446);
        _var_41446 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22180 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22180 = 1;
    }
    {
        int _i_41449;
        _i_41449 = _22180;
L1: 
        if (_i_41449 < 1){
            goto L2; // [10] 99
        }

        /** 		bbi = BB_info[i]*/
        DeRef(_bbi_41447);
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _bbi_41447 = (int)*(((s1_ptr)_2)->base + _i_41449);
        Ref(_bbi_41447);

        /** 		if bbi[BB_VAR] != var then*/
        _2 = (int)SEQ_PTR(_bbi_41447);
        _22182 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22182, _var_41446)){
            _22182 = NOVALUE;
            goto L3; // [31] 40
        }
        _22182 = NOVALUE;

        /** 			continue*/
        goto L4; // [37] 94
L3: 

        /** 		if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22184 = (int)*(((s1_ptr)_2)->base + _var_41446);
        _2 = (int)SEQ_PTR(_22184);
        _22185 = (int)*(((s1_ptr)_2)->base + 3);
        _22184 = NOVALUE;
        if (binary_op_a(EQUALS, _22185, 1)){
            _22185 = NOVALUE;
            goto L5; // [56] 65
        }
        _22185 = NOVALUE;

        /** 			continue*/
        goto L4; // [62] 94
L5: 

        /** 		if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (int)SEQ_PTR(_bbi_41447);
        _22187 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22187, 1)){
            _22187 = NOVALUE;
            goto L6; // [73] 82
        }
        _22187 = NOVALUE;

        /** 			exit*/
        goto L2; // [79] 99
L6: 

        /** 		return bbi[BB_OBJ]*/
        _2 = (int)SEQ_PTR(_bbi_41447);
        _22189 = (int)*(((s1_ptr)_2)->base + 5);
        Ref(_22189);
        DeRef(_bbi_41447);
        return _22189;

        /** 	end for*/
L4: 
        _i_41449 = _i_41449 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** 	return BB_def_values*/
    RefDS(_57BB_def_values_41440);
    DeRef(_bbi_41447);
    _22189 = NOVALUE;
    return _57BB_def_values_41440;
    ;
}


int _57BB_var_type(int _var_41469)
{
    int _22204 = NOVALUE;
    int _22203 = NOVALUE;
    int _22201 = NOVALUE;
    int _22200 = NOVALUE;
    int _22199 = NOVALUE;
    int _22198 = NOVALUE;
    int _22197 = NOVALUE;
    int _22196 = NOVALUE;
    int _22195 = NOVALUE;
    int _22194 = NOVALUE;
    int _22193 = NOVALUE;
    int _22192 = NOVALUE;
    int _22191 = NOVALUE;
    int _22190 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41469)) {
        _1 = (long)(DBL_PTR(_var_41469)->dbl);
        DeRefDS(_var_41469);
        _var_41469 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22190 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22190 = 1;
    }
    {
        int _i_41471;
        _i_41471 = _22190;
L1: 
        if (_i_41471 < 1){
            goto L2; // [10] 125
        }

        /** 		if BB_info[i][BB_VAR] = var and*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22191 = (int)*(((s1_ptr)_2)->base + _i_41471);
        _2 = (int)SEQ_PTR(_22191);
        _22192 = (int)*(((s1_ptr)_2)->base + 1);
        _22191 = NOVALUE;
        if (IS_ATOM_INT(_22192)) {
            _22193 = (_22192 == _var_41469);
        }
        else {
            _22193 = binary_op(EQUALS, _22192, _var_41469);
        }
        _22192 = NOVALUE;
        if (IS_ATOM_INT(_22193)) {
            if (_22193 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22193)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22195 = (int)*(((s1_ptr)_2)->base + _i_41471);
        _2 = (int)SEQ_PTR(_22195);
        _22196 = (int)*(((s1_ptr)_2)->base + 1);
        _22195 = NOVALUE;
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!IS_ATOM_INT(_22196)){
            _22197 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22196)->dbl));
        }
        else{
            _22197 = (int)*(((s1_ptr)_2)->base + _22196);
        }
        _2 = (int)SEQ_PTR(_22197);
        _22198 = (int)*(((s1_ptr)_2)->base + 3);
        _22197 = NOVALUE;
        if (IS_ATOM_INT(_22198)) {
            _22199 = (_22198 == 1);
        }
        else {
            _22199 = binary_op(EQUALS, _22198, 1);
        }
        _22198 = NOVALUE;
        if (_22199 == 0) {
            DeRef(_22199);
            _22199 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22199) && DBL_PTR(_22199)->dbl == 0.0){
                DeRef(_22199);
                _22199 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22199);
            _22199 = NOVALUE;
        }
        DeRef(_22199);
        _22199 = NOVALUE;

        /** 			ifdef DEBUG then*/

        /** 			if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22200 = (int)*(((s1_ptr)_2)->base + _i_41471);
        _2 = (int)SEQ_PTR(_22200);
        _22201 = (int)*(((s1_ptr)_2)->base + 2);
        _22200 = NOVALUE;
        if (binary_op_a(NOTEQ, _22201, 0)){
            _22201 = NOVALUE;
            goto L4; // [85] 100
        }
        _22201 = NOVALUE;

        /** 				return TYPE_OBJECT*/
        _22196 = NOVALUE;
        DeRef(_22193);
        _22193 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** 				return BB_info[i][BB_TYPE]*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22203 = (int)*(((s1_ptr)_2)->base + _i_41471);
        _2 = (int)SEQ_PTR(_22203);
        _22204 = (int)*(((s1_ptr)_2)->base + 2);
        _22203 = NOVALUE;
        Ref(_22204);
        _22196 = NOVALUE;
        DeRef(_22193);
        _22193 = NOVALUE;
        return _22204;
L5: 
L3: 

        /** 	end for*/
        _i_41471 = _i_41471 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** 	return TYPE_OBJECT*/
    _22196 = NOVALUE;
    DeRef(_22193);
    _22193 = NOVALUE;
    _22204 = NOVALUE;
    return 16;
    ;
}


int _57GType(int _s_41499)
{
    int _t_41500 = NOVALUE;
    int _local_t_41501 = NOVALUE;
    int _22208 = NOVALUE;
    int _22207 = NOVALUE;
    int _22205 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41499)) {
        _1 = (long)(DBL_PTR(_s_41499)->dbl);
        DeRefDS(_s_41499);
        _s_41499 = _1;
    }

    /** 	t = SymTab[s][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22205 = (int)*(((s1_ptr)_2)->base + _s_41499);
    _2 = (int)SEQ_PTR(_22205);
    _t_41500 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_41500)){
        _t_41500 = (long)DBL_PTR(_t_41500)->dbl;
    }
    _22205 = NOVALUE;

    /** 	ifdef DEBUG then*/

    /** 	if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22207 = (int)*(((s1_ptr)_2)->base + _s_41499);
    _2 = (int)SEQ_PTR(_22207);
    _22208 = (int)*(((s1_ptr)_2)->base + 3);
    _22207 = NOVALUE;
    if (binary_op_a(EQUALS, _22208, 1)){
        _22208 = NOVALUE;
        goto L1; // [37] 48
    }
    _22208 = NOVALUE;

    /** 		return t*/
    return _t_41500;
L1: 

    /** 	local_t = BB_var_type(s)*/
    _local_t_41501 = _57BB_var_type(_s_41499);
    if (!IS_ATOM_INT(_local_t_41501)) {
        _1 = (long)(DBL_PTR(_local_t_41501)->dbl);
        DeRefDS(_local_t_41501);
        _local_t_41501 = _1;
    }

    /** 	if local_t = TYPE_OBJECT then*/
    if (_local_t_41501 != 16)
    goto L2; // [60] 71

    /** 		return t*/
    return _t_41500;
L2: 

    /** 	if t = TYPE_INTEGER then*/
    if (_t_41500 != 1)
    goto L3; // [75] 88

    /** 		return TYPE_INTEGER*/
    return 1;
L3: 

    /** 	return local_t*/
    return _local_t_41501;
    ;
}


int _57GDelete()
{
    int _0, _1, _2;
    

    /** 	return g_has_delete*/
    return _57g_has_delete_41521;
    ;
}


int _57HasDelete(int _s_41528)
{
    int _22223 = NOVALUE;
    int _22222 = NOVALUE;
    int _22220 = NOVALUE;
    int _22219 = NOVALUE;
    int _22218 = NOVALUE;
    int _22217 = NOVALUE;
    int _22215 = NOVALUE;
    int _22214 = NOVALUE;
    int _22213 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41528)) {
        _1 = (long)(DBL_PTR(_s_41528)->dbl);
        DeRefDS(_s_41528);
        _s_41528 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22213 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22213 = 1;
    }
    {
        int _i_41530;
        _i_41530 = _22213;
L1: 
        if (_i_41530 < 1){
            goto L2; // [10] 57
        }

        /** 		if BB_info[i][BB_VAR] = s then*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22214 = (int)*(((s1_ptr)_2)->base + _i_41530);
        _2 = (int)SEQ_PTR(_22214);
        _22215 = (int)*(((s1_ptr)_2)->base + 1);
        _22214 = NOVALUE;
        if (binary_op_a(NOTEQ, _22215, _s_41528)){
            _22215 = NOVALUE;
            goto L3; // [29] 50
        }
        _22215 = NOVALUE;

        /** 			return BB_info[i][BB_DELETE]*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22217 = (int)*(((s1_ptr)_2)->base + _i_41530);
        _2 = (int)SEQ_PTR(_22217);
        _22218 = (int)*(((s1_ptr)_2)->base + 6);
        _22217 = NOVALUE;
        Ref(_22218);
        return _22218;
L3: 

        /** 	end for*/
        _i_41530 = _i_41530 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22219 = (int)*(((s1_ptr)_2)->base + _s_41528);
    if (IS_SEQUENCE(_22219)){
            _22220 = SEQ_PTR(_22219)->length;
    }
    else {
        _22220 = 1;
    }
    _22219 = NOVALUE;
    if (_22220 >= 54)
    goto L4; // [70] 81

    /** 		return 0*/
    _22218 = NOVALUE;
    _22219 = NOVALUE;
    return 0;
L4: 

    /** 	return SymTab[s][S_HAS_DELETE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22222 = (int)*(((s1_ptr)_2)->base + _s_41528);
    _2 = (int)SEQ_PTR(_22222);
    _22223 = (int)*(((s1_ptr)_2)->base + 54);
    _22222 = NOVALUE;
    Ref(_22223);
    _22218 = NOVALUE;
    _22219 = NOVALUE;
    return _22223;
    ;
}


int _57ObjValue(int _s_41551)
{
    int _local_t_41552 = NOVALUE;
    int _st_41553 = NOVALUE;
    int _tmin_41554 = NOVALUE;
    int _tmax_41555 = NOVALUE;
    int _22236 = NOVALUE;
    int _22234 = NOVALUE;
    int _22233 = NOVALUE;
    int _22231 = NOVALUE;
    int _22228 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41551)) {
        _1 = (long)(DBL_PTR(_s_41551)->dbl);
        DeRefDS(_s_41551);
        _s_41551 = _1;
    }

    /** 	st = SymTab[s]*/
    DeRef(_st_41553);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _st_41553 = (int)*(((s1_ptr)_2)->base + _s_41551);
    Ref(_st_41553);

    /** 	tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_41554);
    _2 = (int)SEQ_PTR(_st_41553);
    _tmin_41554 = (int)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_41554);

    /** 	tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_41555);
    _2 = (int)SEQ_PTR(_st_41553);
    _tmax_41555 = (int)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_41555);

    /** 	if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_41554, _tmax_41555)){
        goto L1; // [29] 41
    }

    /** 		tmin = NOVALUE*/
    Ref(_35NOVALUE_15823);
    DeRef(_tmin_41554);
    _tmin_41554 = _35NOVALUE_15823;
L1: 

    /** 	if st[S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_st_41553);
    _22228 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22228, 1)){
        _22228 = NOVALUE;
        goto L2; // [51] 62
    }
    _22228 = NOVALUE;

    /** 		return tmin*/
    DeRef(_local_t_41552);
    DeRef(_st_41553);
    DeRef(_tmax_41555);
    return _tmin_41554;
L2: 

    /** 	local_t = BB_var_obj(s)*/
    _0 = _local_t_41552;
    _local_t_41552 = _57BB_var_obj(_s_41551);
    DeRef(_0);

    /** 	if local_t[MIN] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_local_t_41552);
    _22231 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22231, _35NOVALUE_15823)){
        _22231 = NOVALUE;
        goto L3; // [80] 91
    }
    _22231 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41552);
    DeRef(_st_41553);
    DeRef(_tmax_41555);
    return _tmin_41554;
L3: 

    /** 	if local_t[MIN] != local_t[MAX] then*/
    _2 = (int)SEQ_PTR(_local_t_41552);
    _22233 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_local_t_41552);
    _22234 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22233, _22234)){
        _22233 = NOVALUE;
        _22234 = NOVALUE;
        goto L4; // [105] 116
    }
    _22233 = NOVALUE;
    _22234 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41552);
    DeRef(_st_41553);
    DeRef(_tmax_41555);
    return _tmin_41554;
L4: 

    /** 	return local_t[MIN]*/
    _2 = (int)SEQ_PTR(_local_t_41552);
    _22236 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22236);
    DeRefDS(_local_t_41552);
    DeRef(_st_41553);
    DeRef(_tmin_41554);
    DeRef(_tmax_41555);
    return _22236;
    ;
}


int _57TypeIs(int _x_41586, int _typei_41587)
{
    int _22238 = NOVALUE;
    int _22237 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41586)) {
        _1 = (long)(DBL_PTR(_x_41586)->dbl);
        DeRefDS(_x_41586);
        _x_41586 = _1;
    }
    if (!IS_ATOM_INT(_typei_41587)) {
        _1 = (long)(DBL_PTR(_typei_41587)->dbl);
        DeRefDS(_typei_41587);
        _typei_41587 = _1;
    }

    /** 	return GType(x) = typei*/
    _22237 = _57GType(_x_41586);
    if (IS_ATOM_INT(_22237)) {
        _22238 = (_22237 == _typei_41587);
    }
    else {
        _22238 = binary_op(EQUALS, _22237, _typei_41587);
    }
    DeRef(_22237);
    _22237 = NOVALUE;
    return _22238;
    ;
}


int _57TypeIsIn(int _x_41592, int _types_41593)
{
    int _22240 = NOVALUE;
    int _22239 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41592)) {
        _1 = (long)(DBL_PTR(_x_41592)->dbl);
        DeRefDS(_x_41592);
        _x_41592 = _1;
    }

    /** 	return find(GType(x), types)*/
    _22239 = _57GType(_x_41592);
    _22240 = find_from(_22239, _types_41593, 1);
    DeRef(_22239);
    _22239 = NOVALUE;
    DeRefDS(_types_41593);
    return _22240;
    ;
}


int _57TypeIsNot(int _x_41598, int _typei_41599)
{
    int _22242 = NOVALUE;
    int _22241 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41598)) {
        _1 = (long)(DBL_PTR(_x_41598)->dbl);
        DeRefDS(_x_41598);
        _x_41598 = _1;
    }
    if (!IS_ATOM_INT(_typei_41599)) {
        _1 = (long)(DBL_PTR(_typei_41599)->dbl);
        DeRefDS(_typei_41599);
        _typei_41599 = _1;
    }

    /** 	return GType(x) != typei*/
    _22241 = _57GType(_x_41598);
    if (IS_ATOM_INT(_22241)) {
        _22242 = (_22241 != _typei_41599);
    }
    else {
        _22242 = binary_op(NOTEQ, _22241, _typei_41599);
    }
    DeRef(_22241);
    _22241 = NOVALUE;
    return _22242;
    ;
}


int _57TypeIsNotIn(int _x_41604, int _types_41605)
{
    int _22245 = NOVALUE;
    int _22244 = NOVALUE;
    int _22243 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41604)) {
        _1 = (long)(DBL_PTR(_x_41604)->dbl);
        DeRefDS(_x_41604);
        _x_41604 = _1;
    }

    /** 	return not find(GType(x), types)*/
    _22243 = _57GType(_x_41604);
    _22244 = find_from(_22243, _types_41605, 1);
    DeRef(_22243);
    _22243 = NOVALUE;
    _22245 = (_22244 == 0);
    _22244 = NOVALUE;
    DeRefDS(_types_41605);
    return _22245;
    ;
}


int _57or_type(int _t1_41611, int _t2_41612)
{
    int _22265 = NOVALUE;
    int _22264 = NOVALUE;
    int _22263 = NOVALUE;
    int _22262 = NOVALUE;
    int _22257 = NOVALUE;
    int _22255 = NOVALUE;
    int _22250 = NOVALUE;
    int _22248 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_41611)) {
        _1 = (long)(DBL_PTR(_t1_41611)->dbl);
        DeRefDS(_t1_41611);
        _t1_41611 = _1;
    }
    if (!IS_ATOM_INT(_t2_41612)) {
        _1 = (long)(DBL_PTR(_t2_41612)->dbl);
        DeRefDS(_t2_41612);
        _t2_41612 = _1;
    }

    /** 	if t1 = TYPE_NULL then*/
    if (_t1_41611 != 0)
    goto L1; // [9] 22

    /** 		return t2*/
    return _t2_41612;
    goto L2; // [19] 307
L1: 

    /** 	elsif t2 = TYPE_NULL then*/
    if (_t2_41612 != 0)
    goto L3; // [26] 39

    /** 		return t1*/
    return _t1_41611;
    goto L2; // [36] 307
L3: 

    /** 	elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22248 = (_t1_41611 == 16);
    if (_22248 != 0) {
        goto L4; // [47] 62
    }
    _22250 = (_t2_41612 == 16);
    if (_22250 == 0)
    {
        DeRef(_22250);
        _22250 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22250);
        _22250 = NOVALUE;
    }
L4: 

    /** 		return TYPE_OBJECT*/
    DeRef(_22248);
    _22248 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** 	elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_41611 != 8)
    goto L6; // [77] 112

    /** 		if t2 = TYPE_SEQUENCE then*/
    if (_t2_41612 != 8)
    goto L7; // [85] 100

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22248);
    _22248 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22248);
    _22248 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** 	elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_41612 != 8)
    goto L8; // [116] 151

    /** 		if t1 = TYPE_SEQUENCE then*/
    if (_t1_41611 != 8)
    goto L9; // [124] 139

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22248);
    _22248 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22248);
    _22248 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** 	elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22255 = (_t1_41611 == 4);
    if (_22255 != 0) {
        goto LA; // [159] 174
    }
    _22257 = (_t2_41612 == 4);
    if (_22257 == 0)
    {
        DeRef(_22257);
        _22257 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22257);
        _22257 = NOVALUE;
    }
LA: 

    /** 		return TYPE_ATOM*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** 	elsif t1 = TYPE_DOUBLE then*/
    if (_t1_41611 != 2)
    goto LC; // [189] 224

    /** 		if t2 = TYPE_INTEGER then*/
    if (_t2_41612 != 1)
    goto LD; // [197] 212

    /** 			return TYPE_ATOM*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** 	elsif t2 = TYPE_DOUBLE then*/
    if (_t2_41612 != 2)
    goto LE; // [228] 263

    /** 		if t1 = TYPE_INTEGER then*/
    if (_t1_41611 != 1)
    goto LF; // [236] 251

    /** 			return TYPE_ATOM*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** 	elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22262 = (_t1_41611 == 1);
    if (_22262 == 0) {
        goto L10; // [271] 296
    }
    _22264 = (_t2_41612 == 1);
    if (_22264 == 0)
    {
        DeRef(_22264);
        _22264 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22264);
        _22264 = NOVALUE;
    }

    /** 		return TYPE_INTEGER*/
    DeRef(_22248);
    _22248 = NOVALUE;
    DeRef(_22255);
    _22255 = NOVALUE;
    DeRef(_22262);
    _22262 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** 		InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _t1_41611;
    ((int *)_2)[2] = _t2_41612;
    _22265 = MAKE_SEQ(_1);
    _44InternalErr(258, _22265);
    _22265 = NOVALUE;
L2: 
    ;
}


void _57RemoveFromBB(int _s_41682)
{
    int _int_41683 = NOVALUE;
    int _22267 = NOVALUE;
    int _22266 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41682)) {
        _1 = (long)(DBL_PTR(_s_41682)->dbl);
        DeRefDS(_s_41682);
        _s_41682 = _1;
    }

    /** 	for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22266 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22266 = 1;
    }
    {
        int _i_41685;
        _i_41685 = 1;
L1: 
        if (_i_41685 > _22266){
            goto L2; // [10] 59
        }

        /** 		int = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_57BB_info_41326);
        _22267 = (int)*(((s1_ptr)_2)->base + _i_41685);
        _2 = (int)SEQ_PTR(_22267);
        _int_41683 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_41683)){
            _int_41683 = (long)DBL_PTR(_int_41683)->dbl;
        }
        _22267 = NOVALUE;

        /** 		if int = s then*/
        if (_int_41683 != _s_41682)
        goto L3; // [33] 52

        /** 			BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_57BB_info_41326);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_41683)) ? _int_41683 : (long)(DBL_PTR(_int_41683)->dbl);
            int stop = (IS_ATOM_INT(_int_41683)) ? _int_41683 : (long)(DBL_PTR(_int_41683)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_57BB_info_41326), start, &_57BB_info_41326 );
                }
                else Tail(SEQ_PTR(_57BB_info_41326), stop+1, &_57BB_info_41326);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_57BB_info_41326), start, &_57BB_info_41326);
            }
            else {
                assign_slice_seq = &assign_space;
                _57BB_info_41326 = Remove_elements(start, stop, (SEQ_PTR(_57BB_info_41326)->ref == 1));
            }
        }

        /** 			return*/
        return;
L3: 

        /** 	end for*/
        _i_41685 = _i_41685 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _57SetBBType(int _s_41703, int _t_41704, int _val_41705, int _etype_41706, int _has_delete_41707)
{
    int _found_41708 = NOVALUE;
    int _i_41709 = NOVALUE;
    int _tn_41710 = NOVALUE;
    int _int_41711 = NOVALUE;
    int _sym_41712 = NOVALUE;
    int _mode_41717 = NOVALUE;
    int _gtype_41732 = NOVALUE;
    int _new_type_41769 = NOVALUE;
    int _bbsym_41792 = NOVALUE;
    int _bbi_41928 = NOVALUE;
    int _22386 = NOVALUE;
    int _22385 = NOVALUE;
    int _22384 = NOVALUE;
    int _22382 = NOVALUE;
    int _22381 = NOVALUE;
    int _22380 = NOVALUE;
    int _22378 = NOVALUE;
    int _22377 = NOVALUE;
    int _22375 = NOVALUE;
    int _22373 = NOVALUE;
    int _22372 = NOVALUE;
    int _22370 = NOVALUE;
    int _22368 = NOVALUE;
    int _22367 = NOVALUE;
    int _22366 = NOVALUE;
    int _22365 = NOVALUE;
    int _22364 = NOVALUE;
    int _22363 = NOVALUE;
    int _22362 = NOVALUE;
    int _22361 = NOVALUE;
    int _22360 = NOVALUE;
    int _22357 = NOVALUE;
    int _22353 = NOVALUE;
    int _22348 = NOVALUE;
    int _22346 = NOVALUE;
    int _22345 = NOVALUE;
    int _22344 = NOVALUE;
    int _22342 = NOVALUE;
    int _22340 = NOVALUE;
    int _22339 = NOVALUE;
    int _22338 = NOVALUE;
    int _22336 = NOVALUE;
    int _22335 = NOVALUE;
    int _22333 = NOVALUE;
    int _22332 = NOVALUE;
    int _22331 = NOVALUE;
    int _22329 = NOVALUE;
    int _22328 = NOVALUE;
    int _22325 = NOVALUE;
    int _22324 = NOVALUE;
    int _22323 = NOVALUE;
    int _22321 = NOVALUE;
    int _22319 = NOVALUE;
    int _22318 = NOVALUE;
    int _22316 = NOVALUE;
    int _22315 = NOVALUE;
    int _22314 = NOVALUE;
    int _22312 = NOVALUE;
    int _22311 = NOVALUE;
    int _22300 = NOVALUE;
    int _22298 = NOVALUE;
    int _22295 = NOVALUE;
    int _22294 = NOVALUE;
    int _22291 = NOVALUE;
    int _22290 = NOVALUE;
    int _22289 = NOVALUE;
    int _22287 = NOVALUE;
    int _22286 = NOVALUE;
    int _22285 = NOVALUE;
    int _22283 = NOVALUE;
    int _22282 = NOVALUE;
    int _22280 = NOVALUE;
    int _22277 = NOVALUE;
    int _22275 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_41703)) {
        _1 = (long)(DBL_PTR(_s_41703)->dbl);
        DeRefDS(_s_41703);
        _s_41703 = _1;
    }
    if (!IS_ATOM_INT(_t_41704)) {
        _1 = (long)(DBL_PTR(_t_41704)->dbl);
        DeRefDS(_t_41704);
        _t_41704 = _1;
    }
    if (!IS_ATOM_INT(_etype_41706)) {
        _1 = (long)(DBL_PTR(_etype_41706)->dbl);
        DeRefDS(_etype_41706);
        _etype_41706 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_41707)) {
        _1 = (long)(DBL_PTR(_has_delete_41707)->dbl);
        DeRefDS(_has_delete_41707);
        _has_delete_41707 = _1;
    }

    /** 	if has_delete then*/
    if (_has_delete_41707 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** 		p_has_delete = 1*/
    _57p_has_delete_41522 = 1;

    /** 		g_has_delete = 1*/
    _57g_has_delete_41521 = 1;
L1: 

    /** 	sym = SymTab[s]*/
    DeRef(_sym_41712);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _sym_41712 = (int)*(((s1_ptr)_2)->base + _s_41703);
    Ref(_sym_41712);

    /** 	SymTab[s] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_41703);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	integer mode = sym[S_MODE]*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _mode_41717 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_41717))
    _mode_41717 = (long)DBL_PTR(_mode_41717)->dbl;

    /** 	if mode = M_NORMAL or mode = M_TEMP  then*/
    _22275 = (_mode_41717 == 1);
    if (_22275 != 0) {
        goto L2; // [61] 76
    }
    _22277 = (_mode_41717 == 3);
    if (_22277 == 0)
    {
        DeRef(_22277);
        _22277 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22277);
        _22277 = NOVALUE;
    }
L2: 

    /** 		found = FALSE*/
    _found_41708 = _13FALSE_435;

    /** 		if mode = M_TEMP then*/
    if (_mode_41717 != 3)
    goto L4; // [89] 465

    /** 			sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41704;
    DeRef(_1);

    /** 			sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41706;
    DeRef(_1);

    /** 			integer gtype = sym[S_GTYPE]*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _gtype_41732 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_41732))
    _gtype_41732 = (long)DBL_PTR(_gtype_41732)->dbl;

    /** 			if gtype = TYPE_OBJECT*/
    _22280 = (_gtype_41732 == 16);
    if (_22280 != 0) {
        goto L5; // [125] 140
    }
    _22282 = (_gtype_41732 == 8);
    if (_22282 == 0)
    {
        DeRef(_22282);
        _22282 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22282);
        _22282 = NOVALUE;
    }
L5: 

    /** 				if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22283 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22283, 0)){
        _22283 = NOVALUE;
        goto L7; // [148] 165
    }
    _22283 = NOVALUE;

    /** 					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** 					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22285 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22285);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22285;
    if( _1 != _22285 ){
        DeRef(_1);
    }
    _22285 = NOVALUE;
L8: 

    /** 				sym[S_OBJ] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 				sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** 				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22286 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22286);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22286;
    if( _1 != _22286 ){
        DeRef(_1);
    }
    _22286 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22287 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22287);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22287;
    if( _1 != _22287 ){
        DeRef(_1);
    }
    _22287 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
L9: 

    /** 			if not Initializing then*/
    if (_35Initializing_16048 != 0)
    goto LA; // [256] 326

    /** 				integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22289 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_35temp_name_type_16050);
    if (!IS_ATOM_INT(_22289)){
        _22290 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22289)->dbl));
    }
    else{
        _22290 = (int)*(((s1_ptr)_2)->base + _22289);
    }
    _2 = (int)SEQ_PTR(_22290);
    _22291 = (int)*(((s1_ptr)_2)->base + 2);
    _22290 = NOVALUE;
    Ref(_22291);
    _new_type_41769 = _57or_type(_22291, _t_41704);
    _22291 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_41769)) {
        _1 = (long)(DBL_PTR(_new_type_41769)->dbl);
        DeRefDS(_new_type_41769);
        _new_type_41769 = _1;
    }

    /** 				if new_type = TYPE_NULL then*/
    if (_new_type_41769 != 0)
    goto LB; // [290] 304

    /** 					new_type = TYPE_OBJECT*/
    _new_type_41769 = 16;
LB: 

    /** 				temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22294 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_35temp_name_type_16050);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35temp_name_type_16050 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22294))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_22294)->dbl));
    else
    _3 = (int)(_22294 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_type_41769;
    DeRef(_1);
    _22295 = NOVALUE;
LA: 

    /** 			tn = sym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _tn_41710 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_41710))
    _tn_41710 = (long)DBL_PTR(_tn_41710)->dbl;

    /** 			i = 1*/
    _i_41709 = 1;

    /** 			while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22298 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22298 = 1;
    }
    if (_i_41709 > _22298)
    goto LD; // [351] 460

    /** 				sequence bbsym*/

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    _22300 = (int)*(((s1_ptr)_2)->base + _i_41709);
    _2 = (int)SEQ_PTR(_22300);
    _int_41711 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_41711)){
        _int_41711 = (long)DBL_PTR(_int_41711)->dbl;
    }
    _22300 = NOVALUE;

    /** 				if int = s then*/
    if (_int_41711 != _s_41703)
    goto LE; // [373] 387

    /** 					bbsym = sym*/
    RefDS(_sym_41712);
    DeRef(_bbsym_41792);
    _bbsym_41792 = _sym_41712;
    goto LF; // [384] 398
LE: 

    /** 					bbsym = SymTab[int]*/
    DeRef(_bbsym_41792);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _bbsym_41792 = (int)*(((s1_ptr)_2)->base + _int_41711);
    Ref(_bbsym_41792);
LF: 

    /** 				int = bbsym[S_MODE]*/
    _2 = (int)SEQ_PTR(_bbsym_41792);
    _int_41711 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_41711))
    _int_41711 = (long)DBL_PTR(_int_41711)->dbl;

    /** 				if int = M_TEMP then*/
    if (_int_41711 != 3)
    goto L10; // [412] 447

    /** 					int = bbsym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_bbsym_41792);
    _int_41711 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_41711))
    _int_41711 = (long)DBL_PTR(_int_41711)->dbl;

    /** 					if int = tn then*/
    if (_int_41711 != _tn_41710)
    goto L11; // [426] 446

    /** 						found = TRUE*/
    _found_41708 = _13TRUE_437;

    /** 						exit*/
    DeRefDS(_bbsym_41792);
    _bbsym_41792 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** 				i += 1*/
    _i_41709 = _i_41709 + 1;
    DeRef(_bbsym_41792);
    _bbsym_41792 = NOVALUE;

    /** 			end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** 			if t != TYPE_NULL then*/
    if (_t_41704 == 0)
    goto L13; // [469] 824

    /** 				if not Initializing then*/
    if (_35Initializing_16048 != 0)
    goto L14; // [477] 500

    /** 					sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22311 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22311);
    _22312 = _57or_type(_22311, _t_41704);
    _22311 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _22312;
    if( _1 != _22312 ){
        DeRef(_1);
    }
    _22312 = NOVALUE;
L14: 

    /** 				if t = TYPE_SEQUENCE then*/
    if (_t_41704 != 8)
    goto L15; // [504] 633

    /** 					sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22314 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22314);
    _22315 = _57or_type(_22314, _etype_41706);
    _22314 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22315;
    if( _1 != _22315 ){
        DeRef(_1);
    }
    _22315 = NOVALUE;

    /** 					if val[MIN] != -1 then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22316 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22316, -1)){
        _22316 = NOVALUE;
        goto L16; // [535] 823
    }
    _22316 = NOVALUE;

    /** 						if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22318 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22319 = (int)NewDouble((double)-0xC0000000);
        else
        _22319 = - _35NOVALUE_15823;
    }
    else {
        _22319 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (binary_op_a(NOTEQ, _22318, _22319)){
        _22318 = NOVALUE;
        DeRef(_22319);
        _22319 = NOVALUE;
        goto L17; // [552] 599
    }
    _22318 = NOVALUE;
    DeRef(_22319);
    _22319 = NOVALUE;

    /** 							if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22321 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22321, 0)){
        _22321 = NOVALUE;
        goto L18; // [564] 581
    }
    _22321 = NOVALUE;

    /** 								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** 								sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22323 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22323);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22323;
    if( _1 != _22323 ){
        DeRef(_1);
    }
    _22323 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** 						elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22324 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_41712);
    _22325 = (int)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22324, _22325)){
        _22324 = NOVALUE;
        _22325 = NOVALUE;
        goto L16; // [613] 823
    }
    _22324 = NOVALUE;
    _22325 = NOVALUE;

    /** 							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** 				elsif t = TYPE_INTEGER then*/
    if (_t_41704 != 1)
    goto L19; // [637] 774

    /** 					if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22328 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22329 = (int)NewDouble((double)-0xC0000000);
        else
        _22329 = - _35NOVALUE_15823;
    }
    else {
        _22329 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (binary_op_a(NOTEQ, _22328, _22329)){
        _22328 = NOVALUE;
        DeRef(_22329);
        _22329 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22328 = NOVALUE;
    DeRef(_22329);
    _22329 = NOVALUE;

    /** 						sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22331 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22331);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22331;
    if( _1 != _22331 ){
        DeRef(_1);
    }
    _22331 = NOVALUE;

    /** 						sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22332 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22332);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22332;
    if( _1 != _22332 ){
        DeRef(_1);
    }
    _22332 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** 					elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22333 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22333, _35NOVALUE_15823)){
        _22333 = NOVALUE;
        goto L16; // [699] 823
    }
    _22333 = NOVALUE;

    /** 						if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22335 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_41712);
    _22336 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22335, _22336)){
        _22335 = NOVALUE;
        _22336 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22335 = NOVALUE;
    _22336 = NOVALUE;

    /** 							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22338 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22338);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22338;
    if( _1 != _22338 ){
        DeRef(_1);
    }
    _22338 = NOVALUE;
L1B: 

    /** 						if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22339 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_sym_41712);
    _22340 = (int)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22339, _22340)){
        _22339 = NOVALUE;
        _22340 = NOVALUE;
        goto L16; // [750] 823
    }
    _22339 = NOVALUE;
    _22340 = NOVALUE;

    /** 							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22342 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22342);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22342;
    if( _1 != _22342 ){
        DeRef(_1);
    }
    _22342 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** 					sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);

    /** 					if t = TYPE_OBJECT then*/
    if (_t_41704 != 16)
    goto L1C; // [788] 822

    /** 						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22344 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22344);
    _22345 = _57or_type(_22344, _etype_41706);
    _22344 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22345;
    if( _1 != _22345 ){
        DeRef(_1);
    }
    _22345 = NOVALUE;

    /** 						sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** 			i = 1*/
    _i_41709 = 1;

    /** 			while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_57BB_info_41326)){
            _22346 = SEQ_PTR(_57BB_info_41326)->length;
    }
    else {
        _22346 = 1;
    }
    if (_i_41709 > _22346)
    goto L1E; // [839] 888

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    _22348 = (int)*(((s1_ptr)_2)->base + _i_41709);
    _2 = (int)SEQ_PTR(_22348);
    _int_41711 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_41711)){
        _int_41711 = (long)DBL_PTR(_int_41711)->dbl;
    }
    _22348 = NOVALUE;

    /** 				if int = s then*/
    if (_int_41711 != _s_41703)
    goto L1F; // [859] 877

    /** 					found = TRUE*/
    _found_41708 = _13TRUE_437;

    /** 					exit*/
    goto L1E; // [874] 888
L1F: 

    /** 				i += 1*/
    _i_41709 = _i_41709 + 1;

    /** 			end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** 		if not found then*/
    if (_found_41708 != 0)
    goto L20; // [891] 907

    /** 			BB_info = append(BB_info, repeat(0, 6))*/
    _22353 = Repeat(0, 6);
    RefDS(_22353);
    Append(&_57BB_info_41326, _57BB_info_41326, _22353);
    DeRefDS(_22353);
    _22353 = NOVALUE;
L20: 

    /** 		if t = TYPE_NULL then*/
    if (_t_41704 != 0)
    goto L21; // [911] 949

    /** 			if not found then*/
    if (_found_41708 != 0)
    goto L22; // [917] 1308

    /** 				BB_info[i] = dummy_bb*/
    RefDS(_57dummy_bb_41692);
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41326 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41709);
    _1 = *(int *)_2;
    *(int *)_2 = _57dummy_bb_41692;
    DeRef(_1);

    /** 				BB_info[i][BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41326 = MAKE_SEQ(_2);
    }
    _3 = (int)(_i_41709 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_41703;
    DeRef(_1);
    _22357 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** 			sequence bbi = BB_info[i]*/
    DeRef(_bbi_41928);
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    _bbi_41928 = (int)*(((s1_ptr)_2)->base + _i_41709);
    Ref(_bbi_41928);

    /** 			BB_info[i] = 0*/
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41326 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41709);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			bbi[BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_41703;
    DeRef(_1);

    /** 			bbi[BB_TYPE] = t*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41704;
    DeRef(_1);

    /** 			bbi[BB_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_41707;
    DeRef(_1);

    /** 			if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22360 = (_t_41704 == 8);
    if (_22360 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (int)SEQ_PTR(_val_41705);
    _22362 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22362)) {
        _22363 = (_22362 == -1);
    }
    else {
        _22363 = binary_op(EQUALS, _22362, -1);
    }
    _22362 = NOVALUE;
    if (_22363 == 0) {
        DeRef(_22363);
        _22363 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22363) && DBL_PTR(_22363)->dbl == 0.0){
            DeRef(_22363);
            _22363 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22363);
        _22363 = NOVALUE;
    }
    DeRef(_22363);
    _22363 = NOVALUE;

    /** 				if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_41708 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (int)SEQ_PTR(_bbi_41928);
    _22365 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22365)) {
        _22366 = (_22365 != 0);
    }
    else {
        _22366 = binary_op(NOTEQ, _22365, 0);
    }
    _22365 = NOVALUE;
    if (_22366 == 0) {
        DeRef(_22366);
        _22366 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22366) && DBL_PTR(_22366)->dbl == 0.0){
            DeRef(_22366);
            _22366 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22366);
        _22366 = NOVALUE;
    }
    DeRef(_22366);
    _22366 = NOVALUE;

    /** 					bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    _22367 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_22367);
    _22368 = _57or_type(_22367, _etype_41706);
    _22367 = NOVALUE;
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _22368;
    if( _1 != _22368 ){
        DeRef(_1);
    }
    _22368 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** 					bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
L25: 

    /** 				if not found then*/
    if (_found_41708 != 0)
    goto L26; // [1062] 1153

    /** 					bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** 				bbi[BB_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41706;
    DeRef(_1);

    /** 				if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22370 = (_t_41704 == 8);
    if (_22370 != 0) {
        goto L27; // [1091] 1106
    }
    _22372 = (_t_41704 == 16);
    if (_22372 == 0)
    {
        DeRef(_22372);
        _22372 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22372);
        _22372 = NOVALUE;
    }
L27: 

    /** 					if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22373 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22373, 0)){
        _22373 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22373 = NOVALUE;

    /** 						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** 						bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22375 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22375);
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _22375;
    if( _1 != _22375 ){
        DeRef(_1);
    }
    _22375 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** 					bbi[BB_OBJ] = val*/
    RefDS(_val_41705);
    _2 = (int)SEQ_PTR(_bbi_41928);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41928 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _val_41705;
    DeRef(_1);
L2A: 
L26: 

    /** 			BB_info[i] = bbi*/
    RefDS(_bbi_41928);
    _2 = (int)SEQ_PTR(_57BB_info_41326);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57BB_info_41326 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41709);
    _1 = *(int *)_2;
    *(int *)_2 = _bbi_41928;
    DeRef(_1);
    DeRefDS(_bbi_41928);
    _bbi_41928 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_41717 != 2)
    goto L2B; // [1171] 1307

    /** 		sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41704;
    DeRef(_1);

    /** 		sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41706;
    DeRef(_1);

    /** 		if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (int)SEQ_PTR(_sym_41712);
    _22377 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22377)) {
        _22378 = (_22377 == 8);
    }
    else {
        _22378 = binary_op(EQUALS, _22377, 8);
    }
    _22377 = NOVALUE;
    if (IS_ATOM_INT(_22378)) {
        if (_22378 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22378)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (int)SEQ_PTR(_sym_41712);
    _22380 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22380)) {
        _22381 = (_22380 == 16);
    }
    else {
        _22381 = binary_op(EQUALS, _22380, 16);
    }
    _22380 = NOVALUE;
    if (_22381 == 0) {
        DeRef(_22381);
        _22381 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22381) && DBL_PTR(_22381)->dbl == 0.0){
            DeRef(_22381);
            _22381 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22381);
        _22381 = NOVALUE;
    }
    DeRef(_22381);
    _22381 = NOVALUE;
L2C: 

    /** 			if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22382 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22382, 0)){
        _22382 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22382 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** 				sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22384 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22384);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22384;
    if( _1 != _22384 ){
        DeRef(_1);
    }
    _22384 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** 			sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22385 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22385);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22385;
    if( _1 != _22385 ){
        DeRef(_1);
    }
    _22385 = NOVALUE;

    /** 			sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41705);
    _22386 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22386);
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22386;
    if( _1 != _22386 ){
        DeRef(_1);
    }
    _22386 = NOVALUE;
L2F: 

    /** 		sym[S_HAS_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_sym_41712);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41712 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_41707;
    DeRef(_1);
L2B: 
L22: 

    /** 	SymTab[s] = sym*/
    RefDS(_sym_41712);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_41703);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_41712;
    DeRef(_1);

    /** end procedure*/
    DeRefDS(_val_41705);
    DeRefDS(_sym_41712);
    DeRef(_22275);
    _22275 = NOVALUE;
    DeRef(_22280);
    _22280 = NOVALUE;
    _22289 = NOVALUE;
    _22294 = NOVALUE;
    DeRef(_22360);
    _22360 = NOVALUE;
    DeRef(_22370);
    _22370 = NOVALUE;
    DeRef(_22378);
    _22378 = NOVALUE;
    return;
    ;
}


void _57CName(int _s_42002)
{
    int _v_42003 = NOVALUE;
    int _mode_42005 = NOVALUE;
    int _22447 = NOVALUE;
    int _22446 = NOVALUE;
    int _22445 = NOVALUE;
    int _22444 = NOVALUE;
    int _22443 = NOVALUE;
    int _22442 = NOVALUE;
    int _22441 = NOVALUE;
    int _22440 = NOVALUE;
    int _22439 = NOVALUE;
    int _22438 = NOVALUE;
    int _22436 = NOVALUE;
    int _22434 = NOVALUE;
    int _22433 = NOVALUE;
    int _22432 = NOVALUE;
    int _22431 = NOVALUE;
    int _22430 = NOVALUE;
    int _22429 = NOVALUE;
    int _22428 = NOVALUE;
    int _22427 = NOVALUE;
    int _22426 = NOVALUE;
    int _22425 = NOVALUE;
    int _22424 = NOVALUE;
    int _22422 = NOVALUE;
    int _22421 = NOVALUE;
    int _22420 = NOVALUE;
    int _22419 = NOVALUE;
    int _22418 = NOVALUE;
    int _22417 = NOVALUE;
    int _22415 = NOVALUE;
    int _22414 = NOVALUE;
    int _22412 = NOVALUE;
    int _22411 = NOVALUE;
    int _22410 = NOVALUE;
    int _22409 = NOVALUE;
    int _22408 = NOVALUE;
    int _22407 = NOVALUE;
    int _22406 = NOVALUE;
    int _22405 = NOVALUE;
    int _22404 = NOVALUE;
    int _22403 = NOVALUE;
    int _22402 = NOVALUE;
    int _22401 = NOVALUE;
    int _22399 = NOVALUE;
    int _22398 = NOVALUE;
    int _22396 = NOVALUE;
    int _22395 = NOVALUE;
    int _22394 = NOVALUE;
    int _22393 = NOVALUE;
    int _22392 = NOVALUE;
    int _22391 = NOVALUE;
    int _22388 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42002)) {
        _1 = (long)(DBL_PTR(_s_42002)->dbl);
        DeRefDS(_s_42002);
        _s_42002 = _1;
    }

    /** 	v = ObjValue(s)*/
    _0 = _v_42003;
    _v_42003 = _57ObjValue(_s_42002);
    DeRef(_0);

    /** 	integer mode = SymTab[s][S_MODE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22388 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22388);
    _mode_42005 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42005)){
        _mode_42005 = (long)DBL_PTR(_mode_42005)->dbl;
    }
    _22388 = NOVALUE;

    /**  	if mode = M_NORMAL then*/
    if (_mode_42005 != 1)
    goto L1; // [29] 240

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22391 = (_57LeftSym_41327 == _13FALSE_435);
    if (_22391 == 0) {
        _22392 = 0;
        goto L2; // [43] 61
    }
    _22393 = _57GType(_s_42002);
    if (IS_ATOM_INT(_22393)) {
        _22394 = (_22393 == 1);
    }
    else {
        _22394 = binary_op(EQUALS, _22393, 1);
    }
    DeRef(_22393);
    _22393 = NOVALUE;
    if (IS_ATOM_INT(_22394))
    _22392 = (_22394 != 0);
    else
    _22392 = DBL_PTR(_22394)->dbl != 0.0;
L2: 
    if (_22392 == 0) {
        goto L3; // [61] 84
    }
    if (IS_ATOM_INT(_v_42003) && IS_ATOM_INT(_35NOVALUE_15823)) {
        _22396 = (_v_42003 != _35NOVALUE_15823);
    }
    else {
        _22396 = binary_op(NOTEQ, _v_42003, _35NOVALUE_15823);
    }
    if (_22396 == 0) {
        DeRef(_22396);
        _22396 = NOVALUE;
        goto L3; // [72] 84
    }
    else {
        if (!IS_ATOM_INT(_22396) && DBL_PTR(_22396)->dbl == 0.0){
            DeRef(_22396);
            _22396 = NOVALUE;
            goto L3; // [72] 84
        }
        DeRef(_22396);
        _22396 = NOVALUE;
    }
    DeRef(_22396);
    _22396 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22397);
    Ref(_v_42003);
    _54c_printf(_22397, _v_42003);
    goto L4; // [81] 166
L3: 

    /** 			if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22398 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22398);
    _22399 = (int)*(((s1_ptr)_2)->base + 4);
    _22398 = NOVALUE;
    if (binary_op_a(LESSEQ, _22399, 3)){
        _22399 = NOVALUE;
        goto L5; // [100] 142
    }
    _22399 = NOVALUE;

    /** 				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22401 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22401);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22402 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22402 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22401 = NOVALUE;
    RefDS(_21908);
    Ref(_22402);
    _54c_printf(_21908, _22402);
    _22402 = NOVALUE;

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22403 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22403);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22404 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22404 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22403 = NOVALUE;
    Ref(_22404);
    _54c_puts(_22404);
    _22404 = NOVALUE;
    goto L6; // [139] 165
L5: 

    /** 				c_puts("_")*/
    RefDS(_21887);
    _54c_puts(_21887);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22405 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22405);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22406 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22406 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22405 = NOVALUE;
    Ref(_22406);
    _54c_puts(_22406);
    _22406 = NOVALUE;
L6: 
L4: 

    /** 		if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22407 = (_s_42002 != _35CurrentSub_15976);
    if (_22407 == 0) {
        goto L7; // [174] 222
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22409 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22409);
    _22410 = (int)*(((s1_ptr)_2)->base + 12);
    _22409 = NOVALUE;
    if (IS_ATOM_INT(_22410)) {
        _22411 = (_22410 < 2);
    }
    else {
        _22411 = binary_op(LESS, _22410, 2);
    }
    _22410 = NOVALUE;
    if (_22411 == 0) {
        DeRef(_22411);
        _22411 = NOVALUE;
        goto L7; // [195] 222
    }
    else {
        if (!IS_ATOM_INT(_22411) && DBL_PTR(_22411)->dbl == 0.0){
            DeRef(_22411);
            _22411 = NOVALUE;
            goto L7; // [195] 222
        }
        DeRef(_22411);
        _22411 = NOVALUE;
    }
    DeRef(_22411);
    _22411 = NOVALUE;

    /** 			SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42002 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22414 = (int)*(((s1_ptr)_2)->base + 12);
    _22412 = NOVALUE;
    if (IS_ATOM_INT(_22414)) {
        _22415 = _22414 + 1;
        if (_22415 > MAXINT){
            _22415 = NewDouble((double)_22415);
        }
    }
    else
    _22415 = binary_op(PLUS, 1, _22414);
    _22414 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22415;
    if( _1 != _22415 ){
        DeRef(_1);
    }
    _22415 = NOVALUE;
    _22412 = NOVALUE;
L7: 

    /** 		SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_54novalue_45126);
    _57SetBBType(_s_42002, 0, _54novalue_45126, 16, 0);
    goto L8; // [237] 490
L1: 

    /**  	elsif mode = M_CONSTANT then*/
    if (_mode_42005 != 2)
    goto L9; // [244] 419

    /** 		if (integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22417 = _53sym_obj(_s_42002);
    if (IS_ATOM_INT(_22417))
    _22418 = 1;
    else if (IS_ATOM_DBL(_22417))
    _22418 = IS_ATOM_INT(DoubleToInt(_22417));
    else
    _22418 = 0;
    DeRef(_22417);
    _22417 = NOVALUE;
    if (_22418 == 0) {
        _22419 = 0;
        goto LA; // [257] 283
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22420 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22420);
    _22421 = (int)*(((s1_ptr)_2)->base + 36);
    _22420 = NOVALUE;
    if (IS_ATOM_INT(_22421)) {
        _22422 = (_22421 != 2);
    }
    else {
        _22422 = binary_op(NOTEQ, _22421, 2);
    }
    _22421 = NOVALUE;
    if (IS_ATOM_INT(_22422))
    _22419 = (_22422 != 0);
    else
    _22419 = DBL_PTR(_22422)->dbl != 0.0;
LA: 
    if (_22419 != 0) {
        goto LB; // [283] 329
    }
    _22424 = (_57LeftSym_41327 == _13FALSE_435);
    if (_22424 == 0) {
        _22425 = 0;
        goto LC; // [295] 310
    }
    _22426 = _57TypeIs(_s_42002, 1);
    if (IS_ATOM_INT(_22426))
    _22425 = (_22426 != 0);
    else
    _22425 = DBL_PTR(_22426)->dbl != 0.0;
LC: 
    if (_22425 == 0) {
        DeRef(_22427);
        _22427 = 0;
        goto LD; // [310] 324
    }
    if (IS_ATOM_INT(_v_42003) && IS_ATOM_INT(_35NOVALUE_15823)) {
        _22428 = (_v_42003 != _35NOVALUE_15823);
    }
    else {
        _22428 = binary_op(NOTEQ, _v_42003, _35NOVALUE_15823);
    }
    if (IS_ATOM_INT(_22428))
    _22427 = (_22428 != 0);
    else
    _22427 = DBL_PTR(_22428)->dbl != 0.0;
LD: 
    if (_22427 == 0)
    {
        _22427 = NOVALUE;
        goto LE; // [325] 338
    }
    else{
        _22427 = NOVALUE;
    }
LB: 

    /** 			c_printf("%d", v)*/
    RefDS(_22397);
    Ref(_v_42003);
    _54c_printf(_22397, _v_42003);
    goto L8; // [335] 490
LE: 

    /** 			c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22429 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22429);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22430 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22430 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22429 = NOVALUE;
    RefDS(_21908);
    Ref(_22430);
    _54c_printf(_21908, _22430);
    _22430 = NOVALUE;

    /** 			c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22431 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22431);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22432 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22432 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22431 = NOVALUE;
    Ref(_22432);
    _54c_puts(_22432);
    _22432 = NOVALUE;

    /** 			if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22433 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22433);
    _22434 = (int)*(((s1_ptr)_2)->base + 12);
    _22433 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22434, 2)){
        _22434 = NOVALUE;
        goto L8; // [387] 490
    }
    _22434 = NOVALUE;

    /** 				SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42002 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22438 = (int)*(((s1_ptr)_2)->base + 12);
    _22436 = NOVALUE;
    if (IS_ATOM_INT(_22438)) {
        _22439 = _22438 + 1;
        if (_22439 > MAXINT){
            _22439 = NewDouble((double)_22439);
        }
    }
    else
    _22439 = binary_op(PLUS, 1, _22438);
    _22438 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22439;
    if( _1 != _22439 ){
        DeRef(_1);
    }
    _22439 = NOVALUE;
    _22436 = NOVALUE;
    goto L8; // [416] 490
L9: 

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22440 = (_57LeftSym_41327 == _13FALSE_435);
    if (_22440 == 0) {
        _22441 = 0;
        goto LF; // [429] 447
    }
    _22442 = _57GType(_s_42002);
    if (IS_ATOM_INT(_22442)) {
        _22443 = (_22442 == 1);
    }
    else {
        _22443 = binary_op(EQUALS, _22442, 1);
    }
    DeRef(_22442);
    _22442 = NOVALUE;
    if (IS_ATOM_INT(_22443))
    _22441 = (_22443 != 0);
    else
    _22441 = DBL_PTR(_22443)->dbl != 0.0;
LF: 
    if (_22441 == 0) {
        goto L10; // [447] 470
    }
    if (IS_ATOM_INT(_v_42003) && IS_ATOM_INT(_35NOVALUE_15823)) {
        _22445 = (_v_42003 != _35NOVALUE_15823);
    }
    else {
        _22445 = binary_op(NOTEQ, _v_42003, _35NOVALUE_15823);
    }
    if (_22445 == 0) {
        DeRef(_22445);
        _22445 = NOVALUE;
        goto L10; // [458] 470
    }
    else {
        if (!IS_ATOM_INT(_22445) && DBL_PTR(_22445)->dbl == 0.0){
            DeRef(_22445);
            _22445 = NOVALUE;
            goto L10; // [458] 470
        }
        DeRef(_22445);
        _22445 = NOVALUE;
    }
    DeRef(_22445);
    _22445 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22397);
    Ref(_v_42003);
    _54c_printf(_22397, _v_42003);
    goto L11; // [467] 489
L10: 

    /** 			c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22446 = (int)*(((s1_ptr)_2)->base + _s_42002);
    _2 = (int)SEQ_PTR(_22446);
    _22447 = (int)*(((s1_ptr)_2)->base + 34);
    _22446 = NOVALUE;
    RefDS(_21908);
    Ref(_22447);
    _54c_printf(_21908, _22447);
    _22447 = NOVALUE;
L11: 
L8: 

    /** 	LeftSym = FALSE*/
    _57LeftSym_41327 = _13FALSE_435;

    /** end procedure*/
    DeRef(_v_42003);
    DeRef(_22391);
    _22391 = NOVALUE;
    DeRef(_22407);
    _22407 = NOVALUE;
    DeRef(_22394);
    _22394 = NOVALUE;
    DeRef(_22424);
    _22424 = NOVALUE;
    DeRef(_22422);
    _22422 = NOVALUE;
    DeRef(_22426);
    _22426 = NOVALUE;
    DeRef(_22428);
    _22428 = NOVALUE;
    DeRef(_22440);
    _22440 = NOVALUE;
    DeRef(_22443);
    _22443 = NOVALUE;
    return;
    ;
}


void _57c_stmt(int _stmt_42136, int _arg_42137, int _lhs_arg_42139)
{
    int _argcount_42140 = NOVALUE;
    int _i_42141 = NOVALUE;
    int _22502 = NOVALUE;
    int _22501 = NOVALUE;
    int _22500 = NOVALUE;
    int _22499 = NOVALUE;
    int _22498 = NOVALUE;
    int _22497 = NOVALUE;
    int _22496 = NOVALUE;
    int _22495 = NOVALUE;
    int _22494 = NOVALUE;
    int _22493 = NOVALUE;
    int _22492 = NOVALUE;
    int _22491 = NOVALUE;
    int _22490 = NOVALUE;
    int _22489 = NOVALUE;
    int _22488 = NOVALUE;
    int _22487 = NOVALUE;
    int _22486 = NOVALUE;
    int _22484 = NOVALUE;
    int _22482 = NOVALUE;
    int _22480 = NOVALUE;
    int _22479 = NOVALUE;
    int _22478 = NOVALUE;
    int _22477 = NOVALUE;
    int _22475 = NOVALUE;
    int _22474 = NOVALUE;
    int _22473 = NOVALUE;
    int _22472 = NOVALUE;
    int _22471 = NOVALUE;
    int _22470 = NOVALUE;
    int _22469 = NOVALUE;
    int _22468 = NOVALUE;
    int _22467 = NOVALUE;
    int _22466 = NOVALUE;
    int _22465 = NOVALUE;
    int _22464 = NOVALUE;
    int _22463 = NOVALUE;
    int _22462 = NOVALUE;
    int _22459 = NOVALUE;
    int _22458 = NOVALUE;
    int _22457 = NOVALUE;
    int _22456 = NOVALUE;
    int _22455 = NOVALUE;
    int _22454 = NOVALUE;
    int _22452 = NOVALUE;
    int _22450 = NOVALUE;
    int _22449 = NOVALUE;
    int _22448 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_42139)) {
        _1 = (long)(DBL_PTR(_lhs_arg_42139)->dbl);
        DeRefDS(_lhs_arg_42139);
        _lhs_arg_42139 = _1;
    }

    /** 	if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22448 = (_57LAST_PASS_41317 == _13TRUE_437);
    if (_22448 == 0) {
        goto L1; // [15] 47
    }
    _22450 = (_35Initializing_16048 == _13FALSE_435);
    if (_22450 == 0)
    {
        DeRef(_22450);
        _22450 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22450);
        _22450 = NOVALUE;
    }

    /** 		cfile_size += 1*/
    _35cfile_size_16047 = _35cfile_size_16047 + 1;

    /** 		update_checksum( stmt )*/
    RefDS(_stmt_42136);
    _55update_checksum(_stmt_42136);
L1: 

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** 		adjust_indent_before(stmt)*/
    RefDS(_stmt_42136);
    _54adjust_indent_before(_stmt_42136);
L2: 

    /** 	if atom(arg) then*/
    _22452 = IS_ATOM(_arg_42137);
    if (_22452 == 0)
    {
        _22452 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22452 = NOVALUE;
    }

    /** 		arg = {arg}*/
    _0 = _arg_42137;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_42137);
    *((int *)(_2+4)) = _arg_42137;
    _arg_42137 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	argcount = 1*/
    _argcount_42140 = 1;

    /** 	i = 1*/
    _i_42141 = 1;

    /** 	while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_42136)){
            _22454 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22454 = 1;
    }
    _22455 = (_i_42141 <= _22454);
    _22454 = NOVALUE;
    if (_22455 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_42136)){
            _22457 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22457 = 1;
    }
    _22458 = (_22457 > 0);
    _22457 = NOVALUE;
    if (_22458 == 0)
    {
        DeRef(_22458);
        _22458 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22458);
        _22458 = NOVALUE;
    }

    /** 		if stmt[i] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22459 = (int)*(((s1_ptr)_2)->base + _i_42141);
    if (binary_op_a(NOTEQ, _22459, 64)){
        _22459 = NOVALUE;
        goto L6; // [118] 288
    }
    _22459 = NOVALUE;

    /** 			if i = 1 then*/
    if (_i_42141 != 1)
    goto L7; // [124] 138

    /** 				LeftSym = TRUE*/
    _57LeftSym_41327 = _13TRUE_437;
L7: 

    /** 			if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_42136)){
            _22462 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22462 = 1;
    }
    _22463 = (_i_42141 < _22462);
    _22462 = NOVALUE;
    if (_22463 == 0) {
        _22464 = 0;
        goto L8; // [147] 167
    }
    _22465 = _i_42141 + 1;
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22466 = (int)*(((s1_ptr)_2)->base + _22465);
    if (IS_ATOM_INT(_22466)) {
        _22467 = (_22466 > 48);
    }
    else {
        _22467 = binary_op(GREATER, _22466, 48);
    }
    _22466 = NOVALUE;
    if (IS_ATOM_INT(_22467))
    _22464 = (_22467 != 0);
    else
    _22464 = DBL_PTR(_22467)->dbl != 0.0;
L8: 
    if (_22464 == 0) {
        goto L9; // [167] 249
    }
    _22469 = _i_42141 + 1;
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22470 = (int)*(((s1_ptr)_2)->base + _22469);
    if (IS_ATOM_INT(_22470)) {
        _22471 = (_22470 <= 57);
    }
    else {
        _22471 = binary_op(LESSEQ, _22470, 57);
    }
    _22470 = NOVALUE;
    if (_22471 == 0) {
        DeRef(_22471);
        _22471 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22471) && DBL_PTR(_22471)->dbl == 0.0){
            DeRef(_22471);
            _22471 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22471);
        _22471 = NOVALUE;
    }
    DeRef(_22471);
    _22471 = NOVALUE;

    /** 				if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22472 = _i_42141 + 1;
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22473 = (int)*(((s1_ptr)_2)->base + _22472);
    if (IS_ATOM_INT(_22473)) {
        _22474 = _22473 - 48;
    }
    else {
        _22474 = binary_op(MINUS, _22473, 48);
    }
    _22473 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42137);
    if (!IS_ATOM_INT(_22474)){
        _22475 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22474)->dbl));
    }
    else{
        _22475 = (int)*(((s1_ptr)_2)->base + _22474);
    }
    if (binary_op_a(NOTEQ, _22475, _lhs_arg_42139)){
        _22475 = NOVALUE;
        goto LA; // [205] 219
    }
    _22475 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _57LeftSym_41327 = _13TRUE_437;
LA: 

    /** 				CName(arg[stmt[i+1]-'0'])*/
    _22477 = _i_42141 + 1;
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22478 = (int)*(((s1_ptr)_2)->base + _22477);
    if (IS_ATOM_INT(_22478)) {
        _22479 = _22478 - 48;
    }
    else {
        _22479 = binary_op(MINUS, _22478, 48);
    }
    _22478 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42137);
    if (!IS_ATOM_INT(_22479)){
        _22480 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22479)->dbl));
    }
    else{
        _22480 = (int)*(((s1_ptr)_2)->base + _22479);
    }
    Ref(_22480);
    _57CName(_22480);
    _22480 = NOVALUE;

    /** 				i += 1*/
    _i_42141 = _i_42141 + 1;
    goto LB; // [246] 279
L9: 

    /** 				if arg[argcount] = lhs_arg then*/
    _2 = (int)SEQ_PTR(_arg_42137);
    _22482 = (int)*(((s1_ptr)_2)->base + _argcount_42140);
    if (binary_op_a(NOTEQ, _22482, _lhs_arg_42139)){
        _22482 = NOVALUE;
        goto LC; // [255] 269
    }
    _22482 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _57LeftSym_41327 = _13TRUE_437;
LC: 

    /** 				CName(arg[argcount])*/
    _2 = (int)SEQ_PTR(_arg_42137);
    _22484 = (int)*(((s1_ptr)_2)->base + _argcount_42140);
    Ref(_22484);
    _57CName(_22484);
    _22484 = NOVALUE;
LB: 

    /** 			argcount += 1*/
    _argcount_42140 = _argcount_42140 + 1;
    goto LD; // [285] 353
L6: 

    /** 			c_putc(stmt[i])*/
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22486 = (int)*(((s1_ptr)_2)->base + _i_42141);
    Ref(_22486);
    _54c_putc(_22486);
    _22486 = NOVALUE;

    /** 			if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22487 = (int)*(((s1_ptr)_2)->base + _i_42141);
    if (IS_ATOM_INT(_22487)) {
        _22488 = (_22487 == 38);
    }
    else {
        _22488 = binary_op(EQUALS, _22487, 38);
    }
    _22487 = NOVALUE;
    if (IS_ATOM_INT(_22488)) {
        if (_22488 == 0) {
            DeRef(_22489);
            _22489 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22488)->dbl == 0.0) {
            DeRef(_22489);
            _22489 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_42136)){
            _22490 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22490 = 1;
    }
    _22491 = (_i_42141 < _22490);
    _22490 = NOVALUE;
    DeRef(_22489);
    _22489 = (_22491 != 0);
LE: 
    if (_22489 == 0) {
        goto LF; // [322] 352
    }
    _22493 = _i_42141 + 1;
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22494 = (int)*(((s1_ptr)_2)->base + _22493);
    if (IS_ATOM_INT(_22494)) {
        _22495 = (_22494 == 64);
    }
    else {
        _22495 = binary_op(EQUALS, _22494, 64);
    }
    _22494 = NOVALUE;
    if (_22495 == 0) {
        DeRef(_22495);
        _22495 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22495) && DBL_PTR(_22495)->dbl == 0.0){
            DeRef(_22495);
            _22495 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22495);
        _22495 = NOVALUE;
    }
    DeRef(_22495);
    _22495 = NOVALUE;

    /** 				LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _57LeftSym_41327 = _13TRUE_437;
LF: 
LD: 

    /** 		if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (int)SEQ_PTR(_stmt_42136);
    _22496 = (int)*(((s1_ptr)_2)->base + _i_42141);
    if (IS_ATOM_INT(_22496)) {
        _22497 = (_22496 == 10);
    }
    else {
        _22497 = binary_op(EQUALS, _22496, 10);
    }
    _22496 = NOVALUE;
    if (IS_ATOM_INT(_22497)) {
        if (_22497 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22497)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_42136)){
            _22499 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22499 = 1;
    }
    _22500 = (_i_42141 < _22499);
    _22499 = NOVALUE;
    if (_22500 == 0)
    {
        DeRef(_22500);
        _22500 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22500);
        _22500 = NOVALUE;
    }

    /** 			if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** 				adjust_indent_after(stmt)*/
    RefDS(_stmt_42136);
    _54adjust_indent_after(_stmt_42136);
L11: 

    /** 			stmt = stmt[i+1..$]*/
    _22501 = _i_42141 + 1;
    if (_22501 > MAXINT){
        _22501 = NewDouble((double)_22501);
    }
    if (IS_SEQUENCE(_stmt_42136)){
            _22502 = SEQ_PTR(_stmt_42136)->length;
    }
    else {
        _22502 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_42136;
    RHS_Slice(_stmt_42136, _22501, _22502);

    /** 			i = 0*/
    _i_42141 = 0;

    /** 			if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** 				adjust_indent_before(stmt)*/
    RefDS(_stmt_42136);
    _54adjust_indent_before(_stmt_42136);
L12: 
L10: 

    /** 		i += 1*/
    _i_42141 = _i_42141 + 1;

    /** 	end while*/
    goto L4; // [432] 90
L5: 

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** 		adjust_indent_after(stmt)*/
    RefDS(_stmt_42136);
    _54adjust_indent_after(_stmt_42136);
L13: 

    /** end procedure*/
    DeRefDS(_stmt_42136);
    DeRef(_arg_42137);
    DeRef(_22448);
    _22448 = NOVALUE;
    DeRef(_22455);
    _22455 = NOVALUE;
    DeRef(_22463);
    _22463 = NOVALUE;
    DeRef(_22465);
    _22465 = NOVALUE;
    DeRef(_22469);
    _22469 = NOVALUE;
    DeRef(_22467);
    _22467 = NOVALUE;
    DeRef(_22472);
    _22472 = NOVALUE;
    DeRef(_22477);
    _22477 = NOVALUE;
    DeRef(_22474);
    _22474 = NOVALUE;
    DeRef(_22491);
    _22491 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    DeRef(_22488);
    _22488 = NOVALUE;
    DeRef(_22493);
    _22493 = NOVALUE;
    DeRef(_22501);
    _22501 = NOVALUE;
    DeRef(_22497);
    _22497 = NOVALUE;
    return;
    ;
}


void _57c_stmt0(int _stmt_42235)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_54emit_c_output_45119 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		c_stmt(stmt, {})*/
    RefDS(_stmt_42235);
    RefDS(_21815);
    _57c_stmt(_stmt_42235, _21815, 0);
L1: 

    /** end procedure*/
    DeRefDS(_stmt_42235);
    return;
    ;
}


void _57DeclareFileVars()
{
    int _s_42241 = NOVALUE;
    int _eentry_42243 = NOVALUE;
    int _22544 = NOVALUE;
    int _22543 = NOVALUE;
    int _22542 = NOVALUE;
    int _22539 = NOVALUE;
    int _22537 = NOVALUE;
    int _22536 = NOVALUE;
    int _22535 = NOVALUE;
    int _22534 = NOVALUE;
    int _22530 = NOVALUE;
    int _22529 = NOVALUE;
    int _22528 = NOVALUE;
    int _22527 = NOVALUE;
    int _22526 = NOVALUE;
    int _22525 = NOVALUE;
    int _22524 = NOVALUE;
    int _22523 = NOVALUE;
    int _22522 = NOVALUE;
    int _22521 = NOVALUE;
    int _22520 = NOVALUE;
    int _22519 = NOVALUE;
    int _22518 = NOVALUE;
    int _22517 = NOVALUE;
    int _22516 = NOVALUE;
    int _22515 = NOVALUE;
    int _22514 = NOVALUE;
    int _22513 = NOVALUE;
    int _22512 = NOVALUE;
    int _22511 = NOVALUE;
    int _22510 = NOVALUE;
    int _22509 = NOVALUE;
    int _22506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Declaring file vars\n")*/
    RefDS(_22505);
    _54c_puts(_22505);

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22506 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    _2 = (int)SEQ_PTR(_22506);
    _s_42241 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42241)){
        _s_42241 = (long)DBL_PTR(_s_42241)->dbl;
    }
    _22506 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42241 == 0)
    {
        goto L2; // [29] 321
    }
    else{
    }

    /** 		eentry = SymTab[s]*/
    DeRef(_eentry_42243);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _eentry_42243 = (int)*(((s1_ptr)_2)->base + _s_42241);
    Ref(_eentry_42243);

    /** 		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22509 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22509)) {
        _22510 = (_22509 >= 5);
    }
    else {
        _22510 = binary_op(GREATEREQ, _22509, 5);
    }
    _22509 = NOVALUE;
    if (IS_ATOM_INT(_22510)) {
        if (_22510 == 0) {
            DeRef(_22511);
            _22511 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22510)->dbl == 0.0) {
            DeRef(_22511);
            _22511 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22512 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22512)) {
        _22513 = (_22512 <= 6);
    }
    else {
        _22513 = binary_op(LESSEQ, _22512, 6);
    }
    _22512 = NOVALUE;
    if (IS_ATOM_INT(_22513)) {
        if (_22513 != 0) {
            DeRef(_22514);
            _22514 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22513)->dbl != 0.0) {
            DeRef(_22514);
            _22514 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22515 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22515)) {
        _22516 = (_22515 == 11);
    }
    else {
        _22516 = binary_op(EQUALS, _22515, 11);
    }
    _22515 = NOVALUE;
    DeRef(_22514);
    if (IS_ATOM_INT(_22516))
    _22514 = (_22516 != 0);
    else
    _22514 = DBL_PTR(_22516)->dbl != 0.0;
L4: 
    if (_22514 != 0) {
        _22517 = 1;
        goto L5; // [92] 112
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22518 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22518)) {
        _22519 = (_22518 == 13);
    }
    else {
        _22519 = binary_op(EQUALS, _22518, 13);
    }
    _22518 = NOVALUE;
    if (IS_ATOM_INT(_22519))
    _22517 = (_22519 != 0);
    else
    _22517 = DBL_PTR(_22519)->dbl != 0.0;
L5: 
    DeRef(_22511);
    _22511 = (_22517 != 0);
L3: 
    if (_22511 == 0) {
        _22520 = 0;
        goto L6; // [116] 136
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22521 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22521)) {
        _22522 = (_22521 != 0);
    }
    else {
        _22522 = binary_op(NOTEQ, _22521, 0);
    }
    _22521 = NOVALUE;
    if (IS_ATOM_INT(_22522))
    _22520 = (_22522 != 0);
    else
    _22520 = DBL_PTR(_22522)->dbl != 0.0;
L6: 
    if (_22520 == 0) {
        _22523 = 0;
        goto L7; // [136] 156
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22524 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22524)) {
        _22525 = (_22524 != 99);
    }
    else {
        _22525 = binary_op(NOTEQ, _22524, 99);
    }
    _22524 = NOVALUE;
    if (IS_ATOM_INT(_22525))
    _22523 = (_22525 != 0);
    else
    _22523 = DBL_PTR(_22525)->dbl != 0.0;
L7: 
    if (_22523 == 0) {
        goto L8; // [156] 300
    }
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22527 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22527 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _22528 = find_from(_22527, _37RTN_TOKS_15594, 1);
    _22527 = NOVALUE;
    _22529 = (_22528 == 0);
    _22528 = NOVALUE;
    if (_22529 == 0)
    {
        DeRef(_22529);
        _22529 = NOVALUE;
        goto L8; // [177] 300
    }
    else{
        DeRef(_22529);
        _22529 = NOVALUE;
    }

    /** 			if eentry[S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22530 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22530 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    if (binary_op_a(NOTEQ, _22530, 27)){
        _22530 = NOVALUE;
        goto L9; // [190] 202
    }
    _22530 = NOVALUE;

    /** 				c_puts( "void ")*/
    RefDS(_22532);
    _54c_puts(_22532);
    goto LA; // [199] 208
L9: 

    /** 				c_puts("int ")*/
    RefDS(_22533);
    _54c_puts(_22533);
LA: 

    /** 			c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22534 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22534 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    RefDS(_21908);
    Ref(_22534);
    _54c_printf(_21908, _22534);
    _22534 = NOVALUE;

    /** 			c_puts(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22535 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22535 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_22535);
    _54c_puts(_22535);
    _22535 = NOVALUE;

    /** 			if integer( eentry[S_OBJ] ) then*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22536 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22536))
    _22537 = 1;
    else if (IS_ATOM_DBL(_22536))
    _22537 = IS_ATOM_INT(DoubleToInt(_22536));
    else
    _22537 = 0;
    _22536 = NOVALUE;
    if (_22537 == 0)
    {
        _22537 = NOVALUE;
        goto LB; // [242] 260
    }
    else{
        _22537 = NOVALUE;
    }

    /** 					c_printf(" = %d;\n", eentry[S_OBJ] )*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    _22539 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_22538);
    Ref(_22539);
    _54c_printf(_22538, _22539);
    _22539 = NOVALUE;
    goto LC; // [257] 266
LB: 

    /** 				c_puts(" = NOVALUE;\n")*/
    RefDS(_22540);
    _54c_puts(_22540);
LC: 

    /** 			c_hputs("extern int ")*/
    RefDS(_22541);
    _54c_hputs(_22541);

    /** 			c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22542 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22542 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    RefDS(_21908);
    Ref(_22542);
    _54c_hprintf(_21908, _22542);
    _22542 = NOVALUE;

    /** 			c_hputs(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42243);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22543 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22543 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    Ref(_22543);
    _54c_hputs(_22543);
    _22543 = NOVALUE;

    /** 			c_hputs(";\n")*/
    RefDS(_22045);
    _54c_hputs(_22045);
L8: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22544 = (int)*(((s1_ptr)_2)->base + _s_42241);
    _2 = (int)SEQ_PTR(_22544);
    _s_42241 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42241)){
        _s_42241 = (long)DBL_PTR(_s_42241)->dbl;
    }
    _22544 = NOVALUE;

    /** 	end while*/
    goto L1; // [318] 29
L2: 

    /** 	c_puts("\n")*/
    RefDS(_21967);
    _54c_puts(_21967);

    /** 	c_hputs("\n")*/
    RefDS(_21967);
    _54c_hputs(_21967);

    /** end procedure*/
    DeRef(_eentry_42243);
    DeRef(_22510);
    _22510 = NOVALUE;
    DeRef(_22513);
    _22513 = NOVALUE;
    DeRef(_22516);
    _22516 = NOVALUE;
    DeRef(_22519);
    _22519 = NOVALUE;
    DeRef(_22522);
    _22522 = NOVALUE;
    DeRef(_22525);
    _22525 = NOVALUE;
    return;
    ;
}


int _57PromoteTypeInfo()
{
    int _updsym_42335 = NOVALUE;
    int _s_42337 = NOVALUE;
    int _sym_42338 = NOVALUE;
    int _symo_42339 = NOVALUE;
    int _upd_42568 = NOVALUE;
    int _22644 = NOVALUE;
    int _22642 = NOVALUE;
    int _22641 = NOVALUE;
    int _22640 = NOVALUE;
    int _22639 = NOVALUE;
    int _22637 = NOVALUE;
    int _22635 = NOVALUE;
    int _22634 = NOVALUE;
    int _22633 = NOVALUE;
    int _22632 = NOVALUE;
    int _22631 = NOVALUE;
    int _22627 = NOVALUE;
    int _22624 = NOVALUE;
    int _22623 = NOVALUE;
    int _22622 = NOVALUE;
    int _22621 = NOVALUE;
    int _22620 = NOVALUE;
    int _22619 = NOVALUE;
    int _22618 = NOVALUE;
    int _22617 = NOVALUE;
    int _22616 = NOVALUE;
    int _22615 = NOVALUE;
    int _22614 = NOVALUE;
    int _22612 = NOVALUE;
    int _22611 = NOVALUE;
    int _22610 = NOVALUE;
    int _22609 = NOVALUE;
    int _22608 = NOVALUE;
    int _22607 = NOVALUE;
    int _22606 = NOVALUE;
    int _22605 = NOVALUE;
    int _22604 = NOVALUE;
    int _22603 = NOVALUE;
    int _22601 = NOVALUE;
    int _22600 = NOVALUE;
    int _22599 = NOVALUE;
    int _22597 = NOVALUE;
    int _22596 = NOVALUE;
    int _22595 = NOVALUE;
    int _22593 = NOVALUE;
    int _22592 = NOVALUE;
    int _22591 = NOVALUE;
    int _22590 = NOVALUE;
    int _22589 = NOVALUE;
    int _22588 = NOVALUE;
    int _22587 = NOVALUE;
    int _22585 = NOVALUE;
    int _22584 = NOVALUE;
    int _22583 = NOVALUE;
    int _22582 = NOVALUE;
    int _22580 = NOVALUE;
    int _22579 = NOVALUE;
    int _22577 = NOVALUE;
    int _22576 = NOVALUE;
    int _22575 = NOVALUE;
    int _22574 = NOVALUE;
    int _22573 = NOVALUE;
    int _22572 = NOVALUE;
    int _22571 = NOVALUE;
    int _22569 = NOVALUE;
    int _22568 = NOVALUE;
    int _22567 = NOVALUE;
    int _22566 = NOVALUE;
    int _22565 = NOVALUE;
    int _22564 = NOVALUE;
    int _22563 = NOVALUE;
    int _22562 = NOVALUE;
    int _22561 = NOVALUE;
    int _22560 = NOVALUE;
    int _22559 = NOVALUE;
    int _22558 = NOVALUE;
    int _22557 = NOVALUE;
    int _22556 = NOVALUE;
    int _22554 = NOVALUE;
    int _22553 = NOVALUE;
    int _22552 = NOVALUE;
    int _22550 = NOVALUE;
    int _22549 = NOVALUE;
    int _22546 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence sym, symo*/

    /** 	updsym = 0*/
    _updsym_42335 = 0;

    /** 	g_has_delete = p_has_delete*/
    _57g_has_delete_41521 = _57p_has_delete_41522;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22546 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    _2 = (int)SEQ_PTR(_22546);
    _s_42337 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42337)){
        _s_42337 = (long)DBL_PTR(_s_42337)->dbl;
    }
    _22546 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42337 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** 		sym = SymTab[s]*/
    DeRef(_sym_42338);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _sym_42338 = (int)*(((s1_ptr)_2)->base + _s_42337);
    Ref(_sym_42338);

    /** 		symo = sym*/
    RefDS(_sym_42338);
    DeRef(_symo_42339);
    _symo_42339 = _sym_42338;

    /** 		if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22549 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22549 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    if (IS_ATOM_INT(_22549)) {
        _22550 = (_22549 == 501);
    }
    else {
        _22550 = binary_op(EQUALS, _22549, 501);
    }
    _22549 = NOVALUE;
    if (IS_ATOM_INT(_22550)) {
        if (_22550 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22550)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22552 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22552 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    if (IS_ATOM_INT(_22552)) {
        _22553 = (_22552 == 504);
    }
    else {
        _22553 = binary_op(EQUALS, _22552, 504);
    }
    _22552 = NOVALUE;
    if (_22553 == 0) {
        DeRef(_22553);
        _22553 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22553) && DBL_PTR(_22553)->dbl == 0.0){
            DeRef(_22553);
            _22553 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22553);
        _22553 = NOVALUE;
    }
    DeRef(_22553);
    _22553 = NOVALUE;
L3: 

    /** 			if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22554 = (int)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22554, 0)){
        _22554 = NOVALUE;
        goto L5; // [103] 120
    }
    _22554 = NOVALUE;

    /** 				sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** 				sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22556 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22556);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22556;
    if( _1 != _22556 ){
        DeRef(_1);
    }
    _22556 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** 			if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22557 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22557)) {
        _22558 = (_22557 != 1);
    }
    else {
        _22558 = binary_op(NOTEQ, _22557, 1);
    }
    _22557 = NOVALUE;
    if (IS_ATOM_INT(_22558)) {
        if (_22558 == 0) {
            DeRef(_22559);
            _22559 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22558)->dbl == 0.0) {
            DeRef(_22559);
            _22559 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22560 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22560)) {
        _22561 = (_22560 != 16);
    }
    else {
        _22561 = binary_op(NOTEQ, _22560, 16);
    }
    _22560 = NOVALUE;
    DeRef(_22559);
    if (IS_ATOM_INT(_22561))
    _22559 = (_22561 != 0);
    else
    _22559 = DBL_PTR(_22561)->dbl != 0.0;
L7: 
    if (_22559 == 0) {
        goto L8; // [172] 283
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22563 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22563)) {
        _22564 = (_22563 != 0);
    }
    else {
        _22564 = binary_op(NOTEQ, _22563, 0);
    }
    _22563 = NOVALUE;
    if (_22564 == 0) {
        DeRef(_22564);
        _22564 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22564) && DBL_PTR(_22564)->dbl == 0.0){
            DeRef(_22564);
            _22564 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22564);
        _22564 = NOVALUE;
    }
    DeRef(_22564);
    _22564 = NOVALUE;

    /** 				if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22565 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22565)) {
        _22566 = (_22565 == 1);
    }
    else {
        _22566 = binary_op(EQUALS, _22565, 1);
    }
    _22565 = NOVALUE;
    if (IS_ATOM_INT(_22566)) {
        if (_22566 != 0) {
            DeRef(_22567);
            _22567 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22566)->dbl != 0.0) {
            DeRef(_22567);
            _22567 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22568 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22568)) {
        _22569 = (_22568 == 16);
    }
    else {
        _22569 = binary_op(EQUALS, _22568, 16);
    }
    _22568 = NOVALUE;
    DeRef(_22567);
    if (IS_ATOM_INT(_22569))
    _22567 = (_22569 != 0);
    else
    _22567 = DBL_PTR(_22569)->dbl != 0.0;
L9: 
    if (_22567 != 0) {
        goto LA; // [226] 267
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22571 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22571)) {
        _22572 = (_22571 == 4);
    }
    else {
        _22572 = binary_op(EQUALS, _22571, 4);
    }
    _22571 = NOVALUE;
    if (IS_ATOM_INT(_22572)) {
        if (_22572 == 0) {
            DeRef(_22573);
            _22573 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22572)->dbl == 0.0) {
            DeRef(_22573);
            _22573 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22574 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22574)) {
        _22575 = (_22574 == 2);
    }
    else {
        _22575 = binary_op(EQUALS, _22574, 2);
    }
    _22574 = NOVALUE;
    DeRef(_22573);
    if (IS_ATOM_INT(_22575))
    _22573 = (_22575 != 0);
    else
    _22573 = DBL_PTR(_22575)->dbl != 0.0;
LB: 
    if (_22573 == 0)
    {
        _22573 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22573 = NOVALUE;
    }
LA: 

    /** 						sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22576 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22576);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22576;
    if( _1 != _22576 ){
        DeRef(_1);
    }
    _22576 = NOVALUE;
LC: 
L8: 

    /** 			if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22577 = (int)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22577, 0)){
        _22577 = NOVALUE;
        goto LD; // [293] 310
    }
    _22577 = NOVALUE;

    /** 				sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** 				sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22579 = (int)*(((s1_ptr)_2)->base + 44);
    Ref(_22579);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _22579;
    if( _1 != _22579 ){
        DeRef(_1);
    }
    _22579 = NOVALUE;
LE: 

    /** 			sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22580 = (int)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22580, 0)){
        _22580 = NOVALUE;
        goto LF; // [345] 362
    }
    _22580 = NOVALUE;

    /** 				sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** 				sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22582 = (int)*(((s1_ptr)_2)->base + 46);
    Ref(_22582);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _22582;
    if( _1 != _22582 ){
        DeRef(_1);
    }
    _22582 = NOVALUE;
L10: 

    /** 			sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22583 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22584 = (int)NewDouble((double)-0xC0000000);
        else
        _22584 = - _35NOVALUE_15823;
    }
    else {
        _22584 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (IS_ATOM_INT(_22583) && IS_ATOM_INT(_22584)) {
        _22585 = (_22583 == _22584);
    }
    else {
        _22585 = binary_op(EQUALS, _22583, _22584);
    }
    _22583 = NOVALUE;
    DeRef(_22584);
    _22584 = NOVALUE;
    if (IS_ATOM_INT(_22585)) {
        if (_22585 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22585)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22587 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22587) && IS_ATOM_INT(_35NOVALUE_15823)) {
        _22588 = (_22587 == _35NOVALUE_15823);
    }
    else {
        _22588 = binary_op(EQUALS, _22587, _35NOVALUE_15823);
    }
    _22587 = NOVALUE;
    if (_22588 == 0) {
        DeRef(_22588);
        _22588 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22588) && DBL_PTR(_22588)->dbl == 0.0){
            DeRef(_22588);
            _22588 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22588);
        _22588 = NOVALUE;
    }
    DeRef(_22588);
    _22588 = NOVALUE;
L11: 

    /** 				sym[S_ARG_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_ARG_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** 				sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22589 = (int)*(((s1_ptr)_2)->base + 49);
    Ref(_22589);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _22589;
    if( _1 != _22589 ){
        DeRef(_1);
    }
    _22589 = NOVALUE;

    /** 				sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22590 = (int)*(((s1_ptr)_2)->base + 50);
    Ref(_22590);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _22590;
    if( _1 != _22590 ){
        DeRef(_1);
    }
    _22590 = NOVALUE;
L13: 

    /** 			sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22591 = (int)NewDouble((double)-0xC0000000);
        else
        _22591 = - _35NOVALUE_15823;
    }
    else {
        _22591 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _22591;
    if( _1 != _22591 ){
        DeRef(_1);
    }
    _22591 = NOVALUE;

    /** 			if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22592 = (int)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22593 = (int)NewDouble((double)-0xC0000000);
        else
        _22593 = - _35NOVALUE_15823;
    }
    else {
        _22593 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (binary_op_a(NOTEQ, _22592, _22593)){
        _22592 = NOVALUE;
        DeRef(_22593);
        _22593 = NOVALUE;
        goto L14; // [503] 520
    }
    _22592 = NOVALUE;
    DeRef(_22593);
    _22593 = NOVALUE;

    /** 				sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** 				sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22595 = (int)*(((s1_ptr)_2)->base + 52);
    Ref(_22595);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _22595;
    if( _1 != _22595 ){
        DeRef(_1);
    }
    _22595 = NOVALUE;
L15: 

    /** 			sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22596 = (int)NewDouble((double)-0xC0000000);
        else
        _22596 = - _35NOVALUE_15823;
    }
    else {
        _22596 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _22596;
    if( _1 != _22596 ){
        DeRef(_1);
    }
    _22596 = NOVALUE;
L6: 

    /** 		sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22597 = (int)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22597, 0)){
        _22597 = NOVALUE;
        goto L16; // [569] 586
    }
    _22597 = NOVALUE;

    /** 		   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** 			sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22599 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22599);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _22599;
    if( _1 != _22599 ){
        DeRef(_1);
    }
    _22599 = NOVALUE;
L17: 

    /** 		sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22600 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22601 = (int)NewDouble((double)-0xC0000000);
        else
        _22601 = - _35NOVALUE_15823;
    }
    else {
        _22601 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (binary_op_a(NOTEQ, _22600, _22601)){
        _22600 = NOVALUE;
        DeRef(_22601);
        _22601 = NOVALUE;
        goto L18; // [624] 641
    }
    _22600 = NOVALUE;
    DeRef(_22601);
    _22601 = NOVALUE;

    /** 			sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_35NOVALUE_15823);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _35NOVALUE_15823;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** 			sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22603 = (int)*(((s1_ptr)_2)->base + 39);
    Ref(_22603);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22603;
    if( _1 != _22603 ){
        DeRef(_1);
    }
    _22603 = NOVALUE;
L19: 

    /** 		sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22604 = (int)NewDouble((double)-0xC0000000);
        else
        _22604 = - _35NOVALUE_15823;
    }
    else {
        _22604 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22604;
    if( _1 != _22604 ){
        DeRef(_1);
    }
    _22604 = NOVALUE;

    /** 		if sym[S_TOKEN] != NAMESPACE*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22605 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22605 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    if (IS_ATOM_INT(_22605)) {
        _22606 = (_22605 != 523);
    }
    else {
        _22606 = binary_op(NOTEQ, _22605, 523);
    }
    _22605 = NOVALUE;
    if (IS_ATOM_INT(_22606)) {
        if (_22606 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22606)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22608 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22608)) {
        _22609 = (_22608 != 2);
    }
    else {
        _22609 = binary_op(NOTEQ, _22608, 2);
    }
    _22608 = NOVALUE;
    if (_22609 == 0) {
        DeRef(_22609);
        _22609 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22609) && DBL_PTR(_22609)->dbl == 0.0){
            DeRef(_22609);
            _22609 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22609);
        _22609 = NOVALUE;
    }
    DeRef(_22609);
    _22609 = NOVALUE;

    /** 			if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22610 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22611 = (int)NewDouble((double)-0xC0000000);
        else
        _22611 = - _35NOVALUE_15823;
    }
    else {
        _22611 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    if (IS_ATOM_INT(_22610) && IS_ATOM_INT(_22611)) {
        _22612 = (_22610 == _22611);
    }
    else {
        _22612 = binary_op(EQUALS, _22610, _22611);
    }
    _22610 = NOVALUE;
    DeRef(_22611);
    _22611 = NOVALUE;
    if (IS_ATOM_INT(_22612)) {
        if (_22612 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22612)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    _22614 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22614) && IS_ATOM_INT(_35NOVALUE_15823)) {
        _22615 = (_22614 == _35NOVALUE_15823);
    }
    else {
        _22615 = binary_op(EQUALS, _22614, _35NOVALUE_15823);
    }
    _22614 = NOVALUE;
    if (_22615 == 0) {
        DeRef(_22615);
        _22615 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22615) && DBL_PTR(_22615)->dbl == 0.0){
            DeRef(_22615);
            _22615 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22615);
        _22615 = NOVALUE;
    }
    DeRef(_22615);
    _22615 = NOVALUE;
L1B: 

    /** 				sym[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** 				sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22616 = (int)*(((s1_ptr)_2)->base + 41);
    Ref(_22616);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22616;
    if( _1 != _22616 ){
        DeRef(_1);
    }
    _22616 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22617 = (int)*(((s1_ptr)_2)->base + 42);
    Ref(_22617);
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22617;
    if( _1 != _22617 ){
        DeRef(_1);
    }
    _22617 = NOVALUE;
L1D: 
L1A: 

    /** 		sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_35NOVALUE_15823)) {
        if ((unsigned long)_35NOVALUE_15823 == 0xC0000000)
        _22618 = (int)NewDouble((double)-0xC0000000);
        else
        _22618 = - _35NOVALUE_15823;
    }
    else {
        _22618 = unary_op(UMINUS, _35NOVALUE_15823);
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22618;
    if( _1 != _22618 ){
        DeRef(_1);
    }
    _22618 = NOVALUE;

    /** 		if sym[S_NREFS] = 1 and*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22619 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22619)) {
        _22620 = (_22619 == 1);
    }
    else {
        _22620 = binary_op(EQUALS, _22619, 1);
    }
    _22619 = NOVALUE;
    if (IS_ATOM_INT(_22620)) {
        if (_22620 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22620)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22622 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22622 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _22623 = find_from(_22622, _37RTN_TOKS_15594, 1);
    _22622 = NOVALUE;
    if (_22623 == 0)
    {
        _22623 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22623 = NOVALUE;
    }

    /** 			if sym[S_USAGE] != U_DELETED then*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _22624 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22624, 99)){
        _22624 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22624 = NOVALUE;

    /** 				sym[S_USAGE] = U_DELETED*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 99;
    DeRef(_1);

    /** 				deleted_routines += 1*/
    _57deleted_routines_42332 = _57deleted_routines_42332 + 1;
L1F: 
L1E: 

    /** 		sym[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_sym_42338);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42338 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if not equal(symo, sym) then*/
    if (_symo_42339 == _sym_42338)
    _22627 = 1;
    else if (IS_ATOM_INT(_symo_42339) && IS_ATOM_INT(_sym_42338))
    _22627 = 0;
    else
    _22627 = (compare(_symo_42339, _sym_42338) == 0);
    if (_22627 != 0)
    goto L20; // [888] 906
    _22627 = NOVALUE;

    /** 			SymTab[s] = sym*/
    RefDS(_sym_42338);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42337);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42338;
    DeRef(_1);

    /** 			updsym += 1*/
    _updsym_42335 = _updsym_42335 + 1;
L20: 

    /** 		s = sym[S_NEXT]*/
    _2 = (int)SEQ_PTR(_sym_42338);
    _s_42337 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42337)){
        _s_42337 = (long)DBL_PTR(_s_42337)->dbl;
    }

    /** 	end while*/
    goto L1; // [918] 38
L2: 

    /** 	for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_35temp_name_type_16050)){
            _22631 = SEQ_PTR(_35temp_name_type_16050)->length;
    }
    else {
        _22631 = 1;
    }
    {
        int _i_42565;
        _i_42565 = 1;
L21: 
        if (_i_42565 > _22631){
            goto L22; // [928] 1061
        }

        /** 		integer upd = 0*/
        _upd_42568 = 0;

        /** 		if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        _22632 = (int)*(((s1_ptr)_2)->base + _i_42565);
        _2 = (int)SEQ_PTR(_22632);
        _22633 = (int)*(((s1_ptr)_2)->base + 1);
        _22632 = NOVALUE;
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        _22634 = (int)*(((s1_ptr)_2)->base + _i_42565);
        _2 = (int)SEQ_PTR(_22634);
        _22635 = (int)*(((s1_ptr)_2)->base + 2);
        _22634 = NOVALUE;
        if (binary_op_a(EQUALS, _22633, _22635)){
            _22633 = NOVALUE;
            _22635 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22633 = NOVALUE;
        _22635 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35temp_name_type_16050 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42565 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        _22639 = (int)*(((s1_ptr)_2)->base + _i_42565);
        _2 = (int)SEQ_PTR(_22639);
        _22640 = (int)*(((s1_ptr)_2)->base + 2);
        _22639 = NOVALUE;
        Ref(_22640);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _22640;
        if( _1 != _22640 ){
            DeRef(_1);
        }
        _22640 = NOVALUE;
        _22637 = NOVALUE;

        /** 			upd = 1*/
        _upd_42568 = 1;
L23: 

        /** 		if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        _22641 = (int)*(((s1_ptr)_2)->base + _i_42565);
        _2 = (int)SEQ_PTR(_22641);
        _22642 = (int)*(((s1_ptr)_2)->base + 2);
        _22641 = NOVALUE;
        if (binary_op_a(EQUALS, _22642, 0)){
            _22642 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22642 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (int)SEQ_PTR(_35temp_name_type_16050);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _35temp_name_type_16050 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42565 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _22644 = NOVALUE;

        /** 			upd = 1*/
        _upd_42568 = 1;
L24: 

        /** 		updsym += upd*/
        _updsym_42335 = _updsym_42335 + _upd_42568;

        /** 	end for*/
        _i_42565 = _i_42565 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** 	return updsym*/
    DeRef(_sym_42338);
    DeRef(_symo_42339);
    DeRef(_22550);
    _22550 = NOVALUE;
    DeRef(_22558);
    _22558 = NOVALUE;
    DeRef(_22561);
    _22561 = NOVALUE;
    DeRef(_22566);
    _22566 = NOVALUE;
    DeRef(_22569);
    _22569 = NOVALUE;
    DeRef(_22572);
    _22572 = NOVALUE;
    DeRef(_22575);
    _22575 = NOVALUE;
    DeRef(_22606);
    _22606 = NOVALUE;
    DeRef(_22585);
    _22585 = NOVALUE;
    DeRef(_22620);
    _22620 = NOVALUE;
    DeRef(_22612);
    _22612 = NOVALUE;
    return _updsym_42335;
    ;
}


void _57declare_prototype(int _s_42603)
{
    int _ret_type_42604 = NOVALUE;
    int _scope_42615 = NOVALUE;
    int _22664 = NOVALUE;
    int _22663 = NOVALUE;
    int _22661 = NOVALUE;
    int _22660 = NOVALUE;
    int _22659 = NOVALUE;
    int _22658 = NOVALUE;
    int _22656 = NOVALUE;
    int _22655 = NOVALUE;
    int _22654 = NOVALUE;
    int _22653 = NOVALUE;
    int _22652 = NOVALUE;
    int _22650 = NOVALUE;
    int _22649 = NOVALUE;
    int _22647 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_token( s ) = PROC then*/
    _22647 = _53sym_token(_s_42603);
    if (binary_op_a(NOTEQ, _22647, 27)){
        DeRef(_22647);
        _22647 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22647);
    _22647 = NOVALUE;

    /** 		ret_type = "void "*/
    RefDS(_22532);
    DeRefi(_ret_type_42604);
    _ret_type_42604 = _22532;
    goto L2; // [22] 33
L1: 

    /** 		ret_type ="int "*/
    RefDS(_22533);
    DeRefi(_ret_type_42604);
    _ret_type_42604 = _22533;
L2: 

    /** 	c_hputs(ret_type)*/
    RefDS(_ret_type_42604);
    _54c_hputs(_ret_type_42604);

    /** 	if dll_option and TWINDOWS  then*/
    if (_57dll_option_41330 == 0) {
        goto L3; // [44] 116
    }
    if (_40TWINDOWS_16112 == 0)
    {
        goto L3; // [51] 116
    }
    else{
    }

    /** 		integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22650 = (int)*(((s1_ptr)_2)->base + _s_42603);
    _2 = (int)SEQ_PTR(_22650);
    _scope_42615 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42615)){
        _scope_42615 = (long)DBL_PTR(_scope_42615)->dbl;
    }
    _22650 = NOVALUE;

    /** 		if (scope = SC_PUBLIC*/
    _22652 = (_scope_42615 == 13);
    if (_22652 != 0) {
        _22653 = 1;
        goto L4; // [78] 92
    }
    _22654 = (_scope_42615 == 11);
    _22653 = (_22654 != 0);
L4: 
    if (_22653 != 0) {
        DeRef(_22655);
        _22655 = 1;
        goto L5; // [92] 106
    }
    _22656 = (_scope_42615 == 6);
    _22655 = (_22656 != 0);
L5: 
    if (_22655 == 0)
    {
        _22655 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22655 = NOVALUE;
    }

    /** 			c_hputs("__stdcall ")*/
    RefDS(_22657);
    _54c_hputs(_22657);
L6: 
L3: 

    /** 	c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22658 = (int)*(((s1_ptr)_2)->base + _s_42603);
    _2 = (int)SEQ_PTR(_22658);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22659 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22659 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22658 = NOVALUE;
    RefDS(_21908);
    Ref(_22659);
    _54c_hprintf(_21908, _22659);
    _22659 = NOVALUE;

    /** 	c_hputs(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22660 = (int)*(((s1_ptr)_2)->base + _s_42603);
    _2 = (int)SEQ_PTR(_22660);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22661 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22661 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22660 = NOVALUE;
    Ref(_22661);
    _54c_hputs(_22661);
    _22661 = NOVALUE;

    /** 	c_hputs("(")*/
    RefDS(_22662);
    _54c_hputs(_22662);

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22663 = (int)*(((s1_ptr)_2)->base + _s_42603);
    _2 = (int)SEQ_PTR(_22663);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _22664 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _22664 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _22663 = NOVALUE;
    {
        int _i_42644;
        _i_42644 = 1;
L7: 
        if (binary_op_a(GREATER, _i_42644, _22664)){
            goto L8; // [172] 206
        }

        /** 		if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_42644, 1)){
            goto L9; // [181] 193
        }

        /** 			c_hputs("int")*/
        RefDS(_22666);
        _54c_hputs(_22666);
        goto LA; // [190] 199
L9: 

        /** 			c_hputs(", int")*/
        RefDS(_22667);
        _54c_hputs(_22667);
LA: 

        /** 	end for*/
        _0 = _i_42644;
        if (IS_ATOM_INT(_i_42644)) {
            _i_42644 = _i_42644 + 1;
            if ((long)((unsigned long)_i_42644 +(unsigned long) HIGH_BITS) >= 0){
                _i_42644 = NewDouble((double)_i_42644);
            }
        }
        else {
            _i_42644 = binary_op_a(PLUS, _i_42644, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_42644);
    }

    /** 	c_hputs(");\n")*/
    RefDS(_22077);
    _54c_hputs(_22077);

    /** end procedure*/
    DeRefi(_ret_type_42604);
    DeRef(_22652);
    _22652 = NOVALUE;
    DeRef(_22654);
    _22654 = NOVALUE;
    DeRef(_22656);
    _22656 = NOVALUE;
    _22664 = NOVALUE;
    return;
    ;
}


void _57add_to_routine_list(int _s_42660, int _seq_num_42661, int _first_42662)
{
    int _p_42737 = NOVALUE;
    int _22713 = NOVALUE;
    int _22711 = NOVALUE;
    int _22709 = NOVALUE;
    int _22707 = NOVALUE;
    int _22705 = NOVALUE;
    int _22704 = NOVALUE;
    int _22703 = NOVALUE;
    int _22701 = NOVALUE;
    int _22699 = NOVALUE;
    int _22697 = NOVALUE;
    int _22696 = NOVALUE;
    int _22694 = NOVALUE;
    int _22693 = NOVALUE;
    int _22689 = NOVALUE;
    int _22688 = NOVALUE;
    int _22687 = NOVALUE;
    int _22686 = NOVALUE;
    int _22685 = NOVALUE;
    int _22684 = NOVALUE;
    int _22683 = NOVALUE;
    int _22682 = NOVALUE;
    int _22681 = NOVALUE;
    int _22680 = NOVALUE;
    int _22678 = NOVALUE;
    int _22677 = NOVALUE;
    int _22676 = NOVALUE;
    int _22675 = NOVALUE;
    int _22672 = NOVALUE;
    int _22671 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not first then*/
    if (_first_42662 != 0)
    goto L1; // [9] 18

    /** 		c_puts(",\n")*/
    RefDS(_22669);
    _54c_puts(_22669);
L1: 

    /** 	c_puts("  {\"")*/
    RefDS(_22670);
    _54c_puts(_22670);

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22671 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22671);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22672 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22672 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22671 = NOVALUE;
    Ref(_22672);
    _54c_puts(_22672);
    _22672 = NOVALUE;

    /** 	c_puts("\", ")*/
    RefDS(_22673);
    _54c_puts(_22673);

    /** 	c_puts("(int (*)())")*/
    RefDS(_22674);
    _54c_puts(_22674);

    /** 	c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22675 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22675);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22676 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22676 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22675 = NOVALUE;
    RefDS(_21908);
    Ref(_22676);
    _54c_printf(_21908, _22676);
    _22676 = NOVALUE;

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22677 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22677);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22678 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22677 = NOVALUE;
    Ref(_22678);
    _54c_puts(_22678);
    _22678 = NOVALUE;

    /** 	c_printf(", %d", seq_num)*/
    RefDS(_22679);
    _54c_printf(_22679, _seq_num_42661);

    /** 	c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22680 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22680);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22681 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22681 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22680 = NOVALUE;
    RefDS(_22679);
    Ref(_22681);
    _54c_printf(_22679, _22681);
    _22681 = NOVALUE;

    /** 	c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22682 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22682);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _22683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _22683 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _22682 = NOVALUE;
    RefDS(_22679);
    Ref(_22683);
    _54c_printf(_22679, _22683);
    _22683 = NOVALUE;

    /** 	if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (_40TWINDOWS_16112 == 0) {
        _22684 = 0;
        goto L2; // [131] 141
    }
    _22684 = (_57dll_option_41330 != 0);
L2: 
    if (_22684 == 0) {
        goto L3; // [141] 186
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22686 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22686);
    _22687 = (int)*(((s1_ptr)_2)->base + 4);
    _22686 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 11;
    *((int *)(_2+12)) = 13;
    _22688 = MAKE_SEQ(_1);
    _22689 = find_from(_22687, _22688, 1);
    _22687 = NOVALUE;
    DeRefDS(_22688);
    _22688 = NOVALUE;
    if (_22689 == 0)
    {
        _22689 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22689 = NOVALUE;
    }

    /** 		c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22690);
    _54c_puts(_22690);
    goto L4; // [183] 192
L3: 

    /** 		c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22691);
    _54c_puts(_22691);
L4: 

    /** 	c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22693 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22693);
    _22694 = (int)*(((s1_ptr)_2)->base + 4);
    _22693 = NOVALUE;
    RefDS(_22692);
    Ref(_22694);
    _54c_printf(_22692, _22694);
    _22694 = NOVALUE;

    /** 	c_puts("}")*/
    RefDS(_22695);
    _54c_puts(_22695);

    /** 	if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22696 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22696);
    _22697 = (int)*(((s1_ptr)_2)->base + 12);
    _22696 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22697, 2)){
        _22697 = NOVALUE;
        goto L5; // [229] 249
    }
    _22697 = NOVALUE;

    /** 		SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42660 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _22699 = NOVALUE;
L5: 

    /** 	symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22701 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22701);
    _p_42737 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_42737)){
        _p_42737 = (long)DBL_PTR(_p_42737)->dbl;
    }
    _22701 = NOVALUE;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22703 = (int)*(((s1_ptr)_2)->base + _s_42660);
    _2 = (int)SEQ_PTR(_22703);
    if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
        _22704 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
    }
    else{
        _22704 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
    }
    _22703 = NOVALUE;
    {
        int _i_42743;
        _i_42743 = 1;
L6: 
        if (binary_op_a(GREATER, _i_42743, _22704)){
            goto L7; // [279] 377
        }

        /** 		SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 46);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22705 = NOVALUE;

        /** 		SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42737 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 44);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22707 = NOVALUE;

        /** 		SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42737 + ((s1_ptr)_2)->base);
        Ref(_35NOVALUE_15823);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 49);
        _1 = *(int *)_2;
        *(int *)_2 = _35NOVALUE_15823;
        DeRef(_1);
        _22709 = NOVALUE;

        /** 		SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36SymTab_14981 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42737 + ((s1_ptr)_2)->base);
        Ref(_35NOVALUE_15823);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 52);
        _1 = *(int *)_2;
        *(int *)_2 = _35NOVALUE_15823;
        DeRef(_1);
        _22711 = NOVALUE;

        /** 		p = SymTab[p][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22713 = (int)*(((s1_ptr)_2)->base + _p_42737);
        _2 = (int)SEQ_PTR(_22713);
        _p_42737 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_42737)){
            _p_42737 = (long)DBL_PTR(_p_42737)->dbl;
        }
        _22713 = NOVALUE;

        /** 	end for*/
        _0 = _i_42743;
        if (IS_ATOM_INT(_i_42743)) {
            _i_42743 = _i_42743 + 1;
            if ((long)((unsigned long)_i_42743 +(unsigned long) HIGH_BITS) >= 0){
                _i_42743 = NewDouble((double)_i_42743);
            }
        }
        else {
            _i_42743 = binary_op_a(PLUS, _i_42743, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_42743);
    }

    /** end procedure*/
    _22704 = NOVALUE;
    return;
    ;
}


void _57DeclareRoutineList()
{
    int _s_42775 = NOVALUE;
    int _first_42776 = NOVALUE;
    int _seq_num_42777 = NOVALUE;
    int _these_routines_42785 = NOVALUE;
    int _these_routines_42807 = NOVALUE;
    int _22729 = NOVALUE;
    int _22728 = NOVALUE;
    int _22726 = NOVALUE;
    int _22724 = NOVALUE;
    int _22721 = NOVALUE;
    int _22720 = NOVALUE;
    int _22718 = NOVALUE;
    int _22716 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_22715);
    _54c_hputs(_22715);

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_43361)){
            _22716 = SEQ_PTR(_57file_routines_43361)->length;
    }
    else {
        _22716 = 1;
    }
    {
        int _f_42782;
        _f_42782 = 1;
L1: 
        if (_f_42782 > _22716){
            goto L2; // [19] 98
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_42785);
        _2 = (int)SEQ_PTR(_57file_routines_43361);
        _these_routines_42785 = (int)*(((s1_ptr)_2)->base + _f_42782);
        Ref(_these_routines_42785);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_42785)){
                _22718 = SEQ_PTR(_these_routines_42785)->length;
        }
        else {
            _22718 = 1;
        }
        {
            int _r_42789;
            _r_42789 = 1;
L3: 
            if (_r_42789 > _22718){
                goto L4; // [41] 89
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_42785);
            _s_42775 = (int)*(((s1_ptr)_2)->base + _r_42789);
            if (!IS_ATOM_INT(_s_42775)){
                _s_42775 = (long)DBL_PTR(_s_42775)->dbl;
            }

            /** 			if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _22720 = (int)*(((s1_ptr)_2)->base + _s_42775);
            _2 = (int)SEQ_PTR(_22720);
            _22721 = (int)*(((s1_ptr)_2)->base + 5);
            _22720 = NOVALUE;
            if (binary_op_a(EQUALS, _22721, 99)){
                _22721 = NOVALUE;
                goto L5; // [72] 82
            }
            _22721 = NOVALUE;

            /** 				declare_prototype( s )*/
            _57declare_prototype(_s_42775);
L5: 

            /** 		end for*/
            _r_42789 = _r_42789 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_42785);
        _these_routines_42785 = NOVALUE;

        /** 	end for*/
        _f_42782 = _f_42782 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** 	c_puts("\n")*/
    RefDS(_21967);
    _54c_puts(_21967);

    /** 	seq_num = 0*/
    _seq_num_42777 = 0;

    /** 	first = TRUE*/
    _first_42776 = _13TRUE_437;

    /** 	c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_22723);
    _54c_puts(_22723);

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_57file_routines_43361)){
            _22724 = SEQ_PTR(_57file_routines_43361)->length;
    }
    else {
        _22724 = 1;
    }
    {
        int _f_42804;
        _f_42804 = 1;
L6: 
        if (_f_42804 > _22724){
            goto L7; // [129] 222
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_42807);
        _2 = (int)SEQ_PTR(_57file_routines_43361);
        _these_routines_42807 = (int)*(((s1_ptr)_2)->base + _f_42804);
        Ref(_these_routines_42807);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_42807)){
                _22726 = SEQ_PTR(_these_routines_42807)->length;
        }
        else {
            _22726 = 1;
        }
        {
            int _r_42811;
            _r_42811 = 1;
L8: 
            if (_r_42811 > _22726){
                goto L9; // [151] 213
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_42807);
            _s_42775 = (int)*(((s1_ptr)_2)->base + _r_42811);
            if (!IS_ATOM_INT(_s_42775)){
                _s_42775 = (long)DBL_PTR(_s_42775)->dbl;
            }

            /** 			if SymTab[s][S_RI_TARGET] then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _22728 = (int)*(((s1_ptr)_2)->base + _s_42775);
            _2 = (int)SEQ_PTR(_22728);
            _22729 = (int)*(((s1_ptr)_2)->base + 53);
            _22728 = NOVALUE;
            if (_22729 == 0) {
                _22729 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_22729) && DBL_PTR(_22729)->dbl == 0.0){
                    _22729 = NOVALUE;
                    goto LA; // [180] 200
                }
                _22729 = NOVALUE;
            }
            _22729 = NOVALUE;

            /** 				add_to_routine_list( s, seq_num, first )*/
            _57add_to_routine_list(_s_42775, _seq_num_42777, _first_42776);

            /** 				first = FALSE*/
            _first_42776 = _13FALSE_435;
LA: 

            /** 			seq_num += 1*/
            _seq_num_42777 = _seq_num_42777 + 1;

            /** 		end for*/
            _r_42811 = _r_42811 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_42807);
        _these_routines_42807 = NOVALUE;

        /** 	end for*/
        _f_42804 = _f_42804 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** 	if not first then*/
    if (_first_42776 != 0)
    goto LB; // [224] 233

    /** 		c_puts(",\n")*/
    RefDS(_22669);
    _54c_puts(_22669);
LB: 

    /** 	c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_22732);
    _54c_puts(_22732);

    /** 	c_hputs("extern unsigned char ** _02;\n")*/
    RefDS(_22733);
    _54c_hputs(_22733);

    /** 	c_puts("unsigned char ** _02;\n")*/
    RefDS(_22734);
    _54c_puts(_22734);

    /** 	c_hputs("extern object _0switches;\n")*/
    RefDS(_22735);
    _54c_hputs(_22735);

    /** 	c_puts("object _0switches;\n")*/
    RefDS(_22736);
    _54c_puts(_22736);

    /** end procedure*/
    return;
    ;
}


void _57DeclareNameSpaceList()
{
    int _s_42837 = NOVALUE;
    int _first_42838 = NOVALUE;
    int _seq_num_42839 = NOVALUE;
    int _22756 = NOVALUE;
    int _22754 = NOVALUE;
    int _22753 = NOVALUE;
    int _22752 = NOVALUE;
    int _22751 = NOVALUE;
    int _22749 = NOVALUE;
    int _22748 = NOVALUE;
    int _22745 = NOVALUE;
    int _22744 = NOVALUE;
    int _22743 = NOVALUE;
    int _22742 = NOVALUE;
    int _22741 = NOVALUE;
    int _22739 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_22737);
    _54c_hputs(_22737);

    /** 	c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_22738);
    _54c_puts(_22738);

    /** 	seq_num = 0*/
    _seq_num_42839 = 0;

    /** 	first = TRUE*/
    _first_42838 = _13TRUE_437;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22739 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    _2 = (int)SEQ_PTR(_22739);
    _s_42837 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42837)){
        _s_42837 = (long)DBL_PTR(_s_42837)->dbl;
    }
    _22739 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42837 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** 		if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22741 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22741);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22742 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22742 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _22741 = NOVALUE;
    _22743 = find_from(_22742, _37NAMED_TOKS_15596, 1);
    _22742 = NOVALUE;
    if (_22743 == 0)
    {
        _22743 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _22743 = NOVALUE;
    }

    /** 			if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22744 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22744);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _22745 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _22745 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _22744 = NOVALUE;
    if (binary_op_a(NOTEQ, _22745, 523)){
        _22745 = NOVALUE;
        goto L4; // [93] 187
    }
    _22745 = NOVALUE;

    /** 				if not first then*/
    if (_first_42838 != 0)
    goto L5; // [99] 108

    /** 					c_puts(",\n")*/
    RefDS(_22669);
    _54c_puts(_22669);
L5: 

    /** 				first = FALSE*/
    _first_42838 = _13FALSE_435;

    /** 				c_puts("  {\"")*/
    RefDS(_22670);
    _54c_puts(_22670);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22748 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22748);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _22749 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _22749 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _22748 = NOVALUE;
    Ref(_22749);
    _54c_puts(_22749);
    _22749 = NOVALUE;

    /** 				c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22751 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22751);
    _22752 = (int)*(((s1_ptr)_2)->base + 1);
    _22751 = NOVALUE;
    RefDS(_22750);
    Ref(_22752);
    _54c_printf(_22750, _22752);
    _22752 = NOVALUE;

    /** 				c_printf(", %d", seq_num)*/
    RefDS(_22679);
    _54c_printf(_22679, _seq_num_42839);

    /** 				c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22753 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22753);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22754 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22754 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _22753 = NOVALUE;
    RefDS(_22679);
    Ref(_22754);
    _54c_printf(_22679, _22754);
    _22754 = NOVALUE;

    /** 				c_puts("}")*/
    RefDS(_22695);
    _54c_puts(_22695);
L4: 

    /** 			seq_num += 1*/
    _seq_num_42839 = _seq_num_42839 + 1;
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _22756 = (int)*(((s1_ptr)_2)->base + _s_42837);
    _2 = (int)SEQ_PTR(_22756);
    _s_42837 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42837)){
        _s_42837 = (long)DBL_PTR(_s_42837)->dbl;
    }
    _22756 = NOVALUE;

    /** 	end while*/
    goto L1; // [212] 50
L2: 

    /** 	if not first then*/
    if (_first_42838 != 0)
    goto L6; // [217] 226

    /** 		c_puts(",\n")*/
    RefDS(_22669);
    _54c_puts(_22669);
L6: 

    /** 	c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_22759);
    _54c_puts(_22759);

    /** end procedure*/
    return;
    ;
}


int _57is_exported(int _s_42901)
{
    int _eentry_42902 = NOVALUE;
    int _scope_42905 = NOVALUE;
    int _22774 = NOVALUE;
    int _22773 = NOVALUE;
    int _22772 = NOVALUE;
    int _22771 = NOVALUE;
    int _22770 = NOVALUE;
    int _22769 = NOVALUE;
    int _22768 = NOVALUE;
    int _22767 = NOVALUE;
    int _22766 = NOVALUE;
    int _22765 = NOVALUE;
    int _22764 = NOVALUE;
    int _22762 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42901)) {
        _1 = (long)(DBL_PTR(_s_42901)->dbl);
        DeRefDS(_s_42901);
        _s_42901 = _1;
    }

    /** 	sequence eentry = SymTab[s]*/
    DeRef(_eentry_42902);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _eentry_42902 = (int)*(((s1_ptr)_2)->base + _s_42901);
    Ref(_eentry_42902);

    /** 	integer scope = eentry[S_SCOPE]*/
    _2 = (int)SEQ_PTR(_eentry_42902);
    _scope_42905 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42905))
    _scope_42905 = (long)DBL_PTR(_scope_42905)->dbl;

    /** 	if eentry[S_MODE] = M_NORMAL then*/
    _2 = (int)SEQ_PTR(_eentry_42902);
    _22762 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _22762, 1)){
        _22762 = NOVALUE;
        goto L1; // [31] 125
    }
    _22762 = NOVALUE;

    /** 		if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (int)SEQ_PTR(_eentry_42902);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22764 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22764 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    if (IS_ATOM_INT(_22764)) {
        _22765 = (_22764 == 1);
    }
    else {
        _22765 = binary_op(EQUALS, _22764, 1);
    }
    _22764 = NOVALUE;
    if (IS_ATOM_INT(_22765)) {
        if (_22765 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_22765)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 11;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 6;
    _22767 = MAKE_SEQ(_1);
    _22768 = find_from(_scope_42905, _22767, 1);
    DeRefDS(_22767);
    _22767 = NOVALUE;
    if (_22768 == 0)
    {
        _22768 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _22768 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_eentry_42902);
    DeRef(_22765);
    _22765 = NOVALUE;
    return 1;
L2: 

    /** 		if scope = SC_PUBLIC and*/
    _22769 = (_scope_42905 == 13);
    if (_22769 == 0) {
        goto L3; // [87] 124
    }
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _22771 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_eentry_42902);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _22772 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _22772 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _2 = (int)SEQ_PTR(_22771);
    if (!IS_ATOM_INT(_22772)){
        _22773 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22772)->dbl));
    }
    else{
        _22773 = (int)*(((s1_ptr)_2)->base + _22772);
    }
    _22771 = NOVALUE;
    if (IS_ATOM_INT(_22773)) {
        {unsigned long tu;
             tu = (unsigned long)_22773 & (unsigned long)4;
             _22774 = MAKE_UINT(tu);
        }
    }
    else {
        _22774 = binary_op(AND_BITS, _22773, 4);
    }
    _22773 = NOVALUE;
    if (_22774 == 0) {
        DeRef(_22774);
        _22774 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_22774) && DBL_PTR(_22774)->dbl == 0.0){
            DeRef(_22774);
            _22774 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_22774);
        _22774 = NOVALUE;
    }
    DeRef(_22774);
    _22774 = NOVALUE;

    /** 			return 1*/
    DeRef(_eentry_42902);
    DeRef(_22769);
    _22769 = NOVALUE;
    DeRef(_22765);
    _22765 = NOVALUE;
    _22772 = NOVALUE;
    return 1;
L3: 
L1: 

    /** 	return 0*/
    DeRef(_eentry_42902);
    DeRef(_22769);
    _22769 = NOVALUE;
    DeRef(_22765);
    _22765 = NOVALUE;
    _22772 = NOVALUE;
    return 0;
    ;
}


void _57version()
{
    int _22808 = NOVALUE;
    int _22807 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _22807 = _32version_string(0);
    {
        int concat_list[3];

        concat_list[0] = _21967;
        concat_list[1] = _22807;
        concat_list[2] = _22806;
        Concat_N((object_ptr)&_22808, concat_list, 3);
    }
    DeRef(_22807);
    _22807 = NOVALUE;
    _54c_puts(_22808);
    _22808 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _57new_c_file(int _name_43009)
{
    int _22811 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_size = 0*/
    _35cfile_size_16047 = 0;

    /** 	if LAST_PASS = FALSE then*/
    if (_57LAST_PASS_41317 != _13FALSE_435)
    goto L1; // [16] 26

    /** 		return*/
    DeRefDS(_name_43009);
    return;
L1: 

    /** 	write_checksum( c_code )*/
    _55write_checksum(_54c_code_45122);

    /** 	close(c_code)*/
    EClose(_54c_code_45122);

    /** 	c_code = open(output_dir & name & ".c", "w")*/
    {
        int concat_list[3];

        concat_list[0] = _22810;
        concat_list[1] = _name_43009;
        concat_list[2] = _57output_dir_41343;
        Concat_N((object_ptr)&_22811, concat_list, 3);
    }
    _54c_code_45122 = EOpen(_22811, _21921, 0);
    DeRefDS(_22811);
    _22811 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_54c_code_45122 != -1)
    goto L2; // [60] 72

    /** 		CompileErr(57)*/
    RefDS(_21815);
    _44CompileErr(57, _21815, 0);
L2: 

    /** 	cfile_count += 1*/
    _35cfile_count_16046 = _35cfile_count_16046 + 1;

    /** 	version()*/
    _57version();

    /** 	c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_21925);
    _54c_puts(_21925);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_21926);
    _54c_puts(_21926);

    /** 	if not TUNIX then*/
    if (_40TUNIX_16116 != 0)
    goto L3; // [100] 112

    /** 		name = lower(name)  -- for faster compare later*/
    RefDS(_name_43009);
    _0 = _name_43009;
    _name_43009 = _14lower(_name_43009);
    DeRefDS(_0);
L3: 

    /** end procedure*/
    DeRefDS(_name_43009);
    return;
    ;
}


int _57unique_c_name(int _name_43038)
{
    int _i_43039 = NOVALUE;
    int _compare_name_43040 = NOVALUE;
    int _next_fc_43041 = NOVALUE;
    int _22827 = NOVALUE;
    int _22825 = NOVALUE;
    int _22824 = NOVALUE;
    int _22823 = NOVALUE;
    int _22821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43040, _name_43038, _22810);

    /** 	if not TUNIX then*/
    if (_40TUNIX_16116 != 0)
    goto L1; // [13] 25

    /** 		compare_name = lower(compare_name)*/
    RefDS(_compare_name_43040);
    _0 = _compare_name_43040;
    _compare_name_43040 = _14lower(_compare_name_43040);
    DeRefDS(_0);
L1: 

    /** 	next_fc = 1*/
    _next_fc_43041 = 1;

    /** 	i = 1*/
    _i_43039 = 1;

    /** 	while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_57generated_files_41334)){
            _22821 = SEQ_PTR(_57generated_files_41334)->length;
    }
    else {
        _22821 = 1;
    }
    if (_i_43039 > _22821)
    goto L3; // [45] 139

    /** 		if equal(generated_files[i], compare_name) then*/
    _2 = (int)SEQ_PTR(_57generated_files_41334);
    _22823 = (int)*(((s1_ptr)_2)->base + _i_43039);
    if (_22823 == _compare_name_43040)
    _22824 = 1;
    else if (IS_ATOM_INT(_22823) && IS_ATOM_INT(_compare_name_43040))
    _22824 = 0;
    else
    _22824 = (compare(_22823, _compare_name_43040) == 0);
    _22823 = NOVALUE;
    if (_22824 == 0)
    {
        _22824 = NOVALUE;
        goto L4; // [61] 127
    }
    else{
        _22824 = NOVALUE;
    }

    /** 			if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_57file_chars_43034)){
            _22825 = SEQ_PTR(_57file_chars_43034)->length;
    }
    else {
        _22825 = 1;
    }
    if (_next_fc_43041 <= _22825)
    goto L5; // [69] 81

    /** 				CompileErr(140)*/
    RefDS(_21815);
    _44CompileErr(140, _21815, 0);
L5: 

    /** 			name[1] = file_chars[next_fc]*/
    _2 = (int)SEQ_PTR(_57file_chars_43034);
    _22827 = (int)*(((s1_ptr)_2)->base + _next_fc_43041);
    Ref(_22827);
    _2 = (int)SEQ_PTR(_name_43038);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _name_43038 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _22827;
    if( _1 != _22827 ){
        DeRef(_1);
    }
    _22827 = NOVALUE;

    /** 			compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43040, _name_43038, _22810);

    /** 			if not TUNIX then*/
    if (_40TUNIX_16116 != 0)
    goto L6; // [101] 113

    /** 				compare_name = lower(compare_name)*/
    RefDS(_compare_name_43040);
    _0 = _compare_name_43040;
    _compare_name_43040 = _14lower(_compare_name_43040);
    DeRefDS(_0);
L6: 

    /** 			next_fc += 1*/
    _next_fc_43041 = _next_fc_43041 + 1;

    /** 			i = 1 -- start over and compare again*/
    _i_43039 = 1;
    goto L2; // [124] 40
L4: 

    /** 			i += 1*/
    _i_43039 = _i_43039 + 1;

    /** 	end while*/
    goto L2; // [136] 40
L3: 

    /** 	return name*/
    DeRef(_compare_name_43040);
    return _name_43038;
    ;
}


int _57is_file_newer(int _f1_43070, int _f2_43071)
{
    int _d1_43072 = NOVALUE;
    int _d2_43075 = NOVALUE;
    int _diff_2__tmp_at42_43086 = NOVALUE;
    int _diff_1__tmp_at42_43085 = NOVALUE;
    int _diff_inlined_diff_at_42_43084 = NOVALUE;
    int _22837 = NOVALUE;
    int _22835 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_43070);
    _0 = _d1_43072;
    _d1_43072 = _17file_timestamp(_f1_43070);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_43071);
    _0 = _d2_43075;
    _d2_43075 = _17file_timestamp(_f2_43071);
    DeRef(_0);

    /** 	if atom(d1) or atom(d2) then return 1 end if*/
    _22835 = IS_ATOM(_d1_43072);
    if (_22835 != 0) {
        goto L1; // [22] 34
    }
    _22837 = IS_ATOM(_d2_43075);
    if (_22837 == 0)
    {
        _22837 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _22837 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_43070);
    DeRefDS(_f2_43071);
    DeRef(_d1_43072);
    DeRef(_d2_43075);
    return 1;
L2: 

    /** 	if datetime:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_43075);
    _0 = _diff_1__tmp_at42_43085;
    _diff_1__tmp_at42_43085 = _18datetimeToSeconds(_d2_43075);
    DeRef(_0);
    Ref(_d1_43072);
    _0 = _diff_2__tmp_at42_43086;
    _diff_2__tmp_at42_43086 = _18datetimeToSeconds(_d1_43072);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_43084);
    if (IS_ATOM_INT(_diff_1__tmp_at42_43085) && IS_ATOM_INT(_diff_2__tmp_at42_43086)) {
        _diff_inlined_diff_at_42_43084 = _diff_1__tmp_at42_43085 - _diff_2__tmp_at42_43086;
        if ((long)((unsigned long)_diff_inlined_diff_at_42_43084 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_43084 = NewDouble((double)_diff_inlined_diff_at_42_43084);
        }
    }
    else {
        _diff_inlined_diff_at_42_43084 = binary_op(MINUS, _diff_1__tmp_at42_43085, _diff_2__tmp_at42_43086);
    }
    DeRef(_diff_1__tmp_at42_43085);
    _diff_1__tmp_at42_43085 = NOVALUE;
    DeRef(_diff_2__tmp_at42_43086);
    _diff_2__tmp_at42_43086 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_43084, 0)){
        goto L3; // [58] 69
    }

    /** 		return 1*/
    DeRefDS(_f1_43070);
    DeRefDS(_f2_43071);
    DeRef(_d1_43072);
    DeRef(_d2_43075);
    return 1;
L3: 

    /** 	return 0*/
    DeRefDS(_f1_43070);
    DeRefDS(_f2_43071);
    DeRef(_d1_43072);
    DeRef(_d2_43075);
    return 0;
    ;
}


void _57add_file(int _filename_43090, int _eu_filename_43091)
{
    int _obj_fname_43111 = NOVALUE;
    int _src_fname_43112 = NOVALUE;
    int _22861 = NOVALUE;
    int _22860 = NOVALUE;
    int _22847 = NOVALUE;
    int _22846 = NOVALUE;
    int _22843 = NOVALUE;
    int _22842 = NOVALUE;
    int _22841 = NOVALUE;
    int _22840 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal("c", fileext(filename)) then*/
    RefDS(_filename_43090);
    _22840 = _17fileext(_filename_43090);
    if (_22839 == _22840)
    _22841 = 1;
    else if (IS_ATOM_INT(_22839) && IS_ATOM_INT(_22840))
    _22841 = 0;
    else
    _22841 = (compare(_22839, _22840) == 0);
    DeRef(_22840);
    _22840 = NOVALUE;
    if (_22841 == 0)
    {
        _22841 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _22841 = NOVALUE;
    }

    /** 		filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_43090)){
            _22842 = SEQ_PTR(_filename_43090)->length;
    }
    else {
        _22842 = 1;
    }
    _22843 = _22842 - 2;
    _22842 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_43090;
    RHS_Slice(_filename_43090, 1, _22843);
    goto L2; // [32] 82
L1: 

    /** 	elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_43090);
    _22846 = _17fileext(_filename_43090);
    if (_22845 == _22846)
    _22847 = 1;
    else if (IS_ATOM_INT(_22845) && IS_ATOM_INT(_22846))
    _22847 = 0;
    else
    _22847 = (compare(_22845, _22846) == 0);
    DeRef(_22846);
    _22846 = NOVALUE;
    if (_22847 == 0)
    {
        _22847 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _22847 = NOVALUE;
    }

    /** 		generated_files = append(generated_files, filename)*/
    RefDS(_filename_43090);
    Append(&_57generated_files_41334, _57generated_files_41334, _filename_43090);

    /** 		if build_system_type = BUILD_DIRECT then*/
    if (_55build_system_type_43982 != 3)
    goto L4; // [62] 75

    /** 			outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_41335, _57outdated_files_41335, 0);
L4: 

    /** 		return*/
    DeRefDS(_filename_43090);
    DeRefDS(_eu_filename_43091);
    DeRef(_obj_fname_43111);
    DeRef(_src_fname_43112);
    DeRef(_22843);
    _22843 = NOVALUE;
    return;
L3: 
L2: 

    /** 	sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_43090);
    DeRef(_obj_fname_43111);
    _obj_fname_43111 = _filename_43090;
    Concat((object_ptr)&_src_fname_43112, _filename_43090, _22810);

    /** 	if compiler_type = COMPILER_WATCOM then*/
    if (_55compiler_type_43986 != 2)
    goto L5; // [99] 112

    /** 		obj_fname &= ".obj"*/
    Concat((object_ptr)&_obj_fname_43111, _obj_fname_43111, _22853);
    goto L6; // [109] 119
L5: 

    /** 		obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_43111, _obj_fname_43111, _22855);
L6: 

    /** 	generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_43112);
    Append(&_57generated_files_41334, _57generated_files_41334, _src_fname_43112);

    /** 	generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_43111);
    Append(&_57generated_files_41334, _57generated_files_41334, _obj_fname_43111);

    /** 	if build_system_type = BUILD_DIRECT then*/
    if (_55build_system_type_43982 != 3)
    goto L7; // [141] 173

    /** 		outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_22860, _57output_dir_41343, _src_fname_43112);
    RefDS(_eu_filename_43091);
    _22861 = _57is_file_newer(_eu_filename_43091, _22860);
    _22860 = NOVALUE;
    Ref(_22861);
    Append(&_57outdated_files_41335, _57outdated_files_41335, _22861);
    DeRef(_22861);
    _22861 = NOVALUE;

    /** 		outdated_files  = append(outdated_files, 0)*/
    Append(&_57outdated_files_41335, _57outdated_files_41335, 0);
L7: 

    /** end procedure*/
    DeRefDS(_filename_43090);
    DeRefDS(_eu_filename_43091);
    DeRef(_obj_fname_43111);
    DeRef(_src_fname_43112);
    DeRef(_22843);
    _22843 = NOVALUE;
    return;
    ;
}


int _57any_code(int _file_no_43135)
{
    int _these_routines_43137 = NOVALUE;
    int _s_43144 = NOVALUE;
    int _22877 = NOVALUE;
    int _22876 = NOVALUE;
    int _22875 = NOVALUE;
    int _22874 = NOVALUE;
    int _22873 = NOVALUE;
    int _22872 = NOVALUE;
    int _22871 = NOVALUE;
    int _22870 = NOVALUE;
    int _22869 = NOVALUE;
    int _22868 = NOVALUE;
    int _22867 = NOVALUE;
    int _22865 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_43137);
    _2 = (int)SEQ_PTR(_57file_routines_43361);
    _these_routines_43137 = (int)*(((s1_ptr)_2)->base + _file_no_43135);
    Ref(_these_routines_43137);

    /** 	for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_43137)){
            _22865 = SEQ_PTR(_these_routines_43137)->length;
    }
    else {
        _22865 = 1;
    }
    {
        int _i_43141;
        _i_43141 = 1;
L1: 
        if (_i_43141 > _22865){
            goto L2; // [22] 126
        }

        /** 		symtab_index s = these_routines[i]*/
        _2 = (int)SEQ_PTR(_these_routines_43137);
        _s_43144 = (int)*(((s1_ptr)_2)->base + _i_43141);
        if (!IS_ATOM_INT(_s_43144)){
            _s_43144 = (long)DBL_PTR(_s_43144)->dbl;
        }

        /** 		if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22867 = (int)*(((s1_ptr)_2)->base + _s_43144);
        _2 = (int)SEQ_PTR(_22867);
        if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
            _22868 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
        }
        else{
            _22868 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
        }
        _22867 = NOVALUE;
        if (IS_ATOM_INT(_22868)) {
            _22869 = (_22868 == _file_no_43135);
        }
        else {
            _22869 = binary_op(EQUALS, _22868, _file_no_43135);
        }
        _22868 = NOVALUE;
        if (IS_ATOM_INT(_22869)) {
            if (_22869 == 0) {
                DeRef(_22870);
                _22870 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_22869)->dbl == 0.0) {
                DeRef(_22870);
                _22870 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22871 = (int)*(((s1_ptr)_2)->base + _s_43144);
        _2 = (int)SEQ_PTR(_22871);
        _22872 = (int)*(((s1_ptr)_2)->base + 5);
        _22871 = NOVALUE;
        if (IS_ATOM_INT(_22872)) {
            _22873 = (_22872 != 99);
        }
        else {
            _22873 = binary_op(NOTEQ, _22872, 99);
        }
        _22872 = NOVALUE;
        DeRef(_22870);
        if (IS_ATOM_INT(_22873))
        _22870 = (_22873 != 0);
        else
        _22870 = DBL_PTR(_22873)->dbl != 0.0;
L3: 
        if (_22870 == 0) {
            goto L4; // [81] 117
        }
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _22875 = (int)*(((s1_ptr)_2)->base + _s_43144);
        _2 = (int)SEQ_PTR(_22875);
        if (!IS_ATOM_INT(_35S_TOKEN_15646)){
            _22876 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
        }
        else{
            _22876 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
        }
        _22875 = NOVALUE;
        _22877 = find_from(_22876, _37RTN_TOKS_15594, 1);
        _22876 = NOVALUE;
        if (_22877 == 0)
        {
            _22877 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _22877 = NOVALUE;
        }

        /** 			return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_43137);
        DeRef(_22869);
        _22869 = NOVALUE;
        DeRef(_22873);
        _22873 = NOVALUE;
        return _13TRUE_437;
L4: 

        /** 	end for*/
        _i_43141 = _i_43141 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** 	return FALSE*/
    DeRef(_these_routines_43137);
    DeRef(_22869);
    _22869 = NOVALUE;
    DeRef(_22873);
    _22873 = NOVALUE;
    return _13FALSE_435;
    ;
}


int _57legaldos_filename_char(int _i_43171)
{
    int _22892 = NOVALUE;
    int _22891 = NOVALUE;
    int _22888 = NOVALUE;
    int _22887 = NOVALUE;
    int _22886 = NOVALUE;
    int _22885 = NOVALUE;
    int _22884 = NOVALUE;
    int _22883 = NOVALUE;
    int _22882 = NOVALUE;
    int _22881 = NOVALUE;
    int _22880 = NOVALUE;
    int _22879 = NOVALUE;
    int _22878 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_43171)) {
        _1 = (long)(DBL_PTR(_i_43171)->dbl);
        DeRefDS(_i_43171);
        _i_43171 = _1;
    }

    /** 	if ('A' <= i and i <= 'Z') or*/
    _22878 = (65 <= _i_43171);
    if (_22878 == 0) {
        _22879 = 0;
        goto L1; // [9] 21
    }
    _22880 = (_i_43171 <= 90);
    _22879 = (_22880 != 0);
L1: 
    if (_22879 != 0) {
        _22881 = 1;
        goto L2; // [21] 45
    }
    _22882 = (48 <= _i_43171);
    if (_22882 == 0) {
        _22883 = 0;
        goto L3; // [29] 41
    }
    _22884 = (_i_43171 <= 57);
    _22883 = (_22884 != 0);
L3: 
    _22881 = (_22883 != 0);
L2: 
    if (_22881 != 0) {
        _22885 = 1;
        goto L4; // [45] 69
    }
    _22886 = (128 <= _i_43171);
    if (_22886 == 0) {
        _22887 = 0;
        goto L5; // [53] 65
    }
    _22888 = (_i_43171 <= 255);
    _22887 = (_22888 != 0);
L5: 
    _22885 = (_22887 != 0);
L4: 
    if (_22885 != 0) {
        goto L6; // [69] 87
    }
    _22891 = find_from(_i_43171, _22890, 1);
    _22892 = (_22891 != 0);
    _22891 = NOVALUE;
    if (_22892 == 0)
    {
        DeRef(_22892);
        _22892 = NOVALUE;
        goto L7; // [83] 96
    }
    else{
        DeRef(_22892);
        _22892 = NOVALUE;
    }
L6: 

    /** 		return 1*/
    DeRef(_22878);
    _22878 = NOVALUE;
    DeRef(_22880);
    _22880 = NOVALUE;
    DeRef(_22882);
    _22882 = NOVALUE;
    DeRef(_22884);
    _22884 = NOVALUE;
    DeRef(_22886);
    _22886 = NOVALUE;
    DeRef(_22888);
    _22888 = NOVALUE;
    return 1;
    goto L8; // [93] 103
L7: 

    /** 		return 0*/
    DeRef(_22878);
    _22878 = NOVALUE;
    DeRef(_22880);
    _22880 = NOVALUE;
    DeRef(_22882);
    _22882 = NOVALUE;
    DeRef(_22884);
    _22884 = NOVALUE;
    DeRef(_22886);
    _22886 = NOVALUE;
    DeRef(_22888);
    _22888 = NOVALUE;
    return 0;
L8: 
    ;
}


int _57legaldos_filename(int _s_43191)
{
    int _dloc_43192 = NOVALUE;
    int _22919 = NOVALUE;
    int _22918 = NOVALUE;
    int _22916 = NOVALUE;
    int _22915 = NOVALUE;
    int _22914 = NOVALUE;
    int _22913 = NOVALUE;
    int _22911 = NOVALUE;
    int _22910 = NOVALUE;
    int _22909 = NOVALUE;
    int _22908 = NOVALUE;
    int _22907 = NOVALUE;
    int _22906 = NOVALUE;
    int _22904 = NOVALUE;
    int _22903 = NOVALUE;
    int _22902 = NOVALUE;
    int _22901 = NOVALUE;
    int _22900 = NOVALUE;
    int _22899 = NOVALUE;
    int _22898 = NOVALUE;
    int _22896 = NOVALUE;
    int _22895 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if find( s, { "..", "." } ) then*/
    RefDS(_22894);
    RefDS(_22893);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22893;
    ((int *)_2)[2] = _22894;
    _22895 = MAKE_SEQ(_1);
    _22896 = find_from(_s_43191, _22895, 1);
    DeRefDS(_22895);
    _22895 = NOVALUE;
    if (_22896 == 0)
    {
        _22896 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _22896 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_s_43191);
    return 1;
L1: 

    /** 	dloc = find('.',s)*/
    _dloc_43192 = find_from(46, _s_43191, 1);

    /** 	if dloc > 8 or ( dloc > 0 and dloc + 3 < length(s) ) or ( dloc = 0 and length(s) > 8 ) then*/
    _22898 = (_dloc_43192 > 8);
    if (_22898 != 0) {
        _22899 = 1;
        goto L2; // [37] 68
    }
    _22900 = (_dloc_43192 > 0);
    if (_22900 == 0) {
        _22901 = 0;
        goto L3; // [45] 64
    }
    _22902 = _dloc_43192 + 3;
    if (IS_SEQUENCE(_s_43191)){
            _22903 = SEQ_PTR(_s_43191)->length;
    }
    else {
        _22903 = 1;
    }
    _22904 = (_22902 < _22903);
    _22902 = NOVALUE;
    _22903 = NOVALUE;
    _22901 = (_22904 != 0);
L3: 
    _22899 = (_22901 != 0);
L2: 
    if (_22899 != 0) {
        goto L4; // [68] 96
    }
    _22906 = (_dloc_43192 == 0);
    if (_22906 == 0) {
        DeRef(_22907);
        _22907 = 0;
        goto L5; // [76] 91
    }
    if (IS_SEQUENCE(_s_43191)){
            _22908 = SEQ_PTR(_s_43191)->length;
    }
    else {
        _22908 = 1;
    }
    _22909 = (_22908 > 8);
    _22908 = NOVALUE;
    _22907 = (_22909 != 0);
L5: 
    if (_22907 == 0)
    {
        _22907 = NOVALUE;
        goto L6; // [92] 103
    }
    else{
        _22907 = NOVALUE;
    }
L4: 

    /** 		return 0*/
    DeRefDS(_s_43191);
    DeRef(_22898);
    _22898 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22906);
    _22906 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    return 0;
L6: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_43191)){
            _22910 = SEQ_PTR(_s_43191)->length;
    }
    else {
        _22910 = 1;
    }
    {
        int _i_43213;
        _i_43213 = 1;
L7: 
        if (_i_43213 > _22910){
            goto L8; // [108] 200
        }

        /** 		if s[i] = '.' then*/
        _2 = (int)SEQ_PTR(_s_43191);
        _22911 = (int)*(((s1_ptr)_2)->base + _i_43213);
        if (binary_op_a(NOTEQ, _22911, 46)){
            _22911 = NOVALUE;
            goto L9; // [121] 173
        }
        _22911 = NOVALUE;

        /** 			for j = i+1 to length(s) do*/
        _22913 = _i_43213 + 1;
        if (IS_SEQUENCE(_s_43191)){
                _22914 = SEQ_PTR(_s_43191)->length;
        }
        else {
            _22914 = 1;
        }
        {
            int _j_43219;
            _j_43219 = _22913;
LA: 
            if (_j_43219 > _22914){
                goto LB; // [134] 168
            }

            /** 				if not legaldos_filename_char(s[j]) then*/
            _2 = (int)SEQ_PTR(_s_43191);
            _22915 = (int)*(((s1_ptr)_2)->base + _j_43219);
            Ref(_22915);
            _22916 = _57legaldos_filename_char(_22915);
            _22915 = NOVALUE;
            if (IS_ATOM_INT(_22916)) {
                if (_22916 != 0){
                    DeRef(_22916);
                    _22916 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            else {
                if (DBL_PTR(_22916)->dbl != 0.0){
                    DeRef(_22916);
                    _22916 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            DeRef(_22916);
            _22916 = NOVALUE;

            /** 					return 0*/
            DeRefDS(_s_43191);
            DeRef(_22898);
            _22898 = NOVALUE;
            DeRef(_22900);
            _22900 = NOVALUE;
            DeRef(_22906);
            _22906 = NOVALUE;
            DeRef(_22904);
            _22904 = NOVALUE;
            DeRef(_22909);
            _22909 = NOVALUE;
            DeRef(_22913);
            _22913 = NOVALUE;
            return 0;
LC: 

            /** 			end for*/
            _j_43219 = _j_43219 + 1;
            goto LA; // [163] 141
LB: 
            ;
        }

        /** 			exit*/
        goto L8; // [170] 200
L9: 

        /** 		if not legaldos_filename_char(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_43191);
        _22918 = (int)*(((s1_ptr)_2)->base + _i_43213);
        Ref(_22918);
        _22919 = _57legaldos_filename_char(_22918);
        _22918 = NOVALUE;
        if (IS_ATOM_INT(_22919)) {
            if (_22919 != 0){
                DeRef(_22919);
                _22919 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        else {
            if (DBL_PTR(_22919)->dbl != 0.0){
                DeRef(_22919);
                _22919 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        DeRef(_22919);
        _22919 = NOVALUE;

        /** 			return 0*/
        DeRefDS(_s_43191);
        DeRef(_22898);
        _22898 = NOVALUE;
        DeRef(_22900);
        _22900 = NOVALUE;
        DeRef(_22906);
        _22906 = NOVALUE;
        DeRef(_22904);
        _22904 = NOVALUE;
        DeRef(_22909);
        _22909 = NOVALUE;
        DeRef(_22913);
        _22913 = NOVALUE;
        return 0;
LD: 

        /** 	end for*/
        _i_43213 = _i_43213 + 1;
        goto L7; // [195] 115
L8: 
        ;
    }

    /** 	return 1*/
    DeRefDS(_s_43191);
    DeRef(_22898);
    _22898 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22906);
    _22906 = NOVALUE;
    DeRef(_22904);
    _22904 = NOVALUE;
    DeRef(_22909);
    _22909 = NOVALUE;
    DeRef(_22913);
    _22913 = NOVALUE;
    return 1;
    ;
}


int _57shrink_to_83(int _s_43232)
{
    int _dl_43233 = NOVALUE;
    int _sl_43234 = NOVALUE;
    int _osl_43235 = NOVALUE;
    int _se_43236 = NOVALUE;
    int _23000 = NOVALUE;
    int _22999 = NOVALUE;
    int _22998 = NOVALUE;
    int _22997 = NOVALUE;
    int _22996 = NOVALUE;
    int _22995 = NOVALUE;
    int _22994 = NOVALUE;
    int _22993 = NOVALUE;
    int _22992 = NOVALUE;
    int _22991 = NOVALUE;
    int _22989 = NOVALUE;
    int _22988 = NOVALUE;
    int _22987 = NOVALUE;
    int _22986 = NOVALUE;
    int _22984 = NOVALUE;
    int _22983 = NOVALUE;
    int _22982 = NOVALUE;
    int _22981 = NOVALUE;
    int _22978 = NOVALUE;
    int _22977 = NOVALUE;
    int _22976 = NOVALUE;
    int _22973 = NOVALUE;
    int _22972 = NOVALUE;
    int _22971 = NOVALUE;
    int _22969 = NOVALUE;
    int _22968 = NOVALUE;
    int _22967 = NOVALUE;
    int _22966 = NOVALUE;
    int _22964 = NOVALUE;
    int _22963 = NOVALUE;
    int _22961 = NOVALUE;
    int _22960 = NOVALUE;
    int _22958 = NOVALUE;
    int _22957 = NOVALUE;
    int _22956 = NOVALUE;
    int _22955 = NOVALUE;
    int _22954 = NOVALUE;
    int _22953 = NOVALUE;
    int _22952 = NOVALUE;
    int _22951 = NOVALUE;
    int _22950 = NOVALUE;
    int _22949 = NOVALUE;
    int _22947 = NOVALUE;
    int _22946 = NOVALUE;
    int _22945 = NOVALUE;
    int _22942 = NOVALUE;
    int _22941 = NOVALUE;
    int _22940 = NOVALUE;
    int _22939 = NOVALUE;
    int _22936 = NOVALUE;
    int _22935 = NOVALUE;
    int _22934 = NOVALUE;
    int _22932 = NOVALUE;
    int _22931 = NOVALUE;
    int _22930 = NOVALUE;
    int _22929 = NOVALUE;
    int _22927 = NOVALUE;
    int _22925 = NOVALUE;
    int _22924 = NOVALUE;
    int _22923 = NOVALUE;
    int _22922 = NOVALUE;
    int _0, _1, _2;
    

    /** 	osl = find( ':', s )*/
    _osl_43235 = find_from(58, _s_43232, 1);

    /** 	sl = osl + find( '\\', s[osl+1..$] ) -- find_from osl*/
    _22922 = _osl_43235 + 1;
    if (IS_SEQUENCE(_s_43232)){
            _22923 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22923 = 1;
    }
    rhs_slice_target = (object_ptr)&_22924;
    RHS_Slice(_s_43232, _22922, _22923);
    _22925 = find_from(92, _22924, 1);
    DeRefDS(_22924);
    _22924 = NOVALUE;
    _sl_43234 = _osl_43235 + _22925;
    _22925 = NOVALUE;

    /** 	if sl=osl+1 then*/
    _22927 = _osl_43235 + 1;
    if (_sl_43234 != _22927)
    goto L1; // [39] 49

    /** 		osl = sl*/
    _osl_43235 = _sl_43234;
L1: 

    /** 	sl = osl + find( '\\', s[osl+1..$] )*/
    _22929 = _osl_43235 + 1;
    if (_22929 > MAXINT){
        _22929 = NewDouble((double)_22929);
    }
    if (IS_SEQUENCE(_s_43232)){
            _22930 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22930 = 1;
    }
    rhs_slice_target = (object_ptr)&_22931;
    RHS_Slice(_s_43232, _22929, _22930);
    _22932 = find_from(92, _22931, 1);
    DeRefDS(_22931);
    _22931 = NOVALUE;
    _sl_43234 = _osl_43235 + _22932;
    _22932 = NOVALUE;

    /** 	dl = osl + find( '.', s[osl+1..sl] )*/
    _22934 = _osl_43235 + 1;
    rhs_slice_target = (object_ptr)&_22935;
    RHS_Slice(_s_43232, _22934, _sl_43234);
    _22936 = find_from(46, _22935, 1);
    DeRefDS(_22935);
    _22935 = NOVALUE;
    _dl_43233 = _osl_43235 + _22936;
    _22936 = NOVALUE;

    /** 	if dl > osl then*/
    if (_dl_43233 <= _osl_43235)
    goto L2; // [94] 124

    /** 		se = s[dl..min({dl+3,sl-1})]*/
    _22939 = _dl_43233 + 3;
    if ((long)((unsigned long)_22939 + (unsigned long)HIGH_BITS) >= 0) 
    _22939 = NewDouble((double)_22939);
    _22940 = _sl_43234 - 1;
    if ((long)((unsigned long)_22940 +(unsigned long) HIGH_BITS) >= 0){
        _22940 = NewDouble((double)_22940);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22939;
    ((int *)_2)[2] = _22940;
    _22941 = MAKE_SEQ(_1);
    _22940 = NOVALUE;
    _22939 = NOVALUE;
    _22942 = _20min(_22941);
    _22941 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43236;
    RHS_Slice(_s_43232, _dl_43233, _22942);
    goto L3; // [121] 132
L2: 

    /** 		se = ""*/
    RefDS(_21815);
    DeRef(_se_43236);
    _se_43236 = _21815;
L3: 

    /** 	while sl != osl do*/
L4: 
    if (_sl_43234 == _osl_43235)
    goto L5; // [137] 333

    /** 		if find( ' ', s[osl+1..sl] ) or not legaldos_filename(upper(s[osl+1..sl-1])) then*/
    _22945 = _osl_43235 + 1;
    rhs_slice_target = (object_ptr)&_22946;
    RHS_Slice(_s_43232, _22945, _sl_43234);
    _22947 = find_from(32, _22946, 1);
    DeRefDS(_22946);
    _22946 = NOVALUE;
    if (_22947 != 0) {
        goto L6; // [157] 190
    }
    _22949 = _osl_43235 + 1;
    if (_22949 > MAXINT){
        _22949 = NewDouble((double)_22949);
    }
    _22950 = _sl_43234 - 1;
    rhs_slice_target = (object_ptr)&_22951;
    RHS_Slice(_s_43232, _22949, _22950);
    _22952 = _14upper(_22951);
    _22951 = NOVALUE;
    _22953 = _57legaldos_filename(_22952);
    _22952 = NOVALUE;
    if (IS_ATOM_INT(_22953)) {
        _22954 = (_22953 == 0);
    }
    else {
        _22954 = unary_op(NOT, _22953);
    }
    DeRef(_22953);
    _22953 = NOVALUE;
    if (_22954 == 0) {
        DeRef(_22954);
        _22954 = NOVALUE;
        goto L7; // [186] 244
    }
    else {
        if (!IS_ATOM_INT(_22954) && DBL_PTR(_22954)->dbl == 0.0){
            DeRef(_22954);
            _22954 = NOVALUE;
            goto L7; // [186] 244
        }
        DeRef(_22954);
        _22954 = NOVALUE;
    }
    DeRef(_22954);
    _22954 = NOVALUE;
L6: 

    /** 			s = s[1..osl] & s[osl+1..osl+6] & "~1" & se & s[sl..$]*/
    rhs_slice_target = (object_ptr)&_22955;
    RHS_Slice(_s_43232, 1, _osl_43235);
    _22956 = _osl_43235 + 1;
    if (_22956 > MAXINT){
        _22956 = NewDouble((double)_22956);
    }
    _22957 = _osl_43235 + 6;
    rhs_slice_target = (object_ptr)&_22958;
    RHS_Slice(_s_43232, _22956, _22957);
    if (IS_SEQUENCE(_s_43232)){
            _22960 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22960 = 1;
    }
    rhs_slice_target = (object_ptr)&_22961;
    RHS_Slice(_s_43232, _sl_43234, _22960);
    {
        int concat_list[5];

        concat_list[0] = _22961;
        concat_list[1] = _se_43236;
        concat_list[2] = _22959;
        concat_list[3] = _22958;
        concat_list[4] = _22955;
        Concat_N((object_ptr)&_s_43232, concat_list, 5);
    }
    DeRefDS(_22961);
    _22961 = NOVALUE;
    DeRefDS(_22958);
    _22958 = NOVALUE;
    DeRefDS(_22955);
    _22955 = NOVALUE;

    /** 			sl = osl+8+length(se)*/
    _22963 = _osl_43235 + 8;
    if ((long)((unsigned long)_22963 + (unsigned long)HIGH_BITS) >= 0) 
    _22963 = NewDouble((double)_22963);
    if (IS_SEQUENCE(_se_43236)){
            _22964 = SEQ_PTR(_se_43236)->length;
    }
    else {
        _22964 = 1;
    }
    if (IS_ATOM_INT(_22963)) {
        _sl_43234 = _22963 + _22964;
    }
    else {
        _sl_43234 = NewDouble(DBL_PTR(_22963)->dbl + (double)_22964);
    }
    DeRef(_22963);
    _22963 = NOVALUE;
    _22964 = NOVALUE;
    if (!IS_ATOM_INT(_sl_43234)) {
        _1 = (long)(DBL_PTR(_sl_43234)->dbl);
        DeRefDS(_sl_43234);
        _sl_43234 = _1;
    }
L7: 

    /** 		osl = sl*/
    _osl_43235 = _sl_43234;

    /** 		sl += find( '\\', s[sl+1..$] )*/
    _22966 = _sl_43234 + 1;
    if (_22966 > MAXINT){
        _22966 = NewDouble((double)_22966);
    }
    if (IS_SEQUENCE(_s_43232)){
            _22967 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22967 = 1;
    }
    rhs_slice_target = (object_ptr)&_22968;
    RHS_Slice(_s_43232, _22966, _22967);
    _22969 = find_from(92, _22968, 1);
    DeRefDS(_22968);
    _22968 = NOVALUE;
    _sl_43234 = _sl_43234 + _22969;
    _22969 = NOVALUE;

    /** 		dl = osl + find( '.', s[osl+1..sl] )*/
    _22971 = _osl_43235 + 1;
    rhs_slice_target = (object_ptr)&_22972;
    RHS_Slice(_s_43232, _22971, _sl_43234);
    _22973 = find_from(46, _22972, 1);
    DeRefDS(_22972);
    _22972 = NOVALUE;
    _dl_43233 = _osl_43235 + _22973;
    _22973 = NOVALUE;

    /** 		if dl > osl then*/
    if (_dl_43233 <= _osl_43235)
    goto L8; // [294] 320

    /** 			se = s[dl..min({dl+3,sl})]*/
    _22976 = _dl_43233 + 3;
    if ((long)((unsigned long)_22976 + (unsigned long)HIGH_BITS) >= 0) 
    _22976 = NewDouble((double)_22976);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22976;
    ((int *)_2)[2] = _sl_43234;
    _22977 = MAKE_SEQ(_1);
    _22976 = NOVALUE;
    _22978 = _20min(_22977);
    _22977 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43236;
    RHS_Slice(_s_43232, _dl_43233, _22978);
    goto L4; // [317] 137
L8: 

    /** 			se = ""*/
    RefDS(_21815);
    DeRef(_se_43236);
    _se_43236 = _21815;

    /** 	end while*/
    goto L4; // [330] 137
L5: 

    /** 	if dl > osl then*/
    if (_dl_43233 <= _osl_43235)
    goto L9; // [335] 362

    /** 		se = s[dl..min({dl+3,length(s)})]*/
    _22981 = _dl_43233 + 3;
    if ((long)((unsigned long)_22981 + (unsigned long)HIGH_BITS) >= 0) 
    _22981 = NewDouble((double)_22981);
    if (IS_SEQUENCE(_s_43232)){
            _22982 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22982 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22981;
    ((int *)_2)[2] = _22982;
    _22983 = MAKE_SEQ(_1);
    _22982 = NOVALUE;
    _22981 = NOVALUE;
    _22984 = _20min(_22983);
    _22983 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43236;
    RHS_Slice(_s_43232, _dl_43233, _22984);
L9: 

    /** 	if find( ' ', s[osl+1..$] ) or not legaldos_filename(upper(s[osl+1..$])) then*/
    _22986 = _osl_43235 + 1;
    if (_22986 > MAXINT){
        _22986 = NewDouble((double)_22986);
    }
    if (IS_SEQUENCE(_s_43232)){
            _22987 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22987 = 1;
    }
    rhs_slice_target = (object_ptr)&_22988;
    RHS_Slice(_s_43232, _22986, _22987);
    _22989 = find_from(32, _22988, 1);
    DeRefDS(_22988);
    _22988 = NOVALUE;
    if (_22989 != 0) {
        goto LA; // [381] 413
    }
    _22991 = _osl_43235 + 1;
    if (_22991 > MAXINT){
        _22991 = NewDouble((double)_22991);
    }
    if (IS_SEQUENCE(_s_43232)){
            _22992 = SEQ_PTR(_s_43232)->length;
    }
    else {
        _22992 = 1;
    }
    rhs_slice_target = (object_ptr)&_22993;
    RHS_Slice(_s_43232, _22991, _22992);
    _22994 = _14upper(_22993);
    _22993 = NOVALUE;
    _22995 = _57legaldos_filename(_22994);
    _22994 = NOVALUE;
    if (IS_ATOM_INT(_22995)) {
        _22996 = (_22995 == 0);
    }
    else {
        _22996 = unary_op(NOT, _22995);
    }
    DeRef(_22995);
    _22995 = NOVALUE;
    if (_22996 == 0) {
        DeRef(_22996);
        _22996 = NOVALUE;
        goto LB; // [409] 443
    }
    else {
        if (!IS_ATOM_INT(_22996) && DBL_PTR(_22996)->dbl == 0.0){
            DeRef(_22996);
            _22996 = NOVALUE;
            goto LB; // [409] 443
        }
        DeRef(_22996);
        _22996 = NOVALUE;
    }
    DeRef(_22996);
    _22996 = NOVALUE;
LA: 

    /** 		s = s[1..osl] & s[osl+1..osl+6] & "~1" & se*/
    rhs_slice_target = (object_ptr)&_22997;
    RHS_Slice(_s_43232, 1, _osl_43235);
    _22998 = _osl_43235 + 1;
    if (_22998 > MAXINT){
        _22998 = NewDouble((double)_22998);
    }
    _22999 = _osl_43235 + 6;
    rhs_slice_target = (object_ptr)&_23000;
    RHS_Slice(_s_43232, _22998, _22999);
    {
        int concat_list[4];

        concat_list[0] = _se_43236;
        concat_list[1] = _22959;
        concat_list[2] = _23000;
        concat_list[3] = _22997;
        Concat_N((object_ptr)&_s_43232, concat_list, 4);
    }
    DeRefDS(_23000);
    _23000 = NOVALUE;
    DeRefDS(_22997);
    _22997 = NOVALUE;
LB: 

    /** 	return s*/
    DeRef(_se_43236);
    DeRef(_22922);
    _22922 = NOVALUE;
    DeRef(_22927);
    _22927 = NOVALUE;
    DeRef(_22929);
    _22929 = NOVALUE;
    DeRef(_22934);
    _22934 = NOVALUE;
    DeRef(_22945);
    _22945 = NOVALUE;
    DeRef(_22942);
    _22942 = NOVALUE;
    DeRef(_22949);
    _22949 = NOVALUE;
    DeRef(_22950);
    _22950 = NOVALUE;
    DeRef(_22966);
    _22966 = NOVALUE;
    DeRef(_22956);
    _22956 = NOVALUE;
    DeRef(_22957);
    _22957 = NOVALUE;
    DeRef(_22971);
    _22971 = NOVALUE;
    DeRef(_22986);
    _22986 = NOVALUE;
    DeRef(_22978);
    _22978 = NOVALUE;
    DeRef(_22984);
    _22984 = NOVALUE;
    DeRef(_22991);
    _22991 = NOVALUE;
    DeRef(_22998);
    _22998 = NOVALUE;
    DeRef(_22999);
    _22999 = NOVALUE;
    return _s_43232;
    ;
}


int _57truncate_to_83(int _lfn_43334)
{
    int _dl_43335 = NOVALUE;
    int _23021 = NOVALUE;
    int _23020 = NOVALUE;
    int _23019 = NOVALUE;
    int _23018 = NOVALUE;
    int _23017 = NOVALUE;
    int _23016 = NOVALUE;
    int _23015 = NOVALUE;
    int _23014 = NOVALUE;
    int _23013 = NOVALUE;
    int _23012 = NOVALUE;
    int _23011 = NOVALUE;
    int _23010 = NOVALUE;
    int _23009 = NOVALUE;
    int _23008 = NOVALUE;
    int _23007 = NOVALUE;
    int _23006 = NOVALUE;
    int _23005 = NOVALUE;
    int _23004 = NOVALUE;
    int _23003 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dl = find( '.', lfn )*/
    _dl_43335 = find_from(46, _lfn_43334, 1);

    /** 	if dl = 0 and length(lfn) > 8 then*/
    _23003 = (_dl_43335 == 0);
    if (_23003 == 0) {
        goto L1; // [16] 45
    }
    if (IS_SEQUENCE(_lfn_43334)){
            _23005 = SEQ_PTR(_lfn_43334)->length;
    }
    else {
        _23005 = 1;
    }
    _23006 = (_23005 > 8);
    _23005 = NOVALUE;
    if (_23006 == 0)
    {
        DeRef(_23006);
        _23006 = NOVALUE;
        goto L1; // [28] 45
    }
    else{
        DeRef(_23006);
        _23006 = NOVALUE;
    }

    /** 		return lfn[1..8]*/
    rhs_slice_target = (object_ptr)&_23007;
    RHS_Slice(_lfn_43334, 1, 8);
    DeRefDS(_lfn_43334);
    DeRef(_23003);
    _23003 = NOVALUE;
    return _23007;
    goto L2; // [42] 138
L1: 

    /** 	elsif dl = 0 and length(lfn) <= 8 then*/
    _23008 = (_dl_43335 == 0);
    if (_23008 == 0) {
        goto L3; // [51] 75
    }
    if (IS_SEQUENCE(_lfn_43334)){
            _23010 = SEQ_PTR(_lfn_43334)->length;
    }
    else {
        _23010 = 1;
    }
    _23011 = (_23010 <= 8);
    _23010 = NOVALUE;
    if (_23011 == 0)
    {
        DeRef(_23011);
        _23011 = NOVALUE;
        goto L3; // [63] 75
    }
    else{
        DeRef(_23011);
        _23011 = NOVALUE;
    }

    /** 		return lfn*/
    DeRef(_23003);
    _23003 = NOVALUE;
    DeRef(_23007);
    _23007 = NOVALUE;
    DeRef(_23008);
    _23008 = NOVALUE;
    return _lfn_43334;
    goto L2; // [72] 138
L3: 

    /** 	elsif dl > 9 and dl + 3 <= length(lfn) then*/
    _23012 = (_dl_43335 > 9);
    if (_23012 == 0) {
        goto L4; // [81] 126
    }
    _23014 = _dl_43335 + 3;
    if ((long)((unsigned long)_23014 + (unsigned long)HIGH_BITS) >= 0) 
    _23014 = NewDouble((double)_23014);
    if (IS_SEQUENCE(_lfn_43334)){
            _23015 = SEQ_PTR(_lfn_43334)->length;
    }
    else {
        _23015 = 1;
    }
    if (IS_ATOM_INT(_23014)) {
        _23016 = (_23014 <= _23015);
    }
    else {
        _23016 = (DBL_PTR(_23014)->dbl <= (double)_23015);
    }
    DeRef(_23014);
    _23014 = NOVALUE;
    _23015 = NOVALUE;
    if (_23016 == 0)
    {
        DeRef(_23016);
        _23016 = NOVALUE;
        goto L4; // [97] 126
    }
    else{
        DeRef(_23016);
        _23016 = NOVALUE;
    }

    /** 		return lfn[1..8] & lfn[dl..$]*/
    rhs_slice_target = (object_ptr)&_23017;
    RHS_Slice(_lfn_43334, 1, 8);
    if (IS_SEQUENCE(_lfn_43334)){
            _23018 = SEQ_PTR(_lfn_43334)->length;
    }
    else {
        _23018 = 1;
    }
    rhs_slice_target = (object_ptr)&_23019;
    RHS_Slice(_lfn_43334, _dl_43335, _23018);
    Concat((object_ptr)&_23020, _23017, _23019);
    DeRefDS(_23017);
    _23017 = NOVALUE;
    DeRef(_23017);
    _23017 = NOVALUE;
    DeRefDS(_23019);
    _23019 = NOVALUE;
    DeRefDS(_lfn_43334);
    DeRef(_23003);
    _23003 = NOVALUE;
    DeRef(_23007);
    _23007 = NOVALUE;
    DeRef(_23008);
    _23008 = NOVALUE;
    DeRef(_23012);
    _23012 = NOVALUE;
    return _23020;
    goto L2; // [123] 138
L4: 

    /** 		CompileErr( 48, {lfn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lfn_43334);
    *((int *)(_2+4)) = _lfn_43334;
    _23021 = MAKE_SEQ(_1);
    _44CompileErr(48, _23021, 0);
    _23021 = NOVALUE;
L2: 
    ;
}


void _57check_file_routines()
{
    int _s_43370 = NOVALUE;
    int _23039 = NOVALUE;
    int _23038 = NOVALUE;
    int _23037 = NOVALUE;
    int _23036 = NOVALUE;
    int _23035 = NOVALUE;
    int _23034 = NOVALUE;
    int _23033 = NOVALUE;
    int _23032 = NOVALUE;
    int _23031 = NOVALUE;
    int _23030 = NOVALUE;
    int _23029 = NOVALUE;
    int _23028 = NOVALUE;
    int _23026 = NOVALUE;
    int _23024 = NOVALUE;
    int _23022 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( file_routines ) then*/
    if (IS_SEQUENCE(_57file_routines_43361)){
            _23022 = SEQ_PTR(_57file_routines_43361)->length;
    }
    else {
        _23022 = 1;
    }
    if (_23022 != 0)
    goto L1; // [8] 146
    _23022 = NOVALUE;

    /** 		file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _23024 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _23024 = 1;
    }
    DeRefDS(_57file_routines_43361);
    _57file_routines_43361 = Repeat(_21815, _23024);
    _23024 = NOVALUE;

    /** 		integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23026 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
    _2 = (int)SEQ_PTR(_23026);
    _s_43370 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43370)){
        _s_43370 = (long)DBL_PTR(_s_43370)->dbl;
    }
    _23026 = NOVALUE;

    /** 		while s do*/
L2: 
    if (_s_43370 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** 			if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23028 = (int)*(((s1_ptr)_2)->base + _s_43370);
    _2 = (int)SEQ_PTR(_23028);
    _23029 = (int)*(((s1_ptr)_2)->base + 5);
    _23028 = NOVALUE;
    if (IS_ATOM_INT(_23029)) {
        _23030 = (_23029 != 99);
    }
    else {
        _23030 = binary_op(NOTEQ, _23029, 99);
    }
    _23029 = NOVALUE;
    if (IS_ATOM_INT(_23030)) {
        if (_23030 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23030)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23032 = (int)*(((s1_ptr)_2)->base + _s_43370);
    _2 = (int)SEQ_PTR(_23032);
    if (!IS_ATOM_INT(_35S_TOKEN_15646)){
        _23033 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    }
    else{
        _23033 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    }
    _23032 = NOVALUE;
    _23034 = find_from(_23033, _37RTN_TOKS_15594, 1);
    _23033 = NOVALUE;
    if (_23034 == 0)
    {
        _23034 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23034 = NOVALUE;
    }

    /** 				file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23035 = (int)*(((s1_ptr)_2)->base + _s_43370);
    _2 = (int)SEQ_PTR(_23035);
    if (!IS_ATOM_INT(_35S_FILE_NO_15637)){
        _23036 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    }
    else{
        _23036 = (int)*(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    }
    _23035 = NOVALUE;
    _2 = (int)SEQ_PTR(_57file_routines_43361);
    if (!IS_ATOM_INT(_23036)){
        _23037 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23036)->dbl));
    }
    else{
        _23037 = (int)*(((s1_ptr)_2)->base + _23036);
    }
    if (IS_SEQUENCE(_23037) && IS_ATOM(_s_43370)) {
        Append(&_23038, _23037, _s_43370);
    }
    else if (IS_ATOM(_23037) && IS_SEQUENCE(_s_43370)) {
    }
    else {
        Concat((object_ptr)&_23038, _23037, _s_43370);
        _23037 = NOVALUE;
    }
    _23037 = NOVALUE;
    _2 = (int)SEQ_PTR(_57file_routines_43361);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _57file_routines_43361 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23036))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23036)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _23036);
    _1 = *(int *)_2;
    *(int *)_2 = _23038;
    if( _1 != _23038 ){
        DeRef(_1);
    }
    _23038 = NOVALUE;
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _23039 = (int)*(((s1_ptr)_2)->base + _s_43370);
    _2 = (int)SEQ_PTR(_23039);
    _s_43370 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43370)){
        _s_43370 = (long)DBL_PTR(_s_43370)->dbl;
    }
    _23039 = NOVALUE;

    /** 		end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** end procedure*/
    _23036 = NOVALUE;
    DeRef(_23030);
    _23030 = NOVALUE;
    return;
    ;
}


void _57GenerateUserRoutines()
{
    int _s_43404 = NOVALUE;
    int _sp_43405 = NOVALUE;
    int _next_c_char_43406 = NOVALUE;
    int _q_43407 = NOVALUE;
    int _temps_43408 = NOVALUE;
    int _buff_43409 = NOVALUE;
    int _base_name_43410 = NOVALUE;
    int _long_c_file_43411 = NOVALUE;
    int _c_file_43412 = NOVALUE;
    int _these_routines_43479 = NOVALUE;
    int _ret_type_43537 = NOVALUE;
    int _scope_43608 = NOVALUE;
    int _names_43642 = NOVALUE;
    int _name_43652 = NOVALUE;
    int _23252 = NOVALUE;
    int _23250 = NOVALUE;
    int _23249 = NOVALUE;
    int _23246 = NOVALUE;
    int _23244 = NOVALUE;
    int _23243 = NOVALUE;
    int _23242 = NOVALUE;
    int _23241 = NOVALUE;
    int _23240 = NOVALUE;
    int _23239 = NOVALUE;
    int _23237 = NOVALUE;
    int _23233 = NOVALUE;
    int _23231 = NOVALUE;
    int _23230 = NOVALUE;
    int _23229 = NOVALUE;
    int _23228 = NOVALUE;
    int _23227 = NOVALUE;
    int _23226 = NOVALUE;
    int _23224 = NOVALUE;
    int _23223 = NOVALUE;
    int _23221 = NOVALUE;
    int _23220 = NOVALUE;
    int _23219 = NOVALUE;
    int _23218 = NOVALUE;
    int _23217 = NOVALUE;
    int _23215 = NOVALUE;
    int _23213 = NOVALUE;
    int _23212 = NOVALUE;
    int _23211 = NOVALUE;
    int _23210 = NOVALUE;
    int _23209 = NOVALUE;
    int _23208 = NOVALUE;
    int _23207 = NOVALUE;
    int _23205 = NOVALUE;
    int _23204 = NOVALUE;
    int _23203 = NOVALUE;
    int _23202 = NOVALUE;
    int _23201 = NOVALUE;
    int _23200 = NOVALUE;
    int _23199 = NOVALUE;
    int _23198 = NOVALUE;
    int _23196 = NOVALUE;
    int _23195 = NOVALUE;
    int _23193 = NOVALUE;
    int _23192 = NOVALUE;
    int _23191 = NOVALUE;
    int _23190 = NOVALUE;
    int _23189 = NOVALUE;
    int _23188 = NOVALUE;
    int _23187 = NOVALUE;
    int _23186 = NOVALUE;
    int _23184 = NOVALUE;
    int _23183 = NOVALUE;
    int _23181 = NOVALUE;
    int _23180 = NOVALUE;
    int _23179 = NOVALUE;
    int _23177 = NOVALUE;
    int _23174 = NOVALUE;
    int _23173 = NOVALUE;
    int _23171 = NOVALUE;
    int _23169 = NOVALUE;
    int _23163 = NOVALUE;
    int _23162 = NOVALUE;
    int _23161 = NOVALUE;
    int _23160 = NOVALUE;
    int _23159 = NOVALUE;
    int _23158 = NOVALUE;
    int _23157 = NOVALUE;
    int _23156 = NOVALUE;
    int _23154 = NOVALUE;
    int _23153 = NOVALUE;
    int _23151 = NOVALUE;
    int _23150 = NOVALUE;
    int _23147 = NOVALUE;
    int _23145 = NOVALUE;
    int _23144 = NOVALUE;
    int _23143 = NOVALUE;
    int _23139 = NOVALUE;
    int _23136 = NOVALUE;
    int _23133 = NOVALUE;
    int _23132 = NOVALUE;
    int _23131 = NOVALUE;
    int _23130 = NOVALUE;
    int _23128 = NOVALUE;
    int _23127 = NOVALUE;
    int _23125 = NOVALUE;
    int _23124 = NOVALUE;
    int _23123 = NOVALUE;
    int _23121 = NOVALUE;
    int _23118 = NOVALUE;
    int _23117 = NOVALUE;
    int _23116 = NOVALUE;
    int _23115 = NOVALUE;
    int _23114 = NOVALUE;
    int _23113 = NOVALUE;
    int _23111 = NOVALUE;
    int _23110 = NOVALUE;
    int _23108 = NOVALUE;
    int _23105 = NOVALUE;
    int _23104 = NOVALUE;
    int _23100 = NOVALUE;
    int _23099 = NOVALUE;
    int _23097 = NOVALUE;
    int _23093 = NOVALUE;
    int _23092 = NOVALUE;
    int _23091 = NOVALUE;
    int _23090 = NOVALUE;
    int _23089 = NOVALUE;
    int _23088 = NOVALUE;
    int _23087 = NOVALUE;
    int _23086 = NOVALUE;
    int _23085 = NOVALUE;
    int _23084 = NOVALUE;
    int _23083 = NOVALUE;
    int _23082 = NOVALUE;
    int _23081 = NOVALUE;
    int _23080 = NOVALUE;
    int _23078 = NOVALUE;
    int _23077 = NOVALUE;
    int _23075 = NOVALUE;
    int _23072 = NOVALUE;
    int _23069 = NOVALUE;
    int _23066 = NOVALUE;
    int _23063 = NOVALUE;
    int _23062 = NOVALUE;
    int _23061 = NOVALUE;
    int _23058 = NOVALUE;
    int _23055 = NOVALUE;
    int _23053 = NOVALUE;
    int _23049 = NOVALUE;
    int _23048 = NOVALUE;
    int _23046 = NOVALUE;
    int _23045 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer next_c_char, q, temps*/

    /** 	sequence buff, base_name, long_c_file, c_file*/

    /** 	if not silent then*/
    if (_35silent_16083 != 0)
    goto L1; // [9] 62

    /** 		if Pass = 1 then*/
    if (_57Pass_41319 != 1)
    goto L2; // [16] 29

    /** 			ShowMsg(1, 239,,0)*/
    RefDS(_21815);
    _45ShowMsg(1, 239, _21815, 0);
L2: 

    /** 		if LAST_PASS = TRUE then*/
    if (_57LAST_PASS_41317 != _13TRUE_437)
    goto L3; // [35] 50

    /** 			ShowMsg(1, 240)*/
    RefDS(_21815);
    _45ShowMsg(1, 240, _21815, 1);
    goto L4; // [47] 61
L3: 

    /** 			ShowMsg(1, 241, Pass, 0)*/
    _45ShowMsg(1, 241, _57Pass_41319, 0);
L4: 
L1: 

    /** 	check_file_routines()*/
    _57check_file_routines();

    /** 	c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23044);
    _54c_puts(_23044);

    /** 	for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _23045 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _23045 = 1;
    }
    {
        int _file_no_43428;
        _file_no_43428 = 1;
L5: 
        if (_file_no_43428 > _23045){
            goto L6; // [78] 2060
        }

        /** 		if file_no = 1 or any_code(file_no) then*/
        _23046 = (_file_no_43428 == 1);
        if (_23046 != 0) {
            goto L7; // [91] 104
        }
        _23048 = _57any_code(_file_no_43428);
        if (_23048 == 0) {
            DeRef(_23048);
            _23048 = NOVALUE;
            goto L8; // [100] 2051
        }
        else {
            if (!IS_ATOM_INT(_23048) && DBL_PTR(_23048)->dbl == 0.0){
                DeRef(_23048);
                _23048 = NOVALUE;
                goto L8; // [100] 2051
            }
            DeRef(_23048);
            _23048 = NOVALUE;
        }
        DeRef(_23048);
        _23048 = NOVALUE;
L7: 

        /** 			next_c_char = 1*/
        _next_c_char_43406 = 1;

        /** 			base_name = name_ext(known_files[file_no])*/
        _2 = (int)SEQ_PTR(_36known_files_14982);
        _23049 = (int)*(((s1_ptr)_2)->base + _file_no_43428);
        Ref(_23049);
        _0 = _base_name_43410;
        _base_name_43410 = _53name_ext(_23049);
        DeRef(_0);
        _23049 = NOVALUE;

        /** 			c_file = base_name*/
        RefDS(_base_name_43410);
        DeRef(_c_file_43412);
        _c_file_43412 = _base_name_43410;

        /** 			q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_43412)){
                _q_43407 = SEQ_PTR(_c_file_43412)->length;
        }
        else {
            _q_43407 = 1;
        }

        /** 			while q >= 1 do*/
L9: 
        if (_q_43407 < 1)
        goto LA; // [140] 181

        /** 				if c_file[q] = '.' then*/
        _2 = (int)SEQ_PTR(_c_file_43412);
        _23053 = (int)*(((s1_ptr)_2)->base + _q_43407);
        if (binary_op_a(NOTEQ, _23053, 46)){
            _23053 = NOVALUE;
            goto LB; // [150] 170
        }
        _23053 = NOVALUE;

        /** 					c_file = c_file[1..q-1]*/
        _23055 = _q_43407 - 1;
        rhs_slice_target = (object_ptr)&_c_file_43412;
        RHS_Slice(_c_file_43412, 1, _23055);

        /** 					exit*/
        goto LA; // [167] 181
LB: 

        /** 				q -= 1*/
        _q_43407 = _q_43407 - 1;

        /** 			end while*/
        goto L9; // [178] 140
LA: 

        /** 			if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_43412);
        _23058 = _14lower(_c_file_43412);
        RefDS(_23060);
        RefDS(_23059);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23059;
        ((int *)_2)[2] = _23060;
        _23061 = MAKE_SEQ(_1);
        _23062 = find_from(_23058, _23061, 1);
        DeRef(_23058);
        _23058 = NOVALUE;
        DeRefDS(_23061);
        _23061 = NOVALUE;
        if (_23062 == 0)
        {
            _23062 = NOVALUE;
            goto LC; // [196] 211
        }
        else{
            _23062 = NOVALUE;
        }

        /** 				CompileErr(12, {base_name})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_base_name_43410);
        *((int *)(_2+4)) = _base_name_43410;
        _23063 = MAKE_SEQ(_1);
        _44CompileErr(12, _23063, 0);
        _23063 = NOVALUE;
LC: 

        /** 			long_c_file = c_file*/
        RefDS(_c_file_43412);
        DeRef(_long_c_file_43411);
        _long_c_file_43411 = _c_file_43412;

        /** 			if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_41317 != _13TRUE_437)
        goto LD; // [224] 249

        /** 				c_file = unique_c_name(c_file)*/
        RefDS(_c_file_43412);
        _0 = _c_file_43412;
        _c_file_43412 = _57unique_c_name(_c_file_43412);
        DeRefDS(_0);

        /** 				add_file(c_file, known_files[file_no])*/
        _2 = (int)SEQ_PTR(_36known_files_14982);
        _23066 = (int)*(((s1_ptr)_2)->base + _file_no_43428);
        RefDS(_c_file_43412);
        Ref(_23066);
        _57add_file(_c_file_43412, _23066);
        _23066 = NOVALUE;
LD: 

        /** 			if file_no = 1 then*/
        if (_file_no_43428 != 1)
        goto LE; // [251] 314

        /** 				if LAST_PASS = TRUE then*/
        if (_57LAST_PASS_41317 != _13TRUE_437)
        goto LF; // [261] 306

        /** 					add_file("main-")*/
        RefDS(_23059);
        RefDS(_21815);
        _57add_file(_23059, _21815);

        /** 					for i = 0 to main_name_num-1 do*/
        _23069 = _54main_name_num_45124 - 1;
        if ((long)((unsigned long)_23069 +(unsigned long) HIGH_BITS) >= 0){
            _23069 = NewDouble((double)_23069);
        }
        {
            int _i_43469;
            _i_43469 = 0;
L10: 
            if (binary_op_a(GREATER, _i_43469, _23069)){
                goto L11; // [279] 305
            }

            /** 						buff = sprintf("main-%d", i)*/
            DeRefi(_buff_43409);
            _buff_43409 = EPrintf(-9999999, _23070, _i_43469);

            /** 						add_file(buff)*/
            RefDS(_buff_43409);
            RefDS(_21815);
            _57add_file(_buff_43409, _21815);

            /** 					end for*/
            _0 = _i_43469;
            if (IS_ATOM_INT(_i_43469)) {
                _i_43469 = _i_43469 + 1;
                if ((long)((unsigned long)_i_43469 +(unsigned long) HIGH_BITS) >= 0){
                    _i_43469 = NewDouble((double)_i_43469);
                }
            }
            else {
                _i_43469 = binary_op_a(PLUS, _i_43469, 1);
            }
            DeRef(_0);
            goto L10; // [300] 286
L11: 
            ;
            DeRef(_i_43469);
        }
LF: 

        /** 				file0 = long_c_file*/
        RefDS(_long_c_file_43411);
        DeRef(_57file0_43168);
        _57file0_43168 = _long_c_file_43411;
LE: 

        /** 			new_c_file(c_file)*/
        RefDS(_c_file_43412);
        _57new_c_file(_c_file_43412);

        /** 			s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (int)SEQ_PTR(_36SymTab_14981);
        _23072 = (int)*(((s1_ptr)_2)->base + _35TopLevelSub_15975);
        _2 = (int)SEQ_PTR(_23072);
        _s_43404 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_43404)){
            _s_43404 = (long)DBL_PTR(_s_43404)->dbl;
        }
        _23072 = NOVALUE;

        /** 			sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_43479);
        _2 = (int)SEQ_PTR(_57file_routines_43361);
        _these_routines_43479 = (int)*(((s1_ptr)_2)->base + _file_no_43428);
        Ref(_these_routines_43479);

        /** 			for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43479)){
                _23075 = SEQ_PTR(_these_routines_43479)->length;
        }
        else {
            _23075 = 1;
        }
        {
            int _routine_no_43482;
            _routine_no_43482 = 1;
L12: 
            if (_routine_no_43482 > _23075){
                goto L13; // [352] 2050
            }

            /** 				s = these_routines[routine_no]*/
            _2 = (int)SEQ_PTR(_these_routines_43479);
            _s_43404 = (int)*(((s1_ptr)_2)->base + _routine_no_43482);
            if (!IS_ATOM_INT(_s_43404)){
                _s_43404 = (long)DBL_PTR(_s_43404)->dbl;
            }

            /** 				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23077 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23077);
            _23078 = (int)*(((s1_ptr)_2)->base + 5);
            _23077 = NOVALUE;
            if (binary_op_a(EQUALS, _23078, 99)){
                _23078 = NOVALUE;
                goto L14; // [383] 2041
            }
            _23078 = NOVALUE;

            /** 					if LAST_PASS = TRUE and*/
            _23080 = (_57LAST_PASS_41317 == _13TRUE_437);
            if (_23080 == 0) {
                goto L15; // [397] 593
            }
            _23082 = (_35cfile_size_16047 > _55max_cfile_size_44001);
            if (_23082 != 0) {
                DeRef(_23083);
                _23083 = 1;
                goto L16; // [409] 472
            }
            _23084 = (_s_43404 != _35TopLevelSub_15975);
            if (_23084 == 0) {
                _23085 = 0;
                goto L17; // [419] 439
            }
            _23086 = (_55max_cfile_size_44001 % 4) ? NewDouble((double)_55max_cfile_size_44001 / 4) : (_55max_cfile_size_44001 / 4);
            if (IS_ATOM_INT(_23086)) {
                _23087 = (_35cfile_size_16047 > _23086);
            }
            else {
                _23087 = ((double)_35cfile_size_16047 > DBL_PTR(_23086)->dbl);
            }
            DeRef(_23086);
            _23086 = NOVALUE;
            _23085 = (_23087 != 0);
L17: 
            if (_23085 == 0) {
                _23088 = 0;
                goto L18; // [439] 468
            }
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23089 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23089);
            if (!IS_ATOM_INT(_35S_CODE_15653)){
                _23090 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
            }
            else{
                _23090 = (int)*(((s1_ptr)_2)->base + _35S_CODE_15653);
            }
            _23089 = NOVALUE;
            if (IS_SEQUENCE(_23090)){
                    _23091 = SEQ_PTR(_23090)->length;
            }
            else {
                _23091 = 1;
            }
            _23090 = NOVALUE;
            _23092 = (_23091 > _55max_cfile_size_44001);
            _23091 = NOVALUE;
            _23088 = (_23092 != 0);
L18: 
            DeRef(_23083);
            _23083 = (_23088 != 0);
L16: 
            if (_23083 == 0)
            {
                _23083 = NOVALUE;
                goto L15; // [473] 593
            }
            else{
                _23083 = NOVALUE;
            }

            /** 						if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_43412)){
                    _23093 = SEQ_PTR(_c_file_43412)->length;
            }
            else {
                _23093 = 1;
            }
            if (_23093 != 7)
            goto L19; // [481] 492

            /** 							c_file &= " "*/
            Concat((object_ptr)&_c_file_43412, _c_file_43412, _23095);
L19: 

            /** 						if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_43412)){
                    _23097 = SEQ_PTR(_c_file_43412)->length;
            }
            else {
                _23097 = 1;
            }
            if (_23097 < 8)
            goto L1A; // [497] 520

            /** 							c_file[7] = '_'*/
            _2 = (int)SEQ_PTR(_c_file_43412);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43412 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 7);
            _1 = *(int *)_2;
            *(int *)_2 = 95;
            DeRef(_1);

            /** 							c_file[8] = file_chars[next_c_char]*/
            _2 = (int)SEQ_PTR(_57file_chars_43034);
            _23099 = (int)*(((s1_ptr)_2)->base + _next_c_char_43406);
            Ref(_23099);
            _2 = (int)SEQ_PTR(_c_file_43412);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43412 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 8);
            _1 = *(int *)_2;
            *(int *)_2 = _23099;
            if( _1 != _23099 ){
                DeRef(_1);
            }
            _23099 = NOVALUE;
            goto L1B; // [517] 552
L1A: 

            /** 							if find('_', c_file) = 0 then*/
            _23100 = find_from(95, _c_file_43412, 1);
            if (_23100 != 0)
            goto L1C; // [527] 538

            /** 								c_file &= "_ "*/
            Concat((object_ptr)&_c_file_43412, _c_file_43412, _23102);
L1C: 

            /** 							c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_43412)){
                    _23104 = SEQ_PTR(_c_file_43412)->length;
            }
            else {
                _23104 = 1;
            }
            _2 = (int)SEQ_PTR(_57file_chars_43034);
            _23105 = (int)*(((s1_ptr)_2)->base + _next_c_char_43406);
            Ref(_23105);
            _2 = (int)SEQ_PTR(_c_file_43412);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43412 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _23104);
            _1 = *(int *)_2;
            *(int *)_2 = _23105;
            if( _1 != _23105 ){
                DeRef(_1);
            }
            _23105 = NOVALUE;
L1B: 

            /** 						c_file = unique_c_name(c_file)*/
            RefDS(_c_file_43412);
            _0 = _c_file_43412;
            _c_file_43412 = _57unique_c_name(_c_file_43412);
            DeRefDS(_0);

            /** 						new_c_file(c_file)*/
            RefDS(_c_file_43412);
            _57new_c_file(_c_file_43412);

            /** 						next_c_char += 1*/
            _next_c_char_43406 = _next_c_char_43406 + 1;

            /** 						if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_57file_chars_43034)){
                    _23108 = SEQ_PTR(_57file_chars_43034)->length;
            }
            else {
                _23108 = 1;
            }
            if (_next_c_char_43406 <= _23108)
            goto L1D; // [576] 586

            /** 							next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_43406 = 1;
L1D: 

            /** 						add_file(c_file)*/
            RefDS(_c_file_43412);
            RefDS(_21815);
            _57add_file(_c_file_43412, _21815);
L15: 

            /** 					sequence ret_type*/

            /** 					if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23110 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23110);
            if (!IS_ATOM_INT(_35S_TOKEN_15646)){
                _23111 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
            }
            else{
                _23111 = (int)*(((s1_ptr)_2)->base + _35S_TOKEN_15646);
            }
            _23110 = NOVALUE;
            if (binary_op_a(NOTEQ, _23111, 27)){
                _23111 = NOVALUE;
                goto L1E; // [611] 625
            }
            _23111 = NOVALUE;

            /** 						ret_type = "void "*/
            RefDS(_22532);
            DeRefi(_ret_type_43537);
            _ret_type_43537 = _22532;
            goto L1F; // [622] 633
L1E: 

            /** 						ret_type = "int "*/
            RefDS(_22533);
            DeRefi(_ret_type_43537);
            _ret_type_43537 = _22533;
L1F: 

            /** 					if find( SymTab[s][S_SCOPE], {SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) and dll_option then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23113 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23113);
            _23114 = (int)*(((s1_ptr)_2)->base + 4);
            _23113 = NOVALUE;
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = 6;
            *((int *)(_2+8)) = 11;
            *((int *)(_2+12)) = 13;
            _23115 = MAKE_SEQ(_1);
            _23116 = find_from(_23114, _23115, 1);
            _23114 = NOVALUE;
            DeRefDS(_23115);
            _23115 = NOVALUE;
            if (_23116 == 0) {
                goto L20; // [664] 740
            }
            if (_57dll_option_41330 == 0)
            {
                goto L20; // [671] 740
            }
            else{
            }

            /** 						SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_14981 = MAKE_SEQ(_2);
            }
            _3 = (int)(_s_43404 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 53);
            _1 = *(int *)_2;
            *(int *)_2 = _13TRUE_437;
            DeRef(_1);
            _23118 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _57LeftSym_41327 = _13TRUE_437;

            /** 						if TWINDOWS then*/
            if (_40TWINDOWS_16112 == 0)
            {
                goto L21; // [704] 723
            }
            else{
            }

            /** 							c_stmt(ret_type & " __stdcall @(", s)*/
            Concat((object_ptr)&_23121, _ret_type_43537, _23120);
            _57c_stmt(_23121, _s_43404, 0);
            _23121 = NOVALUE;
            goto L22; // [720] 763
L21: 

            /** 							c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23123, _ret_type_43537, _23122);
            _57c_stmt(_23123, _s_43404, 0);
            _23123 = NOVALUE;
            goto L22; // [737] 763
L20: 

            /** 						LeftSym = TRUE*/
            _57LeftSym_41327 = _13TRUE_437;

            /** 						c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23124, _ret_type_43537, _23122);
            _57c_stmt(_23124, _s_43404, 0);
            _23124 = NOVALUE;
L22: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23125 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23125);
            _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43405)){
                _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
            }
            _23125 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23127 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23127);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                _23128 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
            }
            else{
                _23128 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
            }
            _23127 = NOVALUE;
            {
                int _p_43578;
                _p_43578 = 1;
L23: 
                if (binary_op_a(GREATER, _p_43578, _23128)){
                    goto L24; // [793] 869
                }

                /** 						c_puts("int _")*/
                RefDS(_23129);
                _54c_puts(_23129);

                /** 						c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23130 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23130);
                if (!IS_ATOM_INT(_35S_NAME_15641)){
                    _23131 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
                }
                else{
                    _23131 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
                }
                _23130 = NOVALUE;
                Ref(_23131);
                _54c_puts(_23131);
                _23131 = NOVALUE;

                /** 						if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23132 = (int)*(((s1_ptr)_2)->base + _s_43404);
                _2 = (int)SEQ_PTR(_23132);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                    _23133 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
                }
                else{
                    _23133 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
                }
                _23132 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43578, _23133)){
                    _23133 = NOVALUE;
                    goto L25; // [836] 846
                }
                _23133 = NOVALUE;

                /** 							c_puts(", ")*/
                RefDS(_23135);
                _54c_puts(_23135);
L25: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23136 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23136);
                _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43405)){
                    _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
                }
                _23136 = NOVALUE;

                /** 					end for*/
                _0 = _p_43578;
                if (IS_ATOM_INT(_p_43578)) {
                    _p_43578 = _p_43578 + 1;
                    if ((long)((unsigned long)_p_43578 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43578 = NewDouble((double)_p_43578);
                    }
                }
                else {
                    _p_43578 = binary_op_a(PLUS, _p_43578, 1);
                }
                DeRef(_0);
                goto L23; // [864] 800
L24: 
                ;
                DeRef(_p_43578);
            }

            /** 					c_puts(")\n")*/
            RefDS(_23138);
            _54c_puts(_23138);

            /** 					c_stmt0("{\n")*/
            RefDS(_21972);
            _57c_stmt0(_21972);

            /** 					NewBB(0, E_ALL_EFFECT, 0)*/
            _57NewBB(0, 1073741823, 0);

            /** 					Initializing = TRUE*/
            _35Initializing_16048 = _13TRUE_437;

            /** 					while sp do*/
L26: 
            if (_sp_43405 == 0)
            {
                goto L27; // [902] 1041
            }
            else{
            }

            /** 						integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23139 = (int)*(((s1_ptr)_2)->base + _sp_43405);
            _2 = (int)SEQ_PTR(_23139);
            _scope_43608 = (int)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_43608)){
                _scope_43608 = (long)DBL_PTR(_scope_43608)->dbl;
            }
            _23139 = NOVALUE;

            /** 						switch scope with fallthru do*/
            _0 = _scope_43608;
            switch ( _0 ){ 

                /** 							case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** 								break*/
                goto L28; // [936] 1018

                /** 							case SC_PRIVATE then*/
                case 3:

                /** 								c_stmt0("int ")*/
                RefDS(_22533);
                _57c_stmt0(_22533);

                /** 								c_puts("_")*/
                RefDS(_21887);
                _54c_puts(_21887);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23143 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23143);
                if (!IS_ATOM_INT(_35S_NAME_15641)){
                    _23144 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
                }
                else{
                    _23144 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
                }
                _23143 = NOVALUE;
                Ref(_23144);
                _54c_puts(_23144);
                _23144 = NOVALUE;

                /** 								c_puts(" = NOVALUE;\n")*/
                RefDS(_22540);
                _54c_puts(_22540);

                /** 								target[MIN] = NOVALUE*/
                Ref(_35NOVALUE_15823);
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _35NOVALUE_15823;
                DeRef(_1);

                /** 								target[MAX] = NOVALUE*/
                Ref(_35NOVALUE_15823);
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _35NOVALUE_15823;
                DeRef(_1);

                /** 								RemoveFromBB( sp )*/
                _57RemoveFromBB(_sp_43405);

                /** 								break*/
                goto L28; // [1005] 1018

                /** 							case else*/
                default:

                /** 								exit*/
                goto L27; // [1015] 1041
            ;}L28: 

            /** 						sp = SymTab[sp][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23145 = (int)*(((s1_ptr)_2)->base + _sp_43405);
            _2 = (int)SEQ_PTR(_23145);
            _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43405)){
                _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
            }
            _23145 = NOVALUE;

            /** 					end while*/
            goto L26; // [1038] 902
L27: 

            /** 					temps = SymTab[s][S_TEMPS]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23147 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23147);
            if (!IS_ATOM_INT(_35S_TEMPS_15686)){
                _temps_43408 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TEMPS_15686)->dbl));
            }
            else{
                _temps_43408 = (int)*(((s1_ptr)_2)->base + _35S_TEMPS_15686);
            }
            if (!IS_ATOM_INT(_temps_43408)){
                _temps_43408 = (long)DBL_PTR(_temps_43408)->dbl;
            }
            _23147 = NOVALUE;

            /** 					sequence names = {}*/
            RefDS(_21815);
            DeRef(_names_43642);
            _names_43642 = _21815;

            /** 					while temps != 0 do*/
L29: 
            if (_temps_43408 == 0)
            goto L2A; // [1069] 1261

            /** 						if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23150 = (int)*(((s1_ptr)_2)->base + _temps_43408);
            _2 = (int)SEQ_PTR(_23150);
            _23151 = (int)*(((s1_ptr)_2)->base + 4);
            _23150 = NOVALUE;
            if (binary_op_a(EQUALS, _23151, 2)){
                _23151 = NOVALUE;
                goto L2B; // [1089] 1221
            }
            _23151 = NOVALUE;

            /** 							sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23153 = (int)*(((s1_ptr)_2)->base + _temps_43408);
            _2 = (int)SEQ_PTR(_23153);
            _23154 = (int)*(((s1_ptr)_2)->base + 34);
            _23153 = NOVALUE;
            DeRefi(_name_43652);
            _name_43652 = EPrintf(-9999999, _21908, _23154);
            _23154 = NOVALUE;

            /** 							if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23156 = (int)*(((s1_ptr)_2)->base + _temps_43408);
            _2 = (int)SEQ_PTR(_23156);
            _23157 = (int)*(((s1_ptr)_2)->base + 34);
            _23156 = NOVALUE;
            _2 = (int)SEQ_PTR(_35temp_name_type_16050);
            if (!IS_ATOM_INT(_23157)){
                _23158 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23157)->dbl));
            }
            else{
                _23158 = (int)*(((s1_ptr)_2)->base + _23157);
            }
            _2 = (int)SEQ_PTR(_23158);
            _23159 = (int)*(((s1_ptr)_2)->base + 1);
            _23158 = NOVALUE;
            if (IS_ATOM_INT(_23159)) {
                _23160 = (_23159 != 0);
            }
            else {
                _23160 = binary_op(NOTEQ, _23159, 0);
            }
            _23159 = NOVALUE;
            if (IS_ATOM_INT(_23160)) {
                if (_23160 == 0) {
                    goto L2C; // [1143] 1217
                }
            }
            else {
                if (DBL_PTR(_23160)->dbl == 0.0) {
                    goto L2C; // [1143] 1217
                }
            }
            _23162 = find_from(_name_43652, _names_43642, 1);
            _23163 = (_23162 == 0);
            _23162 = NOVALUE;
            if (_23163 == 0)
            {
                DeRef(_23163);
                _23163 = NOVALUE;
                goto L2C; // [1156] 1217
            }
            else{
                DeRef(_23163);
                _23163 = NOVALUE;
            }

            /** 								c_stmt0("int ")*/
            RefDS(_22533);
            _57c_stmt0(_22533);

            /** 								c_puts( name )*/
            RefDS(_name_43652);
            _54c_puts(_name_43652);

            /** 								c_puts(" = NOVALUE")*/
            RefDS(_23164);
            _54c_puts(_23164);

            /** 								target = {NOVALUE, NOVALUE}*/
            Ref(_35NOVALUE_15823);
            Ref(_35NOVALUE_15823);
            DeRef(_58target_27098);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _35NOVALUE_15823;
            ((int *)_2)[2] = _35NOVALUE_15823;
            _58target_27098 = MAKE_SEQ(_1);

            /** 								SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_58target_27098);
            _57SetBBType(_temps_43408, 1, _58target_27098, 16, 0);

            /** 								ifdef DEBUG then*/

            /** 									c_puts(";\n")*/
            RefDS(_22045);
            _54c_puts(_22045);

            /** 								names = prepend( names, name )*/
            RefDS(_name_43652);
            Prepend(&_names_43642, _names_43642, _name_43652);
            goto L2D; // [1214] 1220
L2C: 

            /** 								ifdef DEBUG then*/
L2D: 
L2B: 
            DeRefi(_name_43652);
            _name_43652 = NOVALUE;

            /** 						SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _36SymTab_14981 = MAKE_SEQ(_2);
            }
            _3 = (int)(_temps_43408 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 36);
            _1 = *(int *)_2;
            *(int *)_2 = 16;
            DeRef(_1);
            _23169 = NOVALUE;

            /** 						temps = SymTab[temps][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23171 = (int)*(((s1_ptr)_2)->base + _temps_43408);
            _2 = (int)SEQ_PTR(_23171);
            _temps_43408 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_43408)){
                _temps_43408 = (long)DBL_PTR(_temps_43408)->dbl;
            }
            _23171 = NOVALUE;

            /** 					end while*/
            goto L29; // [1258] 1069
L2A: 

            /** 					Initializing = FALSE*/
            _35Initializing_16048 = _13FALSE_435;

            /** 					if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23173 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23173);
            _23174 = (int)*(((s1_ptr)_2)->base + 37);
            _23173 = NOVALUE;
            if (_23174 == 0) {
                _23174 = NOVALUE;
                goto L2E; // [1284] 1295
            }
            else {
                if (!IS_ATOM_INT(_23174) && DBL_PTR(_23174)->dbl == 0.0){
                    _23174 = NOVALUE;
                    goto L2E; // [1284] 1295
                }
                _23174 = NOVALUE;
            }
            _23174 = NOVALUE;

            /** 						c_stmt0("int _0, _1, _2, _3;\n\n")*/
            RefDS(_23175);
            _57c_stmt0(_23175);
            goto L2F; // [1292] 1301
L2E: 

            /** 						c_stmt0("int _0, _1, _2;\n\n")*/
            RefDS(_23176);
            _57c_stmt0(_23176);
L2F: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23177 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23177);
            _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43405)){
                _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
            }
            _23177 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23179 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23179);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                _23180 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
            }
            else{
                _23180 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
            }
            _23179 = NOVALUE;
            {
                int _p_43711;
                _p_43711 = 1;
L30: 
                if (binary_op_a(GREATER, _p_43711, _23180)){
                    goto L31; // [1331] 1682
                }

                /** 						SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _36SymTab_14981 = MAKE_SEQ(_2);
                }
                _3 = (int)(_sp_43405 + ((s1_ptr)_2)->base);
                _2 = (int)SEQ_PTR(*(int *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    *(int *)_3 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 35);
                _1 = *(int *)_2;
                *(int *)_2 = _13FALSE_435;
                DeRef(_1);
                _23181 = NOVALUE;

                /** 						if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23183 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23183);
                _23184 = (int)*(((s1_ptr)_2)->base + 43);
                _23183 = NOVALUE;
                if (binary_op_a(NOTEQ, _23184, 8)){
                    _23184 = NOVALUE;
                    goto L32; // [1371] 1435
                }
                _23184 = NOVALUE;

                /** 							target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23186 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23186);
                _23187 = (int)*(((s1_ptr)_2)->base + 51);
                _23186 = NOVALUE;
                Ref(_23187);
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23187;
                if( _1 != _23187 ){
                    DeRef(_1);
                }
                _23187 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23188 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23188);
                _23189 = (int)*(((s1_ptr)_2)->base + 43);
                _23188 = NOVALUE;
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23190 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23190);
                _23191 = (int)*(((s1_ptr)_2)->base + 45);
                _23190 = NOVALUE;
                Ref(_23189);
                RefDS(_58target_27098);
                Ref(_23191);
                _57SetBBType(_sp_43405, _23189, _58target_27098, _23191, 0);
                _23189 = NOVALUE;
                _23191 = NOVALUE;
                goto L33; // [1432] 1659
L32: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23192 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23192);
                _23193 = (int)*(((s1_ptr)_2)->base + 43);
                _23192 = NOVALUE;
                if (binary_op_a(NOTEQ, _23193, 1)){
                    _23193 = NOVALUE;
                    goto L34; // [1451] 1575
                }
                _23193 = NOVALUE;

                /** 							if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23195 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23195);
                _23196 = (int)*(((s1_ptr)_2)->base + 47);
                _23195 = NOVALUE;
                if (binary_op_a(NOTEQ, _23196, _35NOVALUE_15823)){
                    _23196 = NOVALUE;
                    goto L35; // [1471] 1502
                }
                _23196 = NOVALUE;

                /** 								target[MIN] = MININT*/
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = -1073741824;
                DeRef(_1);

                /** 								target[MAX] = MAXINT*/
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = 1073741823;
                DeRef(_1);
                goto L36; // [1499] 1547
L35: 

                /** 								target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23198 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23198);
                _23199 = (int)*(((s1_ptr)_2)->base + 47);
                _23198 = NOVALUE;
                Ref(_23199);
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23199;
                if( _1 != _23199 ){
                    DeRef(_1);
                }
                _23199 = NOVALUE;

                /** 								target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23200 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23200);
                _23201 = (int)*(((s1_ptr)_2)->base + 48);
                _23200 = NOVALUE;
                Ref(_23201);
                _2 = (int)SEQ_PTR(_58target_27098);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _58target_27098 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _23201;
                if( _1 != _23201 ){
                    DeRef(_1);
                }
                _23201 = NOVALUE;
L36: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23202 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23202);
                _23203 = (int)*(((s1_ptr)_2)->base + 43);
                _23202 = NOVALUE;
                Ref(_23203);
                RefDS(_58target_27098);
                _57SetBBType(_sp_43405, _23203, _58target_27098, 16, 0);
                _23203 = NOVALUE;
                goto L33; // [1572] 1659
L34: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23204 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23204);
                _23205 = (int)*(((s1_ptr)_2)->base + 43);
                _23204 = NOVALUE;
                if (binary_op_a(NOTEQ, _23205, 16)){
                    _23205 = NOVALUE;
                    goto L37; // [1591] 1633
                }
                _23205 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23207 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23207);
                _23208 = (int)*(((s1_ptr)_2)->base + 43);
                _23207 = NOVALUE;
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23209 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23209);
                _23210 = (int)*(((s1_ptr)_2)->base + 45);
                _23209 = NOVALUE;
                Ref(_23208);
                RefDS(_54novalue_45126);
                Ref(_23210);
                _57SetBBType(_sp_43405, _23208, _54novalue_45126, _23210, 0);
                _23208 = NOVALUE;
                _23210 = NOVALUE;
                goto L33; // [1630] 1659
L37: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23211 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23211);
                _23212 = (int)*(((s1_ptr)_2)->base + 43);
                _23211 = NOVALUE;
                Ref(_23212);
                RefDS(_54novalue_45126);
                _57SetBBType(_sp_43405, _23212, _54novalue_45126, 16, 0);
                _23212 = NOVALUE;
L33: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23213 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23213);
                _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43405)){
                    _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
                }
                _23213 = NOVALUE;

                /** 					end for*/
                _0 = _p_43711;
                if (IS_ATOM_INT(_p_43711)) {
                    _p_43711 = _p_43711 + 1;
                    if ((long)((unsigned long)_p_43711 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43711 = NewDouble((double)_p_43711);
                    }
                }
                else {
                    _p_43711 = binary_op_a(PLUS, _p_43711, 1);
                }
                DeRef(_0);
                goto L30; // [1677] 1338
L31: 
                ;
                DeRef(_p_43711);
            }

            /** 					call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _s_43404;
            _23215 = MAKE_SEQ(_1);
            _1 = (int)SEQ_PTR(_23215);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_35Execute_id_16055].addr;
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            DeRefDS(_23215);
            _23215 = NOVALUE;

            /** 					c_puts("    ;\n}\n")*/
            RefDS(_23216);
            _54c_puts(_23216);

            /** 					if TUNIX and dll_option and is_exported( s ) then*/
            if (_40TUNIX_16116 == 0) {
                _23217 = 0;
                goto L38; // [1702] 1712
            }
            _23217 = (_57dll_option_41330 != 0);
L38: 
            if (_23217 == 0) {
                goto L39; // [1712] 2035
            }
            _23219 = _57is_exported(_s_43404);
            if (_23219 == 0) {
                DeRef(_23219);
                _23219 = NOVALUE;
                goto L39; // [1721] 2035
            }
            else {
                if (!IS_ATOM_INT(_23219) && DBL_PTR(_23219)->dbl == 0.0){
                    DeRef(_23219);
                    _23219 = NOVALUE;
                    goto L39; // [1721] 2035
                }
                DeRef(_23219);
                _23219 = NOVALUE;
            }
            DeRef(_23219);
            _23219 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _57LeftSym_41327 = _13TRUE_437;

            /** 						if TOSX then*/
            if (_40TOSX_16120 == 0)
            {
                goto L3A; // [1737] 1997
            }
            else{
            }

            /** 							c_stmt0( ret_type & SymTab[s][S_NAME] & " (" )*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23220 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23220);
            if (!IS_ATOM_INT(_35S_NAME_15641)){
                _23221 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
            }
            else{
                _23221 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
            }
            _23220 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23222;
                concat_list[1] = _23221;
                concat_list[2] = _ret_type_43537;
                Concat_N((object_ptr)&_23223, concat_list, 3);
            }
            _23221 = NOVALUE;
            _57c_stmt0(_23223);
            _23223 = NOVALUE;

            /** 							sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23224 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23224);
            _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43405)){
                _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
            }
            _23224 = NOVALUE;

            /** 							for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23226 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23226);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                _23227 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
            }
            else{
                _23227 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
            }
            _23226 = NOVALUE;
            {
                int _p_43832;
                _p_43832 = 1;
L3B: 
                if (binary_op_a(GREATER, _p_43832, _23227)){
                    goto L3C; // [1795] 1871
                }

                /** 								c_puts("int _")*/
                RefDS(_23129);
                _54c_puts(_23129);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23228 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23228);
                if (!IS_ATOM_INT(_35S_NAME_15641)){
                    _23229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
                }
                else{
                    _23229 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
                }
                _23228 = NOVALUE;
                Ref(_23229);
                _54c_puts(_23229);
                _23229 = NOVALUE;

                /** 								if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23230 = (int)*(((s1_ptr)_2)->base + _s_43404);
                _2 = (int)SEQ_PTR(_23230);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                    _23231 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
                }
                else{
                    _23231 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
                }
                _23230 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43832, _23231)){
                    _23231 = NOVALUE;
                    goto L3D; // [1838] 1848
                }
                _23231 = NOVALUE;

                /** 									c_puts(", ")*/
                RefDS(_23135);
                _54c_puts(_23135);
L3D: 

                /** 								sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23233 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23233);
                _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43405)){
                    _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
                }
                _23233 = NOVALUE;

                /** 							end for*/
                _0 = _p_43832;
                if (IS_ATOM_INT(_p_43832)) {
                    _p_43832 = _p_43832 + 1;
                    if ((long)((unsigned long)_p_43832 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43832 = NewDouble((double)_p_43832);
                    }
                }
                else {
                    _p_43832 = binary_op_a(PLUS, _p_43832, 1);
                }
                DeRef(_0);
                goto L3B; // [1866] 1802
L3C: 
                ;
                DeRef(_p_43832);
            }

            /** 							c_puts( ") {\n")*/
            RefDS(_23235);
            _54c_puts(_23235);

            /** 							c_stmt("    return @(", s)*/
            RefDS(_23236);
            _57c_stmt(_23236, _s_43404, 0);

            /** 							sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23237 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23237);
            _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43405)){
                _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
            }
            _23237 = NOVALUE;

            /** 							for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23239 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23239);
            if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                _23240 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
            }
            else{
                _23240 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
            }
            _23239 = NOVALUE;
            {
                int _p_43862;
                _p_43862 = 1;
L3E: 
                if (binary_op_a(GREATER, _p_43862, _23240)){
                    goto L3F; // [1913] 1989
                }

                /** 								c_puts("_")*/
                RefDS(_21887);
                _54c_puts(_21887);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23241 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23241);
                if (!IS_ATOM_INT(_35S_NAME_15641)){
                    _23242 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
                }
                else{
                    _23242 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
                }
                _23241 = NOVALUE;
                Ref(_23242);
                _54c_puts(_23242);
                _23242 = NOVALUE;

                /** 								if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23243 = (int)*(((s1_ptr)_2)->base + _s_43404);
                _2 = (int)SEQ_PTR(_23243);
                if (!IS_ATOM_INT(_35S_NUM_ARGS_15692)){
                    _23244 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NUM_ARGS_15692)->dbl));
                }
                else{
                    _23244 = (int)*(((s1_ptr)_2)->base + _35S_NUM_ARGS_15692);
                }
                _23243 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43862, _23244)){
                    _23244 = NOVALUE;
                    goto L40; // [1956] 1966
                }
                _23244 = NOVALUE;

                /** 									c_puts(", ")*/
                RefDS(_23135);
                _54c_puts(_23135);
L40: 

                /** 								sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_36SymTab_14981);
                _23246 = (int)*(((s1_ptr)_2)->base + _sp_43405);
                _2 = (int)SEQ_PTR(_23246);
                _sp_43405 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43405)){
                    _sp_43405 = (long)DBL_PTR(_sp_43405)->dbl;
                }
                _23246 = NOVALUE;

                /** 							end for*/
                _0 = _p_43862;
                if (IS_ATOM_INT(_p_43862)) {
                    _p_43862 = _p_43862 + 1;
                    if ((long)((unsigned long)_p_43862 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43862 = NewDouble((double)_p_43862);
                    }
                }
                else {
                    _p_43862 = binary_op_a(PLUS, _p_43862, 1);
                }
                DeRef(_0);
                goto L3E; // [1984] 1920
L3F: 
                ;
                DeRef(_p_43862);
            }

            /** 							c_puts( ");\n}\n" )	*/
            RefDS(_23248);
            _54c_puts(_23248);
            goto L41; // [1994] 2025
L3A: 

            /** 							c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (int)SEQ_PTR(_36SymTab_14981);
            _23249 = (int)*(((s1_ptr)_2)->base + _s_43404);
            _2 = (int)SEQ_PTR(_23249);
            if (!IS_ATOM_INT(_35S_NAME_15641)){
                _23250 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
            }
            else{
                _23250 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
            }
            _23249 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23251;
                concat_list[1] = _23250;
                concat_list[2] = _ret_type_43537;
                Concat_N((object_ptr)&_23252, concat_list, 3);
            }
            _23250 = NOVALUE;
            _57c_stmt(_23252, _s_43404, 0);
            _23252 = NOVALUE;
L41: 

            /** 						LeftSym = FALSE*/
            _57LeftSym_41327 = _13FALSE_435;
L39: 

            /** 					c_puts("\n\n" )*/
            RefDS(_21929);
            _54c_puts(_21929);
L14: 
            DeRefi(_ret_type_43537);
            _ret_type_43537 = NOVALUE;
            DeRef(_names_43642);
            _names_43642 = NOVALUE;

            /** 			end for*/
            _routine_no_43482 = _routine_no_43482 + 1;
            goto L12; // [2045] 359
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_43479);
        _these_routines_43479 = NOVALUE;

        /** 	end for*/
        _file_no_43428 = _file_no_43428 + 1;
        goto L5; // [2055] 85
L6: 
        ;
    }

    /** end procedure*/
    DeRefi(_buff_43409);
    DeRef(_base_name_43410);
    DeRef(_long_c_file_43411);
    DeRef(_c_file_43412);
    DeRef(_23046);
    _23046 = NOVALUE;
    DeRef(_23055);
    _23055 = NOVALUE;
    DeRef(_23069);
    _23069 = NOVALUE;
    DeRef(_23080);
    _23080 = NOVALUE;
    DeRef(_23082);
    _23082 = NOVALUE;
    DeRef(_23084);
    _23084 = NOVALUE;
    _23090 = NOVALUE;
    DeRef(_23087);
    _23087 = NOVALUE;
    DeRef(_23092);
    _23092 = NOVALUE;
    _23128 = NOVALUE;
    _23157 = NOVALUE;
    _23180 = NOVALUE;
    DeRef(_23160);
    _23160 = NOVALUE;
    _23227 = NOVALUE;
    _23240 = NOVALUE;
    return;
    ;
}



// 0x49265976
