// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _44screen_output(int _f_48153, int _msg_48154)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_48153)) {
        _1 = (long)(DBL_PTR(_f_48153)->dbl);
        DeRefDS(_f_48153);
        _f_48153 = _1;
    }

    /** 	puts(f, msg)*/
    EPuts(_f_48153, _msg_48154); // DJP 

    /** end procedure*/
    DeRefDS(_msg_48154);
    return;
    ;
}


void _44Warning(int _msg_48157, int _mask_48158, int _args_48159)
{
    int _orig_mask_48160 = NOVALUE;
    int _text_48161 = NOVALUE;
    int _w_name_48162 = NOVALUE;
    int _25162 = NOVALUE;
    int _25160 = NOVALUE;
    int _25158 = NOVALUE;
    int _25155 = NOVALUE;
    int _25150 = NOVALUE;
    int _25148 = NOVALUE;
    int _25147 = NOVALUE;
    int _25146 = NOVALUE;
    int _25145 = NOVALUE;
    int _25143 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mask_48158)) {
        _1 = (long)(DBL_PTR(_mask_48158)->dbl);
        DeRefDS(_mask_48158);
        _mask_48158 = _1;
    }

    /** 	if display_warnings = 0 then*/
    if (_44display_warnings_48141 != 0)
    goto L1; // [9] 19

    /** 		return*/
    DeRef(_msg_48157);
    DeRefDS(_args_48159);
    DeRef(_text_48161);
    DeRef(_w_name_48162);
    return;
L1: 

    /** 	if not Strict_is_on or Strict_Override then*/
    _25143 = (_35Strict_is_on_16033 == 0);
    if (_25143 != 0) {
        goto L2; // [26] 37
    }
    if (_35Strict_Override_16034 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** 		if find(mask, strict_only_warnings) then*/
    _25145 = find_from(_mask_48158, _35strict_only_warnings_16031, 1);
    if (_25145 == 0)
    {
        _25145 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25145 = NOVALUE;
    }

    /** 			return*/
    DeRef(_msg_48157);
    DeRefDS(_args_48159);
    DeRef(_text_48161);
    DeRef(_w_name_48162);
    DeRef(_25143);
    _25143 = NOVALUE;
    return;
L4: 
L3: 

    /** 	orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_48160 = _mask_48158;

    /** 	if Strict_is_on and Strict_Override = 0 then*/
    if (_35Strict_is_on_16033 == 0) {
        goto L5; // [65] 85
    }
    _25147 = (_35Strict_Override_16034 == 0);
    if (_25147 == 0)
    {
        DeRef(_25147);
        _25147 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25147);
        _25147 = NOVALUE;
    }

    /** 		mask = 0*/
    _mask_48158 = 0;
L5: 

    /** 	if mask = 0 or and_bits(OpWarning, mask) then*/
    _25148 = (_mask_48158 == 0);
    if (_25148 != 0) {
        goto L6; // [91] 106
    }
    {unsigned long tu;
         tu = (unsigned long)_35OpWarning_16035 & (unsigned long)_mask_48158;
         _25150 = MAKE_UINT(tu);
    }
    if (_25150 == 0) {
        DeRef(_25150);
        _25150 = NOVALUE;
        goto L7; // [102] 213
    }
    else {
        if (!IS_ATOM_INT(_25150) && DBL_PTR(_25150)->dbl == 0.0){
            DeRef(_25150);
            _25150 = NOVALUE;
            goto L7; // [102] 213
        }
        DeRef(_25150);
        _25150 = NOVALUE;
    }
    DeRef(_25150);
    _25150 = NOVALUE;
L6: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48160 == 0)
    goto L8; // [108] 122

    /** 			orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_48160 = find_from(_orig_mask_48160, _35warning_flags_16010, 1);
L8: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48160 == 0)
    goto L9; // [124] 145

    /** 			w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (int)SEQ_PTR(_35warning_names_16012);
    _25155 = (int)*(((s1_ptr)_2)->base + _orig_mask_48160);
    {
        int concat_list[3];

        concat_list[0] = _25156;
        concat_list[1] = _25155;
        concat_list[2] = _25154;
        Concat_N((object_ptr)&_w_name_48162, concat_list, 3);
    }
    _25155 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** 			w_name = "" -- not maskable*/
    RefDS(_21815);
    DeRef(_w_name_48162);
    _w_name_48162 = _21815;
LA: 

    /** 		if atom(msg) then*/
    _25158 = IS_ATOM(_msg_48157);
    if (_25158 == 0)
    {
        _25158 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25158 = NOVALUE;
    }

    /** 			msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_48157);
    RefDS(_args_48159);
    _0 = _msg_48157;
    _msg_48157 = _45GetMsgText(_msg_48157, 1, _args_48159);
    DeRef(_0);
LB: 

    /** 		text = GetMsgText(204, 0, {w_name, msg})*/
    Ref(_msg_48157);
    RefDS(_w_name_48162);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _w_name_48162;
    ((int *)_2)[2] = _msg_48157;
    _25160 = MAKE_SEQ(_1);
    _0 = _text_48161;
    _text_48161 = _45GetMsgText(204, 0, _25160);
    DeRef(_0);
    _25160 = NOVALUE;

    /** 		if find(text, warning_list) then*/
    _25162 = find_from(_text_48161, _44warning_list_48150, 1);
    if (_25162 == 0)
    {
        _25162 = NOVALUE;
        goto LC; // [195] 204
    }
    else{
        _25162 = NOVALUE;
    }

    /** 			return -- duplicate*/
    DeRef(_msg_48157);
    DeRefDS(_args_48159);
    DeRefDS(_text_48161);
    DeRefDS(_w_name_48162);
    DeRef(_25143);
    _25143 = NOVALUE;
    DeRef(_25148);
    _25148 = NOVALUE;
    return;
LC: 

    /** 		warning_list = append(warning_list, text)*/
    RefDS(_text_48161);
    Append(&_44warning_list_48150, _44warning_list_48150, _text_48161);
L7: 

    /** end procedure*/
    DeRef(_msg_48157);
    DeRefDS(_args_48159);
    DeRef(_text_48161);
    DeRef(_w_name_48162);
    DeRef(_25143);
    _25143 = NOVALUE;
    DeRef(_25148);
    _25148 = NOVALUE;
    return;
    ;
}


void _44Log_warnings(int _policy_48207)
{
    int _25170 = NOVALUE;
    int _25169 = NOVALUE;
    int _25168 = NOVALUE;
    int _25167 = NOVALUE;
    int _25165 = NOVALUE;
    int _25164 = NOVALUE;
    int _0, _1, _2;
    

    /** 	display_warnings = 1*/
    _44display_warnings_48141 = 1;

    /** 	if sequence(policy) then*/
    _25164 = IS_SEQUENCE(_policy_48207);
    if (_25164 == 0)
    {
        _25164 = NOVALUE;
        goto L1; // [11] 34
    }
    else{
        _25164 = NOVALUE;
    }

    /** 		if length(policy)=0 then*/
    if (IS_SEQUENCE(_policy_48207)){
            _25165 = SEQ_PTR(_policy_48207)->length;
    }
    else {
        _25165 = 1;
    }
    if (_25165 != 0)
    goto L2; // [19] 82

    /** 			policy = STDERR*/
    DeRef(_policy_48207);
    _policy_48207 = 2;
    goto L2; // [31] 82
L1: 

    /** 		if policy >= 0 and policy < STDERR+1 then*/
    if (IS_ATOM_INT(_policy_48207)) {
        _25167 = (_policy_48207 >= 0);
    }
    else {
        _25167 = binary_op(GREATEREQ, _policy_48207, 0);
    }
    if (IS_ATOM_INT(_25167)) {
        if (_25167 == 0) {
            goto L3; // [40] 68
        }
    }
    else {
        if (DBL_PTR(_25167)->dbl == 0.0) {
            goto L3; // [40] 68
        }
    }
    _25169 = 3;
    if (IS_ATOM_INT(_policy_48207)) {
        _25170 = (_policy_48207 < 3);
    }
    else {
        _25170 = binary_op(LESS, _policy_48207, 3);
    }
    _25169 = NOVALUE;
    if (_25170 == 0) {
        DeRef(_25170);
        _25170 = NOVALUE;
        goto L3; // [55] 68
    }
    else {
        if (!IS_ATOM_INT(_25170) && DBL_PTR(_25170)->dbl == 0.0){
            DeRef(_25170);
            _25170 = NOVALUE;
            goto L3; // [55] 68
        }
        DeRef(_25170);
        _25170 = NOVALUE;
    }
    DeRef(_25170);
    _25170 = NOVALUE;

    /** 			policy  = STDERR*/
    DeRef(_policy_48207);
    _policy_48207 = 2;
    goto L4; // [65] 81
L3: 

    /** 		elsif policy < 0 then*/
    if (binary_op_a(GREATEREQ, _policy_48207, 0)){
        goto L5; // [70] 80
    }

    /** 			display_warnings = 0*/
    _44display_warnings_48141 = 0;
L5: 
L4: 
L2: 

    /** end procedure*/
    DeRef(_policy_48207);
    DeRef(_25167);
    _25167 = NOVALUE;
    return;
    ;
}


int _44ShowWarnings()
{
    int _c_48226 = NOVALUE;
    int _errfile_48227 = NOVALUE;
    int _twf_48228 = NOVALUE;
    int _25201 = NOVALUE;
    int _25198 = NOVALUE;
    int _25197 = NOVALUE;
    int _25196 = NOVALUE;
    int _25195 = NOVALUE;
    int _25194 = NOVALUE;
    int _25193 = NOVALUE;
    int _25191 = NOVALUE;
    int _25190 = NOVALUE;
    int _25189 = NOVALUE;
    int _25187 = NOVALUE;
    int _25186 = NOVALUE;
    int _25185 = NOVALUE;
    int _25184 = NOVALUE;
    int _25182 = NOVALUE;
    int _25178 = NOVALUE;
    int _25176 = NOVALUE;
    int _25175 = NOVALUE;
    int _25174 = NOVALUE;
    int _25172 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if display_warnings = 0 or length(warning_list) = 0 then*/
    _25172 = (_44display_warnings_48141 == 0);
    if (_25172 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_44warning_list_48150)){
            _25174 = SEQ_PTR(_44warning_list_48150)->length;
    }
    else {
        _25174 = 1;
    }
    _25175 = (_25174 == 0);
    _25174 = NOVALUE;
    if (_25175 == 0)
    {
        DeRef(_25175);
        _25175 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25175);
        _25175 = NOVALUE;
    }
L1: 

    /** 		return length(warning_list)*/
    if (IS_SEQUENCE(_44warning_list_48150)){
            _25176 = SEQ_PTR(_44warning_list_48150)->length;
    }
    else {
        _25176 = 1;
    }
    DeRef(_25172);
    _25172 = NOVALUE;
    return _25176;
L2: 

    /** 	if TempErrFile > 0 then*/
    if (_44TempErrFile_48139 <= 0)
    goto L3; // [43] 57

    /** 		errfile = TempErrFile*/
    _errfile_48227 = _44TempErrFile_48139;
    goto L4; // [54] 67
L3: 

    /** 		errfile = STDERR*/
    _errfile_48227 = 2;
L4: 

    /** 	if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_35TempWarningName_15982))
    _25178 = 1;
    else if (IS_ATOM_DBL(_35TempWarningName_15982))
    _25178 = IS_ATOM_INT(DoubleToInt(_35TempWarningName_15982));
    else
    _25178 = 0;
    if (_25178 != 0)
    goto L5; // [74] 179
    _25178 = NOVALUE;

    /** 		twf = open(TempWarningName,"w")*/
    _twf_48228 = EOpen(_35TempWarningName_15982, _21921, 0);

    /** 		if twf = -1 then*/
    if (_twf_48228 != -1)
    goto L6; // [88] 136

    /** 			ShowMsg(errfile, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_35TempWarningName_15982);
    *((int *)(_2+4)) = _35TempWarningName_15982;
    _25182 = MAKE_SEQ(_1);
    _45ShowMsg(_errfile_48227, 205, _25182, 1);
    _25182 = NOVALUE;

    /** 			if errfile != STDERR then*/
    if (_errfile_48227 == 2)
    goto L7; // [112] 173

    /** 				ShowMsg(STDERR, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_35TempWarningName_15982);
    *((int *)(_2+4)) = _35TempWarningName_15982;
    _25184 = MAKE_SEQ(_1);
    _45ShowMsg(2, 205, _25184, 1);
    _25184 = NOVALUE;
    goto L7; // [133] 173
L6: 

    /** 			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_44warning_list_48150)){
            _25185 = SEQ_PTR(_44warning_list_48150)->length;
    }
    else {
        _25185 = 1;
    }
    {
        int _i_48259;
        _i_48259 = 1;
L8: 
        if (_i_48259 > _25185){
            goto L9; // [143] 168
        }

        /** 				puts(twf, warning_list[i])*/
        _2 = (int)SEQ_PTR(_44warning_list_48150);
        _25186 = (int)*(((s1_ptr)_2)->base + _i_48259);
        EPuts(_twf_48228, _25186); // DJP 
        _25186 = NOVALUE;

        /** 			end for*/
        _i_48259 = _i_48259 + 1;
        goto L8; // [163] 150
L9: 
        ;
    }

    /** 		    close(twf)*/
    EClose(_twf_48228);
L7: 

    /** 		TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_35TempWarningName_15982);
    _35TempWarningName_15982 = 99;
L5: 

    /** 	if batch_job = 0 or errfile != STDERR then*/
    _25187 = (_35batch_job_15981 == 0);
    if (_25187 != 0) {
        goto LA; // [187] 204
    }
    _25189 = (_errfile_48227 != 2);
    if (_25189 == 0)
    {
        DeRef(_25189);
        _25189 = NOVALUE;
        goto LB; // [200] 311
    }
    else{
        DeRef(_25189);
        _25189 = NOVALUE;
    }
LA: 

    /** 		for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_44warning_list_48150)){
            _25190 = SEQ_PTR(_44warning_list_48150)->length;
    }
    else {
        _25190 = 1;
    }
    {
        int _i_48270;
        _i_48270 = 1;
LC: 
        if (_i_48270 > _25190){
            goto LD; // [211] 310
        }

        /** 			puts(errfile, warning_list[i])*/
        _2 = (int)SEQ_PTR(_44warning_list_48150);
        _25191 = (int)*(((s1_ptr)_2)->base + _i_48270);
        EPuts(_errfile_48227, _25191); // DJP 
        _25191 = NOVALUE;

        /** 			if errfile = STDERR then*/
        if (_errfile_48227 != 2)
        goto LE; // [235] 303

        /** 				if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25193 = (_i_48270 % 20);
        _25194 = (_25193 == 0);
        _25193 = NOVALUE;
        if (_25194 == 0) {
            _25195 = 0;
            goto LF; // [249] 263
        }
        _25196 = (_35batch_job_15981 == 0);
        _25195 = (_25196 != 0);
LF: 
        if (_25195 == 0) {
            goto L10; // [263] 302
        }
        _25198 = (_35test_only_15980 == 0);
        if (_25198 == 0)
        {
            DeRef(_25198);
            _25198 = NOVALUE;
            goto L10; // [274] 302
        }
        else{
            DeRef(_25198);
            _25198 = NOVALUE;
        }

        /** 					ShowMsg(errfile, 206)*/
        RefDS(_21815);
        _45ShowMsg(_errfile_48227, 206, _21815, 1);

        /** 					c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_48226 = getc((FILE*)xstdin);
            }
            else
            _c_48226 = getc(last_r_file_ptr);
        }
        else
        _c_48226 = getc(last_r_file_ptr);

        /** 					if c = 'q' then*/
        if (_c_48226 != 113)
        goto L11; // [292] 301

        /** 						exit*/
        goto LD; // [298] 310
L11: 
L10: 
LE: 

        /** 		end for*/
        _i_48270 = _i_48270 + 1;
        goto LC; // [305] 218
LD: 
        ;
    }
LB: 

    /** 	return length(warning_list)*/
    if (IS_SEQUENCE(_44warning_list_48150)){
            _25201 = SEQ_PTR(_44warning_list_48150)->length;
    }
    else {
        _25201 = 1;
    }
    DeRef(_25172);
    _25172 = NOVALUE;
    DeRef(_25187);
    _25187 = NOVALUE;
    DeRef(_25196);
    _25196 = NOVALUE;
    DeRef(_25194);
    _25194 = NOVALUE;
    return _25201;
    ;
}


void _44ShowDefines(int _errfile_48292)
{
    int _c_48293 = NOVALUE;
    int _25215 = NOVALUE;
    int _25214 = NOVALUE;
    int _25212 = NOVALUE;
    int _25211 = NOVALUE;
    int _25208 = NOVALUE;
    int _25207 = NOVALUE;
    int _25206 = NOVALUE;
    int _25205 = NOVALUE;
    int _25204 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_errfile_48292)) {
        _1 = (long)(DBL_PTR(_errfile_48292)->dbl);
        DeRefDS(_errfile_48292);
        _errfile_48292 = _1;
    }

    /** 	if errfile=0 then*/
    if (_errfile_48292 != 0)
    goto L1; // [5] 19

    /** 		errfile = STDERR*/
    _errfile_48292 = 2;
L1: 

    /** 	puts(errfile, format("\n--- [1] ---\n", {GetMsgText(207,0)}))*/
    RefDS(_21815);
    _25204 = _45GetMsgText(207, 0, _21815);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25204;
    _25205 = MAKE_SEQ(_1);
    _25204 = NOVALUE;
    RefDS(_25203);
    _25206 = _14format(_25203, _25205);
    _25205 = NOVALUE;
    EPuts(_errfile_48292, _25206); // DJP 
    DeRef(_25206);
    _25206 = NOVALUE;

    /** 	for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_35OpDefines_16041)){
            _25207 = SEQ_PTR(_35OpDefines_16041)->length;
    }
    else {
        _25207 = 1;
    }
    {
        int _i_48304;
        _i_48304 = 1;
L2: 
        if (_i_48304 > _25207){
            goto L3; // [46] 98
        }

        /** 		if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (int)SEQ_PTR(_35OpDefines_16041);
        _25208 = (int)*(((s1_ptr)_2)->base + _i_48304);
        RefDS(_25210);
        RefDS(_25209);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25209;
        ((int *)_2)[2] = _25210;
        _25211 = MAKE_SEQ(_1);
        _25212 = find_from(_25208, _25211, 1);
        _25208 = NOVALUE;
        DeRefDS(_25211);
        _25211 = NOVALUE;
        if (_25212 != 0)
        goto L4; // [70] 91

        /** 			printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (int)SEQ_PTR(_35OpDefines_16041);
        _25214 = (int)*(((s1_ptr)_2)->base + _i_48304);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25214);
        *((int *)(_2+4)) = _25214;
        _25215 = MAKE_SEQ(_1);
        _25214 = NOVALUE;
        EPrintf(_errfile_48292, _25084, _25215);
        DeRefDS(_25215);
        _25215 = NOVALUE;
L4: 

        /** 	end for*/
        _i_48304 = _i_48304 + 1;
        goto L2; // [93] 53
L3: 
        ;
    }

    /** 	puts(errfile, "-------------------\n")*/
    EPuts(_errfile_48292, _25216); // DJP 

    /** end procedure*/
    return;
    ;
}


void _44Cleanup(int _status_48321)
{
    int _w_48322 = NOVALUE;
    int _show_error_48323 = NOVALUE;
    int _25230 = NOVALUE;
    int _25229 = NOVALUE;
    int _25228 = NOVALUE;
    int _25227 = NOVALUE;
    int _25226 = NOVALUE;
    int _25225 = NOVALUE;
    int _25224 = NOVALUE;
    int _25223 = NOVALUE;
    int _25222 = NOVALUE;
    int _25221 = NOVALUE;
    int _25217 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_48321)) {
        _1 = (long)(DBL_PTR(_status_48321)->dbl);
        DeRefDS(_status_48321);
        _status_48321 = _1;
    }

    /** 	integer w, show_error = 0*/
    _show_error_48323 = 0;

    /** 	ifdef EU_EX then*/

    /** 	show_error = 1*/
    _show_error_48323 = 1;

    /** 	if object(src_file) = 0 then*/
    if( NOVALUE == _35src_file_16089 ){
        _25217 = 0;
    }
    else{
        _25217 = 1;
    }
    if (_25217 != 0)
    goto L1; // [20] 34

    /** 		src_file = -1*/
    _35src_file_16089 = -1;
    goto L2; // [31] 57
L1: 

    /** 	elsif src_file >= 0 then*/
    if (_35src_file_16089 < 0)
    goto L3; // [38] 56

    /** 		close(src_file)*/
    EClose(_35src_file_16089);

    /** 		src_file = -1*/
    _35src_file_16089 = -1;
L3: 
L2: 

    /** 	w = ShowWarnings()*/
    _w_48322 = _44ShowWarnings();
    if (!IS_ATOM_INT(_w_48322)) {
        _1 = (long)(DBL_PTR(_w_48322)->dbl);
        DeRefDS(_w_48322);
        _w_48322 = _1;
    }

    /** 	if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25221 = (_35TRANSLATE_15611 == 0);
    if (_25221 == 0) {
        _25222 = 0;
        goto L4; // [71] 89
    }
    if (_35BIND_15614 != 0) {
        _25223 = 1;
        goto L5; // [77] 85
    }
    _25223 = (_show_error_48323 != 0);
L5: 
    _25222 = (_25223 != 0);
L4: 
    if (_25222 == 0) {
        goto L6; // [89] 148
    }
    if (_w_48322 != 0) {
        DeRef(_25225);
        _25225 = 1;
        goto L7; // [93] 103
    }
    _25225 = (_44Errors_48138 != 0);
L7: 
    if (_25225 == 0)
    {
        _25225 = NOVALUE;
        goto L6; // [104] 148
    }
    else{
        _25225 = NOVALUE;
    }

    /** 		if not batch_job and not test_only then*/
    _25226 = (_35batch_job_15981 == 0);
    if (_25226 == 0) {
        goto L8; // [114] 147
    }
    _25228 = (_35test_only_15980 == 0);
    if (_25228 == 0)
    {
        DeRef(_25228);
        _25228 = NOVALUE;
        goto L8; // [124] 147
    }
    else{
        DeRef(_25228);
        _25228 = NOVALUE;
    }

    /** 			screen_output(STDERR, GetMsgText(208,0))*/
    RefDS(_21815);
    _25229 = _45GetMsgText(208, 0, _21815);
    _44screen_output(2, _25229);
    _25229 = NOVALUE;

    /** 			getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25230 = getc((FILE*)xstdin);
        }
        else
        _25230 = getc(last_r_file_ptr);
    }
    else
    _25230 = getc(last_r_file_ptr);
L8: 
L6: 

    /** 	cleanup_open_includes()*/
    _61cleanup_open_includes();

    /** 	abort(status)*/
    UserCleanup(_status_48321);

    /** end procedure*/
    DeRef(_25221);
    _25221 = NOVALUE;
    DeRef(_25226);
    _25226 = NOVALUE;
    return;
    ;
}


void _44OpenErrFile()
{
    int _25237 = NOVALUE;
    int _25236 = NOVALUE;
    int _25234 = NOVALUE;
    int _0, _1, _2;
    

    /**     if TempErrFile != -1 then*/
    if (_44TempErrFile_48139 == -1)
    goto L1; // [5] 19

    /** 		TempErrFile = open(TempErrName, "w")*/
    _44TempErrFile_48139 = EOpen(_44TempErrName_48140, _21921, 0);
L1: 

    /** 	if TempErrFile = -1 then*/
    if (_44TempErrFile_48139 != -1)
    goto L2; // [23] 64

    /** 		if length(TempErrName) > 0 then*/
    _25234 = 6;

    /** 			screen_output(STDERR, GetMsgText(209, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_44TempErrName_48140);
    *((int *)(_2+4)) = _44TempErrName_48140;
    _25236 = MAKE_SEQ(_1);
    _25237 = _45GetMsgText(209, 0, _25236);
    _25236 = NOVALUE;
    _44screen_output(2, _25237);
    _25237 = NOVALUE;

    /** 		abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** end procedure*/
    return;
    ;
}


void _44ShowErr(int _f_48370)
{
    int _msg_inlined_screen_output_at_41_48382 = NOVALUE;
    int _25244 = NOVALUE;
    int _25243 = NOVALUE;
    int _25242 = NOVALUE;
    int _25240 = NOVALUE;
    int _25238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _25238 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _25238 = 1;
    }
    if (_25238 != 0)
    goto L1; // [10] 20

    /** 		return*/
    return;
L1: 

    /** 	if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (int)SEQ_PTR(_44ThisLine_48142);
    _25240 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25240, 26)){
        _25240 = NOVALUE;
        goto L2; // [30] 62
    }
    _25240 = NOVALUE;

    /** 		screen_output(f, GetMsgText(210,0))*/
    RefDS(_21815);
    _25242 = _45GetMsgText(210, 0, _21815);
    DeRef(_msg_inlined_screen_output_at_41_48382);
    _msg_inlined_screen_output_at_41_48382 = _25242;
    _25242 = NOVALUE;

    /** 	puts(f, msg)*/
    EPuts(_f_48370, _msg_inlined_screen_output_at_41_48382); // DJP 

    /** end procedure*/
    goto L3; // [54] 57
L3: 
    DeRef(_msg_inlined_screen_output_at_41_48382);
    _msg_inlined_screen_output_at_41_48382 = NOVALUE;
    goto L4; // [59] 79
L2: 

    /** 		screen_output(f, ThisLine)*/

    /** 	puts(f, msg)*/
    EPuts(_f_48370, _44ThisLine_48142); // DJP 

    /** end procedure*/
    goto L5; // [75] 78
L5: 
L4: 

    /** 	for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25243 = _44bp_48146 - 2;
    if ((long)((unsigned long)_25243 +(unsigned long) HIGH_BITS) >= 0){
        _25243 = NewDouble((double)_25243);
    }
    {
        int _i_48386;
        _i_48386 = 1;
L6: 
        if (binary_op_a(GREATER, _i_48386, _25243)){
            goto L7; // [87] 141
        }

        /** 		if ThisLine[i] = '\t' then*/
        _2 = (int)SEQ_PTR(_44ThisLine_48142);
        if (!IS_ATOM_INT(_i_48386)){
            _25244 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_48386)->dbl));
        }
        else{
            _25244 = (int)*(((s1_ptr)_2)->base + _i_48386);
        }
        if (binary_op_a(NOTEQ, _25244, 9)){
            _25244 = NOVALUE;
            goto L8; // [102] 121
        }
        _25244 = NOVALUE;

        /** 			screen_output(f, "\t")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48370, _23591); // DJP 

        /** end procedure*/
        goto L9; // [115] 134
        goto L9; // [118] 134
L8: 

        /** 			screen_output(f, " ")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48370, _23095); // DJP 

        /** end procedure*/
        goto LA; // [130] 133
LA: 
L9: 

        /** 	end for*/
        _0 = _i_48386;
        if (IS_ATOM_INT(_i_48386)) {
            _i_48386 = _i_48386 + 1;
            if ((long)((unsigned long)_i_48386 +(unsigned long) HIGH_BITS) >= 0){
                _i_48386 = NewDouble((double)_i_48386);
            }
        }
        else {
            _i_48386 = binary_op_a(PLUS, _i_48386, 1);
        }
        DeRef(_0);
        goto L6; // [136] 94
L7: 
        ;
        DeRef(_i_48386);
    }

    /** 	screen_output(f, "^\n\n")*/

    /** 	puts(f, msg)*/
    EPuts(_f_48370, _25246); // DJP 

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_25243);
    _25243 = NOVALUE;
    return;
    ;
}


void _44CompileErr(int _msg_48398, int _args_48399, int _preproc_48400)
{
    int _errmsg_48401 = NOVALUE;
    int _25267 = NOVALUE;
    int _25263 = NOVALUE;
    int _25262 = NOVALUE;
    int _25261 = NOVALUE;
    int _25260 = NOVALUE;
    int _25259 = NOVALUE;
    int _25258 = NOVALUE;
    int _25256 = NOVALUE;
    int _25255 = NOVALUE;
    int _25253 = NOVALUE;
    int _25252 = NOVALUE;
    int _25251 = NOVALUE;
    int _25247 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_preproc_48400)) {
        _1 = (long)(DBL_PTR(_preproc_48400)->dbl);
        DeRefDS(_preproc_48400);
        _preproc_48400 = _1;
    }

    /** 	if integer(msg) then*/
    if (IS_ATOM_INT(_msg_48398))
    _25247 = 1;
    else if (IS_ATOM_DBL(_msg_48398))
    _25247 = IS_ATOM_INT(DoubleToInt(_msg_48398));
    else
    _25247 = 0;
    if (_25247 == 0)
    {
        _25247 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25247 = NOVALUE;
    }

    /** 		msg = GetMsgText(msg)*/
    Ref(_msg_48398);
    RefDS(_21815);
    _0 = _msg_48398;
    _msg_48398 = _45GetMsgText(_msg_48398, 1, _21815);
    DeRef(_0);
L1: 

    /** 	msg = format(msg, args)*/
    Ref(_msg_48398);
    Ref(_args_48399);
    _0 = _msg_48398;
    _msg_48398 = _14format(_msg_48398, _args_48399);
    DeRef(_0);

    /** 	Errors += 1*/
    _44Errors_48138 = _44Errors_48138 + 1;

    /** 	if not preproc and length(known_files) then*/
    _25251 = (_preproc_48400 == 0);
    if (_25251 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_36known_files_14982)){
            _25253 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _25253 = 1;
    }
    if (_25253 == 0)
    {
        _25253 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25253 = NOVALUE;
    }

    /** 		errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _25255 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25255);
    *((int *)(_2+4)) = _25255;
    *((int *)(_2+8)) = _35line_number_15969;
    Ref(_msg_48398);
    *((int *)(_2+12)) = _msg_48398;
    _25256 = MAKE_SEQ(_1);
    _25255 = NOVALUE;
    DeRef(_errmsg_48401);
    _errmsg_48401 = EPrintf(-9999999, _25254, _25256);
    DeRefDS(_25256);
    _25256 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** 		errmsg = msg*/
    Ref(_msg_48398);
    DeRef(_errmsg_48401);
    _errmsg_48401 = _msg_48398;

    /** 		if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_48398)){
            _25258 = SEQ_PTR(_msg_48398)->length;
    }
    else {
        _25258 = 1;
    }
    _25259 = (_25258 > 0);
    _25258 = NOVALUE;
    if (_25259 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_48398)){
            _25261 = SEQ_PTR(_msg_48398)->length;
    }
    else {
        _25261 = 1;
    }
    _2 = (int)SEQ_PTR(_msg_48398);
    _25262 = (int)*(((s1_ptr)_2)->base + _25261);
    if (IS_ATOM_INT(_25262)) {
        _25263 = (_25262 != 10);
    }
    else {
        _25263 = binary_op(NOTEQ, _25262, 10);
    }
    _25262 = NOVALUE;
    if (_25263 == 0) {
        DeRef(_25263);
        _25263 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25263) && DBL_PTR(_25263)->dbl == 0.0){
            DeRef(_25263);
            _25263 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25263);
        _25263 = NOVALUE;
    }
    DeRef(_25263);
    _25263 = NOVALUE;

    /** 			errmsg &= '\n'*/
    Append(&_errmsg_48401, _errmsg_48401, 10);
L4: 
L3: 

    /** 	if not preproc then*/
    if (_preproc_48400 != 0)
    goto L5; // [123] 131

    /** 		OpenErrFile() -- exits if error filename is ""*/
    _44OpenErrFile();
L5: 

    /** 	screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_48401);
    _44screen_output(2, _errmsg_48401);

    /** 	if not preproc then*/
    if (_preproc_48400 != 0)
    goto L6; // [143] 196

    /** 		ShowErr(STDERR)*/
    _44ShowErr(2);

    /** 		puts(TempErrFile, errmsg)*/
    EPuts(_44TempErrFile_48139, _errmsg_48401); // DJP 

    /** 		ShowErr(TempErrFile)*/
    _44ShowErr(_44TempErrFile_48139);

    /** 		ShowWarnings()*/
    _25267 = _44ShowWarnings();

    /** 		ShowDefines(TempErrFile)*/
    _44ShowDefines(_44TempErrFile_48139);

    /** 		close(TempErrFile)*/
    EClose(_44TempErrFile_48139);

    /** 		TempErrFile = -2*/
    _44TempErrFile_48139 = -2;

    /** 		Cleanup(1)*/
    _44Cleanup(1);
L6: 

    /** end procedure*/
    DeRef(_msg_48398);
    DeRef(_args_48399);
    DeRef(_errmsg_48401);
    DeRef(_25251);
    _25251 = NOVALUE;
    DeRef(_25259);
    _25259 = NOVALUE;
    DeRef(_25267);
    _25267 = NOVALUE;
    return;
    ;
}


void _44InternalErr(int _msgno_48444, int _args_48445)
{
    int _msg_48446 = NOVALUE;
    int _25282 = NOVALUE;
    int _25281 = NOVALUE;
    int _25280 = NOVALUE;
    int _25279 = NOVALUE;
    int _25278 = NOVALUE;
    int _25277 = NOVALUE;
    int _25276 = NOVALUE;
    int _25275 = NOVALUE;
    int _25274 = NOVALUE;
    int _25273 = NOVALUE;
    int _25272 = NOVALUE;
    int _25269 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_msgno_48444)) {
        _1 = (long)(DBL_PTR(_msgno_48444)->dbl);
        DeRefDS(_msgno_48444);
        _msgno_48444 = _1;
    }

    /** 	if atom(args) then*/
    _25269 = IS_ATOM(_args_48445);
    if (_25269 == 0)
    {
        _25269 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25269 = NOVALUE;
    }

    /** 		args = {args}*/
    _0 = _args_48445;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_args_48445);
    *((int *)(_2+4)) = _args_48445;
    _args_48445 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_48445);
    _0 = _msg_48446;
    _msg_48446 = _45GetMsgText(_msgno_48444, 1, _args_48445);
    DeRef(_0);

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [32] 56
    }
    else{
    }

    /** 		screen_output(STDERR, GetMsgText(211, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_48446);
    *((int *)(_2+4)) = _msg_48446;
    _25272 = MAKE_SEQ(_1);
    _25273 = _45GetMsgText(211, 1, _25272);
    _25272 = NOVALUE;
    _44screen_output(2, _25273);
    _25273 = NOVALUE;
    goto L3; // [53] 87
L2: 

    /** 		screen_output(STDERR, GetMsgText(212, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _25274 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25274);
    *((int *)(_2+4)) = _25274;
    *((int *)(_2+8)) = _35line_number_15969;
    RefDS(_msg_48446);
    *((int *)(_2+12)) = _msg_48446;
    _25275 = MAKE_SEQ(_1);
    _25274 = NOVALUE;
    _25276 = _45GetMsgText(212, 1, _25275);
    _25275 = NOVALUE;
    _44screen_output(2, _25276);
    _25276 = NOVALUE;
L3: 

    /** 	if not batch_job and not test_only then*/
    _25277 = (_35batch_job_15981 == 0);
    if (_25277 == 0) {
        goto L4; // [94] 127
    }
    _25279 = (_35test_only_15980 == 0);
    if (_25279 == 0)
    {
        DeRef(_25279);
        _25279 = NOVALUE;
        goto L4; // [104] 127
    }
    else{
        DeRef(_25279);
        _25279 = NOVALUE;
    }

    /** 		screen_output(STDERR, GetMsgText(208, 0))*/
    RefDS(_21815);
    _25280 = _45GetMsgText(208, 0, _21815);
    _44screen_output(2, _25280);
    _25280 = NOVALUE;

    /** 		getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25281 = getc((FILE*)xstdin);
        }
        else
        _25281 = getc(last_r_file_ptr);
    }
    else
    _25281 = getc(last_r_file_ptr);
L4: 

    /** 	machine_proc(67, GetMsgText(213))*/
    RefDS(_21815);
    _25282 = _45GetMsgText(213, 1, _21815);
    machine(67, _25282);
    DeRef(_25282);
    _25282 = NOVALUE;

    /** end procedure*/
    DeRef(_args_48445);
    DeRef(_msg_48446);
    DeRef(_25277);
    _25277 = NOVALUE;
    return;
    ;
}



// 0xC279ABB8
