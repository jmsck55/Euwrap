// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _51regex(int _o_21162)
{
    int _12247 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(o)*/
    _12247 = IS_SEQUENCE(_o_21162);
    DeRef(_o_21162);
    return _12247;
    ;
}


int _51new(int _pattern_21202, int _options_21203)
{
    int _12267 = NOVALUE;
    int _12266 = NOVALUE;
    int _12264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12264 = 0;
    if (_12264 == 0)
    {
        _12264 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _12264 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21203 = _20or_all(_options_21203);
L1: 

    /** 	return machine_func(M_PCRE_COMPILE, { pattern, options })*/
    Ref(_options_21203);
    Ref(_pattern_21202);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pattern_21202;
    ((int *)_2)[2] = _options_21203;
    _12266 = MAKE_SEQ(_1);
    _12267 = machine(68, _12266);
    DeRefDS(_12266);
    _12266 = NOVALUE;
    DeRef(_pattern_21202);
    DeRef(_options_21203);
    return _12267;
    ;
}


int _51get_ovector_size(int _ex_21222, int _maxsize_21223)
{
    int _m_21224 = NOVALUE;
    int _12275 = NOVALUE;
    int _12272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer m = machine_func(M_PCRE_GET_OVECTOR_SIZE, {ex})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_ex_21222);
    *((int *)(_2+4)) = _ex_21222;
    _12272 = MAKE_SEQ(_1);
    _m_21224 = machine(97, _12272);
    DeRefDS(_12272);
    _12272 = NOVALUE;
    if (!IS_ATOM_INT(_m_21224)) {
        _1 = (long)(DBL_PTR(_m_21224)->dbl);
        DeRefDS(_m_21224);
        _m_21224 = _1;
    }

    /** 	if (m > maxsize) then*/
    if (_m_21224 <= 30)
    goto L1; // [17] 28

    /** 		return maxsize*/
    DeRef(_ex_21222);
    return 30;
L1: 

    /** 	return m+1*/
    _12275 = _m_21224 + 1;
    if (_12275 > MAXINT){
        _12275 = NewDouble((double)_12275);
    }
    DeRef(_ex_21222);
    return _12275;
    ;
}


int _51find(int _re_21232, int _haystack_21234, int _from_21235, int _options_21236, int _size_21237)
{
    int _12282 = NOVALUE;
    int _12281 = NOVALUE;
    int _12280 = NOVALUE;
    int _12277 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_21237)) {
        _1 = (long)(DBL_PTR(_size_21237)->dbl);
        DeRefDS(_size_21237);
        _size_21237 = _1;
    }

    /** 	if sequence(options) then */
    _12277 = IS_SEQUENCE(_options_21236);
    if (_12277 == 0)
    {
        _12277 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _12277 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    Ref(_options_21236);
    _0 = _options_21236;
    _options_21236 = _20or_all(_options_21236);
    DeRef(_0);
L1: 

    /** 	if size < 0 then*/
    if (_size_21237 >= 0)
    goto L2; // [22] 32

    /** 		size = 0*/
    _size_21237 = 0;
L2: 

    /** 	return machine_func(M_PCRE_EXEC, { re, haystack, length(haystack), options, from, size })*/
    if (IS_SEQUENCE(_haystack_21234)){
            _12280 = SEQ_PTR(_haystack_21234)->length;
    }
    else {
        _12280 = 1;
    }
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_re_21232);
    *((int *)(_2+4)) = _re_21232;
    Ref(_haystack_21234);
    *((int *)(_2+8)) = _haystack_21234;
    *((int *)(_2+12)) = _12280;
    Ref(_options_21236);
    *((int *)(_2+16)) = _options_21236;
    *((int *)(_2+20)) = _from_21235;
    *((int *)(_2+24)) = _size_21237;
    _12281 = MAKE_SEQ(_1);
    _12280 = NOVALUE;
    _12282 = machine(70, _12281);
    DeRefDS(_12281);
    _12281 = NOVALUE;
    DeRef(_re_21232);
    DeRef(_haystack_21234);
    DeRef(_options_21236);
    return _12282;
    ;
}


int _51has_match(int _re_21278, int _haystack_21280, int _from_21281, int _options_21282)
{
    int _12299 = NOVALUE;
    int _12298 = NOVALUE;
    int _12297 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return sequence(find(re, haystack, from, options))*/
    Ref(_re_21278);
    _12297 = _51get_ovector_size(_re_21278, 30);
    Ref(_re_21278);
    Ref(_haystack_21280);
    _12298 = _51find(_re_21278, _haystack_21280, 1, 0, _12297);
    _12297 = NOVALUE;
    _12299 = IS_SEQUENCE(_12298);
    DeRef(_12298);
    _12298 = NOVALUE;
    DeRef(_re_21278);
    DeRef(_haystack_21280);
    return _12299;
    ;
}


int _51matches(int _re_21312, int _haystack_21314, int _from_21315, int _options_21316)
{
    int _str_offsets_21320 = NOVALUE;
    int _match_data_21322 = NOVALUE;
    int _tmp_21332 = NOVALUE;
    int _12336 = NOVALUE;
    int _12335 = NOVALUE;
    int _12334 = NOVALUE;
    int _12333 = NOVALUE;
    int _12332 = NOVALUE;
    int _12330 = NOVALUE;
    int _12329 = NOVALUE;
    int _12328 = NOVALUE;
    int _12327 = NOVALUE;
    int _12325 = NOVALUE;
    int _12324 = NOVALUE;
    int _12323 = NOVALUE;
    int _12322 = NOVALUE;
    int _12320 = NOVALUE;
    int _12319 = NOVALUE;
    int _12318 = NOVALUE;
    int _12315 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(options) then */
    _12315 = 0;
    if (_12315 == 0)
    {
        _12315 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _12315 = NOVALUE;
    }

    /** 		options = math:or_all(options) */
    _options_21316 = _20or_all(0);
L1: 

    /** 	integer str_offsets = and_bits(STRING_OFFSETS, options)*/
    if (IS_ATOM_INT(_options_21316)) {
        {unsigned long tu;
             tu = (unsigned long)201326592 & (unsigned long)_options_21316;
             _str_offsets_21320 = MAKE_UINT(tu);
        }
    }
    else {
        _str_offsets_21320 = binary_op(AND_BITS, 201326592, _options_21316);
    }
    if (!IS_ATOM_INT(_str_offsets_21320)) {
        _1 = (long)(DBL_PTR(_str_offsets_21320)->dbl);
        DeRefDS(_str_offsets_21320);
        _str_offsets_21320 = _1;
    }

    /** 	object match_data = find(re, haystack, from, and_bits(options, not_bits(STRING_OFFSETS)))*/
    _12318 = not_bits(201326592);
    if (IS_ATOM_INT(_options_21316) && IS_ATOM_INT(_12318)) {
        {unsigned long tu;
             tu = (unsigned long)_options_21316 & (unsigned long)_12318;
             _12319 = MAKE_UINT(tu);
        }
    }
    else {
        _12319 = binary_op(AND_BITS, _options_21316, _12318);
    }
    DeRef(_12318);
    _12318 = NOVALUE;
    Ref(_re_21312);
    _12320 = _51get_ovector_size(_re_21312, 30);
    Ref(_re_21312);
    Ref(_haystack_21314);
    _0 = _match_data_21322;
    _match_data_21322 = _51find(_re_21312, _haystack_21314, _from_21315, _12319, _12320);
    DeRef(_0);
    _12319 = NOVALUE;
    _12320 = NOVALUE;

    /** 	if atom(match_data) then */
    _12322 = IS_ATOM(_match_data_21322);
    if (_12322 == 0)
    {
        _12322 = NOVALUE;
        goto L2; // [53] 63
    }
    else{
        _12322 = NOVALUE;
    }

    /** 		return ERROR_NOMATCH */
    DeRef(_re_21312);
    DeRef(_haystack_21314);
    DeRef(_options_21316);
    DeRef(_match_data_21322);
    return -1;
L2: 

    /** 	for i = 1 to length(match_data) do*/
    if (IS_SEQUENCE(_match_data_21322)){
            _12323 = SEQ_PTR(_match_data_21322)->length;
    }
    else {
        _12323 = 1;
    }
    {
        int _i_21330;
        _i_21330 = 1;
L3: 
        if (_i_21330 > _12323){
            goto L4; // [68] 181
        }

        /** 		sequence tmp*/

        /** 		if match_data[i][1] = 0 then*/
        _2 = (int)SEQ_PTR(_match_data_21322);
        _12324 = (int)*(((s1_ptr)_2)->base + _i_21330);
        _2 = (int)SEQ_PTR(_12324);
        _12325 = (int)*(((s1_ptr)_2)->base + 1);
        _12324 = NOVALUE;
        if (binary_op_a(NOTEQ, _12325, 0)){
            _12325 = NOVALUE;
            goto L5; // [87] 101
        }
        _12325 = NOVALUE;

        /** 			tmp = ""*/
        RefDS(_5);
        DeRef(_tmp_21332);
        _tmp_21332 = _5;
        goto L6; // [98] 125
L5: 

        /** 			tmp = haystack[match_data[i][1]..match_data[i][2]]*/
        _2 = (int)SEQ_PTR(_match_data_21322);
        _12327 = (int)*(((s1_ptr)_2)->base + _i_21330);
        _2 = (int)SEQ_PTR(_12327);
        _12328 = (int)*(((s1_ptr)_2)->base + 1);
        _12327 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21322);
        _12329 = (int)*(((s1_ptr)_2)->base + _i_21330);
        _2 = (int)SEQ_PTR(_12329);
        _12330 = (int)*(((s1_ptr)_2)->base + 2);
        _12329 = NOVALUE;
        rhs_slice_target = (object_ptr)&_tmp_21332;
        RHS_Slice(_haystack_21314, _12328, _12330);
L6: 

        /** 		if str_offsets then*/
        if (_str_offsets_21320 == 0)
        {
            goto L7; // [127] 163
        }
        else{
        }

        /** 			match_data[i] = { tmp, match_data[i][1], match_data[i][2] }*/
        _2 = (int)SEQ_PTR(_match_data_21322);
        _12332 = (int)*(((s1_ptr)_2)->base + _i_21330);
        _2 = (int)SEQ_PTR(_12332);
        _12333 = (int)*(((s1_ptr)_2)->base + 1);
        _12332 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21322);
        _12334 = (int)*(((s1_ptr)_2)->base + _i_21330);
        _2 = (int)SEQ_PTR(_12334);
        _12335 = (int)*(((s1_ptr)_2)->base + 2);
        _12334 = NOVALUE;
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_tmp_21332);
        *((int *)(_2+4)) = _tmp_21332;
        Ref(_12333);
        *((int *)(_2+8)) = _12333;
        Ref(_12335);
        *((int *)(_2+12)) = _12335;
        _12336 = MAKE_SEQ(_1);
        _12335 = NOVALUE;
        _12333 = NOVALUE;
        _2 = (int)SEQ_PTR(_match_data_21322);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21322 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21330);
        _1 = *(int *)_2;
        *(int *)_2 = _12336;
        if( _1 != _12336 ){
            DeRef(_1);
        }
        _12336 = NOVALUE;
        goto L8; // [160] 172
L7: 

        /** 			match_data[i] = tmp*/
        RefDS(_tmp_21332);
        _2 = (int)SEQ_PTR(_match_data_21322);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _match_data_21322 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21330);
        _1 = *(int *)_2;
        *(int *)_2 = _tmp_21332;
        DeRef(_1);
L8: 
        DeRef(_tmp_21332);
        _tmp_21332 = NOVALUE;

        /** 	end for*/
        _i_21330 = _i_21330 + 1;
        goto L3; // [176] 75
L4: 
        ;
    }

    /** 	return match_data*/
    DeRef(_re_21312);
    DeRef(_haystack_21314);
    DeRef(_options_21316);
    _12328 = NOVALUE;
    _12330 = NOVALUE;
    return _match_data_21322;
    ;
}



// 0x842F014A
