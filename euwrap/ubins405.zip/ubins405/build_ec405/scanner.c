// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _61set_qualified_fwd(int _fwd_23581)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fwd_23581)) {
        _1 = (long)(DBL_PTR(_fwd_23581)->dbl);
        DeRefDS(_fwd_23581);
        _fwd_23581 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23578 = _fwd_23581;

    /** end procedure*/
    return;
    ;
}


int _61get_qualified_fwd()
{
    int _fwd_23584 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer fwd = qualified_fwd*/
    _fwd_23584 = _61qualified_fwd_23578;

    /** 	set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23578 = -1;

    /** end procedure*/
    goto L1; // [17] 20
L1: 

    /** 	return fwd*/
    return _fwd_23584;
    ;
}


void _61InitLex()
{
    int _13567 = NOVALUE;
    int _13566 = NOVALUE;
    int _13565 = NOVALUE;
    int _13563 = NOVALUE;
    int _13562 = NOVALUE;
    int _13561 = NOVALUE;
    int _13560 = NOVALUE;
    int _0, _1, _2;
    

    /** 	gline_number = 0*/
    _35gline_number_15973 = 0;

    /** 	line_number = 0*/
    _35line_number_15969 = 0;

    /** 	IncludeStk = {}*/
    RefDS(_5);
    DeRef(_61IncludeStk_23555);
    _61IncludeStk_23555 = _5;

    /** 	char_class = repeat(ILLEGAL_CHAR, 255)  -- we screen out the 0 character*/
    DeRefi(_61char_class_23553);
    _61char_class_23553 = Repeat(-20, 255);

    /** 	char_class['0'..'9'] = DIGIT*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23553;
    AssignSlice(48, 57, -7);

    /** 	char_class['_']      = DIGIT*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 95);
    *(int *)_2 = -7;

    /** 	char_class['a'..'z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23553;
    AssignSlice(97, 122, -2);

    /** 	char_class['A'..'Z'] = LETTER*/
    assign_slice_seq = (s1_ptr *)&_61char_class_23553;
    AssignSlice(65, 90, -2);

    /** 	char_class[KEYWORD_BASE+1..KEYWORD_BASE+NUM_KEYWORDS] = KEYWORD*/
    _13560 = 129;
    _13561 = 152;
    assign_slice_seq = (s1_ptr *)&_61char_class_23553;
    AssignSlice(129, 152, -10);
    _13560 = NOVALUE;
    _13561 = NOVALUE;

    /** 	char_class[BUILTIN_BASE+1..BUILTIN_BASE+NUM_BUILTINS] = BUILTIN*/
    _13562 = 171;
    _13563 = 234;
    assign_slice_seq = (s1_ptr *)&_61char_class_23553;
    AssignSlice(171, 234, -9);
    _13562 = NOVALUE;
    _13563 = NOVALUE;

    /** 	char_class[' '] = BLANK*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = -8;

    /** 	char_class['\t'] = BLANK*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    *(int *)_2 = -8;

    /** 	char_class['+'] = PLUS*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 43);
    *(int *)_2 = 11;

    /** 	char_class['-'] = MINUS*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 45);
    *(int *)_2 = 10;

    /** 	char_class['*'] = res:MULTIPLY*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 42);
    *(int *)_2 = 13;

    /** 	char_class['/'] = res:DIVIDE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 47);
    *(int *)_2 = 14;

    /** 	char_class['='] = EQUALS*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 61);
    *(int *)_2 = 3;

    /** 	char_class['<'] = LESS*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 60);
    *(int *)_2 = 1;

    /** 	char_class['>'] = GREATER*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 62);
    *(int *)_2 = 6;

    /** 	char_class['\''] = SINGLE_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 39);
    *(int *)_2 = -5;

    /** 	char_class['"'] = DOUBLE_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 34);
    *(int *)_2 = -4;

    /** 	char_class['`'] = BACK_QUOTE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 96);
    *(int *)_2 = -12;

    /** 	char_class['.'] = DOT*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 46);
    *(int *)_2 = -3;

    /** 	char_class[':'] = COLON*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 58);
    *(int *)_2 = -23;

    /** 	char_class['\r'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    *(int *)_2 = -6;

    /** 	char_class['\n'] = NEWLINE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    *(int *)_2 = -6;

    /** 	char_class['!'] = BANG*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 33);
    *(int *)_2 = -1;

    /** 	char_class['{'] = LEFT_BRACE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 123);
    *(int *)_2 = -24;

    /** 	char_class['}'] = RIGHT_BRACE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 125);
    *(int *)_2 = -25;

    /** 	char_class['('] = LEFT_ROUND*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 40);
    *(int *)_2 = -26;

    /** 	char_class[')'] = RIGHT_ROUND*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 41);
    *(int *)_2 = -27;

    /** 	char_class['['] = LEFT_SQUARE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 91);
    *(int *)_2 = -28;

    /** 	char_class[']'] = RIGHT_SQUARE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 93);
    *(int *)_2 = -29;

    /** 	char_class['$'] = DOLLAR*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = -22;

    /** 	char_class[','] = COMMA*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 44);
    *(int *)_2 = -30;

    /** 	char_class['&'] = res:CONCAT*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 38);
    *(int *)_2 = 15;

    /** 	char_class['?'] = QUESTION_MARK*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 63);
    *(int *)_2 = -31;

    /** 	char_class['#'] = NUMBER_SIGN*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 35);
    *(int *)_2 = -11;

    /** 	char_class[END_OF_FILE_CHAR] = END_OF_FILE*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _2 = (int)(((s1_ptr)_2)->base + 26);
    *(int *)_2 = -21;

    /** 	id_char = repeat(FALSE, 255)*/
    DeRefi(_61id_char_23554);
    _61id_char_23554 = Repeat(_13FALSE_435, 255);

    /** 	for i = 1 to 255 do*/
    {
        int _i_23632;
        _i_23632 = 1;
L1: 
        if (_i_23632 > 255){
            goto L2; // [407] 456
        }

        /** 		if find(char_class[i], {LETTER, DIGIT}) then*/
        _2 = (int)SEQ_PTR(_61char_class_23553);
        _13565 = (int)*(((s1_ptr)_2)->base + _i_23632);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = -7;
        _13566 = MAKE_SEQ(_1);
        _13567 = find_from(_13565, _13566, 1);
        _13565 = NOVALUE;
        DeRefDS(_13566);
        _13566 = NOVALUE;
        if (_13567 == 0)
        {
            _13567 = NOVALUE;
            goto L3; // [435] 449
        }
        else{
            _13567 = NOVALUE;
        }

        /** 			id_char[i] = TRUE*/
        _2 = (int)SEQ_PTR(_61id_char_23554);
        _2 = (int)(((s1_ptr)_2)->base + _i_23632);
        *(int *)_2 = _13TRUE_437;
L3: 

        /** 	end for*/
        _i_23632 = _i_23632 + 1;
        goto L1; // [451] 414
L2: 
        ;
    }

    /** 	default_namespaces = {0}*/
    _0 = _61default_namespaces_23552;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _61default_namespaces_23552 = MAKE_SEQ(_1);
    DeRef(_0);

    /** end procedure*/
    return;
    ;
}


void _61ResetTP()
{
    int _0, _1, _2;
    

    /** 	OpTrace = FALSE*/
    _35OpTrace_16037 = _13FALSE_435;

    /** 	OpProfileStatement = FALSE*/
    _35OpProfileStatement_16039 = _13FALSE_435;

    /** 	OpProfileTime = FALSE*/
    _35OpProfileTime_16040 = _13FALSE_435;

    /** 	AnyStatementProfile = FALSE*/
    _36AnyStatementProfile_15004 = _13FALSE_435;

    /** 	AnyTimeProfile = FALSE*/
    _36AnyTimeProfile_15003 = _13FALSE_435;

    /** end procedure*/
    return;
    ;
}


int _61pack_source(int _src_23662)
{
    int _start_23663 = NOVALUE;
    int _13591 = NOVALUE;
    int _13590 = NOVALUE;
    int _13589 = NOVALUE;
    int _13588 = NOVALUE;
    int _13586 = NOVALUE;
    int _13584 = NOVALUE;
    int _13583 = NOVALUE;
    int _13582 = NOVALUE;
    int _13578 = NOVALUE;
    int _13576 = NOVALUE;
    int _13575 = NOVALUE;
    int _13572 = NOVALUE;
    int _13571 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(src, 0) then*/
    if (_src_23662 == 0)
    _13571 = 1;
    else if (IS_ATOM_INT(_src_23662) && IS_ATOM_INT(0))
    _13571 = 0;
    else
    _13571 = (compare(_src_23662, 0) == 0);
    if (_13571 == 0)
    {
        _13571 = NOVALUE;
        goto L1; // [7] 17
    }
    else{
        _13571 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_src_23662);
    return 0;
L1: 

    /** 	if length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_23662)){
            _13572 = SEQ_PTR(_src_23662)->length;
    }
    else {
        _13572 = 1;
    }
    if (_13572 < 10000)
    goto L2; // [22] 34

    /** 		src = src[1..100] -- enough for trace or profile display*/
    rhs_slice_target = (object_ptr)&_src_23662;
    RHS_Slice(_src_23662, 1, 100);
L2: 

    /** 	if current_source_next + length(src) >= SOURCE_CHUNK then*/
    if (IS_SEQUENCE(_src_23662)){
            _13575 = SEQ_PTR(_src_23662)->length;
    }
    else {
        _13575 = 1;
    }
    _13576 = _61current_source_next_23658 + _13575;
    if ((long)((unsigned long)_13576 + (unsigned long)HIGH_BITS) >= 0) 
    _13576 = NewDouble((double)_13576);
    _13575 = NOVALUE;
    if (binary_op_a(LESS, _13576, 10000)){
        DeRef(_13576);
        _13576 = NOVALUE;
        goto L3; // [45] 94
    }
    DeRef(_13576);
    _13576 = NOVALUE;

    /** 		current_source = allocate(SOURCE_CHUNK + LINE_BUFLEN)*/
    _13578 = 10400;
    _0 = _9allocate(10400, 0);
    DeRef(_61current_source_23657);
    _61current_source_23657 = _0;
    _13578 = NOVALUE;

    /** 		if current_source = 0 then*/
    if (binary_op_a(NOTEQ, _61current_source_23657, 0)){
        goto L4; // [64] 76
    }

    /** 			CompileErr(123)*/
    RefDS(_21815);
    _44CompileErr(123, _21815, 0);
L4: 

    /** 		all_source = append(all_source, current_source)*/
    Ref(_61current_source_23657);
    Append(&_36all_source_15005, _36all_source_15005, _61current_source_23657);

    /** 		current_source_next = 1*/
    _61current_source_next_23658 = 1;
L3: 

    /** 	start = current_source_next*/
    _start_23663 = _61current_source_next_23658;

    /** 	poke(current_source+current_source_next, src)*/
    if (IS_ATOM_INT(_61current_source_23657)) {
        _13582 = _61current_source_23657 + _61current_source_next_23658;
        if ((long)((unsigned long)_13582 + (unsigned long)HIGH_BITS) >= 0) 
        _13582 = NewDouble((double)_13582);
    }
    else {
        _13582 = NewDouble(DBL_PTR(_61current_source_23657)->dbl + (double)_61current_source_next_23658);
    }
    if (IS_ATOM_INT(_13582)){
        poke_addr = (unsigned char *)_13582;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13582)->dbl);
    }
    if (IS_ATOM_INT(_src_23662)) {
        *poke_addr = (unsigned char)_src_23662;
    }
    else if (IS_ATOM(_src_23662)) {
        *poke_addr = (signed char)DBL_PTR(_src_23662)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_src_23662);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_13582);
    _13582 = NOVALUE;

    /** 	current_source_next += length(src)-1*/
    if (IS_SEQUENCE(_src_23662)){
            _13583 = SEQ_PTR(_src_23662)->length;
    }
    else {
        _13583 = 1;
    }
    _13584 = _13583 - 1;
    _13583 = NOVALUE;
    _61current_source_next_23658 = _61current_source_next_23658 + _13584;
    _13584 = NOVALUE;

    /** 	poke(current_source+current_source_next, 0) -- overwrite \n*/
    if (IS_ATOM_INT(_61current_source_23657)) {
        _13586 = _61current_source_23657 + _61current_source_next_23658;
        if ((long)((unsigned long)_13586 + (unsigned long)HIGH_BITS) >= 0) 
        _13586 = NewDouble((double)_13586);
    }
    else {
        _13586 = NewDouble(DBL_PTR(_61current_source_23657)->dbl + (double)_61current_source_next_23658);
    }
    if (IS_ATOM_INT(_13586)){
        poke_addr = (unsigned char *)_13586;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_13586)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_13586);
    _13586 = NOVALUE;

    /** 	current_source_next += 1*/
    _61current_source_next_23658 = _61current_source_next_23658 + 1;

    /** 	return start + SOURCE_CHUNK * (length(all_source)-1)*/
    if (IS_SEQUENCE(_36all_source_15005)){
            _13588 = SEQ_PTR(_36all_source_15005)->length;
    }
    else {
        _13588 = 1;
    }
    _13589 = _13588 - 1;
    _13588 = NOVALUE;
    if (_13589 <= INT15)
    _13590 = 10000 * _13589;
    else
    _13590 = NewDouble(10000 * (double)_13589);
    _13589 = NOVALUE;
    if (IS_ATOM_INT(_13590)) {
        _13591 = _start_23663 + _13590;
        if ((long)((unsigned long)_13591 + (unsigned long)HIGH_BITS) >= 0) 
        _13591 = NewDouble((double)_13591);
    }
    else {
        _13591 = NewDouble((double)_start_23663 + DBL_PTR(_13590)->dbl);
    }
    DeRef(_13590);
    _13590 = NOVALUE;
    DeRef(_src_23662);
    return _13591;
    ;
}


int _61fetch_line(int _start_23696)
{
    int _line_23697 = NOVALUE;
    int _memdata_23698 = NOVALUE;
    int _c_23699 = NOVALUE;
    int _chunk_23700 = NOVALUE;
    int _p_23701 = NOVALUE;
    int _n_23702 = NOVALUE;
    int _m_23703 = NOVALUE;
    int _13616 = NOVALUE;
    int _13615 = NOVALUE;
    int _13613 = NOVALUE;
    int _13611 = NOVALUE;
    int _13605 = NOVALUE;
    int _13603 = NOVALUE;
    int _13599 = NOVALUE;
    int _13597 = NOVALUE;
    int _13594 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_start_23696)) {
        _1 = (long)(DBL_PTR(_start_23696)->dbl);
        DeRefDS(_start_23696);
        _start_23696 = _1;
    }

    /** 	if start = 0 then*/
    if (_start_23696 != 0)
    goto L1; // [5] 16

    /** 		return ""*/
    RefDS(_5);
    DeRef(_line_23697);
    DeRefi(_memdata_23698);
    DeRef(_p_23701);
    return _5;
L1: 

    /** 	line = repeat(0, LINE_BUFLEN)*/
    DeRef(_line_23697);
    _line_23697 = Repeat(0, 400);

    /** 	n = 0*/
    _n_23702 = 0;

    /** 	chunk = 1+floor(start / SOURCE_CHUNK)*/
    if (10000 > 0 && _start_23696 >= 0) {
        _13594 = _start_23696 / 10000;
    }
    else {
        temp_dbl = floor((double)_start_23696 / (double)10000);
        _13594 = (long)temp_dbl;
    }
    _chunk_23700 = _13594 + 1;
    _13594 = NOVALUE;

    /** 	start = remainder(start, SOURCE_CHUNK)*/
    _start_23696 = (_start_23696 % 10000);

    /** 	p = all_source[chunk] + start*/
    _2 = (int)SEQ_PTR(_36all_source_15005);
    _13597 = (int)*(((s1_ptr)_2)->base + _chunk_23700);
    DeRef(_p_23701);
    if (IS_ATOM_INT(_13597)) {
        _p_23701 = _13597 + _start_23696;
        if ((long)((unsigned long)_p_23701 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23701 = NewDouble((double)_p_23701);
    }
    else {
        _p_23701 = NewDouble(DBL_PTR(_13597)->dbl + (double)_start_23696);
    }
    _13597 = NOVALUE;

    /** 	memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_23701);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_23701;
    ((int *)_2)[2] = 400;
    _13599 = MAKE_SEQ(_1);
    DeRefi(_memdata_23698);
    _1 = (int)SEQ_PTR(_13599);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_23698 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13599);
    _13599 = NOVALUE;

    /** 	p += LINE_BUFLEN*/
    _0 = _p_23701;
    if (IS_ATOM_INT(_p_23701)) {
        _p_23701 = _p_23701 + 400;
        if ((long)((unsigned long)_p_23701 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23701 = NewDouble((double)_p_23701);
    }
    else {
        _p_23701 = NewDouble(DBL_PTR(_p_23701)->dbl + (double)400);
    }
    DeRef(_0);

    /** 	m = 0*/
    _m_23703 = 0;

    /** 	while TRUE do*/
L2: 
    if (_13TRUE_437 == 0)
    {
        goto L3; // [84] 179
    }
    else{
    }

    /** 		m += 1*/
    _m_23703 = _m_23703 + 1;

    /** 		if m > length(memdata) then*/
    if (IS_SEQUENCE(_memdata_23698)){
            _13603 = SEQ_PTR(_memdata_23698)->length;
    }
    else {
        _13603 = 1;
    }
    if (_m_23703 <= _13603)
    goto L4; // [98] 125

    /** 			memdata = peek({p, LINE_BUFLEN})*/
    Ref(_p_23701);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _p_23701;
    ((int *)_2)[2] = 400;
    _13605 = MAKE_SEQ(_1);
    DeRefDSi(_memdata_23698);
    _1 = (int)SEQ_PTR(_13605);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _memdata_23698 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_13605);
    _13605 = NOVALUE;

    /** 			p += LINE_BUFLEN*/
    _0 = _p_23701;
    if (IS_ATOM_INT(_p_23701)) {
        _p_23701 = _p_23701 + 400;
        if ((long)((unsigned long)_p_23701 + (unsigned long)HIGH_BITS) >= 0) 
        _p_23701 = NewDouble((double)_p_23701);
    }
    else {
        _p_23701 = NewDouble(DBL_PTR(_p_23701)->dbl + (double)400);
    }
    DeRef(_0);

    /** 			m = 1*/
    _m_23703 = 1;
L4: 

    /** 		c = memdata[m]*/
    _2 = (int)SEQ_PTR(_memdata_23698);
    _c_23699 = (int)*(((s1_ptr)_2)->base + _m_23703);

    /** 		if c = 0 then*/
    if (_c_23699 != 0)
    goto L5; // [133] 142

    /** 			exit*/
    goto L3; // [139] 179
L5: 

    /** 		n += 1*/
    _n_23702 = _n_23702 + 1;

    /** 		if n > length(line) then*/
    if (IS_SEQUENCE(_line_23697)){
            _13611 = SEQ_PTR(_line_23697)->length;
    }
    else {
        _13611 = 1;
    }
    if (_n_23702 <= _13611)
    goto L6; // [153] 168

    /** 			line &= repeat(0, LINE_BUFLEN)*/
    _13613 = Repeat(0, 400);
    Concat((object_ptr)&_line_23697, _line_23697, _13613);
    DeRefDS(_13613);
    _13613 = NOVALUE;
L6: 

    /** 		line[n] = c*/
    _2 = (int)SEQ_PTR(_line_23697);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _line_23697 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_23702);
    _1 = *(int *)_2;
    *(int *)_2 = _c_23699;
    DeRef(_1);

    /** 	end while*/
    goto L2; // [176] 82
L3: 

    /** 	line = remove( line, n+1, length( line ) )*/
    _13615 = _n_23702 + 1;
    if (_13615 > MAXINT){
        _13615 = NewDouble((double)_13615);
    }
    if (IS_SEQUENCE(_line_23697)){
            _13616 = SEQ_PTR(_line_23697)->length;
    }
    else {
        _13616 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_line_23697);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13615)) ? _13615 : (long)(DBL_PTR(_13615)->dbl);
        int stop = (IS_ATOM_INT(_13616)) ? _13616 : (long)(DBL_PTR(_13616)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_line_23697), start, &_line_23697 );
            }
            else Tail(SEQ_PTR(_line_23697), stop+1, &_line_23697);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_line_23697), start, &_line_23697);
        }
        else {
            assign_slice_seq = &assign_space;
            _line_23697 = Remove_elements(start, stop, (SEQ_PTR(_line_23697)->ref == 1));
        }
    }
    DeRef(_13615);
    _13615 = NOVALUE;
    _13616 = NOVALUE;

    /** 	return line*/
    DeRefi(_memdata_23698);
    DeRef(_p_23701);
    return _line_23697;
    ;
}


void _61AppendSourceLine()
{
    int _new_23739 = NOVALUE;
    int _old_23740 = NOVALUE;
    int _options_23741 = NOVALUE;
    int _src_23742 = NOVALUE;
    int _13657 = NOVALUE;
    int _13653 = NOVALUE;
    int _13651 = NOVALUE;
    int _13650 = NOVALUE;
    int _13647 = NOVALUE;
    int _13646 = NOVALUE;
    int _13645 = NOVALUE;
    int _13644 = NOVALUE;
    int _13643 = NOVALUE;
    int _13642 = NOVALUE;
    int _13641 = NOVALUE;
    int _13640 = NOVALUE;
    int _13639 = NOVALUE;
    int _13638 = NOVALUE;
    int _13637 = NOVALUE;
    int _13636 = NOVALUE;
    int _13635 = NOVALUE;
    int _13634 = NOVALUE;
    int _13633 = NOVALUE;
    int _13632 = NOVALUE;
    int _13631 = NOVALUE;
    int _13630 = NOVALUE;
    int _13628 = NOVALUE;
    int _13627 = NOVALUE;
    int _13626 = NOVALUE;
    int _13624 = NOVALUE;
    int _13619 = NOVALUE;
    int _13618 = NOVALUE;
    int _0, _1, _2;
    

    /** 	src = 0*/
    DeRef(_src_23742);
    _src_23742 = 0;

    /** 	options = 0*/
    _options_23741 = 0;

    /** 	if TRANSLATE or OpTrace or OpProfileStatement or OpProfileTime then*/
    if (_35TRANSLATE_15611 != 0) {
        _13618 = 1;
        goto L1; // [15] 25
    }
    _13618 = (_35OpTrace_16037 != 0);
L1: 
    if (_13618 != 0) {
        _13619 = 1;
        goto L2; // [25] 35
    }
    _13619 = (_35OpProfileStatement_16039 != 0);
L2: 
    if (_13619 != 0) {
        goto L3; // [35] 46
    }
    if (_35OpProfileTime_16040 == 0)
    {
        goto L4; // [42] 136
    }
    else{
    }
L3: 

    /** 		src = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_src_23742);
    _src_23742 = _44ThisLine_48142;

    /** 		if OpTrace then*/
    if (_35OpTrace_16037 == 0)
    {
        goto L5; // [57] 70
    }
    else{
    }

    /** 			options = SOP_TRACE*/
    _options_23741 = 1;
L5: 

    /** 		if OpProfileTime then*/
    if (_35OpProfileTime_16040 == 0)
    {
        goto L6; // [74] 88
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_TIME)*/
    {unsigned long tu;
         tu = (unsigned long)_options_23741 | (unsigned long)2;
         _options_23741 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_23741)) {
        _1 = (long)(DBL_PTR(_options_23741)->dbl);
        DeRefDS(_options_23741);
        _options_23741 = _1;
    }
L6: 

    /** 		if OpProfileStatement then*/
    if (_35OpProfileStatement_16039 == 0)
    {
        goto L7; // [92] 106
    }
    else{
    }

    /** 			options = or_bits(options, SOP_PROFILE_STATEMENT)*/
    {unsigned long tu;
         tu = (unsigned long)_options_23741 | (unsigned long)4;
         _options_23741 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_options_23741)) {
        _1 = (long)(DBL_PTR(_options_23741)->dbl);
        DeRefDS(_options_23741);
        _options_23741 = _1;
    }
L7: 

    /** 		if OpProfileStatement or OpProfileTime then*/
    if (_35OpProfileStatement_16039 != 0) {
        goto L8; // [110] 121
    }
    if (_35OpProfileTime_16040 == 0)
    {
        goto L9; // [117] 135
    }
    else{
    }
L8: 

    /** 			src = {0,0,0,0} & src*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    _13624 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13624) && IS_ATOM(_src_23742)) {
        Ref(_src_23742);
        Append(&_src_23742, _13624, _src_23742);
    }
    else if (IS_ATOM(_13624) && IS_SEQUENCE(_src_23742)) {
    }
    else {
        Concat((object_ptr)&_src_23742, _13624, _src_23742);
        DeRefDS(_13624);
        _13624 = NOVALUE;
    }
    DeRef(_13624);
    _13624 = NOVALUE;
L9: 
L4: 

    /** 	if length(slist) then*/
    if (IS_SEQUENCE(_35slist_16058)){
            _13626 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13626 = 1;
    }
    if (_13626 == 0)
    {
        _13626 = NOVALUE;
        goto LA; // [143] 345
    }
    else{
        _13626 = NOVALUE;
    }

    /** 		old = slist[$-1]*/
    if (IS_SEQUENCE(_35slist_16058)){
            _13627 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13627 = 1;
    }
    _13628 = _13627 - 1;
    _13627 = NOVALUE;
    DeRef(_old_23740);
    _2 = (int)SEQ_PTR(_35slist_16058);
    _old_23740 = (int)*(((s1_ptr)_2)->base + _13628);
    Ref(_old_23740);

    /** 		if equal(src, old[SRC]) and*/
    _2 = (int)SEQ_PTR(_old_23740);
    _13630 = (int)*(((s1_ptr)_2)->base + 1);
    if (_src_23742 == _13630)
    _13631 = 1;
    else if (IS_ATOM_INT(_src_23742) && IS_ATOM_INT(_13630))
    _13631 = 0;
    else
    _13631 = (compare(_src_23742, _13630) == 0);
    _13630 = NOVALUE;
    if (_13631 == 0) {
        _13632 = 0;
        goto LB; // [175] 195
    }
    _2 = (int)SEQ_PTR(_old_23740);
    _13633 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_13633)) {
        _13634 = (_35current_file_no_15968 == _13633);
    }
    else {
        _13634 = binary_op(EQUALS, _35current_file_no_15968, _13633);
    }
    _13633 = NOVALUE;
    if (IS_ATOM_INT(_13634))
    _13632 = (_13634 != 0);
    else
    _13632 = DBL_PTR(_13634)->dbl != 0.0;
LB: 
    if (_13632 == 0) {
        _13635 = 0;
        goto LC; // [195] 232
    }
    _2 = (int)SEQ_PTR(_old_23740);
    _13636 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13636)) {
        _13637 = _13636 + 1;
        if (_13637 > MAXINT){
            _13637 = NewDouble((double)_13637);
        }
    }
    else
    _13637 = binary_op(PLUS, 1, _13636);
    _13636 = NOVALUE;
    if (IS_SEQUENCE(_35slist_16058)){
            _13638 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13638 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16058);
    _13639 = (int)*(((s1_ptr)_2)->base + _13638);
    if (IS_ATOM_INT(_13637) && IS_ATOM_INT(_13639)) {
        _13640 = _13637 + _13639;
        if ((long)((unsigned long)_13640 + (unsigned long)HIGH_BITS) >= 0) 
        _13640 = NewDouble((double)_13640);
    }
    else {
        _13640 = binary_op(PLUS, _13637, _13639);
    }
    DeRef(_13637);
    _13637 = NOVALUE;
    _13639 = NOVALUE;
    if (IS_ATOM_INT(_13640)) {
        _13641 = (_35line_number_15969 == _13640);
    }
    else {
        _13641 = binary_op(EQUALS, _35line_number_15969, _13640);
    }
    DeRef(_13640);
    _13640 = NOVALUE;
    if (IS_ATOM_INT(_13641))
    _13635 = (_13641 != 0);
    else
    _13635 = DBL_PTR(_13641)->dbl != 0.0;
LC: 
    if (_13635 == 0) {
        goto LD; // [232] 272
    }
    _2 = (int)SEQ_PTR(_old_23740);
    _13643 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_13643)) {
        _13644 = (_options_23741 == _13643);
    }
    else {
        _13644 = binary_op(EQUALS, _options_23741, _13643);
    }
    _13643 = NOVALUE;
    if (_13644 == 0) {
        DeRef(_13644);
        _13644 = NOVALUE;
        goto LD; // [247] 272
    }
    else {
        if (!IS_ATOM_INT(_13644) && DBL_PTR(_13644)->dbl == 0.0){
            DeRef(_13644);
            _13644 = NOVALUE;
            goto LD; // [247] 272
        }
        DeRef(_13644);
        _13644 = NOVALUE;
    }
    DeRef(_13644);
    _13644 = NOVALUE;

    /** 			slist[$] += 1*/
    if (IS_SEQUENCE(_35slist_16058)){
            _13645 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13645 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16058);
    _13646 = (int)*(((s1_ptr)_2)->base + _13645);
    if (IS_ATOM_INT(_13646)) {
        _13647 = _13646 + 1;
        if (_13647 > MAXINT){
            _13647 = NewDouble((double)_13647);
        }
    }
    else
    _13647 = binary_op(PLUS, 1, _13646);
    _13646 = NOVALUE;
    _2 = (int)SEQ_PTR(_35slist_16058);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35slist_16058 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13645);
    _1 = *(int *)_2;
    *(int *)_2 = _13647;
    if( _1 != _13647 ){
        DeRef(_1);
    }
    _13647 = NOVALUE;
    goto LE; // [269] 371
LD: 

    /** 			src = pack_source(src)*/
    Ref(_src_23742);
    _0 = _src_23742;
    _src_23742 = _61pack_source(_src_23742);
    DeRef(_0);

    /** 			new = {src, line_number, current_file_no, options}*/
    _0 = _new_23739;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_23742);
    *((int *)(_2+4)) = _src_23742;
    *((int *)(_2+8)) = _35line_number_15969;
    *((int *)(_2+12)) = _35current_file_no_15968;
    *((int *)(_2+16)) = _options_23741;
    _new_23739 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			if slist[$] = 0 then*/
    if (IS_SEQUENCE(_35slist_16058)){
            _13650 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13650 = 1;
    }
    _2 = (int)SEQ_PTR(_35slist_16058);
    _13651 = (int)*(((s1_ptr)_2)->base + _13650);
    if (binary_op_a(NOTEQ, _13651, 0)){
        _13651 = NOVALUE;
        goto LF; // [302] 320
    }
    _13651 = NOVALUE;

    /** 				slist[$] = new*/
    if (IS_SEQUENCE(_35slist_16058)){
            _13653 = SEQ_PTR(_35slist_16058)->length;
    }
    else {
        _13653 = 1;
    }
    RefDS(_new_23739);
    _2 = (int)SEQ_PTR(_35slist_16058);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _35slist_16058 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13653);
    _1 = *(int *)_2;
    *(int *)_2 = _new_23739;
    DeRef(_1);
    goto L10; // [317] 331
LF: 

    /** 				slist = append(slist, new)*/
    RefDS(_new_23739);
    Append(&_35slist_16058, _35slist_16058, _new_23739);
L10: 

    /** 			slist = append(slist, 0)*/
    Append(&_35slist_16058, _35slist_16058, 0);
    goto LE; // [342] 371
LA: 

    /** 		src = pack_source(src)*/
    Ref(_src_23742);
    _0 = _src_23742;
    _src_23742 = _61pack_source(_src_23742);
    DeRef(_0);

    /** 		slist = {{src, line_number, current_file_no, options}, 0}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_src_23742);
    *((int *)(_2+4)) = _src_23742;
    *((int *)(_2+8)) = _35line_number_15969;
    *((int *)(_2+12)) = _35current_file_no_15968;
    *((int *)(_2+16)) = _options_23741;
    _13657 = MAKE_SEQ(_1);
    DeRef(_35slist_16058);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _13657;
    ((int *)_2)[2] = 0;
    _35slist_16058 = MAKE_SEQ(_1);
    _13657 = NOVALUE;
LE: 

    /** end procedure*/
    DeRef(_new_23739);
    DeRef(_old_23740);
    DeRef(_src_23742);
    DeRef(_13628);
    _13628 = NOVALUE;
    DeRef(_13641);
    _13641 = NOVALUE;
    DeRef(_13634);
    _13634 = NOVALUE;
    return;
    ;
}


int _61s_expand(int _slist_23831)
{
    int _new_slist_23832 = NOVALUE;
    int _13671 = NOVALUE;
    int _13670 = NOVALUE;
    int _13669 = NOVALUE;
    int _13668 = NOVALUE;
    int _13666 = NOVALUE;
    int _13665 = NOVALUE;
    int _13664 = NOVALUE;
    int _13662 = NOVALUE;
    int _13661 = NOVALUE;
    int _13660 = NOVALUE;
    int _13659 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	new_slist = {}*/
    RefDS(_5);
    DeRef(_new_slist_23832);
    _new_slist_23832 = _5;

    /** 	for i = 1 to length(slist) do*/
    if (IS_SEQUENCE(_slist_23831)){
            _13659 = SEQ_PTR(_slist_23831)->length;
    }
    else {
        _13659 = 1;
    }
    {
        int _i_23834;
        _i_23834 = 1;
L1: 
        if (_i_23834 > _13659){
            goto L2; // [15] 114
        }

        /** 		if sequence(slist[i]) then*/
        _2 = (int)SEQ_PTR(_slist_23831);
        _13660 = (int)*(((s1_ptr)_2)->base + _i_23834);
        _13661 = IS_SEQUENCE(_13660);
        _13660 = NOVALUE;
        if (_13661 == 0)
        {
            _13661 = NOVALUE;
            goto L3; // [31] 47
        }
        else{
            _13661 = NOVALUE;
        }

        /** 			new_slist = append(new_slist, slist[i])*/
        _2 = (int)SEQ_PTR(_slist_23831);
        _13662 = (int)*(((s1_ptr)_2)->base + _i_23834);
        Ref(_13662);
        Append(&_new_slist_23832, _new_slist_23832, _13662);
        _13662 = NOVALUE;
        goto L4; // [44] 107
L3: 

        /** 			for j = 1 to slist[i] do*/
        _2 = (int)SEQ_PTR(_slist_23831);
        _13664 = (int)*(((s1_ptr)_2)->base + _i_23834);
        {
            int _j_23843;
            _j_23843 = 1;
L5: 
            if (binary_op_a(GREATER, _j_23843, _13664)){
                goto L6; // [53] 106
            }

            /** 				slist[i-1][LINE] += 1*/
            _13665 = _i_23834 - 1;
            _2 = (int)SEQ_PTR(_slist_23831);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _slist_23831 = MAKE_SEQ(_2);
            }
            _3 = (int)(_13665 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            _13668 = (int)*(((s1_ptr)_2)->base + 2);
            _13666 = NOVALUE;
            if (IS_ATOM_INT(_13668)) {
                _13669 = _13668 + 1;
                if (_13669 > MAXINT){
                    _13669 = NewDouble((double)_13669);
                }
            }
            else
            _13669 = binary_op(PLUS, 1, _13668);
            _13668 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _13669;
            if( _1 != _13669 ){
                DeRef(_1);
            }
            _13669 = NOVALUE;
            _13666 = NOVALUE;

            /** 				new_slist = append(new_slist, slist[i-1])*/
            _13670 = _i_23834 - 1;
            _2 = (int)SEQ_PTR(_slist_23831);
            _13671 = (int)*(((s1_ptr)_2)->base + _13670);
            Ref(_13671);
            Append(&_new_slist_23832, _new_slist_23832, _13671);
            _13671 = NOVALUE;

            /** 			end for*/
            _0 = _j_23843;
            if (IS_ATOM_INT(_j_23843)) {
                _j_23843 = _j_23843 + 1;
                if ((long)((unsigned long)_j_23843 +(unsigned long) HIGH_BITS) >= 0){
                    _j_23843 = NewDouble((double)_j_23843);
                }
            }
            else {
                _j_23843 = binary_op_a(PLUS, _j_23843, 1);
            }
            DeRef(_0);
            goto L5; // [101] 60
L6: 
            ;
            DeRef(_j_23843);
        }
L4: 

        /** 	end for*/
        _i_23834 = _i_23834 + 1;
        goto L1; // [109] 22
L2: 
        ;
    }

    /** 	return new_slist*/
    DeRefDS(_slist_23831);
    _13664 = NOVALUE;
    DeRef(_13665);
    _13665 = NOVALUE;
    DeRef(_13670);
    _13670 = NOVALUE;
    return _new_slist_23832;
    ;
}


void _61set_dont_read(int _read_23858)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_read_23858)) {
        _1 = (long)(DBL_PTR(_read_23858)->dbl);
        DeRefDS(_read_23858);
        _read_23858 = _1;
    }

    /** 	dont_read = read*/
    _61dont_read_23855 = _read_23858;

    /** end procedure*/
    return;
    ;
}


void _61read_line()
{
    int _n_23861 = NOVALUE;
    int _13685 = NOVALUE;
    int _13684 = NOVALUE;
    int _13682 = NOVALUE;
    int _13681 = NOVALUE;
    int _13679 = NOVALUE;
    int _13678 = NOVALUE;
    int _0, _1, _2;
    

    /** 	line_number += 1*/
    _35line_number_15969 = _35line_number_15969 + 1;

    /** 	gline_number += 1*/
    _35gline_number_15973 = _35gline_number_15973 + 1;

    /** 	if dont_read then*/
    if (_61dont_read_23855 == 0)
    {
        goto L1; // [25] 36
    }
    else{
    }

    /** 		ThisLine = -1*/
    DeRef(_44ThisLine_48142);
    _44ThisLine_48142 = -1;
    goto L2; // [33] 108
L1: 

    /** 	elsif src_file < 0 then*/
    if (_35src_file_16089 >= 0)
    goto L3; // [40] 52

    /** 		ThisLine = -1*/
    DeRef(_44ThisLine_48142);
    _44ThisLine_48142 = -1;
    goto L2; // [49] 108
L3: 

    /** 		ThisLine = gets(src_file)*/
    DeRef(_44ThisLine_48142);
    _44ThisLine_48142 = EGets(_35src_file_16089);

    /** 		if sequence(ThisLine) and ends( {13,10}, ThisLine ) then*/
    _13678 = IS_SEQUENCE(_44ThisLine_48142);
    if (_13678 == 0) {
        goto L4; // [66] 107
    }
    RefDS(_13680);
    Ref(_44ThisLine_48142);
    _13681 = _16ends(_13680, _44ThisLine_48142);
    if (_13681 == 0) {
        DeRef(_13681);
        _13681 = NOVALUE;
        goto L4; // [78] 107
    }
    else {
        if (!IS_ATOM_INT(_13681) && DBL_PTR(_13681)->dbl == 0.0){
            DeRef(_13681);
            _13681 = NOVALUE;
            goto L4; // [78] 107
        }
        DeRef(_13681);
        _13681 = NOVALUE;
    }
    DeRef(_13681);
    _13681 = NOVALUE;

    /** 			ThisLine = remove(ThisLine, length(ThisLine))*/
    if (IS_SEQUENCE(_44ThisLine_48142)){
            _13682 = SEQ_PTR(_44ThisLine_48142)->length;
    }
    else {
        _13682 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_44ThisLine_48142);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_13682)) ? _13682 : (long)(DBL_PTR(_13682)->dbl);
        int stop = (IS_ATOM_INT(_13682)) ? _13682 : (long)(DBL_PTR(_13682)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_44ThisLine_48142), start, &_44ThisLine_48142 );
            }
            else Tail(SEQ_PTR(_44ThisLine_48142), stop+1, &_44ThisLine_48142);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_44ThisLine_48142), start, &_44ThisLine_48142);
        }
        else {
            assign_slice_seq = &assign_space;
            _44ThisLine_48142 = Remove_elements(start, stop, (SEQ_PTR(_44ThisLine_48142)->ref == 1));
        }
    }
    _13682 = NOVALUE;
    _13682 = NOVALUE;

    /** 			ThisLine[$] = 10*/
    if (IS_SEQUENCE(_44ThisLine_48142)){
            _13684 = SEQ_PTR(_44ThisLine_48142)->length;
    }
    else {
        _13684 = 1;
    }
    _2 = (int)SEQ_PTR(_44ThisLine_48142);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _44ThisLine_48142 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13684);
    _1 = *(int *)_2;
    *(int *)_2 = 10;
    DeRef(_1);
L4: 
L2: 

    /** 	if atom(ThisLine) then*/
    _13685 = IS_ATOM(_44ThisLine_48142);
    if (_13685 == 0)
    {
        _13685 = NOVALUE;
        goto L5; // [115] 149
    }
    else{
        _13685 = NOVALUE;
    }

    /** 		ThisLine = {END_OF_FILE_CHAR}*/
    _0 = _44ThisLine_48142;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 26;
    _44ThisLine_48142 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		if src_file >= 0 then*/
    if (_35src_file_16089 < 0)
    goto L6; // [130] 141

    /** 			close(src_file)*/
    EClose(_35src_file_16089);
L6: 

    /** 		src_file = -1*/
    _35src_file_16089 = -1;
L5: 

    /** 	bp = 1*/
    _44bp_48146 = 1;

    /** 	AppendSourceLine()*/
    _61AppendSourceLine();

    /** end procedure*/
    return;
    ;
}


int _61getch()
{
    int _c_23905 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_44ThisLine_48142);
    _c_23905 = (int)*(((s1_ptr)_2)->base + _44bp_48146);
    if (!IS_ATOM_INT(_c_23905)){
        _c_23905 = (long)DBL_PTR(_c_23905)->dbl;
    }

    /** 	bp += 1*/
    _44bp_48146 = _44bp_48146 + 1;

    /** 	return c*/
    return _c_23905;
    ;
}


void _61ungetch()
{
    int _0, _1, _2;
    

    /** 	bp -= 1*/
    _44bp_48146 = _44bp_48146 - 1;

    /** end procedure*/
    return;
    ;
}


int _61get_file_path(int _s_23917)
{
    int _13696 = NOVALUE;
    int _13694 = NOVALUE;
    int _13693 = NOVALUE;
    int _13692 = NOVALUE;
    int _13691 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for t=length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_23917)){
            _13691 = SEQ_PTR(_s_23917)->length;
    }
    else {
        _13691 = 1;
    }
    {
        int _t_23919;
        _t_23919 = _13691;
L1: 
        if (_t_23919 < 1){
            goto L2; // [8] 50
        }

        /** 				if find(s[t],SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_s_23917);
        _13692 = (int)*(((s1_ptr)_2)->base + _t_23919);
        _13693 = find_from(_13692, _40SLASH_CHARS_16126, 1);
        _13692 = NOVALUE;
        if (_13693 == 0)
        {
            _13693 = NOVALUE;
            goto L3; // [28] 43
        }
        else{
            _13693 = NOVALUE;
        }

        /** 						return s[1..t]*/
        rhs_slice_target = (object_ptr)&_13694;
        RHS_Slice(_s_23917, 1, _t_23919);
        DeRefDS(_s_23917);
        return _13694;
L3: 

        /** 		end for*/
        _t_23919 = _t_23919 + -1;
        goto L1; // [45] 15
L2: 
        ;
    }

    /** 		return "." & SLASH*/
    Append(&_13696, _13695, 47);
    DeRefDS(_s_23917);
    DeRef(_13694);
    _13694 = NOVALUE;
    return _13696;
    ;
}


int _61find_file(int _fname_23931)
{
    int _try_23932 = NOVALUE;
    int _full_path_23933 = NOVALUE;
    int _errbuff_23934 = NOVALUE;
    int _currdir_23935 = NOVALUE;
    int _conf_path_23936 = NOVALUE;
    int _scan_result_23937 = NOVALUE;
    int _inc_path_23938 = NOVALUE;
    int _mainpath_23957 = NOVALUE;
    int _31397 = NOVALUE;
    int _31396 = NOVALUE;
    int _13793 = NOVALUE;
    int _13791 = NOVALUE;
    int _13790 = NOVALUE;
    int _13789 = NOVALUE;
    int _13787 = NOVALUE;
    int _13785 = NOVALUE;
    int _13783 = NOVALUE;
    int _13782 = NOVALUE;
    int _13780 = NOVALUE;
    int _13779 = NOVALUE;
    int _13776 = NOVALUE;
    int _13773 = NOVALUE;
    int _13772 = NOVALUE;
    int _13771 = NOVALUE;
    int _13770 = NOVALUE;
    int _13769 = NOVALUE;
    int _13768 = NOVALUE;
    int _13767 = NOVALUE;
    int _13766 = NOVALUE;
    int _13763 = NOVALUE;
    int _13762 = NOVALUE;
    int _13758 = NOVALUE;
    int _13755 = NOVALUE;
    int _13754 = NOVALUE;
    int _13753 = NOVALUE;
    int _13752 = NOVALUE;
    int _13751 = NOVALUE;
    int _13750 = NOVALUE;
    int _13749 = NOVALUE;
    int _13748 = NOVALUE;
    int _13745 = NOVALUE;
    int _13741 = NOVALUE;
    int _13739 = NOVALUE;
    int _13738 = NOVALUE;
    int _13737 = NOVALUE;
    int _13736 = NOVALUE;
    int _13735 = NOVALUE;
    int _13732 = NOVALUE;
    int _13731 = NOVALUE;
    int _13730 = NOVALUE;
    int _13729 = NOVALUE;
    int _13728 = NOVALUE;
    int _13727 = NOVALUE;
    int _13725 = NOVALUE;
    int _13724 = NOVALUE;
    int _13723 = NOVALUE;
    int _13722 = NOVALUE;
    int _13721 = NOVALUE;
    int _13719 = NOVALUE;
    int _13718 = NOVALUE;
    int _13715 = NOVALUE;
    int _13712 = NOVALUE;
    int _13710 = NOVALUE;
    int _13707 = NOVALUE;
    int _13705 = NOVALUE;
    int _13704 = NOVALUE;
    int _13701 = NOVALUE;
    int _13700 = NOVALUE;
    int _13698 = NOVALUE;
    int _13697 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(fname) then*/
    RefDS(_fname_23931);
    _13697 = _17absolute_path(_fname_23931);
    if (_13697 == 0) {
        DeRef(_13697);
        _13697 = NOVALUE;
        goto L1; // [9] 42
    }
    else {
        if (!IS_ATOM_INT(_13697) && DBL_PTR(_13697)->dbl == 0.0){
            DeRef(_13697);
            _13697 = NOVALUE;
            goto L1; // [9] 42
        }
        DeRef(_13697);
        _13697 = NOVALUE;
    }
    DeRef(_13697);
    _13697 = NOVALUE;

    /** 		if not file_exists(fname) then*/
    RefDS(_fname_23931);
    _13698 = _17file_exists(_fname_23931);
    if (IS_ATOM_INT(_13698)) {
        if (_13698 != 0){
            DeRef(_13698);
            _13698 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    else {
        if (DBL_PTR(_13698)->dbl != 0.0){
            DeRef(_13698);
            _13698 = NOVALUE;
            goto L2; // [18] 35
        }
    }
    DeRef(_13698);
    _13698 = NOVALUE;

    /** 			CompileErr(51, {new_include_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_35new_include_name_16090);
    *((int *)(_2+4)) = _35new_include_name_16090;
    _13700 = MAKE_SEQ(_1);
    _44CompileErr(51, _13700, 0);
    _13700 = NOVALUE;
L2: 

    /** 		return fname*/
    DeRef(_full_path_23933);
    DeRef(_errbuff_23934);
    DeRef(_currdir_23935);
    DeRef(_conf_path_23936);
    DeRef(_scan_result_23937);
    DeRef(_inc_path_23938);
    DeRef(_mainpath_23957);
    return _fname_23931;
L1: 

    /** 	currdir = get_file_path( known_files[current_file_no] )*/
    _2 = (int)SEQ_PTR(_36known_files_14982);
    _13701 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    Ref(_13701);
    _0 = _currdir_23935;
    _currdir_23935 = _61get_file_path(_13701);
    DeRef(_0);
    _13701 = NOVALUE;

    /** 	full_path = currdir & fname*/
    Concat((object_ptr)&_full_path_23933, _currdir_23935, _fname_23931);

    /** 	if file_exists(full_path) then*/
    RefDS(_full_path_23933);
    _13704 = _17file_exists(_full_path_23933);
    if (_13704 == 0) {
        DeRef(_13704);
        _13704 = NOVALUE;
        goto L3; // [70] 80
    }
    else {
        if (!IS_ATOM_INT(_13704) && DBL_PTR(_13704)->dbl == 0.0){
            DeRef(_13704);
            _13704 = NOVALUE;
            goto L3; // [70] 80
        }
        DeRef(_13704);
        _13704 = NOVALUE;
    }
    DeRef(_13704);
    _13704 = NOVALUE;

    /** 		return full_path*/
    DeRefDS(_fname_23931);
    DeRef(_errbuff_23934);
    DeRefDS(_currdir_23935);
    DeRef(_conf_path_23936);
    DeRef(_scan_result_23937);
    DeRef(_inc_path_23938);
    DeRef(_mainpath_23957);
    return _full_path_23933;
L3: 

    /** 	sequence mainpath = main_path[1..rfind(SLASH, main_path)]*/
    RefDS(_35main_path_16088);
    DeRef(_31396);
    _31396 = _35main_path_16088;
    if (IS_SEQUENCE(_31396)){
            _31397 = SEQ_PTR(_31396)->length;
    }
    else {
        _31397 = 1;
    }
    _31396 = NOVALUE;
    RefDS(_35main_path_16088);
    _13705 = _16rfind(47, _35main_path_16088, _31397);
    _31397 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mainpath_23957;
    RHS_Slice(_35main_path_16088, 1, _13705);

    /** 	if not equal(mainpath, currdir) then*/
    if (_mainpath_23957 == _currdir_23935)
    _13707 = 1;
    else if (IS_ATOM_INT(_mainpath_23957) && IS_ATOM_INT(_currdir_23935))
    _13707 = 0;
    else
    _13707 = (compare(_mainpath_23957, _currdir_23935) == 0);
    if (_13707 != 0)
    goto L4; // [111] 139
    _13707 = NOVALUE;

    /** 		full_path = mainpath & new_include_name*/
    Concat((object_ptr)&_full_path_23933, _mainpath_23957, _35new_include_name_16090);

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_23933);
    _13710 = _17file_exists(_full_path_23933);
    if (_13710 == 0) {
        DeRef(_13710);
        _13710 = NOVALUE;
        goto L5; // [128] 138
    }
    else {
        if (!IS_ATOM_INT(_13710) && DBL_PTR(_13710)->dbl == 0.0){
            DeRef(_13710);
            _13710 = NOVALUE;
            goto L5; // [128] 138
        }
        DeRef(_13710);
        _13710 = NOVALUE;
    }
    DeRef(_13710);
    _13710 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_23931);
    DeRef(_errbuff_23934);
    DeRefDS(_currdir_23935);
    DeRef(_conf_path_23936);
    DeRef(_scan_result_23937);
    DeRef(_inc_path_23938);
    DeRefDS(_mainpath_23957);
    _31396 = NOVALUE;
    DeRef(_13705);
    _13705 = NOVALUE;
    return _full_path_23933;
L5: 
L4: 

    /** 	scan_result = ConfPath(new_include_name)*/
    RefDS(_35new_include_name_16090);
    _0 = _scan_result_23937;
    _scan_result_23937 = _42ConfPath(_35new_include_name_16090);
    DeRef(_0);

    /** 	if atom(scan_result) then*/
    _13712 = IS_ATOM(_scan_result_23937);
    if (_13712 == 0)
    {
        _13712 = NOVALUE;
        goto L6; // [152] 164
    }
    else{
        _13712 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname,"EUINC",0)*/
    RefDS(_fname_23931);
    RefDS(_13713);
    _0 = _scan_result_23937;
    _scan_result_23937 = _42ScanPath(_fname_23931, _13713, 0);
    DeRef(_0);
L6: 

    /** 	if atom(scan_result) then*/
    _13715 = IS_ATOM(_scan_result_23937);
    if (_13715 == 0)
    {
        _13715 = NOVALUE;
        goto L7; // [169] 181
    }
    else{
        _13715 = NOVALUE;
    }

    /** 		scan_result = ScanPath(fname, "EUDIR",1)*/
    RefDS(_fname_23931);
    RefDS(_13716);
    _0 = _scan_result_23937;
    _scan_result_23937 = _42ScanPath(_fname_23931, _13716, 1);
    DeRef(_0);
L7: 

    /** 	if atom(scan_result) then*/
    _13718 = IS_ATOM(_scan_result_23937);
    if (_13718 == 0)
    {
        _13718 = NOVALUE;
        goto L8; // [186] 223
    }
    else{
        _13718 = NOVALUE;
    }

    /** 		full_path = get_eudir() & SLASH & "include" & SLASH & fname*/
    _13719 = _36get_eudir();
    {
        int concat_list[5];

        concat_list[0] = _fname_23931;
        concat_list[1] = 47;
        concat_list[2] = _13139;
        concat_list[3] = 47;
        concat_list[4] = _13719;
        Concat_N((object_ptr)&_full_path_23933, concat_list, 5);
    }
    DeRef(_13719);
    _13719 = NOVALUE;

    /** 		if file_exists(full_path) then*/
    RefDS(_full_path_23933);
    _13721 = _17file_exists(_full_path_23933);
    if (_13721 == 0) {
        DeRef(_13721);
        _13721 = NOVALUE;
        goto L9; // [212] 222
    }
    else {
        if (!IS_ATOM_INT(_13721) && DBL_PTR(_13721)->dbl == 0.0){
            DeRef(_13721);
            _13721 = NOVALUE;
            goto L9; // [212] 222
        }
        DeRef(_13721);
        _13721 = NOVALUE;
    }
    DeRef(_13721);
    _13721 = NOVALUE;

    /** 			return full_path*/
    DeRefDS(_fname_23931);
    DeRef(_errbuff_23934);
    DeRef(_currdir_23935);
    DeRef(_conf_path_23936);
    DeRef(_scan_result_23937);
    DeRef(_inc_path_23938);
    DeRef(_mainpath_23957);
    _31396 = NOVALUE;
    DeRef(_13705);
    _13705 = NOVALUE;
    return _full_path_23933;
L9: 
L8: 

    /** 	if sequence(scan_result) then*/
    _13722 = IS_SEQUENCE(_scan_result_23937);
    if (_13722 == 0)
    {
        _13722 = NOVALUE;
        goto LA; // [228] 250
    }
    else{
        _13722 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_23937);
    _13723 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_13723))
    EClose(_13723);
    else
    EClose((int)DBL_PTR(_13723)->dbl);
    _13723 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_23937);
    _13724 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_13724);
    DeRefDS(_fname_23931);
    DeRef(_full_path_23933);
    DeRef(_errbuff_23934);
    DeRef(_currdir_23935);
    DeRef(_conf_path_23936);
    DeRef(_scan_result_23937);
    DeRef(_inc_path_23938);
    DeRef(_mainpath_23957);
    _31396 = NOVALUE;
    DeRef(_13705);
    _13705 = NOVALUE;
    return _13724;
LA: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_23934);
    _errbuff_23934 = _5;

    /** 	full_path = {}*/
    RefDS(_5);
    DeRef(_full_path_23933);
    _full_path_23933 = _5;

    /** 	if length(currdir) > 0 then*/
    if (IS_SEQUENCE(_currdir_23935)){
            _13725 = SEQ_PTR(_currdir_23935)->length;
    }
    else {
        _13725 = 1;
    }
    if (_13725 <= 0)
    goto LB; // [269] 321

    /** 		if find(currdir[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_currdir_23935)){
            _13727 = SEQ_PTR(_currdir_23935)->length;
    }
    else {
        _13727 = 1;
    }
    _2 = (int)SEQ_PTR(_currdir_23935);
    _13728 = (int)*(((s1_ptr)_2)->base + _13727);
    _13729 = find_from(_13728, _40SLASH_CHARS_16126, 1);
    _13728 = NOVALUE;
    if (_13729 == 0)
    {
        _13729 = NOVALUE;
        goto LC; // [289] 313
    }
    else{
        _13729 = NOVALUE;
    }

    /** 			full_path = append(full_path, currdir[1..$-1])*/
    if (IS_SEQUENCE(_currdir_23935)){
            _13730 = SEQ_PTR(_currdir_23935)->length;
    }
    else {
        _13730 = 1;
    }
    _13731 = _13730 - 1;
    _13730 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13732;
    RHS_Slice(_currdir_23935, 1, _13731);
    RefDS(_13732);
    Append(&_full_path_23933, _full_path_23933, _13732);
    DeRefDS(_13732);
    _13732 = NOVALUE;
    goto LD; // [310] 320
LC: 

    /** 			full_path = append(full_path, currdir)*/
    RefDS(_currdir_23935);
    Append(&_full_path_23933, _full_path_23933, _currdir_23935);
LD: 
LB: 

    /** 	if find(main_path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_35main_path_16088)){
            _13735 = SEQ_PTR(_35main_path_16088)->length;
    }
    else {
        _13735 = 1;
    }
    _2 = (int)SEQ_PTR(_35main_path_16088);
    _13736 = (int)*(((s1_ptr)_2)->base + _13735);
    _13737 = find_from(_13736, _40SLASH_CHARS_16126, 1);
    _13736 = NOVALUE;
    if (_13737 == 0)
    {
        _13737 = NOVALUE;
        goto LE; // [339] 361
    }
    else{
        _13737 = NOVALUE;
    }

    /** 		errbuff = main_path[1..$-1]  -- looks better*/
    if (IS_SEQUENCE(_35main_path_16088)){
            _13738 = SEQ_PTR(_35main_path_16088)->length;
    }
    else {
        _13738 = 1;
    }
    _13739 = _13738 - 1;
    _13738 = NOVALUE;
    rhs_slice_target = (object_ptr)&_errbuff_23934;
    RHS_Slice(_35main_path_16088, 1, _13739);
    goto LF; // [358] 371
LE: 

    /** 		errbuff = main_path*/
    RefDS(_35main_path_16088);
    DeRef(_errbuff_23934);
    _errbuff_23934 = _35main_path_16088;
LF: 

    /** 	if not find(errbuff, full_path) then*/
    _13741 = find_from(_errbuff_23934, _full_path_23933, 1);
    if (_13741 != 0)
    goto L10; // [378] 388
    _13741 = NOVALUE;

    /** 		full_path = append(full_path, errbuff)*/
    RefDS(_errbuff_23934);
    Append(&_full_path_23933, _full_path_23933, _errbuff_23934);
L10: 

    /** 	conf_path = get_conf_dirs()*/
    _0 = _conf_path_23936;
    _conf_path_23936 = _42get_conf_dirs();
    DeRef(_0);

    /** 	if length(conf_path) > 0 then*/
    if (IS_SEQUENCE(_conf_path_23936)){
            _13745 = SEQ_PTR(_conf_path_23936)->length;
    }
    else {
        _13745 = 1;
    }
    if (_13745 <= 0)
    goto L11; // [400] 507

    /** 		conf_path = split(conf_path, PATHSEP)*/
    RefDS(_conf_path_23936);
    _0 = _conf_path_23936;
    _conf_path_23936 = _23split(_conf_path_23936, 58, 0, 0);
    DeRefDS(_0);

    /** 		for i = 1 to length(conf_path) do*/
    if (IS_SEQUENCE(_conf_path_23936)){
            _13748 = SEQ_PTR(_conf_path_23936)->length;
    }
    else {
        _13748 = 1;
    }
    {
        int _i_24038;
        _i_24038 = 1;
L12: 
        if (_i_24038 > _13748){
            goto L13; // [422] 506
        }

        /** 			if find(conf_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_conf_path_23936);
        _13749 = (int)*(((s1_ptr)_2)->base + _i_24038);
        if (IS_SEQUENCE(_13749)){
                _13750 = SEQ_PTR(_13749)->length;
        }
        else {
            _13750 = 1;
        }
        _2 = (int)SEQ_PTR(_13749);
        _13751 = (int)*(((s1_ptr)_2)->base + _13750);
        _13749 = NOVALUE;
        _13752 = find_from(_13751, _40SLASH_CHARS_16126, 1);
        _13751 = NOVALUE;
        if (_13752 == 0)
        {
            _13752 = NOVALUE;
            goto L14; // [449] 473
        }
        else{
            _13752 = NOVALUE;
        }

        /** 				errbuff = conf_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_conf_path_23936);
        _13753 = (int)*(((s1_ptr)_2)->base + _i_24038);
        if (IS_SEQUENCE(_13753)){
                _13754 = SEQ_PTR(_13753)->length;
        }
        else {
            _13754 = 1;
        }
        _13755 = _13754 - 1;
        _13754 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_23934;
        RHS_Slice(_13753, 1, _13755);
        _13753 = NOVALUE;
        goto L15; // [470] 482
L14: 

        /** 				errbuff = conf_path[i]*/
        DeRef(_errbuff_23934);
        _2 = (int)SEQ_PTR(_conf_path_23936);
        _errbuff_23934 = (int)*(((s1_ptr)_2)->base + _i_24038);
        Ref(_errbuff_23934);
L15: 

        /** 			if not find(errbuff, full_path) then*/
        _13758 = find_from(_errbuff_23934, _full_path_23933, 1);
        if (_13758 != 0)
        goto L16; // [489] 499
        _13758 = NOVALUE;

        /** 				full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_23934);
        Append(&_full_path_23933, _full_path_23933, _errbuff_23934);
L16: 

        /** 		end for*/
        _i_24038 = _i_24038 + 1;
        goto L12; // [501] 429
L13: 
        ;
    }
L11: 

    /** 	inc_path = getenv("EUINC")*/
    DeRef(_inc_path_23938);
    _inc_path_23938 = EGetEnv(_13713);

    /** 	if sequence(inc_path) then*/
    _13762 = IS_SEQUENCE(_inc_path_23938);
    if (_13762 == 0)
    {
        _13762 = NOVALUE;
        goto L17; // [517] 631
    }
    else{
        _13762 = NOVALUE;
    }

    /** 		if length(inc_path) > 0 then*/
    if (IS_SEQUENCE(_inc_path_23938)){
            _13763 = SEQ_PTR(_inc_path_23938)->length;
    }
    else {
        _13763 = 1;
    }
    if (_13763 <= 0)
    goto L18; // [525] 630

    /** 			inc_path = split(inc_path, PATHSEP)*/
    Ref(_inc_path_23938);
    _0 = _inc_path_23938;
    _inc_path_23938 = _23split(_inc_path_23938, 58, 0, 0);
    DeRefi(_0);

    /** 			for i = 1 to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_23938)){
            _13766 = SEQ_PTR(_inc_path_23938)->length;
    }
    else {
        _13766 = 1;
    }
    {
        int _i_24066;
        _i_24066 = 1;
L19: 
        if (_i_24066 > _13766){
            goto L1A; // [545] 629
        }

        /** 				if find(inc_path[i][$], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_inc_path_23938);
        _13767 = (int)*(((s1_ptr)_2)->base + _i_24066);
        if (IS_SEQUENCE(_13767)){
                _13768 = SEQ_PTR(_13767)->length;
        }
        else {
            _13768 = 1;
        }
        _2 = (int)SEQ_PTR(_13767);
        _13769 = (int)*(((s1_ptr)_2)->base + _13768);
        _13767 = NOVALUE;
        _13770 = find_from(_13769, _40SLASH_CHARS_16126, 1);
        _13769 = NOVALUE;
        if (_13770 == 0)
        {
            _13770 = NOVALUE;
            goto L1B; // [572] 596
        }
        else{
            _13770 = NOVALUE;
        }

        /** 					errbuff = inc_path[i][1..$-1]  -- looks better*/
        _2 = (int)SEQ_PTR(_inc_path_23938);
        _13771 = (int)*(((s1_ptr)_2)->base + _i_24066);
        if (IS_SEQUENCE(_13771)){
                _13772 = SEQ_PTR(_13771)->length;
        }
        else {
            _13772 = 1;
        }
        _13773 = _13772 - 1;
        _13772 = NOVALUE;
        rhs_slice_target = (object_ptr)&_errbuff_23934;
        RHS_Slice(_13771, 1, _13773);
        _13771 = NOVALUE;
        goto L1C; // [593] 605
L1B: 

        /** 					errbuff = inc_path[i]*/
        DeRef(_errbuff_23934);
        _2 = (int)SEQ_PTR(_inc_path_23938);
        _errbuff_23934 = (int)*(((s1_ptr)_2)->base + _i_24066);
        Ref(_errbuff_23934);
L1C: 

        /** 				if not find(errbuff, full_path) then*/
        _13776 = find_from(_errbuff_23934, _full_path_23933, 1);
        if (_13776 != 0)
        goto L1D; // [612] 622
        _13776 = NOVALUE;

        /** 					full_path = append(full_path, errbuff)*/
        RefDS(_errbuff_23934);
        Append(&_full_path_23933, _full_path_23933, _errbuff_23934);
L1D: 

        /** 			end for*/
        _i_24066 = _i_24066 + 1;
        goto L19; // [624] 552
L1A: 
        ;
    }
L18: 
L17: 

    /** 	if length(get_eudir()) > 0 then*/
    _13779 = _36get_eudir();
    if (IS_SEQUENCE(_13779)){
            _13780 = SEQ_PTR(_13779)->length;
    }
    else {
        _13780 = 1;
    }
    DeRef(_13779);
    _13779 = NOVALUE;
    if (_13780 <= 0)
    goto L1E; // [639] 667

    /** 		if not find(get_eudir(), full_path) then*/
    _13782 = _36get_eudir();
    _13783 = find_from(_13782, _full_path_23933, 1);
    DeRef(_13782);
    _13782 = NOVALUE;
    if (_13783 != 0)
    goto L1F; // [653] 666
    _13783 = NOVALUE;

    /** 			full_path = append(full_path, get_eudir())*/
    _13785 = _36get_eudir();
    Ref(_13785);
    Append(&_full_path_23933, _full_path_23933, _13785);
    DeRef(_13785);
    _13785 = NOVALUE;
L1F: 
L1E: 

    /** 	errbuff = ""*/
    RefDS(_5);
    DeRef(_errbuff_23934);
    _errbuff_23934 = _5;

    /** 	for i = 1 to length(full_path) do*/
    if (IS_SEQUENCE(_full_path_23933)){
            _13787 = SEQ_PTR(_full_path_23933)->length;
    }
    else {
        _13787 = 1;
    }
    {
        int _i_24098;
        _i_24098 = 1;
L20: 
        if (_i_24098 > _13787){
            goto L21; // [679] 711
        }

        /** 		errbuff &= sprintf("\t%s\n", {full_path[i]})*/
        _2 = (int)SEQ_PTR(_full_path_23933);
        _13789 = (int)*(((s1_ptr)_2)->base + _i_24098);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13789);
        *((int *)(_2+4)) = _13789;
        _13790 = MAKE_SEQ(_1);
        _13789 = NOVALUE;
        _13791 = EPrintf(-9999999, _13788, _13790);
        DeRefDS(_13790);
        _13790 = NOVALUE;
        Concat((object_ptr)&_errbuff_23934, _errbuff_23934, _13791);
        DeRefDS(_13791);
        _13791 = NOVALUE;

        /** 	end for*/
        _i_24098 = _i_24098 + 1;
        goto L20; // [706] 686
L21: 
        ;
    }

    /** 	CompileErr(52, {new_include_name, errbuff})*/
    RefDS(_errbuff_23934);
    RefDS(_35new_include_name_16090);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _35new_include_name_16090;
    ((int *)_2)[2] = _errbuff_23934;
    _13793 = MAKE_SEQ(_1);
    _44CompileErr(52, _13793, 0);
    _13793 = NOVALUE;
    ;
}


int _61path_open()
{
    int _fh_24110 = NOVALUE;
    int _0, _1, _2;
    

    /** 	new_include_name = find_file(new_include_name)*/
    RefDS(_35new_include_name_16090);
    _0 = _61find_file(_35new_include_name_16090);
    DeRefDS(_35new_include_name_16090);
    _35new_include_name_16090 = _0;

    /** 	new_include_name = maybe_preprocess(new_include_name)*/
    RefDS(_35new_include_name_16090);
    _0 = _64maybe_preprocess(_35new_include_name_16090);
    DeRefDS(_35new_include_name_16090);
    _35new_include_name_16090 = _0;

    /** 	fh = open_locked(new_include_name)*/
    RefDS(_35new_include_name_16090);
    _fh_24110 = _36open_locked(_35new_include_name_16090);
    if (!IS_ATOM_INT(_fh_24110)) {
        _1 = (long)(DBL_PTR(_fh_24110)->dbl);
        DeRefDS(_fh_24110);
        _fh_24110 = _1;
    }

    /** 	return fh*/
    return _fh_24110;
    ;
}


int _61NameSpace_declaration(int _sym_24134)
{
    int _h_24135 = NOVALUE;
    int _13815 = NOVALUE;
    int _13813 = NOVALUE;
    int _13811 = NOVALUE;
    int _13809 = NOVALUE;
    int _13808 = NOVALUE;
    int _13807 = NOVALUE;
    int _13805 = NOVALUE;
    int _13804 = NOVALUE;
    int _13803 = NOVALUE;
    int _13802 = NOVALUE;
    int _13801 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_24134)) {
        _1 = (long)(DBL_PTR(_sym_24134)->dbl);
        DeRefDS(_sym_24134);
        _sym_24134 = _1;
    }

    /** 	DefinedYet(sym)*/
    _53DefinedYet(_sym_24134);

    /** 	if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_PREDEF}) then*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _13801 = (int)*(((s1_ptr)_2)->base + _sym_24134);
    _2 = (int)SEQ_PTR(_13801);
    _13802 = (int)*(((s1_ptr)_2)->base + 4);
    _13801 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 11;
    *((int *)(_2+16)) = 7;
    _13803 = MAKE_SEQ(_1);
    _13804 = find_from(_13802, _13803, 1);
    _13802 = NOVALUE;
    DeRefDS(_13803);
    _13803 = NOVALUE;
    if (_13804 == 0)
    {
        _13804 = NOVALUE;
        goto L1; // [42] 104
    }
    else{
        _13804 = NOVALUE;
    }

    /** 		h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _13805 = (int)*(((s1_ptr)_2)->base + _sym_24134);
    _2 = (int)SEQ_PTR(_13805);
    _h_24135 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_24135)){
        _h_24135 = (long)DBL_PTR(_h_24135)->dbl;
    }
    _13805 = NOVALUE;

    /** 		sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _13807 = (int)*(((s1_ptr)_2)->base + _sym_24134);
    _2 = (int)SEQ_PTR(_13807);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _13808 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _13808 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _13807 = NOVALUE;
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _13809 = (int)*(((s1_ptr)_2)->base + _h_24135);
    Ref(_13808);
    Ref(_13809);
    _sym_24134 = _53NewEntry(_13808, 0, 0, -100, _h_24135, _13809, 0);
    _13808 = NOVALUE;
    _13809 = NOVALUE;
    if (!IS_ATOM_INT(_sym_24134)) {
        _1 = (long)(DBL_PTR(_sym_24134)->dbl);
        DeRefDS(_sym_24134);
        _sym_24134 = _1;
    }

    /** 		buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_53buckets_45711);
    _2 = (int)(((s1_ptr)_2)->base + _h_24135);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_24134;
    DeRef(_1);
L1: 

    /** 	SymTab[sym][S_SCOPE] = SC_LOCAL*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24134 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 5;
    DeRef(_1);
    _13811 = NOVALUE;

    /** 	SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24134 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _13813 = NOVALUE;

    /** 	SymTab[sym][S_TOKEN] = NAMESPACE -- [S_OBJ] will get the file number referred-to*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24134 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_TOKEN_15646))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_TOKEN_15646)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_TOKEN_15646);
    _1 = *(int *)_2;
    *(int *)_2 = 523;
    DeRef(_1);
    _13815 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_35TRANSLATE_15611 == 0)
    {
        goto L2; // [159] 173
    }
    else{
    }

    /** 		num_routines += 1 -- order of ns declaration relative to routines*/
    _35num_routines_15977 = _35num_routines_15977 + 1;
L2: 

    /** 	return sym*/
    return _sym_24134;
    ;
}


void _61default_namespace()
{
    int _tok_24185 = NOVALUE;
    int _sym_24187 = NOVALUE;
    int _13839 = NOVALUE;
    int _13838 = NOVALUE;
    int _13836 = NOVALUE;
    int _13834 = NOVALUE;
    int _13831 = NOVALUE;
    int _13828 = NOVALUE;
    int _13826 = NOVALUE;
    int _13824 = NOVALUE;
    int _13823 = NOVALUE;
    int _13822 = NOVALUE;
    int _13821 = NOVALUE;
    int _13820 = NOVALUE;
    int _13819 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_61scanner_rid_24181].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24185);
    _tok_24185 = _1;

    /** 	if tok[T_ID] = VARIABLE and equal( SymTab[tok[T_SYM]][S_NAME], "namespace" ) then*/
    _2 = (int)SEQ_PTR(_tok_24185);
    _13819 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13819)) {
        _13820 = (_13819 == -100);
    }
    else {
        _13820 = binary_op(EQUALS, _13819, -100);
    }
    _13819 = NOVALUE;
    if (IS_ATOM_INT(_13820)) {
        if (_13820 == 0) {
            goto L1; // [23] 177
        }
    }
    else {
        if (DBL_PTR(_13820)->dbl == 0.0) {
            goto L1; // [23] 177
        }
    }
    _2 = (int)SEQ_PTR(_tok_24185);
    _13822 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_13822)){
        _13823 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13822)->dbl));
    }
    else{
        _13823 = (int)*(((s1_ptr)_2)->base + _13822);
    }
    _2 = (int)SEQ_PTR(_13823);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _13824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _13824 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _13823 = NOVALUE;
    if (_13824 == _13825)
    _13826 = 1;
    else if (IS_ATOM_INT(_13824) && IS_ATOM_INT(_13825))
    _13826 = 0;
    else
    _13826 = (compare(_13824, _13825) == 0);
    _13824 = NOVALUE;
    if (_13826 == 0)
    {
        _13826 = NOVALUE;
        goto L1; // [50] 177
    }
    else{
        _13826 = NOVALUE;
    }

    /** 		tok = call_func( scanner_rid, {} )*/
    _0 = (int)_00[_61scanner_rid_24181].addr;
    _1 = (*(int (*)())_0)(
                         );
    DeRef(_tok_24185);
    _tok_24185 = _1;

    /** 		if tok[T_ID] != VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_24185);
    _13828 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _13828, -100)){
        _13828 = NOVALUE;
        goto L2; // [71] 83
    }
    _13828 = NOVALUE;

    /** 			CompileErr(114)*/
    RefDS(_21815);
    _44CompileErr(114, _21815, 0);
L2: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_24185);
    _sym_24187 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_24187)){
        _sym_24187 = (long)DBL_PTR(_sym_24187)->dbl;
    }

    /** 		SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24187 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_FILE_NO_15637))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_FILE_NO_15637)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_FILE_NO_15637);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);
    _13831 = NOVALUE;

    /** 		sym  = NameSpace_declaration( sym )*/
    _sym_24187 = _61NameSpace_declaration(_sym_24187);
    if (!IS_ATOM_INT(_sym_24187)) {
        _1 = (long)(DBL_PTR(_sym_24187)->dbl);
        DeRefDS(_sym_24187);
        _sym_24187 = _1;
    }

    /** 		SymTab[sym][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24187 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);
    _13834 = NOVALUE;

    /** 		SymTab[sym][S_SCOPE] = SC_PUBLIC*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_24187 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 13;
    DeRef(_1);
    _13836 = NOVALUE;

    /** 		default_namespaces[current_file_no] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    _13838 = (int)*(((s1_ptr)_2)->base + _sym_24187);
    _2 = (int)SEQ_PTR(_13838);
    if (!IS_ATOM_INT(_35S_NAME_15641)){
        _13839 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_NAME_15641)->dbl));
    }
    else{
        _13839 = (int)*(((s1_ptr)_2)->base + _35S_NAME_15641);
    }
    _13838 = NOVALUE;
    Ref(_13839);
    _2 = (int)SEQ_PTR(_61default_namespaces_23552);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _13839;
    if( _1 != _13839 ){
        DeRef(_1);
    }
    _13839 = NOVALUE;
    goto L3; // [174] 185
L1: 

    /** 		bp = 1*/
    _44bp_48146 = 1;
L3: 

    /** end procedure*/
    DeRef(_tok_24185);
    _13822 = NOVALUE;
    DeRef(_13820);
    _13820 = NOVALUE;
    return;
    ;
}


void _61add_exports(int _from_file_24237, int _to_file_24238)
{
    int _exports_24239 = NOVALUE;
    int _direct_24240 = NOVALUE;
    int _13859 = NOVALUE;
    int _13858 = NOVALUE;
    int _13857 = NOVALUE;
    int _13856 = NOVALUE;
    int _13855 = NOVALUE;
    int _13853 = NOVALUE;
    int _13851 = NOVALUE;
    int _13850 = NOVALUE;
    int _13848 = NOVALUE;
    int _13847 = NOVALUE;
    int _13846 = NOVALUE;
    int _13844 = NOVALUE;
    int _13843 = NOVALUE;
    int _13842 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	direct = file_include[to_file]*/
    DeRef(_direct_24240);
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _direct_24240 = (int)*(((s1_ptr)_2)->base + _to_file_24238);
    Ref(_direct_24240);

    /** 	exports = file_public[from_file]*/
    DeRef(_exports_24239);
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _exports_24239 = (int)*(((s1_ptr)_2)->base + _from_file_24237);
    Ref(_exports_24239);

    /** 	for i = 1 to length(exports) do*/
    if (IS_SEQUENCE(_exports_24239)){
            _13842 = SEQ_PTR(_exports_24239)->length;
    }
    else {
        _13842 = 1;
    }
    {
        int _i_24246;
        _i_24246 = 1;
L1: 
        if (_i_24246 > _13842){
            goto L2; // [30] 127
        }

        /** 		if not find( exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24239);
        _13843 = (int)*(((s1_ptr)_2)->base + _i_24246);
        _13844 = find_from(_13843, _direct_24240, 1);
        _13843 = NOVALUE;
        if (_13844 != 0)
        goto L3; // [48] 120
        _13844 = NOVALUE;

        /** 			if not find( -exports[i], direct ) then*/
        _2 = (int)SEQ_PTR(_exports_24239);
        _13846 = (int)*(((s1_ptr)_2)->base + _i_24246);
        if (IS_ATOM_INT(_13846)) {
            if ((unsigned long)_13846 == 0xC0000000)
            _13847 = (int)NewDouble((double)-0xC0000000);
            else
            _13847 = - _13846;
        }
        else {
            _13847 = unary_op(UMINUS, _13846);
        }
        _13846 = NOVALUE;
        _13848 = find_from(_13847, _direct_24240, 1);
        DeRef(_13847);
        _13847 = NOVALUE;
        if (_13848 != 0)
        goto L4; // [65] 82
        _13848 = NOVALUE;

        /** 				direct &= -exports[i]*/
        _2 = (int)SEQ_PTR(_exports_24239);
        _13850 = (int)*(((s1_ptr)_2)->base + _i_24246);
        if (IS_ATOM_INT(_13850)) {
            if ((unsigned long)_13850 == 0xC0000000)
            _13851 = (int)NewDouble((double)-0xC0000000);
            else
            _13851 = - _13850;
        }
        else {
            _13851 = unary_op(UMINUS, _13850);
        }
        _13850 = NOVALUE;
        if (IS_SEQUENCE(_direct_24240) && IS_ATOM(_13851)) {
            Ref(_13851);
            Append(&_direct_24240, _direct_24240, _13851);
        }
        else if (IS_ATOM(_direct_24240) && IS_SEQUENCE(_13851)) {
        }
        else {
            Concat((object_ptr)&_direct_24240, _direct_24240, _13851);
        }
        DeRef(_13851);
        _13851 = NOVALUE;
L4: 

        /** 			include_matrix[to_file][exports[i]] = or_bits( PUBLIC_INCLUDE, include_matrix[to_file][exports[i]] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_14988 = MAKE_SEQ(_2);
        }
        _3 = (int)(_to_file_24238 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_exports_24239);
        _13855 = (int)*(((s1_ptr)_2)->base + _i_24246);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _13856 = (int)*(((s1_ptr)_2)->base + _to_file_24238);
        _2 = (int)SEQ_PTR(_exports_24239);
        _13857 = (int)*(((s1_ptr)_2)->base + _i_24246);
        _2 = (int)SEQ_PTR(_13856);
        if (!IS_ATOM_INT(_13857)){
            _13858 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13857)->dbl));
        }
        else{
            _13858 = (int)*(((s1_ptr)_2)->base + _13857);
        }
        _13856 = NOVALUE;
        if (IS_ATOM_INT(_13858)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13858;
                 _13859 = MAKE_UINT(tu);
            }
        }
        else {
            _13859 = binary_op(OR_BITS, 4, _13858);
        }
        _13858 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13855))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13855)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _13855);
        _1 = *(int *)_2;
        *(int *)_2 = _13859;
        if( _1 != _13859 ){
            DeRef(_1);
        }
        _13859 = NOVALUE;
        _13853 = NOVALUE;
L3: 

        /** 	end for*/
        _i_24246 = _i_24246 + 1;
        goto L1; // [122] 37
L2: 
        ;
    }

    /** 	file_include[to_file] = direct*/
    RefDS(_direct_24240);
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _2 = (int)(((s1_ptr)_2)->base + _to_file_24238);
    _1 = *(int *)_2;
    *(int *)_2 = _direct_24240;
    DeRef(_1);

    /** end procedure*/
    DeRef(_exports_24239);
    DeRefDS(_direct_24240);
    _13855 = NOVALUE;
    _13857 = NOVALUE;
    return;
    ;
}


void _61patch_exports(int _for_file_24273)
{
    int _export_len_24274 = NOVALUE;
    int _13870 = NOVALUE;
    int _13869 = NOVALUE;
    int _13867 = NOVALUE;
    int _13866 = NOVALUE;
    int _13865 = NOVALUE;
    int _13864 = NOVALUE;
    int _13862 = NOVALUE;
    int _13861 = NOVALUE;
    int _13860 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(file_include) do*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _13860 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _13860 = 1;
    }
    {
        int _i_24276;
        _i_24276 = 1;
L1: 
        if (_i_24276 > _13860){
            goto L2; // [10] 99
        }

        /** 		if find( for_file, file_include[i] ) or find( -for_file, file_include[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_14986);
        _13861 = (int)*(((s1_ptr)_2)->base + _i_24276);
        _13862 = find_from(_for_file_24273, _13861, 1);
        _13861 = NOVALUE;
        if (_13862 != 0) {
            goto L3; // [30] 53
        }
        if ((unsigned long)_for_file_24273 == 0xC0000000)
        _13864 = (int)NewDouble((double)-0xC0000000);
        else
        _13864 = - _for_file_24273;
        _2 = (int)SEQ_PTR(_36file_include_14986);
        _13865 = (int)*(((s1_ptr)_2)->base + _i_24276);
        _13866 = find_from(_13864, _13865, 1);
        DeRef(_13864);
        _13864 = NOVALUE;
        _13865 = NOVALUE;
        if (_13866 == 0)
        {
            _13866 = NOVALUE;
            goto L4; // [49] 92
        }
        else{
            _13866 = NOVALUE;
        }
L3: 

        /** 			export_len = length( file_include[i] )*/
        _2 = (int)SEQ_PTR(_36file_include_14986);
        _13867 = (int)*(((s1_ptr)_2)->base + _i_24276);
        if (IS_SEQUENCE(_13867)){
                _export_len_24274 = SEQ_PTR(_13867)->length;
        }
        else {
            _export_len_24274 = 1;
        }
        _13867 = NOVALUE;

        /** 			add_exports( for_file, i )*/
        _61add_exports(_for_file_24273, _i_24276);

        /** 			if length( file_include[i] ) != export_len then*/
        _2 = (int)SEQ_PTR(_36file_include_14986);
        _13869 = (int)*(((s1_ptr)_2)->base + _i_24276);
        if (IS_SEQUENCE(_13869)){
                _13870 = SEQ_PTR(_13869)->length;
        }
        else {
            _13870 = 1;
        }
        _13869 = NOVALUE;
        if (_13870 == _export_len_24274)
        goto L5; // [81] 91

        /** 				patch_exports( i )*/
        _61patch_exports(_i_24276);
L5: 
L4: 

        /** 	end for*/
        _i_24276 = _i_24276 + 1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** end procedure*/
    _13867 = NOVALUE;
    _13869 = NOVALUE;
    return;
    ;
}


void _61update_include_matrix(int _included_file_24298, int _from_file_24299)
{
    int _add_public_24309 = NOVALUE;
    int _px_24327 = NOVALUE;
    int _indirect_24386 = NOVALUE;
    int _mask_24389 = NOVALUE;
    int _ix_24400 = NOVALUE;
    int _indirect_file_24404 = NOVALUE;
    int _13946 = NOVALUE;
    int _13945 = NOVALUE;
    int _13943 = NOVALUE;
    int _13942 = NOVALUE;
    int _13941 = NOVALUE;
    int _13940 = NOVALUE;
    int _13939 = NOVALUE;
    int _13938 = NOVALUE;
    int _13937 = NOVALUE;
    int _13936 = NOVALUE;
    int _13935 = NOVALUE;
    int _13932 = NOVALUE;
    int _13930 = NOVALUE;
    int _13929 = NOVALUE;
    int _13928 = NOVALUE;
    int _13926 = NOVALUE;
    int _13924 = NOVALUE;
    int _13923 = NOVALUE;
    int _13921 = NOVALUE;
    int _13920 = NOVALUE;
    int _13919 = NOVALUE;
    int _13918 = NOVALUE;
    int _13917 = NOVALUE;
    int _13915 = NOVALUE;
    int _13914 = NOVALUE;
    int _13913 = NOVALUE;
    int _13912 = NOVALUE;
    int _13911 = NOVALUE;
    int _13910 = NOVALUE;
    int _13908 = NOVALUE;
    int _13907 = NOVALUE;
    int _13906 = NOVALUE;
    int _13904 = NOVALUE;
    int _13903 = NOVALUE;
    int _13902 = NOVALUE;
    int _13901 = NOVALUE;
    int _13900 = NOVALUE;
    int _13899 = NOVALUE;
    int _13898 = NOVALUE;
    int _13897 = NOVALUE;
    int _13896 = NOVALUE;
    int _13895 = NOVALUE;
    int _13894 = NOVALUE;
    int _13892 = NOVALUE;
    int _13891 = NOVALUE;
    int _13889 = NOVALUE;
    int _13887 = NOVALUE;
    int _13885 = NOVALUE;
    int _13884 = NOVALUE;
    int _13883 = NOVALUE;
    int _13882 = NOVALUE;
    int _13880 = NOVALUE;
    int _13879 = NOVALUE;
    int _13878 = NOVALUE;
    int _13876 = NOVALUE;
    int _13875 = NOVALUE;
    int _13874 = NOVALUE;
    int _13872 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[from_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[from_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    _3 = (int)(_from_file_24299 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13874 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    _2 = (int)SEQ_PTR(_13874);
    _13875 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
    _13874 = NOVALUE;
    if (IS_ATOM_INT(_13875)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_13875;
             _13876 = MAKE_UINT(tu);
        }
    }
    else {
        _13876 = binary_op(OR_BITS, 2, _13875);
    }
    _13875 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24298);
    _1 = *(int *)_2;
    *(int *)_2 = _13876;
    if( _1 != _13876 ){
        DeRef(_1);
    }
    _13876 = NOVALUE;
    _13872 = NOVALUE;

    /** 	if public_include then*/
    if (_61public_include_23549 == 0)
    {
        goto L1; // [38] 339
    }
    else{
    }

    /** 		sequence add_public = file_include_by[from_file]*/
    DeRef(_add_public_24309);
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _add_public_24309 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    Ref(_add_public_24309);

    /** 		for i = 1 to length( add_public ) do*/
    if (IS_SEQUENCE(_add_public_24309)){
            _13878 = SEQ_PTR(_add_public_24309)->length;
    }
    else {
        _13878 = 1;
    }
    {
        int _i_24313;
        _i_24313 = 1;
L2: 
        if (_i_24313 > _13878){
            goto L3; // [56] 107
        }

        /** 			include_matrix[add_public[i]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13879 = (int)*(((s1_ptr)_2)->base + _i_24313);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_14988 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13879))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13879)->dbl));
        else
        _3 = (int)(_13879 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13882 = (int)*(((s1_ptr)_2)->base + _i_24313);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!IS_ATOM_INT(_13882)){
            _13883 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13882)->dbl));
        }
        else{
            _13883 = (int)*(((s1_ptr)_2)->base + _13882);
        }
        _2 = (int)SEQ_PTR(_13883);
        _13884 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
        _13883 = NOVALUE;
        if (IS_ATOM_INT(_13884)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13884;
                 _13885 = MAKE_UINT(tu);
            }
        }
        else {
            _13885 = binary_op(OR_BITS, 4, _13884);
        }
        _13884 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24298);
        _1 = *(int *)_2;
        *(int *)_2 = _13885;
        if( _1 != _13885 ){
            DeRef(_1);
        }
        _13885 = NOVALUE;
        _13880 = NOVALUE;

        /** 		end for*/
        _i_24313 = _i_24313 + 1;
        goto L2; // [102] 63
L3: 
        ;
    }

    /** 		add_public = file_public_by[from_file]*/
    DeRef(_add_public_24309);
    _2 = (int)SEQ_PTR(_36file_public_by_14996);
    _add_public_24309 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    Ref(_add_public_24309);

    /** 		integer px = length( add_public ) + 1*/
    if (IS_SEQUENCE(_add_public_24309)){
            _13887 = SEQ_PTR(_add_public_24309)->length;
    }
    else {
        _13887 = 1;
    }
    _px_24327 = _13887 + 1;
    _13887 = NOVALUE;

    /** 		while px <= length( add_public ) do*/
L4: 
    if (IS_SEQUENCE(_add_public_24309)){
            _13889 = SEQ_PTR(_add_public_24309)->length;
    }
    else {
        _13889 = 1;
    }
    if (_px_24327 > _13889)
    goto L5; // [134] 338

    /** 			include_matrix[add_public[px]][included_file] =*/
    _2 = (int)SEQ_PTR(_add_public_24309);
    _13891 = (int)*(((s1_ptr)_2)->base + _px_24327);
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_13891))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13891)->dbl));
    else
    _3 = (int)(_13891 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_add_public_24309);
    _13894 = (int)*(((s1_ptr)_2)->base + _px_24327);
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!IS_ATOM_INT(_13894)){
        _13895 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13894)->dbl));
    }
    else{
        _13895 = (int)*(((s1_ptr)_2)->base + _13894);
    }
    _2 = (int)SEQ_PTR(_13895);
    _13896 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
    _13895 = NOVALUE;
    if (IS_ATOM_INT(_13896)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_13896;
             _13897 = MAKE_UINT(tu);
        }
    }
    else {
        _13897 = binary_op(OR_BITS, 4, _13896);
    }
    _13896 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24298);
    _1 = *(int *)_2;
    *(int *)_2 = _13897;
    if( _1 != _13897 ){
        DeRef(_1);
    }
    _13897 = NOVALUE;
    _13892 = NOVALUE;

    /** 			for i = 1 to length( file_public_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24309);
    _13898 = (int)*(((s1_ptr)_2)->base + _px_24327);
    _2 = (int)SEQ_PTR(_36file_public_by_14996);
    if (!IS_ATOM_INT(_13898)){
        _13899 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13898)->dbl));
    }
    else{
        _13899 = (int)*(((s1_ptr)_2)->base + _13898);
    }
    if (IS_SEQUENCE(_13899)){
            _13900 = SEQ_PTR(_13899)->length;
    }
    else {
        _13900 = 1;
    }
    _13899 = NOVALUE;
    {
        int _i_24344;
        _i_24344 = 1;
L6: 
        if (_i_24344 > _13900){
            goto L7; // [190] 249
        }

        /** 				if not find( file_public[add_public[px]][i], add_public ) then*/
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13901 = (int)*(((s1_ptr)_2)->base + _px_24327);
        _2 = (int)SEQ_PTR(_36file_public_14992);
        if (!IS_ATOM_INT(_13901)){
            _13902 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13901)->dbl));
        }
        else{
            _13902 = (int)*(((s1_ptr)_2)->base + _13901);
        }
        _2 = (int)SEQ_PTR(_13902);
        _13903 = (int)*(((s1_ptr)_2)->base + _i_24344);
        _13902 = NOVALUE;
        _13904 = find_from(_13903, _add_public_24309, 1);
        _13903 = NOVALUE;
        if (_13904 != 0)
        goto L8; // [218] 242
        _13904 = NOVALUE;

        /** 					add_public &= file_public[add_public[px]][i]*/
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13906 = (int)*(((s1_ptr)_2)->base + _px_24327);
        _2 = (int)SEQ_PTR(_36file_public_14992);
        if (!IS_ATOM_INT(_13906)){
            _13907 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13906)->dbl));
        }
        else{
            _13907 = (int)*(((s1_ptr)_2)->base + _13906);
        }
        _2 = (int)SEQ_PTR(_13907);
        _13908 = (int)*(((s1_ptr)_2)->base + _i_24344);
        _13907 = NOVALUE;
        if (IS_SEQUENCE(_add_public_24309) && IS_ATOM(_13908)) {
            Ref(_13908);
            Append(&_add_public_24309, _add_public_24309, _13908);
        }
        else if (IS_ATOM(_add_public_24309) && IS_SEQUENCE(_13908)) {
        }
        else {
            Concat((object_ptr)&_add_public_24309, _add_public_24309, _13908);
        }
        _13908 = NOVALUE;
L8: 

        /** 			end for*/
        _i_24344 = _i_24344 + 1;
        goto L6; // [244] 197
L7: 
        ;
    }

    /** 			for i = 1 to length( file_include_by[add_public[px]] ) do*/
    _2 = (int)SEQ_PTR(_add_public_24309);
    _13910 = (int)*(((s1_ptr)_2)->base + _px_24327);
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    if (!IS_ATOM_INT(_13910)){
        _13911 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13910)->dbl));
    }
    else{
        _13911 = (int)*(((s1_ptr)_2)->base + _13910);
    }
    if (IS_SEQUENCE(_13911)){
            _13912 = SEQ_PTR(_13911)->length;
    }
    else {
        _13912 = 1;
    }
    _13911 = NOVALUE;
    {
        int _i_24362;
        _i_24362 = 1;
L9: 
        if (_i_24362 > _13912){
            goto LA; // [264] 327
        }

        /** 				include_matrix[file_include_by[add_public[px]]][included_file] =*/
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13913 = (int)*(((s1_ptr)_2)->base + _px_24327);
        _2 = (int)SEQ_PTR(_36file_include_by_14994);
        if (!IS_ATOM_INT(_13913)){
            _13914 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13913)->dbl));
        }
        else{
            _13914 = (int)*(((s1_ptr)_2)->base + _13913);
        }
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_14988 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_13914))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_13914)->dbl));
        else
        _3 = (int)(_13914 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_add_public_24309);
        _13917 = (int)*(((s1_ptr)_2)->base + _px_24327);
        _2 = (int)SEQ_PTR(_36file_include_by_14994);
        if (!IS_ATOM_INT(_13917)){
            _13918 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13917)->dbl));
        }
        else{
            _13918 = (int)*(((s1_ptr)_2)->base + _13917);
        }
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!IS_ATOM_INT(_13918)){
            _13919 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13918)->dbl));
        }
        else{
            _13919 = (int)*(((s1_ptr)_2)->base + _13918);
        }
        _2 = (int)SEQ_PTR(_13919);
        _13920 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
        _13919 = NOVALUE;
        if (IS_ATOM_INT(_13920)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13920;
                 _13921 = MAKE_UINT(tu);
            }
        }
        else {
            _13921 = binary_op(OR_BITS, 4, _13920);
        }
        _13920 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _included_file_24298);
        _1 = *(int *)_2;
        *(int *)_2 = _13921;
        if( _1 != _13921 ){
            DeRef(_1);
        }
        _13921 = NOVALUE;
        _13915 = NOVALUE;

        /** 			end for*/
        _i_24362 = _i_24362 + 1;
        goto L9; // [322] 271
LA: 
        ;
    }

    /** 			px += 1*/
    _px_24327 = _px_24327 + 1;

    /** 		end while*/
    goto L4; // [335] 131
L5: 
L1: 
    DeRef(_add_public_24309);
    _add_public_24309 = NOVALUE;

    /** 	if indirect_include[from_file][included_file] then*/
    _2 = (int)SEQ_PTR(_36indirect_include_14990);
    _13923 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    _2 = (int)SEQ_PTR(_13923);
    _13924 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
    _13923 = NOVALUE;
    if (_13924 == 0) {
        _13924 = NOVALUE;
        goto LB; // [353] 545
    }
    else {
        if (!IS_ATOM_INT(_13924) && DBL_PTR(_13924)->dbl == 0.0){
            _13924 = NOVALUE;
            goto LB; // [353] 545
        }
        _13924 = NOVALUE;
    }
    _13924 = NOVALUE;

    /** 		sequence indirect = file_include_by[from_file]*/
    DeRef(_indirect_24386);
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _indirect_24386 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    Ref(_indirect_24386);

    /** 		sequence mask = include_matrix[included_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13926 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
    DeRef(_mask_24389);
    if (IS_ATOM_INT(_13926)) {
        _mask_24389 = (_13926 != 0);
    }
    else {
        _mask_24389 = binary_op(NOTEQ, _13926, 0);
    }
    _13926 = NOVALUE;

    /** 		include_matrix[from_file] = or_bits( include_matrix[from_file], mask )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13928 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    _13929 = binary_op(OR_BITS, _13928, _mask_24389);
    _13928 = NOVALUE;
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _2 = (int)(((s1_ptr)_2)->base + _from_file_24299);
    _1 = *(int *)_2;
    *(int *)_2 = _13929;
    if( _1 != _13929 ){
        DeRef(_1);
    }
    _13929 = NOVALUE;

    /** 		mask = include_matrix[from_file] != 0*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13930 = (int)*(((s1_ptr)_2)->base + _from_file_24299);
    DeRefDS(_mask_24389);
    if (IS_ATOM_INT(_13930)) {
        _mask_24389 = (_13930 != 0);
    }
    else {
        _mask_24389 = binary_op(NOTEQ, _13930, 0);
    }
    _13930 = NOVALUE;

    /** 		integer ix = 1*/
    _ix_24400 = 1;

    /** 		while ix <= length(indirect) do*/
LC: 
    if (IS_SEQUENCE(_indirect_24386)){
            _13932 = SEQ_PTR(_indirect_24386)->length;
    }
    else {
        _13932 = 1;
    }
    if (_ix_24400 > _13932)
    goto LD; // [425] 544

    /** 			integer indirect_file = indirect[ix]*/
    _2 = (int)SEQ_PTR(_indirect_24386);
    _indirect_file_24404 = (int)*(((s1_ptr)_2)->base + _ix_24400);
    if (!IS_ATOM_INT(_indirect_file_24404))
    _indirect_file_24404 = (long)DBL_PTR(_indirect_file_24404)->dbl;

    /** 			if indirect_include[indirect_file][included_file] then*/
    _2 = (int)SEQ_PTR(_36indirect_include_14990);
    _13935 = (int)*(((s1_ptr)_2)->base + _indirect_file_24404);
    _2 = (int)SEQ_PTR(_13935);
    _13936 = (int)*(((s1_ptr)_2)->base + _included_file_24298);
    _13935 = NOVALUE;
    if (_13936 == 0) {
        _13936 = NOVALUE;
        goto LE; // [447] 531
    }
    else {
        if (!IS_ATOM_INT(_13936) && DBL_PTR(_13936)->dbl == 0.0){
            _13936 = NOVALUE;
            goto LE; // [447] 531
        }
        _13936 = NOVALUE;
    }
    _13936 = NOVALUE;

    /** 				include_matrix[indirect_file] =*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13937 = (int)*(((s1_ptr)_2)->base + _indirect_file_24404);
    _13938 = binary_op(OR_BITS, _mask_24389, _13937);
    _13937 = NOVALUE;
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _2 = (int)(((s1_ptr)_2)->base + _indirect_file_24404);
    _1 = *(int *)_2;
    *(int *)_2 = _13938;
    if( _1 != _13938 ){
        DeRef(_1);
    }
    _13938 = NOVALUE;

    /** 				for i = 1 to length( file_include_by[indirect_file] ) do*/
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _13939 = (int)*(((s1_ptr)_2)->base + _indirect_file_24404);
    if (IS_SEQUENCE(_13939)){
            _13940 = SEQ_PTR(_13939)->length;
    }
    else {
        _13940 = 1;
    }
    _13939 = NOVALUE;
    {
        int _i_24415;
        _i_24415 = 1;
LF: 
        if (_i_24415 > _13940){
            goto L10; // [479] 530
        }

        /** 					if not find( file_include_by[indirect_file][i], indirect ) then*/
        _2 = (int)SEQ_PTR(_36file_include_by_14994);
        _13941 = (int)*(((s1_ptr)_2)->base + _indirect_file_24404);
        _2 = (int)SEQ_PTR(_13941);
        _13942 = (int)*(((s1_ptr)_2)->base + _i_24415);
        _13941 = NOVALUE;
        _13943 = find_from(_13942, _indirect_24386, 1);
        _13942 = NOVALUE;
        if (_13943 != 0)
        goto L11; // [503] 523
        _13943 = NOVALUE;

        /** 						indirect &= file_include_by[indirect_file][i]*/
        _2 = (int)SEQ_PTR(_36file_include_by_14994);
        _13945 = (int)*(((s1_ptr)_2)->base + _indirect_file_24404);
        _2 = (int)SEQ_PTR(_13945);
        _13946 = (int)*(((s1_ptr)_2)->base + _i_24415);
        _13945 = NOVALUE;
        if (IS_SEQUENCE(_indirect_24386) && IS_ATOM(_13946)) {
            Ref(_13946);
            Append(&_indirect_24386, _indirect_24386, _13946);
        }
        else if (IS_ATOM(_indirect_24386) && IS_SEQUENCE(_13946)) {
        }
        else {
            Concat((object_ptr)&_indirect_24386, _indirect_24386, _13946);
        }
        _13946 = NOVALUE;
L11: 

        /** 				end for*/
        _i_24415 = _i_24415 + 1;
        goto LF; // [525] 486
L10: 
        ;
    }
LE: 

    /** 			ix += 1*/
    _ix_24400 = _ix_24400 + 1;

    /** 		end while*/
    goto LC; // [541] 422
LD: 
LB: 
    DeRef(_indirect_24386);
    _indirect_24386 = NOVALUE;
    DeRef(_mask_24389);
    _mask_24389 = NOVALUE;

    /** 	public_include = FALSE*/
    _61public_include_23549 = _13FALSE_435;

    /** end procedure*/
    _13879 = NOVALUE;
    _13891 = NOVALUE;
    _13882 = NOVALUE;
    _13898 = NOVALUE;
    _13894 = NOVALUE;
    _13899 = NOVALUE;
    _13901 = NOVALUE;
    _13906 = NOVALUE;
    _13910 = NOVALUE;
    _13911 = NOVALUE;
    _13913 = NOVALUE;
    _13914 = NOVALUE;
    _13939 = NOVALUE;
    _13917 = NOVALUE;
    _13918 = NOVALUE;
    return;
    ;
}


void _61add_include_by(int _by_file_24433, int _included_file_24434, int _is_public_24435)
{
    int _13993 = NOVALUE;
    int _13992 = NOVALUE;
    int _13991 = NOVALUE;
    int _13989 = NOVALUE;
    int _13988 = NOVALUE;
    int _13987 = NOVALUE;
    int _13986 = NOVALUE;
    int _13984 = NOVALUE;
    int _13983 = NOVALUE;
    int _13982 = NOVALUE;
    int _13981 = NOVALUE;
    int _13980 = NOVALUE;
    int _13979 = NOVALUE;
    int _13978 = NOVALUE;
    int _13977 = NOVALUE;
    int _13975 = NOVALUE;
    int _13974 = NOVALUE;
    int _13973 = NOVALUE;
    int _13972 = NOVALUE;
    int _13970 = NOVALUE;
    int _13969 = NOVALUE;
    int _13968 = NOVALUE;
    int _13967 = NOVALUE;
    int _13965 = NOVALUE;
    int _13964 = NOVALUE;
    int _13963 = NOVALUE;
    int _13962 = NOVALUE;
    int _13960 = NOVALUE;
    int _13959 = NOVALUE;
    int _13958 = NOVALUE;
    int _13957 = NOVALUE;
    int _13956 = NOVALUE;
    int _13954 = NOVALUE;
    int _13953 = NOVALUE;
    int _13952 = NOVALUE;
    int _13951 = NOVALUE;
    int _13949 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	include_matrix[by_file][included_file] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24433 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13951 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    _2 = (int)SEQ_PTR(_13951);
    _13952 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    _13951 = NOVALUE;
    if (IS_ATOM_INT(_13952)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_13952;
             _13953 = MAKE_UINT(tu);
        }
    }
    else {
        _13953 = binary_op(OR_BITS, 2, _13952);
    }
    _13952 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24434);
    _1 = *(int *)_2;
    *(int *)_2 = _13953;
    if( _1 != _13953 ){
        DeRef(_1);
    }
    _13953 = NOVALUE;
    _13949 = NOVALUE;

    /** 	if is_public then*/
    if (_is_public_24435 == 0)
    {
        goto L1; // [38] 71
    }
    else{
    }

    /** 		include_matrix[by_file][included_file] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][included_file] )*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    _3 = (int)(_by_file_24433 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13956 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    _2 = (int)SEQ_PTR(_13956);
    _13957 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    _13956 = NOVALUE;
    if (IS_ATOM_INT(_13957)) {
        {unsigned long tu;
             tu = (unsigned long)4 | (unsigned long)_13957;
             _13958 = MAKE_UINT(tu);
        }
    }
    else {
        _13958 = binary_op(OR_BITS, 4, _13957);
    }
    _13957 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24434);
    _1 = *(int *)_2;
    *(int *)_2 = _13958;
    if( _1 != _13958 ){
        DeRef(_1);
    }
    _13958 = NOVALUE;
    _13954 = NOVALUE;
L1: 

    /** 	if not find( by_file, file_include_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _13959 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    _13960 = find_from(_by_file_24433, _13959, 1);
    _13959 = NOVALUE;
    if (_13960 != 0)
    goto L2; // [84] 104
    _13960 = NOVALUE;

    /** 		file_include_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _13962 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    if (IS_SEQUENCE(_13962) && IS_ATOM(_by_file_24433)) {
        Append(&_13963, _13962, _by_file_24433);
    }
    else if (IS_ATOM(_13962) && IS_SEQUENCE(_by_file_24433)) {
    }
    else {
        Concat((object_ptr)&_13963, _13962, _by_file_24433);
        _13962 = NOVALUE;
    }
    _13962 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_by_14994);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24434);
    _1 = *(int *)_2;
    *(int *)_2 = _13963;
    if( _1 != _13963 ){
        DeRef(_1);
    }
    _13963 = NOVALUE;
L2: 

    /** 	if not find( included_file, file_include[by_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _13964 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    _13965 = find_from(_included_file_24434, _13964, 1);
    _13964 = NOVALUE;
    if (_13965 != 0)
    goto L3; // [117] 137
    _13965 = NOVALUE;

    /** 		file_include[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _13967 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    if (IS_SEQUENCE(_13967) && IS_ATOM(_included_file_24434)) {
        Append(&_13968, _13967, _included_file_24434);
    }
    else if (IS_ATOM(_13967) && IS_SEQUENCE(_included_file_24434)) {
    }
    else {
        Concat((object_ptr)&_13968, _13967, _included_file_24434);
        _13967 = NOVALUE;
    }
    _13967 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24433);
    _1 = *(int *)_2;
    *(int *)_2 = _13968;
    if( _1 != _13968 ){
        DeRef(_1);
    }
    _13968 = NOVALUE;
L3: 

    /** 	if is_public then*/
    if (_is_public_24435 == 0)
    {
        goto L4; // [139] 209
    }
    else{
    }

    /** 		if not find( by_file, file_public_by[included_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_by_14996);
    _13969 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    _13970 = find_from(_by_file_24433, _13969, 1);
    _13969 = NOVALUE;
    if (_13970 != 0)
    goto L5; // [155] 175
    _13970 = NOVALUE;

    /** 			file_public_by[included_file] &= by_file*/
    _2 = (int)SEQ_PTR(_36file_public_by_14996);
    _13972 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    if (IS_SEQUENCE(_13972) && IS_ATOM(_by_file_24433)) {
        Append(&_13973, _13972, _by_file_24433);
    }
    else if (IS_ATOM(_13972) && IS_SEQUENCE(_by_file_24433)) {
    }
    else {
        Concat((object_ptr)&_13973, _13972, _by_file_24433);
        _13972 = NOVALUE;
    }
    _13972 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_by_14996);
    _2 = (int)(((s1_ptr)_2)->base + _included_file_24434);
    _1 = *(int *)_2;
    *(int *)_2 = _13973;
    if( _1 != _13973 ){
        DeRef(_1);
    }
    _13973 = NOVALUE;
L5: 

    /** 		if not find( included_file, file_public[by_file] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _13974 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    _13975 = find_from(_included_file_24434, _13974, 1);
    _13974 = NOVALUE;
    if (_13975 != 0)
    goto L6; // [188] 208
    _13975 = NOVALUE;

    /** 			file_public[by_file] &= included_file*/
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _13977 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
    if (IS_SEQUENCE(_13977) && IS_ATOM(_included_file_24434)) {
        Append(&_13978, _13977, _included_file_24434);
    }
    else if (IS_ATOM(_13977) && IS_SEQUENCE(_included_file_24434)) {
    }
    else {
        Concat((object_ptr)&_13978, _13977, _included_file_24434);
        _13977 = NOVALUE;
    }
    _13977 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _2 = (int)(((s1_ptr)_2)->base + _by_file_24433);
    _1 = *(int *)_2;
    *(int *)_2 = _13978;
    if( _1 != _13978 ){
        DeRef(_1);
    }
    _13978 = NOVALUE;
L6: 
L4: 

    /** 	for propagate = 1 to length( include_matrix[included_file] ) do*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    _13979 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
    if (IS_SEQUENCE(_13979)){
            _13980 = SEQ_PTR(_13979)->length;
    }
    else {
        _13980 = 1;
    }
    _13979 = NOVALUE;
    {
        int _propagate_24487;
        _propagate_24487 = 1;
L7: 
        if (_propagate_24487 > _13980){
            goto L8; // [220] 320
        }

        /** 		if and_bits( PUBLIC_INCLUDE, include_matrix[included_file][propagate] ) then*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _13981 = (int)*(((s1_ptr)_2)->base + _included_file_24434);
        _2 = (int)SEQ_PTR(_13981);
        _13982 = (int)*(((s1_ptr)_2)->base + _propagate_24487);
        _13981 = NOVALUE;
        if (IS_ATOM_INT(_13982)) {
            {unsigned long tu;
                 tu = (unsigned long)4 & (unsigned long)_13982;
                 _13983 = MAKE_UINT(tu);
            }
        }
        else {
            _13983 = binary_op(AND_BITS, 4, _13982);
        }
        _13982 = NOVALUE;
        if (_13983 == 0) {
            DeRef(_13983);
            _13983 = NOVALUE;
            goto L9; // [245] 313
        }
        else {
            if (!IS_ATOM_INT(_13983) && DBL_PTR(_13983)->dbl == 0.0){
                DeRef(_13983);
                _13983 = NOVALUE;
                goto L9; // [245] 313
            }
            DeRef(_13983);
            _13983 = NOVALUE;
        }
        DeRef(_13983);
        _13983 = NOVALUE;

        /** 			include_matrix[by_file][propagate] = or_bits( DIRECT_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_14988 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24433 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _13986 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
        _2 = (int)SEQ_PTR(_13986);
        _13987 = (int)*(((s1_ptr)_2)->base + _propagate_24487);
        _13986 = NOVALUE;
        if (IS_ATOM_INT(_13987)) {
            {unsigned long tu;
                 tu = (unsigned long)2 | (unsigned long)_13987;
                 _13988 = MAKE_UINT(tu);
            }
        }
        else {
            _13988 = binary_op(OR_BITS, 2, _13987);
        }
        _13987 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24487);
        _1 = *(int *)_2;
        *(int *)_2 = _13988;
        if( _1 != _13988 ){
            DeRef(_1);
        }
        _13988 = NOVALUE;
        _13984 = NOVALUE;

        /** 			if is_public then*/
        if (_is_public_24435 == 0)
        {
            goto LA; // [279] 312
        }
        else{
        }

        /** 				include_matrix[by_file][propagate] = or_bits( PUBLIC_INCLUDE, include_matrix[by_file][propagate] )*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36include_matrix_14988 = MAKE_SEQ(_2);
        }
        _3 = (int)(_by_file_24433 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _13991 = (int)*(((s1_ptr)_2)->base + _by_file_24433);
        _2 = (int)SEQ_PTR(_13991);
        _13992 = (int)*(((s1_ptr)_2)->base + _propagate_24487);
        _13991 = NOVALUE;
        if (IS_ATOM_INT(_13992)) {
            {unsigned long tu;
                 tu = (unsigned long)4 | (unsigned long)_13992;
                 _13993 = MAKE_UINT(tu);
            }
        }
        else {
            _13993 = binary_op(OR_BITS, 4, _13992);
        }
        _13992 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _propagate_24487);
        _1 = *(int *)_2;
        *(int *)_2 = _13993;
        if( _1 != _13993 ){
            DeRef(_1);
        }
        _13993 = NOVALUE;
        _13989 = NOVALUE;
LA: 
L9: 

        /** 	end for*/
        _propagate_24487 = _propagate_24487 + 1;
        goto L7; // [315] 227
L8: 
        ;
    }

    /** end procedure*/
    _13979 = NOVALUE;
    return;
    ;
}


void _61IncludePush()
{
    int _new_file_handle_24516 = NOVALUE;
    int _old_file_no_24517 = NOVALUE;
    int _new_hash_24518 = NOVALUE;
    int _idx_24519 = NOVALUE;
    int _14080 = NOVALUE;
    int _14077 = NOVALUE;
    int _14075 = NOVALUE;
    int _14074 = NOVALUE;
    int _14073 = NOVALUE;
    int _14071 = NOVALUE;
    int _14070 = NOVALUE;
    int _14064 = NOVALUE;
    int _14063 = NOVALUE;
    int _14062 = NOVALUE;
    int _14061 = NOVALUE;
    int _14060 = NOVALUE;
    int _14059 = NOVALUE;
    int _14058 = NOVALUE;
    int _14055 = NOVALUE;
    int _14053 = NOVALUE;
    int _14051 = NOVALUE;
    int _14050 = NOVALUE;
    int _14049 = NOVALUE;
    int _14047 = NOVALUE;
    int _14046 = NOVALUE;
    int _14044 = NOVALUE;
    int _14043 = NOVALUE;
    int _14041 = NOVALUE;
    int _14040 = NOVALUE;
    int _14039 = NOVALUE;
    int _14038 = NOVALUE;
    int _14037 = NOVALUE;
    int _14036 = NOVALUE;
    int _14035 = NOVALUE;
    int _14031 = NOVALUE;
    int _14029 = NOVALUE;
    int _14028 = NOVALUE;
    int _14027 = NOVALUE;
    int _14026 = NOVALUE;
    int _14025 = NOVALUE;
    int _14024 = NOVALUE;
    int _14023 = NOVALUE;
    int _14022 = NOVALUE;
    int _14021 = NOVALUE;
    int _14019 = NOVALUE;
    int _14018 = NOVALUE;
    int _14017 = NOVALUE;
    int _14015 = NOVALUE;
    int _14014 = NOVALUE;
    int _14013 = NOVALUE;
    int _14012 = NOVALUE;
    int _14010 = NOVALUE;
    int _14009 = NOVALUE;
    int _14008 = NOVALUE;
    int _14007 = NOVALUE;
    int _14006 = NOVALUE;
    int _14004 = NOVALUE;
    int _14003 = NOVALUE;
    int _14002 = NOVALUE;
    int _14001 = NOVALUE;
    int _13999 = NOVALUE;
    int _13995 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	start_include = FALSE*/
    _61start_include_23546 = _13FALSE_435;

    /** 	new_file_handle = path_open() -- sets new_include_name to full path*/
    _new_file_handle_24516 = _61path_open();
    if (!IS_ATOM_INT(_new_file_handle_24516)) {
        _1 = (long)(DBL_PTR(_new_file_handle_24516)->dbl);
        DeRefDS(_new_file_handle_24516);
        _new_file_handle_24516 = _1;
    }

    /** 	new_hash = hash(canonical_path(new_include_name,,CORRECT), stdhash:HSIEH32)*/
    RefDS(_35new_include_name_16090);
    _13995 = _17canonical_path(_35new_include_name_16090, 0, 2);
    DeRef(_new_hash_24518);
    _new_hash_24518 = calc_hash(_13995, -5);
    DeRef(_13995);
    _13995 = NOVALUE;

    /** 	idx = find(new_hash, known_files_hash)*/
    _idx_24519 = find_from(_new_hash_24518, _36known_files_hash_14983, 1);

    /** 	if idx then*/
    if (_idx_24519 == 0)
    {
        goto L1; // [42] 335
    }
    else{
    }

    /** 		if new_include_space != 0 then*/
    if (_61new_include_space_23544 == 0)
    goto L2; // [49] 71

    /** 			SymTab[new_include_space][S_OBJ] = idx -- but note any namespace*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_61new_include_space_23544 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24519;
    DeRef(_1);
    _13999 = NOVALUE;
L2: 

    /** 		close(new_file_handle)*/
    EClose(_new_file_handle_24516);

    /** 		if find( -idx, file_include[current_file_no] ) then*/
    if ((unsigned long)_idx_24519 == 0xC0000000)
    _14001 = (int)NewDouble((double)-0xC0000000);
    else
    _14001 = - _idx_24519;
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _14002 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _14003 = find_from(_14001, _14002, 1);
    DeRef(_14001);
    _14001 = NOVALUE;
    _14002 = NOVALUE;
    if (_14003 == 0)
    {
        _14003 = NOVALUE;
        goto L3; // [93] 130
    }
    else{
        _14003 = NOVALUE;
    }

    /** 			file_include[current_file_no][ find( -idx, file_include[current_file_no] ) ] = idx*/
    _2 = (int)SEQ_PTR(_36file_include_14986);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_14986 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_15968 + ((s1_ptr)_2)->base);
    if ((unsigned long)_idx_24519 == 0xC0000000)
    _14006 = (int)NewDouble((double)-0xC0000000);
    else
    _14006 = - _idx_24519;
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _14007 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _14008 = find_from(_14006, _14007, 1);
    DeRef(_14006);
    _14006 = NOVALUE;
    _14007 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14008);
    _1 = *(int *)_2;
    *(int *)_2 = _idx_24519;
    DeRef(_1);
    _14004 = NOVALUE;
    goto L4; // [127] 228
L3: 

    /** 		elsif not find( idx, file_include[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _14009 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _14010 = find_from(_idx_24519, _14009, 1);
    _14009 = NOVALUE;
    if (_14010 != 0)
    goto L5; // [145] 227
    _14010 = NOVALUE;

    /** 			file_include[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _14012 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14012) && IS_ATOM(_idx_24519)) {
        Append(&_14013, _14012, _idx_24519);
    }
    else if (IS_ATOM(_14012) && IS_SEQUENCE(_idx_24519)) {
    }
    else {
        Concat((object_ptr)&_14013, _14012, _idx_24519);
        _14012 = NOVALUE;
    }
    _14012 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14013;
    if( _1 != _14013 ){
        DeRef(_1);
    }
    _14013 = NOVALUE;

    /** 			add_exports( idx, current_file_no )*/
    _61add_exports(_idx_24519, _35current_file_no_15968);

    /** 			if public_include then*/
    if (_61public_include_23549 == 0)
    {
        goto L6; // [178] 226
    }
    else{
    }

    /** 				if not find( idx, file_public[current_file_no] ) then*/
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _14014 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _14015 = find_from(_idx_24519, _14014, 1);
    _14014 = NOVALUE;
    if (_14015 != 0)
    goto L7; // [196] 225
    _14015 = NOVALUE;

    /** 					file_public[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _14017 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14017) && IS_ATOM(_idx_24519)) {
        Append(&_14018, _14017, _idx_24519);
    }
    else if (IS_ATOM(_14017) && IS_SEQUENCE(_idx_24519)) {
    }
    else {
        Concat((object_ptr)&_14018, _14017, _idx_24519);
        _14017 = NOVALUE;
    }
    _14017 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14018;
    if( _1 != _14018 ){
        DeRef(_1);
    }
    _14018 = NOVALUE;

    /** 					patch_exports( current_file_no )*/
    _61patch_exports(_35current_file_no_15968);
L7: 
L6: 
L5: 
L4: 

    /** 		indirect_include[current_file_no][idx] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_36indirect_include_14990);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36indirect_include_14990 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_15968 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _idx_24519);
    _1 = *(int *)_2;
    *(int *)_2 = _35OpIndirectInclude_16043;
    DeRef(_1);
    _14019 = NOVALUE;

    /** 		add_include_by( current_file_no, idx, public_include )*/
    _61add_include_by(_35current_file_no_15968, _idx_24519, _61public_include_23549);

    /** 		update_include_matrix( idx, current_file_no )*/
    _61update_include_matrix(_idx_24519, _35current_file_no_15968);

    /** 		public_include = FALSE*/
    _61public_include_23549 = _13FALSE_435;

    /** 		read_line() -- we can't return without reading a line first*/
    _61read_line();

    /** 		if not find( idx, file_include_depend[current_file_no] ) and not finished_files[idx] then*/
    _2 = (int)SEQ_PTR(_36file_include_depend_14985);
    _14021 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    _14022 = find_from(_idx_24519, _14021, 1);
    _14021 = NOVALUE;
    _14023 = (_14022 == 0);
    _14022 = NOVALUE;
    if (_14023 == 0) {
        goto L8; // [293] 329
    }
    _2 = (int)SEQ_PTR(_36finished_files_14984);
    _14025 = (int)*(((s1_ptr)_2)->base + _idx_24519);
    _14026 = (_14025 == 0);
    _14025 = NOVALUE;
    if (_14026 == 0)
    {
        DeRef(_14026);
        _14026 = NOVALUE;
        goto L8; // [307] 329
    }
    else{
        DeRef(_14026);
        _14026 = NOVALUE;
    }

    /** 			file_include_depend[current_file_no] &= idx*/
    _2 = (int)SEQ_PTR(_36file_include_depend_14985);
    _14027 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14027) && IS_ATOM(_idx_24519)) {
        Append(&_14028, _14027, _idx_24519);
    }
    else if (IS_ATOM(_14027) && IS_SEQUENCE(_idx_24519)) {
    }
    else {
        Concat((object_ptr)&_14028, _14027, _idx_24519);
        _14027 = NOVALUE;
    }
    _14027 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_depend_14985);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_depend_14985 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14028;
    if( _1 != _14028 ){
        DeRef(_1);
    }
    _14028 = NOVALUE;
L8: 

    /** 		return -- ignore it*/
    DeRef(_new_hash_24518);
    DeRef(_14023);
    _14023 = NOVALUE;
    return;
L1: 

    /** 	if length(IncludeStk) >= INCLUDE_LIMIT then*/
    if (IS_SEQUENCE(_61IncludeStk_23555)){
            _14029 = SEQ_PTR(_61IncludeStk_23555)->length;
    }
    else {
        _14029 = 1;
    }
    if (_14029 < 30)
    goto L9; // [342] 354

    /** 		CompileErr(104)*/
    RefDS(_21815);
    _44CompileErr(104, _21815, 0);
L9: 

    /** 	IncludeStk = append(IncludeStk,*/
    _1 = NewS1(22);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _35current_file_no_15968;
    *((int *)(_2+8)) = _35line_number_15969;
    *((int *)(_2+12)) = _35src_file_16089;
    *((int *)(_2+16)) = _35file_start_sym_15974;
    *((int *)(_2+20)) = _35OpWarning_16035;
    *((int *)(_2+24)) = _35OpTrace_16037;
    *((int *)(_2+28)) = _35OpTypeCheck_16038;
    *((int *)(_2+32)) = _35OpProfileTime_16040;
    *((int *)(_2+36)) = _35OpProfileStatement_16039;
    RefDS(_35OpDefines_16041);
    *((int *)(_2+40)) = _35OpDefines_16041;
    *((int *)(_2+44)) = _35prev_OpWarning_16036;
    *((int *)(_2+48)) = _35OpInline_16042;
    *((int *)(_2+52)) = _35OpIndirectInclude_16043;
    *((int *)(_2+56)) = _35putback_fwd_line_number_15971;
    Ref(_44putback_ForwardLine_48144);
    *((int *)(_2+60)) = _44putback_ForwardLine_48144;
    *((int *)(_2+64)) = _44putback_forward_bp_48148;
    *((int *)(_2+68)) = _35last_fwd_line_number_15972;
    Ref(_44last_ForwardLine_48145);
    *((int *)(_2+72)) = _44last_ForwardLine_48145;
    *((int *)(_2+76)) = _44last_forward_bp_48149;
    Ref(_44ThisLine_48142);
    *((int *)(_2+80)) = _44ThisLine_48142;
    *((int *)(_2+84)) = _35fwd_line_number_15970;
    *((int *)(_2+88)) = _44forward_bp_48147;
    _14031 = MAKE_SEQ(_1);
    RefDS(_14031);
    Append(&_61IncludeStk_23555, _61IncludeStk_23555, _14031);
    DeRefDS(_14031);
    _14031 = NOVALUE;

    /** 	file_include = append( file_include, {} )*/
    RefDS(_5);
    Append(&_36file_include_14986, _36file_include_14986, _5);

    /** 	file_include_by = append( file_include_by, {} )*/
    RefDS(_5);
    Append(&_36file_include_by_14994, _36file_include_by_14994, _5);

    /** 	for i = 1 to length( include_matrix) do*/
    if (IS_SEQUENCE(_36include_matrix_14988)){
            _14035 = SEQ_PTR(_36include_matrix_14988)->length;
    }
    else {
        _14035 = 1;
    }
    {
        int _i_24631;
        _i_24631 = 1;
LA: 
        if (_i_24631 > _14035){
            goto LB; // [458] 504
        }

        /** 		include_matrix[i]   &= 0*/
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _14036 = (int)*(((s1_ptr)_2)->base + _i_24631);
        if (IS_SEQUENCE(_14036) && IS_ATOM(0)) {
            Append(&_14037, _14036, 0);
        }
        else if (IS_ATOM(_14036) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14037, _14036, 0);
            _14036 = NOVALUE;
        }
        _14036 = NOVALUE;
        _2 = (int)SEQ_PTR(_36include_matrix_14988);
        _2 = (int)(((s1_ptr)_2)->base + _i_24631);
        _1 = *(int *)_2;
        *(int *)_2 = _14037;
        if( _1 != _14037 ){
            DeRef(_1);
        }
        _14037 = NOVALUE;

        /** 		indirect_include[i] &= 0*/
        _2 = (int)SEQ_PTR(_36indirect_include_14990);
        _14038 = (int)*(((s1_ptr)_2)->base + _i_24631);
        if (IS_SEQUENCE(_14038) && IS_ATOM(0)) {
            Append(&_14039, _14038, 0);
        }
        else if (IS_ATOM(_14038) && IS_SEQUENCE(0)) {
        }
        else {
            Concat((object_ptr)&_14039, _14038, 0);
            _14038 = NOVALUE;
        }
        _14038 = NOVALUE;
        _2 = (int)SEQ_PTR(_36indirect_include_14990);
        _2 = (int)(((s1_ptr)_2)->base + _i_24631);
        _1 = *(int *)_2;
        *(int *)_2 = _14039;
        if( _1 != _14039 ){
            DeRef(_1);
        }
        _14039 = NOVALUE;

        /** 	end for*/
        _i_24631 = _i_24631 + 1;
        goto LA; // [499] 465
LB: 
        ;
    }

    /** 	include_matrix = append( include_matrix, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _14040 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _14040 = 1;
    }
    _14041 = Repeat(0, _14040);
    _14040 = NOVALUE;
    RefDS(_14041);
    Append(&_36include_matrix_14988, _36include_matrix_14988, _14041);
    DeRefDS(_14041);
    _14041 = NOVALUE;

    /** 	include_matrix[$][$] = DIRECT_INCLUDE*/
    if (IS_SEQUENCE(_36include_matrix_14988)){
            _14043 = SEQ_PTR(_36include_matrix_14988)->length;
    }
    else {
        _14043 = 1;
    }
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    _3 = (int)(_14043 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14046 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14046 = 1;
    }
    _14044 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14046);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14044 = NOVALUE;

    /** 	include_matrix[current_file_no][$] = DIRECT_INCLUDE*/
    _2 = (int)SEQ_PTR(_36include_matrix_14988);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36include_matrix_14988 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_15968 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14049 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14049 = 1;
    }
    _14047 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14049);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _14047 = NOVALUE;

    /** 	indirect_include = append( indirect_include, repeat( 0, length( file_include ) ) )*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _14050 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _14050 = 1;
    }
    _14051 = Repeat(0, _14050);
    _14050 = NOVALUE;
    RefDS(_14051);
    Append(&_36indirect_include_14990, _36indirect_include_14990, _14051);
    DeRefDS(_14051);
    _14051 = NOVALUE;

    /** 	indirect_include[current_file_no][$] = OpIndirectInclude*/
    _2 = (int)SEQ_PTR(_36indirect_include_14990);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36indirect_include_14990 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35current_file_no_15968 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(*(object_ptr)_3)){
            _14055 = SEQ_PTR(*(object_ptr)_3)->length;
    }
    else {
        _14055 = 1;
    }
    _14053 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _14055);
    _1 = *(int *)_2;
    *(int *)_2 = _35OpIndirectInclude_16043;
    DeRef(_1);
    _14053 = NOVALUE;

    /** 	OpIndirectInclude = 1*/
    _35OpIndirectInclude_16043 = 1;

    /** 	file_public  = append( file_public, {} )*/
    RefDS(_5);
    Append(&_36file_public_14992, _36file_public_14992, _5);

    /** 	file_public_by = append( file_public_by, {} )*/
    RefDS(_5);
    Append(&_36file_public_by_14996, _36file_public_by_14996, _5);

    /** 	file_include[current_file_no] &= length( file_include )*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _14058 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _14058 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _14059 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14059) && IS_ATOM(_14058)) {
        Append(&_14060, _14059, _14058);
    }
    else if (IS_ATOM(_14059) && IS_SEQUENCE(_14058)) {
    }
    else {
        Concat((object_ptr)&_14060, _14059, _14058);
        _14059 = NOVALUE;
    }
    _14059 = NOVALUE;
    _14058 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_14986);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14060;
    if( _1 != _14060 ){
        DeRef(_1);
    }
    _14060 = NOVALUE;

    /** 	add_include_by( current_file_no, length(file_include), public_include )*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _14061 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _14061 = 1;
    }
    _61add_include_by(_35current_file_no_15968, _14061, _61public_include_23549);
    _14061 = NOVALUE;

    /** 	if public_include then*/
    if (_61public_include_23549 == 0)
    {
        goto LC; // [673] 707
    }
    else{
    }

    /** 		file_public[current_file_no] &= length( file_public )*/
    if (IS_SEQUENCE(_36file_public_14992)){
            _14062 = SEQ_PTR(_36file_public_14992)->length;
    }
    else {
        _14062 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _14063 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14063) && IS_ATOM(_14062)) {
        Append(&_14064, _14063, _14062);
    }
    else if (IS_ATOM(_14063) && IS_SEQUENCE(_14062)) {
    }
    else {
        Concat((object_ptr)&_14064, _14063, _14062);
        _14063 = NOVALUE;
    }
    _14063 = NOVALUE;
    _14062 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_public_14992);
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14064;
    if( _1 != _14064 ){
        DeRef(_1);
    }
    _14064 = NOVALUE;

    /** 		patch_exports( current_file_no )*/
    _61patch_exports(_35current_file_no_15968);
LC: 

    /** ifdef STDDEBUG then*/

    /** 	src_file = new_file_handle*/
    _35src_file_16089 = _new_file_handle_24516;

    /** 	file_start_sym = last_sym*/
    _35file_start_sym_15974 = _53last_sym_45724;

    /** 	if current_file_no >= MAX_FILE then*/
    if (_35current_file_no_15968 < 256)
    goto LD; // [729] 741

    /** 		CompileErr(126)*/
    RefDS(_21815);
    _44CompileErr(126, _21815, 0);
LD: 

    /** 	known_files = append(known_files, new_include_name)*/
    RefDS(_35new_include_name_16090);
    Append(&_36known_files_14982, _36known_files_14982, _35new_include_name_16090);

    /** 	known_files_hash &= new_hash*/
    Ref(_new_hash_24518);
    Append(&_36known_files_hash_14983, _36known_files_hash_14983, _new_hash_24518);

    /** 	finished_files &= 0*/
    Append(&_36finished_files_14984, _36finished_files_14984, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _14070 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _14070 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14070;
    _14071 = MAKE_SEQ(_1);
    _14070 = NOVALUE;
    RefDS(_14071);
    Append(&_36file_include_depend_14985, _36file_include_depend_14985, _14071);
    DeRefDS(_14071);
    _14071 = NOVALUE;

    /** 	file_include_depend[current_file_no] &= length( known_files )*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _14073 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _14073 = 1;
    }
    _2 = (int)SEQ_PTR(_36file_include_depend_14985);
    _14074 = (int)*(((s1_ptr)_2)->base + _35current_file_no_15968);
    if (IS_SEQUENCE(_14074) && IS_ATOM(_14073)) {
        Append(&_14075, _14074, _14073);
    }
    else if (IS_ATOM(_14074) && IS_SEQUENCE(_14073)) {
    }
    else {
        Concat((object_ptr)&_14075, _14074, _14073);
        _14074 = NOVALUE;
    }
    _14074 = NOVALUE;
    _14073 = NOVALUE;
    _2 = (int)SEQ_PTR(_36file_include_depend_14985);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36file_include_depend_14985 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _35current_file_no_15968);
    _1 = *(int *)_2;
    *(int *)_2 = _14075;
    if( _1 != _14075 ){
        DeRef(_1);
    }
    _14075 = NOVALUE;

    /** 	check_coverage()*/
    _50check_coverage();

    /** 	default_namespaces &= 0*/
    Append(&_61default_namespaces_23552, _61default_namespaces_23552, 0);

    /** 	update_include_matrix( length( file_include ), current_file_no )*/
    if (IS_SEQUENCE(_36file_include_14986)){
            _14077 = SEQ_PTR(_36file_include_14986)->length;
    }
    else {
        _14077 = 1;
    }
    _61update_include_matrix(_14077, _35current_file_no_15968);
    _14077 = NOVALUE;

    /** 	old_file_no = current_file_no*/
    _old_file_no_24517 = _35current_file_no_15968;

    /** 	current_file_no = length(known_files)*/
    if (IS_SEQUENCE(_36known_files_14982)){
            _35current_file_no_15968 = SEQ_PTR(_36known_files_14982)->length;
    }
    else {
        _35current_file_no_15968 = 1;
    }

    /** 	line_number = 0*/
    _35line_number_15969 = 0;

    /** 	read_line()*/
    _61read_line();

    /** 	if new_include_space != 0 then*/
    if (_61new_include_space_23544 == 0)
    goto LE; // [873] 897

    /** 		SymTab[new_include_space][S_OBJ] = current_file_no*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_61new_include_space_23544 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _35current_file_no_15968;
    DeRef(_1);
    _14080 = NOVALUE;
LE: 

    /** 	default_namespace( )*/
    _61default_namespace();

    /** end procedure*/
    DeRef(_new_hash_24518);
    DeRef(_14023);
    _14023 = NOVALUE;
    return;
    ;
}


void _61update_include_completion(int _file_no_24741)
{
    int _fx_24750 = NOVALUE;
    int _14090 = NOVALUE;
    int _14089 = NOVALUE;
    int _14088 = NOVALUE;
    int _14087 = NOVALUE;
    int _14085 = NOVALUE;
    int _14084 = NOVALUE;
    int _14083 = NOVALUE;
    int _14082 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( file_include_depend ) do*/
    if (IS_SEQUENCE(_36file_include_depend_14985)){
            _14082 = SEQ_PTR(_36file_include_depend_14985)->length;
    }
    else {
        _14082 = 1;
    }
    {
        int _i_24743;
        _i_24743 = 1;
L1: 
        if (_i_24743 > _14082){
            goto L2; // [10] 114
        }

        /** 		if length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_depend_14985);
        _14083 = (int)*(((s1_ptr)_2)->base + _i_24743);
        if (IS_SEQUENCE(_14083)){
                _14084 = SEQ_PTR(_14083)->length;
        }
        else {
            _14084 = 1;
        }
        _14083 = NOVALUE;
        if (_14084 == 0)
        {
            _14084 = NOVALUE;
            goto L3; // [28] 105
        }
        else{
            _14084 = NOVALUE;
        }

        /** 			integer fx = find( file_no, file_include_depend[i] )*/
        _2 = (int)SEQ_PTR(_36file_include_depend_14985);
        _14085 = (int)*(((s1_ptr)_2)->base + _i_24743);
        _fx_24750 = find_from(_file_no_24741, _14085, 1);
        _14085 = NOVALUE;

        /** 			if fx then*/
        if (_fx_24750 == 0)
        {
            goto L4; // [46] 104
        }
        else{
        }

        /** 				file_include_depend[i] = remove( file_include_depend[i], fx )*/
        _2 = (int)SEQ_PTR(_36file_include_depend_14985);
        _14087 = (int)*(((s1_ptr)_2)->base + _i_24743);
        {
            s1_ptr assign_space = SEQ_PTR(_14087);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_24750)) ? _fx_24750 : (long)(DBL_PTR(_fx_24750)->dbl);
            int stop = (IS_ATOM_INT(_fx_24750)) ? _fx_24750 : (long)(DBL_PTR(_fx_24750)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_14087);
                DeRef(_14088);
                _14088 = _14087;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_14087), start, &_14088 );
                }
                else Tail(SEQ_PTR(_14087), stop+1, &_14088);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_14087), start, &_14088);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_14088);
                _14088 = _1;
            }
        }
        _14087 = NOVALUE;
        _2 = (int)SEQ_PTR(_36file_include_depend_14985);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36file_include_depend_14985 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_24743);
        _1 = *(int *)_2;
        *(int *)_2 = _14088;
        if( _1 != _14088 ){
            DeRef(_1);
        }
        _14088 = NOVALUE;

        /** 				if not length( file_include_depend[i] ) then*/
        _2 = (int)SEQ_PTR(_36file_include_depend_14985);
        _14089 = (int)*(((s1_ptr)_2)->base + _i_24743);
        if (IS_SEQUENCE(_14089)){
                _14090 = SEQ_PTR(_14089)->length;
        }
        else {
            _14090 = 1;
        }
        _14089 = NOVALUE;
        if (_14090 != 0)
        goto L5; // [79] 103
        _14090 = NOVALUE;

        /** 					finished_files[i] = 1*/
        _2 = (int)SEQ_PTR(_36finished_files_14984);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _36finished_files_14984 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_24743);
        *(int *)_2 = 1;

        /** 					if i != file_no then*/
        if (_i_24743 == _file_no_24741)
        goto L6; // [92] 102

        /** 						update_include_completion( i )*/
        _61update_include_completion(_i_24743);
L6: 
L5: 
L4: 
L3: 

        /** 	end for*/
        _i_24743 = _i_24743 + 1;
        goto L1; // [109] 17
L2: 
        ;
    }

    /** end procedure*/
    _14083 = NOVALUE;
    _14089 = NOVALUE;
    return;
    ;
}


int _61IncludePop()
{
    int _top_24781 = NOVALUE;
    int _14121 = NOVALUE;
    int _14119 = NOVALUE;
    int _14118 = NOVALUE;
    int _14096 = NOVALUE;
    int _14094 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	update_include_completion( current_file_no )*/
    _61update_include_completion(_35current_file_no_15968);

    /** 	Resolve_forward_references()*/
    _38Resolve_forward_references(0);

    /** 	HideLocals()*/
    _53HideLocals();

    /** 	if src_file >= 0 then*/
    if (_35src_file_16089 < 0)
    goto L1; // [21] 39

    /** 		close(src_file)*/
    EClose(_35src_file_16089);

    /** 		src_file = -1*/
    _35src_file_16089 = -1;
L1: 

    /** 	if length(IncludeStk) = 0 then*/
    if (IS_SEQUENCE(_61IncludeStk_23555)){
            _14094 = SEQ_PTR(_61IncludeStk_23555)->length;
    }
    else {
        _14094 = 1;
    }
    if (_14094 != 0)
    goto L2; // [46] 59

    /** 		return FALSE  -- the end*/
    DeRef(_top_24781);
    return _13FALSE_435;
L2: 

    /** 	sequence top = IncludeStk[$]*/
    if (IS_SEQUENCE(_61IncludeStk_23555)){
            _14096 = SEQ_PTR(_61IncludeStk_23555)->length;
    }
    else {
        _14096 = 1;
    }
    DeRef(_top_24781);
    _2 = (int)SEQ_PTR(_61IncludeStk_23555);
    _top_24781 = (int)*(((s1_ptr)_2)->base + _14096);
    RefDS(_top_24781);

    /** 	current_file_no    = top[FILE_NO]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35current_file_no_15968 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_35current_file_no_15968)){
        _35current_file_no_15968 = (long)DBL_PTR(_35current_file_no_15968)->dbl;
    }

    /** 	line_number        = top[LINE_NO]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35line_number_15969 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_35line_number_15969)){
        _35line_number_15969 = (long)DBL_PTR(_35line_number_15969)->dbl;
    }

    /** 	src_file           = top[FILE_PTR]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35src_file_16089 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_35src_file_16089)){
        _35src_file_16089 = (long)DBL_PTR(_35src_file_16089)->dbl;
    }

    /** 	file_start_sym     = top[FILE_START_SYM]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35file_start_sym_15974 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_35file_start_sym_15974)){
        _35file_start_sym_15974 = (long)DBL_PTR(_35file_start_sym_15974)->dbl;
    }

    /** 	OpWarning          = top[OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpWarning_16035 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_35OpWarning_16035)){
        _35OpWarning_16035 = (long)DBL_PTR(_35OpWarning_16035)->dbl;
    }

    /** 	OpTrace            = top[OP_TRACE]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpTrace_16037 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_35OpTrace_16037)){
        _35OpTrace_16037 = (long)DBL_PTR(_35OpTrace_16037)->dbl;
    }

    /** 	OpTypeCheck        = top[OP_TYPE_CHECK]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpTypeCheck_16038 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_35OpTypeCheck_16038)){
        _35OpTypeCheck_16038 = (long)DBL_PTR(_35OpTypeCheck_16038)->dbl;
    }

    /** 	OpProfileTime      = top[OP_PROFILE_TIME]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpProfileTime_16040 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_35OpProfileTime_16040)){
        _35OpProfileTime_16040 = (long)DBL_PTR(_35OpProfileTime_16040)->dbl;
    }

    /** 	OpProfileStatement = top[OP_PROFILE_STATEMENT]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpProfileStatement_16039 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_35OpProfileStatement_16039)){
        _35OpProfileStatement_16039 = (long)DBL_PTR(_35OpProfileStatement_16039)->dbl;
    }

    /** 	OpDefines          = top[OP_DEFINES]*/
    DeRef(_35OpDefines_16041);
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpDefines_16041 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_35OpDefines_16041);

    /** 	prev_OpWarning     = top[PREV_OP_WARNING]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35prev_OpWarning_16036 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_35prev_OpWarning_16036)){
        _35prev_OpWarning_16036 = (long)DBL_PTR(_35prev_OpWarning_16036)->dbl;
    }

    /** 	OpInline           = top[OP_INLINE]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpInline_16042 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_35OpInline_16042)){
        _35OpInline_16042 = (long)DBL_PTR(_35OpInline_16042)->dbl;
    }

    /** 	OpIndirectInclude  = top[OP_INDIRECT_INCLUDE]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35OpIndirectInclude_16043 = (int)*(((s1_ptr)_2)->base + 13);
    if (!IS_ATOM_INT(_35OpIndirectInclude_16043)){
        _35OpIndirectInclude_16043 = (long)DBL_PTR(_35OpIndirectInclude_16043)->dbl;
    }

    /** 	putback_fwd_line_number = line_number -- top[PUTBACK_FWD_LINE_NUMBER]*/
    _35putback_fwd_line_number_15971 = _35line_number_15969;

    /** 	putback_ForwardLine = top[PUTBACK_FORWARDLINE]*/
    DeRef(_44putback_ForwardLine_48144);
    _2 = (int)SEQ_PTR(_top_24781);
    _44putback_ForwardLine_48144 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_44putback_ForwardLine_48144);

    /** 	putback_forward_bp = top[PUTBACK_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _44putback_forward_bp_48148 = (int)*(((s1_ptr)_2)->base + 16);
    if (!IS_ATOM_INT(_44putback_forward_bp_48148)){
        _44putback_forward_bp_48148 = (long)DBL_PTR(_44putback_forward_bp_48148)->dbl;
    }

    /** 	last_fwd_line_number = top[LAST_FWD_LINE_NUMBER]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _35last_fwd_line_number_15972 = (int)*(((s1_ptr)_2)->base + 17);
    if (!IS_ATOM_INT(_35last_fwd_line_number_15972)){
        _35last_fwd_line_number_15972 = (long)DBL_PTR(_35last_fwd_line_number_15972)->dbl;
    }

    /** 	last_ForwardLine = top[LAST_FORWARDLINE]*/
    DeRef(_44last_ForwardLine_48145);
    _2 = (int)SEQ_PTR(_top_24781);
    _44last_ForwardLine_48145 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_44last_ForwardLine_48145);

    /** 	last_forward_bp = top[LAST_FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _44last_forward_bp_48149 = (int)*(((s1_ptr)_2)->base + 19);
    if (!IS_ATOM_INT(_44last_forward_bp_48149)){
        _44last_forward_bp_48149 = (long)DBL_PTR(_44last_forward_bp_48149)->dbl;
    }

    /** 	ThisLine = top[THISLINE]*/
    DeRef(_44ThisLine_48142);
    _2 = (int)SEQ_PTR(_top_24781);
    _44ThisLine_48142 = (int)*(((s1_ptr)_2)->base + 20);
    Ref(_44ThisLine_48142);

    /** 	fwd_line_number = line_number --top[FWD_LINE_NUMBER]*/
    _35fwd_line_number_15970 = _35line_number_15969;

    /** 	forward_bp = top[FORWARD_BP]*/
    _2 = (int)SEQ_PTR(_top_24781);
    _44forward_bp_48147 = (int)*(((s1_ptr)_2)->base + 22);
    if (!IS_ATOM_INT(_44forward_bp_48147)){
        _44forward_bp_48147 = (long)DBL_PTR(_44forward_bp_48147)->dbl;
    }

    /** 	ForwardLine = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44ForwardLine_48143);
    _44ForwardLine_48143 = _44ThisLine_48142;

    /** 	putback_ForwardLine = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44putback_ForwardLine_48144);
    _44putback_ForwardLine_48144 = _44ThisLine_48142;

    /** 	last_ForwardLine = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_44last_ForwardLine_48145);
    _44last_ForwardLine_48145 = _44ThisLine_48142;

    /** 	IncludeStk = IncludeStk[1..$-1]*/
    if (IS_SEQUENCE(_61IncludeStk_23555)){
            _14118 = SEQ_PTR(_61IncludeStk_23555)->length;
    }
    else {
        _14118 = 1;
    }
    _14119 = _14118 - 1;
    _14118 = NOVALUE;
    rhs_slice_target = (object_ptr)&_61IncludeStk_23555;
    RHS_Slice(_61IncludeStk_23555, 1, _14119);

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_35TopLevelSub_15975 + ((s1_ptr)_2)->base);
    RefDS(_35Code_16056);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_35S_CODE_15653))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_35S_CODE_15653)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _35S_CODE_15653);
    _1 = *(int *)_2;
    *(int *)_2 = _35Code_16056;
    DeRef(_1);
    _14121 = NOVALUE;

    /** 	return TRUE*/
    DeRefDS(_top_24781);
    _14119 = NOVALUE;
    return _13TRUE_437;
    ;
}


int _61MakeInt(int _text_24869, int _nBase_24870)
{
    int _num_24871 = NOVALUE;
    int _fnum_24872 = NOVALUE;
    int _digit_24873 = NOVALUE;
    int _maxchk_24874 = NOVALUE;
    int _14166 = NOVALUE;
    int _14164 = NOVALUE;
    int _14162 = NOVALUE;
    int _14159 = NOVALUE;
    int _14158 = NOVALUE;
    int _14157 = NOVALUE;
    int _14155 = NOVALUE;
    int _14153 = NOVALUE;
    int _14152 = NOVALUE;
    int _14149 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_nBase_24870)) {
        _1 = (long)(DBL_PTR(_nBase_24870)->dbl);
        DeRefDS(_nBase_24870);
        _nBase_24870 = _1;
    }

    /** 	switch nBase do*/
    _0 = _nBase_24870;
    switch ( _0 ){ 

        /** 		case 2 then*/
        case 2:

        /** 			maxchk = 536870911*/
        _maxchk_24874 = 536870911;
        goto L1; // [21] 82

        /** 		case 8 then*/
        case 8:

        /** 			maxchk = 134217727*/
        _maxchk_24874 = 134217727;
        goto L1; // [32] 82

        /** 		case 10 then*/
        case 10:

        /** 			num = find(text, common_int_text)*/
        _num_24871 = find_from(_text_24869, _61common_int_text_24844, 1);

        /** 			if num then*/
        if (_num_24871 == 0)
        {
            goto L2; // [49] 65
        }
        else{
        }

        /** 				return common_ints[num]*/
        _2 = (int)SEQ_PTR(_61common_ints_24864);
        _14149 = (int)*(((s1_ptr)_2)->base + _num_24871);
        DeRefDS(_text_24869);
        DeRef(_fnum_24872);
        return _14149;
L2: 

        /** 			maxchk = 107374181*/
        _maxchk_24874 = 107374181;
        goto L1; // [70] 82

        /** 		case 16 then*/
        case 16:

        /** 			maxchk = 67108863*/
        _maxchk_24874 = 67108863;
    ;}L1: 

    /** 	num = 0*/
    _num_24871 = 0;

    /** 	fnum = 0*/
    DeRef(_fnum_24872);
    _fnum_24872 = 0;

    /** 	for i = 1 to length(text) do*/
    if (IS_SEQUENCE(_text_24869)){
            _14152 = SEQ_PTR(_text_24869)->length;
    }
    else {
        _14152 = 1;
    }
    {
        int _i_24889;
        _i_24889 = 1;
L3: 
        if (_i_24889 > _14152){
            goto L4; // [97] 212
        }

        /** 		digit = (text[i] - '0')*/
        _2 = (int)SEQ_PTR(_text_24869);
        _14153 = (int)*(((s1_ptr)_2)->base + _i_24889);
        if (IS_ATOM_INT(_14153)) {
            _digit_24873 = _14153 - 48;
        }
        else {
            _digit_24873 = binary_op(MINUS, _14153, 48);
        }
        _14153 = NOVALUE;
        if (!IS_ATOM_INT(_digit_24873)) {
            _1 = (long)(DBL_PTR(_digit_24873)->dbl);
            DeRefDS(_digit_24873);
            _digit_24873 = _1;
        }

        /** 		if digit >= nBase or digit < 0 then*/
        _14155 = (_digit_24873 >= _nBase_24870);
        if (_14155 != 0) {
            goto L5; // [122] 135
        }
        _14157 = (_digit_24873 < 0);
        if (_14157 == 0)
        {
            DeRef(_14157);
            _14157 = NOVALUE;
            goto L6; // [131] 151
        }
        else{
            DeRef(_14157);
            _14157 = NOVALUE;
        }
L5: 

        /** 			CompileErr(62, {text[i],i})*/
        _2 = (int)SEQ_PTR(_text_24869);
        _14158 = (int)*(((s1_ptr)_2)->base + _i_24889);
        Ref(_14158);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _14158;
        ((int *)_2)[2] = _i_24889;
        _14159 = MAKE_SEQ(_1);
        _14158 = NOVALUE;
        _44CompileErr(62, _14159, 0);
        _14159 = NOVALUE;
L6: 

        /** 		if fnum = 0 then*/
        if (binary_op_a(NOTEQ, _fnum_24872, 0)){
            goto L7; // [153] 194
        }

        /** 			if num <= maxchk then*/
        if (_num_24871 > _maxchk_24874)
        goto L8; // [161] 180

        /** 				num = num * nBase + digit*/
        if (_num_24871 == (short)_num_24871 && _nBase_24870 <= INT15 && _nBase_24870 >= -INT15)
        _14162 = _num_24871 * _nBase_24870;
        else
        _14162 = NewDouble(_num_24871 * (double)_nBase_24870);
        if (IS_ATOM_INT(_14162)) {
            _num_24871 = _14162 + _digit_24873;
        }
        else {
            _num_24871 = NewDouble(DBL_PTR(_14162)->dbl + (double)_digit_24873);
        }
        DeRef(_14162);
        _14162 = NOVALUE;
        if (!IS_ATOM_INT(_num_24871)) {
            _1 = (long)(DBL_PTR(_num_24871)->dbl);
            DeRefDS(_num_24871);
            _num_24871 = _1;
        }
        goto L9; // [177] 205
L8: 

        /** 				fnum = num * nBase + digit*/
        if (_num_24871 == (short)_num_24871 && _nBase_24870 <= INT15 && _nBase_24870 >= -INT15)
        _14164 = _num_24871 * _nBase_24870;
        else
        _14164 = NewDouble(_num_24871 * (double)_nBase_24870);
        DeRef(_fnum_24872);
        if (IS_ATOM_INT(_14164)) {
            _fnum_24872 = _14164 + _digit_24873;
            if ((long)((unsigned long)_fnum_24872 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_24872 = NewDouble((double)_fnum_24872);
        }
        else {
            _fnum_24872 = NewDouble(DBL_PTR(_14164)->dbl + (double)_digit_24873);
        }
        DeRef(_14164);
        _14164 = NOVALUE;
        goto L9; // [191] 205
L7: 

        /** 			fnum = fnum * nBase + digit*/
        if (IS_ATOM_INT(_fnum_24872)) {
            if (_fnum_24872 == (short)_fnum_24872 && _nBase_24870 <= INT15 && _nBase_24870 >= -INT15)
            _14166 = _fnum_24872 * _nBase_24870;
            else
            _14166 = NewDouble(_fnum_24872 * (double)_nBase_24870);
        }
        else {
            _14166 = NewDouble(DBL_PTR(_fnum_24872)->dbl * (double)_nBase_24870);
        }
        DeRef(_fnum_24872);
        if (IS_ATOM_INT(_14166)) {
            _fnum_24872 = _14166 + _digit_24873;
            if ((long)((unsigned long)_fnum_24872 + (unsigned long)HIGH_BITS) >= 0) 
            _fnum_24872 = NewDouble((double)_fnum_24872);
        }
        else {
            _fnum_24872 = NewDouble(DBL_PTR(_14166)->dbl + (double)_digit_24873);
        }
        DeRef(_14166);
        _14166 = NOVALUE;
L9: 

        /** 	end for*/
        _i_24889 = _i_24889 + 1;
        goto L3; // [207] 104
L4: 
        ;
    }

    /** 	if fnum = 0 then*/
    if (binary_op_a(NOTEQ, _fnum_24872, 0)){
        goto LA; // [214] 227
    }

    /** 		return num*/
    DeRefDS(_text_24869);
    DeRef(_fnum_24872);
    _14149 = NOVALUE;
    DeRef(_14155);
    _14155 = NOVALUE;
    return _num_24871;
    goto LB; // [224] 234
LA: 

    /** 		return fnum*/
    DeRefDS(_text_24869);
    _14149 = NOVALUE;
    DeRef(_14155);
    _14155 = NOVALUE;
    return _fnum_24872;
LB: 
    ;
}


int _61GetHexChar(int _cnt_24917, int _errno_24918)
{
    int _val_24919 = NOVALUE;
    int _d_24920 = NOVALUE;
    int _14176 = NOVALUE;
    int _14175 = NOVALUE;
    int _14170 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val = 0*/
    DeRef(_val_24919);
    _val_24919 = 0;

    /** 	while cnt > 0 do*/
L1: 
    if (_cnt_24917 <= 0)
    goto L2; // [15] 88

    /** 		d = find(getch(), "0123456789ABCDEFabcdef_")*/
    _14170 = _61getch();
    _d_24920 = find_from(_14170, _14171, 1);
    DeRef(_14170);
    _14170 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_24920 != 0)
    goto L3; // [31] 43

    /** 			CompileErr( errno )*/
    RefDS(_21815);
    _44CompileErr(_errno_24918, _21815, 0);
L3: 

    /** 		if d != 23 then*/
    if (_d_24920 == 23)
    goto L1; // [45] 15

    /** 			val = val * 16 + d - 1*/
    if (IS_ATOM_INT(_val_24919)) {
        if (_val_24919 == (short)_val_24919)
        _14175 = _val_24919 * 16;
        else
        _14175 = NewDouble(_val_24919 * (double)16);
    }
    else {
        _14175 = NewDouble(DBL_PTR(_val_24919)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14175)) {
        _14176 = _14175 + _d_24920;
        if ((long)((unsigned long)_14176 + (unsigned long)HIGH_BITS) >= 0) 
        _14176 = NewDouble((double)_14176);
    }
    else {
        _14176 = NewDouble(DBL_PTR(_14175)->dbl + (double)_d_24920);
    }
    DeRef(_14175);
    _14175 = NOVALUE;
    DeRef(_val_24919);
    if (IS_ATOM_INT(_14176)) {
        _val_24919 = _14176 - 1;
        if ((long)((unsigned long)_val_24919 +(unsigned long) HIGH_BITS) >= 0){
            _val_24919 = NewDouble((double)_val_24919);
        }
    }
    else {
        _val_24919 = NewDouble(DBL_PTR(_14176)->dbl - (double)1);
    }
    DeRef(_14176);
    _14176 = NOVALUE;

    /** 			if d > 16 then*/
    if (_d_24920 <= 16)
    goto L4; // [65] 76

    /** 				val -= 6*/
    _0 = _val_24919;
    if (IS_ATOM_INT(_val_24919)) {
        _val_24919 = _val_24919 - 6;
        if ((long)((unsigned long)_val_24919 +(unsigned long) HIGH_BITS) >= 0){
            _val_24919 = NewDouble((double)_val_24919);
        }
    }
    else {
        _val_24919 = NewDouble(DBL_PTR(_val_24919)->dbl - (double)6);
    }
    DeRef(_0);
L4: 

    /** 			cnt -= 1*/
    _cnt_24917 = _cnt_24917 - 1;

    /** 	end while*/
    goto L1; // [85] 15
L2: 

    /** 	return val*/
    return _val_24919;
    ;
}


int _61GetBinaryChar(int _delim_24940)
{
    int _val_24941 = NOVALUE;
    int _d_24942 = NOVALUE;
    int _vchars_24943 = NOVALUE;
    int _cnt_24946 = NOVALUE;
    int _14190 = NOVALUE;
    int _14189 = NOVALUE;
    int _14183 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence vchars = "01_ " & delim*/
    Append(&_vchars_24943, _14181, _delim_24940);

    /** 	integer cnt = 0*/
    _cnt_24946 = 0;

    /** 	val = 0*/
    DeRef(_val_24941);
    _val_24941 = 0;

    /** 	while 1 do*/
L1: 

    /** 		d = find(getch(), vchars)*/
    _14183 = _61getch();
    _d_24942 = find_from(_14183, _vchars_24943, 1);
    DeRef(_14183);
    _14183 = NOVALUE;

    /** 		if d = 0 then*/
    if (_d_24942 != 0)
    goto L2; // [36] 48

    /** 			CompileErr( 343 )*/
    RefDS(_21815);
    _44CompileErr(343, _21815, 0);
L2: 

    /** 		if d = 5 then*/
    if (_d_24942 != 5)
    goto L3; // [50] 63

    /** 			ungetch()*/
    _61ungetch();

    /** 			exit*/
    goto L4; // [60] 106
L3: 

    /** 		if d = 4 then*/
    if (_d_24942 != 4)
    goto L5; // [65] 74

    /** 			exit*/
    goto L4; // [71] 106
L5: 

    /** 		if d != 3 then*/
    if (_d_24942 == 3)
    goto L1; // [76] 24

    /** 			val = val * 2 + d - 1*/
    if (IS_ATOM_INT(_val_24941) && IS_ATOM_INT(_val_24941)) {
        _14189 = _val_24941 + _val_24941;
        if ((long)((unsigned long)_14189 + (unsigned long)HIGH_BITS) >= 0) 
        _14189 = NewDouble((double)_14189);
    }
    else {
        if (IS_ATOM_INT(_val_24941)) {
            _14189 = NewDouble((double)_val_24941 + DBL_PTR(_val_24941)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_24941)) {
                _14189 = NewDouble(DBL_PTR(_val_24941)->dbl + (double)_val_24941);
            }
            else
            _14189 = NewDouble(DBL_PTR(_val_24941)->dbl + DBL_PTR(_val_24941)->dbl);
        }
    }
    if (IS_ATOM_INT(_14189)) {
        _14190 = _14189 + _d_24942;
        if ((long)((unsigned long)_14190 + (unsigned long)HIGH_BITS) >= 0) 
        _14190 = NewDouble((double)_14190);
    }
    else {
        _14190 = NewDouble(DBL_PTR(_14189)->dbl + (double)_d_24942);
    }
    DeRef(_14189);
    _14189 = NOVALUE;
    DeRef(_val_24941);
    if (IS_ATOM_INT(_14190)) {
        _val_24941 = _14190 - 1;
        if ((long)((unsigned long)_val_24941 +(unsigned long) HIGH_BITS) >= 0){
            _val_24941 = NewDouble((double)_val_24941);
        }
    }
    else {
        _val_24941 = NewDouble(DBL_PTR(_14190)->dbl - (double)1);
    }
    DeRef(_14190);
    _14190 = NOVALUE;

    /** 			cnt += 1*/
    _cnt_24946 = _cnt_24946 + 1;

    /** 	end while*/
    goto L1; // [103] 24
L4: 

    /** 	if cnt = 0 then*/
    if (_cnt_24946 != 0)
    goto L6; // [108] 120

    /** 		CompileErr(343)*/
    RefDS(_21815);
    _44CompileErr(343, _21815, 0);
L6: 

    /** 	return val*/
    DeRefi(_vchars_24943);
    return _val_24941;
    ;
}


int _61EscapeChar(int _delim_24968)
{
    int _c_24969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c = getch()*/
    _0 = _c_24969;
    _c_24969 = _61getch();
    DeRef(_0);

    /** 	switch c do*/
    if (IS_SEQUENCE(_c_24969) ){
        goto L1; // [10] 135
    }
    if(!IS_ATOM_INT(_c_24969)){
        if( (DBL_PTR(_c_24969)->dbl != (double) ((int) DBL_PTR(_c_24969)->dbl) ) ){
            goto L1; // [10] 135
        }
        _0 = (int) DBL_PTR(_c_24969)->dbl;
    }
    else {
        _0 = _c_24969;
    };
    switch ( _0 ){ 

        /** 		case 'n' then*/
        case 110:

        /** 			c = 10 -- Newline*/
        DeRef(_c_24969);
        _c_24969 = 10;
        goto L2; // [24] 145

        /** 		case 't' then*/
        case 116:

        /** 			c = 9 -- Tabulator*/
        DeRef(_c_24969);
        _c_24969 = 9;
        goto L2; // [35] 145

        /** 		case '"', '\\', '\'' then*/
        case 34:
        case 92:
        case 39:

        /** 		case 'r' then*/
        goto L2; // [47] 145
        case 114:

        /** 			c = 13 -- Carriage Return*/
        DeRef(_c_24969);
        _c_24969 = 13;
        goto L2; // [56] 145

        /** 		case '0' then*/
        case 48:

        /** 			c = 0 -- Null*/
        DeRef(_c_24969);
        _c_24969 = 0;
        goto L2; // [67] 145

        /** 		case 'e', 'E' then*/
        case 101:
        case 69:

        /** 			c = 27 -- escape char.*/
        DeRef(_c_24969);
        _c_24969 = 27;
        goto L2; // [80] 145

        /** 		case 'x' then*/
        case 120:

        /** 			c = GetHexChar(2, 340)*/
        _0 = _c_24969;
        _c_24969 = _61GetHexChar(2, 340);
        DeRef(_0);
        goto L2; // [93] 145

        /** 		case 'u' then*/
        case 117:

        /** 			c = GetHexChar(4, 341)*/
        _0 = _c_24969;
        _c_24969 = _61GetHexChar(4, 341);
        DeRef(_0);
        goto L2; // [106] 145

        /** 		case 'U' then*/
        case 85:

        /** 			c = GetHexChar(8, 342)*/
        _0 = _c_24969;
        _c_24969 = _61GetHexChar(8, 342);
        DeRef(_0);
        goto L2; // [119] 145

        /** 		case 'b' then*/
        case 98:

        /** 			c = GetBinaryChar(delim)*/
        _0 = _c_24969;
        _c_24969 = _61GetBinaryChar(_delim_24968);
        DeRef(_0);
        goto L2; // [131] 145

        /** 		case else*/
        default:
L1: 

        /** 			CompileErr(155)*/
        RefDS(_21815);
        _44CompileErr(155, _21815, 0);
    ;}L2: 

    /** 	return c*/
    return _c_24969;
    ;
}


int _61my_sscanf(int _yytext_24992)
{
    int _e_sign_24993 = NOVALUE;
    int _ndigits_24994 = NOVALUE;
    int _e_mag_24995 = NOVALUE;
    int _mantissa_24996 = NOVALUE;
    int _c_24997 = NOVALUE;
    int _i_24998 = NOVALUE;
    int _dec_24999 = NOVALUE;
    int _frac_25029 = NOVALUE;
    int _14235 = NOVALUE;
    int _14230 = NOVALUE;
    int _14229 = NOVALUE;
    int _14227 = NOVALUE;
    int _14226 = NOVALUE;
    int _14225 = NOVALUE;
    int _14217 = NOVALUE;
    int _14216 = NOVALUE;
    int _14213 = NOVALUE;
    int _14212 = NOVALUE;
    int _14211 = NOVALUE;
    int _14207 = NOVALUE;
    int _14206 = NOVALUE;
    int _14204 = NOVALUE;
    int _14202 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(yytext) < 2 then*/
    if (IS_SEQUENCE(_yytext_24992)){
            _14202 = SEQ_PTR(_yytext_24992)->length;
    }
    else {
        _14202 = 1;
    }
    if (_14202 >= 2)
    goto L1; // [8] 20

    /** 		CompileErr(121)*/
    RefDS(_21815);
    _44CompileErr(121, _21815, 0);
L1: 

    /** 	if find( 'e', yytext ) or find( 'E', yytext ) then*/
    _14204 = find_from(101, _yytext_24992, 1);
    if (_14204 != 0) {
        goto L2; // [27] 41
    }
    _14206 = find_from(69, _yytext_24992, 1);
    if (_14206 == 0)
    {
        _14206 = NOVALUE;
        goto L3; // [37] 52
    }
    else{
        _14206 = NOVALUE;
    }
L2: 

    /** 		return scientific_to_atom( yytext )*/
    RefDS(_yytext_24992);
    _14207 = _62scientific_to_atom(_yytext_24992);
    DeRefDS(_yytext_24992);
    DeRef(_mantissa_24996);
    DeRef(_dec_24999);
    return _14207;
L3: 

    /** 	mantissa = 0.0*/
    RefDS(_14208);
    DeRef(_mantissa_24996);
    _mantissa_24996 = _14208;

    /** 	ndigits = 0*/
    _ndigits_24994 = 0;

    /** 	yytext &= 0 -- end marker*/
    Append(&_yytext_24992, _yytext_24992, 0);

    /** 	c = yytext[1]*/
    _2 = (int)SEQ_PTR(_yytext_24992);
    _c_24997 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_c_24997))
    _c_24997 = (long)DBL_PTR(_c_24997)->dbl;

    /** 	i = 2*/
    _i_24998 = 2;

    /** 	while c >= '0' and c <= '9' do*/
L4: 
    _14211 = (_c_24997 >= 48);
    if (_14211 == 0) {
        goto L5; // [88] 137
    }
    _14213 = (_c_24997 <= 57);
    if (_14213 == 0)
    {
        DeRef(_14213);
        _14213 = NOVALUE;
        goto L5; // [97] 137
    }
    else{
        DeRef(_14213);
        _14213 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_24994 = _ndigits_24994 + 1;

    /** 		mantissa = mantissa * 10.0 + (c - '0')*/
    if (IS_ATOM_INT(_mantissa_24996)) {
        _14216 = NewDouble((double)_mantissa_24996 * DBL_PTR(_14215)->dbl);
    }
    else {
        _14216 = NewDouble(DBL_PTR(_mantissa_24996)->dbl * DBL_PTR(_14215)->dbl);
    }
    _14217 = _c_24997 - 48;
    if ((long)((unsigned long)_14217 +(unsigned long) HIGH_BITS) >= 0){
        _14217 = NewDouble((double)_14217);
    }
    DeRef(_mantissa_24996);
    if (IS_ATOM_INT(_14217)) {
        _mantissa_24996 = NewDouble(DBL_PTR(_14216)->dbl + (double)_14217);
    }
    else
    _mantissa_24996 = NewDouble(DBL_PTR(_14216)->dbl + DBL_PTR(_14217)->dbl);
    DeRefDS(_14216);
    _14216 = NOVALUE;
    DeRef(_14217);
    _14217 = NOVALUE;

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_24992);
    _c_24997 = (int)*(((s1_ptr)_2)->base + _i_24998);
    if (!IS_ATOM_INT(_c_24997))
    _c_24997 = (long)DBL_PTR(_c_24997)->dbl;

    /** 		i += 1*/
    _i_24998 = _i_24998 + 1;

    /** 	end while*/
    goto L4; // [134] 84
L5: 

    /** 	if c = '.' then*/
    if (_c_24997 != 46)
    goto L6; // [139] 240

    /** 		c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_24992);
    _c_24997 = (int)*(((s1_ptr)_2)->base + _i_24998);
    if (!IS_ATOM_INT(_c_24997))
    _c_24997 = (long)DBL_PTR(_c_24997)->dbl;

    /** 		i += 1*/
    _i_24998 = _i_24998 + 1;

    /** 		dec = 1.0*/
    RefDS(_14224);
    DeRef(_dec_24999);
    _dec_24999 = _14224;

    /** 		atom frac = 0*/
    DeRef(_frac_25029);
    _frac_25029 = 0;

    /** 		while c >= '0' and c <= '9' do*/
L7: 
    _14225 = (_c_24997 >= 48);
    if (_14225 == 0) {
        goto L8; // [174] 229
    }
    _14227 = (_c_24997 <= 57);
    if (_14227 == 0)
    {
        DeRef(_14227);
        _14227 = NOVALUE;
        goto L8; // [183] 229
    }
    else{
        DeRef(_14227);
        _14227 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_24994 = _ndigits_24994 + 1;

    /** 			frac = frac * 10 + (c - '0')*/
    if (IS_ATOM_INT(_frac_25029)) {
        if (_frac_25029 == (short)_frac_25029)
        _14229 = _frac_25029 * 10;
        else
        _14229 = NewDouble(_frac_25029 * (double)10);
    }
    else {
        _14229 = NewDouble(DBL_PTR(_frac_25029)->dbl * (double)10);
    }
    _14230 = _c_24997 - 48;
    if ((long)((unsigned long)_14230 +(unsigned long) HIGH_BITS) >= 0){
        _14230 = NewDouble((double)_14230);
    }
    DeRef(_frac_25029);
    if (IS_ATOM_INT(_14229) && IS_ATOM_INT(_14230)) {
        _frac_25029 = _14229 + _14230;
        if ((long)((unsigned long)_frac_25029 + (unsigned long)HIGH_BITS) >= 0) 
        _frac_25029 = NewDouble((double)_frac_25029);
    }
    else {
        if (IS_ATOM_INT(_14229)) {
            _frac_25029 = NewDouble((double)_14229 + DBL_PTR(_14230)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14230)) {
                _frac_25029 = NewDouble(DBL_PTR(_14229)->dbl + (double)_14230);
            }
            else
            _frac_25029 = NewDouble(DBL_PTR(_14229)->dbl + DBL_PTR(_14230)->dbl);
        }
    }
    DeRef(_14229);
    _14229 = NOVALUE;
    DeRef(_14230);
    _14230 = NOVALUE;

    /** 			dec *= 10.0*/
    _0 = _dec_24999;
    if (IS_ATOM_INT(_dec_24999)) {
        _dec_24999 = NewDouble((double)_dec_24999 * DBL_PTR(_14215)->dbl);
    }
    else {
        _dec_24999 = NewDouble(DBL_PTR(_dec_24999)->dbl * DBL_PTR(_14215)->dbl);
    }
    DeRef(_0);

    /** 			c = yytext[i]*/
    _2 = (int)SEQ_PTR(_yytext_24992);
    _c_24997 = (int)*(((s1_ptr)_2)->base + _i_24998);
    if (!IS_ATOM_INT(_c_24997))
    _c_24997 = (long)DBL_PTR(_c_24997)->dbl;

    /** 			i += 1*/
    _i_24998 = _i_24998 + 1;

    /** 		end while*/
    goto L7; // [226] 170
L8: 

    /** 		mantissa += frac / dec*/
    if (IS_ATOM_INT(_frac_25029) && IS_ATOM_INT(_dec_24999)) {
        _14235 = (_frac_25029 % _dec_24999) ? NewDouble((double)_frac_25029 / _dec_24999) : (_frac_25029 / _dec_24999);
    }
    else {
        if (IS_ATOM_INT(_frac_25029)) {
            _14235 = NewDouble((double)_frac_25029 / DBL_PTR(_dec_24999)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_24999)) {
                _14235 = NewDouble(DBL_PTR(_frac_25029)->dbl / (double)_dec_24999);
            }
            else
            _14235 = NewDouble(DBL_PTR(_frac_25029)->dbl / DBL_PTR(_dec_24999)->dbl);
        }
    }
    _0 = _mantissa_24996;
    if (IS_ATOM_INT(_mantissa_24996) && IS_ATOM_INT(_14235)) {
        _mantissa_24996 = _mantissa_24996 + _14235;
        if ((long)((unsigned long)_mantissa_24996 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_24996 = NewDouble((double)_mantissa_24996);
    }
    else {
        if (IS_ATOM_INT(_mantissa_24996)) {
            _mantissa_24996 = NewDouble((double)_mantissa_24996 + DBL_PTR(_14235)->dbl);
        }
        else {
            if (IS_ATOM_INT(_14235)) {
                _mantissa_24996 = NewDouble(DBL_PTR(_mantissa_24996)->dbl + (double)_14235);
            }
            else
            _mantissa_24996 = NewDouble(DBL_PTR(_mantissa_24996)->dbl + DBL_PTR(_14235)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_14235);
    _14235 = NOVALUE;
L6: 
    DeRef(_frac_25029);
    _frac_25029 = NOVALUE;

    /** 	if ndigits = 0 then*/
    if (_ndigits_24994 != 0)
    goto L9; // [244] 256

    /** 		CompileErr(121)  -- no digits*/
    RefDS(_21815);
    _44CompileErr(121, _21815, 0);
L9: 

    /** 	return mantissa*/
    DeRefDS(_yytext_24992);
    DeRef(_dec_24999);
    DeRef(_14207);
    _14207 = NOVALUE;
    DeRef(_14211);
    _14211 = NOVALUE;
    DeRef(_14225);
    _14225 = NOVALUE;
    return _mantissa_24996;
    ;
}


void _61maybe_namespace()
{
    int _0, _1, _2;
    

    /** 	might_be_namespace = 1*/
    _61might_be_namespace_25046 = 1;

    /** end procedure*/
    return;
    ;
}


int _61ExtendedString(int _ech_25056)
{
    int _ch_25057 = NOVALUE;
    int _fch_25058 = NOVALUE;
    int _cline_25059 = NOVALUE;
    int _string_text_25060 = NOVALUE;
    int _trimming_25061 = NOVALUE;
    int _14288 = NOVALUE;
    int _14287 = NOVALUE;
    int _14285 = NOVALUE;
    int _14284 = NOVALUE;
    int _14283 = NOVALUE;
    int _14282 = NOVALUE;
    int _14281 = NOVALUE;
    int _14280 = NOVALUE;
    int _14279 = NOVALUE;
    int _14278 = NOVALUE;
    int _14276 = NOVALUE;
    int _14275 = NOVALUE;
    int _14274 = NOVALUE;
    int _14273 = NOVALUE;
    int _14272 = NOVALUE;
    int _14271 = NOVALUE;
    int _14268 = NOVALUE;
    int _14267 = NOVALUE;
    int _14266 = NOVALUE;
    int _14264 = NOVALUE;
    int _14263 = NOVALUE;
    int _14262 = NOVALUE;
    int _14261 = NOVALUE;
    int _14258 = NOVALUE;
    int _14243 = NOVALUE;
    int _14241 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25059 = _35line_number_15969;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRefi(_string_text_25060);
    _string_text_25060 = _5;

    /** 	trimming = 0*/
    _trimming_25061 = 0;

    /** 	ch = getch()*/
    _ch_25057 = _61getch();
    if (!IS_ATOM_INT(_ch_25057)) {
        _1 = (long)(DBL_PTR(_ch_25057)->dbl);
        DeRefDS(_ch_25057);
        _ch_25057 = _1;
    }

    /** 	if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_44ThisLine_48142)){
            _14241 = SEQ_PTR(_44ThisLine_48142)->length;
    }
    else {
        _14241 = 1;
    }
    if (_44bp_48146 <= _14241)
    goto L1; // [40] 101

    /** 		read_line()*/
    _61read_line();

    /** 		while ThisLine[bp] = '_' do*/
L2: 
    _2 = (int)SEQ_PTR(_44ThisLine_48142);
    _14243 = (int)*(((s1_ptr)_2)->base + _44bp_48146);
    if (binary_op_a(NOTEQ, _14243, 95)){
        _14243 = NOVALUE;
        goto L3; // [61] 86
    }
    _14243 = NOVALUE;

    /** 			trimming += 1*/
    _trimming_25061 = _trimming_25061 + 1;

    /** 			bp += 1*/
    _44bp_48146 = _44bp_48146 + 1;

    /** 		end while*/
    goto L2; // [83] 53
L3: 

    /** 		if trimming > 0 then*/
    if (_trimming_25061 <= 0)
    goto L4; // [88] 100

    /** 			ch = getch()*/
    _ch_25057 = _61getch();
    if (!IS_ATOM_INT(_ch_25057)) {
        _1 = (long)(DBL_PTR(_ch_25057)->dbl);
        DeRefDS(_ch_25057);
        _ch_25057 = _1;
    }
L4: 
L1: 

    /** 	while 1 do*/
L5: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25057 != 26)
    goto L6; // [110] 122

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25059, 0);
L6: 

    /** 		if ch = ech then*/
    if (_ch_25057 != _ech_25056)
    goto L7; // [124] 180

    /** 			if ech != '"' then*/
    if (_ech_25056 == 34)
    goto L8; // [130] 139

    /** 				exit*/
    goto L9; // [136] 310
L8: 

    /** 			fch = getch()*/
    _fch_25058 = _61getch();
    if (!IS_ATOM_INT(_fch_25058)) {
        _1 = (long)(DBL_PTR(_fch_25058)->dbl);
        DeRefDS(_fch_25058);
        _fch_25058 = _1;
    }

    /** 			if fch = '"' then*/
    if (_fch_25058 != 34)
    goto LA; // [148] 175

    /** 				fch = getch()*/
    _fch_25058 = _61getch();
    if (!IS_ATOM_INT(_fch_25058)) {
        _1 = (long)(DBL_PTR(_fch_25058)->dbl);
        DeRefDS(_fch_25058);
        _fch_25058 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25058 != 34)
    goto LB; // [161] 170

    /** 					exit*/
    goto L9; // [167] 310
LB: 

    /** 				ungetch()*/
    _61ungetch();
LA: 

    /** 			ungetch()*/
    _61ungetch();
L7: 

    /** 		if ch != '\r' then*/
    if (_ch_25057 == 13)
    goto LC; // [182] 193

    /** 			string_text &= ch*/
    Append(&_string_text_25060, _string_text_25060, _ch_25057);
LC: 

    /** 		if bp > length(ThisLine) then*/
    if (IS_SEQUENCE(_44ThisLine_48142)){
            _14258 = SEQ_PTR(_44ThisLine_48142)->length;
    }
    else {
        _14258 = 1;
    }
    if (_44bp_48146 <= _14258)
    goto LD; // [202] 298

    /** 			read_line() -- sets bp to 1, btw.*/
    _61read_line();

    /** 			if trimming > 0 then*/
    if (_trimming_25061 <= 0)
    goto LE; // [212] 297

    /** 				while bp <= trimming and bp <= length(ThisLine) do*/
LF: 
    _14261 = (_44bp_48146 <= _trimming_25061);
    if (_14261 == 0) {
        goto L10; // [227] 296
    }
    if (IS_SEQUENCE(_44ThisLine_48142)){
            _14263 = SEQ_PTR(_44ThisLine_48142)->length;
    }
    else {
        _14263 = 1;
    }
    _14264 = (_44bp_48146 <= _14263);
    _14263 = NOVALUE;
    if (_14264 == 0)
    {
        DeRef(_14264);
        _14264 = NOVALUE;
        goto L10; // [243] 296
    }
    else{
        DeRef(_14264);
        _14264 = NOVALUE;
    }

    /** 					ch = ThisLine[bp]*/
    _2 = (int)SEQ_PTR(_44ThisLine_48142);
    _ch_25057 = (int)*(((s1_ptr)_2)->base + _44bp_48146);
    if (!IS_ATOM_INT(_ch_25057)){
        _ch_25057 = (long)DBL_PTR(_ch_25057)->dbl;
    }

    /** 					if ch != ' ' and ch != '\t' then*/
    _14266 = (_ch_25057 != 32);
    if (_14266 == 0) {
        goto L11; // [264] 281
    }
    _14268 = (_ch_25057 != 9);
    if (_14268 == 0)
    {
        DeRef(_14268);
        _14268 = NOVALUE;
        goto L11; // [273] 281
    }
    else{
        DeRef(_14268);
        _14268 = NOVALUE;
    }

    /** 						exit*/
    goto L10; // [278] 296
L11: 

    /** 					bp += 1*/
    _44bp_48146 = _44bp_48146 + 1;

    /** 				end while*/
    goto LF; // [293] 221
L10: 
LE: 
LD: 

    /** 		ch = getch()*/
    _ch_25057 = _61getch();
    if (!IS_ATOM_INT(_ch_25057)) {
        _1 = (long)(DBL_PTR(_ch_25057)->dbl);
        DeRefDS(_ch_25057);
        _ch_25057 = _1;
    }

    /** 	end while*/
    goto L5; // [307] 106
L9: 

    /** 	if length(string_text) > 0 and string_text[1] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25060)){
            _14271 = SEQ_PTR(_string_text_25060)->length;
    }
    else {
        _14271 = 1;
    }
    _14272 = (_14271 > 0);
    _14271 = NOVALUE;
    if (_14272 == 0) {
        goto L12; // [319] 389
    }
    _2 = (int)SEQ_PTR(_string_text_25060);
    _14274 = (int)*(((s1_ptr)_2)->base + 1);
    _14275 = (_14274 == 10);
    _14274 = NOVALUE;
    if (_14275 == 0)
    {
        DeRef(_14275);
        _14275 = NOVALUE;
        goto L12; // [332] 389
    }
    else{
        DeRef(_14275);
        _14275 = NOVALUE;
    }

    /** 		string_text = string_text[2 .. $]*/
    if (IS_SEQUENCE(_string_text_25060)){
            _14276 = SEQ_PTR(_string_text_25060)->length;
    }
    else {
        _14276 = 1;
    }
    rhs_slice_target = (object_ptr)&_string_text_25060;
    RHS_Slice(_string_text_25060, 2, _14276);

    /** 		if length(string_text) > 0 and string_text[$] = '\n' then*/
    if (IS_SEQUENCE(_string_text_25060)){
            _14278 = SEQ_PTR(_string_text_25060)->length;
    }
    else {
        _14278 = 1;
    }
    _14279 = (_14278 > 0);
    _14278 = NOVALUE;
    if (_14279 == 0) {
        goto L13; // [354] 388
    }
    if (IS_SEQUENCE(_string_text_25060)){
            _14281 = SEQ_PTR(_string_text_25060)->length;
    }
    else {
        _14281 = 1;
    }
    _2 = (int)SEQ_PTR(_string_text_25060);
    _14282 = (int)*(((s1_ptr)_2)->base + _14281);
    _14283 = (_14282 == 10);
    _14282 = NOVALUE;
    if (_14283 == 0)
    {
        DeRef(_14283);
        _14283 = NOVALUE;
        goto L13; // [370] 388
    }
    else{
        DeRef(_14283);
        _14283 = NOVALUE;
    }

    /** 			string_text = string_text[1 .. $-1]*/
    if (IS_SEQUENCE(_string_text_25060)){
            _14284 = SEQ_PTR(_string_text_25060)->length;
    }
    else {
        _14284 = 1;
    }
    _14285 = _14284 - 1;
    _14284 = NOVALUE;
    rhs_slice_target = (object_ptr)&_string_text_25060;
    RHS_Slice(_string_text_25060, 1, _14285);
L13: 
L12: 

    /** 	return {STRING, NewStringSym(string_text)}*/
    RefDS(_string_text_25060);
    _14287 = _53NewStringSym(_string_text_25060);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14287;
    _14288 = MAKE_SEQ(_1);
    _14287 = NOVALUE;
    DeRefDSi(_string_text_25060);
    DeRef(_14261);
    _14261 = NOVALUE;
    DeRef(_14266);
    _14266 = NOVALUE;
    DeRef(_14272);
    _14272 = NOVALUE;
    DeRef(_14279);
    _14279 = NOVALUE;
    DeRef(_14285);
    _14285 = NOVALUE;
    return _14288;
    ;
}


int _61GetHexString(int _maxnibbles_25147)
{
    int _ch_25148 = NOVALUE;
    int _digit_25149 = NOVALUE;
    int _val_25150 = NOVALUE;
    int _cline_25151 = NOVALUE;
    int _nibble_25152 = NOVALUE;
    int _string_text_25153 = NOVALUE;
    int _14302 = NOVALUE;
    int _14301 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25151 = _35line_number_15969;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25153);
    _string_text_25153 = _5;

    /** 	nibble = 1*/
    _nibble_25152 = 1;

    /** 	val = -1*/
    DeRef(_val_25150);
    _val_25150 = -1;

    /** 	ch = getch()*/
    _ch_25148 = _61getch();
    if (!IS_ATOM_INT(_ch_25148)) {
        _1 = (long)(DBL_PTR(_ch_25148)->dbl);
        DeRefDS(_ch_25148);
        _ch_25148 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25148 != 26)
    goto L2; // [45] 57

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25151, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25148 != 34)
    goto L3; // [59] 68

    /** 			exit*/
    goto L4; // [65] 224
L3: 

    /** 		digit = find(ch, "0123456789ABCDEFabcdef_ \t\n\r")*/
    _digit_25149 = find_from(_ch_25148, _14292, 1);

    /** 		if digit = 0 then*/
    if (_digit_25149 != 0)
    goto L5; // [77] 89

    /** 			CompileErr(329)*/
    RefDS(_21815);
    _44CompileErr(329, _21815, 0);
L5: 

    /** 		if digit <= 23 then*/
    if (_digit_25149 > 23)
    goto L6; // [91] 177

    /** 			if digit != 23 then*/
    if (_digit_25149 == 23)
    goto L7; // [97] 212

    /** 				if digit > 16 then*/
    if (_digit_25149 <= 16)
    goto L8; // [103] 114

    /** 					digit -= 6*/
    _digit_25149 = _digit_25149 - 6;
L8: 

    /** 				if nibble = 1 then*/
    if (_nibble_25152 != 1)
    goto L9; // [116] 129

    /** 					val = digit - 1*/
    DeRef(_val_25150);
    _val_25150 = _digit_25149 - 1;
    if ((long)((unsigned long)_val_25150 +(unsigned long) HIGH_BITS) >= 0){
        _val_25150 = NewDouble((double)_val_25150);
    }
    goto LA; // [126] 167
L9: 

    /** 					val = val * 16 + digit - 1*/
    if (IS_ATOM_INT(_val_25150)) {
        if (_val_25150 == (short)_val_25150)
        _14301 = _val_25150 * 16;
        else
        _14301 = NewDouble(_val_25150 * (double)16);
    }
    else {
        _14301 = NewDouble(DBL_PTR(_val_25150)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_14301)) {
        _14302 = _14301 + _digit_25149;
        if ((long)((unsigned long)_14302 + (unsigned long)HIGH_BITS) >= 0) 
        _14302 = NewDouble((double)_14302);
    }
    else {
        _14302 = NewDouble(DBL_PTR(_14301)->dbl + (double)_digit_25149);
    }
    DeRef(_14301);
    _14301 = NOVALUE;
    DeRef(_val_25150);
    if (IS_ATOM_INT(_14302)) {
        _val_25150 = _14302 - 1;
        if ((long)((unsigned long)_val_25150 +(unsigned long) HIGH_BITS) >= 0){
            _val_25150 = NewDouble((double)_val_25150);
        }
    }
    else {
        _val_25150 = NewDouble(DBL_PTR(_14302)->dbl - (double)1);
    }
    DeRef(_14302);
    _14302 = NOVALUE;

    /** 					if nibble = maxnibbles then*/
    if (_nibble_25152 != _maxnibbles_25147)
    goto LB; // [145] 166

    /** 						string_text &= val*/
    Ref(_val_25150);
    Append(&_string_text_25153, _string_text_25153, _val_25150);

    /** 						val = -1*/
    DeRef(_val_25150);
    _val_25150 = -1;

    /** 						nibble = 0*/
    _nibble_25152 = 0;
LB: 
LA: 

    /** 				nibble += 1*/
    _nibble_25152 = _nibble_25152 + 1;
    goto L7; // [174] 212
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25150, 0)){
        goto LC; // [179] 195
    }

    /** 				string_text &= val*/
    Ref(_val_25150);
    Append(&_string_text_25153, _string_text_25153, _val_25150);

    /** 				val = -1*/
    DeRef(_val_25150);
    _val_25150 = -1;
LC: 

    /** 			nibble = 1*/
    _nibble_25152 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25148 != 10)
    goto LD; // [202] 211

    /** 				read_line()*/
    _61read_line();
LD: 
L7: 

    /** 		ch = getch()*/
    _ch_25148 = _61getch();
    if (!IS_ATOM_INT(_ch_25148)) {
        _1 = (long)(DBL_PTR(_ch_25148)->dbl);
        DeRefDS(_ch_25148);
        _ch_25148 = _1;
    }

    /** 	end while*/
    goto L1; // [221] 41
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25150, 0)){
        goto LE; // [226] 237
    }

    /** 		string_text &= val*/
    Ref(_val_25150);
    Append(&_string_text_25153, _string_text_25153, _val_25150);
LE: 

    /** 	return string_text*/
    DeRef(_val_25150);
    return _string_text_25153;
    ;
}


int _61GetBitString()
{
    int _ch_25198 = NOVALUE;
    int _digit_25199 = NOVALUE;
    int _val_25200 = NOVALUE;
    int _cline_25201 = NOVALUE;
    int _bitcnt_25202 = NOVALUE;
    int _string_text_25203 = NOVALUE;
    int _14324 = NOVALUE;
    int _14323 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cline = line_number*/
    _cline_25201 = _35line_number_15969;

    /** 	string_text = ""*/
    RefDS(_5);
    DeRef(_string_text_25203);
    _string_text_25203 = _5;

    /** 	bitcnt = 1*/
    _bitcnt_25202 = 1;

    /** 	val = -1*/
    DeRef(_val_25200);
    _val_25200 = -1;

    /** 	ch = getch()*/
    _ch_25198 = _61getch();
    if (!IS_ATOM_INT(_ch_25198)) {
        _1 = (long)(DBL_PTR(_ch_25198)->dbl);
        DeRefDS(_ch_25198);
        _ch_25198 = _1;
    }

    /** 	while 1 do*/
L1: 

    /** 		if ch = END_OF_FILE_CHAR then*/
    if (_ch_25198 != 26)
    goto L2; // [43] 55

    /** 			CompileErr(129, cline)*/
    _44CompileErr(129, _cline_25201, 0);
L2: 

    /** 		if ch = '"' then*/
    if (_ch_25198 != 34)
    goto L3; // [57] 66

    /** 			exit*/
    goto L4; // [63] 186
L3: 

    /** 		digit = find(ch, "01_ \t\n\r")*/
    _digit_25199 = find_from(_ch_25198, _14316, 1);

    /** 		if digit = 0 then*/
    if (_digit_25199 != 0)
    goto L5; // [75] 87

    /** 			CompileErr(329)*/
    RefDS(_21815);
    _44CompileErr(329, _21815, 0);
L5: 

    /** 		if digit <= 3 then*/
    if (_digit_25199 > 3)
    goto L6; // [89] 139

    /** 			if digit != 3 then*/
    if (_digit_25199 == 3)
    goto L7; // [95] 174

    /** 				if bitcnt = 1 then*/
    if (_bitcnt_25202 != 1)
    goto L8; // [101] 114

    /** 					val = digit - 1*/
    DeRef(_val_25200);
    _val_25200 = _digit_25199 - 1;
    if ((long)((unsigned long)_val_25200 +(unsigned long) HIGH_BITS) >= 0){
        _val_25200 = NewDouble((double)_val_25200);
    }
    goto L9; // [111] 129
L8: 

    /** 					val = val * 2 + digit - 1*/
    if (IS_ATOM_INT(_val_25200) && IS_ATOM_INT(_val_25200)) {
        _14323 = _val_25200 + _val_25200;
        if ((long)((unsigned long)_14323 + (unsigned long)HIGH_BITS) >= 0) 
        _14323 = NewDouble((double)_14323);
    }
    else {
        if (IS_ATOM_INT(_val_25200)) {
            _14323 = NewDouble((double)_val_25200 + DBL_PTR(_val_25200)->dbl);
        }
        else {
            if (IS_ATOM_INT(_val_25200)) {
                _14323 = NewDouble(DBL_PTR(_val_25200)->dbl + (double)_val_25200);
            }
            else
            _14323 = NewDouble(DBL_PTR(_val_25200)->dbl + DBL_PTR(_val_25200)->dbl);
        }
    }
    if (IS_ATOM_INT(_14323)) {
        _14324 = _14323 + _digit_25199;
        if ((long)((unsigned long)_14324 + (unsigned long)HIGH_BITS) >= 0) 
        _14324 = NewDouble((double)_14324);
    }
    else {
        _14324 = NewDouble(DBL_PTR(_14323)->dbl + (double)_digit_25199);
    }
    DeRef(_14323);
    _14323 = NOVALUE;
    DeRef(_val_25200);
    if (IS_ATOM_INT(_14324)) {
        _val_25200 = _14324 - 1;
        if ((long)((unsigned long)_val_25200 +(unsigned long) HIGH_BITS) >= 0){
            _val_25200 = NewDouble((double)_val_25200);
        }
    }
    else {
        _val_25200 = NewDouble(DBL_PTR(_14324)->dbl - (double)1);
    }
    DeRef(_14324);
    _14324 = NOVALUE;
L9: 

    /** 				bitcnt += 1*/
    _bitcnt_25202 = _bitcnt_25202 + 1;
    goto L7; // [136] 174
L6: 

    /** 			if val >= 0 then*/
    if (binary_op_a(LESS, _val_25200, 0)){
        goto LA; // [141] 157
    }

    /** 				string_text &= val*/
    Ref(_val_25200);
    Append(&_string_text_25203, _string_text_25203, _val_25200);

    /** 				val = -1*/
    DeRef(_val_25200);
    _val_25200 = -1;
LA: 

    /** 			bitcnt = 1*/
    _bitcnt_25202 = 1;

    /** 			if ch = '\n' then*/
    if (_ch_25198 != 10)
    goto LB; // [164] 173

    /** 				read_line()*/
    _61read_line();
LB: 
L7: 

    /** 		ch = getch()*/
    _ch_25198 = _61getch();
    if (!IS_ATOM_INT(_ch_25198)) {
        _1 = (long)(DBL_PTR(_ch_25198)->dbl);
        DeRefDS(_ch_25198);
        _ch_25198 = _1;
    }

    /** 	end while*/
    goto L1; // [183] 39
L4: 

    /** 	if val >= 0 then	*/
    if (binary_op_a(LESS, _val_25200, 0)){
        goto LC; // [188] 199
    }

    /** 		string_text &= val*/
    Ref(_val_25200);
    Append(&_string_text_25203, _string_text_25203, _val_25200);
LC: 

    /** 	return string_text*/
    DeRef(_val_25200);
    return _string_text_25203;
    ;
}


int _61Scanner()
{
    int _fwd_inlined_set_qualified_fwd_at_441_25341 = NOVALUE;
    int _ch_25242 = NOVALUE;
    int _i_25243 = NOVALUE;
    int _sp_25244 = NOVALUE;
    int _prev_Nne_25245 = NOVALUE;
    int _pch_25246 = NOVALUE;
    int _cline_25247 = NOVALUE;
    int _yytext_25248 = NOVALUE;
    int _namespaces_25249 = NOVALUE;
    int _d_25250 = NOVALUE;
    int _tok_25252 = NOVALUE;
    int _is_int_25253 = NOVALUE;
    int _class_25254 = NOVALUE;
    int _name_25255 = NOVALUE;
    int _is_namespace_25314 = NOVALUE;
    int _basetype_25548 = NOVALUE;
    int _hdigit_25588 = NOVALUE;
    int _fch_25726 = NOVALUE;
    int _cnest_25903 = NOVALUE;
    int _ach_25932 = NOVALUE;
    int _31395 = NOVALUE;
    int _31394 = NOVALUE;
    int _31393 = NOVALUE;
    int _31392 = NOVALUE;
    int _31391 = NOVALUE;
    int _31390 = NOVALUE;
    int _31389 = NOVALUE;
    int _14720 = NOVALUE;
    int _14719 = NOVALUE;
    int _14717 = NOVALUE;
    int _14715 = NOVALUE;
    int _14714 = NOVALUE;
    int _14713 = NOVALUE;
    int _14711 = NOVALUE;
    int _14710 = NOVALUE;
    int _14709 = NOVALUE;
    int _14708 = NOVALUE;
    int _14706 = NOVALUE;
    int _14705 = NOVALUE;
    int _14703 = NOVALUE;
    int _14701 = NOVALUE;
    int _14700 = NOVALUE;
    int _14698 = NOVALUE;
    int _14696 = NOVALUE;
    int _14695 = NOVALUE;
    int _14693 = NOVALUE;
    int _14691 = NOVALUE;
    int _14690 = NOVALUE;
    int _14689 = NOVALUE;
    int _14688 = NOVALUE;
    int _14687 = NOVALUE;
    int _14685 = NOVALUE;
    int _14684 = NOVALUE;
    int _14674 = NOVALUE;
    int _14661 = NOVALUE;
    int _14657 = NOVALUE;
    int _14656 = NOVALUE;
    int _14652 = NOVALUE;
    int _14651 = NOVALUE;
    int _14650 = NOVALUE;
    int _14649 = NOVALUE;
    int _14647 = NOVALUE;
    int _14646 = NOVALUE;
    int _14643 = NOVALUE;
    int _14642 = NOVALUE;
    int _14641 = NOVALUE;
    int _14640 = NOVALUE;
    int _14639 = NOVALUE;
    int _14638 = NOVALUE;
    int _14636 = NOVALUE;
    int _14635 = NOVALUE;
    int _14634 = NOVALUE;
    int _14633 = NOVALUE;
    int _14632 = NOVALUE;
    int _14631 = NOVALUE;
    int _14629 = NOVALUE;
    int _14628 = NOVALUE;
    int _14625 = NOVALUE;
    int _14622 = NOVALUE;
    int _14617 = NOVALUE;
    int _14616 = NOVALUE;
    int _14615 = NOVALUE;
    int _14614 = NOVALUE;
    int _14613 = NOVALUE;
    int _14612 = NOVALUE;
    int _14610 = NOVALUE;
    int _14609 = NOVALUE;
    int _14608 = NOVALUE;
    int _14607 = NOVALUE;
    int _14606 = NOVALUE;
    int _14605 = NOVALUE;
    int _14603 = NOVALUE;
    int _14602 = NOVALUE;
    int _14599 = NOVALUE;
    int _14596 = NOVALUE;
    int _14594 = NOVALUE;
    int _14593 = NOVALUE;
    int _14589 = NOVALUE;
    int _14588 = NOVALUE;
    int _14584 = NOVALUE;
    int _14583 = NOVALUE;
    int _14582 = NOVALUE;
    int _14580 = NOVALUE;
    int _14575 = NOVALUE;
    int _14572 = NOVALUE;
    int _14571 = NOVALUE;
    int _14570 = NOVALUE;
    int _14569 = NOVALUE;
    int _14563 = NOVALUE;
    int _14561 = NOVALUE;
    int _14556 = NOVALUE;
    int _14555 = NOVALUE;
    int _14554 = NOVALUE;
    int _14553 = NOVALUE;
    int _14552 = NOVALUE;
    int _14551 = NOVALUE;
    int _14550 = NOVALUE;
    int _14548 = NOVALUE;
    int _14546 = NOVALUE;
    int _14545 = NOVALUE;
    int _14544 = NOVALUE;
    int _14543 = NOVALUE;
    int _14542 = NOVALUE;
    int _14540 = NOVALUE;
    int _14536 = NOVALUE;
    int _14535 = NOVALUE;
    int _14534 = NOVALUE;
    int _14533 = NOVALUE;
    int _14532 = NOVALUE;
    int _14530 = NOVALUE;
    int _14529 = NOVALUE;
    int _14527 = NOVALUE;
    int _14523 = NOVALUE;
    int _14520 = NOVALUE;
    int _14519 = NOVALUE;
    int _14517 = NOVALUE;
    int _14516 = NOVALUE;
    int _14515 = NOVALUE;
    int _14512 = NOVALUE;
    int _14510 = NOVALUE;
    int _14509 = NOVALUE;
    int _14505 = NOVALUE;
    int _14501 = NOVALUE;
    int _14498 = NOVALUE;
    int _14492 = NOVALUE;
    int _14484 = NOVALUE;
    int _14483 = NOVALUE;
    int _14482 = NOVALUE;
    int _14480 = NOVALUE;
    int _14477 = NOVALUE;
    int _14475 = NOVALUE;
    int _14473 = NOVALUE;
    int _14470 = NOVALUE;
    int _14467 = NOVALUE;
    int _14465 = NOVALUE;
    int _14463 = NOVALUE;
    int _14461 = NOVALUE;
    int _14460 = NOVALUE;
    int _14456 = NOVALUE;
    int _14453 = NOVALUE;
    int _14451 = NOVALUE;
    int _14448 = NOVALUE;
    int _14441 = NOVALUE;
    int _14439 = NOVALUE;
    int _14436 = NOVALUE;
    int _14430 = NOVALUE;
    int _14429 = NOVALUE;
    int _14428 = NOVALUE;
    int _14427 = NOVALUE;
    int _14426 = NOVALUE;
    int _14425 = NOVALUE;
    int _14424 = NOVALUE;
    int _14422 = NOVALUE;
    int _14420 = NOVALUE;
    int _14418 = NOVALUE;
    int _14416 = NOVALUE;
    int _14414 = NOVALUE;
    int _14413 = NOVALUE;
    int _14412 = NOVALUE;
    int _14411 = NOVALUE;
    int _14410 = NOVALUE;
    int _14408 = NOVALUE;
    int _14405 = NOVALUE;
    int _14403 = NOVALUE;
    int _14402 = NOVALUE;
    int _14401 = NOVALUE;
    int _14399 = NOVALUE;
    int _14394 = NOVALUE;
    int _14390 = NOVALUE;
    int _14387 = NOVALUE;
    int _14385 = NOVALUE;
    int _14384 = NOVALUE;
    int _14382 = NOVALUE;
    int _14380 = NOVALUE;
    int _14378 = NOVALUE;
    int _14377 = NOVALUE;
    int _14376 = NOVALUE;
    int _14374 = NOVALUE;
    int _14369 = NOVALUE;
    int _14366 = NOVALUE;
    int _14364 = NOVALUE;
    int _14361 = NOVALUE;
    int _14360 = NOVALUE;
    int _14358 = NOVALUE;
    int _14357 = NOVALUE;
    int _14356 = NOVALUE;
    int _14355 = NOVALUE;
    int _14354 = NOVALUE;
    int _14353 = NOVALUE;
    int _14352 = NOVALUE;
    int _14351 = NOVALUE;
    int _14350 = NOVALUE;
    int _14349 = NOVALUE;
    int _14348 = NOVALUE;
    int _14347 = NOVALUE;
    int _14346 = NOVALUE;
    int _14341 = NOVALUE;
    int _14339 = NOVALUE;
    int _14336 = NOVALUE;
    int _14334 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer is_int, class*/

    /** 	sequence name*/

    /** 	while TRUE do*/
L1: 
    if (_13TRUE_437 == 0)
    {
        goto L2; // [12] 3802
    }
    else{
    }

    /** 		ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 		while ch = ' ' or ch = '\t' do*/
L3: 
    _14334 = (_ch_25242 == 32);
    if (_14334 != 0) {
        goto L4; // [31] 44
    }
    _14336 = (_ch_25242 == 9);
    if (_14336 == 0)
    {
        DeRef(_14336);
        _14336 = NOVALUE;
        goto L5; // [40] 56
    }
    else{
        DeRef(_14336);
        _14336 = NOVALUE;
    }
L4: 

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 		end while*/
    goto L3; // [53] 27
L5: 

    /** 		class = char_class[ch]*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _class_25254 = (int)*(((s1_ptr)_2)->base + _ch_25242);

    /** 		if class = LETTER or ch = '_' then*/
    _14339 = (_class_25254 == -2);
    if (_14339 != 0) {
        goto L6; // [72] 85
    }
    _14341 = (_ch_25242 == 95);
    if (_14341 == 0)
    {
        DeRef(_14341);
        _14341 = NOVALUE;
        goto L7; // [81] 1282
    }
    else{
        DeRef(_14341);
        _14341 = NOVALUE;
    }
L6: 

    /** 			sp = bp*/
    _sp_25244 = _44bp_48146;

    /** 			pch = ch*/
    _pch_25246 = _ch_25242;

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25242 != 34)
    goto L8; // [108] 222

    /** 				switch pch do*/
    _0 = _pch_25246;
    switch ( _0 ){ 

        /** 					case 'x' then*/
        case 120:

        /** 						return {STRING, NewStringSym(GetHexString(2))}*/
        _14346 = _61GetHexString(2);
        _14347 = _53NewStringSym(_14346);
        _14346 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14347;
        _14348 = MAKE_SEQ(_1);
        _14347 = NOVALUE;
        DeRef(_yytext_25248);
        DeRef(_namespaces_25249);
        DeRef(_d_25250);
        DeRef(_tok_25252);
        DeRef(_name_25255);
        DeRef(_14334);
        _14334 = NOVALUE;
        DeRef(_14339);
        _14339 = NOVALUE;
        return _14348;
        goto L9; // [143] 221

        /** 					case 'u' then*/
        case 117:

        /** 						return {STRING, NewStringSym(GetHexString(4))}*/
        _14349 = _61GetHexString(4);
        _14350 = _53NewStringSym(_14349);
        _14349 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14350;
        _14351 = MAKE_SEQ(_1);
        _14350 = NOVALUE;
        DeRef(_yytext_25248);
        DeRef(_namespaces_25249);
        DeRef(_d_25250);
        DeRef(_tok_25252);
        DeRef(_name_25255);
        DeRef(_14334);
        _14334 = NOVALUE;
        DeRef(_14339);
        _14339 = NOVALUE;
        DeRef(_14348);
        _14348 = NOVALUE;
        return _14351;
        goto L9; // [169] 221

        /** 					case 'U' then*/
        case 85:

        /** 						return {STRING, NewStringSym(GetHexString(8))}*/
        _14352 = _61GetHexString(8);
        _14353 = _53NewStringSym(_14352);
        _14352 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14353;
        _14354 = MAKE_SEQ(_1);
        _14353 = NOVALUE;
        DeRef(_yytext_25248);
        DeRef(_namespaces_25249);
        DeRef(_d_25250);
        DeRef(_tok_25252);
        DeRef(_name_25255);
        DeRef(_14334);
        _14334 = NOVALUE;
        DeRef(_14339);
        _14339 = NOVALUE;
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14351);
        _14351 = NOVALUE;
        return _14354;
        goto L9; // [195] 221

        /** 					case 'b' then*/
        case 98:

        /** 						return {STRING, NewStringSym(GetBitString())}*/
        _14355 = _61GetBitString();
        _14356 = _53NewStringSym(_14355);
        _14355 = NOVALUE;
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 503;
        ((int *)_2)[2] = _14356;
        _14357 = MAKE_SEQ(_1);
        _14356 = NOVALUE;
        DeRef(_yytext_25248);
        DeRef(_namespaces_25249);
        DeRef(_d_25250);
        DeRef(_tok_25252);
        DeRef(_name_25255);
        DeRef(_14334);
        _14334 = NOVALUE;
        DeRef(_14339);
        _14339 = NOVALUE;
        DeRef(_14348);
        _14348 = NOVALUE;
        DeRef(_14351);
        _14351 = NOVALUE;
        DeRef(_14354);
        _14354 = NOVALUE;
        return _14357;
    ;}L9: 
L8: 

    /** 			while id_char[ch] do*/
LA: 
    _2 = (int)SEQ_PTR(_61id_char_23554);
    _14358 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14358 == 0)
    {
        _14358 = NOVALUE;
        goto LB; // [233] 248
    }
    else{
        _14358 = NOVALUE;
    }

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			end while*/
    goto LA; // [245] 227
LB: 

    /** 			yytext = ThisLine[sp-1..bp-2]*/
    _14360 = _sp_25244 - 1;
    if ((long)((unsigned long)_14360 +(unsigned long) HIGH_BITS) >= 0){
        _14360 = NewDouble((double)_14360);
    }
    _14361 = _44bp_48146 - 2;
    rhs_slice_target = (object_ptr)&_yytext_25248;
    RHS_Slice(_44ThisLine_48142, _14360, _14361);

    /** 			ungetch()*/
    _61ungetch();

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			while ch = ' ' or ch = '\t' do*/
LC: 
    _14364 = (_ch_25242 == 32);
    if (_14364 != 0) {
        goto LD; // [287] 300
    }
    _14366 = (_ch_25242 == 9);
    if (_14366 == 0)
    {
        DeRef(_14366);
        _14366 = NOVALUE;
        goto LE; // [296] 312
    }
    else{
        DeRef(_14366);
        _14366 = NOVALUE;
    }
LD: 

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			end while*/
    goto LC; // [309] 283
LE: 

    /** 			integer is_namespace*/

    /** 			if might_be_namespace then*/
    if (_61might_be_namespace_25046 == 0)
    {
        goto LF; // [318] 361
    }
    else{
    }

    /** 				tok = keyfind(yytext, -1, , -1 )*/
    RefDS(_yytext_25248);
    _31395 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, -1, _35current_file_no_15968, -1, _31395);
    DeRef(_0);
    _31395 = NOVALUE;

    /** 				is_namespace = tok[T_ID] = NAMESPACE*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14369 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_14369)) {
        _is_namespace_25314 = (_14369 == 523);
    }
    else {
        _is_namespace_25314 = binary_op(EQUALS, _14369, 523);
    }
    _14369 = NOVALUE;
    if (!IS_ATOM_INT(_is_namespace_25314)) {
        _1 = (long)(DBL_PTR(_is_namespace_25314)->dbl);
        DeRefDS(_is_namespace_25314);
        _is_namespace_25314 = _1;
    }

    /** 				might_be_namespace = 0*/
    _61might_be_namespace_25046 = 0;
    goto L10; // [358] 384
LF: 

    /** 				is_namespace = ch = ':'*/
    _is_namespace_25314 = (_ch_25242 == 58);

    /** 				tok = keyfind(yytext, -1, , is_namespace )*/
    RefDS(_yytext_25248);
    _31394 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, -1, _35current_file_no_15968, _is_namespace_25314, _31394);
    DeRef(_0);
    _31394 = NOVALUE;
L10: 

    /** 			if not is_namespace then*/
    if (_is_namespace_25314 != 0)
    goto L11; // [388] 396

    /** 				ungetch()*/
    _61ungetch();
L11: 

    /** 			if is_namespace then*/
    if (_is_namespace_25314 == 0)
    {
        goto L12; // [398] 1119
    }
    else{
    }

    /** 				namespaces = yytext*/
    RefDS(_yytext_25248);
    DeRef(_namespaces_25249);
    _namespaces_25249 = _yytext_25248;

    /** 				if tok[T_ID] = NAMESPACE then -- known namespace*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14374 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14374, 523)){
        _14374 = NOVALUE;
        goto L13; // [420] 974
    }
    _14374 = NOVALUE;

    /** 					set_qualified_fwd( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14376 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_14376)){
        _14377 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14376)->dbl));
    }
    else{
        _14377 = (int)*(((s1_ptr)_2)->base + _14376);
    }
    _2 = (int)SEQ_PTR(_14377);
    _14378 = (int)*(((s1_ptr)_2)->base + 1);
    _14377 = NOVALUE;
    Ref(_14378);
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25341);
    _fwd_inlined_set_qualified_fwd_at_441_25341 = _14378;
    _14378 = NOVALUE;
    if (!IS_ATOM_INT(_fwd_inlined_set_qualified_fwd_at_441_25341)) {
        _1 = (long)(DBL_PTR(_fwd_inlined_set_qualified_fwd_at_441_25341)->dbl);
        DeRefDS(_fwd_inlined_set_qualified_fwd_at_441_25341);
        _fwd_inlined_set_qualified_fwd_at_441_25341 = _1;
    }

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23578 = _fwd_inlined_set_qualified_fwd_at_441_25341;

    /** end procedure*/
    goto L14; // [456] 459
L14: 
    DeRef(_fwd_inlined_set_qualified_fwd_at_441_25341);
    _fwd_inlined_set_qualified_fwd_at_441_25341 = NOVALUE;

    /** 					ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 					while ch = ' ' or ch = '\t' do*/
L15: 
    _14380 = (_ch_25242 == 32);
    if (_14380 != 0) {
        goto L16; // [477] 490
    }
    _14382 = (_ch_25242 == 9);
    if (_14382 == 0)
    {
        DeRef(_14382);
        _14382 = NOVALUE;
        goto L17; // [486] 502
    }
    else{
        DeRef(_14382);
        _14382 = NOVALUE;
    }
L16: 

    /** 						ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 					end while*/
    goto L15; // [499] 473
L17: 

    /** 					yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25248);
    _yytext_25248 = _5;

    /** 					if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14384 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    _14385 = (_14384 == -2);
    _14384 = NOVALUE;
    if (_14385 != 0) {
        goto L18; // [523] 536
    }
    _14387 = (_ch_25242 == 95);
    if (_14387 == 0)
    {
        DeRef(_14387);
        _14387 = NOVALUE;
        goto L19; // [532] 589
    }
    else{
        DeRef(_14387);
        _14387 = NOVALUE;
    }
L18: 

    /** 						yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 						ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 						while id_char[ch] = TRUE do*/
L1A: 
    _2 = (int)SEQ_PTR(_61id_char_23554);
    _14390 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14390 != _13TRUE_437)
    goto L1B; // [562] 584

    /** 							yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 							ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 						end while*/
    goto L1A; // [581] 554
L1B: 

    /** 						ungetch()*/
    _61ungetch();
L19: 

    /** 					if length(yytext) = 0 then*/
    if (IS_SEQUENCE(_yytext_25248)){
            _14394 = SEQ_PTR(_yytext_25248)->length;
    }
    else {
        _14394 = 1;
    }
    if (_14394 != 0)
    goto L1C; // [594] 606

    /** 						CompileErr(32)*/
    RefDS(_21815);
    _44CompileErr(32, _21815, 0);
L1C: 

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16073 != 1)
    goto L1D; // [612] 773

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25248);
    Append(&_35Recorded_16074, _35Recorded_16074, _yytext_25248);

    /** 		                Ns_recorded = append(Ns_recorded,namespaces)*/
    RefDS(_namespaces_25249);
    Append(&_35Ns_recorded_16075, _35Ns_recorded_16075, _namespaces_25249);

    /** 		                Ns_recorded_sym &= tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14399 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Ns_recorded_sym_16077) && IS_ATOM(_14399)) {
        Ref(_14399);
        Append(&_35Ns_recorded_sym_16077, _35Ns_recorded_sym_16077, _14399);
    }
    else if (IS_ATOM(_35Ns_recorded_sym_16077) && IS_SEQUENCE(_14399)) {
    }
    else {
        Concat((object_ptr)&_35Ns_recorded_sym_16077, _35Ns_recorded_sym_16077, _14399);
    }
    _14399 = NOVALUE;

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25245 = _53No_new_entry_46887;

    /** 						No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14401 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_14401)){
        _14402 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14401)->dbl));
    }
    else{
        _14402 = (int)*(((s1_ptr)_2)->base + _14401);
    }
    _2 = (int)SEQ_PTR(_14402);
    _14403 = (int)*(((s1_ptr)_2)->base + 1);
    _14402 = NOVALUE;
    RefDS(_yytext_25248);
    _31393 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    Ref(_14403);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, _14403, _35current_file_no_15968, 0, _31393);
    DeRef(_0);
    _14403 = NOVALUE;
    _31393 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14405 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14405, 509)){
        _14405 = NOVALUE;
        goto L1E; // [712] 729
    }
    _14405 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, 0);
    goto L1F; // [726] 746
L1E: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14408 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16076) && IS_ATOM(_14408)) {
        Ref(_14408);
        Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, _14408);
    }
    else if (IS_ATOM(_35Recorded_sym_16076) && IS_SEQUENCE(_14408)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16076, _35Recorded_sym_16076, _14408);
    }
    _14408 = NOVALUE;
L1F: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_46887 = _prev_Nne_25245;

    /** 		                return {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16074)){
            _14410 = SEQ_PTR(_35Recorded_16074)->length;
    }
    else {
        _14410 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14410;
    _14411 = MAKE_SEQ(_1);
    _14410 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    _14401 = NOVALUE;
    return _14411;
    goto L20; // [770] 915
L1D: 

    /** 						tok = keyfind(yytext, SymTab[tok[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14412 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_14412)){
        _14413 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14412)->dbl));
    }
    else{
        _14413 = (int)*(((s1_ptr)_2)->base + _14412);
    }
    _2 = (int)SEQ_PTR(_14413);
    _14414 = (int)*(((s1_ptr)_2)->base + 1);
    _14413 = NOVALUE;
    RefDS(_yytext_25248);
    _31392 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    Ref(_14414);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, _14414, _35current_file_no_15968, 0, _31392);
    DeRef(_0);
    _14414 = NOVALUE;
    _31392 = NOVALUE;

    /** 						if tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14416 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14416, -100)){
        _14416 = NOVALUE;
        goto L21; // [817] 834
    }
    _14416 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_VARIABLE*/
    _2 = (int)SEQ_PTR(_tok_25252);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25252 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 512;
    DeRef(_1);
    goto L22; // [831] 914
L21: 

    /** 						elsif tok[T_ID] = FUNC then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14418 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14418, 501)){
        _14418 = NOVALUE;
        goto L23; // [844] 861
    }
    _14418 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_FUNC*/
    _2 = (int)SEQ_PTR(_tok_25252);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25252 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 520;
    DeRef(_1);
    goto L22; // [858] 914
L23: 

    /** 						elsif tok[T_ID] = PROC then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14420 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14420, 27)){
        _14420 = NOVALUE;
        goto L24; // [871] 888
    }
    _14420 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_PROC*/
    _2 = (int)SEQ_PTR(_tok_25252);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25252 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 521;
    DeRef(_1);
    goto L22; // [885] 914
L24: 

    /** 						elsif tok[T_ID] = TYPE then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14422 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14422, 504)){
        _14422 = NOVALUE;
        goto L25; // [898] 913
    }
    _14422 = NOVALUE;

    /** 							tok[T_ID] = QUALIFIED_TYPE*/
    _2 = (int)SEQ_PTR(_tok_25252);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_25252 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 522;
    DeRef(_1);
L25: 
L22: 
L20: 

    /** 					if atom( tok[T_SYM] ) and  SymTab[tok[T_SYM]][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14424 = (int)*(((s1_ptr)_2)->base + 2);
    _14425 = IS_ATOM(_14424);
    _14424 = NOVALUE;
    if (_14425 == 0) {
        goto L26; // [926] 1269
    }
    _2 = (int)SEQ_PTR(_tok_25252);
    _14427 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!IS_ATOM_INT(_14427)){
        _14428 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14427)->dbl));
    }
    else{
        _14428 = (int)*(((s1_ptr)_2)->base + _14427);
    }
    _2 = (int)SEQ_PTR(_14428);
    _14429 = (int)*(((s1_ptr)_2)->base + 4);
    _14428 = NOVALUE;
    if (IS_ATOM_INT(_14429)) {
        _14430 = (_14429 != 9);
    }
    else {
        _14430 = binary_op(NOTEQ, _14429, 9);
    }
    _14429 = NOVALUE;
    if (_14430 == 0) {
        DeRef(_14430);
        _14430 = NOVALUE;
        goto L26; // [955] 1269
    }
    else {
        if (!IS_ATOM_INT(_14430) && DBL_PTR(_14430)->dbl == 0.0){
            DeRef(_14430);
            _14430 = NOVALUE;
            goto L26; // [955] 1269
        }
        DeRef(_14430);
        _14430 = NOVALUE;
    }
    DeRef(_14430);
    _14430 = NOVALUE;

    /** 						set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23578 = -1;

    /** end procedure*/
    goto L26; // [967] 1269
    goto L26; // [971] 1269
L13: 

    /** 					ungetch()*/
    _61ungetch();

    /** 				    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16073 != 1)
    goto L26; // [984] 1269

    /** 		                Ns_recorded &= 0*/
    Append(&_35Ns_recorded_16075, _35Ns_recorded_16075, 0);

    /** 		                Ns_recorded_sym &= 0*/
    Append(&_35Ns_recorded_sym_16077, _35Ns_recorded_sym_16077, 0);

    /** 		                Recorded = append(Recorded,yytext)*/
    RefDS(_yytext_25248);
    Append(&_35Recorded_16074, _35Recorded_16074, _yytext_25248);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25245 = _53No_new_entry_46887;

    /** 						No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25248);
    _31391 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, -1, _35current_file_no_15968, 0, _31391);
    DeRef(_0);
    _31391 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14436 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14436, 509)){
        _14436 = NOVALUE;
        goto L27; // [1060] 1077
    }
    _14436 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, 0);
    goto L28; // [1074] 1094
L27: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14439 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16076) && IS_ATOM(_14439)) {
        Ref(_14439);
        Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, _14439);
    }
    else if (IS_ATOM(_35Recorded_sym_16076) && IS_SEQUENCE(_14439)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16076, _35Recorded_sym_16076, _14439);
    }
    _14439 = NOVALUE;
L28: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_46887 = _prev_Nne_25245;

    /** 		                tok = {RECORDED,length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16074)){
            _14441 = SEQ_PTR(_35Recorded_16074)->length;
    }
    else {
        _14441 = 1;
    }
    DeRef(_tok_25252);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14441;
    _tok_25252 = MAKE_SEQ(_1);
    _14441 = NOVALUE;
    goto L26; // [1116] 1269
L12: 

    /** 				set_qualified_fwd( -1 )*/

    /** 	qualified_fwd = fwd*/
    _61qualified_fwd_23578 = -1;

    /** end procedure*/
    goto L29; // [1128] 1131
L29: 

    /** 			    if Parser_mode = PAM_RECORD then*/
    if (_35Parser_mode_16073 != 1)
    goto L2A; // [1137] 1268

    /** 	                Ns_recorded_sym &= 0*/
    Append(&_35Ns_recorded_sym_16077, _35Ns_recorded_sym_16077, 0);

    /** 						Recorded = append(Recorded, yytext)*/
    RefDS(_yytext_25248);
    Append(&_35Recorded_16074, _35Recorded_16074, _yytext_25248);

    /** 		                Ns_recorded &= 0*/
    Append(&_35Ns_recorded_16075, _35Ns_recorded_16075, 0);

    /** 		                prev_Nne = No_new_entry*/
    _prev_Nne_25245 = _53No_new_entry_46887;

    /** 						No_new_entry = 1*/
    _53No_new_entry_46887 = 1;

    /** 						tok = keyfind(yytext, -1)*/
    RefDS(_yytext_25248);
    _31390 = _53hashfn(_yytext_25248);
    RefDS(_yytext_25248);
    _0 = _tok_25252;
    _tok_25252 = _53keyfind(_yytext_25248, -1, _35current_file_no_15968, 0, _31390);
    DeRef(_0);
    _31390 = NOVALUE;

    /** 						if tok[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14448 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14448, 509)){
        _14448 = NOVALUE;
        goto L2B; // [1213] 1230
    }
    _14448 = NOVALUE;

    /** 							Recorded_sym &= 0 -- must resolve on call site*/
    Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, 0);
    goto L2C; // [1227] 1247
L2B: 

    /** 							Recorded_sym &= tok[T_SYM] -- fallback when symbol is undefined on call site*/
    _2 = (int)SEQ_PTR(_tok_25252);
    _14451 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_35Recorded_sym_16076) && IS_ATOM(_14451)) {
        Ref(_14451);
        Append(&_35Recorded_sym_16076, _35Recorded_sym_16076, _14451);
    }
    else if (IS_ATOM(_35Recorded_sym_16076) && IS_SEQUENCE(_14451)) {
    }
    else {
        Concat((object_ptr)&_35Recorded_sym_16076, _35Recorded_sym_16076, _14451);
    }
    _14451 = NOVALUE;
L2C: 

    /** 		                No_new_entry = prev_Nne*/
    _53No_new_entry_46887 = _prev_Nne_25245;

    /** 	                tok = {RECORDED, length(Recorded)}*/
    if (IS_SEQUENCE(_35Recorded_16074)){
            _14453 = SEQ_PTR(_35Recorded_16074)->length;
    }
    else {
        _14453 = 1;
    }
    DeRef(_tok_25252);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _14453;
    _tok_25252 = MAKE_SEQ(_1);
    _14453 = NOVALUE;
L2A: 
L26: 

    /** 			return tok*/
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_name_25255);
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14412 = NOVALUE;
    _14427 = NOVALUE;
    return _tok_25252;
    goto L1; // [1279] 10
L7: 

    /** 		elsif class < ILLEGAL_CHAR then*/
    if (_class_25254 >= -20)
    goto L2D; // [1286] 1303

    /** 			return {class, 0}  -- brackets, punctuation, eof, illegal char etc.*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25254;
    ((int *)_2)[2] = 0;
    _14456 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14412 = NOVALUE;
    _14427 = NOVALUE;
    return _14456;
    goto L1; // [1300] 10
L2D: 

    /** 		elsif class = ILLEGAL_CHAR then*/
    if (_class_25254 != -20)
    goto L2E; // [1307] 1321

    /** 			CompileErr(101)*/
    RefDS(_21815);
    _44CompileErr(101, _21815, 0);
    goto L1; // [1318] 10
L2E: 

    /** 		elsif class = NEWLINE then*/
    if (_class_25254 != -6)
    goto L2F; // [1325] 1351

    /** 			if start_include then*/
    if (_61start_include_23546 == 0)
    {
        goto L30; // [1333] 1343
    }
    else{
    }

    /** 				IncludePush()*/
    _61IncludePush();
    goto L1; // [1340] 10
L30: 

    /** 				read_line()*/
    _61read_line();
    goto L1; // [1348] 10
L2F: 

    /** 		elsif class = EQUALS then*/
    if (_class_25254 != 3)
    goto L31; // [1355] 1372

    /** 			return {class, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _class_25254;
    ((int *)_2)[2] = 0;
    _14460 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14412 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    return _14460;
    goto L1; // [1369] 10
L31: 

    /** 		elsif class = DOT or class = DIGIT then*/
    _14461 = (_class_25254 == -3);
    if (_14461 != 0) {
        goto L32; // [1380] 1395
    }
    _14463 = (_class_25254 == -7);
    if (_14463 == 0)
    {
        DeRef(_14463);
        _14463 = NOVALUE;
        goto L33; // [1391] 2196
    }
    else{
        DeRef(_14463);
        _14463 = NOVALUE;
    }
L32: 

    /** 			integer basetype*/

    /** 			if class = DOT then*/
    if (_class_25254 != -3)
    goto L34; // [1401] 1435

    /** 				if getch() = '.' then*/
    _14465 = _61getch();
    if (binary_op_a(NOTEQ, _14465, 46)){
        DeRef(_14465);
        _14465 = NOVALUE;
        goto L35; // [1410] 1429
    }
    DeRef(_14465);
    _14465 = NOVALUE;

    /** 					return {SLICE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 513;
    ((int *)_2)[2] = 0;
    _14467 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14412 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    return _14467;
    goto L36; // [1426] 1434
L35: 

    /** 					ungetch()*/
    _61ungetch();
L36: 
L34: 

    /** 			yytext = {ch}*/
    _0 = _yytext_25248;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25242;
    _yytext_25248 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 			is_int = (ch != '.')*/
    _is_int_25253 = (_ch_25242 != 46);

    /** 			basetype = -1 -- default is decimal*/
    _basetype_25548 = -1;

    /** 			while 1 with entry do*/
    goto L37; // [1454] 1645
L38: 

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14470 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14470 != -7)
    goto L39; // [1467] 1480

    /** 					yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);
    goto L3A; // [1477] 1642
L39: 

    /** 				elsif equal(yytext, "0") then*/
    if (_yytext_25248 == _14123)
    _14473 = 1;
    else if (IS_ATOM_INT(_yytext_25248) && IS_ATOM_INT(_14123))
    _14473 = 0;
    else
    _14473 = (compare(_yytext_25248, _14123) == 0);
    if (_14473 == 0)
    {
        _14473 = NOVALUE;
        goto L3B; // [1486] 1581
    }
    else{
        _14473 = NOVALUE;
    }

    /** 					basetype = find(ch, nbasecode)*/
    _basetype_25548 = find_from(_ch_25242, _61nbasecode_25050, 1);

    /** 					if basetype > length(nbase) then*/
    if (IS_SEQUENCE(_61nbase_25049)){
            _14475 = SEQ_PTR(_61nbase_25049)->length;
    }
    else {
        _14475 = 1;
    }
    if (_basetype_25548 <= _14475)
    goto L3C; // [1501] 1515

    /** 						basetype -= length(nbase)*/
    if (IS_SEQUENCE(_61nbase_25049)){
            _14477 = SEQ_PTR(_61nbase_25049)->length;
    }
    else {
        _14477 = 1;
    }
    _basetype_25548 = _basetype_25548 - _14477;
    _14477 = NOVALUE;
L3C: 

    /** 					if basetype = 0 then*/
    if (_basetype_25548 != 0)
    goto L3D; // [1517] 1572

    /** 						if char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14480 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14480 != -2)
    goto L3E; // [1531] 1562

    /** 							if ch != 'e' and ch != 'E' then*/
    _14482 = (_ch_25242 != 101);
    if (_14482 == 0) {
        goto L3F; // [1541] 1561
    }
    _14484 = (_ch_25242 != 69);
    if (_14484 == 0)
    {
        DeRef(_14484);
        _14484 = NOVALUE;
        goto L3F; // [1550] 1561
    }
    else{
        DeRef(_14484);
        _14484 = NOVALUE;
    }

    /** 								CompileErr(105, ch)*/
    _44CompileErr(105, _ch_25242, 0);
L3F: 
L3E: 

    /** 						basetype = -1 -- decimal*/
    _basetype_25548 = -1;

    /** 						exit*/
    goto L40; // [1569] 1657
L3D: 

    /** 					yytext &= '0'*/
    Append(&_yytext_25248, _yytext_25248, 48);
    goto L3A; // [1578] 1642
L3B: 

    /** 				elsif basetype = 4 then -- hexadecimal*/
    if (_basetype_25548 != 4)
    goto L40; // [1583] 1657

    /** 					integer hdigit*/

    /** 					hdigit = find(ch, "ABCDEFabcdef")*/
    _hdigit_25588 = find_from(_ch_25242, _14487, 1);

    /** 					if hdigit = 0 then*/
    if (_hdigit_25588 != 0)
    goto L41; // [1598] 1609

    /** 						exit*/
    goto L40; // [1606] 1657
L41: 

    /** 					if hdigit > 6 then*/
    if (_hdigit_25588 <= 6)
    goto L42; // [1611] 1622

    /** 						hdigit -= 6*/
    _hdigit_25588 = _hdigit_25588 - 6;
L42: 

    /** 					yytext &= hexasc[hdigit]*/
    _2 = (int)SEQ_PTR(_61hexasc_25052);
    _14492 = (int)*(((s1_ptr)_2)->base + _hdigit_25588);
    if (IS_SEQUENCE(_yytext_25248) && IS_ATOM(_14492)) {
        Ref(_14492);
        Append(&_yytext_25248, _yytext_25248, _14492);
    }
    else if (IS_ATOM(_yytext_25248) && IS_SEQUENCE(_14492)) {
    }
    else {
        Concat((object_ptr)&_yytext_25248, _yytext_25248, _14492);
    }
    _14492 = NOVALUE;
    goto L3A; // [1634] 1642

    /** 					exit*/
    goto L40; // [1639] 1657
L3A: 

    /** 			entry*/
L37: 

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			end while*/
    goto L38; // [1654] 1457
L40: 

    /** 			if ch = '.' then*/
    if (_ch_25242 != 46)
    goto L43; // [1659] 1794

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 				if ch = '.' then*/
    if (_ch_25242 != 46)
    goto L44; // [1672] 1683

    /** 					ungetch()*/
    _61ungetch();
    goto L45; // [1680] 1793
L44: 

    /** 					is_int = FALSE*/
    _is_int_25253 = _13FALSE_435;

    /** 					if yytext[1] = '.' then*/
    _2 = (int)SEQ_PTR(_yytext_25248);
    _14498 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _14498, 46)){
        _14498 = NOVALUE;
        goto L46; // [1698] 1712
    }
    _14498 = NOVALUE;

    /** 						CompileErr(124)*/
    RefDS(_21815);
    _44CompileErr(124, _21815, 0);
    goto L47; // [1709] 1719
L46: 

    /** 						yytext &= '.'*/
    Append(&_yytext_25248, _yytext_25248, 46);
L47: 

    /** 					if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14501 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14501 != -7)
    goto L48; // [1729] 1784

    /** 						yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 						ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 						while char_class[ch] = DIGIT do*/
L49: 
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14505 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14505 != -7)
    goto L4A; // [1759] 1792

    /** 							yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 							ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 						end while*/
    goto L49; // [1778] 1751
    goto L4A; // [1781] 1792
L48: 

    /** 						CompileErr(94)*/
    RefDS(_21815);
    _44CompileErr(94, _21815, 0);
L4A: 
L45: 
L43: 

    /** 			if basetype = -1 and find(ch, "eE") then*/
    _14509 = (_basetype_25548 == -1);
    if (_14509 == 0) {
        goto L4B; // [1800] 1936
    }
    _14512 = find_from(_ch_25242, _14511, 1);
    if (_14512 == 0)
    {
        _14512 = NOVALUE;
        goto L4B; // [1810] 1936
    }
    else{
        _14512 = NOVALUE;
    }

    /** 				is_int = FALSE*/
    _is_int_25253 = _13FALSE_435;

    /** 				yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 				if ch = '-' or ch = '+' or char_class[ch] = DIGIT then*/
    _14515 = (_ch_25242 == 45);
    if (_14515 != 0) {
        _14516 = 1;
        goto L4C; // [1841] 1853
    }
    _14517 = (_ch_25242 == 43);
    _14516 = (_14517 != 0);
L4C: 
    if (_14516 != 0) {
        goto L4D; // [1853] 1874
    }
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14519 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    _14520 = (_14519 == -7);
    _14519 = NOVALUE;
    if (_14520 == 0)
    {
        DeRef(_14520);
        _14520 = NOVALUE;
        goto L4E; // [1870] 1883
    }
    else{
        DeRef(_14520);
        _14520 = NOVALUE;
    }
L4D: 

    /** 					yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);
    goto L4F; // [1880] 1891
L4E: 

    /** 					CompileErr(86)*/
    RefDS(_21815);
    _44CompileErr(86, _21815, 0);
L4F: 

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 				while char_class[ch] = DIGIT do*/
L50: 
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14523 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14523 != -7)
    goto L51; // [1911] 1967

    /** 					yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);

    /** 					ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 				end while*/
    goto L50; // [1930] 1903
    goto L51; // [1933] 1967
L4B: 

    /** 			elsif char_class[ch] = LETTER then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14527 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14527 != -2)
    goto L52; // [1946] 1966

    /** 				CompileErr(127, {{ch}})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_25242;
    _14529 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _14529;
    _14530 = MAKE_SEQ(_1);
    _14529 = NOVALUE;
    _44CompileErr(127, _14530, 0);
    _14530 = NOVALUE;
L52: 
L51: 

    /** 			ungetch()*/
    _61ungetch();

    /** 			while i != 0 with entry do*/
    goto L53; // [1973] 2012
L54: 
    if (_i_25243 == 0)
    goto L55; // [1978] 2024

    /** 			    yytext = yytext[1 .. i-1] & yytext[i+1 .. $]*/
    _14532 = _i_25243 - 1;
    rhs_slice_target = (object_ptr)&_14533;
    RHS_Slice(_yytext_25248, 1, _14532);
    _14534 = _i_25243 + 1;
    if (_14534 > MAXINT){
        _14534 = NewDouble((double)_14534);
    }
    if (IS_SEQUENCE(_yytext_25248)){
            _14535 = SEQ_PTR(_yytext_25248)->length;
    }
    else {
        _14535 = 1;
    }
    rhs_slice_target = (object_ptr)&_14536;
    RHS_Slice(_yytext_25248, _14534, _14535);
    Concat((object_ptr)&_yytext_25248, _14533, _14536);
    DeRefDS(_14533);
    _14533 = NOVALUE;
    DeRef(_14533);
    _14533 = NOVALUE;
    DeRefDS(_14536);
    _14536 = NOVALUE;

    /** 			  entry*/
L53: 

    /** 			    i = find('_', yytext)*/
    _i_25243 = find_from(95, _yytext_25248, 1);

    /** 			end while*/
    goto L54; // [2021] 1976
L55: 

    /** 			if is_int then*/
    if (_is_int_25253 == 0)
    {
        goto L56; // [2026] 2097
    }
    else{
    }

    /** 				if basetype = -1 then*/
    if (_basetype_25548 != -1)
    goto L57; // [2031] 2041

    /** 					basetype = 3 -- decimal*/
    _basetype_25548 = 3;
L57: 

    /** 				d = MakeInt(yytext, nbase[basetype])*/
    _2 = (int)SEQ_PTR(_61nbase_25049);
    _14540 = (int)*(((s1_ptr)_2)->base + _basetype_25548);
    RefDS(_yytext_25248);
    Ref(_14540);
    _0 = _d_25250;
    _d_25250 = _61MakeInt(_yytext_25248, _14540);
    DeRef(_0);
    _14540 = NOVALUE;

    /** 				if integer(d) then*/
    if (IS_ATOM_INT(_d_25250))
    _14542 = 1;
    else if (IS_ATOM_DBL(_d_25250))
    _14542 = IS_ATOM_INT(DoubleToInt(_d_25250));
    else
    _14542 = 0;
    if (_14542 == 0)
    {
        _14542 = NOVALUE;
        goto L58; // [2057] 2079
    }
    else{
        _14542 = NOVALUE;
    }

    /** 					return {ATOM, NewIntSym(d)}*/
    Ref(_d_25250);
    _14543 = _53NewIntSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14543;
    _14544 = MAKE_SEQ(_1);
    _14543 = NOVALUE;
    DeRefDS(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14544;
    goto L59; // [2076] 2096
L58: 

    /** 					return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25250);
    _14545 = _53NewDoubleSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14545;
    _14546 = MAKE_SEQ(_1);
    _14545 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14546;
L59: 
L56: 

    /** 			if basetype != -1 then*/
    if (_basetype_25548 == -1)
    goto L5A; // [2099] 2115

    /** 				CompileErr(125, nbasecode[basetype])*/
    _2 = (int)SEQ_PTR(_61nbasecode_25050);
    _14548 = (int)*(((s1_ptr)_2)->base + _basetype_25548);
    Ref(_14548);
    _44CompileErr(125, _14548, 0);
    _14548 = NOVALUE;
L5A: 

    /** 			d = my_sscanf(yytext)*/
    RefDS(_yytext_25248);
    _0 = _d_25250;
    _d_25250 = _61my_sscanf(_yytext_25248);
    DeRef(_0);

    /** 			if sequence(d) then*/
    _14550 = IS_SEQUENCE(_d_25250);
    if (_14550 == 0)
    {
        _14550 = NOVALUE;
        goto L5B; // [2126] 2139
    }
    else{
        _14550 = NOVALUE;
    }

    /** 				CompileErr(121)*/
    RefDS(_21815);
    _44CompileErr(121, _21815, 0);
    goto L5C; // [2136] 2191
L5B: 

    /** 			elsif is_int and d <= MAXINT_DBL then*/
    if (_is_int_25253 == 0) {
        goto L5D; // [2141] 2174
    }
    if (IS_ATOM_INT(_d_25250)) {
        _14552 = (_d_25250 <= 1073741823);
    }
    else {
        _14552 = binary_op(LESSEQ, _d_25250, 1073741823);
    }
    if (_14552 == 0) {
        DeRef(_14552);
        _14552 = NOVALUE;
        goto L5D; // [2152] 2174
    }
    else {
        if (!IS_ATOM_INT(_14552) && DBL_PTR(_14552)->dbl == 0.0){
            DeRef(_14552);
            _14552 = NOVALUE;
            goto L5D; // [2152] 2174
        }
        DeRef(_14552);
        _14552 = NOVALUE;
    }
    DeRef(_14552);
    _14552 = NOVALUE;

    /** 				return {ATOM, NewIntSym(d)}  -- 1 to 1.07 billion*/
    Ref(_d_25250);
    _14553 = _53NewIntSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14553;
    _14554 = MAKE_SEQ(_1);
    _14553 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14554;
    goto L5C; // [2171] 2191
L5D: 

    /** 				return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25250);
    _14555 = _53NewDoubleSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14555;
    _14556 = MAKE_SEQ(_1);
    _14555 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14556;
L5C: 
    goto L1; // [2193] 10
L33: 

    /** 		elsif class = MINUS then*/
    if (_class_25254 != 10)
    goto L5E; // [2200] 2286

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_25242 != 45)
    goto L5F; // [2213] 2239

    /** 				if start_include then*/
    if (_61start_include_23546 == 0)
    {
        goto L60; // [2221] 2231
    }
    else{
    }

    /** 					IncludePush()*/
    _61IncludePush();
    goto L1; // [2228] 10
L60: 

    /** 					read_line()*/
    _61read_line();
    goto L1; // [2236] 10
L5F: 

    /** 			elsif ch = '=' then*/
    if (_ch_25242 != 61)
    goto L61; // [2241] 2260

    /** 				return {MINUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 516;
    ((int *)_2)[2] = 0;
    _14561 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14561;
    goto L1; // [2257] 10
L61: 

    /** 				bp -= 1*/
    _44bp_48146 = _44bp_48146 - 1;

    /** 				return {MINUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 0;
    _14563 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14563;
    goto L1; // [2283] 10
L5E: 

    /** 		elsif class = DOUBLE_QUOTE then*/
    if (_class_25254 != -4)
    goto L62; // [2290] 2484

    /** 			integer fch*/

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '"' then*/
    if (_ch_25242 != 34)
    goto L63; // [2305] 2341

    /** 				fch = getch()*/
    _fch_25726 = _61getch();
    if (!IS_ATOM_INT(_fch_25726)) {
        _1 = (long)(DBL_PTR(_fch_25726)->dbl);
        DeRefDS(_fch_25726);
        _fch_25726 = _1;
    }

    /** 				if fch = '"' then*/
    if (_fch_25726 != 34)
    goto L64; // [2318] 2335

    /** 					return ExtendedString( fch )*/
    _14569 = _61ExtendedString(_fch_25726);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14569;
    goto L65; // [2332] 2340
L64: 

    /** 					ungetch()*/
    _61ungetch();
L65: 
L63: 

    /** 			yytext = ""*/
    RefDS(_5);
    DeRef(_yytext_25248);
    _yytext_25248 = _5;

    /** 			while ch != '\n' and ch != '\r' do -- can't be EOF*/
L66: 
    _14570 = (_ch_25242 != 10);
    if (_14570 == 0) {
        goto L67; // [2357] 2436
    }
    _14572 = (_ch_25242 != 13);
    if (_14572 == 0)
    {
        DeRef(_14572);
        _14572 = NOVALUE;
        goto L67; // [2366] 2436
    }
    else{
        DeRef(_14572);
        _14572 = NOVALUE;
    }

    /** 				if ch = '"' then*/
    if (_ch_25242 != 34)
    goto L68; // [2371] 2382

    /** 					exit*/
    goto L67; // [2377] 2436
    goto L69; // [2379] 2424
L68: 

    /** 				elsif ch = '\\' then*/
    if (_ch_25242 != 92)
    goto L6A; // [2384] 2401

    /** 					yytext &= EscapeChar('"')*/
    _14575 = _61EscapeChar(34);
    if (IS_SEQUENCE(_yytext_25248) && IS_ATOM(_14575)) {
        Ref(_14575);
        Append(&_yytext_25248, _yytext_25248, _14575);
    }
    else if (IS_ATOM(_yytext_25248) && IS_SEQUENCE(_14575)) {
    }
    else {
        Concat((object_ptr)&_yytext_25248, _yytext_25248, _14575);
    }
    DeRef(_14575);
    _14575 = NOVALUE;
    goto L69; // [2398] 2424
L6A: 

    /** 				elsif ch = '\t' then*/
    if (_ch_25242 != 9)
    goto L6B; // [2403] 2417

    /** 					CompileErr(145)*/
    RefDS(_21815);
    _44CompileErr(145, _21815, 0);
    goto L69; // [2414] 2424
L6B: 

    /** 					yytext &= ch*/
    Append(&_yytext_25248, _yytext_25248, _ch_25242);
L69: 

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			end while*/
    goto L66; // [2433] 2353
L67: 

    /** 			if ch = '\n' or ch = '\r' then*/
    _14580 = (_ch_25242 == 10);
    if (_14580 != 0) {
        goto L6C; // [2442] 2455
    }
    _14582 = (_ch_25242 == 13);
    if (_14582 == 0)
    {
        DeRef(_14582);
        _14582 = NOVALUE;
        goto L6D; // [2451] 2463
    }
    else{
        DeRef(_14582);
        _14582 = NOVALUE;
    }
L6C: 

    /** 				CompileErr(67)*/
    RefDS(_21815);
    _44CompileErr(67, _21815, 0);
L6D: 

    /** 			return {STRING, NewStringSym(yytext)}*/
    RefDS(_yytext_25248);
    _14583 = _53NewStringSym(_yytext_25248);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 503;
    ((int *)_2)[2] = _14583;
    _14584 = MAKE_SEQ(_1);
    _14583 = NOVALUE;
    DeRefDS(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14584;
    goto L1; // [2481] 10
L62: 

    /** 		elsif class = PLUS then*/
    if (_class_25254 != 11)
    goto L6E; // [2488] 2540

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25242 != 61)
    goto L6F; // [2501] 2520

    /** 				return {PLUS_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 515;
    ((int *)_2)[2] = 0;
    _14588 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14588;
    goto L1; // [2517] 10
L6F: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {PLUS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 11;
    ((int *)_2)[2] = 0;
    _14589 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14589;
    goto L1; // [2537] 10
L6E: 

    /** 		elsif class = res:CONCAT then*/
    if (_class_25254 != 15)
    goto L70; // [2542] 2592

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25242 != 61)
    goto L71; // [2555] 2574

    /** 				return {CONCAT_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 0;
    _14593 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14593;
    goto L1; // [2571] 10
L71: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:CONCAT, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 15;
    ((int *)_2)[2] = 0;
    _14594 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14594;
    goto L1; // [2589] 10
L70: 

    /** 		elsif class = NUMBER_SIGN then*/
    if (_class_25254 != -11)
    goto L72; // [2596] 3114

    /** 			i = 0*/
    _i_25243 = 0;

    /** 			is_int = -1*/
    _is_int_25253 = -1;

    /** 			while i < MAXINT/32 do*/
L73: 
    _14596 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(GREATEREQ, _i_25243, _14596)){
        DeRef(_14596);
        _14596 = NOVALUE;
        goto L74; // [2621] 2791
    }
    DeRef(_14596);
    _14596 = NOVALUE;

    /** 				ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 				if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14599 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14599 != -7)
    goto L75; // [2642] 2681

    /** 					if ch != '_' then*/
    if (_ch_25242 == 95)
    goto L73; // [2648] 2615

    /** 						i = i * 16 + ch - '0'*/
    if (_i_25243 == (short)_i_25243)
    _14602 = _i_25243 * 16;
    else
    _14602 = NewDouble(_i_25243 * (double)16);
    if (IS_ATOM_INT(_14602)) {
        _14603 = _14602 + _ch_25242;
        if ((long)((unsigned long)_14603 + (unsigned long)HIGH_BITS) >= 0) 
        _14603 = NewDouble((double)_14603);
    }
    else {
        _14603 = NewDouble(DBL_PTR(_14602)->dbl + (double)_ch_25242);
    }
    DeRef(_14602);
    _14602 = NOVALUE;
    if (IS_ATOM_INT(_14603)) {
        _i_25243 = _14603 - 48;
    }
    else {
        _i_25243 = NewDouble(DBL_PTR(_14603)->dbl - (double)48);
    }
    DeRef(_14603);
    _14603 = NOVALUE;
    if (!IS_ATOM_INT(_i_25243)) {
        _1 = (long)(DBL_PTR(_i_25243)->dbl);
        DeRefDS(_i_25243);
        _i_25243 = _1;
    }

    /** 						is_int = TRUE*/
    _is_int_25253 = _13TRUE_437;
    goto L73; // [2678] 2615
L75: 

    /** 				elsif ch >= 'A' and ch <= 'F' then*/
    _14605 = (_ch_25242 >= 65);
    if (_14605 == 0) {
        goto L76; // [2687] 2731
    }
    _14607 = (_ch_25242 <= 70);
    if (_14607 == 0)
    {
        DeRef(_14607);
        _14607 = NOVALUE;
        goto L76; // [2696] 2731
    }
    else{
        DeRef(_14607);
        _14607 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('A'-10)*/
    if (_i_25243 == (short)_i_25243)
    _14608 = _i_25243 * 16;
    else
    _14608 = NewDouble(_i_25243 * (double)16);
    if (IS_ATOM_INT(_14608)) {
        _14609 = _14608 + _ch_25242;
        if ((long)((unsigned long)_14609 + (unsigned long)HIGH_BITS) >= 0) 
        _14609 = NewDouble((double)_14609);
    }
    else {
        _14609 = NewDouble(DBL_PTR(_14608)->dbl + (double)_ch_25242);
    }
    DeRef(_14608);
    _14608 = NOVALUE;
    _14610 = 55;
    if (IS_ATOM_INT(_14609)) {
        _i_25243 = _14609 - 55;
    }
    else {
        _i_25243 = NewDouble(DBL_PTR(_14609)->dbl - (double)55);
    }
    DeRef(_14609);
    _14609 = NOVALUE;
    _14610 = NOVALUE;
    if (!IS_ATOM_INT(_i_25243)) {
        _1 = (long)(DBL_PTR(_i_25243)->dbl);
        DeRefDS(_i_25243);
        _i_25243 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25253 = _13TRUE_437;
    goto L73; // [2728] 2615
L76: 

    /** 				elsif ch >= 'a' and ch <= 'f' then*/
    _14612 = (_ch_25242 >= 97);
    if (_14612 == 0) {
        goto L74; // [2737] 2791
    }
    _14614 = (_ch_25242 <= 102);
    if (_14614 == 0)
    {
        DeRef(_14614);
        _14614 = NOVALUE;
        goto L74; // [2746] 2791
    }
    else{
        DeRef(_14614);
        _14614 = NOVALUE;
    }

    /** 					i = (i * 16) + ch - ('a'-10)*/
    if (_i_25243 == (short)_i_25243)
    _14615 = _i_25243 * 16;
    else
    _14615 = NewDouble(_i_25243 * (double)16);
    if (IS_ATOM_INT(_14615)) {
        _14616 = _14615 + _ch_25242;
        if ((long)((unsigned long)_14616 + (unsigned long)HIGH_BITS) >= 0) 
        _14616 = NewDouble((double)_14616);
    }
    else {
        _14616 = NewDouble(DBL_PTR(_14615)->dbl + (double)_ch_25242);
    }
    DeRef(_14615);
    _14615 = NOVALUE;
    _14617 = 87;
    if (IS_ATOM_INT(_14616)) {
        _i_25243 = _14616 - 87;
    }
    else {
        _i_25243 = NewDouble(DBL_PTR(_14616)->dbl - (double)87);
    }
    DeRef(_14616);
    _14616 = NOVALUE;
    _14617 = NOVALUE;
    if (!IS_ATOM_INT(_i_25243)) {
        _1 = (long)(DBL_PTR(_i_25243)->dbl);
        DeRefDS(_i_25243);
        _i_25243 = _1;
    }

    /** 					is_int = TRUE*/
    _is_int_25253 = _13TRUE_437;
    goto L73; // [2778] 2615

    /** 					exit*/
    goto L74; // [2783] 2791

    /** 			end while*/
    goto L73; // [2788] 2615
L74: 

    /** 			if is_int = -1 then*/
    if (_is_int_25253 != -1)
    goto L77; // [2793] 2856

    /** 				if ch = '!' then*/
    if (_ch_25242 != 33)
    goto L78; // [2799] 2845

    /** 					if line_number > 1 then*/
    if (_35line_number_15969 <= 1)
    goto L79; // [2807] 2819

    /** 						CompileErr(161)*/
    RefDS(_21815);
    _44CompileErr(161, _21815, 0);
L79: 

    /** 					shebang = ThisLine*/
    Ref(_44ThisLine_48142);
    DeRef(_61shebang_23551);
    _61shebang_23551 = _44ThisLine_48142;

    /** 					if start_include then*/
    if (_61start_include_23546 == 0)
    {
        goto L7A; // [2830] 2838
    }
    else{
    }

    /** 						IncludePush()*/
    _61IncludePush();
L7A: 

    /** 					read_line()*/
    _61read_line();
    goto L1; // [2842] 10
L78: 

    /** 					CompileErr(97)*/
    RefDS(_21815);
    _44CompileErr(97, _21815, 0);
    goto L1; // [2853] 10
L77: 

    /** 				if i >= MAXINT/32 then*/
    _14622 = (1073741823 % 32) ? NewDouble((double)1073741823 / 32) : (1073741823 / 32);
    if (binary_op_a(LESS, _i_25243, _14622)){
        DeRef(_14622);
        _14622 = NOVALUE;
        goto L7B; // [2864] 3035
    }
    DeRef(_14622);
    _14622 = NOVALUE;

    /** 					d = i*/
    DeRef(_d_25250);
    _d_25250 = _i_25243;

    /** 					is_int = FALSE*/
    _is_int_25253 = _13FALSE_435;

    /** 					while TRUE do*/
L7C: 
    if (_13TRUE_437 == 0)
    {
        goto L7D; // [2889] 3034
    }
    else{
    }

    /** 						ch = getch()  -- eventually END_OF_FILE_CHAR or new-line*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 						if char_class[ch] = DIGIT then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14625 = (int)*(((s1_ptr)_2)->base + _ch_25242);
    if (_14625 != -7)
    goto L7E; // [2909] 2937

    /** 							if ch != '_' then*/
    if (_ch_25242 == 95)
    goto L7C; // [2915] 2887

    /** 								d = (d * 16) + ch - '0'*/
    if (IS_ATOM_INT(_d_25250)) {
        if (_d_25250 == (short)_d_25250)
        _14628 = _d_25250 * 16;
        else
        _14628 = NewDouble(_d_25250 * (double)16);
    }
    else {
        _14628 = binary_op(MULTIPLY, _d_25250, 16);
    }
    if (IS_ATOM_INT(_14628)) {
        _14629 = _14628 + _ch_25242;
        if ((long)((unsigned long)_14629 + (unsigned long)HIGH_BITS) >= 0) 
        _14629 = NewDouble((double)_14629);
    }
    else {
        _14629 = binary_op(PLUS, _14628, _ch_25242);
    }
    DeRef(_14628);
    _14628 = NOVALUE;
    DeRef(_d_25250);
    if (IS_ATOM_INT(_14629)) {
        _d_25250 = _14629 - 48;
        if ((long)((unsigned long)_d_25250 +(unsigned long) HIGH_BITS) >= 0){
            _d_25250 = NewDouble((double)_d_25250);
        }
    }
    else {
        _d_25250 = binary_op(MINUS, _14629, 48);
    }
    DeRef(_14629);
    _14629 = NOVALUE;
    goto L7C; // [2934] 2887
L7E: 

    /** 						elsif ch >= 'A' and ch <= 'F' then*/
    _14631 = (_ch_25242 >= 65);
    if (_14631 == 0) {
        goto L7F; // [2943] 2976
    }
    _14633 = (_ch_25242 <= 70);
    if (_14633 == 0)
    {
        DeRef(_14633);
        _14633 = NOVALUE;
        goto L7F; // [2952] 2976
    }
    else{
        DeRef(_14633);
        _14633 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('A'- 10)*/
    if (IS_ATOM_INT(_d_25250)) {
        if (_d_25250 == (short)_d_25250)
        _14634 = _d_25250 * 16;
        else
        _14634 = NewDouble(_d_25250 * (double)16);
    }
    else {
        _14634 = binary_op(MULTIPLY, _d_25250, 16);
    }
    if (IS_ATOM_INT(_14634)) {
        _14635 = _14634 + _ch_25242;
        if ((long)((unsigned long)_14635 + (unsigned long)HIGH_BITS) >= 0) 
        _14635 = NewDouble((double)_14635);
    }
    else {
        _14635 = binary_op(PLUS, _14634, _ch_25242);
    }
    DeRef(_14634);
    _14634 = NOVALUE;
    _14636 = 55;
    DeRef(_d_25250);
    if (IS_ATOM_INT(_14635)) {
        _d_25250 = _14635 - 55;
        if ((long)((unsigned long)_d_25250 +(unsigned long) HIGH_BITS) >= 0){
            _d_25250 = NewDouble((double)_d_25250);
        }
    }
    else {
        _d_25250 = binary_op(MINUS, _14635, 55);
    }
    DeRef(_14635);
    _14635 = NOVALUE;
    _14636 = NOVALUE;
    goto L7C; // [2973] 2887
L7F: 

    /** 						elsif ch >= 'a' and ch <= 'f' then*/
    _14638 = (_ch_25242 >= 97);
    if (_14638 == 0) {
        goto L80; // [2982] 3015
    }
    _14640 = (_ch_25242 <= 102);
    if (_14640 == 0)
    {
        DeRef(_14640);
        _14640 = NOVALUE;
        goto L80; // [2991] 3015
    }
    else{
        DeRef(_14640);
        _14640 = NOVALUE;
    }

    /** 							d = (d * 16) + ch - ('a'-10)*/
    if (IS_ATOM_INT(_d_25250)) {
        if (_d_25250 == (short)_d_25250)
        _14641 = _d_25250 * 16;
        else
        _14641 = NewDouble(_d_25250 * (double)16);
    }
    else {
        _14641 = binary_op(MULTIPLY, _d_25250, 16);
    }
    if (IS_ATOM_INT(_14641)) {
        _14642 = _14641 + _ch_25242;
        if ((long)((unsigned long)_14642 + (unsigned long)HIGH_BITS) >= 0) 
        _14642 = NewDouble((double)_14642);
    }
    else {
        _14642 = binary_op(PLUS, _14641, _ch_25242);
    }
    DeRef(_14641);
    _14641 = NOVALUE;
    _14643 = 87;
    DeRef(_d_25250);
    if (IS_ATOM_INT(_14642)) {
        _d_25250 = _14642 - 87;
        if ((long)((unsigned long)_d_25250 +(unsigned long) HIGH_BITS) >= 0){
            _d_25250 = NewDouble((double)_d_25250);
        }
    }
    else {
        _d_25250 = binary_op(MINUS, _14642, 87);
    }
    DeRef(_14642);
    _14642 = NOVALUE;
    _14643 = NOVALUE;
    goto L7C; // [3012] 2887
L80: 

    /** 						elsif ch = '_' then*/
    if (_ch_25242 != 95)
    goto L7D; // [3017] 3034
    goto L7C; // [3021] 2887

    /** 							exit*/
    goto L7D; // [3026] 3034

    /** 					end while*/
    goto L7C; // [3031] 2887
L7D: 
L7B: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				if is_int then*/
    if (_is_int_25253 == 0)
    {
        goto L81; // [3041] 3063
    }
    else{
    }

    /** 					return {ATOM, NewIntSym(i)}*/
    _14646 = _53NewIntSym(_i_25243);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14646;
    _14647 = MAKE_SEQ(_1);
    _14646 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14647;
    goto L1; // [3060] 10
L81: 

    /** 					if d <= MAXINT_DBL then            -- d is always >= 0*/
    if (binary_op_a(GREATER, _d_25250, 1073741823)){
        goto L82; // [3069] 3092
    }

    /** 						return {ATOM, NewIntSym(d)}*/
    Ref(_d_25250);
    _14649 = _53NewIntSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14649;
    _14650 = MAKE_SEQ(_1);
    _14649 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14650;
    goto L1; // [3089] 10
L82: 

    /** 						return {ATOM, NewDoubleSym(d)}*/
    Ref(_d_25250);
    _14651 = _53NewDoubleSym(_d_25250);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14651;
    _14652 = MAKE_SEQ(_1);
    _14651 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14652;
    goto L1; // [3111] 10
L72: 

    /** 		elsif class = res:MULTIPLY then*/
    if (_class_25254 != 13)
    goto L83; // [3116] 3166

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25242 != 61)
    goto L84; // [3129] 3148

    /** 				return {MULTIPLY_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 517;
    ((int *)_2)[2] = 0;
    _14656 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14656;
    goto L1; // [3145] 10
L84: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:MULTIPLY, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 13;
    ((int *)_2)[2] = 0;
    _14657 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14657;
    goto L1; // [3163] 10
L83: 

    /** 		elsif class = res:DIVIDE then*/
    if (_class_25254 != 14)
    goto L85; // [3168] 3370

    /** 			ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 			if ch = '=' then*/
    if (_ch_25242 != 61)
    goto L86; // [3181] 3200

    /** 				return {DIVIDE_EQUALS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 518;
    ((int *)_2)[2] = 0;
    _14661 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14661;
    goto L1; // [3197] 10
L86: 

    /** 			elsif ch = '*' then*/
    if (_ch_25242 != 42)
    goto L87; // [3202] 3352

    /** 				cline = line_number*/
    _cline_25247 = _35line_number_15969;

    /** 				integer cnest = 1*/
    _cnest_25903 = 1;

    /** 				while cnest > 0 do*/
L88: 
    if (_cnest_25903 <= 0)
    goto L89; // [3225] 3333

    /** 					ch = getch()*/
    _ch_25242 = _61getch();
    if (!IS_ATOM_INT(_ch_25242)) {
        _1 = (long)(DBL_PTR(_ch_25242)->dbl);
        DeRefDS(_ch_25242);
        _ch_25242 = _1;
    }

    /** 					switch ch do*/
    _0 = _ch_25242;
    switch ( _0 ){ 

        /** 						case  END_OF_FILE_CHAR then*/
        case 26:

        /** 							exit*/
        goto L89; // [3249] 3333
        goto L88; // [3251] 3225

        /** 						case '\n' then*/
        case 10:

        /** 							read_line()*/
        _61read_line();
        goto L88; // [3261] 3225

        /** 						case '*' then*/
        case 42:

        /** 							ch = getch()*/
        _ch_25242 = _61getch();
        if (!IS_ATOM_INT(_ch_25242)) {
            _1 = (long)(DBL_PTR(_ch_25242)->dbl);
            DeRefDS(_ch_25242);
            _ch_25242 = _1;
        }

        /** 							if ch = '/' then*/
        if (_ch_25242 != 47)
        goto L8A; // [3276] 3289

        /** 								cnest -= 1*/
        _cnest_25903 = _cnest_25903 - 1;
        goto L88; // [3286] 3225
L8A: 

        /** 								ungetch()*/
        _61ungetch();
        goto L88; // [3294] 3225

        /** 						case '/' then*/
        case 47:

        /** 							ch = getch()*/
        _ch_25242 = _61getch();
        if (!IS_ATOM_INT(_ch_25242)) {
            _1 = (long)(DBL_PTR(_ch_25242)->dbl);
            DeRefDS(_ch_25242);
            _ch_25242 = _1;
        }

        /** 							if ch = '*' then*/
        if (_ch_25242 != 42)
        goto L8B; // [3309] 3322

        /** 								cnest += 1*/
        _cnest_25903 = _cnest_25903 + 1;
        goto L8C; // [3319] 3327
L8B: 

        /** 								ungetch()*/
        _61ungetch();
L8C: 
    ;}
    /** 				end while*/
    goto L88; // [3330] 3225
L89: 

    /** 				if cnest > 0 then*/
    if (_cnest_25903 <= 0)
    goto L8D; // [3335] 3347

    /** 					CompileErr(42, cline)*/
    _44CompileErr(42, _cline_25247, 0);
L8D: 
    goto L1; // [3349] 10
L87: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {res:DIVIDE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 14;
    ((int *)_2)[2] = 0;
    _14674 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14674;
    goto L1; // [3367] 10
L85: 

    /** 		elsif class = SINGLE_QUOTE then*/
    if (_class_25254 != -5)
    goto L8E; // [3374] 3515

    /** 			atom ach = getch()*/
    _0 = _ach_25932;
    _ach_25932 = _61getch();
    DeRef(_0);

    /** 			if ach = '\\' then*/
    if (binary_op_a(NOTEQ, _ach_25932, 92)){
        goto L8F; // [3385] 3398
    }

    /** 				ach = EscapeChar('\'')*/
    _0 = _ach_25932;
    _ach_25932 = _61EscapeChar(39);
    DeRef(_0);
    goto L90; // [3395] 3449
L8F: 

    /** 			elsif ach = '\t' then*/
    if (binary_op_a(NOTEQ, _ach_25932, 9)){
        goto L91; // [3400] 3414
    }

    /** 				CompileErr(145)*/
    RefDS(_21815);
    _44CompileErr(145, _21815, 0);
    goto L90; // [3411] 3449
L91: 

    /** 			elsif ach = '\'' then*/
    if (binary_op_a(NOTEQ, _ach_25932, 39)){
        goto L92; // [3416] 3430
    }

    /** 				CompileErr(137)*/
    RefDS(_21815);
    _44CompileErr(137, _21815, 0);
    goto L90; // [3427] 3449
L92: 

    /** 			elsif ach = '\n' then*/
    if (binary_op_a(NOTEQ, _ach_25932, 10)){
        goto L93; // [3432] 3448
    }

    /** 				CompileErr(68, {"character", "end of line"})*/
    RefDS(_14683);
    RefDS(_14682);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14682;
    ((int *)_2)[2] = _14683;
    _14684 = MAKE_SEQ(_1);
    _44CompileErr(68, _14684, 0);
    _14684 = NOVALUE;
L93: 
L90: 

    /** 			if getch() != '\'' then*/
    _14685 = _61getch();
    if (binary_op_a(EQUALS, _14685, 39)){
        DeRef(_14685);
        _14685 = NOVALUE;
        goto L94; // [3454] 3466
    }
    DeRef(_14685);
    _14685 = NOVALUE;

    /** 				CompileErr(56)*/
    RefDS(_21815);
    _44CompileErr(56, _21815, 0);
L94: 

    /** 			if integer(ach) then*/
    if (IS_ATOM_INT(_ach_25932))
    _14687 = 1;
    else if (IS_ATOM_DBL(_ach_25932))
    _14687 = IS_ATOM_INT(DoubleToInt(_ach_25932));
    else
    _14687 = 0;
    if (_14687 == 0)
    {
        _14687 = NOVALUE;
        goto L95; // [3471] 3493
    }
    else{
        _14687 = NOVALUE;
    }

    /** 				return {ATOM, NewIntSym(ach)}*/
    Ref(_ach_25932);
    _14688 = _53NewIntSym(_ach_25932);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14688;
    _14689 = MAKE_SEQ(_1);
    _14688 = NOVALUE;
    DeRef(_ach_25932);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14689;
    goto L96; // [3490] 3510
L95: 

    /** 				return {ATOM, NewDoubleSym(ach)}*/
    Ref(_ach_25932);
    _14690 = _53NewDoubleSym(_ach_25932);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 502;
    ((int *)_2)[2] = _14690;
    _14691 = MAKE_SEQ(_1);
    _14690 = NOVALUE;
    DeRef(_ach_25932);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14691;
L96: 
    DeRef(_ach_25932);
    _ach_25932 = NOVALUE;
    goto L1; // [3512] 10
L8E: 

    /** 		elsif class = LESS then*/
    if (_class_25254 != 1)
    goto L97; // [3519] 3567

    /** 			if getch() = '=' then*/
    _14693 = _61getch();
    if (binary_op_a(NOTEQ, _14693, 61)){
        DeRef(_14693);
        _14693 = NOVALUE;
        goto L98; // [3528] 3547
    }
    DeRef(_14693);
    _14693 = NOVALUE;

    /** 				return {LESSEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 5;
    ((int *)_2)[2] = 0;
    _14695 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14695;
    goto L1; // [3544] 10
L98: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {LESS, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _14696 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14696;
    goto L1; // [3564] 10
L97: 

    /** 		elsif class = GREATER then*/
    if (_class_25254 != 6)
    goto L99; // [3571] 3619

    /** 			if getch() = '=' then*/
    _14698 = _61getch();
    if (binary_op_a(NOTEQ, _14698, 61)){
        DeRef(_14698);
        _14698 = NOVALUE;
        goto L9A; // [3580] 3599
    }
    DeRef(_14698);
    _14698 = NOVALUE;

    /** 				return {GREATEREQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 2;
    ((int *)_2)[2] = 0;
    _14700 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14700;
    goto L1; // [3596] 10
L9A: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {GREATER, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 6;
    ((int *)_2)[2] = 0;
    _14701 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14701;
    goto L1; // [3616] 10
L99: 

    /** 		elsif class = BANG then*/
    if (_class_25254 != -1)
    goto L9B; // [3623] 3671

    /** 			if getch() = '=' then*/
    _14703 = _61getch();
    if (binary_op_a(NOTEQ, _14703, 61)){
        DeRef(_14703);
        _14703 = NOVALUE;
        goto L9C; // [3632] 3651
    }
    DeRef(_14703);
    _14703 = NOVALUE;

    /** 				return {NOTEQ, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 4;
    ((int *)_2)[2] = 0;
    _14705 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14701);
    _14701 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14705;
    goto L1; // [3648] 10
L9C: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				return {BANG, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _14706 = MAKE_SEQ(_1);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14701);
    _14701 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14706;
    goto L1; // [3668] 10
L9B: 

    /** 		elsif class = KEYWORD then*/
    if (_class_25254 != -10)
    goto L9D; // [3675] 3708

    /** 			return {keylist[ch - KEYWORD_BASE][K_TOKEN], 0}*/
    _14708 = _ch_25242 - 128;
    _2 = (int)SEQ_PTR(_63keylist_22479);
    _14709 = (int)*(((s1_ptr)_2)->base + _14708);
    _2 = (int)SEQ_PTR(_14709);
    _14710 = (int)*(((s1_ptr)_2)->base + 3);
    _14709 = NOVALUE;
    Ref(_14710);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _14710;
    ((int *)_2)[2] = 0;
    _14711 = MAKE_SEQ(_1);
    _14710 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    _14708 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14701);
    _14701 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14706);
    _14706 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14711;
    goto L1; // [3705] 10
L9D: 

    /** 		elsif class = BUILTIN then*/
    if (_class_25254 != -9)
    goto L9E; // [3712] 3765

    /** 			name = keylist[ch - BUILTIN_BASE + NUM_KEYWORDS][K_NAME]*/
    _14713 = _ch_25242 - 170;
    if ((long)((unsigned long)_14713 +(unsigned long) HIGH_BITS) >= 0){
        _14713 = NewDouble((double)_14713);
    }
    if (IS_ATOM_INT(_14713)) {
        _14714 = _14713 + 24;
    }
    else {
        _14714 = NewDouble(DBL_PTR(_14713)->dbl + (double)24);
    }
    DeRef(_14713);
    _14713 = NOVALUE;
    _2 = (int)SEQ_PTR(_63keylist_22479);
    if (!IS_ATOM_INT(_14714)){
        _14715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_14714)->dbl));
    }
    else{
        _14715 = (int)*(((s1_ptr)_2)->base + _14714);
    }
    DeRef(_name_25255);
    _2 = (int)SEQ_PTR(_14715);
    _name_25255 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_name_25255);
    _14715 = NOVALUE;

    /** 			return keyfind(name, -1)*/
    RefDS(_name_25255);
    _31389 = _53hashfn(_name_25255);
    RefDS(_name_25255);
    _14717 = _53keyfind(_name_25255, -1, _35current_file_no_15968, 0, _31389);
    _31389 = NOVALUE;
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRefDS(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14708);
    _14708 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14701);
    _14701 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14711);
    _14711 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14706);
    _14706 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14717;
    goto L1; // [3762] 10
L9E: 

    /** 		elsif class = BACK_QUOTE then*/
    if (_class_25254 != -12)
    goto L9F; // [3769] 3786

    /** 			return ExtendedString( '`' )*/
    _14719 = _61ExtendedString(96);
    DeRef(_yytext_25248);
    DeRef(_namespaces_25249);
    DeRef(_d_25250);
    DeRef(_tok_25252);
    DeRef(_name_25255);
    DeRef(_14351);
    _14351 = NOVALUE;
    DeRef(_14385);
    _14385 = NOVALUE;
    DeRef(_14515);
    _14515 = NOVALUE;
    DeRef(_14708);
    _14708 = NOVALUE;
    DeRef(_14696);
    _14696 = NOVALUE;
    DeRef(_14467);
    _14467 = NOVALUE;
    DeRef(_14638);
    _14638 = NOVALUE;
    DeRef(_14661);
    _14661 = NOVALUE;
    _14412 = NOVALUE;
    DeRef(_14656);
    _14656 = NOVALUE;
    DeRef(_14705);
    _14705 = NOVALUE;
    DeRef(_14348);
    _14348 = NOVALUE;
    DeRef(_14701);
    _14701 = NOVALUE;
    DeRef(_14482);
    _14482 = NOVALUE;
    DeRef(_14361);
    _14361 = NOVALUE;
    _14599 = NOVALUE;
    DeRef(_14360);
    _14360 = NOVALUE;
    DeRef(_14517);
    _14517 = NOVALUE;
    DeRef(_14631);
    _14631 = NOVALUE;
    DeRef(_14652);
    _14652 = NOVALUE;
    _14376 = NOVALUE;
    DeRef(_14554);
    _14554 = NOVALUE;
    DeRef(_14563);
    _14563 = NOVALUE;
    DeRef(_14534);
    _14534 = NOVALUE;
    DeRef(_14612);
    _14612 = NOVALUE;
    DeRef(_14689);
    _14689 = NOVALUE;
    DeRef(_14461);
    _14461 = NOVALUE;
    DeRef(_14650);
    _14650 = NOVALUE;
    DeRef(_14334);
    _14334 = NOVALUE;
    DeRef(_14647);
    _14647 = NOVALUE;
    DeRef(_14657);
    _14657 = NOVALUE;
    DeRef(_14456);
    _14456 = NOVALUE;
    DeRef(_14580);
    _14580 = NOVALUE;
    DeRef(_14594);
    _14594 = NOVALUE;
    DeRef(_14556);
    _14556 = NOVALUE;
    DeRef(_14584);
    _14584 = NOVALUE;
    DeRef(_14674);
    _14674 = NOVALUE;
    DeRef(_14509);
    _14509 = NOVALUE;
    DeRef(_14691);
    _14691 = NOVALUE;
    DeRef(_14561);
    _14561 = NOVALUE;
    DeRef(_14569);
    _14569 = NOVALUE;
    DeRef(_14714);
    _14714 = NOVALUE;
    DeRef(_14357);
    _14357 = NOVALUE;
    _14523 = NOVALUE;
    DeRef(_14544);
    _14544 = NOVALUE;
    DeRef(_14605);
    _14605 = NOVALUE;
    DeRef(_14711);
    _14711 = NOVALUE;
    DeRef(_14460);
    _14460 = NOVALUE;
    _14501 = NOVALUE;
    DeRef(_14588);
    _14588 = NOVALUE;
    DeRef(_14546);
    _14546 = NOVALUE;
    _14427 = NOVALUE;
    DeRef(_14339);
    _14339 = NOVALUE;
    DeRef(_14532);
    _14532 = NOVALUE;
    DeRef(_14589);
    _14589 = NOVALUE;
    _14625 = NOVALUE;
    DeRef(_14700);
    _14700 = NOVALUE;
    _14470 = NOVALUE;
    _14505 = NOVALUE;
    DeRef(_14706);
    _14706 = NOVALUE;
    DeRef(_14364);
    _14364 = NOVALUE;
    DeRef(_14380);
    _14380 = NOVALUE;
    _14527 = NOVALUE;
    DeRef(_14570);
    _14570 = NOVALUE;
    DeRef(_14411);
    _14411 = NOVALUE;
    _14480 = NOVALUE;
    _14390 = NOVALUE;
    DeRef(_14695);
    _14695 = NOVALUE;
    DeRef(_14593);
    _14593 = NOVALUE;
    _14401 = NOVALUE;
    DeRef(_14717);
    _14717 = NOVALUE;
    DeRef(_14354);
    _14354 = NOVALUE;
    return _14719;
    goto L1; // [3783] 10
L9F: 

    /** 			InternalErr(268, {class})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _class_25254;
    _14720 = MAKE_SEQ(_1);
    _44InternalErr(268, _14720);
    _14720 = NOVALUE;

    /**    end while*/
    goto L1; // [3799] 10
L2: 
    ;
}


void _61eu_namespace()
{
    int _eu_tok_26029 = NOVALUE;
    int _eu_ns_26031 = NOVALUE;
    int _31388 = NOVALUE;
    int _31387 = NOVALUE;
    int _14729 = NOVALUE;
    int _14727 = NOVALUE;
    int _14725 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	eu_tok = keyfind("eu", -1, , 1)*/
    RefDS(_14723);
    _31387 = _14723;
    _31388 = _53hashfn(_31387);
    _31387 = NOVALUE;
    RefDS(_14723);
    _0 = _eu_tok_26029;
    _eu_tok_26029 = _53keyfind(_14723, -1, _35current_file_no_15968, 1, _31388);
    DeRef(_0);
    _31388 = NOVALUE;

    /** 	eu_ns  = NameSpace_declaration(eu_tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_eu_tok_26029);
    _14725 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14725);
    _eu_ns_26031 = _61NameSpace_declaration(_14725);
    _14725 = NOVALUE;
    if (!IS_ATOM_INT(_eu_ns_26031)) {
        _1 = (long)(DBL_PTR(_eu_ns_26031)->dbl);
        DeRefDS(_eu_ns_26031);
        _eu_ns_26031 = _1;
    }

    /** 	SymTab[eu_ns][S_OBJ] = 0*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26031 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _14727 = NOVALUE;

    /** 	SymTab[eu_ns][S_SCOPE] = SC_GLOBAL*/
    _2 = (int)SEQ_PTR(_36SymTab_14981);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _36SymTab_14981 = MAKE_SEQ(_2);
    }
    _3 = (int)(_eu_ns_26031 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 6;
    DeRef(_1);
    _14729 = NOVALUE;

    /** end procedure*/
    DeRef(_eu_tok_26029);
    return;
    ;
}


int _61StringToken(int _pDelims_26049)
{
    int _ch_26050 = NOVALUE;
    int _m_26051 = NOVALUE;
    int _gtext_26052 = NOVALUE;
    int _level_26083 = NOVALUE;
    int _14768 = NOVALUE;
    int _14766 = NOVALUE;
    int _14764 = NOVALUE;
    int _14745 = NOVALUE;
    int _14744 = NOVALUE;
    int _14738 = NOVALUE;
    int _14736 = NOVALUE;
    int _14734 = NOVALUE;
    int _14732 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14732 = (_ch_26050 == 32);
    if (_14732 != 0) {
        goto L2; // [19] 32
    }
    _14734 = (_ch_26050 == 9);
    if (_14734 == 0)
    {
        DeRef(_14734);
        _14734 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14734);
        _14734 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	pDelims &= {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14736 = MAKE_SEQ(_1);
    Concat((object_ptr)&_pDelims_26049, _pDelims_26049, _14736);
    DeRefDS(_14736);
    _14736 = NOVALUE;

    /** 	gtext = ""*/
    RefDS(_5);
    DeRefi(_gtext_26052);
    _gtext_26052 = _5;

    /** 	while not find(ch,  pDelims) label "top" do*/
L4: 
    _14738 = find_from(_ch_26050, _pDelims_26049, 1);
    if (_14738 != 0)
    goto L5; // [77] 391
    _14738 = NOVALUE;

    /** 		if ch = '-' then*/
    if (_ch_26050 != 45)
    goto L6; // [82] 145

    /** 			ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 			if ch = '-' then*/
    if (_ch_26050 != 45)
    goto L7; // [95] 137

    /** 				while not find(ch, {'\n', END_OF_FILE_CHAR}) do*/
L8: 
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 10;
    ((int *)_2)[2] = 26;
    _14744 = MAKE_SEQ(_1);
    _14745 = find_from(_ch_26050, _14744, 1);
    DeRefDS(_14744);
    _14744 = NOVALUE;
    if (_14745 != 0)
    goto L5; // [115] 391
    _14745 = NOVALUE;

    /** 					ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 				end while*/
    goto L8; // [127] 104

    /** 				exit*/
    goto L5; // [132] 391
    goto L9; // [134] 373
L7: 

    /** 				ungetch()*/
    _61ungetch();
    goto L9; // [142] 373
L6: 

    /** 		elsif ch = '/' then*/
    if (_ch_26050 != 47)
    goto LA; // [147] 372

    /** 			ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 			if ch = '*' then*/
    if (_ch_26050 != 42)
    goto LB; // [160] 361

    /** 				integer level = 1*/
    _level_26083 = 1;

    /** 				while level > 0 do*/
LC: 
    if (_level_26083 <= 0)
    goto LD; // [174] 293

    /** 					ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 					if ch = '/' then*/
    if (_ch_26050 != 47)
    goto LE; // [187] 221

    /** 						ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 						if ch = '*' then*/
    if (_ch_26050 != 42)
    goto LF; // [200] 213

    /** 							level += 1*/
    _level_26083 = _level_26083 + 1;
    goto LC; // [210] 174
LF: 

    /** 							ungetch()*/
    _61ungetch();
    goto LC; // [218] 174
LE: 

    /** 					elsif ch = '*' then*/
    if (_ch_26050 != 42)
    goto L10; // [223] 257

    /** 						ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 						if ch = '/' then*/
    if (_ch_26050 != 47)
    goto L11; // [236] 249

    /** 							level -= 1*/
    _level_26083 = _level_26083 - 1;
    goto LC; // [246] 174
L11: 

    /** 							ungetch()*/
    _61ungetch();
    goto LC; // [254] 174
L10: 

    /** 					elsif ch = '\n' then*/
    if (_ch_26050 != 10)
    goto L12; // [259] 270

    /** 						read_line()*/
    _61read_line();
    goto LC; // [267] 174
L12: 

    /** 					elsif ch = END_OF_FILE_CHAR then*/
    if (_ch_26050 != 26)
    goto LC; // [274] 174

    /** 						ungetch()*/
    _61ungetch();

    /** 						exit*/
    goto LD; // [284] 293

    /** 				end while*/
    goto LC; // [290] 174
LD: 

    /** 				ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 				if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26052)){
            _14764 = SEQ_PTR(_gtext_26052)->length;
    }
    else {
        _14764 = 1;
    }
    if (_14764 != 0)
    goto L13; // [305] 350

    /** 					while ch = ' ' or ch = '\t' do*/
L14: 
    _14766 = (_ch_26050 == 32);
    if (_14766 != 0) {
        goto L15; // [318] 331
    }
    _14768 = (_ch_26050 == 9);
    if (_14768 == 0)
    {
        DeRef(_14768);
        _14768 = NOVALUE;
        goto L16; // [327] 343
    }
    else{
        DeRef(_14768);
        _14768 = NOVALUE;
    }
L15: 

    /** 						ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 					end while*/
    goto L14; // [340] 314
L16: 

    /** 					continue "top"*/
    goto L4; // [347] 72
L13: 

    /** 				exit*/
    goto L5; // [354] 391
    goto L17; // [358] 371
LB: 

    /** 				ungetch()*/
    _61ungetch();

    /** 				ch = '/'*/
    _ch_26050 = 47;
L17: 
LA: 
L9: 

    /** 		gtext &= ch*/
    Append(&_gtext_26052, _gtext_26052, _ch_26050);

    /** 		ch = getch()*/
    _ch_26050 = _61getch();
    if (!IS_ATOM_INT(_ch_26050)) {
        _1 = (long)(DBL_PTR(_ch_26050)->dbl);
        DeRefDS(_ch_26050);
        _ch_26050 = _1;
    }

    /** 	end while*/
    goto L4; // [388] 72
L5: 

    /** 	ungetch() -- put back end-word token.*/
    _61ungetch();

    /** 	return gtext*/
    DeRefDS(_pDelims_26049);
    DeRef(_14732);
    _14732 = NOVALUE;
    DeRef(_14766);
    _14766 = NOVALUE;
    return _gtext_26052;
    ;
}


void _61IncludeScan(int _is_public_26120)
{
    int _ch_26121 = NOVALUE;
    int _gtext_26122 = NOVALUE;
    int _s_26124 = NOVALUE;
    int _31386 = NOVALUE;
    int _14831 = NOVALUE;
    int _14830 = NOVALUE;
    int _14828 = NOVALUE;
    int _14826 = NOVALUE;
    int _14825 = NOVALUE;
    int _14820 = NOVALUE;
    int _14817 = NOVALUE;
    int _14815 = NOVALUE;
    int _14814 = NOVALUE;
    int _14812 = NOVALUE;
    int _14810 = NOVALUE;
    int _14808 = NOVALUE;
    int _14806 = NOVALUE;
    int _14800 = NOVALUE;
    int _14798 = NOVALUE;
    int _14793 = NOVALUE;
    int _14789 = NOVALUE;
    int _14788 = NOVALUE;
    int _14783 = NOVALUE;
    int _14780 = NOVALUE;
    int _14779 = NOVALUE;
    int _14775 = NOVALUE;
    int _14773 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_is_public_26120)) {
        _1 = (long)(DBL_PTR(_is_public_26120)->dbl);
        DeRefDS(_is_public_26120);
        _is_public_26120 = _1;
    }

    /** 	ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
L1: 
    _14773 = (_ch_26121 == 32);
    if (_14773 != 0) {
        goto L2; // [19] 32
    }
    _14775 = (_ch_26121 == 9);
    if (_14775 == 0)
    {
        DeRef(_14775);
        _14775 = NOVALUE;
        goto L3; // [28] 44
    }
    else{
        DeRef(_14775);
        _14775 = NOVALUE;
    }
L2: 

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 	end while*/
    goto L1; // [41] 15
L3: 

    /** 	gtext = ""*/
    RefDS(_5);
    DeRef(_gtext_26122);
    _gtext_26122 = _5;

    /** 	if ch = '"' then*/
    if (_ch_26121 != 34)
    goto L4; // [53] 141

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		while not find(ch, {'\n', '\r', '"', END_OF_FILE_CHAR}) do*/
L5: 
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 34;
    *((int *)(_2+16)) = 26;
    _14779 = MAKE_SEQ(_1);
    _14780 = find_from(_ch_26121, _14779, 1);
    DeRefDS(_14779);
    _14779 = NOVALUE;
    if (_14780 != 0)
    goto L6; // [83] 124
    _14780 = NOVALUE;

    /** 			if ch = '\\' then*/
    if (_ch_26121 != 92)
    goto L7; // [88] 105

    /** 				gtext &= EscapeChar('"')*/
    _14783 = _61EscapeChar(34);
    if (IS_SEQUENCE(_gtext_26122) && IS_ATOM(_14783)) {
        Ref(_14783);
        Append(&_gtext_26122, _gtext_26122, _14783);
    }
    else if (IS_ATOM(_gtext_26122) && IS_SEQUENCE(_14783)) {
    }
    else {
        Concat((object_ptr)&_gtext_26122, _gtext_26122, _14783);
    }
    DeRef(_14783);
    _14783 = NOVALUE;
    goto L8; // [102] 112
L7: 

    /** 				gtext &= ch*/
    Append(&_gtext_26122, _gtext_26122, _ch_26121);
L8: 

    /** 			ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		end while*/
    goto L5; // [121] 69
L6: 

    /** 		if ch != '"' then*/
    if (_ch_26121 == 34)
    goto L9; // [126] 187

    /** 			CompileErr(115)*/
    RefDS(_21815);
    _44CompileErr(115, _21815, 0);
    goto L9; // [138] 187
L4: 

    /** 		while not find(ch, {' ', '\t', '\n', '\r', END_OF_FILE_CHAR}) do*/
LA: 
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 32;
    *((int *)(_2+8)) = 9;
    *((int *)(_2+12)) = 10;
    *((int *)(_2+16)) = 13;
    *((int *)(_2+20)) = 26;
    _14788 = MAKE_SEQ(_1);
    _14789 = find_from(_ch_26121, _14788, 1);
    DeRefDS(_14788);
    _14788 = NOVALUE;
    if (_14789 != 0)
    goto LB; // [161] 182
    _14789 = NOVALUE;

    /** 			gtext &= ch*/
    Append(&_gtext_26122, _gtext_26122, _ch_26121);

    /** 			ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		end while*/
    goto LA; // [179] 146
LB: 

    /** 		ungetch()*/
    _61ungetch();
L9: 

    /** 	if length(gtext) = 0 then*/
    if (IS_SEQUENCE(_gtext_26122)){
            _14793 = SEQ_PTR(_gtext_26122)->length;
    }
    else {
        _14793 = 1;
    }
    if (_14793 != 0)
    goto LC; // [192] 204

    /** 		CompileErr(95)*/
    RefDS(_21815);
    _44CompileErr(95, _21815, 0);
LC: 

    /** 	ifdef WINDOWS then*/

    /** 		new_include_name = gtext*/
    RefDS(_gtext_26122);
    DeRef(_35new_include_name_16090);
    _35new_include_name_16090 = _gtext_26122;

    /** 	ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 	while ch = ' ' or ch = '\t' do*/
LD: 
    _14798 = (_ch_26121 == 32);
    if (_14798 != 0) {
        goto LE; // [229] 242
    }
    _14800 = (_ch_26121 == 9);
    if (_14800 == 0)
    {
        DeRef(_14800);
        _14800 = NOVALUE;
        goto LF; // [238] 254
    }
    else{
        DeRef(_14800);
        _14800 = NOVALUE;
    }
LE: 

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 	end while*/
    goto LD; // [251] 225
LF: 

    /** 	new_include_space = 0*/
    _61new_include_space_23544 = 0;

    /** 	if ch = 'a' then*/
    if (_ch_26121 != 97)
    goto L10; // [263] 520

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		if ch = 's' then*/
    if (_ch_26121 != 115)
    goto L11; // [276] 509

    /** 			ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 			if ch = ' ' or ch = '\t' then*/
    _14806 = (_ch_26121 == 32);
    if (_14806 != 0) {
        goto L12; // [293] 306
    }
    _14808 = (_ch_26121 == 9);
    if (_14808 == 0)
    {
        DeRef(_14808);
        _14808 = NOVALUE;
        goto L13; // [302] 498
    }
    else{
        DeRef(_14808);
        _14808 = NOVALUE;
    }
L12: 

    /** 				ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 				while ch = ' ' or ch = '\t' do*/
L14: 
    _14810 = (_ch_26121 == 32);
    if (_14810 != 0) {
        goto L15; // [322] 335
    }
    _14812 = (_ch_26121 == 9);
    if (_14812 == 0)
    {
        DeRef(_14812);
        _14812 = NOVALUE;
        goto L16; // [331] 347
    }
    else{
        DeRef(_14812);
        _14812 = NOVALUE;
    }
L15: 

    /** 					ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 				end while*/
    goto L14; // [344] 318
L16: 

    /** 				if char_class[ch] = LETTER or ch = '_' then*/
    _2 = (int)SEQ_PTR(_61char_class_23553);
    _14814 = (int)*(((s1_ptr)_2)->base + _ch_26121);
    _14815 = (_14814 == -2);
    _14814 = NOVALUE;
    if (_14815 != 0) {
        goto L17; // [361] 374
    }
    _14817 = (_ch_26121 == 95);
    if (_14817 == 0)
    {
        DeRef(_14817);
        _14817 = NOVALUE;
        goto L18; // [370] 487
    }
    else{
        DeRef(_14817);
        _14817 = NOVALUE;
    }
L17: 

    /** 					gtext = {ch}*/
    _0 = _gtext_26122;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ch_26121;
    _gtext_26122 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 					ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 					while id_char[ch] = TRUE do*/
L19: 
    _2 = (int)SEQ_PTR(_61id_char_23554);
    _14820 = (int)*(((s1_ptr)_2)->base + _ch_26121);
    if (_14820 != _13TRUE_437)
    goto L1A; // [400] 422

    /** 						gtext &= ch*/
    Append(&_gtext_26122, _gtext_26122, _ch_26121);

    /** 						ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 					end while*/
    goto L19; // [419] 392
L1A: 

    /** 					ungetch()*/
    _61ungetch();

    /** 					s = keyfind(gtext, -1, , 1)*/
    RefDS(_gtext_26122);
    _31386 = _53hashfn(_gtext_26122);
    RefDS(_gtext_26122);
    _0 = _s_26124;
    _s_26124 = _53keyfind(_gtext_26122, -1, _35current_file_no_15968, 1, _31386);
    DeRef(_0);
    _31386 = NOVALUE;

    /** 					if not find(s[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_s_26124);
    _14825 = (int)*(((s1_ptr)_2)->base + 1);
    _14826 = find_from(_14825, _37ID_TOKS_15600, 1);
    _14825 = NOVALUE;
    if (_14826 != 0)
    goto L1B; // [459] 470
    _14826 = NOVALUE;

    /** 						CompileErr(36)*/
    RefDS(_21815);
    _44CompileErr(36, _21815, 0);
L1B: 

    /** 					new_include_space = NameSpace_declaration(s[T_SYM])*/
    _2 = (int)SEQ_PTR(_s_26124);
    _14828 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_14828);
    _0 = _61NameSpace_declaration(_14828);
    _61new_include_space_23544 = _0;
    _14828 = NOVALUE;
    if (!IS_ATOM_INT(_61new_include_space_23544)) {
        _1 = (long)(DBL_PTR(_61new_include_space_23544)->dbl);
        DeRefDS(_61new_include_space_23544);
        _61new_include_space_23544 = _1;
    }
    goto L1C; // [484] 629
L18: 

    /** 					CompileErr(113)*/
    RefDS(_21815);
    _44CompileErr(113, _21815, 0);
    goto L1C; // [495] 629
L13: 

    /** 				CompileErr(100)*/
    RefDS(_21815);
    _44CompileErr(100, _21815, 0);
    goto L1C; // [506] 629
L11: 

    /** 			CompileErr(100)*/
    RefDS(_21815);
    _44CompileErr(100, _21815, 0);
    goto L1C; // [517] 629
L10: 

    /** 	elsif find(ch, {'\n', '\r', END_OF_FILE_CHAR}) then*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 10;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 26;
    _14830 = MAKE_SEQ(_1);
    _14831 = find_from(_ch_26121, _14830, 1);
    DeRefDS(_14830);
    _14830 = NOVALUE;
    if (_14831 == 0)
    {
        _14831 = NOVALUE;
        goto L1D; // [535] 545
    }
    else{
        _14831 = NOVALUE;
    }

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [542] 629
L1D: 

    /** 	elsif ch = '-' then*/
    if (_ch_26121 != 45)
    goto L1E; // [547] 583

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		if ch != '-' then*/
    if (_ch_26121 == 45)
    goto L1F; // [560] 572

    /** 			CompileErr(100)*/
    RefDS(_21815);
    _44CompileErr(100, _21815, 0);
L1F: 

    /** 		ungetch()*/
    _61ungetch();

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [580] 629
L1E: 

    /** 	elsif ch = '/' then*/
    if (_ch_26121 != 47)
    goto L20; // [585] 621

    /** 		ch = getch()*/
    _ch_26121 = _61getch();
    if (!IS_ATOM_INT(_ch_26121)) {
        _1 = (long)(DBL_PTR(_ch_26121)->dbl);
        DeRefDS(_ch_26121);
        _ch_26121 = _1;
    }

    /** 		if ch != '*' then*/
    if (_ch_26121 == 42)
    goto L21; // [598] 610

    /** 			CompileErr(100)*/
    RefDS(_21815);
    _44CompileErr(100, _21815, 0);
L21: 

    /** 		ungetch()*/
    _61ungetch();

    /** 		ungetch()*/
    _61ungetch();
    goto L1C; // [618] 629
L20: 

    /** 		CompileErr(100)*/
    RefDS(_21815);
    _44CompileErr(100, _21815, 0);
L1C: 

    /** 	start_include = TRUE -- let scanner know*/
    _61start_include_23546 = _13TRUE_437;

    /** 	public_include = is_public*/
    _61public_include_23549 = _is_public_26120;

    /** end procedure*/
    DeRef(_gtext_26122);
    DeRef(_s_26124);
    DeRef(_14773);
    _14773 = NOVALUE;
    DeRef(_14798);
    _14798 = NOVALUE;
    DeRef(_14806);
    _14806 = NOVALUE;
    DeRef(_14810);
    _14810 = NOVALUE;
    _14820 = NOVALUE;
    DeRef(_14815);
    _14815 = NOVALUE;
    return;
    ;
}


void _61main_file()
{
    int _0, _1, _2;
    

    /** 	ifdef STDDEBUG then*/

    /** 		read_line()*/
    _61read_line();

    /** 		default_namespace( )*/
    _61default_namespace();

    /** end procedure*/
    return;
    ;
}


void _61cleanup_open_includes()
{
    int _14841 = NOVALUE;
    int _14840 = NOVALUE;
    int _14839 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( IncludeStk ) do*/
    if (IS_SEQUENCE(_61IncludeStk_23555)){
            _14839 = SEQ_PTR(_61IncludeStk_23555)->length;
    }
    else {
        _14839 = 1;
    }
    {
        int _i_26243;
        _i_26243 = 1;
L1: 
        if (_i_26243 > _14839){
            goto L2; // [8] 36
        }

        /** 		close( IncludeStk[i][FILE_PTR] )*/
        _2 = (int)SEQ_PTR(_61IncludeStk_23555);
        _14840 = (int)*(((s1_ptr)_2)->base + _i_26243);
        _2 = (int)SEQ_PTR(_14840);
        _14841 = (int)*(((s1_ptr)_2)->base + 3);
        _14840 = NOVALUE;
        if (IS_ATOM_INT(_14841))
        EClose(_14841);
        else
        EClose((int)DBL_PTR(_14841)->dbl);
        _14841 = NOVALUE;

        /** 	end for*/
        _i_26243 = _i_26243 + 1;
        goto L1; // [31] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}



// 0xA7D42062
