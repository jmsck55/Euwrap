// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _26pretty_out(int _text_7448)
{
    int _4015 = NOVALUE;
    int _4013 = NOVALUE;
    int _4011 = NOVALUE;
    int _4010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_26pretty_line_7445) && IS_ATOM(_text_7448)) {
        Ref(_text_7448);
        Append(&_26pretty_line_7445, _26pretty_line_7445, _text_7448);
    }
    else if (IS_ATOM(_26pretty_line_7445) && IS_SEQUENCE(_text_7448)) {
    }
    else {
        Concat((object_ptr)&_26pretty_line_7445, _26pretty_line_7445, _text_7448);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_7448 == 10)
    _4010 = 1;
    else if (IS_ATOM_INT(_text_7448) && IS_ATOM_INT(10))
    _4010 = 0;
    else
    _4010 = (compare(_text_7448, 10) == 0);
    if (_4010 == 0) {
        goto L1; // [15] 50
    }
    goto L1; // [22] 50

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_26pretty_file_7433, _26pretty_line_7445); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_26pretty_line_7445);
    _26pretty_line_7445 = _5;

    /** 		pretty_line_count += 1*/
    _26pretty_line_count_7438 = _26pretty_line_count_7438 + 1;
L1: 

    /** 	if atom(text) then*/
    _4013 = IS_ATOM(_text_7448);
    if (_4013 == 0)
    {
        _4013 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _4013 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _26pretty_chars_7430 = _26pretty_chars_7430 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_7448)){
            _4015 = SEQ_PTR(_text_7448)->length;
    }
    else {
        _4015 = 1;
    }
    _26pretty_chars_7430 = _26pretty_chars_7430 + _4015;
    _4015 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_7448);
    return;
    ;
}


void _26cut_line(int _n_7462)
{
    int _4018 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_26pretty_line_breaks_7441 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _26pretty_chars_7430 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _4018 = _26pretty_chars_7430 + _n_7462;
    if ((long)((unsigned long)_4018 + (unsigned long)HIGH_BITS) >= 0) 
    _4018 = NewDouble((double)_4018);
    if (binary_op_a(LESSEQ, _4018, _26pretty_end_col_7429)){
        DeRef(_4018);
        _4018 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_4018);
    _4018 = NOVALUE;

    /** 		pretty_out('\n')*/
    _26pretty_out(10);

    /** 		pretty_chars = 0*/
    _26pretty_chars_7430 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _26indent()
{
    int _4026 = NOVALUE;
    int _4025 = NOVALUE;
    int _4024 = NOVALUE;
    int _4023 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_26pretty_line_breaks_7441 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _26pretty_chars_7430 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_26pretty_line_breaks_7441 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _26cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_26pretty_chars_7430 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _26pretty_out(10);

    /** 			pretty_chars = 0*/
    _26pretty_chars_7430 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _4023 = _26pretty_start_col_7431 - 1;
    if ((long)((unsigned long)_4023 +(unsigned long) HIGH_BITS) >= 0){
        _4023 = NewDouble((double)_4023);
    }
    if (_26pretty_level_7432 == (short)_26pretty_level_7432 && _26pretty_indent_7435 <= INT15 && _26pretty_indent_7435 >= -INT15)
    _4024 = _26pretty_level_7432 * _26pretty_indent_7435;
    else
    _4024 = NewDouble(_26pretty_level_7432 * (double)_26pretty_indent_7435);
    if (IS_ATOM_INT(_4023) && IS_ATOM_INT(_4024)) {
        _4025 = _4023 + _4024;
    }
    else {
        if (IS_ATOM_INT(_4023)) {
            _4025 = NewDouble((double)_4023 + DBL_PTR(_4024)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4024)) {
                _4025 = NewDouble(DBL_PTR(_4023)->dbl + (double)_4024);
            }
            else
            _4025 = NewDouble(DBL_PTR(_4023)->dbl + DBL_PTR(_4024)->dbl);
        }
    }
    DeRef(_4023);
    _4023 = NOVALUE;
    DeRef(_4024);
    _4024 = NOVALUE;
    _4026 = Repeat(32, _4025);
    DeRef(_4025);
    _4025 = NOVALUE;
    _26pretty_out(_4026);
    _4026 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _26esc_char(int _a_7483)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_7483)) {
        _1 = (long)(DBL_PTR(_a_7483)->dbl);
        DeRefDS(_a_7483);
        _a_7483 = _1;
    }

    /** 	switch a do*/
    _0 = _a_7483;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_4029);
        return _4029;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_4030);
        return _4030;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_4031);
        return _4031;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_907);
        return _907;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_4032);
        return _4032;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_7483;
    ;}L1: 
    ;
}


void _26rPrint(int _a_7498)
{
    int _sbuff_7499 = NOVALUE;
    int _multi_line_7500 = NOVALUE;
    int _all_ascii_7501 = NOVALUE;
    int _4089 = NOVALUE;
    int _4088 = NOVALUE;
    int _4087 = NOVALUE;
    int _4086 = NOVALUE;
    int _4082 = NOVALUE;
    int _4081 = NOVALUE;
    int _4080 = NOVALUE;
    int _4079 = NOVALUE;
    int _4077 = NOVALUE;
    int _4076 = NOVALUE;
    int _4074 = NOVALUE;
    int _4073 = NOVALUE;
    int _4071 = NOVALUE;
    int _4070 = NOVALUE;
    int _4069 = NOVALUE;
    int _4068 = NOVALUE;
    int _4067 = NOVALUE;
    int _4066 = NOVALUE;
    int _4065 = NOVALUE;
    int _4064 = NOVALUE;
    int _4063 = NOVALUE;
    int _4062 = NOVALUE;
    int _4061 = NOVALUE;
    int _4060 = NOVALUE;
    int _4059 = NOVALUE;
    int _4058 = NOVALUE;
    int _4057 = NOVALUE;
    int _4056 = NOVALUE;
    int _4055 = NOVALUE;
    int _4051 = NOVALUE;
    int _4050 = NOVALUE;
    int _4049 = NOVALUE;
    int _4048 = NOVALUE;
    int _4047 = NOVALUE;
    int _4046 = NOVALUE;
    int _4044 = NOVALUE;
    int _4043 = NOVALUE;
    int _4039 = NOVALUE;
    int _4038 = NOVALUE;
    int _4037 = NOVALUE;
    int _4034 = NOVALUE;
    int _4033 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _4033 = IS_ATOM(_a_7498);
    if (_4033 == 0)
    {
        _4033 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _4033 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_7498))
    _4034 = 1;
    else if (IS_ATOM_DBL(_a_7498))
    _4034 = IS_ATOM_INT(DoubleToInt(_a_7498));
    else
    _4034 = 0;
    if (_4034 == 0)
    {
        _4034 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _4034 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_7499);
    _sbuff_7499 = EPrintf(-9999999, _26pretty_int_format_7444, _a_7498);

    /** 			if pretty_ascii then */
    if (_26pretty_ascii_7434 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_26pretty_ascii_7434 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_7498)) {
        _4037 = (_a_7498 >= _26pretty_ascii_min_7436);
    }
    else {
        _4037 = binary_op(GREATEREQ, _a_7498, _26pretty_ascii_min_7436);
    }
    if (IS_ATOM_INT(_4037)) {
        if (_4037 == 0) {
            _4038 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_4037)->dbl == 0.0) {
            _4038 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_7498)) {
        _4039 = (_a_7498 <= _26pretty_ascii_max_7437);
    }
    else {
        _4039 = binary_op(LESSEQ, _a_7498, _26pretty_ascii_max_7437);
    }
    DeRef(_4038);
    if (IS_ATOM_INT(_4039))
    _4038 = (_4039 != 0);
    else
    _4038 = DBL_PTR(_4039)->dbl != 0.0;
L5: 
    if (_4038 == 0)
    {
        _4038 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _4038 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7498;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7499, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _4043 = find_from(_a_7498, _4042, 1);
    if (_4043 == 0)
    {
        _4043 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _4043 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_7498);
    _4044 = _26esc_char(_a_7498);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _4044;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_7499, concat_list, 3);
    }
    DeRef(_4044);
    _4044 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_7498)) {
        _4046 = (_a_7498 >= _26pretty_ascii_min_7436);
    }
    else {
        _4046 = binary_op(GREATEREQ, _a_7498, _26pretty_ascii_min_7436);
    }
    if (IS_ATOM_INT(_4046)) {
        if (_4046 == 0) {
            DeRef(_4047);
            _4047 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_4046)->dbl == 0.0) {
            DeRef(_4047);
            _4047 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_7498)) {
        _4048 = (_a_7498 <= _26pretty_ascii_max_7437);
    }
    else {
        _4048 = binary_op(LESSEQ, _a_7498, _26pretty_ascii_max_7437);
    }
    DeRef(_4047);
    if (IS_ATOM_INT(_4048))
    _4047 = (_4048 != 0);
    else
    _4047 = DBL_PTR(_4048)->dbl != 0.0;
L7: 
    if (_4047 == 0) {
        goto L3; // [125] 166
    }
    _4050 = (_26pretty_ascii_7434 < 2);
    if (_4050 == 0)
    {
        DeRef(_4050);
        _4050 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_4050);
        _4050 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_7498;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_4051, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_7499, _sbuff_7499, _4051);
    DeRefDS(_4051);
    _4051 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_7499);
    _sbuff_7499 = EPrintf(-9999999, _26pretty_fp_format_7443, _a_7498);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_7499);
    _26pretty_out(_sbuff_7499);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _26cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_7500 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_7501 = (_26pretty_ascii_7434 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7498)){
            _4055 = SEQ_PTR(_a_7498)->length;
    }
    else {
        _4055 = 1;
    }
    {
        int _i_7535;
        _i_7535 = 1;
L9: 
        if (_i_7535 > _4055){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_7498);
        _4056 = (int)*(((s1_ptr)_2)->base + _i_7535);
        _4057 = IS_SEQUENCE(_4056);
        _4056 = NOVALUE;
        if (_4057 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_7498);
        _4059 = (int)*(((s1_ptr)_2)->base + _i_7535);
        if (IS_SEQUENCE(_4059)){
                _4060 = SEQ_PTR(_4059)->length;
        }
        else {
            _4060 = 1;
        }
        _4059 = NOVALUE;
        _4061 = (_4060 > 0);
        _4060 = NOVALUE;
        if (_4061 == 0)
        {
            DeRef(_4061);
            _4061 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_4061);
            _4061 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_7500 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_7501 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_7498);
        _4062 = (int)*(((s1_ptr)_2)->base + _i_7535);
        if (IS_ATOM_INT(_4062))
        _4063 = 1;
        else if (IS_ATOM_DBL(_4062))
        _4063 = IS_ATOM_INT(DoubleToInt(_4062));
        else
        _4063 = 0;
        _4062 = NOVALUE;
        _4064 = (_4063 == 0);
        _4063 = NOVALUE;
        if (_4064 != 0) {
            _4065 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_7498);
        _4066 = (int)*(((s1_ptr)_2)->base + _i_7535);
        if (IS_ATOM_INT(_4066)) {
            _4067 = (_4066 < _26pretty_ascii_min_7436);
        }
        else {
            _4067 = binary_op(LESS, _4066, _26pretty_ascii_min_7436);
        }
        _4066 = NOVALUE;
        if (IS_ATOM_INT(_4067)) {
            if (_4067 == 0) {
                DeRef(_4068);
                _4068 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_4067)->dbl == 0.0) {
                DeRef(_4068);
                _4068 = 0;
                goto LD; // [275] 309
            }
        }
        _4069 = (_26pretty_ascii_7434 < 2);
        if (_4069 != 0) {
            _4070 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_7498);
        _4071 = (int)*(((s1_ptr)_2)->base + _i_7535);
        _4073 = find_from(_4071, _4072, 1);
        _4071 = NOVALUE;
        _4074 = (_4073 == 0);
        _4073 = NOVALUE;
        _4070 = (_4074 != 0);
LE: 
        DeRef(_4068);
        _4068 = (_4070 != 0);
LD: 
        _4065 = (_4068 != 0);
LC: 
        if (_4065 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_7498);
        _4076 = (int)*(((s1_ptr)_2)->base + _i_7535);
        if (IS_ATOM_INT(_4076)) {
            _4077 = (_4076 > _26pretty_ascii_max_7437);
        }
        else {
            _4077 = binary_op(GREATER, _4076, _26pretty_ascii_max_7437);
        }
        _4076 = NOVALUE;
        if (_4077 == 0) {
            DeRef(_4077);
            _4077 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_4077) && DBL_PTR(_4077)->dbl == 0.0){
                DeRef(_4077);
                _4077 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_4077);
            _4077 = NOVALUE;
        }
        DeRef(_4077);
        _4077 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_7501 = 0;
L10: 

        /** 		end for*/
        _i_7535 = _i_7535 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_7501 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _26pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _26pretty_level_7432 = _26pretty_level_7432 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_7498)){
            _4079 = SEQ_PTR(_a_7498)->length;
    }
    else {
        _4079 = 1;
    }
    {
        int _i_7565;
        _i_7565 = 1;
L13: 
        if (_i_7565 > _4079){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_7500 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _26indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_7501 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_7498);
        _4080 = (int)*(((s1_ptr)_2)->base + _i_7565);
        Ref(_4080);
        _4081 = _26esc_char(_4080);
        _4080 = NOVALUE;
        _26pretty_out(_4081);
        _4081 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_7498);
        _4082 = (int)*(((s1_ptr)_2)->base + _i_7565);
        Ref(_4082);
        _26rPrint(_4082);
        _4082 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_26pretty_line_count_7438 < _26pretty_line_max_7439)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_26pretty_dots_7440 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_4085);
        _26pretty_out(_4085);
L19: 

        /** 				pretty_dots = 1*/
        _26pretty_dots_7440 = 1;

        /** 				return*/
        DeRef(_a_7498);
        DeRef(_sbuff_7499);
        DeRef(_4037);
        _4037 = NOVALUE;
        DeRef(_4039);
        _4039 = NOVALUE;
        DeRef(_4046);
        _4046 = NOVALUE;
        DeRef(_4048);
        _4048 = NOVALUE;
        _4059 = NOVALUE;
        DeRef(_4064);
        _4064 = NOVALUE;
        DeRef(_4069);
        _4069 = NOVALUE;
        DeRef(_4067);
        _4067 = NOVALUE;
        DeRef(_4074);
        _4074 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_7498)){
                _4086 = SEQ_PTR(_a_7498)->length;
        }
        else {
            _4086 = 1;
        }
        _4087 = (_i_7565 != _4086);
        _4086 = NOVALUE;
        if (_4087 == 0) {
            goto L1A; // [468] 490
        }
        _4089 = (_all_ascii_7501 == 0);
        if (_4089 == 0)
        {
            DeRef(_4089);
            _4089 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_4089);
            _4089 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _26pretty_out(44);

        /** 				cut_line(6)*/
        _26cut_line(6);
L1A: 

        /** 		end for*/
        _i_7565 = _i_7565 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _26pretty_level_7432 = _26pretty_level_7432 - 1;

    /** 		if multi_line then*/
    if (_multi_line_7500 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _26indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_7501 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _26pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _26pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_7498);
    DeRef(_sbuff_7499);
    DeRef(_4037);
    _4037 = NOVALUE;
    DeRef(_4039);
    _4039 = NOVALUE;
    DeRef(_4046);
    _4046 = NOVALUE;
    DeRef(_4048);
    _4048 = NOVALUE;
    _4059 = NOVALUE;
    DeRef(_4064);
    _4064 = NOVALUE;
    DeRef(_4069);
    _4069 = NOVALUE;
    DeRef(_4067);
    _4067 = NOVALUE;
    DeRef(_4074);
    _4074 = NOVALUE;
    DeRef(_4087);
    _4087 = NOVALUE;
    return;
    ;
}


void _26pretty(int _x_7604, int _options_7605)
{
    int _4096 = NOVALUE;
    int _4095 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    _4095 = 10;
    _4096 = 10;

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_ascii_7434 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_26pretty_ascii_7434))
    _26pretty_ascii_7434 = (long)DBL_PTR(_26pretty_ascii_7434)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_indent_7435 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_26pretty_indent_7435))
    _26pretty_indent_7435 = (long)DBL_PTR(_26pretty_indent_7435)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_start_col_7431 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_26pretty_start_col_7431))
    _26pretty_start_col_7431 = (long)DBL_PTR(_26pretty_start_col_7431)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_end_col_7429 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_26pretty_end_col_7429))
    _26pretty_end_col_7429 = (long)DBL_PTR(_26pretty_end_col_7429)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_26pretty_int_format_7444);
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_int_format_7444 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_26pretty_int_format_7444);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_26pretty_fp_format_7443);
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_fp_format_7443 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_26pretty_fp_format_7443);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_ascii_min_7436 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_26pretty_ascii_min_7436))
    _26pretty_ascii_min_7436 = (long)DBL_PTR(_26pretty_ascii_min_7436)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_ascii_max_7437 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_26pretty_ascii_max_7437))
    _26pretty_ascii_max_7437 = (long)DBL_PTR(_26pretty_ascii_max_7437)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_line_max_7439 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_26pretty_line_max_7439))
    _26pretty_line_max_7439 = (long)DBL_PTR(_26pretty_line_max_7439)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_7605);
    _26pretty_line_breaks_7441 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_26pretty_line_breaks_7441))
    _26pretty_line_breaks_7441 = (long)DBL_PTR(_26pretty_line_breaks_7441)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _26pretty_chars_7430 = _26pretty_start_col_7431;

    /** 	pretty_level = 0 */
    _26pretty_level_7432 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_26pretty_line_7445);
    _26pretty_line_7445 = _5;

    /** 	pretty_line_count = 0*/
    _26pretty_line_count_7438 = 0;

    /** 	pretty_dots = 0*/
    _26pretty_dots_7440 = 0;

    /** 	rPrint(x)*/
    Ref(_x_7604);
    _26rPrint(_x_7604);

    /** end procedure*/
    DeRef(_x_7604);
    DeRefDS(_options_7605);
    return;
    ;
}



// 0x6175D2FB
