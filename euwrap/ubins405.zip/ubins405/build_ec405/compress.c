// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _59compress(int _x_21585)
{
    int _x4_21586 = NOVALUE;
    int _s_21587 = NOVALUE;
    int _12484 = NOVALUE;
    int _12483 = NOVALUE;
    int _12482 = NOVALUE;
    int _12480 = NOVALUE;
    int _12479 = NOVALUE;
    int _12477 = NOVALUE;
    int _12475 = NOVALUE;
    int _12474 = NOVALUE;
    int _12473 = NOVALUE;
    int _12472 = NOVALUE;
    int _12470 = NOVALUE;
    int _12468 = NOVALUE;
    int _12467 = NOVALUE;
    int _12466 = NOVALUE;
    int _12465 = NOVALUE;
    int _12464 = NOVALUE;
    int _12463 = NOVALUE;
    int _12462 = NOVALUE;
    int _12461 = NOVALUE;
    int _12460 = NOVALUE;
    int _12458 = NOVALUE;
    int _12457 = NOVALUE;
    int _12456 = NOVALUE;
    int _12455 = NOVALUE;
    int _12454 = NOVALUE;
    int _12453 = NOVALUE;
    int _12451 = NOVALUE;
    int _12450 = NOVALUE;
    int _12449 = NOVALUE;
    int _12448 = NOVALUE;
    int _12447 = NOVALUE;
    int _12446 = NOVALUE;
    int _12445 = NOVALUE;
    int _12444 = NOVALUE;
    int _12443 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21585))
    _12443 = 1;
    else if (IS_ATOM_DBL(_x_21585))
    _12443 = IS_ATOM_INT(DoubleToInt(_x_21585));
    else
    _12443 = 0;
    if (_12443 == 0)
    {
        _12443 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _12443 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_21585)) {
        _12444 = (_x_21585 >= -2);
    }
    else {
        _12444 = binary_op(GREATEREQ, _x_21585, -2);
    }
    if (IS_ATOM_INT(_12444)) {
        if (_12444 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12444)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_21585)) {
        _12446 = (_x_21585 <= 246);
    }
    else {
        _12446 = binary_op(LESSEQ, _x_21585, 246);
    }
    if (_12446 == 0) {
        DeRef(_12446);
        _12446 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12446) && DBL_PTR(_12446)->dbl == 0.0){
            DeRef(_12446);
            _12446 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12446);
        _12446 = NOVALUE;
    }
    DeRef(_12446);
    _12446 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_21585)) {
        _12447 = _x_21585 - -2;
        if ((long)((unsigned long)_12447 +(unsigned long) HIGH_BITS) >= 0){
            _12447 = NewDouble((double)_12447);
        }
    }
    else {
        _12447 = binary_op(MINUS, _x_21585, -2);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12447;
    _12448 = MAKE_SEQ(_1);
    _12447 = NOVALUE;
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    return _12448;
    goto L3; // [41] 319
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21585)) {
        _12449 = (_x_21585 >= _59MIN2B_21568);
    }
    else {
        _12449 = binary_op(GREATEREQ, _x_21585, _59MIN2B_21568);
    }
    if (IS_ATOM_INT(_12449)) {
        if (_12449 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12449)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_21585)) {
        _12451 = (_x_21585 <= 32767);
    }
    else {
        _12451 = binary_op(LESSEQ, _x_21585, 32767);
    }
    if (_12451 == 0) {
        DeRef(_12451);
        _12451 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12451) && DBL_PTR(_12451)->dbl == 0.0){
            DeRef(_12451);
            _12451 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12451);
        _12451 = NOVALUE;
    }
    DeRef(_12451);
    _12451 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_21585;
    if (IS_ATOM_INT(_x_21585)) {
        _x_21585 = _x_21585 - _59MIN2B_21568;
        if ((long)((unsigned long)_x_21585 +(unsigned long) HIGH_BITS) >= 0){
            _x_21585 = NewDouble((double)_x_21585);
        }
    }
    else {
        _x_21585 = binary_op(MINUS, _x_21585, _59MIN2B_21568);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_21585)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21585 & (unsigned long)255;
             _12453 = MAKE_UINT(tu);
        }
    }
    else {
        _12453 = binary_op(AND_BITS, _x_21585, 255);
    }
    if (IS_ATOM_INT(_x_21585)) {
        if (256 > 0 && _x_21585 >= 0) {
            _12454 = _x_21585 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21585 / (double)256);
            if (_x_21585 != MININT)
            _12454 = (long)temp_dbl;
            else
            _12454 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21585, 256);
        _12454 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12453;
    *((int *)(_2+12)) = _12454;
    _12455 = MAKE_SEQ(_1);
    _12454 = NOVALUE;
    _12453 = NOVALUE;
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    return _12455;
    goto L3; // [94] 319
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21585)) {
        _12456 = (_x_21585 >= _59MIN3B_21574);
    }
    else {
        _12456 = binary_op(GREATEREQ, _x_21585, _59MIN3B_21574);
    }
    if (IS_ATOM_INT(_12456)) {
        if (_12456 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12456)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_21585)) {
        _12458 = (_x_21585 <= 8388607);
    }
    else {
        _12458 = binary_op(LESSEQ, _x_21585, 8388607);
    }
    if (_12458 == 0) {
        DeRef(_12458);
        _12458 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12458) && DBL_PTR(_12458)->dbl == 0.0){
            DeRef(_12458);
            _12458 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12458);
        _12458 = NOVALUE;
    }
    DeRef(_12458);
    _12458 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_21585;
    if (IS_ATOM_INT(_x_21585)) {
        _x_21585 = _x_21585 - _59MIN3B_21574;
        if ((long)((unsigned long)_x_21585 +(unsigned long) HIGH_BITS) >= 0){
            _x_21585 = NewDouble((double)_x_21585);
        }
    }
    else {
        _x_21585 = binary_op(MINUS, _x_21585, _59MIN3B_21574);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_21585)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21585 & (unsigned long)255;
             _12460 = MAKE_UINT(tu);
        }
    }
    else {
        _12460 = binary_op(AND_BITS, _x_21585, 255);
    }
    if (IS_ATOM_INT(_x_21585)) {
        if (256 > 0 && _x_21585 >= 0) {
            _12461 = _x_21585 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21585 / (double)256);
            if (_x_21585 != MININT)
            _12461 = (long)temp_dbl;
            else
            _12461 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21585, 256);
        _12461 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12461)) {
        {unsigned long tu;
             tu = (unsigned long)_12461 & (unsigned long)255;
             _12462 = MAKE_UINT(tu);
        }
    }
    else {
        _12462 = binary_op(AND_BITS, _12461, 255);
    }
    DeRef(_12461);
    _12461 = NOVALUE;
    if (IS_ATOM_INT(_x_21585)) {
        if (65536 > 0 && _x_21585 >= 0) {
            _12463 = _x_21585 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21585 / (double)65536);
            if (_x_21585 != MININT)
            _12463 = (long)temp_dbl;
            else
            _12463 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21585, 65536);
        _12463 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12460;
    *((int *)(_2+12)) = _12462;
    *((int *)(_2+16)) = _12463;
    _12464 = MAKE_SEQ(_1);
    _12463 = NOVALUE;
    _12462 = NOVALUE;
    _12460 = NOVALUE;
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    DeRef(_12455);
    _12455 = NOVALUE;
    DeRef(_12456);
    _12456 = NOVALUE;
    return _12464;
    goto L3; // [156] 319
L5: 

    /** 			return I4B & int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_21585) && IS_ATOM_INT(_59MIN4B_21580)) {
        _12465 = _x_21585 - _59MIN4B_21580;
        if ((long)((unsigned long)_12465 +(unsigned long) HIGH_BITS) >= 0){
            _12465 = NewDouble((double)_12465);
        }
    }
    else {
        _12465 = binary_op(MINUS, _x_21585, _59MIN4B_21580);
    }
    _12466 = _15int_to_bytes(_12465);
    _12465 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12466)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12466)) {
        Prepend(&_12467, _12466, 251);
    }
    else {
        Concat((object_ptr)&_12467, 251, _12466);
    }
    DeRef(_12466);
    _12466 = NOVALUE;
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    DeRef(_12455);
    _12455 = NOVALUE;
    DeRef(_12456);
    _12456 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    return _12467;
    goto L3; // [180] 319
L1: 

    /** 	elsif atom(x) then*/
    _12468 = IS_ATOM(_x_21585);
    if (_12468 == 0)
    {
        _12468 = NOVALUE;
        goto L6; // [188] 240
    }
    else{
        _12468 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21585);
    _0 = _x4_21586;
    _x4_21586 = _15atom_to_float32(_x_21585);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21586);
    _12470 = _15float32_to_atom(_x4_21586);
    if (binary_op_a(NOTEQ, _x_21585, _12470)){
        DeRef(_12470);
        _12470 = NOVALUE;
        goto L7; // [205] 222
    }
    DeRef(_12470);
    _12470 = NOVALUE;

    /** 			return F4B & x4*/
    Prepend(&_12472, _x4_21586, 252);
    DeRef(_x_21585);
    DeRefDS(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    DeRef(_12455);
    _12455 = NOVALUE;
    DeRef(_12456);
    _12456 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12467);
    _12467 = NOVALUE;
    return _12472;
    goto L3; // [219] 319
L7: 

    /** 			return F8B & atom_to_float64(x)*/
    Ref(_x_21585);
    _12473 = _15atom_to_float64(_x_21585);
    if (IS_SEQUENCE(253) && IS_ATOM(_12473)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12473)) {
        Prepend(&_12474, _12473, 253);
    }
    else {
        Concat((object_ptr)&_12474, 253, _12473);
    }
    DeRef(_12473);
    _12473 = NOVALUE;
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_s_21587);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    DeRef(_12455);
    _12455 = NOVALUE;
    DeRef(_12456);
    _12456 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12467);
    _12467 = NOVALUE;
    DeRef(_12472);
    _12472 = NOVALUE;
    return _12474;
    goto L3; // [237] 319
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21585)){
            _12475 = SEQ_PTR(_x_21585)->length;
    }
    else {
        _12475 = 1;
    }
    if (_12475 > 255)
    goto L8; // [245] 261

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21585)){
            _12477 = SEQ_PTR(_x_21585)->length;
    }
    else {
        _12477 = 1;
    }
    DeRef(_s_21587);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12477;
    _s_21587 = MAKE_SEQ(_1);
    _12477 = NOVALUE;
    goto L9; // [258] 275
L8: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21585)){
            _12479 = SEQ_PTR(_x_21585)->length;
    }
    else {
        _12479 = 1;
    }
    _12480 = _15int_to_bytes(_12479);
    _12479 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12480)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12480)) {
        Prepend(&_s_21587, _12480, 255);
    }
    else {
        Concat((object_ptr)&_s_21587, 255, _12480);
    }
    DeRef(_12480);
    _12480 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21585)){
            _12482 = SEQ_PTR(_x_21585)->length;
    }
    else {
        _12482 = 1;
    }
    {
        int _i_21644;
        _i_21644 = 1;
LA: 
        if (_i_21644 > _12482){
            goto LB; // [280] 310
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_21585);
        _12483 = (int)*(((s1_ptr)_2)->base + _i_21644);
        Ref(_12483);
        _12484 = _59compress(_12483);
        _12483 = NOVALUE;
        if (IS_SEQUENCE(_s_21587) && IS_ATOM(_12484)) {
            Ref(_12484);
            Append(&_s_21587, _s_21587, _12484);
        }
        else if (IS_ATOM(_s_21587) && IS_SEQUENCE(_12484)) {
        }
        else {
            Concat((object_ptr)&_s_21587, _s_21587, _12484);
        }
        DeRef(_12484);
        _12484 = NOVALUE;

        /** 		end for*/
        _i_21644 = _i_21644 + 1;
        goto LA; // [305] 287
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_21585);
    DeRef(_x4_21586);
    DeRef(_12444);
    _12444 = NOVALUE;
    DeRef(_12448);
    _12448 = NOVALUE;
    DeRef(_12449);
    _12449 = NOVALUE;
    DeRef(_12455);
    _12455 = NOVALUE;
    DeRef(_12456);
    _12456 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12467);
    _12467 = NOVALUE;
    DeRef(_12472);
    _12472 = NOVALUE;
    DeRef(_12474);
    _12474 = NOVALUE;
    return _s_21587;
L3: 
    ;
}


void _59init_compress()
{
    int _0, _1, _2;
    

    /** 	comp_cache = repeat({}, COMP_CACHE_SIZE)*/
    DeRef(_59comp_cache_21655);
    _59comp_cache_21655 = Repeat(_5, 64);

    /** end procedure*/
    return;
    ;
}


void _59fcompress(int _f_21661, int _x_21662)
{
    int _x4_21663 = NOVALUE;
    int _s_21664 = NOVALUE;
    int _p_21665 = NOVALUE;
    int _12536 = NOVALUE;
    int _12535 = NOVALUE;
    int _12534 = NOVALUE;
    int _12532 = NOVALUE;
    int _12531 = NOVALUE;
    int _12529 = NOVALUE;
    int _12527 = NOVALUE;
    int _12526 = NOVALUE;
    int _12525 = NOVALUE;
    int _12524 = NOVALUE;
    int _12522 = NOVALUE;
    int _12520 = NOVALUE;
    int _12519 = NOVALUE;
    int _12518 = NOVALUE;
    int _12517 = NOVALUE;
    int _12516 = NOVALUE;
    int _12515 = NOVALUE;
    int _12514 = NOVALUE;
    int _12513 = NOVALUE;
    int _12512 = NOVALUE;
    int _12510 = NOVALUE;
    int _12509 = NOVALUE;
    int _12508 = NOVALUE;
    int _12507 = NOVALUE;
    int _12506 = NOVALUE;
    int _12505 = NOVALUE;
    int _12503 = NOVALUE;
    int _12502 = NOVALUE;
    int _12501 = NOVALUE;
    int _12500 = NOVALUE;
    int _12499 = NOVALUE;
    int _12498 = NOVALUE;
    int _12496 = NOVALUE;
    int _12495 = NOVALUE;
    int _12494 = NOVALUE;
    int _12493 = NOVALUE;
    int _12492 = NOVALUE;
    int _12491 = NOVALUE;
    int _12490 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_21661)) {
        _1 = (long)(DBL_PTR(_f_21661)->dbl);
        DeRefDS(_f_21661);
        _f_21661 = _1;
    }

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21662))
    _12490 = 1;
    else if (IS_ATOM_DBL(_x_21662))
    _12490 = IS_ATOM_INT(DoubleToInt(_x_21662));
    else
    _12490 = 0;
    if (_12490 == 0)
    {
        _12490 = NOVALUE;
        goto L1; // [8] 232
    }
    else{
        _12490 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= max1b then*/
    if (IS_ATOM_INT(_x_21662)) {
        _12491 = (_x_21662 >= -2);
    }
    else {
        _12491 = binary_op(GREATEREQ, _x_21662, -2);
    }
    if (IS_ATOM_INT(_12491)) {
        if (_12491 == 0) {
            goto L2; // [17] 43
        }
    }
    else {
        if (DBL_PTR(_12491)->dbl == 0.0) {
            goto L2; // [17] 43
        }
    }
    if (IS_ATOM_INT(_x_21662)) {
        _12493 = (_x_21662 <= 182);
    }
    else {
        _12493 = binary_op(LESSEQ, _x_21662, 182);
    }
    if (_12493 == 0) {
        DeRef(_12493);
        _12493 = NOVALUE;
        goto L2; // [28] 43
    }
    else {
        if (!IS_ATOM_INT(_12493) && DBL_PTR(_12493)->dbl == 0.0){
            DeRef(_12493);
            _12493 = NOVALUE;
            goto L2; // [28] 43
        }
        DeRef(_12493);
        _12493 = NOVALUE;
    }
    DeRef(_12493);
    _12493 = NOVALUE;

    /** 			puts(f, x - MIN1B) -- normal, quite small integer*/
    if (IS_ATOM_INT(_x_21662)) {
        _12494 = _x_21662 - -2;
        if ((long)((unsigned long)_12494 +(unsigned long) HIGH_BITS) >= 0){
            _12494 = NewDouble((double)_12494);
        }
    }
    else {
        _12494 = binary_op(MINUS, _x_21662, -2);
    }
    EPuts(_f_21661, _12494); // DJP 
    DeRef(_12494);
    _12494 = NOVALUE;
    goto L3; // [40] 362
L2: 

    /** 			p = 1 + and_bits(x, COMP_CACHE_SIZE-1)*/
    _12495 = 63;
    if (IS_ATOM_INT(_x_21662)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21662 & (unsigned long)63;
             _12496 = MAKE_UINT(tu);
        }
    }
    else {
        _12496 = binary_op(AND_BITS, _x_21662, 63);
    }
    _12495 = NOVALUE;
    if (IS_ATOM_INT(_12496)) {
        _p_21665 = _12496 + 1;
    }
    else
    { // coercing _p_21665 to an integer 1
        _p_21665 = 1+(long)(DBL_PTR(_12496)->dbl);
        if( !IS_ATOM_INT(_p_21665) ){
            _p_21665 = (object)DBL_PTR(_p_21665)->dbl;
        }
    }
    DeRef(_12496);
    _12496 = NOVALUE;

    /** 			if equal(comp_cache[p], x) then*/
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    _12498 = (int)*(((s1_ptr)_2)->base + _p_21665);
    if (_12498 == _x_21662)
    _12499 = 1;
    else if (IS_ATOM_INT(_12498) && IS_ATOM_INT(_x_21662))
    _12499 = 0;
    else
    _12499 = (compare(_12498, _x_21662) == 0);
    _12498 = NOVALUE;
    if (_12499 == 0)
    {
        _12499 = NOVALUE;
        goto L4; // [69] 86
    }
    else{
        _12499 = NOVALUE;
    }

    /** 				puts(f, CACHE0 + p) -- output the cache slot number*/
    _12500 = 184 + _p_21665;
    if ((long)((unsigned long)_12500 + (unsigned long)HIGH_BITS) >= 0) 
    _12500 = NewDouble((double)_12500);
    EPuts(_f_21661, _12500); // DJP 
    DeRef(_12500);
    _12500 = NOVALUE;
    goto L3; // [83] 362
L4: 

    /** 				comp_cache[p] = x -- store it in cache slot p*/
    Ref(_x_21662);
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    _2 = (int)(((s1_ptr)_2)->base + _p_21665);
    _1 = *(int *)_2;
    *(int *)_2 = _x_21662;
    DeRef(_1);

    /** 				if x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21662)) {
        _12501 = (_x_21662 >= _59MIN2B_21568);
    }
    else {
        _12501 = binary_op(GREATEREQ, _x_21662, _59MIN2B_21568);
    }
    if (IS_ATOM_INT(_12501)) {
        if (_12501 == 0) {
            goto L5; // [102] 146
        }
    }
    else {
        if (DBL_PTR(_12501)->dbl == 0.0) {
            goto L5; // [102] 146
        }
    }
    if (IS_ATOM_INT(_x_21662)) {
        _12503 = (_x_21662 <= 32767);
    }
    else {
        _12503 = binary_op(LESSEQ, _x_21662, 32767);
    }
    if (_12503 == 0) {
        DeRef(_12503);
        _12503 = NOVALUE;
        goto L5; // [113] 146
    }
    else {
        if (!IS_ATOM_INT(_12503) && DBL_PTR(_12503)->dbl == 0.0){
            DeRef(_12503);
            _12503 = NOVALUE;
            goto L5; // [113] 146
        }
        DeRef(_12503);
        _12503 = NOVALUE;
    }
    DeRef(_12503);
    _12503 = NOVALUE;

    /** 					x -= MIN2B*/
    _0 = _x_21662;
    if (IS_ATOM_INT(_x_21662)) {
        _x_21662 = _x_21662 - _59MIN2B_21568;
        if ((long)((unsigned long)_x_21662 +(unsigned long) HIGH_BITS) >= 0){
            _x_21662 = NewDouble((double)_x_21662);
        }
    }
    else {
        _x_21662 = binary_op(MINUS, _x_21662, _59MIN2B_21568);
    }
    DeRef(_0);

    /** 					puts(f, {I2B, and_bits(x, #FF), floor(x / #100)})*/
    if (IS_ATOM_INT(_x_21662)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21662 & (unsigned long)255;
             _12505 = MAKE_UINT(tu);
        }
    }
    else {
        _12505 = binary_op(AND_BITS, _x_21662, 255);
    }
    if (IS_ATOM_INT(_x_21662)) {
        if (256 > 0 && _x_21662 >= 0) {
            _12506 = _x_21662 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21662 / (double)256);
            if (_x_21662 != MININT)
            _12506 = (long)temp_dbl;
            else
            _12506 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21662, 256);
        _12506 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12505;
    *((int *)(_2+12)) = _12506;
    _12507 = MAKE_SEQ(_1);
    _12506 = NOVALUE;
    _12505 = NOVALUE;
    EPuts(_f_21661, _12507); // DJP 
    DeRefDS(_12507);
    _12507 = NOVALUE;
    goto L3; // [143] 362
L5: 

    /** 				elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21662)) {
        _12508 = (_x_21662 >= _59MIN3B_21574);
    }
    else {
        _12508 = binary_op(GREATEREQ, _x_21662, _59MIN3B_21574);
    }
    if (IS_ATOM_INT(_12508)) {
        if (_12508 == 0) {
            goto L6; // [154] 207
        }
    }
    else {
        if (DBL_PTR(_12508)->dbl == 0.0) {
            goto L6; // [154] 207
        }
    }
    if (IS_ATOM_INT(_x_21662)) {
        _12510 = (_x_21662 <= 8388607);
    }
    else {
        _12510 = binary_op(LESSEQ, _x_21662, 8388607);
    }
    if (_12510 == 0) {
        DeRef(_12510);
        _12510 = NOVALUE;
        goto L6; // [165] 207
    }
    else {
        if (!IS_ATOM_INT(_12510) && DBL_PTR(_12510)->dbl == 0.0){
            DeRef(_12510);
            _12510 = NOVALUE;
            goto L6; // [165] 207
        }
        DeRef(_12510);
        _12510 = NOVALUE;
    }
    DeRef(_12510);
    _12510 = NOVALUE;

    /** 					x -= MIN3B*/
    _0 = _x_21662;
    if (IS_ATOM_INT(_x_21662)) {
        _x_21662 = _x_21662 - _59MIN3B_21574;
        if ((long)((unsigned long)_x_21662 +(unsigned long) HIGH_BITS) >= 0){
            _x_21662 = NewDouble((double)_x_21662);
        }
    }
    else {
        _x_21662 = binary_op(MINUS, _x_21662, _59MIN3B_21574);
    }
    DeRef(_0);

    /** 					puts(f, {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)})*/
    if (IS_ATOM_INT(_x_21662)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21662 & (unsigned long)255;
             _12512 = MAKE_UINT(tu);
        }
    }
    else {
        _12512 = binary_op(AND_BITS, _x_21662, 255);
    }
    if (IS_ATOM_INT(_x_21662)) {
        if (256 > 0 && _x_21662 >= 0) {
            _12513 = _x_21662 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21662 / (double)256);
            if (_x_21662 != MININT)
            _12513 = (long)temp_dbl;
            else
            _12513 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21662, 256);
        _12513 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12513)) {
        {unsigned long tu;
             tu = (unsigned long)_12513 & (unsigned long)255;
             _12514 = MAKE_UINT(tu);
        }
    }
    else {
        _12514 = binary_op(AND_BITS, _12513, 255);
    }
    DeRef(_12513);
    _12513 = NOVALUE;
    if (IS_ATOM_INT(_x_21662)) {
        if (65536 > 0 && _x_21662 >= 0) {
            _12515 = _x_21662 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21662 / (double)65536);
            if (_x_21662 != MININT)
            _12515 = (long)temp_dbl;
            else
            _12515 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21662, 65536);
        _12515 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12512;
    *((int *)(_2+12)) = _12514;
    *((int *)(_2+16)) = _12515;
    _12516 = MAKE_SEQ(_1);
    _12515 = NOVALUE;
    _12514 = NOVALUE;
    _12512 = NOVALUE;
    EPuts(_f_21661, _12516); // DJP 
    DeRefDS(_12516);
    _12516 = NOVALUE;
    goto L3; // [204] 362
L6: 

    /** 					puts(f, I4B & int_to_bytes(x-MIN4B))*/
    if (IS_ATOM_INT(_x_21662) && IS_ATOM_INT(_59MIN4B_21580)) {
        _12517 = _x_21662 - _59MIN4B_21580;
        if ((long)((unsigned long)_12517 +(unsigned long) HIGH_BITS) >= 0){
            _12517 = NewDouble((double)_12517);
        }
    }
    else {
        _12517 = binary_op(MINUS, _x_21662, _59MIN4B_21580);
    }
    _12518 = _15int_to_bytes(_12517);
    _12517 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12518)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12518)) {
        Prepend(&_12519, _12518, 251);
    }
    else {
        Concat((object_ptr)&_12519, 251, _12518);
    }
    DeRef(_12518);
    _12518 = NOVALUE;
    EPuts(_f_21661, _12519); // DJP 
    DeRefDS(_12519);
    _12519 = NOVALUE;
    goto L3; // [229] 362
L1: 

    /** 	elsif atom(x) then*/
    _12520 = IS_ATOM(_x_21662);
    if (_12520 == 0)
    {
        _12520 = NOVALUE;
        goto L7; // [237] 287
    }
    else{
        _12520 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21662);
    _0 = _x4_21663;
    _x4_21663 = _15atom_to_float32(_x_21662);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21663);
    _12522 = _15float32_to_atom(_x4_21663);
    if (binary_op_a(NOTEQ, _x_21662, _12522)){
        DeRef(_12522);
        _12522 = NOVALUE;
        goto L8; // [254] 270
    }
    DeRef(_12522);
    _12522 = NOVALUE;

    /** 			puts(f, F4B & x4)*/
    Prepend(&_12524, _x4_21663, 252);
    EPuts(_f_21661, _12524); // DJP 
    DeRefDS(_12524);
    _12524 = NOVALUE;
    goto L3; // [267] 362
L8: 

    /** 			puts(f, F8B & atom_to_float64(x))*/
    Ref(_x_21662);
    _12525 = _15atom_to_float64(_x_21662);
    if (IS_SEQUENCE(253) && IS_ATOM(_12525)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12525)) {
        Prepend(&_12526, _12525, 253);
    }
    else {
        Concat((object_ptr)&_12526, 253, _12525);
    }
    DeRef(_12525);
    _12525 = NOVALUE;
    EPuts(_f_21661, _12526); // DJP 
    DeRefDS(_12526);
    _12526 = NOVALUE;
    goto L3; // [284] 362
L7: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21662)){
            _12527 = SEQ_PTR(_x_21662)->length;
    }
    else {
        _12527 = 1;
    }
    if (_12527 > 255)
    goto L9; // [292] 308

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21662)){
            _12529 = SEQ_PTR(_x_21662)->length;
    }
    else {
        _12529 = 1;
    }
    DeRef(_s_21664);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12529;
    _s_21664 = MAKE_SEQ(_1);
    _12529 = NOVALUE;
    goto LA; // [305] 322
L9: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21662)){
            _12531 = SEQ_PTR(_x_21662)->length;
    }
    else {
        _12531 = 1;
    }
    _12532 = _15int_to_bytes(_12531);
    _12531 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12532)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12532)) {
        Prepend(&_s_21664, _12532, 255);
    }
    else {
        Concat((object_ptr)&_s_21664, 255, _12532);
    }
    DeRef(_12532);
    _12532 = NOVALUE;
LA: 

    /** 		puts(f, s)*/
    EPuts(_f_21661, _s_21664); // DJP 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21662)){
            _12534 = SEQ_PTR(_x_21662)->length;
    }
    else {
        _12534 = 1;
    }
    {
        int _i_21730;
        _i_21730 = 1;
LB: 
        if (_i_21730 > _12534){
            goto LC; // [334] 361
        }

        /** 			fcompress(f, x[i])*/
        _2 = (int)SEQ_PTR(_x_21662);
        _12535 = (int)*(((s1_ptr)_2)->base + _i_21730);
        DeRef(_12536);
        _12536 = _f_21661;
        Ref(_12535);
        _59fcompress(_12536, _12535);
        _12536 = NOVALUE;
        _12535 = NOVALUE;

        /** 		end for*/
        _i_21730 = _i_21730 + 1;
        goto LB; // [356] 341
LC: 
        ;
    }
L3: 

    /** end procedure*/
    DeRef(_x_21662);
    DeRef(_x4_21663);
    DeRef(_s_21664);
    DeRef(_12491);
    _12491 = NOVALUE;
    DeRef(_12501);
    _12501 = NOVALUE;
    DeRef(_12508);
    _12508 = NOVALUE;
    return;
    ;
}


int _59get4()
{
    int _12545 = NOVALUE;
    int _12544 = NOVALUE;
    int _12543 = NOVALUE;
    int _12542 = NOVALUE;
    int _12541 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12541 = getc((FILE*)xstdin);
        }
        else
        _12541 = getc(last_r_file_ptr);
    }
    else
    _12541 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem0_21735)){
        poke_addr = (unsigned char *)_59mem0_21735;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem0_21735)->dbl);
    }
    *poke_addr = (unsigned char)_12541;
    _12541 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12542 = getc((FILE*)xstdin);
        }
        else
        _12542 = getc(last_r_file_ptr);
    }
    else
    _12542 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem1_21736)){
        poke_addr = (unsigned char *)_59mem1_21736;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem1_21736)->dbl);
    }
    *poke_addr = (unsigned char)_12542;
    _12542 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12543 = getc((FILE*)xstdin);
        }
        else
        _12543 = getc(last_r_file_ptr);
    }
    else
    _12543 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem2_21737)){
        poke_addr = (unsigned char *)_59mem2_21737;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem2_21737)->dbl);
    }
    *poke_addr = (unsigned char)_12543;
    _12543 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12544 = getc((FILE*)xstdin);
        }
        else
        _12544 = getc(last_r_file_ptr);
    }
    else
    _12544 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_59mem3_21738)){
        poke_addr = (unsigned char *)_59mem3_21738;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_59mem3_21738)->dbl);
    }
    *poke_addr = (unsigned char)_12544;
    _12544 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_59mem0_21735)) {
        _12545 = *(unsigned long *)_59mem0_21735;
        if ((unsigned)_12545 > (unsigned)MAXINT)
        _12545 = NewDouble((double)(unsigned long)_12545);
    }
    else {
        _12545 = *(unsigned long *)(unsigned long)(DBL_PTR(_59mem0_21735)->dbl);
        if ((unsigned)_12545 > (unsigned)MAXINT)
        _12545 = NewDouble((double)(unsigned long)_12545);
    }
    return _12545;
    ;
}


int _59fdecompress(int _c_21753)
{
    int _s_21754 = NOVALUE;
    int _len_21755 = NOVALUE;
    int _ival_21756 = NOVALUE;
    int _12613 = NOVALUE;
    int _12612 = NOVALUE;
    int _12611 = NOVALUE;
    int _12610 = NOVALUE;
    int _12608 = NOVALUE;
    int _12607 = NOVALUE;
    int _12603 = NOVALUE;
    int _12598 = NOVALUE;
    int _12597 = NOVALUE;
    int _12596 = NOVALUE;
    int _12595 = NOVALUE;
    int _12594 = NOVALUE;
    int _12593 = NOVALUE;
    int _12592 = NOVALUE;
    int _12591 = NOVALUE;
    int _12590 = NOVALUE;
    int _12589 = NOVALUE;
    int _12587 = NOVALUE;
    int _12586 = NOVALUE;
    int _12585 = NOVALUE;
    int _12584 = NOVALUE;
    int _12583 = NOVALUE;
    int _12582 = NOVALUE;
    int _12580 = NOVALUE;
    int _12579 = NOVALUE;
    int _12578 = NOVALUE;
    int _12576 = NOVALUE;
    int _12574 = NOVALUE;
    int _12573 = NOVALUE;
    int _12572 = NOVALUE;
    int _12570 = NOVALUE;
    int _12569 = NOVALUE;
    int _12568 = NOVALUE;
    int _12567 = NOVALUE;
    int _12566 = NOVALUE;
    int _12565 = NOVALUE;
    int _12564 = NOVALUE;
    int _12562 = NOVALUE;
    int _12561 = NOVALUE;
    int _12560 = NOVALUE;
    int _12558 = NOVALUE;
    int _12557 = NOVALUE;
    int _12556 = NOVALUE;
    int _12555 = NOVALUE;
    int _12553 = NOVALUE;
    int _12552 = NOVALUE;
    int _12550 = NOVALUE;
    int _12549 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_21753)) {
        _1 = (long)(DBL_PTR(_c_21753)->dbl);
        DeRefDS(_c_21753);
        _c_21753 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_21753 != 0)
    goto L1; // [5] 70

    /** 		c = getc(current_db)*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_21753 = getc((FILE*)xstdin);
        }
        else
        _c_21753 = getc(last_r_file_ptr);
    }
    else
    _c_21753 = getc(last_r_file_ptr);

    /** 		if c <= CACHE0 then*/
    if (_c_21753 > 184)
    goto L2; // [20] 37

    /** 			return c + MIN1B  -- a normal, quite small integer*/
    _12549 = _c_21753 + -2;
    DeRef(_s_21754);
    return _12549;
    goto L3; // [34] 69
L2: 

    /** 		elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
    _12550 = 248;
    if (_c_21753 > 248)
    goto L4; // [45] 68

    /** 			return comp_cache[c-CACHE0]*/
    _12552 = _c_21753 - 184;
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    _12553 = (int)*(((s1_ptr)_2)->base + _12552);
    Ref(_12553);
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    _12550 = NOVALUE;
    _12552 = NOVALUE;
    return _12553;
L4: 
L3: 
L1: 

    /** 	if c = I2B then*/
    if (_c_21753 != 249)
    goto L5; // [72] 133

    /** 		ival = getc(current_db) +*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12555 = getc((FILE*)xstdin);
        }
        else
        _12555 = getc(last_r_file_ptr);
    }
    else
    _12555 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12556 = getc((FILE*)xstdin);
        }
        else
        _12556 = getc(last_r_file_ptr);
    }
    else
    _12556 = getc(last_r_file_ptr);
    _12557 = 256 * _12556;
    _12556 = NOVALUE;
    _12558 = _12555 + _12557;
    _12555 = NOVALUE;
    _12557 = NOVALUE;
    _ival_21756 = _12558 + _59MIN2B_21568;
    _12558 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12560 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21756 & (unsigned long)63;
         _12561 = MAKE_UINT(tu);
    }
    _12560 = NOVALUE;
    if (IS_ATOM_INT(_12561)) {
        _12562 = _12561 + 1;
    }
    else
    _12562 = binary_op(PLUS, 1, _12561);
    DeRef(_12561);
    _12561 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    if (!IS_ATOM_INT(_12562))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12562)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12562);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21756;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    return _ival_21756;
    goto L6; // [130] 514
L5: 

    /** 	elsif c = I3B then*/
    if (_c_21753 != 250)
    goto L7; // [135] 209

    /** 		ival = getc(current_db) +*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12564 = getc((FILE*)xstdin);
        }
        else
        _12564 = getc(last_r_file_ptr);
    }
    else
    _12564 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12565 = getc((FILE*)xstdin);
        }
        else
        _12565 = getc(last_r_file_ptr);
    }
    else
    _12565 = getc(last_r_file_ptr);
    _12566 = 256 * _12565;
    _12565 = NOVALUE;
    _12567 = _12564 + _12566;
    _12564 = NOVALUE;
    _12566 = NOVALUE;
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12568 = getc((FILE*)xstdin);
        }
        else
        _12568 = getc(last_r_file_ptr);
    }
    else
    _12568 = getc(last_r_file_ptr);
    _12569 = 65536 * _12568;
    _12568 = NOVALUE;
    _12570 = _12567 + _12569;
    _12567 = NOVALUE;
    _12569 = NOVALUE;
    _ival_21756 = _12570 + _59MIN3B_21574;
    _12570 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12572 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21756 & (unsigned long)63;
         _12573 = MAKE_UINT(tu);
    }
    _12572 = NOVALUE;
    if (IS_ATOM_INT(_12573)) {
        _12574 = _12573 + 1;
    }
    else
    _12574 = binary_op(PLUS, 1, _12573);
    DeRef(_12573);
    _12573 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    if (!IS_ATOM_INT(_12574))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12574)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12574);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21756;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    DeRef(_12574);
    _12574 = NOVALUE;
    return _ival_21756;
    goto L6; // [206] 514
L7: 

    /** 	elsif c = I4B  then*/
    if (_c_21753 != 251)
    goto L8; // [211] 257

    /** 		ival = get4() + MIN4B*/
    _12576 = _59get4();
    if (IS_ATOM_INT(_12576) && IS_ATOM_INT(_59MIN4B_21580)) {
        _ival_21756 = _12576 + _59MIN4B_21580;
    }
    else {
        _ival_21756 = binary_op(PLUS, _12576, _59MIN4B_21580);
    }
    DeRef(_12576);
    _12576 = NOVALUE;
    if (!IS_ATOM_INT(_ival_21756)) {
        _1 = (long)(DBL_PTR(_ival_21756)->dbl);
        DeRefDS(_ival_21756);
        _ival_21756 = _1;
    }

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12578 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21756 & (unsigned long)63;
         _12579 = MAKE_UINT(tu);
    }
    _12578 = NOVALUE;
    if (IS_ATOM_INT(_12579)) {
        _12580 = _12579 + 1;
    }
    else
    _12580 = binary_op(PLUS, 1, _12579);
    DeRef(_12579);
    _12579 = NOVALUE;
    _2 = (int)SEQ_PTR(_59comp_cache_21655);
    if (!IS_ATOM_INT(_12580))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12580)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12580);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21756;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    DeRef(_12574);
    _12574 = NOVALUE;
    DeRef(_12580);
    _12580 = NOVALUE;
    return _ival_21756;
    goto L6; // [254] 514
L8: 

    /** 	elsif c = F4B then*/
    if (_c_21753 != 252)
    goto L9; // [259] 303

    /** 		return float32_to_atom({getc(current_db), getc(current_db),*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12582 = getc((FILE*)xstdin);
        }
        else
        _12582 = getc(last_r_file_ptr);
    }
    else
    _12582 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12583 = getc((FILE*)xstdin);
        }
        else
        _12583 = getc(last_r_file_ptr);
    }
    else
    _12583 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12584 = getc((FILE*)xstdin);
        }
        else
        _12584 = getc(last_r_file_ptr);
    }
    else
    _12584 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12585 = getc((FILE*)xstdin);
        }
        else
        _12585 = getc(last_r_file_ptr);
    }
    else
    _12585 = getc(last_r_file_ptr);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12582;
    *((int *)(_2+8)) = _12583;
    *((int *)(_2+12)) = _12584;
    *((int *)(_2+16)) = _12585;
    _12586 = MAKE_SEQ(_1);
    _12585 = NOVALUE;
    _12584 = NOVALUE;
    _12583 = NOVALUE;
    _12582 = NOVALUE;
    _12587 = _15float32_to_atom(_12586);
    _12586 = NOVALUE;
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    DeRef(_12574);
    _12574 = NOVALUE;
    DeRef(_12580);
    _12580 = NOVALUE;
    return _12587;
    goto L6; // [300] 514
L9: 

    /** 	elsif c = F8B then*/
    if (_c_21753 != 253)
    goto LA; // [305] 373

    /** 		return float64_to_atom({getc(current_db), getc(current_db),*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12589 = getc((FILE*)xstdin);
        }
        else
        _12589 = getc(last_r_file_ptr);
    }
    else
    _12589 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12590 = getc((FILE*)xstdin);
        }
        else
        _12590 = getc(last_r_file_ptr);
    }
    else
    _12590 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12591 = getc((FILE*)xstdin);
        }
        else
        _12591 = getc(last_r_file_ptr);
    }
    else
    _12591 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12592 = getc((FILE*)xstdin);
        }
        else
        _12592 = getc(last_r_file_ptr);
    }
    else
    _12592 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12593 = getc((FILE*)xstdin);
        }
        else
        _12593 = getc(last_r_file_ptr);
    }
    else
    _12593 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12594 = getc((FILE*)xstdin);
        }
        else
        _12594 = getc(last_r_file_ptr);
    }
    else
    _12594 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12595 = getc((FILE*)xstdin);
        }
        else
        _12595 = getc(last_r_file_ptr);
    }
    else
    _12595 = getc(last_r_file_ptr);
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12596 = getc((FILE*)xstdin);
        }
        else
        _12596 = getc(last_r_file_ptr);
    }
    else
    _12596 = getc(last_r_file_ptr);
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12589;
    *((int *)(_2+8)) = _12590;
    *((int *)(_2+12)) = _12591;
    *((int *)(_2+16)) = _12592;
    *((int *)(_2+20)) = _12593;
    *((int *)(_2+24)) = _12594;
    *((int *)(_2+28)) = _12595;
    *((int *)(_2+32)) = _12596;
    _12597 = MAKE_SEQ(_1);
    _12596 = NOVALUE;
    _12595 = NOVALUE;
    _12594 = NOVALUE;
    _12593 = NOVALUE;
    _12592 = NOVALUE;
    _12591 = NOVALUE;
    _12590 = NOVALUE;
    _12589 = NOVALUE;
    _12598 = _15float64_to_atom(_12597);
    _12597 = NOVALUE;
    DeRef(_s_21754);
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    DeRef(_12574);
    _12574 = NOVALUE;
    DeRef(_12580);
    _12580 = NOVALUE;
    DeRef(_12587);
    _12587 = NOVALUE;
    return _12598;
    goto L6; // [370] 514
LA: 

    /** 		if c = S1B then*/
    if (_c_21753 != 254)
    goto LB; // [375] 389

    /** 			len = getc(current_db)*/
    if (_59current_db_21743 != last_r_file_no) {
        last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
        last_r_file_no = _59current_db_21743;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _len_21755 = getc((FILE*)xstdin);
        }
        else
        _len_21755 = getc(last_r_file_ptr);
    }
    else
    _len_21755 = getc(last_r_file_ptr);
    goto LC; // [386] 397
LB: 

    /** 			len = get4()*/
    _len_21755 = _59get4();
    if (!IS_ATOM_INT(_len_21755)) {
        _1 = (long)(DBL_PTR(_len_21755)->dbl);
        DeRefDS(_len_21755);
        _len_21755 = _1;
    }
LC: 

    /** 		s = repeat(0, len)*/
    DeRef(_s_21754);
    _s_21754 = Repeat(0, _len_21755);

    /** 		for i = 1 to len do*/
    _12603 = _len_21755;
    {
        int _i_21828;
        _i_21828 = 1;
LD: 
        if (_i_21828 > _12603){
            goto LE; // [410] 507
        }

        /** 			c = getc(current_db)*/
        if (_59current_db_21743 != last_r_file_no) {
            last_r_file_ptr = which_file(_59current_db_21743, EF_READ);
            last_r_file_no = _59current_db_21743;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_21753 = getc((FILE*)xstdin);
            }
            else
            _c_21753 = getc(last_r_file_ptr);
        }
        else
        _c_21753 = getc(last_r_file_ptr);

        /** 			if c < I2B then*/
        if (_c_21753 >= 249)
        goto LF; // [426] 486

        /** 				if c <= CACHE0 then*/
        if (_c_21753 > 184)
        goto L10; // [434] 451

        /** 					s[i] = c + MIN1B*/
        _12607 = _c_21753 + -2;
        _2 = (int)SEQ_PTR(_s_21754);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21754 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21828);
        _1 = *(int *)_2;
        *(int *)_2 = _12607;
        if( _1 != _12607 ){
            DeRef(_1);
        }
        _12607 = NOVALUE;
        goto L11; // [448] 500
L10: 

        /** 				elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
        _12608 = 248;
        if (_c_21753 > 248)
        goto L11; // [459] 500

        /** 					s[i] = comp_cache[c - CACHE0]*/
        _12610 = _c_21753 - 184;
        _2 = (int)SEQ_PTR(_59comp_cache_21655);
        _12611 = (int)*(((s1_ptr)_2)->base + _12610);
        Ref(_12611);
        _2 = (int)SEQ_PTR(_s_21754);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21754 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21828);
        _1 = *(int *)_2;
        *(int *)_2 = _12611;
        if( _1 != _12611 ){
            DeRef(_1);
        }
        _12611 = NOVALUE;
        goto L11; // [483] 500
LF: 

        /** 				s[i] = fdecompress(c)*/
        DeRef(_12612);
        _12612 = _c_21753;
        _12613 = _59fdecompress(_12612);
        _12612 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_21754);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21754 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21828);
        _1 = *(int *)_2;
        *(int *)_2 = _12613;
        if( _1 != _12613 ){
            DeRef(_1);
        }
        _12613 = NOVALUE;
L11: 

        /** 		end for*/
        _i_21828 = _i_21828 + 1;
        goto LD; // [502] 417
LE: 
        ;
    }

    /** 		return s*/
    DeRef(_12549);
    _12549 = NOVALUE;
    DeRef(_12550);
    _12550 = NOVALUE;
    DeRef(_12552);
    _12552 = NOVALUE;
    _12553 = NOVALUE;
    DeRef(_12562);
    _12562 = NOVALUE;
    DeRef(_12574);
    _12574 = NOVALUE;
    DeRef(_12580);
    _12580 = NOVALUE;
    DeRef(_12608);
    _12608 = NOVALUE;
    DeRef(_12587);
    _12587 = NOVALUE;
    DeRef(_12598);
    _12598 = NOVALUE;
    DeRef(_12610);
    _12610 = NOVALUE;
    return _s_21754;
L6: 
    ;
}



// 0xFA63910A
