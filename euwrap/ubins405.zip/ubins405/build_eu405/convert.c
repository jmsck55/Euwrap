// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _19int_to_bytes(int _x_2131)
{
    int _a_2132 = NOVALUE;
    int _b_2133 = NOVALUE;
    int _c_2134 = NOVALUE;
    int _d_2135 = NOVALUE;
    int _941 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2131)) {
        _a_2132 = (_x_2131 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _a_2132 = Dremainder(DBL_PTR(_x_2131), &temp_d);
    }
    if (!IS_ATOM_INT(_a_2132)) {
        _1 = (long)(DBL_PTR(_a_2132)->dbl);
        DeRefDS(_a_2132);
        _a_2132 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2131;
    if (IS_ATOM_INT(_x_2131)) {
        if (256 > 0 && _x_2131 >= 0) {
            _x_2131 = _x_2131 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2131 / (double)256);
            if (_x_2131 != MININT)
            _x_2131 = (long)temp_dbl;
            else
            _x_2131 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2131, 256);
        _x_2131 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	b = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2131)) {
        _b_2133 = (_x_2131 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _b_2133 = Dremainder(DBL_PTR(_x_2131), &temp_d);
    }
    if (!IS_ATOM_INT(_b_2133)) {
        _1 = (long)(DBL_PTR(_b_2133)->dbl);
        DeRefDS(_b_2133);
        _b_2133 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2131;
    if (IS_ATOM_INT(_x_2131)) {
        if (256 > 0 && _x_2131 >= 0) {
            _x_2131 = _x_2131 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2131 / (double)256);
            if (_x_2131 != MININT)
            _x_2131 = (long)temp_dbl;
            else
            _x_2131 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2131, 256);
        _x_2131 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	c = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2131)) {
        _c_2134 = (_x_2131 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _c_2134 = Dremainder(DBL_PTR(_x_2131), &temp_d);
    }
    if (!IS_ATOM_INT(_c_2134)) {
        _1 = (long)(DBL_PTR(_c_2134)->dbl);
        DeRefDS(_c_2134);
        _c_2134 = _1;
    }

    /** 	x = floor(x / #100)*/
    _0 = _x_2131;
    if (IS_ATOM_INT(_x_2131)) {
        if (256 > 0 && _x_2131 >= 0) {
            _x_2131 = _x_2131 / 256;
        }
        else {
            temp_dbl = floor((double)_x_2131 / (double)256);
            if (_x_2131 != MININT)
            _x_2131 = (long)temp_dbl;
            else
            _x_2131 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_2131, 256);
        _x_2131 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_0);

    /** 	d = remainder(x, #100)*/
    if (IS_ATOM_INT(_x_2131)) {
        _d_2135 = (_x_2131 % 256);
    }
    else {
        temp_d.dbl = (double)256;
        _d_2135 = Dremainder(DBL_PTR(_x_2131), &temp_d);
    }
    if (!IS_ATOM_INT(_d_2135)) {
        _1 = (long)(DBL_PTR(_d_2135)->dbl);
        DeRefDS(_d_2135);
        _d_2135 = _1;
    }

    /** 	return {a,b,c,d}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _a_2132;
    *((int *)(_2+8)) = _b_2133;
    *((int *)(_2+12)) = _c_2134;
    *((int *)(_2+16)) = _d_2135;
    _941 = MAKE_SEQ(_1);
    DeRef(_x_2131);
    return _941;
    ;
}


int _19int_to_bits(int _x_2173, int _nbits_2174)
{
    int _bits_2175 = NOVALUE;
    int _mask_2176 = NOVALUE;
    int _967 = NOVALUE;
    int _966 = NOVALUE;
    int _964 = NOVALUE;
    int _961 = NOVALUE;
    int _960 = NOVALUE;
    int _959 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if nbits < 1 then*/

    /** 	bits = repeat(0, nbits)*/
    DeRef(_bits_2175);
    _bits_2175 = Repeat(0, _nbits_2174);

    /** 	if nbits <= 32 then*/

    /** 		mask = 1*/
    DeRef(_mask_2176);
    _mask_2176 = 1;

    /** 		for i = 1 to nbits do*/
    _959 = _nbits_2174;
    {
        int _i_2183;
        _i_2183 = 1;
L1: 
        if (_i_2183 > _959){
            goto L2; // [38] 72
        }

        /** 			bits[i] = and_bits(x, mask) and 1*/
        if (IS_ATOM_INT(_x_2173) && IS_ATOM_INT(_mask_2176)) {
            {unsigned long tu;
                 tu = (unsigned long)_x_2173 & (unsigned long)_mask_2176;
                 _960 = MAKE_UINT(tu);
            }
        }
        else {
            if (IS_ATOM_INT(_x_2173)) {
                temp_d.dbl = (double)_x_2173;
                _960 = Dand_bits(&temp_d, DBL_PTR(_mask_2176));
            }
            else {
                if (IS_ATOM_INT(_mask_2176)) {
                    temp_d.dbl = (double)_mask_2176;
                    _960 = Dand_bits(DBL_PTR(_x_2173), &temp_d);
                }
                else
                _960 = Dand_bits(DBL_PTR(_x_2173), DBL_PTR(_mask_2176));
            }
        }
        if (IS_ATOM_INT(_960)) {
            _961 = (_960 != 0 && 1 != 0);
        }
        else {
            temp_d.dbl = (double)1;
            _961 = Dand(DBL_PTR(_960), &temp_d);
        }
        DeRef(_960);
        _960 = NOVALUE;
        _2 = (int)SEQ_PTR(_bits_2175);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_2175 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2183);
        _1 = *(int *)_2;
        *(int *)_2 = _961;
        if( _1 != _961 ){
            DeRef(_1);
        }
        _961 = NOVALUE;

        /** 			mask *= 2*/
        _0 = _mask_2176;
        if (IS_ATOM_INT(_mask_2176) && IS_ATOM_INT(_mask_2176)) {
            _mask_2176 = _mask_2176 + _mask_2176;
            if ((long)((unsigned long)_mask_2176 + (unsigned long)HIGH_BITS) >= 0) 
            _mask_2176 = NewDouble((double)_mask_2176);
        }
        else {
            if (IS_ATOM_INT(_mask_2176)) {
                _mask_2176 = NewDouble((double)_mask_2176 + DBL_PTR(_mask_2176)->dbl);
            }
            else {
                if (IS_ATOM_INT(_mask_2176)) {
                    _mask_2176 = NewDouble(DBL_PTR(_mask_2176)->dbl + (double)_mask_2176);
                }
                else
                _mask_2176 = NewDouble(DBL_PTR(_mask_2176)->dbl + DBL_PTR(_mask_2176)->dbl);
            }
        }
        DeRef(_0);

        /** 		end for*/
        _i_2183 = _i_2183 + 1;
        goto L1; // [67] 45
L2: 
        ;
    }
    goto L3; // [72] 128

    /** 		if x < 0 then*/
    if (binary_op_a(GREATEREQ, _x_2173, 0)){
        goto L4; // [77] 92
    }

    /** 			x += power(2, nbits) -- for 2's complement bit pattern*/
    _964 = power(2, _nbits_2174);
    _0 = _x_2173;
    if (IS_ATOM_INT(_x_2173) && IS_ATOM_INT(_964)) {
        _x_2173 = _x_2173 + _964;
        if ((long)((unsigned long)_x_2173 + (unsigned long)HIGH_BITS) >= 0) 
        _x_2173 = NewDouble((double)_x_2173);
    }
    else {
        if (IS_ATOM_INT(_x_2173)) {
            _x_2173 = NewDouble((double)_x_2173 + DBL_PTR(_964)->dbl);
        }
        else {
            if (IS_ATOM_INT(_964)) {
                _x_2173 = NewDouble(DBL_PTR(_x_2173)->dbl + (double)_964);
            }
            else
            _x_2173 = NewDouble(DBL_PTR(_x_2173)->dbl + DBL_PTR(_964)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_964);
    _964 = NOVALUE;
L4: 

    /** 		for i = 1 to nbits do*/
    _966 = _nbits_2174;
    {
        int _i_2194;
        _i_2194 = 1;
L5: 
        if (_i_2194 > _966){
            goto L6; // [97] 127
        }

        /** 			bits[i] = remainder(x, 2)*/
        if (IS_ATOM_INT(_x_2173)) {
            _967 = (_x_2173 % 2);
        }
        else {
            temp_d.dbl = (double)2;
            _967 = Dremainder(DBL_PTR(_x_2173), &temp_d);
        }
        _2 = (int)SEQ_PTR(_bits_2175);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _bits_2175 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2194);
        _1 = *(int *)_2;
        *(int *)_2 = _967;
        if( _1 != _967 ){
            DeRef(_1);
        }
        _967 = NOVALUE;

        /** 			x = floor(x / 2)*/
        _0 = _x_2173;
        if (IS_ATOM_INT(_x_2173)) {
            _x_2173 = _x_2173 >> 1;
        }
        else {
            _1 = binary_op(DIVIDE, _x_2173, 2);
            _x_2173 = unary_op(FLOOR, _1);
            DeRef(_1);
        }
        DeRef(_0);

        /** 		end for*/
        _i_2194 = _i_2194 + 1;
        goto L5; // [122] 104
L6: 
        ;
    }
L3: 

    /** 	return bits*/
    DeRef(_x_2173);
    DeRef(_mask_2176);
    return _bits_2175;
    ;
}


int _19bits_to_int(int _bits_2200)
{
    int _value_2201 = NOVALUE;
    int _p_2202 = NOVALUE;
    int _970 = NOVALUE;
    int _969 = NOVALUE;
    int _0, _1, _2;
    

    /** 	value = 0*/
    DeRef(_value_2201);
    _value_2201 = 0;

    /** 	p = 1*/
    DeRef(_p_2202);
    _p_2202 = 1;

    /** 	for i = 1 to length(bits) do*/
    if (IS_SEQUENCE(_bits_2200)){
            _969 = SEQ_PTR(_bits_2200)->length;
    }
    else {
        _969 = 1;
    }
    {
        int _i_2204;
        _i_2204 = 1;
L1: 
        if (_i_2204 > _969){
            goto L2; // [18] 54
        }

        /** 		if bits[i] then*/
        _2 = (int)SEQ_PTR(_bits_2200);
        _970 = (int)*(((s1_ptr)_2)->base + _i_2204);
        if (_970 == 0) {
            _970 = NOVALUE;
            goto L3; // [31] 41
        }
        else {
            if (!IS_ATOM_INT(_970) && DBL_PTR(_970)->dbl == 0.0){
                _970 = NOVALUE;
                goto L3; // [31] 41
            }
            _970 = NOVALUE;
        }
        _970 = NOVALUE;

        /** 			value += p*/
        _0 = _value_2201;
        if (IS_ATOM_INT(_value_2201) && IS_ATOM_INT(_p_2202)) {
            _value_2201 = _value_2201 + _p_2202;
            if ((long)((unsigned long)_value_2201 + (unsigned long)HIGH_BITS) >= 0) 
            _value_2201 = NewDouble((double)_value_2201);
        }
        else {
            if (IS_ATOM_INT(_value_2201)) {
                _value_2201 = NewDouble((double)_value_2201 + DBL_PTR(_p_2202)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2202)) {
                    _value_2201 = NewDouble(DBL_PTR(_value_2201)->dbl + (double)_p_2202);
                }
                else
                _value_2201 = NewDouble(DBL_PTR(_value_2201)->dbl + DBL_PTR(_p_2202)->dbl);
            }
        }
        DeRef(_0);
L3: 

        /** 		p += p*/
        _0 = _p_2202;
        if (IS_ATOM_INT(_p_2202) && IS_ATOM_INT(_p_2202)) {
            _p_2202 = _p_2202 + _p_2202;
            if ((long)((unsigned long)_p_2202 + (unsigned long)HIGH_BITS) >= 0) 
            _p_2202 = NewDouble((double)_p_2202);
        }
        else {
            if (IS_ATOM_INT(_p_2202)) {
                _p_2202 = NewDouble((double)_p_2202 + DBL_PTR(_p_2202)->dbl);
            }
            else {
                if (IS_ATOM_INT(_p_2202)) {
                    _p_2202 = NewDouble(DBL_PTR(_p_2202)->dbl + (double)_p_2202);
                }
                else
                _p_2202 = NewDouble(DBL_PTR(_p_2202)->dbl + DBL_PTR(_p_2202)->dbl);
            }
        }
        DeRef(_0);

        /** 	end for*/
        _i_2204 = _i_2204 + 1;
        goto L1; // [49] 25
L2: 
        ;
    }

    /** 	return value*/
    DeRefDS(_bits_2200);
    DeRef(_p_2202);
    return _value_2201;
    ;
}


int _19atom_to_float64(int _a_2212)
{
    int _973 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F64, a)*/
    _973 = machine(46, _a_2212);
    DeRef(_a_2212);
    return _973;
    ;
}


int _19atom_to_float32(int _a_2216)
{
    int _974 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_A_TO_F32, a)*/
    _974 = machine(48, _a_2216);
    DeRef(_a_2216);
    return _974;
    ;
}


int _19float64_to_atom(int _ieee64_2220)
{
    int _975 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F64_TO_A, ieee64)*/
    _975 = machine(47, _ieee64_2220);
    DeRefDS(_ieee64_2220);
    return _975;
    ;
}


int _19float32_to_atom(int _ieee32_2224)
{
    int _976 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    _976 = machine(49, _ieee32_2224);
    DeRefDS(_ieee32_2224);
    return _976;
    ;
}


int _19to_number(int _text_in_2302, int _return_bad_pos_2303)
{
    int _lDotFound_2304 = NOVALUE;
    int _lSignFound_2305 = NOVALUE;
    int _lCharValue_2306 = NOVALUE;
    int _lBadPos_2307 = NOVALUE;
    int _lLeftSize_2308 = NOVALUE;
    int _lRightSize_2309 = NOVALUE;
    int _lLeftValue_2310 = NOVALUE;
    int _lRightValue_2311 = NOVALUE;
    int _lBase_2312 = NOVALUE;
    int _lPercent_2313 = NOVALUE;
    int _lResult_2314 = NOVALUE;
    int _lDigitCount_2315 = NOVALUE;
    int _lCurrencyFound_2316 = NOVALUE;
    int _lLastDigit_2317 = NOVALUE;
    int _lChar_2318 = NOVALUE;
    int _1097 = NOVALUE;
    int _1096 = NOVALUE;
    int _1089 = NOVALUE;
    int _1087 = NOVALUE;
    int _1086 = NOVALUE;
    int _1081 = NOVALUE;
    int _1080 = NOVALUE;
    int _1079 = NOVALUE;
    int _1078 = NOVALUE;
    int _1077 = NOVALUE;
    int _1076 = NOVALUE;
    int _1072 = NOVALUE;
    int _1068 = NOVALUE;
    int _1060 = NOVALUE;
    int _1049 = NOVALUE;
    int _1048 = NOVALUE;
    int _1042 = NOVALUE;
    int _1040 = NOVALUE;
    int _1034 = NOVALUE;
    int _1033 = NOVALUE;
    int _1032 = NOVALUE;
    int _1031 = NOVALUE;
    int _1030 = NOVALUE;
    int _1029 = NOVALUE;
    int _1028 = NOVALUE;
    int _1027 = NOVALUE;
    int _1026 = NOVALUE;
    int _1018 = NOVALUE;
    int _1017 = NOVALUE;
    int _1016 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer lDotFound = 0*/
    _lDotFound_2304 = 0;

    /** 	integer lSignFound = 2*/
    _lSignFound_2305 = 2;

    /** 	integer lBadPos = 0*/
    _lBadPos_2307 = 0;

    /** 	atom    lLeftSize = 0*/
    DeRef(_lLeftSize_2308);
    _lLeftSize_2308 = 0;

    /** 	atom    lRightSize = 1*/
    DeRef(_lRightSize_2309);
    _lRightSize_2309 = 1;

    /** 	atom    lLeftValue = 0*/
    DeRef(_lLeftValue_2310);
    _lLeftValue_2310 = 0;

    /** 	atom    lRightValue = 0*/
    DeRef(_lRightValue_2311);
    _lRightValue_2311 = 0;

    /** 	integer lBase = 10*/
    _lBase_2312 = 10;

    /** 	integer lPercent = 1*/
    _lPercent_2313 = 1;

    /** 	integer lDigitCount = 0*/
    _lDigitCount_2315 = 0;

    /** 	integer lCurrencyFound = 0*/
    _lCurrencyFound_2316 = 0;

    /** 	integer lLastDigit = 0*/
    _lLastDigit_2317 = 0;

    /** 	for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_2302)){
            _1016 = SEQ_PTR(_text_in_2302)->length;
    }
    else {
        _1016 = 1;
    }
    {
        int _i_2320;
        _i_2320 = 1;
L1: 
        if (_i_2320 > _1016){
            goto L2; // [70] 672
        }

        /** 		if not integer(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_2302);
        _1017 = (int)*(((s1_ptr)_2)->base + _i_2320);
        if (IS_ATOM_INT(_1017))
        _1018 = 1;
        else if (IS_ATOM_DBL(_1017))
        _1018 = IS_ATOM_INT(DoubleToInt(_1017));
        else
        _1018 = 0;
        _1017 = NOVALUE;
        if (_1018 != 0)
        goto L3; // [86] 94
        _1018 = NOVALUE;

        /** 			exit*/
        goto L2; // [91] 672
L3: 

        /** 		lChar = text_in[i]*/
        _2 = (int)SEQ_PTR(_text_in_2302);
        _lChar_2318 = (int)*(((s1_ptr)_2)->base + _i_2320);
        if (!IS_ATOM_INT(_lChar_2318))
        _lChar_2318 = (long)DBL_PTR(_lChar_2318)->dbl;

        /** 		switch lChar do*/
        _0 = _lChar_2318;
        switch ( _0 ){ 

            /** 			case '-' then*/
            case 45:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2305 != 2)
            goto L4; // [113] 130

            /** 					lSignFound = -1*/
            _lSignFound_2305 = -1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2317 = _lDigitCount_2315;
            goto L5; // [127] 654
L4: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [136] 654

            /** 			case '+' then*/
            case 43:

            /** 				if lSignFound = 2 then*/
            if (_lSignFound_2305 != 2)
            goto L6; // [144] 161

            /** 					lSignFound = 1*/
            _lSignFound_2305 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2317 = _lDigitCount_2315;
            goto L5; // [158] 654
L6: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [167] 654

            /** 			case '#' then*/
            case 35:

            /** 				if lDigitCount = 0 and lBase = 10 then*/
            _1026 = (_lDigitCount_2315 == 0);
            if (_1026 == 0) {
                goto L7; // [179] 199
            }
            _1028 = (_lBase_2312 == 10);
            if (_1028 == 0)
            {
                DeRef(_1028);
                _1028 = NOVALUE;
                goto L7; // [188] 199
            }
            else{
                DeRef(_1028);
                _1028 = NOVALUE;
            }

            /** 					lBase = 16*/
            _lBase_2312 = 16;
            goto L5; // [196] 654
L7: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [205] 654

            /** 			case '@' then*/
            case 64:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _1029 = (_lDigitCount_2315 == 0);
            if (_1029 == 0) {
                goto L8; // [217] 237
            }
            _1031 = (_lBase_2312 == 10);
            if (_1031 == 0)
            {
                DeRef(_1031);
                _1031 = NOVALUE;
                goto L8; // [226] 237
            }
            else{
                DeRef(_1031);
                _1031 = NOVALUE;
            }

            /** 					lBase = 8*/
            _lBase_2312 = 8;
            goto L5; // [234] 654
L8: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [243] 654

            /** 			case '!' then*/
            case 33:

            /** 				if lDigitCount = 0  and lBase = 10 then*/
            _1032 = (_lDigitCount_2315 == 0);
            if (_1032 == 0) {
                goto L9; // [255] 275
            }
            _1034 = (_lBase_2312 == 10);
            if (_1034 == 0)
            {
                DeRef(_1034);
                _1034 = NOVALUE;
                goto L9; // [264] 275
            }
            else{
                DeRef(_1034);
                _1034 = NOVALUE;
            }

            /** 					lBase = 2*/
            _lBase_2312 = 2;
            goto L5; // [272] 654
L9: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [281] 654

            /** 			case '$', '�', '�', '�', '�' then*/
            case 36:
            case 163:
            case 164:
            case 165:
            case 128:

            /** 				if lCurrencyFound = 0 then*/
            if (_lCurrencyFound_2316 != 0)
            goto LA; // [297] 314

            /** 					lCurrencyFound = 1*/
            _lCurrencyFound_2316 = 1;

            /** 					lLastDigit = lDigitCount*/
            _lLastDigit_2317 = _lDigitCount_2315;
            goto L5; // [311] 654
LA: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [320] 654

            /** 			case '_' then -- grouping character*/
            case 95:

            /** 				if lDigitCount = 0 or lLastDigit != 0 then*/
            _1040 = (_lDigitCount_2315 == 0);
            if (_1040 != 0) {
                goto LB; // [332] 345
            }
            _1042 = (_lLastDigit_2317 != 0);
            if (_1042 == 0)
            {
                DeRef(_1042);
                _1042 = NOVALUE;
                goto L5; // [341] 654
            }
            else{
                DeRef(_1042);
                _1042 = NOVALUE;
            }
LB: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [351] 654

            /** 			case '.', ',' then*/
            case 46:
            case 44:

            /** 				if lLastDigit = 0 then*/
            if (_lLastDigit_2317 != 0)
            goto LC; // [361] 400

            /** 					if decimal_mark = lChar then*/
            if (46 != _lChar_2318)
            goto L5; // [369] 654

            /** 						if lDotFound = 0 then*/
            if (_lDotFound_2304 != 0)
            goto LD; // [375] 387

            /** 							lDotFound = 1*/
            _lDotFound_2304 = 1;
            goto L5; // [384] 654
LD: 

            /** 							lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [393] 654
            goto L5; // [397] 654
LC: 

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [406] 654

            /** 			case '%' then*/
            case 37:

            /** 				lLastDigit = lDigitCount*/
            _lLastDigit_2317 = _lDigitCount_2315;

            /** 				if lPercent = 1 then*/
            if (_lPercent_2313 != 1)
            goto LE; // [419] 431

            /** 					lPercent = 100*/
            _lPercent_2313 = 100;
            goto L5; // [428] 654
LE: 

            /** 					if text_in[i-1] = '%' then*/
            _1048 = _i_2320 - 1;
            _2 = (int)SEQ_PTR(_text_in_2302);
            _1049 = (int)*(((s1_ptr)_2)->base + _1048);
            if (binary_op_a(NOTEQ, _1049, 37)){
                _1049 = NOVALUE;
                goto LF; // [441] 456
            }
            _1049 = NOVALUE;

            /** 						lPercent *= 10 -- Yes ten not one hundred.*/
            _lPercent_2313 = _lPercent_2313 * 10;
            goto L5; // [453] 654
LF: 

            /** 						lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [463] 654

            /** 			case '\t', ' ', #A0 then*/
            case 9:
            case 32:
            case 160:

            /** 				if lDigitCount = 0 then*/
            if (_lDigitCount_2315 != 0)
            goto L10; // [475] 482
            goto L5; // [479] 654
L10: 

            /** 					lLastDigit = i*/
            _lLastDigit_2317 = _i_2320;
            goto L5; // [488] 654

            /** 			case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9',*/
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
            case 65:
            case 66:
            case 67:
            case 68:
            case 69:
            case 70:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:

            /** 	            lCharValue = find(lChar, vDigits) - 1*/
            _1060 = find_from(_lChar_2318, _19vDigits_2289, 1);
            _lCharValue_2306 = _1060 - 1;
            _1060 = NOVALUE;

            /** 	            if lCharValue > 15 then*/
            if (_lCharValue_2306 <= 15)
            goto L11; // [549] 560

            /** 	            	lCharValue -= 6*/
            _lCharValue_2306 = _lCharValue_2306 - 6;
L11: 

            /** 	            if lCharValue >= lBase then*/
            if (_lCharValue_2306 < _lBase_2312)
            goto L12; // [562] 574

            /** 	                lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [571] 654
L12: 

            /** 	            elsif lLastDigit != 0 then  -- shouldn't be any more digits*/
            if (_lLastDigit_2317 == 0)
            goto L13; // [576] 588

            /** 					lBadPos = i*/
            _lBadPos_2307 = _i_2320;
            goto L5; // [585] 654
L13: 

            /** 				elsif lDotFound = 1 then*/
            if (_lDotFound_2304 != 1)
            goto L14; // [590] 619

            /** 					lRightSize *= lBase*/
            _0 = _lRightSize_2309;
            if (IS_ATOM_INT(_lRightSize_2309)) {
                if (_lRightSize_2309 == (short)_lRightSize_2309 && _lBase_2312 <= INT15 && _lBase_2312 >= -INT15)
                _lRightSize_2309 = _lRightSize_2309 * _lBase_2312;
                else
                _lRightSize_2309 = NewDouble(_lRightSize_2309 * (double)_lBase_2312);
            }
            else {
                _lRightSize_2309 = NewDouble(DBL_PTR(_lRightSize_2309)->dbl * (double)_lBase_2312);
            }
            DeRef(_0);

            /** 					lRightValue = (lRightValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lRightValue_2311)) {
                if (_lRightValue_2311 == (short)_lRightValue_2311 && _lBase_2312 <= INT15 && _lBase_2312 >= -INT15)
                _1068 = _lRightValue_2311 * _lBase_2312;
                else
                _1068 = NewDouble(_lRightValue_2311 * (double)_lBase_2312);
            }
            else {
                _1068 = NewDouble(DBL_PTR(_lRightValue_2311)->dbl * (double)_lBase_2312);
            }
            DeRef(_lRightValue_2311);
            if (IS_ATOM_INT(_1068)) {
                _lRightValue_2311 = _1068 + _lCharValue_2306;
                if ((long)((unsigned long)_lRightValue_2311 + (unsigned long)HIGH_BITS) >= 0) 
                _lRightValue_2311 = NewDouble((double)_lRightValue_2311);
            }
            else {
                _lRightValue_2311 = NewDouble(DBL_PTR(_1068)->dbl + (double)_lCharValue_2306);
            }
            DeRef(_1068);
            _1068 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2315 = _lDigitCount_2315 + 1;
            goto L5; // [616] 654
L14: 

            /** 					lLeftSize += 1*/
            _0 = _lLeftSize_2308;
            if (IS_ATOM_INT(_lLeftSize_2308)) {
                _lLeftSize_2308 = _lLeftSize_2308 + 1;
                if (_lLeftSize_2308 > MAXINT){
                    _lLeftSize_2308 = NewDouble((double)_lLeftSize_2308);
                }
            }
            else
            _lLeftSize_2308 = binary_op(PLUS, 1, _lLeftSize_2308);
            DeRef(_0);

            /** 					lLeftValue = (lLeftValue * lBase) + lCharValue*/
            if (IS_ATOM_INT(_lLeftValue_2310)) {
                if (_lLeftValue_2310 == (short)_lLeftValue_2310 && _lBase_2312 <= INT15 && _lBase_2312 >= -INT15)
                _1072 = _lLeftValue_2310 * _lBase_2312;
                else
                _1072 = NewDouble(_lLeftValue_2310 * (double)_lBase_2312);
            }
            else {
                _1072 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl * (double)_lBase_2312);
            }
            DeRef(_lLeftValue_2310);
            if (IS_ATOM_INT(_1072)) {
                _lLeftValue_2310 = _1072 + _lCharValue_2306;
                if ((long)((unsigned long)_lLeftValue_2310 + (unsigned long)HIGH_BITS) >= 0) 
                _lLeftValue_2310 = NewDouble((double)_lLeftValue_2310);
            }
            else {
                _lLeftValue_2310 = NewDouble(DBL_PTR(_1072)->dbl + (double)_lCharValue_2306);
            }
            DeRef(_1072);
            _1072 = NOVALUE;

            /** 					lDigitCount += 1*/
            _lDigitCount_2315 = _lDigitCount_2315 + 1;
            goto L5; // [642] 654

            /** 			case else*/
            default:

            /** 				lBadPos = i*/
            _lBadPos_2307 = _i_2320;
        ;}L5: 

        /** 		if lBadPos != 0 then*/
        if (_lBadPos_2307 == 0)
        goto L15; // [656] 665

        /** 			exit*/
        goto L2; // [662] 672
L15: 

        /** 	end for*/
        _i_2320 = _i_2320 + 1;
        goto L1; // [667] 77
L2: 
        ;
    }

    /** 	if lBadPos = 0 and lDigitCount = 0 then*/
    _1076 = (_lBadPos_2307 == 0);
    if (_1076 == 0) {
        goto L16; // [678] 696
    }
    _1078 = (_lDigitCount_2315 == 0);
    if (_1078 == 0)
    {
        DeRef(_1078);
        _1078 = NOVALUE;
        goto L16; // [687] 696
    }
    else{
        DeRef(_1078);
        _1078 = NOVALUE;
    }

    /** 		lBadPos = 1*/
    _lBadPos_2307 = 1;
L16: 

    /** 	if return_bad_pos = 0 and lBadPos != 0 then*/
    _1079 = (_return_bad_pos_2303 == 0);
    if (_1079 == 0) {
        goto L17; // [702] 721
    }
    _1081 = (_lBadPos_2307 != 0);
    if (_1081 == 0)
    {
        DeRef(_1081);
        _1081 = NOVALUE;
        goto L17; // [711] 721
    }
    else{
        DeRef(_1081);
        _1081 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_text_in_2302);
    DeRef(_lLeftSize_2308);
    DeRef(_lRightSize_2309);
    DeRef(_lLeftValue_2310);
    DeRef(_lRightValue_2311);
    DeRef(_lResult_2314);
    DeRef(_1026);
    _1026 = NOVALUE;
    DeRef(_1029);
    _1029 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    DeRef(_1040);
    _1040 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1076);
    _1076 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return 0;
L17: 

    /** 	if lRightValue = 0 then*/
    if (binary_op_a(NOTEQ, _lRightValue_2311, 0)){
        goto L18; // [723] 751
    }

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2313 == 1)
    goto L19; // [729] 742

    /** 			lResult = (lLeftValue / lPercent)*/
    DeRef(_lResult_2314);
    if (IS_ATOM_INT(_lLeftValue_2310)) {
        _lResult_2314 = (_lLeftValue_2310 % _lPercent_2313) ? NewDouble((double)_lLeftValue_2310 / _lPercent_2313) : (_lLeftValue_2310 / _lPercent_2313);
    }
    else {
        _lResult_2314 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl / (double)_lPercent_2313);
    }
    goto L1A; // [739] 786
L19: 

    /** 	        lResult = lLeftValue*/
    Ref(_lLeftValue_2310);
    DeRef(_lResult_2314);
    _lResult_2314 = _lLeftValue_2310;
    goto L1A; // [748] 786
L18: 

    /** 	    if lPercent != 1 then*/
    if (_lPercent_2313 == 1)
    goto L1B; // [753] 774

    /** 	        lResult = (lLeftValue  + (lRightValue / (lRightSize))) / lPercent*/
    if (IS_ATOM_INT(_lRightValue_2311) && IS_ATOM_INT(_lRightSize_2309)) {
        _1086 = (_lRightValue_2311 % _lRightSize_2309) ? NewDouble((double)_lRightValue_2311 / _lRightSize_2309) : (_lRightValue_2311 / _lRightSize_2309);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2311)) {
            _1086 = NewDouble((double)_lRightValue_2311 / DBL_PTR(_lRightSize_2309)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2309)) {
                _1086 = NewDouble(DBL_PTR(_lRightValue_2311)->dbl / (double)_lRightSize_2309);
            }
            else
            _1086 = NewDouble(DBL_PTR(_lRightValue_2311)->dbl / DBL_PTR(_lRightSize_2309)->dbl);
        }
    }
    if (IS_ATOM_INT(_lLeftValue_2310) && IS_ATOM_INT(_1086)) {
        _1087 = _lLeftValue_2310 + _1086;
        if ((long)((unsigned long)_1087 + (unsigned long)HIGH_BITS) >= 0) 
        _1087 = NewDouble((double)_1087);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2310)) {
            _1087 = NewDouble((double)_lLeftValue_2310 + DBL_PTR(_1086)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1086)) {
                _1087 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl + (double)_1086);
            }
            else
            _1087 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl + DBL_PTR(_1086)->dbl);
        }
    }
    DeRef(_1086);
    _1086 = NOVALUE;
    DeRef(_lResult_2314);
    if (IS_ATOM_INT(_1087)) {
        _lResult_2314 = (_1087 % _lPercent_2313) ? NewDouble((double)_1087 / _lPercent_2313) : (_1087 / _lPercent_2313);
    }
    else {
        _lResult_2314 = NewDouble(DBL_PTR(_1087)->dbl / (double)_lPercent_2313);
    }
    DeRef(_1087);
    _1087 = NOVALUE;
    goto L1C; // [771] 785
L1B: 

    /** 	        lResult = lLeftValue + (lRightValue / lRightSize)*/
    if (IS_ATOM_INT(_lRightValue_2311) && IS_ATOM_INT(_lRightSize_2309)) {
        _1089 = (_lRightValue_2311 % _lRightSize_2309) ? NewDouble((double)_lRightValue_2311 / _lRightSize_2309) : (_lRightValue_2311 / _lRightSize_2309);
    }
    else {
        if (IS_ATOM_INT(_lRightValue_2311)) {
            _1089 = NewDouble((double)_lRightValue_2311 / DBL_PTR(_lRightSize_2309)->dbl);
        }
        else {
            if (IS_ATOM_INT(_lRightSize_2309)) {
                _1089 = NewDouble(DBL_PTR(_lRightValue_2311)->dbl / (double)_lRightSize_2309);
            }
            else
            _1089 = NewDouble(DBL_PTR(_lRightValue_2311)->dbl / DBL_PTR(_lRightSize_2309)->dbl);
        }
    }
    DeRef(_lResult_2314);
    if (IS_ATOM_INT(_lLeftValue_2310) && IS_ATOM_INT(_1089)) {
        _lResult_2314 = _lLeftValue_2310 + _1089;
        if ((long)((unsigned long)_lResult_2314 + (unsigned long)HIGH_BITS) >= 0) 
        _lResult_2314 = NewDouble((double)_lResult_2314);
    }
    else {
        if (IS_ATOM_INT(_lLeftValue_2310)) {
            _lResult_2314 = NewDouble((double)_lLeftValue_2310 + DBL_PTR(_1089)->dbl);
        }
        else {
            if (IS_ATOM_INT(_1089)) {
                _lResult_2314 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl + (double)_1089);
            }
            else
            _lResult_2314 = NewDouble(DBL_PTR(_lLeftValue_2310)->dbl + DBL_PTR(_1089)->dbl);
        }
    }
    DeRef(_1089);
    _1089 = NOVALUE;
L1C: 
L1A: 

    /** 	if lSignFound < 0 then*/
    if (_lSignFound_2305 >= 0)
    goto L1D; // [788] 800

    /** 		lResult = -lResult*/
    _0 = _lResult_2314;
    if (IS_ATOM_INT(_lResult_2314)) {
        if ((unsigned long)_lResult_2314 == 0xC0000000)
        _lResult_2314 = (int)NewDouble((double)-0xC0000000);
        else
        _lResult_2314 = - _lResult_2314;
    }
    else {
        _lResult_2314 = unary_op(UMINUS, _lResult_2314);
    }
    DeRef(_0);
L1D: 

    /** 	if return_bad_pos = 0 then*/
    if (_return_bad_pos_2303 != 0)
    goto L1E; // [802] 815

    /** 		return lResult*/
    DeRefDS(_text_in_2302);
    DeRef(_lLeftSize_2308);
    DeRef(_lRightSize_2309);
    DeRef(_lLeftValue_2310);
    DeRef(_lRightValue_2311);
    DeRef(_1026);
    _1026 = NOVALUE;
    DeRef(_1029);
    _1029 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    DeRef(_1040);
    _1040 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1076);
    _1076 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return _lResult_2314;
L1E: 

    /** 	if return_bad_pos = -1 then*/
    if (_return_bad_pos_2303 != -1)
    goto L1F; // [817] 850

    /** 		if lBadPos = 0 then*/
    if (_lBadPos_2307 != 0)
    goto L20; // [823] 838

    /** 			return lResult*/
    DeRefDS(_text_in_2302);
    DeRef(_lLeftSize_2308);
    DeRef(_lRightSize_2309);
    DeRef(_lLeftValue_2310);
    DeRef(_lRightValue_2311);
    DeRef(_1026);
    _1026 = NOVALUE;
    DeRef(_1029);
    _1029 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    DeRef(_1040);
    _1040 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1076);
    _1076 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return _lResult_2314;
    goto L21; // [835] 849
L20: 

    /** 			return {lBadPos}	*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _lBadPos_2307;
    _1096 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2302);
    DeRef(_lLeftSize_2308);
    DeRef(_lRightSize_2309);
    DeRef(_lLeftValue_2310);
    DeRef(_lRightValue_2311);
    DeRef(_lResult_2314);
    DeRef(_1026);
    _1026 = NOVALUE;
    DeRef(_1029);
    _1029 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    DeRef(_1040);
    _1040 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1076);
    _1076 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    return _1096;
L21: 
L1F: 

    /** 	return {lResult, lBadPos}*/
    Ref(_lResult_2314);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lResult_2314;
    ((int *)_2)[2] = _lBadPos_2307;
    _1097 = MAKE_SEQ(_1);
    DeRefDS(_text_in_2302);
    DeRef(_lLeftSize_2308);
    DeRef(_lRightSize_2309);
    DeRef(_lLeftValue_2310);
    DeRef(_lRightValue_2311);
    DeRef(_lResult_2314);
    DeRef(_1026);
    _1026 = NOVALUE;
    DeRef(_1029);
    _1029 = NOVALUE;
    DeRef(_1032);
    _1032 = NOVALUE;
    DeRef(_1040);
    _1040 = NOVALUE;
    DeRef(_1048);
    _1048 = NOVALUE;
    DeRef(_1076);
    _1076 = NOVALUE;
    DeRef(_1079);
    _1079 = NOVALUE;
    DeRef(_1096);
    _1096 = NOVALUE;
    return _1097;
    ;
}



// 0x2D5F645A
