// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _5valid_memory_protection_constant(int _x_263)
{
    int _40 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find( x, MEMORY_PROTECTION )*/
    _40 = find_from(_x_263, _5MEMORY_PROTECTION_259, 1);
    DeRef(_x_263);
    return _40;
    ;
}


int _5test_read(int _protection_267)
{
    int _42 = NOVALUE;
    int _41 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_READ,protection) != 0*/
    if (IS_ATOM_INT(_protection_267)) {
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_protection_267;
             _41 = MAKE_UINT(tu);
        }
    }
    else {
        _41 = binary_op(AND_BITS, 1, _protection_267);
    }
    if (IS_ATOM_INT(_41)) {
        _42 = (_41 != 0);
    }
    else {
        _42 = binary_op(NOTEQ, _41, 0);
    }
    DeRef(_41);
    _41 = NOVALUE;
    DeRef(_protection_267);
    return _42;
    ;
}


int _5test_write(int _protection_272)
{
    int _44 = NOVALUE;
    int _43 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_WRITE,protection) != 0*/
    if (IS_ATOM_INT(_protection_272)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_protection_272;
             _43 = MAKE_UINT(tu);
        }
    }
    else {
        _43 = binary_op(AND_BITS, 2, _protection_272);
    }
    if (IS_ATOM_INT(_43)) {
        _44 = (_43 != 0);
    }
    else {
        _44 = binary_op(NOTEQ, _43, 0);
    }
    DeRef(_43);
    _43 = NOVALUE;
    DeRef(_protection_272);
    return _44;
    ;
}


int _5test_exec(int _protection_277)
{
    int _46 = NOVALUE;
    int _45 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return and_bits(PROT_EXEC,protection) != 0*/
    if (IS_ATOM_INT(_protection_277)) {
        {unsigned long tu;
             tu = (unsigned long)4 & (unsigned long)_protection_277;
             _45 = MAKE_UINT(tu);
        }
    }
    else {
        _45 = binary_op(AND_BITS, 4, _protection_277);
    }
    if (IS_ATOM_INT(_45)) {
        _46 = (_45 != 0);
    }
    else {
        _46 = binary_op(NOTEQ, _45, 0);
    }
    DeRef(_45);
    _45 = NOVALUE;
    DeRef(_protection_277);
    return _46;
    ;
}


int _5valid_wordsize(int _i_282)
{
    int _48 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(i, {1,2,4})*/
    _48 = find_from(_i_282, _47, 1);
    DeRef(_i_282);
    return _48;
    ;
}



// 0xDE682C63
