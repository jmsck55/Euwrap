// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _4allocate(int _n_977, int _cleanup_978)
{
    int _iaddr_979 = NOVALUE;
    int _eaddr_980 = NOVALUE;
    int _373 = NOVALUE;
    int _372 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE then*/

    /** 		iaddr = eu:machine_func( memconst:M_ALLOC, n + memory:BORDER_SPACE * 2)*/
    _372 = 0;
    _373 = _n_977 + 0;
    _372 = NOVALUE;
    DeRef(_iaddr_979);
    _iaddr_979 = machine(16, _373);
    _373 = NOVALUE;

    /** 		eaddr = memory:prepare_block( iaddr, n, PAGE_READ_WRITE )*/
    Ref(_iaddr_979);
    Ref(_5PAGE_READ_WRITE_254);
    _0 = _eaddr_980;
    _eaddr_980 = _6prepare_block(_iaddr_979, _n_977, _5PAGE_READ_WRITE_254);
    DeRef(_0);

    /** 	if cleanup then*/

    /** 	return eaddr*/
    DeRef(_iaddr_979);
    return _eaddr_980;
    ;
}


int _4allocate_string(int _s_1118, int _cleanup_1119)
{
    int _mem_1120 = NOVALUE;
    int _439 = NOVALUE;
    int _438 = NOVALUE;
    int _436 = NOVALUE;
    int _435 = NOVALUE;
    int _0, _1, _2;
    

    /** 	mem = allocate( length(s) + 1) -- Thanks to Igor*/
    if (IS_SEQUENCE(_s_1118)){
            _435 = SEQ_PTR(_s_1118)->length;
    }
    else {
        _435 = 1;
    }
    _436 = _435 + 1;
    _435 = NOVALUE;
    _0 = _mem_1120;
    _mem_1120 = _4allocate(_436, 0);
    DeRef(_0);
    _436 = NOVALUE;

    /** 	if mem then*/
    if (_mem_1120 == 0) {
        goto L1; // [19] 54
    }
    else {
        if (!IS_ATOM_INT(_mem_1120) && DBL_PTR(_mem_1120)->dbl == 0.0){
            goto L1; // [19] 54
        }
    }

    /** 		poke(mem, s)*/
    if (IS_ATOM_INT(_mem_1120)){
        poke_addr = (unsigned char *)_mem_1120;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_mem_1120)->dbl);
    }
    _1 = (int)SEQ_PTR(_s_1118);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke(mem+length(s), 0)  -- Thanks to Aku*/
    if (IS_SEQUENCE(_s_1118)){
            _438 = SEQ_PTR(_s_1118)->length;
    }
    else {
        _438 = 1;
    }
    if (IS_ATOM_INT(_mem_1120)) {
        _439 = _mem_1120 + _438;
        if ((long)((unsigned long)_439 + (unsigned long)HIGH_BITS) >= 0) 
        _439 = NewDouble((double)_439);
    }
    else {
        _439 = NewDouble(DBL_PTR(_mem_1120)->dbl + (double)_438);
    }
    _438 = NOVALUE;
    if (IS_ATOM_INT(_439)){
        poke_addr = (unsigned char *)_439;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_439)->dbl);
    }
    *poke_addr = (unsigned char)0;
    DeRef(_439);
    _439 = NOVALUE;

    /** 		if cleanup then*/
L1: 

    /** 	return mem*/
    DeRefDS(_s_1118);
    return _mem_1120;
    ;
}


int _4allocate_protect(int _data_1131, int _wordsize_1132, int _protection_1134)
{
    int _iaddr_1135 = NOVALUE;
    int _eaddr_1137 = NOVALUE;
    int _size_1138 = NOVALUE;
    int _first_protection_1140 = NOVALUE;
    int _true_protection_1142 = NOVALUE;
    int _prepare_block_inlined_prepare_block_at_104_1157 = NOVALUE;
    int _msg_inlined_crash_at_186_1170 = NOVALUE;
    int _460 = NOVALUE;
    int _459 = NOVALUE;
    int _457 = NOVALUE;
    int _456 = NOVALUE;
    int _455 = NOVALUE;
    int _451 = NOVALUE;
    int _449 = NOVALUE;
    int _446 = NOVALUE;
    int _445 = NOVALUE;
    int _443 = NOVALUE;
    int _441 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom iaddr = 0*/
    DeRef(_iaddr_1135);
    _iaddr_1135 = 0;

    /** 	integer size*/

    /** 	valid_memory_protection_constant true_protection = protection*/
    Ref(_protection_1134);
    DeRef(_true_protection_1142);
    _true_protection_1142 = _protection_1134;

    /** 	ifdef SAFE then	*/

    /** 	if atom(data) then*/
    _441 = 1;
    if (_441 == 0)
    {
        _441 = NOVALUE;
        goto L1; // [20] 39
    }
    else{
        _441 = NOVALUE;
    }

    /** 		size = data * wordsize*/
    _size_1138 = _data_1131 * 1;

    /** 		first_protection = true_protection*/
    Ref(_true_protection_1142);
    DeRef(_first_protection_1140);
    _first_protection_1140 = _true_protection_1142;
    goto L2; // [36] 58
L1: 

    /** 		size = length(data) * wordsize*/
    _443 = 1;
    _size_1138 = 1 * _wordsize_1132;
    _443 = NOVALUE;

    /** 		first_protection = PAGE_READ_WRITE*/
    Ref(_5PAGE_READ_WRITE_254);
    DeRef(_first_protection_1140);
    _first_protection_1140 = _5PAGE_READ_WRITE_254;
L2: 

    /** 	iaddr = local_allocate_protected_memory( size + memory:BORDER_SPACE * 2, first_protection )*/
    _445 = 0;
    _446 = _size_1138 + 0;
    _445 = NOVALUE;
    Ref(_first_protection_1140);
    _0 = _iaddr_1135;
    _iaddr_1135 = _4local_allocate_protected_memory(_446, _first_protection_1140);
    DeRef(_0);
    _446 = NOVALUE;

    /** 	if iaddr = 0 then*/
    if (binary_op_a(NOTEQ, _iaddr_1135, 0)){
        goto L3; // [79] 90
    }

    /** 		return 0*/
    DeRef(_protection_1134);
    DeRef(_iaddr_1135);
    DeRef(_eaddr_1137);
    DeRef(_first_protection_1140);
    DeRef(_true_protection_1142);
    return 0;
L3: 

    /** 	eaddr = memory:prepare_block( iaddr, size, protection )*/
    if (!IS_ATOM_INT(_protection_1134)) {
        _1 = (long)(DBL_PTR(_protection_1134)->dbl);
        DeRefDS(_protection_1134);
        _protection_1134 = _1;
    }

    /** 	return addr*/
    Ref(_iaddr_1135);
    DeRef(_eaddr_1137);
    _eaddr_1137 = _iaddr_1135;

    /** 	if eaddr = 0 or atom( data ) then*/
    if (IS_ATOM_INT(_eaddr_1137)) {
        _449 = (_eaddr_1137 == 0);
    }
    else {
        _449 = (DBL_PTR(_eaddr_1137)->dbl == (double)0);
    }
    if (_449 != 0) {
        goto L4; // [106] 118
    }
    _451 = 1;
    if (_451 == 0)
    {
        _451 = NOVALUE;
        goto L5; // [114] 125
    }
    else{
        _451 = NOVALUE;
    }
L4: 

    /** 		return eaddr*/
    DeRef(_protection_1134);
    DeRef(_iaddr_1135);
    DeRef(_first_protection_1140);
    DeRef(_true_protection_1142);
    DeRef(_449);
    _449 = NOVALUE;
    return _eaddr_1137;
L5: 

    /** 	switch wordsize do*/
    _0 = _wordsize_1132;
    switch ( _0 ){ 

        /** 		case 1 then*/
        case 1:

        /** 			eu:poke( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1137)){
            poke_addr = (unsigned char *)_eaddr_1137;
        }
        else {
            poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_eaddr_1137)->dbl);
        }
        *poke_addr = (unsigned char)_data_1131;
        goto L6; // [141] 190

        /** 		case 2 then*/
        case 2:

        /** 			eu:poke2( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1137)){
            poke2_addr = (unsigned short *)_eaddr_1137;
        }
        else {
            poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_eaddr_1137)->dbl);
        }
        *poke2_addr = (unsigned short)_data_1131;
        goto L6; // [152] 190

        /** 		case 4 then*/
        case 4:

        /** 			eu:poke4( eaddr, data )*/
        if (IS_ATOM_INT(_eaddr_1137)){
            poke4_addr = (unsigned long *)_eaddr_1137;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_eaddr_1137)->dbl);
        }
        *poke4_addr = (unsigned long)_data_1131;
        goto L6; // [163] 190

        /** 		case else*/
        default:

        /** 			error:crash("Parameter error: Wrong word size %d in allocate_protect().", wordsize)*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_186_1170);
        _msg_inlined_crash_at_186_1170 = EPrintf(-9999999, _454, _wordsize_1132);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_186_1170);

        /** end procedure*/
        goto L7; // [184] 187
L7: 
        DeRefi(_msg_inlined_crash_at_186_1170);
        _msg_inlined_crash_at_186_1170 = NOVALUE;
    ;}L6: 

    /** 	ifdef SAFE then*/

    /** 	if local_change_protection_on_protected_memory( iaddr, size + memory:BORDER_SPACE * 2, true_protection ) = -1 then*/
    _455 = 0;
    _456 = _size_1138 + 0;
    _455 = NOVALUE;
    Ref(_iaddr_1135);
    Ref(_true_protection_1142);
    _457 = _4local_change_protection_on_protected_memory(_iaddr_1135, _456, _true_protection_1142);
    _456 = NOVALUE;
    if (binary_op_a(NOTEQ, _457, -1)){
        DeRef(_457);
        _457 = NOVALUE;
        goto L8; // [208] 232
    }
    DeRef(_457);
    _457 = NOVALUE;

    /** 		local_free_protected_memory( iaddr, size + memory:BORDER_SPACE * 2 )*/
    _459 = 0;
    _460 = _size_1138 + 0;
    _459 = NOVALUE;
    Ref(_iaddr_1135);
    _4local_free_protected_memory(_iaddr_1135, _460);
    _460 = NOVALUE;

    /** 		eaddr = 0*/
    DeRef(_eaddr_1137);
    _eaddr_1137 = 0;
L8: 

    /** 	return eaddr*/
    DeRef(_protection_1134);
    DeRef(_iaddr_1135);
    DeRef(_first_protection_1140);
    DeRef(_true_protection_1142);
    DeRef(_449);
    _449 = NOVALUE;
    return _eaddr_1137;
    ;
}


int _4local_allocate_protected_memory(int _s_1182, int _first_protection_1183)
{
    int _461 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_first_protection_1183)) {
        _1 = (long)(DBL_PTR(_first_protection_1183)->dbl);
        DeRefDS(_first_protection_1183);
        _first_protection_1183 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		return machine_func( memconst:M_ALLOC, PAGE_SIZE)*/
    _461 = machine(16, _4PAGE_SIZE_1101);
    return _461;
    ;
}


int _4local_change_protection_on_protected_memory(int _p_1187, int _s_1188, int _new_protection_1189)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_new_protection_1189)) {
        _1 = (long)(DBL_PTR(_new_protection_1189)->dbl);
        DeRefDS(_new_protection_1189);
        _new_protection_1189 = _1;
    }

    /** 	ifdef WINDOWS then*/

    /** 		return 0*/
    return 0;
    ;
}


void _4local_free_protected_memory(int _p_1192, int _s_1193)
{
    int _463 = NOVALUE;
    int _462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 			machine_func( memconst:M_FREE, {p})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_p_1192);
    *((int *)(_2+4)) = _p_1192;
    _462 = MAKE_SEQ(_1);
    _463 = machine(17, _462);
    DeRefDS(_462);
    _462 = NOVALUE;

    /** end procedure*/
    DeRef(_p_1192);
    DeRef(_463);
    _463 = NOVALUE;
    return;
    ;
}


void _4free(int _addr_1198)
{
    int _msg_inlined_crash_at_27_1207 = NOVALUE;
    int _data_inlined_crash_at_24_1206 = NOVALUE;
    int _addr_inlined_deallocate_at_64_1213 = NOVALUE;
    int _msg_inlined_crash_at_106_1218 = NOVALUE;
    int _470 = NOVALUE;
    int _469 = NOVALUE;
    int _468 = NOVALUE;
    int _467 = NOVALUE;
    int _465 = NOVALUE;
    int _464 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if types:number_array (addr) then*/
    Ref(_addr_1198);
    _464 = _9number_array(_addr_1198);
    if (_464 == 0) {
        DeRef(_464);
        _464 = NOVALUE;
        goto L1; // [7] 97
    }
    else {
        if (!IS_ATOM_INT(_464) && DBL_PTR(_464)->dbl == 0.0){
            DeRef(_464);
            _464 = NOVALUE;
            goto L1; // [7] 97
        }
        DeRef(_464);
        _464 = NOVALUE;
    }
    DeRef(_464);
    _464 = NOVALUE;

    /** 		if types:ascii_string(addr) then*/
    Ref(_addr_1198);
    _465 = _9ascii_string(_addr_1198);
    if (_465 == 0) {
        DeRef(_465);
        _465 = NOVALUE;
        goto L2; // [16] 47
    }
    else {
        if (!IS_ATOM_INT(_465) && DBL_PTR(_465)->dbl == 0.0){
            DeRef(_465);
            _465 = NOVALUE;
            goto L2; // [16] 47
        }
        DeRef(_465);
        _465 = NOVALUE;
    }
    DeRef(_465);
    _465 = NOVALUE;

    /** 			error:crash("free(\"%s\") is not a valid address", {addr})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_addr_1198);
    *((int *)(_2+4)) = _addr_1198;
    _467 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_24_1206);
    _data_inlined_crash_at_24_1206 = _467;
    _467 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_27_1207);
    _msg_inlined_crash_at_27_1207 = EPrintf(-9999999, _466, _data_inlined_crash_at_24_1206);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_27_1207);

    /** end procedure*/
    goto L3; // [41] 44
L3: 
    DeRef(_data_inlined_crash_at_24_1206);
    _data_inlined_crash_at_24_1206 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_27_1207);
    _msg_inlined_crash_at_27_1207 = NOVALUE;
L2: 

    /** 		for i = 1 to length(addr) do*/
    if (IS_SEQUENCE(_addr_1198)){
            _468 = SEQ_PTR(_addr_1198)->length;
    }
    else {
        _468 = 1;
    }
    {
        int _i_1209;
        _i_1209 = 1;
L4: 
        if (_i_1209 > _468){
            goto L5; // [52] 89
        }

        /** 			memory:deallocate( addr[i] )*/
        _2 = (int)SEQ_PTR(_addr_1198);
        _469 = (int)*(((s1_ptr)_2)->base + _i_1209);
        Ref(_469);
        DeRef(_addr_inlined_deallocate_at_64_1213);
        _addr_inlined_deallocate_at_64_1213 = _469;
        _469 = NOVALUE;

        /** 	ifdef DATA_EXECUTE and WINDOWS then*/

        /**    	machine_proc( memconst:M_FREE, addr)*/
        machine(17, _addr_inlined_deallocate_at_64_1213);

        /** end procedure*/
        goto L6; // [77] 80
L6: 
        DeRef(_addr_inlined_deallocate_at_64_1213);
        _addr_inlined_deallocate_at_64_1213 = NOVALUE;

        /** 		end for*/
        _i_1209 = _i_1209 + 1;
        goto L4; // [84] 59
L5: 
        ;
    }

    /** 		return*/
    DeRef(_addr_1198);
    return;
    goto L7; // [94] 127
L1: 

    /** 	elsif sequence(addr) then*/
    _470 = IS_SEQUENCE(_addr_1198);
    if (_470 == 0)
    {
        _470 = NOVALUE;
        goto L8; // [102] 126
    }
    else{
        _470 = NOVALUE;
    }

    /** 		error:crash("free() called with nested sequence")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_106_1218);
    _msg_inlined_crash_at_106_1218 = EPrintf(-9999999, _471, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_106_1218);

    /** end procedure*/
    goto L9; // [120] 123
L9: 
    DeRefi(_msg_inlined_crash_at_106_1218);
    _msg_inlined_crash_at_106_1218 = NOVALUE;
L8: 
L7: 

    /** 	if addr = 0 then*/
    if (binary_op_a(NOTEQ, _addr_1198, 0)){
        goto LA; // [129] 139
    }

    /** 		return*/
    DeRef(_addr_1198);
    return;
LA: 

    /** 	memory:deallocate( addr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_1198);

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_addr_1198);
    return;
    ;
}


void _4free_pointer_array(int _pointers_array_1226)
{
    int _saved_1227 = NOVALUE;
    int _ptr_1228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom saved = pointers_array*/
    Ref(_pointers_array_1226);
    DeRef(_saved_1227);
    _saved_1227 = _pointers_array_1226;

    /** 	while ptr with entry do*/
    goto L1; // [8] 39
L2: 
    if (_ptr_1228 <= 0) {
        if (_ptr_1228 == 0) {
            goto L3; // [13] 49
        }
        else {
            if (!IS_ATOM_INT(_ptr_1228) && DBL_PTR(_ptr_1228)->dbl == 0.0){
                goto L3; // [13] 49
            }
        }
    }

    /** 		memory:deallocate( ptr )*/

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _ptr_1228);

    /** end procedure*/
    goto L4; // [27] 30
L4: 

    /** 		pointers_array += ADDRESS_LENGTH*/
    _0 = _pointers_array_1226;
    if (IS_ATOM_INT(_pointers_array_1226)) {
        _pointers_array_1226 = _pointers_array_1226 + 4;
        if ((long)((unsigned long)_pointers_array_1226 + (unsigned long)HIGH_BITS) >= 0) 
        _pointers_array_1226 = NewDouble((double)_pointers_array_1226);
    }
    else {
        _pointers_array_1226 = NewDouble(DBL_PTR(_pointers_array_1226)->dbl + (double)4);
    }
    DeRef(_0);

    /** 	entry*/
L1: 

    /** 		ptr = peek4u(pointers_array)*/
    DeRef(_ptr_1228);
    if (IS_ATOM_INT(_pointers_array_1226)) {
        _ptr_1228 = *(unsigned long *)_pointers_array_1226;
        if ((unsigned)_ptr_1228 > (unsigned)MAXINT)
        _ptr_1228 = NewDouble((double)(unsigned long)_ptr_1228);
    }
    else {
        _ptr_1228 = *(unsigned long *)(unsigned long)(DBL_PTR(_pointers_array_1226)->dbl);
        if ((unsigned)_ptr_1228 > (unsigned)MAXINT)
        _ptr_1228 = NewDouble((double)(unsigned long)_ptr_1228);
    }

    /** 	end while*/
    goto L2; // [46] 11
L3: 

    /** 	free(saved)*/
    Ref(_saved_1227);
    _4free(_saved_1227);

    /** end procedure*/
    DeRef(_pointers_array_1226);
    DeRef(_saved_1227);
    DeRef(_ptr_1228);
    return;
    ;
}



// 0xCAA3882F
