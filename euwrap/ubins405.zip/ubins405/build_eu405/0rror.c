// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _43screen_output(int _f_48169, int _msg_48170)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_48169)) {
        _1 = (long)(DBL_PTR(_f_48169)->dbl);
        DeRefDS(_f_48169);
        _f_48169 = _1;
    }

    /** 	puts(f, msg)*/
    EPuts(_f_48169, _msg_48170); // DJP 

    /** end procedure*/
    DeRefDS(_msg_48170);
    return;
    ;
}


void _43Warning(int _msg_48173, int _mask_48174, int _args_48175)
{
    int _orig_mask_48176 = NOVALUE;
    int _text_48177 = NOVALUE;
    int _w_name_48178 = NOVALUE;
    int _25175 = NOVALUE;
    int _25173 = NOVALUE;
    int _25171 = NOVALUE;
    int _25168 = NOVALUE;
    int _25163 = NOVALUE;
    int _25161 = NOVALUE;
    int _25160 = NOVALUE;
    int _25159 = NOVALUE;
    int _25158 = NOVALUE;
    int _25156 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_mask_48174)) {
        _1 = (long)(DBL_PTR(_mask_48174)->dbl);
        DeRefDS(_mask_48174);
        _mask_48174 = _1;
    }

    /** 	if display_warnings = 0 then*/
    if (_43display_warnings_48157 != 0)
    goto L1; // [9] 19

    /** 		return*/
    DeRef(_msg_48173);
    DeRefDS(_args_48175);
    DeRef(_text_48177);
    DeRef(_w_name_48178);
    return;
L1: 

    /** 	if not Strict_is_on or Strict_Override then*/
    _25156 = (_12Strict_is_on_11748 == 0);
    if (_25156 != 0) {
        goto L2; // [26] 37
    }
    if (_12Strict_Override_11749 == 0)
    {
        goto L3; // [33] 56
    }
    else{
    }
L2: 

    /** 		if find(mask, strict_only_warnings) then*/
    _25158 = find_from(_mask_48174, _12strict_only_warnings_11746, 1);
    if (_25158 == 0)
    {
        _25158 = NOVALUE;
        goto L4; // [46] 55
    }
    else{
        _25158 = NOVALUE;
    }

    /** 			return*/
    DeRef(_msg_48173);
    DeRefDS(_args_48175);
    DeRef(_text_48177);
    DeRef(_w_name_48178);
    DeRef(_25156);
    _25156 = NOVALUE;
    return;
L4: 
L3: 

    /** 	orig_mask = mask -- =0 for non maskable warnings - none implemented so far*/
    _orig_mask_48176 = _mask_48174;

    /** 	if Strict_is_on and Strict_Override = 0 then*/
    if (_12Strict_is_on_11748 == 0) {
        goto L5; // [65] 85
    }
    _25160 = (_12Strict_Override_11749 == 0);
    if (_25160 == 0)
    {
        DeRef(_25160);
        _25160 = NOVALUE;
        goto L5; // [76] 85
    }
    else{
        DeRef(_25160);
        _25160 = NOVALUE;
    }

    /** 		mask = 0*/
    _mask_48174 = 0;
L5: 

    /** 	if mask = 0 or and_bits(OpWarning, mask) then*/
    _25161 = (_mask_48174 == 0);
    if (_25161 != 0) {
        goto L6; // [91] 106
    }
    {unsigned long tu;
         tu = (unsigned long)_12OpWarning_11750 & (unsigned long)_mask_48174;
         _25163 = MAKE_UINT(tu);
    }
    if (_25163 == 0) {
        DeRef(_25163);
        _25163 = NOVALUE;
        goto L7; // [102] 213
    }
    else {
        if (!IS_ATOM_INT(_25163) && DBL_PTR(_25163)->dbl == 0.0){
            DeRef(_25163);
            _25163 = NOVALUE;
            goto L7; // [102] 213
        }
        DeRef(_25163);
        _25163 = NOVALUE;
    }
    DeRef(_25163);
    _25163 = NOVALUE;
L6: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48176 == 0)
    goto L8; // [108] 122

    /** 			orig_mask = find(orig_mask,warning_flags)*/
    _orig_mask_48176 = find_from(_orig_mask_48176, _12warning_flags_11725, 1);
L8: 

    /** 		if orig_mask != 0 then*/
    if (_orig_mask_48176 == 0)
    goto L9; // [124] 145

    /** 			w_name = "{ " & warning_names[orig_mask] & " }"*/
    _2 = (int)SEQ_PTR(_12warning_names_11727);
    _25168 = (int)*(((s1_ptr)_2)->base + _orig_mask_48176);
    {
        int concat_list[3];

        concat_list[0] = _25169;
        concat_list[1] = _25168;
        concat_list[2] = _25167;
        Concat_N((object_ptr)&_w_name_48178, concat_list, 3);
    }
    _25168 = NOVALUE;
    goto LA; // [142] 153
L9: 

    /** 			w_name = "" -- not maskable*/
    RefDS(_21829);
    DeRef(_w_name_48178);
    _w_name_48178 = _21829;
LA: 

    /** 		if atom(msg) then*/
    _25171 = IS_ATOM(_msg_48173);
    if (_25171 == 0)
    {
        _25171 = NOVALUE;
        goto LB; // [158] 170
    }
    else{
        _25171 = NOVALUE;
    }

    /** 			msg = GetMsgText(msg, 1, args)*/
    Ref(_msg_48173);
    RefDS(_args_48175);
    _0 = _msg_48173;
    _msg_48173 = _44GetMsgText(_msg_48173, 1, _args_48175);
    DeRef(_0);
LB: 

    /** 		text = GetMsgText(204, 0, {w_name, msg})*/
    Ref(_msg_48173);
    RefDS(_w_name_48178);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _w_name_48178;
    ((int *)_2)[2] = _msg_48173;
    _25173 = MAKE_SEQ(_1);
    _0 = _text_48177;
    _text_48177 = _44GetMsgText(204, 0, _25173);
    DeRef(_0);
    _25173 = NOVALUE;

    /** 		if find(text, warning_list) then*/
    _25175 = find_from(_text_48177, _43warning_list_48166, 1);
    if (_25175 == 0)
    {
        _25175 = NOVALUE;
        goto LC; // [195] 204
    }
    else{
        _25175 = NOVALUE;
    }

    /** 			return -- duplicate*/
    DeRef(_msg_48173);
    DeRefDS(_args_48175);
    DeRefDS(_text_48177);
    DeRefDS(_w_name_48178);
    DeRef(_25156);
    _25156 = NOVALUE;
    DeRef(_25161);
    _25161 = NOVALUE;
    return;
LC: 

    /** 		warning_list = append(warning_list, text)*/
    RefDS(_text_48177);
    Append(&_43warning_list_48166, _43warning_list_48166, _text_48177);
L7: 

    /** end procedure*/
    DeRef(_msg_48173);
    DeRefDS(_args_48175);
    DeRef(_text_48177);
    DeRef(_w_name_48178);
    DeRef(_25156);
    _25156 = NOVALUE;
    DeRef(_25161);
    _25161 = NOVALUE;
    return;
    ;
}


void _43Log_warnings(int _policy_48223)
{
    int _25183 = NOVALUE;
    int _25182 = NOVALUE;
    int _25181 = NOVALUE;
    int _25180 = NOVALUE;
    int _25178 = NOVALUE;
    int _25177 = NOVALUE;
    int _0, _1, _2;
    

    /** 	display_warnings = 1*/
    _43display_warnings_48157 = 1;

    /** 	if sequence(policy) then*/
    _25177 = IS_SEQUENCE(_policy_48223);
    if (_25177 == 0)
    {
        _25177 = NOVALUE;
        goto L1; // [11] 34
    }
    else{
        _25177 = NOVALUE;
    }

    /** 		if length(policy)=0 then*/
    if (IS_SEQUENCE(_policy_48223)){
            _25178 = SEQ_PTR(_policy_48223)->length;
    }
    else {
        _25178 = 1;
    }
    if (_25178 != 0)
    goto L2; // [19] 82

    /** 			policy = STDERR*/
    DeRef(_policy_48223);
    _policy_48223 = 2;
    goto L2; // [31] 82
L1: 

    /** 		if policy >= 0 and policy < STDERR+1 then*/
    if (IS_ATOM_INT(_policy_48223)) {
        _25180 = (_policy_48223 >= 0);
    }
    else {
        _25180 = binary_op(GREATEREQ, _policy_48223, 0);
    }
    if (IS_ATOM_INT(_25180)) {
        if (_25180 == 0) {
            goto L3; // [40] 68
        }
    }
    else {
        if (DBL_PTR(_25180)->dbl == 0.0) {
            goto L3; // [40] 68
        }
    }
    _25182 = 3;
    if (IS_ATOM_INT(_policy_48223)) {
        _25183 = (_policy_48223 < 3);
    }
    else {
        _25183 = binary_op(LESS, _policy_48223, 3);
    }
    _25182 = NOVALUE;
    if (_25183 == 0) {
        DeRef(_25183);
        _25183 = NOVALUE;
        goto L3; // [55] 68
    }
    else {
        if (!IS_ATOM_INT(_25183) && DBL_PTR(_25183)->dbl == 0.0){
            DeRef(_25183);
            _25183 = NOVALUE;
            goto L3; // [55] 68
        }
        DeRef(_25183);
        _25183 = NOVALUE;
    }
    DeRef(_25183);
    _25183 = NOVALUE;

    /** 			policy  = STDERR*/
    DeRef(_policy_48223);
    _policy_48223 = 2;
    goto L4; // [65] 81
L3: 

    /** 		elsif policy < 0 then*/
    if (binary_op_a(GREATEREQ, _policy_48223, 0)){
        goto L5; // [70] 80
    }

    /** 			display_warnings = 0*/
    _43display_warnings_48157 = 0;
L5: 
L4: 
L2: 

    /** end procedure*/
    DeRef(_policy_48223);
    DeRef(_25180);
    _25180 = NOVALUE;
    return;
    ;
}


int _43ShowWarnings()
{
    int _c_48242 = NOVALUE;
    int _errfile_48243 = NOVALUE;
    int _twf_48244 = NOVALUE;
    int _25214 = NOVALUE;
    int _25211 = NOVALUE;
    int _25210 = NOVALUE;
    int _25209 = NOVALUE;
    int _25208 = NOVALUE;
    int _25207 = NOVALUE;
    int _25206 = NOVALUE;
    int _25204 = NOVALUE;
    int _25203 = NOVALUE;
    int _25202 = NOVALUE;
    int _25200 = NOVALUE;
    int _25199 = NOVALUE;
    int _25198 = NOVALUE;
    int _25197 = NOVALUE;
    int _25195 = NOVALUE;
    int _25191 = NOVALUE;
    int _25189 = NOVALUE;
    int _25188 = NOVALUE;
    int _25187 = NOVALUE;
    int _25185 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if display_warnings = 0 or length(warning_list) = 0 then*/
    _25185 = (_43display_warnings_48157 == 0);
    if (_25185 != 0) {
        goto L1; // [9] 27
    }
    if (IS_SEQUENCE(_43warning_list_48166)){
            _25187 = SEQ_PTR(_43warning_list_48166)->length;
    }
    else {
        _25187 = 1;
    }
    _25188 = (_25187 == 0);
    _25187 = NOVALUE;
    if (_25188 == 0)
    {
        DeRef(_25188);
        _25188 = NOVALUE;
        goto L2; // [23] 39
    }
    else{
        DeRef(_25188);
        _25188 = NOVALUE;
    }
L1: 

    /** 		return length(warning_list)*/
    if (IS_SEQUENCE(_43warning_list_48166)){
            _25189 = SEQ_PTR(_43warning_list_48166)->length;
    }
    else {
        _25189 = 1;
    }
    DeRef(_25185);
    _25185 = NOVALUE;
    return _25189;
L2: 

    /** 	if TempErrFile > 0 then*/
    if (_43TempErrFile_48155 <= 0)
    goto L3; // [43] 57

    /** 		errfile = TempErrFile*/
    _errfile_48243 = _43TempErrFile_48155;
    goto L4; // [54] 67
L3: 

    /** 		errfile = STDERR*/
    _errfile_48243 = 2;
L4: 

    /** 	if not integer(TempWarningName) then*/
    if (IS_ATOM_INT(_12TempWarningName_11696))
    _25191 = 1;
    else if (IS_ATOM_DBL(_12TempWarningName_11696))
    _25191 = IS_ATOM_INT(DoubleToInt(_12TempWarningName_11696));
    else
    _25191 = 0;
    if (_25191 != 0)
    goto L5; // [74] 179
    _25191 = NOVALUE;

    /** 		twf = open(TempWarningName,"w")*/
    _twf_48244 = EOpen(_12TempWarningName_11696, _21935, 0);

    /** 		if twf = -1 then*/
    if (_twf_48244 != -1)
    goto L6; // [88] 136

    /** 			ShowMsg(errfile, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_11696);
    *((int *)(_2+4)) = _12TempWarningName_11696;
    _25195 = MAKE_SEQ(_1);
    _44ShowMsg(_errfile_48243, 205, _25195, 1);
    _25195 = NOVALUE;

    /** 			if errfile != STDERR then*/
    if (_errfile_48243 == 2)
    goto L7; // [112] 173

    /** 				ShowMsg(STDERR, 205, {TempWarningName})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_12TempWarningName_11696);
    *((int *)(_2+4)) = _12TempWarningName_11696;
    _25197 = MAKE_SEQ(_1);
    _44ShowMsg(2, 205, _25197, 1);
    _25197 = NOVALUE;
    goto L7; // [133] 173
L6: 

    /** 			for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_43warning_list_48166)){
            _25198 = SEQ_PTR(_43warning_list_48166)->length;
    }
    else {
        _25198 = 1;
    }
    {
        int _i_48275;
        _i_48275 = 1;
L8: 
        if (_i_48275 > _25198){
            goto L9; // [143] 168
        }

        /** 				puts(twf, warning_list[i])*/
        _2 = (int)SEQ_PTR(_43warning_list_48166);
        _25199 = (int)*(((s1_ptr)_2)->base + _i_48275);
        EPuts(_twf_48244, _25199); // DJP 
        _25199 = NOVALUE;

        /** 			end for*/
        _i_48275 = _i_48275 + 1;
        goto L8; // [163] 150
L9: 
        ;
    }

    /** 		    close(twf)*/
    EClose(_twf_48244);
L7: 

    /** 		TempWarningName = 99 -- Flag that we have done this already.*/
    DeRef(_12TempWarningName_11696);
    _12TempWarningName_11696 = 99;
L5: 

    /** 	if batch_job = 0 or errfile != STDERR then*/
    _25200 = (_12batch_job_11695 == 0);
    if (_25200 != 0) {
        goto LA; // [187] 204
    }
    _25202 = (_errfile_48243 != 2);
    if (_25202 == 0)
    {
        DeRef(_25202);
        _25202 = NOVALUE;
        goto LB; // [200] 311
    }
    else{
        DeRef(_25202);
        _25202 = NOVALUE;
    }
LA: 

    /** 		for i = 1 to length(warning_list) do*/
    if (IS_SEQUENCE(_43warning_list_48166)){
            _25203 = SEQ_PTR(_43warning_list_48166)->length;
    }
    else {
        _25203 = 1;
    }
    {
        int _i_48286;
        _i_48286 = 1;
LC: 
        if (_i_48286 > _25203){
            goto LD; // [211] 310
        }

        /** 			puts(errfile, warning_list[i])*/
        _2 = (int)SEQ_PTR(_43warning_list_48166);
        _25204 = (int)*(((s1_ptr)_2)->base + _i_48286);
        EPuts(_errfile_48243, _25204); // DJP 
        _25204 = NOVALUE;

        /** 			if errfile = STDERR then*/
        if (_errfile_48243 != 2)
        goto LE; // [235] 303

        /** 				if remainder(i, 20) = 0 and batch_job = 0 and test_only = 0 then*/
        _25206 = (_i_48286 % 20);
        _25207 = (_25206 == 0);
        _25206 = NOVALUE;
        if (_25207 == 0) {
            _25208 = 0;
            goto LF; // [249] 263
        }
        _25209 = (_12batch_job_11695 == 0);
        _25208 = (_25209 != 0);
LF: 
        if (_25208 == 0) {
            goto L10; // [263] 302
        }
        _25211 = (_12test_only_11694 == 0);
        if (_25211 == 0)
        {
            DeRef(_25211);
            _25211 = NOVALUE;
            goto L10; // [274] 302
        }
        else{
            DeRef(_25211);
            _25211 = NOVALUE;
        }

        /** 					ShowMsg(errfile, 206)*/
        RefDS(_21829);
        _44ShowMsg(_errfile_48243, 206, _21829, 1);

        /** 					c = getc(0)*/
        if (0 != last_r_file_no) {
            last_r_file_ptr = which_file(0, EF_READ);
            last_r_file_no = 0;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_48242 = getc((FILE*)xstdin);
            }
            else
            _c_48242 = getc(last_r_file_ptr);
        }
        else
        _c_48242 = getc(last_r_file_ptr);

        /** 					if c = 'q' then*/
        if (_c_48242 != 113)
        goto L11; // [292] 301

        /** 						exit*/
        goto LD; // [298] 310
L11: 
L10: 
LE: 

        /** 		end for*/
        _i_48286 = _i_48286 + 1;
        goto LC; // [305] 218
LD: 
        ;
    }
LB: 

    /** 	return length(warning_list)*/
    if (IS_SEQUENCE(_43warning_list_48166)){
            _25214 = SEQ_PTR(_43warning_list_48166)->length;
    }
    else {
        _25214 = 1;
    }
    DeRef(_25185);
    _25185 = NOVALUE;
    DeRef(_25200);
    _25200 = NOVALUE;
    DeRef(_25209);
    _25209 = NOVALUE;
    DeRef(_25207);
    _25207 = NOVALUE;
    return _25214;
    ;
}


void _43ShowDefines(int _errfile_48308)
{
    int _c_48309 = NOVALUE;
    int _25228 = NOVALUE;
    int _25227 = NOVALUE;
    int _25225 = NOVALUE;
    int _25224 = NOVALUE;
    int _25221 = NOVALUE;
    int _25220 = NOVALUE;
    int _25219 = NOVALUE;
    int _25218 = NOVALUE;
    int _25217 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_errfile_48308)) {
        _1 = (long)(DBL_PTR(_errfile_48308)->dbl);
        DeRefDS(_errfile_48308);
        _errfile_48308 = _1;
    }

    /** 	if errfile=0 then*/
    if (_errfile_48308 != 0)
    goto L1; // [5] 19

    /** 		errfile = STDERR*/
    _errfile_48308 = 2;
L1: 

    /** 	puts(errfile, format("\n--- [1] ---\n", {GetMsgText(207,0)}))*/
    RefDS(_21829);
    _25217 = _44GetMsgText(207, 0, _21829);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _25217;
    _25218 = MAKE_SEQ(_1);
    _25217 = NOVALUE;
    RefDS(_25216);
    _25219 = _18format(_25216, _25218);
    _25218 = NOVALUE;
    EPuts(_errfile_48308, _25219); // DJP 
    DeRef(_25219);
    _25219 = NOVALUE;

    /** 	for i = 1 to length(OpDefines) do*/
    if (IS_SEQUENCE(_12OpDefines_11756)){
            _25220 = SEQ_PTR(_12OpDefines_11756)->length;
    }
    else {
        _25220 = 1;
    }
    {
        int _i_48320;
        _i_48320 = 1;
L2: 
        if (_i_48320 > _25220){
            goto L3; // [46] 98
        }

        /** 		if find(OpDefines[i], {"_PLAT_START", "_PLAT_STOP"}) = 0 then*/
        _2 = (int)SEQ_PTR(_12OpDefines_11756);
        _25221 = (int)*(((s1_ptr)_2)->base + _i_48320);
        RefDS(_25223);
        RefDS(_25222);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25222;
        ((int *)_2)[2] = _25223;
        _25224 = MAKE_SEQ(_1);
        _25225 = find_from(_25221, _25224, 1);
        _25221 = NOVALUE;
        DeRefDS(_25224);
        _25224 = NOVALUE;
        if (_25225 != 0)
        goto L4; // [70] 91

        /** 			printf(errfile, "%s\n", {OpDefines[i]})*/
        _2 = (int)SEQ_PTR(_12OpDefines_11756);
        _25227 = (int)*(((s1_ptr)_2)->base + _i_48320);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25227);
        *((int *)(_2+4)) = _25227;
        _25228 = MAKE_SEQ(_1);
        _25227 = NOVALUE;
        EPrintf(_errfile_48308, _25097, _25228);
        DeRefDS(_25228);
        _25228 = NOVALUE;
L4: 

        /** 	end for*/
        _i_48320 = _i_48320 + 1;
        goto L2; // [93] 53
L3: 
        ;
    }

    /** 	puts(errfile, "-------------------\n")*/
    EPuts(_errfile_48308, _25229); // DJP 

    /** end procedure*/
    return;
    ;
}


void _43Cleanup(int _status_48337)
{
    int _w_48338 = NOVALUE;
    int _show_error_48339 = NOVALUE;
    int _31380 = NOVALUE;
    int _25243 = NOVALUE;
    int _25242 = NOVALUE;
    int _25241 = NOVALUE;
    int _25240 = NOVALUE;
    int _25239 = NOVALUE;
    int _25238 = NOVALUE;
    int _25237 = NOVALUE;
    int _25236 = NOVALUE;
    int _25235 = NOVALUE;
    int _25234 = NOVALUE;
    int _25230 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_status_48337)) {
        _1 = (long)(DBL_PTR(_status_48337)->dbl);
        DeRefDS(_status_48337);
        _status_48337 = _1;
    }

    /** 	integer w, show_error = 0*/
    _show_error_48339 = 0;

    /** 	ifdef EU_EX then*/

    /** 		write_coverage_db()*/
    _31380 = _49write_coverage_db();
    DeRef(_31380);
    _31380 = NOVALUE;

    /** 	show_error = 1*/
    _show_error_48339 = 1;

    /** 	if object(src_file) = 0 then*/
    if( NOVALUE == _12src_file_11804 ){
        _25230 = 0;
    }
    else{
        _25230 = 1;
    }
    if (_25230 != 0)
    goto L1; // [27] 41

    /** 		src_file = -1*/
    _12src_file_11804 = -1;
    goto L2; // [38] 64
L1: 

    /** 	elsif src_file >= 0 then*/
    if (_12src_file_11804 < 0)
    goto L3; // [45] 63

    /** 		close(src_file)*/
    EClose(_12src_file_11804);

    /** 		src_file = -1*/
    _12src_file_11804 = -1;
L3: 
L2: 

    /** 	w = ShowWarnings()*/
    _w_48338 = _43ShowWarnings();
    if (!IS_ATOM_INT(_w_48338)) {
        _1 = (long)(DBL_PTR(_w_48338)->dbl);
        DeRefDS(_w_48338);
        _w_48338 = _1;
    }

    /** 	if not TRANSLATE and (BIND or show_error) and (w or Errors) then*/
    _25234 = (_12TRANSLATE_11319 == 0);
    if (_25234 == 0) {
        _25235 = 0;
        goto L4; // [78] 96
    }
    if (_12BIND_11322 != 0) {
        _25236 = 1;
        goto L5; // [84] 92
    }
    _25236 = (_show_error_48339 != 0);
L5: 
    _25235 = (_25236 != 0);
L4: 
    if (_25235 == 0) {
        goto L6; // [96] 155
    }
    if (_w_48338 != 0) {
        DeRef(_25238);
        _25238 = 1;
        goto L7; // [100] 110
    }
    _25238 = (_43Errors_48154 != 0);
L7: 
    if (_25238 == 0)
    {
        _25238 = NOVALUE;
        goto L6; // [111] 155
    }
    else{
        _25238 = NOVALUE;
    }

    /** 		if not batch_job and not test_only then*/
    _25239 = (_12batch_job_11695 == 0);
    if (_25239 == 0) {
        goto L8; // [121] 154
    }
    _25241 = (_12test_only_11694 == 0);
    if (_25241 == 0)
    {
        DeRef(_25241);
        _25241 = NOVALUE;
        goto L8; // [131] 154
    }
    else{
        DeRef(_25241);
        _25241 = NOVALUE;
    }

    /** 			screen_output(STDERR, GetMsgText(208,0))*/
    RefDS(_21829);
    _25242 = _44GetMsgText(208, 0, _21829);
    _43screen_output(2, _25242);
    _25242 = NOVALUE;

    /** 			getc(0) -- wait*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25243 = getc((FILE*)xstdin);
        }
        else
        _25243 = getc(last_r_file_ptr);
    }
    else
    _25243 = getc(last_r_file_ptr);
L8: 
L6: 

    /** 	cleanup_open_includes()*/
    _60cleanup_open_includes();

    /** 	abort(status)*/
    UserCleanup(_status_48337);

    /** end procedure*/
    DeRef(_25234);
    _25234 = NOVALUE;
    DeRef(_25239);
    _25239 = NOVALUE;
    return;
    ;
}


void _43OpenErrFile()
{
    int _25250 = NOVALUE;
    int _25249 = NOVALUE;
    int _25247 = NOVALUE;
    int _0, _1, _2;
    

    /**     if TempErrFile != -1 then*/
    if (_43TempErrFile_48155 == -1)
    goto L1; // [5] 19

    /** 		TempErrFile = open(TempErrName, "w")*/
    _43TempErrFile_48155 = EOpen(_43TempErrName_48156, _21935, 0);
L1: 

    /** 	if TempErrFile = -1 then*/
    if (_43TempErrFile_48155 != -1)
    goto L2; // [23] 64

    /** 		if length(TempErrName) > 0 then*/
    _25247 = 6;

    /** 			screen_output(STDERR, GetMsgText(209, 0, {TempErrName}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_43TempErrName_48156);
    *((int *)(_2+4)) = _43TempErrName_48156;
    _25249 = MAKE_SEQ(_1);
    _25250 = _44GetMsgText(209, 0, _25249);
    _25249 = NOVALUE;
    _43screen_output(2, _25250);
    _25250 = NOVALUE;

    /** 		abort(1) -- with no clean up*/
    UserCleanup(1);
L2: 

    /** end procedure*/
    return;
    ;
}


void _43ShowErr(int _f_48387)
{
    int _msg_inlined_screen_output_at_41_48399 = NOVALUE;
    int _25257 = NOVALUE;
    int _25256 = NOVALUE;
    int _25255 = NOVALUE;
    int _25253 = NOVALUE;
    int _25251 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(known_files) = 0 then*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _25251 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _25251 = 1;
    }
    if (_25251 != 0)
    goto L1; // [10] 20

    /** 		return*/
    return;
L1: 

    /** 	if ThisLine[1] = END_OF_FILE_CHAR then*/
    _2 = (int)SEQ_PTR(_43ThisLine_48158);
    _25253 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25253, 26)){
        _25253 = NOVALUE;
        goto L2; // [30] 62
    }
    _25253 = NOVALUE;

    /** 		screen_output(f, GetMsgText(210,0))*/
    RefDS(_21829);
    _25255 = _44GetMsgText(210, 0, _21829);
    DeRef(_msg_inlined_screen_output_at_41_48399);
    _msg_inlined_screen_output_at_41_48399 = _25255;
    _25255 = NOVALUE;

    /** 	puts(f, msg)*/
    EPuts(_f_48387, _msg_inlined_screen_output_at_41_48399); // DJP 

    /** end procedure*/
    goto L3; // [54] 57
L3: 
    DeRef(_msg_inlined_screen_output_at_41_48399);
    _msg_inlined_screen_output_at_41_48399 = NOVALUE;
    goto L4; // [59] 79
L2: 

    /** 		screen_output(f, ThisLine)*/

    /** 	puts(f, msg)*/
    EPuts(_f_48387, _43ThisLine_48158); // DJP 

    /** end procedure*/
    goto L5; // [75] 78
L5: 
L4: 

    /** 	for i = 1 to bp-2 do -- bp-1 points to last character read*/
    _25256 = _43bp_48162 - 2;
    if ((long)((unsigned long)_25256 +(unsigned long) HIGH_BITS) >= 0){
        _25256 = NewDouble((double)_25256);
    }
    {
        int _i_48403;
        _i_48403 = 1;
L6: 
        if (binary_op_a(GREATER, _i_48403, _25256)){
            goto L7; // [87] 141
        }

        /** 		if ThisLine[i] = '\t' then*/
        _2 = (int)SEQ_PTR(_43ThisLine_48158);
        if (!IS_ATOM_INT(_i_48403)){
            _25257 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_48403)->dbl));
        }
        else{
            _25257 = (int)*(((s1_ptr)_2)->base + _i_48403);
        }
        if (binary_op_a(NOTEQ, _25257, 9)){
            _25257 = NOVALUE;
            goto L8; // [102] 121
        }
        _25257 = NOVALUE;

        /** 			screen_output(f, "\t")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48387, _23605); // DJP 

        /** end procedure*/
        goto L9; // [115] 134
        goto L9; // [118] 134
L8: 

        /** 			screen_output(f, " ")*/

        /** 	puts(f, msg)*/
        EPuts(_f_48387, _23109); // DJP 

        /** end procedure*/
        goto LA; // [130] 133
LA: 
L9: 

        /** 	end for*/
        _0 = _i_48403;
        if (IS_ATOM_INT(_i_48403)) {
            _i_48403 = _i_48403 + 1;
            if ((long)((unsigned long)_i_48403 +(unsigned long) HIGH_BITS) >= 0){
                _i_48403 = NewDouble((double)_i_48403);
            }
        }
        else {
            _i_48403 = binary_op_a(PLUS, _i_48403, 1);
        }
        DeRef(_0);
        goto L6; // [136] 94
L7: 
        ;
        DeRef(_i_48403);
    }

    /** 	screen_output(f, "^\n\n")*/

    /** 	puts(f, msg)*/
    EPuts(_f_48387, _25259); // DJP 

    /** end procedure*/
    goto LB; // [150] 153
LB: 

    /** end procedure*/
    DeRef(_25256);
    _25256 = NOVALUE;
    return;
    ;
}


void _43CompileErr(int _msg_48415, int _args_48416, int _preproc_48417)
{
    int _errmsg_48418 = NOVALUE;
    int _25280 = NOVALUE;
    int _25276 = NOVALUE;
    int _25275 = NOVALUE;
    int _25274 = NOVALUE;
    int _25273 = NOVALUE;
    int _25272 = NOVALUE;
    int _25271 = NOVALUE;
    int _25269 = NOVALUE;
    int _25268 = NOVALUE;
    int _25266 = NOVALUE;
    int _25265 = NOVALUE;
    int _25264 = NOVALUE;
    int _25260 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_preproc_48417)) {
        _1 = (long)(DBL_PTR(_preproc_48417)->dbl);
        DeRefDS(_preproc_48417);
        _preproc_48417 = _1;
    }

    /** 	if integer(msg) then*/
    if (IS_ATOM_INT(_msg_48415))
    _25260 = 1;
    else if (IS_ATOM_DBL(_msg_48415))
    _25260 = IS_ATOM_INT(DoubleToInt(_msg_48415));
    else
    _25260 = 0;
    if (_25260 == 0)
    {
        _25260 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25260 = NOVALUE;
    }

    /** 		msg = GetMsgText(msg)*/
    Ref(_msg_48415);
    RefDS(_21829);
    _0 = _msg_48415;
    _msg_48415 = _44GetMsgText(_msg_48415, 1, _21829);
    DeRef(_0);
L1: 

    /** 	msg = format(msg, args)*/
    Ref(_msg_48415);
    Ref(_args_48416);
    _0 = _msg_48415;
    _msg_48415 = _18format(_msg_48415, _args_48416);
    DeRef(_0);

    /** 	Errors += 1*/
    _43Errors_48154 = _43Errors_48154 + 1;

    /** 	if not preproc and length(known_files) then*/
    _25264 = (_preproc_48417 == 0);
    if (_25264 == 0) {
        goto L2; // [40] 78
    }
    if (IS_SEQUENCE(_13known_files_10637)){
            _25266 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _25266 = 1;
    }
    if (_25266 == 0)
    {
        _25266 = NOVALUE;
        goto L2; // [50] 78
    }
    else{
        _25266 = NOVALUE;
    }

    /** 		errmsg = sprintf("%s:%d\n%s\n", {known_files[current_file_no],*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _25268 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25268);
    *((int *)(_2+4)) = _25268;
    *((int *)(_2+8)) = _12line_number_11683;
    Ref(_msg_48415);
    *((int *)(_2+12)) = _msg_48415;
    _25269 = MAKE_SEQ(_1);
    _25268 = NOVALUE;
    DeRef(_errmsg_48418);
    _errmsg_48418 = EPrintf(-9999999, _25267, _25269);
    DeRefDS(_25269);
    _25269 = NOVALUE;
    goto L3; // [75] 121
L2: 

    /** 		errmsg = msg*/
    Ref(_msg_48415);
    DeRef(_errmsg_48418);
    _errmsg_48418 = _msg_48415;

    /** 		if length(msg) > 0 and msg[$] != '\n' then*/
    if (IS_SEQUENCE(_msg_48415)){
            _25271 = SEQ_PTR(_msg_48415)->length;
    }
    else {
        _25271 = 1;
    }
    _25272 = (_25271 > 0);
    _25271 = NOVALUE;
    if (_25272 == 0) {
        goto L4; // [94] 120
    }
    if (IS_SEQUENCE(_msg_48415)){
            _25274 = SEQ_PTR(_msg_48415)->length;
    }
    else {
        _25274 = 1;
    }
    _2 = (int)SEQ_PTR(_msg_48415);
    _25275 = (int)*(((s1_ptr)_2)->base + _25274);
    if (IS_ATOM_INT(_25275)) {
        _25276 = (_25275 != 10);
    }
    else {
        _25276 = binary_op(NOTEQ, _25275, 10);
    }
    _25275 = NOVALUE;
    if (_25276 == 0) {
        DeRef(_25276);
        _25276 = NOVALUE;
        goto L4; // [110] 120
    }
    else {
        if (!IS_ATOM_INT(_25276) && DBL_PTR(_25276)->dbl == 0.0){
            DeRef(_25276);
            _25276 = NOVALUE;
            goto L4; // [110] 120
        }
        DeRef(_25276);
        _25276 = NOVALUE;
    }
    DeRef(_25276);
    _25276 = NOVALUE;

    /** 			errmsg &= '\n'*/
    Append(&_errmsg_48418, _errmsg_48418, 10);
L4: 
L3: 

    /** 	if not preproc then*/
    if (_preproc_48417 != 0)
    goto L5; // [123] 131

    /** 		OpenErrFile() -- exits if error filename is ""*/
    _43OpenErrFile();
L5: 

    /** 	screen_output(STDERR, errmsg)*/
    RefDS(_errmsg_48418);
    _43screen_output(2, _errmsg_48418);

    /** 	if not preproc then*/
    if (_preproc_48417 != 0)
    goto L6; // [143] 196

    /** 		ShowErr(STDERR)*/
    _43ShowErr(2);

    /** 		puts(TempErrFile, errmsg)*/
    EPuts(_43TempErrFile_48155, _errmsg_48418); // DJP 

    /** 		ShowErr(TempErrFile)*/
    _43ShowErr(_43TempErrFile_48155);

    /** 		ShowWarnings()*/
    _25280 = _43ShowWarnings();

    /** 		ShowDefines(TempErrFile)*/
    _43ShowDefines(_43TempErrFile_48155);

    /** 		close(TempErrFile)*/
    EClose(_43TempErrFile_48155);

    /** 		TempErrFile = -2*/
    _43TempErrFile_48155 = -2;

    /** 		Cleanup(1)*/
    _43Cleanup(1);
L6: 

    /** end procedure*/
    DeRef(_msg_48415);
    DeRef(_args_48416);
    DeRef(_errmsg_48418);
    DeRef(_25264);
    _25264 = NOVALUE;
    DeRef(_25272);
    _25272 = NOVALUE;
    DeRef(_25280);
    _25280 = NOVALUE;
    return;
    ;
}


void _43InternalErr(int _msgno_48461, int _args_48462)
{
    int _msg_48463 = NOVALUE;
    int _25295 = NOVALUE;
    int _25294 = NOVALUE;
    int _25293 = NOVALUE;
    int _25292 = NOVALUE;
    int _25291 = NOVALUE;
    int _25290 = NOVALUE;
    int _25289 = NOVALUE;
    int _25288 = NOVALUE;
    int _25287 = NOVALUE;
    int _25286 = NOVALUE;
    int _25285 = NOVALUE;
    int _25282 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_msgno_48461)) {
        _1 = (long)(DBL_PTR(_msgno_48461)->dbl);
        DeRefDS(_msgno_48461);
        _msgno_48461 = _1;
    }

    /** 	if atom(args) then*/
    _25282 = IS_ATOM(_args_48462);
    if (_25282 == 0)
    {
        _25282 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _25282 = NOVALUE;
    }

    /** 		args = {args}*/
    _0 = _args_48462;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_args_48462);
    *((int *)(_2+4)) = _args_48462;
    _args_48462 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	msg = GetMsgText(msgno, 1, args)*/
    Ref(_args_48462);
    _0 = _msg_48463;
    _msg_48463 = _44GetMsgText(_msgno_48461, 1, _args_48462);
    DeRef(_0);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [32] 56
    }
    else{
    }

    /** 		screen_output(STDERR, GetMsgText(211, 1, {msg}))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_48463);
    *((int *)(_2+4)) = _msg_48463;
    _25285 = MAKE_SEQ(_1);
    _25286 = _44GetMsgText(211, 1, _25285);
    _25285 = NOVALUE;
    _43screen_output(2, _25286);
    _25286 = NOVALUE;
    goto L3; // [53] 87
L2: 

    /** 		screen_output(STDERR, GetMsgText(212, 1, {known_files[current_file_no], line_number, msg}))*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _25287 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_25287);
    *((int *)(_2+4)) = _25287;
    *((int *)(_2+8)) = _12line_number_11683;
    RefDS(_msg_48463);
    *((int *)(_2+12)) = _msg_48463;
    _25288 = MAKE_SEQ(_1);
    _25287 = NOVALUE;
    _25289 = _44GetMsgText(212, 1, _25288);
    _25288 = NOVALUE;
    _43screen_output(2, _25289);
    _25289 = NOVALUE;
L3: 

    /** 	if not batch_job and not test_only then*/
    _25290 = (_12batch_job_11695 == 0);
    if (_25290 == 0) {
        goto L4; // [94] 127
    }
    _25292 = (_12test_only_11694 == 0);
    if (_25292 == 0)
    {
        DeRef(_25292);
        _25292 = NOVALUE;
        goto L4; // [104] 127
    }
    else{
        DeRef(_25292);
        _25292 = NOVALUE;
    }

    /** 		screen_output(STDERR, GetMsgText(208, 0))*/
    RefDS(_21829);
    _25293 = _44GetMsgText(208, 0, _21829);
    _43screen_output(2, _25293);
    _25293 = NOVALUE;

    /** 		getc(0)*/
    if (0 != last_r_file_no) {
        last_r_file_ptr = which_file(0, EF_READ);
        last_r_file_no = 0;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _25294 = getc((FILE*)xstdin);
        }
        else
        _25294 = getc(last_r_file_ptr);
    }
    else
    _25294 = getc(last_r_file_ptr);
L4: 

    /** 	machine_proc(67, GetMsgText(213))*/
    RefDS(_21829);
    _25295 = _44GetMsgText(213, 1, _21829);
    machine(67, _25295);
    DeRef(_25295);
    _25295 = NOVALUE;

    /** end procedure*/
    DeRef(_args_48462);
    DeRef(_msg_48463);
    DeRef(_25290);
    _25290 = NOVALUE;
    return;
    ;
}



// 0x0BE38626
