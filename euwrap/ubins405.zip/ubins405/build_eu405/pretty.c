// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _10pretty_out(int _text_1348)
{
    int _531 = NOVALUE;
    int _529 = NOVALUE;
    int _527 = NOVALUE;
    int _526 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pretty_line &= text*/
    if (IS_SEQUENCE(_10pretty_line_1345) && IS_ATOM(_text_1348)) {
        Ref(_text_1348);
        Append(&_10pretty_line_1345, _10pretty_line_1345, _text_1348);
    }
    else if (IS_ATOM(_10pretty_line_1345) && IS_SEQUENCE(_text_1348)) {
    }
    else {
        Concat((object_ptr)&_10pretty_line_1345, _10pretty_line_1345, _text_1348);
    }

    /** 	if equal(text, '\n') and pretty_printing then*/
    if (_text_1348 == 10)
    _526 = 1;
    else if (IS_ATOM_INT(_text_1348) && IS_ATOM_INT(10))
    _526 = 0;
    else
    _526 = (compare(_text_1348, 10) == 0);
    if (_526 == 0) {
        goto L1; // [15] 50
    }
    if (_10pretty_printing_1342 == 0)
    {
        goto L1; // [22] 50
    }
    else{
    }

    /** 		puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1333, _10pretty_line_1345); // DJP 

    /** 		pretty_line = ""*/
    RefDS(_5);
    DeRefDS(_10pretty_line_1345);
    _10pretty_line_1345 = _5;

    /** 		pretty_line_count += 1*/
    _10pretty_line_count_1338 = _10pretty_line_count_1338 + 1;
L1: 

    /** 	if atom(text) then*/
    _529 = IS_ATOM(_text_1348);
    if (_529 == 0)
    {
        _529 = NOVALUE;
        goto L2; // [55] 69
    }
    else{
        _529 = NOVALUE;
    }

    /** 		pretty_chars += 1*/
    _10pretty_chars_1330 = _10pretty_chars_1330 + 1;
    goto L3; // [66] 81
L2: 

    /** 		pretty_chars += length(text)*/
    if (IS_SEQUENCE(_text_1348)){
            _531 = SEQ_PTR(_text_1348)->length;
    }
    else {
        _531 = 1;
    }
    _10pretty_chars_1330 = _10pretty_chars_1330 + _531;
    _531 = NOVALUE;
L3: 

    /** end procedure*/
    DeRef(_text_1348);
    return;
    ;
}


void _10cut_line(int _n_1362)
{
    int _534 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not pretty_line_breaks then	*/
    if (_10pretty_line_breaks_1341 != 0)
    goto L1; // [7] 21

    /** 		pretty_chars = 0*/
    _10pretty_chars_1330 = 0;

    /** 		return*/
    return;
L1: 

    /** 	if pretty_chars + n > pretty_end_col then*/
    _534 = _10pretty_chars_1330 + _n_1362;
    if ((long)((unsigned long)_534 + (unsigned long)HIGH_BITS) >= 0) 
    _534 = NewDouble((double)_534);
    if (binary_op_a(LESSEQ, _534, _10pretty_end_col_1329)){
        DeRef(_534);
        _534 = NOVALUE;
        goto L2; // [31] 46
    }
    DeRef(_534);
    _534 = NOVALUE;

    /** 		pretty_out('\n')*/
    _10pretty_out(10);

    /** 		pretty_chars = 0*/
    _10pretty_chars_1330 = 0;
L2: 

    /** end procedure*/
    return;
    ;
}


void _10indent()
{
    int _542 = NOVALUE;
    int _541 = NOVALUE;
    int _540 = NOVALUE;
    int _539 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if pretty_line_breaks = 0 then	*/
    if (_10pretty_line_breaks_1341 != 0)
    goto L1; // [5] 22

    /** 		pretty_chars = 0*/
    _10pretty_chars_1330 = 0;

    /** 		return*/
    return;
    goto L2; // [19] 85
L1: 

    /** 	elsif pretty_line_breaks = -1 then*/
    if (_10pretty_line_breaks_1341 != -1)
    goto L3; // [26] 38

    /** 		cut_line( 0 )*/
    _10cut_line(0);
    goto L2; // [35] 85
L3: 

    /** 		if pretty_chars > 0 then*/
    if (_10pretty_chars_1330 <= 0)
    goto L4; // [42] 57

    /** 			pretty_out('\n')*/
    _10pretty_out(10);

    /** 			pretty_chars = 0*/
    _10pretty_chars_1330 = 0;
L4: 

    /** 		pretty_out(repeat(' ', (pretty_start_col-1) + */
    _539 = _10pretty_start_col_1331 - 1;
    if ((long)((unsigned long)_539 +(unsigned long) HIGH_BITS) >= 0){
        _539 = NewDouble((double)_539);
    }
    if (_10pretty_level_1332 == (short)_10pretty_level_1332 && _10pretty_indent_1335 <= INT15 && _10pretty_indent_1335 >= -INT15)
    _540 = _10pretty_level_1332 * _10pretty_indent_1335;
    else
    _540 = NewDouble(_10pretty_level_1332 * (double)_10pretty_indent_1335);
    if (IS_ATOM_INT(_539) && IS_ATOM_INT(_540)) {
        _541 = _539 + _540;
    }
    else {
        if (IS_ATOM_INT(_539)) {
            _541 = NewDouble((double)_539 + DBL_PTR(_540)->dbl);
        }
        else {
            if (IS_ATOM_INT(_540)) {
                _541 = NewDouble(DBL_PTR(_539)->dbl + (double)_540);
            }
            else
            _541 = NewDouble(DBL_PTR(_539)->dbl + DBL_PTR(_540)->dbl);
        }
    }
    DeRef(_539);
    _539 = NOVALUE;
    DeRef(_540);
    _540 = NOVALUE;
    _542 = Repeat(32, _541);
    DeRef(_541);
    _541 = NOVALUE;
    _10pretty_out(_542);
    _542 = NOVALUE;
L2: 

    /** end procedure*/
    return;
    ;
}


int _10esc_char(int _a_1383)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_1383)) {
        _1 = (long)(DBL_PTR(_a_1383)->dbl);
        DeRefDS(_a_1383);
        _a_1383 = _1;
    }

    /** 	switch a do*/
    _0 = _a_1383;
    switch ( _0 ){ 

        /** 		case'\t' then*/
        case 9:

        /** 			return `\t`*/
        RefDS(_545);
        return _545;
        goto L1; // [20] 81

        /** 		case'\n' then*/
        case 10:

        /** 			return `\n`*/
        RefDS(_546);
        return _546;
        goto L1; // [32] 81

        /** 		case'\r' then*/
        case 13:

        /** 			return `\r`*/
        RefDS(_547);
        return _547;
        goto L1; // [44] 81

        /** 		case'\\' then*/
        case 92:

        /** 			return `\\`*/
        RefDS(_549);
        return _549;
        goto L1; // [56] 81

        /** 		case'"' then*/
        case 34:

        /** 			return `\"`*/
        RefDS(_551);
        return _551;
        goto L1; // [68] 81

        /** 		case else*/
        default:

        /** 			return a*/
        return _a_1383;
    ;}L1: 
    ;
}


void _10rPrint(int _a_1401)
{
    int _sbuff_1402 = NOVALUE;
    int _multi_line_1403 = NOVALUE;
    int _all_ascii_1404 = NOVALUE;
    int _608 = NOVALUE;
    int _607 = NOVALUE;
    int _606 = NOVALUE;
    int _605 = NOVALUE;
    int _601 = NOVALUE;
    int _600 = NOVALUE;
    int _599 = NOVALUE;
    int _598 = NOVALUE;
    int _596 = NOVALUE;
    int _595 = NOVALUE;
    int _593 = NOVALUE;
    int _592 = NOVALUE;
    int _590 = NOVALUE;
    int _589 = NOVALUE;
    int _588 = NOVALUE;
    int _587 = NOVALUE;
    int _586 = NOVALUE;
    int _585 = NOVALUE;
    int _584 = NOVALUE;
    int _583 = NOVALUE;
    int _582 = NOVALUE;
    int _581 = NOVALUE;
    int _580 = NOVALUE;
    int _579 = NOVALUE;
    int _578 = NOVALUE;
    int _577 = NOVALUE;
    int _576 = NOVALUE;
    int _575 = NOVALUE;
    int _574 = NOVALUE;
    int _570 = NOVALUE;
    int _569 = NOVALUE;
    int _568 = NOVALUE;
    int _567 = NOVALUE;
    int _566 = NOVALUE;
    int _565 = NOVALUE;
    int _563 = NOVALUE;
    int _562 = NOVALUE;
    int _558 = NOVALUE;
    int _557 = NOVALUE;
    int _556 = NOVALUE;
    int _553 = NOVALUE;
    int _552 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _552 = IS_ATOM(_a_1401);
    if (_552 == 0)
    {
        _552 = NOVALUE;
        goto L1; // [6] 176
    }
    else{
        _552 = NOVALUE;
    }

    /** 		if integer(a) then*/
    if (IS_ATOM_INT(_a_1401))
    _553 = 1;
    else if (IS_ATOM_DBL(_a_1401))
    _553 = IS_ATOM_INT(DoubleToInt(_a_1401));
    else
    _553 = 0;
    if (_553 == 0)
    {
        _553 = NOVALUE;
        goto L2; // [14] 157
    }
    else{
        _553 = NOVALUE;
    }

    /** 			sbuff = sprintf(pretty_int_format, a)*/
    DeRef(_sbuff_1402);
    _sbuff_1402 = EPrintf(-9999999, _10pretty_int_format_1344, _a_1401);

    /** 			if pretty_ascii then */
    if (_10pretty_ascii_1334 == 0)
    {
        goto L3; // [29] 166
    }
    else{
    }

    /** 				if pretty_ascii >= 3 then */
    if (_10pretty_ascii_1334 < 3)
    goto L4; // [36] 103

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) then*/
    if (IS_ATOM_INT(_a_1401)) {
        _556 = (_a_1401 >= _10pretty_ascii_min_1336);
    }
    else {
        _556 = binary_op(GREATEREQ, _a_1401, _10pretty_ascii_min_1336);
    }
    if (IS_ATOM_INT(_556)) {
        if (_556 == 0) {
            _557 = 0;
            goto L5; // [48] 62
        }
    }
    else {
        if (DBL_PTR(_556)->dbl == 0.0) {
            _557 = 0;
            goto L5; // [48] 62
        }
    }
    if (IS_ATOM_INT(_a_1401)) {
        _558 = (_a_1401 <= _10pretty_ascii_max_1337);
    }
    else {
        _558 = binary_op(LESSEQ, _a_1401, _10pretty_ascii_max_1337);
    }
    DeRef(_557);
    if (IS_ATOM_INT(_558))
    _557 = (_558 != 0);
    else
    _557 = DBL_PTR(_558)->dbl != 0.0;
L5: 
    if (_557 == 0)
    {
        _557 = NOVALUE;
        goto L6; // [62] 76
    }
    else{
        _557 = NOVALUE;
    }

    /** 						sbuff = '\'' & a & '\''  -- display char only*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1401;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1402, concat_list, 3);
    }
    goto L3; // [73] 166
L6: 

    /** 					elsif find(a, "\t\n\r\\") then*/
    _562 = find_from(_a_1401, _561, 1);
    if (_562 == 0)
    {
        _562 = NOVALUE;
        goto L3; // [83] 166
    }
    else{
        _562 = NOVALUE;
    }

    /** 						sbuff = '\'' & esc_char(a) & '\''  -- display char only*/
    Ref(_a_1401);
    _563 = _10esc_char(_a_1401);
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _563;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_sbuff_1402, concat_list, 3);
    }
    DeRef(_563);
    _563 = NOVALUE;
    goto L3; // [100] 166
L4: 

    /** 					if (a >= pretty_ascii_min and a <= pretty_ascii_max) and pretty_ascii < 2 then*/
    if (IS_ATOM_INT(_a_1401)) {
        _565 = (_a_1401 >= _10pretty_ascii_min_1336);
    }
    else {
        _565 = binary_op(GREATEREQ, _a_1401, _10pretty_ascii_min_1336);
    }
    if (IS_ATOM_INT(_565)) {
        if (_565 == 0) {
            DeRef(_566);
            _566 = 0;
            goto L7; // [111] 125
        }
    }
    else {
        if (DBL_PTR(_565)->dbl == 0.0) {
            DeRef(_566);
            _566 = 0;
            goto L7; // [111] 125
        }
    }
    if (IS_ATOM_INT(_a_1401)) {
        _567 = (_a_1401 <= _10pretty_ascii_max_1337);
    }
    else {
        _567 = binary_op(LESSEQ, _a_1401, _10pretty_ascii_max_1337);
    }
    DeRef(_566);
    if (IS_ATOM_INT(_567))
    _566 = (_567 != 0);
    else
    _566 = DBL_PTR(_567)->dbl != 0.0;
L7: 
    if (_566 == 0) {
        goto L3; // [125] 166
    }
    _569 = (_10pretty_ascii_1334 < 2);
    if (_569 == 0)
    {
        DeRef(_569);
        _569 = NOVALUE;
        goto L3; // [136] 166
    }
    else{
        DeRef(_569);
        _569 = NOVALUE;
    }

    /** 						sbuff &= '\'' & a & '\'' -- add to numeric display*/
    {
        int concat_list[3];

        concat_list[0] = 39;
        concat_list[1] = _a_1401;
        concat_list[2] = 39;
        Concat_N((object_ptr)&_570, concat_list, 3);
    }
    Concat((object_ptr)&_sbuff_1402, _sbuff_1402, _570);
    DeRefDS(_570);
    _570 = NOVALUE;
    goto L3; // [154] 166
L2: 

    /** 			sbuff = sprintf(pretty_fp_format, a)*/
    DeRef(_sbuff_1402);
    _sbuff_1402 = EPrintf(-9999999, _10pretty_fp_format_1343, _a_1401);
L3: 

    /** 		pretty_out(sbuff)*/
    RefDS(_sbuff_1402);
    _10pretty_out(_sbuff_1402);
    goto L8; // [173] 535
L1: 

    /** 		cut_line(1)*/
    _10cut_line(1);

    /** 		multi_line = 0*/
    _multi_line_1403 = 0;

    /** 		all_ascii = pretty_ascii > 1*/
    _all_ascii_1404 = (_10pretty_ascii_1334 > 1);

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1401)){
            _574 = SEQ_PTR(_a_1401)->length;
    }
    else {
        _574 = 1;
    }
    {
        int _i_1438;
        _i_1438 = 1;
L9: 
        if (_i_1438 > _574){
            goto LA; // [199] 345
        }

        /** 			if sequence(a[i]) and length(a[i]) > 0 then*/
        _2 = (int)SEQ_PTR(_a_1401);
        _575 = (int)*(((s1_ptr)_2)->base + _i_1438);
        _576 = IS_SEQUENCE(_575);
        _575 = NOVALUE;
        if (_576 == 0) {
            goto LB; // [215] 249
        }
        _2 = (int)SEQ_PTR(_a_1401);
        _578 = (int)*(((s1_ptr)_2)->base + _i_1438);
        if (IS_SEQUENCE(_578)){
                _579 = SEQ_PTR(_578)->length;
        }
        else {
            _579 = 1;
        }
        _578 = NOVALUE;
        _580 = (_579 > 0);
        _579 = NOVALUE;
        if (_580 == 0)
        {
            DeRef(_580);
            _580 = NOVALUE;
            goto LB; // [231] 249
        }
        else{
            DeRef(_580);
            _580 = NOVALUE;
        }

        /** 				multi_line = 1*/
        _multi_line_1403 = 1;

        /** 				all_ascii = 0*/
        _all_ascii_1404 = 0;

        /** 				exit*/
        goto LA; // [246] 345
LB: 

        /** 			if not integer(a[i]) or*/
        _2 = (int)SEQ_PTR(_a_1401);
        _581 = (int)*(((s1_ptr)_2)->base + _i_1438);
        if (IS_ATOM_INT(_581))
        _582 = 1;
        else if (IS_ATOM_DBL(_581))
        _582 = IS_ATOM_INT(DoubleToInt(_581));
        else
        _582 = 0;
        _581 = NOVALUE;
        _583 = (_582 == 0);
        _582 = NOVALUE;
        if (_583 != 0) {
            _584 = 1;
            goto LC; // [261] 313
        }
        _2 = (int)SEQ_PTR(_a_1401);
        _585 = (int)*(((s1_ptr)_2)->base + _i_1438);
        if (IS_ATOM_INT(_585)) {
            _586 = (_585 < _10pretty_ascii_min_1336);
        }
        else {
            _586 = binary_op(LESS, _585, _10pretty_ascii_min_1336);
        }
        _585 = NOVALUE;
        if (IS_ATOM_INT(_586)) {
            if (_586 == 0) {
                DeRef(_587);
                _587 = 0;
                goto LD; // [275] 309
            }
        }
        else {
            if (DBL_PTR(_586)->dbl == 0.0) {
                DeRef(_587);
                _587 = 0;
                goto LD; // [275] 309
            }
        }
        _588 = (_10pretty_ascii_1334 < 2);
        if (_588 != 0) {
            _589 = 1;
            goto LE; // [285] 305
        }
        _2 = (int)SEQ_PTR(_a_1401);
        _590 = (int)*(((s1_ptr)_2)->base + _i_1438);
        _592 = find_from(_590, _591, 1);
        _590 = NOVALUE;
        _593 = (_592 == 0);
        _592 = NOVALUE;
        _589 = (_593 != 0);
LE: 
        DeRef(_587);
        _587 = (_589 != 0);
LD: 
        _584 = (_587 != 0);
LC: 
        if (_584 != 0) {
            goto LF; // [313] 332
        }
        _2 = (int)SEQ_PTR(_a_1401);
        _595 = (int)*(((s1_ptr)_2)->base + _i_1438);
        if (IS_ATOM_INT(_595)) {
            _596 = (_595 > _10pretty_ascii_max_1337);
        }
        else {
            _596 = binary_op(GREATER, _595, _10pretty_ascii_max_1337);
        }
        _595 = NOVALUE;
        if (_596 == 0) {
            DeRef(_596);
            _596 = NOVALUE;
            goto L10; // [328] 338
        }
        else {
            if (!IS_ATOM_INT(_596) && DBL_PTR(_596)->dbl == 0.0){
                DeRef(_596);
                _596 = NOVALUE;
                goto L10; // [328] 338
            }
            DeRef(_596);
            _596 = NOVALUE;
        }
        DeRef(_596);
        _596 = NOVALUE;
LF: 

        /** 				all_ascii = 0*/
        _all_ascii_1404 = 0;
L10: 

        /** 		end for*/
        _i_1438 = _i_1438 + 1;
        goto L9; // [340] 206
LA: 
        ;
    }

    /** 		if all_ascii then*/
    if (_all_ascii_1404 == 0)
    {
        goto L11; // [347] 358
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _10pretty_out(34);
    goto L12; // [355] 364
L11: 

    /** 			pretty_out('{')*/
    _10pretty_out(123);
L12: 

    /** 		pretty_level += 1*/
    _10pretty_level_1332 = _10pretty_level_1332 + 1;

    /** 		for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_1401)){
            _598 = SEQ_PTR(_a_1401)->length;
    }
    else {
        _598 = 1;
    }
    {
        int _i_1468;
        _i_1468 = 1;
L13: 
        if (_i_1468 > _598){
            goto L14; // [377] 497
        }

        /** 			if multi_line then*/
        if (_multi_line_1403 == 0)
        {
            goto L15; // [386] 394
        }
        else{
        }

        /** 				indent()*/
        _10indent();
L15: 

        /** 			if all_ascii then*/
        if (_all_ascii_1404 == 0)
        {
            goto L16; // [396] 415
        }
        else{
        }

        /** 				pretty_out(esc_char(a[i]))*/
        _2 = (int)SEQ_PTR(_a_1401);
        _599 = (int)*(((s1_ptr)_2)->base + _i_1468);
        Ref(_599);
        _600 = _10esc_char(_599);
        _599 = NOVALUE;
        _10pretty_out(_600);
        _600 = NOVALUE;
        goto L17; // [412] 425
L16: 

        /** 				rPrint(a[i])*/
        _2 = (int)SEQ_PTR(_a_1401);
        _601 = (int)*(((s1_ptr)_2)->base + _i_1468);
        Ref(_601);
        _10rPrint(_601);
        _601 = NOVALUE;
L17: 

        /** 			if pretty_line_count >= pretty_line_max then*/
        if (_10pretty_line_count_1338 < _10pretty_line_max_1339)
        goto L18; // [431] 459

        /** 				if not pretty_dots then*/
        if (_10pretty_dots_1340 != 0)
        goto L19; // [439] 448

        /** 					pretty_out(" ...")*/
        RefDS(_604);
        _10pretty_out(_604);
L19: 

        /** 				pretty_dots = 1*/
        _10pretty_dots_1340 = 1;

        /** 				return*/
        DeRef(_a_1401);
        DeRef(_sbuff_1402);
        DeRef(_556);
        _556 = NOVALUE;
        DeRef(_558);
        _558 = NOVALUE;
        DeRef(_565);
        _565 = NOVALUE;
        DeRef(_567);
        _567 = NOVALUE;
        _578 = NOVALUE;
        DeRef(_583);
        _583 = NOVALUE;
        DeRef(_588);
        _588 = NOVALUE;
        DeRef(_586);
        _586 = NOVALUE;
        DeRef(_593);
        _593 = NOVALUE;
        return;
L18: 

        /** 			if i != length(a) and not all_ascii then*/
        if (IS_SEQUENCE(_a_1401)){
                _605 = SEQ_PTR(_a_1401)->length;
        }
        else {
            _605 = 1;
        }
        _606 = (_i_1468 != _605);
        _605 = NOVALUE;
        if (_606 == 0) {
            goto L1A; // [468] 490
        }
        _608 = (_all_ascii_1404 == 0);
        if (_608 == 0)
        {
            DeRef(_608);
            _608 = NOVALUE;
            goto L1A; // [476] 490
        }
        else{
            DeRef(_608);
            _608 = NOVALUE;
        }

        /** 				pretty_out(',')*/
        _10pretty_out(44);

        /** 				cut_line(6)*/
        _10cut_line(6);
L1A: 

        /** 		end for*/
        _i_1468 = _i_1468 + 1;
        goto L13; // [492] 384
L14: 
        ;
    }

    /** 		pretty_level -= 1*/
    _10pretty_level_1332 = _10pretty_level_1332 - 1;

    /** 		if multi_line then*/
    if (_multi_line_1403 == 0)
    {
        goto L1B; // [507] 515
    }
    else{
    }

    /** 			indent()*/
    _10indent();
L1B: 

    /** 		if all_ascii then*/
    if (_all_ascii_1404 == 0)
    {
        goto L1C; // [517] 528
    }
    else{
    }

    /** 			pretty_out('\"')*/
    _10pretty_out(34);
    goto L1D; // [525] 534
L1C: 

    /** 			pretty_out('}')*/
    _10pretty_out(125);
L1D: 
L8: 

    /** end procedure*/
    DeRef(_a_1401);
    DeRef(_sbuff_1402);
    DeRef(_556);
    _556 = NOVALUE;
    DeRef(_558);
    _558 = NOVALUE;
    DeRef(_565);
    _565 = NOVALUE;
    DeRef(_567);
    _567 = NOVALUE;
    _578 = NOVALUE;
    DeRef(_583);
    _583 = NOVALUE;
    DeRef(_588);
    _588 = NOVALUE;
    DeRef(_586);
    _586 = NOVALUE;
    DeRef(_593);
    _593 = NOVALUE;
    DeRef(_606);
    _606 = NOVALUE;
    return;
    ;
}


void _10pretty(int _x_1510, int _options_1511)
{
    int _623 = NOVALUE;
    int _622 = NOVALUE;
    int _621 = NOVALUE;
    int _620 = NOVALUE;
    int _618 = NOVALUE;
    int _617 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(options) < length( PRETTY_DEFAULT ) then*/
    if (IS_SEQUENCE(_options_1511)){
            _617 = SEQ_PTR(_options_1511)->length;
    }
    else {
        _617 = 1;
    }
    _618 = 10;
    if (_617 >= 10)
    goto L1; // [13] 41

    /** 		options &= PRETTY_DEFAULT[length(options)+1..$]*/
    if (IS_SEQUENCE(_options_1511)){
            _620 = SEQ_PTR(_options_1511)->length;
    }
    else {
        _620 = 1;
    }
    _621 = _620 + 1;
    _620 = NOVALUE;
    _622 = 10;
    rhs_slice_target = (object_ptr)&_623;
    RHS_Slice(_10PRETTY_DEFAULT_1492, _621, 10);
    Concat((object_ptr)&_options_1511, _options_1511, _623);
    DeRefDS(_623);
    _623 = NOVALUE;
L1: 

    /** 	pretty_ascii = options[DISPLAY_ASCII] */
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_ascii_1334 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_10pretty_ascii_1334))
    _10pretty_ascii_1334 = (long)DBL_PTR(_10pretty_ascii_1334)->dbl;

    /** 	pretty_indent = options[INDENT]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_indent_1335 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_10pretty_indent_1335))
    _10pretty_indent_1335 = (long)DBL_PTR(_10pretty_indent_1335)->dbl;

    /** 	pretty_start_col = options[START_COLUMN]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_start_col_1331 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_10pretty_start_col_1331))
    _10pretty_start_col_1331 = (long)DBL_PTR(_10pretty_start_col_1331)->dbl;

    /** 	pretty_end_col = options[WRAP]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_end_col_1329 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_10pretty_end_col_1329))
    _10pretty_end_col_1329 = (long)DBL_PTR(_10pretty_end_col_1329)->dbl;

    /** 	pretty_int_format = options[INT_FORMAT]*/
    DeRef(_10pretty_int_format_1344);
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_int_format_1344 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_10pretty_int_format_1344);

    /** 	pretty_fp_format = options[FP_FORMAT]*/
    DeRef(_10pretty_fp_format_1343);
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_fp_format_1343 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_10pretty_fp_format_1343);

    /** 	pretty_ascii_min = options[MIN_ASCII]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_ascii_min_1336 = (int)*(((s1_ptr)_2)->base + 7);
    if (!IS_ATOM_INT(_10pretty_ascii_min_1336))
    _10pretty_ascii_min_1336 = (long)DBL_PTR(_10pretty_ascii_min_1336)->dbl;

    /** 	pretty_ascii_max = options[MAX_ASCII]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_ascii_max_1337 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_10pretty_ascii_max_1337))
    _10pretty_ascii_max_1337 = (long)DBL_PTR(_10pretty_ascii_max_1337)->dbl;

    /** 	pretty_line_max = options[MAX_LINES]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_line_max_1339 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_10pretty_line_max_1339))
    _10pretty_line_max_1339 = (long)DBL_PTR(_10pretty_line_max_1339)->dbl;

    /** 	pretty_line_breaks = options[LINE_BREAKS]*/
    _2 = (int)SEQ_PTR(_options_1511);
    _10pretty_line_breaks_1341 = (int)*(((s1_ptr)_2)->base + 10);
    if (!IS_ATOM_INT(_10pretty_line_breaks_1341))
    _10pretty_line_breaks_1341 = (long)DBL_PTR(_10pretty_line_breaks_1341)->dbl;

    /** 	pretty_chars = pretty_start_col*/
    _10pretty_chars_1330 = _10pretty_start_col_1331;

    /** 	pretty_level = 0 */
    _10pretty_level_1332 = 0;

    /** 	pretty_line = ""*/
    RefDS(_5);
    DeRef(_10pretty_line_1345);
    _10pretty_line_1345 = _5;

    /** 	pretty_line_count = 0*/
    _10pretty_line_count_1338 = 0;

    /** 	pretty_dots = 0*/
    _10pretty_dots_1340 = 0;

    /** 	rPrint(x)*/
    Ref(_x_1510);
    _10rPrint(_x_1510);

    /** end procedure*/
    DeRef(_x_1510);
    DeRefDS(_options_1511);
    DeRef(_621);
    _621 = NOVALUE;
    return;
    ;
}


void _10pretty_print(int _fn_1533, int _x_1534, int _options_1535)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_fn_1533)) {
        _1 = (long)(DBL_PTR(_fn_1533)->dbl);
        DeRefDS(_fn_1533);
        _fn_1533 = _1;
    }

    /** 	pretty_printing = 1*/
    _10pretty_printing_1342 = 1;

    /** 	pretty_file = fn*/
    _10pretty_file_1333 = _fn_1533;

    /** 	pretty( x, options )*/
    Ref(_x_1534);
    RefDS(_options_1535);
    _10pretty(_x_1534, _options_1535);

    /** 	puts(pretty_file, pretty_line)*/
    EPuts(_10pretty_file_1333, _10pretty_line_1345); // DJP 

    /** end procedure*/
    DeRef(_x_1534);
    DeRefDS(_options_1535);
    return;
    ;
}


int _10pretty_sprint(int _x_1538, int _options_1539)
{
    int _0, _1, _2;
    

    /** 	pretty_printing = 0*/
    _10pretty_printing_1342 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_1538);
    RefDS(_options_1539);
    _10pretty(_x_1538, _options_1539);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1345);
    DeRef(_x_1538);
    DeRefDS(_options_1539);
    return _10pretty_line_1345;
    ;
}



// 0xA72D72DE
