// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _15isLeap(int _year_8213)
{
    int _ly_8214 = NOVALUE;
    int _4500 = NOVALUE;
    int _4499 = NOVALUE;
    int _4498 = NOVALUE;
    int _4497 = NOVALUE;
    int _4496 = NOVALUE;
    int _4495 = NOVALUE;
    int _4494 = NOVALUE;
    int _4493 = NOVALUE;
    int _4492 = NOVALUE;
    int _4489 = NOVALUE;
    int _4487 = NOVALUE;
    int _4486 = NOVALUE;
    int _0, _1, _2;
    

    /** 		ly = (remainder(year, {4, 100, 400, 3200, 80000})=0)*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 4;
    *((int *)(_2+8)) = 100;
    *((int *)(_2+12)) = 400;
    *((int *)(_2+16)) = 3200;
    *((int *)(_2+20)) = 80000;
    _4486 = MAKE_SEQ(_1);
    _4487 = binary_op(REMAINDER, _year_8213, _4486);
    DeRefDS(_4486);
    _4486 = NOVALUE;
    DeRefi(_ly_8214);
    _ly_8214 = binary_op(EQUALS, _4487, 0);
    DeRefDS(_4487);
    _4487 = NOVALUE;

    /** 		if not ly[1] then return 0 end if*/
    _2 = (int)SEQ_PTR(_ly_8214);
    _4489 = (int)*(((s1_ptr)_2)->base + 1);
    if (_4489 != 0)
    goto L1; // [29] 37
    _4489 = NOVALUE;
    DeRefDSi(_ly_8214);
    return 0;
L1: 

    /** 		if year <= Gregorian_Reformation then*/
    if (_year_8213 > 1752)
    goto L2; // [39] 52

    /** 				return 1 -- ly[1] can't possibly be 0 here so set shortcut as '1'.*/
    DeRefi(_ly_8214);
    return 1;
    goto L3; // [49] 95
L2: 

    /** 				return ly[1] - ly[2] + ly[3] - ly[4] + ly[5]*/
    _2 = (int)SEQ_PTR(_ly_8214);
    _4492 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_ly_8214);
    _4493 = (int)*(((s1_ptr)_2)->base + 2);
    _4494 = _4492 - _4493;
    if ((long)((unsigned long)_4494 +(unsigned long) HIGH_BITS) >= 0){
        _4494 = NewDouble((double)_4494);
    }
    _4492 = NOVALUE;
    _4493 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_8214);
    _4495 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_4494)) {
        _4496 = _4494 + _4495;
        if ((long)((unsigned long)_4496 + (unsigned long)HIGH_BITS) >= 0) 
        _4496 = NewDouble((double)_4496);
    }
    else {
        _4496 = NewDouble(DBL_PTR(_4494)->dbl + (double)_4495);
    }
    DeRef(_4494);
    _4494 = NOVALUE;
    _4495 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_8214);
    _4497 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_4496)) {
        _4498 = _4496 - _4497;
        if ((long)((unsigned long)_4498 +(unsigned long) HIGH_BITS) >= 0){
            _4498 = NewDouble((double)_4498);
        }
    }
    else {
        _4498 = NewDouble(DBL_PTR(_4496)->dbl - (double)_4497);
    }
    DeRef(_4496);
    _4496 = NOVALUE;
    _4497 = NOVALUE;
    _2 = (int)SEQ_PTR(_ly_8214);
    _4499 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_4498)) {
        _4500 = _4498 + _4499;
        if ((long)((unsigned long)_4500 + (unsigned long)HIGH_BITS) >= 0) 
        _4500 = NewDouble((double)_4500);
    }
    else {
        _4500 = NewDouble(DBL_PTR(_4498)->dbl + (double)_4499);
    }
    DeRef(_4498);
    _4498 = NOVALUE;
    _4499 = NOVALUE;
    DeRefDSi(_ly_8214);
    return _4500;
L3: 
    ;
}


int _15daysInMonth(int _year_8238, int _month_8239)
{
    int _4508 = NOVALUE;
    int _4507 = NOVALUE;
    int _4506 = NOVALUE;
    int _4505 = NOVALUE;
    int _4503 = NOVALUE;
    int _4502 = NOVALUE;
    int _4501 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_month_8239)) {
        _1 = (long)(DBL_PTR(_month_8239)->dbl);
        DeRefDS(_month_8239);
        _month_8239 = _1;
    }

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _4501 = (_year_8238 == 1752);
    if (_4501 == 0) {
        goto L1; // [11] 32
    }
    _4503 = (_month_8239 == 9);
    if (_4503 == 0)
    {
        DeRef(_4503);
        _4503 = NOVALUE;
        goto L1; // [20] 32
    }
    else{
        DeRef(_4503);
        _4503 = NOVALUE;
    }

    /** 		return 19*/
    DeRef(_4501);
    _4501 = NOVALUE;
    return 19;
    goto L2; // [29] 70
L1: 

    /** 	elsif month != 2 then*/
    if (_month_8239 == 2)
    goto L3; // [34] 51

    /** 		return DaysPerMonth[month]*/
    _2 = (int)SEQ_PTR(_15DaysPerMonth_8195);
    _4505 = (int)*(((s1_ptr)_2)->base + _month_8239);
    Ref(_4505);
    DeRef(_4501);
    _4501 = NOVALUE;
    return _4505;
    goto L2; // [48] 70
L3: 

    /** 		return DaysPerMonth[month] + isLeap(year)*/
    _2 = (int)SEQ_PTR(_15DaysPerMonth_8195);
    _4506 = (int)*(((s1_ptr)_2)->base + _month_8239);
    _4507 = _15isLeap(_year_8238);
    if (IS_ATOM_INT(_4506) && IS_ATOM_INT(_4507)) {
        _4508 = _4506 + _4507;
        if ((long)((unsigned long)_4508 + (unsigned long)HIGH_BITS) >= 0) 
        _4508 = NewDouble((double)_4508);
    }
    else {
        _4508 = binary_op(PLUS, _4506, _4507);
    }
    _4506 = NOVALUE;
    DeRef(_4507);
    _4507 = NOVALUE;
    DeRef(_4501);
    _4501 = NOVALUE;
    _4505 = NOVALUE;
    return _4508;
L2: 
    ;
}


int _15julianDayOfYear(int _ymd_8262)
{
    int _year_8263 = NOVALUE;
    int _month_8264 = NOVALUE;
    int _day_8265 = NOVALUE;
    int _d_8266 = NOVALUE;
    int _4524 = NOVALUE;
    int _4523 = NOVALUE;
    int _4522 = NOVALUE;
    int _4519 = NOVALUE;
    int _4518 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_8262);
    _year_8263 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_8263)){
        _year_8263 = (long)DBL_PTR(_year_8263)->dbl;
    }

    /** 	month = ymd[2]*/
    _2 = (int)SEQ_PTR(_ymd_8262);
    _month_8264 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_month_8264)){
        _month_8264 = (long)DBL_PTR(_month_8264)->dbl;
    }

    /** 	day = ymd[3]*/
    _2 = (int)SEQ_PTR(_ymd_8262);
    _day_8265 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_day_8265)){
        _day_8265 = (long)DBL_PTR(_day_8265)->dbl;
    }

    /** 	if month = 1 then return day end if*/
    if (_month_8264 != 1)
    goto L1; // [27] 36
    DeRef(_ymd_8262);
    return _day_8265;
L1: 

    /** 	d = 0*/
    _d_8266 = 0;

    /** 	for i = 1 to month - 1 do*/
    _4518 = _month_8264 - 1;
    if ((long)((unsigned long)_4518 +(unsigned long) HIGH_BITS) >= 0){
        _4518 = NewDouble((double)_4518);
    }
    {
        int _i_8273;
        _i_8273 = 1;
L2: 
        if (binary_op_a(GREATER, _i_8273, _4518)){
            goto L3; // [47] 74
        }

        /** 		d += daysInMonth(year, i)*/
        Ref(_i_8273);
        _4519 = _15daysInMonth(_year_8263, _i_8273);
        if (IS_ATOM_INT(_4519)) {
            _d_8266 = _d_8266 + _4519;
        }
        else {
            _d_8266 = binary_op(PLUS, _d_8266, _4519);
        }
        DeRef(_4519);
        _4519 = NOVALUE;
        if (!IS_ATOM_INT(_d_8266)) {
            _1 = (long)(DBL_PTR(_d_8266)->dbl);
            DeRefDS(_d_8266);
            _d_8266 = _1;
        }

        /** 	end for*/
        _0 = _i_8273;
        if (IS_ATOM_INT(_i_8273)) {
            _i_8273 = _i_8273 + 1;
            if ((long)((unsigned long)_i_8273 +(unsigned long) HIGH_BITS) >= 0){
                _i_8273 = NewDouble((double)_i_8273);
            }
        }
        else {
            _i_8273 = binary_op_a(PLUS, _i_8273, 1);
        }
        DeRef(_0);
        goto L2; // [69] 54
L3: 
        ;
        DeRef(_i_8273);
    }

    /** 	d += day*/
    _d_8266 = _d_8266 + _day_8265;

    /** 	if year = Gregorian_Reformation and month = 9 then*/
    _4522 = (_year_8263 == 1752);
    if (_4522 == 0) {
        goto L4; // [86] 128
    }
    _4524 = (_month_8264 == 9);
    if (_4524 == 0)
    {
        DeRef(_4524);
        _4524 = NOVALUE;
        goto L4; // [95] 128
    }
    else{
        DeRef(_4524);
        _4524 = NOVALUE;
    }

    /** 		if day > 13 then*/
    if (_day_8265 <= 13)
    goto L5; // [100] 113

    /** 			d -= 11*/
    _d_8266 = _d_8266 - 11;
    goto L6; // [110] 127
L5: 

    /** 		elsif day > 2 then*/
    if (_day_8265 <= 2)
    goto L7; // [115] 126

    /** 			return 0*/
    DeRef(_ymd_8262);
    DeRef(_4518);
    _4518 = NOVALUE;
    DeRef(_4522);
    _4522 = NOVALUE;
    return 0;
L7: 
L6: 
L4: 

    /** 	return d*/
    DeRef(_ymd_8262);
    DeRef(_4518);
    _4518 = NOVALUE;
    DeRef(_4522);
    _4522 = NOVALUE;
    return _d_8266;
    ;
}


int _15julianDay(int _ymd_8289)
{
    int _year_8290 = NOVALUE;
    int _j_8291 = NOVALUE;
    int _greg00_8292 = NOVALUE;
    int _4553 = NOVALUE;
    int _4550 = NOVALUE;
    int _4547 = NOVALUE;
    int _4546 = NOVALUE;
    int _4545 = NOVALUE;
    int _4544 = NOVALUE;
    int _4543 = NOVALUE;
    int _4542 = NOVALUE;
    int _4541 = NOVALUE;
    int _4540 = NOVALUE;
    int _4538 = NOVALUE;
    int _4537 = NOVALUE;
    int _4536 = NOVALUE;
    int _4535 = NOVALUE;
    int _4534 = NOVALUE;
    int _4533 = NOVALUE;
    int _4532 = NOVALUE;
    int _0, _1, _2;
    

    /** 	year = ymd[1]*/
    _2 = (int)SEQ_PTR(_ymd_8289);
    _year_8290 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_year_8290)){
        _year_8290 = (long)DBL_PTR(_year_8290)->dbl;
    }

    /** 	j = julianDayOfYear(ymd)*/
    Ref(_ymd_8289);
    _j_8291 = _15julianDayOfYear(_ymd_8289);
    if (!IS_ATOM_INT(_j_8291)) {
        _1 = (long)(DBL_PTR(_j_8291)->dbl);
        DeRefDS(_j_8291);
        _j_8291 = _1;
    }

    /** 	year  -= 1*/
    _year_8290 = _year_8290 - 1;

    /** 	greg00 = year - Gregorian_Reformation00*/
    _greg00_8292 = _year_8290 - 1700;

    /** 	j += (*/
    if (_year_8290 <= INT15 && _year_8290 >= -INT15)
    _4532 = 365 * _year_8290;
    else
    _4532 = NewDouble(365 * (double)_year_8290);
    if (4 > 0 && _year_8290 >= 0) {
        _4533 = _year_8290 / 4;
    }
    else {
        temp_dbl = floor((double)_year_8290 / (double)4);
        _4533 = (long)temp_dbl;
    }
    if (IS_ATOM_INT(_4532)) {
        _4534 = _4532 + _4533;
        if ((long)((unsigned long)_4534 + (unsigned long)HIGH_BITS) >= 0) 
        _4534 = NewDouble((double)_4534);
    }
    else {
        _4534 = NewDouble(DBL_PTR(_4532)->dbl + (double)_4533);
    }
    DeRef(_4532);
    _4532 = NOVALUE;
    _4533 = NOVALUE;
    _4535 = (_greg00_8292 > 0);
    if (100 > 0 && _greg00_8292 >= 0) {
        _4536 = _greg00_8292 / 100;
    }
    else {
        temp_dbl = floor((double)_greg00_8292 / (double)100);
        _4536 = (long)temp_dbl;
    }
    _4537 = - _4536;
    _4538 = (_greg00_8292 % 400) ? NewDouble((double)_greg00_8292 / 400) : (_greg00_8292 / 400);
    if (IS_ATOM_INT(_4538)) {
        _4540 = NewDouble((double)_4538 + DBL_PTR(_4539)->dbl);
    }
    else {
        _4540 = NewDouble(DBL_PTR(_4538)->dbl + DBL_PTR(_4539)->dbl);
    }
    DeRef(_4538);
    _4538 = NOVALUE;
    _4541 = unary_op(FLOOR, _4540);
    DeRefDS(_4540);
    _4540 = NOVALUE;
    if (IS_ATOM_INT(_4541)) {
        _4542 = _4537 + _4541;
        if ((long)((unsigned long)_4542 + (unsigned long)HIGH_BITS) >= 0) 
        _4542 = NewDouble((double)_4542);
    }
    else {
        _4542 = NewDouble((double)_4537 + DBL_PTR(_4541)->dbl);
    }
    _4537 = NOVALUE;
    DeRef(_4541);
    _4541 = NOVALUE;
    if (IS_ATOM_INT(_4542)) {
        if (_4542 <= INT15 && _4542 >= -INT15)
        _4543 = _4535 * _4542;
        else
        _4543 = NewDouble(_4535 * (double)_4542);
    }
    else {
        _4543 = NewDouble((double)_4535 * DBL_PTR(_4542)->dbl);
    }
    _4535 = NOVALUE;
    DeRef(_4542);
    _4542 = NOVALUE;
    if (IS_ATOM_INT(_4534) && IS_ATOM_INT(_4543)) {
        _4544 = _4534 + _4543;
        if ((long)((unsigned long)_4544 + (unsigned long)HIGH_BITS) >= 0) 
        _4544 = NewDouble((double)_4544);
    }
    else {
        if (IS_ATOM_INT(_4534)) {
            _4544 = NewDouble((double)_4534 + DBL_PTR(_4543)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4543)) {
                _4544 = NewDouble(DBL_PTR(_4534)->dbl + (double)_4543);
            }
            else
            _4544 = NewDouble(DBL_PTR(_4534)->dbl + DBL_PTR(_4543)->dbl);
        }
    }
    DeRef(_4534);
    _4534 = NOVALUE;
    DeRef(_4543);
    _4543 = NOVALUE;
    _4545 = (_year_8290 >= 1752);
    _4546 = 11 * _4545;
    _4545 = NOVALUE;
    if (IS_ATOM_INT(_4544)) {
        _4547 = _4544 - _4546;
        if ((long)((unsigned long)_4547 +(unsigned long) HIGH_BITS) >= 0){
            _4547 = NewDouble((double)_4547);
        }
    }
    else {
        _4547 = NewDouble(DBL_PTR(_4544)->dbl - (double)_4546);
    }
    DeRef(_4544);
    _4544 = NOVALUE;
    _4546 = NOVALUE;
    if (IS_ATOM_INT(_4547)) {
        _j_8291 = _j_8291 + _4547;
    }
    else {
        _j_8291 = NewDouble((double)_j_8291 + DBL_PTR(_4547)->dbl);
    }
    DeRef(_4547);
    _4547 = NOVALUE;
    if (!IS_ATOM_INT(_j_8291)) {
        _1 = (long)(DBL_PTR(_j_8291)->dbl);
        DeRefDS(_j_8291);
        _j_8291 = _1;
    }

    /** 	if year >= 3200 then*/
    if (_year_8290 < 3200)
    goto L1; // [97] 133

    /** 		j -= floor(year/ 3200)*/
    if (3200 > 0 && _year_8290 >= 0) {
        _4550 = _year_8290 / 3200;
    }
    else {
        temp_dbl = floor((double)_year_8290 / (double)3200);
        _4550 = (long)temp_dbl;
    }
    _j_8291 = _j_8291 - _4550;
    _4550 = NOVALUE;

    /** 		if year >= 80000 then*/
    if (_year_8290 < 80000)
    goto L2; // [115] 132

    /** 			j += floor(year/80000)*/
    if (80000 > 0 && _year_8290 >= 0) {
        _4553 = _year_8290 / 80000;
    }
    else {
        temp_dbl = floor((double)_year_8290 / (double)80000);
        _4553 = (long)temp_dbl;
    }
    _j_8291 = _j_8291 + _4553;
    _4553 = NOVALUE;
L2: 
L1: 

    /** 	return j*/
    DeRef(_ymd_8289);
    DeRef(_4536);
    _4536 = NOVALUE;
    return _j_8291;
    ;
}


int _15datetimeToSeconds(int _dt_8378)
{
    int _4596 = NOVALUE;
    int _4595 = NOVALUE;
    int _4594 = NOVALUE;
    int _4593 = NOVALUE;
    int _4592 = NOVALUE;
    int _4591 = NOVALUE;
    int _4590 = NOVALUE;
    int _4589 = NOVALUE;
    int _4588 = NOVALUE;
    int _4587 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return julianDay(dt) * DayLengthInSeconds + (dt[4] * 60 + dt[5]) * 60 + dt[6]*/
    Ref(_dt_8378);
    _4587 = _15julianDay(_dt_8378);
    if (IS_ATOM_INT(_4587)) {
        _4588 = NewDouble(_4587 * (double)86400);
    }
    else {
        _4588 = binary_op(MULTIPLY, _4587, 86400);
    }
    DeRef(_4587);
    _4587 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_8378);
    _4589 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_4589)) {
        if (_4589 == (short)_4589)
        _4590 = _4589 * 60;
        else
        _4590 = NewDouble(_4589 * (double)60);
    }
    else {
        _4590 = binary_op(MULTIPLY, _4589, 60);
    }
    _4589 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_8378);
    _4591 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_4590) && IS_ATOM_INT(_4591)) {
        _4592 = _4590 + _4591;
        if ((long)((unsigned long)_4592 + (unsigned long)HIGH_BITS) >= 0) 
        _4592 = NewDouble((double)_4592);
    }
    else {
        _4592 = binary_op(PLUS, _4590, _4591);
    }
    DeRef(_4590);
    _4590 = NOVALUE;
    _4591 = NOVALUE;
    if (IS_ATOM_INT(_4592)) {
        if (_4592 == (short)_4592)
        _4593 = _4592 * 60;
        else
        _4593 = NewDouble(_4592 * (double)60);
    }
    else {
        _4593 = binary_op(MULTIPLY, _4592, 60);
    }
    DeRef(_4592);
    _4592 = NOVALUE;
    if (IS_ATOM_INT(_4588) && IS_ATOM_INT(_4593)) {
        _4594 = _4588 + _4593;
        if ((long)((unsigned long)_4594 + (unsigned long)HIGH_BITS) >= 0) 
        _4594 = NewDouble((double)_4594);
    }
    else {
        _4594 = binary_op(PLUS, _4588, _4593);
    }
    DeRef(_4588);
    _4588 = NOVALUE;
    DeRef(_4593);
    _4593 = NOVALUE;
    _2 = (int)SEQ_PTR(_dt_8378);
    _4595 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_ATOM_INT(_4594) && IS_ATOM_INT(_4595)) {
        _4596 = _4594 + _4595;
        if ((long)((unsigned long)_4596 + (unsigned long)HIGH_BITS) >= 0) 
        _4596 = NewDouble((double)_4596);
    }
    else {
        _4596 = binary_op(PLUS, _4594, _4595);
    }
    DeRef(_4594);
    _4594 = NOVALUE;
    _4595 = NOVALUE;
    DeRef(_dt_8378);
    return _4596;
    ;
}


int _15from_date(int _src_8542)
{
    int _4709 = NOVALUE;
    int _4708 = NOVALUE;
    int _4707 = NOVALUE;
    int _4706 = NOVALUE;
    int _4705 = NOVALUE;
    int _4704 = NOVALUE;
    int _4703 = NOVALUE;
    int _4701 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return {src[YEAR]+1900, src[MONTH], src[DAY], src[HOUR], src[MINUTE], src[SECOND]}*/
    _2 = (int)SEQ_PTR(_src_8542);
    _4701 = (int)*(((s1_ptr)_2)->base + 1);
    _4703 = _4701 + 1900;
    if ((long)((unsigned long)_4703 + (unsigned long)HIGH_BITS) >= 0) 
    _4703 = NewDouble((double)_4703);
    _4701 = NOVALUE;
    _2 = (int)SEQ_PTR(_src_8542);
    _4704 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_src_8542);
    _4705 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_src_8542);
    _4706 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_src_8542);
    _4707 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_src_8542);
    _4708 = (int)*(((s1_ptr)_2)->base + 6);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _4703;
    *((int *)(_2+8)) = _4704;
    *((int *)(_2+12)) = _4705;
    *((int *)(_2+16)) = _4706;
    *((int *)(_2+20)) = _4707;
    *((int *)(_2+24)) = _4708;
    _4709 = MAKE_SEQ(_1);
    _4708 = NOVALUE;
    _4707 = NOVALUE;
    _4706 = NOVALUE;
    _4705 = NOVALUE;
    _4704 = NOVALUE;
    _4703 = NOVALUE;
    DeRefDSi(_src_8542);
    return _4709;
    ;
}


int _15new(int _year_8574, int _month_8575, int _day_8576, int _hour_8577, int _minute_8578, int _second_8579)
{
    int _d_8580 = NOVALUE;
    int _now_1__tmp_at41_8587 = NOVALUE;
    int _now_inlined_now_at_41_8586 = NOVALUE;
    int _4724 = NOVALUE;
    int _4723 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_year_8574)) {
        _1 = (long)(DBL_PTR(_year_8574)->dbl);
        DeRefDS(_year_8574);
        _year_8574 = _1;
    }
    if (!IS_ATOM_INT(_month_8575)) {
        _1 = (long)(DBL_PTR(_month_8575)->dbl);
        DeRefDS(_month_8575);
        _month_8575 = _1;
    }
    if (!IS_ATOM_INT(_day_8576)) {
        _1 = (long)(DBL_PTR(_day_8576)->dbl);
        DeRefDS(_day_8576);
        _day_8576 = _1;
    }
    if (!IS_ATOM_INT(_hour_8577)) {
        _1 = (long)(DBL_PTR(_hour_8577)->dbl);
        DeRefDS(_hour_8577);
        _hour_8577 = _1;
    }
    if (!IS_ATOM_INT(_minute_8578)) {
        _1 = (long)(DBL_PTR(_minute_8578)->dbl);
        DeRefDS(_minute_8578);
        _minute_8578 = _1;
    }

    /** 	d = {year, month, day, hour, minute, second}*/
    _0 = _d_8580;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _year_8574;
    *((int *)(_2+8)) = _month_8575;
    *((int *)(_2+12)) = _day_8576;
    *((int *)(_2+16)) = _hour_8577;
    *((int *)(_2+20)) = _minute_8578;
    Ref(_second_8579);
    *((int *)(_2+24)) = _second_8579;
    _d_8580 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	if equal(d, {0,0,0,0,0,0}) then*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _4723 = MAKE_SEQ(_1);
    if (_d_8580 == _4723)
    _4724 = 1;
    else if (IS_ATOM_INT(_d_8580) && IS_ATOM_INT(_4723))
    _4724 = 0;
    else
    _4724 = (compare(_d_8580, _4723) == 0);
    DeRefDS(_4723);
    _4723 = NOVALUE;
    if (_4724 == 0)
    {
        _4724 = NOVALUE;
        goto L1; // [37] 60
    }
    else{
        _4724 = NOVALUE;
    }

    /** 		return now()*/

    /** 	return from_date(date())*/
    DeRefi(_now_1__tmp_at41_8587);
    _now_1__tmp_at41_8587 = Date();
    RefDS(_now_1__tmp_at41_8587);
    _0 = _now_inlined_now_at_41_8586;
    _now_inlined_now_at_41_8586 = _15from_date(_now_1__tmp_at41_8587);
    DeRef(_0);
    DeRefi(_now_1__tmp_at41_8587);
    _now_1__tmp_at41_8587 = NOVALUE;
    DeRef(_second_8579);
    DeRef(_d_8580);
    return _now_inlined_now_at_41_8586;
    goto L2; // [57] 67
L1: 

    /** 		return d*/
    DeRef(_second_8579);
    return _d_8580;
L2: 
    ;
}



// 0xE312FF0A
