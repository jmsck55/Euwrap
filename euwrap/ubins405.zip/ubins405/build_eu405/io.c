// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _17get_bytes(int _fn_7229, int _n_7230)
{
    int _s_7231 = NOVALUE;
    int _c_7232 = NOVALUE;
    int _first_7233 = NOVALUE;
    int _last_7234 = NOVALUE;
    int _3977 = NOVALUE;
    int _3974 = NOVALUE;
    int _3972 = NOVALUE;
    int _3971 = NOVALUE;
    int _3970 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_7230)) {
        _1 = (long)(DBL_PTR(_n_7230)->dbl);
        DeRefDS(_n_7230);
        _n_7230 = _1;
    }

    /** 	if n = 0 then*/
    if (_n_7230 != 0)
    goto L1; // [7] 18

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_7231);
    return _5;
L1: 

    /** 	c = getc(fn)*/
    if (_fn_7229 != last_r_file_no) {
        last_r_file_ptr = which_file(_fn_7229, EF_READ);
        last_r_file_no = _fn_7229;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_7232 = getc((FILE*)xstdin);
        }
        else
        _c_7232 = getc(last_r_file_ptr);
    }
    else
    _c_7232 = getc(last_r_file_ptr);

    /** 	if c = EOF then*/
    if (_c_7232 != -1)
    goto L2; // [25] 36

    /** 		return {}*/
    RefDS(_5);
    DeRefi(_s_7231);
    return _5;
L2: 

    /** 	s = repeat(c, n)*/
    DeRefi(_s_7231);
    _s_7231 = Repeat(_c_7232, _n_7230);

    /** 	last = 1*/
    _last_7234 = 1;

    /** 	while last < n do*/
L3: 
    if (_last_7234 >= _n_7230)
    goto L4; // [52] 159

    /** 		first = last+1*/
    _first_7233 = _last_7234 + 1;

    /** 		last  = last+CHUNK*/
    _last_7234 = _last_7234 + 100;

    /** 		if last > n then*/
    if (_last_7234 <= _n_7230)
    goto L5; // [70] 80

    /** 			last = n*/
    _last_7234 = _n_7230;
L5: 

    /** 		for i = first to last do*/
    _3970 = _last_7234;
    {
        int _i_7248;
        _i_7248 = _first_7233;
L6: 
        if (_i_7248 > _3970){
            goto L7; // [85] 108
        }

        /** 			s[i] = getc(fn)*/
        if (_fn_7229 != last_r_file_no) {
            last_r_file_ptr = which_file(_fn_7229, EF_READ);
            last_r_file_no = _fn_7229;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _3971 = getc((FILE*)xstdin);
            }
            else
            _3971 = getc(last_r_file_ptr);
        }
        else
        _3971 = getc(last_r_file_ptr);
        _2 = (int)SEQ_PTR(_s_7231);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_7231 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_7248);
        *(int *)_2 = _3971;
        if( _1 != _3971 ){
        }
        _3971 = NOVALUE;

        /** 		end for*/
        _i_7248 = _i_7248 + 1;
        goto L6; // [103] 92
L7: 
        ;
    }

    /** 		if s[last] = EOF then*/
    _2 = (int)SEQ_PTR(_s_7231);
    _3972 = (int)*(((s1_ptr)_2)->base + _last_7234);
    if (_3972 != -1)
    goto L3; // [114] 52

    /** 			while s[last] = EOF do*/
L8: 
    _2 = (int)SEQ_PTR(_s_7231);
    _3974 = (int)*(((s1_ptr)_2)->base + _last_7234);
    if (_3974 != -1)
    goto L9; // [127] 142

    /** 				last -= 1*/
    _last_7234 = _last_7234 - 1;

    /** 			end while*/
    goto L8; // [139] 123
L9: 

    /** 			return s[1..last]*/
    rhs_slice_target = (object_ptr)&_3977;
    RHS_Slice(_s_7231, 1, _last_7234);
    DeRefDSi(_s_7231);
    _3972 = NOVALUE;
    _3974 = NOVALUE;
    return _3977;

    /** 	end while*/
    goto L3; // [156] 52
L4: 

    /** 	return s*/
    _3972 = NOVALUE;
    _3974 = NOVALUE;
    DeRef(_3977);
    _3977 = NOVALUE;
    return _s_7231;
    ;
}


int _17get_integer32(int _fh_7269)
{
    int _3986 = NOVALUE;
    int _3985 = NOVALUE;
    int _3984 = NOVALUE;
    int _3983 = NOVALUE;
    int _3982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_7269 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7269, EF_READ);
        last_r_file_no = _fh_7269;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3982 = getc((FILE*)xstdin);
        }
        else
        _3982 = getc(last_r_file_ptr);
    }
    else
    _3982 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem0_7259)){
        poke_addr = (unsigned char *)_17mem0_7259;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem0_7259)->dbl);
    }
    *poke_addr = (unsigned char)_3982;
    _3982 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_7269 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7269, EF_READ);
        last_r_file_no = _fh_7269;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3983 = getc((FILE*)xstdin);
        }
        else
        _3983 = getc(last_r_file_ptr);
    }
    else
    _3983 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem1_7260)){
        poke_addr = (unsigned char *)_17mem1_7260;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem1_7260)->dbl);
    }
    *poke_addr = (unsigned char)_3983;
    _3983 = NOVALUE;

    /** 	poke(mem2, getc(fh))*/
    if (_fh_7269 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7269, EF_READ);
        last_r_file_no = _fh_7269;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3984 = getc((FILE*)xstdin);
        }
        else
        _3984 = getc(last_r_file_ptr);
    }
    else
    _3984 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem2_7261)){
        poke_addr = (unsigned char *)_17mem2_7261;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem2_7261)->dbl);
    }
    *poke_addr = (unsigned char)_3984;
    _3984 = NOVALUE;

    /** 	poke(mem3, getc(fh))*/
    if (_fh_7269 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7269, EF_READ);
        last_r_file_no = _fh_7269;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3985 = getc((FILE*)xstdin);
        }
        else
        _3985 = getc(last_r_file_ptr);
    }
    else
    _3985 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem3_7262)){
        poke_addr = (unsigned char *)_17mem3_7262;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem3_7262)->dbl);
    }
    *poke_addr = (unsigned char)_3985;
    _3985 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_17mem0_7259)) {
        _3986 = *(unsigned long *)_17mem0_7259;
        if ((unsigned)_3986 > (unsigned)MAXINT)
        _3986 = NewDouble((double)(unsigned long)_3986);
    }
    else {
        _3986 = *(unsigned long *)(unsigned long)(DBL_PTR(_17mem0_7259)->dbl);
        if ((unsigned)_3986 > (unsigned)MAXINT)
        _3986 = NewDouble((double)(unsigned long)_3986);
    }
    return _3986;
    ;
}


int _17get_integer16(int _fh_7277)
{
    int _3989 = NOVALUE;
    int _3988 = NOVALUE;
    int _3987 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(fh))*/
    if (_fh_7277 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7277, EF_READ);
        last_r_file_no = _fh_7277;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3987 = getc((FILE*)xstdin);
        }
        else
        _3987 = getc(last_r_file_ptr);
    }
    else
    _3987 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem0_7259)){
        poke_addr = (unsigned char *)_17mem0_7259;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem0_7259)->dbl);
    }
    *poke_addr = (unsigned char)_3987;
    _3987 = NOVALUE;

    /** 	poke(mem1, getc(fh))*/
    if (_fh_7277 != last_r_file_no) {
        last_r_file_ptr = which_file(_fh_7277, EF_READ);
        last_r_file_no = _fh_7277;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _3988 = getc((FILE*)xstdin);
        }
        else
        _3988 = getc(last_r_file_ptr);
    }
    else
    _3988 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_17mem1_7260)){
        poke_addr = (unsigned char *)_17mem1_7260;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_17mem1_7260)->dbl);
    }
    *poke_addr = (unsigned char)_3988;
    _3988 = NOVALUE;

    /** 	return peek2u(mem0)*/
    if (IS_ATOM_INT(_17mem0_7259)) {
        _3989 = *(unsigned short *)_17mem0_7259;
    }
    else {
        _3989 = *(unsigned short *)(unsigned long)(DBL_PTR(_17mem0_7259)->dbl);
    }
    return _3989;
    ;
}


int _17seek(int _fn_7370, int _pos_7371)
{
    int _4035 = NOVALUE;
    int _4034 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_7371);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn_7370;
    ((int *)_2)[2] = _pos_7371;
    _4034 = MAKE_SEQ(_1);
    _4035 = machine(19, _4034);
    DeRefDS(_4034);
    _4034 = NOVALUE;
    DeRef(_pos_7371);
    return _4035;
    ;
}


int _17where(int _fn_7376)
{
    int _4036 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_WHERE, fn)*/
    _4036 = machine(20, _fn_7376);
    return _4036;
    ;
}


void _17flush(int _fn_7380)
{
    int _0, _1, _2;
    

    /** 	machine_proc(M_FLUSH, fn)*/
    machine(60, _fn_7380);

    /** end procedure*/
    return;
    ;
}


int _17read_lines(int _file_7395)
{
    int _fn_7396 = NOVALUE;
    int _ret_7397 = NOVALUE;
    int _y_7398 = NOVALUE;
    int _4066 = NOVALUE;
    int _4065 = NOVALUE;
    int _4064 = NOVALUE;
    int _4063 = NOVALUE;
    int _4058 = NOVALUE;
    int _4057 = NOVALUE;
    int _4055 = NOVALUE;
    int _4054 = NOVALUE;
    int _4053 = NOVALUE;
    int _4051 = NOVALUE;
    int _4050 = NOVALUE;
    int _4048 = NOVALUE;
    int _4047 = NOVALUE;
    int _4046 = NOVALUE;
    int _4041 = NOVALUE;
    int _4040 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _4040 = 1;
    if (_4040 == 0)
    {
        _4040 = NOVALUE;
        goto L1; // [6] 37
    }
    else{
        _4040 = NOVALUE;
    }

    /** 		if length(file) = 0 then*/
    if (IS_SEQUENCE(_file_7395)){
            _4041 = SEQ_PTR(_file_7395)->length;
    }
    else {
        _4041 = 1;
    }
    if (_4041 != 0)
    goto L2; // [14] 26

    /** 			fn = 0*/
    DeRef(_fn_7396);
    _fn_7396 = 0;
    goto L3; // [23] 43
L2: 

    /** 			fn = open(file, "r")*/
    DeRef(_fn_7396);
    _fn_7396 = EOpen(_file_7395, _4043, 0);
    goto L3; // [34] 43
L1: 

    /** 		fn = file*/
    Ref(_file_7395);
    DeRef(_fn_7396);
    _fn_7396 = _file_7395;
L3: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_7396, 0)){
        goto L4; // [47] 56
    }
    DeRef(_file_7395);
    DeRef(_fn_7396);
    DeRef(_ret_7397);
    DeRefi(_y_7398);
    return -1;
L4: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_7397);
    _ret_7397 = _5;

    /** 	while sequence(y) with entry do*/
    goto L5; // [63] 162
L6: 
    _4046 = IS_SEQUENCE(_y_7398);
    if (_4046 == 0)
    {
        _4046 = NOVALUE;
        goto L7; // [71] 172
    }
    else{
        _4046 = NOVALUE;
    }

    /** 		if y[$] = '\n' then*/
    if (IS_SEQUENCE(_y_7398)){
            _4047 = SEQ_PTR(_y_7398)->length;
    }
    else {
        _4047 = 1;
    }
    _2 = (int)SEQ_PTR(_y_7398);
    _4048 = (int)*(((s1_ptr)_2)->base + _4047);
    if (_4048 != 10)
    goto L8; // [83] 141

    /** 			y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_7398)){
            _4050 = SEQ_PTR(_y_7398)->length;
    }
    else {
        _4050 = 1;
    }
    _4051 = _4050 - 1;
    _4050 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_7398;
    RHS_Slice(_y_7398, 1, _4051);

    /** 			ifdef UNIX then*/

    /** 				if length(y) then*/
    if (IS_SEQUENCE(_y_7398)){
            _4053 = SEQ_PTR(_y_7398)->length;
    }
    else {
        _4053 = 1;
    }
    if (_4053 == 0)
    {
        _4053 = NOVALUE;
        goto L9; // [108] 140
    }
    else{
        _4053 = NOVALUE;
    }

    /** 					if y[$] = '\r' then*/
    if (IS_SEQUENCE(_y_7398)){
            _4054 = SEQ_PTR(_y_7398)->length;
    }
    else {
        _4054 = 1;
    }
    _2 = (int)SEQ_PTR(_y_7398);
    _4055 = (int)*(((s1_ptr)_2)->base + _4054);
    if (_4055 != 13)
    goto LA; // [120] 139

    /** 						y = y[1..$-1]*/
    if (IS_SEQUENCE(_y_7398)){
            _4057 = SEQ_PTR(_y_7398)->length;
    }
    else {
        _4057 = 1;
    }
    _4058 = _4057 - 1;
    _4057 = NOVALUE;
    rhs_slice_target = (object_ptr)&_y_7398;
    RHS_Slice(_y_7398, 1, _4058);
LA: 
L9: 
L8: 

    /** 		ret = append(ret, y)*/
    Ref(_y_7398);
    Append(&_ret_7397, _ret_7397, _y_7398);

    /** 		if fn = 0 then*/
    if (binary_op_a(NOTEQ, _fn_7396, 0)){
        goto LB; // [149] 159
    }

    /** 			puts(2, '\n')*/
    EPuts(2, 10); // DJP 
LB: 

    /** 	entry*/
L5: 

    /** 		y = gets(fn)*/
    DeRefi(_y_7398);
    _y_7398 = EGets(_fn_7396);

    /** 	end while*/
    goto L6; // [169] 66
L7: 

    /** 	if sequence(file) and length(file) != 0 then*/
    _4063 = IS_SEQUENCE(_file_7395);
    if (_4063 == 0) {
        goto LC; // [177] 197
    }
    if (IS_SEQUENCE(_file_7395)){
            _4065 = SEQ_PTR(_file_7395)->length;
    }
    else {
        _4065 = 1;
    }
    _4066 = (_4065 != 0);
    _4065 = NOVALUE;
    if (_4066 == 0)
    {
        DeRef(_4066);
        _4066 = NOVALUE;
        goto LC; // [189] 197
    }
    else{
        DeRef(_4066);
        _4066 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_7396))
    EClose(_fn_7396);
    else
    EClose((int)DBL_PTR(_fn_7396)->dbl);
LC: 

    /** 	return ret*/
    DeRef(_file_7395);
    DeRef(_fn_7396);
    DeRefi(_y_7398);
    _4048 = NOVALUE;
    DeRef(_4051);
    _4051 = NOVALUE;
    _4055 = NOVALUE;
    DeRef(_4058);
    _4058 = NOVALUE;
    return _ret_7397;
    ;
}


int _17write_lines(int _file_7490, int _lines_7491)
{
    int _fn_7492 = NOVALUE;
    int _4103 = NOVALUE;
    int _4102 = NOVALUE;
    int _4101 = NOVALUE;
    int _4097 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(file) then*/
    _4097 = 1;
    if (_4097 == 0)
    {
        _4097 = NOVALUE;
        goto L1; // [8] 21
    }
    else{
        _4097 = NOVALUE;
    }

    /**     	fn = open(file, "w")*/
    DeRef(_fn_7492);
    _fn_7492 = EOpen(_file_7490, _4098, 0);
    goto L2; // [18] 27
L1: 

    /** 		fn = file*/
    Ref(_file_7490);
    DeRef(_fn_7492);
    _fn_7492 = _file_7490;
L2: 

    /** 	if fn < 0 then return -1 end if*/
    if (binary_op_a(GREATEREQ, _fn_7492, 0)){
        goto L3; // [31] 40
    }
    DeRef(_file_7490);
    DeRefDS(_lines_7491);
    DeRef(_fn_7492);
    return -1;
L3: 

    /** 	for i = 1 to length(lines) do*/
    if (IS_SEQUENCE(_lines_7491)){
            _4101 = SEQ_PTR(_lines_7491)->length;
    }
    else {
        _4101 = 1;
    }
    {
        int _i_7501;
        _i_7501 = 1;
L4: 
        if (_i_7501 > _4101){
            goto L5; // [45] 73
        }

        /** 		puts(fn, lines[i])*/
        _2 = (int)SEQ_PTR(_lines_7491);
        _4102 = (int)*(((s1_ptr)_2)->base + _i_7501);
        EPuts(_fn_7492, _4102); // DJP 
        _4102 = NOVALUE;

        /** 		puts(fn, '\n')*/
        EPuts(_fn_7492, 10); // DJP 

        /** 	end for*/
        _i_7501 = _i_7501 + 1;
        goto L4; // [68] 52
L5: 
        ;
    }

    /** 	if sequence(file) then*/
    _4103 = IS_SEQUENCE(_file_7490);
    if (_4103 == 0)
    {
        _4103 = NOVALUE;
        goto L6; // [78] 86
    }
    else{
        _4103 = NOVALUE;
    }

    /** 		close(fn)*/
    if (IS_ATOM_INT(_fn_7492))
    EClose(_fn_7492);
    else
    EClose((int)DBL_PTR(_fn_7492)->dbl);
L6: 

    /** 	return 1*/
    DeRef(_file_7490);
    DeRefDS(_lines_7491);
    DeRef(_fn_7492);
    return 1;
    ;
}


void _17writef(int _fm_7613, int _data_7614, int _fn_7615, int _data_not_string_7616)
{
    int _real_fn_7617 = NOVALUE;
    int _close_fn_7618 = NOVALUE;
    int _out_style_7619 = NOVALUE;
    int _ts_7622 = NOVALUE;
    int _msg_inlined_crash_at_163_7647 = NOVALUE;
    int _data_inlined_crash_at_160_7646 = NOVALUE;
    int _4170 = NOVALUE;
    int _4168 = NOVALUE;
    int _4167 = NOVALUE;
    int _4166 = NOVALUE;
    int _4160 = NOVALUE;
    int _4159 = NOVALUE;
    int _4158 = NOVALUE;
    int _4157 = NOVALUE;
    int _4156 = NOVALUE;
    int _4155 = NOVALUE;
    int _4153 = NOVALUE;
    int _4152 = NOVALUE;
    int _4151 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer real_fn = 0*/
    _real_fn_7617 = 0;

    /** 	integer close_fn = 0*/
    _close_fn_7618 = 0;

    /** 	sequence out_style = "w"*/
    RefDS(_4098);
    DeRefi(_out_style_7619);
    _out_style_7619 = _4098;

    /** 	if integer(fm) then*/
    _4151 = 1;
    if (_4151 == 0)
    {
        _4151 = NOVALUE;
        goto L1; // [23] 49
    }
    else{
        _4151 = NOVALUE;
    }

    /** 		object ts*/

    /** 		ts = fm*/
    _ts_7622 = _fm_7613;

    /** 		fm = data*/
    RefDS(_data_7614);
    _fm_7613 = _data_7614;

    /** 		data = fn*/
    RefDS(_fn_7615);
    DeRefDS(_data_7614);
    _data_7614 = _fn_7615;

    /** 		fn = ts*/
    DeRefDS(_fn_7615);
    _fn_7615 = _ts_7622;
L1: 

    /** 	if sequence(fn) then*/
    _4152 = IS_SEQUENCE(_fn_7615);
    if (_4152 == 0)
    {
        _4152 = NOVALUE;
        goto L2; // [56] 191
    }
    else{
        _4152 = NOVALUE;
    }

    /** 		if length(fn) = 2 then*/
    if (IS_SEQUENCE(_fn_7615)){
            _4153 = SEQ_PTR(_fn_7615)->length;
    }
    else {
        _4153 = 1;
    }
    if (_4153 != 2)
    goto L3; // [64] 142

    /** 			if sequence(fn[1]) then*/
    _2 = (int)SEQ_PTR(_fn_7615);
    _4155 = (int)*(((s1_ptr)_2)->base + 1);
    _4156 = IS_SEQUENCE(_4155);
    _4155 = NOVALUE;
    if (_4156 == 0)
    {
        _4156 = NOVALUE;
        goto L4; // [77] 141
    }
    else{
        _4156 = NOVALUE;
    }

    /** 				if equal(fn[2], 'a') then*/
    _2 = (int)SEQ_PTR(_fn_7615);
    _4157 = (int)*(((s1_ptr)_2)->base + 2);
    if (_4157 == 97)
    _4158 = 1;
    else if (IS_ATOM_INT(_4157) && IS_ATOM_INT(97))
    _4158 = 0;
    else
    _4158 = (compare(_4157, 97) == 0);
    _4157 = NOVALUE;
    if (_4158 == 0)
    {
        _4158 = NOVALUE;
        goto L5; // [90] 103
    }
    else{
        _4158 = NOVALUE;
    }

    /** 					out_style = "a"*/
    RefDS(_4104);
    DeRefi(_out_style_7619);
    _out_style_7619 = _4104;
    goto L6; // [100] 134
L5: 

    /** 				elsif not equal(fn[2], "a") then*/
    _2 = (int)SEQ_PTR(_fn_7615);
    _4159 = (int)*(((s1_ptr)_2)->base + 2);
    if (_4159 == _4104)
    _4160 = 1;
    else if (IS_ATOM_INT(_4159) && IS_ATOM_INT(_4104))
    _4160 = 0;
    else
    _4160 = (compare(_4159, _4104) == 0);
    _4159 = NOVALUE;
    if (_4160 != 0)
    goto L7; // [113] 126
    _4160 = NOVALUE;

    /** 					out_style = "w"*/
    RefDS(_4098);
    DeRefi(_out_style_7619);
    _out_style_7619 = _4098;
    goto L6; // [123] 134
L7: 

    /** 					out_style = "a"*/
    RefDS(_4104);
    DeRefi(_out_style_7619);
    _out_style_7619 = _4104;
L6: 

    /** 				fn = fn[1]*/
    _0 = _fn_7615;
    _2 = (int)SEQ_PTR(_fn_7615);
    _fn_7615 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_fn_7615);
    DeRef(_0);
L4: 
L3: 

    /** 		real_fn = open(fn, out_style)*/
    _real_fn_7617 = EOpen(_fn_7615, _out_style_7619, 0);

    /** 		if real_fn = -1 then*/
    if (_real_fn_7617 != -1)
    goto L8; // [151] 183

    /** 			error:crash("Unable to write to '%s'", {fn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_fn_7615);
    *((int *)(_2+4)) = _fn_7615;
    _4166 = MAKE_SEQ(_1);
    DeRef(_data_inlined_crash_at_160_7646);
    _data_inlined_crash_at_160_7646 = _4166;
    _4166 = NOVALUE;

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_163_7647);
    _msg_inlined_crash_at_163_7647 = EPrintf(-9999999, _4165, _data_inlined_crash_at_160_7646);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_163_7647);

    /** end procedure*/
    goto L9; // [177] 180
L9: 
    DeRef(_data_inlined_crash_at_160_7646);
    _data_inlined_crash_at_160_7646 = NOVALUE;
    DeRefi(_msg_inlined_crash_at_163_7647);
    _msg_inlined_crash_at_163_7647 = NOVALUE;
L8: 

    /** 		close_fn = 1*/
    _close_fn_7618 = 1;
    goto LA; // [188] 199
L2: 

    /** 		real_fn = fn*/
    Ref(_fn_7615);
    _real_fn_7617 = _fn_7615;
    if (!IS_ATOM_INT(_real_fn_7617)) {
        _1 = (long)(DBL_PTR(_real_fn_7617)->dbl);
        DeRefDS(_real_fn_7617);
        _real_fn_7617 = _1;
    }
LA: 

    /** 	if equal(data_not_string, 0) then*/
    if (_data_not_string_7616 == 0)
    _4167 = 1;
    else if (IS_ATOM_INT(_data_not_string_7616) && IS_ATOM_INT(0))
    _4167 = 0;
    else
    _4167 = (compare(_data_not_string_7616, 0) == 0);
    if (_4167 == 0)
    {
        _4167 = NOVALUE;
        goto LB; // [205] 225
    }
    else{
        _4167 = NOVALUE;
    }

    /** 		if types:t_display(data) then*/
    Ref(_data_7614);
    _4168 = _9t_display(_data_7614);
    if (_4168 == 0) {
        DeRef(_4168);
        _4168 = NOVALUE;
        goto LC; // [214] 224
    }
    else {
        if (!IS_ATOM_INT(_4168) && DBL_PTR(_4168)->dbl == 0.0){
            DeRef(_4168);
            _4168 = NOVALUE;
            goto LC; // [214] 224
        }
        DeRef(_4168);
        _4168 = NOVALUE;
    }
    DeRef(_4168);
    _4168 = NOVALUE;

    /** 			data = {data}*/
    _0 = _data_7614;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_data_7614);
    *((int *)(_2+4)) = _data_7614;
    _data_7614 = MAKE_SEQ(_1);
    DeRef(_0);
LC: 
LB: 

    /**     puts(real_fn, text:format( fm, data ) )*/
    Ref(_fm_7613);
    Ref(_data_7614);
    _4170 = _18format(_fm_7613, _data_7614);
    EPuts(_real_fn_7617, _4170); // DJP 
    DeRef(_4170);
    _4170 = NOVALUE;

    /**     if close_fn then*/
    if (_close_fn_7618 == 0)
    {
        goto LD; // [237] 245
    }
    else{
    }

    /**     	close(real_fn)*/
    EClose(_real_fn_7617);
LD: 

    /** end procedure*/
    DeRef(_fm_7613);
    DeRef(_data_7614);
    DeRef(_fn_7615);
    DeRefi(_out_style_7619);
    return;
    ;
}



// 0x4AECD14F
