// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _6positive_int(int _x_320)
{
    int _58 = NOVALUE;
    int _56 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not integer(x) then*/
    if (IS_ATOM_INT(_x_320))
    _56 = 1;
    else if (IS_ATOM_DBL(_x_320))
    _56 = IS_ATOM_INT(DoubleToInt(_x_320));
    else
    _56 = 0;
    if (_56 != 0)
    goto L1; // [6] 16
    _56 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_320);
    return 0;
L1: 

    /**     return x >= 1*/
    if (IS_ATOM_INT(_x_320)) {
        _58 = (_x_320 >= 1);
    }
    else {
        _58 = binary_op(GREATEREQ, _x_320, 1);
    }
    DeRef(_x_320);
    return _58;
    ;
}


int _6machine_addr(int _a_327)
{
    int _67 = NOVALUE;
    int _66 = NOVALUE;
    int _65 = NOVALUE;
    int _63 = NOVALUE;
    int _61 = NOVALUE;
    int _59 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(a) then*/
    _59 = IS_ATOM(_a_327);
    if (_59 != 0)
    goto L1; // [6] 16
    _59 = NOVALUE;

    /** 		return 0*/
    DeRef(_a_327);
    return 0;
L1: 

    /** 	if not integer(a)then*/
    if (IS_ATOM_INT(_a_327))
    _61 = 1;
    else if (IS_ATOM_DBL(_a_327))
    _61 = IS_ATOM_INT(DoubleToInt(_a_327));
    else
    _61 = 0;
    if (_61 != 0)
    goto L2; // [21] 41
    _61 = NOVALUE;

    /** 		if floor(a) != a then*/
    if (IS_ATOM_INT(_a_327))
    _63 = e_floor(_a_327);
    else
    _63 = unary_op(FLOOR, _a_327);
    if (binary_op_a(EQUALS, _63, _a_327)){
        DeRef(_63);
        _63 = NOVALUE;
        goto L3; // [29] 40
    }
    DeRef(_63);
    _63 = NOVALUE;

    /** 			return 0*/
    DeRef(_a_327);
    return 0;
L3: 
L2: 

    /** 	return a > 0 and a <= MAX_ADDR*/
    if (IS_ATOM_INT(_a_327)) {
        _65 = (_a_327 > 0);
    }
    else {
        _65 = binary_op(GREATER, _a_327, 0);
    }
    if (IS_ATOM_INT(_a_327) && IS_ATOM_INT(_6MAX_ADDR_313)) {
        _66 = (_a_327 <= _6MAX_ADDR_313);
    }
    else {
        _66 = binary_op(LESSEQ, _a_327, _6MAX_ADDR_313);
    }
    if (IS_ATOM_INT(_65) && IS_ATOM_INT(_66)) {
        _67 = (_65 != 0 && _66 != 0);
    }
    else {
        _67 = binary_op(AND, _65, _66);
    }
    DeRef(_65);
    _65 = NOVALUE;
    DeRef(_66);
    _66 = NOVALUE;
    DeRef(_a_327);
    return _67;
    ;
}


void _6deallocate(int _addr_342)
{
    int _0, _1, _2;
    

    /** 	ifdef DATA_EXECUTE and WINDOWS then*/

    /**    	machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_342);

    /** end procedure*/
    DeRef(_addr_342);
    return;
    ;
}


void _6register_block(int _block_addr_349, int _block_len_350, int _protection_351)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_protection_351)) {
        _1 = (long)(DBL_PTR(_protection_351)->dbl);
        DeRefDS(_protection_351);
        _protection_351 = _1;
    }

    /** end procedure*/
    return;
    ;
}


void _6unregister_block(int _block_addr_355)
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _6safe_address(int _start_359, int _len_360, int _action_361)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_len_360)) {
        _1 = (long)(DBL_PTR(_len_360)->dbl);
        DeRefDS(_len_360);
        _len_360 = _1;
    }

    /** 	return 1*/
    return 1;
    ;
}


void _6check_all_blocks()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _6prepare_block(int _addr_368, int _a_369, int _protection_370)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_a_369)) {
        _1 = (long)(DBL_PTR(_a_369)->dbl);
        DeRefDS(_a_369);
        _a_369 = _1;
    }
    if (!IS_ATOM_INT(_protection_370)) {
        _1 = (long)(DBL_PTR(_protection_370)->dbl);
        DeRefDS(_protection_370);
        _protection_370 = _1;
    }

    /** 	return addr*/
    return _addr_368;
    ;
}


int _6bordered_address(int _addr_379)
{
    int _73 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not atom(addr) then*/
    _73 = IS_ATOM(_addr_379);
    if (_73 != 0)
    goto L1; // [6] 16
    _73 = NOVALUE;

    /** 		return 0*/
    DeRef(_addr_379);
    return 0;
L1: 

    /** 	return 1*/
    DeRef(_addr_379);
    return 1;
    ;
}


int _6dep_works()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 	return 1*/
    return 1;
    ;
}


void _6free_code(int _addr_388, int _size_389, int _wordsize_391)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_size_389)) {
        _1 = (long)(DBL_PTR(_size_389)->dbl);
        DeRefDS(_size_389);
        _size_389 = _1;
    }

    /** 		machine_proc( memconst:M_FREE, addr)*/
    machine(17, _addr_388);

    /** end procedure*/
    DeRef(_addr_388);
    return;
    ;
}



// 0x08DB192B
