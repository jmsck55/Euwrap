// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _14find_first_wildcard(int _name_9101, int _from_9102)
{
    int _asterisk_at_9103 = NOVALUE;
    int _question_at_9105 = NOVALUE;
    int _first_wildcard_at_9107 = NOVALUE;
    int _5019 = NOVALUE;
    int _5018 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer asterisk_at = eu:find('*', name, from)*/
    _asterisk_at_9103 = find_from(42, _name_9101, _from_9102);

    /** 	integer question_at = eu:find('?', name, from)*/
    _question_at_9105 = find_from(63, _name_9101, _from_9102);

    /** 	integer first_wildcard_at = asterisk_at*/
    _first_wildcard_at_9107 = _asterisk_at_9103;

    /** 	if asterisk_at or question_at then*/
    if (_asterisk_at_9103 != 0) {
        goto L1; // [26] 35
    }
    if (_question_at_9105 == 0)
    {
        goto L2; // [31] 56
    }
    else{
    }
L1: 

    /** 		if question_at and question_at < asterisk_at then*/
    if (_question_at_9105 == 0) {
        goto L3; // [37] 55
    }
    _5019 = (_question_at_9105 < _asterisk_at_9103);
    if (_5019 == 0)
    {
        DeRef(_5019);
        _5019 = NOVALUE;
        goto L3; // [46] 55
    }
    else{
        DeRef(_5019);
        _5019 = NOVALUE;
    }

    /** 			first_wildcard_at = question_at*/
    _first_wildcard_at_9107 = _question_at_9105;
L3: 
L2: 

    /** 	return first_wildcard_at*/
    DeRefDS(_name_9101);
    return _first_wildcard_at_9107;
    ;
}


int _14dir(int _name_9115)
{
    int _dir_data_9116 = NOVALUE;
    int _data_9117 = NOVALUE;
    int _the_name_9118 = NOVALUE;
    int _the_dir_9119 = NOVALUE;
    int _the_suffix_9120 = NOVALUE;
    int _idx_9121 = NOVALUE;
    int _first_wildcard_at_9122 = NOVALUE;
    int _next_slash_9137 = NOVALUE;
    int _wild_data_9169 = NOVALUE;
    int _interim_dir_9173 = NOVALUE;
    int _dir_results_9177 = NOVALUE;
    int _5062 = NOVALUE;
    int _5061 = NOVALUE;
    int _5060 = NOVALUE;
    int _5058 = NOVALUE;
    int _5057 = NOVALUE;
    int _5056 = NOVALUE;
    int _5054 = NOVALUE;
    int _5052 = NOVALUE;
    int _5051 = NOVALUE;
    int _5050 = NOVALUE;
    int _5049 = NOVALUE;
    int _5047 = NOVALUE;
    int _5045 = NOVALUE;
    int _5044 = NOVALUE;
    int _5043 = NOVALUE;
    int _5042 = NOVALUE;
    int _5041 = NOVALUE;
    int _5040 = NOVALUE;
    int _5037 = NOVALUE;
    int _5036 = NOVALUE;
    int _5034 = NOVALUE;
    int _5032 = NOVALUE;
    int _5031 = NOVALUE;
    int _5024 = NOVALUE;
    int _5022 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	ifdef WINDOWS then*/

    /** 		object dir_data, data, the_name, the_dir, the_suffix = 0*/
    DeRef(_the_suffix_9120);
    _the_suffix_9120 = 0;

    /** 		integer idx*/

    /** 		integer first_wildcard_at = find_first_wildcard( name )*/
    RefDS(_name_9115);
    _first_wildcard_at_9122 = _14find_first_wildcard(_name_9115, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_9122)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_9122)->dbl);
        DeRefDS(_first_wildcard_at_9122);
        _first_wildcard_at_9122 = _1;
    }

    /** 		if first_wildcard_at = 0 then*/
    if (_first_wildcard_at_9122 != 0)
    goto L1; // [23] 38

    /** 			return machine_func(M_DIR, name)*/
    _5022 = machine(22, _name_9115);
    DeRefDS(_name_9115);
    DeRef(_dir_data_9116);
    DeRef(_data_9117);
    DeRef(_the_name_9118);
    DeRef(_the_dir_9119);
    return _5022;
L1: 

    /** 		if first_wildcard_at then*/
    if (_first_wildcard_at_9122 == 0)
    {
        goto L2; // [40] 56
    }
    else{
    }

    /** 			idx = search:rfind(SLASH, name, first_wildcard_at )*/
    RefDS(_name_9115);
    _idx_9121 = _20rfind(47, _name_9115, _first_wildcard_at_9122);
    if (!IS_ATOM_INT(_idx_9121)) {
        _1 = (long)(DBL_PTR(_idx_9121)->dbl);
        DeRefDS(_idx_9121);
        _idx_9121 = _1;
    }
    goto L3; // [53] 70
L2: 

    /** 			idx = search:rfind(SLASH, name )*/
    if (IS_SEQUENCE(_name_9115)){
            _5024 = SEQ_PTR(_name_9115)->length;
    }
    else {
        _5024 = 1;
    }
    RefDS(_name_9115);
    _idx_9121 = _20rfind(47, _name_9115, _5024);
    _5024 = NOVALUE;
    if (!IS_ATOM_INT(_idx_9121)) {
        _1 = (long)(DBL_PTR(_idx_9121)->dbl);
        DeRefDS(_idx_9121);
        _idx_9121 = _1;
    }
L3: 

    /** 		if idx = 0 then*/
    if (_idx_9121 != 0)
    goto L4; // [74] 91

    /** 			the_dir = "."*/
    RefDS(_5027);
    DeRef(_the_dir_9119);
    _the_dir_9119 = _5027;

    /** 			the_name = name*/
    RefDS(_name_9115);
    DeRef(_the_name_9118);
    _the_name_9118 = _name_9115;
    goto L5; // [88] 187
L4: 

    /** 			the_dir = name[1 .. idx]*/
    rhs_slice_target = (object_ptr)&_the_dir_9119;
    RHS_Slice(_name_9115, 1, _idx_9121);

    /** 			integer next_slash = 0*/
    _next_slash_9137 = 0;

    /** 			if first_wildcard_at then*/
    if (_first_wildcard_at_9122 == 0)
    {
        goto L6; // [105] 116
    }
    else{
    }

    /** 				next_slash = eu:find( SLASH, name, first_wildcard_at )*/
    _next_slash_9137 = find_from(47, _name_9115, _first_wildcard_at_9122);
L6: 

    /** 			if next_slash then*/
    if (_next_slash_9137 == 0)
    {
        goto L7; // [118] 164
    }
    else{
    }

    /** 				first_wildcard_at = find_first_wildcard( name, next_slash )*/
    RefDS(_name_9115);
    _first_wildcard_at_9122 = _14find_first_wildcard(_name_9115, _next_slash_9137);
    if (!IS_ATOM_INT(_first_wildcard_at_9122)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_9122)->dbl);
        DeRefDS(_first_wildcard_at_9122);
        _first_wildcard_at_9122 = _1;
    }

    /** 				if first_wildcard_at then*/
    if (_first_wildcard_at_9122 == 0)
    {
        goto L8; // [132] 184
    }
    else{
    }

    /** 					the_name = name[idx+1..next_slash-1]*/
    _5031 = _idx_9121 + 1;
    if (_5031 > MAXINT){
        _5031 = NewDouble((double)_5031);
    }
    _5032 = _next_slash_9137 - 1;
    rhs_slice_target = (object_ptr)&_the_name_9118;
    RHS_Slice(_name_9115, _5031, _5032);

    /** 					the_suffix = name[next_slash..$]*/
    if (IS_SEQUENCE(_name_9115)){
            _5034 = SEQ_PTR(_name_9115)->length;
    }
    else {
        _5034 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_suffix_9120;
    RHS_Slice(_name_9115, _next_slash_9137, _5034);
    goto L8; // [161] 184
L7: 

    /** 				the_name = name[idx+1 .. $]*/
    _5036 = _idx_9121 + 1;
    if (_5036 > MAXINT){
        _5036 = NewDouble((double)_5036);
    }
    if (IS_SEQUENCE(_name_9115)){
            _5037 = SEQ_PTR(_name_9115)->length;
    }
    else {
        _5037 = 1;
    }
    rhs_slice_target = (object_ptr)&_the_name_9118;
    RHS_Slice(_name_9115, _5036, _5037);

    /** 				the_suffix = 0*/
    DeRef(_the_suffix_9120);
    _the_suffix_9120 = 0;
L8: 
L5: 

    /** 		dir_data = dir( the_dir )*/
    Ref(_the_dir_9119);
    _0 = _dir_data_9116;
    _dir_data_9116 = _14dir(_the_dir_9119);
    DeRef(_0);

    /** 		if atom(dir_data) then*/
    _5040 = IS_ATOM(_dir_data_9116);
    if (_5040 == 0)
    {
        _5040 = NOVALUE;
        goto L9; // [200] 210
    }
    else{
        _5040 = NOVALUE;
    }

    /** 			return dir_data*/
    DeRefDS(_name_9115);
    DeRef(_data_9117);
    DeRef(_the_name_9118);
    DeRef(_the_dir_9119);
    DeRef(_the_suffix_9120);
    DeRef(_5022);
    _5022 = NOVALUE;
    DeRef(_5031);
    _5031 = NOVALUE;
    DeRef(_5032);
    _5032 = NOVALUE;
    DeRef(_5036);
    _5036 = NOVALUE;
    return _dir_data_9116;
L9: 

    /** 		data = {}*/
    RefDS(_5);
    DeRef(_data_9117);
    _data_9117 = _5;

    /** 		for i = 1 to length(dir_data) do*/
    if (IS_SEQUENCE(_dir_data_9116)){
            _5041 = SEQ_PTR(_dir_data_9116)->length;
    }
    else {
        _5041 = 1;
    }
    {
        int _i_9156;
        _i_9156 = 1;
LA: 
        if (_i_9156 > _5041){
            goto LB; // [220] 265
        }

        /** 			if wildcard:is_match(the_name, dir_data[i][1]) then*/
        _2 = (int)SEQ_PTR(_dir_data_9116);
        _5042 = (int)*(((s1_ptr)_2)->base + _i_9156);
        _2 = (int)SEQ_PTR(_5042);
        _5043 = (int)*(((s1_ptr)_2)->base + 1);
        _5042 = NOVALUE;
        Ref(_the_name_9118);
        Ref(_5043);
        _5044 = _11is_match(_the_name_9118, _5043);
        _5043 = NOVALUE;
        if (_5044 == 0) {
            DeRef(_5044);
            _5044 = NOVALUE;
            goto LC; // [244] 258
        }
        else {
            if (!IS_ATOM_INT(_5044) && DBL_PTR(_5044)->dbl == 0.0){
                DeRef(_5044);
                _5044 = NOVALUE;
                goto LC; // [244] 258
            }
            DeRef(_5044);
            _5044 = NOVALUE;
        }
        DeRef(_5044);
        _5044 = NOVALUE;

        /** 					data = append(data, dir_data[i])*/
        _2 = (int)SEQ_PTR(_dir_data_9116);
        _5045 = (int)*(((s1_ptr)_2)->base + _i_9156);
        Ref(_5045);
        Append(&_data_9117, _data_9117, _5045);
        _5045 = NOVALUE;
LC: 

        /** 		end for*/
        _i_9156 = _i_9156 + 1;
        goto LA; // [260] 227
LB: 
        ;
    }

    /** 		if not length(data) then*/
    if (IS_SEQUENCE(_data_9117)){
            _5047 = SEQ_PTR(_data_9117)->length;
    }
    else {
        _5047 = 1;
    }
    if (_5047 != 0)
    goto LD; // [270] 280
    _5047 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_name_9115);
    DeRef(_dir_data_9116);
    DeRef(_data_9117);
    DeRef(_the_name_9118);
    DeRef(_the_dir_9119);
    DeRef(_the_suffix_9120);
    DeRef(_5022);
    _5022 = NOVALUE;
    DeRef(_5031);
    _5031 = NOVALUE;
    DeRef(_5032);
    _5032 = NOVALUE;
    DeRef(_5036);
    _5036 = NOVALUE;
    return -1;
LD: 

    /** 		if sequence( the_suffix ) then*/
    _5049 = IS_SEQUENCE(_the_suffix_9120);
    if (_5049 == 0)
    {
        _5049 = NOVALUE;
        goto LE; // [285] 406
    }
    else{
        _5049 = NOVALUE;
    }

    /** 			sequence wild_data = {}*/
    RefDS(_5);
    DeRef(_wild_data_9169);
    _wild_data_9169 = _5;

    /** 			for i = 1 to length( dir_data ) do*/
    if (IS_SEQUENCE(_dir_data_9116)){
            _5050 = SEQ_PTR(_dir_data_9116)->length;
    }
    else {
        _5050 = 1;
    }
    {
        int _i_9171;
        _i_9171 = 1;
LF: 
        if (_i_9171 > _5050){
            goto L10; // [300] 399
        }

        /** 				sequence interim_dir = the_dir & dir_data[i][D_NAME] & SLASH*/
        _2 = (int)SEQ_PTR(_dir_data_9116);
        _5051 = (int)*(((s1_ptr)_2)->base + _i_9171);
        _2 = (int)SEQ_PTR(_5051);
        _5052 = (int)*(((s1_ptr)_2)->base + 1);
        _5051 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = 47;
            concat_list[1] = _5052;
            concat_list[2] = _the_dir_9119;
            Concat_N((object_ptr)&_interim_dir_9173, concat_list, 3);
        }
        _5052 = NOVALUE;

        /** 				object dir_results = dir( interim_dir & the_suffix )*/
        if (IS_SEQUENCE(_interim_dir_9173) && IS_ATOM(_the_suffix_9120)) {
            Ref(_the_suffix_9120);
            Append(&_5054, _interim_dir_9173, _the_suffix_9120);
        }
        else if (IS_ATOM(_interim_dir_9173) && IS_SEQUENCE(_the_suffix_9120)) {
        }
        else {
            Concat((object_ptr)&_5054, _interim_dir_9173, _the_suffix_9120);
        }
        _0 = _dir_results_9177;
        _dir_results_9177 = _14dir(_5054);
        DeRef(_0);
        _5054 = NOVALUE;

        /** 				if sequence( dir_results ) then*/
        _5056 = IS_SEQUENCE(_dir_results_9177);
        if (_5056 == 0)
        {
            _5056 = NOVALUE;
            goto L11; // [338] 390
        }
        else{
            _5056 = NOVALUE;
        }

        /** 					for j = 1 to length( dir_results ) do*/
        if (IS_SEQUENCE(_dir_results_9177)){
                _5057 = SEQ_PTR(_dir_results_9177)->length;
        }
        else {
            _5057 = 1;
        }
        {
            int _j_9183;
            _j_9183 = 1;
L12: 
            if (_j_9183 > _5057){
                goto L13; // [346] 383
            }

            /** 						dir_results[j][D_NAME] = interim_dir & dir_results[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_dir_results_9177);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _dir_results_9177 = MAKE_SEQ(_2);
            }
            _3 = (int)(_j_9183 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_dir_results_9177);
            _5060 = (int)*(((s1_ptr)_2)->base + _j_9183);
            _2 = (int)SEQ_PTR(_5060);
            _5061 = (int)*(((s1_ptr)_2)->base + 1);
            _5060 = NOVALUE;
            if (IS_SEQUENCE(_interim_dir_9173) && IS_ATOM(_5061)) {
                Ref(_5061);
                Append(&_5062, _interim_dir_9173, _5061);
            }
            else if (IS_ATOM(_interim_dir_9173) && IS_SEQUENCE(_5061)) {
            }
            else {
                Concat((object_ptr)&_5062, _interim_dir_9173, _5061);
            }
            _5061 = NOVALUE;
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _5062;
            if( _1 != _5062 ){
                DeRef(_1);
            }
            _5062 = NOVALUE;
            _5058 = NOVALUE;

            /** 					end for*/
            _j_9183 = _j_9183 + 1;
            goto L12; // [378] 353
L13: 
            ;
        }

        /** 					wild_data &= dir_results*/
        if (IS_SEQUENCE(_wild_data_9169) && IS_ATOM(_dir_results_9177)) {
            Ref(_dir_results_9177);
            Append(&_wild_data_9169, _wild_data_9169, _dir_results_9177);
        }
        else if (IS_ATOM(_wild_data_9169) && IS_SEQUENCE(_dir_results_9177)) {
        }
        else {
            Concat((object_ptr)&_wild_data_9169, _wild_data_9169, _dir_results_9177);
        }
L11: 
        DeRef(_interim_dir_9173);
        _interim_dir_9173 = NOVALUE;
        DeRef(_dir_results_9177);
        _dir_results_9177 = NOVALUE;

        /** 			end for*/
        _i_9171 = _i_9171 + 1;
        goto LF; // [394] 307
L10: 
        ;
    }

    /** 			return wild_data*/
    DeRefDS(_name_9115);
    DeRef(_dir_data_9116);
    DeRef(_data_9117);
    DeRef(_the_name_9118);
    DeRef(_the_dir_9119);
    DeRef(_the_suffix_9120);
    DeRef(_5022);
    _5022 = NOVALUE;
    DeRef(_5031);
    _5031 = NOVALUE;
    DeRef(_5032);
    _5032 = NOVALUE;
    DeRef(_5036);
    _5036 = NOVALUE;
    return _wild_data_9169;
LE: 
    DeRef(_wild_data_9169);
    _wild_data_9169 = NOVALUE;

    /** 		return data*/
    DeRefDS(_name_9115);
    DeRef(_dir_data_9116);
    DeRef(_the_name_9118);
    DeRef(_the_dir_9119);
    DeRef(_the_suffix_9120);
    DeRef(_5022);
    _5022 = NOVALUE;
    DeRef(_5031);
    _5031 = NOVALUE;
    DeRef(_5032);
    _5032 = NOVALUE;
    DeRef(_5036);
    _5036 = NOVALUE;
    return _data_9117;
    ;
}


int _14current_dir()
{
    int _5064 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    _5064 = machine(23, 0);
    return _5064;
    ;
}


int _14chdir(int _newdir_9196)
{
    int _5065 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CHDIR, newdir)*/
    _5065 = machine(63, _newdir_9196);
    DeRefDS(_newdir_9196);
    return _5065;
    ;
}


int _14delete_file(int _name_9325)
{
    int _pfilename_9326 = NOVALUE;
    int _success_9328 = NOVALUE;
    int _5139 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom pfilename = machine:allocate_string(name)*/
    RefDS(_name_9325);
    _0 = _pfilename_9326;
    _pfilename_9326 = _4allocate_string(_name_9325, 0);
    DeRef(_0);

    /** 	integer success = c_func(xDeleteFile, {pfilename})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_pfilename_9326);
    *((int *)(_2+4)) = _pfilename_9326;
    _5139 = MAKE_SEQ(_1);
    _success_9328 = call_c(1, _14xDeleteFile_9050, _5139);
    DeRefDS(_5139);
    _5139 = NOVALUE;
    if (!IS_ATOM_INT(_success_9328)) {
        _1 = (long)(DBL_PTR(_success_9328)->dbl);
        DeRefDS(_success_9328);
        _success_9328 = _1;
    }

    /** 	ifdef UNIX then*/

    /** 		success = not success*/
    _success_9328 = (_success_9328 == 0);

    /** 	machine:free(pfilename)*/
    Ref(_pfilename_9326);
    _4free(_pfilename_9326);

    /** 	return success*/
    DeRefDS(_name_9325);
    DeRef(_pfilename_9326);
    return _success_9328;
    ;
}


int _14curdir(int _drive_id_9334)
{
    int _lCurDir_9335 = NOVALUE;
    int _current_dir_inlined_current_dir_at_6_9337 = NOVALUE;
    int _5143 = NOVALUE;
    int _5142 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef not LINUX then*/

    /**     lCurDir = current_dir()*/

    /** 	return machine_func(M_CURRENT_DIR, 0)*/
    DeRefi(_lCurDir_9335);
    _lCurDir_9335 = machine(23, 0);

    /** 	ifdef not LINUX then*/

    /** 	if (lCurDir[$] != SLASH) then*/
    if (IS_SEQUENCE(_lCurDir_9335)){
            _5142 = SEQ_PTR(_lCurDir_9335)->length;
    }
    else {
        _5142 = 1;
    }
    _2 = (int)SEQ_PTR(_lCurDir_9335);
    _5143 = (int)*(((s1_ptr)_2)->base + _5142);
    if (_5143 == 47)
    goto L1; // [27] 38

    /** 		lCurDir &= SLASH*/
    Append(&_lCurDir_9335, _lCurDir_9335, 47);
L1: 

    /** 	return lCurDir*/
    _5143 = NOVALUE;
    return _lCurDir_9335;
    ;
}


int _14pathinfo(int _path_9468, int _std_slash_9469)
{
    int _slash_9470 = NOVALUE;
    int _period_9471 = NOVALUE;
    int _ch_9472 = NOVALUE;
    int _dir_name_9473 = NOVALUE;
    int _file_name_9474 = NOVALUE;
    int _file_ext_9475 = NOVALUE;
    int _file_full_9476 = NOVALUE;
    int _drive_id_9477 = NOVALUE;
    int _from_slash_9509 = NOVALUE;
    int _5245 = NOVALUE;
    int _5238 = NOVALUE;
    int _5237 = NOVALUE;
    int _5234 = NOVALUE;
    int _5233 = NOVALUE;
    int _5231 = NOVALUE;
    int _5230 = NOVALUE;
    int _5227 = NOVALUE;
    int _5225 = NOVALUE;
    int _5224 = NOVALUE;
    int _5223 = NOVALUE;
    int _5222 = NOVALUE;
    int _5220 = NOVALUE;
    int _0, _1, _2;
    

    /** 	dir_name  = ""*/
    RefDS(_5);
    DeRef(_dir_name_9473);
    _dir_name_9473 = _5;

    /** 	file_name = ""*/
    RefDS(_5);
    DeRef(_file_name_9474);
    _file_name_9474 = _5;

    /** 	file_ext  = ""*/
    RefDS(_5);
    DeRef(_file_ext_9475);
    _file_ext_9475 = _5;

    /** 	file_full = ""*/
    RefDS(_5);
    DeRef(_file_full_9476);
    _file_full_9476 = _5;

    /** 	drive_id  = ""*/
    RefDS(_5);
    DeRef(_drive_id_9477);
    _drive_id_9477 = _5;

    /** 	slash = 0*/
    _slash_9470 = 0;

    /** 	period = 0*/
    _period_9471 = 0;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_9468)){
            _5220 = SEQ_PTR(_path_9468)->length;
    }
    else {
        _5220 = 1;
    }
    {
        int _i_9479;
        _i_9479 = _5220;
L1: 
        if (_i_9479 < 1){
            goto L2; // [55] 122
        }

        /** 		ch = path[i]*/
        _2 = (int)SEQ_PTR(_path_9468);
        _ch_9472 = (int)*(((s1_ptr)_2)->base + _i_9479);
        if (!IS_ATOM_INT(_ch_9472))
        _ch_9472 = (long)DBL_PTR(_ch_9472)->dbl;

        /** 		if period = 0 and ch = '.' then*/
        _5222 = (_period_9471 == 0);
        if (_5222 == 0) {
            goto L3; // [74] 94
        }
        _5224 = (_ch_9472 == 46);
        if (_5224 == 0)
        {
            DeRef(_5224);
            _5224 = NOVALUE;
            goto L3; // [83] 94
        }
        else{
            DeRef(_5224);
            _5224 = NOVALUE;
        }

        /** 			period = i*/
        _period_9471 = _i_9479;
        goto L4; // [91] 115
L3: 

        /** 		elsif eu:find(ch, SLASHES) then*/
        _5225 = find_from(_ch_9472, _14SLASHES_9074, 1);
        if (_5225 == 0)
        {
            _5225 = NOVALUE;
            goto L5; // [101] 114
        }
        else{
            _5225 = NOVALUE;
        }

        /** 			slash = i*/
        _slash_9470 = _i_9479;

        /** 			exit*/
        goto L2; // [111] 122
L5: 
L4: 

        /** 	end for*/
        _i_9479 = _i_9479 + -1;
        goto L1; // [117] 62
L2: 
        ;
    }

    /** 	if slash > 0 then*/
    if (_slash_9470 <= 0)
    goto L6; // [124] 142

    /** 		dir_name = path[1..slash-1]*/
    _5227 = _slash_9470 - 1;
    rhs_slice_target = (object_ptr)&_dir_name_9473;
    RHS_Slice(_path_9468, 1, _5227);

    /** 		ifdef not UNIX then*/
L6: 

    /** 	if period > 0 then*/
    if (_period_9471 <= 0)
    goto L7; // [144] 188

    /** 		file_name = path[slash+1..period-1]*/
    _5230 = _slash_9470 + 1;
    if (_5230 > MAXINT){
        _5230 = NewDouble((double)_5230);
    }
    _5231 = _period_9471 - 1;
    rhs_slice_target = (object_ptr)&_file_name_9474;
    RHS_Slice(_path_9468, _5230, _5231);

    /** 		file_ext = path[period+1..$]*/
    _5233 = _period_9471 + 1;
    if (_5233 > MAXINT){
        _5233 = NewDouble((double)_5233);
    }
    if (IS_SEQUENCE(_path_9468)){
            _5234 = SEQ_PTR(_path_9468)->length;
    }
    else {
        _5234 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_ext_9475;
    RHS_Slice(_path_9468, _5233, _5234);

    /** 		file_full = file_name & '.' & file_ext*/
    {
        int concat_list[3];

        concat_list[0] = _file_ext_9475;
        concat_list[1] = 46;
        concat_list[2] = _file_name_9474;
        Concat_N((object_ptr)&_file_full_9476, concat_list, 3);
    }
    goto L8; // [185] 210
L7: 

    /** 		file_name = path[slash+1..$]*/
    _5237 = _slash_9470 + 1;
    if (_5237 > MAXINT){
        _5237 = NewDouble((double)_5237);
    }
    if (IS_SEQUENCE(_path_9468)){
            _5238 = SEQ_PTR(_path_9468)->length;
    }
    else {
        _5238 = 1;
    }
    rhs_slice_target = (object_ptr)&_file_name_9474;
    RHS_Slice(_path_9468, _5237, _5238);

    /** 		file_full = file_name*/
    RefDS(_file_name_9474);
    DeRef(_file_full_9476);
    _file_full_9476 = _file_name_9474;
L8: 

    /** 	if std_slash != 0 then*/
    if (_std_slash_9469 == 0)
    goto L9; // [212] 278

    /** 		if std_slash < 0 then*/
    if (_std_slash_9469 >= 0)
    goto LA; // [218] 254

    /** 			std_slash = SLASH*/
    _std_slash_9469 = 47;

    /** 			ifdef UNIX then*/

    /** 			sequence from_slash = "\\"*/
    RefDS(_1110);
    DeRefi(_from_slash_9509);
    _from_slash_9509 = _1110;

    /** 			dir_name = search:match_replace(from_slash, dir_name, std_slash)*/
    RefDS(_from_slash_9509);
    RefDS(_dir_name_9473);
    _0 = _dir_name_9473;
    _dir_name_9473 = _20match_replace(_from_slash_9509, _dir_name_9473, 47, 0);
    DeRefDS(_0);
    DeRefDSi(_from_slash_9509);
    _from_slash_9509 = NOVALUE;
    goto LB; // [251] 277
LA: 

    /** 			dir_name = search:match_replace("\\", dir_name, std_slash)*/
    RefDS(_1110);
    RefDS(_dir_name_9473);
    _0 = _dir_name_9473;
    _dir_name_9473 = _20match_replace(_1110, _dir_name_9473, _std_slash_9469, 0);
    DeRefDS(_0);

    /** 			dir_name = search:match_replace("/", dir_name, std_slash)*/
    RefDS(_5008);
    RefDS(_dir_name_9473);
    _0 = _dir_name_9473;
    _dir_name_9473 = _20match_replace(_5008, _dir_name_9473, _std_slash_9469, 0);
    DeRefDS(_0);
LB: 
L9: 

    /** 	return {dir_name, file_full, file_name, file_ext, drive_id}*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_dir_name_9473);
    *((int *)(_2+4)) = _dir_name_9473;
    RefDS(_file_full_9476);
    *((int *)(_2+8)) = _file_full_9476;
    RefDS(_file_name_9474);
    *((int *)(_2+12)) = _file_name_9474;
    RefDS(_file_ext_9475);
    *((int *)(_2+16)) = _file_ext_9475;
    RefDS(_drive_id_9477);
    *((int *)(_2+20)) = _drive_id_9477;
    _5245 = MAKE_SEQ(_1);
    DeRefDS(_path_9468);
    DeRefDS(_dir_name_9473);
    DeRefDS(_file_name_9474);
    DeRefDS(_file_ext_9475);
    DeRefDS(_file_full_9476);
    DeRefDS(_drive_id_9477);
    DeRef(_5222);
    _5222 = NOVALUE;
    DeRef(_5227);
    _5227 = NOVALUE;
    DeRef(_5230);
    _5230 = NOVALUE;
    DeRef(_5231);
    _5231 = NOVALUE;
    DeRef(_5233);
    _5233 = NOVALUE;
    DeRef(_5237);
    _5237 = NOVALUE;
    return _5245;
    ;
}


int _14dirname(int _path_9517, int _pcd_9518)
{
    int _data_9519 = NOVALUE;
    int _5250 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_9517);
    _0 = _data_9519;
    _data_9519 = _14pathinfo(_path_9517, 0);
    DeRef(_0);

    /** 	if pcd then*/

    /** 	return data[1]*/
    _2 = (int)SEQ_PTR(_data_9519);
    _5250 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5250);
    DeRefDS(_path_9517);
    DeRefDS(_data_9519);
    return _5250;
    ;
}


int _14filebase(int _path_9546)
{
    int _data_9547 = NOVALUE;
    int _5259 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_9546);
    _0 = _data_9547;
    _data_9547 = _14pathinfo(_path_9546, 0);
    DeRef(_0);

    /** 	return data[3]*/
    _2 = (int)SEQ_PTR(_data_9547);
    _5259 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_5259);
    DeRefDS(_path_9546);
    DeRefDS(_data_9547);
    return _5259;
    ;
}


int _14fileext(int _path_9552)
{
    int _data_9553 = NOVALUE;
    int _5261 = NOVALUE;
    int _0, _1, _2;
    

    /** 	data = pathinfo(path)*/
    RefDS(_path_9552);
    _0 = _data_9553;
    _data_9553 = _14pathinfo(_path_9552, 0);
    DeRef(_0);

    /** 	return data[4]*/
    _2 = (int)SEQ_PTR(_data_9553);
    _5261 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_5261);
    DeRefDS(_path_9552);
    DeRefDS(_data_9553);
    return _5261;
    ;
}


int _14defaultext(int _path_9564, int _defext_9565)
{
    int _5276 = NOVALUE;
    int _5273 = NOVALUE;
    int _5271 = NOVALUE;
    int _5270 = NOVALUE;
    int _5269 = NOVALUE;
    int _5267 = NOVALUE;
    int _5266 = NOVALUE;
    int _5264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(defext) = 0 then*/
    _5264 = 3;

    /** 	for i = length(path) to 1 by -1 do*/
    if (IS_SEQUENCE(_path_9564)){
            _5266 = SEQ_PTR(_path_9564)->length;
    }
    else {
        _5266 = 1;
    }
    {
        int _i_9570;
        _i_9570 = _5266;
L1: 
        if (_i_9570 < 1){
            goto L2; // [26] 95
        }

        /** 		if path[i] = '.' then*/
        _2 = (int)SEQ_PTR(_path_9564);
        _5267 = (int)*(((s1_ptr)_2)->base + _i_9570);
        if (binary_op_a(NOTEQ, _5267, 46)){
            _5267 = NOVALUE;
            goto L3; // [39] 50
        }
        _5267 = NOVALUE;

        /** 			return path*/
        DeRefDSi(_defext_9565);
        return _path_9564;
L3: 

        /** 		if find(path[i], SLASHES) then*/
        _2 = (int)SEQ_PTR(_path_9564);
        _5269 = (int)*(((s1_ptr)_2)->base + _i_9570);
        _5270 = find_from(_5269, _14SLASHES_9074, 1);
        _5269 = NOVALUE;
        if (_5270 == 0)
        {
            _5270 = NOVALUE;
            goto L4; // [61] 88
        }
        else{
            _5270 = NOVALUE;
        }

        /** 			if i = length(path) then*/
        if (IS_SEQUENCE(_path_9564)){
                _5271 = SEQ_PTR(_path_9564)->length;
        }
        else {
            _5271 = 1;
        }
        if (_i_9570 != _5271)
        goto L2; // [69] 95

        /** 				return path*/
        DeRefDSi(_defext_9565);
        return _path_9564;
        goto L5; // [79] 87

        /** 				exit*/
        goto L2; // [84] 95
L5: 
L4: 

        /** 	end for*/
        _i_9570 = _i_9570 + -1;
        goto L1; // [90] 33
L2: 
        ;
    }

    /** 	if defext[1] != '.' then*/
    _2 = (int)SEQ_PTR(_defext_9565);
    _5273 = (int)*(((s1_ptr)_2)->base + 1);
    if (_5273 == 46)
    goto L6; // [101] 112

    /** 		path &= '.'*/
    Append(&_path_9564, _path_9564, 46);
L6: 

    /** 	return path & defext*/
    Concat((object_ptr)&_5276, _path_9564, _defext_9565);
    DeRefDS(_path_9564);
    DeRefDSi(_defext_9565);
    _5273 = NOVALUE;
    return _5276;
    ;
}


int _14absolute_path(int _filename_9589)
{
    int _5280 = NOVALUE;
    int _5279 = NOVALUE;
    int _5277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(filename) = 0 then*/
    if (IS_SEQUENCE(_filename_9589)){
            _5277 = SEQ_PTR(_filename_9589)->length;
    }
    else {
        _5277 = 1;
    }
    if (_5277 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDS(_filename_9589);
    return 0;
L1: 

    /** 	if eu:find(filename[1], SLASHES) then*/
    _2 = (int)SEQ_PTR(_filename_9589);
    _5279 = (int)*(((s1_ptr)_2)->base + 1);
    _5280 = find_from(_5279, _14SLASHES_9074, 1);
    _5279 = NOVALUE;
    if (_5280 == 0)
    {
        _5280 = NOVALUE;
        goto L2; // [30] 40
    }
    else{
        _5280 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_filename_9589);
    return 1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	return 0*/
    DeRefDS(_filename_9589);
    return 0;
    ;
}


int _14canonical_path(int _path_in_9609, int _directory_given_9610, int _case_flags_9611)
{
    int _lPath_9612 = NOVALUE;
    int _lPosA_9613 = NOVALUE;
    int _lPosB_9614 = NOVALUE;
    int _lLevel_9615 = NOVALUE;
    int _lHome_9616 = NOVALUE;
    int _wildcard_suffix_9658 = NOVALUE;
    int _first_wildcard_at_9659 = NOVALUE;
    int _last_slash_9662 = NOVALUE;
    int _sl_9715 = NOVALUE;
    int _short_name_9718 = NOVALUE;
    int _correct_name_9721 = NOVALUE;
    int _lower_name_9724 = NOVALUE;
    int _part_9740 = NOVALUE;
    int _list_9744 = NOVALUE;
    int _supplied_name_9747 = NOVALUE;
    int _read_name_9766 = NOVALUE;
    int _read_name_9791 = NOVALUE;
    int _5460 = NOVALUE;
    int _5458 = NOVALUE;
    int _5457 = NOVALUE;
    int _5456 = NOVALUE;
    int _5455 = NOVALUE;
    int _5454 = NOVALUE;
    int _5452 = NOVALUE;
    int _5451 = NOVALUE;
    int _5450 = NOVALUE;
    int _5449 = NOVALUE;
    int _5448 = NOVALUE;
    int _5447 = NOVALUE;
    int _5446 = NOVALUE;
    int _5445 = NOVALUE;
    int _5443 = NOVALUE;
    int _5442 = NOVALUE;
    int _5441 = NOVALUE;
    int _5440 = NOVALUE;
    int _5439 = NOVALUE;
    int _5438 = NOVALUE;
    int _5437 = NOVALUE;
    int _5436 = NOVALUE;
    int _5435 = NOVALUE;
    int _5433 = NOVALUE;
    int _5432 = NOVALUE;
    int _5431 = NOVALUE;
    int _5430 = NOVALUE;
    int _5429 = NOVALUE;
    int _5428 = NOVALUE;
    int _5427 = NOVALUE;
    int _5426 = NOVALUE;
    int _5425 = NOVALUE;
    int _5424 = NOVALUE;
    int _5423 = NOVALUE;
    int _5422 = NOVALUE;
    int _5421 = NOVALUE;
    int _5420 = NOVALUE;
    int _5419 = NOVALUE;
    int _5417 = NOVALUE;
    int _5416 = NOVALUE;
    int _5415 = NOVALUE;
    int _5414 = NOVALUE;
    int _5413 = NOVALUE;
    int _5411 = NOVALUE;
    int _5410 = NOVALUE;
    int _5409 = NOVALUE;
    int _5408 = NOVALUE;
    int _5407 = NOVALUE;
    int _5406 = NOVALUE;
    int _5405 = NOVALUE;
    int _5404 = NOVALUE;
    int _5403 = NOVALUE;
    int _5402 = NOVALUE;
    int _5401 = NOVALUE;
    int _5400 = NOVALUE;
    int _5399 = NOVALUE;
    int _5397 = NOVALUE;
    int _5396 = NOVALUE;
    int _5394 = NOVALUE;
    int _5393 = NOVALUE;
    int _5392 = NOVALUE;
    int _5391 = NOVALUE;
    int _5390 = NOVALUE;
    int _5388 = NOVALUE;
    int _5387 = NOVALUE;
    int _5386 = NOVALUE;
    int _5385 = NOVALUE;
    int _5384 = NOVALUE;
    int _5382 = NOVALUE;
    int _5380 = NOVALUE;
    int _5379 = NOVALUE;
    int _5377 = NOVALUE;
    int _5376 = NOVALUE;
    int _5374 = NOVALUE;
    int _5373 = NOVALUE;
    int _5372 = NOVALUE;
    int _5370 = NOVALUE;
    int _5369 = NOVALUE;
    int _5367 = NOVALUE;
    int _5365 = NOVALUE;
    int _5363 = NOVALUE;
    int _5356 = NOVALUE;
    int _5353 = NOVALUE;
    int _5352 = NOVALUE;
    int _5351 = NOVALUE;
    int _5350 = NOVALUE;
    int _5344 = NOVALUE;
    int _5340 = NOVALUE;
    int _5339 = NOVALUE;
    int _5338 = NOVALUE;
    int _5337 = NOVALUE;
    int _5336 = NOVALUE;
    int _5334 = NOVALUE;
    int _5333 = NOVALUE;
    int _5332 = NOVALUE;
    int _5330 = NOVALUE;
    int _5329 = NOVALUE;
    int _5328 = NOVALUE;
    int _5327 = NOVALUE;
    int _5325 = NOVALUE;
    int _5323 = NOVALUE;
    int _5319 = NOVALUE;
    int _5318 = NOVALUE;
    int _5316 = NOVALUE;
    int _5315 = NOVALUE;
    int _5314 = NOVALUE;
    int _5313 = NOVALUE;
    int _5312 = NOVALUE;
    int _5311 = NOVALUE;
    int _5310 = NOVALUE;
    int _5307 = NOVALUE;
    int _5306 = NOVALUE;
    int _5301 = NOVALUE;
    int _5300 = NOVALUE;
    int _5299 = NOVALUE;
    int _5298 = NOVALUE;
    int _5297 = NOVALUE;
    int _5295 = NOVALUE;
    int _5294 = NOVALUE;
    int _5293 = NOVALUE;
    int _5292 = NOVALUE;
    int _5291 = NOVALUE;
    int _5290 = NOVALUE;
    int _5289 = NOVALUE;
    int _5288 = NOVALUE;
    int _5287 = NOVALUE;
    int _5286 = NOVALUE;
    int _5285 = NOVALUE;
    int _0, _1, _2;
    

    /**     sequence lPath = ""*/
    RefDS(_5);
    DeRef(_lPath_9612);
    _lPath_9612 = _5;

    /**     integer lPosA = -1*/
    _lPosA_9613 = -1;

    /**     integer lPosB = -1*/
    _lPosB_9614 = -1;

    /**     sequence lLevel = ""*/
    RefDS(_5);
    DeRefi(_lLevel_9615);
    _lLevel_9615 = _5;

    /**     path_in = path_in*/
    RefDS(_path_in_9609);
    DeRefDS(_path_in_9609);
    _path_in_9609 = _path_in_9609;

    /** 	ifdef UNIX then*/

    /** 		lPath = path_in*/
    RefDS(_path_in_9609);
    DeRefDS(_lPath_9612);
    _lPath_9612 = _path_in_9609;

    /**     if (length(lPath) > 2 and lPath[1] = '"' and lPath[$] = '"') then*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5285 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5285 = 1;
    }
    _5286 = (_5285 > 2);
    _5285 = NOVALUE;
    if (_5286 == 0) {
        _5287 = 0;
        goto L1; // [56] 72
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5288 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5288)) {
        _5289 = (_5288 == 34);
    }
    else {
        _5289 = binary_op(EQUALS, _5288, 34);
    }
    _5288 = NOVALUE;
    if (IS_ATOM_INT(_5289))
    _5287 = (_5289 != 0);
    else
    _5287 = DBL_PTR(_5289)->dbl != 0.0;
L1: 
    if (_5287 == 0) {
        DeRef(_5290);
        _5290 = 0;
        goto L2; // [72] 91
    }
    if (IS_SEQUENCE(_lPath_9612)){
            _5291 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5291 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5292 = (int)*(((s1_ptr)_2)->base + _5291);
    if (IS_ATOM_INT(_5292)) {
        _5293 = (_5292 == 34);
    }
    else {
        _5293 = binary_op(EQUALS, _5292, 34);
    }
    _5292 = NOVALUE;
    if (IS_ATOM_INT(_5293))
    _5290 = (_5293 != 0);
    else
    _5290 = DBL_PTR(_5293)->dbl != 0.0;
L2: 
    if (_5290 == 0)
    {
        _5290 = NOVALUE;
        goto L3; // [91] 109
    }
    else{
        _5290 = NOVALUE;
    }

    /**         lPath = lPath[2..$-1]*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5294 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5294 = 1;
    }
    _5295 = _5294 - 1;
    _5294 = NOVALUE;
    rhs_slice_target = (object_ptr)&_lPath_9612;
    RHS_Slice(_lPath_9612, 2, _5295);
L3: 

    /**     if (length(lPath) > 0 and lPath[1] = '~') then*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5297 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5297 = 1;
    }
    _5298 = (_5297 > 0);
    _5297 = NOVALUE;
    if (_5298 == 0) {
        DeRef(_5299);
        _5299 = 0;
        goto L4; // [118] 134
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5300 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5300)) {
        _5301 = (_5300 == 126);
    }
    else {
        _5301 = binary_op(EQUALS, _5300, 126);
    }
    _5300 = NOVALUE;
    if (IS_ATOM_INT(_5301))
    _5299 = (_5301 != 0);
    else
    _5299 = DBL_PTR(_5301)->dbl != 0.0;
L4: 
    if (_5299 == 0)
    {
        _5299 = NOVALUE;
        goto L5; // [134] 222
    }
    else{
        _5299 = NOVALUE;
    }

    /** 		lHome = getenv("HOME")*/
    DeRefi(_lHome_9616);
    _lHome_9616 = EGetEnv(_5302);

    /** 		ifdef WINDOWS then*/

    /** 		if lHome[$] != SLASH then*/
    if (IS_SEQUENCE(_lHome_9616)){
            _5306 = SEQ_PTR(_lHome_9616)->length;
    }
    else {
        _5306 = 1;
    }
    _2 = (int)SEQ_PTR(_lHome_9616);
    _5307 = (int)*(((s1_ptr)_2)->base + _5306);
    if (_5307 == 47)
    goto L6; // [153] 164

    /** 			lHome &= SLASH*/
    if (IS_SEQUENCE(_lHome_9616) && IS_ATOM(47)) {
        Append(&_lHome_9616, _lHome_9616, 47);
    }
    else if (IS_ATOM(_lHome_9616) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_lHome_9616, _lHome_9616, 47);
    }
L6: 

    /** 		if length(lPath) > 1 and lPath[2] = SLASH then*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5310 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5310 = 1;
    }
    _5311 = (_5310 > 1);
    _5310 = NOVALUE;
    if (_5311 == 0) {
        goto L7; // [173] 206
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5313 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_5313)) {
        _5314 = (_5313 == 47);
    }
    else {
        _5314 = binary_op(EQUALS, _5313, 47);
    }
    _5313 = NOVALUE;
    if (_5314 == 0) {
        DeRef(_5314);
        _5314 = NOVALUE;
        goto L7; // [186] 206
    }
    else {
        if (!IS_ATOM_INT(_5314) && DBL_PTR(_5314)->dbl == 0.0){
            DeRef(_5314);
            _5314 = NOVALUE;
            goto L7; // [186] 206
        }
        DeRef(_5314);
        _5314 = NOVALUE;
    }
    DeRef(_5314);
    _5314 = NOVALUE;

    /** 			lPath = lHome & lPath[3 .. $]*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5315 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5315 = 1;
    }
    rhs_slice_target = (object_ptr)&_5316;
    RHS_Slice(_lPath_9612, 3, _5315);
    if (IS_SEQUENCE(_lHome_9616) && IS_ATOM(_5316)) {
    }
    else if (IS_ATOM(_lHome_9616) && IS_SEQUENCE(_5316)) {
        Ref(_lHome_9616);
        Prepend(&_lPath_9612, _5316, _lHome_9616);
    }
    else {
        Concat((object_ptr)&_lPath_9612, _lHome_9616, _5316);
    }
    DeRefDS(_5316);
    _5316 = NOVALUE;
    goto L8; // [203] 221
L7: 

    /** 			lPath = lHome & lPath[2 .. $]*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5318 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5318 = 1;
    }
    rhs_slice_target = (object_ptr)&_5319;
    RHS_Slice(_lPath_9612, 2, _5318);
    if (IS_SEQUENCE(_lHome_9616) && IS_ATOM(_5319)) {
    }
    else if (IS_ATOM(_lHome_9616) && IS_SEQUENCE(_5319)) {
        Ref(_lHome_9616);
        Prepend(&_lPath_9612, _5319, _lHome_9616);
    }
    else {
        Concat((object_ptr)&_lPath_9612, _lHome_9616, _5319);
    }
    DeRefDS(_5319);
    _5319 = NOVALUE;
L8: 
L5: 

    /** 	ifdef WINDOWS then*/

    /** 	sequence wildcard_suffix*/

    /** 	integer first_wildcard_at = find_first_wildcard( lPath )*/
    RefDS(_lPath_9612);
    _first_wildcard_at_9659 = _14find_first_wildcard(_lPath_9612, 1);
    if (!IS_ATOM_INT(_first_wildcard_at_9659)) {
        _1 = (long)(DBL_PTR(_first_wildcard_at_9659)->dbl);
        DeRefDS(_first_wildcard_at_9659);
        _first_wildcard_at_9659 = _1;
    }

    /** 	if first_wildcard_at then*/
    if (_first_wildcard_at_9659 == 0)
    {
        goto L9; // [237] 298
    }
    else{
    }

    /** 		integer last_slash = search:rfind( SLASH, lPath, first_wildcard_at )*/
    RefDS(_lPath_9612);
    _last_slash_9662 = _20rfind(47, _lPath_9612, _first_wildcard_at_9659);
    if (!IS_ATOM_INT(_last_slash_9662)) {
        _1 = (long)(DBL_PTR(_last_slash_9662)->dbl);
        DeRefDS(_last_slash_9662);
        _last_slash_9662 = _1;
    }

    /** 		if last_slash then*/
    if (_last_slash_9662 == 0)
    {
        goto LA; // [252] 278
    }
    else{
    }

    /** 			wildcard_suffix = lPath[last_slash..$]*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5323 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5323 = 1;
    }
    rhs_slice_target = (object_ptr)&_wildcard_suffix_9658;
    RHS_Slice(_lPath_9612, _last_slash_9662, _5323);

    /** 			lPath = remove( lPath, last_slash, length( lPath ) )*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5325 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5325 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_9612);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_last_slash_9662)) ? _last_slash_9662 : (long)(DBL_PTR(_last_slash_9662)->dbl);
        int stop = (IS_ATOM_INT(_5325)) ? _5325 : (long)(DBL_PTR(_5325)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_9612), start, &_lPath_9612 );
            }
            else Tail(SEQ_PTR(_lPath_9612), stop+1, &_lPath_9612);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_9612), start, &_lPath_9612);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_9612 = Remove_elements(start, stop, (SEQ_PTR(_lPath_9612)->ref == 1));
        }
    }
    _5325 = NOVALUE;
    goto LB; // [275] 293
LA: 

    /** 			wildcard_suffix = lPath*/
    RefDS(_lPath_9612);
    DeRef(_wildcard_suffix_9658);
    _wildcard_suffix_9658 = _lPath_9612;

    /** 			lPath = ""*/
    RefDS(_5);
    DeRefDS(_lPath_9612);
    _lPath_9612 = _5;
LB: 
    goto LC; // [295] 306
L9: 

    /** 		wildcard_suffix = ""*/
    RefDS(_5);
    DeRef(_wildcard_suffix_9658);
    _wildcard_suffix_9658 = _5;
LC: 

    /** 	if ((length(lPath) = 0) or not find(lPath[1], "/\\")) then*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5327 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5327 = 1;
    }
    _5328 = (_5327 == 0);
    _5327 = NOVALUE;
    if (_5328 != 0) {
        DeRef(_5329);
        _5329 = 1;
        goto LD; // [315] 335
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5330 = (int)*(((s1_ptr)_2)->base + 1);
    _5332 = find_from(_5330, _5331, 1);
    _5330 = NOVALUE;
    _5333 = (_5332 == 0);
    _5332 = NOVALUE;
    _5329 = (_5333 != 0);
LD: 
    if (_5329 == 0)
    {
        _5329 = NOVALUE;
        goto LE; // [335] 351
    }
    else{
        _5329 = NOVALUE;
    }

    /** 		ifdef UNIX then*/

    /** 			lPath = curdir() & lPath*/
    _5334 = _14curdir(0);
    if (IS_SEQUENCE(_5334) && IS_ATOM(_lPath_9612)) {
    }
    else if (IS_ATOM(_5334) && IS_SEQUENCE(_lPath_9612)) {
        Ref(_5334);
        Prepend(&_lPath_9612, _lPath_9612, _5334);
    }
    else {
        Concat((object_ptr)&_lPath_9612, _5334, _lPath_9612);
        DeRef(_5334);
        _5334 = NOVALUE;
    }
    DeRef(_5334);
    _5334 = NOVALUE;
LE: 

    /** 	if ((directory_given != 0) and (lPath[$] != SLASH) ) then*/
    _5336 = (_directory_given_9610 != 0);
    if (_5336 == 0) {
        DeRef(_5337);
        _5337 = 0;
        goto LF; // [357] 376
    }
    if (IS_SEQUENCE(_lPath_9612)){
            _5338 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5338 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5339 = (int)*(((s1_ptr)_2)->base + _5338);
    if (IS_ATOM_INT(_5339)) {
        _5340 = (_5339 != 47);
    }
    else {
        _5340 = binary_op(NOTEQ, _5339, 47);
    }
    _5339 = NOVALUE;
    if (IS_ATOM_INT(_5340))
    _5337 = (_5340 != 0);
    else
    _5337 = DBL_PTR(_5340)->dbl != 0.0;
LF: 
    if (_5337 == 0)
    {
        _5337 = NOVALUE;
        goto L10; // [376] 386
    }
    else{
        _5337 = NOVALUE;
    }

    /** 		lPath &= SLASH*/
    Append(&_lPath_9612, _lPath_9612, 47);
L10: 

    /** 	lLevel = SLASH & '.' & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = 46;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_9615, concat_list, 3);
    }

    /** 	lPosA = 1*/
    _lPosA_9613 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L11; // [401] 422
L12: 
    if (_lPosA_9613 == 0)
    goto L13; // [404] 434

    /** 		lPath = eu:remove(lPath, lPosA, lPosA + 1)*/
    _5344 = _lPosA_9613 + 1;
    if (_5344 > MAXINT){
        _5344 = NewDouble((double)_5344);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_9612);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosA_9613)) ? _lPosA_9613 : (long)(DBL_PTR(_lPosA_9613)->dbl);
        int stop = (IS_ATOM_INT(_5344)) ? _5344 : (long)(DBL_PTR(_5344)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_9612), start, &_lPath_9612 );
            }
            else Tail(SEQ_PTR(_lPath_9612), stop+1, &_lPath_9612);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_9612), start, &_lPath_9612);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_9612 = Remove_elements(start, stop, (SEQ_PTR(_lPath_9612)->ref == 1));
        }
    }
    DeRef(_5344);
    _5344 = NOVALUE;

    /** 	  entry*/
L11: 

    /** 		lPosA = match(lLevel, lPath, lPosA )*/
    _lPosA_9613 = e_match_from(_lLevel_9615, _lPath_9612, _lPosA_9613);

    /** 	end while*/
    goto L12; // [431] 404
L13: 

    /** 	lLevel = SLASH & ".." & SLASH*/
    {
        int concat_list[3];

        concat_list[0] = 47;
        concat_list[1] = _5094;
        concat_list[2] = 47;
        Concat_N((object_ptr)&_lLevel_9615, concat_list, 3);
    }

    /** 	lPosB = 1*/
    _lPosB_9614 = 1;

    /** 	while( lPosA != 0 ) with entry do*/
    goto L14; // [449] 527
L15: 
    if (_lPosA_9613 == 0)
    goto L16; // [452] 539

    /** 		lPosB = lPosA-1*/
    _lPosB_9614 = _lPosA_9613 - 1;

    /** 		while((lPosB > 0) and (lPath[lPosB] != SLASH)) do*/
L17: 
    _5350 = (_lPosB_9614 > 0);
    if (_5350 == 0) {
        DeRef(_5351);
        _5351 = 0;
        goto L18; // [471] 487
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5352 = (int)*(((s1_ptr)_2)->base + _lPosB_9614);
    if (IS_ATOM_INT(_5352)) {
        _5353 = (_5352 != 47);
    }
    else {
        _5353 = binary_op(NOTEQ, _5352, 47);
    }
    _5352 = NOVALUE;
    if (IS_ATOM_INT(_5353))
    _5351 = (_5353 != 0);
    else
    _5351 = DBL_PTR(_5353)->dbl != 0.0;
L18: 
    if (_5351 == 0)
    {
        _5351 = NOVALUE;
        goto L19; // [487] 501
    }
    else{
        _5351 = NOVALUE;
    }

    /** 			lPosB -= 1*/
    _lPosB_9614 = _lPosB_9614 - 1;

    /** 		end while*/
    goto L17; // [498] 467
L19: 

    /** 		if (lPosB <= 0) then*/
    if (_lPosB_9614 > 0)
    goto L1A; // [503] 513

    /** 			lPosB = 1*/
    _lPosB_9614 = 1;
L1A: 

    /** 		lPath = eu:remove(lPath, lPosB, lPosA + 2)*/
    _5356 = _lPosA_9613 + 2;
    if ((long)((unsigned long)_5356 + (unsigned long)HIGH_BITS) >= 0) 
    _5356 = NewDouble((double)_5356);
    {
        s1_ptr assign_space = SEQ_PTR(_lPath_9612);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_lPosB_9614)) ? _lPosB_9614 : (long)(DBL_PTR(_lPosB_9614)->dbl);
        int stop = (IS_ATOM_INT(_5356)) ? _5356 : (long)(DBL_PTR(_5356)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_lPath_9612), start, &_lPath_9612 );
            }
            else Tail(SEQ_PTR(_lPath_9612), stop+1, &_lPath_9612);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_lPath_9612), start, &_lPath_9612);
        }
        else {
            assign_slice_seq = &assign_space;
            _lPath_9612 = Remove_elements(start, stop, (SEQ_PTR(_lPath_9612)->ref == 1));
        }
    }
    DeRef(_5356);
    _5356 = NOVALUE;

    /** 	  entry*/
L14: 

    /** 		lPosA = match(lLevel, lPath, lPosB )*/
    _lPosA_9613 = e_match_from(_lLevel_9615, _lPath_9612, _lPosB_9614);

    /** 	end while*/
    goto L15; // [536] 452
L16: 

    /** 	if case_flags = TO_LOWER then*/
    if (_case_flags_9611 != 1)
    goto L1B; // [541] 556

    /** 		lPath = lower( lPath )*/
    RefDS(_lPath_9612);
    _0 = _lPath_9612;
    _lPath_9612 = _18lower(_lPath_9612);
    DeRefDS(_0);
    goto L1C; // [553] 1149
L1B: 

    /** 	elsif case_flags != AS_IS then*/
    if (_case_flags_9611 == 0)
    goto L1D; // [558] 1146

    /** 		sequence sl = find_all(SLASH,lPath) -- split apart lPath*/
    RefDS(_lPath_9612);
    _0 = _sl_9715;
    _sl_9715 = _20find_all(47, _lPath_9612, 1);
    DeRef(_0);

    /** 		integer short_name = and_bits(TO_SHORT,case_flags)=TO_SHORT*/
    {unsigned long tu;
         tu = (unsigned long)4 & (unsigned long)_case_flags_9611;
         _5363 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5363)) {
        _short_name_9718 = (_5363 == 4);
    }
    else {
        _short_name_9718 = (DBL_PTR(_5363)->dbl == (double)4);
    }
    DeRef(_5363);
    _5363 = NOVALUE;

    /** 		integer correct_name = and_bits(case_flags,CORRECT)=CORRECT*/
    {unsigned long tu;
         tu = (unsigned long)_case_flags_9611 & (unsigned long)2;
         _5365 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5365)) {
        _correct_name_9721 = (_5365 == 2);
    }
    else {
        _correct_name_9721 = (DBL_PTR(_5365)->dbl == (double)2);
    }
    DeRef(_5365);
    _5365 = NOVALUE;

    /** 		integer lower_name = and_bits(TO_LOWER,case_flags)=TO_LOWER*/
    {unsigned long tu;
         tu = (unsigned long)1 & (unsigned long)_case_flags_9611;
         _5367 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5367)) {
        _lower_name_9724 = (_5367 == 1);
    }
    else {
        _lower_name_9724 = (DBL_PTR(_5367)->dbl == (double)1);
    }
    DeRef(_5367);
    _5367 = NOVALUE;

    /** 		if lPath[$] != SLASH then*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5369 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5369 = 1;
    }
    _2 = (int)SEQ_PTR(_lPath_9612);
    _5370 = (int)*(((s1_ptr)_2)->base + _5369);
    if (binary_op_a(EQUALS, _5370, 47)){
        _5370 = NOVALUE;
        goto L1E; // [611] 633
    }
    _5370 = NOVALUE;

    /** 			sl = sl & {length(lPath)+1}*/
    if (IS_SEQUENCE(_lPath_9612)){
            _5372 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5372 = 1;
    }
    _5373 = _5372 + 1;
    _5372 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5373;
    _5374 = MAKE_SEQ(_1);
    _5373 = NOVALUE;
    Concat((object_ptr)&_sl_9715, _sl_9715, _5374);
    DeRefDS(_5374);
    _5374 = NOVALUE;
L1E: 

    /** 		for i = length(sl)-1 to 1 by -1 label "partloop" do*/
    if (IS_SEQUENCE(_sl_9715)){
            _5376 = SEQ_PTR(_sl_9715)->length;
    }
    else {
        _5376 = 1;
    }
    _5377 = _5376 - 1;
    _5376 = NOVALUE;
    {
        int _i_9736;
        _i_9736 = _5377;
L1F: 
        if (_i_9736 < 1){
            goto L20; // [642] 1111
        }

        /** 			sequence part = lPath[1..sl[i]-1]*/
        _2 = (int)SEQ_PTR(_sl_9715);
        _5379 = (int)*(((s1_ptr)_2)->base + _i_9736);
        if (IS_ATOM_INT(_5379)) {
            _5380 = _5379 - 1;
        }
        else {
            _5380 = binary_op(MINUS, _5379, 1);
        }
        _5379 = NOVALUE;
        rhs_slice_target = (object_ptr)&_part_9740;
        RHS_Slice(_lPath_9612, 1, _5380);

        /** 			object list = dir( part & SLASH )*/
        Append(&_5382, _part_9740, 47);
        _0 = _list_9744;
        _list_9744 = _14dir(_5382);
        DeRef(_0);
        _5382 = NOVALUE;

        /** 			sequence supplied_name = lPath[sl[i]+1..sl[i+1]-1]*/
        _2 = (int)SEQ_PTR(_sl_9715);
        _5384 = (int)*(((s1_ptr)_2)->base + _i_9736);
        if (IS_ATOM_INT(_5384)) {
            _5385 = _5384 + 1;
            if (_5385 > MAXINT){
                _5385 = NewDouble((double)_5385);
            }
        }
        else
        _5385 = binary_op(PLUS, 1, _5384);
        _5384 = NOVALUE;
        _5386 = _i_9736 + 1;
        _2 = (int)SEQ_PTR(_sl_9715);
        _5387 = (int)*(((s1_ptr)_2)->base + _5386);
        if (IS_ATOM_INT(_5387)) {
            _5388 = _5387 - 1;
        }
        else {
            _5388 = binary_op(MINUS, _5387, 1);
        }
        _5387 = NOVALUE;
        rhs_slice_target = (object_ptr)&_supplied_name_9747;
        RHS_Slice(_lPath_9612, _5385, _5388);

        /** 			if atom(list) then*/
        _5390 = IS_ATOM(_list_9744);
        if (_5390 == 0)
        {
            _5390 = NOVALUE;
            goto L21; // [706] 744
        }
        else{
            _5390 = NOVALUE;
        }

        /** 				if lower_name then*/
        if (_lower_name_9724 == 0)
        {
            goto L22; // [711] 737
        }
        else{
        }

        /** 					lPath = part & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_9715);
        _5391 = (int)*(((s1_ptr)_2)->base + _i_9736);
        if (IS_SEQUENCE(_lPath_9612)){
                _5392 = SEQ_PTR(_lPath_9612)->length;
        }
        else {
            _5392 = 1;
        }
        rhs_slice_target = (object_ptr)&_5393;
        RHS_Slice(_lPath_9612, _5391, _5392);
        _5394 = _18lower(_5393);
        _5393 = NOVALUE;
        if (IS_SEQUENCE(_part_9740) && IS_ATOM(_5394)) {
            Ref(_5394);
            Append(&_lPath_9612, _part_9740, _5394);
        }
        else if (IS_ATOM(_part_9740) && IS_SEQUENCE(_5394)) {
        }
        else {
            Concat((object_ptr)&_lPath_9612, _part_9740, _5394);
        }
        DeRef(_5394);
        _5394 = NOVALUE;
L22: 

        /** 				continue*/
        DeRef(_part_9740);
        _part_9740 = NOVALUE;
        DeRef(_list_9744);
        _list_9744 = NOVALUE;
        DeRef(_supplied_name_9747);
        _supplied_name_9747 = NOVALUE;
        goto L23; // [741] 1106
L21: 

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_9744)){
                _5396 = SEQ_PTR(_list_9744)->length;
        }
        else {
            _5396 = 1;
        }
        {
            int _j_9764;
            _j_9764 = 1;
L24: 
            if (_j_9764 > _5396){
                goto L25; // [749] 874
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_9744);
            _5397 = (int)*(((s1_ptr)_2)->base + _j_9764);
            DeRef(_read_name_9766);
            _2 = (int)SEQ_PTR(_5397);
            _read_name_9766 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_9766);
            _5397 = NOVALUE;

            /** 				if equal(read_name, supplied_name) then*/
            if (_read_name_9766 == _supplied_name_9747)
            _5399 = 1;
            else if (IS_ATOM_INT(_read_name_9766) && IS_ATOM_INT(_supplied_name_9747))
            _5399 = 0;
            else
            _5399 = (compare(_read_name_9766, _supplied_name_9747) == 0);
            if (_5399 == 0)
            {
                _5399 = NOVALUE;
                goto L26; // [774] 865
            }
            else{
                _5399 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_9718 == 0) {
                goto L27; // [779] 856
            }
            _2 = (int)SEQ_PTR(_list_9744);
            _5401 = (int)*(((s1_ptr)_2)->base + _j_9764);
            _2 = (int)SEQ_PTR(_5401);
            _5402 = (int)*(((s1_ptr)_2)->base + 11);
            _5401 = NOVALUE;
            _5403 = IS_SEQUENCE(_5402);
            _5402 = NOVALUE;
            if (_5403 == 0)
            {
                _5403 = NOVALUE;
                goto L27; // [795] 856
            }
            else{
                _5403 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_9715);
            _5404 = (int)*(((s1_ptr)_2)->base + _i_9736);
            rhs_slice_target = (object_ptr)&_5405;
            RHS_Slice(_lPath_9612, 1, _5404);
            _2 = (int)SEQ_PTR(_list_9744);
            _5406 = (int)*(((s1_ptr)_2)->base + _j_9764);
            _2 = (int)SEQ_PTR(_5406);
            _5407 = (int)*(((s1_ptr)_2)->base + 11);
            _5406 = NOVALUE;
            _5408 = _i_9736 + 1;
            _2 = (int)SEQ_PTR(_sl_9715);
            _5409 = (int)*(((s1_ptr)_2)->base + _5408);
            if (IS_SEQUENCE(_lPath_9612)){
                    _5410 = SEQ_PTR(_lPath_9612)->length;
            }
            else {
                _5410 = 1;
            }
            rhs_slice_target = (object_ptr)&_5411;
            RHS_Slice(_lPath_9612, _5409, _5410);
            {
                int concat_list[3];

                concat_list[0] = _5411;
                concat_list[1] = _5407;
                concat_list[2] = _5405;
                Concat_N((object_ptr)&_lPath_9612, concat_list, 3);
            }
            DeRefDS(_5411);
            _5411 = NOVALUE;
            _5407 = NOVALUE;
            DeRefDS(_5405);
            _5405 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_9715)){
                    _5413 = SEQ_PTR(_sl_9715)->length;
            }
            else {
                _5413 = 1;
            }
            if (IS_SEQUENCE(_lPath_9612)){
                    _5414 = SEQ_PTR(_lPath_9612)->length;
            }
            else {
                _5414 = 1;
            }
            _5415 = _5414 + 1;
            _5414 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_9715);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_9715 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _5413);
            _1 = *(int *)_2;
            *(int *)_2 = _5415;
            if( _1 != _5415 ){
                DeRef(_1);
            }
            _5415 = NOVALUE;
L27: 

            /** 					continue "partloop"*/
            DeRef(_read_name_9766);
            _read_name_9766 = NOVALUE;
            DeRef(_part_9740);
            _part_9740 = NOVALUE;
            DeRef(_list_9744);
            _list_9744 = NOVALUE;
            DeRef(_supplied_name_9747);
            _supplied_name_9747 = NOVALUE;
            goto L23; // [862] 1106
L26: 
            DeRef(_read_name_9766);
            _read_name_9766 = NOVALUE;

            /** 			end for*/
            _j_9764 = _j_9764 + 1;
            goto L24; // [869] 756
L25: 
            ;
        }

        /** 			for j = 1 to length(list) do*/
        if (IS_SEQUENCE(_list_9744)){
                _5416 = SEQ_PTR(_list_9744)->length;
        }
        else {
            _5416 = 1;
        }
        {
            int _j_9789;
            _j_9789 = 1;
L28: 
            if (_j_9789 > _5416){
                goto L29; // [879] 1051
            }

            /** 				sequence read_name = list[j][D_NAME]*/
            _2 = (int)SEQ_PTR(_list_9744);
            _5417 = (int)*(((s1_ptr)_2)->base + _j_9789);
            DeRef(_read_name_9791);
            _2 = (int)SEQ_PTR(_5417);
            _read_name_9791 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_read_name_9791);
            _5417 = NOVALUE;

            /** 				if equal(lower(read_name), lower(supplied_name)) then*/
            RefDS(_read_name_9791);
            _5419 = _18lower(_read_name_9791);
            RefDS(_supplied_name_9747);
            _5420 = _18lower(_supplied_name_9747);
            if (_5419 == _5420)
            _5421 = 1;
            else if (IS_ATOM_INT(_5419) && IS_ATOM_INT(_5420))
            _5421 = 0;
            else
            _5421 = (compare(_5419, _5420) == 0);
            DeRef(_5419);
            _5419 = NOVALUE;
            DeRef(_5420);
            _5420 = NOVALUE;
            if (_5421 == 0)
            {
                _5421 = NOVALUE;
                goto L2A; // [912] 1042
            }
            else{
                _5421 = NOVALUE;
            }

            /** 					if short_name and sequence(list[j][D_ALTNAME]) then*/
            if (_short_name_9718 == 0) {
                goto L2B; // [917] 994
            }
            _2 = (int)SEQ_PTR(_list_9744);
            _5423 = (int)*(((s1_ptr)_2)->base + _j_9789);
            _2 = (int)SEQ_PTR(_5423);
            _5424 = (int)*(((s1_ptr)_2)->base + 11);
            _5423 = NOVALUE;
            _5425 = IS_SEQUENCE(_5424);
            _5424 = NOVALUE;
            if (_5425 == 0)
            {
                _5425 = NOVALUE;
                goto L2B; // [933] 994
            }
            else{
                _5425 = NOVALUE;
            }

            /** 						lPath = lPath[1..sl[i]] & list[j][D_ALTNAME] & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_9715);
            _5426 = (int)*(((s1_ptr)_2)->base + _i_9736);
            rhs_slice_target = (object_ptr)&_5427;
            RHS_Slice(_lPath_9612, 1, _5426);
            _2 = (int)SEQ_PTR(_list_9744);
            _5428 = (int)*(((s1_ptr)_2)->base + _j_9789);
            _2 = (int)SEQ_PTR(_5428);
            _5429 = (int)*(((s1_ptr)_2)->base + 11);
            _5428 = NOVALUE;
            _5430 = _i_9736 + 1;
            _2 = (int)SEQ_PTR(_sl_9715);
            _5431 = (int)*(((s1_ptr)_2)->base + _5430);
            if (IS_SEQUENCE(_lPath_9612)){
                    _5432 = SEQ_PTR(_lPath_9612)->length;
            }
            else {
                _5432 = 1;
            }
            rhs_slice_target = (object_ptr)&_5433;
            RHS_Slice(_lPath_9612, _5431, _5432);
            {
                int concat_list[3];

                concat_list[0] = _5433;
                concat_list[1] = _5429;
                concat_list[2] = _5427;
                Concat_N((object_ptr)&_lPath_9612, concat_list, 3);
            }
            DeRefDS(_5433);
            _5433 = NOVALUE;
            _5429 = NOVALUE;
            DeRefDS(_5427);
            _5427 = NOVALUE;

            /** 						sl[$] = length(lPath)+1*/
            if (IS_SEQUENCE(_sl_9715)){
                    _5435 = SEQ_PTR(_sl_9715)->length;
            }
            else {
                _5435 = 1;
            }
            if (IS_SEQUENCE(_lPath_9612)){
                    _5436 = SEQ_PTR(_lPath_9612)->length;
            }
            else {
                _5436 = 1;
            }
            _5437 = _5436 + 1;
            _5436 = NOVALUE;
            _2 = (int)SEQ_PTR(_sl_9715);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _sl_9715 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _5435);
            _1 = *(int *)_2;
            *(int *)_2 = _5437;
            if( _1 != _5437 ){
                DeRef(_1);
            }
            _5437 = NOVALUE;
L2B: 

            /** 					if correct_name then*/
            if (_correct_name_9721 == 0)
            {
                goto L2C; // [996] 1033
            }
            else{
            }

            /** 						lPath = lPath[1..sl[i]] & read_name & lPath[sl[i+1]..$]*/
            _2 = (int)SEQ_PTR(_sl_9715);
            _5438 = (int)*(((s1_ptr)_2)->base + _i_9736);
            rhs_slice_target = (object_ptr)&_5439;
            RHS_Slice(_lPath_9612, 1, _5438);
            _5440 = _i_9736 + 1;
            _2 = (int)SEQ_PTR(_sl_9715);
            _5441 = (int)*(((s1_ptr)_2)->base + _5440);
            if (IS_SEQUENCE(_lPath_9612)){
                    _5442 = SEQ_PTR(_lPath_9612)->length;
            }
            else {
                _5442 = 1;
            }
            rhs_slice_target = (object_ptr)&_5443;
            RHS_Slice(_lPath_9612, _5441, _5442);
            {
                int concat_list[3];

                concat_list[0] = _5443;
                concat_list[1] = _read_name_9791;
                concat_list[2] = _5439;
                Concat_N((object_ptr)&_lPath_9612, concat_list, 3);
            }
            DeRefDS(_5443);
            _5443 = NOVALUE;
            DeRefDS(_5439);
            _5439 = NOVALUE;
L2C: 

            /** 					continue "partloop"*/
            DeRef(_read_name_9791);
            _read_name_9791 = NOVALUE;
            DeRef(_part_9740);
            _part_9740 = NOVALUE;
            DeRef(_list_9744);
            _list_9744 = NOVALUE;
            DeRef(_supplied_name_9747);
            _supplied_name_9747 = NOVALUE;
            goto L23; // [1039] 1106
L2A: 
            DeRef(_read_name_9791);
            _read_name_9791 = NOVALUE;

            /** 			end for*/
            _j_9789 = _j_9789 + 1;
            goto L28; // [1046] 886
L29: 
            ;
        }

        /** 			if and_bits(TO_LOWER,case_flags) then*/
        {unsigned long tu;
             tu = (unsigned long)1 & (unsigned long)_case_flags_9611;
             _5445 = MAKE_UINT(tu);
        }
        if (_5445 == 0) {
            DeRef(_5445);
            _5445 = NOVALUE;
            goto L2D; // [1057] 1096
        }
        else {
            if (!IS_ATOM_INT(_5445) && DBL_PTR(_5445)->dbl == 0.0){
                DeRef(_5445);
                _5445 = NOVALUE;
                goto L2D; // [1057] 1096
            }
            DeRef(_5445);
            _5445 = NOVALUE;
        }
        DeRef(_5445);
        _5445 = NOVALUE;

        /** 				lPath = lPath[1..sl[i]-1] & lower(lPath[sl[i]..$])*/
        _2 = (int)SEQ_PTR(_sl_9715);
        _5446 = (int)*(((s1_ptr)_2)->base + _i_9736);
        if (IS_ATOM_INT(_5446)) {
            _5447 = _5446 - 1;
        }
        else {
            _5447 = binary_op(MINUS, _5446, 1);
        }
        _5446 = NOVALUE;
        rhs_slice_target = (object_ptr)&_5448;
        RHS_Slice(_lPath_9612, 1, _5447);
        _2 = (int)SEQ_PTR(_sl_9715);
        _5449 = (int)*(((s1_ptr)_2)->base + _i_9736);
        if (IS_SEQUENCE(_lPath_9612)){
                _5450 = SEQ_PTR(_lPath_9612)->length;
        }
        else {
            _5450 = 1;
        }
        rhs_slice_target = (object_ptr)&_5451;
        RHS_Slice(_lPath_9612, _5449, _5450);
        _5452 = _18lower(_5451);
        _5451 = NOVALUE;
        if (IS_SEQUENCE(_5448) && IS_ATOM(_5452)) {
            Ref(_5452);
            Append(&_lPath_9612, _5448, _5452);
        }
        else if (IS_ATOM(_5448) && IS_SEQUENCE(_5452)) {
        }
        else {
            Concat((object_ptr)&_lPath_9612, _5448, _5452);
            DeRefDS(_5448);
            _5448 = NOVALUE;
        }
        DeRef(_5448);
        _5448 = NOVALUE;
        DeRef(_5452);
        _5452 = NOVALUE;
L2D: 

        /** 			exit*/
        DeRef(_part_9740);
        _part_9740 = NOVALUE;
        DeRef(_list_9744);
        _list_9744 = NOVALUE;
        DeRef(_supplied_name_9747);
        _supplied_name_9747 = NOVALUE;
        goto L20; // [1100] 1111

        /** 		end for*/
L23: 
        _i_9736 = _i_9736 + -1;
        goto L1F; // [1106] 649
L20: 
        ;
    }

    /** 		if and_bits(case_flags,or_bits(CORRECT,TO_LOWER))=TO_LOWER and length(lPath) then*/
    {unsigned long tu;
         tu = (unsigned long)2 | (unsigned long)1;
         _5454 = MAKE_UINT(tu);
    }
    if (IS_ATOM_INT(_5454)) {
        {unsigned long tu;
             tu = (unsigned long)_case_flags_9611 & (unsigned long)_5454;
             _5455 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_case_flags_9611;
        _5455 = Dand_bits(&temp_d, DBL_PTR(_5454));
    }
    DeRef(_5454);
    _5454 = NOVALUE;
    if (IS_ATOM_INT(_5455)) {
        _5456 = (_5455 == 1);
    }
    else {
        _5456 = (DBL_PTR(_5455)->dbl == (double)1);
    }
    DeRef(_5455);
    _5455 = NOVALUE;
    if (_5456 == 0) {
        goto L2E; // [1125] 1145
    }
    if (IS_SEQUENCE(_lPath_9612)){
            _5458 = SEQ_PTR(_lPath_9612)->length;
    }
    else {
        _5458 = 1;
    }
    if (_5458 == 0)
    {
        _5458 = NOVALUE;
        goto L2E; // [1133] 1145
    }
    else{
        _5458 = NOVALUE;
    }

    /** 			lPath = lower(lPath)*/
    RefDS(_lPath_9612);
    _0 = _lPath_9612;
    _lPath_9612 = _18lower(_lPath_9612);
    DeRefDS(_0);
L2E: 
L1D: 
    DeRef(_sl_9715);
    _sl_9715 = NOVALUE;
L1C: 

    /** 	ifdef WINDOWS then*/

    /** 	return lPath & wildcard_suffix*/
    Concat((object_ptr)&_5460, _lPath_9612, _wildcard_suffix_9658);
    DeRefDS(_path_in_9609);
    DeRefDS(_lPath_9612);
    DeRefi(_lLevel_9615);
    DeRefi(_lHome_9616);
    DeRefDS(_wildcard_suffix_9658);
    DeRef(_5293);
    _5293 = NOVALUE;
    _5307 = NOVALUE;
    _5391 = NOVALUE;
    _5409 = NOVALUE;
    DeRef(_5430);
    _5430 = NOVALUE;
    DeRef(_5301);
    _5301 = NOVALUE;
    DeRef(_5311);
    _5311 = NOVALUE;
    DeRef(_5377);
    _5377 = NOVALUE;
    DeRef(_5456);
    _5456 = NOVALUE;
    DeRef(_5295);
    _5295 = NOVALUE;
    DeRef(_5350);
    _5350 = NOVALUE;
    DeRef(_5353);
    _5353 = NOVALUE;
    DeRef(_5289);
    _5289 = NOVALUE;
    DeRef(_5336);
    _5336 = NOVALUE;
    DeRef(_5386);
    _5386 = NOVALUE;
    DeRef(_5447);
    _5447 = NOVALUE;
    _5441 = NOVALUE;
    DeRef(_5388);
    _5388 = NOVALUE;
    _5404 = NOVALUE;
    _5449 = NOVALUE;
    DeRef(_5328);
    _5328 = NOVALUE;
    DeRef(_5298);
    _5298 = NOVALUE;
    DeRef(_5380);
    _5380 = NOVALUE;
    DeRef(_5408);
    _5408 = NOVALUE;
    _5431 = NOVALUE;
    DeRef(_5333);
    _5333 = NOVALUE;
    DeRef(_5340);
    _5340 = NOVALUE;
    DeRef(_5286);
    _5286 = NOVALUE;
    _5438 = NOVALUE;
    DeRef(_5385);
    _5385 = NOVALUE;
    DeRef(_5440);
    _5440 = NOVALUE;
    _5426 = NOVALUE;
    return _5460;
    ;
}


int _14abbreviate_path(int _orig_path_9850, int _base_paths_9851)
{
    int _expanded_path_9852 = NOVALUE;
    int _fs_case_inlined_fs_case_at_61_9862 = NOVALUE;
    int _lowered_expanded_path_9863 = NOVALUE;
    int _fs_case_inlined_fs_case_at_73_9865 = NOVALUE;
    int _fs_case_inlined_fs_case_at_216_9892 = NOVALUE;
    int _s_inlined_fs_case_at_213_9891 = NOVALUE;
    int _5496 = NOVALUE;
    int _5495 = NOVALUE;
    int _5492 = NOVALUE;
    int _5491 = NOVALUE;
    int _5490 = NOVALUE;
    int _5489 = NOVALUE;
    int _5488 = NOVALUE;
    int _5486 = NOVALUE;
    int _5485 = NOVALUE;
    int _5484 = NOVALUE;
    int _5483 = NOVALUE;
    int _5482 = NOVALUE;
    int _5481 = NOVALUE;
    int _5480 = NOVALUE;
    int _5479 = NOVALUE;
    int _5476 = NOVALUE;
    int _5475 = NOVALUE;
    int _5474 = NOVALUE;
    int _5473 = NOVALUE;
    int _5472 = NOVALUE;
    int _5471 = NOVALUE;
    int _5470 = NOVALUE;
    int _5469 = NOVALUE;
    int _5468 = NOVALUE;
    int _5467 = NOVALUE;
    int _5466 = NOVALUE;
    int _5465 = NOVALUE;
    int _5464 = NOVALUE;
    int _5462 = NOVALUE;
    int _0, _1, _2;
    

    /** 	expanded_path = canonical_path(orig_path)*/
    RefDS(_orig_path_9850);
    _0 = _expanded_path_9852;
    _expanded_path_9852 = _14canonical_path(_orig_path_9850, 0, 0);
    DeRef(_0);

    /** 	base_paths = append(base_paths, curdir())*/
    _5462 = _14curdir(0);
    Ref(_5462);
    Append(&_base_paths_9851, _base_paths_9851, _5462);
    DeRef(_5462);
    _5462 = NOVALUE;

    /** 	for i = 1 to length(base_paths) do*/
    _5464 = 1;
    {
        int _i_9857;
        _i_9857 = 1;
L1: 
        if (_i_9857 > 1){
            goto L2; // [30] 60
        }

        /** 		base_paths[i] = canonical_path(base_paths[i], 1) -- assume each base path is meant to be a directory.*/
        _2 = (int)SEQ_PTR(_base_paths_9851);
        _5465 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_5465);
        _5466 = _14canonical_path(_5465, 1, 0);
        _5465 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_9851);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _base_paths_9851 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _5466;
        if( _1 != _5466 ){
            DeRef(_1);
        }
        _5466 = NOVALUE;

        /** 	end for*/
        _i_9857 = 1 + 1;
        goto L1; // [55] 37
L2: 
        ;
    }

    /** 	base_paths = fs_case(base_paths)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_base_paths_9851);
    DeRefDS(_base_paths_9851);
    _base_paths_9851 = _base_paths_9851;

    /** 	sequence lowered_expanded_path = fs_case(expanded_path)*/

    /** 	ifdef WINDOWS then*/

    /** 		return s*/
    RefDS(_expanded_path_9852);
    DeRef(_lowered_expanded_path_9863);
    _lowered_expanded_path_9863 = _expanded_path_9852;

    /** 	for i = 1 to length(base_paths) do*/
    if (IS_SEQUENCE(_base_paths_9851)){
            _5467 = SEQ_PTR(_base_paths_9851)->length;
    }
    else {
        _5467 = 1;
    }
    {
        int _i_9867;
        _i_9867 = 1;
L3: 
        if (_i_9867 > _5467){
            goto L4; // [89] 143
        }

        /** 		if search:begins(base_paths[i], lowered_expanded_path) then*/
        _2 = (int)SEQ_PTR(_base_paths_9851);
        _5468 = (int)*(((s1_ptr)_2)->base + _i_9867);
        Ref(_5468);
        RefDS(_lowered_expanded_path_9863);
        _5469 = _20begins(_5468, _lowered_expanded_path_9863);
        _5468 = NOVALUE;
        if (_5469 == 0) {
            DeRef(_5469);
            _5469 = NOVALUE;
            goto L5; // [107] 136
        }
        else {
            if (!IS_ATOM_INT(_5469) && DBL_PTR(_5469)->dbl == 0.0){
                DeRef(_5469);
                _5469 = NOVALUE;
                goto L5; // [107] 136
            }
            DeRef(_5469);
            _5469 = NOVALUE;
        }
        DeRef(_5469);
        _5469 = NOVALUE;

        /** 			return expanded_path[length(base_paths[i]) + 1 .. $]*/
        _2 = (int)SEQ_PTR(_base_paths_9851);
        _5470 = (int)*(((s1_ptr)_2)->base + _i_9867);
        if (IS_SEQUENCE(_5470)){
                _5471 = SEQ_PTR(_5470)->length;
        }
        else {
            _5471 = 1;
        }
        _5470 = NOVALUE;
        _5472 = _5471 + 1;
        _5471 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_9852)){
                _5473 = SEQ_PTR(_expanded_path_9852)->length;
        }
        else {
            _5473 = 1;
        }
        rhs_slice_target = (object_ptr)&_5474;
        RHS_Slice(_expanded_path_9852, _5472, _5473);
        DeRefDS(_orig_path_9850);
        DeRefDS(_base_paths_9851);
        DeRefDS(_expanded_path_9852);
        DeRefDS(_lowered_expanded_path_9863);
        _5470 = NOVALUE;
        _5472 = NOVALUE;
        return _5474;
L5: 

        /** 	end for*/
        _i_9867 = _i_9867 + 1;
        goto L3; // [138] 96
L4: 
        ;
    }

    /** 	ifdef WINDOWS then*/

    /** 	base_paths = stdseq:split(base_paths[$], SLASH)*/
    if (IS_SEQUENCE(_base_paths_9851)){
            _5475 = SEQ_PTR(_base_paths_9851)->length;
    }
    else {
        _5475 = 1;
    }
    _2 = (int)SEQ_PTR(_base_paths_9851);
    _5476 = (int)*(((s1_ptr)_2)->base + _5475);
    Ref(_5476);
    _0 = _base_paths_9851;
    _base_paths_9851 = _24split(_5476, 47, 0, 0);
    DeRefDS(_0);
    _5476 = NOVALUE;

    /** 	expanded_path = stdseq:split(expanded_path, SLASH)*/
    RefDS(_expanded_path_9852);
    _0 = _expanded_path_9852;
    _expanded_path_9852 = _24split(_expanded_path_9852, 47, 0, 0);
    DeRefDS(_0);

    /** 	lowered_expanded_path = ""*/
    RefDS(_5);
    DeRef(_lowered_expanded_path_9863);
    _lowered_expanded_path_9863 = _5;

    /** 	for i = 1 to math:min({length(expanded_path), length(base_paths) - 1}) do*/
    if (IS_SEQUENCE(_expanded_path_9852)){
            _5479 = SEQ_PTR(_expanded_path_9852)->length;
    }
    else {
        _5479 = 1;
    }
    if (IS_SEQUENCE(_base_paths_9851)){
            _5480 = SEQ_PTR(_base_paths_9851)->length;
    }
    else {
        _5480 = 1;
    }
    _5481 = _5480 - 1;
    _5480 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _5479;
    ((int *)_2)[2] = _5481;
    _5482 = MAKE_SEQ(_1);
    _5481 = NOVALUE;
    _5479 = NOVALUE;
    _5483 = _21min(_5482);
    _5482 = NOVALUE;
    {
        int _i_9882;
        _i_9882 = 1;
L6: 
        if (binary_op_a(GREATER, _i_9882, _5483)){
            goto L7; // [201] 305
        }

        /** 		if not equal(fs_case(expanded_path[i]), base_paths[i]) then*/
        _2 = (int)SEQ_PTR(_expanded_path_9852);
        if (!IS_ATOM_INT(_i_9882)){
            _5484 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_9882)->dbl));
        }
        else{
            _5484 = (int)*(((s1_ptr)_2)->base + _i_9882);
        }
        Ref(_5484);
        DeRef(_s_inlined_fs_case_at_213_9891);
        _s_inlined_fs_case_at_213_9891 = _5484;
        _5484 = NOVALUE;

        /** 	ifdef WINDOWS then*/

        /** 		return s*/
        Ref(_s_inlined_fs_case_at_213_9891);
        DeRef(_fs_case_inlined_fs_case_at_216_9892);
        _fs_case_inlined_fs_case_at_216_9892 = _s_inlined_fs_case_at_213_9891;
        DeRef(_s_inlined_fs_case_at_213_9891);
        _s_inlined_fs_case_at_213_9891 = NOVALUE;
        _2 = (int)SEQ_PTR(_base_paths_9851);
        if (!IS_ATOM_INT(_i_9882)){
            _5485 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_9882)->dbl));
        }
        else{
            _5485 = (int)*(((s1_ptr)_2)->base + _i_9882);
        }
        if (_fs_case_inlined_fs_case_at_216_9892 == _5485)
        _5486 = 1;
        else if (IS_ATOM_INT(_fs_case_inlined_fs_case_at_216_9892) && IS_ATOM_INT(_5485))
        _5486 = 0;
        else
        _5486 = (compare(_fs_case_inlined_fs_case_at_216_9892, _5485) == 0);
        _5485 = NOVALUE;
        if (_5486 != 0)
        goto L8; // [237] 298
        _5486 = NOVALUE;

        /** 			expanded_path = repeat("..", length(base_paths) - i) & expanded_path[i .. $]*/
        if (IS_SEQUENCE(_base_paths_9851)){
                _5488 = SEQ_PTR(_base_paths_9851)->length;
        }
        else {
            _5488 = 1;
        }
        if (IS_ATOM_INT(_i_9882)) {
            _5489 = _5488 - _i_9882;
        }
        else {
            _5489 = NewDouble((double)_5488 - DBL_PTR(_i_9882)->dbl);
        }
        _5488 = NOVALUE;
        _5490 = Repeat(_5094, _5489);
        DeRef(_5489);
        _5489 = NOVALUE;
        if (IS_SEQUENCE(_expanded_path_9852)){
                _5491 = SEQ_PTR(_expanded_path_9852)->length;
        }
        else {
            _5491 = 1;
        }
        rhs_slice_target = (object_ptr)&_5492;
        RHS_Slice(_expanded_path_9852, _i_9882, _5491);
        Concat((object_ptr)&_expanded_path_9852, _5490, _5492);
        DeRefDS(_5490);
        _5490 = NOVALUE;
        DeRef(_5490);
        _5490 = NOVALUE;
        DeRefDS(_5492);
        _5492 = NOVALUE;

        /** 			expanded_path = stdseq:join(expanded_path, SLASH)*/
        RefDS(_expanded_path_9852);
        _0 = _expanded_path_9852;
        _expanded_path_9852 = _24join(_expanded_path_9852, 47);
        DeRefDS(_0);

        /** 			if length(expanded_path) < length(orig_path) then*/
        if (IS_SEQUENCE(_expanded_path_9852)){
                _5495 = SEQ_PTR(_expanded_path_9852)->length;
        }
        else {
            _5495 = 1;
        }
        if (IS_SEQUENCE(_orig_path_9850)){
                _5496 = SEQ_PTR(_orig_path_9850)->length;
        }
        else {
            _5496 = 1;
        }
        if (_5495 >= _5496)
        goto L7; // [282] 305

        /** 		  		return expanded_path*/
        DeRef(_i_9882);
        DeRefDS(_orig_path_9850);
        DeRefDS(_base_paths_9851);
        DeRef(_lowered_expanded_path_9863);
        _5470 = NOVALUE;
        DeRef(_5472);
        _5472 = NOVALUE;
        DeRef(_5474);
        _5474 = NOVALUE;
        DeRef(_5483);
        _5483 = NOVALUE;
        return _expanded_path_9852;

        /** 			exit*/
        goto L7; // [295] 305
L8: 

        /** 	end for*/
        _0 = _i_9882;
        if (IS_ATOM_INT(_i_9882)) {
            _i_9882 = _i_9882 + 1;
            if ((long)((unsigned long)_i_9882 +(unsigned long) HIGH_BITS) >= 0){
                _i_9882 = NewDouble((double)_i_9882);
            }
        }
        else {
            _i_9882 = binary_op_a(PLUS, _i_9882, 1);
        }
        DeRef(_0);
        goto L6; // [300] 208
L7: 
        ;
        DeRef(_i_9882);
    }

    /** 	return orig_path*/
    DeRefDS(_base_paths_9851);
    DeRef(_expanded_path_9852);
    DeRef(_lowered_expanded_path_9863);
    _5470 = NOVALUE;
    DeRef(_5472);
    _5472 = NOVALUE;
    DeRef(_5474);
    _5474 = NOVALUE;
    DeRef(_5483);
    _5483 = NOVALUE;
    return _orig_path_9850;
    ;
}


int _14file_type(int _filename_9940)
{
    int _dirfil_9941 = NOVALUE;
    int _5529 = NOVALUE;
    int _5528 = NOVALUE;
    int _5527 = NOVALUE;
    int _5526 = NOVALUE;
    int _5525 = NOVALUE;
    int _5523 = NOVALUE;
    int _5522 = NOVALUE;
    int _5521 = NOVALUE;
    int _5520 = NOVALUE;
    int _5519 = NOVALUE;
    int _5518 = NOVALUE;
    int _5517 = NOVALUE;
    int _5515 = NOVALUE;
    int _5513 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if eu:find('*', filename) or eu:find('?', filename) then return FILETYPE_UNDEFINED end if*/
    _5513 = find_from(42, _filename_9940, 1);
    if (_5513 != 0) {
        goto L1; // [10] 24
    }
    _5515 = find_from(63, _filename_9940, 1);
    if (_5515 == 0)
    {
        _5515 = NOVALUE;
        goto L2; // [20] 29
    }
    else{
        _5515 = NOVALUE;
    }
L1: 
    DeRefDS(_filename_9940);
    DeRef(_dirfil_9941);
    return -1;
L2: 

    /** 	ifdef WINDOWS then*/

    /** 	dirfil = dir(filename)*/
    RefDS(_filename_9940);
    _0 = _dirfil_9941;
    _dirfil_9941 = _14dir(_filename_9940);
    DeRef(_0);

    /** 	if sequence(dirfil) then*/
    _5517 = IS_SEQUENCE(_dirfil_9941);
    if (_5517 == 0)
    {
        _5517 = NOVALUE;
        goto L3; // [42] 126
    }
    else{
        _5517 = NOVALUE;
    }

    /** 		if length( dirfil ) > 1 or eu:find('d', dirfil[1][2]) or (length(filename)=3 and filename[2]=':') then*/
    if (IS_SEQUENCE(_dirfil_9941)){
            _5518 = SEQ_PTR(_dirfil_9941)->length;
    }
    else {
        _5518 = 1;
    }
    _5519 = (_5518 > 1);
    _5518 = NOVALUE;
    if (_5519 != 0) {
        _5520 = 1;
        goto L4; // [54] 75
    }
    _2 = (int)SEQ_PTR(_dirfil_9941);
    _5521 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5521);
    _5522 = (int)*(((s1_ptr)_2)->base + 2);
    _5521 = NOVALUE;
    _5523 = find_from(100, _5522, 1);
    _5522 = NOVALUE;
    _5520 = (_5523 != 0);
L4: 
    if (_5520 != 0) {
        goto L5; // [75] 107
    }
    if (IS_SEQUENCE(_filename_9940)){
            _5525 = SEQ_PTR(_filename_9940)->length;
    }
    else {
        _5525 = 1;
    }
    _5526 = (_5525 == 3);
    _5525 = NOVALUE;
    if (_5526 == 0) {
        DeRef(_5527);
        _5527 = 0;
        goto L6; // [86] 102
    }
    _2 = (int)SEQ_PTR(_filename_9940);
    _5528 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_5528)) {
        _5529 = (_5528 == 58);
    }
    else {
        _5529 = binary_op(EQUALS, _5528, 58);
    }
    _5528 = NOVALUE;
    if (IS_ATOM_INT(_5529))
    _5527 = (_5529 != 0);
    else
    _5527 = DBL_PTR(_5529)->dbl != 0.0;
L6: 
    if (_5527 == 0)
    {
        _5527 = NOVALUE;
        goto L7; // [103] 116
    }
    else{
        _5527 = NOVALUE;
    }
L5: 

    /** 			return FILETYPE_DIRECTORY*/
    DeRefDS(_filename_9940);
    DeRef(_dirfil_9941);
    DeRef(_5519);
    _5519 = NOVALUE;
    DeRef(_5526);
    _5526 = NOVALUE;
    DeRef(_5529);
    _5529 = NOVALUE;
    return 2;
    goto L8; // [113] 133
L7: 

    /** 			return FILETYPE_FILE*/
    DeRefDS(_filename_9940);
    DeRef(_dirfil_9941);
    DeRef(_5519);
    _5519 = NOVALUE;
    DeRef(_5526);
    _5526 = NOVALUE;
    DeRef(_5529);
    _5529 = NOVALUE;
    return 1;
    goto L8; // [123] 133
L3: 

    /** 		return FILETYPE_NOT_FOUND*/
    DeRefDS(_filename_9940);
    DeRef(_dirfil_9941);
    DeRef(_5519);
    _5519 = NOVALUE;
    DeRef(_5526);
    _5526 = NOVALUE;
    DeRef(_5529);
    _5529 = NOVALUE;
    return 0;
L8: 
    ;
}


int _14file_exists(int _name_9980)
{
    int _pName_9983 = NOVALUE;
    int _r_9985 = NOVALUE;
    int _5534 = NOVALUE;
    int _5532 = NOVALUE;
    int _5530 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(name) then*/
    _5530 = IS_ATOM(_name_9980);
    if (_5530 == 0)
    {
        _5530 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _5530 = NOVALUE;
    }

    /** 		return 0*/
    DeRef(_name_9980);
    DeRef(_pName_9983);
    DeRef(_r_9985);
    return 0;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 		atom pName = machine:allocate_string(name)*/
    Ref(_name_9980);
    _0 = _pName_9983;
    _pName_9983 = _4allocate_string(_name_9980, 0);
    DeRef(_0);

    /** 		atom r = c_func(xGetFileAttributes, {pName, 0})*/
    Ref(_pName_9983);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _pName_9983;
    ((int *)_2)[2] = 0;
    _5532 = MAKE_SEQ(_1);
    DeRef(_r_9985);
    _r_9985 = call_c(1, _14xGetFileAttributes_9062, _5532);
    DeRefDS(_5532);
    _5532 = NOVALUE;

    /** 		machine:free(pName)*/
    Ref(_pName_9983);
    _4free(_pName_9983);

    /** 		return r = 0*/
    if (IS_ATOM_INT(_r_9985)) {
        _5534 = (_r_9985 == 0);
    }
    else {
        _5534 = (DBL_PTR(_r_9985)->dbl == (double)0);
    }
    DeRef(_name_9980);
    DeRef(_pName_9983);
    DeRef(_r_9985);
    return _5534;
    ;
}


int _14file_timestamp(int _fname_9991)
{
    int _d_9992 = NOVALUE;
    int _5549 = NOVALUE;
    int _5548 = NOVALUE;
    int _5547 = NOVALUE;
    int _5546 = NOVALUE;
    int _5545 = NOVALUE;
    int _5544 = NOVALUE;
    int _5543 = NOVALUE;
    int _5542 = NOVALUE;
    int _5541 = NOVALUE;
    int _5540 = NOVALUE;
    int _5539 = NOVALUE;
    int _5538 = NOVALUE;
    int _5537 = NOVALUE;
    int _5536 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d = dir(fname)*/
    RefDS(_fname_9991);
    _0 = _d_9992;
    _d_9992 = _14dir(_fname_9991);
    DeRef(_0);

    /** 	if atom(d) then return -1 end if*/
    _5536 = IS_ATOM(_d_9992);
    if (_5536 == 0)
    {
        _5536 = NOVALUE;
        goto L1; // [14] 22
    }
    else{
        _5536 = NOVALUE;
    }
    DeRefDS(_fname_9991);
    DeRef(_d_9992);
    return -1;
L1: 

    /** 	return datetime:new(d[1][D_YEAR], d[1][D_MONTH], d[1][D_DAY],*/
    _2 = (int)SEQ_PTR(_d_9992);
    _5537 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5537);
    _5538 = (int)*(((s1_ptr)_2)->base + 4);
    _5537 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_9992);
    _5539 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5539);
    _5540 = (int)*(((s1_ptr)_2)->base + 5);
    _5539 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_9992);
    _5541 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5541);
    _5542 = (int)*(((s1_ptr)_2)->base + 6);
    _5541 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_9992);
    _5543 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5543);
    _5544 = (int)*(((s1_ptr)_2)->base + 7);
    _5543 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_9992);
    _5545 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5545);
    _5546 = (int)*(((s1_ptr)_2)->base + 8);
    _5545 = NOVALUE;
    _2 = (int)SEQ_PTR(_d_9992);
    _5547 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_5547);
    _5548 = (int)*(((s1_ptr)_2)->base + 9);
    _5547 = NOVALUE;
    Ref(_5538);
    Ref(_5540);
    Ref(_5542);
    Ref(_5544);
    Ref(_5546);
    Ref(_5548);
    _5549 = _15new(_5538, _5540, _5542, _5544, _5546, _5548);
    _5538 = NOVALUE;
    _5540 = NOVALUE;
    _5542 = NOVALUE;
    _5544 = NOVALUE;
    _5546 = NOVALUE;
    _5548 = NOVALUE;
    DeRefDS(_fname_9991);
    DeRef(_d_9992);
    return _5549;
    ;
}


int _14locate_file(int _filename_10178, int _search_list_10179, int _subdir_10180)
{
    int _extra_paths_10181 = NOVALUE;
    int _this_path_10182 = NOVALUE;
    int _5715 = NOVALUE;
    int _5714 = NOVALUE;
    int _5712 = NOVALUE;
    int _5710 = NOVALUE;
    int _5708 = NOVALUE;
    int _5707 = NOVALUE;
    int _5706 = NOVALUE;
    int _5704 = NOVALUE;
    int _5703 = NOVALUE;
    int _5702 = NOVALUE;
    int _5700 = NOVALUE;
    int _5699 = NOVALUE;
    int _5698 = NOVALUE;
    int _5695 = NOVALUE;
    int _5694 = NOVALUE;
    int _5692 = NOVALUE;
    int _5690 = NOVALUE;
    int _5689 = NOVALUE;
    int _5686 = NOVALUE;
    int _5681 = NOVALUE;
    int _5677 = NOVALUE;
    int _5668 = NOVALUE;
    int _5665 = NOVALUE;
    int _5662 = NOVALUE;
    int _5661 = NOVALUE;
    int _5657 = NOVALUE;
    int _5654 = NOVALUE;
    int _5652 = NOVALUE;
    int _5648 = NOVALUE;
    int _5646 = NOVALUE;
    int _5645 = NOVALUE;
    int _5641 = NOVALUE;
    int _5640 = NOVALUE;
    int _5637 = NOVALUE;
    int _5635 = NOVALUE;
    int _5634 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if absolute_path(filename) then*/
    RefDS(_filename_10178);
    _5634 = _14absolute_path(_filename_10178);
    if (_5634 == 0) {
        DeRef(_5634);
        _5634 = NOVALUE;
        goto L1; // [13] 23
    }
    else {
        if (!IS_ATOM_INT(_5634) && DBL_PTR(_5634)->dbl == 0.0){
            DeRef(_5634);
            _5634 = NOVALUE;
            goto L1; // [13] 23
        }
        DeRef(_5634);
        _5634 = NOVALUE;
    }
    DeRef(_5634);
    _5634 = NOVALUE;

    /** 		return filename*/
    DeRefDS(_search_list_10179);
    DeRefDS(_subdir_10180);
    DeRef(_extra_paths_10181);
    DeRef(_this_path_10182);
    return _filename_10178;
L1: 

    /** 	if length(search_list) = 0 then*/
    if (IS_SEQUENCE(_search_list_10179)){
            _5635 = SEQ_PTR(_search_list_10179)->length;
    }
    else {
        _5635 = 1;
    }
    if (_5635 != 0)
    goto L2; // [28] 282

    /** 		search_list = append(search_list, "." & SLASH)*/
    Append(&_5637, _5027, 47);
    RefDS(_5637);
    Append(&_search_list_10179, _search_list_10179, _5637);
    DeRefDS(_5637);
    _5637 = NOVALUE;

    /** 		extra_paths = command_line()*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = Command_Line();

    /** 		extra_paths = canonical_path(dirname(extra_paths[2]), 1)*/
    _2 = (int)SEQ_PTR(_extra_paths_10181);
    _5640 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_5640);
    _5641 = _14dirname(_5640, 0);
    _5640 = NOVALUE;
    _0 = _extra_paths_10181;
    _extra_paths_10181 = _14canonical_path(_5641, 1, 0);
    DeRefDS(_0);
    _5641 = NOVALUE;

    /** 		search_list = append(search_list, extra_paths)*/
    Ref(_extra_paths_10181);
    Append(&_search_list_10179, _search_list_10179, _extra_paths_10181);

    /** 		ifdef UNIX then*/

    /** 			extra_paths = getenv("HOME")*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = EGetEnv(_5302);

    /** 		if sequence(extra_paths) then*/
    _5645 = IS_SEQUENCE(_extra_paths_10181);
    if (_5645 == 0)
    {
        _5645 = NOVALUE;
        goto L3; // [81] 95
    }
    else{
        _5645 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_10181) && IS_ATOM(47)) {
        Append(&_5646, _extra_paths_10181, 47);
    }
    else if (IS_ATOM(_extra_paths_10181) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_5646, _extra_paths_10181, 47);
    }
    RefDS(_5646);
    Append(&_search_list_10179, _search_list_10179, _5646);
    DeRefDS(_5646);
    _5646 = NOVALUE;
L3: 

    /** 		search_list = append(search_list, ".." & SLASH)*/
    Append(&_5648, _5094, 47);
    RefDS(_5648);
    Append(&_search_list_10179, _search_list_10179, _5648);
    DeRefDS(_5648);
    _5648 = NOVALUE;

    /** 		extra_paths = getenv("EUDIR")*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = EGetEnv(_5650);

    /** 		if sequence(extra_paths) then*/
    _5652 = IS_SEQUENCE(_extra_paths_10181);
    if (_5652 == 0)
    {
        _5652 = NOVALUE;
        goto L4; // [115] 145
    }
    else{
        _5652 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH & "bin" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _5653;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10181;
        Concat_N((object_ptr)&_5654, concat_list, 4);
    }
    RefDS(_5654);
    Append(&_search_list_10179, _search_list_10179, _5654);
    DeRefDS(_5654);
    _5654 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "docs" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _5656;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10181;
        Concat_N((object_ptr)&_5657, concat_list, 4);
    }
    RefDS(_5657);
    Append(&_search_list_10179, _search_list_10179, _5657);
    DeRefDS(_5657);
    _5657 = NOVALUE;
L4: 

    /** 		extra_paths = getenv("EUDIST")*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = EGetEnv(_5659);

    /** 		if sequence(extra_paths) then*/
    _5661 = IS_SEQUENCE(_extra_paths_10181);
    if (_5661 == 0)
    {
        _5661 = NOVALUE;
        goto L5; // [155] 195
    }
    else{
        _5661 = NOVALUE;
    }

    /** 			search_list = append(search_list, extra_paths & SLASH)*/
    if (IS_SEQUENCE(_extra_paths_10181) && IS_ATOM(47)) {
        Append(&_5662, _extra_paths_10181, 47);
    }
    else if (IS_ATOM(_extra_paths_10181) && IS_SEQUENCE(47)) {
    }
    else {
        Concat((object_ptr)&_5662, _extra_paths_10181, 47);
    }
    RefDS(_5662);
    Append(&_search_list_10179, _search_list_10179, _5662);
    DeRefDS(_5662);
    _5662 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "etc" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _5664;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10181;
        Concat_N((object_ptr)&_5665, concat_list, 4);
    }
    RefDS(_5665);
    Append(&_search_list_10179, _search_list_10179, _5665);
    DeRefDS(_5665);
    _5665 = NOVALUE;

    /** 			search_list = append(search_list, extra_paths & SLASH & "data" & SLASH)*/
    {
        int concat_list[4];

        concat_list[0] = 47;
        concat_list[1] = _5667;
        concat_list[2] = 47;
        concat_list[3] = _extra_paths_10181;
        Concat_N((object_ptr)&_5668, concat_list, 4);
    }
    RefDS(_5668);
    Append(&_search_list_10179, _search_list_10179, _5668);
    DeRefDS(_5668);
    _5668 = NOVALUE;
L5: 

    /** 		ifdef UNIX then*/

    /** 			search_list = append( search_list, "/usr/local/share/euphoria/bin/" )*/
    RefDS(_5670);
    Append(&_search_list_10179, _search_list_10179, _5670);

    /** 			search_list = append( search_list, "/usr/share/euphoria/bin/" )*/
    RefDS(_5672);
    Append(&_search_list_10179, _search_list_10179, _5672);

    /** 		search_list &= include_paths(1)*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5676);
    *((int *)(_2+4)) = _5676;
    RefDS(_5675);
    *((int *)(_2+8)) = _5675;
    RefDS(_5674);
    *((int *)(_2+12)) = _5674;
    _5677 = MAKE_SEQ(_1);
    Concat((object_ptr)&_search_list_10179, _search_list_10179, _5677);
    DeRefDS(_5677);
    _5677 = NOVALUE;

    /** 		extra_paths = getenv("USERPATH")*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = EGetEnv(_5679);

    /** 		if sequence(extra_paths) then*/
    _5681 = IS_SEQUENCE(_extra_paths_10181);
    if (_5681 == 0)
    {
        _5681 = NOVALUE;
        goto L6; // [231] 250
    }
    else{
        _5681 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_10181);
    _0 = _extra_paths_10181;
    _extra_paths_10181 = _24split(_extra_paths_10181, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_10179) && IS_ATOM(_extra_paths_10181)) {
        Ref(_extra_paths_10181);
        Append(&_search_list_10179, _search_list_10179, _extra_paths_10181);
    }
    else if (IS_ATOM(_search_list_10179) && IS_SEQUENCE(_extra_paths_10181)) {
    }
    else {
        Concat((object_ptr)&_search_list_10179, _search_list_10179, _extra_paths_10181);
    }
L6: 

    /** 		extra_paths = getenv("PATH")*/
    DeRef(_extra_paths_10181);
    _extra_paths_10181 = EGetEnv(_5684);

    /** 		if sequence(extra_paths) then*/
    _5686 = IS_SEQUENCE(_extra_paths_10181);
    if (_5686 == 0)
    {
        _5686 = NOVALUE;
        goto L7; // [260] 307
    }
    else{
        _5686 = NOVALUE;
    }

    /** 			extra_paths = stdseq:split(extra_paths, PATHSEP)*/
    Ref(_extra_paths_10181);
    _0 = _extra_paths_10181;
    _extra_paths_10181 = _24split(_extra_paths_10181, 58, 0, 0);
    DeRefi(_0);

    /** 			search_list &= extra_paths*/
    if (IS_SEQUENCE(_search_list_10179) && IS_ATOM(_extra_paths_10181)) {
        Ref(_extra_paths_10181);
        Append(&_search_list_10179, _search_list_10179, _extra_paths_10181);
    }
    else if (IS_ATOM(_search_list_10179) && IS_SEQUENCE(_extra_paths_10181)) {
    }
    else {
        Concat((object_ptr)&_search_list_10179, _search_list_10179, _extra_paths_10181);
    }
    goto L7; // [279] 307
L2: 

    /** 		if integer(search_list[1]) then*/
    _2 = (int)SEQ_PTR(_search_list_10179);
    _5689 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_5689))
    _5690 = 1;
    else if (IS_ATOM_DBL(_5689))
    _5690 = IS_ATOM_INT(DoubleToInt(_5689));
    else
    _5690 = 0;
    _5689 = NOVALUE;
    if (_5690 == 0)
    {
        _5690 = NOVALUE;
        goto L8; // [291] 306
    }
    else{
        _5690 = NOVALUE;
    }

    /** 			search_list = stdseq:split(search_list, PATHSEP)*/
    RefDS(_search_list_10179);
    _0 = _search_list_10179;
    _search_list_10179 = _24split(_search_list_10179, 58, 0, 0);
    DeRefDS(_0);
L8: 
L7: 

    /** 	if length(subdir) > 0 then*/
    if (IS_SEQUENCE(_subdir_10180)){
            _5692 = SEQ_PTR(_subdir_10180)->length;
    }
    else {
        _5692 = 1;
    }
    if (_5692 <= 0)
    goto L9; // [312] 337

    /** 		if subdir[$] != SLASH then*/
    if (IS_SEQUENCE(_subdir_10180)){
            _5694 = SEQ_PTR(_subdir_10180)->length;
    }
    else {
        _5694 = 1;
    }
    _2 = (int)SEQ_PTR(_subdir_10180);
    _5695 = (int)*(((s1_ptr)_2)->base + _5694);
    if (binary_op_a(EQUALS, _5695, 47)){
        _5695 = NOVALUE;
        goto LA; // [325] 336
    }
    _5695 = NOVALUE;

    /** 			subdir &= SLASH*/
    Append(&_subdir_10180, _subdir_10180, 47);
LA: 
L9: 

    /** 	for i = 1 to length(search_list) do*/
    if (IS_SEQUENCE(_search_list_10179)){
            _5698 = SEQ_PTR(_search_list_10179)->length;
    }
    else {
        _5698 = 1;
    }
    {
        int _i_10259;
        _i_10259 = 1;
LB: 
        if (_i_10259 > _5698){
            goto LC; // [342] 465
        }

        /** 		if length(search_list[i]) = 0 then*/
        _2 = (int)SEQ_PTR(_search_list_10179);
        _5699 = (int)*(((s1_ptr)_2)->base + _i_10259);
        if (IS_SEQUENCE(_5699)){
                _5700 = SEQ_PTR(_5699)->length;
        }
        else {
            _5700 = 1;
        }
        _5699 = NOVALUE;
        if (_5700 != 0)
        goto LD; // [358] 367

        /** 			continue*/
        goto LE; // [364] 460
LD: 

        /** 		if search_list[i][$] != SLASH then*/
        _2 = (int)SEQ_PTR(_search_list_10179);
        _5702 = (int)*(((s1_ptr)_2)->base + _i_10259);
        if (IS_SEQUENCE(_5702)){
                _5703 = SEQ_PTR(_5702)->length;
        }
        else {
            _5703 = 1;
        }
        _2 = (int)SEQ_PTR(_5702);
        _5704 = (int)*(((s1_ptr)_2)->base + _5703);
        _5702 = NOVALUE;
        if (binary_op_a(EQUALS, _5704, 47)){
            _5704 = NOVALUE;
            goto LF; // [380] 399
        }
        _5704 = NOVALUE;

        /** 			search_list[i] &= SLASH*/
        _2 = (int)SEQ_PTR(_search_list_10179);
        _5706 = (int)*(((s1_ptr)_2)->base + _i_10259);
        if (IS_SEQUENCE(_5706) && IS_ATOM(47)) {
            Append(&_5707, _5706, 47);
        }
        else if (IS_ATOM(_5706) && IS_SEQUENCE(47)) {
        }
        else {
            Concat((object_ptr)&_5707, _5706, 47);
            _5706 = NOVALUE;
        }
        _5706 = NOVALUE;
        _2 = (int)SEQ_PTR(_search_list_10179);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _search_list_10179 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_10259);
        _1 = *(int *)_2;
        *(int *)_2 = _5707;
        if( _1 != _5707 ){
            DeRef(_1);
        }
        _5707 = NOVALUE;
LF: 

        /** 		if length(subdir) > 0 then*/
        if (IS_SEQUENCE(_subdir_10180)){
                _5708 = SEQ_PTR(_subdir_10180)->length;
        }
        else {
            _5708 = 1;
        }
        if (_5708 <= 0)
        goto L10; // [404] 423

        /** 			this_path = search_list[i] & subdir & filename*/
        _2 = (int)SEQ_PTR(_search_list_10179);
        _5710 = (int)*(((s1_ptr)_2)->base + _i_10259);
        {
            int concat_list[3];

            concat_list[0] = _filename_10178;
            concat_list[1] = _subdir_10180;
            concat_list[2] = _5710;
            Concat_N((object_ptr)&_this_path_10182, concat_list, 3);
        }
        _5710 = NOVALUE;
        goto L11; // [420] 434
L10: 

        /** 			this_path = search_list[i] & filename*/
        _2 = (int)SEQ_PTR(_search_list_10179);
        _5712 = (int)*(((s1_ptr)_2)->base + _i_10259);
        if (IS_SEQUENCE(_5712) && IS_ATOM(_filename_10178)) {
        }
        else if (IS_ATOM(_5712) && IS_SEQUENCE(_filename_10178)) {
            Ref(_5712);
            Prepend(&_this_path_10182, _filename_10178, _5712);
        }
        else {
            Concat((object_ptr)&_this_path_10182, _5712, _filename_10178);
            _5712 = NOVALUE;
        }
        _5712 = NOVALUE;
L11: 

        /** 		if file_exists(this_path) then*/
        RefDS(_this_path_10182);
        _5714 = _14file_exists(_this_path_10182);
        if (_5714 == 0) {
            DeRef(_5714);
            _5714 = NOVALUE;
            goto L12; // [442] 458
        }
        else {
            if (!IS_ATOM_INT(_5714) && DBL_PTR(_5714)->dbl == 0.0){
                DeRef(_5714);
                _5714 = NOVALUE;
                goto L12; // [442] 458
            }
            DeRef(_5714);
            _5714 = NOVALUE;
        }
        DeRef(_5714);
        _5714 = NOVALUE;

        /** 			return canonical_path(this_path)*/
        RefDS(_this_path_10182);
        _5715 = _14canonical_path(_this_path_10182, 0, 0);
        DeRefDS(_filename_10178);
        DeRefDS(_search_list_10179);
        DeRefDS(_subdir_10180);
        DeRef(_extra_paths_10181);
        DeRefDS(_this_path_10182);
        _5699 = NOVALUE;
        return _5715;
L12: 

        /** 	end for*/
LE: 
        _i_10259 = _i_10259 + 1;
        goto LB; // [460] 349
LC: 
        ;
    }

    /** 	return filename*/
    DeRefDS(_search_list_10179);
    DeRefDS(_subdir_10180);
    DeRef(_extra_paths_10181);
    DeRef(_this_path_10182);
    _5699 = NOVALUE;
    DeRef(_5715);
    _5715 = NOVALUE;
    return _filename_10178;
    ;
}


int _14count_files(int _orig_path_10361, int _dir_info_10362, int _inst_10363)
{
    int _pos_10364 = NOVALUE;
    int _ext_10365 = NOVALUE;
    int _fileext_inlined_fileext_at_218_10406 = NOVALUE;
    int _data_inlined_fileext_at_218_10405 = NOVALUE;
    int _path_inlined_fileext_at_215_10404 = NOVALUE;
    int _5817 = NOVALUE;
    int _5816 = NOVALUE;
    int _5815 = NOVALUE;
    int _5813 = NOVALUE;
    int _5812 = NOVALUE;
    int _5811 = NOVALUE;
    int _5810 = NOVALUE;
    int _5808 = NOVALUE;
    int _5807 = NOVALUE;
    int _5805 = NOVALUE;
    int _5804 = NOVALUE;
    int _5803 = NOVALUE;
    int _5802 = NOVALUE;
    int _5801 = NOVALUE;
    int _5800 = NOVALUE;
    int _5799 = NOVALUE;
    int _5797 = NOVALUE;
    int _5796 = NOVALUE;
    int _5794 = NOVALUE;
    int _5793 = NOVALUE;
    int _5792 = NOVALUE;
    int _5791 = NOVALUE;
    int _5790 = NOVALUE;
    int _5789 = NOVALUE;
    int _5788 = NOVALUE;
    int _5787 = NOVALUE;
    int _5786 = NOVALUE;
    int _5785 = NOVALUE;
    int _5784 = NOVALUE;
    int _5783 = NOVALUE;
    int _5782 = NOVALUE;
    int _5780 = NOVALUE;
    int _5779 = NOVALUE;
    int _5778 = NOVALUE;
    int _5777 = NOVALUE;
    int _5775 = NOVALUE;
    int _5774 = NOVALUE;
    int _5773 = NOVALUE;
    int _5772 = NOVALUE;
    int _5771 = NOVALUE;
    int _5770 = NOVALUE;
    int _5769 = NOVALUE;
    int _5767 = NOVALUE;
    int _5766 = NOVALUE;
    int _5765 = NOVALUE;
    int _5764 = NOVALUE;
    int _5763 = NOVALUE;
    int _5762 = NOVALUE;
    int _5759 = NOVALUE;
    int _5758 = NOVALUE;
    int _5757 = NOVALUE;
    int _5756 = NOVALUE;
    int _5755 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer pos = 0*/
    _pos_10364 = 0;

    /** 	orig_path = orig_path*/
    RefDS(_orig_path_10361);
    DeRefDS(_orig_path_10361);
    _orig_path_10361 = _orig_path_10361;

    /** 	if equal(dir_info[D_NAME], ".") then*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5755 = (int)*(((s1_ptr)_2)->base + 1);
    if (_5755 == _5027)
    _5756 = 1;
    else if (IS_ATOM_INT(_5755) && IS_ATOM_INT(_5027))
    _5756 = 0;
    else
    _5756 = (compare(_5755, _5027) == 0);
    _5755 = NOVALUE;
    if (_5756 == 0)
    {
        _5756 = NOVALUE;
        goto L1; // [29] 39
    }
    else{
        _5756 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_10361);
    DeRefDS(_dir_info_10362);
    DeRefDS(_inst_10363);
    DeRef(_ext_10365);
    return 0;
L1: 

    /** 	if equal(dir_info[D_NAME], "..") then*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5757 = (int)*(((s1_ptr)_2)->base + 1);
    if (_5757 == _5094)
    _5758 = 1;
    else if (IS_ATOM_INT(_5757) && IS_ATOM_INT(_5094))
    _5758 = 0;
    else
    _5758 = (compare(_5757, _5094) == 0);
    _5757 = NOVALUE;
    if (_5758 == 0)
    {
        _5758 = NOVALUE;
        goto L2; // [49] 59
    }
    else{
        _5758 = NOVALUE;
    }

    /** 		return 0*/
    DeRefDS(_orig_path_10361);
    DeRefDS(_dir_info_10362);
    DeRefDS(_inst_10363);
    DeRef(_ext_10365);
    return 0;
L2: 

    /** 	if inst[1] = 0 then -- count all is false*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5759 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _5759, 0)){
        _5759 = NOVALUE;
        goto L3; // [65] 112
    }
    _5759 = NOVALUE;

    /** 		if find('h', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5762 = (int)*(((s1_ptr)_2)->base + 2);
    _5763 = find_from(104, _5762, 1);
    _5762 = NOVALUE;
    if (_5763 == 0)
    {
        _5763 = NOVALUE;
        goto L4; // [80] 90
    }
    else{
        _5763 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_10361);
    DeRefDS(_dir_info_10362);
    DeRefDS(_inst_10363);
    DeRef(_ext_10365);
    return 0;
L4: 

    /** 		if find('s', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5764 = (int)*(((s1_ptr)_2)->base + 2);
    _5765 = find_from(115, _5764, 1);
    _5764 = NOVALUE;
    if (_5765 == 0)
    {
        _5765 = NOVALUE;
        goto L5; // [101] 111
    }
    else{
        _5765 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_orig_path_10361);
    DeRefDS(_dir_info_10362);
    DeRefDS(_inst_10363);
    DeRef(_ext_10365);
    return 0;
L5: 
L3: 

    /** 	file_counters[inst[2]][COUNT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5766 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5766))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5766)->dbl));
    else
    _3 = (int)(_5766 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5769 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5770 = (int)*(((s1_ptr)_2)->base + 3);
    _5767 = NOVALUE;
    if (IS_ATOM_INT(_5770) && IS_ATOM_INT(_5769)) {
        _5771 = _5770 + _5769;
        if ((long)((unsigned long)_5771 + (unsigned long)HIGH_BITS) >= 0) 
        _5771 = NewDouble((double)_5771);
    }
    else {
        _5771 = binary_op(PLUS, _5770, _5769);
    }
    _5770 = NOVALUE;
    _5769 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5771;
    if( _1 != _5771 ){
        DeRef(_1);
    }
    _5771 = NOVALUE;
    _5767 = NOVALUE;

    /** 	if find('d', dir_info[D_ATTRIBUTES]) then*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5772 = (int)*(((s1_ptr)_2)->base + 2);
    _5773 = find_from(100, _5772, 1);
    _5772 = NOVALUE;
    if (_5773 == 0)
    {
        _5773 = NOVALUE;
        goto L6; // [152] 183
    }
    else{
        _5773 = NOVALUE;
    }

    /** 		file_counters[inst[2]][COUNT_DIRS] += 1*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5774 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5774))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5774)->dbl));
    else
    _3 = (int)(_5774 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5777 = (int)*(((s1_ptr)_2)->base + 1);
    _5775 = NOVALUE;
    if (IS_ATOM_INT(_5777)) {
        _5778 = _5777 + 1;
        if (_5778 > MAXINT){
            _5778 = NewDouble((double)_5778);
        }
    }
    else
    _5778 = binary_op(PLUS, 1, _5777);
    _5777 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _5778;
    if( _1 != _5778 ){
        DeRef(_1);
    }
    _5778 = NOVALUE;
    _5775 = NOVALUE;
    goto L7; // [180] 460
L6: 

    /** 		file_counters[inst[2]][COUNT_FILES] += 1*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5779 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5779))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5779)->dbl));
    else
    _3 = (int)(_5779 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5782 = (int)*(((s1_ptr)_2)->base + 2);
    _5780 = NOVALUE;
    if (IS_ATOM_INT(_5782)) {
        _5783 = _5782 + 1;
        if (_5783 > MAXINT){
            _5783 = NewDouble((double)_5783);
        }
    }
    else
    _5783 = binary_op(PLUS, 1, _5782);
    _5782 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5783;
    if( _1 != _5783 ){
        DeRef(_1);
    }
    _5783 = NOVALUE;
    _5780 = NOVALUE;

    /** 		ifdef not UNIX then*/

    /** 			ext = fileext(dir_info[D_NAME])*/
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5784 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_5784);
    DeRef(_path_inlined_fileext_at_215_10404);
    _path_inlined_fileext_at_215_10404 = _5784;
    _5784 = NOVALUE;

    /** 	data = pathinfo(path)*/
    Ref(_path_inlined_fileext_at_215_10404);
    _0 = _data_inlined_fileext_at_218_10405;
    _data_inlined_fileext_at_218_10405 = _14pathinfo(_path_inlined_fileext_at_215_10404, 0);
    DeRef(_0);

    /** 	return data[4]*/
    DeRef(_ext_10365);
    _2 = (int)SEQ_PTR(_data_inlined_fileext_at_218_10405);
    _ext_10365 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_ext_10365);
    DeRef(_path_inlined_fileext_at_215_10404);
    _path_inlined_fileext_at_215_10404 = NOVALUE;
    DeRef(_data_inlined_fileext_at_218_10405);
    _data_inlined_fileext_at_218_10405 = NOVALUE;

    /** 		pos = 0*/
    _pos_10364 = 0;

    /** 		for i = 1 to length(file_counters[inst[2]][COUNT_TYPES]) do*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5785 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!IS_ATOM_INT(_5785)){
        _5786 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_5785)->dbl));
    }
    else{
        _5786 = (int)*(((s1_ptr)_2)->base + _5785);
    }
    _2 = (int)SEQ_PTR(_5786);
    _5787 = (int)*(((s1_ptr)_2)->base + 4);
    _5786 = NOVALUE;
    if (IS_SEQUENCE(_5787)){
            _5788 = SEQ_PTR(_5787)->length;
    }
    else {
        _5788 = 1;
    }
    _5787 = NOVALUE;
    {
        int _i_10408;
        _i_10408 = 1;
L8: 
        if (_i_10408 > _5788){
            goto L9; // [265] 322
        }

        /** 			if equal(file_counters[inst[2]][COUNT_TYPES][i][EXT_NAME], ext) then*/
        _2 = (int)SEQ_PTR(_inst_10363);
        _5789 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_14file_counters_10358);
        if (!IS_ATOM_INT(_5789)){
            _5790 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_5789)->dbl));
        }
        else{
            _5790 = (int)*(((s1_ptr)_2)->base + _5789);
        }
        _2 = (int)SEQ_PTR(_5790);
        _5791 = (int)*(((s1_ptr)_2)->base + 4);
        _5790 = NOVALUE;
        _2 = (int)SEQ_PTR(_5791);
        _5792 = (int)*(((s1_ptr)_2)->base + _i_10408);
        _5791 = NOVALUE;
        _2 = (int)SEQ_PTR(_5792);
        _5793 = (int)*(((s1_ptr)_2)->base + 1);
        _5792 = NOVALUE;
        if (_5793 == _ext_10365)
        _5794 = 1;
        else if (IS_ATOM_INT(_5793) && IS_ATOM_INT(_ext_10365))
        _5794 = 0;
        else
        _5794 = (compare(_5793, _ext_10365) == 0);
        _5793 = NOVALUE;
        if (_5794 == 0)
        {
            _5794 = NOVALUE;
            goto LA; // [302] 315
        }
        else{
            _5794 = NOVALUE;
        }

        /** 				pos = i*/
        _pos_10364 = _i_10408;

        /** 				exit*/
        goto L9; // [312] 322
LA: 

        /** 		end for*/
        _i_10408 = _i_10408 + 1;
        goto L8; // [317] 272
L9: 
        ;
    }

    /** 		if pos = 0 then*/
    if (_pos_10364 != 0)
    goto LB; // [324] 385

    /** 			file_counters[inst[2]][COUNT_TYPES] &= {{ext, 0, 0}}*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5796 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5796))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5796)->dbl));
    else
    _3 = (int)(_5796 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_ext_10365);
    *((int *)(_2+4)) = _ext_10365;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    _5799 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _5799;
    _5800 = MAKE_SEQ(_1);
    _5799 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5801 = (int)*(((s1_ptr)_2)->base + 4);
    _5797 = NOVALUE;
    if (IS_SEQUENCE(_5801) && IS_ATOM(_5800)) {
    }
    else if (IS_ATOM(_5801) && IS_SEQUENCE(_5800)) {
        Ref(_5801);
        Prepend(&_5802, _5800, _5801);
    }
    else {
        Concat((object_ptr)&_5802, _5801, _5800);
        _5801 = NOVALUE;
    }
    _5801 = NOVALUE;
    DeRefDS(_5800);
    _5800 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _5802;
    if( _1 != _5802 ){
        DeRef(_1);
    }
    _5802 = NOVALUE;
    _5797 = NOVALUE;

    /** 			pos = length(file_counters[inst[2]][COUNT_TYPES])*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5803 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!IS_ATOM_INT(_5803)){
        _5804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_5803)->dbl));
    }
    else{
        _5804 = (int)*(((s1_ptr)_2)->base + _5803);
    }
    _2 = (int)SEQ_PTR(_5804);
    _5805 = (int)*(((s1_ptr)_2)->base + 4);
    _5804 = NOVALUE;
    if (IS_SEQUENCE(_5805)){
            _pos_10364 = SEQ_PTR(_5805)->length;
    }
    else {
        _pos_10364 = 1;
    }
    _5805 = NOVALUE;
LB: 

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5807 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5807))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5807)->dbl));
    else
    _3 = (int)(_5807 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _5808 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_10364 + ((s1_ptr)_2)->base);
    _5808 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5810 = (int)*(((s1_ptr)_2)->base + 2);
    _5808 = NOVALUE;
    if (IS_ATOM_INT(_5810)) {
        _5811 = _5810 + 1;
        if (_5811 > MAXINT){
            _5811 = NewDouble((double)_5811);
        }
    }
    else
    _5811 = binary_op(PLUS, 1, _5810);
    _5810 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _5811;
    if( _1 != _5811 ){
        DeRef(_1);
    }
    _5811 = NOVALUE;
    _5808 = NOVALUE;

    /** 		file_counters[inst[2]][COUNT_TYPES][pos][EXT_SIZE] += dir_info[D_SIZE]*/
    _2 = (int)SEQ_PTR(_inst_10363);
    _5812 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_14file_counters_10358);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _14file_counters_10358 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_5812))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_5812)->dbl));
    else
    _3 = (int)(_5812 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(4 + ((s1_ptr)_2)->base);
    _5813 = NOVALUE;
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pos_10364 + ((s1_ptr)_2)->base);
    _5813 = NOVALUE;
    _2 = (int)SEQ_PTR(_dir_info_10362);
    _5815 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _5816 = (int)*(((s1_ptr)_2)->base + 3);
    _5813 = NOVALUE;
    if (IS_ATOM_INT(_5816) && IS_ATOM_INT(_5815)) {
        _5817 = _5816 + _5815;
        if ((long)((unsigned long)_5817 + (unsigned long)HIGH_BITS) >= 0) 
        _5817 = NewDouble((double)_5817);
    }
    else {
        _5817 = binary_op(PLUS, _5816, _5815);
    }
    _5816 = NOVALUE;
    _5815 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _5817;
    if( _1 != _5817 ){
        DeRef(_1);
    }
    _5817 = NOVALUE;
    _5813 = NOVALUE;
L7: 

    /** 	return 0*/
    DeRefDS(_orig_path_10361);
    DeRefDS(_dir_info_10362);
    DeRefDS(_inst_10363);
    DeRef(_ext_10365);
    _5766 = NOVALUE;
    _5774 = NOVALUE;
    _5779 = NOVALUE;
    _5785 = NOVALUE;
    _5787 = NOVALUE;
    _5789 = NOVALUE;
    _5796 = NOVALUE;
    _5803 = NOVALUE;
    _5805 = NOVALUE;
    _5807 = NOVALUE;
    _5812 = NOVALUE;
    return 0;
    ;
}



// 0x5FDF63F0
