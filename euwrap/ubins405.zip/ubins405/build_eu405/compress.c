// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _58compress(int _x_21603)
{
    int _x4_21604 = NOVALUE;
    int _s_21605 = NOVALUE;
    int _12499 = NOVALUE;
    int _12498 = NOVALUE;
    int _12497 = NOVALUE;
    int _12495 = NOVALUE;
    int _12494 = NOVALUE;
    int _12492 = NOVALUE;
    int _12490 = NOVALUE;
    int _12489 = NOVALUE;
    int _12488 = NOVALUE;
    int _12487 = NOVALUE;
    int _12485 = NOVALUE;
    int _12483 = NOVALUE;
    int _12482 = NOVALUE;
    int _12481 = NOVALUE;
    int _12480 = NOVALUE;
    int _12479 = NOVALUE;
    int _12478 = NOVALUE;
    int _12477 = NOVALUE;
    int _12476 = NOVALUE;
    int _12475 = NOVALUE;
    int _12473 = NOVALUE;
    int _12472 = NOVALUE;
    int _12471 = NOVALUE;
    int _12470 = NOVALUE;
    int _12469 = NOVALUE;
    int _12468 = NOVALUE;
    int _12466 = NOVALUE;
    int _12465 = NOVALUE;
    int _12464 = NOVALUE;
    int _12463 = NOVALUE;
    int _12462 = NOVALUE;
    int _12461 = NOVALUE;
    int _12460 = NOVALUE;
    int _12459 = NOVALUE;
    int _12458 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21603))
    _12458 = 1;
    else if (IS_ATOM_DBL(_x_21603))
    _12458 = IS_ATOM_INT(DoubleToInt(_x_21603));
    else
    _12458 = 0;
    if (_12458 == 0)
    {
        _12458 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _12458 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_21603)) {
        _12459 = (_x_21603 >= -2);
    }
    else {
        _12459 = binary_op(GREATEREQ, _x_21603, -2);
    }
    if (IS_ATOM_INT(_12459)) {
        if (_12459 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_12459)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_21603)) {
        _12461 = (_x_21603 <= 246);
    }
    else {
        _12461 = binary_op(LESSEQ, _x_21603, 246);
    }
    if (_12461 == 0) {
        DeRef(_12461);
        _12461 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_12461) && DBL_PTR(_12461)->dbl == 0.0){
            DeRef(_12461);
            _12461 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_12461);
        _12461 = NOVALUE;
    }
    DeRef(_12461);
    _12461 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_21603)) {
        _12462 = _x_21603 - -2;
        if ((long)((unsigned long)_12462 +(unsigned long) HIGH_BITS) >= 0){
            _12462 = NewDouble((double)_12462);
        }
    }
    else {
        _12462 = binary_op(MINUS, _x_21603, -2);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12462;
    _12463 = MAKE_SEQ(_1);
    _12462 = NOVALUE;
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    return _12463;
    goto L3; // [41] 319
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21603)) {
        _12464 = (_x_21603 >= _58MIN2B_21586);
    }
    else {
        _12464 = binary_op(GREATEREQ, _x_21603, _58MIN2B_21586);
    }
    if (IS_ATOM_INT(_12464)) {
        if (_12464 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_12464)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_21603)) {
        _12466 = (_x_21603 <= 32767);
    }
    else {
        _12466 = binary_op(LESSEQ, _x_21603, 32767);
    }
    if (_12466 == 0) {
        DeRef(_12466);
        _12466 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_12466) && DBL_PTR(_12466)->dbl == 0.0){
            DeRef(_12466);
            _12466 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_12466);
        _12466 = NOVALUE;
    }
    DeRef(_12466);
    _12466 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_21603;
    if (IS_ATOM_INT(_x_21603)) {
        _x_21603 = _x_21603 - _58MIN2B_21586;
        if ((long)((unsigned long)_x_21603 +(unsigned long) HIGH_BITS) >= 0){
            _x_21603 = NewDouble((double)_x_21603);
        }
    }
    else {
        _x_21603 = binary_op(MINUS, _x_21603, _58MIN2B_21586);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_21603)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21603 & (unsigned long)255;
             _12468 = MAKE_UINT(tu);
        }
    }
    else {
        _12468 = binary_op(AND_BITS, _x_21603, 255);
    }
    if (IS_ATOM_INT(_x_21603)) {
        if (256 > 0 && _x_21603 >= 0) {
            _12469 = _x_21603 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21603 / (double)256);
            if (_x_21603 != MININT)
            _12469 = (long)temp_dbl;
            else
            _12469 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21603, 256);
        _12469 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12468;
    *((int *)(_2+12)) = _12469;
    _12470 = MAKE_SEQ(_1);
    _12469 = NOVALUE;
    _12468 = NOVALUE;
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    return _12470;
    goto L3; // [94] 319
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21603)) {
        _12471 = (_x_21603 >= _58MIN3B_21592);
    }
    else {
        _12471 = binary_op(GREATEREQ, _x_21603, _58MIN3B_21592);
    }
    if (IS_ATOM_INT(_12471)) {
        if (_12471 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_12471)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_21603)) {
        _12473 = (_x_21603 <= 8388607);
    }
    else {
        _12473 = binary_op(LESSEQ, _x_21603, 8388607);
    }
    if (_12473 == 0) {
        DeRef(_12473);
        _12473 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_12473) && DBL_PTR(_12473)->dbl == 0.0){
            DeRef(_12473);
            _12473 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_12473);
        _12473 = NOVALUE;
    }
    DeRef(_12473);
    _12473 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_21603;
    if (IS_ATOM_INT(_x_21603)) {
        _x_21603 = _x_21603 - _58MIN3B_21592;
        if ((long)((unsigned long)_x_21603 +(unsigned long) HIGH_BITS) >= 0){
            _x_21603 = NewDouble((double)_x_21603);
        }
    }
    else {
        _x_21603 = binary_op(MINUS, _x_21603, _58MIN3B_21592);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_21603)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21603 & (unsigned long)255;
             _12475 = MAKE_UINT(tu);
        }
    }
    else {
        _12475 = binary_op(AND_BITS, _x_21603, 255);
    }
    if (IS_ATOM_INT(_x_21603)) {
        if (256 > 0 && _x_21603 >= 0) {
            _12476 = _x_21603 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21603 / (double)256);
            if (_x_21603 != MININT)
            _12476 = (long)temp_dbl;
            else
            _12476 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21603, 256);
        _12476 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12476)) {
        {unsigned long tu;
             tu = (unsigned long)_12476 & (unsigned long)255;
             _12477 = MAKE_UINT(tu);
        }
    }
    else {
        _12477 = binary_op(AND_BITS, _12476, 255);
    }
    DeRef(_12476);
    _12476 = NOVALUE;
    if (IS_ATOM_INT(_x_21603)) {
        if (65536 > 0 && _x_21603 >= 0) {
            _12478 = _x_21603 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21603 / (double)65536);
            if (_x_21603 != MININT)
            _12478 = (long)temp_dbl;
            else
            _12478 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21603, 65536);
        _12478 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12475;
    *((int *)(_2+12)) = _12477;
    *((int *)(_2+16)) = _12478;
    _12479 = MAKE_SEQ(_1);
    _12478 = NOVALUE;
    _12477 = NOVALUE;
    _12475 = NOVALUE;
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12471);
    _12471 = NOVALUE;
    return _12479;
    goto L3; // [156] 319
L5: 

    /** 			return I4B & int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_21603) && IS_ATOM_INT(_58MIN4B_21598)) {
        _12480 = _x_21603 - _58MIN4B_21598;
        if ((long)((unsigned long)_12480 +(unsigned long) HIGH_BITS) >= 0){
            _12480 = NewDouble((double)_12480);
        }
    }
    else {
        _12480 = binary_op(MINUS, _x_21603, _58MIN4B_21598);
    }
    _12481 = _19int_to_bytes(_12480);
    _12480 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12481)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12481)) {
        Prepend(&_12482, _12481, 251);
    }
    else {
        Concat((object_ptr)&_12482, 251, _12481);
    }
    DeRef(_12481);
    _12481 = NOVALUE;
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12471);
    _12471 = NOVALUE;
    DeRef(_12479);
    _12479 = NOVALUE;
    return _12482;
    goto L3; // [180] 319
L1: 

    /** 	elsif atom(x) then*/
    _12483 = IS_ATOM(_x_21603);
    if (_12483 == 0)
    {
        _12483 = NOVALUE;
        goto L6; // [188] 240
    }
    else{
        _12483 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21603);
    _0 = _x4_21604;
    _x4_21604 = _19atom_to_float32(_x_21603);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21604);
    _12485 = _19float32_to_atom(_x4_21604);
    if (binary_op_a(NOTEQ, _x_21603, _12485)){
        DeRef(_12485);
        _12485 = NOVALUE;
        goto L7; // [205] 222
    }
    DeRef(_12485);
    _12485 = NOVALUE;

    /** 			return F4B & x4*/
    Prepend(&_12487, _x4_21604, 252);
    DeRef(_x_21603);
    DeRefDS(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12471);
    _12471 = NOVALUE;
    DeRef(_12479);
    _12479 = NOVALUE;
    DeRef(_12482);
    _12482 = NOVALUE;
    return _12487;
    goto L3; // [219] 319
L7: 

    /** 			return F8B & atom_to_float64(x)*/
    Ref(_x_21603);
    _12488 = _19atom_to_float64(_x_21603);
    if (IS_SEQUENCE(253) && IS_ATOM(_12488)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12488)) {
        Prepend(&_12489, _12488, 253);
    }
    else {
        Concat((object_ptr)&_12489, 253, _12488);
    }
    DeRef(_12488);
    _12488 = NOVALUE;
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_s_21605);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12471);
    _12471 = NOVALUE;
    DeRef(_12479);
    _12479 = NOVALUE;
    DeRef(_12482);
    _12482 = NOVALUE;
    DeRef(_12487);
    _12487 = NOVALUE;
    return _12489;
    goto L3; // [237] 319
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21603)){
            _12490 = SEQ_PTR(_x_21603)->length;
    }
    else {
        _12490 = 1;
    }
    if (_12490 > 255)
    goto L8; // [245] 261

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21603)){
            _12492 = SEQ_PTR(_x_21603)->length;
    }
    else {
        _12492 = 1;
    }
    DeRef(_s_21605);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12492;
    _s_21605 = MAKE_SEQ(_1);
    _12492 = NOVALUE;
    goto L9; // [258] 275
L8: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21603)){
            _12494 = SEQ_PTR(_x_21603)->length;
    }
    else {
        _12494 = 1;
    }
    _12495 = _19int_to_bytes(_12494);
    _12494 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12495)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12495)) {
        Prepend(&_s_21605, _12495, 255);
    }
    else {
        Concat((object_ptr)&_s_21605, 255, _12495);
    }
    DeRef(_12495);
    _12495 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21603)){
            _12497 = SEQ_PTR(_x_21603)->length;
    }
    else {
        _12497 = 1;
    }
    {
        int _i_21662;
        _i_21662 = 1;
LA: 
        if (_i_21662 > _12497){
            goto LB; // [280] 310
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_21603);
        _12498 = (int)*(((s1_ptr)_2)->base + _i_21662);
        Ref(_12498);
        _12499 = _58compress(_12498);
        _12498 = NOVALUE;
        if (IS_SEQUENCE(_s_21605) && IS_ATOM(_12499)) {
            Ref(_12499);
            Append(&_s_21605, _s_21605, _12499);
        }
        else if (IS_ATOM(_s_21605) && IS_SEQUENCE(_12499)) {
        }
        else {
            Concat((object_ptr)&_s_21605, _s_21605, _12499);
        }
        DeRef(_12499);
        _12499 = NOVALUE;

        /** 		end for*/
        _i_21662 = _i_21662 + 1;
        goto LA; // [305] 287
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_21603);
    DeRef(_x4_21604);
    DeRef(_12459);
    _12459 = NOVALUE;
    DeRef(_12463);
    _12463 = NOVALUE;
    DeRef(_12464);
    _12464 = NOVALUE;
    DeRef(_12470);
    _12470 = NOVALUE;
    DeRef(_12471);
    _12471 = NOVALUE;
    DeRef(_12479);
    _12479 = NOVALUE;
    DeRef(_12482);
    _12482 = NOVALUE;
    DeRef(_12487);
    _12487 = NOVALUE;
    DeRef(_12489);
    _12489 = NOVALUE;
    return _s_21605;
L3: 
    ;
}


void _58init_compress()
{
    int _0, _1, _2;
    

    /** 	comp_cache = repeat({}, COMP_CACHE_SIZE)*/
    DeRef(_58comp_cache_21673);
    _58comp_cache_21673 = Repeat(_5, 64);

    /** end procedure*/
    return;
    ;
}


void _58fcompress(int _f_21679, int _x_21680)
{
    int _x4_21681 = NOVALUE;
    int _s_21682 = NOVALUE;
    int _p_21683 = NOVALUE;
    int _12551 = NOVALUE;
    int _12550 = NOVALUE;
    int _12549 = NOVALUE;
    int _12547 = NOVALUE;
    int _12546 = NOVALUE;
    int _12544 = NOVALUE;
    int _12542 = NOVALUE;
    int _12541 = NOVALUE;
    int _12540 = NOVALUE;
    int _12539 = NOVALUE;
    int _12537 = NOVALUE;
    int _12535 = NOVALUE;
    int _12534 = NOVALUE;
    int _12533 = NOVALUE;
    int _12532 = NOVALUE;
    int _12531 = NOVALUE;
    int _12530 = NOVALUE;
    int _12529 = NOVALUE;
    int _12528 = NOVALUE;
    int _12527 = NOVALUE;
    int _12525 = NOVALUE;
    int _12524 = NOVALUE;
    int _12523 = NOVALUE;
    int _12522 = NOVALUE;
    int _12521 = NOVALUE;
    int _12520 = NOVALUE;
    int _12518 = NOVALUE;
    int _12517 = NOVALUE;
    int _12516 = NOVALUE;
    int _12515 = NOVALUE;
    int _12514 = NOVALUE;
    int _12513 = NOVALUE;
    int _12511 = NOVALUE;
    int _12510 = NOVALUE;
    int _12509 = NOVALUE;
    int _12508 = NOVALUE;
    int _12507 = NOVALUE;
    int _12506 = NOVALUE;
    int _12505 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_f_21679)) {
        _1 = (long)(DBL_PTR(_f_21679)->dbl);
        DeRefDS(_f_21679);
        _f_21679 = _1;
    }

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_21680))
    _12505 = 1;
    else if (IS_ATOM_DBL(_x_21680))
    _12505 = IS_ATOM_INT(DoubleToInt(_x_21680));
    else
    _12505 = 0;
    if (_12505 == 0)
    {
        _12505 = NOVALUE;
        goto L1; // [8] 232
    }
    else{
        _12505 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= max1b then*/
    if (IS_ATOM_INT(_x_21680)) {
        _12506 = (_x_21680 >= -2);
    }
    else {
        _12506 = binary_op(GREATEREQ, _x_21680, -2);
    }
    if (IS_ATOM_INT(_12506)) {
        if (_12506 == 0) {
            goto L2; // [17] 43
        }
    }
    else {
        if (DBL_PTR(_12506)->dbl == 0.0) {
            goto L2; // [17] 43
        }
    }
    if (IS_ATOM_INT(_x_21680)) {
        _12508 = (_x_21680 <= 182);
    }
    else {
        _12508 = binary_op(LESSEQ, _x_21680, 182);
    }
    if (_12508 == 0) {
        DeRef(_12508);
        _12508 = NOVALUE;
        goto L2; // [28] 43
    }
    else {
        if (!IS_ATOM_INT(_12508) && DBL_PTR(_12508)->dbl == 0.0){
            DeRef(_12508);
            _12508 = NOVALUE;
            goto L2; // [28] 43
        }
        DeRef(_12508);
        _12508 = NOVALUE;
    }
    DeRef(_12508);
    _12508 = NOVALUE;

    /** 			puts(f, x - MIN1B) -- normal, quite small integer*/
    if (IS_ATOM_INT(_x_21680)) {
        _12509 = _x_21680 - -2;
        if ((long)((unsigned long)_12509 +(unsigned long) HIGH_BITS) >= 0){
            _12509 = NewDouble((double)_12509);
        }
    }
    else {
        _12509 = binary_op(MINUS, _x_21680, -2);
    }
    EPuts(_f_21679, _12509); // DJP 
    DeRef(_12509);
    _12509 = NOVALUE;
    goto L3; // [40] 362
L2: 

    /** 			p = 1 + and_bits(x, COMP_CACHE_SIZE-1)*/
    _12510 = 63;
    if (IS_ATOM_INT(_x_21680)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21680 & (unsigned long)63;
             _12511 = MAKE_UINT(tu);
        }
    }
    else {
        _12511 = binary_op(AND_BITS, _x_21680, 63);
    }
    _12510 = NOVALUE;
    if (IS_ATOM_INT(_12511)) {
        _p_21683 = _12511 + 1;
    }
    else
    { // coercing _p_21683 to an integer 1
        _p_21683 = 1+(long)(DBL_PTR(_12511)->dbl);
        if( !IS_ATOM_INT(_p_21683) ){
            _p_21683 = (object)DBL_PTR(_p_21683)->dbl;
        }
    }
    DeRef(_12511);
    _12511 = NOVALUE;

    /** 			if equal(comp_cache[p], x) then*/
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    _12513 = (int)*(((s1_ptr)_2)->base + _p_21683);
    if (_12513 == _x_21680)
    _12514 = 1;
    else if (IS_ATOM_INT(_12513) && IS_ATOM_INT(_x_21680))
    _12514 = 0;
    else
    _12514 = (compare(_12513, _x_21680) == 0);
    _12513 = NOVALUE;
    if (_12514 == 0)
    {
        _12514 = NOVALUE;
        goto L4; // [69] 86
    }
    else{
        _12514 = NOVALUE;
    }

    /** 				puts(f, CACHE0 + p) -- output the cache slot number*/
    _12515 = 184 + _p_21683;
    if ((long)((unsigned long)_12515 + (unsigned long)HIGH_BITS) >= 0) 
    _12515 = NewDouble((double)_12515);
    EPuts(_f_21679, _12515); // DJP 
    DeRef(_12515);
    _12515 = NOVALUE;
    goto L3; // [83] 362
L4: 

    /** 				comp_cache[p] = x -- store it in cache slot p*/
    Ref(_x_21680);
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    _2 = (int)(((s1_ptr)_2)->base + _p_21683);
    _1 = *(int *)_2;
    *(int *)_2 = _x_21680;
    DeRef(_1);

    /** 				if x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_21680)) {
        _12516 = (_x_21680 >= _58MIN2B_21586);
    }
    else {
        _12516 = binary_op(GREATEREQ, _x_21680, _58MIN2B_21586);
    }
    if (IS_ATOM_INT(_12516)) {
        if (_12516 == 0) {
            goto L5; // [102] 146
        }
    }
    else {
        if (DBL_PTR(_12516)->dbl == 0.0) {
            goto L5; // [102] 146
        }
    }
    if (IS_ATOM_INT(_x_21680)) {
        _12518 = (_x_21680 <= 32767);
    }
    else {
        _12518 = binary_op(LESSEQ, _x_21680, 32767);
    }
    if (_12518 == 0) {
        DeRef(_12518);
        _12518 = NOVALUE;
        goto L5; // [113] 146
    }
    else {
        if (!IS_ATOM_INT(_12518) && DBL_PTR(_12518)->dbl == 0.0){
            DeRef(_12518);
            _12518 = NOVALUE;
            goto L5; // [113] 146
        }
        DeRef(_12518);
        _12518 = NOVALUE;
    }
    DeRef(_12518);
    _12518 = NOVALUE;

    /** 					x -= MIN2B*/
    _0 = _x_21680;
    if (IS_ATOM_INT(_x_21680)) {
        _x_21680 = _x_21680 - _58MIN2B_21586;
        if ((long)((unsigned long)_x_21680 +(unsigned long) HIGH_BITS) >= 0){
            _x_21680 = NewDouble((double)_x_21680);
        }
    }
    else {
        _x_21680 = binary_op(MINUS, _x_21680, _58MIN2B_21586);
    }
    DeRef(_0);

    /** 					puts(f, {I2B, and_bits(x, #FF), floor(x / #100)})*/
    if (IS_ATOM_INT(_x_21680)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21680 & (unsigned long)255;
             _12520 = MAKE_UINT(tu);
        }
    }
    else {
        _12520 = binary_op(AND_BITS, _x_21680, 255);
    }
    if (IS_ATOM_INT(_x_21680)) {
        if (256 > 0 && _x_21680 >= 0) {
            _12521 = _x_21680 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21680 / (double)256);
            if (_x_21680 != MININT)
            _12521 = (long)temp_dbl;
            else
            _12521 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21680, 256);
        _12521 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _12520;
    *((int *)(_2+12)) = _12521;
    _12522 = MAKE_SEQ(_1);
    _12521 = NOVALUE;
    _12520 = NOVALUE;
    EPuts(_f_21679, _12522); // DJP 
    DeRefDS(_12522);
    _12522 = NOVALUE;
    goto L3; // [143] 362
L5: 

    /** 				elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_21680)) {
        _12523 = (_x_21680 >= _58MIN3B_21592);
    }
    else {
        _12523 = binary_op(GREATEREQ, _x_21680, _58MIN3B_21592);
    }
    if (IS_ATOM_INT(_12523)) {
        if (_12523 == 0) {
            goto L6; // [154] 207
        }
    }
    else {
        if (DBL_PTR(_12523)->dbl == 0.0) {
            goto L6; // [154] 207
        }
    }
    if (IS_ATOM_INT(_x_21680)) {
        _12525 = (_x_21680 <= 8388607);
    }
    else {
        _12525 = binary_op(LESSEQ, _x_21680, 8388607);
    }
    if (_12525 == 0) {
        DeRef(_12525);
        _12525 = NOVALUE;
        goto L6; // [165] 207
    }
    else {
        if (!IS_ATOM_INT(_12525) && DBL_PTR(_12525)->dbl == 0.0){
            DeRef(_12525);
            _12525 = NOVALUE;
            goto L6; // [165] 207
        }
        DeRef(_12525);
        _12525 = NOVALUE;
    }
    DeRef(_12525);
    _12525 = NOVALUE;

    /** 					x -= MIN3B*/
    _0 = _x_21680;
    if (IS_ATOM_INT(_x_21680)) {
        _x_21680 = _x_21680 - _58MIN3B_21592;
        if ((long)((unsigned long)_x_21680 +(unsigned long) HIGH_BITS) >= 0){
            _x_21680 = NewDouble((double)_x_21680);
        }
    }
    else {
        _x_21680 = binary_op(MINUS, _x_21680, _58MIN3B_21592);
    }
    DeRef(_0);

    /** 					puts(f, {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)})*/
    if (IS_ATOM_INT(_x_21680)) {
        {unsigned long tu;
             tu = (unsigned long)_x_21680 & (unsigned long)255;
             _12527 = MAKE_UINT(tu);
        }
    }
    else {
        _12527 = binary_op(AND_BITS, _x_21680, 255);
    }
    if (IS_ATOM_INT(_x_21680)) {
        if (256 > 0 && _x_21680 >= 0) {
            _12528 = _x_21680 / 256;
        }
        else {
            temp_dbl = floor((double)_x_21680 / (double)256);
            if (_x_21680 != MININT)
            _12528 = (long)temp_dbl;
            else
            _12528 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21680, 256);
        _12528 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_12528)) {
        {unsigned long tu;
             tu = (unsigned long)_12528 & (unsigned long)255;
             _12529 = MAKE_UINT(tu);
        }
    }
    else {
        _12529 = binary_op(AND_BITS, _12528, 255);
    }
    DeRef(_12528);
    _12528 = NOVALUE;
    if (IS_ATOM_INT(_x_21680)) {
        if (65536 > 0 && _x_21680 >= 0) {
            _12530 = _x_21680 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_21680 / (double)65536);
            if (_x_21680 != MININT)
            _12530 = (long)temp_dbl;
            else
            _12530 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_21680, 65536);
        _12530 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _12527;
    *((int *)(_2+12)) = _12529;
    *((int *)(_2+16)) = _12530;
    _12531 = MAKE_SEQ(_1);
    _12530 = NOVALUE;
    _12529 = NOVALUE;
    _12527 = NOVALUE;
    EPuts(_f_21679, _12531); // DJP 
    DeRefDS(_12531);
    _12531 = NOVALUE;
    goto L3; // [204] 362
L6: 

    /** 					puts(f, I4B & int_to_bytes(x-MIN4B))*/
    if (IS_ATOM_INT(_x_21680) && IS_ATOM_INT(_58MIN4B_21598)) {
        _12532 = _x_21680 - _58MIN4B_21598;
        if ((long)((unsigned long)_12532 +(unsigned long) HIGH_BITS) >= 0){
            _12532 = NewDouble((double)_12532);
        }
    }
    else {
        _12532 = binary_op(MINUS, _x_21680, _58MIN4B_21598);
    }
    _12533 = _19int_to_bytes(_12532);
    _12532 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_12533)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_12533)) {
        Prepend(&_12534, _12533, 251);
    }
    else {
        Concat((object_ptr)&_12534, 251, _12533);
    }
    DeRef(_12533);
    _12533 = NOVALUE;
    EPuts(_f_21679, _12534); // DJP 
    DeRefDS(_12534);
    _12534 = NOVALUE;
    goto L3; // [229] 362
L1: 

    /** 	elsif atom(x) then*/
    _12535 = IS_ATOM(_x_21680);
    if (_12535 == 0)
    {
        _12535 = NOVALUE;
        goto L7; // [237] 287
    }
    else{
        _12535 = NOVALUE;
    }

    /** 		x4 = atom_to_float32(x)*/
    Ref(_x_21680);
    _0 = _x4_21681;
    _x4_21681 = _19atom_to_float32(_x_21680);
    DeRef(_0);

    /** 		if x = float32_to_atom(x4) then*/
    RefDS(_x4_21681);
    _12537 = _19float32_to_atom(_x4_21681);
    if (binary_op_a(NOTEQ, _x_21680, _12537)){
        DeRef(_12537);
        _12537 = NOVALUE;
        goto L8; // [254] 270
    }
    DeRef(_12537);
    _12537 = NOVALUE;

    /** 			puts(f, F4B & x4)*/
    Prepend(&_12539, _x4_21681, 252);
    EPuts(_f_21679, _12539); // DJP 
    DeRefDS(_12539);
    _12539 = NOVALUE;
    goto L3; // [267] 362
L8: 

    /** 			puts(f, F8B & atom_to_float64(x))*/
    Ref(_x_21680);
    _12540 = _19atom_to_float64(_x_21680);
    if (IS_SEQUENCE(253) && IS_ATOM(_12540)) {
    }
    else if (IS_ATOM(253) && IS_SEQUENCE(_12540)) {
        Prepend(&_12541, _12540, 253);
    }
    else {
        Concat((object_ptr)&_12541, 253, _12540);
    }
    DeRef(_12540);
    _12540 = NOVALUE;
    EPuts(_f_21679, _12541); // DJP 
    DeRefDS(_12541);
    _12541 = NOVALUE;
    goto L3; // [284] 362
L7: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_21680)){
            _12542 = SEQ_PTR(_x_21680)->length;
    }
    else {
        _12542 = 1;
    }
    if (_12542 > 255)
    goto L9; // [292] 308

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_21680)){
            _12544 = SEQ_PTR(_x_21680)->length;
    }
    else {
        _12544 = 1;
    }
    DeRef(_s_21682);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _12544;
    _s_21682 = MAKE_SEQ(_1);
    _12544 = NOVALUE;
    goto LA; // [305] 322
L9: 

    /** 			s = S4B & int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_21680)){
            _12546 = SEQ_PTR(_x_21680)->length;
    }
    else {
        _12546 = 1;
    }
    _12547 = _19int_to_bytes(_12546);
    _12546 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_12547)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_12547)) {
        Prepend(&_s_21682, _12547, 255);
    }
    else {
        Concat((object_ptr)&_s_21682, 255, _12547);
    }
    DeRef(_12547);
    _12547 = NOVALUE;
LA: 

    /** 		puts(f, s)*/
    EPuts(_f_21679, _s_21682); // DJP 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_21680)){
            _12549 = SEQ_PTR(_x_21680)->length;
    }
    else {
        _12549 = 1;
    }
    {
        int _i_21748;
        _i_21748 = 1;
LB: 
        if (_i_21748 > _12549){
            goto LC; // [334] 361
        }

        /** 			fcompress(f, x[i])*/
        _2 = (int)SEQ_PTR(_x_21680);
        _12550 = (int)*(((s1_ptr)_2)->base + _i_21748);
        DeRef(_12551);
        _12551 = _f_21679;
        Ref(_12550);
        _58fcompress(_12551, _12550);
        _12551 = NOVALUE;
        _12550 = NOVALUE;

        /** 		end for*/
        _i_21748 = _i_21748 + 1;
        goto LB; // [356] 341
LC: 
        ;
    }
L3: 

    /** end procedure*/
    DeRef(_x_21680);
    DeRef(_x4_21681);
    DeRef(_s_21682);
    DeRef(_12506);
    _12506 = NOVALUE;
    DeRef(_12516);
    _12516 = NOVALUE;
    DeRef(_12523);
    _12523 = NOVALUE;
    return;
    ;
}


int _58get4()
{
    int _12560 = NOVALUE;
    int _12559 = NOVALUE;
    int _12558 = NOVALUE;
    int _12557 = NOVALUE;
    int _12556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12556 = getc((FILE*)xstdin);
        }
        else
        _12556 = getc(last_r_file_ptr);
    }
    else
    _12556 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem0_21753)){
        poke_addr = (unsigned char *)_58mem0_21753;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem0_21753)->dbl);
    }
    *poke_addr = (unsigned char)_12556;
    _12556 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12557 = getc((FILE*)xstdin);
        }
        else
        _12557 = getc(last_r_file_ptr);
    }
    else
    _12557 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem1_21754)){
        poke_addr = (unsigned char *)_58mem1_21754;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem1_21754)->dbl);
    }
    *poke_addr = (unsigned char)_12557;
    _12557 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12558 = getc((FILE*)xstdin);
        }
        else
        _12558 = getc(last_r_file_ptr);
    }
    else
    _12558 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem2_21755)){
        poke_addr = (unsigned char *)_58mem2_21755;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem2_21755)->dbl);
    }
    *poke_addr = (unsigned char)_12558;
    _12558 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12559 = getc((FILE*)xstdin);
        }
        else
        _12559 = getc(last_r_file_ptr);
    }
    else
    _12559 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_58mem3_21756)){
        poke_addr = (unsigned char *)_58mem3_21756;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_58mem3_21756)->dbl);
    }
    *poke_addr = (unsigned char)_12559;
    _12559 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_58mem0_21753)) {
        _12560 = *(unsigned long *)_58mem0_21753;
        if ((unsigned)_12560 > (unsigned)MAXINT)
        _12560 = NewDouble((double)(unsigned long)_12560);
    }
    else {
        _12560 = *(unsigned long *)(unsigned long)(DBL_PTR(_58mem0_21753)->dbl);
        if ((unsigned)_12560 > (unsigned)MAXINT)
        _12560 = NewDouble((double)(unsigned long)_12560);
    }
    return _12560;
    ;
}


int _58fdecompress(int _c_21771)
{
    int _s_21772 = NOVALUE;
    int _len_21773 = NOVALUE;
    int _ival_21774 = NOVALUE;
    int _12628 = NOVALUE;
    int _12627 = NOVALUE;
    int _12626 = NOVALUE;
    int _12625 = NOVALUE;
    int _12623 = NOVALUE;
    int _12622 = NOVALUE;
    int _12618 = NOVALUE;
    int _12613 = NOVALUE;
    int _12612 = NOVALUE;
    int _12611 = NOVALUE;
    int _12610 = NOVALUE;
    int _12609 = NOVALUE;
    int _12608 = NOVALUE;
    int _12607 = NOVALUE;
    int _12606 = NOVALUE;
    int _12605 = NOVALUE;
    int _12604 = NOVALUE;
    int _12602 = NOVALUE;
    int _12601 = NOVALUE;
    int _12600 = NOVALUE;
    int _12599 = NOVALUE;
    int _12598 = NOVALUE;
    int _12597 = NOVALUE;
    int _12595 = NOVALUE;
    int _12594 = NOVALUE;
    int _12593 = NOVALUE;
    int _12591 = NOVALUE;
    int _12589 = NOVALUE;
    int _12588 = NOVALUE;
    int _12587 = NOVALUE;
    int _12585 = NOVALUE;
    int _12584 = NOVALUE;
    int _12583 = NOVALUE;
    int _12582 = NOVALUE;
    int _12581 = NOVALUE;
    int _12580 = NOVALUE;
    int _12579 = NOVALUE;
    int _12577 = NOVALUE;
    int _12576 = NOVALUE;
    int _12575 = NOVALUE;
    int _12573 = NOVALUE;
    int _12572 = NOVALUE;
    int _12571 = NOVALUE;
    int _12570 = NOVALUE;
    int _12568 = NOVALUE;
    int _12567 = NOVALUE;
    int _12565 = NOVALUE;
    int _12564 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_c_21771)) {
        _1 = (long)(DBL_PTR(_c_21771)->dbl);
        DeRefDS(_c_21771);
        _c_21771 = _1;
    }

    /** 	if c = 0 then*/
    if (_c_21771 != 0)
    goto L1; // [5] 70

    /** 		c = getc(current_db)*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_21771 = getc((FILE*)xstdin);
        }
        else
        _c_21771 = getc(last_r_file_ptr);
    }
    else
    _c_21771 = getc(last_r_file_ptr);

    /** 		if c <= CACHE0 then*/
    if (_c_21771 > 184)
    goto L2; // [20] 37

    /** 			return c + MIN1B  -- a normal, quite small integer*/
    _12564 = _c_21771 + -2;
    DeRef(_s_21772);
    return _12564;
    goto L3; // [34] 69
L2: 

    /** 		elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
    _12565 = 248;
    if (_c_21771 > 248)
    goto L4; // [45] 68

    /** 			return comp_cache[c-CACHE0]*/
    _12567 = _c_21771 - 184;
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    _12568 = (int)*(((s1_ptr)_2)->base + _12567);
    Ref(_12568);
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    _12565 = NOVALUE;
    _12567 = NOVALUE;
    return _12568;
L4: 
L3: 
L1: 

    /** 	if c = I2B then*/
    if (_c_21771 != 249)
    goto L5; // [72] 133

    /** 		ival = getc(current_db) +*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12570 = getc((FILE*)xstdin);
        }
        else
        _12570 = getc(last_r_file_ptr);
    }
    else
    _12570 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12571 = getc((FILE*)xstdin);
        }
        else
        _12571 = getc(last_r_file_ptr);
    }
    else
    _12571 = getc(last_r_file_ptr);
    _12572 = 256 * _12571;
    _12571 = NOVALUE;
    _12573 = _12570 + _12572;
    _12570 = NOVALUE;
    _12572 = NOVALUE;
    _ival_21774 = _12573 + _58MIN2B_21586;
    _12573 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12575 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21774 & (unsigned long)63;
         _12576 = MAKE_UINT(tu);
    }
    _12575 = NOVALUE;
    if (IS_ATOM_INT(_12576)) {
        _12577 = _12576 + 1;
    }
    else
    _12577 = binary_op(PLUS, 1, _12576);
    DeRef(_12576);
    _12576 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    if (!IS_ATOM_INT(_12577))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12577)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12577);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21774;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    return _ival_21774;
    goto L6; // [130] 514
L5: 

    /** 	elsif c = I3B then*/
    if (_c_21771 != 250)
    goto L7; // [135] 209

    /** 		ival = getc(current_db) +*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12579 = getc((FILE*)xstdin);
        }
        else
        _12579 = getc(last_r_file_ptr);
    }
    else
    _12579 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12580 = getc((FILE*)xstdin);
        }
        else
        _12580 = getc(last_r_file_ptr);
    }
    else
    _12580 = getc(last_r_file_ptr);
    _12581 = 256 * _12580;
    _12580 = NOVALUE;
    _12582 = _12579 + _12581;
    _12579 = NOVALUE;
    _12581 = NOVALUE;
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12583 = getc((FILE*)xstdin);
        }
        else
        _12583 = getc(last_r_file_ptr);
    }
    else
    _12583 = getc(last_r_file_ptr);
    _12584 = 65536 * _12583;
    _12583 = NOVALUE;
    _12585 = _12582 + _12584;
    _12582 = NOVALUE;
    _12584 = NOVALUE;
    _ival_21774 = _12585 + _58MIN3B_21592;
    _12585 = NOVALUE;

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12587 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21774 & (unsigned long)63;
         _12588 = MAKE_UINT(tu);
    }
    _12587 = NOVALUE;
    if (IS_ATOM_INT(_12588)) {
        _12589 = _12588 + 1;
    }
    else
    _12589 = binary_op(PLUS, 1, _12588);
    DeRef(_12588);
    _12588 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    if (!IS_ATOM_INT(_12589))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12589)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12589);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21774;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    DeRef(_12589);
    _12589 = NOVALUE;
    return _ival_21774;
    goto L6; // [206] 514
L7: 

    /** 	elsif c = I4B  then*/
    if (_c_21771 != 251)
    goto L8; // [211] 257

    /** 		ival = get4() + MIN4B*/
    _12591 = _58get4();
    if (IS_ATOM_INT(_12591) && IS_ATOM_INT(_58MIN4B_21598)) {
        _ival_21774 = _12591 + _58MIN4B_21598;
    }
    else {
        _ival_21774 = binary_op(PLUS, _12591, _58MIN4B_21598);
    }
    DeRef(_12591);
    _12591 = NOVALUE;
    if (!IS_ATOM_INT(_ival_21774)) {
        _1 = (long)(DBL_PTR(_ival_21774)->dbl);
        DeRefDS(_ival_21774);
        _ival_21774 = _1;
    }

    /** 		comp_cache[1 + and_bits(ival, COMP_CACHE_SIZE-1)] = ival*/
    _12593 = 63;
    {unsigned long tu;
         tu = (unsigned long)_ival_21774 & (unsigned long)63;
         _12594 = MAKE_UINT(tu);
    }
    _12593 = NOVALUE;
    if (IS_ATOM_INT(_12594)) {
        _12595 = _12594 + 1;
    }
    else
    _12595 = binary_op(PLUS, 1, _12594);
    DeRef(_12594);
    _12594 = NOVALUE;
    _2 = (int)SEQ_PTR(_58comp_cache_21673);
    if (!IS_ATOM_INT(_12595))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12595)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12595);
    _1 = *(int *)_2;
    *(int *)_2 = _ival_21774;
    DeRef(_1);

    /** 		return ival*/
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    DeRef(_12589);
    _12589 = NOVALUE;
    DeRef(_12595);
    _12595 = NOVALUE;
    return _ival_21774;
    goto L6; // [254] 514
L8: 

    /** 	elsif c = F4B then*/
    if (_c_21771 != 252)
    goto L9; // [259] 303

    /** 		return float32_to_atom({getc(current_db), getc(current_db),*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12597 = getc((FILE*)xstdin);
        }
        else
        _12597 = getc(last_r_file_ptr);
    }
    else
    _12597 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12598 = getc((FILE*)xstdin);
        }
        else
        _12598 = getc(last_r_file_ptr);
    }
    else
    _12598 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12599 = getc((FILE*)xstdin);
        }
        else
        _12599 = getc(last_r_file_ptr);
    }
    else
    _12599 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12600 = getc((FILE*)xstdin);
        }
        else
        _12600 = getc(last_r_file_ptr);
    }
    else
    _12600 = getc(last_r_file_ptr);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12597;
    *((int *)(_2+8)) = _12598;
    *((int *)(_2+12)) = _12599;
    *((int *)(_2+16)) = _12600;
    _12601 = MAKE_SEQ(_1);
    _12600 = NOVALUE;
    _12599 = NOVALUE;
    _12598 = NOVALUE;
    _12597 = NOVALUE;
    _12602 = _19float32_to_atom(_12601);
    _12601 = NOVALUE;
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    DeRef(_12589);
    _12589 = NOVALUE;
    DeRef(_12595);
    _12595 = NOVALUE;
    return _12602;
    goto L6; // [300] 514
L9: 

    /** 	elsif c = F8B then*/
    if (_c_21771 != 253)
    goto LA; // [305] 373

    /** 		return float64_to_atom({getc(current_db), getc(current_db),*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12604 = getc((FILE*)xstdin);
        }
        else
        _12604 = getc(last_r_file_ptr);
    }
    else
    _12604 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12605 = getc((FILE*)xstdin);
        }
        else
        _12605 = getc(last_r_file_ptr);
    }
    else
    _12605 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12606 = getc((FILE*)xstdin);
        }
        else
        _12606 = getc(last_r_file_ptr);
    }
    else
    _12606 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12607 = getc((FILE*)xstdin);
        }
        else
        _12607 = getc(last_r_file_ptr);
    }
    else
    _12607 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12608 = getc((FILE*)xstdin);
        }
        else
        _12608 = getc(last_r_file_ptr);
    }
    else
    _12608 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12609 = getc((FILE*)xstdin);
        }
        else
        _12609 = getc(last_r_file_ptr);
    }
    else
    _12609 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12610 = getc((FILE*)xstdin);
        }
        else
        _12610 = getc(last_r_file_ptr);
    }
    else
    _12610 = getc(last_r_file_ptr);
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _12611 = getc((FILE*)xstdin);
        }
        else
        _12611 = getc(last_r_file_ptr);
    }
    else
    _12611 = getc(last_r_file_ptr);
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _12604;
    *((int *)(_2+8)) = _12605;
    *((int *)(_2+12)) = _12606;
    *((int *)(_2+16)) = _12607;
    *((int *)(_2+20)) = _12608;
    *((int *)(_2+24)) = _12609;
    *((int *)(_2+28)) = _12610;
    *((int *)(_2+32)) = _12611;
    _12612 = MAKE_SEQ(_1);
    _12611 = NOVALUE;
    _12610 = NOVALUE;
    _12609 = NOVALUE;
    _12608 = NOVALUE;
    _12607 = NOVALUE;
    _12606 = NOVALUE;
    _12605 = NOVALUE;
    _12604 = NOVALUE;
    _12613 = _19float64_to_atom(_12612);
    _12612 = NOVALUE;
    DeRef(_s_21772);
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    DeRef(_12589);
    _12589 = NOVALUE;
    DeRef(_12595);
    _12595 = NOVALUE;
    DeRef(_12602);
    _12602 = NOVALUE;
    return _12613;
    goto L6; // [370] 514
LA: 

    /** 		if c = S1B then*/
    if (_c_21771 != 254)
    goto LB; // [375] 389

    /** 			len = getc(current_db)*/
    if (_58current_db_21761 != last_r_file_no) {
        last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
        last_r_file_no = _58current_db_21761;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _len_21773 = getc((FILE*)xstdin);
        }
        else
        _len_21773 = getc(last_r_file_ptr);
    }
    else
    _len_21773 = getc(last_r_file_ptr);
    goto LC; // [386] 397
LB: 

    /** 			len = get4()*/
    _len_21773 = _58get4();
    if (!IS_ATOM_INT(_len_21773)) {
        _1 = (long)(DBL_PTR(_len_21773)->dbl);
        DeRefDS(_len_21773);
        _len_21773 = _1;
    }
LC: 

    /** 		s = repeat(0, len)*/
    DeRef(_s_21772);
    _s_21772 = Repeat(0, _len_21773);

    /** 		for i = 1 to len do*/
    _12618 = _len_21773;
    {
        int _i_21846;
        _i_21846 = 1;
LD: 
        if (_i_21846 > _12618){
            goto LE; // [410] 507
        }

        /** 			c = getc(current_db)*/
        if (_58current_db_21761 != last_r_file_no) {
            last_r_file_ptr = which_file(_58current_db_21761, EF_READ);
            last_r_file_no = _58current_db_21761;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _c_21771 = getc((FILE*)xstdin);
            }
            else
            _c_21771 = getc(last_r_file_ptr);
        }
        else
        _c_21771 = getc(last_r_file_ptr);

        /** 			if c < I2B then*/
        if (_c_21771 >= 249)
        goto LF; // [426] 486

        /** 				if c <= CACHE0 then*/
        if (_c_21771 > 184)
        goto L10; // [434] 451

        /** 					s[i] = c + MIN1B*/
        _12622 = _c_21771 + -2;
        _2 = (int)SEQ_PTR(_s_21772);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21772 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21846);
        _1 = *(int *)_2;
        *(int *)_2 = _12622;
        if( _1 != _12622 ){
            DeRef(_1);
        }
        _12622 = NOVALUE;
        goto L11; // [448] 500
L10: 

        /** 				elsif c <= CACHE0 + COMP_CACHE_SIZE then*/
        _12623 = 248;
        if (_c_21771 > 248)
        goto L11; // [459] 500

        /** 					s[i] = comp_cache[c - CACHE0]*/
        _12625 = _c_21771 - 184;
        _2 = (int)SEQ_PTR(_58comp_cache_21673);
        _12626 = (int)*(((s1_ptr)_2)->base + _12625);
        Ref(_12626);
        _2 = (int)SEQ_PTR(_s_21772);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21772 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21846);
        _1 = *(int *)_2;
        *(int *)_2 = _12626;
        if( _1 != _12626 ){
            DeRef(_1);
        }
        _12626 = NOVALUE;
        goto L11; // [483] 500
LF: 

        /** 				s[i] = fdecompress(c)*/
        DeRef(_12627);
        _12627 = _c_21771;
        _12628 = _58fdecompress(_12627);
        _12627 = NOVALUE;
        _2 = (int)SEQ_PTR(_s_21772);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _s_21772 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_21846);
        _1 = *(int *)_2;
        *(int *)_2 = _12628;
        if( _1 != _12628 ){
            DeRef(_1);
        }
        _12628 = NOVALUE;
L11: 

        /** 		end for*/
        _i_21846 = _i_21846 + 1;
        goto LD; // [502] 417
LE: 
        ;
    }

    /** 		return s*/
    DeRef(_12564);
    _12564 = NOVALUE;
    DeRef(_12565);
    _12565 = NOVALUE;
    DeRef(_12567);
    _12567 = NOVALUE;
    _12568 = NOVALUE;
    DeRef(_12577);
    _12577 = NOVALUE;
    DeRef(_12589);
    _12589 = NOVALUE;
    DeRef(_12595);
    _12595 = NOVALUE;
    DeRef(_12623);
    _12623 = NOVALUE;
    DeRef(_12602);
    _12602 = NOVALUE;
    DeRef(_12613);
    _12613 = NOVALUE;
    DeRef(_12625);
    _12625 = NOVALUE;
    return _s_21772;
L6: 
    ;
}



// 0x3A768D45
