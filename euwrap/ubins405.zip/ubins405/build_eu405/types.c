// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _9char_test(int _test_data_469, int _char_set_470)
{
    int _lChr_471 = NOVALUE;
    int _129 = NOVALUE;
    int _128 = NOVALUE;
    int _127 = NOVALUE;
    int _126 = NOVALUE;
    int _125 = NOVALUE;
    int _124 = NOVALUE;
    int _123 = NOVALUE;
    int _122 = NOVALUE;
    int _121 = NOVALUE;
    int _120 = NOVALUE;
    int _119 = NOVALUE;
    int _116 = NOVALUE;
    int _115 = NOVALUE;
    int _114 = NOVALUE;
    int _113 = NOVALUE;
    int _111 = NOVALUE;
    int _109 = NOVALUE;
    int _108 = NOVALUE;
    int _107 = NOVALUE;
    int _106 = NOVALUE;
    int _105 = NOVALUE;
    int _104 = NOVALUE;
    int _103 = NOVALUE;
    int _102 = NOVALUE;
    int _101 = NOVALUE;
    int _100 = NOVALUE;
    int _99 = NOVALUE;
    int _98 = NOVALUE;
    int _97 = NOVALUE;
    int _96 = NOVALUE;
    int _95 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(test_data) then*/
    if (IS_ATOM_INT(_test_data_469))
    _95 = 1;
    else if (IS_ATOM_DBL(_test_data_469))
    _95 = IS_ATOM_INT(DoubleToInt(_test_data_469));
    else
    _95 = 0;
    if (_95 == 0)
    {
        _95 = NOVALUE;
        goto L1; // [8] 115
    }
    else{
        _95 = NOVALUE;
    }

    /** 		if sequence(char_set[1]) then*/
    _2 = (int)SEQ_PTR(_char_set_470);
    _96 = (int)*(((s1_ptr)_2)->base + 1);
    _97 = IS_SEQUENCE(_96);
    _96 = NOVALUE;
    if (_97 == 0)
    {
        _97 = NOVALUE;
        goto L2; // [20] 96
    }
    else{
        _97 = NOVALUE;
    }

    /** 			for j = 1 to length(char_set) do*/
    if (IS_SEQUENCE(_char_set_470)){
            _98 = SEQ_PTR(_char_set_470)->length;
    }
    else {
        _98 = 1;
    }
    {
        int _j_478;
        _j_478 = 1;
L3: 
        if (_j_478 > _98){
            goto L4; // [28] 85
        }

        /** 				if test_data >= char_set[j][1] and test_data <= char_set[j][2] then */
        _2 = (int)SEQ_PTR(_char_set_470);
        _99 = (int)*(((s1_ptr)_2)->base + _j_478);
        _2 = (int)SEQ_PTR(_99);
        _100 = (int)*(((s1_ptr)_2)->base + 1);
        _99 = NOVALUE;
        if (IS_ATOM_INT(_test_data_469) && IS_ATOM_INT(_100)) {
            _101 = (_test_data_469 >= _100);
        }
        else {
            _101 = binary_op(GREATEREQ, _test_data_469, _100);
        }
        _100 = NOVALUE;
        if (IS_ATOM_INT(_101)) {
            if (_101 == 0) {
                goto L5; // [49] 78
            }
        }
        else {
            if (DBL_PTR(_101)->dbl == 0.0) {
                goto L5; // [49] 78
            }
        }
        _2 = (int)SEQ_PTR(_char_set_470);
        _103 = (int)*(((s1_ptr)_2)->base + _j_478);
        _2 = (int)SEQ_PTR(_103);
        _104 = (int)*(((s1_ptr)_2)->base + 2);
        _103 = NOVALUE;
        if (IS_ATOM_INT(_test_data_469) && IS_ATOM_INT(_104)) {
            _105 = (_test_data_469 <= _104);
        }
        else {
            _105 = binary_op(LESSEQ, _test_data_469, _104);
        }
        _104 = NOVALUE;
        if (_105 == 0) {
            DeRef(_105);
            _105 = NOVALUE;
            goto L5; // [66] 78
        }
        else {
            if (!IS_ATOM_INT(_105) && DBL_PTR(_105)->dbl == 0.0){
                DeRef(_105);
                _105 = NOVALUE;
                goto L5; // [66] 78
            }
            DeRef(_105);
            _105 = NOVALUE;
        }
        DeRef(_105);
        _105 = NOVALUE;

        /** 					return TRUE */
        DeRef(_test_data_469);
        DeRefDS(_char_set_470);
        DeRef(_101);
        _101 = NOVALUE;
        return _9TRUE_431;
L5: 

        /** 			end for*/
        _j_478 = _j_478 + 1;
        goto L3; // [80] 35
L4: 
        ;
    }

    /** 			return FALSE*/
    DeRef(_test_data_469);
    DeRefDS(_char_set_470);
    DeRef(_101);
    _101 = NOVALUE;
    return _9FALSE_429;
    goto L6; // [93] 328
L2: 

    /** 			return find(test_data, char_set) > 0*/
    _106 = find_from(_test_data_469, _char_set_470, 1);
    _107 = (_106 > 0);
    _106 = NOVALUE;
    DeRef(_test_data_469);
    DeRefDS(_char_set_470);
    DeRef(_101);
    _101 = NOVALUE;
    return _107;
    goto L6; // [112] 328
L1: 

    /** 	elsif sequence(test_data) then*/
    _108 = IS_SEQUENCE(_test_data_469);
    if (_108 == 0)
    {
        _108 = NOVALUE;
        goto L7; // [120] 319
    }
    else{
        _108 = NOVALUE;
    }

    /** 		if length(test_data) = 0 then */
    if (IS_SEQUENCE(_test_data_469)){
            _109 = SEQ_PTR(_test_data_469)->length;
    }
    else {
        _109 = 1;
    }
    if (_109 != 0)
    goto L8; // [128] 141

    /** 			return FALSE */
    DeRef(_test_data_469);
    DeRefDS(_char_set_470);
    DeRef(_107);
    _107 = NOVALUE;
    DeRef(_101);
    _101 = NOVALUE;
    return _9FALSE_429;
L8: 

    /** 		for i = 1 to length(test_data) label "NXTCHR" do*/
    if (IS_SEQUENCE(_test_data_469)){
            _111 = SEQ_PTR(_test_data_469)->length;
    }
    else {
        _111 = 1;
    }
    {
        int _i_497;
        _i_497 = 1;
L9: 
        if (_i_497 > _111){
            goto LA; // [146] 308
        }

        /** 			if sequence(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_469);
        _113 = (int)*(((s1_ptr)_2)->base + _i_497);
        _114 = IS_SEQUENCE(_113);
        _113 = NOVALUE;
        if (_114 == 0)
        {
            _114 = NOVALUE;
            goto LB; // [162] 174
        }
        else{
            _114 = NOVALUE;
        }

        /** 				return FALSE*/
        DeRef(_test_data_469);
        DeRefDS(_char_set_470);
        DeRef(_107);
        _107 = NOVALUE;
        DeRef(_101);
        _101 = NOVALUE;
        return _9FALSE_429;
LB: 

        /** 			if not integer(test_data[i]) then */
        _2 = (int)SEQ_PTR(_test_data_469);
        _115 = (int)*(((s1_ptr)_2)->base + _i_497);
        if (IS_ATOM_INT(_115))
        _116 = 1;
        else if (IS_ATOM_DBL(_115))
        _116 = IS_ATOM_INT(DoubleToInt(_115));
        else
        _116 = 0;
        _115 = NOVALUE;
        if (_116 != 0)
        goto LC; // [183] 195
        _116 = NOVALUE;

        /** 				return FALSE*/
        DeRef(_test_data_469);
        DeRefDS(_char_set_470);
        DeRef(_107);
        _107 = NOVALUE;
        DeRef(_101);
        _101 = NOVALUE;
        return _9FALSE_429;
LC: 

        /** 			lChr = test_data[i]*/
        _2 = (int)SEQ_PTR(_test_data_469);
        _lChr_471 = (int)*(((s1_ptr)_2)->base + _i_497);
        if (!IS_ATOM_INT(_lChr_471)){
            _lChr_471 = (long)DBL_PTR(_lChr_471)->dbl;
        }

        /** 			if sequence(char_set[1]) then*/
        _2 = (int)SEQ_PTR(_char_set_470);
        _119 = (int)*(((s1_ptr)_2)->base + 1);
        _120 = IS_SEQUENCE(_119);
        _119 = NOVALUE;
        if (_120 == 0)
        {
            _120 = NOVALUE;
            goto LD; // [212] 276
        }
        else{
            _120 = NOVALUE;
        }

        /** 				for j = 1 to length(char_set) do*/
        if (IS_SEQUENCE(_char_set_470)){
                _121 = SEQ_PTR(_char_set_470)->length;
        }
        else {
            _121 = 1;
        }
        {
            int _j_512;
            _j_512 = 1;
LE: 
            if (_j_512 > _121){
                goto LF; // [220] 273
            }

            /** 					if lChr >= char_set[j][1] and lChr <= char_set[j][2] then*/
            _2 = (int)SEQ_PTR(_char_set_470);
            _122 = (int)*(((s1_ptr)_2)->base + _j_512);
            _2 = (int)SEQ_PTR(_122);
            _123 = (int)*(((s1_ptr)_2)->base + 1);
            _122 = NOVALUE;
            if (IS_ATOM_INT(_123)) {
                _124 = (_lChr_471 >= _123);
            }
            else {
                _124 = binary_op(GREATEREQ, _lChr_471, _123);
            }
            _123 = NOVALUE;
            if (IS_ATOM_INT(_124)) {
                if (_124 == 0) {
                    goto L10; // [241] 266
                }
            }
            else {
                if (DBL_PTR(_124)->dbl == 0.0) {
                    goto L10; // [241] 266
                }
            }
            _2 = (int)SEQ_PTR(_char_set_470);
            _126 = (int)*(((s1_ptr)_2)->base + _j_512);
            _2 = (int)SEQ_PTR(_126);
            _127 = (int)*(((s1_ptr)_2)->base + 2);
            _126 = NOVALUE;
            if (IS_ATOM_INT(_127)) {
                _128 = (_lChr_471 <= _127);
            }
            else {
                _128 = binary_op(LESSEQ, _lChr_471, _127);
            }
            _127 = NOVALUE;
            if (_128 == 0) {
                DeRef(_128);
                _128 = NOVALUE;
                goto L10; // [258] 266
            }
            else {
                if (!IS_ATOM_INT(_128) && DBL_PTR(_128)->dbl == 0.0){
                    DeRef(_128);
                    _128 = NOVALUE;
                    goto L10; // [258] 266
                }
                DeRef(_128);
                _128 = NOVALUE;
            }
            DeRef(_128);
            _128 = NOVALUE;

            /** 						continue "NXTCHR" */
            goto L11; // [263] 303
L10: 

            /** 				end for*/
            _j_512 = _j_512 + 1;
            goto LE; // [268] 227
LF: 
            ;
        }
        goto L12; // [273] 293
LD: 

        /** 				if find(lChr, char_set) > 0 then*/
        _129 = find_from(_lChr_471, _char_set_470, 1);
        if (_129 <= 0)
        goto L13; // [283] 292

        /** 					continue "NXTCHR"*/
        goto L11; // [289] 303
L13: 
L12: 

        /** 			return FALSE*/
        DeRef(_test_data_469);
        DeRefDS(_char_set_470);
        DeRef(_107);
        _107 = NOVALUE;
        DeRef(_101);
        _101 = NOVALUE;
        DeRef(_124);
        _124 = NOVALUE;
        return _9FALSE_429;

        /** 		end for*/
L11: 
        _i_497 = _i_497 + 1;
        goto L9; // [303] 153
LA: 
        ;
    }

    /** 		return TRUE*/
    DeRef(_test_data_469);
    DeRefDS(_char_set_470);
    DeRef(_107);
    _107 = NOVALUE;
    DeRef(_101);
    _101 = NOVALUE;
    DeRef(_124);
    _124 = NOVALUE;
    return _9TRUE_431;
    goto L6; // [316] 328
L7: 

    /** 		return FALSE*/
    DeRef(_test_data_469);
    DeRefDS(_char_set_470);
    DeRef(_107);
    _107 = NOVALUE;
    DeRef(_101);
    _101 = NOVALUE;
    DeRef(_124);
    _124 = NOVALUE;
    return _9FALSE_429;
L6: 
    ;
}


void _9set_default_charsets()
{
    int _195 = NOVALUE;
    int _193 = NOVALUE;
    int _192 = NOVALUE;
    int _190 = NOVALUE;
    int _187 = NOVALUE;
    int _186 = NOVALUE;
    int _185 = NOVALUE;
    int _184 = NOVALUE;
    int _181 = NOVALUE;
    int _179 = NOVALUE;
    int _168 = NOVALUE;
    int _161 = NOVALUE;
    int _158 = NOVALUE;
    int _151 = NOVALUE;
    int _148 = NOVALUE;
    int _147 = NOVALUE;
    int _146 = NOVALUE;
    int _143 = NOVALUE;
    int _140 = NOVALUE;
    int _132 = NOVALUE;
    int _131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Defined_Sets = repeat(0, CS_LAST - CS_FIRST - 1)*/
    _131 = 20;
    _132 = 19;
    _131 = NOVALUE;
    DeRef(_9Defined_Sets_527);
    _9Defined_Sets_527 = Repeat(0, 19);
    _132 = NOVALUE;

    /** 	Defined_Sets[CS_Alphabetic	] = {{'a', 'z'}, {'A', 'Z'}}*/
    RefDS(_139);
    RefDS(_136);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _136;
    ((int *)_2)[2] = _139;
    _140 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 12);
    *(int *)_2 = _140;
    if( _1 != _140 ){
    }
    _140 = NOVALUE;

    /** 	Defined_Sets[CS_Alphanumeric] = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_142);
    *((int *)(_2+4)) = _142;
    RefDS(_136);
    *((int *)(_2+8)) = _136;
    RefDS(_139);
    *((int *)(_2+12)) = _139;
    _143 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _143;
    if( _1 != _143 ){
        DeRef(_1);
    }
    _143 = NOVALUE;

    /** 	Defined_Sets[CS_Identifier]   = {{'0', '9'}, {'a', 'z'}, {'A', 'Z'}, {'_', '_'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_142);
    *((int *)(_2+4)) = _142;
    RefDS(_136);
    *((int *)(_2+8)) = _136;
    RefDS(_139);
    *((int *)(_2+12)) = _139;
    RefDS(_145);
    *((int *)(_2+16)) = _145;
    _146 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _146;
    if( _1 != _146 ){
        DeRef(_1);
    }
    _146 = NOVALUE;

    /** 	Defined_Sets[CS_Uppercase 	] = {{'A', 'Z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_139);
    *((int *)(_2+4)) = _139;
    _147 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _147;
    if( _1 != _147 ){
        DeRef(_1);
    }
    _147 = NOVALUE;

    /** 	Defined_Sets[CS_Lowercase 	] = {{'a', 'z'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_136);
    *((int *)(_2+4)) = _136;
    _148 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _148;
    if( _1 != _148 ){
        DeRef(_1);
    }
    _148 = NOVALUE;

    /** 	Defined_Sets[CS_Printable 	] = {{' ', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_150);
    *((int *)(_2+4)) = _150;
    _151 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _151;
    if( _1 != _151 ){
        DeRef(_1);
    }
    _151 = NOVALUE;

    /** 	Defined_Sets[CS_Displayable ] = {{' ', '~'}, "  ", "\t\t", "\n\n", "\r\r", {8,8}, {7,7} }*/
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_150);
    *((int *)(_2+4)) = _150;
    RefDS(_152);
    *((int *)(_2+8)) = _152;
    RefDS(_153);
    *((int *)(_2+12)) = _153;
    RefDS(_154);
    *((int *)(_2+16)) = _154;
    RefDS(_155);
    *((int *)(_2+20)) = _155;
    RefDS(_156);
    *((int *)(_2+24)) = _156;
    RefDS(_157);
    *((int *)(_2+28)) = _157;
    _158 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _158;
    if( _1 != _158 ){
        DeRef(_1);
    }
    _158 = NOVALUE;

    /** 	Defined_Sets[CS_Whitespace 	] = " \t\n\r" & 11 & 160*/
    {
        int concat_list[3];

        concat_list[0] = 160;
        concat_list[1] = 11;
        concat_list[2] = _159;
        Concat_N((object_ptr)&_161, concat_list, 3);
    }
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _161;
    if( _1 != _161 ){
        DeRef(_1);
    }
    _161 = NOVALUE;

    /** 	Defined_Sets[CS_Consonant 	] = "bcdfghjklmnpqrstvwxyzBCDFGHJKLMNPQRSTVWXYZ"*/
    RefDS(_162);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _162;
    DeRef(_1);

    /** 	Defined_Sets[CS_Vowel 		] = "aeiouAEIOU"*/
    RefDS(_163);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _163;
    DeRef(_1);

    /** 	Defined_Sets[CS_Hexadecimal ] = {{'0', '9'}, {'A', 'F'},{'a', 'f'}}*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_142);
    *((int *)(_2+4)) = _142;
    RefDS(_165);
    *((int *)(_2+8)) = _165;
    RefDS(_167);
    *((int *)(_2+12)) = _167;
    _168 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _168;
    if( _1 != _168 ){
        DeRef(_1);
    }
    _168 = NOVALUE;

    /** 	Defined_Sets[CS_Punctuation ] = {{' ', '/'}, {':', '?'}, {'[', '`'}, {'{', '~'}}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_170);
    *((int *)(_2+4)) = _170;
    RefDS(_173);
    *((int *)(_2+8)) = _173;
    RefDS(_176);
    *((int *)(_2+12)) = _176;
    RefDS(_178);
    *((int *)(_2+16)) = _178;
    _179 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _179;
    if( _1 != _179 ){
        DeRef(_1);
    }
    _179 = NOVALUE;

    /** 	Defined_Sets[CS_Control 	] = {{0, 31}, {127, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 31;
    _181 = MAKE_SEQ(_1);
    RefDS(_183);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _181;
    ((int *)_2)[2] = _183;
    _184 = MAKE_SEQ(_1);
    _181 = NOVALUE;
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _184;
    if( _1 != _184 ){
        DeRef(_1);
    }
    _184 = NOVALUE;

    /** 	Defined_Sets[CS_ASCII 		] = {{0, 127}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 127;
    _185 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _185;
    _186 = MAKE_SEQ(_1);
    _185 = NOVALUE;
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 13);
    _1 = *(int *)_2;
    *(int *)_2 = _186;
    if( _1 != _186 ){
        DeRef(_1);
    }
    _186 = NOVALUE;

    /** 	Defined_Sets[CS_Digit 		] = {{'0', '9'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_142);
    *((int *)(_2+4)) = _142;
    _187 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _187;
    if( _1 != _187 ){
        DeRef(_1);
    }
    _187 = NOVALUE;

    /** 	Defined_Sets[CS_Graphic 	] = {{'!', '~'}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_189);
    *((int *)(_2+4)) = _189;
    _190 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _190;
    if( _1 != _190 ){
        DeRef(_1);
    }
    _190 = NOVALUE;

    /** 	Defined_Sets[CS_Bytes	 	] = {{0, 255}}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 255;
    _192 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _192;
    _193 = MAKE_SEQ(_1);
    _192 = NOVALUE;
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 17);
    _1 = *(int *)_2;
    *(int *)_2 = _193;
    if( _1 != _193 ){
        DeRef(_1);
    }
    _193 = NOVALUE;

    /** 	Defined_Sets[CS_SpecWord 	] = "_"*/
    RefDS(_194);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 18);
    _1 = *(int *)_2;
    *(int *)_2 = _194;
    DeRef(_1);

    /** 	Defined_Sets[CS_Boolean     ] = {TRUE,FALSE}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _9TRUE_431;
    ((int *)_2)[2] = _9FALSE_429;
    _195 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _2 = (int)(((s1_ptr)_2)->base + 19);
    _1 = *(int *)_2;
    *(int *)_2 = _195;
    if( _1 != _195 ){
        DeRef(_1);
    }
    _195 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _9get_charsets()
{
    int _result__597 = NOVALUE;
    int _199 = NOVALUE;
    int _198 = NOVALUE;
    int _197 = NOVALUE;
    int _196 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_ = {}*/
    RefDS(_5);
    DeRef(_result__597);
    _result__597 = _5;

    /** 	for i = CS_FIRST + 1 to CS_LAST - 1 do*/
    _196 = 1;
    _197 = 19;
    {
        int _i_599;
        _i_599 = 1;
L1: 
        if (_i_599 > 19){
            goto L2; // [18] 48
        }

        /** 		result_ = append(result_, {i, Defined_Sets[i]} )*/
        _2 = (int)SEQ_PTR(_9Defined_Sets_527);
        _198 = (int)*(((s1_ptr)_2)->base + _i_599);
        Ref(_198);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _i_599;
        ((int *)_2)[2] = _198;
        _199 = MAKE_SEQ(_1);
        _198 = NOVALUE;
        RefDS(_199);
        Append(&_result__597, _result__597, _199);
        DeRefDS(_199);
        _199 = NOVALUE;

        /** 	end for*/
        _i_599 = _i_599 + 1;
        goto L1; // [43] 25
L2: 
        ;
    }

    /** 	return result_*/
    DeRef(_196);
    _196 = NOVALUE;
    DeRef(_197);
    _197 = NOVALUE;
    return _result__597;
    ;
}


void _9set_charsets(int _charset_list_607)
{
    int _222 = NOVALUE;
    int _221 = NOVALUE;
    int _220 = NOVALUE;
    int _219 = NOVALUE;
    int _218 = NOVALUE;
    int _217 = NOVALUE;
    int _216 = NOVALUE;
    int _215 = NOVALUE;
    int _214 = NOVALUE;
    int _213 = NOVALUE;
    int _212 = NOVALUE;
    int _211 = NOVALUE;
    int _210 = NOVALUE;
    int _209 = NOVALUE;
    int _208 = NOVALUE;
    int _207 = NOVALUE;
    int _206 = NOVALUE;
    int _205 = NOVALUE;
    int _204 = NOVALUE;
    int _203 = NOVALUE;
    int _202 = NOVALUE;
    int _201 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(charset_list) do*/
    if (IS_SEQUENCE(_charset_list_607)){
            _201 = SEQ_PTR(_charset_list_607)->length;
    }
    else {
        _201 = 1;
    }
    {
        int _i_609;
        _i_609 = 1;
L1: 
        if (_i_609 > _201){
            goto L2; // [8] 129
        }

        /** 		if sequence(charset_list[i]) and length(charset_list[i]) = 2 then*/
        _2 = (int)SEQ_PTR(_charset_list_607);
        _202 = (int)*(((s1_ptr)_2)->base + _i_609);
        _203 = IS_SEQUENCE(_202);
        _202 = NOVALUE;
        if (_203 == 0) {
            goto L3; // [24] 122
        }
        _2 = (int)SEQ_PTR(_charset_list_607);
        _205 = (int)*(((s1_ptr)_2)->base + _i_609);
        if (IS_SEQUENCE(_205)){
                _206 = SEQ_PTR(_205)->length;
        }
        else {
            _206 = 1;
        }
        _205 = NOVALUE;
        _207 = (_206 == 2);
        _206 = NOVALUE;
        if (_207 == 0)
        {
            DeRef(_207);
            _207 = NOVALUE;
            goto L3; // [40] 122
        }
        else{
            DeRef(_207);
            _207 = NOVALUE;
        }

        /** 			if integer(charset_list[i][1]) and charset_list[i][1] > CS_FIRST and charset_list[i][1] < CS_LAST then*/
        _2 = (int)SEQ_PTR(_charset_list_607);
        _208 = (int)*(((s1_ptr)_2)->base + _i_609);
        _2 = (int)SEQ_PTR(_208);
        _209 = (int)*(((s1_ptr)_2)->base + 1);
        _208 = NOVALUE;
        if (IS_ATOM_INT(_209))
        _210 = 1;
        else if (IS_ATOM_DBL(_209))
        _210 = IS_ATOM_INT(DoubleToInt(_209));
        else
        _210 = 0;
        _209 = NOVALUE;
        if (_210 == 0) {
            _211 = 0;
            goto L4; // [56] 76
        }
        _2 = (int)SEQ_PTR(_charset_list_607);
        _212 = (int)*(((s1_ptr)_2)->base + _i_609);
        _2 = (int)SEQ_PTR(_212);
        _213 = (int)*(((s1_ptr)_2)->base + 1);
        _212 = NOVALUE;
        if (IS_ATOM_INT(_213)) {
            _214 = (_213 > 0);
        }
        else {
            _214 = binary_op(GREATER, _213, 0);
        }
        _213 = NOVALUE;
        if (IS_ATOM_INT(_214))
        _211 = (_214 != 0);
        else
        _211 = DBL_PTR(_214)->dbl != 0.0;
L4: 
        if (_211 == 0) {
            goto L5; // [76] 121
        }
        _2 = (int)SEQ_PTR(_charset_list_607);
        _216 = (int)*(((s1_ptr)_2)->base + _i_609);
        _2 = (int)SEQ_PTR(_216);
        _217 = (int)*(((s1_ptr)_2)->base + 1);
        _216 = NOVALUE;
        if (IS_ATOM_INT(_217)) {
            _218 = (_217 < 20);
        }
        else {
            _218 = binary_op(LESS, _217, 20);
        }
        _217 = NOVALUE;
        if (_218 == 0) {
            DeRef(_218);
            _218 = NOVALUE;
            goto L5; // [93] 121
        }
        else {
            if (!IS_ATOM_INT(_218) && DBL_PTR(_218)->dbl == 0.0){
                DeRef(_218);
                _218 = NOVALUE;
                goto L5; // [93] 121
            }
            DeRef(_218);
            _218 = NOVALUE;
        }
        DeRef(_218);
        _218 = NOVALUE;

        /** 				Defined_Sets[charset_list[i][1]] = charset_list[i][2]*/
        _2 = (int)SEQ_PTR(_charset_list_607);
        _219 = (int)*(((s1_ptr)_2)->base + _i_609);
        _2 = (int)SEQ_PTR(_219);
        _220 = (int)*(((s1_ptr)_2)->base + 1);
        _219 = NOVALUE;
        _2 = (int)SEQ_PTR(_charset_list_607);
        _221 = (int)*(((s1_ptr)_2)->base + _i_609);
        _2 = (int)SEQ_PTR(_221);
        _222 = (int)*(((s1_ptr)_2)->base + 2);
        _221 = NOVALUE;
        Ref(_222);
        _2 = (int)SEQ_PTR(_9Defined_Sets_527);
        if (!IS_ATOM_INT(_220))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_220)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _220);
        _1 = *(int *)_2;
        *(int *)_2 = _222;
        if( _1 != _222 ){
            DeRef(_1);
        }
        _222 = NOVALUE;
L5: 
L3: 

        /** 	end for*/
        _i_609 = _i_609 + 1;
        goto L1; // [124] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_charset_list_607);
    _205 = NOVALUE;
    _220 = NOVALUE;
    DeRef(_214);
    _214 = NOVALUE;
    return;
    ;
}


int _9boolean(int _test_data_636)
{
    int _225 = NOVALUE;
    int _224 = NOVALUE;
    int _223 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return find(test_data,{1,0}) != 0*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _223 = MAKE_SEQ(_1);
    _224 = find_from(_test_data_636, _223, 1);
    DeRefDS(_223);
    _223 = NOVALUE;
    _225 = (_224 != 0);
    _224 = NOVALUE;
    DeRef(_test_data_636);
    return _225;
    ;
}


int _9t_boolean(int _test_data_642)
{
    int _227 = NOVALUE;
    int _226 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Boolean])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _226 = (int)*(((s1_ptr)_2)->base + 19);
    Ref(_test_data_642);
    Ref(_226);
    _227 = _9char_test(_test_data_642, _226);
    _226 = NOVALUE;
    DeRef(_test_data_642);
    return _227;
    ;
}


int _9t_alnum(int _test_data_647)
{
    int _229 = NOVALUE;
    int _228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphanumeric])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _228 = (int)*(((s1_ptr)_2)->base + 10);
    Ref(_test_data_647);
    Ref(_228);
    _229 = _9char_test(_test_data_647, _228);
    _228 = NOVALUE;
    DeRef(_test_data_647);
    return _229;
    ;
}


int _9t_identifier(int _test_data_652)
{
    int _239 = NOVALUE;
    int _238 = NOVALUE;
    int _237 = NOVALUE;
    int _236 = NOVALUE;
    int _235 = NOVALUE;
    int _234 = NOVALUE;
    int _233 = NOVALUE;
    int _232 = NOVALUE;
    int _231 = NOVALUE;
    int _230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if t_digit(test_data) then*/
    Ref(_test_data_652);
    _230 = _9t_digit(_test_data_652);
    if (_230 == 0) {
        DeRef(_230);
        _230 = NOVALUE;
        goto L1; // [7] 19
    }
    else {
        if (!IS_ATOM_INT(_230) && DBL_PTR(_230)->dbl == 0.0){
            DeRef(_230);
            _230 = NOVALUE;
            goto L1; // [7] 19
        }
        DeRef(_230);
        _230 = NOVALUE;
    }
    DeRef(_230);
    _230 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_652);
    return 0;
    goto L2; // [16] 63
L1: 

    /** 	elsif sequence(test_data) and length(test_data) > 0 and t_digit(test_data[1]) then*/
    _231 = IS_SEQUENCE(_test_data_652);
    if (_231 == 0) {
        _232 = 0;
        goto L3; // [24] 39
    }
    if (IS_SEQUENCE(_test_data_652)){
            _233 = SEQ_PTR(_test_data_652)->length;
    }
    else {
        _233 = 1;
    }
    _234 = (_233 > 0);
    _233 = NOVALUE;
    _232 = (_234 != 0);
L3: 
    if (_232 == 0) {
        goto L4; // [39] 62
    }
    _2 = (int)SEQ_PTR(_test_data_652);
    _236 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_236);
    _237 = _9t_digit(_236);
    _236 = NOVALUE;
    if (_237 == 0) {
        DeRef(_237);
        _237 = NOVALUE;
        goto L4; // [52] 62
    }
    else {
        if (!IS_ATOM_INT(_237) && DBL_PTR(_237)->dbl == 0.0){
            DeRef(_237);
            _237 = NOVALUE;
            goto L4; // [52] 62
        }
        DeRef(_237);
        _237 = NOVALUE;
    }
    DeRef(_237);
    _237 = NOVALUE;

    /** 		return 0*/
    DeRef(_test_data_652);
    DeRef(_234);
    _234 = NOVALUE;
    return 0;
L4: 
L2: 

    /** 	return char_test(test_data, Defined_Sets[CS_Identifier])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _238 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_test_data_652);
    Ref(_238);
    _239 = _9char_test(_test_data_652, _238);
    _238 = NOVALUE;
    DeRef(_test_data_652);
    DeRef(_234);
    _234 = NOVALUE;
    return _239;
    ;
}


int _9t_alpha(int _test_data_669)
{
    int _241 = NOVALUE;
    int _240 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Alphabetic])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _240 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_test_data_669);
    Ref(_240);
    _241 = _9char_test(_test_data_669, _240);
    _240 = NOVALUE;
    DeRef(_test_data_669);
    return _241;
    ;
}


int _9t_ascii(int _test_data_674)
{
    int _243 = NOVALUE;
    int _242 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_ASCII])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _242 = (int)*(((s1_ptr)_2)->base + 13);
    Ref(_test_data_674);
    Ref(_242);
    _243 = _9char_test(_test_data_674, _242);
    _242 = NOVALUE;
    DeRef(_test_data_674);
    return _243;
    ;
}


int _9t_cntrl(int _test_data_679)
{
    int _245 = NOVALUE;
    int _244 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Control])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _244 = (int)*(((s1_ptr)_2)->base + 14);
    Ref(_test_data_679);
    Ref(_244);
    _245 = _9char_test(_test_data_679, _244);
    _244 = NOVALUE;
    DeRef(_test_data_679);
    return _245;
    ;
}


int _9t_digit(int _test_data_684)
{
    int _247 = NOVALUE;
    int _246 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Digit])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _246 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_test_data_684);
    Ref(_246);
    _247 = _9char_test(_test_data_684, _246);
    _246 = NOVALUE;
    DeRef(_test_data_684);
    return _247;
    ;
}


int _9t_graph(int _test_data_689)
{
    int _249 = NOVALUE;
    int _248 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Graphic])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _248 = (int)*(((s1_ptr)_2)->base + 16);
    Ref(_test_data_689);
    Ref(_248);
    _249 = _9char_test(_test_data_689, _248);
    _248 = NOVALUE;
    DeRef(_test_data_689);
    return _249;
    ;
}


int _9t_specword(int _test_data_694)
{
    int _251 = NOVALUE;
    int _250 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_SpecWord])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _250 = (int)*(((s1_ptr)_2)->base + 18);
    Ref(_test_data_694);
    Ref(_250);
    _251 = _9char_test(_test_data_694, _250);
    _250 = NOVALUE;
    DeRef(_test_data_694);
    return _251;
    ;
}


int _9t_bytearray(int _test_data_699)
{
    int _253 = NOVALUE;
    int _252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Bytes])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _252 = (int)*(((s1_ptr)_2)->base + 17);
    Ref(_test_data_699);
    Ref(_252);
    _253 = _9char_test(_test_data_699, _252);
    _252 = NOVALUE;
    DeRef(_test_data_699);
    return _253;
    ;
}


int _9t_lower(int _test_data_704)
{
    int _255 = NOVALUE;
    int _254 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Lowercase])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _254 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_test_data_704);
    Ref(_254);
    _255 = _9char_test(_test_data_704, _254);
    _254 = NOVALUE;
    DeRef(_test_data_704);
    return _255;
    ;
}


int _9t_print(int _test_data_709)
{
    int _257 = NOVALUE;
    int _256 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Printable])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _256 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_test_data_709);
    Ref(_256);
    _257 = _9char_test(_test_data_709, _256);
    _256 = NOVALUE;
    DeRef(_test_data_709);
    return _257;
    ;
}


int _9t_display(int _test_data_714)
{
    int _259 = NOVALUE;
    int _258 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Displayable])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _258 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_test_data_714);
    Ref(_258);
    _259 = _9char_test(_test_data_714, _258);
    _258 = NOVALUE;
    DeRef(_test_data_714);
    return _259;
    ;
}


int _9t_punct(int _test_data_719)
{
    int _261 = NOVALUE;
    int _260 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Punctuation])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _260 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_test_data_719);
    Ref(_260);
    _261 = _9char_test(_test_data_719, _260);
    _260 = NOVALUE;
    DeRef(_test_data_719);
    return _261;
    ;
}


int _9t_space(int _test_data_724)
{
    int _263 = NOVALUE;
    int _262 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Whitespace])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _262 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_test_data_724);
    Ref(_262);
    _263 = _9char_test(_test_data_724, _262);
    _262 = NOVALUE;
    DeRef(_test_data_724);
    return _263;
    ;
}


int _9t_upper(int _test_data_729)
{
    int _265 = NOVALUE;
    int _264 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Uppercase])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _264 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_test_data_729);
    Ref(_264);
    _265 = _9char_test(_test_data_729, _264);
    _264 = NOVALUE;
    DeRef(_test_data_729);
    return _265;
    ;
}


int _9t_xdigit(int _test_data_734)
{
    int _267 = NOVALUE;
    int _266 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Hexadecimal])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _266 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_test_data_734);
    Ref(_266);
    _267 = _9char_test(_test_data_734, _266);
    _266 = NOVALUE;
    DeRef(_test_data_734);
    return _267;
    ;
}


int _9t_vowel(int _test_data_739)
{
    int _269 = NOVALUE;
    int _268 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Vowel])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _268 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_test_data_739);
    Ref(_268);
    _269 = _9char_test(_test_data_739, _268);
    _268 = NOVALUE;
    DeRef(_test_data_739);
    return _269;
    ;
}


int _9t_consonant(int _test_data_744)
{
    int _271 = NOVALUE;
    int _270 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return char_test(test_data, Defined_Sets[CS_Consonant])*/
    _2 = (int)SEQ_PTR(_9Defined_Sets_527);
    _270 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_test_data_744);
    Ref(_270);
    _271 = _9char_test(_test_data_744, _270);
    _270 = NOVALUE;
    DeRef(_test_data_744);
    return _271;
    ;
}


int _9integer_array(int _x_749)
{
    int _276 = NOVALUE;
    int _275 = NOVALUE;
    int _274 = NOVALUE;
    int _272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _272 = IS_SEQUENCE(_x_749);
    if (_272 != 0)
    goto L1; // [6] 16
    _272 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_749);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_749)){
            _274 = SEQ_PTR(_x_749)->length;
    }
    else {
        _274 = 1;
    }
    {
        int _i_754;
        _i_754 = 1;
L2: 
        if (_i_754 > _274){
            goto L3; // [21] 54
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_749);
        _275 = (int)*(((s1_ptr)_2)->base + _i_754);
        if (IS_ATOM_INT(_275))
        _276 = 1;
        else if (IS_ATOM_DBL(_275))
        _276 = IS_ATOM_INT(DoubleToInt(_275));
        else
        _276 = 0;
        _275 = NOVALUE;
        if (_276 != 0)
        goto L4; // [37] 47
        _276 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_749);
        return 0;
L4: 

        /** 	end for*/
        _i_754 = _i_754 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_749);
    return 1;
    ;
}


int _9t_text(int _x_762)
{
    int _284 = NOVALUE;
    int _282 = NOVALUE;
    int _281 = NOVALUE;
    int _280 = NOVALUE;
    int _278 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _278 = IS_SEQUENCE(_x_762);
    if (_278 != 0)
    goto L1; // [6] 16
    _278 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_762);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_762)){
            _280 = SEQ_PTR(_x_762)->length;
    }
    else {
        _280 = 1;
    }
    {
        int _i_767;
        _i_767 = 1;
L2: 
        if (_i_767 > _280){
            goto L3; // [21] 71
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_762);
        _281 = (int)*(((s1_ptr)_2)->base + _i_767);
        if (IS_ATOM_INT(_281))
        _282 = 1;
        else if (IS_ATOM_DBL(_281))
        _282 = IS_ATOM_INT(DoubleToInt(_281));
        else
        _282 = 0;
        _281 = NOVALUE;
        if (_282 != 0)
        goto L4; // [37] 47
        _282 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_762);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_762);
        _284 = (int)*(((s1_ptr)_2)->base + _i_767);
        if (binary_op_a(GREATEREQ, _284, 0)){
            _284 = NOVALUE;
            goto L5; // [53] 64
        }
        _284 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_762);
        return 0;
L5: 

        /** 	end for*/
        _i_767 = _i_767 + 1;
        goto L2; // [66] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_762);
    return 1;
    ;
}


int _9number_array(int _x_778)
{
    int _290 = NOVALUE;
    int _289 = NOVALUE;
    int _288 = NOVALUE;
    int _286 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _286 = IS_SEQUENCE(_x_778);
    if (_286 != 0)
    goto L1; // [6] 16
    _286 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_778);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_778)){
            _288 = SEQ_PTR(_x_778)->length;
    }
    else {
        _288 = 1;
    }
    {
        int _i_783;
        _i_783 = 1;
L2: 
        if (_i_783 > _288){
            goto L3; // [21] 54
        }

        /** 		if not atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_778);
        _289 = (int)*(((s1_ptr)_2)->base + _i_783);
        _290 = IS_ATOM(_289);
        _289 = NOVALUE;
        if (_290 != 0)
        goto L4; // [37] 47
        _290 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_778);
        return 0;
L4: 

        /** 	end for*/
        _i_783 = _i_783 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_778);
    return 1;
    ;
}


int _9sequence_array(int _x_791)
{
    int _296 = NOVALUE;
    int _295 = NOVALUE;
    int _294 = NOVALUE;
    int _292 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _292 = IS_SEQUENCE(_x_791);
    if (_292 != 0)
    goto L1; // [6] 16
    _292 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_791);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_791)){
            _294 = SEQ_PTR(_x_791)->length;
    }
    else {
        _294 = 1;
    }
    {
        int _i_796;
        _i_796 = 1;
L2: 
        if (_i_796 > _294){
            goto L3; // [21] 54
        }

        /** 		if not sequence(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_791);
        _295 = (int)*(((s1_ptr)_2)->base + _i_796);
        _296 = IS_SEQUENCE(_295);
        _295 = NOVALUE;
        if (_296 != 0)
        goto L4; // [37] 47
        _296 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_791);
        return 0;
L4: 

        /** 	end for*/
        _i_796 = _i_796 + 1;
        goto L2; // [49] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_791);
    return 1;
    ;
}


int _9ascii_string(int _x_804)
{
    int _306 = NOVALUE;
    int _304 = NOVALUE;
    int _302 = NOVALUE;
    int _301 = NOVALUE;
    int _300 = NOVALUE;
    int _298 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _298 = IS_SEQUENCE(_x_804);
    if (_298 != 0)
    goto L1; // [6] 16
    _298 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_804);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_804)){
            _300 = SEQ_PTR(_x_804)->length;
    }
    else {
        _300 = 1;
    }
    {
        int _i_809;
        _i_809 = 1;
L2: 
        if (_i_809 > _300){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_804);
        _301 = (int)*(((s1_ptr)_2)->base + _i_809);
        if (IS_ATOM_INT(_301))
        _302 = 1;
        else if (IS_ATOM_DBL(_301))
        _302 = IS_ATOM_INT(DoubleToInt(_301));
        else
        _302 = 0;
        _301 = NOVALUE;
        if (_302 != 0)
        goto L4; // [37] 47
        _302 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_804);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_804);
        _304 = (int)*(((s1_ptr)_2)->base + _i_809);
        if (binary_op_a(GREATEREQ, _304, 0)){
            _304 = NOVALUE;
            goto L5; // [53] 64
        }
        _304 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_804);
        return 0;
L5: 

        /** 		if x[i] > 127 then*/
        _2 = (int)SEQ_PTR(_x_804);
        _306 = (int)*(((s1_ptr)_2)->base + _i_809);
        if (binary_op_a(LESSEQ, _306, 127)){
            _306 = NOVALUE;
            goto L6; // [70] 81
        }
        _306 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_804);
        return 0;
L6: 

        /** 	end for*/
        _i_809 = _i_809 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_804);
    return 1;
    ;
}


int _9string(int _x_823)
{
    int _316 = NOVALUE;
    int _314 = NOVALUE;
    int _312 = NOVALUE;
    int _311 = NOVALUE;
    int _310 = NOVALUE;
    int _308 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _308 = IS_SEQUENCE(_x_823);
    if (_308 != 0)
    goto L1; // [6] 16
    _308 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_823);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_823)){
            _310 = SEQ_PTR(_x_823)->length;
    }
    else {
        _310 = 1;
    }
    {
        int _i_828;
        _i_828 = 1;
L2: 
        if (_i_828 > _310){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_823);
        _311 = (int)*(((s1_ptr)_2)->base + _i_828);
        if (IS_ATOM_INT(_311))
        _312 = 1;
        else if (IS_ATOM_DBL(_311))
        _312 = IS_ATOM_INT(DoubleToInt(_311));
        else
        _312 = 0;
        _311 = NOVALUE;
        if (_312 != 0)
        goto L4; // [37] 47
        _312 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_823);
        return 0;
L4: 

        /** 		if x[i] < 0 then*/
        _2 = (int)SEQ_PTR(_x_823);
        _314 = (int)*(((s1_ptr)_2)->base + _i_828);
        if (binary_op_a(GREATEREQ, _314, 0)){
            _314 = NOVALUE;
            goto L5; // [53] 64
        }
        _314 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_823);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_823);
        _316 = (int)*(((s1_ptr)_2)->base + _i_828);
        if (binary_op_a(LESSEQ, _316, 255)){
            _316 = NOVALUE;
            goto L6; // [70] 81
        }
        _316 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_823);
        return 0;
L6: 

        /** 	end for*/
        _i_828 = _i_828 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_823);
    return 1;
    ;
}


int _9cstring(int _x_842)
{
    int _326 = NOVALUE;
    int _324 = NOVALUE;
    int _322 = NOVALUE;
    int _321 = NOVALUE;
    int _320 = NOVALUE;
    int _318 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not sequence(x) then*/
    _318 = IS_SEQUENCE(_x_842);
    if (_318 != 0)
    goto L1; // [6] 16
    _318 = NOVALUE;

    /** 		return 0*/
    DeRef(_x_842);
    return 0;
L1: 

    /** 	for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_842)){
            _320 = SEQ_PTR(_x_842)->length;
    }
    else {
        _320 = 1;
    }
    {
        int _i_847;
        _i_847 = 1;
L2: 
        if (_i_847 > _320){
            goto L3; // [21] 88
        }

        /** 		if not integer(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_842);
        _321 = (int)*(((s1_ptr)_2)->base + _i_847);
        if (IS_ATOM_INT(_321))
        _322 = 1;
        else if (IS_ATOM_DBL(_321))
        _322 = IS_ATOM_INT(DoubleToInt(_321));
        else
        _322 = 0;
        _321 = NOVALUE;
        if (_322 != 0)
        goto L4; // [37] 47
        _322 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_842);
        return 0;
L4: 

        /** 		if x[i] <= 0 then*/
        _2 = (int)SEQ_PTR(_x_842);
        _324 = (int)*(((s1_ptr)_2)->base + _i_847);
        if (binary_op_a(GREATER, _324, 0)){
            _324 = NOVALUE;
            goto L5; // [53] 64
        }
        _324 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_842);
        return 0;
L5: 

        /** 		if x[i] > 255 then*/
        _2 = (int)SEQ_PTR(_x_842);
        _326 = (int)*(((s1_ptr)_2)->base + _i_847);
        if (binary_op_a(LESSEQ, _326, 255)){
            _326 = NOVALUE;
            goto L6; // [70] 81
        }
        _326 = NOVALUE;

        /** 			return 0*/
        DeRef(_x_842);
        return 0;
L6: 

        /** 	end for*/
        _i_847 = _i_847 + 1;
        goto L2; // [83] 28
L3: 
        ;
    }

    /** 	return 1*/
    DeRef(_x_842);
    return 1;
    ;
}



// 0xB77801BE
