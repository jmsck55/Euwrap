// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _25sort(int _x_3329, int _order_3330)
{
    int _gap_3331 = NOVALUE;
    int _j_3332 = NOVALUE;
    int _first_3333 = NOVALUE;
    int _last_3334 = NOVALUE;
    int _tempi_3335 = NOVALUE;
    int _tempj_3336 = NOVALUE;
    int _1552 = NOVALUE;
    int _1548 = NOVALUE;
    int _1545 = NOVALUE;
    int _1541 = NOVALUE;
    int _1538 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3330 = -1;
    goto L1; // [16] 25

    /** 		order = 1*/
    _order_3330 = 1;
L1: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3329)){
            _last_3334 = SEQ_PTR(_x_3329)->length;
    }
    else {
        _last_3334 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3334 >= 0) {
        _1538 = _last_3334 / 10;
    }
    else {
        temp_dbl = floor((double)_last_3334 / (double)10);
        _1538 = (long)temp_dbl;
    }
    _gap_3331 = _1538 + 1;
    _1538 = NOVALUE;

    /** 	while 1 do*/
L2: 

    /** 		first = gap + 1*/
    _first_3333 = _gap_3331 + 1;

    /** 		for i = first to last do*/
    _1541 = _last_3334;
    {
        int _i_3346;
        _i_3346 = _first_3333;
L3: 
        if (_i_3346 > _1541){
            goto L4; // [56] 152
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_3335);
        _2 = (int)SEQ_PTR(_x_3329);
        _tempi_3335 = (int)*(((s1_ptr)_2)->base + _i_3346);
        Ref(_tempi_3335);

        /** 			j = i - gap*/
        _j_3332 = _i_3346 - _gap_3331;

        /** 			while 1 do*/
L5: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_3336);
        _2 = (int)SEQ_PTR(_x_3329);
        _tempj_3336 = (int)*(((s1_ptr)_2)->base + _j_3332);
        Ref(_tempj_3336);

        /** 				if eu:compare(tempi, tempj) != order then*/
        if (IS_ATOM_INT(_tempi_3335) && IS_ATOM_INT(_tempj_3336)){
            _1545 = (_tempi_3335 < _tempj_3336) ? -1 : (_tempi_3335 > _tempj_3336);
        }
        else{
            _1545 = compare(_tempi_3335, _tempj_3336);
        }
        if (_1545 == _order_3330)
        goto L6; // [92] 107

        /** 					j += gap*/
        _j_3332 = _j_3332 + _gap_3331;

        /** 					exit*/
        goto L7; // [104] 139
L6: 

        /** 				x[j+gap] = tempj*/
        _1548 = _j_3332 + _gap_3331;
        Ref(_tempj_3336);
        _2 = (int)SEQ_PTR(_x_3329);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3329 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1548);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3336;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3332 > _gap_3331)
        goto L8; // [119] 128

        /** 					exit*/
        goto L7; // [125] 139
L8: 

        /** 				j -= gap*/
        _j_3332 = _j_3332 - _gap_3331;

        /** 			end while*/
        goto L5; // [136] 80
L7: 

        /** 			x[j] = tempi*/
        Ref(_tempi_3335);
        _2 = (int)SEQ_PTR(_x_3329);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3329 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3332);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3335;
        DeRef(_1);

        /** 		end for*/
        _i_3346 = _i_3346 + 1;
        goto L3; // [147] 63
L4: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3331 != 1)
    goto L9; // [154] 167

    /** 			return x*/
    DeRef(_tempi_3335);
    DeRef(_tempj_3336);
    DeRef(_1548);
    _1548 = NOVALUE;
    return _x_3329;
    goto L2; // [164] 45
L9: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3331 >= 0) {
        _1552 = _gap_3331 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3331 / (double)7);
        _1552 = (long)temp_dbl;
    }
    _gap_3331 = _1552 + 1;
    _1552 = NOVALUE;

    /** 	end while*/
    goto L2; // [180] 45
    ;
}


int _25custom_sort(int _custom_compare_3367, int _x_3368, int _data_3369, int _order_3370)
{
    int _gap_3371 = NOVALUE;
    int _j_3372 = NOVALUE;
    int _first_3373 = NOVALUE;
    int _last_3374 = NOVALUE;
    int _tempi_3375 = NOVALUE;
    int _tempj_3376 = NOVALUE;
    int _result_3377 = NOVALUE;
    int _args_3378 = NOVALUE;
    int _1580 = NOVALUE;
    int _1576 = NOVALUE;
    int _1573 = NOVALUE;
    int _1571 = NOVALUE;
    int _1570 = NOVALUE;
    int _1565 = NOVALUE;
    int _1562 = NOVALUE;
    int _1558 = NOVALUE;
    int _1556 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence args = {0, 0}*/
    DeRef(_args_3378);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _args_3378 = MAKE_SEQ(_1);

    /** 	if order >= 0 then*/

    /** 		order = -1*/
    _order_3370 = -1;
    goto L1; // [24] 33

    /** 		order = 1*/
    _order_3370 = 1;
L1: 

    /** 	if atom(data) then*/
    _1556 = IS_ATOM(_data_3369);
    if (_1556 == 0)
    {
        _1556 = NOVALUE;
        goto L2; // [38] 50
    }
    else{
        _1556 = NOVALUE;
    }

    /** 		args &= data*/
    if (IS_SEQUENCE(_args_3378) && IS_ATOM(_data_3369)) {
        Ref(_data_3369);
        Append(&_args_3378, _args_3378, _data_3369);
    }
    else if (IS_ATOM(_args_3378) && IS_SEQUENCE(_data_3369)) {
    }
    else {
        Concat((object_ptr)&_args_3378, _args_3378, _data_3369);
    }
    goto L3; // [47] 70
L2: 

    /** 	elsif length(data) then*/
    _1558 = 0;
L3: 

    /** 	last = length(x)*/
    if (IS_SEQUENCE(_x_3368)){
            _last_3374 = SEQ_PTR(_x_3368)->length;
    }
    else {
        _last_3374 = 1;
    }

    /** 	gap = floor(last / 10) + 1*/
    if (10 > 0 && _last_3374 >= 0) {
        _1562 = _last_3374 / 10;
    }
    else {
        temp_dbl = floor((double)_last_3374 / (double)10);
        _1562 = (long)temp_dbl;
    }
    _gap_3371 = _1562 + 1;
    _1562 = NOVALUE;

    /** 	while 1 do*/
L4: 

    /** 		first = gap + 1*/
    _first_3373 = _gap_3371 + 1;

    /** 		for i = first to last do*/
    _1565 = _last_3374;
    {
        int _i_3396;
        _i_3396 = _first_3373;
L5: 
        if (_i_3396 > _1565){
            goto L6; // [101] 240
        }

        /** 			tempi = x[i]*/
        DeRef(_tempi_3375);
        _2 = (int)SEQ_PTR(_x_3368);
        _tempi_3375 = (int)*(((s1_ptr)_2)->base + _i_3396);
        Ref(_tempi_3375);

        /** 			args[1] = tempi*/
        Ref(_tempi_3375);
        _2 = (int)SEQ_PTR(_args_3378);
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3375;
        DeRef(_1);

        /** 			j = i - gap*/
        _j_3372 = _i_3396 - _gap_3371;

        /** 			while 1 do*/
L7: 

        /** 				tempj = x[j]*/
        DeRef(_tempj_3376);
        _2 = (int)SEQ_PTR(_x_3368);
        _tempj_3376 = (int)*(((s1_ptr)_2)->base + _j_3372);
        Ref(_tempj_3376);

        /** 				args[2] = tempj*/
        Ref(_tempj_3376);
        _2 = (int)SEQ_PTR(_args_3378);
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3376;
        DeRef(_1);

        /** 				result = call_func(custom_compare, args)*/
        _1 = (int)SEQ_PTR(_args_3378);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_custom_compare_3367].addr;
        switch(((s1_ptr)_1)->length) {
            case 0:
                _1 = (*(int (*)())_0)(
                                     );
                break;
            case 1:
                Ref(*(int *)(_2+4));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4)
                                     );
                break;
            case 2:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8)
                                     );
                break;
            case 3:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12)
                                     );
                break;
            case 4:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16)
                                     );
                break;
            case 5:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20)
                                     );
                break;
            case 6:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24)
                                     );
                break;
            case 7:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28)
                                     );
                break;
            case 8:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32)
                                     );
                break;
            case 9:
                Ref(*(int *)(_2+4));
                Ref(*(int *)(_2+8));
                Ref(*(int *)(_2+12));
                Ref(*(int *)(_2+16));
                Ref(*(int *)(_2+20));
                Ref(*(int *)(_2+24));
                Ref(*(int *)(_2+28));
                Ref(*(int *)(_2+32));
                Ref(*(int *)(_2+36));
                _1 = (*(int (*)())_0)(
                                    *(int *)(_2+4), 
                                    *(int *)(_2+8), 
                                    *(int *)(_2+12), 
                                    *(int *)(_2+16), 
                                    *(int *)(_2+20), 
                                    *(int *)(_2+24), 
                                    *(int *)(_2+28), 
                                    *(int *)(_2+32), 
                                    *(int *)(_2+36)
                                     );
                break;
        }
        DeRef(_result_3377);
        _result_3377 = _1;

        /** 				if sequence(result) then*/
        _1570 = IS_SEQUENCE(_result_3377);
        if (_1570 == 0)
        {
            _1570 = NOVALUE;
            goto L8; // [154] 174
        }
        else{
            _1570 = NOVALUE;
        }

        /** 					args[3] = result[2]*/
        _2 = (int)SEQ_PTR(_result_3377);
        _1571 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_1571);
        _2 = (int)SEQ_PTR(_args_3378);
        _2 = (int)(((s1_ptr)_2)->base + 3);
        _1 = *(int *)_2;
        *(int *)_2 = _1571;
        if( _1 != _1571 ){
            DeRef(_1);
        }
        _1571 = NOVALUE;

        /** 					result = result[1]*/
        _0 = _result_3377;
        _2 = (int)SEQ_PTR(_result_3377);
        _result_3377 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_result_3377);
        DeRef(_0);
L8: 

        /** 				if eu:compare(result, 0) != order then*/
        if (IS_ATOM_INT(_result_3377) && IS_ATOM_INT(0)){
            _1573 = (_result_3377 < 0) ? -1 : (_result_3377 > 0);
        }
        else{
            _1573 = compare(_result_3377, 0);
        }
        if (_1573 == _order_3370)
        goto L9; // [180] 195

        /** 					j += gap*/
        _j_3372 = _j_3372 + _gap_3371;

        /** 					exit*/
        goto LA; // [192] 227
L9: 

        /** 				x[j+gap] = tempj*/
        _1576 = _j_3372 + _gap_3371;
        Ref(_tempj_3376);
        _2 = (int)SEQ_PTR(_x_3368);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3368 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _1576);
        _1 = *(int *)_2;
        *(int *)_2 = _tempj_3376;
        DeRef(_1);

        /** 				if j <= gap then*/
        if (_j_3372 > _gap_3371)
        goto LB; // [207] 216

        /** 					exit*/
        goto LA; // [213] 227
LB: 

        /** 				j -= gap*/
        _j_3372 = _j_3372 - _gap_3371;

        /** 			end while*/
        goto L7; // [224] 131
LA: 

        /** 			x[j] = tempi*/
        Ref(_tempi_3375);
        _2 = (int)SEQ_PTR(_x_3368);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _x_3368 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _j_3372);
        _1 = *(int *)_2;
        *(int *)_2 = _tempi_3375;
        DeRef(_1);

        /** 		end for*/
        _i_3396 = _i_3396 + 1;
        goto L5; // [235] 108
L6: 
        ;
    }

    /** 		if gap = 1 then*/
    if (_gap_3371 != 1)
    goto LC; // [242] 255

    /** 			return x*/
    DeRef(_data_3369);
    DeRef(_tempi_3375);
    DeRef(_tempj_3376);
    DeRef(_result_3377);
    DeRef(_args_3378);
    DeRef(_1576);
    _1576 = NOVALUE;
    return _x_3368;
    goto L4; // [252] 90
LC: 

    /** 			gap = floor(gap / 7) + 1*/
    if (7 > 0 && _gap_3371 >= 0) {
        _1580 = _gap_3371 / 7;
    }
    else {
        temp_dbl = floor((double)_gap_3371 / (double)7);
        _1580 = (long)temp_dbl;
    }
    _gap_3371 = _1580 + 1;
    _1580 = NOVALUE;

    /** 	end while*/
    goto L4; // [268] 90
    ;
}


int _25column_compare(int _a_3422, int _b_3423, int _cols_3424)
{
    int _sign_3425 = NOVALUE;
    int _column_3426 = NOVALUE;
    int _1603 = NOVALUE;
    int _1601 = NOVALUE;
    int _1600 = NOVALUE;
    int _1599 = NOVALUE;
    int _1598 = NOVALUE;
    int _1597 = NOVALUE;
    int _1596 = NOVALUE;
    int _1594 = NOVALUE;
    int _1593 = NOVALUE;
    int _1592 = NOVALUE;
    int _1590 = NOVALUE;
    int _1588 = NOVALUE;
    int _1585 = NOVALUE;
    int _1583 = NOVALUE;
    int _1582 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(cols) do*/
    if (IS_SEQUENCE(_cols_3424)){
            _1582 = SEQ_PTR(_cols_3424)->length;
    }
    else {
        _1582 = 1;
    }
    {
        int _i_3428;
        _i_3428 = 1;
L1: 
        if (_i_3428 > _1582){
            goto L2; // [6] 176
        }

        /** 		if cols[i] < 0 then*/
        _2 = (int)SEQ_PTR(_cols_3424);
        _1583 = (int)*(((s1_ptr)_2)->base + _i_3428);
        if (binary_op_a(GREATEREQ, _1583, 0)){
            _1583 = NOVALUE;
            goto L3; // [19] 42
        }
        _1583 = NOVALUE;

        /** 			sign = -1*/
        _sign_3425 = -1;

        /** 			column = -cols[i]*/
        _2 = (int)SEQ_PTR(_cols_3424);
        _1585 = (int)*(((s1_ptr)_2)->base + _i_3428);
        if (IS_ATOM_INT(_1585)) {
            if ((unsigned long)_1585 == 0xC0000000)
            _column_3426 = (int)NewDouble((double)-0xC0000000);
            else
            _column_3426 = - _1585;
        }
        else {
            _column_3426 = unary_op(UMINUS, _1585);
        }
        _1585 = NOVALUE;
        if (!IS_ATOM_INT(_column_3426)) {
            _1 = (long)(DBL_PTR(_column_3426)->dbl);
            DeRefDS(_column_3426);
            _column_3426 = _1;
        }
        goto L4; // [39] 56
L3: 

        /** 			sign = 1*/
        _sign_3425 = 1;

        /** 			column = cols[i]*/
        _2 = (int)SEQ_PTR(_cols_3424);
        _column_3426 = (int)*(((s1_ptr)_2)->base + _i_3428);
        if (!IS_ATOM_INT(_column_3426)){
            _column_3426 = (long)DBL_PTR(_column_3426)->dbl;
        }
L4: 

        /** 		if column <= length(a) then*/
        if (IS_SEQUENCE(_a_3422)){
                _1588 = SEQ_PTR(_a_3422)->length;
        }
        else {
            _1588 = 1;
        }
        if (_column_3426 > _1588)
        goto L5; // [63] 137

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3423)){
                _1590 = SEQ_PTR(_b_3423)->length;
        }
        else {
            _1590 = 1;
        }
        if (_column_3426 > _1590)
        goto L6; // [72] 121

        /** 				if not equal(a[column], b[column]) then*/
        _2 = (int)SEQ_PTR(_a_3422);
        _1592 = (int)*(((s1_ptr)_2)->base + _column_3426);
        _2 = (int)SEQ_PTR(_b_3423);
        _1593 = (int)*(((s1_ptr)_2)->base + _column_3426);
        if (_1592 == _1593)
        _1594 = 1;
        else if (IS_ATOM_INT(_1592) && IS_ATOM_INT(_1593))
        _1594 = 0;
        else
        _1594 = (compare(_1592, _1593) == 0);
        _1592 = NOVALUE;
        _1593 = NOVALUE;
        if (_1594 != 0)
        goto L7; // [90] 169
        _1594 = NOVALUE;

        /** 					return sign * eu:compare(a[column], b[column])*/
        _2 = (int)SEQ_PTR(_a_3422);
        _1596 = (int)*(((s1_ptr)_2)->base + _column_3426);
        _2 = (int)SEQ_PTR(_b_3423);
        _1597 = (int)*(((s1_ptr)_2)->base + _column_3426);
        if (IS_ATOM_INT(_1596) && IS_ATOM_INT(_1597)){
            _1598 = (_1596 < _1597) ? -1 : (_1596 > _1597);
        }
        else{
            _1598 = compare(_1596, _1597);
        }
        _1596 = NOVALUE;
        _1597 = NOVALUE;
        if (_sign_3425 == (short)_sign_3425)
        _1599 = _sign_3425 * _1598;
        else
        _1599 = NewDouble(_sign_3425 * (double)_1598);
        _1598 = NOVALUE;
        DeRef(_a_3422);
        DeRef(_b_3423);
        DeRef(_cols_3424);
        return _1599;
        goto L7; // [118] 169
L6: 

        /** 				return sign * -1*/
        if (_sign_3425 == (short)_sign_3425)
        _1600 = _sign_3425 * -1;
        else
        _1600 = NewDouble(_sign_3425 * (double)-1);
        DeRef(_a_3422);
        DeRef(_b_3423);
        DeRef(_cols_3424);
        DeRef(_1599);
        _1599 = NOVALUE;
        return _1600;
        goto L7; // [134] 169
L5: 

        /** 			if column <= length(b) then*/
        if (IS_SEQUENCE(_b_3423)){
                _1601 = SEQ_PTR(_b_3423)->length;
        }
        else {
            _1601 = 1;
        }
        if (_column_3426 > _1601)
        goto L8; // [142] 161

        /** 				return sign * 1*/
        _1603 = _sign_3425 * 1;
        DeRef(_a_3422);
        DeRef(_b_3423);
        DeRef(_cols_3424);
        DeRef(_1599);
        _1599 = NOVALUE;
        DeRef(_1600);
        _1600 = NOVALUE;
        return _1603;
        goto L9; // [158] 168
L8: 

        /** 				return 0*/
        DeRef(_a_3422);
        DeRef(_b_3423);
        DeRef(_cols_3424);
        DeRef(_1599);
        _1599 = NOVALUE;
        DeRef(_1600);
        _1600 = NOVALUE;
        DeRef(_1603);
        _1603 = NOVALUE;
        return 0;
L9: 
L7: 

        /** 	end for*/
        _i_3428 = _i_3428 + 1;
        goto L1; // [171] 13
L2: 
        ;
    }

    /** 	return 0*/
    DeRef(_a_3422);
    DeRef(_b_3423);
    DeRef(_cols_3424);
    DeRef(_1599);
    _1599 = NOVALUE;
    DeRef(_1600);
    _1600 = NOVALUE;
    DeRef(_1603);
    _1603 = NOVALUE;
    return 0;
    ;
}



// 0x802225DE
