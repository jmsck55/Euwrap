// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _11qmatch(int _p_1544, int _s_1545)
{
    int _k_1546 = NOVALUE;
    int _648 = NOVALUE;
    int _647 = NOVALUE;
    int _646 = NOVALUE;
    int _645 = NOVALUE;
    int _644 = NOVALUE;
    int _643 = NOVALUE;
    int _642 = NOVALUE;
    int _641 = NOVALUE;
    int _640 = NOVALUE;
    int _639 = NOVALUE;
    int _638 = NOVALUE;
    int _637 = NOVALUE;
    int _635 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find('?', p) then*/
    _635 = find_from(63, _p_1544, 1);
    if (_635 != 0)
    goto L1; // [12] 27
    _635 = NOVALUE;

    /** 		return match(p, s) -- fast*/
    _637 = e_match_from(_p_1544, _s_1545, 1);
    DeRefDS(_p_1544);
    DeRefDS(_s_1545);
    return _637;
L1: 

    /** 	for i = 1 to length(s) - length(p) + 1 do*/
    if (IS_SEQUENCE(_s_1545)){
            _638 = SEQ_PTR(_s_1545)->length;
    }
    else {
        _638 = 1;
    }
    if (IS_SEQUENCE(_p_1544)){
            _639 = SEQ_PTR(_p_1544)->length;
    }
    else {
        _639 = 1;
    }
    _640 = _638 - _639;
    _638 = NOVALUE;
    _639 = NOVALUE;
    _641 = _640 + 1;
    _640 = NOVALUE;
    {
        int _i_1552;
        _i_1552 = 1;
L2: 
        if (_i_1552 > _641){
            goto L3; // [43] 142
        }

        /** 		k = i*/
        _k_1546 = _i_1552;

        /** 		for j = 1 to length(p) do*/
        if (IS_SEQUENCE(_p_1544)){
                _642 = SEQ_PTR(_p_1544)->length;
        }
        else {
            _642 = 1;
        }
        {
            int _j_1558;
            _j_1558 = 1;
L4: 
            if (_j_1558 > _642){
                goto L5; // [62] 122
            }

            /** 			if p[j] != s[k] and p[j] != '?' then*/
            _2 = (int)SEQ_PTR(_p_1544);
            _643 = (int)*(((s1_ptr)_2)->base + _j_1558);
            _2 = (int)SEQ_PTR(_s_1545);
            _644 = (int)*(((s1_ptr)_2)->base + _k_1546);
            if (IS_ATOM_INT(_643) && IS_ATOM_INT(_644)) {
                _645 = (_643 != _644);
            }
            else {
                _645 = binary_op(NOTEQ, _643, _644);
            }
            _643 = NOVALUE;
            _644 = NOVALUE;
            if (IS_ATOM_INT(_645)) {
                if (_645 == 0) {
                    goto L6; // [83] 109
                }
            }
            else {
                if (DBL_PTR(_645)->dbl == 0.0) {
                    goto L6; // [83] 109
                }
            }
            _2 = (int)SEQ_PTR(_p_1544);
            _647 = (int)*(((s1_ptr)_2)->base + _j_1558);
            if (IS_ATOM_INT(_647)) {
                _648 = (_647 != 63);
            }
            else {
                _648 = binary_op(NOTEQ, _647, 63);
            }
            _647 = NOVALUE;
            if (_648 == 0) {
                DeRef(_648);
                _648 = NOVALUE;
                goto L6; // [96] 109
            }
            else {
                if (!IS_ATOM_INT(_648) && DBL_PTR(_648)->dbl == 0.0){
                    DeRef(_648);
                    _648 = NOVALUE;
                    goto L6; // [96] 109
                }
                DeRef(_648);
                _648 = NOVALUE;
            }
            DeRef(_648);
            _648 = NOVALUE;

            /** 				k = 0*/
            _k_1546 = 0;

            /** 				exit*/
            goto L5; // [106] 122
L6: 

            /** 			k += 1*/
            _k_1546 = _k_1546 + 1;

            /** 		end for*/
            _j_1558 = _j_1558 + 1;
            goto L4; // [117] 69
L5: 
            ;
        }

        /** 		if k != 0 then*/
        if (_k_1546 == 0)
        goto L7; // [124] 135

        /** 			return i*/
        DeRefDS(_p_1544);
        DeRefDS(_s_1545);
        DeRef(_641);
        _641 = NOVALUE;
        DeRef(_645);
        _645 = NOVALUE;
        return _i_1552;
L7: 

        /** 	end for*/
        _i_1552 = _i_1552 + 1;
        goto L2; // [137] 50
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_p_1544);
    DeRefDS(_s_1545);
    DeRef(_641);
    _641 = NOVALUE;
    DeRef(_645);
    _645 = NOVALUE;
    return 0;
    ;
}


int _11is_match(int _pattern_1573, int _string_1574)
{
    int _p_1575 = NOVALUE;
    int _f_1576 = NOVALUE;
    int _t_1577 = NOVALUE;
    int _match_string_1578 = NOVALUE;
    int _691 = NOVALUE;
    int _690 = NOVALUE;
    int _688 = NOVALUE;
    int _684 = NOVALUE;
    int _683 = NOVALUE;
    int _682 = NOVALUE;
    int _679 = NOVALUE;
    int _678 = NOVALUE;
    int _675 = NOVALUE;
    int _672 = NOVALUE;
    int _670 = NOVALUE;
    int _668 = NOVALUE;
    int _666 = NOVALUE;
    int _663 = NOVALUE;
    int _660 = NOVALUE;
    int _658 = NOVALUE;
    int _657 = NOVALUE;
    int _656 = NOVALUE;
    int _655 = NOVALUE;
    int _653 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pattern = pattern & END_MARKER*/
    Append(&_pattern_1573, _pattern_1573, -1);

    /** 	string = string & END_MARKER*/
    Append(&_string_1574, _string_1574, -1);

    /** 	p = 1*/
    _p_1575 = 1;

    /** 	f = 1*/
    _f_1576 = 1;

    /** 	while f <= length(string) do*/
L1: 
    if (IS_SEQUENCE(_string_1574)){
            _653 = SEQ_PTR(_string_1574)->length;
    }
    else {
        _653 = 1;
    }
    if (_f_1576 > _653)
    goto L2; // [35] 288

    /** 		if not find(pattern[p], {string[f], '?'}) then*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _655 = (int)*(((s1_ptr)_2)->base + _p_1575);
    _2 = (int)SEQ_PTR(_string_1574);
    _656 = (int)*(((s1_ptr)_2)->base + _f_1576);
    Ref(_656);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _656;
    ((int *)_2)[2] = 63;
    _657 = MAKE_SEQ(_1);
    _656 = NOVALUE;
    _658 = find_from(_655, _657, 1);
    _655 = NOVALUE;
    DeRefDS(_657);
    _657 = NOVALUE;
    if (_658 != 0)
    goto L3; // [58] 248
    _658 = NOVALUE;

    /** 			if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _660 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(NOTEQ, _660, 42)){
        _660 = NOVALUE;
        goto L4; // [67] 240
    }
    _660 = NOVALUE;

    /** 				while pattern[p] = '*' do*/
L5: 
    _2 = (int)SEQ_PTR(_pattern_1573);
    _663 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(NOTEQ, _663, 42)){
        _663 = NOVALUE;
        goto L6; // [80] 95
    }
    _663 = NOVALUE;

    /** 					p += 1*/
    _p_1575 = _p_1575 + 1;

    /** 				end while*/
    goto L5; // [92] 76
L6: 

    /** 				if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _666 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(NOTEQ, _666, -1)){
        _666 = NOVALUE;
        goto L7; // [101] 112
    }
    _666 = NOVALUE;

    /** 					return 1*/
    DeRefDS(_pattern_1573);
    DeRefDS(_string_1574);
    DeRef(_match_string_1578);
    return 1;
L7: 

    /** 				match_string = ""*/
    RefDS(_5);
    DeRef(_match_string_1578);
    _match_string_1578 = _5;

    /** 				while pattern[p] != '*' do*/
L8: 
    _2 = (int)SEQ_PTR(_pattern_1573);
    _668 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(EQUALS, _668, 42)){
        _668 = NOVALUE;
        goto L9; // [128] 168
    }
    _668 = NOVALUE;

    /** 					match_string = match_string & pattern[p]*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _670 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (IS_SEQUENCE(_match_string_1578) && IS_ATOM(_670)) {
        Ref(_670);
        Append(&_match_string_1578, _match_string_1578, _670);
    }
    else if (IS_ATOM(_match_string_1578) && IS_SEQUENCE(_670)) {
    }
    else {
        Concat((object_ptr)&_match_string_1578, _match_string_1578, _670);
    }
    _670 = NOVALUE;

    /** 					if pattern[p] = END_MARKER then*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _672 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(NOTEQ, _672, -1)){
        _672 = NOVALUE;
        goto LA; // [148] 157
    }
    _672 = NOVALUE;

    /** 						exit*/
    goto L9; // [154] 168
LA: 

    /** 					p += 1*/
    _p_1575 = _p_1575 + 1;

    /** 				end while*/
    goto L8; // [165] 124
L9: 

    /** 				if pattern[p] = '*' then*/
    _2 = (int)SEQ_PTR(_pattern_1573);
    _675 = (int)*(((s1_ptr)_2)->base + _p_1575);
    if (binary_op_a(NOTEQ, _675, 42)){
        _675 = NOVALUE;
        goto LB; // [174] 185
    }
    _675 = NOVALUE;

    /** 					p -= 1*/
    _p_1575 = _p_1575 - 1;
LB: 

    /** 				t = qmatch(match_string, string[f..$])*/
    if (IS_SEQUENCE(_string_1574)){
            _678 = SEQ_PTR(_string_1574)->length;
    }
    else {
        _678 = 1;
    }
    rhs_slice_target = (object_ptr)&_679;
    RHS_Slice(_string_1574, _f_1576, _678);
    RefDS(_match_string_1578);
    _t_1577 = _11qmatch(_match_string_1578, _679);
    _679 = NOVALUE;
    if (!IS_ATOM_INT(_t_1577)) {
        _1 = (long)(DBL_PTR(_t_1577)->dbl);
        DeRefDS(_t_1577);
        _t_1577 = _1;
    }

    /** 				if t = 0 then*/
    if (_t_1577 != 0)
    goto LC; // [204] 217

    /** 					return 0*/
    DeRefDS(_pattern_1573);
    DeRefDS(_string_1574);
    DeRefDS(_match_string_1578);
    return 0;
    goto LD; // [214] 247
LC: 

    /** 					f += t + length(match_string) - 2*/
    if (IS_SEQUENCE(_match_string_1578)){
            _682 = SEQ_PTR(_match_string_1578)->length;
    }
    else {
        _682 = 1;
    }
    _683 = _t_1577 + _682;
    if ((long)((unsigned long)_683 + (unsigned long)HIGH_BITS) >= 0) 
    _683 = NewDouble((double)_683);
    _682 = NOVALUE;
    if (IS_ATOM_INT(_683)) {
        _684 = _683 - 2;
        if ((long)((unsigned long)_684 +(unsigned long) HIGH_BITS) >= 0){
            _684 = NewDouble((double)_684);
        }
    }
    else {
        _684 = NewDouble(DBL_PTR(_683)->dbl - (double)2);
    }
    DeRef(_683);
    _683 = NOVALUE;
    if (IS_ATOM_INT(_684)) {
        _f_1576 = _f_1576 + _684;
    }
    else {
        _f_1576 = NewDouble((double)_f_1576 + DBL_PTR(_684)->dbl);
    }
    DeRef(_684);
    _684 = NOVALUE;
    if (!IS_ATOM_INT(_f_1576)) {
        _1 = (long)(DBL_PTR(_f_1576)->dbl);
        DeRefDS(_f_1576);
        _f_1576 = _1;
    }
    goto LD; // [237] 247
L4: 

    /** 				return 0*/
    DeRefDS(_pattern_1573);
    DeRefDS(_string_1574);
    DeRef(_match_string_1578);
    return 0;
LD: 
L3: 

    /** 		p += 1*/
    _p_1575 = _p_1575 + 1;

    /** 		f += 1*/
    _f_1576 = _f_1576 + 1;

    /** 		if p > length(pattern) then*/
    if (IS_SEQUENCE(_pattern_1573)){
            _688 = SEQ_PTR(_pattern_1573)->length;
    }
    else {
        _688 = 1;
    }
    if (_p_1575 <= _688)
    goto L1; // [265] 32

    /** 			return f > length(string) */
    if (IS_SEQUENCE(_string_1574)){
            _690 = SEQ_PTR(_string_1574)->length;
    }
    else {
        _690 = 1;
    }
    _691 = (_f_1576 > _690);
    _690 = NOVALUE;
    DeRefDS(_pattern_1573);
    DeRefDS(_string_1574);
    DeRef(_match_string_1578);
    return _691;

    /** 	end while*/
    goto L1; // [285] 32
L2: 

    /** 	return 0*/
    DeRefDS(_pattern_1573);
    DeRefDS(_string_1574);
    DeRef(_match_string_1578);
    DeRef(_691);
    _691 = NOVALUE;
    return 0;
    ;
}



// 0x82BBBA53
