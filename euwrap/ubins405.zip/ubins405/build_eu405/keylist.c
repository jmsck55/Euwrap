// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _62find_category(int _tokid_23321)
{
    int _catname_23322 = NOVALUE;
    int _13465 = NOVALUE;
    int _13464 = NOVALUE;
    int _13462 = NOVALUE;
    int _13461 = NOVALUE;
    int _13460 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23321)) {
        _1 = (long)(DBL_PTR(_tokid_23321)->dbl);
        DeRefDS(_tokid_23321);
        _tokid_23321 = _1;
    }

    /** 	sequence catname = "reserved word"*/
    RefDS(_13459);
    DeRef(_catname_23322);
    _catname_23322 = _13459;

    /** 	for i = 1 to length(token_category) do*/
    _13460 = 73;
    {
        int _i_23325;
        _i_23325 = 1;
L1: 
        if (_i_23325 > 73){
            goto L2; // [17] 72
        }

        /** 		if token_category[i][1] = tokid then*/
        _2 = (int)SEQ_PTR(_28token_category_11229);
        _13461 = (int)*(((s1_ptr)_2)->base + _i_23325);
        _2 = (int)SEQ_PTR(_13461);
        _13462 = (int)*(((s1_ptr)_2)->base + 1);
        _13461 = NOVALUE;
        if (binary_op_a(NOTEQ, _13462, _tokid_23321)){
            _13462 = NOVALUE;
            goto L3; // [36] 65
        }
        _13462 = NOVALUE;

        /** 			catname = token_catname[token_category[i][2]]*/
        _2 = (int)SEQ_PTR(_28token_category_11229);
        _13464 = (int)*(((s1_ptr)_2)->base + _i_23325);
        _2 = (int)SEQ_PTR(_13464);
        _13465 = (int)*(((s1_ptr)_2)->base + 2);
        _13464 = NOVALUE;
        DeRef(_catname_23322);
        _2 = (int)SEQ_PTR(_28token_catname_11216);
        if (!IS_ATOM_INT(_13465)){
            _catname_23322 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_13465)->dbl));
        }
        else{
            _catname_23322 = (int)*(((s1_ptr)_2)->base + _13465);
        }
        RefDS(_catname_23322);

        /** 			exit*/
        goto L2; // [62] 72
L3: 

        /** 	end for*/
        _i_23325 = _i_23325 + 1;
        goto L1; // [67] 24
L2: 
        ;
    }

    /** 	return catname*/
    _13465 = NOVALUE;
    return _catname_23322;
    ;
}


int _62find_token_text(int _tokid_23340)
{
    int _13474 = NOVALUE;
    int _13472 = NOVALUE;
    int _13471 = NOVALUE;
    int _13469 = NOVALUE;
    int _13468 = NOVALUE;
    int _13467 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tokid_23340)) {
        _1 = (long)(DBL_PTR(_tokid_23340)->dbl);
        DeRefDS(_tokid_23340);
        _tokid_23340 = _1;
    }

    /** 	for i = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22497)){
            _13467 = SEQ_PTR(_62keylist_22497)->length;
    }
    else {
        _13467 = 1;
    }
    {
        int _i_23342;
        _i_23342 = 1;
L1: 
        if (_i_23342 > _13467){
            goto L2; // [10] 57
        }

        /** 		if keylist[i][3] = tokid then*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _13468 = (int)*(((s1_ptr)_2)->base + _i_23342);
        _2 = (int)SEQ_PTR(_13468);
        _13469 = (int)*(((s1_ptr)_2)->base + 3);
        _13468 = NOVALUE;
        if (binary_op_a(NOTEQ, _13469, _tokid_23340)){
            _13469 = NOVALUE;
            goto L3; // [29] 50
        }
        _13469 = NOVALUE;

        /** 			return keylist[i][1]*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _13471 = (int)*(((s1_ptr)_2)->base + _i_23342);
        _2 = (int)SEQ_PTR(_13471);
        _13472 = (int)*(((s1_ptr)_2)->base + 1);
        _13471 = NOVALUE;
        Ref(_13472);
        return _13472;
L3: 

        /** 	end for*/
        _i_23342 = _i_23342 + 1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	return LexName(tokid, "unknown word")*/
    RefDS(_13473);
    _13474 = _37LexName(_tokid_23340, _13473);
    _13472 = NOVALUE;
    return _13474;
    ;
}



// 0x3549B8C7
