// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _29clear_fwd_refs()
{
    int _0, _1, _2;
    

    /** 	fwdref_count = 0*/
    _29fwdref_count_61081 = 0;

    /** end procedure*/
    return;
    ;
}


int _29get_fwdref_count()
{
    int _0, _1, _2;
    

    /** 	return fwdref_count*/
    return _29fwdref_count_61081;
    ;
}


void _29set_glabel_block(int _ref_61088, int _block_61090)
{
    int _30525 = NOVALUE;
    int _30524 = NOVALUE;
    int _30522 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61088)) {
        _1 = (long)(DBL_PTR(_ref_61088)->dbl);
        DeRefDS(_ref_61088);
        _ref_61088 = _1;
    }
    if (!IS_ATOM_INT(_block_61090)) {
        _1 = (long)(DBL_PTR(_block_61090)->dbl);
        DeRefDS(_block_61090);
        _block_61090 = _1;
    }

    /** 	forward_references[ref][FR_DATA] &= block*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61088 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30524 = (int)*(((s1_ptr)_2)->base + 12);
    _30522 = NOVALUE;
    if (IS_SEQUENCE(_30524) && IS_ATOM(_block_61090)) {
        Append(&_30525, _30524, _block_61090);
    }
    else if (IS_ATOM(_30524) && IS_SEQUENCE(_block_61090)) {
    }
    else {
        Concat((object_ptr)&_30525, _30524, _block_61090);
        _30524 = NOVALUE;
    }
    _30524 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30525;
    if( _1 != _30525 ){
        DeRef(_1);
    }
    _30525 = NOVALUE;
    _30522 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _29replace_code(int _code_61102, int _start_61103, int _finish_61104, int _subprog_61105)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_finish_61104)) {
        _1 = (long)(DBL_PTR(_finish_61104)->dbl);
        DeRefDS(_finish_61104);
        _finish_61104 = _1;
    }
    if (!IS_ATOM_INT(_subprog_61105)) {
        _1 = (long)(DBL_PTR(_subprog_61105)->dbl);
        DeRefDS(_subprog_61105);
        _subprog_61105 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_61105;

    /** 	shift:replace_code( code, start, finish )*/
    RefDS(_code_61102);
    _64replace_code(_code_61102, _start_61103, _finish_61104);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    DeRefDS(_code_61102);
    return;
    ;
}


void _29resolved_reference(int _ref_61108)
{
    int _file_61109 = NOVALUE;
    int _subprog_61112 = NOVALUE;
    int _tx_61115 = NOVALUE;
    int _ax_61116 = NOVALUE;
    int _sp_61117 = NOVALUE;
    int _r_61132 = NOVALUE;
    int _r_61150 = NOVALUE;
    int _30549 = NOVALUE;
    int _30548 = NOVALUE;
    int _30547 = NOVALUE;
    int _30545 = NOVALUE;
    int _30542 = NOVALUE;
    int _30540 = NOVALUE;
    int _30538 = NOVALUE;
    int _30537 = NOVALUE;
    int _30535 = NOVALUE;
    int _30533 = NOVALUE;
    int _30531 = NOVALUE;
    int _30530 = NOVALUE;
    int _30528 = NOVALUE;
    int _30526 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 		file    = forward_references[ref][FR_FILE],*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30526 = (int)*(((s1_ptr)_2)->base + _ref_61108);
    _2 = (int)SEQ_PTR(_30526);
    _file_61109 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_61109)){
        _file_61109 = (long)DBL_PTR(_file_61109)->dbl;
    }
    _30526 = NOVALUE;

    /** 		subprog = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30528 = (int)*(((s1_ptr)_2)->base + _ref_61108);
    _2 = (int)SEQ_PTR(_30528);
    _subprog_61112 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_subprog_61112)){
        _subprog_61112 = (long)DBL_PTR(_subprog_61112)->dbl;
    }
    _30528 = NOVALUE;

    /** 		tx = 0,*/
    _tx_61115 = 0;

    /** 		ax = 0,*/
    _ax_61116 = 0;

    /** 		sp = 0*/
    _sp_61117 = 0;

    /** 	if forward_references[ref][FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30530 = (int)*(((s1_ptr)_2)->base + _ref_61108);
    _2 = (int)SEQ_PTR(_30530);
    _30531 = (int)*(((s1_ptr)_2)->base + 4);
    _30530 = NOVALUE;
    if (binary_op_a(NOTEQ, _30531, _12TopLevelSub_11689)){
        _30531 = NOVALUE;
        goto L1; // [60] 80
    }
    _30531 = NOVALUE;

    /** 		tx = find( ref, toplevel_references[file] )*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    _30533 = (int)*(((s1_ptr)_2)->base + _file_61109);
    _tx_61115 = find_from(_ref_61108, _30533, 1);
    _30533 = NOVALUE;
    goto L2; // [77] 111
L1: 

    /** 		sp = find( subprog, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _30535 = (int)*(((s1_ptr)_2)->base + _file_61109);
    _sp_61117 = find_from(_subprog_61112, _30535, 1);
    _30535 = NOVALUE;

    /** 		ax = find( ref, active_references[file][sp] )*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _30537 = (int)*(((s1_ptr)_2)->base + _file_61109);
    _2 = (int)SEQ_PTR(_30537);
    _30538 = (int)*(((s1_ptr)_2)->base + _sp_61117);
    _30537 = NOVALUE;
    _ax_61116 = find_from(_ref_61108, _30538, 1);
    _30538 = NOVALUE;
L2: 

    /** 	if ax then*/
    if (_ax_61116 == 0)
    {
        goto L3; // [113] 253
    }
    else{
    }

    /** 		sequence r = active_references[file][sp] */
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _30540 = (int)*(((s1_ptr)_2)->base + _file_61109);
    DeRef(_r_61132);
    _2 = (int)SEQ_PTR(_30540);
    _r_61132 = (int)*(((s1_ptr)_2)->base + _sp_61117);
    Ref(_r_61132);
    _30540 = NOVALUE;

    /** 		active_references[file][sp] = 0*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61109 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61117);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30542 = NOVALUE;

    /** 		r = remove( r, ax )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61132);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ax_61116)) ? _ax_61116 : (long)(DBL_PTR(_ax_61116)->dbl);
        int stop = (IS_ATOM_INT(_ax_61116)) ? _ax_61116 : (long)(DBL_PTR(_ax_61116)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61132), start, &_r_61132 );
            }
            else Tail(SEQ_PTR(_r_61132), stop+1, &_r_61132);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61132), start, &_r_61132);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61132 = Remove_elements(start, stop, (SEQ_PTR(_r_61132)->ref == 1));
        }
    }

    /** 		active_references[file][sp] = r*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_61109 + ((s1_ptr)_2)->base);
    RefDS(_r_61132);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_61117);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61132;
    DeRef(_1);
    _30545 = NOVALUE;

    /** 		if not length( active_references[file][sp] ) then*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _30547 = (int)*(((s1_ptr)_2)->base + _file_61109);
    _2 = (int)SEQ_PTR(_30547);
    _30548 = (int)*(((s1_ptr)_2)->base + _sp_61117);
    _30547 = NOVALUE;
    if (IS_SEQUENCE(_30548)){
            _30549 = SEQ_PTR(_30548)->length;
    }
    else {
        _30549 = 1;
    }
    _30548 = NOVALUE;
    if (_30549 != 0)
    goto L4; // [178] 248
    _30549 = NOVALUE;

    /** 			r = active_references[file]*/
    DeRefDS(_r_61132);
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _r_61132 = (int)*(((s1_ptr)_2)->base + _file_61109);
    Ref(_r_61132);

    /** 			active_references[file] = 0*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r, sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61132);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61117)) ? _sp_61117 : (long)(DBL_PTR(_sp_61117)->dbl);
        int stop = (IS_ATOM_INT(_sp_61117)) ? _sp_61117 : (long)(DBL_PTR(_sp_61117)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61132), start, &_r_61132 );
            }
            else Tail(SEQ_PTR(_r_61132), stop+1, &_r_61132);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61132), start, &_r_61132);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61132 = Remove_elements(start, stop, (SEQ_PTR(_r_61132)->ref == 1));
        }
    }

    /** 			active_references[file] = r*/
    RefDS(_r_61132);
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61132;
    DeRef(_1);

    /** 			r = active_subprogs[file]*/
    DeRefDS(_r_61132);
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _r_61132 = (int)*(((s1_ptr)_2)->base + _file_61109);
    Ref(_r_61132);

    /** 			active_subprogs[file] = 0*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61062 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			r = remove( r,   sp )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61132);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_sp_61117)) ? _sp_61117 : (long)(DBL_PTR(_sp_61117)->dbl);
        int stop = (IS_ATOM_INT(_sp_61117)) ? _sp_61117 : (long)(DBL_PTR(_sp_61117)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61132), start, &_r_61132 );
            }
            else Tail(SEQ_PTR(_r_61132), stop+1, &_r_61132);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61132), start, &_r_61132);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61132 = Remove_elements(start, stop, (SEQ_PTR(_r_61132)->ref == 1));
        }
    }

    /** 			active_subprogs[file] = r*/
    RefDS(_r_61132);
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61062 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61132;
    DeRef(_1);
L4: 
    DeRef(_r_61132);
    _r_61132 = NOVALUE;
    goto L5; // [250] 303
L3: 

    /** 	elsif tx then*/
    if (_tx_61115 == 0)
    {
        goto L6; // [255] 296
    }
    else{
    }

    /** 		sequence r = toplevel_references[file]*/
    DeRef(_r_61150);
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    _r_61150 = (int)*(((s1_ptr)_2)->base + _file_61109);
    Ref(_r_61150);

    /** 		toplevel_references[file] = 0*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61064 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		r = remove( r, tx )*/
    {
        s1_ptr assign_space = SEQ_PTR(_r_61150);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_tx_61115)) ? _tx_61115 : (long)(DBL_PTR(_tx_61115)->dbl);
        int stop = (IS_ATOM_INT(_tx_61115)) ? _tx_61115 : (long)(DBL_PTR(_tx_61115)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_r_61150), start, &_r_61150 );
            }
            else Tail(SEQ_PTR(_r_61150), stop+1, &_r_61150);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_r_61150), start, &_r_61150);
        }
        else {
            assign_slice_seq = &assign_space;
            _r_61150 = Remove_elements(start, stop, (SEQ_PTR(_r_61150)->ref == 1));
        }
    }

    /** 		toplevel_references[file] = r*/
    RefDS(_r_61150);
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61064 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_61109);
    _1 = *(int *)_2;
    *(int *)_2 = _r_61150;
    DeRef(_1);
    DeRefDS(_r_61150);
    _r_61150 = NOVALUE;
    goto L5; // [293] 303
L6: 

    /** 		InternalErr( 260 )*/
    RefDS(_21829);
    _43InternalErr(260, _21829);
L5: 

    /** 	inactive_references &= ref*/
    Append(&_29inactive_references_61065, _29inactive_references_61065, _ref_61108);

    /** 	forward_references[ref] = 0*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_61108);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** end procedure*/
    _30548 = NOVALUE;
    return;
    ;
}


void _29set_code(int _ref_61164)
{
    int _30565 = NOVALUE;
    int _30563 = NOVALUE;
    int _30561 = NOVALUE;
    int _30558 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	patch_code_sub = forward_references[ref][FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30558 = (int)*(((s1_ptr)_2)->base + _ref_61164);
    _2 = (int)SEQ_PTR(_30558);
    _29patch_code_sub_61159 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29patch_code_sub_61159)){
        _29patch_code_sub_61159 = (long)DBL_PTR(_29patch_code_sub_61159)->dbl;
    }
    _30558 = NOVALUE;

    /** 	if patch_code_sub != CurrentSub then*/
    if (_29patch_code_sub_61159 == _12CurrentSub_11690)
    goto L1; // [23] 119

    /** 		patch_code_temp = Code*/
    RefDS(_12Code_11771);
    DeRef(_29patch_code_temp_61156);
    _29patch_code_temp_61156 = _12Code_11771;

    /** 		patch_linetab_temp = LineTable*/
    RefDS(_12LineTable_11772);
    DeRef(_29patch_linetab_temp_61157);
    _29patch_linetab_temp_61157 = _12LineTable_11772;

    /** 		Code = SymTab[patch_code_sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30561 = (int)*(((s1_ptr)_2)->base + _29patch_code_sub_61159);
    DeRefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(_30561);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _30561 = NOVALUE;

    /** 		SymTab[patch_code_sub][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61159 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30563 = NOVALUE;

    /** 		LineTable = SymTab[patch_code_sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30565 = (int)*(((s1_ptr)_2)->base + _29patch_code_sub_61159);
    DeRefDS(_12LineTable_11772);
    _2 = (int)SEQ_PTR(_30565);
    if (!IS_ATOM_INT(_12S_LINETAB_11389)){
        _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    }
    else{
        _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    }
    Ref(_12LineTable_11772);
    _30565 = NOVALUE;

    /** 		patch_current_sub = CurrentSub*/
    _29patch_current_sub_61161 = _12CurrentSub_11690;

    /** 		CurrentSub = patch_code_sub*/
    _12CurrentSub_11690 = _29patch_code_sub_61159;
    goto L2; // [116] 129
L1: 

    /** 		patch_current_sub = patch_code_sub*/
    _29patch_current_sub_61161 = _29patch_code_sub_61159;
L2: 

    /** end procedure*/
    return;
    ;
}


void _29reset_code()
{
    int _30569 = NOVALUE;
    int _30567 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[patch_code_sub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61159 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _30567 = NOVALUE;

    /** 	SymTab[patch_code_sub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29patch_code_sub_61159 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_11772);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = _12LineTable_11772;
    DeRef(_1);
    _30569 = NOVALUE;

    /** 	if patch_code_sub != patch_current_sub then*/
    if (_29patch_code_sub_61159 == _29patch_current_sub_61161)
    goto L1; // [45] 77

    /** 		CurrentSub = patch_current_sub*/
    _12CurrentSub_11690 = _29patch_current_sub_61161;

    /** 		Code = patch_code_temp*/
    RefDS(_29patch_code_temp_61156);
    DeRefDS(_12Code_11771);
    _12Code_11771 = _29patch_code_temp_61156;

    /** 		LineTable = patch_linetab_temp*/
    RefDS(_29patch_linetab_temp_61157);
    DeRefDS(_12LineTable_11772);
    _12LineTable_11772 = _29patch_linetab_temp_61157;
L1: 

    /** 	patch_code_temp = {}*/
    RefDS(_21829);
    DeRef(_29patch_code_temp_61156);
    _29patch_code_temp_61156 = _21829;

    /** 	patch_linetab_temp = {}*/
    RefDS(_21829);
    DeRef(_29patch_linetab_temp_61157);
    _29patch_linetab_temp_61157 = _21829;

    /** end procedure*/
    return;
    ;
}


void _29set_data(int _ref_61208, int _data_61209)
{
    int _30572 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61208)) {
        _1 = (long)(DBL_PTR(_ref_61208)->dbl);
        DeRefDS(_ref_61208);
        _ref_61208 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61208 + ((s1_ptr)_2)->base);
    Ref(_data_61209);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_61209;
    DeRef(_1);
    _30572 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61209);
    return;
    ;
}


void _29add_data(int _ref_61214, int _data_61215)
{
    int _30578 = NOVALUE;
    int _30577 = NOVALUE;
    int _30576 = NOVALUE;
    int _30574 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61214)) {
        _1 = (long)(DBL_PTR(_ref_61214)->dbl);
        DeRefDS(_ref_61214);
        _ref_61214 = _1;
    }

    /** 	forward_references[ref][FR_DATA] = append( forward_references[ref][FR_DATA], data )*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61214 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30576 = (int)*(((s1_ptr)_2)->base + _ref_61214);
    _2 = (int)SEQ_PTR(_30576);
    _30577 = (int)*(((s1_ptr)_2)->base + 12);
    _30576 = NOVALUE;
    Ref(_data_61215);
    Append(&_30578, _30577, _data_61215);
    _30577 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30578;
    if( _1 != _30578 ){
        DeRef(_1);
    }
    _30578 = NOVALUE;
    _30574 = NOVALUE;

    /** end procedure*/
    DeRef(_data_61215);
    return;
    ;
}


void _29set_line(int _ref_61223, int _line_no_61224, int _this_line_61225, int _bp_61226)
{
    int _30583 = NOVALUE;
    int _30581 = NOVALUE;
    int _30579 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_ref_61223)) {
        _1 = (long)(DBL_PTR(_ref_61223)->dbl);
        DeRefDS(_ref_61223);
        _ref_61223 = _1;
    }
    if (!IS_ATOM_INT(_line_no_61224)) {
        _1 = (long)(DBL_PTR(_line_no_61224)->dbl);
        DeRefDS(_line_no_61224);
        _line_no_61224 = _1;
    }
    if (!IS_ATOM_INT(_bp_61226)) {
        _1 = (long)(DBL_PTR(_bp_61226)->dbl);
        DeRefDS(_bp_61226);
        _bp_61226 = _1;
    }

    /** 	forward_references[ref][FR_LINE] = line_no*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61223 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _line_no_61224;
    DeRef(_1);
    _30579 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE] = this_line*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61223 + ((s1_ptr)_2)->base);
    RefDS(_this_line_61225);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _this_line_61225;
    DeRef(_1);
    _30581 = NOVALUE;

    /** 	forward_references[ref][FR_BP] = bp*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_61223 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _bp_61226;
    DeRef(_1);
    _30583 = NOVALUE;

    /** end procedure*/
    DeRefDS(_this_line_61225);
    return;
    ;
}


void _29add_private_symbol(int _sym_61238, int _name_61239)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_61238)) {
        _1 = (long)(DBL_PTR(_sym_61238)->dbl);
        DeRefDS(_sym_61238);
        _sym_61238 = _1;
    }

    /** 	fwd_private_sym &= sym*/
    Append(&_29fwd_private_sym_61233, _29fwd_private_sym_61233, _sym_61238);

    /** 	fwd_private_name = append( fwd_private_name, name )*/
    RefDS(_name_61239);
    Append(&_29fwd_private_name_61234, _29fwd_private_name_61234, _name_61239);

    /** end procedure*/
    DeRefDS(_name_61239);
    return;
    ;
}


void _29patch_forward_goto(int _tok_61247, int _ref_61248)
{
    int _fr_61249 = NOVALUE;
    int _30599 = NOVALUE;
    int _30598 = NOVALUE;
    int _30597 = NOVALUE;
    int _30596 = NOVALUE;
    int _30595 = NOVALUE;
    int _30594 = NOVALUE;
    int _30593 = NOVALUE;
    int _30592 = NOVALUE;
    int _30590 = NOVALUE;
    int _30589 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61249);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61249 = (int)*(((s1_ptr)_2)->base + _ref_61248);
    Ref(_fr_61249);

    /** 	set_code( ref )*/
    _29set_code(_ref_61248);

    /** 	shifting_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61249);
    _29shifting_sub_61080 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_29shifting_sub_61080))
    _29shifting_sub_61080 = (long)DBL_PTR(_29shifting_sub_61080)->dbl;

    /** 	if length( fr[FR_DATA] ) = 2 then*/
    _2 = (int)SEQ_PTR(_fr_61249);
    _30589 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30589)){
            _30590 = SEQ_PTR(_30589)->length;
    }
    else {
        _30590 = 1;
    }
    _30589 = NOVALUE;
    if (_30590 != 2)
    goto L1; // [33] 62

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61248);

    /** 		CompileErr( 156, { fr[FR_DATA][2] })*/
    _2 = (int)SEQ_PTR(_fr_61249);
    _30592 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30592);
    _30593 = (int)*(((s1_ptr)_2)->base + 2);
    _30592 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30593);
    *((int *)(_2+4)) = _30593;
    _30594 = MAKE_SEQ(_1);
    _30593 = NOVALUE;
    _43CompileErr(156, _30594, 0);
    _30594 = NOVALUE;
L1: 

    /** 	Goto_block(  fr[FR_DATA][1], fr[FR_DATA][3], fr[FR_PC] )*/
    _2 = (int)SEQ_PTR(_fr_61249);
    _30595 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30595);
    _30596 = (int)*(((s1_ptr)_2)->base + 1);
    _30595 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61249);
    _30597 = (int)*(((s1_ptr)_2)->base + 12);
    _2 = (int)SEQ_PTR(_30597);
    _30598 = (int)*(((s1_ptr)_2)->base + 3);
    _30597 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61249);
    _30599 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30596);
    Ref(_30598);
    Ref(_30599);
    _65Goto_block(_30596, _30598, _30599);
    _30596 = NOVALUE;
    _30598 = NOVALUE;
    _30599 = NOVALUE;

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** 	reset_code()*/
    _29reset_code();

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61248);

    /** end procedure*/
    DeRefDS(_fr_61249);
    _30589 = NOVALUE;
    return;
    ;
}


void _29patch_forward_call(int _tok_61270, int _ref_61271)
{
    int _fr_61272 = NOVALUE;
    int _sub_61275 = NOVALUE;
    int _defarg_61281 = NOVALUE;
    int _paramsym_61285 = NOVALUE;
    int _old_61288 = NOVALUE;
    int _tx_61292 = NOVALUE;
    int _code_sub_61302 = NOVALUE;
    int _args_61304 = NOVALUE;
    int _is_func_61309 = NOVALUE;
    int _real_file_61323 = NOVALUE;
    int _code_61327 = NOVALUE;
    int _temp_sub_61329 = NOVALUE;
    int _pc_61331 = NOVALUE;
    int _next_pc_61333 = NOVALUE;
    int _supplied_args_61334 = NOVALUE;
    int _name_61337 = NOVALUE;
    int _old_temps_allocated_61361 = NOVALUE;
    int _temp_target_61370 = NOVALUE;
    int _converted_code_61373 = NOVALUE;
    int _target_61389 = NOVALUE;
    int _has_defaults_61395 = NOVALUE;
    int _goto_target_61396 = NOVALUE;
    int _defarg_61399 = NOVALUE;
    int _code_len_61400 = NOVALUE;
    int _extra_default_args_61402 = NOVALUE;
    int _param_sym_61405 = NOVALUE;
    int _params_61406 = NOVALUE;
    int _orig_code_61408 = NOVALUE;
    int _orig_linetable_61409 = NOVALUE;
    int _ar_sp_61412 = NOVALUE;
    int _pre_refs_61416 = NOVALUE;
    int _old_fwd_params_61431 = NOVALUE;
    int _temp_shifting_sub_61472 = NOVALUE;
    int _new_code_61476 = NOVALUE;
    int _routine_type_61485 = NOVALUE;
    int _31351 = NOVALUE;
    int _30735 = NOVALUE;
    int _30734 = NOVALUE;
    int _30733 = NOVALUE;
    int _30731 = NOVALUE;
    int _30730 = NOVALUE;
    int _30729 = NOVALUE;
    int _30728 = NOVALUE;
    int _30727 = NOVALUE;
    int _30726 = NOVALUE;
    int _30725 = NOVALUE;
    int _30724 = NOVALUE;
    int _30723 = NOVALUE;
    int _30722 = NOVALUE;
    int _30721 = NOVALUE;
    int _30720 = NOVALUE;
    int _30719 = NOVALUE;
    int _30717 = NOVALUE;
    int _30716 = NOVALUE;
    int _30715 = NOVALUE;
    int _30714 = NOVALUE;
    int _30713 = NOVALUE;
    int _30712 = NOVALUE;
    int _30711 = NOVALUE;
    int _30710 = NOVALUE;
    int _30708 = NOVALUE;
    int _30705 = NOVALUE;
    int _30704 = NOVALUE;
    int _30703 = NOVALUE;
    int _30702 = NOVALUE;
    int _30698 = NOVALUE;
    int _30697 = NOVALUE;
    int _30696 = NOVALUE;
    int _30695 = NOVALUE;
    int _30694 = NOVALUE;
    int _30692 = NOVALUE;
    int _30691 = NOVALUE;
    int _30690 = NOVALUE;
    int _30689 = NOVALUE;
    int _30688 = NOVALUE;
    int _30687 = NOVALUE;
    int _30685 = NOVALUE;
    int _30684 = NOVALUE;
    int _30682 = NOVALUE;
    int _30681 = NOVALUE;
    int _30680 = NOVALUE;
    int _30679 = NOVALUE;
    int _30677 = NOVALUE;
    int _30675 = NOVALUE;
    int _30674 = NOVALUE;
    int _30673 = NOVALUE;
    int _30671 = NOVALUE;
    int _30670 = NOVALUE;
    int _30668 = NOVALUE;
    int _30666 = NOVALUE;
    int _30663 = NOVALUE;
    int _30659 = NOVALUE;
    int _30657 = NOVALUE;
    int _30656 = NOVALUE;
    int _30654 = NOVALUE;
    int _30653 = NOVALUE;
    int _30652 = NOVALUE;
    int _30651 = NOVALUE;
    int _30649 = NOVALUE;
    int _30648 = NOVALUE;
    int _30647 = NOVALUE;
    int _30646 = NOVALUE;
    int _30645 = NOVALUE;
    int _30643 = NOVALUE;
    int _30642 = NOVALUE;
    int _30641 = NOVALUE;
    int _30640 = NOVALUE;
    int _30639 = NOVALUE;
    int _30638 = NOVALUE;
    int _30637 = NOVALUE;
    int _30636 = NOVALUE;
    int _30635 = NOVALUE;
    int _30633 = NOVALUE;
    int _30632 = NOVALUE;
    int _30631 = NOVALUE;
    int _30630 = NOVALUE;
    int _30629 = NOVALUE;
    int _30626 = NOVALUE;
    int _30622 = NOVALUE;
    int _30621 = NOVALUE;
    int _30620 = NOVALUE;
    int _30619 = NOVALUE;
    int _30618 = NOVALUE;
    int _30617 = NOVALUE;
    int _30615 = NOVALUE;
    int _30612 = NOVALUE;
    int _30610 = NOVALUE;
    int _30609 = NOVALUE;
    int _30607 = NOVALUE;
    int _30604 = NOVALUE;
    int _30603 = NOVALUE;
    int _30602 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61272);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61272 = (int)*(((s1_ptr)_2)->base + _ref_61271);
    Ref(_fr_61272);

    /** 	symtab_index sub = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61270);
    _sub_61275 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sub_61275)){
        _sub_61275 = (long)DBL_PTR(_sub_61275)->dbl;
    }

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _30602 = (int)*(((s1_ptr)_2)->base + 12);
    _30603 = IS_SEQUENCE(_30602);
    _30602 = NOVALUE;
    if (_30603 == 0)
    {
        _30603 = NOVALUE;
        goto L1; // [32] 117
    }
    else{
        _30603 = NOVALUE;
    }

    /** 		sequence defarg = fr[FR_DATA][1]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _30604 = (int)*(((s1_ptr)_2)->base + 12);
    DeRef(_defarg_61281);
    _2 = (int)SEQ_PTR(_30604);
    _defarg_61281 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_defarg_61281);
    _30604 = NOVALUE;

    /** 		symtab_index paramsym = defarg[2]*/
    _2 = (int)SEQ_PTR(_defarg_61281);
    _paramsym_61285 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_paramsym_61285)){
        _paramsym_61285 = (long)DBL_PTR(_paramsym_61285)->dbl;
    }

    /** 		token old = { RECORDED, defarg[3] }*/
    _2 = (int)SEQ_PTR(_defarg_61281);
    _30607 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30607);
    DeRef(_old_61288);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 508;
    ((int *)_2)[2] = _30607;
    _old_61288 = MAKE_SEQ(_1);
    _30607 = NOVALUE;

    /** 		integer tx = find( old, SymTab[paramsym][S_CODE] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30609 = (int)*(((s1_ptr)_2)->base + _paramsym_61285);
    _2 = (int)SEQ_PTR(_30609);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _30610 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _30610 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _30609 = NOVALUE;
    _tx_61292 = find_from(_old_61288, _30610, 1);
    _30610 = NOVALUE;

    /** 		SymTab[paramsym][S_CODE][tx] = tok*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_paramsym_61285 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(object_ptr)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(object_ptr)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _3 = (int)(_12S_CODE_11366 + ((s1_ptr)_2)->base);
    _30612 = NOVALUE;
    Ref(_tok_61270);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _tx_61292);
    _1 = *(int *)_2;
    *(int *)_2 = _tok_61270;
    DeRef(_1);
    _30612 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61271);

    /** 		return*/
    DeRefDS(_defarg_61281);
    DeRefDS(_old_61288);
    DeRef(_tok_61270);
    DeRefDS(_fr_61272);
    DeRef(_code_61327);
    DeRef(_name_61337);
    DeRef(_params_61406);
    DeRef(_orig_code_61408);
    DeRef(_orig_linetable_61409);
    DeRef(_old_fwd_params_61431);
    DeRef(_new_code_61476);
    return;
L1: 
    DeRef(_defarg_61281);
    _defarg_61281 = NOVALUE;
    DeRef(_old_61288);
    _old_61288 = NOVALUE;

    /** 	integer code_sub = fr[FR_SUBPROG]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _code_sub_61302 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_code_sub_61302))
    _code_sub_61302 = (long)DBL_PTR(_code_sub_61302)->dbl;

    /** 	integer args = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30615 = (int)*(((s1_ptr)_2)->base + _sub_61275);
    _2 = (int)SEQ_PTR(_30615);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _args_61304 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _args_61304 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_args_61304)){
        _args_61304 = (long)DBL_PTR(_args_61304)->dbl;
    }
    _30615 = NOVALUE;

    /** 	integer is_func = (SymTab[sub][S_TOKEN] = FUNC) or (SymTab[sub][S_TOKEN] = TYPE)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30617 = (int)*(((s1_ptr)_2)->base + _sub_61275);
    _2 = (int)SEQ_PTR(_30617);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _30618 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _30618 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _30617 = NOVALUE;
    if (IS_ATOM_INT(_30618)) {
        _30619 = (_30618 == 501);
    }
    else {
        _30619 = binary_op(EQUALS, _30618, 501);
    }
    _30618 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30620 = (int)*(((s1_ptr)_2)->base + _sub_61275);
    _2 = (int)SEQ_PTR(_30620);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _30621 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _30621 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _30620 = NOVALUE;
    if (IS_ATOM_INT(_30621)) {
        _30622 = (_30621 == 504);
    }
    else {
        _30622 = binary_op(EQUALS, _30621, 504);
    }
    _30621 = NOVALUE;
    if (IS_ATOM_INT(_30619) && IS_ATOM_INT(_30622)) {
        _is_func_61309 = (_30619 != 0 || _30622 != 0);
    }
    else {
        _is_func_61309 = binary_op(OR, _30619, _30622);
    }
    DeRef(_30619);
    _30619 = NOVALUE;
    DeRef(_30622);
    _30622 = NOVALUE;
    if (!IS_ATOM_INT(_is_func_61309)) {
        _1 = (long)(DBL_PTR(_is_func_61309)->dbl);
        DeRefDS(_is_func_61309);
        _is_func_61309 = _1;
    }

    /** 	integer real_file = current_file_no*/
    _real_file_61323 = _12current_file_no_11682;

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _12current_file_no_11682 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12current_file_no_11682)){
        _12current_file_no_11682 = (long)DBL_PTR(_12current_file_no_11682)->dbl;
    }

    /** 	set_code( ref )*/
    _29set_code(_ref_61271);

    /** 	sequence code = Code*/
    RefDS(_12Code_11771);
    DeRef(_code_61327);
    _code_61327 = _12Code_11771;

    /** 	integer temp_sub = CurrentSub*/
    _temp_sub_61329 = _12CurrentSub_11690;

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _pc_61331 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61331))
    _pc_61331 = (long)DBL_PTR(_pc_61331)->dbl;

    /** 	integer next_pc = pc*/
    _next_pc_61333 = _pc_61331;

    /** 	integer supplied_args = code[pc+2]*/
    _30626 = _pc_61331 + 2;
    _2 = (int)SEQ_PTR(_code_61327);
    _supplied_args_61334 = (int)*(((s1_ptr)_2)->base + _30626);
    if (!IS_ATOM_INT(_supplied_args_61334))
    _supplied_args_61334 = (long)DBL_PTR(_supplied_args_61334)->dbl;

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_61337);
    _2 = (int)SEQ_PTR(_fr_61272);
    _name_61337 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_61337);

    /** 	if Code[pc] != FUNC_FORWARD and Code[pc] != PROC_FORWARD then*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _30629 = (int)*(((s1_ptr)_2)->base + _pc_61331);
    if (IS_ATOM_INT(_30629)) {
        _30630 = (_30629 != 196);
    }
    else {
        _30630 = binary_op(NOTEQ, _30629, 196);
    }
    _30629 = NOVALUE;
    if (IS_ATOM_INT(_30630)) {
        if (_30630 == 0) {
            goto L2; // [268] 332
        }
    }
    else {
        if (DBL_PTR(_30630)->dbl == 0.0) {
            goto L2; // [268] 332
        }
    }
    _2 = (int)SEQ_PTR(_12Code_11771);
    _30632 = (int)*(((s1_ptr)_2)->base + _pc_61331);
    if (IS_ATOM_INT(_30632)) {
        _30633 = (_30632 != 195);
    }
    else {
        _30633 = binary_op(NOTEQ, _30632, 195);
    }
    _30632 = NOVALUE;
    if (_30633 == 0) {
        DeRef(_30633);
        _30633 = NOVALUE;
        goto L2; // [285] 332
    }
    else {
        if (!IS_ATOM_INT(_30633) && DBL_PTR(_30633)->dbl == 0.0){
            DeRef(_30633);
            _30633 = NOVALUE;
            goto L2; // [285] 332
        }
        DeRef(_30633);
        _30633 = NOVALUE;
    }
    DeRef(_30633);
    _30633 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61271);

    /** 		CompileErr( "The forward call to [4] wasn't where we thought it would be: [1]:[2]:[3]",*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _30635 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _2 = (int)SEQ_PTR(_fr_61272);
    _30636 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_30636);
    _30637 = _52sym_name(_30636);
    _30636 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61272);
    _30638 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_fr_61272);
    _30639 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30635);
    *((int *)(_2+4)) = _30635;
    *((int *)(_2+8)) = _30637;
    Ref(_30638);
    *((int *)(_2+12)) = _30638;
    Ref(_30639);
    *((int *)(_2+16)) = _30639;
    _30640 = MAKE_SEQ(_1);
    _30639 = NOVALUE;
    _30638 = NOVALUE;
    _30637 = NOVALUE;
    _30635 = NOVALUE;
    RefDS(_30634);
    _43CompileErr(_30634, _30640, 0);
    _30640 = NOVALUE;
L2: 

    /** 	integer old_temps_allocated = temps_allocated*/
    _old_temps_allocated_61361 = _52temps_allocated_46251;

    /** 	temps_allocated = 0*/
    _52temps_allocated_46251 = 0;

    /** 	if is_func and fr[FR_OP] = PROC then*/
    if (_is_func_61309 == 0) {
        goto L3; // [350] 438
    }
    _2 = (int)SEQ_PTR(_fr_61272);
    _30642 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30642)) {
        _30643 = (_30642 == 27);
    }
    else {
        _30643 = binary_op(EQUALS, _30642, 27);
    }
    _30642 = NOVALUE;
    if (_30643 == 0) {
        DeRef(_30643);
        _30643 = NOVALUE;
        goto L3; // [365] 438
    }
    else {
        if (!IS_ATOM_INT(_30643) && DBL_PTR(_30643)->dbl == 0.0){
            DeRef(_30643);
            _30643 = NOVALUE;
            goto L3; // [365] 438
        }
        DeRef(_30643);
        _30643 = NOVALUE;
    }
    DeRef(_30643);
    _30643 = NOVALUE;

    /** 		symtab_index temp_target = NewTempSym()*/
    _temp_target_61370 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_temp_target_61370)) {
        _1 = (long)(DBL_PTR(_temp_target_61370)->dbl);
        DeRefDS(_temp_target_61370);
        _temp_target_61370 = _1;
    }

    /** 		sequence converted_code = */
    _30645 = _pc_61331 + 1;
    if (_30645 > MAXINT){
        _30645 = NewDouble((double)_30645);
    }
    _30646 = _pc_61331 + 2;
    if ((long)((unsigned long)_30646 + (unsigned long)HIGH_BITS) >= 0) 
    _30646 = NewDouble((double)_30646);
    if (IS_ATOM_INT(_30646)) {
        _30647 = _30646 + _supplied_args_61334;
    }
    else {
        _30647 = NewDouble(DBL_PTR(_30646)->dbl + (double)_supplied_args_61334);
    }
    DeRef(_30646);
    _30646 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30648;
    RHS_Slice(_12Code_11771, _30645, _30647);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 208;
    ((int *)_2)[2] = _temp_target_61370;
    _30649 = MAKE_SEQ(_1);
    {
        int concat_list[4];

        concat_list[0] = _30649;
        concat_list[1] = _temp_target_61370;
        concat_list[2] = _30648;
        concat_list[3] = 196;
        Concat_N((object_ptr)&_converted_code_61373, concat_list, 4);
    }
    DeRefDS(_30649);
    _30649 = NOVALUE;
    DeRefDS(_30648);
    _30648 = NOVALUE;

    /** 		replace_code( converted_code, pc, pc + 2 + supplied_args, code_sub )*/
    _30651 = _pc_61331 + 2;
    if ((long)((unsigned long)_30651 + (unsigned long)HIGH_BITS) >= 0) 
    _30651 = NewDouble((double)_30651);
    if (IS_ATOM_INT(_30651)) {
        _30652 = _30651 + _supplied_args_61334;
        if ((long)((unsigned long)_30652 + (unsigned long)HIGH_BITS) >= 0) 
        _30652 = NewDouble((double)_30652);
    }
    else {
        _30652 = NewDouble(DBL_PTR(_30651)->dbl + (double)_supplied_args_61334);
    }
    DeRef(_30651);
    _30651 = NOVALUE;
    RefDS(_converted_code_61373);
    _29replace_code(_converted_code_61373, _pc_61331, _30652, _code_sub_61302);
    _30652 = NOVALUE;

    /** 		code = Code*/
    RefDS(_12Code_11771);
    DeRef(_code_61327);
    _code_61327 = _12Code_11771;
L3: 
    DeRef(_converted_code_61373);
    _converted_code_61373 = NOVALUE;

    /** 	next_pc +=*/
    _30653 = 3 + _supplied_args_61334;
    if ((long)((unsigned long)_30653 + (unsigned long)HIGH_BITS) >= 0) 
    _30653 = NewDouble((double)_30653);
    if (IS_ATOM_INT(_30653)) {
        _30654 = _30653 + _is_func_61309;
        if ((long)((unsigned long)_30654 + (unsigned long)HIGH_BITS) >= 0) 
        _30654 = NewDouble((double)_30654);
    }
    else {
        _30654 = NewDouble(DBL_PTR(_30653)->dbl + (double)_is_func_61309);
    }
    DeRef(_30653);
    _30653 = NOVALUE;
    if (IS_ATOM_INT(_30654)) {
        _next_pc_61333 = _next_pc_61333 + _30654;
    }
    else {
        _next_pc_61333 = NewDouble((double)_next_pc_61333 + DBL_PTR(_30654)->dbl);
    }
    DeRef(_30654);
    _30654 = NOVALUE;
    if (!IS_ATOM_INT(_next_pc_61333)) {
        _1 = (long)(DBL_PTR(_next_pc_61333)->dbl);
        DeRefDS(_next_pc_61333);
        _next_pc_61333 = _1;
    }

    /** 	integer target*/

    /** 	if is_func then*/
    if (_is_func_61309 == 0)
    {
        goto L4; // [460] 482
    }
    else{
    }

    /** 		target = Code[pc + 3 + supplied_args]*/
    _30656 = _pc_61331 + 3;
    if ((long)((unsigned long)_30656 + (unsigned long)HIGH_BITS) >= 0) 
    _30656 = NewDouble((double)_30656);
    if (IS_ATOM_INT(_30656)) {
        _30657 = _30656 + _supplied_args_61334;
    }
    else {
        _30657 = NewDouble(DBL_PTR(_30656)->dbl + (double)_supplied_args_61334);
    }
    DeRef(_30656);
    _30656 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!IS_ATOM_INT(_30657)){
        _target_61389 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30657)->dbl));
    }
    else{
        _target_61389 = (int)*(((s1_ptr)_2)->base + _30657);
    }
    if (!IS_ATOM_INT(_target_61389)){
        _target_61389 = (long)DBL_PTR(_target_61389)->dbl;
    }
L4: 

    /** 	integer has_defaults = 0*/
    _has_defaults_61395 = 0;

    /** 	integer goto_target = length( code ) + 1*/
    if (IS_SEQUENCE(_code_61327)){
            _30659 = SEQ_PTR(_code_61327)->length;
    }
    else {
        _30659 = 1;
    }
    _goto_target_61396 = _30659 + 1;
    _30659 = NOVALUE;

    /** 	integer defarg = 0*/
    _defarg_61399 = 0;

    /** 	integer code_len = length(code)*/
    if (IS_SEQUENCE(_code_61327)){
            _code_len_61400 = SEQ_PTR(_code_61327)->length;
    }
    else {
        _code_len_61400 = 1;
    }

    /** 	integer extra_default_args = 0*/
    _extra_default_args_61402 = 0;

    /** 	set_dont_read( 1 )*/
    _60set_dont_read(1);

    /** 	reset_private_lists()*/

    /** 	fwd_private_sym  = {}*/
    RefDS(_21829);
    DeRefi(_29fwd_private_sym_61233);
    _29fwd_private_sym_61233 = _21829;

    /** 	fwd_private_name = {}*/
    RefDS(_21829);
    DeRef(_29fwd_private_name_61234);
    _29fwd_private_name_61234 = _21829;

    /** end procedure*/
    goto L5; // [534] 537
L5: 

    /** 	integer param_sym = sub*/
    _param_sym_61405 = _sub_61275;

    /** 	sequence params = repeat( 0, args )*/
    DeRef(_params_61406);
    _params_61406 = Repeat(0, _args_61304);

    /** 	sequence orig_code = code*/
    RefDS(_code_61327);
    DeRef(_orig_code_61408);
    _orig_code_61408 = _code_61327;

    /** 	sequence orig_linetable = LineTable*/
    RefDS(_12LineTable_11772);
    DeRef(_orig_linetable_61409);
    _orig_linetable_61409 = _12LineTable_11772;

    /** 	Code = {}*/
    RefDS(_21829);
    DeRef(_12Code_11771);
    _12Code_11771 = _21829;

    /** 	integer ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _30663 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _ar_sp_61412 = find_from(_code_sub_61302, _30663, 1);
    _30663 = NOVALUE;

    /** 	integer pre_refs*/

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61302 != _12TopLevelSub_11689)
    goto L6; // [594] 614

    /** 		pre_refs = length( toplevel_references[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    _30666 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_30666)){
            _pre_refs_61416 = SEQ_PTR(_30666)->length;
    }
    else {
        _pre_refs_61416 = 1;
    }
    _30666 = NOVALUE;
    goto L7; // [611] 647
L6: 

    /** 		ar_sp = find( code_sub, active_subprogs[current_file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _30668 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _ar_sp_61412 = find_from(_code_sub_61302, _30668, 1);
    _30668 = NOVALUE;

    /** 		pre_refs = length( active_references[current_file_no][ar_sp] )*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _30670 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _2 = (int)SEQ_PTR(_30670);
    _30671 = (int)*(((s1_ptr)_2)->base + _ar_sp_61412);
    _30670 = NOVALUE;
    if (IS_SEQUENCE(_30671)){
            _pre_refs_61416 = SEQ_PTR(_30671)->length;
    }
    else {
        _pre_refs_61416 = 1;
    }
    _30671 = NOVALUE;
L7: 

    /** 	sequence old_fwd_params = {}*/
    RefDS(_21829);
    DeRef(_old_fwd_params_61431);
    _old_fwd_params_61431 = _21829;

    /** 	for i = pc + 3 to pc + args + 2 do*/
    _30673 = _pc_61331 + 3;
    if ((long)((unsigned long)_30673 + (unsigned long)HIGH_BITS) >= 0) 
    _30673 = NewDouble((double)_30673);
    _30674 = _pc_61331 + _args_61304;
    if ((long)((unsigned long)_30674 + (unsigned long)HIGH_BITS) >= 0) 
    _30674 = NewDouble((double)_30674);
    if (IS_ATOM_INT(_30674)) {
        _30675 = _30674 + 2;
        if ((long)((unsigned long)_30675 + (unsigned long)HIGH_BITS) >= 0) 
        _30675 = NewDouble((double)_30675);
    }
    else {
        _30675 = NewDouble(DBL_PTR(_30674)->dbl + (double)2);
    }
    DeRef(_30674);
    _30674 = NOVALUE;
    {
        int _i_61433;
        Ref(_30673);
        _i_61433 = _30673;
L8: 
        if (binary_op_a(GREATER, _i_61433, _30675)){
            goto L9; // [668] 829
        }

        /** 		defarg += 1*/
        _defarg_61399 = _defarg_61399 + 1;

        /** 		param_sym = SymTab[param_sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30677 = (int)*(((s1_ptr)_2)->base + _param_sym_61405);
        _2 = (int)SEQ_PTR(_30677);
        _param_sym_61405 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_sym_61405)){
            _param_sym_61405 = (long)DBL_PTR(_param_sym_61405)->dbl;
        }
        _30677 = NOVALUE;

        /** 		if defarg > supplied_args or i > length( code ) or not code[i] then*/
        _30679 = (_defarg_61399 > _supplied_args_61334);
        if (_30679 != 0) {
            _30680 = 1;
            goto LA; // [703] 718
        }
        if (IS_SEQUENCE(_code_61327)){
                _30681 = SEQ_PTR(_code_61327)->length;
        }
        else {
            _30681 = 1;
        }
        if (IS_ATOM_INT(_i_61433)) {
            _30682 = (_i_61433 > _30681);
        }
        else {
            _30682 = (DBL_PTR(_i_61433)->dbl > (double)_30681);
        }
        _30681 = NOVALUE;
        _30680 = (_30682 != 0);
LA: 
        if (_30680 != 0) {
            goto LB; // [718] 734
        }
        _2 = (int)SEQ_PTR(_code_61327);
        if (!IS_ATOM_INT(_i_61433)){
            _30684 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61433)->dbl));
        }
        else{
            _30684 = (int)*(((s1_ptr)_2)->base + _i_61433);
        }
        if (IS_ATOM_INT(_30684)) {
            _30685 = (_30684 == 0);
        }
        else {
            _30685 = unary_op(NOT, _30684);
        }
        _30684 = NOVALUE;
        if (_30685 == 0) {
            DeRef(_30685);
            _30685 = NOVALUE;
            goto LC; // [730] 784
        }
        else {
            if (!IS_ATOM_INT(_30685) && DBL_PTR(_30685)->dbl == 0.0){
                DeRef(_30685);
                _30685 = NOVALUE;
                goto LC; // [730] 784
            }
            DeRef(_30685);
            _30685 = NOVALUE;
        }
        DeRef(_30685);
        _30685 = NOVALUE;
LB: 

        /** 			has_defaults = 1*/
        _has_defaults_61395 = 1;

        /** 			extra_default_args += 1*/
        _extra_default_args_61402 = _extra_default_args_61402 + 1;

        /** 			show_params( sub )*/
        _52show_params(_sub_61275);

        /** 			set_error_info( ref )*/
        _29set_error_info(_ref_61271);

        /** 			Parse_default_arg(sub, defarg, fwd_private_name, fwd_private_sym) --call_proc( parse_arg_rid, { sub, defarg, fwd_private_name, fwd_private_sym } )*/
        RefDS(_29fwd_private_name_61234);
        RefDS(_29fwd_private_sym_61233);
        _30Parse_default_arg(_sub_61275, _defarg_61399, _29fwd_private_name_61234, _29fwd_private_sym_61233);

        /** 			hide_params( sub )*/
        _52hide_params(_sub_61275);

        /** 			params[defarg] = Pop()*/
        _30687 = _37Pop();
        _2 = (int)SEQ_PTR(_params_61406);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61399);
        _1 = *(int *)_2;
        *(int *)_2 = _30687;
        if( _1 != _30687 ){
            DeRef(_1);
        }
        _30687 = NOVALUE;
        goto LD; // [781] 822
LC: 

        /** 			extra_default_args = 0*/
        _extra_default_args_61402 = 0;

        /** 			add_private_symbol( code[i], SymTab[param_sym][S_NAME] )*/
        _2 = (int)SEQ_PTR(_code_61327);
        if (!IS_ATOM_INT(_i_61433)){
            _30688 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61433)->dbl));
        }
        else{
            _30688 = (int)*(((s1_ptr)_2)->base + _i_61433);
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30689 = (int)*(((s1_ptr)_2)->base + _param_sym_61405);
        _2 = (int)SEQ_PTR(_30689);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _30690 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _30690 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        _30689 = NOVALUE;
        Ref(_30688);
        Ref(_30690);
        _29add_private_symbol(_30688, _30690);
        _30688 = NOVALUE;
        _30690 = NOVALUE;

        /** 			params[defarg] = code[i]*/
        _2 = (int)SEQ_PTR(_code_61327);
        if (!IS_ATOM_INT(_i_61433)){
            _30691 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61433)->dbl));
        }
        else{
            _30691 = (int)*(((s1_ptr)_2)->base + _i_61433);
        }
        Ref(_30691);
        _2 = (int)SEQ_PTR(_params_61406);
        _2 = (int)(((s1_ptr)_2)->base + _defarg_61399);
        _1 = *(int *)_2;
        *(int *)_2 = _30691;
        if( _1 != _30691 ){
            DeRef(_1);
        }
        _30691 = NOVALUE;
LD: 

        /** 	end for*/
        _0 = _i_61433;
        if (IS_ATOM_INT(_i_61433)) {
            _i_61433 = _i_61433 + 1;
            if ((long)((unsigned long)_i_61433 +(unsigned long) HIGH_BITS) >= 0){
                _i_61433 = NewDouble((double)_i_61433);
            }
        }
        else {
            _i_61433 = binary_op_a(PLUS, _i_61433, 1);
        }
        DeRef(_0);
        goto L8; // [824] 675
L9: 
        ;
        DeRef(_i_61433);
    }

    /** 	SymTab[code_sub][S_STACK_SPACE] += temps_allocated*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_code_sub_61302 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _30694 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _30694 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _30692 = NOVALUE;
    if (IS_ATOM_INT(_30694)) {
        _30695 = _30694 + _52temps_allocated_46251;
        if ((long)((unsigned long)_30695 + (unsigned long)HIGH_BITS) >= 0) 
        _30695 = NewDouble((double)_30695);
    }
    else {
        _30695 = binary_op(PLUS, _30694, _52temps_allocated_46251);
    }
    _30694 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    _1 = *(int *)_2;
    *(int *)_2 = _30695;
    if( _1 != _30695 ){
        DeRef(_1);
    }
    _30695 = NOVALUE;
    _30692 = NOVALUE;

    /** 	temps_allocated = old_temps_allocated*/
    _52temps_allocated_46251 = _old_temps_allocated_61361;

    /** 	integer temp_shifting_sub = shifting_sub*/
    _temp_shifting_sub_61472 = _29shifting_sub_61080;

    /** 	shift( -pc, pc-1 )*/
    if ((unsigned long)_pc_61331 == 0xC0000000)
    _30696 = (int)NewDouble((double)-0xC0000000);
    else
    _30696 = - _pc_61331;
    _30697 = _pc_61331 - 1;
    if ((long)((unsigned long)_30697 +(unsigned long) HIGH_BITS) >= 0){
        _30697 = NewDouble((double)_30697);
    }
    Ref(_30696);
    DeRef(_31351);
    _31351 = _30696;
    _64shift(_30696, _30697, _31351);
    _30696 = NOVALUE;
    _30697 = NOVALUE;
    _31351 = NOVALUE;

    /** 	sequence new_code = Code*/
    RefDS(_12Code_11771);
    DeRef(_new_code_61476);
    _new_code_61476 = _12Code_11771;

    /** 	Code = orig_code*/
    RefDS(_orig_code_61408);
    DeRefDS(_12Code_11771);
    _12Code_11771 = _orig_code_61408;

    /** 	LineTable = orig_linetable*/
    RefDS(_orig_linetable_61409);
    DeRef(_12LineTable_11772);
    _12LineTable_11772 = _orig_linetable_61409;

    /** 	set_dont_read( 0 )*/
    _60set_dont_read(0);

    /** 	current_file_no = real_file*/
    _12current_file_no_11682 = _real_file_61323;

    /** 	if args != ( supplied_args + extra_default_args ) then*/
    _30698 = _supplied_args_61334 + _extra_default_args_61402;
    if ((long)((unsigned long)_30698 + (unsigned long)HIGH_BITS) >= 0) 
    _30698 = NewDouble((double)_30698);
    if (binary_op_a(EQUALS, _args_61304, _30698)){
        DeRef(_30698);
        _30698 = NOVALUE;
        goto LE; // [926] 1004
    }
    DeRef(_30698);
    _30698 = NOVALUE;

    /** 		sequence routine_type*/

    /** 		if is_func then */
    if (_is_func_61309 == 0)
    {
        goto LF; // [934] 947
    }
    else{
    }

    /** 			routine_type = "function"*/
    RefDS(_26059);
    DeRefi(_routine_type_61485);
    _routine_type_61485 = _26059;
    goto L10; // [944] 955
LF: 

    /** 			routine_type = "procedure"*/
    RefDS(_26113);
    DeRefi(_routine_type_61485);
    _routine_type_61485 = _26113;
L10: 

    /** 		current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _12current_file_no_11682 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12current_file_no_11682)){
        _12current_file_no_11682 = (long)DBL_PTR(_12current_file_no_11682)->dbl;
    }

    /** 		line_number = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61272);
    _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_12line_number_11683)){
        _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
    }

    /** 		CompileErr( 158,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _30702 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _30703 = _supplied_args_61334 + _extra_default_args_61402;
    if ((long)((unsigned long)_30703 + (unsigned long)HIGH_BITS) >= 0) 
    _30703 = NewDouble((double)_30703);
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30702);
    *((int *)(_2+4)) = _30702;
    *((int *)(_2+8)) = _12line_number_11683;
    RefDS(_routine_type_61485);
    *((int *)(_2+12)) = _routine_type_61485;
    RefDS(_name_61337);
    *((int *)(_2+16)) = _name_61337;
    *((int *)(_2+20)) = _args_61304;
    *((int *)(_2+24)) = _30703;
    _30704 = MAKE_SEQ(_1);
    _30703 = NOVALUE;
    _30702 = NOVALUE;
    _43CompileErr(158, _30704, 0);
    _30704 = NOVALUE;
LE: 
    DeRefi(_routine_type_61485);
    _routine_type_61485 = NOVALUE;

    /** 	new_code &= PROC & sub & params*/
    {
        int concat_list[3];

        concat_list[0] = _params_61406;
        concat_list[1] = _sub_61275;
        concat_list[2] = 27;
        Concat_N((object_ptr)&_30705, concat_list, 3);
    }
    Concat((object_ptr)&_new_code_61476, _new_code_61476, _30705);
    DeRefDS(_30705);
    _30705 = NOVALUE;

    /** 	if is_func then*/
    if (_is_func_61309 == 0)
    {
        goto L11; // [1022] 1034
    }
    else{
    }

    /** 		new_code &= target*/
    Append(&_new_code_61476, _new_code_61476, _target_61389);
L11: 

    /** 	replace_code( new_code, pc, next_pc - 1, code_sub )*/
    _30708 = _next_pc_61333 - 1;
    if ((long)((unsigned long)_30708 +(unsigned long) HIGH_BITS) >= 0){
        _30708 = NewDouble((double)_30708);
    }
    RefDS(_new_code_61476);
    _29replace_code(_new_code_61476, _pc_61331, _30708, _code_sub_61302);
    _30708 = NOVALUE;

    /** 	if code_sub = TopLevelSub then*/
    if (_code_sub_61302 != _12TopLevelSub_11689)
    goto L12; // [1050] 1131

    /** 		for i = pre_refs + 1 to length( toplevel_references[fr[FR_FILE]] ) do*/
    _30710 = _pre_refs_61416 + 1;
    if (_30710 > MAXINT){
        _30710 = NewDouble((double)_30710);
    }
    _2 = (int)SEQ_PTR(_fr_61272);
    _30711 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    if (!IS_ATOM_INT(_30711)){
        _30712 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30711)->dbl));
    }
    else{
        _30712 = (int)*(((s1_ptr)_2)->base + _30711);
    }
    if (IS_SEQUENCE(_30712)){
            _30713 = SEQ_PTR(_30712)->length;
    }
    else {
        _30713 = 1;
    }
    _30712 = NOVALUE;
    {
        int _i_61509;
        Ref(_30710);
        _i_61509 = _30710;
L13: 
        if (binary_op_a(GREATER, _i_61509, _30713)){
            goto L14; // [1075] 1128
        }

        /** 			forward_references[toplevel_references[fr[FR_FILE]][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61272);
        _30714 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_29toplevel_references_61064);
        if (!IS_ATOM_INT(_30714)){
            _30715 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30714)->dbl));
        }
        else{
            _30715 = (int)*(((s1_ptr)_2)->base + _30714);
        }
        _2 = (int)SEQ_PTR(_30715);
        if (!IS_ATOM_INT(_i_61509)){
            _30716 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61509)->dbl));
        }
        else{
            _30716 = (int)*(((s1_ptr)_2)->base + _i_61509);
        }
        _30715 = NOVALUE;
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30716))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30716)->dbl));
        else
        _3 = (int)(_30716 + ((s1_ptr)_2)->base);
        _30719 = _pc_61331 - 1;
        if ((long)((unsigned long)_30719 +(unsigned long) HIGH_BITS) >= 0){
            _30719 = NewDouble((double)_30719);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _30720 = (int)*(((s1_ptr)_2)->base + 5);
        _30717 = NOVALUE;
        if (IS_ATOM_INT(_30720) && IS_ATOM_INT(_30719)) {
            _30721 = _30720 + _30719;
            if ((long)((unsigned long)_30721 + (unsigned long)HIGH_BITS) >= 0) 
            _30721 = NewDouble((double)_30721);
        }
        else {
            _30721 = binary_op(PLUS, _30720, _30719);
        }
        _30720 = NOVALUE;
        DeRef(_30719);
        _30719 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _30721;
        if( _1 != _30721 ){
            DeRef(_1);
        }
        _30721 = NOVALUE;
        _30717 = NOVALUE;

        /** 		end for*/
        _0 = _i_61509;
        if (IS_ATOM_INT(_i_61509)) {
            _i_61509 = _i_61509 + 1;
            if ((long)((unsigned long)_i_61509 +(unsigned long) HIGH_BITS) >= 0){
                _i_61509 = NewDouble((double)_i_61509);
            }
        }
        else {
            _i_61509 = binary_op_a(PLUS, _i_61509, 1);
        }
        DeRef(_0);
        goto L13; // [1123] 1082
L14: 
        ;
        DeRef(_i_61509);
    }
    goto L15; // [1128] 1214
L12: 

    /** 		for i = pre_refs + 1 to length( active_references[fr[FR_FILE]][ar_sp] ) do*/
    _30722 = _pre_refs_61416 + 1;
    if (_30722 > MAXINT){
        _30722 = NewDouble((double)_30722);
    }
    _2 = (int)SEQ_PTR(_fr_61272);
    _30723 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!IS_ATOM_INT(_30723)){
        _30724 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30723)->dbl));
    }
    else{
        _30724 = (int)*(((s1_ptr)_2)->base + _30723);
    }
    _2 = (int)SEQ_PTR(_30724);
    _30725 = (int)*(((s1_ptr)_2)->base + _ar_sp_61412);
    _30724 = NOVALUE;
    if (IS_SEQUENCE(_30725)){
            _30726 = SEQ_PTR(_30725)->length;
    }
    else {
        _30726 = 1;
    }
    _30725 = NOVALUE;
    {
        int _i_61524;
        Ref(_30722);
        _i_61524 = _30722;
L16: 
        if (binary_op_a(GREATER, _i_61524, _30726)){
            goto L17; // [1156] 1213
        }

        /** 			forward_references[active_references[fr[FR_FILE]][ar_sp][i]][FR_PC] += pc - 1*/
        _2 = (int)SEQ_PTR(_fr_61272);
        _30727 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_29active_references_61063);
        if (!IS_ATOM_INT(_30727)){
            _30728 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30727)->dbl));
        }
        else{
            _30728 = (int)*(((s1_ptr)_2)->base + _30727);
        }
        _2 = (int)SEQ_PTR(_30728);
        _30729 = (int)*(((s1_ptr)_2)->base + _ar_sp_61412);
        _30728 = NOVALUE;
        _2 = (int)SEQ_PTR(_30729);
        if (!IS_ATOM_INT(_i_61524)){
            _30730 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_61524)->dbl));
        }
        else{
            _30730 = (int)*(((s1_ptr)_2)->base + _i_61524);
        }
        _30729 = NOVALUE;
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30730))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30730)->dbl));
        else
        _3 = (int)(_30730 + ((s1_ptr)_2)->base);
        _30733 = _pc_61331 - 1;
        if ((long)((unsigned long)_30733 +(unsigned long) HIGH_BITS) >= 0){
            _30733 = NewDouble((double)_30733);
        }
        _2 = (int)SEQ_PTR(*(int *)_3);
        _30734 = (int)*(((s1_ptr)_2)->base + 5);
        _30731 = NOVALUE;
        if (IS_ATOM_INT(_30734) && IS_ATOM_INT(_30733)) {
            _30735 = _30734 + _30733;
            if ((long)((unsigned long)_30735 + (unsigned long)HIGH_BITS) >= 0) 
            _30735 = NewDouble((double)_30735);
        }
        else {
            _30735 = binary_op(PLUS, _30734, _30733);
        }
        _30734 = NOVALUE;
        DeRef(_30733);
        _30733 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _30735;
        if( _1 != _30735 ){
            DeRef(_1);
        }
        _30735 = NOVALUE;
        _30731 = NOVALUE;

        /** 		end for*/
        _0 = _i_61524;
        if (IS_ATOM_INT(_i_61524)) {
            _i_61524 = _i_61524 + 1;
            if ((long)((unsigned long)_i_61524 +(unsigned long) HIGH_BITS) >= 0){
                _i_61524 = NewDouble((double)_i_61524);
            }
        }
        else {
            _i_61524 = binary_op_a(PLUS, _i_61524, 1);
        }
        DeRef(_0);
        goto L16; // [1208] 1163
L17: 
        ;
        DeRef(_i_61524);
    }
L15: 

    /** 	reset_code()*/
    _29reset_code();

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61271);

    /** end procedure*/
    DeRef(_tok_61270);
    DeRef(_fr_61272);
    DeRef(_code_61327);
    DeRef(_name_61337);
    DeRef(_params_61406);
    DeRef(_orig_code_61408);
    DeRef(_orig_linetable_61409);
    DeRef(_old_fwd_params_61431);
    DeRef(_new_code_61476);
    _30711 = NOVALUE;
    _30730 = NOVALUE;
    DeRef(_30679);
    _30679 = NOVALUE;
    _30714 = NOVALUE;
    DeRef(_30647);
    _30647 = NOVALUE;
    DeRef(_30645);
    _30645 = NOVALUE;
    _30725 = NOVALUE;
    DeRef(_30722);
    _30722 = NOVALUE;
    DeRef(_30682);
    _30682 = NOVALUE;
    DeRef(_30630);
    _30630 = NOVALUE;
    _30712 = NOVALUE;
    _30671 = NOVALUE;
    DeRef(_30673);
    _30673 = NOVALUE;
    _30716 = NOVALUE;
    _30727 = NOVALUE;
    _30666 = NOVALUE;
    _30723 = NOVALUE;
    DeRef(_30657);
    _30657 = NOVALUE;
    DeRef(_30710);
    _30710 = NOVALUE;
    DeRef(_30626);
    _30626 = NOVALUE;
    DeRef(_30675);
    _30675 = NOVALUE;
    return;
    ;
}


void _29set_error_info(int _ref_61541)
{
    int _fr_61542 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61542);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61542 = (int)*(((s1_ptr)_2)->base + _ref_61541);
    Ref(_fr_61542);

    /** 	ThisLine        = fr[FR_THISLINE]*/
    DeRef(_43ThisLine_48158);
    _2 = (int)SEQ_PTR(_fr_61542);
    _43ThisLine_48158 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_43ThisLine_48158);

    /** 	bp              = fr[FR_BP]*/
    _2 = (int)SEQ_PTR(_fr_61542);
    _43bp_48162 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_43bp_48162)){
        _43bp_48162 = (long)DBL_PTR(_43bp_48162)->dbl;
    }

    /** 	line_number     = fr[FR_LINE]*/
    _2 = (int)SEQ_PTR(_fr_61542);
    _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_12line_number_11683)){
        _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
    }

    /** 	current_file_no = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_61542);
    _12current_file_no_11682 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12current_file_no_11682)){
        _12current_file_no_11682 = (long)DBL_PTR(_12current_file_no_11682)->dbl;
    }

    /** end procedure*/
    DeRefDS(_fr_61542);
    return;
    ;
}


void _29patch_forward_variable(int _tok_61555, int _ref_61556)
{
    int _fr_61557 = NOVALUE;
    int _sym_61560 = NOVALUE;
    int _pc_61612 = NOVALUE;
    int _vx_61616 = NOVALUE;
    int _d_61633 = NOVALUE;
    int _param_61643 = NOVALUE;
    int _old_61646 = NOVALUE;
    int _new_61651 = NOVALUE;
    int _30792 = NOVALUE;
    int _30791 = NOVALUE;
    int _30790 = NOVALUE;
    int _30788 = NOVALUE;
    int _30785 = NOVALUE;
    int _30783 = NOVALUE;
    int _30782 = NOVALUE;
    int _30781 = NOVALUE;
    int _30780 = NOVALUE;
    int _30778 = NOVALUE;
    int _30777 = NOVALUE;
    int _30776 = NOVALUE;
    int _30775 = NOVALUE;
    int _30774 = NOVALUE;
    int _30772 = NOVALUE;
    int _30770 = NOVALUE;
    int _30767 = NOVALUE;
    int _30766 = NOVALUE;
    int _30765 = NOVALUE;
    int _30763 = NOVALUE;
    int _30762 = NOVALUE;
    int _30761 = NOVALUE;
    int _30760 = NOVALUE;
    int _30758 = NOVALUE;
    int _30756 = NOVALUE;
    int _30755 = NOVALUE;
    int _30754 = NOVALUE;
    int _30753 = NOVALUE;
    int _30752 = NOVALUE;
    int _30751 = NOVALUE;
    int _30750 = NOVALUE;
    int _30749 = NOVALUE;
    int _30748 = NOVALUE;
    int _30747 = NOVALUE;
    int _30746 = NOVALUE;
    int _30745 = NOVALUE;
    int _30744 = NOVALUE;
    int _30743 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61557);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61557 = (int)*(((s1_ptr)_2)->base + _ref_61556);
    Ref(_fr_61557);

    /** 	symtab_index sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61555);
    _sym_61560 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_61560)){
        _sym_61560 = (long)DBL_PTR(_sym_61560)->dbl;
    }

    /** 	if SymTab[sym][S_FILE_NO] = fr[FR_FILE] */
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30743 = (int)*(((s1_ptr)_2)->base + _sym_61560);
    _2 = (int)SEQ_PTR(_30743);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _30744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _30744 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _30743 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61557);
    _30745 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_30744) && IS_ATOM_INT(_30745)) {
        _30746 = (_30744 == _30745);
    }
    else {
        _30746 = binary_op(EQUALS, _30744, _30745);
    }
    _30744 = NOVALUE;
    _30745 = NOVALUE;
    if (IS_ATOM_INT(_30746)) {
        if (_30746 == 0) {
            goto L1; // [45] 69
        }
    }
    else {
        if (DBL_PTR(_30746)->dbl == 0.0) {
            goto L1; // [45] 69
        }
    }
    _2 = (int)SEQ_PTR(_fr_61557);
    _30748 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30748)) {
        _30749 = (_30748 == _12TopLevelSub_11689);
    }
    else {
        _30749 = binary_op(EQUALS, _30748, _12TopLevelSub_11689);
    }
    _30748 = NOVALUE;
    if (_30749 == 0) {
        DeRef(_30749);
        _30749 = NOVALUE;
        goto L1; // [60] 69
    }
    else {
        if (!IS_ATOM_INT(_30749) && DBL_PTR(_30749)->dbl == 0.0){
            DeRef(_30749);
            _30749 = NOVALUE;
            goto L1; // [60] 69
        }
        DeRef(_30749);
        _30749 = NOVALUE;
    }
    DeRef(_30749);
    _30749 = NOVALUE;

    /** 		return*/
    DeRef(_tok_61555);
    DeRef(_fr_61557);
    DeRef(_30746);
    _30746 = NOVALUE;
    return;
L1: 

    /** 	if fr[FR_OP] = ASSIGN and SymTab[sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_fr_61557);
    _30750 = (int)*(((s1_ptr)_2)->base + 10);
    if (IS_ATOM_INT(_30750)) {
        _30751 = (_30750 == 18);
    }
    else {
        _30751 = binary_op(EQUALS, _30750, 18);
    }
    _30750 = NOVALUE;
    if (IS_ATOM_INT(_30751)) {
        if (_30751 == 0) {
            goto L2; // [81] 120
        }
    }
    else {
        if (DBL_PTR(_30751)->dbl == 0.0) {
            goto L2; // [81] 120
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30753 = (int)*(((s1_ptr)_2)->base + _sym_61560);
    _2 = (int)SEQ_PTR(_30753);
    _30754 = (int)*(((s1_ptr)_2)->base + 3);
    _30753 = NOVALUE;
    if (IS_ATOM_INT(_30754)) {
        _30755 = (_30754 == 2);
    }
    else {
        _30755 = binary_op(EQUALS, _30754, 2);
    }
    _30754 = NOVALUE;
    if (_30755 == 0) {
        DeRef(_30755);
        _30755 = NOVALUE;
        goto L2; // [104] 120
    }
    else {
        if (!IS_ATOM_INT(_30755) && DBL_PTR(_30755)->dbl == 0.0){
            DeRef(_30755);
            _30755 = NOVALUE;
            goto L2; // [104] 120
        }
        DeRef(_30755);
        _30755 = NOVALUE;
    }
    DeRef(_30755);
    _30755 = NOVALUE;

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61556);

    /** 		CompileErr( 110 )*/
    RefDS(_21829);
    _43CompileErr(110, _21829, 0);
L2: 

    /** 	if fr[FR_OP] = ASSIGN then*/
    _2 = (int)SEQ_PTR(_fr_61557);
    _30756 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30756, 18)){
        _30756 = NOVALUE;
        goto L3; // [128] 168
    }
    _30756 = NOVALUE;

    /** 		SymTab[sym][S_USAGE] = or_bits( U_WRITTEN, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_61560 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30760 = (int)*(((s1_ptr)_2)->base + _sym_61560);
    _2 = (int)SEQ_PTR(_30760);
    _30761 = (int)*(((s1_ptr)_2)->base + 5);
    _30760 = NOVALUE;
    if (IS_ATOM_INT(_30761)) {
        {unsigned long tu;
             tu = (unsigned long)2 | (unsigned long)_30761;
             _30762 = MAKE_UINT(tu);
        }
    }
    else {
        _30762 = binary_op(OR_BITS, 2, _30761);
    }
    _30761 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _30762;
    if( _1 != _30762 ){
        DeRef(_1);
    }
    _30762 = NOVALUE;
    _30758 = NOVALUE;
    goto L4; // [165] 202
L3: 

    /** 		SymTab[sym][S_USAGE] = or_bits( U_READ, SymTab[sym][S_USAGE] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_61560 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30765 = (int)*(((s1_ptr)_2)->base + _sym_61560);
    _2 = (int)SEQ_PTR(_30765);
    _30766 = (int)*(((s1_ptr)_2)->base + 5);
    _30765 = NOVALUE;
    if (IS_ATOM_INT(_30766)) {
        {unsigned long tu;
             tu = (unsigned long)1 | (unsigned long)_30766;
             _30767 = MAKE_UINT(tu);
        }
    }
    else {
        _30767 = binary_op(OR_BITS, 1, _30766);
    }
    _30766 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _30767;
    if( _1 != _30767 ){
        DeRef(_1);
    }
    _30767 = NOVALUE;
    _30763 = NOVALUE;
L4: 

    /** 	set_code( ref )*/
    _29set_code(_ref_61556);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61557);
    _pc_61612 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61612))
    _pc_61612 = (long)DBL_PTR(_pc_61612)->dbl;

    /** 	if pc < 1 then*/
    if (_pc_61612 >= 1)
    goto L5; // [215] 225

    /** 		pc = 1*/
    _pc_61612 = 1;
L5: 

    /** 	integer vx = find( -ref, Code, pc )*/
    if ((unsigned long)_ref_61556 == 0xC0000000)
    _30770 = (int)NewDouble((double)-0xC0000000);
    else
    _30770 = - _ref_61556;
    _vx_61616 = find_from(_30770, _12Code_11771, _pc_61612);
    DeRef(_30770);
    _30770 = NOVALUE;

    /** 	if vx then*/
    if (_vx_61616 == 0)
    {
        goto L6; // [239] 281
    }
    else{
    }

    /** 		while vx do*/
L7: 
    if (_vx_61616 == 0)
    {
        goto L8; // [247] 275
    }
    else{
    }

    /** 			Code[vx] = sym*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _vx_61616);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_61560;
    DeRef(_1);

    /** 			vx = find( -ref, Code, vx )*/
    if ((unsigned long)_ref_61556 == 0xC0000000)
    _30772 = (int)NewDouble((double)-0xC0000000);
    else
    _30772 = - _ref_61556;
    _vx_61616 = find_from(_30772, _12Code_11771, _vx_61616);
    DeRef(_30772);
    _30772 = NOVALUE;

    /** 		end while*/
    goto L7; // [272] 247
L8: 

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61556);
L6: 

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61557);
    _30774 = (int)*(((s1_ptr)_2)->base + 12);
    _30775 = IS_SEQUENCE(_30774);
    _30774 = NOVALUE;
    if (_30775 == 0)
    {
        _30775 = NOVALUE;
        goto L9; // [290] 422
    }
    else{
        _30775 = NOVALUE;
    }

    /** 		for i = 1 to length( fr[FR_DATA] ) do*/
    _2 = (int)SEQ_PTR(_fr_61557);
    _30776 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_SEQUENCE(_30776)){
            _30777 = SEQ_PTR(_30776)->length;
    }
    else {
        _30777 = 1;
    }
    _30776 = NOVALUE;
    {
        int _i_61630;
        _i_61630 = 1;
LA: 
        if (_i_61630 > _30777){
            goto LB; // [302] 416
        }

        /** 			object d = fr[FR_DATA][i]*/
        _2 = (int)SEQ_PTR(_fr_61557);
        _30778 = (int)*(((s1_ptr)_2)->base + 12);
        DeRef(_d_61633);
        _2 = (int)SEQ_PTR(_30778);
        _d_61633 = (int)*(((s1_ptr)_2)->base + _i_61630);
        Ref(_d_61633);
        _30778 = NOVALUE;

        /** 			if sequence( d ) and d[1] = PAM_RECORD then*/
        _30780 = IS_SEQUENCE(_d_61633);
        if (_30780 == 0) {
            goto LC; // [324] 405
        }
        _2 = (int)SEQ_PTR(_d_61633);
        _30782 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30782)) {
            _30783 = (_30782 == 1);
        }
        else {
            _30783 = binary_op(EQUALS, _30782, 1);
        }
        _30782 = NOVALUE;
        if (_30783 == 0) {
            DeRef(_30783);
            _30783 = NOVALUE;
            goto LC; // [339] 405
        }
        else {
            if (!IS_ATOM_INT(_30783) && DBL_PTR(_30783)->dbl == 0.0){
                DeRef(_30783);
                _30783 = NOVALUE;
                goto LC; // [339] 405
            }
            DeRef(_30783);
            _30783 = NOVALUE;
        }
        DeRef(_30783);
        _30783 = NOVALUE;

        /** 				symtab_index param = d[2]*/
        _2 = (int)SEQ_PTR(_d_61633);
        _param_61643 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_61643)){
            _param_61643 = (long)DBL_PTR(_param_61643)->dbl;
        }

        /** 				token old = {RECORDED, d[3]}*/
        _2 = (int)SEQ_PTR(_d_61633);
        _30785 = (int)*(((s1_ptr)_2)->base + 3);
        Ref(_30785);
        DeRef(_old_61646);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = 508;
        ((int *)_2)[2] = _30785;
        _old_61646 = MAKE_SEQ(_1);
        _30785 = NOVALUE;

        /** 				token new = {VARIABLE, sym}*/
        DeRefi(_new_61651);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _sym_61560;
        _new_61651 = MAKE_SEQ(_1);

        /** 				SymTab[param][S_CODE] = find_replace( old, SymTab[param][S_CODE], new )*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_param_61643 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30790 = (int)*(((s1_ptr)_2)->base + _param_61643);
        _2 = (int)SEQ_PTR(_30790);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _30791 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _30791 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        _30790 = NOVALUE;
        RefDS(_old_61646);
        Ref(_30791);
        RefDS(_new_61651);
        _30792 = _20find_replace(_old_61646, _30791, _new_61651, 0);
        _30791 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_11366))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
        _1 = *(int *)_2;
        *(int *)_2 = _30792;
        if( _1 != _30792 ){
            DeRef(_1);
        }
        _30792 = NOVALUE;
        _30788 = NOVALUE;
LC: 
        DeRef(_old_61646);
        _old_61646 = NOVALUE;
        DeRefi(_new_61651);
        _new_61651 = NOVALUE;
        DeRef(_d_61633);
        _d_61633 = NOVALUE;

        /** 		end for*/
        _i_61630 = _i_61630 + 1;
        goto LA; // [411] 309
LB: 
        ;
    }

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61556);
L9: 

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_61555);
    DeRef(_fr_61557);
    _30776 = NOVALUE;
    DeRef(_30751);
    _30751 = NOVALUE;
    DeRef(_30746);
    _30746 = NOVALUE;
    return;
    ;
}


void _29patch_forward_init_check(int _tok_61667, int _ref_61668)
{
    int _fr_61669 = NOVALUE;
    int _30800 = NOVALUE;
    int _30799 = NOVALUE;
    int _30798 = NOVALUE;
    int _30796 = NOVALUE;
    int _30795 = NOVALUE;
    int _30794 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61669);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61669 = (int)*(((s1_ptr)_2)->base + _ref_61668);
    Ref(_fr_61669);

    /** 	set_code( ref )*/
    _29set_code(_ref_61668);

    /** 	if sequence( fr[FR_DATA] ) then*/
    _2 = (int)SEQ_PTR(_fr_61669);
    _30794 = (int)*(((s1_ptr)_2)->base + 12);
    _30795 = IS_SEQUENCE(_30794);
    _30794 = NOVALUE;
    if (_30795 == 0)
    {
        _30795 = NOVALUE;
        goto L1; // [27] 38
    }
    else{
        _30795 = NOVALUE;
    }

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61668);
    goto L2; // [35] 85
L1: 

    /** 	elsif fr[FR_PC] > 0 then*/
    _2 = (int)SEQ_PTR(_fr_61669);
    _30796 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(LESSEQ, _30796, 0)){
        _30796 = NOVALUE;
        goto L3; // [44] 78
    }
    _30796 = NOVALUE;

    /** 		Code[fr[FR_PC]+1] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_fr_61669);
    _30798 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_30798)) {
        _30799 = _30798 + 1;
        if (_30799 > MAXINT){
            _30799 = NewDouble((double)_30799);
        }
    }
    else
    _30799 = binary_op(PLUS, 1, _30798);
    _30798 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_61667);
    _30800 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30800);
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30799))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30799)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _30799);
    _1 = *(int *)_2;
    *(int *)_2 = _30800;
    if( _1 != _30800 ){
        DeRef(_1);
    }
    _30800 = NOVALUE;

    /** 		resolved_reference( ref )*/
    _29resolved_reference(_ref_61668);
    goto L2; // [75] 85
L3: 

    /** 		forward_error( tok, ref )*/
    Ref(_tok_61667);
    _29forward_error(_tok_61667, _ref_61668);
L2: 

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_61667);
    DeRef(_fr_61669);
    DeRef(_30799);
    _30799 = NOVALUE;
    return;
    ;
}


int _29expected_name(int _id_61686)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_id_61686)) {
        _1 = (long)(DBL_PTR(_id_61686)->dbl);
        DeRefDS(_id_61686);
        _id_61686 = _1;
    }

    /** 	switch id with fallthru do*/
    _0 = _id_61686;
    switch ( _0 ){ 

        /** 		case PROC then*/
        case 27:
        case 195:

        /** 			return "a procedure"*/
        RefDS(_26111);
        return _26111;

        /** 		case FUNC then*/
        case 501:
        case 196:

        /** 			return "a function"*/
        RefDS(_26057);
        return _26057;

        /** 		case VARIABLE then*/
        case -100:

        /** 			return "a variable, constant or enum"*/
        RefDS(_30803);
        return _30803;

        /** 		case else*/
        default:

        /** 			return "something"*/
        RefDS(_30804);
        return _30804;
    ;}    ;
}


void _29patch_forward_type(int _tok_61703, int _ref_61704)
{
    int _fr_61705 = NOVALUE;
    int _syms_61707 = NOVALUE;
    int _30816 = NOVALUE;
    int _30815 = NOVALUE;
    int _30813 = NOVALUE;
    int _30812 = NOVALUE;
    int _30811 = NOVALUE;
    int _30809 = NOVALUE;
    int _30808 = NOVALUE;
    int _30807 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61705);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61705 = (int)*(((s1_ptr)_2)->base + _ref_61704);
    Ref(_fr_61705);

    /** 	sequence syms = fr[FR_DATA]*/
    DeRef(_syms_61707);
    _2 = (int)SEQ_PTR(_fr_61705);
    _syms_61707 = (int)*(((s1_ptr)_2)->base + 12);
    Ref(_syms_61707);

    /** 	for i = 2 to length( syms ) do*/
    if (IS_SEQUENCE(_syms_61707)){
            _30807 = SEQ_PTR(_syms_61707)->length;
    }
    else {
        _30807 = 1;
    }
    {
        int _i_61710;
        _i_61710 = 2;
L1: 
        if (_i_61710 > _30807){
            goto L2; // [26] 102
        }

        /** 		SymTab[syms[i]][S_VTYPE] = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_syms_61707);
        _30808 = (int)*(((s1_ptr)_2)->base + _i_61710);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30808))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30808)->dbl));
        else
        _3 = (int)(_30808 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_61703);
        _30811 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30811);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _30811;
        if( _1 != _30811 ){
            DeRef(_1);
        }
        _30811 = NOVALUE;
        _30809 = NOVALUE;

        /** 		if TRANSLATE then*/
        if (_12TRANSLATE_11319 == 0)
        {
            goto L3; // [62] 95
        }
        else{
        }

        /** 			SymTab[syms[i]][S_GTYPE] = CompileType(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_syms_61707);
        _30812 = (int)*(((s1_ptr)_2)->base + _i_61710);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_30812))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30812)->dbl));
        else
        _3 = (int)(_30812 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_tok_61703);
        _30815 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30815);
        _30816 = _30CompileType(_30815);
        _30815 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 36);
        _1 = *(int *)_2;
        *(int *)_2 = _30816;
        if( _1 != _30816 ){
            DeRef(_1);
        }
        _30816 = NOVALUE;
        _30813 = NOVALUE;
L3: 

        /** 	end for*/
        _i_61710 = _i_61710 + 1;
        goto L1; // [97] 33
L2: 
        ;
    }

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61704);

    /** end procedure*/
    DeRef(_tok_61703);
    DeRef(_fr_61705);
    DeRef(_syms_61707);
    _30808 = NOVALUE;
    _30812 = NOVALUE;
    return;
    ;
}


void _29patch_forward_case(int _tok_61733, int _ref_61734)
{
    int _fr_61735 = NOVALUE;
    int _switch_pc_61737 = NOVALUE;
    int _case_sym_61740 = NOVALUE;
    int _case_values_61769 = NOVALUE;
    int _cx_61774 = NOVALUE;
    int _negative_61782 = NOVALUE;
    int _30854 = NOVALUE;
    int _30853 = NOVALUE;
    int _30852 = NOVALUE;
    int _30851 = NOVALUE;
    int _30850 = NOVALUE;
    int _30849 = NOVALUE;
    int _30847 = NOVALUE;
    int _30845 = NOVALUE;
    int _30844 = NOVALUE;
    int _30842 = NOVALUE;
    int _30841 = NOVALUE;
    int _30838 = NOVALUE;
    int _30836 = NOVALUE;
    int _30835 = NOVALUE;
    int _30834 = NOVALUE;
    int _30833 = NOVALUE;
    int _30832 = NOVALUE;
    int _30831 = NOVALUE;
    int _30830 = NOVALUE;
    int _30829 = NOVALUE;
    int _30828 = NOVALUE;
    int _30826 = NOVALUE;
    int _30825 = NOVALUE;
    int _30824 = NOVALUE;
    int _30823 = NOVALUE;
    int _30821 = NOVALUE;
    int _30819 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61735);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61735 = (int)*(((s1_ptr)_2)->base + _ref_61734);
    Ref(_fr_61735);

    /** 	integer switch_pc = fr[FR_DATA]*/
    _2 = (int)SEQ_PTR(_fr_61735);
    _switch_pc_61737 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_switch_pc_61737))
    _switch_pc_61737 = (long)DBL_PTR(_switch_pc_61737)->dbl;

    /** 	if fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_fr_61735);
    _30819 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _30819, _12TopLevelSub_11689)){
        _30819 = NOVALUE;
        goto L1; // [27] 48
    }
    _30819 = NOVALUE;

    /** 		case_sym = Code[switch_pc + 2]*/
    _30821 = _switch_pc_61737 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _case_sym_61740 = (int)*(((s1_ptr)_2)->base + _30821);
    if (!IS_ATOM_INT(_case_sym_61740)){
        _case_sym_61740 = (long)DBL_PTR(_case_sym_61740)->dbl;
    }
    goto L2; // [45] 77
L1: 

    /** 		case_sym = SymTab[fr[FR_SUBPROG]][S_CODE][switch_pc + 2]*/
    _2 = (int)SEQ_PTR(_fr_61735);
    _30823 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30823)){
        _30824 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30823)->dbl));
    }
    else{
        _30824 = (int)*(((s1_ptr)_2)->base + _30823);
    }
    _2 = (int)SEQ_PTR(_30824);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _30825 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _30825 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _30824 = NOVALUE;
    _30826 = _switch_pc_61737 + 2;
    _2 = (int)SEQ_PTR(_30825);
    _case_sym_61740 = (int)*(((s1_ptr)_2)->base + _30826);
    if (!IS_ATOM_INT(_case_sym_61740)){
        _case_sym_61740 = (long)DBL_PTR(_case_sym_61740)->dbl;
    }
    _30825 = NOVALUE;
L2: 

    /** 	if SymTab[tok[T_SYM]][S_FILE_NO] = fr[FR_FILE] and fr[FR_SUBPROG] = TopLevelSub then*/
    _2 = (int)SEQ_PTR(_tok_61733);
    _30828 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30828)){
        _30829 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30828)->dbl));
    }
    else{
        _30829 = (int)*(((s1_ptr)_2)->base + _30828);
    }
    _2 = (int)SEQ_PTR(_30829);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _30830 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _30830 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _30829 = NOVALUE;
    _2 = (int)SEQ_PTR(_fr_61735);
    _30831 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_30830) && IS_ATOM_INT(_30831)) {
        _30832 = (_30830 == _30831);
    }
    else {
        _30832 = binary_op(EQUALS, _30830, _30831);
    }
    _30830 = NOVALUE;
    _30831 = NOVALUE;
    if (IS_ATOM_INT(_30832)) {
        if (_30832 == 0) {
            goto L3; // [105] 129
        }
    }
    else {
        if (DBL_PTR(_30832)->dbl == 0.0) {
            goto L3; // [105] 129
        }
    }
    _2 = (int)SEQ_PTR(_fr_61735);
    _30834 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_30834)) {
        _30835 = (_30834 == _12TopLevelSub_11689);
    }
    else {
        _30835 = binary_op(EQUALS, _30834, _12TopLevelSub_11689);
    }
    _30834 = NOVALUE;
    if (_30835 == 0) {
        DeRef(_30835);
        _30835 = NOVALUE;
        goto L3; // [120] 129
    }
    else {
        if (!IS_ATOM_INT(_30835) && DBL_PTR(_30835)->dbl == 0.0){
            DeRef(_30835);
            _30835 = NOVALUE;
            goto L3; // [120] 129
        }
        DeRef(_30835);
        _30835 = NOVALUE;
    }
    DeRef(_30835);
    _30835 = NOVALUE;

    /** 		return*/
    DeRef(_tok_61733);
    DeRef(_fr_61735);
    DeRef(_case_values_61769);
    DeRef(_30821);
    _30821 = NOVALUE;
    _30823 = NOVALUE;
    _30828 = NOVALUE;
    DeRef(_30826);
    _30826 = NOVALUE;
    DeRef(_30832);
    _30832 = NOVALUE;
    return;
L3: 

    /** 	sequence case_values = SymTab[case_sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30836 = (int)*(((s1_ptr)_2)->base + _case_sym_61740);
    DeRef(_case_values_61769);
    _2 = (int)SEQ_PTR(_30836);
    _case_values_61769 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_case_values_61769);
    _30836 = NOVALUE;

    /** 	integer cx = find( { ref }, case_values )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _ref_61734;
    _30838 = MAKE_SEQ(_1);
    _cx_61774 = find_from(_30838, _case_values_61769, 1);
    DeRefDS(_30838);
    _30838 = NOVALUE;

    /** 	if not cx then*/
    if (_cx_61774 != 0)
    goto L4; // [160] 178

    /** 		cx = find( { -ref }, case_values )*/
    if ((unsigned long)_ref_61734 == 0xC0000000)
    _30841 = (int)NewDouble((double)-0xC0000000);
    else
    _30841 = - _ref_61734;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30841;
    _30842 = MAKE_SEQ(_1);
    _30841 = NOVALUE;
    _cx_61774 = find_from(_30842, _case_values_61769, 1);
    DeRefDS(_30842);
    _30842 = NOVALUE;
L4: 

    /**  	ifdef DEBUG then	*/

    /** 	integer negative = 0*/
    _negative_61782 = 0;

    /** 	if case_values[cx][1] < 0 then*/
    _2 = (int)SEQ_PTR(_case_values_61769);
    _30844 = (int)*(((s1_ptr)_2)->base + _cx_61774);
    _2 = (int)SEQ_PTR(_30844);
    _30845 = (int)*(((s1_ptr)_2)->base + 1);
    _30844 = NOVALUE;
    if (binary_op_a(GREATEREQ, _30845, 0)){
        _30845 = NOVALUE;
        goto L5; // [195] 224
    }
    _30845 = NOVALUE;

    /** 		negative = 1*/
    _negative_61782 = 1;

    /** 		case_values[cx][1] *= -1*/
    _2 = (int)SEQ_PTR(_case_values_61769);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61769 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cx_61774 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30849 = (int)*(((s1_ptr)_2)->base + 1);
    _30847 = NOVALUE;
    if (IS_ATOM_INT(_30849)) {
        if (_30849 == (short)_30849)
        _30850 = _30849 * -1;
        else
        _30850 = NewDouble(_30849 * (double)-1);
    }
    else {
        _30850 = binary_op(MULTIPLY, _30849, -1);
    }
    _30849 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _30850;
    if( _1 != _30850 ){
        DeRef(_1);
    }
    _30850 = NOVALUE;
    _30847 = NOVALUE;
L5: 

    /** 	if negative then*/
    if (_negative_61782 == 0)
    {
        goto L6; // [226] 247
    }
    else{
    }

    /** 		case_values[cx] = - tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61733);
    _30851 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30851)) {
        if ((unsigned long)_30851 == 0xC0000000)
        _30852 = (int)NewDouble((double)-0xC0000000);
        else
        _30852 = - _30851;
    }
    else {
        _30852 = unary_op(UMINUS, _30851);
    }
    _30851 = NOVALUE;
    _2 = (int)SEQ_PTR(_case_values_61769);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61769 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_61774);
    _1 = *(int *)_2;
    *(int *)_2 = _30852;
    if( _1 != _30852 ){
        DeRef(_1);
    }
    _30852 = NOVALUE;
    goto L7; // [244] 260
L6: 

    /** 		case_values[cx] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61733);
    _30853 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30853);
    _2 = (int)SEQ_PTR(_case_values_61769);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _case_values_61769 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _cx_61774);
    _1 = *(int *)_2;
    *(int *)_2 = _30853;
    if( _1 != _30853 ){
        DeRef(_1);
    }
    _30853 = NOVALUE;
L7: 

    /** 	SymTab[case_sym][S_OBJ] = case_values*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_case_sym_61740 + ((s1_ptr)_2)->base);
    RefDS(_case_values_61769);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _case_values_61769;
    DeRef(_1);
    _30854 = NOVALUE;

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61734);

    /** end procedure*/
    DeRef(_tok_61733);
    DeRef(_fr_61735);
    DeRefDS(_case_values_61769);
    DeRef(_30821);
    _30821 = NOVALUE;
    _30823 = NOVALUE;
    _30828 = NOVALUE;
    DeRef(_30826);
    _30826 = NOVALUE;
    DeRef(_30832);
    _30832 = NOVALUE;
    return;
    ;
}


void _29patch_forward_type_check(int _tok_61805, int _ref_61806)
{
    int _fr_61807 = NOVALUE;
    int _which_type_61810 = NOVALUE;
    int _var_61812 = NOVALUE;
    int _pc_61845 = NOVALUE;
    int _with_type_check_61847 = NOVALUE;
    int _c_61877 = NOVALUE;
    int _subprog_inlined_insert_code_at_332_61886 = NOVALUE;
    int _code_inlined_insert_code_at_329_61885 = NOVALUE;
    int _subprog_inlined_insert_code_at_415_61902 = NOVALUE;
    int _code_inlined_insert_code_at_412_61901 = NOVALUE;
    int _subprog_inlined_insert_code_at_477_61912 = NOVALUE;
    int _code_inlined_insert_code_at_474_61911 = NOVALUE;
    int _subprog_inlined_insert_code_at_539_61922 = NOVALUE;
    int _code_inlined_insert_code_at_536_61921 = NOVALUE;
    int _start_pc_61929 = NOVALUE;
    int _subprog_inlined_insert_code_at_647_61946 = NOVALUE;
    int _code_inlined_insert_code_at_644_61945 = NOVALUE;
    int _c_61949 = NOVALUE;
    int _subprog_inlined_insert_code_at_741_61965 = NOVALUE;
    int _code_inlined_insert_code_at_738_61964 = NOVALUE;
    int _start_pc_61976 = NOVALUE;
    int _subprog_inlined_insert_code_at_886_61996 = NOVALUE;
    int _code_inlined_insert_code_at_883_61995 = NOVALUE;
    int _subprog_inlined_insert_code_at_987_62017 = NOVALUE;
    int _code_inlined_insert_code_at_984_62016 = NOVALUE;
    int _30944 = NOVALUE;
    int _30943 = NOVALUE;
    int _30942 = NOVALUE;
    int _30941 = NOVALUE;
    int _30940 = NOVALUE;
    int _30939 = NOVALUE;
    int _30938 = NOVALUE;
    int _30936 = NOVALUE;
    int _30934 = NOVALUE;
    int _30933 = NOVALUE;
    int _30932 = NOVALUE;
    int _30931 = NOVALUE;
    int _30930 = NOVALUE;
    int _30929 = NOVALUE;
    int _30928 = NOVALUE;
    int _30926 = NOVALUE;
    int _30925 = NOVALUE;
    int _30924 = NOVALUE;
    int _30923 = NOVALUE;
    int _30922 = NOVALUE;
    int _30921 = NOVALUE;
    int _30919 = NOVALUE;
    int _30918 = NOVALUE;
    int _30917 = NOVALUE;
    int _30916 = NOVALUE;
    int _30914 = NOVALUE;
    int _30913 = NOVALUE;
    int _30910 = NOVALUE;
    int _30909 = NOVALUE;
    int _30907 = NOVALUE;
    int _30906 = NOVALUE;
    int _30905 = NOVALUE;
    int _30904 = NOVALUE;
    int _30903 = NOVALUE;
    int _30902 = NOVALUE;
    int _30900 = NOVALUE;
    int _30899 = NOVALUE;
    int _30896 = NOVALUE;
    int _30895 = NOVALUE;
    int _30892 = NOVALUE;
    int _30891 = NOVALUE;
    int _30887 = NOVALUE;
    int _30886 = NOVALUE;
    int _30884 = NOVALUE;
    int _30883 = NOVALUE;
    int _30881 = NOVALUE;
    int _30880 = NOVALUE;
    int _30877 = NOVALUE;
    int _30874 = NOVALUE;
    int _30872 = NOVALUE;
    int _30869 = NOVALUE;
    int _30868 = NOVALUE;
    int _30865 = NOVALUE;
    int _30860 = NOVALUE;
    int _30859 = NOVALUE;
    int _30857 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence fr = forward_references[ref]*/
    DeRef(_fr_61807);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _fr_61807 = (int)*(((s1_ptr)_2)->base + _ref_61806);
    Ref(_fr_61807);

    /** 	if fr[FR_OP] = TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_fr_61807);
    _30857 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30857, 197)){
        _30857 = NOVALUE;
        goto L1; // [21] 86
    }
    _30857 = NOVALUE;

    /** 		which_type = SymTab[tok[T_SYM]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_tok_61805);
    _30859 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30859)){
        _30860 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30859)->dbl));
    }
    else{
        _30860 = (int)*(((s1_ptr)_2)->base + _30859);
    }
    _2 = (int)SEQ_PTR(_30860);
    _which_type_61810 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_61810)){
        _which_type_61810 = (long)DBL_PTR(_which_type_61810)->dbl;
    }
    _30860 = NOVALUE;

    /** 		if not which_type then*/
    if (_which_type_61810 != 0)
    goto L2; // [49] 72

    /** 			which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61805);
    _which_type_61810 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_61810)){
        _which_type_61810 = (long)DBL_PTR(_which_type_61810)->dbl;
    }

    /** 			var = 0*/
    _var_61812 = 0;
    goto L3; // [69] 144
L2: 

    /** 			var = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61805);
    _var_61812 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_var_61812)){
        _var_61812 = (long)DBL_PTR(_var_61812)->dbl;
    }
    goto L3; // [83] 144
L1: 

    /** 	elsif fr[FR_OP] = TYPE then*/
    _2 = (int)SEQ_PTR(_fr_61807);
    _30865 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(NOTEQ, _30865, 504)){
        _30865 = NOVALUE;
        goto L4; // [94] 118
    }
    _30865 = NOVALUE;

    /** 		which_type = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_61805);
    _which_type_61810 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_which_type_61810)){
        _which_type_61810 = (long)DBL_PTR(_which_type_61810)->dbl;
    }

    /** 		var = 0*/
    _var_61812 = 0;
    goto L3; // [115] 144
L4: 

    /** 		prep_forward_error( ref )*/
    _29prep_forward_error(_ref_61806);

    /** 		InternalErr( 262, { TYPE_CHECK, TYPE_CHECK_FORWARD, fr[FR_OP] })*/
    _2 = (int)SEQ_PTR(_fr_61807);
    _30868 = (int)*(((s1_ptr)_2)->base + 10);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 65;
    *((int *)(_2+8)) = 197;
    Ref(_30868);
    *((int *)(_2+12)) = _30868;
    _30869 = MAKE_SEQ(_1);
    _30868 = NOVALUE;
    _43InternalErr(262, _30869);
    _30869 = NOVALUE;
L3: 

    /** 	if which_type < 0 then*/
    if (_which_type_61810 >= 0)
    goto L5; // [148] 158

    /** 		return*/
    DeRef(_tok_61805);
    DeRef(_fr_61807);
    _30859 = NOVALUE;
    return;
L5: 

    /** 	set_code( ref )*/
    _29set_code(_ref_61806);

    /** 	integer pc = fr[FR_PC]*/
    _2 = (int)SEQ_PTR(_fr_61807);
    _pc_61845 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_pc_61845))
    _pc_61845 = (long)DBL_PTR(_pc_61845)->dbl;

    /** 	integer with_type_check = Code[pc + 2]*/
    _30872 = _pc_61845 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _with_type_check_61847 = (int)*(((s1_ptr)_2)->base + _30872);
    if (!IS_ATOM_INT(_with_type_check_61847)){
        _with_type_check_61847 = (long)DBL_PTR(_with_type_check_61847)->dbl;
    }

    /** 	if Code[pc] != TYPE_CHECK_FORWARD then*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _30874 = (int)*(((s1_ptr)_2)->base + _pc_61845);
    if (binary_op_a(EQUALS, _30874, 197)){
        _30874 = NOVALUE;
        goto L6; // [193] 204
    }
    _30874 = NOVALUE;

    /** 		forward_error( tok, ref )*/
    Ref(_tok_61805);
    _29forward_error(_tok_61805, _ref_61806);
L6: 

    /** 	if not var then*/
    if (_var_61812 != 0)
    goto L7; // [208] 226

    /** 		var = Code[pc+1]*/
    _30877 = _pc_61845 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _var_61812 = (int)*(((s1_ptr)_2)->base + _30877);
    if (!IS_ATOM_INT(_var_61812)){
        _var_61812 = (long)DBL_PTR(_var_61812)->dbl;
    }
L7: 

    /** 	if var < 0 then*/
    if (_var_61812 >= 0)
    goto L8; // [228] 238

    /** 		return*/
    DeRef(_tok_61805);
    DeRef(_fr_61807);
    _30859 = NOVALUE;
    DeRef(_30872);
    _30872 = NOVALUE;
    DeRef(_30877);
    _30877 = NOVALUE;
    return;
L8: 

    /** 	replace_code( {}, pc, pc + 2, fr[FR_SUBPROG])*/
    _30880 = _pc_61845 + 2;
    if ((long)((unsigned long)_30880 + (unsigned long)HIGH_BITS) >= 0) 
    _30880 = NewDouble((double)_30880);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30881 = (int)*(((s1_ptr)_2)->base + 4);
    RefDS(_21829);
    Ref(_30881);
    _29replace_code(_21829, _pc_61845, _30880, _30881);
    _30880 = NOVALUE;
    _30881 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L9; // [258] 364
    }
    else{
    }

    /** 		if with_type_check then*/
    if (_with_type_check_61847 == 0)
    {
        goto LA; // [263] 771
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_61810 == _52object_type_45731)
    goto LA; // [270] 771

    /** 				if SymTab[which_type][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30883 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30883);
    _30884 = (int)*(((s1_ptr)_2)->base + 23);
    _30883 = NOVALUE;
    if (_30884 == 0) {
        _30884 = NOVALUE;
        goto LB; // [288] 357
    }
    else {
        if (!IS_ATOM_INT(_30884) && DBL_PTR(_30884)->dbl == 0.0){
            _30884 = NOVALUE;
            goto LB; // [288] 357
        }
        _30884 = NOVALUE;
    }
    _30884 = NOVALUE;

    /** 					integer c = NewTempSym()*/
    _c_61877 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_61877)) {
        _1 = (long)(DBL_PTR(_c_61877)->dbl);
        DeRefDS(_c_61877);
        _c_61877 = _1;
    }

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_61810;
    *((int *)(_2+12)) = _var_61812;
    *((int *)(_2+16)) = _c_61877;
    *((int *)(_2+20)) = 65;
    _30886 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30887 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_329_61885);
    _code_inlined_insert_code_at_329_61885 = _30886;
    _30886 = NOVALUE;
    Ref(_30887);
    DeRef(_subprog_inlined_insert_code_at_332_61886);
    _subprog_inlined_insert_code_at_332_61886 = _30887;
    _30887 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_332_61886)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_332_61886)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_332_61886);
        _subprog_inlined_insert_code_at_332_61886 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_332_61886;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_329_61885);
    _64insert_code(_code_inlined_insert_code_at_329_61885, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto LC; // [345] 348
LC: 
    DeRefi(_code_inlined_insert_code_at_329_61885);
    _code_inlined_insert_code_at_329_61885 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_332_61886);
    _subprog_inlined_insert_code_at_332_61886 = NOVALUE;

    /** 					pc += 5*/
    _pc_61845 = _pc_61845 + 5;
LB: 
    goto LA; // [361] 771
L9: 

    /** 		if with_type_check then*/
    if (_with_type_check_61847 == 0)
    {
        goto LD; // [366] 770
    }
    else{
    }

    /** 			if which_type = object_type then*/
    if (_which_type_61810 != _52object_type_45731)
    goto LE; // [373] 380
    goto LF; // [377] 769
LE: 

    /** 				if which_type = integer_type then*/
    if (_which_type_61810 != _52integer_type_45737)
    goto L10; // [384] 442

    /** 					insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61812;
    _30891 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30892 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_412_61901);
    _code_inlined_insert_code_at_412_61901 = _30891;
    _30891 = NOVALUE;
    Ref(_30892);
    DeRef(_subprog_inlined_insert_code_at_415_61902);
    _subprog_inlined_insert_code_at_415_61902 = _30892;
    _30892 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_415_61902)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_415_61902)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_415_61902);
        _subprog_inlined_insert_code_at_415_61902 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_415_61902;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_412_61901);
    _64insert_code(_code_inlined_insert_code_at_412_61901, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L11; // [428] 431
L11: 
    DeRefi(_code_inlined_insert_code_at_412_61901);
    _code_inlined_insert_code_at_412_61901 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_415_61902);
    _subprog_inlined_insert_code_at_415_61902 = NOVALUE;

    /** 					pc += 2*/
    _pc_61845 = _pc_61845 + 2;
    goto L12; // [439] 768
L10: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_61810 != _52sequence_type_45735)
    goto L13; // [446] 504

    /** 					insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_61812;
    _30895 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30896 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_474_61911);
    _code_inlined_insert_code_at_474_61911 = _30895;
    _30895 = NOVALUE;
    Ref(_30896);
    DeRef(_subprog_inlined_insert_code_at_477_61912);
    _subprog_inlined_insert_code_at_477_61912 = _30896;
    _30896 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_477_61912)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_477_61912)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_477_61912);
        _subprog_inlined_insert_code_at_477_61912 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_477_61912;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_474_61911);
    _64insert_code(_code_inlined_insert_code_at_474_61911, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L14; // [490] 493
L14: 
    DeRefi(_code_inlined_insert_code_at_474_61911);
    _code_inlined_insert_code_at_474_61911 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_477_61912);
    _subprog_inlined_insert_code_at_477_61912 = NOVALUE;

    /** 					pc += 2*/
    _pc_61845 = _pc_61845 + 2;
    goto L12; // [501] 768
L13: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_61810 != _52atom_type_45733)
    goto L15; // [508] 566

    /** 					insert_code( { ATOM_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 101;
    ((int *)_2)[2] = _var_61812;
    _30899 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30900 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_536_61921);
    _code_inlined_insert_code_at_536_61921 = _30899;
    _30899 = NOVALUE;
    Ref(_30900);
    DeRef(_subprog_inlined_insert_code_at_539_61922);
    _subprog_inlined_insert_code_at_539_61922 = _30900;
    _30900 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_539_61922)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_539_61922)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_539_61922);
        _subprog_inlined_insert_code_at_539_61922 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_539_61922;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_536_61921);
    _64insert_code(_code_inlined_insert_code_at_536_61921, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L16; // [552] 555
L16: 
    DeRefi(_code_inlined_insert_code_at_536_61921);
    _code_inlined_insert_code_at_536_61921 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_539_61922);
    _subprog_inlined_insert_code_at_539_61922 = NOVALUE;

    /** 					pc += 2*/
    _pc_61845 = _pc_61845 + 2;
    goto L12; // [563] 768
L15: 

    /** 				elsif SymTab[which_type][S_NEXT] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30902 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30902);
    _30903 = (int)*(((s1_ptr)_2)->base + 2);
    _30902 = NOVALUE;
    if (_30903 == 0) {
        _30903 = NOVALUE;
        goto L17; // [580] 765
    }
    else {
        if (!IS_ATOM_INT(_30903) && DBL_PTR(_30903)->dbl == 0.0){
            _30903 = NOVALUE;
            goto L17; // [580] 765
        }
        _30903 = NOVALUE;
    }
    _30903 = NOVALUE;

    /** 					integer start_pc = pc*/
    _start_pc_61929 = _pc_61845;

    /** 					if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] = integer_type then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30904 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30904);
    _30905 = (int)*(((s1_ptr)_2)->base + 2);
    _30904 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30905)){
        _30906 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30905)->dbl));
    }
    else{
        _30906 = (int)*(((s1_ptr)_2)->base + _30905);
    }
    _2 = (int)SEQ_PTR(_30906);
    _30907 = (int)*(((s1_ptr)_2)->base + 15);
    _30906 = NOVALUE;
    if (binary_op_a(NOTEQ, _30907, _52integer_type_45737)){
        _30907 = NOVALUE;
        goto L18; // [616] 672
    }
    _30907 = NOVALUE;

    /** 						insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61812;
    _30909 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30910 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_644_61945);
    _code_inlined_insert_code_at_644_61945 = _30909;
    _30909 = NOVALUE;
    Ref(_30910);
    DeRef(_subprog_inlined_insert_code_at_647_61946);
    _subprog_inlined_insert_code_at_647_61946 = _30910;
    _30910 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_647_61946)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_647_61946)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_647_61946);
        _subprog_inlined_insert_code_at_647_61946 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_647_61946;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_644_61945);
    _64insert_code(_code_inlined_insert_code_at_644_61945, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L19; // [660] 663
L19: 
    DeRefi(_code_inlined_insert_code_at_644_61945);
    _code_inlined_insert_code_at_644_61945 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_647_61946);
    _subprog_inlined_insert_code_at_647_61946 = NOVALUE;

    /** 						pc += 2*/
    _pc_61845 = _pc_61845 + 2;
L18: 

    /** 					symtab_index c = NewTempSym()*/
    _c_61949 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_c_61949)) {
        _1 = (long)(DBL_PTR(_c_61949)->dbl);
        DeRefDS(_c_61949);
        _c_61949 = _1;
    }

    /** 					SymTab[fr[FR_SUBPROG]][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_fr_61807);
    _30913 = (int)*(((s1_ptr)_2)->base + 4);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30913))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30913)->dbl));
    else
    _3 = (int)(_30913 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _30916 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _30916 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _30914 = NOVALUE;
    if (IS_ATOM_INT(_30916)) {
        _30917 = _30916 + 1;
        if (_30917 > MAXINT){
            _30917 = NewDouble((double)_30917);
        }
    }
    else
    _30917 = binary_op(PLUS, 1, _30916);
    _30916 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    _1 = *(int *)_2;
    *(int *)_2 = _30917;
    if( _1 != _30917 ){
        DeRef(_1);
    }
    _30917 = NOVALUE;
    _30914 = NOVALUE;

    /** 					insert_code( { PROC, which_type, var, c, TYPE_CHECK }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 27;
    *((int *)(_2+8)) = _which_type_61810;
    *((int *)(_2+12)) = _var_61812;
    *((int *)(_2+16)) = _c_61949;
    *((int *)(_2+20)) = 65;
    _30918 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30919 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_738_61964);
    _code_inlined_insert_code_at_738_61964 = _30918;
    _30918 = NOVALUE;
    Ref(_30919);
    DeRef(_subprog_inlined_insert_code_at_741_61965);
    _subprog_inlined_insert_code_at_741_61965 = _30919;
    _30919 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_741_61965)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_741_61965)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_741_61965);
        _subprog_inlined_insert_code_at_741_61965 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_741_61965;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_738_61964);
    _64insert_code(_code_inlined_insert_code_at_738_61964, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L1A; // [753] 756
L1A: 
    DeRefi(_code_inlined_insert_code_at_738_61964);
    _code_inlined_insert_code_at_738_61964 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_741_61965);
    _subprog_inlined_insert_code_at_741_61965 = NOVALUE;

    /** 					pc += 4*/
    _pc_61845 = _pc_61845 + 4;
L17: 
L12: 
LF: 
LD: 
LA: 

    /** 	if (TRANSLATE or not with_type_check) and SymTab[which_type][S_NEXT] then*/
    if (_12TRANSLATE_11319 != 0) {
        _30921 = 1;
        goto L1B; // [775] 786
    }
    _30922 = (_with_type_check_61847 == 0);
    _30921 = (_30922 != 0);
L1B: 
    if (_30921 == 0) {
        goto L1C; // [786] 1013
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30924 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30924);
    _30925 = (int)*(((s1_ptr)_2)->base + 2);
    _30924 = NOVALUE;
    if (_30925 == 0) {
        _30925 = NOVALUE;
        goto L1C; // [803] 1013
    }
    else {
        if (!IS_ATOM_INT(_30925) && DBL_PTR(_30925)->dbl == 0.0){
            _30925 = NOVALUE;
            goto L1C; // [803] 1013
        }
        _30925 = NOVALUE;
    }
    _30925 = NOVALUE;

    /** 		integer start_pc = pc*/
    _start_pc_61976 = _pc_61845;

    /** 		if which_type = sequence_type or*/
    _30926 = (_which_type_61810 == _52sequence_type_45735);
    if (_30926 != 0) {
        goto L1D; // [819] 858
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30928 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30928);
    _30929 = (int)*(((s1_ptr)_2)->base + 2);
    _30928 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30929)){
        _30930 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30929)->dbl));
    }
    else{
        _30930 = (int)*(((s1_ptr)_2)->base + _30929);
    }
    _2 = (int)SEQ_PTR(_30930);
    _30931 = (int)*(((s1_ptr)_2)->base + 15);
    _30930 = NOVALUE;
    if (IS_ATOM_INT(_30931)) {
        _30932 = (_30931 == _52sequence_type_45735);
    }
    else {
        _30932 = binary_op(EQUALS, _30931, _52sequence_type_45735);
    }
    _30931 = NOVALUE;
    if (_30932 == 0) {
        DeRef(_30932);
        _30932 = NOVALUE;
        goto L1E; // [854] 912
    }
    else {
        if (!IS_ATOM_INT(_30932) && DBL_PTR(_30932)->dbl == 0.0){
            DeRef(_30932);
            _30932 = NOVALUE;
            goto L1E; // [854] 912
        }
        DeRef(_30932);
        _30932 = NOVALUE;
    }
    DeRef(_30932);
    _30932 = NOVALUE;
L1D: 

    /** 			insert_code( { SEQUENCE_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 97;
    ((int *)_2)[2] = _var_61812;
    _30933 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30934 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_883_61995);
    _code_inlined_insert_code_at_883_61995 = _30933;
    _30933 = NOVALUE;
    Ref(_30934);
    DeRef(_subprog_inlined_insert_code_at_886_61996);
    _subprog_inlined_insert_code_at_886_61996 = _30934;
    _30934 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_886_61996)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_886_61996)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_886_61996);
        _subprog_inlined_insert_code_at_886_61996 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_886_61996;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_883_61995);
    _64insert_code(_code_inlined_insert_code_at_883_61995, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L1F; // [898] 901
L1F: 
    DeRefi(_code_inlined_insert_code_at_883_61995);
    _code_inlined_insert_code_at_883_61995 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_886_61996);
    _subprog_inlined_insert_code_at_886_61996 = NOVALUE;

    /** 			pc += 2*/
    _pc_61845 = _pc_61845 + 2;
    goto L20; // [909] 1012
L1E: 

    /** 		elsif which_type = integer_type or*/
    _30936 = (_which_type_61810 == _52integer_type_45737);
    if (_30936 != 0) {
        goto L21; // [920] 959
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30938 = (int)*(((s1_ptr)_2)->base + _which_type_61810);
    _2 = (int)SEQ_PTR(_30938);
    _30939 = (int)*(((s1_ptr)_2)->base + 2);
    _30938 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30939)){
        _30940 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30939)->dbl));
    }
    else{
        _30940 = (int)*(((s1_ptr)_2)->base + _30939);
    }
    _2 = (int)SEQ_PTR(_30940);
    _30941 = (int)*(((s1_ptr)_2)->base + 15);
    _30940 = NOVALUE;
    if (IS_ATOM_INT(_30941)) {
        _30942 = (_30941 == _52integer_type_45737);
    }
    else {
        _30942 = binary_op(EQUALS, _30941, _52integer_type_45737);
    }
    _30941 = NOVALUE;
    if (_30942 == 0) {
        DeRef(_30942);
        _30942 = NOVALUE;
        goto L22; // [955] 1011
    }
    else {
        if (!IS_ATOM_INT(_30942) && DBL_PTR(_30942)->dbl == 0.0){
            DeRef(_30942);
            _30942 = NOVALUE;
            goto L22; // [955] 1011
        }
        DeRef(_30942);
        _30942 = NOVALUE;
    }
    DeRef(_30942);
    _30942 = NOVALUE;
L21: 

    /** 			insert_code( { INTEGER_CHECK, var }, pc, fr[FR_SUBPROG] )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 96;
    ((int *)_2)[2] = _var_61812;
    _30943 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_fr_61807);
    _30944 = (int)*(((s1_ptr)_2)->base + 4);
    DeRefi(_code_inlined_insert_code_at_984_62016);
    _code_inlined_insert_code_at_984_62016 = _30943;
    _30943 = NOVALUE;
    Ref(_30944);
    DeRef(_subprog_inlined_insert_code_at_987_62017);
    _subprog_inlined_insert_code_at_987_62017 = _30944;
    _30944 = NOVALUE;
    if (!IS_ATOM_INT(_subprog_inlined_insert_code_at_987_62017)) {
        _1 = (long)(DBL_PTR(_subprog_inlined_insert_code_at_987_62017)->dbl);
        DeRefDS(_subprog_inlined_insert_code_at_987_62017);
        _subprog_inlined_insert_code_at_987_62017 = _1;
    }

    /** 	shifting_sub = subprog*/
    _29shifting_sub_61080 = _subprog_inlined_insert_code_at_987_62017;

    /** 	shift:insert_code( code, index )*/
    RefDS(_code_inlined_insert_code_at_984_62016);
    _64insert_code(_code_inlined_insert_code_at_984_62016, _pc_61845);

    /** 	shifting_sub = 0*/
    _29shifting_sub_61080 = 0;

    /** end procedure*/
    goto L23; // [999] 1002
L23: 
    DeRefi(_code_inlined_insert_code_at_984_62016);
    _code_inlined_insert_code_at_984_62016 = NOVALUE;
    DeRef(_subprog_inlined_insert_code_at_987_62017);
    _subprog_inlined_insert_code_at_987_62017 = NOVALUE;

    /** 			pc += 4*/
    _pc_61845 = _pc_61845 + 4;
L22: 
L20: 
L1C: 

    /** 	resolved_reference( ref )*/
    _29resolved_reference(_ref_61806);

    /** 	reset_code()*/
    _29reset_code();

    /** end procedure*/
    DeRef(_tok_61805);
    DeRef(_fr_61807);
    _30859 = NOVALUE;
    DeRef(_30872);
    _30872 = NOVALUE;
    DeRef(_30877);
    _30877 = NOVALUE;
    _30905 = NOVALUE;
    _30913 = NOVALUE;
    DeRef(_30922);
    _30922 = NOVALUE;
    DeRef(_30926);
    _30926 = NOVALUE;
    _30929 = NOVALUE;
    DeRef(_30936);
    _30936 = NOVALUE;
    _30939 = NOVALUE;
    return;
    ;
}


void _29prep_forward_error(int _ref_62021)
{
    int _30952 = NOVALUE;
    int _30950 = NOVALUE;
    int _30948 = NOVALUE;
    int _30946 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62021)) {
        _1 = (long)(DBL_PTR(_ref_62021)->dbl);
        DeRefDS(_ref_62021);
        _ref_62021 = _1;
    }

    /** 	ThisLine = forward_references[ref][FR_THISLINE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30946 = (int)*(((s1_ptr)_2)->base + _ref_62021);
    DeRef(_43ThisLine_48158);
    _2 = (int)SEQ_PTR(_30946);
    _43ThisLine_48158 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_43ThisLine_48158);
    _30946 = NOVALUE;

    /** 	bp = forward_references[ref][FR_BP]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30948 = (int)*(((s1_ptr)_2)->base + _ref_62021);
    _2 = (int)SEQ_PTR(_30948);
    _43bp_48162 = (int)*(((s1_ptr)_2)->base + 8);
    if (!IS_ATOM_INT(_43bp_48162)){
        _43bp_48162 = (long)DBL_PTR(_43bp_48162)->dbl;
    }
    _30948 = NOVALUE;

    /** 	line_number = forward_references[ref][FR_LINE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30950 = (int)*(((s1_ptr)_2)->base + _ref_62021);
    _2 = (int)SEQ_PTR(_30950);
    _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 6);
    if (!IS_ATOM_INT(_12line_number_11683)){
        _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
    }
    _30950 = NOVALUE;

    /** 	current_file_no = forward_references[ref][FR_FILE]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30952 = (int)*(((s1_ptr)_2)->base + _ref_62021);
    _2 = (int)SEQ_PTR(_30952);
    _12current_file_no_11682 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12current_file_no_11682)){
        _12current_file_no_11682 = (long)DBL_PTR(_12current_file_no_11682)->dbl;
    }
    _30952 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _29forward_error(int _tok_62037, int _ref_62038)
{
    int _30959 = NOVALUE;
    int _30958 = NOVALUE;
    int _30957 = NOVALUE;
    int _30956 = NOVALUE;
    int _30955 = NOVALUE;
    int _30954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	prep_forward_error( ref )*/
    _29prep_forward_error(_ref_62038);

    /** 	CompileErr(68, { expected_name( forward_references[ref][FR_TYPE] ),*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30954 = (int)*(((s1_ptr)_2)->base + _ref_62038);
    _2 = (int)SEQ_PTR(_30954);
    _30955 = (int)*(((s1_ptr)_2)->base + 1);
    _30954 = NOVALUE;
    Ref(_30955);
    _30956 = _29expected_name(_30955);
    _30955 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_62037);
    _30957 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30957);
    _30958 = _29expected_name(_30957);
    _30957 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30956;
    ((int *)_2)[2] = _30958;
    _30959 = MAKE_SEQ(_1);
    _30958 = NOVALUE;
    _30956 = NOVALUE;
    _43CompileErr(68, _30959, 0);
    _30959 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_62037);
    return;
    ;
}


int _29find_reference(int _fr_62049)
{
    int _name_62050 = NOVALUE;
    int _file_62052 = NOVALUE;
    int _ns_file_62054 = NOVALUE;
    int _ix_62055 = NOVALUE;
    int _ns_62058 = NOVALUE;
    int _ns_tok_62062 = NOVALUE;
    int _tok_62074 = NOVALUE;
    int _30970 = NOVALUE;
    int _30967 = NOVALUE;
    int _30965 = NOVALUE;
    int _30963 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence name = fr[FR_NAME]*/
    DeRef(_name_62050);
    _2 = (int)SEQ_PTR(_fr_62049);
    _name_62050 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_name_62050);

    /** 	integer file  = fr[FR_FILE]*/
    _2 = (int)SEQ_PTR(_fr_62049);
    _file_62052 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_file_62052))
    _file_62052 = (long)DBL_PTR(_file_62052)->dbl;

    /** 	integer ns_file = -1*/
    _ns_file_62054 = -1;

    /** 	integer ix = find( ':', name )*/
    _ix_62055 = find_from(58, _name_62050, 1);

    /** 	if ix then*/
    if (_ix_62055 == 0)
    {
        goto L1; // [31] 85
    }
    else{
    }

    /** 		sequence ns = name[1..ix-1]*/
    _30963 = _ix_62055 - 1;
    rhs_slice_target = (object_ptr)&_ns_62058;
    RHS_Slice(_name_62050, 1, _30963);

    /** 		token ns_tok = keyfind( ns, ns_file, file, 1, fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62049);
    _30965 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_ns_62058);
    Ref(_30965);
    _0 = _ns_tok_62062;
    _ns_tok_62062 = _52keyfind(_ns_62058, -1, _file_62052, 1, _30965);
    DeRef(_0);
    _30965 = NOVALUE;

    /** 		if ns_tok[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_ns_tok_62062);
    _30967 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30967, 523)){
        _30967 = NOVALUE;
        goto L2; // [69] 80
    }
    _30967 = NOVALUE;

    /** 			return ns_tok*/
    DeRefDS(_ns_62058);
    DeRefDS(_fr_62049);
    DeRefDS(_name_62050);
    DeRef(_tok_62074);
    _30963 = NOVALUE;
    return _ns_tok_62062;
L2: 
    DeRef(_ns_62058);
    _ns_62058 = NOVALUE;
    DeRef(_ns_tok_62062);
    _ns_tok_62062 = NOVALUE;
    goto L3; // [82] 92
L1: 

    /** 		ns_file = fr[FR_QUALIFIED]*/
    _2 = (int)SEQ_PTR(_fr_62049);
    _ns_file_62054 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_ns_file_62054))
    _ns_file_62054 = (long)DBL_PTR(_ns_file_62054)->dbl;
L3: 

    /** 	No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 	object tok = keyfind( name, ns_file, file, , fr[FR_HASHVAL] )*/
    _2 = (int)SEQ_PTR(_fr_62049);
    _30970 = (int)*(((s1_ptr)_2)->base + 11);
    RefDS(_name_62050);
    Ref(_30970);
    _0 = _tok_62074;
    _tok_62074 = _52keyfind(_name_62050, _ns_file_62054, _file_62052, 0, _30970);
    DeRef(_0);
    _30970 = NOVALUE;

    /** 	No_new_entry = 0*/
    _52No_new_entry_46903 = 0;

    /** 	return tok*/
    DeRefDS(_fr_62049);
    DeRefDS(_name_62050);
    DeRef(_30963);
    _30963 = NOVALUE;
    return _tok_62074;
    ;
}


void _29register_forward_type(int _sym_62082, int _ref_62083)
{
    int _30977 = NOVALUE;
    int _30976 = NOVALUE;
    int _30974 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_62082)) {
        _1 = (long)(DBL_PTR(_sym_62082)->dbl);
        DeRefDS(_sym_62082);
        _sym_62082 = _1;
    }
    if (!IS_ATOM_INT(_ref_62083)) {
        _1 = (long)(DBL_PTR(_ref_62083)->dbl);
        DeRefDS(_ref_62083);
        _ref_62083 = _1;
    }

    /** 	if ref < 0 then*/
    if (_ref_62083 >= 0)
    goto L1; // [7] 19

    /** 		ref = -ref*/
    _ref_62083 = - _ref_62083;
L1: 

    /** 	forward_references[ref][FR_DATA] &= sym*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62083 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _30976 = (int)*(((s1_ptr)_2)->base + 12);
    _30974 = NOVALUE;
    if (IS_SEQUENCE(_30976) && IS_ATOM(_sym_62082)) {
        Append(&_30977, _30976, _sym_62082);
    }
    else if (IS_ATOM(_30976) && IS_SEQUENCE(_sym_62082)) {
    }
    else {
        Concat((object_ptr)&_30977, _30976, _sym_62082);
        _30976 = NOVALUE;
    }
    _30976 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _30977;
    if( _1 != _30977 ){
        DeRef(_1);
    }
    _30977 = NOVALUE;
    _30974 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _29forward_reference(int _ref_62093)
{
    int _30990 = NOVALUE;
    int _30989 = NOVALUE;
    int _30988 = NOVALUE;
    int _30987 = NOVALUE;
    int _30986 = NOVALUE;
    int _30985 = NOVALUE;
    int _30984 = NOVALUE;
    int _30982 = NOVALUE;
    int _30981 = NOVALUE;
    int _30980 = NOVALUE;
    int _30979 = NOVALUE;
    int _30978 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ref_62093)) {
        _1 = (long)(DBL_PTR(_ref_62093)->dbl);
        DeRefDS(_ref_62093);
        _ref_62093 = _1;
    }

    /** 	if 0 > ref and ref >= -length( forward_references ) then*/
    _30978 = (0 > _ref_62093);
    if (_30978 == 0) {
        goto L1; // [9] 91
    }
    if (IS_SEQUENCE(_29forward_references_61061)){
            _30980 = SEQ_PTR(_29forward_references_61061)->length;
    }
    else {
        _30980 = 1;
    }
    _30981 = - _30980;
    _30982 = (_ref_62093 >= _30981);
    _30981 = NOVALUE;
    if (_30982 == 0)
    {
        DeRef(_30982);
        _30982 = NOVALUE;
        goto L1; // [26] 91
    }
    else{
        DeRef(_30982);
        _30982 = NOVALUE;
    }

    /** 		ref = -ref*/
    _ref_62093 = - _ref_62093;

    /** 		if integer(forward_references[ref][FR_FILE]) and*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30984 = (int)*(((s1_ptr)_2)->base + _ref_62093);
    _2 = (int)SEQ_PTR(_30984);
    _30985 = (int)*(((s1_ptr)_2)->base + 3);
    _30984 = NOVALUE;
    if (IS_ATOM_INT(_30985))
    _30986 = 1;
    else if (IS_ATOM_DBL(_30985))
    _30986 = IS_ATOM_INT(DoubleToInt(_30985));
    else
    _30986 = 0;
    _30985 = NOVALUE;
    if (_30986 == 0) {
        goto L2; // [51] 81
    }
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _30988 = (int)*(((s1_ptr)_2)->base + _ref_62093);
    _2 = (int)SEQ_PTR(_30988);
    _30989 = (int)*(((s1_ptr)_2)->base + 5);
    _30988 = NOVALUE;
    if (IS_ATOM_INT(_30989))
    _30990 = 1;
    else if (IS_ATOM_DBL(_30989))
    _30990 = IS_ATOM_INT(DoubleToInt(_30989));
    else
    _30990 = 0;
    _30989 = NOVALUE;
    if (_30990 == 0)
    {
        _30990 = NOVALUE;
        goto L2; // [69] 81
    }
    else{
        _30990 = NOVALUE;
    }

    /** 				return 1*/
    DeRef(_30978);
    _30978 = NOVALUE;
    return 1;
    goto L3; // [78] 98
L2: 

    /** 			return 0*/
    DeRef(_30978);
    _30978 = NOVALUE;
    return 0;
    goto L3; // [88] 98
L1: 

    /** 		return 0*/
    DeRef(_30978);
    _30978 = NOVALUE;
    return 0;
L3: 
    ;
}


int _29new_forward_reference(int _fwd_op_62113, int _sym_62115, int _op_62116)
{
    int _ref_62117 = NOVALUE;
    int _len_62118 = NOVALUE;
    int _hashval_62148 = NOVALUE;
    int _default_sym_62223 = NOVALUE;
    int _param_62226 = NOVALUE;
    int _set_data_2__tmp_at578_62243 = NOVALUE;
    int _set_data_1__tmp_at578_62242 = NOVALUE;
    int _data_inlined_set_data_at_575_62241 = NOVALUE;
    int _31063 = NOVALUE;
    int _31062 = NOVALUE;
    int _31061 = NOVALUE;
    int _31058 = NOVALUE;
    int _31056 = NOVALUE;
    int _31055 = NOVALUE;
    int _31053 = NOVALUE;
    int _31052 = NOVALUE;
    int _31051 = NOVALUE;
    int _31049 = NOVALUE;
    int _31047 = NOVALUE;
    int _31045 = NOVALUE;
    int _31042 = NOVALUE;
    int _31041 = NOVALUE;
    int _31039 = NOVALUE;
    int _31037 = NOVALUE;
    int _31035 = NOVALUE;
    int _31033 = NOVALUE;
    int _31032 = NOVALUE;
    int _31031 = NOVALUE;
    int _31029 = NOVALUE;
    int _31026 = NOVALUE;
    int _31024 = NOVALUE;
    int _31022 = NOVALUE;
    int _31021 = NOVALUE;
    int _31020 = NOVALUE;
    int _31019 = NOVALUE;
    int _31017 = NOVALUE;
    int _31014 = NOVALUE;
    int _31013 = NOVALUE;
    int _31012 = NOVALUE;
    int _31010 = NOVALUE;
    int _31009 = NOVALUE;
    int _31008 = NOVALUE;
    int _31007 = NOVALUE;
    int _31005 = NOVALUE;
    int _31004 = NOVALUE;
    int _31003 = NOVALUE;
    int _31002 = NOVALUE;
    int _31000 = NOVALUE;
    int _30997 = NOVALUE;
    int _30996 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_fwd_op_62113)) {
        _1 = (long)(DBL_PTR(_fwd_op_62113)->dbl);
        DeRefDS(_fwd_op_62113);
        _fwd_op_62113 = _1;
    }
    if (!IS_ATOM_INT(_sym_62115)) {
        _1 = (long)(DBL_PTR(_sym_62115)->dbl);
        DeRefDS(_sym_62115);
        _sym_62115 = _1;
    }
    if (!IS_ATOM_INT(_op_62116)) {
        _1 = (long)(DBL_PTR(_op_62116)->dbl);
        DeRefDS(_op_62116);
        _op_62116 = _1;
    }

    /** 		len = length( inactive_references )*/
    if (IS_SEQUENCE(_29inactive_references_61065)){
            _len_62118 = SEQ_PTR(_29inactive_references_61065)->length;
    }
    else {
        _len_62118 = 1;
    }

    /** 	if len then*/
    if (_len_62118 == 0)
    {
        goto L1; // [16] 39
    }
    else{
    }

    /** 		ref = inactive_references[len]*/
    _2 = (int)SEQ_PTR(_29inactive_references_61065);
    _ref_62117 = (int)*(((s1_ptr)_2)->base + _len_62118);
    if (!IS_ATOM_INT(_ref_62117))
    _ref_62117 = (long)DBL_PTR(_ref_62117)->dbl;

    /** 		inactive_references = remove( inactive_references, len, len )*/
    {
        s1_ptr assign_space = SEQ_PTR(_29inactive_references_61065);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_len_62118)) ? _len_62118 : (long)(DBL_PTR(_len_62118)->dbl);
        int stop = (IS_ATOM_INT(_len_62118)) ? _len_62118 : (long)(DBL_PTR(_len_62118)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_29inactive_references_61065), start, &_29inactive_references_61065 );
            }
            else Tail(SEQ_PTR(_29inactive_references_61065), stop+1, &_29inactive_references_61065);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_29inactive_references_61065), start, &_29inactive_references_61065);
        }
        else {
            assign_slice_seq = &assign_space;
            _29inactive_references_61065 = Remove_elements(start, stop, (SEQ_PTR(_29inactive_references_61065)->ref == 1));
        }
    }
    goto L2; // [36] 55
L1: 

    /** 		forward_references &= 0*/
    Append(&_29forward_references_61061, _29forward_references_61061, 0);

    /** 		ref = length( forward_references )*/
    if (IS_SEQUENCE(_29forward_references_61061)){
            _ref_62117 = SEQ_PTR(_29forward_references_61061)->length;
    }
    else {
        _ref_62117 = 1;
    }
L2: 

    /** 	forward_references[ref] = repeat( 0, FR_SIZE )*/
    _30996 = Repeat(0, 12);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _ref_62117);
    _1 = *(int *)_2;
    *(int *)_2 = _30996;
    if( _1 != _30996 ){
        DeRef(_1);
    }
    _30996 = NOVALUE;

    /** 	forward_references[ref][FR_TYPE]      = fwd_op*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _fwd_op_62113;
    DeRef(_1);
    _30997 = NOVALUE;

    /** 	if sym < 0 then*/
    if (_sym_62115 >= 0)
    goto L3; // [84] 143

    /** 		forward_references[ref][FR_NAME] = forward_references[-sym][FR_NAME]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62115 == 0xC0000000)
    _31002 = (int)NewDouble((double)-0xC0000000);
    else
    _31002 = - _sym_62115;
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!IS_ATOM_INT(_31002)){
        _31003 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31002)->dbl));
    }
    else{
        _31003 = (int)*(((s1_ptr)_2)->base + _31002);
    }
    _2 = (int)SEQ_PTR(_31003);
    _31004 = (int)*(((s1_ptr)_2)->base + 2);
    _31003 = NOVALUE;
    Ref(_31004);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31004;
    if( _1 != _31004 ){
        DeRef(_1);
    }
    _31004 = NOVALUE;
    _31000 = NOVALUE;

    /** 		forward_references[ref][FR_HASHVAL] = forward_references[-sym][FR_HASHVAL]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    if ((unsigned long)_sym_62115 == 0xC0000000)
    _31007 = (int)NewDouble((double)-0xC0000000);
    else
    _31007 = - _sym_62115;
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!IS_ATOM_INT(_31007)){
        _31008 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31007)->dbl));
    }
    else{
        _31008 = (int)*(((s1_ptr)_2)->base + _31007);
    }
    _2 = (int)SEQ_PTR(_31008);
    _31009 = (int)*(((s1_ptr)_2)->base + 11);
    _31008 = NOVALUE;
    Ref(_31009);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31009;
    if( _1 != _31009 ){
        DeRef(_1);
    }
    _31009 = NOVALUE;
    _31005 = NOVALUE;
    goto L4; // [140] 242
L3: 

    /** 		forward_references[ref][FR_NAME] = SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31012 = (int)*(((s1_ptr)_2)->base + _sym_62115);
    _2 = (int)SEQ_PTR(_31012);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _31013 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _31013 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _31012 = NOVALUE;
    Ref(_31013);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _31013;
    if( _1 != _31013 ){
        DeRef(_1);
    }
    _31013 = NOVALUE;
    _31010 = NOVALUE;

    /** 		integer hashval = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31014 = (int)*(((s1_ptr)_2)->base + _sym_62115);
    _2 = (int)SEQ_PTR(_31014);
    _hashval_62148 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hashval_62148)){
        _hashval_62148 = (long)DBL_PTR(_hashval_62148)->dbl;
    }
    _31014 = NOVALUE;

    /** 		if 0 = hashval then*/
    if (0 != _hashval_62148)
    goto L5; // [186] 220

    /** 			forward_references[ref][FR_HASHVAL] = hashfn( forward_references[ref][FR_NAME] )*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    _31019 = (int)*(((s1_ptr)_2)->base + _ref_62117);
    _2 = (int)SEQ_PTR(_31019);
    _31020 = (int)*(((s1_ptr)_2)->base + 2);
    _31019 = NOVALUE;
    Ref(_31020);
    _31021 = _52hashfn(_31020);
    _31020 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _31021;
    if( _1 != _31021 ){
        DeRef(_1);
    }
    _31021 = NOVALUE;
    _31017 = NOVALUE;
    goto L6; // [217] 239
L5: 

    /** 			forward_references[ref][FR_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_62148;
    DeRef(_1);
    _31022 = NOVALUE;

    /** 			remove_symbol( sym )*/
    _52remove_symbol(_sym_62115);
L6: 
L4: 

    /** 	forward_references[ref][FR_FILE]      = current_file_no*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);
    _31024 = NOVALUE;

    /** 	forward_references[ref][FR_SUBPROG]   = CurrentSub*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12CurrentSub_11690;
    DeRef(_1);
    _31026 = NOVALUE;

    /** 	if fwd_op != TYPE then*/
    if (_fwd_op_62113 == 504)
    goto L7; // [276] 303

    /** 		forward_references[ref][FR_PC]        = length( Code ) + 1*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_11771)){
            _31031 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _31031 = 1;
    }
    _31032 = _31031 + 1;
    _31031 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31032;
    if( _1 != _31032 ){
        DeRef(_1);
    }
    _31032 = NOVALUE;
    _31029 = NOVALUE;
L7: 

    /** 	forward_references[ref][FR_LINE]      = fwd_line_number*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _12fwd_line_number_11684;
    DeRef(_1);
    _31033 = NOVALUE;

    /** 	forward_references[ref][FR_THISLINE]  = ForwardLine*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    Ref(_43ForwardLine_48159);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _43ForwardLine_48159;
    DeRef(_1);
    _31035 = NOVALUE;

    /** 	forward_references[ref][FR_BP]        = forward_bp*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _43forward_bp_48163;
    DeRef(_1);
    _31037 = NOVALUE;

    /** 	forward_references[ref][FR_QUALIFIED] = get_qualified_fwd()*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _31041 = _60get_qualified_fwd();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31041;
    if( _1 != _31041 ){
        DeRef(_1);
    }
    _31041 = NOVALUE;
    _31039 = NOVALUE;

    /** 	forward_references[ref][FR_OP]        = op*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _op_62116;
    DeRef(_1);
    _31042 = NOVALUE;

    /** 	if op = GOTO then*/
    if (_op_62116 != 188)
    goto L8; // [381] 403

    /** 		forward_references[ref][FR_DATA] = { sym }*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _sym_62115;
    _31047 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31047;
    if( _1 != _31047 ){
        DeRef(_1);
    }
    _31047 = NOVALUE;
    _31045 = NOVALUE;
L8: 

    /** 	if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_11690 != _12TopLevelSub_11689)
    goto L9; // [409] 471

    /** 		if length( toplevel_references ) < current_file_no then*/
    if (IS_SEQUENCE(_29toplevel_references_61064)){
            _31049 = SEQ_PTR(_29toplevel_references_61064)->length;
    }
    else {
        _31049 = 1;
    }
    if (_31049 >= _12current_file_no_11682)
    goto LA; // [422] 450

    /** 			toplevel_references &= repeat( {}, current_file_no - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_29toplevel_references_61064)){
            _31051 = SEQ_PTR(_29toplevel_references_61064)->length;
    }
    else {
        _31051 = 1;
    }
    _31052 = _12current_file_no_11682 - _31051;
    _31051 = NOVALUE;
    _31053 = Repeat(_21829, _31052);
    _31052 = NOVALUE;
    Concat((object_ptr)&_29toplevel_references_61064, _29toplevel_references_61064, _31053);
    DeRefDS(_31053);
    _31053 = NOVALUE;
LA: 

    /** 		toplevel_references[current_file_no] &= ref*/
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    _31055 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    if (IS_SEQUENCE(_31055) && IS_ATOM(_ref_62117)) {
        Append(&_31056, _31055, _ref_62117);
    }
    else if (IS_ATOM(_31055) && IS_SEQUENCE(_ref_62117)) {
    }
    else {
        Concat((object_ptr)&_31056, _31055, _ref_62117);
        _31055 = NOVALUE;
    }
    _31055 = NOVALUE;
    _2 = (int)SEQ_PTR(_29toplevel_references_61064);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29toplevel_references_61064 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = *(int *)_2;
    *(int *)_2 = _31056;
    if( _1 != _31056 ){
        DeRef(_1);
    }
    _31056 = NOVALUE;
    goto LB; // [468] 595
L9: 

    /** 		add_active_reference( ref )*/
    _29add_active_reference(_ref_62117, _12current_file_no_11682);

    /** 		if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_11788 != 1)
    goto LC; // [485] 592

    /** 			symtab_pointer default_sym = CurrentSub*/
    _default_sym_62223 = _12CurrentSub_11690;

    /** 			symtab_pointer param = 0*/
    _param_62226 = 0;

    /** 			while default_sym with entry do*/
    goto LD; // [507] 536
LE: 
    if (_default_sym_62223 == 0)
    {
        goto LF; // [510] 549
    }
    else{
    }

    /** 				if sym_scope( default_sym ) = SC_PRIVATE then*/
    _31058 = _52sym_scope(_default_sym_62223);
    if (binary_op_a(NOTEQ, _31058, 3)){
        DeRef(_31058);
        _31058 = NOVALUE;
        goto L10; // [521] 533
    }
    DeRef(_31058);
    _31058 = NOVALUE;

    /** 					param = default_sym*/
    _param_62226 = _default_sym_62223;
L10: 

    /** 			entry*/
LD: 

    /** 				default_sym = sym_next( default_sym )*/
    _default_sym_62223 = _52sym_next(_default_sym_62223);
    if (!IS_ATOM_INT(_default_sym_62223)) {
        _1 = (long)(DBL_PTR(_default_sym_62223)->dbl);
        DeRefDS(_default_sym_62223);
        _default_sym_62223 = _1;
    }

    /** 			end while*/
    goto LE; // [546] 510
LF: 

    /** 			set_data( ref, {{ PAM_RECORD, param, length( Recorded_sym ) }} )*/
    if (IS_SEQUENCE(_12Recorded_sym_11791)){
            _31061 = SEQ_PTR(_12Recorded_sym_11791)->length;
    }
    else {
        _31061 = 1;
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = _param_62226;
    *((int *)(_2+12)) = _31061;
    _31062 = MAKE_SEQ(_1);
    _31061 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _31062;
    _31063 = MAKE_SEQ(_1);
    _31062 = NOVALUE;
    DeRef(_data_inlined_set_data_at_575_62241);
    _data_inlined_set_data_at_575_62241 = _31063;
    _31063 = NOVALUE;

    /** 	forward_references[ref][FR_DATA] = data*/
    _2 = (int)SEQ_PTR(_29forward_references_61061);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29forward_references_61061 = MAKE_SEQ(_2);
    }
    _3 = (int)(_ref_62117 + ((s1_ptr)_2)->base);
    RefDS(_data_inlined_set_data_at_575_62241);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _data_inlined_set_data_at_575_62241;
    DeRef(_1);

    /** end procedure*/
    goto L11; // [586] 589
L11: 
    DeRef(_data_inlined_set_data_at_575_62241);
    _data_inlined_set_data_at_575_62241 = NOVALUE;
LC: 
LB: 

    /** 	fwdref_count += 1*/
    _29fwdref_count_61081 = _29fwdref_count_61081 + 1;

    /** 	return ref*/
    DeRef(_31002);
    _31002 = NOVALUE;
    DeRef(_31007);
    _31007 = NOVALUE;
    return _ref_62117;
    ;
}


void _29add_active_reference(int _ref_62247, int _file_no_62248)
{
    int _sp_62262 = NOVALUE;
    int _31087 = NOVALUE;
    int _31086 = NOVALUE;
    int _31084 = NOVALUE;
    int _31083 = NOVALUE;
    int _31082 = NOVALUE;
    int _31080 = NOVALUE;
    int _31079 = NOVALUE;
    int _31078 = NOVALUE;
    int _31075 = NOVALUE;
    int _31073 = NOVALUE;
    int _31072 = NOVALUE;
    int _31071 = NOVALUE;
    int _31069 = NOVALUE;
    int _31068 = NOVALUE;
    int _31067 = NOVALUE;
    int _31065 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if length( active_references ) < file_no then*/
    if (IS_SEQUENCE(_29active_references_61063)){
            _31065 = SEQ_PTR(_29active_references_61063)->length;
    }
    else {
        _31065 = 1;
    }
    if (_31065 >= _file_no_62248)
    goto L1; // [12] 59

    /** 		active_references &= repeat( {}, file_no - length( active_references ) )*/
    if (IS_SEQUENCE(_29active_references_61063)){
            _31067 = SEQ_PTR(_29active_references_61063)->length;
    }
    else {
        _31067 = 1;
    }
    _31068 = _file_no_62248 - _31067;
    _31067 = NOVALUE;
    _31069 = Repeat(_21829, _31068);
    _31068 = NOVALUE;
    Concat((object_ptr)&_29active_references_61063, _29active_references_61063, _31069);
    DeRefDS(_31069);
    _31069 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, file_no - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_29active_subprogs_61062)){
            _31071 = SEQ_PTR(_29active_subprogs_61062)->length;
    }
    else {
        _31071 = 1;
    }
    _31072 = _file_no_62248 - _31071;
    _31071 = NOVALUE;
    _31073 = Repeat(_21829, _31072);
    _31072 = NOVALUE;
    Concat((object_ptr)&_29active_subprogs_61062, _29active_subprogs_61062, _31073);
    DeRefDS(_31073);
    _31073 = NOVALUE;
L1: 

    /** 	integer sp = find( CurrentSub, active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _31075 = (int)*(((s1_ptr)_2)->base + _file_no_62248);
    _sp_62262 = find_from(_12CurrentSub_11690, _31075, 1);
    _31075 = NOVALUE;

    /** 	if not sp then*/
    if (_sp_62262 != 0)
    goto L2; // [76] 127

    /** 		active_subprogs[file_no] &= CurrentSub*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _31078 = (int)*(((s1_ptr)_2)->base + _file_no_62248);
    if (IS_SEQUENCE(_31078) && IS_ATOM(_12CurrentSub_11690)) {
        Append(&_31079, _31078, _12CurrentSub_11690);
    }
    else if (IS_ATOM(_31078) && IS_SEQUENCE(_12CurrentSub_11690)) {
    }
    else {
        Concat((object_ptr)&_31079, _31078, _12CurrentSub_11690);
        _31078 = NOVALUE;
    }
    _31078 = NOVALUE;
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_subprogs_61062 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62248);
    _1 = *(int *)_2;
    *(int *)_2 = _31079;
    if( _1 != _31079 ){
        DeRef(_1);
    }
    _31079 = NOVALUE;

    /** 		sp = length( active_subprogs[file_no] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _31080 = (int)*(((s1_ptr)_2)->base + _file_no_62248);
    if (IS_SEQUENCE(_31080)){
            _sp_62262 = SEQ_PTR(_31080)->length;
    }
    else {
        _sp_62262 = 1;
    }
    _31080 = NOVALUE;

    /** 		active_references[file_no] = append( active_references[file_no], {} )*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _31082 = (int)*(((s1_ptr)_2)->base + _file_no_62248);
    RefDS(_21829);
    Append(&_31083, _31082, _21829);
    _31082 = NOVALUE;
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _file_no_62248);
    _1 = *(int *)_2;
    *(int *)_2 = _31083;
    if( _1 != _31083 ){
        DeRef(_1);
    }
    _31083 = NOVALUE;
L2: 

    /** 	active_references[file_no][sp] &= ref*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _29active_references_61063 = MAKE_SEQ(_2);
    }
    _3 = (int)(_file_no_62248 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31086 = (int)*(((s1_ptr)_2)->base + _sp_62262);
    _31084 = NOVALUE;
    if (IS_SEQUENCE(_31086) && IS_ATOM(_ref_62247)) {
        Append(&_31087, _31086, _ref_62247);
    }
    else if (IS_ATOM(_31086) && IS_SEQUENCE(_ref_62247)) {
    }
    else {
        Concat((object_ptr)&_31087, _31086, _ref_62247);
        _31086 = NOVALUE;
    }
    _31086 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _sp_62262);
    _1 = *(int *)_2;
    *(int *)_2 = _31087;
    if( _1 != _31087 ){
        DeRef(_1);
    }
    _31087 = NOVALUE;
    _31084 = NOVALUE;

    /** end procedure*/
    _31080 = NOVALUE;
    return;
    ;
}


int _29resolve_file(int _refs_62299, int _report_errors_62300, int _unincluded_ok_62301)
{
    int _errors_62302 = NOVALUE;
    int _ref_62306 = NOVALUE;
    int _fr_62308 = NOVALUE;
    int _tok_62321 = NOVALUE;
    int _code_sub_62329 = NOVALUE;
    int _fr_type_62331 = NOVALUE;
    int _sym_tok_62333 = NOVALUE;
    int _31141 = NOVALUE;
    int _31140 = NOVALUE;
    int _31139 = NOVALUE;
    int _31138 = NOVALUE;
    int _31137 = NOVALUE;
    int _31136 = NOVALUE;
    int _31131 = NOVALUE;
    int _31130 = NOVALUE;
    int _31129 = NOVALUE;
    int _31127 = NOVALUE;
    int _31126 = NOVALUE;
    int _31123 = NOVALUE;
    int _31122 = NOVALUE;
    int _31121 = NOVALUE;
    int _31117 = NOVALUE;
    int _31116 = NOVALUE;
    int _31108 = NOVALUE;
    int _31106 = NOVALUE;
    int _31105 = NOVALUE;
    int _31104 = NOVALUE;
    int _31103 = NOVALUE;
    int _31102 = NOVALUE;
    int _31101 = NOVALUE;
    int _31098 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence errors = {}*/
    RefDS(_21829);
    DeRefi(_errors_62302);
    _errors_62302 = _21829;

    /** 	for ar = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62299)){
            _31098 = SEQ_PTR(_refs_62299)->length;
    }
    else {
        _31098 = 1;
    }
    {
        int _ar_62304;
        _ar_62304 = _31098;
L1: 
        if (_ar_62304 < 1){
            goto L2; // [19] 481
        }

        /** 		integer ref = refs[ar]*/
        _2 = (int)SEQ_PTR(_refs_62299);
        _ref_62306 = (int)*(((s1_ptr)_2)->base + _ar_62304);
        if (!IS_ATOM_INT(_ref_62306))
        _ref_62306 = (long)DBL_PTR(_ref_62306)->dbl;

        /** 		sequence fr = forward_references[ref]*/
        DeRef(_fr_62308);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        _fr_62308 = (int)*(((s1_ptr)_2)->base + _ref_62306);
        Ref(_fr_62308);

        /** 		if include_matrix[fr[FR_FILE]][current_file_no] = NOT_INCLUDED and not unincluded_ok then*/
        _2 = (int)SEQ_PTR(_fr_62308);
        _31101 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        if (!IS_ATOM_INT(_31101)){
            _31102 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31101)->dbl));
        }
        else{
            _31102 = (int)*(((s1_ptr)_2)->base + _31101);
        }
        _2 = (int)SEQ_PTR(_31102);
        _31103 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
        _31102 = NOVALUE;
        if (IS_ATOM_INT(_31103)) {
            _31104 = (_31103 == 0);
        }
        else {
            _31104 = binary_op(EQUALS, _31103, 0);
        }
        _31103 = NOVALUE;
        if (IS_ATOM_INT(_31104)) {
            if (_31104 == 0) {
                goto L3; // [66] 84
            }
        }
        else {
            if (DBL_PTR(_31104)->dbl == 0.0) {
                goto L3; // [66] 84
            }
        }
        _31106 = (_unincluded_ok_62301 == 0);
        if (_31106 == 0)
        {
            DeRef(_31106);
            _31106 = NOVALUE;
            goto L3; // [74] 84
        }
        else{
            DeRef(_31106);
            _31106 = NOVALUE;
        }

        /** 			continue*/
        DeRef(_fr_62308);
        _fr_62308 = NOVALUE;
        DeRef(_tok_62321);
        _tok_62321 = NOVALUE;
        goto L4; // [81] 476
L3: 

        /** 		token tok = find_reference( fr )*/
        RefDS(_fr_62308);
        _0 = _tok_62321;
        _tok_62321 = _29find_reference(_fr_62308);
        DeRef(_0);

        /** 		if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62321);
        _31108 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31108, 509)){
            _31108 = NOVALUE;
            goto L5; // [100] 117
        }
        _31108 = NOVALUE;

        /** 			errors &= ref*/
        Append(&_errors_62302, _errors_62302, _ref_62306);

        /** 			continue*/
        DeRefDS(_fr_62308);
        _fr_62308 = NOVALUE;
        DeRef(_tok_62321);
        _tok_62321 = NOVALUE;
        goto L4; // [114] 476
L5: 

        /** 		integer code_sub = fr[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_fr_62308);
        _code_sub_62329 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_code_sub_62329))
        _code_sub_62329 = (long)DBL_PTR(_code_sub_62329)->dbl;

        /** 		integer fr_type  = fr[FR_TYPE]*/
        _2 = (int)SEQ_PTR(_fr_62308);
        _fr_type_62331 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_fr_type_62331))
        _fr_type_62331 = (long)DBL_PTR(_fr_type_62331)->dbl;

        /** 		integer sym_tok*/

        /** 		switch fr_type label "fr_type" do*/
        _0 = _fr_type_62331;
        switch ( _0 ){ 

            /** 			case PROC, FUNC then*/
            case 27:
            case 501:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62321);
            _31116 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!IS_ATOM_INT(_31116)){
                _31117 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31116)->dbl));
            }
            else{
                _31117 = (int)*(((s1_ptr)_2)->base + _31116);
            }
            _2 = (int)SEQ_PTR(_31117);
            if (!IS_ATOM_INT(_12S_TOKEN_11359)){
                _sym_tok_62333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
            }
            else{
                _sym_tok_62333 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
            }
            if (!IS_ATOM_INT(_sym_tok_62333)){
                _sym_tok_62333 = (long)DBL_PTR(_sym_tok_62333)->dbl;
            }
            _31117 = NOVALUE;

            /** 				if sym_tok = TYPE then*/
            if (_sym_tok_62333 != 504)
            goto L6; // [170] 184

            /** 					sym_tok = FUNC*/
            _sym_tok_62333 = 501;
L6: 

            /** 				if sym_tok != fr_type then*/
            if (_sym_tok_62333 == _fr_type_62331)
            goto L7; // [186] 220

            /** 					if sym_tok != FUNC and fr_type != PROC then*/
            _31121 = (_sym_tok_62333 != 501);
            if (_31121 == 0) {
                goto L8; // [198] 219
            }
            _31123 = (_fr_type_62331 != 27);
            if (_31123 == 0)
            {
                DeRef(_31123);
                _31123 = NOVALUE;
                goto L8; // [209] 219
            }
            else{
                DeRef(_31123);
                _31123 = NOVALUE;
            }

            /** 						forward_error( tok, ref )*/
            Ref(_tok_62321);
            _29forward_error(_tok_62321, _ref_62306);
L8: 
L7: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62333;
            switch ( _0 ){ 

                /** 					case PROC, FUNC then*/
                case 27:
                case 501:

                /** 						patch_forward_call( tok, ref )*/
                Ref(_tok_62321);
                _29patch_forward_call(_tok_62321, _ref_62306);

                /** 						break "fr_type"*/
                goto L9; // [241] 446
                goto L9; // [243] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62321);
                _29forward_error(_tok_62321, _ref_62306);
            ;}            goto L9; // [256] 446

            /** 			case VARIABLE then*/
            case -100:

            /** 				sym_tok = SymTab[tok[T_SYM]][S_TOKEN]*/
            _2 = (int)SEQ_PTR(_tok_62321);
            _31126 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!IS_ATOM_INT(_31126)){
                _31127 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31126)->dbl));
            }
            else{
                _31127 = (int)*(((s1_ptr)_2)->base + _31126);
            }
            _2 = (int)SEQ_PTR(_31127);
            if (!IS_ATOM_INT(_12S_TOKEN_11359)){
                _sym_tok_62333 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
            }
            else{
                _sym_tok_62333 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
            }
            if (!IS_ATOM_INT(_sym_tok_62333)){
                _sym_tok_62333 = (long)DBL_PTR(_sym_tok_62333)->dbl;
            }
            _31127 = NOVALUE;

            /** 				if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
            _2 = (int)SEQ_PTR(_tok_62321);
            _31129 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!IS_ATOM_INT(_31129)){
                _31130 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31129)->dbl));
            }
            else{
                _31130 = (int)*(((s1_ptr)_2)->base + _31129);
            }
            _2 = (int)SEQ_PTR(_31130);
            _31131 = (int)*(((s1_ptr)_2)->base + 4);
            _31130 = NOVALUE;
            if (binary_op_a(NOTEQ, _31131, 9)){
                _31131 = NOVALUE;
                goto LA; // [306] 323
            }
            _31131 = NOVALUE;

            /** 					errors &= ref*/
            Append(&_errors_62302, _errors_62302, _ref_62306);

            /** 					continue*/
            DeRef(_fr_62308);
            _fr_62308 = NOVALUE;
            DeRef(_tok_62321);
            _tok_62321 = NOVALUE;
            goto L4; // [320] 476
LA: 

            /** 				switch sym_tok do*/
            _0 = _sym_tok_62333;
            switch ( _0 ){ 

                /** 					case CONSTANT, ENUM, VARIABLE then*/
                case 417:
                case 427:
                case -100:

                /** 						patch_forward_variable( tok, ref )*/
                Ref(_tok_62321);
                _29patch_forward_variable(_tok_62321, _ref_62306);

                /** 						break "fr_type"*/
                goto L9; // [346] 446
                goto L9; // [348] 446

                /** 					case else*/
                default:

                /** 						forward_error( tok, ref )*/
                Ref(_tok_62321);
                _29forward_error(_tok_62321, _ref_62306);
            ;}            goto L9; // [361] 446

            /** 			case TYPE_CHECK then*/
            case 65:

            /** 				patch_forward_type_check( tok, ref )*/
            Ref(_tok_62321);
            _29patch_forward_type_check(_tok_62321, _ref_62306);
            goto L9; // [373] 446

            /** 			case GLOBAL_INIT_CHECK then*/
            case 109:

            /** 				patch_forward_init_check( tok, ref )*/
            Ref(_tok_62321);
            _29patch_forward_init_check(_tok_62321, _ref_62306);
            goto L9; // [385] 446

            /** 			case CASE then*/
            case 186:

            /** 				patch_forward_case( tok, ref )*/
            Ref(_tok_62321);
            _29patch_forward_case(_tok_62321, _ref_62306);
            goto L9; // [397] 446

            /** 			case TYPE then*/
            case 504:

            /** 				patch_forward_type( tok, ref )*/
            Ref(_tok_62321);
            _29patch_forward_type(_tok_62321, _ref_62306);
            goto L9; // [409] 446

            /** 			case GOTO then*/
            case 188:

            /** 				patch_forward_goto( tok, ref )*/
            Ref(_tok_62321);
            _29patch_forward_goto(_tok_62321, _ref_62306);
            goto L9; // [421] 446

            /** 			case else*/
            default:

            /** 				InternalErr( 263, {fr[FR_TYPE], fr[FR_NAME]})*/
            _2 = (int)SEQ_PTR(_fr_62308);
            _31136 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_fr_62308);
            _31137 = (int)*(((s1_ptr)_2)->base + 2);
            Ref(_31137);
            Ref(_31136);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _31136;
            ((int *)_2)[2] = _31137;
            _31138 = MAKE_SEQ(_1);
            _31137 = NOVALUE;
            _31136 = NOVALUE;
            _43InternalErr(263, _31138);
            _31138 = NOVALUE;
        ;}L9: 

        /** 		if report_errors and sequence( forward_references[ref] ) then*/
        if (_report_errors_62300 == 0) {
            goto LB; // [448] 472
        }
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        _31140 = (int)*(((s1_ptr)_2)->base + _ref_62306);
        _31141 = IS_SEQUENCE(_31140);
        _31140 = NOVALUE;
        if (_31141 == 0)
        {
            _31141 = NOVALUE;
            goto LB; // [462] 472
        }
        else{
            _31141 = NOVALUE;
        }

        /** 			errors &= ref*/
        Append(&_errors_62302, _errors_62302, _ref_62306);
LB: 
        DeRef(_fr_62308);
        _fr_62308 = NOVALUE;
        DeRef(_tok_62321);
        _tok_62321 = NOVALUE;

        /** 	end for*/
L4: 
        _ar_62304 = _ar_62304 + -1;
        goto L1; // [476] 26
L2: 
        ;
    }

    /** 	return errors*/
    DeRefDS(_refs_62299);
    _31101 = NOVALUE;
    _31116 = NOVALUE;
    DeRef(_31104);
    _31104 = NOVALUE;
    DeRef(_31121);
    _31121 = NOVALUE;
    _31126 = NOVALUE;
    _31129 = NOVALUE;
    return _errors_62302;
    ;
}


int _29file_name_based_symindex_compare(int _si1_62411, int _si2_62412)
{
    int _fn1_62433 = NOVALUE;
    int _fn2_62438 = NOVALUE;
    int _31170 = NOVALUE;
    int _31169 = NOVALUE;
    int _31168 = NOVALUE;
    int _31167 = NOVALUE;
    int _31166 = NOVALUE;
    int _31165 = NOVALUE;
    int _31164 = NOVALUE;
    int _31163 = NOVALUE;
    int _31162 = NOVALUE;
    int _31161 = NOVALUE;
    int _31160 = NOVALUE;
    int _31159 = NOVALUE;
    int _31157 = NOVALUE;
    int _31155 = NOVALUE;
    int _31154 = NOVALUE;
    int _31153 = NOVALUE;
    int _31152 = NOVALUE;
    int _31151 = NOVALUE;
    int _31150 = NOVALUE;
    int _31149 = NOVALUE;
    int _31148 = NOVALUE;
    int _31147 = NOVALUE;
    int _31146 = NOVALUE;
    int _31144 = NOVALUE;
    int _31143 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_si1_62411)) {
        _1 = (long)(DBL_PTR(_si1_62411)->dbl);
        DeRefDS(_si1_62411);
        _si1_62411 = _1;
    }
    if (!IS_ATOM_INT(_si2_62412)) {
        _1 = (long)(DBL_PTR(_si2_62412)->dbl);
        DeRefDS(_si2_62412);
        _si2_62412 = _1;
    }

    /** 	if not symtab_index(si1) or not symtab_index(si2) then*/
    _31143 = _12symtab_index(_si1_62411);
    if (IS_ATOM_INT(_31143)) {
        _31144 = (_31143 == 0);
    }
    else {
        _31144 = unary_op(NOT, _31143);
    }
    DeRef(_31143);
    _31143 = NOVALUE;
    if (IS_ATOM_INT(_31144)) {
        if (_31144 != 0) {
            goto L1; // [14] 30
        }
    }
    else {
        if (DBL_PTR(_31144)->dbl != 0.0) {
            goto L1; // [14] 30
        }
    }
    _31146 = _12symtab_index(_si2_62412);
    if (IS_ATOM_INT(_31146)) {
        _31147 = (_31146 == 0);
    }
    else {
        _31147 = unary_op(NOT, _31146);
    }
    DeRef(_31146);
    _31146 = NOVALUE;
    if (_31147 == 0) {
        DeRef(_31147);
        _31147 = NOVALUE;
        goto L2; // [26] 37
    }
    else {
        if (!IS_ATOM_INT(_31147) && DBL_PTR(_31147)->dbl == 0.0){
            DeRef(_31147);
            _31147 = NOVALUE;
            goto L2; // [26] 37
        }
        DeRef(_31147);
        _31147 = NOVALUE;
    }
    DeRef(_31147);
    _31147 = NOVALUE;
L1: 

    /** 		return 1 -- put non symbols last*/
    DeRef(_31144);
    _31144 = NOVALUE;
    return 1;
L2: 

    /** 	if S_FILE_NO <= length(SymTab[si1]) and S_FILE_NO <= length(SymTab[si2]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31148 = (int)*(((s1_ptr)_2)->base + _si1_62411);
    if (IS_SEQUENCE(_31148)){
            _31149 = SEQ_PTR(_31148)->length;
    }
    else {
        _31149 = 1;
    }
    _31148 = NOVALUE;
    if (IS_ATOM_INT(_12S_FILE_NO_11350)) {
        _31150 = (_12S_FILE_NO_11350 <= _31149);
    }
    else {
        _31150 = binary_op(LESSEQ, _12S_FILE_NO_11350, _31149);
    }
    _31149 = NOVALUE;
    if (IS_ATOM_INT(_31150)) {
        if (_31150 == 0) {
            goto L3; // [54] 186
        }
    }
    else {
        if (DBL_PTR(_31150)->dbl == 0.0) {
            goto L3; // [54] 186
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31152 = (int)*(((s1_ptr)_2)->base + _si2_62412);
    if (IS_SEQUENCE(_31152)){
            _31153 = SEQ_PTR(_31152)->length;
    }
    else {
        _31153 = 1;
    }
    _31152 = NOVALUE;
    if (IS_ATOM_INT(_12S_FILE_NO_11350)) {
        _31154 = (_12S_FILE_NO_11350 <= _31153);
    }
    else {
        _31154 = binary_op(LESSEQ, _12S_FILE_NO_11350, _31153);
    }
    _31153 = NOVALUE;
    if (_31154 == 0) {
        DeRef(_31154);
        _31154 = NOVALUE;
        goto L3; // [74] 186
    }
    else {
        if (!IS_ATOM_INT(_31154) && DBL_PTR(_31154)->dbl == 0.0){
            DeRef(_31154);
            _31154 = NOVALUE;
            goto L3; // [74] 186
        }
        DeRef(_31154);
        _31154 = NOVALUE;
    }
    DeRef(_31154);
    _31154 = NOVALUE;

    /** 		integer fn1 = SymTab[si1][S_FILE_NO], fn2 = SymTab[si2][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31155 = (int)*(((s1_ptr)_2)->base + _si1_62411);
    _2 = (int)SEQ_PTR(_31155);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _fn1_62433 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _fn1_62433 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_fn1_62433)){
        _fn1_62433 = (long)DBL_PTR(_fn1_62433)->dbl;
    }
    _31155 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31157 = (int)*(((s1_ptr)_2)->base + _si2_62412);
    _2 = (int)SEQ_PTR(_31157);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _fn2_62438 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _fn2_62438 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_fn2_62438)){
        _fn2_62438 = (long)DBL_PTR(_fn2_62438)->dbl;
    }
    _31157 = NOVALUE;

    /** 		if find(1,{fn1,fn2} > length(known_files) or {fn1,fn2} <= 0) then*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62433;
    ((int *)_2)[2] = _fn2_62438;
    _31159 = MAKE_SEQ(_1);
    if (IS_SEQUENCE(_13known_files_10637)){
            _31160 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31160 = 1;
    }
    _31161 = binary_op(GREATER, _31159, _31160);
    DeRefDS(_31159);
    _31159 = NOVALUE;
    _31160 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _fn1_62433;
    ((int *)_2)[2] = _fn2_62438;
    _31162 = MAKE_SEQ(_1);
    _31163 = binary_op(LESSEQ, _31162, 0);
    DeRefDS(_31162);
    _31162 = NOVALUE;
    _31164 = binary_op(OR, _31161, _31163);
    DeRefDS(_31161);
    _31161 = NOVALUE;
    DeRefDS(_31163);
    _31163 = NOVALUE;
    _31165 = find_from(1, _31164, 1);
    DeRefDS(_31164);
    _31164 = NOVALUE;
    if (_31165 == 0)
    {
        _31165 = NOVALUE;
        goto L4; // [139] 149
    }
    else{
        _31165 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_31144);
    _31144 = NOVALUE;
    _31148 = NOVALUE;
    DeRef(_31150);
    _31150 = NOVALUE;
    _31152 = NOVALUE;
    return 1;
L4: 

    /** 		return compare(abbreviate_path(known_files[fn1]),*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _31166 = (int)*(((s1_ptr)_2)->base + _fn1_62433);
    Ref(_31166);
    RefDS(_21829);
    _31167 = _14abbreviate_path(_31166, _21829);
    _31166 = NOVALUE;
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _31168 = (int)*(((s1_ptr)_2)->base + _fn2_62438);
    Ref(_31168);
    RefDS(_21829);
    _31169 = _14abbreviate_path(_31168, _21829);
    _31168 = NOVALUE;
    if (IS_ATOM_INT(_31167) && IS_ATOM_INT(_31169)){
        _31170 = (_31167 < _31169) ? -1 : (_31167 > _31169);
    }
    else{
        _31170 = compare(_31167, _31169);
    }
    DeRef(_31167);
    _31167 = NOVALUE;
    DeRef(_31169);
    _31169 = NOVALUE;
    DeRef(_31144);
    _31144 = NOVALUE;
    _31148 = NOVALUE;
    DeRef(_31150);
    _31150 = NOVALUE;
    _31152 = NOVALUE;
    return _31170;
    goto L5; // [183] 193
L3: 

    /** 		return 1 -- put non-names last*/
    DeRef(_31144);
    _31144 = NOVALUE;
    _31148 = NOVALUE;
    DeRef(_31150);
    _31150 = NOVALUE;
    _31152 = NOVALUE;
    return 1;
L5: 
    ;
}


void _29Resolve_forward_references(int _report_errors_62464)
{
    int _errors_62465 = NOVALUE;
    int _unincluded_ok_62466 = NOVALUE;
    int _msg_62527 = NOVALUE;
    int _errloc_62528 = NOVALUE;
    int _ref_62533 = NOVALUE;
    int _tok_62549 = NOVALUE;
    int _THIS_SCOPE_62551 = NOVALUE;
    int _THESE_GLOBALS_62552 = NOVALUE;
    int _syms_62610 = NOVALUE;
    int _s_62631 = NOVALUE;
    int _31301 = NOVALUE;
    int _31299 = NOVALUE;
    int _31294 = NOVALUE;
    int _31291 = NOVALUE;
    int _31289 = NOVALUE;
    int _31288 = NOVALUE;
    int _31287 = NOVALUE;
    int _31286 = NOVALUE;
    int _31285 = NOVALUE;
    int _31284 = NOVALUE;
    int _31283 = NOVALUE;
    int _31281 = NOVALUE;
    int _31280 = NOVALUE;
    int _31279 = NOVALUE;
    int _31277 = NOVALUE;
    int _31275 = NOVALUE;
    int _31274 = NOVALUE;
    int _31273 = NOVALUE;
    int _31272 = NOVALUE;
    int _31271 = NOVALUE;
    int _31270 = NOVALUE;
    int _31267 = NOVALUE;
    int _31263 = NOVALUE;
    int _31262 = NOVALUE;
    int _31261 = NOVALUE;
    int _31260 = NOVALUE;
    int _31259 = NOVALUE;
    int _31258 = NOVALUE;
    int _31255 = NOVALUE;
    int _31254 = NOVALUE;
    int _31253 = NOVALUE;
    int _31252 = NOVALUE;
    int _31251 = NOVALUE;
    int _31250 = NOVALUE;
    int _31247 = NOVALUE;
    int _31246 = NOVALUE;
    int _31245 = NOVALUE;
    int _31244 = NOVALUE;
    int _31243 = NOVALUE;
    int _31242 = NOVALUE;
    int _31241 = NOVALUE;
    int _31240 = NOVALUE;
    int _31239 = NOVALUE;
    int _31238 = NOVALUE;
    int _31235 = NOVALUE;
    int _31233 = NOVALUE;
    int _31230 = NOVALUE;
    int _31228 = NOVALUE;
    int _31226 = NOVALUE;
    int _31225 = NOVALUE;
    int _31223 = NOVALUE;
    int _31222 = NOVALUE;
    int _31221 = NOVALUE;
    int _31220 = NOVALUE;
    int _31219 = NOVALUE;
    int _31217 = NOVALUE;
    int _31216 = NOVALUE;
    int _31214 = NOVALUE;
    int _31213 = NOVALUE;
    int _31211 = NOVALUE;
    int _31210 = NOVALUE;
    int _31208 = NOVALUE;
    int _31207 = NOVALUE;
    int _31206 = NOVALUE;
    int _31205 = NOVALUE;
    int _31204 = NOVALUE;
    int _31203 = NOVALUE;
    int _31202 = NOVALUE;
    int _31201 = NOVALUE;
    int _31200 = NOVALUE;
    int _31199 = NOVALUE;
    int _31198 = NOVALUE;
    int _31197 = NOVALUE;
    int _31196 = NOVALUE;
    int _31195 = NOVALUE;
    int _31194 = NOVALUE;
    int _31193 = NOVALUE;
    int _31191 = NOVALUE;
    int _31190 = NOVALUE;
    int _31189 = NOVALUE;
    int _31188 = NOVALUE;
    int _31186 = NOVALUE;
    int _31185 = NOVALUE;
    int _31183 = NOVALUE;
    int _31182 = NOVALUE;
    int _31181 = NOVALUE;
    int _31180 = NOVALUE;
    int _31178 = NOVALUE;
    int _31177 = NOVALUE;
    int _31176 = NOVALUE;
    int _31175 = NOVALUE;
    int _31173 = NOVALUE;
    int _31172 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_report_errors_62464)) {
        _1 = (long)(DBL_PTR(_report_errors_62464)->dbl);
        DeRefDS(_report_errors_62464);
        _report_errors_62464 = _1;
    }

    /** 	sequence errors = {}*/
    RefDS(_21829);
    DeRef(_errors_62465);
    _errors_62465 = _21829;

    /** 	integer unincluded_ok = get_resolve_unincluded_globals()*/
    _unincluded_ok_62466 = _52get_resolve_unincluded_globals();
    if (!IS_ATOM_INT(_unincluded_ok_62466)) {
        _1 = (long)(DBL_PTR(_unincluded_ok_62466)->dbl);
        DeRefDS(_unincluded_ok_62466);
        _unincluded_ok_62466 = _1;
    }

    /** 	if length( active_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_29active_references_61063)){
            _31172 = SEQ_PTR(_29active_references_61063)->length;
    }
    else {
        _31172 = 1;
    }
    if (IS_SEQUENCE(_13known_files_10637)){
            _31173 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31173 = 1;
    }
    if (_31172 >= _31173)
    goto L1; // [29] 86

    /** 		active_references &= repeat( {}, length( known_files ) - length( active_references ) )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _31175 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31175 = 1;
    }
    if (IS_SEQUENCE(_29active_references_61063)){
            _31176 = SEQ_PTR(_29active_references_61063)->length;
    }
    else {
        _31176 = 1;
    }
    _31177 = _31175 - _31176;
    _31175 = NOVALUE;
    _31176 = NOVALUE;
    _31178 = Repeat(_21829, _31177);
    _31177 = NOVALUE;
    Concat((object_ptr)&_29active_references_61063, _29active_references_61063, _31178);
    DeRefDS(_31178);
    _31178 = NOVALUE;

    /** 		active_subprogs   &= repeat( {}, length( known_files ) - length( active_subprogs ) )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _31180 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31180 = 1;
    }
    if (IS_SEQUENCE(_29active_subprogs_61062)){
            _31181 = SEQ_PTR(_29active_subprogs_61062)->length;
    }
    else {
        _31181 = 1;
    }
    _31182 = _31180 - _31181;
    _31180 = NOVALUE;
    _31181 = NOVALUE;
    _31183 = Repeat(_21829, _31182);
    _31182 = NOVALUE;
    Concat((object_ptr)&_29active_subprogs_61062, _29active_subprogs_61062, _31183);
    DeRefDS(_31183);
    _31183 = NOVALUE;
L1: 

    /** 	if length( toplevel_references ) < length( known_files ) then*/
    if (IS_SEQUENCE(_29toplevel_references_61064)){
            _31185 = SEQ_PTR(_29toplevel_references_61064)->length;
    }
    else {
        _31185 = 1;
    }
    if (IS_SEQUENCE(_13known_files_10637)){
            _31186 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31186 = 1;
    }
    if (_31185 >= _31186)
    goto L2; // [98] 129

    /** 		toplevel_references &= repeat( {}, length( known_files ) - length( toplevel_references ) )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _31188 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _31188 = 1;
    }
    if (IS_SEQUENCE(_29toplevel_references_61064)){
            _31189 = SEQ_PTR(_29toplevel_references_61064)->length;
    }
    else {
        _31189 = 1;
    }
    _31190 = _31188 - _31189;
    _31188 = NOVALUE;
    _31189 = NOVALUE;
    _31191 = Repeat(_21829, _31190);
    _31190 = NOVALUE;
    Concat((object_ptr)&_29toplevel_references_61064, _29toplevel_references_61064, _31191);
    DeRefDS(_31191);
    _31191 = NOVALUE;
L2: 

    /** 	for i = 1 to length( active_subprogs ) do*/
    if (IS_SEQUENCE(_29active_subprogs_61062)){
            _31193 = SEQ_PTR(_29active_subprogs_61062)->length;
    }
    else {
        _31193 = 1;
    }
    {
        int _i_62498;
        _i_62498 = 1;
L3: 
        if (_i_62498 > _31193){
            goto L4; // [136] 280
        }

        /** 		if (length( active_subprogs[i] ) or length(toplevel_references[i])) */
        _2 = (int)SEQ_PTR(_29active_subprogs_61062);
        _31194 = (int)*(((s1_ptr)_2)->base + _i_62498);
        if (IS_SEQUENCE(_31194)){
                _31195 = SEQ_PTR(_31194)->length;
        }
        else {
            _31195 = 1;
        }
        _31194 = NOVALUE;
        if (_31195 != 0) {
            _31196 = 1;
            goto L5; // [154] 171
        }
        _2 = (int)SEQ_PTR(_29toplevel_references_61064);
        _31197 = (int)*(((s1_ptr)_2)->base + _i_62498);
        if (IS_SEQUENCE(_31197)){
                _31198 = SEQ_PTR(_31197)->length;
        }
        else {
            _31198 = 1;
        }
        _31197 = NOVALUE;
        _31196 = (_31198 != 0);
L5: 
        if (_31196 == 0) {
            goto L6; // [171] 273
        }
        _31200 = (_i_62498 == _12current_file_no_11682);
        if (_31200 != 0) {
            _31201 = 1;
            goto L7; // [181] 195
        }
        _2 = (int)SEQ_PTR(_13finished_files_10639);
        _31202 = (int)*(((s1_ptr)_2)->base + _i_62498);
        _31201 = (_31202 != 0);
L7: 
        if (_31201 != 0) {
            DeRef(_31203);
            _31203 = 1;
            goto L8; // [195] 203
        }
        _31203 = (_unincluded_ok_62466 != 0);
L8: 
        if (_31203 == 0)
        {
            _31203 = NOVALUE;
            goto L6; // [204] 273
        }
        else{
            _31203 = NOVALUE;
        }

        /** 			for j = length( active_references[i] ) to 1 by -1 do*/
        _2 = (int)SEQ_PTR(_29active_references_61063);
        _31204 = (int)*(((s1_ptr)_2)->base + _i_62498);
        if (IS_SEQUENCE(_31204)){
                _31205 = SEQ_PTR(_31204)->length;
        }
        else {
            _31205 = 1;
        }
        _31204 = NOVALUE;
        {
            int _j_62514;
            _j_62514 = _31205;
L9: 
            if (_j_62514 < 1){
                goto LA; // [218] 254
            }

            /** 				errors &= resolve_file( active_references[i][j], report_errors, unincluded_ok )*/
            _2 = (int)SEQ_PTR(_29active_references_61063);
            _31206 = (int)*(((s1_ptr)_2)->base + _i_62498);
            _2 = (int)SEQ_PTR(_31206);
            _31207 = (int)*(((s1_ptr)_2)->base + _j_62514);
            _31206 = NOVALUE;
            Ref(_31207);
            _31208 = _29resolve_file(_31207, _report_errors_62464, _unincluded_ok_62466);
            _31207 = NOVALUE;
            if (IS_SEQUENCE(_errors_62465) && IS_ATOM(_31208)) {
                Ref(_31208);
                Append(&_errors_62465, _errors_62465, _31208);
            }
            else if (IS_ATOM(_errors_62465) && IS_SEQUENCE(_31208)) {
            }
            else {
                Concat((object_ptr)&_errors_62465, _errors_62465, _31208);
            }
            DeRef(_31208);
            _31208 = NOVALUE;

            /** 			end for*/
            _j_62514 = _j_62514 + -1;
            goto L9; // [249] 225
LA: 
            ;
        }

        /** 			errors &= resolve_file( toplevel_references[i], report_errors, unincluded_ok )*/
        _2 = (int)SEQ_PTR(_29toplevel_references_61064);
        _31210 = (int)*(((s1_ptr)_2)->base + _i_62498);
        Ref(_31210);
        _31211 = _29resolve_file(_31210, _report_errors_62464, _unincluded_ok_62466);
        _31210 = NOVALUE;
        if (IS_SEQUENCE(_errors_62465) && IS_ATOM(_31211)) {
            Ref(_31211);
            Append(&_errors_62465, _errors_62465, _31211);
        }
        else if (IS_ATOM(_errors_62465) && IS_SEQUENCE(_31211)) {
        }
        else {
            Concat((object_ptr)&_errors_62465, _errors_62465, _31211);
        }
        DeRef(_31211);
        _31211 = NOVALUE;
L6: 

        /** 	end for*/
        _i_62498 = _i_62498 + 1;
        goto L3; // [275] 143
L4: 
        ;
    }

    /** 	if report_errors and length( errors ) then*/
    if (_report_errors_62464 == 0) {
        goto LB; // [282] 854
    }
    if (IS_SEQUENCE(_errors_62465)){
            _31214 = SEQ_PTR(_errors_62465)->length;
    }
    else {
        _31214 = 1;
    }
    if (_31214 == 0)
    {
        _31214 = NOVALUE;
        goto LB; // [290] 854
    }
    else{
        _31214 = NOVALUE;
    }

    /** 		sequence msg = ""*/
    RefDS(_21829);
    DeRefi(_msg_62527);
    _msg_62527 = _21829;

    /** 		sequence errloc = "Internal Error - Unknown Error Message"*/
    RefDS(_31215);
    DeRefi(_errloc_62528);
    _errloc_62528 = _31215;

    /** 		for e = length(errors) to 1 by -1 do*/
    if (IS_SEQUENCE(_errors_62465)){
            _31216 = SEQ_PTR(_errors_62465)->length;
    }
    else {
        _31216 = 1;
    }
    {
        int _e_62531;
        _e_62531 = _31216;
LC: 
        if (_e_62531 < 1){
            goto LD; // [312] 828
        }

        /** 			sequence ref = forward_references[errors[e]]*/
        _2 = (int)SEQ_PTR(_errors_62465);
        _31217 = (int)*(((s1_ptr)_2)->base + _e_62531);
        DeRef(_ref_62533);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!IS_ATOM_INT(_31217)){
            _ref_62533 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31217)->dbl));
        }
        else{
            _ref_62533 = (int)*(((s1_ptr)_2)->base + _31217);
        }
        Ref(_ref_62533);

        /** 			if (ref[FR_TYPE] = TYPE_CHECK and ref[FR_OP] = TYPE_CHECK) or ref[FR_TYPE] = GLOBAL_INIT_CHECK then*/
        _2 = (int)SEQ_PTR(_ref_62533);
        _31219 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31219)) {
            _31220 = (_31219 == 65);
        }
        else {
            _31220 = binary_op(EQUALS, _31219, 65);
        }
        _31219 = NOVALUE;
        if (IS_ATOM_INT(_31220)) {
            if (_31220 == 0) {
                DeRef(_31221);
                _31221 = 0;
                goto LE; // [345] 363
            }
        }
        else {
            if (DBL_PTR(_31220)->dbl == 0.0) {
                DeRef(_31221);
                _31221 = 0;
                goto LE; // [345] 363
            }
        }
        _2 = (int)SEQ_PTR(_ref_62533);
        _31222 = (int)*(((s1_ptr)_2)->base + 10);
        if (IS_ATOM_INT(_31222)) {
            _31223 = (_31222 == 65);
        }
        else {
            _31223 = binary_op(EQUALS, _31222, 65);
        }
        _31222 = NOVALUE;
        DeRef(_31221);
        if (IS_ATOM_INT(_31223))
        _31221 = (_31223 != 0);
        else
        _31221 = DBL_PTR(_31223)->dbl != 0.0;
LE: 
        if (_31221 != 0) {
            goto LF; // [363] 382
        }
        _2 = (int)SEQ_PTR(_ref_62533);
        _31225 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31225)) {
            _31226 = (_31225 == 109);
        }
        else {
            _31226 = binary_op(EQUALS, _31225, 109);
        }
        _31225 = NOVALUE;
        if (_31226 == 0) {
            DeRef(_31226);
            _31226 = NOVALUE;
            goto L10; // [378] 391
        }
        else {
            if (!IS_ATOM_INT(_31226) && DBL_PTR(_31226)->dbl == 0.0){
                DeRef(_31226);
                _31226 = NOVALUE;
                goto L10; // [378] 391
            }
            DeRef(_31226);
            _31226 = NOVALUE;
        }
        DeRef(_31226);
        _31226 = NOVALUE;
LF: 

        /** 				continue*/
        DeRef(_ref_62533);
        _ref_62533 = NOVALUE;
        goto L11; // [386] 823
        goto L12; // [388] 789
L10: 

        /** 				object tok = find_reference(ref)*/
        RefDS(_ref_62533);
        _0 = _tok_62549;
        _tok_62549 = _29find_reference(_ref_62533);
        DeRef(_0);

        /** 				integer THIS_SCOPE = 3*/
        _THIS_SCOPE_62551 = 3;

        /** 				integer THESE_GLOBALS = 4*/
        _THESE_GLOBALS_62552 = 4;

        /** 				if tok[T_ID] = IGNORED then*/
        _2 = (int)SEQ_PTR(_tok_62549);
        _31228 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _31228, 509)){
            _31228 = NOVALUE;
            goto L13; // [417] 760
        }
        _31228 = NOVALUE;

        /** 					switch tok[THIS_SCOPE] do*/
        _2 = (int)SEQ_PTR(_tok_62549);
        _31230 = (int)*(((s1_ptr)_2)->base + 3);
        if (IS_SEQUENCE(_31230) ){
            goto L14; // [427] 756
        }
        if(!IS_ATOM_INT(_31230)){
            if( (DBL_PTR(_31230)->dbl != (double) ((int) DBL_PTR(_31230)->dbl) ) ){
                goto L14; // [427] 756
            }
            _0 = (int) DBL_PTR(_31230)->dbl;
        }
        else {
            _0 = _31230;
        };
        _31230 = NOVALUE;
        switch ( _0 ){ 

            /** 						case SC_UNDEFINED then*/
            case 9:

            /** 							if ref[FR_QUALIFIED] != -1 then*/
            _2 = (int)SEQ_PTR(_ref_62533);
            _31233 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(EQUALS, _31233, -1)){
                _31233 = NOVALUE;
                goto L15; // [442] 556
            }
            _31233 = NOVALUE;

            /** 								if ref[FR_QUALIFIED] > 0 then*/
            _2 = (int)SEQ_PTR(_ref_62533);
            _31235 = (int)*(((s1_ptr)_2)->base + 9);
            if (binary_op_a(LESSEQ, _31235, 0)){
                _31235 = NOVALUE;
                goto L16; // [452] 517
            }
            _31235 = NOVALUE;

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) was not declared in \'%s\'.\n", */
            _2 = (int)SEQ_PTR(_ref_62533);
            _31238 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62533);
            _31239 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_13known_files_10637);
            if (!IS_ATOM_INT(_31239)){
                _31240 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31239)->dbl));
            }
            else{
                _31240 = (int)*(((s1_ptr)_2)->base + _31239);
            }
            Ref(_31240);
            RefDS(_21829);
            _31241 = _14abbreviate_path(_31240, _21829);
            _31240 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62533);
            _31242 = (int)*(((s1_ptr)_2)->base + 6);
            _2 = (int)SEQ_PTR(_ref_62533);
            _31243 = (int)*(((s1_ptr)_2)->base + 9);
            _2 = (int)SEQ_PTR(_13known_files_10637);
            if (!IS_ATOM_INT(_31243)){
                _31244 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31243)->dbl));
            }
            else{
                _31244 = (int)*(((s1_ptr)_2)->base + _31243);
            }
            Ref(_31244);
            RefDS(_21829);
            _31245 = _14abbreviate_path(_31244, _21829);
            _31244 = NOVALUE;
            _31246 = _20find_replace(92, _31245, 47, 0);
            _31245 = NOVALUE;
            _1 = NewS1(4);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31238);
            *((int *)(_2+4)) = _31238;
            *((int *)(_2+8)) = _31241;
            Ref(_31242);
            *((int *)(_2+12)) = _31242;
            *((int *)(_2+16)) = _31246;
            _31247 = MAKE_SEQ(_1);
            _31246 = NOVALUE;
            _31242 = NOVALUE;
            _31241 = NOVALUE;
            _31238 = NOVALUE;
            DeRefi(_errloc_62528);
            _errloc_62528 = EPrintf(-9999999, _31237, _31247);
            DeRefDS(_31247);
            _31247 = NOVALUE;
            goto L17; // [514] 759
L16: 

            /** 									errloc = sprintf("\t\'%s\' (%s:%d) is not a builtin.\n", */
            _2 = (int)SEQ_PTR(_ref_62533);
            _31250 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62533);
            _31251 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_13known_files_10637);
            if (!IS_ATOM_INT(_31251)){
                _31252 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31251)->dbl));
            }
            else{
                _31252 = (int)*(((s1_ptr)_2)->base + _31251);
            }
            Ref(_31252);
            RefDS(_21829);
            _31253 = _14abbreviate_path(_31252, _21829);
            _31252 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62533);
            _31254 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31250);
            *((int *)(_2+4)) = _31250;
            *((int *)(_2+8)) = _31253;
            Ref(_31254);
            *((int *)(_2+12)) = _31254;
            _31255 = MAKE_SEQ(_1);
            _31254 = NOVALUE;
            _31253 = NOVALUE;
            _31250 = NOVALUE;
            DeRefi(_errloc_62528);
            _errloc_62528 = EPrintf(-9999999, _31249, _31255);
            DeRefDS(_31255);
            _31255 = NOVALUE;
            goto L17; // [553] 759
L15: 

            /** 								errloc = sprintf("\t\'%s\' (%s:%d) has not been declared.\n", */
            _2 = (int)SEQ_PTR(_ref_62533);
            _31258 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62533);
            _31259 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_13known_files_10637);
            if (!IS_ATOM_INT(_31259)){
                _31260 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31259)->dbl));
            }
            else{
                _31260 = (int)*(((s1_ptr)_2)->base + _31259);
            }
            Ref(_31260);
            RefDS(_21829);
            _31261 = _14abbreviate_path(_31260, _21829);
            _31260 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62533);
            _31262 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31258);
            *((int *)(_2+4)) = _31258;
            *((int *)(_2+8)) = _31261;
            Ref(_31262);
            *((int *)(_2+12)) = _31262;
            _31263 = MAKE_SEQ(_1);
            _31262 = NOVALUE;
            _31261 = NOVALUE;
            _31258 = NOVALUE;
            DeRefi(_errloc_62528);
            _errloc_62528 = EPrintf(-9999999, _31257, _31263);
            DeRefDS(_31263);
            _31263 = NOVALUE;
            goto L17; // [592] 759

            /** 						case SC_MULTIPLY_DEFINED then*/
            case 10:

            /** 							sequence syms = tok[THESE_GLOBALS] -- there should be no forward references in here.*/
            DeRef(_syms_62610);
            _2 = (int)SEQ_PTR(_tok_62549);
            _syms_62610 = (int)*(((s1_ptr)_2)->base + _THESE_GLOBALS_62552);
            Ref(_syms_62610);

            /** 							syms = custom_sort(routine_id("file_name_based_symindex_compare"), syms,, ASCENDING)*/
            _31267 = CRoutineId(1336, 29, _31266);
            RefDS(_syms_62610);
            RefDS(_21829);
            _0 = _syms_62610;
            _syms_62610 = _25custom_sort(_31267, _syms_62610, _21829, 1);
            DeRefDS(_0);
            _31267 = NOVALUE;

            /** 							errloc = sprintf("\t\'%s\' (%s:%d) has been declared more than once.\n", */
            _2 = (int)SEQ_PTR(_ref_62533);
            _31270 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_ref_62533);
            _31271 = (int)*(((s1_ptr)_2)->base + 3);
            _2 = (int)SEQ_PTR(_13known_files_10637);
            if (!IS_ATOM_INT(_31271)){
                _31272 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31271)->dbl));
            }
            else{
                _31272 = (int)*(((s1_ptr)_2)->base + _31271);
            }
            Ref(_31272);
            RefDS(_21829);
            _31273 = _14abbreviate_path(_31272, _21829);
            _31272 = NOVALUE;
            _2 = (int)SEQ_PTR(_ref_62533);
            _31274 = (int)*(((s1_ptr)_2)->base + 6);
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            Ref(_31270);
            *((int *)(_2+4)) = _31270;
            *((int *)(_2+8)) = _31273;
            Ref(_31274);
            *((int *)(_2+12)) = _31274;
            _31275 = MAKE_SEQ(_1);
            _31274 = NOVALUE;
            _31273 = NOVALUE;
            _31270 = NOVALUE;
            DeRefi(_errloc_62528);
            _errloc_62528 = EPrintf(-9999999, _31269, _31275);
            DeRefDS(_31275);
            _31275 = NOVALUE;

            /** 							for si = 1 to length(syms) do*/
            if (IS_SEQUENCE(_syms_62610)){
                    _31277 = SEQ_PTR(_syms_62610)->length;
            }
            else {
                _31277 = 1;
            }
            {
                int _si_62628;
                _si_62628 = 1;
L18: 
                if (_si_62628 > _31277){
                    goto L19; // [664] 750
                }

                /** 								symtab_index s = syms[si] */
                _2 = (int)SEQ_PTR(_syms_62610);
                _s_62631 = (int)*(((s1_ptr)_2)->base + _si_62628);
                if (!IS_ATOM_INT(_s_62631)){
                    _s_62631 = (long)DBL_PTR(_s_62631)->dbl;
                }

                /** 								if equal(ref[FR_NAME], sym_name(s)) then*/
                _2 = (int)SEQ_PTR(_ref_62533);
                _31279 = (int)*(((s1_ptr)_2)->base + 2);
                _31280 = _52sym_name(_s_62631);
                if (_31279 == _31280)
                _31281 = 1;
                else if (IS_ATOM_INT(_31279) && IS_ATOM_INT(_31280))
                _31281 = 0;
                else
                _31281 = (compare(_31279, _31280) == 0);
                _31279 = NOVALUE;
                DeRef(_31280);
                _31280 = NOVALUE;
                if (_31281 == 0)
                {
                    _31281 = NOVALUE;
                    goto L1A; // [693] 741
                }
                else{
                    _31281 = NOVALUE;
                }

                /** 									errloc &= sprintf("\t\tin %s\n", */
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _31283 = (int)*(((s1_ptr)_2)->base + _s_62631);
                _2 = (int)SEQ_PTR(_31283);
                if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
                    _31284 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
                }
                else{
                    _31284 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
                }
                _31283 = NOVALUE;
                _2 = (int)SEQ_PTR(_13known_files_10637);
                if (!IS_ATOM_INT(_31284)){
                    _31285 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31284)->dbl));
                }
                else{
                    _31285 = (int)*(((s1_ptr)_2)->base + _31284);
                }
                Ref(_31285);
                RefDS(_21829);
                _31286 = _14abbreviate_path(_31285, _21829);
                _31285 = NOVALUE;
                _31287 = _20find_replace(92, _31286, 47, 0);
                _31286 = NOVALUE;
                _1 = NewS1(1);
                _2 = (int)((s1_ptr)_1)->base;
                *((int *)(_2+4)) = _31287;
                _31288 = MAKE_SEQ(_1);
                _31287 = NOVALUE;
                _31289 = EPrintf(-9999999, _31282, _31288);
                DeRefDS(_31288);
                _31288 = NOVALUE;
                Concat((object_ptr)&_errloc_62528, _errloc_62528, _31289);
                DeRefDS(_31289);
                _31289 = NOVALUE;
L1A: 

                /** 							end for*/
                _si_62628 = _si_62628 + 1;
                goto L18; // [745] 671
L19: 
                ;
            }
            DeRef(_syms_62610);
            _syms_62610 = NOVALUE;
            goto L17; // [752] 759

            /** 						case else */
            default:
L14: 
        ;}L17: 
L13: 

        /** 				if not match(errloc, msg) then*/
        _31291 = e_match_from(_errloc_62528, _msg_62527, 1);
        if (_31291 != 0)
        goto L1B; // [767] 786
        _31291 = NOVALUE;

        /** 					msg &= errloc*/
        Concat((object_ptr)&_msg_62527, _msg_62527, _errloc_62528);

        /** 					prep_forward_error( errors[e] )*/
        _2 = (int)SEQ_PTR(_errors_62465);
        _31294 = (int)*(((s1_ptr)_2)->base + _e_62531);
        Ref(_31294);
        _29prep_forward_error(_31294);
        _31294 = NOVALUE;
L1B: 
        DeRef(_tok_62549);
        _tok_62549 = NOVALUE;
L12: 

        /** 			ThisLine    = ref[FR_THISLINE]*/
        DeRef(_43ThisLine_48158);
        _2 = (int)SEQ_PTR(_ref_62533);
        _43ThisLine_48158 = (int)*(((s1_ptr)_2)->base + 7);
        Ref(_43ThisLine_48158);

        /** 			bp          = ref[FR_BP]*/
        _2 = (int)SEQ_PTR(_ref_62533);
        _43bp_48162 = (int)*(((s1_ptr)_2)->base + 8);
        if (!IS_ATOM_INT(_43bp_48162)){
            _43bp_48162 = (long)DBL_PTR(_43bp_48162)->dbl;
        }

        /** 			CurrentSub  = ref[FR_SUBPROG]*/
        _2 = (int)SEQ_PTR(_ref_62533);
        _12CurrentSub_11690 = (int)*(((s1_ptr)_2)->base + 4);
        if (!IS_ATOM_INT(_12CurrentSub_11690)){
            _12CurrentSub_11690 = (long)DBL_PTR(_12CurrentSub_11690)->dbl;
        }

        /** 			line_number = ref[FR_LINE]*/
        _2 = (int)SEQ_PTR(_ref_62533);
        _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 6);
        if (!IS_ATOM_INT(_12line_number_11683)){
            _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
        }
        DeRefDS(_ref_62533);
        _ref_62533 = NOVALUE;

        /** 		end for*/
L11: 
        _e_62531 = _e_62531 + -1;
        goto LC; // [823] 319
LD: 
        ;
    }

    /** 		if length(msg) > 0 then*/
    if (IS_SEQUENCE(_msg_62527)){
            _31299 = SEQ_PTR(_msg_62527)->length;
    }
    else {
        _31299 = 1;
    }
    if (_31299 <= 0)
    goto L1C; // [833] 849

    /** 			CompileErr( 74, {msg} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_msg_62527);
    *((int *)(_2+4)) = _msg_62527;
    _31301 = MAKE_SEQ(_1);
    _43CompileErr(74, _31301, 0);
    _31301 = NOVALUE;
L1C: 
    DeRefi(_msg_62527);
    _msg_62527 = NOVALUE;
    DeRefi(_errloc_62528);
    _errloc_62528 = NOVALUE;
    goto L1D; // [851] 889
LB: 

    /** 	elsif report_errors then*/
    if (_report_errors_62464 == 0)
    {
        goto L1E; // [856] 888
    }
    else{
    }

    /** 		forward_references  = {}*/
    RefDS(_21829);
    DeRef(_29forward_references_61061);
    _29forward_references_61061 = _21829;

    /** 		active_references   = {}*/
    RefDS(_21829);
    DeRef(_29active_references_61063);
    _29active_references_61063 = _21829;

    /** 		toplevel_references = {}*/
    RefDS(_21829);
    DeRef(_29toplevel_references_61064);
    _29toplevel_references_61064 = _21829;

    /** 		inactive_references = {}*/
    RefDS(_21829);
    DeRef(_29inactive_references_61065);
    _29inactive_references_61065 = _21829;
L1E: 
L1D: 

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    DeRef(_errors_62465);
    _31194 = NOVALUE;
    _31197 = NOVALUE;
    DeRef(_31200);
    _31200 = NOVALUE;
    _31202 = NOVALUE;
    _31204 = NOVALUE;
    _31217 = NOVALUE;
    _31284 = NOVALUE;
    DeRef(_31220);
    _31220 = NOVALUE;
    DeRef(_31223);
    _31223 = NOVALUE;
    _31239 = NOVALUE;
    _31251 = NOVALUE;
    _31259 = NOVALUE;
    _31243 = NOVALUE;
    _31271 = NOVALUE;
    return;
    ;
}


void _29shift_these(int _refs_62675, int _pc_62676, int _amount_62677)
{
    int _fr_62681 = NOVALUE;
    int _31319 = NOVALUE;
    int _31318 = NOVALUE;
    int _31317 = NOVALUE;
    int _31316 = NOVALUE;
    int _31315 = NOVALUE;
    int _31314 = NOVALUE;
    int _31313 = NOVALUE;
    int _31312 = NOVALUE;
    int _31311 = NOVALUE;
    int _31310 = NOVALUE;
    int _31308 = NOVALUE;
    int _31306 = NOVALUE;
    int _31305 = NOVALUE;
    int _31303 = NOVALUE;
    int _31302 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62675)){
            _31302 = SEQ_PTR(_refs_62675)->length;
    }
    else {
        _31302 = 1;
    }
    {
        int _i_62679;
        _i_62679 = _31302;
L1: 
        if (_i_62679 < 1){
            goto L2; // [12] 147
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_62675);
        _31303 = (int)*(((s1_ptr)_2)->base + _i_62679);
        DeRef(_fr_62681);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!IS_ATOM_INT(_31303)){
            _fr_62681 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31303)->dbl));
        }
        else{
            _fr_62681 = (int)*(((s1_ptr)_2)->base + _31303);
        }
        Ref(_fr_62681);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_62675);
        _31305 = (int)*(((s1_ptr)_2)->base + _i_62679);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31305))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31305)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31305);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_SUBPROG] = shifting_sub then*/
        _2 = (int)SEQ_PTR(_fr_62681);
        _31306 = (int)*(((s1_ptr)_2)->base + 4);
        if (binary_op_a(NOTEQ, _31306, _29shifting_sub_61080)){
            _31306 = NOVALUE;
            goto L3; // [53] 126
        }
        _31306 = NOVALUE;

        /** 			if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_62681);
        _31308 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31308, _pc_62676)){
            _31308 = NOVALUE;
            goto L4; // [63] 125
        }
        _31308 = NOVALUE;

        /** 				fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_62681);
        _31310 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31310)) {
            _31311 = _31310 + _amount_62677;
            if ((long)((unsigned long)_31311 + (unsigned long)HIGH_BITS) >= 0) 
            _31311 = NewDouble((double)_31311);
        }
        else {
            _31311 = binary_op(PLUS, _31310, _amount_62677);
        }
        _31310 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62681);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62681 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31311;
        if( _1 != _31311 ){
            DeRef(_1);
        }
        _31311 = NOVALUE;

        /** 				if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_62681);
        _31312 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31312)) {
            _31313 = (_31312 == 186);
        }
        else {
            _31313 = binary_op(EQUALS, _31312, 186);
        }
        _31312 = NOVALUE;
        if (IS_ATOM_INT(_31313)) {
            if (_31313 == 0) {
                goto L5; // [93] 124
            }
        }
        else {
            if (DBL_PTR(_31313)->dbl == 0.0) {
                goto L5; // [93] 124
            }
        }
        _2 = (int)SEQ_PTR(_fr_62681);
        _31315 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31315)) {
            _31316 = (_31315 >= _pc_62676);
        }
        else {
            _31316 = binary_op(GREATEREQ, _31315, _pc_62676);
        }
        _31315 = NOVALUE;
        if (_31316 == 0) {
            DeRef(_31316);
            _31316 = NOVALUE;
            goto L5; // [106] 124
        }
        else {
            if (!IS_ATOM_INT(_31316) && DBL_PTR(_31316)->dbl == 0.0){
                DeRef(_31316);
                _31316 = NOVALUE;
                goto L5; // [106] 124
            }
            DeRef(_31316);
            _31316 = NOVALUE;
        }
        DeRef(_31316);
        _31316 = NOVALUE;

        /** 					fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_62681);
        _31317 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31317)) {
            _31318 = _31317 + _amount_62677;
            if ((long)((unsigned long)_31318 + (unsigned long)HIGH_BITS) >= 0) 
            _31318 = NewDouble((double)_31318);
        }
        else {
            _31318 = binary_op(PLUS, _31317, _amount_62677);
        }
        _31317 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62681);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62681 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31318;
        if( _1 != _31318 ){
            DeRef(_1);
        }
        _31318 = NOVALUE;
L5: 
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_62675);
        _31319 = (int)*(((s1_ptr)_2)->base + _i_62679);
        RefDS(_fr_62681);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31319))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31319)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31319);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_62681;
        DeRef(_1);
        DeRefDS(_fr_62681);
        _fr_62681 = NOVALUE;

        /** 	end for*/
        _i_62679 = _i_62679 + -1;
        goto L1; // [142] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_62675);
    _31303 = NOVALUE;
    _31305 = NOVALUE;
    _31319 = NOVALUE;
    DeRef(_31313);
    _31313 = NOVALUE;
    return;
    ;
}


void _29shift_top(int _refs_62705, int _pc_62706, int _amount_62707)
{
    int _fr_62711 = NOVALUE;
    int _31335 = NOVALUE;
    int _31334 = NOVALUE;
    int _31333 = NOVALUE;
    int _31332 = NOVALUE;
    int _31331 = NOVALUE;
    int _31330 = NOVALUE;
    int _31329 = NOVALUE;
    int _31328 = NOVALUE;
    int _31327 = NOVALUE;
    int _31326 = NOVALUE;
    int _31324 = NOVALUE;
    int _31323 = NOVALUE;
    int _31321 = NOVALUE;
    int _31320 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( refs ) to 1 by -1 do*/
    if (IS_SEQUENCE(_refs_62705)){
            _31320 = SEQ_PTR(_refs_62705)->length;
    }
    else {
        _31320 = 1;
    }
    {
        int _i_62709;
        _i_62709 = _31320;
L1: 
        if (_i_62709 < 1){
            goto L2; // [12] 134
        }

        /** 		sequence fr = forward_references[refs[i]]*/
        _2 = (int)SEQ_PTR(_refs_62705);
        _31321 = (int)*(((s1_ptr)_2)->base + _i_62709);
        DeRef(_fr_62711);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!IS_ATOM_INT(_31321)){
            _fr_62711 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31321)->dbl));
        }
        else{
            _fr_62711 = (int)*(((s1_ptr)_2)->base + _31321);
        }
        Ref(_fr_62711);

        /** 		forward_references[refs[i]] = 0*/
        _2 = (int)SEQ_PTR(_refs_62705);
        _31323 = (int)*(((s1_ptr)_2)->base + _i_62709);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31323))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31323)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31323);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);

        /** 		if fr[FR_PC] >= pc then*/
        _2 = (int)SEQ_PTR(_fr_62711);
        _31324 = (int)*(((s1_ptr)_2)->base + 5);
        if (binary_op_a(LESS, _31324, _pc_62706)){
            _31324 = NOVALUE;
            goto L3; // [51] 113
        }
        _31324 = NOVALUE;

        /** 			fr[FR_PC] += amount*/
        _2 = (int)SEQ_PTR(_fr_62711);
        _31326 = (int)*(((s1_ptr)_2)->base + 5);
        if (IS_ATOM_INT(_31326)) {
            _31327 = _31326 + _amount_62707;
            if ((long)((unsigned long)_31327 + (unsigned long)HIGH_BITS) >= 0) 
            _31327 = NewDouble((double)_31327);
        }
        else {
            _31327 = binary_op(PLUS, _31326, _amount_62707);
        }
        _31326 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62711);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62711 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _31327;
        if( _1 != _31327 ){
            DeRef(_1);
        }
        _31327 = NOVALUE;

        /** 			if fr[FR_TYPE] = CASE*/
        _2 = (int)SEQ_PTR(_fr_62711);
        _31328 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_31328)) {
            _31329 = (_31328 == 186);
        }
        else {
            _31329 = binary_op(EQUALS, _31328, 186);
        }
        _31328 = NOVALUE;
        if (IS_ATOM_INT(_31329)) {
            if (_31329 == 0) {
                goto L4; // [81] 112
            }
        }
        else {
            if (DBL_PTR(_31329)->dbl == 0.0) {
                goto L4; // [81] 112
            }
        }
        _2 = (int)SEQ_PTR(_fr_62711);
        _31331 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31331)) {
            _31332 = (_31331 >= _pc_62706);
        }
        else {
            _31332 = binary_op(GREATEREQ, _31331, _pc_62706);
        }
        _31331 = NOVALUE;
        if (_31332 == 0) {
            DeRef(_31332);
            _31332 = NOVALUE;
            goto L4; // [94] 112
        }
        else {
            if (!IS_ATOM_INT(_31332) && DBL_PTR(_31332)->dbl == 0.0){
                DeRef(_31332);
                _31332 = NOVALUE;
                goto L4; // [94] 112
            }
            DeRef(_31332);
            _31332 = NOVALUE;
        }
        DeRef(_31332);
        _31332 = NOVALUE;

        /** 				fr[FR_DATA] += amount*/
        _2 = (int)SEQ_PTR(_fr_62711);
        _31333 = (int)*(((s1_ptr)_2)->base + 12);
        if (IS_ATOM_INT(_31333)) {
            _31334 = _31333 + _amount_62707;
            if ((long)((unsigned long)_31334 + (unsigned long)HIGH_BITS) >= 0) 
            _31334 = NewDouble((double)_31334);
        }
        else {
            _31334 = binary_op(PLUS, _31333, _amount_62707);
        }
        _31333 = NOVALUE;
        _2 = (int)SEQ_PTR(_fr_62711);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _fr_62711 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 12);
        _1 = *(int *)_2;
        *(int *)_2 = _31334;
        if( _1 != _31334 ){
            DeRef(_1);
        }
        _31334 = NOVALUE;
L4: 
L3: 

        /** 		forward_references[refs[i]] = fr*/
        _2 = (int)SEQ_PTR(_refs_62705);
        _31335 = (int)*(((s1_ptr)_2)->base + _i_62709);
        RefDS(_fr_62711);
        _2 = (int)SEQ_PTR(_29forward_references_61061);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _29forward_references_61061 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_31335))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_31335)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _31335);
        _1 = *(int *)_2;
        *(int *)_2 = _fr_62711;
        DeRef(_1);
        DeRefDS(_fr_62711);
        _fr_62711 = NOVALUE;

        /** 	end for*/
        _i_62709 = _i_62709 + -1;
        goto L1; // [129] 19
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_refs_62705);
    _31321 = NOVALUE;
    _31323 = NOVALUE;
    _31335 = NOVALUE;
    DeRef(_31329);
    _31329 = NOVALUE;
    return;
    ;
}


void _29shift_fwd_refs(int _pc_62732, int _amount_62733)
{
    int _file_62744 = NOVALUE;
    int _sp_62749 = NOVALUE;
    int _31345 = NOVALUE;
    int _31344 = NOVALUE;
    int _31342 = NOVALUE;
    int _31340 = NOVALUE;
    int _31339 = NOVALUE;
    int _31338 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_pc_62732)) {
        _1 = (long)(DBL_PTR(_pc_62732)->dbl);
        DeRefDS(_pc_62732);
        _pc_62732 = _1;
    }
    if (!IS_ATOM_INT(_amount_62733)) {
        _1 = (long)(DBL_PTR(_amount_62733)->dbl);
        DeRefDS(_amount_62733);
        _amount_62733 = _1;
    }

    /** 	if not shifting_sub then*/
    if (_29shifting_sub_61080 != 0)
    goto L1; // [9] 18

    /** 		return*/
    return;
L1: 

    /** 	if shifting_sub = TopLevelSub then*/
    if (_29shifting_sub_61080 != _12TopLevelSub_11689)
    goto L2; // [24] 65

    /** 		for file = 1 to length( toplevel_references ) do*/
    if (IS_SEQUENCE(_29toplevel_references_61064)){
            _31338 = SEQ_PTR(_29toplevel_references_61064)->length;
    }
    else {
        _31338 = 1;
    }
    {
        int _file_62740;
        _file_62740 = 1;
L3: 
        if (_file_62740 > _31338){
            goto L4; // [35] 62
        }

        /** 			shift_top( toplevel_references[file], pc, amount )*/
        _2 = (int)SEQ_PTR(_29toplevel_references_61064);
        _31339 = (int)*(((s1_ptr)_2)->base + _file_62740);
        Ref(_31339);
        _29shift_top(_31339, _pc_62732, _amount_62733);
        _31339 = NOVALUE;

        /** 		end for*/
        _file_62740 = _file_62740 + 1;
        goto L3; // [57] 42
L4: 
        ;
    }
    goto L5; // [62] 118
L2: 

    /** 		integer file = SymTab[shifting_sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31340 = (int)*(((s1_ptr)_2)->base + _29shifting_sub_61080);
    _2 = (int)SEQ_PTR(_31340);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _file_62744 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _file_62744 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_file_62744)){
        _file_62744 = (long)DBL_PTR(_file_62744)->dbl;
    }
    _31340 = NOVALUE;

    /** 		integer sp   = find( shifting_sub, active_subprogs[file] )*/
    _2 = (int)SEQ_PTR(_29active_subprogs_61062);
    _31342 = (int)*(((s1_ptr)_2)->base + _file_62744);
    _sp_62749 = find_from(_29shifting_sub_61080, _31342, 1);
    _31342 = NOVALUE;

    /** 		shift_these( active_references[file][sp], pc, amount )*/
    _2 = (int)SEQ_PTR(_29active_references_61063);
    _31344 = (int)*(((s1_ptr)_2)->base + _file_62744);
    _2 = (int)SEQ_PTR(_31344);
    _31345 = (int)*(((s1_ptr)_2)->base + _sp_62749);
    _31344 = NOVALUE;
    Ref(_31345);
    _29shift_these(_31345, _pc_62732, _amount_62733);
    _31345 = NOVALUE;
L5: 

    /** end procedure*/
    return;
    ;
}



// 0xA923D3A9
