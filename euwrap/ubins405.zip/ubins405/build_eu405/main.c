// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _69GetSourceName()
{
    int _real_name_68589 = NOVALUE;
    int _fh_68590 = NOVALUE;
    int _has_extension_68592 = NOVALUE;
    int _34596 = NOVALUE;
    int _34594 = NOVALUE;
    int _34593 = NOVALUE;
    int _34590 = NOVALUE;
    int _34589 = NOVALUE;
    int _34588 = NOVALUE;
    int _34587 = NOVALUE;
    int _34586 = NOVALUE;
    int _34585 = NOVALUE;
    int _34582 = NOVALUE;
    int _34581 = NOVALUE;
    int _34579 = NOVALUE;
    int _34578 = NOVALUE;
    int _34577 = NOVALUE;
    int _34576 = NOVALUE;
    int _34575 = NOVALUE;
    int _34574 = NOVALUE;
    int _34571 = NOVALUE;
    int _34570 = NOVALUE;
    int _34568 = NOVALUE;
    int _34567 = NOVALUE;
    int _34565 = NOVALUE;
    int _0, _1, _2;
    

    /** 	boolean has_extension = FALSE*/
    _has_extension_68592 = _9FALSE_429;

    /** 	if length(src_name) = 0 then*/
    if (IS_SEQUENCE(_39src_name_48496)){
            _34565 = SEQ_PTR(_39src_name_48496)->length;
    }
    else {
        _34565 = 1;
    }
    if (_34565 != 0)
    goto L1; // [15] 30

    /** 		show_banner()*/
    _39show_banner();

    /** 		return -2 -- No source file*/
    DeRef(_real_name_68589);
    return -2;
L1: 

    /** 	ifdef WINDOWS then*/

    /** 	for p = length(src_name) to 1 by -1 do*/
    if (IS_SEQUENCE(_39src_name_48496)){
            _34567 = SEQ_PTR(_39src_name_48496)->length;
    }
    else {
        _34567 = 1;
    }
    {
        int _p_68600;
        _p_68600 = _34567;
L2: 
        if (_p_68600 < 1){
            goto L3; // [39] 103
        }

        /** 		if src_name[p] = '.' then*/
        _2 = (int)SEQ_PTR(_39src_name_48496);
        _34568 = (int)*(((s1_ptr)_2)->base + _p_68600);
        if (binary_op_a(NOTEQ, _34568, 46)){
            _34568 = NOVALUE;
            goto L4; // [54] 72
        }
        _34568 = NOVALUE;

        /** 		   has_extension = TRUE*/
        _has_extension_68592 = _9TRUE_431;

        /** 		   exit*/
        goto L3; // [67] 103
        goto L5; // [69] 96
L4: 

        /** 		elsif find(src_name[p], SLASH_CHARS) then*/
        _2 = (int)SEQ_PTR(_39src_name_48496);
        _34570 = (int)*(((s1_ptr)_2)->base + _p_68600);
        _34571 = find_from(_34570, _36SLASH_CHARS_14019, 1);
        _34570 = NOVALUE;
        if (_34571 == 0)
        {
            _34571 = NOVALUE;
            goto L6; // [87] 95
        }
        else{
            _34571 = NOVALUE;
        }

        /** 		   exit*/
        goto L3; // [92] 103
L6: 
L5: 

        /** 	end for*/
        _p_68600 = _p_68600 + -1;
        goto L2; // [98] 46
L3: 
        ;
    }

    /** 	if not has_extension then*/
    if (_has_extension_68592 != 0)
    goto L7; // [105] 210

    /** 		known_files = append(known_files, "")*/
    RefDS(_21829);
    Append(&_13known_files_10637, _13known_files_10637, _21829);

    /** 		for i = 1 to length( DEFAULT_EXTS ) do*/
    _34574 = 4;
    {
        int _i_68619;
        _i_68619 = 1;
L8: 
        if (_i_68619 > 4){
            goto L9; // [125] 190
        }

        /** 			known_files[$] = src_name & DEFAULT_EXTS[i]*/
        if (IS_SEQUENCE(_13known_files_10637)){
                _34575 = SEQ_PTR(_13known_files_10637)->length;
        }
        else {
            _34575 = 1;
        }
        _2 = (int)SEQ_PTR(_36DEFAULT_EXTS_14000);
        _34576 = (int)*(((s1_ptr)_2)->base + _i_68619);
        Concat((object_ptr)&_34577, _39src_name_48496, _34576);
        _34576 = NOVALUE;
        _2 = (int)SEQ_PTR(_13known_files_10637);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13known_files_10637 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _34575);
        _1 = *(int *)_2;
        *(int *)_2 = _34577;
        if( _1 != _34577 ){
            DeRef(_1);
        }
        _34577 = NOVALUE;

        /** 			real_name = e_path_find(known_files[$])*/
        if (IS_SEQUENCE(_13known_files_10637)){
                _34578 = SEQ_PTR(_13known_files_10637)->length;
        }
        else {
            _34578 = 1;
        }
        _2 = (int)SEQ_PTR(_13known_files_10637);
        _34579 = (int)*(((s1_ptr)_2)->base + _34578);
        Ref(_34579);
        _0 = _real_name_68589;
        _real_name_68589 = _38e_path_find(_34579);
        DeRef(_0);
        _34579 = NOVALUE;

        /** 			if sequence(real_name) then*/
        _34581 = IS_SEQUENCE(_real_name_68589);
        if (_34581 == 0)
        {
            _34581 = NOVALUE;
            goto LA; // [175] 183
        }
        else{
            _34581 = NOVALUE;
        }

        /** 				exit*/
        goto L9; // [180] 190
LA: 

        /** 		end for*/
        _i_68619 = _i_68619 + 1;
        goto L8; // [185] 132
L9: 
        ;
    }

    /** 		if atom(real_name) then*/
    _34582 = IS_ATOM(_real_name_68589);
    if (_34582 == 0)
    {
        _34582 = NOVALUE;
        goto LB; // [197] 246
    }
    else{
        _34582 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_68589);
    return -1;
    goto LB; // [207] 246
L7: 

    /** 		known_files = append(known_files, src_name)*/
    RefDS(_39src_name_48496);
    Append(&_13known_files_10637, _13known_files_10637, _39src_name_48496);

    /** 		real_name = e_path_find(src_name)*/
    RefDS(_39src_name_48496);
    _0 = _real_name_68589;
    _real_name_68589 = _38e_path_find(_39src_name_48496);
    DeRef(_0);

    /** 		if atom(real_name) then*/
    _34585 = IS_ATOM(_real_name_68589);
    if (_34585 == 0)
    {
        _34585 = NOVALUE;
        goto LC; // [235] 245
    }
    else{
        _34585 = NOVALUE;
    }

    /** 			return -1*/
    DeRef(_real_name_68589);
    return -1;
LC: 
LB: 

    /** 	known_files[$] = canonical_path(real_name,,CORRECT)*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _34586 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _34586 = 1;
    }
    Ref(_real_name_68589);
    _34587 = _14canonical_path(_real_name_68589, 0, 2);
    _2 = (int)SEQ_PTR(_13known_files_10637);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13known_files_10637 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _34586);
    _1 = *(int *)_2;
    *(int *)_2 = _34587;
    if( _1 != _34587 ){
        DeRef(_1);
    }
    _34587 = NOVALUE;

    /** 	known_files_hash &= hash(known_files[$], stdhash:HSIEH32)*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _34588 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _34588 = 1;
    }
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _34589 = (int)*(((s1_ptr)_2)->base + _34588);
    _34590 = calc_hash(_34589, -5);
    _34589 = NOVALUE;
    Ref(_34590);
    Append(&_13known_files_hash_10638, _13known_files_hash_10638, _34590);
    DeRef(_34590);
    _34590 = NOVALUE;

    /** 	finished_files &= 0*/
    Append(&_13finished_files_10639, _13finished_files_10639, 0);

    /** 	file_include_depend = append( file_include_depend, { length( known_files ) } )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _34593 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _34593 = 1;
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _34593;
    _34594 = MAKE_SEQ(_1);
    _34593 = NOVALUE;
    RefDS(_34594);
    Append(&_13file_include_depend_10640, _13file_include_depend_10640, _34594);
    DeRefDS(_34594);
    _34594 = NOVALUE;

    /** 	if file_exists(real_name) then*/
    Ref(_real_name_68589);
    _34596 = _14file_exists(_real_name_68589);
    if (_34596 == 0) {
        DeRef(_34596);
        _34596 = NOVALUE;
        goto LD; // [325] 349
    }
    else {
        if (!IS_ATOM_INT(_34596) && DBL_PTR(_34596)->dbl == 0.0){
            DeRef(_34596);
            _34596 = NOVALUE;
            goto LD; // [325] 349
        }
        DeRef(_34596);
        _34596 = NOVALUE;
    }
    DeRef(_34596);
    _34596 = NOVALUE;

    /** 		real_name = maybe_preprocess(real_name)*/
    Ref(_real_name_68589);
    _0 = _real_name_68589;
    _real_name_68589 = _63maybe_preprocess(_real_name_68589);
    DeRef(_0);

    /** 		fh = open_locked(real_name)*/
    Ref(_real_name_68589);
    _fh_68590 = _13open_locked(_real_name_68589);
    if (!IS_ATOM_INT(_fh_68590)) {
        _1 = (long)(DBL_PTR(_fh_68590)->dbl);
        DeRefDS(_fh_68590);
        _fh_68590 = _1;
    }

    /** 		return fh*/
    DeRef(_real_name_68589);
    return _fh_68590;
LD: 

    /** 	return -1*/
    DeRef(_real_name_68589);
    return -1;
    ;
}


void _69main()
{
    int _argc_68688 = NOVALUE;
    int _argv_68689 = NOVALUE;
    int _34626 = NOVALUE;
    int _34625 = NOVALUE;
    int _34622 = NOVALUE;
    int _34620 = NOVALUE;
    int _34618 = NOVALUE;
    int _34617 = NOVALUE;
    int _34616 = NOVALUE;
    int _34615 = NOVALUE;
    int _34614 = NOVALUE;
    int _34613 = NOVALUE;
    int _34612 = NOVALUE;
    int _34611 = NOVALUE;
    int _34607 = NOVALUE;
    int _0, _1, _2;
    

    /** 	argv = command_line()*/
    DeRef(_argv_68689);
    _argv_68689 = Command_Line();

    /** 	if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L1; // [9] 21
    }
    else{
    }

    /** 		argv = extract_options(argv)*/
    RefDS(_argv_68689);
    _0 = _argv_68689;
    _argv_68689 = _2extract_options(_argv_68689);
    DeRefDS(_0);
L1: 

    /** 	argc = length(argv)*/
    if (IS_SEQUENCE(_argv_68689)){
            _argc_68688 = SEQ_PTR(_argv_68689)->length;
    }
    else {
        _argc_68688 = 1;
    }

    /** 	Argv = argv*/
    RefDS(_argv_68689);
    DeRef(_12Argv_11693);
    _12Argv_11693 = _argv_68689;

    /** 	Argc = argc*/
    _12Argc_11692 = _argc_68688;

    /** 	TempErrName = "ex.err"*/
    RefDS(_31479);
    DeRefi(_43TempErrName_48156);
    _43TempErrName_48156 = _31479;

    /** 	TempWarningName = STDERR*/
    DeRef(_12TempWarningName_11696);
    _12TempWarningName_11696 = 2;

    /** 	display_warnings = 1*/
    _43display_warnings_48157 = 1;

    /** 	InitGlobals()*/
    _30InitGlobals();

    /** 	if TRANSLATE or BIND or INTERPRET then*/
    if (_12TRANSLATE_11319 != 0) {
        _34607 = 1;
        goto L2; // [69] 79
    }
    _34607 = (_12BIND_11322 != 0);
L2: 
    if (_34607 != 0) {
        goto L3; // [79] 90
    }
    if (_12INTERPRET_11316 == 0)
    {
        goto L4; // [86] 96
    }
    else{
    }
L3: 

    /** 		InitBackEnd(0)*/
    _2InitBackEnd(0);
L4: 

    /** 	src_file = GetSourceName()*/
    _0 = _69GetSourceName();
    _12src_file_11804 = _0;
    if (!IS_ATOM_INT(_12src_file_11804)) {
        _1 = (long)(DBL_PTR(_12src_file_11804)->dbl);
        DeRefDS(_12src_file_11804);
        _12src_file_11804 = _1;
    }

    /** 	if src_file = -1 then*/
    if (_12src_file_11804 != -1)
    goto L5; // [107] 181

    /** 		screen_output(STDERR, GetMsgText(51, 0, {known_files[$]}))*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _34611 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _34611 = 1;
    }
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _34612 = (int)*(((s1_ptr)_2)->base + _34611);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_34612);
    *((int *)(_2+4)) = _34612;
    _34613 = MAKE_SEQ(_1);
    _34612 = NOVALUE;
    _34614 = _44GetMsgText(51, 0, _34613);
    _34613 = NOVALUE;
    _43screen_output(2, _34614);
    _34614 = NOVALUE;

    /** 		if not batch_job and not test_only then*/
    _34615 = (_12batch_job_11695 == 0);
    if (_34615 == 0) {
        goto L6; // [145] 173
    }
    _34617 = (_12test_only_11694 == 0);
    if (_34617 == 0)
    {
        DeRef(_34617);
        _34617 = NOVALUE;
        goto L6; // [155] 173
    }
    else{
        DeRef(_34617);
        _34617 = NOVALUE;
    }

    /** 			maybe_any_key(GetMsgText(277,0), STDERR)*/
    RefDS(_21829);
    _34618 = _44GetMsgText(277, 0, _21829);
    _41maybe_any_key(_34618, 2);
    _34618 = NOVALUE;
L6: 

    /** 		Cleanup(1)*/
    _43Cleanup(1);
    goto L7; // [178] 226
L5: 

    /** 	elsif src_file >= 0 then*/
    if (_12src_file_11804 < 0)
    goto L8; // [185] 225

    /** 		main_path = known_files[$]*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _34620 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _34620 = 1;
    }
    DeRef(_12main_path_11803);
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _12main_path_11803 = (int)*(((s1_ptr)_2)->base + _34620);
    Ref(_12main_path_11803);

    /** 		if length(main_path) = 0 then*/
    if (IS_SEQUENCE(_12main_path_11803)){
            _34622 = SEQ_PTR(_12main_path_11803)->length;
    }
    else {
        _34622 = 1;
    }
    if (_34622 != 0)
    goto L9; // [209] 224

    /** 			main_path = '.' & SLASH*/
    Concat((object_ptr)&_12main_path_11803, 46, 47);
L9: 
L8: 
L7: 

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LA; // [230] 239
    }
    else{
    }

    /** 		InitBackEnd(1)*/
    _2InitBackEnd(1);
LA: 

    /** 	CheckPlatform()*/
    _2CheckPlatform();

    /** 	InitSymTab()*/
    _52InitSymTab();

    /** 	InitEmit()*/
    _37InitEmit();

    /** 	InitLex()*/
    _60InitLex();

    /** 	InitParser()*/
    _30InitParser();

    /** 	eu_namespace()*/
    _60eu_namespace();

    /** 	ifdef TRANSLATOR then*/

    /** 	main_file()*/
    _60main_file();

    /** 	check_coverage()*/
    _49check_coverage();

    /** 	parser()*/
    _30parser();

    /** 	init_coverage()*/
    _49init_coverage();

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LB; // [285] 296
    }
    else{
    }

    /** 		BackEnd(0) -- translate IL to C*/
    _2BackEnd(0);
    goto LC; // [293] 336
LB: 

    /** 	elsif BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto LD; // [300] 310
    }
    else{
    }

    /** 		OutputIL()*/
    _2OutputIL();
    goto LC; // [307] 336
LD: 

    /** 	elsif INTERPRET and not test_only then*/
    if (_12INTERPRET_11316 == 0) {
        goto LE; // [314] 335
    }
    _34626 = (_12test_only_11694 == 0);
    if (_34626 == 0)
    {
        DeRef(_34626);
        _34626 = NOVALUE;
        goto LE; // [324] 335
    }
    else{
        DeRef(_34626);
        _34626 = NOVALUE;
    }

    /** 		ifdef not STDDEBUG then*/

    /** 			BackEnd(0) -- execute IL using Euphoria-coded back-end*/
    _2BackEnd(0);
LE: 
LC: 

    /** 	Cleanup(0) -- does warnings*/
    _43Cleanup(0);

    /** end procedure*/
    DeRef(_argv_68689);
    DeRef(_34615);
    _34615 = NOVALUE;
    return;
    ;
}



// 0xFEC09C8C
