// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _13open_locked(int _file_path_10668)
{
    int _fh_10669 = NOVALUE;
    int _0, _1, _2;
    

    /** 	fh = open(file_path, "u")*/
    _fh_10669 = EOpen(_file_path_10668, _5945, 0);

    /** 	if fh = -1 then*/
    if (_fh_10669 != -1)
    goto L1; // [12] 24

    /** 		fh = open(file_path, "r")*/
    _fh_10669 = EOpen(_file_path_10668, _4043, 0);
L1: 

    /** 	return fh*/
    DeRefDS(_file_path_10668);
    return _fh_10669;
    ;
}


int _13get_eudir()
{
    int _possible_paths_10682 = NOVALUE;
    int _home_10687 = NOVALUE;
    int _possible_path_10701 = NOVALUE;
    int _possible_path_10715 = NOVALUE;
    int _file_check_10729 = NOVALUE;
    int _5986 = NOVALUE;
    int _5985 = NOVALUE;
    int _5984 = NOVALUE;
    int _5982 = NOVALUE;
    int _5980 = NOVALUE;
    int _5978 = NOVALUE;
    int _5977 = NOVALUE;
    int _5976 = NOVALUE;
    int _5975 = NOVALUE;
    int _5974 = NOVALUE;
    int _5972 = NOVALUE;
    int _5970 = NOVALUE;
    int _5969 = NOVALUE;
    int _5965 = NOVALUE;
    int _5959 = NOVALUE;
    int _5957 = NOVALUE;
    int _5951 = NOVALUE;
    int _5949 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(eudir) then*/
    _5949 = IS_SEQUENCE(_13eudir_10664);
    if (_5949 == 0)
    {
        _5949 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _5949 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_13eudir_10664);
    DeRef(_possible_paths_10682);
    DeRefi(_home_10687);
    return _13eudir_10664;
L1: 

    /** 	eudir = getenv("EUDIR")*/
    DeRef(_13eudir_10664);
    _13eudir_10664 = EGetEnv(_5650);

    /** 	if sequence(eudir) then*/
    _5951 = IS_SEQUENCE(_13eudir_10664);
    if (_5951 == 0)
    {
        _5951 = NOVALUE;
        goto L2; // [32] 44
    }
    else{
        _5951 = NOVALUE;
    }

    /** 		return eudir*/
    Ref(_13eudir_10664);
    DeRef(_possible_paths_10682);
    DeRefi(_home_10687);
    return _13eudir_10664;
L2: 

    /** 	ifdef UNIX then*/

    /** 		sequence possible_paths = {*/
    _0 = _possible_paths_10682;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5952);
    *((int *)(_2+4)) = _5952;
    RefDS(_5953);
    *((int *)(_2+8)) = _5953;
    RefDS(_5954);
    *((int *)(_2+12)) = _5954;
    _possible_paths_10682 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		object home = getenv("HOME")*/
    DeRefi(_home_10687);
    _home_10687 = EGetEnv(_5302);

    /** 		if sequence(home) then*/
    _5957 = IS_SEQUENCE(_home_10687);
    if (_5957 == 0)
    {
        _5957 = NOVALUE;
        goto L3; // [64] 78
    }
    else{
        _5957 = NOVALUE;
    }

    /** 			possible_paths = append(possible_paths, home & "/euphoria")*/
    if (IS_SEQUENCE(_home_10687) && IS_ATOM(_5958)) {
    }
    else if (IS_ATOM(_home_10687) && IS_SEQUENCE(_5958)) {
        Ref(_home_10687);
        Prepend(&_5959, _5958, _home_10687);
    }
    else {
        Concat((object_ptr)&_5959, _home_10687, _5958);
    }
    RefDS(_5959);
    Append(&_possible_paths_10682, _possible_paths_10682, _5959);
    DeRefDS(_5959);
    _5959 = NOVALUE;
L3: 

    /** 	for i = 1 to length(possible_paths) do*/
    if (IS_SEQUENCE(_possible_paths_10682)){
            _5965 = SEQ_PTR(_possible_paths_10682)->length;
    }
    else {
        _5965 = 1;
    }
    {
        int _i_10699;
        _i_10699 = 1;
L4: 
        if (_i_10699 > _5965){
            goto L5; // [85] 144
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_10701);
        _2 = (int)SEQ_PTR(_possible_paths_10682);
        _possible_path_10701 = (int)*(((s1_ptr)_2)->base + _i_10699);
        RefDS(_possible_path_10701);

        /** 		if file_exists(possible_path & SLASH & "include" & SLASH & "euphoria.h") then*/
        {
            int concat_list[5];

            concat_list[0] = _5968;
            concat_list[1] = 47;
            concat_list[2] = _5967;
            concat_list[3] = 47;
            concat_list[4] = _possible_path_10701;
            Concat_N((object_ptr)&_5969, concat_list, 5);
        }
        _5970 = _14file_exists(_5969);
        _5969 = NOVALUE;
        if (_5970 == 0) {
            DeRef(_5970);
            _5970 = NOVALUE;
            goto L6; // [118] 135
        }
        else {
            if (!IS_ATOM_INT(_5970) && DBL_PTR(_5970)->dbl == 0.0){
                DeRef(_5970);
                _5970 = NOVALUE;
                goto L6; // [118] 135
            }
            DeRef(_5970);
            _5970 = NOVALUE;
        }
        DeRef(_5970);
        _5970 = NOVALUE;

        /** 			eudir = possible_path*/
        RefDS(_possible_path_10701);
        DeRef(_13eudir_10664);
        _13eudir_10664 = _possible_path_10701;

        /** 			return eudir*/
        RefDS(_13eudir_10664);
        DeRefDS(_possible_path_10701);
        DeRefDS(_possible_paths_10682);
        DeRefi(_home_10687);
        return _13eudir_10664;
L6: 
        DeRef(_possible_path_10701);
        _possible_path_10701 = NOVALUE;

        /** 	end for*/
        _i_10699 = _i_10699 + 1;
        goto L4; // [139] 92
L5: 
        ;
    }

    /** 	possible_paths = include_paths(0)*/
    _0 = _possible_paths_10682;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_5676);
    *((int *)(_2+4)) = _5676;
    RefDS(_5675);
    *((int *)(_2+8)) = _5675;
    RefDS(_5674);
    *((int *)(_2+12)) = _5674;
    _possible_paths_10682 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	for i = 1 to length(possible_paths) do*/
    _5972 = 3;
    {
        int _i_10713;
        _i_10713 = 1;
L7: 
        if (_i_10713 > 3){
            goto L8; // [157] 282
        }

        /** 		sequence possible_path = possible_paths[i]*/
        DeRef(_possible_path_10715);
        _2 = (int)SEQ_PTR(_possible_paths_10682);
        _possible_path_10715 = (int)*(((s1_ptr)_2)->base + _i_10713);
        RefDS(_possible_path_10715);

        /** 		if equal(possible_path[$], SLASH) then*/
        if (IS_SEQUENCE(_possible_path_10715)){
                _5974 = SEQ_PTR(_possible_path_10715)->length;
        }
        else {
            _5974 = 1;
        }
        _2 = (int)SEQ_PTR(_possible_path_10715);
        _5975 = (int)*(((s1_ptr)_2)->base + _5974);
        if (_5975 == 47)
        _5976 = 1;
        else if (IS_ATOM_INT(_5975) && IS_ATOM_INT(47))
        _5976 = 0;
        else
        _5976 = (compare(_5975, 47) == 0);
        _5975 = NOVALUE;
        if (_5976 == 0)
        {
            _5976 = NOVALUE;
            goto L9; // [187] 205
        }
        else{
            _5976 = NOVALUE;
        }

        /** 			possible_path = possible_path[1..$-1]*/
        if (IS_SEQUENCE(_possible_path_10715)){
                _5977 = SEQ_PTR(_possible_path_10715)->length;
        }
        else {
            _5977 = 1;
        }
        _5978 = _5977 - 1;
        _5977 = NOVALUE;
        rhs_slice_target = (object_ptr)&_possible_path_10715;
        RHS_Slice(_possible_path_10715, 1, _5978);
L9: 

        /** 		if not ends("include", possible_path) then*/
        RefDS(_5967);
        RefDS(_possible_path_10715);
        _5980 = _20ends(_5967, _possible_path_10715);
        if (IS_ATOM_INT(_5980)) {
            if (_5980 != 0){
                DeRef(_5980);
                _5980 = NOVALUE;
                goto LA; // [212] 222
            }
        }
        else {
            if (DBL_PTR(_5980)->dbl != 0.0){
                DeRef(_5980);
                _5980 = NOVALUE;
                goto LA; // [212] 222
            }
        }
        DeRef(_5980);
        _5980 = NOVALUE;

        /** 			continue*/
        DeRefDS(_possible_path_10715);
        _possible_path_10715 = NOVALUE;
        DeRef(_file_check_10729);
        _file_check_10729 = NOVALUE;
        goto LB; // [219] 277
LA: 

        /** 		sequence file_check = possible_path*/
        RefDS(_possible_path_10715);
        DeRef(_file_check_10729);
        _file_check_10729 = _possible_path_10715;

        /** 		file_check &= SLASH & "euphoria.h"*/
        Prepend(&_5982, _5968, 47);
        Concat((object_ptr)&_file_check_10729, _file_check_10729, _5982);
        DeRefDS(_5982);
        _5982 = NOVALUE;

        /** 		if file_exists(file_check) then*/
        RefDS(_file_check_10729);
        _5984 = _14file_exists(_file_check_10729);
        if (_5984 == 0) {
            DeRef(_5984);
            _5984 = NOVALUE;
            goto LC; // [247] 273
        }
        else {
            if (!IS_ATOM_INT(_5984) && DBL_PTR(_5984)->dbl == 0.0){
                DeRef(_5984);
                _5984 = NOVALUE;
                goto LC; // [247] 273
            }
            DeRef(_5984);
            _5984 = NOVALUE;
        }
        DeRef(_5984);
        _5984 = NOVALUE;

        /** 			eudir = possible_path[1..$-8] -- strip SLASH & "include"*/
        if (IS_SEQUENCE(_possible_path_10715)){
                _5985 = SEQ_PTR(_possible_path_10715)->length;
        }
        else {
            _5985 = 1;
        }
        _5986 = _5985 - 8;
        _5985 = NOVALUE;
        rhs_slice_target = (object_ptr)&_13eudir_10664;
        RHS_Slice(_possible_path_10715, 1, _5986);

        /** 			return eudir*/
        RefDS(_13eudir_10664);
        DeRefDS(_possible_path_10715);
        DeRefDS(_file_check_10729);
        DeRef(_possible_paths_10682);
        DeRefi(_home_10687);
        DeRef(_5978);
        _5978 = NOVALUE;
        _5986 = NOVALUE;
        return _13eudir_10664;
LC: 
        DeRef(_possible_path_10715);
        _possible_path_10715 = NOVALUE;
        DeRef(_file_check_10729);
        _file_check_10729 = NOVALUE;

        /** 	end for*/
LB: 
        _i_10713 = _i_10713 + 1;
        goto L7; // [277] 164
L8: 
        ;
    }

    /** 	return ""*/
    RefDS(_5);
    DeRef(_possible_paths_10682);
    DeRefi(_home_10687);
    DeRef(_5978);
    _5978 = NOVALUE;
    DeRef(_5986);
    _5986 = NOVALUE;
    return _5;
    ;
}


void _13set_eudir(int _new_eudir_10741)
{
    int _0, _1, _2;
    

    /** 	eudir = new_eudir*/
    RefDS(_new_eudir_10741);
    DeRef(_13eudir_10664);
    _13eudir_10664 = _new_eudir_10741;

    /** 	cmdline_eudir = 1*/
    _13cmdline_eudir_10665 = 1;

    /** end procedure*/
    DeRefDS(_new_eudir_10741);
    return;
    ;
}


int _13is_eudir_from_cmdline()
{
    int _0, _1, _2;
    

    /** 	return cmdline_eudir*/
    return _13cmdline_eudir_10665;
    ;
}



// 0x58871CBA
