// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _3instance()
{
    int _490 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_INSTANCE, 0)*/
    _490 = machine(55, 0);
    return _490;
    ;
}


int _3get_pid()
{
    int _491 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		return machine_func(M_INSTANCE, 0)*/
    _491 = machine(55, 0);
    return _491;
    ;
}


int _3uname()
{
    int _o_1302 = NOVALUE;
    int _518 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		object o = machine_func(M_UNAME, {})*/
    DeRef(_o_1302);
    _o_1302 = machine(76, _5);

    /** 		if atom(o) then*/
    _518 = IS_ATOM(_o_1302);
    if (_518 == 0)
    {
        _518 = NOVALUE;
        goto L1; // [14] 26
    }
    else{
        _518 = NOVALUE;
    }

    /** 			return {}*/
    RefDS(_5);
    DeRef(_o_1302);
    return _5;
    goto L2; // [23] 33
L1: 

    /** 			return o*/
    return _o_1302;
L2: 
    ;
}


int _3is_win_nt()
{
    int _0, _1, _2;
    

    /** 	ifdef WINDOWS then*/

    /** 		return -1*/
    return -1;
    ;
}


int _3setenv(int _name_1312, int _val_1313, int _overwrite_1314)
{
    int _521 = NOVALUE;
    int _520 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_overwrite_1314)) {
        _1 = (long)(DBL_PTR(_overwrite_1314)->dbl);
        DeRefDS(_overwrite_1314);
        _overwrite_1314 = _1;
    }

    /** 	return machine_func(M_SET_ENV, {name, val, overwrite})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_name_1312);
    *((int *)(_2+4)) = _name_1312;
    RefDS(_val_1313);
    *((int *)(_2+8)) = _val_1313;
    *((int *)(_2+12)) = _overwrite_1314;
    _520 = MAKE_SEQ(_1);
    _521 = machine(73, _520);
    DeRefDS(_520);
    _520 = NOVALUE;
    DeRefDS(_name_1312);
    DeRefDS(_val_1313);
    return _521;
    ;
}


int _3unsetenv(int _env_1319)
{
    int _523 = NOVALUE;
    int _522 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_UNSET_ENV, {env})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_env_1319);
    *((int *)(_2+4)) = _env_1319;
    _522 = MAKE_SEQ(_1);
    _523 = machine(74, _522);
    DeRefDS(_522);
    _522 = NOVALUE;
    DeRefDS(_env_1319);
    return _523;
    ;
}


void _3sleep(int _t_1324)
{
    int _0, _1, _2;
    

    /** 	if t >= 0 then*/
    if (binary_op_a(LESS, _t_1324, 0)){
        goto L1; // [3] 13
    }

    /** 		machine_proc(M_SLEEP, t)*/
    machine(64, _t_1324);
L1: 

    /** end procedure*/
    DeRef(_t_1324);
    return;
    ;
}



// 0x7638AAE9
