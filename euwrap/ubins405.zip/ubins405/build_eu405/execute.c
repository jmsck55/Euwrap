// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _67new_arg_assign()
{
    int _0, _1, _2;
    

    /** 	arg_assign += 1*/
    _0 = _67arg_assign_62952;
    if (IS_ATOM_INT(_67arg_assign_62952)) {
        _67arg_assign_62952 = _67arg_assign_62952 + 1;
        if (_67arg_assign_62952 > MAXINT){
            _67arg_assign_62952 = NewDouble((double)_67arg_assign_62952);
        }
    }
    else
    _67arg_assign_62952 = binary_op(PLUS, 1, _67arg_assign_62952);
    DeRef(_0);

    /** 	return arg_assign*/
    Ref(_67arg_assign_62952);
    return _67arg_assign_62952;
    ;
}


void _67open_err_file()
{
    int _31483 = NOVALUE;
    int _0, _1, _2;
    

    /** 	err_file = open(err_file_name, "w")*/
    _67err_file_63057 = EOpen(_67err_file_name_63058, _21935, 0);

    /** 	if err_file = -1 then*/
    if (_67err_file_63057 != -1)
    goto L1; // [14] 36

    /** 		puts(2, "Can't open " & err_file_name & '\n')*/
    {
        int concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_63058;
        concat_list[2] = _31482;
        Concat_N((object_ptr)&_31483, concat_list, 3);
    }
    EPuts(2, _31483); // DJP 
    DeRefDS(_31483);
    _31483 = NOVALUE;

    /** 		abort(1)*/
    UserCleanup(1);
L1: 

    /** end procedure*/
    return;
    ;
}


void _67both_puts(int _s_63071)
{
    int _0, _1, _2;
    

    /** 	if screen_err_out then*/
    if (_67screen_err_out_63068 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		puts(2, s)*/
    EPuts(2, _s_63071); // DJP 
L1: 

    /** 	puts(err_file, s)*/
    EPuts(_67err_file_63057, _s_63071); // DJP 

    /** end procedure*/
    DeRef(_s_63071);
    return;
    ;
}


void _67both_printf(int _format_63075, int _items_63076)
{
    int _0, _1, _2;
    

    /** 	if screen_err_out then*/
    if (_67screen_err_out_63068 == 0)
    {
        goto L1; // [9] 19
    }
    else{
    }

    /** 		printf(2, format, items)*/
    EPrintf(2, _format_63075, _items_63076);
L1: 

    /** 	printf(err_file, format, items)*/
    EPrintf(_67err_file_63057, _format_63075, _items_63076);

    /** end procedure*/
    DeRefDSi(_format_63075);
    DeRefDS(_items_63076);
    return;
    ;
}


int _67find_line(int _sub_63081, int _pc_63082)
{
    int _linetab_63083 = NOVALUE;
    int _line_63084 = NOVALUE;
    int _gline_63085 = NOVALUE;
    int _31507 = NOVALUE;
    int _31506 = NOVALUE;
    int _31505 = NOVALUE;
    int _31504 = NOVALUE;
    int _31503 = NOVALUE;
    int _31502 = NOVALUE;
    int _31500 = NOVALUE;
    int _31499 = NOVALUE;
    int _31498 = NOVALUE;
    int _31496 = NOVALUE;
    int _31495 = NOVALUE;
    int _31494 = NOVALUE;
    int _31493 = NOVALUE;
    int _31491 = NOVALUE;
    int _31490 = NOVALUE;
    int _31488 = NOVALUE;
    int _31487 = NOVALUE;
    int _31486 = NOVALUE;
    int _31484 = NOVALUE;
    int _0, _1, _2;
    

    /** 	linetab = SymTab[sub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31484 = (int)*(((s1_ptr)_2)->base + _sub_63081);
    DeRef(_linetab_63083);
    _2 = (int)SEQ_PTR(_31484);
    if (!IS_ATOM_INT(_12S_LINETAB_11389)){
        _linetab_63083 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    }
    else{
        _linetab_63083 = (int)*(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    }
    Ref(_linetab_63083);
    _31484 = NOVALUE;

    /** 	line = 1*/
    _line_63084 = 1;

    /** 	for i = 1 to length(linetab) do*/
    if (IS_SEQUENCE(_linetab_63083)){
            _31486 = SEQ_PTR(_linetab_63083)->length;
    }
    else {
        _31486 = 1;
    }
    {
        int _i_63091;
        _i_63091 = 1;
L1: 
        if (_i_63091 > _31486){
            goto L2; // [31] 119
        }

        /** 		if linetab[i] >= pc or linetab[i] = -2 then*/
        _2 = (int)SEQ_PTR(_linetab_63083);
        _31487 = (int)*(((s1_ptr)_2)->base + _i_63091);
        if (IS_ATOM_INT(_31487)) {
            _31488 = (_31487 >= _pc_63082);
        }
        else {
            _31488 = binary_op(GREATEREQ, _31487, _pc_63082);
        }
        _31487 = NOVALUE;
        if (IS_ATOM_INT(_31488)) {
            if (_31488 != 0) {
                goto L3; // [48] 65
            }
        }
        else {
            if (DBL_PTR(_31488)->dbl != 0.0) {
                goto L3; // [48] 65
            }
        }
        _2 = (int)SEQ_PTR(_linetab_63083);
        _31490 = (int)*(((s1_ptr)_2)->base + _i_63091);
        if (IS_ATOM_INT(_31490)) {
            _31491 = (_31490 == -2);
        }
        else {
            _31491 = binary_op(EQUALS, _31490, -2);
        }
        _31490 = NOVALUE;
        if (_31491 == 0) {
            DeRef(_31491);
            _31491 = NOVALUE;
            goto L4; // [61] 112
        }
        else {
            if (!IS_ATOM_INT(_31491) && DBL_PTR(_31491)->dbl == 0.0){
                DeRef(_31491);
                _31491 = NOVALUE;
                goto L4; // [61] 112
            }
            DeRef(_31491);
            _31491 = NOVALUE;
        }
        DeRef(_31491);
        _31491 = NOVALUE;
L3: 

        /** 			line = i-1*/
        _line_63084 = _i_63091 - 1;

        /** 			while line > 1 and linetab[line] = -1 do*/
L5: 
        _31493 = (_line_63084 > 1);
        if (_31493 == 0) {
            goto L2; // [80] 119
        }
        _2 = (int)SEQ_PTR(_linetab_63083);
        _31495 = (int)*(((s1_ptr)_2)->base + _line_63084);
        if (IS_ATOM_INT(_31495)) {
            _31496 = (_31495 == -1);
        }
        else {
            _31496 = binary_op(EQUALS, _31495, -1);
        }
        _31495 = NOVALUE;
        if (_31496 <= 0) {
            if (_31496 == 0) {
                DeRef(_31496);
                _31496 = NOVALUE;
                goto L2; // [93] 119
            }
            else {
                if (!IS_ATOM_INT(_31496) && DBL_PTR(_31496)->dbl == 0.0){
                    DeRef(_31496);
                    _31496 = NOVALUE;
                    goto L2; // [93] 119
                }
                DeRef(_31496);
                _31496 = NOVALUE;
            }
        }
        DeRef(_31496);
        _31496 = NOVALUE;

        /** 				line -= 1*/
        _line_63084 = _line_63084 - 1;

        /** 			end while*/
        goto L5; // [104] 76

        /** 			exit*/
        goto L2; // [109] 119
L4: 

        /** 	end for*/
        _i_63091 = _i_63091 + 1;
        goto L1; // [114] 38
L2: 
        ;
    }

    /** 	gline = SymTab[sub][S_FIRSTLINE] + line - 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31498 = (int)*(((s1_ptr)_2)->base + _sub_63081);
    _2 = (int)SEQ_PTR(_31498);
    if (!IS_ATOM_INT(_12S_FIRSTLINE_11394)){
        _31499 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRSTLINE_11394)->dbl));
    }
    else{
        _31499 = (int)*(((s1_ptr)_2)->base + _12S_FIRSTLINE_11394);
    }
    _31498 = NOVALUE;
    if (IS_ATOM_INT(_31499)) {
        _31500 = _31499 + _line_63084;
        if ((long)((unsigned long)_31500 + (unsigned long)HIGH_BITS) >= 0) 
        _31500 = NewDouble((double)_31500);
    }
    else {
        _31500 = binary_op(PLUS, _31499, _line_63084);
    }
    _31499 = NOVALUE;
    if (IS_ATOM_INT(_31500)) {
        _gline_63085 = _31500 - 1;
    }
    else {
        _gline_63085 = binary_op(MINUS, _31500, 1);
    }
    DeRef(_31500);
    _31500 = NOVALUE;
    if (!IS_ATOM_INT(_gline_63085)) {
        _1 = (long)(DBL_PTR(_gline_63085)->dbl);
        DeRefDS(_gline_63085);
        _gline_63085 = _1;
    }

    /** 	return {known_files[slist[gline][LOCAL_FILE_NO]], slist[gline][LINE]}*/
    _2 = (int)SEQ_PTR(_12slist_11773);
    _31502 = (int)*(((s1_ptr)_2)->base + _gline_63085);
    _2 = (int)SEQ_PTR(_31502);
    _31503 = (int)*(((s1_ptr)_2)->base + 3);
    _31502 = NOVALUE;
    _2 = (int)SEQ_PTR(_13known_files_10637);
    if (!IS_ATOM_INT(_31503)){
        _31504 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31503)->dbl));
    }
    else{
        _31504 = (int)*(((s1_ptr)_2)->base + _31503);
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _31505 = (int)*(((s1_ptr)_2)->base + _gline_63085);
    _2 = (int)SEQ_PTR(_31505);
    _31506 = (int)*(((s1_ptr)_2)->base + 2);
    _31505 = NOVALUE;
    Ref(_31506);
    Ref(_31504);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31504;
    ((int *)_2)[2] = _31506;
    _31507 = MAKE_SEQ(_1);
    _31506 = NOVALUE;
    _31504 = NOVALUE;
    DeRef(_linetab_63083);
    DeRef(_31493);
    _31493 = NOVALUE;
    DeRef(_31488);
    _31488 = NOVALUE;
    _31503 = NOVALUE;
    return _31507;
    ;
}


void _67show_var(int _x_63126)
{
    int _31521 = NOVALUE;
    int _31519 = NOVALUE;
    int _31518 = NOVALUE;
    int _31517 = NOVALUE;
    int _31516 = NOVALUE;
    int _31515 = NOVALUE;
    int _31513 = NOVALUE;
    int _31512 = NOVALUE;
    int _31511 = NOVALUE;
    int _31509 = NOVALUE;
    int _31508 = NOVALUE;
    int _0, _1, _2;
    

    /** 	puts(err_file, "    " & SymTab[x][S_NAME] & " = ")*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31508 = (int)*(((s1_ptr)_2)->base + _x_63126);
    _2 = (int)SEQ_PTR(_31508);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _31509 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _31509 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _31508 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _31510;
        concat_list[1] = _31509;
        concat_list[2] = _24751;
        Concat_N((object_ptr)&_31511, concat_list, 3);
    }
    _31509 = NOVALUE;
    EPuts(_67err_file_63057, _31511); // DJP 
    DeRefDS(_31511);
    _31511 = NOVALUE;

    /** 	if equal(val[x], NOVALUE) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _31512 = (int)*(((s1_ptr)_2)->base + _x_63126);
    if (_31512 == _12NOVALUE_11536)
    _31513 = 1;
    else if (IS_ATOM_INT(_31512) && IS_ATOM_INT(_12NOVALUE_11536))
    _31513 = 0;
    else
    _31513 = (compare(_31512, _12NOVALUE_11536) == 0);
    _31512 = NOVALUE;
    if (_31513 == 0)
    {
        _31513 = NOVALUE;
        goto L1; // [42] 55
    }
    else{
        _31513 = NOVALUE;
    }

    /** 		puts(err_file, "<no value>")*/
    EPuts(_67err_file_63057, _31514); // DJP 
    goto L2; // [52] 102
L1: 

    /** 		pretty_print(err_file, val[x],*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _31515 = (int)*(((s1_ptr)_2)->base + _x_63126);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31516 = (int)*(((s1_ptr)_2)->base + _x_63126);
    _2 = (int)SEQ_PTR(_31516);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _31517 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _31517 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _31516 = NOVALUE;
    if (IS_SEQUENCE(_31517)){
            _31518 = SEQ_PTR(_31517)->length;
    }
    else {
        _31518 = 1;
    }
    _31517 = NOVALUE;
    _31519 = _31518 + 7;
    _31518 = NOVALUE;
    _1 = NewS1(9);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 2;
    *((int *)(_2+12)) = _31519;
    *((int *)(_2+16)) = 78;
    RefDS(_22411);
    *((int *)(_2+20)) = _22411;
    RefDS(_31520);
    *((int *)(_2+24)) = _31520;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 500;
    _31521 = MAKE_SEQ(_1);
    _31519 = NOVALUE;
    Ref(_31515);
    _10pretty_print(_67err_file_63057, _31515, _31521);
    _31515 = NOVALUE;
    _31521 = NOVALUE;
L2: 

    /** 	puts(err_file, '\n')*/
    EPuts(_67err_file_63057, 10); // DJP 

    /** end procedure*/
    _31517 = NOVALUE;
    return;
    ;
}


void _67save_private_block(int _rtn_idx_63156, int _block_63157)
{
    int _saved_63158 = NOVALUE;
    int _saved_list_63159 = NOVALUE;
    int _eentry_63160 = NOVALUE;
    int _task_63161 = NOVALUE;
    int _spot_63162 = NOVALUE;
    int _tn_63163 = NOVALUE;
    int _31548 = NOVALUE;
    int _31544 = NOVALUE;
    int _31543 = NOVALUE;
    int _31542 = NOVALUE;
    int _31541 = NOVALUE;
    int _31540 = NOVALUE;
    int _31539 = NOVALUE;
    int _31537 = NOVALUE;
    int _31535 = NOVALUE;
    int _31534 = NOVALUE;
    int _31531 = NOVALUE;
    int _31529 = NOVALUE;
    int _31527 = NOVALUE;
    int _31525 = NOVALUE;
    int _31524 = NOVALUE;
    int _31522 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	task = SymTab[rtn_idx][S_RESIDENT_TASK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31522 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63156);
    _2 = (int)SEQ_PTR(_31522);
    _task_63161 = (int)*(((s1_ptr)_2)->base + 25);
    if (!IS_ATOM_INT(_task_63161)){
        _task_63161 = (long)DBL_PTR(_task_63161)->dbl;
    }
    _31522 = NOVALUE;

    /** 	eentry = {task, tcb[task][TASK_TID], block, 0}*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31524 = (int)*(((s1_ptr)_2)->base + _task_63161);
    _2 = (int)SEQ_PTR(_31524);
    _31525 = (int)*(((s1_ptr)_2)->base + 2);
    _31524 = NOVALUE;
    _0 = _eentry_63160;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _task_63161;
    Ref(_31525);
    *((int *)(_2+8)) = _31525;
    RefDS(_block_63157);
    *((int *)(_2+12)) = _block_63157;
    *((int *)(_2+16)) = 0;
    _eentry_63160 = MAKE_SEQ(_1);
    DeRef(_0);
    _31525 = NOVALUE;

    /** 	saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31527 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63156);
    DeRef(_saved_63158);
    _2 = (int)SEQ_PTR(_31527);
    _saved_63158 = (int)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_63158);
    _31527 = NOVALUE;

    /** 	if length(saved) = 0 then*/
    if (IS_SEQUENCE(_saved_63158)){
            _31529 = SEQ_PTR(_saved_63158)->length;
    }
    else {
        _31529 = 1;
    }
    if (_31529 != 0)
    goto L1; // [61] 78

    /** 		saved = {1, -- index of first item*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_eentry_63160);
    *((int *)(_2+4)) = _eentry_63160;
    _31531 = MAKE_SEQ(_1);
    DeRefDS(_saved_63158);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _31531;
    _saved_63158 = MAKE_SEQ(_1);
    _31531 = NOVALUE;
    goto L2; // [75] 219
L1: 

    /** 		saved_list = saved[2]*/
    DeRef(_saved_list_63159);
    _2 = (int)SEQ_PTR(_saved_63158);
    _saved_list_63159 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_63159);

    /** 		spot = 0*/
    _spot_63162 = 0;

    /** 		for i = 1 to length(saved_list) do*/
    if (IS_SEQUENCE(_saved_list_63159)){
            _31534 = SEQ_PTR(_saved_list_63159)->length;
    }
    else {
        _31534 = 1;
    }
    {
        int _i_63183;
        _i_63183 = 1;
L3: 
        if (_i_63183 > _31534){
            goto L4; // [96] 169
        }

        /** 			tn = saved_list[i][SP_TASK_NUMBER]*/
        _2 = (int)SEQ_PTR(_saved_list_63159);
        _31535 = (int)*(((s1_ptr)_2)->base + _i_63183);
        _2 = (int)SEQ_PTR(_31535);
        _tn_63163 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_tn_63163)){
            _tn_63163 = (long)DBL_PTR(_tn_63163)->dbl;
        }
        _31535 = NOVALUE;

        /** 			if tn = -1 or*/
        _31537 = (_tn_63163 == -1);
        if (_31537 != 0) {
            goto L5; // [121] 152
        }
        _2 = (int)SEQ_PTR(_saved_list_63159);
        _31539 = (int)*(((s1_ptr)_2)->base + _i_63183);
        _2 = (int)SEQ_PTR(_31539);
        _31540 = (int)*(((s1_ptr)_2)->base + 2);
        _31539 = NOVALUE;
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31541 = (int)*(((s1_ptr)_2)->base + _tn_63163);
        _2 = (int)SEQ_PTR(_31541);
        _31542 = (int)*(((s1_ptr)_2)->base + 2);
        _31541 = NOVALUE;
        if (IS_ATOM_INT(_31540) && IS_ATOM_INT(_31542)) {
            _31543 = (_31540 != _31542);
        }
        else {
            _31543 = binary_op(NOTEQ, _31540, _31542);
        }
        _31540 = NOVALUE;
        _31542 = NOVALUE;
        if (_31543 == 0) {
            DeRef(_31543);
            _31543 = NOVALUE;
            goto L6; // [148] 162
        }
        else {
            if (!IS_ATOM_INT(_31543) && DBL_PTR(_31543)->dbl == 0.0){
                DeRef(_31543);
                _31543 = NOVALUE;
                goto L6; // [148] 162
            }
            DeRef(_31543);
            _31543 = NOVALUE;
        }
        DeRef(_31543);
        _31543 = NOVALUE;
L5: 

        /** 				spot = i*/
        _spot_63162 = _i_63183;

        /** 				exit*/
        goto L4; // [159] 169
L6: 

        /** 		end for*/
        _i_63183 = _i_63183 + 1;
        goto L3; // [164] 103
L4: 
        ;
    }

    /** 		eentry[SP_NEXT] = saved[1] -- new eentry points to previous first*/
    _2 = (int)SEQ_PTR(_saved_63158);
    _31544 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_31544);
    _2 = (int)SEQ_PTR(_eentry_63160);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _eentry_63160 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _31544;
    if( _1 != _31544 ){
        DeRef(_1);
    }
    _31544 = NOVALUE;

    /** 		if spot = 0 then*/
    if (_spot_63162 != 0)
    goto L7; // [181] 199

    /** 			saved_list = append(saved_list, eentry)*/
    RefDS(_eentry_63160);
    Append(&_saved_list_63159, _saved_list_63159, _eentry_63160);

    /** 			spot = length(saved_list)*/
    if (IS_SEQUENCE(_saved_list_63159)){
            _spot_63162 = SEQ_PTR(_saved_list_63159)->length;
    }
    else {
        _spot_63162 = 1;
    }
    goto L8; // [196] 206
L7: 

    /** 			saved_list[spot] = eentry*/
    RefDS(_eentry_63160);
    _2 = (int)SEQ_PTR(_saved_list_63159);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63159 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _spot_63162);
    _1 = *(int *)_2;
    *(int *)_2 = _eentry_63160;
    DeRef(_1);
L8: 

    /** 		saved[1] = spot -- it becomes the first on the list*/
    _2 = (int)SEQ_PTR(_saved_63158);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63158 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _spot_63162;
    DeRef(_1);

    /** 		saved[2] = saved_list*/
    RefDS(_saved_list_63159);
    _2 = (int)SEQ_PTR(_saved_63158);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63158 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_list_63159;
    DeRef(_1);
L2: 

    /** 	SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_rtn_idx_63156 + ((s1_ptr)_2)->base);
    RefDS(_saved_63158);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_63158;
    DeRef(_1);
    _31548 = NOVALUE;

    /** end procedure*/
    DeRefDS(_block_63157);
    DeRefDS(_saved_63158);
    DeRef(_saved_list_63159);
    DeRef(_eentry_63160);
    DeRef(_31537);
    _31537 = NOVALUE;
    return;
    ;
}


int _67load_private_block(int _rtn_idx_63208, int _task_63209)
{
    int _saved_63210 = NOVALUE;
    int _saved_list_63211 = NOVALUE;
    int _block_63212 = NOVALUE;
    int _p_63213 = NOVALUE;
    int _prev_p_63214 = NOVALUE;
    int _first_63215 = NOVALUE;
    int _31572 = NOVALUE;
    int _31570 = NOVALUE;
    int _31569 = NOVALUE;
    int _31568 = NOVALUE;
    int _31566 = NOVALUE;
    int _31564 = NOVALUE;
    int _31561 = NOVALUE;
    int _31559 = NOVALUE;
    int _31557 = NOVALUE;
    int _31555 = NOVALUE;
    int _31554 = NOVALUE;
    int _31550 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	saved = SymTab[rtn_idx][S_SAVED_PRIVATES]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31550 = (int)*(((s1_ptr)_2)->base + _rtn_idx_63208);
    DeRef(_saved_63210);
    _2 = (int)SEQ_PTR(_31550);
    _saved_63210 = (int)*(((s1_ptr)_2)->base + 26);
    Ref(_saved_63210);
    _31550 = NOVALUE;

    /** 	first = saved[1]*/
    _2 = (int)SEQ_PTR(_saved_63210);
    _first_63215 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_first_63215))
    _first_63215 = (long)DBL_PTR(_first_63215)->dbl;

    /** 	p = first -- won't be 0*/
    _p_63213 = _first_63215;

    /** 	prev_p = -1*/
    _prev_p_63214 = -1;

    /** 	saved_list = saved[2]*/
    DeRef(_saved_list_63211);
    _2 = (int)SEQ_PTR(_saved_63210);
    _saved_list_63211 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_saved_list_63211);

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_431 == 0)
    {
        goto L2; // [52] 200
    }
    else{
    }

    /** 		if saved_list[p][SP_TASK_NUMBER] = task then*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    _31554 = (int)*(((s1_ptr)_2)->base + _p_63213);
    _2 = (int)SEQ_PTR(_31554);
    _31555 = (int)*(((s1_ptr)_2)->base + 1);
    _31554 = NOVALUE;
    if (binary_op_a(NOTEQ, _31555, _task_63209)){
        _31555 = NOVALUE;
        goto L3; // [65] 178
    }
    _31555 = NOVALUE;

    /** 			block = saved_list[p][SP_BLOCK]*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    _31557 = (int)*(((s1_ptr)_2)->base + _p_63213);
    DeRef(_block_63212);
    _2 = (int)SEQ_PTR(_31557);
    _block_63212 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_block_63212);
    _31557 = NOVALUE;

    /** 			saved_list[p][SP_TASK_NUMBER] = -1 -- mark it as deleted*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63211 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_63213 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _31559 = NOVALUE;

    /** 			saved_list[p][SP_BLOCK] = {}*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63211 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_63213 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _31561 = NOVALUE;

    /** 			if prev_p = -1 then*/
    if (_prev_p_63214 != -1)
    goto L4; // [105] 124

    /** 				first = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    _31564 = (int)*(((s1_ptr)_2)->base + _p_63213);
    _2 = (int)SEQ_PTR(_31564);
    _first_63215 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_first_63215)){
        _first_63215 = (long)DBL_PTR(_first_63215)->dbl;
    }
    _31564 = NOVALUE;
    goto L5; // [121] 144
L4: 

    /** 				saved_list[prev_p][SP_NEXT] = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_list_63211 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_p_63214 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_saved_list_63211);
    _31568 = (int)*(((s1_ptr)_2)->base + _p_63213);
    _2 = (int)SEQ_PTR(_31568);
    _31569 = (int)*(((s1_ptr)_2)->base + 4);
    _31568 = NOVALUE;
    Ref(_31569);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _31569;
    if( _1 != _31569 ){
        DeRef(_1);
    }
    _31569 = NOVALUE;
    _31566 = NOVALUE;
L5: 

    /** 			saved[1] = first*/
    _2 = (int)SEQ_PTR(_saved_63210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63210 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _first_63215;
    DeRef(_1);

    /** 			saved[2] = saved_list*/
    RefDS(_saved_list_63211);
    _2 = (int)SEQ_PTR(_saved_63210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _saved_63210 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_list_63211;
    DeRef(_1);

    /** 			SymTab[rtn_idx][S_SAVED_PRIVATES] = saved*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_rtn_idx_63208 + ((s1_ptr)_2)->base);
    RefDS(_saved_63210);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _saved_63210;
    DeRef(_1);
    _31570 = NOVALUE;

    /** 			return block*/
    DeRefDS(_saved_63210);
    DeRefDS(_saved_list_63211);
    return _block_63212;
L3: 

    /** 		prev_p = p*/
    _prev_p_63214 = _p_63213;

    /** 		p = saved_list[p][SP_NEXT]*/
    _2 = (int)SEQ_PTR(_saved_list_63211);
    _31572 = (int)*(((s1_ptr)_2)->base + _p_63213);
    _2 = (int)SEQ_PTR(_31572);
    _p_63213 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_p_63213)){
        _p_63213 = (long)DBL_PTR(_p_63213)->dbl;
    }
    _31572 = NOVALUE;

    /** 	end while*/
    goto L1; // [197] 50
L2: 
    ;
}


void _67restore_privates(int _this_routine_63252)
{
    int _arg_63254 = NOVALUE;
    int _private_block_63255 = NOVALUE;
    int _base_63256 = NOVALUE;
    int _31639 = NOVALUE;
    int _31637 = NOVALUE;
    int _31635 = NOVALUE;
    int _31632 = NOVALUE;
    int _31630 = NOVALUE;
    int _31628 = NOVALUE;
    int _31626 = NOVALUE;
    int _31625 = NOVALUE;
    int _31624 = NOVALUE;
    int _31623 = NOVALUE;
    int _31622 = NOVALUE;
    int _31621 = NOVALUE;
    int _31620 = NOVALUE;
    int _31619 = NOVALUE;
    int _31618 = NOVALUE;
    int _31617 = NOVALUE;
    int _31616 = NOVALUE;
    int _31615 = NOVALUE;
    int _31614 = NOVALUE;
    int _31613 = NOVALUE;
    int _31612 = NOVALUE;
    int _31610 = NOVALUE;
    int _31607 = NOVALUE;
    int _31605 = NOVALUE;
    int _31602 = NOVALUE;
    int _31600 = NOVALUE;
    int _31598 = NOVALUE;
    int _31596 = NOVALUE;
    int _31595 = NOVALUE;
    int _31594 = NOVALUE;
    int _31593 = NOVALUE;
    int _31592 = NOVALUE;
    int _31591 = NOVALUE;
    int _31590 = NOVALUE;
    int _31589 = NOVALUE;
    int _31588 = NOVALUE;
    int _31587 = NOVALUE;
    int _31586 = NOVALUE;
    int _31585 = NOVALUE;
    int _31584 = NOVALUE;
    int _31583 = NOVALUE;
    int _31582 = NOVALUE;
    int _31580 = NOVALUE;
    int _31578 = NOVALUE;
    int _31577 = NOVALUE;
    int _31575 = NOVALUE;
    int _31574 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_this_routine_63252)) {
        _1 = (long)(DBL_PTR(_this_routine_63252)->dbl);
        DeRefDS(_this_routine_63252);
        _this_routine_63252 = _1;
    }

    /** 	sequence private_block*/

    /** 	integer base*/

    /** 	if SymTab[this_routine][S_RESIDENT_TASK] != current_task then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31574 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31574);
    _31575 = (int)*(((s1_ptr)_2)->base + 25);
    _31574 = NOVALUE;
    if (binary_op_a(EQUALS, _31575, _67current_task_63025)){
        _31575 = NOVALUE;
        goto L1; // [23] 535
    }
    _31575 = NOVALUE;

    /** 		if SymTab[this_routine][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31577 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31577);
    _31578 = (int)*(((s1_ptr)_2)->base + 25);
    _31577 = NOVALUE;
    if (binary_op_a(EQUALS, _31578, 0)){
        _31578 = NOVALUE;
        goto L2; // [41] 274
    }
    _31578 = NOVALUE;

    /** 			arg = SymTab[this_routine][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31580 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31580);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31580 = NOVALUE;

    /** 			private_block = {}*/
    RefDS(_21829);
    DeRef(_private_block_63255);
    _private_block_63255 = _21829;

    /** 			while arg != 0 */
L3: 
    _31582 = (_arg_63254 != 0);
    if (_31582 == 0) {
        goto L4; // [77] 209
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31584 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31584);
    _31585 = (int)*(((s1_ptr)_2)->base + 4);
    _31584 = NOVALUE;
    if (IS_ATOM_INT(_31585)) {
        _31586 = (_31585 <= 3);
    }
    else {
        _31586 = binary_op(LESSEQ, _31585, 3);
    }
    _31585 = NOVALUE;
    if (IS_ATOM_INT(_31586)) {
        if (_31586 != 0) {
            DeRef(_31587);
            _31587 = 1;
            goto L5; // [99] 125
        }
    }
    else {
        if (DBL_PTR(_31586)->dbl != 0.0) {
            DeRef(_31587);
            _31587 = 1;
            goto L5; // [99] 125
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31588 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31588);
    _31589 = (int)*(((s1_ptr)_2)->base + 4);
    _31588 = NOVALUE;
    if (IS_ATOM_INT(_31589)) {
        _31590 = (_31589 == 2);
    }
    else {
        _31590 = binary_op(EQUALS, _31589, 2);
    }
    _31589 = NOVALUE;
    DeRef(_31587);
    if (IS_ATOM_INT(_31590))
    _31587 = (_31590 != 0);
    else
    _31587 = DBL_PTR(_31590)->dbl != 0.0;
L5: 
    if (_31587 != 0) {
        DeRef(_31591);
        _31591 = 1;
        goto L6; // [125] 151
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31592 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31592);
    _31593 = (int)*(((s1_ptr)_2)->base + 4);
    _31592 = NOVALUE;
    if (IS_ATOM_INT(_31593)) {
        _31594 = (_31593 == 9);
    }
    else {
        _31594 = binary_op(EQUALS, _31593, 9);
    }
    _31593 = NOVALUE;
    if (IS_ATOM_INT(_31594))
    _31591 = (_31594 != 0);
    else
    _31591 = DBL_PTR(_31594)->dbl != 0.0;
L6: 
    if (_31591 == 0)
    {
        _31591 = NOVALUE;
        goto L4; // [152] 209
    }
    else{
        _31591 = NOVALUE;
    }

    /** 				if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31595 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31595);
    _31596 = (int)*(((s1_ptr)_2)->base + 4);
    _31595 = NOVALUE;
    if (binary_op_a(EQUALS, _31596, 9)){
        _31596 = NOVALUE;
        goto L7; // [171] 188
    }
    _31596 = NOVALUE;

    /** 					private_block = append(private_block, val[arg])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _31598 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    Ref(_31598);
    Append(&_private_block_63255, _private_block_63255, _31598);
    _31598 = NOVALUE;
L7: 

    /** 				arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31600 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31600);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31600 = NOVALUE;

    /** 			end while*/
    goto L3; // [206] 73
L4: 

    /** 			arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31602 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31602);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _arg_63254 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _arg_63254 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31602 = NOVALUE;

    /** 			while arg != 0 do*/
L8: 
    if (_arg_63254 == 0)
    goto L9; // [230] 267

    /** 				private_block = append(private_block, val[arg])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _31605 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    Ref(_31605);
    Append(&_private_block_63255, _private_block_63255, _31605);
    _31605 = NOVALUE;

    /** 				arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31607 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31607);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31607 = NOVALUE;

    /** 			end while*/
    goto L8; // [264] 230
L9: 

    /** 			save_private_block(this_routine, private_block)*/
    RefDS(_private_block_63255);
    _67save_private_block(_this_routine_63252, _private_block_63255);
L2: 

    /** 		private_block = load_private_block(this_routine, current_task)*/
    _0 = _private_block_63255;
    _private_block_63255 = _67load_private_block(_this_routine_63252, _67current_task_63025);
    DeRef(_0);

    /** 		base = 1*/
    _base_63256 = 1;

    /** 		arg = SymTab[this_routine][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31610 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31610);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31610 = NOVALUE;

    /** 		while arg != 0 */
LA: 
    _31612 = (_arg_63254 != 0);
    if (_31612 == 0) {
        goto LB; // [315] 453
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31614 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31614);
    _31615 = (int)*(((s1_ptr)_2)->base + 4);
    _31614 = NOVALUE;
    if (IS_ATOM_INT(_31615)) {
        _31616 = (_31615 <= 3);
    }
    else {
        _31616 = binary_op(LESSEQ, _31615, 3);
    }
    _31615 = NOVALUE;
    if (IS_ATOM_INT(_31616)) {
        if (_31616 != 0) {
            DeRef(_31617);
            _31617 = 1;
            goto LC; // [337] 363
        }
    }
    else {
        if (DBL_PTR(_31616)->dbl != 0.0) {
            DeRef(_31617);
            _31617 = 1;
            goto LC; // [337] 363
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31618 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31618);
    _31619 = (int)*(((s1_ptr)_2)->base + 4);
    _31618 = NOVALUE;
    if (IS_ATOM_INT(_31619)) {
        _31620 = (_31619 == 2);
    }
    else {
        _31620 = binary_op(EQUALS, _31619, 2);
    }
    _31619 = NOVALUE;
    DeRef(_31617);
    if (IS_ATOM_INT(_31620))
    _31617 = (_31620 != 0);
    else
    _31617 = DBL_PTR(_31620)->dbl != 0.0;
LC: 
    if (_31617 != 0) {
        DeRef(_31621);
        _31621 = 1;
        goto LD; // [363] 389
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31622 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31622);
    _31623 = (int)*(((s1_ptr)_2)->base + 4);
    _31622 = NOVALUE;
    if (IS_ATOM_INT(_31623)) {
        _31624 = (_31623 == 9);
    }
    else {
        _31624 = binary_op(EQUALS, _31623, 9);
    }
    _31623 = NOVALUE;
    if (IS_ATOM_INT(_31624))
    _31621 = (_31624 != 0);
    else
    _31621 = DBL_PTR(_31624)->dbl != 0.0;
LD: 
    if (_31621 == 0)
    {
        _31621 = NOVALUE;
        goto LB; // [390] 453
    }
    else{
        _31621 = NOVALUE;
    }

    /** 			if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31625 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31625);
    _31626 = (int)*(((s1_ptr)_2)->base + 4);
    _31625 = NOVALUE;
    if (binary_op_a(EQUALS, _31626, 9)){
        _31626 = NOVALUE;
        goto LE; // [409] 432
    }
    _31626 = NOVALUE;

    /** 				val[arg] = private_block[base]*/
    _2 = (int)SEQ_PTR(_private_block_63255);
    _31628 = (int)*(((s1_ptr)_2)->base + _base_63256);
    Ref(_31628);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_63254);
    _1 = *(int *)_2;
    *(int *)_2 = _31628;
    if( _1 != _31628 ){
        DeRef(_1);
    }
    _31628 = NOVALUE;

    /** 				base += 1*/
    _base_63256 = _base_63256 + 1;
LE: 

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31630 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31630);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31630 = NOVALUE;

    /** 		end while*/
    goto LA; // [450] 311
LB: 

    /** 		arg = SymTab[this_routine][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31632 = (int)*(((s1_ptr)_2)->base + _this_routine_63252);
    _2 = (int)SEQ_PTR(_31632);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _arg_63254 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _arg_63254 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31632 = NOVALUE;

    /** 		while arg != 0 do*/
LF: 
    if (_arg_63254 == 0)
    goto L10; // [474] 517

    /** 			val[arg] = private_block[base]*/
    _2 = (int)SEQ_PTR(_private_block_63255);
    _31635 = (int)*(((s1_ptr)_2)->base + _base_63256);
    Ref(_31635);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_63254);
    _1 = *(int *)_2;
    *(int *)_2 = _31635;
    if( _1 != _31635 ){
        DeRef(_1);
    }
    _31635 = NOVALUE;

    /** 			base += 1*/
    _base_63256 = _base_63256 + 1;

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31637 = (int)*(((s1_ptr)_2)->base + _arg_63254);
    _2 = (int)SEQ_PTR(_31637);
    _arg_63254 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_63254)){
        _arg_63254 = (long)DBL_PTR(_arg_63254)->dbl;
    }
    _31637 = NOVALUE;

    /** 		end while*/
    goto LF; // [514] 474
L10: 

    /** 		SymTab[this_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_this_routine_63252 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63025;
    DeRef(_1);
    _31639 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_private_block_63255);
    DeRef(_31582);
    _31582 = NOVALUE;
    DeRef(_31612);
    _31612 = NOVALUE;
    DeRef(_31586);
    _31586 = NOVALUE;
    DeRef(_31590);
    _31590 = NOVALUE;
    DeRef(_31594);
    _31594 = NOVALUE;
    DeRef(_31616);
    _31616 = NOVALUE;
    DeRef(_31620);
    _31620 = NOVALUE;
    DeRef(_31624);
    _31624 = NOVALUE;
    return;
    ;
}


void _67trace_back(int _msg_63380)
{
    int _sub_63382 = NOVALUE;
    int _v_63383 = NOVALUE;
    int _levels_63384 = NOVALUE;
    int _prev_file_no_63385 = NOVALUE;
    int _task_63386 = NOVALUE;
    int _dash_count_63387 = NOVALUE;
    int _routine_name_63388 = NOVALUE;
    int _title_63389 = NOVALUE;
    int _show_message_63391 = NOVALUE;
    int _31791 = NOVALUE;
    int _31790 = NOVALUE;
    int _31788 = NOVALUE;
    int _31785 = NOVALUE;
    int _31783 = NOVALUE;
    int _31782 = NOVALUE;
    int _31781 = NOVALUE;
    int _31780 = NOVALUE;
    int _31779 = NOVALUE;
    int _31778 = NOVALUE;
    int _31777 = NOVALUE;
    int _31776 = NOVALUE;
    int _31775 = NOVALUE;
    int _31774 = NOVALUE;
    int _31773 = NOVALUE;
    int _31772 = NOVALUE;
    int _31771 = NOVALUE;
    int _31770 = NOVALUE;
    int _31768 = NOVALUE;
    int _31766 = NOVALUE;
    int _31762 = NOVALUE;
    int _31760 = NOVALUE;
    int _31758 = NOVALUE;
    int _31757 = NOVALUE;
    int _31756 = NOVALUE;
    int _31755 = NOVALUE;
    int _31754 = NOVALUE;
    int _31753 = NOVALUE;
    int _31752 = NOVALUE;
    int _31751 = NOVALUE;
    int _31750 = NOVALUE;
    int _31749 = NOVALUE;
    int _31747 = NOVALUE;
    int _31744 = NOVALUE;
    int _31743 = NOVALUE;
    int _31741 = NOVALUE;
    int _31740 = NOVALUE;
    int _31739 = NOVALUE;
    int _31737 = NOVALUE;
    int _31736 = NOVALUE;
    int _31735 = NOVALUE;
    int _31734 = NOVALUE;
    int _31733 = NOVALUE;
    int _31732 = NOVALUE;
    int _31731 = NOVALUE;
    int _31730 = NOVALUE;
    int _31729 = NOVALUE;
    int _31728 = NOVALUE;
    int _31726 = NOVALUE;
    int _31724 = NOVALUE;
    int _31723 = NOVALUE;
    int _31722 = NOVALUE;
    int _31721 = NOVALUE;
    int _31720 = NOVALUE;
    int _31719 = NOVALUE;
    int _31718 = NOVALUE;
    int _31717 = NOVALUE;
    int _31716 = NOVALUE;
    int _31715 = NOVALUE;
    int _31714 = NOVALUE;
    int _31713 = NOVALUE;
    int _31712 = NOVALUE;
    int _31711 = NOVALUE;
    int _31710 = NOVALUE;
    int _31708 = NOVALUE;
    int _31706 = NOVALUE;
    int _31705 = NOVALUE;
    int _31704 = NOVALUE;
    int _31703 = NOVALUE;
    int _31702 = NOVALUE;
    int _31701 = NOVALUE;
    int _31693 = NOVALUE;
    int _31692 = NOVALUE;
    int _31690 = NOVALUE;
    int _31689 = NOVALUE;
    int _31688 = NOVALUE;
    int _31687 = NOVALUE;
    int _31676 = NOVALUE;
    int _31675 = NOVALUE;
    int _31674 = NOVALUE;
    int _31671 = NOVALUE;
    int _31669 = NOVALUE;
    int _31668 = NOVALUE;
    int _31667 = NOVALUE;
    int _31666 = NOVALUE;
    int _31663 = NOVALUE;
    int _31661 = NOVALUE;
    int _31659 = NOVALUE;
    int _31658 = NOVALUE;
    int _31657 = NOVALUE;
    int _31654 = NOVALUE;
    int _31653 = NOVALUE;
    int _31652 = NOVALUE;
    int _31651 = NOVALUE;
    int _31650 = NOVALUE;
    int _31646 = NOVALUE;
    int _31643 = NOVALUE;
    int _31642 = NOVALUE;
    int _31641 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer levels, prev_file_no, task, dash_count*/

    /** 	sequence routine_name, title*/

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _31641 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _31641 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _31642 = (int)*(((s1_ptr)_2)->base + _31641);
    _31643 = IS_ATOM(_31642);
    _31642 = NOVALUE;
    if (_31643 == 0)
    {
        _31643 = NOVALUE;
        goto L1; // [21] 35
    }
    else{
        _31643 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_12slist_11773);
    _0 = _60s_expand(_12slist_11773);
    DeRefDS(_12slist_11773);
    _12slist_11773 = _0;
L1: 

    /** 	show_message = TRUE*/
    _show_message_63391 = _9TRUE_431;

    /** 	screen_err_out = atom(crash_msg)*/
    _67screen_err_out_63068 = IS_ATOM(_67crash_msg_62934);

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_431 == 0)
    {
        goto L3; // [56] 973
    }
    else{
    }

    /** 		if length(tcb) > 1 then*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _31646 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _31646 = 1;
    }
    if (_31646 <= 1)
    goto L4; // [66] 208

    /** 			if current_task = 1 then*/
    if (_67current_task_63025 != 1)
    goto L5; // [74] 88

    /** 				routine_name = "initial task"*/
    RefDS(_31649);
    DeRef(_routine_name_63388);
    _routine_name_63388 = _31649;
    goto L6; // [85] 127
L5: 

    /** 				routine_name = SymTab[e_routine[1+tcb[current_task][TASK_RID]]][S_NAME]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31650 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31650);
    _31651 = (int)*(((s1_ptr)_2)->base + 1);
    _31650 = NOVALUE;
    if (IS_ATOM_INT(_31651)) {
        _31652 = _31651 + 1;
    }
    else
    _31652 = binary_op(PLUS, 1, _31651);
    _31651 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63056);
    if (!IS_ATOM_INT(_31652)){
        _31653 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_31652)->dbl));
    }
    else{
        _31653 = (int)*(((s1_ptr)_2)->base + _31652);
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31654 = (int)*(((s1_ptr)_2)->base + _31653);
    DeRef(_routine_name_63388);
    _2 = (int)SEQ_PTR(_31654);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _routine_name_63388 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _routine_name_63388 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_routine_name_63388);
    _31654 = NOVALUE;
L6: 

    /** 			title = sprintf(" TASK ID %d: %s ",*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31657 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31657);
    _31658 = (int)*(((s1_ptr)_2)->base + 2);
    _31657 = NOVALUE;
    RefDS(_routine_name_63388);
    Ref(_31658);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _31658;
    ((int *)_2)[2] = _routine_name_63388;
    _31659 = MAKE_SEQ(_1);
    _31658 = NOVALUE;
    DeRefi(_title_63389);
    _title_63389 = EPrintf(-9999999, _31656, _31659);
    DeRefDS(_31659);
    _31659 = NOVALUE;

    /** 			dash_count = 60*/
    _dash_count_63387 = 60;

    /** 			if length(title) < dash_count then*/
    if (IS_SEQUENCE(_title_63389)){
            _31661 = SEQ_PTR(_title_63389)->length;
    }
    else {
        _31661 = 1;
    }
    if (_31661 >= 60)
    goto L7; // [161] 175

    /** 				dash_count = 52 - length(title)*/
    if (IS_SEQUENCE(_title_63389)){
            _31663 = SEQ_PTR(_title_63389)->length;
    }
    else {
        _31663 = 1;
    }
    _dash_count_63387 = 52 - _31663;
    _31663 = NOVALUE;
L7: 

    /** 			if dash_count < 1 then*/
    if (_dash_count_63387 >= 1)
    goto L8; // [177] 187

    /** 				dash_count = 1*/
    _dash_count_63387 = 1;
L8: 

    /** 			both_puts(repeat('-', 22) & title & repeat('-', dash_count) & "\n")*/
    _31666 = Repeat(45, 22);
    _31667 = Repeat(45, _dash_count_63387);
    {
        int concat_list[4];

        concat_list[0] = _21981;
        concat_list[1] = _31667;
        concat_list[2] = _title_63389;
        concat_list[3] = _31666;
        Concat_N((object_ptr)&_31668, concat_list, 4);
    }
    DeRefDS(_31667);
    _31667 = NOVALUE;
    DeRefDS(_31666);
    _31666 = NOVALUE;
    _67both_puts(_31668);
    _31668 = NOVALUE;
L4: 

    /** 		levels = 1*/
    _levels_63384 = 1;

    /** 		while length(call_stack) > 0 do*/
L9: 
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31669 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31669 = 1;
    }
    if (_31669 <= 0)
    goto LA; // [223] 807

    /** 			sub = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31671 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31671 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _sub_63382 = (int)*(((s1_ptr)_2)->base + _31671);
    if (!IS_ATOM_INT(_sub_63382)){
        _sub_63382 = (long)DBL_PTR(_sub_63382)->dbl;
    }

    /** 			if levels = 1 then*/
    if (_levels_63384 != 1)
    goto LB; // [242] 254

    /** 				puts(2, '\n')*/
    EPuts(2, 10); // DJP 
    goto LC; // [251] 283
LB: 

    /** 			elsif sub != call_back_routine and sub != delete_code_routine then*/
    _31674 = (_sub_63382 != _67call_back_routine_62942);
    if (_31674 == 0) {
        goto LD; // [262] 282
    }
    _31676 = (_sub_63382 != _67delete_code_routine_62943);
    if (_31676 == 0)
    {
        DeRef(_31676);
        _31676 = NOVALUE;
        goto LD; // [273] 282
    }
    else{
        DeRef(_31676);
        _31676 = NOVALUE;
    }

    /** 				both_puts("... called from ")*/
    RefDS(_31677);
    _67both_puts(_31677);
LD: 
LC: 

    /** 			if sub = call_back_routine then*/
    if (_sub_63382 != _67call_back_routine_62942)
    goto LE; // [287] 327

    /** 				if crash_count > 0 then*/
    if (_67crash_count_62945 <= 0)
    goto LF; // [295] 311

    /** 					both_puts("^^^ called to handle run-time crash\n")*/
    RefDS(_31680);
    _67both_puts(_31680);

    /** 					exit*/
    goto LA; // [306] 807
    goto L10; // [308] 752
LF: 

    /** 					both_puts("^^^ call-back from ")*/
    RefDS(_31681);
    _67both_puts(_31681);

    /** 					ifdef WINDOWS then*/

    /** 						both_puts("external program\n")*/
    RefDS(_31683);
    _67both_puts(_31683);
    goto L10; // [324] 752
LE: 

    /** 			elsif sub = delete_code_routine then*/
    if (_sub_63382 != _67delete_code_routine_62943)
    goto L11; // [331] 343

    /** 				both_puts("^^^ delete routine\n")*/
    RefDS(_31685);
    _67both_puts(_31685);
    goto L10; // [340] 752
L11: 

    /** 				both_printf("%s:%d", find_line(sub, pc))*/
    _31687 = _67find_line(_sub_63382, _67pc_63008);
    RefDS(_31686);
    _67both_printf(_31686, _31687);
    _31687 = NOVALUE;

    /** 				if not equal(SymTab[sub][S_NAME], "<TopLevel>") then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31688 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31688);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _31689 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _31689 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _31688 = NOVALUE;
    if (_31689 == _24432)
    _31690 = 1;
    else if (IS_ATOM_INT(_31689) && IS_ATOM_INT(_24432))
    _31690 = 0;
    else
    _31690 = (compare(_31689, _24432) == 0);
    _31689 = NOVALUE;
    if (_31690 != 0)
    goto L12; // [374] 462
    _31690 = NOVALUE;

    /** 					switch SymTab[sub][S_TOKEN] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31692 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31692);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _31693 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _31693 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _31692 = NOVALUE;
    if (IS_SEQUENCE(_31693) ){
        goto L13; // [391] 431
    }
    if(!IS_ATOM_INT(_31693)){
        if( (DBL_PTR(_31693)->dbl != (double) ((int) DBL_PTR(_31693)->dbl) ) ){
            goto L13; // [391] 431
        }
        _0 = (int) DBL_PTR(_31693)->dbl;
    }
    else {
        _0 = _31693;
    };
    _31693 = NOVALUE;
    switch ( _0 ){ 

        /** 						case PROC then*/
        case 27:

        /** 							both_puts(" in procedure ")*/
        RefDS(_31696);
        _67both_puts(_31696);
        goto L14; // [405] 439

        /** 						case FUNC then*/
        case 501:

        /** 							both_puts(" in function ")*/
        RefDS(_31697);
        _67both_puts(_31697);
        goto L14; // [416] 439

        /** 						case TYPE then*/
        case 504:

        /** 							both_puts(" in type ")*/
        RefDS(_31698);
        _67both_puts(_31698);
        goto L14; // [427] 439

        /** 						case else*/
        default:
L13: 

        /** 							RTInternal("SymTab[sub][S_TOKEN] is not a routine")*/
        RefDS(_31699);
        _67RTInternal(_31699);
    ;}L14: 

    /** 					both_printf("%s()", {SymTab[sub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31701 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31701);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _31702 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _31702 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _31701 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_31702);
    *((int *)(_2+4)) = _31702;
    _31703 = MAKE_SEQ(_1);
    _31702 = NOVALUE;
    RefDS(_31700);
    _67both_printf(_31700, _31703);
    _31703 = NOVALUE;
L12: 

    /** 				both_puts("\n")*/
    RefDS(_21981);
    _67both_puts(_21981);

    /** 				if show_message then*/
    if (_show_message_63391 == 0)
    {
        goto L15; // [469] 510
    }
    else{
    }

    /** 					if sequence(crash_msg) then*/
    _31704 = IS_SEQUENCE(_67crash_msg_62934);
    if (_31704 == 0)
    {
        _31704 = NOVALUE;
        goto L16; // [479] 493
    }
    else{
        _31704 = NOVALUE;
    }

    /** 						clear_screen()*/
    ClearScreen();

    /** 						puts(2, crash_msg)*/
    EPuts(2, _67crash_msg_62934); // DJP 
L16: 

    /** 					both_puts(msg & " \n")*/
    Concat((object_ptr)&_31705, _msg_63380, _23931);
    _67both_puts(_31705);
    _31705 = NOVALUE;

    /** 					show_message = FALSE*/
    _show_message_63391 = _9FALSE_429;
L15: 

    /** 				if length(call_stack) < 2 then*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31706 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31706 = 1;
    }
    if (_31706 >= 2)
    goto L17; // [517] 531

    /** 					both_puts('\n')*/
    _67both_puts(10);

    /** 					exit*/
    goto LA; // [528] 807
L17: 

    /** 				v = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31708 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31708);
    _v_63383 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63383)){
        _v_63383 = (long)DBL_PTR(_v_63383)->dbl;
    }
    _31708 = NOVALUE;

    /** 				while v != 0 and*/
L18: 
    _31710 = (_v_63383 != 0);
    if (_31710 == 0) {
        goto L19; // [556] 681
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31712 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31712);
    _31713 = (int)*(((s1_ptr)_2)->base + 4);
    _31712 = NOVALUE;
    if (IS_ATOM_INT(_31713)) {
        _31714 = (_31713 == 3);
    }
    else {
        _31714 = binary_op(EQUALS, _31713, 3);
    }
    _31713 = NOVALUE;
    if (IS_ATOM_INT(_31714)) {
        if (_31714 != 0) {
            DeRef(_31715);
            _31715 = 1;
            goto L1A; // [578] 604
        }
    }
    else {
        if (DBL_PTR(_31714)->dbl != 0.0) {
            DeRef(_31715);
            _31715 = 1;
            goto L1A; // [578] 604
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31716 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31716);
    _31717 = (int)*(((s1_ptr)_2)->base + 4);
    _31716 = NOVALUE;
    if (IS_ATOM_INT(_31717)) {
        _31718 = (_31717 == 2);
    }
    else {
        _31718 = binary_op(EQUALS, _31717, 2);
    }
    _31717 = NOVALUE;
    DeRef(_31715);
    if (IS_ATOM_INT(_31718))
    _31715 = (_31718 != 0);
    else
    _31715 = DBL_PTR(_31718)->dbl != 0.0;
L1A: 
    if (_31715 != 0) {
        DeRef(_31719);
        _31719 = 1;
        goto L1B; // [604] 630
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31720 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31720);
    _31721 = (int)*(((s1_ptr)_2)->base + 4);
    _31720 = NOVALUE;
    if (IS_ATOM_INT(_31721)) {
        _31722 = (_31721 == 9);
    }
    else {
        _31722 = binary_op(EQUALS, _31721, 9);
    }
    _31721 = NOVALUE;
    if (IS_ATOM_INT(_31722))
    _31719 = (_31722 != 0);
    else
    _31719 = DBL_PTR(_31722)->dbl != 0.0;
L1B: 
    if (_31719 == 0)
    {
        _31719 = NOVALUE;
        goto L19; // [631] 681
    }
    else{
        _31719 = NOVALUE;
    }

    /** 					if SymTab[v][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31723 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31723);
    _31724 = (int)*(((s1_ptr)_2)->base + 4);
    _31723 = NOVALUE;
    if (binary_op_a(EQUALS, _31724, 9)){
        _31724 = NOVALUE;
        goto L1C; // [650] 660
    }
    _31724 = NOVALUE;

    /** 						show_var(v)*/
    _67show_var(_v_63383);
L1C: 

    /** 					v = SymTab[v][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31726 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31726);
    _v_63383 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63383)){
        _v_63383 = (long)DBL_PTR(_v_63383)->dbl;
    }
    _31726 = NOVALUE;

    /** 				end while*/
    goto L18; // [678] 552
L19: 

    /** 				if length(SymTab[sub][S_SAVED_PRIVATES]) > 0 and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31728 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31728);
    _31729 = (int)*(((s1_ptr)_2)->base + 26);
    _31728 = NOVALUE;
    if (IS_SEQUENCE(_31729)){
            _31730 = SEQ_PTR(_31729)->length;
    }
    else {
        _31730 = 1;
    }
    _31729 = NOVALUE;
    _31731 = (_31730 > 0);
    _31730 = NOVALUE;
    if (_31731 == 0) {
        goto L1D; // [702] 751
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31733 = (int)*(((s1_ptr)_2)->base + _sub_63382);
    _2 = (int)SEQ_PTR(_31733);
    _31734 = (int)*(((s1_ptr)_2)->base + 26);
    _31733 = NOVALUE;
    _2 = (int)SEQ_PTR(_31734);
    _31735 = (int)*(((s1_ptr)_2)->base + 1);
    _31734 = NOVALUE;
    if (IS_ATOM_INT(_31735)) {
        _31736 = (_31735 != 0);
    }
    else {
        _31736 = binary_op(NOTEQ, _31735, 0);
    }
    _31735 = NOVALUE;
    if (_31736 == 0) {
        DeRef(_31736);
        _31736 = NOVALUE;
        goto L1D; // [727] 751
    }
    else {
        if (!IS_ATOM_INT(_31736) && DBL_PTR(_31736)->dbl == 0.0){
            DeRef(_31736);
            _31736 = NOVALUE;
            goto L1D; // [727] 751
        }
        DeRef(_31736);
        _31736 = NOVALUE;
    }
    DeRef(_31736);
    _31736 = NOVALUE;

    /** 					SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_63382 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _31737 = NOVALUE;

    /** 					restore_privates(sub)*/
    _67restore_privates(_sub_63382);
L1D: 
L10: 

    /** 			puts(err_file, '\n')*/
    EPuts(_67err_file_63057, 10); // DJP 

    /** 			pc = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31739 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31739 = 1;
    }
    _31740 = _31739 - 1;
    _31739 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _31741 = (int)*(((s1_ptr)_2)->base + _31740);
    if (IS_ATOM_INT(_31741)) {
        _67pc_63008 = _31741 - 1;
    }
    else {
        _67pc_63008 = binary_op(MINUS, _31741, 1);
    }
    _31741 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }

    /** 			call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31743 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31743 = 1;
    }
    _31744 = _31743 - 2;
    _31743 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63026;
    RHS_Slice(_67call_stack_63026, 1, _31744);

    /** 			levels += 1*/
    _levels_63384 = _levels_63384 + 1;

    /** 		end while*/
    goto L9; // [804] 218
LA: 

    /** 		tcb[current_task][TASK_STATE] = ST_DEAD -- mark as "deleted"*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _31747 = NOVALUE;

    /** 		task = current_task*/
    _task_63386 = _67current_task_63025;

    /** 		for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _31749 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _31749 = 1;
    }
    {
        int _i_63568;
        _i_63568 = 1;
L1E: 
        if (_i_63568 > _31749){
            goto L1F; // [836] 950
        }

        /** 			if tcb[i][TASK_STATE] != ST_DEAD and*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31750 = (int)*(((s1_ptr)_2)->base + _i_63568);
        _2 = (int)SEQ_PTR(_31750);
        _31751 = (int)*(((s1_ptr)_2)->base + 4);
        _31750 = NOVALUE;
        if (IS_ATOM_INT(_31751)) {
            _31752 = (_31751 != 2);
        }
        else {
            _31752 = binary_op(NOTEQ, _31751, 2);
        }
        _31751 = NOVALUE;
        if (IS_ATOM_INT(_31752)) {
            if (_31752 == 0) {
                goto L20; // [859] 943
            }
        }
        else {
            if (DBL_PTR(_31752)->dbl == 0.0) {
                goto L20; // [859] 943
            }
        }
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31754 = (int)*(((s1_ptr)_2)->base + _i_63568);
        _2 = (int)SEQ_PTR(_31754);
        _31755 = (int)*(((s1_ptr)_2)->base + 16);
        _31754 = NOVALUE;
        if (IS_SEQUENCE(_31755)){
                _31756 = SEQ_PTR(_31755)->length;
        }
        else {
            _31756 = 1;
        }
        _31755 = NOVALUE;
        _31757 = (_31756 > 0);
        _31756 = NOVALUE;
        if (_31757 == 0)
        {
            DeRef(_31757);
            _31757 = NOVALUE;
            goto L20; // [881] 943
        }
        else{
            DeRef(_31757);
            _31757 = NOVALUE;
        }

        /** 				current_task = i*/
        _67current_task_63025 = _i_63568;

        /** 				call_stack = tcb[i][TASK_STACK]*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31758 = (int)*(((s1_ptr)_2)->base + _i_63568);
        DeRef(_67call_stack_63026);
        _2 = (int)SEQ_PTR(_31758);
        _67call_stack_63026 = (int)*(((s1_ptr)_2)->base + 16);
        Ref(_67call_stack_63026);
        _31758 = NOVALUE;

        /** 				pc = tcb[i][TASK_PC]*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31760 = (int)*(((s1_ptr)_2)->base + _i_63568);
        _2 = (int)SEQ_PTR(_31760);
        _67pc_63008 = (int)*(((s1_ptr)_2)->base + 14);
        if (!IS_ATOM_INT(_67pc_63008)){
            _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
        }
        _31760 = NOVALUE;

        /** 				Code = tcb[i][TASK_CODE]*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31762 = (int)*(((s1_ptr)_2)->base + _i_63568);
        DeRef(_12Code_11771);
        _2 = (int)SEQ_PTR(_31762);
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + 15);
        Ref(_12Code_11771);
        _31762 = NOVALUE;

        /** 				screen_err_out = FALSE  -- just show offending task on screen*/
        _67screen_err_out_63068 = _9FALSE_429;

        /** 				exit*/
        goto L1F; // [940] 950
L20: 

        /** 		end for*/
        _i_63568 = _i_63568 + 1;
        goto L1E; // [945] 843
L1F: 
        ;
    }

    /** 		if task = current_task then*/
    if (_task_63386 != _67current_task_63025)
    goto L21; // [954] 963

    /** 			exit*/
    goto L3; // [960] 973
L21: 

    /** 		both_puts("\n")*/
    RefDS(_21981);
    _67both_puts(_21981);

    /** 	end while*/
    goto L2; // [970] 54
L3: 

    /** 	puts(2, "\n--> see " & err_file_name & '\n')*/
    {
        int concat_list[3];

        concat_list[0] = 10;
        concat_list[1] = _67err_file_name_63058;
        concat_list[2] = _31765;
        Concat_N((object_ptr)&_31766, concat_list, 3);
    }
    EPuts(2, _31766); // DJP 
    DeRefDS(_31766);
    _31766 = NOVALUE;

    /** 	puts(err_file, "\n\nGlobal & Local Variables\n")*/
    EPuts(_67err_file_63057, _31767); // DJP 

    /** 	prev_file_no = -1*/
    _prev_file_no_63385 = -1;

    /** 	v = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31768 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_31768);
    _v_63383 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63383)){
        _v_63383 = (long)DBL_PTR(_v_63383)->dbl;
    }
    _31768 = NOVALUE;

    /** 	while v do*/
L22: 
    if (_v_63383 == 0)
    {
        goto L23; // [1021] 1188
    }
    else{
    }

    /** 		if SymTab[v][S_TOKEN] = VARIABLE and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31770 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31770);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _31771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _31771 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _31770 = NOVALUE;
    if (IS_ATOM_INT(_31771)) {
        _31772 = (_31771 == -100);
    }
    else {
        _31772 = binary_op(EQUALS, _31771, -100);
    }
    _31771 = NOVALUE;
    if (IS_ATOM_INT(_31772)) {
        if (_31772 == 0) {
            DeRef(_31773);
            _31773 = 0;
            goto L24; // [1044] 1070
        }
    }
    else {
        if (DBL_PTR(_31772)->dbl == 0.0) {
            DeRef(_31773);
            _31773 = 0;
            goto L24; // [1044] 1070
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31774 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31774);
    _31775 = (int)*(((s1_ptr)_2)->base + 3);
    _31774 = NOVALUE;
    if (IS_ATOM_INT(_31775)) {
        _31776 = (_31775 == 1);
    }
    else {
        _31776 = binary_op(EQUALS, _31775, 1);
    }
    _31775 = NOVALUE;
    DeRef(_31773);
    if (IS_ATOM_INT(_31776))
    _31773 = (_31776 != 0);
    else
    _31773 = DBL_PTR(_31776)->dbl != 0.0;
L24: 
    if (_31773 == 0) {
        goto L25; // [1070] 1167
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31778 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31778);
    _31779 = (int)*(((s1_ptr)_2)->base + 4);
    _31778 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 5;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 4;
    _31780 = MAKE_SEQ(_1);
    _31781 = find_from(_31779, _31780, 1);
    _31779 = NOVALUE;
    DeRefDS(_31780);
    _31780 = NOVALUE;
    if (_31781 == 0)
    {
        _31781 = NOVALUE;
        goto L25; // [1104] 1167
    }
    else{
        _31781 = NOVALUE;
    }

    /** 			if SymTab[v][S_FILE_NO] != prev_file_no then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31782 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31782);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _31783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _31783 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _31782 = NOVALUE;
    if (binary_op_a(EQUALS, _31783, _prev_file_no_63385)){
        _31783 = NOVALUE;
        goto L26; // [1121] 1161
    }
    _31783 = NOVALUE;

    /** 				prev_file_no = SymTab[v][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31785 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31785);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _prev_file_no_63385 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _prev_file_no_63385 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_prev_file_no_63385)){
        _prev_file_no_63385 = (long)DBL_PTR(_prev_file_no_63385)->dbl;
    }
    _31785 = NOVALUE;

    /** 				puts(err_file, "\n " & known_files[prev_file_no] & ":\n")*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _31788 = (int)*(((s1_ptr)_2)->base + _prev_file_no_63385);
    {
        int concat_list[3];

        concat_list[0] = _31789;
        concat_list[1] = _31788;
        concat_list[2] = _31787;
        Concat_N((object_ptr)&_31790, concat_list, 3);
    }
    _31788 = NOVALUE;
    EPuts(_67err_file_63057, _31790); // DJP 
    DeRefDS(_31790);
    _31790 = NOVALUE;
L26: 

    /** 			show_var(v)*/
    _67show_var(_v_63383);
L25: 

    /** 		v = SymTab[v][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31791 = (int)*(((s1_ptr)_2)->base + _v_63383);
    _2 = (int)SEQ_PTR(_31791);
    _v_63383 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_v_63383)){
        _v_63383 = (long)DBL_PTR(_v_63383)->dbl;
    }
    _31791 = NOVALUE;

    /** 	end while*/
    goto L22; // [1185] 1021
L23: 

    /** 	puts(err_file, '\n')*/
    EPuts(_67err_file_63057, 10); // DJP 

    /** 	close(err_file)*/
    EClose(_67err_file_63057);

    /** end procedure*/
    DeRefDS(_msg_63380);
    DeRef(_routine_name_63388);
    DeRefi(_title_63389);
    _31653 = NOVALUE;
    DeRef(_31652);
    _31652 = NOVALUE;
    DeRef(_31674);
    _31674 = NOVALUE;
    DeRef(_31710);
    _31710 = NOVALUE;
    _31729 = NOVALUE;
    DeRef(_31714);
    _31714 = NOVALUE;
    DeRef(_31718);
    _31718 = NOVALUE;
    DeRef(_31722);
    _31722 = NOVALUE;
    DeRef(_31731);
    _31731 = NOVALUE;
    DeRef(_31740);
    _31740 = NOVALUE;
    DeRef(_31744);
    _31744 = NOVALUE;
    _31755 = NOVALUE;
    DeRef(_31752);
    _31752 = NOVALUE;
    DeRef(_31772);
    _31772 = NOVALUE;
    DeRef(_31776);
    _31776 = NOVALUE;
    return;
    ;
}


void _67call_crash_routines()
{
    int _quit_63645 = NOVALUE;
    int _31802 = NOVALUE;
    int _31800 = NOVALUE;
    int _31799 = NOVALUE;
    int _31798 = NOVALUE;
    int _31797 = NOVALUE;
    int _31796 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if crash_count > 0 then*/
    if (_67crash_count_62945 <= 0)
    goto L1; // [5] 15

    /** 		return*/
    DeRef(_quit_63645);
    return;
L1: 

    /** 	crash_count += 1*/
    _67crash_count_62945 = _67crash_count_62945 + 1;

    /** 	err_file_name = "ex_crash.err"*/
    RefDS(_31795);
    DeRef(_67err_file_name_63058);
    _67err_file_name_63058 = _31795;

    /** 	for i = length(crash_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_67crash_list_62944)){
            _31796 = SEQ_PTR(_67crash_list_62944)->length;
    }
    else {
        _31796 = 1;
    }
    {
        int _i_63651;
        _i_63651 = _31796;
L2: 
        if (_i_63651 < 1){
            goto L3; // [37] 94
        }

        /** 		quit = call_func(forward_general_callback,*/
        _2 = (int)SEQ_PTR(_67crash_list_62944);
        _31797 = (int)*(((s1_ptr)_2)->base + _i_63651);
        _1 = NewS1(3);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        Ref(_31797);
        *((int *)(_2+8)) = _31797;
        *((int *)(_2+12)) = 1;
        _31798 = MAKE_SEQ(_1);
        _31797 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        _31799 = MAKE_SEQ(_1);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _31798;
        ((int *)_2)[2] = _31799;
        _31800 = MAKE_SEQ(_1);
        _31799 = NOVALUE;
        _31798 = NOVALUE;
        _1 = (int)SEQ_PTR(_31800);
        _2 = (int)((s1_ptr)_1)->base;
        _0 = (int)_00[_67forward_general_callback_63641].addr;
        Ref(*(int *)(_2+4));
        Ref(*(int *)(_2+8));
        _1 = (*(int (*)())_0)(
                            *(int *)(_2+4), 
                            *(int *)(_2+8)
                             );
        DeRef(_quit_63645);
        _quit_63645 = _1;
        DeRefDS(_31800);
        _31800 = NOVALUE;

        /** 		if not equal(quit, 0) then*/
        if (_quit_63645 == 0)
        _31802 = 1;
        else if (IS_ATOM_INT(_quit_63645) && IS_ATOM_INT(0))
        _31802 = 0;
        else
        _31802 = (compare(_quit_63645, 0) == 0);
        if (_31802 != 0)
        goto L4; // [78] 87
        _31802 = NOVALUE;

        /** 			return -- don't call the others*/
        DeRef(_quit_63645);
        return;
L4: 

        /** 	end for*/
        _i_63651 = _i_63651 + -1;
        goto L2; // [89] 44
L3: 
        ;
    }

    /** end procedure*/
    DeRef(_quit_63645);
    return;
    ;
}


void _67quit_after_error()
{
    int _34564 = NOVALUE;
    int _0, _1, _2;
    

    /** 	write_coverage_db()*/
    _34564 = _49write_coverage_db();
    DeRef(_34564);
    _34564 = NOVALUE;

    /** 	ifdef WINDOWS then*/

    /** 	abort(1)*/
    UserCleanup(1);

    /** end procedure*/
    return;
    ;
}


void _67RTFatalType(int _x_63667)
{
    int _msg_63668 = NOVALUE;
    int _v_63669 = NOVALUE;
    int _vname_63670 = NOVALUE;
    int _31836 = NOVALUE;
    int _31832 = NOVALUE;
    int _31831 = NOVALUE;
    int _31830 = NOVALUE;
    int _31829 = NOVALUE;
    int _31827 = NOVALUE;
    int _31826 = NOVALUE;
    int _31825 = NOVALUE;
    int _31824 = NOVALUE;
    int _31822 = NOVALUE;
    int _31821 = NOVALUE;
    int _31819 = NOVALUE;
    int _31818 = NOVALUE;
    int _31817 = NOVALUE;
    int _31815 = NOVALUE;
    int _31813 = NOVALUE;
    int _31809 = NOVALUE;
    int _31807 = NOVALUE;
    int _31806 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_63667)) {
        _1 = (long)(DBL_PTR(_x_63667)->dbl);
        DeRefDS(_x_63667);
        _x_63667 = _1;
    }

    /** 	open_err_file()*/
    _67open_err_file();

    /** 	a = Code[x]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _x_63667);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if length(SymTab[a]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31806 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_31806)){
            _31807 = SEQ_PTR(_31806)->length;
    }
    else {
        _31807 = 1;
    }
    _31806 = NOVALUE;
    if (binary_op_a(LESS, _31807, _12S_NAME_11354)){
        _31807 = NOVALUE;
        goto L1; // [32] 57
    }
    _31807 = NOVALUE;

    /** 		vname = SymTab[a][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _31809 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    DeRef(_vname_63670);
    _2 = (int)SEQ_PTR(_31809);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _vname_63670 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _vname_63670 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_vname_63670);
    _31809 = NOVALUE;
    goto L2; // [54] 65
L1: 

    /** 		vname = "inlined variable"*/
    RefDS(_31811);
    DeRef(_vname_63670);
    _vname_63670 = _31811;
L2: 

    /** 	msg = sprintf("type_check failure, %s is ", {vname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_vname_63670);
    *((int *)(_2+4)) = _vname_63670;
    _31813 = MAKE_SEQ(_1);
    DeRefi(_msg_63668);
    _msg_63668 = EPrintf(-9999999, _31812, _31813);
    DeRefDS(_31813);
    _31813 = NOVALUE;

    /** 	v = sprint(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _31815 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_31815);
    _0 = _v_63669;
    _v_63669 = _18sprint(_31815);
    DeRef(_0);
    _31815 = NOVALUE;

    /** 	if length(v) > 70 - length(vname) then*/
    if (IS_SEQUENCE(_v_63669)){
            _31817 = SEQ_PTR(_v_63669)->length;
    }
    else {
        _31817 = 1;
    }
    if (IS_SEQUENCE(_vname_63670)){
            _31818 = SEQ_PTR(_vname_63670)->length;
    }
    else {
        _31818 = 1;
    }
    _31819 = 70 - _31818;
    _31818 = NOVALUE;
    if (_31817 <= _31819)
    goto L3; // [105] 180

    /** 		v = v[1..70 - length(vname)]*/
    if (IS_SEQUENCE(_vname_63670)){
            _31821 = SEQ_PTR(_vname_63670)->length;
    }
    else {
        _31821 = 1;
    }
    _31822 = 70 - _31821;
    _31821 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_63669;
    RHS_Slice(_v_63669, 1, _31822);

    /** 		while length(v) and not find(v[$], ",}")  do*/
L4: 
    if (IS_SEQUENCE(_v_63669)){
            _31824 = SEQ_PTR(_v_63669)->length;
    }
    else {
        _31824 = 1;
    }
    if (_31824 == 0) {
        goto L5; // [131] 173
    }
    if (IS_SEQUENCE(_v_63669)){
            _31826 = SEQ_PTR(_v_63669)->length;
    }
    else {
        _31826 = 1;
    }
    _2 = (int)SEQ_PTR(_v_63669);
    _31827 = (int)*(((s1_ptr)_2)->base + _31826);
    _31829 = find_from(_31827, _31828, 1);
    _31827 = NOVALUE;
    _31830 = (_31829 == 0);
    _31829 = NOVALUE;
    if (_31830 == 0)
    {
        DeRef(_31830);
        _31830 = NOVALUE;
        goto L5; // [151] 173
    }
    else{
        DeRef(_31830);
        _31830 = NOVALUE;
    }

    /** 			v = v[1..$-1]*/
    if (IS_SEQUENCE(_v_63669)){
            _31831 = SEQ_PTR(_v_63669)->length;
    }
    else {
        _31831 = 1;
    }
    _31832 = _31831 - 1;
    _31831 = NOVALUE;
    rhs_slice_target = (object_ptr)&_v_63669;
    RHS_Slice(_v_63669, 1, _31832);

    /** 		end while*/
    goto L4; // [170] 128
L5: 

    /** 		v = v & " ..."*/
    Concat((object_ptr)&_v_63669, _v_63669, _31834);
L3: 

    /** 	trace_back(msg & v)*/
    Concat((object_ptr)&_31836, _msg_63668, _v_63669);
    _67trace_back(_31836);
    _31836 = NOVALUE;

    /** 	call_crash_routines()*/
    _67call_crash_routines();

    /** 	quit_after_error()*/
    _67quit_after_error();

    /** end procedure*/
    DeRefDSi(_msg_63668);
    DeRefDS(_v_63669);
    DeRef(_vname_63670);
    _31806 = NOVALUE;
    DeRef(_31819);
    _31819 = NOVALUE;
    DeRef(_31822);
    _31822 = NOVALUE;
    DeRef(_31832);
    _31832 = NOVALUE;
    return;
    ;
}


void _67RTFatal(int _msg_63715)
{
    int _0, _1, _2;
    

    /** 	open_err_file()*/
    _67open_err_file();

    /** 	trace_back(msg)*/
    RefDS(_msg_63715);
    _67trace_back(_msg_63715);

    /** 	call_crash_routines()*/
    _67call_crash_routines();

    /** 	quit_after_error()*/
    _67quit_after_error();

    /** end procedure*/
    DeRefDS(_msg_63715);
    return;
    ;
}


void _67RTInternal(int _msg_63718)
{
    int _0, _1, _2;
    

    /** 	machine_proc(67, msg)*/
    machine(67, _msg_63718);

    /** end procedure*/
    DeRefDSi(_msg_63718);
    return;
    ;
}


void _67wait(int _t_63721)
{
    int _t1_63722 = NOVALUE;
    int _t2_63723 = NOVALUE;
    int _31842 = NOVALUE;
    int _31840 = NOVALUE;
    int _0, _1, _2;
    

    /** 	t1 = floor(t)*/
    DeRef(_t1_63722);
    if (IS_ATOM_INT(_t_63721))
    _t1_63722 = e_floor(_t_63721);
    else
    _t1_63722 = unary_op(FLOOR, _t_63721);

    /** 	if t1 >= 1 then*/
    if (binary_op_a(LESS, _t1_63722, 1)){
        goto L1; // [8] 24
    }

    /** 		sleep(t1)*/
    Ref(_t1_63722);
    _3sleep(_t1_63722);

    /** 		t -= t1*/
    _0 = _t_63721;
    if (IS_ATOM_INT(_t_63721) && IS_ATOM_INT(_t1_63722)) {
        _t_63721 = _t_63721 - _t1_63722;
        if ((long)((unsigned long)_t_63721 +(unsigned long) HIGH_BITS) >= 0){
            _t_63721 = NewDouble((double)_t_63721);
        }
    }
    else {
        if (IS_ATOM_INT(_t_63721)) {
            _t_63721 = NewDouble((double)_t_63721 - DBL_PTR(_t1_63722)->dbl);
        }
        else {
            if (IS_ATOM_INT(_t1_63722)) {
                _t_63721 = NewDouble(DBL_PTR(_t_63721)->dbl - (double)_t1_63722);
            }
            else
            _t_63721 = NewDouble(DBL_PTR(_t_63721)->dbl - DBL_PTR(_t1_63722)->dbl);
        }
    }
    DeRef(_0);
L1: 

    /** 	t2 = time() + t*/
    DeRef(_31840);
    _31840 = NewDouble(current_time());
    DeRef(_t2_63723);
    if (IS_ATOM_INT(_t_63721)) {
        _t2_63723 = NewDouble(DBL_PTR(_31840)->dbl + (double)_t_63721);
    }
    else
    _t2_63723 = NewDouble(DBL_PTR(_31840)->dbl + DBL_PTR(_t_63721)->dbl);
    DeRefDS(_31840);
    _31840 = NOVALUE;

    /** 	while time() < t2 do*/
L2: 
    DeRef(_31842);
    _31842 = NewDouble(current_time());
    if (binary_op_a(GREATEREQ, _31842, _t2_63723)){
        DeRefDS(_31842);
        _31842 = NOVALUE;
        goto L3; // [39] 48
    }
    DeRef(_31842);
    _31842 = NOVALUE;

    /** 	end while*/
    goto L2; // [45] 37
L3: 

    /** end procedure*/
    DeRef(_t_63721);
    DeRef(_t1_63722);
    DeRef(_t2_63723);
    return;
    ;
}


void _67scheduler()
{
    int _earliest_time_63739 = NOVALUE;
    int _start_time_63740 = NOVALUE;
    int _now_63741 = NOVALUE;
    int _ts_found_63743 = NOVALUE;
    int _tp_63744 = NOVALUE;
    int _p_63745 = NOVALUE;
    int _earliest_task_63746 = NOVALUE;
    int _31919 = NOVALUE;
    int _31918 = NOVALUE;
    int _31915 = NOVALUE;
    int _31914 = NOVALUE;
    int _31913 = NOVALUE;
    int _31912 = NOVALUE;
    int _31911 = NOVALUE;
    int _31909 = NOVALUE;
    int _31908 = NOVALUE;
    int _31906 = NOVALUE;
    int _31904 = NOVALUE;
    int _31902 = NOVALUE;
    int _31900 = NOVALUE;
    int _31898 = NOVALUE;
    int _31896 = NOVALUE;
    int _31893 = NOVALUE;
    int _31891 = NOVALUE;
    int _31890 = NOVALUE;
    int _31888 = NOVALUE;
    int _31887 = NOVALUE;
    int _31884 = NOVALUE;
    int _31882 = NOVALUE;
    int _31876 = NOVALUE;
    int _31872 = NOVALUE;
    int _31871 = NOVALUE;
    int _31869 = NOVALUE;
    int _31867 = NOVALUE;
    int _31865 = NOVALUE;
    int _31864 = NOVALUE;
    int _31863 = NOVALUE;
    int _31862 = NOVALUE;
    int _31861 = NOVALUE;
    int _31860 = NOVALUE;
    int _31859 = NOVALUE;
    int _31857 = NOVALUE;
    int _31852 = NOVALUE;
    int _31848 = NOVALUE;
    int _31846 = NOVALUE;
    int _31845 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence tp*/

    /** 	integer p, earliest_task*/

    /** 	earliest_task = rt_first*/
    _earliest_task_63746 = _67rt_first_63054;

    /** 	if clock_stopped or earliest_task = 0 then*/
    if (_67clock_stopped_63735 != 0) {
        goto L1; // [16] 29
    }
    _31845 = (_earliest_task_63746 == 0);
    if (_31845 == 0)
    {
        DeRef(_31845);
        _31845 = NOVALUE;
        goto L2; // [25] 42
    }
    else{
        DeRef(_31845);
        _31845 = NOVALUE;
    }
L1: 

    /** 		start_time = 1*/
    DeRef(_start_time_63740);
    _start_time_63740 = 1;

    /** 		now = -1*/
    DeRef(_now_63741);
    _now_63741 = -1;
    goto L3; // [39] 232
L2: 

    /** 		earliest_time = tcb[earliest_task][TASK_MAX_TIME]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31846 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    DeRef(_earliest_time_63739);
    _2 = (int)SEQ_PTR(_31846);
    _earliest_time_63739 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_63739);
    _31846 = NOVALUE;

    /** 		p = tcb[rt_first][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31848 = (int)*(((s1_ptr)_2)->base + _67rt_first_63054);
    _2 = (int)SEQ_PTR(_31848);
    _p_63745 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_63745)){
        _p_63745 = (long)DBL_PTR(_p_63745)->dbl;
    }
    _31848 = NOVALUE;

    /** 		while p != 0 do*/
L4: 
    if (_p_63745 == 0)
    goto L5; // [75] 122

    /** 			tp = tcb[p]*/
    DeRef(_tp_63744);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _tp_63744 = (int)*(((s1_ptr)_2)->base + _p_63745);
    RefDS(_tp_63744);

    /** 			if tp[TASK_MAX_TIME] < earliest_time then*/
    _2 = (int)SEQ_PTR(_tp_63744);
    _31852 = (int)*(((s1_ptr)_2)->base + 9);
    if (binary_op_a(GREATEREQ, _31852, _earliest_time_63739)){
        _31852 = NOVALUE;
        goto L6; // [95] 111
    }
    _31852 = NOVALUE;

    /** 				earliest_task = p*/
    _earliest_task_63746 = _p_63745;

    /** 				earliest_time = tp[TASK_MAX_TIME]*/
    DeRef(_earliest_time_63739);
    _2 = (int)SEQ_PTR(_tp_63744);
    _earliest_time_63739 = (int)*(((s1_ptr)_2)->base + 9);
    Ref(_earliest_time_63739);
L6: 

    /** 			p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_63744);
    _p_63745 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_63745))
    _p_63745 = (long)DBL_PTR(_p_63745)->dbl;

    /** 		end while*/
    goto L4; // [119] 75
L5: 

    /** 		now = time()*/
    DeRef(_now_63741);
    _now_63741 = NewDouble(current_time());

    /** 		start_time = tcb[earliest_task][TASK_MIN_TIME]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31857 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    DeRef(_start_time_63740);
    _2 = (int)SEQ_PTR(_31857);
    _start_time_63740 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_start_time_63740);
    _31857 = NOVALUE;

    /** 		if earliest_task = current_task and*/
    _31859 = (_earliest_task_63746 == _67current_task_63025);
    if (_31859 == 0) {
        goto L7; // [146] 173
    }
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31861 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31861);
    _31862 = (int)*(((s1_ptr)_2)->base + 10);
    _31861 = NOVALUE;
    if (IS_ATOM_INT(_31862)) {
        _31863 = (_31862 > 0);
    }
    else {
        _31863 = binary_op(GREATER, _31862, 0);
    }
    _31862 = NOVALUE;
    if (_31863 == 0) {
        DeRef(_31863);
        _31863 = NOVALUE;
        goto L7; // [167] 173
    }
    else {
        if (!IS_ATOM_INT(_31863) && DBL_PTR(_31863)->dbl == 0.0){
            DeRef(_31863);
            _31863 = NOVALUE;
            goto L7; // [167] 173
        }
        DeRef(_31863);
        _31863 = NOVALUE;
    }
    DeRef(_31863);
    _31863 = NOVALUE;
    goto L8; // [170] 231
L7: 

    /** 			if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31864 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31864);
    _31865 = (int)*(((s1_ptr)_2)->base + 3);
    _31864 = NOVALUE;
    if (binary_op_a(NOTEQ, _31865, 1)){
        _31865 = NOVALUE;
        goto L9; // [187] 207
    }
    _31865 = NOVALUE;

    /** 				tcb[current_task][TASK_RUNS_LEFT] = 0*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _31867 = NOVALUE;
L9: 

    /** 			tcb[earliest_task][TASK_RUNS_LEFT] = tcb[earliest_task][TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_earliest_task_63746 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31871 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    _2 = (int)SEQ_PTR(_31871);
    _31872 = (int)*(((s1_ptr)_2)->base + 11);
    _31871 = NOVALUE;
    Ref(_31872);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _31872;
    if( _1 != _31872 ){
        DeRef(_1);
    }
    _31872 = NOVALUE;
    _31869 = NOVALUE;
L8: 
L3: 

    /** 	if start_time > now then*/
    if (binary_op_a(LESSEQ, _start_time_63740, _now_63741)){
        goto LA; // [238] 416
    }

    /** 		ts_found = FALSE*/
    _ts_found_63743 = _9FALSE_429;

    /** 		p = ts_first*/
    _p_63745 = _67ts_first_63055;

    /** 		while p != 0 do*/
LB: 
    if (_p_63745 == 0)
    goto LC; // [261] 313

    /** 			tp = tcb[p]*/
    DeRef(_tp_63744);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _tp_63744 = (int)*(((s1_ptr)_2)->base + _p_63745);
    RefDS(_tp_63744);

    /** 			if tp[TASK_RUNS_LEFT] > 0 then*/
    _2 = (int)SEQ_PTR(_tp_63744);
    _31876 = (int)*(((s1_ptr)_2)->base + 10);
    if (binary_op_a(LESSEQ, _31876, 0)){
        _31876 = NOVALUE;
        goto LD; // [281] 302
    }
    _31876 = NOVALUE;

    /** 				  earliest_task = p*/
    _earliest_task_63746 = _p_63745;

    /** 				  ts_found = TRUE*/
    _ts_found_63743 = _9TRUE_431;

    /** 				  exit*/
    goto LC; // [299] 313
LD: 

    /** 			p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_63744);
    _p_63745 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_63745))
    _p_63745 = (long)DBL_PTR(_p_63745)->dbl;

    /** 		end while*/
    goto LB; // [310] 261
LC: 

    /** 		if not ts_found then*/
    if (_ts_found_63743 != 0)
    goto LE; // [315] 378

    /** 			p = ts_first*/
    _p_63745 = _67ts_first_63055;

    /** 			while p != 0 do*/
LF: 
    if (_p_63745 == 0)
    goto L10; // [330] 377

    /** 				tp = tcb[p]*/
    DeRef(_tp_63744);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _tp_63744 = (int)*(((s1_ptr)_2)->base + _p_63745);
    RefDS(_tp_63744);

    /** 				earliest_task = p*/
    _earliest_task_63746 = _p_63745;

    /** 				tcb[p][TASK_RUNS_LEFT] = tp[TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_63745 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_tp_63744);
    _31884 = (int)*(((s1_ptr)_2)->base + 11);
    Ref(_31884);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _31884;
    if( _1 != _31884 ){
        DeRef(_1);
    }
    _31884 = NOVALUE;
    _31882 = NOVALUE;

    /** 				p = tp[TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_tp_63744);
    _p_63745 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_63745))
    _p_63745 = (long)DBL_PTR(_p_63745)->dbl;

    /** 			end while*/
    goto LF; // [374] 330
L10: 
LE: 

    /** 		if earliest_task = 0 then*/
    if (_earliest_task_63746 != 0)
    goto L11; // [380] 389

    /** 			abort(0)*/
    UserCleanup(0);
L11: 

    /** 		if tcb[earliest_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31887 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    _2 = (int)SEQ_PTR(_31887);
    _31888 = (int)*(((s1_ptr)_2)->base + 3);
    _31887 = NOVALUE;
    if (binary_op_a(NOTEQ, _31888, 1)){
        _31888 = NOVALUE;
        goto L12; // [401] 415
    }
    _31888 = NOVALUE;

    /** 			wait(start_time - now)*/
    if (IS_ATOM_INT(_start_time_63740) && IS_ATOM_INT(_now_63741)) {
        _31890 = _start_time_63740 - _now_63741;
        if ((long)((unsigned long)_31890 +(unsigned long) HIGH_BITS) >= 0){
            _31890 = NewDouble((double)_31890);
        }
    }
    else {
        if (IS_ATOM_INT(_start_time_63740)) {
            _31890 = NewDouble((double)_start_time_63740 - DBL_PTR(_now_63741)->dbl);
        }
        else {
            if (IS_ATOM_INT(_now_63741)) {
                _31890 = NewDouble(DBL_PTR(_start_time_63740)->dbl - (double)_now_63741);
            }
            else
            _31890 = NewDouble(DBL_PTR(_start_time_63740)->dbl - DBL_PTR(_now_63741)->dbl);
        }
    }
    _67wait(_31890);
    _31890 = NOVALUE;
L12: 
LA: 

    /** 	tcb[earliest_task][TASK_START] = time()*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_earliest_task_63746 + ((s1_ptr)_2)->base);
    DeRef(_31893);
    _31893 = NewDouble(current_time());
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _31893;
    if( _1 != _31893 ){
        DeRef(_1);
    }
    _31893 = NOVALUE;
    _31891 = NOVALUE;

    /** 	if earliest_task = current_task then*/
    if (_earliest_task_63746 != _67current_task_63025)
    goto L13; // [435] 450

    /** 		pc += 1  -- continue with current task*/
    _67pc_63008 = _67pc_63008 + 1;
    goto L14; // [447] 663
L13: 

    /** 		tcb[current_task][TASK_CODE] = Code*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _31896 = NOVALUE;

    /** 		tcb[current_task][TASK_PC] = pc*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _67pc_63008;
    DeRef(_1);
    _31898 = NOVALUE;

    /** 		tcb[current_task][TASK_STACK] = call_stack*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    RefDS(_67call_stack_63026);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _67call_stack_63026;
    DeRef(_1);
    _31900 = NOVALUE;

    /** 		Code = tcb[earliest_task][TASK_CODE]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31902 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    DeRefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(_31902);
    _12Code_11771 = (int)*(((s1_ptr)_2)->base + 15);
    Ref(_12Code_11771);
    _31902 = NOVALUE;

    /** 		pc = tcb[earliest_task][TASK_PC]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31904 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    _2 = (int)SEQ_PTR(_31904);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + 14);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
    _31904 = NOVALUE;

    /** 		call_stack = tcb[earliest_task][TASK_STACK]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31906 = (int)*(((s1_ptr)_2)->base + _earliest_task_63746);
    DeRefDS(_67call_stack_63026);
    _2 = (int)SEQ_PTR(_31906);
    _67call_stack_63026 = (int)*(((s1_ptr)_2)->base + 16);
    Ref(_67call_stack_63026);
    _31906 = NOVALUE;

    /** 		current_task = earliest_task*/
    _67current_task_63025 = _earliest_task_63746;

    /** 		if tcb[current_task][TASK_PC] = 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31908 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31908);
    _31909 = (int)*(((s1_ptr)_2)->base + 14);
    _31908 = NOVALUE;
    if (binary_op_a(NOTEQ, _31909, 0)){
        _31909 = NOVALUE;
        goto L15; // [562] 639
    }
    _31909 = NOVALUE;

    /** 			pc = 1*/
    _67pc_63008 = 1;

    /** 			val[t_id] = tcb[current_task][TASK_RID]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31911 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31911);
    _31912 = (int)*(((s1_ptr)_2)->base + 1);
    _31911 = NOVALUE;
    Ref(_31912);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_62939);
    _1 = *(int *)_2;
    *(int *)_2 = _31912;
    if( _1 != _31912 ){
        DeRef(_1);
    }
    _31912 = NOVALUE;

    /** 			val[t_arglist] = tcb[current_task][TASK_ARGS]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31913 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31913);
    _31914 = (int)*(((s1_ptr)_2)->base + 13);
    _31913 = NOVALUE;
    Ref(_31914);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_62940);
    _1 = *(int *)_2;
    *(int *)_2 = _31914;
    if( _1 != _31914 ){
        DeRef(_1);
    }
    _31914 = NOVALUE;

    /** 			new_arg_assign()*/
    _31915 = _67new_arg_assign();

    /** 			Code = {CALL_PROC, t_id, t_arglist}*/
    _0 = _12Code_11771;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 136;
    *((int *)(_2+8)) = _67t_id_62939;
    *((int *)(_2+12)) = _67t_arglist_62940;
    _12Code_11771 = MAKE_SEQ(_1);
    DeRefDS(_0);
    goto L16; // [636] 662
L15: 

    /** 			pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** 			restore_privates(call_stack[$])*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _31918 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _31918 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _31919 = (int)*(((s1_ptr)_2)->base + _31918);
    Ref(_31919);
    _67restore_privates(_31919);
    _31919 = NOVALUE;
L16: 
L14: 

    /** end procedure*/
    DeRef(_earliest_time_63739);
    DeRef(_start_time_63740);
    DeRef(_now_63741);
    DeRef(_tp_63744);
    DeRef(_31859);
    _31859 = NOVALUE;
    DeRef(_31915);
    _31915 = NOVALUE;
    return;
    ;
}


int _67task_insert(int _first_63849, int _task_63850)
{
    int _31920 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tcb[task][TASK_NEXT] = first*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_63850 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _first_63849;
    DeRef(_1);
    _31920 = NOVALUE;

    /** 	return task*/
    return _task_63850;
    ;
}


int _67task_delete(int _first_63855, int _task_63856)
{
    int _p_63857 = NOVALUE;
    int _prev_p_63858 = NOVALUE;
    int _31931 = NOVALUE;
    int _31930 = NOVALUE;
    int _31929 = NOVALUE;
    int _31927 = NOVALUE;
    int _31926 = NOVALUE;
    int _31925 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	prev_p = -1*/
    _prev_p_63858 = -1;

    /** 	p = first*/
    _p_63857 = _first_63855;

    /** 	while p != 0 do*/
L1: 
    if (_p_63857 == 0)
    goto L2; // [20] 110

    /** 		if p = task then*/
    if (_p_63857 != _task_63856)
    goto L3; // [26] 86

    /** 			if prev_p = -1 then*/
    if (_prev_p_63858 != -1)
    goto L4; // [32] 55

    /** 				return tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31925 = (int)*(((s1_ptr)_2)->base + _p_63857);
    _2 = (int)SEQ_PTR(_31925);
    _31926 = (int)*(((s1_ptr)_2)->base + 12);
    _31925 = NOVALUE;
    Ref(_31926);
    return _31926;
    goto L5; // [52] 85
L4: 

    /** 				tcb[prev_p][TASK_NEXT] = tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_p_63858 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31929 = (int)*(((s1_ptr)_2)->base + _p_63857);
    _2 = (int)SEQ_PTR(_31929);
    _31930 = (int)*(((s1_ptr)_2)->base + 12);
    _31929 = NOVALUE;
    Ref(_31930);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _31930;
    if( _1 != _31930 ){
        DeRef(_1);
    }
    _31930 = NOVALUE;
    _31927 = NOVALUE;

    /** 				return first*/
    _31926 = NOVALUE;
    return _first_63855;
L5: 
L3: 

    /** 		prev_p = p*/
    _prev_p_63858 = _p_63857;

    /** 		p = tcb[p][TASK_NEXT]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31931 = (int)*(((s1_ptr)_2)->base + _p_63857);
    _2 = (int)SEQ_PTR(_31931);
    _p_63857 = (int)*(((s1_ptr)_2)->base + 12);
    if (!IS_ATOM_INT(_p_63857)){
        _p_63857 = (long)DBL_PTR(_p_63857)->dbl;
    }
    _31931 = NOVALUE;

    /** 	end while*/
    goto L1; // [107] 20
L2: 

    /** 	return first*/
    _31926 = NOVALUE;
    return _first_63855;
    ;
}


void _67opTASK_YIELD()
{
    int _now_63876 = NOVALUE;
    int _31981 = NOVALUE;
    int _31980 = NOVALUE;
    int _31979 = NOVALUE;
    int _31977 = NOVALUE;
    int _31976 = NOVALUE;
    int _31975 = NOVALUE;
    int _31974 = NOVALUE;
    int _31972 = NOVALUE;
    int _31971 = NOVALUE;
    int _31970 = NOVALUE;
    int _31969 = NOVALUE;
    int _31967 = NOVALUE;
    int _31966 = NOVALUE;
    int _31965 = NOVALUE;
    int _31964 = NOVALUE;
    int _31962 = NOVALUE;
    int _31961 = NOVALUE;
    int _31960 = NOVALUE;
    int _31958 = NOVALUE;
    int _31955 = NOVALUE;
    int _31954 = NOVALUE;
    int _31953 = NOVALUE;
    int _31952 = NOVALUE;
    int _31951 = NOVALUE;
    int _31950 = NOVALUE;
    int _31949 = NOVALUE;
    int _31948 = NOVALUE;
    int _31947 = NOVALUE;
    int _31944 = NOVALUE;
    int _31943 = NOVALUE;
    int _31942 = NOVALUE;
    int _31941 = NOVALUE;
    int _31939 = NOVALUE;
    int _31937 = NOVALUE;
    int _31936 = NOVALUE;
    int _31934 = NOVALUE;
    int _31933 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if tcb[current_task][TASK_STATE] = ST_ACTIVE then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31933 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31933);
    _31934 = (int)*(((s1_ptr)_2)->base + 4);
    _31933 = NOVALUE;
    if (binary_op_a(NOTEQ, _31934, 0)){
        _31934 = NOVALUE;
        goto L1; // [15] 312
    }
    _31934 = NOVALUE;

    /** 		if tcb[current_task][TASK_RUNS_LEFT] > 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31936 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31936);
    _31937 = (int)*(((s1_ptr)_2)->base + 10);
    _31936 = NOVALUE;
    if (binary_op_a(LESSEQ, _31937, 0)){
        _31937 = NOVALUE;
        goto L2; // [33] 61
    }
    _31937 = NOVALUE;

    /** 			tcb[current_task][TASK_RUNS_LEFT] -= 1*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _31941 = (int)*(((s1_ptr)_2)->base + 10);
    _31939 = NOVALUE;
    if (IS_ATOM_INT(_31941)) {
        _31942 = _31941 - 1;
        if ((long)((unsigned long)_31942 +(unsigned long) HIGH_BITS) >= 0){
            _31942 = NewDouble((double)_31942);
        }
    }
    else {
        _31942 = binary_op(MINUS, _31941, 1);
    }
    _31941 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _31942;
    if( _1 != _31942 ){
        DeRef(_1);
    }
    _31942 = NOVALUE;
    _31939 = NOVALUE;
L2: 

    /** 		if tcb[current_task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31943 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31943);
    _31944 = (int)*(((s1_ptr)_2)->base + 3);
    _31943 = NOVALUE;
    if (binary_op_a(NOTEQ, _31944, 1)){
        _31944 = NOVALUE;
        goto L3; // [75] 311
    }
    _31944 = NOVALUE;

    /** 			now = time()*/
    DeRef(_now_63876);
    _now_63876 = NewDouble(current_time());

    /** 			if tcb[current_task][TASK_RUNS_MAX] > 1 and*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31947 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31947);
    _31948 = (int)*(((s1_ptr)_2)->base + 11);
    _31947 = NOVALUE;
    if (IS_ATOM_INT(_31948)) {
        _31949 = (_31948 > 1);
    }
    else {
        _31949 = binary_op(GREATER, _31948, 1);
    }
    _31948 = NOVALUE;
    if (IS_ATOM_INT(_31949)) {
        if (_31949 == 0) {
            goto L4; // [101] 247
        }
    }
    else {
        if (DBL_PTR(_31949)->dbl == 0.0) {
            goto L4; // [101] 247
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31951 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31951);
    _31952 = (int)*(((s1_ptr)_2)->base + 5);
    _31951 = NOVALUE;
    _31953 = binary_op(EQUALS, _31952, _now_63876);
    _31952 = NOVALUE;
    if (_31953 == 0) {
        DeRef(_31953);
        _31953 = NOVALUE;
        goto L4; // [122] 247
    }
    else {
        if (!IS_ATOM_INT(_31953) && DBL_PTR(_31953)->dbl == 0.0){
            DeRef(_31953);
            _31953 = NOVALUE;
            goto L4; // [122] 247
        }
        DeRef(_31953);
        _31953 = NOVALUE;
    }
    DeRef(_31953);
    _31953 = NOVALUE;

    /** 				if tcb[current_task][TASK_RUNS_LEFT] = 0 then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31954 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31954);
    _31955 = (int)*(((s1_ptr)_2)->base + 10);
    _31954 = NOVALUE;
    if (binary_op_a(NOTEQ, _31955, 0)){
        _31955 = NOVALUE;
        goto L5; // [139] 310
    }
    _31955 = NOVALUE;

    /** 					now += clock_period*/
    _0 = _now_63876;
    if (IS_ATOM_INT(_now_63876)) {
        _now_63876 = NewDouble((double)_now_63876 + DBL_PTR(_67clock_period_63028)->dbl);
    }
    else {
        _now_63876 = NewDouble(DBL_PTR(_now_63876)->dbl + DBL_PTR(_67clock_period_63028)->dbl);
    }
    DeRef(_0);

    /** 					tcb[current_task][TASK_RUNS_LEFT] = tcb[current_task][TASK_RUNS_MAX]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31960 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31960);
    _31961 = (int)*(((s1_ptr)_2)->base + 11);
    _31960 = NOVALUE;
    Ref(_31961);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 10);
    _1 = *(int *)_2;
    *(int *)_2 = _31961;
    if( _1 != _31961 ){
        DeRef(_1);
    }
    _31961 = NOVALUE;
    _31958 = NOVALUE;

    /** 					tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31964 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31964);
    _31965 = (int)*(((s1_ptr)_2)->base + 6);
    _31964 = NOVALUE;
    _31966 = binary_op(PLUS, _now_63876, _31965);
    _31965 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _31966;
    if( _1 != _31966 ){
        DeRef(_1);
    }
    _31966 = NOVALUE;
    _31962 = NOVALUE;

    /** 					tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31969 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31969);
    _31970 = (int)*(((s1_ptr)_2)->base + 7);
    _31969 = NOVALUE;
    _31971 = binary_op(PLUS, _now_63876, _31970);
    _31970 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31971;
    if( _1 != _31971 ){
        DeRef(_1);
    }
    _31971 = NOVALUE;
    _31967 = NOVALUE;
    goto L5; // [240] 310
    goto L5; // [244] 310
L4: 

    /** 				tcb[current_task][TASK_MIN_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31974 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31974);
    _31975 = (int)*(((s1_ptr)_2)->base + 6);
    _31974 = NOVALUE;
    if (IS_ATOM_INT(_now_63876) && IS_ATOM_INT(_31975)) {
        _31976 = _now_63876 + _31975;
        if ((long)((unsigned long)_31976 + (unsigned long)HIGH_BITS) >= 0) 
        _31976 = NewDouble((double)_31976);
    }
    else {
        _31976 = binary_op(PLUS, _now_63876, _31975);
    }
    _31975 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _31976;
    if( _1 != _31976 ){
        DeRef(_1);
    }
    _31976 = NOVALUE;
    _31972 = NOVALUE;

    /** 				tcb[current_task][TASK_MAX_TIME] = now +*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67current_task_63025 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31979 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_31979);
    _31980 = (int)*(((s1_ptr)_2)->base + 7);
    _31979 = NOVALUE;
    if (IS_ATOM_INT(_now_63876) && IS_ATOM_INT(_31980)) {
        _31981 = _now_63876 + _31980;
        if ((long)((unsigned long)_31981 + (unsigned long)HIGH_BITS) >= 0) 
        _31981 = NewDouble((double)_31981);
    }
    else {
        _31981 = binary_op(PLUS, _now_63876, _31980);
    }
    _31980 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _31981;
    if( _1 != _31981 ){
        DeRef(_1);
    }
    _31981 = NOVALUE;
    _31977 = NOVALUE;
L5: 
L3: 
L1: 

    /** 	scheduler()*/
    _67scheduler();

    /** end procedure*/
    DeRef(_now_63876);
    DeRef(_31949);
    _31949 = NOVALUE;
    return;
    ;
}


void _67kill_task(int _task_63935)
{
    int _31987 = NOVALUE;
    int _31983 = NOVALUE;
    int _31982 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _31982 = (int)*(((s1_ptr)_2)->base + _task_63935);
    _2 = (int)SEQ_PTR(_31982);
    _31983 = (int)*(((s1_ptr)_2)->base + 3);
    _31982 = NOVALUE;
    if (binary_op_a(NOTEQ, _31983, 1)){
        _31983 = NOVALUE;
        goto L1; // [15] 33
    }
    _31983 = NOVALUE;

    /** 		rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63054, _task_63935);
    _67rt_first_63054 = _0;
    if (!IS_ATOM_INT(_67rt_first_63054)) {
        _1 = (long)(DBL_PTR(_67rt_first_63054)->dbl);
        DeRefDS(_67rt_first_63054);
        _67rt_first_63054 = _1;
    }
    goto L2; // [30] 45
L1: 

    /** 		ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63055, _task_63935);
    _67ts_first_63055 = _0;
    if (!IS_ATOM_INT(_67ts_first_63055)) {
        _1 = (long)(DBL_PTR(_67ts_first_63055)->dbl);
        DeRefDS(_67ts_first_63055);
        _67ts_first_63055 = _1;
    }
L2: 

    /** 	tcb[task][TASK_STATE] = ST_DEAD*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_63935 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _31987 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


int _67which_task(int _tid_63947)
{
    int _31991 = NOVALUE;
    int _31990 = NOVALUE;
    int _31989 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _31989 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _31989 = 1;
    }
    {
        int _i_63949;
        _i_63949 = 1;
L1: 
        if (_i_63949 > _31989){
            goto L2; // [8] 45
        }

        /** 		if tcb[i][TASK_TID] = tid then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _31990 = (int)*(((s1_ptr)_2)->base + _i_63949);
        _2 = (int)SEQ_PTR(_31990);
        _31991 = (int)*(((s1_ptr)_2)->base + 2);
        _31990 = NOVALUE;
        if (binary_op_a(NOTEQ, _31991, _tid_63947)){
            _31991 = NOVALUE;
            goto L3; // [27] 38
        }
        _31991 = NOVALUE;

        /** 			return i*/
        DeRef(_tid_63947);
        return _i_63949;
L3: 

        /** 	end for*/
        _i_63949 = _i_63949 + 1;
        goto L1; // [40] 15
L2: 
        ;
    }

    /** 	RTFatal("invalid task id")*/
    RefDS(_31993);
    _67RTFatal(_31993);
    ;
}


void _67opTASK_STATUS()
{
    int _r_63958 = NOVALUE;
    int _tid_63959 = NOVALUE;
    int _32007 = NOVALUE;
    int _32006 = NOVALUE;
    int _32004 = NOVALUE;
    int _32003 = NOVALUE;
    int _32001 = NOVALUE;
    int _32000 = NOVALUE;
    int _31999 = NOVALUE;
    int _31996 = NOVALUE;
    int _31994 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _31994 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _31994);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _31996 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _31996);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	tid = val[a]*/
    DeRef(_tid_63959);
    _2 = (int)SEQ_PTR(_67val_63018);
    _tid_63959 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_tid_63959);

    /** 	r = -1*/
    _r_63958 = -1;

    /** 	for t = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _31999 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _31999 = 1;
    }
    {
        int _t_63968;
        _t_63968 = 1;
L1: 
        if (_t_63968 > _31999){
            goto L2; // [55] 137
        }

        /** 		if tcb[t][TASK_TID] = tid then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32000 = (int)*(((s1_ptr)_2)->base + _t_63968);
        _2 = (int)SEQ_PTR(_32000);
        _32001 = (int)*(((s1_ptr)_2)->base + 2);
        _32000 = NOVALUE;
        if (binary_op_a(NOTEQ, _32001, _tid_63959)){
            _32001 = NOVALUE;
            goto L3; // [74] 130
        }
        _32001 = NOVALUE;

        /** 			if tcb[t][TASK_STATE] = ST_ACTIVE then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32003 = (int)*(((s1_ptr)_2)->base + _t_63968);
        _2 = (int)SEQ_PTR(_32003);
        _32004 = (int)*(((s1_ptr)_2)->base + 4);
        _32003 = NOVALUE;
        if (binary_op_a(NOTEQ, _32004, 0)){
            _32004 = NOVALUE;
            goto L4; // [90] 102
        }
        _32004 = NOVALUE;

        /** 				r = 1*/
        _r_63958 = 1;
        goto L2; // [99] 137
L4: 

        /** 			elsif tcb[t][TASK_STATE] = ST_SUSPENDED then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32006 = (int)*(((s1_ptr)_2)->base + _t_63968);
        _2 = (int)SEQ_PTR(_32006);
        _32007 = (int)*(((s1_ptr)_2)->base + 4);
        _32006 = NOVALUE;
        if (binary_op_a(NOTEQ, _32007, 1)){
            _32007 = NOVALUE;
            goto L2; // [114] 137
        }
        _32007 = NOVALUE;

        /** 				r = 0*/
        _r_63958 = 0;

        /** 			exit*/
        goto L2; // [127] 137
L3: 

        /** 	end for*/
        _t_63968 = _t_63968 + 1;
        goto L1; // [132] 62
L2: 
        ;
    }

    /** 	val[target] = r*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _r_63958;
    DeRef(_1);

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_tid_63959);
    DeRef(_31994);
    _31994 = NOVALUE;
    DeRef(_31996);
    _31996 = NOVALUE;
    return;
    ;
}


void _67opTASK_LIST()
{
    int _list_63985 = NOVALUE;
    int _32017 = NOVALUE;
    int _32016 = NOVALUE;
    int _32014 = NOVALUE;
    int _32013 = NOVALUE;
    int _32012 = NOVALUE;
    int _32010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _32010 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32010);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	list = {}*/
    RefDS(_21829);
    DeRef(_list_63985);
    _list_63985 = _21829;

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _32012 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _32012 = 1;
    }
    {
        int _i_63990;
        _i_63990 = 1;
L1: 
        if (_i_63990 > _32012){
            goto L2; // [31] 78
        }

        /** 		if tcb[i][TASK_STATE] != ST_DEAD then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32013 = (int)*(((s1_ptr)_2)->base + _i_63990);
        _2 = (int)SEQ_PTR(_32013);
        _32014 = (int)*(((s1_ptr)_2)->base + 4);
        _32013 = NOVALUE;
        if (binary_op_a(EQUALS, _32014, 2)){
            _32014 = NOVALUE;
            goto L3; // [50] 71
        }
        _32014 = NOVALUE;

        /** 			list = append(list, tcb[i][TASK_TID])*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32016 = (int)*(((s1_ptr)_2)->base + _i_63990);
        _2 = (int)SEQ_PTR(_32016);
        _32017 = (int)*(((s1_ptr)_2)->base + 2);
        _32016 = NOVALUE;
        Ref(_32017);
        Append(&_list_63985, _list_63985, _32017);
        _32017 = NOVALUE;
L3: 

        /** 	end for*/
        _i_63990 = _i_63990 + 1;
        goto L1; // [73] 38
L2: 
        ;
    }

    /** 	val[target] = list*/
    RefDS(_list_63985);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _list_63985;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRefDS(_list_63985);
    DeRef(_32010);
    _32010 = NOVALUE;
    return;
    ;
}


void _67opTASK_SELF()
{
    int _32023 = NOVALUE;
    int _32022 = NOVALUE;
    int _32020 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _32020 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32020);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = tcb[current_task][TASK_TID]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32022 = (int)*(((s1_ptr)_2)->base + _67current_task_63025);
    _2 = (int)SEQ_PTR(_32022);
    _32023 = (int)*(((s1_ptr)_2)->base + 2);
    _32022 = NOVALUE;
    Ref(_32023);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32023;
    if( _1 != _32023 ){
        DeRef(_1);
    }
    _32023 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _32020 = NOVALUE;
    return;
    ;
}


void _67opTASK_CLOCK_STOP()
{
    int _0, _1, _2;
    

    /** 	if not clock_stopped then*/
    if (_67clock_stopped_63735 != 0)
    goto L1; // [5] 20

    /** 		save_clock = time()*/
    DeRef(_67save_clock_64008);
    _67save_clock_64008 = NewDouble(current_time());

    /** 		clock_stopped = TRUE*/
    _67clock_stopped_63735 = _9TRUE_431;
L1: 

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** end procedure*/
    return;
    ;
}


void _67opTASK_CLOCK_START()
{
    int _shift_64018 = NOVALUE;
    int _32042 = NOVALUE;
    int _32041 = NOVALUE;
    int _32039 = NOVALUE;
    int _32038 = NOVALUE;
    int _32037 = NOVALUE;
    int _32035 = NOVALUE;
    int _32034 = NOVALUE;
    int _32032 = NOVALUE;
    int _32031 = NOVALUE;
    int _32030 = NOVALUE;
    int _32029 = NOVALUE;
    int _32028 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if clock_stopped then*/
    if (_67clock_stopped_63735 == 0)
    {
        goto L1; // [5] 114
    }
    else{
    }

    /** 		if save_clock >= 0 and save_clock < time() then*/
    if (IS_ATOM_INT(_67save_clock_64008)) {
        _32028 = (_67save_clock_64008 >= 0);
    }
    else {
        _32028 = (DBL_PTR(_67save_clock_64008)->dbl >= (double)0);
    }
    if (_32028 == 0) {
        goto L2; // [16] 106
    }
    _32030 = NewDouble(current_time());
    if (IS_ATOM_INT(_67save_clock_64008)) {
        _32031 = ((double)_67save_clock_64008 < DBL_PTR(_32030)->dbl);
    }
    else {
        _32031 = (DBL_PTR(_67save_clock_64008)->dbl < DBL_PTR(_32030)->dbl);
    }
    DeRefDS(_32030);
    _32030 = NOVALUE;
    if (_32031 == 0)
    {
        DeRef(_32031);
        _32031 = NOVALUE;
        goto L2; // [29] 106
    }
    else{
        DeRef(_32031);
        _32031 = NOVALUE;
    }

    /** 			shift = time() - save_clock*/
    DeRef(_32032);
    _32032 = NewDouble(current_time());
    DeRef(_shift_64018);
    if (IS_ATOM_INT(_67save_clock_64008)) {
        _shift_64018 = NewDouble(DBL_PTR(_32032)->dbl - (double)_67save_clock_64008);
    }
    else
    _shift_64018 = NewDouble(DBL_PTR(_32032)->dbl - DBL_PTR(_67save_clock_64008)->dbl);
    DeRefDS(_32032);
    _32032 = NOVALUE;

    /** 			for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _32034 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _32034 = 1;
    }
    {
        int _i_64028;
        _i_64028 = 1;
L3: 
        if (_i_64028 > _32034){
            goto L4; // [49] 105
        }

        /** 				tcb[i][TASK_MIN_TIME] += shift*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67tcb_63051 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_64028 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _32037 = (int)*(((s1_ptr)_2)->base + 8);
        _32035 = NOVALUE;
        if (IS_ATOM_INT(_32037) && IS_ATOM_INT(_shift_64018)) {
            _32038 = _32037 + _shift_64018;
            if ((long)((unsigned long)_32038 + (unsigned long)HIGH_BITS) >= 0) 
            _32038 = NewDouble((double)_32038);
        }
        else {
            _32038 = binary_op(PLUS, _32037, _shift_64018);
        }
        _32037 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 8);
        _1 = *(int *)_2;
        *(int *)_2 = _32038;
        if( _1 != _32038 ){
            DeRef(_1);
        }
        _32038 = NOVALUE;
        _32035 = NOVALUE;

        /** 				tcb[i][TASK_MAX_TIME] += shift*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _67tcb_63051 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_64028 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _32041 = (int)*(((s1_ptr)_2)->base + 9);
        _32039 = NOVALUE;
        if (IS_ATOM_INT(_32041) && IS_ATOM_INT(_shift_64018)) {
            _32042 = _32041 + _shift_64018;
            if ((long)((unsigned long)_32042 + (unsigned long)HIGH_BITS) >= 0) 
            _32042 = NewDouble((double)_32042);
        }
        else {
            _32042 = binary_op(PLUS, _32041, _shift_64018);
        }
        _32041 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _32042;
        if( _1 != _32042 ){
            DeRef(_1);
        }
        _32042 = NOVALUE;
        _32039 = NOVALUE;

        /** 			end for*/
        _i_64028 = _i_64028 + 1;
        goto L3; // [100] 56
L4: 
        ;
    }
L2: 

    /** 		clock_stopped = FALSE*/
    _67clock_stopped_63735 = _9FALSE_429;
L1: 

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** end procedure*/
    DeRef(_shift_64018);
    DeRef(_32028);
    _32028 = NOVALUE;
    return;
    ;
}


void _67opTASK_SUSPEND()
{
    int _task_64042 = NOVALUE;
    int _32053 = NOVALUE;
    int _32052 = NOVALUE;
    int _32050 = NOVALUE;
    int _32048 = NOVALUE;
    int _32046 = NOVALUE;
    int _32044 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]*/
    _32044 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32044);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	task = which_task(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32046 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_32046);
    _task_64042 = _67which_task(_32046);
    _32046 = NOVALUE;
    if (!IS_ATOM_INT(_task_64042)) {
        _1 = (long)(DBL_PTR(_task_64042)->dbl);
        DeRefDS(_task_64042);
        _task_64042 = _1;
    }

    /** 	tcb[task][TASK_STATE] = ST_SUSPENDED*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32048 = NOVALUE;

    /** 	tcb[task][TASK_MAX_TIME] = TASK_NEVER*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64042 + ((s1_ptr)_2)->base);
    RefDS(_67TASK_NEVER_63019);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _67TASK_NEVER_63019;
    DeRef(_1);
    _32050 = NOVALUE;

    /** 	if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32052 = (int)*(((s1_ptr)_2)->base + _task_64042);
    _2 = (int)SEQ_PTR(_32052);
    _32053 = (int)*(((s1_ptr)_2)->base + 3);
    _32052 = NOVALUE;
    if (binary_op_a(NOTEQ, _32053, 1)){
        _32053 = NOVALUE;
        goto L1; // [71] 89
    }
    _32053 = NOVALUE;

    /** 		rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63054, _task_64042);
    _67rt_first_63054 = _0;
    if (!IS_ATOM_INT(_67rt_first_63054)) {
        _1 = (long)(DBL_PTR(_67rt_first_63054)->dbl);
        DeRefDS(_67rt_first_63054);
        _67rt_first_63054 = _1;
    }
    goto L2; // [86] 101
L1: 

    /** 		ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63055, _task_64042);
    _67ts_first_63055 = _0;
    if (!IS_ATOM_INT(_67ts_first_63055)) {
        _1 = (long)(DBL_PTR(_67ts_first_63055)->dbl);
        DeRefDS(_67ts_first_63055);
        _67ts_first_63055 = _1;
    }
L2: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_32044);
    _32044 = NOVALUE;
    return;
    ;
}


void _67opTASK_CREATE()
{
    int _sub_64063 = NOVALUE;
    int _new_entry_64064 = NOVALUE;
    int _recycle_64066 = NOVALUE;
    int _32093 = NOVALUE;
    int _32092 = NOVALUE;
    int _32091 = NOVALUE;
    int _32089 = NOVALUE;
    int _32088 = NOVALUE;
    int _32087 = NOVALUE;
    int _32085 = NOVALUE;
    int _32081 = NOVALUE;
    int _32080 = NOVALUE;
    int _32079 = NOVALUE;
    int _32077 = NOVALUE;
    int _32076 = NOVALUE;
    int _32074 = NOVALUE;
    int _32071 = NOVALUE;
    int _32070 = NOVALUE;
    int _32068 = NOVALUE;
    int _32067 = NOVALUE;
    int _32065 = NOVALUE;
    int _32064 = NOVALUE;
    int _32063 = NOVALUE;
    int _32061 = NOVALUE;
    int _32060 = NOVALUE;
    int _32058 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry*/

    /** 	a = Code[pc+1] -- routine id*/
    _32058 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32058);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32060 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32060)) {
        _32061 = (_32060 < 0);
    }
    else {
        _32061 = binary_op(LESS, _32060, 0);
    }
    _32060 = NOVALUE;
    if (IS_ATOM_INT(_32061)) {
        if (_32061 != 0) {
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_32061)->dbl != 0.0) {
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_67val_63018);
    _32063 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_67e_routine_63056)){
            _32064 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _32064 = 1;
    }
    if (IS_ATOM_INT(_32063)) {
        _32065 = (_32063 >= _32064);
    }
    else {
        _32065 = binary_op(GREATEREQ, _32063, _32064);
    }
    _32063 = NOVALUE;
    _32064 = NOVALUE;
    if (_32065 == 0) {
        DeRef(_32065);
        _32065 = NOVALUE;
        goto L2; // [55] 65
    }
    else {
        if (!IS_ATOM_INT(_32065) && DBL_PTR(_32065)->dbl == 0.0){
            DeRef(_32065);
            _32065 = NOVALUE;
            goto L2; // [55] 65
        }
        DeRef(_32065);
        _32065 = NOVALUE;
    }
    DeRef(_32065);
    _32065 = NOVALUE;
L1: 

    /** 		RTFatal("invalid routine id")*/
    RefDS(_32066);
    _67RTFatal(_32066);
L2: 

    /** 	sub = e_routine[val[a]+1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32067 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32067)) {
        _32068 = _32067 + 1;
    }
    else
    _32068 = binary_op(PLUS, 1, _32067);
    _32067 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63056);
    if (!IS_ATOM_INT(_32068)){
        _sub_64063 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32068)->dbl));
    }
    else{
        _sub_64063 = (int)*(((s1_ptr)_2)->base + _32068);
    }

    /** 	if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32070 = (int)*(((s1_ptr)_2)->base + _sub_64063);
    _2 = (int)SEQ_PTR(_32070);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _32071 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _32071 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _32070 = NOVALUE;
    if (binary_op_a(EQUALS, _32071, 27)){
        _32071 = NOVALUE;
        goto L3; // [103] 113
    }
    _32071 = NOVALUE;

    /** 		RTFatal("specify the routine id of a procedure, not a function or type")*/
    RefDS(_32073);
    _67RTFatal(_32073);
L3: 

    /** 	b = Code[pc+2] -- args*/
    _32074 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32074);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	new_entry = {val[a], next_task_id, T_REAL_TIME, ST_SUSPENDED, 0,*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32076 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32077 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _0 = _new_entry_64064;
    _1 = NewS1(16);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_32076);
    *((int *)(_2+4)) = _32076;
    Ref(_67next_task_id_63027);
    *((int *)(_2+8)) = _67next_task_id_63027;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    *((int *)(_2+28)) = 0;
    *((int *)(_2+32)) = 0;
    RefDS(_67TASK_NEVER_63019);
    *((int *)(_2+36)) = _67TASK_NEVER_63019;
    *((int *)(_2+40)) = 1;
    *((int *)(_2+44)) = 1;
    *((int *)(_2+48)) = 0;
    Ref(_32077);
    *((int *)(_2+52)) = _32077;
    *((int *)(_2+56)) = 0;
    RefDSn(_21829, 2);
    *((int *)(_2+60)) = _21829;
    *((int *)(_2+64)) = _21829;
    _new_entry_64064 = MAKE_SEQ(_1);
    DeRef(_0);
    _32077 = NOVALUE;
    _32076 = NOVALUE;

    /** 	recycle = FALSE*/
    _recycle_64066 = _9FALSE_429;

    /** 	for i = 1 to length(tcb) do*/
    if (IS_SEQUENCE(_67tcb_63051)){
            _32079 = SEQ_PTR(_67tcb_63051)->length;
    }
    else {
        _32079 = 1;
    }
    {
        int _i_64097;
        _i_64097 = 1;
L4: 
        if (_i_64097 > _32079){
            goto L5; // [182] 232
        }

        /** 		if tcb[i][TASK_STATE] = ST_DEAD then*/
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _32080 = (int)*(((s1_ptr)_2)->base + _i_64097);
        _2 = (int)SEQ_PTR(_32080);
        _32081 = (int)*(((s1_ptr)_2)->base + 4);
        _32080 = NOVALUE;
        if (binary_op_a(NOTEQ, _32081, 2)){
            _32081 = NOVALUE;
            goto L6; // [201] 225
        }
        _32081 = NOVALUE;

        /** 			tcb[i] = new_entry*/
        RefDS(_new_entry_64064);
        _2 = (int)SEQ_PTR(_67tcb_63051);
        _2 = (int)(((s1_ptr)_2)->base + _i_64097);
        _1 = *(int *)_2;
        *(int *)_2 = _new_entry_64064;
        DeRefDS(_1);

        /** 			recycle = TRUE*/
        _recycle_64066 = _9TRUE_431;

        /** 			exit*/
        goto L5; // [222] 232
L6: 

        /** 	end for*/
        _i_64097 = _i_64097 + 1;
        goto L4; // [227] 189
L5: 
        ;
    }

    /** 	if not recycle then*/
    if (_recycle_64066 != 0)
    goto L7; // [234] 246

    /** 		tcb = append(tcb, new_entry)*/
    RefDS(_new_entry_64064);
    Append(&_67tcb_63051, _67tcb_63051, _new_entry_64064);
L7: 

    /** 	target = Code[pc+3]*/
    _32085 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32085);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = next_task_id*/
    Ref(_67next_task_id_63027);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _67next_task_id_63027;
    DeRef(_1);

    /** 	if not id_wrap and next_task_id < TASK_ID_MAX then*/
    _32087 = (_67id_wrap_63023 == 0);
    if (_32087 == 0) {
        goto L8; // [281] 306
    }
    if (IS_ATOM_INT(_67next_task_id_63027)) {
        _32089 = ((double)_67next_task_id_63027 < DBL_PTR(_67TASK_ID_MAX_63020)->dbl);
    }
    else {
        _32089 = (DBL_PTR(_67next_task_id_63027)->dbl < DBL_PTR(_67TASK_ID_MAX_63020)->dbl);
    }
    if (_32089 == 0)
    {
        DeRef(_32089);
        _32089 = NOVALUE;
        goto L8; // [292] 306
    }
    else{
        DeRef(_32089);
        _32089 = NOVALUE;
    }

    /** 		next_task_id += 1*/
    _0 = _67next_task_id_63027;
    if (IS_ATOM_INT(_67next_task_id_63027)) {
        _67next_task_id_63027 = _67next_task_id_63027 + 1;
        if (_67next_task_id_63027 > MAXINT){
            _67next_task_id_63027 = NewDouble((double)_67next_task_id_63027);
        }
    }
    else
    _67next_task_id_63027 = binary_op(PLUS, 1, _67next_task_id_63027);
    DeRef(_0);
    goto L9; // [303] 396
L8: 

    /** 		id_wrap = TRUE -- id's have wrapped*/
    _67id_wrap_63023 = _9TRUE_431;

    /** 		for i = 1 to TASK_ID_MAX do*/
    {
        int _i_64118;
        _i_64118 = 1;
LA: 
        if (binary_op_a(GREATER, _i_64118, _67TASK_ID_MAX_63020)){
            goto LB; // [315] 395
        }

        /** 			next_task_id = i*/
        Ref(_i_64118);
        DeRef(_67next_task_id_63027);
        _67next_task_id_63027 = _i_64118;

        /** 			for j = 1 to length(tcb) do*/
        if (IS_SEQUENCE(_67tcb_63051)){
                _32091 = SEQ_PTR(_67tcb_63051)->length;
        }
        else {
            _32091 = 1;
        }
        {
            int _j_64120;
            _j_64120 = 1;
LC: 
            if (_j_64120 > _32091){
                goto LD; // [334] 376
            }

            /** 				if next_task_id = tcb[j][TASK_TID] then*/
            _2 = (int)SEQ_PTR(_67tcb_63051);
            _32092 = (int)*(((s1_ptr)_2)->base + _j_64120);
            _2 = (int)SEQ_PTR(_32092);
            _32093 = (int)*(((s1_ptr)_2)->base + 2);
            _32092 = NOVALUE;
            if (binary_op_a(NOTEQ, _67next_task_id_63027, _32093)){
                _32093 = NOVALUE;
                goto LE; // [355] 369
            }
            _32093 = NOVALUE;

            /** 					next_task_id = 0*/
            DeRef(_67next_task_id_63027);
            _67next_task_id_63027 = 0;

            /** 					exit -- this id is still in use*/
            goto LD; // [366] 376
LE: 

            /** 			end for*/
            _j_64120 = _j_64120 + 1;
            goto LC; // [371] 341
LD: 
            ;
        }

        /** 			if next_task_id then*/
        if (_67next_task_id_63027 == 0) {
            goto LF; // [380] 388
        }
        else {
            if (!IS_ATOM_INT(_67next_task_id_63027) && DBL_PTR(_67next_task_id_63027)->dbl == 0.0){
                goto LF; // [380] 388
            }
        }

        /** 				exit -- found unused id for next time*/
        goto LB; // [385] 395
LF: 

        /** 		end for*/
        _0 = _i_64118;
        if (IS_ATOM_INT(_i_64118)) {
            _i_64118 = _i_64118 + 1;
            if ((long)((unsigned long)_i_64118 +(unsigned long) HIGH_BITS) >= 0){
                _i_64118 = NewDouble((double)_i_64118);
            }
        }
        else {
            _i_64118 = binary_op_a(PLUS, _i_64118, 1);
        }
        DeRef(_0);
        goto LA; // [390] 322
LB: 
        ;
        DeRef(_i_64118);
    }
L9: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_new_entry_64064);
    DeRef(_32058);
    _32058 = NOVALUE;
    DeRef(_32074);
    _32074 = NOVALUE;
    DeRef(_32061);
    _32061 = NOVALUE;
    DeRef(_32068);
    _32068 = NOVALUE;
    DeRef(_32085);
    _32085 = NOVALUE;
    DeRef(_32087);
    _32087 = NOVALUE;
    return;
    ;
}


void _67opTASK_SCHEDULE()
{
    int _task_64130 = NOVALUE;
    int _now_64131 = NOVALUE;
    int _s_64132 = NOVALUE;
    int _32185 = NOVALUE;
    int _32183 = NOVALUE;
    int _32181 = NOVALUE;
    int _32180 = NOVALUE;
    int _32179 = NOVALUE;
    int _32177 = NOVALUE;
    int _32176 = NOVALUE;
    int _32175 = NOVALUE;
    int _32172 = NOVALUE;
    int _32171 = NOVALUE;
    int _32170 = NOVALUE;
    int _32169 = NOVALUE;
    int _32167 = NOVALUE;
    int _32166 = NOVALUE;
    int _32165 = NOVALUE;
    int _32163 = NOVALUE;
    int _32161 = NOVALUE;
    int _32159 = NOVALUE;
    int _32157 = NOVALUE;
    int _32154 = NOVALUE;
    int _32153 = NOVALUE;
    int _32152 = NOVALUE;
    int _32150 = NOVALUE;
    int _32147 = NOVALUE;
    int _32145 = NOVALUE;
    int _32144 = NOVALUE;
    int _32143 = NOVALUE;
    int _32141 = NOVALUE;
    int _32138 = NOVALUE;
    int _32137 = NOVALUE;
    int _32135 = NOVALUE;
    int _32134 = NOVALUE;
    int _32132 = NOVALUE;
    int _32131 = NOVALUE;
    int _32129 = NOVALUE;
    int _32128 = NOVALUE;
    int _32126 = NOVALUE;
    int _32125 = NOVALUE;
    int _32122 = NOVALUE;
    int _32120 = NOVALUE;
    int _32118 = NOVALUE;
    int _32117 = NOVALUE;
    int _32116 = NOVALUE;
    int _32114 = NOVALUE;
    int _32113 = NOVALUE;
    int _32112 = NOVALUE;
    int _32109 = NOVALUE;
    int _32108 = NOVALUE;
    int _32106 = NOVALUE;
    int _32103 = NOVALUE;
    int _32100 = NOVALUE;
    int _32098 = NOVALUE;
    int _32096 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]*/
    _32096 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32096);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	task = which_task(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32098 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_32098);
    _task_64130 = _67which_task(_32098);
    _32098 = NOVALUE;
    if (!IS_ATOM_INT(_task_64130)) {
        _1 = (long)(DBL_PTR(_task_64130)->dbl);
        DeRefDS(_task_64130);
        _task_64130 = _1;
    }

    /** 	b = Code[pc+2]*/
    _32100 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32100);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	s = val[b]*/
    DeRef(_s_64132);
    _2 = (int)SEQ_PTR(_67val_63018);
    _s_64132 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_s_64132);

    /** 	if atom(s) then*/
    _32103 = IS_ATOM(_s_64132);
    if (_32103 == 0)
    {
        _32103 = NOVALUE;
        goto L1; // [64] 187
    }
    else{
        _32103 = NOVALUE;
    }

    /** 		if s <= 0 then*/
    if (binary_op_a(GREATER, _s_64132, 0)){
        goto L2; // [69] 79
    }

    /** 			RTFatal("number of executions must be greater than 0")*/
    RefDS(_32105);
    _67RTFatal(_32105);
L2: 

    /** 		tcb[task][TASK_RUNS_MAX] = s   -- max execution count*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    Ref(_s_64132);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _s_64132;
    DeRef(_1);
    _32106 = NOVALUE;

    /** 		if tcb[task][TASK_TYPE] = T_REAL_TIME then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32108 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32108);
    _32109 = (int)*(((s1_ptr)_2)->base + 3);
    _32108 = NOVALUE;
    if (binary_op_a(NOTEQ, _32109, 1)){
        _32109 = NOVALUE;
        goto L3; // [104] 120
    }
    _32109 = NOVALUE;

    /** 			rt_first = task_delete(rt_first, task)*/
    _0 = _67task_delete(_67rt_first_63054, _task_64130);
    _67rt_first_63054 = _0;
    if (!IS_ATOM_INT(_67rt_first_63054)) {
        _1 = (long)(DBL_PTR(_67rt_first_63054)->dbl);
        DeRefDS(_67rt_first_63054);
        _67rt_first_63054 = _1;
    }
L3: 

    /** 		if tcb[task][TASK_TYPE] = T_REAL_TIME or*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32112 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32112);
    _32113 = (int)*(((s1_ptr)_2)->base + 3);
    _32112 = NOVALUE;
    if (IS_ATOM_INT(_32113)) {
        _32114 = (_32113 == 1);
    }
    else {
        _32114 = binary_op(EQUALS, _32113, 1);
    }
    _32113 = NOVALUE;
    if (IS_ATOM_INT(_32114)) {
        if (_32114 != 0) {
            goto L4; // [136] 159
        }
    }
    else {
        if (DBL_PTR(_32114)->dbl != 0.0) {
            goto L4; // [136] 159
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32116 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32116);
    _32117 = (int)*(((s1_ptr)_2)->base + 4);
    _32116 = NOVALUE;
    if (IS_ATOM_INT(_32117)) {
        _32118 = (_32117 == 1);
    }
    else {
        _32118 = binary_op(EQUALS, _32117, 1);
    }
    _32117 = NOVALUE;
    if (_32118 == 0) {
        DeRef(_32118);
        _32118 = NOVALUE;
        goto L5; // [155] 171
    }
    else {
        if (!IS_ATOM_INT(_32118) && DBL_PTR(_32118)->dbl == 0.0){
            DeRef(_32118);
            _32118 = NOVALUE;
            goto L5; // [155] 171
        }
        DeRef(_32118);
        _32118 = NOVALUE;
    }
    DeRef(_32118);
    _32118 = NOVALUE;
L4: 

    /** 			ts_first = task_insert(ts_first, task)*/
    _0 = _67task_insert(_67ts_first_63055, _task_64130);
    _67ts_first_63055 = _0;
    if (!IS_ATOM_INT(_67ts_first_63055)) {
        _1 = (long)(DBL_PTR(_67ts_first_63055)->dbl);
        DeRefDS(_67ts_first_63055);
        _67ts_first_63055 = _1;
    }
L5: 

    /** 		tcb[task][TASK_TYPE] = T_TIME_SHARE*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _32120 = NOVALUE;
    goto L6; // [184] 542
L1: 

    /** 		if length(s) != 2 then*/
    if (IS_SEQUENCE(_s_64132)){
            _32122 = SEQ_PTR(_s_64132)->length;
    }
    else {
        _32122 = 1;
    }
    if (_32122 == 2)
    goto L7; // [192] 202

    /** 			RTFatal("second argument must be {min-time, max-time}")*/
    RefDS(_32124);
    _67RTFatal(_32124);
L7: 

    /** 		if sequence(s[1]) or sequence(s[2]) then*/
    _2 = (int)SEQ_PTR(_s_64132);
    _32125 = (int)*(((s1_ptr)_2)->base + 1);
    _32126 = IS_SEQUENCE(_32125);
    _32125 = NOVALUE;
    if (_32126 != 0) {
        goto L8; // [211] 227
    }
    _2 = (int)SEQ_PTR(_s_64132);
    _32128 = (int)*(((s1_ptr)_2)->base + 2);
    _32129 = IS_SEQUENCE(_32128);
    _32128 = NOVALUE;
    if (_32129 == 0)
    {
        _32129 = NOVALUE;
        goto L9; // [223] 233
    }
    else{
        _32129 = NOVALUE;
    }
L8: 

    /** 			RTFatal("min and max times must be atoms")*/
    RefDS(_32130);
    _67RTFatal(_32130);
L9: 

    /** 		if s[1] < 0 or s[2] < 0 then*/
    _2 = (int)SEQ_PTR(_s_64132);
    _32131 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_32131)) {
        _32132 = (_32131 < 0);
    }
    else {
        _32132 = binary_op(LESS, _32131, 0);
    }
    _32131 = NOVALUE;
    if (IS_ATOM_INT(_32132)) {
        if (_32132 != 0) {
            goto LA; // [243] 260
        }
    }
    else {
        if (DBL_PTR(_32132)->dbl != 0.0) {
            goto LA; // [243] 260
        }
    }
    _2 = (int)SEQ_PTR(_s_64132);
    _32134 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_32134)) {
        _32135 = (_32134 < 0);
    }
    else {
        _32135 = binary_op(LESS, _32134, 0);
    }
    _32134 = NOVALUE;
    if (_32135 == 0) {
        DeRef(_32135);
        _32135 = NOVALUE;
        goto LB; // [256] 266
    }
    else {
        if (!IS_ATOM_INT(_32135) && DBL_PTR(_32135)->dbl == 0.0){
            DeRef(_32135);
            _32135 = NOVALUE;
            goto LB; // [256] 266
        }
        DeRef(_32135);
        _32135 = NOVALUE;
    }
    DeRef(_32135);
    _32135 = NOVALUE;
LA: 

    /** 			RTFatal("min and max times must be greater than or equal to 0")*/
    RefDS(_32136);
    _67RTFatal(_32136);
LB: 

    /** 		if s[1] > s[2] then*/
    _2 = (int)SEQ_PTR(_s_64132);
    _32137 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_s_64132);
    _32138 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _32137, _32138)){
        _32137 = NOVALUE;
        _32138 = NOVALUE;
        goto LC; // [276] 286
    }
    _32137 = NOVALUE;
    _32138 = NOVALUE;

    /** 			RTFatal("task min time must be <= task max time")*/
    RefDS(_32140);
    _67RTFatal(_32140);
LC: 

    /** 		tcb[task][TASK_MIN_INC] = s[1]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64132);
    _32143 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_32143);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _32143;
    if( _1 != _32143 ){
        DeRef(_1);
    }
    _32143 = NOVALUE;
    _32141 = NOVALUE;

    /** 		if s[1] < clock_period/2 then*/
    _2 = (int)SEQ_PTR(_s_64132);
    _32144 = (int)*(((s1_ptr)_2)->base + 1);
    _32145 = binary_op(DIVIDE, _67clock_period_63028, 2);
    if (binary_op_a(GREATEREQ, _32144, _32145)){
        _32144 = NOVALUE;
        DeRefDS(_32145);
        _32145 = NOVALUE;
        goto LD; // [315] 372
    }
    _32144 = NOVALUE;
    DeRef(_32145);
    _32145 = NOVALUE;

    /** 			if s[1] > 1.0e-9 then*/
    _2 = (int)SEQ_PTR(_s_64132);
    _32147 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(LESSEQ, _32147, _32148)){
        _32147 = NOVALUE;
        goto LE; // [325] 355
    }
    _32147 = NOVALUE;

    /** 				tcb[task][TASK_RUNS_MAX] =  floor(clock_period / s[1])*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64132);
    _32152 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = binary_op(DIVIDE, _67clock_period_63028, _32152);
    _32153 = unary_op(FLOOR, _2);
    DeRef(_2);
    _32152 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _32153;
    if( _1 != _32153 ){
        DeRef(_1);
    }
    _32153 = NOVALUE;
    _32150 = NOVALUE;
    goto LF; // [352] 386
LE: 

    /** 				tcb[task][TASK_RUNS_MAX] =  1000000000 -- arbitrary, large*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = 1000000000;
    DeRef(_1);
    _32154 = NOVALUE;
    goto LF; // [369] 386
LD: 

    /** 			tcb[task][TASK_RUNS_MAX] = 1*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32157 = NOVALUE;
LF: 

    /** 		tcb[task][TASK_MAX_INC] = s[2]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64132);
    _32161 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_32161);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _32161;
    if( _1 != _32161 ){
        DeRef(_1);
    }
    _32161 = NOVALUE;
    _32159 = NOVALUE;

    /** 		now = time()*/
    DeRef(_now_64131);
    _now_64131 = NewDouble(current_time());

    /** 		tcb[task][TASK_MIN_TIME] = now + s[1]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64132);
    _32165 = (int)*(((s1_ptr)_2)->base + 1);
    _32166 = binary_op(PLUS, _now_64131, _32165);
    _32165 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 8);
    _1 = *(int *)_2;
    *(int *)_2 = _32166;
    if( _1 != _32166 ){
        DeRef(_1);
    }
    _32166 = NOVALUE;
    _32163 = NOVALUE;

    /** 		tcb[task][TASK_MAX_TIME] = now + s[2]*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_s_64132);
    _32169 = (int)*(((s1_ptr)_2)->base + 2);
    _32170 = binary_op(PLUS, _now_64131, _32169);
    _32169 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _32170;
    if( _1 != _32170 ){
        DeRef(_1);
    }
    _32170 = NOVALUE;
    _32167 = NOVALUE;

    /** 		if tcb[task][TASK_TYPE] = T_TIME_SHARE then*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32171 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32171);
    _32172 = (int)*(((s1_ptr)_2)->base + 3);
    _32171 = NOVALUE;
    if (binary_op_a(NOTEQ, _32172, 2)){
        _32172 = NOVALUE;
        goto L10; // [461] 477
    }
    _32172 = NOVALUE;

    /** 			ts_first = task_delete(ts_first, task)*/
    _0 = _67task_delete(_67ts_first_63055, _task_64130);
    _67ts_first_63055 = _0;
    if (!IS_ATOM_INT(_67ts_first_63055)) {
        _1 = (long)(DBL_PTR(_67ts_first_63055)->dbl);
        DeRefDS(_67ts_first_63055);
        _67ts_first_63055 = _1;
    }
L10: 

    /** 		if tcb[task][TASK_TYPE] = T_TIME_SHARE or*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32175 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32175);
    _32176 = (int)*(((s1_ptr)_2)->base + 3);
    _32175 = NOVALUE;
    if (IS_ATOM_INT(_32176)) {
        _32177 = (_32176 == 2);
    }
    else {
        _32177 = binary_op(EQUALS, _32176, 2);
    }
    _32176 = NOVALUE;
    if (IS_ATOM_INT(_32177)) {
        if (_32177 != 0) {
            goto L11; // [493] 516
        }
    }
    else {
        if (DBL_PTR(_32177)->dbl != 0.0) {
            goto L11; // [493] 516
        }
    }
    _2 = (int)SEQ_PTR(_67tcb_63051);
    _32179 = (int)*(((s1_ptr)_2)->base + _task_64130);
    _2 = (int)SEQ_PTR(_32179);
    _32180 = (int)*(((s1_ptr)_2)->base + 4);
    _32179 = NOVALUE;
    if (IS_ATOM_INT(_32180)) {
        _32181 = (_32180 == 1);
    }
    else {
        _32181 = binary_op(EQUALS, _32180, 1);
    }
    _32180 = NOVALUE;
    if (_32181 == 0) {
        DeRef(_32181);
        _32181 = NOVALUE;
        goto L12; // [512] 528
    }
    else {
        if (!IS_ATOM_INT(_32181) && DBL_PTR(_32181)->dbl == 0.0){
            DeRef(_32181);
            _32181 = NOVALUE;
            goto L12; // [512] 528
        }
        DeRef(_32181);
        _32181 = NOVALUE;
    }
    DeRef(_32181);
    _32181 = NOVALUE;
L11: 

    /** 			rt_first = task_insert(rt_first, task)*/
    _0 = _67task_insert(_67rt_first_63054, _task_64130);
    _67rt_first_63054 = _0;
    if (!IS_ATOM_INT(_67rt_first_63054)) {
        _1 = (long)(DBL_PTR(_67rt_first_63054)->dbl);
        DeRefDS(_67rt_first_63054);
        _67rt_first_63054 = _1;
    }
L12: 

    /** 		tcb[task][TASK_TYPE] = T_REAL_TIME*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _32183 = NOVALUE;
L6: 

    /** 	tcb[task][TASK_STATE] = ST_ACTIVE*/
    _2 = (int)SEQ_PTR(_67tcb_63051);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67tcb_63051 = MAKE_SEQ(_2);
    }
    _3 = (int)(_task_64130 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32185 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_now_64131);
    DeRef(_s_64132);
    DeRef(_32096);
    _32096 = NOVALUE;
    DeRef(_32100);
    _32100 = NOVALUE;
    DeRef(_32114);
    _32114 = NOVALUE;
    DeRef(_32132);
    _32132 = NOVALUE;
    DeRef(_32177);
    _32177 = NOVALUE;
    return;
    ;
}


void _67one_trace_line(int _line_64247)
{
    int _32189 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		printf(trace_file, "%-78.78s\n", {line})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_line_64247);
    *((int *)(_2+4)) = _line_64247;
    _32189 = MAKE_SEQ(_1);
    EPrintf(_67trace_file_64243, _32188, _32189);
    DeRefDS(_32189);
    _32189 = NOVALUE;

    /** end procedure*/
    DeRefDS(_line_64247);
    return;
    ;
}


void _67opCOVERAGE_LINE()
{
    int _32192 = NOVALUE;
    int _32191 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cover_line( Code[pc+1] )*/
    _32191 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32192 = (int)*(((s1_ptr)_2)->base + _32191);
    Ref(_32192);
    _49cover_line(_32192);
    _32192 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _32191 = NOVALUE;
    return;
    ;
}


void _67opCOVERAGE_ROUTINE()
{
    int _32195 = NOVALUE;
    int _32194 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cover_routine( Code[pc+1] )*/
    _32194 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32195 = (int)*(((s1_ptr)_2)->base + _32194);
    Ref(_32195);
    _49cover_routine(_32195);
    _32195 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _32194 = NOVALUE;
    return;
    ;
}


void _67opSTARTLINE()
{
    int _line_64267 = NOVALUE;
    int _w_64268 = NOVALUE;
    int _32229 = NOVALUE;
    int _32228 = NOVALUE;
    int _32227 = NOVALUE;
    int _32224 = NOVALUE;
    int _32218 = NOVALUE;
    int _32217 = NOVALUE;
    int _32216 = NOVALUE;
    int _32215 = NOVALUE;
    int _32214 = NOVALUE;
    int _32213 = NOVALUE;
    int _32212 = NOVALUE;
    int _32209 = NOVALUE;
    int _32208 = NOVALUE;
    int _32206 = NOVALUE;
    int _32205 = NOVALUE;
    int _32204 = NOVALUE;
    int _32202 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TraceOn then*/
    if (_67TraceOn_63006 == 0)
    {
        goto L1; // [5] 277
    }
    else{
    }

    /** 		if trace_file = -1 then*/
    if (_67trace_file_64243 != -1)
    goto L2; // [12] 40

    /** 			trace_file = open("ctrace.out", "wb")*/
    _67trace_file_64243 = EOpen(_32198, _23496, 0);

    /** 			if trace_file = -1 then*/
    if (_67trace_file_64243 != -1)
    goto L3; // [29] 39

    /** 				RTFatal("Couldn't open ctrace.out")*/
    RefDS(_32201);
    _67RTFatal(_32201);
L3: 
L2: 

    /** 		a = Code[pc+1]*/
    _32202 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32202);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 		if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _32204 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _32204 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _32205 = (int)*(((s1_ptr)_2)->base + _32204);
    _32206 = IS_ATOM(_32205);
    _32205 = NOVALUE;
    if (_32206 == 0)
    {
        _32206 = NOVALUE;
        goto L4; // [70] 84
    }
    else{
        _32206 = NOVALUE;
    }

    /** 			slist = s_expand(slist)*/
    RefDS(_12slist_11773);
    _0 = _60s_expand(_12slist_11773);
    DeRefDS(_12slist_11773);
    _12slist_11773 = _0;
L4: 

    /** 		line = fetch_line(slist[a][SRC])*/
    _2 = (int)SEQ_PTR(_12slist_11773);
    _32208 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32208);
    _32209 = (int)*(((s1_ptr)_2)->base + 1);
    _32208 = NOVALUE;
    Ref(_32209);
    _0 = _line_64267;
    _line_64267 = _60fetch_line(_32209);
    DeRef(_0);
    _32209 = NOVALUE;

    /** 		line = sprintf("%s:%d\t%s",*/
    _2 = (int)SEQ_PTR(_12slist_11773);
    _32212 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32212);
    _32213 = (int)*(((s1_ptr)_2)->base + 3);
    _32212 = NOVALUE;
    _2 = (int)SEQ_PTR(_13known_files_10637);
    if (!IS_ATOM_INT(_32213)){
        _32214 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32213)->dbl));
    }
    else{
        _32214 = (int)*(((s1_ptr)_2)->base + _32213);
    }
    Ref(_32214);
    _32215 = _52name_ext(_32214);
    _32214 = NOVALUE;
    _2 = (int)SEQ_PTR(_12slist_11773);
    _32216 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32216);
    _32217 = (int)*(((s1_ptr)_2)->base + 2);
    _32216 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _32215;
    Ref(_32217);
    *((int *)(_2+8)) = _32217;
    RefDS(_line_64267);
    *((int *)(_2+12)) = _line_64267;
    _32218 = MAKE_SEQ(_1);
    _32217 = NOVALUE;
    _32215 = NOVALUE;
    DeRefDS(_line_64267);
    _line_64267 = EPrintf(-9999999, _32211, _32218);
    DeRefDS(_32218);
    _32218 = NOVALUE;

    /** 		trace_line += 1*/
    _67trace_line_64244 = _67trace_line_64244 + 1;

    /** 		if trace_line >= 5000 then*/
    if (_67trace_line_64244 < 5000)
    goto L5; // [168] 208

    /** 			trace_line = 0*/
    _67trace_line_64244 = 0;

    /** 			one_trace_line("")*/
    RefDS(_21829);
    _67one_trace_line(_21829);

    /** 			one_trace_line("               ")*/
    RefDS(_32223);
    _67one_trace_line(_32223);

    /** 			flush(trace_file)*/
    _17flush(_67trace_file_64243);

    /** 			if seek(trace_file, 0) then*/
    _32224 = _17seek(_67trace_file_64243, 0);
    if (_32224 == 0) {
        DeRef(_32224);
        _32224 = NOVALUE;
        goto L6; // [203] 207
    }
    else {
        if (!IS_ATOM_INT(_32224) && DBL_PTR(_32224)->dbl == 0.0){
            DeRef(_32224);
            _32224 = NOVALUE;
            goto L6; // [203] 207
        }
        DeRef(_32224);
        _32224 = NOVALUE;
    }
    DeRef(_32224);
    _32224 = NOVALUE;
L6: 
L5: 

    /** 		one_trace_line(line)*/
    RefDS(_line_64267);
    _67one_trace_line(_line_64267);

    /** 		one_trace_line("")*/
    RefDS(_21829);
    _67one_trace_line(_21829);

    /** 		one_trace_line("=== THE END ===")*/
    RefDS(_32225);
    _67one_trace_line(_32225);

    /** 		one_trace_line("")*/
    RefDS(_21829);
    _67one_trace_line(_21829);

    /** 		one_trace_line("")*/
    RefDS(_21829);
    _67one_trace_line(_21829);

    /** 		one_trace_line("")*/
    RefDS(_21829);
    _67one_trace_line(_21829);

    /** 		flush(trace_file)*/
    _17flush(_67trace_file_64243);

    /** 		w = where(trace_file)*/
    _w_64268 = _17where(_67trace_file_64243);
    if (!IS_ATOM_INT(_w_64268)) {
        _1 = (long)(DBL_PTR(_w_64268)->dbl);
        DeRefDS(_w_64268);
        _w_64268 = _1;
    }

    /** 		if seek(trace_file, w-79*5) then -- back up 5 (fixed-width) lines*/
    _32227 = 395;
    _32228 = _w_64268 - 395;
    if ((long)((unsigned long)_32228 +(unsigned long) HIGH_BITS) >= 0){
        _32228 = NewDouble((double)_32228);
    }
    _32227 = NOVALUE;
    _32229 = _17seek(_67trace_file_64243, _32228);
    _32228 = NOVALUE;
    if (_32229 == 0) {
        DeRef(_32229);
        _32229 = NOVALUE;
        goto L7; // [272] 276
    }
    else {
        if (!IS_ATOM_INT(_32229) && DBL_PTR(_32229)->dbl == 0.0){
            DeRef(_32229);
            _32229 = NOVALUE;
            goto L7; // [272] 276
        }
        DeRef(_32229);
        _32229 = NOVALUE;
    }
    DeRef(_32229);
    _32229 = NOVALUE;
L7: 
L1: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_line_64267);
    DeRef(_32202);
    _32202 = NOVALUE;
    _32213 = NOVALUE;
    return;
    ;
}


void _67opPROC_TAIL()
{
    int _arg_64331 = NOVALUE;
    int _sub_64332 = NOVALUE;
    int _32247 = NOVALUE;
    int _32246 = NOVALUE;
    int _32245 = NOVALUE;
    int _32244 = NOVALUE;
    int _32243 = NOVALUE;
    int _32241 = NOVALUE;
    int _32240 = NOVALUE;
    int _32239 = NOVALUE;
    int _32238 = NOVALUE;
    int _32237 = NOVALUE;
    int _32236 = NOVALUE;
    int _32235 = NOVALUE;
    int _32233 = NOVALUE;
    int _32231 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sub = Code[pc+1] -- subroutine*/
    _32231 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_64332 = (int)*(((s1_ptr)_2)->base + _32231);
    if (!IS_ATOM_INT(_sub_64332)){
        _sub_64332 = (long)DBL_PTR(_sub_64332)->dbl;
    }

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32233 = (int)*(((s1_ptr)_2)->base + _sub_64332);
    _2 = (int)SEQ_PTR(_32233);
    _arg_64331 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64331)){
        _arg_64331 = (long)DBL_PTR(_arg_64331)->dbl;
    }
    _32233 = NOVALUE;

    /** 	for i = 1 to SymTab[sub][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32235 = (int)*(((s1_ptr)_2)->base + _sub_64332);
    _2 = (int)SEQ_PTR(_32235);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _32236 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _32236 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _32235 = NOVALUE;
    {
        int _i_64341;
        _i_64341 = 1;
L1: 
        if (binary_op_a(GREATER, _i_64341, _32236)){
            goto L2; // [47] 107
        }

        /** 		val[arg] = val[Code[pc+1+i]]*/
        _32237 = _67pc_63008 + 1;
        if (_32237 > MAXINT){
            _32237 = NewDouble((double)_32237);
        }
        if (IS_ATOM_INT(_32237) && IS_ATOM_INT(_i_64341)) {
            _32238 = _32237 + _i_64341;
        }
        else {
            if (IS_ATOM_INT(_32237)) {
                _32238 = NewDouble((double)_32237 + DBL_PTR(_i_64341)->dbl);
            }
            else {
                if (IS_ATOM_INT(_i_64341)) {
                    _32238 = NewDouble(DBL_PTR(_32237)->dbl + (double)_i_64341);
                }
                else
                _32238 = NewDouble(DBL_PTR(_32237)->dbl + DBL_PTR(_i_64341)->dbl);
            }
        }
        DeRef(_32237);
        _32237 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_32238)){
            _32239 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32238)->dbl));
        }
        else{
            _32239 = (int)*(((s1_ptr)_2)->base + _32238);
        }
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_32239)){
            _32240 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32239)->dbl));
        }
        else{
            _32240 = (int)*(((s1_ptr)_2)->base + _32239);
        }
        Ref(_32240);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64331);
        _1 = *(int *)_2;
        *(int *)_2 = _32240;
        if( _1 != _32240 ){
            DeRef(_1);
        }
        _32240 = NOVALUE;

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _32241 = (int)*(((s1_ptr)_2)->base + _arg_64331);
        _2 = (int)SEQ_PTR(_32241);
        _arg_64331 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64331)){
            _arg_64331 = (long)DBL_PTR(_arg_64331)->dbl;
        }
        _32241 = NOVALUE;

        /** 	end for*/
        _0 = _i_64341;
        if (IS_ATOM_INT(_i_64341)) {
            _i_64341 = _i_64341 + 1;
            if ((long)((unsigned long)_i_64341 +(unsigned long) HIGH_BITS) >= 0){
                _i_64341 = NewDouble((double)_i_64341);
            }
        }
        else {
            _i_64341 = binary_op_a(PLUS, _i_64341, 1);
        }
        DeRef(_0);
        goto L1; // [102] 54
L2: 
        ;
        DeRef(_i_64341);
    }

    /** 	while arg and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    if (_arg_64331 == 0) {
        goto L4; // [112] 169
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32244 = (int)*(((s1_ptr)_2)->base + _arg_64331);
    _2 = (int)SEQ_PTR(_32244);
    _32245 = (int)*(((s1_ptr)_2)->base + 4);
    _32244 = NOVALUE;
    if (IS_ATOM_INT(_32245)) {
        _32246 = (_32245 <= 3);
    }
    else {
        _32246 = binary_op(LESSEQ, _32245, 3);
    }
    _32245 = NOVALUE;
    if (_32246 <= 0) {
        if (_32246 == 0) {
            DeRef(_32246);
            _32246 = NOVALUE;
            goto L4; // [135] 169
        }
        else {
            if (!IS_ATOM_INT(_32246) && DBL_PTR(_32246)->dbl == 0.0){
                DeRef(_32246);
                _32246 = NOVALUE;
                goto L4; // [135] 169
            }
            DeRef(_32246);
            _32246 = NOVALUE;
        }
    }
    DeRef(_32246);
    _32246 = NOVALUE;

    /** 		val[arg] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64331);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32247 = (int)*(((s1_ptr)_2)->base + _arg_64331);
    _2 = (int)SEQ_PTR(_32247);
    _arg_64331 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64331)){
        _arg_64331 = (long)DBL_PTR(_arg_64331)->dbl;
    }
    _32247 = NOVALUE;

    /** 	end while*/
    goto L3; // [166] 112
L4: 

    /** 	pc = 1*/
    _67pc_63008 = 1;

    /** end procedure*/
    DeRef(_32231);
    _32231 = NOVALUE;
    _32236 = NOVALUE;
    _32239 = NOVALUE;
    DeRef(_32238);
    _32238 = NOVALUE;
    return;
    ;
}


void _67opPROC()
{
    int _n_64370 = NOVALUE;
    int _arg_64371 = NOVALUE;
    int _sub_64372 = NOVALUE;
    int _p_64373 = NOVALUE;
    int _private_block_64374 = NOVALUE;
    int _32314 = NOVALUE;
    int _32309 = NOVALUE;
    int _32308 = NOVALUE;
    int _32306 = NOVALUE;
    int _32304 = NOVALUE;
    int _32302 = NOVALUE;
    int _32301 = NOVALUE;
    int _32300 = NOVALUE;
    int _32299 = NOVALUE;
    int _32298 = NOVALUE;
    int _32297 = NOVALUE;
    int _32295 = NOVALUE;
    int _32293 = NOVALUE;
    int _32290 = NOVALUE;
    int _32288 = NOVALUE;
    int _32286 = NOVALUE;
    int _32284 = NOVALUE;
    int _32283 = NOVALUE;
    int _32282 = NOVALUE;
    int _32281 = NOVALUE;
    int _32280 = NOVALUE;
    int _32279 = NOVALUE;
    int _32278 = NOVALUE;
    int _32277 = NOVALUE;
    int _32276 = NOVALUE;
    int _32275 = NOVALUE;
    int _32274 = NOVALUE;
    int _32273 = NOVALUE;
    int _32272 = NOVALUE;
    int _32271 = NOVALUE;
    int _32270 = NOVALUE;
    int _32268 = NOVALUE;
    int _32267 = NOVALUE;
    int _32266 = NOVALUE;
    int _32265 = NOVALUE;
    int _32264 = NOVALUE;
    int _32262 = NOVALUE;
    int _32261 = NOVALUE;
    int _32259 = NOVALUE;
    int _32258 = NOVALUE;
    int _32256 = NOVALUE;
    int _32255 = NOVALUE;
    int _32253 = NOVALUE;
    int _32251 = NOVALUE;
    int _32249 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sub = Code[pc+1] -- subroutine*/
    _32249 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_64372 = (int)*(((s1_ptr)_2)->base + _32249);
    if (!IS_ATOM_INT(_sub_64372)){
        _sub_64372 = (long)DBL_PTR(_sub_64372)->dbl;
    }

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32251 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32251);
    _arg_64371 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64371)){
        _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
    }
    _32251 = NOVALUE;

    /** 	n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32253 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32253);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _n_64370 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _n_64370 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_n_64370)){
        _n_64370 = (long)DBL_PTR(_n_64370)->dbl;
    }
    _32253 = NOVALUE;

    /** 	if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32255 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32255);
    _32256 = (int)*(((s1_ptr)_2)->base + 25);
    _32255 = NOVALUE;
    if (binary_op_a(EQUALS, _32256, 0)){
        _32256 = NOVALUE;
        goto L1; // [63] 413
    }
    _32256 = NOVALUE;

    /** 		private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32258 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32258);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _32259 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _32259 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _32258 = NOVALUE;
    DeRef(_private_block_64374);
    _private_block_64374 = Repeat(0, _32259);
    _32259 = NOVALUE;

    /** 		p = 1*/
    _p_64373 = 1;

    /** 		for i = 1 to n do*/
    _32261 = _n_64370;
    {
        int _i_64398;
        _i_64398 = 1;
L2: 
        if (_i_64398 > _32261){
            goto L3; // [95] 173
        }

        /** 			private_block[p] = val[arg]*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _32262 = (int)*(((s1_ptr)_2)->base + _arg_64371);
        Ref(_32262);
        _2 = (int)SEQ_PTR(_private_block_64374);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _private_block_64374 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _p_64373);
        _1 = *(int *)_2;
        *(int *)_2 = _32262;
        if( _1 != _32262 ){
            DeRef(_1);
        }
        _32262 = NOVALUE;

        /** 			p += 1*/
        _p_64373 = _p_64373 + 1;

        /** 			val[arg] = val[Code[pc+1+i]]*/
        _32264 = _67pc_63008 + 1;
        if (_32264 > MAXINT){
            _32264 = NewDouble((double)_32264);
        }
        if (IS_ATOM_INT(_32264)) {
            _32265 = _32264 + _i_64398;
        }
        else {
            _32265 = NewDouble(DBL_PTR(_32264)->dbl + (double)_i_64398);
        }
        DeRef(_32264);
        _32264 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_32265)){
            _32266 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32265)->dbl));
        }
        else{
            _32266 = (int)*(((s1_ptr)_2)->base + _32265);
        }
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_32266)){
            _32267 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32266)->dbl));
        }
        else{
            _32267 = (int)*(((s1_ptr)_2)->base + _32266);
        }
        Ref(_32267);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64371);
        _1 = *(int *)_2;
        *(int *)_2 = _32267;
        if( _1 != _32267 ){
            DeRef(_1);
        }
        _32267 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _32268 = (int)*(((s1_ptr)_2)->base + _arg_64371);
        _2 = (int)SEQ_PTR(_32268);
        _arg_64371 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64371)){
            _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
        }
        _32268 = NOVALUE;

        /** 		end for*/
        _i_64398 = _i_64398 + 1;
        goto L2; // [168] 102
L3: 
        ;
    }

    /** 		while arg != 0 */
L4: 
    _32270 = (_arg_64371 != 0);
    if (_32270 == 0) {
        goto L5; // [182] 330
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32272 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32272);
    _32273 = (int)*(((s1_ptr)_2)->base + 4);
    _32272 = NOVALUE;
    if (IS_ATOM_INT(_32273)) {
        _32274 = (_32273 <= 3);
    }
    else {
        _32274 = binary_op(LESSEQ, _32273, 3);
    }
    _32273 = NOVALUE;
    if (IS_ATOM_INT(_32274)) {
        if (_32274 != 0) {
            DeRef(_32275);
            _32275 = 1;
            goto L6; // [204] 230
        }
    }
    else {
        if (DBL_PTR(_32274)->dbl != 0.0) {
            DeRef(_32275);
            _32275 = 1;
            goto L6; // [204] 230
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32276 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32276);
    _32277 = (int)*(((s1_ptr)_2)->base + 4);
    _32276 = NOVALUE;
    if (IS_ATOM_INT(_32277)) {
        _32278 = (_32277 == 2);
    }
    else {
        _32278 = binary_op(EQUALS, _32277, 2);
    }
    _32277 = NOVALUE;
    DeRef(_32275);
    if (IS_ATOM_INT(_32278))
    _32275 = (_32278 != 0);
    else
    _32275 = DBL_PTR(_32278)->dbl != 0.0;
L6: 
    if (_32275 != 0) {
        DeRef(_32279);
        _32279 = 1;
        goto L7; // [230] 256
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32280 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32280);
    _32281 = (int)*(((s1_ptr)_2)->base + 4);
    _32280 = NOVALUE;
    if (IS_ATOM_INT(_32281)) {
        _32282 = (_32281 == 9);
    }
    else {
        _32282 = binary_op(EQUALS, _32281, 9);
    }
    _32281 = NOVALUE;
    if (IS_ATOM_INT(_32282))
    _32279 = (_32282 != 0);
    else
    _32279 = DBL_PTR(_32282)->dbl != 0.0;
L7: 
    if (_32279 == 0)
    {
        _32279 = NOVALUE;
        goto L5; // [257] 330
    }
    else{
        _32279 = NOVALUE;
    }

    /** 			if SymTab[arg][S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32283 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32283);
    _32284 = (int)*(((s1_ptr)_2)->base + 4);
    _32283 = NOVALUE;
    if (binary_op_a(EQUALS, _32284, 9)){
        _32284 = NOVALUE;
        goto L8; // [276] 309
    }
    _32284 = NOVALUE;

    /** 				private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32286 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    Ref(_32286);
    _2 = (int)SEQ_PTR(_private_block_64374);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_64374 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_64373);
    _1 = *(int *)_2;
    *(int *)_2 = _32286;
    if( _1 != _32286 ){
        DeRef(_1);
    }
    _32286 = NOVALUE;

    /** 				p += 1*/
    _p_64373 = _p_64373 + 1;

    /** 				val[arg] = NOVALUE  -- necessary?*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64371);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L8: 

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32288 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32288);
    _arg_64371 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64371)){
        _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
    }
    _32288 = NOVALUE;

    /** 		end while*/
    goto L4; // [327] 178
L5: 

    /** 		arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32290 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32290);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _arg_64371 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _arg_64371 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_arg_64371)){
        _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
    }
    _32290 = NOVALUE;

    /** 		while arg != 0 do*/
L9: 
    if (_arg_64371 == 0)
    goto LA; // [351] 404

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32293 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    Ref(_32293);
    _2 = (int)SEQ_PTR(_private_block_64374);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_64374 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_64373);
    _1 = *(int *)_2;
    *(int *)_2 = _32293;
    if( _1 != _32293 ){
        DeRef(_1);
    }
    _32293 = NOVALUE;

    /** 			p += 1*/
    _p_64373 = _p_64373 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_64371);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32295 = (int)*(((s1_ptr)_2)->base + _arg_64371);
    _2 = (int)SEQ_PTR(_32295);
    _arg_64371 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_64371)){
        _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
    }
    _32295 = NOVALUE;

    /** 		end while*/
    goto L9; // [401] 351
LA: 

    /** 		save_private_block(sub, private_block)*/
    RefDS(_private_block_64374);
    _67save_private_block(_sub_64372, _private_block_64374);
    goto LB; // [410] 479
L1: 

    /** 		for i = 1 to n do*/
    _32297 = _n_64370;
    {
        int _i_64463;
        _i_64463 = 1;
LC: 
        if (_i_64463 > _32297){
            goto LD; // [418] 478
        }

        /** 			val[arg] = val[Code[pc+1+i]]*/
        _32298 = _67pc_63008 + 1;
        if (_32298 > MAXINT){
            _32298 = NewDouble((double)_32298);
        }
        if (IS_ATOM_INT(_32298)) {
            _32299 = _32298 + _i_64463;
        }
        else {
            _32299 = NewDouble(DBL_PTR(_32298)->dbl + (double)_i_64463);
        }
        DeRef(_32298);
        _32298 = NOVALUE;
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_32299)){
            _32300 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32299)->dbl));
        }
        else{
            _32300 = (int)*(((s1_ptr)_2)->base + _32299);
        }
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_32300)){
            _32301 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32300)->dbl));
        }
        else{
            _32301 = (int)*(((s1_ptr)_2)->base + _32300);
        }
        Ref(_32301);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _arg_64371);
        _1 = *(int *)_2;
        *(int *)_2 = _32301;
        if( _1 != _32301 ){
            DeRef(_1);
        }
        _32301 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _32302 = (int)*(((s1_ptr)_2)->base + _arg_64371);
        _2 = (int)SEQ_PTR(_32302);
        _arg_64371 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_64371)){
            _arg_64371 = (long)DBL_PTR(_arg_64371)->dbl;
        }
        _32302 = NOVALUE;

        /** 		end for*/
        _i_64463 = _i_64463 + 1;
        goto LC; // [473] 425
LD: 
        ;
    }
LB: 

    /** 	SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_64372 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63025;
    DeRef(_1);
    _32304 = NOVALUE;

    /** 	pc = pc + 2 + n*/
    _32306 = _67pc_63008 + 2;
    if ((long)((unsigned long)_32306 + (unsigned long)HIGH_BITS) >= 0) 
    _32306 = NewDouble((double)_32306);
    if (IS_ATOM_INT(_32306)) {
        _67pc_63008 = _32306 + _n_64370;
    }
    else {
        _67pc_63008 = NewDouble(DBL_PTR(_32306)->dbl + (double)_n_64370);
    }
    DeRef(_32306);
    _32306 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }

    /** 	if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32308 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    _2 = (int)SEQ_PTR(_32308);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _32309 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _32309 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _32308 = NOVALUE;
    if (binary_op_a(EQUALS, _32309, 27)){
        _32309 = NOVALUE;
        goto LE; // [526] 539
    }
    _32309 = NOVALUE;

    /** 		pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;
LE: 

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67pc_63008);

    /** 	call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _sub_64372);

    /** 	Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32314 = (int)*(((s1_ptr)_2)->base + _sub_64372);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_32314);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _32314 = NOVALUE;

    /** 	pc = 1*/
    _67pc_63008 = 1;

    /** end procedure*/
    DeRef(_private_block_64374);
    DeRef(_32249);
    _32249 = NOVALUE;
    _32266 = NOVALUE;
    DeRef(_32265);
    _32265 = NOVALUE;
    DeRef(_32270);
    _32270 = NOVALUE;
    _32300 = NOVALUE;
    DeRef(_32274);
    _32274 = NOVALUE;
    DeRef(_32278);
    _32278 = NOVALUE;
    DeRef(_32282);
    _32282 = NOVALUE;
    DeRef(_32299);
    _32299 = NOVALUE;
    return;
    ;
}


void _67exit_block(int _block_64500)
{
    int _a_64501 = NOVALUE;
    int _32319 = NOVALUE;
    int _32316 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_block_64500)) {
        _1 = (long)(DBL_PTR(_block_64500)->dbl);
        DeRefDS(_block_64500);
        _block_64500 = _1;
    }

    /** 	integer a = SymTab[block][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32316 = (int)*(((s1_ptr)_2)->base + _block_64500);
    _2 = (int)SEQ_PTR(_32316);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346)){
        _a_64501 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    }
    else{
        _a_64501 = (int)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    }
    if (!IS_ATOM_INT(_a_64501)){
        _a_64501 = (long)DBL_PTR(_a_64501)->dbl;
    }
    _32316 = NOVALUE;

    /** 	while a do*/
L1: 
    if (_a_64501 == 0)
    {
        goto L2; // [24] 60
    }
    else{
    }

    /** 		ifdef DEBUG then*/

    /** 		val[a] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _a_64501);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 		a = SymTab[a][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32319 = (int)*(((s1_ptr)_2)->base + _a_64501);
    _2 = (int)SEQ_PTR(_32319);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346)){
        _a_64501 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    }
    else{
        _a_64501 = (int)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    }
    if (!IS_ATOM_INT(_a_64501)){
        _a_64501 = (long)DBL_PTR(_a_64501)->dbl;
    }
    _32319 = NOVALUE;

    /** 	end while*/
    goto L1; // [57] 24
L2: 

    /** end procedure*/
    return;
    ;
}


void _67opEXIT_BLOCK()
{
    int _32322 = NOVALUE;
    int _32321 = NOVALUE;
    int _0, _1, _2;
    

    /** 	exit_block( Code[pc+1] )*/
    _32321 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32322 = (int)*(((s1_ptr)_2)->base + _32321);
    Ref(_32322);
    _67exit_block(_32322);
    _32322 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _32321 = NOVALUE;
    return;
    ;
}


void _67opRETURNP()
{
    int _arg_64522 = NOVALUE;
    int _sub_64523 = NOVALUE;
    int _caller_64524 = NOVALUE;
    int _op_64525 = NOVALUE;
    int _block_64532 = NOVALUE;
    int _sub_block_64537 = NOVALUE;
    int _local_result_64542 = NOVALUE;
    int _local_result_val_64543 = NOVALUE;
    int _32347 = NOVALUE;
    int _32345 = NOVALUE;
    int _32343 = NOVALUE;
    int _32342 = NOVALUE;
    int _32340 = NOVALUE;
    int _32338 = NOVALUE;
    int _32337 = NOVALUE;
    int _32335 = NOVALUE;
    int _32334 = NOVALUE;
    int _32332 = NOVALUE;
    int _32329 = NOVALUE;
    int _32327 = NOVALUE;
    int _32325 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer op = Code[pc]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _op_64525 = (int)*(((s1_ptr)_2)->base + _67pc_63008);
    if (!IS_ATOM_INT(_op_64525)){
        _op_64525 = (long)DBL_PTR(_op_64525)->dbl;
    }

    /** 	sub = Code[pc+1]*/
    _32325 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_64523 = (int)*(((s1_ptr)_2)->base + _32325);
    if (!IS_ATOM_INT(_sub_64523)){
        _sub_64523 = (long)DBL_PTR(_sub_64523)->dbl;
    }

    /** 	symtab_index block = Code[pc+2]*/
    _32327 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _block_64532 = (int)*(((s1_ptr)_2)->base + _32327);
    if (!IS_ATOM_INT(_block_64532)){
        _block_64532 = (long)DBL_PTR(_block_64532)->dbl;
    }

    /** 	symtab_index sub_block = SymTab[sub][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32329 = (int)*(((s1_ptr)_2)->base + _sub_64523);
    _2 = (int)SEQ_PTR(_32329);
    if (!IS_ATOM_INT(_12S_BLOCK_11374)){
        _sub_block_64537 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    }
    else{
        _sub_block_64537 = (int)*(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    }
    if (!IS_ATOM_INT(_sub_block_64537)){
        _sub_block_64537 = (long)DBL_PTR(_sub_block_64537)->dbl;
    }
    _32329 = NOVALUE;

    /** 	integer local_result = result*/
    _local_result_64542 = _67result_64495;

    /** 	object local_result_val*/

    /** 	if local_result then*/
    if (_local_result_64542 == 0)
    {
        goto L1; // [72] 95
    }
    else{
    }

    /** 		result = 0*/
    _67result_64495 = 0;

    /** 		local_result_val = result_val*/
    Ref(_67result_val_64496);
    DeRef(_local_result_val_64543);
    _local_result_val_64543 = _67result_val_64496;

    /** 		result_val = NOVALUE*/
    Ref(_12NOVALUE_11536);
    DeRef(_67result_val_64496);
    _67result_val_64496 = _12NOVALUE_11536;
L1: 

    /** 	while block != sub_block do*/
L2: 
    if (_block_64532 == _sub_block_64537)
    goto L3; // [100] 136

    /** 		if local_result then*/
    if (_local_result_64542 == 0)
    {
        goto L4; // [106] 115
    }
    else{
    }

    /** 			exit_block( block )*/
    _67exit_block(_block_64532);
L4: 

    /** 		block = SymTab[block][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32332 = (int)*(((s1_ptr)_2)->base + _block_64532);
    _2 = (int)SEQ_PTR(_32332);
    if (!IS_ATOM_INT(_12S_BLOCK_11374)){
        _block_64532 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    }
    else{
        _block_64532 = (int)*(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    }
    if (!IS_ATOM_INT(_block_64532)){
        _block_64532 = (long)DBL_PTR(_block_64532)->dbl;
    }
    _32332 = NOVALUE;

    /** 	end while*/
    goto L2; // [133] 100
L3: 

    /** 	exit_block( sub_block )*/
    _67exit_block(_sub_block_64537);

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32334 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32334 = 1;
    }
    _32335 = _32334 - 1;
    _32334 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32335);
    if (!IS_ATOM_INT(_67pc_63008))
    _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32337 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32337 = 1;
    }
    _32338 = _32337 - 2;
    _32337 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63026;
    RHS_Slice(_67call_stack_63026, 1, _32338);

    /** 	SymTab[sub][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_64523 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _32340 = NOVALUE;

    /** 	if length(call_stack) then*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32342 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32342 = 1;
    }
    if (_32342 == 0)
    {
        _32342 = NOVALUE;
        goto L5; // [194] 256
    }
    else{
        _32342 = NOVALUE;
    }

    /** 		caller = call_stack[$]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32343 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32343 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _caller_64524 = (int)*(((s1_ptr)_2)->base + _32343);
    if (!IS_ATOM_INT(_caller_64524)){
        _caller_64524 = (long)DBL_PTR(_caller_64524)->dbl;
    }

    /** 		Code = SymTab[caller][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32345 = (int)*(((s1_ptr)_2)->base + _caller_64524);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_32345);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _32345 = NOVALUE;

    /** 		restore_privates(caller)*/
    _67restore_privates(_caller_64524);

    /** 		if local_result then*/
    if (_local_result_64542 == 0)
    {
        goto L6; // [233] 268
    }
    else{
    }

    /** 			val[Code[local_result]] = local_result_val*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32347 = (int)*(((s1_ptr)_2)->base + _local_result_64542);
    Ref(_local_result_val_64543);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32347))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32347)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32347);
    _1 = *(int *)_2;
    *(int *)_2 = _local_result_val_64543;
    DeRef(_1);
    goto L6; // [253] 268
L5: 

    /** 		kill_task(current_task)*/
    _67kill_task(_67current_task_63025);

    /** 		scheduler()*/
    _67scheduler();
L6: 

    /** end procedure*/
    DeRef(_local_result_val_64543);
    DeRef(_32325);
    _32325 = NOVALUE;
    DeRef(_32327);
    _32327 = NOVALUE;
    DeRef(_32335);
    _32335 = NOVALUE;
    DeRef(_32338);
    _32338 = NOVALUE;
    _32347 = NOVALUE;
    return;
    ;
}


void _67opRETURNF()
{
    int _32353 = NOVALUE;
    int _32352 = NOVALUE;
    int _32351 = NOVALUE;
    int _32349 = NOVALUE;
    int _32348 = NOVALUE;
    int _0, _1, _2;
    

    /** 	result_val = val[Code[pc+3]]*/
    _32348 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32349 = (int)*(((s1_ptr)_2)->base + _32348);
    DeRef(_67result_val_64496);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32349)){
        _67result_val_64496 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32349)->dbl));
    }
    else{
        _67result_val_64496 = (int)*(((s1_ptr)_2)->base + _32349);
    }
    Ref(_67result_val_64496);

    /** 	result = call_stack[$-1] - 1*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32351 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32351 = 1;
    }
    _32352 = _32351 - 1;
    _32351 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _32353 = (int)*(((s1_ptr)_2)->base + _32352);
    if (IS_ATOM_INT(_32353)) {
        _67result_64495 = _32353 - 1;
    }
    else {
        _67result_64495 = binary_op(MINUS, _32353, 1);
    }
    _32353 = NOVALUE;
    if (!IS_ATOM_INT(_67result_64495)) {
        _1 = (long)(DBL_PTR(_67result_64495)->dbl);
        DeRefDS(_67result_64495);
        _67result_64495 = _1;
    }

    /** 	opRETURNP()*/
    _67opRETURNP();

    /** end procedure*/
    _32348 = NOVALUE;
    _32349 = NOVALUE;
    _32352 = NOVALUE;
    return;
    ;
}


void _67opCALL_BACK_RETURN()
{
    int _0, _1, _2;
    

    /** 	keep_running = FALSE*/
    _67keep_running_63015 = _9FALSE_429;

    /** end procedure*/
    return;
    ;
}


void _67opBADRETURNF()
{
    int _0, _1, _2;
    

    /** 	RTFatal("attempt to exit a function without returning a value")*/
    RefDS(_32355);
    _67RTFatal(_32355);

    /** end procedure*/
    return;
    ;
}


void _67opRETURNT()
{
    int _32357 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** 	if pc > length(Code) then*/
    if (IS_SEQUENCE(_12Code_11771)){
            _32357 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _32357 = 1;
    }
    if (_67pc_63008 <= _32357)
    goto L1; // [18] 32

    /** 		keep_running = FALSE  -- we've reached the end of the code*/
    _67keep_running_63015 = _9FALSE_429;
L1: 

    /** end procedure*/
    return;
    ;
}


void _67opRHS_SUBS()
{
    int _sub_64602 = NOVALUE;
    int _x_64603 = NOVALUE;
    int _32380 = NOVALUE;
    int _32379 = NOVALUE;
    int _32378 = NOVALUE;
    int _32377 = NOVALUE;
    int _32375 = NOVALUE;
    int _32374 = NOVALUE;
    int _32372 = NOVALUE;
    int _32369 = NOVALUE;
    int _32367 = NOVALUE;
    int _32363 = NOVALUE;
    int _32361 = NOVALUE;
    int _32359 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32359 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32359);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _32361 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32361);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32363 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32363);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_64603);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_64603 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_64603);

    /** 	sub = val[b]*/
    DeRef(_sub_64602);
    _2 = (int)SEQ_PTR(_67val_63018);
    _sub_64602 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_sub_64602);

    /** 	if atom(x) then*/
    _32367 = IS_ATOM(_x_64603);
    if (_32367 == 0)
    {
        _32367 = NOVALUE;
        goto L1; // [74] 83
    }
    else{
        _32367 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32368);
    _67RTFatal(_32368);
L1: 

    /** 	if sequence(sub) then*/
    _32369 = IS_SEQUENCE(_sub_64602);
    if (_32369 == 0)
    {
        _32369 = NOVALUE;
        goto L2; // [88] 97
    }
    else{
        _32369 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(reading an element of a sequence)")*/
    RefDS(_32370);
    _67RTFatal(_32370);
L2: 

    /** 	sub = floor(sub)*/
    _0 = _sub_64602;
    if (IS_ATOM_INT(_sub_64602))
    _sub_64602 = e_floor(_sub_64602);
    else
    _sub_64602 = unary_op(FLOOR, _sub_64602);
    DeRef(_0);

    /** 	if sub < 1 or sub > length(x) then*/
    if (IS_ATOM_INT(_sub_64602)) {
        _32372 = (_sub_64602 < 1);
    }
    else {
        _32372 = (DBL_PTR(_sub_64602)->dbl < (double)1);
    }
    if (_32372 != 0) {
        goto L3; // [108] 124
    }
    if (IS_SEQUENCE(_x_64603)){
            _32374 = SEQ_PTR(_x_64603)->length;
    }
    else {
        _32374 = 1;
    }
    if (IS_ATOM_INT(_sub_64602)) {
        _32375 = (_sub_64602 > _32374);
    }
    else {
        _32375 = (DBL_PTR(_sub_64602)->dbl > (double)_32374);
    }
    _32374 = NOVALUE;
    if (_32375 == 0)
    {
        DeRef(_32375);
        _32375 = NOVALUE;
        goto L4; // [120] 141
    }
    else{
        DeRef(_32375);
        _32375 = NOVALUE;
    }
L3: 

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_x_64603)){
            _32377 = SEQ_PTR(_x_64603)->length;
    }
    else {
        _32377 = 1;
    }
    Ref(_sub_64602);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _sub_64602;
    ((int *)_2)[2] = _32377;
    _32378 = MAKE_SEQ(_1);
    _32377 = NOVALUE;
    _32379 = EPrintf(-9999999, _32376, _32378);
    DeRefDS(_32378);
    _32378 = NOVALUE;
    _67RTFatal(_32379);
    _32379 = NOVALUE;
L4: 

    /** 	val[target] = x[sub]*/
    _2 = (int)SEQ_PTR(_x_64603);
    if (!IS_ATOM_INT(_sub_64602)){
        _32380 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_sub_64602)->dbl));
    }
    else{
        _32380 = (int)*(((s1_ptr)_2)->base + _sub_64602);
    }
    Ref(_32380);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32380;
    if( _1 != _32380 ){
        DeRef(_1);
    }
    _32380 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_sub_64602);
    DeRef(_x_64603);
    DeRef(_32359);
    _32359 = NOVALUE;
    DeRef(_32361);
    _32361 = NOVALUE;
    DeRef(_32363);
    _32363 = NOVALUE;
    DeRef(_32372);
    _32372 = NOVALUE;
    return;
    ;
}


void _67opGOTO()
{
    int _32382 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32382 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32382);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** end procedure*/
    _32382 = NOVALUE;
    return;
    ;
}


void _67opGLABEL()
{
    int _32384 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32384 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32384);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** end procedure*/
    _32384 = NOVALUE;
    return;
    ;
}


void _67opIF()
{
    int _32390 = NOVALUE;
    int _32388 = NOVALUE;
    int _32386 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32386 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32386);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32388 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _32388, 0)){
        _32388 = NOVALUE;
        goto L1; // [27] 50
    }
    _32388 = NOVALUE;

    /** 		pc = Code[pc+2]*/
    _32390 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32390);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** 		pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;
L2: 

    /** end procedure*/
    DeRef(_32386);
    _32386 = NOVALUE;
    DeRef(_32390);
    _32390 = NOVALUE;
    return;
    ;
}


void _67opINTEGER_CHECK()
{
    int _32398 = NOVALUE;
    int _32396 = NOVALUE;
    int _32395 = NOVALUE;
    int _32393 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32393 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32393);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if not integer(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32395 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32395))
    _32396 = 1;
    else if (IS_ATOM_DBL(_32395))
    _32396 = IS_ATOM_INT(DoubleToInt(_32395));
    else
    _32396 = 0;
    _32395 = NOVALUE;
    if (_32396 != 0)
    goto L1; // [30] 45
    _32396 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32398 = _67pc_63008 + 1;
    if (_32398 > MAXINT){
        _32398 = NewDouble((double)_32398);
    }
    _67RTFatalType(_32398);
    _32398 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_32393);
    _32393 = NOVALUE;
    return;
    ;
}


void _67opATOM_CHECK()
{
    int _32405 = NOVALUE;
    int _32403 = NOVALUE;
    int _32402 = NOVALUE;
    int _32400 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32400 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32400);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if not atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32402 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32403 = IS_ATOM(_32402);
    _32402 = NOVALUE;
    if (_32403 != 0)
    goto L1; // [30] 45
    _32403 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32405 = _67pc_63008 + 1;
    if (_32405 > MAXINT){
        _32405 = NewDouble((double)_32405);
    }
    _67RTFatalType(_32405);
    _32405 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_32400);
    _32400 = NOVALUE;
    return;
    ;
}


void _67opSEQUENCE_CHECK()
{
    int _32412 = NOVALUE;
    int _32410 = NOVALUE;
    int _32409 = NOVALUE;
    int _32407 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32407 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32407);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32409 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32410 = IS_SEQUENCE(_32409);
    _32409 = NOVALUE;
    if (_32410 != 0)
    goto L1; // [30] 45
    _32410 = NOVALUE;

    /** 		RTFatalType(pc+1)*/
    _32412 = _67pc_63008 + 1;
    if (_32412 > MAXINT){
        _32412 = NewDouble((double)_32412);
    }
    _67RTFatalType(_32412);
    _32412 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_32407);
    _32407 = NOVALUE;
    return;
    ;
}


void _67opASSIGN()
{
    int _a_64691 = NOVALUE;
    int _32419 = NOVALUE;
    int _32418 = NOVALUE;
    int _32416 = NOVALUE;
    int _32414 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer a = Code[pc+1]*/
    _32414 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _a_64691 = (int)*(((s1_ptr)_2)->base + _32414);
    if (!IS_ATOM_INT(_a_64691)){
        _a_64691 = (long)DBL_PTR(_a_64691)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32416 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32416);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32418 = (int)*(((s1_ptr)_2)->base + _a_64691);
    Ref(_32418);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32418;
    if( _1 != _32418 ){
        DeRef(_1);
    }
    _32418 = NOVALUE;

    /** 	if sym_mode( a ) = M_TEMP then*/
    _32419 = _52sym_mode(_a_64691);
    if (binary_op_a(NOTEQ, _32419, 3)){
        DeRef(_32419);
        _32419 = NOVALUE;
        goto L1; // [57] 72
    }
    DeRef(_32419);
    _32419 = NOVALUE;

    /** 		val[a] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _a_64691);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1: 

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_32414);
    _32414 = NOVALUE;
    DeRef(_32416);
    _32416 = NOVALUE;
    return;
    ;
}


void _67opELSE()
{
    int _32422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pc = Code[pc+1]*/
    _32422 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32422);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** end procedure*/
    _32422 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_N()
{
    int _x_64713 = NOVALUE;
    int _32439 = NOVALUE;
    int _32437 = NOVALUE;
    int _32436 = NOVALUE;
    int _32435 = NOVALUE;
    int _32433 = NOVALUE;
    int _32432 = NOVALUE;
    int _32430 = NOVALUE;
    int _32429 = NOVALUE;
    int _32428 = NOVALUE;
    int _32427 = NOVALUE;
    int _32426 = NOVALUE;
    int _32424 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = Code[pc+1]*/
    _32424 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67len_63014 = (int)*(((s1_ptr)_2)->base + _32424);
    if (!IS_ATOM_INT(_67len_63014)){
        _67len_63014 = (long)DBL_PTR(_67len_63014)->dbl;
    }

    /** 	x = {}*/
    RefDS(_21829);
    DeRef(_x_64713);
    _x_64713 = _21829;

    /** 	for i = pc+len+1 to pc+2 by -1 do*/
    _32426 = _67pc_63008 + _67len_63014;
    if ((long)((unsigned long)_32426 + (unsigned long)HIGH_BITS) >= 0) 
    _32426 = NewDouble((double)_32426);
    if (IS_ATOM_INT(_32426)) {
        _32427 = _32426 + 1;
        if (_32427 > MAXINT){
            _32427 = NewDouble((double)_32427);
        }
    }
    else
    _32427 = binary_op(PLUS, 1, _32426);
    DeRef(_32426);
    _32426 = NOVALUE;
    _32428 = _67pc_63008 + 2;
    if ((long)((unsigned long)_32428 + (unsigned long)HIGH_BITS) >= 0) 
    _32428 = NewDouble((double)_32428);
    {
        int _i_64718;
        Ref(_32427);
        _i_64718 = _32427;
L1: 
        if (binary_op_a(LESS, _i_64718, _32428)){
            goto L2; // [44] 111
        }

        /** 		x = append(x, val[Code[i]])*/
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_i_64718)){
            _32429 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_64718)->dbl));
        }
        else{
            _32429 = (int)*(((s1_ptr)_2)->base + _i_64718);
        }
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_32429)){
            _32430 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32429)->dbl));
        }
        else{
            _32430 = (int)*(((s1_ptr)_2)->base + _32429);
        }
        Ref(_32430);
        Append(&_x_64713, _x_64713, _32430);
        _32430 = NOVALUE;

        /** 		if sym_mode( Code[i] ) = M_TEMP then*/
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_i_64718)){
            _32432 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_64718)->dbl));
        }
        else{
            _32432 = (int)*(((s1_ptr)_2)->base + _i_64718);
        }
        Ref(_32432);
        _32433 = _52sym_mode(_32432);
        _32432 = NOVALUE;
        if (binary_op_a(NOTEQ, _32433, 3)){
            DeRef(_32433);
            _32433 = NOVALUE;
            goto L3; // [83] 104
        }
        DeRef(_32433);
        _32433 = NOVALUE;

        /** 			val[Code[i]] = NOVALUE*/
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_i_64718)){
            _32435 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_64718)->dbl));
        }
        else{
            _32435 = (int)*(((s1_ptr)_2)->base + _i_64718);
        }
        Ref(_12NOVALUE_11536);
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_32435))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32435)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _32435);
        _1 = *(int *)_2;
        *(int *)_2 = _12NOVALUE_11536;
        DeRef(_1);
L3: 

        /** 	end for*/
        _0 = _i_64718;
        if (IS_ATOM_INT(_i_64718)) {
            _i_64718 = _i_64718 + -1;
            if ((long)((unsigned long)_i_64718 +(unsigned long) HIGH_BITS) >= 0){
                _i_64718 = NewDouble((double)_i_64718);
            }
        }
        else {
            _i_64718 = binary_op_a(PLUS, _i_64718, -1);
        }
        DeRef(_0);
        goto L1; // [106] 51
L2: 
        ;
        DeRef(_i_64718);
    }

    /** 	target = Code[pc+len+2]*/
    _32436 = _67pc_63008 + _67len_63014;
    if ((long)((unsigned long)_32436 + (unsigned long)HIGH_BITS) >= 0) 
    _32436 = NewDouble((double)_32436);
    if (IS_ATOM_INT(_32436)) {
        _32437 = _32436 + 2;
    }
    else {
        _32437 = NewDouble(DBL_PTR(_32436)->dbl + (double)2);
    }
    DeRef(_32436);
    _32436 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!IS_ATOM_INT(_32437)){
        _67target_63013 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32437)->dbl));
    }
    else{
        _67target_63013 = (int)*(((s1_ptr)_2)->base + _32437);
    }
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = x*/
    RefDS(_x_64713);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _x_64713;
    DeRef(_1);

    /** 	pc += 3 + len*/
    _32439 = 3 + _67len_63014;
    if ((long)((unsigned long)_32439 + (unsigned long)HIGH_BITS) >= 0) 
    _32439 = NewDouble((double)_32439);
    if (IS_ATOM_INT(_32439)) {
        _67pc_63008 = _67pc_63008 + _32439;
    }
    else {
        _67pc_63008 = NewDouble((double)_67pc_63008 + DBL_PTR(_32439)->dbl);
    }
    DeRef(_32439);
    _32439 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }

    /** end procedure*/
    DeRefDS(_x_64713);
    DeRef(_32424);
    _32424 = NOVALUE;
    DeRef(_32428);
    _32428 = NOVALUE;
    DeRef(_32427);
    _32427 = NOVALUE;
    _32429 = NOVALUE;
    _32435 = NOVALUE;
    DeRef(_32437);
    _32437 = NOVALUE;
    return;
    ;
}


void _67opRIGHT_BRACE_2()
{
    int _32461 = NOVALUE;
    int _32460 = NOVALUE;
    int _32458 = NOVALUE;
    int _32457 = NOVALUE;
    int _32456 = NOVALUE;
    int _32455 = NOVALUE;
    int _32454 = NOVALUE;
    int _32452 = NOVALUE;
    int _32451 = NOVALUE;
    int _32450 = NOVALUE;
    int _32449 = NOVALUE;
    int _32448 = NOVALUE;
    int _32447 = NOVALUE;
    int _32446 = NOVALUE;
    int _32445 = NOVALUE;
    int _32444 = NOVALUE;
    int _32443 = NOVALUE;
    int _32441 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+3]*/
    _32441 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32441);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = {val[Code[pc+2]], val[Code[pc+1]]}*/
    _32443 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32444 = (int)*(((s1_ptr)_2)->base + _32443);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32444)){
        _32445 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32444)->dbl));
    }
    else{
        _32445 = (int)*(((s1_ptr)_2)->base + _32444);
    }
    _32446 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32447 = (int)*(((s1_ptr)_2)->base + _32446);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32447)){
        _32448 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32447)->dbl));
    }
    else{
        _32448 = (int)*(((s1_ptr)_2)->base + _32447);
    }
    Ref(_32448);
    Ref(_32445);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _32445;
    ((int *)_2)[2] = _32448;
    _32449 = MAKE_SEQ(_1);
    _32448 = NOVALUE;
    _32445 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32449;
    if( _1 != _32449 ){
        DeRef(_1);
    }
    _32449 = NOVALUE;

    /** 	if sym_mode( Code[pc+2] ) = M_TEMP then*/
    _32450 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32451 = (int)*(((s1_ptr)_2)->base + _32450);
    Ref(_32451);
    _32452 = _52sym_mode(_32451);
    _32451 = NOVALUE;
    if (binary_op_a(NOTEQ, _32452, 3)){
        DeRef(_32452);
        _32452 = NOVALUE;
        goto L1; // [87] 114
    }
    DeRef(_32452);
    _32452 = NOVALUE;

    /** 		val[Code[pc+2]] = NOVALUE*/
    _32454 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32455 = (int)*(((s1_ptr)_2)->base + _32454);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32455))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32455)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32455);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1: 

    /** 	if sym_mode( Code[pc+1] ) = M_TEMP then*/
    _32456 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32457 = (int)*(((s1_ptr)_2)->base + _32456);
    Ref(_32457);
    _32458 = _52sym_mode(_32457);
    _32457 = NOVALUE;
    if (binary_op_a(NOTEQ, _32458, 3)){
        DeRef(_32458);
        _32458 = NOVALUE;
        goto L2; // [134] 161
    }
    DeRef(_32458);
    _32458 = NOVALUE;

    /** 		val[Code[pc+1]] = NOVALUE*/
    _32460 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32461 = (int)*(((s1_ptr)_2)->base + _32460);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32461))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32461)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32461);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L2: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_32441);
    _32441 = NOVALUE;
    DeRef(_32443);
    _32443 = NOVALUE;
    _32444 = NOVALUE;
    DeRef(_32450);
    _32450 = NOVALUE;
    DeRef(_32446);
    _32446 = NOVALUE;
    _32447 = NOVALUE;
    DeRef(_32454);
    _32454 = NOVALUE;
    _32455 = NOVALUE;
    DeRef(_32456);
    _32456 = NOVALUE;
    DeRef(_32460);
    _32460 = NOVALUE;
    _32461 = NOVALUE;
    return;
    ;
}


void _67opPLUS1()
{
    int _32468 = NOVALUE;
    int _32467 = NOVALUE;
    int _32465 = NOVALUE;
    int _32463 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32463 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32463);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32465 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32465);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] + 1*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32467 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32467)) {
        _32468 = _32467 + 1;
        if (_32468 > MAXINT){
            _32468 = NewDouble((double)_32468);
        }
    }
    else
    _32468 = binary_op(PLUS, 1, _32467);
    _32467 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32468;
    if( _1 != _32468 ){
        DeRef(_1);
    }
    _32468 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _32463 = NOVALUE;
    _32465 = NOVALUE;
    return;
    ;
}


void _67opGLOBAL_INIT_CHECK()
{
    int _32478 = NOVALUE;
    int _32476 = NOVALUE;
    int _32475 = NOVALUE;
    int _32473 = NOVALUE;
    int _32472 = NOVALUE;
    int _32470 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32470 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32470);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if equal(val[a], NOVALUE) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32472 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (_32472 == _12NOVALUE_11536)
    _32473 = 1;
    else if (IS_ATOM_INT(_32472) && IS_ATOM_INT(_12NOVALUE_11536))
    _32473 = 0;
    else
    _32473 = (compare(_32472, _12NOVALUE_11536) == 0);
    _32472 = NOVALUE;
    if (_32473 == 0)
    {
        _32473 = NOVALUE;
        goto L1; // [33] 62
    }
    else{
        _32473 = NOVALUE;
    }

    /** 		RTFatal("variable " & SymTab[a][S_NAME] & " has not been assigned a value")*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _32475 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32475);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _32476 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _32476 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _32475 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _32477;
        concat_list[1] = _32476;
        concat_list[2] = _32474;
        Concat_N((object_ptr)&_32478, concat_list, 3);
    }
    _32476 = NOVALUE;
    _67RTFatal(_32478);
    _32478 = NOVALUE;
L1: 

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRef(_32470);
    _32470 = NOVALUE;
    return;
    ;
}


void _67opWHILE()
{
    int _32484 = NOVALUE;
    int _32482 = NOVALUE;
    int _32480 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32480 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32480);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32482 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _32482, 0)){
        _32482 = NOVALUE;
        goto L1; // [27] 50
    }
    _32482 = NOVALUE;

    /** 		pc = Code[pc+2]*/
    _32484 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32484);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
    goto L2; // [47] 59
L1: 

    /** 		pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;
L2: 

    /** end procedure*/
    DeRef(_32480);
    _32480 = NOVALUE;
    DeRef(_32484);
    _32484 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_SPI()
{
    int _32509 = NOVALUE;
    int _32507 = NOVALUE;
    int _32506 = NOVALUE;
    int _32505 = NOVALUE;
    int _32504 = NOVALUE;
    int _32503 = NOVALUE;
    int _32502 = NOVALUE;
    int _32501 = NOVALUE;
    int _32500 = NOVALUE;
    int _32499 = NOVALUE;
    int _32498 = NOVALUE;
    int _32497 = NOVALUE;
    int _32495 = NOVALUE;
    int _32494 = NOVALUE;
    int _32493 = NOVALUE;
    int _32492 = NOVALUE;
    int _32491 = NOVALUE;
    int _32490 = NOVALUE;
    int _32489 = NOVALUE;
    int _32488 = NOVALUE;
    int _32487 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer( val[Code[pc+1]] ) then*/
    _32487 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32488 = (int)*(((s1_ptr)_2)->base + _32487);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32488)){
        _32489 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32488)->dbl));
    }
    else{
        _32489 = (int)*(((s1_ptr)_2)->base + _32488);
    }
    if (IS_ATOM_INT(_32489))
    _32490 = 1;
    else if (IS_ATOM_DBL(_32489))
    _32490 = IS_ATOM_INT(DoubleToInt(_32489));
    else
    _32490 = 0;
    _32489 = NOVALUE;
    if (_32490 == 0)
    {
        _32490 = NOVALUE;
        goto L1; // [24] 149
    }
    else{
        _32490 = NOVALUE;
    }

    /** 		a = val[Code[pc+1]] - Code[pc+2]*/
    _32491 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32492 = (int)*(((s1_ptr)_2)->base + _32491);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32492)){
        _32493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32492)->dbl));
    }
    else{
        _32493 = (int)*(((s1_ptr)_2)->base + _32492);
    }
    _32494 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32495 = (int)*(((s1_ptr)_2)->base + _32494);
    if (IS_ATOM_INT(_32493) && IS_ATOM_INT(_32495)) {
        _67a_63009 = _32493 - _32495;
    }
    else {
        _67a_63009 = binary_op(MINUS, _32493, _32495);
    }
    _32493 = NOVALUE;
    _32495 = NOVALUE;
    if (!IS_ATOM_INT(_67a_63009)) {
        _1 = (long)(DBL_PTR(_67a_63009)->dbl);
        DeRefDS(_67a_63009);
        _67a_63009 = _1;
    }

    /** 		if a > 0 and a <= length( val[Code[pc+3]] ) then*/
    _32497 = (_67a_63009 > 0);
    if (_32497 == 0) {
        goto L2; // [73] 148
    }
    _32499 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32500 = (int)*(((s1_ptr)_2)->base + _32499);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32500)){
        _32501 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32500)->dbl));
    }
    else{
        _32501 = (int)*(((s1_ptr)_2)->base + _32500);
    }
    if (IS_SEQUENCE(_32501)){
            _32502 = SEQ_PTR(_32501)->length;
    }
    else {
        _32502 = 1;
    }
    _32501 = NOVALUE;
    _32503 = (_67a_63009 <= _32502);
    _32502 = NOVALUE;
    if (_32503 == 0)
    {
        DeRef(_32503);
        _32503 = NOVALUE;
        goto L2; // [105] 148
    }
    else{
        DeRef(_32503);
        _32503 = NOVALUE;
    }

    /** 			pc += val[Code[pc+3]][a]*/
    _32504 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32505 = (int)*(((s1_ptr)_2)->base + _32504);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32505)){
        _32506 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32505)->dbl));
    }
    else{
        _32506 = (int)*(((s1_ptr)_2)->base + _32505);
    }
    _2 = (int)SEQ_PTR(_32506);
    _32507 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32506 = NOVALUE;
    if (IS_ATOM_INT(_32507)) {
        _67pc_63008 = _67pc_63008 + _32507;
    }
    else {
        _67pc_63008 = binary_op(PLUS, _67pc_63008, _32507);
    }
    _32507 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }

    /** 			return*/
    DeRef(_32487);
    _32487 = NOVALUE;
    _32488 = NOVALUE;
    DeRef(_32491);
    _32491 = NOVALUE;
    _32492 = NOVALUE;
    DeRef(_32497);
    _32497 = NOVALUE;
    DeRef(_32494);
    _32494 = NOVALUE;
    DeRef(_32499);
    _32499 = NOVALUE;
    _32500 = NOVALUE;
    _32501 = NOVALUE;
    _32504 = NOVALUE;
    _32505 = NOVALUE;
    return;
L2: 
L1: 

    /** 	pc = Code[pc+4]*/
    _32509 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32509);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** end procedure*/
    DeRef(_32487);
    _32487 = NOVALUE;
    _32488 = NOVALUE;
    DeRef(_32491);
    _32491 = NOVALUE;
    _32492 = NOVALUE;
    DeRef(_32497);
    _32497 = NOVALUE;
    DeRef(_32494);
    _32494 = NOVALUE;
    DeRef(_32499);
    _32499 = NOVALUE;
    _32500 = NOVALUE;
    _32501 = NOVALUE;
    DeRef(_32504);
    _32504 = NOVALUE;
    _32505 = NOVALUE;
    _32509 = NOVALUE;
    return;
    ;
}


void _67opSWITCH()
{
    int _32523 = NOVALUE;
    int _32521 = NOVALUE;
    int _32520 = NOVALUE;
    int _32519 = NOVALUE;
    int _32518 = NOVALUE;
    int _32516 = NOVALUE;
    int _32515 = NOVALUE;
    int _32514 = NOVALUE;
    int _32513 = NOVALUE;
    int _32512 = NOVALUE;
    int _32511 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = find( val[Code[pc+1]], val[Code[pc+2]] )*/
    _32511 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32512 = (int)*(((s1_ptr)_2)->base + _32511);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32512)){
        _32513 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32512)->dbl));
    }
    else{
        _32513 = (int)*(((s1_ptr)_2)->base + _32512);
    }
    _32514 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32515 = (int)*(((s1_ptr)_2)->base + _32514);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32515)){
        _32516 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32515)->dbl));
    }
    else{
        _32516 = (int)*(((s1_ptr)_2)->base + _32515);
    }
    _67a_63009 = find_from(_32513, _32516, 1);
    _32513 = NOVALUE;
    _32516 = NOVALUE;

    /** 	if a then*/
    if (_67a_63009 == 0)
    {
        goto L1; // [48] 88
    }
    else{
    }

    /** 		pc += val[Code[pc+3]][a]*/
    _32518 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32519 = (int)*(((s1_ptr)_2)->base + _32518);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32519)){
        _32520 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32519)->dbl));
    }
    else{
        _32520 = (int)*(((s1_ptr)_2)->base + _32519);
    }
    _2 = (int)SEQ_PTR(_32520);
    _32521 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32520 = NOVALUE;
    if (IS_ATOM_INT(_32521)) {
        _67pc_63008 = _67pc_63008 + _32521;
    }
    else {
        _67pc_63008 = binary_op(PLUS, _67pc_63008, _32521);
    }
    _32521 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }
    goto L2; // [85] 105
L1: 

    /** 		pc = Code[pc + 4]*/
    _32523 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _32523);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_32511);
    _32511 = NOVALUE;
    _32512 = NOVALUE;
    DeRef(_32518);
    _32518 = NOVALUE;
    DeRef(_32514);
    _32514 = NOVALUE;
    _32515 = NOVALUE;
    _32519 = NOVALUE;
    DeRef(_32523);
    _32523 = NOVALUE;
    return;
    ;
}


void _67opSWITCH_RT()
{
    int _values_64880 = NOVALUE;
    int _all_ints_64885 = NOVALUE;
    int _max_64886 = NOVALUE;
    int _min_64888 = NOVALUE;
    int _sym_64893 = NOVALUE;
    int _sign_64895 = NOVALUE;
    int _new_value_64910 = NOVALUE;
    int _jump_64927 = NOVALUE;
    int _switch_table_64932 = NOVALUE;
    int _offset_64940 = NOVALUE;
    int _32575 = NOVALUE;
    int _32574 = NOVALUE;
    int _32573 = NOVALUE;
    int _32572 = NOVALUE;
    int _32571 = NOVALUE;
    int _32568 = NOVALUE;
    int _32567 = NOVALUE;
    int _32566 = NOVALUE;
    int _32565 = NOVALUE;
    int _32564 = NOVALUE;
    int _32562 = NOVALUE;
    int _32561 = NOVALUE;
    int _32560 = NOVALUE;
    int _32559 = NOVALUE;
    int _32558 = NOVALUE;
    int _32555 = NOVALUE;
    int _32554 = NOVALUE;
    int _32553 = NOVALUE;
    int _32552 = NOVALUE;
    int _32551 = NOVALUE;
    int _32549 = NOVALUE;
    int _32548 = NOVALUE;
    int _32547 = NOVALUE;
    int _32546 = NOVALUE;
    int _32545 = NOVALUE;
    int _32541 = NOVALUE;
    int _32539 = NOVALUE;
    int _32538 = NOVALUE;
    int _32537 = NOVALUE;
    int _32536 = NOVALUE;
    int _32535 = NOVALUE;
    int _32533 = NOVALUE;
    int _32532 = NOVALUE;
    int _32528 = NOVALUE;
    int _32526 = NOVALUE;
    int _32525 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = val[Code[pc+2]]*/
    _32525 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32526 = (int)*(((s1_ptr)_2)->base + _32525);
    DeRef(_values_64880);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32526)){
        _values_64880 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32526)->dbl));
    }
    else{
        _values_64880 = (int)*(((s1_ptr)_2)->base + _32526);
    }
    Ref(_values_64880);

    /** 	integer all_ints = 1*/
    _all_ints_64885 = 1;

    /** 	integer max = MININT*/
    _max_64886 = -1073741824;

    /** 	integer min = MAXINT*/
    _min_64888 = 1073741823;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_64880)){
            _32528 = SEQ_PTR(_values_64880)->length;
    }
    else {
        _32528 = 1;
    }
    {
        int _i_64891;
        _i_64891 = 1;
L1: 
        if (_i_64891 > _32528){
            goto L2; // [51] 209
        }

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_64880);
        _sym_64893 = (int)*(((s1_ptr)_2)->base + _i_64891);
        if (!IS_ATOM_INT(_sym_64893))
        _sym_64893 = (long)DBL_PTR(_sym_64893)->dbl;

        /** 		integer sign = 1*/
        _sign_64895 = 1;

        /** 		if sym < 0 then*/
        if (_sym_64893 >= 0)
        goto L3; // [71] 88

        /** 			sign = -1*/
        _sign_64895 = -1;

        /** 			sym = -sym*/
        _sym_64893 = - _sym_64893;
L3: 

        /** 		if equal(val[sym], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _32532 = (int)*(((s1_ptr)_2)->base + _sym_64893);
        if (_32532 == _12NOVALUE_11536)
        _32533 = 1;
        else if (IS_ATOM_INT(_32532) && IS_ATOM_INT(_12NOVALUE_11536))
        _32533 = 0;
        else
        _32533 = (compare(_32532, _12NOVALUE_11536) == 0);
        _32532 = NOVALUE;
        if (_32533 == 0)
        {
            _32533 = NOVALUE;
            goto L4; // [102] 131
        }
        else{
            _32533 = NOVALUE;
        }

        /** 			RTFatal( sprintf( "'%s' has not been assigned a value", {SymTab[sym][S_NAME]} ) )*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _32535 = (int)*(((s1_ptr)_2)->base + _sym_64893);
        _2 = (int)SEQ_PTR(_32535);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _32536 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _32536 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        _32535 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_32536);
        *((int *)(_2+4)) = _32536;
        _32537 = MAKE_SEQ(_1);
        _32536 = NOVALUE;
        _32538 = EPrintf(-9999999, _32534, _32537);
        DeRefDS(_32537);
        _32537 = NOVALUE;
        _67RTFatal(_32538);
        _32538 = NOVALUE;
L4: 

        /** 		object new_value = sign * val[sym]*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _32539 = (int)*(((s1_ptr)_2)->base + _sym_64893);
        DeRef(_new_value_64910);
        if (IS_ATOM_INT(_32539)) {
            if (_sign_64895 == (short)_sign_64895 && _32539 <= INT15 && _32539 >= -INT15)
            _new_value_64910 = _sign_64895 * _32539;
            else
            _new_value_64910 = NewDouble(_sign_64895 * (double)_32539);
        }
        else {
            _new_value_64910 = binary_op(MULTIPLY, _sign_64895, _32539);
        }
        _32539 = NOVALUE;

        /** 		values[i] = new_value*/
        Ref(_new_value_64910);
        _2 = (int)SEQ_PTR(_values_64880);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_64880 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_64891);
        _1 = *(int *)_2;
        *(int *)_2 = _new_value_64910;
        DeRef(_1);

        /** 		if not integer( new_value ) then*/
        if (IS_ATOM_INT(_new_value_64910))
        _32541 = 1;
        else if (IS_ATOM_DBL(_new_value_64910))
        _32541 = IS_ATOM_INT(DoubleToInt(_new_value_64910));
        else
        _32541 = 0;
        if (_32541 != 0)
        goto L5; // [154] 165
        _32541 = NOVALUE;

        /** 			all_ints = 0*/
        _all_ints_64885 = 0;
        goto L6; // [162] 200
L5: 

        /** 		elsif all_ints then*/
        if (_all_ints_64885 == 0)
        {
            goto L7; // [167] 199
        }
        else{
        }

        /** 			if new_value < min then*/
        if (binary_op_a(GREATEREQ, _new_value_64910, _min_64888)){
            goto L8; // [172] 184
        }

        /** 				min = new_value*/
        Ref(_new_value_64910);
        _min_64888 = _new_value_64910;
        if (!IS_ATOM_INT(_min_64888)) {
            _1 = (long)(DBL_PTR(_min_64888)->dbl);
            DeRefDS(_min_64888);
            _min_64888 = _1;
        }
L8: 

        /** 			if new_value > max then*/
        if (binary_op_a(LESSEQ, _new_value_64910, _max_64886)){
            goto L9; // [186] 198
        }

        /** 				max = new_value*/
        Ref(_new_value_64910);
        _max_64886 = _new_value_64910;
        if (!IS_ATOM_INT(_max_64886)) {
            _1 = (long)(DBL_PTR(_max_64886)->dbl);
            DeRefDS(_max_64886);
            _max_64886 = _1;
        }
L9: 
L7: 
L6: 
        DeRef(_new_value_64910);
        _new_value_64910 = NOVALUE;

        /** 	end for*/
        _i_64891 = _i_64891 + 1;
        goto L1; // [204] 58
L2: 
        ;
    }

    /** 	if all_ints and max - min < 1024 then*/
    if (_all_ints_64885 == 0) {
        goto LA; // [211] 412
    }
    _32546 = _max_64886 - _min_64888;
    if ((long)((unsigned long)_32546 +(unsigned long) HIGH_BITS) >= 0){
        _32546 = NewDouble((double)_32546);
    }
    if (IS_ATOM_INT(_32546)) {
        _32547 = (_32546 < 1024);
    }
    else {
        _32547 = (DBL_PTR(_32546)->dbl < (double)1024);
    }
    DeRef(_32546);
    _32546 = NOVALUE;
    if (_32547 == 0)
    {
        DeRef(_32547);
        _32547 = NOVALUE;
        goto LA; // [224] 412
    }
    else{
        DeRef(_32547);
        _32547 = NOVALUE;
    }

    /** 		Code[pc] = SWITCH_SPI*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _67pc_63008);
    _1 = *(int *)_2;
    *(int *)_2 = 192;
    DeRef(_1);

    /** 		sequence jump = val[Code[pc+3]]*/
    _32548 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32549 = (int)*(((s1_ptr)_2)->base + _32548);
    DeRef(_jump_64927);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32549)){
        _jump_64927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32549)->dbl));
    }
    else{
        _jump_64927 = (int)*(((s1_ptr)_2)->base + _32549);
    }
    Ref(_jump_64927);

    /** 		sequence switch_table = repeat( Code[pc+4] - pc, max - min + 1 )*/
    _32551 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32552 = (int)*(((s1_ptr)_2)->base + _32551);
    if (IS_ATOM_INT(_32552)) {
        _32553 = _32552 - _67pc_63008;
        if ((long)((unsigned long)_32553 +(unsigned long) HIGH_BITS) >= 0){
            _32553 = NewDouble((double)_32553);
        }
    }
    else {
        _32553 = binary_op(MINUS, _32552, _67pc_63008);
    }
    _32552 = NOVALUE;
    _32554 = _max_64886 - _min_64888;
    if ((long)((unsigned long)_32554 +(unsigned long) HIGH_BITS) >= 0){
        _32554 = NewDouble((double)_32554);
    }
    if (IS_ATOM_INT(_32554)) {
        _32555 = _32554 + 1;
    }
    else
    _32555 = binary_op(PLUS, 1, _32554);
    DeRef(_32554);
    _32554 = NOVALUE;
    DeRef(_switch_table_64932);
    _switch_table_64932 = Repeat(_32553, _32555);
    DeRef(_32553);
    _32553 = NOVALUE;
    DeRef(_32555);
    _32555 = NOVALUE;

    /** 		integer offset = min - 1*/
    _offset_64940 = _min_64888 - 1;

    /** 		for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_64880)){
            _32558 = SEQ_PTR(_values_64880)->length;
    }
    else {
        _32558 = 1;
    }
    {
        int _i_64943;
        _i_64943 = 1;
LB: 
        if (_i_64943 > _32558){
            goto LC; // [304] 336
        }

        /** 			switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_64880);
        _32559 = (int)*(((s1_ptr)_2)->base + _i_64943);
        if (IS_ATOM_INT(_32559)) {
            _32560 = _32559 - _offset_64940;
            if ((long)((unsigned long)_32560 +(unsigned long) HIGH_BITS) >= 0){
                _32560 = NewDouble((double)_32560);
            }
        }
        else {
            _32560 = binary_op(MINUS, _32559, _offset_64940);
        }
        _32559 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_64927);
        _32561 = (int)*(((s1_ptr)_2)->base + _i_64943);
        Ref(_32561);
        _2 = (int)SEQ_PTR(_switch_table_64932);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_64932 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_32560))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32560)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _32560);
        _1 = *(int *)_2;
        *(int *)_2 = _32561;
        if( _1 != _32561 ){
            DeRef(_1);
        }
        _32561 = NOVALUE;

        /** 		end for*/
        _i_64943 = _i_64943 + 1;
        goto LB; // [331] 311
LC: 
        ;
    }

    /** 		Code[pc+2] = offset*/
    _32562 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _32562);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_64940;
    DeRef(_1);

    /** 		val = append( val, switch_table )*/
    RefDS(_switch_table_64932);
    Append(&_67val_63018, _67val_63018, _switch_table_64932);

    /** 		Code[pc+3] = length(val)*/
    _32564 = _67pc_63008 + 3;
    if ((long)((unsigned long)_32564 + (unsigned long)HIGH_BITS) >= 0) 
    _32564 = NewDouble((double)_32564);
    if (IS_SEQUENCE(_67val_63018)){
            _32565 = SEQ_PTR(_67val_63018)->length;
    }
    else {
        _32565 = 1;
    }
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32564))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32564)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32564);
    _1 = *(int *)_2;
    *(int *)_2 = _32565;
    if( _1 != _32565 ){
        DeRef(_1);
    }
    _32565 = NOVALUE;

    /** 		SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32566 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32566 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _32567 = (int)*(((s1_ptr)_2)->base + _32566);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32567))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32567)->dbl));
    else
    _3 = (int)(_32567 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _32568 = NOVALUE;

    /** 		opSWITCH_SPI()*/
    _67opSWITCH_SPI();
    DeRef(_jump_64927);
    _jump_64927 = NOVALUE;
    DeRefDS(_switch_table_64932);
    _switch_table_64932 = NOVALUE;
    goto LD; // [409] 482
LA: 

    /** 		Code[pc] = SWITCH*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _67pc_63008);
    _1 = *(int *)_2;
    *(int *)_2 = 185;
    DeRef(_1);

    /** 		val = append( val, values )*/
    RefDS(_values_64880);
    Append(&_67val_63018, _67val_63018, _values_64880);

    /** 		Code[pc+2] = length(val)*/
    _32571 = _67pc_63008 + 2;
    if ((long)((unsigned long)_32571 + (unsigned long)HIGH_BITS) >= 0) 
    _32571 = NewDouble((double)_32571);
    if (IS_SEQUENCE(_67val_63018)){
            _32572 = SEQ_PTR(_67val_63018)->length;
    }
    else {
        _32572 = 1;
    }
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32571))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32571)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32571);
    _1 = *(int *)_2;
    *(int *)_2 = _32572;
    if( _1 != _32572 ){
        DeRef(_1);
    }
    _32572 = NOVALUE;

    /** 		SymTab[call_stack[$]][S_CODE] = Code*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _32573 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _32573 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _32574 = (int)*(((s1_ptr)_2)->base + _32573);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32574))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32574)->dbl));
    else
    _3 = (int)(_32574 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _32575 = NOVALUE;

    /** 		opSWITCH()*/
    _67opSWITCH();
LD: 

    /** end procedure*/
    DeRef(_values_64880);
    DeRef(_32525);
    _32525 = NOVALUE;
    _32526 = NOVALUE;
    DeRef(_32548);
    _32548 = NOVALUE;
    _32549 = NOVALUE;
    DeRef(_32551);
    _32551 = NOVALUE;
    DeRef(_32562);
    _32562 = NOVALUE;
    DeRef(_32560);
    _32560 = NOVALUE;
    DeRef(_32564);
    _32564 = NOVALUE;
    _32567 = NOVALUE;
    DeRef(_32571);
    _32571 = NOVALUE;
    _32574 = NOVALUE;
    return;
    ;
}


void _67opCASE()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


void _67opNOPSWITCH()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _67var_subs(int _x_64981, int _subs_64982)
{
    int _si_64983 = NOVALUE;
    int _32590 = NOVALUE;
    int _32589 = NOVALUE;
    int _32588 = NOVALUE;
    int _32587 = NOVALUE;
    int _32586 = NOVALUE;
    int _32584 = NOVALUE;
    int _32583 = NOVALUE;
    int _32580 = NOVALUE;
    int _32578 = NOVALUE;
    int _32577 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _32577 = IS_ATOM(_x_64981);
    if (_32577 == 0)
    {
        _32577 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _32577 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32368);
    _67RTFatal(_32368);
L1: 

    /** 	for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_64982)){
            _32578 = SEQ_PTR(_subs_64982)->length;
    }
    else {
        _32578 = 1;
    }
    {
        int _i_64987;
        _i_64987 = 1;
L2: 
        if (_i_64987 > _32578){
            goto L3; // [22] 110
        }

        /** 		si = subs[i]*/
        DeRef(_si_64983);
        _2 = (int)SEQ_PTR(_subs_64982);
        _si_64983 = (int)*(((s1_ptr)_2)->base + _i_64987);
        Ref(_si_64983);

        /** 		if sequence(si) then*/
        _32580 = IS_SEQUENCE(_si_64983);
        if (_32580 == 0)
        {
            _32580 = NOVALUE;
            goto L4; // [40] 49
        }
        else{
            _32580 = NOVALUE;
        }

        /** 			RTFatal("A subscript must be an atom")*/
        RefDS(_32581);
        _67RTFatal(_32581);
L4: 

        /** 		si = floor(si)*/
        _0 = _si_64983;
        if (IS_ATOM_INT(_si_64983))
        _si_64983 = e_floor(_si_64983);
        else
        _si_64983 = unary_op(FLOOR, _si_64983);
        DeRef(_0);

        /** 		if si > length(x) or si < 1 then*/
        if (IS_SEQUENCE(_x_64981)){
                _32583 = SEQ_PTR(_x_64981)->length;
        }
        else {
            _32583 = 1;
        }
        if (IS_ATOM_INT(_si_64983)) {
            _32584 = (_si_64983 > _32583);
        }
        else {
            _32584 = (DBL_PTR(_si_64983)->dbl > (double)_32583);
        }
        _32583 = NOVALUE;
        if (_32584 != 0) {
            goto L5; // [63] 76
        }
        if (IS_ATOM_INT(_si_64983)) {
            _32586 = (_si_64983 < 1);
        }
        else {
            _32586 = (DBL_PTR(_si_64983)->dbl < (double)1);
        }
        if (_32586 == 0)
        {
            DeRef(_32586);
            _32586 = NOVALUE;
            goto L6; // [72] 93
        }
        else{
            DeRef(_32586);
            _32586 = NOVALUE;
        }
L5: 

        /** 			RTFatal(*/
        if (IS_SEQUENCE(_x_64981)){
                _32587 = SEQ_PTR(_x_64981)->length;
        }
        else {
            _32587 = 1;
        }
        Ref(_si_64983);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _si_64983;
        ((int *)_2)[2] = _32587;
        _32588 = MAKE_SEQ(_1);
        _32587 = NOVALUE;
        _32589 = EPrintf(-9999999, _32376, _32588);
        DeRefDS(_32588);
        _32588 = NOVALUE;
        _67RTFatal(_32589);
        _32589 = NOVALUE;
L6: 

        /** 		x = x[subs[i]]*/
        _2 = (int)SEQ_PTR(_subs_64982);
        _32590 = (int)*(((s1_ptr)_2)->base + _i_64987);
        _0 = _x_64981;
        _2 = (int)SEQ_PTR(_x_64981);
        if (!IS_ATOM_INT(_32590)){
            _x_64981 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32590)->dbl));
        }
        else{
            _x_64981 = (int)*(((s1_ptr)_2)->base + _32590);
        }
        Ref(_x_64981);
        DeRef(_0);

        /** 	end for*/
        _i_64987 = _i_64987 + 1;
        goto L2; // [105] 29
L3: 
        ;
    }

    /** 	return x*/
    DeRefDS(_subs_64982);
    DeRef(_si_64983);
    DeRef(_32584);
    _32584 = NOVALUE;
    _32590 = NOVALUE;
    return _x_64981;
    ;
}


void _67opLENGTH()
{
    int _32597 = NOVALUE;
    int _32596 = NOVALUE;
    int _32594 = NOVALUE;
    int _32592 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32592 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32592);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32594 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32594);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = length(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32596 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_32596)){
            _32597 = SEQ_PTR(_32596)->length;
    }
    else {
        _32597 = 1;
    }
    _32596 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32597;
    if( _1 != _32597 ){
        DeRef(_1);
    }
    _32597 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32592 = NOVALUE;
    _32594 = NOVALUE;
    _32596 = NOVALUE;
    return;
    ;
}


void _67opPLENGTH()
{
    int _32610 = NOVALUE;
    int _32609 = NOVALUE;
    int _32608 = NOVALUE;
    int _32606 = NOVALUE;
    int _32605 = NOVALUE;
    int _32603 = NOVALUE;
    int _32601 = NOVALUE;
    int _32599 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32599 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32599);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32601 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32601);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32603 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32603);
    _67lhs_seq_index_63016 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63016)){
        _67lhs_seq_index_63016 = (long)DBL_PTR(_67lhs_seq_index_63016)->dbl;
    }
    _32603 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32605 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_32605)){
            _32606 = SEQ_PTR(_32605)->length;
    }
    else {
        _32606 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63017;
    RHS_Slice(_32605, 2, _32606);
    _32605 = NOVALUE;

    /** 	val[target] = length(var_subs(val[lhs_seq_index], lhs_subs))*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32608 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    Ref(_32608);
    RefDS(_67lhs_subs_63017);
    _32609 = _67var_subs(_32608, _67lhs_subs_63017);
    _32608 = NOVALUE;
    if (IS_SEQUENCE(_32609)){
            _32610 = SEQ_PTR(_32609)->length;
    }
    else {
        _32610 = 1;
    }
    DeRef(_32609);
    _32609 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32610;
    if( _1 != _32610 ){
        DeRef(_1);
    }
    _32610 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRefDS(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32599 = NOVALUE;
    _32601 = NOVALUE;
    _32609 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS()
{
    int _32620 = NOVALUE;
    int _32619 = NOVALUE;
    int _32618 = NOVALUE;
    int _32616 = NOVALUE;
    int _32614 = NOVALUE;
    int _32612 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _32612 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32612);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32614 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32614);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32616 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32616);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = append(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32618 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32619 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_32619);
    Append(&_32620, _32618, _32619);
    _32618 = NOVALUE;
    _32619 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32620;
    if( _1 != _32620 ){
        DeRef(_1);
    }
    _32620 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _32612 = NOVALUE;
    _32614 = NOVALUE;
    _32616 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1()
{
    int _32629 = NOVALUE;
    int _32628 = NOVALUE;
    int _32626 = NOVALUE;
    int _32624 = NOVALUE;
    int _32622 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence, or a temp that contains*/
    _32622 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32622);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32624 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32624);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32626 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32626);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = {a, val[b]}*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32628 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_32628);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _67a_63009;
    ((int *)_2)[2] = _32628;
    _32629 = MAKE_SEQ(_1);
    _32628 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32629;
    if( _1 != _32629 ){
        DeRef(_1);
    }
    _32629 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _32622 = NOVALUE;
    _32624 = NOVALUE;
    _32626 = NOVALUE;
    return;
    ;
}


void _67opLHS_SUBS1_COPY()
{
    int _32641 = NOVALUE;
    int _32640 = NOVALUE;
    int _32639 = NOVALUE;
    int _32637 = NOVALUE;
    int _32635 = NOVALUE;
    int _32633 = NOVALUE;
    int _32631 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1] -- base var sequence*/
    _32631 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32631);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2] -- subscript*/
    _32633 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32633);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3] -- temp for storing result*/
    _32635 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32635);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	c = Code[pc+4] -- temp to hold base sequence while it's manipulated*/
    _32637 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32637);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	val[c] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32639 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_32639);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67c_63011);
    _1 = *(int *)_2;
    *(int *)_2 = _32639;
    if( _1 != _32639 ){
        DeRef(_1);
    }
    _32639 = NOVALUE;

    /** 	val[target] = {c, val[b]}*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32640 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_32640);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _67c_63011;
    ((int *)_2)[2] = _32640;
    _32641 = MAKE_SEQ(_1);
    _32640 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32641;
    if( _1 != _32641 ){
        DeRef(_1);
    }
    _32641 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _32631 = NOVALUE;
    _32633 = NOVALUE;
    _32635 = NOVALUE;
    _32637 = NOVALUE;
    return;
    ;
}


void _67lhs_check_subs(int _seq_65081, int _subs_65082)
{
    int _32657 = NOVALUE;
    int _32656 = NOVALUE;
    int _32655 = NOVALUE;
    int _32653 = NOVALUE;
    int _32652 = NOVALUE;
    int _32650 = NOVALUE;
    int _32648 = NOVALUE;
    int _32647 = NOVALUE;
    int _32645 = NOVALUE;
    int _32643 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(seq) then*/
    _32643 = IS_ATOM(_seq_65081);
    if (_32643 == 0)
    {
        _32643 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _32643 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(assigning to it)")*/
    RefDS(_32644);
    _67RTFatal(_32644);
L1: 

    /** 	if sequence(subs) then*/
    _32645 = IS_SEQUENCE(_subs_65082);
    if (_32645 == 0)
    {
        _32645 = NOVALUE;
        goto L2; // [20] 36
    }
    else{
        _32645 = NOVALUE;
    }

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_seq_65081)){
            _32647 = SEQ_PTR(_seq_65081)->length;
    }
    else {
        _32647 = 1;
    }
    _32648 = EPrintf(-9999999, _32646, _32647);
    _32647 = NOVALUE;
    _67RTFatal(_32648);
    _32648 = NOVALUE;
L2: 

    /** 	subs = floor(subs)*/
    _0 = _subs_65082;
    if (IS_ATOM_INT(_subs_65082))
    _subs_65082 = e_floor(_subs_65082);
    else
    _subs_65082 = unary_op(FLOOR, _subs_65082);
    DeRef(_0);

    /** 	if subs < 1 or subs > length(seq) then*/
    if (IS_ATOM_INT(_subs_65082)) {
        _32650 = (_subs_65082 < 1);
    }
    else {
        _32650 = (DBL_PTR(_subs_65082)->dbl < (double)1);
    }
    if (_32650 != 0) {
        goto L3; // [47] 63
    }
    if (IS_SEQUENCE(_seq_65081)){
            _32652 = SEQ_PTR(_seq_65081)->length;
    }
    else {
        _32652 = 1;
    }
    if (IS_ATOM_INT(_subs_65082)) {
        _32653 = (_subs_65082 > _32652);
    }
    else {
        _32653 = (DBL_PTR(_subs_65082)->dbl > (double)_32652);
    }
    _32652 = NOVALUE;
    if (_32653 == 0)
    {
        DeRef(_32653);
        _32653 = NOVALUE;
        goto L4; // [59] 80
    }
    else{
        DeRef(_32653);
        _32653 = NOVALUE;
    }
L3: 

    /** 		RTFatal(*/
    if (IS_SEQUENCE(_seq_65081)){
            _32655 = SEQ_PTR(_seq_65081)->length;
    }
    else {
        _32655 = 1;
    }
    Ref(_subs_65082);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _subs_65082;
    ((int *)_2)[2] = _32655;
    _32656 = MAKE_SEQ(_1);
    _32655 = NOVALUE;
    _32657 = EPrintf(-9999999, _32654, _32656);
    DeRefDS(_32656);
    _32656 = NOVALUE;
    _67RTFatal(_32657);
    _32657 = NOVALUE;
L4: 

    /** end procedure*/
    DeRef(_seq_65081);
    DeRef(_subs_65082);
    DeRef(_32650);
    _32650 = NOVALUE;
    return;
    ;
}


void _67check_slice(int _seq_65103, int _lower_65104, int _upper_65105)
{
    int _len_65106 = NOVALUE;
    int _32688 = NOVALUE;
    int _32686 = NOVALUE;
    int _32685 = NOVALUE;
    int _32684 = NOVALUE;
    int _32683 = NOVALUE;
    int _32681 = NOVALUE;
    int _32680 = NOVALUE;
    int _32679 = NOVALUE;
    int _32675 = NOVALUE;
    int _32673 = NOVALUE;
    int _32672 = NOVALUE;
    int _32663 = NOVALUE;
    int _32658 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(lower) then*/
    _32658 = IS_SEQUENCE(_lower_65104);
    if (_32658 == 0)
    {
        _32658 = NOVALUE;
        goto L1; // [6] 15
    }
    else{
        _32658 = NOVALUE;
    }

    /** 		RTFatal("slice lower index is not an atom")*/
    RefDS(_32659);
    _67RTFatal(_32659);
L1: 

    /** 	lower = floor(lower)*/
    _0 = _lower_65104;
    if (IS_ATOM_INT(_lower_65104))
    _lower_65104 = e_floor(_lower_65104);
    else
    _lower_65104 = unary_op(FLOOR, _lower_65104);
    DeRef(_0);

    /** 	if lower < 1 then*/
    if (binary_op_a(GREATEREQ, _lower_65104, 1)){
        goto L2; // [22] 32
    }

    /** 		RTFatal("slice lower index is less than 1")*/
    RefDS(_32662);
    _67RTFatal(_32662);
L2: 

    /** 	if sequence(upper) then*/
    _32663 = IS_SEQUENCE(_upper_65105);
    if (_32663 == 0)
    {
        _32663 = NOVALUE;
        goto L3; // [37] 46
    }
    else{
        _32663 = NOVALUE;
    }

    /** 		RTFatal("slice upper index is not an atom")*/
    RefDS(_32664);
    _67RTFatal(_32664);
L3: 

    /** 	upper = floor(upper)*/
    _0 = _upper_65105;
    if (IS_ATOM_INT(_upper_65105))
    _upper_65105 = e_floor(_upper_65105);
    else
    _upper_65105 = unary_op(FLOOR, _upper_65105);
    DeRef(_0);

    /** 	if upper > #FFFF_FFFF then*/
    if (binary_op_a(LESSEQ, _upper_65105, _32666)){
        goto L4; // [53] 63
    }

    /** 		upper = -2147483645*/
    RefDS(_32669);
    DeRef(_upper_65105);
    _upper_65105 = _32669;
L4: 

    /** 	if upper < 0 then*/
    if (binary_op_a(GREATEREQ, _upper_65105, 0)){
        goto L5; // [65] 79
    }

    /** 		RTFatal(sprintf("slice upper index is less than 0 (%d)", upper ) )*/
    _32672 = EPrintf(-9999999, _32671, _upper_65105);
    _67RTFatal(_32672);
    _32672 = NOVALUE;
L5: 

    /** 	if atom(seq) then*/
    _32673 = IS_ATOM(_seq_65103);
    if (_32673 == 0)
    {
        _32673 = NOVALUE;
        goto L6; // [84] 93
    }
    else{
        _32673 = NOVALUE;
    }

    /** 		RTFatal("attempt to slice an atom")*/
    RefDS(_32674);
    _67RTFatal(_32674);
L6: 

    /** 	len = upper - lower + 1*/
    if (IS_ATOM_INT(_upper_65105) && IS_ATOM_INT(_lower_65104)) {
        _32675 = _upper_65105 - _lower_65104;
        if ((long)((unsigned long)_32675 +(unsigned long) HIGH_BITS) >= 0){
            _32675 = NewDouble((double)_32675);
        }
    }
    else {
        _32675 = binary_op(MINUS, _upper_65105, _lower_65104);
    }
    DeRef(_len_65106);
    if (IS_ATOM_INT(_32675)) {
        _len_65106 = _32675 + 1;
        if (_len_65106 > MAXINT){
            _len_65106 = NewDouble((double)_len_65106);
        }
    }
    else
    _len_65106 = binary_op(PLUS, 1, _32675);
    DeRef(_32675);
    _32675 = NOVALUE;

    /** 	if len < 0 then*/
    if (binary_op_a(GREATEREQ, _len_65106, 0)){
        goto L7; // [105] 115
    }

    /** 		RTFatal("slice length is less than 0")*/
    RefDS(_32678);
    _67RTFatal(_32678);
L7: 

    /** 	if lower > length(seq) + 1 or (len > 0 and lower > length(seq)) then*/
    if (IS_SEQUENCE(_seq_65103)){
            _32679 = SEQ_PTR(_seq_65103)->length;
    }
    else {
        _32679 = 1;
    }
    _32680 = _32679 + 1;
    _32679 = NOVALUE;
    if (IS_ATOM_INT(_lower_65104)) {
        _32681 = (_lower_65104 > _32680);
    }
    else {
        _32681 = binary_op(GREATER, _lower_65104, _32680);
    }
    _32680 = NOVALUE;
    if (IS_ATOM_INT(_32681)) {
        if (_32681 != 0) {
            goto L8; // [128] 156
        }
    }
    else {
        if (DBL_PTR(_32681)->dbl != 0.0) {
            goto L8; // [128] 156
        }
    }
    if (IS_ATOM_INT(_len_65106)) {
        _32683 = (_len_65106 > 0);
    }
    else {
        _32683 = (DBL_PTR(_len_65106)->dbl > (double)0);
    }
    if (_32683 == 0) {
        DeRef(_32684);
        _32684 = 0;
        goto L9; // [136] 151
    }
    if (IS_SEQUENCE(_seq_65103)){
            _32685 = SEQ_PTR(_seq_65103)->length;
    }
    else {
        _32685 = 1;
    }
    if (IS_ATOM_INT(_lower_65104)) {
        _32686 = (_lower_65104 > _32685);
    }
    else {
        _32686 = binary_op(GREATER, _lower_65104, _32685);
    }
    _32685 = NOVALUE;
    if (IS_ATOM_INT(_32686))
    _32684 = (_32686 != 0);
    else
    _32684 = DBL_PTR(_32686)->dbl != 0.0;
L9: 
    if (_32684 == 0)
    {
        _32684 = NOVALUE;
        goto LA; // [152] 162
    }
    else{
        _32684 = NOVALUE;
    }
L8: 

    /** 		RTFatal("slice starts past end of sequence")*/
    RefDS(_32687);
    _67RTFatal(_32687);
LA: 

    /** 	if upper > length(seq) then*/
    if (IS_SEQUENCE(_seq_65103)){
            _32688 = SEQ_PTR(_seq_65103)->length;
    }
    else {
        _32688 = 1;
    }
    if (binary_op_a(LESSEQ, _upper_65105, _32688)){
        _32688 = NOVALUE;
        goto LB; // [167] 177
    }
    _32688 = NOVALUE;

    /** 		RTFatal("slice ends past end of sequence")*/
    RefDS(_32690);
    _67RTFatal(_32690);
LB: 

    /** end procedure*/
    DeRef(_seq_65103);
    DeRef(_lower_65104);
    DeRef(_upper_65105);
    DeRef(_len_65106);
    DeRef(_32683);
    _32683 = NOVALUE;
    DeRef(_32681);
    _32681 = NOVALUE;
    DeRef(_32686);
    _32686 = NOVALUE;
    return;
    ;
}


void _67lhs_check_slice(int _seq_65151, int _lower_65152, int _upper_65153, int _rhs_65154)
{
    int _len_65155 = NOVALUE;
    int _32698 = NOVALUE;
    int _32697 = NOVALUE;
    int _32696 = NOVALUE;
    int _32695 = NOVALUE;
    int _32693 = NOVALUE;
    int _32692 = NOVALUE;
    int _32691 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_slice(seq, lower, upper)*/
    Ref(_seq_65151);
    Ref(_lower_65152);
    Ref(_upper_65153);
    _67check_slice(_seq_65151, _lower_65152, _upper_65153);

    /** 	len = floor(upper) - floor(lower) + 1*/
    if (IS_ATOM_INT(_upper_65153))
    _32691 = e_floor(_upper_65153);
    else
    _32691 = unary_op(FLOOR, _upper_65153);
    if (IS_ATOM_INT(_lower_65152))
    _32692 = e_floor(_lower_65152);
    else
    _32692 = unary_op(FLOOR, _lower_65152);
    if (IS_ATOM_INT(_32691) && IS_ATOM_INT(_32692)) {
        _32693 = _32691 - _32692;
        if ((long)((unsigned long)_32693 +(unsigned long) HIGH_BITS) >= 0){
            _32693 = NewDouble((double)_32693);
        }
    }
    else {
        if (IS_ATOM_INT(_32691)) {
            _32693 = NewDouble((double)_32691 - DBL_PTR(_32692)->dbl);
        }
        else {
            if (IS_ATOM_INT(_32692)) {
                _32693 = NewDouble(DBL_PTR(_32691)->dbl - (double)_32692);
            }
            else
            _32693 = NewDouble(DBL_PTR(_32691)->dbl - DBL_PTR(_32692)->dbl);
        }
    }
    DeRef(_32691);
    _32691 = NOVALUE;
    DeRef(_32692);
    _32692 = NOVALUE;
    DeRef(_len_65155);
    if (IS_ATOM_INT(_32693)) {
        _len_65155 = _32693 + 1;
        if (_len_65155 > MAXINT){
            _len_65155 = NewDouble((double)_len_65155);
        }
    }
    else
    _len_65155 = binary_op(PLUS, 1, _32693);
    DeRef(_32693);
    _32693 = NOVALUE;

    /** 	if sequence(rhs) and length(rhs) != len then*/
    _32695 = IS_SEQUENCE(_rhs_65154);
    if (_32695 == 0) {
        goto L1; // [29] 50
    }
    if (IS_SEQUENCE(_rhs_65154)){
            _32697 = SEQ_PTR(_rhs_65154)->length;
    }
    else {
        _32697 = 1;
    }
    if (IS_ATOM_INT(_len_65155)) {
        _32698 = (_32697 != _len_65155);
    }
    else {
        _32698 = ((double)_32697 != DBL_PTR(_len_65155)->dbl);
    }
    _32697 = NOVALUE;
    if (_32698 == 0)
    {
        DeRef(_32698);
        _32698 = NOVALUE;
        goto L1; // [41] 50
    }
    else{
        DeRef(_32698);
        _32698 = NOVALUE;
    }

    /** 		RTFatal("lengths do not match on assignment to slice")*/
    RefDS(_32699);
    _67RTFatal(_32699);
L1: 

    /** end procedure*/
    DeRef(_seq_65151);
    DeRef(_lower_65152);
    DeRef(_upper_65153);
    DeRef(_rhs_65154);
    DeRef(_len_65155);
    return;
    ;
}


int _67var_slice(int _x_65168, int _subs_65169, int _lower_65170, int _upper_65171)
{
    int _32718 = NOVALUE;
    int _32716 = NOVALUE;
    int _32715 = NOVALUE;
    int _32714 = NOVALUE;
    int _32713 = NOVALUE;
    int _32712 = NOVALUE;
    int _32711 = NOVALUE;
    int _32710 = NOVALUE;
    int _32708 = NOVALUE;
    int _32707 = NOVALUE;
    int _32706 = NOVALUE;
    int _32703 = NOVALUE;
    int _32702 = NOVALUE;
    int _32701 = NOVALUE;
    int _32700 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _32700 = IS_ATOM(_x_65168);
    if (_32700 == 0)
    {
        _32700 = NOVALUE;
        goto L1; // [8] 17
    }
    else{
        _32700 = NOVALUE;
    }

    /** 		RTFatal("attempt to subscript an atom\n(reading from it)")*/
    RefDS(_32368);
    _67RTFatal(_32368);
L1: 

    /** 	for i = 1 to length(subs) do*/
    if (IS_SEQUENCE(_subs_65169)){
            _32701 = SEQ_PTR(_subs_65169)->length;
    }
    else {
        _32701 = 1;
    }
    {
        int _i_65175;
        _i_65175 = 1;
L2: 
        if (_i_65175 > _32701){
            goto L3; // [22] 122
        }

        /** 		if sequence(subs[i]) then*/
        _2 = (int)SEQ_PTR(_subs_65169);
        _32702 = (int)*(((s1_ptr)_2)->base + _i_65175);
        _32703 = IS_SEQUENCE(_32702);
        _32702 = NOVALUE;
        if (_32703 == 0)
        {
            _32703 = NOVALUE;
            goto L4; // [38] 47
        }
        else{
            _32703 = NOVALUE;
        }

        /** 			RTFatal("subscript must be an atom")*/
        RefDS(_32704);
        _67RTFatal(_32704);
L4: 

        /** 		subs = floor(subs)*/
        _0 = _subs_65169;
        _subs_65169 = unary_op(FLOOR, _subs_65169);
        DeRefDS(_0);

        /** 		if subs[i] > length(x) or subs[i] < 1 then*/
        _2 = (int)SEQ_PTR(_subs_65169);
        _32706 = (int)*(((s1_ptr)_2)->base + _i_65175);
        if (IS_SEQUENCE(_x_65168)){
                _32707 = SEQ_PTR(_x_65168)->length;
        }
        else {
            _32707 = 1;
        }
        if (IS_ATOM_INT(_32706)) {
            _32708 = (_32706 > _32707);
        }
        else {
            _32708 = binary_op(GREATER, _32706, _32707);
        }
        _32706 = NOVALUE;
        _32707 = NOVALUE;
        if (IS_ATOM_INT(_32708)) {
            if (_32708 != 0) {
                goto L5; // [67] 84
            }
        }
        else {
            if (DBL_PTR(_32708)->dbl != 0.0) {
                goto L5; // [67] 84
            }
        }
        _2 = (int)SEQ_PTR(_subs_65169);
        _32710 = (int)*(((s1_ptr)_2)->base + _i_65175);
        if (IS_ATOM_INT(_32710)) {
            _32711 = (_32710 < 1);
        }
        else {
            _32711 = binary_op(LESS, _32710, 1);
        }
        _32710 = NOVALUE;
        if (_32711 == 0) {
            DeRef(_32711);
            _32711 = NOVALUE;
            goto L6; // [80] 105
        }
        else {
            if (!IS_ATOM_INT(_32711) && DBL_PTR(_32711)->dbl == 0.0){
                DeRef(_32711);
                _32711 = NOVALUE;
                goto L6; // [80] 105
            }
            DeRef(_32711);
            _32711 = NOVALUE;
        }
        DeRef(_32711);
        _32711 = NOVALUE;
L5: 

        /** 			RTFatal(*/
        _2 = (int)SEQ_PTR(_subs_65169);
        _32712 = (int)*(((s1_ptr)_2)->base + _i_65175);
        if (IS_SEQUENCE(_x_65168)){
                _32713 = SEQ_PTR(_x_65168)->length;
        }
        else {
            _32713 = 1;
        }
        Ref(_32712);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _32712;
        ((int *)_2)[2] = _32713;
        _32714 = MAKE_SEQ(_1);
        _32713 = NOVALUE;
        _32712 = NOVALUE;
        _32715 = EPrintf(-9999999, _32376, _32714);
        DeRefDS(_32714);
        _32714 = NOVALUE;
        _67RTFatal(_32715);
        _32715 = NOVALUE;
L6: 

        /** 		x = x[subs[i]]*/
        _2 = (int)SEQ_PTR(_subs_65169);
        _32716 = (int)*(((s1_ptr)_2)->base + _i_65175);
        _0 = _x_65168;
        _2 = (int)SEQ_PTR(_x_65168);
        if (!IS_ATOM_INT(_32716)){
            _x_65168 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32716)->dbl));
        }
        else{
            _x_65168 = (int)*(((s1_ptr)_2)->base + _32716);
        }
        Ref(_x_65168);
        DeRef(_0);

        /** 	end for*/
        _i_65175 = _i_65175 + 1;
        goto L2; // [117] 29
L3: 
        ;
    }

    /** 	check_slice(x, lower, upper)*/
    Ref(_x_65168);
    Ref(_lower_65170);
    Ref(_upper_65171);
    _67check_slice(_x_65168, _lower_65170, _upper_65171);

    /** 	return x[lower..upper]*/
    rhs_slice_target = (object_ptr)&_32718;
    RHS_Slice(_x_65168, _lower_65170, _upper_65171);
    DeRef(_x_65168);
    DeRefDS(_subs_65169);
    DeRef(_lower_65170);
    DeRef(_upper_65171);
    _32716 = NOVALUE;
    DeRef(_32708);
    _32708 = NOVALUE;
    return _32718;
    ;
}


int _67assign_subs(int _x_65198, int _subs_65199, int _rhs_val_65200)
{
    int _32729 = NOVALUE;
    int _32728 = NOVALUE;
    int _32727 = NOVALUE;
    int _32726 = NOVALUE;
    int _32725 = NOVALUE;
    int _32724 = NOVALUE;
    int _32723 = NOVALUE;
    int _32722 = NOVALUE;
    int _32720 = NOVALUE;
    int _32719 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lhs_check_subs(x, subs[1])*/
    _2 = (int)SEQ_PTR(_subs_65199);
    _32719 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_65198);
    Ref(_32719);
    _67lhs_check_subs(_x_65198, _32719);
    _32719 = NOVALUE;

    /** 	if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_65199)){
            _32720 = SEQ_PTR(_subs_65199)->length;
    }
    else {
        _32720 = 1;
    }
    if (_32720 != 1)
    goto L1; // [20] 37

    /** 		x[subs[1]] = rhs_val*/
    _2 = (int)SEQ_PTR(_subs_65199);
    _32722 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_rhs_val_65200);
    _2 = (int)SEQ_PTR(_x_65198);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65198 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32722))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32722)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32722);
    _1 = *(int *)_2;
    *(int *)_2 = _rhs_val_65200;
    DeRef(_1);
    goto L2; // [34] 73
L1: 

    /** 		x[subs[1]] = assign_subs(x[subs[1]], subs[2..$], rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65199);
    _32723 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_subs_65199);
    _32724 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65198);
    if (!IS_ATOM_INT(_32724)){
        _32725 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32724)->dbl));
    }
    else{
        _32725 = (int)*(((s1_ptr)_2)->base + _32724);
    }
    if (IS_SEQUENCE(_subs_65199)){
            _32726 = SEQ_PTR(_subs_65199)->length;
    }
    else {
        _32726 = 1;
    }
    rhs_slice_target = (object_ptr)&_32727;
    RHS_Slice(_subs_65199, 2, _32726);
    Ref(_rhs_val_65200);
    DeRef(_32728);
    _32728 = _rhs_val_65200;
    Ref(_32725);
    _32729 = _67assign_subs(_32725, _32727, _32728);
    _32725 = NOVALUE;
    _32727 = NOVALUE;
    _32728 = NOVALUE;
    _2 = (int)SEQ_PTR(_x_65198);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65198 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32723))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32723)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32723);
    _1 = *(int *)_2;
    *(int *)_2 = _32729;
    if( _1 != _32729 ){
        DeRef(_1);
    }
    _32729 = NOVALUE;
L2: 

    /** 	return x*/
    DeRefDS(_subs_65199);
    DeRef(_rhs_val_65200);
    _32722 = NOVALUE;
    _32723 = NOVALUE;
    _32724 = NOVALUE;
    return _x_65198;
    ;
}


int _67assign_slice(int _x_65216, int _subs_65217, int _lower_65218, int _upper_65219, int _rhs_val_65220)
{
    int _32746 = NOVALUE;
    int _32745 = NOVALUE;
    int _32744 = NOVALUE;
    int _32743 = NOVALUE;
    int _32742 = NOVALUE;
    int _32741 = NOVALUE;
    int _32740 = NOVALUE;
    int _32739 = NOVALUE;
    int _32738 = NOVALUE;
    int _32736 = NOVALUE;
    int _32735 = NOVALUE;
    int _32734 = NOVALUE;
    int _32733 = NOVALUE;
    int _32731 = NOVALUE;
    int _32730 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	lhs_check_subs(x, subs[1])*/
    _2 = (int)SEQ_PTR(_subs_65217);
    _32730 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_x_65216);
    Ref(_32730);
    _67lhs_check_subs(_x_65216, _32730);
    _32730 = NOVALUE;

    /** 	if length(subs) = 1 then*/
    if (IS_SEQUENCE(_subs_65217)){
            _32731 = SEQ_PTR(_subs_65217)->length;
    }
    else {
        _32731 = 1;
    }
    if (_32731 != 1)
    goto L1; // [20] 59

    /** 		lhs_check_slice(x[subs[1]],lower,upper,rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65217);
    _32733 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65216);
    if (!IS_ATOM_INT(_32733)){
        _32734 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32733)->dbl));
    }
    else{
        _32734 = (int)*(((s1_ptr)_2)->base + _32733);
    }
    Ref(_32734);
    Ref(_lower_65218);
    Ref(_upper_65219);
    Ref(_rhs_val_65220);
    _67lhs_check_slice(_32734, _lower_65218, _upper_65219, _rhs_val_65220);
    _32734 = NOVALUE;

    /** 		x[subs[1]][lower..upper] = rhs_val*/
    _2 = (int)SEQ_PTR(_subs_65217);
    _32735 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65216 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32735))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32735)->dbl));
    else
    _3 = (int)(_32735 + ((s1_ptr)_2)->base);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_lower_65218, _upper_65219, _rhs_val_65220);
    goto L2; // [56] 103
L1: 

    /** 		x[subs[1]] = assign_slice(x[subs[1]], subs[2..$], lower, upper, rhs_val)*/
    _2 = (int)SEQ_PTR(_subs_65217);
    _32738 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_subs_65217);
    _32739 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_x_65216);
    if (!IS_ATOM_INT(_32739)){
        _32740 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32739)->dbl));
    }
    else{
        _32740 = (int)*(((s1_ptr)_2)->base + _32739);
    }
    if (IS_SEQUENCE(_subs_65217)){
            _32741 = SEQ_PTR(_subs_65217)->length;
    }
    else {
        _32741 = 1;
    }
    rhs_slice_target = (object_ptr)&_32742;
    RHS_Slice(_subs_65217, 2, _32741);
    Ref(_lower_65218);
    DeRef(_32743);
    _32743 = _lower_65218;
    Ref(_upper_65219);
    DeRef(_32744);
    _32744 = _upper_65219;
    Ref(_rhs_val_65220);
    DeRef(_32745);
    _32745 = _rhs_val_65220;
    Ref(_32740);
    _32746 = _67assign_slice(_32740, _32742, _32743, _32744, _32745);
    _32740 = NOVALUE;
    _32742 = NOVALUE;
    _32743 = NOVALUE;
    _32744 = NOVALUE;
    _32745 = NOVALUE;
    _2 = (int)SEQ_PTR(_x_65216);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _x_65216 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32738))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32738)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32738);
    _1 = *(int *)_2;
    *(int *)_2 = _32746;
    if( _1 != _32746 ){
        DeRef(_1);
    }
    _32746 = NOVALUE;
L2: 

    /** 	return x*/
    DeRefDS(_subs_65217);
    DeRef(_lower_65218);
    DeRef(_upper_65219);
    DeRef(_rhs_val_65220);
    _32733 = NOVALUE;
    _32735 = NOVALUE;
    DeRef(_32736);
    _32736 = NOVALUE;
    _32738 = NOVALUE;
    _32739 = NOVALUE;
    return _x_65216;
    ;
}


void _67opASSIGN_SUBS()
{
    int _x_65242 = NOVALUE;
    int _subs_65243 = NOVALUE;
    int _32760 = NOVALUE;
    int _32757 = NOVALUE;
    int _32754 = NOVALUE;
    int _32752 = NOVALUE;
    int _32751 = NOVALUE;
    int _32749 = NOVALUE;
    int _32747 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]  -- the sequence*/
    _32747 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32747);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]  -- the subscript*/
    _32749 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32749);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32751 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _32752 = IS_SEQUENCE(_32751);
    _32751 = NOVALUE;
    if (_32752 == 0)
    {
        _32752 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _32752 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_32753);
    _67RTFatal(_32753);
L1: 

    /** 	c = Code[pc+3]  -- the RHS value*/
    _32754 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32754);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_65242);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65242 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65242);

    /** 	lhs_check_subs(x, val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32757 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_x_65242);
    Ref(_32757);
    _67lhs_check_subs(_x_65242, _32757);
    _32757 = NOVALUE;

    /** 	x = val[c]*/
    DeRef(_x_65242);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65242 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    Ref(_x_65242);

    /** 	subs = val[b]*/
    DeRef(_subs_65243);
    _2 = (int)SEQ_PTR(_67val_63018);
    _subs_65243 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_subs_65243);

    /** 	val[a][subs] = x  -- single LHS subscript*/
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67val_63018 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67a_63009 + ((s1_ptr)_2)->base);
    Ref(_x_65242);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_subs_65243))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_subs_65243)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _subs_65243);
    _1 = *(int *)_2;
    *(int *)_2 = _x_65242;
    DeRef(_1);
    _32760 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_x_65242);
    DeRef(_subs_65243);
    DeRef(_32747);
    _32747 = NOVALUE;
    DeRef(_32749);
    _32749 = NOVALUE;
    _32754 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SUBS()
{
    int _32780 = NOVALUE;
    int _32779 = NOVALUE;
    int _32778 = NOVALUE;
    int _32777 = NOVALUE;
    int _32776 = NOVALUE;
    int _32774 = NOVALUE;
    int _32773 = NOVALUE;
    int _32771 = NOVALUE;
    int _32769 = NOVALUE;
    int _32768 = NOVALUE;
    int _32767 = NOVALUE;
    int _32765 = NOVALUE;
    int _32763 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32763 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32763);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]  -- subscript*/
    _32765 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32765);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32767 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _32768 = IS_SEQUENCE(_32767);
    _32767 = NOVALUE;
    if (_32768 == 0)
    {
        _32768 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _32768 = NOVALUE;
    }

    /** 		RTFatal("subscript must be an atom\n(assigning to subscript of a sequence)")*/
    RefDS(_32753);
    _67RTFatal(_32753);
L1: 

    /** 	c = Code[pc+3]  -- RHS value*/
    _32769 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32769);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32771 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32771);
    _67lhs_seq_index_63016 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63016)){
        _67lhs_seq_index_63016 = (long)DBL_PTR(_67lhs_seq_index_63016)->dbl;
    }
    _32771 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32773 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_32773)){
            _32774 = SEQ_PTR(_32773)->length;
    }
    else {
        _32774 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63017;
    RHS_Slice(_32773, 2, _32774);
    _32773 = NOVALUE;

    /** 	val[lhs_seq_index] = assign_subs(val[lhs_seq_index],*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32776 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32777 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_67lhs_subs_63017) && IS_ATOM(_32777)) {
        Ref(_32777);
        Append(&_32778, _67lhs_subs_63017, _32777);
    }
    else if (IS_ATOM(_67lhs_subs_63017) && IS_SEQUENCE(_32777)) {
    }
    else {
        Concat((object_ptr)&_32778, _67lhs_subs_63017, _32777);
    }
    _32777 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _32779 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    Ref(_32776);
    Ref(_32779);
    _32780 = _67assign_subs(_32776, _32778, _32779);
    _32776 = NOVALUE;
    _32778 = NOVALUE;
    _32779 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _1 = *(int *)_2;
    *(int *)_2 = _32780;
    if( _1 != _32780 ){
        DeRef(_1);
    }
    _32780 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRefDS(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_32763);
    _32763 = NOVALUE;
    DeRef(_32765);
    _32765 = NOVALUE;
    _32769 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SUBS()
{
    int _x_65291 = NOVALUE;
    int _32791 = NOVALUE;
    int _32790 = NOVALUE;
    int _32789 = NOVALUE;
    int _32786 = NOVALUE;
    int _32784 = NOVALUE;
    int _32782 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32782 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32782);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _32784 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32784);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32786 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32786);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRef(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	x = val[a]*/
    DeRef(_x_65291);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65291 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65291);

    /** 	val[target] = var_subs(x, lhs_subs & val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32789 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_67lhs_subs_63017) && IS_ATOM(_32789)) {
        Ref(_32789);
        Append(&_32790, _67lhs_subs_63017, _32789);
    }
    else if (IS_ATOM(_67lhs_subs_63017) && IS_SEQUENCE(_32789)) {
    }
    else {
        Concat((object_ptr)&_32790, _67lhs_subs_63017, _32789);
    }
    _32789 = NOVALUE;
    Ref(_x_65291);
    _32791 = _67var_subs(_x_65291, _32790);
    _32790 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32791;
    if( _1 != _32791 ){
        DeRef(_1);
    }
    _32791 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_x_65291);
    _32782 = NOVALUE;
    _32784 = NOVALUE;
    _32786 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SUBS()
{
    int _32810 = NOVALUE;
    int _32809 = NOVALUE;
    int _32808 = NOVALUE;
    int _32807 = NOVALUE;
    int _32806 = NOVALUE;
    int _32805 = NOVALUE;
    int _32804 = NOVALUE;
    int _32802 = NOVALUE;
    int _32801 = NOVALUE;
    int _32799 = NOVALUE;
    int _32797 = NOVALUE;
    int _32795 = NOVALUE;
    int _32793 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32793 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32793);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _32795 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32795);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _32797 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32797);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32799 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32799);
    _67lhs_seq_index_63016 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63016)){
        _67lhs_seq_index_63016 = (long)DBL_PTR(_67lhs_seq_index_63016)->dbl;
    }
    _32799 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32801 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_32801)){
            _32802 = SEQ_PTR(_32801)->length;
    }
    else {
        _32802 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63017;
    RHS_Slice(_32801, 2, _32802);
    _32801 = NOVALUE;

    /** 	Code[pc+9] = Code[pc+1] -- patch upcoming op*/
    _32804 = _67pc_63008 + 9;
    if ((long)((unsigned long)_32804 + (unsigned long)HIGH_BITS) >= 0) 
    _32804 = NewDouble((double)_32804);
    _32805 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32806 = (int)*(((s1_ptr)_2)->base + _32805);
    Ref(_32806);
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32804))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32804)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32804);
    _1 = *(int *)_2;
    *(int *)_2 = _32806;
    if( _1 != _32806 ){
        DeRef(_1);
    }
    _32806 = NOVALUE;

    /** 	val[target] = var_subs(val[lhs_seq_index], lhs_subs & val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32807 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32808 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_67lhs_subs_63017) && IS_ATOM(_32808)) {
        Ref(_32808);
        Append(&_32809, _67lhs_subs_63017, _32808);
    }
    else if (IS_ATOM(_67lhs_subs_63017) && IS_SEQUENCE(_32808)) {
    }
    else {
        Concat((object_ptr)&_32809, _67lhs_subs_63017, _32808);
    }
    _32808 = NOVALUE;
    Ref(_32807);
    _32810 = _67var_subs(_32807, _32809);
    _32807 = NOVALUE;
    _32809 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32810;
    if( _1 != _32810 ){
        DeRef(_1);
    }
    _32810 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRefDS(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _32793 = NOVALUE;
    _32795 = NOVALUE;
    _32797 = NOVALUE;
    DeRef(_32804);
    _32804 = NOVALUE;
    _32805 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_OP_SLICE()
{
    int _x_65334 = NOVALUE;
    int _32835 = NOVALUE;
    int _32834 = NOVALUE;
    int _32833 = NOVALUE;
    int _32831 = NOVALUE;
    int _32829 = NOVALUE;
    int _32828 = NOVALUE;
    int _32827 = NOVALUE;
    int _32826 = NOVALUE;
    int _32825 = NOVALUE;
    int _32824 = NOVALUE;
    int _32823 = NOVALUE;
    int _32822 = NOVALUE;
    int _32820 = NOVALUE;
    int _32819 = NOVALUE;
    int _32818 = NOVALUE;
    int _32817 = NOVALUE;
    int _32815 = NOVALUE;
    int _32812 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32812 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32812);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65334);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65334 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65334);

    /** 	b = Code[pc+2]*/
    _32815 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32815);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if floor(val[b]) > length(x) or floor(val[b]) < 1 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32817 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_32817))
    _32818 = e_floor(_32817);
    else
    _32818 = unary_op(FLOOR, _32817);
    _32817 = NOVALUE;
    if (IS_SEQUENCE(_x_65334)){
            _32819 = SEQ_PTR(_x_65334)->length;
    }
    else {
        _32819 = 1;
    }
    if (IS_ATOM_INT(_32818)) {
        _32820 = (_32818 > _32819);
    }
    else {
        _32820 = (DBL_PTR(_32818)->dbl > (double)_32819);
    }
    DeRef(_32818);
    _32818 = NOVALUE;
    _32819 = NOVALUE;
    if (_32820 != 0) {
        goto L1; // [63] 87
    }
    _2 = (int)SEQ_PTR(_67val_63018);
    _32822 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_32822))
    _32823 = e_floor(_32822);
    else
    _32823 = unary_op(FLOOR, _32822);
    _32822 = NOVALUE;
    if (IS_ATOM_INT(_32823)) {
        _32824 = (_32823 < 1);
    }
    else {
        _32824 = (DBL_PTR(_32823)->dbl < (double)1);
    }
    DeRef(_32823);
    _32823 = NOVALUE;
    if (_32824 == 0)
    {
        DeRef(_32824);
        _32824 = NOVALUE;
        goto L2; // [83] 112
    }
    else{
        DeRef(_32824);
        _32824 = NOVALUE;
    }
L1: 

    /** 		RTFatal(*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32825 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_x_65334)){
            _32826 = SEQ_PTR(_x_65334)->length;
    }
    else {
        _32826 = 1;
    }
    Ref(_32825);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _32825;
    ((int *)_2)[2] = _32826;
    _32827 = MAKE_SEQ(_1);
    _32826 = NOVALUE;
    _32825 = NOVALUE;
    _32828 = EPrintf(-9999999, _32376, _32827);
    DeRefDS(_32827);
    _32827 = NOVALUE;
    _67RTFatal(_32828);
    _32828 = NOVALUE;
L2: 

    /** 	c = Code[pc+3]*/
    _32829 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32829);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _32831 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32831);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = var_slice(x, {}, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32833 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32834 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    Ref(_x_65334);
    RefDS(_21829);
    Ref(_32833);
    Ref(_32834);
    _32835 = _67var_slice(_x_65334, _21829, _32833, _32834);
    _32833 = NOVALUE;
    _32834 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32835;
    if( _1 != _32835 ){
        DeRef(_1);
    }
    _32835 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_x_65334);
    DeRef(_32812);
    _32812 = NOVALUE;
    DeRef(_32815);
    _32815 = NOVALUE;
    _32829 = NOVALUE;
    DeRef(_32820);
    _32820 = NOVALUE;
    _32831 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_OP_SLICE()
{
    int _x_65367 = NOVALUE;
    int _32855 = NOVALUE;
    int _32854 = NOVALUE;
    int _32853 = NOVALUE;
    int _32852 = NOVALUE;
    int _32851 = NOVALUE;
    int _32850 = NOVALUE;
    int _32849 = NOVALUE;
    int _32847 = NOVALUE;
    int _32844 = NOVALUE;
    int _32842 = NOVALUE;
    int _32840 = NOVALUE;
    int _32837 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32837 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32837);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65367);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65367 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65367);

    /** 	b = Code[pc+2]*/
    _32840 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32840);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _32842 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32842);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _32844 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32844);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	lhs_seq_index = x[1]*/
    _2 = (int)SEQ_PTR(_x_65367);
    _67lhs_seq_index_63016 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63016)){
        _67lhs_seq_index_63016 = (long)DBL_PTR(_67lhs_seq_index_63016)->dbl;
    }

    /** 	lhs_subs = x[2..$]*/
    if (IS_SEQUENCE(_x_65367)){
            _32847 = SEQ_PTR(_x_65367)->length;
    }
    else {
        _32847 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63017;
    RHS_Slice(_x_65367, 2, _32847);

    /** 	Code[pc+10] = Code[pc+1]*/
    _32849 = _67pc_63008 + 10;
    if ((long)((unsigned long)_32849 + (unsigned long)HIGH_BITS) >= 0) 
    _32849 = NewDouble((double)_32849);
    _32850 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32851 = (int)*(((s1_ptr)_2)->base + _32850);
    Ref(_32851);
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_32849))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_32849)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _32849);
    _1 = *(int *)_2;
    *(int *)_2 = _32851;
    if( _1 != _32851 ){
        DeRef(_1);
    }
    _32851 = NOVALUE;

    /** 	val[target] = var_slice(val[lhs_seq_index], lhs_subs, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32852 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32853 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32854 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    Ref(_32852);
    RefDS(_67lhs_subs_63017);
    Ref(_32853);
    Ref(_32854);
    _32855 = _67var_slice(_32852, _67lhs_subs_63017, _32853, _32854);
    _32852 = NOVALUE;
    _32853 = NOVALUE;
    _32854 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32855;
    if( _1 != _32855 ){
        DeRef(_1);
    }
    _32855 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRefDS(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_x_65367);
    _32837 = NOVALUE;
    _32840 = NOVALUE;
    _32842 = NOVALUE;
    _32844 = NOVALUE;
    DeRef(_32849);
    _32849 = NOVALUE;
    _32850 = NOVALUE;
    return;
    ;
}


void _67opASSIGN_SLICE()
{
    int _x_65396 = NOVALUE;
    int _32873 = NOVALUE;
    int _32872 = NOVALUE;
    int _32870 = NOVALUE;
    int _32868 = NOVALUE;
    int _32867 = NOVALUE;
    int _32866 = NOVALUE;
    int _32863 = NOVALUE;
    int _32861 = NOVALUE;
    int _32859 = NOVALUE;
    int _32857 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _32857 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32857);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _32859 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32859);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _32861 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32861);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	d = Code[pc+4]  -- rhs value to assign*/
    _32863 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67d_63012 = (int)*(((s1_ptr)_2)->base + _32863);
    if (!IS_ATOM_INT(_67d_63012)){
        _67d_63012 = (long)DBL_PTR(_67d_63012)->dbl;
    }

    /** 	x = val[a] -- avoid lingering ref count on val[a]*/
    DeRef(_x_65396);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65396 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65396);

    /** 	lhs_check_slice(x, val[b], val[c], val[d])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32866 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32867 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32868 = (int)*(((s1_ptr)_2)->base + _67d_63012);
    Ref(_x_65396);
    Ref(_32866);
    Ref(_32867);
    Ref(_32868);
    _67lhs_check_slice(_x_65396, _32866, _32867, _32868);
    _32866 = NOVALUE;
    _32867 = NOVALUE;
    _32868 = NOVALUE;

    /** 	x = val[d]*/
    DeRef(_x_65396);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65396 = (int)*(((s1_ptr)_2)->base + _67d_63012);
    Ref(_x_65396);

    /** 	val[a][val[b]..val[c]] = x*/
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _67val_63018 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67a_63009 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32872 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32873 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    assign_slice_seq = (s1_ptr *)_3;
    AssignSlice(_32872, _32873, _x_65396);
    _32872 = NOVALUE;
    _32873 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_x_65396);
    _32857 = NOVALUE;
    _32859 = NOVALUE;
    _32861 = NOVALUE;
    _32863 = NOVALUE;
    _32870 = NOVALUE;
    return;
    ;
}


void _67opPASSIGN_SLICE()
{
    int _32892 = NOVALUE;
    int _32891 = NOVALUE;
    int _32890 = NOVALUE;
    int _32889 = NOVALUE;
    int _32888 = NOVALUE;
    int _32886 = NOVALUE;
    int _32885 = NOVALUE;
    int _32883 = NOVALUE;
    int _32881 = NOVALUE;
    int _32879 = NOVALUE;
    int _32877 = NOVALUE;
    int _32875 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _32875 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32875);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _32877 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32877);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _32879 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32879);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	d = Code[pc+4]  -- rhs value to assign*/
    _32881 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67d_63012 = (int)*(((s1_ptr)_2)->base + _32881);
    if (!IS_ATOM_INT(_67d_63012)){
        _67d_63012 = (long)DBL_PTR(_67d_63012)->dbl;
    }

    /** 	lhs_seq_index = val[a][1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32883 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_32883);
    _67lhs_seq_index_63016 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_67lhs_seq_index_63016)){
        _67lhs_seq_index_63016 = (long)DBL_PTR(_67lhs_seq_index_63016)->dbl;
    }
    _32883 = NOVALUE;

    /** 	lhs_subs = val[a][2..$]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32885 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_32885)){
            _32886 = SEQ_PTR(_32885)->length;
    }
    else {
        _32886 = 1;
    }
    rhs_slice_target = (object_ptr)&_67lhs_subs_63017;
    RHS_Slice(_32885, 2, _32886);
    _32885 = NOVALUE;

    /** 	val[lhs_seq_index] = assign_slice(val[lhs_seq_index],*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32888 = (int)*(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32889 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32890 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32891 = (int)*(((s1_ptr)_2)->base + _67d_63012);
    Ref(_32888);
    RefDS(_67lhs_subs_63017);
    Ref(_32889);
    Ref(_32890);
    Ref(_32891);
    _32892 = _67assign_slice(_32888, _67lhs_subs_63017, _32889, _32890, _32891);
    _32888 = NOVALUE;
    _32889 = NOVALUE;
    _32890 = NOVALUE;
    _32891 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67lhs_seq_index_63016);
    _1 = *(int *)_2;
    *(int *)_2 = _32892;
    if( _1 != _32892 ){
        DeRef(_1);
    }
    _32892 = NOVALUE;

    /** 	lhs_subs = {}*/
    RefDS(_21829);
    DeRefDS(_67lhs_subs_63017);
    _67lhs_subs_63017 = _21829;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _32875 = NOVALUE;
    _32877 = NOVALUE;
    _32879 = NOVALUE;
    _32881 = NOVALUE;
    return;
    ;
}


void _67opRHS_SLICE()
{
    int _x_65446 = NOVALUE;
    int _32907 = NOVALUE;
    int _32906 = NOVALUE;
    int _32905 = NOVALUE;
    int _32904 = NOVALUE;
    int _32903 = NOVALUE;
    int _32900 = NOVALUE;
    int _32898 = NOVALUE;
    int _32896 = NOVALUE;
    int _32894 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]  -- sequence*/
    _32894 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32894);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]  -- 1st index*/
    _32896 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _32896);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]  -- 2nd index*/
    _32898 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _32898);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _32900 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32900);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	x = val[a]*/
    DeRef(_x_65446);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_65446 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_x_65446);

    /** 	check_slice(x, val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32903 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32904 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    Ref(_x_65446);
    Ref(_32903);
    Ref(_32904);
    _67check_slice(_x_65446, _32903, _32904);
    _32903 = NOVALUE;
    _32904 = NOVALUE;

    /** 	val[target] = x[val[b]..val[c]]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32905 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _32906 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    rhs_slice_target = (object_ptr)&_32907;
    RHS_Slice(_x_65446, _32905, _32906);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32907;
    if( _1 != _32907 ){
        DeRef(_1);
    }
    _32907 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_x_65446);
    _32894 = NOVALUE;
    _32896 = NOVALUE;
    _32898 = NOVALUE;
    _32900 = NOVALUE;
    _32905 = NOVALUE;
    _32906 = NOVALUE;
    return;
    ;
}


void _67opTYPE_CHECK()
{
    int _32913 = NOVALUE;
    int _32911 = NOVALUE;
    int _32910 = NOVALUE;
    int _32909 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if val[Code[pc-1]] = 0 then*/
    _32909 = _67pc_63008 - 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _32910 = (int)*(((s1_ptr)_2)->base + _32909);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_32910)){
        _32911 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_32910)->dbl));
    }
    else{
        _32911 = (int)*(((s1_ptr)_2)->base + _32910);
    }
    if (binary_op_a(NOTEQ, _32911, 0)){
        _32911 = NOVALUE;
        goto L1; // [21] 37
    }
    _32911 = NOVALUE;

    /** 		RTFatalType(pc-2)*/
    _32913 = _67pc_63008 - 2;
    if ((long)((unsigned long)_32913 +(unsigned long) HIGH_BITS) >= 0){
        _32913 = NewDouble((double)_32913);
    }
    _67RTFatalType(_32913);
    _32913 = NOVALUE;
L1: 

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** end procedure*/
    DeRef(_32909);
    _32909 = NOVALUE;
    _32910 = NOVALUE;
    return;
    ;
}


void _67kill_temp(int _sym_65479)
{
    int _32915 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_mode( sym ) = M_TEMP then*/
    _32915 = _52sym_mode(_sym_65479);
    if (binary_op_a(NOTEQ, _32915, 3)){
        DeRef(_32915);
        _32915 = NOVALUE;
        goto L1; // [11] 26
    }
    DeRef(_32915);
    _32915 = NOVALUE;

    /** 		val[sym] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _sym_65479);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1: 

    /** end procedure*/
    return;
    ;
}


void _67opIS_AN_INTEGER()
{
    int _32922 = NOVALUE;
    int _32921 = NOVALUE;
    int _32919 = NOVALUE;
    int _32917 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32917 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32917);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32919 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32919);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = integer(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32921 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32921))
    _32922 = 1;
    else if (IS_ATOM_DBL(_32921))
    _32922 = IS_ATOM_INT(DoubleToInt(_32921));
    else
    _32922 = 0;
    _32921 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32922;
    if( _1 != _32922 ){
        DeRef(_1);
    }
    _32922 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63009);

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32917 = NOVALUE;
    _32919 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_ATOM()
{
    int _32929 = NOVALUE;
    int _32928 = NOVALUE;
    int _32926 = NOVALUE;
    int _32924 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32924 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32924);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32926 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32926);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = atom(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32928 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32929 = IS_ATOM(_32928);
    _32928 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32929;
    if( _1 != _32929 ){
        DeRef(_1);
    }
    _32929 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63009);

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32924 = NOVALUE;
    _32926 = NOVALUE;
    return;
    ;
}


void _67opIS_A_SEQUENCE()
{
    int _32936 = NOVALUE;
    int _32935 = NOVALUE;
    int _32933 = NOVALUE;
    int _32931 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32931 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32931);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32933 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32933);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = sequence(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32935 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _32936 = IS_SEQUENCE(_32935);
    _32935 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32936;
    if( _1 != _32936 ){
        DeRef(_1);
    }
    _32936 = NOVALUE;

    /** 	kill_temp( a )*/
    _67kill_temp(_67a_63009);

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32931 = NOVALUE;
    _32933 = NOVALUE;
    return;
    ;
}


void _67opIS_AN_OBJECT()
{
    int _32945 = NOVALUE;
    int _32944 = NOVALUE;
    int _32943 = NOVALUE;
    int _32942 = NOVALUE;
    int _32940 = NOVALUE;
    int _32938 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32938 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32938);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32940 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32940);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if equal( val[a], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32942 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (_32942 == _12NOVALUE_11536)
    _32943 = 1;
    else if (IS_ATOM_INT(_32942) && IS_ATOM_INT(_12NOVALUE_11536))
    _32943 = 0;
    else
    _32943 = (compare(_32942, _12NOVALUE_11536) == 0);
    _32942 = NOVALUE;
    if (_32943 == 0)
    {
        _32943 = NOVALUE;
        goto L1; // [49] 65
    }
    else{
        _32943 = NOVALUE;
    }

    /** 		val[target] = 0*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    goto L2; // [62] 87
L1: 

    /** 		val[target] = object( val[a] )*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32944 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if( NOVALUE == _32944 ){
        _32945 = 0;
    }
    else{
        if (IS_ATOM_INT(_32944))
        _32945 = 1;
        else if (IS_ATOM_DBL(_32944)) {
             if (IS_ATOM_INT(DoubleToInt(_32944))) {
                 _32945 = 1;
                 } else {
                     _32945 = 2;
                } } else if (IS_SEQUENCE(_32944))
                _32945 = 3;
                else
                _32945 = 0;
            }
            _32944 = NOVALUE;
            _2 = (int)SEQ_PTR(_67val_63018);
            _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
            _1 = *(int *)_2;
            *(int *)_2 = _32945;
            if( _1 != _32945 ){
                DeRef(_1);
            }
            _32945 = NOVALUE;
L2: 

            /** 	kill_temp( a )*/
            _67kill_temp(_67a_63009);

            /** 	pc += 3*/
            _67pc_63008 = _67pc_63008 + 3;

            /** end procedure*/
            DeRef(_32938);
            _32938 = NOVALUE;
            DeRef(_32940);
            _32940 = NOVALUE;
            return;
    ;
}


void _67opSQRT()
{
    int _32952 = NOVALUE;
    int _32951 = NOVALUE;
    int _32949 = NOVALUE;
    int _32947 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32947 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32947);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32949 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32949);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = sqrt(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32951 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32951))
    _32952 = e_sqrt(_32951);
    else
    _32952 = unary_op(SQRT, _32951);
    _32951 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32952;
    if( _1 != _32952 ){
        DeRef(_1);
    }
    _32952 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32947 = NOVALUE;
    _32949 = NOVALUE;
    return;
    ;
}


void _67opSIN()
{
    int _32959 = NOVALUE;
    int _32958 = NOVALUE;
    int _32956 = NOVALUE;
    int _32954 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32954 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32954);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32956 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32956);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = sin(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32958 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32958))
    _32959 = e_sin(_32958);
    else
    _32959 = unary_op(SIN, _32958);
    _32958 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32959;
    if( _1 != _32959 ){
        DeRef(_1);
    }
    _32959 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32954 = NOVALUE;
    _32956 = NOVALUE;
    return;
    ;
}


void _67opCOS()
{
    int _32966 = NOVALUE;
    int _32965 = NOVALUE;
    int _32963 = NOVALUE;
    int _32961 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32961 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32961);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32963 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32963);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = cos(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32965 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32965))
    _32966 = e_cos(_32965);
    else
    _32966 = unary_op(COS, _32965);
    _32965 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32966;
    if( _1 != _32966 ){
        DeRef(_1);
    }
    _32966 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32961 = NOVALUE;
    _32963 = NOVALUE;
    return;
    ;
}


void _67opTAN()
{
    int _32973 = NOVALUE;
    int _32972 = NOVALUE;
    int _32970 = NOVALUE;
    int _32968 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32968 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32968);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32970 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32970);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = tan(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32972 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32972))
    _32973 = e_tan(_32972);
    else
    _32973 = unary_op(TAN, _32972);
    _32972 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32973;
    if( _1 != _32973 ){
        DeRef(_1);
    }
    _32973 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32968 = NOVALUE;
    _32970 = NOVALUE;
    return;
    ;
}


void _67opARCTAN()
{
    int _32980 = NOVALUE;
    int _32979 = NOVALUE;
    int _32977 = NOVALUE;
    int _32975 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32975 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32975);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32977 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32977);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = arctan(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32979 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32979))
    _32980 = e_arctan(_32979);
    else
    _32980 = unary_op(ARCTAN, _32979);
    _32979 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32980;
    if( _1 != _32980 ){
        DeRef(_1);
    }
    _32980 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32975 = NOVALUE;
    _32977 = NOVALUE;
    return;
    ;
}


void _67opLOG()
{
    int _32987 = NOVALUE;
    int _32986 = NOVALUE;
    int _32984 = NOVALUE;
    int _32982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32982 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32982);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32984 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32984);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = log(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32986 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32986))
    _32987 = e_log(_32986);
    else
    _32987 = unary_op(LOG, _32986);
    _32986 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32987;
    if( _1 != _32987 ){
        DeRef(_1);
    }
    _32987 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32982 = NOVALUE;
    _32984 = NOVALUE;
    return;
    ;
}


void _67opNOT_BITS()
{
    int _32994 = NOVALUE;
    int _32993 = NOVALUE;
    int _32991 = NOVALUE;
    int _32989 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32989 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32989);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32991 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32991);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = not_bits(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _32993 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_32993))
    _32994 = not_bits(_32993);
    else
    _32994 = unary_op(NOT_BITS, _32993);
    _32993 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _32994;
    if( _1 != _32994 ){
        DeRef(_1);
    }
    _32994 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32989 = NOVALUE;
    _32991 = NOVALUE;
    return;
    ;
}


void _67opFLOOR()
{
    int _33001 = NOVALUE;
    int _33000 = NOVALUE;
    int _32998 = NOVALUE;
    int _32996 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _32996 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _32996);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _32998 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _32998);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = floor(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33000 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33000))
    _33001 = e_floor(_33000);
    else
    _33001 = unary_op(FLOOR, _33000);
    _33000 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33001;
    if( _1 != _33001 ){
        DeRef(_1);
    }
    _33001 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _32996 = NOVALUE;
    _32998 = NOVALUE;
    return;
    ;
}


void _67opNOT_IFW()
{
    int _33008 = NOVALUE;
    int _33005 = NOVALUE;
    int _33003 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33003 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33003);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33005 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _33005, 0)){
        _33005 = NOVALUE;
        goto L1; // [27] 42
    }
    _33005 = NOVALUE;

    /** 		pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;
    goto L2; // [39] 59
L1: 

    /** 		pc = Code[pc+2]*/
    _33008 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33008);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33003);
    _33003 = NOVALUE;
    DeRef(_33008);
    _33008 = NOVALUE;
    return;
    ;
}


void _67opNOT()
{
    int _33015 = NOVALUE;
    int _33014 = NOVALUE;
    int _33012 = NOVALUE;
    int _33010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33010 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33010);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33012 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33012);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = not val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33014 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33014)) {
        _33015 = (_33014 == 0);
    }
    else {
        _33015 = unary_op(NOT, _33014);
    }
    _33014 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33015;
    if( _1 != _33015 ){
        DeRef(_1);
    }
    _33015 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33010 = NOVALUE;
    _33012 = NOVALUE;
    return;
    ;
}


void _67opUMINUS()
{
    int _33022 = NOVALUE;
    int _33021 = NOVALUE;
    int _33019 = NOVALUE;
    int _33017 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33017 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33017);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33019 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33019);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = -val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33021 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33021)) {
        if ((unsigned long)_33021 == 0xC0000000)
        _33022 = (int)NewDouble((double)-0xC0000000);
        else
        _33022 = - _33021;
    }
    else {
        _33022 = unary_op(UMINUS, _33021);
    }
    _33021 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33022;
    if( _1 != _33022 ){
        DeRef(_1);
    }
    _33022 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33017 = NOVALUE;
    _33019 = NOVALUE;
    return;
    ;
}


void _67opRAND()
{
    int _33029 = NOVALUE;
    int _33028 = NOVALUE;
    int _33026 = NOVALUE;
    int _33024 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33024 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33024);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33026 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33026);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = rand(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33028 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33028)) {
        _33029 = good_rand() % ((unsigned)_33028) + 1;
    }
    else {
        _33029 = unary_op(RAND, _33028);
    }
    _33028 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33029;
    if( _1 != _33029 ){
        DeRef(_1);
    }
    _33029 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33024 = NOVALUE;
    _33026 = NOVALUE;
    return;
    ;
}


void _67opDIV2()
{
    int _33036 = NOVALUE;
    int _33035 = NOVALUE;
    int _33033 = NOVALUE;
    int _33031 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33031 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33031);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33033 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33033);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] / 2*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33035 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33035)) {
        if (_33035 & 1) {
            _33036 = NewDouble((_33035 >> 1) + 0.5);
        }
        else
        _33036 = _33035 >> 1;
    }
    else {
        _33036 = binary_op(DIVIDE, _33035, 2);
    }
    _33035 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33036;
    if( _1 != _33036 ){
        DeRef(_1);
    }
    _33036 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33031 = NOVALUE;
    _33033 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV2()
{
    int _33043 = NOVALUE;
    int _33042 = NOVALUE;
    int _33040 = NOVALUE;
    int _33038 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33038 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33038);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33040 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33040);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = floor(val[a] / 2)*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33042 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33042)) {
        _33043 = _33042 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _33042, 2);
        _33043 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    _33042 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33043;
    if( _1 != _33043 ){
        DeRef(_1);
    }
    _33043 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33038 = NOVALUE;
    _33040 = NOVALUE;
    return;
    ;
}


void _67opGREATER_IFW()
{
    int _33053 = NOVALUE;
    int _33050 = NOVALUE;
    int _33049 = NOVALUE;
    int _33047 = NOVALUE;
    int _33045 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33045 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33045);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33047 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33047);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if val[a] > val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33049 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33050 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(LESSEQ, _33049, _33050)){
        _33049 = NOVALUE;
        _33050 = NOVALUE;
        goto L1; // [51] 66
    }
    _33049 = NOVALUE;
    _33050 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33053 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33053);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33045);
    _33045 = NOVALUE;
    DeRef(_33047);
    _33047 = NOVALUE;
    DeRef(_33053);
    _33053 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ_IFW()
{
    int _33063 = NOVALUE;
    int _33060 = NOVALUE;
    int _33059 = NOVALUE;
    int _33057 = NOVALUE;
    int _33055 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33055 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33055);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33057 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33057);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if val[a] != val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33059 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33060 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(EQUALS, _33059, _33060)){
        _33059 = NOVALUE;
        _33060 = NOVALUE;
        goto L1; // [51] 66
    }
    _33059 = NOVALUE;
    _33060 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33063 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33063);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33055);
    _33055 = NOVALUE;
    DeRef(_33057);
    _33057 = NOVALUE;
    DeRef(_33063);
    _33063 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ_IFW()
{
    int _33073 = NOVALUE;
    int _33070 = NOVALUE;
    int _33069 = NOVALUE;
    int _33067 = NOVALUE;
    int _33065 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33065 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33065);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33067 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33067);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if val[a] <= val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33069 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33070 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(GREATER, _33069, _33070)){
        _33069 = NOVALUE;
        _33070 = NOVALUE;
        goto L1; // [51] 66
    }
    _33069 = NOVALUE;
    _33070 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33073 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33073);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33065);
    _33065 = NOVALUE;
    DeRef(_33067);
    _33067 = NOVALUE;
    DeRef(_33073);
    _33073 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ_IFW()
{
    int _33083 = NOVALUE;
    int _33080 = NOVALUE;
    int _33079 = NOVALUE;
    int _33077 = NOVALUE;
    int _33075 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33075 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33075);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33077 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33077);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if val[a] >= val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33079 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33080 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(LESS, _33079, _33080)){
        _33079 = NOVALUE;
        _33080 = NOVALUE;
        goto L1; // [51] 66
    }
    _33079 = NOVALUE;
    _33080 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33083 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33083);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33075);
    _33075 = NOVALUE;
    DeRef(_33077);
    _33077 = NOVALUE;
    DeRef(_33083);
    _33083 = NOVALUE;
    return;
    ;
}


void _67opEQUALS_IFW()
{
    int _33099 = NOVALUE;
    int _33096 = NOVALUE;
    int _33095 = NOVALUE;
    int _33093 = NOVALUE;
    int _33092 = NOVALUE;
    int _33090 = NOVALUE;
    int _33089 = NOVALUE;
    int _33087 = NOVALUE;
    int _33085 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33085 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33085);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33087 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33087);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if sequence( val[a] ) or sequence( val[b] ) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33089 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33090 = IS_SEQUENCE(_33089);
    _33089 = NOVALUE;
    if (_33090 != 0) {
        goto L1; // [46] 66
    }
    _2 = (int)SEQ_PTR(_67val_63018);
    _33092 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33093 = IS_SEQUENCE(_33092);
    _33092 = NOVALUE;
    if (_33093 == 0)
    {
        _33093 = NOVALUE;
        goto L2; // [62] 72
    }
    else{
        _33093 = NOVALUE;
    }
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	if val[a] = val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33095 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33096 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(NOTEQ, _33095, _33096)){
        _33095 = NOVALUE;
        _33096 = NOVALUE;
        goto L3; // [90] 105
    }
    _33095 = NOVALUE;
    _33096 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L4; // [102] 122
L3: 

    /** 		pc = Code[pc+3]*/
    _33099 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33099);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L4: 

    /** end procedure*/
    DeRef(_33085);
    _33085 = NOVALUE;
    DeRef(_33087);
    _33087 = NOVALUE;
    DeRef(_33099);
    _33099 = NOVALUE;
    return;
    ;
}


void _67opLESS_IFW()
{
    int _33109 = NOVALUE;
    int _33106 = NOVALUE;
    int _33105 = NOVALUE;
    int _33103 = NOVALUE;
    int _33101 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33101 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33101);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33103 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33103);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if val[a] < val[b] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33105 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33106 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(GREATEREQ, _33105, _33106)){
        _33105 = NOVALUE;
        _33106 = NOVALUE;
        goto L1; // [51] 66
    }
    _33105 = NOVALUE;
    _33106 = NOVALUE;

    /** 		pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;
    goto L2; // [63] 83
L1: 

    /** 		pc = Code[pc+3]*/
    _33109 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33109);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_33101);
    _33101 = NOVALUE;
    DeRef(_33103);
    _33103 = NOVALUE;
    DeRef(_33109);
    _33109 = NOVALUE;
    return;
    ;
}


void _67opMULTIPLY()
{
    int _33119 = NOVALUE;
    int _33118 = NOVALUE;
    int _33117 = NOVALUE;
    int _33115 = NOVALUE;
    int _33113 = NOVALUE;
    int _33111 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33111 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33111);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33113 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33113);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33115 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33115);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] * val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33117 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33118 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33117) && IS_ATOM_INT(_33118)) {
        if (_33117 == (short)_33117 && _33118 <= INT15 && _33118 >= -INT15)
        _33119 = _33117 * _33118;
        else
        _33119 = NewDouble(_33117 * (double)_33118);
    }
    else {
        _33119 = binary_op(MULTIPLY, _33117, _33118);
    }
    _33117 = NOVALUE;
    _33118 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33119;
    if( _1 != _33119 ){
        DeRef(_1);
    }
    _33119 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33111 = NOVALUE;
    _33113 = NOVALUE;
    _33115 = NOVALUE;
    return;
    ;
}


void _67opPLUS()
{
    int _33129 = NOVALUE;
    int _33128 = NOVALUE;
    int _33127 = NOVALUE;
    int _33125 = NOVALUE;
    int _33123 = NOVALUE;
    int _33121 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33121 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33121);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33123 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33123);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33125 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33125);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] + val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33127 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33128 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33127) && IS_ATOM_INT(_33128)) {
        _33129 = _33127 + _33128;
        if ((long)((unsigned long)_33129 + (unsigned long)HIGH_BITS) >= 0) 
        _33129 = NewDouble((double)_33129);
    }
    else {
        _33129 = binary_op(PLUS, _33127, _33128);
    }
    _33127 = NOVALUE;
    _33128 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33129;
    if( _1 != _33129 ){
        DeRef(_1);
    }
    _33129 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33121 = NOVALUE;
    _33123 = NOVALUE;
    _33125 = NOVALUE;
    return;
    ;
}


void _67opMINUS()
{
    int _33139 = NOVALUE;
    int _33138 = NOVALUE;
    int _33137 = NOVALUE;
    int _33135 = NOVALUE;
    int _33133 = NOVALUE;
    int _33131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33131 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33131);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33133 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33133);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33135 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33135);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] - val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33137 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33138 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33137) && IS_ATOM_INT(_33138)) {
        _33139 = _33137 - _33138;
        if ((long)((unsigned long)_33139 +(unsigned long) HIGH_BITS) >= 0){
            _33139 = NewDouble((double)_33139);
        }
    }
    else {
        _33139 = binary_op(MINUS, _33137, _33138);
    }
    _33137 = NOVALUE;
    _33138 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33139;
    if( _1 != _33139 ){
        DeRef(_1);
    }
    _33139 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33131 = NOVALUE;
    _33133 = NOVALUE;
    _33135 = NOVALUE;
    return;
    ;
}


void _67opOR()
{
    int _33149 = NOVALUE;
    int _33148 = NOVALUE;
    int _33147 = NOVALUE;
    int _33145 = NOVALUE;
    int _33143 = NOVALUE;
    int _33141 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33141 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33141);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33143 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33143);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33145 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33145);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] or val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33147 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33148 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33147) && IS_ATOM_INT(_33148)) {
        _33149 = (_33147 != 0 || _33148 != 0);
    }
    else {
        _33149 = binary_op(OR, _33147, _33148);
    }
    _33147 = NOVALUE;
    _33148 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33149;
    if( _1 != _33149 ){
        DeRef(_1);
    }
    _33149 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33141 = NOVALUE;
    _33143 = NOVALUE;
    _33145 = NOVALUE;
    return;
    ;
}


void _67opXOR()
{
    int _33159 = NOVALUE;
    int _33158 = NOVALUE;
    int _33157 = NOVALUE;
    int _33155 = NOVALUE;
    int _33153 = NOVALUE;
    int _33151 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33151 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33151);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33153 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33153);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33155 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33155);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] xor val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33157 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33158 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33157) && IS_ATOM_INT(_33158)) {
        _33159 = ((_33157 != 0) != (_33158 != 0));
    }
    else {
        _33159 = binary_op(XOR, _33157, _33158);
    }
    _33157 = NOVALUE;
    _33158 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33159;
    if( _1 != _33159 ){
        DeRef(_1);
    }
    _33159 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33151 = NOVALUE;
    _33153 = NOVALUE;
    _33155 = NOVALUE;
    return;
    ;
}


void _67opAND()
{
    int _33169 = NOVALUE;
    int _33168 = NOVALUE;
    int _33167 = NOVALUE;
    int _33165 = NOVALUE;
    int _33163 = NOVALUE;
    int _33161 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33161 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33161);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33163 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33163);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33165 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33165);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] and val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33167 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33168 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33167) && IS_ATOM_INT(_33168)) {
        _33169 = (_33167 != 0 && _33168 != 0);
    }
    else {
        _33169 = binary_op(AND, _33167, _33168);
    }
    _33167 = NOVALUE;
    _33168 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33169;
    if( _1 != _33169 ){
        DeRef(_1);
    }
    _33169 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33161 = NOVALUE;
    _33163 = NOVALUE;
    _33165 = NOVALUE;
    return;
    ;
}


void _67opDIVIDE()
{
    int _33182 = NOVALUE;
    int _33181 = NOVALUE;
    int _33180 = NOVALUE;
    int _33178 = NOVALUE;
    int _33177 = NOVALUE;
    int _33175 = NOVALUE;
    int _33173 = NOVALUE;
    int _33171 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33171 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33171);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33173 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33173);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33175 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33175);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33177 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (_33177 == 0)
    _33178 = 1;
    else if (IS_ATOM_INT(_33177) && IS_ATOM_INT(0))
    _33178 = 0;
    else
    _33178 = (compare(_33177, 0) == 0);
    _33177 = NOVALUE;
    if (_33178 == 0)
    {
        _33178 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33178 = NOVALUE;
    }

    /** 		RTFatal("attempt to divide by 0")*/
    RefDS(_33179);
    _67RTFatal(_33179);
L1: 

    /** 	val[target] = val[a] / val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33180 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33181 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33180) && IS_ATOM_INT(_33181)) {
        _33182 = (_33180 % _33181) ? NewDouble((double)_33180 / _33181) : (_33180 / _33181);
    }
    else {
        _33182 = binary_op(DIVIDE, _33180, _33181);
    }
    _33180 = NOVALUE;
    _33181 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33182;
    if( _1 != _33182 ){
        DeRef(_1);
    }
    _33182 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33171);
    _33171 = NOVALUE;
    DeRef(_33173);
    _33173 = NOVALUE;
    DeRef(_33175);
    _33175 = NOVALUE;
    return;
    ;
}


void _67opREMAINDER()
{
    int _33195 = NOVALUE;
    int _33194 = NOVALUE;
    int _33193 = NOVALUE;
    int _33191 = NOVALUE;
    int _33190 = NOVALUE;
    int _33188 = NOVALUE;
    int _33186 = NOVALUE;
    int _33184 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33184 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33184);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33186 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33186);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33188 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33188);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33190 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (_33190 == 0)
    _33191 = 1;
    else if (IS_ATOM_INT(_33190) && IS_ATOM_INT(0))
    _33191 = 0;
    else
    _33191 = (compare(_33190, 0) == 0);
    _33190 = NOVALUE;
    if (_33191 == 0)
    {
        _33191 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33191 = NOVALUE;
    }

    /** 		RTFatal("Can't get remainder of a number divided by 0")*/
    RefDS(_33192);
    _67RTFatal(_33192);
L1: 

    /** 	val[target] = remainder(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33193 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33194 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33193) && IS_ATOM_INT(_33194)) {
        _33195 = (_33193 % _33194);
    }
    else {
        _33195 = binary_op(REMAINDER, _33193, _33194);
    }
    _33193 = NOVALUE;
    _33194 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33195;
    if( _1 != _33195 ){
        DeRef(_1);
    }
    _33195 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33184);
    _33184 = NOVALUE;
    DeRef(_33186);
    _33186 = NOVALUE;
    DeRef(_33188);
    _33188 = NOVALUE;
    return;
    ;
}


void _67opFLOOR_DIV()
{
    int _33207 = NOVALUE;
    int _33206 = NOVALUE;
    int _33205 = NOVALUE;
    int _33204 = NOVALUE;
    int _33203 = NOVALUE;
    int _33201 = NOVALUE;
    int _33199 = NOVALUE;
    int _33197 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33197 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33197);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33199 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33199);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33201 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33201);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if equal(val[b], 0) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33203 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (_33203 == 0)
    _33204 = 1;
    else if (IS_ATOM_INT(_33203) && IS_ATOM_INT(0))
    _33204 = 0;
    else
    _33204 = (compare(_33203, 0) == 0);
    _33203 = NOVALUE;
    if (_33204 == 0)
    {
        _33204 = NOVALUE;
        goto L1; // [63] 72
    }
    else{
        _33204 = NOVALUE;
    }

    /** 		RTFatal("attempt to divide by 0")*/
    RefDS(_33179);
    _67RTFatal(_33179);
L1: 

    /** 	val[target] = floor(val[a] / val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33205 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33206 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33205) && IS_ATOM_INT(_33206)) {
        if (_33206 > 0 && _33205 >= 0) {
            _33207 = _33205 / _33206;
        }
        else {
            temp_dbl = floor((double)_33205 / (double)_33206);
            if (_33205 != MININT)
            _33207 = (long)temp_dbl;
            else
            _33207 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _33205, _33206);
        _33207 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _33205 = NOVALUE;
    _33206 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33207;
    if( _1 != _33207 ){
        DeRef(_1);
    }
    _33207 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33197);
    _33197 = NOVALUE;
    DeRef(_33199);
    _33199 = NOVALUE;
    DeRef(_33201);
    _33201 = NOVALUE;
    return;
    ;
}


void _67opAND_BITS()
{
    int _33217 = NOVALUE;
    int _33216 = NOVALUE;
    int _33215 = NOVALUE;
    int _33213 = NOVALUE;
    int _33211 = NOVALUE;
    int _33209 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33209 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33209);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33211 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33211);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33213 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33213);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = and_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33215 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33216 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33215) && IS_ATOM_INT(_33216)) {
        {unsigned long tu;
             tu = (unsigned long)_33215 & (unsigned long)_33216;
             _33217 = MAKE_UINT(tu);
        }
    }
    else {
        _33217 = binary_op(AND_BITS, _33215, _33216);
    }
    _33215 = NOVALUE;
    _33216 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33217;
    if( _1 != _33217 ){
        DeRef(_1);
    }
    _33217 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33209 = NOVALUE;
    _33211 = NOVALUE;
    _33213 = NOVALUE;
    return;
    ;
}


void _67opOR_BITS()
{
    int _33227 = NOVALUE;
    int _33226 = NOVALUE;
    int _33225 = NOVALUE;
    int _33223 = NOVALUE;
    int _33221 = NOVALUE;
    int _33219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33219 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33219);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33221 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33221);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33223 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33223);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = or_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33225 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33226 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33225) && IS_ATOM_INT(_33226)) {
        {unsigned long tu;
             tu = (unsigned long)_33225 | (unsigned long)_33226;
             _33227 = MAKE_UINT(tu);
        }
    }
    else {
        _33227 = binary_op(OR_BITS, _33225, _33226);
    }
    _33225 = NOVALUE;
    _33226 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33227;
    if( _1 != _33227 ){
        DeRef(_1);
    }
    _33227 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33219 = NOVALUE;
    _33221 = NOVALUE;
    _33223 = NOVALUE;
    return;
    ;
}


void _67opXOR_BITS()
{
    int _33237 = NOVALUE;
    int _33236 = NOVALUE;
    int _33235 = NOVALUE;
    int _33233 = NOVALUE;
    int _33231 = NOVALUE;
    int _33229 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33229 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33229);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33231 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33231);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33233 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33233);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = xor_bits(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33235 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33236 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33235) && IS_ATOM_INT(_33236)) {
        {unsigned long tu;
             tu = (unsigned long)_33235 ^ (unsigned long)_33236;
             _33237 = MAKE_UINT(tu);
        }
    }
    else {
        _33237 = binary_op(XOR_BITS, _33235, _33236);
    }
    _33235 = NOVALUE;
    _33236 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33237;
    if( _1 != _33237 ){
        DeRef(_1);
    }
    _33237 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33229 = NOVALUE;
    _33231 = NOVALUE;
    _33233 = NOVALUE;
    return;
    ;
}


void _67opPOWER()
{
    int _33247 = NOVALUE;
    int _33246 = NOVALUE;
    int _33245 = NOVALUE;
    int _33243 = NOVALUE;
    int _33241 = NOVALUE;
    int _33239 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33239 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33239);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33241 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33241);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33243 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33243);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = power(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33245 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33246 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33245) && IS_ATOM_INT(_33246)) {
        _33247 = power(_33245, _33246);
    }
    else {
        _33247 = binary_op(POWER, _33245, _33246);
    }
    _33245 = NOVALUE;
    _33246 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33247;
    if( _1 != _33247 ){
        DeRef(_1);
    }
    _33247 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33239 = NOVALUE;
    _33241 = NOVALUE;
    _33243 = NOVALUE;
    return;
    ;
}


void _67opLESS()
{
    int _33257 = NOVALUE;
    int _33256 = NOVALUE;
    int _33255 = NOVALUE;
    int _33253 = NOVALUE;
    int _33251 = NOVALUE;
    int _33249 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33249 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33249);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33251 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33251);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33253 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33253);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] < val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33255 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33256 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33255) && IS_ATOM_INT(_33256)) {
        _33257 = (_33255 < _33256);
    }
    else {
        _33257 = binary_op(LESS, _33255, _33256);
    }
    _33255 = NOVALUE;
    _33256 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33257;
    if( _1 != _33257 ){
        DeRef(_1);
    }
    _33257 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33249 = NOVALUE;
    _33251 = NOVALUE;
    _33253 = NOVALUE;
    return;
    ;
}


void _67opGREATER()
{
    int _33267 = NOVALUE;
    int _33266 = NOVALUE;
    int _33265 = NOVALUE;
    int _33263 = NOVALUE;
    int _33261 = NOVALUE;
    int _33259 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33259 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33259);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33261 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33261);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33263 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33263);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] > val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33265 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33266 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33265) && IS_ATOM_INT(_33266)) {
        _33267 = (_33265 > _33266);
    }
    else {
        _33267 = binary_op(GREATER, _33265, _33266);
    }
    _33265 = NOVALUE;
    _33266 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33267;
    if( _1 != _33267 ){
        DeRef(_1);
    }
    _33267 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33259 = NOVALUE;
    _33261 = NOVALUE;
    _33263 = NOVALUE;
    return;
    ;
}


void _67opEQUALS()
{
    int _33277 = NOVALUE;
    int _33276 = NOVALUE;
    int _33275 = NOVALUE;
    int _33273 = NOVALUE;
    int _33271 = NOVALUE;
    int _33269 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33269 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33269);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33271 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33271);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33273 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33273);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] = val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33275 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33276 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33275) && IS_ATOM_INT(_33276)) {
        _33277 = (_33275 == _33276);
    }
    else {
        _33277 = binary_op(EQUALS, _33275, _33276);
    }
    _33275 = NOVALUE;
    _33276 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33277;
    if( _1 != _33277 ){
        DeRef(_1);
    }
    _33277 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33269 = NOVALUE;
    _33271 = NOVALUE;
    _33273 = NOVALUE;
    return;
    ;
}


void _67opNOTEQ()
{
    int _33287 = NOVALUE;
    int _33286 = NOVALUE;
    int _33285 = NOVALUE;
    int _33283 = NOVALUE;
    int _33281 = NOVALUE;
    int _33279 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33279 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33279);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33281 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33281);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33283 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33283);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] != val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33285 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33286 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33285) && IS_ATOM_INT(_33286)) {
        _33287 = (_33285 != _33286);
    }
    else {
        _33287 = binary_op(NOTEQ, _33285, _33286);
    }
    _33285 = NOVALUE;
    _33286 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33287;
    if( _1 != _33287 ){
        DeRef(_1);
    }
    _33287 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33279 = NOVALUE;
    _33281 = NOVALUE;
    _33283 = NOVALUE;
    return;
    ;
}


void _67opLESSEQ()
{
    int _33297 = NOVALUE;
    int _33296 = NOVALUE;
    int _33295 = NOVALUE;
    int _33293 = NOVALUE;
    int _33291 = NOVALUE;
    int _33289 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33289 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33289);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33291 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33291);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33293 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33293);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] <= val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33295 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33296 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33295) && IS_ATOM_INT(_33296)) {
        _33297 = (_33295 <= _33296);
    }
    else {
        _33297 = binary_op(LESSEQ, _33295, _33296);
    }
    _33295 = NOVALUE;
    _33296 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33297;
    if( _1 != _33297 ){
        DeRef(_1);
    }
    _33297 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33289 = NOVALUE;
    _33291 = NOVALUE;
    _33293 = NOVALUE;
    return;
    ;
}


void _67opGREATEREQ()
{
    int _33307 = NOVALUE;
    int _33306 = NOVALUE;
    int _33305 = NOVALUE;
    int _33303 = NOVALUE;
    int _33301 = NOVALUE;
    int _33299 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33299 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33299);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33301 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33301);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33303 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33303);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] >= val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33305 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33306 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33305) && IS_ATOM_INT(_33306)) {
        _33307 = (_33305 >= _33306);
    }
    else {
        _33307 = binary_op(GREATEREQ, _33305, _33306);
    }
    _33305 = NOVALUE;
    _33306 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33307;
    if( _1 != _33307 ){
        DeRef(_1);
    }
    _33307 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33299 = NOVALUE;
    _33301 = NOVALUE;
    _33303 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND()
{
    int _33317 = NOVALUE;
    int _33315 = NOVALUE;
    int _33314 = NOVALUE;
    int _33313 = NOVALUE;
    int _33311 = NOVALUE;
    int _33309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33309 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33309);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33311 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33311);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33313 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33314 = IS_ATOM(_33313);
    _33313 = NOVALUE;
    if (_33314 == 0)
    {
        _33314 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33314 = NOVALUE;
    }

    /** 		if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33315 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _33315, 0)){
        _33315 = NOVALUE;
        goto L2; // [59] 104
    }
    _33315 = NOVALUE;

    /** 			val[b] = 0*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63010);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33317 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33317);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** 			return*/
    _33309 = NOVALUE;
    _33311 = NOVALUE;
    _33317 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33309);
    _33309 = NOVALUE;
    DeRef(_33311);
    _33311 = NOVALUE;
    DeRef(_33317);
    _33317 = NOVALUE;
    return;
    ;
}


void _67opSC1_AND_IF()
{
    int _33328 = NOVALUE;
    int _33326 = NOVALUE;
    int _33325 = NOVALUE;
    int _33324 = NOVALUE;
    int _33322 = NOVALUE;
    int _33320 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33320 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33320);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33322 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33322);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33324 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33325 = IS_ATOM(_33324);
    _33324 = NOVALUE;
    if (_33325 == 0)
    {
        _33325 = NOVALUE;
        goto L1; // [46] 88
    }
    else{
        _33325 = NOVALUE;
    }

    /** 		if val[a] = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33326 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _33326, 0)){
        _33326 = NOVALUE;
        goto L2; // [59] 94
    }
    _33326 = NOVALUE;

    /** 			pc = Code[pc+3]*/
    _33328 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33328);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** 			return*/
    _33320 = NOVALUE;
    _33322 = NOVALUE;
    _33328 = NOVALUE;
    return;
    goto L2; // [85] 94
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33320);
    _33320 = NOVALUE;
    DeRef(_33322);
    _33322 = NOVALUE;
    DeRef(_33328);
    _33328 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR()
{
    int _33339 = NOVALUE;
    int _33337 = NOVALUE;
    int _33336 = NOVALUE;
    int _33335 = NOVALUE;
    int _33333 = NOVALUE;
    int _33331 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33331 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33331);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33333 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33333);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33335 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33336 = IS_ATOM(_33335);
    _33335 = NOVALUE;
    if (_33336 == 0)
    {
        _33336 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33336 = NOVALUE;
    }

    /** 		if val[a] != 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33337 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(EQUALS, _33337, 0)){
        _33337 = NOVALUE;
        goto L2; // [59] 104
    }
    _33337 = NOVALUE;

    /** 			val[b] = 1*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63010);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33339 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33339);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** 			return*/
    _33331 = NOVALUE;
    _33333 = NOVALUE;
    _33339 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33331);
    _33331 = NOVALUE;
    DeRef(_33333);
    _33333 = NOVALUE;
    DeRef(_33339);
    _33339 = NOVALUE;
    return;
    ;
}


void _67opSC1_OR_IF()
{
    int _33350 = NOVALUE;
    int _33348 = NOVALUE;
    int _33347 = NOVALUE;
    int _33346 = NOVALUE;
    int _33344 = NOVALUE;
    int _33342 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33342 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33342);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33344 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33344);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33346 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33347 = IS_ATOM(_33346);
    _33346 = NOVALUE;
    if (_33347 == 0)
    {
        _33347 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        _33347 = NOVALUE;
    }

    /** 		if val[a] != 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33348 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(EQUALS, _33348, 0)){
        _33348 = NOVALUE;
        goto L2; // [59] 104
    }
    _33348 = NOVALUE;

    /** 			val[b] = 1*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63010);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 			pc = Code[pc+3]*/
    _33350 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33350);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }

    /** 			return*/
    _33342 = NOVALUE;
    _33344 = NOVALUE;
    _33350 = NOVALUE;
    return;
    goto L2; // [95] 104
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33342);
    _33342 = NOVALUE;
    DeRef(_33344);
    _33344 = NOVALUE;
    DeRef(_33350);
    _33350 = NOVALUE;
    return;
    ;
}


void _67opSC2_OR()
{
    int _33359 = NOVALUE;
    int _33358 = NOVALUE;
    int _33357 = NOVALUE;
    int _33355 = NOVALUE;
    int _33353 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33353 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33353);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33355 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33355);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33357 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33358 = IS_ATOM(_33357);
    _33357 = NOVALUE;
    if (_33358 == 0)
    {
        _33358 = NOVALUE;
        goto L1; // [46] 70
    }
    else{
        _33358 = NOVALUE;
    }

    /** 		val[b] = val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33359 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_33359);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63010);
    _1 = *(int *)_2;
    *(int *)_2 = _33359;
    if( _1 != _33359 ){
        DeRef(_1);
    }
    _33359 = NOVALUE;
    goto L2; // [67] 76
L1: 

    /** 		RTFatal("true/false condition must be an ATOM")*/
    RefDS(_33094);
    _67RTFatal(_33094);
L2: 

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_33353);
    _33353 = NOVALUE;
    DeRef(_33355);
    _33355 = NOVALUE;
    return;
    ;
}


void _67opFOR()
{
    int _increment_66188 = NOVALUE;
    int _limit_66189 = NOVALUE;
    int _initial_66190 = NOVALUE;
    int _loopvar_66191 = NOVALUE;
    int _jump_66192 = NOVALUE;
    int _33389 = NOVALUE;
    int _33387 = NOVALUE;
    int _33386 = NOVALUE;
    int _33384 = NOVALUE;
    int _33383 = NOVALUE;
    int _33381 = NOVALUE;
    int _33378 = NOVALUE;
    int _33377 = NOVALUE;
    int _33375 = NOVALUE;
    int _33374 = NOVALUE;
    int _33372 = NOVALUE;
    int _33371 = NOVALUE;
    int _33369 = NOVALUE;
    int _33367 = NOVALUE;
    int _33365 = NOVALUE;
    int _33363 = NOVALUE;
    int _33361 = NOVALUE;
    int _0, _1, _2;
    

    /** 	increment = Code[pc+1]*/
    _33361 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _increment_66188 = (int)*(((s1_ptr)_2)->base + _33361);
    if (!IS_ATOM_INT(_increment_66188)){
        _increment_66188 = (long)DBL_PTR(_increment_66188)->dbl;
    }

    /** 	limit = Code[pc+2]*/
    _33363 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _limit_66189 = (int)*(((s1_ptr)_2)->base + _33363);
    if (!IS_ATOM_INT(_limit_66189)){
        _limit_66189 = (long)DBL_PTR(_limit_66189)->dbl;
    }

    /** 	initial = Code[pc+3]*/
    _33365 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _initial_66190 = (int)*(((s1_ptr)_2)->base + _33365);
    if (!IS_ATOM_INT(_initial_66190)){
        _initial_66190 = (long)DBL_PTR(_initial_66190)->dbl;
    }

    /** 	loopvar = Code[pc+5]*/
    _33367 = _67pc_63008 + 5;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _loopvar_66191 = (int)*(((s1_ptr)_2)->base + _33367);
    if (!IS_ATOM_INT(_loopvar_66191)){
        _loopvar_66191 = (long)DBL_PTR(_loopvar_66191)->dbl;
    }

    /** 	jump = Code[pc+6]*/
    _33369 = _67pc_63008 + 6;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _jump_66192 = (int)*(((s1_ptr)_2)->base + _33369);
    if (!IS_ATOM_INT(_jump_66192)){
        _jump_66192 = (long)DBL_PTR(_jump_66192)->dbl;
    }

    /** 	if sequence(val[initial]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33371 = (int)*(((s1_ptr)_2)->base + _initial_66190);
    _33372 = IS_SEQUENCE(_33371);
    _33371 = NOVALUE;
    if (_33372 == 0)
    {
        _33372 = NOVALUE;
        goto L1; // [92] 101
    }
    else{
        _33372 = NOVALUE;
    }

    /** 		RTFatal("for-loop variable is not an atom")*/
    RefDS(_33373);
    _67RTFatal(_33373);
L1: 

    /** 	if sequence(val[limit]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33374 = (int)*(((s1_ptr)_2)->base + _limit_66189);
    _33375 = IS_SEQUENCE(_33374);
    _33374 = NOVALUE;
    if (_33375 == 0)
    {
        _33375 = NOVALUE;
        goto L2; // [112] 121
    }
    else{
        _33375 = NOVALUE;
    }

    /** 		RTFatal("for-loop limit is not an atom")*/
    RefDS(_33376);
    _67RTFatal(_33376);
L2: 

    /** 	if sequence(val[increment]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33377 = (int)*(((s1_ptr)_2)->base + _increment_66188);
    _33378 = IS_SEQUENCE(_33377);
    _33377 = NOVALUE;
    if (_33378 == 0)
    {
        _33378 = NOVALUE;
        goto L3; // [132] 141
    }
    else{
        _33378 = NOVALUE;
    }

    /** 		RTFatal("for-loop increment is not an atom")*/
    RefDS(_33379);
    _67RTFatal(_33379);
L3: 

    /** 	pc += 7 -- to enter into the loop*/
    _67pc_63008 = _67pc_63008 + 7;

    /** 	if val[increment] >= 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33381 = (int)*(((s1_ptr)_2)->base + _increment_66188);
    if (binary_op_a(LESS, _33381, 0)){
        _33381 = NOVALUE;
        goto L4; // [157] 188
    }
    _33381 = NOVALUE;

    /** 		if val[initial] > val[limit] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33383 = (int)*(((s1_ptr)_2)->base + _initial_66190);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33384 = (int)*(((s1_ptr)_2)->base + _limit_66189);
    if (binary_op_a(LESSEQ, _33383, _33384)){
        _33383 = NOVALUE;
        _33384 = NOVALUE;
        goto L5; // [175] 213
    }
    _33383 = NOVALUE;
    _33384 = NOVALUE;

    /** 			pc = jump -- quit immediately, 0 iterations*/
    _67pc_63008 = _jump_66192;
    goto L5; // [185] 213
L4: 

    /** 		if val[initial] < val[limit] then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33386 = (int)*(((s1_ptr)_2)->base + _initial_66190);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33387 = (int)*(((s1_ptr)_2)->base + _limit_66189);
    if (binary_op_a(GREATEREQ, _33386, _33387)){
        _33386 = NOVALUE;
        _33387 = NOVALUE;
        goto L6; // [202] 212
    }
    _33386 = NOVALUE;
    _33387 = NOVALUE;

    /** 			pc = jump -- quit immediately, 0 iterations*/
    _67pc_63008 = _jump_66192;
L6: 
L5: 

    /** 	val[loopvar] = val[initial] -- initialize loop var*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33389 = (int)*(((s1_ptr)_2)->base + _initial_66190);
    Ref(_33389);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66191);
    _1 = *(int *)_2;
    *(int *)_2 = _33389;
    if( _1 != _33389 ){
        DeRef(_1);
    }
    _33389 = NOVALUE;

    /** end procedure*/
    DeRef(_33361);
    _33361 = NOVALUE;
    DeRef(_33363);
    _33363 = NOVALUE;
    DeRef(_33365);
    _33365 = NOVALUE;
    DeRef(_33367);
    _33367 = NOVALUE;
    DeRef(_33369);
    _33369 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_GENERAL()
{
    int _loopvar_66236 = NOVALUE;
    int _increment_66237 = NOVALUE;
    int _limit_66238 = NOVALUE;
    int _next_66239 = NOVALUE;
    int _33407 = NOVALUE;
    int _33403 = NOVALUE;
    int _33398 = NOVALUE;
    int _33396 = NOVALUE;
    int _33394 = NOVALUE;
    int _33393 = NOVALUE;
    int _33391 = NOVALUE;
    int _33390 = NOVALUE;
    int _0, _1, _2;
    

    /** 	limit = val[Code[pc+2]]*/
    _33390 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33391 = (int)*(((s1_ptr)_2)->base + _33390);
    DeRef(_limit_66238);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33391)){
        _limit_66238 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33391)->dbl));
    }
    else{
        _limit_66238 = (int)*(((s1_ptr)_2)->base + _33391);
    }
    Ref(_limit_66238);

    /** 	increment = val[Code[pc+4]]*/
    _33393 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33394 = (int)*(((s1_ptr)_2)->base + _33393);
    DeRef(_increment_66237);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33394)){
        _increment_66237 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33394)->dbl));
    }
    else{
        _increment_66237 = (int)*(((s1_ptr)_2)->base + _33394);
    }
    Ref(_increment_66237);

    /** 	loopvar = Code[pc+3]*/
    _33396 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _loopvar_66236 = (int)*(((s1_ptr)_2)->base + _33396);
    if (!IS_ATOM_INT(_loopvar_66236)){
        _loopvar_66236 = (long)DBL_PTR(_loopvar_66236)->dbl;
    }

    /** 	next = val[loopvar] + increment*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33398 = (int)*(((s1_ptr)_2)->base + _loopvar_66236);
    DeRef(_next_66239);
    if (IS_ATOM_INT(_33398) && IS_ATOM_INT(_increment_66237)) {
        _next_66239 = _33398 + _increment_66237;
        if ((long)((unsigned long)_next_66239 + (unsigned long)HIGH_BITS) >= 0) 
        _next_66239 = NewDouble((double)_next_66239);
    }
    else {
        _next_66239 = binary_op(PLUS, _33398, _increment_66237);
    }
    _33398 = NOVALUE;

    /** 	if increment >= 0 then*/
    if (binary_op_a(LESS, _increment_66237, 0)){
        goto L1; // [71] 120
    }

    /** 		if next > limit then*/
    if (binary_op_a(LESSEQ, _next_66239, _limit_66238)){
        goto L2; // [77] 92
    }

    /** 			pc += 5 -- exit loop*/
    _67pc_63008 = _67pc_63008 + 5;
    goto L3; // [89] 163
L2: 

    /** 			val[loopvar] = next*/
    Ref(_next_66239);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66236);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66239;
    DeRef(_1);

    /** 			pc = Code[pc+1] -- loop again*/
    _33403 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33403);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
    goto L3; // [117] 163
L1: 

    /** 		if next < limit then*/
    if (binary_op_a(GREATEREQ, _next_66239, _limit_66238)){
        goto L4; // [122] 137
    }

    /** 			pc += 5 -- exit loop*/
    _67pc_63008 = _67pc_63008 + 5;
    goto L5; // [134] 162
L4: 

    /** 			val[loopvar] = next*/
    Ref(_next_66239);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66236);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66239;
    DeRef(_1);

    /** 			pc = Code[pc+1] -- loop again*/
    _33407 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33407);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L5: 
L3: 

    /** end procedure*/
    DeRef(_increment_66237);
    DeRef(_limit_66238);
    DeRef(_next_66239);
    DeRef(_33390);
    _33390 = NOVALUE;
    _33391 = NOVALUE;
    DeRef(_33393);
    _33393 = NOVALUE;
    _33394 = NOVALUE;
    DeRef(_33396);
    _33396 = NOVALUE;
    DeRef(_33403);
    _33403 = NOVALUE;
    DeRef(_33407);
    _33407 = NOVALUE;
    return;
    ;
}


void _67opENDFOR_INT_UP1()
{
    int _loopvar_66272 = NOVALUE;
    int _limit_66273 = NOVALUE;
    int _next_66274 = NOVALUE;
    int _33418 = NOVALUE;
    int _33414 = NOVALUE;
    int _33412 = NOVALUE;
    int _33410 = NOVALUE;
    int _33409 = NOVALUE;
    int _0, _1, _2;
    

    /** 	limit = val[Code[pc+2]]*/
    _33409 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33410 = (int)*(((s1_ptr)_2)->base + _33409);
    DeRef(_limit_66273);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33410)){
        _limit_66273 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33410)->dbl));
    }
    else{
        _limit_66273 = (int)*(((s1_ptr)_2)->base + _33410);
    }
    Ref(_limit_66273);

    /** 	loopvar = Code[pc+3]*/
    _33412 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _loopvar_66272 = (int)*(((s1_ptr)_2)->base + _33412);
    if (!IS_ATOM_INT(_loopvar_66272)){
        _loopvar_66272 = (long)DBL_PTR(_loopvar_66272)->dbl;
    }

    /** 	next = val[loopvar] + 1*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33414 = (int)*(((s1_ptr)_2)->base + _loopvar_66272);
    DeRef(_next_66274);
    if (IS_ATOM_INT(_33414)) {
        _next_66274 = _33414 + 1;
        if (_next_66274 > MAXINT){
            _next_66274 = NewDouble((double)_next_66274);
        }
    }
    else
    _next_66274 = binary_op(PLUS, 1, _33414);
    _33414 = NOVALUE;

    /** 	if next > limit then*/
    if (binary_op_a(LESSEQ, _next_66274, _limit_66273)){
        goto L1; // [51] 66
    }

    /** 		pc += 5 -- exit loop*/
    _67pc_63008 = _67pc_63008 + 5;
    goto L2; // [63] 91
L1: 

    /** 		val[loopvar] = next*/
    Ref(_next_66274);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _loopvar_66272);
    _1 = *(int *)_2;
    *(int *)_2 = _next_66274;
    DeRef(_1);

    /** 		pc = Code[pc+1] -- loop again*/
    _33418 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _33418);
    if (!IS_ATOM_INT(_67pc_63008)){
        _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;
    }
L2: 

    /** end procedure*/
    DeRef(_limit_66273);
    DeRef(_next_66274);
    DeRef(_33409);
    _33409 = NOVALUE;
    _33410 = NOVALUE;
    DeRef(_33412);
    _33412 = NOVALUE;
    DeRef(_33418);
    _33418 = NOVALUE;
    return;
    ;
}


int _67RTLookup(int _name_66293, int _file_66294, int _proc_66296, int _stlen_66297)
{
    int _s_66299 = NOVALUE;
    int _global_found_66300 = NOVALUE;
    int _ns_66301 = NOVALUE;
    int _colon_66302 = NOVALUE;
    int _ns_file_66303 = NOVALUE;
    int _found_in_path_66304 = NOVALUE;
    int _found_outside_path_66305 = NOVALUE;
    int _s_in_include_path_66306 = NOVALUE;
    int _scope_66403 = NOVALUE;
    int _33647 = NOVALUE;
    int _33646 = NOVALUE;
    int _33645 = NOVALUE;
    int _33644 = NOVALUE;
    int _33642 = NOVALUE;
    int _33640 = NOVALUE;
    int _33639 = NOVALUE;
    int _33638 = NOVALUE;
    int _33637 = NOVALUE;
    int _33636 = NOVALUE;
    int _33635 = NOVALUE;
    int _33634 = NOVALUE;
    int _33633 = NOVALUE;
    int _33632 = NOVALUE;
    int _33631 = NOVALUE;
    int _33630 = NOVALUE;
    int _33629 = NOVALUE;
    int _33627 = NOVALUE;
    int _33626 = NOVALUE;
    int _33625 = NOVALUE;
    int _33624 = NOVALUE;
    int _33623 = NOVALUE;
    int _33622 = NOVALUE;
    int _33621 = NOVALUE;
    int _33620 = NOVALUE;
    int _33619 = NOVALUE;
    int _33618 = NOVALUE;
    int _33617 = NOVALUE;
    int _33616 = NOVALUE;
    int _33611 = NOVALUE;
    int _33610 = NOVALUE;
    int _33609 = NOVALUE;
    int _33608 = NOVALUE;
    int _33607 = NOVALUE;
    int _33606 = NOVALUE;
    int _33605 = NOVALUE;
    int _33604 = NOVALUE;
    int _33603 = NOVALUE;
    int _33602 = NOVALUE;
    int _33601 = NOVALUE;
    int _33600 = NOVALUE;
    int _33599 = NOVALUE;
    int _33598 = NOVALUE;
    int _33597 = NOVALUE;
    int _33596 = NOVALUE;
    int _33595 = NOVALUE;
    int _33594 = NOVALUE;
    int _33592 = NOVALUE;
    int _33590 = NOVALUE;
    int _33589 = NOVALUE;
    int _33588 = NOVALUE;
    int _33587 = NOVALUE;
    int _33586 = NOVALUE;
    int _33585 = NOVALUE;
    int _33584 = NOVALUE;
    int _33583 = NOVALUE;
    int _33582 = NOVALUE;
    int _33581 = NOVALUE;
    int _33580 = NOVALUE;
    int _33579 = NOVALUE;
    int _33578 = NOVALUE;
    int _33577 = NOVALUE;
    int _33576 = NOVALUE;
    int _33575 = NOVALUE;
    int _33574 = NOVALUE;
    int _33573 = NOVALUE;
    int _33572 = NOVALUE;
    int _33571 = NOVALUE;
    int _33570 = NOVALUE;
    int _33569 = NOVALUE;
    int _33568 = NOVALUE;
    int _33567 = NOVALUE;
    int _33566 = NOVALUE;
    int _33565 = NOVALUE;
    int _33564 = NOVALUE;
    int _33563 = NOVALUE;
    int _33562 = NOVALUE;
    int _33561 = NOVALUE;
    int _33560 = NOVALUE;
    int _33559 = NOVALUE;
    int _33558 = NOVALUE;
    int _33556 = NOVALUE;
    int _33554 = NOVALUE;
    int _33553 = NOVALUE;
    int _33552 = NOVALUE;
    int _33551 = NOVALUE;
    int _33550 = NOVALUE;
    int _33549 = NOVALUE;
    int _33548 = NOVALUE;
    int _33547 = NOVALUE;
    int _33546 = NOVALUE;
    int _33545 = NOVALUE;
    int _33544 = NOVALUE;
    int _33543 = NOVALUE;
    int _33541 = NOVALUE;
    int _33538 = NOVALUE;
    int _33537 = NOVALUE;
    int _33536 = NOVALUE;
    int _33535 = NOVALUE;
    int _33534 = NOVALUE;
    int _33533 = NOVALUE;
    int _33532 = NOVALUE;
    int _33531 = NOVALUE;
    int _33530 = NOVALUE;
    int _33529 = NOVALUE;
    int _33528 = NOVALUE;
    int _33527 = NOVALUE;
    int _33526 = NOVALUE;
    int _33525 = NOVALUE;
    int _33524 = NOVALUE;
    int _33523 = NOVALUE;
    int _33522 = NOVALUE;
    int _33521 = NOVALUE;
    int _33520 = NOVALUE;
    int _33519 = NOVALUE;
    int _33518 = NOVALUE;
    int _33517 = NOVALUE;
    int _33516 = NOVALUE;
    int _33515 = NOVALUE;
    int _33514 = NOVALUE;
    int _33513 = NOVALUE;
    int _33512 = NOVALUE;
    int _33511 = NOVALUE;
    int _33510 = NOVALUE;
    int _33509 = NOVALUE;
    int _33508 = NOVALUE;
    int _33507 = NOVALUE;
    int _33506 = NOVALUE;
    int _33505 = NOVALUE;
    int _33504 = NOVALUE;
    int _33503 = NOVALUE;
    int _33502 = NOVALUE;
    int _33501 = NOVALUE;
    int _33500 = NOVALUE;
    int _33499 = NOVALUE;
    int _33498 = NOVALUE;
    int _33497 = NOVALUE;
    int _33496 = NOVALUE;
    int _33495 = NOVALUE;
    int _33494 = NOVALUE;
    int _33493 = NOVALUE;
    int _33492 = NOVALUE;
    int _33491 = NOVALUE;
    int _33490 = NOVALUE;
    int _33488 = NOVALUE;
    int _33487 = NOVALUE;
    int _33486 = NOVALUE;
    int _33485 = NOVALUE;
    int _33484 = NOVALUE;
    int _33483 = NOVALUE;
    int _33482 = NOVALUE;
    int _33481 = NOVALUE;
    int _33479 = NOVALUE;
    int _33477 = NOVALUE;
    int _33476 = NOVALUE;
    int _33475 = NOVALUE;
    int _33474 = NOVALUE;
    int _33473 = NOVALUE;
    int _33472 = NOVALUE;
    int _33471 = NOVALUE;
    int _33470 = NOVALUE;
    int _33466 = NOVALUE;
    int _33465 = NOVALUE;
    int _33464 = NOVALUE;
    int _33463 = NOVALUE;
    int _33462 = NOVALUE;
    int _33461 = NOVALUE;
    int _33460 = NOVALUE;
    int _33459 = NOVALUE;
    int _33458 = NOVALUE;
    int _33457 = NOVALUE;
    int _33456 = NOVALUE;
    int _33455 = NOVALUE;
    int _33452 = NOVALUE;
    int _33451 = NOVALUE;
    int _33449 = NOVALUE;
    int _33448 = NOVALUE;
    int _33446 = NOVALUE;
    int _33445 = NOVALUE;
    int _33444 = NOVALUE;
    int _33443 = NOVALUE;
    int _33442 = NOVALUE;
    int _33441 = NOVALUE;
    int _33440 = NOVALUE;
    int _33439 = NOVALUE;
    int _33437 = NOVALUE;
    int _33436 = NOVALUE;
    int _33435 = NOVALUE;
    int _33434 = NOVALUE;
    int _33433 = NOVALUE;
    int _33432 = NOVALUE;
    int _33431 = NOVALUE;
    int _33430 = NOVALUE;
    int _33429 = NOVALUE;
    int _33428 = NOVALUE;
    int _33427 = NOVALUE;
    int _33425 = NOVALUE;
    int _33424 = NOVALUE;
    int _33422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ns*/

    /** 	integer colon*/

    /** 	integer ns_file*/

    /** 	integer found_in_path*/

    /** 	integer found_outside_path*/

    /** 	integer s_in_include_path*/

    /** 	stlen = length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _stlen_66297 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _stlen_66297 = 1;
    }

    /** 	colon = find(':', name)*/
    _colon_66302 = find_from(58, _name_66293, 1);

    /** 	if colon then*/
    if (_colon_66302 == 0)
    {
        goto L1; // [37] 827
    }
    else{
    }

    /** 		ns = name[1..colon-1]*/
    _33422 = _colon_66302 - 1;
    rhs_slice_target = (object_ptr)&_ns_66301;
    RHS_Slice(_name_66293, 1, _33422);

    /** 		name = name[colon+1..$]*/
    _33424 = _colon_66302 + 1;
    if (IS_SEQUENCE(_name_66293)){
            _33425 = SEQ_PTR(_name_66293)->length;
    }
    else {
        _33425 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_66293;
    RHS_Slice(_name_66293, _33424, _33425);

    /** 		while length(ns) and (ns[$] = ' ' or ns[$] = '\t') do*/
L2: 
    if (IS_SEQUENCE(_ns_66301)){
            _33427 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33427 = 1;
    }
    if (_33427 == 0) {
        goto L3; // [73] 130
    }
    if (IS_SEQUENCE(_ns_66301)){
            _33429 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33429 = 1;
    }
    _2 = (int)SEQ_PTR(_ns_66301);
    _33430 = (int)*(((s1_ptr)_2)->base + _33429);
    if (IS_ATOM_INT(_33430)) {
        _33431 = (_33430 == 32);
    }
    else {
        _33431 = binary_op(EQUALS, _33430, 32);
    }
    _33430 = NOVALUE;
    if (IS_ATOM_INT(_33431)) {
        if (_33431 != 0) {
            DeRef(_33432);
            _33432 = 1;
            goto L4; // [88] 107
        }
    }
    else {
        if (DBL_PTR(_33431)->dbl != 0.0) {
            DeRef(_33432);
            _33432 = 1;
            goto L4; // [88] 107
        }
    }
    if (IS_SEQUENCE(_ns_66301)){
            _33433 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33433 = 1;
    }
    _2 = (int)SEQ_PTR(_ns_66301);
    _33434 = (int)*(((s1_ptr)_2)->base + _33433);
    if (IS_ATOM_INT(_33434)) {
        _33435 = (_33434 == 9);
    }
    else {
        _33435 = binary_op(EQUALS, _33434, 9);
    }
    _33434 = NOVALUE;
    DeRef(_33432);
    if (IS_ATOM_INT(_33435))
    _33432 = (_33435 != 0);
    else
    _33432 = DBL_PTR(_33435)->dbl != 0.0;
L4: 
    if (_33432 == 0)
    {
        _33432 = NOVALUE;
        goto L3; // [108] 130
    }
    else{
        _33432 = NOVALUE;
    }

    /** 			ns = ns[1..$-1]*/
    if (IS_SEQUENCE(_ns_66301)){
            _33436 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33436 = 1;
    }
    _33437 = _33436 - 1;
    _33436 = NOVALUE;
    rhs_slice_target = (object_ptr)&_ns_66301;
    RHS_Slice(_ns_66301, 1, _33437);

    /** 		end while*/
    goto L2; // [127] 70
L3: 

    /** 		while length(ns) and (ns[1] = ' ' or ns[1] = '\t') do*/
L5: 
    if (IS_SEQUENCE(_ns_66301)){
            _33439 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33439 = 1;
    }
    if (_33439 == 0) {
        goto L6; // [138] 185
    }
    _2 = (int)SEQ_PTR(_ns_66301);
    _33441 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33441)) {
        _33442 = (_33441 == 32);
    }
    else {
        _33442 = binary_op(EQUALS, _33441, 32);
    }
    _33441 = NOVALUE;
    if (IS_ATOM_INT(_33442)) {
        if (_33442 != 0) {
            DeRef(_33443);
            _33443 = 1;
            goto L7; // [150] 166
        }
    }
    else {
        if (DBL_PTR(_33442)->dbl != 0.0) {
            DeRef(_33443);
            _33443 = 1;
            goto L7; // [150] 166
        }
    }
    _2 = (int)SEQ_PTR(_ns_66301);
    _33444 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33444)) {
        _33445 = (_33444 == 9);
    }
    else {
        _33445 = binary_op(EQUALS, _33444, 9);
    }
    _33444 = NOVALUE;
    DeRef(_33443);
    if (IS_ATOM_INT(_33445))
    _33443 = (_33445 != 0);
    else
    _33443 = DBL_PTR(_33445)->dbl != 0.0;
L7: 
    if (_33443 == 0)
    {
        _33443 = NOVALUE;
        goto L6; // [167] 185
    }
    else{
        _33443 = NOVALUE;
    }

    /** 			ns = ns[2..$]*/
    if (IS_SEQUENCE(_ns_66301)){
            _33446 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33446 = 1;
    }
    rhs_slice_target = (object_ptr)&_ns_66301;
    RHS_Slice(_ns_66301, 2, _33446);

    /** 		end while*/
    goto L5; // [182] 135
L6: 

    /** 		if length(ns) = 0 or equal( ns, "eu") then*/
    if (IS_SEQUENCE(_ns_66301)){
            _33448 = SEQ_PTR(_ns_66301)->length;
    }
    else {
        _33448 = 1;
    }
    _33449 = (_33448 == 0);
    _33448 = NOVALUE;
    if (_33449 != 0) {
        goto L8; // [194] 207
    }
    if (_ns_66301 == _23350)
    _33451 = 1;
    else if (IS_ATOM_INT(_ns_66301) && IS_ATOM_INT(_23350))
    _33451 = 0;
    else
    _33451 = (compare(_ns_66301, _23350) == 0);
    if (_33451 == 0)
    {
        _33451 = NOVALUE;
        goto L9; // [203] 214
    }
    else{
        _33451 = NOVALUE;
    }
L8: 

    /** 			return 0 -- bad syntax*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    return 0;
L9: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33452 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_33452);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33452 = NOVALUE;

    /** 		while s != 0 do*/
LA: 
    if (_s_66299 == 0)
    goto LB; // [237] 335

    /** 			if file = SymTab[s][S_FILE_NO] and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33455 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33455);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33456 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33456 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33455 = NOVALUE;
    if (IS_ATOM_INT(_33456)) {
        _33457 = (_file_66294 == _33456);
    }
    else {
        _33457 = binary_op(EQUALS, _file_66294, _33456);
    }
    _33456 = NOVALUE;
    if (IS_ATOM_INT(_33457)) {
        if (_33457 == 0) {
            DeRef(_33458);
            _33458 = 0;
            goto LC; // [259] 285
        }
    }
    else {
        if (DBL_PTR(_33457)->dbl == 0.0) {
            DeRef(_33458);
            _33458 = 0;
            goto LC; // [259] 285
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33459 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33459);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _33460 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _33460 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _33459 = NOVALUE;
    if (IS_ATOM_INT(_33460)) {
        _33461 = (_33460 == 523);
    }
    else {
        _33461 = binary_op(EQUALS, _33460, 523);
    }
    _33460 = NOVALUE;
    DeRef(_33458);
    if (IS_ATOM_INT(_33461))
    _33458 = (_33461 != 0);
    else
    _33458 = DBL_PTR(_33461)->dbl != 0.0;
LC: 
    if (_33458 == 0) {
        goto LD; // [285] 314
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33463 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33463);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33464 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33464 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33463 = NOVALUE;
    if (_ns_66301 == _33464)
    _33465 = 1;
    else if (IS_ATOM_INT(_ns_66301) && IS_ATOM_INT(_33464))
    _33465 = 0;
    else
    _33465 = (compare(_ns_66301, _33464) == 0);
    _33464 = NOVALUE;
    if (_33465 == 0)
    {
        _33465 = NOVALUE;
        goto LD; // [306] 314
    }
    else{
        _33465 = NOVALUE;
    }

    /** 				exit*/
    goto LB; // [311] 335
LD: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33466 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33466);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33466 = NOVALUE;

    /** 		end while*/
    goto LA; // [332] 237
LB: 

    /** 		if s = 0 then*/
    if (_s_66299 != 0)
    goto LE; // [337] 348

    /** 			return 0 -- couldn't find ns*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    return 0;
LE: 

    /** 		ns_file = val[s]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _ns_file_66303 = (int)*(((s1_ptr)_2)->base + _s_66299);
    if (!IS_ATOM_INT(_ns_file_66303))
    _ns_file_66303 = (long)DBL_PTR(_ns_file_66303)->dbl;

    /** 		while length(name) and (name[1] = ' ' or name[1] = '\t') do*/
LF: 
    if (IS_SEQUENCE(_name_66293)){
            _33470 = SEQ_PTR(_name_66293)->length;
    }
    else {
        _33470 = 1;
    }
    if (_33470 == 0) {
        goto L10; // [364] 411
    }
    _2 = (int)SEQ_PTR(_name_66293);
    _33472 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33472)) {
        _33473 = (_33472 == 32);
    }
    else {
        _33473 = binary_op(EQUALS, _33472, 32);
    }
    _33472 = NOVALUE;
    if (IS_ATOM_INT(_33473)) {
        if (_33473 != 0) {
            DeRef(_33474);
            _33474 = 1;
            goto L11; // [376] 392
        }
    }
    else {
        if (DBL_PTR(_33473)->dbl != 0.0) {
            DeRef(_33474);
            _33474 = 1;
            goto L11; // [376] 392
        }
    }
    _2 = (int)SEQ_PTR(_name_66293);
    _33475 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_33475)) {
        _33476 = (_33475 == 9);
    }
    else {
        _33476 = binary_op(EQUALS, _33475, 9);
    }
    _33475 = NOVALUE;
    DeRef(_33474);
    if (IS_ATOM_INT(_33476))
    _33474 = (_33476 != 0);
    else
    _33474 = DBL_PTR(_33476)->dbl != 0.0;
L11: 
    if (_33474 == 0)
    {
        _33474 = NOVALUE;
        goto L10; // [393] 411
    }
    else{
        _33474 = NOVALUE;
    }

    /** 			name = name[2..$]*/
    if (IS_SEQUENCE(_name_66293)){
            _33477 = SEQ_PTR(_name_66293)->length;
    }
    else {
        _33477 = 1;
    }
    rhs_slice_target = (object_ptr)&_name_66293;
    RHS_Slice(_name_66293, 2, _33477);

    /** 		end while*/
    goto LF; // [408] 361
L10: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33479 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_33479);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33479 = NOVALUE;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L12: 
    _33481 = (_s_66299 != 0);
    if (_33481 == 0) {
        goto L13; // [438] 818
    }
    _33483 = (_s_66299 <= _stlen_66297);
    if (_33483 != 0) {
        DeRef(_33484);
        _33484 = 1;
        goto L14; // [446] 472
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33485 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33485);
    _33486 = (int)*(((s1_ptr)_2)->base + 4);
    _33485 = NOVALUE;
    if (IS_ATOM_INT(_33486)) {
        _33487 = (_33486 == 3);
    }
    else {
        _33487 = binary_op(EQUALS, _33486, 3);
    }
    _33486 = NOVALUE;
    if (IS_ATOM_INT(_33487))
    _33484 = (_33487 != 0);
    else
    _33484 = DBL_PTR(_33487)->dbl != 0.0;
L14: 
    if (_33484 == 0)
    {
        _33484 = NOVALUE;
        goto L13; // [473] 818
    }
    else{
        _33484 = NOVALUE;
    }

    /** 			integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33488 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33488);
    _scope_66403 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_66403)){
        _scope_66403 = (long)DBL_PTR(_scope_66403)->dbl;
    }
    _33488 = NOVALUE;

    /** 			if (((scope = SC_PUBLIC) and*/
    _33490 = (_scope_66403 == 13);
    if (_33490 == 0) {
        _33491 = 0;
        goto L15; // [500] 584
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33492 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33492);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33493 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33492 = NOVALUE;
    if (IS_ATOM_INT(_33493)) {
        _33494 = (_33493 == _ns_file_66303);
    }
    else {
        _33494 = binary_op(EQUALS, _33493, _ns_file_66303);
    }
    _33493 = NOVALUE;
    if (IS_ATOM_INT(_33494)) {
        if (_33494 != 0) {
            DeRef(_33495);
            _33495 = 1;
            goto L16; // [520] 580
        }
    }
    else {
        if (DBL_PTR(_33494)->dbl != 0.0) {
            DeRef(_33495);
            _33495 = 1;
            goto L16; // [520] 580
        }
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33496 = (int)*(((s1_ptr)_2)->base + _ns_file_66303);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33497 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33497);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33498 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33498 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33497 = NOVALUE;
    _2 = (int)SEQ_PTR(_33496);
    if (!IS_ATOM_INT(_33498)){
        _33499 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33498)->dbl));
    }
    else{
        _33499 = (int)*(((s1_ptr)_2)->base + _33498);
    }
    _33496 = NOVALUE;
    if (IS_ATOM_INT(_33499)) {
        {unsigned long tu;
             tu = (unsigned long)4 & (unsigned long)_33499;
             _33500 = MAKE_UINT(tu);
        }
    }
    else {
        _33500 = binary_op(AND_BITS, 4, _33499);
    }
    _33499 = NOVALUE;
    if (IS_ATOM_INT(_33500)) {
        if (_33500 == 0) {
            DeRef(_33501);
            _33501 = 0;
            goto L17; // [552] 576
        }
    }
    else {
        if (DBL_PTR(_33500)->dbl == 0.0) {
            DeRef(_33501);
            _33501 = 0;
            goto L17; // [552] 576
        }
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33502 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_33502);
    _33503 = (int)*(((s1_ptr)_2)->base + _ns_file_66303);
    _33502 = NOVALUE;
    if (IS_ATOM_INT(_33503)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33503;
             _33504 = MAKE_UINT(tu);
        }
    }
    else {
        _33504 = binary_op(AND_BITS, 6, _33503);
    }
    _33503 = NOVALUE;
    DeRef(_33501);
    if (IS_ATOM_INT(_33504))
    _33501 = (_33504 != 0);
    else
    _33501 = DBL_PTR(_33504)->dbl != 0.0;
L17: 
    DeRef(_33495);
    _33495 = (_33501 != 0);
L16: 
    _33491 = (_33495 != 0);
L15: 
    if (_33491 != 0) {
        _33505 = 1;
        goto L18; // [584] 646
    }
    _33506 = (_scope_66403 == 11);
    if (_33506 == 0) {
        _33507 = 0;
        goto L19; // [594] 618
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33508 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33508);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33509 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33509 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33508 = NOVALUE;
    if (IS_ATOM_INT(_33509)) {
        _33510 = (_33509 == _ns_file_66303);
    }
    else {
        _33510 = binary_op(EQUALS, _33509, _ns_file_66303);
    }
    _33509 = NOVALUE;
    if (IS_ATOM_INT(_33510))
    _33507 = (_33510 != 0);
    else
    _33507 = DBL_PTR(_33510)->dbl != 0.0;
L19: 
    if (_33507 == 0) {
        _33511 = 0;
        goto L1A; // [618] 642
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33512 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_33512);
    _33513 = (int)*(((s1_ptr)_2)->base + _ns_file_66303);
    _33512 = NOVALUE;
    if (IS_ATOM_INT(_33513)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_33513;
             _33514 = MAKE_UINT(tu);
        }
    }
    else {
        _33514 = binary_op(AND_BITS, 2, _33513);
    }
    _33513 = NOVALUE;
    if (IS_ATOM_INT(_33514))
    _33511 = (_33514 != 0);
    else
    _33511 = DBL_PTR(_33514)->dbl != 0.0;
L1A: 
    _33505 = (_33511 != 0);
L18: 
    if (_33505 != 0) {
        _33515 = 1;
        goto L1B; // [646] 660
    }
    _33516 = (_scope_66403 == 6);
    _33515 = (_33516 != 0);
L1B: 
    if (_33515 == 0) {
        _33517 = 0;
        goto L1C; // [660] 738
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33518 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33518);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33519 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33519 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33518 = NOVALUE;
    if (IS_ATOM_INT(_33519)) {
        _33520 = (_33519 == _ns_file_66303);
    }
    else {
        _33520 = binary_op(EQUALS, _33519, _ns_file_66303);
    }
    _33519 = NOVALUE;
    if (IS_ATOM_INT(_33520)) {
        if (_33520 != 0) {
            DeRef(_33521);
            _33521 = 1;
            goto L1D; // [680] 734
        }
    }
    else {
        if (DBL_PTR(_33520)->dbl != 0.0) {
            DeRef(_33521);
            _33521 = 1;
            goto L1D; // [680] 734
        }
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33522 = (int)*(((s1_ptr)_2)->base + _ns_file_66303);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33523 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33523);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33524 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33524 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33523 = NOVALUE;
    _2 = (int)SEQ_PTR(_33522);
    if (!IS_ATOM_INT(_33524)){
        _33525 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33524)->dbl));
    }
    else{
        _33525 = (int)*(((s1_ptr)_2)->base + _33524);
    }
    _33522 = NOVALUE;
    if (IS_ATOM_INT(_33525)) {
        if (_33525 == 0) {
            DeRef(_33526);
            _33526 = 0;
            goto L1E; // [706] 730
        }
    }
    else {
        if (DBL_PTR(_33525)->dbl == 0.0) {
            DeRef(_33526);
            _33526 = 0;
            goto L1E; // [706] 730
        }
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33527 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_33527);
    _33528 = (int)*(((s1_ptr)_2)->base + _ns_file_66303);
    _33527 = NOVALUE;
    if (IS_ATOM_INT(_33528)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33528;
             _33529 = MAKE_UINT(tu);
        }
    }
    else {
        _33529 = binary_op(AND_BITS, 6, _33528);
    }
    _33528 = NOVALUE;
    DeRef(_33526);
    if (IS_ATOM_INT(_33529))
    _33526 = (_33529 != 0);
    else
    _33526 = DBL_PTR(_33529)->dbl != 0.0;
L1E: 
    DeRef(_33521);
    _33521 = (_33526 != 0);
L1D: 
    _33517 = (_33521 != 0);
L1C: 
    if (_33517 != 0) {
        _33530 = 1;
        goto L1F; // [738] 764
    }
    _33531 = (_scope_66403 == 5);
    if (_33531 == 0) {
        _33532 = 0;
        goto L20; // [748] 760
    }
    _33533 = (_ns_file_66303 == _file_66294);
    _33532 = (_33533 != 0);
L20: 
    _33530 = (_33532 != 0);
L1F: 
    if (_33530 == 0) {
        goto L21; // [764] 795
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33535 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33535);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33536 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33536 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33535 = NOVALUE;
    if (_33536 == _name_66293)
    _33537 = 1;
    else if (IS_ATOM_INT(_33536) && IS_ATOM_INT(_name_66293))
    _33537 = 0;
    else
    _33537 = (compare(_33536, _name_66293) == 0);
    _33536 = NOVALUE;
    if (_33537 == 0)
    {
        _33537 = NOVALUE;
        goto L21; // [785] 795
    }
    else{
        _33537 = NOVALUE;
    }

    /** 				return s*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return _s_66299;
L21: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33538 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33538);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33538 = NOVALUE;

    /** 		end while*/
    goto L12; // [815] 434
L13: 

    /** 		return 0 -- couldn't find name in ns file*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return 0;
    goto L22; // [824] 1636
L1: 

    /** 		if proc != TopLevelSub then*/
    if (_proc_66296 == _12TopLevelSub_11689)
    goto L23; // [831] 958

    /** 			s = SymTab[proc][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33541 = (int)*(((s1_ptr)_2)->base + _proc_66296);
    _2 = (int)SEQ_PTR(_33541);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33541 = NOVALUE;

    /** 			while s and (SymTab[s][S_SCOPE] = SC_PRIVATE or*/
L24: 
    if (_s_66299 == 0) {
        goto L25; // [856] 957
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33544 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33544);
    _33545 = (int)*(((s1_ptr)_2)->base + 4);
    _33544 = NOVALUE;
    if (IS_ATOM_INT(_33545)) {
        _33546 = (_33545 == 3);
    }
    else {
        _33546 = binary_op(EQUALS, _33545, 3);
    }
    _33545 = NOVALUE;
    if (IS_ATOM_INT(_33546)) {
        if (_33546 != 0) {
            DeRef(_33547);
            _33547 = 1;
            goto L26; // [878] 904
        }
    }
    else {
        if (DBL_PTR(_33546)->dbl != 0.0) {
            DeRef(_33547);
            _33547 = 1;
            goto L26; // [878] 904
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33548 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33548);
    _33549 = (int)*(((s1_ptr)_2)->base + 4);
    _33548 = NOVALUE;
    if (IS_ATOM_INT(_33549)) {
        _33550 = (_33549 == 2);
    }
    else {
        _33550 = binary_op(EQUALS, _33549, 2);
    }
    _33549 = NOVALUE;
    DeRef(_33547);
    if (IS_ATOM_INT(_33550))
    _33547 = (_33550 != 0);
    else
    _33547 = DBL_PTR(_33550)->dbl != 0.0;
L26: 
    if (_33547 == 0)
    {
        _33547 = NOVALUE;
        goto L25; // [905] 957
    }
    else{
        _33547 = NOVALUE;
    }

    /** 				if equal(name, SymTab[s][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33551 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33551);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33552 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33552 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33551 = NOVALUE;
    if (_name_66293 == _33552)
    _33553 = 1;
    else if (IS_ATOM_INT(_name_66293) && IS_ATOM_INT(_33552))
    _33553 = 0;
    else
    _33553 = (compare(_name_66293, _33552) == 0);
    _33552 = NOVALUE;
    if (_33553 == 0)
    {
        _33553 = NOVALUE;
        goto L27; // [926] 936
    }
    else{
        _33553 = NOVALUE;
    }

    /** 					return s*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33550);
    _33550 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33546);
    _33546 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return _s_66299;
L27: 

    /** 				s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33554 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33554);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33554 = NOVALUE;

    /** 			end while*/
    goto L24; // [954] 856
L25: 
L23: 

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33556 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_33556);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33556 = NOVALUE;

    /** 		found_in_path = 0*/
    _found_in_path_66304 = 0;

    /** 		found_outside_path = 0*/
    _found_outside_path_66305 = 0;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L28: 
    _33558 = (_s_66299 != 0);
    if (_33558 == 0) {
        goto L29; // [995] 1221
    }
    _33560 = (_s_66299 <= _stlen_66297);
    if (_33560 != 0) {
        DeRef(_33561);
        _33561 = 1;
        goto L2A; // [1003] 1029
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33562 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33562);
    _33563 = (int)*(((s1_ptr)_2)->base + 4);
    _33562 = NOVALUE;
    if (IS_ATOM_INT(_33563)) {
        _33564 = (_33563 == 3);
    }
    else {
        _33564 = binary_op(EQUALS, _33563, 3);
    }
    _33563 = NOVALUE;
    if (IS_ATOM_INT(_33564))
    _33561 = (_33564 != 0);
    else
    _33561 = DBL_PTR(_33564)->dbl != 0.0;
L2A: 
    if (_33561 == 0)
    {
        _33561 = NOVALUE;
        goto L29; // [1030] 1221
    }
    else{
        _33561 = NOVALUE;
    }

    /** 			if SymTab[s][S_FILE_NO] = file and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33565 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33565);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33566 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33566 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33565 = NOVALUE;
    if (IS_ATOM_INT(_33566)) {
        _33567 = (_33566 == _file_66294);
    }
    else {
        _33567 = binary_op(EQUALS, _33566, _file_66294);
    }
    _33566 = NOVALUE;
    if (IS_ATOM_INT(_33567)) {
        if (_33567 == 0) {
            DeRef(_33568);
            _33568 = 0;
            goto L2B; // [1051] 1169
        }
    }
    else {
        if (DBL_PTR(_33567)->dbl == 0.0) {
            DeRef(_33568);
            _33568 = 0;
            goto L2B; // [1051] 1169
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33569 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33569);
    _33570 = (int)*(((s1_ptr)_2)->base + 4);
    _33569 = NOVALUE;
    if (IS_ATOM_INT(_33570)) {
        _33571 = (_33570 == 5);
    }
    else {
        _33571 = binary_op(EQUALS, _33570, 5);
    }
    _33570 = NOVALUE;
    if (IS_ATOM_INT(_33571)) {
        if (_33571 != 0) {
            DeRef(_33572);
            _33572 = 1;
            goto L2C; // [1073] 1099
        }
    }
    else {
        if (DBL_PTR(_33571)->dbl != 0.0) {
            DeRef(_33572);
            _33572 = 1;
            goto L2C; // [1073] 1099
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33573 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33573);
    _33574 = (int)*(((s1_ptr)_2)->base + 4);
    _33573 = NOVALUE;
    if (IS_ATOM_INT(_33574)) {
        _33575 = (_33574 == 6);
    }
    else {
        _33575 = binary_op(EQUALS, _33574, 6);
    }
    _33574 = NOVALUE;
    DeRef(_33572);
    if (IS_ATOM_INT(_33575))
    _33572 = (_33575 != 0);
    else
    _33572 = DBL_PTR(_33575)->dbl != 0.0;
L2C: 
    if (_33572 != 0) {
        _33576 = 1;
        goto L2D; // [1099] 1125
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33577 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33577);
    _33578 = (int)*(((s1_ptr)_2)->base + 4);
    _33577 = NOVALUE;
    if (IS_ATOM_INT(_33578)) {
        _33579 = (_33578 == 11);
    }
    else {
        _33579 = binary_op(EQUALS, _33578, 11);
    }
    _33578 = NOVALUE;
    if (IS_ATOM_INT(_33579))
    _33576 = (_33579 != 0);
    else
    _33576 = DBL_PTR(_33579)->dbl != 0.0;
L2D: 
    if (_33576 != 0) {
        _33580 = 1;
        goto L2E; // [1125] 1165
    }
    _33581 = (_proc_66296 == _12TopLevelSub_11689);
    if (_33581 == 0) {
        _33582 = 0;
        goto L2F; // [1135] 1161
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33583 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33583);
    _33584 = (int)*(((s1_ptr)_2)->base + 4);
    _33583 = NOVALUE;
    if (IS_ATOM_INT(_33584)) {
        _33585 = (_33584 == 4);
    }
    else {
        _33585 = binary_op(EQUALS, _33584, 4);
    }
    _33584 = NOVALUE;
    if (IS_ATOM_INT(_33585))
    _33582 = (_33585 != 0);
    else
    _33582 = DBL_PTR(_33585)->dbl != 0.0;
L2F: 
    _33580 = (_33582 != 0);
L2E: 
    DeRef(_33568);
    _33568 = (_33580 != 0);
L2B: 
    if (_33568 == 0) {
        goto L30; // [1169] 1200
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33587 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33587);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33588 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33588 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33587 = NOVALUE;
    if (_name_66293 == _33588)
    _33589 = 1;
    else if (IS_ATOM_INT(_name_66293) && IS_ATOM_INT(_33588))
    _33589 = 0;
    else
    _33589 = (compare(_name_66293, _33588) == 0);
    _33588 = NOVALUE;
    if (_33589 == 0)
    {
        _33589 = NOVALUE;
        goto L30; // [1190] 1200
    }
    else{
        _33589 = NOVALUE;
    }

    /** 				return s*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33575);
    _33575 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33564);
    _33564 = NOVALUE;
    DeRef(_33550);
    _33550 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33560);
    _33560 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33579);
    _33579 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33546);
    _33546 = NOVALUE;
    DeRef(_33558);
    _33558 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33571);
    _33571 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33581);
    _33581 = NOVALUE;
    DeRef(_33585);
    _33585 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33567);
    _33567 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return _s_66299;
L30: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33590 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33590);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33590 = NOVALUE;

    /** 		end while*/
    goto L28; // [1218] 991
L29: 

    /** 		global_found = FALSE*/
    _global_found_66300 = _9FALSE_429;

    /** 		s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33592 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_33592);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33592 = NOVALUE;

    /** 		while s != 0 and (s <= stlen or SymTab[s][S_SCOPE] = SC_PRIVATE) do*/
L31: 
    _33594 = (_s_66299 != 0);
    if (_33594 == 0) {
        goto L32; // [1257] 1600
    }
    _33596 = (_s_66299 <= _stlen_66297);
    if (_33596 != 0) {
        DeRef(_33597);
        _33597 = 1;
        goto L33; // [1265] 1291
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33598 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33598);
    _33599 = (int)*(((s1_ptr)_2)->base + 4);
    _33598 = NOVALUE;
    if (IS_ATOM_INT(_33599)) {
        _33600 = (_33599 == 3);
    }
    else {
        _33600 = binary_op(EQUALS, _33599, 3);
    }
    _33599 = NOVALUE;
    if (IS_ATOM_INT(_33600))
    _33597 = (_33600 != 0);
    else
    _33597 = DBL_PTR(_33600)->dbl != 0.0;
L33: 
    if (_33597 == 0)
    {
        _33597 = NOVALUE;
        goto L32; // [1292] 1600
    }
    else{
        _33597 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_GLOBAL and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33601 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33601);
    _33602 = (int)*(((s1_ptr)_2)->base + 4);
    _33601 = NOVALUE;
    if (IS_ATOM_INT(_33602)) {
        _33603 = (_33602 == 6);
    }
    else {
        _33603 = binary_op(EQUALS, _33602, 6);
    }
    _33602 = NOVALUE;
    if (IS_ATOM_INT(_33603)) {
        if (_33603 == 0) {
            goto L34; // [1315] 1413
        }
    }
    else {
        if (DBL_PTR(_33603)->dbl == 0.0) {
            goto L34; // [1315] 1413
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33605 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33605);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33606 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33606 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33605 = NOVALUE;
    if (_name_66293 == _33606)
    _33607 = 1;
    else if (IS_ATOM_INT(_name_66293) && IS_ATOM_INT(_33606))
    _33607 = 0;
    else
    _33607 = (compare(_name_66293, _33606) == 0);
    _33606 = NOVALUE;
    if (_33607 == 0)
    {
        _33607 = NOVALUE;
        goto L34; // [1336] 1413
    }
    else{
        _33607 = NOVALUE;
    }

    /** 				s_in_include_path = include_matrix[file][SymTab[s][S_FILE_NO]] != 0*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33608 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33609 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33609);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33610 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33610 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33609 = NOVALUE;
    _2 = (int)SEQ_PTR(_33608);
    if (!IS_ATOM_INT(_33610)){
        _33611 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33610)->dbl));
    }
    else{
        _33611 = (int)*(((s1_ptr)_2)->base + _33610);
    }
    _33608 = NOVALUE;
    if (IS_ATOM_INT(_33611)) {
        _s_in_include_path_66306 = (_33611 != 0);
    }
    else {
        _s_in_include_path_66306 = binary_op(NOTEQ, _33611, 0);
    }
    _33611 = NOVALUE;
    if (!IS_ATOM_INT(_s_in_include_path_66306)) {
        _1 = (long)(DBL_PTR(_s_in_include_path_66306)->dbl);
        DeRefDS(_s_in_include_path_66306);
        _s_in_include_path_66306 = _1;
    }

    /** 				if s_in_include_path then*/
    if (_s_in_include_path_66306 == 0)
    {
        goto L35; // [1371] 1390
    }
    else{
    }

    /** 					global_found = s*/
    _global_found_66300 = _s_66299;

    /** 					found_in_path += 1*/
    _found_in_path_66304 = _found_in_path_66304 + 1;
    goto L36; // [1387] 1579
L35: 

    /** 					if not found_in_path then*/
    if (_found_in_path_66304 != 0)
    goto L37; // [1392] 1403

    /** 						global_found = s*/
    _global_found_66300 = _s_66299;
L37: 

    /** 					found_outside_path += 1*/
    _found_outside_path_66305 = _found_outside_path_66305 + 1;
    goto L36; // [1410] 1579
L34: 

    /** 			elsif (sym_scope( s ) = SC_PUBLIC and equal( name, SymTab[s][S_NAME] ) and*/
    _33616 = _52sym_scope(_s_66299);
    if (IS_ATOM_INT(_33616)) {
        _33617 = (_33616 == 13);
    }
    else {
        _33617 = binary_op(EQUALS, _33616, 13);
    }
    DeRef(_33616);
    _33616 = NOVALUE;
    if (IS_ATOM_INT(_33617)) {
        if (_33617 == 0) {
            DeRef(_33618);
            _33618 = 0;
            goto L38; // [1425] 1449
        }
    }
    else {
        if (DBL_PTR(_33617)->dbl == 0.0) {
            DeRef(_33618);
            _33618 = 0;
            goto L38; // [1425] 1449
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33619 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33619);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33620 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33620 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33619 = NOVALUE;
    if (_name_66293 == _33620)
    _33621 = 1;
    else if (IS_ATOM_INT(_name_66293) && IS_ATOM_INT(_33620))
    _33621 = 0;
    else
    _33621 = (compare(_name_66293, _33620) == 0);
    _33620 = NOVALUE;
    DeRef(_33618);
    _33618 = (_33621 != 0);
L38: 
    if (_33618 == 0) {
        _33622 = 0;
        goto L39; // [1449] 1485
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33623 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33624 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33624);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33625 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33625 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33624 = NOVALUE;
    _2 = (int)SEQ_PTR(_33623);
    if (!IS_ATOM_INT(_33625)){
        _33626 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33625)->dbl));
    }
    else{
        _33626 = (int)*(((s1_ptr)_2)->base + _33625);
    }
    _33623 = NOVALUE;
    if (IS_ATOM_INT(_33626)) {
        {unsigned long tu;
             tu = (unsigned long)6 & (unsigned long)_33626;
             _33627 = MAKE_UINT(tu);
        }
    }
    else {
        _33627 = binary_op(AND_BITS, 6, _33626);
    }
    _33626 = NOVALUE;
    if (IS_ATOM_INT(_33627))
    _33622 = (_33627 != 0);
    else
    _33622 = DBL_PTR(_33627)->dbl != 0.0;
L39: 
    if (_33622 != 0) {
        goto L3A; // [1485] 1564
    }
    _33629 = _52sym_scope(_s_66299);
    if (IS_ATOM_INT(_33629)) {
        _33630 = (_33629 == 11);
    }
    else {
        _33630 = binary_op(EQUALS, _33629, 11);
    }
    DeRef(_33629);
    _33629 = NOVALUE;
    if (IS_ATOM_INT(_33630)) {
        if (_33630 == 0) {
            DeRef(_33631);
            _33631 = 0;
            goto L3B; // [1499] 1523
        }
    }
    else {
        if (DBL_PTR(_33630)->dbl == 0.0) {
            DeRef(_33631);
            _33631 = 0;
            goto L3B; // [1499] 1523
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33632 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33632);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33633 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33633 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33632 = NOVALUE;
    if (_name_66293 == _33633)
    _33634 = 1;
    else if (IS_ATOM_INT(_name_66293) && IS_ATOM_INT(_33633))
    _33634 = 0;
    else
    _33634 = (compare(_name_66293, _33633) == 0);
    _33633 = NOVALUE;
    DeRef(_33631);
    _33631 = (_33634 != 0);
L3B: 
    if (_33631 == 0) {
        DeRef(_33635);
        _33635 = 0;
        goto L3C; // [1523] 1559
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _33636 = (int)*(((s1_ptr)_2)->base + _file_66294);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33637 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33637);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _33638 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _33638 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _33637 = NOVALUE;
    _2 = (int)SEQ_PTR(_33636);
    if (!IS_ATOM_INT(_33638)){
        _33639 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33638)->dbl));
    }
    else{
        _33639 = (int)*(((s1_ptr)_2)->base + _33638);
    }
    _33636 = NOVALUE;
    if (IS_ATOM_INT(_33639)) {
        {unsigned long tu;
             tu = (unsigned long)2 & (unsigned long)_33639;
             _33640 = MAKE_UINT(tu);
        }
    }
    else {
        _33640 = binary_op(AND_BITS, 2, _33639);
    }
    _33639 = NOVALUE;
    if (IS_ATOM_INT(_33640))
    _33635 = (_33640 != 0);
    else
    _33635 = DBL_PTR(_33640)->dbl != 0.0;
L3C: 
    if (_33635 == 0)
    {
        _33635 = NOVALUE;
        goto L3D; // [1560] 1578
    }
    else{
        _33635 = NOVALUE;
    }
L3A: 

    /** 				global_found = s*/
    _global_found_66300 = _s_66299;

    /** 				found_in_path += 1*/
    _found_in_path_66304 = _found_in_path_66304 + 1;
L3D: 
L36: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33642 = (int)*(((s1_ptr)_2)->base + _s_66299);
    _2 = (int)SEQ_PTR(_33642);
    _s_66299 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_66299)){
        _s_66299 = (long)DBL_PTR(_s_66299)->dbl;
    }
    _33642 = NOVALUE;

    /** 		end while*/
    goto L31; // [1597] 1253
L32: 

    /** 		if found_in_path != 1 and (( found_in_path + found_outside_path ) != 1 ) then*/
    _33644 = (_found_in_path_66304 != 1);
    if (_33644 == 0) {
        goto L3E; // [1606] 1629
    }
    _33646 = _found_in_path_66304 + _found_outside_path_66305;
    if ((long)((unsigned long)_33646 + (unsigned long)HIGH_BITS) >= 0) 
    _33646 = NewDouble((double)_33646);
    if (IS_ATOM_INT(_33646)) {
        _33647 = (_33646 != 1);
    }
    else {
        _33647 = (DBL_PTR(_33646)->dbl != (double)1);
    }
    DeRef(_33646);
    _33646 = NOVALUE;
    if (_33647 == 0)
    {
        DeRef(_33647);
        _33647 = NOVALUE;
        goto L3E; // [1619] 1629
    }
    else{
        DeRef(_33647);
        _33647 = NOVALUE;
    }

    /** 			return 0*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33627);
    _33627 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33575);
    _33575 = NOVALUE;
    DeRef(_33594);
    _33594 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33610 = NOVALUE;
    DeRef(_33596);
    _33596 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33644);
    _33644 = NOVALUE;
    DeRef(_33564);
    _33564 = NOVALUE;
    DeRef(_33550);
    _33550 = NOVALUE;
    DeRef(_33617);
    _33617 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33560);
    _33560 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    _33638 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33579);
    _33579 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33546);
    _33546 = NOVALUE;
    DeRef(_33558);
    _33558 = NOVALUE;
    DeRef(_33640);
    _33640 = NOVALUE;
    _33625 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33571);
    _33571 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33581);
    _33581 = NOVALUE;
    DeRef(_33585);
    _33585 = NOVALUE;
    DeRef(_33630);
    _33630 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33600);
    _33600 = NOVALUE;
    DeRef(_33603);
    _33603 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33567);
    _33567 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return 0;
L3E: 

    /** 		return global_found*/
    DeRefDS(_name_66293);
    DeRef(_ns_66301);
    DeRef(_33481);
    _33481 = NOVALUE;
    DeRef(_33627);
    _33627 = NOVALUE;
    DeRef(_33516);
    _33516 = NOVALUE;
    DeRef(_33575);
    _33575 = NOVALUE;
    DeRef(_33594);
    _33594 = NOVALUE;
    DeRef(_33483);
    _33483 = NOVALUE;
    _33610 = NOVALUE;
    DeRef(_33596);
    _33596 = NOVALUE;
    _33524 = NOVALUE;
    DeRef(_33644);
    _33644 = NOVALUE;
    DeRef(_33564);
    _33564 = NOVALUE;
    DeRef(_33550);
    _33550 = NOVALUE;
    DeRef(_33617);
    _33617 = NOVALUE;
    DeRef(_33442);
    _33442 = NOVALUE;
    DeRef(_33445);
    _33445 = NOVALUE;
    DeRef(_33560);
    _33560 = NOVALUE;
    DeRef(_33422);
    _33422 = NOVALUE;
    DeRef(_33504);
    _33504 = NOVALUE;
    DeRef(_33487);
    _33487 = NOVALUE;
    DeRef(_33533);
    _33533 = NOVALUE;
    DeRef(_33490);
    _33490 = NOVALUE;
    _33638 = NOVALUE;
    DeRef(_33476);
    _33476 = NOVALUE;
    DeRef(_33431);
    _33431 = NOVALUE;
    _33525 = NOVALUE;
    DeRef(_33579);
    _33579 = NOVALUE;
    DeRef(_33424);
    _33424 = NOVALUE;
    DeRef(_33461);
    _33461 = NOVALUE;
    DeRef(_33546);
    _33546 = NOVALUE;
    DeRef(_33558);
    _33558 = NOVALUE;
    DeRef(_33640);
    _33640 = NOVALUE;
    _33625 = NOVALUE;
    DeRef(_33500);
    _33500 = NOVALUE;
    DeRef(_33571);
    _33571 = NOVALUE;
    DeRef(_33531);
    _33531 = NOVALUE;
    DeRef(_33506);
    _33506 = NOVALUE;
    DeRef(_33449);
    _33449 = NOVALUE;
    DeRef(_33457);
    _33457 = NOVALUE;
    DeRef(_33437);
    _33437 = NOVALUE;
    DeRef(_33494);
    _33494 = NOVALUE;
    _33498 = NOVALUE;
    DeRef(_33473);
    _33473 = NOVALUE;
    DeRef(_33520);
    _33520 = NOVALUE;
    DeRef(_33581);
    _33581 = NOVALUE;
    DeRef(_33585);
    _33585 = NOVALUE;
    DeRef(_33630);
    _33630 = NOVALUE;
    DeRef(_33435);
    _33435 = NOVALUE;
    DeRef(_33529);
    _33529 = NOVALUE;
    DeRef(_33600);
    _33600 = NOVALUE;
    DeRef(_33603);
    _33603 = NOVALUE;
    DeRef(_33514);
    _33514 = NOVALUE;
    DeRef(_33567);
    _33567 = NOVALUE;
    DeRef(_33510);
    _33510 = NOVALUE;
    return _global_found_66300;
L22: 
    ;
}


void _67do_call_proc(int _sub_66681, int _args_66682, int _advance_66683)
{
    int _n_66684 = NOVALUE;
    int _arg_66685 = NOVALUE;
    int _private_block_66700 = NOVALUE;
    int _p_66706 = NOVALUE;
    int _33689 = NOVALUE;
    int _33684 = NOVALUE;
    int _33682 = NOVALUE;
    int _33681 = NOVALUE;
    int _33680 = NOVALUE;
    int _33678 = NOVALUE;
    int _33676 = NOVALUE;
    int _33673 = NOVALUE;
    int _33671 = NOVALUE;
    int _33669 = NOVALUE;
    int _33668 = NOVALUE;
    int _33667 = NOVALUE;
    int _33666 = NOVALUE;
    int _33665 = NOVALUE;
    int _33664 = NOVALUE;
    int _33662 = NOVALUE;
    int _33661 = NOVALUE;
    int _33659 = NOVALUE;
    int _33658 = NOVALUE;
    int _33656 = NOVALUE;
    int _33655 = NOVALUE;
    int _33653 = NOVALUE;
    int _33652 = NOVALUE;
    int _33650 = NOVALUE;
    int _33648 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_advance_66683)) {
        _1 = (long)(DBL_PTR(_advance_66683)->dbl);
        DeRefDS(_advance_66683);
        _advance_66683 = _1;
    }

    /** 	n = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33648 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    _2 = (int)SEQ_PTR(_33648);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _n_66684 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _n_66684 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_n_66684)){
        _n_66684 = (long)DBL_PTR(_n_66684)->dbl;
    }
    _33648 = NOVALUE;

    /** 	arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33650 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    _2 = (int)SEQ_PTR(_33650);
    _arg_66685 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66685)){
        _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
    }
    _33650 = NOVALUE;

    /** 	if SymTab[sub][S_RESIDENT_TASK] != 0 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33652 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    _2 = (int)SEQ_PTR(_33652);
    _33653 = (int)*(((s1_ptr)_2)->base + 25);
    _33652 = NOVALUE;
    if (binary_op_a(EQUALS, _33653, 0)){
        _33653 = NOVALUE;
        goto L1; // [53] 314
    }
    _33653 = NOVALUE;

    /** 		sequence private_block = repeat(0, SymTab[sub][S_STACK_SPACE])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33655 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    _2 = (int)SEQ_PTR(_33655);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _33656 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _33656 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _33655 = NOVALUE;
    DeRef(_private_block_66700);
    _private_block_66700 = Repeat(0, _33656);
    _33656 = NOVALUE;

    /** 		integer p = 1*/
    _p_66706 = 1;

    /** 		for i = 1 to n do*/
    _33658 = _n_66684;
    {
        int _i_66708;
        _i_66708 = 1;
L2: 
        if (_i_66708 > _33658){
            goto L3; // [85] 145
        }

        /** 			private_block[p] = val[arg]*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _33659 = (int)*(((s1_ptr)_2)->base + _arg_66685);
        Ref(_33659);
        _2 = (int)SEQ_PTR(_private_block_66700);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _private_block_66700 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _p_66706);
        _1 = *(int *)_2;
        *(int *)_2 = _33659;
        if( _1 != _33659 ){
            DeRef(_1);
        }
        _33659 = NOVALUE;

        /** 			p += 1*/
        _p_66706 = _p_66706 + 1;

        /** 			val[arg] = args[i]*/
        _2 = (int)SEQ_PTR(_args_66682);
        _33661 = (int)*(((s1_ptr)_2)->base + _i_66708);
        Ref(_33661);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _arg_66685);
        _1 = *(int *)_2;
        *(int *)_2 = _33661;
        if( _1 != _33661 ){
            DeRef(_1);
        }
        _33661 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _33662 = (int)*(((s1_ptr)_2)->base + _arg_66685);
        _2 = (int)SEQ_PTR(_33662);
        _arg_66685 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66685)){
            _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
        }
        _33662 = NOVALUE;

        /** 		end for*/
        _i_66708 = _i_66708 + 1;
        goto L2; // [140] 92
L3: 
        ;
    }

    /** 		while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L4: 
    _33664 = (_arg_66685 != 0);
    if (_33664 == 0) {
        goto L5; // [154] 229
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33666 = (int)*(((s1_ptr)_2)->base + _arg_66685);
    _2 = (int)SEQ_PTR(_33666);
    _33667 = (int)*(((s1_ptr)_2)->base + 4);
    _33666 = NOVALUE;
    if (IS_ATOM_INT(_33667)) {
        _33668 = (_33667 <= 3);
    }
    else {
        _33668 = binary_op(LESSEQ, _33667, 3);
    }
    _33667 = NOVALUE;
    if (_33668 <= 0) {
        if (_33668 == 0) {
            DeRef(_33668);
            _33668 = NOVALUE;
            goto L5; // [177] 229
        }
        else {
            if (!IS_ATOM_INT(_33668) && DBL_PTR(_33668)->dbl == 0.0){
                DeRef(_33668);
                _33668 = NOVALUE;
                goto L5; // [177] 229
            }
            DeRef(_33668);
            _33668 = NOVALUE;
        }
    }
    DeRef(_33668);
    _33668 = NOVALUE;

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33669 = (int)*(((s1_ptr)_2)->base + _arg_66685);
    Ref(_33669);
    _2 = (int)SEQ_PTR(_private_block_66700);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_66700 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_66706);
    _1 = *(int *)_2;
    *(int *)_2 = _33669;
    if( _1 != _33669 ){
        DeRef(_1);
    }
    _33669 = NOVALUE;

    /** 			p += 1*/
    _p_66706 = _p_66706 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_66685);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33671 = (int)*(((s1_ptr)_2)->base + _arg_66685);
    _2 = (int)SEQ_PTR(_33671);
    _arg_66685 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66685)){
        _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
    }
    _33671 = NOVALUE;

    /** 		end while*/
    goto L4; // [226] 150
L5: 

    /** 		arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33673 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    _2 = (int)SEQ_PTR(_33673);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _arg_66685 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _arg_66685 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_arg_66685)){
        _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
    }
    _33673 = NOVALUE;

    /** 		while arg != 0 do*/
L6: 
    if (_arg_66685 == 0)
    goto L7; // [250] 303

    /** 			private_block[p] = val[arg]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33676 = (int)*(((s1_ptr)_2)->base + _arg_66685);
    Ref(_33676);
    _2 = (int)SEQ_PTR(_private_block_66700);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _private_block_66700 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_66706);
    _1 = *(int *)_2;
    *(int *)_2 = _33676;
    if( _1 != _33676 ){
        DeRef(_1);
    }
    _33676 = NOVALUE;

    /** 			p += 1*/
    _p_66706 = _p_66706 + 1;

    /** 			val[arg] = NOVALUE -- necessary?*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _arg_66685);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 			arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33678 = (int)*(((s1_ptr)_2)->base + _arg_66685);
    _2 = (int)SEQ_PTR(_33678);
    _arg_66685 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_66685)){
        _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
    }
    _33678 = NOVALUE;

    /** 		end while*/
    goto L6; // [300] 250
L7: 

    /** 		save_private_block(sub, private_block)*/
    RefDS(_private_block_66700);
    _67save_private_block(_sub_66681, _private_block_66700);
    DeRefDS(_private_block_66700);
    _private_block_66700 = NOVALUE;
    goto L8; // [311] 362
L1: 

    /** 		for i = 1 to n do*/
    _33680 = _n_66684;
    {
        int _i_66748;
        _i_66748 = 1;
L9: 
        if (_i_66748 > _33680){
            goto LA; // [319] 361
        }

        /** 			val[arg] = args[i]*/
        _2 = (int)SEQ_PTR(_args_66682);
        _33681 = (int)*(((s1_ptr)_2)->base + _i_66748);
        Ref(_33681);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _arg_66685);
        _1 = *(int *)_2;
        *(int *)_2 = _33681;
        if( _1 != _33681 ){
            DeRef(_1);
        }
        _33681 = NOVALUE;

        /** 			arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _33682 = (int)*(((s1_ptr)_2)->base + _arg_66685);
        _2 = (int)SEQ_PTR(_33682);
        _arg_66685 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_66685)){
            _arg_66685 = (long)DBL_PTR(_arg_66685)->dbl;
        }
        _33682 = NOVALUE;

        /** 		end for*/
        _i_66748 = _i_66748 + 1;
        goto L9; // [356] 326
LA: 
        ;
    }
L8: 

    /** 	SymTab[sub][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sub_66681 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63025;
    DeRef(_1);
    _33684 = NOVALUE;

    /** 	pc += advance*/
    _67pc_63008 = _67pc_63008 + _advance_66683;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67pc_63008);

    /** 	call_stack = append(call_stack, sub)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _sub_66681);

    /** 	Code = SymTab[sub][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33689 = (int)*(((s1_ptr)_2)->base + _sub_66681);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_33689);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _33689 = NOVALUE;

    /** 	pc = 1*/
    _67pc_63008 = 1;

    /** end procedure*/
    DeRefDS(_args_66682);
    DeRef(_33664);
    _33664 = NOVALUE;
    return;
    ;
}


void _67opCALL_PROC()
{
    int _cf_66769 = NOVALUE;
    int _sub_66771 = NOVALUE;
    int _33738 = NOVALUE;
    int _33737 = NOVALUE;
    int _33736 = NOVALUE;
    int _33735 = NOVALUE;
    int _33734 = NOVALUE;
    int _33733 = NOVALUE;
    int _33732 = NOVALUE;
    int _33731 = NOVALUE;
    int _33730 = NOVALUE;
    int _33729 = NOVALUE;
    int _33726 = NOVALUE;
    int _33725 = NOVALUE;
    int _33724 = NOVALUE;
    int _33723 = NOVALUE;
    int _33721 = NOVALUE;
    int _33720 = NOVALUE;
    int _33719 = NOVALUE;
    int _33718 = NOVALUE;
    int _33717 = NOVALUE;
    int _33714 = NOVALUE;
    int _33713 = NOVALUE;
    int _33712 = NOVALUE;
    int _33711 = NOVALUE;
    int _33710 = NOVALUE;
    int _33707 = NOVALUE;
    int _33706 = NOVALUE;
    int _33704 = NOVALUE;
    int _33702 = NOVALUE;
    int _33701 = NOVALUE;
    int _33700 = NOVALUE;
    int _33699 = NOVALUE;
    int _33698 = NOVALUE;
    int _33696 = NOVALUE;
    int _33695 = NOVALUE;
    int _33693 = NOVALUE;
    int _33691 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cf = Code[pc] = CALL_FUNC*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33691 = (int)*(((s1_ptr)_2)->base + _67pc_63008);
    if (IS_ATOM_INT(_33691)) {
        _cf_66769 = (_33691 == 137);
    }
    else {
        _cf_66769 = binary_op(EQUALS, _33691, 137);
    }
    _33691 = NOVALUE;
    if (!IS_ATOM_INT(_cf_66769)) {
        _1 = (long)(DBL_PTR(_cf_66769)->dbl);
        DeRefDS(_cf_66769);
        _cf_66769 = _1;
    }

    /** 	a = Code[pc+1]  -- routine id*/
    _33693 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33693);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	if val[a] < 0 or val[a] >= length(e_routine) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33695 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33695)) {
        _33696 = (_33695 < 0);
    }
    else {
        _33696 = binary_op(LESS, _33695, 0);
    }
    _33695 = NOVALUE;
    if (IS_ATOM_INT(_33696)) {
        if (_33696 != 0) {
            goto L1; // [49] 75
        }
    }
    else {
        if (DBL_PTR(_33696)->dbl != 0.0) {
            goto L1; // [49] 75
        }
    }
    _2 = (int)SEQ_PTR(_67val_63018);
    _33698 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_67e_routine_63056)){
            _33699 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _33699 = 1;
    }
    if (IS_ATOM_INT(_33698)) {
        _33700 = (_33698 >= _33699);
    }
    else {
        _33700 = binary_op(GREATEREQ, _33698, _33699);
    }
    _33698 = NOVALUE;
    _33699 = NOVALUE;
    if (_33700 == 0) {
        DeRef(_33700);
        _33700 = NOVALUE;
        goto L2; // [71] 81
    }
    else {
        if (!IS_ATOM_INT(_33700) && DBL_PTR(_33700)->dbl == 0.0){
            DeRef(_33700);
            _33700 = NOVALUE;
            goto L2; // [71] 81
        }
        DeRef(_33700);
        _33700 = NOVALUE;
    }
    DeRef(_33700);
    _33700 = NOVALUE;
L1: 

    /** 		RTFatal("invalid routine id")*/
    RefDS(_32066);
    _67RTFatal(_32066);
L2: 

    /** 	sub = e_routine[val[a]+1]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33701 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33701)) {
        _33702 = _33701 + 1;
    }
    else
    _33702 = binary_op(PLUS, 1, _33701);
    _33701 = NOVALUE;
    _2 = (int)SEQ_PTR(_67e_routine_63056);
    if (!IS_ATOM_INT(_33702)){
        _sub_66771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33702)->dbl));
    }
    else{
        _sub_66771 = (int)*(((s1_ptr)_2)->base + _33702);
    }

    /** 	b = Code[pc+2]  -- argument list*/
    _33704 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33704);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if cf then*/
    if (_cf_66769 == 0)
    {
        goto L3; // [121] 169
    }
    else{
    }

    /** 		if SymTab[sub][S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33706 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33706);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _33707 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _33707 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _33706 = NOVALUE;
    if (binary_op_a(NOTEQ, _33707, 27)){
        _33707 = NOVALUE;
        goto L4; // [140] 212
    }
    _33707 = NOVALUE;

    /** 			RTFatal(sprintf("%s() does not return a value", SymTab[sub][S_NAME]))*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33710 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33710);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33711 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33711 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33710 = NOVALUE;
    _33712 = EPrintf(-9999999, _33709, _33711);
    _33711 = NOVALUE;
    _67RTFatal(_33712);
    _33712 = NOVALUE;
    goto L4; // [166] 212
L3: 

    /** 		if SymTab[sub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33713 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33713);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _33714 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _33714 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _33713 = NOVALUE;
    if (binary_op_a(EQUALS, _33714, 27)){
        _33714 = NOVALUE;
        goto L5; // [185] 211
    }
    _33714 = NOVALUE;

    /** 			RTFatal(sprintf("the value returned by %s() must be assigned or used",*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33717 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33717);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33718 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33718 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33717 = NOVALUE;
    _33719 = EPrintf(-9999999, _33716, _33718);
    _33718 = NOVALUE;
    _67RTFatal(_33719);
    _33719 = NOVALUE;
L5: 
L4: 

    /** 	if atom(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33720 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33721 = IS_ATOM(_33720);
    _33720 = NOVALUE;
    if (_33721 == 0)
    {
        _33721 = NOVALUE;
        goto L6; // [225] 234
    }
    else{
        _33721 = NOVALUE;
    }

    /** 		RTFatal("argument list must be a sequence")*/
    RefDS(_33722);
    _67RTFatal(_33722);
L6: 

    /** 	if SymTab[sub][S_NUM_ARGS] != length(val[b]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33723 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33723);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _33724 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _33724 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _33723 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _33725 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_33725)){
            _33726 = SEQ_PTR(_33725)->length;
    }
    else {
        _33726 = 1;
    }
    _33725 = NOVALUE;
    if (binary_op_a(EQUALS, _33724, _33726)){
        _33724 = NOVALUE;
        _33726 = NOVALUE;
        goto L7; // [259] 314
    }
    _33724 = NOVALUE;
    _33726 = NOVALUE;

    /** 		RTFatal(sprintf("call to %s() via routine-id should pass %d arguments, not %d",*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33729 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33729);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _33730 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _33730 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _33729 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33731 = (int)*(((s1_ptr)_2)->base + _sub_66771);
    _2 = (int)SEQ_PTR(_33731);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _33732 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _33732 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _33731 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _33733 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_33733)){
            _33734 = SEQ_PTR(_33733)->length;
    }
    else {
        _33734 = 1;
    }
    _33733 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_33730);
    *((int *)(_2+4)) = _33730;
    Ref(_33732);
    *((int *)(_2+8)) = _33732;
    *((int *)(_2+12)) = _33734;
    _33735 = MAKE_SEQ(_1);
    _33734 = NOVALUE;
    _33732 = NOVALUE;
    _33730 = NOVALUE;
    _33736 = EPrintf(-9999999, _33728, _33735);
    DeRefDS(_33735);
    _33735 = NOVALUE;
    _67RTFatal(_33736);
    _33736 = NOVALUE;
L7: 

    /** 	do_call_proc( sub, val[b], 3 + cf )*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33737 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33738 = 3 + _cf_66769;
    if ((long)((unsigned long)_33738 + (unsigned long)HIGH_BITS) >= 0) 
    _33738 = NewDouble((double)_33738);
    Ref(_33737);
    _67do_call_proc(_sub_66771, _33737, _33738);
    _33737 = NOVALUE;
    _33738 = NOVALUE;

    /** end procedure*/
    DeRef(_33693);
    _33693 = NOVALUE;
    DeRef(_33704);
    _33704 = NOVALUE;
    DeRef(_33696);
    _33696 = NOVALUE;
    DeRef(_33702);
    _33702 = NOVALUE;
    _33725 = NOVALUE;
    _33733 = NOVALUE;
    return;
    ;
}


void _67opROUTINE_ID()
{
    int _sub_66849 = NOVALUE;
    int _fn_66850 = NOVALUE;
    int _p_66851 = NOVALUE;
    int _stlen_66852 = NOVALUE;
    int _name_66853 = NOVALUE;
    int _33765 = NOVALUE;
    int _33764 = NOVALUE;
    int _33762 = NOVALUE;
    int _33760 = NOVALUE;
    int _33759 = NOVALUE;
    int _33758 = NOVALUE;
    int _33757 = NOVALUE;
    int _33756 = NOVALUE;
    int _33755 = NOVALUE;
    int _33753 = NOVALUE;
    int _33751 = NOVALUE;
    int _33748 = NOVALUE;
    int _33746 = NOVALUE;
    int _33744 = NOVALUE;
    int _33743 = NOVALUE;
    int _33741 = NOVALUE;
    int _33739 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sub = Code[pc+1]   -- CurrentSub*/
    _33739 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_66849 = (int)*(((s1_ptr)_2)->base + _33739);
    if (!IS_ATOM_INT(_sub_66849)){
        _sub_66849 = (long)DBL_PTR(_sub_66849)->dbl;
    }

    /** 	stlen = Code[pc+2]  -- s.t. length*/
    _33741 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _stlen_66852 = (int)*(((s1_ptr)_2)->base + _33741);
    if (!IS_ATOM_INT(_stlen_66852)){
        _stlen_66852 = (long)DBL_PTR(_stlen_66852)->dbl;
    }

    /** 	name = val[Code[pc+3]]  -- routine name sequence*/
    _33743 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33744 = (int)*(((s1_ptr)_2)->base + _33743);
    DeRef(_name_66853);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33744)){
        _name_66853 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33744)->dbl));
    }
    else{
        _name_66853 = (int)*(((s1_ptr)_2)->base + _33744);
    }
    Ref(_name_66853);

    /** 	fn = Code[pc+4]    -- file number*/
    _33746 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _fn_66850 = (int)*(((s1_ptr)_2)->base + _33746);
    if (!IS_ATOM_INT(_fn_66850)){
        _fn_66850 = (long)DBL_PTR(_fn_66850)->dbl;
    }

    /** 	target = Code[pc+5]*/
    _33748 = _67pc_63008 + 5;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33748);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	pc += 6*/
    _67pc_63008 = _67pc_63008 + 6;

    /** 	if atom(name) then*/
    _33751 = IS_ATOM(_name_66853);
    if (_33751 == 0)
    {
        _33751 = NOVALUE;
        goto L1; // [98] 117
    }
    else{
        _33751 = NOVALUE;
    }

    /** 		val[target] = -1*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 		return*/
    DeRef(_name_66853);
    _33739 = NOVALUE;
    _33741 = NOVALUE;
    _33743 = NOVALUE;
    _33744 = NOVALUE;
    _33746 = NOVALUE;
    _33748 = NOVALUE;
    return;
L1: 

    /** 	p = RTLookup(name, fn, sub, stlen)*/
    Ref(_name_66853);
    _p_66851 = _67RTLookup(_name_66853, _fn_66850, _sub_66849, _stlen_66852);
    if (!IS_ATOM_INT(_p_66851)) {
        _1 = (long)(DBL_PTR(_p_66851)->dbl);
        DeRefDS(_p_66851);
        _p_66851 = _1;
    }

    /** 	if p = 0 or not find(SymTab[p][S_TOKEN], RTN_TOKS) then*/
    _33753 = (_p_66851 == 0);
    if (_33753 != 0) {
        goto L2; // [134] 165
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _33755 = (int)*(((s1_ptr)_2)->base + _p_66851);
    _2 = (int)SEQ_PTR(_33755);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _33756 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _33756 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _33755 = NOVALUE;
    _33757 = find_from(_33756, _28RTN_TOKS_11302, 1);
    _33756 = NOVALUE;
    _33758 = (_33757 == 0);
    _33757 = NOVALUE;
    if (_33758 == 0)
    {
        DeRef(_33758);
        _33758 = NOVALUE;
        goto L3; // [161] 181
    }
    else{
        DeRef(_33758);
        _33758 = NOVALUE;
    }
L2: 

    /** 		val[target] = -1  -- name is not a routine*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 		return*/
    DeRef(_name_66853);
    DeRef(_33739);
    _33739 = NOVALUE;
    DeRef(_33741);
    _33741 = NOVALUE;
    DeRef(_33743);
    _33743 = NOVALUE;
    _33744 = NOVALUE;
    DeRef(_33746);
    _33746 = NOVALUE;
    DeRef(_33748);
    _33748 = NOVALUE;
    DeRef(_33753);
    _33753 = NOVALUE;
    return;
L3: 

    /** 	for i = 1 to length(e_routine) do*/
    if (IS_SEQUENCE(_67e_routine_63056)){
            _33759 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _33759 = 1;
    }
    {
        int _i_66885;
        _i_66885 = 1;
L4: 
        if (_i_66885 > _33759){
            goto L5; // [188] 234
        }

        /** 		if e_routine[i] = p then*/
        _2 = (int)SEQ_PTR(_67e_routine_63056);
        _33760 = (int)*(((s1_ptr)_2)->base + _i_66885);
        if (_33760 != _p_66851)
        goto L6; // [203] 227

        /** 			val[target] = i - 1  -- routine was already assigned an id*/
        _33762 = _i_66885 - 1;
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
        _1 = *(int *)_2;
        *(int *)_2 = _33762;
        if( _1 != _33762 ){
            DeRef(_1);
        }
        _33762 = NOVALUE;

        /** 			return*/
        DeRef(_name_66853);
        DeRef(_33739);
        _33739 = NOVALUE;
        DeRef(_33741);
        _33741 = NOVALUE;
        DeRef(_33743);
        _33743 = NOVALUE;
        _33744 = NOVALUE;
        DeRef(_33746);
        _33746 = NOVALUE;
        DeRef(_33748);
        _33748 = NOVALUE;
        DeRef(_33753);
        _33753 = NOVALUE;
        _33760 = NOVALUE;
        return;
L6: 

        /** 	end for*/
        _i_66885 = _i_66885 + 1;
        goto L4; // [229] 195
L5: 
        ;
    }

    /** 	e_routine = append(e_routine, p)*/
    Append(&_67e_routine_63056, _67e_routine_63056, _p_66851);

    /** 	val[target] = length(e_routine) - 1*/
    if (IS_SEQUENCE(_67e_routine_63056)){
            _33764 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _33764 = 1;
    }
    _33765 = _33764 - 1;
    _33764 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33765;
    if( _1 != _33765 ){
        DeRef(_1);
    }
    _33765 = NOVALUE;

    /** end procedure*/
    DeRef(_name_66853);
    DeRef(_33739);
    _33739 = NOVALUE;
    DeRef(_33741);
    _33741 = NOVALUE;
    DeRef(_33743);
    _33743 = NOVALUE;
    _33744 = NOVALUE;
    DeRef(_33746);
    _33746 = NOVALUE;
    DeRef(_33748);
    _33748 = NOVALUE;
    DeRef(_33753);
    _33753 = NOVALUE;
    _33760 = NOVALUE;
    return;
    ;
}


void _67opAPPEND()
{
    int _33774 = NOVALUE;
    int _33773 = NOVALUE;
    int _33772 = NOVALUE;
    int _33770 = NOVALUE;
    int _33768 = NOVALUE;
    int _33766 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33766 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33766);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33768 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33768);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33770 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33770);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = append(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33772 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33773 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_33773);
    Append(&_33774, _33772, _33773);
    _33772 = NOVALUE;
    _33773 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33774;
    if( _1 != _33774 ){
        DeRef(_1);
    }
    _33774 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33766 = NOVALUE;
    _33768 = NOVALUE;
    _33770 = NOVALUE;
    return;
    ;
}


void _67opPREPEND()
{
    int _33784 = NOVALUE;
    int _33783 = NOVALUE;
    int _33782 = NOVALUE;
    int _33780 = NOVALUE;
    int _33778 = NOVALUE;
    int _33776 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33776 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33776);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33778 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33778);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33780 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33780);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = prepend(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33782 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33783 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Ref(_33783);
    Prepend(&_33784, _33782, _33783);
    _33782 = NOVALUE;
    _33783 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33784;
    if( _1 != _33784 ){
        DeRef(_1);
    }
    _33784 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33776 = NOVALUE;
    _33778 = NOVALUE;
    _33780 = NOVALUE;
    return;
    ;
}


void _67opCONCAT()
{
    int _33794 = NOVALUE;
    int _33793 = NOVALUE;
    int _33792 = NOVALUE;
    int _33790 = NOVALUE;
    int _33788 = NOVALUE;
    int _33786 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33786 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33786);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33788 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33788);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33790 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33790);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = val[a] & val[b]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33792 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33793 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_33792) && IS_ATOM(_33793)) {
        Ref(_33793);
        Append(&_33794, _33792, _33793);
    }
    else if (IS_ATOM(_33792) && IS_SEQUENCE(_33793)) {
        Ref(_33792);
        Prepend(&_33794, _33793, _33792);
    }
    else {
        Concat((object_ptr)&_33794, _33792, _33793);
        _33792 = NOVALUE;
    }
    _33792 = NOVALUE;
    _33793 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33794;
    if( _1 != _33794 ){
        DeRef(_1);
    }
    _33794 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33786 = NOVALUE;
    _33788 = NOVALUE;
    _33790 = NOVALUE;
    return;
    ;
}


void _67opCONCAT_N()
{
    int _n_66941 = NOVALUE;
    int _x_66942 = NOVALUE;
    int _33810 = NOVALUE;
    int _33808 = NOVALUE;
    int _33807 = NOVALUE;
    int _33805 = NOVALUE;
    int _33804 = NOVALUE;
    int _33803 = NOVALUE;
    int _33802 = NOVALUE;
    int _33801 = NOVALUE;
    int _33799 = NOVALUE;
    int _33798 = NOVALUE;
    int _33796 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = Code[pc+1] -- number of items*/
    _33796 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _n_66941 = (int)*(((s1_ptr)_2)->base + _33796);
    if (!IS_ATOM_INT(_n_66941)){
        _n_66941 = (long)DBL_PTR(_n_66941)->dbl;
    }

    /** 	x = val[Code[pc+2]] -- last one*/
    _33798 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33799 = (int)*(((s1_ptr)_2)->base + _33798);
    DeRef(_x_66942);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33799)){
        _x_66942 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33799)->dbl));
    }
    else{
        _x_66942 = (int)*(((s1_ptr)_2)->base + _33799);
    }
    Ref(_x_66942);

    /** 	for i = pc+3 to pc+n+1 do*/
    _33801 = _67pc_63008 + 3;
    if ((long)((unsigned long)_33801 + (unsigned long)HIGH_BITS) >= 0) 
    _33801 = NewDouble((double)_33801);
    _33802 = _67pc_63008 + _n_66941;
    if ((long)((unsigned long)_33802 + (unsigned long)HIGH_BITS) >= 0) 
    _33802 = NewDouble((double)_33802);
    if (IS_ATOM_INT(_33802)) {
        _33803 = _33802 + 1;
        if (_33803 > MAXINT){
            _33803 = NewDouble((double)_33803);
        }
    }
    else
    _33803 = binary_op(PLUS, 1, _33802);
    DeRef(_33802);
    _33802 = NOVALUE;
    {
        int _i_66951;
        Ref(_33801);
        _i_66951 = _33801;
L1: 
        if (binary_op_a(GREATER, _i_66951, _33803)){
            goto L2; // [55] 87
        }

        /** 		x = val[Code[i]] & x*/
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_i_66951)){
            _33804 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_66951)->dbl));
        }
        else{
            _33804 = (int)*(((s1_ptr)_2)->base + _i_66951);
        }
        _2 = (int)SEQ_PTR(_67val_63018);
        if (!IS_ATOM_INT(_33804)){
            _33805 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33804)->dbl));
        }
        else{
            _33805 = (int)*(((s1_ptr)_2)->base + _33804);
        }
        if (IS_SEQUENCE(_33805) && IS_ATOM(_x_66942)) {
            Ref(_x_66942);
            Append(&_x_66942, _33805, _x_66942);
        }
        else if (IS_ATOM(_33805) && IS_SEQUENCE(_x_66942)) {
            Ref(_33805);
            Prepend(&_x_66942, _x_66942, _33805);
        }
        else {
            Concat((object_ptr)&_x_66942, _33805, _x_66942);
            _33805 = NOVALUE;
        }
        _33805 = NOVALUE;

        /** 	end for*/
        _0 = _i_66951;
        if (IS_ATOM_INT(_i_66951)) {
            _i_66951 = _i_66951 + 1;
            if ((long)((unsigned long)_i_66951 +(unsigned long) HIGH_BITS) >= 0){
                _i_66951 = NewDouble((double)_i_66951);
            }
        }
        else {
            _i_66951 = binary_op_a(PLUS, _i_66951, 1);
        }
        DeRef(_0);
        goto L1; // [82] 62
L2: 
        ;
        DeRef(_i_66951);
    }

    /** 	target = Code[pc+n+2]*/
    _33807 = _67pc_63008 + _n_66941;
    if ((long)((unsigned long)_33807 + (unsigned long)HIGH_BITS) >= 0) 
    _33807 = NewDouble((double)_33807);
    if (IS_ATOM_INT(_33807)) {
        _33808 = _33807 + 2;
    }
    else {
        _33808 = NewDouble(DBL_PTR(_33807)->dbl + (double)2);
    }
    DeRef(_33807);
    _33807 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!IS_ATOM_INT(_33808)){
        _67target_63013 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33808)->dbl));
    }
    else{
        _67target_63013 = (int)*(((s1_ptr)_2)->base + _33808);
    }
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = x*/
    Ref(_x_66942);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _x_66942;
    DeRef(_1);

    /** 	pc += n+3*/
    _33810 = _n_66941 + 3;
    if ((long)((unsigned long)_33810 + (unsigned long)HIGH_BITS) >= 0) 
    _33810 = NewDouble((double)_33810);
    if (IS_ATOM_INT(_33810)) {
        _67pc_63008 = _67pc_63008 + _33810;
    }
    else {
        _67pc_63008 = NewDouble((double)_67pc_63008 + DBL_PTR(_33810)->dbl);
    }
    DeRef(_33810);
    _33810 = NOVALUE;
    if (!IS_ATOM_INT(_67pc_63008)) {
        _1 = (long)(DBL_PTR(_67pc_63008)->dbl);
        DeRefDS(_67pc_63008);
        _67pc_63008 = _1;
    }

    /** end procedure*/
    DeRef(_x_66942);
    DeRef(_33796);
    _33796 = NOVALUE;
    DeRef(_33798);
    _33798 = NOVALUE;
    _33799 = NOVALUE;
    DeRef(_33801);
    _33801 = NOVALUE;
    _33804 = NOVALUE;
    DeRef(_33803);
    _33803 = NOVALUE;
    DeRef(_33808);
    _33808 = NOVALUE;
    return;
    ;
}


void _67opREPEAT()
{
    int _33831 = NOVALUE;
    int _33830 = NOVALUE;
    int _33829 = NOVALUE;
    int _33825 = NOVALUE;
    int _33822 = NOVALUE;
    int _33819 = NOVALUE;
    int _33818 = NOVALUE;
    int _33816 = NOVALUE;
    int _33814 = NOVALUE;
    int _33812 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33812 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33812);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33814 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33814);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33816 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33816);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if not atom(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33818 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33819 = IS_ATOM(_33818);
    _33818 = NOVALUE;
    if (_33819 != 0)
    goto L1; // [62] 71
    _33819 = NOVALUE;

    /** 		RTFatal("repetition count must be an atom")*/
    RefDS(_33821);
    _67RTFatal(_33821);
L1: 

    /** 	if val[b] < 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33822 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(GREATEREQ, _33822, 0)){
        _33822 = NOVALUE;
        goto L2; // [81] 91
    }
    _33822 = NOVALUE;

    /** 		RTFatal("repetition count must not be negative")*/
    RefDS(_33824);
    _67RTFatal(_33824);
L2: 

    /** 	if val[b] > 1073741823 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33825 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (binary_op_a(LESSEQ, _33825, 1073741823)){
        _33825 = NOVALUE;
        goto L3; // [101] 111
    }
    _33825 = NOVALUE;

    /** 		RTFatal("repetition count is too large")*/
    RefDS(_33828);
    _67RTFatal(_33828);
L3: 

    /** 	val[target] = repeat(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33829 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33830 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33831 = Repeat(_33829, _33830);
    _33829 = NOVALUE;
    _33830 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33831;
    if( _1 != _33831 ){
        DeRef(_1);
    }
    _33831 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33812);
    _33812 = NOVALUE;
    DeRef(_33814);
    _33814 = NOVALUE;
    DeRef(_33816);
    _33816 = NOVALUE;
    return;
    ;
}


void _67opDATE()
{
    int _33835 = NOVALUE;
    int _33833 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _33833 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33833);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = date()*/
    _33835 = Date();
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33835;
    if( _1 != _33835 ){
        DeRef(_1);
    }
    _33835 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _33833 = NOVALUE;
    return;
    ;
}


void _67opTIME()
{
    int _33839 = NOVALUE;
    int _33837 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _33837 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33837);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = time()*/
    _33839 = NewDouble(current_time());
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33839;
    if( _1 != _33839 ){
        DeRef(_1);
    }
    _33839 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _33837 = NOVALUE;
    return;
    ;
}


void _67opSPACE_USED()
{
    int _0, _1, _2;
    

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opNOP2()
{
    int _0, _1, _2;
    

    /** 	pc+= 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opPOSITION()
{
    int _33848 = NOVALUE;
    int _33847 = NOVALUE;
    int _33845 = NOVALUE;
    int _33843 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33843 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33843);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33845 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33845);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	position(val[a], val[b])  -- error checks*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33847 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33848 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    Position(_33847, _33848);
    _33847 = NOVALUE;
    _33848 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33843 = NOVALUE;
    _33845 = NOVALUE;
    return;
    ;
}


void _67opEQUAL()
{
    int _33858 = NOVALUE;
    int _33857 = NOVALUE;
    int _33856 = NOVALUE;
    int _33854 = NOVALUE;
    int _33852 = NOVALUE;
    int _33850 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33850 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33850);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33852 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33852);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33854 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33854);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = equal(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33856 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33857 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (_33856 == _33857)
    _33858 = 1;
    else if (IS_ATOM_INT(_33856) && IS_ATOM_INT(_33857))
    _33858 = 0;
    else
    _33858 = (compare(_33856, _33857) == 0);
    _33856 = NOVALUE;
    _33857 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33858;
    if( _1 != _33858 ){
        DeRef(_1);
    }
    _33858 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33850 = NOVALUE;
    _33852 = NOVALUE;
    _33854 = NOVALUE;
    return;
    ;
}


void _67opHASH()
{
    int _33868 = NOVALUE;
    int _33867 = NOVALUE;
    int _33866 = NOVALUE;
    int _33864 = NOVALUE;
    int _33862 = NOVALUE;
    int _33860 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33860 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33860);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33862 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33862);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33864 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33864);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = hash(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33866 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33867 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33868 = calc_hash(_33866, _33867);
    _33866 = NOVALUE;
    _33867 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33868;
    if( _1 != _33868 ){
        DeRef(_1);
    }
    _33868 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33860 = NOVALUE;
    _33862 = NOVALUE;
    _33864 = NOVALUE;
    return;
    ;
}


void _67opCOMPARE()
{
    int _33878 = NOVALUE;
    int _33877 = NOVALUE;
    int _33876 = NOVALUE;
    int _33874 = NOVALUE;
    int _33872 = NOVALUE;
    int _33870 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33870 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33870);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33872 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33872);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33874 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33874);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = compare(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33876 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33877 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_33876) && IS_ATOM_INT(_33877)){
        _33878 = (_33876 < _33877) ? -1 : (_33876 > _33877);
    }
    else{
        _33878 = compare(_33876, _33877);
    }
    _33876 = NOVALUE;
    _33877 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33878;
    if( _1 != _33878 ){
        DeRef(_1);
    }
    _33878 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _33870 = NOVALUE;
    _33872 = NOVALUE;
    _33874 = NOVALUE;
    return;
    ;
}


void _67opFIND()
{
    int _33892 = NOVALUE;
    int _33891 = NOVALUE;
    int _33890 = NOVALUE;
    int _33887 = NOVALUE;
    int _33886 = NOVALUE;
    int _33884 = NOVALUE;
    int _33882 = NOVALUE;
    int _33880 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33880 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33880);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33882 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33882);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33884 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33884);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if not sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33886 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33887 = IS_SEQUENCE(_33886);
    _33886 = NOVALUE;
    if (_33887 != 0)
    goto L1; // [62] 71
    _33887 = NOVALUE;

    /** 		RTFatal("second argument of find() must be a sequence")*/
    RefDS(_33889);
    _67RTFatal(_33889);
L1: 

    /** 	val[target] = find(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33890 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33891 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33892 = find_from(_33890, _33891, 1);
    _33890 = NOVALUE;
    _33891 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33892;
    if( _1 != _33892 ){
        DeRef(_1);
    }
    _33892 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33880);
    _33880 = NOVALUE;
    DeRef(_33882);
    _33882 = NOVALUE;
    DeRef(_33884);
    _33884 = NOVALUE;
    return;
    ;
}


void _67opMATCH()
{
    int _33914 = NOVALUE;
    int _33913 = NOVALUE;
    int _33912 = NOVALUE;
    int _33909 = NOVALUE;
    int _33908 = NOVALUE;
    int _33905 = NOVALUE;
    int _33904 = NOVALUE;
    int _33901 = NOVALUE;
    int _33900 = NOVALUE;
    int _33898 = NOVALUE;
    int _33896 = NOVALUE;
    int _33894 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33894 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33894);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _33896 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _33896);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _33898 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33898);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33900 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33901 = IS_SEQUENCE(_33900);
    _33900 = NOVALUE;
    if (_33901 != 0)
    goto L1; // [62] 71
    _33901 = NOVALUE;

    /** 		RTFatal("first argument of match() must be a sequence")*/
    RefDS(_33903);
    _67RTFatal(_33903);
L1: 

    /** 	if not sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33904 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33905 = IS_SEQUENCE(_33904);
    _33904 = NOVALUE;
    if (_33905 != 0)
    goto L2; // [84] 93
    _33905 = NOVALUE;

    /** 		RTFatal("second argument of match() must be a sequence")*/
    RefDS(_33907);
    _67RTFatal(_33907);
L2: 

    /** 	if length(val[a]) = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33908 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_33908)){
            _33909 = SEQ_PTR(_33908)->length;
    }
    else {
        _33909 = 1;
    }
    _33908 = NOVALUE;
    if (_33909 != 0)
    goto L3; // [106] 116

    /** 		 RTFatal("first argument of match() must be a non-empty sequence")*/
    RefDS(_33911);
    _67RTFatal(_33911);
L3: 

    /** 	val[target] = match(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33912 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _33913 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _33914 = e_match_from(_33912, _33913, 1);
    _33912 = NOVALUE;
    _33913 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33914;
    if( _1 != _33914 ){
        DeRef(_1);
    }
    _33914 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_33894);
    _33894 = NOVALUE;
    DeRef(_33896);
    _33896 = NOVALUE;
    DeRef(_33898);
    _33898 = NOVALUE;
    _33908 = NOVALUE;
    return;
    ;
}


void _67opFIND_FROM()
{
    int _s_67122 = NOVALUE;
    int _33937 = NOVALUE;
    int _33935 = NOVALUE;
    int _33934 = NOVALUE;
    int _33933 = NOVALUE;
    int _33931 = NOVALUE;
    int _33930 = NOVALUE;
    int _33929 = NOVALUE;
    int _33928 = NOVALUE;
    int _33924 = NOVALUE;
    int _33923 = NOVALUE;
    int _33922 = NOVALUE;
    int _33921 = NOVALUE;
    int _33919 = NOVALUE;
    int _33917 = NOVALUE;
    int _33916 = NOVALUE;
    int _0, _1, _2;
    

    /** 		c = val[Code[pc+3]]*/
    _33916 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33917 = (int)*(((s1_ptr)_2)->base + _33916);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33917)){
        _67c_63011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33917)->dbl));
    }
    else{
        _67c_63011 = (int)*(((s1_ptr)_2)->base + _33917);
    }
    if (!IS_ATOM_INT(_67c_63011))
    _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;

    /** 		target = Code[pc+4]*/
    _33919 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33919);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 		if not sequence(val[Code[pc+2]]) then*/
    _33921 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33922 = (int)*(((s1_ptr)_2)->base + _33921);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33922)){
        _33923 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33922)->dbl));
    }
    else{
        _33923 = (int)*(((s1_ptr)_2)->base + _33922);
    }
    _33924 = IS_SEQUENCE(_33923);
    _33923 = NOVALUE;
    if (_33924 != 0)
    goto L1; // [60] 82
    _33924 = NOVALUE;

    /** 				RTFatal("second argument of find_from() must be a sequence")*/
    RefDS(_33926);
    _67RTFatal(_33926);

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67122);
    _33916 = NOVALUE;
    _33917 = NOVALUE;
    _33919 = NOVALUE;
    _33921 = NOVALUE;
    _33922 = NOVALUE;
    return;
L1: 

    /** 		s = val[Code[pc+2]][c..$]*/
    _33928 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33929 = (int)*(((s1_ptr)_2)->base + _33928);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33929)){
        _33930 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33929)->dbl));
    }
    else{
        _33930 = (int)*(((s1_ptr)_2)->base + _33929);
    }
    if (IS_SEQUENCE(_33930)){
            _33931 = SEQ_PTR(_33930)->length;
    }
    else {
        _33931 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_67122;
    RHS_Slice(_33930, _67c_63011, _33931);
    _33930 = NOVALUE;

    /** 		b = find( val[Code[pc+1]], s )*/
    _33933 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33934 = (int)*(((s1_ptr)_2)->base + _33933);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33934)){
        _33935 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33934)->dbl));
    }
    else{
        _33935 = (int)*(((s1_ptr)_2)->base + _33934);
    }
    _67b_63010 = find_from(_33935, _s_67122, 1);
    _33935 = NOVALUE;

    /** 		if b then*/
    if (_67b_63010 == 0)
    {
        goto L2; // [141] 161
    }
    else{
    }

    /** 				b += c - 1*/
    _33937 = _67c_63011 - 1;
    if ((long)((unsigned long)_33937 +(unsigned long) HIGH_BITS) >= 0){
        _33937 = NewDouble((double)_33937);
    }
    if (IS_ATOM_INT(_33937)) {
        _67b_63010 = _67b_63010 + _33937;
    }
    else {
        _67b_63010 = NewDouble((double)_67b_63010 + DBL_PTR(_33937)->dbl);
    }
    DeRef(_33937);
    _33937 = NOVALUE;
    if (!IS_ATOM_INT(_67b_63010)) {
        _1 = (long)(DBL_PTR(_67b_63010)->dbl);
        DeRefDS(_67b_63010);
        _67b_63010 = _1;
    }
L2: 

    /** 		val[target] = b*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _67b_63010;
    DeRef(_1);

    /** 		pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_s_67122);
    DeRef(_33916);
    _33916 = NOVALUE;
    _33917 = NOVALUE;
    DeRef(_33919);
    _33919 = NOVALUE;
    DeRef(_33921);
    _33921 = NOVALUE;
    _33922 = NOVALUE;
    DeRef(_33928);
    _33928 = NOVALUE;
    _33929 = NOVALUE;
    DeRef(_33933);
    _33933 = NOVALUE;
    _33934 = NOVALUE;
    return;
    ;
}


void _67opMATCH_FROM()
{
    int _s_67156 = NOVALUE;
    int _33980 = NOVALUE;
    int _33979 = NOVALUE;
    int _33977 = NOVALUE;
    int _33976 = NOVALUE;
    int _33975 = NOVALUE;
    int _33974 = NOVALUE;
    int _33973 = NOVALUE;
    int _33972 = NOVALUE;
    int _33971 = NOVALUE;
    int _33970 = NOVALUE;
    int _33969 = NOVALUE;
    int _33968 = NOVALUE;
    int _33966 = NOVALUE;
    int _33960 = NOVALUE;
    int _33956 = NOVALUE;
    int _33955 = NOVALUE;
    int _33951 = NOVALUE;
    int _33950 = NOVALUE;
    int _33948 = NOVALUE;
    int _33946 = NOVALUE;
    int _33945 = NOVALUE;
    int _33943 = NOVALUE;
    int _33941 = NOVALUE;
    int _33940 = NOVALUE;
    int _0, _1, _2;
    

    /** 		c = val[Code[pc+3]]*/
    _33940 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33941 = (int)*(((s1_ptr)_2)->base + _33940);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33941)){
        _67c_63011 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33941)->dbl));
    }
    else{
        _67c_63011 = (int)*(((s1_ptr)_2)->base + _33941);
    }
    if (!IS_ATOM_INT(_67c_63011))
    _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;

    /** 		target = Code[pc+4]*/
    _33943 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33943);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 		s = val[Code[pc+2]]*/
    _33945 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _33946 = (int)*(((s1_ptr)_2)->base + _33945);
    DeRef(_s_67156);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_33946)){
        _s_67156 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_33946)->dbl));
    }
    else{
        _s_67156 = (int)*(((s1_ptr)_2)->base + _33946);
    }
    Ref(_s_67156);

    /** 		a = Code[pc+1]*/
    _33948 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33948);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 		if not sequence(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33950 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33951 = IS_SEQUENCE(_33950);
    _33950 = NOVALUE;
    if (_33951 != 0)
    goto L1; // [86] 108
    _33951 = NOVALUE;

    /** 				RTFatal("first argument of match_from() must be a sequence")*/
    RefDS(_33953);
    _67RTFatal(_33953);

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67156);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    _33943 = NOVALUE;
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    _33948 = NOVALUE;
    return;
L1: 

    /** 		if length(val[a]) = 0 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33955 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_SEQUENCE(_33955)){
            _33956 = SEQ_PTR(_33955)->length;
    }
    else {
        _33956 = 1;
    }
    _33955 = NOVALUE;
    if (_33956 != 0)
    goto L2; // [121] 144

    /** 				RTFatal("first argument of match_from() must be a non-empty sequence")*/
    RefDS(_33958);
    _67RTFatal(_33958);

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67156);
    DeRef(_33940);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    DeRef(_33943);
    _33943 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    _33955 = NOVALUE;
    return;
L2: 

    /** 		if not sequence(s) then*/
    _33960 = IS_SEQUENCE(_s_67156);
    if (_33960 != 0)
    goto L3; // [149] 171
    _33960 = NOVALUE;

    /** 				RTFatal("second argument of match_from() must be a sequence")*/
    RefDS(_33962);
    _67RTFatal(_33962);

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67156);
    DeRef(_33940);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    DeRef(_33943);
    _33943 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    _33955 = NOVALUE;
    return;
L3: 

    /** 		if c < 1 then*/
    if (_67c_63011 >= 1)
    goto L4; // [175] 204

    /** 				RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _33966 = EPrintf(-9999999, _33965, _67c_63011);
    _67RTFatal(_33966);
    _33966 = NOVALUE;

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67156);
    DeRef(_33940);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    DeRef(_33943);
    _33943 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    _33955 = NOVALUE;
    return;
L4: 

    /** 		if not (length(s) = 0 and c = 1) and c > length(s) + 1 then*/
    if (IS_SEQUENCE(_s_67156)){
            _33968 = SEQ_PTR(_s_67156)->length;
    }
    else {
        _33968 = 1;
    }
    _33969 = (_33968 == 0);
    _33968 = NOVALUE;
    if (_33969 == 0) {
        DeRef(_33970);
        _33970 = 0;
        goto L5; // [213] 227
    }
    _33971 = (_67c_63011 == 1);
    _33970 = (_33971 != 0);
L5: 
    _33972 = (_33970 == 0);
    _33970 = NOVALUE;
    if (_33972 == 0) {
        goto L6; // [230] 276
    }
    if (IS_SEQUENCE(_s_67156)){
            _33974 = SEQ_PTR(_s_67156)->length;
    }
    else {
        _33974 = 1;
    }
    _33975 = _33974 + 1;
    _33974 = NOVALUE;
    _33976 = (_67c_63011 > _33975);
    _33975 = NOVALUE;
    if (_33976 == 0)
    {
        DeRef(_33976);
        _33976 = NOVALUE;
        goto L6; // [248] 276
    }
    else{
        DeRef(_33976);
        _33976 = NOVALUE;
    }

    /** 				RTFatal(sprintf("index (%d) out of bounds in match_from()", c ))*/
    _33977 = EPrintf(-9999999, _33965, _67c_63011);
    _67RTFatal(_33977);
    _33977 = NOVALUE;

    /** 				pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** 				return*/
    DeRef(_s_67156);
    DeRef(_33940);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    DeRef(_33943);
    _33943 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33969);
    _33969 = NOVALUE;
    DeRef(_33971);
    _33971 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    return;
L6: 

    /** 		val[target] = match( val[a], s, c )*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33979 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _33980 = e_match_from(_33979, _s_67156, _67c_63011);
    _33979 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33980;
    if( _1 != _33980 ){
        DeRef(_1);
    }
    _33980 = NOVALUE;

    /** 		pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_s_67156);
    DeRef(_33940);
    _33940 = NOVALUE;
    _33941 = NOVALUE;
    DeRef(_33943);
    _33943 = NOVALUE;
    DeRef(_33945);
    _33945 = NOVALUE;
    _33946 = NOVALUE;
    DeRef(_33948);
    _33948 = NOVALUE;
    _33955 = NOVALUE;
    DeRef(_33969);
    _33969 = NOVALUE;
    DeRef(_33971);
    _33971 = NOVALUE;
    DeRef(_33972);
    _33972 = NOVALUE;
    return;
    ;
}


void _67opPEEK2U()
{
    int _33987 = NOVALUE;
    int _33986 = NOVALUE;
    int _33984 = NOVALUE;
    int _33982 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33982 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33982);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33984 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33984);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek2u(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33986 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33986)) {
        _33987 = *(unsigned short *)_33986;
    }
    else if (IS_ATOM(_33986)) {
        _33987 = *(unsigned short *)(unsigned long)(DBL_PTR(_33986)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_33986);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _33987 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _33986 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33987;
    if( _1 != _33987 ){
        DeRef(_1);
    }
    _33987 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33982 = NOVALUE;
    _33984 = NOVALUE;
    return;
    ;
}


void _67opPEEK2S()
{
    int _33994 = NOVALUE;
    int _33993 = NOVALUE;
    int _33991 = NOVALUE;
    int _33989 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33989 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33989);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33991 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33991);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek2s(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _33993 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_33993)) {
        _33994 = *(signed short *)_33993;
    }
    else if (IS_ATOM(_33993)) {
        _33994 = *(signed short *)(unsigned long)(DBL_PTR(_33993)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_33993);
        poke2_addr = (unsigned short *)get_pos_int("peek2s/peek2u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _33994 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(short)*poke2_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _33993 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _33994;
    if( _1 != _33994 ){
        DeRef(_1);
    }
    _33994 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33989 = NOVALUE;
    _33991 = NOVALUE;
    return;
    ;
}


void _67opPEEK4U()
{
    int _34001 = NOVALUE;
    int _34000 = NOVALUE;
    int _33998 = NOVALUE;
    int _33996 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _33996 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _33996);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _33998 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _33998);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek4u(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34000 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34000)) {
        _34001 = *(unsigned long *)_34000;
        if ((unsigned)_34001 > (unsigned)MAXINT)
        _34001 = NewDouble((double)(unsigned long)_34001);
    }
    else if (IS_ATOM(_34000)) {
        _34001 = *(unsigned long *)(unsigned long)(DBL_PTR(_34000)->dbl);
        if ((unsigned)_34001 > (unsigned)MAXINT)
        _34001 = NewDouble((double)(unsigned long)_34001);
    }
    else {
        _1 = (int)SEQ_PTR(_34000);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34001 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34000 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34001;
    if( _1 != _34001 ){
        DeRef(_1);
    }
    _34001 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _33996 = NOVALUE;
    _33998 = NOVALUE;
    return;
    ;
}


void _67opPEEK4S()
{
    int _34008 = NOVALUE;
    int _34007 = NOVALUE;
    int _34005 = NOVALUE;
    int _34003 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34003 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34003);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34005 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34005);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek4s(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34007 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34007)) {
        _34008 = *(unsigned long *)_34007;
        if (_34008 < MININT || _34008 > MAXINT)
        _34008 = NewDouble((double)(long)_34008);
    }
    else if (IS_ATOM(_34007)) {
        _34008 = *(unsigned long *)(unsigned long)(DBL_PTR(_34007)->dbl);
        if (_34008 < MININT || _34008 > MAXINT)
        _34008 = NewDouble((double)(long)_34008);
    }
    else {
        _1 = (int)SEQ_PTR(_34007);
        peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34008 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if (_1 < MININT || _1 > MAXINT)
            _1 = NewDouble((double)(long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34007 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34008;
    if( _1 != _34008 ){
        DeRef(_1);
    }
    _34008 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34003 = NOVALUE;
    _34005 = NOVALUE;
    return;
    ;
}


void _67opPEEK_STRING()
{
    int _34015 = NOVALUE;
    int _34014 = NOVALUE;
    int _34012 = NOVALUE;
    int _34010 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34010 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34010);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34012 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34012);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek_string(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34014 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34014)) {
        _34015 =  NewString((char *)_34014);
    }
    else if (IS_ATOM(_34014)) {
        _34015 = NewString((char *)(unsigned long)(DBL_PTR(_34014)->dbl));
    }
    else {
        _1 = (int)SEQ_PTR(_34014);
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34015 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)*peek4_addr++;
            if ((unsigned)_1 > (unsigned)MAXINT)
            _1 = NewDouble((double)(unsigned long)_1);
            *(int *)poke4_addr = _1;
        }
    }
    _34014 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34015;
    if( _1 != _34015 ){
        DeRef(_1);
    }
    _34015 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34010 = NOVALUE;
    _34012 = NOVALUE;
    return;
    ;
}


void _67opPEEK()
{
    int _34022 = NOVALUE;
    int _34021 = NOVALUE;
    int _34019 = NOVALUE;
    int _34017 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34017 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34017);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34019 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34019);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peek(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34021 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34021)) {
        _34022 = *(unsigned char *)_34021;
    }
    else if (IS_ATOM(_34021)) {
        _34022 = *(unsigned char *)(unsigned long)(DBL_PTR(_34021)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34021);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34022 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34021 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34022;
    if( _1 != _34022 ){
        DeRef(_1);
    }
    _34022 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34017 = NOVALUE;
    _34019 = NOVALUE;
    return;
    ;
}


void _67opPEEKS()
{
    int _34029 = NOVALUE;
    int _34028 = NOVALUE;
    int _34026 = NOVALUE;
    int _34024 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34024 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34024);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34026 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34026);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = peeks(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34028 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34028)) {
        _34029 = *(signed char *)_34028;
    }
    else if (IS_ATOM(_34028)) {
        _34029 = *(signed char *)(unsigned long)(DBL_PTR(_34028)->dbl);
    }
    else {
        _1 = (int)SEQ_PTR(_34028);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _34029 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(signed char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
    }
    _34028 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34029;
    if( _1 != _34029 ){
        DeRef(_1);
    }
    _34029 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34024 = NOVALUE;
    _34026 = NOVALUE;
    return;
    ;
}


void _67opPOKE()
{
    int _34036 = NOVALUE;
    int _34035 = NOVALUE;
    int _34033 = NOVALUE;
    int _34031 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34031 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34031);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34033 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34033);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	poke(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34035 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34036 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_34035)){
        poke_addr = (unsigned char *)_34035;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_34035)->dbl);
    }
    if (IS_ATOM_INT(_34036)) {
        *poke_addr = (unsigned char)_34036;
    }
    else if (IS_ATOM(_34036)) {
        *poke_addr = (signed char)DBL_PTR(_34036)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34036);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34035 = NOVALUE;
    _34036 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34031 = NOVALUE;
    _34033 = NOVALUE;
    return;
    ;
}


void _67opPOKE4()
{
    int _34043 = NOVALUE;
    int _34042 = NOVALUE;
    int _34040 = NOVALUE;
    int _34038 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34038 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34038);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34040 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34040);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	poke4(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34042 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34043 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_34042)){
        poke4_addr = (unsigned long *)_34042;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34042)->dbl);
    }
    if (IS_ATOM_INT(_34043)) {
        *poke4_addr = (unsigned long)_34043;
    }
    else if (IS_ATOM(_34043)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34043)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34043);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34042 = NOVALUE;
    _34043 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34038 = NOVALUE;
    _34040 = NOVALUE;
    return;
    ;
}


void _67opPOKE2()
{
    int _34050 = NOVALUE;
    int _34049 = NOVALUE;
    int _34047 = NOVALUE;
    int _34045 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34045 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34045);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34047 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34047);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	poke2(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34049 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34050 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_ATOM_INT(_34049)){
        poke2_addr = (unsigned short *)_34049;
    }
    else {
        poke2_addr = (unsigned short *)(unsigned long)(DBL_PTR(_34049)->dbl);
    }
    if (IS_ATOM_INT(_34050)) {
        *poke2_addr = (unsigned short)_34050;
    }
    else if (IS_ATOM(_34050)) {
        *poke_addr = (signed char)DBL_PTR(_34050)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34050);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke2_addr++ = (unsigned short)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke2_addr++ = (unsigned short)DBL_PTR(_2)->dbl;
            }
        }
    }
    _34049 = NOVALUE;
    _34050 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34045 = NOVALUE;
    _34047 = NOVALUE;
    return;
    ;
}


void _67opMEM_COPY()
{
    int _34060 = NOVALUE;
    int _34059 = NOVALUE;
    int _34058 = NOVALUE;
    int _34056 = NOVALUE;
    int _34054 = NOVALUE;
    int _34052 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34052 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34052);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34054 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34054);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34056 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34056);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	mem_copy(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34058 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34059 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34060 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    memory_copy(_34058, _34059, _34060);
    _34058 = NOVALUE;
    _34059 = NOVALUE;
    _34060 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34052 = NOVALUE;
    _34054 = NOVALUE;
    _34056 = NOVALUE;
    return;
    ;
}


void _67opMEM_SET()
{
    int _34070 = NOVALUE;
    int _34069 = NOVALUE;
    int _34068 = NOVALUE;
    int _34066 = NOVALUE;
    int _34064 = NOVALUE;
    int _34062 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34062 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34062);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34064 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34064);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34066 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34066);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	mem_set(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34068 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34069 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34070 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    memory_set(_34068, _34069, _34070);
    _34068 = NOVALUE;
    _34069 = NOVALUE;
    _34070 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34062 = NOVALUE;
    _34064 = NOVALUE;
    _34066 = NOVALUE;
    return;
    ;
}


void _67opCALL()
{
    int _34074 = NOVALUE;
    int _34072 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34072 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34072);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	call(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34074 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34074))
    _0 = (int)_34074;
    else
    _0 = (int)(unsigned long)(DBL_PTR(_34074)->dbl);
    (*(void(*)())_0)();
    _34074 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34072 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM()
{
    int _34087 = NOVALUE;
    int _34086 = NOVALUE;
    int _34084 = NOVALUE;
    int _34083 = NOVALUE;
    int _34081 = NOVALUE;
    int _34080 = NOVALUE;
    int _34078 = NOVALUE;
    int _34076 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34076 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34076);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34078 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34078);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34080 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34081 = IS_ATOM(_34080);
    _34080 = NOVALUE;
    if (_34081 == 0)
    {
        _34081 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34081 = NOVALUE;
    }

    /** 		RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34082);
    _67RTFatal(_34082);
L1: 

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34083 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34084 = IS_SEQUENCE(_34083);
    _34083 = NOVALUE;
    if (_34084 == 0)
    {
        _34084 = NOVALUE;
        goto L2; // [68] 77
    }
    else{
        _34084 = NOVALUE;
    }

    /** 		RTFatal("second argument of system() must be an atom")*/
    RefDS(_34085);
    _67RTFatal(_34085);
L2: 

    /** 	system(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34086 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34087 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    system_call(_34086, _34087);
    _34086 = NOVALUE;
    _34087 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_34076);
    _34076 = NOVALUE;
    DeRef(_34078);
    _34078 = NOVALUE;
    return;
    ;
}


void _67opSYSTEM_EXEC()
{
    int _34101 = NOVALUE;
    int _34100 = NOVALUE;
    int _34099 = NOVALUE;
    int _34098 = NOVALUE;
    int _34097 = NOVALUE;
    int _34096 = NOVALUE;
    int _34095 = NOVALUE;
    int _34093 = NOVALUE;
    int _34091 = NOVALUE;
    int _34089 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34089 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34089);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34091 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34091);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34093 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34093);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34095 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34096 = IS_ATOM(_34095);
    _34095 = NOVALUE;
    if (_34096 == 0)
    {
        _34096 = NOVALUE;
        goto L1; // [62] 71
    }
    else{
        _34096 = NOVALUE;
    }

    /** 		RTFatal("first argument of system() must be a sequence")*/
    RefDS(_34082);
    _67RTFatal(_34082);
L1: 

    /** 	if sequence(val[b]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34097 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34098 = IS_SEQUENCE(_34097);
    _34097 = NOVALUE;
    if (_34098 == 0)
    {
        _34098 = NOVALUE;
        goto L2; // [84] 93
    }
    else{
        _34098 = NOVALUE;
    }

    /** 		RTFatal("second argument of system() must be an atom")*/
    RefDS(_34085);
    _67RTFatal(_34085);
L2: 

    /** 	val[target] = system_exec(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34099 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34100 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34101 = system_exec_call(_34099, _34100);
    _34099 = NOVALUE;
    _34100 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34101;
    if( _1 != _34101 ){
        DeRef(_1);
    }
    _34101 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_34089);
    _34089 = NOVALUE;
    DeRef(_34091);
    _34091 = NOVALUE;
    DeRef(_34093);
    _34093 = NOVALUE;
    return;
    ;
}


void _67opOPEN()
{
    int _34128 = NOVALUE;
    int _34127 = NOVALUE;
    int _34126 = NOVALUE;
    int _34125 = NOVALUE;
    int _34122 = NOVALUE;
    int _34121 = NOVALUE;
    int _34119 = NOVALUE;
    int _34118 = NOVALUE;
    int _34116 = NOVALUE;
    int _34115 = NOVALUE;
    int _34114 = NOVALUE;
    int _34112 = NOVALUE;
    int _34111 = NOVALUE;
    int _34109 = NOVALUE;
    int _34107 = NOVALUE;
    int _34105 = NOVALUE;
    int _34103 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34103 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34103);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34105 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34105);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34107 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34107);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34109 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34109);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if atom(val[b]) or length(val[b]) > 2 then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34111 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34112 = IS_ATOM(_34111);
    _34111 = NOVALUE;
    if (_34112 != 0) {
        goto L1; // [78] 102
    }
    _2 = (int)SEQ_PTR(_67val_63018);
    _34114 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    if (IS_SEQUENCE(_34114)){
            _34115 = SEQ_PTR(_34114)->length;
    }
    else {
        _34115 = 1;
    }
    _34114 = NOVALUE;
    _34116 = (_34115 > 2);
    _34115 = NOVALUE;
    if (_34116 == 0)
    {
        DeRef(_34116);
        _34116 = NOVALUE;
        goto L2; // [98] 108
    }
    else{
        DeRef(_34116);
        _34116 = NOVALUE;
    }
L1: 

    /** 	   RTFatal("invalid open mode")*/
    RefDS(_34117);
    _67RTFatal(_34117);
L2: 

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34118 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34119 = IS_ATOM(_34118);
    _34118 = NOVALUE;
    if (_34119 == 0)
    {
        _34119 = NOVALUE;
        goto L3; // [121] 130
    }
    else{
        _34119 = NOVALUE;
    }

    /** 	   RTFatal("device or file name must be a sequence")*/
    RefDS(_34120);
    _67RTFatal(_34120);
L3: 

    /** 	if not atom(val[c]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34121 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    _34122 = IS_ATOM(_34121);
    _34121 = NOVALUE;
    if (_34122 != 0)
    goto L4; // [143] 152
    _34122 = NOVALUE;

    /** 		RTFatal("cleanup must be an atom")*/
    RefDS(_34124);
    _67RTFatal(_34124);
L4: 

    /** 	val[target] = open(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34125 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34126 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34127 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    _34128 = EOpen(_34125, _34126, _34127);
    _34125 = NOVALUE;
    _34126 = NOVALUE;
    _34127 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34128;
    if( _1 != _34128 ){
        DeRef(_1);
    }
    _34128 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_34103);
    _34103 = NOVALUE;
    DeRef(_34105);
    _34105 = NOVALUE;
    DeRef(_34107);
    _34107 = NOVALUE;
    DeRef(_34109);
    _34109 = NOVALUE;
    _34114 = NOVALUE;
    return;
    ;
}


void _67opCLOSE()
{
    int _34132 = NOVALUE;
    int _34130 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34130 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34130);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	close(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34132 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (IS_ATOM_INT(_34132))
    EClose(_34132);
    else
    EClose((int)DBL_PTR(_34132)->dbl);
    _34132 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34130 = NOVALUE;
    return;
    ;
}


void _67opABORT()
{
    int _34136 = NOVALUE;
    int _34135 = NOVALUE;
    int _34134 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Cleanup(val[Code[pc+1]])*/
    _34134 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34135 = (int)*(((s1_ptr)_2)->base + _34134);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34135)){
        _34136 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34135)->dbl));
    }
    else{
        _34136 = (int)*(((s1_ptr)_2)->base + _34135);
    }
    Ref(_34136);
    _43Cleanup(_34136);
    _34136 = NOVALUE;

    /** end procedure*/
    _34134 = NOVALUE;
    _34135 = NOVALUE;
    return;
    ;
}


void _67opGETC()
{
    int _34142 = NOVALUE;
    int _34141 = NOVALUE;
    int _34139 = NOVALUE;
    int _34137 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34137 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34137);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34139 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34139);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = getc(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34141 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (_34141 != last_r_file_no) {
        last_r_file_ptr = which_file(_34141, EF_READ);
        if (IS_ATOM_INT(_34141))
        last_r_file_no = _34141;
        else
        last_r_file_no = NOVALUE;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _34142 = getc((FILE*)xstdin);
        }
        else
        _34142 = getc(last_r_file_ptr);
    }
    else
    _34142 = getc(last_r_file_ptr);
    _34141 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34142;
    if( _1 != _34142 ){
        DeRef(_1);
    }
    _34142 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34137 = NOVALUE;
    _34139 = NOVALUE;
    return;
    ;
}


void _67opGETS()
{
    int _34149 = NOVALUE;
    int _34148 = NOVALUE;
    int _34146 = NOVALUE;
    int _34144 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34144 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34144);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34146 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34146);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = gets(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34148 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34149 = EGets(_34148);
    _34148 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34149;
    if( _1 != _34149 ){
        DeRef(_1);
    }
    _34149 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34144 = NOVALUE;
    _34146 = NOVALUE;
    return;
    ;
}


void _67opGET_KEY()
{
    int _34153 = NOVALUE;
    int _34151 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34151 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34151);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = get_key()*/
    _34153 = get_key(0);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34153;
    if( _1 != _34153 ){
        DeRef(_1);
    }
    _34153 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34151 = NOVALUE;
    return;
    ;
}


void _67opCLEAR_SCREEN()
{
    int _0, _1, _2;
    

    /** 	clear_screen()*/
    ClearScreen();

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** end procedure*/
    return;
    ;
}


void _67opPUTS()
{
    int _34161 = NOVALUE;
    int _34160 = NOVALUE;
    int _34158 = NOVALUE;
    int _34156 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34156 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34156);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34158 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34158);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	puts(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34160 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34161 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    EPuts(_34160, _34161); // DJP 
    _34160 = NOVALUE;
    _34161 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34156 = NOVALUE;
    _34158 = NOVALUE;
    return;
    ;
}


void _67opQPRINT()
{
    int _34165 = NOVALUE;
    int _34163 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+2]*/
    _34163 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34163);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	? val[a]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34165 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    StdPrint(1, _34165, 1);
    _34165 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34163 = NOVALUE;
    return;
    ;
}


void _67opPRINT()
{
    int _34172 = NOVALUE;
    int _34171 = NOVALUE;
    int _34169 = NOVALUE;
    int _34167 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34167 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34167);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34169 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34169);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	print(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34171 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34172 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    StdPrint(_34171, _34172, 0);
    _34171 = NOVALUE;
    _34172 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    _34167 = NOVALUE;
    _34169 = NOVALUE;
    return;
    ;
}


void _67opPRINTF()
{
    int _34182 = NOVALUE;
    int _34181 = NOVALUE;
    int _34180 = NOVALUE;
    int _34178 = NOVALUE;
    int _34176 = NOVALUE;
    int _34174 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34174 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34174);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34176 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34176);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34178 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34178);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	printf(val[a], val[b], val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34180 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34181 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34182 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    EPrintf(_34180, _34181, _34182);
    _34180 = NOVALUE;
    _34181 = NOVALUE;
    _34182 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34174 = NOVALUE;
    _34176 = NOVALUE;
    _34178 = NOVALUE;
    return;
    ;
}


void _67opSPRINTF()
{
    int _34192 = NOVALUE;
    int _34191 = NOVALUE;
    int _34190 = NOVALUE;
    int _34188 = NOVALUE;
    int _34186 = NOVALUE;
    int _34184 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34184 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34184);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34186 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34186);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34188 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34188);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = sprintf(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34190 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34191 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34192 = EPrintf(-9999999, _34190, _34191);
    _34190 = NOVALUE;
    _34191 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34192;
    if( _1 != _34192 ){
        DeRef(_1);
    }
    _34192 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34184 = NOVALUE;
    _34186 = NOVALUE;
    _34188 = NOVALUE;
    return;
    ;
}


void _67opCOMMAND_LINE()
{
    int _cmd_67538 = NOVALUE;
    int _34202 = NOVALUE;
    int _34201 = NOVALUE;
    int _34200 = NOVALUE;
    int _34199 = NOVALUE;
    int _34197 = NOVALUE;
    int _34194 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34194 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34194);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	cmd = command_line()*/
    DeRef(_cmd_67538);
    _cmd_67538 = Command_Line();

    /** 	if length(cmd) > 2 then*/
    if (IS_SEQUENCE(_cmd_67538)){
            _34197 = SEQ_PTR(_cmd_67538)->length;
    }
    else {
        _34197 = 1;
    }
    if (_34197 <= 2)
    goto L1; // [26] 53

    /** 		cmd = {cmd[1]} & cmd[3..$]*/
    _2 = (int)SEQ_PTR(_cmd_67538);
    _34199 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_34199);
    *((int *)(_2+4)) = _34199;
    _34200 = MAKE_SEQ(_1);
    _34199 = NOVALUE;
    if (IS_SEQUENCE(_cmd_67538)){
            _34201 = SEQ_PTR(_cmd_67538)->length;
    }
    else {
        _34201 = 1;
    }
    rhs_slice_target = (object_ptr)&_34202;
    RHS_Slice(_cmd_67538, 3, _34201);
    Concat((object_ptr)&_cmd_67538, _34200, _34202);
    DeRefDS(_34200);
    _34200 = NOVALUE;
    DeRef(_34200);
    _34200 = NOVALUE;
    DeRefDS(_34202);
    _34202 = NOVALUE;
L1: 

    /** 	val[target] = cmd*/
    RefDS(_cmd_67538);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _cmd_67538;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRefDS(_cmd_67538);
    DeRef(_34194);
    _34194 = NOVALUE;
    return;
    ;
}


void _67opOPTION_SWITCHES()
{
    int _cmd_67554 = NOVALUE;
    int _34205 = NOVALUE;
    int _0, _1, _2;
    

    /** 	target = Code[pc+1]*/
    _34205 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34205);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	cmd = option_switches()*/
    DeRef(_cmd_67554);
    RefDS(_0switches);
    _cmd_67554 = _0switches;

    /** 	val[target] = cmd*/
    RefDS(_cmd_67554);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _cmd_67554;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    DeRefDS(_cmd_67554);
    _34205 = NOVALUE;
    return;
    ;
}


void _67opGETENV()
{
    int _34217 = NOVALUE;
    int _34216 = NOVALUE;
    int _34214 = NOVALUE;
    int _34213 = NOVALUE;
    int _34211 = NOVALUE;
    int _34209 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34209 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34209);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	target = Code[pc+2]*/
    _34211 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34211);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	if atom(val[a]) then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34213 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34214 = IS_ATOM(_34213);
    _34213 = NOVALUE;
    if (_34214 == 0)
    {
        _34214 = NOVALUE;
        goto L1; // [46] 55
    }
    else{
        _34214 = NOVALUE;
    }

    /** 		RTFatal("argument to getenv must be a sequence")*/
    RefDS(_34215);
    _67RTFatal(_34215);
L1: 

    /** 	val[target] = getenv(val[a])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34216 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _34217 = EGetEnv(_34216);
    _34216 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34217;
    if( _1 != _34217 ){
        DeRef(_1);
    }
    _34217 = NOVALUE;

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_34209);
    _34209 = NOVALUE;
    DeRef(_34211);
    _34211 = NOVALUE;
    return;
    ;
}


void _67opC_PROC()
{
    int _sub_67578 = NOVALUE;
    int _34226 = NOVALUE;
    int _34225 = NOVALUE;
    int _34223 = NOVALUE;
    int _34221 = NOVALUE;
    int _34219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34219 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34219);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34221 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34221);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	sub = Code[pc+3]*/
    _34223 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_67578 = (int)*(((s1_ptr)_2)->base + _34223);
    if (!IS_ATOM_INT(_sub_67578)){
        _sub_67578 = (long)DBL_PTR(_sub_67578)->dbl;
    }

    /** 	c_proc(val[a], val[b])  -- callback could happen here*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34225 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34226 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    call_c(0, _34225, _34226);
    _34225 = NOVALUE;
    _34226 = NOVALUE;

    /** 	restore_privates(sub)*/
    _67restore_privates(_sub_67578);

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34219 = NOVALUE;
    _34221 = NOVALUE;
    _34223 = NOVALUE;
    return;
    ;
}


void _67opC_FUNC()
{
    int _target_67593 = NOVALUE;
    int _sub_67595 = NOVALUE;
    int _temp_67596 = NOVALUE;
    int _34237 = NOVALUE;
    int _34236 = NOVALUE;
    int _34234 = NOVALUE;
    int _34232 = NOVALUE;
    int _34230 = NOVALUE;
    int _34228 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object temp*/

    /** 	a = Code[pc+1]*/
    _34228 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34228);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34230 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34230);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	sub = Code[pc+3]*/
    _34232 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _sub_67595 = (int)*(((s1_ptr)_2)->base + _34232);
    if (!IS_ATOM_INT(_sub_67595)){
        _sub_67595 = (long)DBL_PTR(_sub_67595)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34234 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _target_67593 = (int)*(((s1_ptr)_2)->base + _34234);
    if (!IS_ATOM_INT(_target_67593)){
        _target_67593 = (long)DBL_PTR(_target_67593)->dbl;
    }

    /** 	temp = c_func(val[a], val[b])  -- callback could happen here*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34236 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34237 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    DeRef(_temp_67596);
    _temp_67596 = call_c(1, _34236, _34237);
    _34236 = NOVALUE;
    _34237 = NOVALUE;

    /** 	restore_privates(sub)*/
    _67restore_privates(_sub_67595);

    /** 	val[target] = temp*/
    Ref(_temp_67596);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _target_67593);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_67596;
    DeRef(_1);

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    DeRef(_temp_67596);
    _34228 = NOVALUE;
    _34230 = NOVALUE;
    _34232 = NOVALUE;
    _34234 = NOVALUE;
    return;
    ;
}


void _67opTRACE()
{
    int _34241 = NOVALUE;
    int _34240 = NOVALUE;
    int _0, _1, _2;
    

    /** 	TraceOn = val[Code[pc+1]]*/
    _34240 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34241 = (int)*(((s1_ptr)_2)->base + _34240);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34241)){
        _67TraceOn_63006 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34241)->dbl));
    }
    else{
        _67TraceOn_63006 = (int)*(((s1_ptr)_2)->base + _34241);
    }
    if (!IS_ATOM_INT(_67TraceOn_63006))
    _67TraceOn_63006 = (long)DBL_PTR(_67TraceOn_63006)->dbl;

    /** 	pc += 2  -- turn on/off tracing*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34240 = NOVALUE;
    _34241 = NOVALUE;
    return;
    ;
}


void _67opPROFILE()
{
    int _0, _1, _2;
    

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    return;
    ;
}


void _67opUPDATE_GLOBALS()
{
    int _0, _1, _2;
    

    /** 	pc += 1*/
    _67pc_63008 = _67pc_63008 + 1;

    /** end procedure*/
    return;
    ;
}


int _67general_callback(int _rtn_def_67628, int _args_67629)
{
    int _arglist_assign_67631 = NOVALUE;
    int _34263 = NOVALUE;
    int _34261 = NOVALUE;
    int _34260 = NOVALUE;
    int _34259 = NOVALUE;
    int _34256 = NOVALUE;
    int _34255 = NOVALUE;
    int _34253 = NOVALUE;
    int _34252 = NOVALUE;
    int _34248 = NOVALUE;
    int _34246 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val[t_id] = rtn_def[C_USER_ROUTINE]*/
    _2 = (int)SEQ_PTR(_rtn_def_67628);
    _34246 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_34246);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_62939);
    _1 = *(int *)_2;
    *(int *)_2 = _34246;
    if( _1 != _34246 ){
        DeRef(_1);
    }
    _34246 = NOVALUE;

    /** 	val[t_arglist] = args*/
    RefDS(_args_67629);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_62940);
    _1 = *(int *)_2;
    *(int *)_2 = _args_67629;
    DeRef(_1);

    /** 	atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_67631;
    _arglist_assign_67631 = _67new_arg_assign();
    DeRef(_0);

    /** 	SymTab[call_back_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67call_back_routine_62942 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63025;
    DeRef(_1);
    _34248 = NOVALUE;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67pc_63008);

    /** 	call_stack = append(call_stack, call_back_routine)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67call_back_routine_62942);

    /** 	Code = call_back_code*/
    RefDS(_67call_back_code_62936);
    DeRef(_12Code_11771);
    _12Code_11771 = _67call_back_code_62936;

    /** 	pc = 1*/
    _67pc_63008 = 1;

    /** 	do_exec()*/
    _67do_exec();

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34252 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34252 = 1;
    }
    _34253 = _34252 - 1;
    _34252 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _34253);
    if (!IS_ATOM_INT(_67pc_63008))
    _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34255 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34255 = 1;
    }
    _34256 = _34255 - 2;
    _34255 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63026;
    RHS_Slice(_67call_stack_63026, 1, _34256);

    /** 	if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_67631, _67arg_assign_62952)){
        goto L1; // [126] 143
    }

    /** 		val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_62940);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1: 

    /** 	Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34259 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34259 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _34260 = (int)*(((s1_ptr)_2)->base + _34259);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_34260)){
        _34261 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34260)->dbl));
    }
    else{
        _34261 = (int)*(((s1_ptr)_2)->base + _34260);
    }
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_34261);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _34261 = NOVALUE;

    /** 	return val[t_return_val]*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34263 = (int)*(((s1_ptr)_2)->base + _67t_return_val_62941);
    Ref(_34263);
    DeRefDS(_rtn_def_67628);
    DeRefDS(_args_67629);
    DeRef(_arglist_assign_67631);
    DeRef(_34253);
    _34253 = NOVALUE;
    DeRef(_34256);
    _34256 = NOVALUE;
    _34260 = NOVALUE;
    return _34263;
    ;
}


int _67machine_callback(int _cbx_67662, int _ptr_67663)
{
    int _rtn_def_67664 = NOVALUE;
    int _args_67665 = NOVALUE;
    int _34271 = NOVALUE;
    int _34269 = NOVALUE;
    int _34268 = NOVALUE;
    int _34267 = NOVALUE;
    int _0, _1, _2;
    

    /** 	rtn_def = call_backs[cbx]*/
    DeRef(_rtn_def_67664);
    _2 = (int)SEQ_PTR(_67call_backs_62935);
    if (!IS_ATOM_INT(_cbx_67662)){
        _rtn_def_67664 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_cbx_67662)->dbl));
    }
    else{
        _rtn_def_67664 = (int)*(((s1_ptr)_2)->base + _cbx_67662);
    }
    RefDS(_rtn_def_67664);

    /** 	args = peek4u(ptr & call_backs[cbx][C_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_67call_backs_62935);
    if (!IS_ATOM_INT(_cbx_67662)){
        _34267 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_cbx_67662)->dbl));
    }
    else{
        _34267 = (int)*(((s1_ptr)_2)->base + _cbx_67662);
    }
    _2 = (int)SEQ_PTR(_34267);
    _34268 = (int)*(((s1_ptr)_2)->base + 3);
    _34267 = NOVALUE;
    if (IS_SEQUENCE(_ptr_67663) && IS_ATOM(_34268)) {
    }
    else if (IS_ATOM(_ptr_67663) && IS_SEQUENCE(_34268)) {
        Ref(_ptr_67663);
        Prepend(&_34269, _34268, _ptr_67663);
    }
    else {
        Concat((object_ptr)&_34269, _ptr_67663, _34268);
    }
    _34268 = NOVALUE;
    DeRef(_args_67665);
    _1 = (int)SEQ_PTR(_34269);
    peek4_addr = (unsigned long *)get_pos_int("peek4s/peek4u", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _args_67665 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)*peek4_addr++;
        if ((unsigned)_1 > (unsigned)MAXINT)
        _1 = NewDouble((double)(unsigned long)_1);
        *(int *)poke4_addr = _1;
    }
    DeRefDS(_34269);
    _34269 = NOVALUE;

    /** 	return general_callback(rtn_def, args)*/
    RefDS(_rtn_def_67664);
    RefDS(_args_67665);
    _34271 = _67general_callback(_rtn_def_67664, _args_67665);
    DeRef(_cbx_67662);
    DeRef(_ptr_67663);
    DeRefDS(_rtn_def_67664);
    DeRefDS(_args_67665);
    return _34271;
    ;
}


int _67callback(int _a_67680)
{
    int _34275 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return machine_func(M_CALL_BACK, a)*/
    _34275 = machine(52, _a_67680);
    DeRefi(_a_67680);
    return _34275;
    ;
}


void _67do_callback(int _b_67684)
{
    int _r_67686 = NOVALUE;
    int _asm_67687 = NOVALUE;
    int _id_67688 = NOVALUE;
    int _convention_67689 = NOVALUE;
    int _x_67690 = NOVALUE;
    int _34336 = NOVALUE;
    int _34335 = NOVALUE;
    int _34334 = NOVALUE;
    int _34333 = NOVALUE;
    int _34332 = NOVALUE;
    int _34331 = NOVALUE;
    int _34330 = NOVALUE;
    int _34329 = NOVALUE;
    int _34328 = NOVALUE;
    int _34327 = NOVALUE;
    int _34326 = NOVALUE;
    int _34325 = NOVALUE;
    int _34323 = NOVALUE;
    int _34304 = NOVALUE;
    int _34303 = NOVALUE;
    int _34301 = NOVALUE;
    int _34300 = NOVALUE;
    int _34299 = NOVALUE;
    int _34298 = NOVALUE;
    int _34297 = NOVALUE;
    int _34296 = NOVALUE;
    int _34295 = NOVALUE;
    int _34294 = NOVALUE;
    int _34293 = NOVALUE;
    int _34292 = NOVALUE;
    int _34290 = NOVALUE;
    int _34289 = NOVALUE;
    int _34288 = NOVALUE;
    int _34287 = NOVALUE;
    int _34285 = NOVALUE;
    int _34283 = NOVALUE;
    int _34282 = NOVALUE;
    int _34280 = NOVALUE;
    int _34277 = NOVALUE;
    int _0, _1, _2;
    

    /** 	atom asm*/

    /** 	integer id, convention*/

    /** 	object x*/

    /** 	x = val[b]*/
    DeRef(_x_67690);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_67690 = (int)*(((s1_ptr)_2)->base + _b_67684);
    Ref(_x_67690);

    /** 	if atom(x) then*/
    _34277 = IS_ATOM(_x_67690);
    if (_34277 == 0)
    {
        _34277 = NOVALUE;
        goto L1; // [22] 40
    }
    else{
        _34277 = NOVALUE;
    }

    /** 		id = x*/
    Ref(_x_67690);
    _id_67688 = _x_67690;
    if (!IS_ATOM_INT(_id_67688)) {
        _1 = (long)(DBL_PTR(_id_67688)->dbl);
        DeRefDS(_id_67688);
        _id_67688 = _1;
    }

    /** 		convention = 0*/
    _convention_67689 = 0;
    goto L2; // [37] 57
L1: 

    /** 		id = x[2]*/
    _2 = (int)SEQ_PTR(_x_67690);
    _id_67688 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_id_67688)){
        _id_67688 = (long)DBL_PTR(_id_67688)->dbl;
    }

    /** 		convention = x[1]*/
    _2 = (int)SEQ_PTR(_x_67690);
    _convention_67689 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_convention_67689)){
        _convention_67689 = (long)DBL_PTR(_convention_67689)->dbl;
    }
L2: 

    /** 	if id < 0 or id >= length(e_routine) then*/
    _34280 = (_id_67688 < 0);
    if (_34280 != 0) {
        goto L3; // [65] 83
    }
    if (IS_SEQUENCE(_67e_routine_63056)){
            _34282 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _34282 = 1;
    }
    _34283 = (_id_67688 >= _34282);
    _34282 = NOVALUE;
    if (_34283 == 0)
    {
        DeRef(_34283);
        _34283 = NOVALUE;
        goto L4; // [79] 89
    }
    else{
        DeRef(_34283);
        _34283 = NOVALUE;
    }
L3: 

    /** 		RTFatal("Invalid routine id")*/
    RefDS(_34284);
    _67RTFatal(_34284);
L4: 

    /** 	r = e_routine[id+1]*/
    _34285 = _id_67688 + 1;
    _2 = (int)SEQ_PTR(_67e_routine_63056);
    _r_67686 = (int)*(((s1_ptr)_2)->base + _34285);

    /** 	if platform() = WIN32 and convention = 0 then*/
    _34287 = (3 == 2);
    if (_34287 == 0) {
        goto L5; // [111] 224
    }
    _34289 = (_convention_67689 == 0);
    if (_34289 == 0)
    {
        DeRef(_34289);
        _34289 = NOVALUE;
        goto L5; // [122] 224
    }
    else{
        DeRef(_34289);
        _34289 = NOVALUE;
    }

    /** 		asm = dep:allocate_protect(length(cb_std), 1, PAGE_EXECUTE_READWRITE)*/
    _34290 = 24;
    Ref(_5PAGE_EXECUTE_READWRITE_240);
    _0 = _asm_67687;
    _asm_67687 = _4allocate_protect(24, 1, _5PAGE_EXECUTE_READWRITE_240);
    DeRef(_0);
    _34290 = NOVALUE;

    /** 		poke( asm, cb_std )*/
    if (IS_ATOM_INT(_asm_67687)){
        poke_addr = (unsigned char *)_asm_67687;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_asm_67687)->dbl);
    }
    _1 = (int)SEQ_PTR(_67cb_std_67672);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34292 = _asm_67687 + 7;
        if ((long)((unsigned long)_34292 + (unsigned long)HIGH_BITS) >= 0) 
        _34292 = NewDouble((double)_34292);
    }
    else {
        _34292 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)7);
    }
    if (IS_SEQUENCE(_67call_backs_62935)){
            _34293 = SEQ_PTR(_67call_backs_62935)->length;
    }
    else {
        _34293 = 1;
    }
    _34294 = _34293 + 1;
    _34293 = NOVALUE;
    if (IS_ATOM_INT(_34292)){
        poke4_addr = (unsigned long *)_34292;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34292)->dbl);
    }
    *poke4_addr = (unsigned long)_34294;
    DeRef(_34292);
    _34292 = NOVALUE;
    _34294 = NOVALUE;

    /** 		poke4( asm + 13, asm + 20 )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34295 = _asm_67687 + 13;
        if ((long)((unsigned long)_34295 + (unsigned long)HIGH_BITS) >= 0) 
        _34295 = NewDouble((double)_34295);
    }
    else {
        _34295 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)13);
    }
    if (IS_ATOM_INT(_asm_67687)) {
        _34296 = _asm_67687 + 20;
        if ((long)((unsigned long)_34296 + (unsigned long)HIGH_BITS) >= 0) 
        _34296 = NewDouble((double)_34296);
    }
    else {
        _34296 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)20);
    }
    if (IS_ATOM_INT(_34295)){
        poke4_addr = (unsigned long *)_34295;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34295)->dbl);
    }
    if (IS_ATOM_INT(_34296)) {
        *poke4_addr = (unsigned long)_34296;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_34296)->dbl;
    }
    DeRef(_34295);
    _34295 = NOVALUE;
    DeRef(_34296);
    _34296 = NOVALUE;

    /** 		poke( asm + 18, SymTab[r][S_NUM_ARGS] * 4 )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34297 = _asm_67687 + 18;
        if ((long)((unsigned long)_34297 + (unsigned long)HIGH_BITS) >= 0) 
        _34297 = NewDouble((double)_34297);
    }
    else {
        _34297 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)18);
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _34298 = (int)*(((s1_ptr)_2)->base + _r_67686);
    _2 = (int)SEQ_PTR(_34298);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _34299 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _34299 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _34298 = NOVALUE;
    if (IS_ATOM_INT(_34299)) {
        if (_34299 == (short)_34299)
        _34300 = _34299 * 4;
        else
        _34300 = NewDouble(_34299 * (double)4);
    }
    else {
        _34300 = binary_op(MULTIPLY, _34299, 4);
    }
    _34299 = NOVALUE;
    if (IS_ATOM_INT(_34297)){
        poke_addr = (unsigned char *)_34297;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_34297)->dbl);
    }
    if (IS_ATOM_INT(_34300)) {
        *poke_addr = (unsigned char)_34300;
    }
    else if (IS_ATOM(_34300)) {
        *poke_addr = (signed char)DBL_PTR(_34300)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34300);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *poke_addr++ = (unsigned char)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34297);
    _34297 = NOVALUE;
    DeRef(_34300);
    _34300 = NOVALUE;

    /** 		poke4( asm + 20, callback( routine_id("machine_callback") ) )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34301 = _asm_67687 + 20;
        if ((long)((unsigned long)_34301 + (unsigned long)HIGH_BITS) >= 0) 
        _34301 = NewDouble((double)_34301);
    }
    else {
        _34301 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)20);
    }
    _34303 = CRoutineId(1541, 67, _34302);
    _34304 = _67callback(_34303);
    _34303 = NOVALUE;
    if (IS_ATOM_INT(_34301)){
        poke4_addr = (unsigned long *)_34301;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34301)->dbl);
    }
    if (IS_ATOM_INT(_34304)) {
        *poke4_addr = (unsigned long)_34304;
    }
    else if (IS_ATOM(_34304)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34304)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34304);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34301);
    _34301 = NOVALUE;
    DeRef(_34304);
    _34304 = NOVALUE;
    goto L6; // [221] 409
L5: 

    /** 	elsif platform() = OSX then*/

    /** 		asm = dep:allocate_protect(length(cb_cdecl), 1, PAGE_EXECUTE_READWRITE)*/
    _34323 = 27;
    Ref(_5PAGE_EXECUTE_READWRITE_240);
    _0 = _asm_67687;
    _asm_67687 = _4allocate_protect(27, 1, _5PAGE_EXECUTE_READWRITE_240);
    DeRef(_0);
    _34323 = NOVALUE;

    /** 		poke( asm, cb_cdecl )*/
    if (IS_ATOM_INT(_asm_67687)){
        poke_addr = (unsigned char *)_asm_67687;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_asm_67687)->dbl);
    }
    _1 = (int)SEQ_PTR(_67cb_cdecl_67674);
    _1 = (int)((s1_ptr)_1)->base;
    while (1) {
        _1 += 4;
        _2 = *((int *)_1);
        if (IS_ATOM_INT(_2))
        *poke_addr++ = (unsigned char)_2;
        else if (_2 == NOVALUE)
        break;
        else {
            *poke_addr++ = (signed char)DBL_PTR(_2)->dbl;
        }
    }

    /** 		poke4( asm + 7, length(call_backs) + 1 )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34325 = _asm_67687 + 7;
        if ((long)((unsigned long)_34325 + (unsigned long)HIGH_BITS) >= 0) 
        _34325 = NewDouble((double)_34325);
    }
    else {
        _34325 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)7);
    }
    if (IS_SEQUENCE(_67call_backs_62935)){
            _34326 = SEQ_PTR(_67call_backs_62935)->length;
    }
    else {
        _34326 = 1;
    }
    _34327 = _34326 + 1;
    _34326 = NOVALUE;
    if (IS_ATOM_INT(_34325)){
        poke4_addr = (unsigned long *)_34325;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34325)->dbl);
    }
    *poke4_addr = (unsigned long)_34327;
    DeRef(_34325);
    _34325 = NOVALUE;
    _34327 = NOVALUE;

    /** 		poke4( asm + 13, asm + 23 )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34328 = _asm_67687 + 13;
        if ((long)((unsigned long)_34328 + (unsigned long)HIGH_BITS) >= 0) 
        _34328 = NewDouble((double)_34328);
    }
    else {
        _34328 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)13);
    }
    if (IS_ATOM_INT(_asm_67687)) {
        _34329 = _asm_67687 + 23;
        if ((long)((unsigned long)_34329 + (unsigned long)HIGH_BITS) >= 0) 
        _34329 = NewDouble((double)_34329);
    }
    else {
        _34329 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)23);
    }
    if (IS_ATOM_INT(_34328)){
        poke4_addr = (unsigned long *)_34328;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34328)->dbl);
    }
    if (IS_ATOM_INT(_34329)) {
        *poke4_addr = (unsigned long)_34329;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_34329)->dbl;
    }
    DeRef(_34328);
    _34328 = NOVALUE;
    DeRef(_34329);
    _34329 = NOVALUE;

    /** 		poke4( asm + 23, callback( ( '+' & routine_id("machine_callback") ) ) )*/
    if (IS_ATOM_INT(_asm_67687)) {
        _34330 = _asm_67687 + 23;
        if ((long)((unsigned long)_34330 + (unsigned long)HIGH_BITS) >= 0) 
        _34330 = NewDouble((double)_34330);
    }
    else {
        _34330 = NewDouble(DBL_PTR(_asm_67687)->dbl + (double)23);
    }
    _34331 = CRoutineId(1541, 67, _34302);
    Concat((object_ptr)&_34332, 43, _34331);
    _34331 = NOVALUE;
    _34333 = _67callback(_34332);
    _34332 = NOVALUE;
    if (IS_ATOM_INT(_34330)){
        poke4_addr = (unsigned long *)_34330;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_34330)->dbl);
    }
    if (IS_ATOM_INT(_34333)) {
        *poke4_addr = (unsigned long)_34333;
    }
    else if (IS_ATOM(_34333)) {
        *poke4_addr = (unsigned long)DBL_PTR(_34333)->dbl;
    }
    else {
        _1 = (int)SEQ_PTR(_34333);
        _1 = (int)((s1_ptr)_1)->base;
        while (1) {
            _1 += 4;
            _2 = *((int *)_1);
            if (IS_ATOM_INT(_2))
            *(int *)poke4_addr++ = (unsigned long)_2;
            else if (_2 == NOVALUE)
            break;
            else {
                *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
            }
        }
    }
    DeRef(_34330);
    _34330 = NOVALUE;
    DeRef(_34333);
    _34333 = NOVALUE;
L6: 

    /** 	val[target] = asm*/
    Ref(_asm_67687);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _asm_67687;
    DeRef(_1);

    /** 	call_backs = append( call_backs, { r, id, SymTab[r][S_NUM_ARGS] })*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _34334 = (int)*(((s1_ptr)_2)->base + _r_67686);
    _2 = (int)SEQ_PTR(_34334);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _34335 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _34335 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _34334 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _r_67686;
    *((int *)(_2+8)) = _id_67688;
    Ref(_34335);
    *((int *)(_2+12)) = _34335;
    _34336 = MAKE_SEQ(_1);
    _34335 = NOVALUE;
    RefDS(_34336);
    Append(&_67call_backs_62935, _67call_backs_62935, _34336);
    DeRefDS(_34336);
    _34336 = NOVALUE;

    /** end procedure*/
    DeRef(_asm_67687);
    DeRef(_x_67690);
    DeRef(_34280);
    _34280 = NOVALUE;
    DeRef(_34285);
    _34285 = NOVALUE;
    DeRef(_34287);
    _34287 = NOVALUE;
    return;
    ;
}


void _67do_crash_routine(int _b_67772)
{
    int _x_67773 = NOVALUE;
    int _34344 = NOVALUE;
    int _34343 = NOVALUE;
    int _34342 = NOVALUE;
    int _34341 = NOVALUE;
    int _34340 = NOVALUE;
    int _34339 = NOVALUE;
    int _0, _1, _2;
    

    /** 	x = val[b]*/
    DeRef(_x_67773);
    _2 = (int)SEQ_PTR(_67val_63018);
    _x_67773 = (int)*(((s1_ptr)_2)->base + _b_67772);
    Ref(_x_67773);

    /** 	if atom(x) and x >= 0 and x < length(e_routine) then*/
    _34339 = IS_ATOM(_x_67773);
    if (_34339 == 0) {
        _34340 = 0;
        goto L1; // [16] 28
    }
    if (IS_ATOM_INT(_x_67773)) {
        _34341 = (_x_67773 >= 0);
    }
    else {
        _34341 = binary_op(GREATEREQ, _x_67773, 0);
    }
    if (IS_ATOM_INT(_34341))
    _34340 = (_34341 != 0);
    else
    _34340 = DBL_PTR(_34341)->dbl != 0.0;
L1: 
    if (_34340 == 0) {
        goto L2; // [28] 56
    }
    if (IS_SEQUENCE(_67e_routine_63056)){
            _34343 = SEQ_PTR(_67e_routine_63056)->length;
    }
    else {
        _34343 = 1;
    }
    if (IS_ATOM_INT(_x_67773)) {
        _34344 = (_x_67773 < _34343);
    }
    else {
        _34344 = binary_op(LESS, _x_67773, _34343);
    }
    _34343 = NOVALUE;
    if (_34344 == 0) {
        DeRef(_34344);
        _34344 = NOVALUE;
        goto L2; // [42] 56
    }
    else {
        if (!IS_ATOM_INT(_34344) && DBL_PTR(_34344)->dbl == 0.0){
            DeRef(_34344);
            _34344 = NOVALUE;
            goto L2; // [42] 56
        }
        DeRef(_34344);
        _34344 = NOVALUE;
    }
    DeRef(_34344);
    _34344 = NOVALUE;

    /** 		crash_list = append(crash_list, x)*/
    Ref(_x_67773);
    Append(&_67crash_list_62944, _67crash_list_62944, _x_67773);
    goto L3; // [53] 62
L2: 

    /** 		RTFatal("crash routine requires a valid routine id")*/
    RefDS(_34346);
    _67RTFatal(_34346);
L3: 

    /** end procedure*/
    DeRef(_x_67773);
    DeRef(_34341);
    _34341 = NOVALUE;
    return;
    ;
}


void _67opREMOVE()
{
    int _34358 = NOVALUE;
    int _34357 = NOVALUE;
    int _34356 = NOVALUE;
    int _34355 = NOVALUE;
    int _34353 = NOVALUE;
    int _34351 = NOVALUE;
    int _34349 = NOVALUE;
    int _34347 = NOVALUE;
    int _0, _1, _2;
    

    /**  	a = Code[pc+1]*/
    _34347 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34347);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /**  	b = Code[pc+2]*/
    _34349 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34349);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /**  	c = Code[pc+3]*/
    _34351 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34351);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /**  	target = Code[pc+4]*/
    _34353 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34353);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /**  	val[target] = remove(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34355 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34356 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34357 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    {
        s1_ptr assign_space = SEQ_PTR(_34355);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_34356)) ? _34356 : (long)(DBL_PTR(_34356)->dbl);
        int stop = (IS_ATOM_INT(_34357)) ? _34357 : (long)(DBL_PTR(_34357)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
            RefDS(_34355);
            DeRef(_34358);
            _34358 = _34355;
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_34355), start, &_34358 );
            }
            else Tail(SEQ_PTR(_34355), stop+1, &_34358);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_34355), start, &_34358);
        }
        else {
            assign_slice_seq = &assign_space;
            _1 = Remove_elements(start, stop, 0);
            DeRef(_34358);
            _34358 = _1;
        }
    }
    _34355 = NOVALUE;
    _34356 = NOVALUE;
    _34357 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34358;
    if( _1 != _34358 ){
        DeRef(_1);
    }
    _34358 = NOVALUE;

    /**  	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _34347 = NOVALUE;
    _34349 = NOVALUE;
    _34351 = NOVALUE;
    _34353 = NOVALUE;
    return;
    ;
}


void _67opREPLACE()
{
    int _34374 = NOVALUE;
    int _34373 = NOVALUE;
    int _34372 = NOVALUE;
    int _34371 = NOVALUE;
    int _34370 = NOVALUE;
    int _34368 = NOVALUE;
    int _34366 = NOVALUE;
    int _34364 = NOVALUE;
    int _34362 = NOVALUE;
    int _34360 = NOVALUE;
    int _0, _1, _2;
    

    /**  	a = Code[pc+1]*/
    _34360 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34360);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /**  	b = Code[pc+2]*/
    _34362 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34362);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /**  	c = Code[pc+3]*/
    _34364 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34364);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /**  	d = Code[pc+4]*/
    _34366 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67d_63012 = (int)*(((s1_ptr)_2)->base + _34366);
    if (!IS_ATOM_INT(_67d_63012)){
        _67d_63012 = (long)DBL_PTR(_67d_63012)->dbl;
    }

    /**  	target = Code[pc+5]*/
    _34368 = _67pc_63008 + 5;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34368);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /**  	val[target] = replace(val[a],val[b],val[c],val[d])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34370 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34371 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34372 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34373 = (int)*(((s1_ptr)_2)->base + _67d_63012);
    {
        int p1 = _34370;
        int p2 = _34371;
        int p3 = _34372;
        int p4 = _34373;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_34374;
        Replace( &replace_params );
    }
    _34370 = NOVALUE;
    _34371 = NOVALUE;
    _34372 = NOVALUE;
    _34373 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34374;
    if( _1 != _34374 ){
        DeRef(_1);
    }
    _34374 = NOVALUE;

    /**  	pc += 6*/
    _67pc_63008 = _67pc_63008 + 6;

    /** end procedure*/
    _34360 = NOVALUE;
    _34362 = NOVALUE;
    _34364 = NOVALUE;
    _34366 = NOVALUE;
    _34368 = NOVALUE;
    return;
    ;
}


void _67opHEAD()
{
    int _34384 = NOVALUE;
    int _34383 = NOVALUE;
    int _34382 = NOVALUE;
    int _34380 = NOVALUE;
    int _34378 = NOVALUE;
    int _34376 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34376 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34376);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34378 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34378);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34380 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34380);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = head(val[a],val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34382 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34383 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    {
        int len = SEQ_PTR(_34382)->length;
        int size = (IS_ATOM_INT(_34383)) ? _34383 : (object)(DBL_PTR(_34383)->dbl);
        if (size <= 0){
            DeRef( _34384 );
            _34384 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34382);
            DeRef(_34384);
            _34384 = _34382;
        }
        else{
            Head(SEQ_PTR(_34382),size+1,&_34384);
        }
    }
    _34382 = NOVALUE;
    _34383 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34384;
    if( _1 != _34384 ){
        DeRef(_1);
    }
    _34384 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34376 = NOVALUE;
    _34378 = NOVALUE;
    _34380 = NOVALUE;
    return;
    ;
}


void _67opTAIL()
{
    int _34394 = NOVALUE;
    int _34393 = NOVALUE;
    int _34392 = NOVALUE;
    int _34390 = NOVALUE;
    int _34388 = NOVALUE;
    int _34386 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34386 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34386);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34388 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34388);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34390 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34390);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = tail(val[a],val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34392 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34393 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    {
        int len = SEQ_PTR(_34392)->length;
        int size = (IS_ATOM_INT(_34393)) ? _34393 : (long)(DBL_PTR(_34393)->dbl);
        if (size <= 0) {
            DeRef(_34394);
            _34394 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_34392);
            DeRef(_34394);
            _34394 = _34392;
        }
        else Tail(SEQ_PTR(_34392), len-size+1, &_34394);
    }
    _34392 = NOVALUE;
    _34393 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34394;
    if( _1 != _34394 ){
        DeRef(_1);
    }
    _34394 = NOVALUE;

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    _34386 = NOVALUE;
    _34388 = NOVALUE;
    _34390 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_FUNC()
{
    int _34407 = NOVALUE;
    int _34406 = NOVALUE;
    int _34405 = NOVALUE;
    int _34403 = NOVALUE;
    int _34400 = NOVALUE;
    int _34398 = NOVALUE;
    int _34396 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34396 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34396);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34398 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34398);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	target = Code[pc+3]*/
    _34400 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34400);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** 	if val[a] = M_CALL_BACK then*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34403 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    if (binary_op_a(NOTEQ, _34403, 52)){
        _34403 = NOVALUE;
        goto L1; // [67] 81
    }
    _34403 = NOVALUE;

    /** 		do_callback(b)*/
    _67do_callback(_67b_63010);
    goto L2; // [78] 112
L1: 

    /** 		val[target] = machine_func(val[a], val[b])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34405 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34406 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _34407 = machine(_34405, _34406);
    _34405 = NOVALUE;
    _34406 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34407;
    if( _1 != _34407 ){
        DeRef(_1);
    }
    _34407 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_34396);
    _34396 = NOVALUE;
    DeRef(_34398);
    _34398 = NOVALUE;
    DeRef(_34400);
    _34400 = NOVALUE;
    return;
    ;
}


void _67opSPLICE()
{
    int _34419 = NOVALUE;
    int _34418 = NOVALUE;
    int _34417 = NOVALUE;
    int _34416 = NOVALUE;
    int _34414 = NOVALUE;
    int _34412 = NOVALUE;
    int _34410 = NOVALUE;
    int _34408 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34408 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34408);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34410 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34410);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34412 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34412);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34414 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34414);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = splice(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34416 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34417 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34418 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34418) ? _34418 : DBL_PTR(_34418)->dbl;
        if (insert_pos <= 0) {
            if (IS_SEQUENCE(_34417)) {
                Concat(&_34419,_34417,_34416);
            }
            else{
                Prepend(&_34419,_34416,_34417);
            }
        }
        else if (insert_pos > SEQ_PTR(_34416)->length){
            if (IS_SEQUENCE(_34417)) {
                Concat(&_34419,_34416,_34417);
            }
            else{
                Append(&_34419,_34416,_34417);
            }
        }
        else if (IS_SEQUENCE(_34417)) {
            if( _34419 != _34416 || SEQ_PTR( _34416 )->ref != 1 ){
                DeRef( _34419 );
                RefDS( _34416 );
            }
            assign_space = Add_internal_space( _34416, insert_pos,((s1_ptr)SEQ_PTR(_34417))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_34417), _34416 == _34419 );
            _34419 = MAKE_SEQ( assign_space );
        }
        else {
            if( _34419 != _34416 && SEQ_PTR( _34416 )->ref != 1 ){
                _34419 = Insert( _34416, _34417, insert_pos);
            }
            else {
                DeRef( _34419 );
                RefDS( _34416 );
                _34419 = Insert( _34416, _34417, insert_pos);
            }
        }
    }
    _34416 = NOVALUE;
    _34417 = NOVALUE;
    _34418 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34419;
    if( _1 != _34419 ){
        DeRef(_1);
    }
    _34419 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _34408 = NOVALUE;
    _34410 = NOVALUE;
    _34412 = NOVALUE;
    _34414 = NOVALUE;
    return;
    ;
}


void _67opINSERT()
{
    int _34432 = NOVALUE;
    int _34431 = NOVALUE;
    int _34430 = NOVALUE;
    int _34429 = NOVALUE;
    int _34427 = NOVALUE;
    int _34425 = NOVALUE;
    int _34423 = NOVALUE;
    int _34421 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34421 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34421);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34423 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34423);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	c = Code[pc+3]*/
    _34425 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67c_63011 = (int)*(((s1_ptr)_2)->base + _34425);
    if (!IS_ATOM_INT(_67c_63011)){
        _67c_63011 = (long)DBL_PTR(_67c_63011)->dbl;
    }

    /** 	target = Code[pc+4]*/
    _34427 = _67pc_63008 + 4;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67target_63013 = (int)*(((s1_ptr)_2)->base + _34427);
    if (!IS_ATOM_INT(_67target_63013)){
        _67target_63013 = (long)DBL_PTR(_67target_63013)->dbl;
    }

    /** 	val[target] = insert(val[a],val[b],val[c])*/
    _2 = (int)SEQ_PTR(_67val_63018);
    _34429 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34430 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34431 = (int)*(((s1_ptr)_2)->base + _67c_63011);
    {
        s1_ptr assign_space;
        insert_pos = IS_ATOM_INT(_34431) ? _34431 : DBL_PTR(_34431)->dbl;
        if (insert_pos <= 0){
            Prepend(&_34432,_34429,_34430);
        }
        else if (insert_pos > SEQ_PTR(_34429)->length) {
            Ref( _34430 );
            Append(&_34432,_34429,_34430);
        }
        else {
            Ref( _34430 );
            RefDS( _34429 );
            _34432 = Insert(_34429,_34430,insert_pos);
        }
    }
    _34429 = NOVALUE;
    _34430 = NOVALUE;
    _34431 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67target_63013);
    _1 = *(int *)_2;
    *(int *)_2 = _34432;
    if( _1 != _34432 ){
        DeRef(_1);
    }
    _34432 = NOVALUE;

    /** 	pc += 5*/
    _67pc_63008 = _67pc_63008 + 5;

    /** end procedure*/
    _34421 = NOVALUE;
    _34423 = NOVALUE;
    _34425 = NOVALUE;
    _34427 = NOVALUE;
    return;
    ;
}


void _67opMACHINE_PROC()
{
    int _v_67917 = NOVALUE;
    int _34451 = NOVALUE;
    int _34450 = NOVALUE;
    int _34448 = NOVALUE;
    int _34446 = NOVALUE;
    int _34445 = NOVALUE;
    int _34443 = NOVALUE;
    int _34442 = NOVALUE;
    int _34436 = NOVALUE;
    int _34434 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34434 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34434);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	b = Code[pc+2]*/
    _34436 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67b_63010 = (int)*(((s1_ptr)_2)->base + _34436);
    if (!IS_ATOM_INT(_67b_63010)){
        _67b_63010 = (long)DBL_PTR(_67b_63010)->dbl;
    }

    /** 	v = val[a]*/
    DeRef(_v_67917);
    _2 = (int)SEQ_PTR(_67val_63018);
    _v_67917 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    Ref(_v_67917);

    /** 	switch v do*/
    if (IS_SEQUENCE(_v_67917) ){
        goto L1; // [45] 201
    }
    if(!IS_ATOM_INT(_v_67917)){
        if( (DBL_PTR(_v_67917)->dbl != (double) ((int) DBL_PTR(_v_67917)->dbl) ) ){
            goto L1; // [45] 201
        }
        _0 = (int) DBL_PTR(_v_67917)->dbl;
    }
    else {
        _0 = _v_67917;
    };
    switch ( _0 ){ 

        /** 		case M_CRASH_ROUTINE then*/
        case 66:

        /** 			do_crash_routine(b)*/
        _67do_crash_routine(_67b_63010);
        goto L2; // [61] 217

        /** 		case M_CRASH_MESSAGE then*/
        case 37:

        /** 			crash_msg = val[b]*/
        DeRef(_67crash_msg_62934);
        _2 = (int)SEQ_PTR(_67val_63018);
        _67crash_msg_62934 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        Ref(_67crash_msg_62934);
        goto L2; // [77] 217

        /** 		case M_CRASH_FILE then*/
        case 57:

        /** 			if sequence(val[b]) then*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _34442 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        _34443 = IS_SEQUENCE(_34442);
        _34442 = NOVALUE;
        if (_34443 == 0)
        {
            _34443 = NOVALUE;
            goto L2; // [96] 217
        }
        else{
            _34443 = NOVALUE;
        }

        /** 				err_file_name = val[b]*/
        DeRef(_67err_file_name_63058);
        _2 = (int)SEQ_PTR(_67val_63018);
        _67err_file_name_63058 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        Ref(_67err_file_name_63058);
        goto L2; // [112] 217

        /** 		case M_WARNING_FILE then*/
        case 72:

        /** 			display_warnings = 1*/
        _43display_warnings_48157 = 1;

        /** 			if sequence(val[b]) then*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _34445 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        _34446 = IS_SEQUENCE(_34445);
        _34445 = NOVALUE;
        if (_34446 == 0)
        {
            _34446 = NOVALUE;
            goto L3; // [138] 154
        }
        else{
            _34446 = NOVALUE;
        }

        /** 				TempWarningName = val[b]*/
        DeRef(_12TempWarningName_11696);
        _2 = (int)SEQ_PTR(_67val_63018);
        _12TempWarningName_11696 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        Ref(_12TempWarningName_11696);
        goto L2; // [151] 217
L3: 

        /** 				TempWarningName = STDERR*/
        DeRef(_12TempWarningName_11696);
        _12TempWarningName_11696 = 2;

        /** 				display_warnings = (val[b] >= 0)*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _34448 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        if (IS_ATOM_INT(_34448)) {
            _43display_warnings_48157 = (_34448 >= 0);
        }
        else {
            _43display_warnings_48157 = binary_op(GREATEREQ, _34448, 0);
        }
        _34448 = NOVALUE;
        if (!IS_ATOM_INT(_43display_warnings_48157)) {
            _1 = (long)(DBL_PTR(_43display_warnings_48157)->dbl);
            DeRefDS(_43display_warnings_48157);
            _43display_warnings_48157 = _1;
        }
        goto L2; // [178] 217

        /** 		case M_CRASH then*/
        case 67:

        /** 			RTFatal( val[b] )*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _34450 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        Ref(_34450);
        _67RTFatal(_34450);
        _34450 = NOVALUE;
        goto L2; // [197] 217

        /** 		case else*/
        default:
L1: 

        /** 			machine_proc(v, val[b])*/
        _2 = (int)SEQ_PTR(_67val_63018);
        _34451 = (int)*(((s1_ptr)_2)->base + _67b_63010);
        machine(_v_67917, _34451);
        _34451 = NOVALUE;
    ;}L2: 

    /** 	pc += 3*/
    _67pc_63008 = _67pc_63008 + 3;

    /** end procedure*/
    DeRef(_v_67917);
    DeRef(_34434);
    _34434 = NOVALUE;
    DeRef(_34436);
    _34436 = NOVALUE;
    return;
    ;
}


void _67opDEREF_TEMP()
{
    int _34454 = NOVALUE;
    int _34453 = NOVALUE;
    int _0, _1, _2;
    

    /** 	val[Code[pc+1]] = NOVALUE*/
    _34453 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34454 = (int)*(((s1_ptr)_2)->base + _34453);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34454))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_34454)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _34454);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34453 = NOVALUE;
    _34454 = NOVALUE;
    return;
    ;
}


void _67do_delete_routine(int _dx_67970, int _o_67971)
{
    int _arglist_assign_67974 = NOVALUE;
    int _34476 = NOVALUE;
    int _34475 = NOVALUE;
    int _34474 = NOVALUE;
    int _34473 = NOVALUE;
    int _34472 = NOVALUE;
    int _34470 = NOVALUE;
    int _34469 = NOVALUE;
    int _34467 = NOVALUE;
    int _34466 = NOVALUE;
    int _34461 = NOVALUE;
    int _34459 = NOVALUE;
    int _34458 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val[t_id] = user_delete_rid[dx]*/
    _2 = (int)SEQ_PTR(_67user_delete_rid_67963);
    _34458 = (int)*(((s1_ptr)_2)->base + _dx_67970);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_id_62939);
    _1 = *(int *)_2;
    *(int *)_2 = _34458;
    if( _1 != _34458 ){
        DeRef(_1);
    }
    _34458 = NOVALUE;

    /** 	val[t_arglist] = {o}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_o_67971);
    *((int *)(_2+4)) = _o_67971;
    _34459 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_62940);
    _1 = *(int *)_2;
    *(int *)_2 = _34459;
    if( _1 != _34459 ){
        DeRef(_1);
    }
    _34459 = NOVALUE;

    /** 	atom arglist_assign = new_arg_assign()*/
    _0 = _arglist_assign_67974;
    _arglist_assign_67974 = _67new_arg_assign();
    DeRef(_0);

    /** 	SymTab[delete_code_routine][S_RESIDENT_TASK] = current_task*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_67delete_code_routine_62943 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = _67current_task_63025;
    DeRef(_1);
    _34461 = NOVALUE;

    /** 	call_stack = append(call_stack, pc)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67pc_63008);

    /** 	call_stack = append(call_stack, delete_code_routine)*/
    Append(&_67call_stack_63026, _67call_stack_63026, _67delete_code_routine_62943);

    /** 	Code = delete_code*/
    RefDS(_67delete_code_62937);
    DeRef(_12Code_11771);
    _12Code_11771 = _67delete_code_62937;

    /** 	pc = 1*/
    _67pc_63008 = 1;

    /** 	do_exec()*/
    _67do_exec();

    /** 	if arglist_assign = arg_assign then*/
    if (binary_op_a(NOTEQ, _arglist_assign_67974, _67arg_assign_62952)){
        goto L1; // [99] 116
    }

    /** 		val[t_arglist] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67t_arglist_62940);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1: 

    /** 	o = 0*/
    DeRef(_o_67971);
    _o_67971 = 0;

    /** 	pc = call_stack[$-1]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34466 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34466 = 1;
    }
    _34467 = _34466 - 1;
    _34466 = NOVALUE;
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _67pc_63008 = (int)*(((s1_ptr)_2)->base + _34467);
    if (!IS_ATOM_INT(_67pc_63008))
    _67pc_63008 = (long)DBL_PTR(_67pc_63008)->dbl;

    /** 	call_stack = call_stack[1..$-2]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34469 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34469 = 1;
    }
    _34470 = _34469 - 2;
    _34469 = NOVALUE;
    rhs_slice_target = (object_ptr)&_67call_stack_63026;
    RHS_Slice(_67call_stack_63026, 1, _34470);

    /** 	restore_privates( call_stack[$] )*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34472 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34472 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _34473 = (int)*(((s1_ptr)_2)->base + _34472);
    Ref(_34473);
    _67restore_privates(_34473);
    _34473 = NOVALUE;

    /** 	Code = SymTab[call_stack[$]][S_CODE]*/
    if (IS_SEQUENCE(_67call_stack_63026)){
            _34474 = SEQ_PTR(_67call_stack_63026)->length;
    }
    else {
        _34474 = 1;
    }
    _2 = (int)SEQ_PTR(_67call_stack_63026);
    _34475 = (int)*(((s1_ptr)_2)->base + _34474);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_34475)){
        _34476 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34475)->dbl));
    }
    else{
        _34476 = (int)*(((s1_ptr)_2)->base + _34475);
    }
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_34476);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _34476 = NOVALUE;

    /** end procedure*/
    DeRef(_arglist_assign_67974);
    _34467 = NOVALUE;
    _34470 = NOVALUE;
    _34475 = NOVALUE;
    return;
    ;
}


void _67user_delete_01(int _o_68004)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 1, o )*/
    Ref(_o_68004);
    _67do_delete_routine(1, _o_68004);

    /** end procedure*/
    DeRef(_o_68004);
    return;
    ;
}


void _67user_delete_02(int _o_68009)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 2, o )*/
    Ref(_o_68009);
    _67do_delete_routine(2, _o_68009);

    /** end procedure*/
    DeRef(_o_68009);
    return;
    ;
}


void _67user_delete_03(int _o_68014)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 3, o )*/
    Ref(_o_68014);
    _67do_delete_routine(3, _o_68014);

    /** end procedure*/
    DeRef(_o_68014);
    return;
    ;
}


void _67user_delete_04(int _o_68019)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 4, o )*/
    Ref(_o_68019);
    _67do_delete_routine(4, _o_68019);

    /** end procedure*/
    DeRef(_o_68019);
    return;
    ;
}


void _67user_delete_05(int _o_68024)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 5, o )*/
    Ref(_o_68024);
    _67do_delete_routine(5, _o_68024);

    /** end procedure*/
    DeRef(_o_68024);
    return;
    ;
}


void _67user_delete_06(int _o_68029)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 6, o )*/
    Ref(_o_68029);
    _67do_delete_routine(6, _o_68029);

    /** end procedure*/
    DeRef(_o_68029);
    return;
    ;
}


void _67user_delete_07(int _o_68034)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 7, o )*/
    Ref(_o_68034);
    _67do_delete_routine(7, _o_68034);

    /** end procedure*/
    DeRef(_o_68034);
    return;
    ;
}


void _67user_delete_08(int _o_68039)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 8, o )*/
    Ref(_o_68039);
    _67do_delete_routine(8, _o_68039);

    /** end procedure*/
    DeRef(_o_68039);
    return;
    ;
}


void _67user_delete_09(int _o_68044)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 9, o )*/
    Ref(_o_68044);
    _67do_delete_routine(9, _o_68044);

    /** end procedure*/
    DeRef(_o_68044);
    return;
    ;
}


void _67user_delete_10(int _o_68049)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 10, o )*/
    Ref(_o_68049);
    _67do_delete_routine(10, _o_68049);

    /** end procedure*/
    DeRef(_o_68049);
    return;
    ;
}


void _67user_delete_11(int _o_68054)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 11, o )*/
    Ref(_o_68054);
    _67do_delete_routine(11, _o_68054);

    /** end procedure*/
    DeRef(_o_68054);
    return;
    ;
}


void _67user_delete_12(int _o_68059)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 12, o )*/
    Ref(_o_68059);
    _67do_delete_routine(12, _o_68059);

    /** end procedure*/
    DeRef(_o_68059);
    return;
    ;
}


void _67user_delete_13(int _o_68064)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 13, o )*/
    Ref(_o_68064);
    _67do_delete_routine(13, _o_68064);

    /** end procedure*/
    DeRef(_o_68064);
    return;
    ;
}


void _67user_delete_14(int _o_68069)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 14, o )*/
    Ref(_o_68069);
    _67do_delete_routine(14, _o_68069);

    /** end procedure*/
    DeRef(_o_68069);
    return;
    ;
}


void _67user_delete_15(int _o_68074)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 15, o )*/
    Ref(_o_68074);
    _67do_delete_routine(15, _o_68074);

    /** end procedure*/
    DeRef(_o_68074);
    return;
    ;
}


void _67user_delete_16(int _o_68079)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 16, o )*/
    Ref(_o_68079);
    _67do_delete_routine(16, _o_68079);

    /** end procedure*/
    DeRef(_o_68079);
    return;
    ;
}


void _67user_delete_17(int _o_68084)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 17, o )*/
    Ref(_o_68084);
    _67do_delete_routine(17, _o_68084);

    /** end procedure*/
    DeRef(_o_68084);
    return;
    ;
}


void _67user_delete_18(int _o_68089)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 18, o )*/
    Ref(_o_68089);
    _67do_delete_routine(18, _o_68089);

    /** end procedure*/
    DeRef(_o_68089);
    return;
    ;
}


void _67user_delete_19(int _o_68094)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 19, o )*/
    Ref(_o_68094);
    _67do_delete_routine(19, _o_68094);

    /** end procedure*/
    DeRef(_o_68094);
    return;
    ;
}


void _67user_delete_20(int _o_68099)
{
    int _0, _1, _2;
    

    /** 	do_delete_routine( 20, o )*/
    Ref(_o_68099);
    _67do_delete_routine(20, _o_68099);

    /** end procedure*/
    DeRef(_o_68099);
    return;
    ;
}


void _67opDELETE_ROUTINE()
{
    int _rid_68107 = NOVALUE;
    int _34533 = NOVALUE;
    int _34532 = NOVALUE;
    int _34531 = NOVALUE;
    int _34530 = NOVALUE;
    int _34529 = NOVALUE;
    int _34528 = NOVALUE;
    int _34521 = NOVALUE;
    int _34520 = NOVALUE;
    int _34518 = NOVALUE;
    int _0, _1, _2;
    

    /** 	a = Code[pc+1]*/
    _34518 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _67a_63009 = (int)*(((s1_ptr)_2)->base + _34518);
    if (!IS_ATOM_INT(_67a_63009)){
        _67a_63009 = (long)DBL_PTR(_67a_63009)->dbl;
    }

    /** 	integer rid = val[Code[pc+2]]*/
    _34520 = _67pc_63008 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34521 = (int)*(((s1_ptr)_2)->base + _34520);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34521)){
        _rid_68107 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34521)->dbl));
    }
    else{
        _rid_68107 = (int)*(((s1_ptr)_2)->base + _34521);
    }
    if (!IS_ATOM_INT(_rid_68107))
    _rid_68107 = (long)DBL_PTR(_rid_68107)->dbl;

    /** 	b = find( rid, user_delete_rid )*/
    _67b_63010 = find_from(_rid_68107, _67user_delete_rid_67963, 1);

    /** 	if not b then*/
    if (_67b_63010 != 0)
    goto L1; // [50] 86

    /** 		b = find( -1, user_delete_rid )*/
    _67b_63010 = find_from(-1, _67user_delete_rid_67963, 1);

    /** 		if not b then*/
    if (_67b_63010 != 0)
    goto L2; // [66] 75

    /** 			RTFatal("Maximum of 20 user defined delete routines exceeded.")*/
    RefDS(_34527);
    _67RTFatal(_34527);
L2: 

    /** 		user_delete_rid[b] = rid*/
    _2 = (int)SEQ_PTR(_67user_delete_rid_67963);
    _2 = (int)(((s1_ptr)_2)->base + _67b_63010);
    *(int *)_2 = _rid_68107;
L1: 

    /** 	val[Code[pc+3]] = delete_routine( val[a], eu_delete_rid[b] )*/
    _34528 = _67pc_63008 + 3;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34529 = (int)*(((s1_ptr)_2)->base + _34528);
    _2 = (int)SEQ_PTR(_67val_63018);
    _34530 = (int)*(((s1_ptr)_2)->base + _67a_63009);
    _2 = (int)SEQ_PTR(_67eu_delete_rid_67961);
    _34531 = (int)*(((s1_ptr)_2)->base + _67b_63010);
    DeRef(_34532);
    if( IS_ATOM_INT(_34530) ){
        _34532 = NewDouble( (double) _34530 );
    }
    else {
        if( !UNIQUE(SEQ_PTR(_34530)) ){
            if( IS_ATOM_DBL( _34530 ) ){
                _34532 = NewDouble( DBL_PTR(_34530)->dbl );
            }
            else {
                RefDS(_34530);
                _34532 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34530) ));
            }
        }
        else {
            _34532 = _34530;
        }
    }
    _1 = (int) _00[_34531].cleanup;
    if( _1 == 0 ){
        _1 = (int) TransAlloc( sizeof(struct cleanup) );
        _00[_34531].cleanup = (cleanup_ptr)_1;
    }
    ((cleanup_ptr)_1)->type = CLEAN_UDT_RT;
    ((cleanup_ptr)_1)->func.rid = _34531;
    ((cleanup_ptr)_1)->next = 0;
    if( IS_ATOM(_34532) ){
        if( IS_ATOM_INT(_34532) ){
            _34532 = NewDouble( (double) _34530 );
        }
        if(DBL_PTR(_34532)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, DBL_PTR(_34532)->cleanup );
        }
        else if( !UNIQUE(DBL_PTR(_34532)) ){
            DeRefDS(_34532);
            _34532 = NewDouble( DBL_PTR(_34532)->dbl );
        }
        DBL_PTR(_34532)->cleanup = (cleanup_ptr)_1;
    }
    else{
        if(SEQ_PTR(_34532)->cleanup != 0 ){
            _1 = (int) ChainDeleteRoutine( (cleanup_ptr)_1, SEQ_PTR(_34532)->cleanup );
        }
        else if( !UNIQUE(SEQ_PTR(_34532)) ){
            _34532 = MAKE_SEQ(SequenceCopy( SEQ_PTR(_34532) ));
        }
        SEQ_PTR(_34532)->cleanup = (cleanup_ptr)_1;
    }
    _34530 = NOVALUE;
    _34531 = NOVALUE;
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34529))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_34529)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _34529);
    _1 = *(int *)_2;
    *(int *)_2 = _34532;
    if( _1 != _34532 ){
        DeRef(_1);
    }
    _34532 = NOVALUE;

    /** 	if sym_mode( a ) = M_TEMP then*/
    _34533 = _52sym_mode(_67a_63009);
    if (binary_op_a(NOTEQ, _34533, 3)){
        DeRef(_34533);
        _34533 = NOVALUE;
        goto L3; // [136] 153
    }
    DeRef(_34533);
    _34533 = NOVALUE;

    /** 		val[a] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_67val_63018);
    _2 = (int)(((s1_ptr)_2)->base + _67a_63009);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L3: 

    /** 	pc += 4*/
    _67pc_63008 = _67pc_63008 + 4;

    /** end procedure*/
    DeRef(_34518);
    _34518 = NOVALUE;
    DeRef(_34520);
    _34520 = NOVALUE;
    _34521 = NOVALUE;
    DeRef(_34528);
    _34528 = NOVALUE;
    _34529 = NOVALUE;
    return;
    ;
}


void _67opDELETE_OBJECT()
{
    int _34538 = NOVALUE;
    int _34537 = NOVALUE;
    int _34536 = NOVALUE;
    int _0, _1, _2;
    

    /** 	delete( val[Code[pc+1]] )*/
    _34536 = _67pc_63008 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _34537 = (int)*(((s1_ptr)_2)->base + _34536);
    _2 = (int)SEQ_PTR(_67val_63018);
    if (!IS_ATOM_INT(_34537)){
        _34538 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_34537)->dbl));
    }
    else{
        _34538 = (int)*(((s1_ptr)_2)->base + _34537);
    }
    if( IS_SEQUENCE(_34538) ){
        cleanup_sequence(SEQ_PTR(_34538));
    }
    if( IS_ATOM_DBL(_34538)){
        cleanup_double(DBL_PTR(_34538));
    }
    _34538 = NOVALUE;

    /** 	pc += 2*/
    _67pc_63008 = _67pc_63008 + 2;

    /** end procedure*/
    _34536 = NOVALUE;
    _34537 = NOVALUE;
    return;
    ;
}


void _67do_exec()
{
    int _op_68143 = NOVALUE;
    int _34547 = NOVALUE;
    int _0, _1, _2;
    

    /** 	keep_running = TRUE*/
    _67keep_running_63015 = _9TRUE_431;

    /** 	while keep_running do*/
L1: 
    if (_67keep_running_63015 == 0)
    {
        goto L2; // [17] 1850
    }
    else{
    }

    /** 		integer op = Code[pc]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _op_68143 = (int)*(((s1_ptr)_2)->base + _67pc_63008);
    if (!IS_ATOM_INT(_op_68143)){
        _op_68143 = (long)DBL_PTR(_op_68143)->dbl;
    }

    /** 		ifdef DEBUG then*/

    /** 		switch op do*/
    _0 = _op_68143;
    switch ( _0 ){ 

        /** 			case ABORT then*/
        case 126:

        /** 				opABORT()*/
        _67opABORT();
        goto L3; // [49] 1843

        /** 			case AND then*/
        case 8:

        /** 				opAND()*/
        _67opAND();
        goto L3; // [59] 1843

        /** 			case AND_BITS then*/
        case 56:

        /** 				opAND_BITS()*/
        _67opAND_BITS();
        goto L3; // [69] 1843

        /** 			case APPEND then*/
        case 35:

        /** 				opAPPEND()*/
        _67opAPPEND();
        goto L3; // [79] 1843

        /** 			case ARCTAN then*/
        case 73:

        /** 				opARCTAN()*/
        _67opARCTAN();
        goto L3; // [89] 1843

        /** 			case ASSIGN, ASSIGN_I then*/
        case 18:
        case 113:

        /** 				opASSIGN()*/
        _67opASSIGN();
        goto L3; // [101] 1843

        /** 			case ASSIGN_OP_SLICE then*/
        case 150:

        /** 				opASSIGN_OP_SLICE()*/
        _67opASSIGN_OP_SLICE();
        goto L3; // [111] 1843

        /** 			case ASSIGN_OP_SUBS then*/
        case 149:

        /** 				opASSIGN_OP_SUBS()*/
        _67opASSIGN_OP_SUBS();
        goto L3; // [121] 1843

        /** 			case ASSIGN_SLICE then*/
        case 45:

        /** 				opASSIGN_SLICE()*/
        _67opASSIGN_SLICE();
        goto L3; // [131] 1843

        /** 			case ASSIGN_SUBS, ASSIGN_SUBS_CHECK, ASSIGN_SUBS_I then*/
        case 16:
        case 84:
        case 118:

        /** 				opASSIGN_SUBS()*/
        _67opASSIGN_SUBS();
        goto L3; // [145] 1843

        /** 			case ATOM_CHECK then*/
        case 101:

        /** 				opATOM_CHECK()*/
        _67opATOM_CHECK();
        goto L3; // [155] 1843

        /** 			case BADRETURNF then*/
        case 43:

        /** 				opBADRETURNF()*/
        _67opBADRETURNF();
        goto L3; // [165] 1843

        /** 			case C_FUNC then*/
        case 133:

        /** 				opC_FUNC()*/
        _67opC_FUNC();
        goto L3; // [175] 1843

        /** 			case C_PROC then*/
        case 132:

        /** 				opC_PROC()*/
        _67opC_PROC();
        goto L3; // [185] 1843

        /** 			case CALL then*/
        case 129:

        /** 				opCALL()*/
        _67opCALL();
        goto L3; // [195] 1843

        /** 			case CALL_BACK_RETURN then*/
        case 135:

        /** 				opCALL_BACK_RETURN()*/
        _67opCALL_BACK_RETURN();
        goto L3; // [205] 1843

        /** 			case CALL_PROC, CALL_FUNC then*/
        case 136:
        case 137:

        /** 				opCALL_PROC()*/
        _67opCALL_PROC();
        goto L3; // [217] 1843

        /** 			case CASE then*/
        case 186:

        /** 				opCASE()*/
        _67opCASE();
        goto L3; // [227] 1843

        /** 			case CLEAR_SCREEN then*/
        case 59:

        /** 				opCLEAR_SCREEN()*/
        _67opCLEAR_SCREEN();
        goto L3; // [237] 1843

        /** 			case CLOSE then*/
        case 86:

        /** 				opCLOSE()*/
        _67opCLOSE();
        goto L3; // [247] 1843

        /** 			case COMMAND_LINE then*/
        case 100:

        /** 				opCOMMAND_LINE()*/
        _67opCOMMAND_LINE();
        goto L3; // [257] 1843

        /** 			case COMPARE then*/
        case 76:

        /** 				opCOMPARE()*/
        _67opCOMPARE();
        goto L3; // [267] 1843

        /** 			case CONCAT then*/
        case 15:

        /** 				opCONCAT()*/
        _67opCONCAT();
        goto L3; // [277] 1843

        /** 			case CONCAT_N then*/
        case 157:

        /** 				opCONCAT_N()*/
        _67opCONCAT_N();
        goto L3; // [287] 1843

        /** 			case COS then*/
        case 81:

        /** 				opCOS()*/
        _67opCOS();
        goto L3; // [297] 1843

        /** 			case DATE then*/
        case 69:

        /** 				opDATE()*/
        _67opDATE();
        goto L3; // [307] 1843

        /** 			case DIV2 then*/
        case 98:

        /** 				opDIV2()*/
        _67opDIV2();
        goto L3; // [317] 1843

        /** 			case DIVIDE then*/
        case 14:

        /** 				opDIVIDE()*/
        _67opDIVIDE();
        goto L3; // [327] 1843

        /** 			case ELSE, EXIT, ENDWHILE, RETRY then*/
        case 23:
        case 61:
        case 22:
        case 184:

        /** 				opELSE()*/
        _67opELSE();
        goto L3; // [343] 1843

        /** 			case ENDFOR_GENERAL, ENDFOR_UP, ENDFOR_DOWN, ENDFOR_INT_UP,*/
        case 39:
        case 49:
        case 50:
        case 48:
        case 52:
        case 55:

        /** 				opENDFOR_GENERAL()*/
        _67opENDFOR_GENERAL();
        goto L3; // [363] 1843

        /** 			case ENDFOR_INT_UP1 then*/
        case 54:

        /** 				opENDFOR_INT_UP1()*/
        _67opENDFOR_INT_UP1();
        goto L3; // [373] 1843

        /** 			case EQUAL then*/
        case 153:

        /** 				opEQUAL()*/
        _67opEQUAL();
        goto L3; // [383] 1843

        /** 			case EQUALS then*/
        case 3:

        /** 				opEQUALS()*/
        _67opEQUALS();
        goto L3; // [393] 1843

        /** 			case EQUALS_IFW, EQUALS_IFW_I then*/
        case 104:
        case 121:

        /** 				opEQUALS_IFW()*/
        _67opEQUALS_IFW();
        goto L3; // [405] 1843

        /** 			case EXIT_BLOCK then*/
        case 206:

        /** 				opEXIT_BLOCK()*/
        _67opEXIT_BLOCK();
        goto L3; // [415] 1843

        /** 			case FIND then*/
        case 77:

        /** 				opFIND()*/
        _67opFIND();
        goto L3; // [425] 1843

        /** 			case FIND_FROM then*/
        case 176:

        /** 				opFIND_FROM()*/
        _67opFIND_FROM();
        goto L3; // [435] 1843

        /** 			case FLOOR then*/
        case 83:

        /** 				opFLOOR()*/
        _67opFLOOR();
        goto L3; // [445] 1843

        /** 			case FLOOR_DIV then*/
        case 63:

        /** 				opFLOOR_DIV()*/
        _67opFLOOR_DIV();
        goto L3; // [455] 1843

        /** 			case FLOOR_DIV2 then*/
        case 66:

        /** 				opFLOOR_DIV2()*/
        _67opFLOOR_DIV2();
        goto L3; // [465] 1843

        /** 			case FOR, FOR_I then*/
        case 21:
        case 125:

        /** 				opFOR()*/
        _67opFOR();
        goto L3; // [477] 1843

        /** 			case GET_KEY then*/
        case 79:

        /** 				opGET_KEY()*/
        _67opGET_KEY();
        goto L3; // [487] 1843

        /** 			case GETC then*/
        case 33:

        /** 				opGETC()*/
        _67opGETC();
        goto L3; // [497] 1843

        /** 			case GETENV then*/
        case 91:

        /** 				opGETENV()*/
        _67opGETENV();
        goto L3; // [507] 1843

        /** 			case GETS then*/
        case 17:

        /** 				opGETS()*/
        _67opGETS();
        goto L3; // [517] 1843

        /** 			case GLABEL then*/
        case 189:

        /** 				opGLABEL()*/
        _67opGLABEL();
        goto L3; // [527] 1843

        /** 			case GLOBAL_INIT_CHECK, PRIVATE_INIT_CHECK then*/
        case 109:
        case 30:

        /** 				opGLOBAL_INIT_CHECK()*/
        _67opGLOBAL_INIT_CHECK();
        goto L3; // [539] 1843

        /** 			case GOTO then*/
        case 188:

        /** 				opGOTO()*/
        _67opGOTO();
        goto L3; // [549] 1843

        /** 			case GREATER then*/
        case 6:

        /** 				opGREATER()*/
        _67opGREATER();
        goto L3; // [559] 1843

        /** 			case GREATER_IFW, GREATER_IFW_I then*/
        case 107:
        case 124:

        /** 				opGREATER_IFW()*/
        _67opGREATER_IFW();
        goto L3; // [571] 1843

        /** 			case GREATEREQ then*/
        case 2:

        /** 				opGREATEREQ()*/
        _67opGREATEREQ();
        goto L3; // [581] 1843

        /** 			case GREATEREQ_IFW, GREATEREQ_IFW_I then*/
        case 103:
        case 120:

        /** 				opGREATEREQ_IFW()*/
        _67opGREATEREQ_IFW();
        goto L3; // [593] 1843

        /** 			case HASH then*/
        case 194:

        /** 				opHASH()*/
        _67opHASH();
        goto L3; // [603] 1843

        /** 			case HEAD then*/
        case 198:

        /** 				opHEAD()*/
        _67opHEAD();
        goto L3; // [613] 1843

        /** 			case IF then*/
        case 20:

        /** 				opIF()*/
        _67opIF();
        goto L3; // [623] 1843

        /** 			case INSERT then*/
        case 191:

        /** 				opINSERT()*/
        _67opINSERT();
        goto L3; // [633] 1843

        /** 			case INTEGER_CHECK then*/
        case 96:

        /** 				opINTEGER_CHECK()*/
        _67opINTEGER_CHECK();
        goto L3; // [643] 1843

        /** 			case IS_A_SEQUENCE then*/
        case 68:

        /** 				opIS_A_SEQUENCE()*/
        _67opIS_A_SEQUENCE();
        goto L3; // [653] 1843

        /** 			case IS_AN_ATOM then*/
        case 67:

        /** 				opIS_AN_ATOM()*/
        _67opIS_AN_ATOM();
        goto L3; // [663] 1843

        /** 			case IS_AN_INTEGER then*/
        case 94:

        /** 				opIS_AN_INTEGER()*/
        _67opIS_AN_INTEGER();
        goto L3; // [673] 1843

        /** 			case IS_AN_OBJECT then*/
        case 40:

        /** 				opIS_AN_OBJECT()*/
        _67opIS_AN_OBJECT();
        goto L3; // [683] 1843

        /** 			case LENGTH then*/
        case 42:

        /** 				opLENGTH()*/
        _67opLENGTH();
        goto L3; // [693] 1843

        /** 			case LESS then*/
        case 1:

        /** 				opLESS()*/
        _67opLESS();
        goto L3; // [703] 1843

        /** 			case LESS_IFW_I, LESS_IFW then*/
        case 119:
        case 102:

        /** 				opLESS_IFW()*/
        _67opLESS_IFW();
        goto L3; // [715] 1843

        /** 			case LESSEQ then*/
        case 5:

        /** 				opLESSEQ()*/
        _67opLESSEQ();
        goto L3; // [725] 1843

        /** 			case LESSEQ_IFW, LESSEQ_IFW_I then*/
        case 106:
        case 123:

        /** 				opLESSEQ_IFW()*/
        _67opLESSEQ_IFW();
        goto L3; // [737] 1843

        /** 			case LHS_SUBS then*/
        case 95:

        /** 				opLHS_SUBS()*/
        _67opLHS_SUBS();
        goto L3; // [747] 1843

        /** 			case LHS_SUBS1 then*/
        case 161:

        /** 				opLHS_SUBS1()*/
        _67opLHS_SUBS1();
        goto L3; // [757] 1843

        /** 			case LHS_SUBS1_COPY then*/
        case 166:

        /** 				opLHS_SUBS1_COPY()*/
        _67opLHS_SUBS1_COPY();
        goto L3; // [767] 1843

        /** 			case LOG then*/
        case 74:

        /** 				opLOG()*/
        _67opLOG();
        goto L3; // [777] 1843

        /** 			case MACHINE_FUNC then*/
        case 111:

        /** 				opMACHINE_FUNC()*/
        _67opMACHINE_FUNC();
        goto L3; // [787] 1843

        /** 			case MACHINE_PROC then*/
        case 112:

        /** 				opMACHINE_PROC()*/
        _67opMACHINE_PROC();
        goto L3; // [797] 1843

        /** 			case MATCH then*/
        case 78:

        /** 				opMATCH()*/
        _67opMATCH();
        goto L3; // [807] 1843

        /** 			case MATCH_FROM then*/
        case 177:

        /** 				opMATCH_FROM()*/
        _67opMATCH_FROM();
        goto L3; // [817] 1843

        /** 			case MEM_COPY then*/
        case 130:

        /** 				opMEM_COPY()*/
        _67opMEM_COPY();
        goto L3; // [827] 1843

        /** 			case MEM_SET then*/
        case 131:

        /** 				opMEM_SET()*/
        _67opMEM_SET();
        goto L3; // [837] 1843

        /** 			case MINUS, MINUS_I then*/
        case 10:
        case 116:

        /** 				opMINUS()*/
        _67opMINUS();
        goto L3; // [849] 1843

        /** 			case MULTIPLY then*/
        case 13:

        /** 				opMULTIPLY()*/
        _67opMULTIPLY();
        goto L3; // [859] 1843

        /** 			case NOP2, SC2_NULL, ASSIGN_SUBS2, PLATFORM, END_PARAM_CHECK,*/
        case 110:
        case 145:
        case 148:
        case 155:
        case 156:
        case 158:
        case 159:

        /** 				opNOP2()*/
        _67opNOP2();
        goto L3; // [881] 1843

        /** 			case NOPSWITCH then*/
        case 187:

        /** 				opNOPSWITCH()*/
        _67opNOPSWITCH();
        goto L3; // [891] 1843

        /** 			case NOT then*/
        case 7:

        /** 				opNOT()*/
        _67opNOT();
        goto L3; // [901] 1843

        /** 			case NOT_BITS then*/
        case 51:

        /** 				opNOT_BITS()*/
        _67opNOT_BITS();
        goto L3; // [911] 1843

        /** 			case NOT_IFW then*/
        case 108:

        /** 				opNOT_IFW()*/
        _67opNOT_IFW();
        goto L3; // [921] 1843

        /** 			case NOTEQ then*/
        case 4:

        /** 				opNOTEQ()*/
        _67opNOTEQ();
        goto L3; // [931] 1843

        /** 			case NOTEQ_IFW, NOTEQ_IFW_I then*/
        case 105:
        case 122:

        /** 				opNOTEQ_IFW()*/
        _67opNOTEQ_IFW();
        goto L3; // [943] 1843

        /** 			case OPEN then*/
        case 37:

        /** 				opOPEN()*/
        _67opOPEN();
        goto L3; // [953] 1843

        /** 			case OPTION_SWITCHES then*/
        case 183:

        /** 				opOPTION_SWITCHES()*/
        _67opOPTION_SWITCHES();
        goto L3; // [963] 1843

        /** 			case OR then*/
        case 9:

        /** 				opOR()*/
        _67opOR();
        goto L3; // [973] 1843

        /** 			case OR_BITS then*/
        case 24:

        /** 				opOR_BITS()*/
        _67opOR_BITS();
        goto L3; // [983] 1843

        /** 			case PASSIGN_OP_SLICE then*/
        case 165:

        /** 				opPASSIGN_OP_SLICE()*/
        _67opPASSIGN_OP_SLICE();
        goto L3; // [993] 1843

        /** 			case PASSIGN_OP_SUBS then*/
        case 164:

        /** 				opPASSIGN_OP_SUBS()*/
        _67opPASSIGN_OP_SUBS();
        goto L3; // [1003] 1843

        /** 			case PASSIGN_SLICE then*/
        case 163:

        /** 				opPASSIGN_SLICE()*/
        _67opPASSIGN_SLICE();
        goto L3; // [1013] 1843

        /** 			case PASSIGN_SUBS then*/
        case 162:

        /** 				opPASSIGN_SUBS()*/
        _67opPASSIGN_SUBS();
        goto L3; // [1023] 1843

        /** 			case PEEK then*/
        case 127:

        /** 				opPEEK()*/
        _67opPEEK();
        goto L3; // [1033] 1843

        /** 			case PEEK_STRING then*/
        case 182:

        /** 				opPEEK_STRING()*/
        _67opPEEK_STRING();
        goto L3; // [1043] 1843

        /** 			case PEEK2S then*/
        case 179:

        /** 				opPEEK2S()*/
        _67opPEEK2S();
        goto L3; // [1053] 1843

        /** 			case PEEK2U then*/
        case 180:

        /** 				opPEEK2U()*/
        _67opPEEK2U();
        goto L3; // [1063] 1843

        /** 			case PEEK4S then*/
        case 139:

        /** 				opPEEK4S()*/
        _67opPEEK4S();
        goto L3; // [1073] 1843

        /** 			case PEEK4U then*/
        case 140:

        /** 				opPEEK4U()*/
        _67opPEEK4U();
        goto L3; // [1083] 1843

        /** 			case PEEKS then*/
        case 181:

        /** 				opPEEKS()*/
        _67opPEEKS();
        goto L3; // [1093] 1843

        /** 			case PLENGTH then*/
        case 160:

        /** 				opPLENGTH()*/
        _67opPLENGTH();
        goto L3; // [1103] 1843

        /** 			case PLUS, PLUS_I then*/
        case 11:
        case 115:

        /** 				opPLUS()*/
        _67opPLUS();
        goto L3; // [1115] 1843

        /** 			case PLUS1, PLUS1_I then*/
        case 93:
        case 117:

        /** 				opPLUS1()*/
        _67opPLUS1();
        goto L3; // [1127] 1843

        /** 			case POKE then*/
        case 128:

        /** 				opPOKE()*/
        _67opPOKE();
        goto L3; // [1137] 1843

        /** 			case POKE2 then*/
        case 178:

        /** 				opPOKE2()*/
        _67opPOKE2();
        goto L3; // [1147] 1843

        /** 			case POKE4 then*/
        case 138:

        /** 				opPOKE4()*/
        _67opPOKE4();
        goto L3; // [1157] 1843

        /** 			case POSITION then*/
        case 60:

        /** 				opPOSITION()*/
        _67opPOSITION();
        goto L3; // [1167] 1843

        /** 			case POWER then*/
        case 72:

        /** 				opPOWER()*/
        _67opPOWER();
        goto L3; // [1177] 1843

        /** 			case PREPEND then*/
        case 57:

        /** 				opPREPEND()*/
        _67opPREPEND();
        goto L3; // [1187] 1843

        /** 			case PRINT then*/
        case 19:

        /** 				opPRINT()*/
        _67opPRINT();
        goto L3; // [1197] 1843

        /** 			case PRINTF then*/
        case 38:

        /** 				opPRINTF()*/
        _67opPRINTF();
        goto L3; // [1207] 1843

        /** 			case PROC_TAIL then*/
        case 203:

        /** 				opPROC_TAIL()*/
        _67opPROC_TAIL();
        goto L3; // [1217] 1843

        /** 			case PROC then*/
        case 27:

        /** 				opPROC()*/
        _67opPROC();
        goto L3; // [1227] 1843

        /** 			case PROFILE, DISPLAY_VAR, ERASE_PRIVATE_NAMES, ERASE_SYMBOL then*/
        case 151:
        case 87:
        case 88:
        case 90:

        /** 				opPROFILE()*/
        _67opPROFILE();
        goto L3; // [1243] 1843

        /** 			case PUTS then*/
        case 44:

        /** 				opPUTS()*/
        _67opPUTS();
        goto L3; // [1253] 1843

        /** 			case QPRINT then*/
        case 36:

        /** 				opQPRINT()*/
        _67opQPRINT();
        goto L3; // [1263] 1843

        /** 			case RAND then*/
        case 62:

        /** 				opRAND()*/
        _67opRAND();
        goto L3; // [1273] 1843

        /** 			case REMAINDER then*/
        case 71:

        /** 				opREMAINDER()*/
        _67opREMAINDER();
        goto L3; // [1283] 1843

        /** 			case REMOVE then*/
        case 200:

        /** 				opREMOVE()*/
        _67opREMOVE();
        goto L3; // [1293] 1843

        /** 			case REPEAT then*/
        case 32:

        /** 				opREPEAT()*/
        _67opREPEAT();
        goto L3; // [1303] 1843

        /** 			case REPLACE then*/
        case 201:

        /** 				opREPLACE()*/
        _67opREPLACE();
        goto L3; // [1313] 1843

        /** 			case RETURNF then*/
        case 28:

        /** 				opRETURNF()*/
        _67opRETURNF();
        goto L3; // [1323] 1843

        /** 			case RETURNP then*/
        case 29:

        /** 				opRETURNP()*/
        _67opRETURNP();
        goto L3; // [1333] 1843

        /** 			case RETURNT then*/
        case 34:

        /** 				opRETURNT()*/
        _67opRETURNT();
        goto L3; // [1343] 1843

        /** 			case RHS_SLICE then*/
        case 46:

        /** 				opRHS_SLICE()*/
        _67opRHS_SLICE();
        goto L3; // [1353] 1843

        /** 			case RHS_SUBS, RHS_SUBS_CHECK, RHS_SUBS_I then*/
        case 25:
        case 92:
        case 114:

        /** 				opRHS_SUBS()*/
        _67opRHS_SUBS();
        goto L3; // [1367] 1843

        /** 			case RIGHT_BRACE_2 then*/
        case 85:

        /** 				opRIGHT_BRACE_2()*/
        _67opRIGHT_BRACE_2();
        goto L3; // [1377] 1843

        /** 			case RIGHT_BRACE_N then*/
        case 31:

        /** 				opRIGHT_BRACE_N()*/
        _67opRIGHT_BRACE_N();
        goto L3; // [1387] 1843

        /** 			case ROUTINE_ID then*/
        case 134:

        /** 				opROUTINE_ID()*/
        _67opROUTINE_ID();
        goto L3; // [1397] 1843

        /** 			case SC1_AND then*/
        case 141:

        /** 				opSC1_AND()*/
        _67opSC1_AND();
        goto L3; // [1407] 1843

        /** 			case SC1_AND_IF then*/
        case 146:

        /** 				opSC1_AND_IF()*/
        _67opSC1_AND_IF();
        goto L3; // [1417] 1843

        /** 			case SC1_OR then*/
        case 143:

        /** 				opSC1_OR()*/
        _67opSC1_OR();
        goto L3; // [1427] 1843

        /** 			case SC1_OR_IF then*/
        case 147:

        /** 				opSC1_OR_IF()*/
        _67opSC1_OR_IF();
        goto L3; // [1437] 1843

        /** 			case SC2_OR, SC2_AND then*/
        case 144:
        case 142:

        /** 				opSC2_OR()*/
        _67opSC2_OR();
        goto L3; // [1449] 1843

        /** 			case SEQUENCE_CHECK then*/
        case 97:

        /** 				opSEQUENCE_CHECK()*/
        _67opSEQUENCE_CHECK();
        goto L3; // [1459] 1843

        /** 			case SIN then*/
        case 80:

        /** 				opSIN()*/
        _67opSIN();
        goto L3; // [1469] 1843

        /** 			case SPACE_USED then*/
        case 75:

        /** 				opSPACE_USED()*/
        _67opSPACE_USED();
        goto L3; // [1479] 1843

        /** 			case SPLICE then*/
        case 190:

        /** 				opSPLICE()*/
        _67opSPLICE();
        goto L3; // [1489] 1843

        /** 			case SPRINTF then*/
        case 53:

        /** 				opSPRINTF()*/
        _67opSPRINTF();
        goto L3; // [1499] 1843

        /** 			case SQRT then*/
        case 41:

        /** 				opSQRT()*/
        _67opSQRT();
        goto L3; // [1509] 1843

        /** 			case STARTLINE then*/
        case 58:

        /** 				opSTARTLINE()*/
        _67opSTARTLINE();
        goto L3; // [1519] 1843

        /** 			case SWITCH, SWITCH_I then*/
        case 185:
        case 193:

        /** 				opSWITCH()*/
        _67opSWITCH();
        goto L3; // [1531] 1843

        /** 			case SWITCH_SPI then*/
        case 192:

        /** 				opSWITCH_SPI()*/
        _67opSWITCH_SPI();
        goto L3; // [1541] 1843

        /** 			case SWITCH_RT then*/
        case 202:

        /** 				opSWITCH_RT()*/
        _67opSWITCH_RT();
        goto L3; // [1551] 1843

        /** 			case SYSTEM then*/
        case 99:

        /** 				opSYSTEM()*/
        _67opSYSTEM();
        goto L3; // [1561] 1843

        /** 			case SYSTEM_EXEC then*/
        case 154:

        /** 				opSYSTEM_EXEC()*/
        _67opSYSTEM_EXEC();
        goto L3; // [1571] 1843

        /** 			case TAIL then*/
        case 199:

        /** 				opTAIL()*/
        _67opTAIL();
        goto L3; // [1581] 1843

        /** 			case TAN then*/
        case 82:

        /** 				opTAN()*/
        _67opTAN();
        goto L3; // [1591] 1843

        /** 			case TASK_CLOCK_START then*/
        case 175:

        /** 				opTASK_CLOCK_START()*/
        _67opTASK_CLOCK_START();
        goto L3; // [1601] 1843

        /** 			case TASK_CLOCK_STOP then*/
        case 174:

        /** 				opTASK_CLOCK_STOP()*/
        _67opTASK_CLOCK_STOP();
        goto L3; // [1611] 1843

        /** 			case TASK_CREATE then*/
        case 167:

        /** 				opTASK_CREATE()*/
        _67opTASK_CREATE();
        goto L3; // [1621] 1843

        /** 			case TASK_LIST then*/
        case 172:

        /** 				opTASK_LIST()*/
        _67opTASK_LIST();
        goto L3; // [1631] 1843

        /** 			case TASK_SCHEDULE then*/
        case 168:

        /** 				opTASK_SCHEDULE()*/
        _67opTASK_SCHEDULE();
        goto L3; // [1641] 1843

        /** 			case TASK_SELF then*/
        case 170:

        /** 				opTASK_SELF()*/
        _67opTASK_SELF();
        goto L3; // [1651] 1843

        /** 			case TASK_STATUS then*/
        case 173:

        /** 				opTASK_STATUS()*/
        _67opTASK_STATUS();
        goto L3; // [1661] 1843

        /** 			case TASK_SUSPEND then*/
        case 171:

        /** 				opTASK_SUSPEND()*/
        _67opTASK_SUSPEND();
        goto L3; // [1671] 1843

        /** 			case TASK_YIELD then*/
        case 169:

        /** 				opTASK_YIELD()*/
        _67opTASK_YIELD();
        goto L3; // [1681] 1843

        /** 			case TIME then*/
        case 70:

        /** 				opTIME()*/
        _67opTIME();
        goto L3; // [1691] 1843

        /** 			case TRACE then*/
        case 64:

        /** 				opTRACE()*/
        _67opTRACE();
        goto L3; // [1701] 1843

        /** 			case TYPE_CHECK then*/
        case 65:

        /** 				opTYPE_CHECK()*/
        _67opTYPE_CHECK();
        goto L3; // [1711] 1843

        /** 			case UMINUS then*/
        case 12:

        /** 				opUMINUS()*/
        _67opUMINUS();
        goto L3; // [1721] 1843

        /** 			case UPDATE_GLOBALS then*/
        case 89:

        /** 				opUPDATE_GLOBALS()*/
        _67opUPDATE_GLOBALS();
        goto L3; // [1731] 1843

        /** 			case WHILE then*/
        case 47:

        /** 				opWHILE()*/
        _67opWHILE();
        goto L3; // [1741] 1843

        /** 			case XOR then*/
        case 152:

        /** 				opXOR()*/
        _67opXOR();
        goto L3; // [1751] 1843

        /** 			case XOR_BITS then*/
        case 26:

        /** 				opXOR_BITS()*/
        _67opXOR_BITS();
        goto L3; // [1761] 1843

        /** 			case DELETE_ROUTINE then*/
        case 204:

        /** 				opDELETE_ROUTINE()*/
        _67opDELETE_ROUTINE();
        goto L3; // [1771] 1843

        /** 			case DELETE_OBJECT then*/
        case 205:

        /** 				opDELETE_OBJECT()*/
        _67opDELETE_OBJECT();
        goto L3; // [1781] 1843

        /** 			case REF_TEMP then*/
        case 207:

        /** 				pc += 2*/
        _67pc_63008 = _67pc_63008 + 2;
        goto L3; // [1795] 1843

        /** 			case DEREF_TEMP, NOVALUE_TEMP then*/
        case 208:
        case 209:

        /** 				opDEREF_TEMP()*/
        _67opDEREF_TEMP();
        goto L3; // [1807] 1843

        /** 			case COVERAGE_LINE then*/
        case 210:

        /** 				opCOVERAGE_LINE()*/
        _67opCOVERAGE_LINE();
        goto L3; // [1817] 1843

        /** 			case COVERAGE_ROUTINE then*/
        case 211:

        /** 				opCOVERAGE_ROUTINE()*/
        _67opCOVERAGE_ROUTINE();
        goto L3; // [1827] 1843

        /** 			case else*/
        default:

        /** 				RTFatal( sprintf("Unknown opcode: %d", op ) )*/
        _34547 = EPrintf(-9999999, _34546, _op_68143);
        _67RTFatal(_34547);
        _34547 = NOVALUE;
    ;}L3: 

    /** 	end while*/
    goto L1; // [1847] 15
L2: 

    /** 	keep_running = TRUE -- so higher-level do_exec() will keep running*/
    _67keep_running_63015 = _9TRUE_431;

    /** end procedure*/
    return;
    ;
}


void _67InitBackEnd()
{
    int _name_68536 = NOVALUE;
    int _34553 = NOVALUE;
    int _34552 = NOVALUE;
    int _34551 = NOVALUE;
    int _34550 = NOVALUE;
    int _34548 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	val = repeat(0, length(SymTab))*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _34548 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _34548 = 1;
    }
    DeRef(_67val_63018);
    _67val_63018 = Repeat(0, _34548);
    _34548 = NOVALUE;

    /** 	for i = 1 to length(SymTab) do*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _34550 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _34550 = 1;
    }
    {
        int _i_68541;
        _i_68541 = 1;
L1: 
        if (_i_68541 > _34550){
            goto L2; // [19] 68
        }

        /** 		val[i] = SymTab[i][S_OBJ] -- might be NOVALUE*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _34551 = (int)*(((s1_ptr)_2)->base + _i_68541);
        _2 = (int)SEQ_PTR(_34551);
        _34552 = (int)*(((s1_ptr)_2)->base + 1);
        _34551 = NOVALUE;
        Ref(_34552);
        _2 = (int)SEQ_PTR(_67val_63018);
        _2 = (int)(((s1_ptr)_2)->base + _i_68541);
        _1 = *(int *)_2;
        *(int *)_2 = _34552;
        if( _1 != _34552 ){
            DeRef(_1);
        }
        _34552 = NOVALUE;

        /** 		SymTab[i][S_OBJ] = 0*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_68541 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _34553 = NOVALUE;

        /** 	end for*/
        _i_68541 = _i_68541 + 1;
        goto L1; // [63] 26
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _67fake_init(int _ignore_68554)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ignore_68554)) {
        _1 = (long)(DBL_PTR(_ignore_68554)->dbl);
        DeRefDS(_ignore_68554);
        _ignore_68554 = _1;
    }

    /** 	intoptions()*/
    _68intoptions();

    /** end procedure*/
    return;
    ;
}


void _67Execute(int _proc_68563, int _start_index_68564)
{
    int _34558 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_proc_68563)) {
        _1 = (long)(DBL_PTR(_proc_68563)->dbl);
        DeRefDS(_proc_68563);
        _proc_68563 = _1;
    }
    if (!IS_ATOM_INT(_start_index_68564)) {
        _1 = (long)(DBL_PTR(_start_index_68564)->dbl);
        DeRefDS(_start_index_68564);
        _start_index_68564 = _1;
    }

    /** 	InitBackEnd()*/
    _67InitBackEnd();

    /** 	current_task = 1*/
    _67current_task_63025 = 1;

    /** 	call_stack = {proc}*/
    _0 = _67call_stack_63026;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _proc_68563;
    _67call_stack_63026 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 	pc = start_index*/
    _67pc_63008 = _start_index_68564;

    /** 	Code = SymTab[proc][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _34558 = (int)*(((s1_ptr)_2)->base + _proc_68563);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_34558);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _34558 = NOVALUE;

    /** 	do_exec()*/
    _67do_exec();

    /** end procedure*/
    return;
    ;
}


void _67BackEnd(int _ignore_68576)
{
    int _0, _1, _2;
    

    /** 	Execute(TopLevelSub, 1)*/
    _67Execute(_12TopLevelSub_11689, 1);

    /** end procedure*/
    return;
    ;
}


void _67OutputIL()
{
    int _0, _1, _2;
    

    /** end procedure*/
    return;
    ;
}


int _67extract_options(int _s_68585)
{
    int _0, _1, _2;
    

    /** 	return s*/
    return _s_68585;
    ;
}



// 0x58F701F8
