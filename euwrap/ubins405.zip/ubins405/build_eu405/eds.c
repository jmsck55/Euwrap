// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _48fatal(int _errcode_17082, int _msg_17083, int _routine_name_17084, int _parms_17085)
{
    int _9692 = NOVALUE;
    int _0, _1, _2;
    

    /** 	vLastErrors = append(vLastErrors, {errcode, msg, routine_name, parms})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _errcode_17082;
    RefDS(_msg_17083);
    *((int *)(_2+8)) = _msg_17083;
    RefDS(_routine_name_17084);
    *((int *)(_2+12)) = _routine_name_17084;
    RefDS(_parms_17085);
    *((int *)(_2+16)) = _parms_17085;
    _9692 = MAKE_SEQ(_1);
    RefDS(_9692);
    Append(&_48vLastErrors_17079, _48vLastErrors_17079, _9692);
    DeRefDS(_9692);
    _9692 = NOVALUE;

    /** 	if db_fatal_id >= 0 then*/

    /** end procedure*/
    DeRefDSi(_msg_17083);
    DeRefDSi(_routine_name_17084);
    DeRefDS(_parms_17085);
    return;
    ;
}


int _48get4()
{
    int _9708 = NOVALUE;
    int _9707 = NOVALUE;
    int _9706 = NOVALUE;
    int _9705 = NOVALUE;
    int _9704 = NOVALUE;
    int _0, _1, _2;
    

    /** 	poke(mem0, getc(current_db))*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9704 = getc((FILE*)xstdin);
        }
        else
        _9704 = getc(last_r_file_ptr);
    }
    else
    _9704 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem0_17097)){
        poke_addr = (unsigned char *)_48mem0_17097;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke_addr = (unsigned char)_9704;
    _9704 = NOVALUE;

    /** 	poke(mem1, getc(current_db))*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9705 = getc((FILE*)xstdin);
        }
        else
        _9705 = getc(last_r_file_ptr);
    }
    else
    _9705 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem1_17098)){
        poke_addr = (unsigned char *)_48mem1_17098;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem1_17098)->dbl);
    }
    *poke_addr = (unsigned char)_9705;
    _9705 = NOVALUE;

    /** 	poke(mem2, getc(current_db))*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9706 = getc((FILE*)xstdin);
        }
        else
        _9706 = getc(last_r_file_ptr);
    }
    else
    _9706 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem2_17099)){
        poke_addr = (unsigned char *)_48mem2_17099;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem2_17099)->dbl);
    }
    *poke_addr = (unsigned char)_9706;
    _9706 = NOVALUE;

    /** 	poke(mem3, getc(current_db))*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _9707 = getc((FILE*)xstdin);
        }
        else
        _9707 = getc(last_r_file_ptr);
    }
    else
    _9707 = getc(last_r_file_ptr);
    if (IS_ATOM_INT(_48mem3_17100)){
        poke_addr = (unsigned char *)_48mem3_17100;
    }
    else {
        poke_addr = (unsigned char *)(unsigned long)(DBL_PTR(_48mem3_17100)->dbl);
    }
    *poke_addr = (unsigned char)_9707;
    _9707 = NOVALUE;

    /** 	return peek4u(mem0)*/
    if (IS_ATOM_INT(_48mem0_17097)) {
        _9708 = *(unsigned long *)_48mem0_17097;
        if ((unsigned)_9708 > (unsigned)MAXINT)
        _9708 = NewDouble((double)(unsigned long)_9708);
    }
    else {
        _9708 = *(unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        if ((unsigned)_9708 > (unsigned)MAXINT)
        _9708 = NewDouble((double)(unsigned long)_9708);
    }
    return _9708;
    ;
}


int _48get_string()
{
    int _where_inlined_where_at_31_17125 = NOVALUE;
    int _s_17114 = NOVALUE;
    int _c_17115 = NOVALUE;
    int _i_17116 = NOVALUE;
    int _9721 = NOVALUE;
    int _9718 = NOVALUE;
    int _9716 = NOVALUE;
    int _9714 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = repeat(0, 256)*/
    DeRefi(_s_17114);
    _s_17114 = Repeat(0, 256);

    /** 	i = 0*/
    _i_17116 = 0;

    /** 	while c with entry do*/
    goto L1; // [14] 89
L2: 
    if (_c_17115 == 0)
    {
        goto L3; // [19] 101
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17115 != -1)
    goto L4; // [24] 54

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "get_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_31_17125);
    _where_inlined_where_at_31_17125 = machine(20, _48current_db_17055);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_31_17125);
    *((int *)(_2+4)) = _where_inlined_where_at_31_17125;
    _9714 = MAKE_SEQ(_1);
    RefDS(_9712);
    RefDS(_9713);
    _48fatal(900, _9712, _9713, _9714);
    _9714 = NOVALUE;

    /** 			exit*/
    goto L3; // [51] 101
L4: 

    /** 		i += 1*/
    _i_17116 = _i_17116 + 1;

    /** 		if i > length(s) then*/
    if (IS_SEQUENCE(_s_17114)){
            _9716 = SEQ_PTR(_s_17114)->length;
    }
    else {
        _9716 = 1;
    }
    if (_i_17116 <= _9716)
    goto L5; // [65] 80

    /** 			s &= repeat(0, 256)*/
    _9718 = Repeat(0, 256);
    Concat((object_ptr)&_s_17114, _s_17114, _9718);
    DeRefDS(_9718);
    _9718 = NOVALUE;
L5: 

    /** 		s[i] = c*/
    _2 = (int)SEQ_PTR(_s_17114);
    _2 = (int)(((s1_ptr)_2)->base + _i_17116);
    *(int *)_2 = _c_17115;

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17115 = getc((FILE*)xstdin);
        }
        else
        _c_17115 = getc(last_r_file_ptr);
    }
    else
    _c_17115 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [98] 17
L3: 

    /** 	return s[1..i]*/
    rhs_slice_target = (object_ptr)&_9721;
    RHS_Slice(_s_17114, 1, _i_17116);
    DeRefDSi(_s_17114);
    return _9721;
    ;
}


int _48equal_string(int _target_17137)
{
    int _c_17138 = NOVALUE;
    int _i_17139 = NOVALUE;
    int _where_inlined_where_at_27_17145 = NOVALUE;
    int _9732 = NOVALUE;
    int _9731 = NOVALUE;
    int _9728 = NOVALUE;
    int _9726 = NOVALUE;
    int _9724 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = 0*/
    _i_17139 = 0;

    /** 	while c with entry do*/
    goto L1; // [10] 94
L2: 
    if (_c_17138 == 0)
    {
        goto L3; // [15] 106
    }
    else{
    }

    /** 		if c = -1 then*/
    if (_c_17138 != -1)
    goto L4; // [20] 52

    /** 			fatal(MISSING_END, "string is missing 0 terminator", "equal_string", {io:where(current_db)})*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_27_17145);
    _where_inlined_where_at_27_17145 = machine(20, _48current_db_17055);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_where_inlined_where_at_27_17145);
    *((int *)(_2+4)) = _where_inlined_where_at_27_17145;
    _9724 = MAKE_SEQ(_1);
    RefDS(_9712);
    RefDS(_9723);
    _48fatal(900, _9712, _9723, _9724);
    _9724 = NOVALUE;

    /** 			return DB_FATAL_FAIL*/
    DeRefDS(_target_17137);
    return -404;
L4: 

    /** 		i += 1*/
    _i_17139 = _i_17139 + 1;

    /** 		if i > length(target) then*/
    if (IS_SEQUENCE(_target_17137)){
            _9726 = SEQ_PTR(_target_17137)->length;
    }
    else {
        _9726 = 1;
    }
    if (_i_17139 <= _9726)
    goto L5; // [63] 74

    /** 			return 0*/
    DeRefDS(_target_17137);
    return 0;
L5: 

    /** 		if target[i] != c then*/
    _2 = (int)SEQ_PTR(_target_17137);
    _9728 = (int)*(((s1_ptr)_2)->base + _i_17139);
    if (binary_op_a(EQUALS, _9728, _c_17138)){
        _9728 = NOVALUE;
        goto L6; // [80] 91
    }
    _9728 = NOVALUE;

    /** 			return 0*/
    DeRefDS(_target_17137);
    return 0;
L6: 

    /** 	  entry*/
L1: 

    /** 		c = getc(current_db)*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17138 = getc((FILE*)xstdin);
        }
        else
        _c_17138 = getc(last_r_file_ptr);
    }
    else
    _c_17138 = getc(last_r_file_ptr);

    /** 	end while*/
    goto L2; // [103] 13
L3: 

    /** 	return (i = length(target))*/
    if (IS_SEQUENCE(_target_17137)){
            _9731 = SEQ_PTR(_target_17137)->length;
    }
    else {
        _9731 = 1;
    }
    _9732 = (_i_17139 == _9731);
    _9731 = NOVALUE;
    DeRefDS(_target_17137);
    return _9732;
    ;
}


int _48decompress(int _c_17196)
{
    int _s_17197 = NOVALUE;
    int _len_17198 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_176_17234 = NOVALUE;
    int _ieee32_inlined_float32_to_atom_at_173_17233 = NOVALUE;
    int _float64_to_atom_inlined_float64_to_atom_at_251_17247 = NOVALUE;
    int _ieee64_inlined_float64_to_atom_at_248_17246 = NOVALUE;
    int _9801 = NOVALUE;
    int _9800 = NOVALUE;
    int _9799 = NOVALUE;
    int _9796 = NOVALUE;
    int _9791 = NOVALUE;
    int _9790 = NOVALUE;
    int _9789 = NOVALUE;
    int _9788 = NOVALUE;
    int _9787 = NOVALUE;
    int _9786 = NOVALUE;
    int _9785 = NOVALUE;
    int _9784 = NOVALUE;
    int _9783 = NOVALUE;
    int _9782 = NOVALUE;
    int _9781 = NOVALUE;
    int _9780 = NOVALUE;
    int _9779 = NOVALUE;
    int _9778 = NOVALUE;
    int _9777 = NOVALUE;
    int _9776 = NOVALUE;
    int _9775 = NOVALUE;
    int _9774 = NOVALUE;
    int _9773 = NOVALUE;
    int _9772 = NOVALUE;
    int _9770 = NOVALUE;
    int _9769 = NOVALUE;
    int _9768 = NOVALUE;
    int _9767 = NOVALUE;
    int _9766 = NOVALUE;
    int _9765 = NOVALUE;
    int _9764 = NOVALUE;
    int _9763 = NOVALUE;
    int _9762 = NOVALUE;
    int _9759 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if c = 0 then*/
    if (_c_17196 != 0)
    goto L1; // [5] 34

    /** 		c = getc(current_db)*/
    if (_48current_db_17055 != last_r_file_no) {
        last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
        last_r_file_no = _48current_db_17055;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _c_17196 = getc((FILE*)xstdin);
        }
        else
        _c_17196 = getc(last_r_file_ptr);
    }
    else
    _c_17196 = getc(last_r_file_ptr);

    /** 		if c < I2B then*/
    if (_c_17196 >= 249)
    goto L2; // [18] 33

    /** 			return c + MIN1B*/
    _9759 = _c_17196 + -9;
    DeRef(_s_17197);
    return _9759;
L2: 
L1: 

    /** 	switch c with fallthru do*/
    _0 = _c_17196;
    switch ( _0 ){ 

        /** 		case I2B then*/
        case 249:

        /** 			return getc(current_db) +*/
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9762 = getc((FILE*)xstdin);
            }
            else
            _9762 = getc(last_r_file_ptr);
        }
        else
        _9762 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9763 = getc((FILE*)xstdin);
            }
            else
            _9763 = getc(last_r_file_ptr);
        }
        else
        _9763 = getc(last_r_file_ptr);
        _9764 = 256 * _9763;
        _9763 = NOVALUE;
        _9765 = _9762 + _9764;
        _9762 = NOVALUE;
        _9764 = NOVALUE;
        _9766 = _9765 + _48MIN2B_17176;
        if ((long)((unsigned long)_9766 + (unsigned long)HIGH_BITS) >= 0) 
        _9766 = NewDouble((double)_9766);
        _9765 = NOVALUE;
        DeRef(_s_17197);
        DeRef(_9759);
        _9759 = NOVALUE;
        return _9766;

        /** 		case I3B then*/
        case 250:

        /** 			return getc(current_db) +*/
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9767 = getc((FILE*)xstdin);
            }
            else
            _9767 = getc(last_r_file_ptr);
        }
        else
        _9767 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9768 = getc((FILE*)xstdin);
            }
            else
            _9768 = getc(last_r_file_ptr);
        }
        else
        _9768 = getc(last_r_file_ptr);
        _9769 = 256 * _9768;
        _9768 = NOVALUE;
        _9770 = _9767 + _9769;
        _9767 = NOVALUE;
        _9769 = NOVALUE;
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9772 = getc((FILE*)xstdin);
            }
            else
            _9772 = getc(last_r_file_ptr);
        }
        else
        _9772 = getc(last_r_file_ptr);
        _9773 = 65536 * _9772;
        _9772 = NOVALUE;
        _9774 = _9770 + _9773;
        _9770 = NOVALUE;
        _9773 = NOVALUE;
        _9775 = _9774 + _48MIN3B_17183;
        if ((long)((unsigned long)_9775 + (unsigned long)HIGH_BITS) >= 0) 
        _9775 = NewDouble((double)_9775);
        _9774 = NOVALUE;
        DeRef(_s_17197);
        DeRef(_9759);
        _9759 = NOVALUE;
        DeRef(_9766);
        _9766 = NOVALUE;
        return _9775;

        /** 		case I4B then*/
        case 251:

        /** 			return get4() + MIN4B*/
        _9776 = _48get4();
        if (IS_ATOM_INT(_9776) && IS_ATOM_INT(_48MIN4B_17190)) {
            _9777 = _9776 + _48MIN4B_17190;
            if ((long)((unsigned long)_9777 + (unsigned long)HIGH_BITS) >= 0) 
            _9777 = NewDouble((double)_9777);
        }
        else {
            _9777 = binary_op(PLUS, _9776, _48MIN4B_17190);
        }
        DeRef(_9776);
        _9776 = NOVALUE;
        DeRef(_s_17197);
        DeRef(_9759);
        _9759 = NOVALUE;
        DeRef(_9766);
        _9766 = NOVALUE;
        DeRef(_9775);
        _9775 = NOVALUE;
        return _9777;

        /** 		case F4B then*/
        case 252:

        /** 			return convert:float32_to_atom({getc(current_db), getc(current_db),*/
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9778 = getc((FILE*)xstdin);
            }
            else
            _9778 = getc(last_r_file_ptr);
        }
        else
        _9778 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9779 = getc((FILE*)xstdin);
            }
            else
            _9779 = getc(last_r_file_ptr);
        }
        else
        _9779 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9780 = getc((FILE*)xstdin);
            }
            else
            _9780 = getc(last_r_file_ptr);
        }
        else
        _9780 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9781 = getc((FILE*)xstdin);
            }
            else
            _9781 = getc(last_r_file_ptr);
        }
        else
        _9781 = getc(last_r_file_ptr);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9778;
        *((int *)(_2+8)) = _9779;
        *((int *)(_2+12)) = _9780;
        *((int *)(_2+16)) = _9781;
        _9782 = MAKE_SEQ(_1);
        _9781 = NOVALUE;
        _9780 = NOVALUE;
        _9779 = NOVALUE;
        _9778 = NOVALUE;
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17233);
        _ieee32_inlined_float32_to_atom_at_173_17233 = _9782;
        _9782 = NOVALUE;

        /** 	return machine_func(M_F32_TO_A, ieee32)*/
        DeRef(_float32_to_atom_inlined_float32_to_atom_at_176_17234);
        _float32_to_atom_inlined_float32_to_atom_at_176_17234 = machine(49, _ieee32_inlined_float32_to_atom_at_173_17233);
        DeRefi(_ieee32_inlined_float32_to_atom_at_173_17233);
        _ieee32_inlined_float32_to_atom_at_173_17233 = NOVALUE;
        DeRef(_s_17197);
        DeRef(_9759);
        _9759 = NOVALUE;
        DeRef(_9766);
        _9766 = NOVALUE;
        DeRef(_9775);
        _9775 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        return _float32_to_atom_inlined_float32_to_atom_at_176_17234;

        /** 		case F8B then*/
        case 253:

        /** 			return convert:float64_to_atom({getc(current_db), getc(current_db),*/
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9783 = getc((FILE*)xstdin);
            }
            else
            _9783 = getc(last_r_file_ptr);
        }
        else
        _9783 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9784 = getc((FILE*)xstdin);
            }
            else
            _9784 = getc(last_r_file_ptr);
        }
        else
        _9784 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9785 = getc((FILE*)xstdin);
            }
            else
            _9785 = getc(last_r_file_ptr);
        }
        else
        _9785 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9786 = getc((FILE*)xstdin);
            }
            else
            _9786 = getc(last_r_file_ptr);
        }
        else
        _9786 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9787 = getc((FILE*)xstdin);
            }
            else
            _9787 = getc(last_r_file_ptr);
        }
        else
        _9787 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9788 = getc((FILE*)xstdin);
            }
            else
            _9788 = getc(last_r_file_ptr);
        }
        else
        _9788 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9789 = getc((FILE*)xstdin);
            }
            else
            _9789 = getc(last_r_file_ptr);
        }
        else
        _9789 = getc(last_r_file_ptr);
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _9790 = getc((FILE*)xstdin);
            }
            else
            _9790 = getc(last_r_file_ptr);
        }
        else
        _9790 = getc(last_r_file_ptr);
        _1 = NewS1(8);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _9783;
        *((int *)(_2+8)) = _9784;
        *((int *)(_2+12)) = _9785;
        *((int *)(_2+16)) = _9786;
        *((int *)(_2+20)) = _9787;
        *((int *)(_2+24)) = _9788;
        *((int *)(_2+28)) = _9789;
        *((int *)(_2+32)) = _9790;
        _9791 = MAKE_SEQ(_1);
        _9790 = NOVALUE;
        _9789 = NOVALUE;
        _9788 = NOVALUE;
        _9787 = NOVALUE;
        _9786 = NOVALUE;
        _9785 = NOVALUE;
        _9784 = NOVALUE;
        _9783 = NOVALUE;
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17246);
        _ieee64_inlined_float64_to_atom_at_248_17246 = _9791;
        _9791 = NOVALUE;

        /** 	return machine_func(M_F64_TO_A, ieee64)*/
        DeRef(_float64_to_atom_inlined_float64_to_atom_at_251_17247);
        _float64_to_atom_inlined_float64_to_atom_at_251_17247 = machine(47, _ieee64_inlined_float64_to_atom_at_248_17246);
        DeRefi(_ieee64_inlined_float64_to_atom_at_248_17246);
        _ieee64_inlined_float64_to_atom_at_248_17246 = NOVALUE;
        DeRef(_s_17197);
        DeRef(_9759);
        _9759 = NOVALUE;
        DeRef(_9766);
        _9766 = NOVALUE;
        DeRef(_9775);
        _9775 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        return _float64_to_atom_inlined_float64_to_atom_at_251_17247;

        /** 		case else*/
        default:

        /** 			if c = S1B then*/
        if (_c_17196 != 254)
        goto L3; // [273] 287

        /** 				len = getc(current_db)*/
        if (_48current_db_17055 != last_r_file_no) {
            last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
            last_r_file_no = _48current_db_17055;
        }
        if (last_r_file_ptr == xstdin) {
            if (in_from_keyb) {
                _len_17198 = getc((FILE*)xstdin);
            }
            else
            _len_17198 = getc(last_r_file_ptr);
        }
        else
        _len_17198 = getc(last_r_file_ptr);
        goto L4; // [284] 295
L3: 

        /** 				len = get4()*/
        _len_17198 = _48get4();
        if (!IS_ATOM_INT(_len_17198)) {
            _1 = (long)(DBL_PTR(_len_17198)->dbl);
            DeRefDS(_len_17198);
            _len_17198 = _1;
        }
L4: 

        /** 			s = repeat(0, len)*/
        DeRef(_s_17197);
        _s_17197 = Repeat(0, _len_17198);

        /** 			for i = 1 to len do*/
        _9796 = _len_17198;
        {
            int _i_17256;
            _i_17256 = 1;
L5: 
            if (_i_17256 > _9796){
                goto L6; // [308] 362
            }

            /** 				c = getc(current_db)*/
            if (_48current_db_17055 != last_r_file_no) {
                last_r_file_ptr = which_file(_48current_db_17055, EF_READ);
                last_r_file_no = _48current_db_17055;
            }
            if (last_r_file_ptr == xstdin) {
                if (in_from_keyb) {
                    _c_17196 = getc((FILE*)xstdin);
                }
                else
                _c_17196 = getc(last_r_file_ptr);
            }
            else
            _c_17196 = getc(last_r_file_ptr);

            /** 				if c < I2B then*/
            if (_c_17196 >= 249)
            goto L7; // [324] 341

            /** 					s[i] = c + MIN1B*/
            _9799 = _c_17196 + -9;
            _2 = (int)SEQ_PTR(_s_17197);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17197 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17256);
            _1 = *(int *)_2;
            *(int *)_2 = _9799;
            if( _1 != _9799 ){
                DeRef(_1);
            }
            _9799 = NOVALUE;
            goto L8; // [338] 355
L7: 

            /** 					s[i] = decompress(c)*/
            DeRef(_9800);
            _9800 = _c_17196;
            _9801 = _48decompress(_9800);
            _9800 = NOVALUE;
            _2 = (int)SEQ_PTR(_s_17197);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _s_17197 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _i_17256);
            _1 = *(int *)_2;
            *(int *)_2 = _9801;
            if( _1 != _9801 ){
                DeRef(_1);
            }
            _9801 = NOVALUE;
L8: 

            /** 			end for*/
            _i_17256 = _i_17256 + 1;
            goto L5; // [357] 315
L6: 
            ;
        }

        /** 			return s*/
        DeRef(_9759);
        _9759 = NOVALUE;
        DeRef(_9766);
        _9766 = NOVALUE;
        DeRef(_9775);
        _9775 = NOVALUE;
        DeRef(_9777);
        _9777 = NOVALUE;
        return _s_17197;
    ;}    ;
}


int _48compress(int _x_17267)
{
    int _x4_17268 = NOVALUE;
    int _s_17269 = NOVALUE;
    int _atom_to_float32_inlined_atom_to_float32_at_192_17303 = NOVALUE;
    int _float32_to_atom_inlined_float32_to_atom_at_203_17306 = NOVALUE;
    int _atom_to_float64_inlined_atom_to_float64_at_229_17311 = NOVALUE;
    int _9840 = NOVALUE;
    int _9839 = NOVALUE;
    int _9838 = NOVALUE;
    int _9836 = NOVALUE;
    int _9835 = NOVALUE;
    int _9833 = NOVALUE;
    int _9831 = NOVALUE;
    int _9830 = NOVALUE;
    int _9829 = NOVALUE;
    int _9827 = NOVALUE;
    int _9826 = NOVALUE;
    int _9825 = NOVALUE;
    int _9824 = NOVALUE;
    int _9823 = NOVALUE;
    int _9822 = NOVALUE;
    int _9821 = NOVALUE;
    int _9820 = NOVALUE;
    int _9819 = NOVALUE;
    int _9817 = NOVALUE;
    int _9816 = NOVALUE;
    int _9815 = NOVALUE;
    int _9814 = NOVALUE;
    int _9813 = NOVALUE;
    int _9812 = NOVALUE;
    int _9810 = NOVALUE;
    int _9809 = NOVALUE;
    int _9808 = NOVALUE;
    int _9807 = NOVALUE;
    int _9806 = NOVALUE;
    int _9805 = NOVALUE;
    int _9804 = NOVALUE;
    int _9803 = NOVALUE;
    int _9802 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if integer(x) then*/
    if (IS_ATOM_INT(_x_17267))
    _9802 = 1;
    else if (IS_ATOM_DBL(_x_17267))
    _9802 = IS_ATOM_INT(DoubleToInt(_x_17267));
    else
    _9802 = 0;
    if (_9802 == 0)
    {
        _9802 = NOVALUE;
        goto L1; // [6] 183
    }
    else{
        _9802 = NOVALUE;
    }

    /** 		if x >= MIN1B and x <= MAX1B then*/
    if (IS_ATOM_INT(_x_17267)) {
        _9803 = (_x_17267 >= -9);
    }
    else {
        _9803 = binary_op(GREATEREQ, _x_17267, -9);
    }
    if (IS_ATOM_INT(_9803)) {
        if (_9803 == 0) {
            goto L2; // [15] 44
        }
    }
    else {
        if (DBL_PTR(_9803)->dbl == 0.0) {
            goto L2; // [15] 44
        }
    }
    if (IS_ATOM_INT(_x_17267)) {
        _9805 = (_x_17267 <= 239);
    }
    else {
        _9805 = binary_op(LESSEQ, _x_17267, 239);
    }
    if (_9805 == 0) {
        DeRef(_9805);
        _9805 = NOVALUE;
        goto L2; // [24] 44
    }
    else {
        if (!IS_ATOM_INT(_9805) && DBL_PTR(_9805)->dbl == 0.0){
            DeRef(_9805);
            _9805 = NOVALUE;
            goto L2; // [24] 44
        }
        DeRef(_9805);
        _9805 = NOVALUE;
    }
    DeRef(_9805);
    _9805 = NOVALUE;

    /** 			return {x - MIN1B}*/
    if (IS_ATOM_INT(_x_17267)) {
        _9806 = _x_17267 - -9;
        if ((long)((unsigned long)_9806 +(unsigned long) HIGH_BITS) >= 0){
            _9806 = NewDouble((double)_9806);
        }
    }
    else {
        _9806 = binary_op(MINUS, _x_17267, -9);
    }
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _9806;
    _9807 = MAKE_SEQ(_1);
    _9806 = NOVALUE;
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    return _9807;
    goto L3; // [41] 328
L2: 

    /** 		elsif x >= MIN2B and x <= MAX2B then*/
    if (IS_ATOM_INT(_x_17267)) {
        _9808 = (_x_17267 >= _48MIN2B_17176);
    }
    else {
        _9808 = binary_op(GREATEREQ, _x_17267, _48MIN2B_17176);
    }
    if (IS_ATOM_INT(_9808)) {
        if (_9808 == 0) {
            goto L4; // [52] 97
        }
    }
    else {
        if (DBL_PTR(_9808)->dbl == 0.0) {
            goto L4; // [52] 97
        }
    }
    if (IS_ATOM_INT(_x_17267)) {
        _9810 = (_x_17267 <= 32767);
    }
    else {
        _9810 = binary_op(LESSEQ, _x_17267, 32767);
    }
    if (_9810 == 0) {
        DeRef(_9810);
        _9810 = NOVALUE;
        goto L4; // [63] 97
    }
    else {
        if (!IS_ATOM_INT(_9810) && DBL_PTR(_9810)->dbl == 0.0){
            DeRef(_9810);
            _9810 = NOVALUE;
            goto L4; // [63] 97
        }
        DeRef(_9810);
        _9810 = NOVALUE;
    }
    DeRef(_9810);
    _9810 = NOVALUE;

    /** 			x -= MIN2B*/
    _0 = _x_17267;
    if (IS_ATOM_INT(_x_17267)) {
        _x_17267 = _x_17267 - _48MIN2B_17176;
        if ((long)((unsigned long)_x_17267 +(unsigned long) HIGH_BITS) >= 0){
            _x_17267 = NewDouble((double)_x_17267);
        }
    }
    else {
        _x_17267 = binary_op(MINUS, _x_17267, _48MIN2B_17176);
    }
    DeRef(_0);

    /** 			return {I2B, and_bits(x, #FF), floor(x / #100)}*/
    if (IS_ATOM_INT(_x_17267)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17267 & (unsigned long)255;
             _9812 = MAKE_UINT(tu);
        }
    }
    else {
        _9812 = binary_op(AND_BITS, _x_17267, 255);
    }
    if (IS_ATOM_INT(_x_17267)) {
        if (256 > 0 && _x_17267 >= 0) {
            _9813 = _x_17267 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17267 / (double)256);
            if (_x_17267 != MININT)
            _9813 = (long)temp_dbl;
            else
            _9813 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17267, 256);
        _9813 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 249;
    *((int *)(_2+8)) = _9812;
    *((int *)(_2+12)) = _9813;
    _9814 = MAKE_SEQ(_1);
    _9813 = NOVALUE;
    _9812 = NOVALUE;
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    return _9814;
    goto L3; // [94] 328
L4: 

    /** 		elsif x >= MIN3B and x <= MAX3B then*/
    if (IS_ATOM_INT(_x_17267)) {
        _9815 = (_x_17267 >= _48MIN3B_17183);
    }
    else {
        _9815 = binary_op(GREATEREQ, _x_17267, _48MIN3B_17183);
    }
    if (IS_ATOM_INT(_9815)) {
        if (_9815 == 0) {
            goto L5; // [105] 159
        }
    }
    else {
        if (DBL_PTR(_9815)->dbl == 0.0) {
            goto L5; // [105] 159
        }
    }
    if (IS_ATOM_INT(_x_17267)) {
        _9817 = (_x_17267 <= 8388607);
    }
    else {
        _9817 = binary_op(LESSEQ, _x_17267, 8388607);
    }
    if (_9817 == 0) {
        DeRef(_9817);
        _9817 = NOVALUE;
        goto L5; // [116] 159
    }
    else {
        if (!IS_ATOM_INT(_9817) && DBL_PTR(_9817)->dbl == 0.0){
            DeRef(_9817);
            _9817 = NOVALUE;
            goto L5; // [116] 159
        }
        DeRef(_9817);
        _9817 = NOVALUE;
    }
    DeRef(_9817);
    _9817 = NOVALUE;

    /** 			x -= MIN3B*/
    _0 = _x_17267;
    if (IS_ATOM_INT(_x_17267)) {
        _x_17267 = _x_17267 - _48MIN3B_17183;
        if ((long)((unsigned long)_x_17267 +(unsigned long) HIGH_BITS) >= 0){
            _x_17267 = NewDouble((double)_x_17267);
        }
    }
    else {
        _x_17267 = binary_op(MINUS, _x_17267, _48MIN3B_17183);
    }
    DeRef(_0);

    /** 			return {I3B, and_bits(x, #FF), and_bits(floor(x / #100), #FF), floor(x / #10000)}*/
    if (IS_ATOM_INT(_x_17267)) {
        {unsigned long tu;
             tu = (unsigned long)_x_17267 & (unsigned long)255;
             _9819 = MAKE_UINT(tu);
        }
    }
    else {
        _9819 = binary_op(AND_BITS, _x_17267, 255);
    }
    if (IS_ATOM_INT(_x_17267)) {
        if (256 > 0 && _x_17267 >= 0) {
            _9820 = _x_17267 / 256;
        }
        else {
            temp_dbl = floor((double)_x_17267 / (double)256);
            if (_x_17267 != MININT)
            _9820 = (long)temp_dbl;
            else
            _9820 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17267, 256);
        _9820 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (IS_ATOM_INT(_9820)) {
        {unsigned long tu;
             tu = (unsigned long)_9820 & (unsigned long)255;
             _9821 = MAKE_UINT(tu);
        }
    }
    else {
        _9821 = binary_op(AND_BITS, _9820, 255);
    }
    DeRef(_9820);
    _9820 = NOVALUE;
    if (IS_ATOM_INT(_x_17267)) {
        if (65536 > 0 && _x_17267 >= 0) {
            _9822 = _x_17267 / 65536;
        }
        else {
            temp_dbl = floor((double)_x_17267 / (double)65536);
            if (_x_17267 != MININT)
            _9822 = (long)temp_dbl;
            else
            _9822 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _x_17267, 65536);
        _9822 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 250;
    *((int *)(_2+8)) = _9819;
    *((int *)(_2+12)) = _9821;
    *((int *)(_2+16)) = _9822;
    _9823 = MAKE_SEQ(_1);
    _9822 = NOVALUE;
    _9821 = NOVALUE;
    _9819 = NOVALUE;
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    DeRef(_9814);
    _9814 = NOVALUE;
    DeRef(_9815);
    _9815 = NOVALUE;
    return _9823;
    goto L3; // [156] 328
L5: 

    /** 			return I4B & convert:int_to_bytes(x-MIN4B)*/
    if (IS_ATOM_INT(_x_17267) && IS_ATOM_INT(_48MIN4B_17190)) {
        _9824 = _x_17267 - _48MIN4B_17190;
        if ((long)((unsigned long)_9824 +(unsigned long) HIGH_BITS) >= 0){
            _9824 = NewDouble((double)_9824);
        }
    }
    else {
        _9824 = binary_op(MINUS, _x_17267, _48MIN4B_17190);
    }
    _9825 = _19int_to_bytes(_9824);
    _9824 = NOVALUE;
    if (IS_SEQUENCE(251) && IS_ATOM(_9825)) {
    }
    else if (IS_ATOM(251) && IS_SEQUENCE(_9825)) {
        Prepend(&_9826, _9825, 251);
    }
    else {
        Concat((object_ptr)&_9826, 251, _9825);
    }
    DeRef(_9825);
    _9825 = NOVALUE;
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    DeRef(_9814);
    _9814 = NOVALUE;
    DeRef(_9815);
    _9815 = NOVALUE;
    DeRef(_9823);
    _9823 = NOVALUE;
    return _9826;
    goto L3; // [180] 328
L1: 

    /** 	elsif atom(x) then*/
    _9827 = IS_ATOM(_x_17267);
    if (_9827 == 0)
    {
        _9827 = NOVALUE;
        goto L6; // [188] 249
    }
    else{
        _9827 = NOVALUE;
    }

    /** 		x4 = convert:atom_to_float32(x)*/

    /** 	return machine_func(M_A_TO_F32, a)*/
    DeRefi(_x4_17268);
    _x4_17268 = machine(48, _x_17267);

    /** 		if x = convert:float32_to_atom(x4) then*/

    /** 	return machine_func(M_F32_TO_A, ieee32)*/
    DeRef(_float32_to_atom_inlined_float32_to_atom_at_203_17306);
    _float32_to_atom_inlined_float32_to_atom_at_203_17306 = machine(49, _x4_17268);
    if (binary_op_a(NOTEQ, _x_17267, _float32_to_atom_inlined_float32_to_atom_at_203_17306)){
        goto L7; // [211] 228
    }

    /** 			return F4B & x4*/
    Prepend(&_9829, _x4_17268, 252);
    DeRef(_x_17267);
    DeRefDSi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    DeRef(_9814);
    _9814 = NOVALUE;
    DeRef(_9815);
    _9815 = NOVALUE;
    DeRef(_9823);
    _9823 = NOVALUE;
    DeRef(_9826);
    _9826 = NOVALUE;
    return _9829;
    goto L3; // [225] 328
L7: 

    /** 			return F8B & convert:atom_to_float64(x)*/

    /** 	return machine_func(M_A_TO_F64, a)*/
    DeRefi(_atom_to_float64_inlined_atom_to_float64_at_229_17311);
    _atom_to_float64_inlined_atom_to_float64_at_229_17311 = machine(46, _x_17267);
    Prepend(&_9830, _atom_to_float64_inlined_atom_to_float64_at_229_17311, 253);
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_s_17269);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    DeRef(_9814);
    _9814 = NOVALUE;
    DeRef(_9815);
    _9815 = NOVALUE;
    DeRef(_9823);
    _9823 = NOVALUE;
    DeRef(_9826);
    _9826 = NOVALUE;
    DeRef(_9829);
    _9829 = NOVALUE;
    return _9830;
    goto L3; // [246] 328
L6: 

    /** 		if length(x) <= 255 then*/
    if (IS_SEQUENCE(_x_17267)){
            _9831 = SEQ_PTR(_x_17267)->length;
    }
    else {
        _9831 = 1;
    }
    if (_9831 > 255)
    goto L8; // [254] 270

    /** 			s = {S1B, length(x)}*/
    if (IS_SEQUENCE(_x_17267)){
            _9833 = SEQ_PTR(_x_17267)->length;
    }
    else {
        _9833 = 1;
    }
    DeRef(_s_17269);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 254;
    ((int *)_2)[2] = _9833;
    _s_17269 = MAKE_SEQ(_1);
    _9833 = NOVALUE;
    goto L9; // [267] 284
L8: 

    /** 			s = S4B & convert:int_to_bytes(length(x))*/
    if (IS_SEQUENCE(_x_17267)){
            _9835 = SEQ_PTR(_x_17267)->length;
    }
    else {
        _9835 = 1;
    }
    _9836 = _19int_to_bytes(_9835);
    _9835 = NOVALUE;
    if (IS_SEQUENCE(255) && IS_ATOM(_9836)) {
    }
    else if (IS_ATOM(255) && IS_SEQUENCE(_9836)) {
        Prepend(&_s_17269, _9836, 255);
    }
    else {
        Concat((object_ptr)&_s_17269, 255, _9836);
    }
    DeRef(_9836);
    _9836 = NOVALUE;
L9: 

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_17267)){
            _9838 = SEQ_PTR(_x_17267)->length;
    }
    else {
        _9838 = 1;
    }
    {
        int _i_17324;
        _i_17324 = 1;
LA: 
        if (_i_17324 > _9838){
            goto LB; // [289] 319
        }

        /** 			s &= compress(x[i])*/
        _2 = (int)SEQ_PTR(_x_17267);
        _9839 = (int)*(((s1_ptr)_2)->base + _i_17324);
        Ref(_9839);
        _9840 = _48compress(_9839);
        _9839 = NOVALUE;
        if (IS_SEQUENCE(_s_17269) && IS_ATOM(_9840)) {
            Ref(_9840);
            Append(&_s_17269, _s_17269, _9840);
        }
        else if (IS_ATOM(_s_17269) && IS_SEQUENCE(_9840)) {
        }
        else {
            Concat((object_ptr)&_s_17269, _s_17269, _9840);
        }
        DeRef(_9840);
        _9840 = NOVALUE;

        /** 		end for*/
        _i_17324 = _i_17324 + 1;
        goto LA; // [314] 296
LB: 
        ;
    }

    /** 		return s*/
    DeRef(_x_17267);
    DeRefi(_x4_17268);
    DeRef(_9803);
    _9803 = NOVALUE;
    DeRef(_9807);
    _9807 = NOVALUE;
    DeRef(_9808);
    _9808 = NOVALUE;
    DeRef(_9814);
    _9814 = NOVALUE;
    DeRef(_9815);
    _9815 = NOVALUE;
    DeRef(_9823);
    _9823 = NOVALUE;
    DeRef(_9826);
    _9826 = NOVALUE;
    DeRef(_9829);
    _9829 = NOVALUE;
    DeRef(_9830);
    _9830 = NOVALUE;
    return _s_17269;
L3: 
    ;
}


int _48db_allocate(int _n_17708)
{
    int _free_list_17709 = NOVALUE;
    int _size_17710 = NOVALUE;
    int _size_ptr_17711 = NOVALUE;
    int _addr_17712 = NOVALUE;
    int _free_count_17713 = NOVALUE;
    int _remaining_17714 = NOVALUE;
    int _seek_1__tmp_at4_17717 = NOVALUE;
    int _seek_inlined_seek_at_4_17716 = NOVALUE;
    int _seek_1__tmp_at39_17724 = NOVALUE;
    int _seek_inlined_seek_at_39_17723 = NOVALUE;
    int _seek_1__tmp_at111_17741 = NOVALUE;
    int _seek_inlined_seek_at_111_17740 = NOVALUE;
    int _pos_inlined_seek_at_108_17739 = NOVALUE;
    int _put4_1__tmp_at137_17746 = NOVALUE;
    int _x_inlined_put4_at_134_17745 = NOVALUE;
    int _seek_1__tmp_at167_17749 = NOVALUE;
    int _seek_inlined_seek_at_167_17748 = NOVALUE;
    int _put4_1__tmp_at193_17754 = NOVALUE;
    int _x_inlined_put4_at_190_17753 = NOVALUE;
    int _seek_1__tmp_at244_17762 = NOVALUE;
    int _seek_inlined_seek_at_244_17761 = NOVALUE;
    int _pos_inlined_seek_at_241_17760 = NOVALUE;
    int _put4_1__tmp_at266_17766 = NOVALUE;
    int _x_inlined_put4_at_263_17765 = NOVALUE;
    int _seek_1__tmp_at333_17777 = NOVALUE;
    int _seek_inlined_seek_at_333_17776 = NOVALUE;
    int _pos_inlined_seek_at_330_17775 = NOVALUE;
    int _seek_1__tmp_at364_17781 = NOVALUE;
    int _seek_inlined_seek_at_364_17780 = NOVALUE;
    int _put4_1__tmp_at386_17785 = NOVALUE;
    int _x_inlined_put4_at_383_17784 = NOVALUE;
    int _seek_1__tmp_at423_17790 = NOVALUE;
    int _seek_inlined_seek_at_423_17789 = NOVALUE;
    int _pos_inlined_seek_at_420_17788 = NOVALUE;
    int _put4_1__tmp_at438_17792 = NOVALUE;
    int _seek_1__tmp_at490_17796 = NOVALUE;
    int _seek_inlined_seek_at_490_17795 = NOVALUE;
    int _put4_1__tmp_at512_17800 = NOVALUE;
    int _x_inlined_put4_at_509_17799 = NOVALUE;
    int _where_inlined_where_at_542_17802 = NOVALUE;
    int _10052 = NOVALUE;
    int _10050 = NOVALUE;
    int _10049 = NOVALUE;
    int _10048 = NOVALUE;
    int _10047 = NOVALUE;
    int _10046 = NOVALUE;
    int _10044 = NOVALUE;
    int _10043 = NOVALUE;
    int _10042 = NOVALUE;
    int _10041 = NOVALUE;
    int _10039 = NOVALUE;
    int _10038 = NOVALUE;
    int _10037 = NOVALUE;
    int _10036 = NOVALUE;
    int _10035 = NOVALUE;
    int _10034 = NOVALUE;
    int _10033 = NOVALUE;
    int _10031 = NOVALUE;
    int _10029 = NOVALUE;
    int _10026 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_17717);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at4_17717 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_17716 = machine(19, _seek_1__tmp_at4_17717);
    DeRefi(_seek_1__tmp_at4_17717);
    _seek_1__tmp_at4_17717 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17713 = _48get4();
    if (!IS_ATOM_INT(_free_count_17713)) {
        _1 = (long)(DBL_PTR(_free_count_17713)->dbl);
        DeRefDS(_free_count_17713);
        _free_count_17713 = _1;
    }

    /** 	if free_count > 0 then*/
    if (_free_count_17713 <= 0)
    goto L1; // [27] 487

    /** 		free_list = get4()*/
    _0 = _free_list_17709;
    _free_list_17709 = _48get4();
    DeRef(_0);

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17709);
    DeRef(_seek_1__tmp_at39_17724);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _free_list_17709;
    _seek_1__tmp_at39_17724 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_39_17723 = machine(19, _seek_1__tmp_at39_17724);
    DeRef(_seek_1__tmp_at39_17724);
    _seek_1__tmp_at39_17724 = NOVALUE;

    /** 		size_ptr = free_list + 4*/
    DeRef(_size_ptr_17711);
    if (IS_ATOM_INT(_free_list_17709)) {
        _size_ptr_17711 = _free_list_17709 + 4;
        if ((long)((unsigned long)_size_ptr_17711 + (unsigned long)HIGH_BITS) >= 0) 
        _size_ptr_17711 = NewDouble((double)_size_ptr_17711);
    }
    else {
        _size_ptr_17711 = NewDouble(DBL_PTR(_free_list_17709)->dbl + (double)4);
    }

    /** 		for i = 1 to free_count do*/
    _10026 = _free_count_17713;
    {
        int _i_17727;
        _i_17727 = 1;
L2: 
        if (_i_17727 > _10026){
            goto L3; // [64] 486
        }

        /** 			addr = get4()*/
        _0 = _addr_17712;
        _addr_17712 = _48get4();
        DeRef(_0);

        /** 			size = get4()*/
        _0 = _size_17710;
        _size_17710 = _48get4();
        DeRef(_0);

        /** 			if size >= n+4 then*/
        if (IS_ATOM_INT(_n_17708)) {
            _10029 = _n_17708 + 4;
            if ((long)((unsigned long)_10029 + (unsigned long)HIGH_BITS) >= 0) 
            _10029 = NewDouble((double)_10029);
        }
        else {
            _10029 = NewDouble(DBL_PTR(_n_17708)->dbl + (double)4);
        }
        if (binary_op_a(LESS, _size_17710, _10029)){
            DeRef(_10029);
            _10029 = NOVALUE;
            goto L4; // [87] 473
        }
        DeRef(_10029);
        _10029 = NOVALUE;

        /** 				if size >= n+16 then*/
        if (IS_ATOM_INT(_n_17708)) {
            _10031 = _n_17708 + 16;
            if ((long)((unsigned long)_10031 + (unsigned long)HIGH_BITS) >= 0) 
            _10031 = NewDouble((double)_10031);
        }
        else {
            _10031 = NewDouble(DBL_PTR(_n_17708)->dbl + (double)16);
        }
        if (binary_op_a(LESS, _size_17710, _10031)){
            DeRef(_10031);
            _10031 = NOVALUE;
            goto L5; // [97] 296
        }
        DeRef(_10031);
        _10031 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17712)) {
            _10033 = _addr_17712 - 4;
            if ((long)((unsigned long)_10033 +(unsigned long) HIGH_BITS) >= 0){
                _10033 = NewDouble((double)_10033);
            }
        }
        else {
            _10033 = NewDouble(DBL_PTR(_addr_17712)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_108_17739);
        _pos_inlined_seek_at_108_17739 = _10033;
        _10033 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_108_17739);
        DeRef(_seek_1__tmp_at111_17741);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _pos_inlined_seek_at_108_17739;
        _seek_1__tmp_at111_17741 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_111_17740 = machine(19, _seek_1__tmp_at111_17741);
        DeRef(_pos_inlined_seek_at_108_17739);
        _pos_inlined_seek_at_108_17739 = NOVALUE;
        DeRef(_seek_1__tmp_at111_17741);
        _seek_1__tmp_at111_17741 = NOVALUE;

        /** 					put4(size-n-4) -- shrink the block*/
        if (IS_ATOM_INT(_size_17710) && IS_ATOM_INT(_n_17708)) {
            _10034 = _size_17710 - _n_17708;
            if ((long)((unsigned long)_10034 +(unsigned long) HIGH_BITS) >= 0){
                _10034 = NewDouble((double)_10034);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17710)) {
                _10034 = NewDouble((double)_size_17710 - DBL_PTR(_n_17708)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17708)) {
                    _10034 = NewDouble(DBL_PTR(_size_17710)->dbl - (double)_n_17708);
                }
                else
                _10034 = NewDouble(DBL_PTR(_size_17710)->dbl - DBL_PTR(_n_17708)->dbl);
            }
        }
        if (IS_ATOM_INT(_10034)) {
            _10035 = _10034 - 4;
            if ((long)((unsigned long)_10035 +(unsigned long) HIGH_BITS) >= 0){
                _10035 = NewDouble((double)_10035);
            }
        }
        else {
            _10035 = NewDouble(DBL_PTR(_10034)->dbl - (double)4);
        }
        DeRef(_10034);
        _10034 = NOVALUE;
        DeRef(_x_inlined_put4_at_134_17745);
        _x_inlined_put4_at_134_17745 = _10035;
        _10035 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_134_17745)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_134_17745;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_134_17745)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at137_17746);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at137_17746 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at137_17746); // DJP 

        /** end procedure*/
        goto L6; // [159] 162
L6: 
        DeRef(_x_inlined_put4_at_134_17745);
        _x_inlined_put4_at_134_17745 = NOVALUE;
        DeRefi(_put4_1__tmp_at137_17746);
        _put4_1__tmp_at137_17746 = NOVALUE;

        /** 					io:seek(current_db, size_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_size_ptr_17711);
        DeRef(_seek_1__tmp_at167_17749);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _size_ptr_17711;
        _seek_1__tmp_at167_17749 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_167_17748 = machine(19, _seek_1__tmp_at167_17749);
        DeRef(_seek_1__tmp_at167_17749);
        _seek_1__tmp_at167_17749 = NOVALUE;

        /** 					put4(size-n-4) -- update size on free list too*/
        if (IS_ATOM_INT(_size_17710) && IS_ATOM_INT(_n_17708)) {
            _10036 = _size_17710 - _n_17708;
            if ((long)((unsigned long)_10036 +(unsigned long) HIGH_BITS) >= 0){
                _10036 = NewDouble((double)_10036);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17710)) {
                _10036 = NewDouble((double)_size_17710 - DBL_PTR(_n_17708)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17708)) {
                    _10036 = NewDouble(DBL_PTR(_size_17710)->dbl - (double)_n_17708);
                }
                else
                _10036 = NewDouble(DBL_PTR(_size_17710)->dbl - DBL_PTR(_n_17708)->dbl);
            }
        }
        if (IS_ATOM_INT(_10036)) {
            _10037 = _10036 - 4;
            if ((long)((unsigned long)_10037 +(unsigned long) HIGH_BITS) >= 0){
                _10037 = NewDouble((double)_10037);
            }
        }
        else {
            _10037 = NewDouble(DBL_PTR(_10036)->dbl - (double)4);
        }
        DeRef(_10036);
        _10036 = NOVALUE;
        DeRef(_x_inlined_put4_at_190_17753);
        _x_inlined_put4_at_190_17753 = _10037;
        _10037 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_190_17753)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_190_17753;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_190_17753)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at193_17754);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at193_17754 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at193_17754); // DJP 

        /** end procedure*/
        goto L7; // [215] 218
L7: 
        DeRef(_x_inlined_put4_at_190_17753);
        _x_inlined_put4_at_190_17753 = NOVALUE;
        DeRefi(_put4_1__tmp_at193_17754);
        _put4_1__tmp_at193_17754 = NOVALUE;

        /** 					addr += size-n-4*/
        if (IS_ATOM_INT(_size_17710) && IS_ATOM_INT(_n_17708)) {
            _10038 = _size_17710 - _n_17708;
            if ((long)((unsigned long)_10038 +(unsigned long) HIGH_BITS) >= 0){
                _10038 = NewDouble((double)_10038);
            }
        }
        else {
            if (IS_ATOM_INT(_size_17710)) {
                _10038 = NewDouble((double)_size_17710 - DBL_PTR(_n_17708)->dbl);
            }
            else {
                if (IS_ATOM_INT(_n_17708)) {
                    _10038 = NewDouble(DBL_PTR(_size_17710)->dbl - (double)_n_17708);
                }
                else
                _10038 = NewDouble(DBL_PTR(_size_17710)->dbl - DBL_PTR(_n_17708)->dbl);
            }
        }
        if (IS_ATOM_INT(_10038)) {
            _10039 = _10038 - 4;
            if ((long)((unsigned long)_10039 +(unsigned long) HIGH_BITS) >= 0){
                _10039 = NewDouble((double)_10039);
            }
        }
        else {
            _10039 = NewDouble(DBL_PTR(_10038)->dbl - (double)4);
        }
        DeRef(_10038);
        _10038 = NOVALUE;
        _0 = _addr_17712;
        if (IS_ATOM_INT(_addr_17712) && IS_ATOM_INT(_10039)) {
            _addr_17712 = _addr_17712 + _10039;
            if ((long)((unsigned long)_addr_17712 + (unsigned long)HIGH_BITS) >= 0) 
            _addr_17712 = NewDouble((double)_addr_17712);
        }
        else {
            if (IS_ATOM_INT(_addr_17712)) {
                _addr_17712 = NewDouble((double)_addr_17712 + DBL_PTR(_10039)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10039)) {
                    _addr_17712 = NewDouble(DBL_PTR(_addr_17712)->dbl + (double)_10039);
                }
                else
                _addr_17712 = NewDouble(DBL_PTR(_addr_17712)->dbl + DBL_PTR(_10039)->dbl);
            }
        }
        DeRef(_0);
        DeRef(_10039);
        _10039 = NOVALUE;

        /** 					io:seek(current_db, addr - 4) */
        if (IS_ATOM_INT(_addr_17712)) {
            _10041 = _addr_17712 - 4;
            if ((long)((unsigned long)_10041 +(unsigned long) HIGH_BITS) >= 0){
                _10041 = NewDouble((double)_10041);
            }
        }
        else {
            _10041 = NewDouble(DBL_PTR(_addr_17712)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_241_17760);
        _pos_inlined_seek_at_241_17760 = _10041;
        _10041 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_241_17760);
        DeRef(_seek_1__tmp_at244_17762);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _pos_inlined_seek_at_241_17760;
        _seek_1__tmp_at244_17762 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_244_17761 = machine(19, _seek_1__tmp_at244_17762);
        DeRef(_pos_inlined_seek_at_241_17760);
        _pos_inlined_seek_at_241_17760 = NOVALUE;
        DeRef(_seek_1__tmp_at244_17762);
        _seek_1__tmp_at244_17762 = NOVALUE;

        /** 					put4(n+4)*/
        if (IS_ATOM_INT(_n_17708)) {
            _10042 = _n_17708 + 4;
            if ((long)((unsigned long)_10042 + (unsigned long)HIGH_BITS) >= 0) 
            _10042 = NewDouble((double)_10042);
        }
        else {
            _10042 = NewDouble(DBL_PTR(_n_17708)->dbl + (double)4);
        }
        DeRef(_x_inlined_put4_at_263_17765);
        _x_inlined_put4_at_263_17765 = _10042;
        _10042 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_263_17765)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_263_17765;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_263_17765)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at266_17766);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at266_17766 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at266_17766); // DJP 

        /** end procedure*/
        goto L8; // [288] 291
L8: 
        DeRef(_x_inlined_put4_at_263_17765);
        _x_inlined_put4_at_263_17765 = NOVALUE;
        DeRefi(_put4_1__tmp_at266_17766);
        _put4_1__tmp_at266_17766 = NOVALUE;
        goto L9; // [293] 466
L5: 

        /** 					remaining = io:get_bytes(current_db, (free_count-i) * 8)*/
        _10043 = _free_count_17713 - _i_17727;
        if ((long)((unsigned long)_10043 +(unsigned long) HIGH_BITS) >= 0){
            _10043 = NewDouble((double)_10043);
        }
        if (IS_ATOM_INT(_10043)) {
            if (_10043 == (short)_10043)
            _10044 = _10043 * 8;
            else
            _10044 = NewDouble(_10043 * (double)8);
        }
        else {
            _10044 = NewDouble(DBL_PTR(_10043)->dbl * (double)8);
        }
        DeRef(_10043);
        _10043 = NOVALUE;
        _0 = _remaining_17714;
        _remaining_17714 = _17get_bytes(_48current_db_17055, _10044);
        DeRef(_0);
        _10044 = NOVALUE;

        /** 					io:seek(current_db, free_list+8*(i-1))*/
        _10046 = _i_17727 - 1;
        if (_10046 <= INT15)
        _10047 = 8 * _10046;
        else
        _10047 = NewDouble(8 * (double)_10046);
        _10046 = NOVALUE;
        if (IS_ATOM_INT(_free_list_17709) && IS_ATOM_INT(_10047)) {
            _10048 = _free_list_17709 + _10047;
            if ((long)((unsigned long)_10048 + (unsigned long)HIGH_BITS) >= 0) 
            _10048 = NewDouble((double)_10048);
        }
        else {
            if (IS_ATOM_INT(_free_list_17709)) {
                _10048 = NewDouble((double)_free_list_17709 + DBL_PTR(_10047)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10047)) {
                    _10048 = NewDouble(DBL_PTR(_free_list_17709)->dbl + (double)_10047);
                }
                else
                _10048 = NewDouble(DBL_PTR(_free_list_17709)->dbl + DBL_PTR(_10047)->dbl);
            }
        }
        DeRef(_10047);
        _10047 = NOVALUE;
        DeRef(_pos_inlined_seek_at_330_17775);
        _pos_inlined_seek_at_330_17775 = _10048;
        _10048 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_330_17775);
        DeRef(_seek_1__tmp_at333_17777);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _pos_inlined_seek_at_330_17775;
        _seek_1__tmp_at333_17777 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_333_17776 = machine(19, _seek_1__tmp_at333_17777);
        DeRef(_pos_inlined_seek_at_330_17775);
        _pos_inlined_seek_at_330_17775 = NOVALUE;
        DeRef(_seek_1__tmp_at333_17777);
        _seek_1__tmp_at333_17777 = NOVALUE;

        /** 					putn(remaining)*/

        /** 	puts(current_db, s)*/
        EPuts(_48current_db_17055, _remaining_17714); // DJP 

        /** end procedure*/
        goto LA; // [358] 361
LA: 

        /** 					io:seek(current_db, FREE_COUNT)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        DeRefi(_seek_1__tmp_at364_17781);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = 7;
        _seek_1__tmp_at364_17781 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_364_17780 = machine(19, _seek_1__tmp_at364_17781);
        DeRefi(_seek_1__tmp_at364_17781);
        _seek_1__tmp_at364_17781 = NOVALUE;

        /** 					put4(free_count-1)*/
        _10049 = _free_count_17713 - 1;
        if ((long)((unsigned long)_10049 +(unsigned long) HIGH_BITS) >= 0){
            _10049 = NewDouble((double)_10049);
        }
        DeRef(_x_inlined_put4_at_383_17784);
        _x_inlined_put4_at_383_17784 = _10049;
        _10049 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_383_17784)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_383_17784;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_383_17784)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at386_17785);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at386_17785 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at386_17785); // DJP 

        /** end procedure*/
        goto LB; // [408] 411
LB: 
        DeRef(_x_inlined_put4_at_383_17784);
        _x_inlined_put4_at_383_17784 = NOVALUE;
        DeRefi(_put4_1__tmp_at386_17785);
        _put4_1__tmp_at386_17785 = NOVALUE;

        /** 					io:seek(current_db, addr - 4)*/
        if (IS_ATOM_INT(_addr_17712)) {
            _10050 = _addr_17712 - 4;
            if ((long)((unsigned long)_10050 +(unsigned long) HIGH_BITS) >= 0){
                _10050 = NewDouble((double)_10050);
            }
        }
        else {
            _10050 = NewDouble(DBL_PTR(_addr_17712)->dbl - (double)4);
        }
        DeRef(_pos_inlined_seek_at_420_17788);
        _pos_inlined_seek_at_420_17788 = _10050;
        _10050 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_420_17788);
        DeRef(_seek_1__tmp_at423_17790);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _pos_inlined_seek_at_420_17788;
        _seek_1__tmp_at423_17790 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_423_17789 = machine(19, _seek_1__tmp_at423_17790);
        DeRef(_pos_inlined_seek_at_420_17788);
        _pos_inlined_seek_at_420_17788 = NOVALUE;
        DeRef(_seek_1__tmp_at423_17790);
        _seek_1__tmp_at423_17790 = NOVALUE;

        /** 					put4(size) -- in case size was not updated by db_free()*/

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_size_17710)) {
            *poke4_addr = (unsigned long)_size_17710;
        }
        else {
            *poke4_addr = (unsigned long)DBL_PTR(_size_17710)->dbl;
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at438_17792);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at438_17792 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at438_17792); // DJP 

        /** end procedure*/
        goto LC; // [460] 463
LC: 
        DeRefi(_put4_1__tmp_at438_17792);
        _put4_1__tmp_at438_17792 = NOVALUE;
L9: 

        /** 				return addr*/
        DeRef(_n_17708);
        DeRef(_free_list_17709);
        DeRef(_size_17710);
        DeRef(_size_ptr_17711);
        DeRef(_remaining_17714);
        return _addr_17712;
L4: 

        /** 			size_ptr += 8*/
        _0 = _size_ptr_17711;
        if (IS_ATOM_INT(_size_ptr_17711)) {
            _size_ptr_17711 = _size_ptr_17711 + 8;
            if ((long)((unsigned long)_size_ptr_17711 + (unsigned long)HIGH_BITS) >= 0) 
            _size_ptr_17711 = NewDouble((double)_size_ptr_17711);
        }
        else {
            _size_ptr_17711 = NewDouble(DBL_PTR(_size_ptr_17711)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _i_17727 = _i_17727 + 1;
        goto L2; // [481] 71
L3: 
        ;
    }
L1: 

    /** 	io:seek(current_db, -1)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at490_17796);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = -1;
    _seek_1__tmp_at490_17796 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_490_17795 = machine(19, _seek_1__tmp_at490_17796);
    DeRefi(_seek_1__tmp_at490_17796);
    _seek_1__tmp_at490_17796 = NOVALUE;

    /** 	put4(n+4)*/
    if (IS_ATOM_INT(_n_17708)) {
        _10052 = _n_17708 + 4;
        if ((long)((unsigned long)_10052 + (unsigned long)HIGH_BITS) >= 0) 
        _10052 = NewDouble((double)_10052);
    }
    else {
        _10052 = NewDouble(DBL_PTR(_n_17708)->dbl + (double)4);
    }
    DeRef(_x_inlined_put4_at_509_17799);
    _x_inlined_put4_at_509_17799 = _10052;
    _10052 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_509_17799)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_509_17799;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_509_17799)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at512_17800);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at512_17800 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at512_17800); // DJP 

    /** end procedure*/
    goto LD; // [534] 537
LD: 
    DeRef(_x_inlined_put4_at_509_17799);
    _x_inlined_put4_at_509_17799 = NOVALUE;
    DeRefi(_put4_1__tmp_at512_17800);
    _put4_1__tmp_at512_17800 = NOVALUE;

    /** 	return io:where(current_db)*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_542_17802);
    _where_inlined_where_at_542_17802 = machine(20, _48current_db_17055);
    DeRef(_n_17708);
    DeRef(_free_list_17709);
    DeRef(_size_17710);
    DeRef(_size_ptr_17711);
    DeRef(_addr_17712);
    DeRef(_remaining_17714);
    return _where_inlined_where_at_542_17802;
    ;
}


void _48db_free(int _p_17805)
{
    int _psize_17806 = NOVALUE;
    int _i_17807 = NOVALUE;
    int _size_17808 = NOVALUE;
    int _addr_17809 = NOVALUE;
    int _free_list_17810 = NOVALUE;
    int _free_list_space_17811 = NOVALUE;
    int _new_space_17812 = NOVALUE;
    int _to_be_freed_17813 = NOVALUE;
    int _prev_addr_17814 = NOVALUE;
    int _prev_size_17815 = NOVALUE;
    int _free_count_17816 = NOVALUE;
    int _remaining_17817 = NOVALUE;
    int _seek_1__tmp_at11_17822 = NOVALUE;
    int _seek_inlined_seek_at_11_17821 = NOVALUE;
    int _pos_inlined_seek_at_8_17820 = NOVALUE;
    int _seek_1__tmp_at33_17826 = NOVALUE;
    int _seek_inlined_seek_at_33_17825 = NOVALUE;
    int _seek_1__tmp_at69_17833 = NOVALUE;
    int _seek_inlined_seek_at_69_17832 = NOVALUE;
    int _pos_inlined_seek_at_66_17831 = NOVALUE;
    int _seek_1__tmp_at133_17846 = NOVALUE;
    int _seek_inlined_seek_at_133_17845 = NOVALUE;
    int _seek_1__tmp_at157_17850 = NOVALUE;
    int _seek_inlined_seek_at_157_17849 = NOVALUE;
    int _put4_1__tmp_at172_17852 = NOVALUE;
    int _seek_1__tmp_at202_17855 = NOVALUE;
    int _seek_inlined_seek_at_202_17854 = NOVALUE;
    int _seek_1__tmp_at234_17860 = NOVALUE;
    int _seek_inlined_seek_at_234_17859 = NOVALUE;
    int _s_inlined_putn_at_274_17866 = NOVALUE;
    int _seek_1__tmp_at297_17869 = NOVALUE;
    int _seek_inlined_seek_at_297_17868 = NOVALUE;
    int _seek_1__tmp_at430_17890 = NOVALUE;
    int _seek_inlined_seek_at_430_17889 = NOVALUE;
    int _pos_inlined_seek_at_427_17888 = NOVALUE;
    int _put4_1__tmp_at482_17900 = NOVALUE;
    int _x_inlined_put4_at_479_17899 = NOVALUE;
    int _seek_1__tmp_at523_17906 = NOVALUE;
    int _seek_inlined_seek_at_523_17905 = NOVALUE;
    int _pos_inlined_seek_at_520_17904 = NOVALUE;
    int _seek_1__tmp_at574_17916 = NOVALUE;
    int _seek_inlined_seek_at_574_17915 = NOVALUE;
    int _pos_inlined_seek_at_571_17914 = NOVALUE;
    int _seek_1__tmp_at611_17921 = NOVALUE;
    int _seek_inlined_seek_at_611_17920 = NOVALUE;
    int _put4_1__tmp_at626_17923 = NOVALUE;
    int _put4_1__tmp_at664_17928 = NOVALUE;
    int _x_inlined_put4_at_661_17927 = NOVALUE;
    int _seek_1__tmp_at737_17940 = NOVALUE;
    int _seek_inlined_seek_at_737_17939 = NOVALUE;
    int _pos_inlined_seek_at_734_17938 = NOVALUE;
    int _put4_1__tmp_at752_17942 = NOVALUE;
    int _put4_1__tmp_at789_17946 = NOVALUE;
    int _x_inlined_put4_at_786_17945 = NOVALUE;
    int _seek_1__tmp_at837_17954 = NOVALUE;
    int _seek_inlined_seek_at_837_17953 = NOVALUE;
    int _pos_inlined_seek_at_834_17952 = NOVALUE;
    int _seek_1__tmp_at883_17962 = NOVALUE;
    int _seek_inlined_seek_at_883_17961 = NOVALUE;
    int _put4_1__tmp_at898_17964 = NOVALUE;
    int _seek_1__tmp_at943_17971 = NOVALUE;
    int _seek_inlined_seek_at_943_17970 = NOVALUE;
    int _pos_inlined_seek_at_940_17969 = NOVALUE;
    int _put4_1__tmp_at958_17973 = NOVALUE;
    int _put4_1__tmp_at986_17975 = NOVALUE;
    int _10120 = NOVALUE;
    int _10119 = NOVALUE;
    int _10118 = NOVALUE;
    int _10115 = NOVALUE;
    int _10114 = NOVALUE;
    int _10113 = NOVALUE;
    int _10112 = NOVALUE;
    int _10111 = NOVALUE;
    int _10110 = NOVALUE;
    int _10109 = NOVALUE;
    int _10108 = NOVALUE;
    int _10107 = NOVALUE;
    int _10106 = NOVALUE;
    int _10105 = NOVALUE;
    int _10104 = NOVALUE;
    int _10103 = NOVALUE;
    int _10102 = NOVALUE;
    int _10101 = NOVALUE;
    int _10099 = NOVALUE;
    int _10098 = NOVALUE;
    int _10097 = NOVALUE;
    int _10095 = NOVALUE;
    int _10094 = NOVALUE;
    int _10093 = NOVALUE;
    int _10092 = NOVALUE;
    int _10091 = NOVALUE;
    int _10090 = NOVALUE;
    int _10089 = NOVALUE;
    int _10088 = NOVALUE;
    int _10087 = NOVALUE;
    int _10086 = NOVALUE;
    int _10085 = NOVALUE;
    int _10084 = NOVALUE;
    int _10083 = NOVALUE;
    int _10082 = NOVALUE;
    int _10081 = NOVALUE;
    int _10080 = NOVALUE;
    int _10079 = NOVALUE;
    int _10078 = NOVALUE;
    int _10072 = NOVALUE;
    int _10071 = NOVALUE;
    int _10070 = NOVALUE;
    int _10068 = NOVALUE;
    int _10064 = NOVALUE;
    int _10063 = NOVALUE;
    int _10061 = NOVALUE;
    int _10060 = NOVALUE;
    int _10058 = NOVALUE;
    int _10057 = NOVALUE;
    int _10053 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, p-4)*/
    if (IS_ATOM_INT(_p_17805)) {
        _10053 = _p_17805 - 4;
        if ((long)((unsigned long)_10053 +(unsigned long) HIGH_BITS) >= 0){
            _10053 = NewDouble((double)_10053);
        }
    }
    else {
        _10053 = NewDouble(DBL_PTR(_p_17805)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_17820);
    _pos_inlined_seek_at_8_17820 = _10053;
    _10053 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_17820);
    DeRef(_seek_1__tmp_at11_17822);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_17820;
    _seek_1__tmp_at11_17822 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_17821 = machine(19, _seek_1__tmp_at11_17822);
    DeRef(_pos_inlined_seek_at_8_17820);
    _pos_inlined_seek_at_8_17820 = NOVALUE;
    DeRef(_seek_1__tmp_at11_17822);
    _seek_1__tmp_at11_17822 = NOVALUE;

    /** 	psize = get4()*/
    _0 = _psize_17806;
    _psize_17806 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at33_17826);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at33_17826 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_33_17825 = machine(19, _seek_1__tmp_at33_17826);
    DeRefi(_seek_1__tmp_at33_17826);
    _seek_1__tmp_at33_17826 = NOVALUE;

    /** 	free_count = get4()*/
    _free_count_17816 = _48get4();
    if (!IS_ATOM_INT(_free_count_17816)) {
        _1 = (long)(DBL_PTR(_free_count_17816)->dbl);
        DeRefDS(_free_count_17816);
        _free_count_17816 = _1;
    }

    /** 	free_list = get4()*/
    _0 = _free_list_17810;
    _free_list_17810 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, free_list - 4)*/
    if (IS_ATOM_INT(_free_list_17810)) {
        _10057 = _free_list_17810 - 4;
        if ((long)((unsigned long)_10057 +(unsigned long) HIGH_BITS) >= 0){
            _10057 = NewDouble((double)_10057);
        }
    }
    else {
        _10057 = NewDouble(DBL_PTR(_free_list_17810)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_66_17831);
    _pos_inlined_seek_at_66_17831 = _10057;
    _10057 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_66_17831);
    DeRef(_seek_1__tmp_at69_17833);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_66_17831;
    _seek_1__tmp_at69_17833 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_69_17832 = machine(19, _seek_1__tmp_at69_17833);
    DeRef(_pos_inlined_seek_at_66_17831);
    _pos_inlined_seek_at_66_17831 = NOVALUE;
    DeRef(_seek_1__tmp_at69_17833);
    _seek_1__tmp_at69_17833 = NOVALUE;

    /** 	free_list_space = get4()-4*/
    _10058 = _48get4();
    DeRef(_free_list_space_17811);
    if (IS_ATOM_INT(_10058)) {
        _free_list_space_17811 = _10058 - 4;
        if ((long)((unsigned long)_free_list_space_17811 +(unsigned long) HIGH_BITS) >= 0){
            _free_list_space_17811 = NewDouble((double)_free_list_space_17811);
        }
    }
    else {
        _free_list_space_17811 = binary_op(MINUS, _10058, 4);
    }
    DeRef(_10058);
    _10058 = NOVALUE;

    /** 	if free_list_space < 8 * (free_count+1) then*/
    _10060 = _free_count_17816 + 1;
    if (_10060 > MAXINT){
        _10060 = NewDouble((double)_10060);
    }
    if (IS_ATOM_INT(_10060)) {
        if (_10060 <= INT15 && _10060 >= -INT15)
        _10061 = 8 * _10060;
        else
        _10061 = NewDouble(8 * (double)_10060);
    }
    else {
        _10061 = NewDouble((double)8 * DBL_PTR(_10060)->dbl);
    }
    DeRef(_10060);
    _10060 = NOVALUE;
    if (binary_op_a(GREATEREQ, _free_list_space_17811, _10061)){
        DeRef(_10061);
        _10061 = NOVALUE;
        goto L1; // [102] 314
    }
    DeRef(_10061);
    _10061 = NOVALUE;

    /** 		new_space = floor(free_list_space + free_list_space / 2)*/
    if (IS_ATOM_INT(_free_list_space_17811)) {
        if (_free_list_space_17811 & 1) {
            _10063 = NewDouble((_free_list_space_17811 >> 1) + 0.5);
        }
        else
        _10063 = _free_list_space_17811 >> 1;
    }
    else {
        _10063 = binary_op(DIVIDE, _free_list_space_17811, 2);
    }
    if (IS_ATOM_INT(_free_list_space_17811) && IS_ATOM_INT(_10063)) {
        _10064 = _free_list_space_17811 + _10063;
        if ((long)((unsigned long)_10064 + (unsigned long)HIGH_BITS) >= 0) 
        _10064 = NewDouble((double)_10064);
    }
    else {
        if (IS_ATOM_INT(_free_list_space_17811)) {
            _10064 = NewDouble((double)_free_list_space_17811 + DBL_PTR(_10063)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10063)) {
                _10064 = NewDouble(DBL_PTR(_free_list_space_17811)->dbl + (double)_10063);
            }
            else
            _10064 = NewDouble(DBL_PTR(_free_list_space_17811)->dbl + DBL_PTR(_10063)->dbl);
        }
    }
    DeRef(_10063);
    _10063 = NOVALUE;
    DeRef(_new_space_17812);
    if (IS_ATOM_INT(_10064))
    _new_space_17812 = e_floor(_10064);
    else
    _new_space_17812 = unary_op(FLOOR, _10064);
    DeRef(_10064);
    _10064 = NOVALUE;

    /** 		to_be_freed = free_list*/
    Ref(_free_list_17810);
    DeRef(_to_be_freed_17813);
    _to_be_freed_17813 = _free_list_17810;

    /** 		free_list = db_allocate(new_space)*/
    Ref(_new_space_17812);
    _0 = _free_list_17810;
    _free_list_17810 = _48db_allocate(_new_space_17812);
    DeRef(_0);

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at133_17846);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at133_17846 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_133_17845 = machine(19, _seek_1__tmp_at133_17846);
    DeRefi(_seek_1__tmp_at133_17846);
    _seek_1__tmp_at133_17846 = NOVALUE;

    /** 		free_count = get4() -- db_allocate may have changed it*/
    _free_count_17816 = _48get4();
    if (!IS_ATOM_INT(_free_count_17816)) {
        _1 = (long)(DBL_PTR(_free_count_17816)->dbl);
        DeRefDS(_free_count_17816);
        _free_count_17816 = _1;
    }

    /** 		io:seek(current_db, FREE_LIST)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at157_17850);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 11;
    _seek_1__tmp_at157_17850 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_157_17849 = machine(19, _seek_1__tmp_at157_17850);
    DeRefi(_seek_1__tmp_at157_17850);
    _seek_1__tmp_at157_17850 = NOVALUE;

    /** 		put4(free_list)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_free_list_17810)) {
        *poke4_addr = (unsigned long)_free_list_17810;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_free_list_17810)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at172_17852);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at172_17852 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at172_17852); // DJP 

    /** end procedure*/
    goto L2; // [194] 197
L2: 
    DeRefi(_put4_1__tmp_at172_17852);
    _put4_1__tmp_at172_17852 = NOVALUE;

    /** 		io:seek(current_db, to_be_freed)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_to_be_freed_17813);
    DeRef(_seek_1__tmp_at202_17855);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _to_be_freed_17813;
    _seek_1__tmp_at202_17855 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_202_17854 = machine(19, _seek_1__tmp_at202_17855);
    DeRef(_seek_1__tmp_at202_17855);
    _seek_1__tmp_at202_17855 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, 8*free_count)*/
    if (_free_count_17816 <= INT15 && _free_count_17816 >= -INT15)
    _10068 = 8 * _free_count_17816;
    else
    _10068 = NewDouble(8 * (double)_free_count_17816);
    _0 = _remaining_17817;
    _remaining_17817 = _17get_bytes(_48current_db_17055, _10068);
    DeRef(_0);
    _10068 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17810);
    DeRef(_seek_1__tmp_at234_17860);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _free_list_17810;
    _seek_1__tmp_at234_17860 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_234_17859 = machine(19, _seek_1__tmp_at234_17860);
    DeRef(_seek_1__tmp_at234_17860);
    _seek_1__tmp_at234_17860 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_17817); // DJP 

    /** end procedure*/
    goto L3; // [259] 262
L3: 

    /** 		putn(repeat(0, new_space-length(remaining)))*/
    if (IS_SEQUENCE(_remaining_17817)){
            _10070 = SEQ_PTR(_remaining_17817)->length;
    }
    else {
        _10070 = 1;
    }
    if (IS_ATOM_INT(_new_space_17812)) {
        _10071 = _new_space_17812 - _10070;
    }
    else {
        _10071 = NewDouble(DBL_PTR(_new_space_17812)->dbl - (double)_10070);
    }
    _10070 = NOVALUE;
    _10072 = Repeat(0, _10071);
    DeRef(_10071);
    _10071 = NOVALUE;
    DeRefi(_s_inlined_putn_at_274_17866);
    _s_inlined_putn_at_274_17866 = _10072;
    _10072 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_274_17866); // DJP 

    /** end procedure*/
    goto L4; // [289] 292
L4: 
    DeRefi(_s_inlined_putn_at_274_17866);
    _s_inlined_putn_at_274_17866 = NOVALUE;

    /** 		io:seek(current_db, free_list)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_free_list_17810);
    DeRef(_seek_1__tmp_at297_17869);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _free_list_17810;
    _seek_1__tmp_at297_17869 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_297_17868 = machine(19, _seek_1__tmp_at297_17869);
    DeRef(_seek_1__tmp_at297_17869);
    _seek_1__tmp_at297_17869 = NOVALUE;
    goto L5; // [311] 320
L1: 

    /** 		new_space = 0*/
    DeRef(_new_space_17812);
    _new_space_17812 = 0;
L5: 

    /** 	i = 1*/
    DeRef(_i_17807);
    _i_17807 = 1;

    /** 	prev_addr = 0*/
    DeRef(_prev_addr_17814);
    _prev_addr_17814 = 0;

    /** 	prev_size = 0*/
    DeRef(_prev_size_17815);
    _prev_size_17815 = 0;

    /** 	while i <= free_count do*/
L6: 
    if (binary_op_a(GREATER, _i_17807, _free_count_17816)){
        goto L7; // [340] 386
    }

    /** 		addr = get4()*/
    _0 = _addr_17809;
    _addr_17809 = _48get4();
    DeRef(_0);

    /** 		size = get4()*/
    _0 = _size_17808;
    _size_17808 = _48get4();
    DeRef(_0);

    /** 		if p < addr then*/
    if (binary_op_a(GREATEREQ, _p_17805, _addr_17809)){
        goto L8; // [356] 365
    }

    /** 			exit*/
    goto L7; // [362] 386
L8: 

    /** 		prev_addr = addr*/
    Ref(_addr_17809);
    DeRef(_prev_addr_17814);
    _prev_addr_17814 = _addr_17809;

    /** 		prev_size = size*/
    Ref(_size_17808);
    DeRef(_prev_size_17815);
    _prev_size_17815 = _size_17808;

    /** 		i += 1*/
    _0 = _i_17807;
    if (IS_ATOM_INT(_i_17807)) {
        _i_17807 = _i_17807 + 1;
        if (_i_17807 > MAXINT){
            _i_17807 = NewDouble((double)_i_17807);
        }
    }
    else
    _i_17807 = binary_op(PLUS, 1, _i_17807);
    DeRef(_0);

    /** 	end while*/
    goto L6; // [383] 340
L7: 

    /** 	if i > 1 and prev_addr + prev_size = p then*/
    if (IS_ATOM_INT(_i_17807)) {
        _10078 = (_i_17807 > 1);
    }
    else {
        _10078 = (DBL_PTR(_i_17807)->dbl > (double)1);
    }
    if (_10078 == 0) {
        goto L9; // [392] 695
    }
    if (IS_ATOM_INT(_prev_addr_17814) && IS_ATOM_INT(_prev_size_17815)) {
        _10080 = _prev_addr_17814 + _prev_size_17815;
        if ((long)((unsigned long)_10080 + (unsigned long)HIGH_BITS) >= 0) 
        _10080 = NewDouble((double)_10080);
    }
    else {
        if (IS_ATOM_INT(_prev_addr_17814)) {
            _10080 = NewDouble((double)_prev_addr_17814 + DBL_PTR(_prev_size_17815)->dbl);
        }
        else {
            if (IS_ATOM_INT(_prev_size_17815)) {
                _10080 = NewDouble(DBL_PTR(_prev_addr_17814)->dbl + (double)_prev_size_17815);
            }
            else
            _10080 = NewDouble(DBL_PTR(_prev_addr_17814)->dbl + DBL_PTR(_prev_size_17815)->dbl);
        }
    }
    if (IS_ATOM_INT(_10080) && IS_ATOM_INT(_p_17805)) {
        _10081 = (_10080 == _p_17805);
    }
    else {
        if (IS_ATOM_INT(_10080)) {
            _10081 = ((double)_10080 == DBL_PTR(_p_17805)->dbl);
        }
        else {
            if (IS_ATOM_INT(_p_17805)) {
                _10081 = (DBL_PTR(_10080)->dbl == (double)_p_17805);
            }
            else
            _10081 = (DBL_PTR(_10080)->dbl == DBL_PTR(_p_17805)->dbl);
        }
    }
    DeRef(_10080);
    _10080 = NOVALUE;
    if (_10081 == 0)
    {
        DeRef(_10081);
        _10081 = NOVALUE;
        goto L9; // [405] 695
    }
    else{
        DeRef(_10081);
        _10081 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-2)*8+4)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10082 = _i_17807 - 2;
        if ((long)((unsigned long)_10082 +(unsigned long) HIGH_BITS) >= 0){
            _10082 = NewDouble((double)_10082);
        }
    }
    else {
        _10082 = NewDouble(DBL_PTR(_i_17807)->dbl - (double)2);
    }
    if (IS_ATOM_INT(_10082)) {
        if (_10082 == (short)_10082)
        _10083 = _10082 * 8;
        else
        _10083 = NewDouble(_10082 * (double)8);
    }
    else {
        _10083 = NewDouble(DBL_PTR(_10082)->dbl * (double)8);
    }
    DeRef(_10082);
    _10082 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10083)) {
        _10084 = _free_list_17810 + _10083;
        if ((long)((unsigned long)_10084 + (unsigned long)HIGH_BITS) >= 0) 
        _10084 = NewDouble((double)_10084);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10084 = NewDouble((double)_free_list_17810 + DBL_PTR(_10083)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10083)) {
                _10084 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10083);
            }
            else
            _10084 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10083)->dbl);
        }
    }
    DeRef(_10083);
    _10083 = NOVALUE;
    if (IS_ATOM_INT(_10084)) {
        _10085 = _10084 + 4;
        if ((long)((unsigned long)_10085 + (unsigned long)HIGH_BITS) >= 0) 
        _10085 = NewDouble((double)_10085);
    }
    else {
        _10085 = NewDouble(DBL_PTR(_10084)->dbl + (double)4);
    }
    DeRef(_10084);
    _10084 = NOVALUE;
    DeRef(_pos_inlined_seek_at_427_17888);
    _pos_inlined_seek_at_427_17888 = _10085;
    _10085 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_427_17888);
    DeRef(_seek_1__tmp_at430_17890);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_427_17888;
    _seek_1__tmp_at430_17890 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_430_17889 = machine(19, _seek_1__tmp_at430_17890);
    DeRef(_pos_inlined_seek_at_427_17888);
    _pos_inlined_seek_at_427_17888 = NOVALUE;
    DeRef(_seek_1__tmp_at430_17890);
    _seek_1__tmp_at430_17890 = NOVALUE;

    /** 		if i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17807)) {
        _10086 = (_i_17807 < _free_count_17816);
    }
    else {
        _10086 = (DBL_PTR(_i_17807)->dbl < (double)_free_count_17816);
    }
    if (_10086 == 0) {
        goto LA; // [450] 656
    }
    if (IS_ATOM_INT(_p_17805) && IS_ATOM_INT(_psize_17806)) {
        _10088 = _p_17805 + _psize_17806;
        if ((long)((unsigned long)_10088 + (unsigned long)HIGH_BITS) >= 0) 
        _10088 = NewDouble((double)_10088);
    }
    else {
        if (IS_ATOM_INT(_p_17805)) {
            _10088 = NewDouble((double)_p_17805 + DBL_PTR(_psize_17806)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17806)) {
                _10088 = NewDouble(DBL_PTR(_p_17805)->dbl + (double)_psize_17806);
            }
            else
            _10088 = NewDouble(DBL_PTR(_p_17805)->dbl + DBL_PTR(_psize_17806)->dbl);
        }
    }
    if (IS_ATOM_INT(_10088) && IS_ATOM_INT(_addr_17809)) {
        _10089 = (_10088 == _addr_17809);
    }
    else {
        if (IS_ATOM_INT(_10088)) {
            _10089 = ((double)_10088 == DBL_PTR(_addr_17809)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17809)) {
                _10089 = (DBL_PTR(_10088)->dbl == (double)_addr_17809);
            }
            else
            _10089 = (DBL_PTR(_10088)->dbl == DBL_PTR(_addr_17809)->dbl);
        }
    }
    DeRef(_10088);
    _10088 = NOVALUE;
    if (_10089 == 0)
    {
        DeRef(_10089);
        _10089 = NOVALUE;
        goto LA; // [465] 656
    }
    else{
        DeRef(_10089);
        _10089 = NOVALUE;
    }

    /** 			put4(prev_size+psize+size) -- update size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17815) && IS_ATOM_INT(_psize_17806)) {
        _10090 = _prev_size_17815 + _psize_17806;
        if ((long)((unsigned long)_10090 + (unsigned long)HIGH_BITS) >= 0) 
        _10090 = NewDouble((double)_10090);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17815)) {
            _10090 = NewDouble((double)_prev_size_17815 + DBL_PTR(_psize_17806)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17806)) {
                _10090 = NewDouble(DBL_PTR(_prev_size_17815)->dbl + (double)_psize_17806);
            }
            else
            _10090 = NewDouble(DBL_PTR(_prev_size_17815)->dbl + DBL_PTR(_psize_17806)->dbl);
        }
    }
    if (IS_ATOM_INT(_10090) && IS_ATOM_INT(_size_17808)) {
        _10091 = _10090 + _size_17808;
        if ((long)((unsigned long)_10091 + (unsigned long)HIGH_BITS) >= 0) 
        _10091 = NewDouble((double)_10091);
    }
    else {
        if (IS_ATOM_INT(_10090)) {
            _10091 = NewDouble((double)_10090 + DBL_PTR(_size_17808)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17808)) {
                _10091 = NewDouble(DBL_PTR(_10090)->dbl + (double)_size_17808);
            }
            else
            _10091 = NewDouble(DBL_PTR(_10090)->dbl + DBL_PTR(_size_17808)->dbl);
        }
    }
    DeRef(_10090);
    _10090 = NOVALUE;
    DeRef(_x_inlined_put4_at_479_17899);
    _x_inlined_put4_at_479_17899 = _10091;
    _10091 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_479_17899)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_479_17899;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_479_17899)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at482_17900);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at482_17900 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at482_17900); // DJP 

    /** end procedure*/
    goto LB; // [504] 507
LB: 
    DeRef(_x_inlined_put4_at_479_17899);
    _x_inlined_put4_at_479_17899 = NOVALUE;
    DeRefi(_put4_1__tmp_at482_17900);
    _put4_1__tmp_at482_17900 = NOVALUE;

    /** 			io:seek(current_db, free_list+i*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        if (_i_17807 == (short)_i_17807)
        _10092 = _i_17807 * 8;
        else
        _10092 = NewDouble(_i_17807 * (double)8);
    }
    else {
        _10092 = NewDouble(DBL_PTR(_i_17807)->dbl * (double)8);
    }
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10092)) {
        _10093 = _free_list_17810 + _10092;
        if ((long)((unsigned long)_10093 + (unsigned long)HIGH_BITS) >= 0) 
        _10093 = NewDouble((double)_10093);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10093 = NewDouble((double)_free_list_17810 + DBL_PTR(_10092)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10092)) {
                _10093 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10092);
            }
            else
            _10093 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10092)->dbl);
        }
    }
    DeRef(_10092);
    _10092 = NOVALUE;
    DeRef(_pos_inlined_seek_at_520_17904);
    _pos_inlined_seek_at_520_17904 = _10093;
    _10093 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_520_17904);
    DeRef(_seek_1__tmp_at523_17906);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_520_17904;
    _seek_1__tmp_at523_17906 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_523_17905 = machine(19, _seek_1__tmp_at523_17906);
    DeRef(_pos_inlined_seek_at_520_17904);
    _pos_inlined_seek_at_520_17904 = NOVALUE;
    DeRef(_seek_1__tmp_at523_17906);
    _seek_1__tmp_at523_17906 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, (free_count-i)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10094 = _free_count_17816 - _i_17807;
        if ((long)((unsigned long)_10094 +(unsigned long) HIGH_BITS) >= 0){
            _10094 = NewDouble((double)_10094);
        }
    }
    else {
        _10094 = NewDouble((double)_free_count_17816 - DBL_PTR(_i_17807)->dbl);
    }
    if (IS_ATOM_INT(_10094)) {
        if (_10094 == (short)_10094)
        _10095 = _10094 * 8;
        else
        _10095 = NewDouble(_10094 * (double)8);
    }
    else {
        _10095 = NewDouble(DBL_PTR(_10094)->dbl * (double)8);
    }
    DeRef(_10094);
    _10094 = NOVALUE;
    _0 = _remaining_17817;
    _remaining_17817 = _17get_bytes(_48current_db_17055, _10095);
    DeRef(_0);
    _10095 = NOVALUE;

    /** 			io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10097 = _i_17807 - 1;
        if ((long)((unsigned long)_10097 +(unsigned long) HIGH_BITS) >= 0){
            _10097 = NewDouble((double)_10097);
        }
    }
    else {
        _10097 = NewDouble(DBL_PTR(_i_17807)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10097)) {
        if (_10097 == (short)_10097)
        _10098 = _10097 * 8;
        else
        _10098 = NewDouble(_10097 * (double)8);
    }
    else {
        _10098 = NewDouble(DBL_PTR(_10097)->dbl * (double)8);
    }
    DeRef(_10097);
    _10097 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10098)) {
        _10099 = _free_list_17810 + _10098;
        if ((long)((unsigned long)_10099 + (unsigned long)HIGH_BITS) >= 0) 
        _10099 = NewDouble((double)_10099);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10099 = NewDouble((double)_free_list_17810 + DBL_PTR(_10098)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10098)) {
                _10099 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10098);
            }
            else
            _10099 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10098)->dbl);
        }
    }
    DeRef(_10098);
    _10098 = NOVALUE;
    DeRef(_pos_inlined_seek_at_571_17914);
    _pos_inlined_seek_at_571_17914 = _10099;
    _10099 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_571_17914);
    DeRef(_seek_1__tmp_at574_17916);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_571_17914;
    _seek_1__tmp_at574_17916 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_574_17915 = machine(19, _seek_1__tmp_at574_17916);
    DeRef(_pos_inlined_seek_at_571_17914);
    _pos_inlined_seek_at_571_17914 = NOVALUE;
    DeRef(_seek_1__tmp_at574_17916);
    _seek_1__tmp_at574_17916 = NOVALUE;

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_17817); // DJP 

    /** end procedure*/
    goto LC; // [599] 602
LC: 

    /** 			free_count -= 1*/
    _free_count_17816 = _free_count_17816 - 1;

    /** 			io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at611_17921);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at611_17921 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_611_17920 = machine(19, _seek_1__tmp_at611_17921);
    DeRefi(_seek_1__tmp_at611_17921);
    _seek_1__tmp_at611_17921 = NOVALUE;

    /** 			put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17816;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at626_17923);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at626_17923 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at626_17923); // DJP 

    /** end procedure*/
    goto LD; // [648] 651
LD: 
    DeRefi(_put4_1__tmp_at626_17923);
    _put4_1__tmp_at626_17923 = NOVALUE;
    goto LE; // [653] 1028
LA: 

    /** 			put4(prev_size+psize) -- increase previous size on free list (only)*/
    if (IS_ATOM_INT(_prev_size_17815) && IS_ATOM_INT(_psize_17806)) {
        _10101 = _prev_size_17815 + _psize_17806;
        if ((long)((unsigned long)_10101 + (unsigned long)HIGH_BITS) >= 0) 
        _10101 = NewDouble((double)_10101);
    }
    else {
        if (IS_ATOM_INT(_prev_size_17815)) {
            _10101 = NewDouble((double)_prev_size_17815 + DBL_PTR(_psize_17806)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17806)) {
                _10101 = NewDouble(DBL_PTR(_prev_size_17815)->dbl + (double)_psize_17806);
            }
            else
            _10101 = NewDouble(DBL_PTR(_prev_size_17815)->dbl + DBL_PTR(_psize_17806)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_661_17927);
    _x_inlined_put4_at_661_17927 = _10101;
    _10101 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_661_17927)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_661_17927;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_661_17927)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at664_17928);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at664_17928 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at664_17928); // DJP 

    /** end procedure*/
    goto LF; // [686] 689
LF: 
    DeRef(_x_inlined_put4_at_661_17927);
    _x_inlined_put4_at_661_17927 = NOVALUE;
    DeRefi(_put4_1__tmp_at664_17928);
    _put4_1__tmp_at664_17928 = NOVALUE;
    goto LE; // [692] 1028
L9: 

    /** 	elsif i < free_count and p + psize = addr then*/
    if (IS_ATOM_INT(_i_17807)) {
        _10102 = (_i_17807 < _free_count_17816);
    }
    else {
        _10102 = (DBL_PTR(_i_17807)->dbl < (double)_free_count_17816);
    }
    if (_10102 == 0) {
        goto L10; // [701] 819
    }
    if (IS_ATOM_INT(_p_17805) && IS_ATOM_INT(_psize_17806)) {
        _10104 = _p_17805 + _psize_17806;
        if ((long)((unsigned long)_10104 + (unsigned long)HIGH_BITS) >= 0) 
        _10104 = NewDouble((double)_10104);
    }
    else {
        if (IS_ATOM_INT(_p_17805)) {
            _10104 = NewDouble((double)_p_17805 + DBL_PTR(_psize_17806)->dbl);
        }
        else {
            if (IS_ATOM_INT(_psize_17806)) {
                _10104 = NewDouble(DBL_PTR(_p_17805)->dbl + (double)_psize_17806);
            }
            else
            _10104 = NewDouble(DBL_PTR(_p_17805)->dbl + DBL_PTR(_psize_17806)->dbl);
        }
    }
    if (IS_ATOM_INT(_10104) && IS_ATOM_INT(_addr_17809)) {
        _10105 = (_10104 == _addr_17809);
    }
    else {
        if (IS_ATOM_INT(_10104)) {
            _10105 = ((double)_10104 == DBL_PTR(_addr_17809)->dbl);
        }
        else {
            if (IS_ATOM_INT(_addr_17809)) {
                _10105 = (DBL_PTR(_10104)->dbl == (double)_addr_17809);
            }
            else
            _10105 = (DBL_PTR(_10104)->dbl == DBL_PTR(_addr_17809)->dbl);
        }
    }
    DeRef(_10104);
    _10104 = NOVALUE;
    if (_10105 == 0)
    {
        DeRef(_10105);
        _10105 = NOVALUE;
        goto L10; // [716] 819
    }
    else{
        DeRef(_10105);
        _10105 = NOVALUE;
    }

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10106 = _i_17807 - 1;
        if ((long)((unsigned long)_10106 +(unsigned long) HIGH_BITS) >= 0){
            _10106 = NewDouble((double)_10106);
        }
    }
    else {
        _10106 = NewDouble(DBL_PTR(_i_17807)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10106)) {
        if (_10106 == (short)_10106)
        _10107 = _10106 * 8;
        else
        _10107 = NewDouble(_10106 * (double)8);
    }
    else {
        _10107 = NewDouble(DBL_PTR(_10106)->dbl * (double)8);
    }
    DeRef(_10106);
    _10106 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10107)) {
        _10108 = _free_list_17810 + _10107;
        if ((long)((unsigned long)_10108 + (unsigned long)HIGH_BITS) >= 0) 
        _10108 = NewDouble((double)_10108);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10108 = NewDouble((double)_free_list_17810 + DBL_PTR(_10107)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10107)) {
                _10108 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10107);
            }
            else
            _10108 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10107)->dbl);
        }
    }
    DeRef(_10107);
    _10107 = NOVALUE;
    DeRef(_pos_inlined_seek_at_734_17938);
    _pos_inlined_seek_at_734_17938 = _10108;
    _10108 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_734_17938);
    DeRef(_seek_1__tmp_at737_17940);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_734_17938;
    _seek_1__tmp_at737_17940 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_737_17939 = machine(19, _seek_1__tmp_at737_17940);
    DeRef(_pos_inlined_seek_at_734_17938);
    _pos_inlined_seek_at_734_17938 = NOVALUE;
    DeRef(_seek_1__tmp_at737_17940);
    _seek_1__tmp_at737_17940 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_p_17805)) {
        *poke4_addr = (unsigned long)_p_17805;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17805)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at752_17942);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at752_17942 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at752_17942); // DJP 

    /** end procedure*/
    goto L11; // [774] 777
L11: 
    DeRefi(_put4_1__tmp_at752_17942);
    _put4_1__tmp_at752_17942 = NOVALUE;

    /** 		put4(psize+size)*/
    if (IS_ATOM_INT(_psize_17806) && IS_ATOM_INT(_size_17808)) {
        _10109 = _psize_17806 + _size_17808;
        if ((long)((unsigned long)_10109 + (unsigned long)HIGH_BITS) >= 0) 
        _10109 = NewDouble((double)_10109);
    }
    else {
        if (IS_ATOM_INT(_psize_17806)) {
            _10109 = NewDouble((double)_psize_17806 + DBL_PTR(_size_17808)->dbl);
        }
        else {
            if (IS_ATOM_INT(_size_17808)) {
                _10109 = NewDouble(DBL_PTR(_psize_17806)->dbl + (double)_size_17808);
            }
            else
            _10109 = NewDouble(DBL_PTR(_psize_17806)->dbl + DBL_PTR(_size_17808)->dbl);
        }
    }
    DeRef(_x_inlined_put4_at_786_17945);
    _x_inlined_put4_at_786_17945 = _10109;
    _10109 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_786_17945)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_786_17945;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_786_17945)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at789_17946);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at789_17946 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at789_17946); // DJP 

    /** end procedure*/
    goto L12; // [811] 814
L12: 
    DeRef(_x_inlined_put4_at_786_17945);
    _x_inlined_put4_at_786_17945 = NOVALUE;
    DeRefi(_put4_1__tmp_at789_17946);
    _put4_1__tmp_at789_17946 = NOVALUE;
    goto LE; // [816] 1028
L10: 

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10110 = _i_17807 - 1;
        if ((long)((unsigned long)_10110 +(unsigned long) HIGH_BITS) >= 0){
            _10110 = NewDouble((double)_10110);
        }
    }
    else {
        _10110 = NewDouble(DBL_PTR(_i_17807)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10110)) {
        if (_10110 == (short)_10110)
        _10111 = _10110 * 8;
        else
        _10111 = NewDouble(_10110 * (double)8);
    }
    else {
        _10111 = NewDouble(DBL_PTR(_10110)->dbl * (double)8);
    }
    DeRef(_10110);
    _10110 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10111)) {
        _10112 = _free_list_17810 + _10111;
        if ((long)((unsigned long)_10112 + (unsigned long)HIGH_BITS) >= 0) 
        _10112 = NewDouble((double)_10112);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10112 = NewDouble((double)_free_list_17810 + DBL_PTR(_10111)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10111)) {
                _10112 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10111);
            }
            else
            _10112 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10111)->dbl);
        }
    }
    DeRef(_10111);
    _10111 = NOVALUE;
    DeRef(_pos_inlined_seek_at_834_17952);
    _pos_inlined_seek_at_834_17952 = _10112;
    _10112 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_834_17952);
    DeRef(_seek_1__tmp_at837_17954);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_834_17952;
    _seek_1__tmp_at837_17954 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_837_17953 = machine(19, _seek_1__tmp_at837_17954);
    DeRef(_pos_inlined_seek_at_834_17952);
    _pos_inlined_seek_at_834_17952 = NOVALUE;
    DeRef(_seek_1__tmp_at837_17954);
    _seek_1__tmp_at837_17954 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (free_count-i+1)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10113 = _free_count_17816 - _i_17807;
        if ((long)((unsigned long)_10113 +(unsigned long) HIGH_BITS) >= 0){
            _10113 = NewDouble((double)_10113);
        }
    }
    else {
        _10113 = NewDouble((double)_free_count_17816 - DBL_PTR(_i_17807)->dbl);
    }
    if (IS_ATOM_INT(_10113)) {
        _10114 = _10113 + 1;
        if (_10114 > MAXINT){
            _10114 = NewDouble((double)_10114);
        }
    }
    else
    _10114 = binary_op(PLUS, 1, _10113);
    DeRef(_10113);
    _10113 = NOVALUE;
    if (IS_ATOM_INT(_10114)) {
        if (_10114 == (short)_10114)
        _10115 = _10114 * 8;
        else
        _10115 = NewDouble(_10114 * (double)8);
    }
    else {
        _10115 = NewDouble(DBL_PTR(_10114)->dbl * (double)8);
    }
    DeRef(_10114);
    _10114 = NOVALUE;
    _0 = _remaining_17817;
    _remaining_17817 = _17get_bytes(_48current_db_17055, _10115);
    DeRef(_0);
    _10115 = NOVALUE;

    /** 		free_count += 1*/
    _free_count_17816 = _free_count_17816 + 1;

    /** 		io:seek(current_db, FREE_COUNT)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at883_17962);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 7;
    _seek_1__tmp_at883_17962 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_883_17961 = machine(19, _seek_1__tmp_at883_17962);
    DeRefi(_seek_1__tmp_at883_17962);
    _seek_1__tmp_at883_17962 = NOVALUE;

    /** 		put4(free_count)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)_free_count_17816;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at898_17964);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at898_17964 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at898_17964); // DJP 

    /** end procedure*/
    goto L13; // [920] 923
L13: 
    DeRefi(_put4_1__tmp_at898_17964);
    _put4_1__tmp_at898_17964 = NOVALUE;

    /** 		io:seek(current_db, free_list+(i-1)*8)*/
    if (IS_ATOM_INT(_i_17807)) {
        _10118 = _i_17807 - 1;
        if ((long)((unsigned long)_10118 +(unsigned long) HIGH_BITS) >= 0){
            _10118 = NewDouble((double)_10118);
        }
    }
    else {
        _10118 = NewDouble(DBL_PTR(_i_17807)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10118)) {
        if (_10118 == (short)_10118)
        _10119 = _10118 * 8;
        else
        _10119 = NewDouble(_10118 * (double)8);
    }
    else {
        _10119 = NewDouble(DBL_PTR(_10118)->dbl * (double)8);
    }
    DeRef(_10118);
    _10118 = NOVALUE;
    if (IS_ATOM_INT(_free_list_17810) && IS_ATOM_INT(_10119)) {
        _10120 = _free_list_17810 + _10119;
        if ((long)((unsigned long)_10120 + (unsigned long)HIGH_BITS) >= 0) 
        _10120 = NewDouble((double)_10120);
    }
    else {
        if (IS_ATOM_INT(_free_list_17810)) {
            _10120 = NewDouble((double)_free_list_17810 + DBL_PTR(_10119)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10119)) {
                _10120 = NewDouble(DBL_PTR(_free_list_17810)->dbl + (double)_10119);
            }
            else
            _10120 = NewDouble(DBL_PTR(_free_list_17810)->dbl + DBL_PTR(_10119)->dbl);
        }
    }
    DeRef(_10119);
    _10119 = NOVALUE;
    DeRef(_pos_inlined_seek_at_940_17969);
    _pos_inlined_seek_at_940_17969 = _10120;
    _10120 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_940_17969);
    DeRef(_seek_1__tmp_at943_17971);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_940_17969;
    _seek_1__tmp_at943_17971 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_943_17970 = machine(19, _seek_1__tmp_at943_17971);
    DeRef(_pos_inlined_seek_at_940_17969);
    _pos_inlined_seek_at_940_17969 = NOVALUE;
    DeRef(_seek_1__tmp_at943_17971);
    _seek_1__tmp_at943_17971 = NOVALUE;

    /** 		put4(p)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_p_17805)) {
        *poke4_addr = (unsigned long)_p_17805;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_p_17805)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at958_17973);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at958_17973 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at958_17973); // DJP 

    /** end procedure*/
    goto L14; // [980] 983
L14: 
    DeRefi(_put4_1__tmp_at958_17973);
    _put4_1__tmp_at958_17973 = NOVALUE;

    /** 		put4(psize)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_psize_17806)) {
        *poke4_addr = (unsigned long)_psize_17806;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_psize_17806)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at986_17975);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at986_17975 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at986_17975); // DJP 

    /** end procedure*/
    goto L15; // [1008] 1011
L15: 
    DeRefi(_put4_1__tmp_at986_17975);
    _put4_1__tmp_at986_17975 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_17817); // DJP 

    /** end procedure*/
    goto L16; // [1024] 1027
L16: 
LE: 

    /** 	if new_space then*/
    if (_new_space_17812 == 0) {
        goto L17; // [1032] 1043
    }
    else {
        if (!IS_ATOM_INT(_new_space_17812) && DBL_PTR(_new_space_17812)->dbl == 0.0){
            goto L17; // [1032] 1043
        }
    }

    /** 		db_free(to_be_freed) -- free the old space*/
    Ref(_to_be_freed_17813);
    _48db_free(_to_be_freed_17813);
L17: 

    /** end procedure*/
    DeRef(_p_17805);
    DeRef(_psize_17806);
    DeRef(_i_17807);
    DeRef(_size_17808);
    DeRef(_addr_17809);
    DeRef(_free_list_17810);
    DeRef(_free_list_space_17811);
    DeRef(_new_space_17812);
    DeRef(_to_be_freed_17813);
    DeRef(_prev_addr_17814);
    DeRef(_prev_size_17815);
    DeRef(_remaining_17817);
    DeRef(_10078);
    _10078 = NOVALUE;
    DeRef(_10086);
    _10086 = NOVALUE;
    DeRef(_10102);
    _10102 = NOVALUE;
    return;
    ;
}


void _48save_keys()
{
    int _k_17980 = NOVALUE;
    int _10127 = NOVALUE;
    int _10123 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if caching_option = 1 then*/

    /** 		if current_table_pos > 0 then*/
    if (binary_op_a(LESSEQ, _48current_table_pos_17056, 0)){
        goto L1; // [13] 81
    }

    /** 			k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_48current_table_pos_17056);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _48current_table_pos_17056;
    _10123 = MAKE_SEQ(_1);
    _k_17980 = find_from(_10123, _48cache_index_17064, 1);
    DeRefDS(_10123);
    _10123 = NOVALUE;

    /** 			if k != 0 then*/
    if (_k_17980 == 0)
    goto L2; // [36] 53

    /** 				key_cache[k] = key_pointers*/
    RefDS(_48key_pointers_17062);
    _2 = (int)SEQ_PTR(_48key_cache_17063);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _48key_cache_17063 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _k_17980);
    _1 = *(int *)_2;
    *(int *)_2 = _48key_pointers_17062;
    DeRef(_1);
    goto L3; // [50] 80
L2: 

    /** 				key_cache = append(key_cache, key_pointers)*/
    RefDS(_48key_pointers_17062);
    Append(&_48key_cache_17063, _48key_cache_17063, _48key_pointers_17062);

    /** 				cache_index = append(cache_index, {current_db, current_table_pos})*/
    Ref(_48current_table_pos_17056);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _48current_table_pos_17056;
    _10127 = MAKE_SEQ(_1);
    RefDS(_10127);
    Append(&_48cache_index_17064, _48cache_index_17064, _10127);
    DeRefDS(_10127);
    _10127 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _48db_create(int _path_18077, int _lock_method_18078, int _init_tables_18079, int _init_free_18080)
{
    int _db_18081 = NOVALUE;
    int _lock_file_1__tmp_at222_18122 = NOVALUE;
    int _lock_file_inlined_lock_file_at_222_18121 = NOVALUE;
    int _put4_1__tmp_at342_18131 = NOVALUE;
    int _put4_1__tmp_at370_18133 = NOVALUE;
    int _put4_1__tmp_at413_18139 = NOVALUE;
    int _x_inlined_put4_at_410_18138 = NOVALUE;
    int _put4_1__tmp_at452_18144 = NOVALUE;
    int _x_inlined_put4_at_449_18143 = NOVALUE;
    int _put4_1__tmp_at480_18146 = NOVALUE;
    int _s_inlined_putn_at_516_18150 = NOVALUE;
    int _put4_1__tmp_at548_18155 = NOVALUE;
    int _x_inlined_put4_at_545_18154 = NOVALUE;
    int _s_inlined_putn_at_584_18159 = NOVALUE;
    int _10227 = NOVALUE;
    int _10226 = NOVALUE;
    int _10225 = NOVALUE;
    int _10224 = NOVALUE;
    int _10223 = NOVALUE;
    int _10222 = NOVALUE;
    int _10221 = NOVALUE;
    int _10220 = NOVALUE;
    int _10219 = NOVALUE;
    int _10218 = NOVALUE;
    int _10217 = NOVALUE;
    int _10198 = NOVALUE;
    int _10196 = NOVALUE;
    int _10195 = NOVALUE;
    int _10193 = NOVALUE;
    int _10192 = NOVALUE;
    int _10190 = NOVALUE;
    int _10189 = NOVALUE;
    int _10187 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18081 = find_from(_path_18077, _48Known_Aliases_17076, 1);

    /** 	if db then*/
    if (_db_18081 == 0)
    {
        goto L1; // [20] 94
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10187 = (int)*(((s1_ptr)_2)->base + _db_18081);
    DeRefDS(_path_18077);
    _2 = (int)SEQ_PTR(_10187);
    _path_18077 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18077);
    _10187 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10189 = (int)*(((s1_ptr)_2)->base + _db_18081);
    _2 = (int)SEQ_PTR(_10189);
    _10190 = (int)*(((s1_ptr)_2)->base + 2);
    _10189 = NOVALUE;
    _2 = (int)SEQ_PTR(_10190);
    _lock_method_18078 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18078)){
        _lock_method_18078 = (long)DBL_PTR(_lock_method_18078)->dbl;
    }
    _10190 = NOVALUE;

    /** 		init_tables = Alias_Details[db][2][CONNECT_TABLES]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10192 = (int)*(((s1_ptr)_2)->base + _db_18081);
    _2 = (int)SEQ_PTR(_10192);
    _10193 = (int)*(((s1_ptr)_2)->base + 2);
    _10192 = NOVALUE;
    _2 = (int)SEQ_PTR(_10193);
    _init_tables_18079 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_init_tables_18079)){
        _init_tables_18079 = (long)DBL_PTR(_init_tables_18079)->dbl;
    }
    _10193 = NOVALUE;

    /** 		init_free = Alias_Details[db][2][CONNECT_FREE]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10195 = (int)*(((s1_ptr)_2)->base + _db_18081);
    _2 = (int)SEQ_PTR(_10195);
    _10196 = (int)*(((s1_ptr)_2)->base + 2);
    _10195 = NOVALUE;
    _2 = (int)SEQ_PTR(_10196);
    _init_free_18080 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_init_free_18080)){
        _init_free_18080 = (long)DBL_PTR(_init_free_18080)->dbl;
    }
    _10196 = NOVALUE;
    goto L2; // [91] 134
L1: 

    /** 		path = filesys:canonical_path( defaultext(path, "edb") )*/
    RefDS(_path_18077);
    RefDS(_10181);
    _10198 = _14defaultext(_path_18077, _10181);
    _0 = _path_18077;
    _path_18077 = _14canonical_path(_10198, 0, 0);
    DeRefDS(_0);
    _10198 = NOVALUE;

    /** 		if init_tables < 1 then*/
    if (_init_tables_18079 >= 1)
    goto L3; // [111] 121

    /** 			init_tables = 1*/
    _init_tables_18079 = 1;
L3: 

    /** 		if init_free < 0 then*/
    if (_init_free_18080 >= 0)
    goto L4; // [123] 133

    /** 			init_free = 0*/
    _init_free_18080 = 0;
L4: 
L2: 

    /** 	db = open(path, "rb")*/
    _db_18081 = EOpen(_path_18077, _10202, 0);

    /** 	if db != -1 then*/
    if (_db_18081 == -1)
    goto L5; // [143] 158

    /** 		close(db)*/
    EClose(_db_18081);

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_path_18077);
    return -2;
L5: 

    /** 	db = open(path, "wb")*/
    _db_18081 = EOpen(_path_18077, _10205, 0);

    /** 	if db = -1 then*/
    if (_db_18081 != -1)
    goto L6; // [167] 178

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18077);
    return -1;
L6: 

    /** 	close(db)*/
    EClose(_db_18081);

    /** 	db = open(path, "ub")*/
    _db_18081 = EOpen(_path_18077, _10208, 0);

    /** 	if db = -1 then*/
    if (_db_18081 != -1)
    goto L7; // [191] 202

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18077);
    return -1;
L7: 

    /** 	if lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18078 != 1)
    goto L8; // [204] 214

    /** 		lock_method = DB_LOCK_NO*/
    _lock_method_18078 = 0;
L8: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18078 != 2)
    goto L9; // [216] 248

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at222_18122;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18081;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at222_18122 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_222_18121 = machine(61, _lock_file_1__tmp_at222_18122);
    DeRef(_lock_file_1__tmp_at222_18122);
    _lock_file_1__tmp_at222_18122 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_222_18121 != 0)
    goto LA; // [237] 247

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18077);
    return -3;
LA: 
L9: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db*/
    _48current_db_17055 = _db_18081;

    /** 	current_lock = lock_method*/
    _48current_lock_17061 = _lock_method_18078;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17056);
    _48current_table_pos_17056 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17057);
    _48current_table_name_17057 = _5;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18077);
    Append(&_48db_names_17058, _48db_names_17058, _path_18077);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_48db_lock_methods_17060, _48db_lock_methods_17060, _lock_method_18078);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_48db_file_nums_17059, _48db_file_nums_17059, _db_18081);

    /** 	put1(DB_MAGIC) -- so we know what type of file it is*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17055, 77); // DJP 

    /** end procedure*/
    goto LB; // [309] 312
LB: 

    /** 	put1(DB_MAJOR) -- major version*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17055, 4); // DJP 

    /** end procedure*/
    goto LC; // [323] 326
LC: 

    /** 	put1(DB_MINOR) -- minor version*/

    /** 	puts(current_db, x)*/
    EPuts(_48current_db_17055, 0); // DJP 

    /** end procedure*/
    goto LD; // [337] 340
LD: 

    /** 	put4(19)  -- pointer to tables*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)19;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at342_18131);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at342_18131 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at342_18131); // DJP 

    /** end procedure*/
    goto LE; // [363] 366
LE: 
    DeRefi(_put4_1__tmp_at342_18131);
    _put4_1__tmp_at342_18131 = NOVALUE;

    /** 	put4(0)   -- number of free blocks*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at370_18133);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at370_18133 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at370_18133); // DJP 

    /** end procedure*/
    goto LF; // [391] 394
LF: 
    DeRefi(_put4_1__tmp_at370_18133);
    _put4_1__tmp_at370_18133 = NOVALUE;

    /** 	put4(23 + init_tables * SIZEOF_TABLE_HEADER + 4)   -- pointer to free list*/
    if (_init_tables_18079 == (short)_init_tables_18079)
    _10217 = _init_tables_18079 * 16;
    else
    _10217 = NewDouble(_init_tables_18079 * (double)16);
    if (IS_ATOM_INT(_10217)) {
        _10218 = 23 + _10217;
        if ((long)((unsigned long)_10218 + (unsigned long)HIGH_BITS) >= 0) 
        _10218 = NewDouble((double)_10218);
    }
    else {
        _10218 = NewDouble((double)23 + DBL_PTR(_10217)->dbl);
    }
    DeRef(_10217);
    _10217 = NOVALUE;
    if (IS_ATOM_INT(_10218)) {
        _10219 = _10218 + 4;
        if ((long)((unsigned long)_10219 + (unsigned long)HIGH_BITS) >= 0) 
        _10219 = NewDouble((double)_10219);
    }
    else {
        _10219 = NewDouble(DBL_PTR(_10218)->dbl + (double)4);
    }
    DeRef(_10218);
    _10218 = NOVALUE;
    DeRef(_x_inlined_put4_at_410_18138);
    _x_inlined_put4_at_410_18138 = _10219;
    _10219 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_410_18138)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_410_18138;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_410_18138)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at413_18139);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at413_18139 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at413_18139); // DJP 

    /** end procedure*/
    goto L10; // [434] 437
L10: 
    DeRef(_x_inlined_put4_at_410_18138);
    _x_inlined_put4_at_410_18138 = NOVALUE;
    DeRefi(_put4_1__tmp_at413_18139);
    _put4_1__tmp_at413_18139 = NOVALUE;

    /** 	put4( 8 + init_tables * SIZEOF_TABLE_HEADER)  -- allocated size*/
    if (_init_tables_18079 == (short)_init_tables_18079)
    _10220 = _init_tables_18079 * 16;
    else
    _10220 = NewDouble(_init_tables_18079 * (double)16);
    if (IS_ATOM_INT(_10220)) {
        _10221 = 8 + _10220;
        if ((long)((unsigned long)_10221 + (unsigned long)HIGH_BITS) >= 0) 
        _10221 = NewDouble((double)_10221);
    }
    else {
        _10221 = NewDouble((double)8 + DBL_PTR(_10220)->dbl);
    }
    DeRef(_10220);
    _10220 = NOVALUE;
    DeRef(_x_inlined_put4_at_449_18143);
    _x_inlined_put4_at_449_18143 = _10221;
    _10221 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_449_18143)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_449_18143;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_449_18143)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at452_18144);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at452_18144 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at452_18144); // DJP 

    /** end procedure*/
    goto L11; // [473] 476
L11: 
    DeRef(_x_inlined_put4_at_449_18143);
    _x_inlined_put4_at_449_18143 = NOVALUE;
    DeRefi(_put4_1__tmp_at452_18144);
    _put4_1__tmp_at452_18144 = NOVALUE;

    /** 	put4(0)   -- number of tables that currently exist*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at480_18146);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at480_18146 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at480_18146); // DJP 

    /** end procedure*/
    goto L12; // [501] 504
L12: 
    DeRefi(_put4_1__tmp_at480_18146);
    _put4_1__tmp_at480_18146 = NOVALUE;

    /** 	putn(repeat(0, init_tables * SIZEOF_TABLE_HEADER))*/
    _10222 = _init_tables_18079 * 16;
    _10223 = Repeat(0, _10222);
    _10222 = NOVALUE;
    DeRefi(_s_inlined_putn_at_516_18150);
    _s_inlined_putn_at_516_18150 = _10223;
    _10223 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_516_18150); // DJP 

    /** end procedure*/
    goto L13; // [530] 533
L13: 
    DeRefi(_s_inlined_putn_at_516_18150);
    _s_inlined_putn_at_516_18150 = NOVALUE;

    /** 	put4(4+init_free*8)   -- allocated size*/
    if (_init_free_18080 == (short)_init_free_18080)
    _10224 = _init_free_18080 * 8;
    else
    _10224 = NewDouble(_init_free_18080 * (double)8);
    if (IS_ATOM_INT(_10224)) {
        _10225 = 4 + _10224;
        if ((long)((unsigned long)_10225 + (unsigned long)HIGH_BITS) >= 0) 
        _10225 = NewDouble((double)_10225);
    }
    else {
        _10225 = NewDouble((double)4 + DBL_PTR(_10224)->dbl);
    }
    DeRef(_10224);
    _10224 = NOVALUE;
    DeRef(_x_inlined_put4_at_545_18154);
    _x_inlined_put4_at_545_18154 = _10225;
    _10225 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_545_18154)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_545_18154;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_545_18154)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at548_18155);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at548_18155 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at548_18155); // DJP 

    /** end procedure*/
    goto L14; // [569] 572
L14: 
    DeRef(_x_inlined_put4_at_545_18154);
    _x_inlined_put4_at_545_18154 = NOVALUE;
    DeRefi(_put4_1__tmp_at548_18155);
    _put4_1__tmp_at548_18155 = NOVALUE;

    /** 	putn(repeat(0, init_free * 8))*/
    _10226 = _init_free_18080 * 8;
    _10227 = Repeat(0, _10226);
    _10226 = NOVALUE;
    DeRefi(_s_inlined_putn_at_584_18159);
    _s_inlined_putn_at_584_18159 = _10227;
    _10227 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_584_18159); // DJP 

    /** end procedure*/
    goto L15; // [598] 601
L15: 
    DeRefi(_s_inlined_putn_at_584_18159);
    _s_inlined_putn_at_584_18159 = NOVALUE;

    /** 	return DB_OK*/
    DeRefDS(_path_18077);
    return 0;
    ;
}


int _48db_open(int _path_18162, int _lock_method_18163)
{
    int _db_18164 = NOVALUE;
    int _magic_18165 = NOVALUE;
    int _lock_file_1__tmp_at129_18190 = NOVALUE;
    int _lock_file_inlined_lock_file_at_129_18189 = NOVALUE;
    int _lock_file_1__tmp_at169_18197 = NOVALUE;
    int _lock_file_inlined_lock_file_at_169_18196 = NOVALUE;
    int _10238 = NOVALUE;
    int _10236 = NOVALUE;
    int _10234 = NOVALUE;
    int _10232 = NOVALUE;
    int _10231 = NOVALUE;
    int _10229 = NOVALUE;
    int _0, _1, _2;
    

    /** 	db = find(path, Known_Aliases)*/
    _db_18164 = find_from(_path_18162, _48Known_Aliases_17076, 1);

    /** 	if db then*/
    if (_db_18164 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[db][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10229 = (int)*(((s1_ptr)_2)->base + _db_18164);
    DeRefDS(_path_18162);
    _2 = (int)SEQ_PTR(_10229);
    _path_18162 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18162);
    _10229 = NOVALUE;

    /** 		lock_method = Alias_Details[db][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10231 = (int)*(((s1_ptr)_2)->base + _db_18164);
    _2 = (int)SEQ_PTR(_10231);
    _10232 = (int)*(((s1_ptr)_2)->base + 2);
    _10231 = NOVALUE;
    _2 = (int)SEQ_PTR(_10232);
    _lock_method_18163 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18163)){
        _lock_method_18163 = (long)DBL_PTR(_lock_method_18163)->dbl;
    }
    _10232 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18162);
    RefDS(_10181);
    _10234 = _14defaultext(_path_18162, _10181);
    _0 = _path_18162;
    _path_18162 = _14canonical_path(_10234, 0, 0);
    DeRefDS(_0);
    _10234 = NOVALUE;
L2: 

    /** 	if lock_method = DB_LOCK_NO or*/
    _10236 = (_lock_method_18163 == 0);
    if (_10236 != 0) {
        goto L3; // [76] 89
    }
    _10238 = (_lock_method_18163 == 2);
    if (_10238 == 0)
    {
        DeRef(_10238);
        _10238 = NOVALUE;
        goto L4; // [85] 99
    }
    else{
        DeRef(_10238);
        _10238 = NOVALUE;
    }
L3: 

    /** 		db = open(path, "ub")*/
    _db_18164 = EOpen(_path_18162, _10208, 0);
    goto L5; // [96] 107
L4: 

    /** 		db = open(path, "rb")*/
    _db_18164 = EOpen(_path_18162, _10202, 0);
L5: 

    /** ifdef WINDOWS then*/

    /** 	if db = -1 then*/
    if (_db_18164 != -1)
    goto L6; // [111] 122

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18162);
    DeRef(_10236);
    _10236 = NOVALUE;
    return -1;
L6: 

    /** 	if lock_method = DB_LOCK_EXCLUSIVE then*/
    if (_lock_method_18163 != 2)
    goto L7; // [124] 162

    /** 		if not io:lock_file(db, io:LOCK_EXCLUSIVE, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at129_18190;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18164;
    *((int *)(_2+8)) = 2;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at129_18190 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_129_18189 = machine(61, _lock_file_1__tmp_at129_18190);
    DeRef(_lock_file_1__tmp_at129_18190);
    _lock_file_1__tmp_at129_18190 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_129_18189 != 0)
    goto L8; // [145] 201

    /** 			close(db)*/
    EClose(_db_18164);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18162);
    DeRef(_10236);
    _10236 = NOVALUE;
    return -3;
    goto L8; // [159] 201
L7: 

    /** 	elsif lock_method = DB_LOCK_SHARED then*/
    if (_lock_method_18163 != 1)
    goto L9; // [164] 200

    /** 		if not io:lock_file(db, io:LOCK_SHARED, {}) then*/

    /** 	return machine_func(M_LOCK_FILE, {fn, t, r})*/
    _0 = _lock_file_1__tmp_at169_18197;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _db_18164;
    *((int *)(_2+8)) = 1;
    RefDS(_5);
    *((int *)(_2+12)) = _5;
    _lock_file_1__tmp_at169_18197 = MAKE_SEQ(_1);
    DeRef(_0);
    _lock_file_inlined_lock_file_at_169_18196 = machine(61, _lock_file_1__tmp_at169_18197);
    DeRef(_lock_file_1__tmp_at169_18197);
    _lock_file_1__tmp_at169_18197 = NOVALUE;
    if (_lock_file_inlined_lock_file_at_169_18196 != 0)
    goto LA; // [185] 199

    /** 			close(db)*/
    EClose(_db_18164);

    /** 			return DB_LOCK_FAIL*/
    DeRefDS(_path_18162);
    DeRef(_10236);
    _10236 = NOVALUE;
    return -3;
LA: 
L9: 
L8: 

    /** 	magic = getc(db)*/
    if (_db_18164 != last_r_file_no) {
        last_r_file_ptr = which_file(_db_18164, EF_READ);
        last_r_file_no = _db_18164;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _magic_18165 = getc((FILE*)xstdin);
        }
        else
        _magic_18165 = getc(last_r_file_ptr);
    }
    else
    _magic_18165 = getc(last_r_file_ptr);

    /** 	if magic != DB_MAGIC then*/
    if (_magic_18165 == 77)
    goto LB; // [208] 223

    /** 		close(db)*/
    EClose(_db_18164);

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_path_18162);
    DeRef(_10236);
    _10236 = NOVALUE;
    return -1;
LB: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db */
    _48current_db_17055 = _db_18164;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17056);
    _48current_table_pos_17056 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17057);
    _48current_table_name_17057 = _5;

    /** 	current_lock = lock_method*/
    _48current_lock_17061 = _lock_method_18163;

    /** 	db_names = append(db_names, path)*/
    RefDS(_path_18162);
    Append(&_48db_names_17058, _48db_names_17058, _path_18162);

    /** 	db_lock_methods = append(db_lock_methods, lock_method)*/
    Append(&_48db_lock_methods_17060, _48db_lock_methods_17060, _lock_method_18163);

    /** 	db_file_nums = append(db_file_nums, db)*/
    Append(&_48db_file_nums_17059, _48db_file_nums_17059, _db_18164);

    /** 	return DB_OK*/
    DeRefDS(_path_18162);
    DeRef(_10236);
    _10236 = NOVALUE;
    return 0;
    ;
}


int _48db_select(int _path_18207, int _lock_method_18208)
{
    int _index_18209 = NOVALUE;
    int _10257 = NOVALUE;
    int _10255 = NOVALUE;
    int _10254 = NOVALUE;
    int _10252 = NOVALUE;
    int _0, _1, _2;
    

    /** 	index = find(path, Known_Aliases)*/
    _index_18209 = find_from(_path_18207, _48Known_Aliases_17076, 1);

    /** 	if index then*/
    if (_index_18209 == 0)
    {
        goto L1; // [16] 54
    }
    else{
    }

    /** 		path = Alias_Details[index][1]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10252 = (int)*(((s1_ptr)_2)->base + _index_18209);
    DeRefDS(_path_18207);
    _2 = (int)SEQ_PTR(_10252);
    _path_18207 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_path_18207);
    _10252 = NOVALUE;

    /** 		lock_method = Alias_Details[index][2][CONNECT_LOCK]*/
    _2 = (int)SEQ_PTR(_48Alias_Details_17077);
    _10254 = (int)*(((s1_ptr)_2)->base + _index_18209);
    _2 = (int)SEQ_PTR(_10254);
    _10255 = (int)*(((s1_ptr)_2)->base + 2);
    _10254 = NOVALUE;
    _2 = (int)SEQ_PTR(_10255);
    _lock_method_18208 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_lock_method_18208)){
        _lock_method_18208 = (long)DBL_PTR(_lock_method_18208)->dbl;
    }
    _10255 = NOVALUE;
    goto L2; // [51] 70
L1: 

    /** 		path = filesys:canonical_path( filesys:defaultext(path, "edb") )*/
    RefDS(_path_18207);
    RefDS(_10181);
    _10257 = _14defaultext(_path_18207, _10181);
    _0 = _path_18207;
    _path_18207 = _14canonical_path(_10257, 0, 0);
    DeRefDS(_0);
    _10257 = NOVALUE;
L2: 

    /** 	index = eu:find(path, db_names)*/
    _index_18209 = find_from(_path_18207, _48db_names_17058, 1);

    /** 	if index = 0 then*/
    if (_index_18209 != 0)
    goto L3; // [81] 130

    /** 		if lock_method = -1 then*/
    if (_lock_method_18208 != -1)
    goto L4; // [87] 98

    /** 			return DB_OPEN_FAIL*/
    DeRefDS(_path_18207);
    return -1;
L4: 

    /** 		index = db_open(path, lock_method)*/
    RefDS(_path_18207);
    _index_18209 = _48db_open(_path_18207, _lock_method_18208);
    if (!IS_ATOM_INT(_index_18209)) {
        _1 = (long)(DBL_PTR(_index_18209)->dbl);
        DeRefDS(_index_18209);
        _index_18209 = _1;
    }

    /** 		if index != DB_OK then*/
    if (_index_18209 == 0)
    goto L5; // [109] 120

    /** 			return index*/
    DeRefDS(_path_18207);
    return _index_18209;
L5: 

    /** 		index = eu:find(path, db_names)*/
    _index_18209 = find_from(_path_18207, _48db_names_17058, 1);
L3: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_db = db_file_nums[index]*/
    _2 = (int)SEQ_PTR(_48db_file_nums_17059);
    _48current_db_17055 = (int)*(((s1_ptr)_2)->base + _index_18209);
    if (!IS_ATOM_INT(_48current_db_17055))
    _48current_db_17055 = (long)DBL_PTR(_48current_db_17055)->dbl;

    /** 	current_lock = db_lock_methods[index]*/
    _2 = (int)SEQ_PTR(_48db_lock_methods_17060);
    _48current_lock_17061 = (int)*(((s1_ptr)_2)->base + _index_18209);
    if (!IS_ATOM_INT(_48current_lock_17061))
    _48current_lock_17061 = (long)DBL_PTR(_48current_lock_17061)->dbl;

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17056);
    _48current_table_pos_17056 = -1;

    /** 	current_table_name = ""*/
    RefDS(_5);
    DeRef(_48current_table_name_17057);
    _48current_table_name_17057 = _5;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_48key_pointers_17062);
    _48key_pointers_17062 = _5;

    /** 	return DB_OK*/
    DeRefDS(_path_18207);
    return 0;
    ;
}


void _48db_close()
{
    int _unlock_file_1__tmp_at25_18238 = NOVALUE;
    int _index_18233 = NOVALUE;
    int _10274 = NOVALUE;
    int _10273 = NOVALUE;
    int _10272 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if current_db = -1 then*/
    if (_48current_db_17055 != -1)
    goto L1; // [5] 15

    /** 		return*/
    return;
L1: 

    /** 	if current_lock then*/
    if (_48current_lock_17061 == 0)
    {
        goto L2; // [19] 43
    }
    else{
    }

    /** 		io:unlock_file(current_db, {})*/

    /** 	machine_proc(M_UNLOCK_FILE, {fn, r})*/
    RefDS(_5);
    DeRef(_unlock_file_1__tmp_at25_18238);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _5;
    _unlock_file_1__tmp_at25_18238 = MAKE_SEQ(_1);
    machine(62, _unlock_file_1__tmp_at25_18238);

    /** end procedure*/
    goto L3; // [37] 40
L3: 
    DeRef(_unlock_file_1__tmp_at25_18238);
    _unlock_file_1__tmp_at25_18238 = NOVALUE;
L2: 

    /** 	close(current_db)*/
    EClose(_48current_db_17055);

    /** 	index = eu:find(current_db, db_file_nums)*/
    _index_18233 = find_from(_48current_db_17055, _48db_file_nums_17059, 1);

    /** 	db_names = remove(db_names, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_names_17058);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        int stop = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_names_17058), start, &_48db_names_17058 );
            }
            else Tail(SEQ_PTR(_48db_names_17058), stop+1, &_48db_names_17058);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_names_17058), start, &_48db_names_17058);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_names_17058 = Remove_elements(start, stop, (SEQ_PTR(_48db_names_17058)->ref == 1));
        }
    }

    /** 	db_file_nums = remove(db_file_nums, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_file_nums_17059);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        int stop = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_file_nums_17059), start, &_48db_file_nums_17059 );
            }
            else Tail(SEQ_PTR(_48db_file_nums_17059), stop+1, &_48db_file_nums_17059);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_file_nums_17059), start, &_48db_file_nums_17059);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_file_nums_17059 = Remove_elements(start, stop, (SEQ_PTR(_48db_file_nums_17059)->ref == 1));
        }
    }

    /** 	db_lock_methods = remove(db_lock_methods, index)*/
    {
        s1_ptr assign_space = SEQ_PTR(_48db_lock_methods_17060);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        int stop = (IS_ATOM_INT(_index_18233)) ? _index_18233 : (long)(DBL_PTR(_index_18233)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_48db_lock_methods_17060), start, &_48db_lock_methods_17060 );
            }
            else Tail(SEQ_PTR(_48db_lock_methods_17060), stop+1, &_48db_lock_methods_17060);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_48db_lock_methods_17060), start, &_48db_lock_methods_17060);
        }
        else {
            assign_slice_seq = &assign_space;
            _48db_lock_methods_17060 = Remove_elements(start, stop, (SEQ_PTR(_48db_lock_methods_17060)->ref == 1));
        }
    }

    /** 	for i = length(cache_index) to 1 by -1 do*/
    if (IS_SEQUENCE(_48cache_index_17064)){
            _10272 = SEQ_PTR(_48cache_index_17064)->length;
    }
    else {
        _10272 = 1;
    }
    {
        int _i_18244;
        _i_18244 = _10272;
L4: 
        if (_i_18244 < 1){
            goto L5; // [94] 145
        }

        /** 		if cache_index[i][1] = current_db then*/
        _2 = (int)SEQ_PTR(_48cache_index_17064);
        _10273 = (int)*(((s1_ptr)_2)->base + _i_18244);
        _2 = (int)SEQ_PTR(_10273);
        _10274 = (int)*(((s1_ptr)_2)->base + 1);
        _10273 = NOVALUE;
        if (binary_op_a(NOTEQ, _10274, _48current_db_17055)){
            _10274 = NOVALUE;
            goto L6; // [115] 138
        }
        _10274 = NOVALUE;

        /** 			cache_index = remove(cache_index, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_48cache_index_17064);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18244)) ? _i_18244 : (long)(DBL_PTR(_i_18244)->dbl);
            int stop = (IS_ATOM_INT(_i_18244)) ? _i_18244 : (long)(DBL_PTR(_i_18244)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_48cache_index_17064), start, &_48cache_index_17064 );
                }
                else Tail(SEQ_PTR(_48cache_index_17064), stop+1, &_48cache_index_17064);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_48cache_index_17064), start, &_48cache_index_17064);
            }
            else {
                assign_slice_seq = &assign_space;
                _48cache_index_17064 = Remove_elements(start, stop, (SEQ_PTR(_48cache_index_17064)->ref == 1));
            }
        }

        /** 			key_cache = remove(key_cache, i)*/
        {
            s1_ptr assign_space = SEQ_PTR(_48key_cache_17063);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_18244)) ? _i_18244 : (long)(DBL_PTR(_i_18244)->dbl);
            int stop = (IS_ATOM_INT(_i_18244)) ? _i_18244 : (long)(DBL_PTR(_i_18244)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_48key_cache_17063), start, &_48key_cache_17063 );
                }
                else Tail(SEQ_PTR(_48key_cache_17063), stop+1, &_48key_cache_17063);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_48key_cache_17063), start, &_48key_cache_17063);
            }
            else {
                assign_slice_seq = &assign_space;
                _48key_cache_17063 = Remove_elements(start, stop, (SEQ_PTR(_48key_cache_17063)->ref == 1));
            }
        }
L6: 

        /** 	end for*/
        _i_18244 = _i_18244 + -1;
        goto L4; // [140] 101
L5: 
        ;
    }

    /** 	current_table_pos = -1*/
    DeRef(_48current_table_pos_17056);
    _48current_table_pos_17056 = -1;

    /** 	current_table_name = ""	*/
    RefDS(_5);
    DeRef(_48current_table_name_17057);
    _48current_table_name_17057 = _5;

    /** 	current_db = -1*/
    _48current_db_17055 = -1;

    /** 	key_pointers = {}*/
    RefDS(_5);
    DeRef(_48key_pointers_17062);
    _48key_pointers_17062 = _5;

    /** end procedure*/
    return;
    ;
}


int _48table_find(int _name_18254)
{
    int _tables_18255 = NOVALUE;
    int _nt_18256 = NOVALUE;
    int _t_header_18257 = NOVALUE;
    int _name_ptr_18258 = NOVALUE;
    int _seek_1__tmp_at6_18261 = NOVALUE;
    int _seek_inlined_seek_at_6_18260 = NOVALUE;
    int _seek_1__tmp_at44_18268 = NOVALUE;
    int _seek_inlined_seek_at_44_18267 = NOVALUE;
    int _seek_1__tmp_at84_18276 = NOVALUE;
    int _seek_inlined_seek_at_84_18275 = NOVALUE;
    int _seek_1__tmp_at106_18280 = NOVALUE;
    int _seek_inlined_seek_at_106_18279 = NOVALUE;
    int _10285 = NOVALUE;
    int _10283 = NOVALUE;
    int _10278 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at6_18261);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at6_18261 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_6_18260 = machine(19, _seek_1__tmp_at6_18261);
    DeRefi(_seek_1__tmp_at6_18261);
    _seek_1__tmp_at6_18261 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_48vLastErrors_17079)){
            _10278 = SEQ_PTR(_48vLastErrors_17079)->length;
    }
    else {
        _10278 = 1;
    }
    if (_10278 <= 0)
    goto L1; // [27] 36
    DeRefDS(_name_18254);
    DeRef(_tables_18255);
    DeRef(_nt_18256);
    DeRef(_t_header_18257);
    DeRef(_name_ptr_18258);
    return -1;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18255;
    _tables_18255 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18255);
    DeRef(_seek_1__tmp_at44_18268);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _tables_18255;
    _seek_1__tmp_at44_18268 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_44_18267 = machine(19, _seek_1__tmp_at44_18268);
    DeRef(_seek_1__tmp_at44_18268);
    _seek_1__tmp_at44_18268 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18256;
    _nt_18256 = _48get4();
    DeRef(_0);

    /** 	t_header = tables+4*/
    DeRef(_t_header_18257);
    if (IS_ATOM_INT(_tables_18255)) {
        _t_header_18257 = _tables_18255 + 4;
        if ((long)((unsigned long)_t_header_18257 + (unsigned long)HIGH_BITS) >= 0) 
        _t_header_18257 = NewDouble((double)_t_header_18257);
    }
    else {
        _t_header_18257 = NewDouble(DBL_PTR(_tables_18255)->dbl + (double)4);
    }

    /** 	for i = 1 to nt do*/
    Ref(_nt_18256);
    DeRef(_10283);
    _10283 = _nt_18256;
    {
        int _i_18272;
        _i_18272 = 1;
L2: 
        if (binary_op_a(GREATER, _i_18272, _10283)){
            goto L3; // [74] 150
        }

        /** 		io:seek(current_db, t_header)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_t_header_18257);
        DeRef(_seek_1__tmp_at84_18276);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _t_header_18257;
        _seek_1__tmp_at84_18276 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_84_18275 = machine(19, _seek_1__tmp_at84_18276);
        DeRef(_seek_1__tmp_at84_18276);
        _seek_1__tmp_at84_18276 = NOVALUE;

        /** 		name_ptr = get4()*/
        _0 = _name_ptr_18258;
        _name_ptr_18258 = _48get4();
        DeRef(_0);

        /** 		io:seek(current_db, name_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_ptr_18258);
        DeRef(_seek_1__tmp_at106_18280);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _name_ptr_18258;
        _seek_1__tmp_at106_18280 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_106_18279 = machine(19, _seek_1__tmp_at106_18280);
        DeRef(_seek_1__tmp_at106_18280);
        _seek_1__tmp_at106_18280 = NOVALUE;

        /** 		if equal_string(name) > 0 then*/
        RefDS(_name_18254);
        _10285 = _48equal_string(_name_18254);
        if (binary_op_a(LESSEQ, _10285, 0)){
            DeRef(_10285);
            _10285 = NOVALUE;
            goto L4; // [126] 137
        }
        DeRef(_10285);
        _10285 = NOVALUE;

        /** 			return t_header*/
        DeRef(_i_18272);
        DeRefDS(_name_18254);
        DeRef(_tables_18255);
        DeRef(_nt_18256);
        DeRef(_name_ptr_18258);
        return _t_header_18257;
L4: 

        /** 		t_header += SIZEOF_TABLE_HEADER*/
        _0 = _t_header_18257;
        if (IS_ATOM_INT(_t_header_18257)) {
            _t_header_18257 = _t_header_18257 + 16;
            if ((long)((unsigned long)_t_header_18257 + (unsigned long)HIGH_BITS) >= 0) 
            _t_header_18257 = NewDouble((double)_t_header_18257);
        }
        else {
            _t_header_18257 = NewDouble(DBL_PTR(_t_header_18257)->dbl + (double)16);
        }
        DeRef(_0);

        /** 	end for*/
        _0 = _i_18272;
        if (IS_ATOM_INT(_i_18272)) {
            _i_18272 = _i_18272 + 1;
            if ((long)((unsigned long)_i_18272 +(unsigned long) HIGH_BITS) >= 0){
                _i_18272 = NewDouble((double)_i_18272);
            }
        }
        else {
            _i_18272 = binary_op_a(PLUS, _i_18272, 1);
        }
        DeRef(_0);
        goto L2; // [145] 81
L3: 
        ;
        DeRef(_i_18272);
    }

    /** 	return -1*/
    DeRefDS(_name_18254);
    DeRef(_tables_18255);
    DeRef(_nt_18256);
    DeRef(_t_header_18257);
    DeRef(_name_ptr_18258);
    return -1;
    ;
}


int _48db_select_table(int _name_18287)
{
    int _table_18288 = NOVALUE;
    int _nkeys_18289 = NOVALUE;
    int _index_18290 = NOVALUE;
    int _block_ptr_18291 = NOVALUE;
    int _block_size_18292 = NOVALUE;
    int _blocks_18293 = NOVALUE;
    int _k_18294 = NOVALUE;
    int _seek_1__tmp_at120_18313 = NOVALUE;
    int _seek_inlined_seek_at_120_18312 = NOVALUE;
    int _pos_inlined_seek_at_117_18311 = NOVALUE;
    int _seek_1__tmp_at178_18323 = NOVALUE;
    int _seek_inlined_seek_at_178_18322 = NOVALUE;
    int _seek_1__tmp_at205_18328 = NOVALUE;
    int _seek_inlined_seek_at_205_18327 = NOVALUE;
    int _10306 = NOVALUE;
    int _10305 = NOVALUE;
    int _10302 = NOVALUE;
    int _10297 = NOVALUE;
    int _10292 = NOVALUE;
    int _10288 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal(current_table_name, name) then*/
    if (_48current_table_name_17057 == _name_18287)
    _10288 = 1;
    else if (IS_ATOM_INT(_48current_table_name_17057) && IS_ATOM_INT(_name_18287))
    _10288 = 0;
    else
    _10288 = (compare(_48current_table_name_17057, _name_18287) == 0);
    if (_10288 == 0)
    {
        _10288 = NOVALUE;
        goto L1; // [11] 21
    }
    else{
        _10288 = NOVALUE;
    }

    /** 		return DB_OK*/
    DeRefDS(_name_18287);
    DeRef(_table_18288);
    DeRef(_nkeys_18289);
    DeRef(_index_18290);
    DeRef(_block_ptr_18291);
    DeRef(_block_size_18292);
    return 0;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18287);
    _0 = _table_18288;
    _table_18288 = _48table_find(_name_18287);
    DeRef(_0);

    /** 	if table = -1 then*/
    if (binary_op_a(NOTEQ, _table_18288, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_OPEN_FAIL*/
    DeRefDS(_name_18287);
    DeRef(_table_18288);
    DeRef(_nkeys_18289);
    DeRef(_index_18290);
    DeRef(_block_ptr_18291);
    DeRef(_block_size_18292);
    return -1;
L2: 

    /** 	save_keys()*/
    _48save_keys();

    /** 	current_table_pos = table*/
    Ref(_table_18288);
    DeRef(_48current_table_pos_17056);
    _48current_table_pos_17056 = _table_18288;

    /** 	current_table_name = name*/
    RefDS(_name_18287);
    DeRef(_48current_table_name_17057);
    _48current_table_name_17057 = _name_18287;

    /** 	k = 0*/
    _k_18294 = 0;

    /** 	if caching_option = 1 then*/

    /** 		k = eu:find({current_db, current_table_pos}, cache_index)*/
    Ref(_48current_table_pos_17056);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _48current_table_pos_17056;
    _10292 = MAKE_SEQ(_1);
    _k_18294 = find_from(_10292, _48cache_index_17064, 1);
    DeRefDS(_10292);
    _10292 = NOVALUE;

    /** 		if k != 0 then*/
    if (_k_18294 == 0)
    goto L3; // [88] 103

    /** 			key_pointers = key_cache[k]*/
    DeRef(_48key_pointers_17062);
    _2 = (int)SEQ_PTR(_48key_cache_17063);
    _48key_pointers_17062 = (int)*(((s1_ptr)_2)->base + _k_18294);
    Ref(_48key_pointers_17062);
L3: 

    /** 	if k = 0 then*/
    if (_k_18294 != 0)
    goto L4; // [106] 269

    /** 		io:seek(current_db, table+4)*/
    if (IS_ATOM_INT(_table_18288)) {
        _10297 = _table_18288 + 4;
        if ((long)((unsigned long)_10297 + (unsigned long)HIGH_BITS) >= 0) 
        _10297 = NewDouble((double)_10297);
    }
    else {
        _10297 = NewDouble(DBL_PTR(_table_18288)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_117_18311);
    _pos_inlined_seek_at_117_18311 = _10297;
    _10297 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_117_18311);
    DeRef(_seek_1__tmp_at120_18313);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_117_18311;
    _seek_1__tmp_at120_18313 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_120_18312 = machine(19, _seek_1__tmp_at120_18313);
    DeRef(_pos_inlined_seek_at_117_18311);
    _pos_inlined_seek_at_117_18311 = NOVALUE;
    DeRef(_seek_1__tmp_at120_18313);
    _seek_1__tmp_at120_18313 = NOVALUE;

    /** 		nkeys = get4()*/
    _0 = _nkeys_18289;
    _nkeys_18289 = _48get4();
    DeRef(_0);

    /** 		blocks = get4()*/
    _blocks_18293 = _48get4();
    if (!IS_ATOM_INT(_blocks_18293)) {
        _1 = (long)(DBL_PTR(_blocks_18293)->dbl);
        DeRefDS(_blocks_18293);
        _blocks_18293 = _1;
    }

    /** 		index = get4()*/
    _0 = _index_18290;
    _index_18290 = _48get4();
    DeRef(_0);

    /** 		key_pointers = repeat(0, nkeys)*/
    DeRef(_48key_pointers_17062);
    _48key_pointers_17062 = Repeat(0, _nkeys_18289);

    /** 		k = 1*/
    _k_18294 = 1;

    /** 		for b = 0 to blocks-1 do*/
    _10302 = _blocks_18293 - 1;
    if ((long)((unsigned long)_10302 +(unsigned long) HIGH_BITS) >= 0){
        _10302 = NewDouble((double)_10302);
    }
    {
        int _b_18319;
        _b_18319 = 0;
L5: 
        if (binary_op_a(GREATER, _b_18319, _10302)){
            goto L6; // [168] 268
        }

        /** 			io:seek(current_db, index)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_index_18290);
        DeRef(_seek_1__tmp_at178_18323);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _index_18290;
        _seek_1__tmp_at178_18323 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_178_18322 = machine(19, _seek_1__tmp_at178_18323);
        DeRef(_seek_1__tmp_at178_18323);
        _seek_1__tmp_at178_18323 = NOVALUE;

        /** 			block_size = get4()*/
        _0 = _block_size_18292;
        _block_size_18292 = _48get4();
        DeRef(_0);

        /** 			block_ptr = get4()*/
        _0 = _block_ptr_18291;
        _block_ptr_18291 = _48get4();
        DeRef(_0);

        /** 			io:seek(current_db, block_ptr)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_block_ptr_18291);
        DeRef(_seek_1__tmp_at205_18328);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _block_ptr_18291;
        _seek_1__tmp_at205_18328 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_205_18327 = machine(19, _seek_1__tmp_at205_18328);
        DeRef(_seek_1__tmp_at205_18328);
        _seek_1__tmp_at205_18328 = NOVALUE;

        /** 			for j = 1 to block_size do*/
        Ref(_block_size_18292);
        DeRef(_10305);
        _10305 = _block_size_18292;
        {
            int _j_18330;
            _j_18330 = 1;
L7: 
            if (binary_op_a(GREATER, _j_18330, _10305)){
                goto L8; // [224] 255
            }

            /** 				key_pointers[k] = get4()*/
            _10306 = _48get4();
            _2 = (int)SEQ_PTR(_48key_pointers_17062);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _48key_pointers_17062 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _k_18294);
            _1 = *(int *)_2;
            *(int *)_2 = _10306;
            if( _1 != _10306 ){
                DeRef(_1);
            }
            _10306 = NOVALUE;

            /** 				k += 1*/
            _k_18294 = _k_18294 + 1;

            /** 			end for*/
            _0 = _j_18330;
            if (IS_ATOM_INT(_j_18330)) {
                _j_18330 = _j_18330 + 1;
                if ((long)((unsigned long)_j_18330 +(unsigned long) HIGH_BITS) >= 0){
                    _j_18330 = NewDouble((double)_j_18330);
                }
            }
            else {
                _j_18330 = binary_op_a(PLUS, _j_18330, 1);
            }
            DeRef(_0);
            goto L7; // [250] 231
L8: 
            ;
            DeRef(_j_18330);
        }

        /** 			index += 8*/
        _0 = _index_18290;
        if (IS_ATOM_INT(_index_18290)) {
            _index_18290 = _index_18290 + 8;
            if ((long)((unsigned long)_index_18290 + (unsigned long)HIGH_BITS) >= 0) 
            _index_18290 = NewDouble((double)_index_18290);
        }
        else {
            _index_18290 = NewDouble(DBL_PTR(_index_18290)->dbl + (double)8);
        }
        DeRef(_0);

        /** 		end for*/
        _0 = _b_18319;
        if (IS_ATOM_INT(_b_18319)) {
            _b_18319 = _b_18319 + 1;
            if ((long)((unsigned long)_b_18319 +(unsigned long) HIGH_BITS) >= 0){
                _b_18319 = NewDouble((double)_b_18319);
            }
        }
        else {
            _b_18319 = binary_op_a(PLUS, _b_18319, 1);
        }
        DeRef(_0);
        goto L5; // [263] 175
L6: 
        ;
        DeRef(_b_18319);
    }
L4: 

    /** 	return DB_OK*/
    DeRefDS(_name_18287);
    DeRef(_table_18288);
    DeRef(_nkeys_18289);
    DeRef(_index_18290);
    DeRef(_block_ptr_18291);
    DeRef(_block_size_18292);
    DeRef(_10302);
    _10302 = NOVALUE;
    return 0;
    ;
}


int _48db_create_table(int _name_18339, int _init_records_18340)
{
    int _name_ptr_18341 = NOVALUE;
    int _nt_18342 = NOVALUE;
    int _tables_18343 = NOVALUE;
    int _newtables_18344 = NOVALUE;
    int _table_18345 = NOVALUE;
    int _records_ptr_18346 = NOVALUE;
    int _size_18347 = NOVALUE;
    int _newsize_18348 = NOVALUE;
    int _index_ptr_18349 = NOVALUE;
    int _remaining_18350 = NOVALUE;
    int _init_index_18351 = NOVALUE;
    int _seek_1__tmp_at68_18365 = NOVALUE;
    int _seek_inlined_seek_at_68_18364 = NOVALUE;
    int _seek_1__tmp_at97_18371 = NOVALUE;
    int _seek_inlined_seek_at_97_18370 = NOVALUE;
    int _pos_inlined_seek_at_94_18369 = NOVALUE;
    int _put4_1__tmp_at159_18384 = NOVALUE;
    int _seek_1__tmp_at196_18389 = NOVALUE;
    int _seek_inlined_seek_at_196_18388 = NOVALUE;
    int _pos_inlined_seek_at_193_18387 = NOVALUE;
    int _seek_1__tmp_at239_18397 = NOVALUE;
    int _seek_inlined_seek_at_239_18396 = NOVALUE;
    int _pos_inlined_seek_at_236_18395 = NOVALUE;
    int _s_inlined_putn_at_288_18405 = NOVALUE;
    int _seek_1__tmp_at316_18408 = NOVALUE;
    int _seek_inlined_seek_at_316_18407 = NOVALUE;
    int _put4_1__tmp_at331_18410 = NOVALUE;
    int _seek_1__tmp_at369_18414 = NOVALUE;
    int _seek_inlined_seek_at_369_18413 = NOVALUE;
    int _put4_1__tmp_at384_18416 = NOVALUE;
    int _s_inlined_putn_at_431_18422 = NOVALUE;
    int _put4_1__tmp_at462_18426 = NOVALUE;
    int _put4_1__tmp_at490_18428 = NOVALUE;
    int _s_inlined_putn_at_530_18433 = NOVALUE;
    int _s_inlined_putn_at_568_18439 = NOVALUE;
    int _seek_1__tmp_at610_18447 = NOVALUE;
    int _seek_inlined_seek_at_610_18446 = NOVALUE;
    int _pos_inlined_seek_at_607_18445 = NOVALUE;
    int _put4_1__tmp_at625_18449 = NOVALUE;
    int _put4_1__tmp_at653_18451 = NOVALUE;
    int _put4_1__tmp_at681_18453 = NOVALUE;
    int _put4_1__tmp_at709_18455 = NOVALUE;
    int _10355 = NOVALUE;
    int _10354 = NOVALUE;
    int _10353 = NOVALUE;
    int _10352 = NOVALUE;
    int _10351 = NOVALUE;
    int _10350 = NOVALUE;
    int _10348 = NOVALUE;
    int _10347 = NOVALUE;
    int _10346 = NOVALUE;
    int _10345 = NOVALUE;
    int _10344 = NOVALUE;
    int _10342 = NOVALUE;
    int _10341 = NOVALUE;
    int _10340 = NOVALUE;
    int _10338 = NOVALUE;
    int _10337 = NOVALUE;
    int _10336 = NOVALUE;
    int _10335 = NOVALUE;
    int _10334 = NOVALUE;
    int _10333 = NOVALUE;
    int _10332 = NOVALUE;
    int _10330 = NOVALUE;
    int _10329 = NOVALUE;
    int _10328 = NOVALUE;
    int _10325 = NOVALUE;
    int _10324 = NOVALUE;
    int _10322 = NOVALUE;
    int _10321 = NOVALUE;
    int _10319 = NOVALUE;
    int _10317 = NOVALUE;
    int _10314 = NOVALUE;
    int _10309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not cstring(name) then*/
    RefDS(_name_18339);
    _10309 = _9cstring(_name_18339);
    if (IS_ATOM_INT(_10309)) {
        if (_10309 != 0){
            DeRef(_10309);
            _10309 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    else {
        if (DBL_PTR(_10309)->dbl != 0.0){
            DeRef(_10309);
            _10309 = NOVALUE;
            goto L1; // [11] 21
        }
    }
    DeRef(_10309);
    _10309 = NOVALUE;

    /** 		return DB_BAD_NAME*/
    DeRefDS(_name_18339);
    DeRef(_name_ptr_18341);
    DeRef(_nt_18342);
    DeRef(_tables_18343);
    DeRef(_newtables_18344);
    DeRef(_table_18345);
    DeRef(_records_ptr_18346);
    DeRef(_size_18347);
    DeRef(_newsize_18348);
    DeRef(_index_ptr_18349);
    DeRef(_remaining_18350);
    return -4;
L1: 

    /** 	table = table_find(name)*/
    RefDS(_name_18339);
    _0 = _table_18345;
    _table_18345 = _48table_find(_name_18339);
    DeRef(_0);

    /** 	if table != -1 then*/
    if (binary_op_a(EQUALS, _table_18345, -1)){
        goto L2; // [29] 40
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRefDS(_name_18339);
    DeRef(_name_ptr_18341);
    DeRef(_nt_18342);
    DeRef(_tables_18343);
    DeRef(_newtables_18344);
    DeRef(_table_18345);
    DeRef(_records_ptr_18346);
    DeRef(_size_18347);
    DeRef(_newsize_18348);
    DeRef(_index_ptr_18349);
    DeRef(_remaining_18350);
    return -2;
L2: 

    /** 	if init_records < 1 then*/
    if (_init_records_18340 >= 1)
    goto L3; // [42] 52

    /** 		init_records = 1*/
    _init_records_18340 = 1;
L3: 

    /** 	init_index = math:min({init_records, MAX_INDEX})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _init_records_18340;
    ((int *)_2)[2] = 10;
    _10314 = MAKE_SEQ(_1);
    _init_index_18351 = _21min(_10314);
    _10314 = NOVALUE;
    if (!IS_ATOM_INT(_init_index_18351)) {
        _1 = (long)(DBL_PTR(_init_index_18351)->dbl);
        DeRefDS(_init_index_18351);
        _init_index_18351 = _1;
    }

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at68_18365);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at68_18365 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_68_18364 = machine(19, _seek_1__tmp_at68_18365);
    DeRefi(_seek_1__tmp_at68_18365);
    _seek_1__tmp_at68_18365 = NOVALUE;

    /** 	tables = get4()*/
    _0 = _tables_18343;
    _tables_18343 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables-4)*/
    if (IS_ATOM_INT(_tables_18343)) {
        _10317 = _tables_18343 - 4;
        if ((long)((unsigned long)_10317 +(unsigned long) HIGH_BITS) >= 0){
            _10317 = NewDouble((double)_10317);
        }
    }
    else {
        _10317 = NewDouble(DBL_PTR(_tables_18343)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_94_18369);
    _pos_inlined_seek_at_94_18369 = _10317;
    _10317 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_94_18369);
    DeRef(_seek_1__tmp_at97_18371);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_94_18369;
    _seek_1__tmp_at97_18371 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_97_18370 = machine(19, _seek_1__tmp_at97_18371);
    DeRef(_pos_inlined_seek_at_94_18369);
    _pos_inlined_seek_at_94_18369 = NOVALUE;
    DeRef(_seek_1__tmp_at97_18371);
    _seek_1__tmp_at97_18371 = NOVALUE;

    /** 	size = get4()*/
    _0 = _size_18347;
    _size_18347 = _48get4();
    DeRef(_0);

    /** 	nt = get4()+1*/
    _10319 = _48get4();
    DeRef(_nt_18342);
    if (IS_ATOM_INT(_10319)) {
        _nt_18342 = _10319 + 1;
        if (_nt_18342 > MAXINT){
            _nt_18342 = NewDouble((double)_nt_18342);
        }
    }
    else
    _nt_18342 = binary_op(PLUS, 1, _10319);
    DeRef(_10319);
    _10319 = NOVALUE;

    /** 	if nt*SIZEOF_TABLE_HEADER + 8 > size then*/
    if (IS_ATOM_INT(_nt_18342)) {
        if (_nt_18342 == (short)_nt_18342)
        _10321 = _nt_18342 * 16;
        else
        _10321 = NewDouble(_nt_18342 * (double)16);
    }
    else {
        _10321 = NewDouble(DBL_PTR(_nt_18342)->dbl * (double)16);
    }
    if (IS_ATOM_INT(_10321)) {
        _10322 = _10321 + 8;
        if ((long)((unsigned long)_10322 + (unsigned long)HIGH_BITS) >= 0) 
        _10322 = NewDouble((double)_10322);
    }
    else {
        _10322 = NewDouble(DBL_PTR(_10321)->dbl + (double)8);
    }
    DeRef(_10321);
    _10321 = NOVALUE;
    if (binary_op_a(LESSEQ, _10322, _size_18347)){
        DeRef(_10322);
        _10322 = NOVALUE;
        goto L4; // [134] 365
    }
    DeRef(_10322);
    _10322 = NOVALUE;

    /** 		newsize = floor(size + size / 2)*/
    if (IS_ATOM_INT(_size_18347)) {
        if (_size_18347 & 1) {
            _10324 = NewDouble((_size_18347 >> 1) + 0.5);
        }
        else
        _10324 = _size_18347 >> 1;
    }
    else {
        _10324 = binary_op(DIVIDE, _size_18347, 2);
    }
    if (IS_ATOM_INT(_size_18347) && IS_ATOM_INT(_10324)) {
        _10325 = _size_18347 + _10324;
        if ((long)((unsigned long)_10325 + (unsigned long)HIGH_BITS) >= 0) 
        _10325 = NewDouble((double)_10325);
    }
    else {
        if (IS_ATOM_INT(_size_18347)) {
            _10325 = NewDouble((double)_size_18347 + DBL_PTR(_10324)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10324)) {
                _10325 = NewDouble(DBL_PTR(_size_18347)->dbl + (double)_10324);
            }
            else
            _10325 = NewDouble(DBL_PTR(_size_18347)->dbl + DBL_PTR(_10324)->dbl);
        }
    }
    DeRef(_10324);
    _10324 = NOVALUE;
    DeRef(_newsize_18348);
    if (IS_ATOM_INT(_10325))
    _newsize_18348 = e_floor(_10325);
    else
    _newsize_18348 = unary_op(FLOOR, _10325);
    DeRef(_10325);
    _10325 = NOVALUE;

    /** 		newtables = db_allocate(newsize)*/
    Ref(_newsize_18348);
    _0 = _newtables_18344;
    _newtables_18344 = _48db_allocate(_newsize_18348);
    DeRef(_0);

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_nt_18342)) {
        *poke4_addr = (unsigned long)_nt_18342;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18342)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at159_18384);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at159_18384 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at159_18384); // DJP 

    /** end procedure*/
    goto L5; // [180] 183
L5: 
    DeRefi(_put4_1__tmp_at159_18384);
    _put4_1__tmp_at159_18384 = NOVALUE;

    /** 		io:seek(current_db, tables+4)*/
    if (IS_ATOM_INT(_tables_18343)) {
        _10328 = _tables_18343 + 4;
        if ((long)((unsigned long)_10328 + (unsigned long)HIGH_BITS) >= 0) 
        _10328 = NewDouble((double)_10328);
    }
    else {
        _10328 = NewDouble(DBL_PTR(_tables_18343)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_193_18387);
    _pos_inlined_seek_at_193_18387 = _10328;
    _10328 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_193_18387);
    DeRef(_seek_1__tmp_at196_18389);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_193_18387;
    _seek_1__tmp_at196_18389 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_196_18388 = machine(19, _seek_1__tmp_at196_18389);
    DeRef(_pos_inlined_seek_at_193_18387);
    _pos_inlined_seek_at_193_18387 = NOVALUE;
    DeRef(_seek_1__tmp_at196_18389);
    _seek_1__tmp_at196_18389 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, (nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_nt_18342)) {
        _10329 = _nt_18342 - 1;
        if ((long)((unsigned long)_10329 +(unsigned long) HIGH_BITS) >= 0){
            _10329 = NewDouble((double)_10329);
        }
    }
    else {
        _10329 = NewDouble(DBL_PTR(_nt_18342)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10329)) {
        if (_10329 == (short)_10329)
        _10330 = _10329 * 16;
        else
        _10330 = NewDouble(_10329 * (double)16);
    }
    else {
        _10330 = NewDouble(DBL_PTR(_10329)->dbl * (double)16);
    }
    DeRef(_10329);
    _10329 = NOVALUE;
    _0 = _remaining_18350;
    _remaining_18350 = _17get_bytes(_48current_db_17055, _10330);
    DeRef(_0);
    _10330 = NOVALUE;

    /** 		io:seek(current_db, newtables+4)*/
    if (IS_ATOM_INT(_newtables_18344)) {
        _10332 = _newtables_18344 + 4;
        if ((long)((unsigned long)_10332 + (unsigned long)HIGH_BITS) >= 0) 
        _10332 = NewDouble((double)_10332);
    }
    else {
        _10332 = NewDouble(DBL_PTR(_newtables_18344)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_236_18395);
    _pos_inlined_seek_at_236_18395 = _10332;
    _10332 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_236_18395);
    DeRef(_seek_1__tmp_at239_18397);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_236_18395;
    _seek_1__tmp_at239_18397 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_239_18396 = machine(19, _seek_1__tmp_at239_18397);
    DeRef(_pos_inlined_seek_at_236_18395);
    _pos_inlined_seek_at_236_18395 = NOVALUE;
    DeRef(_seek_1__tmp_at239_18397);
    _seek_1__tmp_at239_18397 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_18350); // DJP 

    /** end procedure*/
    goto L6; // [263] 266
L6: 

    /** 		putn(repeat(0, newsize - 4 - (nt-1)*SIZEOF_TABLE_HEADER))*/
    if (IS_ATOM_INT(_newsize_18348)) {
        _10333 = _newsize_18348 - 4;
        if ((long)((unsigned long)_10333 +(unsigned long) HIGH_BITS) >= 0){
            _10333 = NewDouble((double)_10333);
        }
    }
    else {
        _10333 = NewDouble(DBL_PTR(_newsize_18348)->dbl - (double)4);
    }
    if (IS_ATOM_INT(_nt_18342)) {
        _10334 = _nt_18342 - 1;
        if ((long)((unsigned long)_10334 +(unsigned long) HIGH_BITS) >= 0){
            _10334 = NewDouble((double)_10334);
        }
    }
    else {
        _10334 = NewDouble(DBL_PTR(_nt_18342)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10334)) {
        if (_10334 == (short)_10334)
        _10335 = _10334 * 16;
        else
        _10335 = NewDouble(_10334 * (double)16);
    }
    else {
        _10335 = NewDouble(DBL_PTR(_10334)->dbl * (double)16);
    }
    DeRef(_10334);
    _10334 = NOVALUE;
    if (IS_ATOM_INT(_10333) && IS_ATOM_INT(_10335)) {
        _10336 = _10333 - _10335;
    }
    else {
        if (IS_ATOM_INT(_10333)) {
            _10336 = NewDouble((double)_10333 - DBL_PTR(_10335)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10335)) {
                _10336 = NewDouble(DBL_PTR(_10333)->dbl - (double)_10335);
            }
            else
            _10336 = NewDouble(DBL_PTR(_10333)->dbl - DBL_PTR(_10335)->dbl);
        }
    }
    DeRef(_10333);
    _10333 = NOVALUE;
    DeRef(_10335);
    _10335 = NOVALUE;
    _10337 = Repeat(0, _10336);
    DeRef(_10336);
    _10336 = NOVALUE;
    DeRefi(_s_inlined_putn_at_288_18405);
    _s_inlined_putn_at_288_18405 = _10337;
    _10337 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_288_18405); // DJP 

    /** end procedure*/
    goto L7; // [302] 305
L7: 
    DeRefi(_s_inlined_putn_at_288_18405);
    _s_inlined_putn_at_288_18405 = NOVALUE;

    /** 		db_free(tables)*/
    Ref(_tables_18343);
    _48db_free(_tables_18343);

    /** 		io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at316_18408);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at316_18408 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_316_18407 = machine(19, _seek_1__tmp_at316_18408);
    DeRefi(_seek_1__tmp_at316_18408);
    _seek_1__tmp_at316_18408 = NOVALUE;

    /** 		put4(newtables)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_newtables_18344)) {
        *poke4_addr = (unsigned long)_newtables_18344;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_newtables_18344)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at331_18410);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at331_18410 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at331_18410); // DJP 

    /** end procedure*/
    goto L8; // [352] 355
L8: 
    DeRefi(_put4_1__tmp_at331_18410);
    _put4_1__tmp_at331_18410 = NOVALUE;

    /** 		tables = newtables*/
    Ref(_newtables_18344);
    DeRef(_tables_18343);
    _tables_18343 = _newtables_18344;
    goto L9; // [362] 411
L4: 

    /** 		io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18343);
    DeRef(_seek_1__tmp_at369_18414);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _tables_18343;
    _seek_1__tmp_at369_18414 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_369_18413 = machine(19, _seek_1__tmp_at369_18414);
    DeRef(_seek_1__tmp_at369_18414);
    _seek_1__tmp_at369_18414 = NOVALUE;

    /** 		put4(nt)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_nt_18342)) {
        *poke4_addr = (unsigned long)_nt_18342;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nt_18342)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at384_18416);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at384_18416 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at384_18416); // DJP 

    /** end procedure*/
    goto LA; // [405] 408
LA: 
    DeRefi(_put4_1__tmp_at384_18416);
    _put4_1__tmp_at384_18416 = NOVALUE;
L9: 

    /** 	records_ptr = db_allocate(init_records * 4)*/
    if (_init_records_18340 == (short)_init_records_18340)
    _10338 = _init_records_18340 * 4;
    else
    _10338 = NewDouble(_init_records_18340 * (double)4);
    _0 = _records_ptr_18346;
    _records_ptr_18346 = _48db_allocate(_10338);
    DeRef(_0);
    _10338 = NOVALUE;

    /** 	putn(repeat(0, init_records * 4))*/
    _10340 = _init_records_18340 * 4;
    _10341 = Repeat(0, _10340);
    _10340 = NOVALUE;
    DeRefi(_s_inlined_putn_at_431_18422);
    _s_inlined_putn_at_431_18422 = _10341;
    _10341 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_431_18422); // DJP 

    /** end procedure*/
    goto LB; // [445] 448
LB: 
    DeRefi(_s_inlined_putn_at_431_18422);
    _s_inlined_putn_at_431_18422 = NOVALUE;

    /** 	index_ptr = db_allocate(init_index * 8)*/
    if (_init_index_18351 == (short)_init_index_18351)
    _10342 = _init_index_18351 * 8;
    else
    _10342 = NewDouble(_init_index_18351 * (double)8);
    _0 = _index_ptr_18349;
    _index_ptr_18349 = _48db_allocate(_10342);
    DeRef(_0);
    _10342 = NOVALUE;

    /** 	put4(0)  -- 0 records*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at462_18426);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at462_18426 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at462_18426); // DJP 

    /** end procedure*/
    goto LC; // [483] 486
LC: 
    DeRefi(_put4_1__tmp_at462_18426);
    _put4_1__tmp_at462_18426 = NOVALUE;

    /** 	put4(records_ptr) -- point to 1st block*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_records_ptr_18346)) {
        *poke4_addr = (unsigned long)_records_ptr_18346;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_records_ptr_18346)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at490_18428);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at490_18428 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at490_18428); // DJP 

    /** end procedure*/
    goto LD; // [511] 514
LD: 
    DeRefi(_put4_1__tmp_at490_18428);
    _put4_1__tmp_at490_18428 = NOVALUE;

    /** 	putn(repeat(0, (init_index-1) * 8))*/
    _10344 = _init_index_18351 - 1;
    if ((long)((unsigned long)_10344 +(unsigned long) HIGH_BITS) >= 0){
        _10344 = NewDouble((double)_10344);
    }
    if (IS_ATOM_INT(_10344)) {
        _10345 = _10344 * 8;
    }
    else {
        _10345 = NewDouble(DBL_PTR(_10344)->dbl * (double)8);
    }
    DeRef(_10344);
    _10344 = NOVALUE;
    _10346 = Repeat(0, _10345);
    DeRef(_10345);
    _10345 = NOVALUE;
    DeRefi(_s_inlined_putn_at_530_18433);
    _s_inlined_putn_at_530_18433 = _10346;
    _10346 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_530_18433); // DJP 

    /** end procedure*/
    goto LE; // [544] 547
LE: 
    DeRefi(_s_inlined_putn_at_530_18433);
    _s_inlined_putn_at_530_18433 = NOVALUE;

    /** 	name_ptr = db_allocate(length(name)+1)*/
    if (IS_SEQUENCE(_name_18339)){
            _10347 = SEQ_PTR(_name_18339)->length;
    }
    else {
        _10347 = 1;
    }
    _10348 = _10347 + 1;
    _10347 = NOVALUE;
    _0 = _name_ptr_18341;
    _name_ptr_18341 = _48db_allocate(_10348);
    DeRef(_0);
    _10348 = NOVALUE;

    /** 	putn(name & 0)*/
    Append(&_10350, _name_18339, 0);
    DeRef(_s_inlined_putn_at_568_18439);
    _s_inlined_putn_at_568_18439 = _10350;
    _10350 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_568_18439); // DJP 

    /** end procedure*/
    goto LF; // [582] 585
LF: 
    DeRef(_s_inlined_putn_at_568_18439);
    _s_inlined_putn_at_568_18439 = NOVALUE;

    /** 	io:seek(current_db, tables+4+(nt-1)*SIZEOF_TABLE_HEADER)*/
    if (IS_ATOM_INT(_tables_18343)) {
        _10351 = _tables_18343 + 4;
        if ((long)((unsigned long)_10351 + (unsigned long)HIGH_BITS) >= 0) 
        _10351 = NewDouble((double)_10351);
    }
    else {
        _10351 = NewDouble(DBL_PTR(_tables_18343)->dbl + (double)4);
    }
    if (IS_ATOM_INT(_nt_18342)) {
        _10352 = _nt_18342 - 1;
        if ((long)((unsigned long)_10352 +(unsigned long) HIGH_BITS) >= 0){
            _10352 = NewDouble((double)_10352);
        }
    }
    else {
        _10352 = NewDouble(DBL_PTR(_nt_18342)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10352)) {
        if (_10352 == (short)_10352)
        _10353 = _10352 * 16;
        else
        _10353 = NewDouble(_10352 * (double)16);
    }
    else {
        _10353 = NewDouble(DBL_PTR(_10352)->dbl * (double)16);
    }
    DeRef(_10352);
    _10352 = NOVALUE;
    if (IS_ATOM_INT(_10351) && IS_ATOM_INT(_10353)) {
        _10354 = _10351 + _10353;
        if ((long)((unsigned long)_10354 + (unsigned long)HIGH_BITS) >= 0) 
        _10354 = NewDouble((double)_10354);
    }
    else {
        if (IS_ATOM_INT(_10351)) {
            _10354 = NewDouble((double)_10351 + DBL_PTR(_10353)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10353)) {
                _10354 = NewDouble(DBL_PTR(_10351)->dbl + (double)_10353);
            }
            else
            _10354 = NewDouble(DBL_PTR(_10351)->dbl + DBL_PTR(_10353)->dbl);
        }
    }
    DeRef(_10351);
    _10351 = NOVALUE;
    DeRef(_10353);
    _10353 = NOVALUE;
    DeRef(_pos_inlined_seek_at_607_18445);
    _pos_inlined_seek_at_607_18445 = _10354;
    _10354 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_607_18445);
    DeRef(_seek_1__tmp_at610_18447);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_607_18445;
    _seek_1__tmp_at610_18447 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_610_18446 = machine(19, _seek_1__tmp_at610_18447);
    DeRef(_pos_inlined_seek_at_607_18445);
    _pos_inlined_seek_at_607_18445 = NOVALUE;
    DeRef(_seek_1__tmp_at610_18447);
    _seek_1__tmp_at610_18447 = NOVALUE;

    /** 	put4(name_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_name_ptr_18341)) {
        *poke4_addr = (unsigned long)_name_ptr_18341;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_name_ptr_18341)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at625_18449);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at625_18449 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at625_18449); // DJP 

    /** end procedure*/
    goto L10; // [646] 649
L10: 
    DeRefi(_put4_1__tmp_at625_18449);
    _put4_1__tmp_at625_18449 = NOVALUE;

    /** 	put4(0)  -- start with 0 records total*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)0;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at653_18451);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at653_18451 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at653_18451); // DJP 

    /** end procedure*/
    goto L11; // [674] 677
L11: 
    DeRefi(_put4_1__tmp_at653_18451);
    _put4_1__tmp_at653_18451 = NOVALUE;

    /** 	put4(1)  -- start with 1 block of records in index*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)1;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at681_18453);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at681_18453 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at681_18453); // DJP 

    /** end procedure*/
    goto L12; // [702] 705
L12: 
    DeRefi(_put4_1__tmp_at681_18453);
    _put4_1__tmp_at681_18453 = NOVALUE;

    /** 	put4(index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_index_ptr_18349)) {
        *poke4_addr = (unsigned long)_index_ptr_18349;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_index_ptr_18349)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at709_18455);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at709_18455 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at709_18455); // DJP 

    /** end procedure*/
    goto L13; // [730] 733
L13: 
    DeRefi(_put4_1__tmp_at709_18455);
    _put4_1__tmp_at709_18455 = NOVALUE;

    /** 	if db_select_table(name) then*/
    RefDS(_name_18339);
    _10355 = _48db_select_table(_name_18339);
    if (_10355 == 0) {
        DeRef(_10355);
        _10355 = NOVALUE;
        goto L14; // [741] 745
    }
    else {
        if (!IS_ATOM_INT(_10355) && DBL_PTR(_10355)->dbl == 0.0){
            DeRef(_10355);
            _10355 = NOVALUE;
            goto L14; // [741] 745
        }
        DeRef(_10355);
        _10355 = NOVALUE;
    }
    DeRef(_10355);
    _10355 = NOVALUE;
L14: 

    /** 	return DB_OK*/
    DeRefDS(_name_18339);
    DeRef(_name_ptr_18341);
    DeRef(_nt_18342);
    DeRef(_tables_18343);
    DeRef(_newtables_18344);
    DeRef(_table_18345);
    DeRef(_records_ptr_18346);
    DeRef(_size_18347);
    DeRef(_newsize_18348);
    DeRef(_index_ptr_18349);
    DeRef(_remaining_18350);
    return 0;
    ;
}


int _48db_table_list()
{
    int _seek_1__tmp_at120_18714 = NOVALUE;
    int _seek_inlined_seek_at_120_18713 = NOVALUE;
    int _seek_1__tmp_at98_18710 = NOVALUE;
    int _seek_inlined_seek_at_98_18709 = NOVALUE;
    int _pos_inlined_seek_at_95_18708 = NOVALUE;
    int _seek_1__tmp_at42_18698 = NOVALUE;
    int _seek_inlined_seek_at_42_18697 = NOVALUE;
    int _seek_1__tmp_at4_18691 = NOVALUE;
    int _seek_inlined_seek_at_4_18690 = NOVALUE;
    int _table_names_18685 = NOVALUE;
    int _tables_18686 = NOVALUE;
    int _nt_18687 = NOVALUE;
    int _name_18688 = NOVALUE;
    int _10454 = NOVALUE;
    int _10453 = NOVALUE;
    int _10451 = NOVALUE;
    int _10450 = NOVALUE;
    int _10449 = NOVALUE;
    int _10448 = NOVALUE;
    int _10443 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, TABLE_HEADERS)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    DeRefi(_seek_1__tmp_at4_18691);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = 3;
    _seek_1__tmp_at4_18691 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_4_18690 = machine(19, _seek_1__tmp_at4_18691);
    DeRefi(_seek_1__tmp_at4_18691);
    _seek_1__tmp_at4_18691 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return {} end if*/
    if (IS_SEQUENCE(_48vLastErrors_17079)){
            _10443 = SEQ_PTR(_48vLastErrors_17079)->length;
    }
    else {
        _10443 = 1;
    }
    if (_10443 <= 0)
    goto L1; // [25] 34
    RefDS(_5);
    DeRef(_table_names_18685);
    DeRef(_tables_18686);
    DeRef(_nt_18687);
    DeRef(_name_18688);
    return _5;
L1: 

    /** 	tables = get4()*/
    _0 = _tables_18686;
    _tables_18686 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, tables)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_tables_18686);
    DeRef(_seek_1__tmp_at42_18698);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _tables_18686;
    _seek_1__tmp_at42_18698 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_42_18697 = machine(19, _seek_1__tmp_at42_18698);
    DeRef(_seek_1__tmp_at42_18698);
    _seek_1__tmp_at42_18698 = NOVALUE;

    /** 	nt = get4()*/
    _0 = _nt_18687;
    _nt_18687 = _48get4();
    DeRef(_0);

    /** 	table_names = repeat(0, nt)*/
    DeRef(_table_names_18685);
    _table_names_18685 = Repeat(0, _nt_18687);

    /** 	for i = 0 to nt-1 do*/
    if (IS_ATOM_INT(_nt_18687)) {
        _10448 = _nt_18687 - 1;
        if ((long)((unsigned long)_10448 +(unsigned long) HIGH_BITS) >= 0){
            _10448 = NewDouble((double)_10448);
        }
    }
    else {
        _10448 = NewDouble(DBL_PTR(_nt_18687)->dbl - (double)1);
    }
    {
        int _i_18702;
        _i_18702 = 0;
L2: 
        if (binary_op_a(GREATER, _i_18702, _10448)){
            goto L3; // [73] 154
        }

        /** 		io:seek(current_db, tables + 4 + i*SIZEOF_TABLE_HEADER)*/
        if (IS_ATOM_INT(_tables_18686)) {
            _10449 = _tables_18686 + 4;
            if ((long)((unsigned long)_10449 + (unsigned long)HIGH_BITS) >= 0) 
            _10449 = NewDouble((double)_10449);
        }
        else {
            _10449 = NewDouble(DBL_PTR(_tables_18686)->dbl + (double)4);
        }
        if (IS_ATOM_INT(_i_18702)) {
            if (_i_18702 == (short)_i_18702)
            _10450 = _i_18702 * 16;
            else
            _10450 = NewDouble(_i_18702 * (double)16);
        }
        else {
            _10450 = NewDouble(DBL_PTR(_i_18702)->dbl * (double)16);
        }
        if (IS_ATOM_INT(_10449) && IS_ATOM_INT(_10450)) {
            _10451 = _10449 + _10450;
            if ((long)((unsigned long)_10451 + (unsigned long)HIGH_BITS) >= 0) 
            _10451 = NewDouble((double)_10451);
        }
        else {
            if (IS_ATOM_INT(_10449)) {
                _10451 = NewDouble((double)_10449 + DBL_PTR(_10450)->dbl);
            }
            else {
                if (IS_ATOM_INT(_10450)) {
                    _10451 = NewDouble(DBL_PTR(_10449)->dbl + (double)_10450);
                }
                else
                _10451 = NewDouble(DBL_PTR(_10449)->dbl + DBL_PTR(_10450)->dbl);
            }
        }
        DeRef(_10449);
        _10449 = NOVALUE;
        DeRef(_10450);
        _10450 = NOVALUE;
        DeRef(_pos_inlined_seek_at_95_18708);
        _pos_inlined_seek_at_95_18708 = _10451;
        _10451 = NOVALUE;

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_pos_inlined_seek_at_95_18708);
        DeRef(_seek_1__tmp_at98_18710);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _pos_inlined_seek_at_95_18708;
        _seek_1__tmp_at98_18710 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_98_18709 = machine(19, _seek_1__tmp_at98_18710);
        DeRef(_pos_inlined_seek_at_95_18708);
        _pos_inlined_seek_at_95_18708 = NOVALUE;
        DeRef(_seek_1__tmp_at98_18710);
        _seek_1__tmp_at98_18710 = NOVALUE;

        /** 		name = get4()*/
        _0 = _name_18688;
        _name_18688 = _48get4();
        DeRef(_0);

        /** 		io:seek(current_db, name)*/

        /** 	return machine_func(M_SEEK, {fn, pos})*/
        Ref(_name_18688);
        DeRef(_seek_1__tmp_at120_18714);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _48current_db_17055;
        ((int *)_2)[2] = _name_18688;
        _seek_1__tmp_at120_18714 = MAKE_SEQ(_1);
        _seek_inlined_seek_at_120_18713 = machine(19, _seek_1__tmp_at120_18714);
        DeRef(_seek_1__tmp_at120_18714);
        _seek_1__tmp_at120_18714 = NOVALUE;

        /** 		table_names[i+1] = get_string()*/
        if (IS_ATOM_INT(_i_18702)) {
            _10453 = _i_18702 + 1;
            if (_10453 > MAXINT){
                _10453 = NewDouble((double)_10453);
            }
        }
        else
        _10453 = binary_op(PLUS, 1, _i_18702);
        _10454 = _48get_string();
        _2 = (int)SEQ_PTR(_table_names_18685);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _table_names_18685 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_10453))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_10453)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _10453);
        _1 = *(int *)_2;
        *(int *)_2 = _10454;
        if( _1 != _10454 ){
            DeRef(_1);
        }
        _10454 = NOVALUE;

        /** 	end for*/
        _0 = _i_18702;
        if (IS_ATOM_INT(_i_18702)) {
            _i_18702 = _i_18702 + 1;
            if ((long)((unsigned long)_i_18702 +(unsigned long) HIGH_BITS) >= 0){
                _i_18702 = NewDouble((double)_i_18702);
            }
        }
        else {
            _i_18702 = binary_op_a(PLUS, _i_18702, 1);
        }
        DeRef(_0);
        goto L2; // [149] 80
L3: 
        ;
        DeRef(_i_18702);
    }

    /** 	return table_names*/
    DeRef(_tables_18686);
    DeRef(_nt_18687);
    DeRef(_name_18688);
    DeRef(_10448);
    _10448 = NOVALUE;
    DeRef(_10453);
    _10453 = NOVALUE;
    return _table_names_18685;
    ;
}


int _48key_value(int _ptr_18719)
{
    int _seek_1__tmp_at11_18724 = NOVALUE;
    int _seek_inlined_seek_at_11_18723 = NOVALUE;
    int _pos_inlined_seek_at_8_18722 = NOVALUE;
    int _10456 = NOVALUE;
    int _10455 = NOVALUE;
    int _0, _1, _2;
    

    /** 	io:seek(current_db, ptr+4) -- skip ptr to data*/
    if (IS_ATOM_INT(_ptr_18719)) {
        _10455 = _ptr_18719 + 4;
        if ((long)((unsigned long)_10455 + (unsigned long)HIGH_BITS) >= 0) 
        _10455 = NewDouble((double)_10455);
    }
    else {
        _10455 = NewDouble(DBL_PTR(_ptr_18719)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_8_18722);
    _pos_inlined_seek_at_8_18722 = _10455;
    _10455 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_8_18722);
    DeRef(_seek_1__tmp_at11_18724);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_8_18722;
    _seek_1__tmp_at11_18724 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_11_18723 = machine(19, _seek_1__tmp_at11_18724);
    DeRef(_pos_inlined_seek_at_8_18722);
    _pos_inlined_seek_at_8_18722 = NOVALUE;
    DeRef(_seek_1__tmp_at11_18724);
    _seek_1__tmp_at11_18724 = NOVALUE;

    /** 	return decompress(0)*/
    _10456 = _48decompress(0);
    DeRef(_ptr_18719);
    return _10456;
    ;
}


int _48db_find_key(int _key_18728, int _table_name_18729)
{
    int _lo_18730 = NOVALUE;
    int _hi_18731 = NOVALUE;
    int _mid_18732 = NOVALUE;
    int _c_18733 = NOVALUE;
    int _10480 = NOVALUE;
    int _10472 = NOVALUE;
    int _10471 = NOVALUE;
    int _10469 = NOVALUE;
    int _10466 = NOVALUE;
    int _10463 = NOVALUE;
    int _10459 = NOVALUE;
    int _10457 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_18729 == _48current_table_name_17057)
    _10457 = 1;
    else if (IS_ATOM_INT(_table_name_18729) && IS_ATOM_INT(_48current_table_name_17057))
    _10457 = 0;
    else
    _10457 = (compare(_table_name_18729, _48current_table_name_17057) == 0);
    if (_10457 != 0)
    goto L1; // [9] 42
    _10457 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_18729);
    _10459 = _48db_select_table(_table_name_18729);
    if (binary_op_a(EQUALS, _10459, 0)){
        DeRef(_10459);
        _10459 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10459);
    _10459 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_find_key", {key, table_name})*/
    RefDS(_table_name_18729);
    Ref(_key_18728);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18728;
    ((int *)_2)[2] = _table_name_18729;
    _10463 = MAKE_SEQ(_1);
    RefDS(_10461);
    RefDS(_10462);
    _48fatal(903, _10461, _10462, _10463);
    _10463 = NOVALUE;

    /** 			return 0*/
    DeRef(_key_18728);
    DeRefDS(_table_name_18729);
    return 0;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17056, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_find_key", {key, table_name})*/
    Ref(_table_name_18729);
    Ref(_key_18728);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_18728;
    ((int *)_2)[2] = _table_name_18729;
    _10466 = MAKE_SEQ(_1);
    RefDS(_10465);
    RefDS(_10462);
    _48fatal(903, _10465, _10462, _10466);
    _10466 = NOVALUE;

    /** 		return 0*/
    DeRef(_key_18728);
    DeRef(_table_name_18729);
    return 0;
L3: 

    /** 	lo = 1*/
    _lo_18730 = 1;

    /** 	hi = length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _hi_18731 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _hi_18731 = 1;
    }

    /** 	mid = 1*/
    _mid_18732 = 1;

    /** 	c = 0*/
    _c_18733 = 0;

    /** 	while lo <= hi do*/
L4: 
    if (_lo_18730 > _hi_18731)
    goto L5; // [96] 170

    /** 		mid = floor((lo + hi) / 2)*/
    _10469 = _lo_18730 + _hi_18731;
    if ((long)((unsigned long)_10469 + (unsigned long)HIGH_BITS) >= 0) 
    _10469 = NewDouble((double)_10469);
    if (IS_ATOM_INT(_10469)) {
        _mid_18732 = _10469 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _10469, 2);
        _mid_18732 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_10469);
    _10469 = NOVALUE;
    if (!IS_ATOM_INT(_mid_18732)) {
        _1 = (long)(DBL_PTR(_mid_18732)->dbl);
        DeRefDS(_mid_18732);
        _mid_18732 = _1;
    }

    /** 		c = eu:compare(key, key_value(key_pointers[mid]))*/
    _2 = (int)SEQ_PTR(_48key_pointers_17062);
    _10471 = (int)*(((s1_ptr)_2)->base + _mid_18732);
    Ref(_10471);
    _10472 = _48key_value(_10471);
    _10471 = NOVALUE;
    if (IS_ATOM_INT(_key_18728) && IS_ATOM_INT(_10472)){
        _c_18733 = (_key_18728 < _10472) ? -1 : (_key_18728 > _10472);
    }
    else{
        _c_18733 = compare(_key_18728, _10472);
    }
    DeRef(_10472);
    _10472 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_18733 >= 0)
    goto L6; // [130] 143

    /** 			hi = mid - 1*/
    _hi_18731 = _mid_18732 - 1;
    goto L4; // [140] 96
L6: 

    /** 		elsif c > 0 then*/
    if (_c_18733 <= 0)
    goto L7; // [145] 158

    /** 			lo = mid + 1*/
    _lo_18730 = _mid_18732 + 1;
    goto L4; // [155] 96
L7: 

    /** 			return mid*/
    DeRef(_key_18728);
    DeRef(_table_name_18729);
    return _mid_18732;

    /** 	end while*/
    goto L4; // [167] 96
L5: 

    /** 	if c > 0 then*/
    if (_c_18733 <= 0)
    goto L8; // [172] 183

    /** 		mid += 1*/
    _mid_18732 = _mid_18732 + 1;
L8: 

    /** 	return -mid*/
    if ((unsigned long)_mid_18732 == 0xC0000000)
    _10480 = (int)NewDouble((double)-0xC0000000);
    else
    _10480 = - _mid_18732;
    DeRef(_key_18728);
    DeRef(_table_name_18729);
    return _10480;
    ;
}


int _48db_insert(int _key_18768, int _data_18769, int _table_name_18770)
{
    int _key_string_18771 = NOVALUE;
    int _data_string_18772 = NOVALUE;
    int _last_part_18773 = NOVALUE;
    int _remaining_18774 = NOVALUE;
    int _key_ptr_18775 = NOVALUE;
    int _data_ptr_18776 = NOVALUE;
    int _records_ptr_18777 = NOVALUE;
    int _nrecs_18778 = NOVALUE;
    int _current_block_18779 = NOVALUE;
    int _size_18780 = NOVALUE;
    int _new_size_18781 = NOVALUE;
    int _key_location_18782 = NOVALUE;
    int _new_block_18783 = NOVALUE;
    int _index_ptr_18784 = NOVALUE;
    int _new_index_ptr_18785 = NOVALUE;
    int _total_recs_18786 = NOVALUE;
    int _r_18787 = NOVALUE;
    int _blocks_18788 = NOVALUE;
    int _new_recs_18789 = NOVALUE;
    int _n_18790 = NOVALUE;
    int _put4_1__tmp_at79_18804 = NOVALUE;
    int _seek_1__tmp_at132_18810 = NOVALUE;
    int _seek_inlined_seek_at_132_18809 = NOVALUE;
    int _pos_inlined_seek_at_129_18808 = NOVALUE;
    int _seek_1__tmp_at174_18818 = NOVALUE;
    int _seek_inlined_seek_at_174_18817 = NOVALUE;
    int _pos_inlined_seek_at_171_18816 = NOVALUE;
    int _put4_1__tmp_at189_18820 = NOVALUE;
    int _seek_1__tmp_at317_18838 = NOVALUE;
    int _seek_inlined_seek_at_317_18837 = NOVALUE;
    int _pos_inlined_seek_at_314_18836 = NOVALUE;
    int _seek_1__tmp_at339_18842 = NOVALUE;
    int _seek_inlined_seek_at_339_18841 = NOVALUE;
    int _where_inlined_where_at_404_18851 = NOVALUE;
    int _seek_1__tmp_at448_18861 = NOVALUE;
    int _seek_inlined_seek_at_448_18860 = NOVALUE;
    int _pos_inlined_seek_at_445_18859 = NOVALUE;
    int _put4_1__tmp_at493_18870 = NOVALUE;
    int _x_inlined_put4_at_490_18869 = NOVALUE;
    int _seek_1__tmp_at530_18873 = NOVALUE;
    int _seek_inlined_seek_at_530_18872 = NOVALUE;
    int _put4_1__tmp_at551_18876 = NOVALUE;
    int _seek_1__tmp_at588_18881 = NOVALUE;
    int _seek_inlined_seek_at_588_18880 = NOVALUE;
    int _pos_inlined_seek_at_585_18879 = NOVALUE;
    int _seek_1__tmp_at690_18906 = NOVALUE;
    int _seek_inlined_seek_at_690_18905 = NOVALUE;
    int _pos_inlined_seek_at_687_18904 = NOVALUE;
    int _s_inlined_putn_at_751_18915 = NOVALUE;
    int _seek_1__tmp_at774_18918 = NOVALUE;
    int _seek_inlined_seek_at_774_18917 = NOVALUE;
    int _put4_1__tmp_at796_18922 = NOVALUE;
    int _x_inlined_put4_at_793_18921 = NOVALUE;
    int _seek_1__tmp_at833_18927 = NOVALUE;
    int _seek_inlined_seek_at_833_18926 = NOVALUE;
    int _pos_inlined_seek_at_830_18925 = NOVALUE;
    int _seek_1__tmp_at884_18937 = NOVALUE;
    int _seek_inlined_seek_at_884_18936 = NOVALUE;
    int _pos_inlined_seek_at_881_18935 = NOVALUE;
    int _put4_1__tmp_at899_18939 = NOVALUE;
    int _put4_1__tmp_at927_18941 = NOVALUE;
    int _seek_1__tmp_at980_18947 = NOVALUE;
    int _seek_inlined_seek_at_980_18946 = NOVALUE;
    int _pos_inlined_seek_at_977_18945 = NOVALUE;
    int _put4_1__tmp_at1001_18950 = NOVALUE;
    int _seek_1__tmp_at1038_18955 = NOVALUE;
    int _seek_inlined_seek_at_1038_18954 = NOVALUE;
    int _pos_inlined_seek_at_1035_18953 = NOVALUE;
    int _s_inlined_putn_at_1136_18973 = NOVALUE;
    int _seek_1__tmp_at1173_18978 = NOVALUE;
    int _seek_inlined_seek_at_1173_18977 = NOVALUE;
    int _pos_inlined_seek_at_1170_18976 = NOVALUE;
    int _put4_1__tmp_at1188_18980 = NOVALUE;
    int _10576 = NOVALUE;
    int _10575 = NOVALUE;
    int _10574 = NOVALUE;
    int _10573 = NOVALUE;
    int _10570 = NOVALUE;
    int _10569 = NOVALUE;
    int _10567 = NOVALUE;
    int _10565 = NOVALUE;
    int _10564 = NOVALUE;
    int _10562 = NOVALUE;
    int _10561 = NOVALUE;
    int _10559 = NOVALUE;
    int _10558 = NOVALUE;
    int _10556 = NOVALUE;
    int _10555 = NOVALUE;
    int _10554 = NOVALUE;
    int _10553 = NOVALUE;
    int _10552 = NOVALUE;
    int _10551 = NOVALUE;
    int _10550 = NOVALUE;
    int _10549 = NOVALUE;
    int _10548 = NOVALUE;
    int _10545 = NOVALUE;
    int _10544 = NOVALUE;
    int _10543 = NOVALUE;
    int _10542 = NOVALUE;
    int _10539 = NOVALUE;
    int _10536 = NOVALUE;
    int _10535 = NOVALUE;
    int _10534 = NOVALUE;
    int _10533 = NOVALUE;
    int _10529 = NOVALUE;
    int _10528 = NOVALUE;
    int _10526 = NOVALUE;
    int _10525 = NOVALUE;
    int _10523 = NOVALUE;
    int _10522 = NOVALUE;
    int _10521 = NOVALUE;
    int _10520 = NOVALUE;
    int _10519 = NOVALUE;
    int _10518 = NOVALUE;
    int _10517 = NOVALUE;
    int _10515 = NOVALUE;
    int _10512 = NOVALUE;
    int _10507 = NOVALUE;
    int _10505 = NOVALUE;
    int _10504 = NOVALUE;
    int _10502 = NOVALUE;
    int _10501 = NOVALUE;
    int _10500 = NOVALUE;
    int _10497 = NOVALUE;
    int _10495 = NOVALUE;
    int _10492 = NOVALUE;
    int _10491 = NOVALUE;
    int _10489 = NOVALUE;
    int _10488 = NOVALUE;
    int _10486 = NOVALUE;
    int _0, _1, _2;
    

    /** 	key_location = db_find_key(key, table_name) -- Let it set the current table if necessary*/
    Ref(_key_18768);
    RefDS(_table_name_18770);
    _0 = _key_location_18782;
    _key_location_18782 = _48db_find_key(_key_18768, _table_name_18770);
    DeRef(_0);

    /** 	if key_location > 0 then*/
    if (binary_op_a(LESSEQ, _key_location_18782, 0)){
        goto L1; // [10] 21
    }

    /** 		return DB_EXISTS_ALREADY*/
    DeRef(_key_18768);
    DeRefDS(_table_name_18770);
    DeRef(_key_string_18771);
    DeRef(_data_string_18772);
    DeRef(_last_part_18773);
    DeRef(_remaining_18774);
    DeRef(_key_ptr_18775);
    DeRef(_data_ptr_18776);
    DeRef(_records_ptr_18777);
    DeRef(_nrecs_18778);
    DeRef(_current_block_18779);
    DeRef(_size_18780);
    DeRef(_new_size_18781);
    DeRef(_key_location_18782);
    DeRef(_new_block_18783);
    DeRef(_index_ptr_18784);
    DeRef(_new_index_ptr_18785);
    DeRef(_total_recs_18786);
    return -2;
L1: 

    /** 	key_location = -key_location*/
    _0 = _key_location_18782;
    if (IS_ATOM_INT(_key_location_18782)) {
        if ((unsigned long)_key_location_18782 == 0xC0000000)
        _key_location_18782 = (int)NewDouble((double)-0xC0000000);
        else
        _key_location_18782 = - _key_location_18782;
    }
    else {
        _key_location_18782 = unary_op(UMINUS, _key_location_18782);
    }
    DeRef(_0);

    /** 	data_string = compress(data)*/
    _0 = _data_string_18772;
    _data_string_18772 = _48compress(_data_18769);
    DeRef(_0);

    /** 	key_string  = compress(key)*/
    Ref(_key_18768);
    _0 = _key_string_18771;
    _key_string_18771 = _48compress(_key_18768);
    DeRef(_0);

    /** 	data_ptr = db_allocate(length(data_string))*/
    if (IS_SEQUENCE(_data_string_18772)){
            _10486 = SEQ_PTR(_data_string_18772)->length;
    }
    else {
        _10486 = 1;
    }
    _0 = _data_ptr_18776;
    _data_ptr_18776 = _48db_allocate(_10486);
    DeRef(_0);
    _10486 = NOVALUE;

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _data_string_18772); // DJP 

    /** end procedure*/
    goto L2; // [62] 65
L2: 

    /** 	key_ptr = db_allocate(4+length(key_string))*/
    if (IS_SEQUENCE(_key_string_18771)){
            _10488 = SEQ_PTR(_key_string_18771)->length;
    }
    else {
        _10488 = 1;
    }
    _10489 = 4 + _10488;
    _10488 = NOVALUE;
    _0 = _key_ptr_18775;
    _key_ptr_18775 = _48db_allocate(_10489);
    DeRef(_0);
    _10489 = NOVALUE;

    /** 	put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_18776)) {
        *poke4_addr = (unsigned long)_data_ptr_18776;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_18776)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at79_18804);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at79_18804 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at79_18804); // DJP 

    /** end procedure*/
    goto L3; // [101] 104
L3: 
    DeRefi(_put4_1__tmp_at79_18804);
    _put4_1__tmp_at79_18804 = NOVALUE;

    /** 	putn(key_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _key_string_18771); // DJP 

    /** end procedure*/
    goto L4; // [117] 120
L4: 

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_48current_table_pos_17056)) {
        _10491 = _48current_table_pos_17056 + 4;
        if ((long)((unsigned long)_10491 + (unsigned long)HIGH_BITS) >= 0) 
        _10491 = NewDouble((double)_10491);
    }
    else {
        _10491 = NewDouble(DBL_PTR(_48current_table_pos_17056)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_129_18808);
    _pos_inlined_seek_at_129_18808 = _10491;
    _10491 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_129_18808);
    DeRef(_seek_1__tmp_at132_18810);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_129_18808;
    _seek_1__tmp_at132_18810 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_132_18809 = machine(19, _seek_1__tmp_at132_18810);
    DeRef(_pos_inlined_seek_at_129_18808);
    _pos_inlined_seek_at_129_18808 = NOVALUE;
    DeRef(_seek_1__tmp_at132_18810);
    _seek_1__tmp_at132_18810 = NOVALUE;

    /** 	total_recs = get4()+1*/
    _10492 = _48get4();
    DeRef(_total_recs_18786);
    if (IS_ATOM_INT(_10492)) {
        _total_recs_18786 = _10492 + 1;
        if (_total_recs_18786 > MAXINT){
            _total_recs_18786 = NewDouble((double)_total_recs_18786);
        }
    }
    else
    _total_recs_18786 = binary_op(PLUS, 1, _10492);
    DeRef(_10492);
    _10492 = NOVALUE;

    /** 	blocks = get4()*/
    _blocks_18788 = _48get4();
    if (!IS_ATOM_INT(_blocks_18788)) {
        _1 = (long)(DBL_PTR(_blocks_18788)->dbl);
        DeRefDS(_blocks_18788);
        _blocks_18788 = _1;
    }

    /** 	io:seek(current_db, current_table_pos+4)*/
    if (IS_ATOM_INT(_48current_table_pos_17056)) {
        _10495 = _48current_table_pos_17056 + 4;
        if ((long)((unsigned long)_10495 + (unsigned long)HIGH_BITS) >= 0) 
        _10495 = NewDouble((double)_10495);
    }
    else {
        _10495 = NewDouble(DBL_PTR(_48current_table_pos_17056)->dbl + (double)4);
    }
    DeRef(_pos_inlined_seek_at_171_18816);
    _pos_inlined_seek_at_171_18816 = _10495;
    _10495 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_171_18816);
    DeRef(_seek_1__tmp_at174_18818);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_171_18816;
    _seek_1__tmp_at174_18818 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_174_18817 = machine(19, _seek_1__tmp_at174_18818);
    DeRef(_pos_inlined_seek_at_171_18816);
    _pos_inlined_seek_at_171_18816 = NOVALUE;
    DeRef(_seek_1__tmp_at174_18818);
    _seek_1__tmp_at174_18818 = NOVALUE;

    /** 	put4(total_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_total_recs_18786)) {
        *poke4_addr = (unsigned long)_total_recs_18786;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_total_recs_18786)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at189_18820);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at189_18820 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at189_18820); // DJP 

    /** end procedure*/
    goto L5; // [211] 214
L5: 
    DeRefi(_put4_1__tmp_at189_18820);
    _put4_1__tmp_at189_18820 = NOVALUE;

    /** 	n = length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _n_18790 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _n_18790 = 1;
    }

    /** 	if key_location >= floor(n/2) then*/
    _10497 = _n_18790 >> 1;
    if (binary_op_a(LESS, _key_location_18782, _10497)){
        _10497 = NOVALUE;
        goto L6; // [229] 268
    }
    DeRef(_10497);
    _10497 = NOVALUE;

    /** 		key_pointers = append(key_pointers, 0)*/
    Append(&_48key_pointers_17062, _48key_pointers_17062, 0);

    /** 		key_pointers[key_location+1..n+1] = key_pointers[key_location..n]*/
    if (IS_ATOM_INT(_key_location_18782)) {
        _10500 = _key_location_18782 + 1;
        if (_10500 > MAXINT){
            _10500 = NewDouble((double)_10500);
        }
    }
    else
    _10500 = binary_op(PLUS, 1, _key_location_18782);
    _10501 = _n_18790 + 1;
    rhs_slice_target = (object_ptr)&_10502;
    RHS_Slice(_48key_pointers_17062, _key_location_18782, _n_18790);
    assign_slice_seq = (s1_ptr *)&_48key_pointers_17062;
    AssignSlice(_10500, _10501, _10502);
    DeRef(_10500);
    _10500 = NOVALUE;
    _10501 = NOVALUE;
    DeRefDS(_10502);
    _10502 = NOVALUE;
    goto L7; // [265] 297
L6: 

    /** 		key_pointers = prepend(key_pointers, 0)*/
    Prepend(&_48key_pointers_17062, _48key_pointers_17062, 0);

    /** 		key_pointers[1..key_location-1] = key_pointers[2..key_location]*/
    if (IS_ATOM_INT(_key_location_18782)) {
        _10504 = _key_location_18782 - 1;
        if ((long)((unsigned long)_10504 +(unsigned long) HIGH_BITS) >= 0){
            _10504 = NewDouble((double)_10504);
        }
    }
    else {
        _10504 = NewDouble(DBL_PTR(_key_location_18782)->dbl - (double)1);
    }
    rhs_slice_target = (object_ptr)&_10505;
    RHS_Slice(_48key_pointers_17062, 2, _key_location_18782);
    assign_slice_seq = (s1_ptr *)&_48key_pointers_17062;
    AssignSlice(1, _10504, _10505);
    DeRef(_10504);
    _10504 = NOVALUE;
    DeRefDS(_10505);
    _10505 = NOVALUE;
L7: 

    /** 	key_pointers[key_location] = key_ptr*/
    Ref(_key_ptr_18775);
    _2 = (int)SEQ_PTR(_48key_pointers_17062);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _48key_pointers_17062 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_key_location_18782))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_key_location_18782)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _key_location_18782);
    _1 = *(int *)_2;
    *(int *)_2 = _key_ptr_18775;
    DeRef(_1);

    /** 	io:seek(current_db, current_table_pos+12) -- get after put - seek is necessary*/
    if (IS_ATOM_INT(_48current_table_pos_17056)) {
        _10507 = _48current_table_pos_17056 + 12;
        if ((long)((unsigned long)_10507 + (unsigned long)HIGH_BITS) >= 0) 
        _10507 = NewDouble((double)_10507);
    }
    else {
        _10507 = NewDouble(DBL_PTR(_48current_table_pos_17056)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_314_18836);
    _pos_inlined_seek_at_314_18836 = _10507;
    _10507 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_314_18836);
    DeRef(_seek_1__tmp_at317_18838);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_314_18836;
    _seek_1__tmp_at317_18838 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_317_18837 = machine(19, _seek_1__tmp_at317_18838);
    DeRef(_pos_inlined_seek_at_314_18836);
    _pos_inlined_seek_at_314_18836 = NOVALUE;
    DeRef(_seek_1__tmp_at317_18838);
    _seek_1__tmp_at317_18838 = NOVALUE;

    /** 	index_ptr = get4()*/
    _0 = _index_ptr_18784;
    _index_ptr_18784 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, index_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_index_ptr_18784);
    DeRef(_seek_1__tmp_at339_18842);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _index_ptr_18784;
    _seek_1__tmp_at339_18842 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_339_18841 = machine(19, _seek_1__tmp_at339_18842);
    DeRef(_seek_1__tmp_at339_18842);
    _seek_1__tmp_at339_18842 = NOVALUE;

    /** 	r = 0*/
    _r_18787 = 0;

    /** 	while TRUE do*/
L8: 

    /** 		nrecs = get4()*/
    _0 = _nrecs_18778;
    _nrecs_18778 = _48get4();
    DeRef(_0);

    /** 		records_ptr = get4()*/
    _0 = _records_ptr_18777;
    _records_ptr_18777 = _48get4();
    DeRef(_0);

    /** 		r += nrecs*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _r_18787 = _r_18787 + _nrecs_18778;
    }
    else {
        _r_18787 = NewDouble((double)_r_18787 + DBL_PTR(_nrecs_18778)->dbl);
    }
    if (!IS_ATOM_INT(_r_18787)) {
        _1 = (long)(DBL_PTR(_r_18787)->dbl);
        DeRefDS(_r_18787);
        _r_18787 = _1;
    }

    /** 		if r + 1 >= key_location then*/
    _10512 = _r_18787 + 1;
    if (_10512 > MAXINT){
        _10512 = NewDouble((double)_10512);
    }
    if (binary_op_a(LESS, _10512, _key_location_18782)){
        DeRef(_10512);
        _10512 = NOVALUE;
        goto L8; // [387] 363
    }
    DeRef(_10512);
    _10512 = NOVALUE;

    /** 			exit*/
    goto L9; // [393] 401

    /** 	end while*/
    goto L8; // [398] 363
L9: 

    /** 	current_block = io:where(current_db)-8*/

    /** 	return machine_func(M_WHERE, fn)*/
    DeRef(_where_inlined_where_at_404_18851);
    _where_inlined_where_at_404_18851 = machine(20, _48current_db_17055);
    DeRef(_current_block_18779);
    if (IS_ATOM_INT(_where_inlined_where_at_404_18851)) {
        _current_block_18779 = _where_inlined_where_at_404_18851 - 8;
        if ((long)((unsigned long)_current_block_18779 +(unsigned long) HIGH_BITS) >= 0){
            _current_block_18779 = NewDouble((double)_current_block_18779);
        }
    }
    else {
        _current_block_18779 = NewDouble(DBL_PTR(_where_inlined_where_at_404_18851)->dbl - (double)8);
    }

    /** 	key_location -= (r-nrecs)*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _10515 = _r_18787 - _nrecs_18778;
        if ((long)((unsigned long)_10515 +(unsigned long) HIGH_BITS) >= 0){
            _10515 = NewDouble((double)_10515);
        }
    }
    else {
        _10515 = NewDouble((double)_r_18787 - DBL_PTR(_nrecs_18778)->dbl);
    }
    _0 = _key_location_18782;
    if (IS_ATOM_INT(_key_location_18782) && IS_ATOM_INT(_10515)) {
        _key_location_18782 = _key_location_18782 - _10515;
        if ((long)((unsigned long)_key_location_18782 +(unsigned long) HIGH_BITS) >= 0){
            _key_location_18782 = NewDouble((double)_key_location_18782);
        }
    }
    else {
        if (IS_ATOM_INT(_key_location_18782)) {
            _key_location_18782 = NewDouble((double)_key_location_18782 - DBL_PTR(_10515)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10515)) {
                _key_location_18782 = NewDouble(DBL_PTR(_key_location_18782)->dbl - (double)_10515);
            }
            else
            _key_location_18782 = NewDouble(DBL_PTR(_key_location_18782)->dbl - DBL_PTR(_10515)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_10515);
    _10515 = NOVALUE;

    /** 	io:seek(current_db, records_ptr+4*(key_location-1))*/
    if (IS_ATOM_INT(_key_location_18782)) {
        _10517 = _key_location_18782 - 1;
        if ((long)((unsigned long)_10517 +(unsigned long) HIGH_BITS) >= 0){
            _10517 = NewDouble((double)_10517);
        }
    }
    else {
        _10517 = NewDouble(DBL_PTR(_key_location_18782)->dbl - (double)1);
    }
    if (IS_ATOM_INT(_10517)) {
        if (_10517 <= INT15 && _10517 >= -INT15)
        _10518 = 4 * _10517;
        else
        _10518 = NewDouble(4 * (double)_10517);
    }
    else {
        _10518 = NewDouble((double)4 * DBL_PTR(_10517)->dbl);
    }
    DeRef(_10517);
    _10517 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18777) && IS_ATOM_INT(_10518)) {
        _10519 = _records_ptr_18777 + _10518;
        if ((long)((unsigned long)_10519 + (unsigned long)HIGH_BITS) >= 0) 
        _10519 = NewDouble((double)_10519);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18777)) {
            _10519 = NewDouble((double)_records_ptr_18777 + DBL_PTR(_10518)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10518)) {
                _10519 = NewDouble(DBL_PTR(_records_ptr_18777)->dbl + (double)_10518);
            }
            else
            _10519 = NewDouble(DBL_PTR(_records_ptr_18777)->dbl + DBL_PTR(_10518)->dbl);
        }
    }
    DeRef(_10518);
    _10518 = NOVALUE;
    DeRef(_pos_inlined_seek_at_445_18859);
    _pos_inlined_seek_at_445_18859 = _10519;
    _10519 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_445_18859);
    DeRef(_seek_1__tmp_at448_18861);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_445_18859;
    _seek_1__tmp_at448_18861 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_448_18860 = machine(19, _seek_1__tmp_at448_18861);
    DeRef(_pos_inlined_seek_at_445_18859);
    _pos_inlined_seek_at_445_18859 = NOVALUE;
    DeRef(_seek_1__tmp_at448_18861);
    _seek_1__tmp_at448_18861 = NOVALUE;

    /** 	for i = key_location to nrecs+1 do*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _10520 = _nrecs_18778 + 1;
        if (_10520 > MAXINT){
            _10520 = NewDouble((double)_10520);
        }
    }
    else
    _10520 = binary_op(PLUS, 1, _nrecs_18778);
    {
        int _i_18863;
        Ref(_key_location_18782);
        _i_18863 = _key_location_18782;
LA: 
        if (binary_op_a(GREATER, _i_18863, _10520)){
            goto LB; // [468] 527
        }

        /** 		put4(key_pointers[i+r-nrecs])*/
        if (IS_ATOM_INT(_i_18863)) {
            _10521 = _i_18863 + _r_18787;
            if ((long)((unsigned long)_10521 + (unsigned long)HIGH_BITS) >= 0) 
            _10521 = NewDouble((double)_10521);
        }
        else {
            _10521 = NewDouble(DBL_PTR(_i_18863)->dbl + (double)_r_18787);
        }
        if (IS_ATOM_INT(_10521) && IS_ATOM_INT(_nrecs_18778)) {
            _10522 = _10521 - _nrecs_18778;
        }
        else {
            if (IS_ATOM_INT(_10521)) {
                _10522 = NewDouble((double)_10521 - DBL_PTR(_nrecs_18778)->dbl);
            }
            else {
                if (IS_ATOM_INT(_nrecs_18778)) {
                    _10522 = NewDouble(DBL_PTR(_10521)->dbl - (double)_nrecs_18778);
                }
                else
                _10522 = NewDouble(DBL_PTR(_10521)->dbl - DBL_PTR(_nrecs_18778)->dbl);
            }
        }
        DeRef(_10521);
        _10521 = NOVALUE;
        _2 = (int)SEQ_PTR(_48key_pointers_17062);
        if (!IS_ATOM_INT(_10522)){
            _10523 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_10522)->dbl));
        }
        else{
            _10523 = (int)*(((s1_ptr)_2)->base + _10522);
        }
        Ref(_10523);
        DeRef(_x_inlined_put4_at_490_18869);
        _x_inlined_put4_at_490_18869 = _10523;
        _10523 = NOVALUE;

        /** 	poke4(mem0, x) -- faster than doing divides etc.*/
        if (IS_ATOM_INT(_48mem0_17097)){
            poke4_addr = (unsigned long *)_48mem0_17097;
        }
        else {
            poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
        }
        if (IS_ATOM_INT(_x_inlined_put4_at_490_18869)) {
            *poke4_addr = (unsigned long)_x_inlined_put4_at_490_18869;
        }
        else if (IS_ATOM(_x_inlined_put4_at_490_18869)) {
            *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_490_18869)->dbl;
        }
        else {
            _1 = (int)SEQ_PTR(_x_inlined_put4_at_490_18869);
            _1 = (int)((s1_ptr)_1)->base;
            while (1) {
                _1 += 4;
                _2 = *((int *)_1);
                if (IS_ATOM_INT(_2))
                *(int *)poke4_addr++ = (unsigned long)_2;
                else if (_2 == NOVALUE)
                break;
                else {
                    *(int *)poke4_addr++ = (unsigned long)DBL_PTR(_2)->dbl;
                }
            }
        }

        /** 	puts(current_db, peek(memseq))*/
        DeRefi(_put4_1__tmp_at493_18870);
        _1 = (int)SEQ_PTR(_48memseq_17332);
        poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
        _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
        poke4_addr = (unsigned long *)NewS1(_2);
        _put4_1__tmp_at493_18870 = MAKE_SEQ(poke4_addr);
        poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
        while (--_2 >= 0) {
            poke4_addr++;
            _1 = (int)(unsigned char)*poke_addr++;
            *(int *)poke4_addr = _1;
        }
        EPuts(_48current_db_17055, _put4_1__tmp_at493_18870); // DJP 

        /** end procedure*/
        goto LC; // [515] 518
LC: 
        DeRef(_x_inlined_put4_at_490_18869);
        _x_inlined_put4_at_490_18869 = NOVALUE;
        DeRefi(_put4_1__tmp_at493_18870);
        _put4_1__tmp_at493_18870 = NOVALUE;

        /** 	end for*/
        _0 = _i_18863;
        if (IS_ATOM_INT(_i_18863)) {
            _i_18863 = _i_18863 + 1;
            if ((long)((unsigned long)_i_18863 +(unsigned long) HIGH_BITS) >= 0){
                _i_18863 = NewDouble((double)_i_18863);
            }
        }
        else {
            _i_18863 = binary_op_a(PLUS, _i_18863, 1);
        }
        DeRef(_0);
        goto LA; // [522] 475
LB: 
        ;
        DeRef(_i_18863);
    }

    /** 	io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18779);
    DeRef(_seek_1__tmp_at530_18873);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _current_block_18779;
    _seek_1__tmp_at530_18873 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_530_18872 = machine(19, _seek_1__tmp_at530_18873);
    DeRef(_seek_1__tmp_at530_18873);
    _seek_1__tmp_at530_18873 = NOVALUE;

    /** 	nrecs += 1*/
    _0 = _nrecs_18778;
    if (IS_ATOM_INT(_nrecs_18778)) {
        _nrecs_18778 = _nrecs_18778 + 1;
        if (_nrecs_18778 > MAXINT){
            _nrecs_18778 = NewDouble((double)_nrecs_18778);
        }
    }
    else
    _nrecs_18778 = binary_op(PLUS, 1, _nrecs_18778);
    DeRef(_0);

    /** 	put4(nrecs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_nrecs_18778)) {
        *poke4_addr = (unsigned long)_nrecs_18778;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_nrecs_18778)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at551_18876);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at551_18876 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at551_18876); // DJP 

    /** end procedure*/
    goto LD; // [573] 576
LD: 
    DeRefi(_put4_1__tmp_at551_18876);
    _put4_1__tmp_at551_18876 = NOVALUE;

    /** 	io:seek(current_db, records_ptr - 4)*/
    if (IS_ATOM_INT(_records_ptr_18777)) {
        _10525 = _records_ptr_18777 - 4;
        if ((long)((unsigned long)_10525 +(unsigned long) HIGH_BITS) >= 0){
            _10525 = NewDouble((double)_10525);
        }
    }
    else {
        _10525 = NewDouble(DBL_PTR(_records_ptr_18777)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_585_18879);
    _pos_inlined_seek_at_585_18879 = _10525;
    _10525 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_585_18879);
    DeRef(_seek_1__tmp_at588_18881);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_585_18879;
    _seek_1__tmp_at588_18881 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_588_18880 = machine(19, _seek_1__tmp_at588_18881);
    DeRef(_pos_inlined_seek_at_585_18879);
    _pos_inlined_seek_at_585_18879 = NOVALUE;
    DeRef(_seek_1__tmp_at588_18881);
    _seek_1__tmp_at588_18881 = NOVALUE;

    /** 	size = get4() - 4*/
    _10526 = _48get4();
    DeRef(_size_18780);
    if (IS_ATOM_INT(_10526)) {
        _size_18780 = _10526 - 4;
        if ((long)((unsigned long)_size_18780 +(unsigned long) HIGH_BITS) >= 0){
            _size_18780 = NewDouble((double)_size_18780);
        }
    }
    else {
        _size_18780 = binary_op(MINUS, _10526, 4);
    }
    DeRef(_10526);
    _10526 = NOVALUE;

    /** 	if nrecs*4 > size-4 then*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        if (_nrecs_18778 == (short)_nrecs_18778)
        _10528 = _nrecs_18778 * 4;
        else
        _10528 = NewDouble(_nrecs_18778 * (double)4);
    }
    else {
        _10528 = NewDouble(DBL_PTR(_nrecs_18778)->dbl * (double)4);
    }
    if (IS_ATOM_INT(_size_18780)) {
        _10529 = _size_18780 - 4;
        if ((long)((unsigned long)_10529 +(unsigned long) HIGH_BITS) >= 0){
            _10529 = NewDouble((double)_10529);
        }
    }
    else {
        _10529 = NewDouble(DBL_PTR(_size_18780)->dbl - (double)4);
    }
    if (binary_op_a(LESSEQ, _10528, _10529)){
        DeRef(_10528);
        _10528 = NOVALUE;
        DeRef(_10529);
        _10529 = NOVALUE;
        goto LE; // [621] 1217
    }
    DeRef(_10528);
    _10528 = NOVALUE;
    DeRef(_10529);
    _10529 = NOVALUE;

    /** 		new_size = 8 * (20 + floor(sqrt(1.5 * total_recs)))*/
    if (IS_ATOM_INT(_total_recs_18786)) {
        _10533 = NewDouble(DBL_PTR(_10532)->dbl * (double)_total_recs_18786);
    }
    else
    _10533 = NewDouble(DBL_PTR(_10532)->dbl * DBL_PTR(_total_recs_18786)->dbl);
    _10534 = unary_op(SQRT, _10533);
    DeRefDS(_10533);
    _10533 = NOVALUE;
    _10535 = unary_op(FLOOR, _10534);
    DeRefDS(_10534);
    _10534 = NOVALUE;
    if (IS_ATOM_INT(_10535)) {
        _10536 = 20 + _10535;
        if ((long)((unsigned long)_10536 + (unsigned long)HIGH_BITS) >= 0) 
        _10536 = NewDouble((double)_10536);
    }
    else {
        _10536 = NewDouble((double)20 + DBL_PTR(_10535)->dbl);
    }
    DeRef(_10535);
    _10535 = NOVALUE;
    DeRef(_new_size_18781);
    if (IS_ATOM_INT(_10536)) {
        if (_10536 <= INT15 && _10536 >= -INT15)
        _new_size_18781 = 8 * _10536;
        else
        _new_size_18781 = NewDouble(8 * (double)_10536);
    }
    else {
        _new_size_18781 = NewDouble((double)8 * DBL_PTR(_10536)->dbl);
    }
    DeRef(_10536);
    _10536 = NOVALUE;

    /** 		new_recs = floor(new_size/8)*/
    if (IS_ATOM_INT(_new_size_18781)) {
        if (8 > 0 && _new_size_18781 >= 0) {
            _new_recs_18789 = _new_size_18781 / 8;
        }
        else {
            temp_dbl = floor((double)_new_size_18781 / (double)8);
            _new_recs_18789 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _new_size_18781, 8);
        _new_recs_18789 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    if (!IS_ATOM_INT(_new_recs_18789)) {
        _1 = (long)(DBL_PTR(_new_recs_18789)->dbl);
        DeRefDS(_new_recs_18789);
        _new_recs_18789 = _1;
    }

    /** 		if new_recs > floor(nrecs/2) then*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _10539 = _nrecs_18778 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18778, 2);
        _10539 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (binary_op_a(LESSEQ, _new_recs_18789, _10539)){
        DeRef(_10539);
        _10539 = NOVALUE;
        goto LF; // [659] 672
    }
    DeRef(_10539);
    _10539 = NOVALUE;

    /** 			new_recs = floor(nrecs/2)*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _new_recs_18789 = _nrecs_18778 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _nrecs_18778, 2);
        _new_recs_18789 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    if (!IS_ATOM_INT(_new_recs_18789)) {
        _1 = (long)(DBL_PTR(_new_recs_18789)->dbl);
        DeRefDS(_new_recs_18789);
        _new_recs_18789 = _1;
    }
LF: 

    /** 		io:seek(current_db, records_ptr + (nrecs-new_recs)*4)*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _10542 = _nrecs_18778 - _new_recs_18789;
        if ((long)((unsigned long)_10542 +(unsigned long) HIGH_BITS) >= 0){
            _10542 = NewDouble((double)_10542);
        }
    }
    else {
        _10542 = NewDouble(DBL_PTR(_nrecs_18778)->dbl - (double)_new_recs_18789);
    }
    if (IS_ATOM_INT(_10542)) {
        if (_10542 == (short)_10542)
        _10543 = _10542 * 4;
        else
        _10543 = NewDouble(_10542 * (double)4);
    }
    else {
        _10543 = NewDouble(DBL_PTR(_10542)->dbl * (double)4);
    }
    DeRef(_10542);
    _10542 = NOVALUE;
    if (IS_ATOM_INT(_records_ptr_18777) && IS_ATOM_INT(_10543)) {
        _10544 = _records_ptr_18777 + _10543;
        if ((long)((unsigned long)_10544 + (unsigned long)HIGH_BITS) >= 0) 
        _10544 = NewDouble((double)_10544);
    }
    else {
        if (IS_ATOM_INT(_records_ptr_18777)) {
            _10544 = NewDouble((double)_records_ptr_18777 + DBL_PTR(_10543)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10543)) {
                _10544 = NewDouble(DBL_PTR(_records_ptr_18777)->dbl + (double)_10543);
            }
            else
            _10544 = NewDouble(DBL_PTR(_records_ptr_18777)->dbl + DBL_PTR(_10543)->dbl);
        }
    }
    DeRef(_10543);
    _10543 = NOVALUE;
    DeRef(_pos_inlined_seek_at_687_18904);
    _pos_inlined_seek_at_687_18904 = _10544;
    _10544 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_687_18904);
    DeRef(_seek_1__tmp_at690_18906);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_687_18904;
    _seek_1__tmp_at690_18906 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_690_18905 = machine(19, _seek_1__tmp_at690_18906);
    DeRef(_pos_inlined_seek_at_687_18904);
    _pos_inlined_seek_at_687_18904 = NOVALUE;
    DeRef(_seek_1__tmp_at690_18906);
    _seek_1__tmp_at690_18906 = NOVALUE;

    /** 		last_part = io:get_bytes(current_db, new_recs*4)*/
    if (_new_recs_18789 == (short)_new_recs_18789)
    _10545 = _new_recs_18789 * 4;
    else
    _10545 = NewDouble(_new_recs_18789 * (double)4);
    _0 = _last_part_18773;
    _last_part_18773 = _17get_bytes(_48current_db_17055, _10545);
    DeRef(_0);
    _10545 = NOVALUE;

    /** 		new_block = db_allocate(new_size)*/
    Ref(_new_size_18781);
    _0 = _new_block_18783;
    _new_block_18783 = _48db_allocate(_new_size_18781);
    DeRef(_0);

    /** 		putn(last_part)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _last_part_18773); // DJP 

    /** end procedure*/
    goto L10; // [736] 739
L10: 

    /** 		putn(repeat(0, new_size-length(last_part)))*/
    if (IS_SEQUENCE(_last_part_18773)){
            _10548 = SEQ_PTR(_last_part_18773)->length;
    }
    else {
        _10548 = 1;
    }
    if (IS_ATOM_INT(_new_size_18781)) {
        _10549 = _new_size_18781 - _10548;
    }
    else {
        _10549 = NewDouble(DBL_PTR(_new_size_18781)->dbl - (double)_10548);
    }
    _10548 = NOVALUE;
    _10550 = Repeat(0, _10549);
    DeRef(_10549);
    _10549 = NOVALUE;
    DeRefi(_s_inlined_putn_at_751_18915);
    _s_inlined_putn_at_751_18915 = _10550;
    _10550 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_751_18915); // DJP 

    /** end procedure*/
    goto L11; // [766] 769
L11: 
    DeRefi(_s_inlined_putn_at_751_18915);
    _s_inlined_putn_at_751_18915 = NOVALUE;

    /** 		io:seek(current_db, current_block)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_current_block_18779);
    DeRef(_seek_1__tmp_at774_18918);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _current_block_18779;
    _seek_1__tmp_at774_18918 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_774_18917 = machine(19, _seek_1__tmp_at774_18918);
    DeRef(_seek_1__tmp_at774_18918);
    _seek_1__tmp_at774_18918 = NOVALUE;

    /** 		put4(nrecs-new_recs)*/
    if (IS_ATOM_INT(_nrecs_18778)) {
        _10551 = _nrecs_18778 - _new_recs_18789;
        if ((long)((unsigned long)_10551 +(unsigned long) HIGH_BITS) >= 0){
            _10551 = NewDouble((double)_10551);
        }
    }
    else {
        _10551 = NewDouble(DBL_PTR(_nrecs_18778)->dbl - (double)_new_recs_18789);
    }
    DeRef(_x_inlined_put4_at_793_18921);
    _x_inlined_put4_at_793_18921 = _10551;
    _10551 = NOVALUE;

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_x_inlined_put4_at_793_18921)) {
        *poke4_addr = (unsigned long)_x_inlined_put4_at_793_18921;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_x_inlined_put4_at_793_18921)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at796_18922);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at796_18922 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at796_18922); // DJP 

    /** end procedure*/
    goto L12; // [818] 821
L12: 
    DeRef(_x_inlined_put4_at_793_18921);
    _x_inlined_put4_at_793_18921 = NOVALUE;
    DeRefi(_put4_1__tmp_at796_18922);
    _put4_1__tmp_at796_18922 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18779)) {
        _10552 = _current_block_18779 + 8;
        if ((long)((unsigned long)_10552 + (unsigned long)HIGH_BITS) >= 0) 
        _10552 = NewDouble((double)_10552);
    }
    else {
        _10552 = NewDouble(DBL_PTR(_current_block_18779)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_830_18925);
    _pos_inlined_seek_at_830_18925 = _10552;
    _10552 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_830_18925);
    DeRef(_seek_1__tmp_at833_18927);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_830_18925;
    _seek_1__tmp_at833_18927 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_833_18926 = machine(19, _seek_1__tmp_at833_18927);
    DeRef(_pos_inlined_seek_at_830_18925);
    _pos_inlined_seek_at_830_18925 = NOVALUE;
    DeRef(_seek_1__tmp_at833_18927);
    _seek_1__tmp_at833_18927 = NOVALUE;

    /** 		remaining = io:get_bytes(current_db, index_ptr+blocks*8-(current_block+8))*/
    if (_blocks_18788 == (short)_blocks_18788)
    _10553 = _blocks_18788 * 8;
    else
    _10553 = NewDouble(_blocks_18788 * (double)8);
    if (IS_ATOM_INT(_index_ptr_18784) && IS_ATOM_INT(_10553)) {
        _10554 = _index_ptr_18784 + _10553;
        if ((long)((unsigned long)_10554 + (unsigned long)HIGH_BITS) >= 0) 
        _10554 = NewDouble((double)_10554);
    }
    else {
        if (IS_ATOM_INT(_index_ptr_18784)) {
            _10554 = NewDouble((double)_index_ptr_18784 + DBL_PTR(_10553)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10553)) {
                _10554 = NewDouble(DBL_PTR(_index_ptr_18784)->dbl + (double)_10553);
            }
            else
            _10554 = NewDouble(DBL_PTR(_index_ptr_18784)->dbl + DBL_PTR(_10553)->dbl);
        }
    }
    DeRef(_10553);
    _10553 = NOVALUE;
    if (IS_ATOM_INT(_current_block_18779)) {
        _10555 = _current_block_18779 + 8;
        if ((long)((unsigned long)_10555 + (unsigned long)HIGH_BITS) >= 0) 
        _10555 = NewDouble((double)_10555);
    }
    else {
        _10555 = NewDouble(DBL_PTR(_current_block_18779)->dbl + (double)8);
    }
    if (IS_ATOM_INT(_10554) && IS_ATOM_INT(_10555)) {
        _10556 = _10554 - _10555;
        if ((long)((unsigned long)_10556 +(unsigned long) HIGH_BITS) >= 0){
            _10556 = NewDouble((double)_10556);
        }
    }
    else {
        if (IS_ATOM_INT(_10554)) {
            _10556 = NewDouble((double)_10554 - DBL_PTR(_10555)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10555)) {
                _10556 = NewDouble(DBL_PTR(_10554)->dbl - (double)_10555);
            }
            else
            _10556 = NewDouble(DBL_PTR(_10554)->dbl - DBL_PTR(_10555)->dbl);
        }
    }
    DeRef(_10554);
    _10554 = NOVALUE;
    DeRef(_10555);
    _10555 = NOVALUE;
    _0 = _remaining_18774;
    _remaining_18774 = _17get_bytes(_48current_db_17055, _10556);
    DeRef(_0);
    _10556 = NOVALUE;

    /** 		io:seek(current_db, current_block+8)*/
    if (IS_ATOM_INT(_current_block_18779)) {
        _10558 = _current_block_18779 + 8;
        if ((long)((unsigned long)_10558 + (unsigned long)HIGH_BITS) >= 0) 
        _10558 = NewDouble((double)_10558);
    }
    else {
        _10558 = NewDouble(DBL_PTR(_current_block_18779)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_881_18935);
    _pos_inlined_seek_at_881_18935 = _10558;
    _10558 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_881_18935);
    DeRef(_seek_1__tmp_at884_18937);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_881_18935;
    _seek_1__tmp_at884_18937 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_884_18936 = machine(19, _seek_1__tmp_at884_18937);
    DeRef(_pos_inlined_seek_at_881_18935);
    _pos_inlined_seek_at_881_18935 = NOVALUE;
    DeRef(_seek_1__tmp_at884_18937);
    _seek_1__tmp_at884_18937 = NOVALUE;

    /** 		put4(new_recs)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)_new_recs_18789;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at899_18939);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at899_18939 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at899_18939); // DJP 

    /** end procedure*/
    goto L13; // [921] 924
L13: 
    DeRefi(_put4_1__tmp_at899_18939);
    _put4_1__tmp_at899_18939 = NOVALUE;

    /** 		put4(new_block)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_new_block_18783)) {
        *poke4_addr = (unsigned long)_new_block_18783;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_block_18783)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at927_18941);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at927_18941 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at927_18941); // DJP 

    /** end procedure*/
    goto L14; // [949] 952
L14: 
    DeRefi(_put4_1__tmp_at927_18941);
    _put4_1__tmp_at927_18941 = NOVALUE;

    /** 		putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_18774); // DJP 

    /** end procedure*/
    goto L15; // [965] 968
L15: 

    /** 		io:seek(current_db, current_table_pos+8)*/
    if (IS_ATOM_INT(_48current_table_pos_17056)) {
        _10559 = _48current_table_pos_17056 + 8;
        if ((long)((unsigned long)_10559 + (unsigned long)HIGH_BITS) >= 0) 
        _10559 = NewDouble((double)_10559);
    }
    else {
        _10559 = NewDouble(DBL_PTR(_48current_table_pos_17056)->dbl + (double)8);
    }
    DeRef(_pos_inlined_seek_at_977_18945);
    _pos_inlined_seek_at_977_18945 = _10559;
    _10559 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_977_18945);
    DeRef(_seek_1__tmp_at980_18947);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_977_18945;
    _seek_1__tmp_at980_18947 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_980_18946 = machine(19, _seek_1__tmp_at980_18947);
    DeRef(_pos_inlined_seek_at_977_18945);
    _pos_inlined_seek_at_977_18945 = NOVALUE;
    DeRef(_seek_1__tmp_at980_18947);
    _seek_1__tmp_at980_18947 = NOVALUE;

    /** 		blocks += 1*/
    _blocks_18788 = _blocks_18788 + 1;

    /** 		put4(blocks)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    *poke4_addr = (unsigned long)_blocks_18788;

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1001_18950);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1001_18950 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at1001_18950); // DJP 

    /** end procedure*/
    goto L16; // [1023] 1026
L16: 
    DeRefi(_put4_1__tmp_at1001_18950);
    _put4_1__tmp_at1001_18950 = NOVALUE;

    /** 		io:seek(current_db, index_ptr-4)*/
    if (IS_ATOM_INT(_index_ptr_18784)) {
        _10561 = _index_ptr_18784 - 4;
        if ((long)((unsigned long)_10561 +(unsigned long) HIGH_BITS) >= 0){
            _10561 = NewDouble((double)_10561);
        }
    }
    else {
        _10561 = NewDouble(DBL_PTR(_index_ptr_18784)->dbl - (double)4);
    }
    DeRef(_pos_inlined_seek_at_1035_18953);
    _pos_inlined_seek_at_1035_18953 = _10561;
    _10561 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1035_18953);
    DeRef(_seek_1__tmp_at1038_18955);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_1035_18953;
    _seek_1__tmp_at1038_18955 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1038_18954 = machine(19, _seek_1__tmp_at1038_18955);
    DeRef(_pos_inlined_seek_at_1035_18953);
    _pos_inlined_seek_at_1035_18953 = NOVALUE;
    DeRef(_seek_1__tmp_at1038_18955);
    _seek_1__tmp_at1038_18955 = NOVALUE;

    /** 		size = get4() - 4*/
    _10562 = _48get4();
    DeRef(_size_18780);
    if (IS_ATOM_INT(_10562)) {
        _size_18780 = _10562 - 4;
        if ((long)((unsigned long)_size_18780 +(unsigned long) HIGH_BITS) >= 0){
            _size_18780 = NewDouble((double)_size_18780);
        }
    }
    else {
        _size_18780 = binary_op(MINUS, _10562, 4);
    }
    DeRef(_10562);
    _10562 = NOVALUE;

    /** 		if blocks*8 > size-8 then*/
    if (_blocks_18788 == (short)_blocks_18788)
    _10564 = _blocks_18788 * 8;
    else
    _10564 = NewDouble(_blocks_18788 * (double)8);
    if (IS_ATOM_INT(_size_18780)) {
        _10565 = _size_18780 - 8;
        if ((long)((unsigned long)_10565 +(unsigned long) HIGH_BITS) >= 0){
            _10565 = NewDouble((double)_10565);
        }
    }
    else {
        _10565 = NewDouble(DBL_PTR(_size_18780)->dbl - (double)8);
    }
    if (binary_op_a(LESSEQ, _10564, _10565)){
        DeRef(_10564);
        _10564 = NOVALUE;
        DeRef(_10565);
        _10565 = NOVALUE;
        goto L17; // [1071] 1216
    }
    DeRef(_10564);
    _10564 = NOVALUE;
    DeRef(_10565);
    _10565 = NOVALUE;

    /** 			remaining = io:get_bytes(current_db, blocks*8)*/
    if (_blocks_18788 == (short)_blocks_18788)
    _10567 = _blocks_18788 * 8;
    else
    _10567 = NewDouble(_blocks_18788 * (double)8);
    _0 = _remaining_18774;
    _remaining_18774 = _17get_bytes(_48current_db_17055, _10567);
    DeRef(_0);
    _10567 = NOVALUE;

    /** 			new_size = floor(size + size/2)*/
    if (IS_ATOM_INT(_size_18780)) {
        if (_size_18780 & 1) {
            _10569 = NewDouble((_size_18780 >> 1) + 0.5);
        }
        else
        _10569 = _size_18780 >> 1;
    }
    else {
        _10569 = binary_op(DIVIDE, _size_18780, 2);
    }
    if (IS_ATOM_INT(_size_18780) && IS_ATOM_INT(_10569)) {
        _10570 = _size_18780 + _10569;
        if ((long)((unsigned long)_10570 + (unsigned long)HIGH_BITS) >= 0) 
        _10570 = NewDouble((double)_10570);
    }
    else {
        if (IS_ATOM_INT(_size_18780)) {
            _10570 = NewDouble((double)_size_18780 + DBL_PTR(_10569)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10569)) {
                _10570 = NewDouble(DBL_PTR(_size_18780)->dbl + (double)_10569);
            }
            else
            _10570 = NewDouble(DBL_PTR(_size_18780)->dbl + DBL_PTR(_10569)->dbl);
        }
    }
    DeRef(_10569);
    _10569 = NOVALUE;
    DeRef(_new_size_18781);
    if (IS_ATOM_INT(_10570))
    _new_size_18781 = e_floor(_10570);
    else
    _new_size_18781 = unary_op(FLOOR, _10570);
    DeRef(_10570);
    _10570 = NOVALUE;

    /** 			new_index_ptr = db_allocate(new_size)*/
    Ref(_new_size_18781);
    _0 = _new_index_ptr_18785;
    _new_index_ptr_18785 = _48db_allocate(_new_size_18781);
    DeRef(_0);

    /** 			putn(remaining)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _remaining_18774); // DJP 

    /** end procedure*/
    goto L18; // [1120] 1123
L18: 

    /** 			putn(repeat(0, new_size-blocks*8))*/
    if (_blocks_18788 == (short)_blocks_18788)
    _10573 = _blocks_18788 * 8;
    else
    _10573 = NewDouble(_blocks_18788 * (double)8);
    if (IS_ATOM_INT(_new_size_18781) && IS_ATOM_INT(_10573)) {
        _10574 = _new_size_18781 - _10573;
    }
    else {
        if (IS_ATOM_INT(_new_size_18781)) {
            _10574 = NewDouble((double)_new_size_18781 - DBL_PTR(_10573)->dbl);
        }
        else {
            if (IS_ATOM_INT(_10573)) {
                _10574 = NewDouble(DBL_PTR(_new_size_18781)->dbl - (double)_10573);
            }
            else
            _10574 = NewDouble(DBL_PTR(_new_size_18781)->dbl - DBL_PTR(_10573)->dbl);
        }
    }
    DeRef(_10573);
    _10573 = NOVALUE;
    _10575 = Repeat(0, _10574);
    DeRef(_10574);
    _10574 = NOVALUE;
    DeRefi(_s_inlined_putn_at_1136_18973);
    _s_inlined_putn_at_1136_18973 = _10575;
    _10575 = NOVALUE;

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _s_inlined_putn_at_1136_18973); // DJP 

    /** end procedure*/
    goto L19; // [1151] 1154
L19: 
    DeRefi(_s_inlined_putn_at_1136_18973);
    _s_inlined_putn_at_1136_18973 = NOVALUE;

    /** 			db_free(index_ptr)*/
    Ref(_index_ptr_18784);
    _48db_free(_index_ptr_18784);

    /** 			io:seek(current_db, current_table_pos+12)*/
    if (IS_ATOM_INT(_48current_table_pos_17056)) {
        _10576 = _48current_table_pos_17056 + 12;
        if ((long)((unsigned long)_10576 + (unsigned long)HIGH_BITS) >= 0) 
        _10576 = NewDouble((double)_10576);
    }
    else {
        _10576 = NewDouble(DBL_PTR(_48current_table_pos_17056)->dbl + (double)12);
    }
    DeRef(_pos_inlined_seek_at_1170_18976);
    _pos_inlined_seek_at_1170_18976 = _10576;
    _10576 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_1170_18976);
    DeRef(_seek_1__tmp_at1173_18978);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_1170_18976;
    _seek_1__tmp_at1173_18978 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_1173_18977 = machine(19, _seek_1__tmp_at1173_18978);
    DeRef(_pos_inlined_seek_at_1170_18976);
    _pos_inlined_seek_at_1170_18976 = NOVALUE;
    DeRef(_seek_1__tmp_at1173_18978);
    _seek_1__tmp_at1173_18978 = NOVALUE;

    /** 			put4(new_index_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_new_index_ptr_18785)) {
        *poke4_addr = (unsigned long)_new_index_ptr_18785;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_new_index_ptr_18785)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at1188_18980);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at1188_18980 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at1188_18980); // DJP 

    /** end procedure*/
    goto L1A; // [1210] 1213
L1A: 
    DeRefi(_put4_1__tmp_at1188_18980);
    _put4_1__tmp_at1188_18980 = NOVALUE;
L17: 
LE: 

    /** 	return DB_OK*/
    DeRef(_key_18768);
    DeRef(_table_name_18770);
    DeRef(_key_string_18771);
    DeRef(_data_string_18772);
    DeRef(_last_part_18773);
    DeRef(_remaining_18774);
    DeRef(_key_ptr_18775);
    DeRef(_data_ptr_18776);
    DeRef(_records_ptr_18777);
    DeRef(_nrecs_18778);
    DeRef(_current_block_18779);
    DeRef(_size_18780);
    DeRef(_new_size_18781);
    DeRef(_key_location_18782);
    DeRef(_new_block_18783);
    DeRef(_index_ptr_18784);
    DeRef(_new_index_ptr_18785);
    DeRef(_total_recs_18786);
    DeRef(_10520);
    _10520 = NOVALUE;
    DeRef(_10522);
    _10522 = NOVALUE;
    return 0;
    ;
}


void _48db_replace_data(int _key_location_19115, int _data_19116, int _table_name_19117)
{
    int _10650 = NOVALUE;
    int _10649 = NOVALUE;
    int _10648 = NOVALUE;
    int _10647 = NOVALUE;
    int _10645 = NOVALUE;
    int _10644 = NOVALUE;
    int _10642 = NOVALUE;
    int _10639 = NOVALUE;
    int _10637 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19117 == _48current_table_name_17057)
    _10637 = 1;
    else if (IS_ATOM_INT(_table_name_19117) && IS_ATOM_INT(_48current_table_name_17057))
    _10637 = 0;
    else
    _10637 = (compare(_table_name_19117, _48current_table_name_17057) == 0);
    if (_10637 != 0)
    goto L1; // [11] 45
    _10637 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19117);
    _10639 = _48db_select_table(_table_name_19117);
    if (binary_op_a(EQUALS, _10639, 0)){
        DeRef(_10639);
        _10639 = NOVALUE;
        goto L2; // [20] 44
    }
    DeRef(_10639);
    _10639 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19115;
    *((int *)(_2+8)) = _data_19116;
    RefDS(_table_name_19117);
    *((int *)(_2+12)) = _table_name_19117;
    _10642 = MAKE_SEQ(_1);
    RefDS(_10461);
    RefDS(_10641);
    _48fatal(903, _10461, _10641, _10642);
    _10642 = NOVALUE;

    /** 			return*/
    DeRefDS(_table_name_19117);
    return;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17056, -1)){
        goto L3; // [49] 73
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19115;
    *((int *)(_2+8)) = _data_19116;
    Ref(_table_name_19117);
    *((int *)(_2+12)) = _table_name_19117;
    _10644 = MAKE_SEQ(_1);
    RefDS(_10465);
    RefDS(_10641);
    _48fatal(903, _10465, _10641, _10644);
    _10644 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19117);
    return;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10645 = (_key_location_19115 < 1);
    if (_10645 != 0) {
        goto L4; // [79] 97
    }
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _10647 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _10647 = 1;
    }
    _10648 = (_key_location_19115 > _10647);
    _10647 = NOVALUE;
    if (_10648 == 0)
    {
        DeRef(_10648);
        _10648 = NOVALUE;
        goto L5; // [93] 117
    }
    else{
        DeRef(_10648);
        _10648 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_replace_data", {key_location, data, table_name})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _key_location_19115;
    *((int *)(_2+8)) = _data_19116;
    Ref(_table_name_19117);
    *((int *)(_2+12)) = _table_name_19117;
    _10649 = MAKE_SEQ(_1);
    RefDS(_10589);
    RefDS(_10641);
    _48fatal(905, _10589, _10641, _10649);
    _10649 = NOVALUE;

    /** 		return*/
    DeRef(_table_name_19117);
    DeRef(_10645);
    _10645 = NOVALUE;
    return;
L5: 

    /** 	db_replace_recid(key_pointers[key_location], data)*/
    _2 = (int)SEQ_PTR(_48key_pointers_17062);
    _10650 = (int)*(((s1_ptr)_2)->base + _key_location_19115);
    Ref(_10650);
    _48db_replace_recid(_10650, _data_19116);
    _10650 = NOVALUE;

    /** end procedure*/
    DeRef(_table_name_19117);
    DeRef(_10645);
    _10645 = NOVALUE;
    return;
    ;
}


int _48db_table_size(int _table_name_19139)
{
    int _10659 = NOVALUE;
    int _10658 = NOVALUE;
    int _10656 = NOVALUE;
    int _10653 = NOVALUE;
    int _10651 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19139 == _48current_table_name_17057)
    _10651 = 1;
    else if (IS_ATOM_INT(_table_name_19139) && IS_ATOM_INT(_48current_table_name_17057))
    _10651 = 0;
    else
    _10651 = (compare(_table_name_19139, _48current_table_name_17057) == 0);
    if (_10651 != 0)
    goto L1; // [9] 42
    _10651 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19139);
    _10653 = _48db_select_table(_table_name_19139);
    if (binary_op_a(EQUALS, _10653, 0)){
        DeRef(_10653);
        _10653 = NOVALUE;
        goto L2; // [18] 41
    }
    DeRef(_10653);
    _10653 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_19139);
    *((int *)(_2+4)) = _table_name_19139;
    _10656 = MAKE_SEQ(_1);
    RefDS(_10461);
    RefDS(_10655);
    _48fatal(903, _10461, _10655, _10656);
    _10656 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19139);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17056, -1)){
        goto L3; // [46] 69
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_table_size", {table_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_table_name_19139);
    *((int *)(_2+4)) = _table_name_19139;
    _10658 = MAKE_SEQ(_1);
    RefDS(_10465);
    RefDS(_10655);
    _48fatal(903, _10465, _10655, _10658);
    _10658 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19139);
    return -1;
L3: 

    /** 	return length(key_pointers)*/
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _10659 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _10659 = 1;
    }
    DeRef(_table_name_19139);
    return _10659;
    ;
}


int _48db_record_data(int _key_location_19154, int _table_name_19155)
{
    int _data_ptr_19156 = NOVALUE;
    int _data_value_19157 = NOVALUE;
    int _seek_1__tmp_at126_19179 = NOVALUE;
    int _seek_inlined_seek_at_126_19178 = NOVALUE;
    int _pos_inlined_seek_at_123_19177 = NOVALUE;
    int _seek_1__tmp_at164_19186 = NOVALUE;
    int _seek_inlined_seek_at_164_19185 = NOVALUE;
    int _10674 = NOVALUE;
    int _10673 = NOVALUE;
    int _10672 = NOVALUE;
    int _10671 = NOVALUE;
    int _10670 = NOVALUE;
    int _10668 = NOVALUE;
    int _10667 = NOVALUE;
    int _10665 = NOVALUE;
    int _10662 = NOVALUE;
    int _10660 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19154)) {
        _1 = (long)(DBL_PTR(_key_location_19154)->dbl);
        DeRefDS(_key_location_19154);
        _key_location_19154 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19155 == _48current_table_name_17057)
    _10660 = 1;
    else if (IS_ATOM_INT(_table_name_19155) && IS_ATOM_INT(_48current_table_name_17057))
    _10660 = 0;
    else
    _10660 = (compare(_table_name_19155, _48current_table_name_17057) == 0);
    if (_10660 != 0)
    goto L1; // [11] 44
    _10660 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19155);
    _10662 = _48db_select_table(_table_name_19155);
    if (binary_op_a(EQUALS, _10662, 0)){
        DeRef(_10662);
        _10662 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10662);
    _10662 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_data", {key_location, table_name})*/
    RefDS(_table_name_19155);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19154;
    ((int *)_2)[2] = _table_name_19155;
    _10665 = MAKE_SEQ(_1);
    RefDS(_10461);
    RefDS(_10664);
    _48fatal(903, _10461, _10664, _10665);
    _10665 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19155);
    DeRef(_data_ptr_19156);
    DeRef(_data_value_19157);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17056, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19155);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19154;
    ((int *)_2)[2] = _table_name_19155;
    _10667 = MAKE_SEQ(_1);
    RefDS(_10465);
    RefDS(_10664);
    _48fatal(903, _10465, _10664, _10667);
    _10667 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19155);
    DeRef(_data_ptr_19156);
    DeRef(_data_value_19157);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10668 = (_key_location_19154 < 1);
    if (_10668 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _10670 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _10670 = 1;
    }
    _10671 = (_key_location_19154 > _10670);
    _10670 = NOVALUE;
    if (_10671 == 0)
    {
        DeRef(_10671);
        _10671 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10671);
        _10671 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_data", {key_location, table_name})*/
    Ref(_table_name_19155);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19154;
    ((int *)_2)[2] = _table_name_19155;
    _10672 = MAKE_SEQ(_1);
    RefDS(_10589);
    RefDS(_10664);
    _48fatal(905, _10589, _10664, _10672);
    _10672 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19155);
    DeRef(_data_ptr_19156);
    DeRef(_data_value_19157);
    DeRef(_10668);
    _10668 = NOVALUE;
    return -1;
L5: 

    /** 	io:seek(current_db, key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_48key_pointers_17062);
    _10673 = (int)*(((s1_ptr)_2)->base + _key_location_19154);
    Ref(_10673);
    DeRef(_pos_inlined_seek_at_123_19177);
    _pos_inlined_seek_at_123_19177 = _10673;
    _10673 = NOVALUE;

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_pos_inlined_seek_at_123_19177);
    DeRef(_seek_1__tmp_at126_19179);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _pos_inlined_seek_at_123_19177;
    _seek_1__tmp_at126_19179 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_126_19178 = machine(19, _seek_1__tmp_at126_19179);
    DeRef(_pos_inlined_seek_at_123_19177);
    _pos_inlined_seek_at_123_19177 = NOVALUE;
    DeRef(_seek_1__tmp_at126_19179);
    _seek_1__tmp_at126_19179 = NOVALUE;

    /** 	if length(vLastErrors) > 0 then return -1 end if*/
    if (IS_SEQUENCE(_48vLastErrors_17079)){
            _10674 = SEQ_PTR(_48vLastErrors_17079)->length;
    }
    else {
        _10674 = 1;
    }
    if (_10674 <= 0)
    goto L6; // [147] 156
    DeRef(_table_name_19155);
    DeRef(_data_ptr_19156);
    DeRef(_data_value_19157);
    DeRef(_10668);
    _10668 = NOVALUE;
    return -1;
L6: 

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19156;
    _data_ptr_19156 = _48get4();
    DeRef(_0);

    /** 	io:seek(current_db, data_ptr)*/

    /** 	return machine_func(M_SEEK, {fn, pos})*/
    Ref(_data_ptr_19156);
    DeRef(_seek_1__tmp_at164_19186);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _48current_db_17055;
    ((int *)_2)[2] = _data_ptr_19156;
    _seek_1__tmp_at164_19186 = MAKE_SEQ(_1);
    _seek_inlined_seek_at_164_19185 = machine(19, _seek_1__tmp_at164_19186);
    DeRef(_seek_1__tmp_at164_19186);
    _seek_1__tmp_at164_19186 = NOVALUE;

    /** 	data_value = decompress(0)*/
    _0 = _data_value_19157;
    _data_value_19157 = _48decompress(0);
    DeRef(_0);

    /** 	return data_value*/
    DeRef(_table_name_19155);
    DeRef(_data_ptr_19156);
    DeRef(_10668);
    _10668 = NOVALUE;
    return _data_value_19157;
    ;
}


int _48db_fetch_record(int _key_19190, int _table_name_19191)
{
    int _pos_19192 = NOVALUE;
    int _10680 = NOVALUE;
    int _0, _1, _2;
    

    /** 	pos = db_find_key(key, table_name)*/
    Ref(_key_19190);
    RefDS(_table_name_19191);
    _pos_19192 = _48db_find_key(_key_19190, _table_name_19191);
    if (!IS_ATOM_INT(_pos_19192)) {
        _1 = (long)(DBL_PTR(_pos_19192)->dbl);
        DeRefDS(_pos_19192);
        _pos_19192 = _1;
    }

    /** 	if pos > 0 then*/
    if (_pos_19192 <= 0)
    goto L1; // [12] 30

    /** 		return db_record_data(pos, table_name)*/
    RefDS(_table_name_19191);
    _10680 = _48db_record_data(_pos_19192, _table_name_19191);
    DeRef(_key_19190);
    DeRefDS(_table_name_19191);
    return _10680;
    goto L2; // [27] 37
L1: 

    /** 		return pos*/
    DeRef(_key_19190);
    DeRef(_table_name_19191);
    DeRef(_10680);
    _10680 = NOVALUE;
    return _pos_19192;
L2: 
    ;
}


int _48db_record_key(int _key_location_19200, int _table_name_19201)
{
    int _10695 = NOVALUE;
    int _10694 = NOVALUE;
    int _10693 = NOVALUE;
    int _10692 = NOVALUE;
    int _10691 = NOVALUE;
    int _10689 = NOVALUE;
    int _10688 = NOVALUE;
    int _10686 = NOVALUE;
    int _10683 = NOVALUE;
    int _10681 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_key_location_19200)) {
        _1 = (long)(DBL_PTR(_key_location_19200)->dbl);
        DeRefDS(_key_location_19200);
        _key_location_19200 = _1;
    }

    /** 	if not equal(table_name, current_table_name) then*/
    if (_table_name_19201 == _48current_table_name_17057)
    _10681 = 1;
    else if (IS_ATOM_INT(_table_name_19201) && IS_ATOM_INT(_48current_table_name_17057))
    _10681 = 0;
    else
    _10681 = (compare(_table_name_19201, _48current_table_name_17057) == 0);
    if (_10681 != 0)
    goto L1; // [11] 44
    _10681 = NOVALUE;

    /** 		if db_select_table(table_name) != DB_OK then*/
    RefDS(_table_name_19201);
    _10683 = _48db_select_table(_table_name_19201);
    if (binary_op_a(EQUALS, _10683, 0)){
        DeRef(_10683);
        _10683 = NOVALUE;
        goto L2; // [20] 43
    }
    DeRef(_10683);
    _10683 = NOVALUE;

    /** 			fatal(NO_TABLE, "invalid table name given", "db_record_key", {key_location, table_name})*/
    RefDS(_table_name_19201);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19200;
    ((int *)_2)[2] = _table_name_19201;
    _10686 = MAKE_SEQ(_1);
    RefDS(_10461);
    RefDS(_10685);
    _48fatal(903, _10461, _10685, _10686);
    _10686 = NOVALUE;

    /** 			return -1*/
    DeRefDS(_table_name_19201);
    return -1;
L2: 
L1: 

    /** 	if current_table_pos = -1 then*/
    if (binary_op_a(NOTEQ, _48current_table_pos_17056, -1)){
        goto L3; // [48] 71
    }

    /** 		fatal(NO_TABLE, "no table selected", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19201);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19200;
    ((int *)_2)[2] = _table_name_19201;
    _10688 = MAKE_SEQ(_1);
    RefDS(_10465);
    RefDS(_10685);
    _48fatal(903, _10465, _10685, _10688);
    _10688 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19201);
    return -1;
L3: 

    /** 	if key_location < 1 or key_location > length(key_pointers) then*/
    _10689 = (_key_location_19200 < 1);
    if (_10689 != 0) {
        goto L4; // [77] 95
    }
    if (IS_SEQUENCE(_48key_pointers_17062)){
            _10691 = SEQ_PTR(_48key_pointers_17062)->length;
    }
    else {
        _10691 = 1;
    }
    _10692 = (_key_location_19200 > _10691);
    _10691 = NOVALUE;
    if (_10692 == 0)
    {
        DeRef(_10692);
        _10692 = NOVALUE;
        goto L5; // [91] 114
    }
    else{
        DeRef(_10692);
        _10692 = NOVALUE;
    }
L4: 

    /** 		fatal(BAD_RECNO, "bad record number", "db_record_key", {key_location, table_name})*/
    Ref(_table_name_19201);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _key_location_19200;
    ((int *)_2)[2] = _table_name_19201;
    _10693 = MAKE_SEQ(_1);
    RefDS(_10589);
    RefDS(_10685);
    _48fatal(905, _10589, _10685, _10693);
    _10693 = NOVALUE;

    /** 		return -1*/
    DeRef(_table_name_19201);
    DeRef(_10689);
    _10689 = NOVALUE;
    return -1;
L5: 

    /** 	return key_value(key_pointers[key_location])*/
    _2 = (int)SEQ_PTR(_48key_pointers_17062);
    _10694 = (int)*(((s1_ptr)_2)->base + _key_location_19200);
    Ref(_10694);
    _10695 = _48key_value(_10694);
    _10694 = NOVALUE;
    DeRef(_table_name_19201);
    DeRef(_10689);
    _10689 = NOVALUE;
    return _10695;
    ;
}


void _48db_replace_recid(int _recid_19314, int _data_19315)
{
    int _old_size_19316 = NOVALUE;
    int _new_size_19317 = NOVALUE;
    int _data_ptr_19318 = NOVALUE;
    int _data_string_19319 = NOVALUE;
    int _put4_1__tmp_at111_19339 = NOVALUE;
    int _10794 = NOVALUE;
    int _10793 = NOVALUE;
    int _10792 = NOVALUE;
    int _10791 = NOVALUE;
    int _10790 = NOVALUE;
    int _10762 = NOVALUE;
    int _10760 = NOVALUE;
    int _10759 = NOVALUE;
    int _10758 = NOVALUE;
    int _10757 = NOVALUE;
    int _10756 = NOVALUE;
    int _10752 = NOVALUE;
    int _10751 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_recid_19314)) {
        _1 = (long)(DBL_PTR(_recid_19314)->dbl);
        DeRefDS(_recid_19314);
        _recid_19314 = _1;
    }

    /** 	seek(current_db, recid)*/
    _10794 = _17seek(_48current_db_17055, _recid_19314);
    DeRef(_10794);
    _10794 = NOVALUE;

    /** 	data_ptr = get4()*/
    _0 = _data_ptr_19318;
    _data_ptr_19318 = _48get4();
    DeRef(_0);

    /** 	seek(current_db, data_ptr-4)*/
    if (IS_ATOM_INT(_data_ptr_19318)) {
        _10751 = _data_ptr_19318 - 4;
        if ((long)((unsigned long)_10751 +(unsigned long) HIGH_BITS) >= 0){
            _10751 = NewDouble((double)_10751);
        }
    }
    else {
        _10751 = NewDouble(DBL_PTR(_data_ptr_19318)->dbl - (double)4);
    }
    _10793 = _17seek(_48current_db_17055, _10751);
    _10751 = NOVALUE;
    DeRef(_10793);
    _10793 = NOVALUE;

    /** 	old_size = get4()-4*/
    _10752 = _48get4();
    DeRef(_old_size_19316);
    if (IS_ATOM_INT(_10752)) {
        _old_size_19316 = _10752 - 4;
        if ((long)((unsigned long)_old_size_19316 +(unsigned long) HIGH_BITS) >= 0){
            _old_size_19316 = NewDouble((double)_old_size_19316);
        }
    }
    else {
        _old_size_19316 = binary_op(MINUS, _10752, 4);
    }
    DeRef(_10752);
    _10752 = NOVALUE;

    /** 	data_string = compress(data)*/
    _0 = _data_string_19319;
    _data_string_19319 = _48compress(_data_19315);
    DeRef(_0);

    /** 	new_size = length(data_string)*/
    if (IS_SEQUENCE(_data_string_19319)){
            _new_size_19317 = SEQ_PTR(_data_string_19319)->length;
    }
    else {
        _new_size_19317 = 1;
    }

    /** 	if new_size <= old_size and*/
    if (IS_ATOM_INT(_old_size_19316)) {
        _10756 = (_new_size_19317 <= _old_size_19316);
    }
    else {
        _10756 = ((double)_new_size_19317 <= DBL_PTR(_old_size_19316)->dbl);
    }
    if (_10756 == 0) {
        goto L1; // [62] 92
    }
    if (IS_ATOM_INT(_old_size_19316)) {
        _10758 = _old_size_19316 - 16;
        if ((long)((unsigned long)_10758 +(unsigned long) HIGH_BITS) >= 0){
            _10758 = NewDouble((double)_10758);
        }
    }
    else {
        _10758 = NewDouble(DBL_PTR(_old_size_19316)->dbl - (double)16);
    }
    if (IS_ATOM_INT(_10758)) {
        _10759 = (_new_size_19317 >= _10758);
    }
    else {
        _10759 = ((double)_new_size_19317 >= DBL_PTR(_10758)->dbl);
    }
    DeRef(_10758);
    _10758 = NOVALUE;
    if (_10759 == 0)
    {
        DeRef(_10759);
        _10759 = NOVALUE;
        goto L1; // [75] 92
    }
    else{
        DeRef(_10759);
        _10759 = NOVALUE;
    }

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19318);
    _10792 = _17seek(_48current_db_17055, _data_ptr_19318);
    DeRef(_10792);
    _10792 = NOVALUE;
    goto L2; // [89] 168
L1: 

    /** 		db_free(data_ptr)*/
    Ref(_data_ptr_19318);
    _48db_free(_data_ptr_19318);

    /** 		data_ptr = db_allocate(new_size + 8)*/
    _10760 = _new_size_19317 + 8;
    if ((long)((unsigned long)_10760 + (unsigned long)HIGH_BITS) >= 0) 
    _10760 = NewDouble((double)_10760);
    _0 = _data_ptr_19318;
    _data_ptr_19318 = _48db_allocate(_10760);
    DeRef(_0);
    _10760 = NOVALUE;

    /** 		seek(current_db, recid)*/
    _10791 = _17seek(_48current_db_17055, _recid_19314);
    DeRef(_10791);
    _10791 = NOVALUE;

    /** 		put4(data_ptr)*/

    /** 	poke4(mem0, x) -- faster than doing divides etc.*/
    if (IS_ATOM_INT(_48mem0_17097)){
        poke4_addr = (unsigned long *)_48mem0_17097;
    }
    else {
        poke4_addr = (unsigned long *)(unsigned long)(DBL_PTR(_48mem0_17097)->dbl);
    }
    if (IS_ATOM_INT(_data_ptr_19318)) {
        *poke4_addr = (unsigned long)_data_ptr_19318;
    }
    else {
        *poke4_addr = (unsigned long)DBL_PTR(_data_ptr_19318)->dbl;
    }

    /** 	puts(current_db, peek(memseq))*/
    DeRefi(_put4_1__tmp_at111_19339);
    _1 = (int)SEQ_PTR(_48memseq_17332);
    poke_addr = (unsigned char *)get_pos_int("peek", *(((s1_ptr)_1)->base+1));
    _2 = get_pos_int("peek", *(((s1_ptr)_1)->base+2));
    poke4_addr = (unsigned long *)NewS1(_2);
    _put4_1__tmp_at111_19339 = MAKE_SEQ(poke4_addr);
    poke4_addr = (unsigned long *)((s1_ptr)poke4_addr)->base;
    while (--_2 >= 0) {
        poke4_addr++;
        _1 = (int)(unsigned char)*poke_addr++;
        *(int *)poke4_addr = _1;
    }
    EPuts(_48current_db_17055, _put4_1__tmp_at111_19339); // DJP 

    /** end procedure*/
    goto L3; // [141] 144
L3: 
    DeRefi(_put4_1__tmp_at111_19339);
    _put4_1__tmp_at111_19339 = NOVALUE;

    /** 		seek(current_db, data_ptr)*/
    Ref(_data_ptr_19318);
    _10790 = _17seek(_48current_db_17055, _data_ptr_19318);
    DeRef(_10790);
    _10790 = NOVALUE;

    /** 		data_string &= repeat( 0, 8 )*/
    _10762 = Repeat(0, 8);
    Concat((object_ptr)&_data_string_19319, _data_string_19319, _10762);
    DeRefDS(_10762);
    _10762 = NOVALUE;
L2: 

    /** 	putn(data_string)*/

    /** 	puts(current_db, s)*/
    EPuts(_48current_db_17055, _data_string_19319); // DJP 

    /** end procedure*/
    goto L4; // [179] 182
L4: 

    /** end procedure*/
    DeRef(_old_size_19316);
    DeRef(_data_ptr_19318);
    DeRef(_data_string_19319);
    DeRef(_10756);
    _10756 = NOVALUE;
    return;
    ;
}



// 0xD684E755
