// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _49check_coverage()
{
    int _24972 = NOVALUE;
    int _24971 = NOVALUE;
    int _24970 = NOVALUE;
    int _24969 = NOVALUE;
    int _24968 = NOVALUE;
    int _24967 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length( file_coverage ) + 1 to length( known_files ) do*/
    if (IS_SEQUENCE(_49file_coverage_47740)){
            _24967 = SEQ_PTR(_49file_coverage_47740)->length;
    }
    else {
        _24967 = 1;
    }
    _24968 = _24967 + 1;
    _24967 = NOVALUE;
    if (IS_SEQUENCE(_13known_files_10637)){
            _24969 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _24969 = 1;
    }
    {
        int _i_47751;
        _i_47751 = _24968;
L1: 
        if (_i_47751 > _24969){
            goto L2; // [17] 58
        }

        /** 		file_coverage &= find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_13known_files_10637);
        _24970 = (int)*(((s1_ptr)_2)->base + _i_47751);
        Ref(_24970);
        _24971 = _14canonical_path(_24970, 0, 1);
        _24970 = NOVALUE;
        _24972 = find_from(_24971, _49covered_files_47739, 1);
        DeRef(_24971);
        _24971 = NOVALUE;
        Append(&_49file_coverage_47740, _49file_coverage_47740, _24972);
        _24972 = NOVALUE;

        /** 	end for*/
        _i_47751 = _i_47751 + 1;
        goto L1; // [53] 24
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_24968);
    _24968 = NOVALUE;
    return;
    ;
}


void _49init_coverage()
{
    int _cmd_47775 = NOVALUE;
    int _24990 = NOVALUE;
    int _24989 = NOVALUE;
    int _24987 = NOVALUE;
    int _24986 = NOVALUE;
    int _24985 = NOVALUE;
    int _24983 = NOVALUE;
    int _24981 = NOVALUE;
    int _24980 = NOVALUE;
    int _24978 = NOVALUE;
    int _24977 = NOVALUE;
    int _24976 = NOVALUE;
    int _24975 = NOVALUE;
    int _24974 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initialized_coverage then*/
    if (_49initialized_coverage_47747 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return*/
    return;
L1: 

    /** 	initialized_coverage = 1*/
    _49initialized_coverage_47747 = 1;

    /** 	for i = 1 to length( file_coverage ) do*/
    if (IS_SEQUENCE(_49file_coverage_47740)){
            _24974 = SEQ_PTR(_49file_coverage_47740)->length;
    }
    else {
        _24974 = 1;
    }
    {
        int _i_47766;
        _i_47766 = 1;
L2: 
        if (_i_47766 > _24974){
            goto L3; // [26] 67
        }

        /** 		file_coverage[i] = find( canonical_path( known_files[i],,1 ), covered_files )*/
        _2 = (int)SEQ_PTR(_13known_files_10637);
        _24975 = (int)*(((s1_ptr)_2)->base + _i_47766);
        Ref(_24975);
        _24976 = _14canonical_path(_24975, 0, 1);
        _24975 = NOVALUE;
        _24977 = find_from(_24976, _49covered_files_47739, 1);
        DeRef(_24976);
        _24976 = NOVALUE;
        _2 = (int)SEQ_PTR(_49file_coverage_47740);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _49file_coverage_47740 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_47766);
        *(int *)_2 = _24977;
        if( _1 != _24977 ){
        }
        _24977 = NOVALUE;

        /** 	end for*/
        _i_47766 = _i_47766 + 1;
        goto L2; // [62] 33
L3: 
        ;
    }

    /** 	if equal( coverage_db_name, "" ) then*/
    if (_49coverage_db_name_47741 == _21829)
    _24978 = 1;
    else if (IS_ATOM_INT(_49coverage_db_name_47741) && IS_ATOM_INT(_21829))
    _24978 = 0;
    else
    _24978 = (compare(_49coverage_db_name_47741, _21829) == 0);
    if (_24978 == 0)
    {
        _24978 = NOVALUE;
        goto L4; // [75] 105
    }
    else{
        _24978 = NOVALUE;
    }

    /** 		sequence cmd = command_line()*/
    DeRef(_cmd_47775);
    _cmd_47775 = Command_Line();

    /** 		coverage_db_name = canonical_path( filebase( cmd[2] ) & "-cvg.edb" )*/
    _2 = (int)SEQ_PTR(_cmd_47775);
    _24980 = (int)*(((s1_ptr)_2)->base + 2);
    RefDS(_24980);
    _24981 = _14filebase(_24980);
    _24980 = NOVALUE;
    if (IS_SEQUENCE(_24981) && IS_ATOM(_24982)) {
    }
    else if (IS_ATOM(_24981) && IS_SEQUENCE(_24982)) {
        Ref(_24981);
        Prepend(&_24983, _24982, _24981);
    }
    else {
        Concat((object_ptr)&_24983, _24981, _24982);
        DeRef(_24981);
        _24981 = NOVALUE;
    }
    DeRef(_24981);
    _24981 = NOVALUE;
    _0 = _14canonical_path(_24983, 0, 0);
    DeRefDS(_49coverage_db_name_47741);
    _49coverage_db_name_47741 = _0;
    _24983 = NOVALUE;
L4: 
    DeRef(_cmd_47775);
    _cmd_47775 = NOVALUE;

    /** 	if coverage_erase and file_exists( coverage_db_name ) then*/
    if (_49coverage_erase_47742 == 0) {
        goto L5; // [111] 151
    }
    RefDS(_49coverage_db_name_47741);
    _24986 = _14file_exists(_49coverage_db_name_47741);
    if (_24986 == 0) {
        DeRef(_24986);
        _24986 = NOVALUE;
        goto L5; // [122] 151
    }
    else {
        if (!IS_ATOM_INT(_24986) && DBL_PTR(_24986)->dbl == 0.0){
            DeRef(_24986);
            _24986 = NOVALUE;
            goto L5; // [122] 151
        }
        DeRef(_24986);
        _24986 = NOVALUE;
    }
    DeRef(_24986);
    _24986 = NOVALUE;

    /** 		if not delete_file( coverage_db_name ) then*/
    RefDS(_49coverage_db_name_47741);
    _24987 = _14delete_file(_49coverage_db_name_47741);
    if (IS_ATOM_INT(_24987)) {
        if (_24987 != 0){
            DeRef(_24987);
            _24987 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    else {
        if (DBL_PTR(_24987)->dbl != 0.0){
            DeRef(_24987);
            _24987 = NOVALUE;
            goto L6; // [133] 150
        }
    }
    DeRef(_24987);
    _24987 = NOVALUE;

    /** 			CompileErr( 335, { coverage_db_name } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_49coverage_db_name_47741);
    *((int *)(_2+4)) = _49coverage_db_name_47741;
    _24989 = MAKE_SEQ(_1);
    _43CompileErr(335, _24989, 0);
    _24989 = NOVALUE;
L6: 
L5: 

    /** 	if db_open( coverage_db_name ) = DB_OK then*/
    RefDS(_49coverage_db_name_47741);
    _24990 = _48db_open(_49coverage_db_name_47741, 0);
    if (binary_op_a(NOTEQ, _24990, 0)){
        DeRef(_24990);
        _24990 = NOVALUE;
        goto L7; // [162] 175
    }
    DeRef(_24990);
    _24990 = NOVALUE;

    /** 		read_coverage_db()*/
    _49read_coverage_db();

    /** 		db_close()*/
    _48db_close();
L7: 

    /** end procedure*/
    return;
    ;
}


void _49write_map(int _coverage_47804, int _table_name_47805)
{
    int _keys_47827 = NOVALUE;
    int _rec_47832 = NOVALUE;
    int _val_47836 = NOVALUE;
    int _31382 = NOVALUE;
    int _25007 = NOVALUE;
    int _25004 = NOVALUE;
    int _25002 = NOVALUE;
    int _25001 = NOVALUE;
    int _24999 = NOVALUE;
    int _24998 = NOVALUE;
    int _24996 = NOVALUE;
    int _24994 = NOVALUE;
    int _24992 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if db_select( coverage_db_name, DB_LOCK_EXCLUSIVE) = DB_OK then*/
    RefDS(_49coverage_db_name_47741);
    _24992 = _48db_select(_49coverage_db_name_47741, 2);
    if (binary_op_a(NOTEQ, _24992, 0)){
        DeRef(_24992);
        _24992 = NOVALUE;
        goto L1; // [16] 61
    }
    DeRef(_24992);
    _24992 = NOVALUE;

    /** 		if db_select_table( table_name ) != DB_OK then*/
    RefDS(_table_name_47805);
    _24994 = _48db_select_table(_table_name_47805);
    if (binary_op_a(EQUALS, _24994, 0)){
        DeRef(_24994);
        _24994 = NOVALUE;
        goto L2; // [28] 73
    }
    DeRef(_24994);
    _24994 = NOVALUE;

    /** 			if db_create_table( table_name ) != DB_OK then*/
    RefDS(_table_name_47805);
    _24996 = _48db_create_table(_table_name_47805, 50);
    if (binary_op_a(EQUALS, _24996, 0)){
        DeRef(_24996);
        _24996 = NOVALUE;
        goto L2; // [41] 73
    }
    DeRef(_24996);
    _24996 = NOVALUE;

    /** 				CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_47805);
    *((int *)(_2+4)) = _table_name_47805;
    _24998 = MAKE_SEQ(_1);
    _43CompileErr(336, _24998, 0);
    _24998 = NOVALUE;
    goto L2; // [58] 73
L1: 

    /** 		CompileErr( 336, {table_name} )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_table_name_47805);
    *((int *)(_2+4)) = _table_name_47805;
    _24999 = MAKE_SEQ(_1);
    _43CompileErr(336, _24999, 0);
    _24999 = NOVALUE;
L2: 

    /** 	sequence keys = map:keys( coverage )*/
    Ref(_coverage_47804);
    _0 = _keys_47827;
    _keys_47827 = _32keys(_coverage_47804, 0);
    DeRef(_0);

    /** 	for i = 1 to length( keys ) do*/
    if (IS_SEQUENCE(_keys_47827)){
            _25001 = SEQ_PTR(_keys_47827)->length;
    }
    else {
        _25001 = 1;
    }
    {
        int _i_47830;
        _i_47830 = 1;
L3: 
        if (_i_47830 > _25001){
            goto L4; // [87] 167
        }

        /** 		integer rec = db_find_key( keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_47827);
        _25002 = (int)*(((s1_ptr)_2)->base + _i_47830);
        Ref(_25002);
        RefDS(_48current_table_name_17057);
        _rec_47832 = _48db_find_key(_25002, _48current_table_name_17057);
        _25002 = NOVALUE;
        if (!IS_ATOM_INT(_rec_47832)) {
            _1 = (long)(DBL_PTR(_rec_47832)->dbl);
            DeRefDS(_rec_47832);
            _rec_47832 = _1;
        }

        /** 		integer val = map:get( coverage, keys[i] )*/
        _2 = (int)SEQ_PTR(_keys_47827);
        _25004 = (int)*(((s1_ptr)_2)->base + _i_47830);
        Ref(_coverage_47804);
        Ref(_25004);
        _val_47836 = _32get(_coverage_47804, _25004, 0);
        _25004 = NOVALUE;
        if (!IS_ATOM_INT(_val_47836)) {
            _1 = (long)(DBL_PTR(_val_47836)->dbl);
            DeRefDS(_val_47836);
            _val_47836 = _1;
        }

        /** 		if rec > 0 then*/
        if (_rec_47832 <= 0)
        goto L5; // [125] 141

        /** 			db_replace_data( rec, val )*/
        RefDS(_48current_table_name_17057);
        _48db_replace_data(_rec_47832, _val_47836, _48current_table_name_17057);
        goto L6; // [138] 158
L5: 

        /** 			db_insert( keys[i], val )*/
        _2 = (int)SEQ_PTR(_keys_47827);
        _25007 = (int)*(((s1_ptr)_2)->base + _i_47830);
        Ref(_25007);
        RefDS(_48current_table_name_17057);
        _31382 = _48db_insert(_25007, _val_47836, _48current_table_name_17057);
        _25007 = NOVALUE;
        DeRef(_31382);
        _31382 = NOVALUE;
L6: 

        /** 	end for*/
        _i_47830 = _i_47830 + 1;
        goto L3; // [162] 94
L4: 
        ;
    }

    /** end procedure*/
    DeRef(_coverage_47804);
    DeRefDS(_table_name_47805);
    DeRef(_keys_47827);
    return;
    ;
}


int _49write_coverage_db()
{
    int _25022 = NOVALUE;
    int _25021 = NOVALUE;
    int _25020 = NOVALUE;
    int _25019 = NOVALUE;
    int _25018 = NOVALUE;
    int _25017 = NOVALUE;
    int _25016 = NOVALUE;
    int _25015 = NOVALUE;
    int _25012 = NOVALUE;
    int _25010 = NOVALUE;
    int _25008 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if wrote_coverage then*/
    if (_49wrote_coverage_47845 == 0)
    {
        goto L1; // [5] 15
    }
    else{
    }

    /** 		return 1*/
    return 1;
L1: 

    /** 	wrote_coverage = 1*/
    _49wrote_coverage_47845 = 1;

    /** 	init_coverage()*/
    _49init_coverage();

    /** 	if not length( covered_files ) then*/
    if (IS_SEQUENCE(_49covered_files_47739)){
            _25008 = SEQ_PTR(_49covered_files_47739)->length;
    }
    else {
        _25008 = 1;
    }
    if (_25008 != 0)
    goto L2; // [31] 41
    _25008 = NOVALUE;

    /** 		return 1*/
    return 1;
L2: 

    /** 	if DB_OK != db_open( coverage_db_name, DB_LOCK_EXCLUSIVE) then*/
    RefDS(_49coverage_db_name_47741);
    _25010 = _48db_open(_49coverage_db_name_47741, 2);
    if (binary_op_a(EQUALS, 0, _25010)){
        DeRef(_25010);
        _25010 = NOVALUE;
        goto L3; // [54] 95
    }
    DeRef(_25010);
    _25010 = NOVALUE;

    /** 		if DB_OK != db_create( coverage_db_name ) then*/
    RefDS(_49coverage_db_name_47741);
    _25012 = _48db_create(_49coverage_db_name_47741, 0, 5, 5);
    if (binary_op_a(EQUALS, 0, _25012)){
        DeRef(_25012);
        _25012 = NOVALUE;
        goto L4; // [71] 94
    }
    DeRef(_25012);
    _25012 = NOVALUE;

    /** 			printf(2, "error opening %s\n", {coverage_db_name})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_49coverage_db_name_47741);
    *((int *)(_2+4)) = _49coverage_db_name_47741;
    _25015 = MAKE_SEQ(_1);
    EPrintf(2, _25014, _25015);
    DeRefDS(_25015);
    _25015 = NOVALUE;

    /** 			return 0*/
    return 0;
L4: 
L3: 

    /** 	process_lines()*/
    _49process_lines();

    /** 	for tx = 1 to length( routine_map ) do*/
    if (IS_SEQUENCE(_49routine_map_47745)){
            _25016 = SEQ_PTR(_49routine_map_47745)->length;
    }
    else {
        _25016 = 1;
    }
    {
        int _tx_47867;
        _tx_47867 = 1;
L5: 
        if (_tx_47867 > _25016){
            goto L6; // [106] 164
        }

        /** 		write_map( routine_map[tx], 'r' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_49routine_map_47745);
        _25017 = (int)*(((s1_ptr)_2)->base + _tx_47867);
        _2 = (int)SEQ_PTR(_49covered_files_47739);
        _25018 = (int)*(((s1_ptr)_2)->base + _tx_47867);
        if (IS_SEQUENCE(114) && IS_ATOM(_25018)) {
        }
        else if (IS_ATOM(114) && IS_SEQUENCE(_25018)) {
            Prepend(&_25019, _25018, 114);
        }
        else {
            Concat((object_ptr)&_25019, 114, _25018);
        }
        _25018 = NOVALUE;
        Ref(_25017);
        _49write_map(_25017, _25019);
        _25017 = NOVALUE;
        _25019 = NOVALUE;

        /** 		write_map( line_map[tx],    'l' & covered_files[tx] )*/
        _2 = (int)SEQ_PTR(_49line_map_47744);
        _25020 = (int)*(((s1_ptr)_2)->base + _tx_47867);
        _2 = (int)SEQ_PTR(_49covered_files_47739);
        _25021 = (int)*(((s1_ptr)_2)->base + _tx_47867);
        if (IS_SEQUENCE(108) && IS_ATOM(_25021)) {
        }
        else if (IS_ATOM(108) && IS_SEQUENCE(_25021)) {
            Prepend(&_25022, _25021, 108);
        }
        else {
            Concat((object_ptr)&_25022, 108, _25021);
        }
        _25021 = NOVALUE;
        Ref(_25020);
        _49write_map(_25020, _25022);
        _25020 = NOVALUE;
        _25022 = NOVALUE;

        /** 	end for*/
        _tx_47867 = _tx_47867 + 1;
        goto L5; // [159] 113
L6: 
        ;
    }

    /** 	db_close()*/
    _48db_close();

    /** 	routine_map = {}*/
    RefDS(_21829);
    DeRef(_49routine_map_47745);
    _49routine_map_47745 = _21829;

    /** 	line_map    = {}*/
    RefDS(_21829);
    DeRef(_49line_map_47744);
    _49line_map_47744 = _21829;

    /** 	return 1*/
    return 1;
    ;
}


void _49read_coverage_db()
{
    int _tables_47878 = NOVALUE;
    int _name_47884 = NOVALUE;
    int _fx_47888 = NOVALUE;
    int _the_map_47895 = NOVALUE;
    int _31381 = NOVALUE;
    int _25038 = NOVALUE;
    int _25037 = NOVALUE;
    int _25036 = NOVALUE;
    int _25032 = NOVALUE;
    int _25031 = NOVALUE;
    int _25030 = NOVALUE;
    int _25026 = NOVALUE;
    int _25025 = NOVALUE;
    int _25024 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence tables = db_table_list()*/
    _0 = _tables_47878;
    _tables_47878 = _48db_table_list();
    DeRef(_0);

    /** 	for i = 1 to length( tables ) do*/
    if (IS_SEQUENCE(_tables_47878)){
            _25024 = SEQ_PTR(_tables_47878)->length;
    }
    else {
        _25024 = 1;
    }
    {
        int _i_47882;
        _i_47882 = 1;
L1: 
        if (_i_47882 > _25024){
            goto L2; // [13] 159
        }

        /** 		sequence name = tables[i][2..$]*/
        _2 = (int)SEQ_PTR(_tables_47878);
        _25025 = (int)*(((s1_ptr)_2)->base + _i_47882);
        if (IS_SEQUENCE(_25025)){
                _25026 = SEQ_PTR(_25025)->length;
        }
        else {
            _25026 = 1;
        }
        rhs_slice_target = (object_ptr)&_name_47884;
        RHS_Slice(_25025, 2, _25026);
        _25025 = NOVALUE;

        /** 		integer fx = find( name, covered_files )*/
        _fx_47888 = find_from(_name_47884, _49covered_files_47739, 1);

        /** 		if not fx then*/
        if (_fx_47888 != 0)
        goto L3; // [45] 55

        /** 			continue*/
        DeRefDS(_name_47884);
        _name_47884 = NOVALUE;
        DeRef(_the_map_47895);
        _the_map_47895 = NOVALUE;
        goto L4; // [52] 154
L3: 

        /** 		db_select_table( tables[i] )*/
        _2 = (int)SEQ_PTR(_tables_47878);
        _25030 = (int)*(((s1_ptr)_2)->base + _i_47882);
        Ref(_25030);
        _31381 = _48db_select_table(_25030);
        _25030 = NOVALUE;
        DeRef(_31381);
        _31381 = NOVALUE;

        /** 		if tables[i][1] = 'r' then*/
        _2 = (int)SEQ_PTR(_tables_47878);
        _25031 = (int)*(((s1_ptr)_2)->base + _i_47882);
        _2 = (int)SEQ_PTR(_25031);
        _25032 = (int)*(((s1_ptr)_2)->base + 1);
        _25031 = NOVALUE;
        if (binary_op_a(NOTEQ, _25032, 114)){
            _25032 = NOVALUE;
            goto L5; // [77] 92
        }
        _25032 = NOVALUE;

        /** 			the_map = routine_map[fx]*/
        DeRef(_the_map_47895);
        _2 = (int)SEQ_PTR(_49routine_map_47745);
        _the_map_47895 = (int)*(((s1_ptr)_2)->base + _fx_47888);
        Ref(_the_map_47895);
        goto L6; // [89] 101
L5: 

        /** 			the_map = line_map[fx]*/
        DeRef(_the_map_47895);
        _2 = (int)SEQ_PTR(_49line_map_47744);
        _the_map_47895 = (int)*(((s1_ptr)_2)->base + _fx_47888);
        Ref(_the_map_47895);
L6: 

        /** 		for j = 1 to db_table_size() do*/
        RefDS(_48current_table_name_17057);
        _25036 = _48db_table_size(_48current_table_name_17057);
        {
            int _j_47904;
            _j_47904 = 1;
L7: 
            if (binary_op_a(GREATER, _j_47904, _25036)){
                goto L8; // [109] 150
            }

            /** 			map:put( the_map, db_record_key( j ), db_record_data( j ), map:ADD )*/
            Ref(_j_47904);
            RefDS(_48current_table_name_17057);
            _25037 = _48db_record_key(_j_47904, _48current_table_name_17057);
            Ref(_j_47904);
            RefDS(_48current_table_name_17057);
            _25038 = _48db_record_data(_j_47904, _48current_table_name_17057);
            Ref(_the_map_47895);
            _32put(_the_map_47895, _25037, _25038, 2, 23);
            _25037 = NOVALUE;
            _25038 = NOVALUE;

            /** 		end for*/
            _0 = _j_47904;
            if (IS_ATOM_INT(_j_47904)) {
                _j_47904 = _j_47904 + 1;
                if ((long)((unsigned long)_j_47904 +(unsigned long) HIGH_BITS) >= 0){
                    _j_47904 = NewDouble((double)_j_47904);
                }
            }
            else {
                _j_47904 = binary_op_a(PLUS, _j_47904, 1);
            }
            DeRef(_0);
            goto L7; // [145] 116
L8: 
            ;
            DeRef(_j_47904);
        }
        DeRef(_name_47884);
        _name_47884 = NOVALUE;
        DeRef(_the_map_47895);
        _the_map_47895 = NOVALUE;

        /** 	end for*/
L4: 
        _i_47882 = _i_47882 + 1;
        goto L1; // [154] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_tables_47878);
    DeRef(_25036);
    _25036 = NOVALUE;
    return;
    ;
}


void _49coverage_db(int _name_47913)
{
    int _0, _1, _2;
    

    /** 	coverage_db_name = name*/
    RefDS(_name_47913);
    DeRef(_49coverage_db_name_47741);
    _49coverage_db_name_47741 = _name_47913;

    /** end procedure*/
    DeRefDS(_name_47913);
    return;
    ;
}


int _49coverage_on()
{
    int _25039 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return file_coverage[current_file_no]*/
    _2 = (int)SEQ_PTR(_49file_coverage_47740);
    _25039 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    return _25039;
    ;
}


void _49new_covered_path(int _name_47925)
{
    int _25045 = NOVALUE;
    int _25043 = NOVALUE;
    int _0, _1, _2;
    

    /** 	covered_files = append( covered_files, name )*/
    RefDS(_name_47925);
    Append(&_49covered_files_47739, _49covered_files_47739, _name_47925);

    /** 	routine_map &= map:new()*/
    _25043 = _32new(690);
    if (IS_SEQUENCE(_49routine_map_47745) && IS_ATOM(_25043)) {
        Ref(_25043);
        Append(&_49routine_map_47745, _49routine_map_47745, _25043);
    }
    else if (IS_ATOM(_49routine_map_47745) && IS_SEQUENCE(_25043)) {
    }
    else {
        Concat((object_ptr)&_49routine_map_47745, _49routine_map_47745, _25043);
    }
    DeRef(_25043);
    _25043 = NOVALUE;

    /** 	line_map    &= map:new()*/
    _25045 = _32new(690);
    if (IS_SEQUENCE(_49line_map_47744) && IS_ATOM(_25045)) {
        Ref(_25045);
        Append(&_49line_map_47744, _49line_map_47744, _25045);
    }
    else if (IS_ATOM(_49line_map_47744) && IS_SEQUENCE(_25045)) {
    }
    else {
        Concat((object_ptr)&_49line_map_47744, _49line_map_47744, _25045);
    }
    DeRef(_25045);
    _25045 = NOVALUE;

    /** end procedure*/
    DeRefDS(_name_47925);
    return;
    ;
}


void _49add_coverage(int _cover_this_47933)
{
    int _path_47934 = NOVALUE;
    int _files_47943 = NOVALUE;
    int _subpath_47971 = NOVALUE;
    int _25080 = NOVALUE;
    int _25079 = NOVALUE;
    int _25078 = NOVALUE;
    int _25077 = NOVALUE;
    int _25076 = NOVALUE;
    int _25075 = NOVALUE;
    int _25074 = NOVALUE;
    int _25073 = NOVALUE;
    int _25072 = NOVALUE;
    int _25071 = NOVALUE;
    int _25070 = NOVALUE;
    int _25069 = NOVALUE;
    int _25067 = NOVALUE;
    int _25066 = NOVALUE;
    int _25065 = NOVALUE;
    int _25064 = NOVALUE;
    int _25063 = NOVALUE;
    int _25062 = NOVALUE;
    int _25061 = NOVALUE;
    int _25060 = NOVALUE;
    int _25058 = NOVALUE;
    int _25057 = NOVALUE;
    int _25056 = NOVALUE;
    int _25055 = NOVALUE;
    int _25054 = NOVALUE;
    int _25053 = NOVALUE;
    int _25052 = NOVALUE;
    int _25051 = NOVALUE;
    int _25048 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence path = canonical_path( cover_this,, CORRECT )*/
    RefDS(_cover_this_47933);
    _0 = _path_47934;
    _path_47934 = _14canonical_path(_cover_this_47933, 0, 2);
    DeRef(_0);

    /** 	if file_type( path ) = FILETYPE_DIRECTORY then*/
    RefDS(_path_47934);
    _25048 = _14file_type(_path_47934);
    if (binary_op_a(NOTEQ, _25048, 2)){
        DeRef(_25048);
        _25048 = NOVALUE;
        goto L1; // [23] 211
    }
    DeRef(_25048);
    _25048 = NOVALUE;

    /** 		sequence files = dir( path  )*/
    RefDS(_path_47934);
    _0 = _files_47943;
    _files_47943 = _14dir(_path_47934);
    DeRef(_0);

    /** 		for i = 1 to length( files ) do*/
    if (IS_SEQUENCE(_files_47943)){
            _25051 = SEQ_PTR(_files_47943)->length;
    }
    else {
        _25051 = 1;
    }
    {
        int _i_47947;
        _i_47947 = 1;
L2: 
        if (_i_47947 > _25051){
            goto L3; // [40] 206
        }

        /** 			if find( 'd', files[i][D_ATTRIBUTES] ) then*/
        _2 = (int)SEQ_PTR(_files_47943);
        _25052 = (int)*(((s1_ptr)_2)->base + _i_47947);
        _2 = (int)SEQ_PTR(_25052);
        _25053 = (int)*(((s1_ptr)_2)->base + 2);
        _25052 = NOVALUE;
        _25054 = find_from(100, _25053, 1);
        _25053 = NOVALUE;
        if (_25054 == 0)
        {
            _25054 = NOVALUE;
            goto L4; // [64] 118
        }
        else{
            _25054 = NOVALUE;
        }

        /** 				if not eu:find(files[i][D_NAME], {".", ".."}) then*/
        _2 = (int)SEQ_PTR(_files_47943);
        _25055 = (int)*(((s1_ptr)_2)->base + _i_47947);
        _2 = (int)SEQ_PTR(_25055);
        _25056 = (int)*(((s1_ptr)_2)->base + 1);
        _25055 = NOVALUE;
        RefDS(_22907);
        RefDS(_22908);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _22908;
        ((int *)_2)[2] = _22907;
        _25057 = MAKE_SEQ(_1);
        _25058 = find_from(_25056, _25057, 1);
        _25056 = NOVALUE;
        DeRefDS(_25057);
        _25057 = NOVALUE;
        if (_25058 != 0)
        goto L5; // [88] 199
        _25058 = NOVALUE;

        /** 					add_coverage( cover_this & SLASH & files[i][D_NAME] )*/
        _2 = (int)SEQ_PTR(_files_47943);
        _25060 = (int)*(((s1_ptr)_2)->base + _i_47947);
        _2 = (int)SEQ_PTR(_25060);
        _25061 = (int)*(((s1_ptr)_2)->base + 1);
        _25060 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25061;
            concat_list[1] = 47;
            concat_list[2] = _cover_this_47933;
            Concat_N((object_ptr)&_25062, concat_list, 3);
        }
        _25061 = NOVALUE;
        _49add_coverage(_25062);
        _25062 = NOVALUE;
        goto L5; // [115] 199
L4: 

        /** 			elsif regex:has_match( eu_file, files[i][D_NAME] ) then*/
        _2 = (int)SEQ_PTR(_files_47943);
        _25063 = (int)*(((s1_ptr)_2)->base + _i_47947);
        _2 = (int)SEQ_PTR(_25063);
        _25064 = (int)*(((s1_ptr)_2)->base + 1);
        _25063 = NOVALUE;
        Ref(_49eu_file_47919);
        Ref(_25064);
        _25065 = _50has_match(_49eu_file_47919, _25064, 1, 0);
        _25064 = NOVALUE;
        if (_25065 == 0) {
            DeRef(_25065);
            _25065 = NOVALUE;
            goto L6; // [139] 196
        }
        else {
            if (!IS_ATOM_INT(_25065) && DBL_PTR(_25065)->dbl == 0.0){
                DeRef(_25065);
                _25065 = NOVALUE;
                goto L6; // [139] 196
            }
            DeRef(_25065);
            _25065 = NOVALUE;
        }
        DeRef(_25065);
        _25065 = NOVALUE;

        /** 				sequence subpath = path & SLASH & files[i][D_NAME]*/
        _2 = (int)SEQ_PTR(_files_47943);
        _25066 = (int)*(((s1_ptr)_2)->base + _i_47947);
        _2 = (int)SEQ_PTR(_25066);
        _25067 = (int)*(((s1_ptr)_2)->base + 1);
        _25066 = NOVALUE;
        {
            int concat_list[3];

            concat_list[0] = _25067;
            concat_list[1] = 47;
            concat_list[2] = _path_47934;
            Concat_N((object_ptr)&_subpath_47971, concat_list, 3);
        }
        _25067 = NOVALUE;

        /** 				if not find( subpath, covered_files ) and not excluded( subpath ) then*/
        _25069 = find_from(_subpath_47971, _49covered_files_47739, 1);
        _25070 = (_25069 == 0);
        _25069 = NOVALUE;
        if (_25070 == 0) {
            goto L7; // [174] 195
        }
        RefDS(_subpath_47971);
        _25072 = _49excluded(_subpath_47971);
        if (IS_ATOM_INT(_25072)) {
            _25073 = (_25072 == 0);
        }
        else {
            _25073 = unary_op(NOT, _25072);
        }
        DeRef(_25072);
        _25072 = NOVALUE;
        if (_25073 == 0) {
            DeRef(_25073);
            _25073 = NOVALUE;
            goto L7; // [186] 195
        }
        else {
            if (!IS_ATOM_INT(_25073) && DBL_PTR(_25073)->dbl == 0.0){
                DeRef(_25073);
                _25073 = NOVALUE;
                goto L7; // [186] 195
            }
            DeRef(_25073);
            _25073 = NOVALUE;
        }
        DeRef(_25073);
        _25073 = NOVALUE;

        /** 					new_covered_path( subpath )*/
        RefDS(_subpath_47971);
        _49new_covered_path(_subpath_47971);
L7: 
L6: 
        DeRef(_subpath_47971);
        _subpath_47971 = NOVALUE;
L5: 

        /** 		end for*/
        _i_47947 = _i_47947 + 1;
        goto L2; // [201] 47
L3: 
        ;
    }
    DeRef(_files_47943);
    _files_47943 = NOVALUE;
    goto L8; // [208] 262
L1: 

    /** 	elsif regex:has_match( eu_file, path ) and*/
    Ref(_49eu_file_47919);
    RefDS(_path_47934);
    _25074 = _50has_match(_49eu_file_47919, _path_47934, 1, 0);
    if (IS_ATOM_INT(_25074)) {
        if (_25074 == 0) {
            DeRef(_25075);
            _25075 = 0;
            goto L9; // [222] 240
        }
    }
    else {
        if (DBL_PTR(_25074)->dbl == 0.0) {
            DeRef(_25075);
            _25075 = 0;
            goto L9; // [222] 240
        }
    }
    _25076 = find_from(_path_47934, _49covered_files_47739, 1);
    _25077 = (_25076 == 0);
    _25076 = NOVALUE;
    DeRef(_25075);
    _25075 = (_25077 != 0);
L9: 
    if (_25075 == 0) {
        goto LA; // [240] 261
    }
    RefDS(_path_47934);
    _25079 = _49excluded(_path_47934);
    if (IS_ATOM_INT(_25079)) {
        _25080 = (_25079 == 0);
    }
    else {
        _25080 = unary_op(NOT, _25079);
    }
    DeRef(_25079);
    _25079 = NOVALUE;
    if (_25080 == 0) {
        DeRef(_25080);
        _25080 = NOVALUE;
        goto LA; // [252] 261
    }
    else {
        if (!IS_ATOM_INT(_25080) && DBL_PTR(_25080)->dbl == 0.0){
            DeRef(_25080);
            _25080 = NOVALUE;
            goto LA; // [252] 261
        }
        DeRef(_25080);
        _25080 = NOVALUE;
    }
    DeRef(_25080);
    _25080 = NOVALUE;

    /** 		new_covered_path( path )*/
    RefDS(_path_47934);
    _49new_covered_path(_path_47934);
LA: 
L8: 

    /** end procedure*/
    DeRefDS(_cover_this_47933);
    DeRef(_path_47934);
    DeRef(_25070);
    _25070 = NOVALUE;
    DeRef(_25074);
    _25074 = NOVALUE;
    DeRef(_25077);
    _25077 = NOVALUE;
    return;
    ;
}


int _49excluded(int _file_47995)
{
    int _25083 = NOVALUE;
    int _25082 = NOVALUE;
    int _25081 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( exclusion_patterns ) do*/
    if (IS_SEQUENCE(_49exclusion_patterns_47743)){
            _25081 = SEQ_PTR(_49exclusion_patterns_47743)->length;
    }
    else {
        _25081 = 1;
    }
    {
        int _i_47997;
        _i_47997 = 1;
L1: 
        if (_i_47997 > _25081){
            goto L2; // [10] 49
        }

        /** 		if regex:has_match( exclusion_patterns[i], file ) then*/
        _2 = (int)SEQ_PTR(_49exclusion_patterns_47743);
        _25082 = (int)*(((s1_ptr)_2)->base + _i_47997);
        Ref(_25082);
        RefDS(_file_47995);
        _25083 = _50has_match(_25082, _file_47995, 1, 0);
        _25082 = NOVALUE;
        if (_25083 == 0) {
            DeRef(_25083);
            _25083 = NOVALUE;
            goto L3; // [32] 42
        }
        else {
            if (!IS_ATOM_INT(_25083) && DBL_PTR(_25083)->dbl == 0.0){
                DeRef(_25083);
                _25083 = NOVALUE;
                goto L3; // [32] 42
            }
            DeRef(_25083);
            _25083 = NOVALUE;
        }
        DeRef(_25083);
        _25083 = NOVALUE;

        /** 			return 1*/
        DeRefDS(_file_47995);
        return 1;
L3: 

        /** 	end for*/
        _i_47997 = _i_47997 + 1;
        goto L1; // [44] 17
L2: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_47995);
    return 0;
    ;
}


void _49coverage_exclude(int _patterns_48004)
{
    int _ex_48009 = NOVALUE;
    int _fx_48016 = NOVALUE;
    int _25101 = NOVALUE;
    int _25100 = NOVALUE;
    int _25099 = NOVALUE;
    int _25098 = NOVALUE;
    int _25092 = NOVALUE;
    int _25091 = NOVALUE;
    int _25089 = NOVALUE;
    int _25087 = NOVALUE;
    int _25085 = NOVALUE;
    int _25084 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length( patterns ) do*/
    if (IS_SEQUENCE(_patterns_48004)){
            _25084 = SEQ_PTR(_patterns_48004)->length;
    }
    else {
        _25084 = 1;
    }
    {
        int _i_48006;
        _i_48006 = 1;
L1: 
        if (_i_48006 > _25084){
            goto L2; // [8] 161
        }

        /** 		regex ex = regex:new( patterns[i] )*/
        _2 = (int)SEQ_PTR(_patterns_48004);
        _25085 = (int)*(((s1_ptr)_2)->base + _i_48006);
        Ref(_25085);
        _0 = _ex_48009;
        _ex_48009 = _50new(_25085, 0);
        DeRef(_0);
        _25085 = NOVALUE;

        /** 		if regex( ex ) then*/
        Ref(_ex_48009);
        _25087 = _50regex(_ex_48009);
        if (_25087 == 0) {
            DeRef(_25087);
            _25087 = NOVALUE;
            goto L3; // [32] 127
        }
        else {
            if (!IS_ATOM_INT(_25087) && DBL_PTR(_25087)->dbl == 0.0){
                DeRef(_25087);
                _25087 = NOVALUE;
                goto L3; // [32] 127
            }
            DeRef(_25087);
            _25087 = NOVALUE;
        }
        DeRef(_25087);
        _25087 = NOVALUE;

        /** 			exclusion_patterns = append( exclusion_patterns, ex )*/
        Ref(_ex_48009);
        Append(&_49exclusion_patterns_47743, _49exclusion_patterns_47743, _ex_48009);

        /** 			integer fx = 1*/
        _fx_48016 = 1;

        /** 			while fx <= length( covered_files ) do*/
L4: 
        if (IS_SEQUENCE(_49covered_files_47739)){
                _25089 = SEQ_PTR(_49covered_files_47739)->length;
        }
        else {
            _25089 = 1;
        }
        if (_fx_48016 > _25089)
        goto L5; // [58] 122

        /** 				if regex:has_match( ex, covered_files[fx] ) then*/
        _2 = (int)SEQ_PTR(_49covered_files_47739);
        _25091 = (int)*(((s1_ptr)_2)->base + _fx_48016);
        Ref(_ex_48009);
        Ref(_25091);
        _25092 = _50has_match(_ex_48009, _25091, 1, 0);
        _25091 = NOVALUE;
        if (_25092 == 0) {
            DeRef(_25092);
            _25092 = NOVALUE;
            goto L6; // [77] 110
        }
        else {
            if (!IS_ATOM_INT(_25092) && DBL_PTR(_25092)->dbl == 0.0){
                DeRef(_25092);
                _25092 = NOVALUE;
                goto L6; // [77] 110
            }
            DeRef(_25092);
            _25092 = NOVALUE;
        }
        DeRef(_25092);
        _25092 = NOVALUE;

        /** 					covered_files = remove( covered_files, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49covered_files_47739);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            int stop = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49covered_files_47739), start, &_49covered_files_47739 );
                }
                else Tail(SEQ_PTR(_49covered_files_47739), stop+1, &_49covered_files_47739);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49covered_files_47739), start, &_49covered_files_47739);
            }
            else {
                assign_slice_seq = &assign_space;
                _49covered_files_47739 = Remove_elements(start, stop, (SEQ_PTR(_49covered_files_47739)->ref == 1));
            }
        }

        /** 					routine_map   = remove( routine_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49routine_map_47745);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            int stop = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49routine_map_47745), start, &_49routine_map_47745 );
                }
                else Tail(SEQ_PTR(_49routine_map_47745), stop+1, &_49routine_map_47745);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49routine_map_47745), start, &_49routine_map_47745);
            }
            else {
                assign_slice_seq = &assign_space;
                _49routine_map_47745 = Remove_elements(start, stop, (SEQ_PTR(_49routine_map_47745)->ref == 1));
            }
        }

        /** 					line_map      = remove( line_map, fx )*/
        {
            s1_ptr assign_space = SEQ_PTR(_49line_map_47744);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            int stop = (IS_ATOM_INT(_fx_48016)) ? _fx_48016 : (long)(DBL_PTR(_fx_48016)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_49line_map_47744), start, &_49line_map_47744 );
                }
                else Tail(SEQ_PTR(_49line_map_47744), stop+1, &_49line_map_47744);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_49line_map_47744), start, &_49line_map_47744);
            }
            else {
                assign_slice_seq = &assign_space;
                _49line_map_47744 = Remove_elements(start, stop, (SEQ_PTR(_49line_map_47744)->ref == 1));
            }
        }
        goto L4; // [107] 53
L6: 

        /** 					fx += 1*/
        _fx_48016 = _fx_48016 + 1;

        /** 			end while*/
        goto L4; // [119] 53
L5: 
        goto L7; // [124] 152
L3: 

        /** 			printf( 2,"%s\n", { GetMsgText( 339, 1, {patterns[i]}) } )*/
        _2 = (int)SEQ_PTR(_patterns_48004);
        _25098 = (int)*(((s1_ptr)_2)->base + _i_48006);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_25098);
        *((int *)(_2+4)) = _25098;
        _25099 = MAKE_SEQ(_1);
        _25098 = NOVALUE;
        _25100 = _44GetMsgText(339, 1, _25099);
        _25099 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _25100;
        _25101 = MAKE_SEQ(_1);
        _25100 = NOVALUE;
        EPrintf(2, _25097, _25101);
        DeRefDS(_25101);
        _25101 = NOVALUE;
L7: 
        DeRef(_ex_48009);
        _ex_48009 = NOVALUE;

        /** 	end for*/
        _i_48006 = _i_48006 + 1;
        goto L1; // [156] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_patterns_48004);
    return;
    ;
}


void _49new_coverage_db()
{
    int _0, _1, _2;
    

    /** 	coverage_erase = 1*/
    _49coverage_erase_47742 = 1;

    /** end procedure*/
    return;
    ;
}


void _49include_line(int _line_number_48039)
{
    int _25102 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_line_number_48039)) {
        _1 = (long)(DBL_PTR(_line_number_48039)->dbl);
        DeRefDS(_line_number_48039);
        _line_number_48039 = _1;
    }

    /** 	if coverage_on() then*/
    _25102 = _49coverage_on();
    if (_25102 == 0) {
        DeRef(_25102);
        _25102 = NOVALUE;
        goto L1; // [8] 34
    }
    else {
        if (!IS_ATOM_INT(_25102) && DBL_PTR(_25102)->dbl == 0.0){
            DeRef(_25102);
            _25102 = NOVALUE;
            goto L1; // [8] 34
        }
        DeRef(_25102);
        _25102 = NOVALUE;
    }
    DeRef(_25102);
    _25102 = NOVALUE;

    /** 		emit_op( COVERAGE_LINE )*/
    _37emit_op(210);

    /** 		emit_addr( gline_number )*/
    _37emit_addr(_12gline_number_11687);

    /** 		included_lines &= line_number*/
    Append(&_49included_lines_47746, _49included_lines_47746, _line_number_48039);
L1: 

    /** end procedure*/
    return;
    ;
}


void _49include_routine()
{
    int _file_no_48055 = NOVALUE;
    int _25109 = NOVALUE;
    int _25108 = NOVALUE;
    int _25107 = NOVALUE;
    int _25105 = NOVALUE;
    int _25104 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if coverage_on() then*/
    _25104 = _49coverage_on();
    if (_25104 == 0) {
        DeRef(_25104);
        _25104 = NOVALUE;
        goto L1; // [6] 71
    }
    else {
        if (!IS_ATOM_INT(_25104) && DBL_PTR(_25104)->dbl == 0.0){
            DeRef(_25104);
            _25104 = NOVALUE;
            goto L1; // [6] 71
        }
        DeRef(_25104);
        _25104 = NOVALUE;
    }
    DeRef(_25104);
    _25104 = NOVALUE;

    /** 		emit_op( COVERAGE_ROUTINE )*/
    _37emit_op(211);

    /** 		emit_addr( CurrentSub )*/
    _37emit_addr(_12CurrentSub_11690);

    /** 		integer file_no = SymTab[CurrentSub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _25105 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_25105);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _file_no_48055 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _file_no_48055 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_file_no_48055)){
        _file_no_48055 = (long)DBL_PTR(_file_no_48055)->dbl;
    }
    _25105 = NOVALUE;

    /** 		map:put( routine_map[file_coverage[file_no]], sym_name( CurrentSub ), 0, map:ADD )*/
    _2 = (int)SEQ_PTR(_49file_coverage_47740);
    _25107 = (int)*(((s1_ptr)_2)->base + _file_no_48055);
    _2 = (int)SEQ_PTR(_49routine_map_47745);
    _25108 = (int)*(((s1_ptr)_2)->base + _25107);
    _25109 = _52sym_name(_12CurrentSub_11690);
    Ref(_25108);
    _32put(_25108, _25109, 0, 2, 23);
    _25108 = NOVALUE;
    _25109 = NOVALUE;
L1: 

    /** end procedure*/
    _25107 = NOVALUE;
    return;
    ;
}


void _49process_lines()
{
    int _sline_48083 = NOVALUE;
    int _file_48087 = NOVALUE;
    int _line_48097 = NOVALUE;
    int _25127 = NOVALUE;
    int _25125 = NOVALUE;
    int _25124 = NOVALUE;
    int _25123 = NOVALUE;
    int _25122 = NOVALUE;
    int _25121 = NOVALUE;
    int _25119 = NOVALUE;
    int _25117 = NOVALUE;
    int _25116 = NOVALUE;
    int _25114 = NOVALUE;
    int _25113 = NOVALUE;
    int _25112 = NOVALUE;
    int _25110 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( included_lines ) then*/
    if (IS_SEQUENCE(_49included_lines_47746)){
            _25110 = SEQ_PTR(_49included_lines_47746)->length;
    }
    else {
        _25110 = 1;
    }
    if (_25110 != 0)
    goto L1; // [8] 17
    _25110 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _25112 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _25112 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _25113 = (int)*(((s1_ptr)_2)->base + _25112);
    _25114 = IS_ATOM(_25113);
    _25113 = NOVALUE;
    if (_25114 == 0)
    {
        _25114 = NOVALUE;
        goto L2; // [31] 45
    }
    else{
        _25114 = NOVALUE;
    }

    /** 		slist = s_expand( slist )*/
    RefDS(_12slist_11773);
    _0 = _60s_expand(_12slist_11773);
    DeRefDS(_12slist_11773);
    _12slist_11773 = _0;
L2: 

    /** 	for i = 1 to length( included_lines ) do*/
    if (IS_SEQUENCE(_49included_lines_47746)){
            _25116 = SEQ_PTR(_49included_lines_47746)->length;
    }
    else {
        _25116 = 1;
    }
    {
        int _i_48081;
        _i_48081 = 1;
L3: 
        if (_i_48081 > _25116){
            goto L4; // [52] 159
        }

        /** 		sequence sline = slist[included_lines[i]]*/
        _2 = (int)SEQ_PTR(_49included_lines_47746);
        _25117 = (int)*(((s1_ptr)_2)->base + _i_48081);
        DeRef(_sline_48083);
        _2 = (int)SEQ_PTR(_12slist_11773);
        _sline_48083 = (int)*(((s1_ptr)_2)->base + _25117);
        Ref(_sline_48083);

        /** 		integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_sline_48083);
        _25119 = (int)*(((s1_ptr)_2)->base + 3);
        _2 = (int)SEQ_PTR(_49file_coverage_47740);
        if (!IS_ATOM_INT(_25119)){
            _file_48087 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25119)->dbl));
        }
        else{
            _file_48087 = (int)*(((s1_ptr)_2)->base + _25119);
        }

        /** 		if file and file <= length( line_map ) and line_map[file] then*/
        if (_file_48087 == 0) {
            _25121 = 0;
            goto L5; // [91] 108
        }
        if (IS_SEQUENCE(_49line_map_47744)){
                _25122 = SEQ_PTR(_49line_map_47744)->length;
        }
        else {
            _25122 = 1;
        }
        _25123 = (_file_48087 <= _25122);
        _25122 = NOVALUE;
        _25121 = (_25123 != 0);
L5: 
        if (_25121 == 0) {
            goto L6; // [108] 148
        }
        _2 = (int)SEQ_PTR(_49line_map_47744);
        _25125 = (int)*(((s1_ptr)_2)->base + _file_48087);
        if (_25125 == 0) {
            _25125 = NOVALUE;
            goto L6; // [119] 148
        }
        else {
            if (!IS_ATOM_INT(_25125) && DBL_PTR(_25125)->dbl == 0.0){
                _25125 = NOVALUE;
                goto L6; // [119] 148
            }
            _25125 = NOVALUE;
        }
        _25125 = NOVALUE;

        /** 			integer line = sline[LINE]*/
        _2 = (int)SEQ_PTR(_sline_48083);
        _line_48097 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_line_48097))
        _line_48097 = (long)DBL_PTR(_line_48097)->dbl;

        /** 			map:put( line_map[file], line, 0, map:ADD )*/
        _2 = (int)SEQ_PTR(_49line_map_47744);
        _25127 = (int)*(((s1_ptr)_2)->base + _file_48087);
        Ref(_25127);
        _32put(_25127, _line_48097, 0, 2, 23);
        _25127 = NOVALUE;
L6: 
        DeRef(_sline_48083);
        _sline_48083 = NOVALUE;

        /** 	end for*/
        _i_48081 = _i_48081 + 1;
        goto L3; // [154] 59
L4: 
        ;
    }

    /** end procedure*/
    _25117 = NOVALUE;
    _25119 = NOVALUE;
    DeRef(_25123);
    _25123 = NOVALUE;
    return;
    ;
}


void _49cover_line(int _gline_number_48103)
{
    int _sline_48113 = NOVALUE;
    int _file_48116 = NOVALUE;
    int _line_48121 = NOVALUE;
    int _25136 = NOVALUE;
    int _25133 = NOVALUE;
    int _25130 = NOVALUE;
    int _25129 = NOVALUE;
    int _25128 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_gline_number_48103)) {
        _1 = (long)(DBL_PTR(_gline_number_48103)->dbl);
        DeRefDS(_gline_number_48103);
        _gline_number_48103 = _1;
    }

    /** 	if atom(slist[$]) then*/
    if (IS_SEQUENCE(_12slist_11773)){
            _25128 = SEQ_PTR(_12slist_11773)->length;
    }
    else {
        _25128 = 1;
    }
    _2 = (int)SEQ_PTR(_12slist_11773);
    _25129 = (int)*(((s1_ptr)_2)->base + _25128);
    _25130 = IS_ATOM(_25129);
    _25129 = NOVALUE;
    if (_25130 == 0)
    {
        _25130 = NOVALUE;
        goto L1; // [17] 31
    }
    else{
        _25130 = NOVALUE;
    }

    /** 		slist = s_expand(slist)*/
    RefDS(_12slist_11773);
    _0 = _60s_expand(_12slist_11773);
    DeRefDS(_12slist_11773);
    _12slist_11773 = _0;
L1: 

    /** 	sequence sline = slist[gline_number]*/
    DeRef(_sline_48113);
    _2 = (int)SEQ_PTR(_12slist_11773);
    _sline_48113 = (int)*(((s1_ptr)_2)->base + _gline_number_48103);
    Ref(_sline_48113);

    /** 	integer file = file_coverage[sline[LOCAL_FILE_NO]]*/
    _2 = (int)SEQ_PTR(_sline_48113);
    _25133 = (int)*(((s1_ptr)_2)->base + 3);
    _2 = (int)SEQ_PTR(_49file_coverage_47740);
    if (!IS_ATOM_INT(_25133)){
        _file_48116 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_25133)->dbl));
    }
    else{
        _file_48116 = (int)*(((s1_ptr)_2)->base + _25133);
    }

    /** 	if file then*/
    if (_file_48116 == 0)
    {
        goto L2; // [57] 86
    }
    else{
    }

    /** 		integer line = sline[LINE]*/
    _2 = (int)SEQ_PTR(_sline_48113);
    _line_48121 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_line_48121))
    _line_48121 = (long)DBL_PTR(_line_48121)->dbl;

    /** 		map:put( line_map[file], line, 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_49line_map_47744);
    _25136 = (int)*(((s1_ptr)_2)->base + _file_48116);
    Ref(_25136);
    _32put(_25136, _line_48121, 1, 2, 23);
    _25136 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_sline_48113);
    _25133 = NOVALUE;
    return;
    ;
}


void _49cover_routine(int _sub_48128)
{
    int _file_no_48129 = NOVALUE;
    int _25141 = NOVALUE;
    int _25140 = NOVALUE;
    int _25139 = NOVALUE;
    int _25137 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_48128)) {
        _1 = (long)(DBL_PTR(_sub_48128)->dbl);
        DeRefDS(_sub_48128);
        _sub_48128 = _1;
    }

    /** 	integer file_no = SymTab[sub][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _25137 = (int)*(((s1_ptr)_2)->base + _sub_48128);
    _2 = (int)SEQ_PTR(_25137);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _file_no_48129 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _file_no_48129 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_file_no_48129)){
        _file_no_48129 = (long)DBL_PTR(_file_no_48129)->dbl;
    }
    _25137 = NOVALUE;

    /** 	map:put( routine_map[file_coverage[file_no]], sym_name( sub ), 1, map:ADD )*/
    _2 = (int)SEQ_PTR(_49file_coverage_47740);
    _25139 = (int)*(((s1_ptr)_2)->base + _file_no_48129);
    _2 = (int)SEQ_PTR(_49routine_map_47745);
    _25140 = (int)*(((s1_ptr)_2)->base + _25139);
    _25141 = _52sym_name(_sub_48128);
    Ref(_25140);
    _32put(_25140, _25141, 1, 2, 23);
    _25140 = NOVALUE;
    _25141 = NOVALUE;

    /** end procedure*/
    _25139 = NOVALUE;
    return;
    ;
}


int _49has_coverage()
{
    int _25142 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return length( covered_files )*/
    if (IS_SEQUENCE(_49covered_files_47739)){
            _25142 = SEQ_PTR(_49covered_files_47739)->length;
    }
    else {
        _25142 = 1;
    }
    return _25142;
    ;
}



// 0x52A1C82E
