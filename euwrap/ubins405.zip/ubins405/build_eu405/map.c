// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _32map(int _obj_p_12699)
{
    int _m__12703 = NOVALUE;
    int _6935 = NOVALUE;
    int _6934 = NOVALUE;
    int _6933 = NOVALUE;
    int _6932 = NOVALUE;
    int _6931 = NOVALUE;
    int _6930 = NOVALUE;
    int _6929 = NOVALUE;
    int _6928 = NOVALUE;
    int _6927 = NOVALUE;
    int _6926 = NOVALUE;
    int _6924 = NOVALUE;
    int _6923 = NOVALUE;
    int _6922 = NOVALUE;
    int _6921 = NOVALUE;
    int _6919 = NOVALUE;
    int _6918 = NOVALUE;
    int _6917 = NOVALUE;
    int _6916 = NOVALUE;
    int _6914 = NOVALUE;
    int _6913 = NOVALUE;
    int _6912 = NOVALUE;
    int _6911 = NOVALUE;
    int _6910 = NOVALUE;
    int _6909 = NOVALUE;
    int _6908 = NOVALUE;
    int _6907 = NOVALUE;
    int _6906 = NOVALUE;
    int _6905 = NOVALUE;
    int _6903 = NOVALUE;
    int _6901 = NOVALUE;
    int _6900 = NOVALUE;
    int _6898 = NOVALUE;
    int _6896 = NOVALUE;
    int _6895 = NOVALUE;
    int _6893 = NOVALUE;
    int _6892 = NOVALUE;
    int _6890 = NOVALUE;
    int _6888 = NOVALUE;
    int _6886 = NOVALUE;
    int _6883 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not eumem:valid(obj_p, "") then return 0 end if*/
    Ref(_obj_p_12699);
    RefDS(_5);
    _6883 = _33valid(_obj_p_12699, _5);
    if (IS_ATOM_INT(_6883)) {
        if (_6883 != 0){
            DeRef(_6883);
            _6883 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    else {
        if (DBL_PTR(_6883)->dbl != 0.0){
            DeRef(_6883);
            _6883 = NOVALUE;
            goto L1; // [8] 16
        }
    }
    DeRef(_6883);
    _6883 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L1: 

    /** 	object m_*/

    /** 	m_ = eumem:ram_space[obj_p]*/
    DeRef(_m__12703);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_obj_p_12699)){
        _m__12703 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_obj_p_12699)->dbl));
    }
    else{
        _m__12703 = (int)*(((s1_ptr)_2)->base + _obj_p_12699);
    }
    Ref(_m__12703);

    /** 	if not sequence(m_) then return 0 end if*/
    _6886 = IS_SEQUENCE(_m__12703);
    if (_6886 != 0)
    goto L2; // [31] 39
    _6886 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L2: 

    /** 	if length(m_) < 6 then return 0 end if*/
    if (IS_SEQUENCE(_m__12703)){
            _6888 = SEQ_PTR(_m__12703)->length;
    }
    else {
        _6888 = 1;
    }
    if (_6888 >= 6)
    goto L3; // [44] 53
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L3: 

    /** 	if length(m_) > 7 then return 0 end if*/
    if (IS_SEQUENCE(_m__12703)){
            _6890 = SEQ_PTR(_m__12703)->length;
    }
    else {
        _6890 = 1;
    }
    if (_6890 <= 7)
    goto L4; // [58] 67
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L4: 

    /** 	if not equal(m_[TYPE_TAG], type_is_map) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6892 = (int)*(((s1_ptr)_2)->base + 1);
    if (_6892 == _32type_is_map_12679)
    _6893 = 1;
    else if (IS_ATOM_INT(_6892) && IS_ATOM_INT(_32type_is_map_12679))
    _6893 = 0;
    else
    _6893 = (compare(_6892, _32type_is_map_12679) == 0);
    _6892 = NOVALUE;
    if (_6893 != 0)
    goto L5; // [77] 85
    _6893 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L5: 

    /** 	if not integer(m_[ELEMENT_COUNT]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6895 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_6895))
    _6896 = 1;
    else if (IS_ATOM_DBL(_6895))
    _6896 = IS_ATOM_INT(DoubleToInt(_6895));
    else
    _6896 = 0;
    _6895 = NOVALUE;
    if (_6896 != 0)
    goto L6; // [94] 102
    _6896 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L6: 

    /** 	if m_[ELEMENT_COUNT] < 0 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6898 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(GREATEREQ, _6898, 0)){
        _6898 = NOVALUE;
        goto L7; // [108] 117
    }
    _6898 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L7: 

    /** 	if not integer(m_[IN_USE]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6900 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_6900))
    _6901 = 1;
    else if (IS_ATOM_DBL(_6900))
    _6901 = IS_ATOM_INT(DoubleToInt(_6900));
    else
    _6901 = 0;
    _6900 = NOVALUE;
    if (_6901 != 0)
    goto L8; // [126] 134
    _6901 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L8: 

    /** 	if m_[IN_USE] < 0		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6903 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(GREATEREQ, _6903, 0)){
        _6903 = NOVALUE;
        goto L9; // [140] 149
    }
    _6903 = NOVALUE;
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
L9: 

    /** 	if equal(m_[MAP_TYPE],SMALLMAP) then*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6905 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6905 == 115)
    _6906 = 1;
    else if (IS_ATOM_INT(_6905) && IS_ATOM_INT(115))
    _6906 = 0;
    else
    _6906 = (compare(_6905, 115) == 0);
    _6905 = NOVALUE;
    if (_6906 == 0)
    {
        _6906 = NOVALUE;
        goto LA; // [159] 284
    }
    else{
        _6906 = NOVALUE;
    }

    /** 		if atom(m_[KEY_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6907 = (int)*(((s1_ptr)_2)->base + 5);
    _6908 = IS_ATOM(_6907);
    _6907 = NOVALUE;
    if (_6908 == 0)
    {
        _6908 = NOVALUE;
        goto LB; // [171] 179
    }
    else{
        _6908 = NOVALUE;
    }
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
LB: 

    /** 		if atom(m_[VALUE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6909 = (int)*(((s1_ptr)_2)->base + 6);
    _6910 = IS_ATOM(_6909);
    _6909 = NOVALUE;
    if (_6910 == 0)
    {
        _6910 = NOVALUE;
        goto LC; // [188] 196
    }
    else{
        _6910 = NOVALUE;
    }
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
LC: 

    /** 		if atom(m_[FREE_LIST]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6911 = (int)*(((s1_ptr)_2)->base + 7);
    _6912 = IS_ATOM(_6911);
    _6911 = NOVALUE;
    if (_6912 == 0)
    {
        _6912 = NOVALUE;
        goto LD; // [205] 213
    }
    else{
        _6912 = NOVALUE;
    }
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    return 0;
LD: 

    /** 		if length(m_[KEY_LIST]) = 0  then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6913 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6913)){
            _6914 = SEQ_PTR(_6913)->length;
    }
    else {
        _6914 = 1;
    }
    _6913 = NOVALUE;
    if (_6914 != 0)
    goto LE; // [222] 231
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    return 0;
LE: 

    /** 		if length(m_[KEY_LIST]) != length(m_[VALUE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6916 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6916)){
            _6917 = SEQ_PTR(_6916)->length;
    }
    else {
        _6917 = 1;
    }
    _6916 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12703);
    _6918 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6918)){
            _6919 = SEQ_PTR(_6918)->length;
    }
    else {
        _6919 = 1;
    }
    _6918 = NOVALUE;
    if (_6917 == _6919)
    goto LF; // [247] 256
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    return 0;
LF: 

    /** 		if length(m_[KEY_LIST]) != length(m_[FREE_LIST]) then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6921 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6921)){
            _6922 = SEQ_PTR(_6921)->length;
    }
    else {
        _6922 = 1;
    }
    _6921 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12703);
    _6923 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_6923)){
            _6924 = SEQ_PTR(_6923)->length;
    }
    else {
        _6924 = 1;
    }
    _6923 = NOVALUE;
    if (_6922 == _6924)
    goto L10; // [272] 366
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    return 0;
    goto L10; // [281] 366
LA: 

    /** 	elsif  equal(m_[MAP_TYPE],LARGEMAP) then*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6926 = (int)*(((s1_ptr)_2)->base + 4);
    if (_6926 == 76)
    _6927 = 1;
    else if (IS_ATOM_INT(_6926) && IS_ATOM_INT(76))
    _6927 = 0;
    else
    _6927 = (compare(_6926, 76) == 0);
    _6926 = NOVALUE;
    if (_6927 == 0)
    {
        _6927 = NOVALUE;
        goto L11; // [294] 359
    }
    else{
        _6927 = NOVALUE;
    }

    /** 		if atom(m_[KEY_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6928 = (int)*(((s1_ptr)_2)->base + 5);
    _6929 = IS_ATOM(_6928);
    _6928 = NOVALUE;
    if (_6929 == 0)
    {
        _6929 = NOVALUE;
        goto L12; // [306] 314
    }
    else{
        _6929 = NOVALUE;
    }
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    return 0;
L12: 

    /** 		if atom(m_[VALUE_BUCKETS]) 		then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6930 = (int)*(((s1_ptr)_2)->base + 6);
    _6931 = IS_ATOM(_6930);
    _6930 = NOVALUE;
    if (_6931 == 0)
    {
        _6931 = NOVALUE;
        goto L13; // [323] 331
    }
    else{
        _6931 = NOVALUE;
    }
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    return 0;
L13: 

    /** 		if length(m_[KEY_BUCKETS]) != length(m_[VALUE_BUCKETS])	then return 0 end if*/
    _2 = (int)SEQ_PTR(_m__12703);
    _6932 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_6932)){
            _6933 = SEQ_PTR(_6932)->length;
    }
    else {
        _6933 = 1;
    }
    _6932 = NOVALUE;
    _2 = (int)SEQ_PTR(_m__12703);
    _6934 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_6934)){
            _6935 = SEQ_PTR(_6934)->length;
    }
    else {
        _6935 = 1;
    }
    _6934 = NOVALUE;
    if (_6933 == _6935)
    goto L10; // [347] 366
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    _6932 = NOVALUE;
    _6934 = NOVALUE;
    return 0;
    goto L10; // [356] 366
L11: 

    /** 		return 0*/
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    _6932 = NOVALUE;
    _6934 = NOVALUE;
    return 0;
L10: 

    /** 	return 1*/
    DeRef(_obj_p_12699);
    DeRef(_m__12703);
    _6913 = NOVALUE;
    _6916 = NOVALUE;
    _6918 = NOVALUE;
    _6921 = NOVALUE;
    _6923 = NOVALUE;
    _6932 = NOVALUE;
    _6934 = NOVALUE;
    return 1;
    ;
}


void _32rehash(int _the_map_p_12798, int _requested_bucket_size_p_12799)
{
    int _size__12800 = NOVALUE;
    int _index_2__12801 = NOVALUE;
    int _old_key_buckets__12802 = NOVALUE;
    int _old_val_buckets__12803 = NOVALUE;
    int _new_key_buckets__12804 = NOVALUE;
    int _new_val_buckets__12805 = NOVALUE;
    int _key__12806 = NOVALUE;
    int _value__12807 = NOVALUE;
    int _pos_12808 = NOVALUE;
    int _new_keys_12809 = NOVALUE;
    int _in_use_12810 = NOVALUE;
    int _elem_count_12811 = NOVALUE;
    int _calc_hash_1__tmp_at227_12854 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_227_12853 = NOVALUE;
    int _ret__inlined_calc_hash_at_227_12852 = NOVALUE;
    int _7002 = NOVALUE;
    int _7001 = NOVALUE;
    int _7000 = NOVALUE;
    int _6999 = NOVALUE;
    int _6998 = NOVALUE;
    int _6997 = NOVALUE;
    int _6996 = NOVALUE;
    int _6995 = NOVALUE;
    int _6994 = NOVALUE;
    int _6992 = NOVALUE;
    int _6991 = NOVALUE;
    int _6990 = NOVALUE;
    int _6987 = NOVALUE;
    int _6986 = NOVALUE;
    int _6984 = NOVALUE;
    int _6983 = NOVALUE;
    int _6982 = NOVALUE;
    int _6981 = NOVALUE;
    int _6979 = NOVALUE;
    int _6977 = NOVALUE;
    int _6975 = NOVALUE;
    int _6972 = NOVALUE;
    int _6970 = NOVALUE;
    int _6969 = NOVALUE;
    int _6968 = NOVALUE;
    int _6967 = NOVALUE;
    int _6965 = NOVALUE;
    int _6963 = NOVALUE;
    int _6961 = NOVALUE;
    int _6960 = NOVALUE;
    int _6958 = NOVALUE;
    int _6956 = NOVALUE;
    int _6953 = NOVALUE;
    int _6951 = NOVALUE;
    int _6950 = NOVALUE;
    int _6949 = NOVALUE;
    int _6948 = NOVALUE;
    int _6947 = NOVALUE;
    int _6944 = NOVALUE;
    int _6943 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = SMALLMAP then*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _6943 = (int)*(((s1_ptr)_2)->base + _the_map_p_12798);
    _2 = (int)SEQ_PTR(_6943);
    _6944 = (int)*(((s1_ptr)_2)->base + 4);
    _6943 = NOVALUE;
    if (binary_op_a(NOTEQ, _6944, 115)){
        _6944 = NOVALUE;
        goto L1; // [17] 27
    }
    _6944 = NOVALUE;

    /** 		return -- small maps are not hashed.*/
    DeRef(_old_key_buckets__12802);
    DeRef(_old_val_buckets__12803);
    DeRef(_new_key_buckets__12804);
    DeRef(_new_val_buckets__12805);
    DeRef(_key__12806);
    DeRef(_value__12807);
    DeRef(_new_keys_12809);
    return;
L1: 

    /** 	if requested_bucket_size_p <= 0 then*/
    if (_requested_bucket_size_p_12799 > 0)
    goto L2; // [29] 62

    /** 		size_ = floor(length(eumem:ram_space[the_map_p][KEY_BUCKETS]) * 3.5) + 1*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _6947 = (int)*(((s1_ptr)_2)->base + _the_map_p_12798);
    _2 = (int)SEQ_PTR(_6947);
    _6948 = (int)*(((s1_ptr)_2)->base + 5);
    _6947 = NOVALUE;
    if (IS_SEQUENCE(_6948)){
            _6949 = SEQ_PTR(_6948)->length;
    }
    else {
        _6949 = 1;
    }
    _6948 = NOVALUE;
    _6950 = NewDouble((double)_6949 * DBL_PTR(_6538)->dbl);
    _6949 = NOVALUE;
    _6951 = unary_op(FLOOR, _6950);
    DeRefDS(_6950);
    _6950 = NOVALUE;
    if (IS_ATOM_INT(_6951)) {
        _size__12800 = _6951 + 1;
    }
    else
    { // coercing _size__12800 to an integer 1
        _size__12800 = 1+(long)(DBL_PTR(_6951)->dbl);
        if( !IS_ATOM_INT(_size__12800) ){
            _size__12800 = (object)DBL_PTR(_size__12800)->dbl;
        }
    }
    DeRef(_6951);
    _6951 = NOVALUE;
    goto L3; // [59] 68
L2: 

    /** 		size_ = requested_bucket_size_p*/
    _size__12800 = _requested_bucket_size_p_12799;
L3: 

    /** 	size_ = primes:next_prime(size_, -size_, 2)	-- Allow up to 2 seconds to calc next prime.*/
    if ((unsigned long)_size__12800 == 0xC0000000)
    _6953 = (int)NewDouble((double)-0xC0000000);
    else
    _6953 = - _size__12800;
    _size__12800 = _34next_prime(_size__12800, _6953, 2);
    _6953 = NOVALUE;
    if (!IS_ATOM_INT(_size__12800)) {
        _1 = (long)(DBL_PTR(_size__12800)->dbl);
        DeRefDS(_size__12800);
        _size__12800 = _1;
    }

    /** 	if size_ < 0 then*/
    if (_size__12800 >= 0)
    goto L4; // [85] 95

    /** 		return  -- don't do anything. New size would take too long.*/
    DeRef(_old_key_buckets__12802);
    DeRef(_old_val_buckets__12803);
    DeRef(_new_key_buckets__12804);
    DeRef(_new_val_buckets__12805);
    DeRef(_key__12806);
    DeRef(_value__12807);
    DeRef(_new_keys_12809);
    _6948 = NOVALUE;
    return;
L4: 

    /** 	old_key_buckets_ = eumem:ram_space[the_map_p][KEY_BUCKETS]*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _6956 = (int)*(((s1_ptr)_2)->base + _the_map_p_12798);
    DeRef(_old_key_buckets__12802);
    _2 = (int)SEQ_PTR(_6956);
    _old_key_buckets__12802 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_old_key_buckets__12802);
    _6956 = NOVALUE;

    /** 	old_val_buckets_ = eumem:ram_space[the_map_p][VALUE_BUCKETS]*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _6958 = (int)*(((s1_ptr)_2)->base + _the_map_p_12798);
    DeRef(_old_val_buckets__12803);
    _2 = (int)SEQ_PTR(_6958);
    _old_val_buckets__12803 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_old_val_buckets__12803);
    _6958 = NOVALUE;

    /** 	new_key_buckets_ = repeat(repeat(1, threshold_size + 1), size_)*/
    _6960 = 24;
    _6961 = Repeat(1, 24);
    _6960 = NOVALUE;
    DeRef(_new_key_buckets__12804);
    _new_key_buckets__12804 = Repeat(_6961, _size__12800);
    DeRefDS(_6961);
    _6961 = NOVALUE;

    /** 	new_val_buckets_ = repeat(repeat(0, threshold_size), size_)*/
    _6963 = Repeat(0, 23);
    DeRef(_new_val_buckets__12805);
    _new_val_buckets__12805 = Repeat(_6963, _size__12800);
    DeRefDS(_6963);
    _6963 = NOVALUE;

    /** 	elem_count = eumem:ram_space[the_map_p][ELEMENT_COUNT]*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _6965 = (int)*(((s1_ptr)_2)->base + _the_map_p_12798);
    _2 = (int)SEQ_PTR(_6965);
    _elem_count_12811 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_elem_count_12811)){
        _elem_count_12811 = (long)DBL_PTR(_elem_count_12811)->dbl;
    }
    _6965 = NOVALUE;

    /** 	in_use = 0*/
    _in_use_12810 = 0;

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12798);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	for index = 1 to length(old_key_buckets_) do*/
    if (IS_SEQUENCE(_old_key_buckets__12802)){
            _6967 = SEQ_PTR(_old_key_buckets__12802)->length;
    }
    else {
        _6967 = 1;
    }
    {
        int _index_12841;
        _index_12841 = 1;
L5: 
        if (_index_12841 > _6967){
            goto L6; // [183] 373
        }

        /** 		for entry_idx = 1 to length(old_key_buckets_[index]) do*/
        _2 = (int)SEQ_PTR(_old_key_buckets__12802);
        _6968 = (int)*(((s1_ptr)_2)->base + _index_12841);
        if (IS_SEQUENCE(_6968)){
                _6969 = SEQ_PTR(_6968)->length;
        }
        else {
            _6969 = 1;
        }
        _6968 = NOVALUE;
        {
            int _entry_idx_12844;
            _entry_idx_12844 = 1;
L7: 
            if (_entry_idx_12844 > _6969){
                goto L8; // [199] 366
            }

            /** 			key_ = old_key_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_key_buckets__12802);
            _6970 = (int)*(((s1_ptr)_2)->base + _index_12841);
            DeRef(_key__12806);
            _2 = (int)SEQ_PTR(_6970);
            _key__12806 = (int)*(((s1_ptr)_2)->base + _entry_idx_12844);
            Ref(_key__12806);
            _6970 = NOVALUE;

            /** 			value_ = old_val_buckets_[index][entry_idx]*/
            _2 = (int)SEQ_PTR(_old_val_buckets__12803);
            _6972 = (int)*(((s1_ptr)_2)->base + _index_12841);
            DeRef(_value__12807);
            _2 = (int)SEQ_PTR(_6972);
            _value__12807 = (int)*(((s1_ptr)_2)->base + _entry_idx_12844);
            Ref(_value__12807);
            _6972 = NOVALUE;

            /** 			index_2_ = calc_hash(key_, size_)*/

            /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
            DeRef(_ret__inlined_calc_hash_at_227_12852);
            _ret__inlined_calc_hash_at_227_12852 = calc_hash(_key__12806, -6);
            if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_227_12852)) {
                _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_227_12852)->dbl);
                DeRefDS(_ret__inlined_calc_hash_at_227_12852);
                _ret__inlined_calc_hash_at_227_12852 = _1;
            }

            /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
            _calc_hash_1__tmp_at227_12854 = (_ret__inlined_calc_hash_at_227_12852 % _size__12800);
            _index_2__12801 = _calc_hash_1__tmp_at227_12854 + 1;
            DeRef(_ret__inlined_calc_hash_at_227_12852);
            _ret__inlined_calc_hash_at_227_12852 = NOVALUE;
            if (!IS_ATOM_INT(_index_2__12801)) {
                _1 = (long)(DBL_PTR(_index_2__12801)->dbl);
                DeRefDS(_index_2__12801);
                _index_2__12801 = _1;
            }

            /** 			new_keys = new_key_buckets_[index_2_]*/
            DeRef(_new_keys_12809);
            _2 = (int)SEQ_PTR(_new_key_buckets__12804);
            _new_keys_12809 = (int)*(((s1_ptr)_2)->base + _index_2__12801);
            RefDS(_new_keys_12809);

            /** 			pos = new_keys[$]*/
            if (IS_SEQUENCE(_new_keys_12809)){
                    _6975 = SEQ_PTR(_new_keys_12809)->length;
            }
            else {
                _6975 = 1;
            }
            _2 = (int)SEQ_PTR(_new_keys_12809);
            _pos_12808 = (int)*(((s1_ptr)_2)->base + _6975);
            if (!IS_ATOM_INT(_pos_12808))
            _pos_12808 = (long)DBL_PTR(_pos_12808)->dbl;

            /** 			if length(new_keys) = pos then*/
            if (IS_SEQUENCE(_new_keys_12809)){
                    _6977 = SEQ_PTR(_new_keys_12809)->length;
            }
            else {
                _6977 = 1;
            }
            if (_6977 != _pos_12808)
            goto L9; // [273] 310

            /** 				new_keys &= repeat(pos, threshold_size)*/
            _6979 = Repeat(_pos_12808, 23);
            Concat((object_ptr)&_new_keys_12809, _new_keys_12809, _6979);
            DeRefDS(_6979);
            _6979 = NOVALUE;

            /** 				new_val_buckets_[index_2_] &= repeat(0, threshold_size)*/
            _6981 = Repeat(0, 23);
            _2 = (int)SEQ_PTR(_new_val_buckets__12805);
            _6982 = (int)*(((s1_ptr)_2)->base + _index_2__12801);
            if (IS_SEQUENCE(_6982) && IS_ATOM(_6981)) {
            }
            else if (IS_ATOM(_6982) && IS_SEQUENCE(_6981)) {
                Ref(_6982);
                Prepend(&_6983, _6981, _6982);
            }
            else {
                Concat((object_ptr)&_6983, _6982, _6981);
                _6982 = NOVALUE;
            }
            _6982 = NOVALUE;
            DeRefDS(_6981);
            _6981 = NOVALUE;
            _2 = (int)SEQ_PTR(_new_val_buckets__12805);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__12805 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__12801);
            _1 = *(int *)_2;
            *(int *)_2 = _6983;
            if( _1 != _6983 ){
                DeRef(_1);
            }
            _6983 = NOVALUE;
L9: 

            /** 			new_keys[pos] = key_*/
            Ref(_key__12806);
            _2 = (int)SEQ_PTR(_new_keys_12809);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_12809 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_12808);
            _1 = *(int *)_2;
            *(int *)_2 = _key__12806;
            DeRef(_1);

            /** 			new_val_buckets_[index_2_][pos] = value_*/
            _2 = (int)SEQ_PTR(_new_val_buckets__12805);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_val_buckets__12805 = MAKE_SEQ(_2);
            }
            _3 = (int)(_index_2__12801 + ((s1_ptr)_2)->base);
            Ref(_value__12807);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _pos_12808);
            _1 = *(int *)_2;
            *(int *)_2 = _value__12807;
            DeRef(_1);
            _6984 = NOVALUE;

            /** 			new_keys[$] = pos + 1*/
            if (IS_SEQUENCE(_new_keys_12809)){
                    _6986 = SEQ_PTR(_new_keys_12809)->length;
            }
            else {
                _6986 = 1;
            }
            _6987 = _pos_12808 + 1;
            if (_6987 > MAXINT){
                _6987 = NewDouble((double)_6987);
            }
            _2 = (int)SEQ_PTR(_new_keys_12809);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_keys_12809 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _6986);
            _1 = *(int *)_2;
            *(int *)_2 = _6987;
            if( _1 != _6987 ){
                DeRef(_1);
            }
            _6987 = NOVALUE;

            /** 			new_key_buckets_[index_2_] = new_keys*/
            RefDS(_new_keys_12809);
            _2 = (int)SEQ_PTR(_new_key_buckets__12804);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _new_key_buckets__12804 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _index_2__12801);
            _1 = *(int *)_2;
            *(int *)_2 = _new_keys_12809;
            DeRefDS(_1);

            /** 			if pos = 1 then*/
            if (_pos_12808 != 1)
            goto LA; // [348] 359

            /** 				in_use += 1*/
            _in_use_12810 = _in_use_12810 + 1;
LA: 

            /** 		end for*/
            _entry_idx_12844 = _entry_idx_12844 + 1;
            goto L7; // [361] 206
L8: 
            ;
        }

        /** 	end for*/
        _index_12841 = _index_12841 + 1;
        goto L5; // [368] 190
L6: 
        ;
    }

    /** 	for index = 1 to length(new_key_buckets_) do*/
    if (IS_SEQUENCE(_new_key_buckets__12804)){
            _6990 = SEQ_PTR(_new_key_buckets__12804)->length;
    }
    else {
        _6990 = 1;
    }
    {
        int _index_12874;
        _index_12874 = 1;
LB: 
        if (_index_12874 > _6990){
            goto LC; // [378] 451
        }

        /** 		pos = new_key_buckets_[index][$]*/
        _2 = (int)SEQ_PTR(_new_key_buckets__12804);
        _6991 = (int)*(((s1_ptr)_2)->base + _index_12874);
        if (IS_SEQUENCE(_6991)){
                _6992 = SEQ_PTR(_6991)->length;
        }
        else {
            _6992 = 1;
        }
        _2 = (int)SEQ_PTR(_6991);
        _pos_12808 = (int)*(((s1_ptr)_2)->base + _6992);
        if (!IS_ATOM_INT(_pos_12808)){
            _pos_12808 = (long)DBL_PTR(_pos_12808)->dbl;
        }
        _6991 = NOVALUE;

        /** 		new_key_buckets_[index] = remove(new_key_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_key_buckets__12804);
        _6994 = (int)*(((s1_ptr)_2)->base + _index_12874);
        _2 = (int)SEQ_PTR(_new_key_buckets__12804);
        _6995 = (int)*(((s1_ptr)_2)->base + _index_12874);
        if (IS_SEQUENCE(_6995)){
                _6996 = SEQ_PTR(_6995)->length;
        }
        else {
            _6996 = 1;
        }
        _6995 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6994);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_12808)) ? _pos_12808 : (long)(DBL_PTR(_pos_12808)->dbl);
            int stop = (IS_ATOM_INT(_6996)) ? _6996 : (long)(DBL_PTR(_6996)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6994);
                DeRef(_6997);
                _6997 = _6994;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6994), start, &_6997 );
                }
                else Tail(SEQ_PTR(_6994), stop+1, &_6997);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6994), start, &_6997);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_6997);
                _6997 = _1;
            }
        }
        _6994 = NOVALUE;
        _6996 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_key_buckets__12804);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_key_buckets__12804 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_12874);
        _1 = *(int *)_2;
        *(int *)_2 = _6997;
        if( _1 != _6997 ){
            DeRefDS(_1);
        }
        _6997 = NOVALUE;

        /** 		new_val_buckets_[index] = remove(new_val_buckets_[index], pos, */
        _2 = (int)SEQ_PTR(_new_val_buckets__12805);
        _6998 = (int)*(((s1_ptr)_2)->base + _index_12874);
        _2 = (int)SEQ_PTR(_new_val_buckets__12805);
        _6999 = (int)*(((s1_ptr)_2)->base + _index_12874);
        if (IS_SEQUENCE(_6999)){
                _7000 = SEQ_PTR(_6999)->length;
        }
        else {
            _7000 = 1;
        }
        _6999 = NOVALUE;
        {
            s1_ptr assign_space = SEQ_PTR(_6998);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_pos_12808)) ? _pos_12808 : (long)(DBL_PTR(_pos_12808)->dbl);
            int stop = (IS_ATOM_INT(_7000)) ? _7000 : (long)(DBL_PTR(_7000)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
                RefDS(_6998);
                DeRef(_7001);
                _7001 = _6998;
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_6998), start, &_7001 );
                }
                else Tail(SEQ_PTR(_6998), stop+1, &_7001);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_6998), start, &_7001);
            }
            else {
                assign_slice_seq = &assign_space;
                _1 = Remove_elements(start, stop, 0);
                DeRef(_7001);
                _7001 = _1;
            }
        }
        _6998 = NOVALUE;
        _7000 = NOVALUE;
        _2 = (int)SEQ_PTR(_new_val_buckets__12805);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _new_val_buckets__12805 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index_12874);
        _1 = *(int *)_2;
        *(int *)_2 = _7001;
        if( _1 != _7001 ){
            DeRef(_1);
        }
        _7001 = NOVALUE;

        /** 	end for*/
        _index_12874 = _index_12874 + 1;
        goto LB; // [446] 385
LC: 
        ;
    }

    /** 	eumem:ram_space[the_map_p] = { */
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12679);
    *((int *)(_2+4)) = _32type_is_map_12679;
    *((int *)(_2+8)) = _elem_count_12811;
    *((int *)(_2+12)) = _in_use_12810;
    *((int *)(_2+16)) = 76;
    RefDS(_new_key_buckets__12804);
    *((int *)(_2+20)) = _new_key_buckets__12804;
    RefDS(_new_val_buckets__12805);
    *((int *)(_2+24)) = _new_val_buckets__12805;
    _7002 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_12798);
    _1 = *(int *)_2;
    *(int *)_2 = _7002;
    if( _1 != _7002 ){
        DeRef(_1);
    }
    _7002 = NOVALUE;

    /** end procedure*/
    DeRef(_old_key_buckets__12802);
    DeRef(_old_val_buckets__12803);
    DeRefDS(_new_key_buckets__12804);
    DeRefDS(_new_val_buckets__12805);
    DeRef(_key__12806);
    DeRef(_value__12807);
    DeRef(_new_keys_12809);
    _6948 = NOVALUE;
    _6968 = NOVALUE;
    _6995 = NOVALUE;
    _6999 = NOVALUE;
    return;
    ;
}


int _32new(int _initial_size_p_12890)
{
    int _buckets__12892 = NOVALUE;
    int _new_map__12893 = NOVALUE;
    int _temp_map__12894 = NOVALUE;
    int _7015 = NOVALUE;
    int _7014 = NOVALUE;
    int _7013 = NOVALUE;
    int _7011 = NOVALUE;
    int _7010 = NOVALUE;
    int _7007 = NOVALUE;
    int _7006 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if initial_size_p < 3 then*/
    if (_initial_size_p_12890 >= 3)
    goto L1; // [5] 15

    /** 		initial_size_p = 3*/
    _initial_size_p_12890 = 3;
L1: 

    /** 	if initial_size_p > threshold_size then*/
    if (_initial_size_p_12890 <= 23)
    goto L2; // [19] 75

    /** 		buckets_ = floor((initial_size_p + threshold_size - 1) / threshold_size)*/
    _7006 = _initial_size_p_12890 + 23;
    if ((long)((unsigned long)_7006 + (unsigned long)HIGH_BITS) >= 0) 
    _7006 = NewDouble((double)_7006);
    if (IS_ATOM_INT(_7006)) {
        _7007 = _7006 - 1;
        if ((long)((unsigned long)_7007 +(unsigned long) HIGH_BITS) >= 0){
            _7007 = NewDouble((double)_7007);
        }
    }
    else {
        _7007 = NewDouble(DBL_PTR(_7006)->dbl - (double)1);
    }
    DeRef(_7006);
    _7006 = NOVALUE;
    if (IS_ATOM_INT(_7007)) {
        if (23 > 0 && _7007 >= 0) {
            _buckets__12892 = _7007 / 23;
        }
        else {
            temp_dbl = floor((double)_7007 / (double)23);
            _buckets__12892 = (long)temp_dbl;
        }
    }
    else {
        _2 = binary_op(DIVIDE, _7007, 23);
        _buckets__12892 = unary_op(FLOOR, _2);
        DeRef(_2);
    }
    DeRef(_7007);
    _7007 = NOVALUE;
    if (!IS_ATOM_INT(_buckets__12892)) {
        _1 = (long)(DBL_PTR(_buckets__12892)->dbl);
        DeRefDS(_buckets__12892);
        _buckets__12892 = _1;
    }

    /** 		buckets_ = primes:next_prime(buckets_)*/
    _buckets__12892 = _34next_prime(_buckets__12892, -1, 1);
    if (!IS_ATOM_INT(_buckets__12892)) {
        _1 = (long)(DBL_PTR(_buckets__12892)->dbl);
        DeRefDS(_buckets__12892);
        _buckets__12892 = _1;
    }

    /** 		new_map_ = { type_is_map, 0, 0, LARGEMAP, repeat({}, buckets_), repeat({}, buckets_) }*/
    _7010 = Repeat(_5, _buckets__12892);
    _7011 = Repeat(_5, _buckets__12892);
    _0 = _new_map__12893;
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12679);
    *((int *)(_2+4)) = _32type_is_map_12679;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 76;
    *((int *)(_2+20)) = _7010;
    *((int *)(_2+24)) = _7011;
    _new_map__12893 = MAKE_SEQ(_1);
    DeRef(_0);
    _7011 = NOVALUE;
    _7010 = NOVALUE;
    goto L3; // [72] 100
L2: 

    /** 		new_map_ = {*/
    _7013 = Repeat(_32init_small_map_key_12694, _initial_size_p_12890);
    _7014 = Repeat(0, _initial_size_p_12890);
    _7015 = Repeat(0, _initial_size_p_12890);
    _0 = _new_map__12893;
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12679);
    *((int *)(_2+4)) = _32type_is_map_12679;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7013;
    *((int *)(_2+24)) = _7014;
    *((int *)(_2+28)) = _7015;
    _new_map__12893 = MAKE_SEQ(_1);
    DeRef(_0);
    _7015 = NOVALUE;
    _7014 = NOVALUE;
    _7013 = NOVALUE;
L3: 

    /** 	temp_map_ = eumem:malloc()*/
    _0 = _temp_map__12894;
    _temp_map__12894 = _33malloc(1, 1);
    DeRef(_0);

    /** 	eumem:ram_space[temp_map_] = new_map_*/
    RefDS(_new_map__12893);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_temp_map__12894))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_temp_map__12894)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _temp_map__12894);
    _1 = *(int *)_2;
    *(int *)_2 = _new_map__12893;
    DeRef(_1);

    /** 	return temp_map_*/
    DeRefDS(_new_map__12893);
    return _temp_map__12894;
    ;
}


int _32new_extra(int _the_map_p_12914, int _initial_size_p_12915)
{
    int _7019 = NOVALUE;
    int _7018 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if map(the_map_p) then*/
    Ref(_the_map_p_12914);
    _7018 = _32map(_the_map_p_12914);
    if (_7018 == 0) {
        DeRef(_7018);
        _7018 = NOVALUE;
        goto L1; // [9] 21
    }
    else {
        if (!IS_ATOM_INT(_7018) && DBL_PTR(_7018)->dbl == 0.0){
            DeRef(_7018);
            _7018 = NOVALUE;
            goto L1; // [9] 21
        }
        DeRef(_7018);
        _7018 = NOVALUE;
    }
    DeRef(_7018);
    _7018 = NOVALUE;

    /** 		return the_map_p*/
    return _the_map_p_12914;
    goto L2; // [18] 32
L1: 

    /** 		return new(initial_size_p)*/
    _7019 = _32new(_initial_size_p_12915);
    DeRef(_the_map_p_12914);
    return _7019;
L2: 
    ;
}


int _32has(int _the_map_p_12952, int _the_key_p_12953)
{
    int _index__12954 = NOVALUE;
    int _pos__12955 = NOVALUE;
    int _from__12956 = NOVALUE;
    int _calc_hash_1__tmp_at36_12968 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_36_12967 = NOVALUE;
    int _ret__inlined_calc_hash_at_36_12966 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_33_12965 = NOVALUE;
    int _7055 = NOVALUE;
    int _7053 = NOVALUE;
    int _7052 = NOVALUE;
    int _7049 = NOVALUE;
    int _7048 = NOVALUE;
    int _7047 = NOVALUE;
    int _7045 = NOVALUE;
    int _7044 = NOVALUE;
    int _7042 = NOVALUE;
    int _7040 = NOVALUE;
    int _7039 = NOVALUE;
    int _7038 = NOVALUE;
    int _7037 = NOVALUE;
    int _7036 = NOVALUE;
    int _7035 = NOVALUE;
    int _7033 = NOVALUE;
    int _7032 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_12952)) {
        _1 = (long)(DBL_PTR(_the_map_p_12952)->dbl);
        DeRefDS(_the_map_p_12952);
        _the_map_p_12952 = _1;
    }

    /** 	if eumem:ram_space[the_map_p][MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7032 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7032);
    _7033 = (int)*(((s1_ptr)_2)->base + 4);
    _7032 = NOVALUE;
    if (binary_op_a(NOTEQ, _7033, 76)){
        _7033 = NOVALUE;
        goto L1; // [15] 86
    }
    _7033 = NOVALUE;

    /** 		index_ = calc_hash(the_key_p, length(eumem:ram_space[the_map_p][KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7035 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7035);
    _7036 = (int)*(((s1_ptr)_2)->base + 5);
    _7035 = NOVALUE;
    if (IS_SEQUENCE(_7036)){
            _7037 = SEQ_PTR(_7036)->length;
    }
    else {
        _7037 = 1;
    }
    _7036 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_33_12965 = _7037;
    _7037 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_36_12966);
    _ret__inlined_calc_hash_at_36_12966 = calc_hash(_the_key_p_12953, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_36_12966)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_36_12966)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_36_12966);
        _ret__inlined_calc_hash_at_36_12966 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at36_12968 = (_ret__inlined_calc_hash_at_36_12966 % _max_hash_p_inlined_calc_hash_at_33_12965);
    _index__12954 = _calc_hash_1__tmp_at36_12968 + 1;
    DeRef(_ret__inlined_calc_hash_at_36_12966);
    _ret__inlined_calc_hash_at_36_12966 = NOVALUE;
    if (!IS_ATOM_INT(_index__12954)) {
        _1 = (long)(DBL_PTR(_index__12954)->dbl);
        DeRefDS(_index__12954);
        _index__12954 = _1;
    }

    /** 		pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_BUCKETS][index_])*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7038 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7038);
    _7039 = (int)*(((s1_ptr)_2)->base + 5);
    _7038 = NOVALUE;
    _2 = (int)SEQ_PTR(_7039);
    _7040 = (int)*(((s1_ptr)_2)->base + _index__12954);
    _7039 = NOVALUE;
    _pos__12955 = find_from(_the_key_p_12953, _7040, 1);
    _7040 = NOVALUE;
    goto L2; // [83] 201
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_12953 == _32init_small_map_key_12694)
    _7042 = 1;
    else if (IS_ATOM_INT(_the_key_p_12953) && IS_ATOM_INT(_32init_small_map_key_12694))
    _7042 = 0;
    else
    _7042 = (compare(_the_key_p_12953, _32init_small_map_key_12694) == 0);
    if (_7042 == 0)
    {
        _7042 = NOVALUE;
        goto L3; // [92] 182
    }
    else{
        _7042 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__12956 = 1;

    /** 			while from_ > 0 do*/
L4: 
    if (_from__12956 <= 0)
    goto L5; // [105] 200

    /** 				pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7044 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7044);
    _7045 = (int)*(((s1_ptr)_2)->base + 5);
    _7044 = NOVALUE;
    _pos__12955 = find_from(_the_key_p_12953, _7045, _from__12956);
    _7045 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__12955 == 0)
    {
        goto L6; // [128] 161
    }
    else{
    }

    /** 					if eumem:ram_space[the_map_p][FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7047 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7047);
    _7048 = (int)*(((s1_ptr)_2)->base + 7);
    _7047 = NOVALUE;
    _2 = (int)SEQ_PTR(_7048);
    _7049 = (int)*(((s1_ptr)_2)->base + _pos__12955);
    _7048 = NOVALUE;
    if (binary_op_a(NOTEQ, _7049, 1)){
        _7049 = NOVALUE;
        goto L7; // [147] 168
    }
    _7049 = NOVALUE;

    /** 						return 1*/
    DeRef(_the_key_p_12953);
    _7036 = NOVALUE;
    return 1;
    goto L7; // [158] 168
L6: 

    /** 					return 0*/
    DeRef(_the_key_p_12953);
    _7036 = NOVALUE;
    return 0;
L7: 

    /** 				from_ = pos_ + 1*/
    _from__12956 = _pos__12955 + 1;

    /** 			end while*/
    goto L4; // [176] 105
    goto L5; // [179] 200
L3: 

    /** 			pos_ = find(the_key_p, eumem:ram_space[the_map_p][KEY_LIST])*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _7052 = (int)*(((s1_ptr)_2)->base + _the_map_p_12952);
    _2 = (int)SEQ_PTR(_7052);
    _7053 = (int)*(((s1_ptr)_2)->base + 5);
    _7052 = NOVALUE;
    _pos__12955 = find_from(_the_key_p_12953, _7053, 1);
    _7053 = NOVALUE;
L5: 
L2: 

    /** 	return (pos_  != 0)	*/
    _7055 = (_pos__12955 != 0);
    DeRef(_the_key_p_12953);
    _7036 = NOVALUE;
    return _7055;
    ;
}


int _32get(int _the_map_p_12996, int _the_key_p_12997, int _default_value_p_12998)
{
    int _bucket__12999 = NOVALUE;
    int _pos__13000 = NOVALUE;
    int _from__13001 = NOVALUE;
    int _themap_13002 = NOVALUE;
    int _thekeys_13007 = NOVALUE;
    int _calc_hash_1__tmp_at40_13014 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13013 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13012 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13011 = NOVALUE;
    int _7080 = NOVALUE;
    int _7079 = NOVALUE;
    int _7077 = NOVALUE;
    int _7075 = NOVALUE;
    int _7074 = NOVALUE;
    int _7072 = NOVALUE;
    int _7071 = NOVALUE;
    int _7069 = NOVALUE;
    int _7067 = NOVALUE;
    int _7066 = NOVALUE;
    int _7065 = NOVALUE;
    int _7064 = NOVALUE;
    int _7061 = NOVALUE;
    int _7060 = NOVALUE;
    int _7057 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map_p_12996)) {
        _1 = (long)(DBL_PTR(_the_map_p_12996)->dbl);
        DeRefDS(_the_map_p_12996);
        _the_map_p_12996 = _1;
    }

    /** 	themap = eumem:ram_space[the_map_p]*/
    DeRef(_themap_13002);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _themap_13002 = (int)*(((s1_ptr)_2)->base + _the_map_p_12996);
    Ref(_themap_13002);

    /** 	if themap[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7057 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7057, 76)){
        _7057 = NOVALUE;
        goto L1; // [19] 113
    }
    _7057 = NOVALUE;

    /** 		sequence thekeys*/

    /** 		thekeys = themap[KEY_BUCKETS]*/
    DeRef(_thekeys_13007);
    _2 = (int)SEQ_PTR(_themap_13002);
    _thekeys_13007 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_thekeys_13007);

    /** 		bucket_ = calc_hash(the_key_p, length(thekeys))*/
    if (IS_SEQUENCE(_thekeys_13007)){
            _7060 = SEQ_PTR(_thekeys_13007)->length;
    }
    else {
        _7060 = 1;
    }
    _max_hash_p_inlined_calc_hash_at_37_13011 = _7060;
    _7060 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13012);
    _ret__inlined_calc_hash_at_40_13012 = calc_hash(_the_key_p_12997, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13012)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13012)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13012);
        _ret__inlined_calc_hash_at_40_13012 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13014 = (_ret__inlined_calc_hash_at_40_13012 % _max_hash_p_inlined_calc_hash_at_37_13011);
    _bucket__12999 = _calc_hash_1__tmp_at40_13014 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13012);
    _ret__inlined_calc_hash_at_40_13012 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__12999)) {
        _1 = (long)(DBL_PTR(_bucket__12999)->dbl);
        DeRefDS(_bucket__12999);
        _bucket__12999 = _1;
    }

    /** 		pos_ = find(the_key_p, thekeys[bucket_])*/
    _2 = (int)SEQ_PTR(_thekeys_13007);
    _7061 = (int)*(((s1_ptr)_2)->base + _bucket__12999);
    _pos__13000 = find_from(_the_key_p_12997, _7061, 1);
    _7061 = NOVALUE;

    /** 		if pos_ > 0 then*/
    if (_pos__13000 <= 0)
    goto L2; // [79] 102

    /** 			return themap[VALUE_BUCKETS][bucket_][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7064 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7064);
    _7065 = (int)*(((s1_ptr)_2)->base + _bucket__12999);
    _7064 = NOVALUE;
    _2 = (int)SEQ_PTR(_7065);
    _7066 = (int)*(((s1_ptr)_2)->base + _pos__13000);
    _7065 = NOVALUE;
    Ref(_7066);
    DeRefDS(_thekeys_13007);
    DeRef(_the_key_p_12997);
    DeRef(_default_value_p_12998);
    DeRefDS(_themap_13002);
    return _7066;
L2: 

    /** 		return default_value_p*/
    DeRef(_thekeys_13007);
    DeRef(_the_key_p_12997);
    DeRef(_themap_13002);
    _7066 = NOVALUE;
    return _default_value_p_12998;
    goto L3; // [110] 238
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_12997 == _32init_small_map_key_12694)
    _7067 = 1;
    else if (IS_ATOM_INT(_the_key_p_12997) && IS_ATOM_INT(_32init_small_map_key_12694))
    _7067 = 0;
    else
    _7067 = (compare(_the_key_p_12997, _32init_small_map_key_12694) == 0);
    if (_7067 == 0)
    {
        _7067 = NOVALUE;
        goto L4; // [119] 205
    }
    else{
        _7067 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13001 = 1;

    /** 			while from_ > 0 do*/
L5: 
    if (_from__13001 <= 0)
    goto L6; // [132] 237

    /** 				pos_ = find(the_key_p, themap[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7069 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13000 = find_from(_the_key_p_12997, _7069, _from__13001);
    _7069 = NOVALUE;

    /** 				if pos_ then*/
    if (_pos__13000 == 0)
    {
        goto L7; // [149] 184
    }
    else{
    }

    /** 					if themap[FREE_LIST][pos_] = 1 then*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7071 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7071);
    _7072 = (int)*(((s1_ptr)_2)->base + _pos__13000);
    _7071 = NOVALUE;
    if (binary_op_a(NOTEQ, _7072, 1)){
        _7072 = NOVALUE;
        goto L8; // [162] 191
    }
    _7072 = NOVALUE;

    /** 						return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7074 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7074);
    _7075 = (int)*(((s1_ptr)_2)->base + _pos__13000);
    _7074 = NOVALUE;
    Ref(_7075);
    DeRef(_the_key_p_12997);
    DeRef(_default_value_p_12998);
    DeRefDS(_themap_13002);
    _7066 = NOVALUE;
    return _7075;
    goto L8; // [181] 191
L7: 

    /** 					return default_value_p*/
    DeRef(_the_key_p_12997);
    DeRef(_themap_13002);
    _7066 = NOVALUE;
    _7075 = NOVALUE;
    return _default_value_p_12998;
L8: 

    /** 				from_ = pos_ + 1*/
    _from__13001 = _pos__13000 + 1;

    /** 			end while*/
    goto L5; // [199] 132
    goto L6; // [202] 237
L4: 

    /** 			pos_ = find(the_key_p, themap[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7077 = (int)*(((s1_ptr)_2)->base + 5);
    _pos__13000 = find_from(_the_key_p_12997, _7077, 1);
    _7077 = NOVALUE;

    /** 			if pos_  then*/
    if (_pos__13000 == 0)
    {
        goto L9; // [218] 236
    }
    else{
    }

    /** 				return themap[VALUE_LIST][pos_]*/
    _2 = (int)SEQ_PTR(_themap_13002);
    _7079 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7079);
    _7080 = (int)*(((s1_ptr)_2)->base + _pos__13000);
    _7079 = NOVALUE;
    Ref(_7080);
    DeRef(_the_key_p_12997);
    DeRef(_default_value_p_12998);
    DeRefDS(_themap_13002);
    _7066 = NOVALUE;
    _7075 = NOVALUE;
    return _7080;
L9: 
L6: 
L3: 

    /** 	return default_value_p*/
    DeRef(_the_key_p_12997);
    DeRef(_themap_13002);
    _7066 = NOVALUE;
    _7075 = NOVALUE;
    _7080 = NOVALUE;
    return _default_value_p_12998;
    ;
}


void _32put(int _the_map_p_13066, int _the_key_p_13067, int _the_value_p_13068, int _operation_p_13069, int _trigger_p_13070)
{
    int _index__13071 = NOVALUE;
    int _bucket__13072 = NOVALUE;
    int _average_length__13073 = NOVALUE;
    int _from__13074 = NOVALUE;
    int _map_data_13075 = NOVALUE;
    int _calc_hash_1__tmp_at46_13086 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_46_13085 = NOVALUE;
    int _ret__inlined_calc_hash_at_46_13084 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_43_13083 = NOVALUE;
    int _data_13118 = NOVALUE;
    int _msg_inlined_crash_at_334_13134 = NOVALUE;
    int _msg_inlined_crash_at_379_13140 = NOVALUE;
    int _tmp_seqk_13154 = NOVALUE;
    int _tmp_seqv_13162 = NOVALUE;
    int _msg_inlined_crash_at_721_13198 = NOVALUE;
    int _msg_inlined_crash_at_1079_13261 = NOVALUE;
    int _7224 = NOVALUE;
    int _7223 = NOVALUE;
    int _7221 = NOVALUE;
    int _7220 = NOVALUE;
    int _7219 = NOVALUE;
    int _7218 = NOVALUE;
    int _7216 = NOVALUE;
    int _7215 = NOVALUE;
    int _7214 = NOVALUE;
    int _7212 = NOVALUE;
    int _7211 = NOVALUE;
    int _7210 = NOVALUE;
    int _7208 = NOVALUE;
    int _7207 = NOVALUE;
    int _7206 = NOVALUE;
    int _7204 = NOVALUE;
    int _7203 = NOVALUE;
    int _7202 = NOVALUE;
    int _7200 = NOVALUE;
    int _7198 = NOVALUE;
    int _7192 = NOVALUE;
    int _7191 = NOVALUE;
    int _7190 = NOVALUE;
    int _7189 = NOVALUE;
    int _7187 = NOVALUE;
    int _7185 = NOVALUE;
    int _7184 = NOVALUE;
    int _7183 = NOVALUE;
    int _7182 = NOVALUE;
    int _7181 = NOVALUE;
    int _7180 = NOVALUE;
    int _7177 = NOVALUE;
    int _7175 = NOVALUE;
    int _7172 = NOVALUE;
    int _7170 = NOVALUE;
    int _7167 = NOVALUE;
    int _7166 = NOVALUE;
    int _7164 = NOVALUE;
    int _7161 = NOVALUE;
    int _7160 = NOVALUE;
    int _7157 = NOVALUE;
    int _7154 = NOVALUE;
    int _7152 = NOVALUE;
    int _7150 = NOVALUE;
    int _7147 = NOVALUE;
    int _7145 = NOVALUE;
    int _7144 = NOVALUE;
    int _7143 = NOVALUE;
    int _7142 = NOVALUE;
    int _7141 = NOVALUE;
    int _7140 = NOVALUE;
    int _7139 = NOVALUE;
    int _7138 = NOVALUE;
    int _7137 = NOVALUE;
    int _7131 = NOVALUE;
    int _7129 = NOVALUE;
    int _7128 = NOVALUE;
    int _7126 = NOVALUE;
    int _7124 = NOVALUE;
    int _7121 = NOVALUE;
    int _7120 = NOVALUE;
    int _7119 = NOVALUE;
    int _7118 = NOVALUE;
    int _7116 = NOVALUE;
    int _7115 = NOVALUE;
    int _7114 = NOVALUE;
    int _7112 = NOVALUE;
    int _7111 = NOVALUE;
    int _7110 = NOVALUE;
    int _7108 = NOVALUE;
    int _7107 = NOVALUE;
    int _7106 = NOVALUE;
    int _7104 = NOVALUE;
    int _7102 = NOVALUE;
    int _7097 = NOVALUE;
    int _7096 = NOVALUE;
    int _7095 = NOVALUE;
    int _7094 = NOVALUE;
    int _7092 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_the_map_p_13066)) {
        _1 = (long)(DBL_PTR(_the_map_p_13066)->dbl);
        DeRefDS(_the_map_p_13066);
        _the_map_p_13066 = _1;
    }

    /** 	sequence map_data = eumem:ram_space[the_map_p]*/
    DeRef(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _map_data_13075 = (int)*(((s1_ptr)_2)->base + _the_map_p_13066);
    Ref(_map_data_13075);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if map_data[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7092 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7092, 76)){
        _7092 = NOVALUE;
        goto L1; // [31] 618
    }
    _7092 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p,  length(map_data[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7094 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7094)){
            _7095 = SEQ_PTR(_7094)->length;
    }
    else {
        _7095 = 1;
    }
    _7094 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_43_13083 = _7095;
    _7095 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_46_13084);
    _ret__inlined_calc_hash_at_46_13084 = calc_hash(_the_key_p_13067, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_46_13084)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_46_13084)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_46_13084);
        _ret__inlined_calc_hash_at_46_13084 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at46_13086 = (_ret__inlined_calc_hash_at_46_13084 % _max_hash_p_inlined_calc_hash_at_43_13083);
    _bucket__13072 = _calc_hash_1__tmp_at46_13086 + 1;
    DeRef(_ret__inlined_calc_hash_at_46_13084);
    _ret__inlined_calc_hash_at_46_13084 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__13072)) {
        _1 = (long)(DBL_PTR(_bucket__13072)->dbl);
        DeRefDS(_bucket__13072);
        _bucket__13072 = _1;
    }

    /** 		index_ = find(the_key_p, map_data[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7096 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7096);
    _7097 = (int)*(((s1_ptr)_2)->base + _bucket__13072);
    _7096 = NOVALUE;
    _index__13071 = find_from(_the_key_p_13067, _7097, 1);
    _7097 = NOVALUE;

    /** 		if index_ > 0 then*/
    if (_index__13071 <= 0)
    goto L2; // [89] 368

    /** 			switch operation_p do*/
    _0 = _operation_p_13069;
    switch ( _0 ){ 

        /** 				case PUT then*/
        case 1:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7102 = NOVALUE;
        Ref(_the_value_p_13068);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13068;
        DeRef(_1);
        _7102 = NOVALUE;
        goto L3; // [120] 354

        /** 				case ADD then*/
        case 2:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7104 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7106 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7104 = NOVALUE;
        if (IS_ATOM_INT(_7106) && IS_ATOM_INT(_the_value_p_13068)) {
            _7107 = _7106 + _the_value_p_13068;
            if ((long)((unsigned long)_7107 + (unsigned long)HIGH_BITS) >= 0) 
            _7107 = NewDouble((double)_7107);
        }
        else {
            _7107 = binary_op(PLUS, _7106, _the_value_p_13068);
        }
        _7106 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7107;
        if( _1 != _7107 ){
            DeRef(_1);
        }
        _7107 = NOVALUE;
        _7104 = NOVALUE;
        goto L3; // [150] 354

        /** 				case SUBTRACT then*/
        case 3:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7108 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7110 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7108 = NOVALUE;
        if (IS_ATOM_INT(_7110) && IS_ATOM_INT(_the_value_p_13068)) {
            _7111 = _7110 - _the_value_p_13068;
            if ((long)((unsigned long)_7111 +(unsigned long) HIGH_BITS) >= 0){
                _7111 = NewDouble((double)_7111);
            }
        }
        else {
            _7111 = binary_op(MINUS, _7110, _the_value_p_13068);
        }
        _7110 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7111;
        if( _1 != _7111 ){
            DeRef(_1);
        }
        _7111 = NOVALUE;
        _7108 = NOVALUE;
        goto L3; // [180] 354

        /** 				case MULTIPLY then*/
        case 4:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7112 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7114 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7112 = NOVALUE;
        if (IS_ATOM_INT(_7114) && IS_ATOM_INT(_the_value_p_13068)) {
            if (_7114 == (short)_7114 && _the_value_p_13068 <= INT15 && _the_value_p_13068 >= -INT15)
            _7115 = _7114 * _the_value_p_13068;
            else
            _7115 = NewDouble(_7114 * (double)_the_value_p_13068);
        }
        else {
            _7115 = binary_op(MULTIPLY, _7114, _the_value_p_13068);
        }
        _7114 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7115;
        if( _1 != _7115 ){
            DeRef(_1);
        }
        _7115 = NOVALUE;
        _7112 = NOVALUE;
        goto L3; // [210] 354

        /** 				case DIVIDE then*/
        case 5:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7116 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7118 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7116 = NOVALUE;
        if (IS_ATOM_INT(_7118) && IS_ATOM_INT(_the_value_p_13068)) {
            _7119 = (_7118 % _the_value_p_13068) ? NewDouble((double)_7118 / _the_value_p_13068) : (_7118 / _the_value_p_13068);
        }
        else {
            _7119 = binary_op(DIVIDE, _7118, _the_value_p_13068);
        }
        _7118 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7119;
        if( _1 != _7119 ){
            DeRef(_1);
        }
        _7119 = NOVALUE;
        _7116 = NOVALUE;
        goto L3; // [240] 354

        /** 				case APPEND then*/
        case 6:

        /** 					sequence data = map_data[VALUE_BUCKETS][bucket_][index_]*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        _7120 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7120);
        _7121 = (int)*(((s1_ptr)_2)->base + _bucket__13072);
        _7120 = NOVALUE;
        DeRef(_data_13118);
        _2 = (int)SEQ_PTR(_7121);
        _data_13118 = (int)*(((s1_ptr)_2)->base + _index__13071);
        Ref(_data_13118);
        _7121 = NOVALUE;

        /** 					data = append( data, the_value_p )*/
        Ref(_the_value_p_13068);
        Append(&_data_13118, _data_13118, _the_value_p_13068);

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] = data*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7124 = NOVALUE;
        RefDS(_data_13118);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _data_13118;
        DeRef(_1);
        _7124 = NOVALUE;
        DeRefDS(_data_13118);
        _data_13118 = NOVALUE;
        goto L3; // [286] 354

        /** 				case CONCAT then*/
        case 7:

        /** 					map_data[VALUE_BUCKETS][bucket_][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(object_ptr)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(object_ptr)_3 = MAKE_SEQ(_2);
        }
        _3 = (int)(_bucket__13072 + ((s1_ptr)_2)->base);
        _7126 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7128 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7126 = NOVALUE;
        if (IS_SEQUENCE(_7128) && IS_ATOM(_the_value_p_13068)) {
            Ref(_the_value_p_13068);
            Append(&_7129, _7128, _the_value_p_13068);
        }
        else if (IS_ATOM(_7128) && IS_SEQUENCE(_the_value_p_13068)) {
            Ref(_7128);
            Prepend(&_7129, _the_value_p_13068, _7128);
        }
        else {
            Concat((object_ptr)&_7129, _7128, _the_value_p_13068);
            _7128 = NOVALUE;
        }
        _7128 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7129;
        if( _1 != _7129 ){
            DeRef(_1);
        }
        _7129 = NOVALUE;
        _7126 = NOVALUE;
        goto L3; // [316] 354

        /** 				case LEAVE then*/
        case 8:

        /** 					operation_p = operation_p*/
        _operation_p_13069 = _operation_p_13069;
        goto L3; // [327] 354

        /** 				case else*/
        default:

        /** 					error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_334_13134);
        _msg_inlined_crash_at_334_13134 = EPrintf(-9999999, _7130, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_334_13134);

        /** end procedure*/
        goto L4; // [348] 351
L4: 
        DeRefi(_msg_inlined_crash_at_334_13134);
        _msg_inlined_crash_at_334_13134 = NOVALUE;
    ;}L3: 

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13075;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13154);
    DeRef(_tmp_seqv_13162);
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRefDS(_map_data_13075);
    _7094 = NOVALUE;
    return;
L2: 

    /** 		if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7131 = find_from(_operation_p_13069, _32INIT_OPERATIONS_12689, 1);
    if (_7131 != 0)
    goto L5; // [375] 399
    _7131 = NOVALUE;

    /** 				error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_379_13140);
    _msg_inlined_crash_at_379_13140 = EPrintf(-9999999, _7133, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_379_13140);

    /** end procedure*/
    goto L6; // [393] 396
L6: 
    DeRefi(_msg_inlined_crash_at_379_13140);
    _msg_inlined_crash_at_379_13140 = NOVALUE;
L5: 

    /** 		if operation_p = LEAVE then*/
    if (_operation_p_13069 != 8)
    goto L7; // [401] 419

    /** 			eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13075;
    DeRef(_1);

    /** 			return*/
    DeRef(_tmp_seqk_13154);
    DeRef(_tmp_seqv_13162);
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRefDS(_map_data_13075);
    _7094 = NOVALUE;
    return;
L7: 

    /** 		if operation_p = APPEND then*/
    if (_operation_p_13069 != 6)
    goto L8; // [421] 432

    /** 			the_value_p = { the_value_p }*/
    _0 = _the_value_p_13068;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13068);
    *((int *)(_2+4)) = _the_value_p_13068;
    _the_value_p_13068 = MAKE_SEQ(_1);
    DeRef(_0);
L8: 

    /** 		map_data[IN_USE] += (length(map_data[KEY_BUCKETS][bucket_]) = 0)*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7137 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7137);
    _7138 = (int)*(((s1_ptr)_2)->base + _bucket__13072);
    _7137 = NOVALUE;
    if (IS_SEQUENCE(_7138)){
            _7139 = SEQ_PTR(_7138)->length;
    }
    else {
        _7139 = 1;
    }
    _7138 = NOVALUE;
    _7140 = (_7139 == 0);
    _7139 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7141 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7141)) {
        _7142 = _7141 + _7140;
        if ((long)((unsigned long)_7142 + (unsigned long)HIGH_BITS) >= 0) 
        _7142 = NewDouble((double)_7142);
    }
    else {
        _7142 = binary_op(PLUS, _7141, _7140);
    }
    _7141 = NOVALUE;
    _7140 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7142;
    if( _1 != _7142 ){
        DeRef(_1);
    }
    _7142 = NOVALUE;

    /** 		map_data[ELEMENT_COUNT] += 1 -- elementCount		*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7143 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7143)) {
        _7144 = _7143 + 1;
        if (_7144 > MAXINT){
            _7144 = NewDouble((double)_7144);
        }
    }
    else
    _7144 = binary_op(PLUS, 1, _7143);
    _7143 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7144;
    if( _1 != _7144 ){
        DeRef(_1);
    }
    _7144 = NOVALUE;

    /** 		sequence tmp_seqk*/

    /** 		tmp_seqk = map_data[KEY_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7145 = (int)*(((s1_ptr)_2)->base + 5);
    DeRef(_tmp_seqk_13154);
    _2 = (int)SEQ_PTR(_7145);
    _tmp_seqk_13154 = (int)*(((s1_ptr)_2)->base + _bucket__13072);
    Ref(_tmp_seqk_13154);
    _7145 = NOVALUE;

    /** 		map_data[KEY_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13072);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7147 = NOVALUE;

    /** 		tmp_seqk = append( tmp_seqk, the_key_p)*/
    Ref(_the_key_p_13067);
    Append(&_tmp_seqk_13154, _tmp_seqk_13154, _the_key_p_13067);

    /** 		map_data[KEY_BUCKETS][bucket_] = tmp_seqk*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqk_13154);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13072);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqk_13154;
    DeRef(_1);
    _7150 = NOVALUE;

    /** 		sequence tmp_seqv*/

    /** 		tmp_seqv = map_data[VALUE_BUCKETS][bucket_]*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7152 = (int)*(((s1_ptr)_2)->base + 6);
    DeRef(_tmp_seqv_13162);
    _2 = (int)SEQ_PTR(_7152);
    _tmp_seqv_13162 = (int)*(((s1_ptr)_2)->base + _bucket__13072);
    Ref(_tmp_seqv_13162);
    _7152 = NOVALUE;

    /** 		map_data[VALUE_BUCKETS][bucket_] = 0*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13072);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7154 = NOVALUE;

    /** 		tmp_seqv = append( tmp_seqv, the_value_p)*/
    Ref(_the_value_p_13068);
    Append(&_tmp_seqv_13162, _tmp_seqv_13162, _the_value_p_13068);

    /** 		map_data[VALUE_BUCKETS][bucket_] = tmp_seqv*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_tmp_seqv_13162);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13072);
    _1 = *(int *)_2;
    *(int *)_2 = _tmp_seqv_13162;
    DeRef(_1);
    _7157 = NOVALUE;

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13075;
    DeRef(_1);

    /** 		if trigger_p > 0 then*/
    if (_trigger_p_13070 <= 0)
    goto L9; // [569] 608

    /** 			average_length_ = map_data[ELEMENT_COUNT] / map_data[IN_USE]*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7160 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7161 = (int)*(((s1_ptr)_2)->base + 3);
    DeRef(_average_length__13073);
    if (IS_ATOM_INT(_7160) && IS_ATOM_INT(_7161)) {
        _average_length__13073 = (_7160 % _7161) ? NewDouble((double)_7160 / _7161) : (_7160 / _7161);
    }
    else {
        _average_length__13073 = binary_op(DIVIDE, _7160, _7161);
    }
    _7160 = NOVALUE;
    _7161 = NOVALUE;

    /** 			if (average_length_ >= trigger_p) then*/
    if (binary_op_a(LESS, _average_length__13073, _trigger_p_13070)){
        goto LA; // [589] 607
    }

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13075);
    _map_data_13075 = _5;

    /** 				rehash(the_map_p)*/
    _32rehash(_the_map_p_13066, 0);
LA: 
L9: 

    /** 		return*/
    DeRef(_tmp_seqk_13154);
    DeRef(_tmp_seqv_13162);
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRef(_map_data_13075);
    _7094 = NOVALUE;
    _7138 = NOVALUE;
    return;
    goto LB; // [615] 1112
L1: 

    /** 		if equal(the_key_p, init_small_map_key) then*/
    if (_the_key_p_13067 == _32init_small_map_key_12694)
    _7164 = 1;
    else if (IS_ATOM_INT(_the_key_p_13067) && IS_ATOM_INT(_32init_small_map_key_12694))
    _7164 = 0;
    else
    _7164 = (compare(_the_key_p_13067, _32init_small_map_key_12694) == 0);
    if (_7164 == 0)
    {
        _7164 = NOVALUE;
        goto LC; // [624] 690
    }
    else{
        _7164 = NOVALUE;
    }

    /** 			from_ = 1*/
    _from__13074 = 1;

    /** 			while index_ > 0 with entry do*/
    goto LD; // [634] 671
LE: 
    if (_index__13071 <= 0)
    goto LF; // [639] 702

    /** 				if map_data[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7166 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7166);
    _7167 = (int)*(((s1_ptr)_2)->base + _index__13071);
    _7166 = NOVALUE;
    if (binary_op_a(NOTEQ, _7167, 1)){
        _7167 = NOVALUE;
        goto L10; // [653] 662
    }
    _7167 = NOVALUE;

    /** 					exit*/
    goto LF; // [659] 702
L10: 

    /** 				from_ = index_ + 1*/
    _from__13074 = _index__13071 + 1;

    /** 			  entry*/
LD: 

    /** 				index_ = find(the_key_p, map_data[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7170 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13071 = find_from(_the_key_p_13067, _7170, _from__13074);
    _7170 = NOVALUE;

    /** 			end while*/
    goto LE; // [684] 637
    goto LF; // [687] 702
LC: 

    /** 			index_ = find(the_key_p, map_data[KEY_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7172 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13071 = find_from(_the_key_p_13067, _7172, 1);
    _7172 = NOVALUE;
LF: 

    /** 		if index_ = 0 then*/
    if (_index__13071 != 0)
    goto L11; // [706] 884

    /** 			if not eu:find(operation_p, INIT_OPERATIONS) then*/
    _7175 = find_from(_operation_p_13069, _32INIT_OPERATIONS_12689, 1);
    if (_7175 != 0)
    goto L12; // [717] 741
    _7175 = NOVALUE;

    /** 					error:crash("Inappropriate initial operation given to map.e:put()")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_721_13198);
    _msg_inlined_crash_at_721_13198 = EPrintf(-9999999, _7133, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_721_13198);

    /** end procedure*/
    goto L13; // [735] 738
L13: 
    DeRefi(_msg_inlined_crash_at_721_13198);
    _msg_inlined_crash_at_721_13198 = NOVALUE;
L12: 

    /** 			index_ = find(0, map_data[FREE_LIST])*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7177 = (int)*(((s1_ptr)_2)->base + 7);
    _index__13071 = find_from(0, _7177, 1);
    _7177 = NOVALUE;

    /** 			if index_ = 0 then*/
    if (_index__13071 != 0)
    goto L14; // [754] 808

    /** 				eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13075;
    DeRef(_1);

    /** 				map_data = {}*/
    RefDS(_5);
    DeRefDS(_map_data_13075);
    _map_data_13075 = _5;

    /** 				convert_to_large_map(the_map_p)*/
    _32convert_to_large_map(_the_map_p_13066);

    /** 				put(the_map_p, the_key_p, the_value_p, operation_p, trigger_p)*/
    DeRef(_7180);
    _7180 = _the_map_p_13066;
    Ref(_the_key_p_13067);
    DeRef(_7181);
    _7181 = _the_key_p_13067;
    Ref(_the_value_p_13068);
    DeRef(_7182);
    _7182 = _the_value_p_13068;
    DeRef(_7183);
    _7183 = _operation_p_13069;
    DeRef(_7184);
    _7184 = _trigger_p_13070;
    _32put(_7180, _7181, _7182, _7183, _7184);
    _7180 = NOVALUE;
    _7181 = NOVALUE;
    _7182 = NOVALUE;
    _7183 = NOVALUE;
    _7184 = NOVALUE;

    /** 				return*/
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRefDS(_map_data_13075);
    _7094 = NOVALUE;
    _7138 = NOVALUE;
    return;
L14: 

    /** 			map_data[KEY_LIST][index_] = the_key_p*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    Ref(_the_key_p_13067);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13071);
    _1 = *(int *)_2;
    *(int *)_2 = _the_key_p_13067;
    DeRef(_1);
    _7185 = NOVALUE;

    /** 			map_data[FREE_LIST][index_] = 1*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13071);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _7187 = NOVALUE;

    /** 			map_data[IN_USE] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7189 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7189)) {
        _7190 = _7189 + 1;
        if (_7190 > MAXINT){
            _7190 = NewDouble((double)_7190);
        }
    }
    else
    _7190 = binary_op(PLUS, 1, _7189);
    _7189 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7190;
    if( _1 != _7190 ){
        DeRef(_1);
    }
    _7190 = NOVALUE;

    /** 			map_data[ELEMENT_COUNT] += 1*/
    _2 = (int)SEQ_PTR(_map_data_13075);
    _7191 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7191)) {
        _7192 = _7191 + 1;
        if (_7192 > MAXINT){
            _7192 = NewDouble((double)_7192);
        }
    }
    else
    _7192 = binary_op(PLUS, 1, _7191);
    _7191 = NOVALUE;
    _2 = (int)SEQ_PTR(_map_data_13075);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _map_data_13075 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7192;
    if( _1 != _7192 ){
        DeRef(_1);
    }
    _7192 = NOVALUE;

    /** 			if operation_p = APPEND then*/
    if (_operation_p_13069 != 6)
    goto L15; // [860] 871

    /** 				the_value_p = { the_value_p }*/
    _0 = _the_value_p_13068;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_the_value_p_13068);
    *((int *)(_2+4)) = _the_value_p_13068;
    _the_value_p_13068 = MAKE_SEQ(_1);
    DeRef(_0);
L15: 

    /** 			if operation_p != LEAVE then*/
    if (_operation_p_13069 == 8)
    goto L16; // [873] 883

    /** 				operation_p = PUT	-- Initially, nearly everything is a PUT.*/
    _operation_p_13069 = 1;
L16: 
L11: 

    /** 		switch operation_p do*/
    _0 = _operation_p_13069;
    switch ( _0 ){ 

        /** 			case PUT then*/
        case 1:

        /** 				map_data[VALUE_LIST][index_] = the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        Ref(_the_value_p_13068);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _the_value_p_13068;
        DeRef(_1);
        _7198 = NOVALUE;
        goto L17; // [906] 1098

        /** 			case ADD then*/
        case 2:

        /** 				map_data[VALUE_LIST][index_] += the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7202 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7200 = NOVALUE;
        if (IS_ATOM_INT(_7202) && IS_ATOM_INT(_the_value_p_13068)) {
            _7203 = _7202 + _the_value_p_13068;
            if ((long)((unsigned long)_7203 + (unsigned long)HIGH_BITS) >= 0) 
            _7203 = NewDouble((double)_7203);
        }
        else {
            _7203 = binary_op(PLUS, _7202, _the_value_p_13068);
        }
        _7202 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7203;
        if( _1 != _7203 ){
            DeRef(_1);
        }
        _7203 = NOVALUE;
        _7200 = NOVALUE;
        goto L17; // [931] 1098

        /** 			case SUBTRACT then*/
        case 3:

        /** 				map_data[VALUE_LIST][index_] -= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7206 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7204 = NOVALUE;
        if (IS_ATOM_INT(_7206) && IS_ATOM_INT(_the_value_p_13068)) {
            _7207 = _7206 - _the_value_p_13068;
            if ((long)((unsigned long)_7207 +(unsigned long) HIGH_BITS) >= 0){
                _7207 = NewDouble((double)_7207);
            }
        }
        else {
            _7207 = binary_op(MINUS, _7206, _the_value_p_13068);
        }
        _7206 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7207;
        if( _1 != _7207 ){
            DeRef(_1);
        }
        _7207 = NOVALUE;
        _7204 = NOVALUE;
        goto L17; // [956] 1098

        /** 			case MULTIPLY then*/
        case 4:

        /** 				map_data[VALUE_LIST][index_] *= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7210 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7208 = NOVALUE;
        if (IS_ATOM_INT(_7210) && IS_ATOM_INT(_the_value_p_13068)) {
            if (_7210 == (short)_7210 && _the_value_p_13068 <= INT15 && _the_value_p_13068 >= -INT15)
            _7211 = _7210 * _the_value_p_13068;
            else
            _7211 = NewDouble(_7210 * (double)_the_value_p_13068);
        }
        else {
            _7211 = binary_op(MULTIPLY, _7210, _the_value_p_13068);
        }
        _7210 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7211;
        if( _1 != _7211 ){
            DeRef(_1);
        }
        _7211 = NOVALUE;
        _7208 = NOVALUE;
        goto L17; // [981] 1098

        /** 			case DIVIDE then*/
        case 5:

        /** 				map_data[VALUE_LIST][index_] /= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7214 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7212 = NOVALUE;
        if (IS_ATOM_INT(_7214) && IS_ATOM_INT(_the_value_p_13068)) {
            _7215 = (_7214 % _the_value_p_13068) ? NewDouble((double)_7214 / _the_value_p_13068) : (_7214 / _the_value_p_13068);
        }
        else {
            _7215 = binary_op(DIVIDE, _7214, _the_value_p_13068);
        }
        _7214 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7215;
        if( _1 != _7215 ){
            DeRef(_1);
        }
        _7215 = NOVALUE;
        _7212 = NOVALUE;
        goto L17; // [1006] 1098

        /** 			case APPEND then*/
        case 6:

        /** 				map_data[VALUE_LIST][index_] = append( map_data[VALUE_LIST][index_], the_value_p )*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_map_data_13075);
        _7218 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7218);
        _7219 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7218 = NOVALUE;
        Ref(_the_value_p_13068);
        Append(&_7220, _7219, _the_value_p_13068);
        _7219 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7220;
        if( _1 != _7220 ){
            DeRef(_1);
        }
        _7220 = NOVALUE;
        _7216 = NOVALUE;
        goto L17; // [1035] 1098

        /** 			case CONCAT then*/
        case 7:

        /** 				map_data[VALUE_LIST][index_] &= the_value_p*/
        _2 = (int)SEQ_PTR(_map_data_13075);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _map_data_13075 = MAKE_SEQ(_2);
        }
        _3 = (int)(6 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _7223 = (int)*(((s1_ptr)_2)->base + _index__13071);
        _7221 = NOVALUE;
        if (IS_SEQUENCE(_7223) && IS_ATOM(_the_value_p_13068)) {
            Ref(_the_value_p_13068);
            Append(&_7224, _7223, _the_value_p_13068);
        }
        else if (IS_ATOM(_7223) && IS_SEQUENCE(_the_value_p_13068)) {
            Ref(_7223);
            Prepend(&_7224, _the_value_p_13068, _7223);
        }
        else {
            Concat((object_ptr)&_7224, _7223, _the_value_p_13068);
            _7223 = NOVALUE;
        }
        _7223 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _index__13071);
        _1 = *(int *)_2;
        *(int *)_2 = _7224;
        if( _1 != _7224 ){
            DeRef(_1);
        }
        _7224 = NOVALUE;
        _7221 = NOVALUE;
        goto L17; // [1060] 1098

        /** 			case LEAVE then*/
        case 8:

        /** 				operation_p = operation_p*/
        _operation_p_13069 = _operation_p_13069;
        goto L17; // [1071] 1098

        /** 			case else*/
        default:

        /** 				error:crash("Unknown operation given to map.e:put()")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_1079_13261);
        _msg_inlined_crash_at_1079_13261 = EPrintf(-9999999, _7130, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_1079_13261);

        /** end procedure*/
        goto L18; // [1092] 1095
L18: 
        DeRefi(_msg_inlined_crash_at_1079_13261);
        _msg_inlined_crash_at_1079_13261 = NOVALUE;
    ;}L17: 

    /** 		eumem:ram_space[the_map_p] = map_data*/
    RefDS(_map_data_13075);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13066);
    _1 = *(int *)_2;
    *(int *)_2 = _map_data_13075;
    DeRef(_1);

    /** 		return*/
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRefDS(_map_data_13075);
    _7094 = NOVALUE;
    _7138 = NOVALUE;
    return;
LB: 

    /** end procedure*/
    DeRef(_the_key_p_13067);
    DeRef(_the_value_p_13068);
    DeRef(_average_length__13073);
    DeRef(_map_data_13075);
    _7094 = NOVALUE;
    _7138 = NOVALUE;
    return;
    ;
}


void _32nested_put(int _the_map_p_13264, int _the_keys_p_13265, int _the_value_p_13266, int _operation_p_13267, int _trigger_p_13268)
{
    int _temp_map__13269 = NOVALUE;
    int _7236 = NOVALUE;
    int _7235 = NOVALUE;
    int _7234 = NOVALUE;
    int _7233 = NOVALUE;
    int _7232 = NOVALUE;
    int _7231 = NOVALUE;
    int _7229 = NOVALUE;
    int _7228 = NOVALUE;
    int _7227 = NOVALUE;
    int _7225 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( the_keys_p ) = 1 then*/
    if (IS_SEQUENCE(_the_keys_p_13265)){
            _7225 = SEQ_PTR(_the_keys_p_13265)->length;
    }
    else {
        _7225 = 1;
    }
    if (_7225 != 1)
    goto L1; // [12] 32

    /** 		put( the_map_p, the_keys_p[1], the_value_p, operation_p, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13265);
    _7227 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13264);
    Ref(_7227);
    Ref(_the_value_p_13266);
    _32put(_the_map_p_13264, _7227, _the_value_p_13266, _operation_p_13267, _trigger_p_13268);
    _7227 = NOVALUE;
    goto L2; // [29] 89
L1: 

    /** 		temp_map_ = new_extra( get( the_map_p, the_keys_p[1] ) )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13265);
    _7228 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13264);
    Ref(_7228);
    _7229 = _32get(_the_map_p_13264, _7228, 0);
    _7228 = NOVALUE;
    _0 = _temp_map__13269;
    _temp_map__13269 = _32new_extra(_7229, 690);
    DeRef(_0);
    _7229 = NOVALUE;

    /** 		nested_put( temp_map_, the_keys_p[2..$], the_value_p, operation_p, trigger_p )*/
    if (IS_SEQUENCE(_the_keys_p_13265)){
            _7231 = SEQ_PTR(_the_keys_p_13265)->length;
    }
    else {
        _7231 = 1;
    }
    rhs_slice_target = (object_ptr)&_7232;
    RHS_Slice(_the_keys_p_13265, 2, _7231);
    Ref(_the_value_p_13266);
    DeRef(_7233);
    _7233 = _the_value_p_13266;
    DeRef(_7234);
    _7234 = _operation_p_13267;
    DeRef(_7235);
    _7235 = _trigger_p_13268;
    Ref(_temp_map__13269);
    _32nested_put(_temp_map__13269, _7232, _7233, _7234, _7235);
    _7232 = NOVALUE;
    _7233 = NOVALUE;
    _7234 = NOVALUE;
    _7235 = NOVALUE;

    /** 		put( the_map_p, the_keys_p[1], temp_map_, PUT, trigger_p )*/
    _2 = (int)SEQ_PTR(_the_keys_p_13265);
    _7236 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_the_map_p_13264);
    Ref(_7236);
    Ref(_temp_map__13269);
    _32put(_the_map_p_13264, _7236, _temp_map__13269, 1, _trigger_p_13268);
    _7236 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_the_map_p_13264);
    DeRefDS(_the_keys_p_13265);
    DeRef(_the_value_p_13266);
    DeRef(_temp_map__13269);
    return;
    ;
}


void _32remove(int _the_map_p_13286, int _the_key_p_13287)
{
    int _index__13288 = NOVALUE;
    int _bucket__13289 = NOVALUE;
    int _temp_map__13290 = NOVALUE;
    int _from__13291 = NOVALUE;
    int _calc_hash_1__tmp_at40_13302 = NOVALUE;
    int _calc_hash_inlined_calc_hash_at_40_13301 = NOVALUE;
    int _ret__inlined_calc_hash_at_40_13300 = NOVALUE;
    int _max_hash_p_inlined_calc_hash_at_37_13299 = NOVALUE;
    int _7301 = NOVALUE;
    int _7300 = NOVALUE;
    int _7299 = NOVALUE;
    int _7298 = NOVALUE;
    int _7296 = NOVALUE;
    int _7294 = NOVALUE;
    int _7292 = NOVALUE;
    int _7290 = NOVALUE;
    int _7289 = NOVALUE;
    int _7287 = NOVALUE;
    int _7284 = NOVALUE;
    int _7283 = NOVALUE;
    int _7282 = NOVALUE;
    int _7281 = NOVALUE;
    int _7280 = NOVALUE;
    int _7279 = NOVALUE;
    int _7278 = NOVALUE;
    int _7277 = NOVALUE;
    int _7276 = NOVALUE;
    int _7275 = NOVALUE;
    int _7274 = NOVALUE;
    int _7273 = NOVALUE;
    int _7272 = NOVALUE;
    int _7270 = NOVALUE;
    int _7269 = NOVALUE;
    int _7268 = NOVALUE;
    int _7267 = NOVALUE;
    int _7266 = NOVALUE;
    int _7265 = NOVALUE;
    int _7264 = NOVALUE;
    int _7263 = NOVALUE;
    int _7262 = NOVALUE;
    int _7261 = NOVALUE;
    int _7260 = NOVALUE;
    int _7258 = NOVALUE;
    int _7256 = NOVALUE;
    int _7254 = NOVALUE;
    int _7253 = NOVALUE;
    int _7252 = NOVALUE;
    int _7250 = NOVALUE;
    int _7249 = NOVALUE;
    int _7248 = NOVALUE;
    int _7247 = NOVALUE;
    int _7246 = NOVALUE;
    int _7243 = NOVALUE;
    int _7242 = NOVALUE;
    int _7241 = NOVALUE;
    int _7240 = NOVALUE;
    int _7238 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13290);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_the_map_p_13286)){
        _temp_map__13290 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13286)->dbl));
    }
    else{
        _temp_map__13290 = (int)*(((s1_ptr)_2)->base + _the_map_p_13286);
    }
    Ref(_temp_map__13290);

    /** 	eumem:ram_space[the_map_p] = 0*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13286))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13286)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13286);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7238 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7238, 76)){
        _7238 = NOVALUE;
        goto L1; // [25] 305
    }
    _7238 = NOVALUE;

    /** 		bucket_ = calc_hash(the_key_p, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7240 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7240)){
            _7241 = SEQ_PTR(_7240)->length;
    }
    else {
        _7241 = 1;
    }
    _7240 = NOVALUE;
    _max_hash_p_inlined_calc_hash_at_37_13299 = _7241;
    _7241 = NOVALUE;

    /**     ret_ = hash(key_p, stdhash:HSIEH30)*/
    DeRef(_ret__inlined_calc_hash_at_40_13300);
    _ret__inlined_calc_hash_at_40_13300 = calc_hash(_the_key_p_13287, -6);
    if (!IS_ATOM_INT(_ret__inlined_calc_hash_at_40_13300)) {
        _1 = (long)(DBL_PTR(_ret__inlined_calc_hash_at_40_13300)->dbl);
        DeRefDS(_ret__inlined_calc_hash_at_40_13300);
        _ret__inlined_calc_hash_at_40_13300 = _1;
    }

    /** 	return remainder(ret_, max_hash_p) + 1 -- 1-based*/
    _calc_hash_1__tmp_at40_13302 = (_ret__inlined_calc_hash_at_40_13300 % _max_hash_p_inlined_calc_hash_at_37_13299);
    _bucket__13289 = _calc_hash_1__tmp_at40_13302 + 1;
    DeRef(_ret__inlined_calc_hash_at_40_13300);
    _ret__inlined_calc_hash_at_40_13300 = NOVALUE;
    if (!IS_ATOM_INT(_bucket__13289)) {
        _1 = (long)(DBL_PTR(_bucket__13289)->dbl);
        DeRefDS(_bucket__13289);
        _bucket__13289 = _1;
    }

    /** 		index_ = find(the_key_p, temp_map_[KEY_BUCKETS][bucket_])*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7242 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7242);
    _7243 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7242 = NOVALUE;
    _index__13288 = find_from(_the_key_p_13287, _7243, 1);
    _7243 = NOVALUE;

    /** 		if index_ != 0 then*/
    if (_index__13288 == 0)
    goto L2; // [83] 431

    /** 			temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7246 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7246)) {
        _7247 = _7246 - 1;
        if ((long)((unsigned long)_7247 +(unsigned long) HIGH_BITS) >= 0){
            _7247 = NewDouble((double)_7247);
        }
    }
    else {
        _7247 = binary_op(MINUS, _7246, 1);
    }
    _7246 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7247;
    if( _1 != _7247 ){
        DeRef(_1);
    }
    _7247 = NOVALUE;

    /** 			if length(temp_map_[KEY_BUCKETS][bucket_]) = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7248 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7248);
    _7249 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7248 = NOVALUE;
    if (IS_SEQUENCE(_7249)){
            _7250 = SEQ_PTR(_7249)->length;
    }
    else {
        _7250 = 1;
    }
    _7249 = NOVALUE;
    if (_7250 != 1)
    goto L3; // [114] 157

    /** 				temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7252 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7252)) {
        _7253 = _7252 - 1;
        if ((long)((unsigned long)_7253 +(unsigned long) HIGH_BITS) >= 0){
            _7253 = NewDouble((double)_7253);
        }
    }
    else {
        _7253 = binary_op(MINUS, _7252, 1);
    }
    _7252 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7253;
    if( _1 != _7253 ){
        DeRef(_1);
    }
    _7253 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13289);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7254 = NOVALUE;

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = {}*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    RefDS(_5);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13289);
    _1 = *(int *)_2;
    *(int *)_2 = _5;
    DeRef(_1);
    _7256 = NOVALUE;
    goto L4; // [154] 262
L3: 

    /** 				temp_map_[VALUE_BUCKETS][bucket_] = temp_map_[VALUE_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7260 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7260);
    _7261 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7260 = NOVALUE;
    _7262 = _index__13288 - 1;
    rhs_slice_target = (object_ptr)&_7263;
    RHS_Slice(_7261, 1, _7262);
    _7261 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7264 = (int)*(((s1_ptr)_2)->base + 6);
    _2 = (int)SEQ_PTR(_7264);
    _7265 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7264 = NOVALUE;
    _7266 = _index__13288 + 1;
    if (_7266 > MAXINT){
        _7266 = NewDouble((double)_7266);
    }
    if (IS_SEQUENCE(_7265)){
            _7267 = SEQ_PTR(_7265)->length;
    }
    else {
        _7267 = 1;
    }
    rhs_slice_target = (object_ptr)&_7268;
    RHS_Slice(_7265, _7266, _7267);
    _7265 = NOVALUE;
    Concat((object_ptr)&_7269, _7263, _7268);
    DeRefDS(_7263);
    _7263 = NOVALUE;
    DeRef(_7263);
    _7263 = NOVALUE;
    DeRefDS(_7268);
    _7268 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13289);
    _1 = *(int *)_2;
    *(int *)_2 = _7269;
    if( _1 != _7269 ){
        DeRef(_1);
    }
    _7269 = NOVALUE;
    _7258 = NOVALUE;

    /** 				temp_map_[KEY_BUCKETS][bucket_] = temp_map_[KEY_BUCKETS][bucket_][1 .. index_-1] & */
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7272 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7272);
    _7273 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7272 = NOVALUE;
    _7274 = _index__13288 - 1;
    rhs_slice_target = (object_ptr)&_7275;
    RHS_Slice(_7273, 1, _7274);
    _7273 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7276 = (int)*(((s1_ptr)_2)->base + 5);
    _2 = (int)SEQ_PTR(_7276);
    _7277 = (int)*(((s1_ptr)_2)->base + _bucket__13289);
    _7276 = NOVALUE;
    _7278 = _index__13288 + 1;
    if (_7278 > MAXINT){
        _7278 = NewDouble((double)_7278);
    }
    if (IS_SEQUENCE(_7277)){
            _7279 = SEQ_PTR(_7277)->length;
    }
    else {
        _7279 = 1;
    }
    rhs_slice_target = (object_ptr)&_7280;
    RHS_Slice(_7277, _7278, _7279);
    _7277 = NOVALUE;
    Concat((object_ptr)&_7281, _7275, _7280);
    DeRefDS(_7275);
    _7275 = NOVALUE;
    DeRef(_7275);
    _7275 = NOVALUE;
    DeRefDS(_7280);
    _7280 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bucket__13289);
    _1 = *(int *)_2;
    *(int *)_2 = _7281;
    if( _1 != _7281 ){
        DeRef(_1);
    }
    _7281 = NOVALUE;
    _7270 = NOVALUE;
L4: 

    /** 			if temp_map_[ELEMENT_COUNT] < floor(51 * threshold_size / 100) then*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7282 = (int)*(((s1_ptr)_2)->base + 2);
    _7283 = 1173;
    _7284 = 11;
    _7283 = NOVALUE;
    if (binary_op_a(GREATEREQ, _7282, 11)){
        _7282 = NOVALUE;
        _7284 = NOVALUE;
        goto L2; // [278] 431
    }
    _7282 = NOVALUE;
    DeRef(_7284);
    _7284 = NOVALUE;

    /** 				eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13290);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13286))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13286)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13286);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13290;
    DeRef(_1);

    /** 				convert_to_small_map(the_map_p)*/
    Ref(_the_map_p_13286);
    _32convert_to_small_map(_the_map_p_13286);

    /** 				return*/
    DeRef(_the_map_p_13286);
    DeRef(_the_key_p_13287);
    DeRefDS(_temp_map__13290);
    _7240 = NOVALUE;
    _7249 = NOVALUE;
    DeRef(_7262);
    _7262 = NOVALUE;
    DeRef(_7274);
    _7274 = NOVALUE;
    DeRef(_7266);
    _7266 = NOVALUE;
    DeRef(_7278);
    _7278 = NOVALUE;
    return;
    goto L2; // [302] 431
L1: 

    /** 		from_ = 1*/
    _from__13291 = 1;

    /** 		while from_ > 0 do*/
L5: 
    if (_from__13291 <= 0)
    goto L6; // [315] 430

    /** 			index_ = find(the_key_p, temp_map_[KEY_LIST], from_)*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7287 = (int)*(((s1_ptr)_2)->base + 5);
    _index__13288 = find_from(_the_key_p_13287, _7287, _from__13291);
    _7287 = NOVALUE;

    /** 			if index_ then*/
    if (_index__13288 == 0)
    {
        goto L6; // [332] 430
    }
    else{
    }

    /** 				if temp_map_[FREE_LIST][index_] = 1 then*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7289 = (int)*(((s1_ptr)_2)->base + 7);
    _2 = (int)SEQ_PTR(_7289);
    _7290 = (int)*(((s1_ptr)_2)->base + _index__13288);
    _7289 = NOVALUE;
    if (binary_op_a(NOTEQ, _7290, 1)){
        _7290 = NOVALUE;
        goto L7; // [345] 419
    }
    _7290 = NOVALUE;

    /** 					temp_map_[FREE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(7 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13288);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7292 = NOVALUE;

    /** 					temp_map_[KEY_LIST][index_] = init_small_map_key*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(5 + ((s1_ptr)_2)->base);
    RefDS(_32init_small_map_key_12694);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13288);
    _1 = *(int *)_2;
    *(int *)_2 = _32init_small_map_key_12694;
    DeRef(_1);
    _7294 = NOVALUE;

    /** 					temp_map_[VALUE_LIST][index_] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _3 = (int)(6 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _index__13288);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _7296 = NOVALUE;

    /** 					temp_map_[IN_USE] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7298 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_7298)) {
        _7299 = _7298 - 1;
        if ((long)((unsigned long)_7299 +(unsigned long) HIGH_BITS) >= 0){
            _7299 = NewDouble((double)_7299);
        }
    }
    else {
        _7299 = binary_op(MINUS, _7298, 1);
    }
    _7298 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _7299;
    if( _1 != _7299 ){
        DeRef(_1);
    }
    _7299 = NOVALUE;

    /** 					temp_map_[ELEMENT_COUNT] -= 1*/
    _2 = (int)SEQ_PTR(_temp_map__13290);
    _7300 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_7300)) {
        _7301 = _7300 - 1;
        if ((long)((unsigned long)_7301 +(unsigned long) HIGH_BITS) >= 0){
            _7301 = NewDouble((double)_7301);
        }
    }
    else {
        _7301 = binary_op(MINUS, _7300, 1);
    }
    _7300 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13290);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13290 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _7301;
    if( _1 != _7301 ){
        DeRef(_1);
    }
    _7301 = NOVALUE;
    goto L7; // [411] 419

    /** 				exit*/
    goto L6; // [416] 430
L7: 

    /** 			from_ = index_ + 1*/
    _from__13291 = _index__13288 + 1;

    /** 		end while*/
    goto L5; // [427] 315
L6: 
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13290);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13286))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13286)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13286);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13290;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13286);
    DeRef(_the_key_p_13287);
    DeRefDS(_temp_map__13290);
    _7240 = NOVALUE;
    _7249 = NOVALUE;
    DeRef(_7262);
    _7262 = NOVALUE;
    DeRef(_7274);
    _7274 = NOVALUE;
    DeRef(_7266);
    _7266 = NOVALUE;
    DeRef(_7278);
    _7278 = NOVALUE;
    return;
    ;
}


void _32clear(int _the_map_p_13376)
{
    int _temp_map__13377 = NOVALUE;
    int _7320 = NOVALUE;
    int _7319 = NOVALUE;
    int _7318 = NOVALUE;
    int _7317 = NOVALUE;
    int _7316 = NOVALUE;
    int _7315 = NOVALUE;
    int _7314 = NOVALUE;
    int _7313 = NOVALUE;
    int _7312 = NOVALUE;
    int _7311 = NOVALUE;
    int _7310 = NOVALUE;
    int _7309 = NOVALUE;
    int _7308 = NOVALUE;
    int _7307 = NOVALUE;
    int _7306 = NOVALUE;
    int _7304 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13377);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_the_map_p_13376)){
        _temp_map__13377 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13376)->dbl));
    }
    else{
        _temp_map__13377 = (int)*(((s1_ptr)_2)->base + _the_map_p_13376);
    }
    Ref(_temp_map__13377);

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7304 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7304, 76)){
        _7304 = NOVALUE;
        goto L1; // [17] 70
    }
    _7304 = NOVALUE;

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_BUCKETS] = repeat({}, length(temp_map_[KEY_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7306 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7306)){
            _7307 = SEQ_PTR(_7306)->length;
    }
    else {
        _7307 = 1;
    }
    _7306 = NOVALUE;
    _7308 = Repeat(_5, _7307);
    _7307 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7308;
    if( _1 != _7308 ){
        DeRef(_1);
    }
    _7308 = NOVALUE;

    /** 		temp_map_[VALUE_BUCKETS] = repeat({}, length(temp_map_[VALUE_BUCKETS]))*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7309 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7309)){
            _7310 = SEQ_PTR(_7309)->length;
    }
    else {
        _7310 = 1;
    }
    _7309 = NOVALUE;
    _7311 = Repeat(_5, _7310);
    _7310 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7311;
    if( _1 != _7311 ){
        DeRef(_1);
    }
    _7311 = NOVALUE;
    goto L2; // [67] 134
L1: 

    /** 		temp_map_[ELEMENT_COUNT] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[IN_USE] = 0*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		temp_map_[KEY_LIST] = repeat(init_small_map_key, length(temp_map_[KEY_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7312 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7312)){
            _7313 = SEQ_PTR(_7312)->length;
    }
    else {
        _7313 = 1;
    }
    _7312 = NOVALUE;
    _7314 = Repeat(_32init_small_map_key_12694, _7313);
    _7313 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _7314;
    if( _1 != _7314 ){
        DeRef(_1);
    }
    _7314 = NOVALUE;

    /** 		temp_map_[VALUE_LIST] = repeat(0, length(temp_map_[VALUE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7315 = (int)*(((s1_ptr)_2)->base + 6);
    if (IS_SEQUENCE(_7315)){
            _7316 = SEQ_PTR(_7315)->length;
    }
    else {
        _7316 = 1;
    }
    _7315 = NOVALUE;
    _7317 = Repeat(0, _7316);
    _7316 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _7317;
    if( _1 != _7317 ){
        DeRef(_1);
    }
    _7317 = NOVALUE;

    /** 		temp_map_[FREE_LIST] = repeat(0, length(temp_map_[FREE_LIST]))*/
    _2 = (int)SEQ_PTR(_temp_map__13377);
    _7318 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7318)){
            _7319 = SEQ_PTR(_7318)->length;
    }
    else {
        _7319 = 1;
    }
    _7318 = NOVALUE;
    _7320 = Repeat(0, _7319);
    _7319 = NOVALUE;
    _2 = (int)SEQ_PTR(_temp_map__13377);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _temp_map__13377 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 7);
    _1 = *(int *)_2;
    *(int *)_2 = _7320;
    if( _1 != _7320 ){
        DeRef(_1);
    }
    _7320 = NOVALUE;
L2: 

    /** 	eumem:ram_space[the_map_p] = temp_map_*/
    RefDS(_temp_map__13377);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_the_map_p_13376))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13376)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _the_map_p_13376);
    _1 = *(int *)_2;
    *(int *)_2 = _temp_map__13377;
    DeRef(_1);

    /** end procedure*/
    DeRef(_the_map_p_13376);
    DeRefDS(_temp_map__13377);
    _7306 = NOVALUE;
    _7309 = NOVALUE;
    _7312 = NOVALUE;
    _7315 = NOVALUE;
    _7318 = NOVALUE;
    return;
    ;
}


int _32keys(int _the_map_p_13458, int _sorted_result_13459)
{
    int _buckets__13460 = NOVALUE;
    int _current_bucket__13461 = NOVALUE;
    int _results__13462 = NOVALUE;
    int _pos__13463 = NOVALUE;
    int _temp_map__13464 = NOVALUE;
    int _7378 = NOVALUE;
    int _7376 = NOVALUE;
    int _7375 = NOVALUE;
    int _7373 = NOVALUE;
    int _7372 = NOVALUE;
    int _7371 = NOVALUE;
    int _7370 = NOVALUE;
    int _7368 = NOVALUE;
    int _7367 = NOVALUE;
    int _7366 = NOVALUE;
    int _7365 = NOVALUE;
    int _7363 = NOVALUE;
    int _7361 = NOVALUE;
    int _7358 = NOVALUE;
    int _7356 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13464);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_the_map_p_13458)){
        _temp_map__13464 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13458)->dbl));
    }
    else{
        _temp_map__13464 = (int)*(((s1_ptr)_2)->base + _the_map_p_13458);
    }
    Ref(_temp_map__13464);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13464);
    _7356 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13462);
    _results__13462 = Repeat(0, _7356);
    _7356 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13463 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13464);
    _7358 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7358, 76)){
        _7358 = NOVALUE;
        goto L1; // [34] 113
    }
    _7358 = NOVALUE;

    /** 		buckets_ = temp_map_[KEY_BUCKETS]*/
    DeRef(_buckets__13460);
    _2 = (int)SEQ_PTR(_temp_map__13464);
    _buckets__13460 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_buckets__13460);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13460)){
            _7361 = SEQ_PTR(_buckets__13460)->length;
    }
    else {
        _7361 = 1;
    }
    {
        int _index_13473;
        _index_13473 = 1;
L2: 
        if (_index_13473 > _7361){
            goto L3; // [51] 110
        }

        /** 			current_bucket_ = buckets_[index]*/
        DeRef(_current_bucket__13461);
        _2 = (int)SEQ_PTR(_buckets__13460);
        _current_bucket__13461 = (int)*(((s1_ptr)_2)->base + _index_13473);
        Ref(_current_bucket__13461);

        /** 			if length(current_bucket_) > 0 then*/
        if (IS_SEQUENCE(_current_bucket__13461)){
                _7363 = SEQ_PTR(_current_bucket__13461)->length;
        }
        else {
            _7363 = 1;
        }
        if (_7363 <= 0)
        goto L4; // [71] 103

        /** 				results_[pos_ .. pos_ + length(current_bucket_) - 1] = current_bucket_*/
        if (IS_SEQUENCE(_current_bucket__13461)){
                _7365 = SEQ_PTR(_current_bucket__13461)->length;
        }
        else {
            _7365 = 1;
        }
        _7366 = _pos__13463 + _7365;
        if ((long)((unsigned long)_7366 + (unsigned long)HIGH_BITS) >= 0) 
        _7366 = NewDouble((double)_7366);
        _7365 = NOVALUE;
        if (IS_ATOM_INT(_7366)) {
            _7367 = _7366 - 1;
        }
        else {
            _7367 = NewDouble(DBL_PTR(_7366)->dbl - (double)1);
        }
        DeRef(_7366);
        _7366 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13462;
        AssignSlice(_pos__13463, _7367, _current_bucket__13461);
        DeRef(_7367);
        _7367 = NOVALUE;

        /** 				pos_ += length(current_bucket_)*/
        if (IS_SEQUENCE(_current_bucket__13461)){
                _7368 = SEQ_PTR(_current_bucket__13461)->length;
        }
        else {
            _7368 = 1;
        }
        _pos__13463 = _pos__13463 + _7368;
        _7368 = NOVALUE;
L4: 

        /** 		end for*/
        _index_13473 = _index_13473 + 1;
        goto L2; // [105] 58
L3: 
        ;
    }
    goto L5; // [110] 172
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13464);
    _7370 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7370)){
            _7371 = SEQ_PTR(_7370)->length;
    }
    else {
        _7371 = 1;
    }
    _7370 = NOVALUE;
    {
        int _index_13486;
        _index_13486 = 1;
L6: 
        if (_index_13486 > _7371){
            goto L7; // [122] 171
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13464);
        _7372 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7372);
        _7373 = (int)*(((s1_ptr)_2)->base + _index_13486);
        _7372 = NOVALUE;
        if (binary_op_a(EQUALS, _7373, 0)){
            _7373 = NOVALUE;
            goto L8; // [139] 164
        }
        _7373 = NOVALUE;

        /** 				results_[pos_] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13464);
        _7375 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7375);
        _7376 = (int)*(((s1_ptr)_2)->base + _index_13486);
        _7375 = NOVALUE;
        Ref(_7376);
        _2 = (int)SEQ_PTR(_results__13462);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13462 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13463);
        _1 = *(int *)_2;
        *(int *)_2 = _7376;
        if( _1 != _7376 ){
            DeRef(_1);
        }
        _7376 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13463 = _pos__13463 + 1;
L8: 

        /** 		end for*/
        _index_13486 = _index_13486 + 1;
        goto L6; // [166] 129
L7: 
        ;
    }
L5: 

    /** 	if sorted_result then*/
    if (_sorted_result_13459 == 0)
    {
        goto L9; // [174] 191
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13462);
    _7378 = _25sort(_results__13462, 1);
    DeRef(_the_map_p_13458);
    DeRef(_buckets__13460);
    DeRef(_current_bucket__13461);
    DeRefDS(_results__13462);
    DeRef(_temp_map__13464);
    _7370 = NOVALUE;
    return _7378;
    goto LA; // [188] 198
L9: 

    /** 		return results_*/
    DeRef(_the_map_p_13458);
    DeRef(_buckets__13460);
    DeRef(_current_bucket__13461);
    DeRef(_temp_map__13464);
    _7370 = NOVALUE;
    DeRef(_7378);
    _7378 = NOVALUE;
    return _results__13462;
LA: 
    ;
}


int _32values(int _the_map_13501, int _keys_13502, int _default_values_13503)
{
    int _buckets__13527 = NOVALUE;
    int _bucket__13528 = NOVALUE;
    int _results__13529 = NOVALUE;
    int _pos__13530 = NOVALUE;
    int _temp_map__13531 = NOVALUE;
    int _7418 = NOVALUE;
    int _7417 = NOVALUE;
    int _7415 = NOVALUE;
    int _7414 = NOVALUE;
    int _7413 = NOVALUE;
    int _7412 = NOVALUE;
    int _7410 = NOVALUE;
    int _7409 = NOVALUE;
    int _7408 = NOVALUE;
    int _7407 = NOVALUE;
    int _7405 = NOVALUE;
    int _7403 = NOVALUE;
    int _7400 = NOVALUE;
    int _7398 = NOVALUE;
    int _7396 = NOVALUE;
    int _7395 = NOVALUE;
    int _7394 = NOVALUE;
    int _7393 = NOVALUE;
    int _7391 = NOVALUE;
    int _7390 = NOVALUE;
    int _7389 = NOVALUE;
    int _7388 = NOVALUE;
    int _7387 = NOVALUE;
    int _7386 = NOVALUE;
    int _7384 = NOVALUE;
    int _7383 = NOVALUE;
    int _7381 = NOVALUE;
    int _7380 = NOVALUE;
    int _7379 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(keys) then*/
    _7379 = 0;
    if (_7379 == 0)
    {
        _7379 = NOVALUE;
        goto L1; // [6] 116
    }
    else{
        _7379 = NOVALUE;
    }

    /** 		if atom(default_values) then*/
    _7380 = 1;
    if (_7380 == 0)
    {
        _7380 = NOVALUE;
        goto L2; // [14] 29
    }
    else{
        _7380 = NOVALUE;
    }

    /** 			default_values = repeat(default_values, length(keys))*/
    _7381 = 1;
    _default_values_13503 = Repeat(0, 1);
    _7381 = NOVALUE;
    goto L3; // [26] 70
L2: 

    /** 		elsif length(default_values) < length(keys) then*/
    if (IS_SEQUENCE(_default_values_13503)){
            _7383 = SEQ_PTR(_default_values_13503)->length;
    }
    else {
        _7383 = 1;
    }
    if (IS_SEQUENCE(_keys_13502)){
            _7384 = SEQ_PTR(_keys_13502)->length;
    }
    else {
        _7384 = 1;
    }
    if (_7383 >= _7384)
    goto L4; // [37] 69

    /** 			default_values &= repeat(default_values[$], length(keys) - length(default_values))*/
    if (IS_SEQUENCE(_default_values_13503)){
            _7386 = SEQ_PTR(_default_values_13503)->length;
    }
    else {
        _7386 = 1;
    }
    _2 = (int)SEQ_PTR(_default_values_13503);
    _7387 = (int)*(((s1_ptr)_2)->base + _7386);
    if (IS_SEQUENCE(_keys_13502)){
            _7388 = SEQ_PTR(_keys_13502)->length;
    }
    else {
        _7388 = 1;
    }
    if (IS_SEQUENCE(_default_values_13503)){
            _7389 = SEQ_PTR(_default_values_13503)->length;
    }
    else {
        _7389 = 1;
    }
    _7390 = _7388 - _7389;
    _7388 = NOVALUE;
    _7389 = NOVALUE;
    _7391 = Repeat(_7387, _7390);
    _7387 = NOVALUE;
    _7390 = NOVALUE;
    if (IS_SEQUENCE(_default_values_13503) && IS_ATOM(_7391)) {
    }
    else if (IS_ATOM(_default_values_13503) && IS_SEQUENCE(_7391)) {
        Ref(_default_values_13503);
        Prepend(&_default_values_13503, _7391, _default_values_13503);
    }
    else {
        Concat((object_ptr)&_default_values_13503, _default_values_13503, _7391);
    }
    DeRefDS(_7391);
    _7391 = NOVALUE;
L4: 
L3: 

    /** 		for i = 1 to length(keys) do*/
    if (IS_SEQUENCE(_keys_13502)){
            _7393 = SEQ_PTR(_keys_13502)->length;
    }
    else {
        _7393 = 1;
    }
    {
        int _i_13522;
        _i_13522 = 1;
L5: 
        if (_i_13522 > _7393){
            goto L6; // [75] 109
        }

        /** 			keys[i] = get(the_map, keys[i], default_values[i])*/
        _2 = (int)SEQ_PTR(_keys_13502);
        _7394 = (int)*(((s1_ptr)_2)->base + _i_13522);
        _2 = (int)SEQ_PTR(_default_values_13503);
        _7395 = (int)*(((s1_ptr)_2)->base + _i_13522);
        Ref(_7394);
        Ref(_7395);
        _7396 = _32get(_the_map_13501, _7394, _7395);
        _7394 = NOVALUE;
        _7395 = NOVALUE;
        _2 = (int)SEQ_PTR(_keys_13502);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _keys_13502 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_13522);
        _1 = *(int *)_2;
        *(int *)_2 = _7396;
        if( _1 != _7396 ){
            DeRef(_1);
        }
        _7396 = NOVALUE;

        /** 		end for*/
        _i_13522 = _i_13522 + 1;
        goto L5; // [104] 82
L6: 
        ;
    }

    /** 		return keys*/
    DeRef(_default_values_13503);
    DeRef(_buckets__13527);
    DeRef(_bucket__13528);
    DeRef(_results__13529);
    DeRef(_temp_map__13531);
    return _keys_13502;
L1: 

    /** 	sequence buckets_*/

    /** 	sequence bucket_*/

    /** 	sequence results_*/

    /** 	integer pos_*/

    /** 	sequence temp_map_*/

    /** 	temp_map_ = eumem:ram_space[the_map]*/
    DeRef(_temp_map__13531);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _temp_map__13531 = (int)*(((s1_ptr)_2)->base + _the_map_13501);
    Ref(_temp_map__13531);

    /** 	results_ = repeat(0, temp_map_[ELEMENT_COUNT])*/
    _2 = (int)SEQ_PTR(_temp_map__13531);
    _7398 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13529);
    _results__13529 = Repeat(0, _7398);
    _7398 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13530 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13531);
    _7400 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7400, 76)){
        _7400 = NOVALUE;
        goto L7; // [157] 236
    }
    _7400 = NOVALUE;

    /** 		buckets_ = temp_map_[VALUE_BUCKETS]*/
    DeRef(_buckets__13527);
    _2 = (int)SEQ_PTR(_temp_map__13531);
    _buckets__13527 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_buckets__13527);

    /** 		for index = 1 to length(buckets_) do*/
    if (IS_SEQUENCE(_buckets__13527)){
            _7403 = SEQ_PTR(_buckets__13527)->length;
    }
    else {
        _7403 = 1;
    }
    {
        int _index_13540;
        _index_13540 = 1;
L8: 
        if (_index_13540 > _7403){
            goto L9; // [174] 233
        }

        /** 			bucket_ = buckets_[index]*/
        DeRef(_bucket__13528);
        _2 = (int)SEQ_PTR(_buckets__13527);
        _bucket__13528 = (int)*(((s1_ptr)_2)->base + _index_13540);
        Ref(_bucket__13528);

        /** 			if length(bucket_) > 0 then*/
        if (IS_SEQUENCE(_bucket__13528)){
                _7405 = SEQ_PTR(_bucket__13528)->length;
        }
        else {
            _7405 = 1;
        }
        if (_7405 <= 0)
        goto LA; // [194] 226

        /** 				results_[pos_ .. pos_ + length(bucket_) - 1] = bucket_*/
        if (IS_SEQUENCE(_bucket__13528)){
                _7407 = SEQ_PTR(_bucket__13528)->length;
        }
        else {
            _7407 = 1;
        }
        _7408 = _pos__13530 + _7407;
        if ((long)((unsigned long)_7408 + (unsigned long)HIGH_BITS) >= 0) 
        _7408 = NewDouble((double)_7408);
        _7407 = NOVALUE;
        if (IS_ATOM_INT(_7408)) {
            _7409 = _7408 - 1;
        }
        else {
            _7409 = NewDouble(DBL_PTR(_7408)->dbl - (double)1);
        }
        DeRef(_7408);
        _7408 = NOVALUE;
        assign_slice_seq = (s1_ptr *)&_results__13529;
        AssignSlice(_pos__13530, _7409, _bucket__13528);
        DeRef(_7409);
        _7409 = NOVALUE;

        /** 				pos_ += length(bucket_)*/
        if (IS_SEQUENCE(_bucket__13528)){
                _7410 = SEQ_PTR(_bucket__13528)->length;
        }
        else {
            _7410 = 1;
        }
        _pos__13530 = _pos__13530 + _7410;
        _7410 = NOVALUE;
LA: 

        /** 		end for*/
        _index_13540 = _index_13540 + 1;
        goto L8; // [228] 181
L9: 
        ;
    }
    goto LB; // [233] 295
L7: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13531);
    _7412 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7412)){
            _7413 = SEQ_PTR(_7412)->length;
    }
    else {
        _7413 = 1;
    }
    _7412 = NOVALUE;
    {
        int _index_13553;
        _index_13553 = 1;
LC: 
        if (_index_13553 > _7413){
            goto LD; // [245] 294
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13531);
        _7414 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7414);
        _7415 = (int)*(((s1_ptr)_2)->base + _index_13553);
        _7414 = NOVALUE;
        if (binary_op_a(EQUALS, _7415, 0)){
            _7415 = NOVALUE;
            goto LE; // [262] 287
        }
        _7415 = NOVALUE;

        /** 				results_[pos_] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13531);
        _7417 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7417);
        _7418 = (int)*(((s1_ptr)_2)->base + _index_13553);
        _7417 = NOVALUE;
        Ref(_7418);
        _2 = (int)SEQ_PTR(_results__13529);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13529 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _pos__13530);
        _1 = *(int *)_2;
        *(int *)_2 = _7418;
        if( _1 != _7418 ){
            DeRef(_1);
        }
        _7418 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13530 = _pos__13530 + 1;
LE: 

        /** 		end for*/
        _index_13553 = _index_13553 + 1;
        goto LC; // [289] 252
LD: 
        ;
    }
LB: 

    /** 	return results_*/
    DeRef(_keys_13502);
    DeRef(_default_values_13503);
    DeRef(_buckets__13527);
    DeRef(_bucket__13528);
    DeRef(_temp_map__13531);
    _7412 = NOVALUE;
    return _results__13529;
    ;
}


int _32pairs(int _the_map_p_13565, int _sorted_result_13566)
{
    int _key_bucket__13567 = NOVALUE;
    int _value_bucket__13568 = NOVALUE;
    int _results__13569 = NOVALUE;
    int _pos__13570 = NOVALUE;
    int _temp_map__13571 = NOVALUE;
    int _7454 = NOVALUE;
    int _7452 = NOVALUE;
    int _7451 = NOVALUE;
    int _7449 = NOVALUE;
    int _7448 = NOVALUE;
    int _7447 = NOVALUE;
    int _7445 = NOVALUE;
    int _7443 = NOVALUE;
    int _7442 = NOVALUE;
    int _7441 = NOVALUE;
    int _7440 = NOVALUE;
    int _7438 = NOVALUE;
    int _7436 = NOVALUE;
    int _7435 = NOVALUE;
    int _7433 = NOVALUE;
    int _7432 = NOVALUE;
    int _7430 = NOVALUE;
    int _7428 = NOVALUE;
    int _7427 = NOVALUE;
    int _7426 = NOVALUE;
    int _7424 = NOVALUE;
    int _7422 = NOVALUE;
    int _7421 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	temp_map_ = eumem:ram_space[the_map_p]*/
    DeRef(_temp_map__13571);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_the_map_p_13565)){
        _temp_map__13571 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_the_map_p_13565)->dbl));
    }
    else{
        _temp_map__13571 = (int)*(((s1_ptr)_2)->base + _the_map_p_13565);
    }
    Ref(_temp_map__13571);

    /** 	results_ = repeat({ 0, 0 }, temp_map_[ELEMENT_COUNT])*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _7421 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_temp_map__13571);
    _7422 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_results__13569);
    _results__13569 = Repeat(_7421, _7422);
    DeRefDS(_7421);
    _7421 = NOVALUE;
    _7422 = NOVALUE;

    /** 	pos_ = 1*/
    _pos__13570 = 1;

    /** 	if temp_map_[MAP_TYPE] = LARGEMAP then*/
    _2 = (int)SEQ_PTR(_temp_map__13571);
    _7424 = (int)*(((s1_ptr)_2)->base + 4);
    if (binary_op_a(NOTEQ, _7424, 76)){
        _7424 = NOVALUE;
        goto L1; // [38] 147
    }
    _7424 = NOVALUE;

    /** 		for index = 1 to length(temp_map_[KEY_BUCKETS]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13571);
    _7426 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_SEQUENCE(_7426)){
            _7427 = SEQ_PTR(_7426)->length;
    }
    else {
        _7427 = 1;
    }
    _7426 = NOVALUE;
    {
        int _index_13580;
        _index_13580 = 1;
L2: 
        if (_index_13580 > _7427){
            goto L3; // [51] 144
        }

        /** 			key_bucket_ = temp_map_[KEY_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13571);
        _7428 = (int)*(((s1_ptr)_2)->base + 5);
        DeRef(_key_bucket__13567);
        _2 = (int)SEQ_PTR(_7428);
        _key_bucket__13567 = (int)*(((s1_ptr)_2)->base + _index_13580);
        Ref(_key_bucket__13567);
        _7428 = NOVALUE;

        /** 			value_bucket_ = temp_map_[VALUE_BUCKETS][index]*/
        _2 = (int)SEQ_PTR(_temp_map__13571);
        _7430 = (int)*(((s1_ptr)_2)->base + 6);
        DeRef(_value_bucket__13568);
        _2 = (int)SEQ_PTR(_7430);
        _value_bucket__13568 = (int)*(((s1_ptr)_2)->base + _index_13580);
        Ref(_value_bucket__13568);
        _7430 = NOVALUE;

        /** 			for j = 1 to length(key_bucket_) do*/
        if (IS_SEQUENCE(_key_bucket__13567)){
                _7432 = SEQ_PTR(_key_bucket__13567)->length;
        }
        else {
            _7432 = 1;
        }
        {
            int _j_13588;
            _j_13588 = 1;
L4: 
            if (_j_13588 > _7432){
                goto L5; // [87] 137
            }

            /** 				results_[pos_][1] = key_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13569);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13569 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13570 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_key_bucket__13567);
            _7435 = (int)*(((s1_ptr)_2)->base + _j_13588);
            Ref(_7435);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 1);
            _1 = *(int *)_2;
            *(int *)_2 = _7435;
            if( _1 != _7435 ){
                DeRef(_1);
            }
            _7435 = NOVALUE;
            _7433 = NOVALUE;

            /** 				results_[pos_][2] = value_bucket_[j]*/
            _2 = (int)SEQ_PTR(_results__13569);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _results__13569 = MAKE_SEQ(_2);
            }
            _3 = (int)(_pos__13570 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(_value_bucket__13568);
            _7438 = (int)*(((s1_ptr)_2)->base + _j_13588);
            Ref(_7438);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 2);
            _1 = *(int *)_2;
            *(int *)_2 = _7438;
            if( _1 != _7438 ){
                DeRef(_1);
            }
            _7438 = NOVALUE;
            _7436 = NOVALUE;

            /** 				pos_ += 1*/
            _pos__13570 = _pos__13570 + 1;

            /** 			end for*/
            _j_13588 = _j_13588 + 1;
            goto L4; // [132] 94
L5: 
            ;
        }

        /** 		end for*/
        _index_13580 = _index_13580 + 1;
        goto L2; // [139] 58
L3: 
        ;
    }
    goto L6; // [144] 230
L1: 

    /** 		for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13571);
    _7440 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7440)){
            _7441 = SEQ_PTR(_7440)->length;
    }
    else {
        _7441 = 1;
    }
    _7440 = NOVALUE;
    {
        int _index_13599;
        _index_13599 = 1;
L7: 
        if (_index_13599 > _7441){
            goto L8; // [156] 229
        }

        /** 			if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13571);
        _7442 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7442);
        _7443 = (int)*(((s1_ptr)_2)->base + _index_13599);
        _7442 = NOVALUE;
        if (binary_op_a(EQUALS, _7443, 0)){
            _7443 = NOVALUE;
            goto L9; // [173] 222
        }
        _7443 = NOVALUE;

        /** 				results_[pos_][1] = temp_map_[KEY_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13569);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13569 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13570 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13571);
        _7447 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7447);
        _7448 = (int)*(((s1_ptr)_2)->base + _index_13599);
        _7447 = NOVALUE;
        Ref(_7448);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _7448;
        if( _1 != _7448 ){
            DeRef(_1);
        }
        _7448 = NOVALUE;
        _7445 = NOVALUE;

        /** 				results_[pos_][2] = temp_map_[VALUE_LIST][index]*/
        _2 = (int)SEQ_PTR(_results__13569);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _results__13569 = MAKE_SEQ(_2);
        }
        _3 = (int)(_pos__13570 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_temp_map__13571);
        _7451 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7451);
        _7452 = (int)*(((s1_ptr)_2)->base + _index_13599);
        _7451 = NOVALUE;
        Ref(_7452);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = _7452;
        if( _1 != _7452 ){
            DeRef(_1);
        }
        _7452 = NOVALUE;
        _7449 = NOVALUE;

        /** 				pos_ += 1*/
        _pos__13570 = _pos__13570 + 1;
L9: 

        /** 		end for	*/
        _index_13599 = _index_13599 + 1;
        goto L7; // [224] 163
L8: 
        ;
    }
L6: 

    /** 	if sorted_result then*/
    if (_sorted_result_13566 == 0)
    {
        goto LA; // [232] 249
    }
    else{
    }

    /** 		return stdsort:sort(results_)*/
    RefDS(_results__13569);
    _7454 = _25sort(_results__13569, 1);
    DeRef(_the_map_p_13565);
    DeRef(_key_bucket__13567);
    DeRef(_value_bucket__13568);
    DeRefDS(_results__13569);
    DeRef(_temp_map__13571);
    _7426 = NOVALUE;
    _7440 = NOVALUE;
    return _7454;
    goto LB; // [246] 256
LA: 

    /** 		return results_*/
    DeRef(_the_map_p_13565);
    DeRef(_key_bucket__13567);
    DeRef(_value_bucket__13568);
    DeRef(_temp_map__13571);
    _7426 = NOVALUE;
    _7440 = NOVALUE;
    DeRef(_7454);
    _7454 = NOVALUE;
    return _results__13569;
LB: 
    ;
}


void _32convert_to_large_map(int _the_map__13956)
{
    int _temp_map__13957 = NOVALUE;
    int _map_handle__13958 = NOVALUE;
    int _7657 = NOVALUE;
    int _7656 = NOVALUE;
    int _7655 = NOVALUE;
    int _7654 = NOVALUE;
    int _7653 = NOVALUE;
    int _7651 = NOVALUE;
    int _7650 = NOVALUE;
    int _7649 = NOVALUE;
    int _7648 = NOVALUE;
    int _0, _1, _2;
    

    /** 	temp_map_ = eumem:ram_space[the_map_]*/
    DeRef(_temp_map__13957);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    _temp_map__13957 = (int)*(((s1_ptr)_2)->base + _the_map__13956);
    Ref(_temp_map__13957);

    /** 	map_handle_ = new()*/
    _0 = _map_handle__13958;
    _map_handle__13958 = _32new(690);
    DeRef(_0);

    /** 	for index = 1 to length(temp_map_[FREE_LIST]) do*/
    _2 = (int)SEQ_PTR(_temp_map__13957);
    _7648 = (int)*(((s1_ptr)_2)->base + 7);
    if (IS_SEQUENCE(_7648)){
            _7649 = SEQ_PTR(_7648)->length;
    }
    else {
        _7649 = 1;
    }
    _7648 = NOVALUE;
    {
        int _index_13962;
        _index_13962 = 1;
L1: 
        if (_index_13962 > _7649){
            goto L2; // [28] 84
        }

        /** 		if temp_map_[FREE_LIST][index] !=  0 then*/
        _2 = (int)SEQ_PTR(_temp_map__13957);
        _7650 = (int)*(((s1_ptr)_2)->base + 7);
        _2 = (int)SEQ_PTR(_7650);
        _7651 = (int)*(((s1_ptr)_2)->base + _index_13962);
        _7650 = NOVALUE;
        if (binary_op_a(EQUALS, _7651, 0)){
            _7651 = NOVALUE;
            goto L3; // [45] 77
        }
        _7651 = NOVALUE;

        /** 			put(map_handle_, temp_map_[KEY_LIST][index], temp_map_[VALUE_LIST][index])*/
        _2 = (int)SEQ_PTR(_temp_map__13957);
        _7653 = (int)*(((s1_ptr)_2)->base + 5);
        _2 = (int)SEQ_PTR(_7653);
        _7654 = (int)*(((s1_ptr)_2)->base + _index_13962);
        _7653 = NOVALUE;
        _2 = (int)SEQ_PTR(_temp_map__13957);
        _7655 = (int)*(((s1_ptr)_2)->base + 6);
        _2 = (int)SEQ_PTR(_7655);
        _7656 = (int)*(((s1_ptr)_2)->base + _index_13962);
        _7655 = NOVALUE;
        Ref(_map_handle__13958);
        Ref(_7654);
        Ref(_7656);
        _32put(_map_handle__13958, _7654, _7656, 1, 23);
        _7654 = NOVALUE;
        _7656 = NOVALUE;
L3: 

        /** 	end for*/
        _index_13962 = _index_13962 + 1;
        goto L1; // [79] 35
L2: 
        ;
    }

    /** 	eumem:ram_space[the_map_] = eumem:ram_space[map_handle_]*/
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!IS_ATOM_INT(_map_handle__13958)){
        _7657 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_map_handle__13958)->dbl));
    }
    else{
        _7657 = (int)*(((s1_ptr)_2)->base + _map_handle__13958);
    }
    Ref(_7657);
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__13956);
    _1 = *(int *)_2;
    *(int *)_2 = _7657;
    if( _1 != _7657 ){
        DeRef(_1);
    }
    _7657 = NOVALUE;

    /** end procedure*/
    DeRef(_temp_map__13957);
    DeRef(_map_handle__13958);
    _7648 = NOVALUE;
    return;
    ;
}


void _32convert_to_small_map(int _the_map__13976)
{
    int _keys__13977 = NOVALUE;
    int _values__13978 = NOVALUE;
    int _7666 = NOVALUE;
    int _7665 = NOVALUE;
    int _7664 = NOVALUE;
    int _7663 = NOVALUE;
    int _7662 = NOVALUE;
    int _7661 = NOVALUE;
    int _7660 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_the_map__13976)) {
        _1 = (long)(DBL_PTR(_the_map__13976)->dbl);
        DeRefDS(_the_map__13976);
        _the_map__13976 = _1;
    }

    /** 	keys_ = keys(the_map_)*/
    _0 = _keys__13977;
    _keys__13977 = _32keys(_the_map__13976, 0);
    DeRef(_0);

    /** 	values_ = values(the_map_)*/
    _0 = _values__13978;
    _values__13978 = _32values(_the_map__13976, 0, 0);
    DeRef(_0);

    /** 	eumem:ram_space[the_map_] = {*/
    _7660 = Repeat(_32init_small_map_key_12694, 23);
    _7661 = Repeat(0, 23);
    _7662 = Repeat(0, 23);
    _1 = NewS1(7);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_32type_is_map_12679);
    *((int *)(_2+4)) = _32type_is_map_12679;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 115;
    *((int *)(_2+20)) = _7660;
    *((int *)(_2+24)) = _7661;
    *((int *)(_2+28)) = _7662;
    _7663 = MAKE_SEQ(_1);
    _7662 = NOVALUE;
    _7661 = NOVALUE;
    _7660 = NOVALUE;
    _2 = (int)SEQ_PTR(_33ram_space_11949);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _33ram_space_11949 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _the_map__13976);
    _1 = *(int *)_2;
    *(int *)_2 = _7663;
    if( _1 != _7663 ){
        DeRef(_1);
    }
    _7663 = NOVALUE;

    /** 	for i = 1 to length(keys_) do*/
    if (IS_SEQUENCE(_keys__13977)){
            _7664 = SEQ_PTR(_keys__13977)->length;
    }
    else {
        _7664 = 1;
    }
    {
        int _i_13986;
        _i_13986 = 1;
L1: 
        if (_i_13986 > _7664){
            goto L2; // [63] 94
        }

        /** 		put(the_map_, keys_[i], values_[i], PUT, 0)*/
        _2 = (int)SEQ_PTR(_keys__13977);
        _7665 = (int)*(((s1_ptr)_2)->base + _i_13986);
        _2 = (int)SEQ_PTR(_values__13978);
        _7666 = (int)*(((s1_ptr)_2)->base + _i_13986);
        Ref(_7665);
        Ref(_7666);
        _32put(_the_map__13976, _7665, _7666, 1, 0);
        _7665 = NOVALUE;
        _7666 = NOVALUE;

        /** 	end for*/
        _i_13986 = _i_13986 + 1;
        goto L1; // [89] 70
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_keys__13977);
    DeRef(_values__13978);
    return;
    ;
}



// 0x84F95A79
