// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _30EndLineTable()
{
    int _0, _1, _2;
    

    /** 	LineTable = append(LineTable, -2)*/
    Append(&_12LineTable_11772, _12LineTable_11772, -2);

    /** end procedure*/
    return;
    ;
}


void _30CreateTopLevel()
{
    int _27631 = NOVALUE;
    int _27629 = NOVALUE;
    int _27627 = NOVALUE;
    int _27625 = NOVALUE;
    int _27623 = NOVALUE;
    int _27621 = NOVALUE;
    int _27619 = NOVALUE;
    int _27617 = NOVALUE;
    int _27615 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[TopLevelSub][S_NUM_ARGS] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27615 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_11399))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _27617 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _27619 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_LINETAB] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _27621 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_FIRSTLINE] = 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_11394))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRSTLINE_11394)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FIRSTLINE_11394);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27623 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _27625 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_NREFS] = 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27627 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_RESIDENT_TASK] = 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _27629 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _27631 = NOVALUE;

    /** 	Start_block( PROC, TopLevelSub )*/
    _65Start_block(27, _12TopLevelSub_11689);

    /** end procedure*/
    return;
    ;
}


void _30CheckForUndefinedGotoLabels()
{
    int _27645 = NOVALUE;
    int _27644 = NOVALUE;
    int _27641 = NOVALUE;
    int _27639 = NOVALUE;
    int _27637 = NOVALUE;
    int _27635 = NOVALUE;
    int _27634 = NOVALUE;
    int _27633 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(goto_delay) do*/
    if (IS_SEQUENCE(_12goto_delay_11793)){
            _27633 = SEQ_PTR(_12goto_delay_11793)->length;
    }
    else {
        _27633 = 1;
    }
    {
        int _i_53789;
        _i_53789 = 1;
L1: 
        if (_i_53789 > _27633){
            goto L2; // [8] 104
        }

        /** 		if not equal(goto_delay[i],"") then*/
        _2 = (int)SEQ_PTR(_12goto_delay_11793);
        _27634 = (int)*(((s1_ptr)_2)->base + _i_53789);
        if (_27634 == _21829)
        _27635 = 1;
        else if (IS_ATOM_INT(_27634) && IS_ATOM_INT(_21829))
        _27635 = 0;
        else
        _27635 = (compare(_27634, _21829) == 0);
        _27634 = NOVALUE;
        if (_27635 != 0)
        goto L3; // [27] 97
        _27635 = NOVALUE;

        /** 			line_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_53695);
        _27637 = (int)*(((s1_ptr)_2)->base + _i_53789);
        _2 = (int)SEQ_PTR(_27637);
        _12line_number_11683 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_12line_number_11683)){
            _12line_number_11683 = (long)DBL_PTR(_12line_number_11683)->dbl;
        }
        _27637 = NOVALUE;

        /** 			gline_number = goto_line[i][1] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_53695);
        _27639 = (int)*(((s1_ptr)_2)->base + _i_53789);
        _2 = (int)SEQ_PTR(_27639);
        _12gline_number_11687 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_12gline_number_11687)){
            _12gline_number_11687 = (long)DBL_PTR(_12gline_number_11687)->dbl;
        }
        _27639 = NOVALUE;

        /** 			ThisLine = goto_line[i][2] -- tell compiler the correct line number*/
        _2 = (int)SEQ_PTR(_30goto_line_53695);
        _27641 = (int)*(((s1_ptr)_2)->base + _i_53789);
        DeRef(_43ThisLine_48158);
        _2 = (int)SEQ_PTR(_27641);
        _43ThisLine_48158 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_43ThisLine_48158);
        _27641 = NOVALUE;

        /** 			bp = length(ThisLine)*/
        if (IS_SEQUENCE(_43ThisLine_48158)){
                _43bp_48162 = SEQ_PTR(_43ThisLine_48158)->length;
        }
        else {
            _43bp_48162 = 1;
        }

        /** 				CompileErr(156, {goto_delay[i]})*/
        _2 = (int)SEQ_PTR(_12goto_delay_11793);
        _27644 = (int)*(((s1_ptr)_2)->base + _i_53789);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_27644);
        *((int *)(_2+4)) = _27644;
        _27645 = MAKE_SEQ(_1);
        _27644 = NOVALUE;
        _43CompileErr(156, _27645, 0);
        _27645 = NOVALUE;
L3: 

        /** 	end for*/
        _i_53789 = _i_53789 + 1;
        goto L1; // [99] 15
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _30PushGoto()
{
    int _27646 = NOVALUE;
    int _0, _1, _2;
    

    /** 	goto_stack = append(goto_stack, {goto_addr, goto_list, goto_labels, goto_delay, goto_line, goto_ref, label_block, goto_init })*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_30goto_addr_53697);
    *((int *)(_2+4)) = _30goto_addr_53697;
    RefDS(_12goto_list_11794);
    *((int *)(_2+8)) = _12goto_list_11794;
    RefDS(_30goto_labels_53696);
    *((int *)(_2+12)) = _30goto_labels_53696;
    RefDS(_12goto_delay_11793);
    *((int *)(_2+16)) = _12goto_delay_11793;
    RefDS(_30goto_line_53695);
    *((int *)(_2+20)) = _30goto_line_53695;
    RefDS(_30goto_ref_53699);
    *((int *)(_2+24)) = _30goto_ref_53699;
    RefDS(_30label_block_53700);
    *((int *)(_2+28)) = _30label_block_53700;
    Ref(_30goto_init_53702);
    *((int *)(_2+32)) = _30goto_init_53702;
    _27646 = MAKE_SEQ(_1);
    RefDS(_27646);
    Append(&_30goto_stack_53698, _30goto_stack_53698, _27646);
    DeRefDS(_27646);
    _27646 = NOVALUE;

    /** 	goto_addr = {}*/
    RefDS(_21829);
    DeRefDS(_30goto_addr_53697);
    _30goto_addr_53697 = _21829;

    /** 	goto_list = {}*/
    RefDS(_21829);
    DeRefDS(_12goto_list_11794);
    _12goto_list_11794 = _21829;

    /** 	goto_labels = {}*/
    RefDS(_21829);
    DeRefDS(_30goto_labels_53696);
    _30goto_labels_53696 = _21829;

    /** 	goto_delay = {}*/
    RefDS(_21829);
    DeRefDS(_12goto_delay_11793);
    _12goto_delay_11793 = _21829;

    /** 	goto_line = {}*/
    RefDS(_21829);
    DeRefDS(_30goto_line_53695);
    _30goto_line_53695 = _21829;

    /** 	goto_ref = {}*/
    RefDS(_21829);
    DeRefDS(_30goto_ref_53699);
    _30goto_ref_53699 = _21829;

    /** 	label_block = {}*/
    RefDS(_21829);
    DeRefDS(_30label_block_53700);
    _30label_block_53700 = _21829;

    /** 	goto_init = map:new()*/
    _0 = _32new(690);
    DeRef(_30goto_init_53702);
    _30goto_init_53702 = _0;

    /** end procedure*/
    return;
    ;
}


void _30PopGoto()
{
    int _27673 = NOVALUE;
    int _27671 = NOVALUE;
    int _27670 = NOVALUE;
    int _27668 = NOVALUE;
    int _27667 = NOVALUE;
    int _27665 = NOVALUE;
    int _27664 = NOVALUE;
    int _27662 = NOVALUE;
    int _27661 = NOVALUE;
    int _27659 = NOVALUE;
    int _27658 = NOVALUE;
    int _27656 = NOVALUE;
    int _27655 = NOVALUE;
    int _27653 = NOVALUE;
    int _27652 = NOVALUE;
    int _27650 = NOVALUE;
    int _27649 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CheckForUndefinedGotoLabels()*/
    _30CheckForUndefinedGotoLabels();

    /** 	goto_addr   = goto_stack[$][1]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27649 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27649 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27650 = (int)*(((s1_ptr)_2)->base + _27649);
    DeRef(_30goto_addr_53697);
    _2 = (int)SEQ_PTR(_27650);
    _30goto_addr_53697 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30goto_addr_53697);
    _27650 = NOVALUE;

    /** 	goto_list   = goto_stack[$][2]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27652 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27652 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27653 = (int)*(((s1_ptr)_2)->base + _27652);
    DeRef(_12goto_list_11794);
    _2 = (int)SEQ_PTR(_27653);
    _12goto_list_11794 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_12goto_list_11794);
    _27653 = NOVALUE;

    /** 	goto_labels = goto_stack[$][3]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27655 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27655 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27656 = (int)*(((s1_ptr)_2)->base + _27655);
    DeRef(_30goto_labels_53696);
    _2 = (int)SEQ_PTR(_27656);
    _30goto_labels_53696 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_30goto_labels_53696);
    _27656 = NOVALUE;

    /** 	goto_delay  = goto_stack[$][4]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27658 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27658 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27659 = (int)*(((s1_ptr)_2)->base + _27658);
    DeRef(_12goto_delay_11793);
    _2 = (int)SEQ_PTR(_27659);
    _12goto_delay_11793 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_12goto_delay_11793);
    _27659 = NOVALUE;

    /** 	goto_line   = goto_stack[$][5]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27661 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27661 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27662 = (int)*(((s1_ptr)_2)->base + _27661);
    DeRef(_30goto_line_53695);
    _2 = (int)SEQ_PTR(_27662);
    _30goto_line_53695 = (int)*(((s1_ptr)_2)->base + 5);
    Ref(_30goto_line_53695);
    _27662 = NOVALUE;

    /** 	goto_ref    = goto_stack[$][6]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27664 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27664 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27665 = (int)*(((s1_ptr)_2)->base + _27664);
    DeRef(_30goto_ref_53699);
    _2 = (int)SEQ_PTR(_27665);
    _30goto_ref_53699 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_30goto_ref_53699);
    _27665 = NOVALUE;

    /** 	label_block = goto_stack[$][7]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27667 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27667 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27668 = (int)*(((s1_ptr)_2)->base + _27667);
    DeRef(_30label_block_53700);
    _2 = (int)SEQ_PTR(_27668);
    _30label_block_53700 = (int)*(((s1_ptr)_2)->base + 7);
    Ref(_30label_block_53700);
    _27668 = NOVALUE;

    /** 	goto_init   = goto_stack[$][8]*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27670 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27670 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_stack_53698);
    _27671 = (int)*(((s1_ptr)_2)->base + _27670);
    DeRef(_30goto_init_53702);
    _2 = (int)SEQ_PTR(_27671);
    _30goto_init_53702 = (int)*(((s1_ptr)_2)->base + 8);
    Ref(_30goto_init_53702);
    _27671 = NOVALUE;

    /** 	goto_stack = remove( goto_stack, length( goto_stack ) )*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27673 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27673 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30goto_stack_53698);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_27673)) ? _27673 : (long)(DBL_PTR(_27673)->dbl);
        int stop = (IS_ATOM_INT(_27673)) ? _27673 : (long)(DBL_PTR(_27673)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30goto_stack_53698), start, &_30goto_stack_53698 );
            }
            else Tail(SEQ_PTR(_30goto_stack_53698), stop+1, &_30goto_stack_53698);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30goto_stack_53698), start, &_30goto_stack_53698);
        }
        else {
            assign_slice_seq = &assign_space;
            _30goto_stack_53698 = Remove_elements(start, stop, (SEQ_PTR(_30goto_stack_53698)->ref == 1));
        }
    }
    _27673 = NOVALUE;
    _27673 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30EnterTopLevel(int _end_line_table_53854)
{
    int _27688 = NOVALUE;
    int _27687 = NOVALUE;
    int _27685 = NOVALUE;
    int _27684 = NOVALUE;
    int _27682 = NOVALUE;
    int _27680 = NOVALUE;
    int _27679 = NOVALUE;
    int _27677 = NOVALUE;
    int _27675 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if CurrentSub then*/
    if (_12CurrentSub_11690 == 0)
    {
        goto L1; // [7] 59
    }
    else{
    }

    /** 		if end_line_table then*/
    if (_end_line_table_53854 == 0)
    {
        goto L2; // [12] 58
    }
    else{
    }

    /** 			EndLineTable()*/
    _30EndLineTable();

    /** 			SymTab[CurrentSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_11772);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = _12LineTable_11772;
    DeRef(_1);
    _27675 = NOVALUE;

    /** 			SymTab[CurrentSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _27677 = NOVALUE;
L2: 
L1: 

    /** 	if length(goto_stack) then*/
    if (IS_SEQUENCE(_30goto_stack_53698)){
            _27679 = SEQ_PTR(_30goto_stack_53698)->length;
    }
    else {
        _27679 = 1;
    }
    if (_27679 == 0)
    {
        _27679 = NOVALUE;
        goto L3; // [66] 74
    }
    else{
        _27679 = NOVALUE;
    }

    /** 		PopGoto()*/
    _30PopGoto();
L3: 

    /** 	LineTable = SymTab[TopLevelSub][S_LINETAB]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27680 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    DeRef(_12LineTable_11772);
    _2 = (int)SEQ_PTR(_27680);
    if (!IS_ATOM_INT(_12S_LINETAB_11389)){
        _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    }
    else{
        _12LineTable_11772 = (int)*(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    }
    Ref(_12LineTable_11772);
    _27680 = NOVALUE;

    /** 	Code = SymTab[TopLevelSub][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27682 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    DeRef(_12Code_11771);
    _2 = (int)SEQ_PTR(_27682);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _12Code_11771 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    Ref(_12Code_11771);
    _27682 = NOVALUE;

    /** 	previous_op = -1*/
    _12previous_op_11781 = -1;

    /** 	CurrentSub = TopLevelSub*/
    _12CurrentSub_11690 = _12TopLevelSub_11689;

    /** 	clear_last()*/
    _37clear_last();

    /** 	if length( branch_stack ) then*/
    if (IS_SEQUENCE(_30branch_stack_53684)){
            _27684 = SEQ_PTR(_30branch_stack_53684)->length;
    }
    else {
        _27684 = 1;
    }
    if (_27684 == 0)
    {
        _27684 = NOVALUE;
        goto L4; // [137] 171
    }
    else{
        _27684 = NOVALUE;
    }

    /** 		branch_list = branch_stack[$]*/
    if (IS_SEQUENCE(_30branch_stack_53684)){
            _27685 = SEQ_PTR(_30branch_stack_53684)->length;
    }
    else {
        _27685 = 1;
    }
    DeRef(_30branch_list_53683);
    _2 = (int)SEQ_PTR(_30branch_stack_53684);
    _30branch_list_53683 = (int)*(((s1_ptr)_2)->base + _27685);
    Ref(_30branch_list_53683);

    /** 		branch_stack = tail( branch_stack )*/
    if (IS_SEQUENCE(_30branch_stack_53684)){
            _27687 = SEQ_PTR(_30branch_stack_53684)->length;
    }
    else {
        _27687 = 1;
    }
    _27688 = _27687 - 1;
    _27687 = NOVALUE;
    {
        int len = SEQ_PTR(_30branch_stack_53684)->length;
        int size = (IS_ATOM_INT(_27688)) ? _27688 : (long)(DBL_PTR(_27688)->dbl);
        if (size <= 0) {
            DeRef(_30branch_stack_53684);
            _30branch_stack_53684 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_30branch_stack_53684);
            DeRef(_30branch_stack_53684);
            _30branch_stack_53684 = _30branch_stack_53684;
        }
        else Tail(SEQ_PTR(_30branch_stack_53684), len-size+1, &_30branch_stack_53684);
    }
    _27688 = NOVALUE;
L4: 

    /** end procedure*/
    return;
    ;
}


void _30LeaveTopLevel()
{
    int _27693 = NOVALUE;
    int _27691 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	branch_stack = append( branch_stack, branch_list )*/
    RefDS(_30branch_list_53683);
    Append(&_30branch_stack_53684, _30branch_stack_53684, _30branch_list_53683);

    /** 	branch_list = {}*/
    RefDS(_21829);
    DeRefDS(_30branch_list_53683);
    _30branch_list_53683 = _21829;

    /** 	PushGoto()*/
    _30PushGoto();

    /** 	LastLineNumber = -1*/
    _60LastLineNumber_23568 = -1;

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_11772);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = _12LineTable_11772;
    DeRef(_1);
    _27691 = NOVALUE;

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _27693 = NOVALUE;

    /** 	LineTable = {}*/
    RefDS(_21829);
    DeRefDS(_12LineTable_11772);
    _12LineTable_11772 = _21829;

    /** 	Code = {}*/
    RefDS(_21829);
    DeRefDS(_12Code_11771);
    _12Code_11771 = _21829;

    /** 	previous_op = -1*/
    _12previous_op_11781 = -1;

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    return;
    ;
}


void _30InitParser()
{
    int _0, _1, _2;
    

    /** 	goto_stack = {}*/
    RefDS(_21829);
    DeRef(_30goto_stack_53698);
    _30goto_stack_53698 = _21829;

    /** 	goto_labels = {}*/
    RefDS(_21829);
    DeRef(_30goto_labels_53696);
    _30goto_labels_53696 = _21829;

    /** 	label_block = {}*/
    RefDS(_21829);
    DeRef(_30label_block_53700);
    _30label_block_53700 = _21829;

    /** 	goto_ref = {}*/
    RefDS(_21829);
    DeRef(_30goto_ref_53699);
    _30goto_ref_53699 = _21829;

    /** 	goto_addr = {}*/
    RefDS(_21829);
    DeRef(_30goto_addr_53697);
    _30goto_addr_53697 = _21829;

    /** 	goto_line = {}*/
    RefDS(_21829);
    DeRef(_30goto_line_53695);
    _30goto_line_53695 = _21829;

    /** 	break_list = {}*/
    RefDS(_21829);
    DeRefi(_30break_list_53703);
    _30break_list_53703 = _21829;

    /** 	break_delay = {}*/
    RefDS(_21829);
    DeRef(_30break_delay_53704);
    _30break_delay_53704 = _21829;

    /** 	exit_list = {}*/
    RefDS(_21829);
    DeRefi(_30exit_list_53705);
    _30exit_list_53705 = _21829;

    /** 	exit_delay = {}*/
    RefDS(_21829);
    DeRef(_30exit_delay_53706);
    _30exit_delay_53706 = _21829;

    /** 	continue_list = {}*/
    RefDS(_21829);
    DeRefi(_30continue_list_53707);
    _30continue_list_53707 = _21829;

    /** 	continue_delay = {}*/
    RefDS(_21829);
    DeRef(_30continue_delay_53708);
    _30continue_delay_53708 = _21829;

    /** 	init_stack = {}*/
    RefDS(_21829);
    DeRefi(_30init_stack_53718);
    _30init_stack_53718 = _21829;

    /** 	CurrentSub = 0*/
    _12CurrentSub_11690 = 0;

    /** 	CreateTopLevel()*/
    _30CreateTopLevel();

    /** 	EnterTopLevel()*/
    _30EnterTopLevel(1);

    /** 	backed_up_tok = {}*/
    RefDS(_21829);
    DeRef(_30backed_up_tok_53692);
    _30backed_up_tok_53692 = _21829;

    /** 	loop_stack = {}*/
    RefDS(_21829);
    DeRefi(_30loop_stack_53719);
    _30loop_stack_53719 = _21829;

    /** 	stmt_nest = 0*/
    _30stmt_nest_53717 = 0;

    /** 	loop_labels = {}*/
    RefDS(_21829);
    DeRef(_30loop_labels_53713);
    _30loop_labels_53713 = _21829;

    /** 	if_labels = {}*/
    RefDS(_21829);
    DeRef(_30if_labels_53714);
    _30if_labels_53714 = _21829;

    /** 	if_stack = {}*/
    RefDS(_21829);
    DeRefi(_30if_stack_53720);
    _30if_stack_53720 = _21829;

    /** 	continue_addr = {}*/
    RefDS(_21829);
    DeRefi(_30continue_addr_53710);
    _30continue_addr_53710 = _21829;

    /** 	retry_addr = {}*/
    RefDS(_21829);
    DeRefi(_30retry_addr_53711);
    _30retry_addr_53711 = _21829;

    /** 	entry_addr = {}*/
    RefDS(_21829);
    DeRefi(_30entry_addr_53709);
    _30entry_addr_53709 = _21829;

    /** 	block_list = {}*/
    RefDS(_21829);
    DeRefi(_30block_list_53715);
    _30block_list_53715 = _21829;

    /** 	block_index = 0*/
    _30block_index_53716 = 0;

    /** 	param_num = -1*/
    _30param_num_53694 = -1;

    /** 	entry_stack = {}*/
    RefDS(_21829);
    DeRef(_30entry_stack_53712);
    _30entry_stack_53712 = _21829;

    /** 	goto_init = map:new()*/
    _0 = _32new(690);
    DeRef(_30goto_init_53702);
    _30goto_init_53702 = _0;

    /** end procedure*/
    return;
    ;
}


void _30NotReached(int _tok_53928, int _keyword_53929)
{
    int _27709 = NOVALUE;
    int _27708 = NOVALUE;
    int _27707 = NOVALUE;
    int _27706 = NOVALUE;
    int _27705 = NOVALUE;
    int _27704 = NOVALUE;
    int _27702 = NOVALUE;
    int _27701 = NOVALUE;
    int _27700 = NOVALUE;
    int _27699 = NOVALUE;
    int _27697 = NOVALUE;
    int _27696 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_tok_53928)) {
        _1 = (long)(DBL_PTR(_tok_53928)->dbl);
        DeRefDS(_tok_53928);
        _tok_53928 = _1;
    }

    /** 	if not find(tok, {END, ELSE, ELSIF, END_OF_FILE, CASE, IFDEF, ELSIFDEF, ELSEDEF}) then*/
    _1 = NewS1(8);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 402;
    *((int *)(_2+8)) = 23;
    *((int *)(_2+12)) = 414;
    *((int *)(_2+16)) = -21;
    *((int *)(_2+20)) = 186;
    *((int *)(_2+24)) = 407;
    *((int *)(_2+28)) = 408;
    *((int *)(_2+32)) = 409;
    _27696 = MAKE_SEQ(_1);
    _27697 = find_from(_tok_53928, _27696, 1);
    DeRefDS(_27696);
    _27696 = NOVALUE;
    if (_27697 != 0)
    goto L1; // [39] 135
    _27697 = NOVALUE;

    /** 		if equal(keyword, "goto") and find(tok, {LOOP, LABEL, WHILE}) then*/
    if (_keyword_53929 == _26065)
    _27699 = 1;
    else if (IS_ATOM_INT(_keyword_53929) && IS_ATOM_INT(_26065))
    _27699 = 0;
    else
    _27699 = (compare(_keyword_53929, _26065) == 0);
    if (_27699 == 0) {
        goto L2; // [48] 79
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 422;
    *((int *)(_2+8)) = 419;
    *((int *)(_2+12)) = 47;
    _27701 = MAKE_SEQ(_1);
    _27702 = find_from(_tok_53928, _27701, 1);
    DeRefDS(_27701);
    _27701 = NOVALUE;
    if (_27702 == 0)
    {
        _27702 = NOVALUE;
        goto L2; // [70] 79
    }
    else{
        _27702 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_53929);
    return;
L2: 

    /** 		if equal(keyword, "abort()") and tok = LABEL then*/
    if (_keyword_53929 == _27703)
    _27704 = 1;
    else if (IS_ATOM_INT(_keyword_53929) && IS_ATOM_INT(_27703))
    _27704 = 0;
    else
    _27704 = (compare(_keyword_53929, _27703) == 0);
    if (_27704 == 0) {
        goto L3; // [85] 105
    }
    _27706 = (_tok_53928 == 419);
    if (_27706 == 0)
    {
        DeRef(_27706);
        _27706 = NOVALUE;
        goto L3; // [96] 105
    }
    else{
        DeRef(_27706);
        _27706 = NOVALUE;
    }

    /** 			return*/
    DeRefDSi(_keyword_53929);
    return;
L3: 

    /** 		Warning(218, not_reached_warning_flag,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _27707 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_27707);
    _27708 = _52name_ext(_27707);
    _27707 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _27708;
    *((int *)(_2+8)) = _12line_number_11683;
    RefDS(_keyword_53929);
    *((int *)(_2+12)) = _keyword_53929;
    _27709 = MAKE_SEQ(_1);
    _27708 = NOVALUE;
    _43Warning(218, 512, _27709);
    _27709 = NOVALUE;
L1: 

    /** end procedure*/
    DeRefDSi(_keyword_53929);
    return;
    ;
}


void _30Forward_InitCheck(int _tok_53968, int _ref_53969)
{
    int _sym_53971 = NOVALUE;
    int _27715 = NOVALUE;
    int _27714 = NOVALUE;
    int _27713 = NOVALUE;
    int _27711 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if ref then*/
    if (_ref_53969 == 0)
    {
        goto L1; // [5] 83
    }
    else{
    }

    /** 		integer sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_53968);
    _sym_53971 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_53971)){
        _sym_53971 = (long)DBL_PTR(_sym_53971)->dbl;
    }

    /** 		if tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_53968);
    _27711 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27711, 512)){
        _27711 = NOVALUE;
        goto L2; // [28] 50
    }
    _27711 = NOVALUE;

    /** 			set_qualified_fwd( SymTab[sym][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27713 = (int)*(((s1_ptr)_2)->base + _sym_53971);
    _2 = (int)SEQ_PTR(_27713);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _27714 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _27714 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _27713 = NOVALUE;
    Ref(_27714);
    _60set_qualified_fwd(_27714);
    _27714 = NOVALUE;
L2: 

    /** 		ref = new_forward_reference( GLOBAL_INIT_CHECK, tok[T_SYM], GLOBAL_INIT_CHECK )*/
    _2 = (int)SEQ_PTR(_tok_53968);
    _27715 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_27715);
    _ref_53969 = _29new_forward_reference(109, _27715, 109);
    _27715 = NOVALUE;
    if (!IS_ATOM_INT(_ref_53969)) {
        _1 = (long)(DBL_PTR(_ref_53969)->dbl);
        DeRefDS(_ref_53969);
        _ref_53969 = _1;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _37emit_op(109);

    /** 		emit_addr( sym )*/
    _37emit_addr(_sym_53971);
L1: 

    /** end procedure*/
    DeRef(_tok_53968);
    return;
    ;
}


void _30InitCheck(int _sym_53996, int _ref_53997)
{
    int _27792 = NOVALUE;
    int _27791 = NOVALUE;
    int _27790 = NOVALUE;
    int _27789 = NOVALUE;
    int _27788 = NOVALUE;
    int _27787 = NOVALUE;
    int _27786 = NOVALUE;
    int _27785 = NOVALUE;
    int _27783 = NOVALUE;
    int _27781 = NOVALUE;
    int _27780 = NOVALUE;
    int _27778 = NOVALUE;
    int _27777 = NOVALUE;
    int _27776 = NOVALUE;
    int _27775 = NOVALUE;
    int _27774 = NOVALUE;
    int _27773 = NOVALUE;
    int _27772 = NOVALUE;
    int _27771 = NOVALUE;
    int _27770 = NOVALUE;
    int _27769 = NOVALUE;
    int _27768 = NOVALUE;
    int _27767 = NOVALUE;
    int _27766 = NOVALUE;
    int _27765 = NOVALUE;
    int _27763 = NOVALUE;
    int _27762 = NOVALUE;
    int _27761 = NOVALUE;
    int _27760 = NOVALUE;
    int _27759 = NOVALUE;
    int _27758 = NOVALUE;
    int _27757 = NOVALUE;
    int _27756 = NOVALUE;
    int _27755 = NOVALUE;
    int _27753 = NOVALUE;
    int _27752 = NOVALUE;
    int _27751 = NOVALUE;
    int _27750 = NOVALUE;
    int _27749 = NOVALUE;
    int _27748 = NOVALUE;
    int _27747 = NOVALUE;
    int _27746 = NOVALUE;
    int _27745 = NOVALUE;
    int _27744 = NOVALUE;
    int _27743 = NOVALUE;
    int _27742 = NOVALUE;
    int _27741 = NOVALUE;
    int _27740 = NOVALUE;
    int _27739 = NOVALUE;
    int _27738 = NOVALUE;
    int _27737 = NOVALUE;
    int _27736 = NOVALUE;
    int _27735 = NOVALUE;
    int _27734 = NOVALUE;
    int _27733 = NOVALUE;
    int _27732 = NOVALUE;
    int _27730 = NOVALUE;
    int _27729 = NOVALUE;
    int _27728 = NOVALUE;
    int _27727 = NOVALUE;
    int _27726 = NOVALUE;
    int _27725 = NOVALUE;
    int _27724 = NOVALUE;
    int _27723 = NOVALUE;
    int _27722 = NOVALUE;
    int _27721 = NOVALUE;
    int _27720 = NOVALUE;
    int _27719 = NOVALUE;
    int _27717 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sym < 0 or (SymTab[sym][S_MODE] = M_NORMAL and*/
    _27717 = (_sym_53996 < 0);
    if (_27717 != 0) {
        goto L1; // [11] 90
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27719 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27719);
    _27720 = (int)*(((s1_ptr)_2)->base + 3);
    _27719 = NOVALUE;
    if (IS_ATOM_INT(_27720)) {
        _27721 = (_27720 == 1);
    }
    else {
        _27721 = binary_op(EQUALS, _27720, 1);
    }
    _27720 = NOVALUE;
    if (IS_ATOM_INT(_27721)) {
        if (_27721 == 0) {
            _27722 = 0;
            goto L2; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_27721)->dbl == 0.0) {
            _27722 = 0;
            goto L2; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27723 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27723);
    _27724 = (int)*(((s1_ptr)_2)->base + 4);
    _27723 = NOVALUE;
    if (IS_ATOM_INT(_27724)) {
        _27725 = (_27724 != 2);
    }
    else {
        _27725 = binary_op(NOTEQ, _27724, 2);
    }
    _27724 = NOVALUE;
    DeRef(_27722);
    if (IS_ATOM_INT(_27725))
    _27722 = (_27725 != 0);
    else
    _27722 = DBL_PTR(_27725)->dbl != 0.0;
L2: 
    if (_27722 == 0) {
        DeRef(_27726);
        _27726 = 0;
        goto L3; // [59] 85
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27727 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27727);
    _27728 = (int)*(((s1_ptr)_2)->base + 4);
    _27727 = NOVALUE;
    if (IS_ATOM_INT(_27728)) {
        _27729 = (_27728 != 4);
    }
    else {
        _27729 = binary_op(NOTEQ, _27728, 4);
    }
    _27728 = NOVALUE;
    if (IS_ATOM_INT(_27729))
    _27726 = (_27729 != 0);
    else
    _27726 = DBL_PTR(_27729)->dbl != 0.0;
L3: 
    if (_27726 == 0)
    {
        _27726 = NOVALUE;
        goto L4; // [86] 502
    }
    else{
        _27726 = NOVALUE;
    }
L1: 

    /** 		if sym < 0 or ((SymTab[sym][S_SCOPE] != SC_PRIVATE and*/
    _27730 = (_sym_53996 < 0);
    if (_27730 != 0) {
        goto L5; // [96] 213
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27732 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27732);
    _27733 = (int)*(((s1_ptr)_2)->base + 4);
    _27732 = NOVALUE;
    if (IS_ATOM_INT(_27733)) {
        _27734 = (_27733 != 3);
    }
    else {
        _27734 = binary_op(NOTEQ, _27733, 3);
    }
    _27733 = NOVALUE;
    if (IS_ATOM_INT(_27734)) {
        if (_27734 == 0) {
            DeRef(_27735);
            _27735 = 0;
            goto L6; // [118] 144
        }
    }
    else {
        if (DBL_PTR(_27734)->dbl == 0.0) {
            DeRef(_27735);
            _27735 = 0;
            goto L6; // [118] 144
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27736 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27736);
    _27737 = (int)*(((s1_ptr)_2)->base + 1);
    _27736 = NOVALUE;
    if (_27737 == _12NOVALUE_11536)
    _27738 = 1;
    else if (IS_ATOM_INT(_27737) && IS_ATOM_INT(_12NOVALUE_11536))
    _27738 = 0;
    else
    _27738 = (compare(_27737, _12NOVALUE_11536) == 0);
    _27737 = NOVALUE;
    DeRef(_27735);
    _27735 = (_27738 != 0);
L6: 
    if (_27735 != 0) {
        DeRef(_27739);
        _27739 = 1;
        goto L7; // [144] 208
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27740 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27740);
    _27741 = (int)*(((s1_ptr)_2)->base + 4);
    _27740 = NOVALUE;
    if (IS_ATOM_INT(_27741)) {
        _27742 = (_27741 == 3);
    }
    else {
        _27742 = binary_op(EQUALS, _27741, 3);
    }
    _27741 = NOVALUE;
    if (IS_ATOM_INT(_27742)) {
        if (_27742 == 0) {
            DeRef(_27743);
            _27743 = 0;
            goto L8; // [166] 204
        }
    }
    else {
        if (DBL_PTR(_27742)->dbl == 0.0) {
            DeRef(_27743);
            _27743 = 0;
            goto L8; // [166] 204
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27744 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27744);
    _27745 = (int)*(((s1_ptr)_2)->base + 16);
    _27744 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27746 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_27746);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _27747 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _27747 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _27746 = NOVALUE;
    if (IS_ATOM_INT(_27745) && IS_ATOM_INT(_27747)) {
        _27748 = (_27745 >= _27747);
    }
    else {
        _27748 = binary_op(GREATEREQ, _27745, _27747);
    }
    _27745 = NOVALUE;
    _27747 = NOVALUE;
    DeRef(_27743);
    if (IS_ATOM_INT(_27748))
    _27743 = (_27748 != 0);
    else
    _27743 = DBL_PTR(_27748)->dbl != 0.0;
L8: 
    DeRef(_27739);
    _27739 = (_27743 != 0);
L7: 
    if (_27739 == 0)
    {
        _27739 = NOVALUE;
        goto L9; // [209] 566
    }
    else{
        _27739 = NOVALUE;
    }
L5: 

    /** 			if sym < 0 or (SymTab[sym][S_INITLEVEL] = -1)*/
    _27749 = (_sym_53996 < 0);
    if (_27749 != 0) {
        _27750 = 1;
        goto LA; // [219] 243
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27751 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27751);
    _27752 = (int)*(((s1_ptr)_2)->base + 14);
    _27751 = NOVALUE;
    if (IS_ATOM_INT(_27752)) {
        _27753 = (_27752 == -1);
    }
    else {
        _27753 = binary_op(EQUALS, _27752, -1);
    }
    _27752 = NOVALUE;
    if (IS_ATOM_INT(_27753))
    _27750 = (_27753 != 0);
    else
    _27750 = DBL_PTR(_27753)->dbl != 0.0;
LA: 
    if (_27750 != 0) {
        goto LB; // [243] 270
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27755 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27755);
    _27756 = (int)*(((s1_ptr)_2)->base + 4);
    _27755 = NOVALUE;
    if (IS_ATOM_INT(_27756)) {
        _27757 = (_27756 != 3);
    }
    else {
        _27757 = binary_op(NOTEQ, _27756, 3);
    }
    _27756 = NOVALUE;
    if (_27757 == 0) {
        DeRef(_27757);
        _27757 = NOVALUE;
        goto L9; // [266] 566
    }
    else {
        if (!IS_ATOM_INT(_27757) && DBL_PTR(_27757)->dbl == 0.0){
            DeRef(_27757);
            _27757 = NOVALUE;
            goto L9; // [266] 566
        }
        DeRef(_27757);
        _27757 = NOVALUE;
    }
    DeRef(_27757);
    _27757 = NOVALUE;
LB: 

    /** 				if ref then*/
    if (_ref_53997 == 0)
    {
        goto LC; // [272] 375
    }
    else{
    }

    /** 					if sym > 0 and (SymTab[sym][S_SCOPE] = SC_UNDEFINED) then*/
    _27758 = (_sym_53996 > 0);
    if (_27758 == 0) {
        goto LD; // [281] 317
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27760 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27760);
    _27761 = (int)*(((s1_ptr)_2)->base + 4);
    _27760 = NOVALUE;
    if (IS_ATOM_INT(_27761)) {
        _27762 = (_27761 == 9);
    }
    else {
        _27762 = binary_op(EQUALS, _27761, 9);
    }
    _27761 = NOVALUE;
    if (_27762 == 0) {
        DeRef(_27762);
        _27762 = NOVALUE;
        goto LD; // [304] 317
    }
    else {
        if (!IS_ATOM_INT(_27762) && DBL_PTR(_27762)->dbl == 0.0){
            DeRef(_27762);
            _27762 = NOVALUE;
            goto LD; // [304] 317
        }
        DeRef(_27762);
        _27762 = NOVALUE;
    }
    DeRef(_27762);
    _27762 = NOVALUE;

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _37emit_op(30);
    goto LE; // [314] 369
LD: 

    /** 					elsif sym < 0 or find(SymTab[sym][S_SCOPE], SCOPE_TYPES) then*/
    _27763 = (_sym_53996 < 0);
    if (_27763 != 0) {
        goto LF; // [323] 351
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27765 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27765);
    _27766 = (int)*(((s1_ptr)_2)->base + 4);
    _27765 = NOVALUE;
    _27767 = find_from(_27766, _30SCOPE_TYPES_53676, 1);
    _27766 = NOVALUE;
    if (_27767 == 0)
    {
        _27767 = NOVALUE;
        goto L10; // [347] 361
    }
    else{
        _27767 = NOVALUE;
    }
LF: 

    /** 						emit_op(GLOBAL_INIT_CHECK) -- will become NOP2*/
    _37emit_op(109);
    goto LE; // [358] 369
L10: 

    /** 						emit_op(PRIVATE_INIT_CHECK)*/
    _37emit_op(30);
LE: 

    /** 					emit_addr(sym)*/
    _37emit_addr(_sym_53996);
LC: 

    /** 				if sym > 0 */
    _27768 = (_sym_53996 > 0);
    if (_27768 == 0) {
        _27769 = 0;
        goto L11; // [381] 411
    }
    _27770 = (_30short_circuit_53685 <= 0);
    if (_27770 != 0) {
        _27771 = 1;
        goto L12; // [391] 407
    }
    _27772 = (_30short_circuit_B_53687 == _9FALSE_429);
    _27771 = (_27772 != 0);
L12: 
    _27769 = (_27771 != 0);
L11: 
    if (_27769 == 0) {
        goto L9; // [411] 566
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27774 = (int)*(((s1_ptr)_2)->base + _sym_53996);
    _2 = (int)SEQ_PTR(_27774);
    _27775 = (int)*(((s1_ptr)_2)->base + 4);
    _27774 = NOVALUE;
    if (IS_ATOM_INT(_27775)) {
        _27776 = (_27775 != 3);
    }
    else {
        _27776 = binary_op(NOTEQ, _27775, 3);
    }
    _27775 = NOVALUE;
    if (IS_ATOM_INT(_27776)) {
        _27777 = (_27776 == 0);
    }
    else {
        _27777 = unary_op(NOT, _27776);
    }
    DeRef(_27776);
    _27776 = NOVALUE;
    if (_27777 == 0) {
        DeRef(_27777);
        _27777 = NOVALUE;
        goto L9; // [437] 566
    }
    else {
        if (!IS_ATOM_INT(_27777) && DBL_PTR(_27777)->dbl == 0.0){
            DeRef(_27777);
            _27777 = NOVALUE;
            goto L9; // [437] 566
        }
        DeRef(_27777);
        _27777 = NOVALUE;
    }
    DeRef(_27777);
    _27777 = NOVALUE;

    /** 					if CurrentSub != TopLevelSub */
    _27778 = (_12CurrentSub_11690 != _12TopLevelSub_11689);
    if (_27778 != 0) {
        goto L13; // [450] 470
    }
    if (IS_SEQUENCE(_13known_files_10637)){
            _27780 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _27780 = 1;
    }
    _27781 = (_12current_file_no_11682 == _27780);
    _27780 = NOVALUE;
    if (_27781 == 0)
    {
        DeRef(_27781);
        _27781 = NOVALUE;
        goto L9; // [466] 566
    }
    else{
        DeRef(_27781);
        _27781 = NOVALUE;
    }
L13: 

    /** 						init_stack = append(init_stack, sym)*/
    Append(&_30init_stack_53718, _30init_stack_53718, _sym_53996);

    /** 						SymTab[sym][S_INITLEVEL] = stmt_nest*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_53996 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = _30stmt_nest_53717;
    DeRef(_1);
    _27783 = NOVALUE;
    goto L9; // [499] 566
L4: 

    /** 	elsif ref and sym > 0 and sym_mode( sym ) = M_CONSTANT and equal( NOVALUE, sym_obj( sym ) ) then*/
    if (_ref_53997 == 0) {
        _27785 = 0;
        goto L14; // [504] 516
    }
    _27786 = (_sym_53996 > 0);
    _27785 = (_27786 != 0);
L14: 
    if (_27785 == 0) {
        _27787 = 0;
        goto L15; // [516] 534
    }
    _27788 = _52sym_mode(_sym_53996);
    if (IS_ATOM_INT(_27788)) {
        _27789 = (_27788 == 2);
    }
    else {
        _27789 = binary_op(EQUALS, _27788, 2);
    }
    DeRef(_27788);
    _27788 = NOVALUE;
    if (IS_ATOM_INT(_27789))
    _27787 = (_27789 != 0);
    else
    _27787 = DBL_PTR(_27789)->dbl != 0.0;
L15: 
    if (_27787 == 0) {
        goto L16; // [534] 565
    }
    _27791 = _52sym_obj(_sym_53996);
    if (_12NOVALUE_11536 == _27791)
    _27792 = 1;
    else if (IS_ATOM_INT(_12NOVALUE_11536) && IS_ATOM_INT(_27791))
    _27792 = 0;
    else
    _27792 = (compare(_12NOVALUE_11536, _27791) == 0);
    DeRef(_27791);
    _27791 = NOVALUE;
    if (_27792 == 0)
    {
        _27792 = NOVALUE;
        goto L16; // [549] 565
    }
    else{
        _27792 = NOVALUE;
    }

    /** 		emit_op( GLOBAL_INIT_CHECK )*/
    _37emit_op(109);

    /** 		emit_addr(sym)*/
    _37emit_addr(_sym_53996);
L16: 
L9: 

    /** end procedure*/
    DeRef(_27717);
    _27717 = NOVALUE;
    DeRef(_27730);
    _27730 = NOVALUE;
    DeRef(_27721);
    _27721 = NOVALUE;
    DeRef(_27725);
    _27725 = NOVALUE;
    DeRef(_27729);
    _27729 = NOVALUE;
    DeRef(_27749);
    _27749 = NOVALUE;
    DeRef(_27734);
    _27734 = NOVALUE;
    DeRef(_27742);
    _27742 = NOVALUE;
    DeRef(_27758);
    _27758 = NOVALUE;
    DeRef(_27748);
    _27748 = NOVALUE;
    DeRef(_27753);
    _27753 = NOVALUE;
    DeRef(_27763);
    _27763 = NOVALUE;
    DeRef(_27768);
    _27768 = NOVALUE;
    DeRef(_27770);
    _27770 = NOVALUE;
    DeRef(_27772);
    _27772 = NOVALUE;
    DeRef(_27778);
    _27778 = NOVALUE;
    DeRef(_27786);
    _27786 = NOVALUE;
    DeRef(_27789);
    _27789 = NOVALUE;
    return;
    ;
}


void _30InitDelete()
{
    int _27805 = NOVALUE;
    int _27804 = NOVALUE;
    int _27802 = NOVALUE;
    int _27801 = NOVALUE;
    int _27800 = NOVALUE;
    int _27799 = NOVALUE;
    int _27798 = NOVALUE;
    int _27797 = NOVALUE;
    int _27796 = NOVALUE;
    int _27795 = NOVALUE;
    int _27794 = NOVALUE;
    int _27793 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	while length(init_stack) and*/
L1: 
    if (IS_SEQUENCE(_30init_stack_53718)){
            _27793 = SEQ_PTR(_30init_stack_53718)->length;
    }
    else {
        _27793 = 1;
    }
    if (_27793 == 0) {
        goto L2; // [11] 91
    }
    if (IS_SEQUENCE(_30init_stack_53718)){
            _27795 = SEQ_PTR(_30init_stack_53718)->length;
    }
    else {
        _27795 = 1;
    }
    _2 = (int)SEQ_PTR(_30init_stack_53718);
    _27796 = (int)*(((s1_ptr)_2)->base + _27795);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27797 = (int)*(((s1_ptr)_2)->base + _27796);
    _2 = (int)SEQ_PTR(_27797);
    _27798 = (int)*(((s1_ptr)_2)->base + 14);
    _27797 = NOVALUE;
    if (IS_ATOM_INT(_27798)) {
        _27799 = (_27798 > _30stmt_nest_53717);
    }
    else {
        _27799 = binary_op(GREATER, _27798, _30stmt_nest_53717);
    }
    _27798 = NOVALUE;
    if (_27799 <= 0) {
        if (_27799 == 0) {
            DeRef(_27799);
            _27799 = NOVALUE;
            goto L2; // [43] 91
        }
        else {
            if (!IS_ATOM_INT(_27799) && DBL_PTR(_27799)->dbl == 0.0){
                DeRef(_27799);
                _27799 = NOVALUE;
                goto L2; // [43] 91
            }
            DeRef(_27799);
            _27799 = NOVALUE;
        }
    }
    DeRef(_27799);
    _27799 = NOVALUE;

    /** 		SymTab[init_stack[$]][S_INITLEVEL] = -1*/
    if (IS_SEQUENCE(_30init_stack_53718)){
            _27800 = SEQ_PTR(_30init_stack_53718)->length;
    }
    else {
        _27800 = 1;
    }
    _2 = (int)SEQ_PTR(_30init_stack_53718);
    _27801 = (int)*(((s1_ptr)_2)->base + _27800);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_27801 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);
    _27802 = NOVALUE;

    /** 		init_stack = init_stack[1..$-1]*/
    if (IS_SEQUENCE(_30init_stack_53718)){
            _27804 = SEQ_PTR(_30init_stack_53718)->length;
    }
    else {
        _27804 = 1;
    }
    _27805 = _27804 - 1;
    _27804 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30init_stack_53718;
    RHS_Slice(_30init_stack_53718, 1, _27805);

    /** 	end while*/
    goto L1; // [88] 6
L2: 

    /** end procedure*/
    _27796 = NOVALUE;
    _27801 = NOVALUE;
    DeRef(_27805);
    _27805 = NOVALUE;
    return;
    ;
}


void _30emit_forward_addr()
{
    int _27807 = NOVALUE;
    int _0, _1, _2;
    

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	branch_list = append(branch_list, length(Code))*/
    if (IS_SEQUENCE(_12Code_11771)){
            _27807 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _27807 = 1;
    }
    Append(&_30branch_list_53683, _30branch_list_53683, _27807);
    _27807 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30StraightenBranches()
{
    int _br_54170 = NOVALUE;
    int _target_54171 = NOVALUE;
    int _27828 = NOVALUE;
    int _27827 = NOVALUE;
    int _27826 = NOVALUE;
    int _27825 = NOVALUE;
    int _27823 = NOVALUE;
    int _27822 = NOVALUE;
    int _27821 = NOVALUE;
    int _27819 = NOVALUE;
    int _27818 = NOVALUE;
    int _27817 = NOVALUE;
    int _27816 = NOVALUE;
    int _27814 = NOVALUE;
    int _27811 = NOVALUE;
    int _27810 = NOVALUE;
    int _27809 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [5] 14
    }
    else{
    }

    /** 		return -- do it in back-end*/
    return;
L1: 

    /** 	for i = length(branch_list) to 1 by -1 do*/
    if (IS_SEQUENCE(_30branch_list_53683)){
            _27809 = SEQ_PTR(_30branch_list_53683)->length;
    }
    else {
        _27809 = 1;
    }
    {
        int _i_54175;
        _i_54175 = _27809;
L2: 
        if (_i_54175 < 1){
            goto L3; // [21] 170
        }

        /** 		if branch_list[i] > length(Code) then*/
        _2 = (int)SEQ_PTR(_30branch_list_53683);
        _27810 = (int)*(((s1_ptr)_2)->base + _i_54175);
        if (IS_SEQUENCE(_12Code_11771)){
                _27811 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _27811 = 1;
        }
        if (binary_op_a(LESSEQ, _27810, _27811)){
            _27810 = NOVALUE;
            _27811 = NOVALUE;
            goto L4; // [41] 53
        }
        _27810 = NOVALUE;
        _27811 = NOVALUE;

        /** 			CompileErr("wtf")*/
        RefDS(_27813);
        RefDS(_21829);
        _43CompileErr(_27813, _21829, 0);
L4: 

        /** 		target = Code[branch_list[i]]*/
        _2 = (int)SEQ_PTR(_30branch_list_53683);
        _27814 = (int)*(((s1_ptr)_2)->base + _i_54175);
        _2 = (int)SEQ_PTR(_12Code_11771);
        if (!IS_ATOM_INT(_27814)){
            _target_54171 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27814)->dbl));
        }
        else{
            _target_54171 = (int)*(((s1_ptr)_2)->base + _27814);
        }
        if (!IS_ATOM_INT(_target_54171)){
            _target_54171 = (long)DBL_PTR(_target_54171)->dbl;
        }

        /** 		if target <= length(Code) and target > 0 then*/
        if (IS_SEQUENCE(_12Code_11771)){
                _27816 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _27816 = 1;
        }
        _27817 = (_target_54171 <= _27816);
        _27816 = NOVALUE;
        if (_27817 == 0) {
            goto L5; // [80] 163
        }
        _27819 = (_target_54171 > 0);
        if (_27819 == 0)
        {
            DeRef(_27819);
            _27819 = NOVALUE;
            goto L5; // [89] 163
        }
        else{
            DeRef(_27819);
            _27819 = NOVALUE;
        }

        /** 			br = Code[target]*/
        _2 = (int)SEQ_PTR(_12Code_11771);
        _br_54170 = (int)*(((s1_ptr)_2)->base + _target_54171);
        if (!IS_ATOM_INT(_br_54170)){
            _br_54170 = (long)DBL_PTR(_br_54170)->dbl;
        }

        /** 			if br = ELSE or br = ENDWHILE or br = EXIT then*/
        _27821 = (_br_54170 == 23);
        if (_27821 != 0) {
            _27822 = 1;
            goto L6; // [110] 124
        }
        _27823 = (_br_54170 == 22);
        _27822 = (_27823 != 0);
L6: 
        if (_27822 != 0) {
            goto L7; // [124] 139
        }
        _27825 = (_br_54170 == 61);
        if (_27825 == 0)
        {
            DeRef(_27825);
            _27825 = NOVALUE;
            goto L8; // [135] 162
        }
        else{
            DeRef(_27825);
            _27825 = NOVALUE;
        }
L7: 

        /** 				backpatch(branch_list[i], Code[target+1])*/
        _2 = (int)SEQ_PTR(_30branch_list_53683);
        _27826 = (int)*(((s1_ptr)_2)->base + _i_54175);
        _27827 = _target_54171 + 1;
        _2 = (int)SEQ_PTR(_12Code_11771);
        _27828 = (int)*(((s1_ptr)_2)->base + _27827);
        Ref(_27826);
        Ref(_27828);
        _37backpatch(_27826, _27828);
        _27826 = NOVALUE;
        _27828 = NOVALUE;
L8: 
L5: 

        /** 	end for*/
        _i_54175 = _i_54175 + -1;
        goto L2; // [165] 28
L3: 
        ;
    }

    /** 	branch_list = {}*/
    RefDS(_21829);
    DeRef(_30branch_list_53683);
    _30branch_list_53683 = _21829;

    /** end procedure*/
    _27814 = NOVALUE;
    DeRef(_27817);
    _27817 = NOVALUE;
    DeRef(_27821);
    _27821 = NOVALUE;
    DeRef(_27823);
    _27823 = NOVALUE;
    DeRef(_27827);
    _27827 = NOVALUE;
    return;
    ;
}


void _30PatchEList(int _base_54223)
{
    int _break_top_54224 = NOVALUE;
    int _n_54225 = NOVALUE;
    int _27845 = NOVALUE;
    int _27844 = NOVALUE;
    int _27843 = NOVALUE;
    int _27839 = NOVALUE;
    int _27838 = NOVALUE;
    int _27837 = NOVALUE;
    int _27835 = NOVALUE;
    int _27834 = NOVALUE;
    int _27832 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(break_list) then*/
    if (IS_SEQUENCE(_30break_list_53703)){
            _27832 = SEQ_PTR(_30break_list_53703)->length;
    }
    else {
        _27832 = 1;
    }
    if (_27832 != 0)
    goto L1; // [10] 19
    _27832 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	break_top = 0*/
    _break_top_54224 = 0;

    /** 	for i=length(break_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30break_list_53703)){
            _27834 = SEQ_PTR(_30break_list_53703)->length;
    }
    else {
        _27834 = 1;
    }
    _27835 = _base_54223 + 1;
    if (_27835 > MAXINT){
        _27835 = NewDouble((double)_27835);
    }
    {
        int _i_54230;
        _i_54230 = _27834;
L2: 
        if (binary_op_a(LESS, _i_54230, _27835)){
            goto L3; // [35] 129
        }

        /** 		n=break_delay[i]*/
        _2 = (int)SEQ_PTR(_30break_delay_53704);
        if (!IS_ATOM_INT(_i_54230)){
            _n_54225 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54230)->dbl));
        }
        else{
            _n_54225 = (int)*(((s1_ptr)_2)->base + _i_54230);
        }
        if (!IS_ATOM_INT(_n_54225))
        _n_54225 = (long)DBL_PTR(_n_54225)->dbl;

        /** 		break_delay[i] -= (n>0)*/
        _27837 = (_n_54225 > 0);
        _2 = (int)SEQ_PTR(_30break_delay_53704);
        if (!IS_ATOM_INT(_i_54230)){
            _27838 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54230)->dbl));
        }
        else{
            _27838 = (int)*(((s1_ptr)_2)->base + _i_54230);
        }
        if (IS_ATOM_INT(_27838)) {
            _27839 = _27838 - _27837;
            if ((long)((unsigned long)_27839 +(unsigned long) HIGH_BITS) >= 0){
                _27839 = NewDouble((double)_27839);
            }
        }
        else {
            _27839 = binary_op(MINUS, _27838, _27837);
        }
        _27838 = NOVALUE;
        _27837 = NOVALUE;
        _2 = (int)SEQ_PTR(_30break_delay_53704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30break_delay_53704 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54230))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54230)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54230);
        _1 = *(int *)_2;
        *(int *)_2 = _27839;
        if( _1 != _27839 ){
            DeRef(_1);
        }
        _27839 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54225 <= 1)
        goto L4; // [72] 93

        /** 			if break_top = 0 then*/
        if (_break_top_54224 != 0)
        goto L5; // [78] 122

        /** 				break_top = i*/
        Ref(_i_54230);
        _break_top_54224 = _i_54230;
        if (!IS_ATOM_INT(_break_top_54224)) {
            _1 = (long)(DBL_PTR(_break_top_54224)->dbl);
            DeRefDS(_break_top_54224);
            _break_top_54224 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54225 != 1)
        goto L6; // [95] 121

        /** 			backpatch(break_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30break_list_53703);
        if (!IS_ATOM_INT(_i_54230)){
            _27843 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54230)->dbl));
        }
        else{
            _27843 = (int)*(((s1_ptr)_2)->base + _i_54230);
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _27844 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _27844 = 1;
        }
        _27845 = _27844 + 1;
        _27844 = NOVALUE;
        _37backpatch(_27843, _27845);
        _27843 = NOVALUE;
        _27845 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54230;
        if (IS_ATOM_INT(_i_54230)) {
            _i_54230 = _i_54230 + -1;
            if ((long)((unsigned long)_i_54230 +(unsigned long) HIGH_BITS) >= 0){
                _i_54230 = NewDouble((double)_i_54230);
            }
        }
        else {
            _i_54230 = binary_op_a(PLUS, _i_54230, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54230);
    }

    /** 	if break_top=0 then*/
    if (_break_top_54224 != 0)
    goto L7; // [131] 141

    /** 	    break_top=base*/
    _break_top_54224 = _base_54223;
L7: 

    /** 	break_delay = break_delay[1..break_top]*/
    rhs_slice_target = (object_ptr)&_30break_delay_53704;
    RHS_Slice(_30break_delay_53704, 1, _break_top_54224);

    /** 	break_list = break_list[1..break_top]*/
    rhs_slice_target = (object_ptr)&_30break_list_53703;
    RHS_Slice(_30break_list_53703, 1, _break_top_54224);

    /** end procedure*/
    DeRef(_27835);
    _27835 = NOVALUE;
    return;
    ;
}


void _30PatchNList(int _base_54254)
{
    int _next_top_54255 = NOVALUE;
    int _n_54256 = NOVALUE;
    int _27862 = NOVALUE;
    int _27861 = NOVALUE;
    int _27860 = NOVALUE;
    int _27856 = NOVALUE;
    int _27855 = NOVALUE;
    int _27854 = NOVALUE;
    int _27852 = NOVALUE;
    int _27851 = NOVALUE;
    int _27849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(continue_list) then*/
    if (IS_SEQUENCE(_30continue_list_53707)){
            _27849 = SEQ_PTR(_30continue_list_53707)->length;
    }
    else {
        _27849 = 1;
    }
    if (_27849 != 0)
    goto L1; // [10] 19
    _27849 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	next_top = 0*/
    _next_top_54255 = 0;

    /** 	for i=length(continue_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30continue_list_53707)){
            _27851 = SEQ_PTR(_30continue_list_53707)->length;
    }
    else {
        _27851 = 1;
    }
    _27852 = _base_54254 + 1;
    if (_27852 > MAXINT){
        _27852 = NewDouble((double)_27852);
    }
    {
        int _i_54261;
        _i_54261 = _27851;
L2: 
        if (binary_op_a(LESS, _i_54261, _27852)){
            goto L3; // [35] 129
        }

        /** 		n=continue_delay[i]*/
        _2 = (int)SEQ_PTR(_30continue_delay_53708);
        if (!IS_ATOM_INT(_i_54261)){
            _n_54256 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54261)->dbl));
        }
        else{
            _n_54256 = (int)*(((s1_ptr)_2)->base + _i_54261);
        }
        if (!IS_ATOM_INT(_n_54256))
        _n_54256 = (long)DBL_PTR(_n_54256)->dbl;

        /** 		continue_delay[i] -= (n>0)*/
        _27854 = (_n_54256 > 0);
        _2 = (int)SEQ_PTR(_30continue_delay_53708);
        if (!IS_ATOM_INT(_i_54261)){
            _27855 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54261)->dbl));
        }
        else{
            _27855 = (int)*(((s1_ptr)_2)->base + _i_54261);
        }
        if (IS_ATOM_INT(_27855)) {
            _27856 = _27855 - _27854;
            if ((long)((unsigned long)_27856 +(unsigned long) HIGH_BITS) >= 0){
                _27856 = NewDouble((double)_27856);
            }
        }
        else {
            _27856 = binary_op(MINUS, _27855, _27854);
        }
        _27855 = NOVALUE;
        _27854 = NOVALUE;
        _2 = (int)SEQ_PTR(_30continue_delay_53708);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30continue_delay_53708 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54261))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54261)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54261);
        _1 = *(int *)_2;
        *(int *)_2 = _27856;
        if( _1 != _27856 ){
            DeRef(_1);
        }
        _27856 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54256 <= 1)
        goto L4; // [72] 93

        /** 			if next_top = 0 then*/
        if (_next_top_54255 != 0)
        goto L5; // [78] 122

        /** 				next_top = i*/
        Ref(_i_54261);
        _next_top_54255 = _i_54261;
        if (!IS_ATOM_INT(_next_top_54255)) {
            _1 = (long)(DBL_PTR(_next_top_54255)->dbl);
            DeRefDS(_next_top_54255);
            _next_top_54255 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54256 != 1)
        goto L6; // [95] 121

        /** 			backpatch(continue_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30continue_list_53707);
        if (!IS_ATOM_INT(_i_54261)){
            _27860 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54261)->dbl));
        }
        else{
            _27860 = (int)*(((s1_ptr)_2)->base + _i_54261);
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _27861 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _27861 = 1;
        }
        _27862 = _27861 + 1;
        _27861 = NOVALUE;
        _37backpatch(_27860, _27862);
        _27860 = NOVALUE;
        _27862 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54261;
        if (IS_ATOM_INT(_i_54261)) {
            _i_54261 = _i_54261 + -1;
            if ((long)((unsigned long)_i_54261 +(unsigned long) HIGH_BITS) >= 0){
                _i_54261 = NewDouble((double)_i_54261);
            }
        }
        else {
            _i_54261 = binary_op_a(PLUS, _i_54261, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54261);
    }

    /** 	if next_top=0 then*/
    if (_next_top_54255 != 0)
    goto L7; // [131] 141

    /** 	    next_top=base*/
    _next_top_54255 = _base_54254;
L7: 

    /** 	continue_delay =continue_delay[1..next_top]*/
    rhs_slice_target = (object_ptr)&_30continue_delay_53708;
    RHS_Slice(_30continue_delay_53708, 1, _next_top_54255);

    /** 	continue_list = continue_list[1..next_top]*/
    rhs_slice_target = (object_ptr)&_30continue_list_53707;
    RHS_Slice(_30continue_list_53707, 1, _next_top_54255);

    /** end procedure*/
    DeRef(_27852);
    _27852 = NOVALUE;
    return;
    ;
}


void _30PatchXList(int _base_54285)
{
    int _exit_top_54286 = NOVALUE;
    int _n_54287 = NOVALUE;
    int _27879 = NOVALUE;
    int _27878 = NOVALUE;
    int _27877 = NOVALUE;
    int _27873 = NOVALUE;
    int _27872 = NOVALUE;
    int _27871 = NOVALUE;
    int _27869 = NOVALUE;
    int _27868 = NOVALUE;
    int _27866 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(exit_list) then*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _27866 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _27866 = 1;
    }
    if (_27866 != 0)
    goto L1; // [10] 19
    _27866 = NOVALUE;

    /** 		return*/
    return;
L1: 

    /** 	exit_top = 0*/
    _exit_top_54286 = 0;

    /** 	for i=length(exit_list) to base+1 by -1 do*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _27868 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _27868 = 1;
    }
    _27869 = _base_54285 + 1;
    if (_27869 > MAXINT){
        _27869 = NewDouble((double)_27869);
    }
    {
        int _i_54292;
        _i_54292 = _27868;
L2: 
        if (binary_op_a(LESS, _i_54292, _27869)){
            goto L3; // [35] 129
        }

        /** 		n=exit_delay[i]*/
        _2 = (int)SEQ_PTR(_30exit_delay_53706);
        if (!IS_ATOM_INT(_i_54292)){
            _n_54287 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54292)->dbl));
        }
        else{
            _n_54287 = (int)*(((s1_ptr)_2)->base + _i_54292);
        }
        if (!IS_ATOM_INT(_n_54287))
        _n_54287 = (long)DBL_PTR(_n_54287)->dbl;

        /** 		exit_delay[i] -= (n>0)*/
        _27871 = (_n_54287 > 0);
        _2 = (int)SEQ_PTR(_30exit_delay_53706);
        if (!IS_ATOM_INT(_i_54292)){
            _27872 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54292)->dbl));
        }
        else{
            _27872 = (int)*(((s1_ptr)_2)->base + _i_54292);
        }
        if (IS_ATOM_INT(_27872)) {
            _27873 = _27872 - _27871;
            if ((long)((unsigned long)_27873 +(unsigned long) HIGH_BITS) >= 0){
                _27873 = NewDouble((double)_27873);
            }
        }
        else {
            _27873 = binary_op(MINUS, _27872, _27871);
        }
        _27872 = NOVALUE;
        _27871 = NOVALUE;
        _2 = (int)SEQ_PTR(_30exit_delay_53706);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30exit_delay_53706 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_i_54292))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54292)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _i_54292);
        _1 = *(int *)_2;
        *(int *)_2 = _27873;
        if( _1 != _27873 ){
            DeRef(_1);
        }
        _27873 = NOVALUE;

        /** 		if n>1 then*/
        if (_n_54287 <= 1)
        goto L4; // [72] 93

        /** 			if exit_top = 0 then*/
        if (_exit_top_54286 != 0)
        goto L5; // [78] 122

        /** 				exit_top = i*/
        Ref(_i_54292);
        _exit_top_54286 = _i_54292;
        if (!IS_ATOM_INT(_exit_top_54286)) {
            _1 = (long)(DBL_PTR(_exit_top_54286)->dbl);
            DeRefDS(_exit_top_54286);
            _exit_top_54286 = _1;
        }
        goto L5; // [90] 122
L4: 

        /** 		elsif n=1 then*/
        if (_n_54287 != 1)
        goto L6; // [95] 121

        /** 			backpatch(exit_list[i],length(Code)+1)*/
        _2 = (int)SEQ_PTR(_30exit_list_53705);
        if (!IS_ATOM_INT(_i_54292)){
            _27877 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_54292)->dbl));
        }
        else{
            _27877 = (int)*(((s1_ptr)_2)->base + _i_54292);
        }
        if (IS_SEQUENCE(_12Code_11771)){
                _27878 = SEQ_PTR(_12Code_11771)->length;
        }
        else {
            _27878 = 1;
        }
        _27879 = _27878 + 1;
        _27878 = NOVALUE;
        _37backpatch(_27877, _27879);
        _27877 = NOVALUE;
        _27879 = NOVALUE;
L6: 
L5: 

        /** 	end for*/
        _0 = _i_54292;
        if (IS_ATOM_INT(_i_54292)) {
            _i_54292 = _i_54292 + -1;
            if ((long)((unsigned long)_i_54292 +(unsigned long) HIGH_BITS) >= 0){
                _i_54292 = NewDouble((double)_i_54292);
            }
        }
        else {
            _i_54292 = binary_op_a(PLUS, _i_54292, -1);
        }
        DeRef(_0);
        goto L2; // [124] 42
L3: 
        ;
        DeRef(_i_54292);
    }

    /** 	if exit_top=0 then*/
    if (_exit_top_54286 != 0)
    goto L7; // [131] 141

    /** 	    exit_top=base*/
    _exit_top_54286 = _base_54285;
L7: 

    /** 	exit_delay = exit_delay [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_30exit_delay_53706;
    RHS_Slice(_30exit_delay_53706, 1, _exit_top_54286);

    /** 	exit_list = exit_list [1..exit_top]*/
    rhs_slice_target = (object_ptr)&_30exit_list_53705;
    RHS_Slice(_30exit_list_53705, 1, _exit_top_54286);

    /** end procedure*/
    DeRef(_27869);
    _27869 = NOVALUE;
    return;
    ;
}


void _30putback(int _t_54317)
{
    int _27884 = NOVALUE;
    int _0, _1, _2;
    

    /** 	backed_up_tok = append(backed_up_tok, t)*/
    Ref(_t_54317);
    Append(&_30backed_up_tok_53692, _30backed_up_tok_53692, _t_54317);

    /** 	if t[T_SYM] then*/
    _2 = (int)SEQ_PTR(_t_54317);
    _27884 = (int)*(((s1_ptr)_2)->base + 2);
    if (_27884 == 0) {
        _27884 = NOVALUE;
        goto L1; // [17] 79
    }
    else {
        if (!IS_ATOM_INT(_27884) && DBL_PTR(_27884)->dbl == 0.0){
            _27884 = NOVALUE;
            goto L1; // [17] 79
        }
        _27884 = NOVALUE;
    }
    _27884 = NOVALUE;

    /** 		putback_ForwardLine     = ForwardLine*/
    Ref(_43ForwardLine_48159);
    DeRef(_43putback_ForwardLine_48160);
    _43putback_ForwardLine_48160 = _43ForwardLine_48159;

    /** 		putback_forward_bp      = forward_bp*/
    _43putback_forward_bp_48164 = _43forward_bp_48163;

    /** 		putback_fwd_line_number = fwd_line_number*/
    _12putback_fwd_line_number_11685 = _12fwd_line_number_11684;

    /** 		if last_fwd_line_number then*/
    if (_12last_fwd_line_number_11686 == 0)
    {
        goto L2; // [49] 78
    }
    else{
    }

    /** 			ForwardLine     = last_ForwardLine*/
    Ref(_43last_ForwardLine_48161);
    DeRef(_43ForwardLine_48159);
    _43ForwardLine_48159 = _43last_ForwardLine_48161;

    /** 			forward_bp      = last_forward_bp*/
    _43forward_bp_48163 = _43last_forward_bp_48165;

    /** 			fwd_line_number = last_fwd_line_number*/
    _12fwd_line_number_11684 = _12last_fwd_line_number_11686;
L2: 
L1: 

    /** end procedure*/
    DeRef(_t_54317);
    return;
    ;
}


void _30start_recording()
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_30psm_stack_54336, _30psm_stack_54336, _12Parser_mode_11788);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_30canned_tokens_53729);
    Append(&_30can_stack_54337, _30can_stack_54337, _30canned_tokens_53729);

    /** 	idx_stack &= canned_index*/
    Append(&_30idx_stack_54338, _30idx_stack_54338, _30canned_index_53730);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_30backed_up_tok_53692);
    Append(&_30tok_stack_54339, _30tok_stack_54339, _30backed_up_tok_53692);

    /** 	canned_tokens = {}*/
    RefDS(_21829);
    DeRef(_30canned_tokens_53729);
    _30canned_tokens_53729 = _21829;

    /** 	Parser_mode = PAM_RECORD*/
    _12Parser_mode_11788 = 1;

    /** 	clear_last()*/
    _37clear_last();

    /** end procedure*/
    return;
    ;
}


int _30restore_parser()
{
    int _n_54352 = NOVALUE;
    int _tok_54353 = NOVALUE;
    int _x_54354 = NOVALUE;
    int _27915 = NOVALUE;
    int _27914 = NOVALUE;
    int _27913 = NOVALUE;
    int _27911 = NOVALUE;
    int _27907 = NOVALUE;
    int _27906 = NOVALUE;
    int _27904 = NOVALUE;
    int _27902 = NOVALUE;
    int _27901 = NOVALUE;
    int _27899 = NOVALUE;
    int _27897 = NOVALUE;
    int _27896 = NOVALUE;
    int _27894 = NOVALUE;
    int _27892 = NOVALUE;
    int _27891 = NOVALUE;
    int _27889 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n=Parser_mode*/
    _n_54352 = _12Parser_mode_11788;

    /** 	x = canned_tokens*/
    Ref(_30canned_tokens_53729);
    DeRef(_x_54354);
    _x_54354 = _30canned_tokens_53729;

    /** 	canned_tokens = can_stack[$]*/
    if (IS_SEQUENCE(_30can_stack_54337)){
            _27889 = SEQ_PTR(_30can_stack_54337)->length;
    }
    else {
        _27889 = 1;
    }
    DeRef(_30canned_tokens_53729);
    _2 = (int)SEQ_PTR(_30can_stack_54337);
    _30canned_tokens_53729 = (int)*(((s1_ptr)_2)->base + _27889);
    Ref(_30canned_tokens_53729);

    /** 	can_stack     = can_stack[1..$-1]*/
    if (IS_SEQUENCE(_30can_stack_54337)){
            _27891 = SEQ_PTR(_30can_stack_54337)->length;
    }
    else {
        _27891 = 1;
    }
    _27892 = _27891 - 1;
    _27891 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30can_stack_54337;
    RHS_Slice(_30can_stack_54337, 1, _27892);

    /** 	canned_index  = idx_stack[$]*/
    if (IS_SEQUENCE(_30idx_stack_54338)){
            _27894 = SEQ_PTR(_30idx_stack_54338)->length;
    }
    else {
        _27894 = 1;
    }
    _2 = (int)SEQ_PTR(_30idx_stack_54338);
    _30canned_index_53730 = (int)*(((s1_ptr)_2)->base + _27894);

    /** 	idx_stack     = idx_stack[1..$-1]*/
    if (IS_SEQUENCE(_30idx_stack_54338)){
            _27896 = SEQ_PTR(_30idx_stack_54338)->length;
    }
    else {
        _27896 = 1;
    }
    _27897 = _27896 - 1;
    _27896 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30idx_stack_54338;
    RHS_Slice(_30idx_stack_54338, 1, _27897);

    /** 	Parser_mode   = psm_stack[$]*/
    if (IS_SEQUENCE(_30psm_stack_54336)){
            _27899 = SEQ_PTR(_30psm_stack_54336)->length;
    }
    else {
        _27899 = 1;
    }
    _2 = (int)SEQ_PTR(_30psm_stack_54336);
    _12Parser_mode_11788 = (int)*(((s1_ptr)_2)->base + _27899);

    /** 	psm_stack     = psm_stack[1..$-1]*/
    if (IS_SEQUENCE(_30psm_stack_54336)){
            _27901 = SEQ_PTR(_30psm_stack_54336)->length;
    }
    else {
        _27901 = 1;
    }
    _27902 = _27901 - 1;
    _27901 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30psm_stack_54336;
    RHS_Slice(_30psm_stack_54336, 1, _27902);

    /** 	tok 		  = tok_stack[$]*/
    if (IS_SEQUENCE(_30tok_stack_54339)){
            _27904 = SEQ_PTR(_30tok_stack_54339)->length;
    }
    else {
        _27904 = 1;
    }
    DeRef(_tok_54353);
    _2 = (int)SEQ_PTR(_30tok_stack_54339);
    _tok_54353 = (int)*(((s1_ptr)_2)->base + _27904);
    RefDS(_tok_54353);

    /** 	tok_stack 	  = tok_stack[1..$-1]*/
    if (IS_SEQUENCE(_30tok_stack_54339)){
            _27906 = SEQ_PTR(_30tok_stack_54339)->length;
    }
    else {
        _27906 = 1;
    }
    _27907 = _27906 - 1;
    _27906 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30tok_stack_54339;
    RHS_Slice(_30tok_stack_54339, 1, _27907);

    /** 	clear_last()*/
    _37clear_last();

    /** 	if n=PAM_PLAYBACK then*/
    if (_n_54352 != -1)
    goto L1; // [137] 150

    /** 		return {}*/
    RefDS(_21829);
    DeRefDS(_tok_54353);
    DeRefDS(_x_54354);
    _27892 = NOVALUE;
    _27897 = NOVALUE;
    _27902 = NOVALUE;
    _27907 = NOVALUE;
    return _21829;
    goto L2; // [147] 167
L1: 

    /** 	elsif n = PAM_NORMAL then*/
    if (_n_54352 != 0)
    goto L3; // [154] 166

    /** 		use_private_list = 0*/
    _12use_private_list_11796 = 0;
L3: 
L2: 

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_30backed_up_tok_53692)){
            _27911 = SEQ_PTR(_30backed_up_tok_53692)->length;
    }
    else {
        _27911 = 1;
    }
    if (_27911 <= 0)
    goto L4; // [174] 199

    /** 		return x[1..$-1]*/
    if (IS_SEQUENCE(_x_54354)){
            _27913 = SEQ_PTR(_x_54354)->length;
    }
    else {
        _27913 = 1;
    }
    _27914 = _27913 - 1;
    _27913 = NOVALUE;
    rhs_slice_target = (object_ptr)&_27915;
    RHS_Slice(_x_54354, 1, _27914);
    DeRef(_tok_54353);
    DeRefDS(_x_54354);
    DeRef(_27892);
    _27892 = NOVALUE;
    DeRef(_27897);
    _27897 = NOVALUE;
    DeRef(_27902);
    _27902 = NOVALUE;
    DeRef(_27907);
    _27907 = NOVALUE;
    _27914 = NOVALUE;
    return _27915;
    goto L5; // [196] 206
L4: 

    /** 		return x*/
    DeRef(_tok_54353);
    DeRef(_27892);
    _27892 = NOVALUE;
    DeRef(_27897);
    _27897 = NOVALUE;
    DeRef(_27902);
    _27902 = NOVALUE;
    DeRef(_27907);
    _27907 = NOVALUE;
    DeRef(_27914);
    _27914 = NOVALUE;
    DeRef(_27915);
    _27915 = NOVALUE;
    return _x_54354;
L5: 
    ;
}


void _30start_playback(int _s_54394)
{
    int _0, _1, _2;
    

    /** 	psm_stack &= Parser_mode*/
    Append(&_30psm_stack_54336, _30psm_stack_54336, _12Parser_mode_11788);

    /** 	can_stack = append(can_stack,canned_tokens)*/
    Ref(_30canned_tokens_53729);
    Append(&_30can_stack_54337, _30can_stack_54337, _30canned_tokens_53729);

    /** 	idx_stack &= canned_index*/
    Append(&_30idx_stack_54338, _30idx_stack_54338, _30canned_index_53730);

    /** 	tok_stack = append(tok_stack,backed_up_tok)*/
    RefDS(_30backed_up_tok_53692);
    Append(&_30tok_stack_54339, _30tok_stack_54339, _30backed_up_tok_53692);

    /** 	canned_index = 1*/
    _30canned_index_53730 = 1;

    /** 	canned_tokens = s*/
    RefDS(_s_54394);
    DeRef(_30canned_tokens_53729);
    _30canned_tokens_53729 = _s_54394;

    /** 	backed_up_tok = {}*/
    RefDS(_21829);
    DeRefDS(_30backed_up_tok_53692);
    _30backed_up_tok_53692 = _21829;

    /** 	Parser_mode = PAM_PLAYBACK*/
    _12Parser_mode_11788 = -1;

    /** end procedure*/
    DeRefDS(_s_54394);
    return;
    ;
}


void _30restore_parseargs_states()
{
    int _s_54413 = NOVALUE;
    int _n_54414 = NOVALUE;
    int _27932 = NOVALUE;
    int _27931 = NOVALUE;
    int _27923 = NOVALUE;
    int _27922 = NOVALUE;
    int _27920 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = parseargs_states[$]*/
    if (IS_SEQUENCE(_30parseargs_states_54402)){
            _27920 = SEQ_PTR(_30parseargs_states_54402)->length;
    }
    else {
        _27920 = 1;
    }
    DeRef(_s_54413);
    _2 = (int)SEQ_PTR(_30parseargs_states_54402);
    _s_54413 = (int)*(((s1_ptr)_2)->base + _27920);
    RefDS(_s_54413);

    /** 	parseargs_states = parseargs_states[1..$-1]*/
    if (IS_SEQUENCE(_30parseargs_states_54402)){
            _27922 = SEQ_PTR(_30parseargs_states_54402)->length;
    }
    else {
        _27922 = 1;
    }
    _27923 = _27922 - 1;
    _27922 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30parseargs_states_54402;
    RHS_Slice(_30parseargs_states_54402, 1, _27923);

    /** 	n=s[PS_POSITION]*/
    _2 = (int)SEQ_PTR(_s_54413);
    _n_54414 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54414))
    _n_54414 = (long)DBL_PTR(_n_54414)->dbl;

    /** 	private_list = private_list[1..n]*/
    rhs_slice_target = (object_ptr)&_30private_list_54407;
    RHS_Slice(_30private_list_54407, 1, _n_54414);

    /** 	private_sym = private_sym[1..n]*/
    rhs_slice_target = (object_ptr)&_12private_sym_11795;
    RHS_Slice(_12private_sym_11795, 1, _n_54414);

    /** 	lock_scanner = s[PS_SCAN_LOCK]*/
    _2 = (int)SEQ_PTR(_s_54413);
    _30lock_scanner_54408 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_30lock_scanner_54408))
    _30lock_scanner_54408 = (long)DBL_PTR(_30lock_scanner_54408)->dbl;

    /** 	use_private_list = s[PS_USE_LIST]*/
    _2 = (int)SEQ_PTR(_s_54413);
    _12use_private_list_11796 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_12use_private_list_11796)){
        _12use_private_list_11796 = (long)DBL_PTR(_12use_private_list_11796)->dbl;
    }

    /** 	on_arg = s[PS_ON_ARG]*/
    _2 = (int)SEQ_PTR(_s_54413);
    _30on_arg_54409 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_30on_arg_54409))
    _30on_arg_54409 = (long)DBL_PTR(_30on_arg_54409)->dbl;

    /** 	nested_calls = nested_calls[1..$-1]*/
    if (IS_SEQUENCE(_30nested_calls_54410)){
            _27931 = SEQ_PTR(_30nested_calls_54410)->length;
    }
    else {
        _27931 = 1;
    }
    _27932 = _27931 - 1;
    _27931 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30nested_calls_54410;
    RHS_Slice(_30nested_calls_54410, 1, _27932);

    /** end procedure*/
    DeRefDS(_s_54413);
    _27923 = NOVALUE;
    _27932 = NOVALUE;
    return;
    ;
}


int _30read_recorded_token(int _n_54434)
{
    int _t_54436 = NOVALUE;
    int _p_54437 = NOVALUE;
    int _prev_Nne_54438 = NOVALUE;
    int _ts_54467 = NOVALUE;
    int _31377 = NOVALUE;
    int _31376 = NOVALUE;
    int _31375 = NOVALUE;
    int _31374 = NOVALUE;
    int _31373 = NOVALUE;
    int _31372 = NOVALUE;
    int _31371 = NOVALUE;
    int _31370 = NOVALUE;
    int _28004 = NOVALUE;
    int _28003 = NOVALUE;
    int _28002 = NOVALUE;
    int _28001 = NOVALUE;
    int _27997 = NOVALUE;
    int _27995 = NOVALUE;
    int _27994 = NOVALUE;
    int _27993 = NOVALUE;
    int _27992 = NOVALUE;
    int _27990 = NOVALUE;
    int _27989 = NOVALUE;
    int _27988 = NOVALUE;
    int _27987 = NOVALUE;
    int _27985 = NOVALUE;
    int _27982 = NOVALUE;
    int _27980 = NOVALUE;
    int _27978 = NOVALUE;
    int _27977 = NOVALUE;
    int _27976 = NOVALUE;
    int _27975 = NOVALUE;
    int _27973 = NOVALUE;
    int _27971 = NOVALUE;
    int _27967 = NOVALUE;
    int _27965 = NOVALUE;
    int _27963 = NOVALUE;
    int _27962 = NOVALUE;
    int _27961 = NOVALUE;
    int _27960 = NOVALUE;
    int _27959 = NOVALUE;
    int _27958 = NOVALUE;
    int _27957 = NOVALUE;
    int _27956 = NOVALUE;
    int _27955 = NOVALUE;
    int _27954 = NOVALUE;
    int _27953 = NOVALUE;
    int _27952 = NOVALUE;
    int _27950 = NOVALUE;
    int _27949 = NOVALUE;
    int _27947 = NOVALUE;
    int _27946 = NOVALUE;
    int _27945 = NOVALUE;
    int _27944 = NOVALUE;
    int _27943 = NOVALUE;
    int _27942 = NOVALUE;
    int _27941 = NOVALUE;
    int _27940 = NOVALUE;
    int _27937 = NOVALUE;
    int _27935 = NOVALUE;
    int _27934 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_n_54434)) {
        _1 = (long)(DBL_PTR(_n_54434)->dbl);
        DeRefDS(_n_54434);
        _n_54434 = _1;
    }

    /** 	integer p, prev_Nne*/

    /** 	if atom(Ns_recorded[n]) label "top if" then*/
    _2 = (int)SEQ_PTR(_12Ns_recorded_11790);
    _27934 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _27935 = IS_ATOM(_27934);
    _27934 = NOVALUE;
    if (_27935 == 0)
    {
        _27935 = NOVALUE;
        goto L1; // [16] 403
    }
    else{
        _27935 = NOVALUE;
    }

    /** 		if use_private_list then*/
    if (_12use_private_list_11796 == 0)
    {
        goto L2; // [23] 171
    }
    else{
    }

    /** 			p = find( Recorded[n], private_list)*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _27937 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _p_54437 = find_from(_27937, _30private_list_54407, 1);
    _27937 = NOVALUE;

    /** 			if p > 0 then -- the value of this parameter is known, use it*/
    if (_p_54437 <= 0)
    goto L3; // [43] 170

    /** 				if TRANSLATE*/
    if (_12TRANSLATE_11319 == 0) {
        goto L4; // [51] 150
    }
    _2 = (int)SEQ_PTR(_12private_sym_11795);
    _27941 = (int)*(((s1_ptr)_2)->base + _p_54437);
    if (IS_ATOM_INT(_27941)) {
        _27942 = (_27941 < 0);
    }
    else {
        _27942 = binary_op(LESS, _27941, 0);
    }
    _27941 = NOVALUE;
    if (IS_ATOM_INT(_27942)) {
        if (_27942 != 0) {
            _27943 = 1;
            goto L5; // [65] 97
        }
    }
    else {
        if (DBL_PTR(_27942)->dbl != 0.0) {
            _27943 = 1;
            goto L5; // [65] 97
        }
    }
    _2 = (int)SEQ_PTR(_12private_sym_11795);
    _27944 = (int)*(((s1_ptr)_2)->base + _p_54437);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_27944)){
        _27945 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27944)->dbl));
    }
    else{
        _27945 = (int)*(((s1_ptr)_2)->base + _27944);
    }
    _2 = (int)SEQ_PTR(_27945);
    _27946 = (int)*(((s1_ptr)_2)->base + 3);
    _27945 = NOVALUE;
    if (IS_ATOM_INT(_27946)) {
        _27947 = (_27946 == 3);
    }
    else {
        _27947 = binary_op(EQUALS, _27946, 3);
    }
    _27946 = NOVALUE;
    DeRef(_27943);
    if (IS_ATOM_INT(_27947))
    _27943 = (_27947 != 0);
    else
    _27943 = DBL_PTR(_27947)->dbl != 0.0;
L5: 
    if (_27943 == 0)
    {
        _27943 = NOVALUE;
        goto L4; // [98] 150
    }
    else{
        _27943 = NOVALUE;
    }

    /** 					symtab_index ts = NewTempSym()*/
    _ts_54467 = _52NewTempSym(0);
    if (!IS_ATOM_INT(_ts_54467)) {
        _1 = (long)(DBL_PTR(_ts_54467)->dbl);
        DeRefDS(_ts_54467);
        _ts_54467 = _1;
    }

    /** 					Code &= { ASSIGN, private_sym[p], ts }*/
    _2 = (int)SEQ_PTR(_12private_sym_11795);
    _27949 = (int)*(((s1_ptr)_2)->base + _p_54437);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 18;
    Ref(_27949);
    *((int *)(_2+8)) = _27949;
    *((int *)(_2+12)) = _ts_54467;
    _27950 = MAKE_SEQ(_1);
    _27949 = NOVALUE;
    Concat((object_ptr)&_12Code_11771, _12Code_11771, _27950);
    DeRefDS(_27950);
    _27950 = NOVALUE;

    /** 					return {VARIABLE, ts}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _ts_54467;
    _27952 = MAKE_SEQ(_1);
    DeRef(_t_54436);
    _27944 = NOVALUE;
    DeRef(_27942);
    _27942 = NOVALUE;
    DeRef(_27947);
    _27947 = NOVALUE;
    return _27952;
    goto L6; // [147] 169
L4: 

    /** 					return {VARIABLE, private_sym[p]}*/
    _2 = (int)SEQ_PTR(_12private_sym_11795);
    _27953 = (int)*(((s1_ptr)_2)->base + _p_54437);
    Ref(_27953);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _27953;
    _27954 = MAKE_SEQ(_1);
    _27953 = NOVALUE;
    DeRef(_t_54436);
    _27944 = NOVALUE;
    DeRef(_27942);
    _27942 = NOVALUE;
    DeRef(_27952);
    _27952 = NOVALUE;
    DeRef(_27947);
    _27947 = NOVALUE;
    return _27954;
L6: 
L3: 
L2: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54438 = _52No_new_entry_46903;

    /** 		No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 		if Recorded_sym[n] > 0 and  sym_scope( Recorded_sym[n] ) != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _27955 = (int)*(((s1_ptr)_2)->base + _n_54434);
    if (IS_ATOM_INT(_27955)) {
        _27956 = (_27955 > 0);
    }
    else {
        _27956 = binary_op(GREATER, _27955, 0);
    }
    _27955 = NOVALUE;
    if (IS_ATOM_INT(_27956)) {
        if (_27956 == 0) {
            goto L7; // [199] 250
        }
    }
    else {
        if (DBL_PTR(_27956)->dbl == 0.0) {
            goto L7; // [199] 250
        }
    }
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _27958 = (int)*(((s1_ptr)_2)->base + _n_54434);
    Ref(_27958);
    _27959 = _52sym_scope(_27958);
    _27958 = NOVALUE;
    if (IS_ATOM_INT(_27959)) {
        _27960 = (_27959 != 9);
    }
    else {
        _27960 = binary_op(NOTEQ, _27959, 9);
    }
    DeRef(_27959);
    _27959 = NOVALUE;
    if (_27960 == 0) {
        DeRef(_27960);
        _27960 = NOVALUE;
        goto L7; // [220] 250
    }
    else {
        if (!IS_ATOM_INT(_27960) && DBL_PTR(_27960)->dbl == 0.0){
            DeRef(_27960);
            _27960 = NOVALUE;
            goto L7; // [220] 250
        }
        DeRef(_27960);
        _27960 = NOVALUE;
    }
    DeRef(_27960);
    _27960 = NOVALUE;

    /** 			t = { sym_token( Recorded_sym[n] ), Recorded_sym[n] }*/
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _27961 = (int)*(((s1_ptr)_2)->base + _n_54434);
    Ref(_27961);
    _27962 = _52sym_token(_27961);
    _27961 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _27963 = (int)*(((s1_ptr)_2)->base + _n_54434);
    Ref(_27963);
    DeRef(_t_54436);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27962;
    ((int *)_2)[2] = _27963;
    _t_54436 = MAKE_SEQ(_1);
    _27963 = NOVALUE;
    _27962 = NOVALUE;

    /** 			break "top if"*/
    goto L8; // [247] 728
L7: 

    /** 		t = keyfind(Recorded[n],-1)*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _27965 = (int)*(((s1_ptr)_2)->base + _n_54434);
    RefDS(_27965);
    DeRef(_31376);
    _31376 = _27965;
    _31377 = _52hashfn(_31376);
    _31376 = NOVALUE;
    RefDS(_27965);
    _0 = _t_54436;
    _t_54436 = _52keyfind(_27965, -1, _12current_file_no_11682, 0, _31377);
    DeRef(_0);
    _27965 = NOVALUE;
    _31377 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54436);
    _27967 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27967, 509)){
        _27967 = NOVALUE;
        goto L8; // [286] 728
    }
    _27967 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _p_54437 = (int)*(((s1_ptr)_2)->base + _n_54434);
    if (!IS_ATOM_INT(_p_54437)){
        _p_54437 = (long)DBL_PTR(_p_54437)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54437 != 0)
    goto L9; // [302] 380

    /** 				No_new_entry = 0*/
    _52No_new_entry_46903 = 0;

    /** 				t = keyfind( Recorded[n], -1 )*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _27971 = (int)*(((s1_ptr)_2)->base + _n_54434);
    RefDS(_27971);
    DeRef(_31374);
    _31374 = _27971;
    _31375 = _52hashfn(_31374);
    _31374 = NOVALUE;
    RefDS(_27971);
    _0 = _t_54436;
    _t_54436 = _52keyfind(_27971, -1, _12current_file_no_11682, 0, _31375);
    DeRef(_0);
    _27971 = NOVALUE;
    _31375 = NOVALUE;

    /** 				No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 				if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54436);
    _27973 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27973, 509)){
        _27973 = NOVALUE;
        goto L8; // [355] 728
    }
    _27973 = NOVALUE;

    /** 					CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _27975 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_27975);
    *((int *)(_2+4)) = _27975;
    _27976 = MAKE_SEQ(_1);
    _27975 = NOVALUE;
    _43CompileErr(157, _27976, 0);
    _27976 = NOVALUE;
    goto L8; // [377] 728
L9: 

    /** 				t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _27977 = (int)*(((s1_ptr)_2)->base + _p_54437);
    _2 = (int)SEQ_PTR(_27977);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _27978 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _27978 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _27977 = NOVALUE;
    Ref(_27978);
    DeRef(_t_54436);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _27978;
    ((int *)_2)[2] = _p_54437;
    _t_54436 = MAKE_SEQ(_1);
    _27978 = NOVALUE;
    goto L8; // [400] 728
L1: 

    /** 		prev_Nne = No_new_entry*/
    _prev_Nne_54438 = _52No_new_entry_46903;

    /** 		No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 		t = keyfind(Ns_recorded[n],-1, , 1)*/
    _2 = (int)SEQ_PTR(_12Ns_recorded_11790);
    _27980 = (int)*(((s1_ptr)_2)->base + _n_54434);
    Ref(_27980);
    DeRef(_31372);
    _31372 = _27980;
    _31373 = _52hashfn(_31372);
    _31372 = NOVALUE;
    Ref(_27980);
    _0 = _t_54436;
    _t_54436 = _52keyfind(_27980, -1, _12current_file_no_11682, 1, _31373);
    DeRef(_0);
    _27980 = NOVALUE;
    _31373 = NOVALUE;

    /** 		if t[T_ID] != NAMESPACE then*/
    _2 = (int)SEQ_PTR(_t_54436);
    _27982 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _27982, 523)){
        _27982 = NOVALUE;
        goto LA; // [454] 520
    }
    _27982 = NOVALUE;

    /** 			p = Ns_recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_12Ns_recorded_sym_11792);
    _p_54437 = (int)*(((s1_ptr)_2)->base + _n_54434);
    if (!IS_ATOM_INT(_p_54437)){
        _p_54437 = (long)DBL_PTR(_p_54437)->dbl;
    }

    /** 			if p = 0 or sym_token( p ) != NAMESPACE then*/
    _27985 = (_p_54437 == 0);
    if (_27985 != 0) {
        goto LB; // [474] 493
    }
    _27987 = _52sym_token(_p_54437);
    if (IS_ATOM_INT(_27987)) {
        _27988 = (_27987 != 523);
    }
    else {
        _27988 = binary_op(NOTEQ, _27987, 523);
    }
    DeRef(_27987);
    _27987 = NOVALUE;
    if (_27988 == 0) {
        DeRef(_27988);
        _27988 = NOVALUE;
        goto LC; // [489] 511
    }
    else {
        if (!IS_ATOM_INT(_27988) && DBL_PTR(_27988)->dbl == 0.0){
            DeRef(_27988);
            _27988 = NOVALUE;
            goto LC; // [489] 511
        }
        DeRef(_27988);
        _27988 = NOVALUE;
    }
    DeRef(_27988);
    _27988 = NOVALUE;
LB: 

    /** 				CompileErr(153, {Ns_recorded[n]})*/
    _2 = (int)SEQ_PTR(_12Ns_recorded_11790);
    _27989 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_27989);
    *((int *)(_2+4)) = _27989;
    _27990 = MAKE_SEQ(_1);
    _27989 = NOVALUE;
    _43CompileErr(153, _27990, 0);
    _27990 = NOVALUE;
LC: 

    /** 			t = {NAMESPACE, p}*/
    DeRef(_t_54436);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 523;
    ((int *)_2)[2] = _p_54437;
    _t_54436 = MAKE_SEQ(_1);
LA: 

    /** 		t = keyfind(Recorded[n],SymTab[t[T_SYM]][S_OBJ])*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _27992 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _2 = (int)SEQ_PTR(_t_54436);
    _27993 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_27993)){
        _27994 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_27993)->dbl));
    }
    else{
        _27994 = (int)*(((s1_ptr)_2)->base + _27993);
    }
    _2 = (int)SEQ_PTR(_27994);
    _27995 = (int)*(((s1_ptr)_2)->base + 1);
    _27994 = NOVALUE;
    RefDS(_27992);
    DeRef(_31370);
    _31370 = _27992;
    _31371 = _52hashfn(_31370);
    _31370 = NOVALUE;
    RefDS(_27992);
    Ref(_27995);
    _0 = _t_54436;
    _t_54436 = _52keyfind(_27992, _27995, _12current_file_no_11682, 0, _31371);
    DeRef(_0);
    _27992 = NOVALUE;
    _27995 = NOVALUE;
    _31371 = NOVALUE;

    /** 		if t[T_ID] = IGNORED then*/
    _2 = (int)SEQ_PTR(_t_54436);
    _27997 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _27997, 509)){
        _27997 = NOVALUE;
        goto LD; // [573] 630
    }
    _27997 = NOVALUE;

    /** 	        p = Recorded_sym[n]*/
    _2 = (int)SEQ_PTR(_12Recorded_sym_11791);
    _p_54437 = (int)*(((s1_ptr)_2)->base + _n_54434);
    if (!IS_ATOM_INT(_p_54437)){
        _p_54437 = (long)DBL_PTR(_p_54437)->dbl;
    }

    /** 	        if p = 0 then*/
    if (_p_54437 != 0)
    goto LE; // [589] 611

    /** 	        	CompileErr(157,{Recorded[n]})*/
    _2 = (int)SEQ_PTR(_12Recorded_11789);
    _28001 = (int)*(((s1_ptr)_2)->base + _n_54434);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_28001);
    *((int *)(_2+4)) = _28001;
    _28002 = MAKE_SEQ(_1);
    _28001 = NOVALUE;
    _43CompileErr(157, _28002, 0);
    _28002 = NOVALUE;
LE: 

    /** 		    t = {SymTab[p][S_TOKEN], p}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28003 = (int)*(((s1_ptr)_2)->base + _p_54437);
    _2 = (int)SEQ_PTR(_28003);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _28004 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _28004 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _28003 = NOVALUE;
    Ref(_28004);
    DeRef(_t_54436);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28004;
    ((int *)_2)[2] = _p_54437;
    _t_54436 = MAKE_SEQ(_1);
    _28004 = NOVALUE;
LD: 

    /** 		n = t[T_ID]*/
    _2 = (int)SEQ_PTR(_t_54436);
    _n_54434 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_n_54434)){
        _n_54434 = (long)DBL_PTR(_n_54434)->dbl;
    }

    /** 		if n = VARIABLE then*/
    if (_n_54434 != -100)
    goto LF; // [644] 660

    /** 			n = QUALIFIED_VARIABLE*/
    _n_54434 = 512;
    goto L10; // [657] 719
LF: 

    /** 		elsif n = FUNC then*/
    if (_n_54434 != 501)
    goto L11; // [664] 680

    /** 			n = QUALIFIED_FUNC*/
    _n_54434 = 520;
    goto L10; // [677] 719
L11: 

    /** 		elsif n = PROC then*/
    if (_n_54434 != 27)
    goto L12; // [684] 700

    /** 			n = QUALIFIED_PROC*/
    _n_54434 = 521;
    goto L10; // [697] 719
L12: 

    /** 		elsif n = TYPE then*/
    if (_n_54434 != 504)
    goto L13; // [704] 718

    /** 			n = QUALIFIED_TYPE*/
    _n_54434 = 522;
L13: 
L10: 

    /** 		t[T_ID] = n*/
    _2 = (int)SEQ_PTR(_t_54436);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _t_54436 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _n_54434;
    DeRef(_1);
L8: 

    /** 	No_new_entry = prev_Nne*/
    _52No_new_entry_46903 = _prev_Nne_54438;

    /**   	return t*/
    _27944 = NOVALUE;
    DeRef(_27942);
    _27942 = NOVALUE;
    DeRef(_27952);
    _27952 = NOVALUE;
    DeRef(_27947);
    _27947 = NOVALUE;
    DeRef(_27954);
    _27954 = NOVALUE;
    DeRef(_27985);
    _27985 = NOVALUE;
    DeRef(_27956);
    _27956 = NOVALUE;
    _27993 = NOVALUE;
    return _t_54436;
    ;
}


int _30next_token()
{
    int _t_54615 = NOVALUE;
    int _s_54616 = NOVALUE;
    int _28043 = NOVALUE;
    int _28042 = NOVALUE;
    int _28041 = NOVALUE;
    int _28040 = NOVALUE;
    int _28039 = NOVALUE;
    int _28038 = NOVALUE;
    int _28037 = NOVALUE;
    int _28036 = NOVALUE;
    int _28034 = NOVALUE;
    int _28033 = NOVALUE;
    int _28032 = NOVALUE;
    int _28031 = NOVALUE;
    int _28029 = NOVALUE;
    int _28027 = NOVALUE;
    int _28025 = NOVALUE;
    int _28021 = NOVALUE;
    int _28018 = NOVALUE;
    int _28015 = NOVALUE;
    int _28013 = NOVALUE;
    int _28011 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence s*/

    /** 	if length(backed_up_tok) > 0 then*/
    if (IS_SEQUENCE(_30backed_up_tok_53692)){
            _28011 = SEQ_PTR(_30backed_up_tok_53692)->length;
    }
    else {
        _28011 = 1;
    }
    if (_28011 <= 0)
    goto L1; // [10] 82

    /** 		t = backed_up_tok[$]*/
    if (IS_SEQUENCE(_30backed_up_tok_53692)){
            _28013 = SEQ_PTR(_30backed_up_tok_53692)->length;
    }
    else {
        _28013 = 1;
    }
    DeRef(_t_54615);
    _2 = (int)SEQ_PTR(_30backed_up_tok_53692);
    _t_54615 = (int)*(((s1_ptr)_2)->base + _28013);
    Ref(_t_54615);

    /** 		backed_up_tok = remove( backed_up_tok, length( backed_up_tok ) )*/
    if (IS_SEQUENCE(_30backed_up_tok_53692)){
            _28015 = SEQ_PTR(_30backed_up_tok_53692)->length;
    }
    else {
        _28015 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30backed_up_tok_53692);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_28015)) ? _28015 : (long)(DBL_PTR(_28015)->dbl);
        int stop = (IS_ATOM_INT(_28015)) ? _28015 : (long)(DBL_PTR(_28015)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30backed_up_tok_53692), start, &_30backed_up_tok_53692 );
            }
            else Tail(SEQ_PTR(_30backed_up_tok_53692), stop+1, &_30backed_up_tok_53692);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30backed_up_tok_53692), start, &_30backed_up_tok_53692);
        }
        else {
            assign_slice_seq = &assign_space;
            _30backed_up_tok_53692 = Remove_elements(start, stop, (SEQ_PTR(_30backed_up_tok_53692)->ref == 1));
        }
    }
    _28015 = NOVALUE;
    _28015 = NOVALUE;

    /** 		if putback_fwd_line_number then*/
    if (_12putback_fwd_line_number_11685 == 0)
    {
        goto L2; // [43] 347
    }
    else{
    }

    /** 			ForwardLine     = putback_ForwardLine*/
    Ref(_43putback_ForwardLine_48160);
    DeRef(_43ForwardLine_48159);
    _43ForwardLine_48159 = _43putback_ForwardLine_48160;

    /** 			forward_bp      = putback_forward_bp*/
    _43forward_bp_48163 = _43putback_forward_bp_48164;

    /** 			fwd_line_number = putback_fwd_line_number*/
    _12fwd_line_number_11684 = _12putback_fwd_line_number_11685;

    /** 			putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_11685 = 0;
    goto L2; // [79] 347
L1: 

    /** 	elsif Parser_mode = PAM_PLAYBACK then*/
    if (_12Parser_mode_11788 != -1)
    goto L3; // [88] 300

    /** 		if canned_index <= length(canned_tokens) then*/
    if (IS_SEQUENCE(_30canned_tokens_53729)){
            _28018 = SEQ_PTR(_30canned_tokens_53729)->length;
    }
    else {
        _28018 = 1;
    }
    if (_30canned_index_53730 > _28018)
    goto L4; // [101] 150

    /** 			t = canned_tokens[canned_index]*/
    DeRef(_t_54615);
    _2 = (int)SEQ_PTR(_30canned_tokens_53729);
    _t_54615 = (int)*(((s1_ptr)_2)->base + _30canned_index_53730);
    Ref(_t_54615);

    /** 			if canned_index < length(canned_tokens) then*/
    if (IS_SEQUENCE(_30canned_tokens_53729)){
            _28021 = SEQ_PTR(_30canned_tokens_53729)->length;
    }
    else {
        _28021 = 1;
    }
    if (_30canned_index_53730 >= _28021)
    goto L5; // [124] 139

    /** 				canned_index += 1*/
    _30canned_index_53730 = _30canned_index_53730 + 1;
    goto L6; // [136] 157
L5: 

    /** 	            s = restore_parser()*/
    _0 = _s_54616;
    _s_54616 = _30restore_parser();
    DeRef(_0);
    goto L6; // [147] 157
L4: 

    /** 	    	InternalErr(266)*/
    RefDS(_21829);
    _43InternalErr(266, _21829);
L6: 

    /** 		if t[T_ID] = RECORDED then*/
    _2 = (int)SEQ_PTR(_t_54615);
    _28025 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28025, 508)){
        _28025 = NOVALUE;
        goto L7; // [169] 188
    }
    _28025 = NOVALUE;

    /** 			t=read_recorded_token(t[T_SYM])*/
    _2 = (int)SEQ_PTR(_t_54615);
    _28027 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28027);
    _0 = _t_54615;
    _t_54615 = _30read_recorded_token(_28027);
    DeRef(_0);
    _28027 = NOVALUE;
    goto L2; // [185] 347
L7: 

    /** 		elsif t[T_ID] = DEF_PARAM then*/
    _2 = (int)SEQ_PTR(_t_54615);
    _28029 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28029, 510)){
        _28029 = NOVALUE;
        goto L2; // [198] 347
    }
    _28029 = NOVALUE;

    /**         	for i=length(nested_calls) to 1 by -1 do*/
    if (IS_SEQUENCE(_30nested_calls_54410)){
            _28031 = SEQ_PTR(_30nested_calls_54410)->length;
    }
    else {
        _28031 = 1;
    }
    {
        int _i_54663;
        _i_54663 = _28031;
L8: 
        if (_i_54663 < 1){
            goto L9; // [209] 288
        }

        /**         	    if nested_calls[i] = t[T_SYM][2] then*/
        _2 = (int)SEQ_PTR(_30nested_calls_54410);
        _28032 = (int)*(((s1_ptr)_2)->base + _i_54663);
        _2 = (int)SEQ_PTR(_t_54615);
        _28033 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28033);
        _28034 = (int)*(((s1_ptr)_2)->base + 2);
        _28033 = NOVALUE;
        if (binary_op_a(NOTEQ, _28032, _28034)){
            _28032 = NOVALUE;
            _28034 = NOVALUE;
            goto LA; // [234] 281
        }
        _28032 = NOVALUE;
        _28034 = NOVALUE;

        /** 					return {VARIABLE, private_sym[parseargs_states[i][PS_POSITION]+t[T_SYM][1]]}*/
        _2 = (int)SEQ_PTR(_30parseargs_states_54402);
        _28036 = (int)*(((s1_ptr)_2)->base + _i_54663);
        _2 = (int)SEQ_PTR(_28036);
        _28037 = (int)*(((s1_ptr)_2)->base + 1);
        _28036 = NOVALUE;
        _2 = (int)SEQ_PTR(_t_54615);
        _28038 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_28038);
        _28039 = (int)*(((s1_ptr)_2)->base + 1);
        _28038 = NOVALUE;
        if (IS_ATOM_INT(_28037) && IS_ATOM_INT(_28039)) {
            _28040 = _28037 + _28039;
        }
        else {
            _28040 = binary_op(PLUS, _28037, _28039);
        }
        _28037 = NOVALUE;
        _28039 = NOVALUE;
        _2 = (int)SEQ_PTR(_12private_sym_11795);
        if (!IS_ATOM_INT(_28040)){
            _28041 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28040)->dbl));
        }
        else{
            _28041 = (int)*(((s1_ptr)_2)->base + _28040);
        }
        Ref(_28041);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -100;
        ((int *)_2)[2] = _28041;
        _28042 = MAKE_SEQ(_1);
        _28041 = NOVALUE;
        DeRef(_t_54615);
        DeRef(_s_54616);
        DeRef(_28040);
        _28040 = NOVALUE;
        return _28042;
LA: 

        /** 			end for*/
        _i_54663 = _i_54663 + -1;
        goto L8; // [283] 216
L9: 
        ;
    }

    /** 			CompileErr(98)*/
    RefDS(_21829);
    _43CompileErr(98, _21829, 0);
    goto L2; // [297] 347
L3: 

    /** 	elsif lock_scanner then*/
    if (_30lock_scanner_54408 == 0)
    {
        goto LB; // [304] 322
    }
    else{
    }

    /** 		return {PLAYBACK_ENDS,0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 505;
    ((int *)_2)[2] = 0;
    _28043 = MAKE_SEQ(_1);
    DeRef(_t_54615);
    DeRef(_s_54616);
    DeRef(_28042);
    _28042 = NOVALUE;
    DeRef(_28040);
    _28040 = NOVALUE;
    return _28043;
    goto L2; // [319] 347
LB: 

    /** 	    t = Scanner()*/
    _0 = _t_54615;
    _t_54615 = _60Scanner();
    DeRef(_0);

    /** 	    if Parser_mode = PAM_RECORD then*/
    if (_12Parser_mode_11788 != 1)
    goto LC; // [333] 346

    /** 	        canned_tokens = append(canned_tokens,t)*/
    Ref(_t_54615);
    Append(&_30canned_tokens_53729, _30canned_tokens_53729, _t_54615);
LC: 
L2: 

    /** 	putback_fwd_line_number = 0*/
    _12putback_fwd_line_number_11685 = 0;

    /** 	return t*/
    DeRef(_s_54616);
    DeRef(_28042);
    _28042 = NOVALUE;
    DeRef(_28043);
    _28043 = NOVALUE;
    DeRef(_28040);
    _28040 = NOVALUE;
    return _t_54615;
    ;
}


int _30Expr_list()
{
    int _tok_54698 = NOVALUE;
    int _n_54699 = NOVALUE;
    int _28059 = NOVALUE;
    int _28056 = NOVALUE;
    int _28055 = NOVALUE;
    int _28053 = NOVALUE;
    int _28052 = NOVALUE;
    int _28048 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_54698;
    _tok_54698 = _30next_token();
    DeRef(_0);

    /** 	putback(tok)*/
    Ref(_tok_54698);
    _30putback(_tok_54698);

    /** 	if tok[T_ID] = RIGHT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_54698);
    _28048 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28048, -25)){
        _28048 = NOVALUE;
        goto L1; // [23] 36
    }
    _28048 = NOVALUE;

    /** 		return 0*/
    DeRef(_tok_54698);
    return 0;
    goto L2; // [33] 142
L1: 

    /** 		n = 0*/
    _n_54699 = 0;

    /** 		short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 		while TRUE do*/
L3: 
    if (_9TRUE_431 == 0)
    {
        goto L4; // [56] 133
    }
    else{
    }

    /** 			gListItem &= 1*/
    Append(&_30gListItem_53721, _30gListItem_53721, 1);

    /** 			Expr()*/
    _30Expr();

    /** 			n += gListItem[$]*/
    if (IS_SEQUENCE(_30gListItem_53721)){
            _28052 = SEQ_PTR(_30gListItem_53721)->length;
    }
    else {
        _28052 = 1;
    }
    _2 = (int)SEQ_PTR(_30gListItem_53721);
    _28053 = (int)*(((s1_ptr)_2)->base + _28052);
    _n_54699 = _n_54699 + _28053;
    _28053 = NOVALUE;

    /** 			gListItem = gListItem[1 .. $-1]*/
    if (IS_SEQUENCE(_30gListItem_53721)){
            _28055 = SEQ_PTR(_30gListItem_53721)->length;
    }
    else {
        _28055 = 1;
    }
    _28056 = _28055 - 1;
    _28055 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30gListItem_53721;
    RHS_Slice(_30gListItem_53721, 1, _28056);

    /** 			tok = next_token()*/
    _0 = _tok_54698;
    _tok_54698 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_54698);
    _28059 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28059, -30)){
        _28059 = NOVALUE;
        goto L3; // [119] 54
    }
    _28059 = NOVALUE;

    /** 				exit*/
    goto L4; // [125] 133

    /** 		end while*/
    goto L3; // [130] 54
L4: 

    /** 		short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;
L2: 

    /** 	putback(tok)*/
    Ref(_tok_54698);
    _30putback(_tok_54698);

    /** 	return n*/
    DeRef(_tok_54698);
    DeRef(_28056);
    _28056 = NOVALUE;
    return _n_54699;
    ;
}


void _30tok_match(int _tok_54727, int _prevtok_54728)
{
    int _t_54730 = NOVALUE;
    int _expected_54731 = NOVALUE;
    int _actual_54732 = NOVALUE;
    int _prevname_54733 = NOVALUE;
    int _28071 = NOVALUE;
    int _28069 = NOVALUE;
    int _28066 = NOVALUE;
    int _28063 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence expected, actual, prevname*/

    /** 	t = next_token()*/
    _0 = _t_54730;
    _t_54730 = _30next_token();
    DeRef(_0);

    /** 	if t[T_ID] != tok then*/
    _2 = (int)SEQ_PTR(_t_54730);
    _28063 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28063, _tok_54727)){
        _28063 = NOVALUE;
        goto L1; // [20] 92
    }
    _28063 = NOVALUE;

    /** 		expected = LexName(tok)*/
    RefDS(_26196);
    _0 = _expected_54731;
    _expected_54731 = _37LexName(_tok_54727, _26196);
    DeRef(_0);

    /** 		actual = LexName(t[T_ID])*/
    _2 = (int)SEQ_PTR(_t_54730);
    _28066 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28066);
    RefDS(_26196);
    _0 = _actual_54732;
    _actual_54732 = _37LexName(_28066, _26196);
    DeRef(_0);
    _28066 = NOVALUE;

    /** 		if prevtok = 0 then*/
    if (_prevtok_54728 != 0)
    goto L2; // [50] 68

    /** 			CompileErr(132, {expected, actual})*/
    RefDS(_actual_54732);
    RefDS(_expected_54731);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _expected_54731;
    ((int *)_2)[2] = _actual_54732;
    _28069 = MAKE_SEQ(_1);
    _43CompileErr(132, _28069, 0);
    _28069 = NOVALUE;
    goto L3; // [65] 91
L2: 

    /** 			prevname = LexName(prevtok)*/
    RefDS(_26196);
    _0 = _prevname_54733;
    _prevname_54733 = _37LexName(_prevtok_54728, _26196);
    DeRef(_0);

    /** 			CompileErr(138, {expected, prevname, actual})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_expected_54731);
    *((int *)(_2+4)) = _expected_54731;
    RefDS(_prevname_54733);
    *((int *)(_2+8)) = _prevname_54733;
    RefDS(_actual_54732);
    *((int *)(_2+12)) = _actual_54732;
    _28071 = MAKE_SEQ(_1);
    _43CompileErr(138, _28071, 0);
    _28071 = NOVALUE;
L3: 
L1: 

    /** end procedure*/
    DeRef(_t_54730);
    DeRef(_expected_54731);
    DeRef(_actual_54732);
    DeRef(_prevname_54733);
    return;
    ;
}


void _30UndefinedVar(int _s_54767)
{
    int _dup_54769 = NOVALUE;
    int _errmsg_54770 = NOVALUE;
    int _rname_54771 = NOVALUE;
    int _fname_54772 = NOVALUE;
    int _28094 = NOVALUE;
    int _28093 = NOVALUE;
    int _28091 = NOVALUE;
    int _28089 = NOVALUE;
    int _28088 = NOVALUE;
    int _28086 = NOVALUE;
    int _28084 = NOVALUE;
    int _28082 = NOVALUE;
    int _28081 = NOVALUE;
    int _28080 = NOVALUE;
    int _28079 = NOVALUE;
    int _28078 = NOVALUE;
    int _28076 = NOVALUE;
    int _28075 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_54767)) {
        _1 = (long)(DBL_PTR(_s_54767)->dbl);
        DeRefDS(_s_54767);
        _s_54767 = _1;
    }

    /** 	sequence errmsg*/

    /** 	sequence rname*/

    /** 	sequence fname*/

    /** 	if SymTab[s][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28075 = (int)*(((s1_ptr)_2)->base + _s_54767);
    _2 = (int)SEQ_PTR(_28075);
    _28076 = (int)*(((s1_ptr)_2)->base + 4);
    _28075 = NOVALUE;
    if (binary_op_a(NOTEQ, _28076, 9)){
        _28076 = NOVALUE;
        goto L1; // [25] 55
    }
    _28076 = NOVALUE;

    /** 		CompileErr(19, {SymTab[s][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28078 = (int)*(((s1_ptr)_2)->base + _s_54767);
    _2 = (int)SEQ_PTR(_28078);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28079 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28079 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28078 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28079);
    *((int *)(_2+4)) = _28079;
    _28080 = MAKE_SEQ(_1);
    _28079 = NOVALUE;
    _43CompileErr(19, _28080, 0);
    _28080 = NOVALUE;
    goto L2; // [52] 202
L1: 

    /** 	elsif SymTab[s][S_SCOPE] = SC_MULTIPLY_DEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28081 = (int)*(((s1_ptr)_2)->base + _s_54767);
    _2 = (int)SEQ_PTR(_28081);
    _28082 = (int)*(((s1_ptr)_2)->base + 4);
    _28081 = NOVALUE;
    if (binary_op_a(NOTEQ, _28082, 10)){
        _28082 = NOVALUE;
        goto L3; // [71] 179
    }
    _28082 = NOVALUE;

    /** 		rname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28084 = (int)*(((s1_ptr)_2)->base + _s_54767);
    DeRef(_rname_54771);
    _2 = (int)SEQ_PTR(_28084);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _rname_54771 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _rname_54771 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_rname_54771);
    _28084 = NOVALUE;

    /** 		errmsg = ""*/
    RefDS(_21829);
    DeRef(_errmsg_54770);
    _errmsg_54770 = _21829;

    /** 		for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _28086 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _28086 = 1;
    }
    {
        int _i_54798;
        _i_54798 = 1;
L4: 
        if (_i_54798 > _28086){
            goto L5; // [105] 163
        }

        /** 			dup = dup_globals[i]*/
        _2 = (int)SEQ_PTR(_52dup_globals_46892);
        _dup_54769 = (int)*(((s1_ptr)_2)->base + _i_54798);
        if (!IS_ATOM_INT(_dup_54769)){
            _dup_54769 = (long)DBL_PTR(_dup_54769)->dbl;
        }

        /** 			fname = known_files[SymTab[dup][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28088 = (int)*(((s1_ptr)_2)->base + _dup_54769);
        _2 = (int)SEQ_PTR(_28088);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _28089 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _28089 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _28088 = NOVALUE;
        DeRef(_fname_54772);
        _2 = (int)SEQ_PTR(_13known_files_10637);
        if (!IS_ATOM_INT(_28089)){
            _fname_54772 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28089)->dbl));
        }
        else{
            _fname_54772 = (int)*(((s1_ptr)_2)->base + _28089);
        }
        Ref(_fname_54772);

        /** 			errmsg &= "    " & fname & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _21981;
            concat_list[1] = _fname_54772;
            concat_list[2] = _24751;
            Concat_N((object_ptr)&_28091, concat_list, 3);
        }
        Concat((object_ptr)&_errmsg_54770, _errmsg_54770, _28091);
        DeRefDS(_28091);
        _28091 = NOVALUE;

        /** 		end for*/
        _i_54798 = _i_54798 + 1;
        goto L4; // [158] 112
L5: 
        ;
    }

    /** 		CompileErr(23, {rname, rname, errmsg})*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_rname_54771, 2);
    *((int *)(_2+4)) = _rname_54771;
    *((int *)(_2+8)) = _rname_54771;
    RefDS(_errmsg_54770);
    *((int *)(_2+12)) = _errmsg_54770;
    _28093 = MAKE_SEQ(_1);
    _43CompileErr(23, _28093, 0);
    _28093 = NOVALUE;
    goto L2; // [176] 202
L3: 

    /** 	elsif length(symbol_resolution_warning) then*/
    if (IS_SEQUENCE(_12symbol_resolution_warning_11784)){
            _28094 = SEQ_PTR(_12symbol_resolution_warning_11784)->length;
    }
    else {
        _28094 = 1;
    }
    if (_28094 == 0)
    {
        _28094 = NOVALUE;
        goto L6; // [186] 201
    }
    else{
        _28094 = NOVALUE;
    }

    /** 		Warning( symbol_resolution_warning, resolution_warning_flag)*/
    RefDS(_12symbol_resolution_warning_11784);
    RefDS(_21829);
    _43Warning(_12symbol_resolution_warning_11784, 1, _21829);
L6: 
L2: 

    /** end procedure*/
    DeRef(_errmsg_54770);
    DeRef(_rname_54771);
    DeRef(_fname_54772);
    _28089 = NOVALUE;
    return;
    ;
}


void _30WrongNumberArgs(int _subsym_54822, int _only_54823)
{
    int _msgno_54824 = NOVALUE;
    int _28106 = NOVALUE;
    int _28105 = NOVALUE;
    int _28104 = NOVALUE;
    int _28103 = NOVALUE;
    int _28102 = NOVALUE;
    int _28100 = NOVALUE;
    int _28098 = NOVALUE;
    int _28096 = NOVALUE;
    int _28095 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54822)) {
        _1 = (long)(DBL_PTR(_subsym_54822)->dbl);
        DeRefDS(_subsym_54822);
        _subsym_54822 = _1;
    }

    /** 	if SymTab[subsym][S_NUM_ARGS] = 1 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28095 = (int)*(((s1_ptr)_2)->base + _subsym_54822);
    _2 = (int)SEQ_PTR(_28095);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _28096 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _28096 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _28095 = NOVALUE;
    if (binary_op_a(NOTEQ, _28096, 1)){
        _28096 = NOVALUE;
        goto L1; // [19] 49
    }
    _28096 = NOVALUE;

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_54823)){
            _28098 = SEQ_PTR(_only_54823)->length;
    }
    else {
        _28098 = 1;
    }
    if (_28098 != 0)
    goto L2; // [28] 40

    /** 			msgno = 20*/
    _msgno_54824 = 20;
    goto L3; // [37] 73
L2: 

    /** 			msgno = 237*/
    _msgno_54824 = 237;
    goto L3; // [46] 73
L1: 

    /** 		if length(only) = 0 then*/
    if (IS_SEQUENCE(_only_54823)){
            _28100 = SEQ_PTR(_only_54823)->length;
    }
    else {
        _28100 = 1;
    }
    if (_28100 != 0)
    goto L4; // [54] 66

    /** 			msgno = 236*/
    _msgno_54824 = 236;
    goto L5; // [63] 72
L4: 

    /** 			msgno = 238*/
    _msgno_54824 = 238;
L5: 
L3: 

    /** 	CompileErr(msgno, {SymTab[subsym][S_NAME], SymTab[subsym][S_NUM_ARGS]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28102 = (int)*(((s1_ptr)_2)->base + _subsym_54822);
    _2 = (int)SEQ_PTR(_28102);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28103 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28103 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28102 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28104 = (int)*(((s1_ptr)_2)->base + _subsym_54822);
    _2 = (int)SEQ_PTR(_28104);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _28105 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _28105 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _28104 = NOVALUE;
    Ref(_28105);
    Ref(_28103);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28103;
    ((int *)_2)[2] = _28105;
    _28106 = MAKE_SEQ(_1);
    _28105 = NOVALUE;
    _28103 = NOVALUE;
    _43CompileErr(_msgno_54824, _28106, 0);
    _28106 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_only_54823);
    return;
    ;
}


void _30MissingArgs(int _subsym_54853)
{
    int _eentry_54854 = NOVALUE;
    int _28111 = NOVALUE;
    int _28110 = NOVALUE;
    int _28109 = NOVALUE;
    int _28108 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence eentry = SymTab[subsym]*/
    DeRef(_eentry_54854);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _eentry_54854 = (int)*(((s1_ptr)_2)->base + _subsym_54853);
    Ref(_eentry_54854);

    /** 	CompileErr(235, {eentry[S_NAME], eentry[S_DEF_ARGS][2]})*/
    _2 = (int)SEQ_PTR(_eentry_54854);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28108 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28108 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _2 = (int)SEQ_PTR(_eentry_54854);
    _28109 = (int)*(((s1_ptr)_2)->base + 28);
    _2 = (int)SEQ_PTR(_28109);
    _28110 = (int)*(((s1_ptr)_2)->base + 2);
    _28109 = NOVALUE;
    Ref(_28110);
    Ref(_28108);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28108;
    ((int *)_2)[2] = _28110;
    _28111 = MAKE_SEQ(_1);
    _28110 = NOVALUE;
    _28108 = NOVALUE;
    _43CompileErr(235, _28111, 0);
    _28111 = NOVALUE;

    /** end procedure*/
    DeRefDS(_eentry_54854);
    return;
    ;
}


void _30Parse_default_arg(int _subsym_54867, int _arg_54868, int _fwd_private_list_54869, int _fwd_private_sym_54870)
{
    int _param_54872 = NOVALUE;
    int _28131 = NOVALUE;
    int _28130 = NOVALUE;
    int _28129 = NOVALUE;
    int _28128 = NOVALUE;
    int _28127 = NOVALUE;
    int _28126 = NOVALUE;
    int _28125 = NOVALUE;
    int _28124 = NOVALUE;
    int _28123 = NOVALUE;
    int _28122 = NOVALUE;
    int _28121 = NOVALUE;
    int _28120 = NOVALUE;
    int _28119 = NOVALUE;
    int _28117 = NOVALUE;
    int _28116 = NOVALUE;
    int _28113 = NOVALUE;
    int _28112 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54867)) {
        _1 = (long)(DBL_PTR(_subsym_54867)->dbl);
        DeRefDS(_subsym_54867);
        _subsym_54867 = _1;
    }
    if (!IS_ATOM_INT(_arg_54868)) {
        _1 = (long)(DBL_PTR(_arg_54868)->dbl);
        DeRefDS(_arg_54868);
        _arg_54868 = _1;
    }

    /** 	symtab_index param = subsym*/
    _param_54872 = _subsym_54867;

    /** 	on_arg = arg*/
    _30on_arg_54409 = _arg_54868;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_30private_list_54407)){
            _28112 = SEQ_PTR(_30private_list_54407)->length;
    }
    else {
        _28112 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28112;
    *((int *)(_2+8)) = _30lock_scanner_54408;
    *((int *)(_2+12)) = _12use_private_list_11796;
    *((int *)(_2+16)) = _30on_arg_54409;
    _28113 = MAKE_SEQ(_1);
    _28112 = NOVALUE;
    RefDS(_28113);
    Append(&_30parseargs_states_54402, _30parseargs_states_54402, _28113);
    DeRefDS(_28113);
    _28113 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_30nested_calls_54410, _30nested_calls_54410, _subsym_54867);

    /** 	for i = 1 to arg do*/
    _28116 = _arg_54868;
    {
        int _i_54879;
        _i_54879 = 1;
L1: 
        if (_i_54879 > _28116){
            goto L2; // [60] 90
        }

        /** 		param = SymTab[param][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28117 = (int)*(((s1_ptr)_2)->base + _param_54872);
        _2 = (int)SEQ_PTR(_28117);
        _param_54872 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_54872)){
            _param_54872 = (long)DBL_PTR(_param_54872)->dbl;
        }
        _28117 = NOVALUE;

        /** 	end for*/
        _i_54879 = _i_54879 + 1;
        goto L1; // [85] 67
L2: 
        ;
    }

    /** 	private_list = fwd_private_list*/
    RefDS(_fwd_private_list_54869);
    DeRef(_30private_list_54407);
    _30private_list_54407 = _fwd_private_list_54869;

    /** 	private_sym  = fwd_private_sym*/
    RefDS(_fwd_private_sym_54870);
    DeRef(_12private_sym_11795);
    _12private_sym_11795 = _fwd_private_sym_54870;

    /** 	if atom(SymTab[param][S_CODE]) then  -- but no default set*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28119 = (int)*(((s1_ptr)_2)->base + _param_54872);
    _2 = (int)SEQ_PTR(_28119);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _28120 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _28120 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _28119 = NOVALUE;
    _28121 = IS_ATOM(_28120);
    _28120 = NOVALUE;
    if (_28121 == 0)
    {
        _28121 = NOVALUE;
        goto L3; // [121] 162
    }
    else{
        _28121 = NOVALUE;
    }

    /** 		CompileErr(26, {arg, SymTab[subsym][S_NAME], SymTab[param][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28122 = (int)*(((s1_ptr)_2)->base + _subsym_54867);
    _2 = (int)SEQ_PTR(_28122);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28123 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28123 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28122 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28124 = (int)*(((s1_ptr)_2)->base + _param_54872);
    _2 = (int)SEQ_PTR(_28124);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28125 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28125 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28124 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _arg_54868;
    Ref(_28123);
    *((int *)(_2+8)) = _28123;
    Ref(_28125);
    *((int *)(_2+12)) = _28125;
    _28126 = MAKE_SEQ(_1);
    _28125 = NOVALUE;
    _28123 = NOVALUE;
    _43CompileErr(26, _28126, 0);
    _28126 = NOVALUE;
L3: 

    /** 	use_private_list = 1*/
    _12use_private_list_11796 = 1;

    /** 	lock_scanner = 1*/
    _30lock_scanner_54408 = 1;

    /** 	start_playback(SymTab[param][S_CODE] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28127 = (int)*(((s1_ptr)_2)->base + _param_54872);
    _2 = (int)SEQ_PTR(_28127);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _28128 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _28128 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _28127 = NOVALUE;
    Ref(_28128);
    _30start_playback(_28128);
    _28128 = NOVALUE;

    /** 	call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_54694].addr;
    (*(int (*)())_0)(
                         );

    /** 	add_private_symbol( Top(), SymTab[param][S_NAME] )*/
    _28129 = _37Top();
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28130 = (int)*(((s1_ptr)_2)->base + _param_54872);
    _2 = (int)SEQ_PTR(_28130);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28131 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28131 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28130 = NOVALUE;
    Ref(_28131);
    _29add_private_symbol(_28129, _28131);
    _28129 = NOVALUE;
    _28131 = NOVALUE;

    /** 	lock_scanner = 0*/
    _30lock_scanner_54408 = 0;

    /** 	restore_parseargs_states()*/
    _30restore_parseargs_states();

    /** end procedure*/
    DeRefDS(_fwd_private_list_54869);
    DeRefDS(_fwd_private_sym_54870);
    return;
    ;
}


void _30ParseArgs(int _subsym_54917)
{
    int _n_54918 = NOVALUE;
    int _fda_54919 = NOVALUE;
    int _lnda_54920 = NOVALUE;
    int _tok_54922 = NOVALUE;
    int _s_54924 = NOVALUE;
    int _var_code_54925 = NOVALUE;
    int _name_54926 = NOVALUE;
    int _28225 = NOVALUE;
    int _28223 = NOVALUE;
    int _28219 = NOVALUE;
    int _28218 = NOVALUE;
    int _28217 = NOVALUE;
    int _28214 = NOVALUE;
    int _28211 = NOVALUE;
    int _28209 = NOVALUE;
    int _28207 = NOVALUE;
    int _28205 = NOVALUE;
    int _28203 = NOVALUE;
    int _28202 = NOVALUE;
    int _28201 = NOVALUE;
    int _28200 = NOVALUE;
    int _28199 = NOVALUE;
    int _28198 = NOVALUE;
    int _28197 = NOVALUE;
    int _28191 = NOVALUE;
    int _28189 = NOVALUE;
    int _28186 = NOVALUE;
    int _28183 = NOVALUE;
    int _28178 = NOVALUE;
    int _28176 = NOVALUE;
    int _28175 = NOVALUE;
    int _28174 = NOVALUE;
    int _28172 = NOVALUE;
    int _28169 = NOVALUE;
    int _28166 = NOVALUE;
    int _28164 = NOVALUE;
    int _28162 = NOVALUE;
    int _28160 = NOVALUE;
    int _28158 = NOVALUE;
    int _28157 = NOVALUE;
    int _28156 = NOVALUE;
    int _28155 = NOVALUE;
    int _28154 = NOVALUE;
    int _28153 = NOVALUE;
    int _28152 = NOVALUE;
    int _28150 = NOVALUE;
    int _28148 = NOVALUE;
    int _28144 = NOVALUE;
    int _28143 = NOVALUE;
    int _28141 = NOVALUE;
    int _28140 = NOVALUE;
    int _28138 = NOVALUE;
    int _28137 = NOVALUE;
    int _28136 = NOVALUE;
    int _28135 = NOVALUE;
    int _28134 = NOVALUE;
    int _28132 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_subsym_54917)) {
        _1 = (long)(DBL_PTR(_subsym_54917)->dbl);
        DeRefDS(_subsym_54917);
        _subsym_54917 = _1;
    }

    /** 	object var_code*/

    /** 	sequence name*/

    /** 	n = SymTab[subsym][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28132 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
    _2 = (int)SEQ_PTR(_28132);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _n_54918 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _n_54918 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_n_54918)){
        _n_54918 = (long)DBL_PTR(_n_54918)->dbl;
    }
    _28132 = NOVALUE;

    /** 	if sequence(SymTab[subsym][S_DEF_ARGS]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28134 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
    _2 = (int)SEQ_PTR(_28134);
    _28135 = (int)*(((s1_ptr)_2)->base + 28);
    _28134 = NOVALUE;
    _28136 = IS_SEQUENCE(_28135);
    _28135 = NOVALUE;
    if (_28136 == 0)
    {
        _28136 = NOVALUE;
        goto L1; // [40] 86
    }
    else{
        _28136 = NOVALUE;
    }

    /** 		fda = SymTab[subsym][S_DEF_ARGS][1]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28137 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
    _2 = (int)SEQ_PTR(_28137);
    _28138 = (int)*(((s1_ptr)_2)->base + 28);
    _28137 = NOVALUE;
    _2 = (int)SEQ_PTR(_28138);
    _fda_54919 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_fda_54919)){
        _fda_54919 = (long)DBL_PTR(_fda_54919)->dbl;
    }
    _28138 = NOVALUE;

    /** 		lnda = SymTab[subsym][S_DEF_ARGS][2]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28140 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
    _2 = (int)SEQ_PTR(_28140);
    _28141 = (int)*(((s1_ptr)_2)->base + 28);
    _28140 = NOVALUE;
    _2 = (int)SEQ_PTR(_28141);
    _lnda_54920 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_lnda_54920)){
        _lnda_54920 = (long)DBL_PTR(_lnda_54920)->dbl;
    }
    _28141 = NOVALUE;
    goto L2; // [83] 97
L1: 

    /** 		fda = 0*/
    _fda_54919 = 0;

    /** 		lnda = 0*/
    _lnda_54920 = 0;
L2: 

    /** 	s = subsym*/
    _s_54924 = _subsym_54917;

    /** 	parseargs_states = append(parseargs_states,*/
    if (IS_SEQUENCE(_30private_list_54407)){
            _28143 = SEQ_PTR(_30private_list_54407)->length;
    }
    else {
        _28143 = 1;
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28143;
    *((int *)(_2+8)) = _30lock_scanner_54408;
    *((int *)(_2+12)) = _12use_private_list_11796;
    *((int *)(_2+16)) = _30on_arg_54409;
    _28144 = MAKE_SEQ(_1);
    _28143 = NOVALUE;
    RefDS(_28144);
    Append(&_30parseargs_states_54402, _30parseargs_states_54402, _28144);
    DeRefDS(_28144);
    _28144 = NOVALUE;

    /** 	nested_calls &= subsym*/
    Append(&_30nested_calls_54410, _30nested_calls_54410, _subsym_54917);

    /** 	lock_scanner = 0*/
    _30lock_scanner_54408 = 0;

    /** 	on_arg = 0*/
    _30on_arg_54409 = 0;

    /** 	short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 	for i = 1 to n do*/
    _28148 = _n_54918;
    {
        int _i_54955;
        _i_54955 = 1;
L3: 
        if (_i_54955 > _28148){
            goto L4; // [161] 915
        }

        /** 	  	tok = next_token()*/
        _0 = _tok_54922;
        _tok_54922 = _30next_token();
        DeRef(_0);

        /** 		if tok[T_ID] = COMMA then*/
        _2 = (int)SEQ_PTR(_tok_54922);
        _28150 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28150, -30)){
            _28150 = NOVALUE;
            goto L5; // [183] 392
        }
        _28150 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28152 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28152);
        _28153 = (int)*(((s1_ptr)_2)->base + 21);
        _28152 = NOVALUE;
        if (_28153 == 0) {
            _28153 = NOVALUE;
            goto L6; // [201] 261
        }
        else {
            if (!IS_ATOM_INT(_28153) && DBL_PTR(_28153)->dbl == 0.0){
                _28153 = NOVALUE;
                goto L6; // [201] 261
            }
            _28153 = NOVALUE;
        }
        _28153 = NOVALUE;

        /** 				if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28154 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28154);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _28155 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _28155 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        _28154 = NOVALUE;
        _28156 = IS_ATOM(_28155);
        _28155 = NOVALUE;
        if (_28156 == 0)
        {
            _28156 = NOVALUE;
            goto L7; // [221] 232
        }
        else{
            _28156 = NOVALUE;
        }

        /** 					var_code = 0*/
        DeRef(_var_code_54925);
        _var_code_54925 = 0;
        goto L8; // [229] 251
L7: 

        /** 					var_code = SymTab[subsym][S_CODE][i]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28157 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28157);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _28158 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _28158 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        _28157 = NOVALUE;
        DeRef(_var_code_54925);
        _2 = (int)SEQ_PTR(_28158);
        _var_code_54925 = (int)*(((s1_ptr)_2)->base + _i_54955);
        Ref(_var_code_54925);
        _28158 = NOVALUE;
L8: 

        /** 				name = ""*/
        RefDS(_21829);
        DeRef(_name_54926);
        _name_54926 = _21829;
        goto L9; // [258] 308
L6: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28160 = (int)*(((s1_ptr)_2)->base + _s_54924);
        _2 = (int)SEQ_PTR(_28160);
        _s_54924 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54924)){
            _s_54924 = (long)DBL_PTR(_s_54924)->dbl;
        }
        _28160 = NOVALUE;

        /** 				var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28162 = (int)*(((s1_ptr)_2)->base + _s_54924);
        DeRef(_var_code_54925);
        _2 = (int)SEQ_PTR(_28162);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _var_code_54925 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _var_code_54925 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        Ref(_var_code_54925);
        _28162 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28164 = (int)*(((s1_ptr)_2)->base + _s_54924);
        DeRef(_name_54926);
        _2 = (int)SEQ_PTR(_28164);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _name_54926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _name_54926 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        Ref(_name_54926);
        _28164 = NOVALUE;
L9: 

        /** 			if atom(var_code) then  -- but no default set*/
        _28166 = IS_ATOM(_var_code_54925);
        if (_28166 == 0)
        {
            _28166 = NOVALUE;
            goto LA; // [315] 326
        }
        else{
            _28166 = NOVALUE;
        }

        /** 				CompileErr(29,i)*/
        _43CompileErr(29, _i_54955, 0);
LA: 

        /** 			use_private_list = 1*/
        _12use_private_list_11796 = 1;

        /** 			start_playback(var_code)*/
        Ref(_var_code_54925);
        _30start_playback(_var_code_54925);

        /** 			lock_scanner=1*/
        _30lock_scanner_54408 = 1;

        /** 			Expr()*/
        _30Expr();

        /** 			lock_scanner=0*/
        _30lock_scanner_54408 = 0;

        /** 			on_arg += 1*/
        _30on_arg_54409 = _30on_arg_54409 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_54926);
        Append(&_30private_list_54407, _30private_list_54407, _name_54926);

        /** 			private_sym &= Top()*/
        _28169 = _37Top();
        if (IS_SEQUENCE(_12private_sym_11795) && IS_ATOM(_28169)) {
            Ref(_28169);
            Append(&_12private_sym_11795, _12private_sym_11795, _28169);
        }
        else if (IS_ATOM(_12private_sym_11795) && IS_SEQUENCE(_28169)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_11795, _12private_sym_11795, _28169);
        }
        DeRef(_28169);
        _28169 = NOVALUE;

        /** 			backed_up_tok = {tok} -- ????*/
        _0 = _30backed_up_tok_53692;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_tok_54922);
        *((int *)(_2+4)) = _tok_54922;
        _30backed_up_tok_53692 = MAKE_SEQ(_1);
        DeRef(_0);
        goto LB; // [389] 520
L5: 

        /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54922);
        _28172 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28172, -27)){
            _28172 = NOVALUE;
            goto LC; // [402] 519
        }
        _28172 = NOVALUE;

        /** 			if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28174 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28174);
        _28175 = (int)*(((s1_ptr)_2)->base + 21);
        _28174 = NOVALUE;
        if (_28175 == 0) {
            _28175 = NOVALUE;
            goto LD; // [420] 433
        }
        else {
            if (!IS_ATOM_INT(_28175) && DBL_PTR(_28175)->dbl == 0.0){
                _28175 = NOVALUE;
                goto LD; // [420] 433
            }
            _28175 = NOVALUE;
        }
        _28175 = NOVALUE;

        /** 				name = ""*/
        RefDS(_21829);
        DeRef(_name_54926);
        _name_54926 = _21829;
        goto LE; // [430] 466
LD: 

        /** 				s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28176 = (int)*(((s1_ptr)_2)->base + _s_54924);
        _2 = (int)SEQ_PTR(_28176);
        _s_54924 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54924)){
            _s_54924 = (long)DBL_PTR(_s_54924)->dbl;
        }
        _28176 = NOVALUE;

        /** 				name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28178 = (int)*(((s1_ptr)_2)->base + _s_54924);
        DeRef(_name_54926);
        _2 = (int)SEQ_PTR(_28178);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _name_54926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _name_54926 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        Ref(_name_54926);
        _28178 = NOVALUE;
LE: 

        /** 			use_private_list = Parser_mode != PAM_NORMAL*/
        _12use_private_list_11796 = (_12Parser_mode_11788 != 0);

        /** 			putback(tok)*/
        Ref(_tok_54922);
        _30putback(_tok_54922);

        /** 			Expr()*/
        _30Expr();

        /** 			on_arg += 1*/
        _30on_arg_54409 = _30on_arg_54409 + 1;

        /** 			private_list = append(private_list,name)*/
        RefDS(_name_54926);
        Append(&_30private_list_54407, _30private_list_54407, _name_54926);

        /** 			private_sym &= Top()*/
        _28183 = _37Top();
        if (IS_SEQUENCE(_12private_sym_11795) && IS_ATOM(_28183)) {
            Ref(_28183);
            Append(&_12private_sym_11795, _12private_sym_11795, _28183);
        }
        else if (IS_ATOM(_12private_sym_11795) && IS_SEQUENCE(_28183)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_11795, _12private_sym_11795, _28183);
        }
        DeRef(_28183);
        _28183 = NOVALUE;
LC: 
LB: 

        /** 		if on_arg != n then*/
        if (_30on_arg_54409 == _n_54918)
        goto LF; // [524] 908

        /** 			if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54922);
        _28186 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28186, -27)){
            _28186 = NOVALUE;
            goto L10; // [538] 548
        }
        _28186 = NOVALUE;

        /** 				putback( tok )*/
        Ref(_tok_54922);
        _30putback(_tok_54922);
L10: 

        /** 			tok = next_token()*/
        _0 = _tok_54922;
        _tok_54922 = _30next_token();
        DeRef(_0);

        /** 			if tok[T_ID] != COMMA then*/
        _2 = (int)SEQ_PTR(_tok_54922);
        _28189 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _28189, -30)){
            _28189 = NOVALUE;
            goto L11; // [563] 907
        }
        _28189 = NOVALUE;

        /** 		  		if tok[T_ID] = RIGHT_ROUND then*/
        _2 = (int)SEQ_PTR(_tok_54922);
        _28191 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28191, -27)){
            _28191 = NOVALUE;
            goto L12; // [577] 892
        }
        _28191 = NOVALUE;

        /** 					if fda=0 then*/
        if (_fda_54919 != 0)
        goto L13; // [585] 598

        /** 						WrongNumberArgs(subsym, "")*/
        RefDS(_21829);
        _30WrongNumberArgs(_subsym_54917, _21829);
        goto L14; // [595] 613
L13: 

        /** 					elsif i<lnda then*/
        if (_i_54955 >= _lnda_54920)
        goto L15; // [602] 612

        /** 						MissingArgs(subsym)*/
        _30MissingArgs(_subsym_54917);
L15: 
L14: 

        /** 					lock_scanner = 1*/
        _30lock_scanner_54408 = 1;

        /** 					use_private_list = 1*/
        _12use_private_list_11796 = 1;

        /** 					while on_arg < n do*/
L16: 
        if (_30on_arg_54409 >= _n_54918)
        goto L17; // [632] 841

        /** 						on_arg += 1*/
        _30on_arg_54409 = _30on_arg_54409 + 1;

        /** 						if SymTab[subsym][S_OPCODE] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28197 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28197);
        _28198 = (int)*(((s1_ptr)_2)->base + 21);
        _28197 = NOVALUE;
        if (_28198 == 0) {
            _28198 = NOVALUE;
            goto L18; // [658] 720
        }
        else {
            if (!IS_ATOM_INT(_28198) && DBL_PTR(_28198)->dbl == 0.0){
                _28198 = NOVALUE;
                goto L18; // [658] 720
            }
            _28198 = NOVALUE;
        }
        _28198 = NOVALUE;

        /** 							if atom(SymTab[subsym][S_CODE]) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28199 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28199);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _28200 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _28200 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        _28199 = NOVALUE;
        _28201 = IS_ATOM(_28200);
        _28200 = NOVALUE;
        if (_28201 == 0)
        {
            _28201 = NOVALUE;
            goto L19; // [678] 689
        }
        else{
            _28201 = NOVALUE;
        }

        /** 								var_code = 0*/
        DeRef(_var_code_54925);
        _var_code_54925 = 0;
        goto L1A; // [686] 710
L19: 

        /** 								var_code = SymTab[subsym][S_CODE][on_arg]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28202 = (int)*(((s1_ptr)_2)->base + _subsym_54917);
        _2 = (int)SEQ_PTR(_28202);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _28203 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _28203 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        _28202 = NOVALUE;
        DeRef(_var_code_54925);
        _2 = (int)SEQ_PTR(_28203);
        _var_code_54925 = (int)*(((s1_ptr)_2)->base + _30on_arg_54409);
        Ref(_var_code_54925);
        _28203 = NOVALUE;
L1A: 

        /** 							name = ""*/
        RefDS(_21829);
        DeRef(_name_54926);
        _name_54926 = _21829;
        goto L1B; // [717] 767
L18: 

        /** 							s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28205 = (int)*(((s1_ptr)_2)->base + _s_54924);
        _2 = (int)SEQ_PTR(_28205);
        _s_54924 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_54924)){
            _s_54924 = (long)DBL_PTR(_s_54924)->dbl;
        }
        _28205 = NOVALUE;

        /** 							var_code = SymTab[s][S_CODE]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28207 = (int)*(((s1_ptr)_2)->base + _s_54924);
        DeRef(_var_code_54925);
        _2 = (int)SEQ_PTR(_28207);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _var_code_54925 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _var_code_54925 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        Ref(_var_code_54925);
        _28207 = NOVALUE;

        /** 							name = SymTab[s][S_NAME]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28209 = (int)*(((s1_ptr)_2)->base + _s_54924);
        DeRef(_name_54926);
        _2 = (int)SEQ_PTR(_28209);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _name_54926 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _name_54926 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        Ref(_name_54926);
        _28209 = NOVALUE;
L1B: 

        /** 						if sequence(var_code) then*/
        _28211 = IS_SEQUENCE(_var_code_54925);
        if (_28211 == 0)
        {
            _28211 = NOVALUE;
            goto L1C; // [774] 826
        }
        else{
            _28211 = NOVALUE;
        }

        /** 							putback( tok )*/
        Ref(_tok_54922);
        _30putback(_tok_54922);

        /** 							start_playback(var_code)*/
        Ref(_var_code_54925);
        _30start_playback(_var_code_54925);

        /** 							Expr()*/
        _30Expr();

        /** 							if on_arg < n then*/
        if (_30on_arg_54409 >= _n_54918)
        goto L16; // [795] 630

        /** 								private_list = append(private_list,name)*/
        RefDS(_name_54926);
        Append(&_30private_list_54407, _30private_list_54407, _name_54926);

        /** 								private_sym &= Top()*/
        _28214 = _37Top();
        if (IS_SEQUENCE(_12private_sym_11795) && IS_ATOM(_28214)) {
            Ref(_28214);
            Append(&_12private_sym_11795, _12private_sym_11795, _28214);
        }
        else if (IS_ATOM(_12private_sym_11795) && IS_SEQUENCE(_28214)) {
        }
        else {
            Concat((object_ptr)&_12private_sym_11795, _12private_sym_11795, _28214);
        }
        DeRef(_28214);
        _28214 = NOVALUE;
        goto L16; // [823] 630
L1C: 

        /** 							CompileErr(29, on_arg)*/
        _43CompileErr(29, _30on_arg_54409, 0);

        /** 		  		    end while*/
        goto L16; // [838] 630
L17: 

        /** 					short_circuit += 1*/
        _30short_circuit_53685 = _30short_circuit_53685 + 1;

        /** 					if backed_up_tok[$][T_ID] = PLAYBACK_ENDS then*/
        if (IS_SEQUENCE(_30backed_up_tok_53692)){
                _28217 = SEQ_PTR(_30backed_up_tok_53692)->length;
        }
        else {
            _28217 = 1;
        }
        _2 = (int)SEQ_PTR(_30backed_up_tok_53692);
        _28218 = (int)*(((s1_ptr)_2)->base + _28217);
        _2 = (int)SEQ_PTR(_28218);
        _28219 = (int)*(((s1_ptr)_2)->base + 1);
        _28218 = NOVALUE;
        if (binary_op_a(NOTEQ, _28219, 505)){
            _28219 = NOVALUE;
            goto L1D; // [868] 880
        }
        _28219 = NOVALUE;

        /** 						backed_up_tok = {}*/
        RefDS(_21829);
        DeRefDS(_30backed_up_tok_53692);
        _30backed_up_tok_53692 = _21829;
L1D: 

        /** 					restore_parseargs_states()*/
        _30restore_parseargs_states();

        /** 					return*/
        DeRef(_tok_54922);
        DeRef(_var_code_54925);
        DeRef(_name_54926);
        return;
        goto L1E; // [889] 906
L12: 

        /** 					putback(tok)*/
        Ref(_tok_54922);
        _30putback(_tok_54922);

        /** 					tok_match(COMMA)*/
        _30tok_match(-30, 0);
L1E: 
L11: 
LF: 

        /** 	end for*/
        _i_54955 = _i_54955 + 1;
        goto L3; // [910] 168
L4: 
        ;
    }

    /** 	tok = next_token()*/
    _0 = _tok_54922;
    _tok_54922 = _30next_token();
    DeRef(_0);

    /** 	short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** 	if tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_54922);
    _28223 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28223, -27)){
        _28223 = NOVALUE;
        goto L1F; // [938] 980
    }
    _28223 = NOVALUE;

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_54922);
    _28225 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28225, -30)){
        _28225 = NOVALUE;
        goto L20; // [952] 965
    }
    _28225 = NOVALUE;

    /** 			WrongNumberArgs(subsym, "only ")*/
    RefDS(_28227);
    _30WrongNumberArgs(_subsym_54917, _28227);
    goto L21; // [962] 979
L20: 

    /** 			putback(tok)*/
    Ref(_tok_54922);
    _30putback(_tok_54922);

    /** 			tok_match(RIGHT_ROUND)*/
    _30tok_match(-27, 0);
L21: 
L1F: 

    /** 	restore_parseargs_states()*/
    _30restore_parseargs_states();

    /** end procedure*/
    DeRef(_tok_54922);
    DeRef(_var_code_54925);
    DeRef(_name_54926);
    return;
    ;
}


void _30Forward_var(int _tok_55131, int _init_check_55132, int _op_55133)
{
    int _ref_55137 = NOVALUE;
    int _28231 = NOVALUE;
    int _28229 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_op_55133)) {
        _1 = (long)(DBL_PTR(_op_55133)->dbl);
        DeRefDS(_op_55133);
        _op_55133 = _1;
    }

    /** 	ref = new_forward_reference( VARIABLE, tok[T_SYM], op )*/
    _2 = (int)SEQ_PTR(_tok_55131);
    _28229 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28229);
    _ref_55137 = _29new_forward_reference(-100, _28229, _op_55133);
    _28229 = NOVALUE;
    if (!IS_ATOM_INT(_ref_55137)) {
        _1 = (long)(DBL_PTR(_ref_55137)->dbl);
        DeRefDS(_ref_55137);
        _ref_55137 = _1;
    }

    /** 	emit_opnd( - ref )*/
    if ((unsigned long)_ref_55137 == 0xC0000000)
    _28231 = (int)NewDouble((double)-0xC0000000);
    else
    _28231 = - _ref_55137;
    _37emit_opnd(_28231);
    _28231 = NOVALUE;

    /** 	if init_check != -1 then*/
    if (_init_check_55132 == -1)
    goto L1; // [33] 44

    /** 		Forward_InitCheck( tok, init_check )*/
    Ref(_tok_55131);
    _30Forward_InitCheck(_tok_55131, _init_check_55132);
L1: 

    /** end procedure*/
    DeRef(_tok_55131);
    return;
    ;
}


void _30Forward_call(int _tok_55150, int _opcode_55151)
{
    int _args_55154 = NOVALUE;
    int _proc_55156 = NOVALUE;
    int _tok_id_55159 = NOVALUE;
    int _id_55166 = NOVALUE;
    int _fc_pc_55189 = NOVALUE;
    int _28250 = NOVALUE;
    int _28249 = NOVALUE;
    int _28246 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer args = 0*/
    _args_55154 = 0;

    /** 	symtab_index proc = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55150);
    _proc_55156 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_proc_55156)){
        _proc_55156 = (long)DBL_PTR(_proc_55156)->dbl;
    }

    /** 	integer tok_id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55150);
    _tok_id_55159 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_tok_id_55159)){
        _tok_id_55159 = (long)DBL_PTR(_tok_id_55159)->dbl;
    }

    /** 	remove_symbol( proc )*/
    _52remove_symbol(_proc_55156);

    /** 	short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 	while 1 do*/
L1: 

    /** 		tok = next_token()*/
    _0 = _tok_55150;
    _tok_55150 = _30next_token();
    DeRef(_0);

    /** 		integer id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55150);
    _id_55166 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55166)){
        _id_55166 = (long)DBL_PTR(_id_55166)->dbl;
    }

    /** 		switch id do*/
    _0 = _id_55166;
    switch ( _0 ){ 

        /** 			case COMMA then*/
        case -30:

        /** 				emit_opnd( 0 ) -- clean this up later*/
        _37emit_opnd(0);

        /** 				args += 1*/
        _args_55154 = _args_55154 + 1;
        goto L2; // [83] 166

        /** 			case RIGHT_ROUND then*/
        case -27:

        /** 				exit*/
        goto L3; // [93] 173
        goto L2; // [95] 166

        /** 			case else*/
        default:

        /** 				putback( tok )*/
        Ref(_tok_55150);
        _30putback(_tok_55150);

        /** 				call_proc( forward_expr, {} )*/
        _0 = (int)_00[_30forward_expr_54694].addr;
        (*(int (*)())_0)(
                             );

        /** 				args += 1*/
        _args_55154 = _args_55154 + 1;

        /** 				tok = next_token()*/
        _0 = _tok_55150;
        _tok_55150 = _30next_token();
        DeRef(_0);

        /** 				id = tok[T_ID]*/
        _2 = (int)SEQ_PTR(_tok_55150);
        _id_55166 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_id_55166)){
            _id_55166 = (long)DBL_PTR(_id_55166)->dbl;
        }

        /** 				if id = RIGHT_ROUND then*/
        if (_id_55166 != -27)
        goto L4; // [138] 149

        /** 					exit*/
        goto L3; // [146] 173
L4: 

        /** 				if id != COMMA then*/
        if (_id_55166 == -30)
        goto L5; // [153] 165

        /** 						CompileErr(69)*/
        RefDS(_21829);
        _43CompileErr(69, _21829, 0);
L5: 
    ;}L2: 

    /** 	end while*/
    goto L1; // [170] 46
L3: 

    /** 	integer fc_pc = length( Code ) + 1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28246 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28246 = 1;
    }
    _fc_pc_55189 = _28246 + 1;
    _28246 = NOVALUE;

    /** 	emit_opnd( args )*/
    _37emit_opnd(_args_55154);

    /** 	op_info1 = proc*/
    _37op_info1_49791 = _proc_55156;

    /** 	if tok_id = QUALIFIED_VARIABLE then*/
    if (_tok_id_55159 != 512)
    goto L6; // [200] 224

    /** 		set_qualified_fwd( SymTab[proc][S_FILE_NO] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28249 = (int)*(((s1_ptr)_2)->base + _proc_55156);
    _2 = (int)SEQ_PTR(_28249);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _28250 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _28250 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _28249 = NOVALUE;
    Ref(_28250);
    _60set_qualified_fwd(_28250);
    _28250 = NOVALUE;
    goto L7; // [221] 230
L6: 

    /** 		set_qualified_fwd( -1 )*/
    _60set_qualified_fwd(-1);
L7: 

    /** 	emit_op( opcode )*/
    _37emit_op(_opcode_55151);

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L8; // [239] 258

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L9; // [246] 257
    }
    else{
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
L9: 
L8: 

    /** 	short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** end procedure*/
    DeRef(_tok_55150);
    return;
    ;
}


void _30Object_call(int _tok_55217)
{
    int _tok2_55219 = NOVALUE;
    int _tok3_55220 = NOVALUE;
    int _save_factors_55221 = NOVALUE;
    int _save_lhs_subs_level_55222 = NOVALUE;
    int _sym_55224 = NOVALUE;
    int _28310 = NOVALUE;
    int _28308 = NOVALUE;
    int _28307 = NOVALUE;
    int _28304 = NOVALUE;
    int _28303 = NOVALUE;
    int _28299 = NOVALUE;
    int _28293 = NOVALUE;
    int _28290 = NOVALUE;
    int _28289 = NOVALUE;
    int _28288 = NOVALUE;
    int _28286 = NOVALUE;
    int _28285 = NOVALUE;
    int _28283 = NOVALUE;
    int _28282 = NOVALUE;
    int _28279 = NOVALUE;
    int _28278 = NOVALUE;
    int _28277 = NOVALUE;
    int _28275 = NOVALUE;
    int _28274 = NOVALUE;
    int _28272 = NOVALUE;
    int _28271 = NOVALUE;
    int _28270 = NOVALUE;
    int _28269 = NOVALUE;
    int _28267 = NOVALUE;
    int _28266 = NOVALUE;
    int _28264 = NOVALUE;
    int _28263 = NOVALUE;
    int _28260 = NOVALUE;
    int _28258 = NOVALUE;
    int _28257 = NOVALUE;
    int _28255 = NOVALUE;
    int _28254 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	tok2 = next_token()*/
    _0 = _tok2_55219;
    _tok2_55219 = _30next_token();
    DeRef(_0);

    /** 	if tok2[T_ID] = VARIABLE or tok2[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28254 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28254)) {
        _28255 = (_28254 == -100);
    }
    else {
        _28255 = binary_op(EQUALS, _28254, -100);
    }
    _28254 = NOVALUE;
    if (IS_ATOM_INT(_28255)) {
        if (_28255 != 0) {
            goto L1; // [22] 43
        }
    }
    else {
        if (DBL_PTR(_28255)->dbl != 0.0) {
            goto L1; // [22] 43
        }
    }
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28257 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28257)) {
        _28258 = (_28257 == 512);
    }
    else {
        _28258 = binary_op(EQUALS, _28257, 512);
    }
    _28257 = NOVALUE;
    if (_28258 == 0) {
        DeRef(_28258);
        _28258 = NOVALUE;
        goto L2; // [39] 586
    }
    else {
        if (!IS_ATOM_INT(_28258) && DBL_PTR(_28258)->dbl == 0.0){
            DeRef(_28258);
            _28258 = NOVALUE;
            goto L2; // [39] 586
        }
        DeRef(_28258);
        _28258 = NOVALUE;
    }
    DeRef(_28258);
    _28258 = NOVALUE;
L1: 

    /** 		tok3 = next_token()*/
    _0 = _tok3_55220;
    _tok3_55220 = _30next_token();
    DeRef(_0);

    /** 		if tok3[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55220);
    _28260 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28260, -27)){
        _28260 = NOVALUE;
        goto L3; // [58] 155
    }
    _28260 = NOVALUE;

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _sym_55224 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55224)){
        _sym_55224 = (long)DBL_PTR(_sym_55224)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28263 = (int)*(((s1_ptr)_2)->base + _sym_55224);
    _2 = (int)SEQ_PTR(_28263);
    _28264 = (int)*(((s1_ptr)_2)->base + 4);
    _28263 = NOVALUE;
    if (binary_op_a(NOTEQ, _28264, 9)){
        _28264 = NOVALUE;
        goto L4; // [88] 108
    }
    _28264 = NOVALUE;

    /** 				Forward_var( tok2 )*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28266 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55219);
    Ref(_28266);
    _30Forward_var(_tok2_55219, -1, _28266);
    _28266 = NOVALUE;
    goto L5; // [105] 147
L4: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55224 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28269 = (int)*(((s1_ptr)_2)->base + _sym_55224);
    _2 = (int)SEQ_PTR(_28269);
    _28270 = (int)*(((s1_ptr)_2)->base + 5);
    _28269 = NOVALUE;
    if (IS_ATOM_INT(_28270)) {
        {unsigned long tu;
             tu = (unsigned long)_28270 | (unsigned long)1;
             _28271 = MAKE_UINT(tu);
        }
    }
    else {
        _28271 = binary_op(OR_BITS, _28270, 1);
    }
    _28270 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28271;
    if( _1 != _28271 ){
        DeRef(_1);
    }
    _28271 = NOVALUE;
    _28267 = NOVALUE;

    /** 				emit_opnd(sym)*/
    _37emit_opnd(_sym_55224);
L5: 

    /** 			putback( tok3 )*/
    Ref(_tok3_55220);
    _30putback(_tok3_55220);
    goto L6; // [152] 575
L3: 

    /** 		elsif tok3[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok3_55220);
    _28272 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28272, -30)){
        _28272 = NOVALUE;
        goto L7; // [165] 184
    }
    _28272 = NOVALUE;

    /** 			WrongNumberArgs(tok[T_SYM], "")*/
    _2 = (int)SEQ_PTR(_tok_55217);
    _28274 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28274);
    RefDS(_21829);
    _30WrongNumberArgs(_28274, _21829);
    _28274 = NOVALUE;
    goto L6; // [181] 575
L7: 

    /** 		elsif tok3[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok3_55220);
    _28275 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28275, -26)){
        _28275 = NOVALUE;
        goto L8; // [194] 244
    }
    _28275 = NOVALUE;

    /** 			if SymTab[tok2[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28277 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28277)){
        _28278 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28277)->dbl));
    }
    else{
        _28278 = (int)*(((s1_ptr)_2)->base + _28277);
    }
    _2 = (int)SEQ_PTR(_28278);
    _28279 = (int)*(((s1_ptr)_2)->base + 4);
    _28278 = NOVALUE;
    if (binary_op_a(NOTEQ, _28279, 9)){
        _28279 = NOVALUE;
        goto L9; // [220] 235
    }
    _28279 = NOVALUE;

    /** 				Forward_call( tok2, FUNC_FORWARD )*/
    Ref(_tok2_55219);
    _30Forward_call(_tok2_55219, 196);
    goto L6; // [232] 575
L9: 

    /** 				Function_call( tok2 )*/
    Ref(_tok2_55219);
    _30Function_call(_tok2_55219);
    goto L6; // [241] 575
L8: 

    /** 			sym = tok2[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _sym_55224 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_55224)){
        _sym_55224 = (long)DBL_PTR(_sym_55224)->dbl;
    }

    /** 			if SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28282 = (int)*(((s1_ptr)_2)->base + _sym_55224);
    _2 = (int)SEQ_PTR(_28282);
    _28283 = (int)*(((s1_ptr)_2)->base + 4);
    _28282 = NOVALUE;
    if (binary_op_a(NOTEQ, _28283, 9)){
        _28283 = NOVALUE;
        goto LA; // [270] 292
    }
    _28283 = NOVALUE;

    /** 				Forward_var( tok2, TRUE )*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28285 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tok2_55219);
    Ref(_28285);
    _30Forward_var(_tok2_55219, _9TRUE_431, _28285);
    _28285 = NOVALUE;
    goto LB; // [289] 339
LA: 

    /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_55224 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28288 = (int)*(((s1_ptr)_2)->base + _sym_55224);
    _2 = (int)SEQ_PTR(_28288);
    _28289 = (int)*(((s1_ptr)_2)->base + 5);
    _28288 = NOVALUE;
    if (IS_ATOM_INT(_28289)) {
        {unsigned long tu;
             tu = (unsigned long)_28289 | (unsigned long)1;
             _28290 = MAKE_UINT(tu);
        }
    }
    else {
        _28290 = binary_op(OR_BITS, _28289, 1);
    }
    _28289 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28290;
    if( _1 != _28290 ){
        DeRef(_1);
    }
    _28290 = NOVALUE;
    _28286 = NOVALUE;

    /** 				InitCheck(sym, TRUE)*/
    _30InitCheck(_sym_55224, _9TRUE_431);

    /** 				emit_opnd(sym)*/
    _37emit_opnd(_sym_55224);
LB: 

    /** 			if sym = left_sym then*/
    if (_sym_55224 != _30left_sym_53726)
    goto LC; // [343] 353

    /** 				lhs_subs_level = 0*/
    _30lhs_subs_level_53724 = 0;
LC: 

    /** 			tok2 = tok3*/
    Ref(_tok3_55220);
    DeRef(_tok2_55219);
    _tok2_55219 = _tok3_55220;

    /** 			current_sequence = append(current_sequence, sym)*/
    Append(&_37current_sequence_49799, _37current_sequence_49799, _sym_55224);

    /** 			while tok2[T_ID] = LEFT_SQUARE do*/
LD: 
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28293 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28293, -28)){
        _28293 = NOVALUE;
        goto LE; // [381] 551
    }
    _28293 = NOVALUE;

    /** 				subs_depth += 1*/
    _30subs_depth_53727 = _30subs_depth_53727 + 1;

    /** 				if lhs_subs_level >= 0 then*/
    if (_30lhs_subs_level_53724 < 0)
    goto LF; // [397] 410

    /** 					lhs_subs_level += 1*/
    _30lhs_subs_level_53724 = _30lhs_subs_level_53724 + 1;
LF: 

    /** 				save_factors = factors*/
    _save_factors_55221 = _30factors_53723;

    /** 				save_lhs_subs_level = lhs_subs_level*/
    _save_lhs_subs_level_55222 = _30lhs_subs_level_53724;

    /** 				call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_54694].addr;
    (*(int (*)())_0)(
                         );

    /** 				tok2 = next_token()*/
    _0 = _tok2_55219;
    _tok2_55219 = _30next_token();
    DeRef(_0);

    /** 				if tok2[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok2_55219);
    _28299 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28299, 513)){
        _28299 = NOVALUE;
        goto L10; // [446] 484
    }
    _28299 = NOVALUE;

    /** 					call_proc(forward_expr, {})*/
    _0 = (int)_00[_30forward_expr_54694].addr;
    (*(int (*)())_0)(
                         );

    /** 					emit_op(RHS_SLICE)*/
    _37emit_op(46);

    /** 					tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 					tok2 = next_token()*/
    _0 = _tok2_55219;
    _tok2_55219 = _30next_token();
    DeRef(_0);

    /** 					exit*/
    goto LE; // [479] 551
    goto L11; // [481] 531
L10: 

    /** 					putback(tok2)*/
    Ref(_tok2_55219);
    _30putback(_tok2_55219);

    /** 					tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 					subs_depth -= 1*/
    _30subs_depth_53727 = _30subs_depth_53727 - 1;

    /** 					current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_37current_sequence_49799)){
            _28303 = SEQ_PTR(_37current_sequence_49799)->length;
    }
    else {
        _28303 = 1;
    }
    _28304 = _28303 - 1;
    _28303 = NOVALUE;
    rhs_slice_target = (object_ptr)&_37current_sequence_49799;
    RHS_Slice(_37current_sequence_49799, 1, _28304);

    /** 					emit_op(RHS_SUBS)*/
    _37emit_op(25);
L11: 

    /** 				factors = save_factors*/
    _30factors_53723 = _save_factors_55221;

    /** 				lhs_subs_level = save_lhs_subs_level*/
    _30lhs_subs_level_53724 = _save_lhs_subs_level_55222;

    /** 				tok2 = next_token()*/
    _0 = _tok2_55219;
    _tok2_55219 = _30next_token();
    DeRef(_0);

    /** 			end while*/
    goto LD; // [548] 373
LE: 

    /** 			current_sequence = current_sequence[1..$-1]*/
    if (IS_SEQUENCE(_37current_sequence_49799)){
            _28307 = SEQ_PTR(_37current_sequence_49799)->length;
    }
    else {
        _28307 = 1;
    }
    _28308 = _28307 - 1;
    _28307 = NOVALUE;
    rhs_slice_target = (object_ptr)&_37current_sequence_49799;
    RHS_Slice(_37current_sequence_49799, 1, _28308);

    /** 			putback(tok2)*/
    Ref(_tok2_55219);
    _30putback(_tok2_55219);
L6: 

    /** 		tok_match( RIGHT_ROUND )*/
    _30tok_match(-27, 0);
    goto L12; // [583] 603
L2: 

    /** 		putback(tok2)*/
    Ref(_tok2_55219);
    _30putback(_tok2_55219);

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55217);
    _28310 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28310);
    _30ParseArgs(_28310);
    _28310 = NOVALUE;
L12: 

    /** end procedure*/
    DeRef(_tok_55217);
    DeRef(_tok2_55219);
    DeRef(_tok3_55220);
    _28277 = NOVALUE;
    DeRef(_28255);
    _28255 = NOVALUE;
    DeRef(_28304);
    _28304 = NOVALUE;
    DeRef(_28308);
    _28308 = NOVALUE;
    return;
    ;
}


void _30Function_call(int _tok_55362)
{
    int _id_55363 = NOVALUE;
    int _scope_55364 = NOVALUE;
    int _opcode_55365 = NOVALUE;
    int _e_55366 = NOVALUE;
    int _28351 = NOVALUE;
    int _28350 = NOVALUE;
    int _28349 = NOVALUE;
    int _28348 = NOVALUE;
    int _28347 = NOVALUE;
    int _28346 = NOVALUE;
    int _28345 = NOVALUE;
    int _28343 = NOVALUE;
    int _28342 = NOVALUE;
    int _28340 = NOVALUE;
    int _28339 = NOVALUE;
    int _28338 = NOVALUE;
    int _28337 = NOVALUE;
    int _28336 = NOVALUE;
    int _28335 = NOVALUE;
    int _28334 = NOVALUE;
    int _28333 = NOVALUE;
    int _28332 = NOVALUE;
    int _28331 = NOVALUE;
    int _28330 = NOVALUE;
    int _28329 = NOVALUE;
    int _28328 = NOVALUE;
    int _28327 = NOVALUE;
    int _28326 = NOVALUE;
    int _28324 = NOVALUE;
    int _28322 = NOVALUE;
    int _28321 = NOVALUE;
    int _28319 = NOVALUE;
    int _28317 = NOVALUE;
    int _28316 = NOVALUE;
    int _28315 = NOVALUE;
    int _28314 = NOVALUE;
    int _28312 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _id_55363 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55363)){
        _id_55363 = (long)DBL_PTR(_id_55363)->dbl;
    }

    /** 	if id = FUNC or id = TYPE then*/
    _28312 = (_id_55363 == 501);
    if (_28312 != 0) {
        goto L1; // [19] 34
    }
    _28314 = (_id_55363 == 504);
    if (_28314 == 0)
    {
        DeRef(_28314);
        _28314 = NOVALUE;
        goto L2; // [30] 46
    }
    else{
        DeRef(_28314);
        _28314 = NOVALUE;
    }
L1: 

    /** 		UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28315 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28315);
    _30UndefinedVar(_28315);
    _28315 = NOVALUE;
L2: 

    /** 	e = SymTab[tok[T_SYM]][S_EFFECT]*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28316 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28316)){
        _28317 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28316)->dbl));
    }
    else{
        _28317 = (int)*(((s1_ptr)_2)->base + _28316);
    }
    _2 = (int)SEQ_PTR(_28317);
    _e_55366 = (int)*(((s1_ptr)_2)->base + 23);
    if (!IS_ATOM_INT(_e_55366)){
        _e_55366 = (long)DBL_PTR(_e_55366)->dbl;
    }
    _28317 = NOVALUE;

    /** 	if e then*/
    if (_e_55366 == 0)
    {
        goto L3; // [70] 229
    }
    else{
    }

    /** 		if e = E_ALL_EFFECT or tok[T_SYM] > left_sym then*/
    _28319 = (_e_55366 == 1073741823);
    if (_28319 != 0) {
        goto L4; // [81] 102
    }
    _2 = (int)SEQ_PTR(_tok_55362);
    _28321 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_28321)) {
        _28322 = (_28321 > _30left_sym_53726);
    }
    else {
        _28322 = binary_op(GREATER, _28321, _30left_sym_53726);
    }
    _28321 = NOVALUE;
    if (_28322 == 0) {
        DeRef(_28322);
        _28322 = NOVALUE;
        goto L5; // [98] 111
    }
    else {
        if (!IS_ATOM_INT(_28322) && DBL_PTR(_28322)->dbl == 0.0){
            DeRef(_28322);
            _28322 = NOVALUE;
            goto L5; // [98] 111
        }
        DeRef(_28322);
        _28322 = NOVALUE;
    }
    DeRef(_28322);
    _28322 = NOVALUE;
L4: 

    /** 			side_effect_calls = or_bits(side_effect_calls, e)*/
    {unsigned long tu;
         tu = (unsigned long)_30side_effect_calls_53722 | (unsigned long)_e_55366;
         _30side_effect_calls_53722 = MAKE_UINT(tu);
    }
L5: 

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT], e)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28326 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_28326);
    _28327 = (int)*(((s1_ptr)_2)->base + 23);
    _28326 = NOVALUE;
    if (IS_ATOM_INT(_28327)) {
        {unsigned long tu;
             tu = (unsigned long)_28327 | (unsigned long)_e_55366;
             _28328 = MAKE_UINT(tu);
        }
    }
    else {
        _28328 = binary_op(OR_BITS, _28327, _e_55366);
    }
    _28327 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28328;
    if( _1 != _28328 ){
        DeRef(_1);
    }
    _28328 = NOVALUE;
    _28324 = NOVALUE;

    /** 		if short_circuit > 0 and short_circuit_B and*/
    _28329 = (_30short_circuit_53685 > 0);
    if (_28329 == 0) {
        _28330 = 0;
        goto L6; // [154] 164
    }
    _28330 = (_30short_circuit_B_53687 != 0);
L6: 
    if (_28330 == 0) {
        goto L7; // [164] 228
    }
    _28332 = find_from(_id_55363, _28FUNC_TOKS_11314, 1);
    if (_28332 == 0)
    {
        _28332 = NOVALUE;
        goto L7; // [176] 228
    }
    else{
        _28332 = NOVALUE;
    }

    /** 			Warning(219, short_circuit_warning_flag,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _28333 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_28333);
    RefDS(_21829);
    _28334 = _14abbreviate_path(_28333, _21829);
    _28333 = NOVALUE;
    _2 = (int)SEQ_PTR(_tok_55362);
    _28335 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28335)){
        _28336 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28335)->dbl));
    }
    else{
        _28336 = (int)*(((s1_ptr)_2)->base + _28335);
    }
    _2 = (int)SEQ_PTR(_28336);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28337 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28337 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28336 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28334;
    *((int *)(_2+8)) = _12line_number_11683;
    Ref(_28337);
    *((int *)(_2+12)) = _28337;
    _28338 = MAKE_SEQ(_1);
    _28337 = NOVALUE;
    _28334 = NOVALUE;
    _43Warning(219, 2, _28338);
    _28338 = NOVALUE;
L7: 
L3: 

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28339 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28339)){
        _28340 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28339)->dbl));
    }
    else{
        _28340 = (int)*(((s1_ptr)_2)->base + _28339);
    }
    _2 = (int)SEQ_PTR(_28340);
    _scope_55364 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_55364)){
        _scope_55364 = (long)DBL_PTR(_scope_55364)->dbl;
    }
    _28340 = NOVALUE;

    /** 	opcode = SymTab[tok[T_SYM]][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28342 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28342)){
        _28343 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28342)->dbl));
    }
    else{
        _28343 = (int)*(((s1_ptr)_2)->base + _28342);
    }
    _2 = (int)SEQ_PTR(_28343);
    _opcode_55365 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_55365)){
        _opcode_55365 = (long)DBL_PTR(_opcode_55365)->dbl;
    }
    _28343 = NOVALUE;

    /** 	if equal(SymTab[tok[T_SYM]][S_NAME],"object") and scope = SC_PREDEF then*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28345 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28345)){
        _28346 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28345)->dbl));
    }
    else{
        _28346 = (int)*(((s1_ptr)_2)->base + _28345);
    }
    _2 = (int)SEQ_PTR(_28346);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _28347 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _28347 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _28346 = NOVALUE;
    if (_28347 == _24437)
    _28348 = 1;
    else if (IS_ATOM_INT(_28347) && IS_ATOM_INT(_24437))
    _28348 = 0;
    else
    _28348 = (compare(_28347, _24437) == 0);
    _28347 = NOVALUE;
    if (_28348 == 0) {
        goto L8; // [305] 327
    }
    _28350 = (_scope_55364 == 7);
    if (_28350 == 0)
    {
        DeRef(_28350);
        _28350 = NOVALUE;
        goto L8; // [316] 327
    }
    else{
        DeRef(_28350);
        _28350 = NOVALUE;
    }

    /** 		Object_call( tok )*/
    Ref(_tok_55362);
    _30Object_call(_tok_55362);
    goto L9; // [324] 339
L8: 

    /** 		ParseArgs(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _28351 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28351);
    _30ParseArgs(_28351);
    _28351 = NOVALUE;
L9: 

    /** 	if scope = SC_PREDEF then*/
    if (_scope_55364 != 7)
    goto LA; // [343] 355

    /** 		emit_op(opcode)*/
    _37emit_op(_opcode_55365);
    goto LB; // [352] 393
LA: 

    /** 		op_info1 = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_55362);
    _37op_info1_49791 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_37op_info1_49791)){
        _37op_info1_49791 = (long)DBL_PTR(_37op_info1_49791)->dbl;
    }

    /** 		emit_or_inline()*/
    _66emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto LC; // [373] 392

    /** 			if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto LD; // [380] 391
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
LD: 
LC: 
LB: 

    /** end procedure*/
    DeRef(_tok_55362);
    DeRef(_28312);
    _28312 = NOVALUE;
    _28316 = NOVALUE;
    DeRef(_28319);
    _28319 = NOVALUE;
    DeRef(_28329);
    _28329 = NOVALUE;
    _28335 = NOVALUE;
    _28339 = NOVALUE;
    _28342 = NOVALUE;
    _28345 = NOVALUE;
    return;
    ;
}


void _30Factor()
{
    int _tok_55470 = NOVALUE;
    int _id_55471 = NOVALUE;
    int _n_55472 = NOVALUE;
    int _save_factors_55473 = NOVALUE;
    int _save_lhs_subs_level_55474 = NOVALUE;
    int _sym_55476 = NOVALUE;
    int _forward_55507 = NOVALUE;
    int _28413 = NOVALUE;
    int _28412 = NOVALUE;
    int _28411 = NOVALUE;
    int _28409 = NOVALUE;
    int _28408 = NOVALUE;
    int _28407 = NOVALUE;
    int _28406 = NOVALUE;
    int _28405 = NOVALUE;
    int _28403 = NOVALUE;
    int _28399 = NOVALUE;
    int _28398 = NOVALUE;
    int _28395 = NOVALUE;
    int _28394 = NOVALUE;
    int _28390 = NOVALUE;
    int _28384 = NOVALUE;
    int _28379 = NOVALUE;
    int _28378 = NOVALUE;
    int _28377 = NOVALUE;
    int _28375 = NOVALUE;
    int _28374 = NOVALUE;
    int _28372 = NOVALUE;
    int _28370 = NOVALUE;
    int _28369 = NOVALUE;
    int _28368 = NOVALUE;
    int _28366 = NOVALUE;
    int _28359 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer id, n*/

    /** 	integer save_factors, save_lhs_subs_level*/

    /** 	factors += 1*/
    _30factors_53723 = _30factors_53723 + 1;

    /** 	tok = next_token()*/
    _0 = _tok_55470;
    _tok_55470 = _30next_token();
    DeRef(_0);

    /** 	id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55470);
    _id_55471 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55471)){
        _id_55471 = (long)DBL_PTR(_id_55471)->dbl;
    }

    /** 	if id = RECORDED then*/
    if (_id_55471 != 508)
    goto L1; // [32] 59

    /** 		tok = read_recorded_token(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_55470);
    _28359 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28359);
    _0 = _tok_55470;
    _tok_55470 = _30read_recorded_token(_28359);
    DeRef(_0);
    _28359 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55470);
    _id_55471 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55471)){
        _id_55471 = (long)DBL_PTR(_id_55471)->dbl;
    }
L1: 

    /** 	switch id label "factor" do*/
    _0 = _id_55471;
    switch ( _0 ){ 

        /** 		case VARIABLE, QUALIFIED_VARIABLE then*/
        case -100:
        case 512:

        /** 			sym = tok[T_SYM]*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _sym_55476 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_55476)){
            _sym_55476 = (long)DBL_PTR(_sym_55476)->dbl;
        }

        /** 			if sym < 0 or SymTab[sym][S_SCOPE] = SC_UNDEFINED then*/
        _28366 = (_sym_55476 < 0);
        if (_28366 != 0) {
            goto L2; // [88] 115
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28368 = (int)*(((s1_ptr)_2)->base + _sym_55476);
        _2 = (int)SEQ_PTR(_28368);
        _28369 = (int)*(((s1_ptr)_2)->base + 4);
        _28368 = NOVALUE;
        if (IS_ATOM_INT(_28369)) {
            _28370 = (_28369 == 9);
        }
        else {
            _28370 = binary_op(EQUALS, _28369, 9);
        }
        _28369 = NOVALUE;
        if (_28370 == 0) {
            DeRef(_28370);
            _28370 = NOVALUE;
            goto L3; // [111] 177
        }
        else {
            if (!IS_ATOM_INT(_28370) && DBL_PTR(_28370)->dbl == 0.0){
                DeRef(_28370);
                _28370 = NOVALUE;
                goto L3; // [111] 177
            }
            DeRef(_28370);
            _28370 = NOVALUE;
        }
        DeRef(_28370);
        _28370 = NOVALUE;
L2: 

        /** 				token forward = next_token()*/
        _0 = _forward_55507;
        _forward_55507 = _30next_token();
        DeRef(_0);

        /** 				if forward[T_ID] = LEFT_ROUND then*/
        _2 = (int)SEQ_PTR(_forward_55507);
        _28372 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28372, -26)){
            _28372 = NOVALUE;
            goto L4; // [130] 151
        }
        _28372 = NOVALUE;

        /** 					Forward_call( tok, FUNC_FORWARD )*/
        Ref(_tok_55470);
        _30Forward_call(_tok_55470, 196);

        /** 					break "factor"*/
        DeRef(_forward_55507);
        _forward_55507 = NOVALUE;
        goto L5; // [146] 696
        goto L6; // [148] 172
L4: 

        /** 					putback( forward )*/
        Ref(_forward_55507);
        _30putback(_forward_55507);

        /** 					Forward_var( tok, TRUE )*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _28374 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_tok_55470);
        Ref(_28374);
        _30Forward_var(_tok_55470, _9TRUE_431, _28374);
        _28374 = NOVALUE;
L6: 
        DeRef(_forward_55507);
        _forward_55507 = NOVALUE;
        goto L7; // [174] 229
L3: 

        /** 				UndefinedVar(sym)*/
        _30UndefinedVar(_sym_55476);

        /** 				SymTab[sym][S_USAGE] = or_bits(SymTab[sym][S_USAGE], U_READ)*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_sym_55476 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28377 = (int)*(((s1_ptr)_2)->base + _sym_55476);
        _2 = (int)SEQ_PTR(_28377);
        _28378 = (int)*(((s1_ptr)_2)->base + 5);
        _28377 = NOVALUE;
        if (IS_ATOM_INT(_28378)) {
            {unsigned long tu;
                 tu = (unsigned long)_28378 | (unsigned long)1;
                 _28379 = MAKE_UINT(tu);
            }
        }
        else {
            _28379 = binary_op(OR_BITS, _28378, 1);
        }
        _28378 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = _28379;
        if( _1 != _28379 ){
            DeRef(_1);
        }
        _28379 = NOVALUE;
        _28375 = NOVALUE;

        /** 				InitCheck(sym, TRUE)*/
        _30InitCheck(_sym_55476, _9TRUE_431);

        /** 				emit_opnd(sym)*/
        _37emit_opnd(_sym_55476);
L7: 

        /** 			if sym = left_sym then*/
        if (_sym_55476 != _30left_sym_53726)
        goto L8; // [233] 243

        /** 				lhs_subs_level = 0 -- start counting subscripts*/
        _30lhs_subs_level_53724 = 0;
L8: 

        /** 			short_circuit -= 1*/
        _30short_circuit_53685 = _30short_circuit_53685 - 1;

        /** 			tok = next_token()*/
        _0 = _tok_55470;
        _tok_55470 = _30next_token();
        DeRef(_0);

        /** 			current_sequence = append(current_sequence, sym)*/
        Append(&_37current_sequence_49799, _37current_sequence_49799, _sym_55476);

        /** 			while tok[T_ID] = LEFT_SQUARE do*/
L9: 
        _2 = (int)SEQ_PTR(_tok_55470);
        _28384 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28384, -28)){
            _28384 = NOVALUE;
            goto LA; // [279] 450
        }
        _28384 = NOVALUE;

        /** 				subs_depth += 1*/
        _30subs_depth_53727 = _30subs_depth_53727 + 1;

        /** 				if lhs_subs_level >= 0 then*/
        if (_30lhs_subs_level_53724 < 0)
        goto LB; // [295] 308

        /** 					lhs_subs_level += 1*/
        _30lhs_subs_level_53724 = _30lhs_subs_level_53724 + 1;
LB: 

        /** 				save_factors = factors*/
        _save_factors_55473 = _30factors_53723;

        /** 				save_lhs_subs_level = lhs_subs_level*/
        _save_lhs_subs_level_55474 = _30lhs_subs_level_53724;

        /** 				call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_54694].addr;
        (*(int (*)())_0)(
                             );

        /** 				tok = next_token()*/
        _0 = _tok_55470;
        _tok_55470 = _30next_token();
        DeRef(_0);

        /** 				if tok[T_ID] = SLICE then*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _28390 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28390, 513)){
            _28390 = NOVALUE;
            goto LC; // [344] 382
        }
        _28390 = NOVALUE;

        /** 					call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_54694].addr;
        (*(int (*)())_0)(
                             );

        /** 					emit_op(RHS_SLICE)*/
        _37emit_op(46);

        /** 					tok_match(RIGHT_SQUARE)*/
        _30tok_match(-29, 0);

        /** 					tok = next_token()*/
        _0 = _tok_55470;
        _tok_55470 = _30next_token();
        DeRef(_0);

        /** 					exit*/
        goto LA; // [377] 450
        goto LD; // [379] 430
LC: 

        /** 					putback(tok)*/
        Ref(_tok_55470);
        _30putback(_tok_55470);

        /** 					tok_match(RIGHT_SQUARE)*/
        _30tok_match(-29, 0);

        /** 					subs_depth -= 1*/
        _30subs_depth_53727 = _30subs_depth_53727 - 1;

        /** 					current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _28394 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _28394 = 1;
        }
        _28395 = _28394 - 1;
        _28394 = NOVALUE;
        {
            int len = SEQ_PTR(_37current_sequence_49799)->length;
            int size = (IS_ATOM_INT(_28395)) ? _28395 : (object)(DBL_PTR(_28395)->dbl);
            if (size <= 0){
                DeRef( _37current_sequence_49799 );
                _37current_sequence_49799 = MAKE_SEQ(NewS1(0));
            }
            else if (len <= size) {
                RefDS(_37current_sequence_49799);
                DeRef(_37current_sequence_49799);
                _37current_sequence_49799 = _37current_sequence_49799;
            }
            else{
                Head(SEQ_PTR(_37current_sequence_49799),size+1,&_37current_sequence_49799);
            }
        }
        _28395 = NOVALUE;

        /** 					emit_op(RHS_SUBS) -- current_sequence will be updated*/
        _37emit_op(25);
LD: 

        /** 				factors = save_factors*/
        _30factors_53723 = _save_factors_55473;

        /** 				lhs_subs_level = save_lhs_subs_level*/
        _30lhs_subs_level_53724 = _save_lhs_subs_level_55474;

        /** 				tok = next_token()*/
        _0 = _tok_55470;
        _tok_55470 = _30next_token();
        DeRef(_0);

        /** 			end while*/
        goto L9; // [447] 271
LA: 

        /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _28398 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _28398 = 1;
        }
        _28399 = _28398 - 1;
        _28398 = NOVALUE;
        {
            int len = SEQ_PTR(_37current_sequence_49799)->length;
            int size = (IS_ATOM_INT(_28399)) ? _28399 : (object)(DBL_PTR(_28399)->dbl);
            if (size <= 0){
                DeRef( _37current_sequence_49799 );
                _37current_sequence_49799 = MAKE_SEQ(NewS1(0));
            }
            else if (len <= size) {
                RefDS(_37current_sequence_49799);
                DeRef(_37current_sequence_49799);
                _37current_sequence_49799 = _37current_sequence_49799;
            }
            else{
                Head(SEQ_PTR(_37current_sequence_49799),size+1,&_37current_sequence_49799);
            }
        }
        _28399 = NOVALUE;

        /** 			putback(tok)*/
        Ref(_tok_55470);
        _30putback(_tok_55470);

        /** 			short_circuit += 1*/
        _30short_circuit_53685 = _30short_circuit_53685 + 1;
        goto L5; // [482] 696

        /** 		case DOLLAR then*/
        case -22:

        /** 			tok = next_token()*/
        _0 = _tok_55470;
        _tok_55470 = _30next_token();
        DeRef(_0);

        /** 			putback(tok)*/
        Ref(_tok_55470);
        _30putback(_tok_55470);

        /** 			if tok[T_ID] = RIGHT_BRACE then*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _28403 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(NOTEQ, _28403, -25)){
            _28403 = NOVALUE;
            goto LE; // [508] 526
        }
        _28403 = NOVALUE;

        /** 				gListItem[$] = 0*/
        if (IS_SEQUENCE(_30gListItem_53721)){
                _28405 = SEQ_PTR(_30gListItem_53721)->length;
        }
        else {
            _28405 = 1;
        }
        _2 = (int)SEQ_PTR(_30gListItem_53721);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30gListItem_53721 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _28405);
        *(int *)_2 = 0;
        goto L5; // [523] 696
LE: 

        /** 				if subs_depth > 0 and length(current_sequence) then*/
        _28406 = (_30subs_depth_53727 > 0);
        if (_28406 == 0) {
            goto LF; // [534] 557
        }
        if (IS_SEQUENCE(_37current_sequence_49799)){
                _28408 = SEQ_PTR(_37current_sequence_49799)->length;
        }
        else {
            _28408 = 1;
        }
        if (_28408 == 0)
        {
            _28408 = NOVALUE;
            goto LF; // [544] 557
        }
        else{
            _28408 = NOVALUE;
        }

        /** 					emit_op(DOLLAR)*/
        _37emit_op(-22);
        goto L5; // [554] 696
LF: 

        /** 					CompileErr(21)*/
        RefDS(_21829);
        _43CompileErr(21, _21829, 0);
        goto L5; // [566] 696

        /** 		case ATOM then*/
        case 502:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _28409 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28409);
        _37emit_opnd(_28409);
        _28409 = NOVALUE;
        goto L5; // [583] 696

        /** 		case LEFT_BRACE then*/
        case -24:

        /** 			n = Expr_list()*/
        _n_55472 = _30Expr_list();
        if (!IS_ATOM_INT(_n_55472)) {
            _1 = (long)(DBL_PTR(_n_55472)->dbl);
            DeRefDS(_n_55472);
            _n_55472 = _1;
        }

        /** 			tok_match(RIGHT_BRACE)*/
        _30tok_match(-25, 0);

        /** 			op_info1 = n*/
        _37op_info1_49791 = _n_55472;

        /** 			emit_op(RIGHT_BRACE_N)*/
        _37emit_op(31);
        goto L5; // [618] 696

        /** 		case STRING then*/
        case 503:

        /** 			emit_opnd(tok[T_SYM])*/
        _2 = (int)SEQ_PTR(_tok_55470);
        _28411 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_28411);
        _37emit_opnd(_28411);
        _28411 = NOVALUE;
        goto L5; // [635] 696

        /** 		case LEFT_ROUND then*/
        case -26:

        /** 			call_proc(forward_expr, {})*/
        _0 = (int)_00[_30forward_expr_54694].addr;
        (*(int (*)())_0)(
                             );

        /** 			tok_match(RIGHT_ROUND)*/
        _30tok_match(-27, 0);
        goto L5; // [656] 696

        /** 		case FUNC, TYPE, QUALIFIED_FUNC, QUALIFIED_TYPE then*/
        case 501:
        case 504:
        case 520:
        case 522:

        /** 			Function_call( tok )*/
        Ref(_tok_55470);
        _30Function_call(_tok_55470);
        goto L5; // [673] 696

        /** 		case else*/
        default:

        /** 			CompileErr(135, {LexName(id)})*/
        RefDS(_26196);
        _28412 = _37LexName(_id_55471, _26196);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _28412;
        _28413 = MAKE_SEQ(_1);
        _28412 = NOVALUE;
        _43CompileErr(135, _28413, 0);
        _28413 = NOVALUE;
    ;}L5: 

    /** end procedure*/
    DeRef(_tok_55470);
    DeRef(_28366);
    _28366 = NOVALUE;
    DeRef(_28406);
    _28406 = NOVALUE;
    return;
    ;
}


void _30UFactor()
{
    int _tok_55629 = NOVALUE;
    int _28419 = NOVALUE;
    int _28417 = NOVALUE;
    int _28415 = NOVALUE;
    int _0, _1, _2;
    

    /** 	tok = next_token()*/
    _0 = _tok_55629;
    _tok_55629 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_55629);
    _28415 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28415, 10)){
        _28415 = NOVALUE;
        goto L1; // [16] 34
    }
    _28415 = NOVALUE;

    /** 		Factor()*/
    _30Factor();

    /** 		emit_op(UMINUS)*/
    _37emit_op(12);
    goto L2; // [31] 93
L1: 

    /** 	elsif tok[T_ID] = NOT then*/
    _2 = (int)SEQ_PTR(_tok_55629);
    _28417 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28417, 7)){
        _28417 = NOVALUE;
        goto L3; // [44] 62
    }
    _28417 = NOVALUE;

    /** 		Factor()*/
    _30Factor();

    /** 		emit_op(NOT)*/
    _37emit_op(7);
    goto L2; // [59] 93
L3: 

    /** 	elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_55629);
    _28419 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28419, 11)){
        _28419 = NOVALUE;
        goto L4; // [72] 83
    }
    _28419 = NOVALUE;

    /** 		Factor()*/
    _30Factor();
    goto L2; // [80] 93
L4: 

    /** 		putback(tok)*/
    Ref(_tok_55629);
    _30putback(_tok_55629);

    /** 		Factor()*/
    _30Factor();
L2: 

    /** end procedure*/
    DeRef(_tok_55629);
    return;
    ;
}


int _30Term()
{
    int _tok_55654 = NOVALUE;
    int _28427 = NOVALUE;
    int _28426 = NOVALUE;
    int _28425 = NOVALUE;
    int _28423 = NOVALUE;
    int _28422 = NOVALUE;
    int _0, _1, _2;
    

    /** 	UFactor()*/
    _30UFactor();

    /** 	tok = next_token()*/
    _0 = _tok_55654;
    _tok_55654 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = reserved:MULTIPLY or tok[T_ID] = reserved:DIVIDE do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55654);
    _28422 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28422)) {
        _28423 = (_28422 == 13);
    }
    else {
        _28423 = binary_op(EQUALS, _28422, 13);
    }
    _28422 = NOVALUE;
    if (IS_ATOM_INT(_28423)) {
        if (_28423 != 0) {
            goto L2; // [25] 44
        }
    }
    else {
        if (DBL_PTR(_28423)->dbl != 0.0) {
            goto L2; // [25] 44
        }
    }
    _2 = (int)SEQ_PTR(_tok_55654);
    _28425 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28425)) {
        _28426 = (_28425 == 14);
    }
    else {
        _28426 = binary_op(EQUALS, _28425, 14);
    }
    _28425 = NOVALUE;
    if (_28426 <= 0) {
        if (_28426 == 0) {
            DeRef(_28426);
            _28426 = NOVALUE;
            goto L3; // [40] 69
        }
        else {
            if (!IS_ATOM_INT(_28426) && DBL_PTR(_28426)->dbl == 0.0){
                DeRef(_28426);
                _28426 = NOVALUE;
                goto L3; // [40] 69
            }
            DeRef(_28426);
            _28426 = NOVALUE;
        }
    }
    DeRef(_28426);
    _28426 = NOVALUE;
L2: 

    /** 		UFactor()*/
    _30UFactor();

    /** 		emit_op(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_55654);
    _28427 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28427);
    _37emit_op(_28427);
    _28427 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_55654;
    _tok_55654 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L1; // [66] 15
L3: 

    /** 	return tok*/
    DeRef(_28423);
    _28423 = NOVALUE;
    return _tok_55654;
    ;
}


int _30aexpr()
{
    int _tok_55671 = NOVALUE;
    int _id_55672 = NOVALUE;
    int _28434 = NOVALUE;
    int _28433 = NOVALUE;
    int _28431 = NOVALUE;
    int _28430 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = Term()*/
    _0 = _tok_55671;
    _tok_55671 = _30Term();
    DeRef(_0);

    /** 	while tok[T_ID] = PLUS or tok[T_ID] = MINUS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55671);
    _28430 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28430)) {
        _28431 = (_28430 == 11);
    }
    else {
        _28431 = binary_op(EQUALS, _28430, 11);
    }
    _28430 = NOVALUE;
    if (IS_ATOM_INT(_28431)) {
        if (_28431 != 0) {
            goto L2; // [25] 46
        }
    }
    else {
        if (DBL_PTR(_28431)->dbl != 0.0) {
            goto L2; // [25] 46
        }
    }
    _2 = (int)SEQ_PTR(_tok_55671);
    _28433 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28433)) {
        _28434 = (_28433 == 10);
    }
    else {
        _28434 = binary_op(EQUALS, _28433, 10);
    }
    _28433 = NOVALUE;
    if (_28434 <= 0) {
        if (_28434 == 0) {
            DeRef(_28434);
            _28434 = NOVALUE;
            goto L3; // [42] 71
        }
        else {
            if (!IS_ATOM_INT(_28434) && DBL_PTR(_28434)->dbl == 0.0){
                DeRef(_28434);
                _28434 = NOVALUE;
                goto L3; // [42] 71
            }
            DeRef(_28434);
            _28434 = NOVALUE;
        }
    }
    DeRef(_28434);
    _28434 = NOVALUE;
L2: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55671);
    _id_55672 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55672)){
        _id_55672 = (long)DBL_PTR(_id_55672)->dbl;
    }

    /** 		tok = Term()*/
    _0 = _tok_55671;
    _tok_55671 = _30Term();
    DeRef(_0);

    /** 		emit_op(id)*/
    _37emit_op(_id_55672);

    /** 	end while*/
    goto L1; // [68] 13
L3: 

    /** 	return tok*/
    DeRef(_28431);
    _28431 = NOVALUE;
    return _tok_55671;
    ;
}


int _30cexpr()
{
    int _tok_55691 = NOVALUE;
    int _concat_count_55692 = NOVALUE;
    int _28438 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer concat_count*/

    /** 	tok = aexpr()*/
    _0 = _tok_55691;
    _tok_55691 = _30aexpr();
    DeRef(_0);

    /** 	concat_count = 0*/
    _concat_count_55692 = 0;

    /** 	while tok[T_ID] = reserved:CONCAT do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55691);
    _28438 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28438, 15)){
        _28438 = NOVALUE;
        goto L2; // [24] 44
    }
    _28438 = NOVALUE;

    /** 		tok = aexpr()*/
    _0 = _tok_55691;
    _tok_55691 = _30aexpr();
    DeRef(_0);

    /** 		concat_count += 1*/
    _concat_count_55692 = _concat_count_55692 + 1;

    /** 	end while*/
    goto L1; // [41] 18
L2: 

    /** 	if concat_count = 1 then*/
    if (_concat_count_55692 != 1)
    goto L3; // [46] 58

    /** 		emit_op( reserved:CONCAT )*/
    _37emit_op(15);
    goto L4; // [55] 81
L3: 

    /** 	elsif concat_count > 1 then*/
    if (_concat_count_55692 <= 1)
    goto L5; // [60] 80

    /** 		op_info1 = concat_count+1*/
    _37op_info1_49791 = _concat_count_55692 + 1;

    /** 		emit_op(CONCAT_N)*/
    _37emit_op(157);
L5: 
L4: 

    /** 	return tok*/
    return _tok_55691;
    ;
}


int _30rexpr()
{
    int _tok_55712 = NOVALUE;
    int _id_55713 = NOVALUE;
    int _28450 = NOVALUE;
    int _28449 = NOVALUE;
    int _28448 = NOVALUE;
    int _28447 = NOVALUE;
    int _28446 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	tok = cexpr()*/
    _0 = _tok_55712;
    _tok_55712 = _30cexpr();
    DeRef(_0);

    /** 	while tok[T_ID] <= GREATER and tok[T_ID] >= LESS do*/
L1: 
    _2 = (int)SEQ_PTR(_tok_55712);
    _28446 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28446)) {
        _28447 = (_28446 <= 6);
    }
    else {
        _28447 = binary_op(LESSEQ, _28446, 6);
    }
    _28446 = NOVALUE;
    if (IS_ATOM_INT(_28447)) {
        if (_28447 == 0) {
            goto L2; // [25] 70
        }
    }
    else {
        if (DBL_PTR(_28447)->dbl == 0.0) {
            goto L2; // [25] 70
        }
    }
    _2 = (int)SEQ_PTR(_tok_55712);
    _28449 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28449)) {
        _28450 = (_28449 >= 1);
    }
    else {
        _28450 = binary_op(GREATEREQ, _28449, 1);
    }
    _28449 = NOVALUE;
    if (_28450 <= 0) {
        if (_28450 == 0) {
            DeRef(_28450);
            _28450 = NOVALUE;
            goto L2; // [42] 70
        }
        else {
            if (!IS_ATOM_INT(_28450) && DBL_PTR(_28450)->dbl == 0.0){
                DeRef(_28450);
                _28450 = NOVALUE;
                goto L2; // [42] 70
            }
            DeRef(_28450);
            _28450 = NOVALUE;
        }
    }
    DeRef(_28450);
    _28450 = NOVALUE;

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55712);
    _id_55713 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55713)){
        _id_55713 = (long)DBL_PTR(_id_55713)->dbl;
    }

    /** 		tok = cexpr()*/
    _0 = _tok_55712;
    _tok_55712 = _30cexpr();
    DeRef(_0);

    /** 		emit_op(id)*/
    _37emit_op(_id_55713);

    /** 	end while*/
    goto L1; // [67] 13
L2: 

    /** 	return tok*/
    DeRef(_28447);
    _28447 = NOVALUE;
    return _tok_55712;
    ;
}


void _30Expr()
{
    int _tok_55739 = NOVALUE;
    int _id_55740 = NOVALUE;
    int _patch_55741 = NOVALUE;
    int _28473 = NOVALUE;
    int _28471 = NOVALUE;
    int _28470 = NOVALUE;
    int _28468 = NOVALUE;
    int _28467 = NOVALUE;
    int _28466 = NOVALUE;
    int _28465 = NOVALUE;
    int _28464 = NOVALUE;
    int _28458 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	integer patch*/

    /** 	ExprLine = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_30ExprLine_55734);
    _30ExprLine_55734 = _43ThisLine_48158;

    /** 	expr_bp = bp*/
    _30expr_bp_55735 = _43bp_48162;

    /** 	id = -1*/
    _id_55740 = -1;

    /** 	patch = 0*/
    _patch_55741 = 0;

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_431 == 0)
    {
        goto L2; // [40] 300
    }
    else{
    }

    /** 		if id != -1 then*/
    if (_id_55740 == -1)
    goto L3; // [45] 116

    /** 			if id != XOR then*/
    if (_id_55740 == 152)
    goto L4; // [53] 115

    /** 				if short_circuit > 0 then*/
    if (_30short_circuit_53685 <= 0)
    goto L5; // [61] 114

    /** 					if id = OR then*/
    if (_id_55740 != 9)
    goto L6; // [69] 83

    /** 						emit_op(SC1_OR)*/
    _37emit_op(143);
    goto L7; // [80] 91
L6: 

    /** 						emit_op(SC1_AND)*/
    _37emit_op(141);
L7: 

    /** 					patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28458 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28458 = 1;
    }
    _patch_55741 = _28458 + 1;
    _28458 = NOVALUE;

    /** 					emit_forward_addr()*/
    _30emit_forward_addr();

    /** 					short_circuit_B = TRUE*/
    _30short_circuit_B_53687 = _9TRUE_431;
L5: 
L4: 
L3: 

    /** 		tok = rexpr()*/
    _0 = _tok_55739;
    _tok_55739 = _30rexpr();
    DeRef(_0);

    /** 		if id != -1 then*/
    if (_id_55740 == -1)
    goto L8; // [123] 268

    /** 			if id != XOR then*/
    if (_id_55740 == 152)
    goto L9; // [131] 261

    /** 				if short_circuit > 0 then*/
    if (_30short_circuit_53685 <= 0)
    goto LA; // [139] 252

    /** 					if tok[T_ID] != THEN and tok[T_ID] != DO then*/
    _2 = (int)SEQ_PTR(_tok_55739);
    _28464 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28464)) {
        _28465 = (_28464 != 410);
    }
    else {
        _28465 = binary_op(NOTEQ, _28464, 410);
    }
    _28464 = NOVALUE;
    if (IS_ATOM_INT(_28465)) {
        if (_28465 == 0) {
            goto LB; // [157] 206
        }
    }
    else {
        if (DBL_PTR(_28465)->dbl == 0.0) {
            goto LB; // [157] 206
        }
    }
    _2 = (int)SEQ_PTR(_tok_55739);
    _28467 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28467)) {
        _28468 = (_28467 != 411);
    }
    else {
        _28468 = binary_op(NOTEQ, _28467, 411);
    }
    _28467 = NOVALUE;
    if (_28468 == 0) {
        DeRef(_28468);
        _28468 = NOVALUE;
        goto LB; // [174] 206
    }
    else {
        if (!IS_ATOM_INT(_28468) && DBL_PTR(_28468)->dbl == 0.0){
            DeRef(_28468);
            _28468 = NOVALUE;
            goto LB; // [174] 206
        }
        DeRef(_28468);
        _28468 = NOVALUE;
    }
    DeRef(_28468);
    _28468 = NOVALUE;

    /** 						if id = OR then*/
    if (_id_55740 != 9)
    goto LC; // [181] 195

    /** 							emit_op(SC2_OR)*/
    _37emit_op(144);
    goto LD; // [192] 219
LC: 

    /** 							emit_op(SC2_AND)*/
    _37emit_op(142);
    goto LD; // [203] 219
LB: 

    /** 						SC1_type = id -- if/while/elsif must patch*/
    _30SC1_type_53690 = _id_55740;

    /** 						emit_op(SC2_NULL)*/
    _37emit_op(145);
LD: 

    /** 					if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LE; // [223] 234
    }
    else{
    }

    /** 						emit_op(NOP1)   -- to get label here*/
    _37emit_op(159);
LE: 

    /** 					backpatch(patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28470 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28470 = 1;
    }
    _28471 = _28470 + 1;
    _28470 = NOVALUE;
    _37backpatch(_patch_55741, _28471);
    _28471 = NOVALUE;
    goto LF; // [249] 267
LA: 

    /** 					emit_op(id)*/
    _37emit_op(_id_55740);
    goto LF; // [258] 267
L9: 

    /** 				emit_op(id)*/
    _37emit_op(_id_55740);
LF: 
L8: 

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55739);
    _id_55740 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_55740)){
        _id_55740 = (long)DBL_PTR(_id_55740)->dbl;
    }

    /** 		if not find(id, boolOps) then*/
    _28473 = find_from(_id_55740, _30boolOps_55729, 1);
    if (_28473 != 0)
    goto L1; // [287] 38
    _28473 = NOVALUE;

    /** 			exit*/
    goto L2; // [292] 300

    /** 	end while*/
    goto L1; // [297] 38
L2: 

    /** 	putback(tok)*/
    Ref(_tok_55739);
    _30putback(_tok_55739);

    /** 	SC1_patch = patch -- extra line*/
    _30SC1_patch_53689 = _patch_55741;

    /** end procedure*/
    DeRef(_tok_55739);
    DeRef(_28465);
    _28465 = NOVALUE;
    return;
    ;
}


void _30TypeCheck(int _var_55816)
{
    int _which_type_55817 = NOVALUE;
    int _ref_55827 = NOVALUE;
    int _ref_55860 = NOVALUE;
    int _28529 = NOVALUE;
    int _28528 = NOVALUE;
    int _28527 = NOVALUE;
    int _28526 = NOVALUE;
    int _28525 = NOVALUE;
    int _28523 = NOVALUE;
    int _28522 = NOVALUE;
    int _28521 = NOVALUE;
    int _28520 = NOVALUE;
    int _28519 = NOVALUE;
    int _28518 = NOVALUE;
    int _28516 = NOVALUE;
    int _28515 = NOVALUE;
    int _28512 = NOVALUE;
    int _28511 = NOVALUE;
    int _28510 = NOVALUE;
    int _28509 = NOVALUE;
    int _28504 = NOVALUE;
    int _28503 = NOVALUE;
    int _28499 = NOVALUE;
    int _28497 = NOVALUE;
    int _28496 = NOVALUE;
    int _28495 = NOVALUE;
    int _28493 = NOVALUE;
    int _28492 = NOVALUE;
    int _28491 = NOVALUE;
    int _28490 = NOVALUE;
    int _28489 = NOVALUE;
    int _28488 = NOVALUE;
    int _28485 = NOVALUE;
    int _28483 = NOVALUE;
    int _28481 = NOVALUE;
    int _28480 = NOVALUE;
    int _28479 = NOVALUE;
    int _28477 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if var < 0 or SymTab[var][S_SCOPE] = SC_UNDEFINED then*/
    _28477 = (_var_55816 < 0);
    if (_28477 != 0) {
        goto L1; // [9] 36
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28479 = (int)*(((s1_ptr)_2)->base + _var_55816);
    _2 = (int)SEQ_PTR(_28479);
    _28480 = (int)*(((s1_ptr)_2)->base + 4);
    _28479 = NOVALUE;
    if (IS_ATOM_INT(_28480)) {
        _28481 = (_28480 == 9);
    }
    else {
        _28481 = binary_op(EQUALS, _28480, 9);
    }
    _28480 = NOVALUE;
    if (_28481 == 0) {
        DeRef(_28481);
        _28481 = NOVALUE;
        goto L2; // [32] 76
    }
    else {
        if (!IS_ATOM_INT(_28481) && DBL_PTR(_28481)->dbl == 0.0){
            DeRef(_28481);
            _28481 = NOVALUE;
            goto L2; // [32] 76
        }
        DeRef(_28481);
        _28481 = NOVALUE;
    }
    DeRef(_28481);
    _28481 = NOVALUE;
L1: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, var, TYPE_CHECK_FORWARD )*/
    _ref_55827 = _29new_forward_reference(65, _var_55816, 197);
    if (!IS_ATOM_INT(_ref_55827)) {
        _1 = (long)(DBL_PTR(_ref_55827)->dbl);
        DeRefDS(_ref_55827);
        _ref_55827 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_55816;
    *((int *)(_2+12)) = _12OpTypeCheck_11753;
    _28483 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_11771, _12Code_11771, _28483);
    DeRefDS(_28483);
    _28483 = NOVALUE;

    /** 		return*/
    DeRef(_28477);
    _28477 = NOVALUE;
    return;
L2: 

    /** 	which_type = SymTab[var][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28485 = (int)*(((s1_ptr)_2)->base + _var_55816);
    _2 = (int)SEQ_PTR(_28485);
    _which_type_55817 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_which_type_55817)){
        _which_type_55817 = (long)DBL_PTR(_which_type_55817)->dbl;
    }
    _28485 = NOVALUE;

    /** 	if which_type = 0 then*/
    if (_which_type_55817 != 0)
    goto L3; // [96] 106

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28477);
    _28477 = NOVALUE;
    return;
L3: 

    /** 	if which_type > 0 and length(SymTab[which_type]) < S_TOKEN then*/
    _28488 = (_which_type_55817 > 0);
    if (_28488 == 0) {
        goto L4; // [112] 141
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28490 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
    if (IS_SEQUENCE(_28490)){
            _28491 = SEQ_PTR(_28490)->length;
    }
    else {
        _28491 = 1;
    }
    _28490 = NOVALUE;
    if (IS_ATOM_INT(_12S_TOKEN_11359)) {
        _28492 = (_28491 < _12S_TOKEN_11359);
    }
    else {
        _28492 = binary_op(LESS, _28491, _12S_TOKEN_11359);
    }
    _28491 = NOVALUE;
    if (_28492 == 0) {
        DeRef(_28492);
        _28492 = NOVALUE;
        goto L4; // [132] 141
    }
    else {
        if (!IS_ATOM_INT(_28492) && DBL_PTR(_28492)->dbl == 0.0){
            DeRef(_28492);
            _28492 = NOVALUE;
            goto L4; // [132] 141
        }
        DeRef(_28492);
        _28492 = NOVALUE;
    }
    DeRef(_28492);
    _28492 = NOVALUE;

    /** 		return	-- Not a typed identifier.*/
    DeRef(_28477);
    _28477 = NOVALUE;
    DeRef(_28488);
    _28488 = NOVALUE;
    _28490 = NOVALUE;
    return;
L4: 

    /** 	if which_type < 0 or SymTab[which_type][S_TOKEN] = VARIABLE  then*/
    _28493 = (_which_type_55817 < 0);
    if (_28493 != 0) {
        goto L5; // [147] 174
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28495 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
    _2 = (int)SEQ_PTR(_28495);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _28496 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _28496 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _28495 = NOVALUE;
    if (IS_ATOM_INT(_28496)) {
        _28497 = (_28496 == -100);
    }
    else {
        _28497 = binary_op(EQUALS, _28496, -100);
    }
    _28496 = NOVALUE;
    if (_28497 == 0) {
        DeRef(_28497);
        _28497 = NOVALUE;
        goto L6; // [170] 214
    }
    else {
        if (!IS_ATOM_INT(_28497) && DBL_PTR(_28497)->dbl == 0.0){
            DeRef(_28497);
            _28497 = NOVALUE;
            goto L6; // [170] 214
        }
        DeRef(_28497);
        _28497 = NOVALUE;
    }
    DeRef(_28497);
    _28497 = NOVALUE;
L5: 

    /** 		integer ref = new_forward_reference( TYPE_CHECK, which_type, TYPE )*/
    _ref_55860 = _29new_forward_reference(65, _which_type_55817, 504);
    if (!IS_ATOM_INT(_ref_55860)) {
        _1 = (long)(DBL_PTR(_ref_55860)->dbl);
        DeRefDS(_ref_55860);
        _ref_55860 = _1;
    }

    /** 		Code &= { TYPE_CHECK_FORWARD, var, OpTypeCheck }*/
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 197;
    *((int *)(_2+8)) = _var_55816;
    *((int *)(_2+12)) = _12OpTypeCheck_11753;
    _28499 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12Code_11771, _12Code_11771, _28499);
    DeRefDS(_28499);
    _28499 = NOVALUE;

    /** 		return*/
    DeRef(_28477);
    _28477 = NOVALUE;
    DeRef(_28488);
    _28488 = NOVALUE;
    _28490 = NOVALUE;
    DeRef(_28493);
    _28493 = NOVALUE;
    return;
L6: 

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L7; // [220] 317
    }
    else{
    }

    /** 		if OpTypeCheck then*/
    if (_12OpTypeCheck_11753 == 0)
    {
        goto L8; // [227] 481
    }
    else{
    }

    /** 			switch which_type do*/
    if( _30_55874_cases == 0 ){
        _30_55874_cases = 1;
        SEQ_PTR( _28501 )->base[1] = _52object_type_45731;
        SEQ_PTR( _28501 )->base[2] = _52sequence_type_45735;
        SEQ_PTR( _28501 )->base[3] = _52atom_type_45733;
        SEQ_PTR( _28501 )->base[4] = _52integer_type_45737;
    }
    _1 = find(_which_type_55817, _28501);
    switch ( _1 ){ 

        /** 				case object_type, sequence_type, atom_type then*/
        case 1:
        case 2:
        case 3:

        /** 				case integer_type then*/
        goto L8; // [247] 481
        case 4:

        /** 					op_info1 = var*/
        _37op_info1_49791 = _var_55816;

        /** 					emit_op(INTEGER_CHECK)*/
        _37emit_op(96);
        goto L8; // [265] 481

        /** 				case else*/
        case 0:

        /** 					if SymTab[which_type][S_EFFECT] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _28503 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
        _2 = (int)SEQ_PTR(_28503);
        _28504 = (int)*(((s1_ptr)_2)->base + 23);
        _28503 = NOVALUE;
        if (_28504 == 0) {
            _28504 = NOVALUE;
            goto L9; // [285] 312
        }
        else {
            if (!IS_ATOM_INT(_28504) && DBL_PTR(_28504)->dbl == 0.0){
                _28504 = NOVALUE;
                goto L9; // [285] 312
            }
            _28504 = NOVALUE;
        }
        _28504 = NOVALUE;

        /** 						emit_opnd(var)*/
        _37emit_opnd(_var_55816);

        /** 						op_info1 = which_type*/
        _37op_info1_49791 = _which_type_55817;

        /** 						emit_or_inline()*/
        _66emit_or_inline();

        /** 						emit_op(TYPE_CHECK)*/
        _37emit_op(65);
L9: 
    ;}    goto L8; // [314] 481
L7: 

    /** 		if OpTypeCheck then*/
    if (_12OpTypeCheck_11753 == 0)
    {
        goto LA; // [321] 480
    }
    else{
    }

    /** 			if which_type != object_type then*/
    if (_which_type_55817 == _52object_type_45731)
    goto LB; // [328] 479

    /** 				if which_type = integer_type then*/
    if (_which_type_55817 != _52integer_type_45737)
    goto LC; // [336] 357

    /** 						op_info1 = var*/
    _37op_info1_49791 = _var_55816;

    /** 						emit_op(INTEGER_CHECK)*/
    _37emit_op(96);
    goto LD; // [354] 478
LC: 

    /** 				elsif which_type = sequence_type then*/
    if (_which_type_55817 != _52sequence_type_45735)
    goto LE; // [361] 382

    /** 						op_info1 = var*/
    _37op_info1_49791 = _var_55816;

    /** 						emit_op(SEQUENCE_CHECK)*/
    _37emit_op(97);
    goto LD; // [379] 478
LE: 

    /** 				elsif which_type = atom_type then*/
    if (_which_type_55817 != _52atom_type_45733)
    goto LF; // [386] 407

    /** 						op_info1 = var*/
    _37op_info1_49791 = _var_55816;

    /** 						emit_op(ATOM_CHECK)*/
    _37emit_op(101);
    goto LD; // [404] 478
LF: 

    /** 						if SymTab[SymTab[which_type][S_NEXT]][S_VTYPE] =*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28509 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
    _2 = (int)SEQ_PTR(_28509);
    _28510 = (int)*(((s1_ptr)_2)->base + 2);
    _28509 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28510)){
        _28511 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28510)->dbl));
    }
    else{
        _28511 = (int)*(((s1_ptr)_2)->base + _28510);
    }
    _2 = (int)SEQ_PTR(_28511);
    _28512 = (int)*(((s1_ptr)_2)->base + 15);
    _28511 = NOVALUE;
    if (binary_op_a(NOTEQ, _28512, _52integer_type_45737)){
        _28512 = NOVALUE;
        goto L10; // [435] 454
    }
    _28512 = NOVALUE;

    /** 							op_info1 = var*/
    _37op_info1_49791 = _var_55816;

    /** 							emit_op(INTEGER_CHECK) -- need integer conversion*/
    _37emit_op(96);
L10: 

    /** 						emit_opnd(var)*/
    _37emit_opnd(_var_55816);

    /** 						op_info1 = which_type*/
    _37op_info1_49791 = _which_type_55817;

    /** 						emit_or_inline()*/
    _66emit_or_inline();

    /** 						emit_op(TYPE_CHECK)*/
    _37emit_op(65);
LD: 
LB: 
LA: 
L8: 

    /** 	if TRANSLATE or not OpTypeCheck then*/
    if (_12TRANSLATE_11319 != 0) {
        goto L11; // [485] 499
    }
    _28515 = (_12OpTypeCheck_11753 == 0);
    if (_28515 == 0)
    {
        DeRef(_28515);
        _28515 = NOVALUE;
        goto L12; // [495] 620
    }
    else{
        DeRef(_28515);
        _28515 = NOVALUE;
    }
L11: 

    /** 		op_info1 = var*/
    _37op_info1_49791 = _var_55816;

    /** 		if which_type = sequence_type or*/
    _28516 = (_which_type_55817 == _52sequence_type_45735);
    if (_28516 != 0) {
        goto L13; // [514] 553
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28518 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
    _2 = (int)SEQ_PTR(_28518);
    _28519 = (int)*(((s1_ptr)_2)->base + 2);
    _28518 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28519)){
        _28520 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28519)->dbl));
    }
    else{
        _28520 = (int)*(((s1_ptr)_2)->base + _28519);
    }
    _2 = (int)SEQ_PTR(_28520);
    _28521 = (int)*(((s1_ptr)_2)->base + 15);
    _28520 = NOVALUE;
    if (IS_ATOM_INT(_28521)) {
        _28522 = (_28521 == _52sequence_type_45735);
    }
    else {
        _28522 = binary_op(EQUALS, _28521, _52sequence_type_45735);
    }
    _28521 = NOVALUE;
    if (_28522 == 0) {
        DeRef(_28522);
        _28522 = NOVALUE;
        goto L14; // [549] 563
    }
    else {
        if (!IS_ATOM_INT(_28522) && DBL_PTR(_28522)->dbl == 0.0){
            DeRef(_28522);
            _28522 = NOVALUE;
            goto L14; // [549] 563
        }
        DeRef(_28522);
        _28522 = NOVALUE;
    }
    DeRef(_28522);
    _28522 = NOVALUE;
L13: 

    /** 			emit_op(SEQUENCE_CHECK)*/
    _37emit_op(97);
    goto L15; // [560] 619
L14: 

    /** 		elsif which_type = integer_type or*/
    _28523 = (_which_type_55817 == _52integer_type_45737);
    if (_28523 != 0) {
        goto L16; // [571] 610
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28525 = (int)*(((s1_ptr)_2)->base + _which_type_55817);
    _2 = (int)SEQ_PTR(_28525);
    _28526 = (int)*(((s1_ptr)_2)->base + 2);
    _28525 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28526)){
        _28527 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28526)->dbl));
    }
    else{
        _28527 = (int)*(((s1_ptr)_2)->base + _28526);
    }
    _2 = (int)SEQ_PTR(_28527);
    _28528 = (int)*(((s1_ptr)_2)->base + 15);
    _28527 = NOVALUE;
    if (IS_ATOM_INT(_28528)) {
        _28529 = (_28528 == _52integer_type_45737);
    }
    else {
        _28529 = binary_op(EQUALS, _28528, _52integer_type_45737);
    }
    _28528 = NOVALUE;
    if (_28529 == 0) {
        DeRef(_28529);
        _28529 = NOVALUE;
        goto L17; // [606] 618
    }
    else {
        if (!IS_ATOM_INT(_28529) && DBL_PTR(_28529)->dbl == 0.0){
            DeRef(_28529);
            _28529 = NOVALUE;
            goto L17; // [606] 618
        }
        DeRef(_28529);
        _28529 = NOVALUE;
    }
    DeRef(_28529);
    _28529 = NOVALUE;
L16: 

    /** 			emit_op(INTEGER_CHECK)*/
    _37emit_op(96);
L17: 
L15: 
L12: 

    /** end procedure*/
    DeRef(_28477);
    _28477 = NOVALUE;
    DeRef(_28488);
    _28488 = NOVALUE;
    _28490 = NOVALUE;
    DeRef(_28493);
    _28493 = NOVALUE;
    _28510 = NOVALUE;
    DeRef(_28516);
    _28516 = NOVALUE;
    _28519 = NOVALUE;
    DeRef(_28523);
    _28523 = NOVALUE;
    _28526 = NOVALUE;
    return;
    ;
}


void _30Assignment(int _left_var_55981)
{
    int _tok_55983 = NOVALUE;
    int _subs_55984 = NOVALUE;
    int _slice_55985 = NOVALUE;
    int _assign_op_55986 = NOVALUE;
    int _subs1_patch_55987 = NOVALUE;
    int _dangerous_55989 = NOVALUE;
    int _lname_56113 = NOVALUE;
    int _temp_len_56130 = NOVALUE;
    int _28628 = NOVALUE;
    int _28627 = NOVALUE;
    int _28626 = NOVALUE;
    int _28625 = NOVALUE;
    int _28624 = NOVALUE;
    int _28623 = NOVALUE;
    int _28622 = NOVALUE;
    int _28621 = NOVALUE;
    int _28612 = NOVALUE;
    int _28611 = NOVALUE;
    int _28610 = NOVALUE;
    int _28609 = NOVALUE;
    int _28608 = NOVALUE;
    int _28607 = NOVALUE;
    int _28606 = NOVALUE;
    int _28605 = NOVALUE;
    int _28604 = NOVALUE;
    int _28603 = NOVALUE;
    int _28602 = NOVALUE;
    int _28601 = NOVALUE;
    int _28600 = NOVALUE;
    int _28599 = NOVALUE;
    int _28598 = NOVALUE;
    int _28596 = NOVALUE;
    int _28595 = NOVALUE;
    int _28594 = NOVALUE;
    int _28592 = NOVALUE;
    int _28587 = NOVALUE;
    int _28586 = NOVALUE;
    int _28583 = NOVALUE;
    int _28582 = NOVALUE;
    int _28580 = NOVALUE;
    int _28574 = NOVALUE;
    int _28569 = NOVALUE;
    int _28566 = NOVALUE;
    int _28565 = NOVALUE;
    int _28562 = NOVALUE;
    int _28559 = NOVALUE;
    int _28558 = NOVALUE;
    int _28557 = NOVALUE;
    int _28555 = NOVALUE;
    int _28554 = NOVALUE;
    int _28553 = NOVALUE;
    int _28552 = NOVALUE;
    int _28551 = NOVALUE;
    int _28550 = NOVALUE;
    int _28548 = NOVALUE;
    int _28547 = NOVALUE;
    int _28546 = NOVALUE;
    int _28545 = NOVALUE;
    int _28543 = NOVALUE;
    int _28542 = NOVALUE;
    int _28541 = NOVALUE;
    int _28540 = NOVALUE;
    int _28539 = NOVALUE;
    int _28537 = NOVALUE;
    int _28536 = NOVALUE;
    int _28535 = NOVALUE;
    int _28532 = NOVALUE;
    int _28531 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer subs, slice, assign_op, subs1_patch*/

    /** 	left_sym = left_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_left_var_55981);
    _30left_sym_53726 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_30left_sym_53726)){
        _30left_sym_53726 = (long)DBL_PTR(_30left_sym_53726)->dbl;
    }

    /** 	if SymTab[left_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28531 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28531);
    _28532 = (int)*(((s1_ptr)_2)->base + 4);
    _28531 = NOVALUE;
    if (binary_op_a(NOTEQ, _28532, 9)){
        _28532 = NOVALUE;
        goto L1; // [31] 54
    }
    _28532 = NOVALUE;

    /** 		Forward_var( left_var, ,ASSIGN )*/
    Ref(_left_var_55981);
    _30Forward_var(_left_var_55981, -1, 18);

    /** 		left_sym = Pop() -- pops off what forward var emitted, because it gets emitted later*/
    _0 = _37Pop();
    _30left_sym_53726 = _0;
    if (!IS_ATOM_INT(_30left_sym_53726)) {
        _1 = (long)(DBL_PTR(_30left_sym_53726)->dbl);
        DeRefDS(_30left_sym_53726);
        _30left_sym_53726 = _1;
    }
    goto L2; // [51] 267
L1: 

    /** 		UndefinedVar(left_sym)*/
    _30UndefinedVar(_30left_sym_53726);

    /** 		if SymTab[left_sym][S_SCOPE] = SC_LOOP_VAR or*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28535 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28535);
    _28536 = (int)*(((s1_ptr)_2)->base + 4);
    _28535 = NOVALUE;
    if (IS_ATOM_INT(_28536)) {
        _28537 = (_28536 == 2);
    }
    else {
        _28537 = binary_op(EQUALS, _28536, 2);
    }
    _28536 = NOVALUE;
    if (IS_ATOM_INT(_28537)) {
        if (_28537 != 0) {
            goto L3; // [83] 112
        }
    }
    else {
        if (DBL_PTR(_28537)->dbl != 0.0) {
            goto L3; // [83] 112
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28539 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28539);
    _28540 = (int)*(((s1_ptr)_2)->base + 4);
    _28539 = NOVALUE;
    if (IS_ATOM_INT(_28540)) {
        _28541 = (_28540 == 4);
    }
    else {
        _28541 = binary_op(EQUALS, _28540, 4);
    }
    _28540 = NOVALUE;
    if (_28541 == 0) {
        DeRef(_28541);
        _28541 = NOVALUE;
        goto L4; // [108] 122
    }
    else {
        if (!IS_ATOM_INT(_28541) && DBL_PTR(_28541)->dbl == 0.0){
            DeRef(_28541);
            _28541 = NOVALUE;
            goto L4; // [108] 122
        }
        DeRef(_28541);
        _28541 = NOVALUE;
    }
    DeRef(_28541);
    _28541 = NOVALUE;
L3: 

    /** 			CompileErr(109)*/
    RefDS(_21829);
    _43CompileErr(109, _21829, 0);
    goto L5; // [119] 229
L4: 

    /** 		elsif SymTab[left_sym][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28542 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28542);
    _28543 = (int)*(((s1_ptr)_2)->base + 3);
    _28542 = NOVALUE;
    if (binary_op_a(NOTEQ, _28543, 2)){
        _28543 = NOVALUE;
        goto L6; // [140] 154
    }
    _28543 = NOVALUE;

    /** 			CompileErr(110)*/
    RefDS(_21829);
    _43CompileErr(110, _21829, 0);
    goto L5; // [151] 229
L6: 

    /** 		elsif find(SymTab[left_sym][S_SCOPE], SCOPE_TYPES) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28545 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28545);
    _28546 = (int)*(((s1_ptr)_2)->base + 4);
    _28545 = NOVALUE;
    _28547 = find_from(_28546, _30SCOPE_TYPES_53676, 1);
    _28546 = NOVALUE;
    if (_28547 == 0)
    {
        _28547 = NOVALUE;
        goto L7; // [177] 228
    }
    else{
        _28547 = NOVALUE;
    }

    /** 			SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28550 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_28550);
    _28551 = (int)*(((s1_ptr)_2)->base + 23);
    _28550 = NOVALUE;
    _28552 = (_30left_sym_53726 % 29);
    _28553 = power(2, _28552);
    _28552 = NOVALUE;
    if (IS_ATOM_INT(_28551) && IS_ATOM_INT(_28553)) {
        {unsigned long tu;
             tu = (unsigned long)_28551 | (unsigned long)_28553;
             _28554 = MAKE_UINT(tu);
        }
    }
    else {
        _28554 = binary_op(OR_BITS, _28551, _28553);
    }
    _28551 = NOVALUE;
    DeRef(_28553);
    _28553 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _28554;
    if( _1 != _28554 ){
        DeRef(_1);
    }
    _28554 = NOVALUE;
    _28548 = NOVALUE;
L7: 
L5: 

    /** 		SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_WRITTEN)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_30left_sym_53726 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28557 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28557);
    _28558 = (int)*(((s1_ptr)_2)->base + 5);
    _28557 = NOVALUE;
    if (IS_ATOM_INT(_28558)) {
        {unsigned long tu;
             tu = (unsigned long)_28558 | (unsigned long)2;
             _28559 = MAKE_UINT(tu);
        }
    }
    else {
        _28559 = binary_op(OR_BITS, _28558, 2);
    }
    _28558 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28559;
    if( _1 != _28559 ){
        DeRef(_1);
    }
    _28559 = NOVALUE;
    _28555 = NOVALUE;
L2: 

    /** 	tok = next_token()*/
    _0 = _tok_55983;
    _tok_55983 = _30next_token();
    DeRef(_0);

    /** 	subs = 0*/
    _subs_55984 = 0;

    /** 	slice = FALSE*/
    _slice_55985 = _9FALSE_429;

    /** 	dangerous = FALSE*/
    _dangerous_55989 = _9FALSE_429;

    /** 	side_effect_calls = 0*/
    _30side_effect_calls_53722 = 0;

    /** 	emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_53726);

    /** 	current_sequence = append(current_sequence, left_sym)*/
    Append(&_37current_sequence_49799, _37current_sequence_49799, _30left_sym_53726);

    /** 	while tok[T_ID] = LEFT_SQUARE do*/
L8: 
    _2 = (int)SEQ_PTR(_tok_55983);
    _28562 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28562, -28)){
        _28562 = NOVALUE;
        goto L9; // [330] 522
    }
    _28562 = NOVALUE;

    /** 		subs_depth += 1*/
    _30subs_depth_53727 = _30subs_depth_53727 + 1;

    /** 		if lhs_ptr then*/
    if (_37lhs_ptr_49801 == 0)
    {
        goto LA; // [346] 404
    }
    else{
    }

    /** 			current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_37current_sequence_49799)){
            _28565 = SEQ_PTR(_37current_sequence_49799)->length;
    }
    else {
        _28565 = 1;
    }
    _28566 = _28565 - 1;
    _28565 = NOVALUE;
    {
        int len = SEQ_PTR(_37current_sequence_49799)->length;
        int size = (IS_ATOM_INT(_28566)) ? _28566 : (object)(DBL_PTR(_28566)->dbl);
        if (size <= 0){
            DeRef( _37current_sequence_49799 );
            _37current_sequence_49799 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_37current_sequence_49799);
            DeRef(_37current_sequence_49799);
            _37current_sequence_49799 = _37current_sequence_49799;
        }
        else{
            Head(SEQ_PTR(_37current_sequence_49799),size+1,&_37current_sequence_49799);
        }
    }
    _28566 = NOVALUE;

    /** 			if subs = 1 then*/
    if (_subs_55984 != 1)
    goto LB; // [370] 395

    /** 				subs1_patch = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28569 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28569 = 1;
    }
    _subs1_patch_55987 = _28569 + 1;
    _28569 = NOVALUE;

    /** 				emit_op(LHS_SUBS1) -- creates new current_sequence*/
    _37emit_op(161);
    goto LC; // [392] 403
LB: 

    /** 				emit_op(LHS_SUBS) -- adds to current_sequence*/
    _37emit_op(95);
LC: 
LA: 

    /** 		subs += 1*/
    _subs_55984 = _subs_55984 + 1;

    /** 		if subs = 1 then*/
    if (_subs_55984 != 1)
    goto LD; // [412] 427

    /** 			InitCheck(left_sym, TRUE)*/
    _30InitCheck(_30left_sym_53726, _9TRUE_431);
LD: 

    /** 		Expr()*/
    _30Expr();

    /** 		tok = next_token()*/
    _0 = _tok_55983;
    _tok_55983 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = SLICE then*/
    _2 = (int)SEQ_PTR(_tok_55983);
    _28574 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28574, 513)){
        _28574 = NOVALUE;
        goto LE; // [446] 483
    }
    _28574 = NOVALUE;

    /** 			Expr()*/
    _30Expr();

    /** 			slice = TRUE*/
    _slice_55985 = _9TRUE_431;

    /** 			tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 			tok = next_token()*/
    _0 = _tok_55983;
    _tok_55983 = _30next_token();
    DeRef(_0);

    /** 			exit  -- no further subs or slices allowed*/
    goto L9; // [478] 522
    goto LF; // [480] 505
LE: 

    /** 			putback(tok)*/
    Ref(_tok_55983);
    _30putback(_tok_55983);

    /** 			tok_match(RIGHT_SQUARE)*/
    _30tok_match(-29, 0);

    /** 			subs_depth -= 1*/
    _30subs_depth_53727 = _30subs_depth_53727 - 1;
LF: 

    /** 		tok = next_token()*/
    _0 = _tok_55983;
    _tok_55983 = _30next_token();
    DeRef(_0);

    /** 		lhs_ptr = TRUE*/
    _37lhs_ptr_49801 = _9TRUE_431;

    /** 	end while*/
    goto L8; // [519] 322
L9: 

    /** 	lhs_ptr = FALSE*/
    _37lhs_ptr_49801 = _9FALSE_429;

    /** 	assign_op = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_55983);
    _assign_op_55986 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_assign_op_55986)){
        _assign_op_55986 = (long)DBL_PTR(_assign_op_55986)->dbl;
    }

    /** 	if not find(assign_op, ASSIGN_OPS) then*/
    _28580 = find_from(_assign_op_55986, _30ASSIGN_OPS_53668, 1);
    if (_28580 != 0)
    goto L10; // [548] 608
    _28580 = NOVALUE;

    /** 		sequence lname = SymTab[left_var[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_left_var_55981);
    _28582 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28582)){
        _28583 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28582)->dbl));
    }
    else{
        _28583 = (int)*(((s1_ptr)_2)->base + _28582);
    }
    DeRef(_lname_56113);
    _2 = (int)SEQ_PTR(_28583);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _lname_56113 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _lname_56113 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_lname_56113);
    _28583 = NOVALUE;

    /** 		if assign_op = COLON then*/
    if (_assign_op_55986 != -23)
    goto L11; // [577] 595

    /** 			CompileErr(133, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56113);
    *((int *)(_2+4)) = _lname_56113;
    _28586 = MAKE_SEQ(_1);
    _43CompileErr(133, _28586, 0);
    _28586 = NOVALUE;
    goto L12; // [592] 607
L11: 

    /** 			CompileErr(76, {lname})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lname_56113);
    *((int *)(_2+4)) = _lname_56113;
    _28587 = MAKE_SEQ(_1);
    _43CompileErr(76, _28587, 0);
    _28587 = NOVALUE;
L12: 
L10: 
    DeRef(_lname_56113);
    _lname_56113 = NOVALUE;

    /** 	if subs = 0 then*/
    if (_subs_55984 != 0)
    goto L13; // [612] 740

    /** 		integer temp_len = length(Code)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _temp_len_56130 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _temp_len_56130 = 1;
    }

    /** 		if assign_op = EQUALS then*/
    if (_assign_op_55986 != 3)
    goto L14; // [627] 648

    /** 			Expr() -- RHS expression*/
    _30Expr();

    /** 			InitCheck(left_sym, FALSE)*/
    _30InitCheck(_30left_sym_53726, _9FALSE_429);
    goto L15; // [645] 721
L14: 

    /** 			InitCheck(left_sym, TRUE)*/
    _30InitCheck(_30left_sym_53726, _9TRUE_431);

    /** 			if left_sym > 0 then*/
    if (_30left_sym_53726 <= 0)
    goto L16; // [662] 704

    /** 				SymTab[left_sym][S_USAGE] = or_bits(SymTab[left_sym][S_USAGE], U_READ)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_30left_sym_53726 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28594 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28594);
    _28595 = (int)*(((s1_ptr)_2)->base + 5);
    _28594 = NOVALUE;
    if (IS_ATOM_INT(_28595)) {
        {unsigned long tu;
             tu = (unsigned long)_28595 | (unsigned long)1;
             _28596 = MAKE_UINT(tu);
        }
    }
    else {
        _28596 = binary_op(OR_BITS, _28595, 1);
    }
    _28595 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _28596;
    if( _1 != _28596 ){
        DeRef(_1);
    }
    _28596 = NOVALUE;
    _28592 = NOVALUE;
L16: 

    /** 			emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_53726);

    /** 			Expr() -- RHS expression*/
    _30Expr();

    /** 			emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_55986);
L15: 

    /** 		emit_op(ASSIGN)*/
    _37emit_op(18);

    /** 		TypeCheck(left_sym)*/
    _30TypeCheck(_30left_sym_53726);
    goto L17; // [737] 1164
L13: 

    /** 		factors = 0*/
    _30factors_53723 = 0;

    /** 		lhs_subs_level = -1*/
    _30lhs_subs_level_53724 = -1;

    /** 		Expr() -- RHS expression*/
    _30Expr();

    /** 		if subs > 1 then*/
    if (_subs_55984 <= 1)
    goto L18; // [756] 895

    /** 			if left_sym < 0 or SymTab[left_sym][S_SCOPE] != SC_PRIVATE and*/
    _28598 = (_30left_sym_53726 < 0);
    if (_28598 != 0) {
        _28599 = 1;
        goto L19; // [768] 796
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28600 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28600);
    _28601 = (int)*(((s1_ptr)_2)->base + 4);
    _28600 = NOVALUE;
    if (IS_ATOM_INT(_28601)) {
        _28602 = (_28601 != 3);
    }
    else {
        _28602 = binary_op(NOTEQ, _28601, 3);
    }
    _28601 = NOVALUE;
    if (IS_ATOM_INT(_28602))
    _28599 = (_28602 != 0);
    else
    _28599 = DBL_PTR(_28602)->dbl != 0.0;
L19: 
    if (_28599 == 0) {
        goto L1A; // [796] 830
    }
    _28604 = (_30left_sym_53726 % 29);
    _28605 = power(2, _28604);
    _28604 = NOVALUE;
    if (IS_ATOM_INT(_28605)) {
        {unsigned long tu;
             tu = (unsigned long)_30side_effect_calls_53722 & (unsigned long)_28605;
             _28606 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_30side_effect_calls_53722;
        _28606 = Dand_bits(&temp_d, DBL_PTR(_28605));
    }
    DeRef(_28605);
    _28605 = NOVALUE;
    if (_28606 == 0) {
        DeRef(_28606);
        _28606 = NOVALUE;
        goto L1A; // [819] 830
    }
    else {
        if (!IS_ATOM_INT(_28606) && DBL_PTR(_28606)->dbl == 0.0){
            DeRef(_28606);
            _28606 = NOVALUE;
            goto L1A; // [819] 830
        }
        DeRef(_28606);
        _28606 = NOVALUE;
    }
    DeRef(_28606);
    _28606 = NOVALUE;

    /** 				dangerous = TRUE*/
    _dangerous_55989 = _9TRUE_431;
L1A: 

    /** 			if factors = 1 and*/
    _28607 = (_30factors_53723 == 1);
    if (_28607 == 0) {
        _28608 = 0;
        goto L1B; // [838] 852
    }
    _28609 = (_30lhs_subs_level_53724 >= 0);
    _28608 = (_28609 != 0);
L1B: 
    if (_28608 == 0) {
        goto L1C; // [852] 878
    }
    _28611 = _subs_55984 + _slice_55985;
    if ((long)((unsigned long)_28611 + (unsigned long)HIGH_BITS) >= 0) 
    _28611 = NewDouble((double)_28611);
    if (IS_ATOM_INT(_28611)) {
        _28612 = (_30lhs_subs_level_53724 < _28611);
    }
    else {
        _28612 = ((double)_30lhs_subs_level_53724 < DBL_PTR(_28611)->dbl);
    }
    DeRef(_28611);
    _28611 = NOVALUE;
    if (_28612 == 0)
    {
        DeRef(_28612);
        _28612 = NOVALUE;
        goto L1C; // [867] 878
    }
    else{
        DeRef(_28612);
        _28612 = NOVALUE;
    }

    /** 				dangerous = TRUE*/
    _dangerous_55989 = _9TRUE_431;
L1C: 

    /** 			if dangerous then*/
    if (_dangerous_55989 == 0)
    {
        goto L1D; // [880] 894
    }
    else{
    }

    /** 				backpatch(subs1_patch, LHS_SUBS1_COPY)*/
    _37backpatch(_subs1_patch_55987, 166);
L1D: 
L18: 

    /** 		if slice then*/
    if (_slice_55985 == 0)
    {
        goto L1E; // [897] 965
    }
    else{
    }

    /** 			if assign_op != EQUALS then*/
    if (_assign_op_55986 == 3)
    goto L1F; // [904] 938

    /** 				if subs = 1 then*/
    if (_subs_55984 != 1)
    goto L20; // [910] 924

    /** 					emit_op(ASSIGN_OP_SLICE)*/
    _37emit_op(150);
    goto L21; // [921] 932
L20: 

    /** 					emit_op(PASSIGN_OP_SLICE)*/
    _37emit_op(165);
L21: 

    /** 				emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_55986);
L1F: 

    /** 			if subs = 1 then*/
    if (_subs_55984 != 1)
    goto L22; // [940] 954

    /** 				emit_op(ASSIGN_SLICE)*/
    _37emit_op(45);
    goto L23; // [951] 1055
L22: 

    /** 				emit_op(PASSIGN_SLICE)*/
    _37emit_op(163);
    goto L23; // [962] 1055
L1E: 

    /** 			if assign_op = EQUALS then*/
    if (_assign_op_55986 != 3)
    goto L24; // [969] 1000

    /** 				if subs = 1 then*/
    if (_subs_55984 != 1)
    goto L25; // [975] 989

    /** 					emit_op(ASSIGN_SUBS)*/
    _37emit_op(16);
    goto L26; // [986] 1054
L25: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _37emit_op(162);
    goto L26; // [997] 1054
L24: 

    /** 				if subs = 1 then*/
    if (_subs_55984 != 1)
    goto L27; // [1002] 1016

    /** 					emit_op(ASSIGN_OP_SUBS)*/
    _37emit_op(149);
    goto L28; // [1013] 1024
L27: 

    /** 					emit_op(PASSIGN_OP_SUBS)*/
    _37emit_op(164);
L28: 

    /** 				emit_assign_op(assign_op)*/
    _37emit_assign_op(_assign_op_55986);

    /** 				if subs = 1 then*/
    if (_subs_55984 != 1)
    goto L29; // [1031] 1045

    /** 					emit_op(ASSIGN_SUBS2)*/
    _37emit_op(148);
    goto L2A; // [1042] 1053
L29: 

    /** 					emit_op(PASSIGN_SUBS)*/
    _37emit_op(162);
L2A: 
L26: 
L23: 

    /** 		if subs > 1 then*/
    if (_subs_55984 <= 1)
    goto L2B; // [1057] 1109

    /** 			if dangerous then*/
    if (_dangerous_55989 == 0)
    {
        goto L2C; // [1063] 1100
    }
    else{
    }

    /** 				emit_opnd(left_sym)*/
    _37emit_opnd(_30left_sym_53726);

    /** 				emit_opnd(lhs_subs1_copy_temp) -- will be freed*/
    _37emit_opnd(_37lhs_subs1_copy_temp_49804);

    /** 				emit_temp( lhs_subs1_copy_temp, NEW_REFERENCE )*/
    _37emit_temp(_37lhs_subs1_copy_temp_49804, 1);

    /** 				emit_op(ASSIGN)*/
    _37emit_op(18);
    goto L2D; // [1097] 1108
L2C: 

    /** 				TempFree(lhs_subs1_copy_temp)*/
    _37TempFree(_37lhs_subs1_copy_temp_49804);
L2D: 
L2B: 

    /** 		if OpTypeCheck and (left_sym < 0 or SymTab[left_sym][S_VTYPE] != sequence_type) then*/
    if (_12OpTypeCheck_11753 == 0) {
        goto L2E; // [1113] 1163
    }
    _28622 = (_30left_sym_53726 < 0);
    if (_28622 != 0) {
        DeRef(_28623);
        _28623 = 1;
        goto L2F; // [1123] 1151
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28624 = (int)*(((s1_ptr)_2)->base + _30left_sym_53726);
    _2 = (int)SEQ_PTR(_28624);
    _28625 = (int)*(((s1_ptr)_2)->base + 15);
    _28624 = NOVALUE;
    if (IS_ATOM_INT(_28625)) {
        _28626 = (_28625 != _52sequence_type_45735);
    }
    else {
        _28626 = binary_op(NOTEQ, _28625, _52sequence_type_45735);
    }
    _28625 = NOVALUE;
    if (IS_ATOM_INT(_28626))
    _28623 = (_28626 != 0);
    else
    _28623 = DBL_PTR(_28626)->dbl != 0.0;
L2F: 
    if (_28623 == 0)
    {
        _28623 = NOVALUE;
        goto L2E; // [1152] 1163
    }
    else{
        _28623 = NOVALUE;
    }

    /** 			TypeCheck(left_sym)*/
    _30TypeCheck(_30left_sym_53726);
L2E: 
L17: 

    /** 	current_sequence = head( current_sequence, length( current_sequence ) - 1 )*/
    if (IS_SEQUENCE(_37current_sequence_49799)){
            _28627 = SEQ_PTR(_37current_sequence_49799)->length;
    }
    else {
        _28627 = 1;
    }
    _28628 = _28627 - 1;
    _28627 = NOVALUE;
    {
        int len = SEQ_PTR(_37current_sequence_49799)->length;
        int size = (IS_ATOM_INT(_28628)) ? _28628 : (object)(DBL_PTR(_28628)->dbl);
        if (size <= 0){
            DeRef( _37current_sequence_49799 );
            _37current_sequence_49799 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_37current_sequence_49799);
            DeRef(_37current_sequence_49799);
            _37current_sequence_49799 = _37current_sequence_49799;
        }
        else{
            Head(SEQ_PTR(_37current_sequence_49799),size+1,&_37current_sequence_49799);
        }
    }
    _28628 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L30; // [1187] 1213

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L31; // [1194] 1212
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _37emit_op(87);

    /** 			emit_addr(left_sym)*/
    _37emit_addr(_30left_sym_53726);
L31: 
L30: 

    /** end procedure*/
    DeRef(_left_var_55981);
    DeRef(_tok_55983);
    _28582 = NOVALUE;
    DeRef(_28537);
    _28537 = NOVALUE;
    DeRef(_28598);
    _28598 = NOVALUE;
    DeRef(_28607);
    _28607 = NOVALUE;
    DeRef(_28602);
    _28602 = NOVALUE;
    DeRef(_28609);
    _28609 = NOVALUE;
    DeRef(_28622);
    _28622 = NOVALUE;
    DeRef(_28626);
    _28626 = NOVALUE;
    return;
    ;
}


void _30Return_statement()
{
    int _tok_56272 = NOVALUE;
    int _pop_56273 = NOVALUE;
    int _last_op_56279 = NOVALUE;
    int _last_pc_56282 = NOVALUE;
    int _is_tail_56285 = NOVALUE;
    int _28662 = NOVALUE;
    int _28660 = NOVALUE;
    int _28659 = NOVALUE;
    int _28658 = NOVALUE;
    int _28657 = NOVALUE;
    int _28655 = NOVALUE;
    int _28654 = NOVALUE;
    int _28653 = NOVALUE;
    int _28652 = NOVALUE;
    int _28651 = NOVALUE;
    int _28650 = NOVALUE;
    int _28649 = NOVALUE;
    int _28648 = NOVALUE;
    int _28644 = NOVALUE;
    int _28643 = NOVALUE;
    int _28641 = NOVALUE;
    int _28640 = NOVALUE;
    int _28639 = NOVALUE;
    int _28638 = NOVALUE;
    int _28637 = NOVALUE;
    int _28636 = NOVALUE;
    int _28635 = NOVALUE;
    int _28634 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer pop*/

    /** 	if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_11690 != _12TopLevelSub_11689)
    goto L1; // [9] 21

    /** 		CompileErr(130)*/
    RefDS(_21829);
    _43CompileErr(130, _21829, 0);
L1: 

    /** 	integer*/

    /** 		last_op = Last_op(),*/
    _last_op_56279 = _37Last_op();
    if (!IS_ATOM_INT(_last_op_56279)) {
        _1 = (long)(DBL_PTR(_last_op_56279)->dbl);
        DeRefDS(_last_op_56279);
        _last_op_56279 = _1;
    }

    /** 		last_pc = Last_pc(),*/
    _last_pc_56282 = _37Last_pc();
    if (!IS_ATOM_INT(_last_pc_56282)) {
        _1 = (long)(DBL_PTR(_last_pc_56282)->dbl);
        DeRefDS(_last_pc_56282);
        _last_pc_56282 = _1;
    }

    /** 		is_tail = 0*/
    _is_tail_56285 = 0;

    /** 	if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28634 = (_last_op_56279 == 27);
    if (_28634 == 0) {
        _28635 = 0;
        goto L2; // [50] 67
    }
    if (IS_SEQUENCE(_12Code_11771)){
            _28636 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28636 = 1;
    }
    _28637 = (_28636 > _last_pc_56282);
    _28636 = NOVALUE;
    _28635 = (_28637 != 0);
L2: 
    if (_28635 == 0) {
        goto L3; // [67] 97
    }
    _28639 = _last_pc_56282 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _28640 = (int)*(((s1_ptr)_2)->base + _28639);
    if (IS_ATOM_INT(_28640)) {
        _28641 = (_28640 == _12CurrentSub_11690);
    }
    else {
        _28641 = binary_op(EQUALS, _28640, _12CurrentSub_11690);
    }
    _28640 = NOVALUE;
    if (_28641 == 0) {
        DeRef(_28641);
        _28641 = NOVALUE;
        goto L3; // [88] 97
    }
    else {
        if (!IS_ATOM_INT(_28641) && DBL_PTR(_28641)->dbl == 0.0){
            DeRef(_28641);
            _28641 = NOVALUE;
            goto L3; // [88] 97
        }
        DeRef(_28641);
        _28641 = NOVALUE;
    }
    DeRef(_28641);
    _28641 = NOVALUE;

    /** 		is_tail = 1*/
    _is_tail_56285 = 1;
L3: 

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L4; // [101] 127

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L5; // [108] 126
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 			emit_addr(CurrentSub)*/
    _37emit_addr(_12CurrentSub_11690);
L5: 
L4: 

    /** 	if SymTab[CurrentSub][S_TOKEN] != PROC then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _28643 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_28643);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _28644 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _28644 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _28643 = NOVALUE;
    if (binary_op_a(EQUALS, _28644, 27)){
        _28644 = NOVALUE;
        goto L6; // [145] 271
    }
    _28644 = NOVALUE;

    /** 		Expr()*/
    _30Expr();

    /** 		last_op = Last_op()*/
    _last_op_56279 = _37Last_op();
    if (!IS_ATOM_INT(_last_op_56279)) {
        _1 = (long)(DBL_PTR(_last_op_56279)->dbl);
        DeRefDS(_last_op_56279);
        _last_op_56279 = _1;
    }

    /** 		last_pc = Last_pc()*/
    _last_pc_56282 = _37Last_pc();
    if (!IS_ATOM_INT(_last_pc_56282)) {
        _1 = (long)(DBL_PTR(_last_pc_56282)->dbl);
        DeRefDS(_last_pc_56282);
        _last_pc_56282 = _1;
    }

    /** 		if last_op = PROC and length(Code) > last_pc and Code[last_pc+1] = CurrentSub then*/
    _28648 = (_last_op_56279 == 27);
    if (_28648 == 0) {
        _28649 = 0;
        goto L7; // [175] 192
    }
    if (IS_SEQUENCE(_12Code_11771)){
            _28650 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28650 = 1;
    }
    _28651 = (_28650 > _last_pc_56282);
    _28650 = NOVALUE;
    _28649 = (_28651 != 0);
L7: 
    if (_28649 == 0) {
        goto L8; // [192] 251
    }
    _28653 = _last_pc_56282 + 1;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _28654 = (int)*(((s1_ptr)_2)->base + _28653);
    if (IS_ATOM_INT(_28654)) {
        _28655 = (_28654 == _12CurrentSub_11690);
    }
    else {
        _28655 = binary_op(EQUALS, _28654, _12CurrentSub_11690);
    }
    _28654 = NOVALUE;
    if (_28655 == 0) {
        DeRef(_28655);
        _28655 = NOVALUE;
        goto L8; // [213] 251
    }
    else {
        if (!IS_ATOM_INT(_28655) && DBL_PTR(_28655)->dbl == 0.0){
            DeRef(_28655);
            _28655 = NOVALUE;
            goto L8; // [213] 251
        }
        DeRef(_28655);
        _28655 = NOVALUE;
    }
    DeRef(_28655);
    _28655 = NOVALUE;

    /** 			pop = Pop() -- prevent cg_stack (code generation stack) leakage*/
    _pop_56273 = _37Pop();
    if (!IS_ATOM_INT(_pop_56273)) {
        _1 = (long)(DBL_PTR(_pop_56273)->dbl);
        DeRefDS(_pop_56273);
        _pop_56273 = _1;
    }

    /** 			Code[Last_pc()] = PROC_TAIL*/
    _28657 = _37Last_pc();
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_28657))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28657)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _28657);
    _1 = *(int *)_2;
    *(int *)_2 = 203;
    DeRef(_1);

    /** 			if object(pop_temps()) then end if*/
    _28658 = _37pop_temps();
    if( NOVALUE == _28658 ){
        _28659 = 0;
    }
    else{
        if (IS_ATOM_INT(_28658))
        _28659 = 1;
        else if (IS_ATOM_DBL(_28658)) {
             if (IS_ATOM_INT(DoubleToInt(_28658))) {
                 _28659 = 1;
                 } else {
                     _28659 = 2;
                } } else if (IS_SEQUENCE(_28658))
                _28659 = 3;
                else
                _28659 = 0;
            }
            DeRef(_28658);
            _28658 = NOVALUE;
            if (_28659 == 0)
            {
                _28659 = NOVALUE;
                goto L9; // [244] 298
            }
            else{
                _28659 = NOVALUE;
            }
            goto L9; // [248] 298
L8: 

            /** 			FuncReturn = TRUE*/
            _30FuncReturn_53693 = _9TRUE_431;

            /** 			emit_op(RETURNF)*/
            _37emit_op(28);
            goto L9; // [268] 298
L6: 

            /** 		if is_tail then*/
            if (_is_tail_56285 == 0)
            {
                goto LA; // [273] 290
            }
            else{
            }

            /** 			Code[Last_pc()] = PROC_TAIL*/
            _28660 = _37Last_pc();
            _2 = (int)SEQ_PTR(_12Code_11771);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _12Code_11771 = MAKE_SEQ(_2);
            }
            if (!IS_ATOM_INT(_28660))
            _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_28660)->dbl));
            else
            _2 = (int)(((s1_ptr)_2)->base + _28660);
            _1 = *(int *)_2;
            *(int *)_2 = 203;
            DeRef(_1);
LA: 

            /** 		emit_op(RETURNP)*/
            _37emit_op(29);
L9: 

            /** 	tok = next_token()*/
            _0 = _tok_56272;
            _tok_56272 = _30next_token();
            DeRef(_0);

            /** 	putback(tok)*/
            Ref(_tok_56272);
            _30putback(_tok_56272);

            /** 	NotReached(tok[T_ID], "return")*/
            _2 = (int)SEQ_PTR(_tok_56272);
            _28662 = (int)*(((s1_ptr)_2)->base + 1);
            Ref(_28662);
            RefDS(_26123);
            _30NotReached(_28662, _26123);
            _28662 = NOVALUE;

            /** end procedure*/
            DeRef(_tok_56272);
            DeRef(_28634);
            _28634 = NOVALUE;
            DeRef(_28637);
            _28637 = NOVALUE;
            DeRef(_28639);
            _28639 = NOVALUE;
            DeRef(_28648);
            _28648 = NOVALUE;
            DeRef(_28651);
            _28651 = NOVALUE;
            DeRef(_28653);
            _28653 = NOVALUE;
            DeRef(_28657);
            _28657 = NOVALUE;
            DeRef(_28660);
            _28660 = NOVALUE;
            return;
    ;
}


int _30exit_level(int _tok_56361, int _flag_56362)
{
    int _arg_56363 = NOVALUE;
    int _n_56364 = NOVALUE;
    int _num_labels_56365 = NOVALUE;
    int _negative_56366 = NOVALUE;
    int _labels_56367 = NOVALUE;
    int _28691 = NOVALUE;
    int _28690 = NOVALUE;
    int _28689 = NOVALUE;
    int _28688 = NOVALUE;
    int _28687 = NOVALUE;
    int _28684 = NOVALUE;
    int _28683 = NOVALUE;
    int _28682 = NOVALUE;
    int _28680 = NOVALUE;
    int _28679 = NOVALUE;
    int _28678 = NOVALUE;
    int _28677 = NOVALUE;
    int _28675 = NOVALUE;
    int _28670 = NOVALUE;
    int _28669 = NOVALUE;
    int _28667 = NOVALUE;
    int _28664 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer negative = 0*/
    _negative_56366 = 0;

    /** 	if flag then*/
    if (_flag_56362 == 0)
    {
        goto L1; // [10] 25
    }
    else{
    }

    /** 		labels = if_labels*/
    RefDS(_30if_labels_53714);
    DeRef(_labels_56367);
    _labels_56367 = _30if_labels_53714;
    goto L2; // [22] 35
L1: 

    /** 		labels = loop_labels*/
    RefDS(_30loop_labels_53713);
    DeRef(_labels_56367);
    _labels_56367 = _30loop_labels_53713;
L2: 

    /** 	num_labels = length(labels)*/
    if (IS_SEQUENCE(_labels_56367)){
            _num_labels_56365 = SEQ_PTR(_labels_56367)->length;
    }
    else {
        _num_labels_56365 = 1;
    }

    /** 	if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_56361);
    _28664 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28664, 10)){
        _28664 = NOVALUE;
        goto L3; // [52] 67
    }
    _28664 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56361;
    _tok_56361 = _30next_token();
    DeRef(_0);

    /** 		negative = 1*/
    _negative_56366 = 1;
L3: 

    /** 	if tok[T_ID]=ATOM then*/
    _2 = (int)SEQ_PTR(_tok_56361);
    _28667 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28667, 502)){
        _28667 = NOVALUE;
        goto L4; // [77] 178
    }
    _28667 = NOVALUE;

    /** 		arg = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56361);
    _28669 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28669)){
        _28670 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28669)->dbl));
    }
    else{
        _28670 = (int)*(((s1_ptr)_2)->base + _28669);
    }
    DeRef(_arg_56363);
    _2 = (int)SEQ_PTR(_28670);
    _arg_56363 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_arg_56363);
    _28670 = NOVALUE;

    /** 		n = floor(arg)*/
    if (IS_ATOM_INT(_arg_56363))
    _n_56364 = e_floor(_arg_56363);
    else
    _n_56364 = unary_op(FLOOR, _arg_56363);
    if (!IS_ATOM_INT(_n_56364)) {
        _1 = (long)(DBL_PTR(_n_56364)->dbl);
        DeRefDS(_n_56364);
        _n_56364 = _1;
    }

    /** 		if negative then*/
    if (_negative_56366 == 0)
    {
        goto L5; // [110] 122
    }
    else{
    }

    /** 			n = num_labels - n*/
    _n_56364 = _num_labels_56365 - _n_56364;
    goto L6; // [119] 135
L5: 

    /** 		elsif n = 0 then*/
    if (_n_56364 != 0)
    goto L7; // [124] 134

    /** 			n = num_labels*/
    _n_56364 = _num_labels_56365;
L7: 
L6: 

    /** 		if n<=0 or n>num_labels then*/
    _28675 = (_n_56364 <= 0);
    if (_28675 != 0) {
        goto L8; // [141] 154
    }
    _28677 = (_n_56364 > _num_labels_56365);
    if (_28677 == 0)
    {
        DeRef(_28677);
        _28677 = NOVALUE;
        goto L9; // [150] 162
    }
    else{
        DeRef(_28677);
        _28677 = NOVALUE;
    }
L8: 

    /** 			CompileErr(87)*/
    RefDS(_21829);
    _43CompileErr(87, _21829, 0);
L9: 

    /** 		return {n, next_token()}*/
    _28678 = _30next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _n_56364;
    ((int *)_2)[2] = _28678;
    _28679 = MAKE_SEQ(_1);
    _28678 = NOVALUE;
    DeRef(_tok_56361);
    DeRef(_arg_56363);
    DeRef(_labels_56367);
    _28669 = NOVALUE;
    DeRef(_28675);
    _28675 = NOVALUE;
    return _28679;
    goto LA; // [175] 266
L4: 

    /** 	elsif tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56361);
    _28680 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28680, 503)){
        _28680 = NOVALUE;
        goto LB; // [188] 255
    }
    _28680 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],labels)*/
    _2 = (int)SEQ_PTR(_tok_56361);
    _28682 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28682)){
        _28683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28682)->dbl));
    }
    else{
        _28683 = (int)*(((s1_ptr)_2)->base + _28682);
    }
    _2 = (int)SEQ_PTR(_28683);
    _28684 = (int)*(((s1_ptr)_2)->base + 1);
    _28683 = NOVALUE;
    _n_56364 = find_from(_28684, _labels_56367, 1);
    _28684 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56364 != 0)
    goto LC; // [219] 231

    /** 			CompileErr(152)*/
    RefDS(_21829);
    _43CompileErr(152, _21829, 0);
LC: 

    /** 		return {num_labels + 1 - n, next_token()}*/
    _28687 = _num_labels_56365 + 1;
    if (_28687 > MAXINT){
        _28687 = NewDouble((double)_28687);
    }
    if (IS_ATOM_INT(_28687)) {
        _28688 = _28687 - _n_56364;
        if ((long)((unsigned long)_28688 +(unsigned long) HIGH_BITS) >= 0){
            _28688 = NewDouble((double)_28688);
        }
    }
    else {
        _28688 = NewDouble(DBL_PTR(_28687)->dbl - (double)_n_56364);
    }
    DeRef(_28687);
    _28687 = NOVALUE;
    _28689 = _30next_token();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _28688;
    ((int *)_2)[2] = _28689;
    _28690 = MAKE_SEQ(_1);
    _28689 = NOVALUE;
    _28688 = NOVALUE;
    DeRef(_tok_56361);
    DeRef(_arg_56363);
    DeRef(_labels_56367);
    _28669 = NOVALUE;
    DeRef(_28675);
    _28675 = NOVALUE;
    DeRef(_28679);
    _28679 = NOVALUE;
    _28682 = NOVALUE;
    return _28690;
    goto LA; // [252] 266
LB: 

    /** 		return {1, tok} -- no parameters*/
    Ref(_tok_56361);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = _tok_56361;
    _28691 = MAKE_SEQ(_1);
    DeRef(_tok_56361);
    DeRef(_arg_56363);
    DeRef(_labels_56367);
    _28669 = NOVALUE;
    DeRef(_28675);
    _28675 = NOVALUE;
    DeRef(_28679);
    _28679 = NOVALUE;
    _28682 = NOVALUE;
    DeRef(_28690);
    _28690 = NOVALUE;
    return _28691;
LA: 
    ;
}


void _30GLabel_statement()
{
    int _tok_56424 = NOVALUE;
    int _labbel_56425 = NOVALUE;
    int _laddr_56426 = NOVALUE;
    int _n_56427 = NOVALUE;
    int _28710 = NOVALUE;
    int _28708 = NOVALUE;
    int _28707 = NOVALUE;
    int _28706 = NOVALUE;
    int _28705 = NOVALUE;
    int _28703 = NOVALUE;
    int _28700 = NOVALUE;
    int _28698 = NOVALUE;
    int _28696 = NOVALUE;
    int _28695 = NOVALUE;
    int _28693 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object labbel*/

    /** 	object laddr*/

    /** 	integer n*/

    /** 	tok = next_token()*/
    _0 = _tok_56424;
    _tok_56424 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56424);
    _28693 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28693, 503)){
        _28693 = NOVALUE;
        goto L1; // [22] 34
    }
    _28693 = NOVALUE;

    /** 		CompileErr(35)*/
    RefDS(_21829);
    _43CompileErr(35, _21829, 0);
L1: 

    /** 	labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56424);
    _28695 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28695)){
        _28696 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28695)->dbl));
    }
    else{
        _28696 = (int)*(((s1_ptr)_2)->base + _28695);
    }
    DeRef(_labbel_56425);
    _2 = (int)SEQ_PTR(_28696);
    _labbel_56425 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56425);
    _28696 = NOVALUE;

    /** 	laddr = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28698 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28698 = 1;
    }
    _laddr_56426 = _28698 + 1;
    _28698 = NOVALUE;

    /** 	if find(labbel, goto_labels) then*/
    _28700 = find_from(_labbel_56425, _30goto_labels_53696, 1);
    if (_28700 == 0)
    {
        _28700 = NOVALUE;
        goto L2; // [74] 85
    }
    else{
        _28700 = NOVALUE;
    }

    /** 		CompileErr(59)*/
    RefDS(_21829);
    _43CompileErr(59, _21829, 0);
L2: 

    /** 	goto_labels = append(goto_labels, labbel)*/
    Ref(_labbel_56425);
    Append(&_30goto_labels_53696, _30goto_labels_53696, _labbel_56425);

    /** 	goto_addr = append(goto_addr, laddr)*/
    Append(&_30goto_addr_53697, _30goto_addr_53697, _laddr_56426);

    /** 	label_block = append( label_block, top_block() )*/
    _28703 = _65top_block(0);
    Ref(_28703);
    Append(&_30label_block_53700, _30label_block_53700, _28703);
    DeRef(_28703);
    _28703 = NOVALUE;

    /** 	while n with entry do*/
    goto L3; // [115] 174
L4: 
    if (_n_56427 == 0)
    {
        goto L5; // [120] 188
    }
    else{
    }

    /** 		backpatch(goto_list[n], laddr)*/
    _2 = (int)SEQ_PTR(_12goto_list_11794);
    _28705 = (int)*(((s1_ptr)_2)->base + _n_56427);
    Ref(_28705);
    _37backpatch(_28705, _laddr_56426);
    _28705 = NOVALUE;

    /** 		set_glabel_block( goto_ref[n], top_block() )*/
    _2 = (int)SEQ_PTR(_30goto_ref_53699);
    _28706 = (int)*(((s1_ptr)_2)->base + _n_56427);
    _28707 = _65top_block(0);
    Ref(_28706);
    _29set_glabel_block(_28706, _28707);
    _28706 = NOVALUE;
    _28707 = NOVALUE;

    /** 		goto_delay[n] = "" --clear it*/
    RefDS(_21829);
    _2 = (int)SEQ_PTR(_12goto_delay_11793);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12goto_delay_11793 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56427);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);

    /** 		goto_line[n] = {-1,""} --clear it*/
    RefDS(_21829);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _21829;
    _28708 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(_30goto_line_53695);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30goto_line_53695 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _n_56427);
    _1 = *(int *)_2;
    *(int *)_2 = _28708;
    if( _1 != _28708 ){
        DeRef(_1);
    }
    _28708 = NOVALUE;

    /** 	entry*/
L3: 

    /** 		n = find(labbel, goto_delay)*/
    _n_56427 = find_from(_labbel_56425, _12goto_delay_11793, 1);

    /** 	end while*/
    goto L4; // [185] 118
L5: 

    /** 	force_uninitialize( map:get( goto_init, labbel, {} ) )*/
    Ref(_30goto_init_53702);
    Ref(_labbel_56425);
    RefDS(_21829);
    _28710 = _32get(_30goto_init_53702, _labbel_56425, _21829);
    _30force_uninitialize(_28710);
    _28710 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [205] 221
    }
    else{
    }

    /** 		emit_op(GLABEL)*/
    _37emit_op(189);

    /** 		emit_addr(laddr)*/
    _37emit_addr(_laddr_56426);
L6: 

    /** end procedure*/
    DeRef(_tok_56424);
    DeRef(_labbel_56425);
    _28695 = NOVALUE;
    return;
    ;
}


void _30Goto_statement()
{
    int _tok_56474 = NOVALUE;
    int _n_56475 = NOVALUE;
    int _num_labels_56476 = NOVALUE;
    int _31369 = NOVALUE;
    int _28749 = NOVALUE;
    int _28748 = NOVALUE;
    int _28745 = NOVALUE;
    int _28744 = NOVALUE;
    int _28743 = NOVALUE;
    int _28742 = NOVALUE;
    int _28741 = NOVALUE;
    int _28740 = NOVALUE;
    int _28739 = NOVALUE;
    int _28738 = NOVALUE;
    int _28737 = NOVALUE;
    int _28736 = NOVALUE;
    int _28735 = NOVALUE;
    int _28734 = NOVALUE;
    int _28732 = NOVALUE;
    int _28731 = NOVALUE;
    int _28729 = NOVALUE;
    int _28728 = NOVALUE;
    int _28726 = NOVALUE;
    int _28725 = NOVALUE;
    int _28723 = NOVALUE;
    int _28722 = NOVALUE;
    int _28721 = NOVALUE;
    int _28720 = NOVALUE;
    int _28717 = NOVALUE;
    int _28716 = NOVALUE;
    int _28715 = NOVALUE;
    int _28713 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer n*/

    /** 	integer num_labels*/

    /** 	tok = next_token()*/
    _0 = _tok_56474;
    _tok_56474 = _30next_token();
    DeRef(_0);

    /** 	num_labels = length(goto_labels)*/
    if (IS_SEQUENCE(_30goto_labels_53696)){
            _num_labels_56476 = SEQ_PTR(_30goto_labels_53696)->length;
    }
    else {
        _num_labels_56476 = 1;
    }

    /** 	if tok[T_ID]=STRING then*/
    _2 = (int)SEQ_PTR(_tok_56474);
    _28713 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28713, 503)){
        _28713 = NOVALUE;
        goto L1; // [27] 269
    }
    _28713 = NOVALUE;

    /** 		n = find(SymTab[tok[T_SYM]][S_OBJ],goto_labels)*/
    _2 = (int)SEQ_PTR(_tok_56474);
    _28715 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28715)){
        _28716 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28715)->dbl));
    }
    else{
        _28716 = (int)*(((s1_ptr)_2)->base + _28715);
    }
    _2 = (int)SEQ_PTR(_28716);
    _28717 = (int)*(((s1_ptr)_2)->base + 1);
    _28716 = NOVALUE;
    _n_56475 = find_from(_28717, _30goto_labels_53696, 1);
    _28717 = NOVALUE;

    /** 		if n = 0 then*/
    if (_n_56475 != 0)
    goto L2; // [60] 243

    /** 			goto_delay &= {SymTab[tok[T_SYM]][S_OBJ]}*/
    _2 = (int)SEQ_PTR(_tok_56474);
    _28720 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28720)){
        _28721 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28720)->dbl));
    }
    else{
        _28721 = (int)*(((s1_ptr)_2)->base + _28720);
    }
    _2 = (int)SEQ_PTR(_28721);
    _28722 = (int)*(((s1_ptr)_2)->base + 1);
    _28721 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_28722);
    *((int *)(_2+4)) = _28722;
    _28723 = MAKE_SEQ(_1);
    _28722 = NOVALUE;
    Concat((object_ptr)&_12goto_delay_11793, _12goto_delay_11793, _28723);
    DeRefDS(_28723);
    _28723 = NOVALUE;

    /** 			goto_list &= length(Code)+2 --not 1???*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28725 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28725 = 1;
    }
    _28726 = _28725 + 2;
    _28725 = NOVALUE;
    Append(&_12goto_list_11794, _12goto_list_11794, _28726);
    _28726 = NOVALUE;

    /** 			goto_line &= {{line_number,ThisLine}}*/
    Ref(_43ThisLine_48158);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _12line_number_11683;
    ((int *)_2)[2] = _43ThisLine_48158;
    _28728 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _28728;
    _28729 = MAKE_SEQ(_1);
    _28728 = NOVALUE;
    Concat((object_ptr)&_30goto_line_53695, _30goto_line_53695, _28729);
    DeRefDS(_28729);
    _28729 = NOVALUE;

    /** 			goto_ref &= new_forward_reference( GOTO, top_block() )*/
    _28731 = _65top_block(0);
    _31369 = 188;
    _28732 = _29new_forward_reference(188, _28731, 188);
    _28731 = NOVALUE;
    _31369 = NOVALUE;
    if (IS_SEQUENCE(_30goto_ref_53699) && IS_ATOM(_28732)) {
        Ref(_28732);
        Append(&_30goto_ref_53699, _30goto_ref_53699, _28732);
    }
    else if (IS_ATOM(_30goto_ref_53699) && IS_SEQUENCE(_28732)) {
    }
    else {
        Concat((object_ptr)&_30goto_ref_53699, _30goto_ref_53699, _28732);
    }
    DeRef(_28732);
    _28732 = NOVALUE;

    /** 			map:put( goto_init, SymTab[tok[T_SYM]][S_OBJ], get_private_uninitialized() )*/
    _2 = (int)SEQ_PTR(_tok_56474);
    _28734 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28734)){
        _28735 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28734)->dbl));
    }
    else{
        _28735 = (int)*(((s1_ptr)_2)->base + _28734);
    }
    _2 = (int)SEQ_PTR(_28735);
    _28736 = (int)*(((s1_ptr)_2)->base + 1);
    _28735 = NOVALUE;
    _28737 = _30get_private_uninitialized();
    Ref(_30goto_init_53702);
    Ref(_28736);
    _32put(_30goto_init_53702, _28736, _28737, 1, 23);
    _28736 = NOVALUE;
    _28737 = NOVALUE;

    /** 			add_data( goto_ref[$], sym_obj( tok[T_SYM] ) )*/
    if (IS_SEQUENCE(_30goto_ref_53699)){
            _28738 = SEQ_PTR(_30goto_ref_53699)->length;
    }
    else {
        _28738 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_ref_53699);
    _28739 = (int)*(((s1_ptr)_2)->base + _28738);
    _2 = (int)SEQ_PTR(_tok_56474);
    _28740 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_28740);
    _28741 = _52sym_obj(_28740);
    _28740 = NOVALUE;
    Ref(_28739);
    _29add_data(_28739, _28741);
    _28739 = NOVALUE;
    _28741 = NOVALUE;

    /** 			set_line( goto_ref[$], line_number, ThisLine, bp )*/
    if (IS_SEQUENCE(_30goto_ref_53699)){
            _28742 = SEQ_PTR(_30goto_ref_53699)->length;
    }
    else {
        _28742 = 1;
    }
    _2 = (int)SEQ_PTR(_30goto_ref_53699);
    _28743 = (int)*(((s1_ptr)_2)->base + _28742);
    Ref(_28743);
    Ref(_43ThisLine_48158);
    _29set_line(_28743, _12line_number_11683, _43ThisLine_48158, _43bp_48162);
    _28743 = NOVALUE;
    goto L3; // [240] 261
L2: 

    /** 			Goto_block( top_block(), label_block[n] )*/
    _28744 = _65top_block(0);
    _2 = (int)SEQ_PTR(_30label_block_53700);
    _28745 = (int)*(((s1_ptr)_2)->base + _n_56475);
    Ref(_28745);
    _65Goto_block(_28744, _28745, 0);
    _28744 = NOVALUE;
    _28745 = NOVALUE;
L3: 

    /** 		tok = next_token()*/
    _0 = _tok_56474;
    _tok_56474 = _30next_token();
    DeRef(_0);
    goto L4; // [266] 277
L1: 

    /** 		CompileErr(96)*/
    RefDS(_21829);
    _43CompileErr(96, _21829, 0);
L4: 

    /** 	emit_op(GOTO)*/
    _37emit_op(188);

    /** 	if n = 0 then*/
    if (_n_56475 != 0)
    goto L5; // [288] 300

    /** 		emit_addr(0) -- to be back-patched*/
    _37emit_addr(0);
    goto L6; // [297] 312
L5: 

    /** 		emit_addr(goto_addr[n])*/
    _2 = (int)SEQ_PTR(_30goto_addr_53697);
    _28748 = (int)*(((s1_ptr)_2)->base + _n_56475);
    Ref(_28748);
    _37emit_addr(_28748);
    _28748 = NOVALUE;
L6: 

    /** 	putback(tok)*/
    Ref(_tok_56474);
    _30putback(_tok_56474);

    /** 	NotReached(tok[T_ID], "goto")*/
    _2 = (int)SEQ_PTR(_tok_56474);
    _28749 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28749);
    RefDS(_26065);
    _30NotReached(_28749, _26065);
    _28749 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56474);
    _28715 = NOVALUE;
    _28720 = NOVALUE;
    _28734 = NOVALUE;
    return;
    ;
}


void _30Exit_statement()
{
    int _addr_inlined_AppendXList_at_63_56577 = NOVALUE;
    int _tok_56560 = NOVALUE;
    int _by_ref_56561 = NOVALUE;
    int _28757 = NOVALUE;
    int _28756 = NOVALUE;
    int _28755 = NOVALUE;
    int _28754 = NOVALUE;
    int _28752 = NOVALUE;
    int _28750 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _28750 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _28750 = 1;
    }
    if (_28750 != 0)
    goto L1; // [10] 21
    _28750 = NOVALUE;

    /** 		CompileErr(88)*/
    RefDS(_21829);
    _43CompileErr(88, _21829, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28752 = _30next_token();
    _0 = _by_ref_56561;
    _by_ref_56561 = _30exit_level(_28752, 0);
    DeRef(_0);
    _28752 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56561);
    _28754 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28754);
    _65Leave_blocks(_28754, 1);
    _28754 = NOVALUE;

    /** 	emit_op(EXIT)*/
    _37emit_op(61);

    /** 	AppendXList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28755 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28755 = 1;
    }
    _28756 = _28755 + 1;
    _28755 = NOVALUE;
    _addr_inlined_AppendXList_at_63_56577 = _28756;
    _28756 = NOVALUE;

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_30exit_list_53705, _30exit_list_53705, _addr_inlined_AppendXList_at_63_56577);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	exit_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56561);
    _28757 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30exit_delay_53706) && IS_ATOM(_28757)) {
        Ref(_28757);
        Append(&_30exit_delay_53706, _30exit_delay_53706, _28757);
    }
    else if (IS_ATOM(_30exit_delay_53706) && IS_SEQUENCE(_28757)) {
    }
    else {
        Concat((object_ptr)&_30exit_delay_53706, _30exit_delay_53706, _28757);
    }
    _28757 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56560);
    _2 = (int)SEQ_PTR(_by_ref_56561);
    _tok_56560 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56560);

    /** 	putback(tok)*/
    Ref(_tok_56560);
    _30putback(_tok_56560);

    /** end procedure*/
    DeRef(_tok_56560);
    DeRefDS(_by_ref_56561);
    return;
    ;
}


void _30Continue_statement()
{
    int _addr_inlined_AppendNList_at_149_56621 = NOVALUE;
    int _tok_56584 = NOVALUE;
    int _by_ref_56585 = NOVALUE;
    int _loop_level_56586 = NOVALUE;
    int _28783 = NOVALUE;
    int _28780 = NOVALUE;
    int _28779 = NOVALUE;
    int _28778 = NOVALUE;
    int _28777 = NOVALUE;
    int _28776 = NOVALUE;
    int _28775 = NOVALUE;
    int _28773 = NOVALUE;
    int _28772 = NOVALUE;
    int _28771 = NOVALUE;
    int _28770 = NOVALUE;
    int _28769 = NOVALUE;
    int _28768 = NOVALUE;
    int _28767 = NOVALUE;
    int _28766 = NOVALUE;
    int _28764 = NOVALUE;
    int _28762 = NOVALUE;
    int _28760 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	integer loop_level*/

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _28760 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _28760 = 1;
    }
    if (_28760 != 0)
    goto L1; // [12] 23
    _28760 = NOVALUE;

    /** 		CompileErr(49)*/
    RefDS(_21829);
    _43CompileErr(49, _21829, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28762 = _30next_token();
    _0 = _by_ref_56585;
    _by_ref_56585 = _30exit_level(_28762, 0);
    DeRef(_0);
    _28762 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56585);
    _28764 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28764);
    _65Leave_blocks(_28764, 1);
    _28764 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _37emit_op(23);

    /** 	loop_level = by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56585);
    _loop_level_56586 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_loop_level_56586))
    _loop_level_56586 = (long)DBL_PTR(_loop_level_56586)->dbl;

    /** 	if continue_addr[$+1-loop_level] then -- address is known for while loops*/
    if (IS_SEQUENCE(_30continue_addr_53710)){
            _28766 = SEQ_PTR(_30continue_addr_53710)->length;
    }
    else {
        _28766 = 1;
    }
    _28767 = _28766 + 1;
    _28766 = NOVALUE;
    _28768 = _28767 - _loop_level_56586;
    _28767 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_53710);
    _28769 = (int)*(((s1_ptr)_2)->base + _28768);
    if (_28769 == 0)
    {
        _28769 = NOVALUE;
        goto L2; // [79] 138
    }
    else{
        _28769 = NOVALUE;
    }

    /** 		if continue_addr[$+1-loop_level] < 0 then*/
    if (IS_SEQUENCE(_30continue_addr_53710)){
            _28770 = SEQ_PTR(_30continue_addr_53710)->length;
    }
    else {
        _28770 = 1;
    }
    _28771 = _28770 + 1;
    _28770 = NOVALUE;
    _28772 = _28771 - _loop_level_56586;
    _28771 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_53710);
    _28773 = (int)*(((s1_ptr)_2)->base + _28772);
    if (_28773 >= 0)
    goto L3; // [101] 113

    /** 			CompileErr(49)*/
    RefDS(_21829);
    _43CompileErr(49, _21829, 0);
L3: 

    /** 		emit_addr(continue_addr[$+1-loop_level])*/
    if (IS_SEQUENCE(_30continue_addr_53710)){
            _28775 = SEQ_PTR(_30continue_addr_53710)->length;
    }
    else {
        _28775 = 1;
    }
    _28776 = _28775 + 1;
    _28775 = NOVALUE;
    _28777 = _28776 - _loop_level_56586;
    _28776 = NOVALUE;
    _2 = (int)SEQ_PTR(_30continue_addr_53710);
    _28778 = (int)*(((s1_ptr)_2)->base + _28777);
    _37emit_addr(_28778);
    _28778 = NOVALUE;
    goto L4; // [135] 182
L2: 

    /** 		AppendNList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28779 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28779 = 1;
    }
    _28780 = _28779 + 1;
    _28779 = NOVALUE;
    _addr_inlined_AppendNList_at_149_56621 = _28780;
    _28780 = NOVALUE;

    /** 	continue_list = append(continue_list, addr)*/
    Append(&_30continue_list_53707, _30continue_list_53707, _addr_inlined_AppendNList_at_149_56621);

    /** end procedure*/
    goto L5; // [164] 167
L5: 

    /** 		continue_delay &= loop_level*/
    Append(&_30continue_delay_53708, _30continue_delay_53708, _loop_level_56586);

    /** 		emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();
L4: 

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56584);
    _2 = (int)SEQ_PTR(_by_ref_56585);
    _tok_56584 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56584);

    /** 	putback(tok)*/
    Ref(_tok_56584);
    _30putback(_tok_56584);

    /** 	NotReached(tok[T_ID], "continue")*/
    _2 = (int)SEQ_PTR(_tok_56584);
    _28783 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28783);
    RefDS(_26027);
    _30NotReached(_28783, _26027);
    _28783 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56584);
    DeRefDS(_by_ref_56585);
    _28773 = NOVALUE;
    DeRef(_28768);
    _28768 = NOVALUE;
    DeRef(_28772);
    _28772 = NOVALUE;
    DeRef(_28777);
    _28777 = NOVALUE;
    return;
    ;
}


void _30Retry_statement()
{
    int _by_ref_56628 = NOVALUE;
    int _tok_56630 = NOVALUE;
    int _28807 = NOVALUE;
    int _28805 = NOVALUE;
    int _28804 = NOVALUE;
    int _28803 = NOVALUE;
    int _28802 = NOVALUE;
    int _28801 = NOVALUE;
    int _28799 = NOVALUE;
    int _28798 = NOVALUE;
    int _28797 = NOVALUE;
    int _28796 = NOVALUE;
    int _28795 = NOVALUE;
    int _28793 = NOVALUE;
    int _28792 = NOVALUE;
    int _28791 = NOVALUE;
    int _28790 = NOVALUE;
    int _28789 = NOVALUE;
    int _28788 = NOVALUE;
    int _28786 = NOVALUE;
    int _28784 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) then*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _28784 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _28784 = 1;
    }
    if (_28784 != 0)
    goto L1; // [8] 19
    _28784 = NOVALUE;

    /** 		CompileErr(131)*/
    RefDS(_21829);
    _43CompileErr(131, _21829, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),0) -- can't pass tok by reference*/
    _28786 = _30next_token();
    _0 = _by_ref_56628;
    _by_ref_56628 = _30exit_level(_28786, 0);
    DeRef(_0);
    _28786 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], LOOP_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56628);
    _28788 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28788);
    _65Leave_blocks(_28788, 1);
    _28788 = NOVALUE;

    /** 	if loop_stack[$+1-by_ref[1]]=FOR then*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _28789 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _28789 = 1;
    }
    _28790 = _28789 + 1;
    _28789 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56628);
    _28791 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28791)) {
        _28792 = _28790 - _28791;
    }
    else {
        _28792 = binary_op(MINUS, _28790, _28791);
    }
    _28790 = NOVALUE;
    _28791 = NOVALUE;
    _2 = (int)SEQ_PTR(_30loop_stack_53719);
    if (!IS_ATOM_INT(_28792)){
        _28793 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28792)->dbl));
    }
    else{
        _28793 = (int)*(((s1_ptr)_2)->base + _28792);
    }
    if (_28793 != 21)
    goto L2; // [68] 82

    /** 		emit_op(RETRY) -- for Translator to emit a label at the right place*/
    _37emit_op(184);
    goto L3; // [79] 125
L2: 

    /** 		if retry_addr[$+1-by_ref[1]] < 0 then*/
    if (IS_SEQUENCE(_30retry_addr_53711)){
            _28795 = SEQ_PTR(_30retry_addr_53711)->length;
    }
    else {
        _28795 = 1;
    }
    _28796 = _28795 + 1;
    _28795 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56628);
    _28797 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28797)) {
        _28798 = _28796 - _28797;
    }
    else {
        _28798 = binary_op(MINUS, _28796, _28797);
    }
    _28796 = NOVALUE;
    _28797 = NOVALUE;
    _2 = (int)SEQ_PTR(_30retry_addr_53711);
    if (!IS_ATOM_INT(_28798)){
        _28799 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28798)->dbl));
    }
    else{
        _28799 = (int)*(((s1_ptr)_2)->base + _28798);
    }
    if (_28799 >= 0)
    goto L4; // [105] 117

    /** 			CompileErr(131)*/
    RefDS(_21829);
    _43CompileErr(131, _21829, 0);
L4: 

    /** 		emit_op(ELSE)*/
    _37emit_op(23);
L3: 

    /** 	emit_addr(retry_addr[$+1-by_ref[1]])*/
    if (IS_SEQUENCE(_30retry_addr_53711)){
            _28801 = SEQ_PTR(_30retry_addr_53711)->length;
    }
    else {
        _28801 = 1;
    }
    _28802 = _28801 + 1;
    _28801 = NOVALUE;
    _2 = (int)SEQ_PTR(_by_ref_56628);
    _28803 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28803)) {
        _28804 = _28802 - _28803;
    }
    else {
        _28804 = binary_op(MINUS, _28802, _28803);
    }
    _28802 = NOVALUE;
    _28803 = NOVALUE;
    _2 = (int)SEQ_PTR(_30retry_addr_53711);
    if (!IS_ATOM_INT(_28804)){
        _28805 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28804)->dbl));
    }
    else{
        _28805 = (int)*(((s1_ptr)_2)->base + _28804);
    }
    _37emit_addr(_28805);
    _28805 = NOVALUE;

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56630);
    _2 = (int)SEQ_PTR(_by_ref_56628);
    _tok_56630 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56630);

    /** 	putback(tok)*/
    Ref(_tok_56630);
    _30putback(_tok_56630);

    /** 	NotReached(tok[T_ID], "retry")*/
    _2 = (int)SEQ_PTR(_tok_56630);
    _28807 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28807);
    RefDS(_26121);
    _30NotReached(_28807, _26121);
    _28807 = NOVALUE;

    /** end procedure*/
    DeRefDS(_by_ref_56628);
    DeRef(_tok_56630);
    _28793 = NOVALUE;
    _28799 = NOVALUE;
    DeRef(_28792);
    _28792 = NOVALUE;
    DeRef(_28798);
    _28798 = NOVALUE;
    DeRef(_28804);
    _28804 = NOVALUE;
    return;
    ;
}


int _30in_switch()
{
    int _28812 = NOVALUE;
    int _28811 = NOVALUE;
    int _28810 = NOVALUE;
    int _28809 = NOVALUE;
    int _28808 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length( if_stack ) and if_stack[$] = SWITCH then*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _28808 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _28808 = 1;
    }
    if (_28808 == 0) {
        goto L1; // [8] 40
    }
    if (IS_SEQUENCE(_30if_stack_53720)){
            _28810 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _28810 = 1;
    }
    _2 = (int)SEQ_PTR(_30if_stack_53720);
    _28811 = (int)*(((s1_ptr)_2)->base + _28810);
    _28812 = (_28811 == 185);
    _28811 = NOVALUE;
    if (_28812 == 0)
    {
        DeRef(_28812);
        _28812 = NOVALUE;
        goto L1; // [28] 40
    }
    else{
        DeRef(_28812);
        _28812 = NOVALUE;
    }

    /** 		return 1*/
    return 1;
    goto L2; // [37] 47
L1: 

    /** 		return 0*/
    return 0;
L2: 
    ;
}


void _30Break_statement()
{
    int _addr_inlined_AppendEList_at_63_56700 = NOVALUE;
    int _tok_56683 = NOVALUE;
    int _by_ref_56684 = NOVALUE;
    int _28823 = NOVALUE;
    int _28820 = NOVALUE;
    int _28819 = NOVALUE;
    int _28818 = NOVALUE;
    int _28817 = NOVALUE;
    int _28815 = NOVALUE;
    int _28813 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence by_ref*/

    /** 	if not length(if_labels) then*/
    if (IS_SEQUENCE(_30if_labels_53714)){
            _28813 = SEQ_PTR(_30if_labels_53714)->length;
    }
    else {
        _28813 = 1;
    }
    if (_28813 != 0)
    goto L1; // [10] 21
    _28813 = NOVALUE;

    /** 		CompileErr(40)*/
    RefDS(_21829);
    _43CompileErr(40, _21829, 0);
L1: 

    /** 	by_ref = exit_level(next_token(),1)*/
    _28815 = _30next_token();
    _0 = _by_ref_56684;
    _by_ref_56684 = _30exit_level(_28815, 1);
    DeRef(_0);
    _28815 = NOVALUE;

    /** 	Leave_blocks( by_ref[1], CONDITIONAL_BLOCK )*/
    _2 = (int)SEQ_PTR(_by_ref_56684);
    _28817 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28817);
    _65Leave_blocks(_28817, 2);
    _28817 = NOVALUE;

    /** 	emit_op(ELSE)*/
    _37emit_op(23);

    /** 	AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28818 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28818 = 1;
    }
    _28819 = _28818 + 1;
    _28818 = NOVALUE;
    _addr_inlined_AppendEList_at_63_56700 = _28819;
    _28819 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_53703, _30break_list_53703, _addr_inlined_AppendEList_at_63_56700);

    /** end procedure*/
    goto L2; // [78] 81
L2: 

    /** 	break_delay &= by_ref[1]*/
    _2 = (int)SEQ_PTR(_by_ref_56684);
    _28820 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30break_delay_53704) && IS_ATOM(_28820)) {
        Ref(_28820);
        Append(&_30break_delay_53704, _30break_delay_53704, _28820);
    }
    else if (IS_ATOM(_30break_delay_53704) && IS_SEQUENCE(_28820)) {
    }
    else {
        Concat((object_ptr)&_30break_delay_53704, _30break_delay_53704, _28820);
    }
    _28820 = NOVALUE;

    /** 	emit_forward_addr()    -- to be back-patched*/
    _30emit_forward_addr();

    /** 	tok = by_ref[2]*/
    DeRef(_tok_56683);
    _2 = (int)SEQ_PTR(_by_ref_56684);
    _tok_56683 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tok_56683);

    /** 	putback(tok)*/
    Ref(_tok_56683);
    _30putback(_tok_56683);

    /** 	NotReached(tok[T_ID], "break")*/
    _2 = (int)SEQ_PTR(_tok_56683);
    _28823 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_28823);
    RefDS(_26011);
    _30NotReached(_28823, _26011);
    _28823 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_56683);
    DeRefDS(_by_ref_56684);
    return;
    ;
}


int _30finish_block_header(int _opcode_56709)
{
    int _tok_56711 = NOVALUE;
    int _labbel_56712 = NOVALUE;
    int _has_entry_56713 = NOVALUE;
    int _28877 = NOVALUE;
    int _28876 = NOVALUE;
    int _28875 = NOVALUE;
    int _28874 = NOVALUE;
    int _28871 = NOVALUE;
    int _28866 = NOVALUE;
    int _28863 = NOVALUE;
    int _28861 = NOVALUE;
    int _28858 = NOVALUE;
    int _28857 = NOVALUE;
    int _28855 = NOVALUE;
    int _28852 = NOVALUE;
    int _28849 = NOVALUE;
    int _28848 = NOVALUE;
    int _28846 = NOVALUE;
    int _28844 = NOVALUE;
    int _28841 = NOVALUE;
    int _28838 = NOVALUE;
    int _28837 = NOVALUE;
    int _28835 = NOVALUE;
    int _28833 = NOVALUE;
    int _28832 = NOVALUE;
    int _28831 = NOVALUE;
    int _28828 = NOVALUE;
    int _28825 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	object labbel*/

    /** 	integer has_entry*/

    /** 	tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);

    /** 	has_entry=0*/
    _has_entry_56713 = 0;

    /** 	if tok[T_ID] = WITH then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28825 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28825, 420)){
        _28825 = NOVALUE;
        goto L1; // [27] 154
    }
    _28825 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);

    /** 		switch tok[T_ID] do*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28828 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_28828) ){
        goto L2; // [44] 136
    }
    if(!IS_ATOM_INT(_28828)){
        if( (DBL_PTR(_28828)->dbl != (double) ((int) DBL_PTR(_28828)->dbl) ) ){
            goto L2; // [44] 136
        }
        _0 = (int) DBL_PTR(_28828)->dbl;
    }
    else {
        _0 = _28828;
    };
    _28828 = NOVALUE;
    switch ( _0 ){ 

        /** 		    case ENTRY then*/
        case 424:

        /** 				if not (opcode = WHILE or opcode = LOOP) then*/
        _28831 = (_opcode_56709 == 47);
        if (_28831 != 0) {
            DeRef(_28832);
            _28832 = 1;
            goto L3; // [61] 75
        }
        _28833 = (_opcode_56709 == 422);
        _28832 = (_28833 != 0);
L3: 
        if (_28832 != 0)
        goto L4; // [75] 86
        _28832 = NOVALUE;

        /** 					CompileErr(14)*/
        RefDS(_21829);
        _43CompileErr(14, _21829, 0);
L4: 

        /** 			    has_entry = 1*/
        _has_entry_56713 = 1;
        goto L5; // [91] 146

        /** 			case FALLTHRU then*/
        case 431:

        /** 				if not opcode = SWITCH then*/
        _28835 = (_opcode_56709 == 0);
        if (_28835 != 185)
        goto L6; // [104] 116

        /** 					CompileErr(13)*/
        RefDS(_21829);
        _43CompileErr(13, _21829, 0);
L6: 

        /** 				switch_stack[$][SWITCH_FALLTHRU] = 1*/
        if (IS_SEQUENCE(_30switch_stack_53919)){
                _28837 = SEQ_PTR(_30switch_stack_53919)->length;
        }
        else {
            _28837 = 1;
        }
        _2 = (int)SEQ_PTR(_30switch_stack_53919);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _30switch_stack_53919 = MAKE_SEQ(_2);
        }
        _3 = (int)(_28837 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 5);
        _1 = *(int *)_2;
        *(int *)_2 = 1;
        DeRef(_1);
        _28838 = NOVALUE;
        goto L5; // [132] 146

        /** 			case else*/
        default:
L2: 

        /** 			    CompileErr(27)*/
        RefDS(_21829);
        _43CompileErr(27, _21829, 0);
    ;}L5: 

    /**         tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);
    goto L7; // [151] 240
L1: 

    /** 	elsif tok[T_ID] = WITHOUT then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28841 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28841, 421)){
        _28841 = NOVALUE;
        goto L8; // [164] 239
    }
    _28841 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = FALLTHRU then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28844 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28844, 431)){
        _28844 = NOVALUE;
        goto L9; // [183] 225
    }
    _28844 = NOVALUE;

    /** 			if not opcode = SWITCH then*/
    _28846 = (_opcode_56709 == 0);
    if (_28846 != 185)
    goto LA; // [194] 206

    /** 				CompileErr(15)*/
    RefDS(_21829);
    _43CompileErr(15, _21829, 0);
LA: 

    /** 			switch_stack[$][SWITCH_FALLTHRU] = 0*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28848 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28848 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28848 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _28849 = NOVALUE;
    goto LB; // [222] 233
L9: 

    /** 			CompileErr(27)*/
    RefDS(_21829);
    _43CompileErr(27, _21829, 0);
LB: 

    /**         tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);
L8: 
L7: 

    /** 	labbel=0*/
    DeRef(_labbel_56712);
    _labbel_56712 = 0;

    /** 	if tok[T_ID]=LABEL then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28852 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28852, 419)){
        _28852 = NOVALUE;
        goto LC; // [255] 317
    }
    _28852 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != STRING then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28855 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _28855, 503)){
        _28855 = NOVALUE;
        goto LD; // [274] 286
    }
    _28855 = NOVALUE;

    /** 			CompileErr(38)*/
    RefDS(_21829);
    _43CompileErr(38, _21829, 0);
LD: 

    /** 		labbel = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28857 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_28857)){
        _28858 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_28857)->dbl));
    }
    else{
        _28858 = (int)*(((s1_ptr)_2)->base + _28857);
    }
    DeRef(_labbel_56712);
    _2 = (int)SEQ_PTR(_28858);
    _labbel_56712 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_labbel_56712);
    _28858 = NOVALUE;

    /** 		block_label( labbel )*/
    Ref(_labbel_56712);
    _65block_label(_labbel_56712);

    /** 		tok = next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);
LC: 

    /** 	if opcode = IF or opcode = SWITCH then*/
    _28861 = (_opcode_56709 == 20);
    if (_28861 != 0) {
        goto LE; // [325] 340
    }
    _28863 = (_opcode_56709 == 185);
    if (_28863 == 0)
    {
        DeRef(_28863);
        _28863 = NOVALUE;
        goto LF; // [336] 351
    }
    else{
        DeRef(_28863);
        _28863 = NOVALUE;
    }
LE: 

    /** 		if_labels = append(if_labels,labbel)*/
    Ref(_labbel_56712);
    Append(&_30if_labels_53714, _30if_labels_53714, _labbel_56712);
    goto L10; // [348] 360
LF: 

    /** 		loop_labels = append(loop_labels,labbel)*/
    Ref(_labbel_56712);
    Append(&_30loop_labels_53713, _30loop_labels_53713, _labbel_56712);
L10: 

    /** 	if block_index=length(block_list) then*/
    if (IS_SEQUENCE(_30block_list_53715)){
            _28866 = SEQ_PTR(_30block_list_53715)->length;
    }
    else {
        _28866 = 1;
    }
    if (_30block_index_53716 != _28866)
    goto L11; // [369] 392

    /** 	    block_list &= opcode*/
    Append(&_30block_list_53715, _30block_list_53715, _opcode_56709);

    /** 	    block_index += 1*/
    _30block_index_53716 = _30block_index_53716 + 1;
    goto L12; // [389] 411
L11: 

    /** 	    block_index += 1*/
    _30block_index_53716 = _30block_index_53716 + 1;

    /** 	    block_list[block_index] = opcode*/
    _2 = (int)SEQ_PTR(_30block_list_53715);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30block_list_53715 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _30block_index_53716);
    *(int *)_2 = _opcode_56709;
L12: 

    /** 	if tok[T_ID]=ENTRY then*/
    _2 = (int)SEQ_PTR(_tok_56711);
    _28871 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28871, 424)){
        _28871 = NOVALUE;
        goto L13; // [421] 449
    }
    _28871 = NOVALUE;

    /** 	    if has_entry then*/
    if (_has_entry_56713 == 0)
    {
        goto L14; // [427] 438
    }
    else{
    }

    /** 	        CompileErr(64)*/
    RefDS(_21829);
    _43CompileErr(64, _21829, 0);
L14: 

    /** 	    has_entry=1*/
    _has_entry_56713 = 1;

    /** 	    tok=next_token()*/
    _0 = _tok_56711;
    _tok_56711 = _30next_token();
    DeRef(_0);
L13: 

    /** 	if has_entry and (opcode = IF or opcode = SWITCH) then*/
    if (_has_entry_56713 == 0) {
        goto L15; // [451] 487
    }
    _28875 = (_opcode_56709 == 20);
    if (_28875 != 0) {
        DeRef(_28876);
        _28876 = 1;
        goto L16; // [461] 475
    }
    _28877 = (_opcode_56709 == 185);
    _28876 = (_28877 != 0);
L16: 
    if (_28876 == 0)
    {
        _28876 = NOVALUE;
        goto L15; // [476] 487
    }
    else{
        _28876 = NOVALUE;
    }

    /** 		CompileErr(80)*/
    RefDS(_21829);
    _43CompileErr(80, _21829, 0);
L15: 

    /** 	if opcode = IF then*/
    if (_opcode_56709 != 20)
    goto L17; // [491] 507

    /** 		opcode = THEN*/
    _opcode_56709 = 410;
    goto L18; // [504] 517
L17: 

    /** 		opcode = DO*/
    _opcode_56709 = 411;
L18: 

    /** 	putback(tok)*/
    Ref(_tok_56711);
    _30putback(_tok_56711);

    /** 	tok_match(opcode)*/
    _30tok_match(_opcode_56709, 0);

    /** 	return has_entry*/
    DeRef(_tok_56711);
    DeRef(_labbel_56712);
    DeRef(_28831);
    _28831 = NOVALUE;
    DeRef(_28833);
    _28833 = NOVALUE;
    DeRef(_28835);
    _28835 = NOVALUE;
    DeRef(_28846);
    _28846 = NOVALUE;
    _28857 = NOVALUE;
    DeRef(_28861);
    _28861 = NOVALUE;
    DeRef(_28875);
    _28875 = NOVALUE;
    DeRef(_28877);
    _28877 = NOVALUE;
    return _has_entry_56713;
    ;
}


void _30If_statement()
{
    int _addr_inlined_AppendEList_at_624_56959 = NOVALUE;
    int _addr_inlined_AppendEList_at_260_56888 = NOVALUE;
    int _tok_56831 = NOVALUE;
    int _prev_false_56832 = NOVALUE;
    int _prev_false2_56833 = NOVALUE;
    int _elist_base_56834 = NOVALUE;
    int _temps_56842 = NOVALUE;
    int _31368 = NOVALUE;
    int _28943 = NOVALUE;
    int _28942 = NOVALUE;
    int _28939 = NOVALUE;
    int _28938 = NOVALUE;
    int _28936 = NOVALUE;
    int _28935 = NOVALUE;
    int _28934 = NOVALUE;
    int _28932 = NOVALUE;
    int _28931 = NOVALUE;
    int _28929 = NOVALUE;
    int _28928 = NOVALUE;
    int _28927 = NOVALUE;
    int _28925 = NOVALUE;
    int _28924 = NOVALUE;
    int _28922 = NOVALUE;
    int _28921 = NOVALUE;
    int _28920 = NOVALUE;
    int _28919 = NOVALUE;
    int _28917 = NOVALUE;
    int _28916 = NOVALUE;
    int _28913 = NOVALUE;
    int _28911 = NOVALUE;
    int _28910 = NOVALUE;
    int _28909 = NOVALUE;
    int _28906 = NOVALUE;
    int _28903 = NOVALUE;
    int _28902 = NOVALUE;
    int _28900 = NOVALUE;
    int _28899 = NOVALUE;
    int _28897 = NOVALUE;
    int _28896 = NOVALUE;
    int _28894 = NOVALUE;
    int _28891 = NOVALUE;
    int _28889 = NOVALUE;
    int _28888 = NOVALUE;
    int _28887 = NOVALUE;
    int _28883 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer prev_false*/

    /** 	integer prev_false2*/

    /** 	integer elist_base*/

    /** 	if_stack &= IF*/
    Append(&_30if_stack_53720, _30if_stack_53720, 20);

    /** 	Start_block( IF )*/
    _65Start_block(20, 0);

    /** 	elist_base = length(break_list)*/
    if (IS_SEQUENCE(_30break_list_53703)){
            _elist_base_56834 = SEQ_PTR(_30break_list_53703)->length;
    }
    else {
        _elist_base_56834 = 1;
    }

    /** 	short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_53687 = _9FALSE_429;

    /** 	SC1_type = 0*/
    _30SC1_type_53690 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	sequence temps = get_temps()*/
    _31368 = Repeat(_21829, 2);
    _0 = _temps_56842;
    _temps_56842 = _37get_temps(_31368);
    DeRef(_0);
    _31368 = NOVALUE;

    /** 	emit_op(IF)*/
    _37emit_op(20);

    /** 	prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28883 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28883 = 1;
    }
    _prev_false_56832 = _28883 + 1;
    _28883 = NOVALUE;

    /** 	emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 	prev_false2=finish_block_header(IF)  -- 0*/
    _prev_false2_56833 = _30finish_block_header(20);
    if (!IS_ATOM_INT(_prev_false2_56833)) {
        _1 = (long)(DBL_PTR(_prev_false2_56833)->dbl);
        DeRefDS(_prev_false2_56833);
        _prev_false2_56833 = _1;
    }

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_53690 != 9)
    goto L1; // [106] 159

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _28887 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_28887 +(unsigned long) HIGH_BITS) >= 0){
        _28887 = NewDouble((double)_28887);
    }
    _37backpatch(_28887, 147);
    _28887 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [128] 139
    }
    else{
    }

    /** 			emit_op(NOP1)  -- to get label here*/
    _37emit_op(159);
L2: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28888 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28888 = 1;
    }
    _28889 = _28888 + 1;
    _28888 = NOVALUE;
    _37backpatch(_30SC1_patch_53689, _28889);
    _28889 = NOVALUE;
    goto L3; // [156] 192
L1: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_53690 != 8)
    goto L4; // [165] 191

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _28891 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_28891 +(unsigned long) HIGH_BITS) >= 0){
        _28891 = NewDouble((double)_28891);
    }
    _37backpatch(_28891, 146);
    _28891 = NOVALUE;

    /** 		prev_false2 = SC1_patch*/
    _prev_false2_56833 = _30SC1_patch_53689;
L4: 
L3: 

    /** 	short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	tok = next_token()*/
    _0 = _tok_56831;
    _tok_56831 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = ELSIF do*/
L5: 
    _2 = (int)SEQ_PTR(_tok_56831);
    _28894 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28894, 414)){
        _28894 = NOVALUE;
        goto L6; // [222] 530
    }
    _28894 = NOVALUE;

    /** 		Sibling_block( IF )*/
    _65Sibling_block(20);

    /** 		emit_op(ELSE)*/
    _37emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28896 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28896 = 1;
    }
    _28897 = _28896 + 1;
    _28896 = NOVALUE;
    _addr_inlined_AppendEList_at_260_56888 = _28897;
    _28897 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_53703, _30break_list_53703, _addr_inlined_AppendEList_at_260_56888);

    /** end procedure*/
    goto L7; // [266] 269
L7: 

    /** 		break_delay &= 1*/
    Append(&_30break_delay_53704, _30break_delay_53704, 1);

    /** 		emit_forward_addr()  -- to be patched*/
    _30emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L8; // [287] 298
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L8: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28899 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28899 = 1;
    }
    _28900 = _28899 + 1;
    _28899 = NOVALUE;
    _37backpatch(_prev_false_56832, _28900);
    _28900 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56833 == 0)
    goto L9; // [315] 335

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28902 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28902 = 1;
    }
    _28903 = _28902 + 1;
    _28902 = NOVALUE;
    _37backpatch(_prev_false2_56833, _28903);
    _28903 = NOVALUE;
L9: 

    /** 		StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 		short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** 		short_circuit_B = FALSE*/
    _30short_circuit_B_53687 = _9FALSE_429;

    /** 		SC1_type = 0*/
    _30SC1_type_53690 = 0;

    /** 		push_temps( temps )*/
    RefDS(_temps_56842);
    _37push_temps(_temps_56842);

    /** 		Expr()*/
    _30Expr();

    /** 		temps = get_temps( temps )*/
    RefDS(_temps_56842);
    _0 = _temps_56842;
    _temps_56842 = _37get_temps(_temps_56842);
    DeRefDS(_0);

    /** 		emit_op(IF)*/
    _37emit_op(20);

    /** 		prev_false = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28906 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28906 = 1;
    }
    _prev_false_56832 = _28906 + 1;
    _28906 = NOVALUE;

    /** 		prev_false2 = 0*/
    _prev_false2_56833 = 0;

    /** 		emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 		if SC1_type = OR then*/
    if (_30SC1_type_53690 != 9)
    goto LA; // [414] 467

    /** 			backpatch(SC1_patch-3, SC1_OR_IF)*/
    _28909 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_28909 +(unsigned long) HIGH_BITS) >= 0){
        _28909 = NewDouble((double)_28909);
    }
    _37backpatch(_28909, 147);
    _28909 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LB; // [436] 447
    }
    else{
    }

    /** 				emit_op(NOP1)*/
    _37emit_op(159);
LB: 

    /** 			backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28910 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28910 = 1;
    }
    _28911 = _28910 + 1;
    _28910 = NOVALUE;
    _37backpatch(_30SC1_patch_53689, _28911);
    _28911 = NOVALUE;
    goto LC; // [464] 500
LA: 

    /** 		elsif SC1_type = AND then*/
    if (_30SC1_type_53690 != 8)
    goto LD; // [473] 499

    /** 			backpatch(SC1_patch-3, SC1_AND_IF)*/
    _28913 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_28913 +(unsigned long) HIGH_BITS) >= 0){
        _28913 = NewDouble((double)_28913);
    }
    _37backpatch(_28913, 146);
    _28913 = NOVALUE;

    /** 			prev_false2 = SC1_patch*/
    _prev_false2_56833 = _30SC1_patch_53689;
LD: 
LC: 

    /** 		short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 		tok_match(THEN)*/
    _30tok_match(410, 0);

    /** 		Statement_list()*/
    _30Statement_list();

    /** 		tok = next_token()*/
    _0 = _tok_56831;
    _tok_56831 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L5; // [527] 214
L6: 

    /** 	if tok[T_ID] = ELSE or length(temps[1]) then*/
    _2 = (int)SEQ_PTR(_tok_56831);
    _28916 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_28916)) {
        _28917 = (_28916 == 23);
    }
    else {
        _28917 = binary_op(EQUALS, _28916, 23);
    }
    _28916 = NOVALUE;
    if (IS_ATOM_INT(_28917)) {
        if (_28917 != 0) {
            goto LE; // [544] 560
        }
    }
    else {
        if (DBL_PTR(_28917)->dbl != 0.0) {
            goto LE; // [544] 560
        }
    }
    _2 = (int)SEQ_PTR(_temps_56842);
    _28919 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_28919)){
            _28920 = SEQ_PTR(_28919)->length;
    }
    else {
        _28920 = 1;
    }
    _28919 = NOVALUE;
    if (_28920 == 0)
    {
        _28920 = NOVALUE;
        goto LF; // [556] 715
    }
    else{
        _28920 = NOVALUE;
    }
LE: 

    /** 		Sibling_block( IF )*/
    _65Sibling_block(20);

    /** 		StartSourceLine(FALSE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9FALSE_429, 0, 1);

    /** 		emit_op(ELSE)*/
    _37emit_op(23);

    /** 		AppendEList(length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28921 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28921 = 1;
    }
    _28922 = _28921 + 1;
    _28921 = NOVALUE;
    _addr_inlined_AppendEList_at_624_56959 = _28922;
    _28922 = NOVALUE;

    /** 	break_list = append(break_list, addr)*/
    Append(&_30break_list_53703, _30break_list_53703, _addr_inlined_AppendEList_at_624_56959);

    /** end procedure*/
    goto L10; // [611] 614
L10: 

    /** 		break_delay &= 1*/
    Append(&_30break_delay_53704, _30break_delay_53704, 1);

    /** 		emit_forward_addr() -- to be patched*/
    _30emit_forward_addr();

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L11; // [632] 643
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L11: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28924 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28924 = 1;
    }
    _28925 = _28924 + 1;
    _28924 = NOVALUE;
    _37backpatch(_prev_false_56832, _28925);
    _28925 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56833 == 0)
    goto L12; // [660] 680

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28927 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28927 = 1;
    }
    _28928 = _28927 + 1;
    _28927 = NOVALUE;
    _37backpatch(_prev_false2_56833, _28928);
    _28928 = NOVALUE;
L12: 

    /** 		push_temps( temps )*/
    RefDS(_temps_56842);
    _37push_temps(_temps_56842);

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_56831);
    _28929 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _28929, 23)){
        _28929 = NOVALUE;
        goto L13; // [695] 706
    }
    _28929 = NOVALUE;

    /** 			Statement_list()*/
    _30Statement_list();
    goto L14; // [703] 773
L13: 

    /** 			putback(tok)*/
    Ref(_tok_56831);
    _30putback(_tok_56831);
    goto L14; // [712] 773
LF: 

    /** 		putback(tok)*/
    Ref(_tok_56831);
    _30putback(_tok_56831);

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L15; // [724] 735
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L15: 

    /** 		backpatch(prev_false, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28931 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28931 = 1;
    }
    _28932 = _28931 + 1;
    _28931 = NOVALUE;
    _37backpatch(_prev_false_56832, _28932);
    _28932 = NOVALUE;

    /** 		if prev_false2 != 0 then*/
    if (_prev_false2_56833 == 0)
    goto L16; // [752] 772

    /** 			backpatch(prev_false2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _28934 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28934 = 1;
    }
    _28935 = _28934 + 1;
    _28934 = NOVALUE;
    _37backpatch(_prev_false2_56833, _28935);
    _28935 = NOVALUE;
L16: 
L14: 

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(IF, END)*/
    _30tok_match(20, 402);

    /** 	End_block( IF )*/
    _65End_block(20);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L17; // [802] 825
    }
    else{
    }

    /** 		if length(break_list) > elist_base then*/
    if (IS_SEQUENCE(_30break_list_53703)){
            _28936 = SEQ_PTR(_30break_list_53703)->length;
    }
    else {
        _28936 = 1;
    }
    if (_28936 <= _elist_base_56834)
    goto L18; // [812] 824

    /** 			emit_op(NOP1)  -- to emit label here*/
    _37emit_op(159);
L18: 
L17: 

    /** 	PatchEList(elist_base)*/
    _30PatchEList(_elist_base_56834);

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_30if_labels_53714)){
            _28938 = SEQ_PTR(_30if_labels_53714)->length;
    }
    else {
        _28938 = 1;
    }
    _28939 = _28938 - 1;
    _28938 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_labels_53714;
    RHS_Slice(_30if_labels_53714, 1, _28939);

    /** 	block_index -= 1*/
    _30block_index_53716 = _30block_index_53716 - 1;

    /** 	if_stack = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _28942 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _28942 = 1;
    }
    _28943 = _28942 - 1;
    _28942 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_stack_53720;
    RHS_Slice(_30if_stack_53720, 1, _28943);

    /** end procedure*/
    DeRef(_tok_56831);
    DeRef(_temps_56842);
    _28919 = NOVALUE;
    DeRef(_28917);
    _28917 = NOVALUE;
    _28939 = NOVALUE;
    _28943 = NOVALUE;
    return;
    ;
}


void _30exit_loop(int _exit_base_57019)
{
    int _28958 = NOVALUE;
    int _28957 = NOVALUE;
    int _28955 = NOVALUE;
    int _28954 = NOVALUE;
    int _28952 = NOVALUE;
    int _28951 = NOVALUE;
    int _28949 = NOVALUE;
    int _28948 = NOVALUE;
    int _28946 = NOVALUE;
    int _28945 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchXList(exit_base)*/
    _30PatchXList(_exit_base_57019);

    /** 	loop_labels = loop_labels[1..$-1]*/
    if (IS_SEQUENCE(_30loop_labels_53713)){
            _28945 = SEQ_PTR(_30loop_labels_53713)->length;
    }
    else {
        _28945 = 1;
    }
    _28946 = _28945 - 1;
    _28945 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30loop_labels_53713;
    RHS_Slice(_30loop_labels_53713, 1, _28946);

    /** 	loop_stack = loop_stack[1..$-1]*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _28948 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _28948 = 1;
    }
    _28949 = _28948 - 1;
    _28948 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30loop_stack_53719;
    RHS_Slice(_30loop_stack_53719, 1, _28949);

    /** 	continue_addr = continue_addr[1..$-1]*/
    if (IS_SEQUENCE(_30continue_addr_53710)){
            _28951 = SEQ_PTR(_30continue_addr_53710)->length;
    }
    else {
        _28951 = 1;
    }
    _28952 = _28951 - 1;
    _28951 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30continue_addr_53710;
    RHS_Slice(_30continue_addr_53710, 1, _28952);

    /** 	retry_addr = retry_addr[1..$-1]*/
    if (IS_SEQUENCE(_30retry_addr_53711)){
            _28954 = SEQ_PTR(_30retry_addr_53711)->length;
    }
    else {
        _28954 = 1;
    }
    _28955 = _28954 - 1;
    _28954 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30retry_addr_53711;
    RHS_Slice(_30retry_addr_53711, 1, _28955);

    /** 	entry_addr = entry_addr[1..$-1]*/
    if (IS_SEQUENCE(_30entry_addr_53709)){
            _28957 = SEQ_PTR(_30entry_addr_53709)->length;
    }
    else {
        _28957 = 1;
    }
    _28958 = _28957 - 1;
    _28957 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30entry_addr_53709;
    RHS_Slice(_30entry_addr_53709, 1, _28958);

    /** 	block_index -= 1*/
    _30block_index_53716 = _30block_index_53716 - 1;

    /** end procedure*/
    _28946 = NOVALUE;
    _28949 = NOVALUE;
    _28952 = NOVALUE;
    _28955 = NOVALUE;
    _28958 = NOVALUE;
    return;
    ;
}


void _30push_switch()
{
    int _28962 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if_stack &= SWITCH*/
    Append(&_30if_stack_53720, _30if_stack_53720, 185);

    /** 	switch_stack = append( switch_stack, { {}, {}, 0, 0, 0, 0 })*/
    _1 = NewS1(6);
    _2 = (int)((s1_ptr)_1)->base;
    RefDSn(_21829, 2);
    *((int *)(_2+4)) = _21829;
    *((int *)(_2+8)) = _21829;
    *((int *)(_2+12)) = 0;
    *((int *)(_2+16)) = 0;
    *((int *)(_2+20)) = 0;
    *((int *)(_2+24)) = 0;
    _28962 = MAKE_SEQ(_1);
    RefDS(_28962);
    Append(&_30switch_stack_53919, _30switch_stack_53919, _28962);
    DeRefDS(_28962);
    _28962 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30pop_switch(int _break_base_57044)
{
    int _28977 = NOVALUE;
    int _28976 = NOVALUE;
    int _28974 = NOVALUE;
    int _28973 = NOVALUE;
    int _28971 = NOVALUE;
    int _28970 = NOVALUE;
    int _28968 = NOVALUE;
    int _28967 = NOVALUE;
    int _28966 = NOVALUE;
    int _28965 = NOVALUE;
    int _0, _1, _2;
    

    /** 	PatchEList( break_base )*/
    _30PatchEList(_break_base_57044);

    /** 	block_index -= 1*/
    _30block_index_53716 = _30block_index_53716 - 1;

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28965 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28965 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _28966 = (int)*(((s1_ptr)_2)->base + _28965);
    _2 = (int)SEQ_PTR(_28966);
    _28967 = (int)*(((s1_ptr)_2)->base + 1);
    _28966 = NOVALUE;
    if (IS_SEQUENCE(_28967)){
            _28968 = SEQ_PTR(_28967)->length;
    }
    else {
        _28968 = 1;
    }
    _28967 = NOVALUE;
    if (_28968 <= 0)
    goto L1; // [34] 46

    /** 		End_block( CASE )*/
    _65End_block(186);
L1: 

    /** 	if_labels = if_labels[1..$-1]*/
    if (IS_SEQUENCE(_30if_labels_53714)){
            _28970 = SEQ_PTR(_30if_labels_53714)->length;
    }
    else {
        _28970 = 1;
    }
    _28971 = _28970 - 1;
    _28970 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_labels_53714;
    RHS_Slice(_30if_labels_53714, 1, _28971);

    /** 	if_stack  = if_stack[1..$-1]*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _28973 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _28973 = 1;
    }
    _28974 = _28973 - 1;
    _28973 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30if_stack_53720;
    RHS_Slice(_30if_stack_53720, 1, _28974);

    /** 	switch_stack  = switch_stack[1..$-1]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28976 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28976 = 1;
    }
    _28977 = _28976 - 1;
    _28976 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30switch_stack_53919;
    RHS_Slice(_30switch_stack_53919, 1, _28977);

    /** end procedure*/
    _28967 = NOVALUE;
    _28971 = NOVALUE;
    _28974 = NOVALUE;
    _28977 = NOVALUE;
    return;
    ;
}


void _30add_case(int _sym_57065, int _sign_57066)
{
    int _29003 = NOVALUE;
    int _29002 = NOVALUE;
    int _29001 = NOVALUE;
    int _29000 = NOVALUE;
    int _28999 = NOVALUE;
    int _28998 = NOVALUE;
    int _28997 = NOVALUE;
    int _28996 = NOVALUE;
    int _28994 = NOVALUE;
    int _28993 = NOVALUE;
    int _28992 = NOVALUE;
    int _28991 = NOVALUE;
    int _28990 = NOVALUE;
    int _28989 = NOVALUE;
    int _28987 = NOVALUE;
    int _28986 = NOVALUE;
    int _28984 = NOVALUE;
    int _28983 = NOVALUE;
    int _28982 = NOVALUE;
    int _28981 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if sign < 0 then*/
    if (_sign_57066 >= 0)
    goto L1; // [5] 15

    /** 		sym = -sym*/
    _0 = _sym_57065;
    if (IS_ATOM_INT(_sym_57065)) {
        if ((unsigned long)_sym_57065 == 0xC0000000)
        _sym_57065 = (int)NewDouble((double)-0xC0000000);
        else
        _sym_57065 = - _sym_57065;
    }
    else {
        _sym_57065 = unary_op(UMINUS, _sym_57065);
    }
    DeRefi(_0);
L1: 

    /** 	if find(sym, switch_stack[$][SWITCH_CASES] ) = 0 then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28981 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28981 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _28982 = (int)*(((s1_ptr)_2)->base + _28981);
    _2 = (int)SEQ_PTR(_28982);
    _28983 = (int)*(((s1_ptr)_2)->base + 1);
    _28982 = NOVALUE;
    _28984 = find_from(_sym_57065, _28983, 1);
    _28983 = NOVALUE;
    if (_28984 != 0)
    goto L2; // [35] 144

    /** 		switch_stack[$][SWITCH_CASES]       = append( switch_stack[$][SWITCH_CASES], sym )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28986 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28986 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28986 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28989 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28989 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _28990 = (int)*(((s1_ptr)_2)->base + _28989);
    _2 = (int)SEQ_PTR(_28990);
    _28991 = (int)*(((s1_ptr)_2)->base + 1);
    _28990 = NOVALUE;
    Ref(_sym_57065);
    Append(&_28992, _28991, _sym_57065);
    _28991 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _28992;
    if( _1 != _28992 ){
        DeRef(_1);
    }
    _28992 = NOVALUE;
    _28987 = NOVALUE;

    /** 		switch_stack[$][SWITCH_JUMP_TABLE] &= length(Code) + 1*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _28993 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _28993 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_28993 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_11771)){
            _28996 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _28996 = 1;
    }
    _28997 = _28996 + 1;
    _28996 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    _28998 = (int)*(((s1_ptr)_2)->base + 2);
    _28994 = NOVALUE;
    if (IS_SEQUENCE(_28998) && IS_ATOM(_28997)) {
        Append(&_28999, _28998, _28997);
    }
    else if (IS_ATOM(_28998) && IS_SEQUENCE(_28997)) {
    }
    else {
        Concat((object_ptr)&_28999, _28998, _28997);
        _28998 = NOVALUE;
    }
    _28998 = NOVALUE;
    _28997 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _28999;
    if( _1 != _28999 ){
        DeRef(_1);
    }
    _28999 = NOVALUE;
    _28994 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [109] 152
    }
    else{
    }

    /** 			emit_addr( CASE )*/
    _37emit_addr(186);

    /** 			emit_addr( length( switch_stack[$][SWITCH_CASES] ) )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29000 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29000 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29001 = (int)*(((s1_ptr)_2)->base + _29000);
    _2 = (int)SEQ_PTR(_29001);
    _29002 = (int)*(((s1_ptr)_2)->base + 1);
    _29001 = NOVALUE;
    if (IS_SEQUENCE(_29002)){
            _29003 = SEQ_PTR(_29002)->length;
    }
    else {
        _29003 = 1;
    }
    _29002 = NOVALUE;
    _37emit_addr(_29003);
    _29003 = NOVALUE;
    goto L3; // [141] 152
L2: 

    /** 		CompileErr( 63 )*/
    RefDS(_21829);
    _43CompileErr(63, _21829, 0);
L3: 

    /** end procedure*/
    DeRef(_sym_57065);
    _29002 = NOVALUE;
    return;
    ;
}


void _30case_else()
{
    int _29011 = NOVALUE;
    int _29010 = NOVALUE;
    int _29008 = NOVALUE;
    int _29007 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	switch_stack[$][SWITCH_ELSE] = length(Code) + 1*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29007 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29007 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29007 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_12Code_11771)){
            _29010 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29010 = 1;
    }
    _29011 = _29010 + 1;
    _29010 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _29011;
    if( _1 != _29011 ){
        DeRef(_1);
    }
    _29011 = NOVALUE;
    _29008 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [30] 46
    }
    else{
    }

    /** 		emit_addr( CASE )*/
    _37emit_addr(186);

    /** 		emit_addr( 0 )*/
    _37emit_addr(0);
L1: 

    /** end procedure*/
    return;
    ;
}


void _30Case_statement()
{
    int _else_case_2__tmp_at145_57162 = NOVALUE;
    int _else_case_1__tmp_at145_57161 = NOVALUE;
    int _else_case_inlined_else_case_at_145_57160 = NOVALUE;
    int _tok_57124 = NOVALUE;
    int _condition_57126 = NOVALUE;
    int _start_line_57155 = NOVALUE;
    int _sign_57166 = NOVALUE;
    int _fwd_57179 = NOVALUE;
    int _symi_57189 = NOVALUE;
    int _fwdref_57258 = NOVALUE;
    int _31367 = NOVALUE;
    int _29093 = NOVALUE;
    int _29092 = NOVALUE;
    int _29091 = NOVALUE;
    int _29090 = NOVALUE;
    int _29089 = NOVALUE;
    int _29088 = NOVALUE;
    int _29086 = NOVALUE;
    int _29085 = NOVALUE;
    int _29084 = NOVALUE;
    int _29083 = NOVALUE;
    int _29082 = NOVALUE;
    int _29081 = NOVALUE;
    int _29079 = NOVALUE;
    int _29076 = NOVALUE;
    int _29073 = NOVALUE;
    int _29072 = NOVALUE;
    int _29071 = NOVALUE;
    int _29070 = NOVALUE;
    int _29067 = NOVALUE;
    int _29066 = NOVALUE;
    int _29065 = NOVALUE;
    int _29064 = NOVALUE;
    int _29061 = NOVALUE;
    int _29060 = NOVALUE;
    int _29059 = NOVALUE;
    int _29058 = NOVALUE;
    int _29056 = NOVALUE;
    int _29055 = NOVALUE;
    int _29054 = NOVALUE;
    int _29052 = NOVALUE;
    int _29051 = NOVALUE;
    int _29050 = NOVALUE;
    int _29049 = NOVALUE;
    int _29048 = NOVALUE;
    int _29046 = NOVALUE;
    int _29045 = NOVALUE;
    int _29043 = NOVALUE;
    int _29042 = NOVALUE;
    int _29041 = NOVALUE;
    int _29040 = NOVALUE;
    int _29036 = NOVALUE;
    int _29035 = NOVALUE;
    int _29034 = NOVALUE;
    int _29031 = NOVALUE;
    int _29028 = NOVALUE;
    int _29025 = NOVALUE;
    int _29024 = NOVALUE;
    int _29023 = NOVALUE;
    int _29022 = NOVALUE;
    int _29021 = NOVALUE;
    int _29020 = NOVALUE;
    int _29019 = NOVALUE;
    int _29017 = NOVALUE;
    int _29016 = NOVALUE;
    int _29015 = NOVALUE;
    int _29014 = NOVALUE;
    int _29012 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not in_switch() then*/
    _29012 = _30in_switch();
    if (IS_ATOM_INT(_29012)) {
        if (_29012 != 0){
            DeRef(_29012);
            _29012 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29012)->dbl != 0.0){
            DeRef(_29012);
            _29012 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29012);
    _29012 = NOVALUE;

    /** 		CompileErr( 34 )*/
    RefDS(_21829);
    _43CompileErr(34, _21829, 0);
L1: 

    /** 	if length(switch_stack[$][SWITCH_CASES]) > 0 then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29014 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29014 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29015 = (int)*(((s1_ptr)_2)->base + _29014);
    _2 = (int)SEQ_PTR(_29015);
    _29016 = (int)*(((s1_ptr)_2)->base + 1);
    _29015 = NOVALUE;
    if (IS_SEQUENCE(_29016)){
            _29017 = SEQ_PTR(_29016)->length;
    }
    else {
        _29017 = 1;
    }
    _29016 = NOVALUE;
    if (_29017 <= 0)
    goto L2; // [35] 101

    /** 		Sibling_block( CASE )*/
    _65Sibling_block(186);

    /** 		if not switch_stack[$][SWITCH_FALLTHRU] and*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29019 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29019 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29020 = (int)*(((s1_ptr)_2)->base + _29019);
    _2 = (int)SEQ_PTR(_29020);
    _29021 = (int)*(((s1_ptr)_2)->base + 5);
    _29020 = NOVALUE;
    if (IS_ATOM_INT(_29021)) {
        _29022 = (_29021 == 0);
    }
    else {
        _29022 = unary_op(NOT, _29021);
    }
    _29021 = NOVALUE;
    if (IS_ATOM_INT(_29022)) {
        if (_29022 == 0) {
            goto L3; // [64] 110
        }
    }
    else {
        if (DBL_PTR(_29022)->dbl == 0.0) {
            goto L3; // [64] 110
        }
    }
    _29024 = (_30fallthru_case_57120 == 0);
    if (_29024 == 0)
    {
        DeRef(_29024);
        _29024 = NOVALUE;
        goto L3; // [74] 110
    }
    else{
        DeRef(_29024);
        _29024 = NOVALUE;
    }

    /** 			putback( {CASE, 0} )*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 186;
    ((int *)_2)[2] = 0;
    _29025 = MAKE_SEQ(_1);
    _30putback(_29025);
    _29025 = NOVALUE;

    /** 			Break_statement()*/
    _30Break_statement();

    /** 			tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);
    goto L3; // [98] 110
L2: 

    /** 		Start_block( CASE )*/
    _65Start_block(186, 0);
L3: 

    /** 	StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 	fallthru_case = 0*/
    _30fallthru_case_57120 = 0;

    /** 	integer start_line = line_number*/
    _start_line_57155 = _12line_number_11683;

    /** 	while 1 do*/
L4: 

    /** 		if else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _else_case_1__tmp_at145_57161 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _else_case_1__tmp_at145_57161 = 1;
    }
    DeRef(_else_case_2__tmp_at145_57162);
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _else_case_2__tmp_at145_57162 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at145_57161);
    RefDS(_else_case_2__tmp_at145_57162);
    DeRef(_else_case_inlined_else_case_at_145_57160);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at145_57162);
    _else_case_inlined_else_case_at_145_57160 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_145_57160);
    DeRef(_else_case_2__tmp_at145_57162);
    _else_case_2__tmp_at145_57162 = NOVALUE;
    if (_else_case_inlined_else_case_at_145_57160 == 0) {
        goto L5; // [160] 171
    }
    else {
        if (!IS_ATOM_INT(_else_case_inlined_else_case_at_145_57160) && DBL_PTR(_else_case_inlined_else_case_at_145_57160)->dbl == 0.0){
            goto L5; // [160] 171
        }
    }

    /** 			CompileErr( 33 )*/
    RefDS(_21829);
    _43CompileErr(33, _21829, 0);
L5: 

    /** 		maybe_namespace()*/
    _60maybe_namespace();

    /** 		tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);

    /** 		integer sign = 1*/
    _sign_57166 = 1;

    /** 		if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29028 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29028, 10)){
        _29028 = NOVALUE;
        goto L6; // [195] 212
    }
    _29028 = NOVALUE;

    /** 			sign = -1*/
    _sign_57166 = -1;

    /** 			tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);
    goto L7; // [209] 233
L6: 

    /** 		elsif tok[T_ID] = PLUS then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29031 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29031, 11)){
        _29031 = NOVALUE;
        goto L8; // [222] 232
    }
    _29031 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);
L8: 
L7: 

    /** 		integer fwd*/

    /** 		if not find( tok[T_ID], {ATOM, STRING, ELSE} ) then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29034 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 502;
    *((int *)(_2+8)) = 503;
    *((int *)(_2+12)) = 23;
    _29035 = MAKE_SEQ(_1);
    _29036 = find_from(_29034, _29035, 1);
    _29034 = NOVALUE;
    DeRefDS(_29035);
    _29035 = NOVALUE;
    if (_29036 != 0)
    goto L9; // [260] 435
    _29036 = NOVALUE;

    /** 			integer symi = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _symi_57189 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_symi_57189)){
        _symi_57189 = (long)DBL_PTR(_symi_57189)->dbl;
    }

    /** 			fwd = -1*/
    _fwd_57179 = -1;

    /** 			if symi > 0 then*/
    if (_symi_57189 <= 0)
    goto LA; // [280] 430

    /** 				if find(tok[T_ID] , VAR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29040 = (int)*(((s1_ptr)_2)->base + 1);
    _29041 = find_from(_29040, _28VAR_TOKS_11312, 1);
    _29040 = NOVALUE;
    if (_29041 == 0)
    {
        _29041 = NOVALUE;
        goto LB; // [299] 429
    }
    else{
        _29041 = NOVALUE;
    }

    /** 					if SymTab[symi][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29042 = (int)*(((s1_ptr)_2)->base + _symi_57189);
    _2 = (int)SEQ_PTR(_29042);
    _29043 = (int)*(((s1_ptr)_2)->base + 4);
    _29042 = NOVALUE;
    if (binary_op_a(NOTEQ, _29043, 9)){
        _29043 = NOVALUE;
        goto LC; // [318] 330
    }
    _29043 = NOVALUE;

    /** 						fwd = symi*/
    _fwd_57179 = _symi_57189;
    goto LD; // [327] 428
LC: 

    /** 					elsif SymTab[symi][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29045 = (int)*(((s1_ptr)_2)->base + _symi_57189);
    _2 = (int)SEQ_PTR(_29045);
    _29046 = (int)*(((s1_ptr)_2)->base + 3);
    _29045 = NOVALUE;
    if (binary_op_a(NOTEQ, _29046, 2)){
        _29046 = NOVALUE;
        goto LE; // [346] 427
    }
    _29046 = NOVALUE;

    /** 						fwd = 0*/
    _fwd_57179 = 0;

    /** 						if SymTab[symi][S_CODE] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29048 = (int)*(((s1_ptr)_2)->base + _symi_57189);
    _2 = (int)SEQ_PTR(_29048);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _29049 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _29049 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _29048 = NOVALUE;
    if (_29049 == 0) {
        _29049 = NOVALUE;
        goto LF; // [369] 393
    }
    else {
        if (!IS_ATOM_INT(_29049) && DBL_PTR(_29049)->dbl == 0.0){
            _29049 = NOVALUE;
            goto LF; // [369] 393
        }
        _29049 = NOVALUE;
    }
    _29049 = NOVALUE;

    /** 							tok[T_SYM] = SymTab[symi][S_CODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29050 = (int)*(((s1_ptr)_2)->base + _symi_57189);
    _2 = (int)SEQ_PTR(_29050);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _29051 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _29051 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _29050 = NOVALUE;
    Ref(_29051);
    _2 = (int)SEQ_PTR(_tok_57124);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_57124 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _29051;
    if( _1 != _29051 ){
        DeRef(_1);
    }
    _29051 = NOVALUE;
LF: 

    /** 						SymTab[symi][S_USAGE] = or_bits( SymTab[symi][S_USAGE], U_READ )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_symi_57189 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29054 = (int)*(((s1_ptr)_2)->base + _symi_57189);
    _2 = (int)SEQ_PTR(_29054);
    _29055 = (int)*(((s1_ptr)_2)->base + 5);
    _29054 = NOVALUE;
    if (IS_ATOM_INT(_29055)) {
        {unsigned long tu;
             tu = (unsigned long)_29055 | (unsigned long)1;
             _29056 = MAKE_UINT(tu);
        }
    }
    else {
        _29056 = binary_op(OR_BITS, _29055, 1);
    }
    _29055 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29056;
    if( _1 != _29056 ){
        DeRef(_1);
    }
    _29056 = NOVALUE;
    _29052 = NOVALUE;
LE: 
LD: 
LB: 
LA: 
    goto L10; // [432] 441
L9: 

    /** 			fwd = 0*/
    _fwd_57179 = 0;
L10: 

    /** 		if fwd < 0 then*/
    if (_fwd_57179 >= 0)
    goto L11; // [445] 471

    /** 			CompileErr( 91, {find_category(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29058 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29058);
    _29059 = _62find_category(_29058);
    _29058 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29059;
    _29060 = MAKE_SEQ(_1);
    _29059 = NOVALUE;
    _43CompileErr(91, _29060, 0);
    _29060 = NOVALUE;
L11: 

    /** 		if tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29061 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29061, 23)){
        _29061 = NOVALUE;
        goto L12; // [481] 542
    }
    _29061 = NOVALUE;

    /** 			if sign = -1 then*/
    if (_sign_57166 != -1)
    goto L13; // [487] 499

    /** 				CompileErr( 71 )*/
    RefDS(_21829);
    _43CompileErr(71, _21829, 0);
L13: 

    /** 			if length(switch_stack[$][SWITCH_CASES]) = 0 then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29064 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29064 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29065 = (int)*(((s1_ptr)_2)->base + _29064);
    _2 = (int)SEQ_PTR(_29065);
    _29066 = (int)*(((s1_ptr)_2)->base + 1);
    _29065 = NOVALUE;
    if (IS_SEQUENCE(_29066)){
            _29067 = SEQ_PTR(_29066)->length;
    }
    else {
        _29067 = 1;
    }
    _29066 = NOVALUE;
    if (_29067 != 0)
    goto L14; // [517] 529

    /** 				CompileErr( 44 )*/
    RefDS(_21829);
    _43CompileErr(44, _21829, 0);
L14: 

    /** 			case_else()*/
    _30case_else();

    /** 			exit*/
    goto L15; // [537] 777
    goto L16; // [539] 613
L12: 

    /** 		elsif fwd then*/
    if (_fwd_57179 == 0)
    {
        goto L17; // [544] 596
    }
    else{
    }

    /** 			integer fwdref = new_forward_reference( CASE, fwd )*/
    DeRef(_31367);
    _31367 = 186;
    _fwdref_57258 = _29new_forward_reference(186, _fwd_57179, 186);
    _31367 = NOVALUE;
    if (!IS_ATOM_INT(_fwdref_57258)) {
        _1 = (long)(DBL_PTR(_fwdref_57258)->dbl);
        DeRefDS(_fwdref_57258);
        _fwdref_57258 = _1;
    }

    /** 			add_case( {fwdref}, sign )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _fwdref_57258;
    _29070 = MAKE_SEQ(_1);
    _30add_case(_29070, _sign_57166);
    _29070 = NOVALUE;

    /** 			fwd:set_data( fwdref, switch_stack[$][SWITCH_PC] )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29071 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29071 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29072 = (int)*(((s1_ptr)_2)->base + _29071);
    _2 = (int)SEQ_PTR(_29072);
    _29073 = (int)*(((s1_ptr)_2)->base + 4);
    _29072 = NOVALUE;
    Ref(_29073);
    _29set_data(_fwdref_57258, _29073);
    _29073 = NOVALUE;
    goto L16; // [593] 613
L17: 

    /** 			condition = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _condition_57126 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_condition_57126)){
        _condition_57126 = (long)DBL_PTR(_condition_57126)->dbl;
    }

    /** 			add_case( condition, sign )*/
    _30add_case(_condition_57126, _sign_57166);
L16: 

    /** 		tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = THEN then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29076 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29076, 410)){
        _29076 = NOVALUE;
        goto L18; // [628] 732
    }
    _29076 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_57124;
    _tok_57124 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29079 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29079, 186)){
        _29079 = NOVALUE;
        goto L19; // [647] 717
    }
    _29079 = NOVALUE;

    /** 				if switch_stack[$][SWITCH_FALLTHRU] then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29081 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29081 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29082 = (int)*(((s1_ptr)_2)->base + _29081);
    _2 = (int)SEQ_PTR(_29082);
    _29083 = (int)*(((s1_ptr)_2)->base + 5);
    _29082 = NOVALUE;
    if (_29083 == 0) {
        _29083 = NOVALUE;
        goto L1A; // [666] 681
    }
    else {
        if (!IS_ATOM_INT(_29083) && DBL_PTR(_29083)->dbl == 0.0){
            _29083 = NOVALUE;
            goto L1A; // [666] 681
        }
        _29083 = NOVALUE;
    }
    _29083 = NOVALUE;

    /** 					start_line = line_number*/
    _start_line_57155 = _12line_number_11683;
    goto L1B; // [678] 770
L1A: 

    /** 					putback( tok )*/
    Ref(_tok_57124);
    _30putback(_tok_57124);

    /** 					Warning(220, empty_case_warning_flag,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _29084 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_29084);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29084;
    ((int *)_2)[2] = _start_line_57155;
    _29085 = MAKE_SEQ(_1);
    _29084 = NOVALUE;
    _43Warning(220, 2048, _29085);
    _29085 = NOVALUE;

    /** 					exit*/
    goto L15; // [711] 777
    goto L1B; // [714] 770
L19: 

    /** 				putback( tok )*/
    Ref(_tok_57124);
    _30putback(_tok_57124);

    /** 				exit*/
    goto L15; // [726] 777
    goto L1B; // [729] 770
L18: 

    /** 		elsif tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29086 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29086, -30)){
        _29086 = NOVALUE;
        goto L1C; // [742] 769
    }
    _29086 = NOVALUE;

    /** 			CompileErr(66,{LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_57124);
    _29088 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29088);
    RefDS(_26196);
    _29089 = _37LexName(_29088, _26196);
    _29088 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29089;
    _29090 = MAKE_SEQ(_1);
    _29089 = NOVALUE;
    _43CompileErr(66, _29090, 0);
    _29090 = NOVALUE;
L1C: 
L1B: 

    /** 	end while*/
    goto L4; // [774] 140
L15: 

    /** 	StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 	emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29091 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29091 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29092 = (int)*(((s1_ptr)_2)->base + _29091);
    _2 = (int)SEQ_PTR(_29092);
    _29093 = (int)*(((s1_ptr)_2)->base + 6);
    _29092 = NOVALUE;
    Ref(_29093);
    _37emit_temp(_29093, 1);
    _29093 = NOVALUE;

    /** 	flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** end procedure*/
    DeRef(_tok_57124);
    _29016 = NOVALUE;
    DeRef(_29022);
    _29022 = NOVALUE;
    _29066 = NOVALUE;
    return;
    ;
}


void _30Fallthru_statement()
{
    int _29094 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not in_switch() then*/
    _29094 = _30in_switch();
    if (IS_ATOM_INT(_29094)) {
        if (_29094 != 0){
            DeRef(_29094);
            _29094 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    else {
        if (DBL_PTR(_29094)->dbl != 0.0){
            DeRef(_29094);
            _29094 = NOVALUE;
            goto L1; // [6] 17
        }
    }
    DeRef(_29094);
    _29094 = NOVALUE;

    /** 		CompileErr( 22 )*/
    RefDS(_21829);
    _43CompileErr(22, _21829, 0);
L1: 

    /** 	tok_match( CASE )*/
    _30tok_match(186, 0);

    /** 	fallthru_case = 1*/
    _30fallthru_case_57120 = 1;

    /** 	Case_statement()*/
    _30Case_statement();

    /** end procedure*/
    return;
    ;
}


void _30update_translator_info(int _sym_57324, int _all_ints_57325, int _has_integer_57326, int _has_atom_57327, int _has_sequence_57328)
{
    int _29119 = NOVALUE;
    int _29117 = NOVALUE;
    int _29115 = NOVALUE;
    int _29113 = NOVALUE;
    int _29111 = NOVALUE;
    int _29110 = NOVALUE;
    int _29108 = NOVALUE;
    int _29106 = NOVALUE;
    int _29105 = NOVALUE;
    int _29104 = NOVALUE;
    int _29103 = NOVALUE;
    int _29102 = NOVALUE;
    int _29100 = NOVALUE;
    int _29098 = NOVALUE;
    int _29096 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	SymTab[sym][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _29096 = NOVALUE;

    /** 	SymTab[sym][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29098 = NOVALUE;

    /** 	SymTab[sym][S_SEQ_LEN] = length( SymTab[sym][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29102 = (int)*(((s1_ptr)_2)->base + _sym_57324);
    _2 = (int)SEQ_PTR(_29102);
    _29103 = (int)*(((s1_ptr)_2)->base + 1);
    _29102 = NOVALUE;
    if (IS_SEQUENCE(_29103)){
            _29104 = SEQ_PTR(_29103)->length;
    }
    else {
        _29104 = 1;
    }
    _29103 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29104;
    if( _1 != _29104 ){
        DeRef(_1);
    }
    _29104 = NOVALUE;
    _29100 = NOVALUE;

    /** 	if SymTab[sym][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29105 = (int)*(((s1_ptr)_2)->base + _sym_57324);
    _2 = (int)SEQ_PTR(_29105);
    _29106 = (int)*(((s1_ptr)_2)->base + 32);
    _29105 = NOVALUE;
    if (binary_op_a(LESSEQ, _29106, 0)){
        _29106 = NOVALUE;
        goto L1; // [89] 198
    }
    _29106 = NOVALUE;

    /** 		if all_ints then*/
    if (_all_ints_57325 == 0)
    {
        goto L2; // [95] 118
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29108 = NOVALUE;
    goto L3; // [115] 216
L2: 

    /** 		elsif has_atom + has_sequence + has_integer > 1 then*/
    _29110 = _has_atom_57327 + _has_sequence_57328;
    if ((long)((unsigned long)_29110 + (unsigned long)HIGH_BITS) >= 0) 
    _29110 = NewDouble((double)_29110);
    if (IS_ATOM_INT(_29110)) {
        _29111 = _29110 + _has_integer_57326;
        if ((long)((unsigned long)_29111 + (unsigned long)HIGH_BITS) >= 0) 
        _29111 = NewDouble((double)_29111);
    }
    else {
        _29111 = NewDouble(DBL_PTR(_29110)->dbl + (double)_has_integer_57326);
    }
    DeRef(_29110);
    _29110 = NOVALUE;
    if (binary_op_a(LESSEQ, _29111, 1)){
        DeRef(_29111);
        _29111 = NOVALUE;
        goto L4; // [128] 152
    }
    DeRef(_29111);
    _29111 = NOVALUE;

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29113 = NOVALUE;
    goto L3; // [149] 216
L4: 

    /** 		elsif has_atom then*/
    if (_has_atom_57327 == 0)
    {
        goto L5; // [154] 177
    }
    else{
    }

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_ATOM*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29115 = NOVALUE;
    goto L3; // [174] 216
L5: 

    /** 			SymTab[sym][S_SEQ_ELEM] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _29117 = NOVALUE;
    goto L3; // [195] 216
L1: 

    /** 		SymTab[sym][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_57324 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29119 = NOVALUE;
L3: 

    /** end procedure*/
    _29103 = NOVALUE;
    return;
    ;
}


void _30optimize_switch(int _switch_pc_57389, int _else_bp_57390, int _cases_57391, int _jump_table_57392)
{
    int _values_57393 = NOVALUE;
    int _min_57397 = NOVALUE;
    int _max_57399 = NOVALUE;
    int _all_ints_57401 = NOVALUE;
    int _has_integer_57402 = NOVALUE;
    int _has_atom_57403 = NOVALUE;
    int _has_sequence_57404 = NOVALUE;
    int _has_unassigned_57405 = NOVALUE;
    int _has_fwdref_57406 = NOVALUE;
    int _sym_57413 = NOVALUE;
    int _sign_57415 = NOVALUE;
    int _else_target_57479 = NOVALUE;
    int _opcode_57482 = NOVALUE;
    int _delta_57488 = NOVALUE;
    int _jump_57498 = NOVALUE;
    int _switch_table_57502 = NOVALUE;
    int _offset_57505 = NOVALUE;
    int _29197 = NOVALUE;
    int _29196 = NOVALUE;
    int _29195 = NOVALUE;
    int _29194 = NOVALUE;
    int _29192 = NOVALUE;
    int _29190 = NOVALUE;
    int _29187 = NOVALUE;
    int _29186 = NOVALUE;
    int _29185 = NOVALUE;
    int _29184 = NOVALUE;
    int _29183 = NOVALUE;
    int _29182 = NOVALUE;
    int _29181 = NOVALUE;
    int _29178 = NOVALUE;
    int _29176 = NOVALUE;
    int _29175 = NOVALUE;
    int _29174 = NOVALUE;
    int _29173 = NOVALUE;
    int _29172 = NOVALUE;
    int _29171 = NOVALUE;
    int _29170 = NOVALUE;
    int _29166 = NOVALUE;
    int _29165 = NOVALUE;
    int _29163 = NOVALUE;
    int _29162 = NOVALUE;
    int _29161 = NOVALUE;
    int _29160 = NOVALUE;
    int _29159 = NOVALUE;
    int _29158 = NOVALUE;
    int _29157 = NOVALUE;
    int _29156 = NOVALUE;
    int _29155 = NOVALUE;
    int _29154 = NOVALUE;
    int _29152 = NOVALUE;
    int _29151 = NOVALUE;
    int _29147 = NOVALUE;
    int _29144 = NOVALUE;
    int _29143 = NOVALUE;
    int _29142 = NOVALUE;
    int _29140 = NOVALUE;
    int _29139 = NOVALUE;
    int _29138 = NOVALUE;
    int _29137 = NOVALUE;
    int _29136 = NOVALUE;
    int _29134 = NOVALUE;
    int _29133 = NOVALUE;
    int _29132 = NOVALUE;
    int _29128 = NOVALUE;
    int _29127 = NOVALUE;
    int _29126 = NOVALUE;
    int _29122 = NOVALUE;
    int _29121 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29121 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29121 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29122 = (int)*(((s1_ptr)_2)->base + _29121);
    DeRef(_values_57393);
    _2 = (int)SEQ_PTR(_29122);
    _values_57393 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57393);
    _29122 = NOVALUE;

    /** 	atom min =  1e+300*/
    RefDS(_29124);
    DeRef(_min_57397);
    _min_57397 = _29124;

    /** 	atom max = -1e+300*/
    RefDS(_29125);
    DeRef(_max_57399);
    _max_57399 = _29125;

    /** 	integer all_ints = 1*/
    _all_ints_57401 = 1;

    /** 	integer has_integer    = 0*/
    _has_integer_57402 = 0;

    /** 	integer has_atom       = 0*/
    _has_atom_57403 = 0;

    /** 	integer has_sequence   = 0*/
    _has_sequence_57404 = 0;

    /** 	integer has_unassigned = 0*/
    _has_unassigned_57405 = 0;

    /** 	integer has_fwdref     = 0*/
    _has_fwdref_57406 = 0;

    /** 	for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57393)){
            _29126 = SEQ_PTR(_values_57393)->length;
    }
    else {
        _29126 = 1;
    }
    {
        int _i_57408;
        _i_57408 = 1;
L1: 
        if (_i_57408 > _29126){
            goto L2; // [71] 292
        }

        /** 		if sequence( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29127 = (int)*(((s1_ptr)_2)->base + _i_57408);
        _29128 = IS_SEQUENCE(_29127);
        _29127 = NOVALUE;
        if (_29128 == 0)
        {
            _29128 = NOVALUE;
            goto L3; // [87] 100
        }
        else{
            _29128 = NOVALUE;
        }

        /** 			has_fwdref = 1*/
        _has_fwdref_57406 = 1;

        /** 			exit*/
        goto L2; // [97] 292
L3: 

        /** 		integer sym = values[i]*/
        _2 = (int)SEQ_PTR(_values_57393);
        _sym_57413 = (int)*(((s1_ptr)_2)->base + _i_57408);
        if (!IS_ATOM_INT(_sym_57413))
        _sym_57413 = (long)DBL_PTR(_sym_57413)->dbl;

        /** 		integer sign*/

        /** 		if sym < 0 then*/
        if (_sym_57413 >= 0)
        goto L4; // [110] 129

        /** 			sign = -1*/
        _sign_57415 = -1;

        /** 			sym = -sym*/
        _sym_57413 = - _sym_57413;
        goto L5; // [126] 135
L4: 

        /** 			sign = 1*/
        _sign_57415 = 1;
L5: 

        /** 		if not equal(SymTab[sym][S_OBJ], NOVALUE) then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _29132 = (int)*(((s1_ptr)_2)->base + _sym_57413);
        _2 = (int)SEQ_PTR(_29132);
        _29133 = (int)*(((s1_ptr)_2)->base + 1);
        _29132 = NOVALUE;
        if (_29133 == _12NOVALUE_11536)
        _29134 = 1;
        else if (IS_ATOM_INT(_29133) && IS_ATOM_INT(_12NOVALUE_11536))
        _29134 = 0;
        else
        _29134 = (compare(_29133, _12NOVALUE_11536) == 0);
        _29133 = NOVALUE;
        if (_29134 != 0)
        goto L6; // [155] 271
        _29134 = NOVALUE;

        /** 			values[i] = sign * SymTab[sym][S_OBJ]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _29136 = (int)*(((s1_ptr)_2)->base + _sym_57413);
        _2 = (int)SEQ_PTR(_29136);
        _29137 = (int)*(((s1_ptr)_2)->base + 1);
        _29136 = NOVALUE;
        if (IS_ATOM_INT(_29137)) {
            if (_sign_57415 == (short)_sign_57415 && _29137 <= INT15 && _29137 >= -INT15)
            _29138 = _sign_57415 * _29137;
            else
            _29138 = NewDouble(_sign_57415 * (double)_29137);
        }
        else {
            _29138 = binary_op(MULTIPLY, _sign_57415, _29137);
        }
        _29137 = NOVALUE;
        _2 = (int)SEQ_PTR(_values_57393);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _values_57393 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_57408);
        _1 = *(int *)_2;
        *(int *)_2 = _29138;
        if( _1 != _29138 ){
            DeRef(_1);
        }
        _29138 = NOVALUE;

        /** 			if not integer( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29139 = (int)*(((s1_ptr)_2)->base + _i_57408);
        if (IS_ATOM_INT(_29139))
        _29140 = 1;
        else if (IS_ATOM_DBL(_29139))
        _29140 = IS_ATOM_INT(DoubleToInt(_29139));
        else
        _29140 = 0;
        _29139 = NOVALUE;
        if (_29140 != 0)
        goto L7; // [191] 228
        _29140 = NOVALUE;

        /** 				all_ints = 0*/
        _all_ints_57401 = 0;

        /** 				if atom( values[i] ) then*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29142 = (int)*(((s1_ptr)_2)->base + _i_57408);
        _29143 = IS_ATOM(_29142);
        _29142 = NOVALUE;
        if (_29143 == 0)
        {
            _29143 = NOVALUE;
            goto L8; // [208] 219
        }
        else{
            _29143 = NOVALUE;
        }

        /** 					has_atom = 1*/
        _has_atom_57403 = 1;
        goto L9; // [216] 283
L8: 

        /** 					has_sequence = 1*/
        _has_sequence_57404 = 1;
        goto L9; // [225] 283
L7: 

        /** 				has_integer = 1*/
        _has_integer_57402 = 1;

        /** 				if values[i] < min then*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29144 = (int)*(((s1_ptr)_2)->base + _i_57408);
        if (binary_op_a(GREATEREQ, _29144, _min_57397)){
            _29144 = NOVALUE;
            goto LA; // [239] 250
        }
        _29144 = NOVALUE;

        /** 					min = values[i]*/
        DeRef(_min_57397);
        _2 = (int)SEQ_PTR(_values_57393);
        _min_57397 = (int)*(((s1_ptr)_2)->base + _i_57408);
        Ref(_min_57397);
LA: 

        /** 				if values[i] > max then*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29147 = (int)*(((s1_ptr)_2)->base + _i_57408);
        if (binary_op_a(LESSEQ, _29147, _max_57399)){
            _29147 = NOVALUE;
            goto L9; // [256] 283
        }
        _29147 = NOVALUE;

        /** 					max = values[i]*/
        DeRef(_max_57399);
        _2 = (int)SEQ_PTR(_values_57393);
        _max_57399 = (int)*(((s1_ptr)_2)->base + _i_57408);
        Ref(_max_57399);
        goto L9; // [268] 283
L6: 

        /** 			has_unassigned = 1*/
        _has_unassigned_57405 = 1;

        /** 			exit*/
        goto L2; // [280] 292
L9: 

        /** 	end for*/
        _i_57408 = _i_57408 + 1;
        goto L1; // [287] 78
L2: 
        ;
    }

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57405 != 0) {
        goto LB; // [294] 303
    }
    if (_has_fwdref_57406 == 0)
    {
        goto LC; // [299] 321
    }
    else{
    }
LB: 

    /** 		values = switch_stack[$][SWITCH_CASES]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29151 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29151 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29152 = (int)*(((s1_ptr)_2)->base + _29151);
    DeRef(_values_57393);
    _2 = (int)SEQ_PTR(_29152);
    _values_57393 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_values_57393);
    _29152 = NOVALUE;
LC: 

    /** 	if switch_stack[$][SWITCH_ELSE] then*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29154 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29154 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29155 = (int)*(((s1_ptr)_2)->base + _29154);
    _2 = (int)SEQ_PTR(_29155);
    _29156 = (int)*(((s1_ptr)_2)->base + 3);
    _29155 = NOVALUE;
    if (_29156 == 0) {
        _29156 = NOVALUE;
        goto LD; // [336] 363
    }
    else {
        if (!IS_ATOM_INT(_29156) && DBL_PTR(_29156)->dbl == 0.0){
            _29156 = NOVALUE;
            goto LD; // [336] 363
        }
        _29156 = NOVALUE;
    }
    _29156 = NOVALUE;

    /** 			Code[else_bp] = switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29157 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29157 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29158 = (int)*(((s1_ptr)_2)->base + _29157);
    _2 = (int)SEQ_PTR(_29158);
    _29159 = (int)*(((s1_ptr)_2)->base + 3);
    _29158 = NOVALUE;
    Ref(_29159);
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57390);
    _1 = *(int *)_2;
    *(int *)_2 = _29159;
    if( _1 != _29159 ){
        DeRef(_1);
    }
    _29159 = NOVALUE;
    goto LE; // [360] 387
LD: 

    /** 		Code[else_bp] = length(Code) + 1 + TRANSLATE*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29160 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29160 = 1;
    }
    _29161 = _29160 + 1;
    _29160 = NOVALUE;
    _29162 = _29161 + _12TRANSLATE_11319;
    _29161 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _else_bp_57390);
    _1 = *(int *)_2;
    *(int *)_2 = _29162;
    if( _1 != _29162 ){
        DeRef(_1);
    }
    _29162 = NOVALUE;
LE: 

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LF; // [391] 418
    }
    else{
    }

    /** 		SymTab[cases][S_OBJ] &= 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57391 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _29165 = (int)*(((s1_ptr)_2)->base + 1);
    _29163 = NOVALUE;
    if (IS_SEQUENCE(_29165) && IS_ATOM(0)) {
        Append(&_29166, _29165, 0);
    }
    else if (IS_ATOM(_29165) && IS_SEQUENCE(0)) {
    }
    else {
        Concat((object_ptr)&_29166, _29165, 0);
        _29165 = NOVALUE;
    }
    _29165 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29166;
    if( _1 != _29166 ){
        DeRef(_1);
    }
    _29166 = NOVALUE;
    _29163 = NOVALUE;
LF: 

    /** 	integer else_target = Code[else_bp]*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    _else_target_57479 = (int)*(((s1_ptr)_2)->base + _else_bp_57390);
    if (!IS_ATOM_INT(_else_target_57479)){
        _else_target_57479 = (long)DBL_PTR(_else_target_57479)->dbl;
    }

    /** 	integer opcode = SWITCH*/
    _opcode_57482 = 185;

    /** 	if has_unassigned or has_fwdref then*/
    if (_has_unassigned_57405 != 0) {
        goto L10; // [439] 448
    }
    if (_has_fwdref_57406 == 0)
    {
        goto L11; // [444] 460
    }
    else{
    }
L10: 

    /** 		opcode = SWITCH_RT*/
    _opcode_57482 = 202;
    goto L12; // [457] 630
L11: 

    /** 	elsif all_ints then*/
    if (_all_ints_57401 == 0)
    {
        goto L13; // [462] 627
    }
    else{
    }

    /** 		atom delta = max - min*/
    DeRef(_delta_57488);
    if (IS_ATOM_INT(_max_57399) && IS_ATOM_INT(_min_57397)) {
        _delta_57488 = _max_57399 - _min_57397;
        if ((long)((unsigned long)_delta_57488 +(unsigned long) HIGH_BITS) >= 0){
            _delta_57488 = NewDouble((double)_delta_57488);
        }
    }
    else {
        if (IS_ATOM_INT(_max_57399)) {
            _delta_57488 = NewDouble((double)_max_57399 - DBL_PTR(_min_57397)->dbl);
        }
        else {
            if (IS_ATOM_INT(_min_57397)) {
                _delta_57488 = NewDouble(DBL_PTR(_max_57399)->dbl - (double)_min_57397);
            }
            else
            _delta_57488 = NewDouble(DBL_PTR(_max_57399)->dbl - DBL_PTR(_min_57397)->dbl);
        }
    }

    /** 		if not TRANSLATE and  delta < 1024 and delta >= 0 then*/
    _29170 = (_12TRANSLATE_11319 == 0);
    if (_29170 == 0) {
        _29171 = 0;
        goto L14; // [478] 490
    }
    if (IS_ATOM_INT(_delta_57488)) {
        _29172 = (_delta_57488 < 1024);
    }
    else {
        _29172 = (DBL_PTR(_delta_57488)->dbl < (double)1024);
    }
    _29171 = (_29172 != 0);
L14: 
    if (_29171 == 0) {
        goto L15; // [490] 616
    }
    if (IS_ATOM_INT(_delta_57488)) {
        _29174 = (_delta_57488 >= 0);
    }
    else {
        _29174 = (DBL_PTR(_delta_57488)->dbl >= (double)0);
    }
    if (_29174 == 0)
    {
        DeRef(_29174);
        _29174 = NOVALUE;
        goto L15; // [499] 616
    }
    else{
        DeRef(_29174);
        _29174 = NOVALUE;
    }

    /** 			opcode = SWITCH_SPI*/
    _opcode_57482 = 192;

    /** 			sequence jump = switch_stack[$][SWITCH_JUMP_TABLE]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29175 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29175 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29176 = (int)*(((s1_ptr)_2)->base + _29175);
    DeRef(_jump_57498);
    _2 = (int)SEQ_PTR(_29176);
    _jump_57498 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_jump_57498);
    _29176 = NOVALUE;

    /** 			sequence switch_table = repeat( else_target, delta + 1 )*/
    if (IS_ATOM_INT(_delta_57488)) {
        _29178 = _delta_57488 + 1;
    }
    else
    _29178 = binary_op(PLUS, 1, _delta_57488);
    DeRef(_switch_table_57502);
    _switch_table_57502 = Repeat(_else_target_57479, _29178);
    DeRef(_29178);
    _29178 = NOVALUE;

    /** 			integer offset = min - 1*/
    if (IS_ATOM_INT(_min_57397)) {
        _offset_57505 = _min_57397 - 1;
    }
    else {
        _offset_57505 = NewDouble(DBL_PTR(_min_57397)->dbl - (double)1);
    }
    if (!IS_ATOM_INT(_offset_57505)) {
        _1 = (long)(DBL_PTR(_offset_57505)->dbl);
        DeRefDS(_offset_57505);
        _offset_57505 = _1;
    }

    /** 			for i = 1 to length( values ) do*/
    if (IS_SEQUENCE(_values_57393)){
            _29181 = SEQ_PTR(_values_57393)->length;
    }
    else {
        _29181 = 1;
    }
    {
        int _i_57508;
        _i_57508 = 1;
L16: 
        if (_i_57508 > _29181){
            goto L17; // [551] 583
        }

        /** 				switch_table[values[i] - offset] = jump[i]*/
        _2 = (int)SEQ_PTR(_values_57393);
        _29182 = (int)*(((s1_ptr)_2)->base + _i_57508);
        if (IS_ATOM_INT(_29182)) {
            _29183 = _29182 - _offset_57505;
            if ((long)((unsigned long)_29183 +(unsigned long) HIGH_BITS) >= 0){
                _29183 = NewDouble((double)_29183);
            }
        }
        else {
            _29183 = binary_op(MINUS, _29182, _offset_57505);
        }
        _29182 = NOVALUE;
        _2 = (int)SEQ_PTR(_jump_57498);
        _29184 = (int)*(((s1_ptr)_2)->base + _i_57508);
        Ref(_29184);
        _2 = (int)SEQ_PTR(_switch_table_57502);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _switch_table_57502 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29183))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29183)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _29183);
        _1 = *(int *)_2;
        *(int *)_2 = _29184;
        if( _1 != _29184 ){
            DeRef(_1);
        }
        _29184 = NOVALUE;

        /** 			end for*/
        _i_57508 = _i_57508 + 1;
        goto L16; // [578] 558
L17: 
        ;
    }

    /** 			Code[switch_pc + 2] = offset*/
    _29185 = _switch_pc_57389 + 2;
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29185);
    _1 = *(int *)_2;
    *(int *)_2 = _offset_57505;
    DeRef(_1);

    /** 			switch_stack[$][SWITCH_JUMP_TABLE] = switch_table*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29186 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29186 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29186 + ((s1_ptr)_2)->base);
    RefDS(_switch_table_57502);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_table_57502;
    DeRef(_1);
    _29187 = NOVALUE;
    DeRef(_jump_57498);
    _jump_57498 = NOVALUE;
    DeRefDS(_switch_table_57502);
    _switch_table_57502 = NOVALUE;
    goto L18; // [613] 626
L15: 

    /** 			opcode = SWITCH_I*/
    _opcode_57482 = 193;
L18: 
L13: 
    DeRef(_delta_57488);
    _delta_57488 = NOVALUE;
L12: 

    /** 	Code[switch_pc] = opcode*/
    _2 = (int)SEQ_PTR(_12Code_11771);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12Code_11771 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _switch_pc_57389);
    _1 = *(int *)_2;
    *(int *)_2 = _opcode_57482;
    DeRef(_1);

    /** 	if opcode != SWITCH_SPI then*/
    if (_opcode_57482 == 192)
    goto L19; // [642] 679

    /** 		SymTab[cases][S_OBJ] = values*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_cases_57391 + ((s1_ptr)_2)->base);
    RefDS(_values_57393);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _values_57393;
    DeRef(_1);
    _29190 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1A; // [665] 678
    }
    else{
    }

    /** 			update_translator_info( cases, all_ints, has_integer, has_atom, has_sequence )*/
    _30update_translator_info(_cases_57391, _all_ints_57401, _has_integer_57402, _has_atom_57403, _has_sequence_57404);
L1A: 
L19: 

    /** 	SymTab[jump_table][S_OBJ] = switch_stack[$][SWITCH_JUMP_TABLE] - switch_pc*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_jump_table_57392 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29194 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29194 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29195 = (int)*(((s1_ptr)_2)->base + _29194);
    _2 = (int)SEQ_PTR(_29195);
    _29196 = (int)*(((s1_ptr)_2)->base + 2);
    _29195 = NOVALUE;
    if (IS_ATOM_INT(_29196)) {
        _29197 = _29196 - _switch_pc_57389;
        if ((long)((unsigned long)_29197 +(unsigned long) HIGH_BITS) >= 0){
            _29197 = NewDouble((double)_29197);
        }
    }
    else {
        _29197 = binary_op(MINUS, _29196, _switch_pc_57389);
    }
    _29196 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _29197;
    if( _1 != _29197 ){
        DeRef(_1);
    }
    _29197 = NOVALUE;
    _29192 = NOVALUE;

    /** end procedure*/
    DeRef(_values_57393);
    DeRef(_min_57397);
    DeRef(_max_57399);
    DeRef(_29170);
    _29170 = NOVALUE;
    DeRef(_29172);
    _29172 = NOVALUE;
    DeRef(_29185);
    _29185 = NOVALUE;
    DeRef(_29183);
    _29183 = NOVALUE;
    return;
    ;
}


void _30Switch_statement()
{
    int _else_case_2__tmp_at250_57602 = NOVALUE;
    int _else_case_1__tmp_at250_57601 = NOVALUE;
    int _else_case_inlined_else_case_at_250_57600 = NOVALUE;
    int _break_base_57540 = NOVALUE;
    int _cases_57542 = NOVALUE;
    int _jump_table_57543 = NOVALUE;
    int _else_bp_57544 = NOVALUE;
    int _switch_pc_57545 = NOVALUE;
    int _t_57582 = NOVALUE;
    int _29228 = NOVALUE;
    int _29227 = NOVALUE;
    int _29226 = NOVALUE;
    int _29225 = NOVALUE;
    int _29224 = NOVALUE;
    int _29220 = NOVALUE;
    int _29216 = NOVALUE;
    int _29215 = NOVALUE;
    int _29213 = NOVALUE;
    int _29212 = NOVALUE;
    int _29210 = NOVALUE;
    int _29209 = NOVALUE;
    int _29207 = NOVALUE;
    int _29206 = NOVALUE;
    int _29205 = NOVALUE;
    int _29204 = NOVALUE;
    int _29203 = NOVALUE;
    int _29202 = NOVALUE;
    int _29200 = NOVALUE;
    int _29199 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer else_bp*/

    /** 	integer switch_pc*/

    /** 	push_switch()*/
    _30push_switch();

    /** 	break_base = length(break_list)*/
    if (IS_SEQUENCE(_30break_list_53703)){
            _break_base_57540 = SEQ_PTR(_30break_list_53703)->length;
    }
    else {
        _break_base_57540 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	switch_stack[$][SWITCH_VALUE] = Top()*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29199 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29199 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29199 + ((s1_ptr)_2)->base);
    _29202 = _37Top();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _29202;
    if( _1 != _29202 ){
        DeRef(_1);
    }
    _29202 = NOVALUE;
    _29200 = NOVALUE;

    /** 	clear_temp( switch_stack[$][SWITCH_VALUE] )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29203 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29203 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29204 = (int)*(((s1_ptr)_2)->base + _29203);
    _2 = (int)SEQ_PTR(_29204);
    _29205 = (int)*(((s1_ptr)_2)->base + 6);
    _29204 = NOVALUE;
    Ref(_29205);
    _37clear_temp(_29205);
    _29205 = NOVALUE;

    /** 	cases = NewStringSym( {-1, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _29206 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _29206 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = _29206;
    _29207 = MAKE_SEQ(_1);
    _29206 = NOVALUE;
    _cases_57542 = _52NewStringSym(_29207);
    _29207 = NOVALUE;
    if (!IS_ATOM_INT(_cases_57542)) {
        _1 = (long)(DBL_PTR(_cases_57542)->dbl);
        DeRefDS(_cases_57542);
        _cases_57542 = _1;
    }

    /** 	emit_opnd( cases )*/
    _37emit_opnd(_cases_57542);

    /** 	jump_table = NewStringSym( {-2, length(SymTab) } )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _29209 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _29209 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = _29209;
    _29210 = MAKE_SEQ(_1);
    _29209 = NOVALUE;
    _jump_table_57543 = _52NewStringSym(_29210);
    _29210 = NOVALUE;
    if (!IS_ATOM_INT(_jump_table_57543)) {
        _1 = (long)(DBL_PTR(_jump_table_57543)->dbl);
        DeRefDS(_jump_table_57543);
        _jump_table_57543 = _1;
    }

    /** 	emit_opnd( jump_table )*/
    _37emit_opnd(_jump_table_57543);

    /** 	if finish_block_header(SWITCH) then end if*/
    _29212 = _30finish_block_header(185);
    if (_29212 == 0) {
        DeRef(_29212);
        _29212 = NOVALUE;
        goto L1; // [109] 113
    }
    else {
        if (!IS_ATOM_INT(_29212) && DBL_PTR(_29212)->dbl == 0.0){
            DeRef(_29212);
            _29212 = NOVALUE;
            goto L1; // [109] 113
        }
        DeRef(_29212);
        _29212 = NOVALUE;
    }
    DeRef(_29212);
    _29212 = NOVALUE;
L1: 

    /** 	switch_pc = length(Code) + 1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29213 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29213 = 1;
    }
    _switch_pc_57545 = _29213 + 1;
    _29213 = NOVALUE;

    /** 	switch_stack[$][SWITCH_PC] = switch_pc*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29215 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29215 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30switch_stack_53919 = MAKE_SEQ(_2);
    }
    _3 = (int)(_29215 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _switch_pc_57545;
    DeRef(_1);
    _29216 = NOVALUE;

    /** 	emit_op(SWITCH)*/
    _37emit_op(185);

    /** 	emit_forward_addr()  -- the else*/
    _30emit_forward_addr();

    /** 	else_bp = length( Code )*/
    if (IS_SEQUENCE(_12Code_11771)){
            _else_bp_57544 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _else_bp_57544 = 1;
    }

    /** 	t = next_token()*/
    _0 = _t_57582;
    _t_57582 = _30next_token();
    DeRef(_0);

    /** 	if t[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_t_57582);
    _29220 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29220, 186)){
        _29220 = NOVALUE;
        goto L2; // [173] 188
    }
    _29220 = NOVALUE;

    /** 		Case_statement()*/
    _30Case_statement();

    /** 		Statement_list()*/
    _30Statement_list();
    goto L3; // [185] 194
L2: 

    /** 		putback(t)*/
    Ref(_t_57582);
    _30putback(_t_57582);
L3: 

    /** 	optimize_switch( switch_pc, else_bp, cases, jump_table )*/
    _30optimize_switch(_switch_pc_57545, _else_bp_57544, _cases_57542, _jump_table_57543);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(SWITCH, END)*/
    _30tok_match(185, 402);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L4; // [224] 235
    }
    else{
    }

    /** 		emit_op(NOPSWITCH)*/
    _37emit_op(187);
L4: 

    /** 	if not else_case() then*/

    /** 	return switch_stack[$][SWITCH_ELSE]*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _else_case_1__tmp_at250_57601 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _else_case_1__tmp_at250_57601 = 1;
    }
    DeRef(_else_case_2__tmp_at250_57602);
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _else_case_2__tmp_at250_57602 = (int)*(((s1_ptr)_2)->base + _else_case_1__tmp_at250_57601);
    RefDS(_else_case_2__tmp_at250_57602);
    DeRef(_else_case_inlined_else_case_at_250_57600);
    _2 = (int)SEQ_PTR(_else_case_2__tmp_at250_57602);
    _else_case_inlined_else_case_at_250_57600 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_else_case_inlined_else_case_at_250_57600);
    DeRef(_else_case_2__tmp_at250_57602);
    _else_case_2__tmp_at250_57602 = NOVALUE;
    if (IS_ATOM_INT(_else_case_inlined_else_case_at_250_57600)) {
        if (_else_case_inlined_else_case_at_250_57600 != 0){
            goto L5; // [255] 327
        }
    }
    else {
        if (DBL_PTR(_else_case_inlined_else_case_at_250_57600)->dbl != 0.0){
            goto L5; // [255] 327
        }
    }

    /** 		if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L6; // [262] 303

    /** 			StartSourceLine( TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 			emit_temp( switch_stack[$][SWITCH_VALUE], NEW_REFERENCE )*/
    if (IS_SEQUENCE(_30switch_stack_53919)){
            _29224 = SEQ_PTR(_30switch_stack_53919)->length;
    }
    else {
        _29224 = 1;
    }
    _2 = (int)SEQ_PTR(_30switch_stack_53919);
    _29225 = (int)*(((s1_ptr)_2)->base + _29224);
    _2 = (int)SEQ_PTR(_29225);
    _29226 = (int)*(((s1_ptr)_2)->base + 6);
    _29225 = NOVALUE;
    Ref(_29226);
    _37emit_temp(_29226, 1);
    _29226 = NOVALUE;

    /** 			flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);
L6: 

    /** 		Warning(221, no_case_else_warning_flag,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _29227 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_29227);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _29227;
    ((int *)_2)[2] = _12line_number_11683;
    _29228 = MAKE_SEQ(_1);
    _29227 = NOVALUE;
    _43Warning(221, 4096, _29228);
    _29228 = NOVALUE;
L5: 

    /** 	pop_switch( break_base )*/
    _30pop_switch(_break_base_57540);

    /** end procedure*/
    DeRef(_t_57582);
    return;
    ;
}


int _30get_private_uninitialized()
{
    int _uninitialized_57625 = NOVALUE;
    int _s_57631 = NOVALUE;
    int _pu_57637 = NOVALUE;
    int _29245 = NOVALUE;
    int _29243 = NOVALUE;
    int _29242 = NOVALUE;
    int _29241 = NOVALUE;
    int _29240 = NOVALUE;
    int _29239 = NOVALUE;
    int _29238 = NOVALUE;
    int _29237 = NOVALUE;
    int _29236 = NOVALUE;
    int _29235 = NOVALUE;
    int _29234 = NOVALUE;
    int _29233 = NOVALUE;
    int _29230 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = {}*/
    RefDS(_21829);
    DeRefi(_uninitialized_57625);
    _uninitialized_57625 = _21829;

    /** 	if CurrentSub != TopLevelSub then*/
    if (_12CurrentSub_11690 == _12TopLevelSub_11689)
    goto L1; // [14] 149

    /** 		symtab_pointer s = SymTab[CurrentSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29230 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_29230);
    _s_57631 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_57631)){
        _s_57631 = (long)DBL_PTR(_s_57631)->dbl;
    }
    _29230 = NOVALUE;

    /** 		sequence pu = { SC_PRIVATE, SC_UNDEFINED }*/
    DeRefi(_pu_57637);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 3;
    ((int *)_2)[2] = 9;
    _pu_57637 = MAKE_SEQ(_1);

    /** 		while s and find( SymTab[s][S_SCOPE], pu ) do*/
L2: 
    if (_s_57631 == 0) {
        goto L3; // [51] 148
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29234 = (int)*(((s1_ptr)_2)->base + _s_57631);
    _2 = (int)SEQ_PTR(_29234);
    _29235 = (int)*(((s1_ptr)_2)->base + 4);
    _29234 = NOVALUE;
    _29236 = find_from(_29235, _pu_57637, 1);
    _29235 = NOVALUE;
    if (_29236 == 0)
    {
        _29236 = NOVALUE;
        goto L3; // [73] 148
    }
    else{
        _29236 = NOVALUE;
    }

    /** 			if SymTab[s][S_SCOPE] = SC_PRIVATE and SymTab[s][S_INITLEVEL] = -1 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29237 = (int)*(((s1_ptr)_2)->base + _s_57631);
    _2 = (int)SEQ_PTR(_29237);
    _29238 = (int)*(((s1_ptr)_2)->base + 4);
    _29237 = NOVALUE;
    if (IS_ATOM_INT(_29238)) {
        _29239 = (_29238 == 3);
    }
    else {
        _29239 = binary_op(EQUALS, _29238, 3);
    }
    _29238 = NOVALUE;
    if (IS_ATOM_INT(_29239)) {
        if (_29239 == 0) {
            goto L4; // [96] 127
        }
    }
    else {
        if (DBL_PTR(_29239)->dbl == 0.0) {
            goto L4; // [96] 127
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29241 = (int)*(((s1_ptr)_2)->base + _s_57631);
    _2 = (int)SEQ_PTR(_29241);
    _29242 = (int)*(((s1_ptr)_2)->base + 14);
    _29241 = NOVALUE;
    if (IS_ATOM_INT(_29242)) {
        _29243 = (_29242 == -1);
    }
    else {
        _29243 = binary_op(EQUALS, _29242, -1);
    }
    _29242 = NOVALUE;
    if (_29243 == 0) {
        DeRef(_29243);
        _29243 = NOVALUE;
        goto L4; // [117] 127
    }
    else {
        if (!IS_ATOM_INT(_29243) && DBL_PTR(_29243)->dbl == 0.0){
            DeRef(_29243);
            _29243 = NOVALUE;
            goto L4; // [117] 127
        }
        DeRef(_29243);
        _29243 = NOVALUE;
    }
    DeRef(_29243);
    _29243 = NOVALUE;

    /** 				uninitialized &= s*/
    Append(&_uninitialized_57625, _uninitialized_57625, _s_57631);
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29245 = (int)*(((s1_ptr)_2)->base + _s_57631);
    _2 = (int)SEQ_PTR(_29245);
    _s_57631 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_57631)){
        _s_57631 = (long)DBL_PTR(_s_57631)->dbl;
    }
    _29245 = NOVALUE;

    /** 		end while*/
    goto L2; // [145] 51
L3: 
L1: 
    DeRefi(_pu_57637);
    _pu_57637 = NOVALUE;

    /** 	return uninitialized*/
    DeRef(_29239);
    _29239 = NOVALUE;
    return _uninitialized_57625;
    ;
}


void _30While_statement()
{
    int _bp1_57668 = NOVALUE;
    int _bp2_57669 = NOVALUE;
    int _exit_base_57670 = NOVALUE;
    int _next_base_57671 = NOVALUE;
    int _uninitialized_57672 = NOVALUE;
    int _temps_57742 = NOVALUE;
    int _29281 = NOVALUE;
    int _29280 = NOVALUE;
    int _29279 = NOVALUE;
    int _29275 = NOVALUE;
    int _29274 = NOVALUE;
    int _29272 = NOVALUE;
    int _29270 = NOVALUE;
    int _29269 = NOVALUE;
    int _29268 = NOVALUE;
    int _29264 = NOVALUE;
    int _29262 = NOVALUE;
    int _29260 = NOVALUE;
    int _29254 = NOVALUE;
    int _29252 = NOVALUE;
    int _29251 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_57672;
    _uninitialized_57672 = _30get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_57672);
    Append(&_30entry_stack_53712, _30entry_stack_53712, _uninitialized_57672);

    /** 	Start_block( WHILE )*/
    _65Start_block(47, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _exit_base_57670 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _exit_base_57670 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_53707)){
            _next_base_57671 = SEQ_PTR(_30continue_list_53707)->length;
    }
    else {
        _next_base_57671 = 1;
    }

    /** 	entry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29251 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29251 = 1;
    }
    _29252 = _29251 + 1;
    _29251 = NOVALUE;
    Append(&_30entry_addr_53709, _30entry_addr_53709, _29252);
    _29252 = NOVALUE;

    /** 	emit_op(NOP2) -- Entry_statement may patch this later*/
    _37emit_op(110);

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [71] 82
    }
    else{
    }

    /** 		emit_op(NOPWHILE)*/
    _37emit_op(158);
L1: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29254 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29254 = 1;
    }
    _bp1_57668 = _29254 + 1;
    _29254 = NOVALUE;

    /** 	continue_addr &= bp1*/
    Append(&_30continue_addr_53710, _30continue_addr_53710, _bp1_57668);

    /** 	short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_53687 = _9FALSE_429;

    /** 	SC1_type = 0*/
    _30SC1_type_53690 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	optimized_while = FALSE*/
    _37optimized_while_49793 = _9FALSE_429;

    /** 	emit_op(WHILE)*/
    _37emit_op(47);

    /** 	short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 	if not optimized_while then*/
    if (_37optimized_while_49793 != 0)
    goto L2; // [153] 174

    /** 		bp2 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29260 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29260 = 1;
    }
    _bp2_57669 = _29260 + 1;
    _29260 = NOVALUE;

    /** 		emit_forward_addr() -- will be patched*/
    _30emit_forward_addr();
    goto L3; // [171] 180
L2: 

    /** 		bp2 = 0*/
    _bp2_57669 = 0;
L3: 

    /** 	if finish_block_header(WHILE)=0 then*/
    _29262 = _30finish_block_header(47);
    if (binary_op_a(NOTEQ, _29262, 0)){
        DeRef(_29262);
        _29262 = NOVALUE;
        goto L4; // [188] 204
    }
    DeRef(_29262);
    _29262 = NOVALUE;

    /** 		entry_addr[$]=-1*/
    if (IS_SEQUENCE(_30entry_addr_53709)){
            _29264 = SEQ_PTR(_30entry_addr_53709)->length;
    }
    else {
        _29264 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_53709);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30entry_addr_53709 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29264);
    *(int *)_2 = -1;
L4: 

    /** 	loop_stack &= WHILE*/
    Append(&_30loop_stack_53719, _30loop_stack_53719, 47);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _exit_base_57670 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _exit_base_57670 = 1;
    }

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_53690 != 9)
    goto L5; // [227] 280

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29268 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_29268 +(unsigned long) HIGH_BITS) >= 0){
        _29268 = NewDouble((double)_29268);
    }
    _37backpatch(_29268, 147);
    _29268 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [249] 260
    }
    else{
    }

    /** 			emit_op(NOP1)*/
    _37emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29269 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29269 = 1;
    }
    _29270 = _29269 + 1;
    _29269 = NOVALUE;
    _37backpatch(_30SC1_patch_53689, _29270);
    _29270 = NOVALUE;
    goto L7; // [277] 331
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_53690 != 8)
    goto L8; // [286] 330

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29272 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_29272 +(unsigned long) HIGH_BITS) >= 0){
        _29272 = NewDouble((double)_29272);
    }
    _37backpatch(_29272, 146);
    _29272 = NOVALUE;

    /** 		AppendXList(SC1_patch)*/

    /** 	exit_list = append(exit_list, addr)*/
    Append(&_30exit_list_53705, _30exit_list_53705, _30SC1_patch_53689);

    /** end procedure*/
    goto L9; // [318] 321
L9: 

    /** 		exit_delay &= 1*/
    Append(&_30exit_delay_53706, _30exit_delay_53706, 1);
L8: 
L7: 

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29274 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29274 = 1;
    }
    _29275 = _29274 + 1;
    _29274 = NOVALUE;
    Append(&_30retry_addr_53711, _30retry_addr_53711, _29275);
    _29275 = NOVALUE;

    /** 	sequence temps = pop_temps()*/
    _0 = _temps_57742;
    _temps_57742 = _37pop_temps();
    DeRef(_0);

    /** 	push_temps( temps )*/
    RefDS(_temps_57742);
    _37push_temps(_temps_57742);

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_57671);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(WHILE, END)*/
    _30tok_match(47, 402);

    /** 	End_block( WHILE )*/
    _65End_block(47);

    /** 	StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 	emit_op(ENDWHILE)*/
    _37emit_op(22);

    /** 	emit_addr(bp1)*/
    _37emit_addr(_bp1_57668);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LA; // [419] 430
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
LA: 

    /** 	if bp2 != 0 then*/
    if (_bp2_57669 == 0)
    goto LB; // [434] 454

    /** 		backpatch(bp2, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29279 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29279 = 1;
    }
    _29280 = _29279 + 1;
    _29279 = NOVALUE;
    _37backpatch(_bp2_57669, _29280);
    _29280 = NOVALUE;
LB: 

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_57670);

    /** 	entry_stack = remove( entry_stack, length( entry_stack ) )*/
    if (IS_SEQUENCE(_30entry_stack_53712)){
            _29281 = SEQ_PTR(_30entry_stack_53712)->length;
    }
    else {
        _29281 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_30entry_stack_53712);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_29281)) ? _29281 : (long)(DBL_PTR(_29281)->dbl);
        int stop = (IS_ATOM_INT(_29281)) ? _29281 : (long)(DBL_PTR(_29281)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_30entry_stack_53712), start, &_30entry_stack_53712 );
            }
            else Tail(SEQ_PTR(_30entry_stack_53712), stop+1, &_30entry_stack_53712);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_30entry_stack_53712), start, &_30entry_stack_53712);
        }
        else {
            assign_slice_seq = &assign_space;
            _30entry_stack_53712 = Remove_elements(start, stop, (SEQ_PTR(_30entry_stack_53712)->ref == 1));
        }
    }
    _29281 = NOVALUE;
    _29281 = NOVALUE;

    /** 	push_temps( temps )*/
    RefDS(_temps_57742);
    _37push_temps(_temps_57742);

    /** end procedure*/
    DeRef(_uninitialized_57672);
    DeRefDS(_temps_57742);
    return;
    ;
}


void _30Loop_statement()
{
    int _bp1_57772 = NOVALUE;
    int _exit_base_57773 = NOVALUE;
    int _next_base_57774 = NOVALUE;
    int _t_57776 = NOVALUE;
    int _uninitialized_57779 = NOVALUE;
    int _29305 = NOVALUE;
    int _29303 = NOVALUE;
    int _29302 = NOVALUE;
    int _29301 = NOVALUE;
    int _29295 = NOVALUE;
    int _29294 = NOVALUE;
    int _29292 = NOVALUE;
    int _29289 = NOVALUE;
    int _29288 = NOVALUE;
    int _29287 = NOVALUE;
    int _0, _1, _2;
    

    /** 	Start_block( LOOP )*/
    _65Start_block(422, 0);

    /** 	sequence uninitialized = get_private_uninitialized()*/
    _0 = _uninitialized_57779;
    _uninitialized_57779 = _30get_private_uninitialized();
    DeRef(_0);

    /** 	entry_stack = append( entry_stack, uninitialized )*/
    RefDS(_uninitialized_57779);
    Append(&_30entry_stack_53712, _30entry_stack_53712, _uninitialized_57779);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _exit_base_57773 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _exit_base_57773 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_53707)){
            _next_base_57774 = SEQ_PTR(_30continue_list_53707)->length;
    }
    else {
        _next_base_57774 = 1;
    }

    /** 	emit_op(NOP2) -- Entry_statement() may patch this*/
    _37emit_op(110);

    /** 	emit_addr(0)*/
    _37emit_addr(0);

    /** 	if finish_block_header(LOOP) then*/
    _29287 = _30finish_block_header(422);
    if (_29287 == 0) {
        DeRef(_29287);
        _29287 = NOVALUE;
        goto L1; // [58] 81
    }
    else {
        if (!IS_ATOM_INT(_29287) && DBL_PTR(_29287)->dbl == 0.0){
            DeRef(_29287);
            _29287 = NOVALUE;
            goto L1; // [58] 81
        }
        DeRef(_29287);
        _29287 = NOVALUE;
    }
    DeRef(_29287);
    _29287 = NOVALUE;

    /** 	    entry_addr &= length(Code)-1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29288 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29288 = 1;
    }
    _29289 = _29288 - 1;
    _29288 = NOVALUE;
    Append(&_30entry_addr_53709, _30entry_addr_53709, _29289);
    _29289 = NOVALUE;
    goto L2; // [78] 90
L1: 

    /** 		entry_addr &= -1*/
    Append(&_30entry_addr_53709, _30entry_addr_53709, -1);
L2: 

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [94] 105
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L3: 

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29292 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29292 = 1;
    }
    _bp1_57772 = _29292 + 1;
    _29292 = NOVALUE;

    /** 	retry_addr &= length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29294 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29294 = 1;
    }
    _29295 = _29294 + 1;
    _29294 = NOVALUE;
    Append(&_30retry_addr_53711, _30retry_addr_53711, _29295);
    _29295 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_30continue_addr_53710, _30continue_addr_53710, 0);

    /** 	loop_stack &= LOOP*/
    Append(&_30loop_stack_53719, _30loop_stack_53719, 422);

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	End_block( LOOP )*/
    _65End_block(422);

    /** 	tok_match(UNTIL)*/
    _30tok_match(423, 0);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L4; // [174] 185
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L4: 

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_57774);

    /** 	StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 	short_circuit += 1*/
    _30short_circuit_53685 = _30short_circuit_53685 + 1;

    /** 	short_circuit_B = FALSE*/
    _30short_circuit_B_53687 = _9FALSE_429;

    /** 	SC1_type = 0*/
    _30SC1_type_53690 = 0;

    /** 	Expr()*/
    _30Expr();

    /** 	if SC1_type = OR then*/
    if (_30SC1_type_53690 != 9)
    goto L5; // [229] 282

    /** 		backpatch(SC1_patch-3, SC1_OR_IF)*/
    _29301 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_29301 +(unsigned long) HIGH_BITS) >= 0){
        _29301 = NewDouble((double)_29301);
    }
    _37backpatch(_29301, 147);
    _29301 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [251] 262
    }
    else{
    }

    /** 		    emit_op(NOP1)  -- to get label here*/
    _37emit_op(159);
L6: 

    /** 		backpatch(SC1_patch, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29302 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29302 = 1;
    }
    _29303 = _29302 + 1;
    _29302 = NOVALUE;
    _37backpatch(_30SC1_patch_53689, _29303);
    _29303 = NOVALUE;
    goto L7; // [279] 308
L5: 

    /** 	elsif SC1_type = AND then*/
    if (_30SC1_type_53690 != 8)
    goto L8; // [288] 307

    /** 		backpatch(SC1_patch-3, SC1_AND_IF)*/
    _29305 = _30SC1_patch_53689 - 3;
    if ((long)((unsigned long)_29305 +(unsigned long) HIGH_BITS) >= 0){
        _29305 = NewDouble((double)_29305);
    }
    _37backpatch(_29305, 146);
    _29305 = NOVALUE;
L8: 
L7: 

    /** 	short_circuit -= 1*/
    _30short_circuit_53685 = _30short_circuit_53685 - 1;

    /** 	emit_op(IF)*/
    _37emit_op(20);

    /** 	emit_addr(bp1)*/
    _37emit_addr(_bp1_57772);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L9; // [332] 343
    }
    else{
    }

    /** 		emit_op(NOP1)*/
    _37emit_op(159);
L9: 

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_57773);

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(LOOP, END)*/
    _30tok_match(422, 402);

    /** end procedure*/
    DeRef(_uninitialized_57779);
    return;
    ;
}


void _30Ifdef_statement()
{
    int _option_57858 = NOVALUE;
    int _matched_57859 = NOVALUE;
    int _has_matched_57860 = NOVALUE;
    int _in_matched_57861 = NOVALUE;
    int _dead_ifdef_57862 = NOVALUE;
    int _in_elsedef_57863 = NOVALUE;
    int _tok_57865 = NOVALUE;
    int _keyw_57866 = NOVALUE;
    int _parser_id_57870 = NOVALUE;
    int _negate_57886 = NOVALUE;
    int _conjunction_57887 = NOVALUE;
    int _at_start_57888 = NOVALUE;
    int _prev_conj_57889 = NOVALUE;
    int _this_matched_57962 = NOVALUE;
    int _gotword_57978 = NOVALUE;
    int _gotthen_57979 = NOVALUE;
    int _if_lvl_57980 = NOVALUE;
    int _29422 = NOVALUE;
    int _29421 = NOVALUE;
    int _29417 = NOVALUE;
    int _29415 = NOVALUE;
    int _29412 = NOVALUE;
    int _29410 = NOVALUE;
    int _29409 = NOVALUE;
    int _29405 = NOVALUE;
    int _29402 = NOVALUE;
    int _29399 = NOVALUE;
    int _29395 = NOVALUE;
    int _29393 = NOVALUE;
    int _29392 = NOVALUE;
    int _29391 = NOVALUE;
    int _29390 = NOVALUE;
    int _29389 = NOVALUE;
    int _29388 = NOVALUE;
    int _29387 = NOVALUE;
    int _29383 = NOVALUE;
    int _29380 = NOVALUE;
    int _29379 = NOVALUE;
    int _29378 = NOVALUE;
    int _29374 = NOVALUE;
    int _29373 = NOVALUE;
    int _29372 = NOVALUE;
    int _29369 = NOVALUE;
    int _29366 = NOVALUE;
    int _29365 = NOVALUE;
    int _29364 = NOVALUE;
    int _29362 = NOVALUE;
    int _29351 = NOVALUE;
    int _29349 = NOVALUE;
    int _29348 = NOVALUE;
    int _29347 = NOVALUE;
    int _29346 = NOVALUE;
    int _29345 = NOVALUE;
    int _29344 = NOVALUE;
    int _29343 = NOVALUE;
    int _29340 = NOVALUE;
    int _29339 = NOVALUE;
    int _29337 = NOVALUE;
    int _29335 = NOVALUE;
    int _29334 = NOVALUE;
    int _29332 = NOVALUE;
    int _29330 = NOVALUE;
    int _29329 = NOVALUE;
    int _29327 = NOVALUE;
    int _29326 = NOVALUE;
    int _29325 = NOVALUE;
    int _29322 = NOVALUE;
    int _29320 = NOVALUE;
    int _29317 = NOVALUE;
    int _29316 = NOVALUE;
    int _29315 = NOVALUE;
    int _29313 = NOVALUE;
    int _29311 = NOVALUE;
    int _29310 = NOVALUE;
    int _29309 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer matched = 0, has_matched = 0,  in_matched = 0, dead_ifdef = 0, in_elsedef = 0*/
    _matched_57859 = 0;
    _has_matched_57860 = 0;
    _in_matched_57861 = 0;
    _dead_ifdef_57862 = 0;
    _in_elsedef_57863 = 0;

    /** 	sequence keyw ="ifdef"*/
    RefDS(_26073);
    DeRefi(_keyw_57866);
    _keyw_57866 = _26073;

    /** 	live_ifdef += 1*/
    _30live_ifdef_57854 = _30live_ifdef_57854 + 1;

    /** 	ifdef_lineno &= line_number*/
    Append(&_30ifdef_lineno_57855, _30ifdef_lineno_57855, _12line_number_11683);

    /** 	integer parser_id*/

    /** 	if CurrentSub != TopLevelSub or length(if_labels) or length(loop_labels) then*/
    _29309 = (_12CurrentSub_11690 != _12TopLevelSub_11689);
    if (_29309 != 0) {
        _29310 = 1;
        goto L1; // [55] 68
    }
    if (IS_SEQUENCE(_30if_labels_53714)){
            _29311 = SEQ_PTR(_30if_labels_53714)->length;
    }
    else {
        _29311 = 1;
    }
    _29310 = (_29311 != 0);
L1: 
    if (_29310 != 0) {
        goto L2; // [68] 82
    }
    if (IS_SEQUENCE(_30loop_labels_53713)){
            _29313 = SEQ_PTR(_30loop_labels_53713)->length;
    }
    else {
        _29313 = 1;
    }
    if (_29313 == 0)
    {
        _29313 = NOVALUE;
        goto L3; // [78] 92
    }
    else{
        _29313 = NOVALUE;
    }
L2: 

    /** 		parser_id = forward_Statement_list*/
    _parser_id_57870 = _30forward_Statement_list_56706;
    goto L4; // [89] 100
L3: 

    /** 		parser_id = top_level_parser*/
    _parser_id_57870 = _30top_level_parser_57853;
L4: 

    /** 	while 1 label "top" do*/
L5: 

    /** 		if matched = 0 and in_elsedef = 0 then*/
    _29315 = (_matched_57859 == 0);
    if (_29315 == 0) {
        goto L6; // [111] 632
    }
    _29317 = (_in_elsedef_57863 == 0);
    if (_29317 == 0)
    {
        DeRef(_29317);
        _29317 = NOVALUE;
        goto L6; // [120] 632
    }
    else{
        DeRef(_29317);
        _29317 = NOVALUE;
    }

    /** 			integer negate = 0, conjunction = 0*/
    _negate_57886 = 0;
    _conjunction_57887 = 0;

    /** 			integer at_start = 1*/
    _at_start_57888 = 1;

    /** 			sequence prev_conj = ""*/
    RefDS(_21829);
    DeRef(_prev_conj_57889);
    _prev_conj_57889 = _21829;

    /** 			while 1 label "deflist" do*/
L7: 

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_57858;
    _option_57858 = _60StringToken(_5);
    DeRef(_0);

    /** 				if equal(option, "then") then*/
    if (_option_57858 == _26140)
    _29320 = 1;
    else if (IS_ATOM_INT(_option_57858) && IS_ATOM_INT(_26140))
    _29320 = 0;
    else
    _29320 = (compare(_option_57858, _26140) == 0);
    if (_29320 == 0)
    {
        _29320 = NOVALUE;
        goto L8; // [162] 234
    }
    else{
        _29320 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57888 != 1)
    goto L9; // [167] 185

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29322 = MAKE_SEQ(_1);
    _43CompileErr(6, _29322, 0);
    _29322 = NOVALUE;
    goto LA; // [182] 518
L9: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57887 != 0)
    goto LB; // [187] 219

    /** 						if negate = 0 then*/
    if (_negate_57886 != 0)
    goto LC; // [193] 204

    /** 							exit "deflist"*/
    goto LD; // [199] 606
    goto LA; // [201] 518
LC: 

    /** 							CompileErr(11, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29325 = MAKE_SEQ(_1);
    _43CompileErr(11, _29325, 0);
    _29325 = NOVALUE;
    goto LA; // [216] 518
LB: 

    /** 						CompileErr(8, {keyw, prev_conj})*/
    RefDS(_prev_conj_57889);
    RefDS(_keyw_57866);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57866;
    ((int *)_2)[2] = _prev_conj_57889;
    _29326 = MAKE_SEQ(_1);
    _43CompileErr(8, _29326, 0);
    _29326 = NOVALUE;
    goto LA; // [231] 518
L8: 

    /** 				elsif equal(option, "not") then*/
    if (_option_57858 == _26101)
    _29327 = 1;
    else if (IS_ATOM_INT(_option_57858) && IS_ATOM_INT(_26101))
    _29327 = 0;
    else
    _29327 = (compare(_option_57858, _26101) == 0);
    if (_29327 == 0)
    {
        _29327 = NOVALUE;
        goto LE; // [240] 276
    }
    else{
        _29327 = NOVALUE;
    }

    /** 					if negate = 0 then*/
    if (_negate_57886 != 0)
    goto LF; // [245] 261

    /** 						negate = 1*/
    _negate_57886 = 1;

    /** 						continue "deflist"*/
    goto L7; // [256] 148
    goto LA; // [258] 518
LF: 

    /** 						CompileErr(7, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29329 = MAKE_SEQ(_1);
    _43CompileErr(7, _29329, 0);
    _29329 = NOVALUE;
    goto LA; // [273] 518
LE: 

    /** 				elsif equal(option, "and") then*/
    if (_option_57858 == _26005)
    _29330 = 1;
    else if (IS_ATOM_INT(_option_57858) && IS_ATOM_INT(_26005))
    _29330 = 0;
    else
    _29330 = (compare(_option_57858, _26005) == 0);
    if (_29330 == 0)
    {
        _29330 = NOVALUE;
        goto L10; // [282] 345
    }
    else{
        _29330 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57888 != 1)
    goto L11; // [287] 305

    /** 						CompileErr(2, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29332 = MAKE_SEQ(_1);
    _43CompileErr(2, _29332, 0);
    _29332 = NOVALUE;
    goto LA; // [302] 518
L11: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57887 != 0)
    goto L12; // [307] 330

    /** 						conjunction = 1*/
    _conjunction_57887 = 1;

    /** 						prev_conj = option*/
    RefDS(_option_57858);
    DeRef(_prev_conj_57889);
    _prev_conj_57889 = _option_57858;

    /** 						continue "deflist"*/
    goto L7; // [325] 148
    goto LA; // [327] 518
L12: 

    /** 						CompileErr(10,{keyw,prev_conj})*/
    RefDS(_prev_conj_57889);
    RefDS(_keyw_57866);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57866;
    ((int *)_2)[2] = _prev_conj_57889;
    _29334 = MAKE_SEQ(_1);
    _43CompileErr(10, _29334, 0);
    _29334 = NOVALUE;
    goto LA; // [342] 518
L10: 

    /** 				elsif equal(option, "or") then*/
    if (_option_57858 == _26105)
    _29335 = 1;
    else if (IS_ATOM_INT(_option_57858) && IS_ATOM_INT(_26105))
    _29335 = 0;
    else
    _29335 = (compare(_option_57858, _26105) == 0);
    if (_29335 == 0)
    {
        _29335 = NOVALUE;
        goto L13; // [351] 414
    }
    else{
        _29335 = NOVALUE;
    }

    /** 					if at_start = 1 then*/
    if (_at_start_57888 != 1)
    goto L14; // [356] 374

    /** 						CompileErr(6, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29337 = MAKE_SEQ(_1);
    _43CompileErr(6, _29337, 0);
    _29337 = NOVALUE;
    goto LA; // [371] 518
L14: 

    /** 					elsif conjunction = 0 then*/
    if (_conjunction_57887 != 0)
    goto L15; // [376] 399

    /** 						conjunction = 2*/
    _conjunction_57887 = 2;

    /** 						prev_conj = option*/
    RefDS(_option_57858);
    DeRef(_prev_conj_57889);
    _prev_conj_57889 = _option_57858;

    /** 						continue "deflist"*/
    goto L7; // [394] 148
    goto LA; // [396] 518
L15: 

    /** 						CompileErr(9, {keyw, prev_conj})*/
    RefDS(_prev_conj_57889);
    RefDS(_keyw_57866);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _keyw_57866;
    ((int *)_2)[2] = _prev_conj_57889;
    _29339 = MAKE_SEQ(_1);
    _43CompileErr(9, _29339, 0);
    _29339 = NOVALUE;
    goto LA; // [411] 518
L13: 

    /** 				elsif length(option) = 0 then*/
    if (IS_SEQUENCE(_option_57858)){
            _29340 = SEQ_PTR(_option_57858)->length;
    }
    else {
        _29340 = 1;
    }
    if (_29340 != 0)
    goto L16; // [419] 454

    /** 					if at_start = 1 then*/
    if (_at_start_57888 != 1)
    goto L17; // [425] 443

    /** 						CompileErr(122, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29343 = MAKE_SEQ(_1);
    _43CompileErr(122, _29343, 0);
    _29343 = NOVALUE;
    goto LA; // [440] 518
L17: 

    /** 						CompileErr(82)*/
    RefDS(_21829);
    _43CompileErr(82, _21829, 0);
    goto LA; // [451] 518
L16: 

    /** 				elsif not at_start and length(prev_conj) = 0 then*/
    _29344 = (_at_start_57888 == 0);
    if (_29344 == 0) {
        goto L18; // [459] 488
    }
    if (IS_SEQUENCE(_prev_conj_57889)){
            _29346 = SEQ_PTR(_prev_conj_57889)->length;
    }
    else {
        _29346 = 1;
    }
    _29347 = (_29346 == 0);
    _29346 = NOVALUE;
    if (_29347 == 0)
    {
        DeRef(_29347);
        _29347 = NOVALUE;
        goto L18; // [471] 488
    }
    else{
        DeRef(_29347);
        _29347 = NOVALUE;
    }

    /** 					CompileErr(4, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29348 = MAKE_SEQ(_1);
    _43CompileErr(4, _29348, 0);
    _29348 = NOVALUE;
    goto LA; // [485] 518
L18: 

    /** 				elsif t_identifier(option) = 0 then*/
    RefDS(_option_57858);
    _29349 = _9t_identifier(_option_57858);
    if (binary_op_a(NOTEQ, _29349, 0)){
        DeRef(_29349);
        _29349 = NOVALUE;
        goto L19; // [494] 512
    }
    DeRef(_29349);
    _29349 = NOVALUE;

    /** 					CompileErr(3, {keyw})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_keyw_57866);
    *((int *)(_2+4)) = _keyw_57866;
    _29351 = MAKE_SEQ(_1);
    _43CompileErr(3, _29351, 0);
    _29351 = NOVALUE;
    goto LA; // [509] 518
L19: 

    /** 					at_start = 0*/
    _at_start_57888 = 0;
LA: 

    /** 				integer this_matched = find(option, OpDefines)*/
    _this_matched_57962 = find_from(_option_57858, _12OpDefines_11756, 1);

    /** 				if negate then*/
    if (_negate_57886 == 0)
    {
        goto L1A; // [529] 543
    }
    else{
    }

    /** 					this_matched = not this_matched*/
    _this_matched_57962 = (_this_matched_57962 == 0);

    /** 					negate = 0*/
    _negate_57886 = 0;
L1A: 

    /** 				if conjunction = 0 then*/
    if (_conjunction_57887 != 0)
    goto L1B; // [545] 557

    /** 					matched = this_matched*/
    _matched_57859 = _this_matched_57962;
    goto L1C; // [554] 599
L1B: 

    /** 					if conjunction = 1 then*/
    if (_conjunction_57887 != 1)
    goto L1D; // [559] 572

    /** 						matched = matched and this_matched*/
    _matched_57859 = (_matched_57859 != 0 && _this_matched_57962 != 0);
    goto L1E; // [569] 586
L1D: 

    /** 					elsif conjunction = 2 then*/
    if (_conjunction_57887 != 2)
    goto L1F; // [574] 585

    /** 						matched = matched or this_matched*/
    _matched_57859 = (_matched_57859 != 0 || _this_matched_57962 != 0);
L1F: 
L1E: 

    /** 					conjunction = 0*/
    _conjunction_57887 = 0;

    /** 					prev_conj = ""*/
    RefDS(_21829);
    DeRef(_prev_conj_57889);
    _prev_conj_57889 = _21829;
L1C: 

    /** 			end while*/
    goto L7; // [603] 148
LD: 

    /** 			in_matched = matched*/
    _in_matched_57861 = _matched_57859;

    /** 			if matched then*/
    if (_matched_57859 == 0)
    {
        goto L20; // [613] 631
    }
    else{
    }

    /** 				No_new_entry = 0*/
    _52No_new_entry_46903 = 0;

    /** 				call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_57870].addr;
    (*(int (*)())_0)(
                         );
L20: 
L6: 
    DeRef(_prev_conj_57889);
    _prev_conj_57889 = NOVALUE;

    /** 		integer gotword = 0*/
    _gotword_57978 = 0;

    /** 		integer gotthen = 0*/
    _gotthen_57979 = 0;

    /** 		integer if_lvl  = 0*/
    _if_lvl_57980 = 0;

    /** 		No_new_entry = not matched*/
    _52No_new_entry_46903 = (_matched_57859 == 0);

    /** 		has_matched = has_matched or matched*/
    _has_matched_57860 = (_has_matched_57860 != 0 || _matched_57859 != 0);

    /** 		keyw = "elsifdef"*/
    RefDS(_26041);
    DeRefi(_keyw_57866);
    _keyw_57866 = _26041;

    /** 		while 1 do*/
L21: 

    /** 			tok = next_token()*/
    _0 = _tok_57865;
    _tok_57865 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29362 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29362, -21)){
        _29362 = NOVALUE;
        goto L22; // [689] 712
    }
    _29362 = NOVALUE;

    /** 				CompileErr(65, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29364 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29364 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29365 = (int)*(((s1_ptr)_2)->base + _29364);
    _43CompileErr(65, _29365, 0);
    _29365 = NOVALUE;
    goto L21; // [709] 674
L22: 

    /** 			elsif tok[T_ID] = END then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29366 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29366, 402)){
        _29366 = NOVALUE;
        goto L23; // [722] 844
    }
    _29366 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_57865;
    _tok_57865 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29369 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29369, 407)){
        _29369 = NOVALUE;
        goto L24; // [741] 769
    }
    _29369 = NOVALUE;

    /** 					if dead_ifdef then*/
    if (_dead_ifdef_57862 == 0)
    {
        goto L25; // [747] 759
    }
    else{
    }

    /** 						dead_ifdef -= 1*/
    _dead_ifdef_57862 = _dead_ifdef_57862 - 1;
    goto L21; // [756] 674
L25: 

    /** 						exit "top"*/
    goto L26; // [763] 1312
    goto L21; // [766] 674
L24: 

    /** 				elsif in_matched then*/
    if (_in_matched_57861 == 0)
    {
        goto L27; // [771] 793
    }
    else{
    }

    /** 					CompileErr(75, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29372 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29372 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29373 = (int)*(((s1_ptr)_2)->base + _29372);
    _43CompileErr(75, _29373, 0);
    _29373 = NOVALUE;
    goto L21; // [790] 674
L27: 

    /** 					if tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29374 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29374, 20)){
        _29374 = NOVALUE;
        goto L21; // [803] 674
    }
    _29374 = NOVALUE;

    /** 						if if_lvl > 0 then*/
    if (_if_lvl_57980 <= 0)
    goto L28; // [809] 822

    /** 							if_lvl -= 1*/
    _if_lvl_57980 = _if_lvl_57980 - 1;
    goto L21; // [819] 674
L28: 

    /** 							CompileErr(111, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29378 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29378 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29379 = (int)*(((s1_ptr)_2)->base + _29378);
    _43CompileErr(111, _29379, 0);
    _29379 = NOVALUE;
    goto L21; // [841] 674
L23: 

    /** 			elsif tok[T_ID] = IF then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29380 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29380, 20)){
        _29380 = NOVALUE;
        goto L29; // [854] 867
    }
    _29380 = NOVALUE;

    /** 				if_lvl += 1*/
    _if_lvl_57980 = _if_lvl_57980 + 1;
    goto L21; // [864] 674
L29: 

    /** 			elsif tok[T_ID] = ELSE then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29383 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29383, 23)){
        _29383 = NOVALUE;
        goto L2A; // [877] 913
    }
    _29383 = NOVALUE;

    /** 				if not in_matched then*/
    if (_in_matched_57861 != 0)
    goto L21; // [883] 674

    /** 					if if_lvl = 0 then*/
    if (_if_lvl_57980 != 0)
    goto L21; // [888] 674

    /** 						CompileErr(108, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29387 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29387 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29388 = (int)*(((s1_ptr)_2)->base + _29387);
    _43CompileErr(108, _29388, 0);
    _29388 = NOVALUE;
    goto L21; // [910] 674
L2A: 

    /** 			elsif tok[T_ID] = ELSIFDEF and not dead_ifdef then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29389 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29389)) {
        _29390 = (_29389 == 408);
    }
    else {
        _29390 = binary_op(EQUALS, _29389, 408);
    }
    _29389 = NOVALUE;
    if (IS_ATOM_INT(_29390)) {
        if (_29390 == 0) {
            goto L2B; // [927] 1065
        }
    }
    else {
        if (DBL_PTR(_29390)->dbl == 0.0) {
            goto L2B; // [927] 1065
        }
    }
    _29392 = (_dead_ifdef_57862 == 0);
    if (_29392 == 0)
    {
        DeRef(_29392);
        _29392 = NOVALUE;
        goto L2B; // [935] 1065
    }
    else{
        DeRef(_29392);
        _29392 = NOVALUE;
    }

    /** 				if has_matched then*/
    if (_has_matched_57860 == 0)
    {
        goto L2C; // [940] 1305
    }
    else{
    }

    /** 					in_matched = 0*/
    _in_matched_57861 = 0;

    /** 					No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 					gotword = 0*/
    _gotword_57978 = 0;

    /** 					gotthen = 0*/
    _gotthen_57979 = 0;

    /** 					while length(option) > 0 with entry do*/
    goto L2D; // [967] 1009
L2E: 
    if (IS_SEQUENCE(_option_57858)){
            _29393 = SEQ_PTR(_option_57858)->length;
    }
    else {
        _29393 = 1;
    }
    if (_29393 <= 0)
    goto L2F; // [975] 1022

    /** 						if equal(option, "then") then*/
    if (_option_57858 == _26140)
    _29395 = 1;
    else if (IS_ATOM_INT(_option_57858) && IS_ATOM_INT(_26140))
    _29395 = 0;
    else
    _29395 = (compare(_option_57858, _26140) == 0);
    if (_29395 == 0)
    {
        _29395 = NOVALUE;
        goto L30; // [985] 1000
    }
    else{
        _29395 = NOVALUE;
    }

    /** 							gotthen = 1*/
    _gotthen_57979 = 1;

    /** 							exit*/
    goto L2F; // [995] 1022
    goto L31; // [997] 1006
L30: 

    /** 							gotword = 1*/
    _gotword_57978 = 1;
L31: 

    /** 					entry*/
L2D: 

    /** 						option = StringToken()*/
    RefDS(_5);
    _0 = _option_57858;
    _option_57858 = _60StringToken(_5);
    DeRef(_0);

    /** 					end while*/
    goto L2E; // [1019] 970
L2F: 

    /** 					if gotword = 0 then*/
    if (_gotword_57978 != 0)
    goto L32; // [1024] 1036

    /** 						CompileErr(78)*/
    RefDS(_21829);
    _43CompileErr(78, _21829, 0);
L32: 

    /** 					if gotthen = 0 then*/
    if (_gotthen_57979 != 0)
    goto L33; // [1038] 1050

    /** 						CompileErr(77)*/
    RefDS(_21829);
    _43CompileErr(77, _21829, 0);
L33: 

    /** 					read_line()*/
    _60read_line();
    goto L21; // [1054] 674

    /** 					exit*/
    goto L2C; // [1059] 1305
    goto L21; // [1062] 674
L2B: 

    /** 			elsif tok[T_ID] = ELSEDEF then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29399 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29399, 409)){
        _29399 = NOVALUE;
        goto L34; // [1075] 1235
    }
    _29399 = NOVALUE;

    /** 				gotword = line_number*/
    _gotword_57978 = _12line_number_11683;

    /** 				option = StringToken()*/
    RefDS(_5);
    _0 = _option_57858;
    _option_57858 = _60StringToken(_5);
    DeRef(_0);

    /** 				if length(option) > 0 then*/
    if (IS_SEQUENCE(_option_57858)){
            _29402 = SEQ_PTR(_option_57858)->length;
    }
    else {
        _29402 = 1;
    }
    if (_29402 <= 0)
    goto L35; // [1101] 1135

    /** 					if line_number = gotword then*/
    if (_12line_number_11683 != _gotword_57978)
    goto L36; // [1109] 1121

    /** 						CompileErr(116)*/
    RefDS(_21829);
    _43CompileErr(116, _21829, 0);
L36: 

    /** 					bp -= length(option)*/
    if (IS_SEQUENCE(_option_57858)){
            _29405 = SEQ_PTR(_option_57858)->length;
    }
    else {
        _29405 = 1;
    }
    _43bp_48162 = _43bp_48162 - _29405;
    _29405 = NOVALUE;
L35: 

    /** 				if not dead_ifdef then*/
    if (_dead_ifdef_57862 != 0)
    goto L21; // [1137] 674

    /** 					if has_matched then*/
    if (_has_matched_57860 == 0)
    {
        goto L37; // [1142] 1164
    }
    else{
    }

    /** 						in_matched = 0*/
    _in_matched_57861 = 0;

    /** 						No_new_entry = 1*/
    _52No_new_entry_46903 = 1;

    /** 						read_line()*/
    _60read_line();
    goto L21; // [1161] 674
L37: 

    /** 						No_new_entry = 0*/
    _52No_new_entry_46903 = 0;

    /** 						in_elsedef = 1*/
    _in_elsedef_57863 = 1;

    /** 						call_proc(parser_id, {})*/
    _0 = (int)_00[_parser_id_57870].addr;
    (*(int (*)())_0)(
                         );

    /** 						tok_match(END)*/
    _30tok_match(402, 0);

    /** 						tok_match(IFDEF, END)*/
    _30tok_match(407, 402);

    /** 						live_ifdef -= 1*/
    _30live_ifdef_57854 = _30live_ifdef_57854 - 1;

    /** 						ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29409 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29409 = 1;
    }
    _29410 = _29409 - 1;
    _29409 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30ifdef_lineno_57855;
    RHS_Slice(_30ifdef_lineno_57855, 1, _29410);

    /** 						return*/
    DeRef(_option_57858);
    DeRef(_tok_57865);
    DeRefi(_keyw_57866);
    DeRef(_29309);
    _29309 = NOVALUE;
    DeRef(_29315);
    _29315 = NOVALUE;
    DeRef(_29344);
    _29344 = NOVALUE;
    _29410 = NOVALUE;
    DeRef(_29390);
    _29390 = NOVALUE;
    return;
    goto L21; // [1232] 674
L34: 

    /** 			elsif tok[T_ID] = IFDEF then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29412 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29412, 407)){
        _29412 = NOVALUE;
        goto L38; // [1245] 1258
    }
    _29412 = NOVALUE;

    /** 				dead_ifdef += 1*/
    _dead_ifdef_57862 = _dead_ifdef_57862 + 1;
    goto L21; // [1255] 674
L38: 

    /** 			elsif tok[T_ID] = INCLUDE then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29415 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29415, 418)){
        _29415 = NOVALUE;
        goto L39; // [1268] 1279
    }
    _29415 = NOVALUE;

    /** 				read_line()*/
    _60read_line();
    goto L21; // [1276] 674
L39: 

    /** 			elsif tok[T_ID] = CASE then*/
    _2 = (int)SEQ_PTR(_tok_57865);
    _29417 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29417, 186)){
        _29417 = NOVALUE;
        goto L21; // [1289] 674
    }
    _29417 = NOVALUE;

    /** 				tok = next_token()*/
    _0 = _tok_57865;
    _tok_57865 = _30next_token();
    DeRef(_0);

    /** 		end while*/
    goto L21; // [1302] 674
L2C: 

    /** 	end while*/
    goto L5; // [1309] 105
L26: 

    /** 	live_ifdef -= 1*/
    _30live_ifdef_57854 = _30live_ifdef_57854 - 1;

    /** 	ifdef_lineno = ifdef_lineno[1..$-1]*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29421 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29421 = 1;
    }
    _29422 = _29421 - 1;
    _29421 = NOVALUE;
    rhs_slice_target = (object_ptr)&_30ifdef_lineno_57855;
    RHS_Slice(_30ifdef_lineno_57855, 1, _29422);

    /** 	No_new_entry = 0*/
    _52No_new_entry_46903 = 0;

    /** end procedure*/
    DeRef(_option_57858);
    DeRef(_tok_57865);
    DeRefi(_keyw_57866);
    DeRef(_29309);
    _29309 = NOVALUE;
    DeRef(_29315);
    _29315 = NOVALUE;
    DeRef(_29344);
    _29344 = NOVALUE;
    DeRef(_29410);
    _29410 = NOVALUE;
    DeRef(_29390);
    _29390 = NOVALUE;
    _29422 = NOVALUE;
    return;
    ;
}


int _30SetPrivateScope(int _s_58126, int _type_sym_58128, int _n_58129)
{
    int _hashval_58130 = NOVALUE;
    int _scope_58131 = NOVALUE;
    int _t_58133 = NOVALUE;
    int _29443 = NOVALUE;
    int _29442 = NOVALUE;
    int _29441 = NOVALUE;
    int _29440 = NOVALUE;
    int _29439 = NOVALUE;
    int _29438 = NOVALUE;
    int _29435 = NOVALUE;
    int _29432 = NOVALUE;
    int _29430 = NOVALUE;
    int _29428 = NOVALUE;
    int _29424 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_58126)) {
        _1 = (long)(DBL_PTR(_s_58126)->dbl);
        DeRefDS(_s_58126);
        _s_58126 = _1;
    }

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29424 = (int)*(((s1_ptr)_2)->base + _s_58126);
    _2 = (int)SEQ_PTR(_29424);
    _scope_58131 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_58131)){
        _scope_58131 = (long)DBL_PTR(_scope_58131)->dbl;
    }
    _29424 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_58131;
    switch ( _0 ){ 

        /** 		case SC_PRIVATE then*/
        case 3:

        /** 			DefinedYet(s)*/
        _52DefinedYet(_s_58126);

        /** 			Block_var( s )*/
        _65Block_var(_s_58126);

        /** 			return s*/
        return _s_58126;
        goto L1; // [50] 260

        /** 		case SC_LOOP_VAR then*/
        case 2:

        /** 			DefinedYet(s)*/
        _52DefinedYet(_s_58126);

        /** 			return s*/
        return _s_58126;
        goto L1; // [67] 260

        /** 		case SC_UNDEFINED, SC_MULTIPLY_DEFINED then*/
        case 9:
        case 10:

        /** 			SymTab[s][S_SCOPE] = SC_PRIVATE*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58126 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 4);
        _1 = *(int *)_2;
        *(int *)_2 = 3;
        DeRef(_1);
        _29428 = NOVALUE;

        /** 			SymTab[s][S_VARNUM] = n*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58126 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 16);
        _1 = *(int *)_2;
        *(int *)_2 = _n_58129;
        DeRef(_1);
        _29430 = NOVALUE;

        /** 			SymTab[s][S_VTYPE] = type_sym*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_58126 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 15);
        _1 = *(int *)_2;
        *(int *)_2 = _type_sym_58128;
        DeRef(_1);
        _29432 = NOVALUE;

        /** 			if type_sym < 0 then*/
        if (_type_sym_58128 >= 0)
        goto L2; // [124] 135

        /** 				register_forward_type( s, type_sym )*/
        _29register_forward_type(_s_58126, _type_sym_58128);
L2: 

        /** 			Block_var( s )*/
        _65Block_var(_s_58126);

        /** 			return s*/
        return _s_58126;
        goto L1; // [146] 260

        /** 		case SC_LOCAL, SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT then*/
        case 5:
        case 6:
        case 7:
        case 13:
        case 11:

        /** 			hashval = SymTab[s][S_HASHVAL]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _29435 = (int)*(((s1_ptr)_2)->base + _s_58126);
        _2 = (int)SEQ_PTR(_29435);
        _hashval_58130 = (int)*(((s1_ptr)_2)->base + 11);
        if (!IS_ATOM_INT(_hashval_58130)){
            _hashval_58130 = (long)DBL_PTR(_hashval_58130)->dbl;
        }
        _29435 = NOVALUE;

        /** 			t = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _t_58133 = (int)*(((s1_ptr)_2)->base + _hashval_58130);
        if (!IS_ATOM_INT(_t_58133)){
            _t_58133 = (long)DBL_PTR(_t_58133)->dbl;
        }

        /** 			buckets[hashval] = NewEntry(SymTab[s][S_NAME], n, SC_PRIVATE,*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _29438 = (int)*(((s1_ptr)_2)->base + _s_58126);
        _2 = (int)SEQ_PTR(_29438);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _29439 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _29439 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        _29438 = NOVALUE;
        Ref(_29439);
        _29440 = _52NewEntry(_29439, _n_58129, 3, -100, _hashval_58130, _t_58133, _type_sym_58128);
        _29439 = NOVALUE;
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_58130);
        _1 = *(int *)_2;
        *(int *)_2 = _29440;
        if( _1 != _29440 ){
            DeRef(_1);
        }
        _29440 = NOVALUE;

        /** 			Block_var( buckets[hashval] )*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _29441 = (int)*(((s1_ptr)_2)->base + _hashval_58130);
        Ref(_29441);
        _65Block_var(_29441);
        _29441 = NOVALUE;

        /** 			return buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _29442 = (int)*(((s1_ptr)_2)->base + _hashval_58130);
        Ref(_29442);
        return _29442;
        goto L1; // [243] 260

        /** 		case else*/
        default:

        /** 			InternalErr(267, {scope})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _scope_58131;
        _29443 = MAKE_SEQ(_1);
        _43InternalErr(267, _29443);
        _29443 = NOVALUE;
    ;}L1: 

    /** 	return 0*/
    _29442 = NOVALUE;
    return 0;
    ;
}


void _30For_statement()
{
    int _bp1_58198 = NOVALUE;
    int _bp2_58199 = NOVALUE;
    int _exit_base_58200 = NOVALUE;
    int _next_base_58201 = NOVALUE;
    int _end_op_58202 = NOVALUE;
    int _tok_58204 = NOVALUE;
    int _loop_var_58205 = NOVALUE;
    int _loop_var_sym_58207 = NOVALUE;
    int _save_syms_58208 = NOVALUE;
    int _29490 = NOVALUE;
    int _29488 = NOVALUE;
    int _29487 = NOVALUE;
    int _29481 = NOVALUE;
    int _29479 = NOVALUE;
    int _29477 = NOVALUE;
    int _29476 = NOVALUE;
    int _29475 = NOVALUE;
    int _29474 = NOVALUE;
    int _29472 = NOVALUE;
    int _29470 = NOVALUE;
    int _29469 = NOVALUE;
    int _29468 = NOVALUE;
    int _29467 = NOVALUE;
    int _29465 = NOVALUE;
    int _29463 = NOVALUE;
    int _29459 = NOVALUE;
    int _29457 = NOVALUE;
    int _29454 = NOVALUE;
    int _29452 = NOVALUE;
    int _29446 = NOVALUE;
    int _29445 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence save_syms*/

    /** 	Start_block( FOR )*/
    _65Start_block(21, 0);

    /** 	loop_var = next_token()*/
    _0 = _loop_var_58205;
    _loop_var_58205 = _30next_token();
    DeRef(_0);

    /** 	if not find(loop_var[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_loop_var_58205);
    _29445 = (int)*(((s1_ptr)_2)->base + 1);
    _29446 = find_from(_29445, _28ADDR_TOKS_11306, 1);
    _29445 = NOVALUE;
    if (_29446 != 0)
    goto L1; // [31] 42
    _29446 = NOVALUE;

    /** 		CompileErr(28)*/
    RefDS(_21829);
    _43CompileErr(28, _21829, 0);
L1: 

    /** 	if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L2; // [46] 55
    }
    else{
    }

    /** 		add_ref(loop_var)*/
    Ref(_loop_var_58205);
    _52add_ref(_loop_var_58205);
L2: 

    /** 	tok_match(EQUALS)*/
    _30tok_match(3, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _exit_base_58200 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _exit_base_58200 = 1;
    }

    /** 	next_base = length(continue_list)*/
    if (IS_SEQUENCE(_30continue_list_53707)){
            _next_base_58201 = SEQ_PTR(_30continue_list_53707)->length;
    }
    else {
        _next_base_58201 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	tok_match(TO)*/
    _30tok_match(403, 0);

    /** 	exit_base = length(exit_list)*/
    if (IS_SEQUENCE(_30exit_list_53705)){
            _exit_base_58200 = SEQ_PTR(_30exit_list_53705)->length;
    }
    else {
        _exit_base_58200 = 1;
    }

    /** 	Expr()*/
    _30Expr();

    /** 	tok = next_token()*/
    _0 = _tok_58204;
    _tok_58204 = _30next_token();
    DeRef(_0);

    /** 	if tok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_tok_58204);
    _29452 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29452, 404)){
        _29452 = NOVALUE;
        goto L3; // [115] 135
    }
    _29452 = NOVALUE;

    /** 		Expr()*/
    _30Expr();

    /** 		end_op = ENDFOR_GENERAL -- will be set at runtime by FOR op*/
    _end_op_58202 = 39;
    goto L4; // [132] 159
L3: 

    /** 		emit_opnd(NewIntSym(1))*/
    _29454 = _52NewIntSym(1);
    _37emit_opnd(_29454);
    _29454 = NOVALUE;

    /** 		putback(tok)*/
    Ref(_tok_58204);
    _30putback(_tok_58204);

    /** 		end_op = ENDFOR_INT_UP1*/
    _end_op_58202 = 54;
L4: 

    /** 	loop_var_sym = loop_var[T_SYM]*/
    _2 = (int)SEQ_PTR(_loop_var_58205);
    _loop_var_sym_58207 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_loop_var_sym_58207)){
        _loop_var_sym_58207 = (long)DBL_PTR(_loop_var_sym_58207)->dbl;
    }

    /** 	if CurrentSub = TopLevelSub then*/
    if (_12CurrentSub_11690 != _12TopLevelSub_11689)
    goto L5; // [175] 221

    /** 		DefinedYet(loop_var_sym)*/
    _52DefinedYet(_loop_var_sym_58207);

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_GLOOP_VAR*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _29457 = NOVALUE;

    /** 		SymTab[loop_var_sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_45731;
    DeRef(_1);
    _29459 = NOVALUE;
    goto L6; // [218] 265
L5: 

    /** 		loop_var_sym = SetPrivateScope(loop_var_sym, object_type, param_num)*/
    _loop_var_sym_58207 = _30SetPrivateScope(_loop_var_sym_58207, _52object_type_45731, _30param_num_53694);
    if (!IS_ATOM_INT(_loop_var_sym_58207)) {
        _1 = (long)(DBL_PTR(_loop_var_sym_58207)->dbl);
        DeRefDS(_loop_var_sym_58207);
        _loop_var_sym_58207 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_53694 = _30param_num_53694 + 1;

    /** 		SymTab[loop_var_sym][S_SCOPE] = SC_LOOP_VAR*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29463 = NOVALUE;

    /** 		Pop_block_var()*/
    _65Pop_block_var();
L6: 

    /** 	SymTab[loop_var_sym][S_USAGE] = or_bits(SymTab[loop_var_sym][S_USAGE], U_USED)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_loop_var_sym_58207 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29467 = (int)*(((s1_ptr)_2)->base + _loop_var_sym_58207);
    _2 = (int)SEQ_PTR(_29467);
    _29468 = (int)*(((s1_ptr)_2)->base + 5);
    _29467 = NOVALUE;
    if (IS_ATOM_INT(_29468)) {
        {unsigned long tu;
             tu = (unsigned long)_29468 | (unsigned long)3;
             _29469 = MAKE_UINT(tu);
        }
    }
    else {
        _29469 = binary_op(OR_BITS, _29468, 3);
    }
    _29468 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _29469;
    if( _1 != _29469 ){
        DeRef(_1);
    }
    _29469 = NOVALUE;
    _29465 = NOVALUE;

    /** 	op_info1 = loop_var_sym*/
    _37op_info1_49791 = _loop_var_sym_58207;

    /** 	emit_op(FOR)*/
    _37emit_op(21);

    /** 	emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58207);

    /** 	if finish_block_header(FOR) then*/
    _29470 = _30finish_block_header(21);
    if (_29470 == 0) {
        DeRef(_29470);
        _29470 = NOVALUE;
        goto L7; // [325] 336
    }
    else {
        if (!IS_ATOM_INT(_29470) && DBL_PTR(_29470)->dbl == 0.0){
            DeRef(_29470);
            _29470 = NOVALUE;
            goto L7; // [325] 336
        }
        DeRef(_29470);
        _29470 = NOVALUE;
    }
    DeRef(_29470);
    _29470 = NOVALUE;

    /** 		CompileErr(83)*/
    RefDS(_21829);
    _43CompileErr(83, _21829, 0);
L7: 

    /** 	entry_addr &= 0*/
    Append(&_30entry_addr_53709, _30entry_addr_53709, 0);

    /** 	bp1 = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29472 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29472 = 1;
    }
    _bp1_58198 = _29472 + 1;
    _29472 = NOVALUE;

    /** 	emit_addr(0) -- will be patched - don't straighten*/
    _37emit_addr(0);

    /** 	save_syms = Code[$-5..$-3] -- could be temps, but can't get rid of them yet*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29474 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29474 = 1;
    }
    _29475 = _29474 - 5;
    _29474 = NOVALUE;
    if (IS_SEQUENCE(_12Code_11771)){
            _29476 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29476 = 1;
    }
    _29477 = _29476 - 3;
    _29476 = NOVALUE;
    rhs_slice_target = (object_ptr)&_save_syms_58208;
    RHS_Slice(_12Code_11771, _29475, _29477);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58296;
        _i_58296 = 1;
L8: 
        if (_i_58296 > 3){
            goto L9; // [385] 408
        }

        /** 		clear_temp( save_syms[i] )*/
        _2 = (int)SEQ_PTR(_save_syms_58208);
        _29479 = (int)*(((s1_ptr)_2)->base + _i_58296);
        Ref(_29479);
        _37clear_temp(_29479);
        _29479 = NOVALUE;

        /** 	end for*/
        _i_58296 = _i_58296 + 1;
        goto L8; // [403] 392
L9: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** 	bp2 = length(Code)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _bp2_58199 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _bp2_58199 = 1;
    }

    /** 	retry_addr &= bp2 + 1*/
    _29481 = _bp2_58199 + 1;
    Append(&_30retry_addr_53711, _30retry_addr_53711, _29481);
    _29481 = NOVALUE;

    /** 	continue_addr &= 0*/
    Append(&_30continue_addr_53710, _30continue_addr_53710, 0);

    /** 	loop_stack &= FOR*/
    Append(&_30loop_stack_53719, _30loop_stack_53719, 21);

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto LA; // [454] 478

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto LB; // [461] 477
    }
    else{
    }

    /** 			emit_op(DISPLAY_VAR)*/
    _37emit_op(87);

    /** 			emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58207);
LB: 
LA: 

    /** 	Statement_list()*/
    _30Statement_list();

    /** 	tok_match(END)*/
    _30tok_match(402, 0);

    /** 	tok_match(FOR, END)*/
    _30tok_match(21, 402);

    /** 	End_block( FOR )*/
    _65End_block(21);

    /** 	StartSourceLine(TRUE, TRANSLATE)*/
    _37StartSourceLine(_9TRUE_431, _12TRANSLATE_11319, 2);

    /** 	op_info1 = loop_var_sym*/
    _37op_info1_49791 = _loop_var_sym_58207;

    /** 	op_info2 = bp2 + 1*/
    _37op_info2_49792 = _bp2_58199 + 1;

    /** 	PatchNList(next_base)*/
    _30PatchNList(_next_base_58201);

    /** 	emit_op(end_op)*/
    _37emit_op(_end_op_58202);

    /** 	backpatch(bp1, length(Code)+1)*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29487 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29487 = 1;
    }
    _29488 = _29487 + 1;
    _29487 = NOVALUE;
    _37backpatch(_bp1_58198, _29488);
    _29488 = NOVALUE;

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto LC; // [564] 588

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto LD; // [571] 587
    }
    else{
    }

    /** 			emit_op(ERASE_SYMBOL)*/
    _37emit_op(90);

    /** 			emit_addr(loop_var_sym)*/
    _37emit_addr(_loop_var_sym_58207);
LD: 
LC: 

    /** 	Hide(loop_var_sym)*/
    _52Hide(_loop_var_sym_58207);

    /** 	exit_loop(exit_base)*/
    _30exit_loop(_exit_base_58200);

    /** 	for i = 1 to 3 do*/
    {
        int _i_58342;
        _i_58342 = 1;
LE: 
        if (_i_58342 > 3){
            goto LF; // [600] 626
        }

        /** 		emit_temp( save_syms[i], NEW_REFERENCE )*/
        _2 = (int)SEQ_PTR(_save_syms_58208);
        _29490 = (int)*(((s1_ptr)_2)->base + _i_58342);
        Ref(_29490);
        _37emit_temp(_29490, 1);
        _29490 = NOVALUE;

        /** 	end for*/
        _i_58342 = _i_58342 + 1;
        goto LE; // [621] 607
LF: 
        ;
    }

    /** 	flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** end procedure*/
    DeRef(_tok_58204);
    DeRef(_loop_var_58205);
    DeRef(_save_syms_58208);
    DeRef(_29475);
    _29475 = NOVALUE;
    DeRef(_29477);
    _29477 = NOVALUE;
    return;
    ;
}


int _30CompileType(int _type_ptr_58350)
{
    int _t_58351 = NOVALUE;
    int _29501 = NOVALUE;
    int _29500 = NOVALUE;
    int _29499 = NOVALUE;
    int _29493 = NOVALUE;
    int _29492 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_type_ptr_58350)) {
        _1 = (long)(DBL_PTR(_type_ptr_58350)->dbl);
        DeRefDS(_type_ptr_58350);
        _type_ptr_58350 = _1;
    }

    /** 	if type_ptr < 0 then*/
    if (_type_ptr_58350 >= 0)
    goto L1; // [5] 16

    /** 		return type_ptr*/
    return _type_ptr_58350;
L1: 

    /** 	if SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29492 = (int)*(((s1_ptr)_2)->base + _type_ptr_58350);
    _2 = (int)SEQ_PTR(_29492);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _29493 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _29493 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _29492 = NOVALUE;
    if (binary_op_a(NOTEQ, _29493, 415)){
        _29493 = NOVALUE;
        goto L2; // [32] 47
    }
    _29493 = NOVALUE;

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [44] 218
L2: 

    /** 	elsif type_ptr = integer_type then*/
    if (_type_ptr_58350 != _52integer_type_45737)
    goto L4; // [51] 66

    /** 		return TYPE_INTEGER*/
    return 1;
    goto L3; // [63] 218
L4: 

    /** 	elsif type_ptr = atom_type then*/
    if (_type_ptr_58350 != _52atom_type_45733)
    goto L5; // [70] 85

    /** 		return TYPE_ATOM*/
    return 4;
    goto L3; // [82] 218
L5: 

    /** 	elsif type_ptr = sequence_type then*/
    if (_type_ptr_58350 != _52sequence_type_45735)
    goto L6; // [89] 104

    /** 		return TYPE_SEQUENCE*/
    return 8;
    goto L3; // [101] 218
L6: 

    /** 	elsif type_ptr = object_type then*/
    if (_type_ptr_58350 != _52object_type_45731)
    goto L7; // [108] 123

    /** 		return TYPE_OBJECT*/
    return 16;
    goto L3; // [120] 218
L7: 

    /** 		t = SymTab[SymTab[type_ptr][S_NEXT]][S_VTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29499 = (int)*(((s1_ptr)_2)->base + _type_ptr_58350);
    _2 = (int)SEQ_PTR(_29499);
    _29500 = (int)*(((s1_ptr)_2)->base + 2);
    _29499 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_29500)){
        _29501 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29500)->dbl));
    }
    else{
        _29501 = (int)*(((s1_ptr)_2)->base + _29500);
    }
    _2 = (int)SEQ_PTR(_29501);
    _t_58351 = (int)*(((s1_ptr)_2)->base + 15);
    if (!IS_ATOM_INT(_t_58351)){
        _t_58351 = (long)DBL_PTR(_t_58351)->dbl;
    }
    _29501 = NOVALUE;

    /** 		if t = integer_type then*/
    if (_t_58351 != _52integer_type_45737)
    goto L8; // [155] 170

    /** 			return TYPE_INTEGER*/
    _29500 = NOVALUE;
    return 1;
    goto L9; // [167] 217
L8: 

    /** 		elsif t = atom_type then*/
    if (_t_58351 != _52atom_type_45733)
    goto LA; // [174] 189

    /** 			return TYPE_ATOM*/
    _29500 = NOVALUE;
    return 4;
    goto L9; // [186] 217
LA: 

    /** 		elsif t = sequence_type then*/
    if (_t_58351 != _52sequence_type_45735)
    goto LB; // [193] 208

    /** 			return TYPE_SEQUENCE*/
    _29500 = NOVALUE;
    return 8;
    goto L9; // [205] 217
LB: 

    /** 			return TYPE_OBJECT*/
    _29500 = NOVALUE;
    return 16;
L9: 
L3: 
    ;
}


int _30get_assigned_sym()
{
    int _29514 = NOVALUE;
    int _29513 = NOVALUE;
    int _29512 = NOVALUE;
    int _29510 = NOVALUE;
    int _29509 = NOVALUE;
    int _29508 = NOVALUE;
    int _29507 = NOVALUE;
    int _29506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find( Code[$-2], {ASSIGN, ASSIGN_I}) then*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29506 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29506 = 1;
    }
    _29507 = _29506 - 2;
    _29506 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _29508 = (int)*(((s1_ptr)_2)->base + _29507);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 18;
    ((int *)_2)[2] = 113;
    _29509 = MAKE_SEQ(_1);
    _29510 = find_from(_29508, _29509, 1);
    _29508 = NOVALUE;
    DeRefDS(_29509);
    _29509 = NOVALUE;
    if (_29510 != 0)
    goto L1; // [29] 39
    _29510 = NOVALUE;

    /** 		return 0*/
    _29507 = NOVALUE;
    return 0;
L1: 

    /** 	return Code[$-1]*/
    if (IS_SEQUENCE(_12Code_11771)){
            _29512 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29512 = 1;
    }
    _29513 = _29512 - 1;
    _29512 = NOVALUE;
    _2 = (int)SEQ_PTR(_12Code_11771);
    _29514 = (int)*(((s1_ptr)_2)->base + _29513);
    Ref(_29514);
    DeRef(_29507);
    _29507 = NOVALUE;
    _29513 = NOVALUE;
    return _29514;
    ;
}


void _30Assign_Constant(int _sym_58420)
{
    int _valsym_58422 = NOVALUE;
    int _val_58425 = NOVALUE;
    int _29541 = NOVALUE;
    int _29540 = NOVALUE;
    int _29538 = NOVALUE;
    int _29537 = NOVALUE;
    int _29536 = NOVALUE;
    int _29534 = NOVALUE;
    int _29533 = NOVALUE;
    int _29532 = NOVALUE;
    int _29530 = NOVALUE;
    int _29529 = NOVALUE;
    int _29528 = NOVALUE;
    int _29526 = NOVALUE;
    int _29525 = NOVALUE;
    int _29524 = NOVALUE;
    int _29522 = NOVALUE;
    int _29520 = NOVALUE;
    int _29518 = NOVALUE;
    int _29516 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	symtab_index valsym = Pop() -- pop the sym for the constant, too*/
    _valsym_58422 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58422)) {
        _1 = (long)(DBL_PTR(_valsym_58422)->dbl);
        DeRefDS(_valsym_58422);
        _valsym_58422 = _1;
    }

    /** 	object val = SymTab[valsym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29516 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    DeRef(_val_58425);
    _2 = (int)SEQ_PTR(_29516);
    _val_58425 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_val_58425);
    _29516 = NOVALUE;

    /** 	SymTab[sym][S_OBJ] = val*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    Ref(_val_58425);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _val_58425;
    DeRef(_1);
    _29518 = NOVALUE;

    /** 	SymTab[sym][S_INITLEVEL] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29520 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [58] 197
    }
    else{
    }

    /** 		SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29524 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    _2 = (int)SEQ_PTR(_29524);
    _29525 = (int)*(((s1_ptr)_2)->base + 36);
    _29524 = NOVALUE;
    Ref(_29525);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29525;
    if( _1 != _29525 ){
        DeRef(_1);
    }
    _29525 = NOVALUE;
    _29522 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29528 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    _2 = (int)SEQ_PTR(_29528);
    _29529 = (int)*(((s1_ptr)_2)->base + 33);
    _29528 = NOVALUE;
    Ref(_29529);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29529;
    if( _1 != _29529 ){
        DeRef(_1);
    }
    _29529 = NOVALUE;
    _29526 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MIN] = SymTab[valsym][S_OBJ_MIN]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29532 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    _2 = (int)SEQ_PTR(_29532);
    _29533 = (int)*(((s1_ptr)_2)->base + 30);
    _29532 = NOVALUE;
    Ref(_29533);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _29533;
    if( _1 != _29533 ){
        DeRef(_1);
    }
    _29533 = NOVALUE;
    _29530 = NOVALUE;

    /** 		SymTab[sym][S_OBJ_MAX] = SymTab[valsym][S_OBJ_MAX]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29536 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    _2 = (int)SEQ_PTR(_29536);
    _29537 = (int)*(((s1_ptr)_2)->base + 31);
    _29536 = NOVALUE;
    Ref(_29537);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _29537;
    if( _1 != _29537 ){
        DeRef(_1);
    }
    _29537 = NOVALUE;
    _29534 = NOVALUE;

    /** 		SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58420 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29540 = (int)*(((s1_ptr)_2)->base + _valsym_58422);
    _2 = (int)SEQ_PTR(_29540);
    _29541 = (int)*(((s1_ptr)_2)->base + 32);
    _29540 = NOVALUE;
    Ref(_29541);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29541;
    if( _1 != _29541 ){
        DeRef(_1);
    }
    _29541 = NOVALUE;
    _29538 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_val_58425);
    return;
    ;
}


int _30Global_declaration(int _type_ptr_58482, int _scope_58483)
{
    int _new_symbols_58484 = NOVALUE;
    int _tok_58486 = NOVALUE;
    int _tsym_58487 = NOVALUE;
    int _prevtok_58488 = NOVALUE;
    int _sym_58490 = NOVALUE;
    int _valsym_58491 = NOVALUE;
    int _h_58492 = NOVALUE;
    int _count_58493 = NOVALUE;
    int _val_58494 = NOVALUE;
    int _usedval_58495 = NOVALUE;
    int _deltafunc_58496 = NOVALUE;
    int _delta_58497 = NOVALUE;
    int _is_fwd_ref_58498 = NOVALUE;
    int _ptok_58515 = NOVALUE;
    int _negate_58531 = NOVALUE;
    int _negate_58777 = NOVALUE;
    int _31366 = NOVALUE;
    int _31365 = NOVALUE;
    int _31364 = NOVALUE;
    int _29781 = NOVALUE;
    int _29779 = NOVALUE;
    int _29777 = NOVALUE;
    int _29775 = NOVALUE;
    int _29773 = NOVALUE;
    int _29770 = NOVALUE;
    int _29768 = NOVALUE;
    int _29767 = NOVALUE;
    int _29766 = NOVALUE;
    int _29765 = NOVALUE;
    int _29764 = NOVALUE;
    int _29763 = NOVALUE;
    int _29761 = NOVALUE;
    int _29757 = NOVALUE;
    int _29755 = NOVALUE;
    int _29753 = NOVALUE;
    int _29751 = NOVALUE;
    int _29749 = NOVALUE;
    int _29747 = NOVALUE;
    int _29746 = NOVALUE;
    int _29744 = NOVALUE;
    int _29743 = NOVALUE;
    int _29742 = NOVALUE;
    int _29740 = NOVALUE;
    int _29738 = NOVALUE;
    int _29736 = NOVALUE;
    int _29735 = NOVALUE;
    int _29734 = NOVALUE;
    int _29732 = NOVALUE;
    int _29731 = NOVALUE;
    int _29730 = NOVALUE;
    int _29728 = NOVALUE;
    int _29726 = NOVALUE;
    int _29724 = NOVALUE;
    int _29723 = NOVALUE;
    int _29722 = NOVALUE;
    int _29721 = NOVALUE;
    int _29720 = NOVALUE;
    int _29717 = NOVALUE;
    int _29715 = NOVALUE;
    int _29713 = NOVALUE;
    int _29712 = NOVALUE;
    int _29711 = NOVALUE;
    int _29707 = NOVALUE;
    int _29706 = NOVALUE;
    int _29705 = NOVALUE;
    int _29701 = NOVALUE;
    int _29700 = NOVALUE;
    int _29699 = NOVALUE;
    int _29697 = NOVALUE;
    int _29696 = NOVALUE;
    int _29695 = NOVALUE;
    int _29694 = NOVALUE;
    int _29693 = NOVALUE;
    int _29692 = NOVALUE;
    int _29691 = NOVALUE;
    int _29690 = NOVALUE;
    int _29689 = NOVALUE;
    int _29686 = NOVALUE;
    int _29684 = NOVALUE;
    int _29683 = NOVALUE;
    int _29681 = NOVALUE;
    int _29680 = NOVALUE;
    int _29678 = NOVALUE;
    int _29677 = NOVALUE;
    int _29676 = NOVALUE;
    int _29675 = NOVALUE;
    int _29673 = NOVALUE;
    int _29671 = NOVALUE;
    int _29669 = NOVALUE;
    int _29666 = NOVALUE;
    int _29663 = NOVALUE;
    int _29660 = NOVALUE;
    int _29658 = NOVALUE;
    int _29657 = NOVALUE;
    int _29656 = NOVALUE;
    int _29655 = NOVALUE;
    int _29653 = NOVALUE;
    int _29652 = NOVALUE;
    int _29651 = NOVALUE;
    int _29650 = NOVALUE;
    int _29646 = NOVALUE;
    int _29645 = NOVALUE;
    int _29644 = NOVALUE;
    int _29643 = NOVALUE;
    int _29642 = NOVALUE;
    int _29641 = NOVALUE;
    int _29638 = NOVALUE;
    int _29636 = NOVALUE;
    int _29635 = NOVALUE;
    int _29634 = NOVALUE;
    int _29633 = NOVALUE;
    int _29632 = NOVALUE;
    int _29629 = NOVALUE;
    int _29627 = NOVALUE;
    int _29625 = NOVALUE;
    int _29624 = NOVALUE;
    int _29623 = NOVALUE;
    int _29622 = NOVALUE;
    int _29621 = NOVALUE;
    int _29620 = NOVALUE;
    int _29619 = NOVALUE;
    int _29617 = NOVALUE;
    int _29614 = NOVALUE;
    int _29612 = NOVALUE;
    int _29611 = NOVALUE;
    int _29610 = NOVALUE;
    int _29609 = NOVALUE;
    int _29608 = NOVALUE;
    int _29607 = NOVALUE;
    int _29606 = NOVALUE;
    int _29605 = NOVALUE;
    int _29602 = NOVALUE;
    int _29601 = NOVALUE;
    int _29600 = NOVALUE;
    int _29598 = NOVALUE;
    int _29597 = NOVALUE;
    int _29596 = NOVALUE;
    int _29595 = NOVALUE;
    int _29594 = NOVALUE;
    int _29592 = NOVALUE;
    int _29591 = NOVALUE;
    int _29590 = NOVALUE;
    int _29588 = NOVALUE;
    int _29587 = NOVALUE;
    int _29585 = NOVALUE;
    int _29582 = NOVALUE;
    int _29580 = NOVALUE;
    int _29578 = NOVALUE;
    int _29570 = NOVALUE;
    int _29569 = NOVALUE;
    int _29567 = NOVALUE;
    int _29564 = NOVALUE;
    int _29557 = NOVALUE;
    int _29554 = NOVALUE;
    int _29553 = NOVALUE;
    int _29551 = NOVALUE;
    int _29547 = NOVALUE;
    int _29546 = NOVALUE;
    int _29545 = NOVALUE;
    int _29544 = NOVALUE;
    int _29543 = NOVALUE;
    int _29542 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_ptr_58482)) {
        _1 = (long)(DBL_PTR(_type_ptr_58482)->dbl);
        DeRefDS(_type_ptr_58482);
        _type_ptr_58482 = _1;
    }

    /** 	object tsym*/

    /** 	object prevtok = 0*/
    DeRef(_prevtok_58488);
    _prevtok_58488 = 0;

    /** 	integer h, count = 0*/
    _count_58493 = 0;

    /** 	atom val = 1, usedval*/
    DeRef(_val_58494);
    _val_58494 = 1;

    /** 	integer deltafunc = '+'*/
    _deltafunc_58496 = 43;

    /** 	atom delta = 1*/
    DeRef(_delta_58497);
    _delta_58497 = 1;

    /** 	new_symbols = {}*/
    RefDS(_21829);
    DeRefi(_new_symbols_58484);
    _new_symbols_58484 = _21829;

    /** 	integer is_fwd_ref = 0*/
    _is_fwd_ref_58498 = 0;

    /** 	if type_ptr > 0 and SymTab[type_ptr][S_SCOPE] = SC_UNDEFINED then*/
    _29542 = (_type_ptr_58482 > 0);
    if (_29542 == 0) {
        goto L1; // [50] 105
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29544 = (int)*(((s1_ptr)_2)->base + _type_ptr_58482);
    _2 = (int)SEQ_PTR(_29544);
    _29545 = (int)*(((s1_ptr)_2)->base + 4);
    _29544 = NOVALUE;
    if (IS_ATOM_INT(_29545)) {
        _29546 = (_29545 == 9);
    }
    else {
        _29546 = binary_op(EQUALS, _29545, 9);
    }
    _29545 = NOVALUE;
    if (_29546 == 0) {
        DeRef(_29546);
        _29546 = NOVALUE;
        goto L1; // [73] 105
    }
    else {
        if (!IS_ATOM_INT(_29546) && DBL_PTR(_29546)->dbl == 0.0){
            DeRef(_29546);
            _29546 = NOVALUE;
            goto L1; // [73] 105
        }
        DeRef(_29546);
        _29546 = NOVALUE;
    }
    DeRef(_29546);
    _29546 = NOVALUE;

    /** 		is_fwd_ref = 1*/
    _is_fwd_ref_58498 = 1;

    /** 		Hide(type_ptr)*/
    _52Hide(_type_ptr_58482);

    /** 		type_ptr = -new_forward_reference( TYPE, type_ptr )*/
    DeRef(_31366);
    _31366 = 504;
    _29547 = _29new_forward_reference(504, _type_ptr_58482, 504);
    _31366 = NOVALUE;
    if (IS_ATOM_INT(_29547)) {
        if ((unsigned long)_29547 == 0xC0000000)
        _type_ptr_58482 = (int)NewDouble((double)-0xC0000000);
        else
        _type_ptr_58482 = - _29547;
    }
    else {
        _type_ptr_58482 = unary_op(UMINUS, _29547);
    }
    DeRef(_29547);
    _29547 = NOVALUE;
    if (!IS_ATOM_INT(_type_ptr_58482)) {
        _1 = (long)(DBL_PTR(_type_ptr_58482)->dbl);
        DeRefDS(_type_ptr_58482);
        _type_ptr_58482 = _1;
    }
L1: 

    /** 	if type_ptr = -1 then*/
    if (_type_ptr_58482 != -1)
    goto L2; // [107] 423

    /** 		sequence ptok = next_token()*/
    _0 = _ptok_58515;
    _ptok_58515 = _30next_token();
    DeRef(_0);

    /** 		if ptok[T_ID] = TYPE_DECL then*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29551 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29551, 416)){
        _29551 = NOVALUE;
        goto L3; // [128] 171
    }
    _29551 = NOVALUE;

    /** 			putback(keyfind("enum",-1))*/
    RefDS(_26049);
    DeRef(_31364);
    _31364 = _26049;
    _31365 = _52hashfn(_31364);
    _31364 = NOVALUE;
    RefDS(_26049);
    _29553 = _52keyfind(_26049, -1, _12current_file_no_11682, 0, _31365);
    _31365 = NOVALUE;
    _30putback(_29553);
    _29553 = NOVALUE;

    /** 			SubProg(TYPE_DECL, scope)*/
    _30SubProg(416, _scope_58483);

    /** 			return {}*/
    RefDS(_21829);
    DeRefDS(_ptok_58515);
    DeRefi(_new_symbols_58484);
    DeRef(_tok_58486);
    DeRef(_tsym_58487);
    DeRef(_prevtok_58488);
    DeRef(_val_58494);
    DeRef(_usedval_58495);
    DeRef(_delta_58497);
    DeRef(_29542);
    _29542 = NOVALUE;
    return _21829;
    goto L4; // [168] 422
L3: 

    /** 		elsif ptok[T_ID] = BY then*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29554 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29554, 404)){
        _29554 = NOVALUE;
        goto L5; // [181] 416
    }
    _29554 = NOVALUE;

    /** 			integer negate = 0*/
    _negate_58531 = 0;

    /** 			ptok = next_token()*/
    _0 = _ptok_58515;
    _ptok_58515 = _30next_token();
    DeRefDS(_0);

    /** 			switch ptok[T_ID] do*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29557 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29557) ){
        goto L6; // [205] 284
    }
    if(!IS_ATOM_INT(_29557)){
        if( (DBL_PTR(_29557)->dbl != (double) ((int) DBL_PTR(_29557)->dbl) ) ){
            goto L6; // [205] 284
        }
        _0 = (int) DBL_PTR(_29557)->dbl;
    }
    else {
        _0 = _29557;
    };
    _29557 = NOVALUE;
    switch ( _0 ){ 

        /** 				case reserved:MULTIPLY then*/
        case 13:

        /** 					deltafunc = '*'*/
        _deltafunc_58496 = 42;

        /** 					ptok = next_token()*/
        _0 = _ptok_58515;
        _ptok_58515 = _30next_token();
        DeRef(_0);
        goto L7; // [226] 292

        /** 				case reserved:DIVIDE then*/
        case 14:

        /** 					deltafunc = '/'*/
        _deltafunc_58496 = 47;

        /** 					ptok = next_token()*/
        _0 = _ptok_58515;
        _ptok_58515 = _30next_token();
        DeRef(_0);
        goto L7; // [244] 292

        /** 				case MINUS then*/
        case 10:

        /** 					deltafunc = '-'*/
        _deltafunc_58496 = 45;

        /** 					ptok = next_token()*/
        _0 = _ptok_58515;
        _ptok_58515 = _30next_token();
        DeRef(_0);
        goto L7; // [262] 292

        /** 				case PLUS then*/
        case 11:

        /** 					deltafunc = '+'*/
        _deltafunc_58496 = 43;

        /** 					ptok = next_token()*/
        _0 = _ptok_58515;
        _ptok_58515 = _30next_token();
        DeRef(_0);
        goto L7; // [280] 292

        /** 				case else*/
        default:
L6: 

        /** 					deltafunc = '+'*/
        _deltafunc_58496 = 43;
    ;}L7: 

    /** 			if ptok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29564 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29564, 10)){
        _29564 = NOVALUE;
        goto L8; // [302] 319
    }
    _29564 = NOVALUE;

    /** 				negate = 1*/
    _negate_58531 = 1;

    /** 				ptok = next_token()*/
    _0 = _ptok_58515;
    _ptok_58515 = _30next_token();
    DeRefDS(_0);
L8: 

    /** 			if ptok[T_ID] != ATOM then*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29567 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29567, 502)){
        _29567 = NOVALUE;
        goto L9; // [329] 341
    }
    _29567 = NOVALUE;

    /** 				CompileErr( 344 )*/
    RefDS(_21829);
    _43CompileErr(344, _21829, 0);
L9: 

    /** 			delta = SymTab[ptok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_ptok_58515);
    _29569 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_29569)){
        _29570 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29569)->dbl));
    }
    else{
        _29570 = (int)*(((s1_ptr)_2)->base + _29569);
    }
    DeRef(_delta_58497);
    _2 = (int)SEQ_PTR(_29570);
    _delta_58497 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_delta_58497);
    _29570 = NOVALUE;

    /** 			if negate then*/
    if (_negate_58531 == 0)
    {
        goto LA; // [363] 372
    }
    else{
    }

    /** 				delta = -delta*/
    _0 = _delta_58497;
    if (IS_ATOM_INT(_delta_58497)) {
        if ((unsigned long)_delta_58497 == 0xC0000000)
        _delta_58497 = (int)NewDouble((double)-0xC0000000);
        else
        _delta_58497 = - _delta_58497;
    }
    else {
        _delta_58497 = unary_op(UMINUS, _delta_58497);
    }
    DeRef(_0);
LA: 

    /** 			switch deltafunc do*/
    _0 = _deltafunc_58496;
    switch ( _0 ){ 

        /** 				case '/' then*/
        case 47:

        /** 					delta = 1 / delta*/
        _0 = _delta_58497;
        if (IS_ATOM_INT(_delta_58497)) {
            _delta_58497 = (1 % _delta_58497) ? NewDouble((double)1 / _delta_58497) : (1 / _delta_58497);
        }
        else {
            _delta_58497 = NewDouble((double)1 / DBL_PTR(_delta_58497)->dbl);
        }
        DeRef(_0);

        /** 					deltafunc = '*'*/
        _deltafunc_58496 = 42;
        goto LB; // [394] 411

        /** 				case '-' then*/
        case 45:

        /** 					delta = -delta*/
        _0 = _delta_58497;
        if (IS_ATOM_INT(_delta_58497)) {
            if ((unsigned long)_delta_58497 == 0xC0000000)
            _delta_58497 = (int)NewDouble((double)-0xC0000000);
            else
            _delta_58497 = - _delta_58497;
        }
        else {
            _delta_58497 = unary_op(UMINUS, _delta_58497);
        }
        DeRef(_0);

        /** 					deltafunc = '+'*/
        _deltafunc_58496 = 43;
    ;}LB: 
    goto L4; // [413] 422
L5: 

    /** 			putback(ptok)*/
    RefDS(_ptok_58515);
    _30putback(_ptok_58515);
L4: 
L2: 
    DeRef(_ptok_58515);
    _ptok_58515 = NOVALUE;

    /** 	valsym = 0*/
    _valsym_58491 = 0;

    /** 	while TRUE do*/
LC: 
    if (_9TRUE_431 == 0)
    {
        goto LD; // [439] 2282
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = DOLLAR then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29578 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29578, -22)){
        _29578 = NOVALUE;
        goto LE; // [457] 496
    }
    _29578 = NOVALUE;

    /** 			if not equal(prevtok, 0) then*/
    if (_prevtok_58488 == 0)
    _29580 = 1;
    else if (IS_ATOM_INT(_prevtok_58488) && IS_ATOM_INT(0))
    _29580 = 0;
    else
    _29580 = (compare(_prevtok_58488, 0) == 0);
    if (_29580 != 0)
    goto LF; // [467] 495
    _29580 = NOVALUE;

    /** 				if prevtok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_prevtok_58488);
    _29582 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29582, -30)){
        _29582 = NOVALUE;
        goto L10; // [480] 494
    }
    _29582 = NOVALUE;

    /** 					tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /** 					exit*/
    goto LD; // [491] 2282
L10: 
LF: 
LE: 

    /** 		if tok[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29585 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29585, -21)){
        _29585 = NOVALUE;
        goto L11; // [506] 518
    }
    _29585 = NOVALUE;

    /** 			CompileErr( 32 )*/
    RefDS(_21829);
    _43CompileErr(32, _21829, 0);
L11: 

    /** 		if not find(tok[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29587 = (int)*(((s1_ptr)_2)->base + 1);
    _29588 = find_from(_29587, _28ADDR_TOKS_11306, 1);
    _29587 = NOVALUE;
    if (_29588 != 0)
    goto L12; // [533] 558
    _29588 = NOVALUE;

    /** 			CompileErr(25, {find_category(tok[T_ID])} )*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29590 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29590);
    _29591 = _62find_category(_29590);
    _29590 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29591;
    _29592 = MAKE_SEQ(_1);
    _29591 = NOVALUE;
    _43CompileErr(25, _29592, 0);
    _29592 = NOVALUE;
L12: 

    /** 		sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _sym_58490 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_58490)){
        _sym_58490 = (long)DBL_PTR(_sym_58490)->dbl;
    }

    /** 		DefinedYet(sym)*/
    _52DefinedYet(_sym_58490);

    /** 		if find(SymTab[sym][S_SCOPE], {SC_GLOBAL, SC_PREDEF, SC_PUBLIC, SC_EXPORT}) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29594 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29594);
    _29595 = (int)*(((s1_ptr)_2)->base + 4);
    _29594 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 7;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    _29596 = MAKE_SEQ(_1);
    _29597 = find_from(_29595, _29596, 1);
    _29595 = NOVALUE;
    DeRefDS(_29596);
    _29596 = NOVALUE;
    if (_29597 == 0)
    {
        _29597 = NOVALUE;
        goto L13; // [607] 669
    }
    else{
        _29597 = NOVALUE;
    }

    /** 			h = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29598 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29598);
    _h_58492 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_58492)){
        _h_58492 = (long)DBL_PTR(_h_58492)->dbl;
    }
    _29598 = NOVALUE;

    /** 			sym = NewEntry(SymTab[sym][S_NAME], 0, 0, VARIABLE, h, buckets[h], 0)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29600 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29600);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _29601 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _29601 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _29600 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _29602 = (int)*(((s1_ptr)_2)->base + _h_58492);
    Ref(_29601);
    Ref(_29602);
    _sym_58490 = _52NewEntry(_29601, 0, 0, -100, _h_58492, _29602, 0);
    _29601 = NOVALUE;
    _29602 = NOVALUE;
    if (!IS_ATOM_INT(_sym_58490)) {
        _1 = (long)(DBL_PTR(_sym_58490)->dbl);
        DeRefDS(_sym_58490);
        _sym_58490 = _1;
    }

    /** 			buckets[h] = sym*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _2 = (int)(((s1_ptr)_2)->base + _h_58492);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58490;
    DeRef(_1);
L13: 

    /** 		new_symbols = append(new_symbols, sym)*/
    Append(&_new_symbols_58484, _new_symbols_58484, _sym_58490);

    /** 		Block_var( sym )*/
    _65Block_var(_sym_58490);

    /** 		if SymTab[sym][S_SCOPE] = SC_UNDEFINED and SymTab[sym][S_FILE_NO] != current_file_no then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29605 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29605);
    _29606 = (int)*(((s1_ptr)_2)->base + 4);
    _29605 = NOVALUE;
    if (IS_ATOM_INT(_29606)) {
        _29607 = (_29606 == 9);
    }
    else {
        _29607 = binary_op(EQUALS, _29606, 9);
    }
    _29606 = NOVALUE;
    if (IS_ATOM_INT(_29607)) {
        if (_29607 == 0) {
            goto L14; // [700] 744
        }
    }
    else {
        if (DBL_PTR(_29607)->dbl == 0.0) {
            goto L14; // [700] 744
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29609 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29609);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _29610 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _29610 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _29609 = NOVALUE;
    if (IS_ATOM_INT(_29610)) {
        _29611 = (_29610 != _12current_file_no_11682);
    }
    else {
        _29611 = binary_op(NOTEQ, _29610, _12current_file_no_11682);
    }
    _29610 = NOVALUE;
    if (_29611 == 0) {
        DeRef(_29611);
        _29611 = NOVALUE;
        goto L14; // [723] 744
    }
    else {
        if (!IS_ATOM_INT(_29611) && DBL_PTR(_29611)->dbl == 0.0){
            DeRef(_29611);
            _29611 = NOVALUE;
            goto L14; // [723] 744
        }
        DeRef(_29611);
        _29611 = NOVALUE;
    }
    DeRef(_29611);
    _29611 = NOVALUE;

    /** 			SymTab[sym][S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_11350))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);
    _29612 = NOVALUE;
L14: 

    /** 		SymTab[sym][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_58483;
    DeRef(_1);
    _29614 = NOVALUE;

    /** 		if type_ptr = 0 then*/
    if (_type_ptr_58482 != 0)
    goto L15; // [761] 1096

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29617 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29619 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29619);
    _29620 = (int)*(((s1_ptr)_2)->base + 11);
    _29619 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29621 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29621);
    _29622 = (int)*(((s1_ptr)_2)->base + 9);
    _29621 = NOVALUE;
    Ref(_29622);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_29620))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29620)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29620);
    _1 = *(int *)_2;
    *(int *)_2 = _29622;
    if( _1 != _29622 ){
        DeRef(_1);
    }
    _29622 = NOVALUE;

    /** 			tok_match(EQUALS)*/
    _30tok_match(3, 0);

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _37StartSourceLine(_9FALSE_429, 0, 3);

    /** 			emit_opnd(sym)*/
    _37emit_opnd(_sym_58490);

    /** 			Expr()  -- no new symbols can be defined in here*/
    _30Expr();

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29623 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29623);
    _29624 = (int)*(((s1_ptr)_2)->base + 11);
    _29623 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_29624))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29624)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29624);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58490;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29625 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L16; // [883] 921
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29627 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    _29629 = NOVALUE;
L16: 

    /** 			valsym = Top()*/
    _valsym_58491 = _37Top();
    if (!IS_ATOM_INT(_valsym_58491)) {
        _1 = (long)(DBL_PTR(_valsym_58491)->dbl);
        DeRefDS(_valsym_58491);
        _valsym_58491 = _1;
    }

    /** 			if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29632 = (_valsym_58491 > 0);
    if (_29632 == 0) {
        goto L17; // [934] 975
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29634 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29634);
    _29635 = (int)*(((s1_ptr)_2)->base + 1);
    _29634 = NOVALUE;
    if (IS_ATOM_INT(_29635) && IS_ATOM_INT(_12NOVALUE_11536)){
        _29636 = (_29635 < _12NOVALUE_11536) ? -1 : (_29635 > _12NOVALUE_11536);
    }
    else{
        _29636 = compare(_29635, _12NOVALUE_11536);
    }
    _29635 = NOVALUE;
    if (_29636 == 0)
    {
        _29636 = NOVALUE;
        goto L17; // [957] 975
    }
    else{
        _29636 = NOVALUE;
    }

    /** 				Assign_Constant( sym )*/
    _30Assign_Constant(_sym_58490);

    /** 				sym = Pop()*/
    _sym_58490 = _37Pop();
    if (!IS_ATOM_INT(_sym_58490)) {
        _1 = (long)(DBL_PTR(_sym_58490)->dbl);
        DeRefDS(_sym_58490);
        _sym_58490 = _1;
    }
    goto L18; // [972] 2248
L17: 

    /** 				emit_op(ASSIGN)*/
    _37emit_op(18);

    /** 				if Last_op() = ASSIGN then*/
    _29638 = _37Last_op();
    if (binary_op_a(NOTEQ, _29638, 18)){
        DeRef(_29638);
        _29638 = NOVALUE;
        goto L19; // [989] 1003
    }
    DeRef(_29638);
    _29638 = NOVALUE;

    /** 					valsym = get_assigned_sym()*/
    _valsym_58491 = _30get_assigned_sym();
    if (!IS_ATOM_INT(_valsym_58491)) {
        _1 = (long)(DBL_PTR(_valsym_58491)->dbl);
        DeRefDS(_valsym_58491);
        _valsym_58491 = _1;
    }
    goto L1A; // [1000] 1011
L19: 

    /** 					valsym = -1*/
    _valsym_58491 = -1;
L1A: 

    /** 				if valsym > 0 and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    _29641 = (_valsym_58491 > 0);
    if (_29641 == 0) {
        goto L1B; // [1017] 1059
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29643 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29643);
    _29644 = (int)*(((s1_ptr)_2)->base + 1);
    _29643 = NOVALUE;
    if (IS_ATOM_INT(_29644) && IS_ATOM_INT(_12NOVALUE_11536)){
        _29645 = (_29644 < _12NOVALUE_11536) ? -1 : (_29644 > _12NOVALUE_11536);
    }
    else{
        _29645 = compare(_29644, _12NOVALUE_11536);
    }
    _29644 = NOVALUE;
    if (_29645 == 0)
    {
        _29645 = NOVALUE;
        goto L1B; // [1040] 1059
    }
    else{
        _29645 = NOVALUE;
    }

    /** 					SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58491;
    DeRef(_1);
    _29646 = NOVALUE;
L1B: 

    /** 				if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L18; // [1063] 2248
    }
    else{
    }

    /** 					count += 1*/
    _count_58493 = _count_58493 + 1;

    /** 					if count = 10 then*/
    if (_count_58493 != 10)
    goto L18; // [1074] 2248

    /** 						count = 0*/
    _count_58493 = 0;

    /** 						emit_op( RETURNT )*/
    _37emit_op(34);
    goto L18; // [1093] 2248
L15: 

    /** 		elsif type_ptr = -1 and not is_fwd_ref then*/
    _29650 = (_type_ptr_58482 == -1);
    if (_29650 == 0) {
        goto L1C; // [1102] 2075
    }
    _29652 = (_is_fwd_ref_58498 == 0);
    if (_29652 == 0)
    {
        DeRef(_29652);
        _29652 = NOVALUE;
        goto L1C; // [1110] 2075
    }
    else{
        DeRef(_29652);
        _29652 = NOVALUE;
    }

    /** 			StartSourceLine(FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_429, 0, 3);

    /** 			SymTab[sym][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29653 = NOVALUE;

    /** 			buckets[SymTab[sym][S_HASHVAL]] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29655 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29655);
    _29656 = (int)*(((s1_ptr)_2)->base + 11);
    _29655 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29657 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29657);
    _29658 = (int)*(((s1_ptr)_2)->base + 9);
    _29657 = NOVALUE;
    Ref(_29658);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_29656))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29656)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29656);
    _1 = *(int *)_2;
    *(int *)_2 = _29658;
    if( _1 != _29658 ){
        DeRef(_1);
    }
    _29658 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /** 			emit_opnd(sym)*/
    _37emit_opnd(_sym_58490);

    /** 			if tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29660 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29660, 3)){
        _29660 = NOVALUE;
        goto L1D; // [1193] 1588
    }
    _29660 = NOVALUE;

    /** 				integer negate = 1*/
    _negate_58777 = 1;

    /** 				tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = MINUS then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29663 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29663, 10)){
        _29663 = NOVALUE;
        goto L1E; // [1217] 1232
    }
    _29663 = NOVALUE;

    /** 					negate = -1*/
    _negate_58777 = -1;

    /** 					tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);
L1E: 

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29666 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29666, 502)){
        _29666 = NOVALUE;
        goto L1F; // [1242] 1259
    }
    _29666 = NOVALUE;

    /** 					valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _valsym_58491 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58491)){
        _valsym_58491 = (long)DBL_PTR(_valsym_58491)->dbl;
    }
    goto L20; // [1256] 1448
L1F: 

    /** 				elsif tok[T_SYM] > 0 then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29669 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(LESSEQ, _29669, 0)){
        _29669 = NOVALUE;
        goto L21; // [1267] 1440
    }
    _29669 = NOVALUE;

    /** 					tsym = SymTab[tok[T_SYM]]*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29671 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_tsym_58487);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_29671)){
        _tsym_58487 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29671)->dbl));
    }
    else{
        _tsym_58487 = (int)*(((s1_ptr)_2)->base + _29671);
    }
    Ref(_tsym_58487);

    /** 					if tsym[S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_tsym_58487);
    _29673 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _29673, 2)){
        _29673 = NOVALUE;
        goto L22; // [1295] 1403
    }
    _29673 = NOVALUE;

    /** 						if length(tsym) >= S_CODE and tsym[S_CODE] then*/
    if (IS_SEQUENCE(_tsym_58487)){
            _29675 = SEQ_PTR(_tsym_58487)->length;
    }
    else {
        _29675 = 1;
    }
    if (IS_ATOM_INT(_12S_CODE_11366)) {
        _29676 = (_29675 >= _12S_CODE_11366);
    }
    else {
        _29676 = binary_op(GREATEREQ, _29675, _12S_CODE_11366);
    }
    _29675 = NOVALUE;
    if (IS_ATOM_INT(_29676)) {
        if (_29676 == 0) {
            goto L23; // [1310] 1337
        }
    }
    else {
        if (DBL_PTR(_29676)->dbl == 0.0) {
            goto L23; // [1310] 1337
        }
    }
    _2 = (int)SEQ_PTR(_tsym_58487);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _29678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _29678 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    if (_29678 == 0) {
        _29678 = NOVALUE;
        goto L23; // [1321] 1337
    }
    else {
        if (!IS_ATOM_INT(_29678) && DBL_PTR(_29678)->dbl == 0.0){
            _29678 = NOVALUE;
            goto L23; // [1321] 1337
        }
        _29678 = NOVALUE;
    }
    _29678 = NOVALUE;

    /** 							valsym = tsym[S_CODE]*/
    _2 = (int)SEQ_PTR(_tsym_58487);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _valsym_58491 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _valsym_58491 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    if (!IS_ATOM_INT(_valsym_58491)){
        _valsym_58491 = (long)DBL_PTR(_valsym_58491)->dbl;
    }
    goto L20; // [1334] 1448
L23: 

    /** 						elsif not equal( tsym[S_OBJ], NOVALUE ) then*/
    _2 = (int)SEQ_PTR(_tsym_58487);
    _29680 = (int)*(((s1_ptr)_2)->base + 1);
    if (_29680 == _12NOVALUE_11536)
    _29681 = 1;
    else if (IS_ATOM_INT(_29680) && IS_ATOM_INT(_12NOVALUE_11536))
    _29681 = 0;
    else
    _29681 = (compare(_29680, _12NOVALUE_11536) == 0);
    _29680 = NOVALUE;
    if (_29681 != 0)
    goto L24; // [1351] 1392
    _29681 = NOVALUE;

    /** 							if integer(tsym[S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tsym_58487);
    _29683 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_29683))
    _29684 = 1;
    else if (IS_ATOM_DBL(_29683))
    _29684 = IS_ATOM_INT(DoubleToInt(_29683));
    else
    _29684 = 0;
    _29683 = NOVALUE;
    if (_29684 == 0)
    {
        _29684 = NOVALUE;
        goto L25; // [1365] 1381
    }
    else{
        _29684 = NOVALUE;
    }

    /** 								valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _valsym_58491 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58491)){
        _valsym_58491 = (long)DBL_PTR(_valsym_58491)->dbl;
    }
    goto L20; // [1378] 1448
L25: 

    /** 								CompileErr(30)*/
    RefDS(_21829);
    _43CompileErr(30, _21829, 0);
    goto L20; // [1389] 1448
L24: 

    /** 							CompileErr(70)*/
    RefDS(_21829);
    _43CompileErr(70, _21829, 0);
    goto L20; // [1400] 1448
L22: 

    /** 					elsif tsym[S_OBJ] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_tsym_58487);
    _29686 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29686, _12NOVALUE_11536)){
        _29686 = NOVALUE;
        goto L26; // [1413] 1429
    }
    _29686 = NOVALUE;

    /** 						CompileErr(ENUM_FWD_REFERENCES_NOT_SUPPORTED)*/
    RefDS(_21829);
    _43CompileErr(331, _21829, 0);
    goto L20; // [1426] 1448
L26: 

    /** 						CompileErr(99)*/
    RefDS(_21829);
    _43CompileErr(99, _21829, 0);
    goto L20; // [1437] 1448
L21: 

    /** 						CompileErr(99)*/
    RefDS(_21829);
    _43CompileErr(99, _21829, 0);
L20: 

    /** 				valsym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _valsym_58491 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_valsym_58491)){
        _valsym_58491 = (long)DBL_PTR(_valsym_58491)->dbl;
    }

    /** 				if not atom( SymTab[valsym][S_OBJ] ) and tsym[S_SCOPE] != SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29689 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29689);
    _29690 = (int)*(((s1_ptr)_2)->base + 1);
    _29689 = NOVALUE;
    _29691 = IS_ATOM(_29690);
    _29690 = NOVALUE;
    _29692 = (_29691 == 0);
    _29691 = NOVALUE;
    if (_29692 == 0) {
        goto L27; // [1478] 1508
    }
    _2 = (int)SEQ_PTR(_tsym_58487);
    _29694 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_29694)) {
        _29695 = (_29694 != 9);
    }
    else {
        _29695 = binary_op(NOTEQ, _29694, 9);
    }
    _29694 = NOVALUE;
    if (_29695 == 0) {
        DeRef(_29695);
        _29695 = NOVALUE;
        goto L27; // [1497] 1508
    }
    else {
        if (!IS_ATOM_INT(_29695) && DBL_PTR(_29695)->dbl == 0.0){
            DeRef(_29695);
            _29695 = NOVALUE;
            goto L27; // [1497] 1508
        }
        DeRef(_29695);
        _29695 = NOVALUE;
    }
    DeRef(_29695);
    _29695 = NOVALUE;

    /** 					CompileErr(84)*/
    RefDS(_21829);
    _43CompileErr(84, _21829, 0);
L27: 

    /** 				val = SymTab[valsym][S_OBJ] * negate*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29696 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29696);
    _29697 = (int)*(((s1_ptr)_2)->base + 1);
    _29696 = NOVALUE;
    DeRef(_val_58494);
    if (IS_ATOM_INT(_29697)) {
        if (_29697 == (short)_29697 && _negate_58777 <= INT15 && _negate_58777 >= -INT15)
        _val_58494 = _29697 * _negate_58777;
        else
        _val_58494 = NewDouble(_29697 * (double)_negate_58777);
    }
    else {
        _val_58494 = binary_op(MULTIPLY, _29697, _negate_58777);
    }
    _29697 = NOVALUE;

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58494))
    _29699 = 1;
    else if (IS_ATOM_DBL(_val_58494))
    _29699 = IS_ATOM_INT(DoubleToInt(_val_58494));
    else
    _29699 = 0;
    if (_29699 == 0)
    {
        _29699 = NOVALUE;
        goto L28; // [1531] 1546
    }
    else{
        _29699 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58494);
    _29700 = _52NewIntSym(_val_58494);
    _37Push(_29700);
    _29700 = NOVALUE;
    goto L29; // [1543] 1556
L28: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58494);
    _29701 = _52NewDoubleSym(_val_58494);
    _37Push(_29701);
    _29701 = NOVALUE;
L29: 

    /** 				usedval = val*/
    Ref(_val_58494);
    DeRef(_usedval_58495);
    _usedval_58495 = _val_58494;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58496 != 43)
    goto L2A; // [1563] 1576

    /** 					val += delta*/
    _0 = _val_58494;
    if (IS_ATOM_INT(_val_58494) && IS_ATOM_INT(_delta_58497)) {
        _val_58494 = _val_58494 + _delta_58497;
        if ((long)((unsigned long)_val_58494 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58494 = NewDouble((double)_val_58494);
    }
    else {
        if (IS_ATOM_INT(_val_58494)) {
            _val_58494 = NewDouble((double)_val_58494 + DBL_PTR(_delta_58497)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58497)) {
                _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl + (double)_delta_58497);
            }
            else
            _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl + DBL_PTR(_delta_58497)->dbl);
        }
    }
    DeRef(_0);
    goto L2B; // [1573] 1583
L2A: 

    /** 					val *= delta*/
    _0 = _val_58494;
    if (IS_ATOM_INT(_val_58494) && IS_ATOM_INT(_delta_58497)) {
        if (_val_58494 == (short)_val_58494 && _delta_58497 <= INT15 && _delta_58497 >= -INT15)
        _val_58494 = _val_58494 * _delta_58497;
        else
        _val_58494 = NewDouble(_val_58494 * (double)_delta_58497);
    }
    else {
        if (IS_ATOM_INT(_val_58494)) {
            _val_58494 = NewDouble((double)_val_58494 * DBL_PTR(_delta_58497)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58497)) {
                _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl * (double)_delta_58497);
            }
            else
            _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl * DBL_PTR(_delta_58497)->dbl);
        }
    }
    DeRef(_0);
L2B: 
    goto L2C; // [1585] 1658
L1D: 

    /** 				putback(tok)*/
    Ref(_tok_58486);
    _30putback(_tok_58486);

    /** 				if integer(val) then*/
    if (IS_ATOM_INT(_val_58494))
    _29705 = 1;
    else if (IS_ATOM_DBL(_val_58494))
    _29705 = IS_ATOM_INT(DoubleToInt(_val_58494));
    else
    _29705 = 0;
    if (_29705 == 0)
    {
        _29705 = NOVALUE;
        goto L2D; // [1598] 1613
    }
    else{
        _29705 = NOVALUE;
    }

    /** 					Push(NewIntSym(val))*/
    Ref(_val_58494);
    _29706 = _52NewIntSym(_val_58494);
    _37Push(_29706);
    _29706 = NOVALUE;
    goto L2E; // [1610] 1623
L2D: 

    /** 					Push(NewDoubleSym(val))*/
    Ref(_val_58494);
    _29707 = _52NewDoubleSym(_val_58494);
    _37Push(_29707);
    _29707 = NOVALUE;
L2E: 

    /** 				usedval = val*/
    Ref(_val_58494);
    DeRef(_usedval_58495);
    _usedval_58495 = _val_58494;

    /** 				if deltafunc = '+' then*/
    if (_deltafunc_58496 != 43)
    goto L2F; // [1630] 1643

    /** 					val += delta*/
    _0 = _val_58494;
    if (IS_ATOM_INT(_val_58494) && IS_ATOM_INT(_delta_58497)) {
        _val_58494 = _val_58494 + _delta_58497;
        if ((long)((unsigned long)_val_58494 + (unsigned long)HIGH_BITS) >= 0) 
        _val_58494 = NewDouble((double)_val_58494);
    }
    else {
        if (IS_ATOM_INT(_val_58494)) {
            _val_58494 = NewDouble((double)_val_58494 + DBL_PTR(_delta_58497)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58497)) {
                _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl + (double)_delta_58497);
            }
            else
            _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl + DBL_PTR(_delta_58497)->dbl);
        }
    }
    DeRef(_0);
    goto L30; // [1640] 1650
L2F: 

    /** 					val *= delta*/
    _0 = _val_58494;
    if (IS_ATOM_INT(_val_58494) && IS_ATOM_INT(_delta_58497)) {
        if (_val_58494 == (short)_val_58494 && _delta_58497 <= INT15 && _delta_58497 >= -INT15)
        _val_58494 = _val_58494 * _delta_58497;
        else
        _val_58494 = NewDouble(_val_58494 * (double)_delta_58497);
    }
    else {
        if (IS_ATOM_INT(_val_58494)) {
            _val_58494 = NewDouble((double)_val_58494 * DBL_PTR(_delta_58497)->dbl);
        }
        else {
            if (IS_ATOM_INT(_delta_58497)) {
                _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl * (double)_delta_58497);
            }
            else
            _val_58494 = NewDouble(DBL_PTR(_val_58494)->dbl * DBL_PTR(_delta_58497)->dbl);
        }
    }
    DeRef(_0);
L30: 

    /** 				valsym = 0*/
    _valsym_58491 = 0;
L2C: 

    /** 			buckets[SymTab[sym][S_HASHVAL]] = sym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29711 = (int)*(((s1_ptr)_2)->base + _sym_58490);
    _2 = (int)SEQ_PTR(_29711);
    _29712 = (int)*(((s1_ptr)_2)->base + 11);
    _29711 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_29712))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29712)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _29712);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_58490;
    DeRef(_1);

    /** 			SymTab[sym][S_USAGE] = U_WRITTEN*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29713 = NOVALUE;

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L31; // [1699] 1737
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _29715 = NOVALUE;

    /** 				SymTab[sym][S_OBJ] = NOVALUE     -- distinguish from literals*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    _29717 = NOVALUE;
L31: 

    /** 			if valsym < 0 then*/
    if (_valsym_58491 >= 0)
    goto L32; // [1739] 1744
L32: 

    /** 			if valsym and compare( SymTab[valsym][S_OBJ], NOVALUE ) then*/
    if (_valsym_58491 == 0) {
        goto L33; // [1746] 1926
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29721 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29721);
    _29722 = (int)*(((s1_ptr)_2)->base + 1);
    _29721 = NOVALUE;
    if (IS_ATOM_INT(_29722) && IS_ATOM_INT(_12NOVALUE_11536)){
        _29723 = (_29722 < _12NOVALUE_11536) ? -1 : (_29722 > _12NOVALUE_11536);
    }
    else{
        _29723 = compare(_29722, _12NOVALUE_11536);
    }
    _29722 = NOVALUE;
    if (_29723 == 0)
    {
        _29723 = NOVALUE;
        goto L33; // [1769] 1926
    }
    else{
        _29723 = NOVALUE;
    }

    /** 				SymTab[sym][S_CODE] = valsym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _valsym_58491;
    DeRef(_1);
    _29724 = NOVALUE;

    /** 				SymTab[sym][S_OBJ]  = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29726 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L34; // [1808] 2058
    }
    else{
    }

    /** 					SymTab[sym][S_GTYPE] = SymTab[valsym][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29730 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29730);
    _29731 = (int)*(((s1_ptr)_2)->base + 36);
    _29730 = NOVALUE;
    Ref(_29731);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29731;
    if( _1 != _29731 ){
        DeRef(_1);
    }
    _29731 = NOVALUE;
    _29728 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_ELEM] = SymTab[valsym][S_SEQ_ELEM]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29734 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29734);
    _29735 = (int)*(((s1_ptr)_2)->base + 33);
    _29734 = NOVALUE;
    Ref(_29735);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _29735;
    if( _1 != _29735 ){
        DeRef(_1);
    }
    _29735 = NOVALUE;
    _29732 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29736 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29738 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29742 = (int)*(((s1_ptr)_2)->base + _valsym_58491);
    _2 = (int)SEQ_PTR(_29742);
    _29743 = (int)*(((s1_ptr)_2)->base + 32);
    _29742 = NOVALUE;
    Ref(_29743);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _29743;
    if( _1 != _29743 ){
        DeRef(_1);
    }
    _29743 = NOVALUE;
    _29740 = NOVALUE;
    goto L34; // [1923] 2058
L33: 

    /** 				SymTab[sym][S_OBJ] = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29744 = NOVALUE;

    /** 				if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L35; // [1947] 2057
    }
    else{
    }

    /** 					if integer( usedval ) then*/
    if (IS_ATOM_INT(_usedval_58495))
    _29746 = 1;
    else if (IS_ATOM_DBL(_usedval_58495))
    _29746 = IS_ATOM_INT(DoubleToInt(_usedval_58495));
    else
    _29746 = 0;
    if (_29746 == 0)
    {
        _29746 = NOVALUE;
        goto L36; // [1955] 1978
    }
    else{
        _29746 = NOVALUE;
    }

    /** 						SymTab[sym][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29747 = NOVALUE;
    goto L37; // [1975] 1996
L36: 

    /** 						SymTab[sym][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _29749 = NOVALUE;
L37: 

    /** 					SymTab[sym][S_SEQ_ELEM] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29751 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MIN] = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29753 = NOVALUE;

    /** 					SymTab[sym][S_OBJ_MAX] = usedval*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    Ref(_usedval_58495);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _usedval_58495;
    DeRef(_1);
    _29755 = NOVALUE;

    /** 					SymTab[sym][S_SEQ_LEN] = 0 --SymTab[valsym][S_SEQ_LEN]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _29757 = NOVALUE;
L35: 
L34: 

    /** 			valsym = Pop()*/
    _valsym_58491 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58491)) {
        _1 = (long)(DBL_PTR(_valsym_58491)->dbl);
        DeRefDS(_valsym_58491);
        _valsym_58491 = _1;
    }

    /** 			valsym = Pop()*/
    _valsym_58491 = _37Pop();
    if (!IS_ATOM_INT(_valsym_58491)) {
        _1 = (long)(DBL_PTR(_valsym_58491)->dbl);
        DeRefDS(_valsym_58491);
        _valsym_58491 = _1;
    }
    goto L18; // [2072] 2248
L1C: 

    /** 			SymTab[sym][S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _29761 = NOVALUE;

    /** 			if type_ptr > 0 and SymTab[type_ptr][S_TOKEN] = OBJECT then*/
    _29763 = (_type_ptr_58482 > 0);
    if (_29763 == 0) {
        goto L38; // [2098] 2144
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29765 = (int)*(((s1_ptr)_2)->base + _type_ptr_58482);
    _2 = (int)SEQ_PTR(_29765);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _29766 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _29766 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _29765 = NOVALUE;
    if (IS_ATOM_INT(_29766)) {
        _29767 = (_29766 == 415);
    }
    else {
        _29767 = binary_op(EQUALS, _29766, 415);
    }
    _29766 = NOVALUE;
    if (_29767 == 0) {
        DeRef(_29767);
        _29767 = NOVALUE;
        goto L38; // [2121] 2144
    }
    else {
        if (!IS_ATOM_INT(_29767) && DBL_PTR(_29767)->dbl == 0.0){
            DeRef(_29767);
            _29767 = NOVALUE;
            goto L38; // [2121] 2144
        }
        DeRef(_29767);
        _29767 = NOVALUE;
    }
    DeRef(_29767);
    _29767 = NOVALUE;

    /** 				SymTab[sym][S_VTYPE] = object_type*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _52object_type_45731;
    DeRef(_1);
    _29768 = NOVALUE;
    goto L39; // [2141] 2173
L38: 

    /** 				SymTab[sym][S_VTYPE] = type_ptr*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_ptr_58482;
    DeRef(_1);
    _29770 = NOVALUE;

    /** 				if type_ptr < 0 then*/
    if (_type_ptr_58482 >= 0)
    goto L3A; // [2161] 2172

    /** 					register_forward_type( sym, type_ptr )*/
    _29register_forward_type(_sym_58490, _type_ptr_58482);
L3A: 
L39: 

    /** 			if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3B; // [2177] 2200
    }
    else{
    }

    /** 				SymTab[sym][S_GTYPE] = CompileType(type_ptr)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_58490 + ((s1_ptr)_2)->base);
    _29775 = _30CompileType(_type_ptr_58482);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29775;
    if( _1 != _29775 ){
        DeRef(_1);
    }
    _29775 = NOVALUE;
    _29773 = NOVALUE;
L3B: 

    /** 	   		tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /**    			putback(tok)*/
    Ref(_tok_58486);
    _30putback(_tok_58486);

    /** 	   		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29777 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29777, 3)){
        _29777 = NOVALUE;
        goto L3C; // [2220] 2247
    }
    _29777 = NOVALUE;

    /** 	   			StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_429, 0, 3);

    /** 	   			Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_58490;
    _29779 = MAKE_SEQ(_1);
    _30Assignment(_29779);
    _29779 = NOVALUE;
L3C: 
L18: 

    /** 		tok = next_token()*/
    _0 = _tok_58486;
    _tok_58486 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_58486);
    _29781 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29781, -30)){
        _29781 = NOVALUE;
        goto L3D; // [2263] 2272
    }
    _29781 = NOVALUE;

    /** 			exit*/
    goto LD; // [2269] 2282
L3D: 

    /** 		prevtok = tok*/
    Ref(_tok_58486);
    DeRef(_prevtok_58488);
    _prevtok_58488 = _tok_58486;

    /** 	end while*/
    goto LC; // [2279] 437
LD: 

    /** 	putback(tok)*/
    Ref(_tok_58486);
    _30putback(_tok_58486);

    /** 	return new_symbols*/
    DeRef(_tok_58486);
    DeRef(_tsym_58487);
    DeRef(_prevtok_58488);
    DeRef(_val_58494);
    DeRef(_usedval_58495);
    DeRef(_delta_58497);
    DeRef(_29542);
    _29542 = NOVALUE;
    _29569 = NOVALUE;
    _29620 = NOVALUE;
    DeRef(_29607);
    _29607 = NOVALUE;
    _29624 = NOVALUE;
    DeRef(_29632);
    _29632 = NOVALUE;
    DeRef(_29641);
    _29641 = NOVALUE;
    DeRef(_29650);
    _29650 = NOVALUE;
    _29656 = NOVALUE;
    _29671 = NOVALUE;
    DeRef(_29676);
    _29676 = NOVALUE;
    DeRef(_29692);
    _29692 = NOVALUE;
    _29712 = NOVALUE;
    DeRef(_29763);
    _29763 = NOVALUE;
    return _new_symbols_58484;
    ;
}


void _30Private_declaration(int _type_sym_59059)
{
    int _tok_59061 = NOVALUE;
    int _sym_59063 = NOVALUE;
    int _31363 = NOVALUE;
    int _31362 = NOVALUE;
    int _31361 = NOVALUE;
    int _29807 = NOVALUE;
    int _29805 = NOVALUE;
    int _29803 = NOVALUE;
    int _29801 = NOVALUE;
    int _29799 = NOVALUE;
    int _29797 = NOVALUE;
    int _29795 = NOVALUE;
    int _29792 = NOVALUE;
    int _29790 = NOVALUE;
    int _29789 = NOVALUE;
    int _29786 = NOVALUE;
    int _29784 = NOVALUE;
    int _29783 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_type_sym_59059)) {
        _1 = (long)(DBL_PTR(_type_sym_59059)->dbl);
        DeRefDS(_type_sym_59059);
        _type_sym_59059 = _1;
    }

    /** 	if SymTab[type_sym][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29783 = (int)*(((s1_ptr)_2)->base + _type_sym_59059);
    _2 = (int)SEQ_PTR(_29783);
    _29784 = (int)*(((s1_ptr)_2)->base + 4);
    _29783 = NOVALUE;
    if (binary_op_a(NOTEQ, _29784, 9)){
        _29784 = NOVALUE;
        goto L1; // [19] 47
    }
    _29784 = NOVALUE;

    /** 		Hide( type_sym )*/
    _52Hide(_type_sym_59059);

    /** 		type_sym = -new_forward_reference( TYPE, type_sym )*/
    _31363 = 504;
    _29786 = _29new_forward_reference(504, _type_sym_59059, 504);
    _31363 = NOVALUE;
    if (IS_ATOM_INT(_29786)) {
        if ((unsigned long)_29786 == 0xC0000000)
        _type_sym_59059 = (int)NewDouble((double)-0xC0000000);
        else
        _type_sym_59059 = - _29786;
    }
    else {
        _type_sym_59059 = unary_op(UMINUS, _29786);
    }
    DeRef(_29786);
    _29786 = NOVALUE;
    if (!IS_ATOM_INT(_type_sym_59059)) {
        _1 = (long)(DBL_PTR(_type_sym_59059)->dbl);
        DeRefDS(_type_sym_59059);
        _type_sym_59059 = _1;
    }
L1: 

    /** 	while TRUE do*/
L2: 
    if (_9TRUE_431 == 0)
    {
        goto L3; // [54] 255
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59061;
    _tok_59061 = _30next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29789 = (int)*(((s1_ptr)_2)->base + 1);
    _29790 = find_from(_29789, _28ID_TOKS_11308, 1);
    _29789 = NOVALUE;
    if (_29790 != 0)
    goto L4; // [77] 88
    _29790 = NOVALUE;

    /** 			CompileErr(24)*/
    RefDS(_21829);
    _43CompileErr(24, _21829, 0);
L4: 

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29792 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29792);
    _sym_59063 = _30SetPrivateScope(_29792, _type_sym_59059, _30param_num_53694);
    _29792 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59063)) {
        _1 = (long)(DBL_PTR(_sym_59063)->dbl);
        DeRefDS(_sym_59063);
        _sym_59063 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_53694 = _30param_num_53694 + 1;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L5; // [118] 141
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59063 + ((s1_ptr)_2)->base);
    _29797 = _30CompileType(_type_sym_59059);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _29797;
    if( _1 != _29797 ){
        DeRef(_1);
    }
    _29797 = NOVALUE;
    _29795 = NOVALUE;
L5: 

    /**    		tok = next_token()*/
    _0 = _tok_59061;
    _tok_59061 = _30next_token();
    DeRef(_0);

    /**    		if tok[T_ID] = EQUALS then -- assign on declare*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29799 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29799, 3)){
        _29799 = NOVALUE;
        goto L6; // [156] 231
    }
    _29799 = NOVALUE;

    /** 		    putback(tok)*/
    Ref(_tok_59061);
    _30putback(_tok_59061);

    /** 		    StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 		    Assignment({VARIABLE,sym})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _sym_59063;
    _29801 = MAKE_SEQ(_1);
    _30Assignment(_29801);
    _29801 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59061;
    _tok_59061 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID]=IGNORED then*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29803 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29803, 509)){
        _29803 = NOVALUE;
        goto L7; // [200] 230
    }
    _29803 = NOVALUE;

    /** 				tok = keyfind(tok[T_SYM],-1)*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29805 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29805);
    DeRef(_31361);
    _31361 = _29805;
    _31362 = _52hashfn(_31361);
    _31361 = NOVALUE;
    Ref(_29805);
    _0 = _tok_59061;
    _tok_59061 = _52keyfind(_29805, -1, _12current_file_no_11682, 0, _31362);
    DeRef(_0);
    _29805 = NOVALUE;
    _31362 = NOVALUE;
L7: 
L6: 

    /** 		if tok[T_ID] != COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59061);
    _29807 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _29807, -30)){
        _29807 = NOVALUE;
        goto L2; // [241] 52
    }
    _29807 = NOVALUE;

    /** 			exit*/
    goto L3; // [247] 255

    /** 	end while*/
    goto L2; // [252] 52
L3: 

    /** 	putback(tok)*/
    Ref(_tok_59061);
    _30putback(_tok_59061);

    /** end procedure*/
    DeRef(_tok_59061);
    return;
    ;
}


void _30Procedure_call(int _tok_59125)
{
    int _n_59126 = NOVALUE;
    int _scope_59127 = NOVALUE;
    int _opcode_59128 = NOVALUE;
    int _temp_tok_59130 = NOVALUE;
    int _s_59132 = NOVALUE;
    int _sub_59133 = NOVALUE;
    int _29843 = NOVALUE;
    int _29838 = NOVALUE;
    int _29837 = NOVALUE;
    int _29836 = NOVALUE;
    int _29835 = NOVALUE;
    int _29834 = NOVALUE;
    int _29833 = NOVALUE;
    int _29832 = NOVALUE;
    int _29831 = NOVALUE;
    int _29830 = NOVALUE;
    int _29829 = NOVALUE;
    int _29828 = NOVALUE;
    int _29826 = NOVALUE;
    int _29825 = NOVALUE;
    int _29824 = NOVALUE;
    int _29823 = NOVALUE;
    int _29822 = NOVALUE;
    int _29821 = NOVALUE;
    int _29820 = NOVALUE;
    int _29818 = NOVALUE;
    int _29817 = NOVALUE;
    int _29816 = NOVALUE;
    int _29814 = NOVALUE;
    int _29812 = NOVALUE;
    int _29810 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59125);
    _s_59132 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59132)){
        _s_59132 = (long)DBL_PTR(_s_59132)->dbl;
    }

    /** 	sub=s*/
    _sub_59133 = _s_59132;

    /** 	n = SymTab[s][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29810 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29810);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _n_59126 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _n_59126 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_n_59126)){
        _n_59126 = (long)DBL_PTR(_n_59126)->dbl;
    }
    _29810 = NOVALUE;

    /** 	scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29812 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29812);
    _scope_59127 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_59127)){
        _scope_59127 = (long)DBL_PTR(_scope_59127)->dbl;
    }
    _29812 = NOVALUE;

    /** 	opcode = SymTab[s][S_OPCODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29814 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29814);
    _opcode_59128 = (int)*(((s1_ptr)_2)->base + 21);
    if (!IS_ATOM_INT(_opcode_59128)){
        _opcode_59128 = (long)DBL_PTR(_opcode_59128)->dbl;
    }
    _29814 = NOVALUE;

    /** 	if SymTab[s][S_EFFECT] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29816 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29816);
    _29817 = (int)*(((s1_ptr)_2)->base + 23);
    _29816 = NOVALUE;
    if (_29817 == 0) {
        _29817 = NOVALUE;
        goto L1; // [88] 139
    }
    else {
        if (!IS_ATOM_INT(_29817) && DBL_PTR(_29817)->dbl == 0.0){
            _29817 = NOVALUE;
            goto L1; // [88] 139
        }
        _29817 = NOVALUE;
    }
    _29817 = NOVALUE;

    /** 		SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29820 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_29820);
    _29821 = (int)*(((s1_ptr)_2)->base + 23);
    _29820 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29822 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29822);
    _29823 = (int)*(((s1_ptr)_2)->base + 23);
    _29822 = NOVALUE;
    if (IS_ATOM_INT(_29821) && IS_ATOM_INT(_29823)) {
        {unsigned long tu;
             tu = (unsigned long)_29821 | (unsigned long)_29823;
             _29824 = MAKE_UINT(tu);
        }
    }
    else {
        _29824 = binary_op(OR_BITS, _29821, _29823);
    }
    _29821 = NOVALUE;
    _29823 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _29824;
    if( _1 != _29824 ){
        DeRef(_1);
    }
    _29824 = NOVALUE;
    _29818 = NOVALUE;
L1: 

    /** 	ParseArgs(s)*/
    _30ParseArgs(_s_59132);

    /** 	for i=1 to n+1 do*/
    _29825 = _n_59126 + 1;
    if (_29825 > MAXINT){
        _29825 = NewDouble((double)_29825);
    }
    {
        int _i_59170;
        _i_59170 = 1;
L2: 
        if (binary_op_a(GREATER, _i_59170, _29825)){
            goto L3; // [150] 180
        }

        /** 		s = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _29826 = (int)*(((s1_ptr)_2)->base + _s_59132);
        _2 = (int)SEQ_PTR(_29826);
        _s_59132 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_59132)){
            _s_59132 = (long)DBL_PTR(_s_59132)->dbl;
        }
        _29826 = NOVALUE;

        /** 	end for*/
        _0 = _i_59170;
        if (IS_ATOM_INT(_i_59170)) {
            _i_59170 = _i_59170 + 1;
            if ((long)((unsigned long)_i_59170 +(unsigned long) HIGH_BITS) >= 0){
                _i_59170 = NewDouble((double)_i_59170);
            }
        }
        else {
            _i_59170 = binary_op_a(PLUS, _i_59170, 1);
        }
        DeRef(_0);
        goto L2; // [175] 157
L3: 
        ;
        DeRef(_i_59170);
    }

    /** 	while s and SymTab[s][S_SCOPE]=SC_PRIVATE do*/
L4: 
    if (_s_59132 == 0) {
        goto L5; // [185] 281
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29829 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29829);
    _29830 = (int)*(((s1_ptr)_2)->base + 4);
    _29829 = NOVALUE;
    if (IS_ATOM_INT(_29830)) {
        _29831 = (_29830 == 3);
    }
    else {
        _29831 = binary_op(EQUALS, _29830, 3);
    }
    _29830 = NOVALUE;
    if (_29831 <= 0) {
        if (_29831 == 0) {
            DeRef(_29831);
            _29831 = NOVALUE;
            goto L5; // [208] 281
        }
        else {
            if (!IS_ATOM_INT(_29831) && DBL_PTR(_29831)->dbl == 0.0){
                DeRef(_29831);
                _29831 = NOVALUE;
                goto L5; // [208] 281
            }
            DeRef(_29831);
            _29831 = NOVALUE;
        }
    }
    DeRef(_29831);
    _29831 = NOVALUE;

    /** 		if sequence(SymTab[s][S_CODE]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29832 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29832);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _29833 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _29833 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _29832 = NOVALUE;
    _29834 = IS_SEQUENCE(_29833);
    _29833 = NOVALUE;
    if (_29834 == 0)
    {
        _29834 = NOVALUE;
        goto L6; // [228] 260
    }
    else{
        _29834 = NOVALUE;
    }

    /** 			start_playback(SymTab[s][S_CODE])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29835 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29835);
    if (!IS_ATOM_INT(_12S_CODE_11366)){
        _29836 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    }
    else{
        _29836 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
    }
    _29835 = NOVALUE;
    Ref(_29836);
    _30start_playback(_29836);
    _29836 = NOVALUE;

    /** 			Assignment({VARIABLE,s})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _s_59132;
    _29837 = MAKE_SEQ(_1);
    _30Assignment(_29837);
    _29837 = NOVALUE;
L6: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29838 = (int)*(((s1_ptr)_2)->base + _s_59132);
    _2 = (int)SEQ_PTR(_29838);
    _s_59132 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_59132)){
        _s_59132 = (long)DBL_PTR(_s_59132)->dbl;
    }
    _29838 = NOVALUE;

    /** 	end while*/
    goto L4; // [278] 185
L5: 

    /** 	s = sub*/
    _s_59132 = _sub_59133;

    /** 	if scope = SC_PREDEF then*/
    if (_scope_59127 != 7)
    goto L7; // [292] 335

    /** 		emit_op(opcode)*/
    _37emit_op(_opcode_59128);

    /** 		if opcode = ABORT then*/
    if (_opcode_59128 != 126)
    goto L8; // [305] 370

    /** 			temp_tok = next_token()*/
    _0 = _temp_tok_59130;
    _temp_tok_59130 = _30next_token();
    DeRef(_0);

    /** 			putback(temp_tok)*/
    Ref(_temp_tok_59130);
    _30putback(_temp_tok_59130);

    /** 			NotReached(temp_tok[T_ID], "abort()")*/
    _2 = (int)SEQ_PTR(_temp_tok_59130);
    _29843 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29843);
    RefDS(_27703);
    _30NotReached(_29843, _27703);
    _29843 = NOVALUE;
    goto L8; // [332] 370
L7: 

    /** 		op_info1 = s*/
    _37op_info1_49791 = _s_59132;

    /** 		emit_or_inline()*/
    _66emit_or_inline();

    /** 		if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L9; // [350] 369

    /** 			if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto LA; // [357] 368
    }
    else{
    }

    /** 				emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
LA: 
L9: 
L8: 

    /** end procedure*/
    DeRef(_tok_59125);
    DeRef(_temp_tok_59130);
    DeRef(_29825);
    _29825 = NOVALUE;
    return;
    ;
}


void _30Print_statement()
{
    int _29850 = NOVALUE;
    int _29849 = NOVALUE;
    int _29848 = NOVALUE;
    int _29846 = NOVALUE;
    int _29845 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	emit_opnd(NewIntSym(1)) -- stdout*/
    _29845 = _52NewIntSym(1);
    _37emit_opnd(_29845);
    _29845 = NOVALUE;

    /** 	Expr()*/
    _30Expr();

    /** 	emit_op(QPRINT)*/
    _37emit_op(36);

    /** 	SymTab[CurrentSub][S_EFFECT] = or_bits(SymTab[CurrentSub][S_EFFECT],*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29848 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_29848);
    _29849 = (int)*(((s1_ptr)_2)->base + 23);
    _29848 = NOVALUE;
    if (IS_ATOM_INT(_29849)) {
        {unsigned long tu;
             tu = (unsigned long)_29849 | (unsigned long)536870912;
             _29850 = MAKE_UINT(tu);
        }
    }
    else {
        _29850 = binary_op(OR_BITS, _29849, 536870912);
    }
    _29849 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = _29850;
    if( _1 != _29850 ){
        DeRef(_1);
    }
    _29850 = NOVALUE;
    _29846 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _30Entry_statement()
{
    int _addr_59241 = NOVALUE;
    int _29874 = NOVALUE;
    int _29873 = NOVALUE;
    int _29872 = NOVALUE;
    int _29871 = NOVALUE;
    int _29870 = NOVALUE;
    int _29869 = NOVALUE;
    int _29868 = NOVALUE;
    int _29867 = NOVALUE;
    int _29863 = NOVALUE;
    int _29861 = NOVALUE;
    int _29860 = NOVALUE;
    int _29859 = NOVALUE;
    int _29858 = NOVALUE;
    int _29856 = NOVALUE;
    int _29855 = NOVALUE;
    int _29854 = NOVALUE;
    int _29852 = NOVALUE;
    int _29851 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(loop_stack) or block_index=0 then*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _29851 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _29851 = 1;
    }
    _29852 = (_29851 == 0);
    _29851 = NOVALUE;
    if (_29852 != 0) {
        goto L1; // [11] 26
    }
    _29854 = (_30block_index_53716 == 0);
    if (_29854 == 0)
    {
        DeRef(_29854);
        _29854 = NOVALUE;
        goto L2; // [22] 34
    }
    else{
        DeRef(_29854);
        _29854 = NOVALUE;
    }
L1: 

    /** 		CompileErr(144)*/
    RefDS(_21829);
    _43CompileErr(144, _21829, 0);
L2: 

    /** 	if block_list[block_index]=IF or block_list[block_index]=SWITCH then*/
    _2 = (int)SEQ_PTR(_30block_list_53715);
    _29855 = (int)*(((s1_ptr)_2)->base + _30block_index_53716);
    _29856 = (_29855 == 20);
    _29855 = NOVALUE;
    if (_29856 != 0) {
        goto L3; // [50] 73
    }
    _2 = (int)SEQ_PTR(_30block_list_53715);
    _29858 = (int)*(((s1_ptr)_2)->base + _30block_index_53716);
    _29859 = (_29858 == 185);
    _29858 = NOVALUE;
    if (_29859 == 0)
    {
        DeRef(_29859);
        _29859 = NOVALUE;
        goto L4; // [69] 83
    }
    else{
        DeRef(_29859);
        _29859 = NOVALUE;
    }
L3: 

    /** 		CompileErr(143)*/
    RefDS(_21829);
    _43CompileErr(143, _21829, 0);
    goto L5; // [80] 109
L4: 

    /** 	elsif loop_stack[$] = FOR then  -- not allowed in an innermost for loop*/
    if (IS_SEQUENCE(_30loop_stack_53719)){
            _29860 = SEQ_PTR(_30loop_stack_53719)->length;
    }
    else {
        _29860 = 1;
    }
    _2 = (int)SEQ_PTR(_30loop_stack_53719);
    _29861 = (int)*(((s1_ptr)_2)->base + _29860);
    if (_29861 != 21)
    goto L6; // [96] 108

    /** 		CompileErr(142)*/
    RefDS(_21829);
    _43CompileErr(142, _21829, 0);
L6: 
L5: 

    /** 	addr = entry_addr[$]*/
    if (IS_SEQUENCE(_30entry_addr_53709)){
            _29863 = SEQ_PTR(_30entry_addr_53709)->length;
    }
    else {
        _29863 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_53709);
    _addr_59241 = (int)*(((s1_ptr)_2)->base + _29863);

    /** 	if addr=0  then*/
    if (_addr_59241 != 0)
    goto L7; // [122] 136

    /** 		CompileErr(141)*/
    RefDS(_21829);
    _43CompileErr(141, _21829, 0);
    goto L8; // [133] 151
L7: 

    /** 	elsif addr<0 then*/
    if (_addr_59241 >= 0)
    goto L9; // [138] 150

    /** 		CompileErr(73)*/
    RefDS(_21829);
    _43CompileErr(73, _21829, 0);
L9: 
L8: 

    /** 	backpatch(addr,ELSE)*/
    _37backpatch(_addr_59241, 23);

    /** 	backpatch(addr+1,length(Code)+1+(TRANSLATE>0))*/
    _29867 = _addr_59241 + 1;
    if (_29867 > MAXINT){
        _29867 = NewDouble((double)_29867);
    }
    if (IS_SEQUENCE(_12Code_11771)){
            _29868 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _29868 = 1;
    }
    _29869 = _29868 + 1;
    _29868 = NOVALUE;
    _29870 = (_12TRANSLATE_11319 > 0);
    _29871 = _29869 + _29870;
    _29869 = NOVALUE;
    _29870 = NOVALUE;
    _37backpatch(_29867, _29871);
    _29867 = NOVALUE;
    _29871 = NOVALUE;

    /** 	entry_addr[$] = 0*/
    if (IS_SEQUENCE(_30entry_addr_53709)){
            _29872 = SEQ_PTR(_30entry_addr_53709)->length;
    }
    else {
        _29872 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_addr_53709);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _30entry_addr_53709 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _29872);
    *(int *)_2 = 0;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto LA; // [203] 214
    }
    else{
    }

    /** 	    emit_op(NOP1)*/
    _37emit_op(159);
LA: 

    /** 	force_uninitialize( entry_stack[$] )*/
    if (IS_SEQUENCE(_30entry_stack_53712)){
            _29873 = SEQ_PTR(_30entry_stack_53712)->length;
    }
    else {
        _29873 = 1;
    }
    _2 = (int)SEQ_PTR(_30entry_stack_53712);
    _29874 = (int)*(((s1_ptr)_2)->base + _29873);
    Ref(_29874);
    _30force_uninitialize(_29874);
    _29874 = NOVALUE;

    /** end procedure*/
    DeRef(_29852);
    _29852 = NOVALUE;
    _29861 = NOVALUE;
    DeRef(_29856);
    _29856 = NOVALUE;
    return;
    ;
}


void _30force_uninitialize(int _uninitialized_59291)
{
    int _29877 = NOVALUE;
    int _29876 = NOVALUE;
    int _29875 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	for i = 1 to length( uninitialized ) do*/
    if (IS_SEQUENCE(_uninitialized_59291)){
            _29875 = SEQ_PTR(_uninitialized_59291)->length;
    }
    else {
        _29875 = 1;
    }
    {
        int _i_59293;
        _i_59293 = 1;
L1: 
        if (_i_59293 > _29875){
            goto L2; // [8] 41
        }

        /** 		SymTab[uninitialized[i]][S_INITLEVEL] = -1*/
        _2 = (int)SEQ_PTR(_uninitialized_59291);
        _29876 = (int)*(((s1_ptr)_2)->base + _i_59293);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_29876))
        _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_29876)->dbl));
        else
        _3 = (int)(_29876 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 14);
        _1 = *(int *)_2;
        *(int *)_2 = -1;
        DeRef(_1);
        _29877 = NOVALUE;

        /** 	end for*/
        _i_59293 = _i_59293 + 1;
        goto L1; // [36] 15
L2: 
        ;
    }

    /** end procedure*/
    DeRefDS(_uninitialized_59291);
    _29876 = NOVALUE;
    return;
    ;
}


void _30Statement_list()
{
    int _tok_59303 = NOVALUE;
    int _id_59304 = NOVALUE;
    int _forward_59327 = NOVALUE;
    int _test_59476 = NOVALUE;
    int _29949 = NOVALUE;
    int _29948 = NOVALUE;
    int _29945 = NOVALUE;
    int _29943 = NOVALUE;
    int _29942 = NOVALUE;
    int _29939 = NOVALUE;
    int _29937 = NOVALUE;
    int _29936 = NOVALUE;
    int _29935 = NOVALUE;
    int _29932 = NOVALUE;
    int _29930 = NOVALUE;
    int _29928 = NOVALUE;
    int _29926 = NOVALUE;
    int _29908 = NOVALUE;
    int _29907 = NOVALUE;
    int _29905 = NOVALUE;
    int _29903 = NOVALUE;
    int _29902 = NOVALUE;
    int _29900 = NOVALUE;
    int _29898 = NOVALUE;
    int _29897 = NOVALUE;
    int _29896 = NOVALUE;
    int _29895 = NOVALUE;
    int _29890 = NOVALUE;
    int _29887 = NOVALUE;
    int _29886 = NOVALUE;
    int _29885 = NOVALUE;
    int _29884 = NOVALUE;
    int _29882 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer id*/

    /** 	stmt_nest += 1*/
    _30stmt_nest_53717 = _30stmt_nest_53717 + 1;

    /** 	while TRUE do*/
L1: 
    if (_9TRUE_431 == 0)
    {
        goto L2; // [18] 1093
    }
    else{
    }

    /** 		tok = next_token()*/
    _0 = _tok_59303;
    _tok_59303 = _30next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _id_59304 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_59304)){
        _id_59304 = (long)DBL_PTR(_id_59304)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _29882 = (_id_59304 == -100);
    if (_29882 != 0) {
        goto L3; // [44] 59
    }
    _29884 = (_id_59304 == 512);
    if (_29884 == 0)
    {
        DeRef(_29884);
        _29884 = NOVALUE;
        goto L4; // [55] 229
    }
    else{
        DeRef(_29884);
        _29884 = NOVALUE;
    }
L3: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _29885 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_29885)){
        _29886 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_29885)->dbl));
    }
    else{
        _29886 = (int)*(((s1_ptr)_2)->base + _29885);
    }
    _2 = (int)SEQ_PTR(_29886);
    _29887 = (int)*(((s1_ptr)_2)->base + 4);
    _29886 = NOVALUE;
    if (binary_op_a(NOTEQ, _29887, 9)){
        _29887 = NOVALUE;
        goto L5; // [81] 210
    }
    _29887 = NOVALUE;

    /** 				token forward = next_token()*/
    _0 = _forward_59327;
    _forward_59327 = _30next_token();
    DeRef(_0);

    /** 				switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_59327);
    _29890 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_29890) ){
        goto L6; // [98] 204
    }
    if(!IS_ATOM_INT(_29890)){
        if( (DBL_PTR(_29890)->dbl != (double) ((int) DBL_PTR(_29890)->dbl) ) ){
            goto L6; // [98] 204
        }
        _0 = (int) DBL_PTR(_29890)->dbl;
    }
    else {
        _0 = _29890;
    };
    _29890 = NOVALUE;
    switch ( _0 ){ 

        /** 					case LEFT_ROUND then*/
        case -26:

        /** 						StartSourceLine( TRUE )*/
        _37StartSourceLine(_9TRUE_431, 0, 2);

        /** 						Forward_call( tok )*/
        Ref(_tok_59303);
        _30Forward_call(_tok_59303, 195);

        /** 						flush_temps()*/
        RefDS(_21829);
        _37flush_temps(_21829);

        /** 						continue*/
        DeRef(_forward_59327);
        _forward_59327 = NOVALUE;
        goto L1; // [133] 16
        goto L6; // [135] 204

        /** 					case VARIABLE then*/
        case -100:

        /** 						putback( forward )*/
        Ref(_forward_59327);
        _30putback(_forward_59327);

        /** 						if param_num != -1 then*/
        if (_30param_num_53694 == -1)
        goto L7; // [150] 176

        /** 							param_num += 1*/
        _30param_num_53694 = _30param_num_53694 + 1;

        /** 							Private_declaration( tok[T_SYM] )*/
        _2 = (int)SEQ_PTR(_tok_59303);
        _29895 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_29895);
        _30Private_declaration(_29895);
        _29895 = NOVALUE;
        goto L8; // [173] 192
L7: 

        /** 							Global_declaration( tok[T_SYM], SC_LOCAL )*/
        _2 = (int)SEQ_PTR(_tok_59303);
        _29896 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_29896);
        _29897 = _30Global_declaration(_29896, 5);
        _29896 = NOVALUE;
L8: 

        /** 						flush_temps()*/
        RefDS(_21829);
        _37flush_temps(_21829);

        /** 						continue*/
        DeRef(_forward_59327);
        _forward_59327 = NOVALUE;
        goto L1; // [201] 16
    ;}L6: 

    /** 				putback( forward )*/
    Ref(_forward_59327);
    _30putback(_forward_59327);
L5: 
    DeRef(_forward_59327);
    _forward_59327 = NOVALUE;

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_59303);
    _30Assignment(_tok_59303);
    goto L9; // [226] 1083
L4: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _29898 = (_id_59304 == 27);
    if (_29898 != 0) {
        goto LA; // [237] 252
    }
    _29900 = (_id_59304 == 521);
    if (_29900 == 0)
    {
        DeRef(_29900);
        _29900 = NOVALUE;
        goto LB; // [248] 289
    }
    else{
        DeRef(_29900);
        _29900 = NOVALUE;
    }
LA: 

    /** 			if id = PROC then*/
    if (_id_59304 != 27)
    goto LC; // [256] 272

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _29902 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29902);
    _30UndefinedVar(_29902);
    _29902 = NOVALUE;
LC: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59303);
    _30Procedure_call(_tok_59303);
    goto L9; // [286] 1083
LB: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _29903 = (_id_59304 == 501);
    if (_29903 != 0) {
        goto LD; // [297] 312
    }
    _29905 = (_id_59304 == 520);
    if (_29905 == 0)
    {
        DeRef(_29905);
        _29905 = NOVALUE;
        goto LE; // [308] 362
    }
    else{
        DeRef(_29905);
        _29905 = NOVALUE;
    }
LD: 

    /** 			if id = FUNC then*/
    if (_id_59304 != 501)
    goto LF; // [316] 332

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _29907 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29907);
    _30UndefinedVar(_29907);
    _29907 = NOVALUE;
LF: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Procedure_call(tok)*/
    Ref(_tok_59303);
    _30Procedure_call(_tok_59303);

    /** 			clear_op()*/
    _37clear_op();

    /** 			if Pop() then end if*/
    _29908 = _37Pop();
    if (_29908 == 0) {
        DeRef(_29908);
        _29908 = NOVALUE;
        goto L9; // [355] 1083
    }
    else {
        if (!IS_ATOM_INT(_29908) && DBL_PTR(_29908)->dbl == 0.0){
            DeRef(_29908);
            _29908 = NOVALUE;
            goto L9; // [355] 1083
        }
        DeRef(_29908);
        _29908 = NOVALUE;
    }
    DeRef(_29908);
    _29908 = NOVALUE;
    goto L9; // [359] 1083
LE: 

    /** 		elsif id = IF then*/
    if (_id_59304 != 20)
    goto L10; // [366] 386

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			If_statement()*/
    _30If_statement();
    goto L9; // [383] 1083
L10: 

    /** 		elsif id = FOR then*/
    if (_id_59304 != 21)
    goto L11; // [390] 410

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			For_statement()*/
    _30For_statement();
    goto L9; // [407] 1083
L11: 

    /** 		elsif id = RETURN then*/
    if (_id_59304 != 413)
    goto L12; // [414] 434

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Return_statement()*/
    _30Return_statement();
    goto L9; // [431] 1083
L12: 

    /** 		elsif id = LABEL then*/
    if (_id_59304 != 419)
    goto L13; // [438] 460

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 			GLabel_statement()*/
    _30GLabel_statement();
    goto L9; // [457] 1083
L13: 

    /** 		elsif id = GOTO then*/
    if (_id_59304 != 188)
    goto L14; // [464] 484

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Goto_statement()*/
    _30Goto_statement();
    goto L9; // [481] 1083
L14: 

    /** 		elsif id = EXIT then*/
    if (_id_59304 != 61)
    goto L15; // [488] 508

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Exit_statement()*/
    _30Exit_statement();
    goto L9; // [505] 1083
L15: 

    /** 		elsif id = BREAK then*/
    if (_id_59304 != 425)
    goto L16; // [512] 532

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Break_statement()*/
    _30Break_statement();
    goto L9; // [529] 1083
L16: 

    /** 		elsif id = WHILE then*/
    if (_id_59304 != 47)
    goto L17; // [536] 556

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			While_statement()*/
    _30While_statement();
    goto L9; // [553] 1083
L17: 

    /** 		elsif id = LOOP then*/
    if (_id_59304 != 422)
    goto L18; // [560] 580

    /** 		    StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 	        Loop_statement()*/
    _30Loop_statement();
    goto L9; // [577] 1083
L18: 

    /** 		elsif id = ENTRY then*/
    if (_id_59304 != 424)
    goto L19; // [584] 606

    /** 		    StartSourceLine(TRUE, , COVERAGE_SUPPRESS )*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 		    Entry_statement()*/
    _30Entry_statement();
    goto L9; // [603] 1083
L19: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_59304 != -31)
    goto L1A; // [610] 630

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Print_statement()*/
    _30Print_statement();
    goto L9; // [627] 1083
L1A: 

    /** 		elsif id = CONTINUE then*/
    if (_id_59304 != 426)
    goto L1B; // [634] 654

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Continue_statement()*/
    _30Continue_statement();
    goto L9; // [651] 1083
L1B: 

    /** 		elsif id = RETRY then*/
    if (_id_59304 != 184)
    goto L1C; // [658] 678

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Retry_statement()*/
    _30Retry_statement();
    goto L9; // [675] 1083
L1C: 

    /** 		elsif id = IFDEF then*/
    if (_id_59304 != 407)
    goto L1D; // [682] 702

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Ifdef_statement()*/
    _30Ifdef_statement();
    goto L9; // [699] 1083
L1D: 

    /** 		elsif id = CASE then*/
    if (_id_59304 != 186)
    goto L1E; // [706] 717

    /** 			Case_statement()*/
    _30Case_statement();
    goto L9; // [714] 1083
L1E: 

    /** 		elsif id = SWITCH then*/
    if (_id_59304 != 185)
    goto L1F; // [721] 741

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Switch_statement()*/
    _30Switch_statement();
    goto L9; // [738] 1083
L1F: 

    /** 		elsif id = FALLTHRU then*/
    if (_id_59304 != 431)
    goto L20; // [745] 756

    /** 			Fallthru_statement()*/
    _30Fallthru_statement();
    goto L9; // [753] 1083
L20: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _29926 = (_id_59304 == 504);
    if (_29926 != 0) {
        goto L21; // [764] 779
    }
    _29928 = (_id_59304 == 522);
    if (_29928 == 0)
    {
        DeRef(_29928);
        _29928 = NOVALUE;
        goto L22; // [775] 904
    }
    else{
        DeRef(_29928);
        _29928 = NOVALUE;
    }
L21: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			token test = next_token()*/
    _0 = _test_59476;
    _test_59476 = _30next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_59476);
    _30putback(_test_59476);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_59476);
    _29930 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29930, -26)){
        _29930 = NOVALUE;
        goto L23; // [808] 852
    }
    _29930 = NOVALUE;

    /** 				StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 				Procedure_call(tok)*/
    Ref(_tok_59303);
    _30Procedure_call(_tok_59303);

    /** 				clear_op()*/
    _37clear_op();

    /** 				if Pop() then end if*/
    _29932 = _37Pop();
    if (_29932 == 0) {
        DeRef(_29932);
        _29932 = NOVALUE;
        goto L24; // [835] 839
    }
    else {
        if (!IS_ATOM_INT(_29932) && DBL_PTR(_29932)->dbl == 0.0){
            DeRef(_29932);
            _29932 = NOVALUE;
            goto L24; // [835] 839
        }
        DeRef(_29932);
        _29932 = NOVALUE;
    }
    DeRef(_29932);
    _29932 = NOVALUE;
L24: 

    /** 				ExecCommand()*/
    _30ExecCommand();

    /** 				continue*/
    DeRef(_test_59476);
    _test_59476 = NOVALUE;
    goto L1; // [847] 16
    goto L25; // [849] 899
L23: 

    /** 				if param_num != -1 then*/
    if (_30param_num_53694 == -1)
    goto L26; // [856] 882

    /** 					param_num += 1*/
    _30param_num_53694 = _30param_num_53694 + 1;

    /** 					Private_declaration( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _29935 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29935);
    _30Private_declaration(_29935);
    _29935 = NOVALUE;
    goto L27; // [879] 898
L26: 

    /** 					Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_59303);
    _29936 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29936);
    _29937 = _30Global_declaration(_29936, 5);
    _29936 = NOVALUE;
L27: 
L25: 
    DeRef(_test_59476);
    _test_59476 = NOVALUE;
    goto L9; // [901] 1083
L22: 

    /** 			if id = ELSE then*/
    if (_id_59304 != 23)
    goto L28; // [908] 962

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _29939 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _29939 = 1;
    }
    if (_29939 != 0)
    goto L29; // [919] 1019

    /** 					if live_ifdef > 0 then*/
    if (_30live_ifdef_57854 <= 0)
    goto L2A; // [927] 950

    /** 						CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29942 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29942 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29943 = (int)*(((s1_ptr)_2)->base + _29942);
    _43CompileErr(134, _29943, 0);
    _29943 = NOVALUE;
    goto L29; // [947] 1019
L2A: 

    /** 						CompileErr(118)*/
    RefDS(_21829);
    _43CompileErr(118, _21829, 0);
    goto L29; // [959] 1019
L28: 

    /** 			elsif id = ELSIF then*/
    if (_id_59304 != 414)
    goto L2B; // [966] 1018

    /** 				if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _29945 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _29945 = 1;
    }
    if (_29945 != 0)
    goto L2C; // [977] 1017

    /** 					if live_ifdef > 0 then*/
    if (_30live_ifdef_57854 <= 0)
    goto L2D; // [985] 1008

    /** 						CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _29948 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _29948 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _29949 = (int)*(((s1_ptr)_2)->base + _29948);
    _43CompileErr(139, _29949, 0);
    _29949 = NOVALUE;
    goto L2E; // [1005] 1016
L2D: 

    /** 						CompileErr(119)*/
    RefDS(_21829);
    _43CompileErr(119, _21829, 0);
L2E: 
L2C: 
L2B: 
L29: 

    /** 			putback( tok )*/
    Ref(_tok_59303);
    _30putback(_tok_59303);

    /** 			switch id do*/
    _0 = _id_59304;
    switch ( _0 ){ 

        /** 				case END, ELSEDEF, ELSIFDEF, ELSIF, ELSE, UNTIL then*/
        case 402:
        case 409:
        case 408:
        case 414:
        case 23:
        case 423:

        /** 					stmt_nest -= 1*/
        _30stmt_nest_53717 = _30stmt_nest_53717 - 1;

        /** 					InitDelete()*/
        _30InitDelete();

        /** 					flush_temps()*/
        RefDS(_21829);
        _37flush_temps(_21829);

        /** 					return*/
        DeRef(_tok_59303);
        DeRef(_29882);
        _29882 = NOVALUE;
        _29885 = NOVALUE;
        DeRef(_29898);
        _29898 = NOVALUE;
        DeRef(_29897);
        _29897 = NOVALUE;
        DeRef(_29903);
        _29903 = NOVALUE;
        DeRef(_29926);
        _29926 = NOVALUE;
        DeRef(_29937);
        _29937 = NOVALUE;
        return;
        goto L2F; // [1067] 1082

        /** 				case else*/
        default:

        /** 					tok_match( END )*/
        _30tok_match(402, 0);
    ;}L2F: 
L9: 

    /** 		flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** 	end while*/
    goto L1; // [1090] 16
L2: 

    /** end procedure*/
    DeRef(_tok_59303);
    DeRef(_29882);
    _29882 = NOVALUE;
    _29885 = NOVALUE;
    DeRef(_29898);
    _29898 = NOVALUE;
    DeRef(_29897);
    _29897 = NOVALUE;
    DeRef(_29903);
    _29903 = NOVALUE;
    DeRef(_29926);
    _29926 = NOVALUE;
    DeRef(_29937);
    _29937 = NOVALUE;
    return;
    ;
}


void _30SubProg(int _prog_type_59546, int _scope_59547)
{
    int _h_59548 = NOVALUE;
    int _pt_59549 = NOVALUE;
    int _p_59551 = NOVALUE;
    int _type_sym_59552 = NOVALUE;
    int _sym_59553 = NOVALUE;
    int _tok_59555 = NOVALUE;
    int _prog_name_59556 = NOVALUE;
    int _first_def_arg_59557 = NOVALUE;
    int _again_59558 = NOVALUE;
    int _type_enum_59559 = NOVALUE;
    int _seq_sym_59560 = NOVALUE;
    int _i1_sym_59561 = NOVALUE;
    int _enum_syms_59562 = NOVALUE;
    int _type_enum_gline_59563 = NOVALUE;
    int _real_gline_59564 = NOVALUE;
    int _tsym_59575 = NOVALUE;
    int _seq_symbol_59586 = NOVALUE;
    int _middle_def_args_59785 = NOVALUE;
    int _last_nda_59786 = NOVALUE;
    int _start_def_59787 = NOVALUE;
    int _last_link_59789 = NOVALUE;
    int _temptok_59816 = NOVALUE;
    int _undef_type_59818 = NOVALUE;
    int _tokcat_59867 = NOVALUE;
    int _31360 = NOVALUE;
    int _31359 = NOVALUE;
    int _31358 = NOVALUE;
    int _31357 = NOVALUE;
    int _31356 = NOVALUE;
    int _31355 = NOVALUE;
    int _31354 = NOVALUE;
    int _31353 = NOVALUE;
    int _31352 = NOVALUE;
    int _30213 = NOVALUE;
    int _30211 = NOVALUE;
    int _30210 = NOVALUE;
    int _30208 = NOVALUE;
    int _30207 = NOVALUE;
    int _30206 = NOVALUE;
    int _30205 = NOVALUE;
    int _30204 = NOVALUE;
    int _30202 = NOVALUE;
    int _30201 = NOVALUE;
    int _30198 = NOVALUE;
    int _30197 = NOVALUE;
    int _30196 = NOVALUE;
    int _30195 = NOVALUE;
    int _30193 = NOVALUE;
    int _30184 = NOVALUE;
    int _30182 = NOVALUE;
    int _30181 = NOVALUE;
    int _30180 = NOVALUE;
    int _30179 = NOVALUE;
    int _30176 = NOVALUE;
    int _30175 = NOVALUE;
    int _30174 = NOVALUE;
    int _30172 = NOVALUE;
    int _30169 = NOVALUE;
    int _30168 = NOVALUE;
    int _30167 = NOVALUE;
    int _30165 = NOVALUE;
    int _30164 = NOVALUE;
    int _30161 = NOVALUE;
    int _30159 = NOVALUE;
    int _30157 = NOVALUE;
    int _30156 = NOVALUE;
    int _30155 = NOVALUE;
    int _30154 = NOVALUE;
    int _30152 = NOVALUE;
    int _30151 = NOVALUE;
    int _30150 = NOVALUE;
    int _30149 = NOVALUE;
    int _30148 = NOVALUE;
    int _30147 = NOVALUE;
    int _30144 = NOVALUE;
    int _30142 = NOVALUE;
    int _30140 = NOVALUE;
    int _30138 = NOVALUE;
    int _30136 = NOVALUE;
    int _30133 = NOVALUE;
    int _30131 = NOVALUE;
    int _30130 = NOVALUE;
    int _30127 = NOVALUE;
    int _30123 = NOVALUE;
    int _30122 = NOVALUE;
    int _30120 = NOVALUE;
    int _30118 = NOVALUE;
    int _30116 = NOVALUE;
    int _30114 = NOVALUE;
    int _30112 = NOVALUE;
    int _30110 = NOVALUE;
    int _30109 = NOVALUE;
    int _30108 = NOVALUE;
    int _30107 = NOVALUE;
    int _30106 = NOVALUE;
    int _30105 = NOVALUE;
    int _30104 = NOVALUE;
    int _30103 = NOVALUE;
    int _30102 = NOVALUE;
    int _30101 = NOVALUE;
    int _30100 = NOVALUE;
    int _30099 = NOVALUE;
    int _30096 = NOVALUE;
    int _30095 = NOVALUE;
    int _30094 = NOVALUE;
    int _30093 = NOVALUE;
    int _30092 = NOVALUE;
    int _30091 = NOVALUE;
    int _30090 = NOVALUE;
    int _30089 = NOVALUE;
    int _30088 = NOVALUE;
    int _30087 = NOVALUE;
    int _30086 = NOVALUE;
    int _30085 = NOVALUE;
    int _30084 = NOVALUE;
    int _30083 = NOVALUE;
    int _30082 = NOVALUE;
    int _30080 = NOVALUE;
    int _30078 = NOVALUE;
    int _30077 = NOVALUE;
    int _30072 = NOVALUE;
    int _30071 = NOVALUE;
    int _30069 = NOVALUE;
    int _30068 = NOVALUE;
    int _30067 = NOVALUE;
    int _30066 = NOVALUE;
    int _30065 = NOVALUE;
    int _30064 = NOVALUE;
    int _30063 = NOVALUE;
    int _30062 = NOVALUE;
    int _30061 = NOVALUE;
    int _30060 = NOVALUE;
    int _30058 = NOVALUE;
    int _30057 = NOVALUE;
    int _30055 = NOVALUE;
    int _30054 = NOVALUE;
    int _30053 = NOVALUE;
    int _30052 = NOVALUE;
    int _30051 = NOVALUE;
    int _30050 = NOVALUE;
    int _30049 = NOVALUE;
    int _30047 = NOVALUE;
    int _30044 = NOVALUE;
    int _30042 = NOVALUE;
    int _30040 = NOVALUE;
    int _30038 = NOVALUE;
    int _30036 = NOVALUE;
    int _30034 = NOVALUE;
    int _30032 = NOVALUE;
    int _30030 = NOVALUE;
    int _30028 = NOVALUE;
    int _30027 = NOVALUE;
    int _30026 = NOVALUE;
    int _30025 = NOVALUE;
    int _30024 = NOVALUE;
    int _30023 = NOVALUE;
    int _30022 = NOVALUE;
    int _30020 = NOVALUE;
    int _30019 = NOVALUE;
    int _30017 = NOVALUE;
    int _30015 = NOVALUE;
    int _30013 = NOVALUE;
    int _30012 = NOVALUE;
    int _30009 = NOVALUE;
    int _30008 = NOVALUE;
    int _30007 = NOVALUE;
    int _30006 = NOVALUE;
    int _30005 = NOVALUE;
    int _30003 = NOVALUE;
    int _30002 = NOVALUE;
    int _30001 = NOVALUE;
    int _30000 = NOVALUE;
    int _29999 = NOVALUE;
    int _29997 = NOVALUE;
    int _29996 = NOVALUE;
    int _29995 = NOVALUE;
    int _29993 = NOVALUE;
    int _29992 = NOVALUE;
    int _29991 = NOVALUE;
    int _29990 = NOVALUE;
    int _29986 = NOVALUE;
    int _29985 = NOVALUE;
    int _29984 = NOVALUE;
    int _29982 = NOVALUE;
    int _29981 = NOVALUE;
    int _29980 = NOVALUE;
    int _29979 = NOVALUE;
    int _29978 = NOVALUE;
    int _29977 = NOVALUE;
    int _29973 = NOVALUE;
    int _29972 = NOVALUE;
    int _29971 = NOVALUE;
    int _29969 = NOVALUE;
    int _29968 = NOVALUE;
    int _29967 = NOVALUE;
    int _29965 = NOVALUE;
    int _29964 = NOVALUE;
    int _29962 = NOVALUE;
    int _29961 = NOVALUE;
    int _29960 = NOVALUE;
    int _29956 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_prog_type_59546)) {
        _1 = (long)(DBL_PTR(_prog_type_59546)->dbl);
        DeRefDS(_prog_type_59546);
        _prog_type_59546 = _1;
    }

    /** 	integer first_def_arg*/

    /** 	integer again*/

    /** 	integer type_enum*/

    /** 	object seq_sym*/

    /** 	object i1_sym*/

    /** 	sequence enum_syms = {}*/
    RefDS(_21829);
    DeRef(_enum_syms_59562);
    _enum_syms_59562 = _21829;

    /** 	integer type_enum_gline, real_gline*/

    /** 	LeaveTopLevel()*/
    _30LeaveTopLevel();

    /** 	prog_name = next_token()*/
    _0 = _prog_name_59556;
    _prog_name_59556 = _30next_token();
    DeRef(_0);

    /** 	if prog_name[T_ID] = END_OF_FILE then*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29956 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _29956, -21)){
        _29956 = NOVALUE;
        goto L1; // [43] 55
    }
    _29956 = NOVALUE;

    /** 		CompileErr( 32 )*/
    RefDS(_21829);
    _43CompileErr(32, _21829, 0);
L1: 

    /** 	type_enum =  0*/
    _type_enum_59559 = 0;

    /** 	if prog_type = TYPE_DECL then*/
    if (_prog_type_59546 != 416)
    goto L2; // [64] 316

    /** 		object tsym = prog_name[T_SYM]*/
    DeRef(_tsym_59575);
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _tsym_59575 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tsym_59575);

    /** 		if equal(sym_name(prog_name[T_SYM]),"enum") then*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29960 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_29960);
    _29961 = _52sym_name(_29960);
    _29960 = NOVALUE;
    if (_29961 == _26049)
    _29962 = 1;
    else if (IS_ATOM_INT(_29961) && IS_ATOM_INT(_26049))
    _29962 = 0;
    else
    _29962 = (compare(_29961, _26049) == 0);
    DeRef(_29961);
    _29961 = NOVALUE;
    if (_29962 == 0)
    {
        _29962 = NOVALUE;
        goto L3; // [92] 313
    }
    else{
        _29962 = NOVALUE;
    }

    /** 			EnterTopLevel( FALSE )*/
    _30EnterTopLevel(_9FALSE_429);

    /** 			type_enum_gline = gline_number*/
    _type_enum_gline_59563 = _12gline_number_11687;

    /** 			type_enum = 1*/
    _type_enum_59559 = 1;

    /** 			sequence seq_symbol*/

    /** 			prog_name = next_token()*/
    _0 = _prog_name_59556;
    _prog_name_59556 = _30next_token();
    DeRef(_0);

    /** 			if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29964 = (int)*(((s1_ptr)_2)->base + 1);
    _29965 = find_from(_29964, _28ADDR_TOKS_11306, 1);
    _29964 = NOVALUE;
    if (_29965 != 0)
    goto L4; // [138] 163
    _29965 = NOVALUE;

    /** 				CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29967 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29967);
    _29968 = _62find_category(_29967);
    _29967 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29968;
    _29969 = MAKE_SEQ(_1);
    _29968 = NOVALUE;
    _43CompileErr(25, _29969, 0);
    _29969 = NOVALUE;
L4: 

    /** 			enum_syms = Global_declaration(-1, scope)*/
    _0 = _enum_syms_59562;
    _enum_syms_59562 = _30Global_declaration(-1, _scope_59547);
    DeRef(_0);

    /** 			seq_symbol = enum_syms*/
    RefDS(_enum_syms_59562);
    DeRef(_seq_symbol_59586);
    _seq_symbol_59586 = _enum_syms_59562;

    /** 			for i = 1 to length( enum_syms ) do*/
    if (IS_SEQUENCE(_enum_syms_59562)){
            _29971 = SEQ_PTR(_enum_syms_59562)->length;
    }
    else {
        _29971 = 1;
    }
    {
        int _i_59602;
        _i_59602 = 1;
L5: 
        if (_i_59602 > _29971){
            goto L6; // [184] 212
        }

        /** 				seq_symbol[i] = sym_obj(enum_syms[i])*/
        _2 = (int)SEQ_PTR(_enum_syms_59562);
        _29972 = (int)*(((s1_ptr)_2)->base + _i_59602);
        Ref(_29972);
        _29973 = _52sym_obj(_29972);
        _29972 = NOVALUE;
        _2 = (int)SEQ_PTR(_seq_symbol_59586);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _seq_symbol_59586 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_59602);
        _1 = *(int *)_2;
        *(int *)_2 = _29973;
        if( _1 != _29973 ){
            DeRef(_1);
        }
        _29973 = NOVALUE;

        /** 			end for*/
        _i_59602 = _i_59602 + 1;
        goto L5; // [207] 191
L6: 
        ;
    }

    /** 			i1_sym = keyfind("i1",-1)*/
    RefDS(_29974);
    DeRef(_31359);
    _31359 = _29974;
    _31360 = _52hashfn(_31359);
    _31359 = NOVALUE;
    RefDS(_29974);
    _0 = _i1_sym_59561;
    _i1_sym_59561 = _52keyfind(_29974, -1, _12current_file_no_11682, 0, _31360);
    DeRef(_0);
    _31360 = NOVALUE;

    /** 			seq_sym = NewStringSym(seq_symbol)*/
    RefDS(_seq_symbol_59586);
    _0 = _seq_sym_59560;
    _seq_sym_59560 = _52NewStringSym(_seq_symbol_59586);
    DeRef(_0);

    /** 			putback(keyfind("return",-1))*/
    RefDS(_26123);
    DeRef(_31357);
    _31357 = _26123;
    _31358 = _52hashfn(_31357);
    _31357 = NOVALUE;
    RefDS(_26123);
    _29977 = _52keyfind(_26123, -1, _12current_file_no_11682, 0, _31358);
    _31358 = NOVALUE;
    _30putback(_29977);
    _29977 = NOVALUE;

    /** 			putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _29978 = MAKE_SEQ(_1);
    _30putback(_29978);
    _29978 = NOVALUE;

    /** 			putback(i1_sym)*/
    Ref(_i1_sym_59561);
    _30putback(_i1_sym_59561);

    /** 			putback(keyfind("object",-1))*/
    RefDS(_24437);
    DeRef(_31355);
    _31355 = _24437;
    _31356 = _52hashfn(_31355);
    _31355 = NOVALUE;
    RefDS(_24437);
    _29979 = _52keyfind(_24437, -1, _12current_file_no_11682, 0, _31356);
    _31356 = NOVALUE;
    _30putback(_29979);
    _29979 = NOVALUE;

    /** 			putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _29980 = MAKE_SEQ(_1);
    _30putback(_29980);
    _29980 = NOVALUE;

    /** 			LeaveTopLevel()*/
    _30LeaveTopLevel();
L3: 
    DeRef(_seq_symbol_59586);
    _seq_symbol_59586 = NOVALUE;
L2: 
    DeRef(_tsym_59575);
    _tsym_59575 = NOVALUE;

    /** 	if not find(prog_name[T_ID], ADDR_TOKS) then*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29981 = (int)*(((s1_ptr)_2)->base + 1);
    _29982 = find_from(_29981, _28ADDR_TOKS_11306, 1);
    _29981 = NOVALUE;
    if (_29982 != 0)
    goto L7; // [333] 358
    _29982 = NOVALUE;

    /** 		CompileErr(25, {find_category(prog_name[T_ID])} )*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _29984 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_29984);
    _29985 = _62find_category(_29984);
    _29984 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _29985;
    _29986 = MAKE_SEQ(_1);
    _29985 = NOVALUE;
    _43CompileErr(25, _29986, 0);
    _29986 = NOVALUE;
L7: 

    /** 	p = prog_name[T_SYM]*/
    _2 = (int)SEQ_PTR(_prog_name_59556);
    _p_59551 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_59551)){
        _p_59551 = (long)DBL_PTR(_p_59551)->dbl;
    }

    /** 	DefinedYet(p)*/
    _52DefinedYet(_p_59551);

    /** 	if prog_type = PROCEDURE then*/
    if (_prog_type_59546 != 405)
    goto L8; // [377] 393

    /** 		pt = PROC*/
    _pt_59549 = 27;
    goto L9; // [390] 423
L8: 

    /** 	elsif prog_type = FUNCTION then*/
    if (_prog_type_59546 != 406)
    goto LA; // [397] 413

    /** 		pt = FUNC*/
    _pt_59549 = 501;
    goto L9; // [410] 423
LA: 

    /** 		pt = TYPE*/
    _pt_59549 = 504;
L9: 

    /** 	clear_fwd_refs()*/
    _29clear_fwd_refs();

    /** 	if find(SymTab[p][S_SCOPE], {SC_PREDEF, SC_GLOBAL, SC_PUBLIC, SC_EXPORT, SC_OVERRIDE}) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29990 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_29990);
    _29991 = (int)*(((s1_ptr)_2)->base + 4);
    _29990 = NOVALUE;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 7;
    *((int *)(_2+8)) = 6;
    *((int *)(_2+12)) = 13;
    *((int *)(_2+16)) = 11;
    *((int *)(_2+20)) = 12;
    _29992 = MAKE_SEQ(_1);
    _29993 = find_from(_29991, _29992, 1);
    _29991 = NOVALUE;
    DeRefDS(_29992);
    _29992 = NOVALUE;
    if (_29993 == 0)
    {
        _29993 = NOVALUE;
        goto LB; // [464] 660
    }
    else{
        _29993 = NOVALUE;
    }

    /** 		if scope = SC_OVERRIDE then*/
    if (_scope_59547 != 12)
    goto LC; // [471] 597

    /** 			if SymTab[p][S_SCOPE] = SC_PREDEF or SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29995 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_29995);
    _29996 = (int)*(((s1_ptr)_2)->base + 4);
    _29995 = NOVALUE;
    if (IS_ATOM_INT(_29996)) {
        _29997 = (_29996 == 7);
    }
    else {
        _29997 = binary_op(EQUALS, _29996, 7);
    }
    _29996 = NOVALUE;
    if (IS_ATOM_INT(_29997)) {
        if (_29997 != 0) {
            goto LD; // [495] 522
        }
    }
    else {
        if (DBL_PTR(_29997)->dbl != 0.0) {
            goto LD; // [495] 522
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _29999 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_29999);
    _30000 = (int)*(((s1_ptr)_2)->base + 4);
    _29999 = NOVALUE;
    if (IS_ATOM_INT(_30000)) {
        _30001 = (_30000 == 12);
    }
    else {
        _30001 = binary_op(EQUALS, _30000, 12);
    }
    _30000 = NOVALUE;
    if (_30001 == 0) {
        DeRef(_30001);
        _30001 = NOVALUE;
        goto LE; // [518] 596
    }
    else {
        if (!IS_ATOM_INT(_30001) && DBL_PTR(_30001)->dbl == 0.0){
            DeRef(_30001);
            _30001 = NOVALUE;
            goto LE; // [518] 596
        }
        DeRef(_30001);
        _30001 = NOVALUE;
    }
    DeRef(_30001);
    _30001 = NOVALUE;
LD: 

    /** 					if SymTab[p][S_SCOPE] = SC_OVERRIDE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30002 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30002);
    _30003 = (int)*(((s1_ptr)_2)->base + 4);
    _30002 = NOVALUE;
    if (binary_op_a(NOTEQ, _30003, 12)){
        _30003 = NOVALUE;
        goto LF; // [538] 550
    }
    _30003 = NOVALUE;

    /** 						again = 223*/
    _again_59558 = 223;
    goto L10; // [547] 556
LF: 

    /** 						again = 222*/
    _again_59558 = 222;
L10: 

    /** 					Warning(again, override_warning_flag,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _30005 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30006 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30006);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _30007 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _30007 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _30006 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30005);
    *((int *)(_2+4)) = _30005;
    *((int *)(_2+8)) = _12line_number_11683;
    Ref(_30007);
    *((int *)(_2+12)) = _30007;
    _30008 = MAKE_SEQ(_1);
    _30007 = NOVALUE;
    _30005 = NOVALUE;
    _43Warning(_again_59558, 4, _30008);
    _30008 = NOVALUE;
LE: 
LC: 

    /** 		h = SymTab[p][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30009 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30009);
    _h_59548 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_h_59548)){
        _h_59548 = (long)DBL_PTR(_h_59548)->dbl;
    }
    _30009 = NOVALUE;

    /** 		sym = buckets[h]*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _sym_59553 = (int)*(((s1_ptr)_2)->base + _h_59548);
    if (!IS_ATOM_INT(_sym_59553)){
        _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
    }

    /** 		p = NewEntry(SymTab[p][S_NAME], 0, 0, pt, h, sym, 0)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30012 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30012);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _30013 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _30013 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _30012 = NOVALUE;
    Ref(_30013);
    _p_59551 = _52NewEntry(_30013, 0, 0, _pt_59549, _h_59548, _sym_59553, 0);
    _30013 = NOVALUE;
    if (!IS_ATOM_INT(_p_59551)) {
        _1 = (long)(DBL_PTR(_p_59551)->dbl);
        DeRefDS(_p_59551);
        _p_59551 = _1;
    }

    /** 		buckets[h] = p*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _2 = (int)(((s1_ptr)_2)->base + _h_59548);
    _1 = *(int *)_2;
    *(int *)_2 = _p_59551;
    DeRef(_1);
LB: 

    /** 	Start_block( pt, p )*/
    _65Start_block(_pt_59549, _p_59551);

    /** 	CurrentSub = p*/
    _12CurrentSub_11690 = _p_59551;

    /** 	first_def_arg = 0*/
    _first_def_arg_59557 = 0;

    /** 	temps_allocated = 0*/
    _52temps_allocated_46251 = 0;

    /** 	SymTab[p][S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_59547;
    DeRef(_1);
    _30015 = NOVALUE;

    /** 	SymTab[p][S_TOKEN] = pt*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_11359))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    _1 = *(int *)_2;
    *(int *)_2 = _pt_59549;
    DeRef(_1);
    _30017 = NOVALUE;

    /** 	if length(SymTab[p]) < SIZEOF_ROUTINE_ENTRY then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30019 = (int)*(((s1_ptr)_2)->base + _p_59551);
    if (IS_SEQUENCE(_30019)){
            _30020 = SEQ_PTR(_30019)->length;
    }
    else {
        _30020 = 1;
    }
    _30019 = NOVALUE;
    if (_30020 >= _12SIZEOF_ROUTINE_ENTRY_11479)
    goto L11; // [730] 772

    /** 		SymTab[p] = SymTab[p] & repeat(0, SIZEOF_ROUTINE_ENTRY -*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30022 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30023 = (int)*(((s1_ptr)_2)->base + _p_59551);
    if (IS_SEQUENCE(_30023)){
            _30024 = SEQ_PTR(_30023)->length;
    }
    else {
        _30024 = 1;
    }
    _30023 = NOVALUE;
    _30025 = _12SIZEOF_ROUTINE_ENTRY_11479 - _30024;
    _30024 = NOVALUE;
    _30026 = Repeat(0, _30025);
    _30025 = NOVALUE;
    if (IS_SEQUENCE(_30022) && IS_ATOM(_30026)) {
    }
    else if (IS_ATOM(_30022) && IS_SEQUENCE(_30026)) {
        Ref(_30022);
        Prepend(&_30027, _30026, _30022);
    }
    else {
        Concat((object_ptr)&_30027, _30022, _30026);
        _30022 = NOVALUE;
    }
    _30022 = NOVALUE;
    DeRefDS(_30026);
    _30026 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _p_59551);
    _1 = *(int *)_2;
    *(int *)_2 = _30027;
    if( _1 != _30027 ){
        DeRef(_1);
    }
    _30027 = NOVALUE;
L11: 

    /** 	SymTab[p][S_CODE] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30028 = NOVALUE;

    /** 	SymTab[p][S_LINETAB] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30030 = NOVALUE;

    /** 	SymTab[p][S_EFFECT] = E_PURE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 23);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30032 = NOVALUE;

    /** 	SymTab[p][S_REFLIST] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _30034 = NOVALUE;

    /** 	SymTab[p][S_FIRSTLINE] = gline_number*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_11394))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRSTLINE_11394)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FIRSTLINE_11394);
    _1 = *(int *)_2;
    *(int *)_2 = _12gline_number_11687;
    DeRef(_1);
    _30036 = NOVALUE;

    /** 	SymTab[p][S_TEMPS] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_11399))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30038 = NOVALUE;

    /** 	SymTab[p][S_RESIDENT_TASK] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 25);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30040 = NOVALUE;

    /** 	SymTab[p][S_SAVED_PRIVATES] = {}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    RefDS(_21829);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 26);
    _1 = *(int *)_2;
    *(int *)_2 = _21829;
    DeRef(_1);
    _30042 = NOVALUE;

    /** 	if type_enum then*/
    if (_type_enum_59559 == 0)
    {
        goto L12; // [898] 955
    }
    else{
    }

    /** 		SymTab[p][S_FIRSTLINE] = type_enum_gline*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FIRSTLINE_11394))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FIRSTLINE_11394)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FIRSTLINE_11394);
    _1 = *(int *)_2;
    *(int *)_2 = _type_enum_gline_59563;
    DeRef(_1);
    _30044 = NOVALUE;

    /** 		real_gline = gline_number*/
    _real_gline_59564 = _12gline_number_11687;

    /** 		gline_number = type_enum_gline*/
    _12gline_number_11687 = _type_enum_gline_59563;

    /** 		StartSourceLine( FALSE, , COVERAGE_OVERRIDE )*/
    _37StartSourceLine(_9FALSE_429, 0, 3);

    /** 		gline_number = real_gline*/
    _12gline_number_11687 = _real_gline_59564;
    goto L13; // [952] 967
L12: 

    /** 		StartSourceLine(FALSE, , COVERAGE_OVERRIDE)*/
    _37StartSourceLine(_9FALSE_429, 0, 3);
L13: 

    /** 	tok_match(LEFT_ROUND)*/
    _30tok_match(-26, 0);

    /** 	tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 	param_num = 0*/
    _30param_num_53694 = 0;

    /** 	sequence middle_def_args = {}*/
    RefDS(_21829);
    DeRef(_middle_def_args_59785);
    _middle_def_args_59785 = _21829;

    /** 	integer last_nda = 0, start_def = 0*/
    _last_nda_59786 = 0;
    _start_def_59787 = 0;

    /** 	symtab_index last_link = p*/
    _last_link_59789 = _p_59551;

    /** 	while tok[T_ID] != RIGHT_ROUND do*/
L14: 
    _2 = (int)SEQ_PTR(_tok_59555);
    _30047 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30047, -27)){
        _30047 = NOVALUE;
        goto L15; // [1020] 1793
    }
    _30047 = NOVALUE;

    /** 		if tok[T_ID] != TYPE and tok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30049 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30049)) {
        _30050 = (_30049 != 504);
    }
    else {
        _30050 = binary_op(NOTEQ, _30049, 504);
    }
    _30049 = NOVALUE;
    if (IS_ATOM_INT(_30050)) {
        if (_30050 == 0) {
            goto L16; // [1038] 1262
        }
    }
    else {
        if (DBL_PTR(_30050)->dbl == 0.0) {
            goto L16; // [1038] 1262
        }
    }
    _2 = (int)SEQ_PTR(_tok_59555);
    _30052 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30052)) {
        _30053 = (_30052 != 522);
    }
    else {
        _30053 = binary_op(NOTEQ, _30052, 522);
    }
    _30052 = NOVALUE;
    if (_30053 == 0) {
        DeRef(_30053);
        _30053 = NOVALUE;
        goto L16; // [1055] 1262
    }
    else {
        if (!IS_ATOM_INT(_30053) && DBL_PTR(_30053)->dbl == 0.0){
            DeRef(_30053);
            _30053 = NOVALUE;
            goto L16; // [1055] 1262
        }
        DeRef(_30053);
        _30053 = NOVALUE;
    }
    DeRef(_30053);
    _30053 = NOVALUE;

    /** 			if tok[T_ID] = VARIABLE or tok[T_ID] = QUALIFIED_VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30054 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30054)) {
        _30055 = (_30054 == -100);
    }
    else {
        _30055 = binary_op(EQUALS, _30054, -100);
    }
    _30054 = NOVALUE;
    if (IS_ATOM_INT(_30055)) {
        if (_30055 != 0) {
            goto L17; // [1072] 1093
        }
    }
    else {
        if (DBL_PTR(_30055)->dbl != 0.0) {
            goto L17; // [1072] 1093
        }
    }
    _2 = (int)SEQ_PTR(_tok_59555);
    _30057 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30057)) {
        _30058 = (_30057 == 512);
    }
    else {
        _30058 = binary_op(EQUALS, _30057, 512);
    }
    _30057 = NOVALUE;
    if (_30058 == 0) {
        DeRef(_30058);
        _30058 = NOVALUE;
        goto L18; // [1089] 1253
    }
    else {
        if (!IS_ATOM_INT(_30058) && DBL_PTR(_30058)->dbl == 0.0){
            DeRef(_30058);
            _30058 = NOVALUE;
            goto L18; // [1089] 1253
        }
        DeRef(_30058);
        _30058 = NOVALUE;
    }
    DeRef(_30058);
    _30058 = NOVALUE;
L17: 

    /** 				token temptok = next_token()*/
    _0 = _temptok_59816;
    _temptok_59816 = _30next_token();
    DeRef(_0);

    /** 				integer undef_type = 0*/
    _undef_type_59818 = 0;

    /** 				if temptok[T_ID] != TYPE and temptok[T_ID] != QUALIFIED_TYPE then*/
    _2 = (int)SEQ_PTR(_temptok_59816);
    _30060 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30060)) {
        _30061 = (_30060 != 504);
    }
    else {
        _30061 = binary_op(NOTEQ, _30060, 504);
    }
    _30060 = NOVALUE;
    if (IS_ATOM_INT(_30061)) {
        if (_30061 == 0) {
            goto L19; // [1117] 1218
        }
    }
    else {
        if (DBL_PTR(_30061)->dbl == 0.0) {
            goto L19; // [1117] 1218
        }
    }
    _2 = (int)SEQ_PTR(_temptok_59816);
    _30063 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30063)) {
        _30064 = (_30063 != 522);
    }
    else {
        _30064 = binary_op(NOTEQ, _30063, 522);
    }
    _30063 = NOVALUE;
    if (_30064 == 0) {
        DeRef(_30064);
        _30064 = NOVALUE;
        goto L19; // [1134] 1218
    }
    else {
        if (!IS_ATOM_INT(_30064) && DBL_PTR(_30064)->dbl == 0.0){
            DeRef(_30064);
            _30064 = NOVALUE;
            goto L19; // [1134] 1218
        }
        DeRef(_30064);
        _30064 = NOVALUE;
    }
    DeRef(_30064);
    _30064 = NOVALUE;

    /** 					if find( temptok[T_ID], FULL_ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_temptok_59816);
    _30065 = (int)*(((s1_ptr)_2)->base + 1);
    _30066 = find_from(_30065, _28FULL_ID_TOKS_11310, 1);
    _30065 = NOVALUE;
    if (_30066 == 0)
    {
        _30066 = NOVALUE;
        goto L1A; // [1152] 1217
    }
    else{
        _30066 = NOVALUE;
    }

    /** 						if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30067 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30067)){
        _30068 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30067)->dbl));
    }
    else{
        _30068 = (int)*(((s1_ptr)_2)->base + _30067);
    }
    _2 = (int)SEQ_PTR(_30068);
    _30069 = (int)*(((s1_ptr)_2)->base + 4);
    _30068 = NOVALUE;
    if (binary_op_a(NOTEQ, _30069, 9)){
        _30069 = NOVALUE;
        goto L1B; // [1177] 1208
    }
    _30069 = NOVALUE;

    /** 							undef_type = - new_forward_reference( TYPE, tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30071 = (int)*(((s1_ptr)_2)->base + 2);
    DeRef(_31354);
    _31354 = 504;
    Ref(_30071);
    _30072 = _29new_forward_reference(504, _30071, 504);
    _30071 = NOVALUE;
    _31354 = NOVALUE;
    if (IS_ATOM_INT(_30072)) {
        if ((unsigned long)_30072 == 0xC0000000)
        _undef_type_59818 = (int)NewDouble((double)-0xC0000000);
        else
        _undef_type_59818 = - _30072;
    }
    else {
        _undef_type_59818 = unary_op(UMINUS, _30072);
    }
    DeRef(_30072);
    _30072 = NOVALUE;
    if (!IS_ATOM_INT(_undef_type_59818)) {
        _1 = (long)(DBL_PTR(_undef_type_59818)->dbl);
        DeRefDS(_undef_type_59818);
        _undef_type_59818 = _1;
    }
    goto L1C; // [1205] 1216
L1B: 

    /** 							CompileErr(37)*/
    RefDS(_21829);
    _43CompileErr(37, _21829, 0);
L1C: 
L1A: 
L19: 

    /** 				putback(temptok) -- Return whatever came after the name back onto the token stream.*/
    Ref(_temptok_59816);
    _30putback(_temptok_59816);

    /** 				if undef_type != 0 then*/
    if (_undef_type_59818 == 0)
    goto L1D; // [1225] 1240

    /** 					tok[T_SYM] = undef_type*/
    _2 = (int)SEQ_PTR(_tok_59555);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _tok_59555 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _undef_type_59818;
    DeRef(_1);
    goto L1E; // [1237] 1248
L1D: 

    /** 					CompileErr(37)*/
    RefDS(_21829);
    _43CompileErr(37, _21829, 0);
L1E: 
    DeRef(_temptok_59816);
    _temptok_59816 = NOVALUE;
    goto L1F; // [1250] 1261
L18: 

    /** 				CompileErr(37)*/
    RefDS(_21829);
    _43CompileErr(37, _21829, 0);
L1F: 
L16: 

    /** 		type_sym = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _type_sym_59552 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_type_sym_59552)){
        _type_sym_59552 = (long)DBL_PTR(_type_sym_59552)->dbl;
    }

    /** 		tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 		if not find(tok[T_ID], ID_TOKS) then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30077 = (int)*(((s1_ptr)_2)->base + 1);
    _30078 = find_from(_30077, _28ID_TOKS_11308, 1);
    _30077 = NOVALUE;
    if (_30078 != 0)
    goto L20; // [1292] 1406
    _30078 = NOVALUE;

    /** 			sequence tokcat = find_category(tok[T_ID])*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30080 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30080);
    _0 = _tokcat_59867;
    _tokcat_59867 = _62find_category(_30080);
    DeRef(_0);
    _30080 = NOVALUE;

    /** 			if tok[T_SYM] != 0 and length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30082 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_30082)) {
        _30083 = (_30082 != 0);
    }
    else {
        _30083 = binary_op(NOTEQ, _30082, 0);
    }
    _30082 = NOVALUE;
    if (IS_ATOM_INT(_30083)) {
        if (_30083 == 0) {
            goto L21; // [1321] 1382
        }
    }
    else {
        if (DBL_PTR(_30083)->dbl == 0.0) {
            goto L21; // [1321] 1382
        }
    }
    _2 = (int)SEQ_PTR(_tok_59555);
    _30085 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30085)){
        _30086 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30085)->dbl));
    }
    else{
        _30086 = (int)*(((s1_ptr)_2)->base + _30085);
    }
    if (IS_SEQUENCE(_30086)){
            _30087 = SEQ_PTR(_30086)->length;
    }
    else {
        _30087 = 1;
    }
    _30086 = NOVALUE;
    if (IS_ATOM_INT(_12S_NAME_11354)) {
        _30088 = (_30087 >= _12S_NAME_11354);
    }
    else {
        _30088 = binary_op(GREATEREQ, _30087, _12S_NAME_11354);
    }
    _30087 = NOVALUE;
    if (_30088 == 0) {
        DeRef(_30088);
        _30088 = NOVALUE;
        goto L21; // [1347] 1382
    }
    else {
        if (!IS_ATOM_INT(_30088) && DBL_PTR(_30088)->dbl == 0.0){
            DeRef(_30088);
            _30088 = NOVALUE;
            goto L21; // [1347] 1382
        }
        DeRef(_30088);
        _30088 = NOVALUE;
    }
    DeRef(_30088);
    _30088 = NOVALUE;

    /** 				CompileErr(90, {tokcat, SymTab[tok[T_SYM]][S_NAME]})*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30089 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30089)){
        _30090 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30089)->dbl));
    }
    else{
        _30090 = (int)*(((s1_ptr)_2)->base + _30089);
    }
    _2 = (int)SEQ_PTR(_30090);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _30091 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _30091 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _30090 = NOVALUE;
    Ref(_30091);
    RefDS(_tokcat_59867);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _tokcat_59867;
    ((int *)_2)[2] = _30091;
    _30092 = MAKE_SEQ(_1);
    _30091 = NOVALUE;
    _43CompileErr(90, _30092, 0);
    _30092 = NOVALUE;
    goto L22; // [1379] 1405
L21: 

    /** 				CompileErr(92, {LexName(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30093 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30093);
    RefDS(_26196);
    _30094 = _37LexName(_30093, _26196);
    _30093 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30094;
    _30095 = MAKE_SEQ(_1);
    _30094 = NOVALUE;
    _43CompileErr(92, _30095, 0);
    _30095 = NOVALUE;
L22: 
L20: 
    DeRef(_tokcat_59867);
    _tokcat_59867 = NOVALUE;

    /** 		sym = SetPrivateScope(tok[T_SYM], type_sym, param_num)*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30096 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30096);
    _sym_59553 = _30SetPrivateScope(_30096, _type_sym_59552, _30param_num_53694);
    _30096 = NOVALUE;
    if (!IS_ATOM_INT(_sym_59553)) {
        _1 = (long)(DBL_PTR(_sym_59553)->dbl);
        DeRefDS(_sym_59553);
        _sym_59553 = _1;
    }

    /** 		param_num += 1*/
    _30param_num_53694 = _30param_num_53694 + 1;

    /** 		if SymTab[last_link][S_NEXT] != sym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30099 = (int)*(((s1_ptr)_2)->base + _last_link_59789);
    _2 = (int)SEQ_PTR(_30099);
    _30100 = (int)*(((s1_ptr)_2)->base + 2);
    _30099 = NOVALUE;
    if (IS_ATOM_INT(_30100)) {
        _30101 = (_30100 != _sym_59553);
    }
    else {
        _30101 = binary_op(NOTEQ, _30100, _sym_59553);
    }
    _30100 = NOVALUE;
    if (IS_ATOM_INT(_30101)) {
        if (_30101 == 0) {
            goto L23; // [1452] 1533
        }
    }
    else {
        if (DBL_PTR(_30101)->dbl == 0.0) {
            goto L23; // [1452] 1533
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30103 = (int)*(((s1_ptr)_2)->base + _last_link_59789);
    _2 = (int)SEQ_PTR(_30103);
    _30104 = (int)*(((s1_ptr)_2)->base + 2);
    _30103 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30104)){
        _30105 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30104)->dbl));
    }
    else{
        _30105 = (int)*(((s1_ptr)_2)->base + _30104);
    }
    _2 = (int)SEQ_PTR(_30105);
    _30106 = (int)*(((s1_ptr)_2)->base + 4);
    _30105 = NOVALUE;
    if (IS_ATOM_INT(_30106)) {
        _30107 = (_30106 == 9);
    }
    else {
        _30107 = binary_op(EQUALS, _30106, 9);
    }
    _30106 = NOVALUE;
    if (_30107 == 0) {
        DeRef(_30107);
        _30107 = NOVALUE;
        goto L23; // [1487] 1533
    }
    else {
        if (!IS_ATOM_INT(_30107) && DBL_PTR(_30107)->dbl == 0.0){
            DeRef(_30107);
            _30107 = NOVALUE;
            goto L23; // [1487] 1533
        }
        DeRef(_30107);
        _30107 = NOVALUE;
    }
    DeRef(_30107);
    _30107 = NOVALUE;

    /** 			SymTab[SymTab[last_link][S_NEXT]][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30108 = (int)*(((s1_ptr)_2)->base + _last_link_59789);
    _2 = (int)SEQ_PTR(_30108);
    _30109 = (int)*(((s1_ptr)_2)->base + 2);
    _30108 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_30109))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_30109)->dbl));
    else
    _3 = (int)(_30109 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30110 = NOVALUE;

    /** 			SymTab[last_link][S_NEXT] = sym*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_last_link_59789 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_59553;
    DeRef(_1);
    _30112 = NOVALUE;
L23: 

    /** 		last_link = sym*/
    _last_link_59789 = _sym_59553;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L24; // [1544] 1567
    }
    else{
    }

    /** 			SymTab[sym][S_GTYPE] = CompileType(type_sym)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59553 + ((s1_ptr)_2)->base);
    _30116 = _30CompileType(_type_sym_59552);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _30116;
    if( _1 != _30116 ){
        DeRef(_1);
    }
    _30116 = NOVALUE;
    _30114 = NOVALUE;
L24: 

    /** 		tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 		if tok[T_ID] = EQUALS then -- defaulted parameter*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30118 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30118, 3)){
        _30118 = NOVALUE;
        goto L25; // [1582] 1664
    }
    _30118 = NOVALUE;

    /** 			start_recording()*/
    _30start_recording();

    /** 			Expr()*/
    _30Expr();

    /** 			SymTab[sym][S_CODE] = restore_parser()*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_sym_59553 + ((s1_ptr)_2)->base);
    _30122 = _30restore_parser();
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _30122;
    if( _1 != _30122 ){
        DeRef(_1);
    }
    _30122 = NOVALUE;
    _30120 = NOVALUE;

    /** 			if Pop() then end if -- don't leak the default argument*/
    _30123 = _37Pop();
    if (_30123 == 0) {
        DeRef(_30123);
        _30123 = NOVALUE;
        goto L26; // [1617] 1621
    }
    else {
        if (!IS_ATOM_INT(_30123) && DBL_PTR(_30123)->dbl == 0.0){
            DeRef(_30123);
            _30123 = NOVALUE;
            goto L26; // [1617] 1621
        }
        DeRef(_30123);
        _30123 = NOVALUE;
    }
    DeRef(_30123);
    _30123 = NOVALUE;
L26: 

    /** 			tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 			if first_def_arg = 0 then*/
    if (_first_def_arg_59557 != 0)
    goto L27; // [1628] 1640

    /** 				first_def_arg = param_num*/
    _first_def_arg_59557 = _30param_num_53694;
L27: 

    /** 			previous_op = -1 -- no interferences betwen defparms, or them and subsequent code*/
    _12previous_op_11781 = -1;

    /** 			if start_def = 0 then*/
    if (_start_def_59787 != 0)
    goto L28; // [1649] 1721

    /** 				start_def = param_num*/
    _start_def_59787 = _30param_num_53694;
    goto L28; // [1661] 1721
L25: 

    /** 			last_nda = param_num*/
    _last_nda_59786 = _30param_num_53694;

    /** 			if start_def then*/
    if (_start_def_59787 == 0)
    {
        goto L29; // [1673] 1720
    }
    else{
    }

    /** 				if start_def = param_num-1 then*/
    _30127 = _30param_num_53694 - 1;
    if ((long)((unsigned long)_30127 +(unsigned long) HIGH_BITS) >= 0){
        _30127 = NewDouble((double)_30127);
    }
    if (binary_op_a(NOTEQ, _start_def_59787, _30127)){
        DeRef(_30127);
        _30127 = NOVALUE;
        goto L2A; // [1684] 1697
    }
    DeRef(_30127);
    _30127 = NOVALUE;

    /** 					middle_def_args &= start_def*/
    Append(&_middle_def_args_59785, _middle_def_args_59785, _start_def_59787);
    goto L2B; // [1694] 1714
L2A: 

    /** 					middle_def_args = append(middle_def_args, {start_def, param_num-1})*/
    _30130 = _30param_num_53694 - 1;
    if ((long)((unsigned long)_30130 +(unsigned long) HIGH_BITS) >= 0){
        _30130 = NewDouble((double)_30130);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _start_def_59787;
    ((int *)_2)[2] = _30130;
    _30131 = MAKE_SEQ(_1);
    _30130 = NOVALUE;
    RefDS(_30131);
    Append(&_middle_def_args_59785, _middle_def_args_59785, _30131);
    DeRefDS(_30131);
    _30131 = NOVALUE;
L2B: 

    /** 				start_def = 0*/
    _start_def_59787 = 0;
L29: 
L28: 

    /** 		if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30133 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30133, -30)){
        _30133 = NOVALUE;
        goto L2C; // [1731] 1765
    }
    _30133 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30136 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30136, -27)){
        _30136 = NOVALUE;
        goto L14; // [1750] 1012
    }
    _30136 = NOVALUE;

    /** 				CompileErr(85)*/
    RefDS(_21829);
    _43CompileErr(85, _21829, 0);
    goto L14; // [1762] 1012
L2C: 

    /** 		elsif tok[T_ID] != RIGHT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30138 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30138, -27)){
        _30138 = NOVALUE;
        goto L14; // [1775] 1012
    }
    _30138 = NOVALUE;

    /** 			CompileErr(41)*/
    RefDS(_21829);
    _43CompileErr(41, _21829, 0);

    /** 	end while*/
    goto L14; // [1790] 1012
L15: 

    /** 	Code = {} -- removes any spurious code emitted while recording parameters*/
    RefDS(_21829);
    DeRef(_12Code_11771);
    _12Code_11771 = _21829;

    /** 	SymTab[p][S_NUM_ARGS] = param_num*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    _1 = *(int *)_2;
    *(int *)_2 = _30param_num_53694;
    DeRef(_1);
    _30140 = NOVALUE;

    /** 	SymTab[p][S_DEF_ARGS] = {first_def_arg, last_nda, middle_def_args}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _first_def_arg_59557;
    *((int *)(_2+8)) = _last_nda_59786;
    RefDS(_middle_def_args_59785);
    *((int *)(_2+12)) = _middle_def_args_59785;
    _30144 = MAKE_SEQ(_1);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 28);
    _1 = *(int *)_2;
    *(int *)_2 = _30144;
    if( _1 != _30144 ){
        DeRef(_1);
    }
    _30144 = NOVALUE;
    _30142 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2D; // [1842] 1876
    }
    else{
    }

    /** 		if param_num > max_params then*/
    if (_30param_num_53694 <= _37max_params_49797)
    goto L2E; // [1851] 1865

    /** 			max_params = param_num*/
    _37max_params_49797 = _30param_num_53694;
L2E: 

    /** 		num_routines += 1*/
    _12num_routines_11691 = _12num_routines_11691 + 1;
L2D: 

    /** 	if SymTab[p][S_TOKEN] = TYPE and param_num != 1 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30147 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30147);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _30148 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _30148 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _30147 = NOVALUE;
    if (IS_ATOM_INT(_30148)) {
        _30149 = (_30148 == 504);
    }
    else {
        _30149 = binary_op(EQUALS, _30148, 504);
    }
    _30148 = NOVALUE;
    if (IS_ATOM_INT(_30149)) {
        if (_30149 == 0) {
            goto L2F; // [1896] 1918
        }
    }
    else {
        if (DBL_PTR(_30149)->dbl == 0.0) {
            goto L2F; // [1896] 1918
        }
    }
    _30151 = (_30param_num_53694 != 1);
    if (_30151 == 0)
    {
        DeRef(_30151);
        _30151 = NOVALUE;
        goto L2F; // [1907] 1918
    }
    else{
        DeRef(_30151);
        _30151 = NOVALUE;
    }

    /** 		CompileErr(148)*/
    RefDS(_21829);
    _43CompileErr(148, _21829, 0);
L2F: 

    /** 	include_routine()*/
    _49include_routine();

    /** 	sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30152 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30152);
    _sym_59553 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59553)){
        _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
    }
    _30152 = NOVALUE;

    /** 	for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30154 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30154);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _30155 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _30155 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _30154 = NOVALUE;
    {
        int _i_60021;
        _i_60021 = 1;
L30: 
        if (binary_op_a(GREATER, _i_60021, _30155)){
            goto L31; // [1952] 2031
        }

        /** 		while SymTab[sym][S_SCOPE] != SC_PRIVATE do*/
L32: 
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30156 = (int)*(((s1_ptr)_2)->base + _sym_59553);
        _2 = (int)SEQ_PTR(_30156);
        _30157 = (int)*(((s1_ptr)_2)->base + 4);
        _30156 = NOVALUE;
        if (binary_op_a(EQUALS, _30157, 3)){
            _30157 = NOVALUE;
            goto L33; // [1978] 2003
        }
        _30157 = NOVALUE;

        /** 			sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30159 = (int)*(((s1_ptr)_2)->base + _sym_59553);
        _2 = (int)SEQ_PTR(_30159);
        _sym_59553 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59553)){
            _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
        }
        _30159 = NOVALUE;

        /** 		end while*/
        goto L32; // [2000] 1964
L33: 

        /** 		TypeCheck(sym)*/
        _30TypeCheck(_sym_59553);

        /** 		sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30161 = (int)*(((s1_ptr)_2)->base + _sym_59553);
        _2 = (int)SEQ_PTR(_30161);
        _sym_59553 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59553)){
            _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
        }
        _30161 = NOVALUE;

        /** 	end for*/
        _0 = _i_60021;
        if (IS_ATOM_INT(_i_60021)) {
            _i_60021 = _i_60021 + 1;
            if ((long)((unsigned long)_i_60021 +(unsigned long) HIGH_BITS) >= 0){
                _i_60021 = NewDouble((double)_i_60021);
            }
        }
        else {
            _i_60021 = binary_op_a(PLUS, _i_60021, 1);
        }
        DeRef(_0);
        goto L30; // [2026] 1959
L31: 
        ;
        DeRef(_i_60021);
    }

    /** 	tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 	while tok[T_ID] = TYPE or tok[T_ID] = QUALIFIED_TYPE do*/
L34: 
    _2 = (int)SEQ_PTR(_tok_59555);
    _30164 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30164)) {
        _30165 = (_30164 == 504);
    }
    else {
        _30165 = binary_op(EQUALS, _30164, 504);
    }
    _30164 = NOVALUE;
    if (IS_ATOM_INT(_30165)) {
        if (_30165 != 0) {
            goto L35; // [2053] 2074
        }
    }
    else {
        if (DBL_PTR(_30165)->dbl != 0.0) {
            goto L35; // [2053] 2074
        }
    }
    _2 = (int)SEQ_PTR(_tok_59555);
    _30167 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30167)) {
        _30168 = (_30167 == 522);
    }
    else {
        _30168 = binary_op(EQUALS, _30167, 522);
    }
    _30167 = NOVALUE;
    if (_30168 <= 0) {
        if (_30168 == 0) {
            DeRef(_30168);
            _30168 = NOVALUE;
            goto L36; // [2070] 2095
        }
        else {
            if (!IS_ATOM_INT(_30168) && DBL_PTR(_30168)->dbl == 0.0){
                DeRef(_30168);
                _30168 = NOVALUE;
                goto L36; // [2070] 2095
            }
            DeRef(_30168);
            _30168 = NOVALUE;
        }
    }
    DeRef(_30168);
    _30168 = NOVALUE;
L35: 

    /** 		Private_declaration(tok[T_SYM])*/
    _2 = (int)SEQ_PTR(_tok_59555);
    _30169 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30169);
    _30Private_declaration(_30169);
    _30169 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_59555;
    _tok_59555 = _30next_token();
    DeRef(_0);

    /** 	end while*/
    goto L34; // [2092] 2041
L36: 

    /** 	if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L37; // [2099] 2202

    /** 		if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L38; // [2106] 2201
    }
    else{
    }

    /** 			emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 			emit_addr(p)*/
    _37emit_addr(_p_59551);

    /** 			sym = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30172 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30172);
    _sym_59553 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_sym_59553)){
        _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
    }
    _30172 = NOVALUE;

    /** 			for i = 1 to SymTab[p][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _30174 = (int)*(((s1_ptr)_2)->base + _p_59551);
    _2 = (int)SEQ_PTR(_30174);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _30175 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _30175 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _30174 = NOVALUE;
    {
        int _i_60068;
        _i_60068 = 1;
L39: 
        if (binary_op_a(GREATER, _i_60068, _30175)){
            goto L3A; // [2151] 2193
        }

        /** 				emit_op(DISPLAY_VAR)*/
        _37emit_op(87);

        /** 				emit_addr(sym)*/
        _37emit_addr(_sym_59553);

        /** 				sym = SymTab[sym][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _30176 = (int)*(((s1_ptr)_2)->base + _sym_59553);
        _2 = (int)SEQ_PTR(_30176);
        _sym_59553 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_sym_59553)){
            _sym_59553 = (long)DBL_PTR(_sym_59553)->dbl;
        }
        _30176 = NOVALUE;

        /** 			end for*/
        _0 = _i_60068;
        if (IS_ATOM_INT(_i_60068)) {
            _i_60068 = _i_60068 + 1;
            if ((long)((unsigned long)_i_60068 +(unsigned long) HIGH_BITS) >= 0){
                _i_60068 = NewDouble((double)_i_60068);
            }
        }
        else {
            _i_60068 = binary_op_a(PLUS, _i_60068, 1);
        }
        DeRef(_0);
        goto L39; // [2188] 2158
L3A: 
        ;
        DeRef(_i_60068);
    }

    /** 			emit_op(UPDATE_GLOBALS)*/
    _37emit_op(89);
L38: 
L37: 

    /** 	putback(tok)*/
    Ref(_tok_59555);
    _30putback(_tok_59555);

    /** 	FuncReturn = FALSE*/
    _30FuncReturn_53693 = _9FALSE_429;

    /** 	if type_enum then*/
    if (_type_enum_59559 == 0)
    {
        goto L3B; // [2218] 2387
    }
    else{
    }

    /** 		stmt_nest += 1*/
    _30stmt_nest_53717 = _30stmt_nest_53717 + 1;

    /** 		tok_match(RETURN)*/
    _30tok_match(413, 0);

    /** 		putback({RIGHT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -27;
    ((int *)_2)[2] = 0;
    _30179 = MAKE_SEQ(_1);
    _30putback(_30179);
    _30179 = NOVALUE;

    /** 		putback({VARIABLE,seq_sym})*/
    Ref(_seq_sym_59560);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _seq_sym_59560;
    _30180 = MAKE_SEQ(_1);
    _30putback(_30180);
    _30180 = NOVALUE;

    /** 		putback({COMMA,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -30;
    ((int *)_2)[2] = 0;
    _30181 = MAKE_SEQ(_1);
    _30putback(_30181);
    _30181 = NOVALUE;

    /** 		putback(i1_sym)*/
    Ref(_i1_sym_59561);
    _30putback(_i1_sym_59561);

    /** 		putback({LEFT_ROUND,0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -26;
    ((int *)_2)[2] = 0;
    _30182 = MAKE_SEQ(_1);
    _30putback(_30182);
    _30182 = NOVALUE;

    /** 		putback(keyfind("find",-1))*/
    RefDS(_30183);
    DeRef(_31352);
    _31352 = _30183;
    _31353 = _52hashfn(_31352);
    _31352 = NOVALUE;
    RefDS(_30183);
    _30184 = _52keyfind(_30183, -1, _12current_file_no_11682, 0, _31353);
    _31353 = NOVALUE;
    _30putback(_30184);
    _30184 = NOVALUE;

    /** 		if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L3C; // [2316] 2342

    /** 			if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L3D; // [2323] 2341
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 				emit_addr(CurrentSub)*/
    _37emit_addr(_12CurrentSub_11690);
L3D: 
L3C: 

    /** 		Expr()*/
    _30Expr();

    /** 		FuncReturn = TRUE*/
    _30FuncReturn_53693 = _9TRUE_431;

    /** 		emit_op(RETURNF)*/
    _37emit_op(28);

    /** 		flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** 		stmt_nest -= 1*/
    _30stmt_nest_53717 = _30stmt_nest_53717 - 1;

    /** 		InitDelete()*/
    _30InitDelete();

    /** 		flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);
    goto L3E; // [2384] 2400
L3B: 

    /** 		Statement_list()*/
    _30Statement_list();

    /** 		tok_match(END)*/
    _30tok_match(402, 0);
L3E: 

    /** 	tok_match(prog_type, END)*/
    _30tok_match(_prog_type_59546, 402);

    /** 	if prog_type != PROCEDURE then*/
    if (_prog_type_59546 == 405)
    goto L3F; // [2412] 2460

    /** 		if not FuncReturn then*/
    if (_30FuncReturn_53693 != 0)
    goto L40; // [2420] 2450

    /** 			if prog_type = FUNCTION then*/
    if (_prog_type_59546 != 406)
    goto L41; // [2427] 2441

    /** 				CompileErr(120)*/
    RefDS(_21829);
    _43CompileErr(120, _21829, 0);
    goto L42; // [2438] 2449
L41: 

    /** 				CompileErr(149)*/
    RefDS(_21829);
    _43CompileErr(149, _21829, 0);
L42: 
L40: 

    /** 		emit_op(BADRETURNF) -- function/type shouldn't reach here*/
    _37emit_op(43);
    goto L43; // [2457] 2520
L3F: 

    /** 		StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 		if not TRANSLATE then*/
    if (_12TRANSLATE_11319 != 0)
    goto L44; // [2473] 2497

    /** 			if OpTrace then*/
    if (_12OpTrace_11752 == 0)
    {
        goto L45; // [2480] 2496
    }
    else{
    }

    /** 				emit_op(ERASE_PRIVATE_NAMES)*/
    _37emit_op(88);

    /** 				emit_addr(p)*/
    _37emit_addr(_p_59551);
L45: 
L44: 

    /** 		emit_op(RETURNP)*/
    _37emit_op(29);

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L46; // [2508] 2519
    }
    else{
    }

    /** 			emit_op(BADRETURNF) -- just to mark end of procedure*/
    _37emit_op(43);
L46: 
L43: 

    /** 	Drop_block( pt )*/
    _65Drop_block(_pt_59549);

    /** 	if Strict_Override > 0 then*/
    if (_12Strict_Override_11749 <= 0)
    goto L47; // [2529] 2544

    /** 		Strict_Override -= 1	-- Reset at the end of each routine.*/
    _12Strict_Override_11749 = _12Strict_Override_11749 - 1;
L47: 

    /** 	SymTab[p][S_STACK_SPACE] += temps_allocated + param_num*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    _30195 = _52temps_allocated_46251 + _30param_num_53694;
    if ((long)((unsigned long)_30195 + (unsigned long)HIGH_BITS) >= 0) 
    _30195 = NewDouble((double)_30195);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _30196 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _30196 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _30193 = NOVALUE;
    if (IS_ATOM_INT(_30196) && IS_ATOM_INT(_30195)) {
        _30197 = _30196 + _30195;
        if ((long)((unsigned long)_30197 + (unsigned long)HIGH_BITS) >= 0) 
        _30197 = NewDouble((double)_30197);
    }
    else {
        _30197 = binary_op(PLUS, _30196, _30195);
    }
    _30196 = NOVALUE;
    DeRef(_30195);
    _30195 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    _1 = *(int *)_2;
    *(int *)_2 = _30197;
    if( _1 != _30197 ){
        DeRef(_1);
    }
    _30197 = NOVALUE;
    _30193 = NOVALUE;

    /** 	if temps_allocated + param_num > max_stack_per_call then*/
    _30198 = _52temps_allocated_46251 + _30param_num_53694;
    if ((long)((unsigned long)_30198 + (unsigned long)HIGH_BITS) >= 0) 
    _30198 = NewDouble((double)_30198);
    if (binary_op_a(LESSEQ, _30198, _12max_stack_per_call_11782)){
        DeRef(_30198);
        _30198 = NOVALUE;
        goto L48; // [2587] 2604
    }
    DeRef(_30198);
    _30198 = NOVALUE;

    /** 		max_stack_per_call = temps_allocated + param_num*/
    _12max_stack_per_call_11782 = _52temps_allocated_46251 + _30param_num_53694;
L48: 

    /** 	param_num = -1*/
    _30param_num_53694 = -1;

    /** 	StraightenBranches()*/
    _30StraightenBranches();

    /** 	check_inline( p )*/
    _66check_inline(_p_59551);

    /** 	param_num = -1*/
    _30param_num_53694 = -1;

    /** 	EnterTopLevel()*/
    _30EnterTopLevel(1);

    /** 	if length( enum_syms ) then*/
    if (IS_SEQUENCE(_enum_syms_59562)){
            _30201 = SEQ_PTR(_enum_syms_59562)->length;
    }
    else {
        _30201 = 1;
    }
    if (_30201 == 0)
    {
        _30201 = NOVALUE;
        goto L49; // [2633] 2720
    }
    else{
        _30201 = NOVALUE;
    }

    /** 		SymTab[p][S_NEXT] = SymTab[enum_syms[$]][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_59551 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_enum_syms_59562)){
            _30204 = SEQ_PTR(_enum_syms_59562)->length;
    }
    else {
        _30204 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59562);
    _30205 = (int)*(((s1_ptr)_2)->base + _30204);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30205)){
        _30206 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30205)->dbl));
    }
    else{
        _30206 = (int)*(((s1_ptr)_2)->base + _30205);
    }
    _2 = (int)SEQ_PTR(_30206);
    _30207 = (int)*(((s1_ptr)_2)->base + 2);
    _30206 = NOVALUE;
    Ref(_30207);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30207;
    if( _1 != _30207 ){
        DeRef(_1);
    }
    _30207 = NOVALUE;
    _30202 = NOVALUE;

    /** 		SymTab[last_sym][S_NEXT] = enum_syms[1]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_45740 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_enum_syms_59562);
    _30210 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30210);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _30210;
    if( _1 != _30210 ){
        DeRef(_1);
    }
    _30210 = NOVALUE;
    _30208 = NOVALUE;

    /** 		last_sym = enum_syms[$]*/
    if (IS_SEQUENCE(_enum_syms_59562)){
            _30211 = SEQ_PTR(_enum_syms_59562)->length;
    }
    else {
        _30211 = 1;
    }
    _2 = (int)SEQ_PTR(_enum_syms_59562);
    _52last_sym_45740 = (int)*(((s1_ptr)_2)->base + _30211);
    if (!IS_ATOM_INT(_52last_sym_45740)){
        _52last_sym_45740 = (long)DBL_PTR(_52last_sym_45740)->dbl;
    }

    /** 		SymTab[last_sym][S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_45740 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _30213 = NOVALUE;
L49: 

    /** end procedure*/
    DeRef(_tok_59555);
    DeRef(_prog_name_59556);
    DeRef(_seq_sym_59560);
    DeRef(_i1_sym_59561);
    DeRef(_enum_syms_59562);
    DeRef(_middle_def_args_59785);
    _30019 = NOVALUE;
    DeRef(_29997);
    _29997 = NOVALUE;
    _30067 = NOVALUE;
    _30023 = NOVALUE;
    DeRef(_30050);
    _30050 = NOVALUE;
    DeRef(_30055);
    _30055 = NOVALUE;
    DeRef(_30061);
    _30061 = NOVALUE;
    _30085 = NOVALUE;
    DeRef(_30083);
    _30083 = NOVALUE;
    _30086 = NOVALUE;
    _30089 = NOVALUE;
    _30104 = NOVALUE;
    DeRef(_30101);
    _30101 = NOVALUE;
    _30109 = NOVALUE;
    _30155 = NOVALUE;
    DeRef(_30149);
    _30149 = NOVALUE;
    _30175 = NOVALUE;
    DeRef(_30165);
    _30165 = NOVALUE;
    _30205 = NOVALUE;
    return;
    ;
}


void _30InitGlobals()
{
    int _30232 = NOVALUE;
    int _30230 = NOVALUE;
    int _30229 = NOVALUE;
    int _30228 = NOVALUE;
    int _30227 = NOVALUE;
    int _30226 = NOVALUE;
    int _30225 = NOVALUE;
    int _30223 = NOVALUE;
    int _30222 = NOVALUE;
    int _30221 = NOVALUE;
    int _30220 = NOVALUE;
    int _30218 = NOVALUE;
    int _30217 = NOVALUE;
    int _30216 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ResetTP()*/
    _60ResetTP();

    /** 	OpTypeCheck = TRUE*/
    _12OpTypeCheck_11753 = _9TRUE_431;

    /** 	OpDefines &= {*/
    _30216 = _31version_major();
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30216;
    _30217 = MAKE_SEQ(_1);
    _30216 = NOVALUE;
    _30218 = EPrintf(-9999999, _30215, _30217);
    DeRefDS(_30217);
    _30217 = NOVALUE;
    _30220 = _31version_major();
    _30221 = _31version_minor();
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _30220;
    ((int *)_2)[2] = _30221;
    _30222 = MAKE_SEQ(_1);
    _30221 = NOVALUE;
    _30220 = NOVALUE;
    _30223 = EPrintf(-9999999, _30219, _30222);
    DeRefDS(_30222);
    _30222 = NOVALUE;
    _30225 = _31version_major();
    _30226 = _31version_minor();
    _30227 = _31version_patch();
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30225;
    *((int *)(_2+8)) = _30226;
    *((int *)(_2+12)) = _30227;
    _30228 = MAKE_SEQ(_1);
    _30227 = NOVALUE;
    _30226 = NOVALUE;
    _30225 = NOVALUE;
    _30229 = EPrintf(-9999999, _30224, _30228);
    DeRefDS(_30228);
    _30228 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30218;
    *((int *)(_2+8)) = _30223;
    *((int *)(_2+12)) = _30229;
    _30230 = MAKE_SEQ(_1);
    _30229 = NOVALUE;
    _30223 = NOVALUE;
    _30218 = NOVALUE;
    Concat((object_ptr)&_12OpDefines_11756, _12OpDefines_11756, _30230);
    DeRefDS(_30230);
    _30230 = NOVALUE;

    /** 	OpDefines &= GetPlatformDefines()*/
    _30232 = _36GetPlatformDefines(0);
    if (IS_SEQUENCE(_12OpDefines_11756) && IS_ATOM(_30232)) {
        Ref(_30232);
        Append(&_12OpDefines_11756, _12OpDefines_11756, _30232);
    }
    else if (IS_ATOM(_12OpDefines_11756) && IS_SEQUENCE(_30232)) {
    }
    else {
        Concat((object_ptr)&_12OpDefines_11756, _12OpDefines_11756, _30232);
    }
    DeRef(_30232);
    _30232 = NOVALUE;

    /** 	OpInline = DEFAULT_INLINE*/
    _12OpInline_11757 = 30;

    /** 	OpIndirectInclude = 1*/
    _12OpIndirectInclude_11758 = 1;

    /** end procedure*/
    return;
    ;
}


void _30not_supported_compile(int _feature_60232)
{
    int _30234 = NOVALUE;
    int _0, _1, _2;
    

    /** 	CompileErr(5, {feature, version_name})*/
    RefDS(_12version_name_11333);
    RefDS(_feature_60232);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _feature_60232;
    ((int *)_2)[2] = _12version_name_11333;
    _30234 = MAKE_SEQ(_1);
    _43CompileErr(5, _30234, 0);
    _30234 = NOVALUE;

    /** end procedure*/
    DeRefDSi(_feature_60232);
    return;
    ;
}


void _30SetWith(int _on_off_60238)
{
    int _option_60239 = NOVALUE;
    int _idx_60240 = NOVALUE;
    int _reset_flags_60241 = NOVALUE;
    int _tok_60293 = NOVALUE;
    int _good_sofar_60341 = NOVALUE;
    int _tok_60344 = NOVALUE;
    int _warning_extra_60346 = NOVALUE;
    int _endlist_60437 = NOVALUE;
    int _tok_60580 = NOVALUE;
    int _30379 = NOVALUE;
    int _30378 = NOVALUE;
    int _30377 = NOVALUE;
    int _30376 = NOVALUE;
    int _30375 = NOVALUE;
    int _30372 = NOVALUE;
    int _30371 = NOVALUE;
    int _30370 = NOVALUE;
    int _30368 = NOVALUE;
    int _30366 = NOVALUE;
    int _30363 = NOVALUE;
    int _30361 = NOVALUE;
    int _30360 = NOVALUE;
    int _30359 = NOVALUE;
    int _30358 = NOVALUE;
    int _30357 = NOVALUE;
    int _30353 = NOVALUE;
    int _30351 = NOVALUE;
    int _30349 = NOVALUE;
    int _30345 = NOVALUE;
    int _30340 = NOVALUE;
    int _30339 = NOVALUE;
    int _30334 = NOVALUE;
    int _30333 = NOVALUE;
    int _30332 = NOVALUE;
    int _30331 = NOVALUE;
    int _30330 = NOVALUE;
    int _30329 = NOVALUE;
    int _30328 = NOVALUE;
    int _30327 = NOVALUE;
    int _30326 = NOVALUE;
    int _30325 = NOVALUE;
    int _30323 = NOVALUE;
    int _30322 = NOVALUE;
    int _30320 = NOVALUE;
    int _30319 = NOVALUE;
    int _30318 = NOVALUE;
    int _30316 = NOVALUE;
    int _30315 = NOVALUE;
    int _30313 = NOVALUE;
    int _30310 = NOVALUE;
    int _30308 = NOVALUE;
    int _30305 = NOVALUE;
    int _30304 = NOVALUE;
    int _30303 = NOVALUE;
    int _30302 = NOVALUE;
    int _30295 = NOVALUE;
    int _30294 = NOVALUE;
    int _30292 = NOVALUE;
    int _30289 = NOVALUE;
    int _30288 = NOVALUE;
    int _30286 = NOVALUE;
    int _30285 = NOVALUE;
    int _30284 = NOVALUE;
    int _30283 = NOVALUE;
    int _30282 = NOVALUE;
    int _30281 = NOVALUE;
    int _30278 = NOVALUE;
    int _30277 = NOVALUE;
    int _30276 = NOVALUE;
    int _30275 = NOVALUE;
    int _30274 = NOVALUE;
    int _30273 = NOVALUE;
    int _30270 = NOVALUE;
    int _30269 = NOVALUE;
    int _30268 = NOVALUE;
    int _30266 = NOVALUE;
    int _30263 = NOVALUE;
    int _30261 = NOVALUE;
    int _30260 = NOVALUE;
    int _30258 = NOVALUE;
    int _30257 = NOVALUE;
    int _30256 = NOVALUE;
    int _30255 = NOVALUE;
    int _30254 = NOVALUE;
    int _30253 = NOVALUE;
    int _30251 = NOVALUE;
    int _30248 = NOVALUE;
    int _30247 = NOVALUE;
    int _30246 = NOVALUE;
    int _30245 = NOVALUE;
    int _30243 = NOVALUE;
    int _30242 = NOVALUE;
    int _30241 = NOVALUE;
    int _30240 = NOVALUE;
    int _30238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer reset_flags = 1*/
    _reset_flags_60241 = 1;

    /** 	option = StringToken("&+=")*/
    RefDS(_30235);
    _0 = _option_60239;
    _option_60239 = _60StringToken(_30235);
    DeRef(_0);

    /** 	if equal(option, "type_check") then*/
    if (_option_60239 == _30237)
    _30238 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30237))
    _30238 = 0;
    else
    _30238 = (compare(_option_60239, _30237) == 0);
    if (_30238 == 0)
    {
        _30238 = NOVALUE;
        goto L1; // [22] 35
    }
    else{
        _30238 = NOVALUE;
    }

    /** 		OpTypeCheck = on_off*/
    _12OpTypeCheck_11753 = _on_off_60238;
    goto L2; // [32] 1521
L1: 

    /** 	elsif equal(option, "profile") then*/
    if (_option_60239 == _30239)
    _30240 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30239))
    _30240 = 0;
    else
    _30240 = (compare(_option_60239, _30239) == 0);
    if (_30240 == 0)
    {
        _30240 = NOVALUE;
        goto L3; // [41] 121
    }
    else{
        _30240 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30241 = (_12TRANSLATE_11319 == 0);
    if (_30241 == 0) {
        goto L2; // [51] 1521
    }
    _30243 = (_12BIND_11322 == 0);
    if (_30243 == 0)
    {
        DeRef(_30243);
        _30243 = NOVALUE;
        goto L2; // [61] 1521
    }
    else{
        DeRef(_30243);
        _30243 = NOVALUE;
    }

    /** 			OpProfileStatement = on_off*/
    _12OpProfileStatement_11754 = _on_off_60238;

    /** 			if OpProfileStatement then*/
    if (_12OpProfileStatement_11754 == 0)
    {
        goto L2; // [75] 1521
    }
    else{
    }

    /** 				if AnyTimeProfile then*/
    if (_13AnyTimeProfile_10660 == 0)
    {
        goto L4; // [82] 106
    }
    else{
    }

    /** 					Warning(224, mixed_profile_warning_flag)*/
    RefDS(_21829);
    _43Warning(224, 1024, _21829);

    /** 					OpProfileStatement = FALSE*/
    _12OpProfileStatement_11754 = _9FALSE_429;
    goto L2; // [103] 1521
L4: 

    /** 					AnyStatementProfile = TRUE*/
    _13AnyStatementProfile_10661 = _9TRUE_431;
    goto L2; // [118] 1521
L3: 

    /** 	elsif equal(option, "profile_time") then*/
    if (_option_60239 == _30244)
    _30245 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30244))
    _30245 = 0;
    else
    _30245 = (compare(_option_60239, _30244) == 0);
    if (_30245 == 0)
    {
        _30245 = NOVALUE;
        goto L5; // [127] 361
    }
    else{
        _30245 = NOVALUE;
    }

    /** 		if not TRANSLATE and not BIND then*/
    _30246 = (_12TRANSLATE_11319 == 0);
    if (_30246 == 0) {
        goto L2; // [137] 1521
    }
    _30248 = (_12BIND_11322 == 0);
    if (_30248 == 0)
    {
        DeRef(_30248);
        _30248 = NOVALUE;
        goto L2; // [147] 1521
    }
    else{
        DeRef(_30248);
        _30248 = NOVALUE;
    }

    /** 			if not IWINDOWS then*/

    /** 				if on_off then*/
    if (_on_off_60238 == 0)
    {
        goto L6; // [159] 168
    }
    else{
    }

    /** 					not_supported_compile("profile_time")*/
    RefDS(_30244);
    _30not_supported_compile(_30244);
L6: 

    /** 			OpProfileTime = on_off*/
    _12OpProfileTime_11755 = _on_off_60238;

    /** 			if OpProfileTime then*/
    if (_12OpProfileTime_11755 == 0)
    {
        goto L7; // [180] 355
    }
    else{
    }

    /** 				if AnyStatementProfile then*/
    if (_13AnyStatementProfile_10661 == 0)
    {
        goto L8; // [187] 209
    }
    else{
    }

    /** 					Warning(224,mixed_profile_warning_flag)*/
    RefDS(_21829);
    _43Warning(224, 1024, _21829);

    /** 					OpProfileTime = FALSE*/
    _12OpProfileTime_11755 = _9FALSE_429;
L8: 

    /** 				token tok = next_token()*/
    _0 = _tok_60293;
    _tok_60293 = _30next_token();
    DeRef(_0);

    /** 				if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60293);
    _30251 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30251, 502)){
        _30251 = NOVALUE;
        goto L9; // [224] 316
    }
    _30251 = NOVALUE;

    /** 					if integer(SymTab[tok[T_SYM]][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_tok_60293);
    _30253 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30253)){
        _30254 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30253)->dbl));
    }
    else{
        _30254 = (int)*(((s1_ptr)_2)->base + _30253);
    }
    _2 = (int)SEQ_PTR(_30254);
    _30255 = (int)*(((s1_ptr)_2)->base + 1);
    _30254 = NOVALUE;
    if (IS_ATOM_INT(_30255))
    _30256 = 1;
    else if (IS_ATOM_DBL(_30255))
    _30256 = IS_ATOM_INT(DoubleToInt(_30255));
    else
    _30256 = 0;
    _30255 = NOVALUE;
    if (_30256 == 0)
    {
        _30256 = NOVALUE;
        goto LA; // [251] 279
    }
    else{
        _30256 = NOVALUE;
    }

    /** 						sample_size = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60293);
    _30257 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30257)){
        _30258 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30257)->dbl));
    }
    else{
        _30258 = (int)*(((s1_ptr)_2)->base + _30257);
    }
    _2 = (int)SEQ_PTR(_30258);
    _12sample_size_11783 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_12sample_size_11783)){
        _12sample_size_11783 = (long)DBL_PTR(_12sample_size_11783)->dbl;
    }
    _30258 = NOVALUE;
    goto LB; // [276] 287
LA: 

    /** 						sample_size = -1*/
    _12sample_size_11783 = -1;
LB: 

    /** 					if sample_size < 1 and OpProfileTime then*/
    _30260 = (_12sample_size_11783 < 1);
    if (_30260 == 0) {
        goto LC; // [295] 329
    }
    if (_12OpProfileTime_11755 == 0)
    {
        goto LC; // [302] 329
    }
    else{
    }

    /** 						CompileErr(136)*/
    RefDS(_21829);
    _43CompileErr(136, _21829, 0);
    goto LC; // [313] 329
L9: 

    /** 					putback(tok)*/
    Ref(_tok_60293);
    _30putback(_tok_60293);

    /** 					sample_size = DEFAULT_SAMPLE_SIZE*/
    _12sample_size_11783 = 25000;
LC: 

    /** 				if OpProfileTime then*/
    if (_12OpProfileTime_11755 == 0)
    {
        goto LD; // [333] 354
    }
    else{
    }

    /** 					if IWINDOWS then*/
LD: 
L7: 
    DeRef(_tok_60293);
    _tok_60293 = NOVALUE;
    goto L2; // [358] 1521
L5: 

    /** 	elsif equal(option, "trace") then*/
    if (_option_60239 == _30262)
    _30263 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30262))
    _30263 = 0;
    else
    _30263 = (compare(_option_60239, _30262) == 0);
    if (_30263 == 0)
    {
        _30263 = NOVALUE;
        goto LE; // [367] 388
    }
    else{
        _30263 = NOVALUE;
    }

    /** 		if not BIND then*/
    if (_12BIND_11322 != 0)
    goto L2; // [374] 1521

    /** 			OpTrace = on_off*/
    _12OpTrace_11752 = _on_off_60238;
    goto L2; // [385] 1521
LE: 

    /** 	elsif equal(option, "warning") then*/
    if (_option_60239 == _30265)
    _30266 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30265))
    _30266 = 0;
    else
    _30266 = (compare(_option_60239, _30265) == 0);
    if (_30266 == 0)
    {
        _30266 = NOVALUE;
        goto LF; // [394] 1234
    }
    else{
        _30266 = NOVALUE;
    }

    /** 		integer good_sofar = line_number*/
    _good_sofar_60341 = _12line_number_11683;

    /** 		reset_flags = 1*/
    _reset_flags_60241 = 1;

    /** 		token tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 		integer warning_extra = 1*/
    _warning_extra_60346 = 1;

    /** 		if find(tok[T_ID], {CONCAT_EQUALS, PLUS_EQUALS}) != 0 then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30268 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 519;
    ((int *)_2)[2] = 515;
    _30269 = MAKE_SEQ(_1);
    _30270 = find_from(_30268, _30269, 1);
    _30268 = NOVALUE;
    DeRefDS(_30269);
    _30269 = NOVALUE;
    if (_30270 == 0)
    goto L10; // [442] 501

    /** 			tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30273 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30273)) {
        _30274 = (_30273 != -24);
    }
    else {
        _30274 = binary_op(NOTEQ, _30273, -24);
    }
    _30273 = NOVALUE;
    if (IS_ATOM_INT(_30274)) {
        if (_30274 == 0) {
            goto L11; // [465] 493
        }
    }
    else {
        if (DBL_PTR(_30274)->dbl == 0.0) {
            goto L11; // [465] 493
        }
    }
    _2 = (int)SEQ_PTR(_tok_60344);
    _30276 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30276)) {
        _30277 = (_30276 != -26);
    }
    else {
        _30277 = binary_op(NOTEQ, _30276, -26);
    }
    _30276 = NOVALUE;
    if (_30277 == 0) {
        DeRef(_30277);
        _30277 = NOVALUE;
        goto L11; // [482] 493
    }
    else {
        if (!IS_ATOM_INT(_30277) && DBL_PTR(_30277)->dbl == 0.0){
            DeRef(_30277);
            _30277 = NOVALUE;
            goto L11; // [482] 493
        }
        DeRef(_30277);
        _30277 = NOVALUE;
    }
    DeRef(_30277);
    _30277 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_21829);
    _43CompileErr(160, _21829, 0);
L11: 

    /** 			reset_flags = 0*/
    _reset_flags_60241 = 0;
    goto L12; // [498] 727
L10: 

    /** 		elsif tok[T_ID] = EQUALS then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30278 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30278, 3)){
        _30278 = NOVALUE;
        goto L13; // [511] 570
    }
    _30278 = NOVALUE;

    /** 			tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] != LEFT_BRACE and tok[T_ID] != LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30281 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30281)) {
        _30282 = (_30281 != -24);
    }
    else {
        _30282 = binary_op(NOTEQ, _30281, -24);
    }
    _30281 = NOVALUE;
    if (IS_ATOM_INT(_30282)) {
        if (_30282 == 0) {
            goto L14; // [534] 562
        }
    }
    else {
        if (DBL_PTR(_30282)->dbl == 0.0) {
            goto L14; // [534] 562
        }
    }
    _2 = (int)SEQ_PTR(_tok_60344);
    _30284 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_30284)) {
        _30285 = (_30284 != -26);
    }
    else {
        _30285 = binary_op(NOTEQ, _30284, -26);
    }
    _30284 = NOVALUE;
    if (_30285 == 0) {
        DeRef(_30285);
        _30285 = NOVALUE;
        goto L14; // [551] 562
    }
    else {
        if (!IS_ATOM_INT(_30285) && DBL_PTR(_30285)->dbl == 0.0){
            DeRef(_30285);
            _30285 = NOVALUE;
            goto L14; // [551] 562
        }
        DeRef(_30285);
        _30285 = NOVALUE;
    }
    DeRef(_30285);
    _30285 = NOVALUE;

    /** 				CompileErr(160)*/
    RefDS(_21829);
    _43CompileErr(160, _21829, 0);
L14: 

    /** 			reset_flags = 1*/
    _reset_flags_60241 = 1;
    goto L12; // [567] 727
L13: 

    /** 		elsif tok[T_ID] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30286 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30286, -100)){
        _30286 = NOVALUE;
        goto L15; // [580] 726
    }
    _30286 = NOVALUE;

    /** 			option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30288 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30288)){
        _30289 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30288)->dbl));
    }
    else{
        _30289 = (int)*(((s1_ptr)_2)->base + _30288);
    }
    DeRef(_option_60239);
    _2 = (int)SEQ_PTR(_30289);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _option_60239 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _option_60239 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_option_60239);
    _30289 = NOVALUE;

    /** 			if equal(option, "save") then*/
    if (_option_60239 == _30291)
    _30292 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30291))
    _30292 = 0;
    else
    _30292 = (compare(_option_60239, _30291) == 0);
    if (_30292 == 0)
    {
        _30292 = NOVALUE;
        goto L16; // [612] 636
    }
    else{
        _30292 = NOVALUE;
    }

    /** 				prev_OpWarning = OpWarning*/
    _12prev_OpWarning_11751 = _12OpWarning_11750;

    /** 				warning_extra = FALSE*/
    _warning_extra_60346 = _9FALSE_429;
    goto L17; // [633] 725
L16: 

    /** 			elsif equal(option, "restore") then*/
    if (_option_60239 == _30293)
    _30294 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30293))
    _30294 = 0;
    else
    _30294 = (compare(_option_60239, _30293) == 0);
    if (_30294 == 0)
    {
        _30294 = NOVALUE;
        goto L18; // [642] 666
    }
    else{
        _30294 = NOVALUE;
    }

    /** 				OpWarning = prev_OpWarning*/
    _12OpWarning_11750 = _12prev_OpWarning_11751;

    /** 				warning_extra = FALSE*/
    _warning_extra_60346 = _9FALSE_429;
    goto L17; // [663] 725
L18: 

    /** 			elsif equal(option, "strict") then*/
    if (_option_60239 == _25347)
    _30295 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_25347))
    _30295 = 0;
    else
    _30295 = (compare(_option_60239, _25347) == 0);
    if (_30295 == 0)
    {
        _30295 = NOVALUE;
        goto L19; // [672] 724
    }
    else{
        _30295 = NOVALUE;
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60238 != 0)
    goto L1A; // [677] 694

    /** 					Strict_Override += 1*/
    _12Strict_Override_11749 = _12Strict_Override_11749 + 1;
    goto L1B; // [691] 714
L1A: 

    /** 				elsif Strict_Override > 0 then*/
    if (_12Strict_Override_11749 <= 0)
    goto L1C; // [698] 713

    /** 					Strict_Override -= 1*/
    _12Strict_Override_11749 = _12Strict_Override_11749 - 1;
L1C: 
L1B: 

    /** 				warning_extra = FALSE*/
    _warning_extra_60346 = _9FALSE_429;
L19: 
L17: 
L15: 
L12: 

    /** 		if warning_extra = TRUE then*/
    if (_warning_extra_60346 != _9TRUE_431)
    goto L1D; // [731] 1229

    /** 			if reset_flags then*/
    if (_reset_flags_60241 == 0)
    {
        goto L1E; // [737] 769
    }
    else{
    }

    /** 				if on_off = 0 then*/
    if (_on_off_60238 != 0)
    goto L1F; // [742] 758

    /** 					OpWarning = no_warning_flag*/
    _12OpWarning_11750 = 0;
    goto L20; // [755] 768
L1F: 

    /** 					OpWarning = all_warning_flag*/
    _12OpWarning_11750 = 32767;
L20: 
L1E: 

    /** 			if find(tok[T_ID], {LEFT_BRACE, LEFT_ROUND}) then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30302 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -24;
    ((int *)_2)[2] = -26;
    _30303 = MAKE_SEQ(_1);
    _30304 = find_from(_30302, _30303, 1);
    _30302 = NOVALUE;
    DeRefDS(_30303);
    _30303 = NOVALUE;
    if (_30304 == 0)
    {
        _30304 = NOVALUE;
        goto L21; // [790] 1222
    }
    else{
        _30304 = NOVALUE;
    }

    /** 				integer endlist*/

    /** 				if tok[T_ID] = LEFT_BRACE then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30305 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30305, -24)){
        _30305 = NOVALUE;
        goto L22; // [805] 821
    }
    _30305 = NOVALUE;

    /** 					endlist = RIGHT_BRACE*/
    _endlist_60437 = -25;
    goto L23; // [818] 831
L22: 

    /** 					endlist = RIGHT_ROUND*/
    _endlist_60437 = -27;
L23: 

    /** 				tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 				while tok[T_ID] != endlist do*/
L24: 
    _2 = (int)SEQ_PTR(_tok_60344);
    _30308 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _30308, _endlist_60437)){
        _30308 = NOVALUE;
        goto L25; // [849] 1217
    }
    _30308 = NOVALUE;

    /** 					if tok[T_ID] = COMMA then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30310 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30310, -30)){
        _30310 = NOVALUE;
        goto L26; // [863] 877
    }
    _30310 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 						continue*/
    goto L24; // [874] 841
L26: 

    /** 					if tok[T_ID] = STRING then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30313 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30313, 503)){
        _30313 = NOVALUE;
        goto L27; // [887] 916
    }
    _30313 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_OBJ]*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30315 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30315)){
        _30316 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30315)->dbl));
    }
    else{
        _30316 = (int)*(((s1_ptr)_2)->base + _30315);
    }
    DeRef(_option_60239);
    _2 = (int)SEQ_PTR(_30316);
    _option_60239 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_option_60239);
    _30316 = NOVALUE;
    goto L28; // [913] 1064
L27: 

    /** 					elsif length(SymTab[tok[T_SYM]]) >= S_NAME then*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30318 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30318)){
        _30319 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30318)->dbl));
    }
    else{
        _30319 = (int)*(((s1_ptr)_2)->base + _30318);
    }
    if (IS_SEQUENCE(_30319)){
            _30320 = SEQ_PTR(_30319)->length;
    }
    else {
        _30320 = 1;
    }
    _30319 = NOVALUE;
    if (binary_op_a(LESS, _30320, _12S_NAME_11354)){
        _30320 = NOVALUE;
        goto L29; // [935] 964
    }
    _30320 = NOVALUE;

    /** 						option = SymTab[tok[T_SYM]][S_NAME]*/
    _2 = (int)SEQ_PTR(_tok_60344);
    _30322 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30322)){
        _30323 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30322)->dbl));
    }
    else{
        _30323 = (int)*(((s1_ptr)_2)->base + _30322);
    }
    DeRef(_option_60239);
    _2 = (int)SEQ_PTR(_30323);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _option_60239 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _option_60239 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_option_60239);
    _30323 = NOVALUE;
    goto L28; // [961] 1064
L29: 

    /** 						option = ""*/
    RefDS(_21829);
    DeRef(_option_60239);
    _option_60239 = _21829;

    /** 						for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22497)){
            _30325 = SEQ_PTR(_62keylist_22497)->length;
    }
    else {
        _30325 = 1;
    }
    {
        int _k_60484;
        _k_60484 = 1;
L2A: 
        if (_k_60484 > _30325){
            goto L2B; // [978] 1063
        }

        /** 							if keylist[k][S_SCOPE] = SC_KEYWORD and*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _30326 = (int)*(((s1_ptr)_2)->base + _k_60484);
        _2 = (int)SEQ_PTR(_30326);
        _30327 = (int)*(((s1_ptr)_2)->base + 4);
        _30326 = NOVALUE;
        if (IS_ATOM_INT(_30327)) {
            _30328 = (_30327 == 8);
        }
        else {
            _30328 = binary_op(EQUALS, _30327, 8);
        }
        _30327 = NOVALUE;
        if (IS_ATOM_INT(_30328)) {
            if (_30328 == 0) {
                goto L2C; // [1005] 1056
            }
        }
        else {
            if (DBL_PTR(_30328)->dbl == 0.0) {
                goto L2C; // [1005] 1056
            }
        }
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _30330 = (int)*(((s1_ptr)_2)->base + _k_60484);
        _2 = (int)SEQ_PTR(_30330);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _30331 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _30331 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _30330 = NOVALUE;
        _2 = (int)SEQ_PTR(_tok_60344);
        _30332 = (int)*(((s1_ptr)_2)->base + 1);
        if (IS_ATOM_INT(_30331) && IS_ATOM_INT(_30332)) {
            _30333 = (_30331 == _30332);
        }
        else {
            _30333 = binary_op(EQUALS, _30331, _30332);
        }
        _30331 = NOVALUE;
        _30332 = NOVALUE;
        if (_30333 == 0) {
            DeRef(_30333);
            _30333 = NOVALUE;
            goto L2C; // [1032] 1056
        }
        else {
            if (!IS_ATOM_INT(_30333) && DBL_PTR(_30333)->dbl == 0.0){
                DeRef(_30333);
                _30333 = NOVALUE;
                goto L2C; // [1032] 1056
            }
            DeRef(_30333);
            _30333 = NOVALUE;
        }
        DeRef(_30333);
        _30333 = NOVALUE;

        /** 									option = keylist[k][S_NAME]*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _30334 = (int)*(((s1_ptr)_2)->base + _k_60484);
        DeRef(_option_60239);
        _2 = (int)SEQ_PTR(_30334);
        if (!IS_ATOM_INT(_12S_NAME_11354)){
            _option_60239 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
        }
        else{
            _option_60239 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
        }
        Ref(_option_60239);
        _30334 = NOVALUE;

        /** 									exit*/
        goto L2B; // [1053] 1063
L2C: 

        /** 						end for*/
        _k_60484 = _k_60484 + 1;
        goto L2A; // [1058] 985
L2B: 
        ;
    }
L28: 

    /** 					idx = find(option, warning_names)*/
    _idx_60240 = find_from(_option_60239, _12warning_names_11727, 1);

    /** 					if idx = 0 then*/
    if (_idx_60240 != 0)
    goto L2D; // [1075] 1128

    /** 	 					if good_sofar != line_number then*/
    if (_good_sofar_60341 == _12line_number_11683)
    goto L2E; // [1083] 1095

    /**  							CompileErr(147)*/
    RefDS(_21829);
    _43CompileErr(147, _21829, 0);
L2E: 

    /** 						Warning(225, 0,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _30339 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_30339);
    *((int *)(_2+4)) = _30339;
    *((int *)(_2+8)) = _12line_number_11683;
    RefDS(_option_60239);
    *((int *)(_2+12)) = _option_60239;
    _30340 = MAKE_SEQ(_1);
    _30339 = NOVALUE;
    _43Warning(225, 0, _30340);
    _30340 = NOVALUE;

    /** 						tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 						continue*/
    goto L24; // [1125] 841
L2D: 

    /** 					idx = warning_flags[idx]*/
    _2 = (int)SEQ_PTR(_12warning_flags_11725);
    _idx_60240 = (int)*(((s1_ptr)_2)->base + _idx_60240);

    /** 					if idx = 0 then*/
    if (_idx_60240 != 0)
    goto L2F; // [1140] 1174

    /** 						if on_off then*/
    if (_on_off_60238 == 0)
    {
        goto L30; // [1146] 1161
    }
    else{
    }

    /** 							OpWarning = no_warning_flag*/
    _12OpWarning_11750 = 0;
    goto L31; // [1158] 1207
L30: 

    /** 						    OpWarning = all_warning_flag*/
    _12OpWarning_11750 = 32767;
    goto L31; // [1171] 1207
L2F: 

    /** 						if on_off then*/
    if (_on_off_60238 == 0)
    {
        goto L32; // [1176] 1192
    }
    else{
    }

    /** 							OpWarning = or_bits(OpWarning, idx)*/
    {unsigned long tu;
         tu = (unsigned long)_12OpWarning_11750 | (unsigned long)_idx_60240;
         _12OpWarning_11750 = MAKE_UINT(tu);
    }
    if (!IS_ATOM_INT(_12OpWarning_11750)) {
        _1 = (long)(DBL_PTR(_12OpWarning_11750)->dbl);
        DeRefDS(_12OpWarning_11750);
        _12OpWarning_11750 = _1;
    }
    goto L33; // [1189] 1206
L32: 

    /** 						    OpWarning = and_bits(OpWarning, not_bits(idx))*/
    _30345 = not_bits(_idx_60240);
    if (IS_ATOM_INT(_30345)) {
        {unsigned long tu;
             tu = (unsigned long)_12OpWarning_11750 & (unsigned long)_30345;
             _12OpWarning_11750 = MAKE_UINT(tu);
        }
    }
    else {
        temp_d.dbl = (double)_12OpWarning_11750;
        _12OpWarning_11750 = Dand_bits(&temp_d, DBL_PTR(_30345));
    }
    DeRef(_30345);
    _30345 = NOVALUE;
    if (!IS_ATOM_INT(_12OpWarning_11750)) {
        _1 = (long)(DBL_PTR(_12OpWarning_11750)->dbl);
        DeRefDS(_12OpWarning_11750);
        _12OpWarning_11750 = _1;
    }
L33: 
L31: 

    /** 					tok = next_token()*/
    _0 = _tok_60344;
    _tok_60344 = _30next_token();
    DeRef(_0);

    /** 				end while*/
    goto L24; // [1214] 841
L25: 
    goto L34; // [1219] 1228
L21: 

    /** 				putback(tok)*/
    Ref(_tok_60344);
    _30putback(_tok_60344);
L34: 
L1D: 
    DeRef(_tok_60344);
    _tok_60344 = NOVALUE;
    goto L2; // [1231] 1521
LF: 

    /** 	elsif equal(option, "define") then*/
    if (_option_60239 == _30348)
    _30349 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30348))
    _30349 = 0;
    else
    _30349 = (compare(_option_60239, _30348) == 0);
    if (_30349 == 0)
    {
        _30349 = NOVALUE;
        goto L35; // [1240] 1363
    }
    else{
        _30349 = NOVALUE;
    }

    /** 		option = StringToken()*/
    RefDS(_5);
    _0 = _option_60239;
    _option_60239 = _60StringToken(_5);
    DeRefDS(_0);

    /** 		if length(option) = 0 then*/
    if (IS_SEQUENCE(_option_60239)){
            _30351 = SEQ_PTR(_option_60239)->length;
    }
    else {
        _30351 = 1;
    }
    if (_30351 != 0)
    goto L36; // [1256] 1270

    /** 			CompileErr(81)*/
    RefDS(_21829);
    _43CompileErr(81, _21829, 0);
    goto L37; // [1267] 1288
L36: 

    /** 		elsif not t_identifier(option) then*/
    RefDS(_option_60239);
    _30353 = _9t_identifier(_option_60239);
    if (IS_ATOM_INT(_30353)) {
        if (_30353 != 0){
            DeRef(_30353);
            _30353 = NOVALUE;
            goto L38; // [1276] 1287
        }
    }
    else {
        if (DBL_PTR(_30353)->dbl != 0.0){
            DeRef(_30353);
            _30353 = NOVALUE;
            goto L38; // [1276] 1287
        }
    }
    DeRef(_30353);
    _30353 = NOVALUE;

    /** 			CompileErr(61)*/
    RefDS(_21829);
    _43CompileErr(61, _21829, 0);
L38: 
L37: 

    /** 		if on_off = 0 then*/
    if (_on_off_60238 != 0)
    goto L39; // [1290] 1345

    /** 			idx = find(option, OpDefines)*/
    _idx_60240 = find_from(_option_60239, _12OpDefines_11756, 1);

    /** 			if idx then*/
    if (_idx_60240 == 0)
    {
        goto L2; // [1305] 1521
    }
    else{
    }

    /** 				OpDefines = OpDefines[1..idx-1]&OpDefines[idx+1..$]*/
    _30357 = _idx_60240 - 1;
    rhs_slice_target = (object_ptr)&_30358;
    RHS_Slice(_12OpDefines_11756, 1, _30357);
    _30359 = _idx_60240 + 1;
    if (IS_SEQUENCE(_12OpDefines_11756)){
            _30360 = SEQ_PTR(_12OpDefines_11756)->length;
    }
    else {
        _30360 = 1;
    }
    rhs_slice_target = (object_ptr)&_30361;
    RHS_Slice(_12OpDefines_11756, _30359, _30360);
    Concat((object_ptr)&_12OpDefines_11756, _30358, _30361);
    DeRefDS(_30358);
    _30358 = NOVALUE;
    DeRef(_30358);
    _30358 = NOVALUE;
    DeRefDS(_30361);
    _30361 = NOVALUE;
    goto L2; // [1342] 1521
L39: 

    /** 			OpDefines &= {option}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60239);
    *((int *)(_2+4)) = _option_60239;
    _30363 = MAKE_SEQ(_1);
    Concat((object_ptr)&_12OpDefines_11756, _12OpDefines_11756, _30363);
    DeRefDS(_30363);
    _30363 = NOVALUE;
    goto L2; // [1360] 1521
L35: 

    /** 	elsif equal(option, "inline") then*/
    if (_option_60239 == _30365)
    _30366 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30365))
    _30366 = 0;
    else
    _30366 = (compare(_option_60239, _30365) == 0);
    if (_30366 == 0)
    {
        _30366 = NOVALUE;
        goto L3A; // [1369] 1455
    }
    else{
        _30366 = NOVALUE;
    }

    /** 		if on_off then*/
    if (_on_off_60238 == 0)
    {
        goto L3B; // [1374] 1444
    }
    else{
    }

    /** 			token tok = next_token()*/
    _0 = _tok_60580;
    _tok_60580 = _30next_token();
    DeRef(_0);

    /** 			if tok[T_ID] = ATOM then*/
    _2 = (int)SEQ_PTR(_tok_60580);
    _30368 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30368, 502)){
        _30368 = NOVALUE;
        goto L3C; // [1392] 1424
    }
    _30368 = NOVALUE;

    /** 				OpInline = floor( SymTab[tok[T_SYM]][S_OBJ] )*/
    _2 = (int)SEQ_PTR(_tok_60580);
    _30370 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30370)){
        _30371 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30370)->dbl));
    }
    else{
        _30371 = (int)*(((s1_ptr)_2)->base + _30370);
    }
    _2 = (int)SEQ_PTR(_30371);
    _30372 = (int)*(((s1_ptr)_2)->base + 1);
    _30371 = NOVALUE;
    if (IS_ATOM_INT(_30372))
    _12OpInline_11757 = e_floor(_30372);
    else
    _12OpInline_11757 = unary_op(FLOOR, _30372);
    _30372 = NOVALUE;
    if (!IS_ATOM_INT(_12OpInline_11757)) {
        _1 = (long)(DBL_PTR(_12OpInline_11757)->dbl);
        DeRefDS(_12OpInline_11757);
        _12OpInline_11757 = _1;
    }
    goto L3D; // [1421] 1439
L3C: 

    /** 				putback(tok)*/
    Ref(_tok_60580);
    _30putback(_tok_60580);

    /** 				OpInline = DEFAULT_INLINE*/
    _12OpInline_11757 = 30;
L3D: 
    DeRef(_tok_60580);
    _tok_60580 = NOVALUE;
    goto L2; // [1441] 1521
L3B: 

    /** 			OpInline = 0*/
    _12OpInline_11757 = 0;
    goto L2; // [1452] 1521
L3A: 

    /** 	elsif equal( option, "indirect_includes" ) then*/
    if (_option_60239 == _30374)
    _30375 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_30374))
    _30375 = 0;
    else
    _30375 = (compare(_option_60239, _30374) == 0);
    if (_30375 == 0)
    {
        _30375 = NOVALUE;
        goto L3E; // [1461] 1474
    }
    else{
        _30375 = NOVALUE;
    }

    /** 		OpIndirectInclude = on_off*/
    _12OpIndirectInclude_11758 = _on_off_60238;
    goto L2; // [1471] 1521
L3E: 

    /** 	elsif equal(option, "batch") then*/
    if (_option_60239 == _25344)
    _30376 = 1;
    else if (IS_ATOM_INT(_option_60239) && IS_ATOM_INT(_25344))
    _30376 = 0;
    else
    _30376 = (compare(_option_60239, _25344) == 0);
    if (_30376 == 0)
    {
        _30376 = NOVALUE;
        goto L3F; // [1480] 1493
    }
    else{
        _30376 = NOVALUE;
    }

    /** 		batch_job = on_off*/
    _12batch_job_11695 = _on_off_60238;
    goto L2; // [1490] 1521
L3F: 

    /** 	elsif integer(to_number(option, -1)) then*/
    RefDS(_option_60239);
    _30377 = _19to_number(_option_60239, -1);
    if (IS_ATOM_INT(_30377))
    _30378 = 1;
    else if (IS_ATOM_DBL(_30377))
    _30378 = IS_ATOM_INT(DoubleToInt(_30377));
    else
    _30378 = 0;
    DeRef(_30377);
    _30377 = NOVALUE;
    if (_30378 == 0)
    {
        _30378 = NOVALUE;
        goto L40; // [1503] 1509
    }
    else{
        _30378 = NOVALUE;
    }
    goto L2; // [1506] 1521
L40: 

    /** 		CompileErr(154, {option})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_option_60239);
    *((int *)(_2+4)) = _option_60239;
    _30379 = MAKE_SEQ(_1);
    _43CompileErr(154, _30379, 0);
    _30379 = NOVALUE;
L2: 

    /** end procedure*/
    DeRef(_option_60239);
    DeRef(_30241);
    _30241 = NOVALUE;
    DeRef(_30246);
    _30246 = NOVALUE;
    _30253 = NOVALUE;
    _30257 = NOVALUE;
    DeRef(_30260);
    _30260 = NOVALUE;
    _30288 = NOVALUE;
    DeRef(_30274);
    _30274 = NOVALUE;
    DeRef(_30282);
    _30282 = NOVALUE;
    _30315 = NOVALUE;
    _30318 = NOVALUE;
    _30319 = NOVALUE;
    _30322 = NOVALUE;
    DeRef(_30357);
    _30357 = NOVALUE;
    DeRef(_30328);
    _30328 = NOVALUE;
    _30370 = NOVALUE;
    DeRef(_30359);
    _30359 = NOVALUE;
    return;
    ;
}


void _30ExecCommand()
{
    int _0, _1, _2;
    

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [5] 16
    }
    else{
    }

    /** 		emit_op(RETURNT)*/
    _37emit_op(34);
L1: 

    /** 	StraightenBranches()  -- straighten top-level*/
    _30StraightenBranches();

    /** end procedure*/
    return;
    ;
}


int _30undefined_var(int _tok_60623, int _scope_60624)
{
    int _forward_60626 = NOVALUE;
    int _30385 = NOVALUE;
    int _30384 = NOVALUE;
    int _30381 = NOVALUE;
    int _0, _1, _2;
    

    /** 	token forward = next_token()*/
    _0 = _forward_60626;
    _forward_60626 = _30next_token();
    DeRef(_0);

    /** 		switch forward[T_ID] do*/
    _2 = (int)SEQ_PTR(_forward_60626);
    _30381 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_30381) ){
        goto L1; // [16] 82
    }
    if(!IS_ATOM_INT(_30381)){
        if( (DBL_PTR(_30381)->dbl != (double) ((int) DBL_PTR(_30381)->dbl) ) ){
            goto L1; // [16] 82
        }
        _0 = (int) DBL_PTR(_30381)->dbl;
    }
    else {
        _0 = _30381;
    };
    _30381 = NOVALUE;
    switch ( _0 ){ 

        /** 			case LEFT_ROUND then*/
        case -26:

        /** 				StartSourceLine( TRUE )*/
        _37StartSourceLine(_9TRUE_431, 0, 2);

        /** 				Forward_call( tok )*/
        Ref(_tok_60623);
        _30Forward_call(_tok_60623, 195);

        /** 				return 1*/
        DeRef(_tok_60623);
        DeRef(_forward_60626);
        return 1;
        goto L2; // [48] 96

        /** 			case VARIABLE then*/
        case -100:

        /** 				putback( forward )*/
        Ref(_forward_60626);
        _30putback(_forward_60626);

        /** 				Global_declaration( tok[T_SYM], scope )*/
        _2 = (int)SEQ_PTR(_tok_60623);
        _30384 = (int)*(((s1_ptr)_2)->base + 2);
        Ref(_30384);
        _30385 = _30Global_declaration(_30384, _scope_60624);
        _30384 = NOVALUE;

        /** 				return 1*/
        DeRef(_tok_60623);
        DeRef(_forward_60626);
        DeRef(_30385);
        _30385 = NOVALUE;
        return 1;
        goto L2; // [78] 96

        /** 			case else*/
        default:
L1: 

        /** 				putback( forward )*/
        Ref(_forward_60626);
        _30putback(_forward_60626);

        /** 				return 0*/
        DeRef(_tok_60623);
        DeRef(_forward_60626);
        DeRef(_30385);
        _30385 = NOVALUE;
        return 0;
    ;}L2: 
    ;
}


void _30real_parser(int _nested_60645)
{
    int _tok_60647 = NOVALUE;
    int _id_60648 = NOVALUE;
    int _scope_60649 = NOVALUE;
    int _test_60790 = NOVALUE;
    int _30518 = NOVALUE;
    int _30516 = NOVALUE;
    int _30515 = NOVALUE;
    int _30514 = NOVALUE;
    int _30513 = NOVALUE;
    int _30512 = NOVALUE;
    int _30511 = NOVALUE;
    int _30510 = NOVALUE;
    int _30505 = NOVALUE;
    int _30504 = NOVALUE;
    int _30501 = NOVALUE;
    int _30499 = NOVALUE;
    int _30498 = NOVALUE;
    int _30495 = NOVALUE;
    int _30482 = NOVALUE;
    int _30475 = NOVALUE;
    int _30474 = NOVALUE;
    int _30472 = NOVALUE;
    int _30470 = NOVALUE;
    int _30469 = NOVALUE;
    int _30467 = NOVALUE;
    int _30465 = NOVALUE;
    int _30460 = NOVALUE;
    int _30458 = NOVALUE;
    int _30456 = NOVALUE;
    int _30455 = NOVALUE;
    int _30454 = NOVALUE;
    int _30452 = NOVALUE;
    int _30450 = NOVALUE;
    int _30448 = NOVALUE;
    int _30446 = NOVALUE;
    int _30445 = NOVALUE;
    int _30444 = NOVALUE;
    int _30443 = NOVALUE;
    int _30442 = NOVALUE;
    int _30441 = NOVALUE;
    int _30440 = NOVALUE;
    int _30439 = NOVALUE;
    int _30438 = NOVALUE;
    int _30437 = NOVALUE;
    int _30436 = NOVALUE;
    int _30435 = NOVALUE;
    int _30434 = NOVALUE;
    int _30433 = NOVALUE;
    int _30431 = NOVALUE;
    int _30430 = NOVALUE;
    int _30429 = NOVALUE;
    int _30428 = NOVALUE;
    int _30426 = NOVALUE;
    int _30424 = NOVALUE;
    int _30423 = NOVALUE;
    int _30422 = NOVALUE;
    int _30420 = NOVALUE;
    int _30413 = NOVALUE;
    int _30411 = NOVALUE;
    int _30410 = NOVALUE;
    int _30409 = NOVALUE;
    int _30408 = NOVALUE;
    int _30407 = NOVALUE;
    int _30406 = NOVALUE;
    int _30405 = NOVALUE;
    int _30403 = NOVALUE;
    int _30402 = NOVALUE;
    int _30401 = NOVALUE;
    int _30400 = NOVALUE;
    int _30399 = NOVALUE;
    int _30398 = NOVALUE;
    int _30397 = NOVALUE;
    int _30396 = NOVALUE;
    int _30395 = NOVALUE;
    int _30394 = NOVALUE;
    int _30392 = NOVALUE;
    int _30388 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_nested_60645)) {
        _1 = (long)(DBL_PTR(_nested_60645)->dbl);
        DeRefDS(_nested_60645);
        _nested_60645 = _1;
    }

    /** 	integer id*/

    /** 	integer scope*/

    /** 	while TRUE do  -- infinite loop until scanner aborts*/
L1: 
    if (_9TRUE_431 == 0)
    {
        goto L2; // [14] 1811
    }
    else{
    }

    /** 		if OpInline = 25000 then*/
    if (_12OpInline_11757 != 25000)
    goto L3; // [21] 35

    /** 			CompileErr("OpInline went nuts: [1]", OpInline )*/
    RefDS(_30387);
    _43CompileErr(_30387, _12OpInline_11757, 0);
L3: 

    /** 		start_index = length(Code)+1*/
    if (IS_SEQUENCE(_12Code_11771)){
            _30388 = SEQ_PTR(_12Code_11771)->length;
    }
    else {
        _30388 = 1;
    }
    _30start_index_53691 = _30388 + 1;
    _30388 = NOVALUE;

    /** 		tok = next_token()*/
    _0 = _tok_60647;
    _tok_60647 = _30next_token();
    DeRef(_0);

    /** 		id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _id_60648 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_60648)){
        _id_60648 = (long)DBL_PTR(_id_60648)->dbl;
    }

    /** 		if id = VARIABLE or id = QUALIFIED_VARIABLE then*/
    _30392 = (_id_60648 == -100);
    if (_30392 != 0) {
        goto L4; // [69] 84
    }
    _30394 = (_id_60648 == 512);
    if (_30394 == 0)
    {
        DeRef(_30394);
        _30394 = NOVALUE;
        goto L5; // [80] 151
    }
    else{
        DeRef(_30394);
        _30394 = NOVALUE;
    }
L4: 

    /** 			if SymTab[tok[T_SYM]][S_SCOPE] = SC_UNDEFINED*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30395 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30395)){
        _30396 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30395)->dbl));
    }
    else{
        _30396 = (int)*(((s1_ptr)_2)->base + _30395);
    }
    _2 = (int)SEQ_PTR(_30396);
    _30397 = (int)*(((s1_ptr)_2)->base + 4);
    _30396 = NOVALUE;
    if (IS_ATOM_INT(_30397)) {
        _30398 = (_30397 == 9);
    }
    else {
        _30398 = binary_op(EQUALS, _30397, 9);
    }
    _30397 = NOVALUE;
    if (IS_ATOM_INT(_30398)) {
        if (_30398 == 0) {
            goto L6; // [110] 130
        }
    }
    else {
        if (DBL_PTR(_30398)->dbl == 0.0) {
            goto L6; // [110] 130
        }
    }
    Ref(_tok_60647);
    _30400 = _30undefined_var(_tok_60647, 5);
    if (_30400 == 0) {
        DeRef(_30400);
        _30400 = NOVALUE;
        goto L6; // [122] 130
    }
    else {
        if (!IS_ATOM_INT(_30400) && DBL_PTR(_30400)->dbl == 0.0){
            DeRef(_30400);
            _30400 = NOVALUE;
            goto L6; // [122] 130
        }
        DeRef(_30400);
        _30400 = NOVALUE;
    }
    DeRef(_30400);
    _30400 = NOVALUE;

    /** 				continue*/
    goto L1; // [127] 12
L6: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Assignment(tok)*/
    Ref(_tok_60647);
    _30Assignment(_tok_60647);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [148] 1801
L5: 

    /** 		elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30401 = (_id_60648 == 405);
    if (_30401 != 0) {
        _30402 = 1;
        goto L8; // [159] 173
    }
    _30403 = (_id_60648 == 406);
    _30402 = (_30403 != 0);
L8: 
    if (_30402 != 0) {
        goto L9; // [173] 188
    }
    _30405 = (_id_60648 == 416);
    if (_30405 == 0)
    {
        DeRef(_30405);
        _30405 = NOVALUE;
        goto LA; // [184] 205
    }
    else{
        DeRef(_30405);
        _30405 = NOVALUE;
    }
L9: 

    /** 			SubProg(tok[T_ID], SC_LOCAL)*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30406 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30406);
    _30SubProg(_30406, 5);
    _30406 = NOVALUE;
    goto L7; // [202] 1801
LA: 

    /** 		elsif id = GLOBAL or id = EXPORT or id = OVERRIDE or id = PUBLIC then*/
    _30407 = (_id_60648 == 412);
    if (_30407 != 0) {
        _30408 = 1;
        goto LB; // [213] 227
    }
    _30409 = (_id_60648 == 428);
    _30408 = (_30409 != 0);
LB: 
    if (_30408 != 0) {
        _30410 = 1;
        goto LC; // [227] 241
    }
    _30411 = (_id_60648 == 429);
    _30410 = (_30411 != 0);
LC: 
    if (_30410 != 0) {
        goto LD; // [241] 256
    }
    _30413 = (_id_60648 == 430);
    if (_30413 == 0)
    {
        DeRef(_30413);
        _30413 = NOVALUE;
        goto LE; // [252] 626
    }
    else{
        DeRef(_30413);
        _30413 = NOVALUE;
    }
LD: 

    /** 			if id = GLOBAL then*/
    if (_id_60648 != 412)
    goto LF; // [260] 276

    /** 			    scope = SC_GLOBAL*/
    _scope_60649 = 6;
    goto L10; // [273] 335
LF: 

    /** 			elsif id = EXPORT then*/
    if (_id_60648 != 428)
    goto L11; // [280] 296

    /** 				scope = SC_EXPORT*/
    _scope_60649 = 11;
    goto L10; // [293] 335
L11: 

    /** 			elsif id = OVERRIDE then*/
    if (_id_60648 != 429)
    goto L12; // [300] 316

    /** 				scope = SC_OVERRIDE*/
    _scope_60649 = 12;
    goto L10; // [313] 335
L12: 

    /** 			elsif id = PUBLIC then*/
    if (_id_60648 != 430)
    goto L13; // [320] 334

    /** 				scope = SC_PUBLIC*/
    _scope_60649 = 13;
L13: 
L10: 

    /** 			tok = next_token()*/
    _0 = _tok_60647;
    _tok_60647 = _30next_token();
    DeRef(_0);

    /** 			id = tok[T_ID]*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _id_60648 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_id_60648)){
        _id_60648 = (long)DBL_PTR(_id_60648)->dbl;
    }

    /** 			if id = TYPE or id = QUALIFIED_TYPE then*/
    _30420 = (_id_60648 == 504);
    if (_30420 != 0) {
        goto L14; // [358] 373
    }
    _30422 = (_id_60648 == 522);
    if (_30422 == 0)
    {
        DeRef(_30422);
        _30422 = NOVALUE;
        goto L15; // [369] 391
    }
    else{
        DeRef(_30422);
        _30422 = NOVALUE;
    }
L14: 

    /** 				Global_declaration(tok[T_SYM], scope )*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30423 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30423);
    _30424 = _30Global_declaration(_30423, _scope_60649);
    _30423 = NOVALUE;
    goto L7; // [388] 1801
L15: 

    /** 			elsif id = CONSTANT then*/
    if (_id_60648 != 417)
    goto L16; // [395] 415

    /** 				Global_declaration(0, scope )*/
    _30426 = _30Global_declaration(0, _scope_60649);

    /** 				ExecCommand()*/
    _30ExecCommand();
    goto L7; // [412] 1801
L16: 

    /** 			elsif id = ENUM then*/
    if (_id_60648 != 427)
    goto L17; // [419] 439

    /** 				Global_declaration(-1, scope )*/
    _30428 = _30Global_declaration(-1, _scope_60649);

    /** 				ExecCommand()*/
    _30ExecCommand();
    goto L7; // [436] 1801
L17: 

    /** 			elsif id = PROCEDURE or id = FUNCTION or id = TYPE_DECL then*/
    _30429 = (_id_60648 == 405);
    if (_30429 != 0) {
        _30430 = 1;
        goto L18; // [447] 461
    }
    _30431 = (_id_60648 == 406);
    _30430 = (_30431 != 0);
L18: 
    if (_30430 != 0) {
        goto L19; // [461] 476
    }
    _30433 = (_id_60648 == 416);
    if (_30433 == 0)
    {
        DeRef(_30433);
        _30433 = NOVALUE;
        goto L1A; // [472] 487
    }
    else{
        DeRef(_30433);
        _30433 = NOVALUE;
    }
L19: 

    /** 				SubProg(id, scope )*/
    _30SubProg(_id_60648, _scope_60649);
    goto L7; // [484] 1801
L1A: 

    /** 			elsif (scope = SC_PUBLIC) and id = INCLUDE then*/
    _30434 = (_scope_60649 == 13);
    if (_30434 == 0) {
        goto L1B; // [497] 523
    }
    _30436 = (_id_60648 == 418);
    if (_30436 == 0)
    {
        DeRef(_30436);
        _30436 = NOVALUE;
        goto L1B; // [508] 523
    }
    else{
        DeRef(_30436);
        _30436 = NOVALUE;
    }

    /** 				IncludeScan( 1 )*/
    _60IncludeScan(1);

    /** 				PushGoto()*/
    _30PushGoto();
    goto L7; // [520] 1801
L1B: 

    /** 			elsif (id = VARIABLE or id = QUALIFIED_VARIABLE)*/
    _30437 = (_id_60648 == -100);
    if (_30437 != 0) {
        _30438 = 1;
        goto L1C; // [531] 545
    }
    _30439 = (_id_60648 == 512);
    _30438 = (_30439 != 0);
L1C: 
    if (_30438 == 0) {
        _30440 = 0;
        goto L1D; // [545] 577
    }
    _2 = (int)SEQ_PTR(_tok_60647);
    _30441 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_30441)){
        _30442 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_30441)->dbl));
    }
    else{
        _30442 = (int)*(((s1_ptr)_2)->base + _30441);
    }
    _2 = (int)SEQ_PTR(_30442);
    _30443 = (int)*(((s1_ptr)_2)->base + 4);
    _30442 = NOVALUE;
    if (IS_ATOM_INT(_30443)) {
        _30444 = (_30443 == 9);
    }
    else {
        _30444 = binary_op(EQUALS, _30443, 9);
    }
    _30443 = NOVALUE;
    if (IS_ATOM_INT(_30444))
    _30440 = (_30444 != 0);
    else
    _30440 = DBL_PTR(_30444)->dbl != 0.0;
L1D: 
    if (_30440 == 0) {
        goto L1E; // [577] 597
    }
    Ref(_tok_60647);
    _30446 = _30undefined_var(_tok_60647, _scope_60649);
    if (_30446 == 0) {
        DeRef(_30446);
        _30446 = NOVALUE;
        goto L1E; // [587] 597
    }
    else {
        if (!IS_ATOM_INT(_30446) && DBL_PTR(_30446)->dbl == 0.0){
            DeRef(_30446);
            _30446 = NOVALUE;
            goto L1E; // [587] 597
        }
        DeRef(_30446);
        _30446 = NOVALUE;
    }
    DeRef(_30446);
    _30446 = NOVALUE;

    /** 				continue*/
    goto L1; // [592] 12
    goto L7; // [594] 1801
L1E: 

    /** 			elsif scope = SC_GLOBAL then*/
    if (_scope_60649 != 6)
    goto L1F; // [601] 615

    /** 				CompileErr( 18 )*/
    RefDS(_21829);
    _43CompileErr(18, _21829, 0);
    goto L7; // [612] 1801
L1F: 

    /** 				CompileErr( 16 )*/
    RefDS(_21829);
    _43CompileErr(16, _21829, 0);
    goto L7; // [623] 1801
LE: 

    /** 		elsif id = TYPE or id = QUALIFIED_TYPE then*/
    _30448 = (_id_60648 == 504);
    if (_30448 != 0) {
        goto L20; // [634] 649
    }
    _30450 = (_id_60648 == 522);
    if (_30450 == 0)
    {
        DeRef(_30450);
        _30450 = NOVALUE;
        goto L21; // [645] 734
    }
    else{
        DeRef(_30450);
        _30450 = NOVALUE;
    }
L20: 

    /** 			token test = next_token()*/
    _0 = _test_60790;
    _test_60790 = _30next_token();
    DeRef(_0);

    /** 			putback( test )*/
    Ref(_test_60790);
    _30putback(_test_60790);

    /** 			if test[T_ID] = LEFT_ROUND then*/
    _2 = (int)SEQ_PTR(_test_60790);
    _30452 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _30452, -26)){
        _30452 = NOVALUE;
        goto L22; // [669] 707
    }
    _30452 = NOVALUE;

    /** 					StartSourceLine( TRUE )*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 					Procedure_call(tok)*/
    Ref(_tok_60647);
    _30Procedure_call(_tok_60647);

    /** 					clear_op()*/
    _37clear_op();

    /** 					if Pop() then end if*/
    _30454 = _37Pop();
    if (_30454 == 0) {
        DeRef(_30454);
        _30454 = NOVALUE;
        goto L23; // [696] 700
    }
    else {
        if (!IS_ATOM_INT(_30454) && DBL_PTR(_30454)->dbl == 0.0){
            DeRef(_30454);
            _30454 = NOVALUE;
            goto L23; // [696] 700
        }
        DeRef(_30454);
        _30454 = NOVALUE;
    }
    DeRef(_30454);
    _30454 = NOVALUE;
L23: 

    /** 					ExecCommand()*/
    _30ExecCommand();
    goto L24; // [704] 723
L22: 

    /** 				Global_declaration( tok[T_SYM], SC_LOCAL )*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30455 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30455);
    _30456 = _30Global_declaration(_30455, 5);
    _30455 = NOVALUE;
L24: 

    /** 			continue*/
    DeRef(_test_60790);
    _test_60790 = NOVALUE;
    goto L1; // [727] 12
    goto L7; // [731] 1801
L21: 

    /** 		elsif id = CONSTANT then*/
    if (_id_60648 != 417)
    goto L25; // [738] 758

    /** 			Global_declaration(0, SC_LOCAL)*/
    _30458 = _30Global_declaration(0, 5);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [755] 1801
L25: 

    /** 		elsif id = ENUM then*/
    if (_id_60648 != 427)
    goto L26; // [762] 782

    /** 			Global_declaration(-1, SC_LOCAL)*/
    _30460 = _30Global_declaration(-1, 5);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [779] 1801
L26: 

    /** 		elsif id = IF then*/
    if (_id_60648 != 20)
    goto L27; // [786] 810

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			If_statement()*/
    _30If_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [807] 1801
L27: 

    /** 		elsif id = FOR then*/
    if (_id_60648 != 21)
    goto L28; // [814] 838

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			For_statement()*/
    _30For_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [835] 1801
L28: 

    /** 		elsif id = WHILE then*/
    if (_id_60648 != 47)
    goto L29; // [842] 866

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			While_statement()*/
    _30While_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [863] 1801
L29: 

    /** 		elsif id = LOOP then*/
    if (_id_60648 != 422)
    goto L2A; // [870] 894

    /** 		    StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 		    Loop_statement()*/
    _30Loop_statement();

    /** 		    ExecCommand()*/
    _30ExecCommand();
    goto L7; // [891] 1801
L2A: 

    /** 		elsif id = PROC or id = QUALIFIED_PROC then*/
    _30465 = (_id_60648 == 27);
    if (_30465 != 0) {
        goto L2B; // [902] 917
    }
    _30467 = (_id_60648 == 521);
    if (_30467 == 0)
    {
        DeRef(_30467);
        _30467 = NOVALUE;
        goto L2C; // [913] 958
    }
    else{
        DeRef(_30467);
        _30467 = NOVALUE;
    }
L2B: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			if id = PROC then*/
    if (_id_60648 != 27)
    goto L2D; // [930] 946

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30469 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30469);
    _30UndefinedVar(_30469);
    _30469 = NOVALUE;
L2D: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_60647);
    _30Procedure_call(_tok_60647);

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [955] 1801
L2C: 

    /** 		elsif id = FUNC or id = QUALIFIED_FUNC then*/
    _30470 = (_id_60648 == 501);
    if (_30470 != 0) {
        goto L2E; // [966] 981
    }
    _30472 = (_id_60648 == 520);
    if (_30472 == 0)
    {
        DeRef(_30472);
        _30472 = NOVALUE;
        goto L2F; // [977] 1035
    }
    else{
        DeRef(_30472);
        _30472 = NOVALUE;
    }
L2E: 

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			if id = FUNC then*/
    if (_id_60648 != 501)
    goto L30; // [994] 1010

    /** 				UndefinedVar( tok[T_SYM] )*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30474 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_30474);
    _30UndefinedVar(_30474);
    _30474 = NOVALUE;
L30: 

    /** 			Procedure_call(tok)*/
    Ref(_tok_60647);
    _30Procedure_call(_tok_60647);

    /** 			clear_op()*/
    _37clear_op();

    /** 			if Pop() then end if*/
    _30475 = _37Pop();
    if (_30475 == 0) {
        DeRef(_30475);
        _30475 = NOVALUE;
        goto L31; // [1024] 1028
    }
    else {
        if (!IS_ATOM_INT(_30475) && DBL_PTR(_30475)->dbl == 0.0){
            DeRef(_30475);
            _30475 = NOVALUE;
            goto L31; // [1024] 1028
        }
        DeRef(_30475);
        _30475 = NOVALUE;
    }
    DeRef(_30475);
    _30475 = NOVALUE;
L31: 

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [1032] 1801
L2F: 

    /** 		elsif id = RETURN then*/
    if (_id_60648 != 413)
    goto L32; // [1039] 1050

    /** 			Return_statement() -- will fail - not allowed at top level*/
    _30Return_statement();
    goto L7; // [1047] 1801
L32: 

    /** 		elsif id = EXIT then*/
    if (_id_60648 != 61)
    goto L33; // [1054] 1090

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L34; // [1060] 1079
    }
    else{
    }

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Exit_statement()*/
    _30Exit_statement();
    goto L7; // [1076] 1801
L34: 

    /** 			CompileErr(89)*/
    RefDS(_21829);
    _43CompileErr(89, _21829, 0);
    goto L7; // [1087] 1801
L33: 

    /** 		elsif id = INCLUDE then*/
    if (_id_60648 != 418)
    goto L35; // [1094] 1110

    /** 			IncludeScan( 0 )*/
    _60IncludeScan(0);

    /** 			PushGoto()*/
    _30PushGoto();
    goto L7; // [1107] 1801
L35: 

    /** 		elsif id = WITH then*/
    if (_id_60648 != 420)
    goto L36; // [1114] 1128

    /** 			SetWith(TRUE)*/
    _30SetWith(_9TRUE_431);
    goto L7; // [1125] 1801
L36: 

    /** 		elsif id = WITHOUT then*/
    if (_id_60648 != 421)
    goto L37; // [1132] 1146

    /** 			SetWith(FALSE)*/
    _30SetWith(_9FALSE_429);
    goto L7; // [1143] 1801
L37: 

    /** 		elsif id = END_OF_FILE then*/
    if (_id_60648 != -21)
    goto L38; // [1150] 1267

    /** 			if IncludePop() then*/
    _30482 = _60IncludePop();
    if (_30482 == 0) {
        DeRef(_30482);
        _30482 = NOVALUE;
        goto L39; // [1159] 1255
    }
    else {
        if (!IS_ATOM_INT(_30482) && DBL_PTR(_30482)->dbl == 0.0){
            DeRef(_30482);
            _30482 = NOVALUE;
            goto L39; // [1159] 1255
        }
        DeRef(_30482);
        _30482 = NOVALUE;
    }
    DeRef(_30482);
    _30482 = NOVALUE;

    /** 				backed_up_tok = {}*/
    RefDS(_21829);
    DeRef(_30backed_up_tok_53692);
    _30backed_up_tok_53692 = _21829;

    /** 				PopGoto()*/
    _30PopGoto();

    /** 				read_line()*/
    _60read_line();

    /** 				last_ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43last_ForwardLine_48161);
    _43last_ForwardLine_48161 = _43ThisLine_48158;

    /** 				last_fwd_line_number = line_number*/
    _12last_fwd_line_number_11686 = _12line_number_11683;

    /** 				last_forward_bp      = bp*/
    _43last_forward_bp_48165 = _43bp_48162;

    /** 				putback_ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43putback_ForwardLine_48160);
    _43putback_ForwardLine_48160 = _43ThisLine_48158;

    /** 				putback_fwd_line_number = line_number*/
    _12putback_fwd_line_number_11685 = _12line_number_11683;

    /** 				putback_forward_bp      = bp*/
    _43putback_forward_bp_48164 = _43bp_48162;

    /** 				ForwardLine     = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43ForwardLine_48159);
    _43ForwardLine_48159 = _43ThisLine_48158;

    /** 				fwd_line_number = line_number*/
    _12fwd_line_number_11684 = _12line_number_11683;

    /** 				forward_bp      = bp*/
    _43forward_bp_48163 = _43bp_48162;
    goto L7; // [1252] 1801
L39: 

    /** 				CheckForUndefinedGotoLabels()*/
    _30CheckForUndefinedGotoLabels();

    /** 				exit -- all finished*/
    goto L2; // [1261] 1811
    goto L7; // [1264] 1801
L38: 

    /** 		elsif id = QUESTION_MARK then*/
    if (_id_60648 != -31)
    goto L3A; // [1271] 1295

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Print_statement()*/
    _30Print_statement();

    /** 			ExecCommand()*/
    _30ExecCommand();
    goto L7; // [1292] 1801
L3A: 

    /** 		elsif id = LABEL then*/
    if (_id_60648 != 419)
    goto L3B; // [1299] 1321

    /** 			StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 			GLabel_statement()*/
    _30GLabel_statement();
    goto L7; // [1318] 1801
L3B: 

    /** 		elsif id = GOTO then*/
    if (_id_60648 != 188)
    goto L3C; // [1325] 1345

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Goto_statement()*/
    _30Goto_statement();
    goto L7; // [1342] 1801
L3C: 

    /** 		elsif id = CONTINUE then*/
    if (_id_60648 != 426)
    goto L3D; // [1349] 1385

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L3E; // [1355] 1374
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 				Continue_statement()*/
    _30Continue_statement();
    goto L7; // [1371] 1801
L3E: 

    /** 				CompileErr(50)*/
    RefDS(_21829);
    _43CompileErr(50, _21829, 0);
    goto L7; // [1382] 1801
L3D: 

    /** 		elsif id = RETRY then*/
    if (_id_60648 != 184)
    goto L3F; // [1389] 1425

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L40; // [1395] 1414
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 				Retry_statement()*/
    _30Retry_statement();
    goto L7; // [1411] 1801
L40: 

    /** 				CompileErr(128)*/
    RefDS(_21829);
    _43CompileErr(128, _21829, 0);
    goto L7; // [1422] 1801
L3F: 

    /** 		elsif id = BREAK then*/
    if (_id_60648 != 425)
    goto L41; // [1429] 1465

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L42; // [1435] 1454
    }
    else{
    }

    /** 				StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 				Break_statement()*/
    _30Break_statement();
    goto L7; // [1451] 1801
L42: 

    /** 				CompileErr(39)*/
    RefDS(_21829);
    _43CompileErr(39, _21829, 0);
    goto L7; // [1462] 1801
L41: 

    /** 		elsif id = ENTRY then*/
    if (_id_60648 != 424)
    goto L43; // [1469] 1507

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L44; // [1475] 1496
    }
    else{
    }

    /** 			    StartSourceLine(TRUE, , COVERAGE_SUPPRESS)*/
    _37StartSourceLine(_9TRUE_431, 0, 1);

    /** 			    Entry_statement()*/
    _30Entry_statement();
    goto L7; // [1493] 1801
L44: 

    /** 				CompileErr(72)*/
    RefDS(_21829);
    _43CompileErr(72, _21829, 0);
    goto L7; // [1504] 1801
L43: 

    /** 		elsif id = IFDEF then*/
    if (_id_60648 != 407)
    goto L45; // [1511] 1531

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Ifdef_statement()*/
    _30Ifdef_statement();
    goto L7; // [1528] 1801
L45: 

    /** 		elsif id = CASE then*/
    if (_id_60648 != 186)
    goto L46; // [1535] 1546

    /** 			Case_statement()*/
    _30Case_statement();
    goto L7; // [1543] 1801
L46: 

    /** 		elsif id = SWITCH then*/
    if (_id_60648 != 185)
    goto L47; // [1550] 1570

    /** 			StartSourceLine(TRUE)*/
    _37StartSourceLine(_9TRUE_431, 0, 2);

    /** 			Switch_statement()*/
    _30Switch_statement();
    goto L7; // [1567] 1801
L47: 

    /** 		elsif id = ILLEGAL_CHAR then*/
    if (_id_60648 != -20)
    goto L48; // [1574] 1588

    /** 			CompileErr(102)*/
    RefDS(_21829);
    _43CompileErr(102, _21829, 0);
    goto L7; // [1585] 1801
L48: 

    /** 			if nested then*/
    if (_nested_60645 == 0)
    {
        goto L49; // [1590] 1742
    }
    else{
    }

    /** 				if id = ELSE then*/
    if (_id_60648 != 23)
    goto L4A; // [1597] 1651

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _30495 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _30495 = 1;
    }
    if (_30495 != 0)
    goto L4B; // [1608] 1708

    /** 						if live_ifdef > 0 then*/
    if (_30live_ifdef_57854 <= 0)
    goto L4C; // [1616] 1639

    /** 							CompileErr(134, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _30498 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _30498 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _30499 = (int)*(((s1_ptr)_2)->base + _30498);
    _43CompileErr(134, _30499, 0);
    _30499 = NOVALUE;
    goto L4B; // [1636] 1708
L4C: 

    /** 							CompileErr(118)*/
    RefDS(_21829);
    _43CompileErr(118, _21829, 0);
    goto L4B; // [1648] 1708
L4A: 

    /** 				elsif id = ELSIF then*/
    if (_id_60648 != 414)
    goto L4D; // [1655] 1707

    /** 					if length(if_stack) = 0 then*/
    if (IS_SEQUENCE(_30if_stack_53720)){
            _30501 = SEQ_PTR(_30if_stack_53720)->length;
    }
    else {
        _30501 = 1;
    }
    if (_30501 != 0)
    goto L4E; // [1666] 1706

    /** 						if live_ifdef > 0 then*/
    if (_30live_ifdef_57854 <= 0)
    goto L4F; // [1674] 1697

    /** 							CompileErr(139, ifdef_lineno[$])*/
    if (IS_SEQUENCE(_30ifdef_lineno_57855)){
            _30504 = SEQ_PTR(_30ifdef_lineno_57855)->length;
    }
    else {
        _30504 = 1;
    }
    _2 = (int)SEQ_PTR(_30ifdef_lineno_57855);
    _30505 = (int)*(((s1_ptr)_2)->base + _30504);
    _43CompileErr(139, _30505, 0);
    _30505 = NOVALUE;
    goto L50; // [1694] 1705
L4F: 

    /** 							CompileErr(119)*/
    RefDS(_21829);
    _43CompileErr(119, _21829, 0);
L50: 
L4E: 
L4D: 
L4B: 

    /** 				putback(tok)*/
    Ref(_tok_60647);
    _30putback(_tok_60647);

    /** 				if stmt_nest > 0 then*/
    if (_30stmt_nest_53717 <= 0)
    goto L51; // [1717] 1734

    /** 					stmt_nest -= 1*/
    _30stmt_nest_53717 = _30stmt_nest_53717 - 1;

    /** 					InitDelete()*/
    _30InitDelete();
L51: 

    /** 				return*/
    DeRef(_tok_60647);
    DeRef(_30411);
    _30411 = NOVALUE;
    DeRef(_30420);
    _30420 = NOVALUE;
    DeRef(_30456);
    _30456 = NOVALUE;
    DeRef(_30428);
    _30428 = NOVALUE;
    DeRef(_30458);
    _30458 = NOVALUE;
    DeRef(_30470);
    _30470 = NOVALUE;
    DeRef(_30409);
    _30409 = NOVALUE;
    _30441 = NOVALUE;
    DeRef(_30434);
    _30434 = NOVALUE;
    DeRef(_30439);
    _30439 = NOVALUE;
    DeRef(_30431);
    _30431 = NOVALUE;
    DeRef(_30403);
    _30403 = NOVALUE;
    _30395 = NOVALUE;
    DeRef(_30398);
    _30398 = NOVALUE;
    DeRef(_30465);
    _30465 = NOVALUE;
    DeRef(_30392);
    _30392 = NOVALUE;
    DeRef(_30426);
    _30426 = NOVALUE;
    DeRef(_30429);
    _30429 = NOVALUE;
    DeRef(_30424);
    _30424 = NOVALUE;
    DeRef(_30448);
    _30448 = NOVALUE;
    DeRef(_30444);
    _30444 = NOVALUE;
    DeRef(_30401);
    _30401 = NOVALUE;
    DeRef(_30407);
    _30407 = NOVALUE;
    DeRef(_30460);
    _30460 = NOVALUE;
    DeRef(_30437);
    _30437 = NOVALUE;
    return;
    goto L52; // [1739] 1800
L49: 

    /** 				if id = END then*/
    if (_id_60648 != 402)
    goto L53; // [1746] 1777

    /** 					tok = next_token()*/
    _0 = _tok_60647;
    _tok_60647 = _30next_token();
    DeRef(_0);

    /** 					CompileErr(17, {find_token_text(tok[T_ID])})*/
    _2 = (int)SEQ_PTR(_tok_60647);
    _30510 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_30510);
    _30511 = _62find_token_text(_30510);
    _30510 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30511;
    _30512 = MAKE_SEQ(_1);
    _30511 = NOVALUE;
    _43CompileErr(17, _30512, 0);
    _30512 = NOVALUE;
L53: 

    /** 				CompileErr(117, { match_replace(",", find_token_text(id), "") })*/
    _30513 = _62find_token_text(_id_60648);
    RefDS(_26019);
    RefDS(_21829);
    _30514 = _20match_replace(_26019, _30513, _21829, 0);
    _30513 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _30514;
    _30515 = MAKE_SEQ(_1);
    _30514 = NOVALUE;
    _43CompileErr(117, _30515, 0);
    _30515 = NOVALUE;
L52: 
L7: 

    /** 		flush_temps()*/
    RefDS(_21829);
    _37flush_temps(_21829);

    /** 	end while*/
    goto L1; // [1808] 12
L2: 

    /** 	emit_op(RETURNT)*/
    _37emit_op(34);

    /** 	clear_last()*/
    _37clear_last();

    /** 	StraightenBranches()*/
    _30StraightenBranches();

    /** 	SymTab[TopLevelSub][S_CODE] = Code*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_12Code_11771);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_CODE_11366))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
    _1 = *(int *)_2;
    *(int *)_2 = _12Code_11771;
    DeRef(_1);
    _30516 = NOVALUE;

    /** 	EndLineTable()*/
    _30EndLineTable();

    /** 	SymTab[TopLevelSub][S_LINETAB] = LineTable*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12TopLevelSub_11689 + ((s1_ptr)_2)->base);
    RefDS(_12LineTable_11772);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_LINETAB_11389))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_LINETAB_11389)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_LINETAB_11389);
    _1 = *(int *)_2;
    *(int *)_2 = _12LineTable_11772;
    DeRef(_1);
    _30518 = NOVALUE;

    /** end procedure*/
    DeRef(_tok_60647);
    DeRef(_30411);
    _30411 = NOVALUE;
    DeRef(_30420);
    _30420 = NOVALUE;
    DeRef(_30456);
    _30456 = NOVALUE;
    DeRef(_30428);
    _30428 = NOVALUE;
    DeRef(_30458);
    _30458 = NOVALUE;
    DeRef(_30470);
    _30470 = NOVALUE;
    DeRef(_30409);
    _30409 = NOVALUE;
    _30441 = NOVALUE;
    DeRef(_30434);
    _30434 = NOVALUE;
    DeRef(_30439);
    _30439 = NOVALUE;
    DeRef(_30431);
    _30431 = NOVALUE;
    DeRef(_30403);
    _30403 = NOVALUE;
    _30395 = NOVALUE;
    DeRef(_30398);
    _30398 = NOVALUE;
    DeRef(_30465);
    _30465 = NOVALUE;
    DeRef(_30392);
    _30392 = NOVALUE;
    DeRef(_30426);
    _30426 = NOVALUE;
    DeRef(_30429);
    _30429 = NOVALUE;
    DeRef(_30424);
    _30424 = NOVALUE;
    DeRef(_30448);
    _30448 = NOVALUE;
    DeRef(_30444);
    _30444 = NOVALUE;
    DeRef(_30401);
    _30401 = NOVALUE;
    DeRef(_30407);
    _30407 = NOVALUE;
    DeRef(_30460);
    _30460 = NOVALUE;
    DeRef(_30437);
    _30437 = NOVALUE;
    return;
    ;
}


void _30parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(0)*/
    _30real_parser(0);

    /** 	mark_final_targets()*/
    _52mark_final_targets();

    /** 	resolve_unincluded_globals( 1 )*/
    _52resolve_unincluded_globals(1);

    /** 	Resolve_forward_references( 1 )*/
    _29Resolve_forward_references(1);

    /** 	inline_deferred_calls()*/
    _66inline_deferred_calls();

    /** 	End_block( PROC )*/
    _65End_block(27);

    /** 	Code = {}*/
    RefDS(_21829);
    DeRef(_12Code_11771);
    _12Code_11771 = _21829;

    /** 	LineTable = {}*/
    RefDS(_21829);
    DeRef(_12LineTable_11772);
    _12LineTable_11772 = _21829;

    /** end procedure*/
    return;
    ;
}


void _30nested_parser()
{
    int _0, _1, _2;
    

    /** 	real_parser(1)*/
    _30real_parser(1);

    /** end procedure*/
    return;
    ;
}



// 0xF8C3C208
