// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _39add_options(int _new_options_48604)
{
    int _0, _1, _2;
    

    /** 	options = splice(options, new_options, COMMON_OPTIONS_SPLICE_IDX)*/
    {
        s1_ptr assign_space;
        insert_pos = 15;
        if (insert_pos <= 0) {
            Concat(&_39options_48600,_new_options_48604,_39options_48600);
        }
        else if (insert_pos > SEQ_PTR(_39options_48600)->length){
            Concat(&_39options_48600,_39options_48600,_new_options_48604);
        }
        else if (IS_SEQUENCE(_new_options_48604)) {
            if( _39options_48600 != _39options_48600 || SEQ_PTR( _39options_48600 )->ref != 1 ){
                DeRef( _39options_48600 );
                RefDS( _39options_48600 );
            }
            assign_space = Add_internal_space( _39options_48600, insert_pos,((s1_ptr)SEQ_PTR(_new_options_48604))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_new_options_48604), _39options_48600 == _39options_48600 );
            _39options_48600 = MAKE_SEQ( assign_space );
        }
        else {
            if( _39options_48600 != _39options_48600 && SEQ_PTR( _39options_48600 )->ref != 1 ){
                _39options_48600 = Insert( _39options_48600, _new_options_48604, insert_pos);
            }
            else {
                DeRef( _39options_48600 );
                RefDS( _39options_48600 );
                _39options_48600 = Insert( _39options_48600, _new_options_48604, insert_pos);
            }
        }
    }

    /** end procedure*/
    DeRefDS(_new_options_48604);
    return;
    ;
}


int _39get_options()
{
    int _0, _1, _2;
    

    /** 	return options*/
    RefDS(_39options_48600);
    return _39options_48600;
    ;
}


int _39get_common_options()
{
    int _0, _1, _2;
    

    /** 	return COMMON_OPTIONS*/
    RefDS(_39COMMON_OPTIONS_48498);
    return _39COMMON_OPTIONS_48498;
    ;
}


int _39get_switches()
{
    int _0, _1, _2;
    

    /** 	return switches*/
    RefDS(_39switches_48497);
    return _39switches_48497;
    ;
}


void _39show_copyrights()
{
    int _notices_48614 = NOVALUE;
    int _25373 = NOVALUE;
    int _25372 = NOVALUE;
    int _25370 = NOVALUE;
    int _25369 = NOVALUE;
    int _25368 = NOVALUE;
    int _25367 = NOVALUE;
    int _25365 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence notices = all_copyrights()*/
    _0 = _notices_48614;
    _notices_48614 = _31all_copyrights();
    DeRef(_0);

    /** 	for i = 1 to length(notices) do*/
    if (IS_SEQUENCE(_notices_48614)){
            _25365 = SEQ_PTR(_notices_48614)->length;
    }
    else {
        _25365 = 1;
    }
    {
        int _i_48618;
        _i_48618 = 1;
L1: 
        if (_i_48618 > _25365){
            goto L2; // [13] 60
        }

        /** 		printf(2, "%s\n  %s\n\n", { notices[i][1], match_replace("\n", notices[i][2], "\n  ") })*/
        _2 = (int)SEQ_PTR(_notices_48614);
        _25367 = (int)*(((s1_ptr)_2)->base + _i_48618);
        _2 = (int)SEQ_PTR(_25367);
        _25368 = (int)*(((s1_ptr)_2)->base + 1);
        _25367 = NOVALUE;
        _2 = (int)SEQ_PTR(_notices_48614);
        _25369 = (int)*(((s1_ptr)_2)->base + _i_48618);
        _2 = (int)SEQ_PTR(_25369);
        _25370 = (int)*(((s1_ptr)_2)->base + 2);
        _25369 = NOVALUE;
        RefDS(_21981);
        Ref(_25370);
        RefDS(_25371);
        _25372 = _20match_replace(_21981, _25370, _25371, 0);
        _25370 = NOVALUE;
        Ref(_25368);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _25368;
        ((int *)_2)[2] = _25372;
        _25373 = MAKE_SEQ(_1);
        _25372 = NOVALUE;
        _25368 = NOVALUE;
        EPrintf(2, _25366, _25373);
        DeRefDS(_25373);
        _25373 = NOVALUE;

        /** 	end for*/
        _i_48618 = _i_48618 + 1;
        goto L1; // [55] 20
L2: 
        ;
    }

    /** end procedure*/
    DeRef(_notices_48614);
    return;
    ;
}


void _39show_banner()
{
    int _version_type_inlined_version_type_at_206_48681 = NOVALUE;
    int _version_string_short_1__tmp_at190_48679 = NOVALUE;
    int _version_string_short_inlined_version_string_short_at_190_48678 = NOVALUE;
    int _version_revision_inlined_version_revision_at_121_48660 = NOVALUE;
    int _platform_name_inlined_platform_name_at_83_48652 = NOVALUE;
    int _prod_name_48631 = NOVALUE;
    int _memory_type_48632 = NOVALUE;
    int _misc_info_48650 = NOVALUE;
    int _EuConsole_48664 = NOVALUE;
    int _25397 = NOVALUE;
    int _25396 = NOVALUE;
    int _25395 = NOVALUE;
    int _25392 = NOVALUE;
    int _25391 = NOVALUE;
    int _25387 = NOVALUE;
    int _25386 = NOVALUE;
    int _25385 = NOVALUE;
    int _25383 = NOVALUE;
    int _25381 = NOVALUE;
    int _25380 = NOVALUE;
    int _25375 = NOVALUE;
    int _25374 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if INTERPRET and not BIND then*/
    if (_12INTERPRET_11316 == 0) {
        goto L1; // [5] 31
    }
    _25375 = (_12BIND_11322 == 0);
    if (_25375 == 0)
    {
        DeRef(_25375);
        _25375 = NOVALUE;
        goto L1; // [15] 31
    }
    else{
        DeRef(_25375);
        _25375 = NOVALUE;
    }

    /** 		prod_name = GetMsgText(270,0)*/
    RefDS(_21829);
    _0 = _prod_name_48631;
    _prod_name_48631 = _44GetMsgText(270, 0, _21829);
    DeRef(_0);
    goto L2; // [28] 70
L1: 

    /** 	elsif TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [35] 51
    }
    else{
    }

    /** 		prod_name = GetMsgText(271,0)*/
    RefDS(_21829);
    _0 = _prod_name_48631;
    _prod_name_48631 = _44GetMsgText(271, 0, _21829);
    DeRef(_0);
    goto L2; // [48] 70
L3: 

    /** 	elsif BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L4; // [55] 69
    }
    else{
    }

    /** 		prod_name = GetMsgText(272,0)*/
    RefDS(_21829);
    _0 = _prod_name_48631;
    _prod_name_48631 = _44GetMsgText(272, 0, _21829);
    DeRef(_0);
L4: 
L2: 

    /** 	ifdef EU_MANAGED_MEM then*/

    /** 		memory_type = GetMsgText(274,0)*/
    RefDS(_21829);
    _0 = _memory_type_48632;
    _memory_type_48632 = _44GetMsgText(274, 0, _21829);
    DeRef(_0);

    /** 	sequence misc_info = {*/

    /** 	ifdef WINDOWS then*/

    /** 		return "Linux"*/
    RefDS(_6246);
    DeRefi(_platform_name_inlined_platform_name_at_83_48652);
    _platform_name_inlined_platform_name_at_83_48652 = _6246;
    _25380 = _31version_date(0);
    _25381 = _31version_node(0);
    _0 = _misc_info_48650;
    _1 = NewS1(5);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_platform_name_inlined_platform_name_at_83_48652);
    *((int *)(_2+4)) = _platform_name_inlined_platform_name_at_83_48652;
    RefDS(_memory_type_48632);
    *((int *)(_2+8)) = _memory_type_48632;
    RefDS(_21829);
    *((int *)(_2+12)) = _21829;
    *((int *)(_2+16)) = _25380;
    *((int *)(_2+20)) = _25381;
    _misc_info_48650 = MAKE_SEQ(_1);
    DeRef(_0);
    _25381 = NOVALUE;
    _25380 = NOVALUE;

    /** 	if info:is_developmental then*/
    if (_31is_developmental_11825 == 0)
    {
        goto L5; // [114] 148
    }
    else{
    }

    /** 		misc_info[$] = sprintf("%d:%s", { info:version_revision(), info:version_node() })*/
    _25383 = 5;

    /** 	return version_info[REVISION]*/
    DeRef(_version_revision_inlined_version_revision_at_121_48660);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _version_revision_inlined_version_revision_at_121_48660 = (int)*(((s1_ptr)_2)->base + 6);
    Ref(_version_revision_inlined_version_revision_at_121_48660);
    _25385 = _31version_node(0);
    Ref(_version_revision_inlined_version_revision_at_121_48660);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _version_revision_inlined_version_revision_at_121_48660;
    ((int *)_2)[2] = _25385;
    _25386 = MAKE_SEQ(_1);
    _25385 = NOVALUE;
    _25387 = EPrintf(-9999999, _25384, _25386);
    DeRefDS(_25386);
    _25386 = NOVALUE;
    _2 = (int)SEQ_PTR(_misc_info_48650);
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _25387;
    if( _1 != _25387 ){
        DeRef(_1);
    }
    _25387 = NOVALUE;
L5: 

    /** 	object EuConsole = getenv("EUCONS")*/
    DeRefi(_EuConsole_48664);
    _EuConsole_48664 = EGetEnv(_25388);

    /** 	if equal(EuConsole, "1") then*/
    if (_EuConsole_48664 == _25390)
    _25391 = 1;
    else if (IS_ATOM_INT(_EuConsole_48664) && IS_ATOM_INT(_25390))
    _25391 = 0;
    else
    _25391 = (compare(_EuConsole_48664, _25390) == 0);
    if (_25391 == 0)
    {
        _25391 = NOVALUE;
        goto L6; // [159] 177
    }
    else{
        _25391 = NOVALUE;
    }

    /** 		misc_info[3] = GetMsgText(275,0)*/
    RefDS(_21829);
    _25392 = _44GetMsgText(275, 0, _21829);
    _2 = (int)SEQ_PTR(_misc_info_48650);
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _25392;
    if( _1 != _25392 ){
        DeRef(_1);
    }
    _25392 = NOVALUE;
    goto L7; // [174] 185
L6: 

    /** 		misc_info = remove(misc_info, 3)*/
    {
        s1_ptr assign_space = SEQ_PTR(_misc_info_48650);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        int stop = (IS_ATOM_INT(3)) ? 3 : (long)(DBL_PTR(3)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_misc_info_48650), start, &_misc_info_48650 );
            }
            else Tail(SEQ_PTR(_misc_info_48650), stop+1, &_misc_info_48650);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_misc_info_48650), start, &_misc_info_48650);
        }
        else {
            assign_slice_seq = &assign_space;
            _misc_info_48650 = Remove_elements(start, stop, (SEQ_PTR(_misc_info_48650)->ref == 1));
        }
    }
L7: 

    /** 	screen_output(STDERR, sprintf("%s v%s %s\n   %s, %s\n   Revision Date: %s, Id: %s\n", {*/

    /** 	return sprintf("%d.%d.%d", version_info[MAJ_VER..PAT_VER])*/
    rhs_slice_target = (object_ptr)&_version_string_short_1__tmp_at190_48679;
    RHS_Slice(_31version_info_11823, 1, 3);
    DeRefi(_version_string_short_inlined_version_string_short_at_190_48678);
    _version_string_short_inlined_version_string_short_at_190_48678 = EPrintf(-9999999, _6476, _version_string_short_1__tmp_at190_48679);
    DeRef(_version_string_short_1__tmp_at190_48679);
    _version_string_short_1__tmp_at190_48679 = NOVALUE;

    /** 	return version_info[VER_TYPE]*/
    DeRef(_version_type_inlined_version_type_at_206_48681);
    _2 = (int)SEQ_PTR(_31version_info_11823);
    _version_type_inlined_version_type_at_206_48681 = (int)*(((s1_ptr)_2)->base + 4);
    Ref(_version_type_inlined_version_type_at_206_48681);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_prod_name_48631);
    *((int *)(_2+4)) = _prod_name_48631;
    RefDS(_version_string_short_inlined_version_string_short_at_190_48678);
    *((int *)(_2+8)) = _version_string_short_inlined_version_string_short_at_190_48678;
    Ref(_version_type_inlined_version_type_at_206_48681);
    *((int *)(_2+12)) = _version_type_inlined_version_type_at_206_48681;
    _25395 = MAKE_SEQ(_1);
    Concat((object_ptr)&_25396, _25395, _misc_info_48650);
    DeRefDS(_25395);
    _25395 = NOVALUE;
    DeRef(_25395);
    _25395 = NOVALUE;
    _25397 = EPrintf(-9999999, _25394, _25396);
    DeRefDS(_25396);
    _25396 = NOVALUE;
    _43screen_output(2, _25397);
    _25397 = NOVALUE;

    /** end procedure*/
    DeRefDS(_prod_name_48631);
    DeRef(_memory_type_48632);
    DeRefDS(_misc_info_48650);
    DeRefi(_EuConsole_48664);
    return;
    ;
}


int _39find_opt(int _name_type_48693, int _opt_48694, int _opts_48695)
{
    int _o_48699 = NOVALUE;
    int _has_case_48701 = NOVALUE;
    int _25410 = NOVALUE;
    int _25409 = NOVALUE;
    int _25408 = NOVALUE;
    int _25407 = NOVALUE;
    int _25406 = NOVALUE;
    int _25405 = NOVALUE;
    int _25404 = NOVALUE;
    int _25403 = NOVALUE;
    int _25402 = NOVALUE;
    int _25400 = NOVALUE;
    int _25398 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(opts) do*/
    if (IS_SEQUENCE(_opts_48695)){
            _25398 = SEQ_PTR(_opts_48695)->length;
    }
    else {
        _25398 = 1;
    }
    {
        int _i_48697;
        _i_48697 = 1;
L1: 
        if (_i_48697 > _25398){
            goto L2; // [12] 113
        }

        /** 		sequence o = opts[i]		*/
        DeRef(_o_48699);
        _2 = (int)SEQ_PTR(_opts_48695);
        _o_48699 = (int)*(((s1_ptr)_2)->base + _i_48697);
        Ref(_o_48699);

        /** 		integer has_case = find(HAS_CASE, o[OPTIONS])*/
        _2 = (int)SEQ_PTR(_o_48699);
        _25400 = (int)*(((s1_ptr)_2)->base + 4);
        _has_case_48701 = find_from(99, _25400, 1);
        _25400 = NOVALUE;

        /** 		if has_case and equal(o[name_type], opt) then*/
        if (_has_case_48701 == 0) {
            goto L3; // [42] 67
        }
        _2 = (int)SEQ_PTR(_o_48699);
        _25403 = (int)*(((s1_ptr)_2)->base + _name_type_48693);
        if (_25403 == _opt_48694)
        _25404 = 1;
        else if (IS_ATOM_INT(_25403) && IS_ATOM_INT(_opt_48694))
        _25404 = 0;
        else
        _25404 = (compare(_25403, _opt_48694) == 0);
        _25403 = NOVALUE;
        if (_25404 == 0)
        {
            _25404 = NOVALUE;
            goto L3; // [55] 67
        }
        else{
            _25404 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_48694);
        DeRefDS(_opts_48695);
        return _o_48699;
        goto L4; // [64] 104
L3: 

        /** 		elsif not has_case and equal(text:lower(o[name_type]), text:lower(opt)) then*/
        _25405 = (_has_case_48701 == 0);
        if (_25405 == 0) {
            goto L5; // [72] 103
        }
        _2 = (int)SEQ_PTR(_o_48699);
        _25407 = (int)*(((s1_ptr)_2)->base + _name_type_48693);
        Ref(_25407);
        _25408 = _18lower(_25407);
        _25407 = NOVALUE;
        RefDS(_opt_48694);
        _25409 = _18lower(_opt_48694);
        if (_25408 == _25409)
        _25410 = 1;
        else if (IS_ATOM_INT(_25408) && IS_ATOM_INT(_25409))
        _25410 = 0;
        else
        _25410 = (compare(_25408, _25409) == 0);
        DeRef(_25408);
        _25408 = NOVALUE;
        DeRef(_25409);
        _25409 = NOVALUE;
        if (_25410 == 0)
        {
            _25410 = NOVALUE;
            goto L5; // [93] 103
        }
        else{
            _25410 = NOVALUE;
        }

        /** 			return o*/
        DeRefDS(_opt_48694);
        DeRefDS(_opts_48695);
        DeRef(_25405);
        _25405 = NOVALUE;
        return _o_48699;
L5: 
L4: 
        DeRef(_o_48699);
        _o_48699 = NOVALUE;

        /** 	end for*/
        _i_48697 = _i_48697 + 1;
        goto L1; // [108] 19
L2: 
        ;
    }

    /** 	return {}*/
    RefDS(_21829);
    DeRefDS(_opt_48694);
    DeRefDS(_opts_48695);
    DeRef(_25405);
    _25405 = NOVALUE;
    return _21829;
    ;
}


int _39merge_parameters(int _a_48718, int _b_48719, int _opts_48720, int _dedupe_48721)
{
    int _i_48722 = NOVALUE;
    int _opt_48726 = NOVALUE;
    int _this_opt_48732 = NOVALUE;
    int _bi_48733 = NOVALUE;
    int _beginLen_48793 = NOVALUE;
    int _first_extra_48815 = NOVALUE;
    int _opt_48819 = NOVALUE;
    int _this_opt_48824 = NOVALUE;
    int _25504 = NOVALUE;
    int _25503 = NOVALUE;
    int _25500 = NOVALUE;
    int _25499 = NOVALUE;
    int _25498 = NOVALUE;
    int _25496 = NOVALUE;
    int _25495 = NOVALUE;
    int _25494 = NOVALUE;
    int _25493 = NOVALUE;
    int _25491 = NOVALUE;
    int _25490 = NOVALUE;
    int _25488 = NOVALUE;
    int _25487 = NOVALUE;
    int _25486 = NOVALUE;
    int _25485 = NOVALUE;
    int _25484 = NOVALUE;
    int _25483 = NOVALUE;
    int _25482 = NOVALUE;
    int _25480 = NOVALUE;
    int _25477 = NOVALUE;
    int _25476 = NOVALUE;
    int _25471 = NOVALUE;
    int _25469 = NOVALUE;
    int _25468 = NOVALUE;
    int _25467 = NOVALUE;
    int _25466 = NOVALUE;
    int _25465 = NOVALUE;
    int _25464 = NOVALUE;
    int _25463 = NOVALUE;
    int _25462 = NOVALUE;
    int _25458 = NOVALUE;
    int _25457 = NOVALUE;
    int _25456 = NOVALUE;
    int _25455 = NOVALUE;
    int _25454 = NOVALUE;
    int _25453 = NOVALUE;
    int _25452 = NOVALUE;
    int _25451 = NOVALUE;
    int _25450 = NOVALUE;
    int _25449 = NOVALUE;
    int _25448 = NOVALUE;
    int _25447 = NOVALUE;
    int _25446 = NOVALUE;
    int _25445 = NOVALUE;
    int _25444 = NOVALUE;
    int _25442 = NOVALUE;
    int _25441 = NOVALUE;
    int _25440 = NOVALUE;
    int _25439 = NOVALUE;
    int _25438 = NOVALUE;
    int _25437 = NOVALUE;
    int _25436 = NOVALUE;
    int _25435 = NOVALUE;
    int _25433 = NOVALUE;
    int _25432 = NOVALUE;
    int _25431 = NOVALUE;
    int _25430 = NOVALUE;
    int _25428 = NOVALUE;
    int _25427 = NOVALUE;
    int _25426 = NOVALUE;
    int _25425 = NOVALUE;
    int _25424 = NOVALUE;
    int _25423 = NOVALUE;
    int _25422 = NOVALUE;
    int _25420 = NOVALUE;
    int _25419 = NOVALUE;
    int _25417 = NOVALUE;
    int _25414 = NOVALUE;
    int _25411 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_dedupe_48721)) {
        _1 = (long)(DBL_PTR(_dedupe_48721)->dbl);
        DeRefDS(_dedupe_48721);
        _dedupe_48721 = _1;
    }

    /** 	integer i = 1*/
    _i_48722 = 1;

    /** 	while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_48718)){
            _25411 = SEQ_PTR(_a_48718)->length;
    }
    else {
        _25411 = 1;
    }
    if (_i_48722 > _25411)
    goto L2; // [22] 465

    /** 		sequence opt = a[i]*/
    DeRef(_opt_48726);
    _2 = (int)SEQ_PTR(_a_48718);
    _opt_48726 = (int)*(((s1_ptr)_2)->base + _i_48722);
    Ref(_opt_48726);

    /** 		if length(opt) < 2 then*/
    if (IS_SEQUENCE(_opt_48726)){
            _25414 = SEQ_PTR(_opt_48726)->length;
    }
    else {
        _25414 = 1;
    }
    if (_25414 >= 2)
    goto L3; // [39] 56

    /** 			i += 1*/
    _i_48722 = _i_48722 + 1;

    /** 			continue*/
    DeRefDS(_opt_48726);
    _opt_48726 = NOVALUE;
    DeRef(_this_opt_48732);
    _this_opt_48732 = NOVALUE;
    goto L1; // [53] 19
L3: 

    /** 		sequence this_opt = {}*/
    RefDS(_21829);
    DeRef(_this_opt_48732);
    _this_opt_48732 = _21829;

    /** 		integer bi = 0*/
    _bi_48733 = 0;

    /** 		if opt[2] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_48726);
    _25417 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25417, 45)){
        _25417 = NOVALUE;
        goto L4; // [74] 149
    }
    _25417 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_48726)){
            _25419 = SEQ_PTR(_opt_48726)->length;
    }
    else {
        _25419 = 1;
    }
    rhs_slice_target = (object_ptr)&_25420;
    RHS_Slice(_opt_48726, 3, _25419);
    RefDS(_opts_48720);
    _0 = _this_opt_48732;
    _this_opt_48732 = _39find_opt(2, _25420, _opts_48720);
    DeRefDS(_0);
    _25420 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_48719)){
            _25422 = SEQ_PTR(_b_48719)->length;
    }
    else {
        _25422 = 1;
    }
    {
        int _j_48741;
        _j_48741 = 1;
L5: 
        if (_j_48741 > _25422){
            goto L6; // [101] 146
        }

        /** 				if equal(text:lower(b[j]), text:lower(opt)) then*/
        _2 = (int)SEQ_PTR(_b_48719);
        _25423 = (int)*(((s1_ptr)_2)->base + _j_48741);
        Ref(_25423);
        _25424 = _18lower(_25423);
        _25423 = NOVALUE;
        RefDS(_opt_48726);
        _25425 = _18lower(_opt_48726);
        if (_25424 == _25425)
        _25426 = 1;
        else if (IS_ATOM_INT(_25424) && IS_ATOM_INT(_25425))
        _25426 = 0;
        else
        _25426 = (compare(_25424, _25425) == 0);
        DeRef(_25424);
        _25424 = NOVALUE;
        DeRef(_25425);
        _25425 = NOVALUE;
        if (_25426 == 0)
        {
            _25426 = NOVALUE;
            goto L7; // [126] 139
        }
        else{
            _25426 = NOVALUE;
        }

        /** 					bi = j*/
        _bi_48733 = _j_48741;

        /** 					exit*/
        goto L6; // [136] 146
L7: 

        /** 			end for*/
        _j_48741 = _j_48741 + 1;
        goto L5; // [141] 108
L6: 
        ;
    }
    goto L8; // [146] 292
L4: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_48726);
    _25427 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25427)) {
        _25428 = (_25427 == 45);
    }
    else {
        _25428 = binary_op(EQUALS, _25427, 45);
    }
    _25427 = NOVALUE;
    if (IS_ATOM_INT(_25428)) {
        if (_25428 != 0) {
            goto L9; // [159] 176
        }
    }
    else {
        if (DBL_PTR(_25428)->dbl != 0.0) {
            goto L9; // [159] 176
        }
    }
    _2 = (int)SEQ_PTR(_opt_48726);
    _25430 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25430)) {
        _25431 = (_25430 == 47);
    }
    else {
        _25431 = binary_op(EQUALS, _25430, 47);
    }
    _25430 = NOVALUE;
    if (_25431 == 0) {
        DeRef(_25431);
        _25431 = NOVALUE;
        goto LA; // [172] 291
    }
    else {
        if (!IS_ATOM_INT(_25431) && DBL_PTR(_25431)->dbl == 0.0){
            DeRef(_25431);
            _25431 = NOVALUE;
            goto LA; // [172] 291
        }
        DeRef(_25431);
        _25431 = NOVALUE;
    }
    DeRef(_25431);
    _25431 = NOVALUE;
L9: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_48726)){
            _25432 = SEQ_PTR(_opt_48726)->length;
    }
    else {
        _25432 = 1;
    }
    rhs_slice_target = (object_ptr)&_25433;
    RHS_Slice(_opt_48726, 2, _25432);
    RefDS(_opts_48720);
    _0 = _this_opt_48732;
    _this_opt_48732 = _39find_opt(1, _25433, _opts_48720);
    DeRef(_0);
    _25433 = NOVALUE;

    /** 			for j = 1 to length(b) do*/
    if (IS_SEQUENCE(_b_48719)){
            _25435 = SEQ_PTR(_b_48719)->length;
    }
    else {
        _25435 = 1;
    }
    {
        int _j_48758;
        _j_48758 = 1;
LB: 
        if (_j_48758 > _25435){
            goto LC; // [199] 290
        }

        /** 				if equal(text:lower(b[j]), '-' & text:lower(opt[2..$])) or */
        _2 = (int)SEQ_PTR(_b_48719);
        _25436 = (int)*(((s1_ptr)_2)->base + _j_48758);
        Ref(_25436);
        _25437 = _18lower(_25436);
        _25436 = NOVALUE;
        if (IS_SEQUENCE(_opt_48726)){
                _25438 = SEQ_PTR(_opt_48726)->length;
        }
        else {
            _25438 = 1;
        }
        rhs_slice_target = (object_ptr)&_25439;
        RHS_Slice(_opt_48726, 2, _25438);
        _25440 = _18lower(_25439);
        _25439 = NOVALUE;
        if (IS_SEQUENCE(45) && IS_ATOM(_25440)) {
        }
        else if (IS_ATOM(45) && IS_SEQUENCE(_25440)) {
            Prepend(&_25441, _25440, 45);
        }
        else {
            Concat((object_ptr)&_25441, 45, _25440);
        }
        DeRef(_25440);
        _25440 = NOVALUE;
        if (_25437 == _25441)
        _25442 = 1;
        else if (IS_ATOM_INT(_25437) && IS_ATOM_INT(_25441))
        _25442 = 0;
        else
        _25442 = (compare(_25437, _25441) == 0);
        DeRef(_25437);
        _25437 = NOVALUE;
        DeRefDS(_25441);
        _25441 = NOVALUE;
        if (_25442 != 0) {
            goto LD; // [236] 273
        }
        _2 = (int)SEQ_PTR(_b_48719);
        _25444 = (int)*(((s1_ptr)_2)->base + _j_48758);
        Ref(_25444);
        _25445 = _18lower(_25444);
        _25444 = NOVALUE;
        if (IS_SEQUENCE(_opt_48726)){
                _25446 = SEQ_PTR(_opt_48726)->length;
        }
        else {
            _25446 = 1;
        }
        rhs_slice_target = (object_ptr)&_25447;
        RHS_Slice(_opt_48726, 2, _25446);
        _25448 = _18lower(_25447);
        _25447 = NOVALUE;
        if (IS_SEQUENCE(47) && IS_ATOM(_25448)) {
        }
        else if (IS_ATOM(47) && IS_SEQUENCE(_25448)) {
            Prepend(&_25449, _25448, 47);
        }
        else {
            Concat((object_ptr)&_25449, 47, _25448);
        }
        DeRef(_25448);
        _25448 = NOVALUE;
        if (_25445 == _25449)
        _25450 = 1;
        else if (IS_ATOM_INT(_25445) && IS_ATOM_INT(_25449))
        _25450 = 0;
        else
        _25450 = (compare(_25445, _25449) == 0);
        DeRef(_25445);
        _25445 = NOVALUE;
        DeRefDS(_25449);
        _25449 = NOVALUE;
        if (_25450 == 0)
        {
            _25450 = NOVALUE;
            goto LE; // [269] 283
        }
        else{
            _25450 = NOVALUE;
        }
LD: 

        /** 					bi = j*/
        _bi_48733 = _j_48758;

        /** 					exit*/
        goto LC; // [280] 290
LE: 

        /** 			end for*/
        _j_48758 = _j_48758 + 1;
        goto LB; // [285] 206
LC: 
        ;
    }
LA: 
L8: 

    /** 		if length(this_opt) and not find(MULTIPLE, this_opt[OPTIONS]) then*/
    if (IS_SEQUENCE(_this_opt_48732)){
            _25451 = SEQ_PTR(_this_opt_48732)->length;
    }
    else {
        _25451 = 1;
    }
    if (_25451 == 0) {
        goto LF; // [297] 451
    }
    _2 = (int)SEQ_PTR(_this_opt_48732);
    _25453 = (int)*(((s1_ptr)_2)->base + 4);
    _25454 = find_from(42, _25453, 1);
    _25453 = NOVALUE;
    _25455 = (_25454 == 0);
    _25454 = NOVALUE;
    if (_25455 == 0)
    {
        DeRef(_25455);
        _25455 = NOVALUE;
        goto LF; // [316] 451
    }
    else{
        DeRef(_25455);
        _25455 = NOVALUE;
    }

    /** 			if bi then*/
    if (_bi_48733 == 0)
    {
        goto L10; // [321] 365
    }
    else{
    }

    /** 				if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_48732);
    _25456 = (int)*(((s1_ptr)_2)->base + 4);
    _25457 = find_from(112, _25456, 1);
    _25456 = NOVALUE;
    if (_25457 == 0)
    {
        _25457 = NOVALUE;
        goto L11; // [337] 354
    }
    else{
        _25457 = NOVALUE;
    }

    /** 					a = remove(a, i, i + 1)*/
    _25458 = _i_48722 + 1;
    if (_25458 > MAXINT){
        _25458 = NewDouble((double)_25458);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_a_48718);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_48722)) ? _i_48722 : (long)(DBL_PTR(_i_48722)->dbl);
        int stop = (IS_ATOM_INT(_25458)) ? _25458 : (long)(DBL_PTR(_25458)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_48718), start, &_a_48718 );
            }
            else Tail(SEQ_PTR(_a_48718), stop+1, &_a_48718);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_48718), start, &_a_48718);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_48718 = Remove_elements(start, stop, (SEQ_PTR(_a_48718)->ref == 1));
        }
    }
    DeRef(_25458);
    _25458 = NOVALUE;
    goto L12; // [351] 458
L11: 

    /** 					a = remove(a, i)*/
    {
        s1_ptr assign_space = SEQ_PTR(_a_48718);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_i_48722)) ? _i_48722 : (long)(DBL_PTR(_i_48722)->dbl);
        int stop = (IS_ATOM_INT(_i_48722)) ? _i_48722 : (long)(DBL_PTR(_i_48722)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_a_48718), start, &_a_48718 );
            }
            else Tail(SEQ_PTR(_a_48718), stop+1, &_a_48718);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_a_48718), start, &_a_48718);
        }
        else {
            assign_slice_seq = &assign_space;
            _a_48718 = Remove_elements(start, stop, (SEQ_PTR(_a_48718)->ref == 1));
        }
    }
    goto L12; // [362] 458
L10: 

    /** 				integer beginLen = length(a)*/
    if (IS_SEQUENCE(_a_48718)){
            _beginLen_48793 = SEQ_PTR(_a_48718)->length;
    }
    else {
        _beginLen_48793 = 1;
    }

    /** 				if dedupe = 0 and i < beginLen then*/
    _25462 = (_dedupe_48721 == 0);
    if (_25462 == 0) {
        goto L13; // [376] 438
    }
    _25464 = (_i_48722 < _beginLen_48793);
    if (_25464 == 0)
    {
        DeRef(_25464);
        _25464 = NOVALUE;
        goto L13; // [385] 438
    }
    else{
        DeRef(_25464);
        _25464 = NOVALUE;
    }

    /** 					a = merge_parameters( a[i + 1..$], a[1..i], opts, 1)*/
    _25465 = _i_48722 + 1;
    if (_25465 > MAXINT){
        _25465 = NewDouble((double)_25465);
    }
    if (IS_SEQUENCE(_a_48718)){
            _25466 = SEQ_PTR(_a_48718)->length;
    }
    else {
        _25466 = 1;
    }
    rhs_slice_target = (object_ptr)&_25467;
    RHS_Slice(_a_48718, _25465, _25466);
    rhs_slice_target = (object_ptr)&_25468;
    RHS_Slice(_a_48718, 1, _i_48722);
    RefDS(_opts_48720);
    DeRef(_25469);
    _25469 = _opts_48720;
    _0 = _a_48718;
    _a_48718 = _39merge_parameters(_25467, _25468, _25469, 1);
    DeRefDS(_0);
    _25467 = NOVALUE;
    _25468 = NOVALUE;
    _25469 = NOVALUE;

    /** 					if beginLen = length(a) then*/
    if (IS_SEQUENCE(_a_48718)){
            _25471 = SEQ_PTR(_a_48718)->length;
    }
    else {
        _25471 = 1;
    }
    if (_beginLen_48793 != _25471)
    goto L14; // [424] 445

    /** 						i += 1*/
    _i_48722 = _i_48722 + 1;
    goto L14; // [435] 445
L13: 

    /** 					i += 1*/
    _i_48722 = _i_48722 + 1;
L14: 
    goto L12; // [448] 458
LF: 

    /** 			i += 1*/
    _i_48722 = _i_48722 + 1;
L12: 
    DeRef(_opt_48726);
    _opt_48726 = NOVALUE;
    DeRef(_this_opt_48732);
    _this_opt_48732 = NOVALUE;

    /** 	end while*/
    goto L1; // [462] 19
L2: 

    /** 	if dedupe then*/
    if (_dedupe_48721 == 0)
    {
        goto L15; // [467] 481
    }
    else{
    }

    /** 		return b & a*/
    Concat((object_ptr)&_25476, _b_48719, _a_48718);
    DeRefDS(_a_48718);
    DeRefDS(_b_48719);
    DeRefDS(_opts_48720);
    DeRef(_25462);
    _25462 = NOVALUE;
    DeRef(_25428);
    _25428 = NOVALUE;
    DeRef(_25465);
    _25465 = NOVALUE;
    return _25476;
L15: 

    /** 	integer first_extra = 0*/
    _first_extra_48815 = 0;

    /** 	i = 1*/
    _i_48722 = 1;

    /** 	while i <= length(b) do*/
L16: 
    if (IS_SEQUENCE(_b_48719)){
            _25477 = SEQ_PTR(_b_48719)->length;
    }
    else {
        _25477 = 1;
    }
    if (_i_48722 > _25477)
    goto L17; // [499] 692

    /** 		sequence opt = b[i]*/
    DeRef(_opt_48819);
    _2 = (int)SEQ_PTR(_b_48719);
    _opt_48819 = (int)*(((s1_ptr)_2)->base + _i_48722);
    Ref(_opt_48819);

    /** 		if length(opt) <= 1 then*/
    if (IS_SEQUENCE(_opt_48819)){
            _25480 = SEQ_PTR(_opt_48819)->length;
    }
    else {
        _25480 = 1;
    }
    if (_25480 > 1)
    goto L18; // [516] 532

    /** 			first_extra = i*/
    _first_extra_48815 = _i_48722;

    /** 			exit*/
    DeRefDS(_opt_48819);
    _opt_48819 = NOVALUE;
    DeRef(_this_opt_48824);
    _this_opt_48824 = NOVALUE;
    goto L17; // [529] 692
L18: 

    /** 		sequence this_opt = {}*/
    RefDS(_21829);
    DeRef(_this_opt_48824);
    _this_opt_48824 = _21829;

    /** 		if opt[2] = '-' and opt[1] = '-' then*/
    _2 = (int)SEQ_PTR(_opt_48819);
    _25482 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25482)) {
        _25483 = (_25482 == 45);
    }
    else {
        _25483 = binary_op(EQUALS, _25482, 45);
    }
    _25482 = NOVALUE;
    if (IS_ATOM_INT(_25483)) {
        if (_25483 == 0) {
            goto L19; // [549] 586
        }
    }
    else {
        if (DBL_PTR(_25483)->dbl == 0.0) {
            goto L19; // [549] 586
        }
    }
    _2 = (int)SEQ_PTR(_opt_48819);
    _25485 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25485)) {
        _25486 = (_25485 == 45);
    }
    else {
        _25486 = binary_op(EQUALS, _25485, 45);
    }
    _25485 = NOVALUE;
    if (_25486 == 0) {
        DeRef(_25486);
        _25486 = NOVALUE;
        goto L19; // [562] 586
    }
    else {
        if (!IS_ATOM_INT(_25486) && DBL_PTR(_25486)->dbl == 0.0){
            DeRef(_25486);
            _25486 = NOVALUE;
            goto L19; // [562] 586
        }
        DeRef(_25486);
        _25486 = NOVALUE;
    }
    DeRef(_25486);
    _25486 = NOVALUE;

    /** 			this_opt = find_opt(LONGNAME, opt[3..$], opts)*/
    if (IS_SEQUENCE(_opt_48819)){
            _25487 = SEQ_PTR(_opt_48819)->length;
    }
    else {
        _25487 = 1;
    }
    rhs_slice_target = (object_ptr)&_25488;
    RHS_Slice(_opt_48819, 3, _25487);
    RefDS(_opts_48720);
    _0 = _this_opt_48824;
    _this_opt_48824 = _39find_opt(2, _25488, _opts_48720);
    DeRef(_0);
    _25488 = NOVALUE;
    goto L1A; // [583] 633
L19: 

    /** 		elsif opt[1] = '-' or opt[1] = '/' then*/
    _2 = (int)SEQ_PTR(_opt_48819);
    _25490 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25490)) {
        _25491 = (_25490 == 45);
    }
    else {
        _25491 = binary_op(EQUALS, _25490, 45);
    }
    _25490 = NOVALUE;
    if (IS_ATOM_INT(_25491)) {
        if (_25491 != 0) {
            goto L1B; // [596] 613
        }
    }
    else {
        if (DBL_PTR(_25491)->dbl != 0.0) {
            goto L1B; // [596] 613
        }
    }
    _2 = (int)SEQ_PTR(_opt_48819);
    _25493 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25493)) {
        _25494 = (_25493 == 47);
    }
    else {
        _25494 = binary_op(EQUALS, _25493, 47);
    }
    _25493 = NOVALUE;
    if (_25494 == 0) {
        DeRef(_25494);
        _25494 = NOVALUE;
        goto L1C; // [609] 632
    }
    else {
        if (!IS_ATOM_INT(_25494) && DBL_PTR(_25494)->dbl == 0.0){
            DeRef(_25494);
            _25494 = NOVALUE;
            goto L1C; // [609] 632
        }
        DeRef(_25494);
        _25494 = NOVALUE;
    }
    DeRef(_25494);
    _25494 = NOVALUE;
L1B: 

    /** 			this_opt = find_opt(SHORTNAME, opt[2..$], opts)*/
    if (IS_SEQUENCE(_opt_48819)){
            _25495 = SEQ_PTR(_opt_48819)->length;
    }
    else {
        _25495 = 1;
    }
    rhs_slice_target = (object_ptr)&_25496;
    RHS_Slice(_opt_48819, 2, _25495);
    RefDS(_opts_48720);
    _0 = _this_opt_48824;
    _this_opt_48824 = _39find_opt(1, _25496, _opts_48720);
    DeRef(_0);
    _25496 = NOVALUE;
L1C: 
L1A: 

    /** 		if length(this_opt) then*/
    if (IS_SEQUENCE(_this_opt_48824)){
            _25498 = SEQ_PTR(_this_opt_48824)->length;
    }
    else {
        _25498 = 1;
    }
    if (_25498 == 0)
    {
        _25498 = NOVALUE;
        goto L1D; // [638] 667
    }
    else{
        _25498 = NOVALUE;
    }

    /** 			if find(HAS_PARAMETER, this_opt[OPTIONS]) then*/
    _2 = (int)SEQ_PTR(_this_opt_48824);
    _25499 = (int)*(((s1_ptr)_2)->base + 4);
    _25500 = find_from(112, _25499, 1);
    _25499 = NOVALUE;
    if (_25500 == 0)
    {
        _25500 = NOVALUE;
        goto L1E; // [654] 679
    }
    else{
        _25500 = NOVALUE;
    }

    /** 				i += 1*/
    _i_48722 = _i_48722 + 1;
    goto L1E; // [664] 679
L1D: 

    /** 			first_extra = i*/
    _first_extra_48815 = _i_48722;

    /** 			exit*/
    DeRef(_opt_48819);
    _opt_48819 = NOVALUE;
    DeRef(_this_opt_48824);
    _this_opt_48824 = NOVALUE;
    goto L17; // [676] 692
L1E: 

    /** 		i += 1*/
    _i_48722 = _i_48722 + 1;
    DeRef(_opt_48819);
    _opt_48819 = NOVALUE;
    DeRef(_this_opt_48824);
    _this_opt_48824 = NOVALUE;

    /** 	end while*/
    goto L16; // [689] 496
L17: 

    /** 	if first_extra then*/
    if (_first_extra_48815 == 0)
    {
        goto L1F; // [694] 709
    }
    else{
    }

    /** 		return splice(b, a, first_extra)*/
    {
        s1_ptr assign_space;
        insert_pos = _first_extra_48815;
        if (insert_pos <= 0) {
            Concat(&_25503,_a_48718,_b_48719);
        }
        else if (insert_pos > SEQ_PTR(_b_48719)->length){
            Concat(&_25503,_b_48719,_a_48718);
        }
        else if (IS_SEQUENCE(_a_48718)) {
            if( _25503 != _b_48719 || SEQ_PTR( _b_48719 )->ref != 1 ){
                DeRef( _25503 );
                RefDS( _b_48719 );
            }
            assign_space = Add_internal_space( _b_48719, insert_pos,((s1_ptr)SEQ_PTR(_a_48718))->length);
            assign_slice_seq = &assign_space;
            assign_space = Copy_elements( insert_pos, SEQ_PTR(_a_48718), _b_48719 == _25503 );
            _25503 = MAKE_SEQ( assign_space );
        }
        else {
            if( _25503 != _b_48719 && SEQ_PTR( _b_48719 )->ref != 1 ){
                _25503 = Insert( _b_48719, _a_48718, insert_pos);
            }
            else {
                DeRef( _25503 );
                RefDS( _b_48719 );
                _25503 = Insert( _b_48719, _a_48718, insert_pos);
            }
        }
    }
    DeRefDS(_a_48718);
    DeRefDS(_b_48719);
    DeRefDS(_opts_48720);
    DeRef(_25462);
    _25462 = NOVALUE;
    DeRef(_25428);
    _25428 = NOVALUE;
    DeRef(_25465);
    _25465 = NOVALUE;
    DeRef(_25476);
    _25476 = NOVALUE;
    DeRef(_25483);
    _25483 = NOVALUE;
    DeRef(_25491);
    _25491 = NOVALUE;
    return _25503;
L1F: 

    /** 	return b & a*/
    Concat((object_ptr)&_25504, _b_48719, _a_48718);
    DeRefDS(_a_48718);
    DeRefDS(_b_48719);
    DeRefDS(_opts_48720);
    DeRef(_25462);
    _25462 = NOVALUE;
    DeRef(_25428);
    _25428 = NOVALUE;
    DeRef(_25465);
    _25465 = NOVALUE;
    DeRef(_25476);
    _25476 = NOVALUE;
    DeRef(_25503);
    _25503 = NOVALUE;
    DeRef(_25483);
    _25483 = NOVALUE;
    DeRef(_25491);
    _25491 = NOVALUE;
    return _25504;
    ;
}


int _39validate_opt(int _opt_type_48857, int _arg_48858, int _args_48859, int _ix_48860)
{
    int _opt_48861 = NOVALUE;
    int _this_opt_48869 = NOVALUE;
    int _25523 = NOVALUE;
    int _25522 = NOVALUE;
    int _25521 = NOVALUE;
    int _25520 = NOVALUE;
    int _25519 = NOVALUE;
    int _25517 = NOVALUE;
    int _25516 = NOVALUE;
    int _25515 = NOVALUE;
    int _25514 = NOVALUE;
    int _25513 = NOVALUE;
    int _25511 = NOVALUE;
    int _25508 = NOVALUE;
    int _25506 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if opt_type = SHORTNAME then*/
    if (_opt_type_48857 != 1)
    goto L1; // [11] 28

    /** 		opt = arg[2..$]*/
    if (IS_SEQUENCE(_arg_48858)){
            _25506 = SEQ_PTR(_arg_48858)->length;
    }
    else {
        _25506 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_48861;
    RHS_Slice(_arg_48858, 2, _25506);
    goto L2; // [25] 39
L1: 

    /** 		opt = arg[3..$]*/
    if (IS_SEQUENCE(_arg_48858)){
            _25508 = SEQ_PTR(_arg_48858)->length;
    }
    else {
        _25508 = 1;
    }
    rhs_slice_target = (object_ptr)&_opt_48861;
    RHS_Slice(_arg_48858, 3, _25508);
L2: 

    /** 	sequence this_opt = find_opt( opt_type, opt, options )*/
    RefDS(_opt_48861);
    RefDS(_39options_48600);
    _0 = _this_opt_48869;
    _this_opt_48869 = _39find_opt(_opt_type_48857, _opt_48861, _39options_48600);
    DeRef(_0);

    /** 	if not length( this_opt ) then*/
    if (IS_SEQUENCE(_this_opt_48869)){
            _25511 = SEQ_PTR(_this_opt_48869)->length;
    }
    else {
        _25511 = 1;
    }
    if (_25511 != 0)
    goto L3; // [58] 72
    _25511 = NOVALUE;

    /** 		return { 0, 0 }*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _25513 = MAKE_SEQ(_1);
    DeRefDS(_arg_48858);
    DeRefDS(_args_48859);
    DeRefDS(_opt_48861);
    DeRefDS(_this_opt_48869);
    return _25513;
L3: 

    /** 	if find( HAS_PARAMETER, this_opt[OPTIONS] ) then*/
    _2 = (int)SEQ_PTR(_this_opt_48869);
    _25514 = (int)*(((s1_ptr)_2)->base + 4);
    _25515 = find_from(112, _25514, 1);
    _25514 = NOVALUE;
    if (_25515 == 0)
    {
        _25515 = NOVALUE;
        goto L4; // [85] 135
    }
    else{
        _25515 = NOVALUE;
    }

    /** 		if ix = length( args ) - 1 then*/
    if (IS_SEQUENCE(_args_48859)){
            _25516 = SEQ_PTR(_args_48859)->length;
    }
    else {
        _25516 = 1;
    }
    _25517 = _25516 - 1;
    _25516 = NOVALUE;
    if (_ix_48860 != _25517)
    goto L5; // [97] 117

    /** 			CompileErr( MISSING_CMD_PARAMETER, { arg } )*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_arg_48858);
    *((int *)(_2+4)) = _arg_48858;
    _25519 = MAKE_SEQ(_1);
    _43CompileErr(353, _25519, 0);
    _25519 = NOVALUE;
    goto L6; // [114] 150
L5: 

    /** 			return { ix, ix + 2 }*/
    _25520 = _ix_48860 + 2;
    if ((long)((unsigned long)_25520 + (unsigned long)HIGH_BITS) >= 0) 
    _25520 = NewDouble((double)_25520);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_48860;
    ((int *)_2)[2] = _25520;
    _25521 = MAKE_SEQ(_1);
    _25520 = NOVALUE;
    DeRefDS(_arg_48858);
    DeRefDS(_args_48859);
    DeRef(_opt_48861);
    DeRef(_this_opt_48869);
    DeRef(_25513);
    _25513 = NOVALUE;
    DeRef(_25517);
    _25517 = NOVALUE;
    return _25521;
    goto L6; // [132] 150
L4: 

    /** 		return { ix, ix + 1 }*/
    _25522 = _ix_48860 + 1;
    if (_25522 > MAXINT){
        _25522 = NewDouble((double)_25522);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _ix_48860;
    ((int *)_2)[2] = _25522;
    _25523 = MAKE_SEQ(_1);
    _25522 = NOVALUE;
    DeRefDS(_arg_48858);
    DeRefDS(_args_48859);
    DeRef(_opt_48861);
    DeRef(_this_opt_48869);
    DeRef(_25513);
    _25513 = NOVALUE;
    DeRef(_25517);
    _25517 = NOVALUE;
    DeRef(_25521);
    _25521 = NOVALUE;
    return _25523;
L6: 
    ;
}


int _39find_next_opt(int _ix_48894, int _args_48895)
{
    int _arg_48899 = NOVALUE;
    int _25545 = NOVALUE;
    int _25544 = NOVALUE;
    int _25542 = NOVALUE;
    int _25541 = NOVALUE;
    int _25540 = NOVALUE;
    int _25539 = NOVALUE;
    int _25538 = NOVALUE;
    int _25537 = NOVALUE;
    int _25536 = NOVALUE;
    int _25535 = NOVALUE;
    int _25533 = NOVALUE;
    int _25531 = NOVALUE;
    int _25529 = NOVALUE;
    int _25527 = NOVALUE;
    int _25524 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while ix < length( args ) do*/
L1: 
    if (IS_SEQUENCE(_args_48895)){
            _25524 = SEQ_PTR(_args_48895)->length;
    }
    else {
        _25524 = 1;
    }
    if (_ix_48894 >= _25524)
    goto L2; // [13] 157

    /** 		sequence arg = args[ix]*/
    DeRef(_arg_48899);
    _2 = (int)SEQ_PTR(_args_48895);
    _arg_48899 = (int)*(((s1_ptr)_2)->base + _ix_48894);
    Ref(_arg_48899);

    /** 		if length( arg ) > 1 then*/
    if (IS_SEQUENCE(_arg_48899)){
            _25527 = SEQ_PTR(_arg_48899)->length;
    }
    else {
        _25527 = 1;
    }
    if (_25527 <= 1)
    goto L3; // [30] 129

    /** 			if arg[1] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_48899);
    _25529 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _25529, 45)){
        _25529 = NOVALUE;
        goto L4; // [40] 111
    }
    _25529 = NOVALUE;

    /** 				if arg[2] = '-' then*/
    _2 = (int)SEQ_PTR(_arg_48899);
    _25531 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _25531, 45)){
        _25531 = NOVALUE;
        goto L5; // [50] 94
    }
    _25531 = NOVALUE;

    /** 					if length( arg ) = 2 then*/
    if (IS_SEQUENCE(_arg_48899)){
            _25533 = SEQ_PTR(_arg_48899)->length;
    }
    else {
        _25533 = 1;
    }
    if (_25533 != 2)
    goto L6; // [59] 78

    /** 						return { 0, ix - 1 }*/
    _25535 = _ix_48894 - 1;
    if ((long)((unsigned long)_25535 +(unsigned long) HIGH_BITS) >= 0){
        _25535 = NewDouble((double)_25535);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25535;
    _25536 = MAKE_SEQ(_1);
    _25535 = NOVALUE;
    DeRefDS(_arg_48899);
    DeRefDS(_args_48895);
    return _25536;
L6: 

    /** 					return validate_opt( LONGNAME, arg, args, ix )*/
    RefDS(_arg_48899);
    RefDS(_args_48895);
    _25537 = _39validate_opt(2, _arg_48899, _args_48895, _ix_48894);
    DeRefDS(_arg_48899);
    DeRefDS(_args_48895);
    DeRef(_25536);
    _25536 = NOVALUE;
    return _25537;
    goto L7; // [91] 144
L5: 

    /** 					return validate_opt( SHORTNAME, arg, args, ix )*/
    RefDS(_arg_48899);
    RefDS(_args_48895);
    _25538 = _39validate_opt(1, _arg_48899, _args_48895, _ix_48894);
    DeRefDS(_arg_48899);
    DeRefDS(_args_48895);
    DeRef(_25536);
    _25536 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    return _25538;
    goto L7; // [108] 144
L4: 

    /** 				return {0, ix-1}*/
    _25539 = _ix_48894 - 1;
    if ((long)((unsigned long)_25539 +(unsigned long) HIGH_BITS) >= 0){
        _25539 = NewDouble((double)_25539);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25539;
    _25540 = MAKE_SEQ(_1);
    _25539 = NOVALUE;
    DeRef(_arg_48899);
    DeRefDS(_args_48895);
    DeRef(_25536);
    _25536 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    DeRef(_25538);
    _25538 = NOVALUE;
    return _25540;
    goto L7; // [126] 144
L3: 

    /** 			return { 0, ix-1 }*/
    _25541 = _ix_48894 - 1;
    if ((long)((unsigned long)_25541 +(unsigned long) HIGH_BITS) >= 0){
        _25541 = NewDouble((double)_25541);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25541;
    _25542 = MAKE_SEQ(_1);
    _25541 = NOVALUE;
    DeRef(_arg_48899);
    DeRefDS(_args_48895);
    DeRef(_25536);
    _25536 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    DeRef(_25538);
    _25538 = NOVALUE;
    DeRef(_25540);
    _25540 = NOVALUE;
    return _25542;
L7: 

    /** 		ix += 1*/
    _ix_48894 = _ix_48894 + 1;
    DeRef(_arg_48899);
    _arg_48899 = NOVALUE;

    /** 	end while*/
    goto L1; // [154] 10
L2: 

    /** 	return {0, ix-1}*/
    _25544 = _ix_48894 - 1;
    if ((long)((unsigned long)_25544 +(unsigned long) HIGH_BITS) >= 0){
        _25544 = NewDouble((double)_25544);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _25544;
    _25545 = MAKE_SEQ(_1);
    _25544 = NOVALUE;
    DeRefDS(_args_48895);
    DeRef(_25536);
    _25536 = NOVALUE;
    DeRef(_25537);
    _25537 = NOVALUE;
    DeRef(_25538);
    _25538 = NOVALUE;
    DeRef(_25540);
    _25540 = NOVALUE;
    DeRef(_25542);
    _25542 = NOVALUE;
    return _25545;
    ;
}


int _39expand_config_options(int _args_48929)
{
    int _idx_48930 = NOVALUE;
    int _next_idx_48931 = NOVALUE;
    int _files_48932 = NOVALUE;
    int _cmd_1_2_48933 = NOVALUE;
    int _25568 = NOVALUE;
    int _25567 = NOVALUE;
    int _25566 = NOVALUE;
    int _25565 = NOVALUE;
    int _25564 = NOVALUE;
    int _25563 = NOVALUE;
    int _25562 = NOVALUE;
    int _25561 = NOVALUE;
    int _25560 = NOVALUE;
    int _25555 = NOVALUE;
    int _25553 = NOVALUE;
    int _25552 = NOVALUE;
    int _25551 = NOVALUE;
    int _25549 = NOVALUE;
    int _25548 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer idx = 1*/
    _idx_48930 = 1;

    /** 	sequence files = {}*/
    RefDS(_21829);
    DeRef(_files_48932);
    _files_48932 = _21829;

    /** 	sequence cmd_1_2 = args[1..2]*/
    rhs_slice_target = (object_ptr)&_cmd_1_2_48933;
    RHS_Slice(_args_48929, 1, 2);

    /** 	args = remove( args, 1, 2 )*/
    {
        s1_ptr assign_space = SEQ_PTR(_args_48929);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(1)) ? 1 : (long)(DBL_PTR(1)->dbl);
        int stop = (IS_ATOM_INT(2)) ? 2 : (long)(DBL_PTR(2)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_48929), start, &_args_48929 );
            }
            else Tail(SEQ_PTR(_args_48929), stop+1, &_args_48929);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_48929), start, &_args_48929);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_48929 = Remove_elements(start, stop, (SEQ_PTR(_args_48929)->ref == 1));
        }
    }

    /** 	while idx with entry do*/
    goto L1; // [31] 94
L2: 
    if (_idx_48930 == 0)
    {
        goto L3; // [34] 114
    }
    else{
    }

    /** 		if equal(upper(args[idx]), "-C") then*/
    _2 = (int)SEQ_PTR(_args_48929);
    _25548 = (int)*(((s1_ptr)_2)->base + _idx_48930);
    Ref(_25548);
    _25549 = _18upper(_25548);
    _25548 = NOVALUE;
    if (_25549 == _25550)
    _25551 = 1;
    else if (IS_ATOM_INT(_25549) && IS_ATOM_INT(_25550))
    _25551 = 0;
    else
    _25551 = (compare(_25549, _25550) == 0);
    DeRef(_25549);
    _25549 = NOVALUE;
    if (_25551 == 0)
    {
        _25551 = NOVALUE;
        goto L4; // [51] 82
    }
    else{
        _25551 = NOVALUE;
    }

    /** 			files = append( files, args[idx+1] )*/
    _25552 = _idx_48930 + 1;
    _2 = (int)SEQ_PTR(_args_48929);
    _25553 = (int)*(((s1_ptr)_2)->base + _25552);
    Ref(_25553);
    Append(&_files_48932, _files_48932, _25553);
    _25553 = NOVALUE;

    /** 			args = remove( args, idx, idx + 1 )*/
    _25555 = _idx_48930 + 1;
    if (_25555 > MAXINT){
        _25555 = NewDouble((double)_25555);
    }
    {
        s1_ptr assign_space = SEQ_PTR(_args_48929);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_idx_48930)) ? _idx_48930 : (long)(DBL_PTR(_idx_48930)->dbl);
        int stop = (IS_ATOM_INT(_25555)) ? _25555 : (long)(DBL_PTR(_25555)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_args_48929), start, &_args_48929 );
            }
            else Tail(SEQ_PTR(_args_48929), stop+1, &_args_48929);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_args_48929), start, &_args_48929);
        }
        else {
            assign_slice_seq = &assign_space;
            _args_48929 = Remove_elements(start, stop, (SEQ_PTR(_args_48929)->ref == 1));
        }
    }
    DeRef(_25555);
    _25555 = NOVALUE;
    goto L5; // [79] 91
L4: 

    /** 			idx = next_idx[2]*/
    _2 = (int)SEQ_PTR(_next_idx_48931);
    _idx_48930 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_idx_48930))
    _idx_48930 = (long)DBL_PTR(_idx_48930)->dbl;
L5: 

    /** 	entry*/
L1: 

    /** 		next_idx = find_next_opt( idx, args )*/
    RefDS(_args_48929);
    _0 = _next_idx_48931;
    _next_idx_48931 = _39find_next_opt(_idx_48930, _args_48929);
    DeRef(_0);

    /** 		idx = next_idx[1]*/
    _2 = (int)SEQ_PTR(_next_idx_48931);
    _idx_48930 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_idx_48930))
    _idx_48930 = (long)DBL_PTR(_idx_48930)->dbl;

    /** 	end while*/
    goto L2; // [111] 34
L3: 

    /** 	return cmd_1_2 & merge_parameters( GetDefaultArgs( files ), args[1..next_idx[2]], options, 1 ) & args[next_idx[2]+1..$]*/
    RefDS(_files_48932);
    _25560 = _38GetDefaultArgs(_files_48932);
    _2 = (int)SEQ_PTR(_next_idx_48931);
    _25561 = (int)*(((s1_ptr)_2)->base + 2);
    rhs_slice_target = (object_ptr)&_25562;
    RHS_Slice(_args_48929, 1, _25561);
    RefDS(_39options_48600);
    _25563 = _39merge_parameters(_25560, _25562, _39options_48600, 1);
    _25560 = NOVALUE;
    _25562 = NOVALUE;
    _2 = (int)SEQ_PTR(_next_idx_48931);
    _25564 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_25564)) {
        _25565 = _25564 + 1;
        if (_25565 > MAXINT){
            _25565 = NewDouble((double)_25565);
        }
    }
    else
    _25565 = binary_op(PLUS, 1, _25564);
    _25564 = NOVALUE;
    if (IS_SEQUENCE(_args_48929)){
            _25566 = SEQ_PTR(_args_48929)->length;
    }
    else {
        _25566 = 1;
    }
    rhs_slice_target = (object_ptr)&_25567;
    RHS_Slice(_args_48929, _25565, _25566);
    {
        int concat_list[3];

        concat_list[0] = _25567;
        concat_list[1] = _25563;
        concat_list[2] = _cmd_1_2_48933;
        Concat_N((object_ptr)&_25568, concat_list, 3);
    }
    DeRefDS(_25567);
    _25567 = NOVALUE;
    DeRef(_25563);
    _25563 = NOVALUE;
    DeRefDS(_args_48929);
    DeRefDS(_next_idx_48931);
    DeRefDS(_files_48932);
    DeRefDS(_cmd_1_2_48933);
    DeRef(_25552);
    _25552 = NOVALUE;
    _25561 = NOVALUE;
    DeRef(_25565);
    _25565 = NOVALUE;
    return _25568;
    ;
}


void _39handle_common_options(int _opts_48964)
{
    int _opt_keys_48965 = NOVALUE;
    int _option_w_48967 = NOVALUE;
    int _key_48971 = NOVALUE;
    int _val_48973 = NOVALUE;
    int _this_warn_49019 = NOVALUE;
    int _auto_add_warn_49021 = NOVALUE;
    int _n_49027 = NOVALUE;
    int _this_warn_49050 = NOVALUE;
    int _auto_add_warn_49052 = NOVALUE;
    int _n_49058 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_615_49093 = NOVALUE;
    int _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106 = NOVALUE;
    int _prompt_inlined_maybe_any_key_at_689_49105 = NOVALUE;
    int _25621 = NOVALUE;
    int _25620 = NOVALUE;
    int _25619 = NOVALUE;
    int _25618 = NOVALUE;
    int _25617 = NOVALUE;
    int _25616 = NOVALUE;
    int _25615 = NOVALUE;
    int _25614 = NOVALUE;
    int _25613 = NOVALUE;
    int _25611 = NOVALUE;
    int _25609 = NOVALUE;
    int _25608 = NOVALUE;
    int _25607 = NOVALUE;
    int _25602 = NOVALUE;
    int _25600 = NOVALUE;
    int _25598 = NOVALUE;
    int _25595 = NOVALUE;
    int _25594 = NOVALUE;
    int _25589 = NOVALUE;
    int _25587 = NOVALUE;
    int _25585 = NOVALUE;
    int _25583 = NOVALUE;
    int _25582 = NOVALUE;
    int _25581 = NOVALUE;
    int _25580 = NOVALUE;
    int _25579 = NOVALUE;
    int _25578 = NOVALUE;
    int _25576 = NOVALUE;
    int _25575 = NOVALUE;
    int _25570 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence opt_keys = m:keys(opts)*/
    Ref(_opts_48964);
    _0 = _opt_keys_48965;
    _opt_keys_48965 = _32keys(_opts_48964, 0);
    DeRef(_0);

    /** 	integer option_w = 0*/
    _option_w_48967 = 0;

    /** 	for idx = 1 to length(opt_keys) do*/
    if (IS_SEQUENCE(_opt_keys_48965)){
            _25570 = SEQ_PTR(_opt_keys_48965)->length;
    }
    else {
        _25570 = 1;
    }
    {
        int _idx_48969;
        _idx_48969 = 1;
L1: 
        if (_idx_48969 > _25570){
            goto L2; // [20] 731
        }

        /** 		sequence key = opt_keys[idx]*/
        DeRef(_key_48971);
        _2 = (int)SEQ_PTR(_opt_keys_48965);
        _key_48971 = (int)*(((s1_ptr)_2)->base + _idx_48969);
        Ref(_key_48971);

        /** 		object val = m:get(opts, key)*/
        Ref(_opts_48964);
        RefDS(_key_48971);
        _0 = _val_48973;
        _val_48973 = _32get(_opts_48964, _key_48971, 0);
        DeRef(_0);

        /** 		switch key do*/
        _1 = find(_key_48971, _25573);
        switch ( _1 ){ 

            /** 			case "i" then*/
            case 1:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48973)){
                    _25575 = SEQ_PTR(_val_48973)->length;
            }
            else {
                _25575 = 1;
            }
            {
                int _i_48979;
                _i_48979 = 1;
L3: 
                if (_i_48979 > _25575){
                    goto L4; // [59] 82
                }

                /** 					add_include_directory(val[i])*/
                _2 = (int)SEQ_PTR(_val_48973);
                _25576 = (int)*(((s1_ptr)_2)->base + _i_48979);
                Ref(_25576);
                _38add_include_directory(_25576);
                _25576 = NOVALUE;

                /** 				end for*/
                _i_48979 = _i_48979 + 1;
                goto L3; // [77] 66
L4: 
                ;
            }
            goto L5; // [82] 722

            /** 			case "d" then*/
            case 2:

            /** 				OpDefines &= val*/
            if (IS_SEQUENCE(_12OpDefines_11756) && IS_ATOM(_val_48973)) {
                Ref(_val_48973);
                Append(&_12OpDefines_11756, _12OpDefines_11756, _val_48973);
            }
            else if (IS_ATOM(_12OpDefines_11756) && IS_SEQUENCE(_val_48973)) {
            }
            else {
                Concat((object_ptr)&_12OpDefines_11756, _12OpDefines_11756, _val_48973);
            }
            goto L5; // [98] 722

            /** 			case "batch" then*/
            case 3:

            /** 				batch_job = 1*/
            _12batch_job_11695 = 1;
            goto L5; // [111] 722

            /** 			case "test" then*/
            case 4:

            /** 				test_only = 1*/
            _12test_only_11694 = 1;
            goto L5; // [124] 722

            /** 			case "strict" then*/
            case 5:

            /** 				Strict_is_on = 1*/
            _12Strict_is_on_11748 = 1;
            goto L5; // [137] 722

            /** 			case "p" then*/
            case 6:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48973)){
                    _25578 = SEQ_PTR(_val_48973)->length;
            }
            else {
                _25578 = 1;
            }
            {
                int _i_48994;
                _i_48994 = 1;
L6: 
                if (_i_48994 > _25578){
                    goto L7; // [148] 173
                }

                /** 					add_preprocessor(val[i])*/
                _2 = (int)SEQ_PTR(_val_48973);
                _25579 = (int)*(((s1_ptr)_2)->base + _i_48994);
                Ref(_25579);
                _63add_preprocessor(_25579, 0, 0);
                _25579 = NOVALUE;

                /** 				end for*/
                _i_48994 = _i_48994 + 1;
                goto L6; // [168] 155
L7: 
                ;
            }
            goto L5; // [173] 722

            /** 			case "pf" then*/
            case 7:

            /** 				force_preprocessor = 1*/
            _13force_preprocessor_10656 = 1;
            goto L5; // [186] 722

            /** 			case "l" then*/
            case 8:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48973)){
                    _25580 = SEQ_PTR(_val_48973)->length;
            }
            else {
                _25580 = 1;
            }
            {
                int _i_49002;
                _i_49002 = 1;
L8: 
                if (_i_49002 > _25580){
                    goto L9; // [197] 238
                }

                /** 					LocalizeQual = append(LocalizeQual, (filter(lower(val[i]), STDFLTR_ALPHA)))*/
                _2 = (int)SEQ_PTR(_val_48973);
                _25581 = (int)*(((s1_ptr)_2)->base + _i_49002);
                Ref(_25581);
                _25582 = _18lower(_25581);
                _25581 = NOVALUE;
                RefDS(_21829);
                RefDS(_5);
                _25583 = _24filter(_25582, _24STDFLTR_ALPHA_4466, _21829, _5);
                _25582 = NOVALUE;
                Ref(_25583);
                Append(&_13LocalizeQual_10657, _13LocalizeQual_10657, _25583);
                DeRef(_25583);
                _25583 = NOVALUE;

                /** 				end for*/
                _i_49002 = _i_49002 + 1;
                goto L8; // [233] 204
L9: 
                ;
            }
            goto L5; // [238] 722

            /** 			case "ldb" then*/
            case 9:

            /** 				LocalDB = val*/
            Ref(_val_48973);
            DeRef(_13LocalDB_10658);
            _13LocalDB_10658 = _val_48973;
            goto L5; // [251] 722

            /** 			case "w" then*/
            case 10:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48973)){
                    _25585 = SEQ_PTR(_val_48973)->length;
            }
            else {
                _25585 = 1;
            }
            {
                int _i_49017;
                _i_49017 = 1;
LA: 
                if (_i_49017 > _25585){
                    goto LB; // [262] 392
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49019);
                _2 = (int)SEQ_PTR(_val_48973);
                _this_warn_49019 = (int)*(((s1_ptr)_2)->base + _i_49017);
                Ref(_this_warn_49019);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49021 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49019);
                _25587 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25587, 43)){
                    _25587 = NOVALUE;
                    goto LC; // [288] 308
                }
                _25587 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49021 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49019)){
                        _25589 = SEQ_PTR(_this_warn_49019)->length;
                }
                else {
                    _25589 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49019;
                RHS_Slice(_this_warn_49019, 2, _25589);
LC: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49027 = find_from(_this_warn_49019, _12warning_names_11727, 1);

                /** 					if n != 0 then*/
                if (_n_49027 == 0)
                goto LD; // [319] 383

                /** 						if auto_add_warn or option_w = 1 then*/
                if (_auto_add_warn_49021 != 0) {
                    goto LE; // [325] 338
                }
                _25594 = (_option_w_48967 == 1);
                if (_25594 == 0)
                {
                    DeRef(_25594);
                    _25594 = NOVALUE;
                    goto LF; // [334] 357
                }
                else{
                    DeRef(_25594);
                    _25594 = NOVALUE;
                }
LE: 

                /** 							OpWarning = or_bits(OpWarning, warning_flags[n])*/
                _2 = (int)SEQ_PTR(_12warning_flags_11725);
                _25595 = (int)*(((s1_ptr)_2)->base + _n_49027);
                {unsigned long tu;
                     tu = (unsigned long)_12OpWarning_11750 | (unsigned long)_25595;
                     _12OpWarning_11750 = MAKE_UINT(tu);
                }
                _25595 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_11750)) {
                    _1 = (long)(DBL_PTR(_12OpWarning_11750)->dbl);
                    DeRefDS(_12OpWarning_11750);
                    _12OpWarning_11750 = _1;
                }
                goto L10; // [354] 373
LF: 

                /** 							option_w = 1*/
                _option_w_48967 = 1;

                /** 							OpWarning = warning_flags[n]*/
                _2 = (int)SEQ_PTR(_12warning_flags_11725);
                _12OpWarning_11750 = (int)*(((s1_ptr)_2)->base + _n_49027);
L10: 

                /** 						prev_OpWarning = OpWarning*/
                _12prev_OpWarning_11751 = _12OpWarning_11750;
LD: 
                DeRef(_this_warn_49019);
                _this_warn_49019 = NOVALUE;

                /** 				end for*/
                _i_49017 = _i_49017 + 1;
                goto LA; // [387] 269
LB: 
                ;
            }
            goto L5; // [392] 722

            /** 			case "x" then*/
            case 11:

            /** 				for i = 1 to length(val) do*/
            if (IS_SEQUENCE(_val_48973)){
                    _25598 = SEQ_PTR(_val_48973)->length;
            }
            else {
                _25598 = 1;
            }
            {
                int _i_49048;
                _i_49048 = 1;
L11: 
                if (_i_49048 > _25598){
                    goto L12; // [403] 542
                }

                /** 					sequence this_warn = val[i]*/
                DeRef(_this_warn_49050);
                _2 = (int)SEQ_PTR(_val_48973);
                _this_warn_49050 = (int)*(((s1_ptr)_2)->base + _i_49048);
                Ref(_this_warn_49050);

                /** 					integer auto_add_warn = 0*/
                _auto_add_warn_49052 = 0;

                /** 					if this_warn[1] = '+' then*/
                _2 = (int)SEQ_PTR(_this_warn_49050);
                _25600 = (int)*(((s1_ptr)_2)->base + 1);
                if (binary_op_a(NOTEQ, _25600, 43)){
                    _25600 = NOVALUE;
                    goto L13; // [429] 449
                }
                _25600 = NOVALUE;

                /** 						auto_add_warn = 1*/
                _auto_add_warn_49052 = 1;

                /** 						this_warn = this_warn[2 .. $]*/
                if (IS_SEQUENCE(_this_warn_49050)){
                        _25602 = SEQ_PTR(_this_warn_49050)->length;
                }
                else {
                    _25602 = 1;
                }
                rhs_slice_target = (object_ptr)&_this_warn_49050;
                RHS_Slice(_this_warn_49050, 2, _25602);
L13: 

                /** 					integer n = find(this_warn, warning_names)*/
                _n_49058 = find_from(_this_warn_49050, _12warning_names_11727, 1);

                /** 					if n != 0 then*/
                if (_n_49058 == 0)
                goto L14; // [460] 533

                /** 						if auto_add_warn or option_w = -1 then*/
                if (_auto_add_warn_49052 != 0) {
                    goto L15; // [466] 479
                }
                _25607 = (_option_w_48967 == -1);
                if (_25607 == 0)
                {
                    DeRef(_25607);
                    _25607 = NOVALUE;
                    goto L16; // [475] 501
                }
                else{
                    DeRef(_25607);
                    _25607 = NOVALUE;
                }
L15: 

                /** 							OpWarning = and_bits(OpWarning, not_bits(warning_flags[n]))*/
                _2 = (int)SEQ_PTR(_12warning_flags_11725);
                _25608 = (int)*(((s1_ptr)_2)->base + _n_49058);
                _25609 = not_bits(_25608);
                _25608 = NOVALUE;
                if (IS_ATOM_INT(_25609)) {
                    {unsigned long tu;
                         tu = (unsigned long)_12OpWarning_11750 & (unsigned long)_25609;
                         _12OpWarning_11750 = MAKE_UINT(tu);
                    }
                }
                else {
                    temp_d.dbl = (double)_12OpWarning_11750;
                    _12OpWarning_11750 = Dand_bits(&temp_d, DBL_PTR(_25609));
                }
                DeRef(_25609);
                _25609 = NOVALUE;
                if (!IS_ATOM_INT(_12OpWarning_11750)) {
                    _1 = (long)(DBL_PTR(_12OpWarning_11750)->dbl);
                    DeRefDS(_12OpWarning_11750);
                    _12OpWarning_11750 = _1;
                }
                goto L17; // [498] 523
L16: 

                /** 							option_w = -1*/
                _option_w_48967 = -1;

                /** 							OpWarning = all_warning_flag - warning_flags[n]*/
                _2 = (int)SEQ_PTR(_12warning_flags_11725);
                _25611 = (int)*(((s1_ptr)_2)->base + _n_49058);
                _12OpWarning_11750 = 32767 - _25611;
                _25611 = NOVALUE;
L17: 

                /** 						prev_OpWarning = OpWarning*/
                _12prev_OpWarning_11751 = _12OpWarning_11750;
L14: 
                DeRef(_this_warn_49050);
                _this_warn_49050 = NOVALUE;

                /** 				end for*/
                _i_49048 = _i_49048 + 1;
                goto L11; // [537] 410
L12: 
                ;
            }
            goto L5; // [542] 722

            /** 			case "wf" then*/
            case 12:

            /** 				TempWarningName = val*/
            Ref(_val_48973);
            DeRef(_12TempWarningName_11696);
            _12TempWarningName_11696 = _val_48973;

            /** 			  	error:warning_file(TempWarningName)*/
            Ref(_12TempWarningName_11696);
            _8warning_file(_12TempWarningName_11696);
            goto L5; // [560] 722

            /** 			case "v", "version" then*/
            case 13:
            case 14:

            /** 				show_banner()*/
            _39show_banner();

            /** 				if not batch_job and not test_only then*/
            _25613 = (_12batch_job_11695 == 0);
            if (_25613 == 0) {
                goto L18; // [579] 632
            }
            _25615 = (_12test_only_11694 == 0);
            if (_25615 == 0)
            {
                DeRef(_25615);
                _25615 = NOVALUE;
                goto L18; // [589] 632
            }
            else{
                DeRef(_25615);
                _25615 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_21829);
            _25616 = _44GetMsgText(278, 0, _21829);
            DeRef(_prompt_inlined_maybe_any_key_at_615_49093);
            _prompt_inlined_maybe_any_key_at_615_49093 = _25616;
            _25616 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094 != 0){
                    goto L19; // [614] 629
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094)->dbl != 0.0){
                    goto L19; // [614] 629
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_615_49093);
            _41any_key(_prompt_inlined_maybe_any_key_at_615_49093, 2);

            /** end procedure*/
            goto L19; // [626] 629
L19: 
            DeRef(_prompt_inlined_maybe_any_key_at_615_49093);
            _prompt_inlined_maybe_any_key_at_615_49093 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_618_49094 = NOVALUE;
L18: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [636] 722

            /** 			case "copyright" then*/
            case 15:

            /** 				show_copyrights()*/
            _39show_copyrights();

            /** 				if not batch_job and not test_only then*/
            _25617 = (_12batch_job_11695 == 0);
            if (_25617 == 0) {
                goto L1A; // [653] 706
            }
            _25619 = (_12test_only_11694 == 0);
            if (_25619 == 0)
            {
                DeRef(_25619);
                _25619 = NOVALUE;
                goto L1A; // [663] 706
            }
            else{
                DeRef(_25619);
                _25619 = NOVALUE;
            }

            /** 					console:maybe_any_key(GetMsgText(278,0), 2)*/
            RefDS(_21829);
            _25620 = _44GetMsgText(278, 0, _21829);
            DeRef(_prompt_inlined_maybe_any_key_at_689_49105);
            _prompt_inlined_maybe_any_key_at_689_49105 = _25620;
            _25620 = NOVALUE;

            /** 	if not has_console() then*/

            /** 	return machine_func(M_HAS_CONSOLE, 0)*/
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106 = machine(99, 0);
            if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106)) {
                if (_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106 != 0){
                    goto L1B; // [688] 703
                }
            }
            else {
                if (DBL_PTR(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106)->dbl != 0.0){
                    goto L1B; // [688] 703
                }
            }

            /** 		any_key(prompt, con)*/
            Ref(_prompt_inlined_maybe_any_key_at_689_49105);
            _41any_key(_prompt_inlined_maybe_any_key_at_689_49105, 2);

            /** end procedure*/
            goto L1B; // [700] 703
L1B: 
            DeRef(_prompt_inlined_maybe_any_key_at_689_49105);
            _prompt_inlined_maybe_any_key_at_689_49105 = NOVALUE;
            DeRef(_has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106);
            _has_console_inlined_has_console_at_6_inlined_maybe_any_key_at_692_49106 = NOVALUE;
L1A: 

            /** 				abort(0)*/
            UserCleanup(0);
            goto L5; // [710] 722

            /** 			case "eudir" then*/
            case 16:

            /** 				set_eudir( val )*/
            Ref(_val_48973);
            _13set_eudir(_val_48973);
        ;}L5: 
        DeRef(_key_48971);
        _key_48971 = NOVALUE;
        DeRef(_val_48973);
        _val_48973 = NOVALUE;

        /** 	end for*/
        _idx_48969 = _idx_48969 + 1;
        goto L1; // [726] 27
L2: 
        ;
    }

    /** 	if length(LocalizeQual) = 0 then*/
    if (IS_SEQUENCE(_13LocalizeQual_10657)){
            _25621 = SEQ_PTR(_13LocalizeQual_10657)->length;
    }
    else {
        _25621 = 1;
    }
    if (_25621 != 0)
    goto L1C; // [738] 751

    /** 		LocalizeQual = {"en"}*/
    _0 = _13LocalizeQual_10657;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_25623);
    *((int *)(_2+4)) = _25623;
    _13LocalizeQual_10657 = MAKE_SEQ(_1);
    DeRefDS(_0);
L1C: 

    /** end procedure*/
    DeRef(_opts_48964);
    DeRef(_opt_keys_48965);
    DeRef(_25613);
    _25613 = NOVALUE;
    DeRef(_25617);
    _25617 = NOVALUE;
    return;
    ;
}


void _39finalize_command_line(int _opts_49118)
{
    int _extras_49125 = NOVALUE;
    int _pairs_49130 = NOVALUE;
    int _pair_49135 = NOVALUE;
    int _25653 = NOVALUE;
    int _25651 = NOVALUE;
    int _25648 = NOVALUE;
    int _25647 = NOVALUE;
    int _25646 = NOVALUE;
    int _25645 = NOVALUE;
    int _25644 = NOVALUE;
    int _25643 = NOVALUE;
    int _25642 = NOVALUE;
    int _25641 = NOVALUE;
    int _25640 = NOVALUE;
    int _25639 = NOVALUE;
    int _25638 = NOVALUE;
    int _25637 = NOVALUE;
    int _25636 = NOVALUE;
    int _25635 = NOVALUE;
    int _25634 = NOVALUE;
    int _25633 = NOVALUE;
    int _25632 = NOVALUE;
    int _25631 = NOVALUE;
    int _25629 = NOVALUE;
    int _25626 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if Strict_is_on then -- overrides any -W/-X switches*/
    if (_12Strict_is_on_11748 == 0)
    {
        goto L1; // [5] 27
    }
    else{
    }

    /** 		OpWarning = all_warning_flag*/
    _12OpWarning_11750 = 32767;

    /** 		prev_OpWarning = OpWarning*/
    _12prev_OpWarning_11751 = 32767;
L1: 

    /** 	sequence extras = m:get(opts, cmdline:EXTRAS)*/
    Ref(_opts_49118);
    RefDS(_40EXTRAS_15167);
    _0 = _extras_49125;
    _extras_49125 = _32get(_opts_49118, _40EXTRAS_15167, 0);
    DeRef(_0);

    /** 	if length(extras) > 0 then*/
    if (IS_SEQUENCE(_extras_49125)){
            _25626 = SEQ_PTR(_extras_49125)->length;
    }
    else {
        _25626 = 1;
    }
    if (_25626 <= 0)
    goto L2; // [44] 270

    /** 		sequence pairs = m:pairs( opts )*/
    Ref(_opts_49118);
    _0 = _pairs_49130;
    _pairs_49130 = _32pairs(_opts_49118, 0);
    DeRef(_0);

    /** 		for i = 1 to length( pairs ) do*/
    if (IS_SEQUENCE(_pairs_49130)){
            _25629 = SEQ_PTR(_pairs_49130)->length;
    }
    else {
        _25629 = 1;
    }
    {
        int _i_49133;
        _i_49133 = 1;
L3: 
        if (_i_49133 > _25629){
            goto L4; // [62] 237
        }

        /** 			sequence pair = pairs[i]*/
        DeRef(_pair_49135);
        _2 = (int)SEQ_PTR(_pairs_49130);
        _pair_49135 = (int)*(((s1_ptr)_2)->base + _i_49133);
        Ref(_pair_49135);

        /** 			if equal( pair[1], cmdline:EXTRAS ) then*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25631 = (int)*(((s1_ptr)_2)->base + 1);
        if (_25631 == _40EXTRAS_15167)
        _25632 = 1;
        else if (IS_ATOM_INT(_25631) && IS_ATOM_INT(_40EXTRAS_15167))
        _25632 = 0;
        else
        _25632 = (compare(_25631, _40EXTRAS_15167) == 0);
        _25631 = NOVALUE;
        if (_25632 == 0)
        {
            _25632 = NOVALUE;
            goto L5; // [89] 99
        }
        else{
            _25632 = NOVALUE;
        }

        /** 				continue*/
        DeRefDS(_pair_49135);
        _pair_49135 = NOVALUE;
        goto L6; // [96] 232
L5: 

        /** 			pair[1] = prepend( pair[1], '-' )*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25633 = (int)*(((s1_ptr)_2)->base + 1);
        Prepend(&_25634, _25633, 45);
        _25633 = NOVALUE;
        _2 = (int)SEQ_PTR(_pair_49135);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _pair_49135 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _25634;
        if( _1 != _25634 ){
            DeRef(_1);
        }
        _25634 = NOVALUE;

        /** 			if sequence( pair[2] ) then*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25635 = (int)*(((s1_ptr)_2)->base + 2);
        _25636 = IS_SEQUENCE(_25635);
        _25635 = NOVALUE;
        if (_25636 == 0)
        {
            _25636 = NOVALUE;
            goto L7; // [122] 215
        }
        else{
            _25636 = NOVALUE;
        }

        /** 				if length( pair[2] ) and sequence( pair[2][1] ) then*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25637 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25637)){
                _25638 = SEQ_PTR(_25637)->length;
        }
        else {
            _25638 = 1;
        }
        _25637 = NOVALUE;
        if (_25638 == 0) {
            goto L8; // [134] 203
        }
        _2 = (int)SEQ_PTR(_pair_49135);
        _25640 = (int)*(((s1_ptr)_2)->base + 2);
        _2 = (int)SEQ_PTR(_25640);
        _25641 = (int)*(((s1_ptr)_2)->base + 1);
        _25640 = NOVALUE;
        _25642 = IS_SEQUENCE(_25641);
        _25641 = NOVALUE;
        if (_25642 == 0)
        {
            _25642 = NOVALUE;
            goto L8; // [150] 203
        }
        else{
            _25642 = NOVALUE;
        }

        /** 					for j = 1 to length( pair[2] ) do*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25643 = (int)*(((s1_ptr)_2)->base + 2);
        if (IS_SEQUENCE(_25643)){
                _25644 = SEQ_PTR(_25643)->length;
        }
        else {
            _25644 = 1;
        }
        _25643 = NOVALUE;
        {
            int _j_49153;
            _j_49153 = 1;
L9: 
            if (_j_49153 > _25644){
                goto LA; // [162] 200
            }

            /** 						switches &= { pair[1], pair[2][j] }*/
            _2 = (int)SEQ_PTR(_pair_49135);
            _25645 = (int)*(((s1_ptr)_2)->base + 1);
            _2 = (int)SEQ_PTR(_pair_49135);
            _25646 = (int)*(((s1_ptr)_2)->base + 2);
            _2 = (int)SEQ_PTR(_25646);
            _25647 = (int)*(((s1_ptr)_2)->base + _j_49153);
            _25646 = NOVALUE;
            Ref(_25647);
            Ref(_25645);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _25645;
            ((int *)_2)[2] = _25647;
            _25648 = MAKE_SEQ(_1);
            _25647 = NOVALUE;
            _25645 = NOVALUE;
            Concat((object_ptr)&_39switches_48497, _39switches_48497, _25648);
            DeRefDS(_25648);
            _25648 = NOVALUE;

            /** 					end for*/
            _j_49153 = _j_49153 + 1;
            goto L9; // [195] 169
LA: 
            ;
        }
        goto LB; // [200] 228
L8: 

        /** 					switches &= pair*/
        Concat((object_ptr)&_39switches_48497, _39switches_48497, _pair_49135);
        goto LB; // [212] 228
L7: 

        /** 				switches = append( switches, pair[1] )*/
        _2 = (int)SEQ_PTR(_pair_49135);
        _25651 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_25651);
        Append(&_39switches_48497, _39switches_48497, _25651);
        _25651 = NOVALUE;
LB: 
        DeRef(_pair_49135);
        _pair_49135 = NOVALUE;

        /** 		end for*/
L6: 
        _i_49133 = _i_49133 + 1;
        goto L3; // [232] 69
L4: 
        ;
    }

    /** 		Argv = Argv[2..3] & extras*/
    rhs_slice_target = (object_ptr)&_25653;
    RHS_Slice(_12Argv_11693, 2, 3);
    Concat((object_ptr)&_12Argv_11693, _25653, _extras_49125);
    DeRefDS(_25653);
    _25653 = NOVALUE;
    DeRef(_25653);
    _25653 = NOVALUE;

    /** 		Argc = length(Argv)*/
    if (IS_SEQUENCE(_12Argv_11693)){
            _12Argc_11692 = SEQ_PTR(_12Argv_11693)->length;
    }
    else {
        _12Argc_11692 = 1;
    }

    /** 		src_name = extras[1]*/
    DeRef(_39src_name_48496);
    _2 = (int)SEQ_PTR(_extras_49125);
    _39src_name_48496 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_39src_name_48496);
L2: 
    DeRef(_pairs_49130);
    _pairs_49130 = NOVALUE;

    /** end procedure*/
    DeRef(_opts_49118);
    DeRef(_extras_49125);
    _25637 = NOVALUE;
    _25643 = NOVALUE;
    return;
    ;
}



// 0x9A14BF84
