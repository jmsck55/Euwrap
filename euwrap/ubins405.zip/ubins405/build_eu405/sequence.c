// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _24reverse(int _target_3843, int _pFrom_3844, int _pTo_3845)
{
    int _uppr_3846 = NOVALUE;
    int _n_3847 = NOVALUE;
    int _lLimit_3848 = NOVALUE;
    int _t_3849 = NOVALUE;
    int _1840 = NOVALUE;
    int _1839 = NOVALUE;
    int _1838 = NOVALUE;
    int _1836 = NOVALUE;
    int _1835 = NOVALUE;
    int _1833 = NOVALUE;
    int _1831 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(target)*/
    if (IS_SEQUENCE(_target_3843)){
            _n_3847 = SEQ_PTR(_target_3843)->length;
    }
    else {
        _n_3847 = 1;
    }

    /** 	if n < 2 then*/
    if (_n_3847 >= 2)
    goto L1; // [12] 23

    /** 		return target*/
    DeRef(_t_3849);
    return _target_3843;
L1: 

    /** 	if pFrom < 1 then*/
    if (_pFrom_3844 >= 1)
    goto L2; // [25] 35

    /** 		pFrom = 1*/
    _pFrom_3844 = 1;
L2: 

    /** 	if pTo < 1 then*/
    if (_pTo_3845 >= 1)
    goto L3; // [37] 48

    /** 		pTo = n + pTo*/
    _pTo_3845 = _n_3847 + _pTo_3845;
L3: 

    /** 	if pTo < pFrom or pFrom >= n then*/
    _1831 = (_pTo_3845 < _pFrom_3844);
    if (_1831 != 0) {
        goto L4; // [54] 67
    }
    _1833 = (_pFrom_3844 >= _n_3847);
    if (_1833 == 0)
    {
        DeRef(_1833);
        _1833 = NOVALUE;
        goto L5; // [63] 74
    }
    else{
        DeRef(_1833);
        _1833 = NOVALUE;
    }
L4: 

    /** 		return target*/
    DeRef(_t_3849);
    DeRef(_1831);
    _1831 = NOVALUE;
    return _target_3843;
L5: 

    /** 	if pTo > n then*/
    if (_pTo_3845 <= _n_3847)
    goto L6; // [76] 86

    /** 		pTo = n*/
    _pTo_3845 = _n_3847;
L6: 

    /** 	lLimit = floor((pFrom+pTo-1)/2)*/
    _1835 = _pFrom_3844 + _pTo_3845;
    if ((long)((unsigned long)_1835 + (unsigned long)HIGH_BITS) >= 0) 
    _1835 = NewDouble((double)_1835);
    if (IS_ATOM_INT(_1835)) {
        _1836 = _1835 - 1;
        if ((long)((unsigned long)_1836 +(unsigned long) HIGH_BITS) >= 0){
            _1836 = NewDouble((double)_1836);
        }
    }
    else {
        _1836 = NewDouble(DBL_PTR(_1835)->dbl - (double)1);
    }
    DeRef(_1835);
    _1835 = NOVALUE;
    if (IS_ATOM_INT(_1836)) {
        _lLimit_3848 = _1836 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _1836, 2);
        _lLimit_3848 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_1836);
    _1836 = NOVALUE;
    if (!IS_ATOM_INT(_lLimit_3848)) {
        _1 = (long)(DBL_PTR(_lLimit_3848)->dbl);
        DeRefDS(_lLimit_3848);
        _lLimit_3848 = _1;
    }

    /** 	t = target*/
    Ref(_target_3843);
    DeRef(_t_3849);
    _t_3849 = _target_3843;

    /** 	uppr = pTo*/
    _uppr_3846 = _pTo_3845;

    /** 	for lowr = pFrom to lLimit do*/
    _1838 = _lLimit_3848;
    {
        int _lowr_3868;
        _lowr_3868 = _pFrom_3844;
L7: 
        if (_lowr_3868 > _1838){
            goto L8; // [119] 159
        }

        /** 		t[uppr] = target[lowr]*/
        _2 = (int)SEQ_PTR(_target_3843);
        _1839 = (int)*(((s1_ptr)_2)->base + _lowr_3868);
        Ref(_1839);
        _2 = (int)SEQ_PTR(_t_3849);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_3849 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _uppr_3846);
        _1 = *(int *)_2;
        *(int *)_2 = _1839;
        if( _1 != _1839 ){
            DeRef(_1);
        }
        _1839 = NOVALUE;

        /** 		t[lowr] = target[uppr]*/
        _2 = (int)SEQ_PTR(_target_3843);
        _1840 = (int)*(((s1_ptr)_2)->base + _uppr_3846);
        Ref(_1840);
        _2 = (int)SEQ_PTR(_t_3849);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_3849 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lowr_3868);
        _1 = *(int *)_2;
        *(int *)_2 = _1840;
        if( _1 != _1840 ){
            DeRef(_1);
        }
        _1840 = NOVALUE;

        /** 		uppr -= 1*/
        _uppr_3846 = _uppr_3846 - 1;

        /** 	end for*/
        _lowr_3868 = _lowr_3868 + 1;
        goto L7; // [154] 126
L8: 
        ;
    }

    /** 	return t*/
    DeRef(_target_3843);
    DeRef(_1831);
    _1831 = NOVALUE;
    return _t_3849;
    ;
}


int _24pad_tail(int _target_3943, int _size_3944, int _ch_3945)
{
    int _1876 = NOVALUE;
    int _1875 = NOVALUE;
    int _1874 = NOVALUE;
    int _1873 = NOVALUE;
    int _1871 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if size <= length(target) then*/
    if (IS_SEQUENCE(_target_3943)){
            _1871 = SEQ_PTR(_target_3943)->length;
    }
    else {
        _1871 = 1;
    }
    if (_size_3944 > _1871)
    goto L1; // [8] 19

    /** 		return target*/
    return _target_3943;
L1: 

    /** 	return target & repeat(ch, size - length(target))*/
    if (IS_SEQUENCE(_target_3943)){
            _1873 = SEQ_PTR(_target_3943)->length;
    }
    else {
        _1873 = 1;
    }
    _1874 = _size_3944 - _1873;
    _1873 = NOVALUE;
    _1875 = Repeat(_ch_3945, _1874);
    _1874 = NOVALUE;
    if (IS_SEQUENCE(_target_3943) && IS_ATOM(_1875)) {
    }
    else if (IS_ATOM(_target_3943) && IS_SEQUENCE(_1875)) {
        Ref(_target_3943);
        Prepend(&_1876, _1875, _target_3943);
    }
    else {
        Concat((object_ptr)&_1876, _target_3943, _1875);
    }
    DeRefDS(_1875);
    _1875 = NOVALUE;
    DeRef(_target_3943);
    return _1876;
    ;
}


int _24filter(int _source_4197, int _rid_4198, int _userdata_4199, int _rangetype_4200)
{
    int _dest_4201 = NOVALUE;
    int _idx_4202 = NOVALUE;
    int _2190 = NOVALUE;
    int _2189 = NOVALUE;
    int _2187 = NOVALUE;
    int _2186 = NOVALUE;
    int _2185 = NOVALUE;
    int _2184 = NOVALUE;
    int _2183 = NOVALUE;
    int _2180 = NOVALUE;
    int _2179 = NOVALUE;
    int _2178 = NOVALUE;
    int _2177 = NOVALUE;
    int _2174 = NOVALUE;
    int _2173 = NOVALUE;
    int _2172 = NOVALUE;
    int _2171 = NOVALUE;
    int _2170 = NOVALUE;
    int _2167 = NOVALUE;
    int _2166 = NOVALUE;
    int _2165 = NOVALUE;
    int _2164 = NOVALUE;
    int _2161 = NOVALUE;
    int _2160 = NOVALUE;
    int _2159 = NOVALUE;
    int _2158 = NOVALUE;
    int _2157 = NOVALUE;
    int _2154 = NOVALUE;
    int _2153 = NOVALUE;
    int _2152 = NOVALUE;
    int _2151 = NOVALUE;
    int _2148 = NOVALUE;
    int _2147 = NOVALUE;
    int _2146 = NOVALUE;
    int _2145 = NOVALUE;
    int _2144 = NOVALUE;
    int _2141 = NOVALUE;
    int _2140 = NOVALUE;
    int _2139 = NOVALUE;
    int _2138 = NOVALUE;
    int _2135 = NOVALUE;
    int _2134 = NOVALUE;
    int _2133 = NOVALUE;
    int _2132 = NOVALUE;
    int _2131 = NOVALUE;
    int _2128 = NOVALUE;
    int _2127 = NOVALUE;
    int _2126 = NOVALUE;
    int _2122 = NOVALUE;
    int _2119 = NOVALUE;
    int _2118 = NOVALUE;
    int _2117 = NOVALUE;
    int _2115 = NOVALUE;
    int _2114 = NOVALUE;
    int _2113 = NOVALUE;
    int _2112 = NOVALUE;
    int _2111 = NOVALUE;
    int _2108 = NOVALUE;
    int _2107 = NOVALUE;
    int _2106 = NOVALUE;
    int _2104 = NOVALUE;
    int _2103 = NOVALUE;
    int _2102 = NOVALUE;
    int _2101 = NOVALUE;
    int _2100 = NOVALUE;
    int _2097 = NOVALUE;
    int _2096 = NOVALUE;
    int _2095 = NOVALUE;
    int _2093 = NOVALUE;
    int _2092 = NOVALUE;
    int _2091 = NOVALUE;
    int _2090 = NOVALUE;
    int _2089 = NOVALUE;
    int _2086 = NOVALUE;
    int _2085 = NOVALUE;
    int _2084 = NOVALUE;
    int _2082 = NOVALUE;
    int _2081 = NOVALUE;
    int _2080 = NOVALUE;
    int _2079 = NOVALUE;
    int _2078 = NOVALUE;
    int _2076 = NOVALUE;
    int _2075 = NOVALUE;
    int _2074 = NOVALUE;
    int _2070 = NOVALUE;
    int _2067 = NOVALUE;
    int _2066 = NOVALUE;
    int _2065 = NOVALUE;
    int _2062 = NOVALUE;
    int _2059 = NOVALUE;
    int _2058 = NOVALUE;
    int _2057 = NOVALUE;
    int _2054 = NOVALUE;
    int _2051 = NOVALUE;
    int _2050 = NOVALUE;
    int _2049 = NOVALUE;
    int _2046 = NOVALUE;
    int _2043 = NOVALUE;
    int _2042 = NOVALUE;
    int _2041 = NOVALUE;
    int _2037 = NOVALUE;
    int _2034 = NOVALUE;
    int _2033 = NOVALUE;
    int _2032 = NOVALUE;
    int _2029 = NOVALUE;
    int _2026 = NOVALUE;
    int _2025 = NOVALUE;
    int _2024 = NOVALUE;
    int _2018 = NOVALUE;
    int _2016 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(source) = 0 then*/
    if (IS_SEQUENCE(_source_4197)){
            _2016 = SEQ_PTR(_source_4197)->length;
    }
    else {
        _2016 = 1;
    }
    if (_2016 != 0)
    goto L1; // [8] 19

    /** 		return source*/
    DeRefDS(_userdata_4199);
    DeRefDS(_rangetype_4200);
    DeRef(_dest_4201);
    return _source_4197;
L1: 

    /** 	dest = repeat(0, length(source))*/
    if (IS_SEQUENCE(_source_4197)){
            _2018 = SEQ_PTR(_source_4197)->length;
    }
    else {
        _2018 = 1;
    }
    DeRef(_dest_4201);
    _dest_4201 = Repeat(0, _2018);
    _2018 = NOVALUE;

    /** 	idx = 0*/
    _idx_4202 = 0;

    /** 	switch rid do*/
    _1 = find(_rid_4198, _2020);
    switch ( _1 ){ 

        /** 		case "<", "lt" then*/
        case 1:
        case 2:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2024 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2024 = 1;
        }
        {
            int _a_4214;
            _a_4214 = 1;
L2: 
            if (_a_4214 > _2024){
                goto L3; // [51] 96
            }

            /** 				if compare(source[a], userdata) < 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2025 = (int)*(((s1_ptr)_2)->base + _a_4214);
            if (IS_ATOM_INT(_2025) && IS_ATOM_INT(_userdata_4199)){
                _2026 = (_2025 < _userdata_4199) ? -1 : (_2025 > _userdata_4199);
            }
            else{
                _2026 = compare(_2025, _userdata_4199);
            }
            _2025 = NOVALUE;
            if (_2026 >= 0)
            goto L4; // [68] 89

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2029 = (int)*(((s1_ptr)_2)->base + _a_4214);
            Ref(_2029);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2029;
            if( _1 != _2029 ){
                DeRef(_1);
            }
            _2029 = NOVALUE;
L4: 

            /** 			end for*/
            _a_4214 = _a_4214 + 1;
            goto L2; // [91] 58
L3: 
            ;
        }
        goto L5; // [96] 1304

        /** 		case "<=", "le" then*/
        case 3:
        case 4:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2032 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2032 = 1;
        }
        {
            int _a_4226;
            _a_4226 = 1;
L6: 
            if (_a_4226 > _2032){
                goto L7; // [109] 154
            }

            /** 				if compare(source[a], userdata) <= 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2033 = (int)*(((s1_ptr)_2)->base + _a_4226);
            if (IS_ATOM_INT(_2033) && IS_ATOM_INT(_userdata_4199)){
                _2034 = (_2033 < _userdata_4199) ? -1 : (_2033 > _userdata_4199);
            }
            else{
                _2034 = compare(_2033, _userdata_4199);
            }
            _2033 = NOVALUE;
            if (_2034 > 0)
            goto L8; // [126] 147

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2037 = (int)*(((s1_ptr)_2)->base + _a_4226);
            Ref(_2037);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2037;
            if( _1 != _2037 ){
                DeRef(_1);
            }
            _2037 = NOVALUE;
L8: 

            /** 			end for*/
            _a_4226 = _a_4226 + 1;
            goto L6; // [149] 116
L7: 
            ;
        }
        goto L5; // [154] 1304

        /** 		case "=", "==", "eq" then*/
        case 5:
        case 6:
        case 7:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2041 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2041 = 1;
        }
        {
            int _a_4239;
            _a_4239 = 1;
L9: 
            if (_a_4239 > _2041){
                goto LA; // [169] 214
            }

            /** 				if compare(source[a], userdata) = 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2042 = (int)*(((s1_ptr)_2)->base + _a_4239);
            if (IS_ATOM_INT(_2042) && IS_ATOM_INT(_userdata_4199)){
                _2043 = (_2042 < _userdata_4199) ? -1 : (_2042 > _userdata_4199);
            }
            else{
                _2043 = compare(_2042, _userdata_4199);
            }
            _2042 = NOVALUE;
            if (_2043 != 0)
            goto LB; // [186] 207

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2046 = (int)*(((s1_ptr)_2)->base + _a_4239);
            Ref(_2046);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2046;
            if( _1 != _2046 ){
                DeRef(_1);
            }
            _2046 = NOVALUE;
LB: 

            /** 			end for*/
            _a_4239 = _a_4239 + 1;
            goto L9; // [209] 176
LA: 
            ;
        }
        goto L5; // [214] 1304

        /** 		case "!=", "ne" then*/
        case 8:
        case 9:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2049 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2049 = 1;
        }
        {
            int _a_4251;
            _a_4251 = 1;
LC: 
            if (_a_4251 > _2049){
                goto LD; // [227] 272
            }

            /** 				if compare(source[a], userdata) != 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2050 = (int)*(((s1_ptr)_2)->base + _a_4251);
            if (IS_ATOM_INT(_2050) && IS_ATOM_INT(_userdata_4199)){
                _2051 = (_2050 < _userdata_4199) ? -1 : (_2050 > _userdata_4199);
            }
            else{
                _2051 = compare(_2050, _userdata_4199);
            }
            _2050 = NOVALUE;
            if (_2051 == 0)
            goto LE; // [244] 265

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2054 = (int)*(((s1_ptr)_2)->base + _a_4251);
            Ref(_2054);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2054;
            if( _1 != _2054 ){
                DeRef(_1);
            }
            _2054 = NOVALUE;
LE: 

            /** 			end for*/
            _a_4251 = _a_4251 + 1;
            goto LC; // [267] 234
LD: 
            ;
        }
        goto L5; // [272] 1304

        /** 		case ">", "gt" then*/
        case 10:
        case 11:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2057 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2057 = 1;
        }
        {
            int _a_4263;
            _a_4263 = 1;
LF: 
            if (_a_4263 > _2057){
                goto L10; // [285] 330
            }

            /** 				if compare(source[a], userdata) > 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2058 = (int)*(((s1_ptr)_2)->base + _a_4263);
            if (IS_ATOM_INT(_2058) && IS_ATOM_INT(_userdata_4199)){
                _2059 = (_2058 < _userdata_4199) ? -1 : (_2058 > _userdata_4199);
            }
            else{
                _2059 = compare(_2058, _userdata_4199);
            }
            _2058 = NOVALUE;
            if (_2059 <= 0)
            goto L11; // [302] 323

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2062 = (int)*(((s1_ptr)_2)->base + _a_4263);
            Ref(_2062);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2062;
            if( _1 != _2062 ){
                DeRef(_1);
            }
            _2062 = NOVALUE;
L11: 

            /** 			end for*/
            _a_4263 = _a_4263 + 1;
            goto LF; // [325] 292
L10: 
            ;
        }
        goto L5; // [330] 1304

        /** 		case ">=", "ge" then*/
        case 12:
        case 13:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2065 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2065 = 1;
        }
        {
            int _a_4275;
            _a_4275 = 1;
L12: 
            if (_a_4275 > _2065){
                goto L13; // [343] 388
            }

            /** 				if compare(source[a], userdata) >= 0 then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2066 = (int)*(((s1_ptr)_2)->base + _a_4275);
            if (IS_ATOM_INT(_2066) && IS_ATOM_INT(_userdata_4199)){
                _2067 = (_2066 < _userdata_4199) ? -1 : (_2066 > _userdata_4199);
            }
            else{
                _2067 = compare(_2066, _userdata_4199);
            }
            _2066 = NOVALUE;
            if (_2067 < 0)
            goto L14; // [360] 381

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2070 = (int)*(((s1_ptr)_2)->base + _a_4275);
            Ref(_2070);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2070;
            if( _1 != _2070 ){
                DeRef(_1);
            }
            _2070 = NOVALUE;
L14: 

            /** 			end for*/
            _a_4275 = _a_4275 + 1;
            goto L12; // [383] 350
L13: 
            ;
        }
        goto L5; // [388] 1304

        /** 		case "in" then*/
        case 14:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4200, _2072);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2074 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2074 = 1;
            }
            {
                int _a_4289;
                _a_4289 = 1;
L15: 
                if (_a_4289 > _2074){
                    goto L16; // [410] 455
                }

                /** 						if find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2075 = (int)*(((s1_ptr)_2)->base + _a_4289);
                _2076 = find_from(_2075, _userdata_4199, 1);
                _2075 = NOVALUE;
                if (_2076 == 0)
                {
                    _2076 = NOVALUE;
                    goto L17; // [428] 448
                }
                else{
                    _2076 = NOVALUE;
                }

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2078 = (int)*(((s1_ptr)_2)->base + _a_4289);
                Ref(_2078);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2078;
                if( _1 != _2078 ){
                    DeRef(_1);
                }
                _2078 = NOVALUE;
L17: 

                /** 					end for*/
                _a_4289 = _a_4289 + 1;
                goto L15; // [450] 417
L16: 
                ;
            }
            goto L5; // [455] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2079 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2079 = 1;
            }
            {
                int _a_4298;
                _a_4298 = 1;
L18: 
                if (_a_4298 > _2079){
                    goto L19; // [466] 534
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2080 = (int)*(((s1_ptr)_2)->base + _a_4298);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2081 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2080) && IS_ATOM_INT(_2081)){
                    _2082 = (_2080 < _2081) ? -1 : (_2080 > _2081);
                }
                else{
                    _2082 = compare(_2080, _2081);
                }
                _2080 = NOVALUE;
                _2081 = NOVALUE;
                if (_2082 < 0)
                goto L1A; // [487] 527

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2084 = (int)*(((s1_ptr)_2)->base + _a_4298);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2085 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2084) && IS_ATOM_INT(_2085)){
                    _2086 = (_2084 < _2085) ? -1 : (_2084 > _2085);
                }
                else{
                    _2086 = compare(_2084, _2085);
                }
                _2084 = NOVALUE;
                _2085 = NOVALUE;
                if (_2086 > 0)
                goto L1B; // [505] 526

                /** 								idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2089 = (int)*(((s1_ptr)_2)->base + _a_4298);
                Ref(_2089);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2089;
                if( _1 != _2089 ){
                    DeRef(_1);
                }
                _2089 = NOVALUE;
L1B: 
L1A: 

                /** 					end for*/
                _a_4298 = _a_4298 + 1;
                goto L18; // [529] 473
L19: 
                ;
            }
            goto L5; // [534] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2090 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2090 = 1;
            }
            {
                int _a_4314;
                _a_4314 = 1;
L1C: 
                if (_a_4314 > _2090){
                    goto L1D; // [545] 613
                }

                /** 						if compare(source[a], userdata[1]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2091 = (int)*(((s1_ptr)_2)->base + _a_4314);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2092 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2091) && IS_ATOM_INT(_2092)){
                    _2093 = (_2091 < _2092) ? -1 : (_2091 > _2092);
                }
                else{
                    _2093 = compare(_2091, _2092);
                }
                _2091 = NOVALUE;
                _2092 = NOVALUE;
                if (_2093 < 0)
                goto L1E; // [566] 606

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2095 = (int)*(((s1_ptr)_2)->base + _a_4314);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2096 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2095) && IS_ATOM_INT(_2096)){
                    _2097 = (_2095 < _2096) ? -1 : (_2095 > _2096);
                }
                else{
                    _2097 = compare(_2095, _2096);
                }
                _2095 = NOVALUE;
                _2096 = NOVALUE;
                if (_2097 >= 0)
                goto L1F; // [584] 605

                /** 								idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2100 = (int)*(((s1_ptr)_2)->base + _a_4314);
                Ref(_2100);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2100;
                if( _1 != _2100 ){
                    DeRef(_1);
                }
                _2100 = NOVALUE;
L1F: 
L1E: 

                /** 					end for*/
                _a_4314 = _a_4314 + 1;
                goto L1C; // [608] 552
L1D: 
                ;
            }
            goto L5; // [613] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2101 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2101 = 1;
            }
            {
                int _a_4330;
                _a_4330 = 1;
L20: 
                if (_a_4330 > _2101){
                    goto L21; // [624] 692
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2102 = (int)*(((s1_ptr)_2)->base + _a_4330);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2103 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2102) && IS_ATOM_INT(_2103)){
                    _2104 = (_2102 < _2103) ? -1 : (_2102 > _2103);
                }
                else{
                    _2104 = compare(_2102, _2103);
                }
                _2102 = NOVALUE;
                _2103 = NOVALUE;
                if (_2104 <= 0)
                goto L22; // [645] 685

                /** 							if compare(source[a], userdata[2]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2106 = (int)*(((s1_ptr)_2)->base + _a_4330);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2107 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2106) && IS_ATOM_INT(_2107)){
                    _2108 = (_2106 < _2107) ? -1 : (_2106 > _2107);
                }
                else{
                    _2108 = compare(_2106, _2107);
                }
                _2106 = NOVALUE;
                _2107 = NOVALUE;
                if (_2108 > 0)
                goto L23; // [663] 684

                /** 								idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2111 = (int)*(((s1_ptr)_2)->base + _a_4330);
                Ref(_2111);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2111;
                if( _1 != _2111 ){
                    DeRef(_1);
                }
                _2111 = NOVALUE;
L23: 
L22: 

                /** 					end for*/
                _a_4330 = _a_4330 + 1;
                goto L20; // [687] 631
L21: 
                ;
            }
            goto L5; // [692] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2112 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2112 = 1;
            }
            {
                int _a_4346;
                _a_4346 = 1;
L24: 
                if (_a_4346 > _2112){
                    goto L25; // [703] 771
                }

                /** 						if compare(source[a], userdata[1]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2113 = (int)*(((s1_ptr)_2)->base + _a_4346);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2114 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2113) && IS_ATOM_INT(_2114)){
                    _2115 = (_2113 < _2114) ? -1 : (_2113 > _2114);
                }
                else{
                    _2115 = compare(_2113, _2114);
                }
                _2113 = NOVALUE;
                _2114 = NOVALUE;
                if (_2115 <= 0)
                goto L26; // [724] 764

                /** 							if compare(source[a], userdata[2]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2117 = (int)*(((s1_ptr)_2)->base + _a_4346);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2118 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2117) && IS_ATOM_INT(_2118)){
                    _2119 = (_2117 < _2118) ? -1 : (_2117 > _2118);
                }
                else{
                    _2119 = compare(_2117, _2118);
                }
                _2117 = NOVALUE;
                _2118 = NOVALUE;
                if (_2119 >= 0)
                goto L27; // [742] 763

                /** 								idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 								dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2122 = (int)*(((s1_ptr)_2)->base + _a_4346);
                Ref(_2122);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2122;
                if( _1 != _2122 ){
                    DeRef(_1);
                }
                _2122 = NOVALUE;
L27: 
L26: 

                /** 					end for*/
                _a_4346 = _a_4346 + 1;
                goto L24; // [766] 710
L25: 
                ;
            }
            goto L5; // [771] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [778] 1304

        /** 		case "out" then*/
        case 15:

        /** 			switch rangetype do*/
        _1 = find(_rangetype_4200, _2124);
        switch ( _1 ){ 

            /** 				case "" then*/
            case 1:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2126 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2126 = 1;
            }
            {
                int _a_4367;
                _a_4367 = 1;
L28: 
                if (_a_4367 > _2126){
                    goto L29; // [800] 845
                }

                /** 						if not find(source[a], userdata)  then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2127 = (int)*(((s1_ptr)_2)->base + _a_4367);
                _2128 = find_from(_2127, _userdata_4199, 1);
                _2127 = NOVALUE;
                if (_2128 != 0)
                goto L2A; // [818] 838
                _2128 = NOVALUE;

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2131 = (int)*(((s1_ptr)_2)->base + _a_4367);
                Ref(_2131);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2131;
                if( _1 != _2131 ){
                    DeRef(_1);
                }
                _2131 = NOVALUE;
L2A: 

                /** 					end for*/
                _a_4367 = _a_4367 + 1;
                goto L28; // [840] 807
L29: 
                ;
            }
            goto L5; // [845] 1304

            /** 				case "[]" then*/
            case 2:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2132 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2132 = 1;
            }
            {
                int _a_4377;
                _a_4377 = 1;
L2B: 
                if (_a_4377 > _2132){
                    goto L2C; // [856] 943
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2133 = (int)*(((s1_ptr)_2)->base + _a_4377);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2134 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2133) && IS_ATOM_INT(_2134)){
                    _2135 = (_2133 < _2134) ? -1 : (_2133 > _2134);
                }
                else{
                    _2135 = compare(_2133, _2134);
                }
                _2133 = NOVALUE;
                _2134 = NOVALUE;
                if (_2135 >= 0)
                goto L2D; // [877] 900

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2138 = (int)*(((s1_ptr)_2)->base + _a_4377);
                Ref(_2138);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2138;
                if( _1 != _2138 ){
                    DeRef(_1);
                }
                _2138 = NOVALUE;
                goto L2E; // [897] 936
L2D: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2139 = (int)*(((s1_ptr)_2)->base + _a_4377);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2140 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2139) && IS_ATOM_INT(_2140)){
                    _2141 = (_2139 < _2140) ? -1 : (_2139 > _2140);
                }
                else{
                    _2141 = compare(_2139, _2140);
                }
                _2139 = NOVALUE;
                _2140 = NOVALUE;
                if (_2141 <= 0)
                goto L2F; // [914] 935

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2144 = (int)*(((s1_ptr)_2)->base + _a_4377);
                Ref(_2144);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2144;
                if( _1 != _2144 ){
                    DeRef(_1);
                }
                _2144 = NOVALUE;
L2F: 
L2E: 

                /** 					end for*/
                _a_4377 = _a_4377 + 1;
                goto L2B; // [938] 863
L2C: 
                ;
            }
            goto L5; // [943] 1304

            /** 				case "[)" then*/
            case 3:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2145 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2145 = 1;
            }
            {
                int _a_4395;
                _a_4395 = 1;
L30: 
                if (_a_4395 > _2145){
                    goto L31; // [954] 1041
                }

                /** 						if compare(source[a], userdata[1]) < 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2146 = (int)*(((s1_ptr)_2)->base + _a_4395);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2147 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2146) && IS_ATOM_INT(_2147)){
                    _2148 = (_2146 < _2147) ? -1 : (_2146 > _2147);
                }
                else{
                    _2148 = compare(_2146, _2147);
                }
                _2146 = NOVALUE;
                _2147 = NOVALUE;
                if (_2148 >= 0)
                goto L32; // [975] 998

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2151 = (int)*(((s1_ptr)_2)->base + _a_4395);
                Ref(_2151);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2151;
                if( _1 != _2151 ){
                    DeRef(_1);
                }
                _2151 = NOVALUE;
                goto L33; // [995] 1034
L32: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2152 = (int)*(((s1_ptr)_2)->base + _a_4395);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2153 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2152) && IS_ATOM_INT(_2153)){
                    _2154 = (_2152 < _2153) ? -1 : (_2152 > _2153);
                }
                else{
                    _2154 = compare(_2152, _2153);
                }
                _2152 = NOVALUE;
                _2153 = NOVALUE;
                if (_2154 < 0)
                goto L34; // [1012] 1033

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2157 = (int)*(((s1_ptr)_2)->base + _a_4395);
                Ref(_2157);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2157;
                if( _1 != _2157 ){
                    DeRef(_1);
                }
                _2157 = NOVALUE;
L34: 
L33: 

                /** 					end for*/
                _a_4395 = _a_4395 + 1;
                goto L30; // [1036] 961
L31: 
                ;
            }
            goto L5; // [1041] 1304

            /** 				case "(]" then*/
            case 4:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2158 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2158 = 1;
            }
            {
                int _a_4413;
                _a_4413 = 1;
L35: 
                if (_a_4413 > _2158){
                    goto L36; // [1052] 1139
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2159 = (int)*(((s1_ptr)_2)->base + _a_4413);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2160 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2159) && IS_ATOM_INT(_2160)){
                    _2161 = (_2159 < _2160) ? -1 : (_2159 > _2160);
                }
                else{
                    _2161 = compare(_2159, _2160);
                }
                _2159 = NOVALUE;
                _2160 = NOVALUE;
                if (_2161 > 0)
                goto L37; // [1073] 1096

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2164 = (int)*(((s1_ptr)_2)->base + _a_4413);
                Ref(_2164);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2164;
                if( _1 != _2164 ){
                    DeRef(_1);
                }
                _2164 = NOVALUE;
                goto L38; // [1093] 1132
L37: 

                /** 						elsif compare(source[a], userdata[2]) > 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2165 = (int)*(((s1_ptr)_2)->base + _a_4413);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2166 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2165) && IS_ATOM_INT(_2166)){
                    _2167 = (_2165 < _2166) ? -1 : (_2165 > _2166);
                }
                else{
                    _2167 = compare(_2165, _2166);
                }
                _2165 = NOVALUE;
                _2166 = NOVALUE;
                if (_2167 <= 0)
                goto L39; // [1110] 1131

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2170 = (int)*(((s1_ptr)_2)->base + _a_4413);
                Ref(_2170);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2170;
                if( _1 != _2170 ){
                    DeRef(_1);
                }
                _2170 = NOVALUE;
L39: 
L38: 

                /** 					end for*/
                _a_4413 = _a_4413 + 1;
                goto L35; // [1134] 1059
L36: 
                ;
            }
            goto L5; // [1139] 1304

            /** 				case "()" then*/
            case 5:

            /** 					for a = 1 to length(source) do*/
            if (IS_SEQUENCE(_source_4197)){
                    _2171 = SEQ_PTR(_source_4197)->length;
            }
            else {
                _2171 = 1;
            }
            {
                int _a_4431;
                _a_4431 = 1;
L3A: 
                if (_a_4431 > _2171){
                    goto L3B; // [1150] 1237
                }

                /** 						if compare(source[a], userdata[1]) <= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2172 = (int)*(((s1_ptr)_2)->base + _a_4431);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2173 = (int)*(((s1_ptr)_2)->base + 1);
                if (IS_ATOM_INT(_2172) && IS_ATOM_INT(_2173)){
                    _2174 = (_2172 < _2173) ? -1 : (_2172 > _2173);
                }
                else{
                    _2174 = compare(_2172, _2173);
                }
                _2172 = NOVALUE;
                _2173 = NOVALUE;
                if (_2174 > 0)
                goto L3C; // [1171] 1194

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2177 = (int)*(((s1_ptr)_2)->base + _a_4431);
                Ref(_2177);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2177;
                if( _1 != _2177 ){
                    DeRef(_1);
                }
                _2177 = NOVALUE;
                goto L3D; // [1191] 1230
L3C: 

                /** 						elsif compare(source[a], userdata[2]) >= 0 then*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2178 = (int)*(((s1_ptr)_2)->base + _a_4431);
                _2 = (int)SEQ_PTR(_userdata_4199);
                _2179 = (int)*(((s1_ptr)_2)->base + 2);
                if (IS_ATOM_INT(_2178) && IS_ATOM_INT(_2179)){
                    _2180 = (_2178 < _2179) ? -1 : (_2178 > _2179);
                }
                else{
                    _2180 = compare(_2178, _2179);
                }
                _2178 = NOVALUE;
                _2179 = NOVALUE;
                if (_2180 < 0)
                goto L3E; // [1208] 1229

                /** 							idx += 1*/
                _idx_4202 = _idx_4202 + 1;

                /** 							dest[idx] = source[a]*/
                _2 = (int)SEQ_PTR(_source_4197);
                _2183 = (int)*(((s1_ptr)_2)->base + _a_4431);
                Ref(_2183);
                _2 = (int)SEQ_PTR(_dest_4201);
                _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
                _1 = *(int *)_2;
                *(int *)_2 = _2183;
                if( _1 != _2183 ){
                    DeRef(_1);
                }
                _2183 = NOVALUE;
L3E: 
L3D: 

                /** 					end for*/
                _a_4431 = _a_4431 + 1;
                goto L3A; // [1232] 1157
L3B: 
                ;
            }
            goto L5; // [1237] 1304

            /** 				case else*/
            case 0:
        ;}        goto L5; // [1244] 1304

        /** 		case else*/
        case 0:

        /** 			for a = 1 to length(source) do*/
        if (IS_SEQUENCE(_source_4197)){
                _2184 = SEQ_PTR(_source_4197)->length;
        }
        else {
            _2184 = 1;
        }
        {
            int _a_4450;
            _a_4450 = 1;
L3F: 
            if (_a_4450 > _2184){
                goto L40; // [1255] 1303
            }

            /** 				if call_func(rid, {source[a], userdata}) then*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2185 = (int)*(((s1_ptr)_2)->base + _a_4450);
            Ref(_userdata_4199);
            Ref(_2185);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _2185;
            ((int *)_2)[2] = _userdata_4199;
            _2186 = MAKE_SEQ(_1);
            _2185 = NOVALUE;
            _1 = (int)SEQ_PTR(_2186);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_rid_4198].addr;
            Ref(*(int *)(_2+4));
            Ref(*(int *)(_2+8));
            _1 = (*(int (*)())_0)(
                                *(int *)(_2+4), 
                                *(int *)(_2+8)
                                 );
            DeRef(_2187);
            _2187 = _1;
            DeRefDS(_2186);
            _2186 = NOVALUE;
            if (_2187 == 0) {
                DeRef(_2187);
                _2187 = NOVALUE;
                goto L41; // [1276] 1296
            }
            else {
                if (!IS_ATOM_INT(_2187) && DBL_PTR(_2187)->dbl == 0.0){
                    DeRef(_2187);
                    _2187 = NOVALUE;
                    goto L41; // [1276] 1296
                }
                DeRef(_2187);
                _2187 = NOVALUE;
            }
            DeRef(_2187);
            _2187 = NOVALUE;

            /** 					idx += 1*/
            _idx_4202 = _idx_4202 + 1;

            /** 					dest[idx] = source[a]*/
            _2 = (int)SEQ_PTR(_source_4197);
            _2189 = (int)*(((s1_ptr)_2)->base + _a_4450);
            Ref(_2189);
            _2 = (int)SEQ_PTR(_dest_4201);
            _2 = (int)(((s1_ptr)_2)->base + _idx_4202);
            _1 = *(int *)_2;
            *(int *)_2 = _2189;
            if( _1 != _2189 ){
                DeRef(_1);
            }
            _2189 = NOVALUE;
L41: 

            /** 			end for*/
            _a_4450 = _a_4450 + 1;
            goto L3F; // [1298] 1262
L40: 
            ;
        }
    ;}L5: 

    /** 	return dest[1..idx]*/
    rhs_slice_target = (object_ptr)&_2190;
    RHS_Slice(_dest_4201, 1, _idx_4202);
    DeRefDS(_source_4197);
    DeRef(_userdata_4199);
    DeRef(_rangetype_4200);
    DeRefDS(_dest_4201);
    return _2190;
    ;
}


int _24filter_alpha(int _elem_4462, int _ud_4463)
{
    int _2191 = NOVALUE;
    int _0, _1, _2;
    

    /** 	return t_alpha(elem)*/
    Ref(_elem_4462);
    _2191 = _9t_alpha(_elem_4462);
    DeRef(_elem_4462);
    return _2191;
    ;
}


int _24split(int _st_4507, int _delim_4508, int _no_empty_4509, int _limit_4510)
{
    int _ret_4511 = NOVALUE;
    int _start_4512 = NOVALUE;
    int _pos_4513 = NOVALUE;
    int _k_4565 = NOVALUE;
    int _2259 = NOVALUE;
    int _2257 = NOVALUE;
    int _2256 = NOVALUE;
    int _2252 = NOVALUE;
    int _2251 = NOVALUE;
    int _2250 = NOVALUE;
    int _2247 = NOVALUE;
    int _2246 = NOVALUE;
    int _2241 = NOVALUE;
    int _2240 = NOVALUE;
    int _2236 = NOVALUE;
    int _2232 = NOVALUE;
    int _2230 = NOVALUE;
    int _2229 = NOVALUE;
    int _2225 = NOVALUE;
    int _2223 = NOVALUE;
    int _2222 = NOVALUE;
    int _2221 = NOVALUE;
    int _2220 = NOVALUE;
    int _2217 = NOVALUE;
    int _2216 = NOVALUE;
    int _2215 = NOVALUE;
    int _2214 = NOVALUE;
    int _2213 = NOVALUE;
    int _2211 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence ret = {}*/
    RefDS(_5);
    DeRef(_ret_4511);
    _ret_4511 = _5;

    /** 	if length(st) = 0 then*/
    if (IS_SEQUENCE(_st_4507)){
            _2211 = SEQ_PTR(_st_4507)->length;
    }
    else {
        _2211 = 1;
    }
    if (_2211 != 0)
    goto L1; // [19] 30

    /** 		return ret*/
    DeRefDS(_st_4507);
    DeRefi(_delim_4508);
    return _ret_4511;
L1: 

    /** 	if sequence(delim) then*/
    _2213 = IS_SEQUENCE(_delim_4508);
    if (_2213 == 0)
    {
        _2213 = NOVALUE;
        goto L2; // [35] 211
    }
    else{
        _2213 = NOVALUE;
    }

    /** 		if equal(delim, "") then*/
    if (_delim_4508 == _5)
    _2214 = 1;
    else if (IS_ATOM_INT(_delim_4508) && IS_ATOM_INT(_5))
    _2214 = 0;
    else
    _2214 = (compare(_delim_4508, _5) == 0);
    if (_2214 == 0)
    {
        _2214 = NOVALUE;
        goto L3; // [44] 127
    }
    else{
        _2214 = NOVALUE;
    }

    /** 			for i = 1 to length(st) do*/
    if (IS_SEQUENCE(_st_4507)){
            _2215 = SEQ_PTR(_st_4507)->length;
    }
    else {
        _2215 = 1;
    }
    {
        int _i_4522;
        _i_4522 = 1;
L4: 
        if (_i_4522 > _2215){
            goto L5; // [52] 120
        }

        /** 				st[i] = {st[i]}*/
        _2 = (int)SEQ_PTR(_st_4507);
        _2216 = (int)*(((s1_ptr)_2)->base + _i_4522);
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_2216);
        *((int *)(_2+4)) = _2216;
        _2217 = MAKE_SEQ(_1);
        _2216 = NOVALUE;
        _2 = (int)SEQ_PTR(_st_4507);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _st_4507 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_4522);
        _1 = *(int *)_2;
        *(int *)_2 = _2217;
        if( _1 != _2217 ){
            DeRef(_1);
        }
        _2217 = NOVALUE;

        /** 				limit -= 1*/
        _limit_4510 = _limit_4510 - 1;

        /** 				if limit = 0 then*/
        if (_limit_4510 != 0)
        goto L6; // [81] 113

        /** 					st = append(st[1 .. i],st[i+1 .. $])*/
        rhs_slice_target = (object_ptr)&_2220;
        RHS_Slice(_st_4507, 1, _i_4522);
        _2221 = _i_4522 + 1;
        if (IS_SEQUENCE(_st_4507)){
                _2222 = SEQ_PTR(_st_4507)->length;
        }
        else {
            _2222 = 1;
        }
        rhs_slice_target = (object_ptr)&_2223;
        RHS_Slice(_st_4507, _2221, _2222);
        RefDS(_2223);
        Append(&_st_4507, _2220, _2223);
        DeRefDS(_2220);
        _2220 = NOVALUE;
        DeRefDS(_2223);
        _2223 = NOVALUE;

        /** 					exit*/
        goto L5; // [110] 120
L6: 

        /** 			end for*/
        _i_4522 = _i_4522 + 1;
        goto L4; // [115] 59
L5: 
        ;
    }

    /** 			return st*/
    DeRefi(_delim_4508);
    DeRef(_ret_4511);
    DeRef(_2221);
    _2221 = NOVALUE;
    return _st_4507;
L3: 

    /** 		start = 1*/
    _start_4512 = 1;

    /** 		while start <= length(st) do*/
L7: 
    if (IS_SEQUENCE(_st_4507)){
            _2225 = SEQ_PTR(_st_4507)->length;
    }
    else {
        _2225 = 1;
    }
    if (_start_4512 > _2225)
    goto L8; // [140] 290

    /** 			pos = match(delim, st, start)*/
    _pos_4513 = e_match_from(_delim_4508, _st_4507, _start_4512);

    /** 			if pos = 0 then*/
    if (_pos_4513 != 0)
    goto L9; // [153] 162

    /** 				exit*/
    goto L8; // [159] 290
L9: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2229 = _pos_4513 - 1;
    rhs_slice_target = (object_ptr)&_2230;
    RHS_Slice(_st_4507, _start_4512, _2229);
    RefDS(_2230);
    Append(&_ret_4511, _ret_4511, _2230);
    DeRefDS(_2230);
    _2230 = NOVALUE;

    /** 			start = pos+length(delim)*/
    if (IS_SEQUENCE(_delim_4508)){
            _2232 = SEQ_PTR(_delim_4508)->length;
    }
    else {
        _2232 = 1;
    }
    _start_4512 = _pos_4513 + _2232;
    _2232 = NOVALUE;

    /** 			limit -= 1*/
    _limit_4510 = _limit_4510 - 1;

    /** 			if limit = 0 then*/
    if (_limit_4510 != 0)
    goto L7; // [194] 137

    /** 				exit*/
    goto L8; // [200] 290

    /** 		end while*/
    goto L7; // [205] 137
    goto L8; // [208] 290
L2: 

    /** 		start = 1*/
    _start_4512 = 1;

    /** 		while start <= length(st) do*/
LA: 
    if (IS_SEQUENCE(_st_4507)){
            _2236 = SEQ_PTR(_st_4507)->length;
    }
    else {
        _2236 = 1;
    }
    if (_start_4512 > _2236)
    goto LB; // [224] 289

    /** 			pos = find(delim, st, start)*/
    _pos_4513 = find_from(_delim_4508, _st_4507, _start_4512);

    /** 			if pos = 0 then*/
    if (_pos_4513 != 0)
    goto LC; // [237] 246

    /** 				exit*/
    goto LB; // [243] 289
LC: 

    /** 			ret = append(ret, st[start..pos-1])*/
    _2240 = _pos_4513 - 1;
    rhs_slice_target = (object_ptr)&_2241;
    RHS_Slice(_st_4507, _start_4512, _2240);
    RefDS(_2241);
    Append(&_ret_4511, _ret_4511, _2241);
    DeRefDS(_2241);
    _2241 = NOVALUE;

    /** 			start = pos + 1*/
    _start_4512 = _pos_4513 + 1;

    /** 			limit -= 1*/
    _limit_4510 = _limit_4510 - 1;

    /** 			if limit = 0 then*/
    if (_limit_4510 != 0)
    goto LA; // [275] 221

    /** 				exit*/
    goto LB; // [281] 289

    /** 		end while*/
    goto LA; // [286] 221
LB: 
L8: 

    /** 	ret = append(ret, st[start..$])*/
    if (IS_SEQUENCE(_st_4507)){
            _2246 = SEQ_PTR(_st_4507)->length;
    }
    else {
        _2246 = 1;
    }
    rhs_slice_target = (object_ptr)&_2247;
    RHS_Slice(_st_4507, _start_4512, _2246);
    RefDS(_2247);
    Append(&_ret_4511, _ret_4511, _2247);
    DeRefDS(_2247);
    _2247 = NOVALUE;

    /** 	integer k = length(ret)*/
    if (IS_SEQUENCE(_ret_4511)){
            _k_4565 = SEQ_PTR(_ret_4511)->length;
    }
    else {
        _k_4565 = 1;
    }

    /** 	if no_empty then*/
    if (_no_empty_4509 == 0)
    {
        goto LD; // [313] 378
    }
    else{
    }

    /** 		k = 0*/
    _k_4565 = 0;

    /** 		for i = 1 to length(ret) do*/
    if (IS_SEQUENCE(_ret_4511)){
            _2250 = SEQ_PTR(_ret_4511)->length;
    }
    else {
        _2250 = 1;
    }
    {
        int _i_4569;
        _i_4569 = 1;
LE: 
        if (_i_4569 > _2250){
            goto LF; // [326] 377
        }

        /** 			if length(ret[i]) != 0 then*/
        _2 = (int)SEQ_PTR(_ret_4511);
        _2251 = (int)*(((s1_ptr)_2)->base + _i_4569);
        if (IS_SEQUENCE(_2251)){
                _2252 = SEQ_PTR(_2251)->length;
        }
        else {
            _2252 = 1;
        }
        _2251 = NOVALUE;
        if (_2252 == 0)
        goto L10; // [342] 370

        /** 				k += 1*/
        _k_4565 = _k_4565 + 1;

        /** 				if k != i then*/
        if (_k_4565 == _i_4569)
        goto L11; // [354] 369

        /** 					ret[k] = ret[i]*/
        _2 = (int)SEQ_PTR(_ret_4511);
        _2256 = (int)*(((s1_ptr)_2)->base + _i_4569);
        Ref(_2256);
        _2 = (int)SEQ_PTR(_ret_4511);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _ret_4511 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _k_4565);
        _1 = *(int *)_2;
        *(int *)_2 = _2256;
        if( _1 != _2256 ){
            DeRef(_1);
        }
        _2256 = NOVALUE;
L11: 
L10: 

        /** 		end for*/
        _i_4569 = _i_4569 + 1;
        goto LE; // [372] 333
LF: 
        ;
    }
LD: 

    /** 	if k < length(ret) then*/
    if (IS_SEQUENCE(_ret_4511)){
            _2257 = SEQ_PTR(_ret_4511)->length;
    }
    else {
        _2257 = 1;
    }
    if (_k_4565 >= _2257)
    goto L12; // [383] 401

    /** 		return ret[1 .. k]*/
    rhs_slice_target = (object_ptr)&_2259;
    RHS_Slice(_ret_4511, 1, _k_4565);
    DeRefDS(_st_4507);
    DeRefi(_delim_4508);
    DeRefDS(_ret_4511);
    DeRef(_2229);
    _2229 = NOVALUE;
    DeRef(_2221);
    _2221 = NOVALUE;
    DeRef(_2240);
    _2240 = NOVALUE;
    _2251 = NOVALUE;
    return _2259;
    goto L13; // [398] 408
L12: 

    /** 		return ret*/
    DeRefDS(_st_4507);
    DeRefi(_delim_4508);
    DeRef(_2229);
    _2229 = NOVALUE;
    DeRef(_2221);
    _2221 = NOVALUE;
    DeRef(_2240);
    _2240 = NOVALUE;
    _2251 = NOVALUE;
    DeRef(_2259);
    _2259 = NOVALUE;
    return _ret_4511;
L13: 
    ;
}


int _24join(int _items_4634, int _delim_4635)
{
    int _ret_4637 = NOVALUE;
    int _2294 = NOVALUE;
    int _2293 = NOVALUE;
    int _2291 = NOVALUE;
    int _2290 = NOVALUE;
    int _2289 = NOVALUE;
    int _2288 = NOVALUE;
    int _2286 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(items) then return {} end if*/
    if (IS_SEQUENCE(_items_4634)){
            _2286 = SEQ_PTR(_items_4634)->length;
    }
    else {
        _2286 = 1;
    }
    if (_2286 != 0)
    goto L1; // [8] 16
    _2286 = NOVALUE;
    RefDS(_5);
    DeRefDS(_items_4634);
    DeRef(_ret_4637);
    return _5;
L1: 

    /** 	ret = {}*/
    RefDS(_5);
    DeRef(_ret_4637);
    _ret_4637 = _5;

    /** 	for i=1 to length(items)-1 do*/
    if (IS_SEQUENCE(_items_4634)){
            _2288 = SEQ_PTR(_items_4634)->length;
    }
    else {
        _2288 = 1;
    }
    _2289 = _2288 - 1;
    _2288 = NOVALUE;
    {
        int _i_4642;
        _i_4642 = 1;
L2: 
        if (_i_4642 > _2289){
            goto L3; // [30] 58
        }

        /** 		ret &= items[i] & delim*/
        _2 = (int)SEQ_PTR(_items_4634);
        _2290 = (int)*(((s1_ptr)_2)->base + _i_4642);
        if (IS_SEQUENCE(_2290) && IS_ATOM(_delim_4635)) {
            Append(&_2291, _2290, _delim_4635);
        }
        else if (IS_ATOM(_2290) && IS_SEQUENCE(_delim_4635)) {
        }
        else {
            Concat((object_ptr)&_2291, _2290, _delim_4635);
            _2290 = NOVALUE;
        }
        _2290 = NOVALUE;
        if (IS_SEQUENCE(_ret_4637) && IS_ATOM(_2291)) {
        }
        else if (IS_ATOM(_ret_4637) && IS_SEQUENCE(_2291)) {
            Ref(_ret_4637);
            Prepend(&_ret_4637, _2291, _ret_4637);
        }
        else {
            Concat((object_ptr)&_ret_4637, _ret_4637, _2291);
        }
        DeRefDS(_2291);
        _2291 = NOVALUE;

        /** 	end for*/
        _i_4642 = _i_4642 + 1;
        goto L2; // [53] 37
L3: 
        ;
    }

    /** 	ret &= items[$]*/
    if (IS_SEQUENCE(_items_4634)){
            _2293 = SEQ_PTR(_items_4634)->length;
    }
    else {
        _2293 = 1;
    }
    _2 = (int)SEQ_PTR(_items_4634);
    _2294 = (int)*(((s1_ptr)_2)->base + _2293);
    if (IS_SEQUENCE(_ret_4637) && IS_ATOM(_2294)) {
        Ref(_2294);
        Append(&_ret_4637, _ret_4637, _2294);
    }
    else if (IS_ATOM(_ret_4637) && IS_SEQUENCE(_2294)) {
        Ref(_ret_4637);
        Prepend(&_ret_4637, _2294, _ret_4637);
    }
    else {
        Concat((object_ptr)&_ret_4637, _ret_4637, _2294);
    }
    _2294 = NOVALUE;

    /** 	return ret*/
    DeRefDS(_items_4634);
    DeRef(_2289);
    _2289 = NOVALUE;
    return _ret_4637;
    ;
}


int _24flatten(int _s_4744, int _delim_4745)
{
    int _ret_4746 = NOVALUE;
    int _x_4747 = NOVALUE;
    int _len_4748 = NOVALUE;
    int _pos_4749 = NOVALUE;
    int _temp_4767 = NOVALUE;
    int _2380 = NOVALUE;
    int _2379 = NOVALUE;
    int _2378 = NOVALUE;
    int _2376 = NOVALUE;
    int _2375 = NOVALUE;
    int _2374 = NOVALUE;
    int _2372 = NOVALUE;
    int _2370 = NOVALUE;
    int _2369 = NOVALUE;
    int _2368 = NOVALUE;
    int _2366 = NOVALUE;
    int _2365 = NOVALUE;
    int _2364 = NOVALUE;
    int _2363 = NOVALUE;
    int _2362 = NOVALUE;
    int _2361 = NOVALUE;
    int _2359 = NOVALUE;
    int _2358 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ret = s*/
    RefDS(_s_4744);
    DeRef(_ret_4746);
    _ret_4746 = _s_4744;

    /** 	pos = 1*/
    _pos_4749 = 1;

    /** 	len = length(ret)*/
    if (IS_SEQUENCE(_ret_4746)){
            _len_4748 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _len_4748 = 1;
    }

    /** 	while pos <= len do*/
L1: 
    if (_pos_4749 > _len_4748)
    goto L2; // [25] 183

    /** 		x = ret[pos]*/
    DeRef(_x_4747);
    _2 = (int)SEQ_PTR(_ret_4746);
    _x_4747 = (int)*(((s1_ptr)_2)->base + _pos_4749);
    Ref(_x_4747);

    /** 		if sequence(x) then*/
    _2358 = IS_SEQUENCE(_x_4747);
    if (_2358 == 0)
    {
        _2358 = NOVALUE;
        goto L3; // [40] 171
    }
    else{
        _2358 = NOVALUE;
    }

    /** 			if length(delim) = 0 then*/
    if (IS_SEQUENCE(_delim_4745)){
            _2359 = SEQ_PTR(_delim_4745)->length;
    }
    else {
        _2359 = 1;
    }
    if (_2359 != 0)
    goto L4; // [48] 89

    /** 				ret = ret[1..pos-1] & flatten(x) & ret[pos+1 .. $]*/
    _2361 = _pos_4749 - 1;
    rhs_slice_target = (object_ptr)&_2362;
    RHS_Slice(_ret_4746, 1, _2361);
    Ref(_x_4747);
    RefDS(_5);
    _2363 = _24flatten(_x_4747, _5);
    _2364 = _pos_4749 + 1;
    if (_2364 > MAXINT){
        _2364 = NewDouble((double)_2364);
    }
    if (IS_SEQUENCE(_ret_4746)){
            _2365 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _2365 = 1;
    }
    rhs_slice_target = (object_ptr)&_2366;
    RHS_Slice(_ret_4746, _2364, _2365);
    {
        int concat_list[3];

        concat_list[0] = _2366;
        concat_list[1] = _2363;
        concat_list[2] = _2362;
        Concat_N((object_ptr)&_ret_4746, concat_list, 3);
    }
    DeRefDS(_2366);
    _2366 = NOVALUE;
    DeRef(_2363);
    _2363 = NOVALUE;
    DeRefDS(_2362);
    _2362 = NOVALUE;
    goto L5; // [86] 163
L4: 

    /** 				sequence temp = ret[1..pos-1] & flatten(x)*/
    _2368 = _pos_4749 - 1;
    rhs_slice_target = (object_ptr)&_2369;
    RHS_Slice(_ret_4746, 1, _2368);
    Ref(_x_4747);
    RefDS(_5);
    _2370 = _24flatten(_x_4747, _5);
    if (IS_SEQUENCE(_2369) && IS_ATOM(_2370)) {
        Ref(_2370);
        Append(&_temp_4767, _2369, _2370);
    }
    else if (IS_ATOM(_2369) && IS_SEQUENCE(_2370)) {
    }
    else {
        Concat((object_ptr)&_temp_4767, _2369, _2370);
        DeRefDS(_2369);
        _2369 = NOVALUE;
    }
    DeRef(_2369);
    _2369 = NOVALUE;
    DeRef(_2370);
    _2370 = NOVALUE;

    /** 				if pos != length(ret) then*/
    if (IS_SEQUENCE(_ret_4746)){
            _2372 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _2372 = 1;
    }
    if (_pos_4749 == _2372)
    goto L6; // [114] 141

    /** 					ret = temp &  delim & ret[pos+1 .. $]*/
    _2374 = _pos_4749 + 1;
    if (_2374 > MAXINT){
        _2374 = NewDouble((double)_2374);
    }
    if (IS_SEQUENCE(_ret_4746)){
            _2375 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _2375 = 1;
    }
    rhs_slice_target = (object_ptr)&_2376;
    RHS_Slice(_ret_4746, _2374, _2375);
    {
        int concat_list[3];

        concat_list[0] = _2376;
        concat_list[1] = _delim_4745;
        concat_list[2] = _temp_4767;
        Concat_N((object_ptr)&_ret_4746, concat_list, 3);
    }
    DeRefDS(_2376);
    _2376 = NOVALUE;
    goto L7; // [138] 160
L6: 

    /** 					ret = temp & ret[pos+1 .. $]*/
    _2378 = _pos_4749 + 1;
    if (_2378 > MAXINT){
        _2378 = NewDouble((double)_2378);
    }
    if (IS_SEQUENCE(_ret_4746)){
            _2379 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _2379 = 1;
    }
    rhs_slice_target = (object_ptr)&_2380;
    RHS_Slice(_ret_4746, _2378, _2379);
    Concat((object_ptr)&_ret_4746, _temp_4767, _2380);
    DeRefDS(_2380);
    _2380 = NOVALUE;
L7: 
    DeRef(_temp_4767);
    _temp_4767 = NOVALUE;
L5: 

    /** 			len = length(ret)*/
    if (IS_SEQUENCE(_ret_4746)){
            _len_4748 = SEQ_PTR(_ret_4746)->length;
    }
    else {
        _len_4748 = 1;
    }
    goto L1; // [168] 25
L3: 

    /** 			pos += 1*/
    _pos_4749 = _pos_4749 + 1;

    /** 	end while*/
    goto L1; // [180] 25
L2: 

    /** 	return ret*/
    DeRefDS(_s_4744);
    DeRefi(_delim_4745);
    DeRef(_x_4747);
    DeRef(_2361);
    _2361 = NOVALUE;
    DeRef(_2368);
    _2368 = NOVALUE;
    DeRef(_2374);
    _2374 = NOVALUE;
    DeRef(_2364);
    _2364 = NOVALUE;
    DeRef(_2378);
    _2378 = NOVALUE;
    return _ret_4746;
    ;
}



// 0x05FB4A39
