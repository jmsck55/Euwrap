// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _41any_key(int _prompt_14869, int _con_14871)
{
    int _wait_key_inlined_wait_key_at_27_14876 = NOVALUE;
    int _8088 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not find(con, {1,2}) then*/
    _8088 = find_from(_con_14871, _7549, 1);
    if (_8088 != 0)
    goto L1; // [12] 21
    _8088 = NOVALUE;

    /** 		con = 1*/
    _con_14871 = 1;
L1: 

    /** 	puts(con, prompt)*/
    EPuts(_con_14871, _prompt_14869); // DJP 

    /** 	wait_key()*/

    /** 	return machine_func(M_WAIT_KEY, 0)*/
    _wait_key_inlined_wait_key_at_27_14876 = machine(26, 0);

    /** 	puts(con, "\n")*/
    EPuts(_con_14871, _3934); // DJP 

    /** end procedure*/
    DeRefDS(_prompt_14869);
    return;
    ;
}


void _41maybe_any_key(int _prompt_14879, int _con_14880)
{
    int _has_console_inlined_has_console_at_6_14883 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not has_console() then*/

    /** 	return machine_func(M_HAS_CONSOLE, 0)*/
    DeRef(_has_console_inlined_has_console_at_6_14883);
    _has_console_inlined_has_console_at_6_14883 = machine(99, 0);
    if (IS_ATOM_INT(_has_console_inlined_has_console_at_6_14883)) {
        if (_has_console_inlined_has_console_at_6_14883 != 0){
            goto L1; // [14] 24
        }
    }
    else {
        if (DBL_PTR(_has_console_inlined_has_console_at_6_14883)->dbl != 0.0){
            goto L1; // [14] 24
        }
    }

    /** 		any_key(prompt, con)*/
    RefDS(_prompt_14879);
    _41any_key(_prompt_14879, _con_14880);
L1: 

    /** end procedure*/
    DeRefDS(_prompt_14879);
    return;
    ;
}



// 0xA2DDC7A4
