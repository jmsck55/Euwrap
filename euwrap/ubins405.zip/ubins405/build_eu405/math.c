// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _21abs(int _a_2704)
{
    int _t_2705 = NOVALUE;
    int _1230 = NOVALUE;
    int _1229 = NOVALUE;
    int _1228 = NOVALUE;
    int _1226 = NOVALUE;
    int _1224 = NOVALUE;
    int _1223 = NOVALUE;
    int _1221 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1221 = IS_ATOM(_a_2704);
    if (_1221 == 0)
    {
        _1221 = NOVALUE;
        goto L1; // [6] 35
    }
    else{
        _1221 = NOVALUE;
    }

    /** 		if a >= 0 then*/
    if (binary_op_a(LESS, _a_2704, 0)){
        goto L2; // [11] 24
    }

    /** 			return a*/
    DeRef(_t_2705);
    return _a_2704;
    goto L3; // [21] 34
L2: 

    /** 			return - a*/
    if (IS_ATOM_INT(_a_2704)) {
        if ((unsigned long)_a_2704 == 0xC0000000)
        _1223 = (int)NewDouble((double)-0xC0000000);
        else
        _1223 = - _a_2704;
    }
    else {
        _1223 = unary_op(UMINUS, _a_2704);
    }
    DeRef(_a_2704);
    DeRef(_t_2705);
    return _1223;
L3: 
L1: 

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2704)){
            _1224 = SEQ_PTR(_a_2704)->length;
    }
    else {
        _1224 = 1;
    }
    {
        int _i_2713;
        _i_2713 = 1;
L4: 
        if (_i_2713 > _1224){
            goto L5; // [40] 101
        }

        /** 		t = a[i]*/
        DeRef(_t_2705);
        _2 = (int)SEQ_PTR(_a_2704);
        _t_2705 = (int)*(((s1_ptr)_2)->base + _i_2713);
        Ref(_t_2705);

        /** 		if atom(t) then*/
        _1226 = IS_ATOM(_t_2705);
        if (_1226 == 0)
        {
            _1226 = NOVALUE;
            goto L6; // [58] 80
        }
        else{
            _1226 = NOVALUE;
        }

        /** 			if t < 0 then*/
        if (binary_op_a(GREATEREQ, _t_2705, 0)){
            goto L7; // [63] 94
        }

        /** 				a[i] = - t*/
        if (IS_ATOM_INT(_t_2705)) {
            if ((unsigned long)_t_2705 == 0xC0000000)
            _1228 = (int)NewDouble((double)-0xC0000000);
            else
            _1228 = - _t_2705;
        }
        else {
            _1228 = unary_op(UMINUS, _t_2705);
        }
        _2 = (int)SEQ_PTR(_a_2704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_2704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2713);
        _1 = *(int *)_2;
        *(int *)_2 = _1228;
        if( _1 != _1228 ){
            DeRef(_1);
        }
        _1228 = NOVALUE;
        goto L7; // [77] 94
L6: 

        /** 			a[i] = abs(t)*/
        Ref(_t_2705);
        DeRef(_1229);
        _1229 = _t_2705;
        _1230 = _21abs(_1229);
        _1229 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_2704);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_2704 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_2713);
        _1 = *(int *)_2;
        *(int *)_2 = _1230;
        if( _1 != _1230 ){
            DeRef(_1);
        }
        _1230 = NOVALUE;
L7: 

        /** 	end for*/
        _i_2713 = _i_2713 + 1;
        goto L4; // [96] 47
L5: 
        ;
    }

    /** 	return a*/
    DeRef(_t_2705);
    DeRef(_1223);
    _1223 = NOVALUE;
    return _a_2704;
    ;
}


int _21max(int _a_2748)
{
    int _b_2749 = NOVALUE;
    int _c_2750 = NOVALUE;
    int _1240 = NOVALUE;
    int _1239 = NOVALUE;
    int _1238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1238 = IS_ATOM(_a_2748);
    if (_1238 == 0)
    {
        _1238 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1238 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_2749);
    DeRef(_c_2750);
    return _a_2748;
L1: 

    /** 	b = mathcons:MINF*/
    RefDS(_23MINF_2682);
    DeRef(_b_2749);
    _b_2749 = _23MINF_2682;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2748)){
            _1239 = SEQ_PTR(_a_2748)->length;
    }
    else {
        _1239 = 1;
    }
    {
        int _i_2754;
        _i_2754 = 1;
L2: 
        if (_i_2754 > _1239){
            goto L3; // [28] 64
        }

        /** 		c = max(a[i])*/
        _2 = (int)SEQ_PTR(_a_2748);
        _1240 = (int)*(((s1_ptr)_2)->base + _i_2754);
        Ref(_1240);
        _0 = _c_2750;
        _c_2750 = _21max(_1240);
        DeRef(_0);
        _1240 = NOVALUE;

        /** 		if c > b then*/
        if (binary_op_a(LESSEQ, _c_2750, _b_2749)){
            goto L4; // [47] 57
        }

        /** 			b = c*/
        Ref(_c_2750);
        DeRef(_b_2749);
        _b_2749 = _c_2750;
L4: 

        /** 	end for*/
        _i_2754 = _i_2754 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_2748);
    DeRef(_c_2750);
    return _b_2749;
    ;
}


int _21min(int _a_2762)
{
    int _b_2763 = NOVALUE;
    int _c_2764 = NOVALUE;
    int _1245 = NOVALUE;
    int _1244 = NOVALUE;
    int _1243 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1243 = IS_ATOM(_a_2762);
    if (_1243 == 0)
    {
        _1243 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1243 = NOVALUE;
    }

    /** 			return a*/
    DeRef(_b_2763);
    DeRef(_c_2764);
    return _a_2762;
L1: 

    /** 	b = mathcons:PINF*/
    RefDS(_23PINF_2678);
    DeRef(_b_2763);
    _b_2763 = _23PINF_2678;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_2762)){
            _1244 = SEQ_PTR(_a_2762)->length;
    }
    else {
        _1244 = 1;
    }
    {
        int _i_2768;
        _i_2768 = 1;
L2: 
        if (_i_2768 > _1244){
            goto L3; // [28] 64
        }

        /** 		c = min(a[i])*/
        _2 = (int)SEQ_PTR(_a_2762);
        _1245 = (int)*(((s1_ptr)_2)->base + _i_2768);
        Ref(_1245);
        _0 = _c_2764;
        _c_2764 = _21min(_1245);
        DeRef(_0);
        _1245 = NOVALUE;

        /** 			if c < b then*/
        if (binary_op_a(GREATEREQ, _c_2764, _b_2763)){
            goto L4; // [47] 57
        }

        /** 				b = c*/
        Ref(_c_2764);
        DeRef(_b_2763);
        _b_2763 = _c_2764;
L4: 

        /** 	end for*/
        _i_2768 = _i_2768 + 1;
        goto L2; // [59] 35
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_2762);
    DeRef(_c_2764);
    return _b_2763;
    ;
}


int _21or_all(int _a_3141)
{
    int _b_3142 = NOVALUE;
    int _1444 = NOVALUE;
    int _1443 = NOVALUE;
    int _1441 = NOVALUE;
    int _1440 = NOVALUE;
    int _1439 = NOVALUE;
    int _1438 = NOVALUE;
    int _1437 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(a) then*/
    _1437 = IS_ATOM(_a_3141);
    if (_1437 == 0)
    {
        _1437 = NOVALUE;
        goto L1; // [6] 16
    }
    else{
        _1437 = NOVALUE;
    }

    /** 		return a*/
    DeRef(_b_3142);
    return _a_3141;
L1: 

    /** 	b = 0*/
    DeRef(_b_3142);
    _b_3142 = 0;

    /** 	for i = 1 to length(a) do*/
    if (IS_SEQUENCE(_a_3141)){
            _1438 = SEQ_PTR(_a_3141)->length;
    }
    else {
        _1438 = 1;
    }
    {
        int _i_3146;
        _i_3146 = 1;
L2: 
        if (_i_3146 > _1438){
            goto L3; // [26] 80
        }

        /** 		if atom(a[i]) then*/
        _2 = (int)SEQ_PTR(_a_3141);
        _1439 = (int)*(((s1_ptr)_2)->base + _i_3146);
        _1440 = IS_ATOM(_1439);
        _1439 = NOVALUE;
        if (_1440 == 0)
        {
            _1440 = NOVALUE;
            goto L4; // [42] 58
        }
        else{
            _1440 = NOVALUE;
        }

        /** 			b = or_bits(b, a[i])*/
        _2 = (int)SEQ_PTR(_a_3141);
        _1441 = (int)*(((s1_ptr)_2)->base + _i_3146);
        _0 = _b_3142;
        if (IS_ATOM_INT(_b_3142) && IS_ATOM_INT(_1441)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3142 | (unsigned long)_1441;
                 _b_3142 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3142 = binary_op(OR_BITS, _b_3142, _1441);
        }
        DeRef(_0);
        _1441 = NOVALUE;
        goto L5; // [55] 73
L4: 

        /** 			b = or_bits(b, or_all(a[i]))*/
        _2 = (int)SEQ_PTR(_a_3141);
        _1443 = (int)*(((s1_ptr)_2)->base + _i_3146);
        Ref(_1443);
        _1444 = _21or_all(_1443);
        _1443 = NOVALUE;
        _0 = _b_3142;
        if (IS_ATOM_INT(_b_3142) && IS_ATOM_INT(_1444)) {
            {unsigned long tu;
                 tu = (unsigned long)_b_3142 | (unsigned long)_1444;
                 _b_3142 = MAKE_UINT(tu);
            }
        }
        else {
            _b_3142 = binary_op(OR_BITS, _b_3142, _1444);
        }
        DeRef(_0);
        DeRef(_1444);
        _1444 = NOVALUE;
L5: 

        /** 	end for*/
        _i_3146 = _i_3146 + 1;
        goto L2; // [75] 33
L3: 
        ;
    }

    /** 	return b*/
    DeRef(_a_3141);
    return _b_3142;
    ;
}



// 0xB3F434BA
