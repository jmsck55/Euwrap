// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _63is_file_newer(int _f1_23361, int _f2_23362)
{
    int _d1_23363 = NOVALUE;
    int _d2_23366 = NOVALUE;
    int _diff_2__tmp_at33_23375 = NOVALUE;
    int _diff_1__tmp_at33_23374 = NOVALUE;
    int _diff_inlined_diff_at_33_23373 = NOVALUE;
    int _13477 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_23361);
    _0 = _d1_23363;
    _d1_23363 = _14file_timestamp(_f1_23361);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_23362);
    _0 = _d2_23366;
    _d2_23366 = _14file_timestamp(_f2_23362);
    DeRef(_0);

    /** 	if atom(d2) then return 1 end if*/
    _13477 = IS_ATOM(_d2_23366);
    if (_13477 == 0)
    {
        _13477 = NOVALUE;
        goto L1; // [22] 30
    }
    else{
        _13477 = NOVALUE;
    }
    DeRefDS(_f1_23361);
    DeRefDS(_f2_23362);
    DeRef(_d1_23363);
    DeRef(_d2_23366);
    return 1;
L1: 

    /** 	if dt:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_23366);
    _0 = _diff_1__tmp_at33_23374;
    _diff_1__tmp_at33_23374 = _15datetimeToSeconds(_d2_23366);
    DeRef(_0);
    Ref(_d1_23363);
    _0 = _diff_2__tmp_at33_23375;
    _diff_2__tmp_at33_23375 = _15datetimeToSeconds(_d1_23363);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_33_23373);
    if (IS_ATOM_INT(_diff_1__tmp_at33_23374) && IS_ATOM_INT(_diff_2__tmp_at33_23375)) {
        _diff_inlined_diff_at_33_23373 = _diff_1__tmp_at33_23374 - _diff_2__tmp_at33_23375;
        if ((long)((unsigned long)_diff_inlined_diff_at_33_23373 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_33_23373 = NewDouble((double)_diff_inlined_diff_at_33_23373);
        }
    }
    else {
        _diff_inlined_diff_at_33_23373 = binary_op(MINUS, _diff_1__tmp_at33_23374, _diff_2__tmp_at33_23375);
    }
    DeRef(_diff_1__tmp_at33_23374);
    _diff_1__tmp_at33_23374 = NOVALUE;
    DeRef(_diff_2__tmp_at33_23375);
    _diff_2__tmp_at33_23375 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_33_23373, 0)){
        goto L2; // [49] 60
    }

    /** 		return 1*/
    DeRefDS(_f1_23361);
    DeRefDS(_f2_23362);
    DeRef(_d1_23363);
    DeRef(_d2_23366);
    return 1;
L2: 

    /** 	return 0*/
    DeRefDS(_f1_23361);
    DeRefDS(_f2_23362);
    DeRef(_d1_23363);
    DeRef(_d2_23366);
    return 0;
    ;
}


void _63add_preprocessor(int _file_ext_23379, int _command_23380, int _params_23381)
{
    int _tmp_23384 = NOVALUE;
    int _file_exts_23394 = NOVALUE;
    int _exts_23400 = NOVALUE;
    int _13494 = NOVALUE;
    int _13493 = NOVALUE;
    int _13492 = NOVALUE;
    int _13491 = NOVALUE;
    int _13489 = NOVALUE;
    int _13484 = NOVALUE;
    int _13479 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(command) then*/
    _13479 = 1;
    if (_13479 == 0)
    {
        _13479 = NOVALUE;
        goto L1; // [8] 53
    }
    else{
        _13479 = NOVALUE;
    }

    /** 		sequence tmp = split( file_ext, ":")*/
    RefDS(_file_ext_23379);
    RefDS(_13480);
    _0 = _tmp_23384;
    _tmp_23384 = _24split(_file_ext_23379, _13480, 0, 0);
    DeRef(_0);

    /** 		file_ext = tmp[1]*/
    DeRefDS(_file_ext_23379);
    _2 = (int)SEQ_PTR(_tmp_23384);
    _file_ext_23379 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_file_ext_23379);

    /** 		command = tmp[2]*/
    _2 = (int)SEQ_PTR(_tmp_23384);
    _command_23380 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_command_23380);

    /** 		if length(tmp) >= 3 then*/
    if (IS_SEQUENCE(_tmp_23384)){
            _13484 = SEQ_PTR(_tmp_23384)->length;
    }
    else {
        _13484 = 1;
    }
    if (_13484 < 3)
    goto L2; // [41] 52

    /** 			params = tmp[3]*/
    _2 = (int)SEQ_PTR(_tmp_23384);
    _params_23381 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_params_23381);
L2: 
L1: 
    DeRef(_tmp_23384);
    _tmp_23384 = NOVALUE;

    /** 	sequence file_exts = split( file_ext, "," )*/
    RefDS(_file_ext_23379);
    RefDS(_13487);
    _0 = _file_exts_23394;
    _file_exts_23394 = _24split(_file_ext_23379, _13487, 0, 0);
    DeRef(_0);

    /** 	if atom(params) then*/
    _13489 = IS_ATOM(_params_23381);
    if (_13489 == 0)
    {
        _13489 = NOVALUE;
        goto L3; // [71] 80
    }
    else{
        _13489 = NOVALUE;
    }

    /** 		params = ""*/
    RefDS(_5);
    DeRef(_params_23381);
    _params_23381 = _5;
L3: 

    /** 	sequence exts = split(file_ext, ",")*/
    RefDS(_file_ext_23379);
    RefDS(_13487);
    _0 = _exts_23400;
    _exts_23400 = _24split(_file_ext_23379, _13487, 0, 0);
    DeRef(_0);

    /** 	for i = 1 to length(exts) do*/
    if (IS_SEQUENCE(_exts_23400)){
            _13491 = SEQ_PTR(_exts_23400)->length;
    }
    else {
        _13491 = 1;
    }
    {
        int _i_23404;
        _i_23404 = 1;
L4: 
        if (_i_23404 > _13491){
            goto L5; // [96] 135
        }

        /** 		preprocessors &= { { exts[i], command, params, -1 } }*/
        _2 = (int)SEQ_PTR(_exts_23400);
        _13492 = (int)*(((s1_ptr)_2)->base + _i_23404);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        Ref(_13492);
        *((int *)(_2+4)) = _13492;
        Ref(_command_23380);
        *((int *)(_2+8)) = _command_23380;
        Ref(_params_23381);
        *((int *)(_2+12)) = _params_23381;
        *((int *)(_2+16)) = -1;
        _13493 = MAKE_SEQ(_1);
        _13492 = NOVALUE;
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = _13493;
        _13494 = MAKE_SEQ(_1);
        _13493 = NOVALUE;
        Concat((object_ptr)&_13preprocessors_10655, _13preprocessors_10655, _13494);
        DeRefDS(_13494);
        _13494 = NOVALUE;

        /** 	end for*/
        _i_23404 = _i_23404 + 1;
        goto L4; // [130] 103
L5: 
        ;
    }

    /** end procedure */
    DeRefDS(_file_ext_23379);
    DeRef(_command_23380);
    DeRef(_params_23381);
    DeRef(_file_exts_23394);
    DeRef(_exts_23400);
    return;
    ;
}


int _63maybe_preprocess(int _fname_23413)
{
    int _pp_23414 = NOVALUE;
    int _pp_id_23415 = NOVALUE;
    int _fext_23419 = NOVALUE;
    int _post_fname_23436 = NOVALUE;
    int _rid_23464 = NOVALUE;
    int _dll_id_23468 = NOVALUE;
    int _public_cmd_args_23504 = NOVALUE;
    int _cmd_args_23507 = NOVALUE;
    int _cmd_23536 = NOVALUE;
    int _pcmd_23541 = NOVALUE;
    int _result_23546 = NOVALUE;
    int _13573 = NOVALUE;
    int _13572 = NOVALUE;
    int _13567 = NOVALUE;
    int _13566 = NOVALUE;
    int _13564 = NOVALUE;
    int _13563 = NOVALUE;
    int _13561 = NOVALUE;
    int _13559 = NOVALUE;
    int _13558 = NOVALUE;
    int _13556 = NOVALUE;
    int _13553 = NOVALUE;
    int _13551 = NOVALUE;
    int _13549 = NOVALUE;
    int _13547 = NOVALUE;
    int _13546 = NOVALUE;
    int _13544 = NOVALUE;
    int _13543 = NOVALUE;
    int _13541 = NOVALUE;
    int _13538 = NOVALUE;
    int _13537 = NOVALUE;
    int _13536 = NOVALUE;
    int _13534 = NOVALUE;
    int _13530 = NOVALUE;
    int _13528 = NOVALUE;
    int _13527 = NOVALUE;
    int _13526 = NOVALUE;
    int _13522 = NOVALUE;
    int _13519 = NOVALUE;
    int _13518 = NOVALUE;
    int _13517 = NOVALUE;
    int _13515 = NOVALUE;
    int _13512 = NOVALUE;
    int _13510 = NOVALUE;
    int _13509 = NOVALUE;
    int _13507 = NOVALUE;
    int _13505 = NOVALUE;
    int _13503 = NOVALUE;
    int _13501 = NOVALUE;
    int _13500 = NOVALUE;
    int _13499 = NOVALUE;
    int _13498 = NOVALUE;
    int _13496 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence pp = {}*/
    RefDS(_5);
    DeRef(_pp_23414);
    _pp_23414 = _5;

    /** 	if length(preprocessors) then*/
    if (IS_SEQUENCE(_13preprocessors_10655)){
            _13496 = SEQ_PTR(_13preprocessors_10655)->length;
    }
    else {
        _13496 = 1;
    }
    if (_13496 == 0)
    {
        _13496 = NOVALUE;
        goto L1; // [17] 89
    }
    else{
        _13496 = NOVALUE;
    }

    /** 		sequence fext = fileext(fname)*/
    RefDS(_fname_23413);
    _0 = _fext_23419;
    _fext_23419 = _14fileext(_fname_23413);
    DeRef(_0);

    /** 		for i = 1 to length(preprocessors) do*/
    if (IS_SEQUENCE(_13preprocessors_10655)){
            _13498 = SEQ_PTR(_13preprocessors_10655)->length;
    }
    else {
        _13498 = 1;
    }
    {
        int _i_23423;
        _i_23423 = 1;
L2: 
        if (_i_23423 > _13498){
            goto L3; // [35] 88
        }

        /** 			if equal(fext, preprocessors[i][1]) then*/
        _2 = (int)SEQ_PTR(_13preprocessors_10655);
        _13499 = (int)*(((s1_ptr)_2)->base + _i_23423);
        _2 = (int)SEQ_PTR(_13499);
        _13500 = (int)*(((s1_ptr)_2)->base + 1);
        _13499 = NOVALUE;
        if (_fext_23419 == _13500)
        _13501 = 1;
        else if (IS_ATOM_INT(_fext_23419) && IS_ATOM_INT(_13500))
        _13501 = 0;
        else
        _13501 = (compare(_fext_23419, _13500) == 0);
        _13500 = NOVALUE;
        if (_13501 == 0)
        {
            _13501 = NOVALUE;
            goto L4; // [58] 81
        }
        else{
            _13501 = NOVALUE;
        }

        /** 				pp_id = i*/
        _pp_id_23415 = _i_23423;

        /** 				pp = preprocessors[pp_id]*/
        DeRef(_pp_23414);
        _2 = (int)SEQ_PTR(_13preprocessors_10655);
        _pp_23414 = (int)*(((s1_ptr)_2)->base + _pp_id_23415);
        RefDS(_pp_23414);

        /** 				exit*/
        goto L3; // [78] 88
L4: 

        /** 		end for*/
        _i_23423 = _i_23423 + 1;
        goto L2; // [83] 42
L3: 
        ;
    }
L1: 
    DeRef(_fext_23419);
    _fext_23419 = NOVALUE;

    /** 	if length(pp) = 0 then */
    if (IS_SEQUENCE(_pp_23414)){
            _13503 = SEQ_PTR(_pp_23414)->length;
    }
    else {
        _13503 = 1;
    }
    if (_13503 != 0)
    goto L5; // [96] 107

    /** 		return fname*/
    DeRefDS(_pp_23414);
    DeRef(_post_fname_23436);
    return _fname_23413;
L5: 

    /** 	sequence post_fname = filebase(fname) & ".pp." & fileext(fname)*/
    RefDS(_fname_23413);
    _13505 = _14filebase(_fname_23413);
    RefDS(_fname_23413);
    _13507 = _14fileext(_fname_23413);
    {
        int concat_list[3];

        concat_list[0] = _13507;
        concat_list[1] = _13506;
        concat_list[2] = _13505;
        Concat_N((object_ptr)&_post_fname_23436, concat_list, 3);
    }
    DeRef(_13507);
    _13507 = NOVALUE;
    DeRef(_13505);
    _13505 = NOVALUE;

    /** 	if length(dirname(fname)) > 0 then*/
    RefDS(_fname_23413);
    _13509 = _14dirname(_fname_23413, 0);
    if (IS_SEQUENCE(_13509)){
            _13510 = SEQ_PTR(_13509)->length;
    }
    else {
        _13510 = 1;
    }
    DeRef(_13509);
    _13509 = NOVALUE;
    if (_13510 <= 0)
    goto L6; // [133] 153

    /** 		post_fname = dirname(fname) & SLASH & post_fname*/
    RefDS(_fname_23413);
    _13512 = _14dirname(_fname_23413, 0);
    {
        int concat_list[3];

        concat_list[0] = _post_fname_23436;
        concat_list[1] = 47;
        concat_list[2] = _13512;
        Concat_N((object_ptr)&_post_fname_23436, concat_list, 3);
    }
    DeRef(_13512);
    _13512 = NOVALUE;
L6: 

    /** 	if not force_preprocessor then*/
    if (_13force_preprocessor_10656 != 0)
    goto L7; // [157] 178

    /** 		if not is_file_newer(fname, post_fname) then*/
    RefDS(_fname_23413);
    RefDS(_post_fname_23436);
    _13515 = _63is_file_newer(_fname_23413, _post_fname_23436);
    if (IS_ATOM_INT(_13515)) {
        if (_13515 != 0){
            DeRef(_13515);
            _13515 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    else {
        if (DBL_PTR(_13515)->dbl != 0.0){
            DeRef(_13515);
            _13515 = NOVALUE;
            goto L8; // [167] 177
        }
    }
    DeRef(_13515);
    _13515 = NOVALUE;

    /** 			return post_fname*/
    DeRefDS(_fname_23413);
    DeRef(_pp_23414);
    _13509 = NOVALUE;
    return _post_fname_23436;
L8: 
L7: 

    /** 	if equal(fileext(pp[PP_COMMAND]), SHARED_LIB_EXT) then*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13517 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13517);
    _13518 = _14fileext(_13517);
    _13517 = NOVALUE;
    if (_13518 == _14SHARED_LIB_EXT_9081)
    _13519 = 1;
    else if (IS_ATOM_INT(_13518) && IS_ATOM_INT(_14SHARED_LIB_EXT_9081))
    _13519 = 0;
    else
    _13519 = (compare(_13518, _14SHARED_LIB_EXT_9081) == 0);
    DeRef(_13518);
    _13518 = NOVALUE;
    if (_13519 == 0)
    {
        _13519 = NOVALUE;
        goto L9; // [194] 348
    }
    else{
        _13519 = NOVALUE;
    }

    /** 		integer rid = pp[PP_RID]*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _rid_23464 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_rid_23464))
    _rid_23464 = (long)DBL_PTR(_rid_23464)->dbl;

    /** 		if rid = -1 then*/
    if (_rid_23464 != -1)
    goto LA; // [205] 307

    /** 			integer dll_id = open_dll(pp[PP_COMMAND])*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13522 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13522);
    _dll_id_23468 = _7open_dll(_13522);
    _13522 = NOVALUE;
    if (!IS_ATOM_INT(_dll_id_23468)) {
        _1 = (long)(DBL_PTR(_dll_id_23468)->dbl);
        DeRefDS(_dll_id_23468);
        _dll_id_23468 = _1;
    }

    /** 			if dll_id = -1 then*/
    if (_dll_id_23468 != -1)
    goto LB; // [223] 247

    /** 				CompileErr(sprintf("Preprocessor shared library '%s' could not be loaded\n",*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13526 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13526);
    *((int *)(_2+4)) = _13526;
    _13527 = MAKE_SEQ(_1);
    _13526 = NOVALUE;
    _13528 = EPrintf(-9999999, _13525, _13527);
    DeRefDS(_13527);
    _13527 = NOVALUE;
    RefDS(_21829);
    _43CompileErr(_13528, _21829, 1);
    _13528 = NOVALUE;
LB: 

    /** 			rid = define_c_func(dll_id, "preprocess", { E_SEQUENCE, E_SEQUENCE, E_SEQUENCE }, */
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 134217732;
    *((int *)(_2+8)) = 134217732;
    *((int *)(_2+12)) = 134217732;
    _13530 = MAKE_SEQ(_1);
    RefDS(_13529);
    _rid_23464 = _7define_c_func(_dll_id_23468, _13529, _13530, 100663300);
    _13530 = NOVALUE;
    if (!IS_ATOM_INT(_rid_23464)) {
        _1 = (long)(DBL_PTR(_rid_23464)->dbl);
        DeRefDS(_rid_23464);
        _rid_23464 = _1;
    }

    /** 			if rid = -1 then*/
    if (_rid_23464 != -1)
    goto LC; // [274] 291

    /** 				CompileErr("Preprocessor entry point cound not be found\n",,1)*/
    RefDS(_13533);
    RefDS(_21829);
    _43CompileErr(_13533, _21829, 1);

    /** 				Cleanup(1)*/
    _43Cleanup(1);
LC: 

    /** 			preprocessors[pp_id][PP_RID] = rid*/
    _2 = (int)SEQ_PTR(_13preprocessors_10655);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13preprocessors_10655 = MAKE_SEQ(_2);
    }
    _3 = (int)(_pp_id_23415 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _rid_23464;
    DeRef(_1);
    _13534 = NOVALUE;
LA: 

    /** 		if c_func(rid, { fname, post_fname, pp[PP_PARAMS] }) != 0 then*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13536 = (int)*(((s1_ptr)_2)->base + 3);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_fname_23413);
    *((int *)(_2+4)) = _fname_23413;
    RefDS(_post_fname_23436);
    *((int *)(_2+8)) = _post_fname_23436;
    Ref(_13536);
    *((int *)(_2+12)) = _13536;
    _13537 = MAKE_SEQ(_1);
    _13536 = NOVALUE;
    _13538 = call_c(1, _rid_23464, _13537);
    DeRefDS(_13537);
    _13537 = NOVALUE;
    if (binary_op_a(EQUALS, _13538, 0)){
        DeRef(_13538);
        _13538 = NOVALUE;
        goto LD; // [326] 343
    }
    DeRef(_13538);
    _13538 = NOVALUE;

    /** 			CompileErr("Preprocessor call failed\n",,1)*/
    RefDS(_13540);
    RefDS(_21829);
    _43CompileErr(_13540, _21829, 1);

    /** 			Cleanup(1)*/
    _43Cleanup(1);
LD: 
    goto LE; // [345] 520
L9: 

    /** 		sequence public_cmd_args = {pp[PP_COMMAND]}*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13541 = (int)*(((s1_ptr)_2)->base + 2);
    _0 = _public_cmd_args_23504;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_13541);
    *((int *)(_2+4)) = _13541;
    _public_cmd_args_23504 = MAKE_SEQ(_1);
    DeRef(_0);
    _13541 = NOVALUE;

    /** 		sequence cmd_args = {canonical_path(pp[PP_COMMAND],,TO_SHORT)}*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13543 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13543);
    _13544 = _14canonical_path(_13543, 0, 4);
    _13543 = NOVALUE;
    _0 = _cmd_args_23507;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _13544;
    _cmd_args_23507 = MAKE_SEQ(_1);
    DeRef(_0);
    _13544 = NOVALUE;

    /** 		if equal(fileext(pp[PP_COMMAND]), "ex") then*/
    _2 = (int)SEQ_PTR(_pp_23414);
    _13546 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_13546);
    _13547 = _14fileext(_13546);
    _13546 = NOVALUE;
    if (_13547 == _13548)
    _13549 = 1;
    else if (IS_ATOM_INT(_13547) && IS_ATOM_INT(_13548))
    _13549 = 0;
    else
    _13549 = (compare(_13547, _13548) == 0);
    DeRef(_13547);
    _13547 = NOVALUE;
    if (_13549 == 0)
    {
        _13549 = NOVALUE;
        goto LF; // [390] 414
    }
    else{
        _13549 = NOVALUE;
    }

    /** 			public_cmd_args = { "eui" } & public_cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13550);
    *((int *)(_2+4)) = _13550;
    _13551 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23504, _13551, _public_cmd_args_23504);
    DeRefDS(_13551);
    _13551 = NOVALUE;
    DeRef(_13551);
    _13551 = NOVALUE;

    /** 			cmd_args = { "eui" } & cmd_args*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13550);
    *((int *)(_2+4)) = _13550;
    _13553 = MAKE_SEQ(_1);
    Concat((object_ptr)&_cmd_args_23507, _13553, _cmd_args_23507);
    DeRefDS(_13553);
    _13553 = NOVALUE;
    DeRef(_13553);
    _13553 = NOVALUE;
LF: 

    /** 		cmd_args &= { "-i", canonical_path(fname,,TO_SHORT), "-o", canonical_path(post_fname,,TO_SHORT) }*/
    RefDS(_fname_23413);
    _13556 = _14canonical_path(_fname_23413, 0, 4);
    RefDS(_post_fname_23436);
    _13558 = _14canonical_path(_post_fname_23436, 0, 4);
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13555);
    *((int *)(_2+4)) = _13555;
    *((int *)(_2+8)) = _13556;
    RefDS(_13557);
    *((int *)(_2+12)) = _13557;
    *((int *)(_2+16)) = _13558;
    _13559 = MAKE_SEQ(_1);
    _13558 = NOVALUE;
    _13556 = NOVALUE;
    Concat((object_ptr)&_cmd_args_23507, _cmd_args_23507, _13559);
    DeRefDS(_13559);
    _13559 = NOVALUE;

    /** 		public_cmd_args &= { "-i", fname, "-o", post_fname }*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_13555);
    *((int *)(_2+4)) = _13555;
    RefDS(_fname_23413);
    *((int *)(_2+8)) = _fname_23413;
    RefDS(_13557);
    *((int *)(_2+12)) = _13557;
    RefDS(_post_fname_23436);
    *((int *)(_2+16)) = _post_fname_23436;
    _13561 = MAKE_SEQ(_1);
    Concat((object_ptr)&_public_cmd_args_23504, _public_cmd_args_23504, _13561);
    DeRefDS(_13561);
    _13561 = NOVALUE;

    /** 		sequence cmd = build_commandline( cmd_args ) & pp[PP_PARAMS]*/
    RefDS(_cmd_args_23507);
    _13563 = _40build_commandline(_cmd_args_23507);
    _2 = (int)SEQ_PTR(_pp_23414);
    _13564 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13563) && IS_ATOM(_13564)) {
        Ref(_13564);
        Append(&_cmd_23536, _13563, _13564);
    }
    else if (IS_ATOM(_13563) && IS_SEQUENCE(_13564)) {
        Ref(_13563);
        Prepend(&_cmd_23536, _13564, _13563);
    }
    else {
        Concat((object_ptr)&_cmd_23536, _13563, _13564);
        DeRef(_13563);
        _13563 = NOVALUE;
    }
    DeRef(_13563);
    _13563 = NOVALUE;
    _13564 = NOVALUE;

    /** 		sequence pcmd = build_commandline(public_cmd_args) & pp[PP_PARAMS]*/
    RefDS(_public_cmd_args_23504);
    _13566 = _40build_commandline(_public_cmd_args_23504);
    _2 = (int)SEQ_PTR(_pp_23414);
    _13567 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_SEQUENCE(_13566) && IS_ATOM(_13567)) {
        Ref(_13567);
        Append(&_pcmd_23541, _13566, _13567);
    }
    else if (IS_ATOM(_13566) && IS_SEQUENCE(_13567)) {
        Ref(_13566);
        Prepend(&_pcmd_23541, _13567, _13566);
    }
    else {
        Concat((object_ptr)&_pcmd_23541, _13566, _13567);
        DeRef(_13566);
        _13566 = NOVALUE;
    }
    DeRef(_13566);
    _13566 = NOVALUE;
    _13567 = NOVALUE;

    /** 		integer result = system_exec(cmd, 2)*/
    _result_23546 = system_exec_call(_cmd_23536, 2);

    /** 		if result != 0 then*/
    if (_result_23546 == 0)
    goto L10; // [492] 517

    /** 			CompileErr(sprintf("Preprocessor command failed (%d): %s\n", { result, pcmd } ),,1)*/
    RefDS(_pcmd_23541);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _result_23546;
    ((int *)_2)[2] = _pcmd_23541;
    _13572 = MAKE_SEQ(_1);
    _13573 = EPrintf(-9999999, _13571, _13572);
    DeRefDS(_13572);
    _13572 = NOVALUE;
    RefDS(_21829);
    _43CompileErr(_13573, _21829, 1);
    _13573 = NOVALUE;

    /** 			Cleanup(1)*/
    _43Cleanup(1);
L10: 
    DeRef(_public_cmd_args_23504);
    _public_cmd_args_23504 = NOVALUE;
    DeRef(_cmd_args_23507);
    _cmd_args_23507 = NOVALUE;
    DeRef(_cmd_23536);
    _cmd_23536 = NOVALUE;
    DeRef(_pcmd_23541);
    _pcmd_23541 = NOVALUE;
LE: 

    /** 	return post_fname*/
    DeRefDS(_fname_23413);
    DeRef(_pp_23414);
    _13509 = NOVALUE;
    return _post_fname_23436;
    ;
}



// 0x1D265144
