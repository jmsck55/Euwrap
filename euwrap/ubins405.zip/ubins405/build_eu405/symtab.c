// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _52hashfn(int _name_45746)
{
    int _len_45747 = NOVALUE;
    int _val_45748 = NOVALUE;
    int _int_45749 = NOVALUE;
    int _24173 = NOVALUE;
    int _24172 = NOVALUE;
    int _24169 = NOVALUE;
    int _24168 = NOVALUE;
    int _24157 = NOVALUE;
    int _24153 = NOVALUE;
    int _0, _1, _2;
    

    /** 	len = length(name)*/
    if (IS_SEQUENCE(_name_45746)){
            _len_45747 = SEQ_PTR(_name_45746)->length;
    }
    else {
        _len_45747 = 1;
    }

    /** 	val = name[1]*/
    _2 = (int)SEQ_PTR(_name_45746);
    _val_45748 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_val_45748))
    _val_45748 = (long)DBL_PTR(_val_45748)->dbl;

    /** 	int = name[$]*/
    if (IS_SEQUENCE(_name_45746)){
            _24153 = SEQ_PTR(_name_45746)->length;
    }
    else {
        _24153 = 1;
    }
    _2 = (int)SEQ_PTR(_name_45746);
    _int_45749 = (int)*(((s1_ptr)_2)->base + _24153);
    if (!IS_ATOM_INT(_int_45749))
    _int_45749 = (long)DBL_PTR(_int_45749)->dbl;

    /** 	int *= 256*/
    _int_45749 = _int_45749 * 256;

    /** 	val *= 2*/
    _val_45748 = _val_45748 + _val_45748;

    /** 	val += int + len*/
    _24157 = _int_45749 + _len_45747;
    if ((long)((unsigned long)_24157 + (unsigned long)HIGH_BITS) >= 0) 
    _24157 = NewDouble((double)_24157);
    if (IS_ATOM_INT(_24157)) {
        _val_45748 = _val_45748 + _24157;
    }
    else {
        _val_45748 = NewDouble((double)_val_45748 + DBL_PTR(_24157)->dbl);
    }
    DeRef(_24157);
    _24157 = NOVALUE;
    if (!IS_ATOM_INT(_val_45748)) {
        _1 = (long)(DBL_PTR(_val_45748)->dbl);
        DeRefDS(_val_45748);
        _val_45748 = _1;
    }

    /** 	if len = 3 then*/
    if (_len_45747 != 3)
    goto L1; // [51] 78

    /** 		val *= 32*/
    _val_45748 = _val_45748 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_45746);
    _int_45749 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_45749))
    _int_45749 = (long)DBL_PTR(_int_45749)->dbl;

    /** 		val += int*/
    _val_45748 = _val_45748 + _int_45749;
    goto L2; // [75] 133
L1: 

    /** 	elsif len > 3 then*/
    if (_len_45747 <= 3)
    goto L3; // [80] 132

    /** 		val *= 32*/
    _val_45748 = _val_45748 * 32;

    /** 		int = name[2]*/
    _2 = (int)SEQ_PTR(_name_45746);
    _int_45749 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_int_45749))
    _int_45749 = (long)DBL_PTR(_int_45749)->dbl;

    /** 		val += int*/
    _val_45748 = _val_45748 + _int_45749;

    /** 		val *= 32*/
    _val_45748 = _val_45748 * 32;

    /** 		int = name[$-1]*/
    if (IS_SEQUENCE(_name_45746)){
            _24168 = SEQ_PTR(_name_45746)->length;
    }
    else {
        _24168 = 1;
    }
    _24169 = _24168 - 1;
    _24168 = NOVALUE;
    _2 = (int)SEQ_PTR(_name_45746);
    _int_45749 = (int)*(((s1_ptr)_2)->base + _24169);
    if (!IS_ATOM_INT(_int_45749))
    _int_45749 = (long)DBL_PTR(_int_45749)->dbl;

    /** 		val += int*/
    _val_45748 = _val_45748 + _int_45749;
L3: 
L2: 

    /** 	return remainder(val, NBUCKETS) + 1*/
    _24172 = (_val_45748 % 2003);
    _24173 = _24172 + 1;
    _24172 = NOVALUE;
    DeRefDS(_name_45746);
    DeRef(_24169);
    _24169 = NOVALUE;
    return _24173;
    ;
}


void _52remove_symbol(int _sym_45778)
{
    int _hash_45779 = NOVALUE;
    int _st_ptr_45780 = NOVALUE;
    int _24188 = NOVALUE;
    int _24187 = NOVALUE;
    int _24185 = NOVALUE;
    int _24184 = NOVALUE;
    int _24183 = NOVALUE;
    int _24181 = NOVALUE;
    int _24179 = NOVALUE;
    int _24178 = NOVALUE;
    int _24177 = NOVALUE;
    int _24174 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_sym_45778)) {
        _1 = (long)(DBL_PTR(_sym_45778)->dbl);
        DeRefDS(_sym_45778);
        _sym_45778 = _1;
    }

    /** 	hash = SymTab[sym][S_HASHVAL]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24174 = (int)*(((s1_ptr)_2)->base + _sym_45778);
    _2 = (int)SEQ_PTR(_24174);
    _hash_45779 = (int)*(((s1_ptr)_2)->base + 11);
    if (!IS_ATOM_INT(_hash_45779)){
        _hash_45779 = (long)DBL_PTR(_hash_45779)->dbl;
    }
    _24174 = NOVALUE;

    /** 	st_ptr = buckets[hash]*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _st_ptr_45780 = (int)*(((s1_ptr)_2)->base + _hash_45779);
    if (!IS_ATOM_INT(_st_ptr_45780))
    _st_ptr_45780 = (long)DBL_PTR(_st_ptr_45780)->dbl;

    /** 	while st_ptr and st_ptr != sym do*/
L1: 
    if (_st_ptr_45780 == 0) {
        goto L2; // [32] 65
    }
    _24178 = (_st_ptr_45780 != _sym_45778);
    if (_24178 == 0)
    {
        DeRef(_24178);
        _24178 = NOVALUE;
        goto L2; // [41] 65
    }
    else{
        DeRef(_24178);
        _24178 = NOVALUE;
    }

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24179 = (int)*(((s1_ptr)_2)->base + _st_ptr_45780);
    _2 = (int)SEQ_PTR(_24179);
    _st_ptr_45780 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_45780)){
        _st_ptr_45780 = (long)DBL_PTR(_st_ptr_45780)->dbl;
    }
    _24179 = NOVALUE;

    /** 	end while*/
    goto L1; // [62] 32
L2: 

    /** 	if st_ptr then*/
    if (_st_ptr_45780 == 0)
    {
        goto L3; // [67] 134
    }
    else{
    }

    /** 		if st_ptr = buckets[hash] then*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _24181 = (int)*(((s1_ptr)_2)->base + _hash_45779);
    if (binary_op_a(NOTEQ, _st_ptr_45780, _24181)){
        _24181 = NOVALUE;
        goto L4; // [78] 105
    }
    _24181 = NOVALUE;

    /** 			buckets[hash] = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24183 = (int)*(((s1_ptr)_2)->base + _st_ptr_45780);
    _2 = (int)SEQ_PTR(_24183);
    _24184 = (int)*(((s1_ptr)_2)->base + 9);
    _24183 = NOVALUE;
    Ref(_24184);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _2 = (int)(((s1_ptr)_2)->base + _hash_45779);
    _1 = *(int *)_2;
    *(int *)_2 = _24184;
    if( _1 != _24184 ){
        DeRef(_1);
    }
    _24184 = NOVALUE;
    goto L5; // [102] 133
L4: 

    /** 			SymTab[st_ptr][S_SAMEHASH] = SymTab[sym][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_st_ptr_45780 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24187 = (int)*(((s1_ptr)_2)->base + _sym_45778);
    _2 = (int)SEQ_PTR(_24187);
    _24188 = (int)*(((s1_ptr)_2)->base + 9);
    _24187 = NOVALUE;
    Ref(_24188);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24188;
    if( _1 != _24188 ){
        DeRef(_1);
    }
    _24188 = NOVALUE;
    _24185 = NOVALUE;
L5: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _52NewBasicEntry(int _name_45812, int _varnum_45813, int _scope_45814, int _token_45815, int _hashval_45816, int _samehash_45818, int _type_sym_45820)
{
    int _new_45821 = NOVALUE;
    int _24197 = NOVALUE;
    int _24195 = NOVALUE;
    int _24194 = NOVALUE;
    int _24193 = NOVALUE;
    int _24192 = NOVALUE;
    int _24191 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_varnum_45813)) {
        _1 = (long)(DBL_PTR(_varnum_45813)->dbl);
        DeRefDS(_varnum_45813);
        _varnum_45813 = _1;
    }
    if (!IS_ATOM_INT(_scope_45814)) {
        _1 = (long)(DBL_PTR(_scope_45814)->dbl);
        DeRefDS(_scope_45814);
        _scope_45814 = _1;
    }
    if (!IS_ATOM_INT(_token_45815)) {
        _1 = (long)(DBL_PTR(_token_45815)->dbl);
        DeRefDS(_token_45815);
        _token_45815 = _1;
    }
    if (!IS_ATOM_INT(_hashval_45816)) {
        _1 = (long)(DBL_PTR(_hashval_45816)->dbl);
        DeRefDS(_hashval_45816);
        _hashval_45816 = _1;
    }
    if (!IS_ATOM_INT(_samehash_45818)) {
        _1 = (long)(DBL_PTR(_samehash_45818)->dbl);
        DeRefDS(_samehash_45818);
        _samehash_45818 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_45820)) {
        _1 = (long)(DBL_PTR(_type_sym_45820)->dbl);
        DeRefDS(_type_sym_45820);
        _type_sym_45820 = _1;
    }

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [19] 33
    }
    else{
    }

    /** 		new = repeat(0, SIZEOF_ROUTINE_ENTRY)*/
    DeRef(_new_45821);
    _new_45821 = Repeat(0, _12SIZEOF_ROUTINE_ENTRY_11479);
    goto L2; // [30] 42
L1: 

    /** 		new = repeat(0, SIZEOF_VAR_ENTRY)*/
    DeRef(_new_45821);
    _new_45821 = Repeat(0, _12SIZEOF_VAR_ENTRY_11482);
L2: 

    /** 	new[S_NEXT] = 0*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_NAME] = name*/
    RefDS(_name_45812);
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_NAME_11354))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_NAME_11354);
    _1 = *(int *)_2;
    *(int *)_2 = _name_45812;
    DeRef(_1);

    /** 	new[S_SCOPE] = scope*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _scope_45814;
    DeRef(_1);

    /** 	new[S_MODE] = M_NORMAL*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);

    /** 	new[S_USAGE] = U_UNUSED*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	new[S_FILE_NO] = current_file_no*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_11350))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    _1 = *(int *)_2;
    *(int *)_2 = _12current_file_no_11682;
    DeRef(_1);

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [102] 327
    }
    else{
    }

    /** 		new[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_SEQ_ELEM_NEW] = TYPE_NULL -- starting point for ORing*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ARG_MIN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 		new[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _24191 = (int)NewDouble((double)-0xC0000000);
        else
        _24191 = - _12NOVALUE_11536;
    }
    else {
        _24191 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _24191;
    if( _1 != _24191 ){
        DeRef(_1);
    }
    _24191 = NOVALUE;

    /** 		new[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 		new[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _24192 = (int)NewDouble((double)-0xC0000000);
        else
        _24192 = - _12NOVALUE_11536;
    }
    else {
        _24192 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _24192;
    if( _1 != _24192 ){
        DeRef(_1);
    }
    _24192 = NOVALUE;

    /** 		new[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 		new[S_SEQ_LEN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _24193 = (int)NewDouble((double)-0xC0000000);
        else
        _24193 = - _12NOVALUE_11536;
    }
    else {
        _24193 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _24193;
    if( _1 != _24193 ){
        DeRef(_1);
    }
    _24193 = NOVALUE;

    /** 		new[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_ONE_REF] = TRUE          -- assume TRUE until we find otherwise*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 35);
    _1 = *(int *)_2;
    *(int *)_2 = _9TRUE_431;
    DeRef(_1);

    /** 		new[S_RI_TARGET] = 0*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 53);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		new[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 		new[S_OBJ_MIN_NEW] = -NOVALUE -- no idea yet*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _24194 = (int)NewDouble((double)-0xC0000000);
        else
        _24194 = - _12NOVALUE_11536;
    }
    else {
        _24194 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _24194;
    if( _1 != _24194 ){
        DeRef(_1);
    }
    _24194 = NOVALUE;

    /** 		new[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);

    /** 		new[S_OBJ_MAX_NEW] = -NOVALUE -- missing from C code? (not needed)*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _24195 = (int)NewDouble((double)-0xC0000000);
        else
        _24195 = - _12NOVALUE_11536;
    }
    else {
        _24195 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _24195;
    if( _1 != _24195 ){
        DeRef(_1);
    }
    _24195 = NOVALUE;
L3: 

    /** 	new[S_TOKEN] = token*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TOKEN_11359))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    _1 = *(int *)_2;
    *(int *)_2 = _token_45815;
    DeRef(_1);

    /** 	new[S_VARNUM] = varnum*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 16);
    _1 = *(int *)_2;
    *(int *)_2 = _varnum_45813;
    DeRef(_1);

    /** 	new[S_INITLEVEL] = -1*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 14);
    _1 = *(int *)_2;
    *(int *)_2 = -1;
    DeRef(_1);

    /** 	new[S_VTYPE] = type_sym*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 15);
    _1 = *(int *)_2;
    *(int *)_2 = _type_sym_45820;
    DeRef(_1);

    /** 	new[S_HASHVAL] = hashval*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 11);
    _1 = *(int *)_2;
    *(int *)_2 = _hashval_45816;
    DeRef(_1);

    /** 	new[S_SAMEHASH] = samehash*/
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _samehash_45818;
    DeRef(_1);

    /** 	new[S_OBJ] = NOVALUE -- important*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_new_45821);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_45821 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 	SymTab = append(SymTab, new)*/
    RefDS(_new_45821);
    Append(&_13SymTab_10636, _13SymTab_10636, _new_45821);

    /** 	return length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _24197 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _24197 = 1;
    }
    DeRefDS(_name_45812);
    DeRefDS(_new_45821);
    return _24197;
    ;
}


int _52NewEntry(int _name_45900, int _varnum_45901, int _scope_45902, int _token_45903, int _hashval_45904, int _samehash_45906, int _type_sym_45908)
{
    int _new_45910 = NOVALUE;
    int _24199 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_varnum_45901)) {
        _1 = (long)(DBL_PTR(_varnum_45901)->dbl);
        DeRefDS(_varnum_45901);
        _varnum_45901 = _1;
    }
    if (!IS_ATOM_INT(_scope_45902)) {
        _1 = (long)(DBL_PTR(_scope_45902)->dbl);
        DeRefDS(_scope_45902);
        _scope_45902 = _1;
    }
    if (!IS_ATOM_INT(_token_45903)) {
        _1 = (long)(DBL_PTR(_token_45903)->dbl);
        DeRefDS(_token_45903);
        _token_45903 = _1;
    }
    if (!IS_ATOM_INT(_hashval_45904)) {
        _1 = (long)(DBL_PTR(_hashval_45904)->dbl);
        DeRefDS(_hashval_45904);
        _hashval_45904 = _1;
    }
    if (!IS_ATOM_INT(_samehash_45906)) {
        _1 = (long)(DBL_PTR(_samehash_45906)->dbl);
        DeRefDS(_samehash_45906);
        _samehash_45906 = _1;
    }
    if (!IS_ATOM_INT(_type_sym_45908)) {
        _1 = (long)(DBL_PTR(_type_sym_45908)->dbl);
        DeRefDS(_type_sym_45908);
        _type_sym_45908 = _1;
    }

    /** 	symtab_index new = NewBasicEntry( name, varnum, scope, token, hashval, samehash, type_sym )*/
    RefDS(_name_45900);
    _new_45910 = _52NewBasicEntry(_name_45900, _varnum_45901, _scope_45902, _token_45903, _hashval_45904, _samehash_45906, _type_sym_45908);
    if (!IS_ATOM_INT(_new_45910)) {
        _1 = (long)(DBL_PTR(_new_45910)->dbl);
        DeRefDS(_new_45910);
        _new_45910 = _1;
    }

    /** 	if last_sym then*/
    if (_52last_sym_45740 == 0)
    {
        goto L1; // [33] 54
    }
    else{
    }

    /** 		SymTab[last_sym][S_NEXT] = new*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_52last_sym_45740 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_45910;
    DeRef(_1);
    _24199 = NOVALUE;
L1: 

    /** 	last_sym = new*/
    _52last_sym_45740 = _new_45910;

    /** 	if type_sym < 0 then*/
    if (_type_sym_45908 >= 0)
    goto L2; // [63] 76

    /** 		register_forward_type( last_sym, type_sym )*/
    _29register_forward_type(_52last_sym_45740, _type_sym_45908);
L2: 

    /** 	return last_sym*/
    DeRefDS(_name_45900);
    return _52last_sym_45740;
    ;
}


int _52tmp_alloc()
{
    int _new_entry_45925 = NOVALUE;
    int _24213 = NOVALUE;
    int _24211 = NOVALUE;
    int _24208 = NOVALUE;
    int _24205 = NOVALUE;
    int _24204 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_entry = repeat( 0, SIZEOF_TEMP_ENTRY )*/
    DeRef(_new_entry_45925);
    _new_entry_45925 = Repeat(0, _12SIZEOF_TEMP_ENTRY_11488);

    /** 	new_entry[S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    *(int *)_2 = 4;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L1; // [23] 132
    }
    else{
    }

    /** 		new_entry[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    *(int *)_2 = 16;

    /** 		new_entry[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    *(int *)_2 = -1073741824;

    /** 		new_entry[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    *(int *)_2 = 1073741823;

    /** 		new_entry[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    *(int *)_2 = _12NOVALUE_11536;

    /** 		new_entry[S_SEQ_ELEM] = TYPE_OBJECT  -- other fields set later*/
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);

    /** 		if length(temp_name_type)+1 = 8087 then*/
    if (IS_SEQUENCE(_12temp_name_type_11765)){
            _24204 = SEQ_PTR(_12temp_name_type_11765)->length;
    }
    else {
        _24204 = 1;
    }
    _24205 = _24204 + 1;
    _24204 = NOVALUE;
    if (_24205 != 8087)
    goto L2; // [87] 106

    /** 			temp_name_type = append(temp_name_type, {0, 0})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = 0;
    _24208 = MAKE_SEQ(_1);
    RefDS(_24208);
    Append(&_12temp_name_type_11765, _12temp_name_type_11765, _24208);
    DeRefDS(_24208);
    _24208 = NOVALUE;
L2: 

    /** 		temp_name_type = append(temp_name_type, TYPES_OBNL)*/
    RefDS(_53TYPES_OBNL_45132);
    Append(&_12temp_name_type_11765, _12temp_name_type_11765, _53TYPES_OBNL_45132);

    /** 		new_entry[S_TEMP_NAME] = length(temp_name_type)*/
    if (IS_SEQUENCE(_12temp_name_type_11765)){
            _24211 = SEQ_PTR(_12temp_name_type_11765)->length;
    }
    else {
        _24211 = 1;
    }
    _2 = (int)SEQ_PTR(_new_entry_45925);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _new_entry_45925 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24211;
    if( _1 != _24211 ){
        DeRef(_1);
    }
    _24211 = NOVALUE;
L1: 

    /** 	SymTab = append(SymTab, new_entry )*/
    RefDS(_new_entry_45925);
    Append(&_13SymTab_10636, _13SymTab_10636, _new_entry_45925);

    /** 	return length( SymTab )*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _24213 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _24213 = 1;
    }
    DeRefDS(_new_entry_45925);
    DeRef(_24205);
    _24205 = NOVALUE;
    return _24213;
    ;
}


void _52DefinedYet(int _sym_45994)
{
    int _24233 = NOVALUE;
    int _24232 = NOVALUE;
    int _24231 = NOVALUE;
    int _24229 = NOVALUE;
    int _24228 = NOVALUE;
    int _24226 = NOVALUE;
    int _24225 = NOVALUE;
    int _24224 = NOVALUE;
    int _24223 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_45994)) {
        _1 = (long)(DBL_PTR(_sym_45994)->dbl);
        DeRefDS(_sym_45994);
        _sym_45994 = _1;
    }

    /** 	if not find(SymTab[sym][S_SCOPE],*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24223 = (int)*(((s1_ptr)_2)->base + _sym_45994);
    _2 = (int)SEQ_PTR(_24223);
    _24224 = (int)*(((s1_ptr)_2)->base + 4);
    _24223 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 9;
    *((int *)(_2+8)) = 10;
    *((int *)(_2+12)) = 7;
    _24225 = MAKE_SEQ(_1);
    _24226 = find_from(_24224, _24225, 1);
    _24224 = NOVALUE;
    DeRefDS(_24225);
    _24225 = NOVALUE;
    if (_24226 != 0)
    goto L1; // [34] 82
    _24226 = NOVALUE;

    /** 		if SymTab[sym][S_FILE_NO] = current_file_no then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24228 = (int)*(((s1_ptr)_2)->base + _sym_45994);
    _2 = (int)SEQ_PTR(_24228);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24229 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24229 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24228 = NOVALUE;
    if (binary_op_a(NOTEQ, _24229, _12current_file_no_11682)){
        _24229 = NOVALUE;
        goto L2; // [53] 81
    }
    _24229 = NOVALUE;

    /** 			CompileErr(31, {SymTab[sym][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24231 = (int)*(((s1_ptr)_2)->base + _sym_45994);
    _2 = (int)SEQ_PTR(_24231);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24232 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24232 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24231 = NOVALUE;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_24232);
    *((int *)(_2+4)) = _24232;
    _24233 = MAKE_SEQ(_1);
    _24232 = NOVALUE;
    _43CompileErr(31, _24233, 0);
    _24233 = NOVALUE;
L2: 
L1: 

    /** end procedure*/
    return;
    ;
}


int _52name_ext(int _s_46021)
{
    int _24240 = NOVALUE;
    int _24239 = NOVALUE;
    int _24238 = NOVALUE;
    int _24237 = NOVALUE;
    int _24235 = NOVALUE;
    int _24234 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(s) to 1 by -1 do*/
    if (IS_SEQUENCE(_s_46021)){
            _24234 = SEQ_PTR(_s_46021)->length;
    }
    else {
        _24234 = 1;
    }
    {
        int _i_46023;
        _i_46023 = _24234;
L1: 
        if (_i_46023 < 1){
            goto L2; // [8] 55
        }

        /** 		if find(s[i], "/\\:") then*/
        _2 = (int)SEQ_PTR(_s_46021);
        _24235 = (int)*(((s1_ptr)_2)->base + _i_46023);
        _24237 = find_from(_24235, _24236, 1);
        _24235 = NOVALUE;
        if (_24237 == 0)
        {
            _24237 = NOVALUE;
            goto L3; // [26] 48
        }
        else{
            _24237 = NOVALUE;
        }

        /** 			return s[i+1 .. $]*/
        _24238 = _i_46023 + 1;
        if (IS_SEQUENCE(_s_46021)){
                _24239 = SEQ_PTR(_s_46021)->length;
        }
        else {
            _24239 = 1;
        }
        rhs_slice_target = (object_ptr)&_24240;
        RHS_Slice(_s_46021, _24238, _24239);
        DeRefDS(_s_46021);
        _24238 = NOVALUE;
        return _24240;
L3: 

        /** 	end for*/
        _i_46023 = _i_46023 + -1;
        goto L1; // [50] 15
L2: 
        ;
    }

    /** 	return s*/
    DeRef(_24238);
    _24238 = NOVALUE;
    DeRef(_24240);
    _24240 = NOVALUE;
    return _s_46021;
    ;
}


int _52NewStringSym(int _s_46040)
{
    int _p_46042 = NOVALUE;
    int _tp_46043 = NOVALUE;
    int _prev_46044 = NOVALUE;
    int _search_count_46045 = NOVALUE;
    int _24284 = NOVALUE;
    int _24282 = NOVALUE;
    int _24281 = NOVALUE;
    int _24280 = NOVALUE;
    int _24278 = NOVALUE;
    int _24277 = NOVALUE;
    int _24274 = NOVALUE;
    int _24272 = NOVALUE;
    int _24270 = NOVALUE;
    int _24269 = NOVALUE;
    int _24268 = NOVALUE;
    int _24266 = NOVALUE;
    int _24264 = NOVALUE;
    int _24262 = NOVALUE;
    int _24260 = NOVALUE;
    int _24257 = NOVALUE;
    int _24255 = NOVALUE;
    int _24254 = NOVALUE;
    int _24253 = NOVALUE;
    int _24251 = NOVALUE;
    int _24249 = NOVALUE;
    int _24248 = NOVALUE;
    int _24247 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46043 = _52literal_init_45739;

    /** 	prev = 0*/
    _prev_46044 = 0;

    /** 	search_count = 0*/
    _search_count_46045 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46043 == 0)
    goto L2; // [31] 170

    /** 		search_count += 1*/
    _search_count_46045 = _search_count_46045 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46045, _52SEARCH_LIMIT_46032)){
        goto L3; // [45] 54
    }

    /** 			exit*/
    goto L2; // [51] 170
L3: 

    /** 		if equal(s, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24247 = (int)*(((s1_ptr)_2)->base + _tp_46043);
    _2 = (int)SEQ_PTR(_24247);
    _24248 = (int)*(((s1_ptr)_2)->base + 1);
    _24247 = NOVALUE;
    if (_s_46040 == _24248)
    _24249 = 1;
    else if (IS_ATOM_INT(_s_46040) && IS_ATOM_INT(_24248))
    _24249 = 0;
    else
    _24249 = (compare(_s_46040, _24248) == 0);
    _24248 = NOVALUE;
    if (_24249 == 0)
    {
        _24249 = NOVALUE;
        goto L4; // [72] 142
    }
    else{
        _24249 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46043 == _52literal_init_45739)
    goto L5; // [79] 135

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46044 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24253 = (int)*(((s1_ptr)_2)->base + _tp_46043);
    _2 = (int)SEQ_PTR(_24253);
    _24254 = (int)*(((s1_ptr)_2)->base + 2);
    _24253 = NOVALUE;
    Ref(_24254);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24254;
    if( _1 != _24254 ){
        DeRef(_1);
    }
    _24254 = NOVALUE;
    _24251 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46043 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_45739;
    DeRef(_1);
    _24255 = NOVALUE;

    /** 				literal_init = tp*/
    _52literal_init_45739 = _tp_46043;
L5: 

    /** 			return tp*/
    DeRefDS(_s_46040);
    return _tp_46043;
L4: 

    /** 		prev = tp*/
    _prev_46044 = _tp_46043;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24257 = (int)*(((s1_ptr)_2)->base + _tp_46043);
    _2 = (int)SEQ_PTR(_24257);
    _tp_46043 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46043)){
        _tp_46043 = (long)DBL_PTR(_tp_46043)->dbl;
    }
    _24257 = NOVALUE;

    /** 	end while*/
    goto L1; // [167] 31
L2: 

    /** 	p = tmp_alloc()*/
    _p_46042 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46042)) {
        _1 = (long)(DBL_PTR(_p_46042)->dbl);
        DeRefDS(_p_46042);
        _p_46042 = _1;
    }

    /** 	SymTab[p][S_OBJ] = s*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    RefDS(_s_46040);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_46040;
    DeRef(_1);
    _24260 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [196] 346
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP    -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24262 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_SEQUENCE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 8;
    DeRef(_1);
    _24264 = NOVALUE;

    /** 		SymTab[p][S_SEQ_LEN] = length(s)*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    if (IS_SEQUENCE(_s_46040)){
            _24268 = SEQ_PTR(_s_46040)->length;
    }
    else {
        _24268 = 1;
    }
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _24268;
    if( _1 != _24268 ){
        DeRef(_1);
    }
    _24268 = NOVALUE;
    _24266 = NOVALUE;

    /** 		if SymTab[p][S_SEQ_LEN] > 0 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24269 = (int)*(((s1_ptr)_2)->base + _p_46042);
    _2 = (int)SEQ_PTR(_24269);
    _24270 = (int)*(((s1_ptr)_2)->base + 32);
    _24269 = NOVALUE;
    if (binary_op_a(LESSEQ, _24270, 0)){
        _24270 = NOVALUE;
        goto L7; // [265] 289
    }
    _24270 = NOVALUE;

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24272 = NOVALUE;
    goto L8; // [286] 307
L7: 

    /** 			SymTab[p][S_SEQ_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24274 = NOVALUE;
L8: 

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24277 = (int)*(((s1_ptr)_2)->base + _p_46042);
    _2 = (int)SEQ_PTR(_24277);
    _24278 = (int)*(((s1_ptr)_2)->base + 34);
    _24277 = NOVALUE;
    RefDS(_24276);
    Ref(_24278);
    _53c_printf(_24276, _24278);
    _24278 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24280 = (int)*(((s1_ptr)_2)->base + _p_46042);
    _2 = (int)SEQ_PTR(_24280);
    _24281 = (int)*(((s1_ptr)_2)->base + 34);
    _24280 = NOVALUE;
    RefDS(_24279);
    Ref(_24281);
    _53c_hprintf(_24279, _24281);
    _24281 = NOVALUE;
    goto L9; // [343] 364
L6: 

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24282 = NOVALUE;
L9: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46042 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_45739;
    DeRef(_1);
    _24284 = NOVALUE;

    /** 	literal_init = p*/
    _52literal_init_45739 = _p_46042;

    /** 	return p*/
    DeRefDS(_s_46040);
    return _p_46042;
    ;
}


int _52NewIntSym(int _int_val_46138)
{
    int _p_46140 = NOVALUE;
    int _x_46141 = NOVALUE;
    int _24303 = NOVALUE;
    int _24301 = NOVALUE;
    int _24297 = NOVALUE;
    int _24295 = NOVALUE;
    int _24293 = NOVALUE;
    int _24291 = NOVALUE;
    int _24289 = NOVALUE;
    int _24287 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_int_val_46138)) {
        _1 = (long)(DBL_PTR(_int_val_46138)->dbl);
        DeRefDS(_int_val_46138);
        _int_val_46138 = _1;
    }

    /** 	integer x*/

    /** 	x = find(int_val, lastintval)*/
    _x_46141 = find_from(_int_val_46138, _52lastintval_45741, 1);

    /** 	if x then*/
    if (_x_46141 == 0)
    {
        goto L1; // [16] 34
    }
    else{
    }

    /** 		return lastintsym[x]  -- saves space, helps Translator reduce code size*/
    _2 = (int)SEQ_PTR(_52lastintsym_45742);
    _24287 = (int)*(((s1_ptr)_2)->base + _x_46141);
    return _24287;
    goto L2; // [31] 180
L1: 

    /** 		p = tmp_alloc()*/
    _p_46140 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46140)) {
        _1 = (long)(DBL_PTR(_p_46140)->dbl);
        DeRefDS(_p_46140);
        _p_46140 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24289 = NOVALUE;

    /** 		SymTab[p][S_OBJ] = int_val*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46138;
    DeRef(_1);
    _24291 = NOVALUE;

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L3; // [77] 128
    }
    else{
    }

    /** 			SymTab[p][S_OBJ_MIN] = int_val*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46138;
    DeRef(_1);
    _24293 = NOVALUE;

    /** 			SymTab[p][S_OBJ_MAX] = int_val*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _int_val_46138;
    DeRef(_1);
    _24295 = NOVALUE;

    /** 			SymTab[p][S_GTYPE] = TYPE_INTEGER*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46140 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24297 = NOVALUE;
L3: 

    /** 		lastintval = prepend(lastintval, int_val)*/
    Prepend(&_52lastintval_45741, _52lastintval_45741, _int_val_46138);

    /** 		lastintsym = prepend(lastintsym, p)*/
    Prepend(&_52lastintsym_45742, _52lastintsym_45742, _p_46140);

    /** 		if length(lastintval) > SEARCH_LIMIT then*/
    if (IS_SEQUENCE(_52lastintval_45741)){
            _24301 = SEQ_PTR(_52lastintval_45741)->length;
    }
    else {
        _24301 = 1;
    }
    if (binary_op_a(LESSEQ, _24301, _52SEARCH_LIMIT_46032)){
        _24301 = NOVALUE;
        goto L4; // [153] 173
    }
    _24301 = NOVALUE;

    /** 			lastintval = lastintval[1..floor(SEARCH_LIMIT/2)]*/
    if (IS_ATOM_INT(_52SEARCH_LIMIT_46032)) {
        _24303 = _52SEARCH_LIMIT_46032 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _52SEARCH_LIMIT_46032, 2);
        _24303 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    rhs_slice_target = (object_ptr)&_52lastintval_45741;
    RHS_Slice(_52lastintval_45741, 1, _24303);
L4: 

    /** 		return p*/
    _24287 = NOVALUE;
    DeRef(_24303);
    _24303 = NOVALUE;
    return _p_46140;
L2: 
    ;
}


int _52NewDoubleSym(int _d_46180)
{
    int _p_46182 = NOVALUE;
    int _tp_46183 = NOVALUE;
    int _prev_46184 = NOVALUE;
    int _search_count_46185 = NOVALUE;
    int _24333 = NOVALUE;
    int _24332 = NOVALUE;
    int _24331 = NOVALUE;
    int _24330 = NOVALUE;
    int _24329 = NOVALUE;
    int _24327 = NOVALUE;
    int _24325 = NOVALUE;
    int _24323 = NOVALUE;
    int _24321 = NOVALUE;
    int _24318 = NOVALUE;
    int _24316 = NOVALUE;
    int _24315 = NOVALUE;
    int _24314 = NOVALUE;
    int _24312 = NOVALUE;
    int _24310 = NOVALUE;
    int _24309 = NOVALUE;
    int _24308 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer search_count*/

    /** 	tp = literal_init*/
    _tp_46183 = _52literal_init_45739;

    /** 	prev = 0*/
    _prev_46184 = 0;

    /** 	search_count = 0*/
    _search_count_46185 = 0;

    /** 	while tp != 0 do*/
L1: 
    if (_tp_46183 == 0)
    goto L2; // [29] 168

    /** 		search_count += 1*/
    _search_count_46185 = _search_count_46185 + 1;

    /** 		if search_count > SEARCH_LIMIT then  -- avoid n-squared algorithm*/
    if (binary_op_a(LESSEQ, _search_count_46185, _52SEARCH_LIMIT_46032)){
        goto L3; // [43] 52
    }

    /** 			exit*/
    goto L2; // [49] 168
L3: 

    /** 		if equal(d, SymTab[tp][S_OBJ]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24308 = (int)*(((s1_ptr)_2)->base + _tp_46183);
    _2 = (int)SEQ_PTR(_24308);
    _24309 = (int)*(((s1_ptr)_2)->base + 1);
    _24308 = NOVALUE;
    if (_d_46180 == _24309)
    _24310 = 1;
    else if (IS_ATOM_INT(_d_46180) && IS_ATOM_INT(_24309))
    _24310 = 0;
    else
    _24310 = (compare(_d_46180, _24309) == 0);
    _24309 = NOVALUE;
    if (_24310 == 0)
    {
        _24310 = NOVALUE;
        goto L4; // [70] 140
    }
    else{
        _24310 = NOVALUE;
    }

    /** 			if tp != literal_init then*/
    if (_tp_46183 == _52literal_init_45739)
    goto L5; // [77] 133

    /** 				SymTab[prev][S_NEXT] = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_46184 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24314 = (int)*(((s1_ptr)_2)->base + _tp_46183);
    _2 = (int)SEQ_PTR(_24314);
    _24315 = (int)*(((s1_ptr)_2)->base + 2);
    _24314 = NOVALUE;
    Ref(_24315);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24315;
    if( _1 != _24315 ){
        DeRef(_1);
    }
    _24315 = NOVALUE;
    _24312 = NOVALUE;

    /** 				SymTab[tp][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_tp_46183 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_45739;
    DeRef(_1);
    _24316 = NOVALUE;

    /** 				literal_init = tp*/
    _52literal_init_45739 = _tp_46183;
L5: 

    /** 			return tp*/
    DeRef(_d_46180);
    return _tp_46183;
L4: 

    /** 		prev = tp*/
    _prev_46184 = _tp_46183;

    /** 		tp = SymTab[tp][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24318 = (int)*(((s1_ptr)_2)->base + _tp_46183);
    _2 = (int)SEQ_PTR(_24318);
    _tp_46183 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_tp_46183)){
        _tp_46183 = (long)DBL_PTR(_tp_46183)->dbl;
    }
    _24318 = NOVALUE;

    /** 	end while*/
    goto L1; // [165] 29
L2: 

    /** 	p = tmp_alloc()*/
    _p_46182 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46182)) {
        _1 = (long)(DBL_PTR(_p_46182)->dbl);
        DeRefDS(_p_46182);
        _p_46182 = _1;
    }

    /** 	SymTab[p][S_MODE] = M_CONSTANT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46182 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24321 = NOVALUE;

    /** 	SymTab[p][S_OBJ] = d*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46182 + ((s1_ptr)_2)->base);
    Ref(_d_46180);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _d_46180;
    DeRef(_1);
    _24323 = NOVALUE;

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [211] 285
    }
    else{
    }

    /** 		SymTab[p][S_MODE] = M_TEMP  -- override CONSTANT for compile*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46182 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24325 = NOVALUE;

    /** 		SymTab[p][S_GTYPE] = TYPE_DOUBLE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46182 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24327 = NOVALUE;

    /** 		c_printf("int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24329 = (int)*(((s1_ptr)_2)->base + _p_46182);
    _2 = (int)SEQ_PTR(_24329);
    _24330 = (int)*(((s1_ptr)_2)->base + 34);
    _24329 = NOVALUE;
    RefDS(_24276);
    Ref(_24330);
    _53c_printf(_24276, _24330);
    _24330 = NOVALUE;

    /** 		c_hprintf("extern int _%d;\n", SymTab[p][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24331 = (int)*(((s1_ptr)_2)->base + _p_46182);
    _2 = (int)SEQ_PTR(_24331);
    _24332 = (int)*(((s1_ptr)_2)->base + 34);
    _24331 = NOVALUE;
    RefDS(_24279);
    Ref(_24332);
    _53c_hprintf(_24279, _24332);
    _24332 = NOVALUE;
L6: 

    /** 	SymTab[p][S_NEXT] = literal_init*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46182 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _52literal_init_45739;
    DeRef(_1);
    _24333 = NOVALUE;

    /** 	literal_init = p*/
    _52literal_init_45739 = _p_46182;

    /** 	return p*/
    DeRef(_d_46180);
    return _p_46182;
    ;
}


int _52NewTempSym(int _inlining_46254)
{
    int _p_46256 = NOVALUE;
    int _q_46257 = NOVALUE;
    int _24382 = NOVALUE;
    int _24380 = NOVALUE;
    int _24378 = NOVALUE;
    int _24376 = NOVALUE;
    int _24374 = NOVALUE;
    int _24372 = NOVALUE;
    int _24371 = NOVALUE;
    int _24370 = NOVALUE;
    int _24368 = NOVALUE;
    int _24367 = NOVALUE;
    int _24366 = NOVALUE;
    int _24364 = NOVALUE;
    int _24362 = NOVALUE;
    int _24359 = NOVALUE;
    int _24358 = NOVALUE;
    int _24357 = NOVALUE;
    int _24355 = NOVALUE;
    int _24353 = NOVALUE;
    int _24352 = NOVALUE;
    int _24351 = NOVALUE;
    int _24349 = NOVALUE;
    int _24347 = NOVALUE;
    int _24342 = NOVALUE;
    int _24341 = NOVALUE;
    int _24340 = NOVALUE;
    int _24339 = NOVALUE;
    int _24338 = NOVALUE;
    int _24337 = NOVALUE;
    int _24335 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_inlining_46254)) {
        _1 = (long)(DBL_PTR(_inlining_46254)->dbl);
        DeRefDS(_inlining_46254);
        _inlining_46254 = _1;
    }

    /** 	if inlining then*/
    if (_inlining_46254 == 0)
    {
        goto L1; // [5] 85
    }
    else{
    }

    /** 		p = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24335 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24335);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _p_46256 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _p_46256 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_p_46256)){
        _p_46256 = (long)DBL_PTR(_p_46256)->dbl;
    }
    _24335 = NOVALUE;

    /** 		while p != 0 and SymTab[p][S_SCOPE] != FREE do*/
L2: 
    _24337 = (_p_46256 != 0);
    if (_24337 == 0) {
        goto L3; // [35] 93
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24339 = (int)*(((s1_ptr)_2)->base + _p_46256);
    _2 = (int)SEQ_PTR(_24339);
    _24340 = (int)*(((s1_ptr)_2)->base + 4);
    _24339 = NOVALUE;
    if (IS_ATOM_INT(_24340)) {
        _24341 = (_24340 != 0);
    }
    else {
        _24341 = binary_op(NOTEQ, _24340, 0);
    }
    _24340 = NOVALUE;
    if (_24341 <= 0) {
        if (_24341 == 0) {
            DeRef(_24341);
            _24341 = NOVALUE;
            goto L3; // [58] 93
        }
        else {
            if (!IS_ATOM_INT(_24341) && DBL_PTR(_24341)->dbl == 0.0){
                DeRef(_24341);
                _24341 = NOVALUE;
                goto L3; // [58] 93
            }
            DeRef(_24341);
            _24341 = NOVALUE;
        }
    }
    DeRef(_24341);
    _24341 = NOVALUE;

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24342 = (int)*(((s1_ptr)_2)->base + _p_46256);
    _2 = (int)SEQ_PTR(_24342);
    _p_46256 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46256)){
        _p_46256 = (long)DBL_PTR(_p_46256)->dbl;
    }
    _24342 = NOVALUE;

    /** 		end while*/
    goto L2; // [79] 31
    goto L3; // [82] 93
L1: 

    /** 		p = 0*/
    _p_46256 = 0;
L3: 

    /** 	if p = 0 then*/
    if (_p_46256 != 0)
    goto L4; // [97] 213

    /** 		temps_allocated += 1*/
    _52temps_allocated_46251 = _52temps_allocated_46251 + 1;

    /** 		p = tmp_alloc()*/
    _p_46256 = _52tmp_alloc();
    if (!IS_ATOM_INT(_p_46256)) {
        _1 = (long)(DBL_PTR(_p_46256)->dbl);
        DeRefDS(_p_46256);
        _p_46256 = _1;
    }

    /** 		SymTab[p][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24347 = NOVALUE;

    /** 		SymTab[p][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24351 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24351);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _24352 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _24352 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    _24351 = NOVALUE;
    Ref(_24352);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24352;
    if( _1 != _24352 ){
        DeRef(_1);
    }
    _24352 = NOVALUE;
    _24349 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = p*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_11399))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    _1 = *(int *)_2;
    *(int *)_2 = _p_46256;
    DeRef(_1);
    _24353 = NOVALUE;

    /** 		if inlining then*/
    if (_inlining_46254 == 0)
    {
        goto L5; // [181] 343
    }
    else{
    }

    /** 			SymTab[CurrentSub][S_STACK_SPACE] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414)){
        _24357 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    }
    else{
        _24357 = (int)*(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    }
    _24355 = NOVALUE;
    if (IS_ATOM_INT(_24357)) {
        _24358 = _24357 + 1;
        if (_24358 > MAXINT){
            _24358 = NewDouble((double)_24358);
        }
    }
    else
    _24358 = binary_op(PLUS, 1, _24357);
    _24357 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_STACK_SPACE_11414))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_STACK_SPACE_11414)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_STACK_SPACE_11414);
    _1 = *(int *)_2;
    *(int *)_2 = _24358;
    if( _1 != _24358 ){
        DeRef(_1);
    }
    _24358 = NOVALUE;
    _24355 = NOVALUE;
    goto L5; // [210] 343
L4: 

    /** 	elsif TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L6; // [217] 342
    }
    else{
    }

    /** 		SymTab[p][S_SCOPE] = DELETED*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _24359 = NOVALUE;

    /** 		q = tmp_alloc()*/
    _q_46257 = _52tmp_alloc();
    if (!IS_ATOM_INT(_q_46257)) {
        _1 = (long)(DBL_PTR(_q_46257)->dbl);
        DeRefDS(_q_46257);
        _q_46257 = _1;
    }

    /** 		SymTab[q][S_MODE] = M_TEMP*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46257 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 3;
    DeRef(_1);
    _24362 = NOVALUE;

    /** 		SymTab[q][S_TEMP_NAME] = SymTab[p][S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46257 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24366 = (int)*(((s1_ptr)_2)->base + _p_46256);
    _2 = (int)SEQ_PTR(_24366);
    _24367 = (int)*(((s1_ptr)_2)->base + 34);
    _24366 = NOVALUE;
    Ref(_24367);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 34);
    _1 = *(int *)_2;
    *(int *)_2 = _24367;
    if( _1 != _24367 ){
        DeRef(_1);
    }
    _24367 = NOVALUE;
    _24364 = NOVALUE;

    /** 		SymTab[q][S_NEXT] = SymTab[CurrentSub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_q_46257 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24370 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24370);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _24371 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _24371 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    _24370 = NOVALUE;
    Ref(_24371);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _24371;
    if( _1 != _24371 ){
        DeRef(_1);
    }
    _24371 = NOVALUE;
    _24368 = NOVALUE;

    /** 		SymTab[CurrentSub][S_TEMPS] = q*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_TEMPS_11399))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    _1 = *(int *)_2;
    *(int *)_2 = _q_46257;
    DeRef(_1);
    _24372 = NOVALUE;

    /** 		p = q*/
    _p_46256 = _q_46257;
L6: 
L5: 

    /** 	if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L7; // [347] 385
    }
    else{
    }

    /** 		SymTab[p][S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24374 = NOVALUE;

    /** 		SymTab[p][S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    _24376 = NOVALUE;
L7: 

    /** 	SymTab[p][S_OBJ] = NOVALUE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    _24378 = NOVALUE;

    /** 	SymTab[p][S_USAGE] = T_UNKNOWN*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 4;
    DeRef(_1);
    _24380 = NOVALUE;

    /** 	SymTab[p][S_SCOPE] = IN_USE*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46256 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = 1;
    DeRef(_1);
    _24382 = NOVALUE;

    /** 	return p*/
    DeRef(_24337);
    _24337 = NOVALUE;
    return _p_46256;
    ;
}


void _52InitSymTab()
{
    int _hashval_46373 = NOVALUE;
    int _len_46374 = NOVALUE;
    int _s_46376 = NOVALUE;
    int _st_index_46377 = NOVALUE;
    int _kname_46378 = NOVALUE;
    int _fixups_46379 = NOVALUE;
    int _si_46519 = NOVALUE;
    int _sj_46520 = NOVALUE;
    int _24966 = NOVALUE;
    int _24965 = NOVALUE;
    int _24498 = NOVALUE;
    int _24497 = NOVALUE;
    int _24496 = NOVALUE;
    int _24495 = NOVALUE;
    int _24494 = NOVALUE;
    int _24492 = NOVALUE;
    int _24491 = NOVALUE;
    int _24490 = NOVALUE;
    int _24489 = NOVALUE;
    int _24487 = NOVALUE;
    int _24485 = NOVALUE;
    int _24483 = NOVALUE;
    int _24482 = NOVALUE;
    int _24480 = NOVALUE;
    int _24478 = NOVALUE;
    int _24476 = NOVALUE;
    int _24475 = NOVALUE;
    int _24473 = NOVALUE;
    int _24472 = NOVALUE;
    int _24471 = NOVALUE;
    int _24470 = NOVALUE;
    int _24469 = NOVALUE;
    int _24466 = NOVALUE;
    int _24465 = NOVALUE;
    int _24464 = NOVALUE;
    int _24462 = NOVALUE;
    int _24461 = NOVALUE;
    int _24460 = NOVALUE;
    int _24458 = NOVALUE;
    int _24457 = NOVALUE;
    int _24456 = NOVALUE;
    int _24453 = NOVALUE;
    int _24451 = NOVALUE;
    int _24449 = NOVALUE;
    int _24448 = NOVALUE;
    int _24445 = NOVALUE;
    int _24444 = NOVALUE;
    int _24442 = NOVALUE;
    int _24440 = NOVALUE;
    int _24438 = NOVALUE;
    int _24435 = NOVALUE;
    int _24434 = NOVALUE;
    int _24433 = NOVALUE;
    int _24430 = NOVALUE;
    int _24429 = NOVALUE;
    int _24427 = NOVALUE;
    int _24426 = NOVALUE;
    int _24424 = NOVALUE;
    int _24423 = NOVALUE;
    int _24422 = NOVALUE;
    int _24420 = NOVALUE;
    int _24418 = NOVALUE;
    int _24417 = NOVALUE;
    int _24415 = NOVALUE;
    int _24414 = NOVALUE;
    int _24413 = NOVALUE;
    int _24411 = NOVALUE;
    int _24410 = NOVALUE;
    int _24409 = NOVALUE;
    int _24407 = NOVALUE;
    int _24406 = NOVALUE;
    int _24405 = NOVALUE;
    int _24403 = NOVALUE;
    int _24402 = NOVALUE;
    int _24401 = NOVALUE;
    int _24400 = NOVALUE;
    int _24399 = NOVALUE;
    int _24398 = NOVALUE;
    int _24397 = NOVALUE;
    int _24396 = NOVALUE;
    int _24395 = NOVALUE;
    int _24394 = NOVALUE;
    int _24392 = NOVALUE;
    int _24391 = NOVALUE;
    int _24390 = NOVALUE;
    int _24389 = NOVALUE;
    int _24385 = NOVALUE;
    int _24384 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence kname, fixups = {}*/
    RefDS(_21829);
    DeRefi(_fixups_46379);
    _fixups_46379 = _21829;

    /** 	for k = 1 to length(keylist) do*/
    if (IS_SEQUENCE(_62keylist_22497)){
            _24384 = SEQ_PTR(_62keylist_22497)->length;
    }
    else {
        _24384 = 1;
    }
    {
        int _k_46381;
        _k_46381 = 1;
L1: 
        if (_k_46381 > _24384){
            goto L2; // [15] 560
        }

        /** 		kname = keylist[k][K_NAME]*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24385 = (int)*(((s1_ptr)_2)->base + _k_46381);
        DeRef(_kname_46378);
        _2 = (int)SEQ_PTR(_24385);
        _kname_46378 = (int)*(((s1_ptr)_2)->base + 1);
        Ref(_kname_46378);
        _24385 = NOVALUE;

        /** 		len = length(kname)*/
        if (IS_SEQUENCE(_kname_46378)){
                _len_46374 = SEQ_PTR(_kname_46378)->length;
        }
        else {
            _len_46374 = 1;
        }

        /** 		hashval = hashfn(kname)*/
        RefDS(_kname_46378);
        _hashval_46373 = _52hashfn(_kname_46378);
        if (!IS_ATOM_INT(_hashval_46373)) {
            _1 = (long)(DBL_PTR(_hashval_46373)->dbl);
            DeRefDS(_hashval_46373);
            _hashval_46373 = _1;
        }

        /** 		st_index = NewEntry(kname,*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24389 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24389);
        _24390 = (int)*(((s1_ptr)_2)->base + 2);
        _24389 = NOVALUE;
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24391 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24391);
        _24392 = (int)*(((s1_ptr)_2)->base + 3);
        _24391 = NOVALUE;
        RefDS(_kname_46378);
        Ref(_24390);
        Ref(_24392);
        _st_index_46377 = _52NewEntry(_kname_46378, 0, _24390, _24392, _hashval_46373, 0, 0);
        _24390 = NOVALUE;
        _24392 = NOVALUE;
        if (!IS_ATOM_INT(_st_index_46377)) {
            _1 = (long)(DBL_PTR(_st_index_46377)->dbl);
            DeRefDS(_st_index_46377);
            _st_index_46377 = _1;
        }

        /** 		if find(keylist[k][K_TOKEN], RTN_TOKS) then*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24394 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24394);
        _24395 = (int)*(((s1_ptr)_2)->base + 3);
        _24394 = NOVALUE;
        _24396 = find_from(_24395, _28RTN_TOKS_11302, 1);
        _24395 = NOVALUE;
        if (_24396 == 0)
        {
            _24396 = NOVALUE;
            goto L3; // [110] 325
        }
        else{
            _24396 = NOVALUE;
        }

        /** 			SymTab[st_index] = SymTab[st_index] &*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24397 = (int)*(((s1_ptr)_2)->base + _st_index_46377);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24398 = (int)*(((s1_ptr)_2)->base + _st_index_46377);
        if (IS_SEQUENCE(_24398)){
                _24399 = SEQ_PTR(_24398)->length;
        }
        else {
            _24399 = 1;
        }
        _24398 = NOVALUE;
        _24400 = _12SIZEOF_ROUTINE_ENTRY_11479 - _24399;
        _24399 = NOVALUE;
        _24401 = Repeat(0, _24400);
        _24400 = NOVALUE;
        if (IS_SEQUENCE(_24397) && IS_ATOM(_24401)) {
        }
        else if (IS_ATOM(_24397) && IS_SEQUENCE(_24401)) {
            Ref(_24397);
            Prepend(&_24402, _24401, _24397);
        }
        else {
            Concat((object_ptr)&_24402, _24397, _24401);
            _24397 = NOVALUE;
        }
        _24397 = NOVALUE;
        DeRefDS(_24401);
        _24401 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _st_index_46377);
        _1 = *(int *)_2;
        *(int *)_2 = _24402;
        if( _1 != _24402 ){
            DeRef(_1);
        }
        _24402 = NOVALUE;

        /** 			SymTab[st_index][S_NUM_ARGS] = keylist[k][K_NUM_ARGS]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24405 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24405);
        _24406 = (int)*(((s1_ptr)_2)->base + 5);
        _24405 = NOVALUE;
        Ref(_24406);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_NUM_ARGS_11405))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
        _1 = *(int *)_2;
        *(int *)_2 = _24406;
        if( _1 != _24406 ){
            DeRef(_1);
        }
        _24406 = NOVALUE;
        _24403 = NOVALUE;

        /** 			SymTab[st_index][S_OPCODE] = keylist[k][K_OPCODE]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24409 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24409);
        _24410 = (int)*(((s1_ptr)_2)->base + 4);
        _24409 = NOVALUE;
        Ref(_24410);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 21);
        _1 = *(int *)_2;
        *(int *)_2 = _24410;
        if( _1 != _24410 ){
            DeRef(_1);
        }
        _24410 = NOVALUE;
        _24407 = NOVALUE;

        /** 			SymTab[st_index][S_EFFECT] = keylist[k][K_EFFECT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24413 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24413);
        _24414 = (int)*(((s1_ptr)_2)->base + 6);
        _24413 = NOVALUE;
        Ref(_24414);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 23);
        _1 = *(int *)_2;
        *(int *)_2 = _24414;
        if( _1 != _24414 ){
            DeRef(_1);
        }
        _24414 = NOVALUE;
        _24411 = NOVALUE;

        /** 			SymTab[st_index][S_REFLIST] = {}*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        RefDS(_21829);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 24);
        _1 = *(int *)_2;
        *(int *)_2 = _21829;
        DeRef(_1);
        _24415 = NOVALUE;

        /** 			if length(keylist[k]) > K_EFFECT then*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24417 = (int)*(((s1_ptr)_2)->base + _k_46381);
        if (IS_SEQUENCE(_24417)){
                _24418 = SEQ_PTR(_24417)->length;
        }
        else {
            _24418 = 1;
        }
        _24417 = NOVALUE;
        if (_24418 <= 6)
        goto L4; // [259] 324

        /** 			    SymTab[st_index][S_CODE] = keylist[k][K_CODE]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24422 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24422);
        _24423 = (int)*(((s1_ptr)_2)->base + 7);
        _24422 = NOVALUE;
        Ref(_24423);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_11366))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
        _1 = *(int *)_2;
        *(int *)_2 = _24423;
        if( _1 != _24423 ){
            DeRef(_1);
        }
        _24423 = NOVALUE;
        _24420 = NOVALUE;

        /** 			    SymTab[st_index][S_DEF_ARGS] = keylist[k][K_DEF_ARGS]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24426 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24426);
        _24427 = (int)*(((s1_ptr)_2)->base + 8);
        _24426 = NOVALUE;
        Ref(_24427);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 28);
        _1 = *(int *)_2;
        *(int *)_2 = _24427;
        if( _1 != _24427 ){
            DeRef(_1);
        }
        _24427 = NOVALUE;
        _24424 = NOVALUE;

        /** 			    fixups &= st_index*/
        Append(&_fixups_46379, _fixups_46379, _st_index_46377);
L4: 
L3: 

        /** 		if keylist[k][K_TOKEN] = PROC then*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24429 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24429);
        _24430 = (int)*(((s1_ptr)_2)->base + 3);
        _24429 = NOVALUE;
        if (binary_op_a(NOTEQ, _24430, 27)){
            _24430 = NOVALUE;
            goto L5; // [341] 365
        }
        _24430 = NOVALUE;

        /** 			if equal(kname, "<TopLevel>") then*/
        if (_kname_46378 == _24432)
        _24433 = 1;
        else if (IS_ATOM_INT(_kname_46378) && IS_ATOM_INT(_24432))
        _24433 = 0;
        else
        _24433 = (compare(_kname_46378, _24432) == 0);
        if (_24433 == 0)
        {
            _24433 = NOVALUE;
            goto L6; // [351] 462
        }
        else{
            _24433 = NOVALUE;
        }

        /** 				TopLevelSub = st_index*/
        _12TopLevelSub_11689 = _st_index_46377;
        goto L6; // [362] 462
L5: 

        /** 		elsif keylist[k][K_TOKEN] = TYPE then*/
        _2 = (int)SEQ_PTR(_62keylist_22497);
        _24434 = (int)*(((s1_ptr)_2)->base + _k_46381);
        _2 = (int)SEQ_PTR(_24434);
        _24435 = (int)*(((s1_ptr)_2)->base + 3);
        _24434 = NOVALUE;
        if (binary_op_a(NOTEQ, _24435, 504)){
            _24435 = NOVALUE;
            goto L7; // [381] 461
        }
        _24435 = NOVALUE;

        /** 			if equal(kname, "object") then*/
        if (_kname_46378 == _24437)
        _24438 = 1;
        else if (IS_ATOM_INT(_kname_46378) && IS_ATOM_INT(_24437))
        _24438 = 0;
        else
        _24438 = (compare(_kname_46378, _24437) == 0);
        if (_24438 == 0)
        {
            _24438 = NOVALUE;
            goto L8; // [391] 404
        }
        else{
            _24438 = NOVALUE;
        }

        /** 				object_type = st_index*/
        _52object_type_45731 = _st_index_46377;
        goto L9; // [401] 460
L8: 

        /** 			elsif equal(kname, "atom") then*/
        if (_kname_46378 == _24439)
        _24440 = 1;
        else if (IS_ATOM_INT(_kname_46378) && IS_ATOM_INT(_24439))
        _24440 = 0;
        else
        _24440 = (compare(_kname_46378, _24439) == 0);
        if (_24440 == 0)
        {
            _24440 = NOVALUE;
            goto LA; // [410] 423
        }
        else{
            _24440 = NOVALUE;
        }

        /** 				atom_type = st_index*/
        _52atom_type_45733 = _st_index_46377;
        goto L9; // [420] 460
LA: 

        /** 			elsif equal(kname, "integer") then*/
        if (_kname_46378 == _24441)
        _24442 = 1;
        else if (IS_ATOM_INT(_kname_46378) && IS_ATOM_INT(_24441))
        _24442 = 0;
        else
        _24442 = (compare(_kname_46378, _24441) == 0);
        if (_24442 == 0)
        {
            _24442 = NOVALUE;
            goto LB; // [429] 442
        }
        else{
            _24442 = NOVALUE;
        }

        /** 				integer_type = st_index*/
        _52integer_type_45737 = _st_index_46377;
        goto L9; // [439] 460
LB: 

        /** 			elsif equal(kname, "sequence") then*/
        if (_kname_46378 == _24443)
        _24444 = 1;
        else if (IS_ATOM_INT(_kname_46378) && IS_ATOM_INT(_24443))
        _24444 = 0;
        else
        _24444 = (compare(_kname_46378, _24443) == 0);
        if (_24444 == 0)
        {
            _24444 = NOVALUE;
            goto LC; // [448] 459
        }
        else{
            _24444 = NOVALUE;
        }

        /** 				sequence_type = st_index*/
        _52sequence_type_45735 = _st_index_46377;
LC: 
L9: 
L7: 
L6: 

        /** 		if buckets[hashval] = 0 then*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _24445 = (int)*(((s1_ptr)_2)->base + _hashval_46373);
        if (binary_op_a(NOTEQ, _24445, 0)){
            _24445 = NOVALUE;
            goto LD; // [470] 485
        }
        _24445 = NOVALUE;

        /** 			buckets[hashval] = st_index*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _2 = (int)(((s1_ptr)_2)->base + _hashval_46373);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46377;
        DeRef(_1);
        goto LE; // [482] 553
LD: 

        /** 			s = buckets[hashval]*/
        _2 = (int)SEQ_PTR(_52buckets_45727);
        _s_46376 = (int)*(((s1_ptr)_2)->base + _hashval_46373);
        if (!IS_ATOM_INT(_s_46376)){
            _s_46376 = (long)DBL_PTR(_s_46376)->dbl;
        }

        /** 			while SymTab[s][S_SAMEHASH] != 0 do*/
LF: 
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24448 = (int)*(((s1_ptr)_2)->base + _s_46376);
        _2 = (int)SEQ_PTR(_24448);
        _24449 = (int)*(((s1_ptr)_2)->base + 9);
        _24448 = NOVALUE;
        if (binary_op_a(EQUALS, _24449, 0)){
            _24449 = NOVALUE;
            goto L10; // [512] 537
        }
        _24449 = NOVALUE;

        /** 				s = SymTab[s][S_SAMEHASH]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24451 = (int)*(((s1_ptr)_2)->base + _s_46376);
        _2 = (int)SEQ_PTR(_24451);
        _s_46376 = (int)*(((s1_ptr)_2)->base + 9);
        if (!IS_ATOM_INT(_s_46376)){
            _s_46376 = (long)DBL_PTR(_s_46376)->dbl;
        }
        _24451 = NOVALUE;

        /** 			end while*/
        goto LF; // [534] 500
L10: 

        /** 			SymTab[s][S_SAMEHASH] = st_index*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_s_46376 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 9);
        _1 = *(int *)_2;
        *(int *)_2 = _st_index_46377;
        DeRef(_1);
        _24453 = NOVALUE;
LE: 

        /** 	end for*/
        _k_46381 = _k_46381 + 1;
        goto L1; // [555] 22
L2: 
        ;
    }

    /** 	file_start_sym = length(SymTab)*/
    if (IS_SEQUENCE(_13SymTab_10636)){
            _12file_start_sym_11688 = SEQ_PTR(_13SymTab_10636)->length;
    }
    else {
        _12file_start_sym_11688 = 1;
    }

    /** 	sequence si, sj*/

    /** 	CurrentSub = TopLevelSub*/
    _12CurrentSub_11690 = _12TopLevelSub_11689;

    /** 	for i=1 to length(fixups) do*/
    if (IS_SEQUENCE(_fixups_46379)){
            _24456 = SEQ_PTR(_fixups_46379)->length;
    }
    else {
        _24456 = 1;
    }
    {
        int _i_46524;
        _i_46524 = 1;
L11: 
        if (_i_46524 > _24456){
            goto L12; // [585] 945
        }

        /** 	    si = SymTab[fixups[i]][S_CODE] -- seq of either 0's or sequences of tokens*/
        _2 = (int)SEQ_PTR(_fixups_46379);
        _24457 = (int)*(((s1_ptr)_2)->base + _i_46524);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24458 = (int)*(((s1_ptr)_2)->base + _24457);
        DeRef(_si_46519);
        _2 = (int)SEQ_PTR(_24458);
        if (!IS_ATOM_INT(_12S_CODE_11366)){
            _si_46519 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        }
        else{
            _si_46519 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
        }
        Ref(_si_46519);
        _24458 = NOVALUE;

        /** 	    for j=1 to length(si) do*/
        if (IS_SEQUENCE(_si_46519)){
                _24460 = SEQ_PTR(_si_46519)->length;
        }
        else {
            _24460 = 1;
        }
        {
            int _j_46532;
            _j_46532 = 1;
L13: 
            if (_j_46532 > _24460){
                goto L14; // [617] 919
            }

            /** 	        if sequence(si[j]) then*/
            _2 = (int)SEQ_PTR(_si_46519);
            _24461 = (int)*(((s1_ptr)_2)->base + _j_46532);
            _24462 = IS_SEQUENCE(_24461);
            _24461 = NOVALUE;
            if (_24462 == 0)
            {
                _24462 = NOVALUE;
                goto L15; // [633] 912
            }
            else{
                _24462 = NOVALUE;
            }

            /** 	            sj = si[j] -- a sequence of tokens*/
            DeRef(_sj_46520);
            _2 = (int)SEQ_PTR(_si_46519);
            _sj_46520 = (int)*(((s1_ptr)_2)->base + _j_46532);
            Ref(_sj_46520);

            /** 				for ij=1 to length(sj) do*/
            if (IS_SEQUENCE(_sj_46520)){
                    _24464 = SEQ_PTR(_sj_46520)->length;
            }
            else {
                _24464 = 1;
            }
            {
                int _ij_46539;
                _ij_46539 = 1;
L16: 
                if (_ij_46539 > _24464){
                    goto L17; // [649] 905
                }

                /** 	                switch sj[ij][T_ID] with fallthru do*/
                _2 = (int)SEQ_PTR(_sj_46520);
                _24465 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                _2 = (int)SEQ_PTR(_24465);
                _24466 = (int)*(((s1_ptr)_2)->base + 1);
                _24465 = NOVALUE;
                if (IS_SEQUENCE(_24466) ){
                    goto L18; // [668] 898
                }
                if(!IS_ATOM_INT(_24466)){
                    if( (DBL_PTR(_24466)->dbl != (double) ((int) DBL_PTR(_24466)->dbl) ) ){
                        goto L18; // [668] 898
                    }
                    _0 = (int) DBL_PTR(_24466)->dbl;
                }
                else {
                    _0 = _24466;
                };
                _24466 = NOVALUE;
                switch ( _0 ){ 

                    /** 	                    case ATOM then -- must create a lasting temp*/
                    case 502:

                    /** 	                    	if integer(sj[ij][T_SYM]) then*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    _24469 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                    _2 = (int)SEQ_PTR(_24469);
                    _24470 = (int)*(((s1_ptr)_2)->base + 2);
                    _24469 = NOVALUE;
                    if (IS_ATOM_INT(_24470))
                    _24471 = 1;
                    else if (IS_ATOM_DBL(_24470))
                    _24471 = IS_ATOM_INT(DoubleToInt(_24470));
                    else
                    _24471 = 0;
                    _24470 = NOVALUE;
                    if (_24471 == 0)
                    {
                        _24471 = NOVALUE;
                        goto L19; // [692] 716
                    }
                    else{
                        _24471 = NOVALUE;
                    }

                    /** 								st_index = NewIntSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    _24472 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                    _2 = (int)SEQ_PTR(_24472);
                    _24473 = (int)*(((s1_ptr)_2)->base + 2);
                    _24472 = NOVALUE;
                    Ref(_24473);
                    _st_index_46377 = _52NewIntSym(_24473);
                    _24473 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46377)) {
                        _1 = (long)(DBL_PTR(_st_index_46377)->dbl);
                        DeRefDS(_st_index_46377);
                        _st_index_46377 = _1;
                    }
                    goto L1A; // [713] 735
L19: 

                    /** 								st_index = NewDoubleSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    _24475 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                    _2 = (int)SEQ_PTR(_24475);
                    _24476 = (int)*(((s1_ptr)_2)->base + 2);
                    _24475 = NOVALUE;
                    Ref(_24476);
                    _st_index_46377 = _52NewDoubleSym(_24476);
                    _24476 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46377)) {
                        _1 = (long)(DBL_PTR(_st_index_46377)->dbl);
                        DeRefDS(_st_index_46377);
                        _st_index_46377 = _1;
                    }
L1A: 

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_13SymTab_10636);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _13SymTab_10636 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24478 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46520 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46539 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46377;
                    DeRef(_1);
                    _24480 = NOVALUE;

                    /** 							break*/
                    goto L18; // [769] 898

                    /** 						case STRING then -- same*/
                    case 503:

                    /** 	                    	st_index = NewStringSym(sj[ij][T_SYM])*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    _24482 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                    _2 = (int)SEQ_PTR(_24482);
                    _24483 = (int)*(((s1_ptr)_2)->base + 2);
                    _24482 = NOVALUE;
                    Ref(_24483);
                    _st_index_46377 = _52NewStringSym(_24483);
                    _24483 = NOVALUE;
                    if (!IS_ATOM_INT(_st_index_46377)) {
                        _1 = (long)(DBL_PTR(_st_index_46377)->dbl);
                        DeRefDS(_st_index_46377);
                        _st_index_46377 = _1;
                    }

                    /** 							SymTab[st_index][S_SCOPE] = IN_USE -- TempKeep()*/
                    _2 = (int)SEQ_PTR(_13SymTab_10636);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _13SymTab_10636 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_st_index_46377 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 4);
                    _1 = *(int *)_2;
                    *(int *)_2 = 1;
                    DeRef(_1);
                    _24485 = NOVALUE;

                    /** 							sj[ij][T_SYM] = st_index*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46520 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46539 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _st_index_46377;
                    DeRef(_1);
                    _24487 = NOVALUE;

                    /** 							break*/
                    goto L18; // [825] 898

                    /** 						case BUILT_IN then -- name of a builtin in econd field*/
                    case 511:

                    /**                             sj[ij] = keyfind(sj[ij][T_SYM],-1)*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    _24489 = (int)*(((s1_ptr)_2)->base + _ij_46539);
                    _2 = (int)SEQ_PTR(_24489);
                    _24490 = (int)*(((s1_ptr)_2)->base + 2);
                    _24489 = NOVALUE;
                    Ref(_24490);
                    DeRef(_24965);
                    _24965 = _24490;
                    _24966 = _52hashfn(_24965);
                    _24965 = NOVALUE;
                    Ref(_24490);
                    _24491 = _52keyfind(_24490, -1, _12current_file_no_11682, 0, _24966);
                    _24490 = NOVALUE;
                    _24966 = NOVALUE;
                    _2 = (int)SEQ_PTR(_sj_46520);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46520 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + _ij_46539);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24491;
                    if( _1 != _24491 ){
                        DeRef(_1);
                    }
                    _24491 = NOVALUE;

                    /** 							break*/
                    goto L18; // [866] 898

                    /** 						case DEF_PARAM then*/
                    case 510:

                    /** 							sj[ij][T_SYM] &= fixups[i]*/
                    _2 = (int)SEQ_PTR(_sj_46520);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        _sj_46520 = MAKE_SEQ(_2);
                    }
                    _3 = (int)(_ij_46539 + ((s1_ptr)_2)->base);
                    _2 = (int)SEQ_PTR(_fixups_46379);
                    _24494 = (int)*(((s1_ptr)_2)->base + _i_46524);
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    _24495 = (int)*(((s1_ptr)_2)->base + 2);
                    _24492 = NOVALUE;
                    if (IS_SEQUENCE(_24495) && IS_ATOM(_24494)) {
                        Append(&_24496, _24495, _24494);
                    }
                    else if (IS_ATOM(_24495) && IS_SEQUENCE(_24494)) {
                    }
                    else {
                        Concat((object_ptr)&_24496, _24495, _24494);
                        _24495 = NOVALUE;
                    }
                    _24495 = NOVALUE;
                    _24494 = NOVALUE;
                    _2 = (int)SEQ_PTR(*(int *)_3);
                    if (!UNIQUE(_2)) {
                        _2 = (int)SequenceCopy((s1_ptr)_2);
                        *(int *)_3 = MAKE_SEQ(_2);
                    }
                    _2 = (int)(((s1_ptr)_2)->base + 2);
                    _1 = *(int *)_2;
                    *(int *)_2 = _24496;
                    if( _1 != _24496 ){
                        DeRef(_1);
                    }
                    _24496 = NOVALUE;
                    _24492 = NOVALUE;
                ;}L18: 

                /** 				end for*/
                _ij_46539 = _ij_46539 + 1;
                goto L16; // [900] 656
L17: 
                ;
            }

            /** 				si[j] = sj*/
            RefDS(_sj_46520);
            _2 = (int)SEQ_PTR(_si_46519);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _si_46519 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_46532);
            _1 = *(int *)_2;
            *(int *)_2 = _sj_46520;
            DeRef(_1);
L15: 

            /** 		end for*/
            _j_46532 = _j_46532 + 1;
            goto L13; // [914] 624
L14: 
            ;
        }

        /** 		SymTab[fixups[i]][S_CODE] = si*/
        _2 = (int)SEQ_PTR(_fixups_46379);
        _24497 = (int)*(((s1_ptr)_2)->base + _i_46524);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_24497 + ((s1_ptr)_2)->base);
        RefDS(_si_46519);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        if (!IS_ATOM_INT(_12S_CODE_11366))
        _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
        else
        _2 = (int)(((s1_ptr)_2)->base + _12S_CODE_11366);
        _1 = *(int *)_2;
        *(int *)_2 = _si_46519;
        DeRef(_1);
        _24498 = NOVALUE;

        /** 	end for*/
        _i_46524 = _i_46524 + 1;
        goto L11; // [940] 592
L12: 
        ;
    }

    /** end procedure*/
    DeRef(_kname_46378);
    DeRefi(_fixups_46379);
    DeRef(_si_46519);
    DeRef(_sj_46520);
    _24417 = NOVALUE;
    _24398 = NOVALUE;
    _24457 = NOVALUE;
    _24497 = NOVALUE;
    return;
    ;
}


void _52add_ref(int _tok_46607)
{
    int _s_46609 = NOVALUE;
    int _24514 = NOVALUE;
    int _24513 = NOVALUE;
    int _24511 = NOVALUE;
    int _24510 = NOVALUE;
    int _24509 = NOVALUE;
    int _24507 = NOVALUE;
    int _24506 = NOVALUE;
    int _24505 = NOVALUE;
    int _24504 = NOVALUE;
    int _24503 = NOVALUE;
    int _24502 = NOVALUE;
    int _24501 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	s = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_46607);
    _s_46609 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_46609)){
        _s_46609 = (long)DBL_PTR(_s_46609)->dbl;
    }

    /** 	if s != CurrentSub and -- ignore self-ref's*/
    _24501 = (_s_46609 != _12CurrentSub_11690);
    if (_24501 == 0) {
        goto L1; // [19] 98
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24503 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24503);
    _24504 = (int)*(((s1_ptr)_2)->base + 24);
    _24503 = NOVALUE;
    _24505 = find_from(_s_46609, _24504, 1);
    _24504 = NOVALUE;
    _24506 = (_24505 == 0);
    _24505 = NOVALUE;
    if (_24506 == 0)
    {
        DeRef(_24506);
        _24506 = NOVALUE;
        goto L1; // [46] 98
    }
    else{
        DeRef(_24506);
        _24506 = NOVALUE;
    }

    /** 		SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_46609 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24509 = (int)*(((s1_ptr)_2)->base + 12);
    _24507 = NOVALUE;
    if (IS_ATOM_INT(_24509)) {
        _24510 = _24509 + 1;
        if (_24510 > MAXINT){
            _24510 = NewDouble((double)_24510);
        }
    }
    else
    _24510 = binary_op(PLUS, 1, _24509);
    _24509 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _24510;
    if( _1 != _24510 ){
        DeRef(_1);
    }
    _24510 = NOVALUE;
    _24507 = NOVALUE;

    /** 		SymTab[CurrentSub][S_REFLIST] &= s*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_12CurrentSub_11690 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24513 = (int)*(((s1_ptr)_2)->base + 24);
    _24511 = NOVALUE;
    if (IS_SEQUENCE(_24513) && IS_ATOM(_s_46609)) {
        Append(&_24514, _24513, _s_46609);
    }
    else if (IS_ATOM(_24513) && IS_SEQUENCE(_s_46609)) {
    }
    else {
        Concat((object_ptr)&_24514, _24513, _s_46609);
        _24513 = NOVALUE;
    }
    _24513 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 24);
    _1 = *(int *)_2;
    *(int *)_2 = _24514;
    if( _1 != _24514 ){
        DeRef(_1);
    }
    _24514 = NOVALUE;
    _24511 = NOVALUE;
L1: 

    /** end procedure*/
    DeRef(_tok_46607);
    DeRef(_24501);
    _24501 = NOVALUE;
    return;
    ;
}


void _52mark_all(int _attribute_46639)
{
    int _p_46642 = NOVALUE;
    int _sym_file_46649 = NOVALUE;
    int _scope_46666 = NOVALUE;
    int _24546 = NOVALUE;
    int _24545 = NOVALUE;
    int _24544 = NOVALUE;
    int _24542 = NOVALUE;
    int _24540 = NOVALUE;
    int _24539 = NOVALUE;
    int _24538 = NOVALUE;
    int _24537 = NOVALUE;
    int _24536 = NOVALUE;
    int _24534 = NOVALUE;
    int _24533 = NOVALUE;
    int _24532 = NOVALUE;
    int _24531 = NOVALUE;
    int _24527 = NOVALUE;
    int _24526 = NOVALUE;
    int _24525 = NOVALUE;
    int _24523 = NOVALUE;
    int _24522 = NOVALUE;
    int _24520 = NOVALUE;
    int _24518 = NOVALUE;
    int _24515 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if just_mark_everything_from then*/
    if (_52just_mark_everything_from_46636 == 0)
    {
        goto L1; // [7] 270
    }
    else{
    }

    /** 		symtab_pointer p = SymTab[just_mark_everything_from][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24515 = (int)*(((s1_ptr)_2)->base + _52just_mark_everything_from_46636);
    _2 = (int)SEQ_PTR(_24515);
    _p_46642 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46642)){
        _p_46642 = (long)DBL_PTR(_p_46642)->dbl;
    }
    _24515 = NOVALUE;

    /** 		while p != 0 do*/
L2: 
    if (_p_46642 == 0)
    goto L3; // [33] 269

    /** 			integer sym_file = SymTab[p][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24518 = (int)*(((s1_ptr)_2)->base + _p_46642);
    _2 = (int)SEQ_PTR(_24518);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _sym_file_46649 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _sym_file_46649 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_sym_file_46649)){
        _sym_file_46649 = (long)DBL_PTR(_sym_file_46649)->dbl;
    }
    _24518 = NOVALUE;

    /** 			just_mark_everything_from = p*/
    _52just_mark_everything_from_46636 = _p_46642;

    /** 			if sym_file = current_file_no or find( sym_file, recheck_files ) then*/
    _24520 = (_sym_file_46649 == _12current_file_no_11682);
    if (_24520 != 0) {
        goto L4; // [68] 84
    }
    _24522 = find_from(_sym_file_46649, _52recheck_files_46709, 1);
    if (_24522 == 0)
    {
        _24522 = NOVALUE;
        goto L5; // [80] 108
    }
    else{
        _24522 = NOVALUE;
    }
L4: 

    /** 				SymTab[p][attribute] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_p_46642 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24525 = (int)*(((s1_ptr)_2)->base + _attribute_46639);
    _24523 = NOVALUE;
    if (IS_ATOM_INT(_24525)) {
        _24526 = _24525 + 1;
        if (_24526 > MAXINT){
            _24526 = NewDouble((double)_24526);
        }
    }
    else
    _24526 = binary_op(PLUS, 1, _24525);
    _24525 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_46639);
    _1 = *(int *)_2;
    *(int *)_2 = _24526;
    if( _1 != _24526 ){
        DeRef(_1);
    }
    _24526 = NOVALUE;
    _24523 = NOVALUE;
    goto L6; // [105] 246
L5: 

    /** 				integer scope = SymTab[p][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24527 = (int)*(((s1_ptr)_2)->base + _p_46642);
    _2 = (int)SEQ_PTR(_24527);
    _scope_46666 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46666)){
        _scope_46666 = (long)DBL_PTR(_scope_46666)->dbl;
    }
    _24527 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_46666;
    switch ( _0 ){ 

        /** 					case SC_PUBLIC then*/
        case 13:

        /** 						if and_bits( DIRECT_OR_PUBLIC_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24531 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
        _2 = (int)SEQ_PTR(_24531);
        _24532 = (int)*(((s1_ptr)_2)->base + _sym_file_46649);
        _24531 = NOVALUE;
        if (IS_ATOM_INT(_24532)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24532;
                 _24533 = MAKE_UINT(tu);
            }
        }
        else {
            _24533 = binary_op(AND_BITS, 6, _24532);
        }
        _24532 = NOVALUE;
        if (_24533 == 0) {
            DeRef(_24533);
            _24533 = NOVALUE;
            goto L7; // [155] 243
        }
        else {
            if (!IS_ATOM_INT(_24533) && DBL_PTR(_24533)->dbl == 0.0){
                DeRef(_24533);
                _24533 = NOVALUE;
                goto L7; // [155] 243
            }
            DeRef(_24533);
            _24533 = NOVALUE;
        }
        DeRef(_24533);
        _24533 = NOVALUE;

        /** 							SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_46642 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24536 = (int)*(((s1_ptr)_2)->base + _attribute_46639);
        _24534 = NOVALUE;
        if (IS_ATOM_INT(_24536)) {
            _24537 = _24536 + 1;
            if (_24537 > MAXINT){
                _24537 = NewDouble((double)_24537);
            }
        }
        else
        _24537 = binary_op(PLUS, 1, _24536);
        _24536 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46639);
        _1 = *(int *)_2;
        *(int *)_2 = _24537;
        if( _1 != _24537 ){
            DeRef(_1);
        }
        _24537 = NOVALUE;
        _24534 = NOVALUE;

        /** 						break*/
        goto L7; // [182] 243

        /** 					case SC_EXPORT then*/
        case 11:

        /** 						if not and_bits( DIRECT_INCLUDE, include_matrix[current_file_no][sym_file] ) then*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24538 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
        _2 = (int)SEQ_PTR(_24538);
        _24539 = (int)*(((s1_ptr)_2)->base + _sym_file_46649);
        _24538 = NOVALUE;
        if (IS_ATOM_INT(_24539)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24539;
                 _24540 = MAKE_UINT(tu);
            }
        }
        else {
            _24540 = binary_op(AND_BITS, 2, _24539);
        }
        _24539 = NOVALUE;
        if (IS_ATOM_INT(_24540)) {
            if (_24540 != 0){
                DeRef(_24540);
                _24540 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        else {
            if (DBL_PTR(_24540)->dbl != 0.0){
                DeRef(_24540);
                _24540 = NOVALUE;
                goto L8; // [208] 216
            }
        }
        DeRef(_24540);
        _24540 = NOVALUE;

        /** 							break*/
        goto L9; // [213] 217
L8: 
L9: 

        /** 					case SC_GLOBAL then*/
        case 6:

        /** 						SymTab[p][attribute] += 1*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_46642 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        _24544 = (int)*(((s1_ptr)_2)->base + _attribute_46639);
        _24542 = NOVALUE;
        if (IS_ATOM_INT(_24544)) {
            _24545 = _24544 + 1;
            if (_24545 > MAXINT){
                _24545 = NewDouble((double)_24545);
            }
        }
        else
        _24545 = binary_op(PLUS, 1, _24544);
        _24544 = NOVALUE;
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _attribute_46639);
        _1 = *(int *)_2;
        *(int *)_2 = _24545;
        if( _1 != _24545 ){
            DeRef(_1);
        }
        _24545 = NOVALUE;
        _24542 = NOVALUE;
    ;}L7: 
L6: 

    /** 			p = SymTab[p][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24546 = (int)*(((s1_ptr)_2)->base + _p_46642);
    _2 = (int)SEQ_PTR(_24546);
    _p_46642 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_46642)){
        _p_46642 = (long)DBL_PTR(_p_46642)->dbl;
    }
    _24546 = NOVALUE;

    /** 		end while*/
    goto L2; // [266] 33
L3: 
L1: 

    /** end procedure*/
    DeRef(_24520);
    _24520 = NOVALUE;
    return;
    ;
}


void _52mark_final_targets()
{
    int _marked_46724 = NOVALUE;
    int _24552 = NOVALUE;
    int _24550 = NOVALUE;
    int _24549 = NOVALUE;
    int _24548 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if just_mark_everything_from then*/
    if (_52just_mark_everything_from_46636 == 0)
    {
        goto L1; // [5] 44
    }
    else{
    }

    /** 		if TRANSLATE then*/
    if (_12TRANSLATE_11319 == 0)
    {
        goto L2; // [12] 25
    }
    else{
    }

    /** 			mark_all( S_RI_TARGET )*/
    _52mark_all(53);
    goto L3; // [22] 152
L2: 

    /** 		elsif BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L3; // [29] 152
    }
    else{
    }

    /** 			mark_all( S_NREFS )*/
    _52mark_all(12);
    goto L3; // [41] 152
L1: 

    /** 	elsif length( recheck_targets ) then*/
    if (IS_SEQUENCE(_52recheck_targets_46708)){
            _24548 = SEQ_PTR(_52recheck_targets_46708)->length;
    }
    else {
        _24548 = 1;
    }
    if (_24548 == 0)
    {
        _24548 = NOVALUE;
        goto L4; // [51] 151
    }
    else{
        _24548 = NOVALUE;
    }

    /** 		for i = length( recheck_targets ) to 1 by -1 do*/
    if (IS_SEQUENCE(_52recheck_targets_46708)){
            _24549 = SEQ_PTR(_52recheck_targets_46708)->length;
    }
    else {
        _24549 = 1;
    }
    {
        int _i_46722;
        _i_46722 = _24549;
L5: 
        if (_i_46722 < 1){
            goto L6; // [61] 150
        }

        /** 			integer marked = 0*/
        _marked_46724 = 0;

        /** 			if TRANSLATE then*/
        if (_12TRANSLATE_11319 == 0)
        {
            goto L7; // [77] 100
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_RI_TARGET )*/
        _2 = (int)SEQ_PTR(_52recheck_targets_46708);
        _24550 = (int)*(((s1_ptr)_2)->base + _i_46722);
        Ref(_24550);
        _marked_46724 = _52MarkTargets(_24550, 53);
        _24550 = NOVALUE;
        if (!IS_ATOM_INT(_marked_46724)) {
            _1 = (long)(DBL_PTR(_marked_46724)->dbl);
            DeRefDS(_marked_46724);
            _marked_46724 = _1;
        }
        goto L8; // [97] 126
L7: 

        /** 			elsif BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto L9; // [104] 125
        }
        else{
        }

        /** 				marked = MarkTargets( recheck_targets[i], S_NREFS )*/
        _2 = (int)SEQ_PTR(_52recheck_targets_46708);
        _24552 = (int)*(((s1_ptr)_2)->base + _i_46722);
        Ref(_24552);
        _marked_46724 = _52MarkTargets(_24552, 12);
        _24552 = NOVALUE;
        if (!IS_ATOM_INT(_marked_46724)) {
            _1 = (long)(DBL_PTR(_marked_46724)->dbl);
            DeRefDS(_marked_46724);
            _marked_46724 = _1;
        }
L9: 
L8: 

        /** 			if marked then*/
        if (_marked_46724 == 0)
        {
            goto LA; // [128] 141
        }
        else{
        }

        /** 				recheck_targets = remove( recheck_targets, i )*/
        {
            s1_ptr assign_space = SEQ_PTR(_52recheck_targets_46708);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_i_46722)) ? _i_46722 : (long)(DBL_PTR(_i_46722)->dbl);
            int stop = (IS_ATOM_INT(_i_46722)) ? _i_46722 : (long)(DBL_PTR(_i_46722)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_52recheck_targets_46708), start, &_52recheck_targets_46708 );
                }
                else Tail(SEQ_PTR(_52recheck_targets_46708), stop+1, &_52recheck_targets_46708);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_52recheck_targets_46708), start, &_52recheck_targets_46708);
            }
            else {
                assign_slice_seq = &assign_space;
                _52recheck_targets_46708 = Remove_elements(start, stop, (SEQ_PTR(_52recheck_targets_46708)->ref == 1));
            }
        }
LA: 

        /** 		end for*/
        _i_46722 = _i_46722 + -1;
        goto L5; // [145] 68
L6: 
        ;
    }
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _52is_routine(int _sym_46742)
{
    int _tok_46743 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer tok = sym_token( sym )*/
    _tok_46743 = _52sym_token(_sym_46742);
    if (!IS_ATOM_INT(_tok_46743)) {
        _1 = (long)(DBL_PTR(_tok_46743)->dbl);
        DeRefDS(_tok_46743);
        _tok_46743 = _1;
    }

    /** 	switch tok do*/
    _0 = _tok_46743;
    switch ( _0 ){ 

        /** 		case FUNC, PROC, TYPE then*/
        case 501:
        case 27:
        case 504:

        /** 			return 1*/
        return 1;
        goto L1; // [32] 45

        /** 		case else*/
        default:

        /** 			return 0*/
        return 0;
    ;}L1: 
    ;
}


int _52is_visible(int _sym_46756, int _from_file_46757)
{
    int _scope_46758 = NOVALUE;
    int _sym_file_46761 = NOVALUE;
    int _visible_mask_46766 = NOVALUE;
    int _24566 = NOVALUE;
    int _24565 = NOVALUE;
    int _24564 = NOVALUE;
    int _24563 = NOVALUE;
    int _24559 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer scope = sym_scope( sym )*/
    _scope_46758 = _52sym_scope(_sym_46756);
    if (!IS_ATOM_INT(_scope_46758)) {
        _1 = (long)(DBL_PTR(_scope_46758)->dbl);
        DeRefDS(_scope_46758);
        _scope_46758 = _1;
    }

    /** 	integer sym_file = SymTab[sym][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24559 = (int)*(((s1_ptr)_2)->base + _sym_46756);
    _2 = (int)SEQ_PTR(_24559);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _sym_file_46761 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _sym_file_46761 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_sym_file_46761)){
        _sym_file_46761 = (long)DBL_PTR(_sym_file_46761)->dbl;
    }
    _24559 = NOVALUE;

    /** 	switch scope do*/
    _0 = _scope_46758;
    switch ( _0 ){ 

        /** 		case SC_PUBLIC then*/
        case 13:

        /** 			visible_mask = DIRECT_OR_PUBLIC_INCLUDE*/
        _visible_mask_46766 = 6;
        goto L1; // [49] 93

        /** 		case SC_EXPORT then*/
        case 11:

        /** 			visible_mask = DIRECT_INCLUDE*/
        _visible_mask_46766 = 2;
        goto L1; // [64] 93

        /** 		case SC_GLOBAL then*/
        case 6:

        /** 			return 1*/
        return 1;
        goto L1; // [76] 93

        /** 		case else*/
        default:

        /** 			return from_file = sym_file*/
        _24563 = (_from_file_46757 == _sym_file_46761);
        return _24563;
    ;}L1: 

    /** 	return and_bits( visible_mask, include_matrix[from_file][sym_file] )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _24564 = (int)*(((s1_ptr)_2)->base + _from_file_46757);
    _2 = (int)SEQ_PTR(_24564);
    _24565 = (int)*(((s1_ptr)_2)->base + _sym_file_46761);
    _24564 = NOVALUE;
    if (IS_ATOM_INT(_24565)) {
        {unsigned long tu;
             tu = (unsigned long)_visible_mask_46766 & (unsigned long)_24565;
             _24566 = MAKE_UINT(tu);
        }
    }
    else {
        _24566 = binary_op(AND_BITS, _visible_mask_46766, _24565);
    }
    _24565 = NOVALUE;
    DeRef(_24563);
    _24563 = NOVALUE;
    return _24566;
    ;
}


int _52MarkTargets(int _s_46786, int _attribute_46787)
{
    int _p_46789 = NOVALUE;
    int _sname_46790 = NOVALUE;
    int _string_46791 = NOVALUE;
    int _colon_46792 = NOVALUE;
    int _h_46793 = NOVALUE;
    int _scope_46794 = NOVALUE;
    int _found_46815 = NOVALUE;
    int _24618 = NOVALUE;
    int _24614 = NOVALUE;
    int _24612 = NOVALUE;
    int _24611 = NOVALUE;
    int _24610 = NOVALUE;
    int _24609 = NOVALUE;
    int _24607 = NOVALUE;
    int _24606 = NOVALUE;
    int _24605 = NOVALUE;
    int _24604 = NOVALUE;
    int _24603 = NOVALUE;
    int _24601 = NOVALUE;
    int _24600 = NOVALUE;
    int _24599 = NOVALUE;
    int _24597 = NOVALUE;
    int _24595 = NOVALUE;
    int _24593 = NOVALUE;
    int _24592 = NOVALUE;
    int _24591 = NOVALUE;
    int _24590 = NOVALUE;
    int _24588 = NOVALUE;
    int _24587 = NOVALUE;
    int _24586 = NOVALUE;
    int _24585 = NOVALUE;
    int _24583 = NOVALUE;
    int _24582 = NOVALUE;
    int _24578 = NOVALUE;
    int _24577 = NOVALUE;
    int _24576 = NOVALUE;
    int _24575 = NOVALUE;
    int _24574 = NOVALUE;
    int _24573 = NOVALUE;
    int _24572 = NOVALUE;
    int _24571 = NOVALUE;
    int _24570 = NOVALUE;
    int _24569 = NOVALUE;
    int _24568 = NOVALUE;
    int _24567 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_46786)) {
        _1 = (long)(DBL_PTR(_s_46786)->dbl);
        DeRefDS(_s_46786);
        _s_46786 = _1;
    }
    if (!IS_ATOM_INT(_attribute_46787)) {
        _1 = (long)(DBL_PTR(_attribute_46787)->dbl);
        DeRefDS(_attribute_46787);
        _attribute_46787 = _1;
    }

    /** 	sequence sname*/

    /** 	sequence string*/

    /** 	integer colon, h*/

    /** 	integer scope*/

    /** 	if (SymTab[s][S_MODE] = M_TEMP or*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24567 = (int)*(((s1_ptr)_2)->base + _s_46786);
    _2 = (int)SEQ_PTR(_24567);
    _24568 = (int)*(((s1_ptr)_2)->base + 3);
    _24567 = NOVALUE;
    if (IS_ATOM_INT(_24568)) {
        _24569 = (_24568 == 3);
    }
    else {
        _24569 = binary_op(EQUALS, _24568, 3);
    }
    _24568 = NOVALUE;
    if (IS_ATOM_INT(_24569)) {
        if (_24569 != 0) {
            _24570 = 1;
            goto L1; // [33] 59
        }
    }
    else {
        if (DBL_PTR(_24569)->dbl != 0.0) {
            _24570 = 1;
            goto L1; // [33] 59
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24571 = (int)*(((s1_ptr)_2)->base + _s_46786);
    _2 = (int)SEQ_PTR(_24571);
    _24572 = (int)*(((s1_ptr)_2)->base + 3);
    _24571 = NOVALUE;
    if (IS_ATOM_INT(_24572)) {
        _24573 = (_24572 == 2);
    }
    else {
        _24573 = binary_op(EQUALS, _24572, 2);
    }
    _24572 = NOVALUE;
    DeRef(_24570);
    if (IS_ATOM_INT(_24573))
    _24570 = (_24573 != 0);
    else
    _24570 = DBL_PTR(_24573)->dbl != 0.0;
L1: 
    if (_24570 == 0) {
        goto L2; // [59] 440
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24575 = (int)*(((s1_ptr)_2)->base + _s_46786);
    _2 = (int)SEQ_PTR(_24575);
    _24576 = (int)*(((s1_ptr)_2)->base + 1);
    _24575 = NOVALUE;
    _24577 = IS_SEQUENCE(_24576);
    _24576 = NOVALUE;
    if (_24577 == 0)
    {
        _24577 = NOVALUE;
        goto L2; // [79] 440
    }
    else{
        _24577 = NOVALUE;
    }

    /** 		integer found = 0*/
    _found_46815 = 0;

    /** 		string = SymTab[s][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24578 = (int)*(((s1_ptr)_2)->base + _s_46786);
    DeRef(_string_46791);
    _2 = (int)SEQ_PTR(_24578);
    _string_46791 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_string_46791);
    _24578 = NOVALUE;

    /** 		colon = find(':', string)*/
    _colon_46792 = find_from(58, _string_46791, 1);

    /** 		if colon = 0 then*/
    if (_colon_46792 != 0)
    goto L3; // [112] 126

    /** 			sname = string*/
    RefDS(_string_46791);
    DeRef(_sname_46790);
    _sname_46790 = _string_46791;
    goto L4; // [123] 200
L3: 

    /** 			sname = string[colon+1..$]  -- ignore namespace part*/
    _24582 = _colon_46792 + 1;
    if (_24582 > MAXINT){
        _24582 = NewDouble((double)_24582);
    }
    if (IS_SEQUENCE(_string_46791)){
            _24583 = SEQ_PTR(_string_46791)->length;
    }
    else {
        _24583 = 1;
    }
    rhs_slice_target = (object_ptr)&_sname_46790;
    RHS_Slice(_string_46791, _24582, _24583);

    /** 			while length(sname) and sname[1] = ' ' or sname[1] = '\t' do*/
L5: 
    if (IS_SEQUENCE(_sname_46790)){
            _24585 = SEQ_PTR(_sname_46790)->length;
    }
    else {
        _24585 = 1;
    }
    if (_24585 == 0) {
        _24586 = 0;
        goto L6; // [148] 164
    }
    _2 = (int)SEQ_PTR(_sname_46790);
    _24587 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24587)) {
        _24588 = (_24587 == 32);
    }
    else {
        _24588 = binary_op(EQUALS, _24587, 32);
    }
    _24587 = NOVALUE;
    if (IS_ATOM_INT(_24588))
    _24586 = (_24588 != 0);
    else
    _24586 = DBL_PTR(_24588)->dbl != 0.0;
L6: 
    if (_24586 != 0) {
        goto L7; // [164] 181
    }
    _2 = (int)SEQ_PTR(_sname_46790);
    _24590 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24590)) {
        _24591 = (_24590 == 9);
    }
    else {
        _24591 = binary_op(EQUALS, _24590, 9);
    }
    _24590 = NOVALUE;
    if (_24591 <= 0) {
        if (_24591 == 0) {
            DeRef(_24591);
            _24591 = NOVALUE;
            goto L8; // [177] 199
        }
        else {
            if (!IS_ATOM_INT(_24591) && DBL_PTR(_24591)->dbl == 0.0){
                DeRef(_24591);
                _24591 = NOVALUE;
                goto L8; // [177] 199
            }
            DeRef(_24591);
            _24591 = NOVALUE;
        }
    }
    DeRef(_24591);
    _24591 = NOVALUE;
L7: 

    /** 				sname = tail( sname, length( sname ) -1 )*/
    if (IS_SEQUENCE(_sname_46790)){
            _24592 = SEQ_PTR(_sname_46790)->length;
    }
    else {
        _24592 = 1;
    }
    _24593 = _24592 - 1;
    _24592 = NOVALUE;
    {
        int len = SEQ_PTR(_sname_46790)->length;
        int size = (IS_ATOM_INT(_24593)) ? _24593 : (long)(DBL_PTR(_24593)->dbl);
        if (size <= 0) {
            DeRef(_sname_46790);
            _sname_46790 = MAKE_SEQ(NewS1(0));
        }
        else if (len <= size) {
            RefDS(_sname_46790);
            DeRef(_sname_46790);
            _sname_46790 = _sname_46790;
        }
        else Tail(SEQ_PTR(_sname_46790), len-size+1, &_sname_46790);
    }
    _24593 = NOVALUE;

    /** 			end while*/
    goto L5; // [196] 145
L8: 
L4: 

    /** 		if length(sname) = 0 then*/
    if (IS_SEQUENCE(_sname_46790)){
            _24595 = SEQ_PTR(_sname_46790)->length;
    }
    else {
        _24595 = 1;
    }
    if (_24595 != 0)
    goto L9; // [207] 218

    /** 			return 1*/
    DeRefDS(_sname_46790);
    DeRef(_string_46791);
    DeRef(_24582);
    _24582 = NOVALUE;
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24573);
    _24573 = NOVALUE;
    DeRef(_24588);
    _24588 = NOVALUE;
    return 1;
L9: 

    /** 		h = buckets[hashfn(sname)]*/
    RefDS(_sname_46790);
    _24597 = _52hashfn(_sname_46790);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_24597)){
        _h_46793 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24597)->dbl));
    }
    else{
        _h_46793 = (int)*(((s1_ptr)_2)->base + _24597);
    }
    if (!IS_ATOM_INT(_h_46793))
    _h_46793 = (long)DBL_PTR(_h_46793)->dbl;

    /** 		while h do*/
LA: 
    if (_h_46793 == 0)
    {
        goto LB; // [235] 381
    }
    else{
    }

    /** 			if equal(sname, SymTab[h][S_NAME]) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24599 = (int)*(((s1_ptr)_2)->base + _h_46793);
    _2 = (int)SEQ_PTR(_24599);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24600 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24600 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24599 = NOVALUE;
    if (_sname_46790 == _24600)
    _24601 = 1;
    else if (IS_ATOM_INT(_sname_46790) && IS_ATOM_INT(_24600))
    _24601 = 0;
    else
    _24601 = (compare(_sname_46790, _24600) == 0);
    _24600 = NOVALUE;
    if (_24601 == 0)
    {
        _24601 = NOVALUE;
        goto LC; // [256] 360
    }
    else{
        _24601 = NOVALUE;
    }

    /** 				if attribute = S_NREFS then*/
    if (_attribute_46787 != 12)
    goto LD; // [263] 289

    /** 					if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto LE; // [271] 359
    }
    else{
    }

    /** 						add_ref({PROC, h})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 27;
    ((int *)_2)[2] = _h_46793;
    _24603 = MAKE_SEQ(_1);
    _52add_ref(_24603);
    _24603 = NOVALUE;
    goto LE; // [286] 359
LD: 

    /** 				elsif is_routine( h ) and is_visible( h, current_file_no ) then*/
    _24604 = _52is_routine(_h_46793);
    if (IS_ATOM_INT(_24604)) {
        if (_24604 == 0) {
            goto LF; // [295] 358
        }
    }
    else {
        if (DBL_PTR(_24604)->dbl == 0.0) {
            goto LF; // [295] 358
        }
    }
    _24606 = _52is_visible(_h_46793, _12current_file_no_11682);
    if (_24606 == 0) {
        DeRef(_24606);
        _24606 = NOVALUE;
        goto LF; // [307] 358
    }
    else {
        if (!IS_ATOM_INT(_24606) && DBL_PTR(_24606)->dbl == 0.0){
            DeRef(_24606);
            _24606 = NOVALUE;
            goto LF; // [307] 358
        }
        DeRef(_24606);
        _24606 = NOVALUE;
    }
    DeRef(_24606);
    _24606 = NOVALUE;

    /** 					SymTab[h][attribute] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_h_46793 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _24609 = (int)*(((s1_ptr)_2)->base + _attribute_46787);
    _24607 = NOVALUE;
    if (IS_ATOM_INT(_24609)) {
        _24610 = _24609 + 1;
        if (_24610 > MAXINT){
            _24610 = NewDouble((double)_24610);
        }
    }
    else
    _24610 = binary_op(PLUS, 1, _24609);
    _24609 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _attribute_46787);
    _1 = *(int *)_2;
    *(int *)_2 = _24610;
    if( _1 != _24610 ){
        DeRef(_1);
    }
    _24610 = NOVALUE;
    _24607 = NOVALUE;

    /** 					if current_file_no = SymTab[h][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24611 = (int)*(((s1_ptr)_2)->base + _h_46793);
    _2 = (int)SEQ_PTR(_24611);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24612 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24612 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24611 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_11682, _24612)){
        _24612 = NOVALUE;
        goto L10; // [347] 357
    }
    _24612 = NOVALUE;

    /** 						found = 1*/
    _found_46815 = 1;
L10: 
LF: 
LE: 
LC: 

    /** 			h = SymTab[h][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24614 = (int)*(((s1_ptr)_2)->base + _h_46793);
    _2 = (int)SEQ_PTR(_24614);
    _h_46793 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_h_46793)){
        _h_46793 = (long)DBL_PTR(_h_46793)->dbl;
    }
    _24614 = NOVALUE;

    /** 		end while*/
    goto LA; // [378] 235
LB: 

    /** 		if not found then*/
    if (_found_46815 != 0)
    goto L11; // [383] 429

    /** 			just_mark_everything_from = TopLevelSub*/
    _52just_mark_everything_from_46636 = _12TopLevelSub_11689;

    /** 			recheck_targets &= s*/
    Append(&_52recheck_targets_46708, _52recheck_targets_46708, _s_46786);

    /** 			if not find( current_file_no, recheck_files ) then*/
    _24618 = find_from(_12current_file_no_11682, _52recheck_files_46709, 1);
    if (_24618 != 0)
    goto L12; // [414] 428
    _24618 = NOVALUE;

    /** 				recheck_files &= current_file_no*/
    Append(&_52recheck_files_46709, _52recheck_files_46709, _12current_file_no_11682);
L12: 
L11: 

    /** 		return found*/
    DeRef(_sname_46790);
    DeRef(_string_46791);
    DeRef(_24582);
    _24582 = NOVALUE;
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24573);
    _24573 = NOVALUE;
    DeRef(_24597);
    _24597 = NOVALUE;
    DeRef(_24588);
    _24588 = NOVALUE;
    DeRef(_24604);
    _24604 = NOVALUE;
    return _found_46815;
    goto L13; // [437] 469
L2: 

    /** 		if not just_mark_everything_from then*/
    if (_52just_mark_everything_from_46636 != 0)
    goto L14; // [444] 457

    /** 			just_mark_everything_from = TopLevelSub*/
    _52just_mark_everything_from_46636 = _12TopLevelSub_11689;
L14: 

    /** 		mark_all( attribute )*/
    _52mark_all(_attribute_46787);

    /** 		return 1*/
    DeRef(_sname_46790);
    DeRef(_string_46791);
    DeRef(_24582);
    _24582 = NOVALUE;
    DeRef(_24569);
    _24569 = NOVALUE;
    DeRef(_24573);
    _24573 = NOVALUE;
    DeRef(_24597);
    _24597 = NOVALUE;
    DeRef(_24588);
    _24588 = NOVALUE;
    DeRef(_24604);
    _24604 = NOVALUE;
    return 1;
L13: 
    ;
}


void _52resolve_unincluded_globals(int _ok_46900)
{
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_ok_46900)) {
        _1 = (long)(DBL_PTR(_ok_46900)->dbl);
        DeRefDS(_ok_46900);
        _ok_46900 = _1;
    }

    /** 	Resolve_unincluded_globals = ok*/
    _52Resolve_unincluded_globals_46897 = _ok_46900;

    /** end procedure*/
    return;
    ;
}


int _52get_resolve_unincluded_globals()
{
    int _0, _1, _2;
    

    /** 	return Resolve_unincluded_globals*/
    return _52Resolve_unincluded_globals_46897;
    ;
}


int _52keyfind(int _word_46906, int _file_no_46907, int _scanning_file_46908, int _namespace_ok_46911, int _hashval_46912)
{
    int _msg_46914 = NOVALUE;
    int _b_name_46915 = NOVALUE;
    int _scope_46916 = NOVALUE;
    int _defined_46917 = NOVALUE;
    int _ix_46918 = NOVALUE;
    int _st_ptr_46920 = NOVALUE;
    int _st_builtin_46921 = NOVALUE;
    int _tok_46923 = NOVALUE;
    int _gtok_46924 = NOVALUE;
    int _any_symbol_46927 = NOVALUE;
    int _tok_file_47095 = NOVALUE;
    int _good_47102 = NOVALUE;
    int _include_type_47112 = NOVALUE;
    int _msg_file_47168 = NOVALUE;
    int _24813 = NOVALUE;
    int _24812 = NOVALUE;
    int _24810 = NOVALUE;
    int _24808 = NOVALUE;
    int _24807 = NOVALUE;
    int _24806 = NOVALUE;
    int _24805 = NOVALUE;
    int _24804 = NOVALUE;
    int _24802 = NOVALUE;
    int _24800 = NOVALUE;
    int _24799 = NOVALUE;
    int _24798 = NOVALUE;
    int _24797 = NOVALUE;
    int _24796 = NOVALUE;
    int _24795 = NOVALUE;
    int _24794 = NOVALUE;
    int _24793 = NOVALUE;
    int _24791 = NOVALUE;
    int _24790 = NOVALUE;
    int _24789 = NOVALUE;
    int _24788 = NOVALUE;
    int _24787 = NOVALUE;
    int _24786 = NOVALUE;
    int _24785 = NOVALUE;
    int _24784 = NOVALUE;
    int _24783 = NOVALUE;
    int _24782 = NOVALUE;
    int _24781 = NOVALUE;
    int _24780 = NOVALUE;
    int _24779 = NOVALUE;
    int _24778 = NOVALUE;
    int _24777 = NOVALUE;
    int _24776 = NOVALUE;
    int _24775 = NOVALUE;
    int _24773 = NOVALUE;
    int _24772 = NOVALUE;
    int _24769 = NOVALUE;
    int _24765 = NOVALUE;
    int _24763 = NOVALUE;
    int _24762 = NOVALUE;
    int _24761 = NOVALUE;
    int _24760 = NOVALUE;
    int _24759 = NOVALUE;
    int _24757 = NOVALUE;
    int _24756 = NOVALUE;
    int _24755 = NOVALUE;
    int _24754 = NOVALUE;
    int _24752 = NOVALUE;
    int _24749 = NOVALUE;
    int _24748 = NOVALUE;
    int _24747 = NOVALUE;
    int _24746 = NOVALUE;
    int _24744 = NOVALUE;
    int _24741 = NOVALUE;
    int _24740 = NOVALUE;
    int _24739 = NOVALUE;
    int _24738 = NOVALUE;
    int _24737 = NOVALUE;
    int _24736 = NOVALUE;
    int _24735 = NOVALUE;
    int _24732 = NOVALUE;
    int _24731 = NOVALUE;
    int _24729 = NOVALUE;
    int _24727 = NOVALUE;
    int _24725 = NOVALUE;
    int _24724 = NOVALUE;
    int _24723 = NOVALUE;
    int _24719 = NOVALUE;
    int _24718 = NOVALUE;
    int _24713 = NOVALUE;
    int _24711 = NOVALUE;
    int _24709 = NOVALUE;
    int _24708 = NOVALUE;
    int _24704 = NOVALUE;
    int _24703 = NOVALUE;
    int _24701 = NOVALUE;
    int _24700 = NOVALUE;
    int _24698 = NOVALUE;
    int _24697 = NOVALUE;
    int _24696 = NOVALUE;
    int _24695 = NOVALUE;
    int _24694 = NOVALUE;
    int _24692 = NOVALUE;
    int _24691 = NOVALUE;
    int _24690 = NOVALUE;
    int _24689 = NOVALUE;
    int _24688 = NOVALUE;
    int _24687 = NOVALUE;
    int _24686 = NOVALUE;
    int _24685 = NOVALUE;
    int _24684 = NOVALUE;
    int _24683 = NOVALUE;
    int _24682 = NOVALUE;
    int _24681 = NOVALUE;
    int _24680 = NOVALUE;
    int _24679 = NOVALUE;
    int _24678 = NOVALUE;
    int _24677 = NOVALUE;
    int _24676 = NOVALUE;
    int _24675 = NOVALUE;
    int _24674 = NOVALUE;
    int _24673 = NOVALUE;
    int _24672 = NOVALUE;
    int _24671 = NOVALUE;
    int _24669 = NOVALUE;
    int _24668 = NOVALUE;
    int _24666 = NOVALUE;
    int _24665 = NOVALUE;
    int _24664 = NOVALUE;
    int _24663 = NOVALUE;
    int _24662 = NOVALUE;
    int _24660 = NOVALUE;
    int _24659 = NOVALUE;
    int _24658 = NOVALUE;
    int _24656 = NOVALUE;
    int _24655 = NOVALUE;
    int _24654 = NOVALUE;
    int _24653 = NOVALUE;
    int _24652 = NOVALUE;
    int _24651 = NOVALUE;
    int _24650 = NOVALUE;
    int _24648 = NOVALUE;
    int _24647 = NOVALUE;
    int _24642 = NOVALUE;
    int _24639 = NOVALUE;
    int _24638 = NOVALUE;
    int _24637 = NOVALUE;
    int _24636 = NOVALUE;
    int _24635 = NOVALUE;
    int _24634 = NOVALUE;
    int _24633 = NOVALUE;
    int _24632 = NOVALUE;
    int _24631 = NOVALUE;
    int _24630 = NOVALUE;
    int _24629 = NOVALUE;
    int _24628 = NOVALUE;
    int _24627 = NOVALUE;
    int _24626 = NOVALUE;
    int _24625 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_file_no_46907)) {
        _1 = (long)(DBL_PTR(_file_no_46907)->dbl);
        DeRefDS(_file_no_46907);
        _file_no_46907 = _1;
    }
    if (!IS_ATOM_INT(_scanning_file_46908)) {
        _1 = (long)(DBL_PTR(_scanning_file_46908)->dbl);
        DeRefDS(_scanning_file_46908);
        _scanning_file_46908 = _1;
    }
    if (!IS_ATOM_INT(_namespace_ok_46911)) {
        _1 = (long)(DBL_PTR(_namespace_ok_46911)->dbl);
        DeRefDS(_namespace_ok_46911);
        _namespace_ok_46911 = _1;
    }
    if (!IS_ATOM_INT(_hashval_46912)) {
        _1 = (long)(DBL_PTR(_hashval_46912)->dbl);
        DeRefDS(_hashval_46912);
        _hashval_46912 = _1;
    }

    /** 	dup_globals = {}*/
    RefDS(_21829);
    DeRef(_52dup_globals_46892);
    _52dup_globals_46892 = _21829;

    /** 	dup_overrides = {}*/
    RefDS(_21829);
    DeRefi(_52dup_overrides_46893);
    _52dup_overrides_46893 = _21829;

    /** 	in_include_path = {}*/
    RefDS(_21829);
    DeRef(_52in_include_path_46894);
    _52in_include_path_46894 = _21829;

    /** 	symbol_resolution_warning = ""*/
    RefDS(_21829);
    DeRef(_12symbol_resolution_warning_11784);
    _12symbol_resolution_warning_11784 = _21829;

    /** 	st_builtin = 0*/
    _st_builtin_46921 = 0;

    /** 	ifdef EUDIS then*/

    /** 	st_ptr = buckets[hashval]*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _st_ptr_46920 = (int)*(((s1_ptr)_2)->base + _hashval_46912);
    if (!IS_ATOM_INT(_st_ptr_46920)){
        _st_ptr_46920 = (long)DBL_PTR(_st_ptr_46920)->dbl;
    }

    /** 	integer any_symbol = namespace_ok = -1*/
    _any_symbol_46927 = (_namespace_ok_46911 == -1);

    /** 	while st_ptr do*/
L1: 
    if (_st_ptr_46920 == 0)
    {
        goto L2; // [69] 1033
    }
    else{
    }

    /** 		if SymTab[st_ptr][S_SCOPE] != SC_UNDEFINED */
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24625 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24625);
    _24626 = (int)*(((s1_ptr)_2)->base + 4);
    _24625 = NOVALUE;
    if (IS_ATOM_INT(_24626)) {
        _24627 = (_24626 != 9);
    }
    else {
        _24627 = binary_op(NOTEQ, _24626, 9);
    }
    _24626 = NOVALUE;
    if (IS_ATOM_INT(_24627)) {
        if (_24627 == 0) {
            DeRef(_24628);
            _24628 = 0;
            goto L3; // [92] 116
        }
    }
    else {
        if (DBL_PTR(_24627)->dbl == 0.0) {
            DeRef(_24628);
            _24628 = 0;
            goto L3; // [92] 116
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24629 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24629);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24630 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24630 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24629 = NOVALUE;
    if (_word_46906 == _24630)
    _24631 = 1;
    else if (IS_ATOM_INT(_word_46906) && IS_ATOM_INT(_24630))
    _24631 = 0;
    else
    _24631 = (compare(_word_46906, _24630) == 0);
    _24630 = NOVALUE;
    DeRef(_24628);
    _24628 = (_24631 != 0);
L3: 
    if (_24628 == 0) {
        goto L4; // [116] 1012
    }
    if (_any_symbol_46927 != 0) {
        DeRef(_24633);
        _24633 = 1;
        goto L5; // [120] 150
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24634 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24634);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24635 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24635 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24634 = NOVALUE;
    if (IS_ATOM_INT(_24635)) {
        _24636 = (_24635 == 523);
    }
    else {
        _24636 = binary_op(EQUALS, _24635, 523);
    }
    _24635 = NOVALUE;
    if (IS_ATOM_INT(_24636)) {
        _24637 = (_namespace_ok_46911 == _24636);
    }
    else {
        _24637 = binary_op(EQUALS, _namespace_ok_46911, _24636);
    }
    DeRef(_24636);
    _24636 = NOVALUE;
    if (IS_ATOM_INT(_24637))
    _24633 = (_24637 != 0);
    else
    _24633 = DBL_PTR(_24637)->dbl != 0.0;
L5: 
    if (_24633 == 0)
    {
        _24633 = NOVALUE;
        goto L4; // [151] 1012
    }
    else{
        _24633 = NOVALUE;
    }

    /** 			tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24638 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24638);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24639 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24639 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24638 = NOVALUE;
    Ref(_24639);
    DeRef(_tok_46923);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24639;
    ((int *)_2)[2] = _st_ptr_46920;
    _tok_46923 = MAKE_SEQ(_1);
    _24639 = NOVALUE;

    /** 			if file_no = -1 then*/
    if (_file_no_46907 != -1)
    goto L6; // [174] 714

    /** 				scope = SymTab[st_ptr][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24642 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24642);
    _scope_46916 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46916)){
        _scope_46916 = (long)DBL_PTR(_scope_46916)->dbl;
    }
    _24642 = NOVALUE;

    /** 				switch scope with fallthru do*/
    _0 = _scope_46916;
    switch ( _0 ){ 

        /** 				case SC_OVERRIDE then*/
        case 12:

        /** 					dup_overrides &= st_ptr*/
        Append(&_52dup_overrides_46893, _52dup_overrides_46893, _st_ptr_46920);

        /** 					break*/
        goto L7; // [215] 1011

        /** 				case SC_PREDEF then*/
        case 7:

        /** 					st_builtin = st_ptr*/
        _st_builtin_46921 = _st_ptr_46920;

        /** 					break*/
        goto L7; // [230] 1011

        /** 				case SC_GLOBAL then*/
        case 6:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24647 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24647);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24648 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24648 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24647 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46908, _24648)){
            _24648 = NOVALUE;
            goto L8; // [250] 274
        }
        _24648 = NOVALUE;

        /** 						if BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto L9; // [258] 267
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46923);
        _52add_ref(_tok_46923);
L9: 

        /** 						return tok*/
        DeRefDS(_word_46906);
        DeRef(_msg_46914);
        DeRef(_b_name_46915);
        DeRef(_gtok_46924);
        DeRef(_24637);
        _24637 = NOVALUE;
        DeRef(_24627);
        _24627 = NOVALUE;
        return _tok_46923;
L8: 

        /** 					if Resolve_unincluded_globals */
        if (_52Resolve_unincluded_globals_46897 != 0) {
            _24650 = 1;
            goto LA; // [278] 322
        }
        _2 = (int)SEQ_PTR(_13finished_files_10639);
        _24651 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        if (_24651 == 0) {
            _24652 = 0;
            goto LB; // [288] 318
        }
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24653 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24654 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24654);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24655 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24655 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24654 = NOVALUE;
        _2 = (int)SEQ_PTR(_24653);
        if (!IS_ATOM_INT(_24655)){
            _24656 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24655)->dbl));
        }
        else{
            _24656 = (int)*(((s1_ptr)_2)->base + _24655);
        }
        _24653 = NOVALUE;
        if (IS_ATOM_INT(_24656))
        _24652 = (_24656 != 0);
        else
        _24652 = DBL_PTR(_24656)->dbl != 0.0;
LB: 
        _24650 = (_24652 != 0);
LA: 
        if (_24650 != 0) {
            goto LC; // [322] 349
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24658 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24658);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _24659 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _24659 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _24658 = NOVALUE;
        if (IS_ATOM_INT(_24659)) {
            _24660 = (_24659 == 523);
        }
        else {
            _24660 = binary_op(EQUALS, _24659, 523);
        }
        _24659 = NOVALUE;
        if (_24660 == 0) {
            DeRef(_24660);
            _24660 = NOVALUE;
            goto L7; // [345] 1011
        }
        else {
            if (!IS_ATOM_INT(_24660) && DBL_PTR(_24660)->dbl == 0.0){
                DeRef(_24660);
                _24660 = NOVALUE;
                goto L7; // [345] 1011
            }
            DeRef(_24660);
            _24660 = NOVALUE;
        }
        DeRef(_24660);
        _24660 = NOVALUE;
LC: 

        /** 						gtok = tok*/
        Ref(_tok_46923);
        DeRef(_gtok_46924);
        _gtok_46924 = _tok_46923;

        /** 						dup_globals &= st_ptr*/
        Append(&_52dup_globals_46892, _52dup_globals_46892, _st_ptr_46920);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24662 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24663 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24663);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24664 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24664 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24663 = NOVALUE;
        _2 = (int)SEQ_PTR(_24662);
        if (!IS_ATOM_INT(_24664)){
            _24665 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24664)->dbl));
        }
        else{
            _24665 = (int)*(((s1_ptr)_2)->base + _24664);
        }
        _24662 = NOVALUE;
        if (IS_ATOM_INT(_24665)) {
            _24666 = (_24665 != 0);
        }
        else {
            _24666 = binary_op(NOTEQ, _24665, 0);
        }
        _24665 = NOVALUE;
        if (IS_SEQUENCE(_52in_include_path_46894) && IS_ATOM(_24666)) {
            Ref(_24666);
            Append(&_52in_include_path_46894, _52in_include_path_46894, _24666);
        }
        else if (IS_ATOM(_52in_include_path_46894) && IS_SEQUENCE(_24666)) {
        }
        else {
            Concat((object_ptr)&_52in_include_path_46894, _52in_include_path_46894, _24666);
        }
        DeRef(_24666);
        _24666 = NOVALUE;

        /** 					break*/
        goto L7; // [399] 1011

        /** 				case SC_PUBLIC, SC_EXPORT then*/
        case 13:
        case 11:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24668 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24668);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24669 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24669 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24668 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46908, _24669)){
            _24669 = NOVALUE;
            goto LD; // [421] 445
        }
        _24669 = NOVALUE;

        /** 						if BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto LE; // [429] 438
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46923);
        _52add_ref(_tok_46923);
LE: 

        /** 						return tok*/
        DeRefDS(_word_46906);
        DeRef(_msg_46914);
        DeRef(_b_name_46915);
        DeRef(_gtok_46924);
        DeRef(_24637);
        _24637 = NOVALUE;
        DeRef(_24627);
        _24627 = NOVALUE;
        _24651 = NOVALUE;
        _24656 = NOVALUE;
        _24655 = NOVALUE;
        _24664 = NOVALUE;
        return _tok_46923;
LD: 

        /** 					if (finished_files[scanning_file] -- everything this file needs has been read in*/
        _2 = (int)SEQ_PTR(_13finished_files_10639);
        _24671 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        if (_24671 != 0) {
            _24672 = 1;
            goto LF; // [453] 487
        }
        if (_namespace_ok_46911 == 0) {
            _24673 = 0;
            goto L10; // [457] 483
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24674 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24674);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _24675 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _24675 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _24674 = NOVALUE;
        if (IS_ATOM_INT(_24675)) {
            _24676 = (_24675 == 523);
        }
        else {
            _24676 = binary_op(EQUALS, _24675, 523);
        }
        _24675 = NOVALUE;
        if (IS_ATOM_INT(_24676))
        _24673 = (_24676 != 0);
        else
        _24673 = DBL_PTR(_24676)->dbl != 0.0;
L10: 
        _24672 = (_24673 != 0);
LF: 
        if (_24672 == 0) {
            goto L7; // [487] 1011
        }
        _24678 = (_scope_46916 == 13);
        if (_24678 == 0) {
            _24679 = 0;
            goto L11; // [497] 533
        }
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24680 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24681 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24681);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24682 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24682 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24681 = NOVALUE;
        _2 = (int)SEQ_PTR(_24680);
        if (!IS_ATOM_INT(_24682)){
            _24683 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24682)->dbl));
        }
        else{
            _24683 = (int)*(((s1_ptr)_2)->base + _24682);
        }
        _24680 = NOVALUE;
        if (IS_ATOM_INT(_24683)) {
            {unsigned long tu;
                 tu = (unsigned long)6 & (unsigned long)_24683;
                 _24684 = MAKE_UINT(tu);
            }
        }
        else {
            _24684 = binary_op(AND_BITS, 6, _24683);
        }
        _24683 = NOVALUE;
        if (IS_ATOM_INT(_24684))
        _24679 = (_24684 != 0);
        else
        _24679 = DBL_PTR(_24684)->dbl != 0.0;
L11: 
        if (_24679 != 0) {
            DeRef(_24685);
            _24685 = 1;
            goto L12; // [533] 583
        }
        _24686 = (_scope_46916 == 11);
        if (_24686 == 0) {
            _24687 = 0;
            goto L13; // [543] 579
        }
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24688 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24689 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24689);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24690 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24690 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24689 = NOVALUE;
        _2 = (int)SEQ_PTR(_24688);
        if (!IS_ATOM_INT(_24690)){
            _24691 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24690)->dbl));
        }
        else{
            _24691 = (int)*(((s1_ptr)_2)->base + _24690);
        }
        _24688 = NOVALUE;
        if (IS_ATOM_INT(_24691)) {
            {unsigned long tu;
                 tu = (unsigned long)2 & (unsigned long)_24691;
                 _24692 = MAKE_UINT(tu);
            }
        }
        else {
            _24692 = binary_op(AND_BITS, 2, _24691);
        }
        _24691 = NOVALUE;
        if (IS_ATOM_INT(_24692))
        _24687 = (_24692 != 0);
        else
        _24687 = DBL_PTR(_24692)->dbl != 0.0;
L13: 
        DeRef(_24685);
        _24685 = (_24687 != 0);
L12: 
        if (_24685 == 0)
        {
            _24685 = NOVALUE;
            goto L7; // [584] 1011
        }
        else{
            _24685 = NOVALUE;
        }

        /** 						gtok = tok*/
        Ref(_tok_46923);
        DeRef(_gtok_46924);
        _gtok_46924 = _tok_46923;

        /** 						dup_globals &= st_ptr*/
        Append(&_52dup_globals_46892, _52dup_globals_46892, _st_ptr_46920);

        /** 						in_include_path &= include_matrix[scanning_file][SymTab[st_ptr][S_FILE_NO]] != 0 --symbol_in_include_path( st_ptr, scanning_file, {} )*/
        _2 = (int)SEQ_PTR(_13include_matrix_10643);
        _24694 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24695 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24695);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24696 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24696 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24695 = NOVALUE;
        _2 = (int)SEQ_PTR(_24694);
        if (!IS_ATOM_INT(_24696)){
            _24697 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24696)->dbl));
        }
        else{
            _24697 = (int)*(((s1_ptr)_2)->base + _24696);
        }
        _24694 = NOVALUE;
        if (IS_ATOM_INT(_24697)) {
            _24698 = (_24697 != 0);
        }
        else {
            _24698 = binary_op(NOTEQ, _24697, 0);
        }
        _24697 = NOVALUE;
        if (IS_SEQUENCE(_52in_include_path_46894) && IS_ATOM(_24698)) {
            Ref(_24698);
            Append(&_52in_include_path_46894, _52in_include_path_46894, _24698);
        }
        else if (IS_ATOM(_52in_include_path_46894) && IS_SEQUENCE(_24698)) {
        }
        else {
            Concat((object_ptr)&_52in_include_path_46894, _52in_include_path_46894, _24698);
        }
        DeRef(_24698);
        _24698 = NOVALUE;

        /** ifdef STDDEBUG then*/

        /** 					break*/
        goto L7; // [639] 1011

        /** 				case SC_LOCAL then*/
        case 5:

        /** 					if scanning_file = SymTab[st_ptr][S_FILE_NO] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24700 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
        _2 = (int)SEQ_PTR(_24700);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24701 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24701 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24700 = NOVALUE;
        if (binary_op_a(NOTEQ, _scanning_file_46908, _24701)){
            _24701 = NOVALUE;
            goto L7; // [659] 1011
        }
        _24701 = NOVALUE;

        /** 						if BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto L14; // [667] 676
        }
        else{
        }

        /** 							add_ref(tok)*/
        Ref(_tok_46923);
        _52add_ref(_tok_46923);
L14: 

        /** 						return tok*/
        DeRefDS(_word_46906);
        DeRef(_msg_46914);
        DeRef(_b_name_46915);
        DeRef(_gtok_46924);
        DeRef(_24637);
        _24637 = NOVALUE;
        DeRef(_24627);
        _24627 = NOVALUE;
        _24651 = NOVALUE;
        _24656 = NOVALUE;
        _24655 = NOVALUE;
        _24671 = NOVALUE;
        _24664 = NOVALUE;
        DeRef(_24678);
        _24678 = NOVALUE;
        DeRef(_24676);
        _24676 = NOVALUE;
        DeRef(_24686);
        _24686 = NOVALUE;
        _24682 = NOVALUE;
        DeRef(_24684);
        _24684 = NOVALUE;
        _24690 = NOVALUE;
        DeRef(_24692);
        _24692 = NOVALUE;
        _24696 = NOVALUE;
        return _tok_46923;

        /** 					break*/
        goto L7; // [685] 1011

        /** 				case else*/
        default:

        /** 					if BIND then*/
        if (_12BIND_11322 == 0)
        {
            goto L15; // [695] 704
        }
        else{
        }

        /** 						add_ref(tok)*/
        Ref(_tok_46923);
        _52add_ref(_tok_46923);
L15: 

        /** 					return tok -- keyword, private*/
        DeRefDS(_word_46906);
        DeRef(_msg_46914);
        DeRef(_b_name_46915);
        DeRef(_gtok_46924);
        DeRef(_24637);
        _24637 = NOVALUE;
        DeRef(_24627);
        _24627 = NOVALUE;
        _24651 = NOVALUE;
        _24656 = NOVALUE;
        _24655 = NOVALUE;
        _24671 = NOVALUE;
        _24664 = NOVALUE;
        DeRef(_24678);
        _24678 = NOVALUE;
        DeRef(_24676);
        _24676 = NOVALUE;
        DeRef(_24686);
        _24686 = NOVALUE;
        _24682 = NOVALUE;
        DeRef(_24684);
        _24684 = NOVALUE;
        _24690 = NOVALUE;
        DeRef(_24692);
        _24692 = NOVALUE;
        _24696 = NOVALUE;
        return _tok_46923;
    ;}    goto L7; // [711] 1011
L6: 

    /** 				scope = SymTab[tok[T_SYM]][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_tok_46923);
    _24703 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_24703)){
        _24704 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24703)->dbl));
    }
    else{
        _24704 = (int)*(((s1_ptr)_2)->base + _24703);
    }
    _2 = (int)SEQ_PTR(_24704);
    _scope_46916 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_46916)){
        _scope_46916 = (long)DBL_PTR(_scope_46916)->dbl;
    }
    _24704 = NOVALUE;

    /** 				if not file_no then*/
    if (_file_no_46907 != 0)
    goto L16; // [738] 772

    /** 					if scope = SC_PREDEF then*/
    if (_scope_46916 != 7)
    goto L17; // [745] 1010

    /** 						if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L18; // [753] 762
    }
    else{
    }

    /** 							add_ref( tok )*/
    Ref(_tok_46923);
    _52add_ref(_tok_46923);
L18: 

    /** 						return tok*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_gtok_46924);
    DeRef(_24637);
    _24637 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24651 = NOVALUE;
    _24656 = NOVALUE;
    _24655 = NOVALUE;
    _24671 = NOVALUE;
    _24664 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    _24703 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24696 = NOVALUE;
    return _tok_46923;
    goto L17; // [769] 1010
L16: 

    /** 					integer tok_file = SymTab[tok[T_SYM]][S_FILE_NO]*/
    _2 = (int)SEQ_PTR(_tok_46923);
    _24708 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_24708)){
        _24709 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24708)->dbl));
    }
    else{
        _24709 = (int)*(((s1_ptr)_2)->base + _24708);
    }
    _2 = (int)SEQ_PTR(_24709);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _tok_file_47095 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _tok_file_47095 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (!IS_ATOM_INT(_tok_file_47095)){
        _tok_file_47095 = (long)DBL_PTR(_tok_file_47095)->dbl;
    }
    _24709 = NOVALUE;

    /** 					integer good = 0*/
    _good_47102 = 0;

    /** 					if scope = SC_PRIVATE or scope = SC_PREDEF then*/
    _24711 = (_scope_46916 == 3);
    if (_24711 != 0) {
        goto L19; // [807] 940
    }
    _24713 = (_scope_46916 == 7);
    if (_24713 == 0)
    {
        DeRef(_24713);
        _24713 = NOVALUE;
        goto L1A; // [818] 825
    }
    else{
        DeRef(_24713);
        _24713 = NOVALUE;
    }
    goto L19; // [822] 940
L1A: 

    /** 					elsif file_no = tok_file then*/
    if (_file_no_46907 != _tok_file_47095)
    goto L1B; // [827] 839

    /** 						good = 1*/
    _good_47102 = 1;
    goto L19; // [836] 940
L1B: 

    /** 						integer include_type = 0*/
    _include_type_47112 = 0;

    /** 						switch scope do*/
    _0 = _scope_46916;
    switch ( _0 ){ 

        /** 							case SC_GLOBAL then*/
        case 6:

        /** 								if Resolve_unincluded_globals then*/
        if (_52Resolve_unincluded_globals_46897 == 0)
        {
            goto L1C; // [859] 874
        }
        else{
        }

        /** 									include_type = ANY_INCLUDE*/
        _include_type_47112 = 7;
        goto L1D; // [871] 919
L1C: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47112 = 6;
        goto L1D; // [884] 919

        /** 							case SC_PUBLIC then*/
        case 13:

        /** 								if tok_file != file_no then*/
        if (_tok_file_47095 == _file_no_46907)
        goto L1E; // [892] 908

        /** 									include_type = PUBLIC_INCLUDE*/
        _include_type_47112 = 4;
        goto L1F; // [905] 918
L1E: 

        /** 									include_type = DIRECT_OR_PUBLIC_INCLUDE*/
        _include_type_47112 = 6;
L1F: 
    ;}L1D: 

    /** 						good = and_bits( include_type, include_matrix[file_no][tok_file] )*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _24718 = (int)*(((s1_ptr)_2)->base + _file_no_46907);
    _2 = (int)SEQ_PTR(_24718);
    _24719 = (int)*(((s1_ptr)_2)->base + _tok_file_47095);
    _24718 = NOVALUE;
    if (IS_ATOM_INT(_24719)) {
        {unsigned long tu;
             tu = (unsigned long)_include_type_47112 & (unsigned long)_24719;
             _good_47102 = MAKE_UINT(tu);
        }
    }
    else {
        _good_47102 = binary_op(AND_BITS, _include_type_47112, _24719);
    }
    _24719 = NOVALUE;
    if (!IS_ATOM_INT(_good_47102)) {
        _1 = (long)(DBL_PTR(_good_47102)->dbl);
        DeRefDS(_good_47102);
        _good_47102 = _1;
    }
L19: 

    /** 					if good then*/
    if (_good_47102 == 0)
    {
        goto L20; // [942] 1007
    }
    else{
    }

    /** 						if file_no = tok_file then*/
    if (_file_no_46907 != _tok_file_47095)
    goto L21; // [947] 971

    /** 							if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L22; // [955] 964
    }
    else{
    }

    /** 								add_ref(tok)*/
    Ref(_tok_46923);
    _52add_ref(_tok_46923);
L22: 

    /** 							return tok*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_gtok_46924);
    DeRef(_24637);
    _24637 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24651 = NOVALUE;
    _24656 = NOVALUE;
    _24655 = NOVALUE;
    _24671 = NOVALUE;
    _24664 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    _24703 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24696 = NOVALUE;
    _24708 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    return _tok_46923;
L21: 

    /** 						gtok = tok*/
    Ref(_tok_46923);
    DeRef(_gtok_46924);
    _gtok_46924 = _tok_46923;

    /** 						dup_globals &= st_ptr*/
    Append(&_52dup_globals_46892, _52dup_globals_46892, _st_ptr_46920);

    /** 						in_include_path &= include_matrix[scanning_file][tok_file] != 0*/
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _24723 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
    _2 = (int)SEQ_PTR(_24723);
    _24724 = (int)*(((s1_ptr)_2)->base + _tok_file_47095);
    _24723 = NOVALUE;
    if (IS_ATOM_INT(_24724)) {
        _24725 = (_24724 != 0);
    }
    else {
        _24725 = binary_op(NOTEQ, _24724, 0);
    }
    _24724 = NOVALUE;
    if (IS_SEQUENCE(_52in_include_path_46894) && IS_ATOM(_24725)) {
        Ref(_24725);
        Append(&_52in_include_path_46894, _52in_include_path_46894, _24725);
    }
    else if (IS_ATOM(_52in_include_path_46894) && IS_SEQUENCE(_24725)) {
    }
    else {
        Concat((object_ptr)&_52in_include_path_46894, _52in_include_path_46894, _24725);
    }
    DeRef(_24725);
    _24725 = NOVALUE;
L20: 
L17: 
L7: 
L4: 

    /** 		st_ptr = SymTab[st_ptr][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24727 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24727);
    _st_ptr_46920 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_st_ptr_46920)){
        _st_ptr_46920 = (long)DBL_PTR(_st_ptr_46920)->dbl;
    }
    _24727 = NOVALUE;

    /** 	end while*/
    goto L1; // [1030] 69
L2: 

    /** 	if length(dup_overrides) then*/
    if (IS_SEQUENCE(_52dup_overrides_46893)){
            _24729 = SEQ_PTR(_52dup_overrides_46893)->length;
    }
    else {
        _24729 = 1;
    }
    if (_24729 == 0)
    {
        _24729 = NOVALUE;
        goto L23; // [1040] 1093
    }
    else{
        _24729 = NOVALUE;
    }

    /** 		st_ptr = dup_overrides[1]*/
    _2 = (int)SEQ_PTR(_52dup_overrides_46893);
    _st_ptr_46920 = (int)*(((s1_ptr)_2)->base + 1);

    /** 		tok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24731 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24731);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24732 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24732 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24731 = NOVALUE;
    Ref(_24732);
    DeRef(_tok_46923);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24732;
    ((int *)_2)[2] = _st_ptr_46920;
    _tok_46923 = MAKE_SEQ(_1);
    _24732 = NOVALUE;

    /** 			if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L24; // [1075] 1084
    }
    else{
    }

    /** 				add_ref(tok)*/
    RefDS(_tok_46923);
    _52add_ref(_tok_46923);
L24: 

    /** 			return tok*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_gtok_46924);
    DeRef(_24637);
    _24637 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24651 = NOVALUE;
    _24656 = NOVALUE;
    _24655 = NOVALUE;
    _24671 = NOVALUE;
    _24664 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    _24703 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24696 = NOVALUE;
    _24708 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    return _tok_46923;
    goto L25; // [1090] 1320
L23: 

    /** 	elsif st_builtin != 0 then*/
    if (_st_builtin_46921 == 0)
    goto L26; // [1095] 1319

    /** 		if length(dup_globals) and find(SymTab[st_builtin][S_NAME], builtin_warnings) = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24735 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24735 = 1;
    }
    if (_24735 == 0) {
        goto L27; // [1106] 1279
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24737 = (int)*(((s1_ptr)_2)->base + _st_builtin_46921);
    _2 = (int)SEQ_PTR(_24737);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24738 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24738 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24737 = NOVALUE;
    _24739 = find_from(_24738, _52builtin_warnings_46896, 1);
    _24738 = NOVALUE;
    _24740 = (_24739 == 0);
    _24739 = NOVALUE;
    if (_24740 == 0)
    {
        DeRef(_24740);
        _24740 = NOVALUE;
        goto L27; // [1134] 1279
    }
    else{
        DeRef(_24740);
        _24740 = NOVALUE;
    }

    /** 			sequence msg_file */

    /** 			b_name = SymTab[st_builtin][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24741 = (int)*(((s1_ptr)_2)->base + _st_builtin_46921);
    DeRef(_b_name_46915);
    _2 = (int)SEQ_PTR(_24741);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _b_name_46915 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _b_name_46915 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_b_name_46915);
    _24741 = NOVALUE;

    /** 			builtin_warnings = append(builtin_warnings, b_name)*/
    RefDS(_b_name_46915);
    Append(&_52builtin_warnings_46896, _52builtin_warnings_46896, _b_name_46915);

    /** 			if length(dup_globals) > 1 then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24744 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24744 = 1;
    }
    if (_24744 <= 1)
    goto L28; // [1170] 1184

    /** 				msg = "\n"*/
    RefDS(_21981);
    DeRef(_msg_46914);
    _msg_46914 = _21981;
    goto L29; // [1181] 1192
L28: 

    /** 				msg = ""*/
    RefDS(_21829);
    DeRef(_msg_46914);
    _msg_46914 = _21829;
L29: 

    /** 			for i = 1 to length(dup_globals) do*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24746 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24746 = 1;
    }
    {
        int _i_47179;
        _i_47179 = 1;
L2A: 
        if (_i_47179 > _24746){
            goto L2B; // [1199] 1255
        }

        /** 				msg_file = known_files[SymTab[dup_globals[i]][S_FILE_NO]]*/
        _2 = (int)SEQ_PTR(_52dup_globals_46892);
        _24747 = (int)*(((s1_ptr)_2)->base + _i_47179);
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_24747)){
            _24748 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24747)->dbl));
        }
        else{
            _24748 = (int)*(((s1_ptr)_2)->base + _24747);
        }
        _2 = (int)SEQ_PTR(_24748);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _24749 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _24749 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _24748 = NOVALUE;
        DeRef(_msg_file_47168);
        _2 = (int)SEQ_PTR(_13known_files_10637);
        if (!IS_ATOM_INT(_24749)){
            _msg_file_47168 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24749)->dbl));
        }
        else{
            _msg_file_47168 = (int)*(((s1_ptr)_2)->base + _24749);
        }
        Ref(_msg_file_47168);

        /** 				msg &= "    " & msg_file & "\n"*/
        {
            int concat_list[3];

            concat_list[0] = _21981;
            concat_list[1] = _msg_file_47168;
            concat_list[2] = _24751;
            Concat_N((object_ptr)&_24752, concat_list, 3);
        }
        Concat((object_ptr)&_msg_46914, _msg_46914, _24752);
        DeRefDS(_24752);
        _24752 = NOVALUE;

        /** 			end for*/
        _i_47179 = _i_47179 + 1;
        goto L2A; // [1250] 1206
L2B: 
        ;
    }

    /** 			Warning(234, builtin_chosen_warning_flag, {b_name, known_files[scanning_file], msg})*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _24754 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_b_name_46915);
    *((int *)(_2+4)) = _b_name_46915;
    Ref(_24754);
    *((int *)(_2+8)) = _24754;
    RefDS(_msg_46914);
    *((int *)(_2+12)) = _msg_46914;
    _24755 = MAKE_SEQ(_1);
    _24754 = NOVALUE;
    _43Warning(234, 8, _24755);
    _24755 = NOVALUE;
L27: 
    DeRef(_msg_file_47168);
    _msg_file_47168 = NOVALUE;

    /** 		tok = {SymTab[st_builtin][S_TOKEN], st_builtin}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24756 = (int)*(((s1_ptr)_2)->base + _st_builtin_46921);
    _2 = (int)SEQ_PTR(_24756);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24757 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24757 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24756 = NOVALUE;
    Ref(_24757);
    DeRef(_tok_46923);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24757;
    ((int *)_2)[2] = _st_builtin_46921;
    _tok_46923 = MAKE_SEQ(_1);
    _24757 = NOVALUE;

    /** 		if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L2C; // [1303] 1312
    }
    else{
    }

    /** 			add_ref(tok)*/
    RefDS(_tok_46923);
    _52add_ref(_tok_46923);
L2C: 

    /** 		return tok*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_gtok_46924);
    DeRef(_24637);
    _24637 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24651 = NOVALUE;
    _24656 = NOVALUE;
    _24655 = NOVALUE;
    _24671 = NOVALUE;
    _24664 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    _24703 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24696 = NOVALUE;
    _24708 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    _24747 = NOVALUE;
    _24749 = NOVALUE;
    return _tok_46923;
L26: 
L25: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) > 1 and find( 1, in_include_path ) then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24759 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24759 = 1;
    }
    _24760 = (_24759 > 1);
    _24759 = NOVALUE;
    if (_24760 == 0) {
        goto L2D; // [1333] 1452
    }
    _24762 = find_from(1, _52in_include_path_46894, 1);
    if (_24762 == 0)
    {
        _24762 = NOVALUE;
        goto L2D; // [1345] 1452
    }
    else{
        _24762 = NOVALUE;
    }

    /** 		ix = 1*/
    _ix_46918 = 1;

    /** 		while ix <= length(dup_globals) do*/
L2E: 
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24763 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24763 = 1;
    }
    if (_ix_46918 > _24763)
    goto L2F; // [1363] 1411

    /** 			if in_include_path[ix] then*/
    _2 = (int)SEQ_PTR(_52in_include_path_46894);
    _24765 = (int)*(((s1_ptr)_2)->base + _ix_46918);
    if (_24765 == 0) {
        _24765 = NOVALUE;
        goto L30; // [1375] 1387
    }
    else {
        if (!IS_ATOM_INT(_24765) && DBL_PTR(_24765)->dbl == 0.0){
            _24765 = NOVALUE;
            goto L30; // [1375] 1387
        }
        _24765 = NOVALUE;
    }
    _24765 = NOVALUE;

    /** 				ix += 1*/
    _ix_46918 = _ix_46918 + 1;
    goto L2E; // [1384] 1358
L30: 

    /** 				dup_globals     = remove( dup_globals, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_52dup_globals_46892);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_46918)) ? _ix_46918 : (long)(DBL_PTR(_ix_46918)->dbl);
        int stop = (IS_ATOM_INT(_ix_46918)) ? _ix_46918 : (long)(DBL_PTR(_ix_46918)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_52dup_globals_46892), start, &_52dup_globals_46892 );
            }
            else Tail(SEQ_PTR(_52dup_globals_46892), stop+1, &_52dup_globals_46892);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_52dup_globals_46892), start, &_52dup_globals_46892);
        }
        else {
            assign_slice_seq = &assign_space;
            _52dup_globals_46892 = Remove_elements(start, stop, (SEQ_PTR(_52dup_globals_46892)->ref == 1));
        }
    }

    /** 				in_include_path = remove( in_include_path, ix )*/
    {
        s1_ptr assign_space = SEQ_PTR(_52in_include_path_46894);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_ix_46918)) ? _ix_46918 : (long)(DBL_PTR(_ix_46918)->dbl);
        int stop = (IS_ATOM_INT(_ix_46918)) ? _ix_46918 : (long)(DBL_PTR(_ix_46918)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_52in_include_path_46894), start, &_52in_include_path_46894 );
            }
            else Tail(SEQ_PTR(_52in_include_path_46894), stop+1, &_52in_include_path_46894);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_52in_include_path_46894), start, &_52in_include_path_46894);
        }
        else {
            assign_slice_seq = &assign_space;
            _52in_include_path_46894 = Remove_elements(start, stop, (SEQ_PTR(_52in_include_path_46894)->ref == 1));
        }
    }

    /** 		end while*/
    goto L2E; // [1408] 1358
L2F: 

    /** 		if length(dup_globals) = 1 then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24769 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24769 = 1;
    }
    if (_24769 != 1)
    goto L31; // [1418] 1451

    /** 				st_ptr = dup_globals[1]*/
    _2 = (int)SEQ_PTR(_52dup_globals_46892);
    _st_ptr_46920 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_st_ptr_46920)){
        _st_ptr_46920 = (long)DBL_PTR(_st_ptr_46920)->dbl;
    }

    /** 				gtok = {SymTab[st_ptr][S_TOKEN], st_ptr}*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24772 = (int)*(((s1_ptr)_2)->base + _st_ptr_46920);
    _2 = (int)SEQ_PTR(_24772);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24773 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24773 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24772 = NOVALUE;
    Ref(_24773);
    DeRef(_gtok_46924);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _24773;
    ((int *)_2)[2] = _st_ptr_46920;
    _gtok_46924 = MAKE_SEQ(_1);
    _24773 = NOVALUE;
L31: 
L2D: 

    /** ifdef STDDEBUG then*/

    /** 	if length(dup_globals) = 1 and st_builtin = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24775 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24775 = 1;
    }
    _24776 = (_24775 == 1);
    _24775 = NOVALUE;
    if (_24776 == 0) {
        goto L32; // [1465] 1642
    }
    _24778 = (_st_builtin_46921 == 0);
    if (_24778 == 0)
    {
        DeRef(_24778);
        _24778 = NOVALUE;
        goto L32; // [1474] 1642
    }
    else{
        DeRef(_24778);
        _24778 = NOVALUE;
    }

    /** 		if BIND then*/
    if (_12BIND_11322 == 0)
    {
        goto L33; // [1481] 1492
    }
    else{
    }

    /** 			add_ref(gtok)*/
    Ref(_gtok_46924);
    _52add_ref(_gtok_46924);
L33: 

    /** 		if not in_include_path[1] and*/
    _2 = (int)SEQ_PTR(_52in_include_path_46894);
    _24779 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_24779)) {
        _24780 = (_24779 == 0);
    }
    else {
        _24780 = unary_op(NOT, _24779);
    }
    _24779 = NOVALUE;
    if (IS_ATOM_INT(_24780)) {
        if (_24780 == 0) {
            goto L34; // [1503] 1635
        }
    }
    else {
        if (DBL_PTR(_24780)->dbl == 0.0) {
            goto L34; // [1503] 1635
        }
    }
    _2 = (int)SEQ_PTR(_gtok_46924);
    _24782 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_24782)){
        _24783 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24782)->dbl));
    }
    else{
        _24783 = (int)*(((s1_ptr)_2)->base + _24782);
    }
    _2 = (int)SEQ_PTR(_24783);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24784 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24784 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24783 = NOVALUE;
    Ref(_24784);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_46908;
    ((int *)_2)[2] = _24784;
    _24785 = MAKE_SEQ(_1);
    _24784 = NOVALUE;
    _24786 = find_from(_24785, _52include_warnings_46895, 1);
    DeRefDS(_24785);
    _24785 = NOVALUE;
    _24787 = (_24786 == 0);
    _24786 = NOVALUE;
    if (_24787 == 0)
    {
        DeRef(_24787);
        _24787 = NOVALUE;
        goto L34; // [1542] 1635
    }
    else{
        DeRef(_24787);
        _24787 = NOVALUE;
    }

    /** 			include_warnings = prepend( include_warnings,*/
    _2 = (int)SEQ_PTR(_gtok_46924);
    _24788 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_24788)){
        _24789 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24788)->dbl));
    }
    else{
        _24789 = (int)*(((s1_ptr)_2)->base + _24788);
    }
    _2 = (int)SEQ_PTR(_24789);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24790 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24790 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24789 = NOVALUE;
    Ref(_24790);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _scanning_file_46908;
    ((int *)_2)[2] = _24790;
    _24791 = MAKE_SEQ(_1);
    _24790 = NOVALUE;
    RefDS(_24791);
    Prepend(&_52include_warnings_46895, _52include_warnings_46895, _24791);
    DeRefDS(_24791);
    _24791 = NOVALUE;

    /** ifdef STDDEBUG then*/

    /** 				symbol_resolution_warning = GetMsgText(233,0,*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _24793 = (int)*(((s1_ptr)_2)->base + _scanning_file_46908);
    Ref(_24793);
    _24794 = _52name_ext(_24793);
    _24793 = NOVALUE;
    _2 = (int)SEQ_PTR(_gtok_46924);
    _24795 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!IS_ATOM_INT(_24795)){
        _24796 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24795)->dbl));
    }
    else{
        _24796 = (int)*(((s1_ptr)_2)->base + _24795);
    }
    _2 = (int)SEQ_PTR(_24796);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24797 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24797 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24796 = NOVALUE;
    _2 = (int)SEQ_PTR(_13known_files_10637);
    if (!IS_ATOM_INT(_24797)){
        _24798 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24797)->dbl));
    }
    else{
        _24798 = (int)*(((s1_ptr)_2)->base + _24797);
    }
    Ref(_24798);
    _24799 = _52name_ext(_24798);
    _24798 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _24794;
    *((int *)(_2+8)) = _12line_number_11683;
    RefDS(_word_46906);
    *((int *)(_2+12)) = _word_46906;
    *((int *)(_2+16)) = _24799;
    _24800 = MAKE_SEQ(_1);
    _24799 = NOVALUE;
    _24794 = NOVALUE;
    _0 = _44GetMsgText(233, 0, _24800);
    DeRef(_12symbol_resolution_warning_11784);
    _12symbol_resolution_warning_11784 = _0;
    _24800 = NOVALUE;
L34: 

    /** 		return gtok*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_tok_46923);
    _24708 = NOVALUE;
    DeRef(_24637);
    _24637 = NOVALUE;
    _24782 = NOVALUE;
    _24788 = NOVALUE;
    _24671 = NOVALUE;
    _24747 = NOVALUE;
    _24703 = NOVALUE;
    _24795 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24749 = NOVALUE;
    _24797 = NOVALUE;
    _24651 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24655 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    DeRef(_24776);
    _24776 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24664 = NOVALUE;
    _24656 = NOVALUE;
    DeRef(_24780);
    _24780 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    _24696 = NOVALUE;
    return _gtok_46924;
L32: 

    /** 	if length(dup_globals) = 0 then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24802 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24802 = 1;
    }
    if (_24802 != 0)
    goto L35; // [1649] 1723

    /** 		defined = SC_UNDEFINED*/
    _defined_46917 = 9;

    /** 		if fwd_line_number then*/
    if (_12fwd_line_number_11684 == 0)
    {
        goto L36; // [1666] 1695
    }
    else{
    }

    /** 			last_ForwardLine     = ForwardLine*/
    Ref(_43ForwardLine_48159);
    DeRef(_43last_ForwardLine_48161);
    _43last_ForwardLine_48161 = _43ForwardLine_48159;

    /** 			last_forward_bp      = forward_bp*/
    _43last_forward_bp_48165 = _43forward_bp_48163;

    /** 			last_fwd_line_number = fwd_line_number*/
    _12last_fwd_line_number_11686 = _12fwd_line_number_11684;
L36: 

    /** 		ForwardLine = ThisLine*/
    Ref(_43ThisLine_48158);
    DeRef(_43ForwardLine_48159);
    _43ForwardLine_48159 = _43ThisLine_48158;

    /** 		forward_bp = bp*/
    _43forward_bp_48163 = _43bp_48162;

    /** 		fwd_line_number = line_number*/
    _12fwd_line_number_11684 = _12line_number_11683;
    goto L37; // [1720] 1766
L35: 

    /** 	elsif length(dup_globals) then*/
    if (IS_SEQUENCE(_52dup_globals_46892)){
            _24804 = SEQ_PTR(_52dup_globals_46892)->length;
    }
    else {
        _24804 = 1;
    }
    if (_24804 == 0)
    {
        _24804 = NOVALUE;
        goto L38; // [1730] 1745
    }
    else{
        _24804 = NOVALUE;
    }

    /** 		defined = SC_MULTIPLY_DEFINED*/
    _defined_46917 = 10;
    goto L37; // [1742] 1766
L38: 

    /** 	elsif length(dup_overrides) then*/
    if (IS_SEQUENCE(_52dup_overrides_46893)){
            _24805 = SEQ_PTR(_52dup_overrides_46893)->length;
    }
    else {
        _24805 = 1;
    }
    if (_24805 == 0)
    {
        _24805 = NOVALUE;
        goto L39; // [1752] 1765
    }
    else{
        _24805 = NOVALUE;
    }

    /** 		defined = SC_OVERRIDE*/
    _defined_46917 = 12;
L39: 
L37: 

    /** 	if No_new_entry then*/
    if (_52No_new_entry_46903 == 0)
    {
        goto L3A; // [1770] 1793
    }
    else{
    }

    /** 		return {IGNORED,word,defined,dup_globals}*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 509;
    RefDS(_word_46906);
    *((int *)(_2+8)) = _word_46906;
    *((int *)(_2+12)) = _defined_46917;
    RefDS(_52dup_globals_46892);
    *((int *)(_2+16)) = _52dup_globals_46892;
    _24806 = MAKE_SEQ(_1);
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_tok_46923);
    DeRef(_gtok_46924);
    _24708 = NOVALUE;
    DeRef(_24637);
    _24637 = NOVALUE;
    _24782 = NOVALUE;
    _24788 = NOVALUE;
    _24671 = NOVALUE;
    _24747 = NOVALUE;
    _24703 = NOVALUE;
    _24795 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    _24749 = NOVALUE;
    _24797 = NOVALUE;
    _24651 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24655 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    DeRef(_24776);
    _24776 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24664 = NOVALUE;
    _24656 = NOVALUE;
    DeRef(_24780);
    _24780 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    _24696 = NOVALUE;
    return _24806;
L3A: 

    /** 	tok = {VARIABLE, NewEntry(word, 0, defined,*/
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _24807 = (int)*(((s1_ptr)_2)->base + _hashval_46912);
    RefDS(_word_46906);
    Ref(_24807);
    _24808 = _52NewEntry(_word_46906, 0, _defined_46917, -100, _hashval_46912, _24807, 0);
    _24807 = NOVALUE;
    DeRef(_tok_46923);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -100;
    ((int *)_2)[2] = _24808;
    _tok_46923 = MAKE_SEQ(_1);
    _24808 = NOVALUE;

    /** 	buckets[hashval] = tok[T_SYM]*/
    _2 = (int)SEQ_PTR(_tok_46923);
    _24810 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_24810);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    _2 = (int)(((s1_ptr)_2)->base + _hashval_46912);
    _1 = *(int *)_2;
    *(int *)_2 = _24810;
    if( _1 != _24810 ){
        DeRef(_1);
    }
    _24810 = NOVALUE;

    /** 	if file_no != -1 then*/
    if (_file_no_46907 == -1)
    goto L3B; // [1837] 1863

    /** 		SymTab[tok[T_SYM]][S_FILE_NO] = file_no*/
    _2 = (int)SEQ_PTR(_tok_46923);
    _24812 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_24812))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24812)->dbl));
    else
    _3 = (int)(_24812 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12S_FILE_NO_11350))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    _1 = *(int *)_2;
    *(int *)_2 = _file_no_46907;
    DeRef(_1);
    _24813 = NOVALUE;
L3B: 

    /** 	return tok  -- no ref on newly declared symbol*/
    DeRefDS(_word_46906);
    DeRef(_msg_46914);
    DeRef(_b_name_46915);
    DeRef(_gtok_46924);
    _24708 = NOVALUE;
    DeRef(_24637);
    _24637 = NOVALUE;
    _24782 = NOVALUE;
    _24788 = NOVALUE;
    _24812 = NOVALUE;
    _24671 = NOVALUE;
    _24747 = NOVALUE;
    _24703 = NOVALUE;
    _24795 = NOVALUE;
    _24690 = NOVALUE;
    DeRef(_24760);
    _24760 = NOVALUE;
    DeRef(_24678);
    _24678 = NOVALUE;
    DeRef(_24627);
    _24627 = NOVALUE;
    DeRef(_24806);
    _24806 = NOVALUE;
    _24749 = NOVALUE;
    _24797 = NOVALUE;
    _24651 = NOVALUE;
    _24682 = NOVALUE;
    DeRef(_24676);
    _24676 = NOVALUE;
    DeRef(_24692);
    _24692 = NOVALUE;
    _24655 = NOVALUE;
    DeRef(_24684);
    _24684 = NOVALUE;
    DeRef(_24776);
    _24776 = NOVALUE;
    DeRef(_24686);
    _24686 = NOVALUE;
    _24664 = NOVALUE;
    _24656 = NOVALUE;
    DeRef(_24780);
    _24780 = NOVALUE;
    DeRef(_24711);
    _24711 = NOVALUE;
    _24696 = NOVALUE;
    return _tok_46923;
    ;
}


void _52Hide(int _s_47316)
{
    int _prev_47318 = NOVALUE;
    int _p_47319 = NOVALUE;
    int _24833 = NOVALUE;
    int _24832 = NOVALUE;
    int _24831 = NOVALUE;
    int _24829 = NOVALUE;
    int _24828 = NOVALUE;
    int _24827 = NOVALUE;
    int _24826 = NOVALUE;
    int _24825 = NOVALUE;
    int _24821 = NOVALUE;
    int _24820 = NOVALUE;
    int _24819 = NOVALUE;
    int _24818 = NOVALUE;
    int _24816 = NOVALUE;
    int _24815 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47316)) {
        _1 = (long)(DBL_PTR(_s_47316)->dbl);
        DeRefDS(_s_47316);
        _s_47316 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24815 = (int)*(((s1_ptr)_2)->base + _s_47316);
    _2 = (int)SEQ_PTR(_24815);
    _24816 = (int)*(((s1_ptr)_2)->base + 11);
    _24815 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_24816)){
        _p_47319 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24816)->dbl));
    }
    else{
        _p_47319 = (int)*(((s1_ptr)_2)->base + _24816);
    }
    if (!IS_ATOM_INT(_p_47319)){
        _p_47319 = (long)DBL_PTR(_p_47319)->dbl;
    }

    /** 	prev = 0*/
    _prev_47318 = 0;

    /** 	while p != s and p != 0 do*/
L1: 
    _24818 = (_p_47319 != _s_47316);
    if (_24818 == 0) {
        goto L2; // [41] 81
    }
    _24820 = (_p_47319 != 0);
    if (_24820 == 0)
    {
        DeRef(_24820);
        _24820 = NOVALUE;
        goto L2; // [50] 81
    }
    else{
        DeRef(_24820);
        _24820 = NOVALUE;
    }

    /** 		prev = p*/
    _prev_47318 = _p_47319;

    /** 		p = SymTab[p][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24821 = (int)*(((s1_ptr)_2)->base + _p_47319);
    _2 = (int)SEQ_PTR(_24821);
    _p_47319 = (int)*(((s1_ptr)_2)->base + 9);
    if (!IS_ATOM_INT(_p_47319)){
        _p_47319 = (long)DBL_PTR(_p_47319)->dbl;
    }
    _24821 = NOVALUE;

    /** 	end while*/
    goto L1; // [78] 37
L2: 

    /** 	if p = 0 then*/
    if (_p_47319 != 0)
    goto L3; // [83] 93

    /** 		return -- already hidden*/
    _24816 = NOVALUE;
    DeRef(_24818);
    _24818 = NOVALUE;
    return;
L3: 

    /** 	if prev = 0 then*/
    if (_prev_47318 != 0)
    goto L4; // [95] 134

    /** 		buckets[SymTab[s][S_HASHVAL]] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24825 = (int)*(((s1_ptr)_2)->base + _s_47316);
    _2 = (int)SEQ_PTR(_24825);
    _24826 = (int)*(((s1_ptr)_2)->base + 11);
    _24825 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24827 = (int)*(((s1_ptr)_2)->base + _s_47316);
    _2 = (int)SEQ_PTR(_24827);
    _24828 = (int)*(((s1_ptr)_2)->base + 9);
    _24827 = NOVALUE;
    Ref(_24828);
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_24826))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24826)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _24826);
    _1 = *(int *)_2;
    *(int *)_2 = _24828;
    if( _1 != _24828 ){
        DeRef(_1);
    }
    _24828 = NOVALUE;
    goto L5; // [131] 162
L4: 

    /** 		SymTab[prev][S_SAMEHASH] = SymTab[s][S_SAMEHASH]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_prev_47318 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24831 = (int)*(((s1_ptr)_2)->base + _s_47316);
    _2 = (int)SEQ_PTR(_24831);
    _24832 = (int)*(((s1_ptr)_2)->base + 9);
    _24831 = NOVALUE;
    Ref(_24832);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _24832;
    if( _1 != _24832 ){
        DeRef(_1);
    }
    _24832 = NOVALUE;
    _24829 = NOVALUE;
L5: 

    /** 	SymTab[s][S_SAMEHASH] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47316 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
    _24833 = NOVALUE;

    /** end procedure*/
    _24816 = NOVALUE;
    DeRef(_24818);
    _24818 = NOVALUE;
    _24826 = NOVALUE;
    return;
    ;
}


void _52Show(int _s_47361)
{
    int _p_47363 = NOVALUE;
    int _24845 = NOVALUE;
    int _24844 = NOVALUE;
    int _24842 = NOVALUE;
    int _24841 = NOVALUE;
    int _24839 = NOVALUE;
    int _24838 = NOVALUE;
    int _24836 = NOVALUE;
    int _24835 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_47361)) {
        _1 = (long)(DBL_PTR(_s_47361)->dbl);
        DeRefDS(_s_47361);
        _s_47361 = _1;
    }

    /** 	p = buckets[SymTab[s][S_HASHVAL]]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24835 = (int)*(((s1_ptr)_2)->base + _s_47361);
    _2 = (int)SEQ_PTR(_24835);
    _24836 = (int)*(((s1_ptr)_2)->base + 11);
    _24835 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_24836)){
        _p_47363 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_24836)->dbl));
    }
    else{
        _p_47363 = (int)*(((s1_ptr)_2)->base + _24836);
    }
    if (!IS_ATOM_INT(_p_47363)){
        _p_47363 = (long)DBL_PTR(_p_47363)->dbl;
    }

    /** 	if SymTab[s][S_SAMEHASH] or p = s then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24838 = (int)*(((s1_ptr)_2)->base + _s_47361);
    _2 = (int)SEQ_PTR(_24838);
    _24839 = (int)*(((s1_ptr)_2)->base + 9);
    _24838 = NOVALUE;
    if (IS_ATOM_INT(_24839)) {
        if (_24839 != 0) {
            goto L1; // [39] 52
        }
    }
    else {
        if (DBL_PTR(_24839)->dbl != 0.0) {
            goto L1; // [39] 52
        }
    }
    _24841 = (_p_47363 == _s_47361);
    if (_24841 == 0)
    {
        DeRef(_24841);
        _24841 = NOVALUE;
        goto L2; // [48] 58
    }
    else{
        DeRef(_24841);
        _24841 = NOVALUE;
    }
L1: 

    /** 		return*/
    _24836 = NOVALUE;
    _24839 = NOVALUE;
    return;
L2: 

    /** 	SymTab[s][S_SAMEHASH] = p*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_47361 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 9);
    _1 = *(int *)_2;
    *(int *)_2 = _p_47363;
    DeRef(_1);
    _24842 = NOVALUE;

    /** 	buckets[SymTab[s][S_HASHVAL]] = s*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24844 = (int)*(((s1_ptr)_2)->base + _s_47361);
    _2 = (int)SEQ_PTR(_24844);
    _24845 = (int)*(((s1_ptr)_2)->base + 11);
    _24844 = NOVALUE;
    _2 = (int)SEQ_PTR(_52buckets_45727);
    if (!IS_ATOM_INT(_24845))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_24845)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _24845);
    _1 = *(int *)_2;
    *(int *)_2 = _s_47361;
    DeRef(_1);

    /** end procedure*/
    _24836 = NOVALUE;
    _24839 = NOVALUE;
    _24845 = NOVALUE;
    return;
    ;
}


void _52hide_params(int _s_47387)
{
    int _param_47389 = NOVALUE;
    int _24848 = NOVALUE;
    int _24847 = NOVALUE;
    int _24846 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47387)) {
        _1 = (long)(DBL_PTR(_s_47387)->dbl);
        DeRefDS(_s_47387);
        _s_47387 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47389 = _s_47387;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24846 = (int)*(((s1_ptr)_2)->base + _s_47387);
    _2 = (int)SEQ_PTR(_24846);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _24847 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _24847 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _24846 = NOVALUE;
    {
        int _i_47391;
        _i_47391 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47391, _24847)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24848 = (int)*(((s1_ptr)_2)->base + _s_47387);
        _2 = (int)SEQ_PTR(_24848);
        _param_47389 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47389)){
            _param_47389 = (long)DBL_PTR(_param_47389)->dbl;
        }
        _24848 = NOVALUE;

        /** 		Hide( param )*/
        _52Hide(_param_47389);

        /** 	end for*/
        _0 = _i_47391;
        if (IS_ATOM_INT(_i_47391)) {
            _i_47391 = _i_47391 + 1;
            if ((long)((unsigned long)_i_47391 +(unsigned long) HIGH_BITS) >= 0){
                _i_47391 = NewDouble((double)_i_47391);
            }
        }
        else {
            _i_47391 = binary_op_a(PLUS, _i_47391, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47391);
    }

    /** end procedure*/
    _24847 = NOVALUE;
    return;
    ;
}


void _52show_params(int _s_47403)
{
    int _param_47405 = NOVALUE;
    int _24852 = NOVALUE;
    int _24851 = NOVALUE;
    int _24850 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47403)) {
        _1 = (long)(DBL_PTR(_s_47403)->dbl);
        DeRefDS(_s_47403);
        _s_47403 = _1;
    }

    /** 	symtab_index param = s*/
    _param_47405 = _s_47403;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24850 = (int)*(((s1_ptr)_2)->base + _s_47403);
    _2 = (int)SEQ_PTR(_24850);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _24851 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _24851 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _24850 = NOVALUE;
    {
        int _i_47407;
        _i_47407 = 1;
L1: 
        if (binary_op_a(GREATER, _i_47407, _24851)){
            goto L2; // [24] 59
        }

        /** 		param = SymTab[s][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24852 = (int)*(((s1_ptr)_2)->base + _s_47403);
        _2 = (int)SEQ_PTR(_24852);
        _param_47405 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_param_47405)){
            _param_47405 = (long)DBL_PTR(_param_47405)->dbl;
        }
        _24852 = NOVALUE;

        /** 		Show( param )*/
        _52Show(_param_47405);

        /** 	end for*/
        _0 = _i_47407;
        if (IS_ATOM_INT(_i_47407)) {
            _i_47407 = _i_47407 + 1;
            if ((long)((unsigned long)_i_47407 +(unsigned long) HIGH_BITS) >= 0){
                _i_47407 = NewDouble((double)_i_47407);
            }
        }
        else {
            _i_47407 = binary_op_a(PLUS, _i_47407, 1);
        }
        DeRef(_0);
        goto L1; // [54] 31
L2: 
        ;
        DeRef(_i_47407);
    }

    /** end procedure*/
    _24851 = NOVALUE;
    return;
    ;
}


void _52LintCheck(int _s_47419)
{
    int _warn_level_47420 = NOVALUE;
    int _file_47421 = NOVALUE;
    int _vscope_47422 = NOVALUE;
    int _vname_47423 = NOVALUE;
    int _vusage_47424 = NOVALUE;
    int _24913 = NOVALUE;
    int _24912 = NOVALUE;
    int _24911 = NOVALUE;
    int _24910 = NOVALUE;
    int _24909 = NOVALUE;
    int _24908 = NOVALUE;
    int _24906 = NOVALUE;
    int _24905 = NOVALUE;
    int _24904 = NOVALUE;
    int _24903 = NOVALUE;
    int _24902 = NOVALUE;
    int _24901 = NOVALUE;
    int _24898 = NOVALUE;
    int _24897 = NOVALUE;
    int _24896 = NOVALUE;
    int _24895 = NOVALUE;
    int _24894 = NOVALUE;
    int _24893 = NOVALUE;
    int _24891 = NOVALUE;
    int _24889 = NOVALUE;
    int _24888 = NOVALUE;
    int _24886 = NOVALUE;
    int _24885 = NOVALUE;
    int _24883 = NOVALUE;
    int _24882 = NOVALUE;
    int _24881 = NOVALUE;
    int _24880 = NOVALUE;
    int _24878 = NOVALUE;
    int _24877 = NOVALUE;
    int _24873 = NOVALUE;
    int _24870 = NOVALUE;
    int _24869 = NOVALUE;
    int _24868 = NOVALUE;
    int _24867 = NOVALUE;
    int _24864 = NOVALUE;
    int _24863 = NOVALUE;
    int _24858 = NOVALUE;
    int _24856 = NOVALUE;
    int _24854 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_47419)) {
        _1 = (long)(DBL_PTR(_s_47419)->dbl);
        DeRefDS(_s_47419);
        _s_47419 = _1;
    }

    /** 	vusage = SymTab[s][S_USAGE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24854 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24854);
    _vusage_47424 = (int)*(((s1_ptr)_2)->base + 5);
    if (!IS_ATOM_INT(_vusage_47424)){
        _vusage_47424 = (long)DBL_PTR(_vusage_47424)->dbl;
    }
    _24854 = NOVALUE;

    /** 	vscope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24856 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24856);
    _vscope_47422 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_vscope_47422)){
        _vscope_47422 = (long)DBL_PTR(_vscope_47422)->dbl;
    }
    _24856 = NOVALUE;

    /** 	vname = SymTab[s][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24858 = (int)*(((s1_ptr)_2)->base + _s_47419);
    DeRef(_vname_47423);
    _2 = (int)SEQ_PTR(_24858);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _vname_47423 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _vname_47423 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_vname_47423);
    _24858 = NOVALUE;

    /** 	switch vusage do*/
    _0 = _vusage_47424;
    switch ( _0 ){ 

        /** 		case U_UNUSED then*/
        case 0:

        /** 			warn_level = 1*/
        _warn_level_47420 = 1;
        goto L1; // [67] 193

        /** 		case U_WRITTEN then -- Set but never read*/
        case 2:

        /** 			warn_level = 2*/
        _warn_level_47420 = 2;

        /** 			if vscope > SC_LOCAL then*/
        if (_vscope_47422 <= 5)
        goto L2; // [82] 94

        /** 				warn_level = 0 */
        _warn_level_47420 = 0;
        goto L1; // [91] 193
L2: 

        /** 			elsif SymTab[s][S_MODE] = M_CONSTANT then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24863 = (int)*(((s1_ptr)_2)->base + _s_47419);
        _2 = (int)SEQ_PTR(_24863);
        _24864 = (int)*(((s1_ptr)_2)->base + 3);
        _24863 = NOVALUE;
        if (binary_op_a(NOTEQ, _24864, 2)){
            _24864 = NOVALUE;
            goto L1; // [110] 193
        }
        _24864 = NOVALUE;

        /** 				if not Strict_is_on then*/
        if (_12Strict_is_on_11748 != 0)
        goto L1; // [118] 193

        /** 					warn_level = 0 */
        _warn_level_47420 = 0;
        goto L1; // [129] 193

        /** 		case U_READ then -- Read but never set*/
        case 1:

        /** 			if SymTab[s][S_VARNUM] >= SymTab[CurrentSub][S_NUM_ARGS] then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24867 = (int)*(((s1_ptr)_2)->base + _s_47419);
        _2 = (int)SEQ_PTR(_24867);
        _24868 = (int)*(((s1_ptr)_2)->base + 16);
        _24867 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24869 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
        _2 = (int)SEQ_PTR(_24869);
        if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
            _24870 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
        }
        else{
            _24870 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
        }
        _24869 = NOVALUE;
        if (binary_op_a(LESS, _24868, _24870)){
            _24868 = NOVALUE;
            _24870 = NOVALUE;
            goto L3; // [163] 175
        }
        _24868 = NOVALUE;
        _24870 = NOVALUE;

        /** 		    	warn_level = 3*/
        _warn_level_47420 = 3;
        goto L1; // [172] 193
L3: 

        /** 		    	warn_level = 0*/
        _warn_level_47420 = 0;
        goto L1; // [181] 193

        /** 	    case else*/
        default:

        /** 	    	warn_level = 0*/
        _warn_level_47420 = 0;
    ;}L1: 

    /** 	if warn_level = 0 then*/
    if (_warn_level_47420 != 0)
    goto L4; // [197] 207

    /** 		return*/
    DeRef(_file_47421);
    DeRef(_vname_47423);
    return;
L4: 

    /** 	file = abbreviate_path(known_files[current_file_no])*/
    _2 = (int)SEQ_PTR(_13known_files_10637);
    _24873 = (int)*(((s1_ptr)_2)->base + _12current_file_no_11682);
    Ref(_24873);
    RefDS(_21829);
    _0 = _file_47421;
    _file_47421 = _14abbreviate_path(_24873, _21829);
    DeRef(_0);
    _24873 = NOVALUE;

    /** 	if warn_level = 3 then*/
    if (_warn_level_47420 != 3)
    goto L5; // [226] 308

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47422 != 5)
    goto L6; // [234] 275

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24877 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24877);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24878 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24878 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24877 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_11682, _24878)){
        _24878 = NOVALUE;
        goto L7; // [254] 602
    }
    _24878 = NOVALUE;

    /** 				Warning(226, no_value_warning_flag, {file,  vname})*/
    RefDS(_vname_47423);
    RefDS(_file_47421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47421;
    ((int *)_2)[2] = _vname_47423;
    _24880 = MAKE_SEQ(_1);
    _43Warning(226, 32, _24880);
    _24880 = NOVALUE;
    goto L7; // [272] 602
L6: 

    /** 			Warning(227, no_value_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24881 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24881);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24882 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24882 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24881 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47421);
    *((int *)(_2+4)) = _file_47421;
    RefDS(_vname_47423);
    *((int *)(_2+8)) = _vname_47423;
    Ref(_24882);
    *((int *)(_2+12)) = _24882;
    _24883 = MAKE_SEQ(_1);
    _24882 = NOVALUE;
    _43Warning(227, 32, _24883);
    _24883 = NOVALUE;
    goto L7; // [305] 602
L5: 

    /** 		if vscope = SC_LOCAL then*/
    if (_vscope_47422 != 5)
    goto L8; // [312] 412

    /** 			if current_file_no = SymTab[s][S_FILE_NO] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24885 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24885);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24886 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24886 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24885 = NOVALUE;
    if (binary_op_a(NOTEQ, _12current_file_no_11682, _24886)){
        _24886 = NOVALUE;
        goto L9; // [332] 601
    }
    _24886 = NOVALUE;

    /** 				if SymTab[s][S_MODE] = M_CONSTANT then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24888 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24888);
    _24889 = (int)*(((s1_ptr)_2)->base + 3);
    _24888 = NOVALUE;
    if (binary_op_a(NOTEQ, _24889, 2)){
        _24889 = NOVALUE;
        goto LA; // [352] 372
    }
    _24889 = NOVALUE;

    /** 					Warning(228, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47423);
    RefDS(_file_47421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47421;
    ((int *)_2)[2] = _vname_47423;
    _24891 = MAKE_SEQ(_1);
    _43Warning(228, 16, _24891);
    _24891 = NOVALUE;
    goto L9; // [369] 601
LA: 

    /** 				elsif warn_level = 1 then*/
    if (_warn_level_47420 != 1)
    goto LB; // [374] 394

    /** 					Warning(229, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47423);
    RefDS(_file_47421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47421;
    ((int *)_2)[2] = _vname_47423;
    _24893 = MAKE_SEQ(_1);
    _43Warning(229, 16, _24893);
    _24893 = NOVALUE;
    goto L9; // [391] 601
LB: 

    /** 					Warning(320, not_used_warning_flag, {file,  vname})*/
    RefDS(_vname_47423);
    RefDS(_file_47421);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _file_47421;
    ((int *)_2)[2] = _vname_47423;
    _24894 = MAKE_SEQ(_1);
    _43Warning(320, 16, _24894);
    _24894 = NOVALUE;
    goto L9; // [409] 601
L8: 

    /** 			if SymTab[s][S_VARNUM] < SymTab[CurrentSub][S_NUM_ARGS] then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24895 = (int)*(((s1_ptr)_2)->base + _s_47419);
    _2 = (int)SEQ_PTR(_24895);
    _24896 = (int)*(((s1_ptr)_2)->base + 16);
    _24895 = NOVALUE;
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24897 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24897);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _24898 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _24898 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _24897 = NOVALUE;
    if (binary_op_a(GREATEREQ, _24896, _24898)){
        _24896 = NOVALUE;
        _24898 = NOVALUE;
        goto LC; // [440] 523
    }
    _24896 = NOVALUE;
    _24898 = NOVALUE;

    /** 				if warn_level = 1 then*/
    if (_warn_level_47420 != 1)
    goto LD; // [446] 490

    /** 					if Strict_is_on then*/
    if (_12Strict_is_on_11748 == 0)
    {
        goto LE; // [454] 600
    }
    else{
    }

    /** 						Warning(230, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24901 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24901);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24902 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24902 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24901 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47421);
    *((int *)(_2+4)) = _file_47421;
    RefDS(_vname_47423);
    *((int *)(_2+8)) = _vname_47423;
    Ref(_24902);
    *((int *)(_2+12)) = _24902;
    _24903 = MAKE_SEQ(_1);
    _24902 = NOVALUE;
    _43Warning(230, 16, _24903);
    _24903 = NOVALUE;
    goto LE; // [487] 600
LD: 

    /** 					Warning(321, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24904 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24904);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24905 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24905 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24904 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47421);
    *((int *)(_2+4)) = _file_47421;
    RefDS(_vname_47423);
    *((int *)(_2+8)) = _vname_47423;
    Ref(_24905);
    *((int *)(_2+12)) = _24905;
    _24906 = MAKE_SEQ(_1);
    _24905 = NOVALUE;
    _43Warning(321, 16, _24906);
    _24906 = NOVALUE;
    goto LE; // [520] 600
LC: 

    /** 				if warn_level = 1 then*/
    if (_warn_level_47420 != 1)
    goto LF; // [525] 569

    /** 					if Strict_is_on then*/
    if (_12Strict_is_on_11748 == 0)
    {
        goto L10; // [533] 599
    }
    else{
    }

    /** 						Warning(231, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24908 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24908);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24909 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24909 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24908 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47421);
    *((int *)(_2+4)) = _file_47421;
    RefDS(_vname_47423);
    *((int *)(_2+8)) = _vname_47423;
    Ref(_24909);
    *((int *)(_2+12)) = _24909;
    _24910 = MAKE_SEQ(_1);
    _24909 = NOVALUE;
    _43Warning(231, 16, _24910);
    _24910 = NOVALUE;
    goto L10; // [566] 599
LF: 

    /** 					Warning(322, not_used_warning_flag, {file,  vname, SymTab[CurrentSub][S_NAME]})*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24911 = (int)*(((s1_ptr)_2)->base + _12CurrentSub_11690);
    _2 = (int)SEQ_PTR(_24911);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24912 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24912 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24911 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_file_47421);
    *((int *)(_2+4)) = _file_47421;
    RefDS(_vname_47423);
    *((int *)(_2+8)) = _vname_47423;
    Ref(_24912);
    *((int *)(_2+12)) = _24912;
    _24913 = MAKE_SEQ(_1);
    _24912 = NOVALUE;
    _43Warning(322, 16, _24913);
    _24913 = NOVALUE;
L10: 
LE: 
L9: 
L7: 

    /** end procedure*/
    DeRef(_file_47421);
    DeRef(_vname_47423);
    return;
    ;
}


void _52HideLocals()
{
    int _s_47590 = NOVALUE;
    int _24924 = NOVALUE;
    int _24922 = NOVALUE;
    int _24921 = NOVALUE;
    int _24920 = NOVALUE;
    int _24919 = NOVALUE;
    int _24918 = NOVALUE;
    int _24917 = NOVALUE;
    int _24916 = NOVALUE;
    int _24915 = NOVALUE;
    int _24914 = NOVALUE;
    int _0, _1, _2;
    

    /** 	s = file_start_sym*/
    _s_47590 = _12file_start_sym_11688;

    /** 	while s do*/
L1: 
    if (_s_47590 == 0)
    {
        goto L2; // [15] 117
    }
    else{
    }

    /** 		if SymTab[s][S_SCOPE] = SC_LOCAL and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24914 = (int)*(((s1_ptr)_2)->base + _s_47590);
    _2 = (int)SEQ_PTR(_24914);
    _24915 = (int)*(((s1_ptr)_2)->base + 4);
    _24914 = NOVALUE;
    if (IS_ATOM_INT(_24915)) {
        _24916 = (_24915 == 5);
    }
    else {
        _24916 = binary_op(EQUALS, _24915, 5);
    }
    _24915 = NOVALUE;
    if (IS_ATOM_INT(_24916)) {
        if (_24916 == 0) {
            goto L3; // [38] 96
        }
    }
    else {
        if (DBL_PTR(_24916)->dbl == 0.0) {
            goto L3; // [38] 96
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24918 = (int)*(((s1_ptr)_2)->base + _s_47590);
    _2 = (int)SEQ_PTR(_24918);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _24919 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _24919 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _24918 = NOVALUE;
    if (IS_ATOM_INT(_24919)) {
        _24920 = (_24919 == _12current_file_no_11682);
    }
    else {
        _24920 = binary_op(EQUALS, _24919, _12current_file_no_11682);
    }
    _24919 = NOVALUE;
    if (_24920 == 0) {
        DeRef(_24920);
        _24920 = NOVALUE;
        goto L3; // [61] 96
    }
    else {
        if (!IS_ATOM_INT(_24920) && DBL_PTR(_24920)->dbl == 0.0){
            DeRef(_24920);
            _24920 = NOVALUE;
            goto L3; // [61] 96
        }
        DeRef(_24920);
        _24920 = NOVALUE;
    }
    DeRef(_24920);
    _24920 = NOVALUE;

    /** 			Hide(s)*/
    _52Hide(_s_47590);

    /** 			if SymTab[s][S_TOKEN] = VARIABLE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24921 = (int)*(((s1_ptr)_2)->base + _s_47590);
    _2 = (int)SEQ_PTR(_24921);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24922 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24922 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24921 = NOVALUE;
    if (binary_op_a(NOTEQ, _24922, -100)){
        _24922 = NOVALUE;
        goto L4; // [85] 95
    }
    _24922 = NOVALUE;

    /** 				LintCheck(s)*/
    _52LintCheck(_s_47590);
L4: 
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24924 = (int)*(((s1_ptr)_2)->base + _s_47590);
    _2 = (int)SEQ_PTR(_24924);
    _s_47590 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_47590)){
        _s_47590 = (long)DBL_PTR(_s_47590)->dbl;
    }
    _24924 = NOVALUE;

    /** 	end while*/
    goto L1; // [114] 15
L2: 

    /** end procedure*/
    DeRef(_24916);
    _24916 = NOVALUE;
    return;
    ;
}


int _52sym_name(int _sym_47621)
{
    int _24927 = NOVALUE;
    int _24926 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47621)) {
        _1 = (long)(DBL_PTR(_sym_47621)->dbl);
        DeRefDS(_sym_47621);
        _sym_47621 = _1;
    }

    /** 	return SymTab[sym][S_NAME]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24926 = (int)*(((s1_ptr)_2)->base + _sym_47621);
    _2 = (int)SEQ_PTR(_24926);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _24927 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _24927 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _24926 = NOVALUE;
    Ref(_24927);
    return _24927;
    ;
}


int _52sym_token(int _sym_47629)
{
    int _24929 = NOVALUE;
    int _24928 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47629)) {
        _1 = (long)(DBL_PTR(_sym_47629)->dbl);
        DeRefDS(_sym_47629);
        _sym_47629 = _1;
    }

    /** 	return SymTab[sym][S_TOKEN]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24928 = (int)*(((s1_ptr)_2)->base + _sym_47629);
    _2 = (int)SEQ_PTR(_24928);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _24929 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _24929 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _24928 = NOVALUE;
    Ref(_24929);
    return _24929;
    ;
}


int _52sym_scope(int _sym_47637)
{
    int _24931 = NOVALUE;
    int _24930 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47637)) {
        _1 = (long)(DBL_PTR(_sym_47637)->dbl);
        DeRefDS(_sym_47637);
        _sym_47637 = _1;
    }

    /** 	return SymTab[sym][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24930 = (int)*(((s1_ptr)_2)->base + _sym_47637);
    _2 = (int)SEQ_PTR(_24930);
    _24931 = (int)*(((s1_ptr)_2)->base + 4);
    _24930 = NOVALUE;
    Ref(_24931);
    return _24931;
    ;
}


int _52sym_mode(int _sym_47645)
{
    int _24933 = NOVALUE;
    int _24932 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47645)) {
        _1 = (long)(DBL_PTR(_sym_47645)->dbl);
        DeRefDS(_sym_47645);
        _sym_47645 = _1;
    }

    /** 	return SymTab[sym][S_MODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24932 = (int)*(((s1_ptr)_2)->base + _sym_47645);
    _2 = (int)SEQ_PTR(_24932);
    _24933 = (int)*(((s1_ptr)_2)->base + 3);
    _24932 = NOVALUE;
    Ref(_24933);
    return _24933;
    ;
}


int _52sym_obj(int _sym_47653)
{
    int _24935 = NOVALUE;
    int _24934 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47653)) {
        _1 = (long)(DBL_PTR(_sym_47653)->dbl);
        DeRefDS(_sym_47653);
        _sym_47653 = _1;
    }

    /** 	return SymTab[sym][S_OBJ]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24934 = (int)*(((s1_ptr)_2)->base + _sym_47653);
    _2 = (int)SEQ_PTR(_24934);
    _24935 = (int)*(((s1_ptr)_2)->base + 1);
    _24934 = NOVALUE;
    Ref(_24935);
    return _24935;
    ;
}


int _52sym_next(int _sym_47661)
{
    int _24937 = NOVALUE;
    int _24936 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47661)) {
        _1 = (long)(DBL_PTR(_sym_47661)->dbl);
        DeRefDS(_sym_47661);
        _sym_47661 = _1;
    }

    /** 	return SymTab[sym][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24936 = (int)*(((s1_ptr)_2)->base + _sym_47661);
    _2 = (int)SEQ_PTR(_24936);
    _24937 = (int)*(((s1_ptr)_2)->base + 2);
    _24936 = NOVALUE;
    Ref(_24937);
    return _24937;
    ;
}


int _52sym_block(int _sym_47669)
{
    int _24939 = NOVALUE;
    int _24938 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47669)) {
        _1 = (long)(DBL_PTR(_sym_47669)->dbl);
        DeRefDS(_sym_47669);
        _sym_47669 = _1;
    }

    /** 	return SymTab[sym][S_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24938 = (int)*(((s1_ptr)_2)->base + _sym_47669);
    _2 = (int)SEQ_PTR(_24938);
    if (!IS_ATOM_INT(_12S_BLOCK_11374)){
        _24939 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_BLOCK_11374)->dbl));
    }
    else{
        _24939 = (int)*(((s1_ptr)_2)->base + _12S_BLOCK_11374);
    }
    _24938 = NOVALUE;
    Ref(_24939);
    return _24939;
    ;
}


int _52sym_next_in_block(int _sym_47677)
{
    int _24941 = NOVALUE;
    int _24940 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47677)) {
        _1 = (long)(DBL_PTR(_sym_47677)->dbl);
        DeRefDS(_sym_47677);
        _sym_47677 = _1;
    }

    /** 	return SymTab[sym][S_NEXT_IN_BLOCK]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24940 = (int)*(((s1_ptr)_2)->base + _sym_47677);
    _2 = (int)SEQ_PTR(_24940);
    if (!IS_ATOM_INT(_12S_NEXT_IN_BLOCK_11346)){
        _24941 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NEXT_IN_BLOCK_11346)->dbl));
    }
    else{
        _24941 = (int)*(((s1_ptr)_2)->base + _12S_NEXT_IN_BLOCK_11346);
    }
    _24940 = NOVALUE;
    Ref(_24941);
    return _24941;
    ;
}


int _52sym_usage(int _sym_47685)
{
    int _24943 = NOVALUE;
    int _24942 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sym_47685)) {
        _1 = (long)(DBL_PTR(_sym_47685)->dbl);
        DeRefDS(_sym_47685);
        _sym_47685 = _1;
    }

    /** 	return SymTab[sym][S_USAGE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24942 = (int)*(((s1_ptr)_2)->base + _sym_47685);
    _2 = (int)SEQ_PTR(_24942);
    _24943 = (int)*(((s1_ptr)_2)->base + 5);
    _24942 = NOVALUE;
    Ref(_24943);
    return _24943;
    ;
}


int _52calc_stack_required(int _sub_47693)
{
    int _required_47694 = NOVALUE;
    int _arg_47699 = NOVALUE;
    int _24963 = NOVALUE;
    int _24959 = NOVALUE;
    int _24957 = NOVALUE;
    int _24955 = NOVALUE;
    int _24954 = NOVALUE;
    int _24953 = NOVALUE;
    int _24952 = NOVALUE;
    int _24951 = NOVALUE;
    int _24949 = NOVALUE;
    int _24948 = NOVALUE;
    int _24946 = NOVALUE;
    int _24944 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_sub_47693)) {
        _1 = (long)(DBL_PTR(_sub_47693)->dbl);
        DeRefDS(_sub_47693);
        _sub_47693 = _1;
    }

    /** 	integer required = SymTab[sub][S_NUM_ARGS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24944 = (int)*(((s1_ptr)_2)->base + _sub_47693);
    _2 = (int)SEQ_PTR(_24944);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _required_47694 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _required_47694 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    if (!IS_ATOM_INT(_required_47694)){
        _required_47694 = (long)DBL_PTR(_required_47694)->dbl;
    }
    _24944 = NOVALUE;

    /** 	integer arg = SymTab[sub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24946 = (int)*(((s1_ptr)_2)->base + _sub_47693);
    _2 = (int)SEQ_PTR(_24946);
    _arg_47699 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47699)){
        _arg_47699 = (long)DBL_PTR(_arg_47699)->dbl;
    }
    _24946 = NOVALUE;

    /** 	for i = 1 to required do*/
    _24948 = _required_47694;
    {
        int _i_47705;
        _i_47705 = 1;
L1: 
        if (_i_47705 > _24948){
            goto L2; // [40] 70
        }

        /** 		arg = SymTab[arg][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _24949 = (int)*(((s1_ptr)_2)->base + _arg_47699);
        _2 = (int)SEQ_PTR(_24949);
        _arg_47699 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_arg_47699)){
            _arg_47699 = (long)DBL_PTR(_arg_47699)->dbl;
        }
        _24949 = NOVALUE;

        /** 	end for*/
        _i_47705 = _i_47705 + 1;
        goto L1; // [65] 47
L2: 
        ;
    }

    /** 	while arg != 0 and SymTab[arg][S_SCOPE] <= SC_PRIVATE do*/
L3: 
    _24951 = (_arg_47699 != 0);
    if (_24951 == 0) {
        goto L4; // [79] 132
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24953 = (int)*(((s1_ptr)_2)->base + _arg_47699);
    _2 = (int)SEQ_PTR(_24953);
    _24954 = (int)*(((s1_ptr)_2)->base + 4);
    _24953 = NOVALUE;
    if (IS_ATOM_INT(_24954)) {
        _24955 = (_24954 <= 3);
    }
    else {
        _24955 = binary_op(LESSEQ, _24954, 3);
    }
    _24954 = NOVALUE;
    if (_24955 <= 0) {
        if (_24955 == 0) {
            DeRef(_24955);
            _24955 = NOVALUE;
            goto L4; // [102] 132
        }
        else {
            if (!IS_ATOM_INT(_24955) && DBL_PTR(_24955)->dbl == 0.0){
                DeRef(_24955);
                _24955 = NOVALUE;
                goto L4; // [102] 132
            }
            DeRef(_24955);
            _24955 = NOVALUE;
        }
    }
    DeRef(_24955);
    _24955 = NOVALUE;

    /** 		required += 1*/
    _required_47694 = _required_47694 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24957 = (int)*(((s1_ptr)_2)->base + _arg_47699);
    _2 = (int)SEQ_PTR(_24957);
    _arg_47699 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47699)){
        _arg_47699 = (long)DBL_PTR(_arg_47699)->dbl;
    }
    _24957 = NOVALUE;

    /** 	end while*/
    goto L3; // [129] 75
L4: 

    /** 	arg = SymTab[sub][S_TEMPS]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24959 = (int)*(((s1_ptr)_2)->base + _sub_47693);
    _2 = (int)SEQ_PTR(_24959);
    if (!IS_ATOM_INT(_12S_TEMPS_11399)){
        _arg_47699 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
    }
    else{
        _arg_47699 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
    }
    if (!IS_ATOM_INT(_arg_47699)){
        _arg_47699 = (long)DBL_PTR(_arg_47699)->dbl;
    }
    _24959 = NOVALUE;

    /** 	while arg != 0 do*/
L5: 
    if (_arg_47699 == 0)
    goto L6; // [153] 184

    /** 		required += 1*/
    _required_47694 = _required_47694 + 1;

    /** 		arg = SymTab[arg][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _24963 = (int)*(((s1_ptr)_2)->base + _arg_47699);
    _2 = (int)SEQ_PTR(_24963);
    _arg_47699 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_arg_47699)){
        _arg_47699 = (long)DBL_PTR(_arg_47699)->dbl;
    }
    _24963 = NOVALUE;

    /** 	end while*/
    goto L5; // [181] 153
L6: 

    /** 	return required*/
    DeRef(_24951);
    _24951 = NOVALUE;
    return _required_47694;
    ;
}



// 0xA2B59381
