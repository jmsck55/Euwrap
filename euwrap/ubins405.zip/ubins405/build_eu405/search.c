// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _20find_all(int _needle_1689, int _haystack_1690, int _start_1691)
{
    int _kx_1692 = NOVALUE;
    int _711 = NOVALUE;
    int _710 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer kx = 0*/
    _kx_1692 = 0;

    /** 	while start with entry do*/
    goto L1; // [12] 39
L2: 
    if (_start_1691 == 0)
    {
        goto L3; // [15] 51
    }
    else{
    }

    /** 		kx += 1*/
    _kx_1692 = _kx_1692 + 1;

    /** 		haystack[kx] = start*/
    _2 = (int)SEQ_PTR(_haystack_1690);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1690 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _kx_1692);
    _1 = *(int *)_2;
    *(int *)_2 = _start_1691;
    DeRef(_1);

    /** 		start += 1*/
    _start_1691 = _start_1691 + 1;

    /** 	entry*/
L1: 

    /** 		start = find(needle, haystack, start)*/
    _start_1691 = find_from(_needle_1689, _haystack_1690, _start_1691);

    /** 	end while*/
    goto L2; // [48] 15
L3: 

    /** 	haystack = remove( haystack, kx+1, length( haystack ) )*/
    _710 = _kx_1692 + 1;
    if (_710 > MAXINT){
        _710 = NewDouble((double)_710);
    }
    if (IS_SEQUENCE(_haystack_1690)){
            _711 = SEQ_PTR(_haystack_1690)->length;
    }
    else {
        _711 = 1;
    }
    {
        s1_ptr assign_space = SEQ_PTR(_haystack_1690);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_710)) ? _710 : (long)(DBL_PTR(_710)->dbl);
        int stop = (IS_ATOM_INT(_711)) ? _711 : (long)(DBL_PTR(_711)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_haystack_1690), start, &_haystack_1690 );
            }
            else Tail(SEQ_PTR(_haystack_1690), stop+1, &_haystack_1690);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_haystack_1690), start, &_haystack_1690);
        }
        else {
            assign_slice_seq = &assign_space;
            _haystack_1690 = Remove_elements(start, stop, (SEQ_PTR(_haystack_1690)->ref == 1));
        }
    }
    DeRef(_710);
    _710 = NOVALUE;
    _711 = NOVALUE;

    /** 	return haystack*/
    return _haystack_1690;
    ;
}


int _20rfind(int _needle_1807, int _haystack_1808, int _start_1809)
{
    int _len_1811 = NOVALUE;
    int _772 = NOVALUE;
    int _771 = NOVALUE;
    int _768 = NOVALUE;
    int _767 = NOVALUE;
    int _765 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer len = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1808)){
            _len_1811 = SEQ_PTR(_haystack_1808)->length;
    }
    else {
        _len_1811 = 1;
    }

    /** 	if start = 0 then start = len end if*/
    if (_start_1809 != 0)
    goto L1; // [12] 20
    _start_1809 = _len_1811;
L1: 

    /** 	if (start > len) or (len + start < 1) then*/
    _765 = (_start_1809 > _len_1811);
    if (_765 != 0) {
        goto L2; // [26] 43
    }
    _767 = _len_1811 + _start_1809;
    if ((long)((unsigned long)_767 + (unsigned long)HIGH_BITS) >= 0) 
    _767 = NewDouble((double)_767);
    if (IS_ATOM_INT(_767)) {
        _768 = (_767 < 1);
    }
    else {
        _768 = (DBL_PTR(_767)->dbl < (double)1);
    }
    DeRef(_767);
    _767 = NOVALUE;
    if (_768 == 0)
    {
        DeRef(_768);
        _768 = NOVALUE;
        goto L3; // [39] 50
    }
    else{
        DeRef(_768);
        _768 = NOVALUE;
    }
L2: 

    /** 		return 0*/
    DeRef(_needle_1807);
    DeRefDS(_haystack_1808);
    DeRef(_765);
    _765 = NOVALUE;
    return 0;
L3: 

    /** 	if start < 1 then*/
    if (_start_1809 >= 1)
    goto L4; // [52] 63

    /** 		start = len + start*/
    _start_1809 = _len_1811 + _start_1809;
L4: 

    /** 	for i = start to 1 by -1 do*/
    {
        int _i_1824;
        _i_1824 = _start_1809;
L5: 
        if (_i_1824 < 1){
            goto L6; // [65] 99
        }

        /** 		if equal(haystack[i], needle) then*/
        _2 = (int)SEQ_PTR(_haystack_1808);
        _771 = (int)*(((s1_ptr)_2)->base + _i_1824);
        if (_771 == _needle_1807)
        _772 = 1;
        else if (IS_ATOM_INT(_771) && IS_ATOM_INT(_needle_1807))
        _772 = 0;
        else
        _772 = (compare(_771, _needle_1807) == 0);
        _771 = NOVALUE;
        if (_772 == 0)
        {
            _772 = NOVALUE;
            goto L7; // [82] 92
        }
        else{
            _772 = NOVALUE;
        }

        /** 			return i*/
        DeRef(_needle_1807);
        DeRefDS(_haystack_1808);
        DeRef(_765);
        _765 = NOVALUE;
        return _i_1824;
L7: 

        /** 	end for*/
        _i_1824 = _i_1824 + -1;
        goto L5; // [94] 72
L6: 
        ;
    }

    /** 	return 0*/
    DeRef(_needle_1807);
    DeRefDS(_haystack_1808);
    DeRef(_765);
    _765 = NOVALUE;
    return 0;
    ;
}


int _20find_replace(int _needle_1830, int _haystack_1831, int _replacement_1832, int _max_1833)
{
    int _posn_1834 = NOVALUE;
    int _776 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer posn = 0*/
    _posn_1834 = 0;

    /** 	while posn != 0 entry do */
    goto L1; // [12] 45
L2: 
    if (_posn_1834 == 0)
    goto L3; // [15] 61

    /** 		haystack[posn] = replacement*/
    Ref(_replacement_1832);
    _2 = (int)SEQ_PTR(_haystack_1831);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _haystack_1831 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _posn_1834);
    _1 = *(int *)_2;
    *(int *)_2 = _replacement_1832;
    DeRef(_1);

    /** 		max -= 1*/
    _max_1833 = _max_1833 - 1;

    /** 		if max = 0 then*/
    if (_max_1833 != 0)
    goto L4; // [33] 42

    /** 			exit*/
    goto L3; // [39] 61
L4: 

    /** 	entry*/
L1: 

    /** 		posn = find(needle, haystack, posn + 1)*/
    _776 = _posn_1834 + 1;
    if (_776 > MAXINT){
        _776 = NewDouble((double)_776);
    }
    _posn_1834 = find_from(_needle_1830, _haystack_1831, _776);
    DeRef(_776);
    _776 = NOVALUE;

    /** 	end while*/
    goto L2; // [58] 15
L3: 

    /** 	return haystack*/
    DeRef(_needle_1830);
    DeRefi(_replacement_1832);
    return _haystack_1831;
    ;
}


int _20match_replace(int _needle_1844, int _haystack_1845, int _replacement_1846, int _max_1847)
{
    int _posn_1848 = NOVALUE;
    int _needle_len_1849 = NOVALUE;
    int _replacement_len_1850 = NOVALUE;
    int _scan_from_1851 = NOVALUE;
    int _cnt_1852 = NOVALUE;
    int _788 = NOVALUE;
    int _785 = NOVALUE;
    int _783 = NOVALUE;
    int _781 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if max < 0 then*/

    /** 	cnt = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1845)){
            _cnt_1852 = SEQ_PTR(_haystack_1845)->length;
    }
    else {
        _cnt_1852 = 1;
    }

    /** 	if max != 0 then*/

    /** 	if atom(needle) then*/
    _781 = IS_ATOM(_needle_1844);
    if (_781 == 0)
    {
        _781 = NOVALUE;
        goto L1; // [40] 50
    }
    else{
        _781 = NOVALUE;
    }

    /** 		needle = {needle}*/
    _0 = _needle_1844;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_needle_1844);
    *((int *)(_2+4)) = _needle_1844;
    _needle_1844 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	if atom(replacement) then*/
    _783 = IS_ATOM(_replacement_1846);
    if (_783 == 0)
    {
        _783 = NOVALUE;
        goto L2; // [55] 65
    }
    else{
        _783 = NOVALUE;
    }

    /** 		replacement = {replacement}*/
    _0 = _replacement_1846;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_replacement_1846);
    *((int *)(_2+4)) = _replacement_1846;
    _replacement_1846 = MAKE_SEQ(_1);
    DeRef(_0);
L2: 

    /** 	needle_len = length(needle) - 1*/
    if (IS_SEQUENCE(_needle_1844)){
            _785 = SEQ_PTR(_needle_1844)->length;
    }
    else {
        _785 = 1;
    }
    _needle_len_1849 = _785 - 1;
    _785 = NOVALUE;

    /** 	replacement_len = length(replacement)*/
    if (IS_SEQUENCE(_replacement_1846)){
            _replacement_len_1850 = SEQ_PTR(_replacement_1846)->length;
    }
    else {
        _replacement_len_1850 = 1;
    }

    /** 	scan_from = 1*/
    _scan_from_1851 = 1;

    /** 	while posn with entry do*/
    goto L3; // [86] 132
L4: 
    if (_posn_1848 == 0)
    {
        goto L5; // [91] 144
    }
    else{
    }

    /** 		haystack = replace(haystack, replacement, posn, posn + needle_len)*/
    _788 = _posn_1848 + _needle_len_1849;
    if ((long)((unsigned long)_788 + (unsigned long)HIGH_BITS) >= 0) 
    _788 = NewDouble((double)_788);
    {
        int p1 = _haystack_1845;
        int p2 = _replacement_1846;
        int p3 = _posn_1848;
        int p4 = _788;
        struct replace_block replace_params;
        replace_params.copy_to   = &p1;
        replace_params.copy_from = &p2;
        replace_params.start     = &p3;
        replace_params.stop      = &p4;
        replace_params.target    = &_haystack_1845;
        Replace( &replace_params );
    }
    DeRef(_788);
    _788 = NOVALUE;

    /** 		cnt -= 1*/
    _cnt_1852 = _cnt_1852 - 1;

    /** 		if cnt = 0 then*/
    if (_cnt_1852 != 0)
    goto L6; // [114] 123

    /** 			exit*/
    goto L5; // [120] 144
L6: 

    /** 		scan_from = posn + replacement_len*/
    _scan_from_1851 = _posn_1848 + _replacement_len_1850;

    /** 	entry*/
L3: 

    /** 		posn = match(needle, haystack, scan_from)*/
    _posn_1848 = e_match_from(_needle_1844, _haystack_1845, _scan_from_1851);

    /** 	end while*/
    goto L4; // [141] 89
L5: 

    /** 	return haystack*/
    DeRef(_needle_1844);
    DeRef(_replacement_1846);
    return _haystack_1845;
    ;
}


int _20binary_search(int _needle_1877, int _haystack_1878, int _start_point_1879, int _end_point_1880)
{
    int _lo_1881 = NOVALUE;
    int _hi_1882 = NOVALUE;
    int _mid_1883 = NOVALUE;
    int _c_1884 = NOVALUE;
    int _814 = NOVALUE;
    int _806 = NOVALUE;
    int _804 = NOVALUE;
    int _801 = NOVALUE;
    int _800 = NOVALUE;
    int _799 = NOVALUE;
    int _798 = NOVALUE;
    int _795 = NOVALUE;
    int _0, _1, _2;
    

    /** 	lo = start_point*/
    _lo_1881 = 1;

    /** 	if end_point <= 0 then*/
    if (_end_point_1880 > 0)
    goto L1; // [14] 30

    /** 		hi = length(haystack) + end_point*/
    if (IS_SEQUENCE(_haystack_1878)){
            _795 = SEQ_PTR(_haystack_1878)->length;
    }
    else {
        _795 = 1;
    }
    _hi_1882 = _795 + _end_point_1880;
    _795 = NOVALUE;
    goto L2; // [27] 36
L1: 

    /** 		hi = end_point*/
    _hi_1882 = _end_point_1880;
L2: 

    /** 	if lo<1 then*/
    if (_lo_1881 >= 1)
    goto L3; // [38] 48

    /** 		lo=1*/
    _lo_1881 = 1;
L3: 

    /** 	if lo > hi and length(haystack) > 0 then*/
    _798 = (_lo_1881 > _hi_1882);
    if (_798 == 0) {
        goto L4; // [56] 77
    }
    if (IS_SEQUENCE(_haystack_1878)){
            _800 = SEQ_PTR(_haystack_1878)->length;
    }
    else {
        _800 = 1;
    }
    _801 = (_800 > 0);
    _800 = NOVALUE;
    if (_801 == 0)
    {
        DeRef(_801);
        _801 = NOVALUE;
        goto L4; // [68] 77
    }
    else{
        DeRef(_801);
        _801 = NOVALUE;
    }

    /** 		hi = length(haystack)*/
    if (IS_SEQUENCE(_haystack_1878)){
            _hi_1882 = SEQ_PTR(_haystack_1878)->length;
    }
    else {
        _hi_1882 = 1;
    }
L4: 

    /** 	mid = start_point*/
    _mid_1883 = _start_point_1879;

    /** 	c = 0*/
    _c_1884 = 0;

    /** 	while lo <= hi do*/
L5: 
    if (_lo_1881 > _hi_1882)
    goto L6; // [92] 160

    /** 		mid = floor((lo + hi) / 2)*/
    _804 = _lo_1881 + _hi_1882;
    if ((long)((unsigned long)_804 + (unsigned long)HIGH_BITS) >= 0) 
    _804 = NewDouble((double)_804);
    if (IS_ATOM_INT(_804)) {
        _mid_1883 = _804 >> 1;
    }
    else {
        _1 = binary_op(DIVIDE, _804, 2);
        _mid_1883 = unary_op(FLOOR, _1);
        DeRef(_1);
    }
    DeRef(_804);
    _804 = NOVALUE;
    if (!IS_ATOM_INT(_mid_1883)) {
        _1 = (long)(DBL_PTR(_mid_1883)->dbl);
        DeRefDS(_mid_1883);
        _mid_1883 = _1;
    }

    /** 		c = eu:compare(needle, haystack[mid])*/
    _2 = (int)SEQ_PTR(_haystack_1878);
    _806 = (int)*(((s1_ptr)_2)->base + _mid_1883);
    if (IS_ATOM_INT(_needle_1877) && IS_ATOM_INT(_806)){
        _c_1884 = (_needle_1877 < _806) ? -1 : (_needle_1877 > _806);
    }
    else{
        _c_1884 = compare(_needle_1877, _806);
    }
    _806 = NOVALUE;

    /** 		if c < 0 then*/
    if (_c_1884 >= 0)
    goto L7; // [120] 133

    /** 			hi = mid - 1*/
    _hi_1882 = _mid_1883 - 1;
    goto L5; // [130] 92
L7: 

    /** 		elsif c > 0 then*/
    if (_c_1884 <= 0)
    goto L8; // [135] 148

    /** 			lo = mid + 1*/
    _lo_1881 = _mid_1883 + 1;
    goto L5; // [145] 92
L8: 

    /** 			return mid*/
    DeRefDS(_haystack_1878);
    DeRef(_798);
    _798 = NOVALUE;
    return _mid_1883;

    /** 	end while*/
    goto L5; // [157] 92
L6: 

    /** 	if c > 0 then*/
    if (_c_1884 <= 0)
    goto L9; // [162] 173

    /** 		mid += 1*/
    _mid_1883 = _mid_1883 + 1;
L9: 

    /** 	return -mid*/
    if ((unsigned long)_mid_1883 == 0xC0000000)
    _814 = (int)NewDouble((double)-0xC0000000);
    else
    _814 = - _mid_1883;
    DeRefDS(_haystack_1878);
    DeRef(_798);
    _798 = NOVALUE;
    return _814;
    ;
}


int _20begins(int _sub_text_1965, int _full_text_1966)
{
    int _852 = NOVALUE;
    int _851 = NOVALUE;
    int _850 = NOVALUE;
    int _848 = NOVALUE;
    int _847 = NOVALUE;
    int _846 = NOVALUE;
    int _845 = NOVALUE;
    int _844 = NOVALUE;
    int _842 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1966)){
            _842 = SEQ_PTR(_full_text_1966)->length;
    }
    else {
        _842 = 1;
    }
    if (_842 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _844 = IS_ATOM(_sub_text_1965);
    if (_844 == 0)
    {
        _844 = NOVALUE;
        goto L2; // [24] 57
    }
    else{
        _844 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[1]) then*/
    _2 = (int)SEQ_PTR(_full_text_1966);
    _845 = (int)*(((s1_ptr)_2)->base + 1);
    if (_sub_text_1965 == _845)
    _846 = 1;
    else if (IS_ATOM_INT(_sub_text_1965) && IS_ATOM_INT(_845))
    _846 = 0;
    else
    _846 = (compare(_sub_text_1965, _845) == 0);
    _845 = NOVALUE;
    if (_846 == 0)
    {
        _846 = NOVALUE;
        goto L3; // [37] 49
    }
    else{
        _846 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 1;
    goto L4; // [46] 56
L3: 

    /** 			return 0*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1965)){
            _847 = SEQ_PTR(_sub_text_1965)->length;
    }
    else {
        _847 = 1;
    }
    if (IS_SEQUENCE(_full_text_1966)){
            _848 = SEQ_PTR(_full_text_1966)->length;
    }
    else {
        _848 = 1;
    }
    if (_847 <= _848)
    goto L5; // [65] 76

    /** 		return 0*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[1.. length(sub_text)]) then*/
    if (IS_SEQUENCE(_sub_text_1965)){
            _850 = SEQ_PTR(_sub_text_1965)->length;
    }
    else {
        _850 = 1;
    }
    rhs_slice_target = (object_ptr)&_851;
    RHS_Slice(_full_text_1966, 1, _850);
    if (_sub_text_1965 == _851)
    _852 = 1;
    else if (IS_ATOM_INT(_sub_text_1965) && IS_ATOM_INT(_851))
    _852 = 0;
    else
    _852 = (compare(_sub_text_1965, _851) == 0);
    DeRefDS(_851);
    _851 = NOVALUE;
    if (_852 == 0)
    {
        _852 = NOVALUE;
        goto L6; // [90] 102
    }
    else{
        _852 = NOVALUE;
    }

    /** 		return 1*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 1;
    goto L7; // [99] 109
L6: 

    /** 		return 0*/
    DeRef(_sub_text_1965);
    DeRefDS(_full_text_1966);
    return 0;
L7: 
    ;
}


int _20ends(int _sub_text_1987, int _full_text_1988)
{
    int _868 = NOVALUE;
    int _867 = NOVALUE;
    int _866 = NOVALUE;
    int _865 = NOVALUE;
    int _864 = NOVALUE;
    int _863 = NOVALUE;
    int _862 = NOVALUE;
    int _860 = NOVALUE;
    int _859 = NOVALUE;
    int _858 = NOVALUE;
    int _857 = NOVALUE;
    int _856 = NOVALUE;
    int _855 = NOVALUE;
    int _853 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(full_text) = 0 then*/
    if (IS_SEQUENCE(_full_text_1988)){
            _853 = SEQ_PTR(_full_text_1988)->length;
    }
    else {
        _853 = 1;
    }
    if (_853 != 0)
    goto L1; // [8] 19

    /** 		return 0*/
    DeRefDSi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    return 0;
L1: 

    /** 	if atom(sub_text) then*/
    _855 = IS_ATOM(_sub_text_1987);
    if (_855 == 0)
    {
        _855 = NOVALUE;
        goto L2; // [24] 60
    }
    else{
        _855 = NOVALUE;
    }

    /** 		if equal(sub_text, full_text[$]) then*/
    if (IS_SEQUENCE(_full_text_1988)){
            _856 = SEQ_PTR(_full_text_1988)->length;
    }
    else {
        _856 = 1;
    }
    _2 = (int)SEQ_PTR(_full_text_1988);
    _857 = (int)*(((s1_ptr)_2)->base + _856);
    if (_sub_text_1987 == _857)
    _858 = 1;
    else if (IS_ATOM_INT(_sub_text_1987) && IS_ATOM_INT(_857))
    _858 = 0;
    else
    _858 = (compare(_sub_text_1987, _857) == 0);
    _857 = NOVALUE;
    if (_858 == 0)
    {
        _858 = NOVALUE;
        goto L3; // [40] 52
    }
    else{
        _858 = NOVALUE;
    }

    /** 			return 1*/
    DeRefi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    return 1;
    goto L4; // [49] 59
L3: 

    /** 			return 0*/
    DeRefi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    return 0;
L4: 
L2: 

    /** 	if length(sub_text) > length(full_text) then*/
    if (IS_SEQUENCE(_sub_text_1987)){
            _859 = SEQ_PTR(_sub_text_1987)->length;
    }
    else {
        _859 = 1;
    }
    if (IS_SEQUENCE(_full_text_1988)){
            _860 = SEQ_PTR(_full_text_1988)->length;
    }
    else {
        _860 = 1;
    }
    if (_859 <= _860)
    goto L5; // [68] 79

    /** 		return 0*/
    DeRefi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    return 0;
L5: 

    /** 	if equal(sub_text, full_text[$ - length(sub_text) + 1 .. $]) then*/
    if (IS_SEQUENCE(_full_text_1988)){
            _862 = SEQ_PTR(_full_text_1988)->length;
    }
    else {
        _862 = 1;
    }
    if (IS_SEQUENCE(_sub_text_1987)){
            _863 = SEQ_PTR(_sub_text_1987)->length;
    }
    else {
        _863 = 1;
    }
    _864 = _862 - _863;
    _862 = NOVALUE;
    _863 = NOVALUE;
    _865 = _864 + 1;
    _864 = NOVALUE;
    if (IS_SEQUENCE(_full_text_1988)){
            _866 = SEQ_PTR(_full_text_1988)->length;
    }
    else {
        _866 = 1;
    }
    rhs_slice_target = (object_ptr)&_867;
    RHS_Slice(_full_text_1988, _865, _866);
    if (_sub_text_1987 == _867)
    _868 = 1;
    else if (IS_ATOM_INT(_sub_text_1987) && IS_ATOM_INT(_867))
    _868 = 0;
    else
    _868 = (compare(_sub_text_1987, _867) == 0);
    DeRefDS(_867);
    _867 = NOVALUE;
    if (_868 == 0)
    {
        _868 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        _868 = NOVALUE;
    }

    /** 		return 1*/
    DeRefi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    _865 = NOVALUE;
    return 1;
    goto L7; // [116] 126
L6: 

    /** 		return 0*/
    DeRefi(_sub_text_1987);
    DeRefDS(_full_text_1988);
    DeRef(_865);
    _865 = NOVALUE;
    return 0;
L7: 
    ;
}



// 0x28C8A287
