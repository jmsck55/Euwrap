// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _7open_dll(int _file_name_913)
{
    int _fh_923 = NOVALUE;
    int _355 = NOVALUE;
    int _353 = NOVALUE;
    int _352 = NOVALUE;
    int _351 = NOVALUE;
    int _350 = NOVALUE;
    int _349 = NOVALUE;
    int _348 = NOVALUE;
    int _347 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(file_name) > 0 and types:string(file_name) then*/
    if (IS_SEQUENCE(_file_name_913)){
            _347 = SEQ_PTR(_file_name_913)->length;
    }
    else {
        _347 = 1;
    }
    _348 = (_347 > 0);
    _347 = NOVALUE;
    if (_348 == 0) {
        goto L1; // [12] 35
    }
    RefDS(_file_name_913);
    _350 = _9string(_file_name_913);
    if (_350 == 0) {
        DeRef(_350);
        _350 = NOVALUE;
        goto L1; // [21] 35
    }
    else {
        if (!IS_ATOM_INT(_350) && DBL_PTR(_350)->dbl == 0.0){
            DeRef(_350);
            _350 = NOVALUE;
            goto L1; // [21] 35
        }
        DeRef(_350);
        _350 = NOVALUE;
    }
    DeRef(_350);
    _350 = NOVALUE;

    /** 		return machine_func(M_OPEN_DLL, file_name)*/
    _351 = machine(50, _file_name_913);
    DeRefDS(_file_name_913);
    DeRef(_348);
    _348 = NOVALUE;
    return _351;
L1: 

    /** 	for idx = 1 to length(file_name) do*/
    if (IS_SEQUENCE(_file_name_913)){
            _352 = SEQ_PTR(_file_name_913)->length;
    }
    else {
        _352 = 1;
    }
    {
        int _idx_921;
        _idx_921 = 1;
L2: 
        if (_idx_921 > _352){
            goto L3; // [40] 82
        }

        /** 		atom fh = machine_func(M_OPEN_DLL, file_name[idx])*/
        _2 = (int)SEQ_PTR(_file_name_913);
        _353 = (int)*(((s1_ptr)_2)->base + _idx_921);
        DeRef(_fh_923);
        _fh_923 = machine(50, _353);
        _353 = NOVALUE;

        /** 		if not fh = 0 then*/
        if (IS_ATOM_INT(_fh_923)) {
            _355 = (_fh_923 == 0);
        }
        else {
            _355 = unary_op(NOT, _fh_923);
        }
        if (_355 != 0)
        goto L4; // [62] 73

        /** 			return fh*/
        DeRefDS(_file_name_913);
        DeRef(_348);
        _348 = NOVALUE;
        DeRef(_351);
        _351 = NOVALUE;
        _355 = NOVALUE;
        return _fh_923;
L4: 
        DeRef(_fh_923);
        _fh_923 = NOVALUE;

        /** 	end for*/
        _idx_921 = _idx_921 + 1;
        goto L2; // [77] 47
L3: 
        ;
    }

    /** 	return 0*/
    DeRefDS(_file_name_913);
    DeRef(_348);
    _348 = NOVALUE;
    DeRef(_351);
    _351 = NOVALUE;
    DeRef(_355);
    _355 = NOVALUE;
    return 0;
    ;
}


int _7define_c_func(int _lib_953, int _routine_name_954, int _arg_types_955, int _return_type_956)
{
    int _safe_address_inlined_safe_address_at_11_961 = NOVALUE;
    int _msg_inlined_crash_at_26_964 = NOVALUE;
    int _369 = NOVALUE;
    int _368 = NOVALUE;
    int _367 = NOVALUE;
    int _366 = NOVALUE;
    int _365 = NOVALUE;
    int _0, _1, _2;
    

    /** 	  if atom(routine_name) and not machine:safe_address(routine_name, 1, machine:A_EXECUTE) then*/
    _365 = 0;
    if (_365 == 0) {
        goto L1; // [8] 46
    }

    /** 	return 1*/
    _safe_address_inlined_safe_address_at_11_961 = 1;
    _367 = (1 == 0);
    if (_367 == 0)
    {
        DeRef(_367);
        _367 = NOVALUE;
        goto L1; // [22] 46
    }
    else{
        DeRef(_367);
        _367 = NOVALUE;
    }

    /** 	      error:crash("A C function is being defined from Non-executable memory.")*/

    /** 	msg = sprintf(fmt, data)*/
    DeRefi(_msg_inlined_crash_at_26_964);
    _msg_inlined_crash_at_26_964 = EPrintf(-9999999, _362, _5);

    /** 	machine_proc(M_CRASH, msg)*/
    machine(67, _msg_inlined_crash_at_26_964);

    /** end procedure*/
    goto L2; // [40] 43
L2: 
    DeRefi(_msg_inlined_crash_at_26_964);
    _msg_inlined_crash_at_26_964 = NOVALUE;
L1: 

    /** 	  return machine_func(M_DEFINE_C, {lib, routine_name, arg_types, return_type})*/
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_lib_953);
    *((int *)(_2+4)) = _lib_953;
    Ref(_routine_name_954);
    *((int *)(_2+8)) = _routine_name_954;
    RefDS(_arg_types_955);
    *((int *)(_2+12)) = _arg_types_955;
    *((int *)(_2+16)) = _return_type_956;
    _368 = MAKE_SEQ(_1);
    _369 = machine(51, _368);
    DeRefDS(_368);
    _368 = NOVALUE;
    DeRef(_lib_953);
    DeRefi(_routine_name_954);
    DeRefDSi(_arg_types_955);
    return _369;
    ;
}



// 0x98AAE04B
