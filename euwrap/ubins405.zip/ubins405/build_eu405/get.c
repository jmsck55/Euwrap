// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

void _16get_ch()
{
    int _4183 = NOVALUE;
    int _4182 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(input_string) then*/
    _4182 = IS_SEQUENCE(_16input_string_7690);
    if (_4182 == 0)
    {
        _4182 = NOVALUE;
        goto L1; // [8] 56
    }
    else{
        _4182 = NOVALUE;
    }

    /** 		if string_next <= length(input_string) then*/
    if (IS_SEQUENCE(_16input_string_7690)){
            _4183 = SEQ_PTR(_16input_string_7690)->length;
    }
    else {
        _4183 = 1;
    }
    if (_16string_next_7691 > _4183)
    goto L2; // [20] 47

    /** 			ch = input_string[string_next]*/
    _2 = (int)SEQ_PTR(_16input_string_7690);
    _16ch_7692 = (int)*(((s1_ptr)_2)->base + _16string_next_7691);
    if (!IS_ATOM_INT(_16ch_7692)){
        _16ch_7692 = (long)DBL_PTR(_16ch_7692)->dbl;
    }

    /** 			string_next += 1*/
    _16string_next_7691 = _16string_next_7691 + 1;
    goto L3; // [44] 81
L2: 

    /** 			ch = GET_EOF*/
    _16ch_7692 = -1;
    goto L3; // [53] 81
L1: 

    /** 		ch = getc(input_file)*/
    if (_16input_file_7689 != last_r_file_no) {
        last_r_file_ptr = which_file(_16input_file_7689, EF_READ);
        last_r_file_no = _16input_file_7689;
    }
    if (last_r_file_ptr == xstdin) {
        if (in_from_keyb) {
            _16ch_7692 = getc((FILE*)xstdin);
        }
        else
        _16ch_7692 = getc(last_r_file_ptr);
    }
    else
    _16ch_7692 = getc(last_r_file_ptr);

    /** 		if ch = GET_EOF then*/
    if (_16ch_7692 != -1)
    goto L4; // [67] 80

    /** 			string_next += 1*/
    _16string_next_7691 = _16string_next_7691 + 1;
L4: 
L3: 

    /** end procedure*/
    return;
    ;
}


int _16escape_char(int _c_7719)
{
    int _i_7720 = NOVALUE;
    int _4195 = NOVALUE;
    int _0, _1, _2;
    

    /** 	i = find(c, ESCAPE_CHARS)*/
    _i_7720 = find_from(_c_7719, _16ESCAPE_CHARS_7713, 1);

    /** 	if i = 0 then*/
    if (_i_7720 != 0)
    goto L1; // [12] 25

    /** 		return GET_FAIL*/
    return 1;
    goto L2; // [22] 36
L1: 

    /** 		return ESCAPED_CHARS[i]*/
    _2 = (int)SEQ_PTR(_16ESCAPED_CHARS_7715);
    _4195 = (int)*(((s1_ptr)_2)->base + _i_7720);
    Ref(_4195);
    return _4195;
L2: 
    ;
}


int _16get_qchar()
{
    int _c_7728 = NOVALUE;
    int _4204 = NOVALUE;
    int _4203 = NOVALUE;
    int _4201 = NOVALUE;
    int _4199 = NOVALUE;
    int _0, _1, _2;
    

    /** 	get_ch()*/
    _16get_ch();

    /** 	c = ch*/
    _c_7728 = _16ch_7692;

    /** 	if ch = '\\' then*/
    if (_16ch_7692 != 92)
    goto L1; // [16] 54

    /** 		get_ch()*/
    _16get_ch();

    /** 		c = escape_char(ch)*/
    _c_7728 = _16escape_char(_16ch_7692);
    if (!IS_ATOM_INT(_c_7728)) {
        _1 = (long)(DBL_PTR(_c_7728)->dbl);
        DeRefDS(_c_7728);
        _c_7728 = _1;
    }

    /** 		if c = GET_FAIL then*/
    if (_c_7728 != 1)
    goto L2; // [36] 74

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4199 = MAKE_SEQ(_1);
    return _4199;
    goto L2; // [51] 74
L1: 

    /** 	elsif ch = '\'' then*/
    if (_16ch_7692 != 39)
    goto L3; // [58] 73

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4201 = MAKE_SEQ(_1);
    DeRef(_4199);
    _4199 = NOVALUE;
    return _4201;
L3: 
L2: 

    /** 	get_ch()*/
    _16get_ch();

    /** 	if ch != '\'' then*/
    if (_16ch_7692 == 39)
    goto L4; // [82] 99

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4203 = MAKE_SEQ(_1);
    DeRef(_4199);
    _4199 = NOVALUE;
    DeRef(_4201);
    _4201 = NOVALUE;
    return _4203;
    goto L5; // [96] 114
L4: 

    /** 		get_ch()*/
    _16get_ch();

    /** 		return {GET_SUCCESS, c}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _c_7728;
    _4204 = MAKE_SEQ(_1);
    DeRef(_4199);
    _4199 = NOVALUE;
    DeRef(_4201);
    _4201 = NOVALUE;
    DeRef(_4203);
    _4203 = NOVALUE;
    return _4204;
L5: 
    ;
}


int _16get_string()
{
    int _text_7745 = NOVALUE;
    int _4214 = NOVALUE;
    int _4210 = NOVALUE;
    int _4208 = NOVALUE;
    int _4207 = NOVALUE;
    int _4205 = NOVALUE;
    int _0, _1, _2;
    

    /** 	text = ""*/
    RefDS(_5);
    DeRefi(_text_7745);
    _text_7745 = _5;

    /** 	while TRUE do*/
L1: 

    /** 		get_ch()*/
    _16get_ch();

    /** 		if ch = GET_EOF or ch = '\n' then*/
    _4205 = (_16ch_7692 == -1);
    if (_4205 != 0) {
        goto L2; // [25] 40
    }
    _4207 = (_16ch_7692 == 10);
    if (_4207 == 0)
    {
        DeRef(_4207);
        _4207 = NOVALUE;
        goto L3; // [36] 53
    }
    else{
        DeRef(_4207);
        _4207 = NOVALUE;
    }
L2: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4208 = MAKE_SEQ(_1);
    DeRefi(_text_7745);
    DeRef(_4205);
    _4205 = NOVALUE;
    return _4208;
    goto L4; // [50] 121
L3: 

    /** 		elsif ch = '"' then*/
    if (_16ch_7692 != 34)
    goto L5; // [57] 78

    /** 			get_ch()*/
    _16get_ch();

    /** 			return {GET_SUCCESS, text}*/
    RefDS(_text_7745);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _text_7745;
    _4210 = MAKE_SEQ(_1);
    DeRefDSi(_text_7745);
    DeRef(_4205);
    _4205 = NOVALUE;
    DeRef(_4208);
    _4208 = NOVALUE;
    return _4210;
    goto L4; // [75] 121
L5: 

    /** 		elsif ch = '\\' then*/
    if (_16ch_7692 != 92)
    goto L6; // [82] 120

    /** 			get_ch()*/
    _16get_ch();

    /** 			ch = escape_char(ch)*/
    _0 = _16escape_char(_16ch_7692);
    _16ch_7692 = _0;
    if (!IS_ATOM_INT(_16ch_7692)) {
        _1 = (long)(DBL_PTR(_16ch_7692)->dbl);
        DeRefDS(_16ch_7692);
        _16ch_7692 = _1;
    }

    /** 			if ch = GET_FAIL then*/
    if (_16ch_7692 != 1)
    goto L7; // [104] 119

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4214 = MAKE_SEQ(_1);
    DeRefi(_text_7745);
    DeRef(_4205);
    _4205 = NOVALUE;
    DeRef(_4208);
    _4208 = NOVALUE;
    DeRef(_4210);
    _4210 = NOVALUE;
    return _4214;
L7: 
L6: 
L4: 

    /** 		text = text & ch*/
    Append(&_text_7745, _text_7745, _16ch_7692);

    /** 	end while*/
    goto L1; // [131] 13
    ;
}


int _16read_comment()
{
    int _4235 = NOVALUE;
    int _4234 = NOVALUE;
    int _4232 = NOVALUE;
    int _4230 = NOVALUE;
    int _4228 = NOVALUE;
    int _4227 = NOVALUE;
    int _4226 = NOVALUE;
    int _4224 = NOVALUE;
    int _4223 = NOVALUE;
    int _4222 = NOVALUE;
    int _4221 = NOVALUE;
    int _4220 = NOVALUE;
    int _4219 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(input_string) then*/
    _4219 = IS_ATOM(_16input_string_7690);
    if (_4219 == 0)
    {
        _4219 = NOVALUE;
        goto L1; // [8] 98
    }
    else{
        _4219 = NOVALUE;
    }

    /** 		while ch!='\n' and ch!='\r' and ch!=-1 do*/
L2: 
    _4220 = (_16ch_7692 != 10);
    if (_4220 == 0) {
        _4221 = 0;
        goto L3; // [22] 36
    }
    _4222 = (_16ch_7692 != 13);
    _4221 = (_4222 != 0);
L3: 
    if (_4221 == 0) {
        goto L4; // [36] 59
    }
    _4224 = (_16ch_7692 != -1);
    if (_4224 == 0)
    {
        DeRef(_4224);
        _4224 = NOVALUE;
        goto L4; // [47] 59
    }
    else{
        DeRef(_4224);
        _4224 = NOVALUE;
    }

    /** 			get_ch()*/
    _16get_ch();

    /** 		end while*/
    goto L2; // [56] 16
L4: 

    /** 		get_ch()*/
    _16get_ch();

    /** 		if ch=-1 then*/
    if (_16ch_7692 != -1)
    goto L5; // [67] 84

    /** 			return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _4226 = MAKE_SEQ(_1);
    DeRef(_4220);
    _4220 = NOVALUE;
    DeRef(_4222);
    _4222 = NOVALUE;
    return _4226;
    goto L6; // [81] 182
L5: 

    /** 			return {GET_IGNORE, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _4227 = MAKE_SEQ(_1);
    DeRef(_4220);
    _4220 = NOVALUE;
    DeRef(_4222);
    _4222 = NOVALUE;
    DeRef(_4226);
    _4226 = NOVALUE;
    return _4227;
    goto L6; // [95] 182
L1: 

    /** 		for i=string_next to length(input_string) do*/
    if (IS_SEQUENCE(_16input_string_7690)){
            _4228 = SEQ_PTR(_16input_string_7690)->length;
    }
    else {
        _4228 = 1;
    }
    {
        int _i_7786;
        _i_7786 = _16string_next_7691;
L7: 
        if (_i_7786 > _4228){
            goto L8; // [107] 171
        }

        /** 			ch=input_string[i]*/
        _2 = (int)SEQ_PTR(_16input_string_7690);
        _16ch_7692 = (int)*(((s1_ptr)_2)->base + _i_7786);
        if (!IS_ATOM_INT(_16ch_7692)){
            _16ch_7692 = (long)DBL_PTR(_16ch_7692)->dbl;
        }

        /** 			if ch='\n' or ch='\r' then*/
        _4230 = (_16ch_7692 == 10);
        if (_4230 != 0) {
            goto L9; // [132] 147
        }
        _4232 = (_16ch_7692 == 13);
        if (_4232 == 0)
        {
            DeRef(_4232);
            _4232 = NOVALUE;
            goto LA; // [143] 164
        }
        else{
            DeRef(_4232);
            _4232 = NOVALUE;
        }
L9: 

        /** 				string_next=i+1*/
        _16string_next_7691 = _i_7786 + 1;

        /** 				return {GET_IGNORE, 0}*/
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -2;
        ((int *)_2)[2] = 0;
        _4234 = MAKE_SEQ(_1);
        DeRef(_4220);
        _4220 = NOVALUE;
        DeRef(_4222);
        _4222 = NOVALUE;
        DeRef(_4226);
        _4226 = NOVALUE;
        DeRef(_4227);
        _4227 = NOVALUE;
        DeRef(_4230);
        _4230 = NOVALUE;
        return _4234;
LA: 

        /** 		end for*/
        _i_7786 = _i_7786 + 1;
        goto L7; // [166] 114
L8: 
        ;
    }

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _4235 = MAKE_SEQ(_1);
    DeRef(_4220);
    _4220 = NOVALUE;
    DeRef(_4222);
    _4222 = NOVALUE;
    DeRef(_4226);
    _4226 = NOVALUE;
    DeRef(_4227);
    _4227 = NOVALUE;
    DeRef(_4230);
    _4230 = NOVALUE;
    DeRef(_4234);
    _4234 = NOVALUE;
    return _4235;
L6: 
    ;
}


int _16get_number()
{
    int _sign_7798 = NOVALUE;
    int _e_sign_7799 = NOVALUE;
    int _ndigits_7800 = NOVALUE;
    int _hex_digit_7801 = NOVALUE;
    int _mantissa_7802 = NOVALUE;
    int _dec_7803 = NOVALUE;
    int _e_mag_7804 = NOVALUE;
    int _4296 = NOVALUE;
    int _4294 = NOVALUE;
    int _4292 = NOVALUE;
    int _4289 = NOVALUE;
    int _4285 = NOVALUE;
    int _4283 = NOVALUE;
    int _4282 = NOVALUE;
    int _4281 = NOVALUE;
    int _4280 = NOVALUE;
    int _4279 = NOVALUE;
    int _4277 = NOVALUE;
    int _4276 = NOVALUE;
    int _4275 = NOVALUE;
    int _4272 = NOVALUE;
    int _4270 = NOVALUE;
    int _4268 = NOVALUE;
    int _4264 = NOVALUE;
    int _4263 = NOVALUE;
    int _4261 = NOVALUE;
    int _4260 = NOVALUE;
    int _4259 = NOVALUE;
    int _4256 = NOVALUE;
    int _4255 = NOVALUE;
    int _4253 = NOVALUE;
    int _4252 = NOVALUE;
    int _4251 = NOVALUE;
    int _4250 = NOVALUE;
    int _4249 = NOVALUE;
    int _4248 = NOVALUE;
    int _4245 = NOVALUE;
    int _4241 = NOVALUE;
    int _4238 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sign = +1*/
    _sign_7798 = 1;

    /** 	mantissa = 0*/
    DeRef(_mantissa_7802);
    _mantissa_7802 = 0;

    /** 	ndigits = 0*/
    _ndigits_7800 = 0;

    /** 	if ch = '-' then*/
    if (_16ch_7692 != 45)
    goto L1; // [20] 54

    /** 		sign = -1*/
    _sign_7798 = -1;

    /** 		get_ch()*/
    _16get_ch();

    /** 		if ch='-' then*/
    if (_16ch_7692 != 45)
    goto L2; // [37] 68

    /** 			return read_comment()*/
    _4238 = _16read_comment();
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    return _4238;
    goto L2; // [51] 68
L1: 

    /** 	elsif ch = '+' then*/
    if (_16ch_7692 != 43)
    goto L3; // [58] 67

    /** 		get_ch()*/
    _16get_ch();
L3: 
L2: 

    /** 	if ch = '#' then*/
    if (_16ch_7692 != 35)
    goto L4; // [72] 170

    /** 		get_ch()*/
    _16get_ch();

    /** 		while TRUE do*/
L5: 

    /** 			hex_digit = find(ch, HEX_DIGITS)-1*/
    _4241 = find_from(_16ch_7692, _16HEX_DIGITS_7672, 1);
    _hex_digit_7801 = _4241 - 1;
    _4241 = NOVALUE;

    /** 			if hex_digit >= 0 then*/
    if (_hex_digit_7801 < 0)
    goto L6; // [102] 129

    /** 				ndigits += 1*/
    _ndigits_7800 = _ndigits_7800 + 1;

    /** 				mantissa = mantissa * 16 + hex_digit*/
    if (IS_ATOM_INT(_mantissa_7802)) {
        if (_mantissa_7802 == (short)_mantissa_7802)
        _4245 = _mantissa_7802 * 16;
        else
        _4245 = NewDouble(_mantissa_7802 * (double)16);
    }
    else {
        _4245 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * (double)16);
    }
    DeRef(_mantissa_7802);
    if (IS_ATOM_INT(_4245)) {
        _mantissa_7802 = _4245 + _hex_digit_7801;
        if ((long)((unsigned long)_mantissa_7802 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_7802 = NewDouble((double)_mantissa_7802);
    }
    else {
        _mantissa_7802 = NewDouble(DBL_PTR(_4245)->dbl + (double)_hex_digit_7801);
    }
    DeRef(_4245);
    _4245 = NOVALUE;

    /** 				get_ch()*/
    _16get_ch();
    goto L5; // [126] 85
L6: 

    /** 				if ndigits > 0 then*/
    if (_ndigits_7800 <= 0)
    goto L7; // [131] 152

    /** 					return {GET_SUCCESS, sign * mantissa}*/
    if (IS_ATOM_INT(_mantissa_7802)) {
        if (_sign_7798 == (short)_sign_7798 && _mantissa_7802 <= INT15 && _mantissa_7802 >= -INT15)
        _4248 = _sign_7798 * _mantissa_7802;
        else
        _4248 = NewDouble(_sign_7798 * (double)_mantissa_7802);
    }
    else {
        _4248 = NewDouble((double)_sign_7798 * DBL_PTR(_mantissa_7802)->dbl);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _4248;
    _4249 = MAKE_SEQ(_1);
    _4248 = NOVALUE;
    DeRef(_mantissa_7802);
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    DeRef(_4238);
    _4238 = NOVALUE;
    return _4249;
    goto L5; // [149] 85
L7: 

    /** 					return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4250 = MAKE_SEQ(_1);
    DeRef(_mantissa_7802);
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    DeRef(_4238);
    _4238 = NOVALUE;
    DeRef(_4249);
    _4249 = NOVALUE;
    return _4250;

    /** 		end while*/
    goto L5; // [166] 85
L4: 

    /** 	while ch >= '0' and ch <= '9' do*/
L8: 
    _4251 = (_16ch_7692 >= 48);
    if (_4251 == 0) {
        goto L9; // [181] 226
    }
    _4253 = (_16ch_7692 <= 57);
    if (_4253 == 0)
    {
        DeRef(_4253);
        _4253 = NOVALUE;
        goto L9; // [192] 226
    }
    else{
        DeRef(_4253);
        _4253 = NOVALUE;
    }

    /** 		ndigits += 1*/
    _ndigits_7800 = _ndigits_7800 + 1;

    /** 		mantissa = mantissa * 10 + (ch - '0')*/
    if (IS_ATOM_INT(_mantissa_7802)) {
        if (_mantissa_7802 == (short)_mantissa_7802)
        _4255 = _mantissa_7802 * 10;
        else
        _4255 = NewDouble(_mantissa_7802 * (double)10);
    }
    else {
        _4255 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * (double)10);
    }
    _4256 = _16ch_7692 - 48;
    if ((long)((unsigned long)_4256 +(unsigned long) HIGH_BITS) >= 0){
        _4256 = NewDouble((double)_4256);
    }
    DeRef(_mantissa_7802);
    if (IS_ATOM_INT(_4255) && IS_ATOM_INT(_4256)) {
        _mantissa_7802 = _4255 + _4256;
        if ((long)((unsigned long)_mantissa_7802 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_7802 = NewDouble((double)_mantissa_7802);
    }
    else {
        if (IS_ATOM_INT(_4255)) {
            _mantissa_7802 = NewDouble((double)_4255 + DBL_PTR(_4256)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4256)) {
                _mantissa_7802 = NewDouble(DBL_PTR(_4255)->dbl + (double)_4256);
            }
            else
            _mantissa_7802 = NewDouble(DBL_PTR(_4255)->dbl + DBL_PTR(_4256)->dbl);
        }
    }
    DeRef(_4255);
    _4255 = NOVALUE;
    DeRef(_4256);
    _4256 = NOVALUE;

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L8; // [223] 175
L9: 

    /** 	if ch = '.' then*/
    if (_16ch_7692 != 46)
    goto LA; // [230] 306

    /** 		get_ch()*/
    _16get_ch();

    /** 		dec = 10*/
    DeRef(_dec_7803);
    _dec_7803 = 10;

    /** 		while ch >= '0' and ch <= '9' do*/
LB: 
    _4259 = (_16ch_7692 >= 48);
    if (_4259 == 0) {
        goto LC; // [254] 305
    }
    _4261 = (_16ch_7692 <= 57);
    if (_4261 == 0)
    {
        DeRef(_4261);
        _4261 = NOVALUE;
        goto LC; // [265] 305
    }
    else{
        DeRef(_4261);
        _4261 = NOVALUE;
    }

    /** 			ndigits += 1*/
    _ndigits_7800 = _ndigits_7800 + 1;

    /** 			mantissa += (ch - '0') / dec*/
    _4263 = _16ch_7692 - 48;
    if ((long)((unsigned long)_4263 +(unsigned long) HIGH_BITS) >= 0){
        _4263 = NewDouble((double)_4263);
    }
    if (IS_ATOM_INT(_4263) && IS_ATOM_INT(_dec_7803)) {
        _4264 = (_4263 % _dec_7803) ? NewDouble((double)_4263 / _dec_7803) : (_4263 / _dec_7803);
    }
    else {
        if (IS_ATOM_INT(_4263)) {
            _4264 = NewDouble((double)_4263 / DBL_PTR(_dec_7803)->dbl);
        }
        else {
            if (IS_ATOM_INT(_dec_7803)) {
                _4264 = NewDouble(DBL_PTR(_4263)->dbl / (double)_dec_7803);
            }
            else
            _4264 = NewDouble(DBL_PTR(_4263)->dbl / DBL_PTR(_dec_7803)->dbl);
        }
    }
    DeRef(_4263);
    _4263 = NOVALUE;
    _0 = _mantissa_7802;
    if (IS_ATOM_INT(_mantissa_7802) && IS_ATOM_INT(_4264)) {
        _mantissa_7802 = _mantissa_7802 + _4264;
        if ((long)((unsigned long)_mantissa_7802 + (unsigned long)HIGH_BITS) >= 0) 
        _mantissa_7802 = NewDouble((double)_mantissa_7802);
    }
    else {
        if (IS_ATOM_INT(_mantissa_7802)) {
            _mantissa_7802 = NewDouble((double)_mantissa_7802 + DBL_PTR(_4264)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4264)) {
                _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl + (double)_4264);
            }
            else
            _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl + DBL_PTR(_4264)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_4264);
    _4264 = NOVALUE;

    /** 			dec *= 10*/
    _0 = _dec_7803;
    if (IS_ATOM_INT(_dec_7803)) {
        if (_dec_7803 == (short)_dec_7803)
        _dec_7803 = _dec_7803 * 10;
        else
        _dec_7803 = NewDouble(_dec_7803 * (double)10);
    }
    else {
        _dec_7803 = NewDouble(DBL_PTR(_dec_7803)->dbl * (double)10);
    }
    DeRef(_0);

    /** 			get_ch()*/
    _16get_ch();

    /** 		end while*/
    goto LB; // [302] 248
LC: 
LA: 

    /** 	if ndigits = 0 then*/
    if (_ndigits_7800 != 0)
    goto LD; // [308] 323

    /** 		return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4268 = MAKE_SEQ(_1);
    DeRef(_mantissa_7802);
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    DeRef(_4238);
    _4238 = NOVALUE;
    DeRef(_4249);
    _4249 = NOVALUE;
    DeRef(_4250);
    _4250 = NOVALUE;
    DeRef(_4251);
    _4251 = NOVALUE;
    DeRef(_4259);
    _4259 = NOVALUE;
    return _4268;
LD: 

    /** 	mantissa = sign * mantissa*/
    _0 = _mantissa_7802;
    if (IS_ATOM_INT(_mantissa_7802)) {
        if (_sign_7798 == (short)_sign_7798 && _mantissa_7802 <= INT15 && _mantissa_7802 >= -INT15)
        _mantissa_7802 = _sign_7798 * _mantissa_7802;
        else
        _mantissa_7802 = NewDouble(_sign_7798 * (double)_mantissa_7802);
    }
    else {
        _mantissa_7802 = NewDouble((double)_sign_7798 * DBL_PTR(_mantissa_7802)->dbl);
    }
    DeRef(_0);

    /** 	if ch = 'e' or ch = 'E' then*/
    _4270 = (_16ch_7692 == 101);
    if (_4270 != 0) {
        goto LE; // [337] 352
    }
    _4272 = (_16ch_7692 == 69);
    if (_4272 == 0)
    {
        DeRef(_4272);
        _4272 = NOVALUE;
        goto LF; // [348] 573
    }
    else{
        DeRef(_4272);
        _4272 = NOVALUE;
    }
LE: 

    /** 		e_sign = +1*/
    _e_sign_7799 = 1;

    /** 		e_mag = 0*/
    DeRef(_e_mag_7804);
    _e_mag_7804 = 0;

    /** 		get_ch()*/
    _16get_ch();

    /** 		if ch = '-' then*/
    if (_16ch_7692 != 45)
    goto L10; // [370] 386

    /** 			e_sign = -1*/
    _e_sign_7799 = -1;

    /** 			get_ch()*/
    _16get_ch();
    goto L11; // [383] 400
L10: 

    /** 		elsif ch = '+' then*/
    if (_16ch_7692 != 43)
    goto L12; // [390] 399

    /** 			get_ch()*/
    _16get_ch();
L12: 
L11: 

    /** 		if ch >= '0' and ch <= '9' then*/
    _4275 = (_16ch_7692 >= 48);
    if (_4275 == 0) {
        goto L13; // [408] 487
    }
    _4277 = (_16ch_7692 <= 57);
    if (_4277 == 0)
    {
        DeRef(_4277);
        _4277 = NOVALUE;
        goto L13; // [419] 487
    }
    else{
        DeRef(_4277);
        _4277 = NOVALUE;
    }

    /** 			e_mag = ch - '0'*/
    DeRef(_e_mag_7804);
    _e_mag_7804 = _16ch_7692 - 48;
    if ((long)((unsigned long)_e_mag_7804 +(unsigned long) HIGH_BITS) >= 0){
        _e_mag_7804 = NewDouble((double)_e_mag_7804);
    }

    /** 			get_ch()*/
    _16get_ch();

    /** 			while ch >= '0' and ch <= '9' do*/
L14: 
    _4279 = (_16ch_7692 >= 48);
    if (_4279 == 0) {
        goto L15; // [445] 498
    }
    _4281 = (_16ch_7692 <= 57);
    if (_4281 == 0)
    {
        DeRef(_4281);
        _4281 = NOVALUE;
        goto L15; // [456] 498
    }
    else{
        DeRef(_4281);
        _4281 = NOVALUE;
    }

    /** 				e_mag = e_mag * 10 + ch - '0'*/
    if (IS_ATOM_INT(_e_mag_7804)) {
        if (_e_mag_7804 == (short)_e_mag_7804)
        _4282 = _e_mag_7804 * 10;
        else
        _4282 = NewDouble(_e_mag_7804 * (double)10);
    }
    else {
        _4282 = NewDouble(DBL_PTR(_e_mag_7804)->dbl * (double)10);
    }
    if (IS_ATOM_INT(_4282)) {
        _4283 = _4282 + _16ch_7692;
        if ((long)((unsigned long)_4283 + (unsigned long)HIGH_BITS) >= 0) 
        _4283 = NewDouble((double)_4283);
    }
    else {
        _4283 = NewDouble(DBL_PTR(_4282)->dbl + (double)_16ch_7692);
    }
    DeRef(_4282);
    _4282 = NOVALUE;
    DeRef(_e_mag_7804);
    if (IS_ATOM_INT(_4283)) {
        _e_mag_7804 = _4283 - 48;
        if ((long)((unsigned long)_e_mag_7804 +(unsigned long) HIGH_BITS) >= 0){
            _e_mag_7804 = NewDouble((double)_e_mag_7804);
        }
    }
    else {
        _e_mag_7804 = NewDouble(DBL_PTR(_4283)->dbl - (double)48);
    }
    DeRef(_4283);
    _4283 = NOVALUE;

    /** 				get_ch()*/
    _16get_ch();

    /** 			end while*/
    goto L14; // [481] 439
    goto L15; // [484] 498
L13: 

    /** 			return {GET_FAIL, 0} -- no exponent*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4285 = MAKE_SEQ(_1);
    DeRef(_mantissa_7802);
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    DeRef(_4238);
    _4238 = NOVALUE;
    DeRef(_4249);
    _4249 = NOVALUE;
    DeRef(_4250);
    _4250 = NOVALUE;
    DeRef(_4251);
    _4251 = NOVALUE;
    DeRef(_4259);
    _4259 = NOVALUE;
    DeRef(_4268);
    _4268 = NOVALUE;
    DeRef(_4270);
    _4270 = NOVALUE;
    DeRef(_4275);
    _4275 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    return _4285;
L15: 

    /** 		e_mag *= e_sign*/
    _0 = _e_mag_7804;
    if (IS_ATOM_INT(_e_mag_7804)) {
        if (_e_mag_7804 == (short)_e_mag_7804 && _e_sign_7799 <= INT15 && _e_sign_7799 >= -INT15)
        _e_mag_7804 = _e_mag_7804 * _e_sign_7799;
        else
        _e_mag_7804 = NewDouble(_e_mag_7804 * (double)_e_sign_7799);
    }
    else {
        _e_mag_7804 = NewDouble(DBL_PTR(_e_mag_7804)->dbl * (double)_e_sign_7799);
    }
    DeRef(_0);

    /** 		if e_mag > 308 then*/
    if (binary_op_a(LESSEQ, _e_mag_7804, 308)){
        goto L16; // [506] 561
    }

    /** 			mantissa *= power(10, 308)*/
    _4289 = power(10, 308);
    _0 = _mantissa_7802;
    if (IS_ATOM_INT(_mantissa_7802) && IS_ATOM_INT(_4289)) {
        if (_mantissa_7802 == (short)_mantissa_7802 && _4289 <= INT15 && _4289 >= -INT15)
        _mantissa_7802 = _mantissa_7802 * _4289;
        else
        _mantissa_7802 = NewDouble(_mantissa_7802 * (double)_4289);
    }
    else {
        if (IS_ATOM_INT(_mantissa_7802)) {
            _mantissa_7802 = NewDouble((double)_mantissa_7802 * DBL_PTR(_4289)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4289)) {
                _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * (double)_4289);
            }
            else
            _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * DBL_PTR(_4289)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_4289);
    _4289 = NOVALUE;

    /** 			if e_mag > 1000 then*/
    if (binary_op_a(LESSEQ, _e_mag_7804, 1000)){
        goto L17; // [522] 532
    }

    /** 				e_mag = 1000*/
    DeRef(_e_mag_7804);
    _e_mag_7804 = 1000;
L17: 

    /** 			for i = 1 to e_mag - 308 do*/
    if (IS_ATOM_INT(_e_mag_7804)) {
        _4292 = _e_mag_7804 - 308;
        if ((long)((unsigned long)_4292 +(unsigned long) HIGH_BITS) >= 0){
            _4292 = NewDouble((double)_4292);
        }
    }
    else {
        _4292 = NewDouble(DBL_PTR(_e_mag_7804)->dbl - (double)308);
    }
    {
        int _i_7883;
        _i_7883 = 1;
L18: 
        if (binary_op_a(GREATER, _i_7883, _4292)){
            goto L19; // [538] 558
        }

        /** 				mantissa *= 10*/
        _0 = _mantissa_7802;
        if (IS_ATOM_INT(_mantissa_7802)) {
            if (_mantissa_7802 == (short)_mantissa_7802)
            _mantissa_7802 = _mantissa_7802 * 10;
            else
            _mantissa_7802 = NewDouble(_mantissa_7802 * (double)10);
        }
        else {
            _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * (double)10);
        }
        DeRef(_0);

        /** 			end for*/
        _0 = _i_7883;
        if (IS_ATOM_INT(_i_7883)) {
            _i_7883 = _i_7883 + 1;
            if ((long)((unsigned long)_i_7883 +(unsigned long) HIGH_BITS) >= 0){
                _i_7883 = NewDouble((double)_i_7883);
            }
        }
        else {
            _i_7883 = binary_op_a(PLUS, _i_7883, 1);
        }
        DeRef(_0);
        goto L18; // [553] 545
L19: 
        ;
        DeRef(_i_7883);
    }
    goto L1A; // [558] 572
L16: 

    /** 			mantissa *= power(10, e_mag)*/
    if (IS_ATOM_INT(_e_mag_7804)) {
        _4294 = power(10, _e_mag_7804);
    }
    else {
        temp_d.dbl = (double)10;
        _4294 = Dpower(&temp_d, DBL_PTR(_e_mag_7804));
    }
    _0 = _mantissa_7802;
    if (IS_ATOM_INT(_mantissa_7802) && IS_ATOM_INT(_4294)) {
        if (_mantissa_7802 == (short)_mantissa_7802 && _4294 <= INT15 && _4294 >= -INT15)
        _mantissa_7802 = _mantissa_7802 * _4294;
        else
        _mantissa_7802 = NewDouble(_mantissa_7802 * (double)_4294);
    }
    else {
        if (IS_ATOM_INT(_mantissa_7802)) {
            _mantissa_7802 = NewDouble((double)_mantissa_7802 * DBL_PTR(_4294)->dbl);
        }
        else {
            if (IS_ATOM_INT(_4294)) {
                _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * (double)_4294);
            }
            else
            _mantissa_7802 = NewDouble(DBL_PTR(_mantissa_7802)->dbl * DBL_PTR(_4294)->dbl);
        }
    }
    DeRef(_0);
    DeRef(_4294);
    _4294 = NOVALUE;
L1A: 
LF: 

    /** 	return {GET_SUCCESS, mantissa}*/
    Ref(_mantissa_7802);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _mantissa_7802;
    _4296 = MAKE_SEQ(_1);
    DeRef(_mantissa_7802);
    DeRef(_dec_7803);
    DeRef(_e_mag_7804);
    DeRef(_4238);
    _4238 = NOVALUE;
    DeRef(_4249);
    _4249 = NOVALUE;
    DeRef(_4250);
    _4250 = NOVALUE;
    DeRef(_4251);
    _4251 = NOVALUE;
    DeRef(_4259);
    _4259 = NOVALUE;
    DeRef(_4268);
    _4268 = NOVALUE;
    DeRef(_4270);
    _4270 = NOVALUE;
    DeRef(_4275);
    _4275 = NOVALUE;
    DeRef(_4279);
    _4279 = NOVALUE;
    DeRef(_4285);
    _4285 = NOVALUE;
    DeRef(_4292);
    _4292 = NOVALUE;
    return _4296;
    ;
}


int _16Get()
{
    int _skip_blanks_1__tmp_at328_7936 = NOVALUE;
    int _skip_blanks_1__tmp_at177_7917 = NOVALUE;
    int _skip_blanks_1__tmp_at88_7908 = NOVALUE;
    int _s_7892 = NOVALUE;
    int _e_7893 = NOVALUE;
    int _e1_7894 = NOVALUE;
    int _4332 = NOVALUE;
    int _4331 = NOVALUE;
    int _4329 = NOVALUE;
    int _4327 = NOVALUE;
    int _4325 = NOVALUE;
    int _4323 = NOVALUE;
    int _4320 = NOVALUE;
    int _4318 = NOVALUE;
    int _4314 = NOVALUE;
    int _4310 = NOVALUE;
    int _4307 = NOVALUE;
    int _4306 = NOVALUE;
    int _4304 = NOVALUE;
    int _4302 = NOVALUE;
    int _4300 = NOVALUE;
    int _4299 = NOVALUE;
    int _4297 = NOVALUE;
    int _0, _1, _2;
    

    /** 	while find(ch, white_space) do*/
L1: 
    _4297 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_4297 == 0)
    {
        _4297 = NOVALUE;
        goto L2; // [13] 25
    }
    else{
        _4297 = NOVALUE;
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L1; // [22] 6
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_16ch_7692 != -1)
    goto L3; // [29] 44

    /** 		return {GET_EOF, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -1;
    ((int *)_2)[2] = 0;
    _4299 = MAKE_SEQ(_1);
    DeRef(_s_7892);
    DeRef(_e_7893);
    return _4299;
L3: 

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _4300 = find_from(_16ch_7692, _16START_NUMERIC_7675, 1);
    if (_4300 == 0)
    {
        _4300 = NOVALUE;
        goto L5; // [60] 157
    }
    else{
        _4300 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_7893;
    _e_7893 = _16get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_7893);
    _4302 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4302, -2)){
        _4302 = NOVALUE;
        goto L6; // [76] 87
    }
    _4302 = NOVALUE;

    /** 				return e*/
    DeRef(_s_7892);
    DeRef(_4299);
    _4299 = NOVALUE;
    return _e_7893;
L6: 

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L7: 
    _skip_blanks_1__tmp_at88_7908 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_skip_blanks_1__tmp_at88_7908 == 0)
    {
        goto L8; // [101] 118
    }
    else{
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L7; // [110] 94

    /** end procedure*/
    goto L8; // [115] 118
L8: 

    /** 			if ch=-1 or ch='}' then -- '}' is expected only in the "{--\n}" case*/
    _4304 = (_16ch_7692 == -1);
    if (_4304 != 0) {
        goto L9; // [128] 143
    }
    _4306 = (_16ch_7692 == 125);
    if (_4306 == 0)
    {
        DeRef(_4306);
        _4306 = NOVALUE;
        goto L4; // [139] 49
    }
    else{
        DeRef(_4306);
        _4306 = NOVALUE;
    }
L9: 

    /** 				return {GET_NOTHING, 0} -- just a comment*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = -2;
    ((int *)_2)[2] = 0;
    _4307 = MAKE_SEQ(_1);
    DeRef(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    return _4307;
    goto L4; // [154] 49
L5: 

    /** 		elsif ch = '{' then*/
    if (_16ch_7692 != 123)
    goto LA; // [161] 465

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_7892);
    _s_7892 = _5;

    /** 			get_ch()*/
    _16get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
LB: 
    _skip_blanks_1__tmp_at177_7917 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_skip_blanks_1__tmp_at177_7917 == 0)
    {
        goto LC; // [190] 207
    }
    else{
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto LB; // [199] 183

    /** end procedure*/
    goto LC; // [204] 207
LC: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_16ch_7692 != 125)
    goto LD; // [213] 232

    /** 				get_ch()*/
    _16get_ch();

    /** 				return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_7892);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_7892;
    _4310 = MAKE_SEQ(_1);
    DeRefDS(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    return _4310;
LD: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LE: 

    /** 				while 1 do -- read zero or more comments and an element*/
LF: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_7893;
    _e_7893 = _16Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_7893);
    _e1_7894 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_7894))
    _e1_7894 = (long)DBL_PTR(_e1_7894)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_7894 != 0)
    goto L10; // [257] 278

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_7893);
    _4314 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_4314);
    Append(&_s_7892, _s_7892, _4314);
    _4314 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto L11; // [273] 322
    goto LF; // [275] 242
L10: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_7894 == -2)
    goto L12; // [280] 293

    /** 						return e*/
    DeRef(_s_7892);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    return _e_7893;
    goto LF; // [290] 242
L12: 

    /** 					elsif ch='}' then*/
    if (_16ch_7692 != 125)
    goto LF; // [297] 242

    /** 						get_ch()*/
    _16get_ch();

    /** 						return {GET_SUCCESS, s} -- empty sequence*/
    RefDS(_s_7892);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_7892;
    _4318 = MAKE_SEQ(_1);
    DeRefDS(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    return _4318;

    /** 				end while*/
    goto LF; // [319] 242
L11: 

    /** 				while 1 do -- now read zero or more post element comments*/
L13: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L14: 
    _skip_blanks_1__tmp_at328_7936 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_skip_blanks_1__tmp_at328_7936 == 0)
    {
        goto L15; // [341] 358
    }
    else{
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L14; // [350] 334

    /** end procedure*/
    goto L15; // [355] 358
L15: 

    /** 					if ch = '}' then*/
    if (_16ch_7692 != 125)
    goto L16; // [364] 385

    /** 						get_ch()*/
    _16get_ch();

    /** 					return {GET_SUCCESS, s}*/
    RefDS(_s_7892);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 0;
    ((int *)_2)[2] = _s_7892;
    _4320 = MAKE_SEQ(_1);
    DeRefDS(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    return _4320;
    goto L13; // [382] 327
L16: 

    /** 					elsif ch!='-' then*/
    if (_16ch_7692 == 45)
    goto L17; // [389] 400

    /** 						exit*/
    goto L18; // [395] 434
    goto L13; // [397] 327
L17: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_7893;
    _e_7893 = _16get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it wasn't a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_7893);
    _4323 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4323, -2)){
        _4323 = NOVALUE;
        goto L13; // [413] 327
    }
    _4323 = NOVALUE;

    /** 							return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4325 = MAKE_SEQ(_1);
    DeRef(_s_7892);
    DeRefDS(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    DeRef(_4320);
    _4320 = NOVALUE;
    return _4325;

    /** 			end while*/
    goto L13; // [431] 327
L18: 

    /** 				if ch != ',' then*/
    if (_16ch_7692 == 44)
    goto L19; // [438] 453

    /** 				return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4327 = MAKE_SEQ(_1);
    DeRef(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    DeRef(_4320);
    _4320 = NOVALUE;
    DeRef(_4325);
    _4325 = NOVALUE;
    return _4327;
L19: 

    /** 			get_ch() -- skip comma*/
    _16get_ch();

    /** 			end while*/
    goto LE; // [459] 237
    goto L4; // [462] 49
LA: 

    /** 		elsif ch = '\"' then*/
    if (_16ch_7692 != 34)
    goto L1A; // [469] 485

    /** 			return get_string()*/
    _4329 = _16get_string();
    DeRef(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    DeRef(_4320);
    _4320 = NOVALUE;
    DeRef(_4325);
    _4325 = NOVALUE;
    DeRef(_4327);
    _4327 = NOVALUE;
    return _4329;
    goto L4; // [482] 49
L1A: 

    /** 		elsif ch = '\'' then*/
    if (_16ch_7692 != 39)
    goto L1B; // [489] 505

    /** 			return get_qchar()*/
    _4331 = _16get_qchar();
    DeRef(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    DeRef(_4320);
    _4320 = NOVALUE;
    DeRef(_4325);
    _4325 = NOVALUE;
    DeRef(_4327);
    _4327 = NOVALUE;
    DeRef(_4329);
    _4329 = NOVALUE;
    return _4331;
    goto L4; // [502] 49
L1B: 

    /** 			return {GET_FAIL, 0}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = 1;
    ((int *)_2)[2] = 0;
    _4332 = MAKE_SEQ(_1);
    DeRef(_s_7892);
    DeRef(_e_7893);
    DeRef(_4299);
    _4299 = NOVALUE;
    DeRef(_4304);
    _4304 = NOVALUE;
    DeRef(_4307);
    _4307 = NOVALUE;
    DeRef(_4310);
    _4310 = NOVALUE;
    DeRef(_4318);
    _4318 = NOVALUE;
    DeRef(_4320);
    _4320 = NOVALUE;
    DeRef(_4325);
    _4325 = NOVALUE;
    DeRef(_4327);
    _4327 = NOVALUE;
    DeRef(_4329);
    _4329 = NOVALUE;
    DeRef(_4331);
    _4331 = NOVALUE;
    return _4332;

    /** 	end while*/
    goto L4; // [518] 49
    ;
}


int _16Get2()
{
    int _skip_blanks_1__tmp_at464_8033 = NOVALUE;
    int _skip_blanks_1__tmp_at233_8000 = NOVALUE;
    int _s_7962 = NOVALUE;
    int _e_7963 = NOVALUE;
    int _e1_7964 = NOVALUE;
    int _offset_7965 = NOVALUE;
    int _4424 = NOVALUE;
    int _4423 = NOVALUE;
    int _4422 = NOVALUE;
    int _4421 = NOVALUE;
    int _4420 = NOVALUE;
    int _4419 = NOVALUE;
    int _4418 = NOVALUE;
    int _4417 = NOVALUE;
    int _4416 = NOVALUE;
    int _4415 = NOVALUE;
    int _4414 = NOVALUE;
    int _4411 = NOVALUE;
    int _4410 = NOVALUE;
    int _4409 = NOVALUE;
    int _4408 = NOVALUE;
    int _4407 = NOVALUE;
    int _4406 = NOVALUE;
    int _4403 = NOVALUE;
    int _4402 = NOVALUE;
    int _4401 = NOVALUE;
    int _4400 = NOVALUE;
    int _4399 = NOVALUE;
    int _4397 = NOVALUE;
    int _4396 = NOVALUE;
    int _4395 = NOVALUE;
    int _4394 = NOVALUE;
    int _4393 = NOVALUE;
    int _4391 = NOVALUE;
    int _4388 = NOVALUE;
    int _4387 = NOVALUE;
    int _4386 = NOVALUE;
    int _4385 = NOVALUE;
    int _4384 = NOVALUE;
    int _4382 = NOVALUE;
    int _4381 = NOVALUE;
    int _4380 = NOVALUE;
    int _4379 = NOVALUE;
    int _4378 = NOVALUE;
    int _4376 = NOVALUE;
    int _4375 = NOVALUE;
    int _4374 = NOVALUE;
    int _4373 = NOVALUE;
    int _4372 = NOVALUE;
    int _4371 = NOVALUE;
    int _4368 = NOVALUE;
    int _4364 = NOVALUE;
    int _4363 = NOVALUE;
    int _4362 = NOVALUE;
    int _4361 = NOVALUE;
    int _4360 = NOVALUE;
    int _4357 = NOVALUE;
    int _4356 = NOVALUE;
    int _4355 = NOVALUE;
    int _4354 = NOVALUE;
    int _4353 = NOVALUE;
    int _4351 = NOVALUE;
    int _4350 = NOVALUE;
    int _4349 = NOVALUE;
    int _4348 = NOVALUE;
    int _4347 = NOVALUE;
    int _4346 = NOVALUE;
    int _4344 = NOVALUE;
    int _4342 = NOVALUE;
    int _4340 = NOVALUE;
    int _4339 = NOVALUE;
    int _4338 = NOVALUE;
    int _4337 = NOVALUE;
    int _4336 = NOVALUE;
    int _4334 = NOVALUE;
    int _0, _1, _2;
    

    /** 	offset = string_next-1*/
    _offset_7965 = _16string_next_7691 - 1;

    /** 	get_ch()*/
    _16get_ch();

    /** 	while find(ch, white_space) do*/
L1: 
    _4334 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_4334 == 0)
    {
        _4334 = NOVALUE;
        goto L2; // [25] 37
    }
    else{
        _4334 = NOVALUE;
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L1; // [34] 18
L2: 

    /** 	if ch = -1 then -- string is made of whitespace only*/
    if (_16ch_7692 != -1)
    goto L3; // [41] 75

    /** 		return {GET_EOF, 0, string_next-1-offset ,string_next-1}*/
    _4336 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4336 +(unsigned long) HIGH_BITS) >= 0){
        _4336 = NewDouble((double)_4336);
    }
    if (IS_ATOM_INT(_4336)) {
        _4337 = _4336 - _offset_7965;
        if ((long)((unsigned long)_4337 +(unsigned long) HIGH_BITS) >= 0){
            _4337 = NewDouble((double)_4337);
        }
    }
    else {
        _4337 = NewDouble(DBL_PTR(_4336)->dbl - (double)_offset_7965);
    }
    DeRef(_4336);
    _4336 = NOVALUE;
    _4338 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4338 +(unsigned long) HIGH_BITS) >= 0){
        _4338 = NewDouble((double)_4338);
    }
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _4337;
    *((int *)(_2+16)) = _4338;
    _4339 = MAKE_SEQ(_1);
    _4338 = NOVALUE;
    _4337 = NOVALUE;
    DeRef(_s_7962);
    DeRef(_e_7963);
    return _4339;
L3: 

    /** 	leading_whitespace = string_next-2-offset -- index of the last whitespace: string_next points past the first non whitespace*/
    _4340 = _16string_next_7691 - 2;
    if ((long)((unsigned long)_4340 +(unsigned long) HIGH_BITS) >= 0){
        _4340 = NewDouble((double)_4340);
    }
    if (IS_ATOM_INT(_4340)) {
        _16leading_whitespace_7959 = _4340 - _offset_7965;
    }
    else {
        _16leading_whitespace_7959 = NewDouble(DBL_PTR(_4340)->dbl - (double)_offset_7965);
    }
    DeRef(_4340);
    _4340 = NOVALUE;
    if (!IS_ATOM_INT(_16leading_whitespace_7959)) {
        _1 = (long)(DBL_PTR(_16leading_whitespace_7959)->dbl);
        DeRefDS(_16leading_whitespace_7959);
        _16leading_whitespace_7959 = _1;
    }

    /** 	while 1 do*/
L4: 

    /** 		if find(ch, START_NUMERIC) then*/
    _4342 = find_from(_16ch_7692, _16START_NUMERIC_7675, 1);
    if (_4342 == 0)
    {
        _4342 = NOVALUE;
        goto L5; // [105] 213
    }
    else{
        _4342 = NOVALUE;
    }

    /** 			e = get_number()*/
    _0 = _e_7963;
    _e_7963 = _16get_number();
    DeRef(_0);

    /** 			if e[1] != GET_IGNORE then -- either a number or something illegal was read, so exit: the other goto*/
    _2 = (int)SEQ_PTR(_e_7963);
    _4344 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4344, -2)){
        _4344 = NOVALUE;
        goto L6; // [121] 162
    }
    _4344 = NOVALUE;

    /** 				return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4346 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4346 +(unsigned long) HIGH_BITS) >= 0){
        _4346 = NewDouble((double)_4346);
    }
    if (IS_ATOM_INT(_4346)) {
        _4347 = _4346 - _offset_7965;
        if ((long)((unsigned long)_4347 +(unsigned long) HIGH_BITS) >= 0){
            _4347 = NewDouble((double)_4347);
        }
    }
    else {
        _4347 = NewDouble(DBL_PTR(_4346)->dbl - (double)_offset_7965);
    }
    DeRef(_4346);
    _4346 = NOVALUE;
    _4348 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4347)) {
        _4349 = _4347 - _4348;
        if ((long)((unsigned long)_4349 +(unsigned long) HIGH_BITS) >= 0){
            _4349 = NewDouble((double)_4349);
        }
    }
    else {
        _4349 = NewDouble(DBL_PTR(_4347)->dbl - (double)_4348);
    }
    DeRef(_4347);
    _4347 = NOVALUE;
    _4348 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4349;
    ((int *)_2)[2] = _16leading_whitespace_7959;
    _4350 = MAKE_SEQ(_1);
    _4349 = NOVALUE;
    Concat((object_ptr)&_4351, _e_7963, _4350);
    DeRefDS(_4350);
    _4350 = NOVALUE;
    DeRef(_s_7962);
    DeRefDS(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    return _4351;
L6: 

    /** 			get_ch()*/
    _16get_ch();

    /** 			if ch=-1 then*/
    if (_16ch_7692 != -1)
    goto L4; // [170] 94

    /** 				return {GET_NOTHING, 0, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _4353 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4353 +(unsigned long) HIGH_BITS) >= 0){
        _4353 = NewDouble((double)_4353);
    }
    if (IS_ATOM_INT(_4353)) {
        _4354 = _4353 - _offset_7965;
        if ((long)((unsigned long)_4354 +(unsigned long) HIGH_BITS) >= 0){
            _4354 = NewDouble((double)_4354);
        }
    }
    else {
        _4354 = NewDouble(DBL_PTR(_4353)->dbl - (double)_offset_7965);
    }
    DeRef(_4353);
    _4353 = NOVALUE;
    _4355 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4354)) {
        _4356 = _4354 - _4355;
        if ((long)((unsigned long)_4356 +(unsigned long) HIGH_BITS) >= 0){
            _4356 = NewDouble((double)_4356);
        }
    }
    else {
        _4356 = NewDouble(DBL_PTR(_4354)->dbl - (double)_4355);
    }
    DeRef(_4354);
    _4354 = NOVALUE;
    _4355 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = -2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _4356;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4357 = MAKE_SEQ(_1);
    _4356 = NOVALUE;
    DeRef(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    return _4357;
    goto L4; // [210] 94
L5: 

    /** 		elsif ch = '{' then*/
    if (_16ch_7692 != 123)
    goto L7; // [217] 676

    /** 			s = {}*/
    RefDS(_5);
    DeRef(_s_7962);
    _s_7962 = _5;

    /** 			get_ch()*/
    _16get_ch();

    /** 			skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L8: 
    _skip_blanks_1__tmp_at233_8000 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_skip_blanks_1__tmp_at233_8000 == 0)
    {
        goto L9; // [246] 263
    }
    else{
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L8; // [255] 239

    /** end procedure*/
    goto L9; // [260] 263
L9: 

    /** 			if ch = '}' then -- empty sequence*/
    if (_16ch_7692 != 125)
    goto LA; // [269] 313

    /** 				get_ch()*/
    _16get_ch();

    /** 				return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace} -- empty sequence*/
    _4360 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4360 +(unsigned long) HIGH_BITS) >= 0){
        _4360 = NewDouble((double)_4360);
    }
    if (IS_ATOM_INT(_4360)) {
        _4361 = _4360 - _offset_7965;
        if ((long)((unsigned long)_4361 +(unsigned long) HIGH_BITS) >= 0){
            _4361 = NewDouble((double)_4361);
        }
    }
    else {
        _4361 = NewDouble(DBL_PTR(_4360)->dbl - (double)_offset_7965);
    }
    DeRef(_4360);
    _4360 = NOVALUE;
    _4362 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4361)) {
        _4363 = _4361 - _4362;
        if ((long)((unsigned long)_4363 +(unsigned long) HIGH_BITS) >= 0){
            _4363 = NewDouble((double)_4363);
        }
    }
    else {
        _4363 = NewDouble(DBL_PTR(_4361)->dbl - (double)_4362);
    }
    DeRef(_4361);
    _4361 = NOVALUE;
    _4362 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_7962);
    *((int *)(_2+8)) = _s_7962;
    *((int *)(_2+12)) = _4363;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4364 = MAKE_SEQ(_1);
    _4363 = NOVALUE;
    DeRefDS(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    return _4364;
LA: 

    /** 			while TRUE do -- read: comment(s), element, comment(s), comma and so on till it terminates or errors out*/
LB: 

    /** 				while 1 do -- read zero or more comments and an element*/
LC: 

    /** 					e = Get() -- read next element, using standard function*/
    _0 = _e_7963;
    _e_7963 = _16Get();
    DeRef(_0);

    /** 					e1 = e[1]*/
    _2 = (int)SEQ_PTR(_e_7963);
    _e1_7964 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_e1_7964))
    _e1_7964 = (long)DBL_PTR(_e1_7964)->dbl;

    /** 					if e1 = GET_SUCCESS then*/
    if (_e1_7964 != 0)
    goto LD; // [338] 359

    /** 						s = append(s, e[2])*/
    _2 = (int)SEQ_PTR(_e_7963);
    _4368 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_4368);
    Append(&_s_7962, _s_7962, _4368);
    _4368 = NOVALUE;

    /** 						exit  -- element read and added to result*/
    goto LE; // [354] 458
    goto LC; // [356] 323
LD: 

    /** 					elsif e1 != GET_IGNORE then*/
    if (_e1_7964 == -2)
    goto LF; // [361] 404

    /** 						return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4371 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4371 +(unsigned long) HIGH_BITS) >= 0){
        _4371 = NewDouble((double)_4371);
    }
    if (IS_ATOM_INT(_4371)) {
        _4372 = _4371 - _offset_7965;
        if ((long)((unsigned long)_4372 +(unsigned long) HIGH_BITS) >= 0){
            _4372 = NewDouble((double)_4372);
        }
    }
    else {
        _4372 = NewDouble(DBL_PTR(_4371)->dbl - (double)_offset_7965);
    }
    DeRef(_4371);
    _4371 = NOVALUE;
    _4373 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4372)) {
        _4374 = _4372 - _4373;
        if ((long)((unsigned long)_4374 +(unsigned long) HIGH_BITS) >= 0){
            _4374 = NewDouble((double)_4374);
        }
    }
    else {
        _4374 = NewDouble(DBL_PTR(_4372)->dbl - (double)_4373);
    }
    DeRef(_4372);
    _4372 = NOVALUE;
    _4373 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4374;
    ((int *)_2)[2] = _16leading_whitespace_7959;
    _4375 = MAKE_SEQ(_1);
    _4374 = NOVALUE;
    Concat((object_ptr)&_4376, _e_7963, _4375);
    DeRefDS(_4375);
    _4375 = NOVALUE;
    DeRef(_s_7962);
    DeRefDS(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    return _4376;
    goto LC; // [401] 323
LF: 

    /** 					elsif ch='}' then*/
    if (_16ch_7692 != 125)
    goto LC; // [408] 323

    /** 						get_ch()*/
    _16get_ch();

    /** 						return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1),leading_whitespace} -- empty sequence*/
    _4378 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4378 +(unsigned long) HIGH_BITS) >= 0){
        _4378 = NewDouble((double)_4378);
    }
    if (IS_ATOM_INT(_4378)) {
        _4379 = _4378 - _offset_7965;
        if ((long)((unsigned long)_4379 +(unsigned long) HIGH_BITS) >= 0){
            _4379 = NewDouble((double)_4379);
        }
    }
    else {
        _4379 = NewDouble(DBL_PTR(_4378)->dbl - (double)_offset_7965);
    }
    DeRef(_4378);
    _4378 = NOVALUE;
    _4380 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4379)) {
        _4381 = _4379 - _4380;
        if ((long)((unsigned long)_4381 +(unsigned long) HIGH_BITS) >= 0){
            _4381 = NewDouble((double)_4381);
        }
    }
    else {
        _4381 = NewDouble(DBL_PTR(_4379)->dbl - (double)_4380);
    }
    DeRef(_4379);
    _4379 = NOVALUE;
    _4380 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_7962);
    *((int *)(_2+8)) = _s_7962;
    *((int *)(_2+12)) = _4381;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4382 = MAKE_SEQ(_1);
    _4381 = NOVALUE;
    DeRefDS(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    return _4382;

    /** 				end while*/
    goto LC; // [455] 323
LE: 

    /** 				while 1 do -- now read zero or more post element comments*/
L10: 

    /** 					skip_blanks()*/

    /** 	while find(ch, white_space) do*/
L11: 
    _skip_blanks_1__tmp_at464_8033 = find_from(_16ch_7692, _16white_space_7708, 1);
    if (_skip_blanks_1__tmp_at464_8033 == 0)
    {
        goto L12; // [477] 494
    }
    else{
    }

    /** 		get_ch()*/
    _16get_ch();

    /** 	end while*/
    goto L11; // [486] 470

    /** end procedure*/
    goto L12; // [491] 494
L12: 

    /** 					if ch = '}' then*/
    if (_16ch_7692 != 125)
    goto L13; // [500] 546

    /** 						get_ch()*/
    _16get_ch();

    /** 					return {GET_SUCCESS, s, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4384 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4384 +(unsigned long) HIGH_BITS) >= 0){
        _4384 = NewDouble((double)_4384);
    }
    if (IS_ATOM_INT(_4384)) {
        _4385 = _4384 - _offset_7965;
        if ((long)((unsigned long)_4385 +(unsigned long) HIGH_BITS) >= 0){
            _4385 = NewDouble((double)_4385);
        }
    }
    else {
        _4385 = NewDouble(DBL_PTR(_4384)->dbl - (double)_offset_7965);
    }
    DeRef(_4384);
    _4384 = NOVALUE;
    _4386 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4385)) {
        _4387 = _4385 - _4386;
        if ((long)((unsigned long)_4387 +(unsigned long) HIGH_BITS) >= 0){
            _4387 = NewDouble((double)_4387);
        }
    }
    else {
        _4387 = NewDouble(DBL_PTR(_4385)->dbl - (double)_4386);
    }
    DeRef(_4385);
    _4385 = NOVALUE;
    _4386 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    RefDS(_s_7962);
    *((int *)(_2+8)) = _s_7962;
    *((int *)(_2+12)) = _4387;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4388 = MAKE_SEQ(_1);
    _4387 = NOVALUE;
    DeRefDS(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    return _4388;
    goto L10; // [543] 463
L13: 

    /** 					elsif ch!='-' then*/
    if (_16ch_7692 == 45)
    goto L14; // [550] 561

    /** 						exit*/
    goto L15; // [556] 620
    goto L10; // [558] 463
L14: 

    /** 						e = get_number() -- reads anything starting with '-'*/
    _0 = _e_7963;
    _e_7963 = _16get_number();
    DeRef(_0);

    /** 						if e[1] != GET_IGNORE then  -- it was not a comment, this is illegal*/
    _2 = (int)SEQ_PTR(_e_7963);
    _4391 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _4391, -2)){
        _4391 = NOVALUE;
        goto L10; // [574] 463
    }
    _4391 = NOVALUE;

    /** 							return {GET_FAIL, 0, string_next-1-offset-(ch!=-1),leading_whitespace}*/
    _4393 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4393 +(unsigned long) HIGH_BITS) >= 0){
        _4393 = NewDouble((double)_4393);
    }
    if (IS_ATOM_INT(_4393)) {
        _4394 = _4393 - _offset_7965;
        if ((long)((unsigned long)_4394 +(unsigned long) HIGH_BITS) >= 0){
            _4394 = NewDouble((double)_4394);
        }
    }
    else {
        _4394 = NewDouble(DBL_PTR(_4393)->dbl - (double)_offset_7965);
    }
    DeRef(_4393);
    _4393 = NOVALUE;
    _4395 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4394)) {
        _4396 = _4394 - _4395;
        if ((long)((unsigned long)_4396 +(unsigned long) HIGH_BITS) >= 0){
            _4396 = NewDouble((double)_4396);
        }
    }
    else {
        _4396 = NewDouble(DBL_PTR(_4394)->dbl - (double)_4395);
    }
    DeRef(_4394);
    _4394 = NOVALUE;
    _4395 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _4396;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4397 = MAKE_SEQ(_1);
    _4396 = NOVALUE;
    DeRef(_s_7962);
    DeRefDS(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    DeRef(_4388);
    _4388 = NOVALUE;
    return _4397;

    /** 			end while*/
    goto L10; // [617] 463
L15: 

    /** 				if ch != ',' then*/
    if (_16ch_7692 == 44)
    goto L16; // [624] 664

    /** 				return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4399 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4399 +(unsigned long) HIGH_BITS) >= 0){
        _4399 = NewDouble((double)_4399);
    }
    if (IS_ATOM_INT(_4399)) {
        _4400 = _4399 - _offset_7965;
        if ((long)((unsigned long)_4400 +(unsigned long) HIGH_BITS) >= 0){
            _4400 = NewDouble((double)_4400);
        }
    }
    else {
        _4400 = NewDouble(DBL_PTR(_4399)->dbl - (double)_offset_7965);
    }
    DeRef(_4399);
    _4399 = NOVALUE;
    _4401 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4400)) {
        _4402 = _4400 - _4401;
        if ((long)((unsigned long)_4402 +(unsigned long) HIGH_BITS) >= 0){
            _4402 = NewDouble((double)_4402);
        }
    }
    else {
        _4402 = NewDouble(DBL_PTR(_4400)->dbl - (double)_4401);
    }
    DeRef(_4400);
    _4400 = NOVALUE;
    _4401 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _4402;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4403 = MAKE_SEQ(_1);
    _4402 = NOVALUE;
    DeRef(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    DeRef(_4388);
    _4388 = NOVALUE;
    DeRef(_4397);
    _4397 = NOVALUE;
    return _4403;
L16: 

    /** 			get_ch() -- skip comma*/
    _16get_ch();

    /** 			end while*/
    goto LB; // [670] 318
    goto L4; // [673] 94
L7: 

    /** 		elsif ch = '\"' then*/
    if (_16ch_7692 != 34)
    goto L17; // [680] 730

    /** 			e = get_string()*/
    _0 = _e_7963;
    _e_7963 = _16get_string();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4406 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4406 +(unsigned long) HIGH_BITS) >= 0){
        _4406 = NewDouble((double)_4406);
    }
    if (IS_ATOM_INT(_4406)) {
        _4407 = _4406 - _offset_7965;
        if ((long)((unsigned long)_4407 +(unsigned long) HIGH_BITS) >= 0){
            _4407 = NewDouble((double)_4407);
        }
    }
    else {
        _4407 = NewDouble(DBL_PTR(_4406)->dbl - (double)_offset_7965);
    }
    DeRef(_4406);
    _4406 = NOVALUE;
    _4408 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4407)) {
        _4409 = _4407 - _4408;
        if ((long)((unsigned long)_4409 +(unsigned long) HIGH_BITS) >= 0){
            _4409 = NewDouble((double)_4409);
        }
    }
    else {
        _4409 = NewDouble(DBL_PTR(_4407)->dbl - (double)_4408);
    }
    DeRef(_4407);
    _4407 = NOVALUE;
    _4408 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4409;
    ((int *)_2)[2] = _16leading_whitespace_7959;
    _4410 = MAKE_SEQ(_1);
    _4409 = NOVALUE;
    Concat((object_ptr)&_4411, _e_7963, _4410);
    DeRefDS(_4410);
    _4410 = NOVALUE;
    DeRef(_s_7962);
    DeRefDS(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    DeRef(_4388);
    _4388 = NOVALUE;
    DeRef(_4397);
    _4397 = NOVALUE;
    DeRef(_4403);
    _4403 = NOVALUE;
    return _4411;
    goto L4; // [727] 94
L17: 

    /** 		elsif ch = '\'' then*/
    if (_16ch_7692 != 39)
    goto L18; // [734] 784

    /** 			e = get_qchar()*/
    _0 = _e_7963;
    _e_7963 = _16get_qchar();
    DeRef(_0);

    /** 			return e & {string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4414 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4414 +(unsigned long) HIGH_BITS) >= 0){
        _4414 = NewDouble((double)_4414);
    }
    if (IS_ATOM_INT(_4414)) {
        _4415 = _4414 - _offset_7965;
        if ((long)((unsigned long)_4415 +(unsigned long) HIGH_BITS) >= 0){
            _4415 = NewDouble((double)_4415);
        }
    }
    else {
        _4415 = NewDouble(DBL_PTR(_4414)->dbl - (double)_offset_7965);
    }
    DeRef(_4414);
    _4414 = NOVALUE;
    _4416 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4415)) {
        _4417 = _4415 - _4416;
        if ((long)((unsigned long)_4417 +(unsigned long) HIGH_BITS) >= 0){
            _4417 = NewDouble((double)_4417);
        }
    }
    else {
        _4417 = NewDouble(DBL_PTR(_4415)->dbl - (double)_4416);
    }
    DeRef(_4415);
    _4415 = NOVALUE;
    _4416 = NOVALUE;
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _4417;
    ((int *)_2)[2] = _16leading_whitespace_7959;
    _4418 = MAKE_SEQ(_1);
    _4417 = NOVALUE;
    Concat((object_ptr)&_4419, _e_7963, _4418);
    DeRefDS(_4418);
    _4418 = NOVALUE;
    DeRef(_s_7962);
    DeRefDS(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    DeRef(_4388);
    _4388 = NOVALUE;
    DeRef(_4397);
    _4397 = NOVALUE;
    DeRef(_4403);
    _4403 = NOVALUE;
    DeRef(_4411);
    _4411 = NOVALUE;
    return _4419;
    goto L4; // [781] 94
L18: 

    /** 			return {GET_FAIL, 0, string_next-1-offset-(ch!=-1), leading_whitespace}*/
    _4420 = _16string_next_7691 - 1;
    if ((long)((unsigned long)_4420 +(unsigned long) HIGH_BITS) >= 0){
        _4420 = NewDouble((double)_4420);
    }
    if (IS_ATOM_INT(_4420)) {
        _4421 = _4420 - _offset_7965;
        if ((long)((unsigned long)_4421 +(unsigned long) HIGH_BITS) >= 0){
            _4421 = NewDouble((double)_4421);
        }
    }
    else {
        _4421 = NewDouble(DBL_PTR(_4420)->dbl - (double)_offset_7965);
    }
    DeRef(_4420);
    _4420 = NOVALUE;
    _4422 = (_16ch_7692 != -1);
    if (IS_ATOM_INT(_4421)) {
        _4423 = _4421 - _4422;
        if ((long)((unsigned long)_4423 +(unsigned long) HIGH_BITS) >= 0){
            _4423 = NewDouble((double)_4423);
        }
    }
    else {
        _4423 = NewDouble(DBL_PTR(_4421)->dbl - (double)_4422);
    }
    DeRef(_4421);
    _4421 = NOVALUE;
    _4422 = NOVALUE;
    _1 = NewS1(4);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 1;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = _4423;
    *((int *)(_2+16)) = _16leading_whitespace_7959;
    _4424 = MAKE_SEQ(_1);
    _4423 = NOVALUE;
    DeRef(_s_7962);
    DeRef(_e_7963);
    DeRef(_4339);
    _4339 = NOVALUE;
    DeRef(_4351);
    _4351 = NOVALUE;
    DeRef(_4357);
    _4357 = NOVALUE;
    DeRef(_4364);
    _4364 = NOVALUE;
    DeRef(_4376);
    _4376 = NOVALUE;
    DeRef(_4382);
    _4382 = NOVALUE;
    DeRef(_4388);
    _4388 = NOVALUE;
    DeRef(_4397);
    _4397 = NOVALUE;
    DeRef(_4403);
    _4403 = NOVALUE;
    DeRef(_4411);
    _4411 = NOVALUE;
    DeRef(_4419);
    _4419 = NOVALUE;
    return _4424;

    /** 	end while*/
    goto L4; // [822] 94
    ;
}



// 0x97D414BF
