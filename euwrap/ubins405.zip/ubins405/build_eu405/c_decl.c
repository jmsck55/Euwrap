// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _56get_eucompiledir()
{
    int _x_41364 = NOVALUE;
    int _22159 = NOVALUE;
    int _22157 = NOVALUE;
    int _22154 = NOVALUE;
    int _22152 = NOVALUE;
    int _22150 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object x = getenv("EUCOMPILEDIR")*/
    DeRef(_x_41364);
    _x_41364 = EGetEnv(_22148);

    /** 	if is_eudir_from_cmdline() then*/
    _22150 = _13is_eudir_from_cmdline();
    if (_22150 == 0) {
        DeRef(_22150);
        _22150 = NOVALUE;
        goto L1; // [11] 20
    }
    else {
        if (!IS_ATOM_INT(_22150) && DBL_PTR(_22150)->dbl == 0.0){
            DeRef(_22150);
            _22150 = NOVALUE;
            goto L1; // [11] 20
        }
        DeRef(_22150);
        _22150 = NOVALUE;
    }
    DeRef(_22150);
    _22150 = NOVALUE;

    /** 		x = get_eudir()*/
    _0 = _x_41364;
    _x_41364 = _13get_eudir();
    DeRefi(_0);
L1: 

    /** 	ifdef UNIX then*/

    /** 		if equal(x, -1) then*/
    if (_x_41364 == -1)
    _22152 = 1;
    else if (IS_ATOM_INT(_x_41364) && IS_ATOM_INT(-1))
    _22152 = 0;
    else
    _22152 = (compare(_x_41364, -1) == 0);
    if (_22152 == 0)
    {
        _22152 = NOVALUE;
        goto L2; // [28] 67
    }
    else{
        _22152 = NOVALUE;
    }

    /** 			x = "/usr/local/share/euphoria"*/
    RefDS(_22153);
    DeRef(_x_41364);
    _x_41364 = _22153;

    /** 			if not file_exists( x ) then*/
    RefDS(_x_41364);
    _22154 = _14file_exists(_x_41364);
    if (IS_ATOM_INT(_22154)) {
        if (_22154 != 0){
            DeRef(_22154);
            _22154 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    else {
        if (DBL_PTR(_22154)->dbl != 0.0){
            DeRef(_22154);
            _22154 = NOVALUE;
            goto L3; // [42] 66
        }
    }
    DeRef(_22154);
    _22154 = NOVALUE;

    /** 				x = "/usr/share/euphoria"*/
    RefDS(_22156);
    DeRefDSi(_x_41364);
    _x_41364 = _22156;

    /** 				if not file_exists( x ) then*/
    RefDS(_x_41364);
    _22157 = _14file_exists(_x_41364);
    if (IS_ATOM_INT(_22157)) {
        if (_22157 != 0){
            DeRef(_22157);
            _22157 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    else {
        if (DBL_PTR(_22157)->dbl != 0.0){
            DeRef(_22157);
            _22157 = NOVALUE;
            goto L4; // [56] 65
        }
    }
    DeRef(_22157);
    _22157 = NOVALUE;

    /** 					x = -1*/
    DeRefDSi(_x_41364);
    _x_41364 = -1;
L4: 
L3: 
L2: 

    /** 	if equal(x, -1) then*/
    if (_x_41364 == -1)
    _22159 = 1;
    else if (IS_ATOM_INT(_x_41364) && IS_ATOM_INT(-1))
    _22159 = 0;
    else
    _22159 = (compare(_x_41364, -1) == 0);
    if (_22159 == 0)
    {
        _22159 = NOVALUE;
        goto L5; // [73] 82
    }
    else{
        _22159 = NOVALUE;
    }

    /** 		x = get_eudir()*/
    _0 = _x_41364;
    _x_41364 = _13get_eudir();
    DeRef(_0);
L5: 

    /** 	return x*/
    return _x_41364;
    ;
}


void _56NewBB(int _a_call_41390, int _mask_41391, int _sub_41393)
{
    int _s_41395 = NOVALUE;
    int _22192 = NOVALUE;
    int _22191 = NOVALUE;
    int _22189 = NOVALUE;
    int _22188 = NOVALUE;
    int _22186 = NOVALUE;
    int _22185 = NOVALUE;
    int _22184 = NOVALUE;
    int _22183 = NOVALUE;
    int _22182 = NOVALUE;
    int _22181 = NOVALUE;
    int _22180 = NOVALUE;
    int _22179 = NOVALUE;
    int _22178 = NOVALUE;
    int _22177 = NOVALUE;
    int _22176 = NOVALUE;
    int _22175 = NOVALUE;
    int _22174 = NOVALUE;
    int _22173 = NOVALUE;
    int _22172 = NOVALUE;
    int _22171 = NOVALUE;
    int _22170 = NOVALUE;
    int _22169 = NOVALUE;
    int _22168 = NOVALUE;
    int _22167 = NOVALUE;
    int _22166 = NOVALUE;
    int _22165 = NOVALUE;
    int _22164 = NOVALUE;
    int _22162 = NOVALUE;
    int _22161 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_a_call_41390)) {
        _1 = (long)(DBL_PTR(_a_call_41390)->dbl);
        DeRefDS(_a_call_41390);
        _a_call_41390 = _1;
    }
    if (!IS_ATOM_INT(_mask_41391)) {
        _1 = (long)(DBL_PTR(_mask_41391)->dbl);
        DeRefDS(_mask_41391);
        _mask_41391 = _1;
    }
    if (!IS_ATOM_INT(_sub_41393)) {
        _1 = (long)(DBL_PTR(_sub_41393)->dbl);
        DeRefDS(_sub_41393);
        _sub_41393 = _1;
    }

    /** 	if a_call then*/
    if (_a_call_41390 == 0)
    {
        goto L1; // [9] 252
    }
    else{
    }

    /** 		for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22161 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22161 = 1;
    }
    {
        int _i_41398;
        _i_41398 = 1;
L2: 
        if (_i_41398 > _22161){
            goto L3; // [19] 249
        }

        /** 			s = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22162 = (int)*(((s1_ptr)_2)->base + _i_41398);
        _2 = (int)SEQ_PTR(_22162);
        _s_41395 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_s_41395)){
            _s_41395 = (long)DBL_PTR(_s_41395)->dbl;
        }
        _22162 = NOVALUE;

        /** 			if SymTab[s][S_MODE] = M_NORMAL and*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22164 = (int)*(((s1_ptr)_2)->base + _s_41395);
        _2 = (int)SEQ_PTR(_22164);
        _22165 = (int)*(((s1_ptr)_2)->base + 3);
        _22164 = NOVALUE;
        if (IS_ATOM_INT(_22165)) {
            _22166 = (_22165 == 1);
        }
        else {
            _22166 = binary_op(EQUALS, _22165, 1);
        }
        _22165 = NOVALUE;
        if (IS_ATOM_INT(_22166)) {
            if (_22166 == 0) {
                goto L4; // [60] 242
            }
        }
        else {
            if (DBL_PTR(_22166)->dbl == 0.0) {
                goto L4; // [60] 242
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22168 = (int)*(((s1_ptr)_2)->base + _s_41395);
        _2 = (int)SEQ_PTR(_22168);
        _22169 = (int)*(((s1_ptr)_2)->base + 4);
        _22168 = NOVALUE;
        if (IS_ATOM_INT(_22169)) {
            _22170 = (_22169 == 6);
        }
        else {
            _22170 = binary_op(EQUALS, _22169, 6);
        }
        _22169 = NOVALUE;
        if (IS_ATOM_INT(_22170)) {
            if (_22170 != 0) {
                DeRef(_22171);
                _22171 = 1;
                goto L5; // [82] 108
            }
        }
        else {
            if (DBL_PTR(_22170)->dbl != 0.0) {
                DeRef(_22171);
                _22171 = 1;
                goto L5; // [82] 108
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22172 = (int)*(((s1_ptr)_2)->base + _s_41395);
        _2 = (int)SEQ_PTR(_22172);
        _22173 = (int)*(((s1_ptr)_2)->base + 4);
        _22172 = NOVALUE;
        if (IS_ATOM_INT(_22173)) {
            _22174 = (_22173 == 5);
        }
        else {
            _22174 = binary_op(EQUALS, _22173, 5);
        }
        _22173 = NOVALUE;
        DeRef(_22171);
        if (IS_ATOM_INT(_22174))
        _22171 = (_22174 != 0);
        else
        _22171 = DBL_PTR(_22174)->dbl != 0.0;
L5: 
        if (_22171 != 0) {
            _22175 = 1;
            goto L6; // [108] 134
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22176 = (int)*(((s1_ptr)_2)->base + _s_41395);
        _2 = (int)SEQ_PTR(_22176);
        _22177 = (int)*(((s1_ptr)_2)->base + 4);
        _22176 = NOVALUE;
        if (IS_ATOM_INT(_22177)) {
            _22178 = (_22177 == 11);
        }
        else {
            _22178 = binary_op(EQUALS, _22177, 11);
        }
        _22177 = NOVALUE;
        if (IS_ATOM_INT(_22178))
        _22175 = (_22178 != 0);
        else
        _22175 = DBL_PTR(_22178)->dbl != 0.0;
L6: 
        if (_22175 != 0) {
            DeRef(_22179);
            _22179 = 1;
            goto L7; // [134] 160
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22180 = (int)*(((s1_ptr)_2)->base + _s_41395);
        _2 = (int)SEQ_PTR(_22180);
        _22181 = (int)*(((s1_ptr)_2)->base + 4);
        _22180 = NOVALUE;
        if (IS_ATOM_INT(_22181)) {
            _22182 = (_22181 == 13);
        }
        else {
            _22182 = binary_op(EQUALS, _22181, 13);
        }
        _22181 = NOVALUE;
        if (IS_ATOM_INT(_22182))
        _22179 = (_22182 != 0);
        else
        _22179 = DBL_PTR(_22182)->dbl != 0.0;
L7: 
        if (_22179 == 0)
        {
            _22179 = NOVALUE;
            goto L4; // [161] 242
        }
        else{
            _22179 = NOVALUE;
        }

        /** 				  if and_bits(mask, power(2, remainder(s, E_SIZE))) then*/
        _22183 = (_s_41395 % 29);
        _22184 = power(2, _22183);
        _22183 = NOVALUE;
        if (IS_ATOM_INT(_22184)) {
            {unsigned long tu;
                 tu = (unsigned long)_mask_41391 & (unsigned long)_22184;
                 _22185 = MAKE_UINT(tu);
            }
        }
        else {
            temp_d.dbl = (double)_mask_41391;
            _22185 = Dand_bits(&temp_d, DBL_PTR(_22184));
        }
        DeRef(_22184);
        _22184 = NOVALUE;
        if (_22185 == 0) {
            DeRef(_22185);
            _22185 = NOVALUE;
            goto L8; // [180] 241
        }
        else {
            if (!IS_ATOM_INT(_22185) && DBL_PTR(_22185)->dbl == 0.0){
                DeRef(_22185);
                _22185 = NOVALUE;
                goto L8; // [180] 241
            }
            DeRef(_22185);
            _22185 = NOVALUE;
        }
        DeRef(_22185);
        _22185 = NOVALUE;

        /** 					  if mask = E_ALL_EFFECT or s < sub then*/
        _22186 = (_mask_41391 == 1073741823);
        if (_22186 != 0) {
            goto L9; // [191] 204
        }
        _22188 = (_s_41395 < _sub_41393);
        if (_22188 == 0)
        {
            DeRef(_22188);
            _22188 = NOVALUE;
            goto LA; // [200] 240
        }
        else{
            DeRef(_22188);
            _22188 = NOVALUE;
        }
L9: 

        /** 						  BB_info[i][BB_TYPE..BB_OBJ] =*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _56BB_info_41343 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_41398 + ((s1_ptr)_2)->base);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = -1073741824;
        ((int *)_2)[2] = 1073741823;
        _22191 = MAKE_SEQ(_1);
        _1 = NewS1(4);
        _2 = (int)((s1_ptr)_1)->base;
        *((int *)(_2+4)) = 0;
        *((int *)(_2+8)) = 0;
        Ref(_12NOVALUE_11536);
        *((int *)(_2+12)) = _12NOVALUE_11536;
        *((int *)(_2+16)) = _22191;
        _22192 = MAKE_SEQ(_1);
        _22191 = NOVALUE;
        assign_slice_seq = (s1_ptr *)_3;
        AssignSlice(2, 5, _22192);
        DeRefDS(_22192);
        _22192 = NOVALUE;
LA: 
L8: 
L4: 

        /** 		end for*/
        _i_41398 = _i_41398 + 1;
        goto L2; // [244] 26
L3: 
        ;
    }
    goto LB; // [249] 260
L1: 

    /** 		BB_info = {}*/
    RefDS(_21829);
    DeRef(_56BB_info_41343);
    _56BB_info_41343 = _21829;
LB: 

    /** end procedure*/
    DeRef(_22186);
    _22186 = NOVALUE;
    DeRef(_22166);
    _22166 = NOVALUE;
    DeRef(_22170);
    _22170 = NOVALUE;
    DeRef(_22174);
    _22174 = NOVALUE;
    DeRef(_22178);
    _22178 = NOVALUE;
    DeRef(_22182);
    _22182 = NOVALUE;
    DeRef(_22189);
    _22189 = NOVALUE;
    return;
    ;
}


int _56BB_var_obj(int _var_41463)
{
    int _bbi_41464 = NOVALUE;
    int _22203 = NOVALUE;
    int _22201 = NOVALUE;
    int _22199 = NOVALUE;
    int _22198 = NOVALUE;
    int _22196 = NOVALUE;
    int _22194 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41463)) {
        _1 = (long)(DBL_PTR(_var_41463)->dbl);
        DeRefDS(_var_41463);
        _var_41463 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22194 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22194 = 1;
    }
    {
        int _i_41466;
        _i_41466 = _22194;
L1: 
        if (_i_41466 < 1){
            goto L2; // [10] 99
        }

        /** 		bbi = BB_info[i]*/
        DeRef(_bbi_41464);
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _bbi_41464 = (int)*(((s1_ptr)_2)->base + _i_41466);
        Ref(_bbi_41464);

        /** 		if bbi[BB_VAR] != var then*/
        _2 = (int)SEQ_PTR(_bbi_41464);
        _22196 = (int)*(((s1_ptr)_2)->base + 1);
        if (binary_op_a(EQUALS, _22196, _var_41463)){
            _22196 = NOVALUE;
            goto L3; // [31] 40
        }
        _22196 = NOVALUE;

        /** 			continue*/
        goto L4; // [37] 94
L3: 

        /** 		if SymTab[var][S_MODE] != M_NORMAL then*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22198 = (int)*(((s1_ptr)_2)->base + _var_41463);
        _2 = (int)SEQ_PTR(_22198);
        _22199 = (int)*(((s1_ptr)_2)->base + 3);
        _22198 = NOVALUE;
        if (binary_op_a(EQUALS, _22199, 1)){
            _22199 = NOVALUE;
            goto L5; // [56] 65
        }
        _22199 = NOVALUE;

        /** 			continue*/
        goto L4; // [62] 94
L5: 

        /** 		if bbi[BB_TYPE] != TYPE_INTEGER then*/
        _2 = (int)SEQ_PTR(_bbi_41464);
        _22201 = (int)*(((s1_ptr)_2)->base + 2);
        if (binary_op_a(EQUALS, _22201, 1)){
            _22201 = NOVALUE;
            goto L6; // [73] 82
        }
        _22201 = NOVALUE;

        /** 			exit*/
        goto L2; // [79] 99
L6: 

        /** 		return bbi[BB_OBJ]*/
        _2 = (int)SEQ_PTR(_bbi_41464);
        _22203 = (int)*(((s1_ptr)_2)->base + 5);
        Ref(_22203);
        DeRef(_bbi_41464);
        return _22203;

        /** 	end for*/
L4: 
        _i_41466 = _i_41466 + -1;
        goto L1; // [94] 17
L2: 
        ;
    }

    /** 	return BB_def_values*/
    RefDS(_56BB_def_values_41457);
    DeRef(_bbi_41464);
    _22203 = NOVALUE;
    return _56BB_def_values_41457;
    ;
}


int _56BB_var_type(int _var_41486)
{
    int _22218 = NOVALUE;
    int _22217 = NOVALUE;
    int _22215 = NOVALUE;
    int _22214 = NOVALUE;
    int _22213 = NOVALUE;
    int _22212 = NOVALUE;
    int _22211 = NOVALUE;
    int _22210 = NOVALUE;
    int _22209 = NOVALUE;
    int _22208 = NOVALUE;
    int _22207 = NOVALUE;
    int _22206 = NOVALUE;
    int _22205 = NOVALUE;
    int _22204 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_var_41486)) {
        _1 = (long)(DBL_PTR(_var_41486)->dbl);
        DeRefDS(_var_41486);
        _var_41486 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22204 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22204 = 1;
    }
    {
        int _i_41488;
        _i_41488 = _22204;
L1: 
        if (_i_41488 < 1){
            goto L2; // [10] 125
        }

        /** 		if BB_info[i][BB_VAR] = var and*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22205 = (int)*(((s1_ptr)_2)->base + _i_41488);
        _2 = (int)SEQ_PTR(_22205);
        _22206 = (int)*(((s1_ptr)_2)->base + 1);
        _22205 = NOVALUE;
        if (IS_ATOM_INT(_22206)) {
            _22207 = (_22206 == _var_41486);
        }
        else {
            _22207 = binary_op(EQUALS, _22206, _var_41486);
        }
        _22206 = NOVALUE;
        if (IS_ATOM_INT(_22207)) {
            if (_22207 == 0) {
                goto L3; // [33] 118
            }
        }
        else {
            if (DBL_PTR(_22207)->dbl == 0.0) {
                goto L3; // [33] 118
            }
        }
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22209 = (int)*(((s1_ptr)_2)->base + _i_41488);
        _2 = (int)SEQ_PTR(_22209);
        _22210 = (int)*(((s1_ptr)_2)->base + 1);
        _22209 = NOVALUE;
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!IS_ATOM_INT(_22210)){
            _22211 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22210)->dbl));
        }
        else{
            _22211 = (int)*(((s1_ptr)_2)->base + _22210);
        }
        _2 = (int)SEQ_PTR(_22211);
        _22212 = (int)*(((s1_ptr)_2)->base + 3);
        _22211 = NOVALUE;
        if (IS_ATOM_INT(_22212)) {
            _22213 = (_22212 == 1);
        }
        else {
            _22213 = binary_op(EQUALS, _22212, 1);
        }
        _22212 = NOVALUE;
        if (_22213 == 0) {
            DeRef(_22213);
            _22213 = NOVALUE;
            goto L3; // [66] 118
        }
        else {
            if (!IS_ATOM_INT(_22213) && DBL_PTR(_22213)->dbl == 0.0){
                DeRef(_22213);
                _22213 = NOVALUE;
                goto L3; // [66] 118
            }
            DeRef(_22213);
            _22213 = NOVALUE;
        }
        DeRef(_22213);
        _22213 = NOVALUE;

        /** 			ifdef DEBUG then*/

        /** 			if BB_info[i][BB_TYPE] = TYPE_NULL then  -- var has only been read*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22214 = (int)*(((s1_ptr)_2)->base + _i_41488);
        _2 = (int)SEQ_PTR(_22214);
        _22215 = (int)*(((s1_ptr)_2)->base + 2);
        _22214 = NOVALUE;
        if (binary_op_a(NOTEQ, _22215, 0)){
            _22215 = NOVALUE;
            goto L4; // [85] 100
        }
        _22215 = NOVALUE;

        /** 				return TYPE_OBJECT*/
        _22210 = NOVALUE;
        DeRef(_22207);
        _22207 = NOVALUE;
        return 16;
        goto L5; // [97] 117
L4: 

        /** 				return BB_info[i][BB_TYPE]*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22217 = (int)*(((s1_ptr)_2)->base + _i_41488);
        _2 = (int)SEQ_PTR(_22217);
        _22218 = (int)*(((s1_ptr)_2)->base + 2);
        _22217 = NOVALUE;
        Ref(_22218);
        _22210 = NOVALUE;
        DeRef(_22207);
        _22207 = NOVALUE;
        return _22218;
L5: 
L3: 

        /** 	end for*/
        _i_41488 = _i_41488 + -1;
        goto L1; // [120] 17
L2: 
        ;
    }

    /** 	return TYPE_OBJECT*/
    _22210 = NOVALUE;
    DeRef(_22207);
    _22207 = NOVALUE;
    _22218 = NOVALUE;
    return 16;
    ;
}


int _56GType(int _s_41516)
{
    int _t_41517 = NOVALUE;
    int _local_t_41518 = NOVALUE;
    int _22222 = NOVALUE;
    int _22221 = NOVALUE;
    int _22219 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41516)) {
        _1 = (long)(DBL_PTR(_s_41516)->dbl);
        DeRefDS(_s_41516);
        _s_41516 = _1;
    }

    /** 	t = SymTab[s][S_GTYPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22219 = (int)*(((s1_ptr)_2)->base + _s_41516);
    _2 = (int)SEQ_PTR(_22219);
    _t_41517 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_t_41517)){
        _t_41517 = (long)DBL_PTR(_t_41517)->dbl;
    }
    _22219 = NOVALUE;

    /** 	ifdef DEBUG then*/

    /** 	if SymTab[s][S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22221 = (int)*(((s1_ptr)_2)->base + _s_41516);
    _2 = (int)SEQ_PTR(_22221);
    _22222 = (int)*(((s1_ptr)_2)->base + 3);
    _22221 = NOVALUE;
    if (binary_op_a(EQUALS, _22222, 1)){
        _22222 = NOVALUE;
        goto L1; // [37] 48
    }
    _22222 = NOVALUE;

    /** 		return t*/
    return _t_41517;
L1: 

    /** 	local_t = BB_var_type(s)*/
    _local_t_41518 = _56BB_var_type(_s_41516);
    if (!IS_ATOM_INT(_local_t_41518)) {
        _1 = (long)(DBL_PTR(_local_t_41518)->dbl);
        DeRefDS(_local_t_41518);
        _local_t_41518 = _1;
    }

    /** 	if local_t = TYPE_OBJECT then*/
    if (_local_t_41518 != 16)
    goto L2; // [60] 71

    /** 		return t*/
    return _t_41517;
L2: 

    /** 	if t = TYPE_INTEGER then*/
    if (_t_41517 != 1)
    goto L3; // [75] 88

    /** 		return TYPE_INTEGER*/
    return 1;
L3: 

    /** 	return local_t*/
    return _local_t_41518;
    ;
}


int _56GDelete()
{
    int _0, _1, _2;
    

    /** 	return g_has_delete*/
    return _56g_has_delete_41538;
    ;
}


int _56HasDelete(int _s_41545)
{
    int _22237 = NOVALUE;
    int _22236 = NOVALUE;
    int _22234 = NOVALUE;
    int _22233 = NOVALUE;
    int _22232 = NOVALUE;
    int _22231 = NOVALUE;
    int _22229 = NOVALUE;
    int _22228 = NOVALUE;
    int _22227 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41545)) {
        _1 = (long)(DBL_PTR(_s_41545)->dbl);
        DeRefDS(_s_41545);
        _s_41545 = _1;
    }

    /** 	for i = length(BB_info) to 1 by -1 do*/
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22227 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22227 = 1;
    }
    {
        int _i_41547;
        _i_41547 = _22227;
L1: 
        if (_i_41547 < 1){
            goto L2; // [10] 57
        }

        /** 		if BB_info[i][BB_VAR] = s then*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22228 = (int)*(((s1_ptr)_2)->base + _i_41547);
        _2 = (int)SEQ_PTR(_22228);
        _22229 = (int)*(((s1_ptr)_2)->base + 1);
        _22228 = NOVALUE;
        if (binary_op_a(NOTEQ, _22229, _s_41545)){
            _22229 = NOVALUE;
            goto L3; // [29] 50
        }
        _22229 = NOVALUE;

        /** 			return BB_info[i][BB_DELETE]*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22231 = (int)*(((s1_ptr)_2)->base + _i_41547);
        _2 = (int)SEQ_PTR(_22231);
        _22232 = (int)*(((s1_ptr)_2)->base + 6);
        _22231 = NOVALUE;
        Ref(_22232);
        return _22232;
L3: 

        /** 	end for*/
        _i_41547 = _i_41547 + -1;
        goto L1; // [52] 17
L2: 
        ;
    }

    /** 	if length(SymTab[s]) < S_HAS_DELETE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22233 = (int)*(((s1_ptr)_2)->base + _s_41545);
    if (IS_SEQUENCE(_22233)){
            _22234 = SEQ_PTR(_22233)->length;
    }
    else {
        _22234 = 1;
    }
    _22233 = NOVALUE;
    if (_22234 >= 54)
    goto L4; // [70] 81

    /** 		return 0*/
    _22232 = NOVALUE;
    _22233 = NOVALUE;
    return 0;
L4: 

    /** 	return SymTab[s][S_HAS_DELETE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22236 = (int)*(((s1_ptr)_2)->base + _s_41545);
    _2 = (int)SEQ_PTR(_22236);
    _22237 = (int)*(((s1_ptr)_2)->base + 54);
    _22236 = NOVALUE;
    Ref(_22237);
    _22232 = NOVALUE;
    _22233 = NOVALUE;
    return _22237;
    ;
}


int _56ObjValue(int _s_41568)
{
    int _local_t_41569 = NOVALUE;
    int _st_41570 = NOVALUE;
    int _tmin_41571 = NOVALUE;
    int _tmax_41572 = NOVALUE;
    int _22250 = NOVALUE;
    int _22248 = NOVALUE;
    int _22247 = NOVALUE;
    int _22245 = NOVALUE;
    int _22242 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41568)) {
        _1 = (long)(DBL_PTR(_s_41568)->dbl);
        DeRefDS(_s_41568);
        _s_41568 = _1;
    }

    /** 	st = SymTab[s]*/
    DeRef(_st_41570);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _st_41570 = (int)*(((s1_ptr)_2)->base + _s_41568);
    Ref(_st_41570);

    /** 	tmin = st[S_OBJ_MIN]*/
    DeRef(_tmin_41571);
    _2 = (int)SEQ_PTR(_st_41570);
    _tmin_41571 = (int)*(((s1_ptr)_2)->base + 30);
    Ref(_tmin_41571);

    /** 	tmax = st[S_OBJ_MAX]*/
    DeRef(_tmax_41572);
    _2 = (int)SEQ_PTR(_st_41570);
    _tmax_41572 = (int)*(((s1_ptr)_2)->base + 31);
    Ref(_tmax_41572);

    /** 	if tmin != tmax then*/
    if (binary_op_a(EQUALS, _tmin_41571, _tmax_41572)){
        goto L1; // [29] 41
    }

    /** 		tmin = NOVALUE*/
    Ref(_12NOVALUE_11536);
    DeRef(_tmin_41571);
    _tmin_41571 = _12NOVALUE_11536;
L1: 

    /** 	if st[S_MODE] != M_NORMAL then*/
    _2 = (int)SEQ_PTR(_st_41570);
    _22242 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(EQUALS, _22242, 1)){
        _22242 = NOVALUE;
        goto L2; // [51] 62
    }
    _22242 = NOVALUE;

    /** 		return tmin*/
    DeRef(_local_t_41569);
    DeRef(_st_41570);
    DeRef(_tmax_41572);
    return _tmin_41571;
L2: 

    /** 	local_t = BB_var_obj(s)*/
    _0 = _local_t_41569;
    _local_t_41569 = _56BB_var_obj(_s_41568);
    DeRef(_0);

    /** 	if local_t[MIN] = NOVALUE then*/
    _2 = (int)SEQ_PTR(_local_t_41569);
    _22245 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _22245, _12NOVALUE_11536)){
        _22245 = NOVALUE;
        goto L3; // [80] 91
    }
    _22245 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41569);
    DeRef(_st_41570);
    DeRef(_tmax_41572);
    return _tmin_41571;
L3: 

    /** 	if local_t[MIN] != local_t[MAX] then*/
    _2 = (int)SEQ_PTR(_local_t_41569);
    _22247 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_local_t_41569);
    _22248 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(EQUALS, _22247, _22248)){
        _22247 = NOVALUE;
        _22248 = NOVALUE;
        goto L4; // [105] 116
    }
    _22247 = NOVALUE;
    _22248 = NOVALUE;

    /** 		return tmin*/
    DeRefDS(_local_t_41569);
    DeRef(_st_41570);
    DeRef(_tmax_41572);
    return _tmin_41571;
L4: 

    /** 	return local_t[MIN]*/
    _2 = (int)SEQ_PTR(_local_t_41569);
    _22250 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22250);
    DeRefDS(_local_t_41569);
    DeRef(_st_41570);
    DeRef(_tmin_41571);
    DeRef(_tmax_41572);
    return _22250;
    ;
}


int _56TypeIs(int _x_41603, int _typei_41604)
{
    int _22252 = NOVALUE;
    int _22251 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41603)) {
        _1 = (long)(DBL_PTR(_x_41603)->dbl);
        DeRefDS(_x_41603);
        _x_41603 = _1;
    }
    if (!IS_ATOM_INT(_typei_41604)) {
        _1 = (long)(DBL_PTR(_typei_41604)->dbl);
        DeRefDS(_typei_41604);
        _typei_41604 = _1;
    }

    /** 	return GType(x) = typei*/
    _22251 = _56GType(_x_41603);
    if (IS_ATOM_INT(_22251)) {
        _22252 = (_22251 == _typei_41604);
    }
    else {
        _22252 = binary_op(EQUALS, _22251, _typei_41604);
    }
    DeRef(_22251);
    _22251 = NOVALUE;
    return _22252;
    ;
}


int _56TypeIsIn(int _x_41609, int _types_41610)
{
    int _22254 = NOVALUE;
    int _22253 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41609)) {
        _1 = (long)(DBL_PTR(_x_41609)->dbl);
        DeRefDS(_x_41609);
        _x_41609 = _1;
    }

    /** 	return find(GType(x), types)*/
    _22253 = _56GType(_x_41609);
    _22254 = find_from(_22253, _types_41610, 1);
    DeRef(_22253);
    _22253 = NOVALUE;
    DeRefDS(_types_41610);
    return _22254;
    ;
}


int _56TypeIsNot(int _x_41615, int _typei_41616)
{
    int _22256 = NOVALUE;
    int _22255 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41615)) {
        _1 = (long)(DBL_PTR(_x_41615)->dbl);
        DeRefDS(_x_41615);
        _x_41615 = _1;
    }
    if (!IS_ATOM_INT(_typei_41616)) {
        _1 = (long)(DBL_PTR(_typei_41616)->dbl);
        DeRefDS(_typei_41616);
        _typei_41616 = _1;
    }

    /** 	return GType(x) != typei*/
    _22255 = _56GType(_x_41615);
    if (IS_ATOM_INT(_22255)) {
        _22256 = (_22255 != _typei_41616);
    }
    else {
        _22256 = binary_op(NOTEQ, _22255, _typei_41616);
    }
    DeRef(_22255);
    _22255 = NOVALUE;
    return _22256;
    ;
}


int _56TypeIsNotIn(int _x_41621, int _types_41622)
{
    int _22259 = NOVALUE;
    int _22258 = NOVALUE;
    int _22257 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_x_41621)) {
        _1 = (long)(DBL_PTR(_x_41621)->dbl);
        DeRefDS(_x_41621);
        _x_41621 = _1;
    }

    /** 	return not find(GType(x), types)*/
    _22257 = _56GType(_x_41621);
    _22258 = find_from(_22257, _types_41622, 1);
    DeRef(_22257);
    _22257 = NOVALUE;
    _22259 = (_22258 == 0);
    _22258 = NOVALUE;
    DeRefDS(_types_41622);
    return _22259;
    ;
}


int _56or_type(int _t1_41628, int _t2_41629)
{
    int _22279 = NOVALUE;
    int _22278 = NOVALUE;
    int _22277 = NOVALUE;
    int _22276 = NOVALUE;
    int _22271 = NOVALUE;
    int _22269 = NOVALUE;
    int _22264 = NOVALUE;
    int _22262 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_t1_41628)) {
        _1 = (long)(DBL_PTR(_t1_41628)->dbl);
        DeRefDS(_t1_41628);
        _t1_41628 = _1;
    }
    if (!IS_ATOM_INT(_t2_41629)) {
        _1 = (long)(DBL_PTR(_t2_41629)->dbl);
        DeRefDS(_t2_41629);
        _t2_41629 = _1;
    }

    /** 	if t1 = TYPE_NULL then*/
    if (_t1_41628 != 0)
    goto L1; // [9] 22

    /** 		return t2*/
    return _t2_41629;
    goto L2; // [19] 307
L1: 

    /** 	elsif t2 = TYPE_NULL then*/
    if (_t2_41629 != 0)
    goto L3; // [26] 39

    /** 		return t1*/
    return _t1_41628;
    goto L2; // [36] 307
L3: 

    /** 	elsif t1 = TYPE_OBJECT or t2 = TYPE_OBJECT then*/
    _22262 = (_t1_41628 == 16);
    if (_22262 != 0) {
        goto L4; // [47] 62
    }
    _22264 = (_t2_41629 == 16);
    if (_22264 == 0)
    {
        DeRef(_22264);
        _22264 = NOVALUE;
        goto L5; // [58] 73
    }
    else{
        DeRef(_22264);
        _22264 = NOVALUE;
    }
L4: 

    /** 		return TYPE_OBJECT*/
    DeRef(_22262);
    _22262 = NOVALUE;
    return 16;
    goto L2; // [70] 307
L5: 

    /** 	elsif t1 = TYPE_SEQUENCE then*/
    if (_t1_41628 != 8)
    goto L6; // [77] 112

    /** 		if t2 = TYPE_SEQUENCE then*/
    if (_t2_41629 != 8)
    goto L7; // [85] 100

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22262);
    _22262 = NOVALUE;
    return 8;
    goto L2; // [97] 307
L7: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22262);
    _22262 = NOVALUE;
    return 16;
    goto L2; // [109] 307
L6: 

    /** 	elsif t2 = TYPE_SEQUENCE then*/
    if (_t2_41629 != 8)
    goto L8; // [116] 151

    /** 		if t1 = TYPE_SEQUENCE then*/
    if (_t1_41628 != 8)
    goto L9; // [124] 139

    /** 			return TYPE_SEQUENCE*/
    DeRef(_22262);
    _22262 = NOVALUE;
    return 8;
    goto L2; // [136] 307
L9: 

    /** 			return TYPE_OBJECT*/
    DeRef(_22262);
    _22262 = NOVALUE;
    return 16;
    goto L2; // [148] 307
L8: 

    /** 	elsif t1 = TYPE_ATOM or t2 = TYPE_ATOM then*/
    _22269 = (_t1_41628 == 4);
    if (_22269 != 0) {
        goto LA; // [159] 174
    }
    _22271 = (_t2_41629 == 4);
    if (_22271 == 0)
    {
        DeRef(_22271);
        _22271 = NOVALUE;
        goto LB; // [170] 185
    }
    else{
        DeRef(_22271);
        _22271 = NOVALUE;
    }
LA: 

    /** 		return TYPE_ATOM*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    return 4;
    goto L2; // [182] 307
LB: 

    /** 	elsif t1 = TYPE_DOUBLE then*/
    if (_t1_41628 != 2)
    goto LC; // [189] 224

    /** 		if t2 = TYPE_INTEGER then*/
    if (_t2_41629 != 1)
    goto LD; // [197] 212

    /** 			return TYPE_ATOM*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    return 4;
    goto L2; // [209] 307
LD: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    return 2;
    goto L2; // [221] 307
LC: 

    /** 	elsif t2 = TYPE_DOUBLE then*/
    if (_t2_41629 != 2)
    goto LE; // [228] 263

    /** 		if t1 = TYPE_INTEGER then*/
    if (_t1_41628 != 1)
    goto LF; // [236] 251

    /** 			return TYPE_ATOM*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    return 4;
    goto L2; // [248] 307
LF: 

    /** 			return TYPE_DOUBLE*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    return 2;
    goto L2; // [260] 307
LE: 

    /** 	elsif t1 = TYPE_INTEGER and t2 = TYPE_INTEGER then*/
    _22276 = (_t1_41628 == 1);
    if (_22276 == 0) {
        goto L10; // [271] 296
    }
    _22278 = (_t2_41629 == 1);
    if (_22278 == 0)
    {
        DeRef(_22278);
        _22278 = NOVALUE;
        goto L10; // [282] 296
    }
    else{
        DeRef(_22278);
        _22278 = NOVALUE;
    }

    /** 		return TYPE_INTEGER*/
    DeRef(_22262);
    _22262 = NOVALUE;
    DeRef(_22269);
    _22269 = NOVALUE;
    DeRef(_22276);
    _22276 = NOVALUE;
    return 1;
    goto L2; // [293] 307
L10: 

    /** 		InternalErr(258, {t1, t2})*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _t1_41628;
    ((int *)_2)[2] = _t2_41629;
    _22279 = MAKE_SEQ(_1);
    _43InternalErr(258, _22279);
    _22279 = NOVALUE;
L2: 
    ;
}


void _56RemoveFromBB(int _s_41699)
{
    int _int_41700 = NOVALUE;
    int _22281 = NOVALUE;
    int _22280 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_41699)) {
        _1 = (long)(DBL_PTR(_s_41699)->dbl);
        DeRefDS(_s_41699);
        _s_41699 = _1;
    }

    /** 	for i = 1 to length(BB_info) do*/
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22280 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22280 = 1;
    }
    {
        int _i_41702;
        _i_41702 = 1;
L1: 
        if (_i_41702 > _22280){
            goto L2; // [10] 59
        }

        /** 		int = BB_info[i][BB_VAR]*/
        _2 = (int)SEQ_PTR(_56BB_info_41343);
        _22281 = (int)*(((s1_ptr)_2)->base + _i_41702);
        _2 = (int)SEQ_PTR(_22281);
        _int_41700 = (int)*(((s1_ptr)_2)->base + 1);
        if (!IS_ATOM_INT(_int_41700)){
            _int_41700 = (long)DBL_PTR(_int_41700)->dbl;
        }
        _22281 = NOVALUE;

        /** 		if int = s then*/
        if (_int_41700 != _s_41699)
        goto L3; // [33] 52

        /** 			BB_info = remove( BB_info, int )*/
        {
            s1_ptr assign_space = SEQ_PTR(_56BB_info_41343);
            int len = assign_space->length;
            int start = (IS_ATOM_INT(_int_41700)) ? _int_41700 : (long)(DBL_PTR(_int_41700)->dbl);
            int stop = (IS_ATOM_INT(_int_41700)) ? _int_41700 : (long)(DBL_PTR(_int_41700)->dbl);
            if (stop > len){
                stop = len;
            }
            if (start > len || start > stop || stop<0) {
            }
            else if (start < 2) {
                if (stop >= len) {
                    Head( SEQ_PTR(_56BB_info_41343), start, &_56BB_info_41343 );
                }
                else Tail(SEQ_PTR(_56BB_info_41343), stop+1, &_56BB_info_41343);
            }
            else if (stop >= len){
                Head(SEQ_PTR(_56BB_info_41343), start, &_56BB_info_41343);
            }
            else {
                assign_slice_seq = &assign_space;
                _56BB_info_41343 = Remove_elements(start, stop, (SEQ_PTR(_56BB_info_41343)->ref == 1));
            }
        }

        /** 			return*/
        return;
L3: 

        /** 	end for*/
        _i_41702 = _i_41702 + 1;
        goto L1; // [54] 17
L2: 
        ;
    }

    /** end procedure*/
    return;
    ;
}


void _56SetBBType(int _s_41720, int _t_41721, int _val_41722, int _etype_41723, int _has_delete_41724)
{
    int _found_41725 = NOVALUE;
    int _i_41726 = NOVALUE;
    int _tn_41727 = NOVALUE;
    int _int_41728 = NOVALUE;
    int _sym_41729 = NOVALUE;
    int _mode_41734 = NOVALUE;
    int _gtype_41749 = NOVALUE;
    int _new_type_41786 = NOVALUE;
    int _bbsym_41809 = NOVALUE;
    int _bbi_41945 = NOVALUE;
    int _22400 = NOVALUE;
    int _22399 = NOVALUE;
    int _22398 = NOVALUE;
    int _22396 = NOVALUE;
    int _22395 = NOVALUE;
    int _22394 = NOVALUE;
    int _22392 = NOVALUE;
    int _22391 = NOVALUE;
    int _22389 = NOVALUE;
    int _22387 = NOVALUE;
    int _22386 = NOVALUE;
    int _22384 = NOVALUE;
    int _22382 = NOVALUE;
    int _22381 = NOVALUE;
    int _22380 = NOVALUE;
    int _22379 = NOVALUE;
    int _22378 = NOVALUE;
    int _22377 = NOVALUE;
    int _22376 = NOVALUE;
    int _22375 = NOVALUE;
    int _22374 = NOVALUE;
    int _22371 = NOVALUE;
    int _22367 = NOVALUE;
    int _22362 = NOVALUE;
    int _22360 = NOVALUE;
    int _22359 = NOVALUE;
    int _22358 = NOVALUE;
    int _22356 = NOVALUE;
    int _22354 = NOVALUE;
    int _22353 = NOVALUE;
    int _22352 = NOVALUE;
    int _22350 = NOVALUE;
    int _22349 = NOVALUE;
    int _22347 = NOVALUE;
    int _22346 = NOVALUE;
    int _22345 = NOVALUE;
    int _22343 = NOVALUE;
    int _22342 = NOVALUE;
    int _22339 = NOVALUE;
    int _22338 = NOVALUE;
    int _22337 = NOVALUE;
    int _22335 = NOVALUE;
    int _22333 = NOVALUE;
    int _22332 = NOVALUE;
    int _22330 = NOVALUE;
    int _22329 = NOVALUE;
    int _22328 = NOVALUE;
    int _22326 = NOVALUE;
    int _22325 = NOVALUE;
    int _22314 = NOVALUE;
    int _22312 = NOVALUE;
    int _22309 = NOVALUE;
    int _22308 = NOVALUE;
    int _22305 = NOVALUE;
    int _22304 = NOVALUE;
    int _22303 = NOVALUE;
    int _22301 = NOVALUE;
    int _22300 = NOVALUE;
    int _22299 = NOVALUE;
    int _22297 = NOVALUE;
    int _22296 = NOVALUE;
    int _22294 = NOVALUE;
    int _22291 = NOVALUE;
    int _22289 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_41720)) {
        _1 = (long)(DBL_PTR(_s_41720)->dbl);
        DeRefDS(_s_41720);
        _s_41720 = _1;
    }
    if (!IS_ATOM_INT(_t_41721)) {
        _1 = (long)(DBL_PTR(_t_41721)->dbl);
        DeRefDS(_t_41721);
        _t_41721 = _1;
    }
    if (!IS_ATOM_INT(_etype_41723)) {
        _1 = (long)(DBL_PTR(_etype_41723)->dbl);
        DeRefDS(_etype_41723);
        _etype_41723 = _1;
    }
    if (!IS_ATOM_INT(_has_delete_41724)) {
        _1 = (long)(DBL_PTR(_has_delete_41724)->dbl);
        DeRefDS(_has_delete_41724);
        _has_delete_41724 = _1;
    }

    /** 	if has_delete then*/
    if (_has_delete_41724 == 0)
    {
        goto L1; // [13] 27
    }
    else{
    }

    /** 		p_has_delete = 1*/
    _56p_has_delete_41539 = 1;

    /** 		g_has_delete = 1*/
    _56g_has_delete_41538 = 1;
L1: 

    /** 	sym = SymTab[s]*/
    DeRef(_sym_41729);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _sym_41729 = (int)*(((s1_ptr)_2)->base + _s_41720);
    Ref(_sym_41729);

    /** 	SymTab[s] = 0*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_41720);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 	integer mode = sym[S_MODE]*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _mode_41734 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_41734))
    _mode_41734 = (long)DBL_PTR(_mode_41734)->dbl;

    /** 	if mode = M_NORMAL or mode = M_TEMP  then*/
    _22289 = (_mode_41734 == 1);
    if (_22289 != 0) {
        goto L2; // [61] 76
    }
    _22291 = (_mode_41734 == 3);
    if (_22291 == 0)
    {
        DeRef(_22291);
        _22291 = NOVALUE;
        goto L3; // [72] 1167
    }
    else{
        DeRef(_22291);
        _22291 = NOVALUE;
    }
L2: 

    /** 		found = FALSE*/
    _found_41725 = _9FALSE_429;

    /** 		if mode = M_TEMP then*/
    if (_mode_41734 != 3)
    goto L4; // [89] 465

    /** 			sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41721;
    DeRef(_1);

    /** 			sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41723;
    DeRef(_1);

    /** 			integer gtype = sym[S_GTYPE]*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _gtype_41749 = (int)*(((s1_ptr)_2)->base + 36);
    if (!IS_ATOM_INT(_gtype_41749))
    _gtype_41749 = (long)DBL_PTR(_gtype_41749)->dbl;

    /** 			if gtype = TYPE_OBJECT*/
    _22294 = (_gtype_41749 == 16);
    if (_22294 != 0) {
        goto L5; // [125] 140
    }
    _22296 = (_gtype_41749 == 8);
    if (_22296 == 0)
    {
        DeRef(_22296);
        _22296 = NOVALUE;
        goto L6; // [136] 213
    }
    else{
        DeRef(_22296);
        _22296 = NOVALUE;
    }
L5: 

    /** 				if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22297 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22297, 0)){
        _22297 = NOVALUE;
        goto L7; // [148] 165
    }
    _22297 = NOVALUE;

    /** 					sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L8; // [162] 180
L7: 

    /** 					sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22299 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22299);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22299;
    if( _1 != _22299 ){
        DeRef(_1);
    }
    _22299 = NOVALUE;
L8: 

    /** 				sym[S_OBJ] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 				sym[S_OBJ_MIN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L9; // [210] 252
L6: 

    /** 				sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22300 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22300);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22300;
    if( _1 != _22300 ){
        DeRef(_1);
    }
    _22300 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22301 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22301);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22301;
    if( _1 != _22301 ){
        DeRef(_1);
    }
    _22301 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L9: 

    /** 			if not Initializing then*/
    if (_12Initializing_11763 != 0)
    goto LA; // [256] 326

    /** 				integer new_type = or_type(temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22303 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_12temp_name_type_11765);
    if (!IS_ATOM_INT(_22303)){
        _22304 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22303)->dbl));
    }
    else{
        _22304 = (int)*(((s1_ptr)_2)->base + _22303);
    }
    _2 = (int)SEQ_PTR(_22304);
    _22305 = (int)*(((s1_ptr)_2)->base + 2);
    _22304 = NOVALUE;
    Ref(_22305);
    _new_type_41786 = _56or_type(_22305, _t_41721);
    _22305 = NOVALUE;
    if (!IS_ATOM_INT(_new_type_41786)) {
        _1 = (long)(DBL_PTR(_new_type_41786)->dbl);
        DeRefDS(_new_type_41786);
        _new_type_41786 = _1;
    }

    /** 				if new_type = TYPE_NULL then*/
    if (_new_type_41786 != 0)
    goto LB; // [290] 304

    /** 					new_type = TYPE_OBJECT*/
    _new_type_41786 = 16;
LB: 

    /** 				temp_name_type[sym[S_TEMP_NAME]][T_GTYPE_NEW] = new_type*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22308 = (int)*(((s1_ptr)_2)->base + 34);
    _2 = (int)SEQ_PTR(_12temp_name_type_11765);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _12temp_name_type_11765 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_22308))
    _3 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_22308)->dbl));
    else
    _3 = (int)(_22308 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _new_type_41786;
    DeRef(_1);
    _22309 = NOVALUE;
LA: 

    /** 			tn = sym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _tn_41727 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_tn_41727))
    _tn_41727 = (long)DBL_PTR(_tn_41727)->dbl;

    /** 			i = 1*/
    _i_41726 = 1;

    /** 			while i <= length(BB_info) do*/
LC: 
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22312 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22312 = 1;
    }
    if (_i_41726 > _22312)
    goto LD; // [351] 460

    /** 				sequence bbsym*/

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    _22314 = (int)*(((s1_ptr)_2)->base + _i_41726);
    _2 = (int)SEQ_PTR(_22314);
    _int_41728 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_41728)){
        _int_41728 = (long)DBL_PTR(_int_41728)->dbl;
    }
    _22314 = NOVALUE;

    /** 				if int = s then*/
    if (_int_41728 != _s_41720)
    goto LE; // [373] 387

    /** 					bbsym = sym*/
    RefDS(_sym_41729);
    DeRef(_bbsym_41809);
    _bbsym_41809 = _sym_41729;
    goto LF; // [384] 398
LE: 

    /** 					bbsym = SymTab[int]*/
    DeRef(_bbsym_41809);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _bbsym_41809 = (int)*(((s1_ptr)_2)->base + _int_41728);
    Ref(_bbsym_41809);
LF: 

    /** 				int = bbsym[S_MODE]*/
    _2 = (int)SEQ_PTR(_bbsym_41809);
    _int_41728 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_int_41728))
    _int_41728 = (long)DBL_PTR(_int_41728)->dbl;

    /** 				if int = M_TEMP then*/
    if (_int_41728 != 3)
    goto L10; // [412] 447

    /** 					int = bbsym[S_TEMP_NAME]*/
    _2 = (int)SEQ_PTR(_bbsym_41809);
    _int_41728 = (int)*(((s1_ptr)_2)->base + 34);
    if (!IS_ATOM_INT(_int_41728))
    _int_41728 = (long)DBL_PTR(_int_41728)->dbl;

    /** 					if int = tn then*/
    if (_int_41728 != _tn_41727)
    goto L11; // [426] 446

    /** 						found = TRUE*/
    _found_41725 = _9TRUE_431;

    /** 						exit*/
    DeRefDS(_bbsym_41809);
    _bbsym_41809 = NOVALUE;
    goto LD; // [443] 460
L11: 
L10: 

    /** 				i += 1*/
    _i_41726 = _i_41726 + 1;
    DeRef(_bbsym_41809);
    _bbsym_41809 = NOVALUE;

    /** 			end while*/
    goto LC; // [457] 346
LD: 
    goto L12; // [462] 889
L4: 

    /** 			if t != TYPE_NULL then*/
    if (_t_41721 == 0)
    goto L13; // [469] 824

    /** 				if not Initializing then*/
    if (_12Initializing_11763 != 0)
    goto L14; // [477] 500

    /** 					sym[S_GTYPE_NEW] = or_type(sym[S_GTYPE_NEW], t)*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22325 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22325);
    _22326 = _56or_type(_22325, _t_41721);
    _22325 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = _22326;
    if( _1 != _22326 ){
        DeRef(_1);
    }
    _22326 = NOVALUE;
L14: 

    /** 				if t = TYPE_SEQUENCE then*/
    if (_t_41721 != 8)
    goto L15; // [504] 633

    /** 					sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22328 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22328);
    _22329 = _56or_type(_22328, _etype_41723);
    _22328 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22329;
    if( _1 != _22329 ){
        DeRef(_1);
    }
    _22329 = NOVALUE;

    /** 					if val[MIN] != -1 then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22330 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(EQUALS, _22330, -1)){
        _22330 = NOVALUE;
        goto L16; // [535] 823
    }
    _22330 = NOVALUE;

    /** 						if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22332 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22333 = (int)NewDouble((double)-0xC0000000);
        else
        _22333 = - _12NOVALUE_11536;
    }
    else {
        _22333 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (binary_op_a(NOTEQ, _22332, _22333)){
        _22332 = NOVALUE;
        DeRef(_22333);
        _22333 = NOVALUE;
        goto L17; // [552] 599
    }
    _22332 = NOVALUE;
    DeRef(_22333);
    _22333 = NOVALUE;

    /** 							if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22335 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22335, 0)){
        _22335 = NOVALUE;
        goto L18; // [564] 581
    }
    _22335 = NOVALUE;

    /** 								sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L16; // [578] 823
L18: 

    /** 								sym[S_SEQ_LEN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22337 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22337);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22337;
    if( _1 != _22337 ){
        DeRef(_1);
    }
    _22337 = NOVALUE;
    goto L16; // [596] 823
L17: 

    /** 						elsif val[MIN] != sym[S_SEQ_LEN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22338 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_41729);
    _22339 = (int)*(((s1_ptr)_2)->base + 39);
    if (binary_op_a(EQUALS, _22338, _22339)){
        _22338 = NOVALUE;
        _22339 = NOVALUE;
        goto L16; // [613] 823
    }
    _22338 = NOVALUE;
    _22339 = NOVALUE;

    /** 							sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L16; // [630] 823
L15: 

    /** 				elsif t = TYPE_INTEGER then*/
    if (_t_41721 != 1)
    goto L19; // [637] 774

    /** 					if sym[S_OBJ_MIN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22342 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22343 = (int)NewDouble((double)-0xC0000000);
        else
        _22343 = - _12NOVALUE_11536;
    }
    else {
        _22343 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (binary_op_a(NOTEQ, _22342, _22343)){
        _22342 = NOVALUE;
        DeRef(_22343);
        _22343 = NOVALUE;
        goto L1A; // [654] 689
    }
    _22342 = NOVALUE;
    DeRef(_22343);
    _22343 = NOVALUE;

    /** 						sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22345 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22345);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22345;
    if( _1 != _22345 ){
        DeRef(_1);
    }
    _22345 = NOVALUE;

    /** 						sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22346 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22346);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22346;
    if( _1 != _22346 ){
        DeRef(_1);
    }
    _22346 = NOVALUE;
    goto L16; // [686] 823
L1A: 

    /** 					elsif sym[S_OBJ_MIN_NEW] != NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22347 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(EQUALS, _22347, _12NOVALUE_11536)){
        _22347 = NOVALUE;
        goto L16; // [699] 823
    }
    _22347 = NOVALUE;

    /** 						if val[MIN] < sym[S_OBJ_MIN_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22349 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_sym_41729);
    _22350 = (int)*(((s1_ptr)_2)->base + 41);
    if (binary_op_a(GREATEREQ, _22349, _22350)){
        _22349 = NOVALUE;
        _22350 = NOVALUE;
        goto L1B; // [717] 736
    }
    _22349 = NOVALUE;
    _22350 = NOVALUE;

    /** 							sym[S_OBJ_MIN_NEW] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22352 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22352);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22352;
    if( _1 != _22352 ){
        DeRef(_1);
    }
    _22352 = NOVALUE;
L1B: 

    /** 						if val[MAX] > sym[S_OBJ_MAX_NEW] then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22353 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_sym_41729);
    _22354 = (int)*(((s1_ptr)_2)->base + 42);
    if (binary_op_a(LESSEQ, _22353, _22354)){
        _22353 = NOVALUE;
        _22354 = NOVALUE;
        goto L16; // [750] 823
    }
    _22353 = NOVALUE;
    _22354 = NOVALUE;

    /** 							sym[S_OBJ_MAX_NEW] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22356 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22356);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 42);
    _1 = *(int *)_2;
    *(int *)_2 = _22356;
    if( _1 != _22356 ){
        DeRef(_1);
    }
    _22356 = NOVALUE;
    goto L16; // [771] 823
L19: 

    /** 					sym[S_OBJ_MIN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);

    /** 					if t = TYPE_OBJECT then*/
    if (_t_41721 != 16)
    goto L1C; // [788] 822

    /** 						sym[S_SEQ_ELEM_NEW] =*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22358 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22358);
    _22359 = _56or_type(_22358, _etype_41723);
    _22358 = NOVALUE;
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = _22359;
    if( _1 != _22359 ){
        DeRef(_1);
    }
    _22359 = NOVALUE;

    /** 						sym[S_SEQ_LEN_NEW] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
L1C: 
L16: 
L13: 

    /** 			i = 1*/
    _i_41726 = 1;

    /** 			while i <= length(BB_info) do*/
L1D: 
    if (IS_SEQUENCE(_56BB_info_41343)){
            _22360 = SEQ_PTR(_56BB_info_41343)->length;
    }
    else {
        _22360 = 1;
    }
    if (_i_41726 > _22360)
    goto L1E; // [839] 888

    /** 				int = BB_info[i][BB_VAR]*/
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    _22362 = (int)*(((s1_ptr)_2)->base + _i_41726);
    _2 = (int)SEQ_PTR(_22362);
    _int_41728 = (int)*(((s1_ptr)_2)->base + 1);
    if (!IS_ATOM_INT(_int_41728)){
        _int_41728 = (long)DBL_PTR(_int_41728)->dbl;
    }
    _22362 = NOVALUE;

    /** 				if int = s then*/
    if (_int_41728 != _s_41720)
    goto L1F; // [859] 877

    /** 					found = TRUE*/
    _found_41725 = _9TRUE_431;

    /** 					exit*/
    goto L1E; // [874] 888
L1F: 

    /** 				i += 1*/
    _i_41726 = _i_41726 + 1;

    /** 			end while*/
    goto L1D; // [885] 834
L1E: 
L12: 

    /** 		if not found then*/
    if (_found_41725 != 0)
    goto L20; // [891] 907

    /** 			BB_info = append(BB_info, repeat(0, 6))*/
    _22367 = Repeat(0, 6);
    RefDS(_22367);
    Append(&_56BB_info_41343, _56BB_info_41343, _22367);
    DeRefDS(_22367);
    _22367 = NOVALUE;
L20: 

    /** 		if t = TYPE_NULL then*/
    if (_t_41721 != 0)
    goto L21; // [911] 949

    /** 			if not found then*/
    if (_found_41725 != 0)
    goto L22; // [917] 1308

    /** 				BB_info[i] = dummy_bb*/
    RefDS(_56dummy_bb_41709);
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41343 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41726);
    _1 = *(int *)_2;
    *(int *)_2 = _56dummy_bb_41709;
    DeRef(_1);

    /** 				BB_info[i][BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41343 = MAKE_SEQ(_2);
    }
    _3 = (int)(_i_41726 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_41720;
    DeRef(_1);
    _22371 = NOVALUE;
    goto L22; // [946] 1308
L21: 

    /** 			sequence bbi = BB_info[i]*/
    DeRef(_bbi_41945);
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    _bbi_41945 = (int)*(((s1_ptr)_2)->base + _i_41726);
    Ref(_bbi_41945);

    /** 			BB_info[i] = 0*/
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41343 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41726);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			bbi[BB_VAR] = s*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _s_41720;
    DeRef(_1);

    /** 			bbi[BB_TYPE] = t*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41721;
    DeRef(_1);

    /** 			bbi[BB_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 6);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_41724;
    DeRef(_1);

    /** 			if t = TYPE_SEQUENCE and val[MIN] = -1 then*/
    _22374 = (_t_41721 == 8);
    if (_22374 == 0) {
        goto L23; // [995] 1077
    }
    _2 = (int)SEQ_PTR(_val_41722);
    _22376 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22376)) {
        _22377 = (_22376 == -1);
    }
    else {
        _22377 = binary_op(EQUALS, _22376, -1);
    }
    _22376 = NOVALUE;
    if (_22377 == 0) {
        DeRef(_22377);
        _22377 = NOVALUE;
        goto L23; // [1010] 1077
    }
    else {
        if (!IS_ATOM_INT(_22377) && DBL_PTR(_22377)->dbl == 0.0){
            DeRef(_22377);
            _22377 = NOVALUE;
            goto L23; // [1010] 1077
        }
        DeRef(_22377);
        _22377 = NOVALUE;
    }
    DeRef(_22377);
    _22377 = NOVALUE;

    /** 				if found and bbi[BB_ELEM] != TYPE_NULL then*/
    if (_found_41725 == 0) {
        goto L24; // [1015] 1051
    }
    _2 = (int)SEQ_PTR(_bbi_41945);
    _22379 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22379)) {
        _22380 = (_22379 != 0);
    }
    else {
        _22380 = binary_op(NOTEQ, _22379, 0);
    }
    _22379 = NOVALUE;
    if (_22380 == 0) {
        DeRef(_22380);
        _22380 = NOVALUE;
        goto L24; // [1030] 1051
    }
    else {
        if (!IS_ATOM_INT(_22380) && DBL_PTR(_22380)->dbl == 0.0){
            DeRef(_22380);
            _22380 = NOVALUE;
            goto L24; // [1030] 1051
        }
        DeRef(_22380);
        _22380 = NOVALUE;
    }
    DeRef(_22380);
    _22380 = NOVALUE;

    /** 					bbi[BB_ELEM] = or_type(bbi[BB_ELEM], etype)*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    _22381 = (int)*(((s1_ptr)_2)->base + 3);
    Ref(_22381);
    _22382 = _56or_type(_22381, _etype_41723);
    _22381 = NOVALUE;
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _22382;
    if( _1 != _22382 ){
        DeRef(_1);
    }
    _22382 = NOVALUE;
    goto L25; // [1048] 1060
L24: 

    /** 					bbi[BB_ELEM] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);
L25: 

    /** 				if not found then*/
    if (_found_41725 != 0)
    goto L26; // [1062] 1153

    /** 					bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L26; // [1074] 1153
L23: 

    /** 				bbi[BB_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 3);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41723;
    DeRef(_1);

    /** 				if t = TYPE_SEQUENCE or t = TYPE_OBJECT then*/
    _22384 = (_t_41721 == 8);
    if (_22384 != 0) {
        goto L27; // [1091] 1106
    }
    _22386 = (_t_41721 == 16);
    if (_22386 == 0)
    {
        DeRef(_22386);
        _22386 = NOVALUE;
        goto L28; // [1102] 1145
    }
    else{
        DeRef(_22386);
        _22386 = NOVALUE;
    }
L27: 

    /** 					if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22387 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22387, 0)){
        _22387 = NOVALUE;
        goto L29; // [1114] 1129
    }
    _22387 = NOVALUE;

    /** 						bbi[BB_SEQLEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L2A; // [1126] 1152
L29: 

    /** 						bbi[BB_SEQLEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22389 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22389);
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 4);
    _1 = *(int *)_2;
    *(int *)_2 = _22389;
    if( _1 != _22389 ){
        DeRef(_1);
    }
    _22389 = NOVALUE;
    goto L2A; // [1142] 1152
L28: 

    /** 					bbi[BB_OBJ] = val*/
    RefDS(_val_41722);
    _2 = (int)SEQ_PTR(_bbi_41945);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bbi_41945 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = _val_41722;
    DeRef(_1);
L2A: 
L26: 

    /** 			BB_info[i] = bbi*/
    RefDS(_bbi_41945);
    _2 = (int)SEQ_PTR(_56BB_info_41343);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56BB_info_41343 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _i_41726);
    _1 = *(int *)_2;
    *(int *)_2 = _bbi_41945;
    DeRef(_1);
    DeRefDS(_bbi_41945);
    _bbi_41945 = NOVALUE;
    goto L22; // [1164] 1308
L3: 

    /** 	elsif mode = M_CONSTANT then*/
    if (_mode_41734 != 2)
    goto L2B; // [1171] 1307

    /** 		sym[S_GTYPE] = t*/
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _t_41721;
    DeRef(_1);

    /** 		sym[S_SEQ_ELEM] = etype*/
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _etype_41723;
    DeRef(_1);

    /** 		if sym[S_GTYPE] = TYPE_SEQUENCE or*/
    _2 = (int)SEQ_PTR(_sym_41729);
    _22391 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22391)) {
        _22392 = (_22391 == 8);
    }
    else {
        _22392 = binary_op(EQUALS, _22391, 8);
    }
    _22391 = NOVALUE;
    if (IS_ATOM_INT(_22392)) {
        if (_22392 != 0) {
            goto L2C; // [1205] 1226
        }
    }
    else {
        if (DBL_PTR(_22392)->dbl != 0.0) {
            goto L2C; // [1205] 1226
        }
    }
    _2 = (int)SEQ_PTR(_sym_41729);
    _22394 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22394)) {
        _22395 = (_22394 == 16);
    }
    else {
        _22395 = binary_op(EQUALS, _22394, 16);
    }
    _22394 = NOVALUE;
    if (_22395 == 0) {
        DeRef(_22395);
        _22395 = NOVALUE;
        goto L2D; // [1222] 1269
    }
    else {
        if (!IS_ATOM_INT(_22395) && DBL_PTR(_22395)->dbl == 0.0){
            DeRef(_22395);
            _22395 = NOVALUE;
            goto L2D; // [1222] 1269
        }
        DeRef(_22395);
        _22395 = NOVALUE;
    }
    DeRef(_22395);
    _22395 = NOVALUE;
L2C: 

    /** 			if val[MIN] < 0 then*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22396 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(GREATEREQ, _22396, 0)){
        _22396 = NOVALUE;
        goto L2E; // [1234] 1251
    }
    _22396 = NOVALUE;

    /** 				sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L2F; // [1248] 1298
L2E: 

    /** 				sym[S_SEQ_LEN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22398 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22398);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22398;
    if( _1 != _22398 ){
        DeRef(_1);
    }
    _22398 = NOVALUE;
    goto L2F; // [1266] 1298
L2D: 

    /** 			sym[S_OBJ_MIN] = val[MIN]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22399 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_22399);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22399;
    if( _1 != _22399 ){
        DeRef(_1);
    }
    _22399 = NOVALUE;

    /** 			sym[S_OBJ_MAX] = val[MAX]*/
    _2 = (int)SEQ_PTR(_val_41722);
    _22400 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_22400);
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22400;
    if( _1 != _22400 ){
        DeRef(_1);
    }
    _22400 = NOVALUE;
L2F: 

    /** 		sym[S_HAS_DELETE] = has_delete*/
    _2 = (int)SEQ_PTR(_sym_41729);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_41729 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 54);
    _1 = *(int *)_2;
    *(int *)_2 = _has_delete_41724;
    DeRef(_1);
L2B: 
L22: 

    /** 	SymTab[s] = sym*/
    RefDS(_sym_41729);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_41720);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_41729;
    DeRef(_1);

    /** end procedure*/
    DeRefDS(_val_41722);
    DeRefDS(_sym_41729);
    DeRef(_22289);
    _22289 = NOVALUE;
    DeRef(_22294);
    _22294 = NOVALUE;
    _22303 = NOVALUE;
    _22308 = NOVALUE;
    DeRef(_22374);
    _22374 = NOVALUE;
    DeRef(_22384);
    _22384 = NOVALUE;
    DeRef(_22392);
    _22392 = NOVALUE;
    return;
    ;
}


void _56CName(int _s_42019)
{
    int _v_42020 = NOVALUE;
    int _mode_42022 = NOVALUE;
    int _22461 = NOVALUE;
    int _22460 = NOVALUE;
    int _22459 = NOVALUE;
    int _22458 = NOVALUE;
    int _22457 = NOVALUE;
    int _22456 = NOVALUE;
    int _22455 = NOVALUE;
    int _22454 = NOVALUE;
    int _22453 = NOVALUE;
    int _22452 = NOVALUE;
    int _22450 = NOVALUE;
    int _22448 = NOVALUE;
    int _22447 = NOVALUE;
    int _22446 = NOVALUE;
    int _22445 = NOVALUE;
    int _22444 = NOVALUE;
    int _22443 = NOVALUE;
    int _22442 = NOVALUE;
    int _22441 = NOVALUE;
    int _22440 = NOVALUE;
    int _22439 = NOVALUE;
    int _22438 = NOVALUE;
    int _22436 = NOVALUE;
    int _22435 = NOVALUE;
    int _22434 = NOVALUE;
    int _22433 = NOVALUE;
    int _22432 = NOVALUE;
    int _22431 = NOVALUE;
    int _22429 = NOVALUE;
    int _22428 = NOVALUE;
    int _22426 = NOVALUE;
    int _22425 = NOVALUE;
    int _22424 = NOVALUE;
    int _22423 = NOVALUE;
    int _22422 = NOVALUE;
    int _22421 = NOVALUE;
    int _22420 = NOVALUE;
    int _22419 = NOVALUE;
    int _22418 = NOVALUE;
    int _22417 = NOVALUE;
    int _22416 = NOVALUE;
    int _22415 = NOVALUE;
    int _22413 = NOVALUE;
    int _22412 = NOVALUE;
    int _22410 = NOVALUE;
    int _22409 = NOVALUE;
    int _22408 = NOVALUE;
    int _22407 = NOVALUE;
    int _22406 = NOVALUE;
    int _22405 = NOVALUE;
    int _22402 = NOVALUE;
    int _0, _1, _2, _3;
    
    if (!IS_ATOM_INT(_s_42019)) {
        _1 = (long)(DBL_PTR(_s_42019)->dbl);
        DeRefDS(_s_42019);
        _s_42019 = _1;
    }

    /** 	v = ObjValue(s)*/
    _0 = _v_42020;
    _v_42020 = _56ObjValue(_s_42019);
    DeRef(_0);

    /** 	integer mode = SymTab[s][S_MODE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22402 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22402);
    _mode_42022 = (int)*(((s1_ptr)_2)->base + 3);
    if (!IS_ATOM_INT(_mode_42022)){
        _mode_42022 = (long)DBL_PTR(_mode_42022)->dbl;
    }
    _22402 = NOVALUE;

    /**  	if mode = M_NORMAL then*/
    if (_mode_42022 != 1)
    goto L1; // [29] 240

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22405 = (_56LeftSym_41344 == _9FALSE_429);
    if (_22405 == 0) {
        _22406 = 0;
        goto L2; // [43] 61
    }
    _22407 = _56GType(_s_42019);
    if (IS_ATOM_INT(_22407)) {
        _22408 = (_22407 == 1);
    }
    else {
        _22408 = binary_op(EQUALS, _22407, 1);
    }
    DeRef(_22407);
    _22407 = NOVALUE;
    if (IS_ATOM_INT(_22408))
    _22406 = (_22408 != 0);
    else
    _22406 = DBL_PTR(_22408)->dbl != 0.0;
L2: 
    if (_22406 == 0) {
        goto L3; // [61] 84
    }
    if (IS_ATOM_INT(_v_42020) && IS_ATOM_INT(_12NOVALUE_11536)) {
        _22410 = (_v_42020 != _12NOVALUE_11536);
    }
    else {
        _22410 = binary_op(NOTEQ, _v_42020, _12NOVALUE_11536);
    }
    if (_22410 == 0) {
        DeRef(_22410);
        _22410 = NOVALUE;
        goto L3; // [72] 84
    }
    else {
        if (!IS_ATOM_INT(_22410) && DBL_PTR(_22410)->dbl == 0.0){
            DeRef(_22410);
            _22410 = NOVALUE;
            goto L3; // [72] 84
        }
        DeRef(_22410);
        _22410 = NOVALUE;
    }
    DeRef(_22410);
    _22410 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22411);
    Ref(_v_42020);
    _53c_printf(_22411, _v_42020);
    goto L4; // [81] 166
L3: 

    /** 			if SymTab[s][S_SCOPE] > SC_PRIVATE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22412 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22412);
    _22413 = (int)*(((s1_ptr)_2)->base + 4);
    _22412 = NOVALUE;
    if (binary_op_a(LESSEQ, _22413, 3)){
        _22413 = NOVALUE;
        goto L5; // [100] 142
    }
    _22413 = NOVALUE;

    /** 				c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22415 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22415);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22416 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22416 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22415 = NOVALUE;
    RefDS(_21922);
    Ref(_22416);
    _53c_printf(_21922, _22416);
    _22416 = NOVALUE;

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22417 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22417);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22418 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22418 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22417 = NOVALUE;
    Ref(_22418);
    _53c_puts(_22418);
    _22418 = NOVALUE;
    goto L6; // [139] 165
L5: 

    /** 				c_puts("_")*/
    RefDS(_21901);
    _53c_puts(_21901);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22419 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22419);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22420 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22420 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22419 = NOVALUE;
    Ref(_22420);
    _53c_puts(_22420);
    _22420 = NOVALUE;
L6: 
L4: 

    /** 		if s != CurrentSub and SymTab[s][S_NREFS] < 2 then*/
    _22421 = (_s_42019 != _12CurrentSub_11690);
    if (_22421 == 0) {
        goto L7; // [174] 222
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22423 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22423);
    _22424 = (int)*(((s1_ptr)_2)->base + 12);
    _22423 = NOVALUE;
    if (IS_ATOM_INT(_22424)) {
        _22425 = (_22424 < 2);
    }
    else {
        _22425 = binary_op(LESS, _22424, 2);
    }
    _22424 = NOVALUE;
    if (_22425 == 0) {
        DeRef(_22425);
        _22425 = NOVALUE;
        goto L7; // [195] 222
    }
    else {
        if (!IS_ATOM_INT(_22425) && DBL_PTR(_22425)->dbl == 0.0){
            DeRef(_22425);
            _22425 = NOVALUE;
            goto L7; // [195] 222
        }
        DeRef(_22425);
        _22425 = NOVALUE;
    }
    DeRef(_22425);
    _22425 = NOVALUE;

    /** 			SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42019 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22428 = (int)*(((s1_ptr)_2)->base + 12);
    _22426 = NOVALUE;
    if (IS_ATOM_INT(_22428)) {
        _22429 = _22428 + 1;
        if (_22429 > MAXINT){
            _22429 = NewDouble((double)_22429);
        }
    }
    else
    _22429 = binary_op(PLUS, 1, _22428);
    _22428 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22429;
    if( _1 != _22429 ){
        DeRef(_1);
    }
    _22429 = NOVALUE;
    _22426 = NOVALUE;
L7: 

    /** 		SetBBType(s, TYPE_NULL, novalue, TYPE_OBJECT, 0) -- record that this var was referenced in this BB*/
    RefDS(_53novalue_45142);
    _56SetBBType(_s_42019, 0, _53novalue_45142, 16, 0);
    goto L8; // [237] 490
L1: 

    /**  	elsif mode = M_CONSTANT then*/
    if (_mode_42022 != 2)
    goto L9; // [244] 419

    /** 		if (integer( sym_obj( s ) ) and SymTab[s][S_GTYPE] != TYPE_DOUBLE ) or (LeftSym = FALSE and TypeIs(s, TYPE_INTEGER) and v != NOVALUE) then*/
    _22431 = _52sym_obj(_s_42019);
    if (IS_ATOM_INT(_22431))
    _22432 = 1;
    else if (IS_ATOM_DBL(_22431))
    _22432 = IS_ATOM_INT(DoubleToInt(_22431));
    else
    _22432 = 0;
    DeRef(_22431);
    _22431 = NOVALUE;
    if (_22432 == 0) {
        _22433 = 0;
        goto LA; // [257] 283
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22434 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22434);
    _22435 = (int)*(((s1_ptr)_2)->base + 36);
    _22434 = NOVALUE;
    if (IS_ATOM_INT(_22435)) {
        _22436 = (_22435 != 2);
    }
    else {
        _22436 = binary_op(NOTEQ, _22435, 2);
    }
    _22435 = NOVALUE;
    if (IS_ATOM_INT(_22436))
    _22433 = (_22436 != 0);
    else
    _22433 = DBL_PTR(_22436)->dbl != 0.0;
LA: 
    if (_22433 != 0) {
        goto LB; // [283] 329
    }
    _22438 = (_56LeftSym_41344 == _9FALSE_429);
    if (_22438 == 0) {
        _22439 = 0;
        goto LC; // [295] 310
    }
    _22440 = _56TypeIs(_s_42019, 1);
    if (IS_ATOM_INT(_22440))
    _22439 = (_22440 != 0);
    else
    _22439 = DBL_PTR(_22440)->dbl != 0.0;
LC: 
    if (_22439 == 0) {
        DeRef(_22441);
        _22441 = 0;
        goto LD; // [310] 324
    }
    if (IS_ATOM_INT(_v_42020) && IS_ATOM_INT(_12NOVALUE_11536)) {
        _22442 = (_v_42020 != _12NOVALUE_11536);
    }
    else {
        _22442 = binary_op(NOTEQ, _v_42020, _12NOVALUE_11536);
    }
    if (IS_ATOM_INT(_22442))
    _22441 = (_22442 != 0);
    else
    _22441 = DBL_PTR(_22442)->dbl != 0.0;
LD: 
    if (_22441 == 0)
    {
        _22441 = NOVALUE;
        goto LE; // [325] 338
    }
    else{
        _22441 = NOVALUE;
    }
LB: 

    /** 			c_printf("%d", v)*/
    RefDS(_22411);
    Ref(_v_42020);
    _53c_printf(_22411, _v_42020);
    goto L8; // [335] 490
LE: 

    /** 			c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22443 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22443);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22444 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22444 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22443 = NOVALUE;
    RefDS(_21922);
    Ref(_22444);
    _53c_printf(_21922, _22444);
    _22444 = NOVALUE;

    /** 			c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22445 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22445);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22446 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22446 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22445 = NOVALUE;
    Ref(_22446);
    _53c_puts(_22446);
    _22446 = NOVALUE;

    /** 			if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22447 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22447);
    _22448 = (int)*(((s1_ptr)_2)->base + 12);
    _22447 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22448, 2)){
        _22448 = NOVALUE;
        goto L8; // [387] 490
    }
    _22448 = NOVALUE;

    /** 				SymTab[s][S_NREFS] += 1*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42019 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    _22452 = (int)*(((s1_ptr)_2)->base + 12);
    _22450 = NOVALUE;
    if (IS_ATOM_INT(_22452)) {
        _22453 = _22452 + 1;
        if (_22453 > MAXINT){
            _22453 = NewDouble((double)_22453);
        }
    }
    else
    _22453 = binary_op(PLUS, 1, _22452);
    _22452 = NOVALUE;
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = _22453;
    if( _1 != _22453 ){
        DeRef(_1);
    }
    _22453 = NOVALUE;
    _22450 = NOVALUE;
    goto L8; // [416] 490
L9: 

    /** 		if LeftSym = FALSE and GType(s) = TYPE_INTEGER and v != NOVALUE then*/
    _22454 = (_56LeftSym_41344 == _9FALSE_429);
    if (_22454 == 0) {
        _22455 = 0;
        goto LF; // [429] 447
    }
    _22456 = _56GType(_s_42019);
    if (IS_ATOM_INT(_22456)) {
        _22457 = (_22456 == 1);
    }
    else {
        _22457 = binary_op(EQUALS, _22456, 1);
    }
    DeRef(_22456);
    _22456 = NOVALUE;
    if (IS_ATOM_INT(_22457))
    _22455 = (_22457 != 0);
    else
    _22455 = DBL_PTR(_22457)->dbl != 0.0;
LF: 
    if (_22455 == 0) {
        goto L10; // [447] 470
    }
    if (IS_ATOM_INT(_v_42020) && IS_ATOM_INT(_12NOVALUE_11536)) {
        _22459 = (_v_42020 != _12NOVALUE_11536);
    }
    else {
        _22459 = binary_op(NOTEQ, _v_42020, _12NOVALUE_11536);
    }
    if (_22459 == 0) {
        DeRef(_22459);
        _22459 = NOVALUE;
        goto L10; // [458] 470
    }
    else {
        if (!IS_ATOM_INT(_22459) && DBL_PTR(_22459)->dbl == 0.0){
            DeRef(_22459);
            _22459 = NOVALUE;
            goto L10; // [458] 470
        }
        DeRef(_22459);
        _22459 = NOVALUE;
    }
    DeRef(_22459);
    _22459 = NOVALUE;

    /** 			c_printf("%d", v)*/
    RefDS(_22411);
    Ref(_v_42020);
    _53c_printf(_22411, _v_42020);
    goto L11; // [467] 489
L10: 

    /** 			c_printf("_%d", SymTab[s][S_TEMP_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22460 = (int)*(((s1_ptr)_2)->base + _s_42019);
    _2 = (int)SEQ_PTR(_22460);
    _22461 = (int)*(((s1_ptr)_2)->base + 34);
    _22460 = NOVALUE;
    RefDS(_21922);
    Ref(_22461);
    _53c_printf(_21922, _22461);
    _22461 = NOVALUE;
L11: 
L8: 

    /** 	LeftSym = FALSE*/
    _56LeftSym_41344 = _9FALSE_429;

    /** end procedure*/
    DeRef(_v_42020);
    DeRef(_22405);
    _22405 = NOVALUE;
    DeRef(_22421);
    _22421 = NOVALUE;
    DeRef(_22408);
    _22408 = NOVALUE;
    DeRef(_22438);
    _22438 = NOVALUE;
    DeRef(_22436);
    _22436 = NOVALUE;
    DeRef(_22440);
    _22440 = NOVALUE;
    DeRef(_22442);
    _22442 = NOVALUE;
    DeRef(_22454);
    _22454 = NOVALUE;
    DeRef(_22457);
    _22457 = NOVALUE;
    return;
    ;
}


void _56c_stmt(int _stmt_42153, int _arg_42154, int _lhs_arg_42156)
{
    int _argcount_42157 = NOVALUE;
    int _i_42158 = NOVALUE;
    int _22516 = NOVALUE;
    int _22515 = NOVALUE;
    int _22514 = NOVALUE;
    int _22513 = NOVALUE;
    int _22512 = NOVALUE;
    int _22511 = NOVALUE;
    int _22510 = NOVALUE;
    int _22509 = NOVALUE;
    int _22508 = NOVALUE;
    int _22507 = NOVALUE;
    int _22506 = NOVALUE;
    int _22505 = NOVALUE;
    int _22504 = NOVALUE;
    int _22503 = NOVALUE;
    int _22502 = NOVALUE;
    int _22501 = NOVALUE;
    int _22500 = NOVALUE;
    int _22498 = NOVALUE;
    int _22496 = NOVALUE;
    int _22494 = NOVALUE;
    int _22493 = NOVALUE;
    int _22492 = NOVALUE;
    int _22491 = NOVALUE;
    int _22489 = NOVALUE;
    int _22488 = NOVALUE;
    int _22487 = NOVALUE;
    int _22486 = NOVALUE;
    int _22485 = NOVALUE;
    int _22484 = NOVALUE;
    int _22483 = NOVALUE;
    int _22482 = NOVALUE;
    int _22481 = NOVALUE;
    int _22480 = NOVALUE;
    int _22479 = NOVALUE;
    int _22478 = NOVALUE;
    int _22477 = NOVALUE;
    int _22476 = NOVALUE;
    int _22473 = NOVALUE;
    int _22472 = NOVALUE;
    int _22471 = NOVALUE;
    int _22470 = NOVALUE;
    int _22469 = NOVALUE;
    int _22468 = NOVALUE;
    int _22466 = NOVALUE;
    int _22464 = NOVALUE;
    int _22463 = NOVALUE;
    int _22462 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_lhs_arg_42156)) {
        _1 = (long)(DBL_PTR(_lhs_arg_42156)->dbl);
        DeRefDS(_lhs_arg_42156);
        _lhs_arg_42156 = _1;
    }

    /** 	if LAST_PASS = TRUE and Initializing = FALSE then*/
    _22462 = (_56LAST_PASS_41334 == _9TRUE_431);
    if (_22462 == 0) {
        goto L1; // [15] 47
    }
    _22464 = (_12Initializing_11763 == _9FALSE_429);
    if (_22464 == 0)
    {
        DeRef(_22464);
        _22464 = NOVALUE;
        goto L1; // [28] 47
    }
    else{
        DeRef(_22464);
        _22464 = NOVALUE;
    }

    /** 		cfile_size += 1*/
    _12cfile_size_11762 = _12cfile_size_11762 + 1;

    /** 		update_checksum( stmt )*/
    RefDS(_stmt_42153);
    _54update_checksum(_stmt_42153);
L1: 

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L2; // [51] 60
    }
    else{
    }

    /** 		adjust_indent_before(stmt)*/
    RefDS(_stmt_42153);
    _53adjust_indent_before(_stmt_42153);
L2: 

    /** 	if atom(arg) then*/
    _22466 = IS_ATOM(_arg_42154);
    if (_22466 == 0)
    {
        _22466 = NOVALUE;
        goto L3; // [65] 75
    }
    else{
        _22466 = NOVALUE;
    }

    /** 		arg = {arg}*/
    _0 = _arg_42154;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_42154);
    *((int *)(_2+4)) = _arg_42154;
    _arg_42154 = MAKE_SEQ(_1);
    DeRef(_0);
L3: 

    /** 	argcount = 1*/
    _argcount_42157 = 1;

    /** 	i = 1*/
    _i_42158 = 1;

    /** 	while i <= length(stmt) and length(stmt) > 0 do*/
L4: 
    if (IS_SEQUENCE(_stmt_42153)){
            _22468 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22468 = 1;
    }
    _22469 = (_i_42158 <= _22468);
    _22468 = NOVALUE;
    if (_22469 == 0) {
        goto L5; // [97] 435
    }
    if (IS_SEQUENCE(_stmt_42153)){
            _22471 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22471 = 1;
    }
    _22472 = (_22471 > 0);
    _22471 = NOVALUE;
    if (_22472 == 0)
    {
        DeRef(_22472);
        _22472 = NOVALUE;
        goto L5; // [109] 435
    }
    else{
        DeRef(_22472);
        _22472 = NOVALUE;
    }

    /** 		if stmt[i] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22473 = (int)*(((s1_ptr)_2)->base + _i_42158);
    if (binary_op_a(NOTEQ, _22473, 64)){
        _22473 = NOVALUE;
        goto L6; // [118] 288
    }
    _22473 = NOVALUE;

    /** 			if i = 1 then*/
    if (_i_42158 != 1)
    goto L7; // [124] 138

    /** 				LeftSym = TRUE*/
    _56LeftSym_41344 = _9TRUE_431;
L7: 

    /** 			if i < length(stmt) and stmt[i+1] > '0' and stmt[i+1] <= '9' then*/
    if (IS_SEQUENCE(_stmt_42153)){
            _22476 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22476 = 1;
    }
    _22477 = (_i_42158 < _22476);
    _22476 = NOVALUE;
    if (_22477 == 0) {
        _22478 = 0;
        goto L8; // [147] 167
    }
    _22479 = _i_42158 + 1;
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22480 = (int)*(((s1_ptr)_2)->base + _22479);
    if (IS_ATOM_INT(_22480)) {
        _22481 = (_22480 > 48);
    }
    else {
        _22481 = binary_op(GREATER, _22480, 48);
    }
    _22480 = NOVALUE;
    if (IS_ATOM_INT(_22481))
    _22478 = (_22481 != 0);
    else
    _22478 = DBL_PTR(_22481)->dbl != 0.0;
L8: 
    if (_22478 == 0) {
        goto L9; // [167] 249
    }
    _22483 = _i_42158 + 1;
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22484 = (int)*(((s1_ptr)_2)->base + _22483);
    if (IS_ATOM_INT(_22484)) {
        _22485 = (_22484 <= 57);
    }
    else {
        _22485 = binary_op(LESSEQ, _22484, 57);
    }
    _22484 = NOVALUE;
    if (_22485 == 0) {
        DeRef(_22485);
        _22485 = NOVALUE;
        goto L9; // [184] 249
    }
    else {
        if (!IS_ATOM_INT(_22485) && DBL_PTR(_22485)->dbl == 0.0){
            DeRef(_22485);
            _22485 = NOVALUE;
            goto L9; // [184] 249
        }
        DeRef(_22485);
        _22485 = NOVALUE;
    }
    DeRef(_22485);
    _22485 = NOVALUE;

    /** 				if arg[stmt[i+1]-'0'] = lhs_arg then*/
    _22486 = _i_42158 + 1;
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22487 = (int)*(((s1_ptr)_2)->base + _22486);
    if (IS_ATOM_INT(_22487)) {
        _22488 = _22487 - 48;
    }
    else {
        _22488 = binary_op(MINUS, _22487, 48);
    }
    _22487 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42154);
    if (!IS_ATOM_INT(_22488)){
        _22489 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22488)->dbl));
    }
    else{
        _22489 = (int)*(((s1_ptr)_2)->base + _22488);
    }
    if (binary_op_a(NOTEQ, _22489, _lhs_arg_42156)){
        _22489 = NOVALUE;
        goto LA; // [205] 219
    }
    _22489 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _56LeftSym_41344 = _9TRUE_431;
LA: 

    /** 				CName(arg[stmt[i+1]-'0'])*/
    _22491 = _i_42158 + 1;
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22492 = (int)*(((s1_ptr)_2)->base + _22491);
    if (IS_ATOM_INT(_22492)) {
        _22493 = _22492 - 48;
    }
    else {
        _22493 = binary_op(MINUS, _22492, 48);
    }
    _22492 = NOVALUE;
    _2 = (int)SEQ_PTR(_arg_42154);
    if (!IS_ATOM_INT(_22493)){
        _22494 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22493)->dbl));
    }
    else{
        _22494 = (int)*(((s1_ptr)_2)->base + _22493);
    }
    Ref(_22494);
    _56CName(_22494);
    _22494 = NOVALUE;

    /** 				i += 1*/
    _i_42158 = _i_42158 + 1;
    goto LB; // [246] 279
L9: 

    /** 				if arg[argcount] = lhs_arg then*/
    _2 = (int)SEQ_PTR(_arg_42154);
    _22496 = (int)*(((s1_ptr)_2)->base + _argcount_42157);
    if (binary_op_a(NOTEQ, _22496, _lhs_arg_42156)){
        _22496 = NOVALUE;
        goto LC; // [255] 269
    }
    _22496 = NOVALUE;

    /** 					LeftSym = TRUE*/
    _56LeftSym_41344 = _9TRUE_431;
LC: 

    /** 				CName(arg[argcount])*/
    _2 = (int)SEQ_PTR(_arg_42154);
    _22498 = (int)*(((s1_ptr)_2)->base + _argcount_42157);
    Ref(_22498);
    _56CName(_22498);
    _22498 = NOVALUE;
LB: 

    /** 			argcount += 1*/
    _argcount_42157 = _argcount_42157 + 1;
    goto LD; // [285] 353
L6: 

    /** 			c_putc(stmt[i])*/
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22500 = (int)*(((s1_ptr)_2)->base + _i_42158);
    Ref(_22500);
    _53c_putc(_22500);
    _22500 = NOVALUE;

    /** 			if stmt[i] = '&' and i < length(stmt) and stmt[i+1] = '@' then*/
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22501 = (int)*(((s1_ptr)_2)->base + _i_42158);
    if (IS_ATOM_INT(_22501)) {
        _22502 = (_22501 == 38);
    }
    else {
        _22502 = binary_op(EQUALS, _22501, 38);
    }
    _22501 = NOVALUE;
    if (IS_ATOM_INT(_22502)) {
        if (_22502 == 0) {
            DeRef(_22503);
            _22503 = 0;
            goto LE; // [307] 322
        }
    }
    else {
        if (DBL_PTR(_22502)->dbl == 0.0) {
            DeRef(_22503);
            _22503 = 0;
            goto LE; // [307] 322
        }
    }
    if (IS_SEQUENCE(_stmt_42153)){
            _22504 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22504 = 1;
    }
    _22505 = (_i_42158 < _22504);
    _22504 = NOVALUE;
    DeRef(_22503);
    _22503 = (_22505 != 0);
LE: 
    if (_22503 == 0) {
        goto LF; // [322] 352
    }
    _22507 = _i_42158 + 1;
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22508 = (int)*(((s1_ptr)_2)->base + _22507);
    if (IS_ATOM_INT(_22508)) {
        _22509 = (_22508 == 64);
    }
    else {
        _22509 = binary_op(EQUALS, _22508, 64);
    }
    _22508 = NOVALUE;
    if (_22509 == 0) {
        DeRef(_22509);
        _22509 = NOVALUE;
        goto LF; // [339] 352
    }
    else {
        if (!IS_ATOM_INT(_22509) && DBL_PTR(_22509)->dbl == 0.0){
            DeRef(_22509);
            _22509 = NOVALUE;
            goto LF; // [339] 352
        }
        DeRef(_22509);
        _22509 = NOVALUE;
    }
    DeRef(_22509);
    _22509 = NOVALUE;

    /** 				LeftSym = TRUE -- never say: x = x &y or andy - always leave space*/
    _56LeftSym_41344 = _9TRUE_431;
LF: 
LD: 

    /** 		if stmt[i] = '\n' and i < length(stmt) then*/
    _2 = (int)SEQ_PTR(_stmt_42153);
    _22510 = (int)*(((s1_ptr)_2)->base + _i_42158);
    if (IS_ATOM_INT(_22510)) {
        _22511 = (_22510 == 10);
    }
    else {
        _22511 = binary_op(EQUALS, _22510, 10);
    }
    _22510 = NOVALUE;
    if (IS_ATOM_INT(_22511)) {
        if (_22511 == 0) {
            goto L10; // [363] 424
        }
    }
    else {
        if (DBL_PTR(_22511)->dbl == 0.0) {
            goto L10; // [363] 424
        }
    }
    if (IS_SEQUENCE(_stmt_42153)){
            _22513 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22513 = 1;
    }
    _22514 = (_i_42158 < _22513);
    _22513 = NOVALUE;
    if (_22514 == 0)
    {
        DeRef(_22514);
        _22514 = NOVALUE;
        goto L10; // [375] 424
    }
    else{
        DeRef(_22514);
        _22514 = NOVALUE;
    }

    /** 			if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L11; // [382] 391
    }
    else{
    }

    /** 				adjust_indent_after(stmt)*/
    RefDS(_stmt_42153);
    _53adjust_indent_after(_stmt_42153);
L11: 

    /** 			stmt = stmt[i+1..$]*/
    _22515 = _i_42158 + 1;
    if (_22515 > MAXINT){
        _22515 = NewDouble((double)_22515);
    }
    if (IS_SEQUENCE(_stmt_42153)){
            _22516 = SEQ_PTR(_stmt_42153)->length;
    }
    else {
        _22516 = 1;
    }
    rhs_slice_target = (object_ptr)&_stmt_42153;
    RHS_Slice(_stmt_42153, _22515, _22516);

    /** 			i = 0*/
    _i_42158 = 0;

    /** 			if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L12; // [414] 423
    }
    else{
    }

    /** 				adjust_indent_before(stmt)*/
    RefDS(_stmt_42153);
    _53adjust_indent_before(_stmt_42153);
L12: 
L10: 

    /** 		i += 1*/
    _i_42158 = _i_42158 + 1;

    /** 	end while*/
    goto L4; // [432] 90
L5: 

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L13; // [439] 448
    }
    else{
    }

    /** 		adjust_indent_after(stmt)*/
    RefDS(_stmt_42153);
    _53adjust_indent_after(_stmt_42153);
L13: 

    /** end procedure*/
    DeRefDS(_stmt_42153);
    DeRef(_arg_42154);
    DeRef(_22462);
    _22462 = NOVALUE;
    DeRef(_22469);
    _22469 = NOVALUE;
    DeRef(_22477);
    _22477 = NOVALUE;
    DeRef(_22479);
    _22479 = NOVALUE;
    DeRef(_22483);
    _22483 = NOVALUE;
    DeRef(_22481);
    _22481 = NOVALUE;
    DeRef(_22486);
    _22486 = NOVALUE;
    DeRef(_22491);
    _22491 = NOVALUE;
    DeRef(_22488);
    _22488 = NOVALUE;
    DeRef(_22505);
    _22505 = NOVALUE;
    DeRef(_22493);
    _22493 = NOVALUE;
    DeRef(_22502);
    _22502 = NOVALUE;
    DeRef(_22507);
    _22507 = NOVALUE;
    DeRef(_22515);
    _22515 = NOVALUE;
    DeRef(_22511);
    _22511 = NOVALUE;
    return;
    ;
}


void _56c_stmt0(int _stmt_42252)
{
    int _0, _1, _2;
    

    /** 	if emit_c_output then*/
    if (_53emit_c_output_45135 == 0)
    {
        goto L1; // [7] 18
    }
    else{
    }

    /** 		c_stmt(stmt, {})*/
    RefDS(_stmt_42252);
    RefDS(_21829);
    _56c_stmt(_stmt_42252, _21829, 0);
L1: 

    /** end procedure*/
    DeRefDS(_stmt_42252);
    return;
    ;
}


void _56DeclareFileVars()
{
    int _s_42258 = NOVALUE;
    int _eentry_42260 = NOVALUE;
    int _22558 = NOVALUE;
    int _22557 = NOVALUE;
    int _22556 = NOVALUE;
    int _22553 = NOVALUE;
    int _22551 = NOVALUE;
    int _22550 = NOVALUE;
    int _22549 = NOVALUE;
    int _22548 = NOVALUE;
    int _22544 = NOVALUE;
    int _22543 = NOVALUE;
    int _22542 = NOVALUE;
    int _22541 = NOVALUE;
    int _22540 = NOVALUE;
    int _22539 = NOVALUE;
    int _22538 = NOVALUE;
    int _22537 = NOVALUE;
    int _22536 = NOVALUE;
    int _22535 = NOVALUE;
    int _22534 = NOVALUE;
    int _22533 = NOVALUE;
    int _22532 = NOVALUE;
    int _22531 = NOVALUE;
    int _22530 = NOVALUE;
    int _22529 = NOVALUE;
    int _22528 = NOVALUE;
    int _22527 = NOVALUE;
    int _22526 = NOVALUE;
    int _22525 = NOVALUE;
    int _22524 = NOVALUE;
    int _22523 = NOVALUE;
    int _22520 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Declaring file vars\n")*/
    RefDS(_22519);
    _53c_puts(_22519);

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22520 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_22520);
    _s_42258 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42258)){
        _s_42258 = (long)DBL_PTR(_s_42258)->dbl;
    }
    _22520 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42258 == 0)
    {
        goto L2; // [29] 321
    }
    else{
    }

    /** 		eentry = SymTab[s]*/
    DeRef(_eentry_42260);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _eentry_42260 = (int)*(((s1_ptr)_2)->base + _s_42258);
    Ref(_eentry_42260);

    /** 		if eentry[S_SCOPE] >= SC_LOCAL*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22523 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22523)) {
        _22524 = (_22523 >= 5);
    }
    else {
        _22524 = binary_op(GREATEREQ, _22523, 5);
    }
    _22523 = NOVALUE;
    if (IS_ATOM_INT(_22524)) {
        if (_22524 == 0) {
            DeRef(_22525);
            _22525 = 0;
            goto L3; // [56] 116
        }
    }
    else {
        if (DBL_PTR(_22524)->dbl == 0.0) {
            DeRef(_22525);
            _22525 = 0;
            goto L3; // [56] 116
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22526 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22526)) {
        _22527 = (_22526 <= 6);
    }
    else {
        _22527 = binary_op(LESSEQ, _22526, 6);
    }
    _22526 = NOVALUE;
    if (IS_ATOM_INT(_22527)) {
        if (_22527 != 0) {
            DeRef(_22528);
            _22528 = 1;
            goto L4; // [72] 92
        }
    }
    else {
        if (DBL_PTR(_22527)->dbl != 0.0) {
            DeRef(_22528);
            _22528 = 1;
            goto L4; // [72] 92
        }
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22529 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22529)) {
        _22530 = (_22529 == 11);
    }
    else {
        _22530 = binary_op(EQUALS, _22529, 11);
    }
    _22529 = NOVALUE;
    DeRef(_22528);
    if (IS_ATOM_INT(_22530))
    _22528 = (_22530 != 0);
    else
    _22528 = DBL_PTR(_22530)->dbl != 0.0;
L4: 
    if (_22528 != 0) {
        _22531 = 1;
        goto L5; // [92] 112
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22532 = (int)*(((s1_ptr)_2)->base + 4);
    if (IS_ATOM_INT(_22532)) {
        _22533 = (_22532 == 13);
    }
    else {
        _22533 = binary_op(EQUALS, _22532, 13);
    }
    _22532 = NOVALUE;
    if (IS_ATOM_INT(_22533))
    _22531 = (_22533 != 0);
    else
    _22531 = DBL_PTR(_22533)->dbl != 0.0;
L5: 
    DeRef(_22525);
    _22525 = (_22531 != 0);
L3: 
    if (_22525 == 0) {
        _22534 = 0;
        goto L6; // [116] 136
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22535 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22535)) {
        _22536 = (_22535 != 0);
    }
    else {
        _22536 = binary_op(NOTEQ, _22535, 0);
    }
    _22535 = NOVALUE;
    if (IS_ATOM_INT(_22536))
    _22534 = (_22536 != 0);
    else
    _22534 = DBL_PTR(_22536)->dbl != 0.0;
L6: 
    if (_22534 == 0) {
        _22537 = 0;
        goto L7; // [136] 156
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22538 = (int)*(((s1_ptr)_2)->base + 5);
    if (IS_ATOM_INT(_22538)) {
        _22539 = (_22538 != 99);
    }
    else {
        _22539 = binary_op(NOTEQ, _22538, 99);
    }
    _22538 = NOVALUE;
    if (IS_ATOM_INT(_22539))
    _22537 = (_22539 != 0);
    else
    _22537 = DBL_PTR(_22539)->dbl != 0.0;
L7: 
    if (_22537 == 0) {
        goto L8; // [156] 300
    }
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22541 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22541 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _22542 = find_from(_22541, _28RTN_TOKS_11302, 1);
    _22541 = NOVALUE;
    _22543 = (_22542 == 0);
    _22542 = NOVALUE;
    if (_22543 == 0)
    {
        DeRef(_22543);
        _22543 = NOVALUE;
        goto L8; // [177] 300
    }
    else{
        DeRef(_22543);
        _22543 = NOVALUE;
    }

    /** 			if eentry[S_TOKEN] = PROC then*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22544 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22544 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    if (binary_op_a(NOTEQ, _22544, 27)){
        _22544 = NOVALUE;
        goto L9; // [190] 202
    }
    _22544 = NOVALUE;

    /** 				c_puts( "void ")*/
    RefDS(_22546);
    _53c_puts(_22546);
    goto LA; // [199] 208
L9: 

    /** 				c_puts("int ")*/
    RefDS(_22547);
    _53c_puts(_22547);
LA: 

    /** 			c_printf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22548 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22548 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    RefDS(_21922);
    Ref(_22548);
    _53c_printf(_21922, _22548);
    _22548 = NOVALUE;

    /** 			c_puts(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22549 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22549 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_22549);
    _53c_puts(_22549);
    _22549 = NOVALUE;

    /** 			if integer( eentry[S_OBJ] ) then*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22550 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_22550))
    _22551 = 1;
    else if (IS_ATOM_DBL(_22550))
    _22551 = IS_ATOM_INT(DoubleToInt(_22550));
    else
    _22551 = 0;
    _22550 = NOVALUE;
    if (_22551 == 0)
    {
        _22551 = NOVALUE;
        goto LB; // [242] 260
    }
    else{
        _22551 = NOVALUE;
    }

    /** 					c_printf(" = %d;\n", eentry[S_OBJ] )*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    _22553 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_22552);
    Ref(_22553);
    _53c_printf(_22552, _22553);
    _22553 = NOVALUE;
    goto LC; // [257] 266
LB: 

    /** 				c_puts(" = NOVALUE;\n")*/
    RefDS(_22554);
    _53c_puts(_22554);
LC: 

    /** 			c_hputs("extern int ")*/
    RefDS(_22555);
    _53c_hputs(_22555);

    /** 			c_hprintf("_%d", eentry[S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22556 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22556 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    RefDS(_21922);
    Ref(_22556);
    _53c_hprintf(_21922, _22556);
    _22556 = NOVALUE;

    /** 			c_hputs(eentry[S_NAME])*/
    _2 = (int)SEQ_PTR(_eentry_42260);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22557 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22557 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    Ref(_22557);
    _53c_hputs(_22557);
    _22557 = NOVALUE;

    /** 			c_hputs(";\n")*/
    RefDS(_22059);
    _53c_hputs(_22059);
L8: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22558 = (int)*(((s1_ptr)_2)->base + _s_42258);
    _2 = (int)SEQ_PTR(_22558);
    _s_42258 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42258)){
        _s_42258 = (long)DBL_PTR(_s_42258)->dbl;
    }
    _22558 = NOVALUE;

    /** 	end while*/
    goto L1; // [318] 29
L2: 

    /** 	c_puts("\n")*/
    RefDS(_21981);
    _53c_puts(_21981);

    /** 	c_hputs("\n")*/
    RefDS(_21981);
    _53c_hputs(_21981);

    /** end procedure*/
    DeRef(_eentry_42260);
    DeRef(_22524);
    _22524 = NOVALUE;
    DeRef(_22527);
    _22527 = NOVALUE;
    DeRef(_22530);
    _22530 = NOVALUE;
    DeRef(_22533);
    _22533 = NOVALUE;
    DeRef(_22536);
    _22536 = NOVALUE;
    DeRef(_22539);
    _22539 = NOVALUE;
    return;
    ;
}


int _56PromoteTypeInfo()
{
    int _updsym_42352 = NOVALUE;
    int _s_42354 = NOVALUE;
    int _sym_42355 = NOVALUE;
    int _symo_42356 = NOVALUE;
    int _upd_42585 = NOVALUE;
    int _22658 = NOVALUE;
    int _22656 = NOVALUE;
    int _22655 = NOVALUE;
    int _22654 = NOVALUE;
    int _22653 = NOVALUE;
    int _22651 = NOVALUE;
    int _22649 = NOVALUE;
    int _22648 = NOVALUE;
    int _22647 = NOVALUE;
    int _22646 = NOVALUE;
    int _22645 = NOVALUE;
    int _22641 = NOVALUE;
    int _22638 = NOVALUE;
    int _22637 = NOVALUE;
    int _22636 = NOVALUE;
    int _22635 = NOVALUE;
    int _22634 = NOVALUE;
    int _22633 = NOVALUE;
    int _22632 = NOVALUE;
    int _22631 = NOVALUE;
    int _22630 = NOVALUE;
    int _22629 = NOVALUE;
    int _22628 = NOVALUE;
    int _22626 = NOVALUE;
    int _22625 = NOVALUE;
    int _22624 = NOVALUE;
    int _22623 = NOVALUE;
    int _22622 = NOVALUE;
    int _22621 = NOVALUE;
    int _22620 = NOVALUE;
    int _22619 = NOVALUE;
    int _22618 = NOVALUE;
    int _22617 = NOVALUE;
    int _22615 = NOVALUE;
    int _22614 = NOVALUE;
    int _22613 = NOVALUE;
    int _22611 = NOVALUE;
    int _22610 = NOVALUE;
    int _22609 = NOVALUE;
    int _22607 = NOVALUE;
    int _22606 = NOVALUE;
    int _22605 = NOVALUE;
    int _22604 = NOVALUE;
    int _22603 = NOVALUE;
    int _22602 = NOVALUE;
    int _22601 = NOVALUE;
    int _22599 = NOVALUE;
    int _22598 = NOVALUE;
    int _22597 = NOVALUE;
    int _22596 = NOVALUE;
    int _22594 = NOVALUE;
    int _22593 = NOVALUE;
    int _22591 = NOVALUE;
    int _22590 = NOVALUE;
    int _22589 = NOVALUE;
    int _22588 = NOVALUE;
    int _22587 = NOVALUE;
    int _22586 = NOVALUE;
    int _22585 = NOVALUE;
    int _22583 = NOVALUE;
    int _22582 = NOVALUE;
    int _22581 = NOVALUE;
    int _22580 = NOVALUE;
    int _22579 = NOVALUE;
    int _22578 = NOVALUE;
    int _22577 = NOVALUE;
    int _22576 = NOVALUE;
    int _22575 = NOVALUE;
    int _22574 = NOVALUE;
    int _22573 = NOVALUE;
    int _22572 = NOVALUE;
    int _22571 = NOVALUE;
    int _22570 = NOVALUE;
    int _22568 = NOVALUE;
    int _22567 = NOVALUE;
    int _22566 = NOVALUE;
    int _22564 = NOVALUE;
    int _22563 = NOVALUE;
    int _22560 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	sequence sym, symo*/

    /** 	updsym = 0*/
    _updsym_42352 = 0;

    /** 	g_has_delete = p_has_delete*/
    _56g_has_delete_41538 = _56p_has_delete_41539;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22560 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_22560);
    _s_42354 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42354)){
        _s_42354 = (long)DBL_PTR(_s_42354)->dbl;
    }
    _22560 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42354 == 0)
    {
        goto L2; // [38] 921
    }
    else{
    }

    /** 		sym = SymTab[s]*/
    DeRef(_sym_42355);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _sym_42355 = (int)*(((s1_ptr)_2)->base + _s_42354);
    Ref(_sym_42355);

    /** 		symo = sym*/
    RefDS(_sym_42355);
    DeRef(_symo_42356);
    _symo_42356 = _sym_42355;

    /** 		if sym[S_TOKEN] = FUNC or sym[S_TOKEN] = TYPE then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22563 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22563 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    if (IS_ATOM_INT(_22563)) {
        _22564 = (_22563 == 501);
    }
    else {
        _22564 = binary_op(EQUALS, _22563, 501);
    }
    _22563 = NOVALUE;
    if (IS_ATOM_INT(_22564)) {
        if (_22564 != 0) {
            goto L3; // [72] 93
        }
    }
    else {
        if (DBL_PTR(_22564)->dbl != 0.0) {
            goto L3; // [72] 93
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22566 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22566 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    if (IS_ATOM_INT(_22566)) {
        _22567 = (_22566 == 504);
    }
    else {
        _22567 = binary_op(EQUALS, _22566, 504);
    }
    _22566 = NOVALUE;
    if (_22567 == 0) {
        DeRef(_22567);
        _22567 = NOVALUE;
        goto L4; // [89] 138
    }
    else {
        if (!IS_ATOM_INT(_22567) && DBL_PTR(_22567)->dbl == 0.0){
            DeRef(_22567);
            _22567 = NOVALUE;
            goto L4; // [89] 138
        }
        DeRef(_22567);
        _22567 = NOVALUE;
    }
    DeRef(_22567);
    _22567 = NOVALUE;
L3: 

    /** 			if sym[S_GTYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22568 = (int)*(((s1_ptr)_2)->base + 38);
    if (binary_op_a(NOTEQ, _22568, 0)){
        _22568 = NOVALUE;
        goto L5; // [103] 120
    }
    _22568 = NOVALUE;

    /** 				sym[S_GTYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L6; // [117] 549
L5: 

    /** 				sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22570 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22570);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22570;
    if( _1 != _22570 ){
        DeRef(_1);
    }
    _22570 = NOVALUE;
    goto L6; // [135] 549
L4: 

    /** 			if sym[S_GTYPE] != TYPE_INTEGER and*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22571 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22571)) {
        _22572 = (_22571 != 1);
    }
    else {
        _22572 = binary_op(NOTEQ, _22571, 1);
    }
    _22571 = NOVALUE;
    if (IS_ATOM_INT(_22572)) {
        if (_22572 == 0) {
            DeRef(_22573);
            _22573 = 0;
            goto L7; // [152] 172
        }
    }
    else {
        if (DBL_PTR(_22572)->dbl == 0.0) {
            DeRef(_22573);
            _22573 = 0;
            goto L7; // [152] 172
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22574 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22574)) {
        _22575 = (_22574 != 16);
    }
    else {
        _22575 = binary_op(NOTEQ, _22574, 16);
    }
    _22574 = NOVALUE;
    DeRef(_22573);
    if (IS_ATOM_INT(_22575))
    _22573 = (_22575 != 0);
    else
    _22573 = DBL_PTR(_22575)->dbl != 0.0;
L7: 
    if (_22573 == 0) {
        goto L8; // [172] 283
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22577 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22577)) {
        _22578 = (_22577 != 0);
    }
    else {
        _22578 = binary_op(NOTEQ, _22577, 0);
    }
    _22577 = NOVALUE;
    if (_22578 == 0) {
        DeRef(_22578);
        _22578 = NOVALUE;
        goto L8; // [189] 283
    }
    else {
        if (!IS_ATOM_INT(_22578) && DBL_PTR(_22578)->dbl == 0.0){
            DeRef(_22578);
            _22578 = NOVALUE;
            goto L8; // [189] 283
        }
        DeRef(_22578);
        _22578 = NOVALUE;
    }
    DeRef(_22578);
    _22578 = NOVALUE;

    /** 				if sym[S_GTYPE_NEW] = TYPE_INTEGER or*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22579 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22579)) {
        _22580 = (_22579 == 1);
    }
    else {
        _22580 = binary_op(EQUALS, _22579, 1);
    }
    _22579 = NOVALUE;
    if (IS_ATOM_INT(_22580)) {
        if (_22580 != 0) {
            DeRef(_22581);
            _22581 = 1;
            goto L9; // [206] 226
        }
    }
    else {
        if (DBL_PTR(_22580)->dbl != 0.0) {
            DeRef(_22581);
            _22581 = 1;
            goto L9; // [206] 226
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22582 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22582)) {
        _22583 = (_22582 == 16);
    }
    else {
        _22583 = binary_op(EQUALS, _22582, 16);
    }
    _22582 = NOVALUE;
    DeRef(_22581);
    if (IS_ATOM_INT(_22583))
    _22581 = (_22583 != 0);
    else
    _22581 = DBL_PTR(_22583)->dbl != 0.0;
L9: 
    if (_22581 != 0) {
        goto LA; // [226] 267
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22585 = (int)*(((s1_ptr)_2)->base + 36);
    if (IS_ATOM_INT(_22585)) {
        _22586 = (_22585 == 4);
    }
    else {
        _22586 = binary_op(EQUALS, _22585, 4);
    }
    _22585 = NOVALUE;
    if (IS_ATOM_INT(_22586)) {
        if (_22586 == 0) {
            DeRef(_22587);
            _22587 = 0;
            goto LB; // [242] 262
        }
    }
    else {
        if (DBL_PTR(_22586)->dbl == 0.0) {
            DeRef(_22587);
            _22587 = 0;
            goto LB; // [242] 262
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22588 = (int)*(((s1_ptr)_2)->base + 38);
    if (IS_ATOM_INT(_22588)) {
        _22589 = (_22588 == 2);
    }
    else {
        _22589 = binary_op(EQUALS, _22588, 2);
    }
    _22588 = NOVALUE;
    DeRef(_22587);
    if (IS_ATOM_INT(_22589))
    _22587 = (_22589 != 0);
    else
    _22587 = DBL_PTR(_22589)->dbl != 0.0;
LB: 
    if (_22587 == 0)
    {
        _22587 = NOVALUE;
        goto LC; // [263] 282
    }
    else{
        _22587 = NOVALUE;
    }
LA: 

    /** 						sym[S_GTYPE] = sym[S_GTYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22590 = (int)*(((s1_ptr)_2)->base + 38);
    Ref(_22590);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 36);
    _1 = *(int *)_2;
    *(int *)_2 = _22590;
    if( _1 != _22590 ){
        DeRef(_1);
    }
    _22590 = NOVALUE;
LC: 
L8: 

    /** 			if sym[S_ARG_TYPE_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22591 = (int)*(((s1_ptr)_2)->base + 44);
    if (binary_op_a(NOTEQ, _22591, 0)){
        _22591 = NOVALUE;
        goto LD; // [293] 310
    }
    _22591 = NOVALUE;

    /** 				sym[S_ARG_TYPE] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto LE; // [307] 325
LD: 

    /** 				sym[S_ARG_TYPE] = sym[S_ARG_TYPE_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22593 = (int)*(((s1_ptr)_2)->base + 44);
    Ref(_22593);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 43);
    _1 = *(int *)_2;
    *(int *)_2 = _22593;
    if( _1 != _22593 ){
        DeRef(_1);
    }
    _22593 = NOVALUE;
LE: 

    /** 			sym[S_ARG_TYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 44);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22594 = (int)*(((s1_ptr)_2)->base + 46);
    if (binary_op_a(NOTEQ, _22594, 0)){
        _22594 = NOVALUE;
        goto LF; // [345] 362
    }
    _22594 = NOVALUE;

    /** 				sym[S_ARG_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L10; // [359] 377
LF: 

    /** 				sym[S_ARG_SEQ_ELEM] = sym[S_ARG_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22596 = (int)*(((s1_ptr)_2)->base + 46);
    Ref(_22596);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 45);
    _1 = *(int *)_2;
    *(int *)_2 = _22596;
    if( _1 != _22596 ){
        DeRef(_1);
    }
    _22596 = NOVALUE;
L10: 

    /** 			sym[S_ARG_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 46);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 			if sym[S_ARG_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22597 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22598 = (int)NewDouble((double)-0xC0000000);
        else
        _22598 = - _12NOVALUE_11536;
    }
    else {
        _22598 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (IS_ATOM_INT(_22597) && IS_ATOM_INT(_22598)) {
        _22599 = (_22597 == _22598);
    }
    else {
        _22599 = binary_op(EQUALS, _22597, _22598);
    }
    _22597 = NOVALUE;
    DeRef(_22598);
    _22598 = NOVALUE;
    if (IS_ATOM_INT(_22599)) {
        if (_22599 != 0) {
            goto L11; // [404] 425
        }
    }
    else {
        if (DBL_PTR(_22599)->dbl != 0.0) {
            goto L11; // [404] 425
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22601 = (int)*(((s1_ptr)_2)->base + 49);
    if (IS_ATOM_INT(_22601) && IS_ATOM_INT(_12NOVALUE_11536)) {
        _22602 = (_22601 == _12NOVALUE_11536);
    }
    else {
        _22602 = binary_op(EQUALS, _22601, _12NOVALUE_11536);
    }
    _22601 = NOVALUE;
    if (_22602 == 0) {
        DeRef(_22602);
        _22602 = NOVALUE;
        goto L12; // [421] 448
    }
    else {
        if (!IS_ATOM_INT(_22602) && DBL_PTR(_22602)->dbl == 0.0){
            DeRef(_22602);
            _22602 = NOVALUE;
            goto L12; // [421] 448
        }
        DeRef(_22602);
        _22602 = NOVALUE;
    }
    DeRef(_22602);
    _22602 = NOVALUE;
L11: 

    /** 				sym[S_ARG_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_ARG_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L13; // [445] 477
L12: 

    /** 				sym[S_ARG_MIN] = sym[S_ARG_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22603 = (int)*(((s1_ptr)_2)->base + 49);
    Ref(_22603);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 47);
    _1 = *(int *)_2;
    *(int *)_2 = _22603;
    if( _1 != _22603 ){
        DeRef(_1);
    }
    _22603 = NOVALUE;

    /** 				sym[S_ARG_MAX] = sym[S_ARG_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22604 = (int)*(((s1_ptr)_2)->base + 50);
    Ref(_22604);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 48);
    _1 = *(int *)_2;
    *(int *)_2 = _22604;
    if( _1 != _22604 ){
        DeRef(_1);
    }
    _22604 = NOVALUE;
L13: 

    /** 			sym[S_ARG_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22605 = (int)NewDouble((double)-0xC0000000);
        else
        _22605 = - _12NOVALUE_11536;
    }
    else {
        _22605 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 49);
    _1 = *(int *)_2;
    *(int *)_2 = _22605;
    if( _1 != _22605 ){
        DeRef(_1);
    }
    _22605 = NOVALUE;

    /** 			if sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22606 = (int)*(((s1_ptr)_2)->base + 52);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22607 = (int)NewDouble((double)-0xC0000000);
        else
        _22607 = - _12NOVALUE_11536;
    }
    else {
        _22607 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (binary_op_a(NOTEQ, _22606, _22607)){
        _22606 = NOVALUE;
        DeRef(_22607);
        _22607 = NOVALUE;
        goto L14; // [503] 520
    }
    _22606 = NOVALUE;
    DeRef(_22607);
    _22607 = NOVALUE;

    /** 				sym[S_ARG_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L15; // [517] 535
L14: 

    /** 				sym[S_ARG_SEQ_LEN] = sym[S_ARG_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22609 = (int)*(((s1_ptr)_2)->base + 52);
    Ref(_22609);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 51);
    _1 = *(int *)_2;
    *(int *)_2 = _22609;
    if( _1 != _22609 ){
        DeRef(_1);
    }
    _22609 = NOVALUE;
L15: 

    /** 			sym[S_ARG_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22610 = (int)NewDouble((double)-0xC0000000);
        else
        _22610 = - _12NOVALUE_11536;
    }
    else {
        _22610 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 52);
    _1 = *(int *)_2;
    *(int *)_2 = _22610;
    if( _1 != _22610 ){
        DeRef(_1);
    }
    _22610 = NOVALUE;
L6: 

    /** 		sym[S_GTYPE_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 38);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_ELEM_NEW] = TYPE_NULL then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22611 = (int)*(((s1_ptr)_2)->base + 40);
    if (binary_op_a(NOTEQ, _22611, 0)){
        _22611 = NOVALUE;
        goto L16; // [569] 586
    }
    _22611 = NOVALUE;

    /** 		   sym[S_SEQ_ELEM] = TYPE_OBJECT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = 16;
    DeRef(_1);
    goto L17; // [583] 601
L16: 

    /** 			sym[S_SEQ_ELEM] = sym[S_SEQ_ELEM_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22613 = (int)*(((s1_ptr)_2)->base + 40);
    Ref(_22613);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 33);
    _1 = *(int *)_2;
    *(int *)_2 = _22613;
    if( _1 != _22613 ){
        DeRef(_1);
    }
    _22613 = NOVALUE;
L17: 

    /** 		sym[S_SEQ_ELEM_NEW] = TYPE_NULL*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 40);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if sym[S_SEQ_LEN_NEW] = -NOVALUE then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22614 = (int)*(((s1_ptr)_2)->base + 39);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22615 = (int)NewDouble((double)-0xC0000000);
        else
        _22615 = - _12NOVALUE_11536;
    }
    else {
        _22615 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (binary_op_a(NOTEQ, _22614, _22615)){
        _22614 = NOVALUE;
        DeRef(_22615);
        _22615 = NOVALUE;
        goto L18; // [624] 641
    }
    _22614 = NOVALUE;
    DeRef(_22615);
    _22615 = NOVALUE;

    /** 			sym[S_SEQ_LEN] = NOVALUE*/
    Ref(_12NOVALUE_11536);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _12NOVALUE_11536;
    DeRef(_1);
    goto L19; // [638] 656
L18: 

    /** 			sym[S_SEQ_LEN] = sym[S_SEQ_LEN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22617 = (int)*(((s1_ptr)_2)->base + 39);
    Ref(_22617);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 32);
    _1 = *(int *)_2;
    *(int *)_2 = _22617;
    if( _1 != _22617 ){
        DeRef(_1);
    }
    _22617 = NOVALUE;
L19: 

    /** 		sym[S_SEQ_LEN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22618 = (int)NewDouble((double)-0xC0000000);
        else
        _22618 = - _12NOVALUE_11536;
    }
    else {
        _22618 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 39);
    _1 = *(int *)_2;
    *(int *)_2 = _22618;
    if( _1 != _22618 ){
        DeRef(_1);
    }
    _22618 = NOVALUE;

    /** 		if sym[S_TOKEN] != NAMESPACE*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22619 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22619 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    if (IS_ATOM_INT(_22619)) {
        _22620 = (_22619 != 523);
    }
    else {
        _22620 = binary_op(NOTEQ, _22619, 523);
    }
    _22619 = NOVALUE;
    if (IS_ATOM_INT(_22620)) {
        if (_22620 == 0) {
            goto L1A; // [683] 794
        }
    }
    else {
        if (DBL_PTR(_22620)->dbl == 0.0) {
            goto L1A; // [683] 794
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22622 = (int)*(((s1_ptr)_2)->base + 3);
    if (IS_ATOM_INT(_22622)) {
        _22623 = (_22622 != 2);
    }
    else {
        _22623 = binary_op(NOTEQ, _22622, 2);
    }
    _22622 = NOVALUE;
    if (_22623 == 0) {
        DeRef(_22623);
        _22623 = NOVALUE;
        goto L1A; // [700] 794
    }
    else {
        if (!IS_ATOM_INT(_22623) && DBL_PTR(_22623)->dbl == 0.0){
            DeRef(_22623);
            _22623 = NOVALUE;
            goto L1A; // [700] 794
        }
        DeRef(_22623);
        _22623 = NOVALUE;
    }
    DeRef(_22623);
    _22623 = NOVALUE;

    /** 			if sym[S_OBJ_MIN_NEW] = -NOVALUE or*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22624 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22625 = (int)NewDouble((double)-0xC0000000);
        else
        _22625 = - _12NOVALUE_11536;
    }
    else {
        _22625 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    if (IS_ATOM_INT(_22624) && IS_ATOM_INT(_22625)) {
        _22626 = (_22624 == _22625);
    }
    else {
        _22626 = binary_op(EQUALS, _22624, _22625);
    }
    _22624 = NOVALUE;
    DeRef(_22625);
    _22625 = NOVALUE;
    if (IS_ATOM_INT(_22626)) {
        if (_22626 != 0) {
            goto L1B; // [720] 741
        }
    }
    else {
        if (DBL_PTR(_22626)->dbl != 0.0) {
            goto L1B; // [720] 741
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    _22628 = (int)*(((s1_ptr)_2)->base + 41);
    if (IS_ATOM_INT(_22628) && IS_ATOM_INT(_12NOVALUE_11536)) {
        _22629 = (_22628 == _12NOVALUE_11536);
    }
    else {
        _22629 = binary_op(EQUALS, _22628, _12NOVALUE_11536);
    }
    _22628 = NOVALUE;
    if (_22629 == 0) {
        DeRef(_22629);
        _22629 = NOVALUE;
        goto L1C; // [737] 764
    }
    else {
        if (!IS_ATOM_INT(_22629) && DBL_PTR(_22629)->dbl == 0.0){
            DeRef(_22629);
            _22629 = NOVALUE;
            goto L1C; // [737] 764
        }
        DeRef(_22629);
        _22629 = NOVALUE;
    }
    DeRef(_22629);
    _22629 = NOVALUE;
L1B: 

    /** 				sym[S_OBJ_MIN] = MININT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = -1073741824;
    DeRef(_1);

    /** 				sym[S_OBJ_MAX] = MAXINT*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = 1073741823;
    DeRef(_1);
    goto L1D; // [761] 793
L1C: 

    /** 				sym[S_OBJ_MIN] = sym[S_OBJ_MIN_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22630 = (int)*(((s1_ptr)_2)->base + 41);
    Ref(_22630);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 30);
    _1 = *(int *)_2;
    *(int *)_2 = _22630;
    if( _1 != _22630 ){
        DeRef(_1);
    }
    _22630 = NOVALUE;

    /** 				sym[S_OBJ_MAX] = sym[S_OBJ_MAX_NEW]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22631 = (int)*(((s1_ptr)_2)->base + 42);
    Ref(_22631);
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 31);
    _1 = *(int *)_2;
    *(int *)_2 = _22631;
    if( _1 != _22631 ){
        DeRef(_1);
    }
    _22631 = NOVALUE;
L1D: 
L1A: 

    /** 		sym[S_OBJ_MIN_NEW] = -NOVALUE*/
    if (IS_ATOM_INT(_12NOVALUE_11536)) {
        if ((unsigned long)_12NOVALUE_11536 == 0xC0000000)
        _22632 = (int)NewDouble((double)-0xC0000000);
        else
        _22632 = - _12NOVALUE_11536;
    }
    else {
        _22632 = unary_op(UMINUS, _12NOVALUE_11536);
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 41);
    _1 = *(int *)_2;
    *(int *)_2 = _22632;
    if( _1 != _22632 ){
        DeRef(_1);
    }
    _22632 = NOVALUE;

    /** 		if sym[S_NREFS] = 1 and*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22633 = (int)*(((s1_ptr)_2)->base + 12);
    if (IS_ATOM_INT(_22633)) {
        _22634 = (_22633 == 1);
    }
    else {
        _22634 = binary_op(EQUALS, _22633, 1);
    }
    _22633 = NOVALUE;
    if (IS_ATOM_INT(_22634)) {
        if (_22634 == 0) {
            goto L1E; // [819] 874
        }
    }
    else {
        if (DBL_PTR(_22634)->dbl == 0.0) {
            goto L1E; // [819] 874
        }
    }
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22636 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22636 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _22637 = find_from(_22636, _28RTN_TOKS_11302, 1);
    _22636 = NOVALUE;
    if (_22637 == 0)
    {
        _22637 = NOVALUE;
        goto L1E; // [837] 874
    }
    else{
        _22637 = NOVALUE;
    }

    /** 			if sym[S_USAGE] != U_DELETED then*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _22638 = (int)*(((s1_ptr)_2)->base + 5);
    if (binary_op_a(EQUALS, _22638, 99)){
        _22638 = NOVALUE;
        goto L1F; // [850] 873
    }
    _22638 = NOVALUE;

    /** 				sym[S_USAGE] = U_DELETED*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 5);
    _1 = *(int *)_2;
    *(int *)_2 = 99;
    DeRef(_1);

    /** 				deleted_routines += 1*/
    _56deleted_routines_42349 = _56deleted_routines_42349 + 1;
L1F: 
L1E: 

    /** 		sym[S_NREFS] = 0*/
    _2 = (int)SEQ_PTR(_sym_42355);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _sym_42355 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 0;
    DeRef(_1);

    /** 		if not equal(symo, sym) then*/
    if (_symo_42356 == _sym_42355)
    _22641 = 1;
    else if (IS_ATOM_INT(_symo_42356) && IS_ATOM_INT(_sym_42355))
    _22641 = 0;
    else
    _22641 = (compare(_symo_42356, _sym_42355) == 0);
    if (_22641 != 0)
    goto L20; // [888] 906
    _22641 = NOVALUE;

    /** 			SymTab[s] = sym*/
    RefDS(_sym_42355);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _s_42354);
    _1 = *(int *)_2;
    *(int *)_2 = _sym_42355;
    DeRef(_1);

    /** 			updsym += 1*/
    _updsym_42352 = _updsym_42352 + 1;
L20: 

    /** 		s = sym[S_NEXT]*/
    _2 = (int)SEQ_PTR(_sym_42355);
    _s_42354 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42354)){
        _s_42354 = (long)DBL_PTR(_s_42354)->dbl;
    }

    /** 	end while*/
    goto L1; // [918] 38
L2: 

    /** 	for i = 1 to length(temp_name_type) do*/
    if (IS_SEQUENCE(_12temp_name_type_11765)){
            _22645 = SEQ_PTR(_12temp_name_type_11765)->length;
    }
    else {
        _22645 = 1;
    }
    {
        int _i_42582;
        _i_42582 = 1;
L21: 
        if (_i_42582 > _22645){
            goto L22; // [928] 1061
        }

        /** 		integer upd = 0*/
        _upd_42585 = 0;

        /** 		if temp_name_type[i][T_GTYPE] != temp_name_type[i][T_GTYPE_NEW] then*/
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        _22646 = (int)*(((s1_ptr)_2)->base + _i_42582);
        _2 = (int)SEQ_PTR(_22646);
        _22647 = (int)*(((s1_ptr)_2)->base + 1);
        _22646 = NOVALUE;
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        _22648 = (int)*(((s1_ptr)_2)->base + _i_42582);
        _2 = (int)SEQ_PTR(_22648);
        _22649 = (int)*(((s1_ptr)_2)->base + 2);
        _22648 = NOVALUE;
        if (binary_op_a(EQUALS, _22647, _22649)){
            _22647 = NOVALUE;
            _22649 = NOVALUE;
            goto L23; // [966] 1003
        }
        _22647 = NOVALUE;
        _22649 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE] = temp_name_type[i][T_GTYPE_NEW]*/
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _12temp_name_type_11765 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42582 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        _22653 = (int)*(((s1_ptr)_2)->base + _i_42582);
        _2 = (int)SEQ_PTR(_22653);
        _22654 = (int)*(((s1_ptr)_2)->base + 2);
        _22653 = NOVALUE;
        Ref(_22654);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 1);
        _1 = *(int *)_2;
        *(int *)_2 = _22654;
        if( _1 != _22654 ){
            DeRef(_1);
        }
        _22654 = NOVALUE;
        _22651 = NOVALUE;

        /** 			upd = 1*/
        _upd_42585 = 1;
L23: 

        /** 		if temp_name_type[i][T_GTYPE_NEW] != TYPE_NULL then*/
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        _22655 = (int)*(((s1_ptr)_2)->base + _i_42582);
        _2 = (int)SEQ_PTR(_22655);
        _22656 = (int)*(((s1_ptr)_2)->base + 2);
        _22655 = NOVALUE;
        if (binary_op_a(EQUALS, _22656, 0)){
            _22656 = NOVALUE;
            goto L24; // [1019] 1046
        }
        _22656 = NOVALUE;

        /** 			temp_name_type[i][T_GTYPE_NEW] = TYPE_NULL*/
        _2 = (int)SEQ_PTR(_12temp_name_type_11765);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _12temp_name_type_11765 = MAKE_SEQ(_2);
        }
        _3 = (int)(_i_42582 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 2);
        _1 = *(int *)_2;
        *(int *)_2 = 0;
        DeRef(_1);
        _22658 = NOVALUE;

        /** 			upd = 1*/
        _upd_42585 = 1;
L24: 

        /** 		updsym += upd*/
        _updsym_42352 = _updsym_42352 + _upd_42585;

        /** 	end for*/
        _i_42582 = _i_42582 + 1;
        goto L21; // [1056] 935
L22: 
        ;
    }

    /** 	return updsym*/
    DeRef(_sym_42355);
    DeRef(_symo_42356);
    DeRef(_22564);
    _22564 = NOVALUE;
    DeRef(_22572);
    _22572 = NOVALUE;
    DeRef(_22575);
    _22575 = NOVALUE;
    DeRef(_22580);
    _22580 = NOVALUE;
    DeRef(_22583);
    _22583 = NOVALUE;
    DeRef(_22586);
    _22586 = NOVALUE;
    DeRef(_22589);
    _22589 = NOVALUE;
    DeRef(_22620);
    _22620 = NOVALUE;
    DeRef(_22599);
    _22599 = NOVALUE;
    DeRef(_22634);
    _22634 = NOVALUE;
    DeRef(_22626);
    _22626 = NOVALUE;
    return _updsym_42352;
    ;
}


void _56declare_prototype(int _s_42620)
{
    int _ret_type_42621 = NOVALUE;
    int _scope_42632 = NOVALUE;
    int _22678 = NOVALUE;
    int _22677 = NOVALUE;
    int _22675 = NOVALUE;
    int _22674 = NOVALUE;
    int _22673 = NOVALUE;
    int _22672 = NOVALUE;
    int _22670 = NOVALUE;
    int _22669 = NOVALUE;
    int _22668 = NOVALUE;
    int _22667 = NOVALUE;
    int _22666 = NOVALUE;
    int _22664 = NOVALUE;
    int _22663 = NOVALUE;
    int _22661 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sym_token( s ) = PROC then*/
    _22661 = _52sym_token(_s_42620);
    if (binary_op_a(NOTEQ, _22661, 27)){
        DeRef(_22661);
        _22661 = NOVALUE;
        goto L1; // [11] 25
    }
    DeRef(_22661);
    _22661 = NOVALUE;

    /** 		ret_type = "void "*/
    RefDS(_22546);
    DeRefi(_ret_type_42621);
    _ret_type_42621 = _22546;
    goto L2; // [22] 33
L1: 

    /** 		ret_type ="int "*/
    RefDS(_22547);
    DeRefi(_ret_type_42621);
    _ret_type_42621 = _22547;
L2: 

    /** 	c_hputs(ret_type)*/
    RefDS(_ret_type_42621);
    _53c_hputs(_ret_type_42621);

    /** 	if dll_option and TWINDOWS  then*/
    if (_56dll_option_41347 == 0) {
        goto L3; // [44] 116
    }
    goto L3; // [51] 116

    /** 		integer scope = SymTab[s][S_SCOPE]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22664 = (int)*(((s1_ptr)_2)->base + _s_42620);
    _2 = (int)SEQ_PTR(_22664);
    _scope_42632 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42632)){
        _scope_42632 = (long)DBL_PTR(_scope_42632)->dbl;
    }
    _22664 = NOVALUE;

    /** 		if (scope = SC_PUBLIC*/
    _22666 = (_scope_42632 == 13);
    if (_22666 != 0) {
        _22667 = 1;
        goto L4; // [78] 92
    }
    _22668 = (_scope_42632 == 11);
    _22667 = (_22668 != 0);
L4: 
    if (_22667 != 0) {
        DeRef(_22669);
        _22669 = 1;
        goto L5; // [92] 106
    }
    _22670 = (_scope_42632 == 6);
    _22669 = (_22670 != 0);
L5: 
    if (_22669 == 0)
    {
        _22669 = NOVALUE;
        goto L6; // [106] 115
    }
    else{
        _22669 = NOVALUE;
    }

    /** 			c_hputs("__stdcall ")*/
    RefDS(_22671);
    _53c_hputs(_22671);
L6: 
L3: 

    /** 	c_hprintf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22672 = (int)*(((s1_ptr)_2)->base + _s_42620);
    _2 = (int)SEQ_PTR(_22672);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22673 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22673 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22672 = NOVALUE;
    RefDS(_21922);
    Ref(_22673);
    _53c_hprintf(_21922, _22673);
    _22673 = NOVALUE;

    /** 	c_hputs(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22674 = (int)*(((s1_ptr)_2)->base + _s_42620);
    _2 = (int)SEQ_PTR(_22674);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22675 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22675 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22674 = NOVALUE;
    Ref(_22675);
    _53c_hputs(_22675);
    _22675 = NOVALUE;

    /** 	c_hputs("(")*/
    RefDS(_22676);
    _53c_hputs(_22676);

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22677 = (int)*(((s1_ptr)_2)->base + _s_42620);
    _2 = (int)SEQ_PTR(_22677);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _22678 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _22678 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _22677 = NOVALUE;
    {
        int _i_42661;
        _i_42661 = 1;
L7: 
        if (binary_op_a(GREATER, _i_42661, _22678)){
            goto L8; // [172] 206
        }

        /** 		if i = 1 then*/
        if (binary_op_a(NOTEQ, _i_42661, 1)){
            goto L9; // [181] 193
        }

        /** 			c_hputs("int")*/
        RefDS(_22680);
        _53c_hputs(_22680);
        goto LA; // [190] 199
L9: 

        /** 			c_hputs(", int")*/
        RefDS(_22681);
        _53c_hputs(_22681);
LA: 

        /** 	end for*/
        _0 = _i_42661;
        if (IS_ATOM_INT(_i_42661)) {
            _i_42661 = _i_42661 + 1;
            if ((long)((unsigned long)_i_42661 +(unsigned long) HIGH_BITS) >= 0){
                _i_42661 = NewDouble((double)_i_42661);
            }
        }
        else {
            _i_42661 = binary_op_a(PLUS, _i_42661, 1);
        }
        DeRef(_0);
        goto L7; // [201] 179
L8: 
        ;
        DeRef(_i_42661);
    }

    /** 	c_hputs(");\n")*/
    RefDS(_22091);
    _53c_hputs(_22091);

    /** end procedure*/
    DeRefi(_ret_type_42621);
    DeRef(_22666);
    _22666 = NOVALUE;
    DeRef(_22668);
    _22668 = NOVALUE;
    DeRef(_22670);
    _22670 = NOVALUE;
    _22678 = NOVALUE;
    return;
    ;
}


void _56add_to_routine_list(int _s_42677, int _seq_num_42678, int _first_42679)
{
    int _p_42754 = NOVALUE;
    int _22727 = NOVALUE;
    int _22725 = NOVALUE;
    int _22723 = NOVALUE;
    int _22721 = NOVALUE;
    int _22719 = NOVALUE;
    int _22718 = NOVALUE;
    int _22717 = NOVALUE;
    int _22715 = NOVALUE;
    int _22713 = NOVALUE;
    int _22711 = NOVALUE;
    int _22710 = NOVALUE;
    int _22708 = NOVALUE;
    int _22707 = NOVALUE;
    int _22703 = NOVALUE;
    int _22702 = NOVALUE;
    int _22701 = NOVALUE;
    int _22700 = NOVALUE;
    int _22699 = NOVALUE;
    int _22698 = NOVALUE;
    int _22697 = NOVALUE;
    int _22696 = NOVALUE;
    int _22695 = NOVALUE;
    int _22694 = NOVALUE;
    int _22692 = NOVALUE;
    int _22691 = NOVALUE;
    int _22690 = NOVALUE;
    int _22689 = NOVALUE;
    int _22686 = NOVALUE;
    int _22685 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	if not first then*/
    if (_first_42679 != 0)
    goto L1; // [9] 18

    /** 		c_puts(",\n")*/
    RefDS(_22683);
    _53c_puts(_22683);
L1: 

    /** 	c_puts("  {\"")*/
    RefDS(_22684);
    _53c_puts(_22684);

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22685 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22685);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22686 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22686 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22685 = NOVALUE;
    Ref(_22686);
    _53c_puts(_22686);
    _22686 = NOVALUE;

    /** 	c_puts("\", ")*/
    RefDS(_22687);
    _53c_puts(_22687);

    /** 	c_puts("(int (*)())")*/
    RefDS(_22688);
    _53c_puts(_22688);

    /** 	c_printf("_%d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22689 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22689);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22690 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22690 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22689 = NOVALUE;
    RefDS(_21922);
    Ref(_22690);
    _53c_printf(_21922, _22690);
    _22690 = NOVALUE;

    /** 	c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22691 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22691);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22692 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22692 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22691 = NOVALUE;
    Ref(_22692);
    _53c_puts(_22692);
    _22692 = NOVALUE;

    /** 	c_printf(", %d", seq_num)*/
    RefDS(_22693);
    _53c_printf(_22693, _seq_num_42678);

    /** 	c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22694 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22694);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22695 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22695 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22694 = NOVALUE;
    RefDS(_22693);
    Ref(_22695);
    _53c_printf(_22693, _22695);
    _22695 = NOVALUE;

    /** 	c_printf(", %d", SymTab[s][S_NUM_ARGS])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22696 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22696);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _22697 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _22697 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _22696 = NOVALUE;
    RefDS(_22693);
    Ref(_22697);
    _53c_printf(_22693, _22697);
    _22697 = NOVALUE;

    /** 	if TWINDOWS and dll_option and find( SymTab[s][S_SCOPE], { SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) then*/
    if (0 == 0) {
        _22698 = 0;
        goto L2; // [131] 141
    }
    _22698 = (_56dll_option_41347 != 0);
L2: 
    if (_22698 == 0) {
        goto L3; // [141] 186
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22700 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22700);
    _22701 = (int)*(((s1_ptr)_2)->base + 4);
    _22700 = NOVALUE;
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 6;
    *((int *)(_2+8)) = 11;
    *((int *)(_2+12)) = 13;
    _22702 = MAKE_SEQ(_1);
    _22703 = find_from(_22701, _22702, 1);
    _22701 = NOVALUE;
    DeRefDS(_22702);
    _22702 = NOVALUE;
    if (_22703 == 0)
    {
        _22703 = NOVALUE;
        goto L3; // [175] 186
    }
    else{
        _22703 = NOVALUE;
    }

    /** 		c_puts(", 1")  -- must call with __stdcall convention*/
    RefDS(_22704);
    _53c_puts(_22704);
    goto L4; // [183] 192
L3: 

    /** 		c_puts(", 0")  -- default: call with normal or __cdecl convention*/
    RefDS(_22705);
    _53c_puts(_22705);
L4: 

    /** 	c_printf(", %d, 0", SymTab[s][S_SCOPE] )*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22707 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22707);
    _22708 = (int)*(((s1_ptr)_2)->base + 4);
    _22707 = NOVALUE;
    RefDS(_22706);
    Ref(_22708);
    _53c_printf(_22706, _22708);
    _22708 = NOVALUE;

    /** 	c_puts("}")*/
    RefDS(_22709);
    _53c_puts(_22709);

    /** 	if SymTab[s][S_NREFS] < 2 then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22710 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22710);
    _22711 = (int)*(((s1_ptr)_2)->base + 12);
    _22710 = NOVALUE;
    if (binary_op_a(GREATEREQ, _22711, 2)){
        _22711 = NOVALUE;
        goto L5; // [229] 249
    }
    _22711 = NOVALUE;

    /** 		SymTab[s][S_NREFS] = 2 --s->nrefs++*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _13SymTab_10636 = MAKE_SEQ(_2);
    }
    _3 = (int)(_s_42677 + ((s1_ptr)_2)->base);
    _2 = (int)SEQ_PTR(*(int *)_3);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        *(int *)_3 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 12);
    _1 = *(int *)_2;
    *(int *)_2 = 2;
    DeRef(_1);
    _22713 = NOVALUE;
L5: 

    /** 	symtab_index p = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22715 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22715);
    _p_42754 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_p_42754)){
        _p_42754 = (long)DBL_PTR(_p_42754)->dbl;
    }
    _22715 = NOVALUE;

    /** 	for i = 1 to SymTab[s][S_NUM_ARGS] do*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22717 = (int)*(((s1_ptr)_2)->base + _s_42677);
    _2 = (int)SEQ_PTR(_22717);
    if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
        _22718 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
    }
    else{
        _22718 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
    }
    _22717 = NOVALUE;
    {
        int _i_42760;
        _i_42760 = 1;
L6: 
        if (binary_op_a(GREATER, _i_42760, _22718)){
            goto L7; // [279] 377
        }

        /** 		SymTab[p][S_ARG_SEQ_ELEM_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42754 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 46);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22719 = NOVALUE;

        /** 		SymTab[p][S_ARG_TYPE_NEW] = TYPE_OBJECT*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42754 + ((s1_ptr)_2)->base);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 44);
        _1 = *(int *)_2;
        *(int *)_2 = 16;
        DeRef(_1);
        _22721 = NOVALUE;

        /** 		SymTab[p][S_ARG_MIN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42754 + ((s1_ptr)_2)->base);
        Ref(_12NOVALUE_11536);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 49);
        _1 = *(int *)_2;
        *(int *)_2 = _12NOVALUE_11536;
        DeRef(_1);
        _22723 = NOVALUE;

        /** 		SymTab[p][S_ARG_SEQ_LEN_NEW] = NOVALUE*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _13SymTab_10636 = MAKE_SEQ(_2);
        }
        _3 = (int)(_p_42754 + ((s1_ptr)_2)->base);
        Ref(_12NOVALUE_11536);
        _2 = (int)SEQ_PTR(*(int *)_3);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            *(int *)_3 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + 52);
        _1 = *(int *)_2;
        *(int *)_2 = _12NOVALUE_11536;
        DeRef(_1);
        _22725 = NOVALUE;

        /** 		p = SymTab[p][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22727 = (int)*(((s1_ptr)_2)->base + _p_42754);
        _2 = (int)SEQ_PTR(_22727);
        _p_42754 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_p_42754)){
            _p_42754 = (long)DBL_PTR(_p_42754)->dbl;
        }
        _22727 = NOVALUE;

        /** 	end for*/
        _0 = _i_42760;
        if (IS_ATOM_INT(_i_42760)) {
            _i_42760 = _i_42760 + 1;
            if ((long)((unsigned long)_i_42760 +(unsigned long) HIGH_BITS) >= 0){
                _i_42760 = NewDouble((double)_i_42760);
            }
        }
        else {
            _i_42760 = binary_op_a(PLUS, _i_42760, 1);
        }
        DeRef(_0);
        goto L6; // [372] 286
L7: 
        ;
        DeRef(_i_42760);
    }

    /** end procedure*/
    _22718 = NOVALUE;
    return;
    ;
}


void _56DeclareRoutineList()
{
    int _s_42792 = NOVALUE;
    int _first_42793 = NOVALUE;
    int _seq_num_42794 = NOVALUE;
    int _these_routines_42802 = NOVALUE;
    int _these_routines_42824 = NOVALUE;
    int _22743 = NOVALUE;
    int _22742 = NOVALUE;
    int _22740 = NOVALUE;
    int _22738 = NOVALUE;
    int _22735 = NOVALUE;
    int _22734 = NOVALUE;
    int _22732 = NOVALUE;
    int _22730 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct routine_list _00[];\n")*/
    RefDS(_22729);
    _53c_hputs(_22729);

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_56file_routines_43378)){
            _22730 = SEQ_PTR(_56file_routines_43378)->length;
    }
    else {
        _22730 = 1;
    }
    {
        int _f_42799;
        _f_42799 = 1;
L1: 
        if (_f_42799 > _22730){
            goto L2; // [19] 98
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_42802);
        _2 = (int)SEQ_PTR(_56file_routines_43378);
        _these_routines_42802 = (int)*(((s1_ptr)_2)->base + _f_42799);
        Ref(_these_routines_42802);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_42802)){
                _22732 = SEQ_PTR(_these_routines_42802)->length;
        }
        else {
            _22732 = 1;
        }
        {
            int _r_42806;
            _r_42806 = 1;
L3: 
            if (_r_42806 > _22732){
                goto L4; // [41] 89
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_42802);
            _s_42792 = (int)*(((s1_ptr)_2)->base + _r_42806);
            if (!IS_ATOM_INT(_s_42792)){
                _s_42792 = (long)DBL_PTR(_s_42792)->dbl;
            }

            /** 			if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _22734 = (int)*(((s1_ptr)_2)->base + _s_42792);
            _2 = (int)SEQ_PTR(_22734);
            _22735 = (int)*(((s1_ptr)_2)->base + 5);
            _22734 = NOVALUE;
            if (binary_op_a(EQUALS, _22735, 99)){
                _22735 = NOVALUE;
                goto L5; // [72] 82
            }
            _22735 = NOVALUE;

            /** 				declare_prototype( s )*/
            _56declare_prototype(_s_42792);
L5: 

            /** 		end for*/
            _r_42806 = _r_42806 + 1;
            goto L3; // [84] 48
L4: 
            ;
        }
        DeRef(_these_routines_42802);
        _these_routines_42802 = NOVALUE;

        /** 	end for*/
        _f_42799 = _f_42799 + 1;
        goto L1; // [93] 26
L2: 
        ;
    }

    /** 	c_puts("\n")*/
    RefDS(_21981);
    _53c_puts(_21981);

    /** 	seq_num = 0*/
    _seq_num_42794 = 0;

    /** 	first = TRUE*/
    _first_42793 = _9TRUE_431;

    /** 	c_puts("struct routine_list _00[] = {\n")*/
    RefDS(_22737);
    _53c_puts(_22737);

    /** 	for f = 1 to length( file_routines ) do*/
    if (IS_SEQUENCE(_56file_routines_43378)){
            _22738 = SEQ_PTR(_56file_routines_43378)->length;
    }
    else {
        _22738 = 1;
    }
    {
        int _f_42821;
        _f_42821 = 1;
L6: 
        if (_f_42821 > _22738){
            goto L7; // [129] 222
        }

        /** 		sequence these_routines = file_routines[f]*/
        DeRef(_these_routines_42824);
        _2 = (int)SEQ_PTR(_56file_routines_43378);
        _these_routines_42824 = (int)*(((s1_ptr)_2)->base + _f_42821);
        Ref(_these_routines_42824);

        /** 		for r = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_42824)){
                _22740 = SEQ_PTR(_these_routines_42824)->length;
        }
        else {
            _22740 = 1;
        }
        {
            int _r_42828;
            _r_42828 = 1;
L8: 
            if (_r_42828 > _22740){
                goto L9; // [151] 213
            }

            /** 			s = these_routines[r]*/
            _2 = (int)SEQ_PTR(_these_routines_42824);
            _s_42792 = (int)*(((s1_ptr)_2)->base + _r_42828);
            if (!IS_ATOM_INT(_s_42792)){
                _s_42792 = (long)DBL_PTR(_s_42792)->dbl;
            }

            /** 			if SymTab[s][S_RI_TARGET] then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _22742 = (int)*(((s1_ptr)_2)->base + _s_42792);
            _2 = (int)SEQ_PTR(_22742);
            _22743 = (int)*(((s1_ptr)_2)->base + 53);
            _22742 = NOVALUE;
            if (_22743 == 0) {
                _22743 = NOVALUE;
                goto LA; // [180] 200
            }
            else {
                if (!IS_ATOM_INT(_22743) && DBL_PTR(_22743)->dbl == 0.0){
                    _22743 = NOVALUE;
                    goto LA; // [180] 200
                }
                _22743 = NOVALUE;
            }
            _22743 = NOVALUE;

            /** 				add_to_routine_list( s, seq_num, first )*/
            _56add_to_routine_list(_s_42792, _seq_num_42794, _first_42793);

            /** 				first = FALSE*/
            _first_42793 = _9FALSE_429;
LA: 

            /** 			seq_num += 1*/
            _seq_num_42794 = _seq_num_42794 + 1;

            /** 		end for*/
            _r_42828 = _r_42828 + 1;
            goto L8; // [208] 158
L9: 
            ;
        }
        DeRef(_these_routines_42824);
        _these_routines_42824 = NOVALUE;

        /** 	end for*/
        _f_42821 = _f_42821 + 1;
        goto L6; // [217] 136
L7: 
        ;
    }

    /** 	if not first then*/
    if (_first_42793 != 0)
    goto LB; // [224] 233

    /** 		c_puts(",\n")*/
    RefDS(_22683);
    _53c_puts(_22683);
LB: 

    /** 	c_puts("  {\"\", 0, 999999999, 0, 0, 0, 0}\n};\n\n")  -- end marker*/
    RefDS(_22746);
    _53c_puts(_22746);

    /** 	c_hputs("extern unsigned char ** _02;\n")*/
    RefDS(_22747);
    _53c_hputs(_22747);

    /** 	c_puts("unsigned char ** _02;\n")*/
    RefDS(_22748);
    _53c_puts(_22748);

    /** 	c_hputs("extern object _0switches;\n")*/
    RefDS(_22749);
    _53c_hputs(_22749);

    /** 	c_puts("object _0switches;\n")*/
    RefDS(_22750);
    _53c_puts(_22750);

    /** end procedure*/
    return;
    ;
}


void _56DeclareNameSpaceList()
{
    int _s_42854 = NOVALUE;
    int _first_42855 = NOVALUE;
    int _seq_num_42856 = NOVALUE;
    int _22770 = NOVALUE;
    int _22768 = NOVALUE;
    int _22767 = NOVALUE;
    int _22766 = NOVALUE;
    int _22765 = NOVALUE;
    int _22763 = NOVALUE;
    int _22762 = NOVALUE;
    int _22759 = NOVALUE;
    int _22758 = NOVALUE;
    int _22757 = NOVALUE;
    int _22756 = NOVALUE;
    int _22755 = NOVALUE;
    int _22753 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer first, seq_num*/

    /** 	c_hputs("extern struct ns_list _01[];\n")*/
    RefDS(_22751);
    _53c_hputs(_22751);

    /** 	c_puts("struct ns_list _01[] = {\n")*/
    RefDS(_22752);
    _53c_puts(_22752);

    /** 	seq_num = 0*/
    _seq_num_42856 = 0;

    /** 	first = TRUE*/
    _first_42855 = _9TRUE_431;

    /** 	s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22753 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_22753);
    _s_42854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42854)){
        _s_42854 = (long)DBL_PTR(_s_42854)->dbl;
    }
    _22753 = NOVALUE;

    /** 	while s do*/
L1: 
    if (_s_42854 == 0)
    {
        goto L2; // [50] 215
    }
    else{
    }

    /** 		if find(SymTab[s][S_TOKEN], NAMED_TOKS) then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22755 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22755);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22756 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22756 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _22755 = NOVALUE;
    _22757 = find_from(_22756, _28NAMED_TOKS_11304, 1);
    _22756 = NOVALUE;
    if (_22757 == 0)
    {
        _22757 = NOVALUE;
        goto L3; // [74] 194
    }
    else{
        _22757 = NOVALUE;
    }

    /** 			if SymTab[s][S_TOKEN] = NAMESPACE then*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22758 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22758);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _22759 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _22759 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _22758 = NOVALUE;
    if (binary_op_a(NOTEQ, _22759, 523)){
        _22759 = NOVALUE;
        goto L4; // [93] 187
    }
    _22759 = NOVALUE;

    /** 				if not first then*/
    if (_first_42855 != 0)
    goto L5; // [99] 108

    /** 					c_puts(",\n")*/
    RefDS(_22683);
    _53c_puts(_22683);
L5: 

    /** 				first = FALSE*/
    _first_42855 = _9FALSE_429;

    /** 				c_puts("  {\"")*/
    RefDS(_22684);
    _53c_puts(_22684);

    /** 				c_puts(SymTab[s][S_NAME])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22762 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22762);
    if (!IS_ATOM_INT(_12S_NAME_11354)){
        _22763 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
    }
    else{
        _22763 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
    }
    _22762 = NOVALUE;
    Ref(_22763);
    _53c_puts(_22763);
    _22763 = NOVALUE;

    /** 				c_printf("\", %d", SymTab[s][S_OBJ])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22765 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22765);
    _22766 = (int)*(((s1_ptr)_2)->base + 1);
    _22765 = NOVALUE;
    RefDS(_22764);
    Ref(_22766);
    _53c_printf(_22764, _22766);
    _22766 = NOVALUE;

    /** 				c_printf(", %d", seq_num)*/
    RefDS(_22693);
    _53c_printf(_22693, _seq_num_42856);

    /** 				c_printf(", %d", SymTab[s][S_FILE_NO])*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22767 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22767);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22768 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22768 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _22767 = NOVALUE;
    RefDS(_22693);
    Ref(_22768);
    _53c_printf(_22693, _22768);
    _22768 = NOVALUE;

    /** 				c_puts("}")*/
    RefDS(_22709);
    _53c_puts(_22709);
L4: 

    /** 			seq_num += 1*/
    _seq_num_42856 = _seq_num_42856 + 1;
L3: 

    /** 		s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _22770 = (int)*(((s1_ptr)_2)->base + _s_42854);
    _2 = (int)SEQ_PTR(_22770);
    _s_42854 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_42854)){
        _s_42854 = (long)DBL_PTR(_s_42854)->dbl;
    }
    _22770 = NOVALUE;

    /** 	end while*/
    goto L1; // [212] 50
L2: 

    /** 	if not first then*/
    if (_first_42855 != 0)
    goto L6; // [217] 226

    /** 		c_puts(",\n")*/
    RefDS(_22683);
    _53c_puts(_22683);
L6: 

    /** 	c_puts("  {\"\", 0, 999999999, 0}\n};\n\n")  -- end marker*/
    RefDS(_22773);
    _53c_puts(_22773);

    /** end procedure*/
    return;
    ;
}


int _56is_exported(int _s_42918)
{
    int _eentry_42919 = NOVALUE;
    int _scope_42922 = NOVALUE;
    int _22788 = NOVALUE;
    int _22787 = NOVALUE;
    int _22786 = NOVALUE;
    int _22785 = NOVALUE;
    int _22784 = NOVALUE;
    int _22783 = NOVALUE;
    int _22782 = NOVALUE;
    int _22781 = NOVALUE;
    int _22780 = NOVALUE;
    int _22779 = NOVALUE;
    int _22778 = NOVALUE;
    int _22776 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_s_42918)) {
        _1 = (long)(DBL_PTR(_s_42918)->dbl);
        DeRefDS(_s_42918);
        _s_42918 = _1;
    }

    /** 	sequence eentry = SymTab[s]*/
    DeRef(_eentry_42919);
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _eentry_42919 = (int)*(((s1_ptr)_2)->base + _s_42918);
    Ref(_eentry_42919);

    /** 	integer scope = eentry[S_SCOPE]*/
    _2 = (int)SEQ_PTR(_eentry_42919);
    _scope_42922 = (int)*(((s1_ptr)_2)->base + 4);
    if (!IS_ATOM_INT(_scope_42922))
    _scope_42922 = (long)DBL_PTR(_scope_42922)->dbl;

    /** 	if eentry[S_MODE] = M_NORMAL then*/
    _2 = (int)SEQ_PTR(_eentry_42919);
    _22776 = (int)*(((s1_ptr)_2)->base + 3);
    if (binary_op_a(NOTEQ, _22776, 1)){
        _22776 = NOVALUE;
        goto L1; // [31] 125
    }
    _22776 = NOVALUE;

    /** 		if eentry[S_FILE_NO] = 1 and find(scope, { SC_EXPORT, SC_PUBLIC, SC_GLOBAL }) then*/
    _2 = (int)SEQ_PTR(_eentry_42919);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22778 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22778 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    if (IS_ATOM_INT(_22778)) {
        _22779 = (_22778 == 1);
    }
    else {
        _22779 = binary_op(EQUALS, _22778, 1);
    }
    _22778 = NOVALUE;
    if (IS_ATOM_INT(_22779)) {
        if (_22779 == 0) {
            goto L2; // [47] 79
        }
    }
    else {
        if (DBL_PTR(_22779)->dbl == 0.0) {
            goto L2; // [47] 79
        }
    }
    _1 = NewS1(3);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 11;
    *((int *)(_2+8)) = 13;
    *((int *)(_2+12)) = 6;
    _22781 = MAKE_SEQ(_1);
    _22782 = find_from(_scope_42922, _22781, 1);
    DeRefDS(_22781);
    _22781 = NOVALUE;
    if (_22782 == 0)
    {
        _22782 = NOVALUE;
        goto L2; // [69] 79
    }
    else{
        _22782 = NOVALUE;
    }

    /** 			return 1*/
    DeRef(_eentry_42919);
    DeRef(_22779);
    _22779 = NOVALUE;
    return 1;
L2: 

    /** 		if scope = SC_PUBLIC and*/
    _22783 = (_scope_42922 == 13);
    if (_22783 == 0) {
        goto L3; // [87] 124
    }
    _2 = (int)SEQ_PTR(_13include_matrix_10643);
    _22785 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_eentry_42919);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _22786 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _22786 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _2 = (int)SEQ_PTR(_22785);
    if (!IS_ATOM_INT(_22786)){
        _22787 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_22786)->dbl));
    }
    else{
        _22787 = (int)*(((s1_ptr)_2)->base + _22786);
    }
    _22785 = NOVALUE;
    if (IS_ATOM_INT(_22787)) {
        {unsigned long tu;
             tu = (unsigned long)_22787 & (unsigned long)4;
             _22788 = MAKE_UINT(tu);
        }
    }
    else {
        _22788 = binary_op(AND_BITS, _22787, 4);
    }
    _22787 = NOVALUE;
    if (_22788 == 0) {
        DeRef(_22788);
        _22788 = NOVALUE;
        goto L3; // [114] 124
    }
    else {
        if (!IS_ATOM_INT(_22788) && DBL_PTR(_22788)->dbl == 0.0){
            DeRef(_22788);
            _22788 = NOVALUE;
            goto L3; // [114] 124
        }
        DeRef(_22788);
        _22788 = NOVALUE;
    }
    DeRef(_22788);
    _22788 = NOVALUE;

    /** 			return 1*/
    DeRef(_eentry_42919);
    DeRef(_22783);
    _22783 = NOVALUE;
    DeRef(_22779);
    _22779 = NOVALUE;
    _22786 = NOVALUE;
    return 1;
L3: 
L1: 

    /** 	return 0*/
    DeRef(_eentry_42919);
    DeRef(_22783);
    _22783 = NOVALUE;
    DeRef(_22779);
    _22779 = NOVALUE;
    _22786 = NOVALUE;
    return 0;
    ;
}


void _56version()
{
    int _22822 = NOVALUE;
    int _22821 = NOVALUE;
    int _0, _1, _2;
    

    /** 	c_puts("// Euphoria To C version " & version_string() & "\n")*/
    _22821 = _31version_string(0);
    {
        int concat_list[3];

        concat_list[0] = _21981;
        concat_list[1] = _22821;
        concat_list[2] = _22820;
        Concat_N((object_ptr)&_22822, concat_list, 3);
    }
    DeRef(_22821);
    _22821 = NOVALUE;
    _53c_puts(_22822);
    _22822 = NOVALUE;

    /** end procedure*/
    return;
    ;
}


void _56new_c_file(int _name_43026)
{
    int _22825 = NOVALUE;
    int _0, _1, _2;
    

    /** 	cfile_size = 0*/
    _12cfile_size_11762 = 0;

    /** 	if LAST_PASS = FALSE then*/
    if (_56LAST_PASS_41334 != _9FALSE_429)
    goto L1; // [16] 26

    /** 		return*/
    DeRefDS(_name_43026);
    return;
L1: 

    /** 	write_checksum( c_code )*/
    _54write_checksum(_53c_code_45138);

    /** 	close(c_code)*/
    EClose(_53c_code_45138);

    /** 	c_code = open(output_dir & name & ".c", "w")*/
    {
        int concat_list[3];

        concat_list[0] = _22824;
        concat_list[1] = _name_43026;
        concat_list[2] = _56output_dir_41360;
        Concat_N((object_ptr)&_22825, concat_list, 3);
    }
    _53c_code_45138 = EOpen(_22825, _21935, 0);
    DeRefDS(_22825);
    _22825 = NOVALUE;

    /** 	if c_code = -1 then*/
    if (_53c_code_45138 != -1)
    goto L2; // [60] 72

    /** 		CompileErr(57)*/
    RefDS(_21829);
    _43CompileErr(57, _21829, 0);
L2: 

    /** 	cfile_count += 1*/
    _12cfile_count_11761 = _12cfile_count_11761 + 1;

    /** 	version()*/
    _56version();

    /** 	c_puts("#include \"include/euphoria.h\"\n")*/
    RefDS(_21939);
    _53c_puts(_21939);

    /** 	c_puts("#include \"main-.h\"\n\n")*/
    RefDS(_21940);
    _53c_puts(_21940);

    /** 	if not TUNIX then*/
    if (_36TUNIX_14009 != 0)
    goto L3; // [100] 112

    /** 		name = lower(name)  -- for faster compare later*/
    RefDS(_name_43026);
    _0 = _name_43026;
    _name_43026 = _18lower(_name_43026);
    DeRefDS(_0);
L3: 

    /** end procedure*/
    DeRefDS(_name_43026);
    return;
    ;
}


int _56unique_c_name(int _name_43055)
{
    int _i_43056 = NOVALUE;
    int _compare_name_43057 = NOVALUE;
    int _next_fc_43058 = NOVALUE;
    int _22841 = NOVALUE;
    int _22839 = NOVALUE;
    int _22838 = NOVALUE;
    int _22837 = NOVALUE;
    int _22835 = NOVALUE;
    int _0, _1, _2;
    

    /** 	compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43057, _name_43055, _22824);

    /** 	if not TUNIX then*/
    if (_36TUNIX_14009 != 0)
    goto L1; // [13] 25

    /** 		compare_name = lower(compare_name)*/
    RefDS(_compare_name_43057);
    _0 = _compare_name_43057;
    _compare_name_43057 = _18lower(_compare_name_43057);
    DeRefDS(_0);
L1: 

    /** 	next_fc = 1*/
    _next_fc_43058 = 1;

    /** 	i = 1*/
    _i_43056 = 1;

    /** 	while i <= length(generated_files) do*/
L2: 
    if (IS_SEQUENCE(_56generated_files_41351)){
            _22835 = SEQ_PTR(_56generated_files_41351)->length;
    }
    else {
        _22835 = 1;
    }
    if (_i_43056 > _22835)
    goto L3; // [45] 139

    /** 		if equal(generated_files[i], compare_name) then*/
    _2 = (int)SEQ_PTR(_56generated_files_41351);
    _22837 = (int)*(((s1_ptr)_2)->base + _i_43056);
    if (_22837 == _compare_name_43057)
    _22838 = 1;
    else if (IS_ATOM_INT(_22837) && IS_ATOM_INT(_compare_name_43057))
    _22838 = 0;
    else
    _22838 = (compare(_22837, _compare_name_43057) == 0);
    _22837 = NOVALUE;
    if (_22838 == 0)
    {
        _22838 = NOVALUE;
        goto L4; // [61] 127
    }
    else{
        _22838 = NOVALUE;
    }

    /** 			if next_fc > length(file_chars) then*/
    if (IS_SEQUENCE(_56file_chars_43051)){
            _22839 = SEQ_PTR(_56file_chars_43051)->length;
    }
    else {
        _22839 = 1;
    }
    if (_next_fc_43058 <= _22839)
    goto L5; // [69] 81

    /** 				CompileErr(140)*/
    RefDS(_21829);
    _43CompileErr(140, _21829, 0);
L5: 

    /** 			name[1] = file_chars[next_fc]*/
    _2 = (int)SEQ_PTR(_56file_chars_43051);
    _22841 = (int)*(((s1_ptr)_2)->base + _next_fc_43058);
    Ref(_22841);
    _2 = (int)SEQ_PTR(_name_43055);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _name_43055 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _22841;
    if( _1 != _22841 ){
        DeRef(_1);
    }
    _22841 = NOVALUE;

    /** 			compare_name = name & ".c"*/
    Concat((object_ptr)&_compare_name_43057, _name_43055, _22824);

    /** 			if not TUNIX then*/
    if (_36TUNIX_14009 != 0)
    goto L6; // [101] 113

    /** 				compare_name = lower(compare_name)*/
    RefDS(_compare_name_43057);
    _0 = _compare_name_43057;
    _compare_name_43057 = _18lower(_compare_name_43057);
    DeRefDS(_0);
L6: 

    /** 			next_fc += 1*/
    _next_fc_43058 = _next_fc_43058 + 1;

    /** 			i = 1 -- start over and compare again*/
    _i_43056 = 1;
    goto L2; // [124] 40
L4: 

    /** 			i += 1*/
    _i_43056 = _i_43056 + 1;

    /** 	end while*/
    goto L2; // [136] 40
L3: 

    /** 	return name*/
    DeRef(_compare_name_43057);
    return _name_43055;
    ;
}


int _56is_file_newer(int _f1_43087, int _f2_43088)
{
    int _d1_43089 = NOVALUE;
    int _d2_43092 = NOVALUE;
    int _diff_2__tmp_at42_43103 = NOVALUE;
    int _diff_1__tmp_at42_43102 = NOVALUE;
    int _diff_inlined_diff_at_42_43101 = NOVALUE;
    int _22851 = NOVALUE;
    int _22849 = NOVALUE;
    int _0, _1, _2;
    

    /** 	object d1 = file_timestamp(f1)*/
    RefDS(_f1_43087);
    _0 = _d1_43089;
    _d1_43089 = _14file_timestamp(_f1_43087);
    DeRef(_0);

    /** 	object d2 = file_timestamp(f2)*/
    RefDS(_f2_43088);
    _0 = _d2_43092;
    _d2_43092 = _14file_timestamp(_f2_43088);
    DeRef(_0);

    /** 	if atom(d1) or atom(d2) then return 1 end if*/
    _22849 = IS_ATOM(_d1_43089);
    if (_22849 != 0) {
        goto L1; // [22] 34
    }
    _22851 = IS_ATOM(_d2_43092);
    if (_22851 == 0)
    {
        _22851 = NOVALUE;
        goto L2; // [30] 39
    }
    else{
        _22851 = NOVALUE;
    }
L1: 
    DeRefDS(_f1_43087);
    DeRefDS(_f2_43088);
    DeRef(_d1_43089);
    DeRef(_d2_43092);
    return 1;
L2: 

    /** 	if datetime:diff(d1, d2) < 0 then*/

    /** 	return datetimeToSeconds(dt2) - datetimeToSeconds(dt1)*/
    Ref(_d2_43092);
    _0 = _diff_1__tmp_at42_43102;
    _diff_1__tmp_at42_43102 = _15datetimeToSeconds(_d2_43092);
    DeRef(_0);
    Ref(_d1_43089);
    _0 = _diff_2__tmp_at42_43103;
    _diff_2__tmp_at42_43103 = _15datetimeToSeconds(_d1_43089);
    DeRef(_0);
    DeRef(_diff_inlined_diff_at_42_43101);
    if (IS_ATOM_INT(_diff_1__tmp_at42_43102) && IS_ATOM_INT(_diff_2__tmp_at42_43103)) {
        _diff_inlined_diff_at_42_43101 = _diff_1__tmp_at42_43102 - _diff_2__tmp_at42_43103;
        if ((long)((unsigned long)_diff_inlined_diff_at_42_43101 +(unsigned long) HIGH_BITS) >= 0){
            _diff_inlined_diff_at_42_43101 = NewDouble((double)_diff_inlined_diff_at_42_43101);
        }
    }
    else {
        _diff_inlined_diff_at_42_43101 = binary_op(MINUS, _diff_1__tmp_at42_43102, _diff_2__tmp_at42_43103);
    }
    DeRef(_diff_1__tmp_at42_43102);
    _diff_1__tmp_at42_43102 = NOVALUE;
    DeRef(_diff_2__tmp_at42_43103);
    _diff_2__tmp_at42_43103 = NOVALUE;
    if (binary_op_a(GREATEREQ, _diff_inlined_diff_at_42_43101, 0)){
        goto L3; // [58] 69
    }

    /** 		return 1*/
    DeRefDS(_f1_43087);
    DeRefDS(_f2_43088);
    DeRef(_d1_43089);
    DeRef(_d2_43092);
    return 1;
L3: 

    /** 	return 0*/
    DeRefDS(_f1_43087);
    DeRefDS(_f2_43088);
    DeRef(_d1_43089);
    DeRef(_d2_43092);
    return 0;
    ;
}


void _56add_file(int _filename_43107, int _eu_filename_43108)
{
    int _obj_fname_43128 = NOVALUE;
    int _src_fname_43129 = NOVALUE;
    int _22875 = NOVALUE;
    int _22874 = NOVALUE;
    int _22861 = NOVALUE;
    int _22860 = NOVALUE;
    int _22857 = NOVALUE;
    int _22856 = NOVALUE;
    int _22855 = NOVALUE;
    int _22854 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if equal("c", fileext(filename)) then*/
    RefDS(_filename_43107);
    _22854 = _14fileext(_filename_43107);
    if (_22853 == _22854)
    _22855 = 1;
    else if (IS_ATOM_INT(_22853) && IS_ATOM_INT(_22854))
    _22855 = 0;
    else
    _22855 = (compare(_22853, _22854) == 0);
    DeRef(_22854);
    _22854 = NOVALUE;
    if (_22855 == 0)
    {
        _22855 = NOVALUE;
        goto L1; // [15] 35
    }
    else{
        _22855 = NOVALUE;
    }

    /** 		filename = filename[1..$-2]*/
    if (IS_SEQUENCE(_filename_43107)){
            _22856 = SEQ_PTR(_filename_43107)->length;
    }
    else {
        _22856 = 1;
    }
    _22857 = _22856 - 2;
    _22856 = NOVALUE;
    rhs_slice_target = (object_ptr)&_filename_43107;
    RHS_Slice(_filename_43107, 1, _22857);
    goto L2; // [32] 82
L1: 

    /** 	elsif equal("h", fileext(filename)) then*/
    RefDS(_filename_43107);
    _22860 = _14fileext(_filename_43107);
    if (_22859 == _22860)
    _22861 = 1;
    else if (IS_ATOM_INT(_22859) && IS_ATOM_INT(_22860))
    _22861 = 0;
    else
    _22861 = (compare(_22859, _22860) == 0);
    DeRef(_22860);
    _22860 = NOVALUE;
    if (_22861 == 0)
    {
        _22861 = NOVALUE;
        goto L3; // [45] 81
    }
    else{
        _22861 = NOVALUE;
    }

    /** 		generated_files = append(generated_files, filename)*/
    RefDS(_filename_43107);
    Append(&_56generated_files_41351, _56generated_files_41351, _filename_43107);

    /** 		if build_system_type = BUILD_DIRECT then*/

    /** 			outdated_files  = append(outdated_files, 0)*/
    Append(&_56outdated_files_41352, _56outdated_files_41352, 0);

    /** 		return*/
    DeRefDS(_filename_43107);
    DeRefDS(_eu_filename_43108);
    DeRef(_obj_fname_43128);
    DeRef(_src_fname_43129);
    DeRef(_22857);
    _22857 = NOVALUE;
    return;
L3: 
L2: 

    /** 	sequence obj_fname = filename, src_fname = filename & ".c"*/
    RefDS(_filename_43107);
    DeRef(_obj_fname_43128);
    _obj_fname_43128 = _filename_43107;
    Concat((object_ptr)&_src_fname_43129, _filename_43107, _22824);

    /** 	if compiler_type = COMPILER_WATCOM then*/

    /** 		obj_fname &= ".o"*/
    Concat((object_ptr)&_obj_fname_43128, _obj_fname_43128, _22869);

    /** 	generated_files = append(generated_files, src_fname)*/
    RefDS(_src_fname_43129);
    Append(&_56generated_files_41351, _56generated_files_41351, _src_fname_43129);

    /** 	generated_files = append(generated_files, obj_fname)*/
    RefDS(_obj_fname_43128);
    Append(&_56generated_files_41351, _56generated_files_41351, _obj_fname_43128);

    /** 	if build_system_type = BUILD_DIRECT then*/

    /** 		outdated_files  = append(outdated_files, is_file_newer(eu_filename, output_dir & src_fname))*/
    Concat((object_ptr)&_22874, _56output_dir_41360, _src_fname_43129);
    RefDS(_eu_filename_43108);
    _22875 = _56is_file_newer(_eu_filename_43108, _22874);
    _22874 = NOVALUE;
    Ref(_22875);
    Append(&_56outdated_files_41352, _56outdated_files_41352, _22875);
    DeRef(_22875);
    _22875 = NOVALUE;

    /** 		outdated_files  = append(outdated_files, 0)*/
    Append(&_56outdated_files_41352, _56outdated_files_41352, 0);

    /** end procedure*/
    DeRefDS(_filename_43107);
    DeRefDS(_eu_filename_43108);
    DeRef(_obj_fname_43128);
    DeRef(_src_fname_43129);
    DeRef(_22857);
    _22857 = NOVALUE;
    return;
    ;
}


int _56any_code(int _file_no_43152)
{
    int _these_routines_43154 = NOVALUE;
    int _s_43161 = NOVALUE;
    int _22891 = NOVALUE;
    int _22890 = NOVALUE;
    int _22889 = NOVALUE;
    int _22888 = NOVALUE;
    int _22887 = NOVALUE;
    int _22886 = NOVALUE;
    int _22885 = NOVALUE;
    int _22884 = NOVALUE;
    int _22883 = NOVALUE;
    int _22882 = NOVALUE;
    int _22881 = NOVALUE;
    int _22879 = NOVALUE;
    int _0, _1, _2;
    

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	sequence these_routines = file_routines[file_no]*/
    DeRef(_these_routines_43154);
    _2 = (int)SEQ_PTR(_56file_routines_43378);
    _these_routines_43154 = (int)*(((s1_ptr)_2)->base + _file_no_43152);
    Ref(_these_routines_43154);

    /** 	for i = 1 to length( these_routines ) do*/
    if (IS_SEQUENCE(_these_routines_43154)){
            _22879 = SEQ_PTR(_these_routines_43154)->length;
    }
    else {
        _22879 = 1;
    }
    {
        int _i_43158;
        _i_43158 = 1;
L1: 
        if (_i_43158 > _22879){
            goto L2; // [22] 126
        }

        /** 		symtab_index s = these_routines[i]*/
        _2 = (int)SEQ_PTR(_these_routines_43154);
        _s_43161 = (int)*(((s1_ptr)_2)->base + _i_43158);
        if (!IS_ATOM_INT(_s_43161)){
            _s_43161 = (long)DBL_PTR(_s_43161)->dbl;
        }

        /** 		if SymTab[s][S_FILE_NO] = file_no and*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22881 = (int)*(((s1_ptr)_2)->base + _s_43161);
        _2 = (int)SEQ_PTR(_22881);
        if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
            _22882 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
        }
        else{
            _22882 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
        }
        _22881 = NOVALUE;
        if (IS_ATOM_INT(_22882)) {
            _22883 = (_22882 == _file_no_43152);
        }
        else {
            _22883 = binary_op(EQUALS, _22882, _file_no_43152);
        }
        _22882 = NOVALUE;
        if (IS_ATOM_INT(_22883)) {
            if (_22883 == 0) {
                DeRef(_22884);
                _22884 = 0;
                goto L3; // [55] 81
            }
        }
        else {
            if (DBL_PTR(_22883)->dbl == 0.0) {
                DeRef(_22884);
                _22884 = 0;
                goto L3; // [55] 81
            }
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22885 = (int)*(((s1_ptr)_2)->base + _s_43161);
        _2 = (int)SEQ_PTR(_22885);
        _22886 = (int)*(((s1_ptr)_2)->base + 5);
        _22885 = NOVALUE;
        if (IS_ATOM_INT(_22886)) {
            _22887 = (_22886 != 99);
        }
        else {
            _22887 = binary_op(NOTEQ, _22886, 99);
        }
        _22886 = NOVALUE;
        DeRef(_22884);
        if (IS_ATOM_INT(_22887))
        _22884 = (_22887 != 0);
        else
        _22884 = DBL_PTR(_22887)->dbl != 0.0;
L3: 
        if (_22884 == 0) {
            goto L4; // [81] 117
        }
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _22889 = (int)*(((s1_ptr)_2)->base + _s_43161);
        _2 = (int)SEQ_PTR(_22889);
        if (!IS_ATOM_INT(_12S_TOKEN_11359)){
            _22890 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
        }
        else{
            _22890 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
        }
        _22889 = NOVALUE;
        _22891 = find_from(_22890, _28RTN_TOKS_11302, 1);
        _22890 = NOVALUE;
        if (_22891 == 0)
        {
            _22891 = NOVALUE;
            goto L4; // [105] 117
        }
        else{
            _22891 = NOVALUE;
        }

        /** 			return TRUE -- found a non-deleted routine in this file*/
        DeRef(_these_routines_43154);
        DeRef(_22883);
        _22883 = NOVALUE;
        DeRef(_22887);
        _22887 = NOVALUE;
        return _9TRUE_431;
L4: 

        /** 	end for*/
        _i_43158 = _i_43158 + 1;
        goto L1; // [121] 29
L2: 
        ;
    }

    /** 	return FALSE*/
    DeRef(_these_routines_43154);
    DeRef(_22883);
    _22883 = NOVALUE;
    DeRef(_22887);
    _22887 = NOVALUE;
    return _9FALSE_429;
    ;
}


int _56legaldos_filename_char(int _i_43188)
{
    int _22906 = NOVALUE;
    int _22905 = NOVALUE;
    int _22902 = NOVALUE;
    int _22901 = NOVALUE;
    int _22900 = NOVALUE;
    int _22899 = NOVALUE;
    int _22898 = NOVALUE;
    int _22897 = NOVALUE;
    int _22896 = NOVALUE;
    int _22895 = NOVALUE;
    int _22894 = NOVALUE;
    int _22893 = NOVALUE;
    int _22892 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_i_43188)) {
        _1 = (long)(DBL_PTR(_i_43188)->dbl);
        DeRefDS(_i_43188);
        _i_43188 = _1;
    }

    /** 	if ('A' <= i and i <= 'Z') or*/
    _22892 = (65 <= _i_43188);
    if (_22892 == 0) {
        _22893 = 0;
        goto L1; // [9] 21
    }
    _22894 = (_i_43188 <= 90);
    _22893 = (_22894 != 0);
L1: 
    if (_22893 != 0) {
        _22895 = 1;
        goto L2; // [21] 45
    }
    _22896 = (48 <= _i_43188);
    if (_22896 == 0) {
        _22897 = 0;
        goto L3; // [29] 41
    }
    _22898 = (_i_43188 <= 57);
    _22897 = (_22898 != 0);
L3: 
    _22895 = (_22897 != 0);
L2: 
    if (_22895 != 0) {
        _22899 = 1;
        goto L4; // [45] 69
    }
    _22900 = (128 <= _i_43188);
    if (_22900 == 0) {
        _22901 = 0;
        goto L5; // [53] 65
    }
    _22902 = (_i_43188 <= 255);
    _22901 = (_22902 != 0);
L5: 
    _22899 = (_22901 != 0);
L4: 
    if (_22899 != 0) {
        goto L6; // [69] 87
    }
    _22905 = find_from(_i_43188, _22904, 1);
    _22906 = (_22905 != 0);
    _22905 = NOVALUE;
    if (_22906 == 0)
    {
        DeRef(_22906);
        _22906 = NOVALUE;
        goto L7; // [83] 96
    }
    else{
        DeRef(_22906);
        _22906 = NOVALUE;
    }
L6: 

    /** 		return 1*/
    DeRef(_22892);
    _22892 = NOVALUE;
    DeRef(_22894);
    _22894 = NOVALUE;
    DeRef(_22896);
    _22896 = NOVALUE;
    DeRef(_22898);
    _22898 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22902);
    _22902 = NOVALUE;
    return 1;
    goto L8; // [93] 103
L7: 

    /** 		return 0*/
    DeRef(_22892);
    _22892 = NOVALUE;
    DeRef(_22894);
    _22894 = NOVALUE;
    DeRef(_22896);
    _22896 = NOVALUE;
    DeRef(_22898);
    _22898 = NOVALUE;
    DeRef(_22900);
    _22900 = NOVALUE;
    DeRef(_22902);
    _22902 = NOVALUE;
    return 0;
L8: 
    ;
}


int _56legaldos_filename(int _s_43208)
{
    int _dloc_43209 = NOVALUE;
    int _22933 = NOVALUE;
    int _22932 = NOVALUE;
    int _22930 = NOVALUE;
    int _22929 = NOVALUE;
    int _22928 = NOVALUE;
    int _22927 = NOVALUE;
    int _22925 = NOVALUE;
    int _22924 = NOVALUE;
    int _22923 = NOVALUE;
    int _22922 = NOVALUE;
    int _22921 = NOVALUE;
    int _22920 = NOVALUE;
    int _22918 = NOVALUE;
    int _22917 = NOVALUE;
    int _22916 = NOVALUE;
    int _22915 = NOVALUE;
    int _22914 = NOVALUE;
    int _22913 = NOVALUE;
    int _22912 = NOVALUE;
    int _22910 = NOVALUE;
    int _22909 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if find( s, { "..", "." } ) then*/
    RefDS(_22908);
    RefDS(_22907);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22907;
    ((int *)_2)[2] = _22908;
    _22909 = MAKE_SEQ(_1);
    _22910 = find_from(_s_43208, _22909, 1);
    DeRefDS(_22909);
    _22909 = NOVALUE;
    if (_22910 == 0)
    {
        _22910 = NOVALUE;
        goto L1; // [14] 24
    }
    else{
        _22910 = NOVALUE;
    }

    /** 		return 1*/
    DeRefDS(_s_43208);
    return 1;
L1: 

    /** 	dloc = find('.',s)*/
    _dloc_43209 = find_from(46, _s_43208, 1);

    /** 	if dloc > 8 or ( dloc > 0 and dloc + 3 < length(s) ) or ( dloc = 0 and length(s) > 8 ) then*/
    _22912 = (_dloc_43209 > 8);
    if (_22912 != 0) {
        _22913 = 1;
        goto L2; // [37] 68
    }
    _22914 = (_dloc_43209 > 0);
    if (_22914 == 0) {
        _22915 = 0;
        goto L3; // [45] 64
    }
    _22916 = _dloc_43209 + 3;
    if (IS_SEQUENCE(_s_43208)){
            _22917 = SEQ_PTR(_s_43208)->length;
    }
    else {
        _22917 = 1;
    }
    _22918 = (_22916 < _22917);
    _22916 = NOVALUE;
    _22917 = NOVALUE;
    _22915 = (_22918 != 0);
L3: 
    _22913 = (_22915 != 0);
L2: 
    if (_22913 != 0) {
        goto L4; // [68] 96
    }
    _22920 = (_dloc_43209 == 0);
    if (_22920 == 0) {
        DeRef(_22921);
        _22921 = 0;
        goto L5; // [76] 91
    }
    if (IS_SEQUENCE(_s_43208)){
            _22922 = SEQ_PTR(_s_43208)->length;
    }
    else {
        _22922 = 1;
    }
    _22923 = (_22922 > 8);
    _22922 = NOVALUE;
    _22921 = (_22923 != 0);
L5: 
    if (_22921 == 0)
    {
        _22921 = NOVALUE;
        goto L6; // [92] 103
    }
    else{
        _22921 = NOVALUE;
    }
L4: 

    /** 		return 0*/
    DeRefDS(_s_43208);
    DeRef(_22912);
    _22912 = NOVALUE;
    DeRef(_22914);
    _22914 = NOVALUE;
    DeRef(_22920);
    _22920 = NOVALUE;
    DeRef(_22918);
    _22918 = NOVALUE;
    DeRef(_22923);
    _22923 = NOVALUE;
    return 0;
L6: 

    /** 	for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_43208)){
            _22924 = SEQ_PTR(_s_43208)->length;
    }
    else {
        _22924 = 1;
    }
    {
        int _i_43230;
        _i_43230 = 1;
L7: 
        if (_i_43230 > _22924){
            goto L8; // [108] 200
        }

        /** 		if s[i] = '.' then*/
        _2 = (int)SEQ_PTR(_s_43208);
        _22925 = (int)*(((s1_ptr)_2)->base + _i_43230);
        if (binary_op_a(NOTEQ, _22925, 46)){
            _22925 = NOVALUE;
            goto L9; // [121] 173
        }
        _22925 = NOVALUE;

        /** 			for j = i+1 to length(s) do*/
        _22927 = _i_43230 + 1;
        if (IS_SEQUENCE(_s_43208)){
                _22928 = SEQ_PTR(_s_43208)->length;
        }
        else {
            _22928 = 1;
        }
        {
            int _j_43236;
            _j_43236 = _22927;
LA: 
            if (_j_43236 > _22928){
                goto LB; // [134] 168
            }

            /** 				if not legaldos_filename_char(s[j]) then*/
            _2 = (int)SEQ_PTR(_s_43208);
            _22929 = (int)*(((s1_ptr)_2)->base + _j_43236);
            Ref(_22929);
            _22930 = _56legaldos_filename_char(_22929);
            _22929 = NOVALUE;
            if (IS_ATOM_INT(_22930)) {
                if (_22930 != 0){
                    DeRef(_22930);
                    _22930 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            else {
                if (DBL_PTR(_22930)->dbl != 0.0){
                    DeRef(_22930);
                    _22930 = NOVALUE;
                    goto LC; // [151] 161
                }
            }
            DeRef(_22930);
            _22930 = NOVALUE;

            /** 					return 0*/
            DeRefDS(_s_43208);
            DeRef(_22912);
            _22912 = NOVALUE;
            DeRef(_22914);
            _22914 = NOVALUE;
            DeRef(_22920);
            _22920 = NOVALUE;
            DeRef(_22918);
            _22918 = NOVALUE;
            DeRef(_22923);
            _22923 = NOVALUE;
            DeRef(_22927);
            _22927 = NOVALUE;
            return 0;
LC: 

            /** 			end for*/
            _j_43236 = _j_43236 + 1;
            goto LA; // [163] 141
LB: 
            ;
        }

        /** 			exit*/
        goto L8; // [170] 200
L9: 

        /** 		if not legaldos_filename_char(s[i]) then*/
        _2 = (int)SEQ_PTR(_s_43208);
        _22932 = (int)*(((s1_ptr)_2)->base + _i_43230);
        Ref(_22932);
        _22933 = _56legaldos_filename_char(_22932);
        _22932 = NOVALUE;
        if (IS_ATOM_INT(_22933)) {
            if (_22933 != 0){
                DeRef(_22933);
                _22933 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        else {
            if (DBL_PTR(_22933)->dbl != 0.0){
                DeRef(_22933);
                _22933 = NOVALUE;
                goto LD; // [183] 193
            }
        }
        DeRef(_22933);
        _22933 = NOVALUE;

        /** 			return 0*/
        DeRefDS(_s_43208);
        DeRef(_22912);
        _22912 = NOVALUE;
        DeRef(_22914);
        _22914 = NOVALUE;
        DeRef(_22920);
        _22920 = NOVALUE;
        DeRef(_22918);
        _22918 = NOVALUE;
        DeRef(_22923);
        _22923 = NOVALUE;
        DeRef(_22927);
        _22927 = NOVALUE;
        return 0;
LD: 

        /** 	end for*/
        _i_43230 = _i_43230 + 1;
        goto L7; // [195] 115
L8: 
        ;
    }

    /** 	return 1*/
    DeRefDS(_s_43208);
    DeRef(_22912);
    _22912 = NOVALUE;
    DeRef(_22914);
    _22914 = NOVALUE;
    DeRef(_22920);
    _22920 = NOVALUE;
    DeRef(_22918);
    _22918 = NOVALUE;
    DeRef(_22923);
    _22923 = NOVALUE;
    DeRef(_22927);
    _22927 = NOVALUE;
    return 1;
    ;
}


int _56shrink_to_83(int _s_43249)
{
    int _dl_43250 = NOVALUE;
    int _sl_43251 = NOVALUE;
    int _osl_43252 = NOVALUE;
    int _se_43253 = NOVALUE;
    int _23014 = NOVALUE;
    int _23013 = NOVALUE;
    int _23012 = NOVALUE;
    int _23011 = NOVALUE;
    int _23010 = NOVALUE;
    int _23009 = NOVALUE;
    int _23008 = NOVALUE;
    int _23007 = NOVALUE;
    int _23006 = NOVALUE;
    int _23005 = NOVALUE;
    int _23003 = NOVALUE;
    int _23002 = NOVALUE;
    int _23001 = NOVALUE;
    int _23000 = NOVALUE;
    int _22998 = NOVALUE;
    int _22997 = NOVALUE;
    int _22996 = NOVALUE;
    int _22995 = NOVALUE;
    int _22992 = NOVALUE;
    int _22991 = NOVALUE;
    int _22990 = NOVALUE;
    int _22987 = NOVALUE;
    int _22986 = NOVALUE;
    int _22985 = NOVALUE;
    int _22983 = NOVALUE;
    int _22982 = NOVALUE;
    int _22981 = NOVALUE;
    int _22980 = NOVALUE;
    int _22978 = NOVALUE;
    int _22977 = NOVALUE;
    int _22975 = NOVALUE;
    int _22974 = NOVALUE;
    int _22972 = NOVALUE;
    int _22971 = NOVALUE;
    int _22970 = NOVALUE;
    int _22969 = NOVALUE;
    int _22968 = NOVALUE;
    int _22967 = NOVALUE;
    int _22966 = NOVALUE;
    int _22965 = NOVALUE;
    int _22964 = NOVALUE;
    int _22963 = NOVALUE;
    int _22961 = NOVALUE;
    int _22960 = NOVALUE;
    int _22959 = NOVALUE;
    int _22956 = NOVALUE;
    int _22955 = NOVALUE;
    int _22954 = NOVALUE;
    int _22953 = NOVALUE;
    int _22950 = NOVALUE;
    int _22949 = NOVALUE;
    int _22948 = NOVALUE;
    int _22946 = NOVALUE;
    int _22945 = NOVALUE;
    int _22944 = NOVALUE;
    int _22943 = NOVALUE;
    int _22941 = NOVALUE;
    int _22939 = NOVALUE;
    int _22938 = NOVALUE;
    int _22937 = NOVALUE;
    int _22936 = NOVALUE;
    int _0, _1, _2;
    

    /** 	osl = find( ':', s )*/
    _osl_43252 = find_from(58, _s_43249, 1);

    /** 	sl = osl + find( '\\', s[osl+1..$] ) -- find_from osl*/
    _22936 = _osl_43252 + 1;
    if (IS_SEQUENCE(_s_43249)){
            _22937 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _22937 = 1;
    }
    rhs_slice_target = (object_ptr)&_22938;
    RHS_Slice(_s_43249, _22936, _22937);
    _22939 = find_from(92, _22938, 1);
    DeRefDS(_22938);
    _22938 = NOVALUE;
    _sl_43251 = _osl_43252 + _22939;
    _22939 = NOVALUE;

    /** 	if sl=osl+1 then*/
    _22941 = _osl_43252 + 1;
    if (_sl_43251 != _22941)
    goto L1; // [39] 49

    /** 		osl = sl*/
    _osl_43252 = _sl_43251;
L1: 

    /** 	sl = osl + find( '\\', s[osl+1..$] )*/
    _22943 = _osl_43252 + 1;
    if (_22943 > MAXINT){
        _22943 = NewDouble((double)_22943);
    }
    if (IS_SEQUENCE(_s_43249)){
            _22944 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _22944 = 1;
    }
    rhs_slice_target = (object_ptr)&_22945;
    RHS_Slice(_s_43249, _22943, _22944);
    _22946 = find_from(92, _22945, 1);
    DeRefDS(_22945);
    _22945 = NOVALUE;
    _sl_43251 = _osl_43252 + _22946;
    _22946 = NOVALUE;

    /** 	dl = osl + find( '.', s[osl+1..sl] )*/
    _22948 = _osl_43252 + 1;
    rhs_slice_target = (object_ptr)&_22949;
    RHS_Slice(_s_43249, _22948, _sl_43251);
    _22950 = find_from(46, _22949, 1);
    DeRefDS(_22949);
    _22949 = NOVALUE;
    _dl_43250 = _osl_43252 + _22950;
    _22950 = NOVALUE;

    /** 	if dl > osl then*/
    if (_dl_43250 <= _osl_43252)
    goto L2; // [94] 124

    /** 		se = s[dl..min({dl+3,sl-1})]*/
    _22953 = _dl_43250 + 3;
    if ((long)((unsigned long)_22953 + (unsigned long)HIGH_BITS) >= 0) 
    _22953 = NewDouble((double)_22953);
    _22954 = _sl_43251 - 1;
    if ((long)((unsigned long)_22954 +(unsigned long) HIGH_BITS) >= 0){
        _22954 = NewDouble((double)_22954);
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22953;
    ((int *)_2)[2] = _22954;
    _22955 = MAKE_SEQ(_1);
    _22954 = NOVALUE;
    _22953 = NOVALUE;
    _22956 = _21min(_22955);
    _22955 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43253;
    RHS_Slice(_s_43249, _dl_43250, _22956);
    goto L3; // [121] 132
L2: 

    /** 		se = ""*/
    RefDS(_21829);
    DeRef(_se_43253);
    _se_43253 = _21829;
L3: 

    /** 	while sl != osl do*/
L4: 
    if (_sl_43251 == _osl_43252)
    goto L5; // [137] 333

    /** 		if find( ' ', s[osl+1..sl] ) or not legaldos_filename(upper(s[osl+1..sl-1])) then*/
    _22959 = _osl_43252 + 1;
    rhs_slice_target = (object_ptr)&_22960;
    RHS_Slice(_s_43249, _22959, _sl_43251);
    _22961 = find_from(32, _22960, 1);
    DeRefDS(_22960);
    _22960 = NOVALUE;
    if (_22961 != 0) {
        goto L6; // [157] 190
    }
    _22963 = _osl_43252 + 1;
    if (_22963 > MAXINT){
        _22963 = NewDouble((double)_22963);
    }
    _22964 = _sl_43251 - 1;
    rhs_slice_target = (object_ptr)&_22965;
    RHS_Slice(_s_43249, _22963, _22964);
    _22966 = _18upper(_22965);
    _22965 = NOVALUE;
    _22967 = _56legaldos_filename(_22966);
    _22966 = NOVALUE;
    if (IS_ATOM_INT(_22967)) {
        _22968 = (_22967 == 0);
    }
    else {
        _22968 = unary_op(NOT, _22967);
    }
    DeRef(_22967);
    _22967 = NOVALUE;
    if (_22968 == 0) {
        DeRef(_22968);
        _22968 = NOVALUE;
        goto L7; // [186] 244
    }
    else {
        if (!IS_ATOM_INT(_22968) && DBL_PTR(_22968)->dbl == 0.0){
            DeRef(_22968);
            _22968 = NOVALUE;
            goto L7; // [186] 244
        }
        DeRef(_22968);
        _22968 = NOVALUE;
    }
    DeRef(_22968);
    _22968 = NOVALUE;
L6: 

    /** 			s = s[1..osl] & s[osl+1..osl+6] & "~1" & se & s[sl..$]*/
    rhs_slice_target = (object_ptr)&_22969;
    RHS_Slice(_s_43249, 1, _osl_43252);
    _22970 = _osl_43252 + 1;
    if (_22970 > MAXINT){
        _22970 = NewDouble((double)_22970);
    }
    _22971 = _osl_43252 + 6;
    rhs_slice_target = (object_ptr)&_22972;
    RHS_Slice(_s_43249, _22970, _22971);
    if (IS_SEQUENCE(_s_43249)){
            _22974 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _22974 = 1;
    }
    rhs_slice_target = (object_ptr)&_22975;
    RHS_Slice(_s_43249, _sl_43251, _22974);
    {
        int concat_list[5];

        concat_list[0] = _22975;
        concat_list[1] = _se_43253;
        concat_list[2] = _22973;
        concat_list[3] = _22972;
        concat_list[4] = _22969;
        Concat_N((object_ptr)&_s_43249, concat_list, 5);
    }
    DeRefDS(_22975);
    _22975 = NOVALUE;
    DeRefDS(_22972);
    _22972 = NOVALUE;
    DeRefDS(_22969);
    _22969 = NOVALUE;

    /** 			sl = osl+8+length(se)*/
    _22977 = _osl_43252 + 8;
    if ((long)((unsigned long)_22977 + (unsigned long)HIGH_BITS) >= 0) 
    _22977 = NewDouble((double)_22977);
    if (IS_SEQUENCE(_se_43253)){
            _22978 = SEQ_PTR(_se_43253)->length;
    }
    else {
        _22978 = 1;
    }
    if (IS_ATOM_INT(_22977)) {
        _sl_43251 = _22977 + _22978;
    }
    else {
        _sl_43251 = NewDouble(DBL_PTR(_22977)->dbl + (double)_22978);
    }
    DeRef(_22977);
    _22977 = NOVALUE;
    _22978 = NOVALUE;
    if (!IS_ATOM_INT(_sl_43251)) {
        _1 = (long)(DBL_PTR(_sl_43251)->dbl);
        DeRefDS(_sl_43251);
        _sl_43251 = _1;
    }
L7: 

    /** 		osl = sl*/
    _osl_43252 = _sl_43251;

    /** 		sl += find( '\\', s[sl+1..$] )*/
    _22980 = _sl_43251 + 1;
    if (_22980 > MAXINT){
        _22980 = NewDouble((double)_22980);
    }
    if (IS_SEQUENCE(_s_43249)){
            _22981 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _22981 = 1;
    }
    rhs_slice_target = (object_ptr)&_22982;
    RHS_Slice(_s_43249, _22980, _22981);
    _22983 = find_from(92, _22982, 1);
    DeRefDS(_22982);
    _22982 = NOVALUE;
    _sl_43251 = _sl_43251 + _22983;
    _22983 = NOVALUE;

    /** 		dl = osl + find( '.', s[osl+1..sl] )*/
    _22985 = _osl_43252 + 1;
    rhs_slice_target = (object_ptr)&_22986;
    RHS_Slice(_s_43249, _22985, _sl_43251);
    _22987 = find_from(46, _22986, 1);
    DeRefDS(_22986);
    _22986 = NOVALUE;
    _dl_43250 = _osl_43252 + _22987;
    _22987 = NOVALUE;

    /** 		if dl > osl then*/
    if (_dl_43250 <= _osl_43252)
    goto L8; // [294] 320

    /** 			se = s[dl..min({dl+3,sl})]*/
    _22990 = _dl_43250 + 3;
    if ((long)((unsigned long)_22990 + (unsigned long)HIGH_BITS) >= 0) 
    _22990 = NewDouble((double)_22990);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22990;
    ((int *)_2)[2] = _sl_43251;
    _22991 = MAKE_SEQ(_1);
    _22990 = NOVALUE;
    _22992 = _21min(_22991);
    _22991 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43253;
    RHS_Slice(_s_43249, _dl_43250, _22992);
    goto L4; // [317] 137
L8: 

    /** 			se = ""*/
    RefDS(_21829);
    DeRef(_se_43253);
    _se_43253 = _21829;

    /** 	end while*/
    goto L4; // [330] 137
L5: 

    /** 	if dl > osl then*/
    if (_dl_43250 <= _osl_43252)
    goto L9; // [335] 362

    /** 		se = s[dl..min({dl+3,length(s)})]*/
    _22995 = _dl_43250 + 3;
    if ((long)((unsigned long)_22995 + (unsigned long)HIGH_BITS) >= 0) 
    _22995 = NewDouble((double)_22995);
    if (IS_SEQUENCE(_s_43249)){
            _22996 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _22996 = 1;
    }
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _22995;
    ((int *)_2)[2] = _22996;
    _22997 = MAKE_SEQ(_1);
    _22996 = NOVALUE;
    _22995 = NOVALUE;
    _22998 = _21min(_22997);
    _22997 = NOVALUE;
    rhs_slice_target = (object_ptr)&_se_43253;
    RHS_Slice(_s_43249, _dl_43250, _22998);
L9: 

    /** 	if find( ' ', s[osl+1..$] ) or not legaldos_filename(upper(s[osl+1..$])) then*/
    _23000 = _osl_43252 + 1;
    if (_23000 > MAXINT){
        _23000 = NewDouble((double)_23000);
    }
    if (IS_SEQUENCE(_s_43249)){
            _23001 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _23001 = 1;
    }
    rhs_slice_target = (object_ptr)&_23002;
    RHS_Slice(_s_43249, _23000, _23001);
    _23003 = find_from(32, _23002, 1);
    DeRefDS(_23002);
    _23002 = NOVALUE;
    if (_23003 != 0) {
        goto LA; // [381] 413
    }
    _23005 = _osl_43252 + 1;
    if (_23005 > MAXINT){
        _23005 = NewDouble((double)_23005);
    }
    if (IS_SEQUENCE(_s_43249)){
            _23006 = SEQ_PTR(_s_43249)->length;
    }
    else {
        _23006 = 1;
    }
    rhs_slice_target = (object_ptr)&_23007;
    RHS_Slice(_s_43249, _23005, _23006);
    _23008 = _18upper(_23007);
    _23007 = NOVALUE;
    _23009 = _56legaldos_filename(_23008);
    _23008 = NOVALUE;
    if (IS_ATOM_INT(_23009)) {
        _23010 = (_23009 == 0);
    }
    else {
        _23010 = unary_op(NOT, _23009);
    }
    DeRef(_23009);
    _23009 = NOVALUE;
    if (_23010 == 0) {
        DeRef(_23010);
        _23010 = NOVALUE;
        goto LB; // [409] 443
    }
    else {
        if (!IS_ATOM_INT(_23010) && DBL_PTR(_23010)->dbl == 0.0){
            DeRef(_23010);
            _23010 = NOVALUE;
            goto LB; // [409] 443
        }
        DeRef(_23010);
        _23010 = NOVALUE;
    }
    DeRef(_23010);
    _23010 = NOVALUE;
LA: 

    /** 		s = s[1..osl] & s[osl+1..osl+6] & "~1" & se*/
    rhs_slice_target = (object_ptr)&_23011;
    RHS_Slice(_s_43249, 1, _osl_43252);
    _23012 = _osl_43252 + 1;
    if (_23012 > MAXINT){
        _23012 = NewDouble((double)_23012);
    }
    _23013 = _osl_43252 + 6;
    rhs_slice_target = (object_ptr)&_23014;
    RHS_Slice(_s_43249, _23012, _23013);
    {
        int concat_list[4];

        concat_list[0] = _se_43253;
        concat_list[1] = _22973;
        concat_list[2] = _23014;
        concat_list[3] = _23011;
        Concat_N((object_ptr)&_s_43249, concat_list, 4);
    }
    DeRefDS(_23014);
    _23014 = NOVALUE;
    DeRefDS(_23011);
    _23011 = NOVALUE;
LB: 

    /** 	return s*/
    DeRef(_se_43253);
    DeRef(_22936);
    _22936 = NOVALUE;
    DeRef(_22941);
    _22941 = NOVALUE;
    DeRef(_22943);
    _22943 = NOVALUE;
    DeRef(_22948);
    _22948 = NOVALUE;
    DeRef(_22959);
    _22959 = NOVALUE;
    DeRef(_22956);
    _22956 = NOVALUE;
    DeRef(_22963);
    _22963 = NOVALUE;
    DeRef(_22964);
    _22964 = NOVALUE;
    DeRef(_22980);
    _22980 = NOVALUE;
    DeRef(_22970);
    _22970 = NOVALUE;
    DeRef(_22971);
    _22971 = NOVALUE;
    DeRef(_22985);
    _22985 = NOVALUE;
    DeRef(_23000);
    _23000 = NOVALUE;
    DeRef(_22992);
    _22992 = NOVALUE;
    DeRef(_22998);
    _22998 = NOVALUE;
    DeRef(_23005);
    _23005 = NOVALUE;
    DeRef(_23012);
    _23012 = NOVALUE;
    DeRef(_23013);
    _23013 = NOVALUE;
    return _s_43249;
    ;
}


int _56truncate_to_83(int _lfn_43351)
{
    int _dl_43352 = NOVALUE;
    int _23035 = NOVALUE;
    int _23034 = NOVALUE;
    int _23033 = NOVALUE;
    int _23032 = NOVALUE;
    int _23031 = NOVALUE;
    int _23030 = NOVALUE;
    int _23029 = NOVALUE;
    int _23028 = NOVALUE;
    int _23027 = NOVALUE;
    int _23026 = NOVALUE;
    int _23025 = NOVALUE;
    int _23024 = NOVALUE;
    int _23023 = NOVALUE;
    int _23022 = NOVALUE;
    int _23021 = NOVALUE;
    int _23020 = NOVALUE;
    int _23019 = NOVALUE;
    int _23018 = NOVALUE;
    int _23017 = NOVALUE;
    int _0, _1, _2;
    

    /** 	integer dl = find( '.', lfn )*/
    _dl_43352 = find_from(46, _lfn_43351, 1);

    /** 	if dl = 0 and length(lfn) > 8 then*/
    _23017 = (_dl_43352 == 0);
    if (_23017 == 0) {
        goto L1; // [16] 45
    }
    if (IS_SEQUENCE(_lfn_43351)){
            _23019 = SEQ_PTR(_lfn_43351)->length;
    }
    else {
        _23019 = 1;
    }
    _23020 = (_23019 > 8);
    _23019 = NOVALUE;
    if (_23020 == 0)
    {
        DeRef(_23020);
        _23020 = NOVALUE;
        goto L1; // [28] 45
    }
    else{
        DeRef(_23020);
        _23020 = NOVALUE;
    }

    /** 		return lfn[1..8]*/
    rhs_slice_target = (object_ptr)&_23021;
    RHS_Slice(_lfn_43351, 1, 8);
    DeRefDS(_lfn_43351);
    DeRef(_23017);
    _23017 = NOVALUE;
    return _23021;
    goto L2; // [42] 138
L1: 

    /** 	elsif dl = 0 and length(lfn) <= 8 then*/
    _23022 = (_dl_43352 == 0);
    if (_23022 == 0) {
        goto L3; // [51] 75
    }
    if (IS_SEQUENCE(_lfn_43351)){
            _23024 = SEQ_PTR(_lfn_43351)->length;
    }
    else {
        _23024 = 1;
    }
    _23025 = (_23024 <= 8);
    _23024 = NOVALUE;
    if (_23025 == 0)
    {
        DeRef(_23025);
        _23025 = NOVALUE;
        goto L3; // [63] 75
    }
    else{
        DeRef(_23025);
        _23025 = NOVALUE;
    }

    /** 		return lfn*/
    DeRef(_23017);
    _23017 = NOVALUE;
    DeRef(_23021);
    _23021 = NOVALUE;
    DeRef(_23022);
    _23022 = NOVALUE;
    return _lfn_43351;
    goto L2; // [72] 138
L3: 

    /** 	elsif dl > 9 and dl + 3 <= length(lfn) then*/
    _23026 = (_dl_43352 > 9);
    if (_23026 == 0) {
        goto L4; // [81] 126
    }
    _23028 = _dl_43352 + 3;
    if ((long)((unsigned long)_23028 + (unsigned long)HIGH_BITS) >= 0) 
    _23028 = NewDouble((double)_23028);
    if (IS_SEQUENCE(_lfn_43351)){
            _23029 = SEQ_PTR(_lfn_43351)->length;
    }
    else {
        _23029 = 1;
    }
    if (IS_ATOM_INT(_23028)) {
        _23030 = (_23028 <= _23029);
    }
    else {
        _23030 = (DBL_PTR(_23028)->dbl <= (double)_23029);
    }
    DeRef(_23028);
    _23028 = NOVALUE;
    _23029 = NOVALUE;
    if (_23030 == 0)
    {
        DeRef(_23030);
        _23030 = NOVALUE;
        goto L4; // [97] 126
    }
    else{
        DeRef(_23030);
        _23030 = NOVALUE;
    }

    /** 		return lfn[1..8] & lfn[dl..$]*/
    rhs_slice_target = (object_ptr)&_23031;
    RHS_Slice(_lfn_43351, 1, 8);
    if (IS_SEQUENCE(_lfn_43351)){
            _23032 = SEQ_PTR(_lfn_43351)->length;
    }
    else {
        _23032 = 1;
    }
    rhs_slice_target = (object_ptr)&_23033;
    RHS_Slice(_lfn_43351, _dl_43352, _23032);
    Concat((object_ptr)&_23034, _23031, _23033);
    DeRefDS(_23031);
    _23031 = NOVALUE;
    DeRef(_23031);
    _23031 = NOVALUE;
    DeRefDS(_23033);
    _23033 = NOVALUE;
    DeRefDS(_lfn_43351);
    DeRef(_23017);
    _23017 = NOVALUE;
    DeRef(_23021);
    _23021 = NOVALUE;
    DeRef(_23022);
    _23022 = NOVALUE;
    DeRef(_23026);
    _23026 = NOVALUE;
    return _23034;
    goto L2; // [123] 138
L4: 

    /** 		CompileErr( 48, {lfn})*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_lfn_43351);
    *((int *)(_2+4)) = _lfn_43351;
    _23035 = MAKE_SEQ(_1);
    _43CompileErr(48, _23035, 0);
    _23035 = NOVALUE;
L2: 
    ;
}


void _56check_file_routines()
{
    int _s_43387 = NOVALUE;
    int _23053 = NOVALUE;
    int _23052 = NOVALUE;
    int _23051 = NOVALUE;
    int _23050 = NOVALUE;
    int _23049 = NOVALUE;
    int _23048 = NOVALUE;
    int _23047 = NOVALUE;
    int _23046 = NOVALUE;
    int _23045 = NOVALUE;
    int _23044 = NOVALUE;
    int _23043 = NOVALUE;
    int _23042 = NOVALUE;
    int _23040 = NOVALUE;
    int _23038 = NOVALUE;
    int _23036 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length( file_routines ) then*/
    if (IS_SEQUENCE(_56file_routines_43378)){
            _23036 = SEQ_PTR(_56file_routines_43378)->length;
    }
    else {
        _23036 = 1;
    }
    if (_23036 != 0)
    goto L1; // [8] 146
    _23036 = NOVALUE;

    /** 		file_routines = repeat( {}, length( known_files ) )*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _23038 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _23038 = 1;
    }
    DeRefDS(_56file_routines_43378);
    _56file_routines_43378 = Repeat(_21829, _23038);
    _23038 = NOVALUE;

    /** 		integer s = SymTab[TopLevelSub][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23040 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
    _2 = (int)SEQ_PTR(_23040);
    _s_43387 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43387)){
        _s_43387 = (long)DBL_PTR(_s_43387)->dbl;
    }
    _23040 = NOVALUE;

    /** 		while s do*/
L2: 
    if (_s_43387 == 0)
    {
        goto L3; // [45] 145
    }
    else{
    }

    /** 			if SymTab[s][S_USAGE] != U_DELETED and*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23042 = (int)*(((s1_ptr)_2)->base + _s_43387);
    _2 = (int)SEQ_PTR(_23042);
    _23043 = (int)*(((s1_ptr)_2)->base + 5);
    _23042 = NOVALUE;
    if (IS_ATOM_INT(_23043)) {
        _23044 = (_23043 != 99);
    }
    else {
        _23044 = binary_op(NOTEQ, _23043, 99);
    }
    _23043 = NOVALUE;
    if (IS_ATOM_INT(_23044)) {
        if (_23044 == 0) {
            goto L4; // [68] 124
        }
    }
    else {
        if (DBL_PTR(_23044)->dbl == 0.0) {
            goto L4; // [68] 124
        }
    }
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23046 = (int)*(((s1_ptr)_2)->base + _s_43387);
    _2 = (int)SEQ_PTR(_23046);
    if (!IS_ATOM_INT(_12S_TOKEN_11359)){
        _23047 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
    }
    else{
        _23047 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
    }
    _23046 = NOVALUE;
    _23048 = find_from(_23047, _28RTN_TOKS_11302, 1);
    _23047 = NOVALUE;
    if (_23048 == 0)
    {
        _23048 = NOVALUE;
        goto L4; // [92] 124
    }
    else{
        _23048 = NOVALUE;
    }

    /** 				file_routines[SymTab[s][S_FILE_NO]] &= s*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23049 = (int)*(((s1_ptr)_2)->base + _s_43387);
    _2 = (int)SEQ_PTR(_23049);
    if (!IS_ATOM_INT(_12S_FILE_NO_11350)){
        _23050 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_FILE_NO_11350)->dbl));
    }
    else{
        _23050 = (int)*(((s1_ptr)_2)->base + _12S_FILE_NO_11350);
    }
    _23049 = NOVALUE;
    _2 = (int)SEQ_PTR(_56file_routines_43378);
    if (!IS_ATOM_INT(_23050)){
        _23051 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23050)->dbl));
    }
    else{
        _23051 = (int)*(((s1_ptr)_2)->base + _23050);
    }
    if (IS_SEQUENCE(_23051) && IS_ATOM(_s_43387)) {
        Append(&_23052, _23051, _s_43387);
    }
    else if (IS_ATOM(_23051) && IS_SEQUENCE(_s_43387)) {
    }
    else {
        Concat((object_ptr)&_23052, _23051, _s_43387);
        _23051 = NOVALUE;
    }
    _23051 = NOVALUE;
    _2 = (int)SEQ_PTR(_56file_routines_43378);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _56file_routines_43378 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_23050))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_23050)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _23050);
    _1 = *(int *)_2;
    *(int *)_2 = _23052;
    if( _1 != _23052 ){
        DeRef(_1);
    }
    _23052 = NOVALUE;
L4: 

    /** 			s = SymTab[s][S_NEXT]*/
    _2 = (int)SEQ_PTR(_13SymTab_10636);
    _23053 = (int)*(((s1_ptr)_2)->base + _s_43387);
    _2 = (int)SEQ_PTR(_23053);
    _s_43387 = (int)*(((s1_ptr)_2)->base + 2);
    if (!IS_ATOM_INT(_s_43387)){
        _s_43387 = (long)DBL_PTR(_s_43387)->dbl;
    }
    _23053 = NOVALUE;

    /** 		end while*/
    goto L2; // [142] 45
L3: 
L1: 

    /** end procedure*/
    _23050 = NOVALUE;
    DeRef(_23044);
    _23044 = NOVALUE;
    return;
    ;
}


void _56GenerateUserRoutines()
{
    int _s_43421 = NOVALUE;
    int _sp_43422 = NOVALUE;
    int _next_c_char_43423 = NOVALUE;
    int _q_43424 = NOVALUE;
    int _temps_43425 = NOVALUE;
    int _buff_43426 = NOVALUE;
    int _base_name_43427 = NOVALUE;
    int _long_c_file_43428 = NOVALUE;
    int _c_file_43429 = NOVALUE;
    int _these_routines_43496 = NOVALUE;
    int _ret_type_43554 = NOVALUE;
    int _scope_43625 = NOVALUE;
    int _names_43659 = NOVALUE;
    int _name_43669 = NOVALUE;
    int _23266 = NOVALUE;
    int _23264 = NOVALUE;
    int _23263 = NOVALUE;
    int _23233 = NOVALUE;
    int _23232 = NOVALUE;
    int _23231 = NOVALUE;
    int _23229 = NOVALUE;
    int _23227 = NOVALUE;
    int _23226 = NOVALUE;
    int _23225 = NOVALUE;
    int _23224 = NOVALUE;
    int _23223 = NOVALUE;
    int _23222 = NOVALUE;
    int _23221 = NOVALUE;
    int _23219 = NOVALUE;
    int _23218 = NOVALUE;
    int _23217 = NOVALUE;
    int _23216 = NOVALUE;
    int _23215 = NOVALUE;
    int _23214 = NOVALUE;
    int _23213 = NOVALUE;
    int _23212 = NOVALUE;
    int _23210 = NOVALUE;
    int _23209 = NOVALUE;
    int _23207 = NOVALUE;
    int _23206 = NOVALUE;
    int _23205 = NOVALUE;
    int _23204 = NOVALUE;
    int _23203 = NOVALUE;
    int _23202 = NOVALUE;
    int _23201 = NOVALUE;
    int _23200 = NOVALUE;
    int _23198 = NOVALUE;
    int _23197 = NOVALUE;
    int _23195 = NOVALUE;
    int _23194 = NOVALUE;
    int _23193 = NOVALUE;
    int _23191 = NOVALUE;
    int _23188 = NOVALUE;
    int _23187 = NOVALUE;
    int _23185 = NOVALUE;
    int _23183 = NOVALUE;
    int _23177 = NOVALUE;
    int _23176 = NOVALUE;
    int _23175 = NOVALUE;
    int _23174 = NOVALUE;
    int _23173 = NOVALUE;
    int _23172 = NOVALUE;
    int _23171 = NOVALUE;
    int _23170 = NOVALUE;
    int _23168 = NOVALUE;
    int _23167 = NOVALUE;
    int _23165 = NOVALUE;
    int _23164 = NOVALUE;
    int _23161 = NOVALUE;
    int _23159 = NOVALUE;
    int _23158 = NOVALUE;
    int _23157 = NOVALUE;
    int _23153 = NOVALUE;
    int _23150 = NOVALUE;
    int _23147 = NOVALUE;
    int _23146 = NOVALUE;
    int _23145 = NOVALUE;
    int _23144 = NOVALUE;
    int _23142 = NOVALUE;
    int _23141 = NOVALUE;
    int _23139 = NOVALUE;
    int _23138 = NOVALUE;
    int _23137 = NOVALUE;
    int _23132 = NOVALUE;
    int _23131 = NOVALUE;
    int _23130 = NOVALUE;
    int _23129 = NOVALUE;
    int _23128 = NOVALUE;
    int _23127 = NOVALUE;
    int _23125 = NOVALUE;
    int _23124 = NOVALUE;
    int _23122 = NOVALUE;
    int _23119 = NOVALUE;
    int _23118 = NOVALUE;
    int _23114 = NOVALUE;
    int _23113 = NOVALUE;
    int _23111 = NOVALUE;
    int _23107 = NOVALUE;
    int _23106 = NOVALUE;
    int _23105 = NOVALUE;
    int _23104 = NOVALUE;
    int _23103 = NOVALUE;
    int _23102 = NOVALUE;
    int _23101 = NOVALUE;
    int _23100 = NOVALUE;
    int _23099 = NOVALUE;
    int _23098 = NOVALUE;
    int _23097 = NOVALUE;
    int _23096 = NOVALUE;
    int _23095 = NOVALUE;
    int _23094 = NOVALUE;
    int _23092 = NOVALUE;
    int _23091 = NOVALUE;
    int _23089 = NOVALUE;
    int _23086 = NOVALUE;
    int _23083 = NOVALUE;
    int _23080 = NOVALUE;
    int _23077 = NOVALUE;
    int _23076 = NOVALUE;
    int _23075 = NOVALUE;
    int _23072 = NOVALUE;
    int _23069 = NOVALUE;
    int _23067 = NOVALUE;
    int _23063 = NOVALUE;
    int _23062 = NOVALUE;
    int _23060 = NOVALUE;
    int _23059 = NOVALUE;
    int _0, _1, _2, _3;
    

    /** 	integer next_c_char, q, temps*/

    /** 	sequence buff, base_name, long_c_file, c_file*/

    /** 	if not silent then*/
    if (_12silent_11798 != 0)
    goto L1; // [9] 62

    /** 		if Pass = 1 then*/
    if (_56Pass_41336 != 1)
    goto L2; // [16] 29

    /** 			ShowMsg(1, 239,,0)*/
    RefDS(_21829);
    _44ShowMsg(1, 239, _21829, 0);
L2: 

    /** 		if LAST_PASS = TRUE then*/
    if (_56LAST_PASS_41334 != _9TRUE_431)
    goto L3; // [35] 50

    /** 			ShowMsg(1, 240)*/
    RefDS(_21829);
    _44ShowMsg(1, 240, _21829, 1);
    goto L4; // [47] 61
L3: 

    /** 			ShowMsg(1, 241, Pass, 0)*/
    _44ShowMsg(1, 241, _56Pass_41336, 0);
L4: 
L1: 

    /** 	check_file_routines()*/
    _56check_file_routines();

    /** 	c_puts("// GenerateUserRoutines\n")*/
    RefDS(_23058);
    _53c_puts(_23058);

    /** 	for file_no = 1 to length(known_files) do*/
    if (IS_SEQUENCE(_13known_files_10637)){
            _23059 = SEQ_PTR(_13known_files_10637)->length;
    }
    else {
        _23059 = 1;
    }
    {
        int _file_no_43445;
        _file_no_43445 = 1;
L5: 
        if (_file_no_43445 > _23059){
            goto L6; // [78] 2060
        }

        /** 		if file_no = 1 or any_code(file_no) then*/
        _23060 = (_file_no_43445 == 1);
        if (_23060 != 0) {
            goto L7; // [91] 104
        }
        _23062 = _56any_code(_file_no_43445);
        if (_23062 == 0) {
            DeRef(_23062);
            _23062 = NOVALUE;
            goto L8; // [100] 2051
        }
        else {
            if (!IS_ATOM_INT(_23062) && DBL_PTR(_23062)->dbl == 0.0){
                DeRef(_23062);
                _23062 = NOVALUE;
                goto L8; // [100] 2051
            }
            DeRef(_23062);
            _23062 = NOVALUE;
        }
        DeRef(_23062);
        _23062 = NOVALUE;
L7: 

        /** 			next_c_char = 1*/
        _next_c_char_43423 = 1;

        /** 			base_name = name_ext(known_files[file_no])*/
        _2 = (int)SEQ_PTR(_13known_files_10637);
        _23063 = (int)*(((s1_ptr)_2)->base + _file_no_43445);
        Ref(_23063);
        _0 = _base_name_43427;
        _base_name_43427 = _52name_ext(_23063);
        DeRef(_0);
        _23063 = NOVALUE;

        /** 			c_file = base_name*/
        RefDS(_base_name_43427);
        DeRef(_c_file_43429);
        _c_file_43429 = _base_name_43427;

        /** 			q = length(c_file)*/
        if (IS_SEQUENCE(_c_file_43429)){
                _q_43424 = SEQ_PTR(_c_file_43429)->length;
        }
        else {
            _q_43424 = 1;
        }

        /** 			while q >= 1 do*/
L9: 
        if (_q_43424 < 1)
        goto LA; // [140] 181

        /** 				if c_file[q] = '.' then*/
        _2 = (int)SEQ_PTR(_c_file_43429);
        _23067 = (int)*(((s1_ptr)_2)->base + _q_43424);
        if (binary_op_a(NOTEQ, _23067, 46)){
            _23067 = NOVALUE;
            goto LB; // [150] 170
        }
        _23067 = NOVALUE;

        /** 					c_file = c_file[1..q-1]*/
        _23069 = _q_43424 - 1;
        rhs_slice_target = (object_ptr)&_c_file_43429;
        RHS_Slice(_c_file_43429, 1, _23069);

        /** 					exit*/
        goto LA; // [167] 181
LB: 

        /** 				q -= 1*/
        _q_43424 = _q_43424 - 1;

        /** 			end while*/
        goto L9; // [178] 140
LA: 

        /** 			if find(lower(c_file), {"main-", "init-"})  then*/
        RefDS(_c_file_43429);
        _23072 = _18lower(_c_file_43429);
        RefDS(_23074);
        RefDS(_23073);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _23073;
        ((int *)_2)[2] = _23074;
        _23075 = MAKE_SEQ(_1);
        _23076 = find_from(_23072, _23075, 1);
        DeRef(_23072);
        _23072 = NOVALUE;
        DeRefDS(_23075);
        _23075 = NOVALUE;
        if (_23076 == 0)
        {
            _23076 = NOVALUE;
            goto LC; // [196] 211
        }
        else{
            _23076 = NOVALUE;
        }

        /** 				CompileErr(12, {base_name})*/
        _1 = NewS1(1);
        _2 = (int)((s1_ptr)_1)->base;
        RefDS(_base_name_43427);
        *((int *)(_2+4)) = _base_name_43427;
        _23077 = MAKE_SEQ(_1);
        _43CompileErr(12, _23077, 0);
        _23077 = NOVALUE;
LC: 

        /** 			long_c_file = c_file*/
        RefDS(_c_file_43429);
        DeRef(_long_c_file_43428);
        _long_c_file_43428 = _c_file_43429;

        /** 			if LAST_PASS = TRUE then*/
        if (_56LAST_PASS_41334 != _9TRUE_431)
        goto LD; // [224] 249

        /** 				c_file = unique_c_name(c_file)*/
        RefDS(_c_file_43429);
        _0 = _c_file_43429;
        _c_file_43429 = _56unique_c_name(_c_file_43429);
        DeRefDS(_0);

        /** 				add_file(c_file, known_files[file_no])*/
        _2 = (int)SEQ_PTR(_13known_files_10637);
        _23080 = (int)*(((s1_ptr)_2)->base + _file_no_43445);
        RefDS(_c_file_43429);
        Ref(_23080);
        _56add_file(_c_file_43429, _23080);
        _23080 = NOVALUE;
LD: 

        /** 			if file_no = 1 then*/
        if (_file_no_43445 != 1)
        goto LE; // [251] 314

        /** 				if LAST_PASS = TRUE then*/
        if (_56LAST_PASS_41334 != _9TRUE_431)
        goto LF; // [261] 306

        /** 					add_file("main-")*/
        RefDS(_23073);
        RefDS(_21829);
        _56add_file(_23073, _21829);

        /** 					for i = 0 to main_name_num-1 do*/
        _23083 = _53main_name_num_45140 - 1;
        if ((long)((unsigned long)_23083 +(unsigned long) HIGH_BITS) >= 0){
            _23083 = NewDouble((double)_23083);
        }
        {
            int _i_43486;
            _i_43486 = 0;
L10: 
            if (binary_op_a(GREATER, _i_43486, _23083)){
                goto L11; // [279] 305
            }

            /** 						buff = sprintf("main-%d", i)*/
            DeRefi(_buff_43426);
            _buff_43426 = EPrintf(-9999999, _23084, _i_43486);

            /** 						add_file(buff)*/
            RefDS(_buff_43426);
            RefDS(_21829);
            _56add_file(_buff_43426, _21829);

            /** 					end for*/
            _0 = _i_43486;
            if (IS_ATOM_INT(_i_43486)) {
                _i_43486 = _i_43486 + 1;
                if ((long)((unsigned long)_i_43486 +(unsigned long) HIGH_BITS) >= 0){
                    _i_43486 = NewDouble((double)_i_43486);
                }
            }
            else {
                _i_43486 = binary_op_a(PLUS, _i_43486, 1);
            }
            DeRef(_0);
            goto L10; // [300] 286
L11: 
            ;
            DeRef(_i_43486);
        }
LF: 

        /** 				file0 = long_c_file*/
        RefDS(_long_c_file_43428);
        DeRef(_56file0_43185);
        _56file0_43185 = _long_c_file_43428;
LE: 

        /** 			new_c_file(c_file)*/
        RefDS(_c_file_43429);
        _56new_c_file(_c_file_43429);

        /** 			s = SymTab[TopLevelSub][S_NEXT]*/
        _2 = (int)SEQ_PTR(_13SymTab_10636);
        _23086 = (int)*(((s1_ptr)_2)->base + _12TopLevelSub_11689);
        _2 = (int)SEQ_PTR(_23086);
        _s_43421 = (int)*(((s1_ptr)_2)->base + 2);
        if (!IS_ATOM_INT(_s_43421)){
            _s_43421 = (long)DBL_PTR(_s_43421)->dbl;
        }
        _23086 = NOVALUE;

        /** 			sequence these_routines = file_routines[file_no]*/
        DeRef(_these_routines_43496);
        _2 = (int)SEQ_PTR(_56file_routines_43378);
        _these_routines_43496 = (int)*(((s1_ptr)_2)->base + _file_no_43445);
        Ref(_these_routines_43496);

        /** 			for routine_no = 1 to length( these_routines ) do*/
        if (IS_SEQUENCE(_these_routines_43496)){
                _23089 = SEQ_PTR(_these_routines_43496)->length;
        }
        else {
            _23089 = 1;
        }
        {
            int _routine_no_43499;
            _routine_no_43499 = 1;
L12: 
            if (_routine_no_43499 > _23089){
                goto L13; // [352] 2050
            }

            /** 				s = these_routines[routine_no]*/
            _2 = (int)SEQ_PTR(_these_routines_43496);
            _s_43421 = (int)*(((s1_ptr)_2)->base + _routine_no_43499);
            if (!IS_ATOM_INT(_s_43421)){
                _s_43421 = (long)DBL_PTR(_s_43421)->dbl;
            }

            /** 				if SymTab[s][S_USAGE] != U_DELETED then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23091 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23091);
            _23092 = (int)*(((s1_ptr)_2)->base + 5);
            _23091 = NOVALUE;
            if (binary_op_a(EQUALS, _23092, 99)){
                _23092 = NOVALUE;
                goto L14; // [383] 2041
            }
            _23092 = NOVALUE;

            /** 					if LAST_PASS = TRUE and*/
            _23094 = (_56LAST_PASS_41334 == _9TRUE_431);
            if (_23094 == 0) {
                goto L15; // [397] 593
            }
            _23096 = (_12cfile_size_11762 > 100000);
            if (_23096 != 0) {
                DeRef(_23097);
                _23097 = 1;
                goto L16; // [409] 472
            }
            _23098 = (_s_43421 != _12TopLevelSub_11689);
            if (_23098 == 0) {
                _23099 = 0;
                goto L17; // [419] 439
            }
            _23100 = (100000 % 4) ? NewDouble((double)100000 / 4) : (100000 / 4);
            if (IS_ATOM_INT(_23100)) {
                _23101 = (_12cfile_size_11762 > _23100);
            }
            else {
                _23101 = ((double)_12cfile_size_11762 > DBL_PTR(_23100)->dbl);
            }
            DeRef(_23100);
            _23100 = NOVALUE;
            _23099 = (_23101 != 0);
L17: 
            if (_23099 == 0) {
                _23102 = 0;
                goto L18; // [439] 468
            }
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23103 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23103);
            if (!IS_ATOM_INT(_12S_CODE_11366)){
                _23104 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_CODE_11366)->dbl));
            }
            else{
                _23104 = (int)*(((s1_ptr)_2)->base + _12S_CODE_11366);
            }
            _23103 = NOVALUE;
            if (IS_SEQUENCE(_23104)){
                    _23105 = SEQ_PTR(_23104)->length;
            }
            else {
                _23105 = 1;
            }
            _23104 = NOVALUE;
            _23106 = (_23105 > 100000);
            _23105 = NOVALUE;
            _23102 = (_23106 != 0);
L18: 
            DeRef(_23097);
            _23097 = (_23102 != 0);
L16: 
            if (_23097 == 0)
            {
                _23097 = NOVALUE;
                goto L15; // [473] 593
            }
            else{
                _23097 = NOVALUE;
            }

            /** 						if length(c_file) = 7 then*/
            if (IS_SEQUENCE(_c_file_43429)){
                    _23107 = SEQ_PTR(_c_file_43429)->length;
            }
            else {
                _23107 = 1;
            }
            if (_23107 != 7)
            goto L19; // [481] 492

            /** 							c_file &= " "*/
            Concat((object_ptr)&_c_file_43429, _c_file_43429, _23109);
L19: 

            /** 						if length(c_file) >= 8 then*/
            if (IS_SEQUENCE(_c_file_43429)){
                    _23111 = SEQ_PTR(_c_file_43429)->length;
            }
            else {
                _23111 = 1;
            }
            if (_23111 < 8)
            goto L1A; // [497] 520

            /** 							c_file[7] = '_'*/
            _2 = (int)SEQ_PTR(_c_file_43429);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43429 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 7);
            _1 = *(int *)_2;
            *(int *)_2 = 95;
            DeRef(_1);

            /** 							c_file[8] = file_chars[next_c_char]*/
            _2 = (int)SEQ_PTR(_56file_chars_43051);
            _23113 = (int)*(((s1_ptr)_2)->base + _next_c_char_43423);
            Ref(_23113);
            _2 = (int)SEQ_PTR(_c_file_43429);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43429 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 8);
            _1 = *(int *)_2;
            *(int *)_2 = _23113;
            if( _1 != _23113 ){
                DeRef(_1);
            }
            _23113 = NOVALUE;
            goto L1B; // [517] 552
L1A: 

            /** 							if find('_', c_file) = 0 then*/
            _23114 = find_from(95, _c_file_43429, 1);
            if (_23114 != 0)
            goto L1C; // [527] 538

            /** 								c_file &= "_ "*/
            Concat((object_ptr)&_c_file_43429, _c_file_43429, _23116);
L1C: 

            /** 							c_file[$] = file_chars[next_c_char]*/
            if (IS_SEQUENCE(_c_file_43429)){
                    _23118 = SEQ_PTR(_c_file_43429)->length;
            }
            else {
                _23118 = 1;
            }
            _2 = (int)SEQ_PTR(_56file_chars_43051);
            _23119 = (int)*(((s1_ptr)_2)->base + _next_c_char_43423);
            Ref(_23119);
            _2 = (int)SEQ_PTR(_c_file_43429);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _c_file_43429 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _23118);
            _1 = *(int *)_2;
            *(int *)_2 = _23119;
            if( _1 != _23119 ){
                DeRef(_1);
            }
            _23119 = NOVALUE;
L1B: 

            /** 						c_file = unique_c_name(c_file)*/
            RefDS(_c_file_43429);
            _0 = _c_file_43429;
            _c_file_43429 = _56unique_c_name(_c_file_43429);
            DeRefDS(_0);

            /** 						new_c_file(c_file)*/
            RefDS(_c_file_43429);
            _56new_c_file(_c_file_43429);

            /** 						next_c_char += 1*/
            _next_c_char_43423 = _next_c_char_43423 + 1;

            /** 						if next_c_char > length(file_chars) then*/
            if (IS_SEQUENCE(_56file_chars_43051)){
                    _23122 = SEQ_PTR(_56file_chars_43051)->length;
            }
            else {
                _23122 = 1;
            }
            if (_next_c_char_43423 <= _23122)
            goto L1D; // [576] 586

            /** 							next_c_char = 1  -- (unique_c_name will resolve)*/
            _next_c_char_43423 = 1;
L1D: 

            /** 						add_file(c_file)*/
            RefDS(_c_file_43429);
            RefDS(_21829);
            _56add_file(_c_file_43429, _21829);
L15: 

            /** 					sequence ret_type*/

            /** 					if SymTab[s][S_TOKEN] = PROC then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23124 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23124);
            if (!IS_ATOM_INT(_12S_TOKEN_11359)){
                _23125 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TOKEN_11359)->dbl));
            }
            else{
                _23125 = (int)*(((s1_ptr)_2)->base + _12S_TOKEN_11359);
            }
            _23124 = NOVALUE;
            if (binary_op_a(NOTEQ, _23125, 27)){
                _23125 = NOVALUE;
                goto L1E; // [611] 625
            }
            _23125 = NOVALUE;

            /** 						ret_type = "void "*/
            RefDS(_22546);
            DeRefi(_ret_type_43554);
            _ret_type_43554 = _22546;
            goto L1F; // [622] 633
L1E: 

            /** 						ret_type = "int "*/
            RefDS(_22547);
            DeRefi(_ret_type_43554);
            _ret_type_43554 = _22547;
L1F: 

            /** 					if find( SymTab[s][S_SCOPE], {SC_GLOBAL, SC_EXPORT, SC_PUBLIC} ) and dll_option then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23127 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23127);
            _23128 = (int)*(((s1_ptr)_2)->base + 4);
            _23127 = NOVALUE;
            _1 = NewS1(3);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = 6;
            *((int *)(_2+8)) = 11;
            *((int *)(_2+12)) = 13;
            _23129 = MAKE_SEQ(_1);
            _23130 = find_from(_23128, _23129, 1);
            _23128 = NOVALUE;
            DeRefDS(_23129);
            _23129 = NOVALUE;
            if (_23130 == 0) {
                goto L20; // [664] 740
            }
            if (_56dll_option_41347 == 0)
            {
                goto L20; // [671] 740
            }
            else{
            }

            /** 						SymTab[s][S_RI_TARGET] = TRUE*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _13SymTab_10636 = MAKE_SEQ(_2);
            }
            _3 = (int)(_s_43421 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 53);
            _1 = *(int *)_2;
            *(int *)_2 = _9TRUE_431;
            DeRef(_1);
            _23132 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _56LeftSym_41344 = _9TRUE_431;

            /** 						if TWINDOWS then*/

            /** 							c_stmt(ret_type & "@(", s)*/
            Concat((object_ptr)&_23137, _ret_type_43554, _23136);
            _56c_stmt(_23137, _s_43421, 0);
            _23137 = NOVALUE;
            goto L21; // [737] 763
L20: 

            /** 						LeftSym = TRUE*/
            _56LeftSym_41344 = _9TRUE_431;

            /** 						c_stmt( ret_type & "@(", s)*/
            Concat((object_ptr)&_23138, _ret_type_43554, _23136);
            _56c_stmt(_23138, _s_43421, 0);
            _23138 = NOVALUE;
L21: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23139 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23139);
            _sp_43422 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43422)){
                _sp_43422 = (long)DBL_PTR(_sp_43422)->dbl;
            }
            _23139 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23141 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23141);
            if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
                _23142 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
            }
            else{
                _23142 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
            }
            _23141 = NOVALUE;
            {
                int _p_43595;
                _p_43595 = 1;
L22: 
                if (binary_op_a(GREATER, _p_43595, _23142)){
                    goto L23; // [793] 869
                }

                /** 						c_puts("int _")*/
                RefDS(_23143);
                _53c_puts(_23143);

                /** 						c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23144 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23144);
                if (!IS_ATOM_INT(_12S_NAME_11354)){
                    _23145 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
                }
                else{
                    _23145 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
                }
                _23144 = NOVALUE;
                Ref(_23145);
                _53c_puts(_23145);
                _23145 = NOVALUE;

                /** 						if p != SymTab[s][S_NUM_ARGS] then*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23146 = (int)*(((s1_ptr)_2)->base + _s_43421);
                _2 = (int)SEQ_PTR(_23146);
                if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
                    _23147 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
                }
                else{
                    _23147 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
                }
                _23146 = NOVALUE;
                if (binary_op_a(EQUALS, _p_43595, _23147)){
                    _23147 = NOVALUE;
                    goto L24; // [836] 846
                }
                _23147 = NOVALUE;

                /** 							c_puts(", ")*/
                RefDS(_23149);
                _53c_puts(_23149);
L24: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23150 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23150);
                _sp_43422 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43422)){
                    _sp_43422 = (long)DBL_PTR(_sp_43422)->dbl;
                }
                _23150 = NOVALUE;

                /** 					end for*/
                _0 = _p_43595;
                if (IS_ATOM_INT(_p_43595)) {
                    _p_43595 = _p_43595 + 1;
                    if ((long)((unsigned long)_p_43595 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43595 = NewDouble((double)_p_43595);
                    }
                }
                else {
                    _p_43595 = binary_op_a(PLUS, _p_43595, 1);
                }
                DeRef(_0);
                goto L22; // [864] 800
L23: 
                ;
                DeRef(_p_43595);
            }

            /** 					c_puts(")\n")*/
            RefDS(_23152);
            _53c_puts(_23152);

            /** 					c_stmt0("{\n")*/
            RefDS(_21986);
            _56c_stmt0(_21986);

            /** 					NewBB(0, E_ALL_EFFECT, 0)*/
            _56NewBB(0, 1073741823, 0);

            /** 					Initializing = TRUE*/
            _12Initializing_11763 = _9TRUE_431;

            /** 					while sp do*/
L25: 
            if (_sp_43422 == 0)
            {
                goto L26; // [902] 1041
            }
            else{
            }

            /** 						integer scope = SymTab[sp][S_SCOPE]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23153 = (int)*(((s1_ptr)_2)->base + _sp_43422);
            _2 = (int)SEQ_PTR(_23153);
            _scope_43625 = (int)*(((s1_ptr)_2)->base + 4);
            if (!IS_ATOM_INT(_scope_43625)){
                _scope_43625 = (long)DBL_PTR(_scope_43625)->dbl;
            }
            _23153 = NOVALUE;

            /** 						switch scope with fallthru do*/
            _0 = _scope_43625;
            switch ( _0 ){ 

                /** 							case SC_LOOP_VAR, SC_UNDEFINED then*/
                case 2:
                case 9:

                /** 								break*/
                goto L27; // [936] 1018

                /** 							case SC_PRIVATE then*/
                case 3:

                /** 								c_stmt0("int ")*/
                RefDS(_22547);
                _56c_stmt0(_22547);

                /** 								c_puts("_")*/
                RefDS(_21901);
                _53c_puts(_21901);

                /** 								c_puts(SymTab[sp][S_NAME])*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23157 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23157);
                if (!IS_ATOM_INT(_12S_NAME_11354)){
                    _23158 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
                }
                else{
                    _23158 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
                }
                _23157 = NOVALUE;
                Ref(_23158);
                _53c_puts(_23158);
                _23158 = NOVALUE;

                /** 								c_puts(" = NOVALUE;\n")*/
                RefDS(_22554);
                _53c_puts(_22554);

                /** 								target[MIN] = NOVALUE*/
                Ref(_12NOVALUE_11536);
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _12NOVALUE_11536;
                DeRef(_1);

                /** 								target[MAX] = NOVALUE*/
                Ref(_12NOVALUE_11536);
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _12NOVALUE_11536;
                DeRef(_1);

                /** 								RemoveFromBB( sp )*/
                _56RemoveFromBB(_sp_43422);

                /** 								break*/
                goto L27; // [1005] 1018

                /** 							case else*/
                default:

                /** 								exit*/
                goto L26; // [1015] 1041
            ;}L27: 

            /** 						sp = SymTab[sp][S_NEXT]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23159 = (int)*(((s1_ptr)_2)->base + _sp_43422);
            _2 = (int)SEQ_PTR(_23159);
            _sp_43422 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43422)){
                _sp_43422 = (long)DBL_PTR(_sp_43422)->dbl;
            }
            _23159 = NOVALUE;

            /** 					end while*/
            goto L25; // [1038] 902
L26: 

            /** 					temps = SymTab[s][S_TEMPS]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23161 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23161);
            if (!IS_ATOM_INT(_12S_TEMPS_11399)){
                _temps_43425 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_TEMPS_11399)->dbl));
            }
            else{
                _temps_43425 = (int)*(((s1_ptr)_2)->base + _12S_TEMPS_11399);
            }
            if (!IS_ATOM_INT(_temps_43425)){
                _temps_43425 = (long)DBL_PTR(_temps_43425)->dbl;
            }
            _23161 = NOVALUE;

            /** 					sequence names = {}*/
            RefDS(_21829);
            DeRef(_names_43659);
            _names_43659 = _21829;

            /** 					while temps != 0 do*/
L28: 
            if (_temps_43425 == 0)
            goto L29; // [1069] 1261

            /** 						if SymTab[temps][S_SCOPE] != DELETED then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23164 = (int)*(((s1_ptr)_2)->base + _temps_43425);
            _2 = (int)SEQ_PTR(_23164);
            _23165 = (int)*(((s1_ptr)_2)->base + 4);
            _23164 = NOVALUE;
            if (binary_op_a(EQUALS, _23165, 2)){
                _23165 = NOVALUE;
                goto L2A; // [1089] 1221
            }
            _23165 = NOVALUE;

            /** 							sequence name = sprintf("_%d", SymTab[temps][S_TEMP_NAME] )*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23167 = (int)*(((s1_ptr)_2)->base + _temps_43425);
            _2 = (int)SEQ_PTR(_23167);
            _23168 = (int)*(((s1_ptr)_2)->base + 34);
            _23167 = NOVALUE;
            DeRefi(_name_43669);
            _name_43669 = EPrintf(-9999999, _21922, _23168);
            _23168 = NOVALUE;

            /** 							if temp_name_type[SymTab[temps][S_TEMP_NAME]][T_GTYPE]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23170 = (int)*(((s1_ptr)_2)->base + _temps_43425);
            _2 = (int)SEQ_PTR(_23170);
            _23171 = (int)*(((s1_ptr)_2)->base + 34);
            _23170 = NOVALUE;
            _2 = (int)SEQ_PTR(_12temp_name_type_11765);
            if (!IS_ATOM_INT(_23171)){
                _23172 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_23171)->dbl));
            }
            else{
                _23172 = (int)*(((s1_ptr)_2)->base + _23171);
            }
            _2 = (int)SEQ_PTR(_23172);
            _23173 = (int)*(((s1_ptr)_2)->base + 1);
            _23172 = NOVALUE;
            if (IS_ATOM_INT(_23173)) {
                _23174 = (_23173 != 0);
            }
            else {
                _23174 = binary_op(NOTEQ, _23173, 0);
            }
            _23173 = NOVALUE;
            if (IS_ATOM_INT(_23174)) {
                if (_23174 == 0) {
                    goto L2B; // [1143] 1217
                }
            }
            else {
                if (DBL_PTR(_23174)->dbl == 0.0) {
                    goto L2B; // [1143] 1217
                }
            }
            _23176 = find_from(_name_43669, _names_43659, 1);
            _23177 = (_23176 == 0);
            _23176 = NOVALUE;
            if (_23177 == 0)
            {
                DeRef(_23177);
                _23177 = NOVALUE;
                goto L2B; // [1156] 1217
            }
            else{
                DeRef(_23177);
                _23177 = NOVALUE;
            }

            /** 								c_stmt0("int ")*/
            RefDS(_22547);
            _56c_stmt0(_22547);

            /** 								c_puts( name )*/
            RefDS(_name_43669);
            _53c_puts(_name_43669);

            /** 								c_puts(" = NOVALUE")*/
            RefDS(_23178);
            _53c_puts(_23178);

            /** 								target = {NOVALUE, NOVALUE}*/
            Ref(_12NOVALUE_11536);
            Ref(_12NOVALUE_11536);
            DeRef(_57target_27115);
            _1 = NewS1(2);
            _2 = (int)((s1_ptr)_1)->base;
            ((int *)_2)[1] = _12NOVALUE_11536;
            ((int *)_2)[2] = _12NOVALUE_11536;
            _57target_27115 = MAKE_SEQ(_1);

            /** 								SetBBType(temps, TYPE_INTEGER, target, TYPE_OBJECT, 0)*/
            RefDS(_57target_27115);
            _56SetBBType(_temps_43425, 1, _57target_27115, 16, 0);

            /** 								ifdef DEBUG then*/

            /** 									c_puts(";\n")*/
            RefDS(_22059);
            _53c_puts(_22059);

            /** 								names = prepend( names, name )*/
            RefDS(_name_43669);
            Prepend(&_names_43659, _names_43659, _name_43669);
            goto L2C; // [1214] 1220
L2B: 

            /** 								ifdef DEBUG then*/
L2C: 
L2A: 
            DeRefi(_name_43669);
            _name_43669 = NOVALUE;

            /** 						SymTab[temps][S_GTYPE] = TYPE_OBJECT*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _13SymTab_10636 = MAKE_SEQ(_2);
            }
            _3 = (int)(_temps_43425 + ((s1_ptr)_2)->base);
            _2 = (int)SEQ_PTR(*(int *)_3);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                *(int *)_3 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + 36);
            _1 = *(int *)_2;
            *(int *)_2 = 16;
            DeRef(_1);
            _23183 = NOVALUE;

            /** 						temps = SymTab[temps][S_NEXT]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23185 = (int)*(((s1_ptr)_2)->base + _temps_43425);
            _2 = (int)SEQ_PTR(_23185);
            _temps_43425 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_temps_43425)){
                _temps_43425 = (long)DBL_PTR(_temps_43425)->dbl;
            }
            _23185 = NOVALUE;

            /** 					end while*/
            goto L28; // [1258] 1069
L29: 

            /** 					Initializing = FALSE*/
            _12Initializing_11763 = _9FALSE_429;

            /** 					if SymTab[s][S_LHS_SUBS2] then*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23187 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23187);
            _23188 = (int)*(((s1_ptr)_2)->base + 37);
            _23187 = NOVALUE;
            if (_23188 == 0) {
                _23188 = NOVALUE;
                goto L2D; // [1284] 1295
            }
            else {
                if (!IS_ATOM_INT(_23188) && DBL_PTR(_23188)->dbl == 0.0){
                    _23188 = NOVALUE;
                    goto L2D; // [1284] 1295
                }
                _23188 = NOVALUE;
            }
            _23188 = NOVALUE;

            /** 						c_stmt0("int _0, _1, _2, _3;\n\n")*/
            RefDS(_23189);
            _56c_stmt0(_23189);
            goto L2E; // [1292] 1301
L2D: 

            /** 						c_stmt0("int _0, _1, _2;\n\n")*/
            RefDS(_23190);
            _56c_stmt0(_23190);
L2E: 

            /** 					sp = SymTab[s][S_NEXT]*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23191 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23191);
            _sp_43422 = (int)*(((s1_ptr)_2)->base + 2);
            if (!IS_ATOM_INT(_sp_43422)){
                _sp_43422 = (long)DBL_PTR(_sp_43422)->dbl;
            }
            _23191 = NOVALUE;

            /** 					for p = 1 to SymTab[s][S_NUM_ARGS] do*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23193 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23193);
            if (!IS_ATOM_INT(_12S_NUM_ARGS_11405)){
                _23194 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NUM_ARGS_11405)->dbl));
            }
            else{
                _23194 = (int)*(((s1_ptr)_2)->base + _12S_NUM_ARGS_11405);
            }
            _23193 = NOVALUE;
            {
                int _p_43728;
                _p_43728 = 1;
L2F: 
                if (binary_op_a(GREATER, _p_43728, _23194)){
                    goto L30; // [1331] 1682
                }

                /** 						SymTab[sp][S_ONE_REF] = FALSE*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _13SymTab_10636 = MAKE_SEQ(_2);
                }
                _3 = (int)(_sp_43422 + ((s1_ptr)_2)->base);
                _2 = (int)SEQ_PTR(*(int *)_3);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    *(int *)_3 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 35);
                _1 = *(int *)_2;
                *(int *)_2 = _9FALSE_429;
                DeRef(_1);
                _23195 = NOVALUE;

                /** 						if SymTab[sp][S_ARG_TYPE] = TYPE_SEQUENCE then*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23197 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23197);
                _23198 = (int)*(((s1_ptr)_2)->base + 43);
                _23197 = NOVALUE;
                if (binary_op_a(NOTEQ, _23198, 8)){
                    _23198 = NOVALUE;
                    goto L31; // [1371] 1435
                }
                _23198 = NOVALUE;

                /** 							target[MIN] = SymTab[sp][S_ARG_SEQ_LEN]*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23200 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23200);
                _23201 = (int)*(((s1_ptr)_2)->base + 51);
                _23200 = NOVALUE;
                Ref(_23201);
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23201;
                if( _1 != _23201 ){
                    DeRef(_1);
                }
                _23201 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target,*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23202 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23202);
                _23203 = (int)*(((s1_ptr)_2)->base + 43);
                _23202 = NOVALUE;
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23204 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23204);
                _23205 = (int)*(((s1_ptr)_2)->base + 45);
                _23204 = NOVALUE;
                Ref(_23203);
                RefDS(_57target_27115);
                Ref(_23205);
                _56SetBBType(_sp_43422, _23203, _57target_27115, _23205, 0);
                _23203 = NOVALUE;
                _23205 = NOVALUE;
                goto L32; // [1432] 1659
L31: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_INTEGER then*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23206 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23206);
                _23207 = (int)*(((s1_ptr)_2)->base + 43);
                _23206 = NOVALUE;
                if (binary_op_a(NOTEQ, _23207, 1)){
                    _23207 = NOVALUE;
                    goto L33; // [1451] 1575
                }
                _23207 = NOVALUE;

                /** 							if SymTab[sp][S_ARG_MIN] = NOVALUE then*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23209 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23209);
                _23210 = (int)*(((s1_ptr)_2)->base + 47);
                _23209 = NOVALUE;
                if (binary_op_a(NOTEQ, _23210, _12NOVALUE_11536)){
                    _23210 = NOVALUE;
                    goto L34; // [1471] 1502
                }
                _23210 = NOVALUE;

                /** 								target[MIN] = MININT*/
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = -1073741824;
                DeRef(_1);

                /** 								target[MAX] = MAXINT*/
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = 1073741823;
                DeRef(_1);
                goto L35; // [1499] 1547
L34: 

                /** 								target[MIN] = SymTab[sp][S_ARG_MIN]*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23212 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23212);
                _23213 = (int)*(((s1_ptr)_2)->base + 47);
                _23212 = NOVALUE;
                Ref(_23213);
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 1);
                _1 = *(int *)_2;
                *(int *)_2 = _23213;
                if( _1 != _23213 ){
                    DeRef(_1);
                }
                _23213 = NOVALUE;

                /** 								target[MAX] = SymTab[sp][S_ARG_MAX]*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23214 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23214);
                _23215 = (int)*(((s1_ptr)_2)->base + 48);
                _23214 = NOVALUE;
                Ref(_23215);
                _2 = (int)SEQ_PTR(_57target_27115);
                if (!UNIQUE(_2)) {
                    _2 = (int)SequenceCopy((s1_ptr)_2);
                    _57target_27115 = MAKE_SEQ(_2);
                }
                _2 = (int)(((s1_ptr)_2)->base + 2);
                _1 = *(int *)_2;
                *(int *)_2 = _23215;
                if( _1 != _23215 ){
                    DeRef(_1);
                }
                _23215 = NOVALUE;
L35: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], target, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23216 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23216);
                _23217 = (int)*(((s1_ptr)_2)->base + 43);
                _23216 = NOVALUE;
                Ref(_23217);
                RefDS(_57target_27115);
                _56SetBBType(_sp_43422, _23217, _57target_27115, 16, 0);
                _23217 = NOVALUE;
                goto L32; // [1572] 1659
L33: 

                /** 						elsif SymTab[sp][S_ARG_TYPE] = TYPE_OBJECT then*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23218 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23218);
                _23219 = (int)*(((s1_ptr)_2)->base + 43);
                _23218 = NOVALUE;
                if (binary_op_a(NOTEQ, _23219, 16)){
                    _23219 = NOVALUE;
                    goto L36; // [1591] 1633
                }
                _23219 = NOVALUE;

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue,*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23221 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23221);
                _23222 = (int)*(((s1_ptr)_2)->base + 43);
                _23221 = NOVALUE;
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23223 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23223);
                _23224 = (int)*(((s1_ptr)_2)->base + 45);
                _23223 = NOVALUE;
                Ref(_23222);
                RefDS(_53novalue_45142);
                Ref(_23224);
                _56SetBBType(_sp_43422, _23222, _53novalue_45142, _23224, 0);
                _23222 = NOVALUE;
                _23224 = NOVALUE;
                goto L32; // [1630] 1659
L36: 

                /** 							SetBBType(sp, SymTab[sp][S_ARG_TYPE], novalue, TYPE_OBJECT, 0)*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23225 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23225);
                _23226 = (int)*(((s1_ptr)_2)->base + 43);
                _23225 = NOVALUE;
                Ref(_23226);
                RefDS(_53novalue_45142);
                _56SetBBType(_sp_43422, _23226, _53novalue_45142, 16, 0);
                _23226 = NOVALUE;
L32: 

                /** 						sp = SymTab[sp][S_NEXT]*/
                _2 = (int)SEQ_PTR(_13SymTab_10636);
                _23227 = (int)*(((s1_ptr)_2)->base + _sp_43422);
                _2 = (int)SEQ_PTR(_23227);
                _sp_43422 = (int)*(((s1_ptr)_2)->base + 2);
                if (!IS_ATOM_INT(_sp_43422)){
                    _sp_43422 = (long)DBL_PTR(_sp_43422)->dbl;
                }
                _23227 = NOVALUE;

                /** 					end for*/
                _0 = _p_43728;
                if (IS_ATOM_INT(_p_43728)) {
                    _p_43728 = _p_43728 + 1;
                    if ((long)((unsigned long)_p_43728 +(unsigned long) HIGH_BITS) >= 0){
                        _p_43728 = NewDouble((double)_p_43728);
                    }
                }
                else {
                    _p_43728 = binary_op_a(PLUS, _p_43728, 1);
                }
                DeRef(_0);
                goto L2F; // [1677] 1338
L30: 
                ;
                DeRef(_p_43728);
            }

            /** 					call_proc(Execute_id, {s})*/
            _1 = NewS1(1);
            _2 = (int)((s1_ptr)_1)->base;
            *((int *)(_2+4)) = _s_43421;
            _23229 = MAKE_SEQ(_1);
            _1 = (int)SEQ_PTR(_23229);
            _2 = (int)((s1_ptr)_1)->base;
            _0 = (int)_00[_12Execute_id_11770].addr;
            Ref(*(int *)(_2+4));
            (*(int (*)())_0)(
                                *(int *)(_2+4)
                                 );
            DeRefDS(_23229);
            _23229 = NOVALUE;

            /** 					c_puts("    ;\n}\n")*/
            RefDS(_23230);
            _53c_puts(_23230);

            /** 					if TUNIX and dll_option and is_exported( s ) then*/
            if (_36TUNIX_14009 == 0) {
                _23231 = 0;
                goto L37; // [1702] 1712
            }
            _23231 = (_56dll_option_41347 != 0);
L37: 
            if (_23231 == 0) {
                goto L38; // [1712] 2035
            }
            _23233 = _56is_exported(_s_43421);
            if (_23233 == 0) {
                DeRef(_23233);
                _23233 = NOVALUE;
                goto L38; // [1721] 2035
            }
            else {
                if (!IS_ATOM_INT(_23233) && DBL_PTR(_23233)->dbl == 0.0){
                    DeRef(_23233);
                    _23233 = NOVALUE;
                    goto L38; // [1721] 2035
                }
                DeRef(_23233);
                _23233 = NOVALUE;
            }
            DeRef(_23233);
            _23233 = NOVALUE;

            /** 						LeftSym = TRUE*/
            _56LeftSym_41344 = _9TRUE_431;

            /** 						if TOSX then*/

            /** 							c_stmt( ret_type & SymTab[s][S_NAME] & "() __attribute__ ((alias (\"@\")));\n", s )*/
            _2 = (int)SEQ_PTR(_13SymTab_10636);
            _23263 = (int)*(((s1_ptr)_2)->base + _s_43421);
            _2 = (int)SEQ_PTR(_23263);
            if (!IS_ATOM_INT(_12S_NAME_11354)){
                _23264 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12S_NAME_11354)->dbl));
            }
            else{
                _23264 = (int)*(((s1_ptr)_2)->base + _12S_NAME_11354);
            }
            _23263 = NOVALUE;
            {
                int concat_list[3];

                concat_list[0] = _23265;
                concat_list[1] = _23264;
                concat_list[2] = _ret_type_43554;
                Concat_N((object_ptr)&_23266, concat_list, 3);
            }
            _23264 = NOVALUE;
            _56c_stmt(_23266, _s_43421, 0);
            _23266 = NOVALUE;

            /** 						LeftSym = FALSE*/
            _56LeftSym_41344 = _9FALSE_429;
L38: 

            /** 					c_puts("\n\n" )*/
            RefDS(_21943);
            _53c_puts(_21943);
L14: 
            DeRefi(_ret_type_43554);
            _ret_type_43554 = NOVALUE;
            DeRef(_names_43659);
            _names_43659 = NOVALUE;

            /** 			end for*/
            _routine_no_43499 = _routine_no_43499 + 1;
            goto L12; // [2045] 359
L13: 
            ;
        }
L8: 
        DeRef(_these_routines_43496);
        _these_routines_43496 = NOVALUE;

        /** 	end for*/
        _file_no_43445 = _file_no_43445 + 1;
        goto L5; // [2055] 85
L6: 
        ;
    }

    /** end procedure*/
    DeRefi(_buff_43426);
    DeRef(_base_name_43427);
    DeRef(_long_c_file_43428);
    DeRef(_c_file_43429);
    DeRef(_23060);
    _23060 = NOVALUE;
    DeRef(_23069);
    _23069 = NOVALUE;
    DeRef(_23083);
    _23083 = NOVALUE;
    DeRef(_23094);
    _23094 = NOVALUE;
    DeRef(_23096);
    _23096 = NOVALUE;
    DeRef(_23098);
    _23098 = NOVALUE;
    _23104 = NOVALUE;
    DeRef(_23101);
    _23101 = NOVALUE;
    DeRef(_23106);
    _23106 = NOVALUE;
    _23142 = NOVALUE;
    _23171 = NOVALUE;
    _23194 = NOVALUE;
    DeRef(_23174);
    _23174 = NOVALUE;
    return;
    ;
}



// 0xD0CF6CCE
