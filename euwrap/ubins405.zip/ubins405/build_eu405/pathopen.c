// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _38exe_path()
{
    int _25675 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if sequence(exe_path_cache) then*/
    _25675 = IS_SEQUENCE(_38exe_path_cache_49219);
    if (_25675 == 0)
    {
        _25675 = NOVALUE;
        goto L1; // [8] 20
    }
    else{
        _25675 = NOVALUE;
    }

    /** 		return exe_path_cache*/
    Ref(_38exe_path_cache_49219);
    return _38exe_path_cache_49219;
L1: 

    /** 	exe_path_cache = command_line()*/
    DeRef(_38exe_path_cache_49219);
    _38exe_path_cache_49219 = Command_Line();

    /** 	exe_path_cache = exe_path_cache[1]*/
    _0 = _38exe_path_cache_49219;
    _2 = (int)SEQ_PTR(_38exe_path_cache_49219);
    _38exe_path_cache_49219 = (int)*(((s1_ptr)_2)->base + 1);
    RefDS(_38exe_path_cache_49219);
    DeRefDS(_0);

    /** 	return exe_path_cache*/
    RefDS(_38exe_path_cache_49219);
    return _38exe_path_cache_49219;
    ;
}


int _38check_cache(int _env_49231, int _inc_path_49232)
{
    int _delim_49233 = NOVALUE;
    int _pos_49234 = NOVALUE;
    int _25723 = NOVALUE;
    int _25722 = NOVALUE;
    int _25721 = NOVALUE;
    int _25720 = NOVALUE;
    int _25718 = NOVALUE;
    int _25717 = NOVALUE;
    int _25716 = NOVALUE;
    int _25715 = NOVALUE;
    int _25714 = NOVALUE;
    int _25713 = NOVALUE;
    int _25712 = NOVALUE;
    int _25711 = NOVALUE;
    int _25710 = NOVALUE;
    int _25706 = NOVALUE;
    int _25705 = NOVALUE;
    int _25704 = NOVALUE;
    int _25703 = NOVALUE;
    int _25702 = NOVALUE;
    int _25701 = NOVALUE;
    int _25700 = NOVALUE;
    int _25699 = NOVALUE;
    int _25697 = NOVALUE;
    int _25696 = NOVALUE;
    int _25695 = NOVALUE;
    int _25694 = NOVALUE;
    int _25693 = NOVALUE;
    int _25692 = NOVALUE;
    int _25690 = NOVALUE;
    int _25689 = NOVALUE;
    int _25688 = NOVALUE;
    int _25687 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not num_var then -- first time the var is accessed, add cache entry*/
    if (_38num_var_49208 != 0)
    goto L1; // [9] 86

    /** 		cache_vars = append(cache_vars,env)*/
    RefDS(_env_49231);
    Append(&_38cache_vars_49209, _38cache_vars_49209, _env_49231);

    /** 		cache_strings = append(cache_strings,inc_path)*/
    RefDS(_inc_path_49232);
    Append(&_38cache_strings_49210, _38cache_strings_49210, _inc_path_49232);

    /** 		cache_substrings = append(cache_substrings,{})*/
    RefDS(_21829);
    Append(&_38cache_substrings_49211, _38cache_substrings_49211, _21829);

    /** 		cache_starts = append(cache_starts,{})*/
    RefDS(_21829);
    Append(&_38cache_starts_49212, _38cache_starts_49212, _21829);

    /** 		cache_ends = append(cache_ends,{})*/
    RefDS(_21829);
    Append(&_38cache_ends_49213, _38cache_ends_49213, _21829);

    /** 		ifdef WINDOWS then*/

    /** 		num_var = length(cache_vars)*/
    if (IS_SEQUENCE(_38cache_vars_49209)){
            _38num_var_49208 = SEQ_PTR(_38cache_vars_49209)->length;
    }
    else {
        _38num_var_49208 = 1;
    }

    /** 		cache_complete &= 0*/
    Append(&_38cache_complete_49215, _38cache_complete_49215, 0);

    /** 		cache_delims &= 0*/
    Append(&_38cache_delims_49216, _38cache_delims_49216, 0);

    /** 		return 0*/
    DeRefDS(_env_49231);
    DeRefDSi(_inc_path_49232);
    return 0;
    goto L2; // [83] 425
L1: 

    /** 		if compare(inc_path,cache_strings[num_var]) then*/
    _2 = (int)SEQ_PTR(_38cache_strings_49210);
    _25687 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    if (IS_ATOM_INT(_inc_path_49232) && IS_ATOM_INT(_25687)){
        _25688 = (_inc_path_49232 < _25687) ? -1 : (_inc_path_49232 > _25687);
    }
    else{
        _25688 = compare(_inc_path_49232, _25687);
    }
    _25687 = NOVALUE;
    if (_25688 == 0)
    {
        _25688 = NOVALUE;
        goto L3; // [100] 424
    }
    else{
        _25688 = NOVALUE;
    }

    /** 			cache_strings[num_var] = inc_path*/
    RefDS(_inc_path_49232);
    _2 = (int)SEQ_PTR(_38cache_strings_49210);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_strings_49210 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
    _1 = *(int *)_2;
    *(int *)_2 = _inc_path_49232;
    DeRefDS(_1);

    /** 			cache_complete[num_var] = 0*/
    _2 = (int)SEQ_PTR(_38cache_complete_49215);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49215 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
    *(int *)_2 = 0;

    /** 			if match(cache_strings[num_var],inc_path)!=1 then -- try to salvage what we can*/
    _2 = (int)SEQ_PTR(_38cache_strings_49210);
    _25689 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    _25690 = e_match_from(_25689, _inc_path_49232, 1);
    _25689 = NOVALUE;
    if (_25690 == 1)
    goto L4; // [138] 423

    /** 				pos = -1*/
    _pos_49234 = -1;

    /** 				for i=1 to length(cache_strings[num_var]) do*/
    _2 = (int)SEQ_PTR(_38cache_strings_49210);
    _25692 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    if (IS_SEQUENCE(_25692)){
            _25693 = SEQ_PTR(_25692)->length;
    }
    else {
        _25693 = 1;
    }
    _25692 = NOVALUE;
    {
        int _i_49254;
        _i_49254 = 1;
L5: 
        if (_i_49254 > _25693){
            goto L6; // [160] 422
        }

        /** 					if cache_ends[num_var][i] > length(inc_path) or */
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25694 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        _2 = (int)SEQ_PTR(_25694);
        _25695 = (int)*(((s1_ptr)_2)->base + _i_49254);
        _25694 = NOVALUE;
        if (IS_SEQUENCE(_inc_path_49232)){
                _25696 = SEQ_PTR(_inc_path_49232)->length;
        }
        else {
            _25696 = 1;
        }
        if (IS_ATOM_INT(_25695)) {
            _25697 = (_25695 > _25696);
        }
        else {
            _25697 = binary_op(GREATER, _25695, _25696);
        }
        _25695 = NOVALUE;
        _25696 = NOVALUE;
        if (IS_ATOM_INT(_25697)) {
            if (_25697 != 0) {
                goto L7; // [188] 242
            }
        }
        else {
            if (DBL_PTR(_25697)->dbl != 0.0) {
                goto L7; // [188] 242
            }
        }
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        _25699 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        _2 = (int)SEQ_PTR(_25699);
        _25700 = (int)*(((s1_ptr)_2)->base + _i_49254);
        _25699 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        _25701 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        _2 = (int)SEQ_PTR(_25701);
        _25702 = (int)*(((s1_ptr)_2)->base + _i_49254);
        _25701 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25703 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        _2 = (int)SEQ_PTR(_25703);
        _25704 = (int)*(((s1_ptr)_2)->base + _i_49254);
        _25703 = NOVALUE;
        rhs_slice_target = (object_ptr)&_25705;
        RHS_Slice(_inc_path_49232, _25702, _25704);
        if (IS_ATOM_INT(_25700) && IS_ATOM_INT(_25705)){
            _25706 = (_25700 < _25705) ? -1 : (_25700 > _25705);
        }
        else{
            _25706 = compare(_25700, _25705);
        }
        _25700 = NOVALUE;
        DeRefDS(_25705);
        _25705 = NOVALUE;
        if (_25706 == 0)
        {
            _25706 = NOVALUE;
            goto L8; // [238] 253
        }
        else{
            _25706 = NOVALUE;
        }
L7: 

        /** 						pos = i-1*/
        _pos_49234 = _i_49254 - 1;

        /** 						exit*/
        goto L6; // [250] 422
L8: 

        /** 					if pos = 0 then*/
        if (_pos_49234 != 0)
        goto L9; // [255] 268

        /** 						return 0*/
        DeRefDS(_env_49231);
        DeRefDSi(_inc_path_49232);
        _25692 = NOVALUE;
        DeRef(_25697);
        _25697 = NOVALUE;
        _25702 = NOVALUE;
        _25704 = NOVALUE;
        return 0;
        goto LA; // [265] 415
L9: 

        /** 					elsif pos >0 then -- crop cache data*/
        if (_pos_49234 <= 0)
        goto LB; // [270] 414

        /** 						cache_substrings[num_var] = cache_substrings[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        _25710 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        rhs_slice_target = (object_ptr)&_25711;
        RHS_Slice(_25710, 1, _pos_49234);
        _25710 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49211 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25711;
        if( _1 != _25711 ){
            DeRefDS(_1);
        }
        _25711 = NOVALUE;

        /** 						cache_starts[num_var] = cache_starts[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        _25712 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        rhs_slice_target = (object_ptr)&_25713;
        RHS_Slice(_25712, 1, _pos_49234);
        _25712 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49212 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25713;
        if( _1 != _25713 ){
            DeRef(_1);
        }
        _25713 = NOVALUE;

        /** 						cache_ends[num_var] = cache_ends[num_var][1..pos]*/
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25714 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        rhs_slice_target = (object_ptr)&_25715;
        RHS_Slice(_25714, 1, _pos_49234);
        _25714 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49213 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25715;
        if( _1 != _25715 ){
            DeRef(_1);
        }
        _25715 = NOVALUE;

        /** 						ifdef WINDOWS then*/

        /** 						delim = cache_ends[num_var][$]+1*/
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25716 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        if (IS_SEQUENCE(_25716)){
                _25717 = SEQ_PTR(_25716)->length;
        }
        else {
            _25717 = 1;
        }
        _2 = (int)SEQ_PTR(_25716);
        _25718 = (int)*(((s1_ptr)_2)->base + _25717);
        _25716 = NOVALUE;
        if (IS_ATOM_INT(_25718)) {
            _delim_49233 = _25718 + 1;
        }
        else
        { // coercing _delim_49233 to an integer 1
            _delim_49233 = 1+(long)(DBL_PTR(_25718)->dbl);
            if( !IS_ATOM_INT(_delim_49233) ){
                _delim_49233 = (object)DBL_PTR(_delim_49233)->dbl;
            }
        }
        _25718 = NOVALUE;

        /** 						while delim <= length(inc_path) and delim != PATH_SEPARATOR do*/
LC: 
        if (IS_SEQUENCE(_inc_path_49232)){
                _25720 = SEQ_PTR(_inc_path_49232)->length;
        }
        else {
            _25720 = 1;
        }
        _25721 = (_delim_49233 <= _25720);
        _25720 = NOVALUE;
        if (_25721 == 0) {
            goto LD; // [378] 403
        }
        _25723 = (_delim_49233 != 58);
        if (_25723 == 0)
        {
            DeRef(_25723);
            _25723 = NOVALUE;
            goto LD; // [389] 403
        }
        else{
            DeRef(_25723);
            _25723 = NOVALUE;
        }

        /** 							delim+=1*/
        _delim_49233 = _delim_49233 + 1;

        /** 						end while*/
        goto LC; // [400] 371
LD: 

        /** 						cache_delims[num_var] = delim*/
        _2 = (int)SEQ_PTR(_38cache_delims_49216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        *(int *)_2 = _delim_49233;
LB: 
LA: 

        /** 				end for*/
        _i_49254 = _i_49254 + 1;
        goto L5; // [417] 167
L6: 
        ;
    }
L4: 
L3: 
L2: 

    /** 	return 1*/
    DeRefDS(_env_49231);
    DeRefDSi(_inc_path_49232);
    _25692 = NOVALUE;
    DeRef(_25721);
    _25721 = NOVALUE;
    DeRef(_25697);
    _25697 = NOVALUE;
    _25702 = NOVALUE;
    _25704 = NOVALUE;
    return 1;
    ;
}


int _38get_conf_dirs()
{
    int _delimiter_49295 = NOVALUE;
    int _dirs_49296 = NOVALUE;
    int _25728 = NOVALUE;
    int _25726 = NOVALUE;
    int _25725 = NOVALUE;
    int _0, _1, _2;
    

    /** 	ifdef UNIX then*/

    /** 		delimiter = ':'*/
    _delimiter_49295 = 58;

    /** 	dirs = ""*/
    RefDS(_21829);
    DeRef(_dirs_49296);
    _dirs_49296 = _21829;

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_38config_inc_paths_49217)){
            _25725 = SEQ_PTR(_38config_inc_paths_49217)->length;
    }
    else {
        _25725 = 1;
    }
    {
        int _i_49298;
        _i_49298 = 1;
L1: 
        if (_i_49298 > _25725){
            goto L2; // [22] 68
        }

        /** 		dirs &= config_inc_paths[i]*/
        _2 = (int)SEQ_PTR(_38config_inc_paths_49217);
        _25726 = (int)*(((s1_ptr)_2)->base + _i_49298);
        Concat((object_ptr)&_dirs_49296, _dirs_49296, _25726);
        _25726 = NOVALUE;

        /** 		if i != length(config_inc_paths) then*/
        if (IS_SEQUENCE(_38config_inc_paths_49217)){
                _25728 = SEQ_PTR(_38config_inc_paths_49217)->length;
        }
        else {
            _25728 = 1;
        }
        if (_i_49298 == _25728)
        goto L3; // [48] 61

        /** 			dirs &= delimiter*/
        Append(&_dirs_49296, _dirs_49296, _delimiter_49295);
L3: 

        /** 	end for*/
        _i_49298 = _i_49298 + 1;
        goto L1; // [63] 29
L2: 
        ;
    }

    /** 	return dirs*/
    return _dirs_49296;
    ;
}


int _38strip_file_from_path(int _full_path_49308)
{
    int _25734 = NOVALUE;
    int _25732 = NOVALUE;
    int _25731 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = length(full_path) to 1 by -1 do*/
    if (IS_SEQUENCE(_full_path_49308)){
            _25731 = SEQ_PTR(_full_path_49308)->length;
    }
    else {
        _25731 = 1;
    }
    {
        int _i_49310;
        _i_49310 = _25731;
L1: 
        if (_i_49310 < 1){
            goto L2; // [8] 46
        }

        /** 		if full_path[i] = SLASH then*/
        _2 = (int)SEQ_PTR(_full_path_49308);
        _25732 = (int)*(((s1_ptr)_2)->base + _i_49310);
        if (binary_op_a(NOTEQ, _25732, 47)){
            _25732 = NOVALUE;
            goto L3; // [23] 39
        }
        _25732 = NOVALUE;

        /** 			return full_path[1..i]*/
        rhs_slice_target = (object_ptr)&_25734;
        RHS_Slice(_full_path_49308, 1, _i_49310);
        DeRefDS(_full_path_49308);
        return _25734;
L3: 

        /** 	end for*/
        _i_49310 = _i_49310 + -1;
        goto L1; // [41] 15
L2: 
        ;
    }

    /** 	return ""*/
    RefDS(_21829);
    DeRefDS(_full_path_49308);
    DeRef(_25734);
    _25734 = NOVALUE;
    return _21829;
    ;
}


int _38expand_path(int _path_49319, int _prefix_49320)
{
    int _absolute_49321 = NOVALUE;
    int _home_49325 = NOVALUE;
    int _25758 = NOVALUE;
    int _25757 = NOVALUE;
    int _25756 = NOVALUE;
    int _25755 = NOVALUE;
    int _25754 = NOVALUE;
    int _25753 = NOVALUE;
    int _25749 = NOVALUE;
    int _25747 = NOVALUE;
    int _25746 = NOVALUE;
    int _25745 = NOVALUE;
    int _25744 = NOVALUE;
    int _25743 = NOVALUE;
    int _25740 = NOVALUE;
    int _25739 = NOVALUE;
    int _25738 = NOVALUE;
    int _25737 = NOVALUE;
    int _25735 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if not length(path) then*/
    if (IS_SEQUENCE(_path_49319)){
            _25735 = SEQ_PTR(_path_49319)->length;
    }
    else {
        _25735 = 1;
    }
    if (_25735 != 0)
    goto L1; // [10] 22
    _25735 = NOVALUE;

    /** 		return pwd*/
    RefDS(_38pwd_49220);
    DeRefDS(_path_49319);
    DeRefDS(_prefix_49320);
    DeRefi(_home_49325);
    return _38pwd_49220;
L1: 

    /** 	ifdef UNIX then*/

    /** 		object home*/

    /** 		if length(path) and path[1] = '~' then*/
    if (IS_SEQUENCE(_path_49319)){
            _25737 = SEQ_PTR(_path_49319)->length;
    }
    else {
        _25737 = 1;
    }
    if (_25737 == 0) {
        goto L2; // [31] 84
    }
    _2 = (int)SEQ_PTR(_path_49319);
    _25739 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_25739)) {
        _25740 = (_25739 == 126);
    }
    else {
        _25740 = binary_op(EQUALS, _25739, 126);
    }
    _25739 = NOVALUE;
    if (_25740 == 0) {
        DeRef(_25740);
        _25740 = NOVALUE;
        goto L2; // [44] 84
    }
    else {
        if (!IS_ATOM_INT(_25740) && DBL_PTR(_25740)->dbl == 0.0){
            DeRef(_25740);
            _25740 = NOVALUE;
            goto L2; // [44] 84
        }
        DeRef(_25740);
        _25740 = NOVALUE;
    }
    DeRef(_25740);
    _25740 = NOVALUE;

    /** 			home = getenv("HOME")*/
    DeRefi(_home_49325);
    _home_49325 = EGetEnv(_25741);

    /** 			if sequence(home) and length(home) then*/
    _25743 = IS_SEQUENCE(_home_49325);
    if (_25743 == 0) {
        goto L3; // [57] 83
    }
    if (IS_SEQUENCE(_home_49325)){
            _25745 = SEQ_PTR(_home_49325)->length;
    }
    else {
        _25745 = 1;
    }
    if (_25745 == 0)
    {
        _25745 = NOVALUE;
        goto L3; // [65] 83
    }
    else{
        _25745 = NOVALUE;
    }

    /** 				path = home & path[2..$]*/
    if (IS_SEQUENCE(_path_49319)){
            _25746 = SEQ_PTR(_path_49319)->length;
    }
    else {
        _25746 = 1;
    }
    rhs_slice_target = (object_ptr)&_25747;
    RHS_Slice(_path_49319, 2, _25746);
    if (IS_SEQUENCE(_home_49325) && IS_ATOM(_25747)) {
    }
    else if (IS_ATOM(_home_49325) && IS_SEQUENCE(_25747)) {
        Ref(_home_49325);
        Prepend(&_path_49319, _25747, _home_49325);
    }
    else {
        Concat((object_ptr)&_path_49319, _home_49325, _25747);
    }
    DeRefDS(_25747);
    _25747 = NOVALUE;
L3: 
L2: 

    /** 		absolute = find(path[1], SLASH_CHARS)*/
    _2 = (int)SEQ_PTR(_path_49319);
    _25749 = (int)*(((s1_ptr)_2)->base + 1);
    _absolute_49321 = find_from(_25749, _36SLASH_CHARS_14019, 1);
    _25749 = NOVALUE;

    /** 	if not absolute then*/
    if (_absolute_49321 != 0)
    goto L4; // [101] 115

    /** 		path = prefix & SLASH & path*/
    {
        int concat_list[3];

        concat_list[0] = _path_49319;
        concat_list[1] = 47;
        concat_list[2] = _prefix_49320;
        Concat_N((object_ptr)&_path_49319, concat_list, 3);
    }
L4: 

    /** 	if length(path) and not find(path[$], SLASH_CHARS) then*/
    if (IS_SEQUENCE(_path_49319)){
            _25753 = SEQ_PTR(_path_49319)->length;
    }
    else {
        _25753 = 1;
    }
    if (_25753 == 0) {
        goto L5; // [120] 154
    }
    if (IS_SEQUENCE(_path_49319)){
            _25755 = SEQ_PTR(_path_49319)->length;
    }
    else {
        _25755 = 1;
    }
    _2 = (int)SEQ_PTR(_path_49319);
    _25756 = (int)*(((s1_ptr)_2)->base + _25755);
    _25757 = find_from(_25756, _36SLASH_CHARS_14019, 1);
    _25756 = NOVALUE;
    _25758 = (_25757 == 0);
    _25757 = NOVALUE;
    if (_25758 == 0)
    {
        DeRef(_25758);
        _25758 = NOVALUE;
        goto L5; // [142] 154
    }
    else{
        DeRef(_25758);
        _25758 = NOVALUE;
    }

    /** 		path &= SLASH*/
    Append(&_path_49319, _path_49319, 47);
L5: 

    /** 	return path*/
    DeRefDS(_prefix_49320);
    DeRefi(_home_49325);
    return _path_49319;
    ;
}


void _38add_include_directory(int _path_49359)
{
    int _25761 = NOVALUE;
    int _0, _1, _2;
    

    /** 	path = expand_path( path, pwd )*/
    RefDS(_path_49359);
    RefDS(_38pwd_49220);
    _0 = _path_49359;
    _path_49359 = _38expand_path(_path_49359, _38pwd_49220);
    DeRefDS(_0);

    /** 	if not find( path, config_inc_paths ) then*/
    _25761 = find_from(_path_49359, _38config_inc_paths_49217, 1);
    if (_25761 != 0)
    goto L1; // [23] 35
    _25761 = NOVALUE;

    /** 		config_inc_paths = append( config_inc_paths, path )*/
    RefDS(_path_49359);
    Append(&_38config_inc_paths_49217, _38config_inc_paths_49217, _path_49359);
L1: 

    /** end procedure*/
    DeRefDS(_path_49359);
    return;
    ;
}


int _38load_euphoria_config(int _file_49368)
{
    int _fn_49369 = NOVALUE;
    int _in_49370 = NOVALUE;
    int _spos_49371 = NOVALUE;
    int _epos_49372 = NOVALUE;
    int _conf_path_49373 = NOVALUE;
    int _new_args_49374 = NOVALUE;
    int _arg_49375 = NOVALUE;
    int _parm_49376 = NOVALUE;
    int _section_49377 = NOVALUE;
    int _needed_49474 = NOVALUE;
    int _25858 = NOVALUE;
    int _25857 = NOVALUE;
    int _25854 = NOVALUE;
    int _25852 = NOVALUE;
    int _25851 = NOVALUE;
    int _25829 = NOVALUE;
    int _25826 = NOVALUE;
    int _25825 = NOVALUE;
    int _25823 = NOVALUE;
    int _25819 = NOVALUE;
    int _25817 = NOVALUE;
    int _25815 = NOVALUE;
    int _25813 = NOVALUE;
    int _25811 = NOVALUE;
    int _25809 = NOVALUE;
    int _25808 = NOVALUE;
    int _25807 = NOVALUE;
    int _25806 = NOVALUE;
    int _25805 = NOVALUE;
    int _25804 = NOVALUE;
    int _25803 = NOVALUE;
    int _25802 = NOVALUE;
    int _25800 = NOVALUE;
    int _25798 = NOVALUE;
    int _25796 = NOVALUE;
    int _25792 = NOVALUE;
    int _25791 = NOVALUE;
    int _25786 = NOVALUE;
    int _25784 = NOVALUE;
    int _25782 = NOVALUE;
    int _25781 = NOVALUE;
    int _25773 = NOVALUE;
    int _25767 = NOVALUE;
    int _25766 = NOVALUE;
    int _25764 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence new_args = {}*/
    RefDS(_21829);
    DeRef(_new_args_49374);
    _new_args_49374 = _21829;

    /** 	if file_type(file) = FILETYPE_DIRECTORY then*/
    RefDS(_file_49368);
    _25764 = _14file_type(_file_49368);
    if (binary_op_a(NOTEQ, _25764, 2)){
        DeRef(_25764);
        _25764 = NOVALUE;
        goto L1; // [18] 53
    }
    DeRef(_25764);
    _25764 = NOVALUE;

    /** 		if file[$] != SLASH then*/
    if (IS_SEQUENCE(_file_49368)){
            _25766 = SEQ_PTR(_file_49368)->length;
    }
    else {
        _25766 = 1;
    }
    _2 = (int)SEQ_PTR(_file_49368);
    _25767 = (int)*(((s1_ptr)_2)->base + _25766);
    if (binary_op_a(EQUALS, _25767, 47)){
        _25767 = NOVALUE;
        goto L2; // [33] 46
    }
    _25767 = NOVALUE;

    /** 			file &= SLASH*/
    Append(&_file_49368, _file_49368, 47);
L2: 

    /** 		file &= "eu.cfg"*/
    Concat((object_ptr)&_file_49368, _file_49368, _25770);
L1: 

    /** 	conf_path = canonical_path( file,,CORRECT )*/
    RefDS(_file_49368);
    _0 = _conf_path_49373;
    _conf_path_49373 = _14canonical_path(_file_49368, 0, 2);
    DeRef(_0);

    /** 	if find(conf_path, seen_conf) != 0 then*/
    _25773 = find_from(_conf_path_49373, _38seen_conf_49365, 1);
    if (_25773 == 0)
    goto L3; // [74] 85

    /** 		return {}*/
    RefDS(_21829);
    DeRefDS(_file_49368);
    DeRefi(_in_49370);
    DeRefDS(_conf_path_49373);
    DeRef(_new_args_49374);
    DeRefi(_arg_49375);
    DeRefi(_parm_49376);
    DeRef(_section_49377);
    return _21829;
L3: 

    /** 	seen_conf = append(seen_conf, conf_path)*/
    RefDS(_conf_path_49373);
    Append(&_38seen_conf_49365, _38seen_conf_49365, _conf_path_49373);

    /** 	section = "all"*/
    RefDS(_25776);
    DeRef(_section_49377);
    _section_49377 = _25776;

    /** 	fn = open( conf_path, "r" )*/
    _fn_49369 = EOpen(_conf_path_49373, _25777, 0);

    /** 	if fn = -1 then return {} end if*/
    if (_fn_49369 != -1)
    goto L4; // [109] 118
    RefDS(_21829);
    DeRefDS(_file_49368);
    DeRefi(_in_49370);
    DeRefDS(_conf_path_49373);
    DeRef(_new_args_49374);
    DeRefi(_arg_49375);
    DeRefi(_parm_49376);
    DeRefDSi(_section_49377);
    return _21829;
L4: 

    /** 	in = gets( fn )*/
    DeRefi(_in_49370);
    _in_49370 = EGets(_fn_49369);

    /** 	while sequence( in ) do*/
L5: 
    _25781 = IS_SEQUENCE(_in_49370);
    if (_25781 == 0)
    {
        _25781 = NOVALUE;
        goto L6; // [131] 768
    }
    else{
        _25781 = NOVALUE;
    }

    /** 		spos = 1*/
    _spos_49371 = 1;

    /** 		while spos <= length(in) do*/
L7: 
    if (IS_SEQUENCE(_in_49370)){
            _25782 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _25782 = 1;
    }
    if (_spos_49371 > _25782)
    goto L8; // [147] 182

    /** 			if find( in[spos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49370);
    _25784 = (int)*(((s1_ptr)_2)->base + _spos_49371);
    _25786 = find_from(_25784, _25785, 1);
    _25784 = NOVALUE;
    if (_25786 != 0)
    goto L9; // [162] 171

    /** 				exit*/
    goto L8; // [168] 182
L9: 

    /** 			spos += 1*/
    _spos_49371 = _spos_49371 + 1;

    /** 		end while*/
    goto L7; // [179] 144
L8: 

    /** 		epos = length(in)*/
    if (IS_SEQUENCE(_in_49370)){
            _epos_49372 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _epos_49372 = 1;
    }

    /** 		while epos >= spos do*/
LA: 
    if (_epos_49372 < _spos_49371)
    goto LB; // [192] 227

    /** 			if find( in[epos], "\n\r \t" ) = 0 then*/
    _2 = (int)SEQ_PTR(_in_49370);
    _25791 = (int)*(((s1_ptr)_2)->base + _epos_49372);
    _25792 = find_from(_25791, _25785, 1);
    _25791 = NOVALUE;
    if (_25792 != 0)
    goto LC; // [207] 216

    /** 				exit*/
    goto LB; // [213] 227
LC: 

    /** 			epos -= 1*/
    _epos_49372 = _epos_49372 - 1;

    /** 		end while*/
    goto LA; // [224] 192
LB: 

    /** 		in = in[spos .. epos]		*/
    rhs_slice_target = (object_ptr)&_in_49370;
    RHS_Slice(_in_49370, _spos_49371, _epos_49372);

    /** 		arg = ""*/
    RefDS(_21829);
    DeRefi(_arg_49375);
    _arg_49375 = _21829;

    /** 		parm = ""*/
    RefDS(_21829);
    DeRefi(_parm_49376);
    _parm_49376 = _21829;

    /** 		if length(in) > 0 then*/
    if (IS_SEQUENCE(_in_49370)){
            _25796 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _25796 = 1;
    }
    if (_25796 <= 0)
    goto LD; // [253] 477

    /** 			if in[1] = '[' then*/
    _2 = (int)SEQ_PTR(_in_49370);
    _25798 = (int)*(((s1_ptr)_2)->base + 1);
    if (_25798 != 91)
    goto LE; // [263] 354

    /** 				section = in[2..$]*/
    if (IS_SEQUENCE(_in_49370)){
            _25800 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _25800 = 1;
    }
    rhs_slice_target = (object_ptr)&_section_49377;
    RHS_Slice(_in_49370, 2, _25800);

    /** 				if length(section) > 0 and section[$] = ']' then*/
    if (IS_SEQUENCE(_section_49377)){
            _25802 = SEQ_PTR(_section_49377)->length;
    }
    else {
        _25802 = 1;
    }
    _25803 = (_25802 > 0);
    _25802 = NOVALUE;
    if (_25803 == 0) {
        goto LF; // [286] 320
    }
    if (IS_SEQUENCE(_section_49377)){
            _25805 = SEQ_PTR(_section_49377)->length;
    }
    else {
        _25805 = 1;
    }
    _2 = (int)SEQ_PTR(_section_49377);
    _25806 = (int)*(((s1_ptr)_2)->base + _25805);
    _25807 = (_25806 == 93);
    _25806 = NOVALUE;
    if (_25807 == 0)
    {
        DeRef(_25807);
        _25807 = NOVALUE;
        goto LF; // [302] 320
    }
    else{
        DeRef(_25807);
        _25807 = NOVALUE;
    }

    /** 					section = section[1..$-1]*/
    if (IS_SEQUENCE(_section_49377)){
            _25808 = SEQ_PTR(_section_49377)->length;
    }
    else {
        _25808 = 1;
    }
    _25809 = _25808 - 1;
    _25808 = NOVALUE;
    rhs_slice_target = (object_ptr)&_section_49377;
    RHS_Slice(_section_49377, 1, _25809);
LF: 

    /** 				section = lower(trim(section))*/
    RefDS(_section_49377);
    RefDS(_2965);
    _25811 = _18trim(_section_49377, _2965, 0);
    _0 = _section_49377;
    _section_49377 = _18lower(_25811);
    DeRefDS(_0);
    _25811 = NOVALUE;

    /** 				if length(section) = 0 then*/
    if (IS_SEQUENCE(_section_49377)){
            _25813 = SEQ_PTR(_section_49377)->length;
    }
    else {
        _25813 = 1;
    }
    if (_25813 != 0)
    goto L10; // [339] 476

    /** 					section = "all"*/
    RefDS(_25776);
    DeRefDS(_section_49377);
    _section_49377 = _25776;
    goto L10; // [351] 476
LE: 

    /** 			elsif length(in) > 2 then*/
    if (IS_SEQUENCE(_in_49370)){
            _25815 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _25815 = 1;
    }
    if (_25815 <= 2)
    goto L11; // [359] 461

    /** 				if in[1] = '-' then*/
    _2 = (int)SEQ_PTR(_in_49370);
    _25817 = (int)*(((s1_ptr)_2)->base + 1);
    if (_25817 != 45)
    goto L12; // [369] 443

    /** 					if in[2] != '-' then*/
    _2 = (int)SEQ_PTR(_in_49370);
    _25819 = (int)*(((s1_ptr)_2)->base + 2);
    if (_25819 == 45)
    goto L10; // [379] 476

    /** 						spos = find(' ', in)*/
    _spos_49371 = find_from(32, _in_49370, 1);

    /** 						if spos = 0 then*/
    if (_spos_49371 != 0)
    goto L13; // [392] 413

    /** 							arg = in*/
    Ref(_in_49370);
    DeRefi(_arg_49375);
    _arg_49375 = _in_49370;

    /** 							parm = ""*/
    RefDS(_21829);
    DeRefi(_parm_49376);
    _parm_49376 = _21829;
    goto L10; // [410] 476
L13: 

    /** 							arg = in[1..spos - 1]*/
    _25823 = _spos_49371 - 1;
    rhs_slice_target = (object_ptr)&_arg_49375;
    RHS_Slice(_in_49370, 1, _25823);

    /** 							parm = in[spos + 1 .. $]*/
    _25825 = _spos_49371 + 1;
    if (_25825 > MAXINT){
        _25825 = NewDouble((double)_25825);
    }
    if (IS_SEQUENCE(_in_49370)){
            _25826 = SEQ_PTR(_in_49370)->length;
    }
    else {
        _25826 = 1;
    }
    rhs_slice_target = (object_ptr)&_parm_49376;
    RHS_Slice(_in_49370, _25825, _25826);
    goto L10; // [440] 476
L12: 

    /** 					arg = "-i"*/
    RefDS(_25828);
    DeRefi(_arg_49375);
    _arg_49375 = _25828;

    /** 					parm = in*/
    Ref(_in_49370);
    DeRefi(_parm_49376);
    _parm_49376 = _in_49370;
    goto L10; // [458] 476
L11: 

    /** 				arg = "-i"*/
    RefDS(_25828);
    DeRefi(_arg_49375);
    _arg_49375 = _25828;

    /** 				parm = in*/
    Ref(_in_49370);
    DeRefi(_parm_49376);
    _parm_49376 = _in_49370;
L10: 
LD: 

    /** 		if length(arg) > 0 then*/
    if (IS_SEQUENCE(_arg_49375)){
            _25829 = SEQ_PTR(_arg_49375)->length;
    }
    else {
        _25829 = 1;
    }
    if (_25829 <= 0)
    goto L14; // [482] 756

    /** 			integer needed = 0*/
    _needed_49474 = 0;

    /** 			switch section do*/
    _1 = find(_section_49377, _25831);
    switch ( _1 ){ 

        /** 				case "all" then*/
        case 1:

        /** 					needed = 1*/
        _needed_49474 = 1;
        goto L15; // [507] 691

        /** 				case "windows" then*/
        case 2:

        /** 					needed = TWINDOWS*/
        _needed_49474 = 0;
        goto L15; // [522] 691

        /** 				case "unix" then*/
        case 3:

        /** 					needed = TUNIX*/
        _needed_49474 = _36TUNIX_14009;
        goto L15; // [537] 691

        /** 				case "translate" then*/
        case 4:

        /** 					needed = TRANSLATE*/
        _needed_49474 = _12TRANSLATE_11319;
        goto L15; // [552] 691

        /** 				case "translate:windows" then*/
        case 5:

        /** 					needed = TRANSLATE and TWINDOWS*/
        _needed_49474 = (_12TRANSLATE_11319 != 0 && 0 != 0);
        goto L15; // [570] 691

        /** 				case "translate:unix" then*/
        case 6:

        /** 					needed = TRANSLATE and TUNIX*/
        _needed_49474 = (_12TRANSLATE_11319 != 0 && _36TUNIX_14009 != 0);
        goto L15; // [588] 691

        /** 				case "interpret" then*/
        case 7:

        /** 					needed = INTERPRET*/
        _needed_49474 = _12INTERPRET_11316;
        goto L15; // [603] 691

        /** 				case "interpret:windows" then*/
        case 8:

        /** 					needed = INTERPRET and TWINDOWS*/
        _needed_49474 = (_12INTERPRET_11316 != 0 && 0 != 0);
        goto L15; // [621] 691

        /** 				case "interpret:unix" then*/
        case 9:

        /** 					needed = INTERPRET and TUNIX*/
        _needed_49474 = (_12INTERPRET_11316 != 0 && _36TUNIX_14009 != 0);
        goto L15; // [639] 691

        /** 				case "bind" then*/
        case 10:

        /** 					needed = BIND*/
        _needed_49474 = _12BIND_11322;
        goto L15; // [654] 691

        /** 				case "bind:windows" then*/
        case 11:

        /** 					needed = BIND and TWINDOWS*/
        _needed_49474 = (_12BIND_11322 != 0 && 0 != 0);
        goto L15; // [672] 691

        /** 				case "bind:unix" then*/
        case 12:

        /** 					needed = BIND and TUNIX*/
        _needed_49474 = (_12BIND_11322 != 0 && _36TUNIX_14009 != 0);
    ;}L15: 

    /** 			if needed then*/
    if (_needed_49474 == 0)
    {
        goto L16; // [693] 755
    }
    else{
    }

    /** 				if equal(arg, "-c") then*/
    if (_arg_49375 == _25850)
    _25851 = 1;
    else if (IS_ATOM_INT(_arg_49375) && IS_ATOM_INT(_25850))
    _25851 = 0;
    else
    _25851 = (compare(_arg_49375, _25850) == 0);
    if (_25851 == 0)
    {
        _25851 = NOVALUE;
        goto L17; // [702] 728
    }
    else{
        _25851 = NOVALUE;
    }

    /** 					if length(parm) > 0 then*/
    if (IS_SEQUENCE(_parm_49376)){
            _25852 = SEQ_PTR(_parm_49376)->length;
    }
    else {
        _25852 = 1;
    }
    if (_25852 <= 0)
    goto L18; // [710] 754

    /** 						new_args &= load_euphoria_config(parm)*/
    RefDS(_parm_49376);
    _25854 = _38load_euphoria_config(_parm_49376);
    if (IS_SEQUENCE(_new_args_49374) && IS_ATOM(_25854)) {
        Ref(_25854);
        Append(&_new_args_49374, _new_args_49374, _25854);
    }
    else if (IS_ATOM(_new_args_49374) && IS_SEQUENCE(_25854)) {
    }
    else {
        Concat((object_ptr)&_new_args_49374, _new_args_49374, _25854);
    }
    DeRef(_25854);
    _25854 = NOVALUE;
    goto L18; // [725] 754
L17: 

    /** 					new_args = append(new_args, arg)*/
    RefDS(_arg_49375);
    Append(&_new_args_49374, _new_args_49374, _arg_49375);

    /** 					if length(parm > 0) then*/
    _25857 = binary_op(GREATER, _parm_49376, 0);
    if (IS_SEQUENCE(_25857)){
            _25858 = SEQ_PTR(_25857)->length;
    }
    else {
        _25858 = 1;
    }
    DeRefDS(_25857);
    _25857 = NOVALUE;
    if (_25858 == 0)
    {
        _25858 = NOVALUE;
        goto L19; // [743] 753
    }
    else{
        _25858 = NOVALUE;
    }

    /** 						new_args = append(new_args, parm)*/
    RefDS(_parm_49376);
    Append(&_new_args_49374, _new_args_49374, _parm_49376);
L19: 
L18: 
L16: 
L14: 

    /** 		in = gets( fn )*/
    DeRefi(_in_49370);
    _in_49370 = EGets(_fn_49369);

    /** 	end while*/
    goto L5; // [765] 128
L6: 

    /** 	close(fn)*/
    EClose(_fn_49369);

    /** 	return new_args*/
    DeRefDS(_file_49368);
    DeRefi(_in_49370);
    DeRef(_conf_path_49373);
    DeRefi(_arg_49375);
    DeRefi(_parm_49376);
    DeRef(_section_49377);
    _25798 = NOVALUE;
    DeRef(_25803);
    _25803 = NOVALUE;
    DeRef(_25809);
    _25809 = NOVALUE;
    _25817 = NOVALUE;
    _25819 = NOVALUE;
    DeRef(_25823);
    _25823 = NOVALUE;
    DeRef(_25825);
    _25825 = NOVALUE;
    _25857 = NOVALUE;
    return _new_args_49374;
    ;
}


int _38GetDefaultArgs(int _user_files_49541)
{
    int _env_49542 = NOVALUE;
    int _default_args_49543 = NOVALUE;
    int _conf_file_49544 = NOVALUE;
    int _cmd_options_49546 = NOVALUE;
    int _user_config_49552 = NOVALUE;
    int _25893 = NOVALUE;
    int _25892 = NOVALUE;
    int _25891 = NOVALUE;
    int _25883 = NOVALUE;
    int _25882 = NOVALUE;
    int _25880 = NOVALUE;
    int _25877 = NOVALUE;
    int _25876 = NOVALUE;
    int _25873 = NOVALUE;
    int _25872 = NOVALUE;
    int _25870 = NOVALUE;
    int _25868 = NOVALUE;
    int _25867 = NOVALUE;
    int _25863 = NOVALUE;
    int _25862 = NOVALUE;
    int _0, _1, _2;
    

    /** 	sequence default_args = {}*/
    RefDS(_21829);
    DeRef(_default_args_49543);
    _default_args_49543 = _21829;

    /** 	sequence conf_file = "eu.cfg"*/
    RefDS(_25770);
    DeRefi(_conf_file_49544);
    _conf_file_49544 = _25770;

    /** 	if loaded_config_inc_paths then return "" end if*/
    if (_38loaded_config_inc_paths_49218 == 0)
    {
        goto L1; // [21] 29
    }
    else{
    }
    RefDS(_21829);
    DeRefDS(_user_files_49541);
    DeRef(_env_49542);
    DeRefDS(_default_args_49543);
    DeRefDSi(_conf_file_49544);
    DeRef(_cmd_options_49546);
    return _21829;
L1: 

    /** 	loaded_config_inc_paths = 1*/
    _38loaded_config_inc_paths_49218 = 1;

    /** 	sequence cmd_options = get_options()*/
    _0 = _cmd_options_49546;
    _cmd_options_49546 = _39get_options();
    DeRef(_0);

    /** 	default_args = {}*/
    RefDS(_21829);
    DeRef(_default_args_49543);
    _default_args_49543 = _21829;

    /** 	for i = 1 to length( user_files ) do*/
    if (IS_SEQUENCE(_user_files_49541)){
            _25862 = SEQ_PTR(_user_files_49541)->length;
    }
    else {
        _25862 = 1;
    }
    {
        int _i_49550;
        _i_49550 = 1;
L2: 
        if (_i_49550 > _25862){
            goto L3; // [53] 92
        }

        /** 		sequence user_config = load_euphoria_config( user_files[i] )*/
        _2 = (int)SEQ_PTR(_user_files_49541);
        _25863 = (int)*(((s1_ptr)_2)->base + _i_49550);
        Ref(_25863);
        _0 = _user_config_49552;
        _user_config_49552 = _38load_euphoria_config(_25863);
        DeRef(_0);
        _25863 = NOVALUE;

        /** 		default_args = merge_parameters( user_config, default_args, cmd_options, 1 )*/
        RefDS(_user_config_49552);
        RefDS(_default_args_49543);
        RefDS(_cmd_options_49546);
        _0 = _default_args_49543;
        _default_args_49543 = _39merge_parameters(_user_config_49552, _default_args_49543, _cmd_options_49546, 1);
        DeRefDS(_0);
        DeRefDS(_user_config_49552);
        _user_config_49552 = NOVALUE;

        /** 	end for*/
        _i_49550 = _i_49550 + 1;
        goto L2; // [87] 60
L3: 
        ;
    }

    /** 	default_args = merge_parameters( load_euphoria_config("./" & conf_file), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_25867, _25866, _conf_file_49544);
    _25868 = _38load_euphoria_config(_25867);
    _25867 = NOVALUE;
    RefDS(_default_args_49543);
    RefDS(_cmd_options_49546);
    _0 = _default_args_49543;
    _default_args_49543 = _39merge_parameters(_25868, _default_args_49543, _cmd_options_49546, 1);
    DeRefDS(_0);
    _25868 = NOVALUE;

    /** 	env = strip_file_from_path( exe_path() )*/
    _25870 = _38exe_path();
    _0 = _env_49542;
    _env_49542 = _38strip_file_from_path(_25870);
    DeRef(_0);
    _25870 = NOVALUE;

    /** 	default_args = merge_parameters( load_euphoria_config( env & conf_file ), default_args, cmd_options, 1 )*/
    if (IS_SEQUENCE(_env_49542) && IS_ATOM(_conf_file_49544)) {
    }
    else if (IS_ATOM(_env_49542) && IS_SEQUENCE(_conf_file_49544)) {
        Ref(_env_49542);
        Prepend(&_25872, _conf_file_49544, _env_49542);
    }
    else {
        Concat((object_ptr)&_25872, _env_49542, _conf_file_49544);
    }
    _25873 = _38load_euphoria_config(_25872);
    _25872 = NOVALUE;
    RefDS(_default_args_49543);
    RefDS(_cmd_options_49546);
    _0 = _default_args_49543;
    _default_args_49543 = _39merge_parameters(_25873, _default_args_49543, _cmd_options_49546, 1);
    DeRefDS(_0);
    _25873 = NOVALUE;

    /** 	ifdef UNIX then*/

    /** 		default_args = merge_parameters( load_euphoria_config( "/etc/euphoria/" & conf_file ), default_args, cmd_options, 1 )*/
    Concat((object_ptr)&_25876, _25875, _conf_file_49544);
    _25877 = _38load_euphoria_config(_25876);
    _25876 = NOVALUE;
    RefDS(_default_args_49543);
    RefDS(_cmd_options_49546);
    _0 = _default_args_49543;
    _default_args_49543 = _39merge_parameters(_25877, _default_args_49543, _cmd_options_49546, 1);
    DeRefDS(_0);
    _25877 = NOVALUE;

    /** 		env = getenv( "HOME" )*/
    DeRef(_env_49542);
    _env_49542 = EGetEnv(_25741);

    /** 		if sequence(env) then*/
    _25880 = IS_SEQUENCE(_env_49542);
    if (_25880 == 0)
    {
        _25880 = NOVALUE;
        goto L4; // [170] 195
    }
    else{
        _25880 = NOVALUE;
    }

    /** 			default_args = merge_parameters( load_euphoria_config( env & "/." & conf_file ), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49544;
        concat_list[1] = _25881;
        concat_list[2] = _env_49542;
        Concat_N((object_ptr)&_25882, concat_list, 3);
    }
    _25883 = _38load_euphoria_config(_25882);
    _25882 = NOVALUE;
    RefDS(_default_args_49543);
    RefDS(_cmd_options_49546);
    _0 = _default_args_49543;
    _default_args_49543 = _39merge_parameters(_25883, _default_args_49543, _cmd_options_49546, 1);
    DeRefDS(_0);
    _25883 = NOVALUE;
L4: 

    /** 	env = get_eudir()*/
    _0 = _env_49542;
    _env_49542 = _13get_eudir();
    DeRef(_0);

    /** 	if sequence(env) then*/
    _25891 = IS_SEQUENCE(_env_49542);
    if (_25891 == 0)
    {
        _25891 = NOVALUE;
        goto L5; // [205] 230
    }
    else{
        _25891 = NOVALUE;
    }

    /** 		default_args = merge_parameters( load_euphoria_config(env & "/" & conf_file), default_args, cmd_options, 1 )*/
    {
        int concat_list[3];

        concat_list[0] = _conf_file_49544;
        concat_list[1] = _23277;
        concat_list[2] = _env_49542;
        Concat_N((object_ptr)&_25892, concat_list, 3);
    }
    _25893 = _38load_euphoria_config(_25892);
    _25892 = NOVALUE;
    RefDS(_default_args_49543);
    RefDS(_cmd_options_49546);
    _0 = _default_args_49543;
    _default_args_49543 = _39merge_parameters(_25893, _default_args_49543, _cmd_options_49546, 1);
    DeRefDS(_0);
    _25893 = NOVALUE;
L5: 

    /** 	return default_args*/
    DeRefDS(_user_files_49541);
    DeRef(_env_49542);
    DeRefi(_conf_file_49544);
    DeRef(_cmd_options_49546);
    return _default_args_49543;
    ;
}


int _38ConfPath(int _file_name_49596)
{
    int _file_path_49597 = NOVALUE;
    int _try_49598 = NOVALUE;
    int _25900 = NOVALUE;
    int _25896 = NOVALUE;
    int _25895 = NOVALUE;
    int _0, _1, _2;
    

    /** 	for i = 1 to length(config_inc_paths) do*/
    if (IS_SEQUENCE(_38config_inc_paths_49217)){
            _25895 = SEQ_PTR(_38config_inc_paths_49217)->length;
    }
    else {
        _25895 = 1;
    }
    {
        int _i_49600;
        _i_49600 = 1;
L1: 
        if (_i_49600 > _25895){
            goto L2; // [10] 60
        }

        /** 		file_path = config_inc_paths[i] & file_name*/
        _2 = (int)SEQ_PTR(_38config_inc_paths_49217);
        _25896 = (int)*(((s1_ptr)_2)->base + _i_49600);
        Concat((object_ptr)&_file_path_49597, _25896, _file_name_49596);
        _25896 = NOVALUE;
        _25896 = NOVALUE;

        /** 		try = open( file_path, "r" )*/
        _try_49598 = EOpen(_file_path_49597, _25777, 0);

        /** 		if try != -1 then*/
        if (_try_49598 == -1)
        goto L3; // [38] 53

        /** 			return {file_path, try}*/
        RefDS(_file_path_49597);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49597;
        ((int *)_2)[2] = _try_49598;
        _25900 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49596);
        DeRefDS(_file_path_49597);
        return _25900;
L3: 

        /** 	end for*/
        _i_49600 = _i_49600 + 1;
        goto L1; // [55] 17
L2: 
        ;
    }

    /** 	return -1*/
    DeRefDS(_file_name_49596);
    DeRef(_file_path_49597);
    DeRef(_25900);
    _25900 = NOVALUE;
    return -1;
    ;
}


int _38ScanPath(int _file_name_49610, int _env_49611, int _flag_49612)
{
    int _inc_path_49613 = NOVALUE;
    int _full_path_49614 = NOVALUE;
    int _file_path_49615 = NOVALUE;
    int _strings_49616 = NOVALUE;
    int _end_path_49617 = NOVALUE;
    int _start_path_49618 = NOVALUE;
    int _try_49619 = NOVALUE;
    int _use_cache_49620 = NOVALUE;
    int _pos_49621 = NOVALUE;
    int _25948 = NOVALUE;
    int _25947 = NOVALUE;
    int _25946 = NOVALUE;
    int _25945 = NOVALUE;
    int _25944 = NOVALUE;
    int _25943 = NOVALUE;
    int _25942 = NOVALUE;
    int _25941 = NOVALUE;
    int _25937 = NOVALUE;
    int _25936 = NOVALUE;
    int _25935 = NOVALUE;
    int _25934 = NOVALUE;
    int _25933 = NOVALUE;
    int _25932 = NOVALUE;
    int _25930 = NOVALUE;
    int _25928 = NOVALUE;
    int _25927 = NOVALUE;
    int _25925 = NOVALUE;
    int _25924 = NOVALUE;
    int _25923 = NOVALUE;
    int _25920 = NOVALUE;
    int _25919 = NOVALUE;
    int _25917 = NOVALUE;
    int _25916 = NOVALUE;
    int _25915 = NOVALUE;
    int _25910 = NOVALUE;
    int _25902 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_flag_49612)) {
        _1 = (long)(DBL_PTR(_flag_49612)->dbl);
        DeRefDS(_flag_49612);
        _flag_49612 = _1;
    }

    /** 	inc_path = getenv(env)*/
    DeRefi(_inc_path_49613);
    _inc_path_49613 = EGetEnv(_env_49611);

    /** 	if compare(inc_path,{})!=1 then -- nothing to do, just fail*/
    if (IS_ATOM_INT(_inc_path_49613) && IS_ATOM_INT(_21829)){
        _25902 = (_inc_path_49613 < _21829) ? -1 : (_inc_path_49613 > _21829);
    }
    else{
        _25902 = compare(_inc_path_49613, _21829);
    }
    if (_25902 == 1)
    goto L1; // [18] 29

    /** 		return -1*/
    DeRefDS(_file_name_49610);
    DeRefDS(_env_49611);
    DeRefi(_inc_path_49613);
    DeRef(_full_path_49614);
    DeRef(_file_path_49615);
    DeRef(_strings_49616);
    return -1;
L1: 

    /** 	num_var = find(env,cache_vars)*/
    _38num_var_49208 = find_from(_env_49611, _38cache_vars_49209, 1);

    /** 	use_cache = check_cache(env,inc_path)*/
    RefDS(_env_49611);
    Ref(_inc_path_49613);
    _use_cache_49620 = _38check_cache(_env_49611, _inc_path_49613);
    if (!IS_ATOM_INT(_use_cache_49620)) {
        _1 = (long)(DBL_PTR(_use_cache_49620)->dbl);
        DeRefDS(_use_cache_49620);
        _use_cache_49620 = _1;
    }

    /** 	inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_49613, _inc_path_49613, 58);

    /** 	file_name = SLASH & file_name*/
    Prepend(&_file_name_49610, _file_name_49610, 47);

    /** 	if flag then*/
    if (_flag_49612 == 0)
    {
        goto L2; // [65] 77
    }
    else{
    }

    /** 		file_name = include_subfolder & file_name*/
    Concat((object_ptr)&_file_name_49610, _38include_subfolder_49204, _file_name_49610);
L2: 

    /** 	strings = cache_substrings[num_var]*/
    DeRef(_strings_49616);
    _2 = (int)SEQ_PTR(_38cache_substrings_49211);
    _strings_49616 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    RefDS(_strings_49616);

    /** 	if use_cache then*/
    if (_use_cache_49620 == 0)
    {
        goto L3; // [91] 194
    }
    else{
    }

    /** 		for i=1 to length(strings) do*/
    if (IS_SEQUENCE(_strings_49616)){
            _25910 = SEQ_PTR(_strings_49616)->length;
    }
    else {
        _25910 = 1;
    }
    {
        int _i_49637;
        _i_49637 = 1;
L4: 
        if (_i_49637 > _25910){
            goto L5; // [99] 154
        }

        /** 			full_path = strings[i]*/
        DeRef(_full_path_49614);
        _2 = (int)SEQ_PTR(_strings_49616);
        _full_path_49614 = (int)*(((s1_ptr)_2)->base + _i_49637);
        Ref(_full_path_49614);

        /** 			file_path = full_path & file_name*/
        Concat((object_ptr)&_file_path_49615, _full_path_49614, _file_name_49610);

        /** 			try = open_locked(file_path)    */
        RefDS(_file_path_49615);
        _try_49619 = _13open_locked(_file_path_49615);
        if (!IS_ATOM_INT(_try_49619)) {
            _1 = (long)(DBL_PTR(_try_49619)->dbl);
            DeRefDS(_try_49619);
            _try_49619 = _1;
        }

        /** 			if try != -1 then*/
        if (_try_49619 == -1)
        goto L6; // [130] 145

        /** 				return {file_path,try}*/
        RefDS(_file_path_49615);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49615;
        ((int *)_2)[2] = _try_49619;
        _25915 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49610);
        DeRefDS(_env_49611);
        DeRefi(_inc_path_49613);
        DeRefDS(_full_path_49614);
        DeRefDS(_file_path_49615);
        DeRefDS(_strings_49616);
        return _25915;
L6: 

        /** 			ifdef WINDOWS then */

        /** 		end for*/
        _i_49637 = _i_49637 + 1;
        goto L4; // [149] 106
L5: 
        ;
    }

    /** 		if cache_complete[num_var] then -- nothing to scan*/
    _2 = (int)SEQ_PTR(_38cache_complete_49215);
    _25916 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    if (_25916 == 0)
    {
        _25916 = NOVALUE;
        goto L7; // [164] 176
    }
    else{
        _25916 = NOVALUE;
    }

    /** 			return -1*/
    DeRefDS(_file_name_49610);
    DeRefDS(_env_49611);
    DeRefi(_inc_path_49613);
    DeRef(_full_path_49614);
    DeRef(_file_path_49615);
    DeRef(_strings_49616);
    DeRef(_25915);
    _25915 = NOVALUE;
    return -1;
    goto L8; // [173] 200
L7: 

    /** 			pos = cache_delims[num_var]+1 -- scan remainder, starting from as far sa possible*/
    _2 = (int)SEQ_PTR(_38cache_delims_49216);
    _25917 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    _pos_49621 = _25917 + 1;
    _25917 = NOVALUE;
    goto L8; // [191] 200
L3: 

    /** 		pos = 1*/
    _pos_49621 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_49618 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_49613)){
            _25919 = SEQ_PTR(_inc_path_49613)->length;
    }
    else {
        _25919 = 1;
    }
    {
        int _p_49653;
        _p_49653 = _pos_49621;
L9: 
        if (_p_49653 > _25919){
            goto LA; // [212] 460
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_49613);
        _25920 = (int)*(((s1_ptr)_2)->base + _p_49653);
        if (_25920 != 58)
        goto LB; // [227] 409

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_38cache_delims_49216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        *(int *)_2 = _p_49653;

        /** 			end_path = p-1*/
        _end_path_49617 = _p_49653 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path], " \t" & SLASH_CHARS) do*/
LC: 
        _25923 = (_end_path_49617 >= _start_path_49618);
        if (_25923 == 0) {
            goto LD; // [256] 290
        }
        _2 = (int)SEQ_PTR(_inc_path_49613);
        _25925 = (int)*(((s1_ptr)_2)->base + _end_path_49617);
        Concat((object_ptr)&_25927, _25926, _36SLASH_CHARS_14019);
        _25928 = find_from(_25925, _25927, 1);
        _25925 = NOVALUE;
        DeRefDS(_25927);
        _25927 = NOVALUE;
        if (_25928 == 0)
        {
            _25928 = NOVALUE;
            goto LD; // [276] 290
        }
        else{
            _25928 = NOVALUE;
        }

        /** 				end_path-=1*/
        _end_path_49617 = _end_path_49617 - 1;

        /** 			end while*/
        goto LC; // [287] 252
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_49618 == 0) {
            goto LE; // [292] 453
        }
        if (_end_path_49617 == 0)
        {
            goto LE; // [297] 453
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_49614;
        RHS_Slice(_inc_path_49613, _start_path_49618, _end_path_49617);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        _25932 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        RefDS(_full_path_49614);
        Append(&_25933, _25932, _full_path_49614);
        _25932 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49211 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25933;
        if( _1 != _25933 ){
            DeRefDS(_1);
        }
        _25933 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        _25934 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        if (IS_SEQUENCE(_25934) && IS_ATOM(_start_path_49618)) {
            Append(&_25935, _25934, _start_path_49618);
        }
        else if (IS_ATOM(_25934) && IS_SEQUENCE(_start_path_49618)) {
        }
        else {
            Concat((object_ptr)&_25935, _25934, _start_path_49618);
            _25934 = NOVALUE;
        }
        _25934 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49212 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25935;
        if( _1 != _25935 ){
            DeRef(_1);
        }
        _25935 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25936 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        if (IS_SEQUENCE(_25936) && IS_ATOM(_end_path_49617)) {
            Append(&_25937, _25936, _end_path_49617);
        }
        else if (IS_ATOM(_25936) && IS_SEQUENCE(_end_path_49617)) {
        }
        else {
            Concat((object_ptr)&_25937, _25936, _end_path_49617);
            _25936 = NOVALUE;
        }
        _25936 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49213 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25937;
        if( _1 != _25937 ){
            DeRef(_1);
        }
        _25937 = NOVALUE;

        /** 				file_path = full_path & file_name  */
        Concat((object_ptr)&_file_path_49615, _full_path_49614, _file_name_49610);

        /** 				try = open_locked(file_path)*/
        RefDS(_file_path_49615);
        _try_49619 = _13open_locked(_file_path_49615);
        if (!IS_ATOM_INT(_try_49619)) {
            _1 = (long)(DBL_PTR(_try_49619)->dbl);
            DeRefDS(_try_49619);
            _try_49619 = _1;
        }

        /** 				if try != -1 then -- valid path, no point trying to convert*/
        if (_try_49619 == -1)
        goto LF; // [381] 398

        /** 					ifdef WINDOWS then*/

        /** 					return {file_path,try}*/
        RefDS(_file_path_49615);
        _1 = NewS1(2);
        _2 = (int)((s1_ptr)_1)->base;
        ((int *)_2)[1] = _file_path_49615;
        ((int *)_2)[2] = _try_49619;
        _25941 = MAKE_SEQ(_1);
        DeRefDS(_file_name_49610);
        DeRefDS(_env_49611);
        DeRefi(_inc_path_49613);
        DeRefDSi(_full_path_49614);
        DeRefDS(_file_path_49615);
        DeRef(_strings_49616);
        DeRef(_25915);
        _25915 = NOVALUE;
        _25920 = NOVALUE;
        DeRef(_25923);
        _25923 = NOVALUE;
        return _25941;
LF: 

        /** 				ifdef WINDOWS then*/

        /** 				start_path = 0*/
        _start_path_49618 = 0;
        goto LE; // [406] 453
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _25942 = (_start_path_49618 == 0);
        if (_25942 == 0) {
            goto L10; // [414] 452
        }
        _2 = (int)SEQ_PTR(_inc_path_49613);
        _25944 = (int)*(((s1_ptr)_2)->base + _p_49653);
        _25945 = (_25944 != 32);
        _25944 = NOVALUE;
        if (_25945 == 0) {
            DeRef(_25946);
            _25946 = 0;
            goto L11; // [426] 442
        }
        _2 = (int)SEQ_PTR(_inc_path_49613);
        _25947 = (int)*(((s1_ptr)_2)->base + _p_49653);
        _25948 = (_25947 != 9);
        _25947 = NOVALUE;
        _25946 = (_25948 != 0);
L11: 
        if (_25946 == 0)
        {
            _25946 = NOVALUE;
            goto L10; // [443] 452
        }
        else{
            _25946 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_49618 = _p_49653;
L10: 
LE: 

        /** 	end for*/
        _p_49653 = _p_49653 + 1;
        goto L9; // [455] 219
LA: 
        ;
    }

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_38cache_complete_49215);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49215 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
    *(int *)_2 = 1;

    /** 	return -1*/
    DeRefDS(_file_name_49610);
    DeRefDS(_env_49611);
    DeRefi(_inc_path_49613);
    DeRef(_full_path_49614);
    DeRef(_file_path_49615);
    DeRef(_strings_49616);
    DeRef(_25915);
    _25915 = NOVALUE;
    _25920 = NOVALUE;
    DeRef(_25923);
    _25923 = NOVALUE;
    DeRef(_25941);
    _25941 = NOVALUE;
    DeRef(_25942);
    _25942 = NOVALUE;
    DeRef(_25945);
    _25945 = NOVALUE;
    DeRef(_25948);
    _25948 = NOVALUE;
    return -1;
    ;
}


int _38Include_paths(int _add_converted_49695)
{
    int _status_49696 = NOVALUE;
    int _pos_49697 = NOVALUE;
    int _inc_path_49698 = NOVALUE;
    int _full_path_49699 = NOVALUE;
    int _start_path_49700 = NOVALUE;
    int _end_path_49701 = NOVALUE;
    int _eudir_path_49717 = NOVALUE;
    int _25994 = NOVALUE;
    int _25993 = NOVALUE;
    int _25992 = NOVALUE;
    int _25991 = NOVALUE;
    int _25990 = NOVALUE;
    int _25989 = NOVALUE;
    int _25988 = NOVALUE;
    int _25987 = NOVALUE;
    int _25986 = NOVALUE;
    int _25985 = NOVALUE;
    int _25984 = NOVALUE;
    int _25983 = NOVALUE;
    int _25982 = NOVALUE;
    int _25981 = NOVALUE;
    int _25979 = NOVALUE;
    int _25977 = NOVALUE;
    int _25976 = NOVALUE;
    int _25975 = NOVALUE;
    int _25974 = NOVALUE;
    int _25973 = NOVALUE;
    int _25970 = NOVALUE;
    int _25969 = NOVALUE;
    int _25967 = NOVALUE;
    int _25965 = NOVALUE;
    int _25963 = NOVALUE;
    int _25962 = NOVALUE;
    int _25960 = NOVALUE;
    int _25957 = NOVALUE;
    int _25955 = NOVALUE;
    int _25950 = NOVALUE;
    int _25949 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_add_converted_49695)) {
        _1 = (long)(DBL_PTR(_add_converted_49695)->dbl);
        DeRefDS(_add_converted_49695);
        _add_converted_49695 = _1;
    }

    /** 	if length(include_Paths) then*/
    if (IS_SEQUENCE(_38include_Paths_49692)){
            _25949 = SEQ_PTR(_38include_Paths_49692)->length;
    }
    else {
        _25949 = 1;
    }
    if (_25949 == 0)
    {
        _25949 = NOVALUE;
        goto L1; // [10] 22
    }
    else{
        _25949 = NOVALUE;
    }

    /** 		return include_Paths*/
    RefDS(_38include_Paths_49692);
    DeRefi(_inc_path_49698);
    DeRefi(_full_path_49699);
    DeRef(_eudir_path_49717);
    return _38include_Paths_49692;
L1: 

    /** 	include_Paths = append(config_inc_paths, current_dir())*/
    _25950 = _14current_dir();
    Ref(_25950);
    Append(&_38include_Paths_49692, _38config_inc_paths_49217, _25950);
    DeRef(_25950);
    _25950 = NOVALUE;

    /** 	num_var = find("EUINC", cache_vars)*/
    _38num_var_49208 = find_from(_25952, _38cache_vars_49209, 1);

    /** 	inc_path = getenv("EUINC")*/
    DeRefi(_inc_path_49698);
    _inc_path_49698 = EGetEnv(_25952);

    /** 	if atom(inc_path) then*/
    _25955 = IS_ATOM(_inc_path_49698);
    if (_25955 == 0)
    {
        _25955 = NOVALUE;
        goto L2; // [52] 61
    }
    else{
        _25955 = NOVALUE;
    }

    /** 		inc_path = ""*/
    RefDS(_21829);
    DeRefi(_inc_path_49698);
    _inc_path_49698 = _21829;
L2: 

    /** 	status = check_cache("EUINC", inc_path)*/
    RefDS(_25952);
    Ref(_inc_path_49698);
    _status_49696 = _38check_cache(_25952, _inc_path_49698);
    if (!IS_ATOM_INT(_status_49696)) {
        _1 = (long)(DBL_PTR(_status_49696)->dbl);
        DeRefDS(_status_49696);
        _status_49696 = _1;
    }

    /** 	if length(inc_path) then*/
    if (IS_SEQUENCE(_inc_path_49698)){
            _25957 = SEQ_PTR(_inc_path_49698)->length;
    }
    else {
        _25957 = 1;
    }
    if (_25957 == 0)
    {
        _25957 = NOVALUE;
        goto L3; // [75] 87
    }
    else{
        _25957 = NOVALUE;
    }

    /** 		inc_path = append(inc_path, PATH_SEPARATOR)*/
    Append(&_inc_path_49698, _inc_path_49698, 58);
L3: 

    /** 	object eudir_path = get_eudir()*/
    _0 = _eudir_path_49717;
    _eudir_path_49717 = _13get_eudir();
    DeRef(_0);

    /** 	if sequence(eudir_path) then*/
    _25960 = IS_SEQUENCE(_eudir_path_49717);
    if (_25960 == 0)
    {
        _25960 = NOVALUE;
        goto L4; // [97] 117
    }
    else{
        _25960 = NOVALUE;
    }

    /** 		include_Paths = append(include_Paths, sprintf("%s/include", { eudir_path }))*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_eudir_path_49717);
    *((int *)(_2+4)) = _eudir_path_49717;
    _25962 = MAKE_SEQ(_1);
    _25963 = EPrintf(-9999999, _25961, _25962);
    DeRefDS(_25962);
    _25962 = NOVALUE;
    RefDS(_25963);
    Append(&_38include_Paths_49692, _38include_Paths_49692, _25963);
    DeRefDS(_25963);
    _25963 = NOVALUE;
L4: 

    /** 	if status then*/
    if (_status_49696 == 0)
    {
        goto L5; // [119] 161
    }
    else{
    }

    /** 		if cache_complete[num_var] then*/
    _2 = (int)SEQ_PTR(_38cache_complete_49215);
    _25965 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    if (_25965 == 0)
    {
        _25965 = NOVALUE;
        goto L6; // [132] 144
    }
    else{
        _25965 = NOVALUE;
    }

    /** 			goto "cache done"*/
    goto G7;
L6: 

    /** 		pos = cache_delims[num_var]+1*/
    _2 = (int)SEQ_PTR(_38cache_delims_49216);
    _25967 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    _pos_49697 = _25967 + 1;
    _25967 = NOVALUE;
    goto L8; // [158] 167
L5: 

    /**         pos = 1*/
    _pos_49697 = 1;
L8: 

    /** 	start_path = 0*/
    _start_path_49700 = 0;

    /** 	for p = pos to length(inc_path) do*/
    if (IS_SEQUENCE(_inc_path_49698)){
            _25969 = SEQ_PTR(_inc_path_49698)->length;
    }
    else {
        _25969 = 1;
    }
    {
        int _p_49734;
        _p_49734 = _pos_49697;
L9: 
        if (_p_49734 > _25969){
            goto LA; // [179] 394
        }

        /** 		if inc_path[p] = PATH_SEPARATOR then*/
        _2 = (int)SEQ_PTR(_inc_path_49698);
        _25970 = (int)*(((s1_ptr)_2)->base + _p_49734);
        if (_25970 != 58)
        goto LB; // [194] 343

        /** 			cache_delims[num_var] = p*/
        _2 = (int)SEQ_PTR(_38cache_delims_49216);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_delims_49216 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        *(int *)_2 = _p_49734;

        /** 			end_path = p-1*/
        _end_path_49701 = _p_49734 - 1;

        /** 			while end_path >= start_path and find(inc_path[end_path]," \t" & SLASH_CHARS) do*/
LC: 
        _25973 = (_end_path_49701 >= _start_path_49700);
        if (_25973 == 0) {
            goto LD; // [223] 257
        }
        _2 = (int)SEQ_PTR(_inc_path_49698);
        _25975 = (int)*(((s1_ptr)_2)->base + _end_path_49701);
        Concat((object_ptr)&_25976, _25926, _36SLASH_CHARS_14019);
        _25977 = find_from(_25975, _25976, 1);
        _25975 = NOVALUE;
        DeRefDS(_25976);
        _25976 = NOVALUE;
        if (_25977 == 0)
        {
            _25977 = NOVALUE;
            goto LD; // [243] 257
        }
        else{
            _25977 = NOVALUE;
        }

        /** 				end_path -= 1*/
        _end_path_49701 = _end_path_49701 - 1;

        /** 			end while*/
        goto LC; // [254] 219
LD: 

        /** 			if start_path and end_path then*/
        if (_start_path_49700 == 0) {
            goto LE; // [259] 387
        }
        if (_end_path_49701 == 0)
        {
            goto LE; // [264] 387
        }
        else{
        }

        /** 				full_path = inc_path[start_path..end_path]*/
        rhs_slice_target = (object_ptr)&_full_path_49699;
        RHS_Slice(_inc_path_49698, _start_path_49700, _end_path_49701);

        /** 				cache_substrings[num_var] = append(cache_substrings[num_var],full_path)*/
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        _25981 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        RefDS(_full_path_49699);
        Append(&_25982, _25981, _full_path_49699);
        _25981 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_substrings_49211);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_substrings_49211 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25982;
        if( _1 != _25982 ){
            DeRefDS(_1);
        }
        _25982 = NOVALUE;

        /** 				cache_starts[num_var] &= start_path*/
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        _25983 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        if (IS_SEQUENCE(_25983) && IS_ATOM(_start_path_49700)) {
            Append(&_25984, _25983, _start_path_49700);
        }
        else if (IS_ATOM(_25983) && IS_SEQUENCE(_start_path_49700)) {
        }
        else {
            Concat((object_ptr)&_25984, _25983, _start_path_49700);
            _25983 = NOVALUE;
        }
        _25983 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_starts_49212);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_starts_49212 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25984;
        if( _1 != _25984 ){
            DeRef(_1);
        }
        _25984 = NOVALUE;

        /** 				cache_ends[num_var] &= end_path*/
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        _25985 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
        if (IS_SEQUENCE(_25985) && IS_ATOM(_end_path_49701)) {
            Append(&_25986, _25985, _end_path_49701);
        }
        else if (IS_ATOM(_25985) && IS_SEQUENCE(_end_path_49701)) {
        }
        else {
            Concat((object_ptr)&_25986, _25985, _end_path_49701);
            _25985 = NOVALUE;
        }
        _25985 = NOVALUE;
        _2 = (int)SEQ_PTR(_38cache_ends_49213);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _38cache_ends_49213 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
        _1 = *(int *)_2;
        *(int *)_2 = _25986;
        if( _1 != _25986 ){
            DeRef(_1);
        }
        _25986 = NOVALUE;

        /** 				ifdef WINDOWS then*/

        /** 				start_path = 0*/
        _start_path_49700 = 0;
        goto LE; // [340] 387
LB: 

        /** 		elsif not start_path and (inc_path[p] != ' ' and inc_path[p] != '\t') then*/
        _25987 = (_start_path_49700 == 0);
        if (_25987 == 0) {
            goto LF; // [348] 386
        }
        _2 = (int)SEQ_PTR(_inc_path_49698);
        _25989 = (int)*(((s1_ptr)_2)->base + _p_49734);
        _25990 = (_25989 != 32);
        _25989 = NOVALUE;
        if (_25990 == 0) {
            DeRef(_25991);
            _25991 = 0;
            goto L10; // [360] 376
        }
        _2 = (int)SEQ_PTR(_inc_path_49698);
        _25992 = (int)*(((s1_ptr)_2)->base + _p_49734);
        _25993 = (_25992 != 9);
        _25992 = NOVALUE;
        _25991 = (_25993 != 0);
L10: 
        if (_25991 == 0)
        {
            _25991 = NOVALUE;
            goto LF; // [377] 386
        }
        else{
            _25991 = NOVALUE;
        }

        /** 			start_path = p*/
        _start_path_49700 = _p_49734;
LF: 
LE: 

        /** 	end for*/
        _p_49734 = _p_49734 + 1;
        goto L9; // [389] 186
LA: 
        ;
    }

    /** label "cache done"*/
G7:

    /** 	include_Paths &= cache_substrings[num_var]*/
    _2 = (int)SEQ_PTR(_38cache_substrings_49211);
    _25994 = (int)*(((s1_ptr)_2)->base + _38num_var_49208);
    Concat((object_ptr)&_38include_Paths_49692, _38include_Paths_49692, _25994);
    _25994 = NOVALUE;

    /** 	cache_complete[num_var] = 1*/
    _2 = (int)SEQ_PTR(_38cache_complete_49215);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _38cache_complete_49215 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _38num_var_49208);
    *(int *)_2 = 1;

    /** 	ifdef WINDOWS then*/

    /** 	return include_Paths*/
    RefDS(_38include_Paths_49692);
    DeRefi(_inc_path_49698);
    DeRefi(_full_path_49699);
    DeRef(_eudir_path_49717);
    _25970 = NOVALUE;
    DeRef(_25973);
    _25973 = NOVALUE;
    DeRef(_25987);
    _25987 = NOVALUE;
    DeRef(_25990);
    _25990 = NOVALUE;
    DeRef(_25993);
    _25993 = NOVALUE;
    return _38include_Paths_49692;
    ;
}


int _38e_path_find(int _name_49770)
{
    int _scan_result_49771 = NOVALUE;
    int _26004 = NOVALUE;
    int _26003 = NOVALUE;
    int _26002 = NOVALUE;
    int _25999 = NOVALUE;
    int _25998 = NOVALUE;
    int _25997 = NOVALUE;
    int _25996 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if file_exists(name) then*/
    RefDS(_name_49770);
    _25996 = _14file_exists(_name_49770);
    if (_25996 == 0) {
        DeRef(_25996);
        _25996 = NOVALUE;
        goto L1; // [9] 19
    }
    else {
        if (!IS_ATOM_INT(_25996) && DBL_PTR(_25996)->dbl == 0.0){
            DeRef(_25996);
            _25996 = NOVALUE;
            goto L1; // [9] 19
        }
        DeRef(_25996);
        _25996 = NOVALUE;
    }
    DeRef(_25996);
    _25996 = NOVALUE;

    /** 		return name*/
    DeRef(_scan_result_49771);
    return _name_49770;
L1: 

    /** 	for i = 1 to length(SLASH_CHARS) do*/
    if (IS_SEQUENCE(_36SLASH_CHARS_14019)){
            _25997 = SEQ_PTR(_36SLASH_CHARS_14019)->length;
    }
    else {
        _25997 = 1;
    }
    {
        int _i_49776;
        _i_49776 = 1;
L2: 
        if (_i_49776 > _25997){
            goto L3; // [26] 63
        }

        /** 		if find(SLASH_CHARS[i], name) then*/
        _2 = (int)SEQ_PTR(_36SLASH_CHARS_14019);
        _25998 = (int)*(((s1_ptr)_2)->base + _i_49776);
        _25999 = find_from(_25998, _name_49770, 1);
        _25998 = NOVALUE;
        if (_25999 == 0)
        {
            _25999 = NOVALUE;
            goto L4; // [46] 56
        }
        else{
            _25999 = NOVALUE;
        }

        /** 			return -1*/
        DeRefDS(_name_49770);
        DeRef(_scan_result_49771);
        return -1;
L4: 

        /** 	end for*/
        _i_49776 = _i_49776 + 1;
        goto L2; // [58] 33
L3: 
        ;
    }

    /** 	scan_result = ScanPath(name, "PATH", 0)*/
    RefDS(_name_49770);
    RefDS(_26000);
    _0 = _scan_result_49771;
    _scan_result_49771 = _38ScanPath(_name_49770, _26000, 0);
    DeRef(_0);

    /** 	if sequence(scan_result) then*/
    _26002 = IS_SEQUENCE(_scan_result_49771);
    if (_26002 == 0)
    {
        _26002 = NOVALUE;
        goto L5; // [76] 98
    }
    else{
        _26002 = NOVALUE;
    }

    /** 		close(scan_result[2])*/
    _2 = (int)SEQ_PTR(_scan_result_49771);
    _26003 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_ATOM_INT(_26003))
    EClose(_26003);
    else
    EClose((int)DBL_PTR(_26003)->dbl);
    _26003 = NOVALUE;

    /** 		return scan_result[1]*/
    _2 = (int)SEQ_PTR(_scan_result_49771);
    _26004 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_26004);
    DeRefDS(_name_49770);
    DeRef(_scan_result_49771);
    return _26004;
L5: 

    /** 	return -1*/
    DeRefDS(_name_49770);
    DeRef(_scan_result_49771);
    _26004 = NOVALUE;
    return -1;
    ;
}



// 0xE35152A4
