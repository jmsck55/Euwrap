// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _44GetMsgText(int _MsgNum_20835, int _WithNum_20836, int _Args_20837)
{
    int _idx_20838 = NOVALUE;
    int _msgtext_20839 = NOVALUE;
    int _12064 = NOVALUE;
    int _12063 = NOVALUE;
    int _12059 = NOVALUE;
    int _12058 = NOVALUE;
    int _12056 = NOVALUE;
    int _12054 = NOVALUE;
    int _12052 = NOVALUE;
    int _12051 = NOVALUE;
    int _12050 = NOVALUE;
    int _12049 = NOVALUE;
    int _0, _1, _2;
    
    if (!IS_ATOM_INT(_MsgNum_20835)) {
        _1 = (long)(DBL_PTR(_MsgNum_20835)->dbl);
        DeRefDS(_MsgNum_20835);
        _MsgNum_20835 = _1;
    }

    /** 	integer idx = 1*/
    _idx_20838 = 1;

    /** 	msgtext = get_text( MsgNum, LocalizeQual, LocalDB )*/
    RefDS(_13LocalizeQual_10657);
    RefDS(_13LocalDB_10658);
    _0 = _msgtext_20839;
    _msgtext_20839 = _45get_text(_MsgNum_20835, _13LocalizeQual_10657, _13LocalDB_10658);
    DeRef(_0);

    /** 	if atom(msgtext) then*/
    _12049 = IS_ATOM(_msgtext_20839);
    if (_12049 == 0)
    {
        _12049 = NOVALUE;
        goto L1; // [27] 90
    }
    else{
        _12049 = NOVALUE;
    }

    /** 		for i = 1 to length(StdErrMsgs) do*/
    _12050 = 354;
    {
        int _i_20847;
        _i_20847 = 1;
L2: 
        if (_i_20847 > 354){
            goto L3; // [37] 77
        }

        /** 			if StdErrMsgs[i][1] = MsgNum then*/
        _2 = (int)SEQ_PTR(_44StdErrMsgs_19826);
        _12051 = (int)*(((s1_ptr)_2)->base + _i_20847);
        _2 = (int)SEQ_PTR(_12051);
        _12052 = (int)*(((s1_ptr)_2)->base + 1);
        _12051 = NOVALUE;
        if (binary_op_a(NOTEQ, _12052, _MsgNum_20835)){
            _12052 = NOVALUE;
            goto L4; // [56] 70
        }
        _12052 = NOVALUE;

        /** 				idx = i*/
        _idx_20838 = _i_20847;

        /** 				exit*/
        goto L3; // [67] 77
L4: 

        /** 		end for*/
        _i_20847 = _i_20847 + 1;
        goto L2; // [72] 44
L3: 
        ;
    }

    /** 		msgtext = StdErrMsgs[idx][2]*/
    _2 = (int)SEQ_PTR(_44StdErrMsgs_19826);
    _12054 = (int)*(((s1_ptr)_2)->base + _idx_20838);
    DeRef(_msgtext_20839);
    _2 = (int)SEQ_PTR(_12054);
    _msgtext_20839 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_msgtext_20839);
    _12054 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12056 = IS_ATOM(_Args_20837);
    if (_12056 != 0) {
        goto L5; // [95] 111
    }
    if (IS_SEQUENCE(_Args_20837)){
            _12058 = SEQ_PTR(_Args_20837)->length;
    }
    else {
        _12058 = 1;
    }
    _12059 = (_12058 != 0);
    _12058 = NOVALUE;
    if (_12059 == 0)
    {
        DeRef(_12059);
        _12059 = NOVALUE;
        goto L6; // [107] 119
    }
    else{
        DeRef(_12059);
        _12059 = NOVALUE;
    }
L5: 

    /** 		msgtext = format(msgtext, Args)*/
    Ref(_msgtext_20839);
    Ref(_Args_20837);
    _0 = _msgtext_20839;
    _msgtext_20839 = _18format(_msgtext_20839, _Args_20837);
    DeRef(_0);
L6: 

    /** 	if WithNum != 0 then*/
    if (_WithNum_20836 == 0)
    goto L7; // [121] 142

    /** 		return sprintf("<%04d>:: %s", {MsgNum, msgtext})*/
    Ref(_msgtext_20839);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _MsgNum_20835;
    ((int *)_2)[2] = _msgtext_20839;
    _12063 = MAKE_SEQ(_1);
    _12064 = EPrintf(-9999999, _12062, _12063);
    DeRefDS(_12063);
    _12063 = NOVALUE;
    DeRef(_Args_20837);
    DeRef(_msgtext_20839);
    return _12064;
    goto L8; // [139] 149
L7: 

    /** 		return msgtext*/
    DeRef(_Args_20837);
    DeRef(_12064);
    _12064 = NOVALUE;
    return _msgtext_20839;
L8: 
    ;
}


void _44ShowMsg(int _Cons_20870, int _Msg_20871, int _Args_20872, int _NL_20873)
{
    int _12071 = NOVALUE;
    int _12070 = NOVALUE;
    int _12068 = NOVALUE;
    int _12066 = NOVALUE;
    int _12065 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(Msg) then*/
    _12065 = 1;
    if (_12065 == 0)
    {
        _12065 = NOVALUE;
        goto L1; // [10] 25
    }
    else{
        _12065 = NOVALUE;
    }

    /** 		Msg = GetMsgText(floor(Msg), 0)*/
    _12066 = e_floor(_Msg_20871);
    RefDS(_5);
    _Msg_20871 = _44GetMsgText(_12066, 0, _5);
    _12066 = NOVALUE;
L1: 

    /** 	if atom(Args) or length(Args) != 0 then*/
    _12068 = IS_ATOM(_Args_20872);
    if (_12068 != 0) {
        goto L2; // [30] 46
    }
    if (IS_SEQUENCE(_Args_20872)){
            _12070 = SEQ_PTR(_Args_20872)->length;
    }
    else {
        _12070 = 1;
    }
    _12071 = (_12070 != 0);
    _12070 = NOVALUE;
    if (_12071 == 0)
    {
        DeRef(_12071);
        _12071 = NOVALUE;
        goto L3; // [42] 54
    }
    else{
        DeRef(_12071);
        _12071 = NOVALUE;
    }
L2: 

    /** 		Msg = format(Msg, Args)*/
    Ref(_Msg_20871);
    Ref(_Args_20872);
    _0 = _Msg_20871;
    _Msg_20871 = _18format(_Msg_20871, _Args_20872);
    DeRef(_0);
L3: 

    /** 	puts(Cons, Msg)*/
    EPuts(_Cons_20870, _Msg_20871); // DJP 

    /** 	if NL then*/
    if (_NL_20873 == 0)
    {
        goto L4; // [61] 70
    }
    else{
    }

    /** 		puts(Cons, '\n')*/
    EPuts(_Cons_20870, 10); // DJP 
L4: 

    /** end procedure*/
    DeRef(_Msg_20871);
    DeRef(_Args_20872);
    return;
    ;
}



// 0x517A5E85
