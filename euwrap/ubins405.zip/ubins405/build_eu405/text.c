// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _18sprint(int _x_5683)
{
    int _s_5684 = NOVALUE;
    int _2963 = NOVALUE;
    int _2961 = NOVALUE;
    int _2960 = NOVALUE;
    int _2957 = NOVALUE;
    int _2956 = NOVALUE;
    int _2954 = NOVALUE;
    int _2953 = NOVALUE;
    int _2952 = NOVALUE;
    int _2951 = NOVALUE;
    int _2950 = NOVALUE;
    int _2949 = NOVALUE;
    int _2948 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(x) then*/
    _2948 = IS_ATOM(_x_5683);
    if (_2948 == 0)
    {
        _2948 = NOVALUE;
        goto L1; // [6] 22
    }
    else{
        _2948 = NOVALUE;
    }

    /** 		return sprintf("%.10g", x)*/
    _2949 = EPrintf(-9999999, _614, _x_5683);
    DeRef(_x_5683);
    DeRef(_s_5684);
    return _2949;
    goto L2; // [19] 137
L1: 

    /** 		s = "{"*/
    RefDS(_1127);
    DeRef(_s_5684);
    _s_5684 = _1127;

    /** 		for i = 1 to length(x) do*/
    if (IS_SEQUENCE(_x_5683)){
            _2950 = SEQ_PTR(_x_5683)->length;
    }
    else {
        _2950 = 1;
    }
    {
        int _i_5690;
        _i_5690 = 1;
L3: 
        if (_i_5690 > _2950){
            goto L4; // [34] 98
        }

        /** 			if atom(x[i]) then*/
        _2 = (int)SEQ_PTR(_x_5683);
        _2951 = (int)*(((s1_ptr)_2)->base + _i_5690);
        _2952 = IS_ATOM(_2951);
        _2951 = NOVALUE;
        if (_2952 == 0)
        {
            _2952 = NOVALUE;
            goto L5; // [50] 70
        }
        else{
            _2952 = NOVALUE;
        }

        /** 				s &= sprintf("%.10g", x[i])*/
        _2 = (int)SEQ_PTR(_x_5683);
        _2953 = (int)*(((s1_ptr)_2)->base + _i_5690);
        _2954 = EPrintf(-9999999, _614, _2953);
        _2953 = NOVALUE;
        Concat((object_ptr)&_s_5684, _s_5684, _2954);
        DeRefDS(_2954);
        _2954 = NOVALUE;
        goto L6; // [67] 85
L5: 

        /** 				s &= sprint(x[i])*/
        _2 = (int)SEQ_PTR(_x_5683);
        _2956 = (int)*(((s1_ptr)_2)->base + _i_5690);
        Ref(_2956);
        _2957 = _18sprint(_2956);
        _2956 = NOVALUE;
        if (IS_SEQUENCE(_s_5684) && IS_ATOM(_2957)) {
            Ref(_2957);
            Append(&_s_5684, _s_5684, _2957);
        }
        else if (IS_ATOM(_s_5684) && IS_SEQUENCE(_2957)) {
        }
        else {
            Concat((object_ptr)&_s_5684, _s_5684, _2957);
        }
        DeRef(_2957);
        _2957 = NOVALUE;
L6: 

        /** 			s &= ','*/
        Append(&_s_5684, _s_5684, 44);

        /** 		end for*/
        _i_5690 = _i_5690 + 1;
        goto L3; // [93] 41
L4: 
        ;
    }

    /** 		if s[$] = ',' then*/
    if (IS_SEQUENCE(_s_5684)){
            _2960 = SEQ_PTR(_s_5684)->length;
    }
    else {
        _2960 = 1;
    }
    _2 = (int)SEQ_PTR(_s_5684);
    _2961 = (int)*(((s1_ptr)_2)->base + _2960);
    if (binary_op_a(NOTEQ, _2961, 44)){
        _2961 = NOVALUE;
        goto L7; // [107] 123
    }
    _2961 = NOVALUE;

    /** 			s[$] = '}'*/
    if (IS_SEQUENCE(_s_5684)){
            _2963 = SEQ_PTR(_s_5684)->length;
    }
    else {
        _2963 = 1;
    }
    _2 = (int)SEQ_PTR(_s_5684);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _s_5684 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _2963);
    _1 = *(int *)_2;
    *(int *)_2 = 125;
    DeRef(_1);
    goto L8; // [120] 130
L7: 

    /** 			s &= '}'*/
    Append(&_s_5684, _s_5684, 125);
L8: 

    /** 		return s*/
    DeRef(_x_5683);
    DeRef(_2949);
    _2949 = NOVALUE;
    return _s_5684;
L2: 
    ;
}


int _18trim(int _source_5754, int _what_5755, int _ret_index_5756)
{
    int _rpos_5757 = NOVALUE;
    int _lpos_5758 = NOVALUE;
    int _3005 = NOVALUE;
    int _3003 = NOVALUE;
    int _3001 = NOVALUE;
    int _2999 = NOVALUE;
    int _2996 = NOVALUE;
    int _2995 = NOVALUE;
    int _2990 = NOVALUE;
    int _2989 = NOVALUE;
    int _2987 = NOVALUE;
    int _2985 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(what) then*/
    _2985 = 0;
    if (_2985 == 0)
    {
        _2985 = NOVALUE;
        goto L1; // [10] 20
    }
    else{
        _2985 = NOVALUE;
    }

    /** 		what = {what}*/
    _0 = _what_5755;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    RefDS(_what_5755);
    *((int *)(_2+4)) = _what_5755;
    _what_5755 = MAKE_SEQ(_1);
    DeRefDSi(_0);
L1: 

    /** 	lpos = 1*/
    _lpos_5758 = 1;

    /** 	while lpos <= length(source) do*/
L2: 
    if (IS_SEQUENCE(_source_5754)){
            _2987 = SEQ_PTR(_source_5754)->length;
    }
    else {
        _2987 = 1;
    }
    if (_lpos_5758 > _2987)
    goto L3; // [33] 67

    /** 		if not find(source[lpos], what) then*/
    _2 = (int)SEQ_PTR(_source_5754);
    _2989 = (int)*(((s1_ptr)_2)->base + _lpos_5758);
    _2990 = find_from(_2989, _what_5755, 1);
    _2989 = NOVALUE;
    if (_2990 != 0)
    goto L4; // [48] 56
    _2990 = NOVALUE;

    /** 			exit*/
    goto L3; // [53] 67
L4: 

    /** 		lpos += 1*/
    _lpos_5758 = _lpos_5758 + 1;

    /** 	end while*/
    goto L2; // [64] 30
L3: 

    /** 	rpos = length(source)*/
    if (IS_SEQUENCE(_source_5754)){
            _rpos_5757 = SEQ_PTR(_source_5754)->length;
    }
    else {
        _rpos_5757 = 1;
    }

    /** 	while rpos > lpos do*/
L5: 
    if (_rpos_5757 <= _lpos_5758)
    goto L6; // [77] 111

    /** 		if not find(source[rpos], what) then*/
    _2 = (int)SEQ_PTR(_source_5754);
    _2995 = (int)*(((s1_ptr)_2)->base + _rpos_5757);
    _2996 = find_from(_2995, _what_5755, 1);
    _2995 = NOVALUE;
    if (_2996 != 0)
    goto L7; // [92] 100
    _2996 = NOVALUE;

    /** 			exit*/
    goto L6; // [97] 111
L7: 

    /** 		rpos -= 1*/
    _rpos_5757 = _rpos_5757 - 1;

    /** 	end while*/
    goto L5; // [108] 77
L6: 

    /** 	if ret_index then*/
    if (_ret_index_5756 == 0)
    {
        goto L8; // [113] 129
    }
    else{
    }

    /** 		return {lpos, rpos}*/
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _lpos_5758;
    ((int *)_2)[2] = _rpos_5757;
    _2999 = MAKE_SEQ(_1);
    DeRefDS(_source_5754);
    DeRef(_what_5755);
    return _2999;
    goto L9; // [126] 180
L8: 

    /** 		if lpos = 1 then*/
    if (_lpos_5758 != 1)
    goto LA; // [131] 152

    /** 			if rpos = length(source) then*/
    if (IS_SEQUENCE(_source_5754)){
            _3001 = SEQ_PTR(_source_5754)->length;
    }
    else {
        _3001 = 1;
    }
    if (_rpos_5757 != _3001)
    goto LB; // [140] 151

    /** 				return source*/
    DeRef(_what_5755);
    DeRef(_2999);
    _2999 = NOVALUE;
    return _source_5754;
LB: 
LA: 

    /** 		if lpos > length(source) then*/
    if (IS_SEQUENCE(_source_5754)){
            _3003 = SEQ_PTR(_source_5754)->length;
    }
    else {
        _3003 = 1;
    }
    if (_lpos_5758 <= _3003)
    goto LC; // [157] 168

    /** 			return {}*/
    RefDS(_5);
    DeRefDS(_source_5754);
    DeRef(_what_5755);
    DeRef(_2999);
    _2999 = NOVALUE;
    return _5;
LC: 

    /** 		return source[lpos..rpos]*/
    rhs_slice_target = (object_ptr)&_3005;
    RHS_Slice(_source_5754, _lpos_5758, _rpos_5757);
    DeRefDS(_source_5754);
    DeRef(_what_5755);
    DeRef(_2999);
    _2999 = NOVALUE;
    return _3005;
L9: 
    ;
}


int _18lower(int _x_5954)
{
    int _3122 = NOVALUE;
    int _3121 = NOVALUE;
    int _3120 = NOVALUE;
    int _3119 = NOVALUE;
    int _3118 = NOVALUE;
    int _3115 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(lower_case_SET) != 0 then*/
    _3115 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return x + (x >= 'A' and x <= 'Z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_5954)) {
        _3118 = (_x_5954 >= 65);
    }
    else {
        _3118 = binary_op(GREATEREQ, _x_5954, 65);
    }
    if (IS_ATOM_INT(_x_5954)) {
        _3119 = (_x_5954 <= 90);
    }
    else {
        _3119 = binary_op(LESSEQ, _x_5954, 90);
    }
    if (IS_ATOM_INT(_3118) && IS_ATOM_INT(_3119)) {
        _3120 = (_3118 != 0 && _3119 != 0);
    }
    else {
        _3120 = binary_op(AND, _3118, _3119);
    }
    DeRef(_3118);
    _3118 = NOVALUE;
    DeRef(_3119);
    _3119 = NOVALUE;
    if (IS_ATOM_INT(_3120)) {
        if (_3120 == (short)_3120)
        _3121 = _3120 * 32;
        else
        _3121 = NewDouble(_3120 * (double)32);
    }
    else {
        _3121 = binary_op(MULTIPLY, _3120, 32);
    }
    DeRef(_3120);
    _3120 = NOVALUE;
    if (IS_ATOM_INT(_x_5954) && IS_ATOM_INT(_3121)) {
        _3122 = _x_5954 + _3121;
        if ((long)((unsigned long)_3122 + (unsigned long)HIGH_BITS) >= 0) 
        _3122 = NewDouble((double)_3122);
    }
    else {
        _3122 = binary_op(PLUS, _x_5954, _3121);
    }
    DeRef(_3121);
    _3121 = NOVALUE;
    DeRef(_x_5954);
    return _3122;
    ;
}


int _18upper(int _x_5966)
{
    int _3130 = NOVALUE;
    int _3129 = NOVALUE;
    int _3128 = NOVALUE;
    int _3127 = NOVALUE;
    int _3126 = NOVALUE;
    int _3123 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(upper_case_SET) != 0 then*/
    _3123 = 0;

    /** 	ifdef WINDOWS then*/

    /** 		return x - (x >= 'a' and x <= 'z') * TO_LOWER*/
    if (IS_ATOM_INT(_x_5966)) {
        _3126 = (_x_5966 >= 97);
    }
    else {
        _3126 = binary_op(GREATEREQ, _x_5966, 97);
    }
    if (IS_ATOM_INT(_x_5966)) {
        _3127 = (_x_5966 <= 122);
    }
    else {
        _3127 = binary_op(LESSEQ, _x_5966, 122);
    }
    if (IS_ATOM_INT(_3126) && IS_ATOM_INT(_3127)) {
        _3128 = (_3126 != 0 && _3127 != 0);
    }
    else {
        _3128 = binary_op(AND, _3126, _3127);
    }
    DeRef(_3126);
    _3126 = NOVALUE;
    DeRef(_3127);
    _3127 = NOVALUE;
    if (IS_ATOM_INT(_3128)) {
        if (_3128 == (short)_3128)
        _3129 = _3128 * 32;
        else
        _3129 = NewDouble(_3128 * (double)32);
    }
    else {
        _3129 = binary_op(MULTIPLY, _3128, 32);
    }
    DeRef(_3128);
    _3128 = NOVALUE;
    if (IS_ATOM_INT(_x_5966) && IS_ATOM_INT(_3129)) {
        _3130 = _x_5966 - _3129;
        if ((long)((unsigned long)_3130 +(unsigned long) HIGH_BITS) >= 0){
            _3130 = NewDouble((double)_3130);
        }
    }
    else {
        _3130 = binary_op(MINUS, _x_5966, _3129);
    }
    DeRef(_3129);
    _3129 = NOVALUE;
    DeRef(_x_5966);
    return _3130;
    ;
}


int _18proper(int _x_5978)
{
    int _pos_5979 = NOVALUE;
    int _inword_5980 = NOVALUE;
    int _convert_5981 = NOVALUE;
    int _res_5982 = NOVALUE;
    int _3160 = NOVALUE;
    int _3159 = NOVALUE;
    int _3158 = NOVALUE;
    int _3157 = NOVALUE;
    int _3156 = NOVALUE;
    int _3155 = NOVALUE;
    int _3154 = NOVALUE;
    int _3153 = NOVALUE;
    int _3152 = NOVALUE;
    int _3151 = NOVALUE;
    int _3149 = NOVALUE;
    int _3148 = NOVALUE;
    int _3143 = NOVALUE;
    int _3140 = NOVALUE;
    int _3137 = NOVALUE;
    int _3134 = NOVALUE;
    int _3133 = NOVALUE;
    int _3132 = NOVALUE;
    int _3131 = NOVALUE;
    int _0, _1, _2;
    

    /** 	inword = 0	-- Initially not in a word*/
    _inword_5980 = 0;

    /** 	convert = 1	-- Initially convert text*/
    _convert_5981 = 1;

    /** 	res = x		-- Work on a copy of the original, in case we need to restore.*/
    RefDS(_x_5978);
    DeRef(_res_5982);
    _res_5982 = _x_5978;

    /** 	for i = 1 to length(res) do*/
    if (IS_SEQUENCE(_res_5982)){
            _3131 = SEQ_PTR(_res_5982)->length;
    }
    else {
        _3131 = 1;
    }
    {
        int _i_5984;
        _i_5984 = 1;
L1: 
        if (_i_5984 > _3131){
            goto L2; // [25] 298
        }

        /** 		if integer(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3132 = (int)*(((s1_ptr)_2)->base + _i_5984);
        if (IS_ATOM_INT(_3132))
        _3133 = 1;
        else if (IS_ATOM_DBL(_3132))
        _3133 = IS_ATOM_INT(DoubleToInt(_3132));
        else
        _3133 = 0;
        _3132 = NOVALUE;
        if (_3133 == 0)
        {
            _3133 = NOVALUE;
            goto L3; // [41] 209
        }
        else{
            _3133 = NOVALUE;
        }

        /** 			if convert then*/
        if (_convert_5981 == 0)
        {
            goto L4; // [46] 291
        }
        else{
        }

        /** 				pos = types:t_upper(res[i])*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3134 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3134);
        _pos_5979 = _9t_upper(_3134);
        _3134 = NOVALUE;
        if (!IS_ATOM_INT(_pos_5979)) {
            _1 = (long)(DBL_PTR(_pos_5979)->dbl);
            DeRefDS(_pos_5979);
            _pos_5979 = _1;
        }

        /** 				if pos = 0 then*/
        if (_pos_5979 != 0)
        goto L5; // [63] 175

        /** 					pos = types:t_lower(res[i])*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3137 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3137);
        _pos_5979 = _9t_lower(_3137);
        _3137 = NOVALUE;
        if (!IS_ATOM_INT(_pos_5979)) {
            _1 = (long)(DBL_PTR(_pos_5979)->dbl);
            DeRefDS(_pos_5979);
            _pos_5979 = _1;
        }

        /** 					if pos = 0 then*/
        if (_pos_5979 != 0)
        goto L6; // [81] 138

        /** 						pos = t_digit(res[i])*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3140 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3140);
        _pos_5979 = _9t_digit(_3140);
        _3140 = NOVALUE;
        if (!IS_ATOM_INT(_pos_5979)) {
            _1 = (long)(DBL_PTR(_pos_5979)->dbl);
            DeRefDS(_pos_5979);
            _pos_5979 = _1;
        }

        /** 						if pos = 0 then*/
        if (_pos_5979 != 0)
        goto L4; // [99] 291

        /** 							pos = t_specword(res[i])*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3143 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3143);
        _pos_5979 = _9t_specword(_3143);
        _3143 = NOVALUE;
        if (!IS_ATOM_INT(_pos_5979)) {
            _1 = (long)(DBL_PTR(_pos_5979)->dbl);
            DeRefDS(_pos_5979);
            _pos_5979 = _1;
        }

        /** 							if pos then*/
        if (_pos_5979 == 0)
        {
            goto L7; // [117] 128
        }
        else{
        }

        /** 								inword = 1*/
        _inword_5980 = 1;
        goto L4; // [125] 291
L7: 

        /** 								inword = 0*/
        _inword_5980 = 0;
        goto L4; // [135] 291
L6: 

        /** 						if inword = 0 then*/
        if (_inword_5980 != 0)
        goto L4; // [140] 291

        /** 							if pos <= 26 then*/
        if (_pos_5979 > 26)
        goto L8; // [146] 165

        /** 								res[i] = upper(res[i]) -- Convert to uppercase*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3148 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3148);
        _3149 = _18upper(_3148);
        _3148 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_5982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_5982 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5984);
        _1 = *(int *)_2;
        *(int *)_2 = _3149;
        if( _1 != _3149 ){
            DeRef(_1);
        }
        _3149 = NOVALUE;
L8: 

        /** 							inword = 1	-- now we are in a word*/
        _inword_5980 = 1;
        goto L4; // [172] 291
L5: 

        /** 					if inword = 1 then*/
        if (_inword_5980 != 1)
        goto L9; // [177] 198

        /** 						res[i] = lower(res[i]) -- Convert to lowercase*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3151 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3151);
        _3152 = _18lower(_3151);
        _3151 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_5982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_5982 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5984);
        _1 = *(int *)_2;
        *(int *)_2 = _3152;
        if( _1 != _3152 ){
            DeRef(_1);
        }
        _3152 = NOVALUE;
        goto L4; // [195] 291
L9: 

        /** 						inword = 1	-- now we are in a word*/
        _inword_5980 = 1;
        goto L4; // [206] 291
L3: 

        /** 			if convert then*/
        if (_convert_5981 == 0)
        {
            goto LA; // [211] 263
        }
        else{
        }

        /** 				for j = 1 to i-1 do*/
        _3153 = _i_5984 - 1;
        {
            int _j_6025;
            _j_6025 = 1;
LB: 
            if (_j_6025 > _3153){
                goto LC; // [220] 257
            }

            /** 					if atom(x[j]) then*/
            _2 = (int)SEQ_PTR(_x_5978);
            _3154 = (int)*(((s1_ptr)_2)->base + _j_6025);
            _3155 = IS_ATOM(_3154);
            _3154 = NOVALUE;
            if (_3155 == 0)
            {
                _3155 = NOVALUE;
                goto LD; // [236] 250
            }
            else{
                _3155 = NOVALUE;
            }

            /** 						res[j] = x[j]*/
            _2 = (int)SEQ_PTR(_x_5978);
            _3156 = (int)*(((s1_ptr)_2)->base + _j_6025);
            Ref(_3156);
            _2 = (int)SEQ_PTR(_res_5982);
            if (!UNIQUE(_2)) {
                _2 = (int)SequenceCopy((s1_ptr)_2);
                _res_5982 = MAKE_SEQ(_2);
            }
            _2 = (int)(((s1_ptr)_2)->base + _j_6025);
            _1 = *(int *)_2;
            *(int *)_2 = _3156;
            if( _1 != _3156 ){
                DeRef(_1);
            }
            _3156 = NOVALUE;
LD: 

            /** 				end for*/
            _j_6025 = _j_6025 + 1;
            goto LB; // [252] 227
LC: 
            ;
        }

        /** 				convert = 0*/
        _convert_5981 = 0;
LA: 

        /** 			if sequence(res[i]) then*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3157 = (int)*(((s1_ptr)_2)->base + _i_5984);
        _3158 = IS_SEQUENCE(_3157);
        _3157 = NOVALUE;
        if (_3158 == 0)
        {
            _3158 = NOVALUE;
            goto LE; // [272] 290
        }
        else{
            _3158 = NOVALUE;
        }

        /** 				res[i] = proper(res[i])	-- recursive conversion*/
        _2 = (int)SEQ_PTR(_res_5982);
        _3159 = (int)*(((s1_ptr)_2)->base + _i_5984);
        Ref(_3159);
        _3160 = _18proper(_3159);
        _3159 = NOVALUE;
        _2 = (int)SEQ_PTR(_res_5982);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _res_5982 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_5984);
        _1 = *(int *)_2;
        *(int *)_2 = _3160;
        if( _1 != _3160 ){
            DeRef(_1);
        }
        _3160 = NOVALUE;
LE: 
L4: 

        /** 	end for*/
        _i_5984 = _i_5984 + 1;
        goto L1; // [293] 32
L2: 
        ;
    }

    /** 	return res*/
    DeRefDS(_x_5978);
    DeRef(_3153);
    _3153 = NOVALUE;
    return _res_5982;
    ;
}


int _18quote(int _text_in_6301, int _quote_pair_6302, int _esc_6304, int _sp_6306)
{
    int _3431 = NOVALUE;
    int _3430 = NOVALUE;
    int _3429 = NOVALUE;
    int _3427 = NOVALUE;
    int _3426 = NOVALUE;
    int _3425 = NOVALUE;
    int _3423 = NOVALUE;
    int _3422 = NOVALUE;
    int _3421 = NOVALUE;
    int _3420 = NOVALUE;
    int _3419 = NOVALUE;
    int _3418 = NOVALUE;
    int _3417 = NOVALUE;
    int _3416 = NOVALUE;
    int _3415 = NOVALUE;
    int _3413 = NOVALUE;
    int _3412 = NOVALUE;
    int _3411 = NOVALUE;
    int _3409 = NOVALUE;
    int _3408 = NOVALUE;
    int _3407 = NOVALUE;
    int _3406 = NOVALUE;
    int _3405 = NOVALUE;
    int _3404 = NOVALUE;
    int _3403 = NOVALUE;
    int _3402 = NOVALUE;
    int _3401 = NOVALUE;
    int _3399 = NOVALUE;
    int _3398 = NOVALUE;
    int _3396 = NOVALUE;
    int _3395 = NOVALUE;
    int _3394 = NOVALUE;
    int _3392 = NOVALUE;
    int _3391 = NOVALUE;
    int _3390 = NOVALUE;
    int _3389 = NOVALUE;
    int _3388 = NOVALUE;
    int _3387 = NOVALUE;
    int _3386 = NOVALUE;
    int _3385 = NOVALUE;
    int _3384 = NOVALUE;
    int _3383 = NOVALUE;
    int _3382 = NOVALUE;
    int _3381 = NOVALUE;
    int _3380 = NOVALUE;
    int _3379 = NOVALUE;
    int _3378 = NOVALUE;
    int _3377 = NOVALUE;
    int _3376 = NOVALUE;
    int _3373 = NOVALUE;
    int _3372 = NOVALUE;
    int _3371 = NOVALUE;
    int _3370 = NOVALUE;
    int _3369 = NOVALUE;
    int _3368 = NOVALUE;
    int _3367 = NOVALUE;
    int _3366 = NOVALUE;
    int _3365 = NOVALUE;
    int _3364 = NOVALUE;
    int _3363 = NOVALUE;
    int _3362 = NOVALUE;
    int _3361 = NOVALUE;
    int _3360 = NOVALUE;
    int _3357 = NOVALUE;
    int _3355 = NOVALUE;
    int _3354 = NOVALUE;
    int _3352 = NOVALUE;
    int _3350 = NOVALUE;
    int _3349 = NOVALUE;
    int _3348 = NOVALUE;
    int _3346 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if length(text_in) = 0 then*/
    if (IS_SEQUENCE(_text_in_6301)){
            _3346 = SEQ_PTR(_text_in_6301)->length;
    }
    else {
        _3346 = 1;
    }
    if (_3346 != 0)
    goto L1; // [10] 21

    /** 		return text_in*/
    DeRef(_quote_pair_6302);
    DeRef(_sp_6306);
    return _text_in_6301;
L1: 

    /** 	if atom(quote_pair) then*/
    _3348 = IS_ATOM(_quote_pair_6302);
    if (_3348 == 0)
    {
        _3348 = NOVALUE;
        goto L2; // [26] 46
    }
    else{
        _3348 = NOVALUE;
    }

    /** 		quote_pair = {{quote_pair}, {quote_pair}}*/
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_6302);
    *((int *)(_2+4)) = _quote_pair_6302;
    _3349 = MAKE_SEQ(_1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_quote_pair_6302);
    *((int *)(_2+4)) = _quote_pair_6302;
    _3350 = MAKE_SEQ(_1);
    DeRef(_quote_pair_6302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3349;
    ((int *)_2)[2] = _3350;
    _quote_pair_6302 = MAKE_SEQ(_1);
    _3350 = NOVALUE;
    _3349 = NOVALUE;
    goto L3; // [43] 89
L2: 

    /** 	elsif length(quote_pair) = 1 then*/
    if (IS_SEQUENCE(_quote_pair_6302)){
            _3352 = SEQ_PTR(_quote_pair_6302)->length;
    }
    else {
        _3352 = 1;
    }
    if (_3352 != 1)
    goto L4; // [51] 72

    /** 		quote_pair = {quote_pair[1], quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3354 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3355 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_3355);
    Ref(_3354);
    DeRef(_quote_pair_6302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3354;
    ((int *)_2)[2] = _3355;
    _quote_pair_6302 = MAKE_SEQ(_1);
    _3355 = NOVALUE;
    _3354 = NOVALUE;
    goto L3; // [69] 89
L4: 

    /** 	elsif length(quote_pair) = 0 then*/
    if (IS_SEQUENCE(_quote_pair_6302)){
            _3357 = SEQ_PTR(_quote_pair_6302)->length;
    }
    else {
        _3357 = 1;
    }
    if (_3357 != 0)
    goto L5; // [77] 88

    /** 		quote_pair = {"\"", "\""}*/
    RefDS(_3338);
    RefDS(_3338);
    DeRef(_quote_pair_6302);
    _1 = NewS1(2);
    _2 = (int)((s1_ptr)_1)->base;
    ((int *)_2)[1] = _3338;
    ((int *)_2)[2] = _3338;
    _quote_pair_6302 = MAKE_SEQ(_1);
L5: 
L3: 

    /** 	if sequence(text_in[1]) then*/
    _2 = (int)SEQ_PTR(_text_in_6301);
    _3360 = (int)*(((s1_ptr)_2)->base + 1);
    _3361 = IS_SEQUENCE(_3360);
    _3360 = NOVALUE;
    if (_3361 == 0)
    {
        _3361 = NOVALUE;
        goto L6; // [98] 166
    }
    else{
        _3361 = NOVALUE;
    }

    /** 		for i = 1 to length(text_in) do*/
    if (IS_SEQUENCE(_text_in_6301)){
            _3362 = SEQ_PTR(_text_in_6301)->length;
    }
    else {
        _3362 = 1;
    }
    {
        int _i_6329;
        _i_6329 = 1;
L7: 
        if (_i_6329 > _3362){
            goto L8; // [106] 159
        }

        /** 			if sequence(text_in[i]) then*/
        _2 = (int)SEQ_PTR(_text_in_6301);
        _3363 = (int)*(((s1_ptr)_2)->base + _i_6329);
        _3364 = IS_SEQUENCE(_3363);
        _3363 = NOVALUE;
        if (_3364 == 0)
        {
            _3364 = NOVALUE;
            goto L9; // [122] 152
        }
        else{
            _3364 = NOVALUE;
        }

        /** 				text_in[i] = quote(text_in[i], quote_pair, esc, sp)*/
        _2 = (int)SEQ_PTR(_text_in_6301);
        _3365 = (int)*(((s1_ptr)_2)->base + _i_6329);
        Ref(_quote_pair_6302);
        DeRef(_3366);
        _3366 = _quote_pair_6302;
        DeRef(_3367);
        _3367 = _esc_6304;
        Ref(_sp_6306);
        DeRef(_3368);
        _3368 = _sp_6306;
        Ref(_3365);
        _3369 = _18quote(_3365, _3366, _3367, _3368);
        _3365 = NOVALUE;
        _3366 = NOVALUE;
        _3367 = NOVALUE;
        _3368 = NOVALUE;
        _2 = (int)SEQ_PTR(_text_in_6301);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _text_in_6301 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_6329);
        _1 = *(int *)_2;
        *(int *)_2 = _3369;
        if( _1 != _3369 ){
            DeRef(_1);
        }
        _3369 = NOVALUE;
L9: 

        /** 		end for*/
        _i_6329 = _i_6329 + 1;
        goto L7; // [154] 113
L8: 
        ;
    }

    /** 		return text_in*/
    DeRef(_quote_pair_6302);
    DeRef(_sp_6306);
    return _text_in_6301;
L6: 

    /** 	for i = 1 to length(sp) do*/
    if (IS_SEQUENCE(_sp_6306)){
            _3370 = SEQ_PTR(_sp_6306)->length;
    }
    else {
        _3370 = 1;
    }
    {
        int _i_6340;
        _i_6340 = 1;
LA: 
        if (_i_6340 > _3370){
            goto LB; // [171] 220
        }

        /** 		if find(sp[i], text_in) then*/
        _2 = (int)SEQ_PTR(_sp_6306);
        _3371 = (int)*(((s1_ptr)_2)->base + _i_6340);
        _3372 = find_from(_3371, _text_in_6301, 1);
        _3371 = NOVALUE;
        if (_3372 == 0)
        {
            _3372 = NOVALUE;
            goto LC; // [189] 197
        }
        else{
            _3372 = NOVALUE;
        }

        /** 			exit*/
        goto LB; // [194] 220
LC: 

        /** 		if i = length(sp) then*/
        if (IS_SEQUENCE(_sp_6306)){
                _3373 = SEQ_PTR(_sp_6306)->length;
        }
        else {
            _3373 = 1;
        }
        if (_i_6340 != _3373)
        goto LD; // [202] 213

        /** 			return text_in*/
        DeRef(_quote_pair_6302);
        DeRef(_sp_6306);
        return _text_in_6301;
LD: 

        /** 	end for*/
        _i_6340 = _i_6340 + 1;
        goto LA; // [215] 178
LB: 
        ;
    }

    /** 	if esc >= 0  then*/
    if (_esc_6304 < 0)
    goto LE; // [222] 561

    /** 		if atom(quote_pair[1]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3376 = (int)*(((s1_ptr)_2)->base + 1);
    _3377 = IS_ATOM(_3376);
    _3376 = NOVALUE;
    if (_3377 == 0)
    {
        _3377 = NOVALUE;
        goto LF; // [235] 253
    }
    else{
        _3377 = NOVALUE;
    }

    /** 			quote_pair[1] = {quote_pair[1]}*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3378 = (int)*(((s1_ptr)_2)->base + 1);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_3378);
    *((int *)(_2+4)) = _3378;
    _3379 = MAKE_SEQ(_1);
    _3378 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_6302 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _3379;
    if( _1 != _3379 ){
        DeRef(_1);
    }
    _3379 = NOVALUE;
LF: 

    /** 		if atom(quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3380 = (int)*(((s1_ptr)_2)->base + 2);
    _3381 = IS_ATOM(_3380);
    _3380 = NOVALUE;
    if (_3381 == 0)
    {
        _3381 = NOVALUE;
        goto L10; // [262] 280
    }
    else{
        _3381 = NOVALUE;
    }

    /** 			quote_pair[2] = {quote_pair[2]}*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3382 = (int)*(((s1_ptr)_2)->base + 2);
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_3382);
    *((int *)(_2+4)) = _3382;
    _3383 = MAKE_SEQ(_1);
    _3382 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _quote_pair_6302 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 2);
    _1 = *(int *)_2;
    *(int *)_2 = _3383;
    if( _1 != _3383 ){
        DeRef(_1);
    }
    _3383 = NOVALUE;
L10: 

    /** 		if equal(quote_pair[1], quote_pair[2]) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3384 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3385 = (int)*(((s1_ptr)_2)->base + 2);
    if (_3384 == _3385)
    _3386 = 1;
    else if (IS_ATOM_INT(_3384) && IS_ATOM_INT(_3385))
    _3386 = 0;
    else
    _3386 = (compare(_3384, _3385) == 0);
    _3384 = NOVALUE;
    _3385 = NOVALUE;
    if (_3386 == 0)
    {
        _3386 = NOVALUE;
        goto L11; // [294] 372
    }
    else{
        _3386 = NOVALUE;
    }

    /** 			if match(quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3387 = (int)*(((s1_ptr)_2)->base + 1);
    _3388 = e_match_from(_3387, _text_in_6301, 1);
    _3387 = NOVALUE;
    if (_3388 == 0)
    {
        _3388 = NOVALUE;
        goto L12; // [308] 560
    }
    else{
        _3388 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3389 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3389)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3389)) {
        Prepend(&_3390, _3389, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3390, _esc_6304, _3389);
    }
    _3389 = NOVALUE;
    _3391 = e_match_from(_3390, _text_in_6301, 1);
    DeRefDS(_3390);
    _3390 = NOVALUE;
    if (_3391 == 0)
    {
        _3391 = NOVALUE;
        goto L13; // [326] 345
    }
    else{
        _3391 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc, text_in, esc & esc)*/
    Concat((object_ptr)&_3392, _esc_6304, _esc_6304);
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_esc_6304, _text_in_6301, _3392, 0);
    DeRefDS(_0);
    _3392 = NOVALUE;
L13: 

    /** 				text_in = search:match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3394 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3395 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3395)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3395)) {
        Prepend(&_3396, _3395, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3396, _esc_6304, _3395);
    }
    _3395 = NOVALUE;
    Ref(_3394);
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_3394, _text_in_6301, _3396, 0);
    DeRefDS(_0);
    _3394 = NOVALUE;
    _3396 = NOVALUE;
    goto L12; // [369] 560
L11: 

    /** 			if match(quote_pair[1], text_in) or*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3398 = (int)*(((s1_ptr)_2)->base + 1);
    _3399 = e_match_from(_3398, _text_in_6301, 1);
    _3398 = NOVALUE;
    if (_3399 != 0) {
        goto L14; // [383] 401
    }
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3401 = (int)*(((s1_ptr)_2)->base + 2);
    _3402 = e_match_from(_3401, _text_in_6301, 1);
    _3401 = NOVALUE;
    if (_3402 == 0)
    {
        _3402 = NOVALUE;
        goto L15; // [397] 473
    }
    else{
        _3402 = NOVALUE;
    }
L14: 

    /** 				if match(esc & quote_pair[1], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3403 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3403)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3403)) {
        Prepend(&_3404, _3403, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3404, _esc_6304, _3403);
    }
    _3403 = NOVALUE;
    _3405 = e_match_from(_3404, _text_in_6301, 1);
    DeRefDS(_3404);
    _3404 = NOVALUE;
    if (_3405 == 0)
    {
        _3405 = NOVALUE;
        goto L16; // [416] 449
    }
    else{
        _3405 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[1], text_in, esc & esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3406 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3406)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3406)) {
        Prepend(&_3407, _3406, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3407, _esc_6304, _3406);
    }
    _3406 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3408 = (int)*(((s1_ptr)_2)->base + 1);
    {
        int concat_list[3];

        concat_list[0] = _3408;
        concat_list[1] = _esc_6304;
        concat_list[2] = _esc_6304;
        Concat_N((object_ptr)&_3409, concat_list, 3);
    }
    _3408 = NOVALUE;
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_3407, _text_in_6301, _3409, 0);
    DeRefDS(_0);
    _3407 = NOVALUE;
    _3409 = NOVALUE;
L16: 

    /** 				text_in = match_replace(quote_pair[1], text_in, esc & quote_pair[1])*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3411 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3412 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3412)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3412)) {
        Prepend(&_3413, _3412, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3413, _esc_6304, _3412);
    }
    _3412 = NOVALUE;
    Ref(_3411);
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_3411, _text_in_6301, _3413, 0);
    DeRefDS(_0);
    _3411 = NOVALUE;
    _3413 = NOVALUE;
L15: 

    /** 			if match(quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3415 = (int)*(((s1_ptr)_2)->base + 2);
    _3416 = e_match_from(_3415, _text_in_6301, 1);
    _3415 = NOVALUE;
    if (_3416 == 0)
    {
        _3416 = NOVALUE;
        goto L17; // [484] 559
    }
    else{
        _3416 = NOVALUE;
    }

    /** 				if match(esc & quote_pair[2], text_in) then*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3417 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3417)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3417)) {
        Prepend(&_3418, _3417, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3418, _esc_6304, _3417);
    }
    _3417 = NOVALUE;
    _3419 = e_match_from(_3418, _text_in_6301, 1);
    DeRefDS(_3418);
    _3418 = NOVALUE;
    if (_3419 == 0)
    {
        _3419 = NOVALUE;
        goto L18; // [502] 535
    }
    else{
        _3419 = NOVALUE;
    }

    /** 					text_in = search:match_replace(esc & quote_pair[2], text_in, esc & esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3420 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3420)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3420)) {
        Prepend(&_3421, _3420, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3421, _esc_6304, _3420);
    }
    _3420 = NOVALUE;
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3422 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _3422;
        concat_list[1] = _esc_6304;
        concat_list[2] = _esc_6304;
        Concat_N((object_ptr)&_3423, concat_list, 3);
    }
    _3422 = NOVALUE;
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_3421, _text_in_6301, _3423, 0);
    DeRefDS(_0);
    _3421 = NOVALUE;
    _3423 = NOVALUE;
L18: 

    /** 				text_in = search:match_replace(quote_pair[2], text_in, esc & quote_pair[2])*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3425 = (int)*(((s1_ptr)_2)->base + 2);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3426 = (int)*(((s1_ptr)_2)->base + 2);
    if (IS_SEQUENCE(_esc_6304) && IS_ATOM(_3426)) {
    }
    else if (IS_ATOM(_esc_6304) && IS_SEQUENCE(_3426)) {
        Prepend(&_3427, _3426, _esc_6304);
    }
    else {
        Concat((object_ptr)&_3427, _esc_6304, _3426);
    }
    _3426 = NOVALUE;
    Ref(_3425);
    RefDS(_text_in_6301);
    _0 = _text_in_6301;
    _text_in_6301 = _20match_replace(_3425, _text_in_6301, _3427, 0);
    DeRefDS(_0);
    _3425 = NOVALUE;
    _3427 = NOVALUE;
L17: 
L12: 
LE: 

    /** 	return quote_pair[1] & text_in & quote_pair[2]*/
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3429 = (int)*(((s1_ptr)_2)->base + 1);
    _2 = (int)SEQ_PTR(_quote_pair_6302);
    _3430 = (int)*(((s1_ptr)_2)->base + 2);
    {
        int concat_list[3];

        concat_list[0] = _3430;
        concat_list[1] = _text_in_6301;
        concat_list[2] = _3429;
        Concat_N((object_ptr)&_3431, concat_list, 3);
    }
    _3430 = NOVALUE;
    _3429 = NOVALUE;
    DeRefDS(_text_in_6301);
    DeRef(_quote_pair_6302);
    DeRef(_sp_6306);
    return _3431;
    ;
}


int _18format(int _format_pattern_6522, int _arg_list_6523)
{
    int _result_6524 = NOVALUE;
    int _in_token_6525 = NOVALUE;
    int _tch_6526 = NOVALUE;
    int _i_6527 = NOVALUE;
    int _tend_6528 = NOVALUE;
    int _cap_6529 = NOVALUE;
    int _align_6530 = NOVALUE;
    int _psign_6531 = NOVALUE;
    int _msign_6532 = NOVALUE;
    int _zfill_6533 = NOVALUE;
    int _bwz_6534 = NOVALUE;
    int _spacer_6535 = NOVALUE;
    int _alt_6536 = NOVALUE;
    int _width_6537 = NOVALUE;
    int _decs_6538 = NOVALUE;
    int _pos_6539 = NOVALUE;
    int _argn_6540 = NOVALUE;
    int _argl_6541 = NOVALUE;
    int _trimming_6542 = NOVALUE;
    int _hexout_6543 = NOVALUE;
    int _binout_6544 = NOVALUE;
    int _tsep_6545 = NOVALUE;
    int _istext_6546 = NOVALUE;
    int _prevargv_6547 = NOVALUE;
    int _currargv_6548 = NOVALUE;
    int _idname_6549 = NOVALUE;
    int _envsym_6550 = NOVALUE;
    int _envvar_6551 = NOVALUE;
    int _ep_6552 = NOVALUE;
    int _sp_6631 = NOVALUE;
    int _sp_6667 = NOVALUE;
    int _argtext_6714 = NOVALUE;
    int _tempv_6937 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2427_6992 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2424_6991 = NOVALUE;
    int _pretty_sprint_inlined_pretty_sprint_at_2483_6999 = NOVALUE;
    int _options_inlined_pretty_sprint_at_2480_6998 = NOVALUE;
    int _x_inlined_pretty_sprint_at_2477_6997 = NOVALUE;
    int _msg_inlined_crash_at_2631_7021 = NOVALUE;
    int _dpos_7064 = NOVALUE;
    int _dist_7065 = NOVALUE;
    int _bracketed_7066 = NOVALUE;
    int _3929 = NOVALUE;
    int _3928 = NOVALUE;
    int _3927 = NOVALUE;
    int _3925 = NOVALUE;
    int _3924 = NOVALUE;
    int _3923 = NOVALUE;
    int _3920 = NOVALUE;
    int _3919 = NOVALUE;
    int _3916 = NOVALUE;
    int _3914 = NOVALUE;
    int _3911 = NOVALUE;
    int _3910 = NOVALUE;
    int _3909 = NOVALUE;
    int _3906 = NOVALUE;
    int _3903 = NOVALUE;
    int _3902 = NOVALUE;
    int _3901 = NOVALUE;
    int _3900 = NOVALUE;
    int _3897 = NOVALUE;
    int _3896 = NOVALUE;
    int _3895 = NOVALUE;
    int _3892 = NOVALUE;
    int _3890 = NOVALUE;
    int _3887 = NOVALUE;
    int _3886 = NOVALUE;
    int _3885 = NOVALUE;
    int _3884 = NOVALUE;
    int _3881 = NOVALUE;
    int _3876 = NOVALUE;
    int _3875 = NOVALUE;
    int _3874 = NOVALUE;
    int _3873 = NOVALUE;
    int _3867 = NOVALUE;
    int _3863 = NOVALUE;
    int _3862 = NOVALUE;
    int _3860 = NOVALUE;
    int _3858 = NOVALUE;
    int _3857 = NOVALUE;
    int _3856 = NOVALUE;
    int _3855 = NOVALUE;
    int _3854 = NOVALUE;
    int _3851 = NOVALUE;
    int _3848 = NOVALUE;
    int _3847 = NOVALUE;
    int _3844 = NOVALUE;
    int _3843 = NOVALUE;
    int _3842 = NOVALUE;
    int _3839 = NOVALUE;
    int _3837 = NOVALUE;
    int _3832 = NOVALUE;
    int _3831 = NOVALUE;
    int _3823 = NOVALUE;
    int _3819 = NOVALUE;
    int _3817 = NOVALUE;
    int _3816 = NOVALUE;
    int _3815 = NOVALUE;
    int _3812 = NOVALUE;
    int _3810 = NOVALUE;
    int _3809 = NOVALUE;
    int _3808 = NOVALUE;
    int _3806 = NOVALUE;
    int _3805 = NOVALUE;
    int _3804 = NOVALUE;
    int _3803 = NOVALUE;
    int _3800 = NOVALUE;
    int _3799 = NOVALUE;
    int _3798 = NOVALUE;
    int _3796 = NOVALUE;
    int _3795 = NOVALUE;
    int _3794 = NOVALUE;
    int _3793 = NOVALUE;
    int _3791 = NOVALUE;
    int _3789 = NOVALUE;
    int _3787 = NOVALUE;
    int _3785 = NOVALUE;
    int _3783 = NOVALUE;
    int _3781 = NOVALUE;
    int _3780 = NOVALUE;
    int _3779 = NOVALUE;
    int _3778 = NOVALUE;
    int _3777 = NOVALUE;
    int _3776 = NOVALUE;
    int _3774 = NOVALUE;
    int _3773 = NOVALUE;
    int _3771 = NOVALUE;
    int _3770 = NOVALUE;
    int _3768 = NOVALUE;
    int _3766 = NOVALUE;
    int _3765 = NOVALUE;
    int _3762 = NOVALUE;
    int _3760 = NOVALUE;
    int _3756 = NOVALUE;
    int _3754 = NOVALUE;
    int _3753 = NOVALUE;
    int _3752 = NOVALUE;
    int _3750 = NOVALUE;
    int _3749 = NOVALUE;
    int _3748 = NOVALUE;
    int _3747 = NOVALUE;
    int _3746 = NOVALUE;
    int _3744 = NOVALUE;
    int _3742 = NOVALUE;
    int _3741 = NOVALUE;
    int _3740 = NOVALUE;
    int _3739 = NOVALUE;
    int _3735 = NOVALUE;
    int _3732 = NOVALUE;
    int _3731 = NOVALUE;
    int _3728 = NOVALUE;
    int _3727 = NOVALUE;
    int _3726 = NOVALUE;
    int _3724 = NOVALUE;
    int _3723 = NOVALUE;
    int _3722 = NOVALUE;
    int _3721 = NOVALUE;
    int _3719 = NOVALUE;
    int _3717 = NOVALUE;
    int _3716 = NOVALUE;
    int _3715 = NOVALUE;
    int _3714 = NOVALUE;
    int _3713 = NOVALUE;
    int _3712 = NOVALUE;
    int _3710 = NOVALUE;
    int _3709 = NOVALUE;
    int _3708 = NOVALUE;
    int _3706 = NOVALUE;
    int _3705 = NOVALUE;
    int _3704 = NOVALUE;
    int _3703 = NOVALUE;
    int _3701 = NOVALUE;
    int _3698 = NOVALUE;
    int _3697 = NOVALUE;
    int _3695 = NOVALUE;
    int _3694 = NOVALUE;
    int _3692 = NOVALUE;
    int _3689 = NOVALUE;
    int _3688 = NOVALUE;
    int _3685 = NOVALUE;
    int _3683 = NOVALUE;
    int _3679 = NOVALUE;
    int _3677 = NOVALUE;
    int _3676 = NOVALUE;
    int _3675 = NOVALUE;
    int _3673 = NOVALUE;
    int _3671 = NOVALUE;
    int _3670 = NOVALUE;
    int _3669 = NOVALUE;
    int _3668 = NOVALUE;
    int _3667 = NOVALUE;
    int _3665 = NOVALUE;
    int _3663 = NOVALUE;
    int _3662 = NOVALUE;
    int _3661 = NOVALUE;
    int _3660 = NOVALUE;
    int _3658 = NOVALUE;
    int _3655 = NOVALUE;
    int _3653 = NOVALUE;
    int _3652 = NOVALUE;
    int _3650 = NOVALUE;
    int _3649 = NOVALUE;
    int _3648 = NOVALUE;
    int _3645 = NOVALUE;
    int _3644 = NOVALUE;
    int _3643 = NOVALUE;
    int _3642 = NOVALUE;
    int _3640 = NOVALUE;
    int _3639 = NOVALUE;
    int _3638 = NOVALUE;
    int _3637 = NOVALUE;
    int _3636 = NOVALUE;
    int _3633 = NOVALUE;
    int _3632 = NOVALUE;
    int _3631 = NOVALUE;
    int _3630 = NOVALUE;
    int _3628 = NOVALUE;
    int _3627 = NOVALUE;
    int _3626 = NOVALUE;
    int _3624 = NOVALUE;
    int _3623 = NOVALUE;
    int _3622 = NOVALUE;
    int _3620 = NOVALUE;
    int _3613 = NOVALUE;
    int _3611 = NOVALUE;
    int _3610 = NOVALUE;
    int _3603 = NOVALUE;
    int _3600 = NOVALUE;
    int _3596 = NOVALUE;
    int _3594 = NOVALUE;
    int _3593 = NOVALUE;
    int _3590 = NOVALUE;
    int _3588 = NOVALUE;
    int _3586 = NOVALUE;
    int _3583 = NOVALUE;
    int _3581 = NOVALUE;
    int _3580 = NOVALUE;
    int _3579 = NOVALUE;
    int _3578 = NOVALUE;
    int _3577 = NOVALUE;
    int _3574 = NOVALUE;
    int _3571 = NOVALUE;
    int _3570 = NOVALUE;
    int _3569 = NOVALUE;
    int _3566 = NOVALUE;
    int _3564 = NOVALUE;
    int _3562 = NOVALUE;
    int _3559 = NOVALUE;
    int _3558 = NOVALUE;
    int _3551 = NOVALUE;
    int _3548 = NOVALUE;
    int _3547 = NOVALUE;
    int _3539 = NOVALUE;
    int _3528 = NOVALUE;
    int _3525 = NOVALUE;
    int _3515 = NOVALUE;
    int _3513 = NOVALUE;
    int _0, _1, _2;
    

    /** 	if atom(arg_list) then*/
    _3513 = IS_ATOM(_arg_list_6523);
    if (_3513 == 0)
    {
        _3513 = NOVALUE;
        goto L1; // [8] 18
    }
    else{
        _3513 = NOVALUE;
    }

    /** 		arg_list = {arg_list}*/
    _0 = _arg_list_6523;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    Ref(_arg_list_6523);
    *((int *)(_2+4)) = _arg_list_6523;
    _arg_list_6523 = MAKE_SEQ(_1);
    DeRef(_0);
L1: 

    /** 	result = ""*/
    RefDS(_5);
    DeRef(_result_6524);
    _result_6524 = _5;

    /** 	in_token = 0*/
    _in_token_6525 = 0;

    /** 	i = 0*/
    _i_6527 = 0;

    /** 	tend = 0*/
    _tend_6528 = 0;

    /** 	argl = 0*/
    _argl_6541 = 0;

    /** 	spacer = 0*/
    _spacer_6535 = 0;

    /** 	prevargv = 0*/
    DeRef(_prevargv_6547);
    _prevargv_6547 = 0;

    /**     while i < length(format_pattern) do*/
L2: 
    if (IS_SEQUENCE(_format_pattern_6522)){
            _3515 = SEQ_PTR(_format_pattern_6522)->length;
    }
    else {
        _3515 = 1;
    }
    if (_i_6527 >= _3515)
    goto L3; // [63] 3380

    /**     	i += 1*/
    _i_6527 = _i_6527 + 1;

    /**     	tch = format_pattern[i]*/
    _2 = (int)SEQ_PTR(_format_pattern_6522);
    _tch_6526 = (int)*(((s1_ptr)_2)->base + _i_6527);
    if (!IS_ATOM_INT(_tch_6526))
    _tch_6526 = (long)DBL_PTR(_tch_6526)->dbl;

    /**     	if not in_token then*/
    if (_in_token_6525 != 0)
    goto L4; // [81] 210

    /**     		if tch = '[' then*/
    if (_tch_6526 != 91)
    goto L5; // [86] 200

    /**     			in_token = 1*/
    _in_token_6525 = 1;

    /**     			tend = 0*/
    _tend_6528 = 0;

    /** 				cap = 0*/
    _cap_6529 = 0;

    /** 				align = 0*/
    _align_6530 = 0;

    /** 				psign = 0*/
    _psign_6531 = 0;

    /** 				msign = 0*/
    _msign_6532 = 0;

    /** 				zfill = 0*/
    _zfill_6533 = 0;

    /** 				bwz = 0*/
    _bwz_6534 = 0;

    /** 				spacer = 0*/
    _spacer_6535 = 0;

    /** 				alt = 0*/
    _alt_6536 = 0;

    /**     			width = 0*/
    _width_6537 = 0;

    /**     			decs = -1*/
    _decs_6538 = -1;

    /**     			argn = 0*/
    _argn_6540 = 0;

    /**     			hexout = 0*/
    _hexout_6543 = 0;

    /**     			binout = 0*/
    _binout_6544 = 0;

    /**     			trimming = 0*/
    _trimming_6542 = 0;

    /**     			tsep = 0*/
    _tsep_6545 = 0;

    /**     			istext = 0*/
    _istext_6546 = 0;

    /**     			idname = ""*/
    RefDS(_5);
    DeRef(_idname_6549);
    _idname_6549 = _5;

    /**     			envvar = ""*/
    RefDS(_5);
    DeRefi(_envvar_6551);
    _envvar_6551 = _5;

    /**     			envsym = ""*/
    RefDS(_5);
    DeRef(_envsym_6550);
    _envsym_6550 = _5;
    goto L2; // [197] 60
L5: 

    /**     			result &= tch*/
    Append(&_result_6524, _result_6524, _tch_6526);
    goto L2; // [207] 60
L4: 

    /** 			switch tch do*/
    _0 = _tch_6526;
    switch ( _0 ){ 

        /**     			case ']' then*/
        case 93:

        /**     				in_token = 0*/
        _in_token_6525 = 0;

        /**     				tend = i*/
        _tend_6528 = _i_6527;
        goto L6; // [231] 1072

        /**     			case '[' then*/
        case 91:

        /** 	    			result &= tch*/
        Append(&_result_6524, _result_6524, _tch_6526);

        /** 	    			while i < length(format_pattern) do*/
L7: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3525 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3525 = 1;
        }
        if (_i_6527 >= _3525)
        goto L6; // [251] 1072

        /** 	    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3528 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3528, 93)){
            _3528 = NOVALUE;
            goto L7; // [267] 248
        }
        _3528 = NOVALUE;

        /** 	    					in_token = 0*/
        _in_token_6525 = 0;

        /** 	    					tend = 0*/
        _tend_6528 = 0;

        /** 	    					exit*/
        goto L6; // [283] 1072

        /** 	    			end while*/
        goto L7; // [288] 248
        goto L6; // [291] 1072

        /** 	    		case 'w', 'u', 'l' then*/
        case 119:
        case 117:
        case 108:

        /** 	    			cap = tch*/
        _cap_6529 = _tch_6526;
        goto L6; // [306] 1072

        /** 	    		case 'b' then*/
        case 98:

        /** 	    			bwz = 1*/
        _bwz_6534 = 1;
        goto L6; // [317] 1072

        /** 	    		case 's' then*/
        case 115:

        /** 	    			spacer = 1*/
        _spacer_6535 = 1;
        goto L6; // [328] 1072

        /** 	    		case 't' then*/
        case 116:

        /** 	    			trimming = 1*/
        _trimming_6542 = 1;
        goto L6; // [339] 1072

        /** 	    		case 'z' then*/
        case 122:

        /** 	    			zfill = 1*/
        _zfill_6533 = 1;
        goto L6; // [350] 1072

        /** 	    		case 'X' then*/
        case 88:

        /** 	    			hexout = 1*/
        _hexout_6543 = 1;
        goto L6; // [361] 1072

        /** 	    		case 'B' then*/
        case 66:

        /** 	    			binout = 1*/
        _binout_6544 = 1;
        goto L6; // [372] 1072

        /** 	    		case 'c', '<', '>' then*/
        case 99:
        case 60:
        case 62:

        /** 	    			align = tch*/
        _align_6530 = _tch_6526;
        goto L6; // [387] 1072

        /** 	    		case '+' then*/
        case 43:

        /** 	    			psign = 1*/
        _psign_6531 = 1;
        goto L6; // [398] 1072

        /** 	    		case '(' then*/
        case 40:

        /** 	    			msign = 1*/
        _msign_6532 = 1;
        goto L6; // [409] 1072

        /** 	    		case '?' then*/
        case 63:

        /** 	    			alt = 1*/
        _alt_6536 = 1;
        goto L6; // [420] 1072

        /** 	    		case 'T' then*/
        case 84:

        /** 	    			istext = 1*/
        _istext_6546 = 1;
        goto L6; // [431] 1072

        /** 	    		case ':' then*/
        case 58:

        /** 	    			while i < length(format_pattern) do*/
L8: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3539 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3539 = 1;
        }
        if (_i_6527 >= _3539)
        goto L6; // [445] 1072

        /** 	    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _tch_6526 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (!IS_ATOM_INT(_tch_6526))
        _tch_6526 = (long)DBL_PTR(_tch_6526)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_6539 = find_from(_tch_6526, _3543, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_6539 != 0)
        goto L9; // [470] 485

        /** 	    					i -= 1*/
        _i_6527 = _i_6527 - 1;

        /** 	    					exit*/
        goto L6; // [482] 1072
L9: 

        /** 	    				width = width * 10 + pos - 1*/
        if (_width_6537 == (short)_width_6537)
        _3547 = _width_6537 * 10;
        else
        _3547 = NewDouble(_width_6537 * (double)10);
        if (IS_ATOM_INT(_3547)) {
            _3548 = _3547 + _pos_6539;
            if ((long)((unsigned long)_3548 + (unsigned long)HIGH_BITS) >= 0) 
            _3548 = NewDouble((double)_3548);
        }
        else {
            _3548 = NewDouble(DBL_PTR(_3547)->dbl + (double)_pos_6539);
        }
        DeRef(_3547);
        _3547 = NOVALUE;
        if (IS_ATOM_INT(_3548)) {
            _width_6537 = _3548 - 1;
        }
        else {
            _width_6537 = NewDouble(DBL_PTR(_3548)->dbl - (double)1);
        }
        DeRef(_3548);
        _3548 = NOVALUE;
        if (!IS_ATOM_INT(_width_6537)) {
            _1 = (long)(DBL_PTR(_width_6537)->dbl);
            DeRefDS(_width_6537);
            _width_6537 = _1;
        }

        /** 	    				if width = 0 then*/
        if (_width_6537 != 0)
        goto L8; // [505] 442

        /** 	    					zfill = '0'*/
        _zfill_6533 = 48;

        /** 	    			end while*/
        goto L8; // [517] 442
        goto L6; // [520] 1072

        /** 	    		case '.' then*/
        case 46:

        /** 	    			decs = 0*/
        _decs_6538 = 0;

        /** 	    			while i < length(format_pattern) do*/
LA: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3551 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3551 = 1;
        }
        if (_i_6527 >= _3551)
        goto L6; // [539] 1072

        /** 	    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 	    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _tch_6526 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (!IS_ATOM_INT(_tch_6526))
        _tch_6526 = (long)DBL_PTR(_tch_6526)->dbl;

        /** 	    				pos = find(tch, "0123456789")*/
        _pos_6539 = find_from(_tch_6526, _3543, 1);

        /** 	    				if pos = 0 then*/
        if (_pos_6539 != 0)
        goto LB; // [564] 579

        /** 	    					i -= 1*/
        _i_6527 = _i_6527 - 1;

        /** 	    					exit*/
        goto L6; // [576] 1072
LB: 

        /** 	    				decs = decs * 10 + pos - 1*/
        if (_decs_6538 == (short)_decs_6538)
        _3558 = _decs_6538 * 10;
        else
        _3558 = NewDouble(_decs_6538 * (double)10);
        if (IS_ATOM_INT(_3558)) {
            _3559 = _3558 + _pos_6539;
            if ((long)((unsigned long)_3559 + (unsigned long)HIGH_BITS) >= 0) 
            _3559 = NewDouble((double)_3559);
        }
        else {
            _3559 = NewDouble(DBL_PTR(_3558)->dbl + (double)_pos_6539);
        }
        DeRef(_3558);
        _3558 = NOVALUE;
        if (IS_ATOM_INT(_3559)) {
            _decs_6538 = _3559 - 1;
        }
        else {
            _decs_6538 = NewDouble(DBL_PTR(_3559)->dbl - (double)1);
        }
        DeRef(_3559);
        _3559 = NOVALUE;
        if (!IS_ATOM_INT(_decs_6538)) {
            _1 = (long)(DBL_PTR(_decs_6538)->dbl);
            DeRefDS(_decs_6538);
            _decs_6538 = _1;
        }

        /** 	    			end while*/
        goto LA; // [597] 536
        goto L6; // [600] 1072

        /** 	    		case '{' then*/
        case 123:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_6631 = _i_6527 + 1;

        /** 	    			i = sp*/
        _i_6527 = _sp_6631;

        /** 	    			while i < length(format_pattern) do*/
LC: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3562 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3562 = 1;
        }
        if (_i_6527 >= _3562)
        goto LD; // [627] 672

        /** 	    				if format_pattern[i] = '}' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3564 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3564, 125)){
            _3564 = NOVALUE;
            goto LE; // [637] 646
        }
        _3564 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [643] 672
LE: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3566 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3566, 93)){
            _3566 = NOVALUE;
            goto LF; // [652] 661
        }
        _3566 = NOVALUE;

        /** 	    					exit*/
        goto LD; // [658] 672
LF: 

        /** 	    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 	    			end while*/
        goto LC; // [669] 624
LD: 

        /** 	    			idname = trim(format_pattern[sp .. i-1]) & '='*/
        _3569 = _i_6527 - 1;
        rhs_slice_target = (object_ptr)&_3570;
        RHS_Slice(_format_pattern_6522, _sp_6631, _3569);
        RefDS(_2965);
        _3571 = _18trim(_3570, _2965, 0);
        _3570 = NOVALUE;
        if (IS_SEQUENCE(_3571) && IS_ATOM(61)) {
            Append(&_idname_6549, _3571, 61);
        }
        else if (IS_ATOM(_3571) && IS_SEQUENCE(61)) {
        }
        else {
            Concat((object_ptr)&_idname_6549, _3571, 61);
            DeRef(_3571);
            _3571 = NOVALUE;
        }
        DeRef(_3571);
        _3571 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3574 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3574, 93)){
            _3574 = NOVALUE;
            goto L10; // [699] 710
        }
        _3574 = NOVALUE;

        /**     					i -= 1*/
        _i_6527 = _i_6527 - 1;
L10: 

        /**     				for j = 1 to length(arg_list) do*/
        if (IS_SEQUENCE(_arg_list_6523)){
                _3577 = SEQ_PTR(_arg_list_6523)->length;
        }
        else {
            _3577 = 1;
        }
        {
            int _j_6653;
            _j_6653 = 1;
L11: 
            if (_j_6653 > _3577){
                goto L12; // [715] 797
            }

            /**     					if sequence(arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_6523);
            _3578 = (int)*(((s1_ptr)_2)->base + _j_6653);
            _3579 = IS_SEQUENCE(_3578);
            _3578 = NOVALUE;
            if (_3579 == 0)
            {
                _3579 = NOVALUE;
                goto L13; // [731] 768
            }
            else{
                _3579 = NOVALUE;
            }

            /**     						if search:begins(idname, arg_list[j]) then*/
            _2 = (int)SEQ_PTR(_arg_list_6523);
            _3580 = (int)*(((s1_ptr)_2)->base + _j_6653);
            RefDS(_idname_6549);
            Ref(_3580);
            _3581 = _20begins(_idname_6549, _3580);
            _3580 = NOVALUE;
            if (_3581 == 0) {
                DeRef(_3581);
                _3581 = NOVALUE;
                goto L14; // [745] 767
            }
            else {
                if (!IS_ATOM_INT(_3581) && DBL_PTR(_3581)->dbl == 0.0){
                    DeRef(_3581);
                    _3581 = NOVALUE;
                    goto L14; // [745] 767
                }
                DeRef(_3581);
                _3581 = NOVALUE;
            }
            DeRef(_3581);
            _3581 = NOVALUE;

            /**     							if argn = 0 then*/
            if (_argn_6540 != 0)
            goto L15; // [752] 766

            /**     								argn = j*/
            _argn_6540 = _j_6653;

            /**     								exit*/
            goto L12; // [763] 797
L15: 
L14: 
L13: 

            /**     					if j = length(arg_list) then*/
            if (IS_SEQUENCE(_arg_list_6523)){
                    _3583 = SEQ_PTR(_arg_list_6523)->length;
            }
            else {
                _3583 = 1;
            }
            if (_j_6653 != _3583)
            goto L16; // [773] 790

            /**     						idname = ""*/
            RefDS(_5);
            DeRef(_idname_6549);
            _idname_6549 = _5;

            /**     						argn = -1*/
            _argn_6540 = -1;
L16: 

            /**     				end for*/
            _j_6653 = _j_6653 + 1;
            goto L11; // [792] 722
L12: 
            ;
        }
        goto L6; // [799] 1072

        /** 	    		case '%' then*/
        case 37:

        /** 	    			integer sp*/

        /** 	    			sp = i + 1*/
        _sp_6667 = _i_6527 + 1;

        /** 	    			i = sp*/
        _i_6527 = _sp_6667;

        /** 	    			while i < length(format_pattern) do*/
L17: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3586 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3586 = 1;
        }
        if (_i_6527 >= _3586)
        goto L18; // [826] 871

        /** 	    				if format_pattern[i] = '%' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3588 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3588, 37)){
            _3588 = NOVALUE;
            goto L19; // [836] 845
        }
        _3588 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [842] 871
L19: 

        /** 	    				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3590 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3590, 93)){
            _3590 = NOVALUE;
            goto L1A; // [851] 860
        }
        _3590 = NOVALUE;

        /** 	    					exit*/
        goto L18; // [857] 871
L1A: 

        /** 	    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 	    			end while*/
        goto L17; // [868] 823
L18: 

        /** 	    			envsym = trim(format_pattern[sp .. i-1])*/
        _3593 = _i_6527 - 1;
        rhs_slice_target = (object_ptr)&_3594;
        RHS_Slice(_format_pattern_6522, _sp_6667, _3593);
        RefDS(_2965);
        _0 = _envsym_6550;
        _envsym_6550 = _18trim(_3594, _2965, 0);
        DeRef(_0);
        _3594 = NOVALUE;

        /**     				if format_pattern[i] = ']' then*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _3596 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (binary_op_a(NOTEQ, _3596, 93)){
            _3596 = NOVALUE;
            goto L1B; // [894] 905
        }
        _3596 = NOVALUE;

        /**     					i -= 1*/
        _i_6527 = _i_6527 - 1;
L1B: 

        /**     				envvar = getenv(envsym)*/
        DeRefi(_envvar_6551);
        _envvar_6551 = EGetEnv(_envsym_6550);

        /**     				argn = -1*/
        _argn_6540 = -1;

        /**     				if atom(envvar) then*/
        _3600 = IS_ATOM(_envvar_6551);
        if (_3600 == 0)
        {
            _3600 = NOVALUE;
            goto L1C; // [920] 929
        }
        else{
            _3600 = NOVALUE;
        }

        /**     					envvar = ""*/
        RefDS(_5);
        DeRefi(_envvar_6551);
        _envvar_6551 = _5;
L1C: 
        goto L6; // [931] 1072

        /** 	    		case '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' then*/
        case 48:
        case 49:
        case 50:
        case 51:
        case 52:
        case 53:
        case 54:
        case 55:
        case 56:
        case 57:

        /** 	    			if argn = 0 then*/
        if (_argn_6540 != 0)
        goto L6; // [957] 1072

        /** 		    			i -= 1*/
        _i_6527 = _i_6527 - 1;

        /** 		    			while i < length(format_pattern) do*/
L1D: 
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3603 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3603 = 1;
        }
        if (_i_6527 >= _3603)
        goto L6; // [975] 1072

        /** 		    				i += 1*/
        _i_6527 = _i_6527 + 1;

        /** 		    				tch = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _tch_6526 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (!IS_ATOM_INT(_tch_6526))
        _tch_6526 = (long)DBL_PTR(_tch_6526)->dbl;

        /** 		    				pos = find(tch, "0123456789")*/
        _pos_6539 = find_from(_tch_6526, _3543, 1);

        /** 		    				if pos = 0 then*/
        if (_pos_6539 != 0)
        goto L1E; // [1000] 1015

        /** 		    					i -= 1*/
        _i_6527 = _i_6527 - 1;

        /** 		    					exit*/
        goto L6; // [1012] 1072
L1E: 

        /** 		    				argn = argn * 10 + pos - 1*/
        if (_argn_6540 == (short)_argn_6540)
        _3610 = _argn_6540 * 10;
        else
        _3610 = NewDouble(_argn_6540 * (double)10);
        if (IS_ATOM_INT(_3610)) {
            _3611 = _3610 + _pos_6539;
            if ((long)((unsigned long)_3611 + (unsigned long)HIGH_BITS) >= 0) 
            _3611 = NewDouble((double)_3611);
        }
        else {
            _3611 = NewDouble(DBL_PTR(_3610)->dbl + (double)_pos_6539);
        }
        DeRef(_3610);
        _3610 = NOVALUE;
        if (IS_ATOM_INT(_3611)) {
            _argn_6540 = _3611 - 1;
        }
        else {
            _argn_6540 = NewDouble(DBL_PTR(_3611)->dbl - (double)1);
        }
        DeRef(_3611);
        _3611 = NOVALUE;
        if (!IS_ATOM_INT(_argn_6540)) {
            _1 = (long)(DBL_PTR(_argn_6540)->dbl);
            DeRefDS(_argn_6540);
            _argn_6540 = _1;
        }

        /** 		    			end while*/
        goto L1D; // [1033] 972
        goto L6; // [1037] 1072

        /** 	    		case ',' then*/
        case 44:

        /** 	    			if i < length(format_pattern) then*/
        if (IS_SEQUENCE(_format_pattern_6522)){
                _3613 = SEQ_PTR(_format_pattern_6522)->length;
        }
        else {
            _3613 = 1;
        }
        if (_i_6527 >= _3613)
        goto L6; // [1048] 1072

        /** 	    				i +=1*/
        _i_6527 = _i_6527 + 1;

        /** 	    				tsep = format_pattern[i]*/
        _2 = (int)SEQ_PTR(_format_pattern_6522);
        _tsep_6545 = (int)*(((s1_ptr)_2)->base + _i_6527);
        if (!IS_ATOM_INT(_tsep_6545))
        _tsep_6545 = (long)DBL_PTR(_tsep_6545)->dbl;
        goto L6; // [1065] 1072

        /** 	    		case else*/
        default:
    ;}L6: 

    /**     		if tend > 0 then*/
    if (_tend_6528 <= 0)
    goto L1F; // [1074] 3372

    /**     			sequence argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_6714);
    _argtext_6714 = _5;

    /**     			if argn = 0 then*/
    if (_argn_6540 != 0)
    goto L20; // [1089] 1100

    /**     				argn = argl + 1*/
    _argn_6540 = _argl_6541 + 1;
L20: 

    /**     			argl = argn*/
    _argl_6541 = _argn_6540;

    /**     			if argn < 1 or argn > length(arg_list) then*/
    _3620 = (_argn_6540 < 1);
    if (_3620 != 0) {
        goto L21; // [1111] 1127
    }
    if (IS_SEQUENCE(_arg_list_6523)){
            _3622 = SEQ_PTR(_arg_list_6523)->length;
    }
    else {
        _3622 = 1;
    }
    _3623 = (_argn_6540 > _3622);
    _3622 = NOVALUE;
    if (_3623 == 0)
    {
        DeRef(_3623);
        _3623 = NOVALUE;
        goto L22; // [1123] 1169
    }
    else{
        DeRef(_3623);
        _3623 = NOVALUE;
    }
L21: 

    /**     				if length(envvar) > 0 then*/
    if (IS_SEQUENCE(_envvar_6551)){
            _3624 = SEQ_PTR(_envvar_6551)->length;
    }
    else {
        _3624 = 1;
    }
    if (_3624 <= 0)
    goto L23; // [1134] 1153

    /**     					argtext = envvar*/
    Ref(_envvar_6551);
    DeRef(_argtext_6714);
    _argtext_6714 = _envvar_6551;

    /** 	    				currargv = envvar*/
    Ref(_envvar_6551);
    DeRef(_currargv_6548);
    _currargv_6548 = _envvar_6551;
    goto L24; // [1150] 2553
L23: 

    /**     					argtext = ""*/
    RefDS(_5);
    DeRef(_argtext_6714);
    _argtext_6714 = _5;

    /** 	    				currargv =""*/
    RefDS(_5);
    DeRef(_currargv_6548);
    _currargv_6548 = _5;
    goto L24; // [1166] 2553
L22: 

    /** 					if string(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3626 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    Ref(_3626);
    _3627 = _9string(_3626);
    _3626 = NOVALUE;
    if (_3627 == 0) {
        DeRef(_3627);
        _3627 = NOVALUE;
        goto L25; // [1179] 1229
    }
    else {
        if (!IS_ATOM_INT(_3627) && DBL_PTR(_3627)->dbl == 0.0){
            DeRef(_3627);
            _3627 = NOVALUE;
            goto L25; // [1179] 1229
        }
        DeRef(_3627);
        _3627 = NOVALUE;
    }
    DeRef(_3627);
    _3627 = NOVALUE;

    /** 						if length(idname) > 0 then*/
    if (IS_SEQUENCE(_idname_6549)){
            _3628 = SEQ_PTR(_idname_6549)->length;
    }
    else {
        _3628 = 1;
    }
    if (_3628 <= 0)
    goto L26; // [1189] 1217

    /** 							argtext = arg_list[argn][length(idname) + 1 .. $]*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3630 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (IS_SEQUENCE(_idname_6549)){
            _3631 = SEQ_PTR(_idname_6549)->length;
    }
    else {
        _3631 = 1;
    }
    _3632 = _3631 + 1;
    _3631 = NOVALUE;
    if (IS_SEQUENCE(_3630)){
            _3633 = SEQ_PTR(_3630)->length;
    }
    else {
        _3633 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_3630, _3632, _3633);
    _3630 = NOVALUE;
    goto L27; // [1214] 2546
L26: 

    /** 							argtext = arg_list[argn]*/
    DeRef(_argtext_6714);
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _argtext_6714 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    Ref(_argtext_6714);
    goto L27; // [1226] 2546
L25: 

    /** 					elsif integer(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3636 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (IS_ATOM_INT(_3636))
    _3637 = 1;
    else if (IS_ATOM_DBL(_3636))
    _3637 = IS_ATOM_INT(DoubleToInt(_3636));
    else
    _3637 = 0;
    _3636 = NOVALUE;
    if (_3637 == 0)
    {
        _3637 = NOVALUE;
        goto L28; // [1238] 1718
    }
    else{
        _3637 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_6546 == 0)
    {
        goto L29; // [1245] 1269
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(arg_list[argn]))}*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3638 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    Ref(_3638);
    _3639 = _21abs(_3638);
    _3638 = NOVALUE;
    _3640 = binary_op(AND_BITS, _1151, _3639);
    DeRef(_3639);
    _3639 = NOVALUE;
    _0 = _argtext_6714;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3640;
    _argtext_6714 = MAKE_SEQ(_1);
    DeRef(_0);
    _3640 = NOVALUE;
    goto L27; // [1266] 2546
L29: 

    /** 						elsif bwz != 0 and arg_list[argn] = 0 then*/
    _3642 = (_bwz_6534 != 0);
    if (_3642 == 0) {
        goto L2A; // [1277] 1304
    }
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3644 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (IS_ATOM_INT(_3644)) {
        _3645 = (_3644 == 0);
    }
    else {
        _3645 = binary_op(EQUALS, _3644, 0);
    }
    _3644 = NOVALUE;
    if (_3645 == 0) {
        DeRef(_3645);
        _3645 = NOVALUE;
        goto L2A; // [1290] 1304
    }
    else {
        if (!IS_ATOM_INT(_3645) && DBL_PTR(_3645)->dbl == 0.0){
            DeRef(_3645);
            _3645 = NOVALUE;
            goto L2A; // [1290] 1304
        }
        DeRef(_3645);
        _3645 = NOVALUE;
    }
    DeRef(_3645);
    _3645 = NOVALUE;

    /** 							argtext = repeat(' ', width)*/
    DeRef(_argtext_6714);
    _argtext_6714 = Repeat(32, _width_6537);
    goto L27; // [1301] 2546
L2A: 

    /** 						elsif binout = 1 then*/
    if (_binout_6544 != 1)
    goto L2B; // [1308] 1382

    /** 							argtext = stdseq:reverse( convert:int_to_bits(arg_list[argn], 32)) + '0'*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3648 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    Ref(_3648);
    _3649 = _19int_to_bits(_3648, 32);
    _3648 = NOVALUE;
    _3650 = _24reverse(_3649, 1, 0);
    _3649 = NOVALUE;
    DeRef(_argtext_6714);
    if (IS_ATOM_INT(_3650)) {
        _argtext_6714 = _3650 + 48;
        if ((long)((unsigned long)_argtext_6714 + (unsigned long)HIGH_BITS) >= 0) 
        _argtext_6714 = NewDouble((double)_argtext_6714);
    }
    else {
        _argtext_6714 = binary_op(PLUS, _3650, 48);
    }
    DeRef(_3650);
    _3650 = NOVALUE;

    /** 							for ib = 1 to length(argtext) do*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3652 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3652 = 1;
    }
    {
        int _ib_6763;
        _ib_6763 = 1;
L2C: 
        if (_ib_6763 > _3652){
            goto L2D; // [1340] 1379
        }

        /** 								if argtext[ib] = '1' then*/
        _2 = (int)SEQ_PTR(_argtext_6714);
        _3653 = (int)*(((s1_ptr)_2)->base + _ib_6763);
        if (binary_op_a(NOTEQ, _3653, 49)){
            _3653 = NOVALUE;
            goto L2E; // [1353] 1372
        }
        _3653 = NOVALUE;

        /** 									argtext = argtext[ib .. $]*/
        if (IS_SEQUENCE(_argtext_6714)){
                _3655 = SEQ_PTR(_argtext_6714)->length;
        }
        else {
            _3655 = 1;
        }
        rhs_slice_target = (object_ptr)&_argtext_6714;
        RHS_Slice(_argtext_6714, _ib_6763, _3655);

        /** 									exit*/
        goto L2D; // [1369] 1379
L2E: 

        /** 							end for*/
        _ib_6763 = _ib_6763 + 1;
        goto L2C; // [1374] 1347
L2D: 
        ;
    }
    goto L27; // [1379] 2546
L2B: 

    /** 						elsif hexout = 0 then*/
    if (_hexout_6543 != 0)
    goto L2F; // [1386] 1652

    /** 							argtext = sprintf("%d", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3658 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_argtext_6714);
    _argtext_6714 = EPrintf(-9999999, _613, _3658);
    _3658 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _3660 = (_zfill_6533 != 0);
    if (_3660 == 0) {
        goto L30; // [1408] 1505
    }
    _3662 = (_width_6537 > 0);
    if (_3662 == 0)
    {
        DeRef(_3662);
        _3662 = NOVALUE;
        goto L30; // [1419] 1505
    }
    else{
        DeRef(_3662);
        _3662 = NOVALUE;
    }

    /** 								if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3663 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3663, 45)){
        _3663 = NOVALUE;
        goto L31; // [1428] 1474
    }
    _3663 = NOVALUE;

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3665 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3665 = 1;
    }
    if (_width_6537 <= _3665)
    goto L32; // [1439] 1504

    /** 										argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3667 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3667 = 1;
    }
    _3668 = _width_6537 - _3667;
    _3667 = NOVALUE;
    _3669 = Repeat(48, _3668);
    _3668 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6714)){
            _3670 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3670 = 1;
    }
    rhs_slice_target = (object_ptr)&_3671;
    RHS_Slice(_argtext_6714, 2, _3670);
    {
        int concat_list[3];

        concat_list[0] = _3671;
        concat_list[1] = _3669;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3671);
    _3671 = NOVALUE;
    DeRefDS(_3669);
    _3669 = NOVALUE;
    goto L32; // [1471] 1504
L31: 

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3673 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3673 = 1;
    }
    if (_width_6537 <= _3673)
    goto L33; // [1481] 1503

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3675 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3675 = 1;
    }
    _3676 = _width_6537 - _3675;
    _3675 = NOVALUE;
    _3677 = Repeat(48, _3676);
    _3676 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _3677, _argtext_6714);
    DeRefDS(_3677);
    _3677 = NOVALUE;
    DeRef(_3677);
    _3677 = NOVALUE;
L33: 
L32: 
L30: 

    /** 							if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3679 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (binary_op_a(LESSEQ, _3679, 0)){
        _3679 = NOVALUE;
        goto L34; // [1511] 1559
    }
    _3679 = NOVALUE;

    /** 								if psign then*/
    if (_psign_6531 == 0)
    {
        goto L27; // [1519] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_6533 != 0)
    goto L35; // [1524] 1537

    /** 										argtext = '+' & argtext*/
    Prepend(&_argtext_6714, _argtext_6714, 43);
    goto L27; // [1534] 2546
L35: 

    /** 									elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3683 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3683, 48)){
        _3683 = NOVALUE;
        goto L27; // [1543] 2546
    }
    _3683 = NOVALUE;

    /** 										argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_6714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [1556] 2546
L34: 

    /** 							elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3685 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (binary_op_a(GREATEREQ, _3685, 0)){
        _3685 = NOVALUE;
        goto L27; // [1565] 2546
    }
    _3685 = NOVALUE;

    /** 								if msign then*/
    if (_msign_6532 == 0)
    {
        goto L27; // [1573] 2546
    }
    else{
    }

    /** 									if zfill = 0 then*/
    if (_zfill_6533 != 0)
    goto L36; // [1578] 1601

    /** 										argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3688 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3688 = 1;
    }
    rhs_slice_target = (object_ptr)&_3689;
    RHS_Slice(_argtext_6714, 2, _3688);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3689;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3689);
    _3689 = NOVALUE;
    goto L27; // [1598] 2546
L36: 

    /** 										if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3692 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3692, 48)){
        _3692 = NOVALUE;
        goto L37; // [1607] 1630
    }
    _3692 = NOVALUE;

    /** 											argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3694 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3694 = 1;
    }
    rhs_slice_target = (object_ptr)&_3695;
    RHS_Slice(_argtext_6714, 3, _3694);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3695;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3695);
    _3695 = NOVALUE;
    goto L27; // [1627] 2546
L37: 

    /** 											argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3697 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3697 = 1;
    }
    rhs_slice_target = (object_ptr)&_3698;
    RHS_Slice(_argtext_6714, 2, _3697);
    Append(&_argtext_6714, _3698, 41);
    DeRefDS(_3698);
    _3698 = NOVALUE;
    goto L27; // [1649] 2546
L2F: 

    /** 							argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3701 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_argtext_6714);
    _argtext_6714 = EPrintf(-9999999, _3700, _3701);
    _3701 = NOVALUE;

    /** 							if zfill != 0 and width > 0 then*/
    _3703 = (_zfill_6533 != 0);
    if (_3703 == 0) {
        goto L27; // [1670] 2546
    }
    _3705 = (_width_6537 > 0);
    if (_3705 == 0)
    {
        DeRef(_3705);
        _3705 = NOVALUE;
        goto L27; // [1681] 2546
    }
    else{
        DeRef(_3705);
        _3705 = NOVALUE;
    }

    /** 								if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3706 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3706 = 1;
    }
    if (_width_6537 <= _3706)
    goto L27; // [1691] 2546

    /** 									argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3708 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3708 = 1;
    }
    _3709 = _width_6537 - _3708;
    _3708 = NOVALUE;
    _3710 = Repeat(48, _3709);
    _3709 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _3710, _argtext_6714);
    DeRefDS(_3710);
    _3710 = NOVALUE;
    DeRef(_3710);
    _3710 = NOVALUE;
    goto L27; // [1715] 2546
L28: 

    /** 					elsif atom(arg_list[argn]) then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3712 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    _3713 = IS_ATOM(_3712);
    _3712 = NOVALUE;
    if (_3713 == 0)
    {
        _3713 = NOVALUE;
        goto L38; // [1727] 2130
    }
    else{
        _3713 = NOVALUE;
    }

    /** 						if istext then*/
    if (_istext_6546 == 0)
    {
        goto L39; // [1734] 1761
    }
    else{
    }

    /** 							argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(arg_list[argn])))}*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3714 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (IS_ATOM_INT(_3714))
    _3715 = e_floor(_3714);
    else
    _3715 = unary_op(FLOOR, _3714);
    _3714 = NOVALUE;
    _3716 = _21abs(_3715);
    _3715 = NOVALUE;
    _3717 = binary_op(AND_BITS, _1151, _3716);
    DeRef(_3716);
    _3716 = NOVALUE;
    _0 = _argtext_6714;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3717;
    _argtext_6714 = MAKE_SEQ(_1);
    DeRef(_0);
    _3717 = NOVALUE;
    goto L27; // [1758] 2546
L39: 

    /** 							if hexout then*/
    if (_hexout_6543 == 0)
    {
        goto L3A; // [1765] 1833
    }
    else{
    }

    /** 								argtext = sprintf("%x", arg_list[argn])*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3719 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_argtext_6714);
    _argtext_6714 = EPrintf(-9999999, _3700, _3719);
    _3719 = NOVALUE;

    /** 								if zfill != 0 and width > 0 then*/
    _3721 = (_zfill_6533 != 0);
    if (_3721 == 0) {
        goto L27; // [1786] 2546
    }
    _3723 = (_width_6537 > 0);
    if (_3723 == 0)
    {
        DeRef(_3723);
        _3723 = NOVALUE;
        goto L27; // [1797] 2546
    }
    else{
        DeRef(_3723);
        _3723 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3724 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3724 = 1;
    }
    if (_width_6537 <= _3724)
    goto L27; // [1807] 2546

    /** 										argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3726 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3726 = 1;
    }
    _3727 = _width_6537 - _3726;
    _3726 = NOVALUE;
    _3728 = Repeat(48, _3727);
    _3727 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _3728, _argtext_6714);
    DeRefDS(_3728);
    _3728 = NOVALUE;
    DeRef(_3728);
    _3728 = NOVALUE;
    goto L27; // [1830] 2546
L3A: 

    /** 								argtext = trim(sprintf("%15.15g", arg_list[argn]))*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3731 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    _3732 = EPrintf(-9999999, _3730, _3731);
    _3731 = NOVALUE;
    RefDS(_2965);
    _0 = _argtext_6714;
    _argtext_6714 = _18trim(_3732, _2965, 0);
    DeRef(_0);
    _3732 = NOVALUE;

    /** 								while ep != 0 with entry do*/
    goto L3B; // [1853] 1876
L3C: 
    if (_ep_6552 == 0)
    goto L3D; // [1858] 1888

    /** 									argtext = remove(argtext, ep+2)*/
    _3735 = _ep_6552 + 2;
    if ((long)((unsigned long)_3735 + (unsigned long)HIGH_BITS) >= 0) 
    _3735 = NewDouble((double)_3735);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_6714);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_3735)) ? _3735 : (long)(DBL_PTR(_3735)->dbl);
        int stop = (IS_ATOM_INT(_3735)) ? _3735 : (long)(DBL_PTR(_3735)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_6714), start, &_argtext_6714 );
            }
            else Tail(SEQ_PTR(_argtext_6714), stop+1, &_argtext_6714);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_6714), start, &_argtext_6714);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_6714 = Remove_elements(start, stop, (SEQ_PTR(_argtext_6714)->ref == 1));
        }
    }
    DeRef(_3735);
    _3735 = NOVALUE;
    _3735 = NOVALUE;

    /** 								entry*/
L3B: 

    /** 									ep = match("e+0", argtext)*/
    _ep_6552 = e_match_from(_3737, _argtext_6714, 1);

    /** 								end while*/
    goto L3C; // [1885] 1856
L3D: 

    /** 								if zfill != 0 and width > 0 then*/
    _3739 = (_zfill_6533 != 0);
    if (_3739 == 0) {
        goto L3E; // [1896] 1981
    }
    _3741 = (_width_6537 > 0);
    if (_3741 == 0)
    {
        DeRef(_3741);
        _3741 = NOVALUE;
        goto L3E; // [1907] 1981
    }
    else{
        DeRef(_3741);
        _3741 = NOVALUE;
    }

    /** 									if width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3742 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3742 = 1;
    }
    if (_width_6537 <= _3742)
    goto L3F; // [1917] 1980

    /** 										if argtext[1] = '-' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3744 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3744, 45)){
        _3744 = NOVALUE;
        goto L40; // [1927] 1961
    }
    _3744 = NOVALUE;

    /** 											argtext = '-' & repeat('0', width - length(argtext)) & argtext[2..$]*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3746 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3746 = 1;
    }
    _3747 = _width_6537 - _3746;
    _3746 = NOVALUE;
    _3748 = Repeat(48, _3747);
    _3747 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6714)){
            _3749 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3749 = 1;
    }
    rhs_slice_target = (object_ptr)&_3750;
    RHS_Slice(_argtext_6714, 2, _3749);
    {
        int concat_list[3];

        concat_list[0] = _3750;
        concat_list[1] = _3748;
        concat_list[2] = 45;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3750);
    _3750 = NOVALUE;
    DeRefDS(_3748);
    _3748 = NOVALUE;
    goto L41; // [1958] 1979
L40: 

    /** 											argtext = repeat('0', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3752 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3752 = 1;
    }
    _3753 = _width_6537 - _3752;
    _3752 = NOVALUE;
    _3754 = Repeat(48, _3753);
    _3753 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _3754, _argtext_6714);
    DeRefDS(_3754);
    _3754 = NOVALUE;
    DeRef(_3754);
    _3754 = NOVALUE;
L41: 
L3F: 
L3E: 

    /** 								if arg_list[argn] > 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3756 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (binary_op_a(LESSEQ, _3756, 0)){
        _3756 = NOVALUE;
        goto L42; // [1987] 2035
    }
    _3756 = NOVALUE;

    /** 									if psign  then*/
    if (_psign_6531 == 0)
    {
        goto L27; // [1995] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_6533 != 0)
    goto L43; // [2000] 2013

    /** 											argtext = '+' & argtext*/
    Prepend(&_argtext_6714, _argtext_6714, 43);
    goto L27; // [2010] 2546
L43: 

    /** 										elsif argtext[1] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3760 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _3760, 48)){
        _3760 = NOVALUE;
        goto L27; // [2019] 2546
    }
    _3760 = NOVALUE;

    /** 											argtext[1] = '+'*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_6714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = 43;
    DeRef(_1);
    goto L27; // [2032] 2546
L42: 

    /** 								elsif arg_list[argn] < 0 then*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3762 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (binary_op_a(GREATEREQ, _3762, 0)){
        _3762 = NOVALUE;
        goto L27; // [2041] 2546
    }
    _3762 = NOVALUE;

    /** 									if msign then*/
    if (_msign_6532 == 0)
    {
        goto L27; // [2049] 2546
    }
    else{
    }

    /** 										if zfill = 0 then*/
    if (_zfill_6533 != 0)
    goto L44; // [2054] 2077

    /** 											argtext = '(' & argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3765 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3765 = 1;
    }
    rhs_slice_target = (object_ptr)&_3766;
    RHS_Slice(_argtext_6714, 2, _3765);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3766;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3766);
    _3766 = NOVALUE;
    goto L27; // [2074] 2546
L44: 

    /** 											if argtext[2] = '0' then*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3768 = (int)*(((s1_ptr)_2)->base + 2);
    if (binary_op_a(NOTEQ, _3768, 48)){
        _3768 = NOVALUE;
        goto L45; // [2083] 2106
    }
    _3768 = NOVALUE;

    /** 												argtext = '(' & argtext[3..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3770 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3770 = 1;
    }
    rhs_slice_target = (object_ptr)&_3771;
    RHS_Slice(_argtext_6714, 3, _3770);
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _3771;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3771);
    _3771 = NOVALUE;
    goto L27; // [2103] 2546
L45: 

    /** 												argtext = argtext[2..$] & ')'*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3773 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3773 = 1;
    }
    rhs_slice_target = (object_ptr)&_3774;
    RHS_Slice(_argtext_6714, 2, _3773);
    Append(&_argtext_6714, _3774, 41);
    DeRefDS(_3774);
    _3774 = NOVALUE;
    goto L27; // [2127] 2546
L38: 

    /** 						if alt != 0 and length(arg_list[argn]) = 2 then*/
    _3776 = (_alt_6536 != 0);
    if (_3776 == 0) {
        goto L46; // [2138] 2457
    }
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3778 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    if (IS_SEQUENCE(_3778)){
            _3779 = SEQ_PTR(_3778)->length;
    }
    else {
        _3779 = 1;
    }
    _3778 = NOVALUE;
    _3780 = (_3779 == 2);
    _3779 = NOVALUE;
    if (_3780 == 0)
    {
        DeRef(_3780);
        _3780 = NOVALUE;
        goto L46; // [2154] 2457
    }
    else{
        DeRef(_3780);
        _3780 = NOVALUE;
    }

    /** 							object tempv*/

    /** 							if atom(prevargv) then*/
    _3781 = IS_ATOM(_prevargv_6547);
    if (_3781 == 0)
    {
        _3781 = NOVALUE;
        goto L47; // [2164] 2200
    }
    else{
        _3781 = NOVALUE;
    }

    /** 								if prevargv != 1 then*/
    if (binary_op_a(EQUALS, _prevargv_6547, 1)){
        goto L48; // [2169] 2186
    }

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3783 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_tempv_6937);
    _2 = (int)SEQ_PTR(_3783);
    _tempv_6937 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_6937);
    _3783 = NOVALUE;
    goto L49; // [2183] 2234
L48: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3785 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_tempv_6937);
    _2 = (int)SEQ_PTR(_3785);
    _tempv_6937 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_6937);
    _3785 = NOVALUE;
    goto L49; // [2197] 2234
L47: 

    /** 								if length(prevargv) = 0 then*/
    if (IS_SEQUENCE(_prevargv_6547)){
            _3787 = SEQ_PTR(_prevargv_6547)->length;
    }
    else {
        _3787 = 1;
    }
    if (_3787 != 0)
    goto L4A; // [2205] 2222

    /** 									tempv = arg_list[argn][1]*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3789 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_tempv_6937);
    _2 = (int)SEQ_PTR(_3789);
    _tempv_6937 = (int)*(((s1_ptr)_2)->base + 1);
    Ref(_tempv_6937);
    _3789 = NOVALUE;
    goto L4B; // [2219] 2233
L4A: 

    /** 									tempv = arg_list[argn][2]*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3791 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    DeRef(_tempv_6937);
    _2 = (int)SEQ_PTR(_3791);
    _tempv_6937 = (int)*(((s1_ptr)_2)->base + 2);
    Ref(_tempv_6937);
    _3791 = NOVALUE;
L4B: 
L49: 

    /** 							if string(tempv) then*/
    Ref(_tempv_6937);
    _3793 = _9string(_tempv_6937);
    if (_3793 == 0) {
        DeRef(_3793);
        _3793 = NOVALUE;
        goto L4C; // [2242] 2255
    }
    else {
        if (!IS_ATOM_INT(_3793) && DBL_PTR(_3793)->dbl == 0.0){
            DeRef(_3793);
            _3793 = NOVALUE;
            goto L4C; // [2242] 2255
        }
        DeRef(_3793);
        _3793 = NOVALUE;
    }
    DeRef(_3793);
    _3793 = NOVALUE;

    /** 								argtext = tempv*/
    Ref(_tempv_6937);
    DeRef(_argtext_6714);
    _argtext_6714 = _tempv_6937;
    goto L4D; // [2252] 2452
L4C: 

    /** 							elsif integer(tempv) then*/
    if (IS_ATOM_INT(_tempv_6937))
    _3794 = 1;
    else if (IS_ATOM_DBL(_tempv_6937))
    _3794 = IS_ATOM_INT(DoubleToInt(_tempv_6937));
    else
    _3794 = 0;
    if (_3794 == 0)
    {
        _3794 = NOVALUE;
        goto L4E; // [2260] 2326
    }
    else{
        _3794 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_6546 == 0)
    {
        goto L4F; // [2265] 2285
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(tempv))}*/
    Ref(_tempv_6937);
    _3795 = _21abs(_tempv_6937);
    _3796 = binary_op(AND_BITS, _1151, _3795);
    DeRef(_3795);
    _3795 = NOVALUE;
    _0 = _argtext_6714;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3796;
    _argtext_6714 = MAKE_SEQ(_1);
    DeRef(_0);
    _3796 = NOVALUE;
    goto L4D; // [2282] 2452
L4F: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _3798 = (_bwz_6534 != 0);
    if (_3798 == 0) {
        goto L50; // [2293] 2316
    }
    if (IS_ATOM_INT(_tempv_6937)) {
        _3800 = (_tempv_6937 == 0);
    }
    else {
        _3800 = binary_op(EQUALS, _tempv_6937, 0);
    }
    if (_3800 == 0) {
        DeRef(_3800);
        _3800 = NOVALUE;
        goto L50; // [2302] 2316
    }
    else {
        if (!IS_ATOM_INT(_3800) && DBL_PTR(_3800)->dbl == 0.0){
            DeRef(_3800);
            _3800 = NOVALUE;
            goto L50; // [2302] 2316
        }
        DeRef(_3800);
        _3800 = NOVALUE;
    }
    DeRef(_3800);
    _3800 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_6714);
    _argtext_6714 = Repeat(32, _width_6537);
    goto L4D; // [2313] 2452
L50: 

    /** 									argtext = sprintf("%d", tempv)*/
    DeRef(_argtext_6714);
    _argtext_6714 = EPrintf(-9999999, _613, _tempv_6937);
    goto L4D; // [2323] 2452
L4E: 

    /** 							elsif atom(tempv) then*/
    _3803 = IS_ATOM(_tempv_6937);
    if (_3803 == 0)
    {
        _3803 = NOVALUE;
        goto L51; // [2331] 2408
    }
    else{
        _3803 = NOVALUE;
    }

    /** 								if istext then*/
    if (_istext_6546 == 0)
    {
        goto L52; // [2336] 2359
    }
    else{
    }

    /** 									argtext = {and_bits(0xFFFF_FFFF, math:abs(floor(tempv)))}*/
    if (IS_ATOM_INT(_tempv_6937))
    _3804 = e_floor(_tempv_6937);
    else
    _3804 = unary_op(FLOOR, _tempv_6937);
    _3805 = _21abs(_3804);
    _3804 = NOVALUE;
    _3806 = binary_op(AND_BITS, _1151, _3805);
    DeRef(_3805);
    _3805 = NOVALUE;
    _0 = _argtext_6714;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = _3806;
    _argtext_6714 = MAKE_SEQ(_1);
    DeRef(_0);
    _3806 = NOVALUE;
    goto L4D; // [2356] 2452
L52: 

    /** 								elsif bwz != 0 and tempv = 0 then*/
    _3808 = (_bwz_6534 != 0);
    if (_3808 == 0) {
        goto L53; // [2367] 2390
    }
    if (IS_ATOM_INT(_tempv_6937)) {
        _3810 = (_tempv_6937 == 0);
    }
    else {
        _3810 = binary_op(EQUALS, _tempv_6937, 0);
    }
    if (_3810 == 0) {
        DeRef(_3810);
        _3810 = NOVALUE;
        goto L53; // [2376] 2390
    }
    else {
        if (!IS_ATOM_INT(_3810) && DBL_PTR(_3810)->dbl == 0.0){
            DeRef(_3810);
            _3810 = NOVALUE;
            goto L53; // [2376] 2390
        }
        DeRef(_3810);
        _3810 = NOVALUE;
    }
    DeRef(_3810);
    _3810 = NOVALUE;

    /** 									argtext = repeat(' ', width)*/
    DeRef(_argtext_6714);
    _argtext_6714 = Repeat(32, _width_6537);
    goto L4D; // [2387] 2452
L53: 

    /** 									argtext = trim(sprintf("%15.15g", tempv))*/
    _3812 = EPrintf(-9999999, _3730, _tempv_6937);
    RefDS(_2965);
    _0 = _argtext_6714;
    _argtext_6714 = _18trim(_3812, _2965, 0);
    DeRef(_0);
    _3812 = NOVALUE;
    goto L4D; // [2405] 2452
L51: 

    /** 								argtext = pretty:pretty_sprint( tempv,*/
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_613);
    *((int *)(_2+20)) = _613;
    RefDS(_3814);
    *((int *)(_2+24)) = _3814;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _3815 = MAKE_SEQ(_1);
    DeRef(_options_inlined_pretty_sprint_at_2424_6991);
    _options_inlined_pretty_sprint_at_2424_6991 = _3815;
    _3815 = NOVALUE;

    /** 	pretty_printing = 0*/
    _10pretty_printing_1342 = 0;

    /** 	pretty( x, options )*/
    Ref(_tempv_6937);
    RefDS(_options_inlined_pretty_sprint_at_2424_6991);
    _10pretty(_tempv_6937, _options_inlined_pretty_sprint_at_2424_6991);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1345);
    DeRef(_argtext_6714);
    _argtext_6714 = _10pretty_line_1345;
    DeRef(_options_inlined_pretty_sprint_at_2424_6991);
    _options_inlined_pretty_sprint_at_2424_6991 = NOVALUE;
L4D: 
    DeRef(_tempv_6937);
    _tempv_6937 = NOVALUE;
    goto L54; // [2454] 2533
L46: 

    /** 							argtext = pretty:pretty_sprint( arg_list[argn],*/
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _3816 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    _1 = NewS1(10);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 2;
    *((int *)(_2+8)) = 0;
    *((int *)(_2+12)) = 1;
    *((int *)(_2+16)) = 1000;
    RefDS(_613);
    *((int *)(_2+20)) = _613;
    RefDS(_3814);
    *((int *)(_2+24)) = _3814;
    *((int *)(_2+28)) = 32;
    *((int *)(_2+32)) = 127;
    *((int *)(_2+36)) = 1;
    *((int *)(_2+40)) = 0;
    _3817 = MAKE_SEQ(_1);
    Ref(_3816);
    DeRef(_x_inlined_pretty_sprint_at_2477_6997);
    _x_inlined_pretty_sprint_at_2477_6997 = _3816;
    _3816 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_6998);
    _options_inlined_pretty_sprint_at_2480_6998 = _3817;
    _3817 = NOVALUE;

    /** 	pretty_printing = 0*/
    _10pretty_printing_1342 = 0;

    /** 	pretty( x, options )*/
    Ref(_x_inlined_pretty_sprint_at_2477_6997);
    RefDS(_options_inlined_pretty_sprint_at_2480_6998);
    _10pretty(_x_inlined_pretty_sprint_at_2477_6997, _options_inlined_pretty_sprint_at_2480_6998);

    /** 	return pretty_line*/
    RefDS(_10pretty_line_1345);
    DeRef(_argtext_6714);
    _argtext_6714 = _10pretty_line_1345;
    DeRef(_x_inlined_pretty_sprint_at_2477_6997);
    _x_inlined_pretty_sprint_at_2477_6997 = NOVALUE;
    DeRef(_options_inlined_pretty_sprint_at_2480_6998);
    _options_inlined_pretty_sprint_at_2480_6998 = NOVALUE;

    /** 						while ep != 0 with entry do*/
    goto L54; // [2510] 2533
L55: 
    if (_ep_6552 == 0)
    goto L56; // [2515] 2545

    /** 							argtext = remove(argtext, ep+2)*/
    _3819 = _ep_6552 + 2;
    if ((long)((unsigned long)_3819 + (unsigned long)HIGH_BITS) >= 0) 
    _3819 = NewDouble((double)_3819);
    {
        s1_ptr assign_space = SEQ_PTR(_argtext_6714);
        int len = assign_space->length;
        int start = (IS_ATOM_INT(_3819)) ? _3819 : (long)(DBL_PTR(_3819)->dbl);
        int stop = (IS_ATOM_INT(_3819)) ? _3819 : (long)(DBL_PTR(_3819)->dbl);
        if (stop > len){
            stop = len;
        }
        if (start > len || start > stop || stop<0) {
        }
        else if (start < 2) {
            if (stop >= len) {
                Head( SEQ_PTR(_argtext_6714), start, &_argtext_6714 );
            }
            else Tail(SEQ_PTR(_argtext_6714), stop+1, &_argtext_6714);
        }
        else if (stop >= len){
            Head(SEQ_PTR(_argtext_6714), start, &_argtext_6714);
        }
        else {
            assign_slice_seq = &assign_space;
            _argtext_6714 = Remove_elements(start, stop, (SEQ_PTR(_argtext_6714)->ref == 1));
        }
    }
    DeRef(_3819);
    _3819 = NOVALUE;
    _3819 = NOVALUE;

    /** 						entry*/
L54: 

    /** 							ep = match("e+0", argtext)*/
    _ep_6552 = e_match_from(_3737, _argtext_6714, 1);

    /** 						end while*/
    goto L55; // [2542] 2513
L56: 
L27: 

    /** 	    			currargv = arg_list[argn]*/
    DeRef(_currargv_6548);
    _2 = (int)SEQ_PTR(_arg_list_6523);
    _currargv_6548 = (int)*(((s1_ptr)_2)->base + _argn_6540);
    Ref(_currargv_6548);
L24: 

    /**     			if length(argtext) > 0 then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3823 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3823 = 1;
    }
    if (_3823 <= 0)
    goto L57; // [2558] 3328

    /**     				switch cap do*/
    _0 = _cap_6529;
    switch ( _0 ){ 

        /**     					case 'u' then*/
        case 117:

        /**     						argtext = upper(argtext)*/
        RefDS(_argtext_6714);
        _0 = _argtext_6714;
        _argtext_6714 = _18upper(_argtext_6714);
        DeRefDS(_0);
        goto L58; // [2583] 2649

        /**     					case 'l' then*/
        case 108:

        /**     						argtext = lower(argtext)*/
        RefDS(_argtext_6714);
        _0 = _argtext_6714;
        _argtext_6714 = _18lower(_argtext_6714);
        DeRefDS(_0);
        goto L58; // [2597] 2649

        /**     					case 'w' then*/
        case 119:

        /**     						argtext = proper(argtext)*/
        RefDS(_argtext_6714);
        _0 = _argtext_6714;
        _argtext_6714 = _18proper(_argtext_6714);
        DeRefDS(_0);
        goto L58; // [2611] 2649

        /**     					case 0 then*/
        case 0:

        /** 							cap = cap*/
        _cap_6529 = _cap_6529;
        goto L58; // [2622] 2649

        /**     					case else*/
        default:

        /**     						error:crash("logic error: 'cap' mode in format.")*/

        /** 	msg = sprintf(fmt, data)*/
        DeRefi(_msg_inlined_crash_at_2631_7021);
        _msg_inlined_crash_at_2631_7021 = EPrintf(-9999999, _3830, _5);

        /** 	machine_proc(M_CRASH, msg)*/
        machine(67, _msg_inlined_crash_at_2631_7021);

        /** end procedure*/
        goto L59; // [2643] 2646
L59: 
        DeRefi(_msg_inlined_crash_at_2631_7021);
        _msg_inlined_crash_at_2631_7021 = NOVALUE;
    ;}L58: 

    /** 					if atom(currargv) then*/
    _3831 = IS_ATOM(_currargv_6548);
    if (_3831 == 0)
    {
        _3831 = NOVALUE;
        goto L5A; // [2656] 2795
    }
    else{
        _3831 = NOVALUE;
    }

    /** 						if find('e', argtext) = 0 then*/
    _3832 = find_from(101, _argtext_6714, 1);
    if (_3832 != 0)
    goto L5B; // [2666] 2794

    /** 							if decs != -1 then*/
    if (_decs_6538 == -1)
    goto L5C; // [2674] 2793

    /** 								pos = find('.', argtext)*/
    _pos_6539 = find_from(46, _argtext_6714, 1);

    /** 								if pos then*/
    if (_pos_6539 == 0)
    {
        goto L5D; // [2687] 2772
    }
    else{
    }

    /** 									if decs = 0 then*/
    if (_decs_6538 != 0)
    goto L5E; // [2692] 2710

    /** 										argtext = argtext [1 .. pos-1 ]*/
    _3837 = _pos_6539 - 1;
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, 1, _3837);
    goto L5F; // [2707] 2792
L5E: 

    /** 										pos = length(argtext) - pos*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3839 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3839 = 1;
    }
    _pos_6539 = _3839 - _pos_6539;
    _3839 = NOVALUE;

    /** 										if pos > decs then*/
    if (_pos_6539 <= _decs_6538)
    goto L60; // [2721] 2746

    /** 											argtext = argtext[ 1 .. $ - pos + decs ]*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3842 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3842 = 1;
    }
    _3843 = _3842 - _pos_6539;
    if ((long)((unsigned long)_3843 +(unsigned long) HIGH_BITS) >= 0){
        _3843 = NewDouble((double)_3843);
    }
    _3842 = NOVALUE;
    if (IS_ATOM_INT(_3843)) {
        _3844 = _3843 + _decs_6538;
    }
    else {
        _3844 = NewDouble(DBL_PTR(_3843)->dbl + (double)_decs_6538);
    }
    DeRef(_3843);
    _3843 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, 1, _3844);
    goto L5F; // [2743] 2792
L60: 

    /** 										elsif pos < decs then*/
    if (_pos_6539 >= _decs_6538)
    goto L5F; // [2748] 2792

    /** 											argtext = argtext & repeat('0', decs - pos)*/
    _3847 = _decs_6538 - _pos_6539;
    _3848 = Repeat(48, _3847);
    _3847 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _argtext_6714, _3848);
    DeRefDS(_3848);
    _3848 = NOVALUE;
    goto L5F; // [2769] 2792
L5D: 

    /** 								elsif decs > 0 then*/
    if (_decs_6538 <= 0)
    goto L61; // [2774] 2791

    /** 									argtext = argtext & '.' & repeat('0', decs)*/
    _3851 = Repeat(48, _decs_6538);
    {
        int concat_list[3];

        concat_list[0] = _3851;
        concat_list[1] = 46;
        concat_list[2] = _argtext_6714;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3851);
    _3851 = NOVALUE;
L61: 
L5F: 
L5C: 
L5B: 
L5A: 

    /**     				if align = 0 then*/
    if (_align_6530 != 0)
    goto L62; // [2799] 2826

    /**     					if atom(currargv) then*/
    _3854 = IS_ATOM(_currargv_6548);
    if (_3854 == 0)
    {
        _3854 = NOVALUE;
        goto L63; // [2808] 2819
    }
    else{
        _3854 = NOVALUE;
    }

    /**     						align = '>'*/
    _align_6530 = 62;
    goto L64; // [2816] 2825
L63: 

    /**     						align = '<'*/
    _align_6530 = 60;
L64: 
L62: 

    /**     				if atom(currargv) then*/
    _3855 = IS_ATOM(_currargv_6548);
    if (_3855 == 0)
    {
        _3855 = NOVALUE;
        goto L65; // [2831] 3032
    }
    else{
        _3855 = NOVALUE;
    }

    /** 	    				if tsep != 0 and zfill = 0 then*/
    _3856 = (_tsep_6545 != 0);
    if (_3856 == 0) {
        goto L66; // [2842] 3029
    }
    _3858 = (_zfill_6533 == 0);
    if (_3858 == 0)
    {
        DeRef(_3858);
        _3858 = NOVALUE;
        goto L66; // [2853] 3029
    }
    else{
        DeRef(_3858);
        _3858 = NOVALUE;
    }

    /** 	    					integer dpos*/

    /** 	    					integer dist*/

    /** 	    					integer bracketed*/

    /** 	    					if binout or hexout then*/
    if (_binout_6544 != 0) {
        goto L67; // [2866] 2875
    }
    if (_hexout_6543 == 0)
    {
        goto L68; // [2871] 2883
    }
    else{
    }
L67: 

    /** 	    						dist = 4*/
    _dist_7065 = 4;
    goto L69; // [2880] 2889
L68: 

    /** 	    						dist = 3*/
    _dist_7065 = 3;
L69: 

    /** 	    					bracketed = (argtext[1] = '(')*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    _3860 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_3860)) {
        _bracketed_7066 = (_3860 == 40);
    }
    else {
        _bracketed_7066 = binary_op(EQUALS, _3860, 40);
    }
    _3860 = NOVALUE;
    if (!IS_ATOM_INT(_bracketed_7066)) {
        _1 = (long)(DBL_PTR(_bracketed_7066)->dbl);
        DeRefDS(_bracketed_7066);
        _bracketed_7066 = _1;
    }

    /** 	    					if bracketed then*/
    if (_bracketed_7066 == 0)
    {
        goto L6A; // [2903] 2921
    }
    else{
    }

    /** 	    						argtext = argtext[2 .. $-1]*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3862 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3862 = 1;
    }
    _3863 = _3862 - 1;
    _3862 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, 2, _3863);
L6A: 

    /** 	    					dpos = find('.', argtext)*/
    _dpos_7064 = find_from(46, _argtext_6714, 1);

    /** 	    					if dpos = 0 then*/
    if (_dpos_7064 != 0)
    goto L6B; // [2930] 2946

    /** 	    						dpos = length(argtext) + 1*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3867 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3867 = 1;
    }
    _dpos_7064 = _3867 + 1;
    _3867 = NOVALUE;
    goto L6C; // [2943] 2960
L6B: 

    /** 	    						if tsep = '.' then*/
    if (_tsep_6545 != 46)
    goto L6D; // [2948] 2959

    /** 	    							argtext[dpos] = ','*/
    _2 = (int)SEQ_PTR(_argtext_6714);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _argtext_6714 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _dpos_7064);
    _1 = *(int *)_2;
    *(int *)_2 = 44;
    DeRef(_1);
L6D: 
L6C: 

    /** 	    					while dpos > dist do*/
L6E: 
    if (_dpos_7064 <= _dist_7065)
    goto L6F; // [2967] 3014

    /** 	    						dpos -= dist*/
    _dpos_7064 = _dpos_7064 - _dist_7065;

    /** 	    						if dpos > 1 then*/
    if (_dpos_7064 <= 1)
    goto L6E; // [2979] 2965

    /** 	    							argtext = argtext[1.. dpos - 1] & tsep & argtext[dpos .. $]*/
    _3873 = _dpos_7064 - 1;
    rhs_slice_target = (object_ptr)&_3874;
    RHS_Slice(_argtext_6714, 1, _3873);
    if (IS_SEQUENCE(_argtext_6714)){
            _3875 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3875 = 1;
    }
    rhs_slice_target = (object_ptr)&_3876;
    RHS_Slice(_argtext_6714, _dpos_7064, _3875);
    {
        int concat_list[3];

        concat_list[0] = _3876;
        concat_list[1] = _tsep_6545;
        concat_list[2] = _3874;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3876);
    _3876 = NOVALUE;
    DeRefDS(_3874);
    _3874 = NOVALUE;

    /** 	    					end while*/
    goto L6E; // [3011] 2965
L6F: 

    /** 	    					if bracketed then*/
    if (_bracketed_7066 == 0)
    {
        goto L70; // [3016] 3028
    }
    else{
    }

    /** 	    						argtext = '(' & argtext & ')'*/
    {
        int concat_list[3];

        concat_list[0] = 41;
        concat_list[1] = _argtext_6714;
        concat_list[2] = 40;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
L70: 
L66: 
L65: 

    /**     				if width <= 0 then*/
    if (_width_6537 > 0)
    goto L71; // [3036] 3046

    /**     					width = length(argtext)*/
    if (IS_SEQUENCE(_argtext_6714)){
            _width_6537 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _width_6537 = 1;
    }
L71: 

    /**     				if width < length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3881 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3881 = 1;
    }
    if (_width_6537 >= _3881)
    goto L72; // [3051] 3182

    /**     					if align = '>' then*/
    if (_align_6530 != 62)
    goto L73; // [3057] 3085

    /**     						argtext = argtext[ $ - width + 1 .. $]*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3884 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3884 = 1;
    }
    _3885 = _3884 - _width_6537;
    if ((long)((unsigned long)_3885 +(unsigned long) HIGH_BITS) >= 0){
        _3885 = NewDouble((double)_3885);
    }
    _3884 = NOVALUE;
    if (IS_ATOM_INT(_3885)) {
        _3886 = _3885 + 1;
        if (_3886 > MAXINT){
            _3886 = NewDouble((double)_3886);
        }
    }
    else
    _3886 = binary_op(PLUS, 1, _3885);
    DeRef(_3885);
    _3885 = NOVALUE;
    if (IS_SEQUENCE(_argtext_6714)){
            _3887 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3887 = 1;
    }
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, _3886, _3887);
    goto L74; // [3082] 3319
L73: 

    /**     					elsif align = 'c' then*/
    if (_align_6530 != 99)
    goto L75; // [3087] 3171

    /**     						pos = length(argtext) - width*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3890 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3890 = 1;
    }
    _pos_6539 = _3890 - _width_6537;
    _3890 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _3892 = (_pos_6539 % 2);
    if (_3892 != 0)
    goto L76; // [3106] 3139

    /**     							pos = pos / 2*/
    if (_pos_6539 & 1) {
        _pos_6539 = NewDouble((_pos_6539 >> 1) + 0.5);
    }
    else
    _pos_6539 = _pos_6539 >> 1;
    if (!IS_ATOM_INT(_pos_6539)) {
        _1 = (long)(DBL_PTR(_pos_6539)->dbl);
        DeRefDS(_pos_6539);
        _pos_6539 = _1;
    }

    /**     							argtext = argtext[ pos + 1 .. $ - pos ]*/
    _3895 = _pos_6539 + 1;
    if (_3895 > MAXINT){
        _3895 = NewDouble((double)_3895);
    }
    if (IS_SEQUENCE(_argtext_6714)){
            _3896 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3896 = 1;
    }
    _3897 = _3896 - _pos_6539;
    _3896 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, _3895, _3897);
    goto L74; // [3136] 3319
L76: 

    /**     							pos = floor(pos / 2)*/
    _pos_6539 = _pos_6539 >> 1;

    /**     							argtext = argtext[ pos + 1 .. $ - pos - 1]*/
    _3900 = _pos_6539 + 1;
    if (_3900 > MAXINT){
        _3900 = NewDouble((double)_3900);
    }
    if (IS_SEQUENCE(_argtext_6714)){
            _3901 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3901 = 1;
    }
    _3902 = _3901 - _pos_6539;
    if ((long)((unsigned long)_3902 +(unsigned long) HIGH_BITS) >= 0){
        _3902 = NewDouble((double)_3902);
    }
    _3901 = NOVALUE;
    if (IS_ATOM_INT(_3902)) {
        _3903 = _3902 - 1;
    }
    else {
        _3903 = NewDouble(DBL_PTR(_3902)->dbl - (double)1);
    }
    DeRef(_3902);
    _3902 = NOVALUE;
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, _3900, _3903);
    goto L74; // [3168] 3319
L75: 

    /**     						argtext = argtext[ 1 .. width]*/
    rhs_slice_target = (object_ptr)&_argtext_6714;
    RHS_Slice(_argtext_6714, 1, _width_6537);
    goto L74; // [3179] 3319
L72: 

    /**     				elsif width > length(argtext) then*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3906 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3906 = 1;
    }
    if (_width_6537 <= _3906)
    goto L77; // [3187] 3318

    /** 						if align = '>' then*/
    if (_align_6530 != 62)
    goto L78; // [3193] 3217

    /** 							argtext = repeat(' ', width - length(argtext)) & argtext*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3909 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3909 = 1;
    }
    _3910 = _width_6537 - _3909;
    _3909 = NOVALUE;
    _3911 = Repeat(32, _3910);
    _3910 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _3911, _argtext_6714);
    DeRefDS(_3911);
    _3911 = NOVALUE;
    DeRef(_3911);
    _3911 = NOVALUE;
    goto L79; // [3214] 3317
L78: 

    /**     					elsif align = 'c' then*/
    if (_align_6530 != 99)
    goto L7A; // [3219] 3299

    /**     						pos = width - length(argtext)*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3914 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3914 = 1;
    }
    _pos_6539 = _width_6537 - _3914;
    _3914 = NOVALUE;

    /**     						if remainder(pos, 2) = 0 then*/
    _3916 = (_pos_6539 % 2);
    if (_3916 != 0)
    goto L7B; // [3238] 3269

    /**     							pos = pos / 2*/
    if (_pos_6539 & 1) {
        _pos_6539 = NewDouble((_pos_6539 >> 1) + 0.5);
    }
    else
    _pos_6539 = _pos_6539 >> 1;
    if (!IS_ATOM_INT(_pos_6539)) {
        _1 = (long)(DBL_PTR(_pos_6539)->dbl);
        DeRefDS(_pos_6539);
        _pos_6539 = _1;
    }

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos)*/
    _3919 = Repeat(32, _pos_6539);
    _3920 = Repeat(32, _pos_6539);
    {
        int concat_list[3];

        concat_list[0] = _3920;
        concat_list[1] = _argtext_6714;
        concat_list[2] = _3919;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3920);
    _3920 = NOVALUE;
    DeRefDS(_3919);
    _3919 = NOVALUE;
    goto L79; // [3266] 3317
L7B: 

    /**     							pos = floor(pos / 2)*/
    _pos_6539 = _pos_6539 >> 1;

    /**     							argtext = repeat(' ', pos) & argtext & repeat(' ', pos + 1)*/
    _3923 = Repeat(32, _pos_6539);
    _3924 = _pos_6539 + 1;
    _3925 = Repeat(32, _3924);
    _3924 = NOVALUE;
    {
        int concat_list[3];

        concat_list[0] = _3925;
        concat_list[1] = _argtext_6714;
        concat_list[2] = _3923;
        Concat_N((object_ptr)&_argtext_6714, concat_list, 3);
    }
    DeRefDS(_3925);
    _3925 = NOVALUE;
    DeRefDS(_3923);
    _3923 = NOVALUE;
    goto L79; // [3296] 3317
L7A: 

    /** 							argtext = argtext & repeat(' ', width - length(argtext))*/
    if (IS_SEQUENCE(_argtext_6714)){
            _3927 = SEQ_PTR(_argtext_6714)->length;
    }
    else {
        _3927 = 1;
    }
    _3928 = _width_6537 - _3927;
    _3927 = NOVALUE;
    _3929 = Repeat(32, _3928);
    _3928 = NOVALUE;
    Concat((object_ptr)&_argtext_6714, _argtext_6714, _3929);
    DeRefDS(_3929);
    _3929 = NOVALUE;
L79: 
L77: 
L74: 

    /**     				result &= argtext*/
    Concat((object_ptr)&_result_6524, _result_6524, _argtext_6714);
    goto L7C; // [3325] 3341
L57: 

    /**     				if spacer then*/
    if (_spacer_6535 == 0)
    {
        goto L7D; // [3330] 3340
    }
    else{
    }

    /**     					result &= ' '*/
    Append(&_result_6524, _result_6524, 32);
L7D: 
L7C: 

    /**    				if trimming then*/
    if (_trimming_6542 == 0)
    {
        goto L7E; // [3345] 3359
    }
    else{
    }

    /**    					result = trim(result)*/
    RefDS(_result_6524);
    RefDS(_2965);
    _0 = _result_6524;
    _result_6524 = _18trim(_result_6524, _2965, 0);
    DeRefDS(_0);
L7E: 

    /**     			tend = 0*/
    _tend_6528 = 0;

    /** 		    	prevargv = currargv*/
    Ref(_currargv_6548);
    DeRef(_prevargv_6547);
    _prevargv_6547 = _currargv_6548;
L1F: 
    DeRef(_argtext_6714);
    _argtext_6714 = NOVALUE;

    /**     end while*/
    goto L2; // [3377] 60
L3: 

    /** 	return result*/
    DeRefDS(_format_pattern_6522);
    DeRef(_arg_list_6523);
    DeRef(_prevargv_6547);
    DeRef(_currargv_6548);
    DeRef(_idname_6549);
    DeRef(_envsym_6550);
    DeRefi(_envvar_6551);
    DeRef(_3856);
    _3856 = NOVALUE;
    DeRef(_3900);
    _3900 = NOVALUE;
    DeRef(_3593);
    _3593 = NOVALUE;
    DeRef(_3798);
    _3798 = NOVALUE;
    DeRef(_3863);
    _3863 = NOVALUE;
    DeRef(_3892);
    _3892 = NOVALUE;
    DeRef(_3660);
    _3660 = NOVALUE;
    DeRef(_3632);
    _3632 = NOVALUE;
    _3778 = NOVALUE;
    DeRef(_3895);
    _3895 = NOVALUE;
    DeRef(_3897);
    _3897 = NOVALUE;
    DeRef(_3873);
    _3873 = NOVALUE;
    DeRef(_3569);
    _3569 = NOVALUE;
    DeRef(_3620);
    _3620 = NOVALUE;
    DeRef(_3703);
    _3703 = NOVALUE;
    DeRef(_3721);
    _3721 = NOVALUE;
    DeRef(_3916);
    _3916 = NOVALUE;
    DeRef(_3886);
    _3886 = NOVALUE;
    DeRef(_3739);
    _3739 = NOVALUE;
    DeRef(_3837);
    _3837 = NOVALUE;
    DeRef(_3903);
    _3903 = NOVALUE;
    DeRef(_3642);
    _3642 = NOVALUE;
    DeRef(_3808);
    _3808 = NOVALUE;
    DeRef(_3776);
    _3776 = NOVALUE;
    DeRef(_3844);
    _3844 = NOVALUE;
    return _result_6524;
    ;
}



// 0xAE47F53A
