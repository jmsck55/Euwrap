// Euphoria To C version 4.0.5  (62d94559f849, 2012-10-15)
#include "include/euphoria.h"
#include "main-.h"

int _61reverse(int _s_22080)
{
    int _lower_22081 = NOVALUE;
    int _n_22082 = NOVALUE;
    int _n2_22083 = NOVALUE;
    int _t_22084 = NOVALUE;
    int _12847 = NOVALUE;
    int _12846 = NOVALUE;
    int _12845 = NOVALUE;
    int _12842 = NOVALUE;
    int _0, _1, _2;
    

    /** 	n = length(s)*/
    if (IS_SEQUENCE(_s_22080)){
            _n_22082 = SEQ_PTR(_s_22080)->length;
    }
    else {
        _n_22082 = 1;
    }

    /** 	n2 = floor(n/2)+1*/
    _12842 = _n_22082 >> 1;
    _n2_22083 = _12842 + 1;
    _12842 = NOVALUE;

    /** 	t = repeat(0, n)*/
    DeRef(_t_22084);
    _t_22084 = Repeat(0, _n_22082);

    /** 	lower = 1*/
    _lower_22081 = 1;

    /** 	for upper = n to n2 by -1 do*/
    _12845 = _n2_22083;
    {
        int _upper_22090;
        _upper_22090 = _n_22082;
L1: 
        if (_upper_22090 < _12845){
            goto L2; // [34] 74
        }

        /** 		t[upper] = s[lower]*/
        _2 = (int)SEQ_PTR(_s_22080);
        _12846 = (int)*(((s1_ptr)_2)->base + _lower_22081);
        Ref(_12846);
        _2 = (int)SEQ_PTR(_t_22084);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22084 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _upper_22090);
        _1 = *(int *)_2;
        *(int *)_2 = _12846;
        if( _1 != _12846 ){
            DeRef(_1);
        }
        _12846 = NOVALUE;

        /** 		t[lower] = s[upper]*/
        _2 = (int)SEQ_PTR(_s_22080);
        _12847 = (int)*(((s1_ptr)_2)->base + _upper_22090);
        Ref(_12847);
        _2 = (int)SEQ_PTR(_t_22084);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _t_22084 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _lower_22081);
        _1 = *(int *)_2;
        *(int *)_2 = _12847;
        if( _1 != _12847 ){
            DeRef(_1);
        }
        _12847 = NOVALUE;

        /** 		lower += 1*/
        _lower_22081 = _lower_22081 + 1;

        /** 	end for*/
        _upper_22090 = _upper_22090 + -1;
        goto L1; // [69] 41
L2: 
        ;
    }

    /** 	return t*/
    DeRefDS(_s_22080);
    return _t_22084;
    ;
}


int _61carry(int _a_22097, int _radix_22098)
{
    int _q_22099 = NOVALUE;
    int _r_22100 = NOVALUE;
    int _b_22101 = NOVALUE;
    int _rmax_22102 = NOVALUE;
    int _i_22103 = NOVALUE;
    int _12861 = NOVALUE;
    int _12860 = NOVALUE;
    int _12859 = NOVALUE;
    int _12856 = NOVALUE;
    int _12850 = NOVALUE;
    int _0, _1, _2;
    

    /** 		rmax = radix - 1*/
    DeRef(_rmax_22102);
    _rmax_22102 = _radix_22098 - 1;
    if ((long)((unsigned long)_rmax_22102 +(unsigned long) HIGH_BITS) >= 0){
        _rmax_22102 = NewDouble((double)_rmax_22102);
    }

    /** 		i = 1*/
    DeRef(_i_22103);
    _i_22103 = 1;

    /** 		while i <= length(a) do*/
L1: 
    if (IS_SEQUENCE(_a_22097)){
            _12850 = SEQ_PTR(_a_22097)->length;
    }
    else {
        _12850 = 1;
    }
    if (binary_op_a(GREATER, _i_22103, _12850)){
        _12850 = NOVALUE;
        goto L2; // [24] 104
    }
    _12850 = NOVALUE;

    /** 				b = a[i]*/
    DeRef(_b_22101);
    _2 = (int)SEQ_PTR(_a_22097);
    if (!IS_ATOM_INT(_i_22103)){
        _b_22101 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22103)->dbl));
    }
    else{
        _b_22101 = (int)*(((s1_ptr)_2)->base + _i_22103);
    }
    Ref(_b_22101);

    /** 				if b > rmax then*/
    if (binary_op_a(LESSEQ, _b_22101, _rmax_22102)){
        goto L3; // [36] 93
    }

    /** 						q = floor( b / radix )*/
    DeRef(_q_22099);
    if (IS_ATOM_INT(_b_22101)) {
        if (_radix_22098 > 0 && _b_22101 >= 0) {
            _q_22099 = _b_22101 / _radix_22098;
        }
        else {
            temp_dbl = floor((double)_b_22101 / (double)_radix_22098);
            if (_b_22101 != MININT)
            _q_22099 = (long)temp_dbl;
            else
            _q_22099 = NewDouble(temp_dbl);
        }
    }
    else {
        _2 = binary_op(DIVIDE, _b_22101, _radix_22098);
        _q_22099 = unary_op(FLOOR, _2);
        DeRef(_2);
    }

    /** 						r = remainder( b, radix )*/
    DeRef(_r_22100);
    if (IS_ATOM_INT(_b_22101)) {
        _r_22100 = (_b_22101 % _radix_22098);
    }
    else {
        temp_d.dbl = (double)_radix_22098;
        _r_22100 = Dremainder(DBL_PTR(_b_22101), &temp_d);
    }

    /** 						a[i] = r*/
    Ref(_r_22100);
    _2 = (int)SEQ_PTR(_a_22097);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22097 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_i_22103))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_i_22103)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _i_22103);
    _1 = *(int *)_2;
    *(int *)_2 = _r_22100;
    DeRef(_1);

    /** 						if i = length(a) then*/
    if (IS_SEQUENCE(_a_22097)){
            _12856 = SEQ_PTR(_a_22097)->length;
    }
    else {
        _12856 = 1;
    }
    if (binary_op_a(NOTEQ, _i_22103, _12856)){
        _12856 = NOVALUE;
        goto L4; // [63] 74
    }
    _12856 = NOVALUE;

    /** 								a &= 0*/
    Append(&_a_22097, _a_22097, 0);
L4: 

    /** 						a[i+1] += q*/
    if (IS_ATOM_INT(_i_22103)) {
        _12859 = _i_22103 + 1;
    }
    else
    _12859 = binary_op(PLUS, 1, _i_22103);
    _2 = (int)SEQ_PTR(_a_22097);
    if (!IS_ATOM_INT(_12859)){
        _12860 = (int)*(((s1_ptr)_2)->base + (int)(DBL_PTR(_12859)->dbl));
    }
    else{
        _12860 = (int)*(((s1_ptr)_2)->base + _12859);
    }
    if (IS_ATOM_INT(_12860) && IS_ATOM_INT(_q_22099)) {
        _12861 = _12860 + _q_22099;
        if ((long)((unsigned long)_12861 + (unsigned long)HIGH_BITS) >= 0) 
        _12861 = NewDouble((double)_12861);
    }
    else {
        _12861 = binary_op(PLUS, _12860, _q_22099);
    }
    _12860 = NOVALUE;
    _2 = (int)SEQ_PTR(_a_22097);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _a_22097 = MAKE_SEQ(_2);
    }
    if (!IS_ATOM_INT(_12859))
    _2 = (int)(((s1_ptr)_2)->base + (int)(DBL_PTR(_12859)->dbl));
    else
    _2 = (int)(((s1_ptr)_2)->base + _12859);
    _1 = *(int *)_2;
    *(int *)_2 = _12861;
    if( _1 != _12861 ){
        DeRef(_1);
    }
    _12861 = NOVALUE;
L3: 

    /** 				i += 1*/
    _0 = _i_22103;
    if (IS_ATOM_INT(_i_22103)) {
        _i_22103 = _i_22103 + 1;
        if (_i_22103 > MAXINT){
            _i_22103 = NewDouble((double)_i_22103);
        }
    }
    else
    _i_22103 = binary_op(PLUS, 1, _i_22103);
    DeRef(_0);

    /** 		end while*/
    goto L1; // [101] 21
L2: 

    /** 		return a*/
    DeRef(_q_22099);
    DeRef(_r_22100);
    DeRef(_b_22101);
    DeRef(_rmax_22102);
    DeRef(_i_22103);
    DeRef(_12859);
    _12859 = NOVALUE;
    return _a_22097;
    ;
}


int _61add(int _a_22123, int _b_22124)
{
    int _12879 = NOVALUE;
    int _12877 = NOVALUE;
    int _12876 = NOVALUE;
    int _12875 = NOVALUE;
    int _12874 = NOVALUE;
    int _12872 = NOVALUE;
    int _12871 = NOVALUE;
    int _12869 = NOVALUE;
    int _12868 = NOVALUE;
    int _12867 = NOVALUE;
    int _12866 = NOVALUE;
    int _12864 = NOVALUE;
    int _12863 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if length(a) < length(b) then*/
    if (IS_SEQUENCE(_a_22123)){
            _12863 = SEQ_PTR(_a_22123)->length;
    }
    else {
        _12863 = 1;
    }
    if (IS_SEQUENCE(_b_22124)){
            _12864 = SEQ_PTR(_b_22124)->length;
    }
    else {
        _12864 = 1;
    }
    if (_12863 >= _12864)
    goto L1; // [13] 40

    /** 				a &= repeat( 0, length(b) - length(a) )*/
    if (IS_SEQUENCE(_b_22124)){
            _12866 = SEQ_PTR(_b_22124)->length;
    }
    else {
        _12866 = 1;
    }
    if (IS_SEQUENCE(_a_22123)){
            _12867 = SEQ_PTR(_a_22123)->length;
    }
    else {
        _12867 = 1;
    }
    _12868 = _12866 - _12867;
    _12866 = NOVALUE;
    _12867 = NOVALUE;
    _12869 = Repeat(0, _12868);
    _12868 = NOVALUE;
    Concat((object_ptr)&_a_22123, _a_22123, _12869);
    DeRefDS(_12869);
    _12869 = NOVALUE;
    goto L2; // [37] 74
L1: 

    /** 		elsif length(b) < length(a) then*/
    if (IS_SEQUENCE(_b_22124)){
            _12871 = SEQ_PTR(_b_22124)->length;
    }
    else {
        _12871 = 1;
    }
    if (IS_SEQUENCE(_a_22123)){
            _12872 = SEQ_PTR(_a_22123)->length;
    }
    else {
        _12872 = 1;
    }
    if (_12871 >= _12872)
    goto L3; // [48] 73

    /** 				b &= repeat( 0, length(a) - length(b) )*/
    if (IS_SEQUENCE(_a_22123)){
            _12874 = SEQ_PTR(_a_22123)->length;
    }
    else {
        _12874 = 1;
    }
    if (IS_SEQUENCE(_b_22124)){
            _12875 = SEQ_PTR(_b_22124)->length;
    }
    else {
        _12875 = 1;
    }
    _12876 = _12874 - _12875;
    _12874 = NOVALUE;
    _12875 = NOVALUE;
    _12877 = Repeat(0, _12876);
    _12876 = NOVALUE;
    Concat((object_ptr)&_b_22124, _b_22124, _12877);
    DeRefDS(_12877);
    _12877 = NOVALUE;
L3: 
L2: 

    /** 		return a + b*/
    _12879 = binary_op(PLUS, _a_22123, _b_22124);
    DeRefDS(_a_22123);
    DeRefDS(_b_22124);
    return _12879;
    ;
}


int _61borrow(int _a_22146, int _radix_22147)
{
    int _12887 = NOVALUE;
    int _12886 = NOVALUE;
    int _12885 = NOVALUE;
    int _12884 = NOVALUE;
    int _12883 = NOVALUE;
    int _12881 = NOVALUE;
    int _12880 = NOVALUE;
    int _0, _1, _2;
    

    /** 		for i = length(a) to 2 by -1 do*/
    if (IS_SEQUENCE(_a_22146)){
            _12880 = SEQ_PTR(_a_22146)->length;
    }
    else {
        _12880 = 1;
    }
    {
        int _i_22149;
        _i_22149 = _12880;
L1: 
        if (_i_22149 < 2){
            goto L2; // [10] 67
        }

        /** 				if a[i] < 0 then*/
        _2 = (int)SEQ_PTR(_a_22146);
        _12881 = (int)*(((s1_ptr)_2)->base + _i_22149);
        if (binary_op_a(GREATEREQ, _12881, 0)){
            _12881 = NOVALUE;
            goto L3; // [23] 60
        }
        _12881 = NOVALUE;

        /** 						a[i] += radix*/
        _2 = (int)SEQ_PTR(_a_22146);
        _12883 = (int)*(((s1_ptr)_2)->base + _i_22149);
        if (IS_ATOM_INT(_12883)) {
            _12884 = _12883 + _radix_22147;
            if ((long)((unsigned long)_12884 + (unsigned long)HIGH_BITS) >= 0) 
            _12884 = NewDouble((double)_12884);
        }
        else {
            _12884 = binary_op(PLUS, _12883, _radix_22147);
        }
        _12883 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22146);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22146 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22149);
        _1 = *(int *)_2;
        *(int *)_2 = _12884;
        if( _1 != _12884 ){
            DeRef(_1);
        }
        _12884 = NOVALUE;

        /** 						a[i-1] -= 1*/
        _12885 = _i_22149 - 1;
        _2 = (int)SEQ_PTR(_a_22146);
        _12886 = (int)*(((s1_ptr)_2)->base + _12885);
        if (IS_ATOM_INT(_12886)) {
            _12887 = _12886 - 1;
            if ((long)((unsigned long)_12887 +(unsigned long) HIGH_BITS) >= 0){
                _12887 = NewDouble((double)_12887);
            }
        }
        else {
            _12887 = binary_op(MINUS, _12886, 1);
        }
        _12886 = NOVALUE;
        _2 = (int)SEQ_PTR(_a_22146);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _a_22146 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _12885);
        _1 = *(int *)_2;
        *(int *)_2 = _12887;
        if( _1 != _12887 ){
            DeRef(_1);
        }
        _12887 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22149 = _i_22149 + -1;
        goto L1; // [62] 17
L2: 
        ;
    }

    /** 		return a*/
    DeRef(_12885);
    _12885 = NOVALUE;
    return _a_22146;
    ;
}


int _61bits_to_bytes(int _bits_22161)
{
    int _bytes_22162 = NOVALUE;
    int _r_22163 = NOVALUE;
    int _12896 = NOVALUE;
    int _12895 = NOVALUE;
    int _12894 = NOVALUE;
    int _12893 = NOVALUE;
    int _12891 = NOVALUE;
    int _12890 = NOVALUE;
    int _12888 = NOVALUE;
    int _0, _1, _2;
    

    /** 		r = remainder( length(bits), 8 )*/
    if (IS_SEQUENCE(_bits_22161)){
            _12888 = SEQ_PTR(_bits_22161)->length;
    }
    else {
        _12888 = 1;
    }
    _r_22163 = (_12888 % 8);
    _12888 = NOVALUE;

    /** 		if r  then*/
    if (_r_22163 == 0)
    {
        goto L1; // [14] 32
    }
    else{
    }

    /** 				bits &= repeat( 0, 8 - r )*/
    _12890 = 8 - _r_22163;
    _12891 = Repeat(0, _12890);
    _12890 = NOVALUE;
    Concat((object_ptr)&_bits_22161, _bits_22161, _12891);
    DeRefDS(_12891);
    _12891 = NOVALUE;
L1: 

    /** 		bytes = {}*/
    RefDS(_5);
    DeRef(_bytes_22162);
    _bytes_22162 = _5;

    /** 		for i = 1 to length(bits) by 8 do*/
    if (IS_SEQUENCE(_bits_22161)){
            _12893 = SEQ_PTR(_bits_22161)->length;
    }
    else {
        _12893 = 1;
    }
    {
        int _i_22171;
        _i_22171 = 1;
L2: 
        if (_i_22171 > _12893){
            goto L3; // [44] 77
        }

        /** 				bytes &= bits_to_int( bits[i..i+7] )*/
        _12894 = _i_22171 + 7;
        rhs_slice_target = (object_ptr)&_12895;
        RHS_Slice(_bits_22161, _i_22171, _12894);
        _12896 = _19bits_to_int(_12895);
        _12895 = NOVALUE;
        if (IS_SEQUENCE(_bytes_22162) && IS_ATOM(_12896)) {
            Ref(_12896);
            Append(&_bytes_22162, _bytes_22162, _12896);
        }
        else if (IS_ATOM(_bytes_22162) && IS_SEQUENCE(_12896)) {
        }
        else {
            Concat((object_ptr)&_bytes_22162, _bytes_22162, _12896);
        }
        DeRef(_12896);
        _12896 = NOVALUE;

        /** 		end for*/
        _i_22171 = _i_22171 + 8;
        goto L2; // [72] 51
L3: 
        ;
    }

    /** 		return bytes*/
    DeRefDS(_bits_22161);
    DeRef(_12894);
    _12894 = NOVALUE;
    return _bytes_22162;
    ;
}


int _61bytes_to_bits(int _bytes_22180)
{
    int _bits_22181 = NOVALUE;
    int _12900 = NOVALUE;
    int _12899 = NOVALUE;
    int _12898 = NOVALUE;
    int _0, _1, _2;
    

    /** 		bits = {}*/
    RefDS(_5);
    DeRef(_bits_22181);
    _bits_22181 = _5;

    /** 		for i = 1 to length(bytes) do*/
    if (IS_SEQUENCE(_bytes_22180)){
            _12898 = SEQ_PTR(_bytes_22180)->length;
    }
    else {
        _12898 = 1;
    }
    {
        int _i_22183;
        _i_22183 = 1;
L1: 
        if (_i_22183 > _12898){
            goto L2; // [15] 44
        }

        /** 				bits &= int_to_bits( bytes[i], 8 )*/
        _2 = (int)SEQ_PTR(_bytes_22180);
        _12899 = (int)*(((s1_ptr)_2)->base + _i_22183);
        Ref(_12899);
        _12900 = _19int_to_bits(_12899, 8);
        _12899 = NOVALUE;
        if (IS_SEQUENCE(_bits_22181) && IS_ATOM(_12900)) {
            Ref(_12900);
            Append(&_bits_22181, _bits_22181, _12900);
        }
        else if (IS_ATOM(_bits_22181) && IS_SEQUENCE(_12900)) {
        }
        else {
            Concat((object_ptr)&_bits_22181, _bits_22181, _12900);
        }
        DeRef(_12900);
        _12900 = NOVALUE;

        /** 		end for*/
        _i_22183 = _i_22183 + 1;
        goto L1; // [39] 22
L2: 
        ;
    }

    /** 		return bits*/
    DeRefDS(_bytes_22180);
    return _bits_22181;
    ;
}


int _61convert_radix(int _number_22191, int _from_radix_22192, int _to_radix_22193)
{
    int _target_22194 = NOVALUE;
    int _base_22195 = NOVALUE;
    int _12907 = NOVALUE;
    int _12906 = NOVALUE;
    int _12905 = NOVALUE;
    int _12904 = NOVALUE;
    int _0, _1, _2;
    

    /** 		base = {1}*/
    RefDS(_12902);
    DeRef(_base_22195);
    _base_22195 = _12902;

    /** 		target = {0}*/
    _0 = _target_22194;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _target_22194 = MAKE_SEQ(_1);
    DeRef(_0);

    /** 		for i = 1 to length(number) do*/
    if (IS_SEQUENCE(_number_22191)){
            _12904 = SEQ_PTR(_number_22191)->length;
    }
    else {
        _12904 = 1;
    }
    {
        int _i_22199;
        _i_22199 = 1;
L1: 
        if (_i_22199 > _12904){
            goto L2; // [25] 78
        }

        /** 				target = carry( add( base * number[i], target ), to_radix )*/
        _2 = (int)SEQ_PTR(_number_22191);
        _12905 = (int)*(((s1_ptr)_2)->base + _i_22199);
        _12906 = binary_op(MULTIPLY, _base_22195, _12905);
        _12905 = NOVALUE;
        RefDS(_target_22194);
        _12907 = _61add(_12906, _target_22194);
        _12906 = NOVALUE;
        _0 = _target_22194;
        _target_22194 = _61carry(_12907, _to_radix_22193);
        DeRefDS(_0);
        _12907 = NOVALUE;

        /** 				base *= from_radix*/
        _0 = _base_22195;
        _base_22195 = binary_op(MULTIPLY, _base_22195, _from_radix_22192);
        DeRefDS(_0);

        /** 				base = carry( base, to_radix )*/
        RefDS(_base_22195);
        _0 = _base_22195;
        _base_22195 = _61carry(_base_22195, _to_radix_22193);
        DeRefDS(_0);

        /** 		end for*/
        _i_22199 = _i_22199 + 1;
        goto L1; // [73] 32
L2: 
        ;
    }

    /** 		return target*/
    DeRefDS(_number_22191);
    DeRef(_base_22195);
    return _target_22194;
    ;
}


int _61half(int _decimal_22209)
{
    int _quotient_22210 = NOVALUE;
    int _q_22211 = NOVALUE;
    int _Q_22212 = NOVALUE;
    int _12928 = NOVALUE;
    int _12927 = NOVALUE;
    int _12926 = NOVALUE;
    int _12925 = NOVALUE;
    int _12924 = NOVALUE;
    int _12923 = NOVALUE;
    int _12920 = NOVALUE;
    int _12918 = NOVALUE;
    int _12917 = NOVALUE;
    int _12914 = NOVALUE;
    int _12913 = NOVALUE;
    int _12911 = NOVALUE;
    int _0, _1, _2;
    

    /** 		quotient = repeat( 0, length(decimal) )*/
    if (IS_SEQUENCE(_decimal_22209)){
            _12911 = SEQ_PTR(_decimal_22209)->length;
    }
    else {
        _12911 = 1;
    }
    DeRef(_quotient_22210);
    _quotient_22210 = Repeat(0, _12911);
    _12911 = NOVALUE;

    /** 		for i = 1 to length( decimal ) do*/
    if (IS_SEQUENCE(_decimal_22209)){
            _12913 = SEQ_PTR(_decimal_22209)->length;
    }
    else {
        _12913 = 1;
    }
    {
        int _i_22216;
        _i_22216 = 1;
L1: 
        if (_i_22216 > _12913){
            goto L2; // [17] 101
        }

        /** 				q = decimal[i] / 2*/
        _2 = (int)SEQ_PTR(_decimal_22209);
        _12914 = (int)*(((s1_ptr)_2)->base + _i_22216);
        DeRef(_q_22211);
        if (IS_ATOM_INT(_12914)) {
            if (_12914 & 1) {
                _q_22211 = NewDouble((_12914 >> 1) + 0.5);
            }
            else
            _q_22211 = _12914 >> 1;
        }
        else {
            _q_22211 = binary_op(DIVIDE, _12914, 2);
        }
        _12914 = NOVALUE;

        /** 				Q = floor( q )*/
        DeRef(_Q_22212);
        if (IS_ATOM_INT(_q_22211))
        _Q_22212 = e_floor(_q_22211);
        else
        _Q_22212 = unary_op(FLOOR, _q_22211);

        /** 				quotient[i] +=  Q*/
        _2 = (int)SEQ_PTR(_quotient_22210);
        _12917 = (int)*(((s1_ptr)_2)->base + _i_22216);
        if (IS_ATOM_INT(_12917) && IS_ATOM_INT(_Q_22212)) {
            _12918 = _12917 + _Q_22212;
            if ((long)((unsigned long)_12918 + (unsigned long)HIGH_BITS) >= 0) 
            _12918 = NewDouble((double)_12918);
        }
        else {
            _12918 = binary_op(PLUS, _12917, _Q_22212);
        }
        _12917 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22210);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22210 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _i_22216);
        _1 = *(int *)_2;
        *(int *)_2 = _12918;
        if( _1 != _12918 ){
            DeRef(_1);
        }
        _12918 = NOVALUE;

        /** 				if q != Q then*/
        if (binary_op_a(EQUALS, _q_22211, _Q_22212)){
            goto L3; // [55] 94
        }

        /** 						if length(quotient) = i then*/
        if (IS_SEQUENCE(_quotient_22210)){
                _12920 = SEQ_PTR(_quotient_22210)->length;
        }
        else {
            _12920 = 1;
        }
        if (_12920 != _i_22216)
        goto L4; // [64] 75

        /** 								quotient &= 0*/
        Append(&_quotient_22210, _quotient_22210, 0);
L4: 

        /** 						quotient[i+1] += 5*/
        _12923 = _i_22216 + 1;
        _2 = (int)SEQ_PTR(_quotient_22210);
        _12924 = (int)*(((s1_ptr)_2)->base + _12923);
        if (IS_ATOM_INT(_12924)) {
            _12925 = _12924 + 5;
            if ((long)((unsigned long)_12925 + (unsigned long)HIGH_BITS) >= 0) 
            _12925 = NewDouble((double)_12925);
        }
        else {
            _12925 = binary_op(PLUS, _12924, 5);
        }
        _12924 = NOVALUE;
        _2 = (int)SEQ_PTR(_quotient_22210);
        if (!UNIQUE(_2)) {
            _2 = (int)SequenceCopy((s1_ptr)_2);
            _quotient_22210 = MAKE_SEQ(_2);
        }
        _2 = (int)(((s1_ptr)_2)->base + _12923);
        _1 = *(int *)_2;
        *(int *)_2 = _12925;
        if( _1 != _12925 ){
            DeRef(_1);
        }
        _12925 = NOVALUE;
L3: 

        /** 		end for*/
        _i_22216 = _i_22216 + 1;
        goto L1; // [96] 24
L2: 
        ;
    }

    /** 		return reverse( carry( reverse( quotient ), 10 ) )*/
    RefDS(_quotient_22210);
    _12926 = _61reverse(_quotient_22210);
    _12927 = _61carry(_12926, 10);
    _12926 = NOVALUE;
    _12928 = _61reverse(_12927);
    _12927 = NOVALUE;
    DeRefDS(_decimal_22209);
    DeRefDS(_quotient_22210);
    DeRef(_q_22211);
    DeRef(_Q_22212);
    DeRef(_12923);
    _12923 = NOVALUE;
    return _12928;
    ;
}


int _61decimals_to_bits(int _decimals_22245)
{
    int _sub_22246 = NOVALUE;
    int _bits_22247 = NOVALUE;
    int _bit_22248 = NOVALUE;
    int _assigned_22249 = NOVALUE;
    int _12955 = NOVALUE;
    int _12951 = NOVALUE;
    int _12950 = NOVALUE;
    int _12949 = NOVALUE;
    int _12948 = NOVALUE;
    int _12946 = NOVALUE;
    int _12945 = NOVALUE;
    int _12944 = NOVALUE;
    int _12942 = NOVALUE;
    int _12940 = NOVALUE;
    int _12939 = NOVALUE;
    int _12938 = NOVALUE;
    int _12937 = NOVALUE;
    int _12935 = NOVALUE;
    int _12933 = NOVALUE;
    int _0, _1, _2;
    

    /** 		sub = {5}*/
    RefDS(_12931);
    DeRef(_sub_22246);
    _sub_22246 = _12931;

    /** 		bits = repeat( 0, 53 )*/
    DeRef(_bits_22247);
    _bits_22247 = Repeat(0, 53);

    /** 		bit = 1*/
    _bit_22248 = 1;

    /** 		assigned = 0*/
    _assigned_22249 = 0;

    /** 		if compare(decimals, bits) > 0 then */
    if (IS_ATOM_INT(_decimals_22245) && IS_ATOM_INT(_bits_22247)){
        _12933 = (_decimals_22245 < _bits_22247) ? -1 : (_decimals_22245 > _bits_22247);
    }
    else{
        _12933 = compare(_decimals_22245, _bits_22247);
    }
    if (_12933 <= 0)
    goto L1; // [32] 160

    /** 			while (not assigned) or (bit < find( 1, bits ) + 54)  do*/
L2: 
    _12935 = (_assigned_22249 == 0);
    if (_12935 != 0) {
        goto L3; // [44] 66
    }
    _12937 = find_from(1, _bits_22247, 1);
    _12938 = _12937 + 54;
    _12937 = NOVALUE;
    _12939 = (_bit_22248 < _12938);
    _12938 = NOVALUE;
    if (_12939 == 0)
    {
        DeRef(_12939);
        _12939 = NOVALUE;
        goto L4; // [62] 159
    }
    else{
        DeRef(_12939);
        _12939 = NOVALUE;
    }
L3: 

    /** 				if compare( sub, decimals ) <= 0 then*/
    if (IS_ATOM_INT(_sub_22246) && IS_ATOM_INT(_decimals_22245)){
        _12940 = (_sub_22246 < _decimals_22245) ? -1 : (_sub_22246 > _decimals_22245);
    }
    else{
        _12940 = compare(_sub_22246, _decimals_22245);
    }
    if (_12940 > 0)
    goto L5; // [72] 140

    /** 						assigned = 1*/
    _assigned_22249 = 1;

    /** 						if length( bits ) < bit then*/
    if (IS_SEQUENCE(_bits_22247)){
            _12942 = SEQ_PTR(_bits_22247)->length;
    }
    else {
        _12942 = 1;
    }
    if (_12942 >= _bit_22248)
    goto L6; // [86] 108

    /** 								bits &= repeat( 0, bit - length(bits)) */
    if (IS_SEQUENCE(_bits_22247)){
            _12944 = SEQ_PTR(_bits_22247)->length;
    }
    else {
        _12944 = 1;
    }
    _12945 = _bit_22248 - _12944;
    _12944 = NOVALUE;
    _12946 = Repeat(0, _12945);
    _12945 = NOVALUE;
    Concat((object_ptr)&_bits_22247, _bits_22247, _12946);
    DeRefDS(_12946);
    _12946 = NOVALUE;
L6: 

    /** 						bits[bit] += 1*/
    _2 = (int)SEQ_PTR(_bits_22247);
    _12948 = (int)*(((s1_ptr)_2)->base + _bit_22248);
    if (IS_ATOM_INT(_12948)) {
        _12949 = _12948 + 1;
        if (_12949 > MAXINT){
            _12949 = NewDouble((double)_12949);
        }
    }
    else
    _12949 = binary_op(PLUS, 1, _12948);
    _12948 = NOVALUE;
    _2 = (int)SEQ_PTR(_bits_22247);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _bits_22247 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _bit_22248);
    _1 = *(int *)_2;
    *(int *)_2 = _12949;
    if( _1 != _12949 ){
        DeRef(_1);
    }
    _12949 = NOVALUE;

    /** 						decimals = borrow( add( decimals, -sub ), 10 )*/
    _12950 = unary_op(UMINUS, _sub_22246);
    RefDS(_decimals_22245);
    _12951 = _61add(_decimals_22245, _12950);
    _12950 = NOVALUE;
    _0 = _decimals_22245;
    _decimals_22245 = _61borrow(_12951, 10);
    DeRefDS(_0);
    _12951 = NOVALUE;
L5: 

    /** 				sub = half( sub )*/
    RefDS(_sub_22246);
    _0 = _sub_22246;
    _sub_22246 = _61half(_sub_22246);
    DeRefDS(_0);

    /** 				bit += 1*/
    _bit_22248 = _bit_22248 + 1;

    /** 			end while*/
    goto L2; // [156] 41
L4: 
L1: 

    /** 		return reverse(bits)*/
    RefDS(_bits_22247);
    _12955 = _61reverse(_bits_22247);
    DeRefDS(_decimals_22245);
    DeRef(_sub_22246);
    DeRefDS(_bits_22247);
    DeRef(_12935);
    _12935 = NOVALUE;
    return _12955;
    ;
}


int _61string_to_int(int _s_22281)
{
    int _int_22282 = NOVALUE;
    int _12959 = NOVALUE;
    int _12958 = NOVALUE;
    int _12956 = NOVALUE;
    int _0, _1, _2;
    

    /** 		int = 0*/
    _int_22282 = 0;

    /** 		for i = 1 to length(s) do*/
    if (IS_SEQUENCE(_s_22281)){
            _12956 = SEQ_PTR(_s_22281)->length;
    }
    else {
        _12956 = 1;
    }
    {
        int _i_22284;
        _i_22284 = 1;
L1: 
        if (_i_22284 > _12956){
            goto L2; // [13] 51
        }

        /** 				int *= 10*/
        _int_22282 = _int_22282 * 10;

        /** 				int += s[i] - '0'*/
        _2 = (int)SEQ_PTR(_s_22281);
        _12958 = (int)*(((s1_ptr)_2)->base + _i_22284);
        if (IS_ATOM_INT(_12958)) {
            _12959 = _12958 - 48;
            if ((long)((unsigned long)_12959 +(unsigned long) HIGH_BITS) >= 0){
                _12959 = NewDouble((double)_12959);
            }
        }
        else {
            _12959 = binary_op(MINUS, _12958, 48);
        }
        _12958 = NOVALUE;
        if (IS_ATOM_INT(_12959)) {
            _int_22282 = _int_22282 + _12959;
        }
        else {
            _int_22282 = binary_op(PLUS, _int_22282, _12959);
        }
        DeRef(_12959);
        _12959 = NOVALUE;
        if (!IS_ATOM_INT(_int_22282)) {
            _1 = (long)(DBL_PTR(_int_22282)->dbl);
            DeRefDS(_int_22282);
            _int_22282 = _1;
        }

        /** 		end for*/
        _i_22284 = _i_22284 + 1;
        goto L1; // [46] 20
L2: 
        ;
    }

    /** 		return int*/
    DeRefDS(_s_22281);
    return _int_22282;
    ;
}


int _61trim_bits(int _bits_22292)
{
    int _12967 = NOVALUE;
    int _12966 = NOVALUE;
    int _12965 = NOVALUE;
    int _12964 = NOVALUE;
    int _12963 = NOVALUE;
    int _12962 = NOVALUE;
    int _12961 = NOVALUE;
    int _0, _1, _2;
    

    /** 		while length(bits) and not bits[$] do*/
L1: 
    if (IS_SEQUENCE(_bits_22292)){
            _12961 = SEQ_PTR(_bits_22292)->length;
    }
    else {
        _12961 = 1;
    }
    if (_12961 == 0) {
        goto L2; // [11] 48
    }
    if (IS_SEQUENCE(_bits_22292)){
            _12963 = SEQ_PTR(_bits_22292)->length;
    }
    else {
        _12963 = 1;
    }
    _2 = (int)SEQ_PTR(_bits_22292);
    _12964 = (int)*(((s1_ptr)_2)->base + _12963);
    if (IS_ATOM_INT(_12964)) {
        _12965 = (_12964 == 0);
    }
    else {
        _12965 = unary_op(NOT, _12964);
    }
    _12964 = NOVALUE;
    if (_12965 <= 0) {
        if (_12965 == 0) {
            DeRef(_12965);
            _12965 = NOVALUE;
            goto L2; // [26] 48
        }
        else {
            if (!IS_ATOM_INT(_12965) && DBL_PTR(_12965)->dbl == 0.0){
                DeRef(_12965);
                _12965 = NOVALUE;
                goto L2; // [26] 48
            }
            DeRef(_12965);
            _12965 = NOVALUE;
        }
    }
    DeRef(_12965);
    _12965 = NOVALUE;

    /** 				bits = bits[1..$-1]*/
    if (IS_SEQUENCE(_bits_22292)){
            _12966 = SEQ_PTR(_bits_22292)->length;
    }
    else {
        _12966 = 1;
    }
    _12967 = _12966 - 1;
    _12966 = NOVALUE;
    rhs_slice_target = (object_ptr)&_bits_22292;
    RHS_Slice(_bits_22292, 1, _12967);

    /** 		end while*/
    goto L1; // [45] 8
L2: 

    /** 		return bits*/
    DeRef(_12967);
    _12967 = NOVALUE;
    return _bits_22292;
    ;
}


int _61scientific_to_float64(int _s_22304)
{
    int _dp_22305 = NOVALUE;
    int _e_22306 = NOVALUE;
    int _exp_22307 = NOVALUE;
    int _int_bits_22308 = NOVALUE;
    int _frac_bits_22309 = NOVALUE;
    int _mbits_22310 = NOVALUE;
    int _ebits_22311 = NOVALUE;
    int _sbits_22312 = NOVALUE;
    int _13111 = NOVALUE;
    int _13110 = NOVALUE;
    int _13108 = NOVALUE;
    int _13106 = NOVALUE;
    int _13105 = NOVALUE;
    int _13104 = NOVALUE;
    int _13102 = NOVALUE;
    int _13101 = NOVALUE;
    int _13100 = NOVALUE;
    int _13099 = NOVALUE;
    int _13098 = NOVALUE;
    int _13097 = NOVALUE;
    int _13096 = NOVALUE;
    int _13094 = NOVALUE;
    int _13093 = NOVALUE;
    int _13092 = NOVALUE;
    int _13091 = NOVALUE;
    int _13089 = NOVALUE;
    int _13088 = NOVALUE;
    int _13087 = NOVALUE;
    int _13086 = NOVALUE;
    int _13085 = NOVALUE;
    int _13084 = NOVALUE;
    int _13083 = NOVALUE;
    int _13080 = NOVALUE;
    int _13077 = NOVALUE;
    int _13076 = NOVALUE;
    int _13075 = NOVALUE;
    int _13070 = NOVALUE;
    int _13069 = NOVALUE;
    int _13067 = NOVALUE;
    int _13066 = NOVALUE;
    int _13064 = NOVALUE;
    int _13062 = NOVALUE;
    int _13061 = NOVALUE;
    int _13060 = NOVALUE;
    int _13059 = NOVALUE;
    int _13058 = NOVALUE;
    int _13057 = NOVALUE;
    int _13056 = NOVALUE;
    int _13055 = NOVALUE;
    int _13053 = NOVALUE;
    int _13052 = NOVALUE;
    int _13051 = NOVALUE;
    int _13050 = NOVALUE;
    int _13048 = NOVALUE;
    int _13046 = NOVALUE;
    int _13045 = NOVALUE;
    int _13044 = NOVALUE;
    int _13043 = NOVALUE;
    int _13042 = NOVALUE;
    int _13040 = NOVALUE;
    int _13039 = NOVALUE;
    int _13038 = NOVALUE;
    int _13037 = NOVALUE;
    int _13036 = NOVALUE;
    int _13035 = NOVALUE;
    int _13033 = NOVALUE;
    int _13032 = NOVALUE;
    int _13031 = NOVALUE;
    int _13030 = NOVALUE;
    int _13029 = NOVALUE;
    int _13027 = NOVALUE;
    int _13026 = NOVALUE;
    int _13024 = NOVALUE;
    int _13023 = NOVALUE;
    int _13022 = NOVALUE;
    int _13021 = NOVALUE;
    int _13020 = NOVALUE;
    int _13018 = NOVALUE;
    int _13016 = NOVALUE;
    int _13015 = NOVALUE;
    int _13013 = NOVALUE;
    int _13012 = NOVALUE;
    int _13010 = NOVALUE;
    int _13007 = NOVALUE;
    int _13006 = NOVALUE;
    int _13005 = NOVALUE;
    int _13004 = NOVALUE;
    int _13003 = NOVALUE;
    int _13001 = NOVALUE;
    int _13000 = NOVALUE;
    int _12999 = NOVALUE;
    int _12998 = NOVALUE;
    int _12996 = NOVALUE;
    int _12995 = NOVALUE;
    int _12994 = NOVALUE;
    int _12993 = NOVALUE;
    int _12991 = NOVALUE;
    int _12990 = NOVALUE;
    int _12988 = NOVALUE;
    int _12987 = NOVALUE;
    int _12986 = NOVALUE;
    int _12985 = NOVALUE;
    int _12983 = NOVALUE;
    int _12982 = NOVALUE;
    int _12976 = NOVALUE;
    int _12974 = NOVALUE;
    int _12971 = NOVALUE;
    int _12969 = NOVALUE;
    int _0, _1, _2;
    

    /** 		if s[1] = '-' then*/
    _2 = (int)SEQ_PTR(_s_22304);
    _12969 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12969, 45)){
        _12969 = NOVALUE;
        goto L1; // [9] 33
    }
    _12969 = NOVALUE;

    /** 				sbits = {1}*/
    RefDS(_12902);
    DeRefi(_sbits_22312);
    _sbits_22312 = _12902;

    /** 				s = s[2..$]*/
    if (IS_SEQUENCE(_s_22304)){
            _12971 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _12971 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22304;
    RHS_Slice(_s_22304, 2, _12971);
    goto L2; // [30] 61
L1: 

    /** 				sbits = {0}*/
    _0 = _sbits_22312;
    _1 = NewS1(1);
    _2 = (int)((s1_ptr)_1)->base;
    *((int *)(_2+4)) = 0;
    _sbits_22312 = MAKE_SEQ(_1);
    DeRefi(_0);

    /** 				if s[1] = '+' then*/
    _2 = (int)SEQ_PTR(_s_22304);
    _12974 = (int)*(((s1_ptr)_2)->base + 1);
    if (binary_op_a(NOTEQ, _12974, 43)){
        _12974 = NOVALUE;
        goto L3; // [45] 60
    }
    _12974 = NOVALUE;

    /** 						s = s[2..$]*/
    if (IS_SEQUENCE(_s_22304)){
            _12976 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _12976 = 1;
    }
    rhs_slice_target = (object_ptr)&_s_22304;
    RHS_Slice(_s_22304, 2, _12976);
L3: 
L2: 

    /** 		dp = find('.', s)*/
    _dp_22305 = find_from(46, _s_22304, 1);

    /** 		e = find( 'e', s )*/
    _e_22306 = find_from(101, _s_22304, 1);

    /** 		if not e then*/
    if (_e_22306 != 0)
    goto L4; // [77] 88

    /** 				e = find('E', s )*/
    _e_22306 = find_from(69, _s_22304, 1);
L4: 

    /** 		exp = 0*/
    _exp_22307 = 0;

    /** 		if s[e+1] = '-' then*/
    _12982 = _e_22306 + 1;
    _2 = (int)SEQ_PTR(_s_22304);
    _12983 = (int)*(((s1_ptr)_2)->base + _12982);
    if (binary_op_a(NOTEQ, _12983, 45)){
        _12983 = NOVALUE;
        goto L5; // [103] 134
    }
    _12983 = NOVALUE;

    /** 				exp -= string_to_int( s[e+2..$] )*/
    _12985 = _e_22306 + 2;
    if ((long)((unsigned long)_12985 + (unsigned long)HIGH_BITS) >= 0) 
    _12985 = NewDouble((double)_12985);
    if (IS_SEQUENCE(_s_22304)){
            _12986 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _12986 = 1;
    }
    rhs_slice_target = (object_ptr)&_12987;
    RHS_Slice(_s_22304, _12985, _12986);
    _12988 = _61string_to_int(_12987);
    _12987 = NOVALUE;
    if (IS_ATOM_INT(_12988)) {
        _exp_22307 = _exp_22307 - _12988;
    }
    else {
        _exp_22307 = binary_op(MINUS, _exp_22307, _12988);
    }
    DeRef(_12988);
    _12988 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22307)) {
        _1 = (long)(DBL_PTR(_exp_22307)->dbl);
        DeRefDS(_exp_22307);
        _exp_22307 = _1;
    }
    goto L6; // [131] 201
L5: 

    /** 				if s[e+1] = '+' then*/
    _12990 = _e_22306 + 1;
    _2 = (int)SEQ_PTR(_s_22304);
    _12991 = (int)*(((s1_ptr)_2)->base + _12990);
    if (binary_op_a(NOTEQ, _12991, 43)){
        _12991 = NOVALUE;
        goto L7; // [144] 175
    }
    _12991 = NOVALUE;

    /** 						exp += string_to_int( s[e+2..$] )*/
    _12993 = _e_22306 + 2;
    if ((long)((unsigned long)_12993 + (unsigned long)HIGH_BITS) >= 0) 
    _12993 = NewDouble((double)_12993);
    if (IS_SEQUENCE(_s_22304)){
            _12994 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _12994 = 1;
    }
    rhs_slice_target = (object_ptr)&_12995;
    RHS_Slice(_s_22304, _12993, _12994);
    _12996 = _61string_to_int(_12995);
    _12995 = NOVALUE;
    if (IS_ATOM_INT(_12996)) {
        _exp_22307 = _exp_22307 + _12996;
    }
    else {
        _exp_22307 = binary_op(PLUS, _exp_22307, _12996);
    }
    DeRef(_12996);
    _12996 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22307)) {
        _1 = (long)(DBL_PTR(_exp_22307)->dbl);
        DeRefDS(_exp_22307);
        _exp_22307 = _1;
    }
    goto L8; // [172] 200
L7: 

    /** 						exp += string_to_int( s[e+1..$] )*/
    _12998 = _e_22306 + 1;
    if (_12998 > MAXINT){
        _12998 = NewDouble((double)_12998);
    }
    if (IS_SEQUENCE(_s_22304)){
            _12999 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _12999 = 1;
    }
    rhs_slice_target = (object_ptr)&_13000;
    RHS_Slice(_s_22304, _12998, _12999);
    _13001 = _61string_to_int(_13000);
    _13000 = NOVALUE;
    if (IS_ATOM_INT(_13001)) {
        _exp_22307 = _exp_22307 + _13001;
    }
    else {
        _exp_22307 = binary_op(PLUS, _exp_22307, _13001);
    }
    DeRef(_13001);
    _13001 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22307)) {
        _1 = (long)(DBL_PTR(_exp_22307)->dbl);
        DeRefDS(_exp_22307);
        _exp_22307 = _1;
    }
L8: 
L6: 

    /** 		if dp then*/
    if (_dp_22305 == 0)
    {
        goto L9; // [203] 252
    }
    else{
    }

    /** 				s = s[1..dp-1] & s[dp+1..$]*/
    _13003 = _dp_22305 - 1;
    rhs_slice_target = (object_ptr)&_13004;
    RHS_Slice(_s_22304, 1, _13003);
    _13005 = _dp_22305 + 1;
    if (_13005 > MAXINT){
        _13005 = NewDouble((double)_13005);
    }
    if (IS_SEQUENCE(_s_22304)){
            _13006 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13006 = 1;
    }
    rhs_slice_target = (object_ptr)&_13007;
    RHS_Slice(_s_22304, _13005, _13006);
    Concat((object_ptr)&_s_22304, _13004, _13007);
    DeRefDS(_13004);
    _13004 = NOVALUE;
    DeRef(_13004);
    _13004 = NOVALUE;
    DeRefDS(_13007);
    _13007 = NOVALUE;

    /** 				e -= 1*/
    _e_22306 = _e_22306 - 1;

    /** 				exp -= e - dp*/
    _13010 = _e_22306 - _dp_22305;
    if ((long)((unsigned long)_13010 +(unsigned long) HIGH_BITS) >= 0){
        _13010 = NewDouble((double)_13010);
    }
    if (IS_ATOM_INT(_13010)) {
        _exp_22307 = _exp_22307 - _13010;
    }
    else {
        _exp_22307 = NewDouble((double)_exp_22307 - DBL_PTR(_13010)->dbl);
    }
    DeRef(_13010);
    _13010 = NOVALUE;
    if (!IS_ATOM_INT(_exp_22307)) {
        _1 = (long)(DBL_PTR(_exp_22307)->dbl);
        DeRefDS(_exp_22307);
        _exp_22307 = _1;
    }
L9: 

    /** 		s = s[1..e-1] - '0'*/
    _13012 = _e_22306 - 1;
    rhs_slice_target = (object_ptr)&_13013;
    RHS_Slice(_s_22304, 1, _13012);
    DeRefDS(_s_22304);
    _s_22304 = binary_op(MINUS, _13013, 48);
    DeRefDS(_13013);
    _13013 = NOVALUE;

    /** 		if not find(0, s = 0) then*/
    _13015 = binary_op(EQUALS, _s_22304, 0);
    _13016 = find_from(0, _13015, 1);
    DeRefDS(_13015);
    _13015 = NOVALUE;
    if (_13016 != 0)
    goto LA; // [280] 294
    _13016 = NOVALUE;

    /** 			return atom_to_float64(0)*/
    _13018 = _19atom_to_float64(0);
    DeRefDS(_s_22304);
    DeRef(_int_bits_22308);
    DeRef(_frac_bits_22309);
    DeRef(_mbits_22310);
    DeRef(_ebits_22311);
    DeRefi(_sbits_22312);
    DeRef(_12982);
    _12982 = NOVALUE;
    DeRef(_12985);
    _12985 = NOVALUE;
    DeRef(_12990);
    _12990 = NOVALUE;
    DeRef(_12993);
    _12993 = NOVALUE;
    DeRef(_12998);
    _12998 = NOVALUE;
    DeRef(_13003);
    _13003 = NOVALUE;
    _13012 = NOVALUE;
    DeRef(_13005);
    _13005 = NOVALUE;
    return _13018;
LA: 

    /** 		if exp >= 0 then*/
    if (_exp_22307 < 0)
    goto LB; // [296] 340

    /** 				int_bits = trim_bits( bytes_to_bits( convert_radix( repeat( 0, exp ) & reverse( s ), 10, #100 ) ) )*/
    _13020 = Repeat(0, _exp_22307);
    RefDS(_s_22304);
    _13021 = _61reverse(_s_22304);
    if (IS_SEQUENCE(_13020) && IS_ATOM(_13021)) {
        Ref(_13021);
        Append(&_13022, _13020, _13021);
    }
    else if (IS_ATOM(_13020) && IS_SEQUENCE(_13021)) {
    }
    else {
        Concat((object_ptr)&_13022, _13020, _13021);
        DeRefDS(_13020);
        _13020 = NOVALUE;
    }
    DeRef(_13020);
    _13020 = NOVALUE;
    DeRef(_13021);
    _13021 = NOVALUE;
    _13023 = _61convert_radix(_13022, 10, 256);
    _13022 = NOVALUE;
    _13024 = _61bytes_to_bits(_13023);
    _13023 = NOVALUE;
    _0 = _int_bits_22308;
    _int_bits_22308 = _61trim_bits(_13024);
    DeRef(_0);
    _13024 = NOVALUE;

    /** 				frac_bits = {}*/
    RefDS(_5);
    DeRef(_frac_bits_22309);
    _frac_bits_22309 = _5;
    goto LC; // [337] 451
LB: 

    /** 				if -exp > length(s) then*/
    if ((unsigned long)_exp_22307 == 0xC0000000)
    _13026 = (int)NewDouble((double)-0xC0000000);
    else
    _13026 = - _exp_22307;
    if (IS_SEQUENCE(_s_22304)){
            _13027 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13027 = 1;
    }
    if (binary_op_a(LESSEQ, _13026, _13027)){
        DeRef(_13026);
        _13026 = NOVALUE;
        _13027 = NOVALUE;
        goto LD; // [348] 388
    }
    DeRef(_13026);
    _13026 = NOVALUE;
    _13027 = NOVALUE;

    /** 						int_bits = {}*/
    RefDS(_5);
    DeRef(_int_bits_22308);
    _int_bits_22308 = _5;

    /** 						frac_bits = decimals_to_bits( repeat( 0, -exp-length(s) ) & s ) */
    if ((unsigned long)_exp_22307 == 0xC0000000)
    _13029 = (int)NewDouble((double)-0xC0000000);
    else
    _13029 = - _exp_22307;
    if (IS_SEQUENCE(_s_22304)){
            _13030 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13030 = 1;
    }
    if (IS_ATOM_INT(_13029)) {
        _13031 = _13029 - _13030;
    }
    else {
        _13031 = NewDouble(DBL_PTR(_13029)->dbl - (double)_13030);
    }
    DeRef(_13029);
    _13029 = NOVALUE;
    _13030 = NOVALUE;
    _13032 = Repeat(0, _13031);
    DeRef(_13031);
    _13031 = NOVALUE;
    Concat((object_ptr)&_13033, _13032, _s_22304);
    DeRefDS(_13032);
    _13032 = NOVALUE;
    DeRef(_13032);
    _13032 = NOVALUE;
    _0 = _frac_bits_22309;
    _frac_bits_22309 = _61decimals_to_bits(_13033);
    DeRef(_0);
    _13033 = NOVALUE;
    goto LE; // [385] 450
LD: 

    /** 						int_bits = trim_bits( bytes_to_bits( convert_radix( reverse( s[1..$+exp] ), 10, #100 ) ) )*/
    if (IS_SEQUENCE(_s_22304)){
            _13035 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13035 = 1;
    }
    _13036 = _13035 + _exp_22307;
    _13035 = NOVALUE;
    rhs_slice_target = (object_ptr)&_13037;
    RHS_Slice(_s_22304, 1, _13036);
    _13038 = _61reverse(_13037);
    _13037 = NOVALUE;
    _13039 = _61convert_radix(_13038, 10, 256);
    _13038 = NOVALUE;
    _13040 = _61bytes_to_bits(_13039);
    _13039 = NOVALUE;
    _0 = _int_bits_22308;
    _int_bits_22308 = _61trim_bits(_13040);
    DeRef(_0);
    _13040 = NOVALUE;

    /** 						frac_bits =  decimals_to_bits( s[$+exp+1..$] )*/
    if (IS_SEQUENCE(_s_22304)){
            _13042 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13042 = 1;
    }
    _13043 = _13042 + _exp_22307;
    if ((long)((unsigned long)_13043 + (unsigned long)HIGH_BITS) >= 0) 
    _13043 = NewDouble((double)_13043);
    _13042 = NOVALUE;
    if (IS_ATOM_INT(_13043)) {
        _13044 = _13043 + 1;
        if (_13044 > MAXINT){
            _13044 = NewDouble((double)_13044);
        }
    }
    else
    _13044 = binary_op(PLUS, 1, _13043);
    DeRef(_13043);
    _13043 = NOVALUE;
    if (IS_SEQUENCE(_s_22304)){
            _13045 = SEQ_PTR(_s_22304)->length;
    }
    else {
        _13045 = 1;
    }
    rhs_slice_target = (object_ptr)&_13046;
    RHS_Slice(_s_22304, _13044, _13045);
    _0 = _frac_bits_22309;
    _frac_bits_22309 = _61decimals_to_bits(_13046);
    DeRef(_0);
    _13046 = NOVALUE;
LE: 
LC: 

    /** 		if length(int_bits) >= 53 then*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13048 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13048 = 1;
    }
    if (_13048 < 53)
    goto LF; // [458] 547

    /** 				mbits = int_bits[$-52..$-1]*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13050 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13050 = 1;
    }
    _13051 = _13050 - 52;
    _13050 = NOVALUE;
    if (IS_SEQUENCE(_int_bits_22308)){
            _13052 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13052 = 1;
    }
    _13053 = _13052 - 1;
    _13052 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22310;
    RHS_Slice(_int_bits_22308, _13051, _13053);

    /** 				if length(int_bits) > 53 and int_bits[$-53] then*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13055 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13055 = 1;
    }
    _13056 = (_13055 > 53);
    _13055 = NOVALUE;
    if (_13056 == 0) {
        goto L10; // [492] 535
    }
    if (IS_SEQUENCE(_int_bits_22308)){
            _13058 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13058 = 1;
    }
    _13059 = _13058 - 53;
    _13058 = NOVALUE;
    _2 = (int)SEQ_PTR(_int_bits_22308);
    _13060 = (int)*(((s1_ptr)_2)->base + _13059);
    if (_13060 == 0) {
        _13060 = NOVALUE;
        goto L10; // [508] 535
    }
    else {
        if (!IS_ATOM_INT(_13060) && DBL_PTR(_13060)->dbl == 0.0){
            _13060 = NOVALUE;
            goto L10; // [508] 535
        }
        _13060 = NOVALUE;
    }
    _13060 = NOVALUE;

    /** 						mbits[1] += 1*/
    _2 = (int)SEQ_PTR(_mbits_22310);
    _13061 = (int)*(((s1_ptr)_2)->base + 1);
    if (IS_ATOM_INT(_13061)) {
        _13062 = _13061 + 1;
        if (_13062 > MAXINT){
            _13062 = NewDouble((double)_13062);
        }
    }
    else
    _13062 = binary_op(PLUS, 1, _13061);
    _13061 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22310 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + 1);
    _1 = *(int *)_2;
    *(int *)_2 = _13062;
    if( _1 != _13062 ){
        DeRef(_1);
    }
    _13062 = NOVALUE;

    /** 						mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22310);
    _0 = _mbits_22310;
    _mbits_22310 = _61carry(_mbits_22310, 2);
    DeRefDS(_0);
L10: 

    /** 				exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13064 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13064 = 1;
    }
    _exp_22307 = _13064 - 1;
    _13064 = NOVALUE;
    goto L11; // [544] 783
LF: 

    /** 				if length(int_bits) then*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13066 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13066 = 1;
    }
    if (_13066 == 0)
    {
        _13066 = NOVALUE;
        goto L12; // [552] 567
    }
    else{
        _13066 = NOVALUE;
    }

    /** 						exp = length(int_bits)-1*/
    if (IS_SEQUENCE(_int_bits_22308)){
            _13067 = SEQ_PTR(_int_bits_22308)->length;
    }
    else {
        _13067 = 1;
    }
    _exp_22307 = _13067 - 1;
    _13067 = NOVALUE;
    goto L13; // [564] 622
L12: 

    /** 						exp = - find( 1, reverse( frac_bits ) )*/
    RefDS(_frac_bits_22309);
    _13069 = _61reverse(_frac_bits_22309);
    _13070 = find_from(1, _13069, 1);
    DeRef(_13069);
    _13069 = NOVALUE;
    _exp_22307 = - _13070;

    /** 						if exp < -1023 then*/
    if (_exp_22307 >= -1023)
    goto L14; // [587] 597

    /** 								exp = -1023*/
    _exp_22307 = -1023;
L14: 

    /** 						if exp then*/
    if (_exp_22307 == 0)
    {
        goto L15; // [599] 621
    }
    else{
    }

    /** 								frac_bits = frac_bits[1..$+exp+1]*/
    if (IS_SEQUENCE(_frac_bits_22309)){
            _13075 = SEQ_PTR(_frac_bits_22309)->length;
    }
    else {
        _13075 = 1;
    }
    _13076 = _13075 + _exp_22307;
    if ((long)((unsigned long)_13076 + (unsigned long)HIGH_BITS) >= 0) 
    _13076 = NewDouble((double)_13076);
    _13075 = NOVALUE;
    if (IS_ATOM_INT(_13076)) {
        _13077 = _13076 + 1;
    }
    else
    _13077 = binary_op(PLUS, 1, _13076);
    DeRef(_13076);
    _13076 = NOVALUE;
    rhs_slice_target = (object_ptr)&_frac_bits_22309;
    RHS_Slice(_frac_bits_22309, 1, _13077);
L15: 
L13: 

    /** 				mbits = frac_bits & int_bits*/
    Concat((object_ptr)&_mbits_22310, _frac_bits_22309, _int_bits_22308);

    /** 				mbits = repeat( 0, 53 ) & mbits*/
    _13080 = Repeat(0, 53);
    Concat((object_ptr)&_mbits_22310, _13080, _mbits_22310);
    DeRefDS(_13080);
    _13080 = NOVALUE;
    DeRef(_13080);
    _13080 = NOVALUE;

    /** 				if exp > -1023 then*/
    if (_exp_22307 <= -1023)
    goto L16; // [642] 717

    /** 						if mbits[$-53] then*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13083 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13083 = 1;
    }
    _13084 = _13083 - 53;
    _13083 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    _13085 = (int)*(((s1_ptr)_2)->base + _13084);
    if (_13085 == 0) {
        _13085 = NOVALUE;
        goto L17; // [659] 693
    }
    else {
        if (!IS_ATOM_INT(_13085) && DBL_PTR(_13085)->dbl == 0.0){
            _13085 = NOVALUE;
            goto L17; // [659] 693
        }
        _13085 = NOVALUE;
    }
    _13085 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13086 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13086 = 1;
    }
    _13087 = _13086 - 52;
    _13086 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    _13088 = (int)*(((s1_ptr)_2)->base + _13087);
    if (IS_ATOM_INT(_13088)) {
        _13089 = _13088 + 1;
        if (_13089 > MAXINT){
            _13089 = NewDouble((double)_13089);
        }
    }
    else
    _13089 = binary_op(PLUS, 1, _13088);
    _13088 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22310 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13087);
    _1 = *(int *)_2;
    *(int *)_2 = _13089;
    if( _1 != _13089 ){
        DeRef(_1);
    }
    _13089 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22310);
    _0 = _mbits_22310;
    _mbits_22310 = _61carry(_mbits_22310, 2);
    DeRefDS(_0);
L17: 

    /** 						mbits = mbits[$-52..$-1]*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13091 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13091 = 1;
    }
    _13092 = _13091 - 52;
    _13091 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22310)){
            _13093 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13093 = 1;
    }
    _13094 = _13093 - 1;
    _13093 = NOVALUE;
    rhs_slice_target = (object_ptr)&_mbits_22310;
    RHS_Slice(_mbits_22310, _13092, _13094);
    goto L18; // [714] 782
L16: 

    /** 						if mbits[$-52] then*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13096 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13096 = 1;
    }
    _13097 = _13096 - 52;
    _13096 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    _13098 = (int)*(((s1_ptr)_2)->base + _13097);
    if (_13098 == 0) {
        _13098 = NOVALUE;
        goto L19; // [730] 764
    }
    else {
        if (!IS_ATOM_INT(_13098) && DBL_PTR(_13098)->dbl == 0.0){
            _13098 = NOVALUE;
            goto L19; // [730] 764
        }
        _13098 = NOVALUE;
    }
    _13098 = NOVALUE;

    /** 								mbits[$-52] += 1*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13099 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13099 = 1;
    }
    _13100 = _13099 - 52;
    _13099 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    _13101 = (int)*(((s1_ptr)_2)->base + _13100);
    if (IS_ATOM_INT(_13101)) {
        _13102 = _13101 + 1;
        if (_13102 > MAXINT){
            _13102 = NewDouble((double)_13102);
        }
    }
    else
    _13102 = binary_op(PLUS, 1, _13101);
    _13101 = NOVALUE;
    _2 = (int)SEQ_PTR(_mbits_22310);
    if (!UNIQUE(_2)) {
        _2 = (int)SequenceCopy((s1_ptr)_2);
        _mbits_22310 = MAKE_SEQ(_2);
    }
    _2 = (int)(((s1_ptr)_2)->base + _13100);
    _1 = *(int *)_2;
    *(int *)_2 = _13102;
    if( _1 != _13102 ){
        DeRef(_1);
    }
    _13102 = NOVALUE;

    /** 								mbits = carry( mbits, 2 )*/
    RefDS(_mbits_22310);
    _0 = _mbits_22310;
    _mbits_22310 = _61carry(_mbits_22310, 2);
    DeRefDS(_0);
L19: 

    /** 						mbits = mbits[$-51..$]*/
    if (IS_SEQUENCE(_mbits_22310)){
            _13104 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13104 = 1;
    }
    _13105 = _13104 - 51;
    _13104 = NOVALUE;
    if (IS_SEQUENCE(_mbits_22310)){
            _13106 = SEQ_PTR(_mbits_22310)->length;
    }
    else {
        _13106 = 1;
    }
    rhs_slice_target = (object_ptr)&_mbits_22310;
    RHS_Slice(_mbits_22310, _13105, _13106);
L18: 
L11: 

    /** 		ebits = int_to_bits( exp + 1023, 11 )*/
    _13108 = _exp_22307 + 1023;
    if ((long)((unsigned long)_13108 + (unsigned long)HIGH_BITS) >= 0) 
    _13108 = NewDouble((double)_13108);
    _0 = _ebits_22311;
    _ebits_22311 = _19int_to_bits(_13108, 11);
    DeRef(_0);
    _13108 = NOVALUE;

    /** 		return bits_to_bytes( mbits & ebits & sbits )*/
    {
        int concat_list[3];

        concat_list[0] = _sbits_22312;
        concat_list[1] = _ebits_22311;
        concat_list[2] = _mbits_22310;
        Concat_N((object_ptr)&_13110, concat_list, 3);
    }
    _13111 = _61bits_to_bytes(_13110);
    _13110 = NOVALUE;
    DeRefDS(_s_22304);
    DeRef(_int_bits_22308);
    DeRef(_frac_bits_22309);
    DeRefDS(_mbits_22310);
    DeRefDS(_ebits_22311);
    DeRefDSi(_sbits_22312);
    DeRef(_13018);
    _13018 = NOVALUE;
    DeRef(_13105);
    _13105 = NOVALUE;
    DeRef(_13097);
    _13097 = NOVALUE;
    DeRef(_13059);
    _13059 = NOVALUE;
    DeRef(_13005);
    _13005 = NOVALUE;
    DeRef(_12982);
    _12982 = NOVALUE;
    DeRef(_12993);
    _12993 = NOVALUE;
    DeRef(_13092);
    _13092 = NOVALUE;
    DeRef(_13084);
    _13084 = NOVALUE;
    DeRef(_12990);
    _12990 = NOVALUE;
    DeRef(_13056);
    _13056 = NOVALUE;
    DeRef(_13012);
    _13012 = NOVALUE;
    DeRef(_13051);
    _13051 = NOVALUE;
    DeRef(_12985);
    _12985 = NOVALUE;
    DeRef(_13077);
    _13077 = NOVALUE;
    DeRef(_13087);
    _13087 = NOVALUE;
    DeRef(_13053);
    _13053 = NOVALUE;
    DeRef(_13094);
    _13094 = NOVALUE;
    DeRef(_13003);
    _13003 = NOVALUE;
    DeRef(_13100);
    _13100 = NOVALUE;
    DeRef(_12998);
    _12998 = NOVALUE;
    DeRef(_13036);
    _13036 = NOVALUE;
    DeRef(_13044);
    _13044 = NOVALUE;
    return _13111;
    ;
}


int _61scientific_to_atom(int _s_22485)
{
    int _13113 = NOVALUE;
    int _13112 = NOVALUE;
    int _0, _1, _2;
    

    /** 		return float64_to_atom( scientific_to_float64( s ) )*/
    RefDS(_s_22485);
    _13112 = _61scientific_to_float64(_s_22485);
    _13113 = _19float64_to_atom(_13112);
    _13112 = NOVALUE;
    DeRefDS(_s_22485);
    return _13113;
    ;
}



// 0xD688B22F
